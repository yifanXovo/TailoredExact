* Signature: 0x615bb797602ace73
NAME R160_physical_neighborhood
ROWS
 N  OBJ
 G  product_lb_0
 L  product_ub_1
 G  product_lb_2
 L  product_ub_3
 G  product_lb_4
 L  product_ub_5
 G  product_lb_6
 L  product_ub_7
 G  product_lb_8
 L  product_ub_9
 G  product_lb_10
 L  product_ub_11
 G  product_lb_12
 L  product_ub_13
 G  product_lb_14
 L  product_ub_15
 G  product_lb_16
 L  product_ub_17
 G  product_lb_18
 L  product_ub_19
 G  product_lb_20
 L  product_ub_21
 E  onehot_6_22
 E  normalized_mass_6_23
 E  normalized_ratio_6_24
 G  product_lb_25
 L  product_ub_26
 G  product_lb_27
 L  product_ub_28
 G  product_lb_29
 L  product_ub_30
 G  product_lb_31
 L  product_ub_32
 G  product_lb_33
 L  product_ub_34
 G  product_lb_35
 L  product_ub_36
 G  product_lb_37
 L  product_ub_38
 G  product_lb_39
 L  product_ub_40
 G  product_lb_41
 L  product_ub_42
 G  product_lb_43
 L  product_ub_44
 G  product_lb_45
 L  product_ub_46
 G  product_lb_47
 L  product_ub_48
 G  product_lb_49
 L  product_ub_50
 G  product_lb_51
 L  product_ub_52
 G  product_lb_53
 L  product_ub_54
 G  product_lb_55
 L  product_ub_56
 E  onehot_2_57
 E  normalized_mass_2_58
 E  normalized_ratio_2_59
 G  product_lb_60
 L  product_ub_61
 G  product_lb_62
 L  product_ub_63
 G  product_lb_64
 L  product_ub_65
 G  product_lb_66
 L  product_ub_67
 G  product_lb_68
 L  product_ub_69
 G  product_lb_70
 L  product_ub_71
 G  product_lb_72
 L  product_ub_73
 G  product_lb_74
 L  product_ub_75
 G  product_lb_76
 L  product_ub_77
 G  product_lb_78
 L  product_ub_79
 G  product_lb_80
 L  product_ub_81
 G  product_lb_82
 L  product_ub_83
 G  product_lb_84
 L  product_ub_85
 E  onehot_31_86
 E  normalized_mass_31_87
 E  normalized_ratio_31_88
 G  product_lb_89
 L  product_ub_90
 G  product_lb_91
 L  product_ub_92
 G  product_lb_93
 L  product_ub_94
 G  product_lb_95
 L  product_ub_96
 G  product_lb_97
 L  product_ub_98
 G  product_lb_99
 L  product_ub_100
 G  product_lb_101
 L  product_ub_102
 G  product_lb_103
 L  product_ub_104
 G  product_lb_105
 L  product_ub_106
 G  product_lb_107
 L  product_ub_108
 G  product_lb_109
 L  product_ub_110
 G  product_lb_111
 L  product_ub_112
 G  product_lb_113
 L  product_ub_114
 E  onehot_9_115
 E  normalized_mass_9_116
 E  normalized_ratio_9_117
 G  product_lb_118
 L  product_ub_119
 G  product_lb_120
 L  product_ub_121
 G  product_lb_122
 L  product_ub_123
 G  product_lb_124
 L  product_ub_125
 G  product_lb_126
 L  product_ub_127
 G  product_lb_128
 L  product_ub_129
 G  product_lb_130
 L  product_ub_131
 G  product_lb_132
 L  product_ub_133
 G  product_lb_134
 L  product_ub_135
 G  product_lb_136
 L  product_ub_137
 G  product_lb_138
 L  product_ub_139
 G  product_lb_140
 L  product_ub_141
 G  product_lb_142
 L  product_ub_143
 E  onehot_32_144
 E  normalized_mass_32_145
 E  normalized_ratio_32_146
 G  product_lb_147
 L  product_ub_148
 G  product_lb_149
 L  product_ub_150
 G  product_lb_151
 L  product_ub_152
 G  product_lb_153
 L  product_ub_154
 G  product_lb_155
 L  product_ub_156
 G  product_lb_157
 L  product_ub_158
 G  product_lb_159
 L  product_ub_160
 G  product_lb_161
 L  product_ub_162
 G  product_lb_163
 L  product_ub_164
 G  product_lb_165
 L  product_ub_166
 G  product_lb_167
 L  product_ub_168
 G  product_lb_169
 L  product_ub_170
 G  product_lb_171
 L  product_ub_172
 G  product_lb_173
 L  product_ub_174
 G  product_lb_175
 L  product_ub_176
 G  product_lb_177
 L  product_ub_178
 G  product_lb_179
 L  product_ub_180
 G  product_lb_181
 L  product_ub_182
 G  product_lb_183
 L  product_ub_184
 G  product_lb_185
 L  product_ub_186
 G  product_lb_187
 L  product_ub_188
 G  product_lb_189
 L  product_ub_190
 E  onehot_8_191
 E  normalized_mass_8_192
 E  normalized_ratio_8_193
 G  product_lb_194
 L  product_ub_195
 G  product_lb_196
 L  product_ub_197
 G  product_lb_198
 L  product_ub_199
 G  product_lb_200
 L  product_ub_201
 G  product_lb_202
 L  product_ub_203
 G  product_lb_204
 L  product_ub_205
 G  product_lb_206
 L  product_ub_207
 G  product_lb_208
 L  product_ub_209
 G  product_lb_210
 L  product_ub_211
 G  product_lb_212
 L  product_ub_213
 G  product_lb_214
 L  product_ub_215
 G  product_lb_216
 L  product_ub_217
 G  product_lb_218
 L  product_ub_219
 E  onehot_16_220
 E  normalized_mass_16_221
 E  normalized_ratio_16_222
 G  product_lb_223
 L  product_ub_224
 G  product_lb_225
 L  product_ub_226
 G  product_lb_227
 L  product_ub_228
 G  product_lb_229
 L  product_ub_230
 G  product_lb_231
 L  product_ub_232
 G  product_lb_233
 L  product_ub_234
 G  product_lb_235
 L  product_ub_236
 G  product_lb_237
 L  product_ub_238
 G  product_lb_239
 L  product_ub_240
 G  product_lb_241
 L  product_ub_242
 G  product_lb_243
 L  product_ub_244
 G  product_lb_245
 L  product_ub_246
 G  product_lb_247
 L  product_ub_248
 G  product_lb_249
 L  product_ub_250
 G  product_lb_251
 L  product_ub_252
 G  product_lb_253
 L  product_ub_254
 G  product_lb_255
 L  product_ub_256
 G  product_lb_257
 L  product_ub_258
 G  product_lb_259
 L  product_ub_260
 G  product_lb_261
 L  product_ub_262
 E  onehot_13_263
 E  normalized_mass_13_264
 E  normalized_ratio_13_265
 G  stock_lb_266
 L  stock_ub_267
 L  parent_nonstrict_scope_268
 G  block_pair_pos_269
 G  block_pair_neg_270
 G  block_pair_pos_271
 G  block_pair_neg_272
 G  block_pair_pos_273
 G  block_pair_neg_274
 G  block_pair_pos_275
 G  block_pair_neg_276
 G  block_pair_pos_277
 G  block_pair_neg_278
 G  block_pair_pos_279
 G  block_pair_neg_280
 G  block_pair_pos_281
 G  block_pair_neg_282
 G  block_pair_pos_283
 G  block_pair_neg_284
 G  block_pair_pos_285
 G  block_pair_neg_286
 G  block_pair_pos_287
 G  block_pair_neg_288
 G  block_pair_pos_289
 G  block_pair_neg_290
 G  block_pair_pos_291
 G  block_pair_neg_292
 G  block_pair_pos_293
 G  block_pair_neg_294
 G  block_pair_pos_295
 G  block_pair_neg_296
 G  block_pair_pos_297
 G  block_pair_neg_298
 G  block_pair_pos_299
 G  block_pair_neg_300
 G  block_pair_pos_301
 G  block_pair_neg_302
 G  block_pair_pos_303
 G  block_pair_neg_304
 G  block_pair_pos_305
 G  block_pair_neg_306
 G  block_pair_pos_307
 G  block_pair_neg_308
 G  block_pair_pos_309
 G  block_pair_neg_310
 G  block_pair_pos_311
 G  block_pair_neg_312
 G  block_pair_pos_313
 G  block_pair_neg_314
 G  block_pair_pos_315
 G  block_pair_neg_316
 G  block_pair_pos_317
 G  block_pair_neg_318
 G  block_pair_pos_319
 G  block_pair_neg_320
 G  block_pair_pos_321
 G  block_pair_neg_322
 G  block_pair_pos_323
 G  block_pair_neg_324
 E  normalization_325
 G  full_original_Gini_326
 E  unique_nonzero_owner_327
 E  unique_nonzero_owner_328
 E  unique_nonzero_owner_329
 E  unique_nonzero_owner_330
 E  unique_nonzero_owner_331
 E  unique_nonzero_owner_332
 E  unique_nonzero_owner_333
 E  unique_nonzero_owner_334
 E  unique_nonzero_owner_335
 E  unique_nonzero_owner_336
 E  unique_nonzero_owner_337
 E  unique_nonzero_owner_338
 E  unique_nonzero_owner_339
 E  unique_nonzero_owner_340
 E  unique_nonzero_owner_341
 E  unique_nonzero_owner_342
 E  unique_nonzero_owner_343
 E  unique_nonzero_owner_344
 E  unique_nonzero_owner_345
 E  unique_nonzero_owner_346
 E  unique_nonzero_owner_347
 E  unique_nonzero_owner_348
 E  unique_nonzero_owner_349
 E  unique_nonzero_owner_350
 E  unique_nonzero_owner_351
 E  unique_nonzero_owner_352
 E  unique_nonzero_owner_353
 E  unique_nonzero_owner_354
 E  unique_nonzero_owner_355
 E  unique_nonzero_owner_356
 E  unique_nonzero_owner_357
 E  unique_nonzero_owner_358
 E  unique_nonzero_owner_359
 E  unique_nonzero_owner_360
 E  unique_nonzero_owner_361
 E  unique_nonzero_owner_362
 E  unique_nonzero_owner_363
 E  unique_nonzero_owner_364
 E  unique_nonzero_owner_365
 E  unique_nonzero_owner_366
 E  unique_nonzero_owner_367
 E  unique_nonzero_owner_368
 E  unique_nonzero_owner_369
 E  unique_nonzero_owner_370
 E  unique_nonzero_owner_371
 E  unique_nonzero_owner_372
 E  unique_nonzero_owner_373
 E  unique_nonzero_owner_374
 E  unique_nonzero_owner_375
 E  unique_nonzero_owner_376
 E  unique_nonzero_owner_377
 E  unique_nonzero_owner_378
 E  unique_nonzero_owner_379
 E  unique_nonzero_owner_380
 E  unique_nonzero_owner_381
 E  unique_nonzero_owner_382
 E  unique_nonzero_owner_383
 E  unique_nonzero_owner_384
 E  unique_nonzero_owner_385
 E  unique_nonzero_owner_386
 E  unique_nonzero_owner_387
 E  unique_nonzero_owner_388
 E  unique_nonzero_owner_389
 E  unique_nonzero_owner_390
 E  unique_nonzero_owner_391
 E  unique_nonzero_owner_392
 E  unique_nonzero_owner_393
 E  unique_nonzero_owner_394
 E  unique_nonzero_owner_395
 E  unique_nonzero_owner_396
 E  unique_nonzero_owner_397
 E  unique_nonzero_owner_398
 E  unique_nonzero_owner_399
 E  unique_nonzero_owner_400
 E  unique_nonzero_owner_401
 E  unique_nonzero_owner_402
 E  unique_nonzero_owner_403
 E  unique_nonzero_owner_404
 E  unique_nonzero_owner_405
 E  unique_nonzero_owner_406
 E  unique_nonzero_owner_407
 E  unique_nonzero_owner_408
 E  unique_nonzero_owner_409
 E  unique_nonzero_owner_410
 E  unique_nonzero_owner_411
 E  unique_nonzero_owner_412
 E  unique_nonzero_owner_413
 E  unique_nonzero_owner_414
 E  unique_nonzero_owner_415
 E  unique_nonzero_owner_416
 E  unique_nonzero_owner_417
 E  unique_nonzero_owner_418
 E  unique_nonzero_owner_419
 E  unique_nonzero_owner_420
 E  unique_nonzero_owner_421
 E  unique_nonzero_owner_422
 E  unique_nonzero_owner_423
 E  unique_nonzero_owner_424
 E  unique_nonzero_owner_425
 E  unique_nonzero_owner_426
 E  unique_nonzero_owner_427
 E  unique_nonzero_owner_428
 E  unique_nonzero_owner_429
 E  unique_nonzero_owner_430
 E  unique_nonzero_owner_431
 E  unique_nonzero_owner_432
 E  unique_nonzero_owner_433
 E  unique_nonzero_owner_434
 E  unique_nonzero_owner_435
 E  unique_nonzero_owner_436
 E  unique_nonzero_owner_437
 E  unique_nonzero_owner_438
 E  unique_nonzero_owner_439
 L  arc_capacity_440
 L  arc_capacity_441
 L  arc_capacity_442
 L  arc_capacity_443
 L  arc_capacity_444
 L  arc_capacity_445
 L  arc_capacity_446
 L  arc_capacity_447
 L  arc_capacity_448
 L  arc_capacity_449
 L  arc_capacity_450
 L  arc_capacity_451
 L  arc_capacity_452
 L  arc_capacity_453
 L  arc_capacity_454
 L  arc_capacity_455
 L  arc_capacity_456
 G  connected_order_arc_457
 L  arc_capacity_458
 G  connected_order_arc_459
 L  arc_capacity_460
 G  connected_order_arc_461
 L  arc_capacity_462
 G  connected_order_arc_463
 L  arc_capacity_464
 G  connected_order_arc_465
 L  arc_capacity_466
 G  connected_order_arc_467
 L  arc_capacity_468
 G  connected_order_arc_469
 L  arc_capacity_470
 G  connected_order_arc_471
 L  arc_capacity_472
 G  connected_order_arc_473
 L  arc_capacity_474
 G  connected_order_arc_475
 L  arc_capacity_476
 G  connected_order_arc_477
 L  arc_capacity_478
 G  connected_order_arc_479
 L  arc_capacity_480
 G  connected_order_arc_481
 L  arc_capacity_482
 L  arc_capacity_483
 G  connected_order_arc_484
 L  arc_capacity_485
 G  connected_order_arc_486
 L  arc_capacity_487
 G  connected_order_arc_488
 L  arc_capacity_489
 G  connected_order_arc_490
 L  arc_capacity_491
 G  connected_order_arc_492
 L  arc_capacity_493
 G  connected_order_arc_494
 L  arc_capacity_495
 G  connected_order_arc_496
 L  arc_capacity_497
 G  connected_order_arc_498
 L  arc_capacity_499
 G  connected_order_arc_500
 L  arc_capacity_501
 G  connected_order_arc_502
 L  arc_capacity_503
 G  connected_order_arc_504
 L  arc_capacity_505
 G  connected_order_arc_506
 L  arc_capacity_507
 G  connected_order_arc_508
 L  arc_capacity_509
 L  arc_capacity_510
 G  connected_order_arc_511
 L  arc_capacity_512
 G  connected_order_arc_513
 L  arc_capacity_514
 G  connected_order_arc_515
 L  arc_capacity_516
 G  connected_order_arc_517
 L  arc_capacity_518
 G  connected_order_arc_519
 L  arc_capacity_520
 G  connected_order_arc_521
 L  arc_capacity_522
 G  connected_order_arc_523
 L  arc_capacity_524
 G  connected_order_arc_525
 L  arc_capacity_526
 G  connected_order_arc_527
 L  arc_capacity_528
 G  connected_order_arc_529
 L  arc_capacity_530
 G  connected_order_arc_531
 L  arc_capacity_532
 G  connected_order_arc_533
 L  arc_capacity_534
 G  connected_order_arc_535
 L  arc_capacity_536
 L  arc_capacity_537
 G  connected_order_arc_538
 L  arc_capacity_539
 G  connected_order_arc_540
 L  arc_capacity_541
 G  connected_order_arc_542
 L  arc_capacity_543
 G  connected_order_arc_544
 L  arc_capacity_545
 G  connected_order_arc_546
 L  arc_capacity_547
 G  connected_order_arc_548
 L  arc_capacity_549
 G  connected_order_arc_550
 L  arc_capacity_551
 G  connected_order_arc_552
 L  arc_capacity_553
 G  connected_order_arc_554
 L  arc_capacity_555
 G  connected_order_arc_556
 L  arc_capacity_557
 G  connected_order_arc_558
 L  arc_capacity_559
 G  connected_order_arc_560
 L  arc_capacity_561
 G  connected_order_arc_562
 L  arc_capacity_563
 L  arc_capacity_564
 G  connected_order_arc_565
 L  arc_capacity_566
 G  connected_order_arc_567
 L  arc_capacity_568
 G  connected_order_arc_569
 L  arc_capacity_570
 G  connected_order_arc_571
 L  arc_capacity_572
 G  connected_order_arc_573
 L  arc_capacity_574
 G  connected_order_arc_575
 L  arc_capacity_576
 G  connected_order_arc_577
 L  arc_capacity_578
 G  connected_order_arc_579
 L  arc_capacity_580
 G  connected_order_arc_581
 L  arc_capacity_582
 G  connected_order_arc_583
 L  arc_capacity_584
 G  connected_order_arc_585
 L  arc_capacity_586
 G  connected_order_arc_587
 L  arc_capacity_588
 G  connected_order_arc_589
 L  arc_capacity_590
 L  arc_capacity_591
 G  connected_order_arc_592
 L  arc_capacity_593
 G  connected_order_arc_594
 L  arc_capacity_595
 G  connected_order_arc_596
 L  arc_capacity_597
 G  connected_order_arc_598
 L  arc_capacity_599
 G  connected_order_arc_600
 L  arc_capacity_601
 G  connected_order_arc_602
 L  arc_capacity_603
 G  connected_order_arc_604
 L  arc_capacity_605
 G  connected_order_arc_606
 L  arc_capacity_607
 G  connected_order_arc_608
 L  arc_capacity_609
 G  connected_order_arc_610
 L  arc_capacity_611
 G  connected_order_arc_612
 L  arc_capacity_613
 G  connected_order_arc_614
 L  arc_capacity_615
 G  connected_order_arc_616
 L  arc_capacity_617
 L  arc_capacity_618
 G  connected_order_arc_619
 L  arc_capacity_620
 G  connected_order_arc_621
 L  arc_capacity_622
 G  connected_order_arc_623
 L  arc_capacity_624
 G  connected_order_arc_625
 L  arc_capacity_626
 G  connected_order_arc_627
 L  arc_capacity_628
 G  connected_order_arc_629
 L  arc_capacity_630
 G  connected_order_arc_631
 L  arc_capacity_632
 G  connected_order_arc_633
 L  arc_capacity_634
 G  connected_order_arc_635
 L  arc_capacity_636
 G  connected_order_arc_637
 L  arc_capacity_638
 G  connected_order_arc_639
 L  arc_capacity_640
 G  connected_order_arc_641
 L  arc_capacity_642
 G  connected_order_arc_643
 L  arc_capacity_644
 L  arc_capacity_645
 G  connected_order_arc_646
 L  arc_capacity_647
 G  connected_order_arc_648
 L  arc_capacity_649
 G  connected_order_arc_650
 L  arc_capacity_651
 G  connected_order_arc_652
 L  arc_capacity_653
 G  connected_order_arc_654
 L  arc_capacity_655
 G  connected_order_arc_656
 L  arc_capacity_657
 G  connected_order_arc_658
 L  arc_capacity_659
 G  connected_order_arc_660
 L  arc_capacity_661
 G  connected_order_arc_662
 L  arc_capacity_663
 G  connected_order_arc_664
 L  arc_capacity_665
 G  connected_order_arc_666
 L  arc_capacity_667
 G  connected_order_arc_668
 L  arc_capacity_669
 G  connected_order_arc_670
 L  arc_capacity_671
 L  arc_capacity_672
 G  connected_order_arc_673
 L  arc_capacity_674
 G  connected_order_arc_675
 L  arc_capacity_676
 G  connected_order_arc_677
 L  arc_capacity_678
 G  connected_order_arc_679
 L  arc_capacity_680
 G  connected_order_arc_681
 L  arc_capacity_682
 G  connected_order_arc_683
 L  arc_capacity_684
 G  connected_order_arc_685
 L  arc_capacity_686
 G  connected_order_arc_687
 L  arc_capacity_688
 G  connected_order_arc_689
 L  arc_capacity_690
 G  connected_order_arc_691
 L  arc_capacity_692
 G  connected_order_arc_693
 L  arc_capacity_694
 G  connected_order_arc_695
 L  arc_capacity_696
 G  connected_order_arc_697
 L  arc_capacity_698
 L  arc_capacity_699
 G  connected_order_arc_700
 L  arc_capacity_701
 G  connected_order_arc_702
 L  arc_capacity_703
 G  connected_order_arc_704
 L  arc_capacity_705
 G  connected_order_arc_706
 L  arc_capacity_707
 G  connected_order_arc_708
 L  arc_capacity_709
 G  connected_order_arc_710
 L  arc_capacity_711
 G  connected_order_arc_712
 L  arc_capacity_713
 G  connected_order_arc_714
 L  arc_capacity_715
 G  connected_order_arc_716
 L  arc_capacity_717
 G  connected_order_arc_718
 L  arc_capacity_719
 G  connected_order_arc_720
 L  arc_capacity_721
 G  connected_order_arc_722
 L  arc_capacity_723
 G  connected_order_arc_724
 L  arc_capacity_725
 L  arc_capacity_726
 G  connected_order_arc_727
 L  arc_capacity_728
 G  connected_order_arc_729
 L  arc_capacity_730
 G  connected_order_arc_731
 L  arc_capacity_732
 G  connected_order_arc_733
 L  arc_capacity_734
 G  connected_order_arc_735
 L  arc_capacity_736
 G  connected_order_arc_737
 L  arc_capacity_738
 G  connected_order_arc_739
 L  arc_capacity_740
 G  connected_order_arc_741
 L  arc_capacity_742
 G  connected_order_arc_743
 L  arc_capacity_744
 G  connected_order_arc_745
 L  arc_capacity_746
 G  connected_order_arc_747
 L  arc_capacity_748
 G  connected_order_arc_749
 L  arc_capacity_750
 G  connected_order_arc_751
 L  arc_capacity_752
 L  arc_capacity_753
 G  connected_order_arc_754
 L  arc_capacity_755
 G  connected_order_arc_756
 L  arc_capacity_757
 G  connected_order_arc_758
 L  arc_capacity_759
 G  connected_order_arc_760
 L  arc_capacity_761
 G  connected_order_arc_762
 L  arc_capacity_763
 G  connected_order_arc_764
 L  arc_capacity_765
 G  connected_order_arc_766
 L  arc_capacity_767
 G  connected_order_arc_768
 L  arc_capacity_769
 G  connected_order_arc_770
 L  arc_capacity_771
 G  connected_order_arc_772
 L  arc_capacity_773
 G  connected_order_arc_774
 L  arc_capacity_775
 G  connected_order_arc_776
 L  arc_capacity_777
 G  connected_order_arc_778
 L  arc_capacity_779
 L  arc_capacity_780
 G  connected_order_arc_781
 L  arc_capacity_782
 G  connected_order_arc_783
 L  arc_capacity_784
 G  connected_order_arc_785
 L  arc_capacity_786
 G  connected_order_arc_787
 L  arc_capacity_788
 G  connected_order_arc_789
 L  arc_capacity_790
 G  connected_order_arc_791
 L  arc_capacity_792
 G  connected_order_arc_793
 L  arc_capacity_794
 G  connected_order_arc_795
 L  arc_capacity_796
 G  connected_order_arc_797
 L  arc_capacity_798
 G  connected_order_arc_799
 L  arc_capacity_800
 G  connected_order_arc_801
 L  arc_capacity_802
 G  connected_order_arc_803
 L  arc_capacity_804
 G  connected_order_arc_805
 L  arc_capacity_806
 L  arc_capacity_807
 G  connected_order_arc_808
 L  arc_capacity_809
 G  connected_order_arc_810
 L  arc_capacity_811
 G  connected_order_arc_812
 L  arc_capacity_813
 G  connected_order_arc_814
 L  arc_capacity_815
 G  connected_order_arc_816
 L  arc_capacity_817
 G  connected_order_arc_818
 L  arc_capacity_819
 G  connected_order_arc_820
 L  arc_capacity_821
 G  connected_order_arc_822
 L  arc_capacity_823
 G  connected_order_arc_824
 L  arc_capacity_825
 G  connected_order_arc_826
 L  arc_capacity_827
 G  connected_order_arc_828
 L  arc_capacity_829
 G  connected_order_arc_830
 L  arc_capacity_831
 G  connected_order_arc_832
 E  depot_departure_or_bypass_833
 E  depot_return_or_bypass_834
 E  out_degree_835
 E  in_degree_836
 G  order_active_lb_837
 L  order_active_ub_838
 E  segment_load_conservation_839
 G  segment_prefix_lb_840
 L  segment_prefix_ub_841
 E  out_degree_842
 E  in_degree_843
 G  order_active_lb_844
 L  order_active_ub_845
 E  segment_load_conservation_846
 G  segment_prefix_lb_847
 L  segment_prefix_ub_848
 E  out_degree_849
 E  in_degree_850
 G  order_active_lb_851
 L  order_active_ub_852
 E  segment_load_conservation_853
 G  segment_prefix_lb_854
 L  segment_prefix_ub_855
 E  out_degree_856
 E  in_degree_857
 G  order_active_lb_858
 L  order_active_ub_859
 E  segment_load_conservation_860
 G  segment_prefix_lb_861
 L  segment_prefix_ub_862
 E  out_degree_863
 E  in_degree_864
 G  order_active_lb_865
 L  order_active_ub_866
 E  segment_load_conservation_867
 G  segment_prefix_lb_868
 L  segment_prefix_ub_869
 E  out_degree_870
 E  in_degree_871
 G  order_active_lb_872
 L  order_active_ub_873
 E  segment_load_conservation_874
 G  segment_prefix_lb_875
 L  segment_prefix_ub_876
 E  out_degree_877
 E  in_degree_878
 G  order_active_lb_879
 L  order_active_ub_880
 E  service_visit_def_881
 E  free_load_conservation_882
 E  out_degree_883
 E  in_degree_884
 G  order_active_lb_885
 L  order_active_ub_886
 E  service_visit_def_887
 E  free_load_conservation_888
 E  out_degree_889
 E  in_degree_890
 G  order_active_lb_891
 L  order_active_ub_892
 E  service_visit_def_893
 E  free_load_conservation_894
 E  out_degree_895
 E  in_degree_896
 G  order_active_lb_897
 L  order_active_ub_898
 E  service_visit_def_899
 E  free_load_conservation_900
 E  out_degree_901
 E  in_degree_902
 G  order_active_lb_903
 L  order_active_ub_904
 E  service_visit_def_905
 E  free_load_conservation_906
 E  out_degree_907
 E  in_degree_908
 G  order_active_lb_909
 L  order_active_ub_910
 E  service_visit_def_911
 E  free_load_conservation_912
 E  out_degree_913
 E  in_degree_914
 G  order_active_lb_915
 L  order_active_ub_916
 E  service_visit_def_917
 E  free_load_conservation_918
 E  out_degree_919
 E  in_degree_920
 G  order_active_lb_921
 L  order_active_ub_922
 E  service_visit_def_923
 E  free_load_conservation_924
 G  fixed_segment_relative_order_925
 G  fixed_segment_relative_order_926
 G  fixed_segment_relative_order_927
 G  fixed_segment_relative_order_928
 G  fixed_segment_relative_order_929
 L  original_T_including_depot_unload_930
 L  arc_capacity_931
 L  arc_capacity_932
 L  arc_capacity_933
 L  arc_capacity_934
 L  arc_capacity_935
 L  arc_capacity_936
 L  arc_capacity_937
 L  arc_capacity_938
 L  arc_capacity_939
 L  arc_capacity_940
 L  arc_capacity_941
 L  arc_capacity_942
 L  arc_capacity_943
 L  arc_capacity_944
 L  arc_capacity_945
 G  connected_order_arc_946
 L  arc_capacity_947
 G  connected_order_arc_948
 L  arc_capacity_949
 G  connected_order_arc_950
 L  arc_capacity_951
 G  connected_order_arc_952
 L  arc_capacity_953
 G  connected_order_arc_954
 L  arc_capacity_955
 G  connected_order_arc_956
 L  arc_capacity_957
 G  connected_order_arc_958
 L  arc_capacity_959
 G  connected_order_arc_960
 L  arc_capacity_961
 G  connected_order_arc_962
 L  arc_capacity_963
 G  connected_order_arc_964
 L  arc_capacity_965
 G  connected_order_arc_966
 L  arc_capacity_967
 L  arc_capacity_968
 G  connected_order_arc_969
 L  arc_capacity_970
 G  connected_order_arc_971
 L  arc_capacity_972
 G  connected_order_arc_973
 L  arc_capacity_974
 G  connected_order_arc_975
 L  arc_capacity_976
 G  connected_order_arc_977
 L  arc_capacity_978
 G  connected_order_arc_979
 L  arc_capacity_980
 G  connected_order_arc_981
 L  arc_capacity_982
 G  connected_order_arc_983
 L  arc_capacity_984
 G  connected_order_arc_985
 L  arc_capacity_986
 G  connected_order_arc_987
 L  arc_capacity_988
 G  connected_order_arc_989
 L  arc_capacity_990
 L  arc_capacity_991
 G  connected_order_arc_992
 L  arc_capacity_993
 G  connected_order_arc_994
 L  arc_capacity_995
 G  connected_order_arc_996
 L  arc_capacity_997
 G  connected_order_arc_998
 L  arc_capacity_999
 G  connected_order_arc_1000
 L  arc_capacity_1001
 G  connected_order_arc_1002
 L  arc_capacity_1003
 G  connected_order_arc_1004
 L  arc_capacity_1005
 G  connected_order_arc_1006
 L  arc_capacity_1007
 G  connected_order_arc_1008
 L  arc_capacity_1009
 G  connected_order_arc_1010
 L  arc_capacity_1011
 G  connected_order_arc_1012
 L  arc_capacity_1013
 L  arc_capacity_1014
 G  connected_order_arc_1015
 L  arc_capacity_1016
 G  connected_order_arc_1017
 L  arc_capacity_1018
 G  connected_order_arc_1019
 L  arc_capacity_1020
 G  connected_order_arc_1021
 L  arc_capacity_1022
 G  connected_order_arc_1023
 L  arc_capacity_1024
 G  connected_order_arc_1025
 L  arc_capacity_1026
 G  connected_order_arc_1027
 L  arc_capacity_1028
 G  connected_order_arc_1029
 L  arc_capacity_1030
 G  connected_order_arc_1031
 L  arc_capacity_1032
 G  connected_order_arc_1033
 L  arc_capacity_1034
 G  connected_order_arc_1035
 L  arc_capacity_1036
 L  arc_capacity_1037
 G  connected_order_arc_1038
 L  arc_capacity_1039
 G  connected_order_arc_1040
 L  arc_capacity_1041
 G  connected_order_arc_1042
 L  arc_capacity_1043
 G  connected_order_arc_1044
 L  arc_capacity_1045
 G  connected_order_arc_1046
 L  arc_capacity_1047
 G  connected_order_arc_1048
 L  arc_capacity_1049
 G  connected_order_arc_1050
 L  arc_capacity_1051
 G  connected_order_arc_1052
 L  arc_capacity_1053
 G  connected_order_arc_1054
 L  arc_capacity_1055
 G  connected_order_arc_1056
 L  arc_capacity_1057
 G  connected_order_arc_1058
 L  arc_capacity_1059
 L  arc_capacity_1060
 G  connected_order_arc_1061
 L  arc_capacity_1062
 G  connected_order_arc_1063
 L  arc_capacity_1064
 G  connected_order_arc_1065
 L  arc_capacity_1066
 G  connected_order_arc_1067
 L  arc_capacity_1068
 G  connected_order_arc_1069
 L  arc_capacity_1070
 G  connected_order_arc_1071
 L  arc_capacity_1072
 G  connected_order_arc_1073
 L  arc_capacity_1074
 G  connected_order_arc_1075
 L  arc_capacity_1076
 G  connected_order_arc_1077
 L  arc_capacity_1078
 G  connected_order_arc_1079
 L  arc_capacity_1080
 G  connected_order_arc_1081
 L  arc_capacity_1082
 L  arc_capacity_1083
 G  connected_order_arc_1084
 L  arc_capacity_1085
 G  connected_order_arc_1086
 L  arc_capacity_1087
 G  connected_order_arc_1088
 L  arc_capacity_1089
 G  connected_order_arc_1090
 L  arc_capacity_1091
 G  connected_order_arc_1092
 L  arc_capacity_1093
 G  connected_order_arc_1094
 L  arc_capacity_1095
 G  connected_order_arc_1096
 L  arc_capacity_1097
 G  connected_order_arc_1098
 L  arc_capacity_1099
 G  connected_order_arc_1100
 L  arc_capacity_1101
 G  connected_order_arc_1102
 L  arc_capacity_1103
 G  connected_order_arc_1104
 L  arc_capacity_1105
 L  arc_capacity_1106
 G  connected_order_arc_1107
 L  arc_capacity_1108
 G  connected_order_arc_1109
 L  arc_capacity_1110
 G  connected_order_arc_1111
 L  arc_capacity_1112
 G  connected_order_arc_1113
 L  arc_capacity_1114
 G  connected_order_arc_1115
 L  arc_capacity_1116
 G  connected_order_arc_1117
 L  arc_capacity_1118
 G  connected_order_arc_1119
 L  arc_capacity_1120
 G  connected_order_arc_1121
 L  arc_capacity_1122
 G  connected_order_arc_1123
 L  arc_capacity_1124
 G  connected_order_arc_1125
 L  arc_capacity_1126
 G  connected_order_arc_1127
 L  arc_capacity_1128
 L  arc_capacity_1129
 G  connected_order_arc_1130
 L  arc_capacity_1131
 G  connected_order_arc_1132
 L  arc_capacity_1133
 G  connected_order_arc_1134
 L  arc_capacity_1135
 G  connected_order_arc_1136
 L  arc_capacity_1137
 G  connected_order_arc_1138
 L  arc_capacity_1139
 G  connected_order_arc_1140
 L  arc_capacity_1141
 G  connected_order_arc_1142
 L  arc_capacity_1143
 G  connected_order_arc_1144
 L  arc_capacity_1145
 G  connected_order_arc_1146
 L  arc_capacity_1147
 G  connected_order_arc_1148
 L  arc_capacity_1149
 G  connected_order_arc_1150
 L  arc_capacity_1151
 L  arc_capacity_1152
 G  connected_order_arc_1153
 L  arc_capacity_1154
 G  connected_order_arc_1155
 L  arc_capacity_1156
 G  connected_order_arc_1157
 L  arc_capacity_1158
 G  connected_order_arc_1159
 L  arc_capacity_1160
 G  connected_order_arc_1161
 L  arc_capacity_1162
 G  connected_order_arc_1163
 L  arc_capacity_1164
 G  connected_order_arc_1165
 L  arc_capacity_1166
 G  connected_order_arc_1167
 L  arc_capacity_1168
 G  connected_order_arc_1169
 L  arc_capacity_1170
 G  connected_order_arc_1171
 L  arc_capacity_1172
 G  connected_order_arc_1173
 L  arc_capacity_1174
 L  arc_capacity_1175
 G  connected_order_arc_1176
 L  arc_capacity_1177
 G  connected_order_arc_1178
 L  arc_capacity_1179
 G  connected_order_arc_1180
 L  arc_capacity_1181
 G  connected_order_arc_1182
 L  arc_capacity_1183
 G  connected_order_arc_1184
 L  arc_capacity_1185
 G  connected_order_arc_1186
 L  arc_capacity_1187
 G  connected_order_arc_1188
 L  arc_capacity_1189
 G  connected_order_arc_1190
 L  arc_capacity_1191
 G  connected_order_arc_1192
 L  arc_capacity_1193
 G  connected_order_arc_1194
 L  arc_capacity_1195
 G  connected_order_arc_1196
 L  arc_capacity_1197
 L  arc_capacity_1198
 G  connected_order_arc_1199
 L  arc_capacity_1200
 G  connected_order_arc_1201
 L  arc_capacity_1202
 G  connected_order_arc_1203
 L  arc_capacity_1204
 G  connected_order_arc_1205
 L  arc_capacity_1206
 G  connected_order_arc_1207
 L  arc_capacity_1208
 G  connected_order_arc_1209
 L  arc_capacity_1210
 G  connected_order_arc_1211
 L  arc_capacity_1212
 G  connected_order_arc_1213
 L  arc_capacity_1214
 G  connected_order_arc_1215
 L  arc_capacity_1216
 G  connected_order_arc_1217
 L  arc_capacity_1218
 G  connected_order_arc_1219
 E  depot_departure_or_bypass_1220
 E  depot_return_or_bypass_1221
 E  out_degree_1222
 E  in_degree_1223
 G  order_active_lb_1224
 L  order_active_ub_1225
 E  segment_load_conservation_1226
 G  segment_prefix_lb_1227
 L  segment_prefix_ub_1228
 E  out_degree_1229
 E  in_degree_1230
 G  order_active_lb_1231
 L  order_active_ub_1232
 E  segment_load_conservation_1233
 G  segment_prefix_lb_1234
 L  segment_prefix_ub_1235
 E  out_degree_1236
 E  in_degree_1237
 G  order_active_lb_1238
 L  order_active_ub_1239
 E  segment_load_conservation_1240
 G  segment_prefix_lb_1241
 L  segment_prefix_ub_1242
 E  out_degree_1243
 E  in_degree_1244
 G  order_active_lb_1245
 L  order_active_ub_1246
 E  segment_load_conservation_1247
 G  segment_prefix_lb_1248
 L  segment_prefix_ub_1249
 E  out_degree_1250
 E  in_degree_1251
 G  order_active_lb_1252
 L  order_active_ub_1253
 E  service_visit_def_1254
 E  free_load_conservation_1255
 E  out_degree_1256
 E  in_degree_1257
 G  order_active_lb_1258
 L  order_active_ub_1259
 E  service_visit_def_1260
 E  free_load_conservation_1261
 E  out_degree_1262
 E  in_degree_1263
 G  order_active_lb_1264
 L  order_active_ub_1265
 E  service_visit_def_1266
 E  free_load_conservation_1267
 E  out_degree_1268
 E  in_degree_1269
 G  order_active_lb_1270
 L  order_active_ub_1271
 E  service_visit_def_1272
 E  free_load_conservation_1273
 E  out_degree_1274
 E  in_degree_1275
 G  order_active_lb_1276
 L  order_active_ub_1277
 E  service_visit_def_1278
 E  free_load_conservation_1279
 E  out_degree_1280
 E  in_degree_1281
 G  order_active_lb_1282
 L  order_active_ub_1283
 E  service_visit_def_1284
 E  free_load_conservation_1285
 E  out_degree_1286
 E  in_degree_1287
 G  order_active_lb_1288
 L  order_active_ub_1289
 E  service_visit_def_1290
 E  free_load_conservation_1291
 E  out_degree_1292
 E  in_degree_1293
 G  order_active_lb_1294
 L  order_active_ub_1295
 E  service_visit_def_1296
 E  free_load_conservation_1297
 G  fixed_segment_relative_order_1298
 G  fixed_segment_relative_order_1299
 G  fixed_segment_relative_order_1300
 L  original_T_including_depot_unload_1301
 L  arc_capacity_1302
 L  arc_capacity_1303
 L  arc_capacity_1304
 L  arc_capacity_1305
 L  arc_capacity_1306
 L  arc_capacity_1307
 L  arc_capacity_1308
 L  arc_capacity_1309
 L  arc_capacity_1310
 L  arc_capacity_1311
 L  arc_capacity_1312
 L  arc_capacity_1313
 L  arc_capacity_1314
 L  arc_capacity_1315
 L  arc_capacity_1316
 G  connected_order_arc_1317
 L  arc_capacity_1318
 G  connected_order_arc_1319
 L  arc_capacity_1320
 G  connected_order_arc_1321
 L  arc_capacity_1322
 G  connected_order_arc_1323
 L  arc_capacity_1324
 G  connected_order_arc_1325
 L  arc_capacity_1326
 G  connected_order_arc_1327
 L  arc_capacity_1328
 G  connected_order_arc_1329
 L  arc_capacity_1330
 G  connected_order_arc_1331
 L  arc_capacity_1332
 G  connected_order_arc_1333
 L  arc_capacity_1334
 G  connected_order_arc_1335
 L  arc_capacity_1336
 G  connected_order_arc_1337
 L  arc_capacity_1338
 L  arc_capacity_1339
 G  connected_order_arc_1340
 L  arc_capacity_1341
 G  connected_order_arc_1342
 L  arc_capacity_1343
 G  connected_order_arc_1344
 L  arc_capacity_1345
 G  connected_order_arc_1346
 L  arc_capacity_1347
 G  connected_order_arc_1348
 L  arc_capacity_1349
 G  connected_order_arc_1350
 L  arc_capacity_1351
 G  connected_order_arc_1352
 L  arc_capacity_1353
 G  connected_order_arc_1354
 L  arc_capacity_1355
 G  connected_order_arc_1356
 L  arc_capacity_1357
 G  connected_order_arc_1358
 L  arc_capacity_1359
 G  connected_order_arc_1360
 L  arc_capacity_1361
 L  arc_capacity_1362
 G  connected_order_arc_1363
 L  arc_capacity_1364
 G  connected_order_arc_1365
 L  arc_capacity_1366
 G  connected_order_arc_1367
 L  arc_capacity_1368
 G  connected_order_arc_1369
 L  arc_capacity_1370
 G  connected_order_arc_1371
 L  arc_capacity_1372
 G  connected_order_arc_1373
 L  arc_capacity_1374
 G  connected_order_arc_1375
 L  arc_capacity_1376
 G  connected_order_arc_1377
 L  arc_capacity_1378
 G  connected_order_arc_1379
 L  arc_capacity_1380
 G  connected_order_arc_1381
 L  arc_capacity_1382
 G  connected_order_arc_1383
 L  arc_capacity_1384
 L  arc_capacity_1385
 G  connected_order_arc_1386
 L  arc_capacity_1387
 G  connected_order_arc_1388
 L  arc_capacity_1389
 G  connected_order_arc_1390
 L  arc_capacity_1391
 G  connected_order_arc_1392
 L  arc_capacity_1393
 G  connected_order_arc_1394
 L  arc_capacity_1395
 G  connected_order_arc_1396
 L  arc_capacity_1397
 G  connected_order_arc_1398
 L  arc_capacity_1399
 G  connected_order_arc_1400
 L  arc_capacity_1401
 G  connected_order_arc_1402
 L  arc_capacity_1403
 G  connected_order_arc_1404
 L  arc_capacity_1405
 G  connected_order_arc_1406
 L  arc_capacity_1407
 L  arc_capacity_1408
 G  connected_order_arc_1409
 L  arc_capacity_1410
 G  connected_order_arc_1411
 L  arc_capacity_1412
 G  connected_order_arc_1413
 L  arc_capacity_1414
 G  connected_order_arc_1415
 L  arc_capacity_1416
 G  connected_order_arc_1417
 L  arc_capacity_1418
 G  connected_order_arc_1419
 L  arc_capacity_1420
 G  connected_order_arc_1421
 L  arc_capacity_1422
 G  connected_order_arc_1423
 L  arc_capacity_1424
 G  connected_order_arc_1425
 L  arc_capacity_1426
 G  connected_order_arc_1427
 L  arc_capacity_1428
 G  connected_order_arc_1429
 L  arc_capacity_1430
 L  arc_capacity_1431
 G  connected_order_arc_1432
 L  arc_capacity_1433
 G  connected_order_arc_1434
 L  arc_capacity_1435
 G  connected_order_arc_1436
 L  arc_capacity_1437
 G  connected_order_arc_1438
 L  arc_capacity_1439
 G  connected_order_arc_1440
 L  arc_capacity_1441
 G  connected_order_arc_1442
 L  arc_capacity_1443
 G  connected_order_arc_1444
 L  arc_capacity_1445
 G  connected_order_arc_1446
 L  arc_capacity_1447
 G  connected_order_arc_1448
 L  arc_capacity_1449
 G  connected_order_arc_1450
 L  arc_capacity_1451
 G  connected_order_arc_1452
 L  arc_capacity_1453
 L  arc_capacity_1454
 G  connected_order_arc_1455
 L  arc_capacity_1456
 G  connected_order_arc_1457
 L  arc_capacity_1458
 G  connected_order_arc_1459
 L  arc_capacity_1460
 G  connected_order_arc_1461
 L  arc_capacity_1462
 G  connected_order_arc_1463
 L  arc_capacity_1464
 G  connected_order_arc_1465
 L  arc_capacity_1466
 G  connected_order_arc_1467
 L  arc_capacity_1468
 G  connected_order_arc_1469
 L  arc_capacity_1470
 G  connected_order_arc_1471
 L  arc_capacity_1472
 G  connected_order_arc_1473
 L  arc_capacity_1474
 G  connected_order_arc_1475
 L  arc_capacity_1476
 L  arc_capacity_1477
 G  connected_order_arc_1478
 L  arc_capacity_1479
 G  connected_order_arc_1480
 L  arc_capacity_1481
 G  connected_order_arc_1482
 L  arc_capacity_1483
 G  connected_order_arc_1484
 L  arc_capacity_1485
 G  connected_order_arc_1486
 L  arc_capacity_1487
 G  connected_order_arc_1488
 L  arc_capacity_1489
 G  connected_order_arc_1490
 L  arc_capacity_1491
 G  connected_order_arc_1492
 L  arc_capacity_1493
 G  connected_order_arc_1494
 L  arc_capacity_1495
 G  connected_order_arc_1496
 L  arc_capacity_1497
 G  connected_order_arc_1498
 L  arc_capacity_1499
 L  arc_capacity_1500
 G  connected_order_arc_1501
 L  arc_capacity_1502
 G  connected_order_arc_1503
 L  arc_capacity_1504
 G  connected_order_arc_1505
 L  arc_capacity_1506
 G  connected_order_arc_1507
 L  arc_capacity_1508
 G  connected_order_arc_1509
 L  arc_capacity_1510
 G  connected_order_arc_1511
 L  arc_capacity_1512
 G  connected_order_arc_1513
 L  arc_capacity_1514
 G  connected_order_arc_1515
 L  arc_capacity_1516
 G  connected_order_arc_1517
 L  arc_capacity_1518
 G  connected_order_arc_1519
 L  arc_capacity_1520
 G  connected_order_arc_1521
 L  arc_capacity_1522
 L  arc_capacity_1523
 G  connected_order_arc_1524
 L  arc_capacity_1525
 G  connected_order_arc_1526
 L  arc_capacity_1527
 G  connected_order_arc_1528
 L  arc_capacity_1529
 G  connected_order_arc_1530
 L  arc_capacity_1531
 G  connected_order_arc_1532
 L  arc_capacity_1533
 G  connected_order_arc_1534
 L  arc_capacity_1535
 G  connected_order_arc_1536
 L  arc_capacity_1537
 G  connected_order_arc_1538
 L  arc_capacity_1539
 G  connected_order_arc_1540
 L  arc_capacity_1541
 G  connected_order_arc_1542
 L  arc_capacity_1543
 G  connected_order_arc_1544
 L  arc_capacity_1545
 L  arc_capacity_1546
 G  connected_order_arc_1547
 L  arc_capacity_1548
 G  connected_order_arc_1549
 L  arc_capacity_1550
 G  connected_order_arc_1551
 L  arc_capacity_1552
 G  connected_order_arc_1553
 L  arc_capacity_1554
 G  connected_order_arc_1555
 L  arc_capacity_1556
 G  connected_order_arc_1557
 L  arc_capacity_1558
 G  connected_order_arc_1559
 L  arc_capacity_1560
 G  connected_order_arc_1561
 L  arc_capacity_1562
 G  connected_order_arc_1563
 L  arc_capacity_1564
 G  connected_order_arc_1565
 L  arc_capacity_1566
 G  connected_order_arc_1567
 L  arc_capacity_1568
 L  arc_capacity_1569
 G  connected_order_arc_1570
 L  arc_capacity_1571
 G  connected_order_arc_1572
 L  arc_capacity_1573
 G  connected_order_arc_1574
 L  arc_capacity_1575
 G  connected_order_arc_1576
 L  arc_capacity_1577
 G  connected_order_arc_1578
 L  arc_capacity_1579
 G  connected_order_arc_1580
 L  arc_capacity_1581
 G  connected_order_arc_1582
 L  arc_capacity_1583
 G  connected_order_arc_1584
 L  arc_capacity_1585
 G  connected_order_arc_1586
 L  arc_capacity_1587
 G  connected_order_arc_1588
 L  arc_capacity_1589
 G  connected_order_arc_1590
 E  depot_departure_or_bypass_1591
 E  depot_return_or_bypass_1592
 E  out_degree_1593
 E  in_degree_1594
 G  order_active_lb_1595
 L  order_active_ub_1596
 E  segment_load_conservation_1597
 G  segment_prefix_lb_1598
 L  segment_prefix_ub_1599
 E  out_degree_1600
 E  in_degree_1601
 G  order_active_lb_1602
 L  order_active_ub_1603
 E  segment_load_conservation_1604
 G  segment_prefix_lb_1605
 L  segment_prefix_ub_1606
 E  out_degree_1607
 E  in_degree_1608
 G  order_active_lb_1609
 L  order_active_ub_1610
 E  segment_load_conservation_1611
 G  segment_prefix_lb_1612
 L  segment_prefix_ub_1613
 E  out_degree_1614
 E  in_degree_1615
 G  order_active_lb_1616
 L  order_active_ub_1617
 E  segment_load_conservation_1618
 G  segment_prefix_lb_1619
 L  segment_prefix_ub_1620
 E  out_degree_1621
 E  in_degree_1622
 G  order_active_lb_1623
 L  order_active_ub_1624
 E  service_visit_def_1625
 E  free_load_conservation_1626
 E  out_degree_1627
 E  in_degree_1628
 G  order_active_lb_1629
 L  order_active_ub_1630
 E  service_visit_def_1631
 E  free_load_conservation_1632
 E  out_degree_1633
 E  in_degree_1634
 G  order_active_lb_1635
 L  order_active_ub_1636
 E  service_visit_def_1637
 E  free_load_conservation_1638
 E  out_degree_1639
 E  in_degree_1640
 G  order_active_lb_1641
 L  order_active_ub_1642
 E  service_visit_def_1643
 E  free_load_conservation_1644
 E  out_degree_1645
 E  in_degree_1646
 G  order_active_lb_1647
 L  order_active_ub_1648
 E  service_visit_def_1649
 E  free_load_conservation_1650
 E  out_degree_1651
 E  in_degree_1652
 G  order_active_lb_1653
 L  order_active_ub_1654
 E  service_visit_def_1655
 E  free_load_conservation_1656
 E  out_degree_1657
 E  in_degree_1658
 G  order_active_lb_1659
 L  order_active_ub_1660
 E  service_visit_def_1661
 E  free_load_conservation_1662
 E  out_degree_1663
 E  in_degree_1664
 G  order_active_lb_1665
 L  order_active_ub_1666
 E  service_visit_def_1667
 E  free_load_conservation_1668
 G  fixed_segment_relative_order_1669
 G  fixed_segment_relative_order_1670
 G  fixed_segment_relative_order_1671
 L  original_T_including_depot_unload_1672
COLUMNS
    t         normalized_mass_6_23  -1
    t         normalized_mass_2_58  -1
    t         normalized_mass_31_87  -1
    t         normalized_mass_9_116  -1
    t         normalized_mass_32_145  -1
    t         normalized_mass_8_192  -1
    t         normalized_mass_16_221  -1
    t         normalized_mass_13_264  -1
    t         normalization_325  2.4078571428571429e+01
    t         full_original_Gini_326  -8.1378571428571448e+01
    q         OBJ       1
    q         parent_nonstrict_scope_268  1
    q         full_original_Gini_326  35
    MARKER    'MARKER'                 'INTORG'
    x_6_0     OBJ       0.01875
    x_6_0     product_lb_0  -2.4265534275042893e-02
    x_6_0     product_ub_1  -4.1530703055514692e-02
    x_6_0     onehot_6_22  1
    x_6_0     parent_nonstrict_scope_268  0.0375
    x_6_0     unique_nonzero_owner_327  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_0     product_lb_0  1
    w_6_0     product_ub_1  1
    w_6_0     normalized_mass_6_23  1
    w_6_0     full_original_Gini_326  -2.4078571428571429e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_1     OBJ       0.01125
    x_6_1     product_lb_2  -2.4265534275042893e-02
    x_6_1     product_ub_3  -4.1530703055514692e-02
    x_6_1     onehot_6_22  1
    x_6_1     stock_lb_266  1
    x_6_1     stock_ub_267  1
    x_6_1     parent_nonstrict_scope_268  0.03
    MARKER    'MARKER'                 'INTEND'
    w_6_1     product_lb_2  1
    w_6_1     product_ub_3  1
    w_6_1     normalized_mass_6_23  1
    w_6_1     normalized_ratio_6_24  -0.2
    w_6_1     full_original_Gini_326  -1.8678571428571438e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_2     OBJ       0.00375
    x_6_2     product_lb_4  -2.4265534275042893e-02
    x_6_2     product_ub_5  -4.1530703055514692e-02
    x_6_2     onehot_6_22  1
    x_6_2     stock_lb_266  2
    x_6_2     stock_ub_267  2
    x_6_2     parent_nonstrict_scope_268  0.0225
    x_6_2     unique_nonzero_owner_328  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_2     product_lb_4  1
    w_6_2     product_ub_5  1
    w_6_2     normalized_mass_6_23  1
    w_6_2     normalized_ratio_6_24  -0.4
    w_6_2     full_original_Gini_326  -1.3878571428571426e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_3     OBJ       -3.7500000000000033e-03
    x_6_3     product_lb_6  -2.4265534275042893e-02
    x_6_3     product_ub_7  -4.1530703055514692e-02
    x_6_3     onehot_6_22  1
    x_6_3     stock_lb_266  3
    x_6_3     stock_ub_267  3
    x_6_3     parent_nonstrict_scope_268  1.4999999999999996e-02
    x_6_3     unique_nonzero_owner_329  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_3     product_lb_6  1
    w_6_3     product_ub_7  1
    w_6_3     normalized_mass_6_23  1
    w_6_3     normalized_ratio_6_24  -6.0000000000000009e-01
    w_6_3     full_original_Gini_326  -9.6785714285714288e+00
    MARKER    'MARKER'                 'INTORG'
    x_6_4     OBJ       -1.1250000000000001e-02
    x_6_4     product_lb_8  -2.4265534275042893e-02
    x_6_4     product_ub_9  -4.1530703055514692e-02
    x_6_4     onehot_6_22  1
    x_6_4     stock_lb_266  4
    x_6_4     stock_ub_267  4
    x_6_4     parent_nonstrict_scope_268  7.4999999999999980e-03
    x_6_4     unique_nonzero_owner_330  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_4     product_lb_8  1
    w_6_4     product_ub_9  1
    w_6_4     normalized_mass_6_23  1
    w_6_4     normalized_ratio_6_24  -0.8
    w_6_4     full_original_Gini_326  -5.7500000000000018e+00
    MARKER    'MARKER'                 'INTORG'
    x_6_5     OBJ       -0.01875
    x_6_5     product_lb_10  -2.4265534275042893e-02
    x_6_5     product_ub_11  -4.1530703055514692e-02
    x_6_5     onehot_6_22  1
    x_6_5     stock_lb_266  5
    x_6_5     stock_ub_267  5
    x_6_5     unique_nonzero_owner_331  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_5     product_lb_10  1
    w_6_5     product_ub_11  1
    w_6_5     normalized_mass_6_23  1
    w_6_5     normalized_ratio_6_24  -1
    w_6_5     full_original_Gini_326  -3.8214285714285721e+00
    MARKER    'MARKER'                 'INTORG'
    x_6_6     OBJ       -1.1249999999999993e-02
    x_6_6     product_lb_12  -2.4265534275042893e-02
    x_6_6     product_ub_13  -4.1530703055514692e-02
    x_6_6     onehot_6_22  1
    x_6_6     stock_lb_266  6
    x_6_6     stock_ub_267  6
    x_6_6     parent_nonstrict_scope_268  7.5000000000000067e-03
    x_6_6     unique_nonzero_owner_332  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_6     product_lb_12  1
    w_6_6     product_ub_13  1
    w_6_6     normalized_mass_6_23  1
    w_6_6     normalized_ratio_6_24  -1.2000000000000002e+00
    w_6_6     full_original_Gini_326  -8.4214285714285744e+00
    MARKER    'MARKER'                 'INTORG'
    x_6_7     OBJ       -3.7499999999999947e-03
    x_6_7     product_lb_14  -2.4265534275042893e-02
    x_6_7     product_ub_15  -4.1530703055514692e-02
    x_6_7     onehot_6_22  1
    x_6_7     stock_lb_266  7
    x_6_7     stock_ub_267  7
    x_6_7     parent_nonstrict_scope_268  1.5000000000000005e-02
    x_6_7     unique_nonzero_owner_333  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_7     product_lb_14  1
    w_6_7     product_ub_15  1
    w_6_7     normalized_mass_6_23  1
    w_6_7     normalized_ratio_6_24  -1.4000000000000001e+00
    w_6_7     full_original_Gini_326  -1.3721428571428577e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_8     OBJ       3.7500000000000033e-03
    x_6_8     product_lb_16  -2.4265534275042893e-02
    x_6_8     product_ub_17  -4.1530703055514692e-02
    x_6_8     onehot_6_22  1
    x_6_8     stock_lb_266  8
    x_6_8     stock_ub_267  8
    x_6_8     parent_nonstrict_scope_268  2.2500000000000003e-02
    x_6_8     unique_nonzero_owner_334  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_8     product_lb_16  1
    w_6_8     product_ub_17  1
    w_6_8     normalized_mass_6_23  1
    w_6_8     normalized_ratio_6_24  -1.6
    w_6_8     full_original_Gini_326  -1.9121428571428574e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_9     OBJ       0.01125
    x_6_9     product_lb_18  -2.4265534275042893e-02
    x_6_9     product_ub_19  -4.1530703055514692e-02
    x_6_9     onehot_6_22  1
    x_6_9     stock_lb_266  9
    x_6_9     stock_ub_267  9
    x_6_9     parent_nonstrict_scope_268  0.03
    x_6_9     unique_nonzero_owner_335  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_9     product_lb_18  1
    w_6_9     product_ub_19  1
    w_6_9     normalized_mass_6_23  1
    w_6_9     normalized_ratio_6_24  -1.8
    w_6_9     full_original_Gini_326  -2.4521428571428579e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_10    OBJ       0.01875
    x_6_10    product_lb_20  -2.4265534275042893e-02
    x_6_10    product_ub_21  -4.1530703055514692e-02
    x_6_10    onehot_6_22  1
    x_6_10    stock_lb_266  10
    x_6_10    stock_ub_267  10
    x_6_10    parent_nonstrict_scope_268  0.0375
    x_6_10    unique_nonzero_owner_336  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_10    product_lb_20  1
    w_6_10    product_ub_21  1
    w_6_10    normalized_mass_6_23  1
    w_6_10    normalized_ratio_6_24  -2
    w_6_10    full_original_Gini_326  -2.9921428571428571e+01
    rho_6     normalized_ratio_6_24  1
    rho_6     block_pair_pos_281  -1
    rho_6     block_pair_neg_282  1
    rho_6     block_pair_pos_283  -1
    rho_6     block_pair_neg_284  1
    rho_6     block_pair_pos_285  -1
    rho_6     block_pair_neg_286  1
    rho_6     block_pair_pos_287  -1
    rho_6     block_pair_neg_288  1
    rho_6     block_pair_pos_289  -1
    rho_6     block_pair_neg_290  1
    rho_6     block_pair_pos_291  -1
    rho_6     block_pair_neg_292  1
    rho_6     block_pair_pos_293  -1
    rho_6     block_pair_neg_294  1
    rho_6     normalization_325  1
    MARKER    'MARKER'                 'INTORG'
    x_2_0     OBJ       0.0315
    x_2_0     product_lb_25  -2.4265534275042893e-02
    x_2_0     product_ub_26  -4.1530703055514692e-02
    x_2_0     onehot_2_57  1
    x_2_0     parent_nonstrict_scope_268  0.0735
    MARKER    'MARKER'                 'INTEND'
    w_2_0     product_lb_25  1
    w_2_0     product_ub_26  1
    w_2_0     normalized_mass_2_58  1
    w_2_0     full_original_Gini_326  -2.4078571428571429e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_1     OBJ       2.1000000000000005e-02
    x_2_1     product_lb_27  -2.4265534275042893e-02
    x_2_1     product_ub_28  -4.1530703055514692e-02
    x_2_1     onehot_2_57  1
    x_2_1     stock_lb_266  1
    x_2_1     stock_ub_267  1
    x_2_1     parent_nonstrict_scope_268  0.063
    x_2_1     unique_nonzero_owner_337  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_1     product_lb_27  1
    w_2_1     product_ub_28  1
    w_2_1     normalized_mass_2_58  1
    w_2_1     normalized_ratio_2_59  -1.4285714285714285e-01
    w_2_1     full_original_Gini_326  -2.0221428571428579e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_2     OBJ       1.0500000000000002e-02
    x_2_2     product_lb_29  -2.4265534275042893e-02
    x_2_2     product_ub_30  -4.1530703055514692e-02
    x_2_2     onehot_2_57  1
    x_2_2     stock_lb_266  2
    x_2_2     stock_ub_267  2
    x_2_2     parent_nonstrict_scope_268  0.0525
    x_2_2     unique_nonzero_owner_338  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_2     product_lb_29  1
    w_2_2     product_ub_30  1
    w_2_2     normalized_mass_2_58  1
    w_2_2     normalized_ratio_2_59  -2.8571428571428570e-01
    w_2_2     full_original_Gini_326  -1.6507142857142853e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_3     product_lb_31  -2.4265534275042893e-02
    x_2_3     product_ub_32  -4.1530703055514692e-02
    x_2_3     onehot_2_57  1
    x_2_3     stock_lb_266  3
    x_2_3     stock_ub_267  3
    x_2_3     parent_nonstrict_scope_268  4.1999999999999996e-02
    x_2_3     unique_nonzero_owner_339  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_3     product_lb_31  1
    w_2_3     product_ub_32  1
    w_2_3     normalized_mass_2_58  1
    w_2_3     normalized_ratio_2_59  -4.2857142857142855e-01
    w_2_3     full_original_Gini_326  -1.3278571428571427e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_4     OBJ       -1.0499999999999995e-02
    x_2_4     product_lb_33  -2.4265534275042893e-02
    x_2_4     product_ub_34  -4.1530703055514692e-02
    x_2_4     onehot_2_57  1
    x_2_4     stock_lb_266  4
    x_2_4     stock_ub_267  4
    x_2_4     parent_nonstrict_scope_268  0.0315
    x_2_4     unique_nonzero_owner_340  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_4     product_lb_33  1
    w_2_4     product_ub_34  1
    w_2_4     normalized_mass_2_58  1
    w_2_4     normalized_ratio_2_59  -5.7142857142857140e-01
    w_2_4     full_original_Gini_326  -1.0278571428571432e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_5     OBJ       -2.0999999999999991e-02
    x_2_5     product_lb_35  -2.4265534275042893e-02
    x_2_5     product_ub_36  -4.1530703055514692e-02
    x_2_5     onehot_2_57  1
    x_2_5     stock_lb_266  5
    x_2_5     stock_ub_267  5
    x_2_5     parent_nonstrict_scope_268  2.1000000000000005e-02
    x_2_5     unique_nonzero_owner_341  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_5     product_lb_35  1
    w_2_5     product_ub_36  1
    w_2_5     normalized_mass_2_58  1
    w_2_5     normalized_ratio_2_59  -7.1428571428571419e-01
    w_2_5     full_original_Gini_326  -7.2785714285714285e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_6     OBJ       -3.1499999999999993e-02
    x_2_6     product_lb_37  -2.4265534275042893e-02
    x_2_6     product_ub_38  -4.1530703055514692e-02
    x_2_6     onehot_2_57  1
    x_2_6     stock_lb_266  6
    x_2_6     stock_ub_267  6
    x_2_6     parent_nonstrict_scope_268  1.0500000000000002e-02
    x_2_6     unique_nonzero_owner_342  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_6     product_lb_37  1
    w_2_6     product_ub_38  1
    w_2_6     normalized_mass_2_58  1
    w_2_6     normalized_ratio_2_59  -8.5714285714285710e-01
    w_2_6     full_original_Gini_326  -4.8928571428571432e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_7     OBJ       -4.1999999999999996e-02
    x_2_7     product_lb_39  -2.4265534275042893e-02
    x_2_7     product_ub_40  -4.1530703055514692e-02
    x_2_7     onehot_2_57  1
    x_2_7     stock_lb_266  7
    x_2_7     stock_ub_267  7
    x_2_7     unique_nonzero_owner_343  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_7     product_lb_39  1
    w_2_7     product_ub_40  1
    w_2_7     normalized_mass_2_58  1
    w_2_7     normalized_ratio_2_59  -1
    w_2_7     full_original_Gini_326  -3.8214285714285721e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_8     OBJ       -0.0315
    x_2_8     product_lb_41  -2.4265534275042893e-02
    x_2_8     product_ub_42  -4.1530703055514692e-02
    x_2_8     onehot_2_57  1
    x_2_8     stock_lb_266  8
    x_2_8     stock_ub_267  8
    x_2_8     parent_nonstrict_scope_268  1.0499999999999995e-02
    x_2_8     unique_nonzero_owner_344  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_8     product_lb_41  1
    w_2_8     product_ub_42  1
    w_2_8     normalized_mass_2_58  1
    w_2_8     normalized_ratio_2_59  -1.1428571428571428e+00
    w_2_8     full_original_Gini_326  -7.1071428571428541e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_9     OBJ       -2.1000000000000005e-02
    x_2_9     product_lb_43  -2.4265534275042893e-02
    x_2_9     product_ub_44  -4.1530703055514692e-02
    x_2_9     onehot_2_57  1
    x_2_9     stock_lb_266  9
    x_2_9     stock_ub_267  9
    x_2_9     parent_nonstrict_scope_268  2.0999999999999991e-02
    x_2_9     unique_nonzero_owner_345  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_9     product_lb_43  1
    w_2_9     product_ub_44  1
    w_2_9     normalized_mass_2_58  1
    w_2_9     normalized_ratio_2_59  -1.2857142857142856e+00
    w_2_9     full_original_Gini_326  -1.0635714285714283e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_10    OBJ       -1.0500000000000009e-02
    x_2_10    product_lb_45  -2.4265534275042893e-02
    x_2_10    product_ub_46  -4.1530703055514692e-02
    x_2_10    onehot_2_57  1
    x_2_10    stock_lb_266  10
    x_2_10    stock_ub_267  10
    x_2_10    parent_nonstrict_scope_268  3.1499999999999986e-02
    x_2_10    unique_nonzero_owner_346  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_10    product_lb_45  1
    w_2_10    product_ub_46  1
    w_2_10    normalized_mass_2_58  1
    w_2_10    normalized_ratio_2_59  -1.4285714285714284e+00
    w_2_10    full_original_Gini_326  -1.4492857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_11    product_lb_47  -2.4265534275042893e-02
    x_2_11    product_ub_48  -4.1530703055514692e-02
    x_2_11    onehot_2_57  1
    x_2_11    stock_lb_266  11
    x_2_11    stock_ub_267  11
    x_2_11    parent_nonstrict_scope_268  4.1999999999999996e-02
    x_2_11    unique_nonzero_owner_347  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_11    product_lb_47  1
    w_2_11    product_ub_48  1
    w_2_11    normalized_mass_2_58  1
    w_2_11    normalized_ratio_2_59  -1.5714285714285714e+00
    w_2_11    full_original_Gini_326  -1.8349999999999998e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_12    OBJ       1.0499999999999995e-02
    x_2_12    product_lb_49  -2.4265534275042893e-02
    x_2_12    product_ub_50  -4.1530703055514692e-02
    x_2_12    onehot_2_57  1
    x_2_12    stock_lb_266  12
    x_2_12    stock_ub_267  12
    x_2_12    parent_nonstrict_scope_268  5.2499999999999991e-02
    x_2_12    unique_nonzero_owner_348  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_12    product_lb_49  1
    w_2_12    product_ub_50  1
    w_2_12    normalized_mass_2_58  1
    w_2_12    normalized_ratio_2_59  -1.7142857142857142e+00
    w_2_12    full_original_Gini_326  -2.2207142857142856e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_13    OBJ       2.0999999999999991e-02
    x_2_13    product_lb_51  -2.4265534275042893e-02
    x_2_13    product_ub_52  -4.1530703055514692e-02
    x_2_13    onehot_2_57  1
    x_2_13    stock_lb_266  13
    x_2_13    stock_ub_267  13
    x_2_13    parent_nonstrict_scope_268  6.2999999999999987e-02
    x_2_13    unique_nonzero_owner_349  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_13    product_lb_51  1
    w_2_13    product_ub_52  1
    w_2_13    normalized_mass_2_58  1
    w_2_13    normalized_ratio_2_59  -1.8571428571428570e+00
    w_2_13    full_original_Gini_326  -2.6064285714285717e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_14    OBJ       0.0315
    x_2_14    product_lb_53  -2.4265534275042893e-02
    x_2_14    product_ub_54  -4.1530703055514692e-02
    x_2_14    onehot_2_57  1
    x_2_14    stock_lb_266  14
    x_2_14    stock_ub_267  14
    x_2_14    parent_nonstrict_scope_268  0.0735
    x_2_14    unique_nonzero_owner_350  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_14    product_lb_53  1
    w_2_14    product_ub_54  1
    w_2_14    normalized_mass_2_58  1
    w_2_14    normalized_ratio_2_59  -2
    w_2_14    full_original_Gini_326  -2.9921428571428571e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_15    OBJ       4.1999999999999996e-02
    x_2_15    product_lb_55  -2.4265534275042893e-02
    x_2_15    product_ub_56  -4.1530703055514692e-02
    x_2_15    onehot_2_57  1
    x_2_15    stock_lb_266  15
    x_2_15    stock_ub_267  15
    x_2_15    parent_nonstrict_scope_268  8.3999999999999991e-02
    x_2_15    unique_nonzero_owner_351  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_15    product_lb_55  1
    w_2_15    product_ub_56  1
    w_2_15    normalized_mass_2_58  1
    w_2_15    normalized_ratio_2_59  -2.1428571428571428e+00
    w_2_15    full_original_Gini_326  -3.3778571428571418e+01
    rho_2     normalized_ratio_2_59  1
    rho_2     block_pair_pos_269  -1
    rho_2     block_pair_neg_270  1
    rho_2     block_pair_pos_271  -1
    rho_2     block_pair_neg_272  1
    rho_2     block_pair_pos_273  -1
    rho_2     block_pair_neg_274  1
    rho_2     block_pair_pos_275  -1
    rho_2     block_pair_neg_276  1
    rho_2     block_pair_pos_277  -1
    rho_2     block_pair_neg_278  1
    rho_2     block_pair_pos_279  -1
    rho_2     block_pair_neg_280  1
    rho_2     block_pair_pos_281  1
    rho_2     block_pair_neg_282  -1
    rho_2     normalization_325  1
    MARKER    'MARKER'                 'INTORG'
    x_31_0    OBJ       0.03675
    x_31_0    product_lb_60  -2.4265534275042893e-02
    x_31_0    product_ub_61  -4.1530703055514692e-02
    x_31_0    onehot_31_86  1
    x_31_0    parent_nonstrict_scope_268  0.0735
    x_31_0    unique_nonzero_owner_352  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_0    product_lb_60  1
    w_31_0    product_ub_61  1
    w_31_0    normalized_mass_31_87  1
    w_31_0    full_original_Gini_326  -2.4078571428571429e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_1    OBJ       2.6250000000000002e-02
    x_31_1    product_lb_62  -2.4265534275042893e-02
    x_31_1    product_ub_63  -4.1530703055514692e-02
    x_31_1    onehot_31_86  1
    x_31_1    stock_lb_266  1
    x_31_1    stock_ub_267  1
    x_31_1    parent_nonstrict_scope_268  0.063
    x_31_1    unique_nonzero_owner_353  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_1    product_lb_62  1
    w_31_1    product_ub_63  1
    w_31_1    normalized_mass_31_87  1
    w_31_1    normalized_ratio_31_88  -1.4285714285714285e-01
    w_31_1    full_original_Gini_326  -2.0221428571428579e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_2    OBJ       0.01575
    x_31_2    product_lb_64  -2.4265534275042893e-02
    x_31_2    product_ub_65  -4.1530703055514692e-02
    x_31_2    onehot_31_86  1
    x_31_2    stock_lb_266  2
    x_31_2    stock_ub_267  2
    x_31_2    parent_nonstrict_scope_268  0.0525
    MARKER    'MARKER'                 'INTEND'
    w_31_2    product_lb_64  1
    w_31_2    product_ub_65  1
    w_31_2    normalized_mass_31_87  1
    w_31_2    normalized_ratio_31_88  -2.8571428571428570e-01
    w_31_2    full_original_Gini_326  -1.6507142857142853e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_3    OBJ       5.2499999999999977e-03
    x_31_3    product_lb_66  -2.4265534275042893e-02
    x_31_3    product_ub_67  -4.1530703055514692e-02
    x_31_3    onehot_31_86  1
    x_31_3    stock_lb_266  3
    x_31_3    stock_ub_267  3
    x_31_3    parent_nonstrict_scope_268  4.1999999999999996e-02
    x_31_3    unique_nonzero_owner_354  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_3    product_lb_66  1
    w_31_3    product_ub_67  1
    w_31_3    normalized_mass_31_87  1
    w_31_3    normalized_ratio_31_88  -4.2857142857142855e-01
    w_31_3    full_original_Gini_326  -1.3278571428571427e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_4    OBJ       -5.2499999999999977e-03
    x_31_4    product_lb_68  -2.4265534275042893e-02
    x_31_4    product_ub_69  -4.1530703055514692e-02
    x_31_4    onehot_31_86  1
    x_31_4    stock_lb_266  4
    x_31_4    stock_ub_267  4
    x_31_4    parent_nonstrict_scope_268  0.0315
    x_31_4    unique_nonzero_owner_355  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_4    product_lb_68  1
    w_31_4    product_ub_69  1
    w_31_4    normalized_mass_31_87  1
    w_31_4    normalized_ratio_31_88  -5.7142857142857140e-01
    w_31_4    full_original_Gini_326  -1.0278571428571432e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_5    OBJ       -1.5749999999999993e-02
    x_31_5    product_lb_70  -2.4265534275042893e-02
    x_31_5    product_ub_71  -4.1530703055514692e-02
    x_31_5    onehot_31_86  1
    x_31_5    stock_lb_266  5
    x_31_5    stock_ub_267  5
    x_31_5    parent_nonstrict_scope_268  2.1000000000000005e-02
    x_31_5    unique_nonzero_owner_356  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_5    product_lb_70  1
    w_31_5    product_ub_71  1
    w_31_5    normalized_mass_31_87  1
    w_31_5    normalized_ratio_31_88  -7.1428571428571419e-01
    w_31_5    full_original_Gini_326  -7.2785714285714285e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_6    OBJ       -2.6249999999999996e-02
    x_31_6    product_lb_72  -2.4265534275042893e-02
    x_31_6    product_ub_73  -4.1530703055514692e-02
    x_31_6    onehot_31_86  1
    x_31_6    stock_lb_266  6
    x_31_6    stock_ub_267  6
    x_31_6    parent_nonstrict_scope_268  1.0500000000000002e-02
    x_31_6    unique_nonzero_owner_357  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_6    product_lb_72  1
    w_31_6    product_ub_73  1
    w_31_6    normalized_mass_31_87  1
    w_31_6    normalized_ratio_31_88  -8.5714285714285710e-01
    w_31_6    full_original_Gini_326  -4.8928571428571432e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_7    OBJ       -0.03675
    x_31_7    product_lb_74  -2.4265534275042893e-02
    x_31_7    product_ub_75  -4.1530703055514692e-02
    x_31_7    onehot_31_86  1
    x_31_7    stock_lb_266  7
    x_31_7    stock_ub_267  7
    x_31_7    unique_nonzero_owner_358  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_7    product_lb_74  1
    w_31_7    product_ub_75  1
    w_31_7    normalized_mass_31_87  1
    w_31_7    normalized_ratio_31_88  -1
    w_31_7    full_original_Gini_326  -3.8214285714285721e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_8    OBJ       -2.6250000000000002e-02
    x_31_8    product_lb_76  -2.4265534275042893e-02
    x_31_8    product_ub_77  -4.1530703055514692e-02
    x_31_8    onehot_31_86  1
    x_31_8    stock_lb_266  8
    x_31_8    stock_ub_267  8
    x_31_8    parent_nonstrict_scope_268  1.0499999999999995e-02
    x_31_8    unique_nonzero_owner_359  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_8    product_lb_76  1
    w_31_8    product_ub_77  1
    w_31_8    normalized_mass_31_87  1
    w_31_8    normalized_ratio_31_88  -1.1428571428571428e+00
    w_31_8    full_original_Gini_326  -7.1071428571428541e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_9    OBJ       -1.5750000000000007e-02
    x_31_9    product_lb_78  -2.4265534275042893e-02
    x_31_9    product_ub_79  -4.1530703055514692e-02
    x_31_9    onehot_31_86  1
    x_31_9    stock_lb_266  9
    x_31_9    stock_ub_267  9
    x_31_9    parent_nonstrict_scope_268  2.0999999999999991e-02
    x_31_9    unique_nonzero_owner_360  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_9    product_lb_78  1
    w_31_9    product_ub_79  1
    w_31_9    normalized_mass_31_87  1
    w_31_9    normalized_ratio_31_88  -1.2857142857142856e+00
    w_31_9    full_original_Gini_326  -1.0635714285714283e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_10   OBJ       -5.2500000000000116e-03
    x_31_10   product_lb_80  -2.4265534275042893e-02
    x_31_10   product_ub_81  -4.1530703055514692e-02
    x_31_10   onehot_31_86  1
    x_31_10   stock_lb_266  10
    x_31_10   stock_ub_267  10
    x_31_10   parent_nonstrict_scope_268  3.1499999999999986e-02
    x_31_10   unique_nonzero_owner_361  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_10   product_lb_80  1
    w_31_10   product_ub_81  1
    w_31_10   normalized_mass_31_87  1
    w_31_10   normalized_ratio_31_88  -1.4285714285714284e+00
    w_31_10   full_original_Gini_326  -1.4492857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_11   OBJ       5.2499999999999977e-03
    x_31_11   product_lb_82  -2.4265534275042893e-02
    x_31_11   product_ub_83  -4.1530703055514692e-02
    x_31_11   onehot_31_86  1
    x_31_11   stock_lb_266  11
    x_31_11   stock_ub_267  11
    x_31_11   parent_nonstrict_scope_268  4.1999999999999996e-02
    x_31_11   unique_nonzero_owner_362  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_11   product_lb_82  1
    w_31_11   product_ub_83  1
    w_31_11   normalized_mass_31_87  1
    w_31_11   normalized_ratio_31_88  -1.5714285714285714e+00
    w_31_11   full_original_Gini_326  -1.8349999999999998e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_12   OBJ       1.5749999999999993e-02
    x_31_12   product_lb_84  -2.4265534275042893e-02
    x_31_12   product_ub_85  -4.1530703055514692e-02
    x_31_12   onehot_31_86  1
    x_31_12   stock_lb_266  12
    x_31_12   stock_ub_267  12
    x_31_12   parent_nonstrict_scope_268  5.2499999999999991e-02
    x_31_12   unique_nonzero_owner_363  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_12   product_lb_84  1
    w_31_12   product_ub_85  1
    w_31_12   normalized_mass_31_87  1
    w_31_12   normalized_ratio_31_88  -1.7142857142857142e+00
    w_31_12   full_original_Gini_326  -2.2207142857142856e+01
    rho_31    normalized_ratio_31_88  1
    rho_31    block_pair_pos_277  1
    rho_31    block_pair_neg_278  -1
    rho_31    block_pair_pos_291  1
    rho_31    block_pair_neg_292  -1
    rho_31    block_pair_pos_309  -1
    rho_31    block_pair_neg_310  1
    rho_31    block_pair_pos_311  -1
    rho_31    block_pair_neg_312  1
    rho_31    block_pair_pos_313  -1
    rho_31    block_pair_neg_314  1
    rho_31    block_pair_pos_315  -1
    rho_31    block_pair_neg_316  1
    rho_31    block_pair_pos_317  -1
    rho_31    block_pair_neg_318  1
    rho_31    normalization_325  1
    MARKER    'MARKER'                 'INTORG'
    x_9_0     OBJ       1.1249999999999993e-02
    x_9_0     product_lb_89  -2.4265534275042893e-02
    x_9_0     product_ub_90  -4.1530703055514692e-02
    x_9_0     onehot_9_115  1
    x_9_0     parent_nonstrict_scope_268  0.0375
    x_9_0     unique_nonzero_owner_364  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_0     product_lb_89  1
    w_9_0     product_ub_90  1
    w_9_0     normalized_mass_9_116  1
    w_9_0     full_original_Gini_326  -2.4078571428571429e+01
    MARKER    'MARKER'                 'INTORG'
    x_9_1     OBJ       3.7499999999999929e-03
    x_9_1     product_lb_91  -2.4265534275042893e-02
    x_9_1     product_ub_92  -4.1530703055514692e-02
    x_9_1     onehot_9_115  1
    x_9_1     stock_lb_266  1
    x_9_1     stock_ub_267  1
    x_9_1     parent_nonstrict_scope_268  0.03
    x_9_1     unique_nonzero_owner_365  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_1     product_lb_91  1
    w_9_1     product_ub_92  1
    w_9_1     normalized_mass_9_116  1
    w_9_1     normalized_ratio_9_117  -0.2
    w_9_1     full_original_Gini_326  -1.8678571428571438e+01
    MARKER    'MARKER'                 'INTORG'
    x_9_2     OBJ       -3.7500000000000068e-03
    x_9_2     product_lb_93  -2.4265534275042893e-02
    x_9_2     product_ub_94  -4.1530703055514692e-02
    x_9_2     onehot_9_115  1
    x_9_2     stock_lb_266  2
    x_9_2     stock_ub_267  2
    x_9_2     parent_nonstrict_scope_268  0.0225
    x_9_2     unique_nonzero_owner_366  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_2     product_lb_93  1
    w_9_2     product_ub_94  1
    w_9_2     normalized_mass_9_116  1
    w_9_2     normalized_ratio_9_117  -0.4
    w_9_2     full_original_Gini_326  -1.3878571428571426e+01
    MARKER    'MARKER'                 'INTORG'
    x_9_3     OBJ       -1.1250000000000010e-02
    x_9_3     product_lb_95  -2.4265534275042893e-02
    x_9_3     product_ub_96  -4.1530703055514692e-02
    x_9_3     onehot_9_115  1
    x_9_3     stock_lb_266  3
    x_9_3     stock_ub_267  3
    x_9_3     parent_nonstrict_scope_268  1.4999999999999996e-02
    x_9_3     unique_nonzero_owner_367  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_3     product_lb_95  1
    w_9_3     product_ub_96  1
    w_9_3     normalized_mass_9_116  1
    w_9_3     normalized_ratio_9_117  -6.0000000000000009e-01
    w_9_3     full_original_Gini_326  -9.6785714285714288e+00
    MARKER    'MARKER'                 'INTORG'
    x_9_4     OBJ       -1.8750000000000010e-02
    x_9_4     product_lb_97  -2.4265534275042893e-02
    x_9_4     product_ub_98  -4.1530703055514692e-02
    x_9_4     onehot_9_115  1
    x_9_4     stock_lb_266  4
    x_9_4     stock_ub_267  4
    x_9_4     parent_nonstrict_scope_268  7.4999999999999980e-03
    x_9_4     unique_nonzero_owner_368  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_4     product_lb_97  1
    w_9_4     product_ub_98  1
    w_9_4     normalized_mass_9_116  1
    w_9_4     normalized_ratio_9_117  -0.8
    w_9_4     full_original_Gini_326  -5.7500000000000018e+00
    MARKER    'MARKER'                 'INTORG'
    x_9_5     OBJ       -2.6250000000000006e-02
    x_9_5     product_lb_99  -2.4265534275042893e-02
    x_9_5     product_ub_100  -4.1530703055514692e-02
    x_9_5     onehot_9_115  1
    x_9_5     stock_lb_266  5
    x_9_5     stock_ub_267  5
    x_9_5     unique_nonzero_owner_369  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_5     product_lb_99  1
    w_9_5     product_ub_100  1
    w_9_5     normalized_mass_9_116  1
    w_9_5     normalized_ratio_9_117  -1
    w_9_5     full_original_Gini_326  -3.8214285714285721e+00
    MARKER    'MARKER'                 'INTORG'
    x_9_6     OBJ       -0.01875
    x_9_6     product_lb_101  -2.4265534275042893e-02
    x_9_6     product_ub_102  -4.1530703055514692e-02
    x_9_6     onehot_9_115  1
    x_9_6     stock_lb_266  6
    x_9_6     stock_ub_267  6
    x_9_6     parent_nonstrict_scope_268  7.5000000000000067e-03
    x_9_6     unique_nonzero_owner_370  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_6     product_lb_101  1
    w_9_6     product_ub_102  1
    w_9_6     normalized_mass_9_116  1
    w_9_6     normalized_ratio_9_117  -1.2000000000000002e+00
    w_9_6     full_original_Gini_326  -8.4214285714285744e+00
    MARKER    'MARKER'                 'INTORG'
    x_9_7     OBJ       -1.1250000000000001e-02
    x_9_7     product_lb_103  -2.4265534275042893e-02
    x_9_7     product_ub_104  -4.1530703055514692e-02
    x_9_7     onehot_9_115  1
    x_9_7     stock_lb_266  7
    x_9_7     stock_ub_267  7
    x_9_7     parent_nonstrict_scope_268  1.5000000000000005e-02
    x_9_7     unique_nonzero_owner_371  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_7     product_lb_103  1
    w_9_7     product_ub_104  1
    w_9_7     normalized_mass_9_116  1
    w_9_7     normalized_ratio_9_117  -1.4000000000000001e+00
    w_9_7     full_original_Gini_326  -1.3721428571428577e+01
    MARKER    'MARKER'                 'INTORG'
    x_9_8     OBJ       -3.7500000000000033e-03
    x_9_8     product_lb_105  -2.4265534275042893e-02
    x_9_8     product_ub_106  -4.1530703055514692e-02
    x_9_8     onehot_9_115  1
    x_9_8     stock_lb_266  8
    x_9_8     stock_ub_267  8
    x_9_8     parent_nonstrict_scope_268  2.2500000000000003e-02
    MARKER    'MARKER'                 'INTEND'
    w_9_8     product_lb_105  1
    w_9_8     product_ub_106  1
    w_9_8     normalized_mass_9_116  1
    w_9_8     normalized_ratio_9_117  -1.6
    w_9_8     full_original_Gini_326  -1.9121428571428574e+01
    MARKER    'MARKER'                 'INTORG'
    x_9_9     OBJ       3.7499999999999929e-03
    x_9_9     product_lb_107  -2.4265534275042893e-02
    x_9_9     product_ub_108  -4.1530703055514692e-02
    x_9_9     onehot_9_115  1
    x_9_9     stock_lb_266  9
    x_9_9     stock_ub_267  9
    x_9_9     parent_nonstrict_scope_268  0.03
    x_9_9     unique_nonzero_owner_372  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_9     product_lb_107  1
    w_9_9     product_ub_108  1
    w_9_9     normalized_mass_9_116  1
    w_9_9     normalized_ratio_9_117  -1.8
    w_9_9     full_original_Gini_326  -2.4521428571428579e+01
    MARKER    'MARKER'                 'INTORG'
    x_9_10    OBJ       1.1249999999999993e-02
    x_9_10    product_lb_109  -2.4265534275042893e-02
    x_9_10    product_ub_110  -4.1530703055514692e-02
    x_9_10    onehot_9_115  1
    x_9_10    stock_lb_266  10
    x_9_10    stock_ub_267  10
    x_9_10    parent_nonstrict_scope_268  0.0375
    x_9_10    unique_nonzero_owner_373  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_10    product_lb_109  1
    w_9_10    product_ub_110  1
    w_9_10    normalized_mass_9_116  1
    w_9_10    normalized_ratio_9_117  -2
    w_9_10    full_original_Gini_326  -2.9921428571428571e+01
    MARKER    'MARKER'                 'INTORG'
    x_9_11    OBJ       0.01875
    x_9_11    product_lb_111  -2.4265534275042893e-02
    x_9_11    product_ub_112  -4.1530703055514692e-02
    x_9_11    onehot_9_115  1
    x_9_11    stock_lb_266  11
    x_9_11    stock_ub_267  11
    x_9_11    parent_nonstrict_scope_268  4.5000000000000005e-02
    x_9_11    unique_nonzero_owner_374  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_11    product_lb_111  1
    w_9_11    product_ub_112  1
    w_9_11    normalized_mass_9_116  1
    w_9_11    normalized_ratio_9_117  -2.2
    w_9_11    full_original_Gini_326  -3.5321428571428569e+01
    MARKER    'MARKER'                 'INTORG'
    x_9_12    OBJ       2.6250000000000006e-02
    x_9_12    product_lb_113  -2.4265534275042893e-02
    x_9_12    product_ub_114  -4.1530703055514692e-02
    x_9_12    onehot_9_115  1
    x_9_12    stock_lb_266  12
    x_9_12    stock_ub_267  12
    x_9_12    parent_nonstrict_scope_268  5.2500000000000012e-02
    x_9_12    unique_nonzero_owner_375  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_12    product_lb_113  1
    w_9_12    product_ub_114  1
    w_9_12    normalized_mass_9_116  1
    w_9_12    normalized_ratio_9_117  -2.4000000000000004e+00
    w_9_12    full_original_Gini_326  -4.0721428571428568e+01
    rho_9     normalized_ratio_9_117  1
    rho_9     block_pair_pos_271  1
    rho_9     block_pair_neg_272  -1
    rho_9     block_pair_pos_285  1
    rho_9     block_pair_neg_286  -1
    rho_9     block_pair_pos_299  -1
    rho_9     block_pair_neg_300  1
    rho_9     block_pair_pos_301  -1
    rho_9     block_pair_neg_302  1
    rho_9     block_pair_pos_303  -1
    rho_9     block_pair_neg_304  1
    rho_9     block_pair_pos_305  -1
    rho_9     block_pair_neg_306  1
    rho_9     block_pair_pos_311  1
    rho_9     block_pair_neg_312  -1
    rho_9     normalization_325  1
    MARKER    'MARKER'                 'INTORG'
    x_32_0    OBJ       1.1249999999999993e-02
    x_32_0    product_lb_118  -2.4265534275042893e-02
    x_32_0    product_ub_119  -4.1530703055514692e-02
    x_32_0    onehot_32_144  1
    x_32_0    parent_nonstrict_scope_268  0.0375
    MARKER    'MARKER'                 'INTEND'
    w_32_0    product_lb_118  1
    w_32_0    product_ub_119  1
    w_32_0    normalized_mass_32_145  1
    w_32_0    full_original_Gini_326  -2.4078571428571429e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_1    OBJ       3.7499999999999929e-03
    x_32_1    product_lb_120  -2.4265534275042893e-02
    x_32_1    product_ub_121  -4.1530703055514692e-02
    x_32_1    onehot_32_144  1
    x_32_1    stock_lb_266  1
    x_32_1    stock_ub_267  1
    x_32_1    parent_nonstrict_scope_268  0.03
    x_32_1    unique_nonzero_owner_376  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_1    product_lb_120  1
    w_32_1    product_ub_121  1
    w_32_1    normalized_mass_32_145  1
    w_32_1    normalized_ratio_32_146  -0.2
    w_32_1    full_original_Gini_326  -1.8678571428571438e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_2    OBJ       -3.7500000000000068e-03
    x_32_2    product_lb_122  -2.4265534275042893e-02
    x_32_2    product_ub_123  -4.1530703055514692e-02
    x_32_2    onehot_32_144  1
    x_32_2    stock_lb_266  2
    x_32_2    stock_ub_267  2
    x_32_2    parent_nonstrict_scope_268  0.0225
    x_32_2    unique_nonzero_owner_377  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_2    product_lb_122  1
    w_32_2    product_ub_123  1
    w_32_2    normalized_mass_32_145  1
    w_32_2    normalized_ratio_32_146  -0.4
    w_32_2    full_original_Gini_326  -1.3878571428571426e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_3    OBJ       -1.1250000000000010e-02
    x_32_3    product_lb_124  -2.4265534275042893e-02
    x_32_3    product_ub_125  -4.1530703055514692e-02
    x_32_3    onehot_32_144  1
    x_32_3    stock_lb_266  3
    x_32_3    stock_ub_267  3
    x_32_3    parent_nonstrict_scope_268  1.4999999999999996e-02
    x_32_3    unique_nonzero_owner_378  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_3    product_lb_124  1
    w_32_3    product_ub_125  1
    w_32_3    normalized_mass_32_145  1
    w_32_3    normalized_ratio_32_146  -6.0000000000000009e-01
    w_32_3    full_original_Gini_326  -9.6785714285714288e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_4    OBJ       -1.8750000000000010e-02
    x_32_4    product_lb_126  -2.4265534275042893e-02
    x_32_4    product_ub_127  -4.1530703055514692e-02
    x_32_4    onehot_32_144  1
    x_32_4    stock_lb_266  4
    x_32_4    stock_ub_267  4
    x_32_4    parent_nonstrict_scope_268  7.4999999999999980e-03
    x_32_4    unique_nonzero_owner_379  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_4    product_lb_126  1
    w_32_4    product_ub_127  1
    w_32_4    normalized_mass_32_145  1
    w_32_4    normalized_ratio_32_146  -0.8
    w_32_4    full_original_Gini_326  -5.7500000000000018e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_5    OBJ       -2.6250000000000006e-02
    x_32_5    product_lb_128  -2.4265534275042893e-02
    x_32_5    product_ub_129  -4.1530703055514692e-02
    x_32_5    onehot_32_144  1
    x_32_5    stock_lb_266  5
    x_32_5    stock_ub_267  5
    x_32_5    unique_nonzero_owner_380  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_5    product_lb_128  1
    w_32_5    product_ub_129  1
    w_32_5    normalized_mass_32_145  1
    w_32_5    normalized_ratio_32_146  -1
    w_32_5    full_original_Gini_326  -3.8214285714285721e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_6    OBJ       -0.01875
    x_32_6    product_lb_130  -2.4265534275042893e-02
    x_32_6    product_ub_131  -4.1530703055514692e-02
    x_32_6    onehot_32_144  1
    x_32_6    stock_lb_266  6
    x_32_6    stock_ub_267  6
    x_32_6    parent_nonstrict_scope_268  7.5000000000000067e-03
    x_32_6    unique_nonzero_owner_381  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_6    product_lb_130  1
    w_32_6    product_ub_131  1
    w_32_6    normalized_mass_32_145  1
    w_32_6    normalized_ratio_32_146  -1.2000000000000002e+00
    w_32_6    full_original_Gini_326  -8.4214285714285744e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_7    OBJ       -1.1250000000000001e-02
    x_32_7    product_lb_132  -2.4265534275042893e-02
    x_32_7    product_ub_133  -4.1530703055514692e-02
    x_32_7    onehot_32_144  1
    x_32_7    stock_lb_266  7
    x_32_7    stock_ub_267  7
    x_32_7    parent_nonstrict_scope_268  1.5000000000000005e-02
    x_32_7    unique_nonzero_owner_382  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_7    product_lb_132  1
    w_32_7    product_ub_133  1
    w_32_7    normalized_mass_32_145  1
    w_32_7    normalized_ratio_32_146  -1.4000000000000001e+00
    w_32_7    full_original_Gini_326  -1.3721428571428577e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_8    OBJ       -3.7500000000000033e-03
    x_32_8    product_lb_134  -2.4265534275042893e-02
    x_32_8    product_ub_135  -4.1530703055514692e-02
    x_32_8    onehot_32_144  1
    x_32_8    stock_lb_266  8
    x_32_8    stock_ub_267  8
    x_32_8    parent_nonstrict_scope_268  2.2500000000000003e-02
    x_32_8    unique_nonzero_owner_383  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_8    product_lb_134  1
    w_32_8    product_ub_135  1
    w_32_8    normalized_mass_32_145  1
    w_32_8    normalized_ratio_32_146  -1.6
    w_32_8    full_original_Gini_326  -1.9121428571428574e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_9    OBJ       3.7499999999999929e-03
    x_32_9    product_lb_136  -2.4265534275042893e-02
    x_32_9    product_ub_137  -4.1530703055514692e-02
    x_32_9    onehot_32_144  1
    x_32_9    stock_lb_266  9
    x_32_9    stock_ub_267  9
    x_32_9    parent_nonstrict_scope_268  0.03
    x_32_9    unique_nonzero_owner_384  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_9    product_lb_136  1
    w_32_9    product_ub_137  1
    w_32_9    normalized_mass_32_145  1
    w_32_9    normalized_ratio_32_146  -1.8
    w_32_9    full_original_Gini_326  -2.4521428571428579e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_10   OBJ       1.1249999999999993e-02
    x_32_10   product_lb_138  -2.4265534275042893e-02
    x_32_10   product_ub_139  -4.1530703055514692e-02
    x_32_10   onehot_32_144  1
    x_32_10   stock_lb_266  10
    x_32_10   stock_ub_267  10
    x_32_10   parent_nonstrict_scope_268  0.0375
    x_32_10   unique_nonzero_owner_385  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_10   product_lb_138  1
    w_32_10   product_ub_139  1
    w_32_10   normalized_mass_32_145  1
    w_32_10   normalized_ratio_32_146  -2
    w_32_10   full_original_Gini_326  -2.9921428571428571e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_11   OBJ       0.01875
    x_32_11   product_lb_140  -2.4265534275042893e-02
    x_32_11   product_ub_141  -4.1530703055514692e-02
    x_32_11   onehot_32_144  1
    x_32_11   stock_lb_266  11
    x_32_11   stock_ub_267  11
    x_32_11   parent_nonstrict_scope_268  4.5000000000000005e-02
    x_32_11   unique_nonzero_owner_386  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_11   product_lb_140  1
    w_32_11   product_ub_141  1
    w_32_11   normalized_mass_32_145  1
    w_32_11   normalized_ratio_32_146  -2.2
    w_32_11   full_original_Gini_326  -3.5321428571428569e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_12   OBJ       2.6250000000000006e-02
    x_32_12   product_lb_142  -2.4265534275042893e-02
    x_32_12   product_ub_143  -4.1530703055514692e-02
    x_32_12   onehot_32_144  1
    x_32_12   stock_lb_266  12
    x_32_12   stock_ub_267  12
    x_32_12   parent_nonstrict_scope_268  5.2500000000000012e-02
    x_32_12   unique_nonzero_owner_387  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_12   product_lb_142  1
    w_32_12   product_ub_143  1
    w_32_12   normalized_mass_32_145  1
    w_32_12   normalized_ratio_32_146  -2.4000000000000004e+00
    w_32_12   full_original_Gini_326  -4.0721428571428568e+01
    rho_32    normalized_ratio_32_146  1
    rho_32    block_pair_pos_279  1
    rho_32    block_pair_neg_280  -1
    rho_32    block_pair_pos_293  1
    rho_32    block_pair_neg_294  -1
    rho_32    block_pair_pos_305  1
    rho_32    block_pair_neg_306  -1
    rho_32    block_pair_pos_317  1
    rho_32    block_pair_neg_318  -1
    rho_32    block_pair_pos_319  -1
    rho_32    block_pair_neg_320  1
    rho_32    block_pair_pos_321  -1
    rho_32    block_pair_neg_322  1
    rho_32    block_pair_pos_323  -1
    rho_32    block_pair_neg_324  1
    rho_32    normalization_325  1
    MARKER    'MARKER'                 'INTORG'
    x_8_0     OBJ       6.7499999999999991e-02
    x_8_0     product_lb_147  -2.4265534275042893e-02
    x_8_0     product_ub_148  -4.1530703055514692e-02
    x_8_0     onehot_8_191  1
    x_8_0     parent_nonstrict_scope_268  0.15
    x_8_0     unique_nonzero_owner_388  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_0     product_lb_147  1
    w_8_0     product_ub_148  1
    w_8_0     normalized_mass_8_192  1
    w_8_0     full_original_Gini_326  -2.4078571428571429e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_1     OBJ       5.2500000000000005e-02
    x_8_1     product_lb_149  -2.4265534275042893e-02
    x_8_1     product_ub_150  -4.1530703055514692e-02
    x_8_1     onehot_8_191  1
    x_8_1     stock_lb_266  1
    x_8_1     stock_ub_267  1
    x_8_1     parent_nonstrict_scope_268  0.135
    x_8_1     unique_nonzero_owner_389  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_1     product_lb_149  1
    w_8_1     product_ub_150  1
    w_8_1     normalized_mass_8_192  1
    w_8_1     normalized_ratio_8_193  -0.1
    w_8_1     full_original_Gini_326  -2.1378571428571426e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_2     OBJ       3.7499999999999992e-02
    x_8_2     product_lb_151  -2.4265534275042893e-02
    x_8_2     product_ub_152  -4.1530703055514692e-02
    x_8_2     onehot_8_191  1
    x_8_2     stock_lb_266  2
    x_8_2     stock_ub_267  2
    x_8_2     parent_nonstrict_scope_268  0.12
    x_8_2     unique_nonzero_owner_390  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_2     product_lb_151  1
    w_8_2     product_ub_152  1
    w_8_2     normalized_mass_8_192  1
    w_8_2     normalized_ratio_8_193  -0.2
    w_8_2     full_original_Gini_326  -1.8678571428571438e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_3     OBJ       2.2499999999999992e-02
    x_8_3     product_lb_153  -2.4265534275042893e-02
    x_8_3     product_ub_154  -4.1530703055514692e-02
    x_8_3     onehot_8_191  1
    x_8_3     stock_lb_266  3
    x_8_3     stock_ub_267  3
    x_8_3     parent_nonstrict_scope_268  0.105
    x_8_3     unique_nonzero_owner_391  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_3     product_lb_153  1
    w_8_3     product_ub_154  1
    w_8_3     normalized_mass_8_192  1
    w_8_3     normalized_ratio_8_193  -3.0000000000000004e-01
    w_8_3     full_original_Gini_326  -1.6178571428571423e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_4     OBJ       7.4999999999999928e-03
    x_8_4     product_lb_155  -2.4265534275042893e-02
    x_8_4     product_ub_156  -4.1530703055514692e-02
    x_8_4     onehot_8_191  1
    x_8_4     stock_lb_266  4
    x_8_4     stock_ub_267  4
    x_8_4     parent_nonstrict_scope_268  0.09
    x_8_4     unique_nonzero_owner_392  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_4     product_lb_155  1
    w_8_4     product_ub_156  1
    w_8_4     normalized_mass_8_192  1
    w_8_4     normalized_ratio_8_193  -0.4
    w_8_4     full_original_Gini_326  -1.3878571428571426e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_5     OBJ       -7.5000000000000067e-03
    x_8_5     product_lb_157  -2.4265534275042893e-02
    x_8_5     product_ub_158  -4.1530703055514692e-02
    x_8_5     onehot_8_191  1
    x_8_5     stock_lb_266  5
    x_8_5     stock_ub_267  5
    x_8_5     parent_nonstrict_scope_268  0.075
    x_8_5     unique_nonzero_owner_393  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_5     product_lb_157  1
    w_8_5     product_ub_158  1
    w_8_5     normalized_mass_8_192  1
    w_8_5     normalized_ratio_8_193  -0.5
    w_8_5     full_original_Gini_326  -1.1778571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_6     OBJ       -2.2500000000000020e-02
    x_8_6     product_lb_159  -2.4265534275042893e-02
    x_8_6     product_ub_160  -4.1530703055514692e-02
    x_8_6     onehot_8_191  1
    x_8_6     stock_lb_266  6
    x_8_6     stock_ub_267  6
    x_8_6     parent_nonstrict_scope_268  5.9999999999999984e-02
    x_8_6     unique_nonzero_owner_394  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_6     product_lb_159  1
    w_8_6     product_ub_160  1
    w_8_6     normalized_mass_8_192  1
    w_8_6     normalized_ratio_8_193  -6.0000000000000009e-01
    w_8_6     full_original_Gini_326  -9.6785714285714288e+00
    MARKER    'MARKER'                 'INTORG'
    x_8_7     OBJ       -3.7500000000000012e-02
    x_8_7     product_lb_161  -2.4265534275042893e-02
    x_8_7     product_ub_162  -4.1530703055514692e-02
    x_8_7     onehot_8_191  1
    x_8_7     stock_lb_266  7
    x_8_7     stock_ub_267  7
    x_8_7     parent_nonstrict_scope_268  4.4999999999999991e-02
    x_8_7     unique_nonzero_owner_395  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_7     product_lb_161  1
    w_8_7     product_ub_162  1
    w_8_7     normalized_mass_8_192  1
    w_8_7     normalized_ratio_8_193  -7.0000000000000007e-01
    w_8_7     full_original_Gini_326  -7.5785714285714256e+00
    MARKER    'MARKER'                 'INTORG'
    x_8_8     OBJ       -5.2500000000000012e-02
    x_8_8     product_lb_163  -2.4265534275042893e-02
    x_8_8     product_ub_164  -4.1530703055514692e-02
    x_8_8     onehot_8_191  1
    x_8_8     stock_lb_266  8
    x_8_8     stock_ub_267  8
    x_8_8     parent_nonstrict_scope_268  2.9999999999999992e-02
    x_8_8     unique_nonzero_owner_396  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_8     product_lb_163  1
    w_8_8     product_ub_164  1
    w_8_8     normalized_mass_8_192  1
    w_8_8     normalized_ratio_8_193  -0.8
    w_8_8     full_original_Gini_326  -5.7500000000000018e+00
    MARKER    'MARKER'                 'INTORG'
    x_8_9     OBJ       -0.0675
    x_8_9     product_lb_165  -2.4265534275042893e-02
    x_8_9     product_ub_166  -4.1530703055514692e-02
    x_8_9     onehot_8_191  1
    x_8_9     stock_lb_266  9
    x_8_9     stock_ub_267  9
    x_8_9     parent_nonstrict_scope_268  1.4999999999999996e-02
    x_8_9     unique_nonzero_owner_397  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_9     product_lb_165  1
    w_8_9     product_ub_166  1
    w_8_9     normalized_mass_8_192  1
    w_8_9     normalized_ratio_8_193  -0.9
    w_8_9     full_original_Gini_326  -4.5214285714285722e+00
    MARKER    'MARKER'                 'INTORG'
    x_8_10    OBJ       -0.0825
    x_8_10    product_lb_167  -2.4265534275042893e-02
    x_8_10    product_ub_168  -4.1530703055514692e-02
    x_8_10    onehot_8_191  1
    x_8_10    stock_lb_266  10
    x_8_10    stock_ub_267  10
    x_8_10    unique_nonzero_owner_398  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_10    product_lb_167  1
    w_8_10    product_ub_168  1
    w_8_10    normalized_mass_8_192  1
    w_8_10    normalized_ratio_8_193  -1
    w_8_10    full_original_Gini_326  -3.8214285714285721e+00
    MARKER    'MARKER'                 'INTORG'
    x_8_11    OBJ       -6.7499999999999991e-02
    x_8_11    product_lb_169  -2.4265534275042893e-02
    x_8_11    product_ub_170  -4.1530703055514692e-02
    x_8_11    onehot_8_191  1
    x_8_11    stock_lb_266  11
    x_8_11    stock_ub_267  11
    x_8_11    parent_nonstrict_scope_268  1.5000000000000013e-02
    x_8_11    unique_nonzero_owner_399  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_11    product_lb_169  1
    w_8_11    product_ub_170  1
    w_8_11    normalized_mass_8_192  1
    w_8_11    normalized_ratio_8_193  -1.1
    w_8_11    full_original_Gini_326  -6.1214285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_8_12    OBJ       -5.2499999999999977e-02
    x_8_12    product_lb_171  -2.4265534275042893e-02
    x_8_12    product_ub_172  -4.1530703055514692e-02
    x_8_12    onehot_8_191  1
    x_8_12    stock_lb_266  12
    x_8_12    stock_ub_267  12
    x_8_12    parent_nonstrict_scope_268  3.0000000000000027e-02
    x_8_12    unique_nonzero_owner_400  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_12    product_lb_171  1
    w_8_12    product_ub_172  1
    w_8_12    normalized_mass_8_192  1
    w_8_12    normalized_ratio_8_193  -1.2000000000000002e+00
    w_8_12    full_original_Gini_326  -8.4214285714285744e+00
    MARKER    'MARKER'                 'INTORG'
    x_8_13    OBJ       -0.0375
    x_8_13    product_lb_173  -2.4265534275042893e-02
    x_8_13    product_ub_174  -4.1530703055514692e-02
    x_8_13    onehot_8_191  1
    x_8_13    stock_lb_266  13
    x_8_13    stock_ub_267  13
    x_8_13    parent_nonstrict_scope_268  4.5000000000000005e-02
    x_8_13    unique_nonzero_owner_401  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_13    product_lb_173  1
    w_8_13    product_ub_174  1
    w_8_13    normalized_mass_8_192  1
    w_8_13    normalized_ratio_8_193  -1.3
    w_8_13    full_original_Gini_326  -1.1021428571428576e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_14    OBJ       -2.2499999999999985e-02
    x_8_14    product_lb_175  -2.4265534275042893e-02
    x_8_14    product_ub_176  -4.1530703055514692e-02
    x_8_14    onehot_8_191  1
    x_8_14    stock_lb_266  14
    x_8_14    stock_ub_267  14
    x_8_14    parent_nonstrict_scope_268  6.0000000000000019e-02
    x_8_14    unique_nonzero_owner_402  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_14    product_lb_175  1
    w_8_14    product_ub_176  1
    w_8_14    normalized_mass_8_192  1
    w_8_14    normalized_ratio_8_193  -1.4000000000000001e+00
    w_8_14    full_original_Gini_326  -1.3721428571428577e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_15    OBJ       -7.5000000000000067e-03
    x_8_15    product_lb_177  -2.4265534275042893e-02
    x_8_15    product_ub_178  -4.1530703055514692e-02
    x_8_15    onehot_8_191  1
    x_8_15    stock_lb_266  15
    x_8_15    stock_ub_267  15
    x_8_15    parent_nonstrict_scope_268  0.075
    MARKER    'MARKER'                 'INTEND'
    w_8_15    product_lb_177  1
    w_8_15    product_ub_178  1
    w_8_15    normalized_mass_8_192  1
    w_8_15    normalized_ratio_8_193  -1.5
    w_8_15    full_original_Gini_326  -1.6421428571428571e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_16    OBJ       7.5000000000000067e-03
    x_8_16    product_lb_179  -2.4265534275042893e-02
    x_8_16    product_ub_180  -4.1530703055514692e-02
    x_8_16    onehot_8_191  1
    x_8_16    stock_lb_266  16
    x_8_16    stock_ub_267  16
    x_8_16    parent_nonstrict_scope_268  9.0000000000000011e-02
    x_8_16    unique_nonzero_owner_403  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_16    product_lb_179  1
    w_8_16    product_ub_180  1
    w_8_16    normalized_mass_8_192  1
    w_8_16    normalized_ratio_8_193  -1.6
    w_8_16    full_original_Gini_326  -1.9121428571428574e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_17    OBJ       2.2500000000000020e-02
    x_8_17    product_lb_181  -2.4265534275042893e-02
    x_8_17    product_ub_182  -4.1530703055514692e-02
    x_8_17    onehot_8_191  1
    x_8_17    stock_lb_266  17
    x_8_17    stock_ub_267  17
    x_8_17    parent_nonstrict_scope_268  1.0500000000000002e-01
    x_8_17    unique_nonzero_owner_404  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_17    product_lb_181  1
    w_8_17    product_ub_182  1
    w_8_17    normalized_mass_8_192  1
    w_8_17    normalized_ratio_8_193  -1.7000000000000002e+00
    w_8_17    full_original_Gini_326  -2.1821428571428566e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_18    OBJ       3.7499999999999992e-02
    x_8_18    product_lb_183  -2.4265534275042893e-02
    x_8_18    product_ub_184  -4.1530703055514692e-02
    x_8_18    onehot_8_191  1
    x_8_18    stock_lb_266  18
    x_8_18    stock_ub_267  18
    x_8_18    parent_nonstrict_scope_268  0.12
    x_8_18    unique_nonzero_owner_405  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_18    product_lb_183  1
    w_8_18    product_ub_184  1
    w_8_18    normalized_mass_8_192  1
    w_8_18    normalized_ratio_8_193  -1.8
    w_8_18    full_original_Gini_326  -2.4521428571428579e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_19    OBJ       5.2500000000000005e-02
    x_8_19    product_lb_185  -2.4265534275042893e-02
    x_8_19    product_ub_186  -4.1530703055514692e-02
    x_8_19    onehot_8_191  1
    x_8_19    stock_lb_266  19
    x_8_19    stock_ub_267  19
    x_8_19    parent_nonstrict_scope_268  0.135
    x_8_19    unique_nonzero_owner_406  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_19    product_lb_185  1
    w_8_19    product_ub_186  1
    w_8_19    normalized_mass_8_192  1
    w_8_19    normalized_ratio_8_193  -1.9000000000000001e+00
    w_8_19    full_original_Gini_326  -2.7221428571428568e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_20    OBJ       6.7499999999999991e-02
    x_8_20    product_lb_187  -2.4265534275042893e-02
    x_8_20    product_ub_188  -4.1530703055514692e-02
    x_8_20    onehot_8_191  1
    x_8_20    stock_lb_266  20
    x_8_20    stock_ub_267  20
    x_8_20    parent_nonstrict_scope_268  0.15
    x_8_20    unique_nonzero_owner_407  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_20    product_lb_187  1
    w_8_20    product_ub_188  1
    w_8_20    normalized_mass_8_192  1
    w_8_20    normalized_ratio_8_193  -2
    w_8_20    full_original_Gini_326  -2.9921428571428571e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_21    OBJ       0.0825
    x_8_21    product_lb_189  -2.4265534275042893e-02
    x_8_21    product_ub_190  -4.1530703055514692e-02
    x_8_21    onehot_8_191  1
    x_8_21    stock_lb_266  21
    x_8_21    stock_ub_267  21
    x_8_21    parent_nonstrict_scope_268  0.165
    x_8_21    unique_nonzero_owner_408  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_21    product_lb_189  1
    w_8_21    product_ub_190  1
    w_8_21    normalized_mass_8_192  1
    w_8_21    normalized_ratio_8_193  -2.1
    w_8_21    full_original_Gini_326  -3.2621428571428581e+01
    rho_8     normalized_ratio_8_193  1
    rho_8     block_pair_pos_269  1
    rho_8     block_pair_neg_270  -1
    rho_8     block_pair_pos_283  1
    rho_8     block_pair_neg_284  -1
    rho_8     block_pair_pos_295  -1
    rho_8     block_pair_neg_296  1
    rho_8     block_pair_pos_297  -1
    rho_8     block_pair_neg_298  1
    rho_8     block_pair_pos_299  1
    rho_8     block_pair_neg_300  -1
    rho_8     block_pair_pos_309  1
    rho_8     block_pair_neg_310  -1
    rho_8     block_pair_pos_319  1
    rho_8     block_pair_neg_320  -1
    rho_8     normalization_325  1
    MARKER    'MARKER'                 'INTORG'
    x_16_0    OBJ       0.027
    x_16_0    product_lb_194  -2.4265534275042893e-02
    x_16_0    product_ub_195  -4.1530703055514692e-02
    x_16_0    onehot_16_220  1
    x_16_0    parent_nonstrict_scope_268  0.054
    x_16_0    unique_nonzero_owner_409  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_0    product_lb_194  1
    w_16_0    product_ub_195  1
    w_16_0    normalized_mass_16_221  1
    w_16_0    full_original_Gini_326  -2.4078571428571429e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_1    OBJ       0.018
    x_16_1    product_lb_196  -2.4265534275042893e-02
    x_16_1    product_ub_197  -4.1530703055514692e-02
    x_16_1    onehot_16_220  1
    x_16_1    stock_lb_266  1
    x_16_1    stock_ub_267  1
    x_16_1    parent_nonstrict_scope_268  0.045
    MARKER    'MARKER'                 'INTEND'
    w_16_1    product_lb_196  1
    w_16_1    product_ub_197  1
    w_16_1    normalized_mass_16_221  1
    w_16_1    normalized_ratio_16_222  -1.6666666666666666e-01
    w_16_1    full_original_Gini_326  -1.9578571428571433e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_2    OBJ       9.0000000000000045e-03
    x_16_2    product_lb_198  -2.4265534275042893e-02
    x_16_2    product_ub_199  -4.1530703055514692e-02
    x_16_2    onehot_16_220  1
    x_16_2    stock_lb_266  2
    x_16_2    stock_ub_267  2
    x_16_2    parent_nonstrict_scope_268  3.6000000000000004e-02
    x_16_2    unique_nonzero_owner_410  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_2    product_lb_198  1
    w_16_2    product_ub_199  1
    w_16_2    normalized_mass_16_221  1
    w_16_2    normalized_ratio_16_222  -3.3333333333333331e-01
    w_16_2    full_original_Gini_326  -1.5411904761904760e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_3    product_lb_200  -2.4265534275042893e-02
    x_16_3    product_ub_201  -4.1530703055514692e-02
    x_16_3    onehot_16_220  1
    x_16_3    stock_lb_266  3
    x_16_3    stock_ub_267  3
    x_16_3    parent_nonstrict_scope_268  0.027
    x_16_3    unique_nonzero_owner_411  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_3    product_lb_200  1
    w_16_3    product_ub_201  1
    w_16_3    normalized_mass_16_221  1
    w_16_3    normalized_ratio_16_222  -0.5
    w_16_3    full_original_Gini_326  -1.1778571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_4    OBJ       -8.9999999999999976e-03
    x_16_4    product_lb_202  -2.4265534275042893e-02
    x_16_4    product_ub_203  -4.1530703055514692e-02
    x_16_4    onehot_16_220  1
    x_16_4    stock_lb_266  4
    x_16_4    stock_ub_267  4
    x_16_4    parent_nonstrict_scope_268  1.8000000000000002e-02
    x_16_4    unique_nonzero_owner_412  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_4    product_lb_202  1
    w_16_4    product_ub_203  1
    w_16_4    normalized_mass_16_221  1
    w_16_4    normalized_ratio_16_222  -6.6666666666666663e-01
    w_16_4    full_original_Gini_326  -8.2785714285714285e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_5    OBJ       -1.7999999999999995e-02
    x_16_5    product_lb_204  -2.4265534275042893e-02
    x_16_5    product_ub_205  -4.1530703055514692e-02
    x_16_5    onehot_16_220  1
    x_16_5    stock_lb_266  5
    x_16_5    stock_ub_267  5
    x_16_5    parent_nonstrict_scope_268  9.0000000000000045e-03
    x_16_5    unique_nonzero_owner_413  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_5    product_lb_204  1
    w_16_5    product_ub_205  1
    w_16_5    normalized_mass_16_221  1
    w_16_5    normalized_ratio_16_222  -8.3333333333333326e-01
    w_16_5    full_original_Gini_326  -5.2500000000000036e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_6    OBJ       -0.027
    x_16_6    product_lb_206  -2.4265534275042893e-02
    x_16_6    product_ub_207  -4.1530703055514692e-02
    x_16_6    onehot_16_220  1
    x_16_6    stock_lb_266  6
    x_16_6    stock_ub_267  6
    x_16_6    unique_nonzero_owner_414  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_6    product_lb_206  1
    w_16_6    product_ub_207  1
    w_16_6    normalized_mass_16_221  1
    w_16_6    normalized_ratio_16_222  -1
    w_16_6    full_original_Gini_326  -3.8214285714285721e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_7    OBJ       -1.8000000000000009e-02
    x_16_7    product_lb_208  -2.4265534275042893e-02
    x_16_7    product_ub_209  -4.1530703055514692e-02
    x_16_7    onehot_16_220  1
    x_16_7    stock_lb_266  7
    x_16_7    stock_ub_267  7
    x_16_7    parent_nonstrict_scope_268  8.9999999999999924e-03
    x_16_7    unique_nonzero_owner_415  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_7    product_lb_208  1
    w_16_7    product_ub_209  1
    w_16_7    normalized_mass_16_221  1
    w_16_7    normalized_ratio_16_222  -1.1666666666666665e+00
    w_16_7    full_original_Gini_326  -7.6547619047619
    MARKER    'MARKER'                 'INTORG'
    x_16_8    OBJ       -9.0000000000000045e-03
    x_16_8    product_lb_210  -2.4265534275042893e-02
    x_16_8    product_ub_211  -4.1530703055514692e-02
    x_16_8    onehot_16_220  1
    x_16_8    stock_lb_266  8
    x_16_8    stock_ub_267  8
    x_16_8    parent_nonstrict_scope_268  1.7999999999999995e-02
    x_16_8    unique_nonzero_owner_416  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_8    product_lb_210  1
    w_16_8    product_ub_211  1
    w_16_8    normalized_mass_16_221  1
    w_16_8    normalized_ratio_16_222  -1.3333333333333333e+00
    w_16_8    full_original_Gini_326  -1.1921428571428573e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_9    product_lb_212  -2.4265534275042893e-02
    x_16_9    product_ub_213  -4.1530703055514692e-02
    x_16_9    onehot_16_220  1
    x_16_9    stock_lb_266  9
    x_16_9    stock_ub_267  9
    x_16_9    parent_nonstrict_scope_268  0.027
    x_16_9    unique_nonzero_owner_417  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_9    product_lb_212  1
    w_16_9    product_ub_213  1
    w_16_9    normalized_mass_16_221  1
    w_16_9    normalized_ratio_16_222  -1.5
    w_16_9    full_original_Gini_326  -1.6421428571428571e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_10   OBJ       0.00899999999999999
    x_16_10   product_lb_214  -2.4265534275042893e-02
    x_16_10   product_ub_215  -4.1530703055514692e-02
    x_16_10   onehot_16_220  1
    x_16_10   stock_lb_266  10
    x_16_10   stock_ub_267  10
    x_16_10   parent_nonstrict_scope_268  3.5999999999999990e-02
    x_16_10   unique_nonzero_owner_418  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_10   product_lb_214  1
    w_16_10   product_ub_215  1
    w_16_10   normalized_mass_16_221  1
    w_16_10   normalized_ratio_16_222  -1.6666666666666665e+00
    w_16_10   full_original_Gini_326  -2.0921428571428571e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_11   OBJ       0.018
    x_16_11   product_lb_216  -2.4265534275042893e-02
    x_16_11   product_ub_217  -4.1530703055514692e-02
    x_16_11   onehot_16_220  1
    x_16_11   stock_lb_266  11
    x_16_11   stock_ub_267  11
    x_16_11   parent_nonstrict_scope_268  0.045
    x_16_11   unique_nonzero_owner_419  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_11   product_lb_216  1
    w_16_11   product_ub_217  1
    w_16_11   normalized_mass_16_221  1
    w_16_11   normalized_ratio_16_222  -1.8333333333333333e+00
    w_16_11   full_original_Gini_326  -2.5421428571428567e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_12   OBJ       0.027
    x_16_12   product_lb_218  -2.4265534275042893e-02
    x_16_12   product_ub_219  -4.1530703055514692e-02
    x_16_12   onehot_16_220  1
    x_16_12   stock_lb_266  12
    x_16_12   stock_ub_267  12
    x_16_12   parent_nonstrict_scope_268  0.054
    x_16_12   unique_nonzero_owner_420  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_12   product_lb_218  1
    w_16_12   product_ub_219  1
    w_16_12   normalized_mass_16_221  1
    w_16_12   normalized_ratio_16_222  -2
    w_16_12   full_original_Gini_326  -2.9921428571428571e+01
    rho_16    normalized_ratio_16_222  1
    rho_16    block_pair_pos_275  1
    rho_16    block_pair_neg_276  -1
    rho_16    block_pair_pos_289  1
    rho_16    block_pair_neg_290  -1
    rho_16    block_pair_pos_297  1
    rho_16    block_pair_neg_298  -1
    rho_16    block_pair_pos_303  1
    rho_16    block_pair_neg_304  -1
    rho_16    block_pair_pos_307  -1
    rho_16    block_pair_neg_308  1
    rho_16    block_pair_pos_315  1
    rho_16    block_pair_neg_316  -1
    rho_16    block_pair_pos_323  1
    rho_16    block_pair_neg_324  -1
    rho_16    normalization_325  1
    MARKER    'MARKER'                 'INTORG'
    x_13_0    OBJ       0.03
    x_13_0    product_lb_223  -2.4265534275042893e-02
    x_13_0    product_ub_224  -4.1530703055514692e-02
    x_13_0    onehot_13_263  1
    x_13_0    parent_nonstrict_scope_268  0.096
    x_13_0    unique_nonzero_owner_421  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_0    product_lb_223  1
    w_13_0    product_ub_224  1
    w_13_0    normalized_mass_13_264  1
    w_13_0    full_original_Gini_326  -2.4078571428571429e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_1    OBJ       1.8000000000000002e-02
    x_13_1    product_lb_225  -2.4265534275042893e-02
    x_13_1    product_ub_226  -4.1530703055514692e-02
    x_13_1    onehot_13_263  1
    x_13_1    stock_lb_266  1
    x_13_1    stock_ub_267  1
    x_13_1    parent_nonstrict_scope_268  0.084
    x_13_1    unique_nonzero_owner_422  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_1    product_lb_225  1
    w_13_1    product_ub_226  1
    w_13_1    normalized_mass_13_264  1
    w_13_1    normalized_ratio_13_265  -0.125
    w_13_1    full_original_Gini_326  -2.0703571428571426e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_2    OBJ       6.0000000000000053e-03
    x_13_2    product_lb_227  -2.4265534275042893e-02
    x_13_2    product_ub_228  -4.1530703055514692e-02
    x_13_2    onehot_13_263  1
    x_13_2    stock_lb_266  2
    x_13_2    stock_ub_267  2
    x_13_2    parent_nonstrict_scope_268  7.2000000000000008e-02
    x_13_2    unique_nonzero_owner_423  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_2    product_lb_227  1
    w_13_2    product_ub_228  1
    w_13_2    normalized_mass_13_264  1
    w_13_2    normalized_ratio_13_265  -0.25
    w_13_2    full_original_Gini_326  -1.7328571428571426e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_3    OBJ       -6.0000000000000053e-03
    x_13_3    product_lb_229  -2.4265534275042893e-02
    x_13_3    product_ub_230  -4.1530703055514692e-02
    x_13_3    onehot_13_263  1
    x_13_3    stock_lb_266  3
    x_13_3    stock_ub_267  3
    x_13_3    parent_nonstrict_scope_268  0.06
    x_13_3    unique_nonzero_owner_424  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_3    product_lb_229  1
    w_13_3    product_ub_230  1
    w_13_3    normalized_mass_13_264  1
    w_13_3    normalized_ratio_13_265  -0.375
    w_13_3    full_original_Gini_326  -1.4453571428571429e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_4    OBJ       -1.8000000000000002e-02
    x_13_4    product_lb_231  -2.4265534275042893e-02
    x_13_4    product_ub_232  -4.1530703055514692e-02
    x_13_4    onehot_13_263  1
    x_13_4    stock_lb_266  4
    x_13_4    stock_ub_267  4
    x_13_4    parent_nonstrict_scope_268  0.048
    x_13_4    unique_nonzero_owner_425  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_4    product_lb_231  1
    w_13_4    product_ub_232  1
    w_13_4    normalized_mass_13_264  1
    w_13_4    normalized_ratio_13_265  -0.5
    w_13_4    full_original_Gini_326  -1.1778571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_5    OBJ       -0.03
    x_13_5    product_lb_233  -2.4265534275042893e-02
    x_13_5    product_ub_234  -4.1530703055514692e-02
    x_13_5    onehot_13_263  1
    x_13_5    stock_lb_266  5
    x_13_5    stock_ub_267  5
    x_13_5    parent_nonstrict_scope_268  3.6000000000000004e-02
    x_13_5    unique_nonzero_owner_426  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_5    product_lb_233  1
    w_13_5    product_ub_234  1
    w_13_5    normalized_mass_13_264  1
    w_13_5    normalized_ratio_13_265  -0.625
    w_13_5    full_original_Gini_326  -9.1535714285714285e+00
    MARKER    'MARKER'                 'INTORG'
    x_13_6    OBJ       -0.042
    x_13_6    product_lb_235  -2.4265534275042893e-02
    x_13_6    product_ub_236  -4.1530703055514692e-02
    x_13_6    onehot_13_263  1
    x_13_6    stock_lb_266  6
    x_13_6    stock_ub_267  6
    x_13_6    parent_nonstrict_scope_268  0.024
    x_13_6    unique_nonzero_owner_427  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_6    product_lb_235  1
    w_13_6    product_ub_236  1
    w_13_6    normalized_mass_13_264  1
    w_13_6    normalized_ratio_13_265  -0.75
    w_13_6    full_original_Gini_326  -6.6
    MARKER    'MARKER'                 'INTORG'
    x_13_7    OBJ       -5.4000000000000006e-02
    x_13_7    product_lb_237  -2.4265534275042893e-02
    x_13_7    product_ub_238  -4.1530703055514692e-02
    x_13_7    onehot_13_263  1
    x_13_7    stock_lb_266  7
    x_13_7    stock_ub_267  7
    x_13_7    parent_nonstrict_scope_268  0.012
    x_13_7    unique_nonzero_owner_428  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_7    product_lb_237  1
    w_13_7    product_ub_238  1
    w_13_7    normalized_mass_13_264  1
    w_13_7    normalized_ratio_13_265  -0.875
    w_13_7    full_original_Gini_326  -4.6964285714285721e+00
    MARKER    'MARKER'                 'INTORG'
    x_13_8    OBJ       -0.066
    x_13_8    product_lb_239  -2.4265534275042893e-02
    x_13_8    product_ub_240  -4.1530703055514692e-02
    x_13_8    onehot_13_263  1
    x_13_8    stock_lb_266  8
    x_13_8    stock_ub_267  8
    x_13_8    unique_nonzero_owner_429  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_8    product_lb_239  1
    w_13_8    product_ub_240  1
    w_13_8    normalized_mass_13_264  1
    w_13_8    normalized_ratio_13_265  -1
    w_13_8    full_original_Gini_326  -3.8214285714285721e+00
    MARKER    'MARKER'                 'INTORG'
    x_13_9    OBJ       -5.4000000000000006e-02
    x_13_9    product_lb_241  -2.4265534275042893e-02
    x_13_9    product_ub_242  -4.1530703055514692e-02
    x_13_9    onehot_13_263  1
    x_13_9    stock_lb_266  9
    x_13_9    stock_ub_267  9
    x_13_9    parent_nonstrict_scope_268  0.012
    x_13_9    unique_nonzero_owner_430  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_9    product_lb_241  1
    w_13_9    product_ub_242  1
    w_13_9    normalized_mass_13_264  1
    w_13_9    normalized_ratio_13_265  -1.125
    w_13_9    full_original_Gini_326  -6.6964285714285721e+00
    MARKER    'MARKER'                 'INTORG'
    x_13_10   OBJ       -0.042
    x_13_10   product_lb_243  -2.4265534275042893e-02
    x_13_10   product_ub_244  -4.1530703055514692e-02
    x_13_10   onehot_13_263  1
    x_13_10   stock_lb_266  10
    x_13_10   stock_ub_267  10
    x_13_10   parent_nonstrict_scope_268  0.024
    x_13_10   unique_nonzero_owner_431  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_10   product_lb_243  1
    w_13_10   product_ub_244  1
    w_13_10   normalized_mass_13_264  1
    w_13_10   normalized_ratio_13_265  -1.25
    w_13_10   full_original_Gini_326  -9.67142857142857
    MARKER    'MARKER'                 'INTORG'
    x_13_11   OBJ       -0.03
    x_13_11   product_lb_245  -2.4265534275042893e-02
    x_13_11   product_ub_246  -4.1530703055514692e-02
    x_13_11   onehot_13_263  1
    x_13_11   stock_lb_266  11
    x_13_11   stock_ub_267  11
    x_13_11   parent_nonstrict_scope_268  3.6000000000000004e-02
    x_13_11   unique_nonzero_owner_432  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_11   product_lb_245  1
    w_13_11   product_ub_246  1
    w_13_11   normalized_mass_13_264  1
    w_13_11   normalized_ratio_13_265  -1.375
    w_13_11   full_original_Gini_326  -1.3046428571428571e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_12   OBJ       -1.8000000000000002e-02
    x_13_12   product_lb_247  -2.4265534275042893e-02
    x_13_12   product_ub_248  -4.1530703055514692e-02
    x_13_12   onehot_13_263  1
    x_13_12   stock_lb_266  12
    x_13_12   stock_ub_267  12
    x_13_12   parent_nonstrict_scope_268  0.048
    x_13_12   unique_nonzero_owner_433  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_12   product_lb_247  1
    w_13_12   product_ub_248  1
    w_13_12   normalized_mass_13_264  1
    w_13_12   normalized_ratio_13_265  -1.5
    w_13_12   full_original_Gini_326  -1.6421428571428571e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_13   OBJ       -6.0000000000000053e-03
    x_13_13   product_lb_249  -2.4265534275042893e-02
    x_13_13   product_ub_250  -4.1530703055514692e-02
    x_13_13   onehot_13_263  1
    x_13_13   stock_lb_266  13
    x_13_13   stock_ub_267  13
    x_13_13   parent_nonstrict_scope_268  0.06
    MARKER    'MARKER'                 'INTEND'
    w_13_13   product_lb_249  1
    w_13_13   product_ub_250  1
    w_13_13   normalized_mass_13_264  1
    w_13_13   normalized_ratio_13_265  -1.625
    w_13_13   full_original_Gini_326  -1.9796428571428574e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_14   OBJ       6.0000000000000053e-03
    x_13_14   product_lb_251  -2.4265534275042893e-02
    x_13_14   product_ub_252  -4.1530703055514692e-02
    x_13_14   onehot_13_263  1
    x_13_14   stock_lb_266  14
    x_13_14   stock_ub_267  14
    x_13_14   parent_nonstrict_scope_268  7.2000000000000008e-02
    x_13_14   unique_nonzero_owner_434  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_14   product_lb_251  1
    w_13_14   product_ub_252  1
    w_13_14   normalized_mass_13_264  1
    w_13_14   normalized_ratio_13_265  -1.75
    w_13_14   full_original_Gini_326  -2.3171428571428574e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_15   OBJ       1.8000000000000002e-02
    x_13_15   product_lb_253  -2.4265534275042893e-02
    x_13_15   product_ub_254  -4.1530703055514692e-02
    x_13_15   onehot_13_263  1
    x_13_15   stock_lb_266  15
    x_13_15   stock_ub_267  15
    x_13_15   parent_nonstrict_scope_268  0.084
    x_13_15   unique_nonzero_owner_435  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_15   product_lb_253  1
    w_13_15   product_ub_254  1
    w_13_15   normalized_mass_13_264  1
    w_13_15   normalized_ratio_13_265  -1.875
    w_13_15   full_original_Gini_326  -2.6546428571428571e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_16   OBJ       0.03
    x_13_16   product_lb_255  -2.4265534275042893e-02
    x_13_16   product_ub_256  -4.1530703055514692e-02
    x_13_16   onehot_13_263  1
    x_13_16   stock_lb_266  16
    x_13_16   stock_ub_267  16
    x_13_16   parent_nonstrict_scope_268  0.096
    x_13_16   unique_nonzero_owner_436  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_16   product_lb_255  1
    w_13_16   product_ub_256  1
    w_13_16   normalized_mass_13_264  1
    w_13_16   normalized_ratio_13_265  -2
    w_13_16   full_original_Gini_326  -2.9921428571428571e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_17   OBJ       4.1999999999999996e-02
    x_13_17   product_lb_257  -2.4265534275042893e-02
    x_13_17   product_ub_258  -4.1530703055514692e-02
    x_13_17   onehot_13_263  1
    x_13_17   stock_lb_266  17
    x_13_17   stock_ub_267  17
    x_13_17   parent_nonstrict_scope_268  0.108
    x_13_17   unique_nonzero_owner_437  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_17   product_lb_257  1
    w_13_17   product_ub_258  1
    w_13_17   normalized_mass_13_264  1
    w_13_17   normalized_ratio_13_265  -2.125
    w_13_17   full_original_Gini_326  -3.3296428571428571e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_18   OBJ       5.3999999999999992e-02
    x_13_18   product_lb_259  -2.4265534275042893e-02
    x_13_18   product_ub_260  -4.1530703055514692e-02
    x_13_18   onehot_13_263  1
    x_13_18   stock_lb_266  18
    x_13_18   stock_ub_267  18
    x_13_18   parent_nonstrict_scope_268  0.12
    x_13_18   unique_nonzero_owner_438  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_18   product_lb_259  1
    w_13_18   product_ub_260  1
    w_13_18   normalized_mass_13_264  1
    w_13_18   normalized_ratio_13_265  -2.25
    w_13_18   full_original_Gini_326  -3.6671428571428578e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_19   OBJ       0.066
    x_13_19   product_lb_261  -2.4265534275042893e-02
    x_13_19   product_ub_262  -4.1530703055514692e-02
    x_13_19   onehot_13_263  1
    x_13_19   stock_lb_266  19
    x_13_19   stock_ub_267  19
    x_13_19   parent_nonstrict_scope_268  0.132
    x_13_19   unique_nonzero_owner_439  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_19   product_lb_261  1
    w_13_19   product_ub_262  1
    w_13_19   normalized_mass_13_264  1
    w_13_19   normalized_ratio_13_265  -2.375
    w_13_19   full_original_Gini_326  -4.0046428571428578e+01
    rho_13    normalized_ratio_13_265  1
    rho_13    block_pair_pos_273  1
    rho_13    block_pair_neg_274  -1
    rho_13    block_pair_pos_287  1
    rho_13    block_pair_neg_288  -1
    rho_13    block_pair_pos_295  1
    rho_13    block_pair_neg_296  -1
    rho_13    block_pair_pos_301  1
    rho_13    block_pair_neg_302  -1
    rho_13    block_pair_pos_307  1
    rho_13    block_pair_neg_308  -1
    rho_13    block_pair_pos_313  1
    rho_13    block_pair_neg_314  -1
    rho_13    block_pair_pos_321  1
    rho_13    block_pair_neg_322  -1
    rho_13    normalization_325  1
    a_6_2     block_pair_pos_281  1
    a_6_2     block_pair_neg_282  1
    a_6_2     full_original_Gini_326  -1
    a_6_31    block_pair_pos_291  1
    a_6_31    block_pair_neg_292  1
    a_6_31    full_original_Gini_326  -1
    a_6_9     block_pair_pos_285  1
    a_6_9     block_pair_neg_286  1
    a_6_9     full_original_Gini_326  -1
    a_6_32    block_pair_pos_293  1
    a_6_32    block_pair_neg_294  1
    a_6_32    full_original_Gini_326  -1
    a_6_8     block_pair_pos_283  1
    a_6_8     block_pair_neg_284  1
    a_6_8     full_original_Gini_326  -1
    a_6_16    block_pair_pos_289  1
    a_6_16    block_pair_neg_290  1
    a_6_16    full_original_Gini_326  -1
    a_6_13    block_pair_pos_287  1
    a_6_13    block_pair_neg_288  1
    a_6_13    full_original_Gini_326  -1
    a_2_31    block_pair_pos_277  1
    a_2_31    block_pair_neg_278  1
    a_2_31    full_original_Gini_326  -1
    a_2_9     block_pair_pos_271  1
    a_2_9     block_pair_neg_272  1
    a_2_9     full_original_Gini_326  -1
    a_2_32    block_pair_pos_279  1
    a_2_32    block_pair_neg_280  1
    a_2_32    full_original_Gini_326  -1
    a_2_8     block_pair_pos_269  1
    a_2_8     block_pair_neg_270  1
    a_2_8     full_original_Gini_326  -1
    a_2_16    block_pair_pos_275  1
    a_2_16    block_pair_neg_276  1
    a_2_16    full_original_Gini_326  -1
    a_2_13    block_pair_pos_273  1
    a_2_13    block_pair_neg_274  1
    a_2_13    full_original_Gini_326  -1
    a_31_9    block_pair_pos_311  1
    a_31_9    block_pair_neg_312  1
    a_31_9    full_original_Gini_326  -1
    a_31_32   block_pair_pos_317  1
    a_31_32   block_pair_neg_318  1
    a_31_32   full_original_Gini_326  -1
    a_31_8    block_pair_pos_309  1
    a_31_8    block_pair_neg_310  1
    a_31_8    full_original_Gini_326  -1
    a_31_16   block_pair_pos_315  1
    a_31_16   block_pair_neg_316  1
    a_31_16   full_original_Gini_326  -1
    a_31_13   block_pair_pos_313  1
    a_31_13   block_pair_neg_314  1
    a_31_13   full_original_Gini_326  -1
    a_9_32    block_pair_pos_305  1
    a_9_32    block_pair_neg_306  1
    a_9_32    full_original_Gini_326  -1
    a_9_8     block_pair_pos_299  1
    a_9_8     block_pair_neg_300  1
    a_9_8     full_original_Gini_326  -1
    a_9_16    block_pair_pos_303  1
    a_9_16    block_pair_neg_304  1
    a_9_16    full_original_Gini_326  -1
    a_9_13    block_pair_pos_301  1
    a_9_13    block_pair_neg_302  1
    a_9_13    full_original_Gini_326  -1
    a_32_8    block_pair_pos_319  1
    a_32_8    block_pair_neg_320  1
    a_32_8    full_original_Gini_326  -1
    a_32_16   block_pair_pos_323  1
    a_32_16   block_pair_neg_324  1
    a_32_16   full_original_Gini_326  -1
    a_32_13   block_pair_pos_321  1
    a_32_13   block_pair_neg_322  1
    a_32_13   full_original_Gini_326  -1
    a_8_16    block_pair_pos_297  1
    a_8_16    block_pair_neg_298  1
    a_8_16    full_original_Gini_326  -1
    a_8_13    block_pair_pos_295  1
    a_8_13    block_pair_neg_296  1
    a_8_13    full_original_Gini_326  -1
    a_16_13   block_pair_pos_307  1
    a_16_13   block_pair_neg_308  1
    a_16_13   full_original_Gini_326  -1
    MARKER    'MARKER'                 'INTORG'
    service_0_6_0  unique_nonzero_owner_327  1
    service_0_6_0  service_visit_def_881  1
    service_0_6_0  free_load_conservation_882  -1
    service_0_6_0  original_T_including_depot_unload_930  120
    service_0_6_2  unique_nonzero_owner_328  1
    service_0_6_2  service_visit_def_881  1
    service_0_6_2  free_load_conservation_882  1
    service_0_6_3  unique_nonzero_owner_329  1
    service_0_6_3  service_visit_def_881  1
    service_0_6_3  free_load_conservation_882  2
    service_0_6_4  unique_nonzero_owner_330  1
    service_0_6_4  service_visit_def_881  1
    service_0_6_4  free_load_conservation_882  3
    service_0_6_5  unique_nonzero_owner_331  1
    service_0_6_5  service_visit_def_881  1
    service_0_6_5  free_load_conservation_882  4
    service_0_6_6  unique_nonzero_owner_332  1
    service_0_6_6  service_visit_def_881  1
    service_0_6_6  free_load_conservation_882  5
    service_0_6_7  unique_nonzero_owner_333  1
    service_0_6_7  service_visit_def_881  1
    service_0_6_7  free_load_conservation_882  6
    service_0_6_8  unique_nonzero_owner_334  1
    service_0_6_8  service_visit_def_881  1
    service_0_6_8  free_load_conservation_882  7
    service_0_6_9  unique_nonzero_owner_335  1
    service_0_6_9  service_visit_def_881  1
    service_0_6_9  free_load_conservation_882  8
    service_0_6_10  unique_nonzero_owner_336  1
    service_0_6_10  service_visit_def_881  1
    service_0_6_10  free_load_conservation_882  9
    service_1_6_0  unique_nonzero_owner_327  1
    service_1_6_0  service_visit_def_1254  1
    service_1_6_0  free_load_conservation_1255  -1
    service_1_6_0  original_T_including_depot_unload_1301  120
    service_1_6_2  unique_nonzero_owner_328  1
    service_1_6_2  service_visit_def_1254  1
    service_1_6_2  free_load_conservation_1255  1
    service_1_6_3  unique_nonzero_owner_329  1
    service_1_6_3  service_visit_def_1254  1
    service_1_6_3  free_load_conservation_1255  2
    service_1_6_4  unique_nonzero_owner_330  1
    service_1_6_4  service_visit_def_1254  1
    service_1_6_4  free_load_conservation_1255  3
    service_1_6_5  unique_nonzero_owner_331  1
    service_1_6_5  service_visit_def_1254  1
    service_1_6_5  free_load_conservation_1255  4
    service_1_6_6  unique_nonzero_owner_332  1
    service_1_6_6  service_visit_def_1254  1
    service_1_6_6  free_load_conservation_1255  5
    service_1_6_7  unique_nonzero_owner_333  1
    service_1_6_7  service_visit_def_1254  1
    service_1_6_7  free_load_conservation_1255  6
    service_1_6_8  unique_nonzero_owner_334  1
    service_1_6_8  service_visit_def_1254  1
    service_1_6_8  free_load_conservation_1255  7
    service_1_6_9  unique_nonzero_owner_335  1
    service_1_6_9  service_visit_def_1254  1
    service_1_6_9  free_load_conservation_1255  8
    service_1_6_10  unique_nonzero_owner_336  1
    service_1_6_10  service_visit_def_1254  1
    service_1_6_10  free_load_conservation_1255  9
    service_2_6_0  unique_nonzero_owner_327  1
    service_2_6_0  service_visit_def_1625  1
    service_2_6_0  free_load_conservation_1626  -1
    service_2_6_0  original_T_including_depot_unload_1672  120
    service_2_6_2  unique_nonzero_owner_328  1
    service_2_6_2  service_visit_def_1625  1
    service_2_6_2  free_load_conservation_1626  1
    service_2_6_3  unique_nonzero_owner_329  1
    service_2_6_3  service_visit_def_1625  1
    service_2_6_3  free_load_conservation_1626  2
    service_2_6_4  unique_nonzero_owner_330  1
    service_2_6_4  service_visit_def_1625  1
    service_2_6_4  free_load_conservation_1626  3
    service_2_6_5  unique_nonzero_owner_331  1
    service_2_6_5  service_visit_def_1625  1
    service_2_6_5  free_load_conservation_1626  4
    service_2_6_6  unique_nonzero_owner_332  1
    service_2_6_6  service_visit_def_1625  1
    service_2_6_6  free_load_conservation_1626  5
    service_2_6_7  unique_nonzero_owner_333  1
    service_2_6_7  service_visit_def_1625  1
    service_2_6_7  free_load_conservation_1626  6
    service_2_6_8  unique_nonzero_owner_334  1
    service_2_6_8  service_visit_def_1625  1
    service_2_6_8  free_load_conservation_1626  7
    service_2_6_9  unique_nonzero_owner_335  1
    service_2_6_9  service_visit_def_1625  1
    service_2_6_9  free_load_conservation_1626  8
    service_2_6_10  unique_nonzero_owner_336  1
    service_2_6_10  service_visit_def_1625  1
    service_2_6_10  free_load_conservation_1626  9
    service_0_2_1  unique_nonzero_owner_337  1
    service_0_2_1  service_visit_def_887  1
    service_0_2_1  free_load_conservation_888  1
    service_0_2_2  unique_nonzero_owner_338  1
    service_0_2_2  service_visit_def_887  1
    service_0_2_2  free_load_conservation_888  2
    service_0_2_3  unique_nonzero_owner_339  1
    service_0_2_3  service_visit_def_887  1
    service_0_2_3  free_load_conservation_888  3
    service_0_2_4  unique_nonzero_owner_340  1
    service_0_2_4  service_visit_def_887  1
    service_0_2_4  free_load_conservation_888  4
    service_0_2_5  unique_nonzero_owner_341  1
    service_0_2_5  service_visit_def_887  1
    service_0_2_5  free_load_conservation_888  5
    service_0_2_6  unique_nonzero_owner_342  1
    service_0_2_6  service_visit_def_887  1
    service_0_2_6  free_load_conservation_888  6
    service_0_2_7  unique_nonzero_owner_343  1
    service_0_2_7  service_visit_def_887  1
    service_0_2_7  free_load_conservation_888  7
    service_0_2_8  unique_nonzero_owner_344  1
    service_0_2_8  service_visit_def_887  1
    service_0_2_8  free_load_conservation_888  8
    service_0_2_9  unique_nonzero_owner_345  1
    service_0_2_9  service_visit_def_887  1
    service_0_2_9  free_load_conservation_888  9
    service_0_2_10  unique_nonzero_owner_346  1
    service_0_2_10  service_visit_def_887  1
    service_0_2_10  free_load_conservation_888  10
    service_0_2_11  unique_nonzero_owner_347  1
    service_0_2_11  service_visit_def_887  1
    service_0_2_11  free_load_conservation_888  11
    service_0_2_12  unique_nonzero_owner_348  1
    service_0_2_12  service_visit_def_887  1
    service_0_2_12  free_load_conservation_888  12
    service_0_2_13  unique_nonzero_owner_349  1
    service_0_2_13  service_visit_def_887  1
    service_0_2_13  free_load_conservation_888  13
    service_0_2_14  unique_nonzero_owner_350  1
    service_0_2_14  service_visit_def_887  1
    service_0_2_14  free_load_conservation_888  14
    service_0_2_15  unique_nonzero_owner_351  1
    service_0_2_15  service_visit_def_887  1
    service_0_2_15  free_load_conservation_888  15
    service_1_2_1  unique_nonzero_owner_337  1
    service_1_2_1  service_visit_def_1260  1
    service_1_2_1  free_load_conservation_1261  1
    service_1_2_2  unique_nonzero_owner_338  1
    service_1_2_2  service_visit_def_1260  1
    service_1_2_2  free_load_conservation_1261  2
    service_1_2_3  unique_nonzero_owner_339  1
    service_1_2_3  service_visit_def_1260  1
    service_1_2_3  free_load_conservation_1261  3
    service_1_2_4  unique_nonzero_owner_340  1
    service_1_2_4  service_visit_def_1260  1
    service_1_2_4  free_load_conservation_1261  4
    service_1_2_5  unique_nonzero_owner_341  1
    service_1_2_5  service_visit_def_1260  1
    service_1_2_5  free_load_conservation_1261  5
    service_1_2_6  unique_nonzero_owner_342  1
    service_1_2_6  service_visit_def_1260  1
    service_1_2_6  free_load_conservation_1261  6
    service_1_2_7  unique_nonzero_owner_343  1
    service_1_2_7  service_visit_def_1260  1
    service_1_2_7  free_load_conservation_1261  7
    service_1_2_8  unique_nonzero_owner_344  1
    service_1_2_8  service_visit_def_1260  1
    service_1_2_8  free_load_conservation_1261  8
    service_1_2_9  unique_nonzero_owner_345  1
    service_1_2_9  service_visit_def_1260  1
    service_1_2_9  free_load_conservation_1261  9
    service_1_2_10  unique_nonzero_owner_346  1
    service_1_2_10  service_visit_def_1260  1
    service_1_2_10  free_load_conservation_1261  10
    service_1_2_11  unique_nonzero_owner_347  1
    service_1_2_11  service_visit_def_1260  1
    service_1_2_11  free_load_conservation_1261  11
    service_1_2_12  unique_nonzero_owner_348  1
    service_1_2_12  service_visit_def_1260  1
    service_1_2_12  free_load_conservation_1261  12
    service_1_2_13  unique_nonzero_owner_349  1
    service_1_2_13  service_visit_def_1260  1
    service_1_2_13  free_load_conservation_1261  13
    service_1_2_14  unique_nonzero_owner_350  1
    service_1_2_14  service_visit_def_1260  1
    service_1_2_14  free_load_conservation_1261  14
    service_1_2_15  unique_nonzero_owner_351  1
    service_1_2_15  service_visit_def_1260  1
    service_1_2_15  free_load_conservation_1261  15
    service_2_2_1  unique_nonzero_owner_337  1
    service_2_2_1  service_visit_def_1631  1
    service_2_2_1  free_load_conservation_1632  1
    service_2_2_2  unique_nonzero_owner_338  1
    service_2_2_2  service_visit_def_1631  1
    service_2_2_2  free_load_conservation_1632  2
    service_2_2_3  unique_nonzero_owner_339  1
    service_2_2_3  service_visit_def_1631  1
    service_2_2_3  free_load_conservation_1632  3
    service_2_2_4  unique_nonzero_owner_340  1
    service_2_2_4  service_visit_def_1631  1
    service_2_2_4  free_load_conservation_1632  4
    service_2_2_5  unique_nonzero_owner_341  1
    service_2_2_5  service_visit_def_1631  1
    service_2_2_5  free_load_conservation_1632  5
    service_2_2_6  unique_nonzero_owner_342  1
    service_2_2_6  service_visit_def_1631  1
    service_2_2_6  free_load_conservation_1632  6
    service_2_2_7  unique_nonzero_owner_343  1
    service_2_2_7  service_visit_def_1631  1
    service_2_2_7  free_load_conservation_1632  7
    service_2_2_8  unique_nonzero_owner_344  1
    service_2_2_8  service_visit_def_1631  1
    service_2_2_8  free_load_conservation_1632  8
    service_2_2_9  unique_nonzero_owner_345  1
    service_2_2_9  service_visit_def_1631  1
    service_2_2_9  free_load_conservation_1632  9
    service_2_2_10  unique_nonzero_owner_346  1
    service_2_2_10  service_visit_def_1631  1
    service_2_2_10  free_load_conservation_1632  10
    service_2_2_11  unique_nonzero_owner_347  1
    service_2_2_11  service_visit_def_1631  1
    service_2_2_11  free_load_conservation_1632  11
    service_2_2_12  unique_nonzero_owner_348  1
    service_2_2_12  service_visit_def_1631  1
    service_2_2_12  free_load_conservation_1632  12
    service_2_2_13  unique_nonzero_owner_349  1
    service_2_2_13  service_visit_def_1631  1
    service_2_2_13  free_load_conservation_1632  13
    service_2_2_14  unique_nonzero_owner_350  1
    service_2_2_14  service_visit_def_1631  1
    service_2_2_14  free_load_conservation_1632  14
    service_2_2_15  unique_nonzero_owner_351  1
    service_2_2_15  service_visit_def_1631  1
    service_2_2_15  free_load_conservation_1632  15
    service_0_31_0  unique_nonzero_owner_352  1
    service_0_31_0  service_visit_def_893  1
    service_0_31_0  free_load_conservation_894  -2
    service_0_31_0  original_T_including_depot_unload_930  240
    service_0_31_1  unique_nonzero_owner_353  1
    service_0_31_1  service_visit_def_893  1
    service_0_31_1  free_load_conservation_894  -1
    service_0_31_1  original_T_including_depot_unload_930  120
    service_0_31_3  unique_nonzero_owner_354  1
    service_0_31_3  service_visit_def_893  1
    service_0_31_3  free_load_conservation_894  1
    service_0_31_4  unique_nonzero_owner_355  1
    service_0_31_4  service_visit_def_893  1
    service_0_31_4  free_load_conservation_894  2
    service_0_31_5  unique_nonzero_owner_356  1
    service_0_31_5  service_visit_def_893  1
    service_0_31_5  free_load_conservation_894  3
    service_0_31_6  unique_nonzero_owner_357  1
    service_0_31_6  service_visit_def_893  1
    service_0_31_6  free_load_conservation_894  4
    service_0_31_7  unique_nonzero_owner_358  1
    service_0_31_7  service_visit_def_893  1
    service_0_31_7  free_load_conservation_894  5
    service_0_31_8  unique_nonzero_owner_359  1
    service_0_31_8  service_visit_def_893  1
    service_0_31_8  free_load_conservation_894  6
    service_0_31_9  unique_nonzero_owner_360  1
    service_0_31_9  service_visit_def_893  1
    service_0_31_9  free_load_conservation_894  7
    service_0_31_10  unique_nonzero_owner_361  1
    service_0_31_10  service_visit_def_893  1
    service_0_31_10  free_load_conservation_894  8
    service_0_31_11  unique_nonzero_owner_362  1
    service_0_31_11  service_visit_def_893  1
    service_0_31_11  free_load_conservation_894  9
    service_0_31_12  unique_nonzero_owner_363  1
    service_0_31_12  service_visit_def_893  1
    service_0_31_12  free_load_conservation_894  10
    service_1_31_0  unique_nonzero_owner_352  1
    service_1_31_0  service_visit_def_1266  1
    service_1_31_0  free_load_conservation_1267  -2
    service_1_31_0  original_T_including_depot_unload_1301  240
    service_1_31_1  unique_nonzero_owner_353  1
    service_1_31_1  service_visit_def_1266  1
    service_1_31_1  free_load_conservation_1267  -1
    service_1_31_1  original_T_including_depot_unload_1301  120
    service_1_31_3  unique_nonzero_owner_354  1
    service_1_31_3  service_visit_def_1266  1
    service_1_31_3  free_load_conservation_1267  1
    service_1_31_4  unique_nonzero_owner_355  1
    service_1_31_4  service_visit_def_1266  1
    service_1_31_4  free_load_conservation_1267  2
    service_1_31_5  unique_nonzero_owner_356  1
    service_1_31_5  service_visit_def_1266  1
    service_1_31_5  free_load_conservation_1267  3
    service_1_31_6  unique_nonzero_owner_357  1
    service_1_31_6  service_visit_def_1266  1
    service_1_31_6  free_load_conservation_1267  4
    service_1_31_7  unique_nonzero_owner_358  1
    service_1_31_7  service_visit_def_1266  1
    service_1_31_7  free_load_conservation_1267  5
    service_1_31_8  unique_nonzero_owner_359  1
    service_1_31_8  service_visit_def_1266  1
    service_1_31_8  free_load_conservation_1267  6
    service_1_31_9  unique_nonzero_owner_360  1
    service_1_31_9  service_visit_def_1266  1
    service_1_31_9  free_load_conservation_1267  7
    service_1_31_10  unique_nonzero_owner_361  1
    service_1_31_10  service_visit_def_1266  1
    service_1_31_10  free_load_conservation_1267  8
    service_1_31_11  unique_nonzero_owner_362  1
    service_1_31_11  service_visit_def_1266  1
    service_1_31_11  free_load_conservation_1267  9
    service_1_31_12  unique_nonzero_owner_363  1
    service_1_31_12  service_visit_def_1266  1
    service_1_31_12  free_load_conservation_1267  10
    service_2_31_0  unique_nonzero_owner_352  1
    service_2_31_0  service_visit_def_1637  1
    service_2_31_0  free_load_conservation_1638  -2
    service_2_31_0  original_T_including_depot_unload_1672  240
    service_2_31_1  unique_nonzero_owner_353  1
    service_2_31_1  service_visit_def_1637  1
    service_2_31_1  free_load_conservation_1638  -1
    service_2_31_1  original_T_including_depot_unload_1672  120
    service_2_31_3  unique_nonzero_owner_354  1
    service_2_31_3  service_visit_def_1637  1
    service_2_31_3  free_load_conservation_1638  1
    service_2_31_4  unique_nonzero_owner_355  1
    service_2_31_4  service_visit_def_1637  1
    service_2_31_4  free_load_conservation_1638  2
    service_2_31_5  unique_nonzero_owner_356  1
    service_2_31_5  service_visit_def_1637  1
    service_2_31_5  free_load_conservation_1638  3
    service_2_31_6  unique_nonzero_owner_357  1
    service_2_31_6  service_visit_def_1637  1
    service_2_31_6  free_load_conservation_1638  4
    service_2_31_7  unique_nonzero_owner_358  1
    service_2_31_7  service_visit_def_1637  1
    service_2_31_7  free_load_conservation_1638  5
    service_2_31_8  unique_nonzero_owner_359  1
    service_2_31_8  service_visit_def_1637  1
    service_2_31_8  free_load_conservation_1638  6
    service_2_31_9  unique_nonzero_owner_360  1
    service_2_31_9  service_visit_def_1637  1
    service_2_31_9  free_load_conservation_1638  7
    service_2_31_10  unique_nonzero_owner_361  1
    service_2_31_10  service_visit_def_1637  1
    service_2_31_10  free_load_conservation_1638  8
    service_2_31_11  unique_nonzero_owner_362  1
    service_2_31_11  service_visit_def_1637  1
    service_2_31_11  free_load_conservation_1638  9
    service_2_31_12  unique_nonzero_owner_363  1
    service_2_31_12  service_visit_def_1637  1
    service_2_31_12  free_load_conservation_1638  10
    service_0_9_0  unique_nonzero_owner_364  1
    service_0_9_0  service_visit_def_899  1
    service_0_9_0  free_load_conservation_900  -8
    service_0_9_0  original_T_including_depot_unload_930  960
    service_0_9_1  unique_nonzero_owner_365  1
    service_0_9_1  service_visit_def_899  1
    service_0_9_1  free_load_conservation_900  -7
    service_0_9_1  original_T_including_depot_unload_930  840
    service_0_9_2  unique_nonzero_owner_366  1
    service_0_9_2  service_visit_def_899  1
    service_0_9_2  free_load_conservation_900  -6
    service_0_9_2  original_T_including_depot_unload_930  720
    service_0_9_3  unique_nonzero_owner_367  1
    service_0_9_3  service_visit_def_899  1
    service_0_9_3  free_load_conservation_900  -5
    service_0_9_3  original_T_including_depot_unload_930  600
    service_0_9_4  unique_nonzero_owner_368  1
    service_0_9_4  service_visit_def_899  1
    service_0_9_4  free_load_conservation_900  -4
    service_0_9_4  original_T_including_depot_unload_930  480
    service_0_9_5  unique_nonzero_owner_369  1
    service_0_9_5  service_visit_def_899  1
    service_0_9_5  free_load_conservation_900  -3
    service_0_9_5  original_T_including_depot_unload_930  360
    service_0_9_6  unique_nonzero_owner_370  1
    service_0_9_6  service_visit_def_899  1
    service_0_9_6  free_load_conservation_900  -2
    service_0_9_6  original_T_including_depot_unload_930  240
    service_0_9_7  unique_nonzero_owner_371  1
    service_0_9_7  service_visit_def_899  1
    service_0_9_7  free_load_conservation_900  -1
    service_0_9_7  original_T_including_depot_unload_930  120
    service_0_9_9  unique_nonzero_owner_372  1
    service_0_9_9  service_visit_def_899  1
    service_0_9_9  free_load_conservation_900  1
    service_0_9_10  unique_nonzero_owner_373  1
    service_0_9_10  service_visit_def_899  1
    service_0_9_10  free_load_conservation_900  2
    service_0_9_11  unique_nonzero_owner_374  1
    service_0_9_11  service_visit_def_899  1
    service_0_9_11  free_load_conservation_900  3
    service_0_9_12  unique_nonzero_owner_375  1
    service_0_9_12  service_visit_def_899  1
    service_0_9_12  free_load_conservation_900  4
    service_1_9_0  unique_nonzero_owner_364  1
    service_1_9_0  service_visit_def_1272  1
    service_1_9_0  free_load_conservation_1273  -8
    service_1_9_0  original_T_including_depot_unload_1301  960
    service_1_9_1  unique_nonzero_owner_365  1
    service_1_9_1  service_visit_def_1272  1
    service_1_9_1  free_load_conservation_1273  -7
    service_1_9_1  original_T_including_depot_unload_1301  840
    service_1_9_2  unique_nonzero_owner_366  1
    service_1_9_2  service_visit_def_1272  1
    service_1_9_2  free_load_conservation_1273  -6
    service_1_9_2  original_T_including_depot_unload_1301  720
    service_1_9_3  unique_nonzero_owner_367  1
    service_1_9_3  service_visit_def_1272  1
    service_1_9_3  free_load_conservation_1273  -5
    service_1_9_3  original_T_including_depot_unload_1301  600
    service_1_9_4  unique_nonzero_owner_368  1
    service_1_9_4  service_visit_def_1272  1
    service_1_9_4  free_load_conservation_1273  -4
    service_1_9_4  original_T_including_depot_unload_1301  480
    service_1_9_5  unique_nonzero_owner_369  1
    service_1_9_5  service_visit_def_1272  1
    service_1_9_5  free_load_conservation_1273  -3
    service_1_9_5  original_T_including_depot_unload_1301  360
    service_1_9_6  unique_nonzero_owner_370  1
    service_1_9_6  service_visit_def_1272  1
    service_1_9_6  free_load_conservation_1273  -2
    service_1_9_6  original_T_including_depot_unload_1301  240
    service_1_9_7  unique_nonzero_owner_371  1
    service_1_9_7  service_visit_def_1272  1
    service_1_9_7  free_load_conservation_1273  -1
    service_1_9_7  original_T_including_depot_unload_1301  120
    service_1_9_9  unique_nonzero_owner_372  1
    service_1_9_9  service_visit_def_1272  1
    service_1_9_9  free_load_conservation_1273  1
    service_1_9_10  unique_nonzero_owner_373  1
    service_1_9_10  service_visit_def_1272  1
    service_1_9_10  free_load_conservation_1273  2
    service_1_9_11  unique_nonzero_owner_374  1
    service_1_9_11  service_visit_def_1272  1
    service_1_9_11  free_load_conservation_1273  3
    service_1_9_12  unique_nonzero_owner_375  1
    service_1_9_12  service_visit_def_1272  1
    service_1_9_12  free_load_conservation_1273  4
    service_2_9_0  unique_nonzero_owner_364  1
    service_2_9_0  service_visit_def_1643  1
    service_2_9_0  free_load_conservation_1644  -8
    service_2_9_0  original_T_including_depot_unload_1672  960
    service_2_9_1  unique_nonzero_owner_365  1
    service_2_9_1  service_visit_def_1643  1
    service_2_9_1  free_load_conservation_1644  -7
    service_2_9_1  original_T_including_depot_unload_1672  840
    service_2_9_2  unique_nonzero_owner_366  1
    service_2_9_2  service_visit_def_1643  1
    service_2_9_2  free_load_conservation_1644  -6
    service_2_9_2  original_T_including_depot_unload_1672  720
    service_2_9_3  unique_nonzero_owner_367  1
    service_2_9_3  service_visit_def_1643  1
    service_2_9_3  free_load_conservation_1644  -5
    service_2_9_3  original_T_including_depot_unload_1672  600
    service_2_9_4  unique_nonzero_owner_368  1
    service_2_9_4  service_visit_def_1643  1
    service_2_9_4  free_load_conservation_1644  -4
    service_2_9_4  original_T_including_depot_unload_1672  480
    service_2_9_5  unique_nonzero_owner_369  1
    service_2_9_5  service_visit_def_1643  1
    service_2_9_5  free_load_conservation_1644  -3
    service_2_9_5  original_T_including_depot_unload_1672  360
    service_2_9_6  unique_nonzero_owner_370  1
    service_2_9_6  service_visit_def_1643  1
    service_2_9_6  free_load_conservation_1644  -2
    service_2_9_6  original_T_including_depot_unload_1672  240
    service_2_9_7  unique_nonzero_owner_371  1
    service_2_9_7  service_visit_def_1643  1
    service_2_9_7  free_load_conservation_1644  -1
    service_2_9_7  original_T_including_depot_unload_1672  120
    service_2_9_9  unique_nonzero_owner_372  1
    service_2_9_9  service_visit_def_1643  1
    service_2_9_9  free_load_conservation_1644  1
    service_2_9_10  unique_nonzero_owner_373  1
    service_2_9_10  service_visit_def_1643  1
    service_2_9_10  free_load_conservation_1644  2
    service_2_9_11  unique_nonzero_owner_374  1
    service_2_9_11  service_visit_def_1643  1
    service_2_9_11  free_load_conservation_1644  3
    service_2_9_12  unique_nonzero_owner_375  1
    service_2_9_12  service_visit_def_1643  1
    service_2_9_12  free_load_conservation_1644  4
    service_0_32_1  unique_nonzero_owner_376  1
    service_0_32_1  service_visit_def_905  1
    service_0_32_1  free_load_conservation_906  1
    service_0_32_2  unique_nonzero_owner_377  1
    service_0_32_2  service_visit_def_905  1
    service_0_32_2  free_load_conservation_906  2
    service_0_32_3  unique_nonzero_owner_378  1
    service_0_32_3  service_visit_def_905  1
    service_0_32_3  free_load_conservation_906  3
    service_0_32_4  unique_nonzero_owner_379  1
    service_0_32_4  service_visit_def_905  1
    service_0_32_4  free_load_conservation_906  4
    service_0_32_5  unique_nonzero_owner_380  1
    service_0_32_5  service_visit_def_905  1
    service_0_32_5  free_load_conservation_906  5
    service_0_32_6  unique_nonzero_owner_381  1
    service_0_32_6  service_visit_def_905  1
    service_0_32_6  free_load_conservation_906  6
    service_0_32_7  unique_nonzero_owner_382  1
    service_0_32_7  service_visit_def_905  1
    service_0_32_7  free_load_conservation_906  7
    service_0_32_8  unique_nonzero_owner_383  1
    service_0_32_8  service_visit_def_905  1
    service_0_32_8  free_load_conservation_906  8
    service_0_32_9  unique_nonzero_owner_384  1
    service_0_32_9  service_visit_def_905  1
    service_0_32_9  free_load_conservation_906  9
    service_0_32_10  unique_nonzero_owner_385  1
    service_0_32_10  service_visit_def_905  1
    service_0_32_10  free_load_conservation_906  10
    service_0_32_11  unique_nonzero_owner_386  1
    service_0_32_11  service_visit_def_905  1
    service_0_32_11  free_load_conservation_906  11
    service_0_32_12  unique_nonzero_owner_387  1
    service_0_32_12  service_visit_def_905  1
    service_0_32_12  free_load_conservation_906  12
    service_1_32_1  unique_nonzero_owner_376  1
    service_1_32_1  service_visit_def_1278  1
    service_1_32_1  free_load_conservation_1279  1
    service_1_32_2  unique_nonzero_owner_377  1
    service_1_32_2  service_visit_def_1278  1
    service_1_32_2  free_load_conservation_1279  2
    service_1_32_3  unique_nonzero_owner_378  1
    service_1_32_3  service_visit_def_1278  1
    service_1_32_3  free_load_conservation_1279  3
    service_1_32_4  unique_nonzero_owner_379  1
    service_1_32_4  service_visit_def_1278  1
    service_1_32_4  free_load_conservation_1279  4
    service_1_32_5  unique_nonzero_owner_380  1
    service_1_32_5  service_visit_def_1278  1
    service_1_32_5  free_load_conservation_1279  5
    service_1_32_6  unique_nonzero_owner_381  1
    service_1_32_6  service_visit_def_1278  1
    service_1_32_6  free_load_conservation_1279  6
    service_1_32_7  unique_nonzero_owner_382  1
    service_1_32_7  service_visit_def_1278  1
    service_1_32_7  free_load_conservation_1279  7
    service_1_32_8  unique_nonzero_owner_383  1
    service_1_32_8  service_visit_def_1278  1
    service_1_32_8  free_load_conservation_1279  8
    service_1_32_9  unique_nonzero_owner_384  1
    service_1_32_9  service_visit_def_1278  1
    service_1_32_9  free_load_conservation_1279  9
    service_1_32_10  unique_nonzero_owner_385  1
    service_1_32_10  service_visit_def_1278  1
    service_1_32_10  free_load_conservation_1279  10
    service_1_32_11  unique_nonzero_owner_386  1
    service_1_32_11  service_visit_def_1278  1
    service_1_32_11  free_load_conservation_1279  11
    service_1_32_12  unique_nonzero_owner_387  1
    service_1_32_12  service_visit_def_1278  1
    service_1_32_12  free_load_conservation_1279  12
    service_2_32_1  unique_nonzero_owner_376  1
    service_2_32_1  service_visit_def_1649  1
    service_2_32_1  free_load_conservation_1650  1
    service_2_32_2  unique_nonzero_owner_377  1
    service_2_32_2  service_visit_def_1649  1
    service_2_32_2  free_load_conservation_1650  2
    service_2_32_3  unique_nonzero_owner_378  1
    service_2_32_3  service_visit_def_1649  1
    service_2_32_3  free_load_conservation_1650  3
    service_2_32_4  unique_nonzero_owner_379  1
    service_2_32_4  service_visit_def_1649  1
    service_2_32_4  free_load_conservation_1650  4
    service_2_32_5  unique_nonzero_owner_380  1
    service_2_32_5  service_visit_def_1649  1
    service_2_32_5  free_load_conservation_1650  5
    service_2_32_6  unique_nonzero_owner_381  1
    service_2_32_6  service_visit_def_1649  1
    service_2_32_6  free_load_conservation_1650  6
    service_2_32_7  unique_nonzero_owner_382  1
    service_2_32_7  service_visit_def_1649  1
    service_2_32_7  free_load_conservation_1650  7
    service_2_32_8  unique_nonzero_owner_383  1
    service_2_32_8  service_visit_def_1649  1
    service_2_32_8  free_load_conservation_1650  8
    service_2_32_9  unique_nonzero_owner_384  1
    service_2_32_9  service_visit_def_1649  1
    service_2_32_9  free_load_conservation_1650  9
    service_2_32_10  unique_nonzero_owner_385  1
    service_2_32_10  service_visit_def_1649  1
    service_2_32_10  free_load_conservation_1650  10
    service_2_32_11  unique_nonzero_owner_386  1
    service_2_32_11  service_visit_def_1649  1
    service_2_32_11  free_load_conservation_1650  11
    service_2_32_12  unique_nonzero_owner_387  1
    service_2_32_12  service_visit_def_1649  1
    service_2_32_12  free_load_conservation_1650  12
    service_0_8_0  unique_nonzero_owner_388  1
    service_0_8_0  service_visit_def_911  1
    service_0_8_0  free_load_conservation_912  -15
    service_0_8_0  original_T_including_depot_unload_930  1800
    service_0_8_1  unique_nonzero_owner_389  1
    service_0_8_1  service_visit_def_911  1
    service_0_8_1  free_load_conservation_912  -14
    service_0_8_1  original_T_including_depot_unload_930  1680
    service_0_8_2  unique_nonzero_owner_390  1
    service_0_8_2  service_visit_def_911  1
    service_0_8_2  free_load_conservation_912  -13
    service_0_8_2  original_T_including_depot_unload_930  1560
    service_0_8_3  unique_nonzero_owner_391  1
    service_0_8_3  service_visit_def_911  1
    service_0_8_3  free_load_conservation_912  -12
    service_0_8_3  original_T_including_depot_unload_930  1440
    service_0_8_4  unique_nonzero_owner_392  1
    service_0_8_4  service_visit_def_911  1
    service_0_8_4  free_load_conservation_912  -11
    service_0_8_4  original_T_including_depot_unload_930  1320
    service_0_8_5  unique_nonzero_owner_393  1
    service_0_8_5  service_visit_def_911  1
    service_0_8_5  free_load_conservation_912  -10
    service_0_8_5  original_T_including_depot_unload_930  1200
    service_0_8_6  unique_nonzero_owner_394  1
    service_0_8_6  service_visit_def_911  1
    service_0_8_6  free_load_conservation_912  -9
    service_0_8_6  original_T_including_depot_unload_930  1080
    service_0_8_7  unique_nonzero_owner_395  1
    service_0_8_7  service_visit_def_911  1
    service_0_8_7  free_load_conservation_912  -8
    service_0_8_7  original_T_including_depot_unload_930  960
    service_0_8_8  unique_nonzero_owner_396  1
    service_0_8_8  service_visit_def_911  1
    service_0_8_8  free_load_conservation_912  -7
    service_0_8_8  original_T_including_depot_unload_930  840
    service_0_8_9  unique_nonzero_owner_397  1
    service_0_8_9  service_visit_def_911  1
    service_0_8_9  free_load_conservation_912  -6
    service_0_8_9  original_T_including_depot_unload_930  720
    service_0_8_10  unique_nonzero_owner_398  1
    service_0_8_10  service_visit_def_911  1
    service_0_8_10  free_load_conservation_912  -5
    service_0_8_10  original_T_including_depot_unload_930  600
    service_0_8_11  unique_nonzero_owner_399  1
    service_0_8_11  service_visit_def_911  1
    service_0_8_11  free_load_conservation_912  -4
    service_0_8_11  original_T_including_depot_unload_930  480
    service_0_8_12  unique_nonzero_owner_400  1
    service_0_8_12  service_visit_def_911  1
    service_0_8_12  free_load_conservation_912  -3
    service_0_8_12  original_T_including_depot_unload_930  360
    service_0_8_13  unique_nonzero_owner_401  1
    service_0_8_13  service_visit_def_911  1
    service_0_8_13  free_load_conservation_912  -2
    service_0_8_13  original_T_including_depot_unload_930  240
    service_0_8_14  unique_nonzero_owner_402  1
    service_0_8_14  service_visit_def_911  1
    service_0_8_14  free_load_conservation_912  -1
    service_0_8_14  original_T_including_depot_unload_930  120
    service_0_8_16  unique_nonzero_owner_403  1
    service_0_8_16  service_visit_def_911  1
    service_0_8_16  free_load_conservation_912  1
    service_0_8_17  unique_nonzero_owner_404  1
    service_0_8_17  service_visit_def_911  1
    service_0_8_17  free_load_conservation_912  2
    service_0_8_18  unique_nonzero_owner_405  1
    service_0_8_18  service_visit_def_911  1
    service_0_8_18  free_load_conservation_912  3
    service_0_8_19  unique_nonzero_owner_406  1
    service_0_8_19  service_visit_def_911  1
    service_0_8_19  free_load_conservation_912  4
    service_0_8_20  unique_nonzero_owner_407  1
    service_0_8_20  service_visit_def_911  1
    service_0_8_20  free_load_conservation_912  5
    service_0_8_21  unique_nonzero_owner_408  1
    service_0_8_21  service_visit_def_911  1
    service_0_8_21  free_load_conservation_912  6
    service_1_8_0  unique_nonzero_owner_388  1
    service_1_8_0  service_visit_def_1284  1
    service_1_8_0  free_load_conservation_1285  -15
    service_1_8_0  original_T_including_depot_unload_1301  1800
    service_1_8_1  unique_nonzero_owner_389  1
    service_1_8_1  service_visit_def_1284  1
    service_1_8_1  free_load_conservation_1285  -14
    service_1_8_1  original_T_including_depot_unload_1301  1680
    service_1_8_2  unique_nonzero_owner_390  1
    service_1_8_2  service_visit_def_1284  1
    service_1_8_2  free_load_conservation_1285  -13
    service_1_8_2  original_T_including_depot_unload_1301  1560
    service_1_8_3  unique_nonzero_owner_391  1
    service_1_8_3  service_visit_def_1284  1
    service_1_8_3  free_load_conservation_1285  -12
    service_1_8_3  original_T_including_depot_unload_1301  1440
    service_1_8_4  unique_nonzero_owner_392  1
    service_1_8_4  service_visit_def_1284  1
    service_1_8_4  free_load_conservation_1285  -11
    service_1_8_4  original_T_including_depot_unload_1301  1320
    service_1_8_5  unique_nonzero_owner_393  1
    service_1_8_5  service_visit_def_1284  1
    service_1_8_5  free_load_conservation_1285  -10
    service_1_8_5  original_T_including_depot_unload_1301  1200
    service_1_8_6  unique_nonzero_owner_394  1
    service_1_8_6  service_visit_def_1284  1
    service_1_8_6  free_load_conservation_1285  -9
    service_1_8_6  original_T_including_depot_unload_1301  1080
    service_1_8_7  unique_nonzero_owner_395  1
    service_1_8_7  service_visit_def_1284  1
    service_1_8_7  free_load_conservation_1285  -8
    service_1_8_7  original_T_including_depot_unload_1301  960
    service_1_8_8  unique_nonzero_owner_396  1
    service_1_8_8  service_visit_def_1284  1
    service_1_8_8  free_load_conservation_1285  -7
    service_1_8_8  original_T_including_depot_unload_1301  840
    service_1_8_9  unique_nonzero_owner_397  1
    service_1_8_9  service_visit_def_1284  1
    service_1_8_9  free_load_conservation_1285  -6
    service_1_8_9  original_T_including_depot_unload_1301  720
    service_1_8_10  unique_nonzero_owner_398  1
    service_1_8_10  service_visit_def_1284  1
    service_1_8_10  free_load_conservation_1285  -5
    service_1_8_10  original_T_including_depot_unload_1301  600
    service_1_8_11  unique_nonzero_owner_399  1
    service_1_8_11  service_visit_def_1284  1
    service_1_8_11  free_load_conservation_1285  -4
    service_1_8_11  original_T_including_depot_unload_1301  480
    service_1_8_12  unique_nonzero_owner_400  1
    service_1_8_12  service_visit_def_1284  1
    service_1_8_12  free_load_conservation_1285  -3
    service_1_8_12  original_T_including_depot_unload_1301  360
    service_1_8_13  unique_nonzero_owner_401  1
    service_1_8_13  service_visit_def_1284  1
    service_1_8_13  free_load_conservation_1285  -2
    service_1_8_13  original_T_including_depot_unload_1301  240
    service_1_8_14  unique_nonzero_owner_402  1
    service_1_8_14  service_visit_def_1284  1
    service_1_8_14  free_load_conservation_1285  -1
    service_1_8_14  original_T_including_depot_unload_1301  120
    service_1_8_16  unique_nonzero_owner_403  1
    service_1_8_16  service_visit_def_1284  1
    service_1_8_16  free_load_conservation_1285  1
    service_1_8_17  unique_nonzero_owner_404  1
    service_1_8_17  service_visit_def_1284  1
    service_1_8_17  free_load_conservation_1285  2
    service_1_8_18  unique_nonzero_owner_405  1
    service_1_8_18  service_visit_def_1284  1
    service_1_8_18  free_load_conservation_1285  3
    service_1_8_19  unique_nonzero_owner_406  1
    service_1_8_19  service_visit_def_1284  1
    service_1_8_19  free_load_conservation_1285  4
    service_1_8_20  unique_nonzero_owner_407  1
    service_1_8_20  service_visit_def_1284  1
    service_1_8_20  free_load_conservation_1285  5
    service_1_8_21  unique_nonzero_owner_408  1
    service_1_8_21  service_visit_def_1284  1
    service_1_8_21  free_load_conservation_1285  6
    service_2_8_0  unique_nonzero_owner_388  1
    service_2_8_0  service_visit_def_1655  1
    service_2_8_0  free_load_conservation_1656  -15
    service_2_8_0  original_T_including_depot_unload_1672  1800
    service_2_8_1  unique_nonzero_owner_389  1
    service_2_8_1  service_visit_def_1655  1
    service_2_8_1  free_load_conservation_1656  -14
    service_2_8_1  original_T_including_depot_unload_1672  1680
    service_2_8_2  unique_nonzero_owner_390  1
    service_2_8_2  service_visit_def_1655  1
    service_2_8_2  free_load_conservation_1656  -13
    service_2_8_2  original_T_including_depot_unload_1672  1560
    service_2_8_3  unique_nonzero_owner_391  1
    service_2_8_3  service_visit_def_1655  1
    service_2_8_3  free_load_conservation_1656  -12
    service_2_8_3  original_T_including_depot_unload_1672  1440
    service_2_8_4  unique_nonzero_owner_392  1
    service_2_8_4  service_visit_def_1655  1
    service_2_8_4  free_load_conservation_1656  -11
    service_2_8_4  original_T_including_depot_unload_1672  1320
    service_2_8_5  unique_nonzero_owner_393  1
    service_2_8_5  service_visit_def_1655  1
    service_2_8_5  free_load_conservation_1656  -10
    service_2_8_5  original_T_including_depot_unload_1672  1200
    service_2_8_6  unique_nonzero_owner_394  1
    service_2_8_6  service_visit_def_1655  1
    service_2_8_6  free_load_conservation_1656  -9
    service_2_8_6  original_T_including_depot_unload_1672  1080
    service_2_8_7  unique_nonzero_owner_395  1
    service_2_8_7  service_visit_def_1655  1
    service_2_8_7  free_load_conservation_1656  -8
    service_2_8_7  original_T_including_depot_unload_1672  960
    service_2_8_8  unique_nonzero_owner_396  1
    service_2_8_8  service_visit_def_1655  1
    service_2_8_8  free_load_conservation_1656  -7
    service_2_8_8  original_T_including_depot_unload_1672  840
    service_2_8_9  unique_nonzero_owner_397  1
    service_2_8_9  service_visit_def_1655  1
    service_2_8_9  free_load_conservation_1656  -6
    service_2_8_9  original_T_including_depot_unload_1672  720
    service_2_8_10  unique_nonzero_owner_398  1
    service_2_8_10  service_visit_def_1655  1
    service_2_8_10  free_load_conservation_1656  -5
    service_2_8_10  original_T_including_depot_unload_1672  600
    service_2_8_11  unique_nonzero_owner_399  1
    service_2_8_11  service_visit_def_1655  1
    service_2_8_11  free_load_conservation_1656  -4
    service_2_8_11  original_T_including_depot_unload_1672  480
    service_2_8_12  unique_nonzero_owner_400  1
    service_2_8_12  service_visit_def_1655  1
    service_2_8_12  free_load_conservation_1656  -3
    service_2_8_12  original_T_including_depot_unload_1672  360
    service_2_8_13  unique_nonzero_owner_401  1
    service_2_8_13  service_visit_def_1655  1
    service_2_8_13  free_load_conservation_1656  -2
    service_2_8_13  original_T_including_depot_unload_1672  240
    service_2_8_14  unique_nonzero_owner_402  1
    service_2_8_14  service_visit_def_1655  1
    service_2_8_14  free_load_conservation_1656  -1
    service_2_8_14  original_T_including_depot_unload_1672  120
    service_2_8_16  unique_nonzero_owner_403  1
    service_2_8_16  service_visit_def_1655  1
    service_2_8_16  free_load_conservation_1656  1
    service_2_8_17  unique_nonzero_owner_404  1
    service_2_8_17  service_visit_def_1655  1
    service_2_8_17  free_load_conservation_1656  2
    service_2_8_18  unique_nonzero_owner_405  1
    service_2_8_18  service_visit_def_1655  1
    service_2_8_18  free_load_conservation_1656  3
    service_2_8_19  unique_nonzero_owner_406  1
    service_2_8_19  service_visit_def_1655  1
    service_2_8_19  free_load_conservation_1656  4
    service_2_8_20  unique_nonzero_owner_407  1
    service_2_8_20  service_visit_def_1655  1
    service_2_8_20  free_load_conservation_1656  5
    service_2_8_21  unique_nonzero_owner_408  1
    service_2_8_21  service_visit_def_1655  1
    service_2_8_21  free_load_conservation_1656  6
    service_0_16_0  unique_nonzero_owner_409  1
    service_0_16_0  service_visit_def_917  1
    service_0_16_0  free_load_conservation_918  -1
    service_0_16_0  original_T_including_depot_unload_930  120
    service_0_16_2  unique_nonzero_owner_410  1
    service_0_16_2  service_visit_def_917  1
    service_0_16_2  free_load_conservation_918  1
    service_0_16_3  unique_nonzero_owner_411  1
    service_0_16_3  service_visit_def_917  1
    service_0_16_3  free_load_conservation_918  2
    service_0_16_4  unique_nonzero_owner_412  1
    service_0_16_4  service_visit_def_917  1
    service_0_16_4  free_load_conservation_918  3
    service_0_16_5  unique_nonzero_owner_413  1
    service_0_16_5  service_visit_def_917  1
    service_0_16_5  free_load_conservation_918  4
    service_0_16_6  unique_nonzero_owner_414  1
    service_0_16_6  service_visit_def_917  1
    service_0_16_6  free_load_conservation_918  5
    service_0_16_7  unique_nonzero_owner_415  1
    service_0_16_7  service_visit_def_917  1
    service_0_16_7  free_load_conservation_918  6
    service_0_16_8  unique_nonzero_owner_416  1
    service_0_16_8  service_visit_def_917  1
    service_0_16_8  free_load_conservation_918  7
    service_0_16_9  unique_nonzero_owner_417  1
    service_0_16_9  service_visit_def_917  1
    service_0_16_9  free_load_conservation_918  8
    service_0_16_10  unique_nonzero_owner_418  1
    service_0_16_10  service_visit_def_917  1
    service_0_16_10  free_load_conservation_918  9
    service_0_16_11  unique_nonzero_owner_419  1
    service_0_16_11  service_visit_def_917  1
    service_0_16_11  free_load_conservation_918  10
    service_0_16_12  unique_nonzero_owner_420  1
    service_0_16_12  service_visit_def_917  1
    service_0_16_12  free_load_conservation_918  11
    service_1_16_0  unique_nonzero_owner_409  1
    service_1_16_0  service_visit_def_1290  1
    service_1_16_0  free_load_conservation_1291  -1
    service_1_16_0  original_T_including_depot_unload_1301  120
    service_1_16_2  unique_nonzero_owner_410  1
    service_1_16_2  service_visit_def_1290  1
    service_1_16_2  free_load_conservation_1291  1
    service_1_16_3  unique_nonzero_owner_411  1
    service_1_16_3  service_visit_def_1290  1
    service_1_16_3  free_load_conservation_1291  2
    service_1_16_4  unique_nonzero_owner_412  1
    service_1_16_4  service_visit_def_1290  1
    service_1_16_4  free_load_conservation_1291  3
    service_1_16_5  unique_nonzero_owner_413  1
    service_1_16_5  service_visit_def_1290  1
    service_1_16_5  free_load_conservation_1291  4
    service_1_16_6  unique_nonzero_owner_414  1
    service_1_16_6  service_visit_def_1290  1
    service_1_16_6  free_load_conservation_1291  5
    service_1_16_7  unique_nonzero_owner_415  1
    service_1_16_7  service_visit_def_1290  1
    service_1_16_7  free_load_conservation_1291  6
    service_1_16_8  unique_nonzero_owner_416  1
    service_1_16_8  service_visit_def_1290  1
    service_1_16_8  free_load_conservation_1291  7
    service_1_16_9  unique_nonzero_owner_417  1
    service_1_16_9  service_visit_def_1290  1
    service_1_16_9  free_load_conservation_1291  8
    service_1_16_10  unique_nonzero_owner_418  1
    service_1_16_10  service_visit_def_1290  1
    service_1_16_10  free_load_conservation_1291  9
    service_1_16_11  unique_nonzero_owner_419  1
    service_1_16_11  service_visit_def_1290  1
    service_1_16_11  free_load_conservation_1291  10
    service_1_16_12  unique_nonzero_owner_420  1
    service_1_16_12  service_visit_def_1290  1
    service_1_16_12  free_load_conservation_1291  11
    service_2_16_0  unique_nonzero_owner_409  1
    service_2_16_0  service_visit_def_1661  1
    service_2_16_0  free_load_conservation_1662  -1
    service_2_16_0  original_T_including_depot_unload_1672  120
    service_2_16_2  unique_nonzero_owner_410  1
    service_2_16_2  service_visit_def_1661  1
    service_2_16_2  free_load_conservation_1662  1
    service_2_16_3  unique_nonzero_owner_411  1
    service_2_16_3  service_visit_def_1661  1
    service_2_16_3  free_load_conservation_1662  2
    service_2_16_4  unique_nonzero_owner_412  1
    service_2_16_4  service_visit_def_1661  1
    service_2_16_4  free_load_conservation_1662  3
    service_2_16_5  unique_nonzero_owner_413  1
    service_2_16_5  service_visit_def_1661  1
    service_2_16_5  free_load_conservation_1662  4
    service_2_16_6  unique_nonzero_owner_414  1
    service_2_16_6  service_visit_def_1661  1
    service_2_16_6  free_load_conservation_1662  5
    service_2_16_7  unique_nonzero_owner_415  1
    service_2_16_7  service_visit_def_1661  1
    service_2_16_7  free_load_conservation_1662  6
    service_2_16_8  unique_nonzero_owner_416  1
    service_2_16_8  service_visit_def_1661  1
    service_2_16_8  free_load_conservation_1662  7
    service_2_16_9  unique_nonzero_owner_417  1
    service_2_16_9  service_visit_def_1661  1
    service_2_16_9  free_load_conservation_1662  8
    service_2_16_10  unique_nonzero_owner_418  1
    service_2_16_10  service_visit_def_1661  1
    service_2_16_10  free_load_conservation_1662  9
    service_2_16_11  unique_nonzero_owner_419  1
    service_2_16_11  service_visit_def_1661  1
    service_2_16_11  free_load_conservation_1662  10
    service_2_16_12  unique_nonzero_owner_420  1
    service_2_16_12  service_visit_def_1661  1
    service_2_16_12  free_load_conservation_1662  11
    service_0_13_0  unique_nonzero_owner_421  1
    service_0_13_0  service_visit_def_923  1
    service_0_13_0  free_load_conservation_924  -13
    service_0_13_0  original_T_including_depot_unload_930  1560
    service_0_13_1  unique_nonzero_owner_422  1
    service_0_13_1  service_visit_def_923  1
    service_0_13_1  free_load_conservation_924  -12
    service_0_13_1  original_T_including_depot_unload_930  1440
    service_0_13_2  unique_nonzero_owner_423  1
    service_0_13_2  service_visit_def_923  1
    service_0_13_2  free_load_conservation_924  -11
    service_0_13_2  original_T_including_depot_unload_930  1320
    service_0_13_3  unique_nonzero_owner_424  1
    service_0_13_3  service_visit_def_923  1
    service_0_13_3  free_load_conservation_924  -10
    service_0_13_3  original_T_including_depot_unload_930  1200
    service_0_13_4  unique_nonzero_owner_425  1
    service_0_13_4  service_visit_def_923  1
    service_0_13_4  free_load_conservation_924  -9
    service_0_13_4  original_T_including_depot_unload_930  1080
    service_0_13_5  unique_nonzero_owner_426  1
    service_0_13_5  service_visit_def_923  1
    service_0_13_5  free_load_conservation_924  -8
    service_0_13_5  original_T_including_depot_unload_930  960
    service_0_13_6  unique_nonzero_owner_427  1
    service_0_13_6  service_visit_def_923  1
    service_0_13_6  free_load_conservation_924  -7
    service_0_13_6  original_T_including_depot_unload_930  840
    service_0_13_7  unique_nonzero_owner_428  1
    service_0_13_7  service_visit_def_923  1
    service_0_13_7  free_load_conservation_924  -6
    service_0_13_7  original_T_including_depot_unload_930  720
    service_0_13_8  unique_nonzero_owner_429  1
    service_0_13_8  service_visit_def_923  1
    service_0_13_8  free_load_conservation_924  -5
    service_0_13_8  original_T_including_depot_unload_930  600
    service_0_13_9  unique_nonzero_owner_430  1
    service_0_13_9  service_visit_def_923  1
    service_0_13_9  free_load_conservation_924  -4
    service_0_13_9  original_T_including_depot_unload_930  480
    service_0_13_10  unique_nonzero_owner_431  1
    service_0_13_10  service_visit_def_923  1
    service_0_13_10  free_load_conservation_924  -3
    service_0_13_10  original_T_including_depot_unload_930  360
    service_0_13_11  unique_nonzero_owner_432  1
    service_0_13_11  service_visit_def_923  1
    service_0_13_11  free_load_conservation_924  -2
    service_0_13_11  original_T_including_depot_unload_930  240
    service_0_13_12  unique_nonzero_owner_433  1
    service_0_13_12  service_visit_def_923  1
    service_0_13_12  free_load_conservation_924  -1
    service_0_13_12  original_T_including_depot_unload_930  120
    service_0_13_14  unique_nonzero_owner_434  1
    service_0_13_14  service_visit_def_923  1
    service_0_13_14  free_load_conservation_924  1
    service_0_13_15  unique_nonzero_owner_435  1
    service_0_13_15  service_visit_def_923  1
    service_0_13_15  free_load_conservation_924  2
    service_0_13_16  unique_nonzero_owner_436  1
    service_0_13_16  service_visit_def_923  1
    service_0_13_16  free_load_conservation_924  3
    service_0_13_17  unique_nonzero_owner_437  1
    service_0_13_17  service_visit_def_923  1
    service_0_13_17  free_load_conservation_924  4
    service_0_13_18  unique_nonzero_owner_438  1
    service_0_13_18  service_visit_def_923  1
    service_0_13_18  free_load_conservation_924  5
    service_0_13_19  unique_nonzero_owner_439  1
    service_0_13_19  service_visit_def_923  1
    service_0_13_19  free_load_conservation_924  6
    service_1_13_0  unique_nonzero_owner_421  1
    service_1_13_0  service_visit_def_1296  1
    service_1_13_0  free_load_conservation_1297  -13
    service_1_13_0  original_T_including_depot_unload_1301  1560
    service_1_13_1  unique_nonzero_owner_422  1
    service_1_13_1  service_visit_def_1296  1
    service_1_13_1  free_load_conservation_1297  -12
    service_1_13_1  original_T_including_depot_unload_1301  1440
    service_1_13_2  unique_nonzero_owner_423  1
    service_1_13_2  service_visit_def_1296  1
    service_1_13_2  free_load_conservation_1297  -11
    service_1_13_2  original_T_including_depot_unload_1301  1320
    service_1_13_3  unique_nonzero_owner_424  1
    service_1_13_3  service_visit_def_1296  1
    service_1_13_3  free_load_conservation_1297  -10
    service_1_13_3  original_T_including_depot_unload_1301  1200
    service_1_13_4  unique_nonzero_owner_425  1
    service_1_13_4  service_visit_def_1296  1
    service_1_13_4  free_load_conservation_1297  -9
    service_1_13_4  original_T_including_depot_unload_1301  1080
    service_1_13_5  unique_nonzero_owner_426  1
    service_1_13_5  service_visit_def_1296  1
    service_1_13_5  free_load_conservation_1297  -8
    service_1_13_5  original_T_including_depot_unload_1301  960
    service_1_13_6  unique_nonzero_owner_427  1
    service_1_13_6  service_visit_def_1296  1
    service_1_13_6  free_load_conservation_1297  -7
    service_1_13_6  original_T_including_depot_unload_1301  840
    service_1_13_7  unique_nonzero_owner_428  1
    service_1_13_7  service_visit_def_1296  1
    service_1_13_7  free_load_conservation_1297  -6
    service_1_13_7  original_T_including_depot_unload_1301  720
    service_1_13_8  unique_nonzero_owner_429  1
    service_1_13_8  service_visit_def_1296  1
    service_1_13_8  free_load_conservation_1297  -5
    service_1_13_8  original_T_including_depot_unload_1301  600
    service_1_13_9  unique_nonzero_owner_430  1
    service_1_13_9  service_visit_def_1296  1
    service_1_13_9  free_load_conservation_1297  -4
    service_1_13_9  original_T_including_depot_unload_1301  480
    service_1_13_10  unique_nonzero_owner_431  1
    service_1_13_10  service_visit_def_1296  1
    service_1_13_10  free_load_conservation_1297  -3
    service_1_13_10  original_T_including_depot_unload_1301  360
    service_1_13_11  unique_nonzero_owner_432  1
    service_1_13_11  service_visit_def_1296  1
    service_1_13_11  free_load_conservation_1297  -2
    service_1_13_11  original_T_including_depot_unload_1301  240
    service_1_13_12  unique_nonzero_owner_433  1
    service_1_13_12  service_visit_def_1296  1
    service_1_13_12  free_load_conservation_1297  -1
    service_1_13_12  original_T_including_depot_unload_1301  120
    service_1_13_14  unique_nonzero_owner_434  1
    service_1_13_14  service_visit_def_1296  1
    service_1_13_14  free_load_conservation_1297  1
    service_1_13_15  unique_nonzero_owner_435  1
    service_1_13_15  service_visit_def_1296  1
    service_1_13_15  free_load_conservation_1297  2
    service_1_13_16  unique_nonzero_owner_436  1
    service_1_13_16  service_visit_def_1296  1
    service_1_13_16  free_load_conservation_1297  3
    service_1_13_17  unique_nonzero_owner_437  1
    service_1_13_17  service_visit_def_1296  1
    service_1_13_17  free_load_conservation_1297  4
    service_1_13_18  unique_nonzero_owner_438  1
    service_1_13_18  service_visit_def_1296  1
    service_1_13_18  free_load_conservation_1297  5
    service_1_13_19  unique_nonzero_owner_439  1
    service_1_13_19  service_visit_def_1296  1
    service_1_13_19  free_load_conservation_1297  6
    service_2_13_0  unique_nonzero_owner_421  1
    service_2_13_0  service_visit_def_1667  1
    service_2_13_0  free_load_conservation_1668  -13
    service_2_13_0  original_T_including_depot_unload_1672  1560
    service_2_13_1  unique_nonzero_owner_422  1
    service_2_13_1  service_visit_def_1667  1
    service_2_13_1  free_load_conservation_1668  -12
    service_2_13_1  original_T_including_depot_unload_1672  1440
    service_2_13_2  unique_nonzero_owner_423  1
    service_2_13_2  service_visit_def_1667  1
    service_2_13_2  free_load_conservation_1668  -11
    service_2_13_2  original_T_including_depot_unload_1672  1320
    service_2_13_3  unique_nonzero_owner_424  1
    service_2_13_3  service_visit_def_1667  1
    service_2_13_3  free_load_conservation_1668  -10
    service_2_13_3  original_T_including_depot_unload_1672  1200
    service_2_13_4  unique_nonzero_owner_425  1
    service_2_13_4  service_visit_def_1667  1
    service_2_13_4  free_load_conservation_1668  -9
    service_2_13_4  original_T_including_depot_unload_1672  1080
    service_2_13_5  unique_nonzero_owner_426  1
    service_2_13_5  service_visit_def_1667  1
    service_2_13_5  free_load_conservation_1668  -8
    service_2_13_5  original_T_including_depot_unload_1672  960
    service_2_13_6  unique_nonzero_owner_427  1
    service_2_13_6  service_visit_def_1667  1
    service_2_13_6  free_load_conservation_1668  -7
    service_2_13_6  original_T_including_depot_unload_1672  840
    service_2_13_7  unique_nonzero_owner_428  1
    service_2_13_7  service_visit_def_1667  1
    service_2_13_7  free_load_conservation_1668  -6
    service_2_13_7  original_T_including_depot_unload_1672  720
    service_2_13_8  unique_nonzero_owner_429  1
    service_2_13_8  service_visit_def_1667  1
    service_2_13_8  free_load_conservation_1668  -5
    service_2_13_8  original_T_including_depot_unload_1672  600
    service_2_13_9  unique_nonzero_owner_430  1
    service_2_13_9  service_visit_def_1667  1
    service_2_13_9  free_load_conservation_1668  -4
    service_2_13_9  original_T_including_depot_unload_1672  480
    service_2_13_10  unique_nonzero_owner_431  1
    service_2_13_10  service_visit_def_1667  1
    service_2_13_10  free_load_conservation_1668  -3
    service_2_13_10  original_T_including_depot_unload_1672  360
    service_2_13_11  unique_nonzero_owner_432  1
    service_2_13_11  service_visit_def_1667  1
    service_2_13_11  free_load_conservation_1668  -2
    service_2_13_11  original_T_including_depot_unload_1672  240
    service_2_13_12  unique_nonzero_owner_433  1
    service_2_13_12  service_visit_def_1667  1
    service_2_13_12  free_load_conservation_1668  -1
    service_2_13_12  original_T_including_depot_unload_1672  120
    service_2_13_14  unique_nonzero_owner_434  1
    service_2_13_14  service_visit_def_1667  1
    service_2_13_14  free_load_conservation_1668  1
    service_2_13_15  unique_nonzero_owner_435  1
    service_2_13_15  service_visit_def_1667  1
    service_2_13_15  free_load_conservation_1668  2
    service_2_13_16  unique_nonzero_owner_436  1
    service_2_13_16  service_visit_def_1667  1
    service_2_13_16  free_load_conservation_1668  3
    service_2_13_17  unique_nonzero_owner_437  1
    service_2_13_17  service_visit_def_1667  1
    service_2_13_17  free_load_conservation_1668  4
    service_2_13_18  unique_nonzero_owner_438  1
    service_2_13_18  service_visit_def_1667  1
    service_2_13_18  free_load_conservation_1668  5
    service_2_13_19  unique_nonzero_owner_439  1
    service_2_13_19  service_visit_def_1667  1
    service_2_13_19  free_load_conservation_1668  6
    MARKER    'MARKER'                 'INTEND'
    visit_0_1  out_degree_835  -1
    visit_0_1  in_degree_836  -1
    visit_0_1  order_active_lb_837  -1
    visit_0_1  order_active_ub_838  -14
    order_0_1  connected_order_arc_457  -1
    order_0_1  connected_order_arc_459  -1
    order_0_1  connected_order_arc_461  -1
    order_0_1  connected_order_arc_463  -1
    order_0_1  connected_order_arc_465  -1
    order_0_1  connected_order_arc_467  -1
    order_0_1  connected_order_arc_469  -1
    order_0_1  connected_order_arc_471  -1
    order_0_1  connected_order_arc_473  -1
    order_0_1  connected_order_arc_475  -1
    order_0_1  connected_order_arc_477  -1
    order_0_1  connected_order_arc_479  -1
    order_0_1  connected_order_arc_481  -1
    order_0_1  connected_order_arc_484  1
    order_0_1  connected_order_arc_511  1
    order_0_1  connected_order_arc_538  1
    order_0_1  connected_order_arc_565  1
    order_0_1  connected_order_arc_592  1
    order_0_1  connected_order_arc_619  1
    order_0_1  connected_order_arc_646  1
    order_0_1  connected_order_arc_673  1
    order_0_1  connected_order_arc_700  1
    order_0_1  connected_order_arc_727  1
    order_0_1  connected_order_arc_754  1
    order_0_1  connected_order_arc_781  1
    order_0_1  connected_order_arc_808  1
    order_0_1  order_active_lb_837  1
    order_0_1  order_active_ub_838  1
    order_0_1  fixed_segment_relative_order_925  -1
    visit_0_2  out_degree_842  -1
    visit_0_2  in_degree_843  -1
    visit_0_2  order_active_lb_844  -1
    visit_0_2  order_active_ub_845  -14
    order_0_2  connected_order_arc_457  1
    order_0_2  connected_order_arc_484  -1
    order_0_2  connected_order_arc_486  -1
    order_0_2  connected_order_arc_488  -1
    order_0_2  connected_order_arc_490  -1
    order_0_2  connected_order_arc_492  -1
    order_0_2  connected_order_arc_494  -1
    order_0_2  connected_order_arc_496  -1
    order_0_2  connected_order_arc_498  -1
    order_0_2  connected_order_arc_500  -1
    order_0_2  connected_order_arc_502  -1
    order_0_2  connected_order_arc_504  -1
    order_0_2  connected_order_arc_506  -1
    order_0_2  connected_order_arc_508  -1
    order_0_2  connected_order_arc_513  1
    order_0_2  connected_order_arc_540  1
    order_0_2  connected_order_arc_567  1
    order_0_2  connected_order_arc_594  1
    order_0_2  connected_order_arc_621  1
    order_0_2  connected_order_arc_648  1
    order_0_2  connected_order_arc_675  1
    order_0_2  connected_order_arc_702  1
    order_0_2  connected_order_arc_729  1
    order_0_2  connected_order_arc_756  1
    order_0_2  connected_order_arc_783  1
    order_0_2  connected_order_arc_810  1
    order_0_2  order_active_lb_844  1
    order_0_2  order_active_ub_845  1
    order_0_2  fixed_segment_relative_order_925  1
    order_0_2  fixed_segment_relative_order_926  -1
    visit_0_3  out_degree_849  -1
    visit_0_3  in_degree_850  -1
    visit_0_3  order_active_lb_851  -1
    visit_0_3  order_active_ub_852  -14
    order_0_3  connected_order_arc_459  1
    order_0_3  connected_order_arc_486  1
    order_0_3  connected_order_arc_511  -1
    order_0_3  connected_order_arc_513  -1
    order_0_3  connected_order_arc_515  -1
    order_0_3  connected_order_arc_517  -1
    order_0_3  connected_order_arc_519  -1
    order_0_3  connected_order_arc_521  -1
    order_0_3  connected_order_arc_523  -1
    order_0_3  connected_order_arc_525  -1
    order_0_3  connected_order_arc_527  -1
    order_0_3  connected_order_arc_529  -1
    order_0_3  connected_order_arc_531  -1
    order_0_3  connected_order_arc_533  -1
    order_0_3  connected_order_arc_535  -1
    order_0_3  connected_order_arc_542  1
    order_0_3  connected_order_arc_569  1
    order_0_3  connected_order_arc_596  1
    order_0_3  connected_order_arc_623  1
    order_0_3  connected_order_arc_650  1
    order_0_3  connected_order_arc_677  1
    order_0_3  connected_order_arc_704  1
    order_0_3  connected_order_arc_731  1
    order_0_3  connected_order_arc_758  1
    order_0_3  connected_order_arc_785  1
    order_0_3  connected_order_arc_812  1
    order_0_3  order_active_lb_851  1
    order_0_3  order_active_ub_852  1
    order_0_3  fixed_segment_relative_order_926  1
    order_0_3  fixed_segment_relative_order_927  -1
    visit_0_4  out_degree_856  -1
    visit_0_4  in_degree_857  -1
    visit_0_4  order_active_lb_858  -1
    visit_0_4  order_active_ub_859  -14
    order_0_4  connected_order_arc_461  1
    order_0_4  connected_order_arc_488  1
    order_0_4  connected_order_arc_515  1
    order_0_4  connected_order_arc_538  -1
    order_0_4  connected_order_arc_540  -1
    order_0_4  connected_order_arc_542  -1
    order_0_4  connected_order_arc_544  -1
    order_0_4  connected_order_arc_546  -1
    order_0_4  connected_order_arc_548  -1
    order_0_4  connected_order_arc_550  -1
    order_0_4  connected_order_arc_552  -1
    order_0_4  connected_order_arc_554  -1
    order_0_4  connected_order_arc_556  -1
    order_0_4  connected_order_arc_558  -1
    order_0_4  connected_order_arc_560  -1
    order_0_4  connected_order_arc_562  -1
    order_0_4  connected_order_arc_571  1
    order_0_4  connected_order_arc_598  1
    order_0_4  connected_order_arc_625  1
    order_0_4  connected_order_arc_652  1
    order_0_4  connected_order_arc_679  1
    order_0_4  connected_order_arc_706  1
    order_0_4  connected_order_arc_733  1
    order_0_4  connected_order_arc_760  1
    order_0_4  connected_order_arc_787  1
    order_0_4  connected_order_arc_814  1
    order_0_4  order_active_lb_858  1
    order_0_4  order_active_ub_859  1
    order_0_4  fixed_segment_relative_order_927  1
    order_0_4  fixed_segment_relative_order_928  -1
    visit_0_5  out_degree_863  -1
    visit_0_5  in_degree_864  -1
    visit_0_5  order_active_lb_865  -1
    visit_0_5  order_active_ub_866  -14
    order_0_5  connected_order_arc_463  1
    order_0_5  connected_order_arc_490  1
    order_0_5  connected_order_arc_517  1
    order_0_5  connected_order_arc_544  1
    order_0_5  connected_order_arc_565  -1
    order_0_5  connected_order_arc_567  -1
    order_0_5  connected_order_arc_569  -1
    order_0_5  connected_order_arc_571  -1
    order_0_5  connected_order_arc_573  -1
    order_0_5  connected_order_arc_575  -1
    order_0_5  connected_order_arc_577  -1
    order_0_5  connected_order_arc_579  -1
    order_0_5  connected_order_arc_581  -1
    order_0_5  connected_order_arc_583  -1
    order_0_5  connected_order_arc_585  -1
    order_0_5  connected_order_arc_587  -1
    order_0_5  connected_order_arc_589  -1
    order_0_5  connected_order_arc_600  1
    order_0_5  connected_order_arc_627  1
    order_0_5  connected_order_arc_654  1
    order_0_5  connected_order_arc_681  1
    order_0_5  connected_order_arc_708  1
    order_0_5  connected_order_arc_735  1
    order_0_5  connected_order_arc_762  1
    order_0_5  connected_order_arc_789  1
    order_0_5  connected_order_arc_816  1
    order_0_5  order_active_lb_865  1
    order_0_5  order_active_ub_866  1
    order_0_5  fixed_segment_relative_order_928  1
    order_0_5  fixed_segment_relative_order_929  -1
    visit_0_6  out_degree_870  -1
    visit_0_6  in_degree_871  -1
    visit_0_6  order_active_lb_872  -1
    visit_0_6  order_active_ub_873  -14
    order_0_6  connected_order_arc_465  1
    order_0_6  connected_order_arc_492  1
    order_0_6  connected_order_arc_519  1
    order_0_6  connected_order_arc_546  1
    order_0_6  connected_order_arc_573  1
    order_0_6  connected_order_arc_592  -1
    order_0_6  connected_order_arc_594  -1
    order_0_6  connected_order_arc_596  -1
    order_0_6  connected_order_arc_598  -1
    order_0_6  connected_order_arc_600  -1
    order_0_6  connected_order_arc_602  -1
    order_0_6  connected_order_arc_604  -1
    order_0_6  connected_order_arc_606  -1
    order_0_6  connected_order_arc_608  -1
    order_0_6  connected_order_arc_610  -1
    order_0_6  connected_order_arc_612  -1
    order_0_6  connected_order_arc_614  -1
    order_0_6  connected_order_arc_616  -1
    order_0_6  connected_order_arc_629  1
    order_0_6  connected_order_arc_656  1
    order_0_6  connected_order_arc_683  1
    order_0_6  connected_order_arc_710  1
    order_0_6  connected_order_arc_737  1
    order_0_6  connected_order_arc_764  1
    order_0_6  connected_order_arc_791  1
    order_0_6  connected_order_arc_818  1
    order_0_6  order_active_lb_872  1
    order_0_6  order_active_ub_873  1
    order_0_6  fixed_segment_relative_order_929  1
    visit_0_15  out_degree_877  -1
    visit_0_15  in_degree_878  -1
    visit_0_15  order_active_lb_879  -1
    visit_0_15  order_active_ub_880  -14
    visit_0_15  service_visit_def_881  -1
    order_0_15  connected_order_arc_467  1
    order_0_15  connected_order_arc_494  1
    order_0_15  connected_order_arc_521  1
    order_0_15  connected_order_arc_548  1
    order_0_15  connected_order_arc_575  1
    order_0_15  connected_order_arc_602  1
    order_0_15  connected_order_arc_619  -1
    order_0_15  connected_order_arc_621  -1
    order_0_15  connected_order_arc_623  -1
    order_0_15  connected_order_arc_625  -1
    order_0_15  connected_order_arc_627  -1
    order_0_15  connected_order_arc_629  -1
    order_0_15  connected_order_arc_631  -1
    order_0_15  connected_order_arc_633  -1
    order_0_15  connected_order_arc_635  -1
    order_0_15  connected_order_arc_637  -1
    order_0_15  connected_order_arc_639  -1
    order_0_15  connected_order_arc_641  -1
    order_0_15  connected_order_arc_643  -1
    order_0_15  connected_order_arc_658  1
    order_0_15  connected_order_arc_685  1
    order_0_15  connected_order_arc_712  1
    order_0_15  connected_order_arc_739  1
    order_0_15  connected_order_arc_766  1
    order_0_15  connected_order_arc_793  1
    order_0_15  connected_order_arc_820  1
    order_0_15  order_active_lb_879  1
    order_0_15  order_active_ub_880  1
    visit_0_16  out_degree_883  -1
    visit_0_16  in_degree_884  -1
    visit_0_16  order_active_lb_885  -1
    visit_0_16  order_active_ub_886  -14
    visit_0_16  service_visit_def_887  -1
    order_0_16  connected_order_arc_469  1
    order_0_16  connected_order_arc_496  1
    order_0_16  connected_order_arc_523  1
    order_0_16  connected_order_arc_550  1
    order_0_16  connected_order_arc_577  1
    order_0_16  connected_order_arc_604  1
    order_0_16  connected_order_arc_631  1
    order_0_16  connected_order_arc_646  -1
    order_0_16  connected_order_arc_648  -1
    order_0_16  connected_order_arc_650  -1
    order_0_16  connected_order_arc_652  -1
    order_0_16  connected_order_arc_654  -1
    order_0_16  connected_order_arc_656  -1
    order_0_16  connected_order_arc_658  -1
    order_0_16  connected_order_arc_660  -1
    order_0_16  connected_order_arc_662  -1
    order_0_16  connected_order_arc_664  -1
    order_0_16  connected_order_arc_666  -1
    order_0_16  connected_order_arc_668  -1
    order_0_16  connected_order_arc_670  -1
    order_0_16  connected_order_arc_687  1
    order_0_16  connected_order_arc_714  1
    order_0_16  connected_order_arc_741  1
    order_0_16  connected_order_arc_768  1
    order_0_16  connected_order_arc_795  1
    order_0_16  connected_order_arc_822  1
    order_0_16  order_active_lb_885  1
    order_0_16  order_active_ub_886  1
    visit_0_17  out_degree_889  -1
    visit_0_17  in_degree_890  -1
    visit_0_17  order_active_lb_891  -1
    visit_0_17  order_active_ub_892  -14
    visit_0_17  service_visit_def_893  -1
    order_0_17  connected_order_arc_471  1
    order_0_17  connected_order_arc_498  1
    order_0_17  connected_order_arc_525  1
    order_0_17  connected_order_arc_552  1
    order_0_17  connected_order_arc_579  1
    order_0_17  connected_order_arc_606  1
    order_0_17  connected_order_arc_633  1
    order_0_17  connected_order_arc_660  1
    order_0_17  connected_order_arc_673  -1
    order_0_17  connected_order_arc_675  -1
    order_0_17  connected_order_arc_677  -1
    order_0_17  connected_order_arc_679  -1
    order_0_17  connected_order_arc_681  -1
    order_0_17  connected_order_arc_683  -1
    order_0_17  connected_order_arc_685  -1
    order_0_17  connected_order_arc_687  -1
    order_0_17  connected_order_arc_689  -1
    order_0_17  connected_order_arc_691  -1
    order_0_17  connected_order_arc_693  -1
    order_0_17  connected_order_arc_695  -1
    order_0_17  connected_order_arc_697  -1
    order_0_17  connected_order_arc_716  1
    order_0_17  connected_order_arc_743  1
    order_0_17  connected_order_arc_770  1
    order_0_17  connected_order_arc_797  1
    order_0_17  connected_order_arc_824  1
    order_0_17  order_active_lb_891  1
    order_0_17  order_active_ub_892  1
    visit_0_18  out_degree_895  -1
    visit_0_18  in_degree_896  -1
    visit_0_18  order_active_lb_897  -1
    visit_0_18  order_active_ub_898  -14
    visit_0_18  service_visit_def_899  -1
    order_0_18  connected_order_arc_473  1
    order_0_18  connected_order_arc_500  1
    order_0_18  connected_order_arc_527  1
    order_0_18  connected_order_arc_554  1
    order_0_18  connected_order_arc_581  1
    order_0_18  connected_order_arc_608  1
    order_0_18  connected_order_arc_635  1
    order_0_18  connected_order_arc_662  1
    order_0_18  connected_order_arc_689  1
    order_0_18  connected_order_arc_700  -1
    order_0_18  connected_order_arc_702  -1
    order_0_18  connected_order_arc_704  -1
    order_0_18  connected_order_arc_706  -1
    order_0_18  connected_order_arc_708  -1
    order_0_18  connected_order_arc_710  -1
    order_0_18  connected_order_arc_712  -1
    order_0_18  connected_order_arc_714  -1
    order_0_18  connected_order_arc_716  -1
    order_0_18  connected_order_arc_718  -1
    order_0_18  connected_order_arc_720  -1
    order_0_18  connected_order_arc_722  -1
    order_0_18  connected_order_arc_724  -1
    order_0_18  connected_order_arc_745  1
    order_0_18  connected_order_arc_772  1
    order_0_18  connected_order_arc_799  1
    order_0_18  connected_order_arc_826  1
    order_0_18  order_active_lb_897  1
    order_0_18  order_active_ub_898  1
    visit_0_19  out_degree_901  -1
    visit_0_19  in_degree_902  -1
    visit_0_19  order_active_lb_903  -1
    visit_0_19  order_active_ub_904  -14
    visit_0_19  service_visit_def_905  -1
    order_0_19  connected_order_arc_475  1
    order_0_19  connected_order_arc_502  1
    order_0_19  connected_order_arc_529  1
    order_0_19  connected_order_arc_556  1
    order_0_19  connected_order_arc_583  1
    order_0_19  connected_order_arc_610  1
    order_0_19  connected_order_arc_637  1
    order_0_19  connected_order_arc_664  1
    order_0_19  connected_order_arc_691  1
    order_0_19  connected_order_arc_718  1
    order_0_19  connected_order_arc_727  -1
    order_0_19  connected_order_arc_729  -1
    order_0_19  connected_order_arc_731  -1
    order_0_19  connected_order_arc_733  -1
    order_0_19  connected_order_arc_735  -1
    order_0_19  connected_order_arc_737  -1
    order_0_19  connected_order_arc_739  -1
    order_0_19  connected_order_arc_741  -1
    order_0_19  connected_order_arc_743  -1
    order_0_19  connected_order_arc_745  -1
    order_0_19  connected_order_arc_747  -1
    order_0_19  connected_order_arc_749  -1
    order_0_19  connected_order_arc_751  -1
    order_0_19  connected_order_arc_774  1
    order_0_19  connected_order_arc_801  1
    order_0_19  connected_order_arc_828  1
    order_0_19  order_active_lb_903  1
    order_0_19  order_active_ub_904  1
    visit_0_20  out_degree_907  -1
    visit_0_20  in_degree_908  -1
    visit_0_20  order_active_lb_909  -1
    visit_0_20  order_active_ub_910  -14
    visit_0_20  service_visit_def_911  -1
    order_0_20  connected_order_arc_477  1
    order_0_20  connected_order_arc_504  1
    order_0_20  connected_order_arc_531  1
    order_0_20  connected_order_arc_558  1
    order_0_20  connected_order_arc_585  1
    order_0_20  connected_order_arc_612  1
    order_0_20  connected_order_arc_639  1
    order_0_20  connected_order_arc_666  1
    order_0_20  connected_order_arc_693  1
    order_0_20  connected_order_arc_720  1
    order_0_20  connected_order_arc_747  1
    order_0_20  connected_order_arc_754  -1
    order_0_20  connected_order_arc_756  -1
    order_0_20  connected_order_arc_758  -1
    order_0_20  connected_order_arc_760  -1
    order_0_20  connected_order_arc_762  -1
    order_0_20  connected_order_arc_764  -1
    order_0_20  connected_order_arc_766  -1
    order_0_20  connected_order_arc_768  -1
    order_0_20  connected_order_arc_770  -1
    order_0_20  connected_order_arc_772  -1
    order_0_20  connected_order_arc_774  -1
    order_0_20  connected_order_arc_776  -1
    order_0_20  connected_order_arc_778  -1
    order_0_20  connected_order_arc_803  1
    order_0_20  connected_order_arc_830  1
    order_0_20  order_active_lb_909  1
    order_0_20  order_active_ub_910  1
    visit_0_21  out_degree_913  -1
    visit_0_21  in_degree_914  -1
    visit_0_21  order_active_lb_915  -1
    visit_0_21  order_active_ub_916  -14
    visit_0_21  service_visit_def_917  -1
    order_0_21  connected_order_arc_479  1
    order_0_21  connected_order_arc_506  1
    order_0_21  connected_order_arc_533  1
    order_0_21  connected_order_arc_560  1
    order_0_21  connected_order_arc_587  1
    order_0_21  connected_order_arc_614  1
    order_0_21  connected_order_arc_641  1
    order_0_21  connected_order_arc_668  1
    order_0_21  connected_order_arc_695  1
    order_0_21  connected_order_arc_722  1
    order_0_21  connected_order_arc_749  1
    order_0_21  connected_order_arc_776  1
    order_0_21  connected_order_arc_781  -1
    order_0_21  connected_order_arc_783  -1
    order_0_21  connected_order_arc_785  -1
    order_0_21  connected_order_arc_787  -1
    order_0_21  connected_order_arc_789  -1
    order_0_21  connected_order_arc_791  -1
    order_0_21  connected_order_arc_793  -1
    order_0_21  connected_order_arc_795  -1
    order_0_21  connected_order_arc_797  -1
    order_0_21  connected_order_arc_799  -1
    order_0_21  connected_order_arc_801  -1
    order_0_21  connected_order_arc_803  -1
    order_0_21  connected_order_arc_805  -1
    order_0_21  connected_order_arc_832  1
    order_0_21  order_active_lb_915  1
    order_0_21  order_active_ub_916  1
    visit_0_22  out_degree_919  -1
    visit_0_22  in_degree_920  -1
    visit_0_22  order_active_lb_921  -1
    visit_0_22  order_active_ub_922  -14
    visit_0_22  service_visit_def_923  -1
    order_0_22  connected_order_arc_481  1
    order_0_22  connected_order_arc_508  1
    order_0_22  connected_order_arc_535  1
    order_0_22  connected_order_arc_562  1
    order_0_22  connected_order_arc_589  1
    order_0_22  connected_order_arc_616  1
    order_0_22  connected_order_arc_643  1
    order_0_22  connected_order_arc_670  1
    order_0_22  connected_order_arc_697  1
    order_0_22  connected_order_arc_724  1
    order_0_22  connected_order_arc_751  1
    order_0_22  connected_order_arc_778  1
    order_0_22  connected_order_arc_805  1
    order_0_22  connected_order_arc_808  -1
    order_0_22  connected_order_arc_810  -1
    order_0_22  connected_order_arc_812  -1
    order_0_22  connected_order_arc_814  -1
    order_0_22  connected_order_arc_816  -1
    order_0_22  connected_order_arc_818  -1
    order_0_22  connected_order_arc_820  -1
    order_0_22  connected_order_arc_822  -1
    order_0_22  connected_order_arc_824  -1
    order_0_22  connected_order_arc_826  -1
    order_0_22  connected_order_arc_828  -1
    order_0_22  connected_order_arc_830  -1
    order_0_22  connected_order_arc_832  -1
    order_0_22  order_active_lb_921  1
    order_0_22  order_active_ub_922  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_0  arc_capacity_440  -20
    arc_0_0_0  depot_departure_or_bypass_833  1
    arc_0_0_0  depot_return_or_bypass_834  1
    MARKER    'MARKER'                 'INTEND'
    load_0_0_0  arc_capacity_440  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_1  arc_capacity_441  -20
    arc_0_0_1  depot_departure_or_bypass_833  1
    arc_0_0_1  in_degree_836  1
    arc_0_0_1  original_T_including_depot_unload_930  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_1  arc_capacity_441  1
    load_0_0_1  segment_load_conservation_839  -1
    load_0_0_1  segment_prefix_lb_840  1
    load_0_0_1  segment_prefix_ub_841  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_2  arc_capacity_442  -20
    arc_0_0_2  depot_departure_or_bypass_833  1
    arc_0_0_2  in_degree_843  1
    arc_0_0_2  original_T_including_depot_unload_930  7.2130540230577469e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_2  arc_capacity_442  1
    load_0_0_2  segment_load_conservation_846  -1
    load_0_0_2  segment_prefix_lb_847  1
    load_0_0_2  segment_prefix_ub_848  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_3  arc_capacity_443  -20
    arc_0_0_3  depot_departure_or_bypass_833  1
    arc_0_0_3  in_degree_850  1
    arc_0_0_3  original_T_including_depot_unload_930  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_3  arc_capacity_443  1
    load_0_0_3  segment_load_conservation_853  -1
    load_0_0_3  segment_prefix_lb_854  1
    load_0_0_3  segment_prefix_ub_855  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_4  arc_capacity_444  -20
    arc_0_0_4  depot_departure_or_bypass_833  1
    arc_0_0_4  in_degree_857  1
    arc_0_0_4  original_T_including_depot_unload_930  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_4  arc_capacity_444  1
    load_0_0_4  segment_load_conservation_860  -1
    load_0_0_4  segment_prefix_lb_861  1
    load_0_0_4  segment_prefix_ub_862  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_5  arc_capacity_445  -20
    arc_0_0_5  depot_departure_or_bypass_833  1
    arc_0_0_5  in_degree_864  1
    arc_0_0_5  original_T_including_depot_unload_930  7.2571167924583824e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_5  arc_capacity_445  1
    load_0_0_5  segment_load_conservation_867  -1
    load_0_0_5  segment_prefix_lb_868  1
    load_0_0_5  segment_prefix_ub_869  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_6  arc_capacity_446  -20
    arc_0_0_6  depot_departure_or_bypass_833  1
    arc_0_0_6  in_degree_871  1
    arc_0_0_6  original_T_including_depot_unload_930  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_6  arc_capacity_446  1
    load_0_0_6  segment_load_conservation_874  -1
    load_0_0_6  segment_prefix_lb_875  1
    load_0_0_6  segment_prefix_ub_876  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_15  arc_capacity_447  -20
    arc_0_0_15  depot_departure_or_bypass_833  1
    arc_0_0_15  in_degree_878  1
    arc_0_0_15  original_T_including_depot_unload_930  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_15  arc_capacity_447  1
    load_0_0_15  free_load_conservation_882  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_16  arc_capacity_448  -20
    arc_0_0_16  depot_departure_or_bypass_833  1
    arc_0_0_16  in_degree_884  1
    arc_0_0_16  original_T_including_depot_unload_930  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_16  arc_capacity_448  1
    load_0_0_16  free_load_conservation_888  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_17  arc_capacity_449  -20
    arc_0_0_17  depot_departure_or_bypass_833  1
    arc_0_0_17  in_degree_890  1
    arc_0_0_17  original_T_including_depot_unload_930  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_17  arc_capacity_449  1
    load_0_0_17  free_load_conservation_894  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_18  arc_capacity_450  -20
    arc_0_0_18  depot_departure_or_bypass_833  1
    arc_0_0_18  in_degree_896  1
    arc_0_0_18  original_T_including_depot_unload_930  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_18  arc_capacity_450  1
    load_0_0_18  free_load_conservation_900  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_19  arc_capacity_451  -20
    arc_0_0_19  depot_departure_or_bypass_833  1
    arc_0_0_19  in_degree_902  1
    arc_0_0_19  original_T_including_depot_unload_930  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_19  arc_capacity_451  1
    load_0_0_19  free_load_conservation_906  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_20  arc_capacity_452  -20
    arc_0_0_20  depot_departure_or_bypass_833  1
    arc_0_0_20  in_degree_908  1
    arc_0_0_20  original_T_including_depot_unload_930  6.6653528395596720e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_20  arc_capacity_452  1
    load_0_0_20  free_load_conservation_912  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_21  arc_capacity_453  -20
    arc_0_0_21  depot_departure_or_bypass_833  1
    arc_0_0_21  in_degree_914  1
    arc_0_0_21  original_T_including_depot_unload_930  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_21  arc_capacity_453  1
    load_0_0_21  free_load_conservation_918  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_22  arc_capacity_454  -20
    arc_0_0_22  depot_departure_or_bypass_833  1
    arc_0_0_22  in_degree_920  1
    arc_0_0_22  original_T_including_depot_unload_930  5.9431738885389052e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_22  arc_capacity_454  1
    load_0_0_22  free_load_conservation_924  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_0  arc_capacity_455  -20
    arc_0_1_0  depot_return_or_bypass_834  1
    arc_0_1_0  out_degree_835  1
    arc_0_1_0  original_T_including_depot_unload_930  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_0  arc_capacity_455  1
    load_0_1_0  segment_load_conservation_839  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_2  arc_capacity_456  -20
    arc_0_1_2  connected_order_arc_457  -15
    arc_0_1_2  out_degree_835  1
    arc_0_1_2  in_degree_843  1
    arc_0_1_2  original_T_including_depot_unload_930  4.4733407106545638e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_2  arc_capacity_456  1
    load_0_1_2  segment_load_conservation_839  1
    load_0_1_2  segment_load_conservation_846  -1
    load_0_1_2  segment_prefix_lb_847  1
    load_0_1_2  segment_prefix_ub_848  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_3  arc_capacity_458  -20
    arc_0_1_3  connected_order_arc_459  -15
    arc_0_1_3  out_degree_835  1
    arc_0_1_3  in_degree_850  1
    arc_0_1_3  original_T_including_depot_unload_930  2.7078292664437623e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_3  arc_capacity_458  1
    load_0_1_3  segment_load_conservation_839  1
    load_0_1_3  segment_load_conservation_853  -1
    load_0_1_3  segment_prefix_lb_854  1
    load_0_1_3  segment_prefix_ub_855  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_4  arc_capacity_460  -20
    arc_0_1_4  connected_order_arc_461  -15
    arc_0_1_4  out_degree_835  1
    arc_0_1_4  in_degree_857  1
    arc_0_1_4  original_T_including_depot_unload_930  545.439458844012
    MARKER    'MARKER'                 'INTEND'
    load_0_1_4  arc_capacity_460  1
    load_0_1_4  segment_load_conservation_839  1
    load_0_1_4  segment_load_conservation_860  -1
    load_0_1_4  segment_prefix_lb_861  1
    load_0_1_4  segment_prefix_ub_862  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_5  arc_capacity_462  -20
    arc_0_1_5  connected_order_arc_463  -15
    arc_0_1_5  out_degree_835  1
    arc_0_1_5  in_degree_864  1
    arc_0_1_5  original_T_including_depot_unload_930  8.7876124407720954e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_5  arc_capacity_462  1
    load_0_1_5  segment_load_conservation_839  1
    load_0_1_5  segment_load_conservation_867  -1
    load_0_1_5  segment_prefix_lb_868  1
    load_0_1_5  segment_prefix_ub_869  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_6  arc_capacity_464  -20
    arc_0_1_6  connected_order_arc_465  -15
    arc_0_1_6  out_degree_835  1
    arc_0_1_6  in_degree_871  1
    arc_0_1_6  original_T_including_depot_unload_930  9.3905252655669165e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_6  arc_capacity_464  1
    load_0_1_6  segment_load_conservation_839  1
    load_0_1_6  segment_load_conservation_874  -1
    load_0_1_6  segment_prefix_lb_875  1
    load_0_1_6  segment_prefix_ub_876  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_15  arc_capacity_466  -20
    arc_0_1_15  connected_order_arc_467  -15
    arc_0_1_15  out_degree_835  1
    arc_0_1_15  in_degree_878  1
    arc_0_1_15  original_T_including_depot_unload_930  4.2733962838090457e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_15  arc_capacity_466  1
    load_0_1_15  segment_load_conservation_839  1
    load_0_1_15  free_load_conservation_882  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_16  arc_capacity_468  -20
    arc_0_1_16  connected_order_arc_469  -15
    arc_0_1_16  out_degree_835  1
    arc_0_1_16  in_degree_884  1
    arc_0_1_16  original_T_including_depot_unload_930  3.9758967496529505e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_16  arc_capacity_468  1
    load_0_1_16  segment_load_conservation_839  1
    load_0_1_16  free_load_conservation_888  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_17  arc_capacity_470  -20
    arc_0_1_17  connected_order_arc_471  -15
    arc_0_1_17  out_degree_835  1
    arc_0_1_17  in_degree_890  1
    arc_0_1_17  original_T_including_depot_unload_930  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_17  arc_capacity_470  1
    load_0_1_17  segment_load_conservation_839  1
    load_0_1_17  free_load_conservation_894  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_18  arc_capacity_472  -20
    arc_0_1_18  connected_order_arc_473  -15
    arc_0_1_18  out_degree_835  1
    arc_0_1_18  in_degree_896  1
    arc_0_1_18  original_T_including_depot_unload_930  4.3618991857210159e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_18  arc_capacity_472  1
    load_0_1_18  segment_load_conservation_839  1
    load_0_1_18  free_load_conservation_900  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_19  arc_capacity_474  -20
    arc_0_1_19  connected_order_arc_475  -15
    arc_0_1_19  out_degree_835  1
    arc_0_1_19  in_degree_902  1
    arc_0_1_19  original_T_including_depot_unload_930  1.5902582434549993e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_19  arc_capacity_474  1
    load_0_1_19  segment_load_conservation_839  1
    load_0_1_19  free_load_conservation_906  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_20  arc_capacity_476  -20
    arc_0_1_20  connected_order_arc_477  -15
    arc_0_1_20  out_degree_835  1
    arc_0_1_20  in_degree_908  1
    arc_0_1_20  original_T_including_depot_unload_930  628.141943094385
    MARKER    'MARKER'                 'INTEND'
    load_0_1_20  arc_capacity_476  1
    load_0_1_20  segment_load_conservation_839  1
    load_0_1_20  free_load_conservation_912  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_21  arc_capacity_478  -20
    arc_0_1_21  connected_order_arc_479  -15
    arc_0_1_21  out_degree_835  1
    arc_0_1_21  in_degree_914  1
    arc_0_1_21  original_T_including_depot_unload_930  4.5128490093732506e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_21  arc_capacity_478  1
    load_0_1_21  segment_load_conservation_839  1
    load_0_1_21  free_load_conservation_918  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_22  arc_capacity_480  -20
    arc_0_1_22  connected_order_arc_481  -15
    arc_0_1_22  out_degree_835  1
    arc_0_1_22  in_degree_920  1
    arc_0_1_22  original_T_including_depot_unload_930  6.9736186698570737e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_22  arc_capacity_480  1
    load_0_1_22  segment_load_conservation_839  1
    load_0_1_22  free_load_conservation_924  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_0  arc_capacity_482  -20
    arc_0_2_0  depot_return_or_bypass_834  1
    arc_0_2_0  out_degree_842  1
    arc_0_2_0  original_T_including_depot_unload_930  5.4249700630778887e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_0  arc_capacity_482  1
    load_0_2_0  segment_load_conservation_846  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_1  arc_capacity_483  -20
    arc_0_2_1  connected_order_arc_484  -15
    arc_0_2_1  in_degree_836  1
    arc_0_2_1  out_degree_842  1
    arc_0_2_1  original_T_including_depot_unload_930  2.8529311190414518e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_1  arc_capacity_483  1
    load_0_2_1  segment_load_conservation_839  -1
    load_0_2_1  segment_prefix_lb_840  1
    load_0_2_1  segment_prefix_ub_841  1
    load_0_2_1  segment_load_conservation_846  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_3  arc_capacity_485  -20
    arc_0_2_3  connected_order_arc_486  -15
    arc_0_2_3  out_degree_842  1
    arc_0_2_3  in_degree_850  1
    arc_0_2_3  original_T_including_depot_unload_930  1.7461252424213140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_3  arc_capacity_485  1
    load_0_2_3  segment_load_conservation_846  1
    load_0_2_3  segment_load_conservation_853  -1
    load_0_2_3  segment_prefix_lb_854  1
    load_0_2_3  segment_prefix_ub_855  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_4  arc_capacity_487  -20
    arc_0_2_4  connected_order_arc_488  -15
    arc_0_2_4  out_degree_842  1
    arc_0_2_4  in_degree_857  1
    arc_0_2_4  original_T_including_depot_unload_930  3.4289721135663990e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_4  arc_capacity_487  1
    load_0_2_4  segment_load_conservation_846  1
    load_0_2_4  segment_load_conservation_860  -1
    load_0_2_4  segment_prefix_lb_861  1
    load_0_2_4  segment_prefix_ub_862  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_5  arc_capacity_489  -20
    arc_0_2_5  connected_order_arc_490  -15
    arc_0_2_5  out_degree_842  1
    arc_0_2_5  in_degree_864  1
    arc_0_2_5  original_T_including_depot_unload_930  9.6620394708383776e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_5  arc_capacity_489  1
    load_0_2_5  segment_load_conservation_846  1
    load_0_2_5  segment_load_conservation_867  -1
    load_0_2_5  segment_prefix_lb_868  1
    load_0_2_5  segment_prefix_ub_869  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_6  arc_capacity_491  -20
    arc_0_2_6  connected_order_arc_492  -15
    arc_0_2_6  out_degree_842  1
    arc_0_2_6  in_degree_871  1
    arc_0_2_6  original_T_including_depot_unload_930  1.0838347754693179e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_6  arc_capacity_491  1
    load_0_2_6  segment_load_conservation_846  1
    load_0_2_6  segment_load_conservation_874  -1
    load_0_2_6  segment_prefix_lb_875  1
    load_0_2_6  segment_prefix_ub_876  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_15  arc_capacity_493  -20
    arc_0_2_15  connected_order_arc_494  -15
    arc_0_2_15  out_degree_842  1
    arc_0_2_15  in_degree_878  1
    arc_0_2_15  original_T_including_depot_unload_930  4.6789193623835109e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_15  arc_capacity_493  1
    load_0_2_15  segment_load_conservation_846  1
    load_0_2_15  free_load_conservation_882  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_16  arc_capacity_495  -20
    arc_0_2_16  connected_order_arc_496  -15
    arc_0_2_16  out_degree_842  1
    arc_0_2_16  in_degree_884  1
    arc_0_2_16  original_T_including_depot_unload_930  3.3800157717255917e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_16  arc_capacity_495  1
    load_0_2_16  segment_load_conservation_846  1
    load_0_2_16  free_load_conservation_888  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_17  arc_capacity_497  -20
    arc_0_2_17  connected_order_arc_498  -15
    arc_0_2_17  out_degree_842  1
    arc_0_2_17  in_degree_890  1
    arc_0_2_17  original_T_including_depot_unload_930  1.6231508478292610e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_17  arc_capacity_497  1
    load_0_2_17  segment_load_conservation_846  1
    load_0_2_17  free_load_conservation_894  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_18  arc_capacity_499  -20
    arc_0_2_18  connected_order_arc_500  -15
    arc_0_2_18  out_degree_842  1
    arc_0_2_18  in_degree_896  1
    arc_0_2_18  original_T_including_depot_unload_930  6.0309764600105484e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_18  arc_capacity_499  1
    load_0_2_18  segment_load_conservation_846  1
    load_0_2_18  free_load_conservation_900  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_19  arc_capacity_501  -20
    arc_0_2_19  connected_order_arc_502  -15
    arc_0_2_19  out_degree_842  1
    arc_0_2_19  in_degree_902  1
    arc_0_2_19  original_T_including_depot_unload_930  1.7249161387293191e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_19  arc_capacity_501  1
    load_0_2_19  segment_load_conservation_846  1
    load_0_2_19  free_load_conservation_906  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_20  arc_capacity_503  -20
    arc_0_2_20  connected_order_arc_504  -15
    arc_0_2_20  out_degree_842  1
    arc_0_2_20  in_degree_908  1
    arc_0_2_20  original_T_including_depot_unload_930  5.5739415765733247e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_20  arc_capacity_503  1
    load_0_2_20  segment_load_conservation_846  1
    load_0_2_20  free_load_conservation_912  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_21  arc_capacity_505  -20
    arc_0_2_21  connected_order_arc_506  -15
    arc_0_2_21  out_degree_842  1
    arc_0_2_21  in_degree_914  1
    arc_0_2_21  original_T_including_depot_unload_930  603.649383070884
    MARKER    'MARKER'                 'INTEND'
    load_0_2_21  arc_capacity_505  1
    load_0_2_21  segment_load_conservation_846  1
    load_0_2_21  free_load_conservation_918  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_22  arc_capacity_507  -20
    arc_0_2_22  connected_order_arc_508  -15
    arc_0_2_22  out_degree_842  1
    arc_0_2_22  in_degree_920  1
    arc_0_2_22  original_T_including_depot_unload_930  7.5688558078083690e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_22  arc_capacity_507  1
    load_0_2_22  segment_load_conservation_846  1
    load_0_2_22  free_load_conservation_924  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_0  arc_capacity_509  -20
    arc_0_3_0  depot_return_or_bypass_834  1
    arc_0_3_0  out_degree_849  1
    arc_0_3_0  original_T_including_depot_unload_930  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_0  arc_capacity_509  1
    load_0_3_0  segment_load_conservation_853  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_1  arc_capacity_510  -20
    arc_0_3_1  connected_order_arc_511  -15
    arc_0_3_1  in_degree_836  1
    arc_0_3_1  out_degree_849  1
    arc_0_3_1  original_T_including_depot_unload_930  2.7078292664437623e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_1  arc_capacity_510  1
    load_0_3_1  segment_load_conservation_839  -1
    load_0_3_1  segment_prefix_lb_840  1
    load_0_3_1  segment_prefix_ub_841  1
    load_0_3_1  segment_load_conservation_853  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_2  arc_capacity_512  -20
    arc_0_3_2  connected_order_arc_513  -15
    arc_0_3_2  in_degree_843  1
    arc_0_3_2  out_degree_849  1
    arc_0_3_2  original_T_including_depot_unload_930  4.9242827332511274e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_2  arc_capacity_512  1
    load_0_3_2  segment_load_conservation_846  -1
    load_0_3_2  segment_prefix_lb_847  1
    load_0_3_2  segment_prefix_ub_848  1
    load_0_3_2  segment_load_conservation_853  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_4  arc_capacity_514  -20
    arc_0_3_4  connected_order_arc_515  -15
    arc_0_3_4  out_degree_849  1
    arc_0_3_4  in_degree_857  1
    arc_0_3_4  original_T_including_depot_unload_930  2.7570828838654035e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_4  arc_capacity_514  1
    load_0_3_4  segment_load_conservation_853  1
    load_0_3_4  segment_load_conservation_860  -1
    load_0_3_4  segment_prefix_lb_861  1
    load_0_3_4  segment_prefix_ub_862  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_5  arc_capacity_516  -20
    arc_0_3_5  connected_order_arc_517  -15
    arc_0_3_5  out_degree_849  1
    arc_0_3_5  in_degree_864  1
    arc_0_3_5  original_T_including_depot_unload_930  7.9195606724980928e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_5  arc_capacity_516  1
    load_0_3_5  segment_load_conservation_853  1
    load_0_3_5  segment_load_conservation_867  -1
    load_0_3_5  segment_prefix_lb_868  1
    load_0_3_5  segment_prefix_ub_869  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_6  arc_capacity_518  -20
    arc_0_3_6  connected_order_arc_519  -15
    arc_0_3_6  out_degree_849  1
    arc_0_3_6  in_degree_871  1
    arc_0_3_6  original_T_including_depot_unload_930  9.1580557259044724e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_6  arc_capacity_518  1
    load_0_3_6  segment_load_conservation_853  1
    load_0_3_6  segment_load_conservation_874  -1
    load_0_3_6  segment_prefix_lb_875  1
    load_0_3_6  segment_prefix_ub_876  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_15  arc_capacity_520  -20
    arc_0_3_15  connected_order_arc_521  -15
    arc_0_3_15  out_degree_849  1
    arc_0_3_15  in_degree_878  1
    arc_0_3_15  original_T_including_depot_unload_930  2.9376641610717382e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_15  arc_capacity_520  1
    load_0_3_15  segment_load_conservation_853  1
    load_0_3_15  free_load_conservation_882  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_16  arc_capacity_522  -20
    arc_0_3_16  connected_order_arc_523  -15
    arc_0_3_16  out_degree_849  1
    arc_0_3_16  in_degree_884  1
    arc_0_3_16  original_T_including_depot_unload_930  1.7053268374267958e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_16  arc_capacity_522  1
    load_0_3_16  segment_load_conservation_853  1
    load_0_3_16  free_load_conservation_888  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_17  arc_capacity_524  -20
    arc_0_3_17  connected_order_arc_525  -15
    arc_0_3_17  out_degree_849  1
    arc_0_3_17  in_degree_890  1
    arc_0_3_17  original_T_including_depot_unload_930  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_17  arc_capacity_524  1
    load_0_3_17  segment_load_conservation_853  1
    load_0_3_17  free_load_conservation_894  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_18  arc_capacity_526  -20
    arc_0_3_18  connected_order_arc_527  -15
    arc_0_3_18  out_degree_849  1
    arc_0_3_18  in_degree_896  1
    arc_0_3_18  original_T_including_depot_unload_930  4.5094949828949649e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_18  arc_capacity_526  1
    load_0_3_18  segment_load_conservation_853  1
    load_0_3_18  free_load_conservation_900  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_19  arc_capacity_528  -20
    arc_0_3_19  connected_order_arc_529  -15
    arc_0_3_19  out_degree_849  1
    arc_0_3_19  in_degree_902  1
    arc_0_3_19  original_T_including_depot_unload_930  1.5530568652263394e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_19  arc_capacity_528  1
    load_0_3_19  segment_load_conservation_853  1
    load_0_3_19  free_load_conservation_906  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_20  arc_capacity_530  -20
    arc_0_3_20  connected_order_arc_531  -15
    arc_0_3_20  out_degree_849  1
    arc_0_3_20  in_degree_908  1
    arc_0_3_20  original_T_including_depot_unload_930  4.0284428834016438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_20  arc_capacity_530  1
    load_0_3_20  segment_load_conservation_853  1
    load_0_3_20  free_load_conservation_912  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_21  arc_capacity_532  -20
    arc_0_3_21  connected_order_arc_533  -15
    arc_0_3_21  out_degree_849  1
    arc_0_3_21  in_degree_914  1
    arc_0_3_21  original_T_including_depot_unload_930  6.8976718276177132e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_21  arc_capacity_532  1
    load_0_3_21  segment_load_conservation_853  1
    load_0_3_21  free_load_conservation_918  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_22  arc_capacity_534  -20
    arc_0_3_22  connected_order_arc_535  -15
    arc_0_3_22  out_degree_849  1
    arc_0_3_22  in_degree_920  1
    arc_0_3_22  original_T_including_depot_unload_930  5.8227353503177085e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_22  arc_capacity_534  1
    load_0_3_22  segment_load_conservation_853  1
    load_0_3_22  free_load_conservation_924  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_0  arc_capacity_536  -20
    arc_0_4_0  depot_return_or_bypass_834  1
    arc_0_4_0  out_degree_856  1
    arc_0_4_0  original_T_including_depot_unload_930  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_0  arc_capacity_536  1
    load_0_4_0  segment_load_conservation_860  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_1  arc_capacity_537  -20
    arc_0_4_1  connected_order_arc_538  -15
    arc_0_4_1  in_degree_836  1
    arc_0_4_1  out_degree_856  1
    arc_0_4_1  original_T_including_depot_unload_930  545.439458844012
    MARKER    'MARKER'                 'INTEND'
    load_0_4_1  arc_capacity_537  1
    load_0_4_1  segment_load_conservation_839  -1
    load_0_4_1  segment_prefix_lb_840  1
    load_0_4_1  segment_prefix_ub_841  1
    load_0_4_1  segment_load_conservation_860  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_2  arc_capacity_539  -20
    arc_0_4_2  connected_order_arc_540  -15
    arc_0_4_2  in_degree_843  1
    arc_0_4_2  out_degree_856  1
    arc_0_4_2  original_T_including_depot_unload_930  6.3648699141452130e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_2  arc_capacity_539  1
    load_0_4_2  segment_load_conservation_846  -1
    load_0_4_2  segment_prefix_lb_847  1
    load_0_4_2  segment_prefix_ub_848  1
    load_0_4_2  segment_load_conservation_860  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_3  arc_capacity_541  -20
    arc_0_4_3  connected_order_arc_542  -15
    arc_0_4_3  in_degree_850  1
    arc_0_4_3  out_degree_856  1
    arc_0_4_3  original_T_including_depot_unload_930  2.7570828838654035e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_3  arc_capacity_541  1
    load_0_4_3  segment_load_conservation_853  -1
    load_0_4_3  segment_prefix_lb_854  1
    load_0_4_3  segment_prefix_ub_855  1
    load_0_4_3  segment_load_conservation_860  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_5  arc_capacity_543  -20
    arc_0_4_5  connected_order_arc_544  -15
    arc_0_4_5  out_degree_856  1
    arc_0_4_5  in_degree_864  1
    arc_0_4_5  original_T_including_depot_unload_930  8.2707974701454475e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_5  arc_capacity_543  1
    load_0_4_5  segment_load_conservation_860  1
    load_0_4_5  segment_load_conservation_867  -1
    load_0_4_5  segment_prefix_lb_868  1
    load_0_4_5  segment_prefix_ub_869  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_6  arc_capacity_545  -20
    arc_0_4_6  connected_order_arc_546  -15
    arc_0_4_6  out_degree_856  1
    arc_0_4_6  in_degree_871  1
    arc_0_4_6  original_T_including_depot_unload_930  1.0038065985492663e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_6  arc_capacity_545  1
    load_0_4_6  segment_load_conservation_860  1
    load_0_4_6  segment_load_conservation_874  -1
    load_0_4_6  segment_prefix_lb_875  1
    load_0_4_6  segment_prefix_ub_876  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_15  arc_capacity_547  -20
    arc_0_4_15  connected_order_arc_548  -15
    arc_0_4_15  out_degree_856  1
    arc_0_4_15  in_degree_878  1
    arc_0_4_15  original_T_including_depot_unload_930  3.9864800790786632e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_15  arc_capacity_547  1
    load_0_4_15  segment_load_conservation_860  1
    load_0_4_15  free_load_conservation_882  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_16  arc_capacity_549  -20
    arc_0_4_16  connected_order_arc_550  -15
    arc_0_4_16  out_degree_856  1
    arc_0_4_16  in_degree_884  1
    arc_0_4_16  original_T_including_depot_unload_930  2.4111148152767828e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_16  arc_capacity_549  1
    load_0_4_16  segment_load_conservation_860  1
    load_0_4_16  free_load_conservation_888  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_17  arc_capacity_551  -20
    arc_0_4_17  connected_order_arc_552  -15
    arc_0_4_17  out_degree_856  1
    arc_0_4_17  in_degree_890  1
    arc_0_4_17  original_T_including_depot_unload_930  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_17  arc_capacity_551  1
    load_0_4_17  segment_load_conservation_860  1
    load_0_4_17  free_load_conservation_894  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_18  arc_capacity_553  -20
    arc_0_4_18  connected_order_arc_554  -15
    arc_0_4_18  out_degree_856  1
    arc_0_4_18  in_degree_896  1
    arc_0_4_18  original_T_including_depot_unload_930  6.2886632383683013e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_18  arc_capacity_553  1
    load_0_4_18  segment_load_conservation_860  1
    load_0_4_18  free_load_conservation_900  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_19  arc_capacity_555  -20
    arc_0_4_19  connected_order_arc_556  -15
    arc_0_4_19  out_degree_856  1
    arc_0_4_19  in_degree_902  1
    arc_0_4_19  original_T_including_depot_unload_930  1.5968108380866881e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_19  arc_capacity_555  1
    load_0_4_19  segment_load_conservation_860  1
    load_0_4_19  free_load_conservation_906  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_20  arc_capacity_557  -20
    arc_0_4_20  connected_order_arc_558  -15
    arc_0_4_20  out_degree_856  1
    arc_0_4_20  in_degree_908  1
    arc_0_4_20  original_T_including_depot_unload_930  3.1069481377857926e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_20  arc_capacity_557  1
    load_0_4_20  segment_load_conservation_860  1
    load_0_4_20  free_load_conservation_912  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_21  arc_capacity_559  -20
    arc_0_4_21  connected_order_arc_560  -15
    arc_0_4_21  out_degree_856  1
    arc_0_4_21  in_degree_914  1
    arc_0_4_21  original_T_including_depot_unload_930  9.3962613467893414e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_21  arc_capacity_559  1
    load_0_4_21  segment_load_conservation_860  1
    load_0_4_21  free_load_conservation_918  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_22  arc_capacity_561  -20
    arc_0_4_22  connected_order_arc_562  -15
    arc_0_4_22  out_degree_856  1
    arc_0_4_22  in_degree_920  1
    arc_0_4_22  original_T_including_depot_unload_930  6.1561452832791758e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_22  arc_capacity_561  1
    load_0_4_22  segment_load_conservation_860  1
    load_0_4_22  free_load_conservation_924  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_0  arc_capacity_563  -20
    arc_0_5_0  depot_return_or_bypass_834  1
    arc_0_5_0  out_degree_863  1
    arc_0_5_0  original_T_including_depot_unload_930  7.2571167924583824e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_0  arc_capacity_563  1
    load_0_5_0  segment_load_conservation_867  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_1  arc_capacity_564  -20
    arc_0_5_1  connected_order_arc_565  -15
    arc_0_5_1  in_degree_836  1
    arc_0_5_1  out_degree_863  1
    arc_0_5_1  original_T_including_depot_unload_930  8.7876124407720954e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_1  arc_capacity_564  1
    load_0_5_1  segment_load_conservation_839  -1
    load_0_5_1  segment_prefix_lb_840  1
    load_0_5_1  segment_prefix_ub_841  1
    load_0_5_1  segment_load_conservation_867  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_2  arc_capacity_566  -20
    arc_0_5_2  connected_order_arc_567  -15
    arc_0_5_2  in_degree_843  1
    arc_0_5_2  out_degree_863  1
    arc_0_5_2  original_T_including_depot_unload_930  1.2724370432148053e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_2  arc_capacity_566  1
    load_0_5_2  segment_load_conservation_846  -1
    load_0_5_2  segment_prefix_lb_847  1
    load_0_5_2  segment_prefix_ub_848  1
    load_0_5_2  segment_load_conservation_867  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_3  arc_capacity_568  -20
    arc_0_5_3  connected_order_arc_569  -15
    arc_0_5_3  in_degree_850  1
    arc_0_5_3  out_degree_863  1
    arc_0_5_3  original_T_including_depot_unload_930  7.9195606724980928e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_3  arc_capacity_568  1
    load_0_5_3  segment_load_conservation_853  -1
    load_0_5_3  segment_prefix_lb_854  1
    load_0_5_3  segment_prefix_ub_855  1
    load_0_5_3  segment_load_conservation_867  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_4  arc_capacity_570  -20
    arc_0_5_4  connected_order_arc_571  -15
    arc_0_5_4  in_degree_857  1
    arc_0_5_4  out_degree_863  1
    arc_0_5_4  original_T_including_depot_unload_930  8.2707974701454475e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_4  arc_capacity_570  1
    load_0_5_4  segment_load_conservation_860  -1
    load_0_5_4  segment_prefix_lb_861  1
    load_0_5_4  segment_prefix_ub_862  1
    load_0_5_4  segment_load_conservation_867  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_6  arc_capacity_572  -20
    arc_0_5_6  connected_order_arc_573  -15
    arc_0_5_6  out_degree_863  1
    arc_0_5_6  in_degree_871  1
    arc_0_5_6  original_T_including_depot_unload_930  2.3059951477332697e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_6  arc_capacity_572  1
    load_0_5_6  segment_load_conservation_867  1
    load_0_5_6  segment_load_conservation_874  -1
    load_0_5_6  segment_prefix_lb_875  1
    load_0_5_6  segment_prefix_ub_876  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_15  arc_capacity_574  -20
    arc_0_5_15  connected_order_arc_575  -15
    arc_0_5_15  out_degree_863  1
    arc_0_5_15  in_degree_878  1
    arc_0_5_15  original_T_including_depot_unload_930  4.9831220386775891e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_15  arc_capacity_574  1
    load_0_5_15  segment_load_conservation_867  1
    load_0_5_15  free_load_conservation_882  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_16  arc_capacity_576  -20
    arc_0_5_16  connected_order_arc_577  -15
    arc_0_5_16  out_degree_863  1
    arc_0_5_16  in_degree_884  1
    arc_0_5_16  original_T_including_depot_unload_930  6.4542450829473034e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_16  arc_capacity_576  1
    load_0_5_16  segment_load_conservation_867  1
    load_0_5_16  free_load_conservation_888  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_17  arc_capacity_578  -20
    arc_0_5_17  connected_order_arc_579  -15
    arc_0_5_17  out_degree_863  1
    arc_0_5_17  in_degree_890  1
    arc_0_5_17  original_T_including_depot_unload_930  1.3163662834239574e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_17  arc_capacity_578  1
    load_0_5_17  segment_load_conservation_867  1
    load_0_5_17  free_load_conservation_894  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_18  arc_capacity_580  -20
    arc_0_5_18  connected_order_arc_581  -15
    arc_0_5_18  out_degree_863  1
    arc_0_5_18  in_degree_896  1
    arc_0_5_18  original_T_including_depot_unload_930  4.6276703023336785e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_18  arc_capacity_580  1
    load_0_5_18  segment_load_conservation_867  1
    load_0_5_18  free_load_conservation_900  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_19  arc_capacity_582  -20
    arc_0_5_19  connected_order_arc_583  -15
    arc_0_5_19  out_degree_863  1
    arc_0_5_19  in_degree_902  1
    arc_0_5_19  original_T_including_depot_unload_930  7.7190219995954919e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_19  arc_capacity_582  1
    load_0_5_19  segment_load_conservation_867  1
    load_0_5_19  free_load_conservation_906  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_20  arc_capacity_584  -20
    arc_0_5_20  connected_order_arc_585  -15
    arc_0_5_20  out_degree_863  1
    arc_0_5_20  in_degree_908  1
    arc_0_5_20  original_T_including_depot_unload_930  5.2996691306068044e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_20  arc_capacity_584  1
    load_0_5_20  segment_load_conservation_867  1
    load_0_5_20  free_load_conservation_912  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_21  arc_capacity_586  -20
    arc_0_5_21  connected_order_arc_587  -15
    arc_0_5_21  out_degree_863  1
    arc_0_5_21  in_degree_914  1
    arc_0_5_21  original_T_including_depot_unload_930  1.2968499029957554e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_21  arc_capacity_586  1
    load_0_5_21  segment_load_conservation_867  1
    load_0_5_21  free_load_conservation_918  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_22  arc_capacity_588  -20
    arc_0_5_22  connected_order_arc_589  -15
    arc_0_5_22  out_degree_863  1
    arc_0_5_22  in_degree_920  1
    arc_0_5_22  original_T_including_depot_unload_930  2.1481294511470344e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_22  arc_capacity_588  1
    load_0_5_22  segment_load_conservation_867  1
    load_0_5_22  free_load_conservation_924  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_0  arc_capacity_590  -20
    arc_0_6_0  depot_return_or_bypass_834  1
    arc_0_6_0  out_degree_870  1
    arc_0_6_0  original_T_including_depot_unload_930  4.6364706268001146e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_0  arc_capacity_590  1
    load_0_6_0  segment_load_conservation_874  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_1  arc_capacity_591  -20
    arc_0_6_1  connected_order_arc_592  -15
    arc_0_6_1  in_degree_836  1
    arc_0_6_1  out_degree_870  1
    arc_0_6_1  original_T_including_depot_unload_930  6.7517249538835438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_1  arc_capacity_591  1
    load_0_6_1  segment_load_conservation_839  -1
    load_0_6_1  segment_prefix_lb_840  1
    load_0_6_1  segment_prefix_ub_841  1
    load_0_6_1  segment_load_conservation_874  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_2  arc_capacity_593  -20
    arc_0_6_2  connected_order_arc_594  -15
    arc_0_6_2  in_degree_843  1
    arc_0_6_2  out_degree_870  1
    arc_0_6_2  original_T_including_depot_unload_930  1.1090437276384578e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_2  arc_capacity_593  1
    load_0_6_2  segment_load_conservation_846  -1
    load_0_6_2  segment_prefix_lb_847  1
    load_0_6_2  segment_prefix_ub_848  1
    load_0_6_2  segment_load_conservation_874  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_3  arc_capacity_595  -20
    arc_0_6_3  connected_order_arc_596  -15
    arc_0_6_3  in_degree_850  1
    arc_0_6_3  out_degree_870  1
    arc_0_6_3  original_T_including_depot_unload_930  6.7868877694996661e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_3  arc_capacity_595  1
    load_0_6_3  segment_load_conservation_853  -1
    load_0_6_3  segment_prefix_lb_854  1
    load_0_6_3  segment_prefix_ub_855  1
    load_0_6_3  segment_load_conservation_874  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_4  arc_capacity_597  -20
    arc_0_6_4  connected_order_arc_598  -15
    arc_0_6_4  in_degree_857  1
    arc_0_6_4  out_degree_870  1
    arc_0_6_4  original_T_including_depot_unload_930  8.1289340937717509e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_4  arc_capacity_597  1
    load_0_6_4  segment_load_conservation_860  -1
    load_0_6_4  segment_prefix_lb_861  1
    load_0_6_4  segment_prefix_ub_862  1
    load_0_6_4  segment_load_conservation_874  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_5  arc_capacity_599  -20
    arc_0_6_5  connected_order_arc_600  -15
    arc_0_6_5  in_degree_864  1
    arc_0_6_5  out_degree_870  1
    arc_0_6_5  original_T_including_depot_unload_930  3.0055050459786975e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_5  arc_capacity_599  1
    load_0_6_5  segment_load_conservation_867  -1
    load_0_6_5  segment_prefix_lb_868  1
    load_0_6_5  segment_prefix_ub_869  1
    load_0_6_5  segment_load_conservation_874  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_15  arc_capacity_601  -20
    arc_0_6_15  connected_order_arc_602  -15
    arc_0_6_15  out_degree_870  1
    arc_0_6_15  in_degree_878  1
    arc_0_6_15  original_T_including_depot_unload_930  4.1665889045115779e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_15  arc_capacity_601  1
    load_0_6_15  segment_load_conservation_874  1
    load_0_6_15  free_load_conservation_882  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_16  arc_capacity_603  -20
    arc_0_6_16  connected_order_arc_604  -15
    arc_0_6_16  out_degree_870  1
    arc_0_6_16  in_degree_884  1
    arc_0_6_16  original_T_including_depot_unload_930  5.8212369880329140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_16  arc_capacity_603  1
    load_0_6_16  segment_load_conservation_874  1
    load_0_6_16  free_load_conservation_888  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_17  arc_capacity_605  -20
    arc_0_6_17  connected_order_arc_606  -15
    arc_0_6_17  out_degree_870  1
    arc_0_6_17  in_degree_890  1
    arc_0_6_17  original_T_including_depot_unload_930  1075.72043838369
    MARKER    'MARKER'                 'INTEND'
    load_0_6_17  arc_capacity_605  1
    load_0_6_17  segment_load_conservation_874  1
    load_0_6_17  free_load_conservation_894  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_18  arc_capacity_607  -20
    arc_0_6_18  connected_order_arc_608  -15
    arc_0_6_18  out_degree_870  1
    arc_0_6_18  in_degree_896  1
    arc_0_6_18  original_T_including_depot_unload_930  2.4191291221621205e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_18  arc_capacity_607  1
    load_0_6_18  segment_load_conservation_874  1
    load_0_6_18  free_load_conservation_900  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_19  arc_capacity_609  -20
    arc_0_6_19  connected_order_arc_610  -15
    arc_0_6_19  out_degree_870  1
    arc_0_6_19  in_degree_902  1
    arc_0_6_19  original_T_including_depot_unload_930  9.1576870176747968e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_19  arc_capacity_609  1
    load_0_6_19  segment_load_conservation_874  1
    load_0_6_19  free_load_conservation_906  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_20  arc_capacity_611  -20
    arc_0_6_20  connected_order_arc_612  -15
    arc_0_6_20  out_degree_870  1
    arc_0_6_20  in_degree_908  1
    arc_0_6_20  original_T_including_depot_unload_930  5.8442598457899078e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_20  arc_capacity_611  1
    load_0_6_20  segment_load_conservation_874  1
    load_0_6_20  free_load_conservation_912  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_21  arc_capacity_613  -20
    arc_0_6_21  connected_order_arc_614  -15
    arc_0_6_21  out_degree_870  1
    arc_0_6_21  in_degree_914  1
    arc_0_6_21  original_T_including_depot_unload_930  1.0491196843462671e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_21  arc_capacity_613  1
    load_0_6_21  segment_load_conservation_874  1
    load_0_6_21  free_load_conservation_918  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_22  arc_capacity_615  -20
    arc_0_6_22  connected_order_arc_616  -15
    arc_0_6_22  out_degree_870  1
    arc_0_6_22  in_degree_920  1
    arc_0_6_22  original_T_including_depot_unload_930  2.9706418113632907e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_22  arc_capacity_615  1
    load_0_6_22  segment_load_conservation_874  1
    load_0_6_22  free_load_conservation_924  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_0  arc_capacity_617  -20
    arc_0_15_0  depot_return_or_bypass_834  1
    arc_0_15_0  out_degree_877  1
    arc_0_15_0  original_T_including_depot_unload_930  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_0  arc_capacity_617  1
    load_0_15_0  free_load_conservation_882  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_1  arc_capacity_618  -20
    arc_0_15_1  connected_order_arc_619  -15
    arc_0_15_1  in_degree_836  1
    arc_0_15_1  out_degree_877  1
    arc_0_15_1  original_T_including_depot_unload_930  4.2733962838090457e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_1  arc_capacity_618  1
    load_0_15_1  segment_load_conservation_839  -1
    load_0_15_1  segment_prefix_lb_840  1
    load_0_15_1  segment_prefix_ub_841  1
    load_0_15_1  free_load_conservation_882  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_2  arc_capacity_620  -20
    arc_0_15_2  connected_order_arc_621  -15
    arc_0_15_2  in_degree_843  1
    arc_0_15_2  out_degree_877  1
    arc_0_15_2  original_T_including_depot_unload_930  7.7772825846942942e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_2  arc_capacity_620  1
    load_0_15_2  segment_load_conservation_846  -1
    load_0_15_2  segment_prefix_lb_847  1
    load_0_15_2  segment_prefix_ub_848  1
    load_0_15_2  free_load_conservation_882  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_3  arc_capacity_622  -20
    arc_0_15_3  connected_order_arc_623  -15
    arc_0_15_3  in_degree_850  1
    arc_0_15_3  out_degree_877  1
    arc_0_15_3  original_T_including_depot_unload_930  2.9376641610717382e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_3  arc_capacity_622  1
    load_0_15_3  segment_load_conservation_853  -1
    load_0_15_3  segment_prefix_lb_854  1
    load_0_15_3  segment_prefix_ub_855  1
    load_0_15_3  free_load_conservation_882  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_4  arc_capacity_624  -20
    arc_0_15_4  connected_order_arc_625  -15
    arc_0_15_4  in_degree_857  1
    arc_0_15_4  out_degree_877  1
    arc_0_15_4  original_T_including_depot_unload_930  3.9864800790786632e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_4  arc_capacity_624  1
    load_0_15_4  segment_load_conservation_860  -1
    load_0_15_4  segment_prefix_lb_861  1
    load_0_15_4  segment_prefix_ub_862  1
    load_0_15_4  free_load_conservation_882  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_5  arc_capacity_626  -20
    arc_0_15_5  connected_order_arc_627  -15
    arc_0_15_5  in_degree_864  1
    arc_0_15_5  out_degree_877  1
    arc_0_15_5  original_T_including_depot_unload_930  4.9831220386775891e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_5  arc_capacity_626  1
    load_0_15_5  segment_load_conservation_867  -1
    load_0_15_5  segment_prefix_lb_868  1
    load_0_15_5  segment_prefix_ub_869  1
    load_0_15_5  free_load_conservation_882  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_6  arc_capacity_628  -20
    arc_0_15_6  connected_order_arc_629  -15
    arc_0_15_6  in_degree_871  1
    arc_0_15_6  out_degree_877  1
    arc_0_15_6  original_T_including_depot_unload_930  6.3111682574558915e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_6  arc_capacity_628  1
    load_0_15_6  segment_load_conservation_874  -1
    load_0_15_6  segment_prefix_lb_875  1
    load_0_15_6  segment_prefix_ub_876  1
    load_0_15_6  free_load_conservation_882  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_16  arc_capacity_630  -20
    arc_0_15_16  connected_order_arc_631  -15
    arc_0_15_16  out_degree_877  1
    arc_0_15_16  in_degree_884  1
    arc_0_15_16  original_T_including_depot_unload_930  1.6597164064313077e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_16  arc_capacity_630  1
    load_0_15_16  free_load_conservation_882  1
    load_0_15_16  free_load_conservation_888  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_17  arc_capacity_632  -20
    arc_0_15_17  connected_order_arc_633  -15
    arc_0_15_17  out_degree_877  1
    arc_0_15_17  in_degree_890  1
    arc_0_15_17  original_T_including_depot_unload_930  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_17  arc_capacity_632  1
    load_0_15_17  free_load_conservation_882  1
    load_0_15_17  free_load_conservation_894  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_18  arc_capacity_634  -20
    arc_0_15_18  connected_order_arc_635  -15
    arc_0_15_18  out_degree_877  1
    arc_0_15_18  in_degree_896  1
    arc_0_15_18  original_T_including_depot_unload_930  2.4083746437975364e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_18  arc_capacity_634  1
    load_0_15_18  free_load_conservation_882  1
    load_0_15_18  free_load_conservation_900  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_19  arc_capacity_636  -20
    arc_0_15_19  connected_order_arc_637  -15
    arc_0_15_19  out_degree_877  1
    arc_0_15_19  in_degree_902  1
    arc_0_15_19  original_T_including_depot_unload_930  1.2608612406747543e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_19  arc_capacity_636  1
    load_0_15_19  free_load_conservation_882  1
    load_0_15_19  free_load_conservation_906  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_20  arc_capacity_638  -20
    arc_0_15_20  connected_order_arc_639  -15
    arc_0_15_20  out_degree_877  1
    arc_0_15_20  in_degree_908  1
    arc_0_15_20  original_T_including_depot_unload_930  2.5147997402163108e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_20  arc_capacity_638  1
    load_0_15_20  free_load_conservation_882  1
    load_0_15_20  free_load_conservation_912  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_21  arc_capacity_640  -20
    arc_0_15_21  connected_order_arc_641  -15
    arc_0_15_21  out_degree_877  1
    arc_0_15_21  in_degree_914  1
    arc_0_15_21  original_T_including_depot_unload_930  8.7684829846426385e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_21  arc_capacity_640  1
    load_0_15_21  free_load_conservation_882  1
    load_0_15_21  free_load_conservation_918  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_22  arc_capacity_642  -20
    arc_0_15_22  connected_order_arc_643  -15
    arc_0_15_22  out_degree_877  1
    arc_0_15_22  in_degree_920  1
    arc_0_15_22  original_T_including_depot_unload_930  2.9098466309579254e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_22  arc_capacity_642  1
    load_0_15_22  free_load_conservation_882  1
    load_0_15_22  free_load_conservation_924  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_0  arc_capacity_644  -20
    arc_0_16_0  depot_return_or_bypass_834  1
    arc_0_16_0  out_degree_883  1
    arc_0_16_0  original_T_including_depot_unload_930  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_0  arc_capacity_644  1
    load_0_16_0  free_load_conservation_888  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_1  arc_capacity_645  -20
    arc_0_16_1  connected_order_arc_646  -15
    arc_0_16_1  in_degree_836  1
    arc_0_16_1  out_degree_883  1
    arc_0_16_1  original_T_including_depot_unload_930  3.9758967496529505e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_1  arc_capacity_645  1
    load_0_16_1  segment_load_conservation_839  -1
    load_0_16_1  segment_prefix_lb_840  1
    load_0_16_1  segment_prefix_ub_841  1
    load_0_16_1  free_load_conservation_888  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_2  arc_capacity_647  -20
    arc_0_16_2  connected_order_arc_648  -15
    arc_0_16_2  in_degree_843  1
    arc_0_16_2  out_degree_883  1
    arc_0_16_2  original_T_including_depot_unload_930  6.6047504008669523e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_2  arc_capacity_647  1
    load_0_16_2  segment_load_conservation_846  -1
    load_0_16_2  segment_prefix_lb_847  1
    load_0_16_2  segment_prefix_ub_848  1
    load_0_16_2  free_load_conservation_888  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_3  arc_capacity_649  -20
    arc_0_16_3  connected_order_arc_650  -15
    arc_0_16_3  in_degree_850  1
    arc_0_16_3  out_degree_883  1
    arc_0_16_3  original_T_including_depot_unload_930  1.7053268374267958e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_3  arc_capacity_649  1
    load_0_16_3  segment_load_conservation_853  -1
    load_0_16_3  segment_prefix_lb_854  1
    load_0_16_3  segment_prefix_ub_855  1
    load_0_16_3  free_load_conservation_888  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_4  arc_capacity_651  -20
    arc_0_16_4  connected_order_arc_652  -15
    arc_0_16_4  in_degree_857  1
    arc_0_16_4  out_degree_883  1
    arc_0_16_4  original_T_including_depot_unload_930  2.4111148152767828e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_4  arc_capacity_651  1
    load_0_16_4  segment_load_conservation_860  -1
    load_0_16_4  segment_prefix_lb_861  1
    load_0_16_4  segment_prefix_ub_862  1
    load_0_16_4  free_load_conservation_888  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_5  arc_capacity_653  -20
    arc_0_16_5  connected_order_arc_654  -15
    arc_0_16_5  in_degree_864  1
    arc_0_16_5  out_degree_883  1
    arc_0_16_5  original_T_including_depot_unload_930  6.4542450829473034e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_5  arc_capacity_653  1
    load_0_16_5  segment_load_conservation_867  -1
    load_0_16_5  segment_prefix_lb_868  1
    load_0_16_5  segment_prefix_ub_869  1
    load_0_16_5  free_load_conservation_888  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_6  arc_capacity_655  -20
    arc_0_16_6  connected_order_arc_656  -15
    arc_0_16_6  in_degree_871  1
    arc_0_16_6  out_degree_883  1
    arc_0_16_6  original_T_including_depot_unload_930  7.9403551275216375e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_6  arc_capacity_655  1
    load_0_16_6  segment_load_conservation_874  -1
    load_0_16_6  segment_prefix_lb_875  1
    load_0_16_6  segment_prefix_ub_876  1
    load_0_16_6  free_load_conservation_888  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_15  arc_capacity_657  -20
    arc_0_16_15  connected_order_arc_658  -15
    arc_0_16_15  in_degree_878  1
    arc_0_16_15  out_degree_883  1
    arc_0_16_15  original_T_including_depot_unload_930  1.6597164064313077e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_15  arc_capacity_657  1
    load_0_16_15  free_load_conservation_882  -1
    load_0_16_15  free_load_conservation_888  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_17  arc_capacity_659  -20
    arc_0_16_17  connected_order_arc_660  -15
    arc_0_16_17  out_degree_883  1
    arc_0_16_17  in_degree_890  1
    arc_0_16_17  original_T_including_depot_unload_930  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_17  arc_capacity_659  1
    load_0_16_17  free_load_conservation_888  1
    load_0_16_17  free_load_conservation_894  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_18  arc_capacity_661  -20
    arc_0_16_18  connected_order_arc_662  -15
    arc_0_16_18  out_degree_883  1
    arc_0_16_18  in_degree_896  1
    arc_0_16_18  original_T_including_depot_unload_930  3.8790073962518773e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_18  arc_capacity_661  1
    load_0_16_18  free_load_conservation_888  1
    load_0_16_18  free_load_conservation_900  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_19  arc_capacity_663  -20
    arc_0_16_19  connected_order_arc_664  -15
    arc_0_16_19  out_degree_883  1
    arc_0_16_19  in_degree_902  1
    arc_0_16_19  original_T_including_depot_unload_930  1.4150780419437449e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_19  arc_capacity_663  1
    load_0_16_19  free_load_conservation_888  1
    load_0_16_19  free_load_conservation_906  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_20  arc_capacity_665  -20
    arc_0_16_20  connected_order_arc_666  -15
    arc_0_16_20  out_degree_883  1
    arc_0_16_20  in_degree_908  1
    arc_0_16_20  original_T_including_depot_unload_930  2.3649901674897566e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_20  arc_capacity_665  1
    load_0_16_20  free_load_conservation_888  1
    load_0_16_20  free_load_conservation_912  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_21  arc_capacity_667  -20
    arc_0_16_21  connected_order_arc_668  -15
    arc_0_16_21  out_degree_883  1
    arc_0_16_21  in_degree_914  1
    arc_0_16_21  original_T_including_depot_unload_930  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_21  arc_capacity_667  1
    load_0_16_21  free_load_conservation_888  1
    load_0_16_21  free_load_conservation_918  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_22  arc_capacity_669  -20
    arc_0_16_22  connected_order_arc_670  -15
    arc_0_16_22  out_degree_883  1
    arc_0_16_22  in_degree_920  1
    arc_0_16_22  original_T_including_depot_unload_930  4.3129452098285111e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_22  arc_capacity_669  1
    load_0_16_22  free_load_conservation_888  1
    load_0_16_22  free_load_conservation_924  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_0  arc_capacity_671  -20
    arc_0_17_0  depot_return_or_bypass_834  1
    arc_0_17_0  out_degree_889  1
    arc_0_17_0  original_T_including_depot_unload_930  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_0  arc_capacity_671  1
    load_0_17_0  free_load_conservation_894  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_1  arc_capacity_672  -20
    arc_0_17_1  connected_order_arc_673  -15
    arc_0_17_1  in_degree_836  1
    arc_0_17_1  out_degree_889  1
    arc_0_17_1  original_T_including_depot_unload_930  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_1  arc_capacity_672  1
    load_0_17_1  segment_load_conservation_839  -1
    load_0_17_1  segment_prefix_lb_840  1
    load_0_17_1  segment_prefix_ub_841  1
    load_0_17_1  free_load_conservation_894  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_2  arc_capacity_674  -20
    arc_0_17_2  connected_order_arc_675  -15
    arc_0_17_2  in_degree_843  1
    arc_0_17_2  out_degree_889  1
    arc_0_17_2  original_T_including_depot_unload_930  1.7303231472353602e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_2  arc_capacity_674  1
    load_0_17_2  segment_load_conservation_846  -1
    load_0_17_2  segment_prefix_lb_847  1
    load_0_17_2  segment_prefix_ub_848  1
    load_0_17_2  free_load_conservation_894  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_3  arc_capacity_676  -20
    arc_0_17_3  connected_order_arc_677  -15
    arc_0_17_3  in_degree_850  1
    arc_0_17_3  out_degree_889  1
    arc_0_17_3  original_T_including_depot_unload_930  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_3  arc_capacity_676  1
    load_0_17_3  segment_load_conservation_853  -1
    load_0_17_3  segment_prefix_lb_854  1
    load_0_17_3  segment_prefix_ub_855  1
    load_0_17_3  free_load_conservation_894  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_4  arc_capacity_678  -20
    arc_0_17_4  connected_order_arc_679  -15
    arc_0_17_4  in_degree_857  1
    arc_0_17_4  out_degree_889  1
    arc_0_17_4  original_T_including_depot_unload_930  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_4  arc_capacity_678  1
    load_0_17_4  segment_load_conservation_860  -1
    load_0_17_4  segment_prefix_lb_861  1
    load_0_17_4  segment_prefix_ub_862  1
    load_0_17_4  free_load_conservation_894  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_5  arc_capacity_680  -20
    arc_0_17_5  connected_order_arc_681  -15
    arc_0_17_5  in_degree_864  1
    arc_0_17_5  out_degree_889  1
    arc_0_17_5  original_T_including_depot_unload_930  1.3163662834239574e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_5  arc_capacity_680  1
    load_0_17_5  segment_load_conservation_867  -1
    load_0_17_5  segment_prefix_lb_868  1
    load_0_17_5  segment_prefix_ub_869  1
    load_0_17_5  free_load_conservation_894  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_6  arc_capacity_682  -20
    arc_0_17_6  connected_order_arc_683  -15
    arc_0_17_6  in_degree_871  1
    arc_0_17_6  out_degree_889  1
    arc_0_17_6  original_T_including_depot_unload_930  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_6  arc_capacity_682  1
    load_0_17_6  segment_load_conservation_874  -1
    load_0_17_6  segment_prefix_lb_875  1
    load_0_17_6  segment_prefix_ub_876  1
    load_0_17_6  free_load_conservation_894  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_15  arc_capacity_684  -20
    arc_0_17_15  connected_order_arc_685  -15
    arc_0_17_15  in_degree_878  1
    arc_0_17_15  out_degree_889  1
    arc_0_17_15  original_T_including_depot_unload_930  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_15  arc_capacity_684  1
    load_0_17_15  free_load_conservation_882  -1
    load_0_17_15  free_load_conservation_894  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_16  arc_capacity_686  -20
    arc_0_17_16  connected_order_arc_687  -15
    arc_0_17_16  in_degree_884  1
    arc_0_17_16  out_degree_889  1
    arc_0_17_16  original_T_including_depot_unload_930  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_16  arc_capacity_686  1
    load_0_17_16  free_load_conservation_888  -1
    load_0_17_16  free_load_conservation_894  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_18  arc_capacity_688  -20
    arc_0_17_18  connected_order_arc_689  -15
    arc_0_17_18  out_degree_889  1
    arc_0_17_18  in_degree_896  1
    arc_0_17_18  original_T_including_depot_unload_930  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_18  arc_capacity_688  1
    load_0_17_18  free_load_conservation_894  1
    load_0_17_18  free_load_conservation_900  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_19  arc_capacity_690  -20
    arc_0_17_19  connected_order_arc_691  -15
    arc_0_17_19  out_degree_889  1
    arc_0_17_19  in_degree_902  1
    arc_0_17_19  original_T_including_depot_unload_930  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_19  arc_capacity_690  1
    load_0_17_19  free_load_conservation_894  1
    load_0_17_19  free_load_conservation_906  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_20  arc_capacity_692  -20
    arc_0_17_20  connected_order_arc_693  -15
    arc_0_17_20  out_degree_889  1
    arc_0_17_20  in_degree_908  1
    arc_0_17_20  original_T_including_depot_unload_930  1.6292966848558842e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_20  arc_capacity_692  1
    load_0_17_20  free_load_conservation_894  1
    load_0_17_20  free_load_conservation_912  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_21  arc_capacity_694  -20
    arc_0_17_21  connected_order_arc_695  -15
    arc_0_17_21  out_degree_889  1
    arc_0_17_21  in_degree_914  1
    arc_0_17_21  original_T_including_depot_unload_930  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_21  arc_capacity_694  1
    load_0_17_21  free_load_conservation_894  1
    load_0_17_21  free_load_conservation_918  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_22  arc_capacity_696  -20
    arc_0_17_22  connected_order_arc_697  -15
    arc_0_17_22  out_degree_889  1
    arc_0_17_22  in_degree_920  1
    arc_0_17_22  original_T_including_depot_unload_930  1.3727638439182763e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_22  arc_capacity_696  1
    load_0_17_22  free_load_conservation_894  1
    load_0_17_22  free_load_conservation_924  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_0  arc_capacity_698  -20
    arc_0_18_0  depot_return_or_bypass_834  1
    arc_0_18_0  out_degree_895  1
    arc_0_18_0  original_T_including_depot_unload_930  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_0  arc_capacity_698  1
    load_0_18_0  free_load_conservation_900  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_1  arc_capacity_699  -20
    arc_0_18_1  connected_order_arc_700  -15
    arc_0_18_1  in_degree_836  1
    arc_0_18_1  out_degree_895  1
    arc_0_18_1  original_T_including_depot_unload_930  4.3618991857210159e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_1  arc_capacity_699  1
    load_0_18_1  segment_load_conservation_839  -1
    load_0_18_1  segment_prefix_lb_840  1
    load_0_18_1  segment_prefix_ub_841  1
    load_0_18_1  free_load_conservation_900  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_2  arc_capacity_701  -20
    arc_0_18_2  connected_order_arc_702  -15
    arc_0_18_2  in_degree_843  1
    arc_0_18_2  out_degree_895  1
    arc_0_18_2  original_T_including_depot_unload_930  8.6713096341893186e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_2  arc_capacity_701  1
    load_0_18_2  segment_load_conservation_846  -1
    load_0_18_2  segment_prefix_lb_847  1
    load_0_18_2  segment_prefix_ub_848  1
    load_0_18_2  free_load_conservation_900  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_3  arc_capacity_703  -20
    arc_0_18_3  connected_order_arc_704  -15
    arc_0_18_3  in_degree_850  1
    arc_0_18_3  out_degree_895  1
    arc_0_18_3  original_T_including_depot_unload_930  4.5094949828949649e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_3  arc_capacity_703  1
    load_0_18_3  segment_load_conservation_853  -1
    load_0_18_3  segment_prefix_lb_854  1
    load_0_18_3  segment_prefix_ub_855  1
    load_0_18_3  free_load_conservation_900  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_4  arc_capacity_705  -20
    arc_0_18_4  connected_order_arc_706  -15
    arc_0_18_4  in_degree_857  1
    arc_0_18_4  out_degree_895  1
    arc_0_18_4  original_T_including_depot_unload_930  6.2886632383683013e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_4  arc_capacity_705  1
    load_0_18_4  segment_load_conservation_860  -1
    load_0_18_4  segment_prefix_lb_861  1
    load_0_18_4  segment_prefix_ub_862  1
    load_0_18_4  free_load_conservation_900  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_5  arc_capacity_707  -20
    arc_0_18_5  connected_order_arc_708  -15
    arc_0_18_5  in_degree_864  1
    arc_0_18_5  out_degree_895  1
    arc_0_18_5  original_T_including_depot_unload_930  4.6276703023336785e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_5  arc_capacity_707  1
    load_0_18_5  segment_load_conservation_867  -1
    load_0_18_5  segment_prefix_lb_868  1
    load_0_18_5  segment_prefix_ub_869  1
    load_0_18_5  free_load_conservation_900  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_6  arc_capacity_709  -20
    arc_0_18_6  connected_order_arc_710  -15
    arc_0_18_6  in_degree_871  1
    arc_0_18_6  out_degree_895  1
    arc_0_18_6  original_T_including_depot_unload_930  5.0315495126439691e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_6  arc_capacity_709  1
    load_0_18_6  segment_load_conservation_874  -1
    load_0_18_6  segment_prefix_lb_875  1
    load_0_18_6  segment_prefix_ub_876  1
    load_0_18_6  free_load_conservation_900  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_15  arc_capacity_711  -20
    arc_0_18_15  connected_order_arc_712  -15
    arc_0_18_15  in_degree_878  1
    arc_0_18_15  out_degree_895  1
    arc_0_18_15  original_T_including_depot_unload_930  2.4083746437975364e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_15  arc_capacity_711  1
    load_0_18_15  free_load_conservation_882  -1
    load_0_18_15  free_load_conservation_900  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_16  arc_capacity_713  -20
    arc_0_18_16  connected_order_arc_714  -15
    arc_0_18_16  in_degree_884  1
    arc_0_18_16  out_degree_895  1
    arc_0_18_16  original_T_including_depot_unload_930  3.8790073962518773e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_16  arc_capacity_713  1
    load_0_18_16  free_load_conservation_888  -1
    load_0_18_16  free_load_conservation_900  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_17  arc_capacity_715  -20
    arc_0_18_17  connected_order_arc_716  -15
    arc_0_18_17  in_degree_890  1
    arc_0_18_17  out_degree_895  1
    arc_0_18_17  original_T_including_depot_unload_930  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_17  arc_capacity_715  1
    load_0_18_17  free_load_conservation_894  -1
    load_0_18_17  free_load_conservation_900  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_19  arc_capacity_717  -20
    arc_0_18_19  connected_order_arc_718  -15
    arc_0_18_19  out_degree_895  1
    arc_0_18_19  in_degree_902  1
    arc_0_18_19  original_T_including_depot_unload_930  1.1544376314422677e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_19  arc_capacity_717  1
    load_0_18_19  free_load_conservation_900  1
    load_0_18_19  free_load_conservation_906  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_20  arc_capacity_719  -20
    arc_0_18_20  connected_order_arc_720  -15
    arc_0_18_20  out_degree_895  1
    arc_0_18_20  in_degree_908  1
    arc_0_18_20  original_T_including_depot_unload_930  4.7597588586788925e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_20  arc_capacity_719  1
    load_0_18_20  free_load_conservation_900  1
    load_0_18_20  free_load_conservation_912  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_21  arc_capacity_721  -20
    arc_0_18_21  connected_order_arc_722  -15
    arc_0_18_21  out_degree_895  1
    arc_0_18_21  in_degree_914  1
    arc_0_18_21  original_T_including_depot_unload_930  8.3486971116736720e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_21  arc_capacity_721  1
    load_0_18_21  free_load_conservation_900  1
    load_0_18_21  free_load_conservation_918  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_22  arc_capacity_723  -20
    arc_0_18_22  connected_order_arc_724  -15
    arc_0_18_22  out_degree_895  1
    arc_0_18_22  in_degree_920  1
    arc_0_18_22  original_T_including_depot_unload_930  3.2938591738444967e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_22  arc_capacity_723  1
    load_0_18_22  free_load_conservation_900  1
    load_0_18_22  free_load_conservation_924  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_0  arc_capacity_725  -20
    arc_0_19_0  depot_return_or_bypass_834  1
    arc_0_19_0  out_degree_901  1
    arc_0_19_0  original_T_including_depot_unload_930  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_0  arc_capacity_725  1
    load_0_19_0  free_load_conservation_906  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_1  arc_capacity_726  -20
    arc_0_19_1  connected_order_arc_727  -15
    arc_0_19_1  in_degree_836  1
    arc_0_19_1  out_degree_901  1
    arc_0_19_1  original_T_including_depot_unload_930  1.5902582434549993e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_1  arc_capacity_726  1
    load_0_19_1  segment_load_conservation_839  -1
    load_0_19_1  segment_prefix_lb_840  1
    load_0_19_1  segment_prefix_ub_841  1
    load_0_19_1  free_load_conservation_906  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_2  arc_capacity_728  -20
    arc_0_19_2  connected_order_arc_729  -15
    arc_0_19_2  in_degree_843  1
    arc_0_19_2  out_degree_901  1
    arc_0_19_2  original_T_including_depot_unload_930  2.0162129512771592e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_2  arc_capacity_728  1
    load_0_19_2  segment_load_conservation_846  -1
    load_0_19_2  segment_prefix_lb_847  1
    load_0_19_2  segment_prefix_ub_848  1
    load_0_19_2  free_load_conservation_906  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_3  arc_capacity_730  -20
    arc_0_19_3  connected_order_arc_731  -15
    arc_0_19_3  in_degree_850  1
    arc_0_19_3  out_degree_901  1
    arc_0_19_3  original_T_including_depot_unload_930  1.5530568652263394e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_3  arc_capacity_730  1
    load_0_19_3  segment_load_conservation_853  -1
    load_0_19_3  segment_prefix_lb_854  1
    load_0_19_3  segment_prefix_ub_855  1
    load_0_19_3  free_load_conservation_906  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_4  arc_capacity_732  -20
    arc_0_19_4  connected_order_arc_733  -15
    arc_0_19_4  in_degree_857  1
    arc_0_19_4  out_degree_901  1
    arc_0_19_4  original_T_including_depot_unload_930  1.5968108380866881e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_4  arc_capacity_732  1
    load_0_19_4  segment_load_conservation_860  -1
    load_0_19_4  segment_prefix_lb_861  1
    load_0_19_4  segment_prefix_ub_862  1
    load_0_19_4  free_load_conservation_906  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_5  arc_capacity_734  -20
    arc_0_19_5  connected_order_arc_735  -15
    arc_0_19_5  in_degree_864  1
    arc_0_19_5  out_degree_901  1
    arc_0_19_5  original_T_including_depot_unload_930  7.7190219995954919e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_5  arc_capacity_734  1
    load_0_19_5  segment_load_conservation_867  -1
    load_0_19_5  segment_prefix_lb_868  1
    load_0_19_5  segment_prefix_ub_869  1
    load_0_19_5  free_load_conservation_906  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_6  arc_capacity_736  -20
    arc_0_19_6  connected_order_arc_737  -15
    arc_0_19_6  in_degree_871  1
    arc_0_19_6  out_degree_901  1
    arc_0_19_6  original_T_including_depot_unload_930  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_6  arc_capacity_736  1
    load_0_19_6  segment_load_conservation_874  -1
    load_0_19_6  segment_prefix_lb_875  1
    load_0_19_6  segment_prefix_ub_876  1
    load_0_19_6  free_load_conservation_906  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_15  arc_capacity_738  -20
    arc_0_19_15  connected_order_arc_739  -15
    arc_0_19_15  in_degree_878  1
    arc_0_19_15  out_degree_901  1
    arc_0_19_15  original_T_including_depot_unload_930  1.2608612406747543e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_15  arc_capacity_738  1
    load_0_19_15  free_load_conservation_882  -1
    load_0_19_15  free_load_conservation_906  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_16  arc_capacity_740  -20
    arc_0_19_16  connected_order_arc_741  -15
    arc_0_19_16  in_degree_884  1
    arc_0_19_16  out_degree_901  1
    arc_0_19_16  original_T_including_depot_unload_930  1.4150780419437449e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_16  arc_capacity_740  1
    load_0_19_16  free_load_conservation_888  -1
    load_0_19_16  free_load_conservation_906  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_17  arc_capacity_742  -20
    arc_0_19_17  connected_order_arc_743  -15
    arc_0_19_17  in_degree_890  1
    arc_0_19_17  out_degree_901  1
    arc_0_19_17  original_T_including_depot_unload_930  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_17  arc_capacity_742  1
    load_0_19_17  free_load_conservation_894  -1
    load_0_19_17  free_load_conservation_906  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_18  arc_capacity_744  -20
    arc_0_19_18  connected_order_arc_745  -15
    arc_0_19_18  in_degree_896  1
    arc_0_19_18  out_degree_901  1
    arc_0_19_18  original_T_including_depot_unload_930  1.1544376314422677e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_18  arc_capacity_744  1
    load_0_19_18  free_load_conservation_900  -1
    load_0_19_18  free_load_conservation_906  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_20  arc_capacity_746  -20
    arc_0_19_20  connected_order_arc_747  -15
    arc_0_19_20  out_degree_901  1
    arc_0_19_20  in_degree_908  1
    arc_0_19_20  original_T_including_depot_unload_930  1.2927075446362680e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_20  arc_capacity_746  1
    load_0_19_20  free_load_conservation_906  1
    load_0_19_20  free_load_conservation_912  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_21  arc_capacity_748  -20
    arc_0_19_21  connected_order_arc_749  -15
    arc_0_19_21  out_degree_901  1
    arc_0_19_21  in_degree_914  1
    arc_0_19_21  original_T_including_depot_unload_930  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_21  arc_capacity_748  1
    load_0_19_21  free_load_conservation_906  1
    load_0_19_21  free_load_conservation_918  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_22  arc_capacity_750  -20
    arc_0_19_22  connected_order_arc_751  -15
    arc_0_19_22  out_degree_901  1
    arc_0_19_22  in_degree_920  1
    arc_0_19_22  original_T_including_depot_unload_930  9.8652191996938075e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_22  arc_capacity_750  1
    load_0_19_22  free_load_conservation_906  1
    load_0_19_22  free_load_conservation_924  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_0  arc_capacity_752  -20
    arc_0_20_0  depot_return_or_bypass_834  1
    arc_0_20_0  out_degree_907  1
    arc_0_20_0  original_T_including_depot_unload_930  6.6653528395596720e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_0  arc_capacity_752  1
    load_0_20_0  free_load_conservation_912  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_1  arc_capacity_753  -20
    arc_0_20_1  connected_order_arc_754  -15
    arc_0_20_1  in_degree_836  1
    arc_0_20_1  out_degree_907  1
    arc_0_20_1  original_T_including_depot_unload_930  628.141943094385
    MARKER    'MARKER'                 'INTEND'
    load_0_20_1  arc_capacity_753  1
    load_0_20_1  segment_load_conservation_839  -1
    load_0_20_1  segment_prefix_lb_840  1
    load_0_20_1  segment_prefix_ub_841  1
    load_0_20_1  free_load_conservation_912  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_2  arc_capacity_755  -20
    arc_0_20_2  connected_order_arc_756  -15
    arc_0_20_2  in_degree_843  1
    arc_0_20_2  out_degree_907  1
    arc_0_20_2  original_T_including_depot_unload_930  880.352897387315
    MARKER    'MARKER'                 'INTEND'
    load_0_20_2  arc_capacity_755  1
    load_0_20_2  segment_load_conservation_846  -1
    load_0_20_2  segment_prefix_lb_847  1
    load_0_20_2  segment_prefix_ub_848  1
    load_0_20_2  free_load_conservation_912  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_3  arc_capacity_757  -20
    arc_0_20_3  connected_order_arc_758  -15
    arc_0_20_3  in_degree_850  1
    arc_0_20_3  out_degree_907  1
    arc_0_20_3  original_T_including_depot_unload_930  4.0284428834016438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_3  arc_capacity_757  1
    load_0_20_3  segment_load_conservation_853  -1
    load_0_20_3  segment_prefix_lb_854  1
    load_0_20_3  segment_prefix_ub_855  1
    load_0_20_3  free_load_conservation_912  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_4  arc_capacity_759  -20
    arc_0_20_4  connected_order_arc_760  -15
    arc_0_20_4  in_degree_857  1
    arc_0_20_4  out_degree_907  1
    arc_0_20_4  original_T_including_depot_unload_930  3.1069481377857926e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_4  arc_capacity_759  1
    load_0_20_4  segment_load_conservation_860  -1
    load_0_20_4  segment_prefix_lb_861  1
    load_0_20_4  segment_prefix_ub_862  1
    load_0_20_4  free_load_conservation_912  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_5  arc_capacity_761  -20
    arc_0_20_5  connected_order_arc_762  -15
    arc_0_20_5  in_degree_864  1
    arc_0_20_5  out_degree_907  1
    arc_0_20_5  original_T_including_depot_unload_930  5.2996691306068044e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_5  arc_capacity_761  1
    load_0_20_5  segment_load_conservation_867  -1
    load_0_20_5  segment_prefix_lb_868  1
    load_0_20_5  segment_prefix_ub_869  1
    load_0_20_5  free_load_conservation_912  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_6  arc_capacity_763  -20
    arc_0_20_6  connected_order_arc_764  -15
    arc_0_20_6  in_degree_871  1
    arc_0_20_6  out_degree_907  1
    arc_0_20_6  original_T_including_depot_unload_930  7.2751050611121218e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_6  arc_capacity_763  1
    load_0_20_6  segment_load_conservation_874  -1
    load_0_20_6  segment_prefix_lb_875  1
    load_0_20_6  segment_prefix_ub_876  1
    load_0_20_6  free_load_conservation_912  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_15  arc_capacity_765  -20
    arc_0_20_15  connected_order_arc_766  -15
    arc_0_20_15  in_degree_878  1
    arc_0_20_15  out_degree_907  1
    arc_0_20_15  original_T_including_depot_unload_930  2.5147997402163108e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_15  arc_capacity_765  1
    load_0_20_15  free_load_conservation_882  -1
    load_0_20_15  free_load_conservation_912  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_16  arc_capacity_767  -20
    arc_0_20_16  connected_order_arc_768  -15
    arc_0_20_16  in_degree_884  1
    arc_0_20_16  out_degree_907  1
    arc_0_20_16  original_T_including_depot_unload_930  2.3649901674897566e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_16  arc_capacity_767  1
    load_0_20_16  free_load_conservation_888  -1
    load_0_20_16  free_load_conservation_912  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_17  arc_capacity_769  -20
    arc_0_20_17  connected_order_arc_770  -15
    arc_0_20_17  in_degree_890  1
    arc_0_20_17  out_degree_907  1
    arc_0_20_17  original_T_including_depot_unload_930  1.6292966848558842e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_17  arc_capacity_769  1
    load_0_20_17  free_load_conservation_894  -1
    load_0_20_17  free_load_conservation_912  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_18  arc_capacity_771  -20
    arc_0_20_18  connected_order_arc_772  -15
    arc_0_20_18  in_degree_896  1
    arc_0_20_18  out_degree_907  1
    arc_0_20_18  original_T_including_depot_unload_930  4.7597588586788925e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_18  arc_capacity_771  1
    load_0_20_18  free_load_conservation_900  -1
    load_0_20_18  free_load_conservation_912  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_19  arc_capacity_773  -20
    arc_0_20_19  connected_order_arc_774  -15
    arc_0_20_19  in_degree_902  1
    arc_0_20_19  out_degree_907  1
    arc_0_20_19  original_T_including_depot_unload_930  1.2927075446362680e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_19  arc_capacity_773  1
    load_0_20_19  free_load_conservation_906  -1
    load_0_20_19  free_load_conservation_912  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_21  arc_capacity_775  -20
    arc_0_20_21  connected_order_arc_776  -15
    arc_0_20_21  out_degree_907  1
    arc_0_20_21  in_degree_914  1
    arc_0_20_21  original_T_including_depot_unload_930  1.0758099325648966e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_21  arc_capacity_775  1
    load_0_20_21  free_load_conservation_912  1
    load_0_20_21  free_load_conservation_918  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_22  arc_capacity_777  -20
    arc_0_20_22  connected_order_arc_778  -15
    arc_0_20_22  out_degree_907  1
    arc_0_20_22  in_degree_920  1
    arc_0_20_22  original_T_including_depot_unload_930  3.2985327387120213e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_22  arc_capacity_777  1
    load_0_20_22  free_load_conservation_912  1
    load_0_20_22  free_load_conservation_924  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_0  arc_capacity_779  -20
    arc_0_21_0  depot_return_or_bypass_834  1
    arc_0_21_0  out_degree_913  1
    arc_0_21_0  original_T_including_depot_unload_930  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_0  arc_capacity_779  1
    load_0_21_0  free_load_conservation_918  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_1  arc_capacity_780  -20
    arc_0_21_1  connected_order_arc_781  -15
    arc_0_21_1  in_degree_836  1
    arc_0_21_1  out_degree_913  1
    arc_0_21_1  original_T_including_depot_unload_930  4.5128490093732506e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_1  arc_capacity_780  1
    load_0_21_1  segment_load_conservation_839  -1
    load_0_21_1  segment_prefix_lb_840  1
    load_0_21_1  segment_prefix_ub_841  1
    load_0_21_1  free_load_conservation_918  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_2  arc_capacity_782  -20
    arc_0_21_2  connected_order_arc_783  -15
    arc_0_21_2  in_degree_843  1
    arc_0_21_2  out_degree_913  1
    arc_0_21_2  original_T_including_depot_unload_930  4.6128219015626763e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_2  arc_capacity_782  1
    load_0_21_2  segment_load_conservation_846  -1
    load_0_21_2  segment_prefix_lb_847  1
    load_0_21_2  segment_prefix_ub_848  1
    load_0_21_2  free_load_conservation_918  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_3  arc_capacity_784  -20
    arc_0_21_3  connected_order_arc_785  -15
    arc_0_21_3  in_degree_850  1
    arc_0_21_3  out_degree_913  1
    arc_0_21_3  original_T_including_depot_unload_930  6.8976718276177132e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_3  arc_capacity_784  1
    load_0_21_3  segment_load_conservation_853  -1
    load_0_21_3  segment_prefix_lb_854  1
    load_0_21_3  segment_prefix_ub_855  1
    load_0_21_3  free_load_conservation_918  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_4  arc_capacity_786  -20
    arc_0_21_4  connected_order_arc_787  -15
    arc_0_21_4  in_degree_857  1
    arc_0_21_4  out_degree_913  1
    arc_0_21_4  original_T_including_depot_unload_930  9.3962613467893414e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_4  arc_capacity_786  1
    load_0_21_4  segment_load_conservation_860  -1
    load_0_21_4  segment_prefix_lb_861  1
    load_0_21_4  segment_prefix_ub_862  1
    load_0_21_4  free_load_conservation_918  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_5  arc_capacity_788  -20
    arc_0_21_5  connected_order_arc_789  -15
    arc_0_21_5  in_degree_864  1
    arc_0_21_5  out_degree_913  1
    arc_0_21_5  original_T_including_depot_unload_930  1.2968499029957554e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_5  arc_capacity_788  1
    load_0_21_5  segment_load_conservation_867  -1
    load_0_21_5  segment_prefix_lb_868  1
    load_0_21_5  segment_prefix_ub_869  1
    load_0_21_5  free_load_conservation_918  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_6  arc_capacity_790  -20
    arc_0_21_6  connected_order_arc_791  -15
    arc_0_21_6  in_degree_871  1
    arc_0_21_6  out_degree_913  1
    arc_0_21_6  original_T_including_depot_unload_930  1.3127274783157229e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_6  arc_capacity_790  1
    load_0_21_6  segment_load_conservation_874  -1
    load_0_21_6  segment_prefix_lb_875  1
    load_0_21_6  segment_prefix_ub_876  1
    load_0_21_6  free_load_conservation_918  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_15  arc_capacity_792  -20
    arc_0_21_15  connected_order_arc_793  -15
    arc_0_21_15  in_degree_878  1
    arc_0_21_15  out_degree_913  1
    arc_0_21_15  original_T_including_depot_unload_930  8.7684829846426385e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_15  arc_capacity_792  1
    load_0_21_15  free_load_conservation_882  -1
    load_0_21_15  free_load_conservation_918  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_16  arc_capacity_794  -20
    arc_0_21_16  connected_order_arc_795  -15
    arc_0_21_16  in_degree_884  1
    arc_0_21_16  out_degree_913  1
    arc_0_21_16  original_T_including_depot_unload_930  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_16  arc_capacity_794  1
    load_0_21_16  free_load_conservation_888  -1
    load_0_21_16  free_load_conservation_918  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_17  arc_capacity_796  -20
    arc_0_21_17  connected_order_arc_797  -15
    arc_0_21_17  in_degree_890  1
    arc_0_21_17  out_degree_913  1
    arc_0_21_17  original_T_including_depot_unload_930  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_17  arc_capacity_796  1
    load_0_21_17  free_load_conservation_894  -1
    load_0_21_17  free_load_conservation_918  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_18  arc_capacity_798  -20
    arc_0_21_18  connected_order_arc_799  -15
    arc_0_21_18  in_degree_896  1
    arc_0_21_18  out_degree_913  1
    arc_0_21_18  original_T_including_depot_unload_930  8.3486971116736720e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_18  arc_capacity_798  1
    load_0_21_18  free_load_conservation_900  -1
    load_0_21_18  free_load_conservation_918  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_19  arc_capacity_800  -20
    arc_0_21_19  connected_order_arc_801  -15
    arc_0_21_19  in_degree_902  1
    arc_0_21_19  out_degree_913  1
    arc_0_21_19  original_T_including_depot_unload_930  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_19  arc_capacity_800  1
    load_0_21_19  free_load_conservation_906  -1
    load_0_21_19  free_load_conservation_918  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_20  arc_capacity_802  -20
    arc_0_21_20  connected_order_arc_803  -15
    arc_0_21_20  in_degree_908  1
    arc_0_21_20  out_degree_913  1
    arc_0_21_20  original_T_including_depot_unload_930  1.0758099325648966e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_20  arc_capacity_802  1
    load_0_21_20  free_load_conservation_912  -1
    load_0_21_20  free_load_conservation_918  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_22  arc_capacity_804  -20
    arc_0_21_22  connected_order_arc_805  -15
    arc_0_21_22  out_degree_913  1
    arc_0_21_22  in_degree_920  1
    arc_0_21_22  original_T_including_depot_unload_930  1.1341050580477483e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_22  arc_capacity_804  1
    load_0_21_22  free_load_conservation_918  1
    load_0_21_22  free_load_conservation_924  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_0  arc_capacity_806  -20
    arc_0_22_0  depot_return_or_bypass_834  1
    arc_0_22_0  out_degree_919  1
    arc_0_22_0  original_T_including_depot_unload_930  5.9431738885389052e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_0  arc_capacity_806  1
    load_0_22_0  free_load_conservation_924  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_1  arc_capacity_807  -20
    arc_0_22_1  connected_order_arc_808  -15
    arc_0_22_1  in_degree_836  1
    arc_0_22_1  out_degree_919  1
    arc_0_22_1  original_T_including_depot_unload_930  6.9736186698570737e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_1  arc_capacity_807  1
    load_0_22_1  segment_load_conservation_839  -1
    load_0_22_1  segment_prefix_lb_840  1
    load_0_22_1  segment_prefix_ub_841  1
    load_0_22_1  free_load_conservation_924  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_2  arc_capacity_809  -20
    arc_0_22_2  connected_order_arc_810  -15
    arc_0_22_2  in_degree_843  1
    arc_0_22_2  out_degree_919  1
    arc_0_22_2  original_T_including_depot_unload_930  1.0687086794720833e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_22_2  arc_capacity_809  1
    load_0_22_2  segment_load_conservation_846  -1
    load_0_22_2  segment_prefix_lb_847  1
    load_0_22_2  segment_prefix_ub_848  1
    load_0_22_2  free_load_conservation_924  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_3  arc_capacity_811  -20
    arc_0_22_3  connected_order_arc_812  -15
    arc_0_22_3  in_degree_850  1
    arc_0_22_3  out_degree_919  1
    arc_0_22_3  original_T_including_depot_unload_930  5.8227353503177085e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_3  arc_capacity_811  1
    load_0_22_3  segment_load_conservation_853  -1
    load_0_22_3  segment_prefix_lb_854  1
    load_0_22_3  segment_prefix_ub_855  1
    load_0_22_3  free_load_conservation_924  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_4  arc_capacity_813  -20
    arc_0_22_4  connected_order_arc_814  -15
    arc_0_22_4  in_degree_857  1
    arc_0_22_4  out_degree_919  1
    arc_0_22_4  original_T_including_depot_unload_930  6.1561452832791758e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_4  arc_capacity_813  1
    load_0_22_4  segment_load_conservation_860  -1
    load_0_22_4  segment_prefix_lb_861  1
    load_0_22_4  segment_prefix_ub_862  1
    load_0_22_4  free_load_conservation_924  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_5  arc_capacity_815  -20
    arc_0_22_5  connected_order_arc_816  -15
    arc_0_22_5  in_degree_864  1
    arc_0_22_5  out_degree_919  1
    arc_0_22_5  original_T_including_depot_unload_930  2.1481294511470344e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_5  arc_capacity_815  1
    load_0_22_5  segment_load_conservation_867  -1
    load_0_22_5  segment_prefix_lb_868  1
    load_0_22_5  segment_prefix_ub_869  1
    load_0_22_5  free_load_conservation_924  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_6  arc_capacity_817  -20
    arc_0_22_6  connected_order_arc_818  -15
    arc_0_22_6  in_degree_871  1
    arc_0_22_6  out_degree_919  1
    arc_0_22_6  original_T_including_depot_unload_930  3.9766425523492148e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_6  arc_capacity_817  1
    load_0_22_6  segment_load_conservation_874  -1
    load_0_22_6  segment_prefix_lb_875  1
    load_0_22_6  segment_prefix_ub_876  1
    load_0_22_6  free_load_conservation_924  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_15  arc_capacity_819  -20
    arc_0_22_15  connected_order_arc_820  -15
    arc_0_22_15  in_degree_878  1
    arc_0_22_15  out_degree_919  1
    arc_0_22_15  original_T_including_depot_unload_930  2.9098466309579254e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_15  arc_capacity_819  1
    load_0_22_15  free_load_conservation_882  -1
    load_0_22_15  free_load_conservation_924  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_16  arc_capacity_821  -20
    arc_0_22_16  connected_order_arc_822  -15
    arc_0_22_16  in_degree_884  1
    arc_0_22_16  out_degree_919  1
    arc_0_22_16  original_T_including_depot_unload_930  4.3129452098285111e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_16  arc_capacity_821  1
    load_0_22_16  free_load_conservation_888  -1
    load_0_22_16  free_load_conservation_924  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_17  arc_capacity_823  -20
    arc_0_22_17  connected_order_arc_824  -15
    arc_0_22_17  in_degree_890  1
    arc_0_22_17  out_degree_919  1
    arc_0_22_17  original_T_including_depot_unload_930  1.3727638439182763e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_22_17  arc_capacity_823  1
    load_0_22_17  free_load_conservation_894  -1
    load_0_22_17  free_load_conservation_924  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_18  arc_capacity_825  -20
    arc_0_22_18  connected_order_arc_826  -15
    arc_0_22_18  in_degree_896  1
    arc_0_22_18  out_degree_919  1
    arc_0_22_18  original_T_including_depot_unload_930  3.2938591738444967e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_18  arc_capacity_825  1
    load_0_22_18  free_load_conservation_900  -1
    load_0_22_18  free_load_conservation_924  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_19  arc_capacity_827  -20
    arc_0_22_19  connected_order_arc_828  -15
    arc_0_22_19  in_degree_902  1
    arc_0_22_19  out_degree_919  1
    arc_0_22_19  original_T_including_depot_unload_930  9.8652191996938075e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_19  arc_capacity_827  1
    load_0_22_19  free_load_conservation_906  -1
    load_0_22_19  free_load_conservation_924  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_20  arc_capacity_829  -20
    arc_0_22_20  connected_order_arc_830  -15
    arc_0_22_20  in_degree_908  1
    arc_0_22_20  out_degree_919  1
    arc_0_22_20  original_T_including_depot_unload_930  3.2985327387120213e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_20  arc_capacity_829  1
    load_0_22_20  free_load_conservation_912  -1
    load_0_22_20  free_load_conservation_924  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_21  arc_capacity_831  -20
    arc_0_22_21  connected_order_arc_832  -15
    arc_0_22_21  in_degree_914  1
    arc_0_22_21  out_degree_919  1
    arc_0_22_21  original_T_including_depot_unload_930  1.1341050580477483e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_22_21  arc_capacity_831  1
    load_0_22_21  free_load_conservation_918  -1
    load_0_22_21  free_load_conservation_924  1
    visit_1_7  out_degree_1222  -1
    visit_1_7  in_degree_1223  -1
    visit_1_7  order_active_lb_1224  -1
    visit_1_7  order_active_ub_1225  -12
    order_1_7  connected_order_arc_946  -1
    order_1_7  connected_order_arc_948  -1
    order_1_7  connected_order_arc_950  -1
    order_1_7  connected_order_arc_952  -1
    order_1_7  connected_order_arc_954  -1
    order_1_7  connected_order_arc_956  -1
    order_1_7  connected_order_arc_958  -1
    order_1_7  connected_order_arc_960  -1
    order_1_7  connected_order_arc_962  -1
    order_1_7  connected_order_arc_964  -1
    order_1_7  connected_order_arc_966  -1
    order_1_7  connected_order_arc_969  1
    order_1_7  connected_order_arc_992  1
    order_1_7  connected_order_arc_1015  1
    order_1_7  connected_order_arc_1038  1
    order_1_7  connected_order_arc_1061  1
    order_1_7  connected_order_arc_1084  1
    order_1_7  connected_order_arc_1107  1
    order_1_7  connected_order_arc_1130  1
    order_1_7  connected_order_arc_1153  1
    order_1_7  connected_order_arc_1176  1
    order_1_7  connected_order_arc_1199  1
    order_1_7  order_active_lb_1224  1
    order_1_7  order_active_ub_1225  1
    order_1_7  fixed_segment_relative_order_1298  -1
    visit_1_8  out_degree_1229  -1
    visit_1_8  in_degree_1230  -1
    visit_1_8  order_active_lb_1231  -1
    visit_1_8  order_active_ub_1232  -12
    order_1_8  connected_order_arc_946  1
    order_1_8  connected_order_arc_969  -1
    order_1_8  connected_order_arc_971  -1
    order_1_8  connected_order_arc_973  -1
    order_1_8  connected_order_arc_975  -1
    order_1_8  connected_order_arc_977  -1
    order_1_8  connected_order_arc_979  -1
    order_1_8  connected_order_arc_981  -1
    order_1_8  connected_order_arc_983  -1
    order_1_8  connected_order_arc_985  -1
    order_1_8  connected_order_arc_987  -1
    order_1_8  connected_order_arc_989  -1
    order_1_8  connected_order_arc_994  1
    order_1_8  connected_order_arc_1017  1
    order_1_8  connected_order_arc_1040  1
    order_1_8  connected_order_arc_1063  1
    order_1_8  connected_order_arc_1086  1
    order_1_8  connected_order_arc_1109  1
    order_1_8  connected_order_arc_1132  1
    order_1_8  connected_order_arc_1155  1
    order_1_8  connected_order_arc_1178  1
    order_1_8  connected_order_arc_1201  1
    order_1_8  order_active_lb_1231  1
    order_1_8  order_active_ub_1232  1
    order_1_8  fixed_segment_relative_order_1298  1
    order_1_8  fixed_segment_relative_order_1299  -1
    visit_1_9  out_degree_1236  -1
    visit_1_9  in_degree_1237  -1
    visit_1_9  order_active_lb_1238  -1
    visit_1_9  order_active_ub_1239  -12
    order_1_9  connected_order_arc_948  1
    order_1_9  connected_order_arc_971  1
    order_1_9  connected_order_arc_992  -1
    order_1_9  connected_order_arc_994  -1
    order_1_9  connected_order_arc_996  -1
    order_1_9  connected_order_arc_998  -1
    order_1_9  connected_order_arc_1000  -1
    order_1_9  connected_order_arc_1002  -1
    order_1_9  connected_order_arc_1004  -1
    order_1_9  connected_order_arc_1006  -1
    order_1_9  connected_order_arc_1008  -1
    order_1_9  connected_order_arc_1010  -1
    order_1_9  connected_order_arc_1012  -1
    order_1_9  connected_order_arc_1019  1
    order_1_9  connected_order_arc_1042  1
    order_1_9  connected_order_arc_1065  1
    order_1_9  connected_order_arc_1088  1
    order_1_9  connected_order_arc_1111  1
    order_1_9  connected_order_arc_1134  1
    order_1_9  connected_order_arc_1157  1
    order_1_9  connected_order_arc_1180  1
    order_1_9  connected_order_arc_1203  1
    order_1_9  order_active_lb_1238  1
    order_1_9  order_active_ub_1239  1
    order_1_9  fixed_segment_relative_order_1299  1
    order_1_9  fixed_segment_relative_order_1300  -1
    visit_1_10  out_degree_1243  -1
    visit_1_10  in_degree_1244  -1
    visit_1_10  order_active_lb_1245  -1
    visit_1_10  order_active_ub_1246  -12
    order_1_10  connected_order_arc_950  1
    order_1_10  connected_order_arc_973  1
    order_1_10  connected_order_arc_996  1
    order_1_10  connected_order_arc_1015  -1
    order_1_10  connected_order_arc_1017  -1
    order_1_10  connected_order_arc_1019  -1
    order_1_10  connected_order_arc_1021  -1
    order_1_10  connected_order_arc_1023  -1
    order_1_10  connected_order_arc_1025  -1
    order_1_10  connected_order_arc_1027  -1
    order_1_10  connected_order_arc_1029  -1
    order_1_10  connected_order_arc_1031  -1
    order_1_10  connected_order_arc_1033  -1
    order_1_10  connected_order_arc_1035  -1
    order_1_10  connected_order_arc_1044  1
    order_1_10  connected_order_arc_1067  1
    order_1_10  connected_order_arc_1090  1
    order_1_10  connected_order_arc_1113  1
    order_1_10  connected_order_arc_1136  1
    order_1_10  connected_order_arc_1159  1
    order_1_10  connected_order_arc_1182  1
    order_1_10  connected_order_arc_1205  1
    order_1_10  order_active_lb_1245  1
    order_1_10  order_active_ub_1246  1
    order_1_10  fixed_segment_relative_order_1300  1
    visit_1_15  out_degree_1250  -1
    visit_1_15  in_degree_1251  -1
    visit_1_15  order_active_lb_1252  -1
    visit_1_15  order_active_ub_1253  -12
    visit_1_15  service_visit_def_1254  -1
    order_1_15  connected_order_arc_952  1
    order_1_15  connected_order_arc_975  1
    order_1_15  connected_order_arc_998  1
    order_1_15  connected_order_arc_1021  1
    order_1_15  connected_order_arc_1038  -1
    order_1_15  connected_order_arc_1040  -1
    order_1_15  connected_order_arc_1042  -1
    order_1_15  connected_order_arc_1044  -1
    order_1_15  connected_order_arc_1046  -1
    order_1_15  connected_order_arc_1048  -1
    order_1_15  connected_order_arc_1050  -1
    order_1_15  connected_order_arc_1052  -1
    order_1_15  connected_order_arc_1054  -1
    order_1_15  connected_order_arc_1056  -1
    order_1_15  connected_order_arc_1058  -1
    order_1_15  connected_order_arc_1069  1
    order_1_15  connected_order_arc_1092  1
    order_1_15  connected_order_arc_1115  1
    order_1_15  connected_order_arc_1138  1
    order_1_15  connected_order_arc_1161  1
    order_1_15  connected_order_arc_1184  1
    order_1_15  connected_order_arc_1207  1
    order_1_15  order_active_lb_1252  1
    order_1_15  order_active_ub_1253  1
    visit_1_16  out_degree_1256  -1
    visit_1_16  in_degree_1257  -1
    visit_1_16  order_active_lb_1258  -1
    visit_1_16  order_active_ub_1259  -12
    visit_1_16  service_visit_def_1260  -1
    order_1_16  connected_order_arc_954  1
    order_1_16  connected_order_arc_977  1
    order_1_16  connected_order_arc_1000  1
    order_1_16  connected_order_arc_1023  1
    order_1_16  connected_order_arc_1046  1
    order_1_16  connected_order_arc_1061  -1
    order_1_16  connected_order_arc_1063  -1
    order_1_16  connected_order_arc_1065  -1
    order_1_16  connected_order_arc_1067  -1
    order_1_16  connected_order_arc_1069  -1
    order_1_16  connected_order_arc_1071  -1
    order_1_16  connected_order_arc_1073  -1
    order_1_16  connected_order_arc_1075  -1
    order_1_16  connected_order_arc_1077  -1
    order_1_16  connected_order_arc_1079  -1
    order_1_16  connected_order_arc_1081  -1
    order_1_16  connected_order_arc_1094  1
    order_1_16  connected_order_arc_1117  1
    order_1_16  connected_order_arc_1140  1
    order_1_16  connected_order_arc_1163  1
    order_1_16  connected_order_arc_1186  1
    order_1_16  connected_order_arc_1209  1
    order_1_16  order_active_lb_1258  1
    order_1_16  order_active_ub_1259  1
    visit_1_17  out_degree_1262  -1
    visit_1_17  in_degree_1263  -1
    visit_1_17  order_active_lb_1264  -1
    visit_1_17  order_active_ub_1265  -12
    visit_1_17  service_visit_def_1266  -1
    order_1_17  connected_order_arc_956  1
    order_1_17  connected_order_arc_979  1
    order_1_17  connected_order_arc_1002  1
    order_1_17  connected_order_arc_1025  1
    order_1_17  connected_order_arc_1048  1
    order_1_17  connected_order_arc_1071  1
    order_1_17  connected_order_arc_1084  -1
    order_1_17  connected_order_arc_1086  -1
    order_1_17  connected_order_arc_1088  -1
    order_1_17  connected_order_arc_1090  -1
    order_1_17  connected_order_arc_1092  -1
    order_1_17  connected_order_arc_1094  -1
    order_1_17  connected_order_arc_1096  -1
    order_1_17  connected_order_arc_1098  -1
    order_1_17  connected_order_arc_1100  -1
    order_1_17  connected_order_arc_1102  -1
    order_1_17  connected_order_arc_1104  -1
    order_1_17  connected_order_arc_1119  1
    order_1_17  connected_order_arc_1142  1
    order_1_17  connected_order_arc_1165  1
    order_1_17  connected_order_arc_1188  1
    order_1_17  connected_order_arc_1211  1
    order_1_17  order_active_lb_1264  1
    order_1_17  order_active_ub_1265  1
    visit_1_18  out_degree_1268  -1
    visit_1_18  in_degree_1269  -1
    visit_1_18  order_active_lb_1270  -1
    visit_1_18  order_active_ub_1271  -12
    visit_1_18  service_visit_def_1272  -1
    order_1_18  connected_order_arc_958  1
    order_1_18  connected_order_arc_981  1
    order_1_18  connected_order_arc_1004  1
    order_1_18  connected_order_arc_1027  1
    order_1_18  connected_order_arc_1050  1
    order_1_18  connected_order_arc_1073  1
    order_1_18  connected_order_arc_1096  1
    order_1_18  connected_order_arc_1107  -1
    order_1_18  connected_order_arc_1109  -1
    order_1_18  connected_order_arc_1111  -1
    order_1_18  connected_order_arc_1113  -1
    order_1_18  connected_order_arc_1115  -1
    order_1_18  connected_order_arc_1117  -1
    order_1_18  connected_order_arc_1119  -1
    order_1_18  connected_order_arc_1121  -1
    order_1_18  connected_order_arc_1123  -1
    order_1_18  connected_order_arc_1125  -1
    order_1_18  connected_order_arc_1127  -1
    order_1_18  connected_order_arc_1144  1
    order_1_18  connected_order_arc_1167  1
    order_1_18  connected_order_arc_1190  1
    order_1_18  connected_order_arc_1213  1
    order_1_18  order_active_lb_1270  1
    order_1_18  order_active_ub_1271  1
    visit_1_19  out_degree_1274  -1
    visit_1_19  in_degree_1275  -1
    visit_1_19  order_active_lb_1276  -1
    visit_1_19  order_active_ub_1277  -12
    visit_1_19  service_visit_def_1278  -1
    order_1_19  connected_order_arc_960  1
    order_1_19  connected_order_arc_983  1
    order_1_19  connected_order_arc_1006  1
    order_1_19  connected_order_arc_1029  1
    order_1_19  connected_order_arc_1052  1
    order_1_19  connected_order_arc_1075  1
    order_1_19  connected_order_arc_1098  1
    order_1_19  connected_order_arc_1121  1
    order_1_19  connected_order_arc_1130  -1
    order_1_19  connected_order_arc_1132  -1
    order_1_19  connected_order_arc_1134  -1
    order_1_19  connected_order_arc_1136  -1
    order_1_19  connected_order_arc_1138  -1
    order_1_19  connected_order_arc_1140  -1
    order_1_19  connected_order_arc_1142  -1
    order_1_19  connected_order_arc_1144  -1
    order_1_19  connected_order_arc_1146  -1
    order_1_19  connected_order_arc_1148  -1
    order_1_19  connected_order_arc_1150  -1
    order_1_19  connected_order_arc_1169  1
    order_1_19  connected_order_arc_1192  1
    order_1_19  connected_order_arc_1215  1
    order_1_19  order_active_lb_1276  1
    order_1_19  order_active_ub_1277  1
    visit_1_20  out_degree_1280  -1
    visit_1_20  in_degree_1281  -1
    visit_1_20  order_active_lb_1282  -1
    visit_1_20  order_active_ub_1283  -12
    visit_1_20  service_visit_def_1284  -1
    order_1_20  connected_order_arc_962  1
    order_1_20  connected_order_arc_985  1
    order_1_20  connected_order_arc_1008  1
    order_1_20  connected_order_arc_1031  1
    order_1_20  connected_order_arc_1054  1
    order_1_20  connected_order_arc_1077  1
    order_1_20  connected_order_arc_1100  1
    order_1_20  connected_order_arc_1123  1
    order_1_20  connected_order_arc_1146  1
    order_1_20  connected_order_arc_1153  -1
    order_1_20  connected_order_arc_1155  -1
    order_1_20  connected_order_arc_1157  -1
    order_1_20  connected_order_arc_1159  -1
    order_1_20  connected_order_arc_1161  -1
    order_1_20  connected_order_arc_1163  -1
    order_1_20  connected_order_arc_1165  -1
    order_1_20  connected_order_arc_1167  -1
    order_1_20  connected_order_arc_1169  -1
    order_1_20  connected_order_arc_1171  -1
    order_1_20  connected_order_arc_1173  -1
    order_1_20  connected_order_arc_1194  1
    order_1_20  connected_order_arc_1217  1
    order_1_20  order_active_lb_1282  1
    order_1_20  order_active_ub_1283  1
    visit_1_21  out_degree_1286  -1
    visit_1_21  in_degree_1287  -1
    visit_1_21  order_active_lb_1288  -1
    visit_1_21  order_active_ub_1289  -12
    visit_1_21  service_visit_def_1290  -1
    order_1_21  connected_order_arc_964  1
    order_1_21  connected_order_arc_987  1
    order_1_21  connected_order_arc_1010  1
    order_1_21  connected_order_arc_1033  1
    order_1_21  connected_order_arc_1056  1
    order_1_21  connected_order_arc_1079  1
    order_1_21  connected_order_arc_1102  1
    order_1_21  connected_order_arc_1125  1
    order_1_21  connected_order_arc_1148  1
    order_1_21  connected_order_arc_1171  1
    order_1_21  connected_order_arc_1176  -1
    order_1_21  connected_order_arc_1178  -1
    order_1_21  connected_order_arc_1180  -1
    order_1_21  connected_order_arc_1182  -1
    order_1_21  connected_order_arc_1184  -1
    order_1_21  connected_order_arc_1186  -1
    order_1_21  connected_order_arc_1188  -1
    order_1_21  connected_order_arc_1190  -1
    order_1_21  connected_order_arc_1192  -1
    order_1_21  connected_order_arc_1194  -1
    order_1_21  connected_order_arc_1196  -1
    order_1_21  connected_order_arc_1219  1
    order_1_21  order_active_lb_1288  1
    order_1_21  order_active_ub_1289  1
    visit_1_22  out_degree_1292  -1
    visit_1_22  in_degree_1293  -1
    visit_1_22  order_active_lb_1294  -1
    visit_1_22  order_active_ub_1295  -12
    visit_1_22  service_visit_def_1296  -1
    order_1_22  connected_order_arc_966  1
    order_1_22  connected_order_arc_989  1
    order_1_22  connected_order_arc_1012  1
    order_1_22  connected_order_arc_1035  1
    order_1_22  connected_order_arc_1058  1
    order_1_22  connected_order_arc_1081  1
    order_1_22  connected_order_arc_1104  1
    order_1_22  connected_order_arc_1127  1
    order_1_22  connected_order_arc_1150  1
    order_1_22  connected_order_arc_1173  1
    order_1_22  connected_order_arc_1196  1
    order_1_22  connected_order_arc_1199  -1
    order_1_22  connected_order_arc_1201  -1
    order_1_22  connected_order_arc_1203  -1
    order_1_22  connected_order_arc_1205  -1
    order_1_22  connected_order_arc_1207  -1
    order_1_22  connected_order_arc_1209  -1
    order_1_22  connected_order_arc_1211  -1
    order_1_22  connected_order_arc_1213  -1
    order_1_22  connected_order_arc_1215  -1
    order_1_22  connected_order_arc_1217  -1
    order_1_22  connected_order_arc_1219  -1
    order_1_22  order_active_lb_1294  1
    order_1_22  order_active_ub_1295  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_0  arc_capacity_931  -25
    arc_1_0_0  depot_departure_or_bypass_1220  1
    arc_1_0_0  depot_return_or_bypass_1221  1
    MARKER    'MARKER'                 'INTEND'
    load_1_0_0  arc_capacity_931  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_7  arc_capacity_932  -25
    arc_1_0_7  depot_departure_or_bypass_1220  1
    arc_1_0_7  in_degree_1223  1
    arc_1_0_7  original_T_including_depot_unload_1301  8.7749189782983967e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_7  arc_capacity_932  1
    load_1_0_7  segment_load_conservation_1226  -1
    load_1_0_7  segment_prefix_lb_1227  1
    load_1_0_7  segment_prefix_ub_1228  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_8  arc_capacity_933  -25
    arc_1_0_8  depot_departure_or_bypass_1220  1
    arc_1_0_8  in_degree_1230  1
    arc_1_0_8  original_T_including_depot_unload_1301  7.8195480223834068e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_8  arc_capacity_933  1
    load_1_0_8  segment_load_conservation_1233  -1
    load_1_0_8  segment_prefix_lb_1234  1
    load_1_0_8  segment_prefix_ub_1235  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_9  arc_capacity_934  -25
    arc_1_0_9  depot_departure_or_bypass_1220  1
    arc_1_0_9  in_degree_1237  1
    arc_1_0_9  original_T_including_depot_unload_1301  4.7522445589173662e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_9  arc_capacity_934  1
    load_1_0_9  segment_load_conservation_1240  -1
    load_1_0_9  segment_prefix_lb_1241  1
    load_1_0_9  segment_prefix_ub_1242  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_10  arc_capacity_935  -25
    arc_1_0_10  depot_departure_or_bypass_1220  1
    arc_1_0_10  in_degree_1244  1
    arc_1_0_10  original_T_including_depot_unload_1301  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_10  arc_capacity_935  1
    load_1_0_10  segment_load_conservation_1247  -1
    load_1_0_10  segment_prefix_lb_1248  1
    load_1_0_10  segment_prefix_ub_1249  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_15  arc_capacity_936  -25
    arc_1_0_15  depot_departure_or_bypass_1220  1
    arc_1_0_15  in_degree_1251  1
    arc_1_0_15  original_T_including_depot_unload_1301  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_15  arc_capacity_936  1
    load_1_0_15  free_load_conservation_1255  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_16  arc_capacity_937  -25
    arc_1_0_16  depot_departure_or_bypass_1220  1
    arc_1_0_16  in_degree_1257  1
    arc_1_0_16  original_T_including_depot_unload_1301  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_16  arc_capacity_937  1
    load_1_0_16  free_load_conservation_1261  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_17  arc_capacity_938  -25
    arc_1_0_17  depot_departure_or_bypass_1220  1
    arc_1_0_17  in_degree_1263  1
    arc_1_0_17  original_T_including_depot_unload_1301  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_17  arc_capacity_938  1
    load_1_0_17  free_load_conservation_1267  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_18  arc_capacity_939  -25
    arc_1_0_18  depot_departure_or_bypass_1220  1
    arc_1_0_18  in_degree_1269  1
    arc_1_0_18  original_T_including_depot_unload_1301  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_18  arc_capacity_939  1
    load_1_0_18  free_load_conservation_1273  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_19  arc_capacity_940  -25
    arc_1_0_19  depot_departure_or_bypass_1220  1
    arc_1_0_19  in_degree_1275  1
    arc_1_0_19  original_T_including_depot_unload_1301  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_19  arc_capacity_940  1
    load_1_0_19  free_load_conservation_1279  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_20  arc_capacity_941  -25
    arc_1_0_20  depot_departure_or_bypass_1220  1
    arc_1_0_20  in_degree_1281  1
    arc_1_0_20  original_T_including_depot_unload_1301  6.6653528395596720e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_20  arc_capacity_941  1
    load_1_0_20  free_load_conservation_1285  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_21  arc_capacity_942  -25
    arc_1_0_21  depot_departure_or_bypass_1220  1
    arc_1_0_21  in_degree_1287  1
    arc_1_0_21  original_T_including_depot_unload_1301  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_21  arc_capacity_942  1
    load_1_0_21  free_load_conservation_1291  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_22  arc_capacity_943  -25
    arc_1_0_22  depot_departure_or_bypass_1220  1
    arc_1_0_22  in_degree_1293  1
    arc_1_0_22  original_T_including_depot_unload_1301  5.9431738885389052e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_22  arc_capacity_943  1
    load_1_0_22  free_load_conservation_1297  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_0  arc_capacity_944  -25
    arc_1_7_0  depot_return_or_bypass_1221  1
    arc_1_7_0  out_degree_1222  1
    arc_1_7_0  original_T_including_depot_unload_1301  887.312716328479
    MARKER    'MARKER'                 'INTEND'
    load_1_7_0  arc_capacity_944  1
    load_1_7_0  segment_load_conservation_1226  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_8  arc_capacity_945  -25
    arc_1_7_8  connected_order_arc_946  -13
    arc_1_7_8  out_degree_1222  1
    arc_1_7_8  in_degree_1230  1
    arc_1_7_8  original_T_including_depot_unload_1301  1.1119949880978965e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_8  arc_capacity_945  1
    load_1_7_8  segment_load_conservation_1226  1
    load_1_7_8  segment_load_conservation_1233  -1
    load_1_7_8  segment_prefix_lb_1234  1
    load_1_7_8  segment_prefix_ub_1235  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_9  arc_capacity_947  -25
    arc_1_7_9  connected_order_arc_948  -13
    arc_1_7_9  out_degree_1222  1
    arc_1_7_9  in_degree_1237  1
    arc_1_7_9  original_T_including_depot_unload_1301  4.9711893625650669e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_9  arc_capacity_947  1
    load_1_7_9  segment_load_conservation_1226  1
    load_1_7_9  segment_load_conservation_1240  -1
    load_1_7_9  segment_prefix_lb_1241  1
    load_1_7_9  segment_prefix_ub_1242  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_10  arc_capacity_949  -25
    arc_1_7_10  connected_order_arc_950  -13
    arc_1_7_10  out_degree_1222  1
    arc_1_7_10  in_degree_1244  1
    arc_1_7_10  original_T_including_depot_unload_1301  8.4332546654485930e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_10  arc_capacity_949  1
    load_1_7_10  segment_load_conservation_1226  1
    load_1_7_10  segment_load_conservation_1247  -1
    load_1_7_10  segment_prefix_lb_1248  1
    load_1_7_10  segment_prefix_ub_1249  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_15  arc_capacity_951  -25
    arc_1_7_15  connected_order_arc_952  -13
    arc_1_7_15  out_degree_1222  1
    arc_1_7_15  in_degree_1251  1
    arc_1_7_15  original_T_including_depot_unload_1301  1.2087821033682005e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_15  arc_capacity_951  1
    load_1_7_15  segment_load_conservation_1226  1
    load_1_7_15  free_load_conservation_1255  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_16  arc_capacity_953  -25
    arc_1_7_16  connected_order_arc_954  -13
    arc_1_7_16  out_degree_1222  1
    arc_1_7_16  in_degree_1257  1
    arc_1_7_16  original_T_including_depot_unload_1301  1.1750055851715294e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_16  arc_capacity_953  1
    load_1_7_16  segment_load_conservation_1226  1
    load_1_7_16  free_load_conservation_1261  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_17  arc_capacity_955  -25
    arc_1_7_17  connected_order_arc_956  -13
    arc_1_7_17  out_degree_1222  1
    arc_1_7_17  in_degree_1263  1
    arc_1_7_17  original_T_including_depot_unload_1301  1.4573788798892317e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_17  arc_capacity_955  1
    load_1_7_17  segment_load_conservation_1226  1
    load_1_7_17  free_load_conservation_1267  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_18  arc_capacity_957  -25
    arc_1_7_18  connected_order_arc_958  -13
    arc_1_7_18  out_degree_1222  1
    arc_1_7_18  in_degree_1269  1
    arc_1_7_18  original_T_including_depot_unload_1301  1.1485840683203917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_18  arc_capacity_957  1
    load_1_7_18  segment_load_conservation_1226  1
    load_1_7_18  free_load_conservation_1273  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_19  arc_capacity_959  -25
    arc_1_7_19  connected_order_arc_960  -13
    arc_1_7_19  out_degree_1222  1
    arc_1_7_19  in_degree_1275  1
    arc_1_7_19  original_T_including_depot_unload_1301  2226.1143218952
    MARKER    'MARKER'                 'INTEND'
    load_1_7_19  arc_capacity_959  1
    load_1_7_19  segment_load_conservation_1226  1
    load_1_7_19  free_load_conservation_1279  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_20  arc_capacity_961  -25
    arc_1_7_20  connected_order_arc_962  -13
    arc_1_7_20  out_degree_1222  1
    arc_1_7_20  in_degree_1281  1
    arc_1_7_20  original_T_including_depot_unload_1301  1.4099802576911704e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_20  arc_capacity_961  1
    load_1_7_20  segment_load_conservation_1226  1
    load_1_7_20  free_load_conservation_1285  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_21  arc_capacity_963  -25
    arc_1_7_21  connected_order_arc_964  -13
    arc_1_7_21  out_degree_1222  1
    arc_1_7_21  in_degree_1287  1
    arc_1_7_21  original_T_including_depot_unload_1301  3.3422575089633142e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_21  arc_capacity_963  1
    load_1_7_21  segment_load_conservation_1226  1
    load_1_7_21  free_load_conservation_1291  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_22  arc_capacity_965  -25
    arc_1_7_22  connected_order_arc_966  -13
    arc_1_7_22  out_degree_1222  1
    arc_1_7_22  in_degree_1293  1
    arc_1_7_22  original_T_including_depot_unload_1301  1.4586590520122220e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_22  arc_capacity_965  1
    load_1_7_22  segment_load_conservation_1226  1
    load_1_7_22  free_load_conservation_1297  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_0  arc_capacity_967  -25
    arc_1_8_0  depot_return_or_bypass_1221  1
    arc_1_8_0  out_degree_1229  1
    arc_1_8_0  original_T_including_depot_unload_1301  7.8195480223834068e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_0  arc_capacity_967  1
    load_1_8_0  segment_load_conservation_1233  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_7  arc_capacity_968  -25
    arc_1_8_7  connected_order_arc_969  -13
    arc_1_8_7  in_degree_1223  1
    arc_1_8_7  out_degree_1229  1
    arc_1_8_7  original_T_including_depot_unload_1301  7.0804311489116617e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_7  arc_capacity_968  1
    load_1_8_7  segment_load_conservation_1226  -1
    load_1_8_7  segment_prefix_lb_1227  1
    load_1_8_7  segment_prefix_ub_1228  1
    load_1_8_7  segment_load_conservation_1233  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_9  arc_capacity_970  -25
    arc_1_8_9  connected_order_arc_971  -13
    arc_1_8_9  out_degree_1229  1
    arc_1_8_9  in_degree_1237  1
    arc_1_8_9  original_T_including_depot_unload_1301  4.1964259385165178e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_9  arc_capacity_970  1
    load_1_8_9  segment_load_conservation_1233  1
    load_1_8_9  segment_load_conservation_1240  -1
    load_1_8_9  segment_prefix_lb_1241  1
    load_1_8_9  segment_prefix_ub_1242  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_10  arc_capacity_972  -25
    arc_1_8_10  connected_order_arc_973  -13
    arc_1_8_10  out_degree_1229  1
    arc_1_8_10  in_degree_1244  1
    arc_1_8_10  original_T_including_depot_unload_1301  7.3394466063263269e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_10  arc_capacity_972  1
    load_1_8_10  segment_load_conservation_1233  1
    load_1_8_10  segment_load_conservation_1247  -1
    load_1_8_10  segment_prefix_lb_1248  1
    load_1_8_10  segment_prefix_ub_1249  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_15  arc_capacity_974  -25
    arc_1_8_15  connected_order_arc_975  -13
    arc_1_8_15  out_degree_1229  1
    arc_1_8_15  in_degree_1251  1
    arc_1_8_15  original_T_including_depot_unload_1301  1.1162091303696777e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_15  arc_capacity_974  1
    load_1_8_15  segment_load_conservation_1233  1
    load_1_8_15  free_load_conservation_1255  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_16  arc_capacity_976  -25
    arc_1_8_16  connected_order_arc_977  -13
    arc_1_8_16  out_degree_1229  1
    arc_1_8_16  in_degree_1257  1
    arc_1_8_16  original_T_including_depot_unload_1301  1.0921272639748563e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_16  arc_capacity_976  1
    load_1_8_16  segment_load_conservation_1233  1
    load_1_8_16  free_load_conservation_1261  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_17  arc_capacity_978  -25
    arc_1_8_17  connected_order_arc_979  -13
    arc_1_8_17  out_degree_1229  1
    arc_1_8_17  in_degree_1263  1
    arc_1_8_17  original_T_including_depot_unload_1301  1.3626829404511475e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_17  arc_capacity_978  1
    load_1_8_17  segment_load_conservation_1233  1
    load_1_8_17  free_load_conservation_1267  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_18  arc_capacity_980  -25
    arc_1_8_18  connected_order_arc_981  -13
    arc_1_8_18  out_degree_1229  1
    arc_1_8_18  in_degree_1269  1
    arc_1_8_18  original_T_including_depot_unload_1301  1.0453757248865720e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_18  arc_capacity_980  1
    load_1_8_18  segment_load_conservation_1233  1
    load_1_8_18  free_load_conservation_1273  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_19  arc_capacity_982  -25
    arc_1_8_19  connected_order_arc_983  -13
    arc_1_8_19  out_degree_1229  1
    arc_1_8_19  in_degree_1275  1
    arc_1_8_19  original_T_including_depot_unload_1301  2115.53677476792
    MARKER    'MARKER'                 'INTEND'
    load_1_8_19  arc_capacity_982  1
    load_1_8_19  segment_load_conservation_1233  1
    load_1_8_19  free_load_conservation_1279  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_20  arc_capacity_984  -25
    arc_1_8_20  connected_order_arc_985  -13
    arc_1_8_20  out_degree_1229  1
    arc_1_8_20  in_degree_1281  1
    arc_1_8_20  original_T_including_depot_unload_1301  1.3251252487627862e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_20  arc_capacity_984  1
    load_1_8_20  segment_load_conservation_1233  1
    load_1_8_20  free_load_conservation_1285  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_21  arc_capacity_986  -25
    arc_1_8_21  connected_order_arc_987  -13
    arc_1_8_21  out_degree_1229  1
    arc_1_8_21  in_degree_1287  1
    arc_1_8_21  original_T_including_depot_unload_1301  2.5572087458878266e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_21  arc_capacity_986  1
    load_1_8_21  segment_load_conservation_1233  1
    load_1_8_21  free_load_conservation_1291  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_22  arc_capacity_988  -25
    arc_1_8_22  connected_order_arc_989  -13
    arc_1_8_22  out_degree_1229  1
    arc_1_8_22  in_degree_1293  1
    arc_1_8_22  original_T_including_depot_unload_1301  1.3593311700505531e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_22  arc_capacity_988  1
    load_1_8_22  segment_load_conservation_1233  1
    load_1_8_22  free_load_conservation_1297  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_0  arc_capacity_990  -25
    arc_1_9_0  depot_return_or_bypass_1221  1
    arc_1_9_0  out_degree_1236  1
    arc_1_9_0  original_T_including_depot_unload_1301  4.7522445589173662e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_0  arc_capacity_990  1
    load_1_9_0  segment_load_conservation_1240  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_7  arc_capacity_991  -25
    arc_1_9_7  connected_order_arc_992  -13
    arc_1_9_7  in_degree_1223  1
    arc_1_9_7  out_degree_1236  1
    arc_1_9_7  original_T_including_depot_unload_1301  9.0121368945211725e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_7  arc_capacity_991  1
    load_1_9_7  segment_load_conservation_1226  -1
    load_1_9_7  segment_prefix_lb_1227  1
    load_1_9_7  segment_prefix_ub_1228  1
    load_1_9_7  segment_load_conservation_1240  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_8  arc_capacity_993  -25
    arc_1_9_8  connected_order_arc_994  -13
    arc_1_9_8  in_degree_1230  1
    arc_1_9_8  out_degree_1236  1
    arc_1_9_8  original_T_including_depot_unload_1301  4.1964259385165178e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_8  arc_capacity_993  1
    load_1_9_8  segment_load_conservation_1233  -1
    load_1_9_8  segment_prefix_lb_1234  1
    load_1_9_8  segment_prefix_ub_1235  1
    load_1_9_8  segment_load_conservation_1240  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_10  arc_capacity_995  -25
    arc_1_9_10  connected_order_arc_996  -13
    arc_1_9_10  out_degree_1236  1
    arc_1_9_10  in_degree_1244  1
    arc_1_9_10  original_T_including_depot_unload_1301  4.9232225330062903e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_10  arc_capacity_995  1
    load_1_9_10  segment_load_conservation_1240  1
    load_1_9_10  segment_load_conservation_1247  -1
    load_1_9_10  segment_prefix_lb_1248  1
    load_1_9_10  segment_prefix_ub_1249  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_15  arc_capacity_997  -25
    arc_1_9_15  connected_order_arc_998  -13
    arc_1_9_15  out_degree_1236  1
    arc_1_9_15  in_degree_1251  1
    arc_1_9_15  original_T_including_depot_unload_1301  7.2171835955896984e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_15  arc_capacity_997  1
    load_1_9_15  segment_load_conservation_1240  1
    load_1_9_15  free_load_conservation_1255  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_16  arc_capacity_999  -25
    arc_1_9_16  connected_order_arc_1000  -13
    arc_1_9_16  out_degree_1236  1
    arc_1_9_16  in_degree_1257  1
    arc_1_9_16  original_T_including_depot_unload_1301  6.7803521648175558e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_16  arc_capacity_999  1
    load_1_9_16  segment_load_conservation_1240  1
    load_1_9_16  free_load_conservation_1261  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_17  arc_capacity_1001  -25
    arc_1_9_17  connected_order_arc_1002  -13
    arc_1_9_17  out_degree_1236  1
    arc_1_9_17  in_degree_1263  1
    arc_1_9_17  original_T_including_depot_unload_1301  1.3823927712314810e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_17  arc_capacity_1001  1
    load_1_9_17  segment_load_conservation_1240  1
    load_1_9_17  free_load_conservation_1267  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_18  arc_capacity_1003  -25
    arc_1_9_18  connected_order_arc_1004  -13
    arc_1_9_18  out_degree_1236  1
    arc_1_9_18  in_degree_1269  1
    arc_1_9_18  original_T_including_depot_unload_1301  7.0350721341213284e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_18  arc_capacity_1003  1
    load_1_9_18  segment_load_conservation_1240  1
    load_1_9_18  free_load_conservation_1273  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_19  arc_capacity_1005  -25
    arc_1_9_19  connected_order_arc_1006  -13
    arc_1_9_19  out_degree_1236  1
    arc_1_9_19  in_degree_1275  1
    arc_1_9_19  original_T_including_depot_unload_1301  1.8418804985785646e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_19  arc_capacity_1005  1
    load_1_9_19  segment_load_conservation_1240  1
    load_1_9_19  free_load_conservation_1279  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_20  arc_capacity_1007  -25
    arc_1_9_20  connected_order_arc_1008  -13
    arc_1_9_20  out_degree_1236  1
    arc_1_9_20  in_degree_1281  1
    arc_1_9_20  original_T_including_depot_unload_1301  9.1345700487521981e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_20  arc_capacity_1007  1
    load_1_9_20  segment_load_conservation_1240  1
    load_1_9_20  free_load_conservation_1285  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_21  arc_capacity_1009  -25
    arc_1_9_21  connected_order_arc_1010  -13
    arc_1_9_21  out_degree_1236  1
    arc_1_9_21  in_degree_1287  1
    arc_1_9_21  original_T_including_depot_unload_1301  1.6444540482789353e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_21  arc_capacity_1009  1
    load_1_9_21  segment_load_conservation_1240  1
    load_1_9_21  free_load_conservation_1291  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_22  arc_capacity_1011  -25
    arc_1_9_22  connected_order_arc_1012  -13
    arc_1_9_22  out_degree_1236  1
    arc_1_9_22  in_degree_1293  1
    arc_1_9_22  original_T_including_depot_unload_1301  987.973588780524
    MARKER    'MARKER'                 'INTEND'
    load_1_9_22  arc_capacity_1011  1
    load_1_9_22  segment_load_conservation_1240  1
    load_1_9_22  free_load_conservation_1297  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_0  arc_capacity_1013  -25
    arc_1_10_0  depot_return_or_bypass_1221  1
    arc_1_10_0  out_degree_1243  1
    arc_1_10_0  original_T_including_depot_unload_1301  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_0  arc_capacity_1013  1
    load_1_10_0  segment_load_conservation_1247  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_7  arc_capacity_1014  -25
    arc_1_10_7  connected_order_arc_1015  -13
    arc_1_10_7  in_degree_1223  1
    arc_1_10_7  out_degree_1243  1
    arc_1_10_7  original_T_including_depot_unload_1301  7.5571464781430223e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_7  arc_capacity_1014  1
    load_1_10_7  segment_load_conservation_1226  -1
    load_1_10_7  segment_prefix_lb_1227  1
    load_1_10_7  segment_prefix_ub_1228  1
    load_1_10_7  segment_load_conservation_1247  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_8  arc_capacity_1016  -25
    arc_1_10_8  connected_order_arc_1017  -13
    arc_1_10_8  in_degree_1230  1
    arc_1_10_8  out_degree_1243  1
    arc_1_10_8  original_T_including_depot_unload_1301  7.3394466063263269e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_8  arc_capacity_1016  1
    load_1_10_8  segment_load_conservation_1233  -1
    load_1_10_8  segment_prefix_lb_1234  1
    load_1_10_8  segment_prefix_ub_1235  1
    load_1_10_8  segment_load_conservation_1247  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_9  arc_capacity_1018  -25
    arc_1_10_9  connected_order_arc_1019  -13
    arc_1_10_9  in_degree_1237  1
    arc_1_10_9  out_degree_1243  1
    arc_1_10_9  original_T_including_depot_unload_1301  4.9232225330062903e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_9  arc_capacity_1018  1
    load_1_10_9  segment_load_conservation_1240  -1
    load_1_10_9  segment_prefix_lb_1241  1
    load_1_10_9  segment_prefix_ub_1242  1
    load_1_10_9  segment_load_conservation_1247  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_15  arc_capacity_1020  -25
    arc_1_10_15  connected_order_arc_1021  -13
    arc_1_10_15  out_degree_1243  1
    arc_1_10_15  in_degree_1251  1
    arc_1_10_15  original_T_including_depot_unload_1301  5.3713048648006088e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_15  arc_capacity_1020  1
    load_1_10_15  segment_load_conservation_1247  1
    load_1_10_15  free_load_conservation_1255  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_16  arc_capacity_1022  -25
    arc_1_10_16  connected_order_arc_1023  -13
    arc_1_10_16  out_degree_1243  1
    arc_1_10_16  in_degree_1257  1
    arc_1_10_16  original_T_including_depot_unload_1301  6.1704611580490348e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_16  arc_capacity_1022  1
    load_1_10_16  segment_load_conservation_1247  1
    load_1_10_16  free_load_conservation_1261  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_17  arc_capacity_1024  -25
    arc_1_10_17  connected_order_arc_1025  -13
    arc_1_10_17  out_degree_1243  1
    arc_1_10_17  in_degree_1263  1
    arc_1_10_17  original_T_including_depot_unload_1301  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_17  arc_capacity_1024  1
    load_1_10_17  segment_load_conservation_1247  1
    load_1_10_17  free_load_conservation_1267  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_18  arc_capacity_1026  -25
    arc_1_10_18  connected_order_arc_1027  -13
    arc_1_10_18  out_degree_1243  1
    arc_1_10_18  in_degree_1269  1
    arc_1_10_18  original_T_including_depot_unload_1301  359.975566576564
    MARKER    'MARKER'                 'INTEND'
    load_1_10_18  arc_capacity_1026  1
    load_1_10_18  segment_load_conservation_1247  1
    load_1_10_18  free_load_conservation_1273  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_19  arc_capacity_1028  -25
    arc_1_10_19  connected_order_arc_1029  -13
    arc_1_10_19  out_degree_1243  1
    arc_1_10_19  in_degree_1275  1
    arc_1_10_19  original_T_including_depot_unload_1301  1.3857128117205509e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_19  arc_capacity_1028  1
    load_1_10_19  segment_load_conservation_1247  1
    load_1_10_19  free_load_conservation_1279  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_20  arc_capacity_1030  -25
    arc_1_10_20  connected_order_arc_1031  -13
    arc_1_10_20  out_degree_1243  1
    arc_1_10_20  in_degree_1281  1
    arc_1_10_20  original_T_including_depot_unload_1301  7.8830763320343567e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_20  arc_capacity_1030  1
    load_1_10_20  segment_load_conservation_1247  1
    load_1_10_20  free_load_conservation_1285  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_21  arc_capacity_1032  -25
    arc_1_10_21  connected_order_arc_1033  -13
    arc_1_10_21  out_degree_1243  1
    arc_1_10_21  in_degree_1287  1
    arc_1_10_21  original_T_including_depot_unload_1301  5.7102904773674652e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_21  arc_capacity_1032  1
    load_1_10_21  segment_load_conservation_1247  1
    load_1_10_21  free_load_conservation_1291  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_22  arc_capacity_1034  -25
    arc_1_10_22  connected_order_arc_1035  -13
    arc_1_10_22  out_degree_1243  1
    arc_1_10_22  in_degree_1293  1
    arc_1_10_22  original_T_including_depot_unload_1301  6.8881953094806647e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_22  arc_capacity_1034  1
    load_1_10_22  segment_load_conservation_1247  1
    load_1_10_22  free_load_conservation_1297  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_0  arc_capacity_1036  -25
    arc_1_15_0  depot_return_or_bypass_1221  1
    arc_1_15_0  out_degree_1250  1
    arc_1_15_0  original_T_including_depot_unload_1301  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_0  arc_capacity_1036  1
    load_1_15_0  free_load_conservation_1255  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_7  arc_capacity_1037  -25
    arc_1_15_7  connected_order_arc_1038  -13
    arc_1_15_7  in_degree_1223  1
    arc_1_15_7  out_degree_1250  1
    arc_1_15_7  original_T_including_depot_unload_1301  1.2927779971523576e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_7  arc_capacity_1037  1
    load_1_15_7  segment_load_conservation_1226  -1
    load_1_15_7  segment_prefix_lb_1227  1
    load_1_15_7  segment_prefix_ub_1228  1
    load_1_15_7  free_load_conservation_1255  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_8  arc_capacity_1039  -25
    arc_1_15_8  connected_order_arc_1040  -13
    arc_1_15_8  in_degree_1230  1
    arc_1_15_8  out_degree_1250  1
    arc_1_15_8  original_T_including_depot_unload_1301  1.1162091303696777e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_8  arc_capacity_1039  1
    load_1_15_8  segment_load_conservation_1233  -1
    load_1_15_8  segment_prefix_lb_1234  1
    load_1_15_8  segment_prefix_ub_1235  1
    load_1_15_8  free_load_conservation_1255  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_9  arc_capacity_1041  -25
    arc_1_15_9  connected_order_arc_1042  -13
    arc_1_15_9  in_degree_1237  1
    arc_1_15_9  out_degree_1250  1
    arc_1_15_9  original_T_including_depot_unload_1301  7.2171835955896984e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_9  arc_capacity_1041  1
    load_1_15_9  segment_load_conservation_1240  -1
    load_1_15_9  segment_prefix_lb_1241  1
    load_1_15_9  segment_prefix_ub_1242  1
    load_1_15_9  free_load_conservation_1255  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_10  arc_capacity_1043  -25
    arc_1_15_10  connected_order_arc_1044  -13
    arc_1_15_10  in_degree_1244  1
    arc_1_15_10  out_degree_1250  1
    arc_1_15_10  original_T_including_depot_unload_1301  5.3713048648006088e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_10  arc_capacity_1043  1
    load_1_15_10  segment_load_conservation_1247  -1
    load_1_15_10  segment_prefix_lb_1248  1
    load_1_15_10  segment_prefix_ub_1249  1
    load_1_15_10  free_load_conservation_1255  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_16  arc_capacity_1045  -25
    arc_1_15_16  connected_order_arc_1046  -13
    arc_1_15_16  out_degree_1250  1
    arc_1_15_16  in_degree_1257  1
    arc_1_15_16  original_T_including_depot_unload_1301  1.6597164064313077e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_16  arc_capacity_1045  1
    load_1_15_16  free_load_conservation_1255  1
    load_1_15_16  free_load_conservation_1261  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_17  arc_capacity_1047  -25
    arc_1_15_17  connected_order_arc_1048  -13
    arc_1_15_17  out_degree_1250  1
    arc_1_15_17  in_degree_1263  1
    arc_1_15_17  original_T_including_depot_unload_1301  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_17  arc_capacity_1047  1
    load_1_15_17  free_load_conservation_1255  1
    load_1_15_17  free_load_conservation_1267  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_18  arc_capacity_1049  -25
    arc_1_15_18  connected_order_arc_1050  -13
    arc_1_15_18  out_degree_1250  1
    arc_1_15_18  in_degree_1269  1
    arc_1_15_18  original_T_including_depot_unload_1301  2.4083746437975364e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_18  arc_capacity_1049  1
    load_1_15_18  free_load_conservation_1255  1
    load_1_15_18  free_load_conservation_1273  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_19  arc_capacity_1051  -25
    arc_1_15_19  connected_order_arc_1052  -13
    arc_1_15_19  out_degree_1250  1
    arc_1_15_19  in_degree_1275  1
    arc_1_15_19  original_T_including_depot_unload_1301  1.2608612406747543e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_19  arc_capacity_1051  1
    load_1_15_19  free_load_conservation_1255  1
    load_1_15_19  free_load_conservation_1279  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_20  arc_capacity_1053  -25
    arc_1_15_20  connected_order_arc_1054  -13
    arc_1_15_20  out_degree_1250  1
    arc_1_15_20  in_degree_1281  1
    arc_1_15_20  original_T_including_depot_unload_1301  2.5147997402163108e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_20  arc_capacity_1053  1
    load_1_15_20  free_load_conservation_1255  1
    load_1_15_20  free_load_conservation_1285  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_21  arc_capacity_1055  -25
    arc_1_15_21  connected_order_arc_1056  -13
    arc_1_15_21  out_degree_1250  1
    arc_1_15_21  in_degree_1287  1
    arc_1_15_21  original_T_including_depot_unload_1301  8.7684829846426385e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_21  arc_capacity_1055  1
    load_1_15_21  free_load_conservation_1255  1
    load_1_15_21  free_load_conservation_1291  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_22  arc_capacity_1057  -25
    arc_1_15_22  connected_order_arc_1058  -13
    arc_1_15_22  out_degree_1250  1
    arc_1_15_22  in_degree_1293  1
    arc_1_15_22  original_T_including_depot_unload_1301  2.9098466309579254e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_22  arc_capacity_1057  1
    load_1_15_22  free_load_conservation_1255  1
    load_1_15_22  free_load_conservation_1297  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_0  arc_capacity_1059  -25
    arc_1_16_0  depot_return_or_bypass_1221  1
    arc_1_16_0  out_degree_1256  1
    arc_1_16_0  original_T_including_depot_unload_1301  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_0  arc_capacity_1059  1
    load_1_16_0  free_load_conservation_1261  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_7  arc_capacity_1060  -25
    arc_1_16_7  connected_order_arc_1061  -13
    arc_1_16_7  in_degree_1223  1
    arc_1_16_7  out_degree_1256  1
    arc_1_16_7  original_T_including_depot_unload_1301  1.3600272346134373e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_7  arc_capacity_1060  1
    load_1_16_7  segment_load_conservation_1226  -1
    load_1_16_7  segment_prefix_lb_1227  1
    load_1_16_7  segment_prefix_ub_1228  1
    load_1_16_7  free_load_conservation_1261  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_8  arc_capacity_1062  -25
    arc_1_16_8  connected_order_arc_1063  -13
    arc_1_16_8  in_degree_1230  1
    arc_1_16_8  out_degree_1256  1
    arc_1_16_8  original_T_including_depot_unload_1301  1.0921272639748563e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_8  arc_capacity_1062  1
    load_1_16_8  segment_load_conservation_1233  -1
    load_1_16_8  segment_prefix_lb_1234  1
    load_1_16_8  segment_prefix_ub_1235  1
    load_1_16_8  free_load_conservation_1261  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_9  arc_capacity_1064  -25
    arc_1_16_9  connected_order_arc_1065  -13
    arc_1_16_9  in_degree_1237  1
    arc_1_16_9  out_degree_1256  1
    arc_1_16_9  original_T_including_depot_unload_1301  6.7803521648175558e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_9  arc_capacity_1064  1
    load_1_16_9  segment_load_conservation_1240  -1
    load_1_16_9  segment_prefix_lb_1241  1
    load_1_16_9  segment_prefix_ub_1242  1
    load_1_16_9  free_load_conservation_1261  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_10  arc_capacity_1066  -25
    arc_1_16_10  connected_order_arc_1067  -13
    arc_1_16_10  in_degree_1244  1
    arc_1_16_10  out_degree_1256  1
    arc_1_16_10  original_T_including_depot_unload_1301  6.1704611580490348e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_10  arc_capacity_1066  1
    load_1_16_10  segment_load_conservation_1247  -1
    load_1_16_10  segment_prefix_lb_1248  1
    load_1_16_10  segment_prefix_ub_1249  1
    load_1_16_10  free_load_conservation_1261  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_15  arc_capacity_1068  -25
    arc_1_16_15  connected_order_arc_1069  -13
    arc_1_16_15  in_degree_1251  1
    arc_1_16_15  out_degree_1256  1
    arc_1_16_15  original_T_including_depot_unload_1301  1.6597164064313077e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_15  arc_capacity_1068  1
    load_1_16_15  free_load_conservation_1255  -1
    load_1_16_15  free_load_conservation_1261  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_17  arc_capacity_1070  -25
    arc_1_16_17  connected_order_arc_1071  -13
    arc_1_16_17  out_degree_1256  1
    arc_1_16_17  in_degree_1263  1
    arc_1_16_17  original_T_including_depot_unload_1301  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_17  arc_capacity_1070  1
    load_1_16_17  free_load_conservation_1261  1
    load_1_16_17  free_load_conservation_1267  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_18  arc_capacity_1072  -25
    arc_1_16_18  connected_order_arc_1073  -13
    arc_1_16_18  out_degree_1256  1
    arc_1_16_18  in_degree_1269  1
    arc_1_16_18  original_T_including_depot_unload_1301  3.8790073962518773e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_18  arc_capacity_1072  1
    load_1_16_18  free_load_conservation_1261  1
    load_1_16_18  free_load_conservation_1273  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_19  arc_capacity_1074  -25
    arc_1_16_19  connected_order_arc_1075  -13
    arc_1_16_19  out_degree_1256  1
    arc_1_16_19  in_degree_1275  1
    arc_1_16_19  original_T_including_depot_unload_1301  1.4150780419437449e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_19  arc_capacity_1074  1
    load_1_16_19  free_load_conservation_1261  1
    load_1_16_19  free_load_conservation_1279  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_20  arc_capacity_1076  -25
    arc_1_16_20  connected_order_arc_1077  -13
    arc_1_16_20  out_degree_1256  1
    arc_1_16_20  in_degree_1281  1
    arc_1_16_20  original_T_including_depot_unload_1301  2.3649901674897566e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_20  arc_capacity_1076  1
    load_1_16_20  free_load_conservation_1261  1
    load_1_16_20  free_load_conservation_1285  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_21  arc_capacity_1078  -25
    arc_1_16_21  connected_order_arc_1079  -13
    arc_1_16_21  out_degree_1256  1
    arc_1_16_21  in_degree_1287  1
    arc_1_16_21  original_T_including_depot_unload_1301  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_21  arc_capacity_1078  1
    load_1_16_21  free_load_conservation_1261  1
    load_1_16_21  free_load_conservation_1291  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_22  arc_capacity_1080  -25
    arc_1_16_22  connected_order_arc_1081  -13
    arc_1_16_22  out_degree_1256  1
    arc_1_16_22  in_degree_1293  1
    arc_1_16_22  original_T_including_depot_unload_1301  4.3129452098285111e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_22  arc_capacity_1080  1
    load_1_16_22  free_load_conservation_1261  1
    load_1_16_22  free_load_conservation_1297  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_0  arc_capacity_1082  -25
    arc_1_17_0  depot_return_or_bypass_1221  1
    arc_1_17_0  out_degree_1262  1
    arc_1_17_0  original_T_including_depot_unload_1301  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_0  arc_capacity_1082  1
    load_1_17_0  free_load_conservation_1267  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_7  arc_capacity_1083  -25
    arc_1_17_7  connected_order_arc_1084  -13
    arc_1_17_7  in_degree_1223  1
    arc_1_17_7  out_degree_1262  1
    arc_1_17_7  original_T_including_depot_unload_1301  7.3227602527872671e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_7  arc_capacity_1083  1
    load_1_17_7  segment_load_conservation_1226  -1
    load_1_17_7  segment_prefix_lb_1227  1
    load_1_17_7  segment_prefix_ub_1228  1
    load_1_17_7  free_load_conservation_1267  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_8  arc_capacity_1085  -25
    arc_1_17_8  connected_order_arc_1086  -13
    arc_1_17_8  in_degree_1230  1
    arc_1_17_8  out_degree_1262  1
    arc_1_17_8  original_T_including_depot_unload_1301  1.3626829404511475e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_8  arc_capacity_1085  1
    load_1_17_8  segment_load_conservation_1233  -1
    load_1_17_8  segment_prefix_lb_1234  1
    load_1_17_8  segment_prefix_ub_1235  1
    load_1_17_8  free_load_conservation_1267  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_9  arc_capacity_1087  -25
    arc_1_17_9  connected_order_arc_1088  -13
    arc_1_17_9  in_degree_1237  1
    arc_1_17_9  out_degree_1262  1
    arc_1_17_9  original_T_including_depot_unload_1301  1.3823927712314810e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_9  arc_capacity_1087  1
    load_1_17_9  segment_load_conservation_1240  -1
    load_1_17_9  segment_prefix_lb_1241  1
    load_1_17_9  segment_prefix_ub_1242  1
    load_1_17_9  free_load_conservation_1267  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_10  arc_capacity_1089  -25
    arc_1_17_10  connected_order_arc_1090  -13
    arc_1_17_10  in_degree_1244  1
    arc_1_17_10  out_degree_1262  1
    arc_1_17_10  original_T_including_depot_unload_1301  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_10  arc_capacity_1089  1
    load_1_17_10  segment_load_conservation_1247  -1
    load_1_17_10  segment_prefix_lb_1248  1
    load_1_17_10  segment_prefix_ub_1249  1
    load_1_17_10  free_load_conservation_1267  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_15  arc_capacity_1091  -25
    arc_1_17_15  connected_order_arc_1092  -13
    arc_1_17_15  in_degree_1251  1
    arc_1_17_15  out_degree_1262  1
    arc_1_17_15  original_T_including_depot_unload_1301  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_15  arc_capacity_1091  1
    load_1_17_15  free_load_conservation_1255  -1
    load_1_17_15  free_load_conservation_1267  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_16  arc_capacity_1093  -25
    arc_1_17_16  connected_order_arc_1094  -13
    arc_1_17_16  in_degree_1257  1
    arc_1_17_16  out_degree_1262  1
    arc_1_17_16  original_T_including_depot_unload_1301  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_16  arc_capacity_1093  1
    load_1_17_16  free_load_conservation_1261  -1
    load_1_17_16  free_load_conservation_1267  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_18  arc_capacity_1095  -25
    arc_1_17_18  connected_order_arc_1096  -13
    arc_1_17_18  out_degree_1262  1
    arc_1_17_18  in_degree_1269  1
    arc_1_17_18  original_T_including_depot_unload_1301  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_18  arc_capacity_1095  1
    load_1_17_18  free_load_conservation_1267  1
    load_1_17_18  free_load_conservation_1273  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_19  arc_capacity_1097  -25
    arc_1_17_19  connected_order_arc_1098  -13
    arc_1_17_19  out_degree_1262  1
    arc_1_17_19  in_degree_1275  1
    arc_1_17_19  original_T_including_depot_unload_1301  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_19  arc_capacity_1097  1
    load_1_17_19  free_load_conservation_1267  1
    load_1_17_19  free_load_conservation_1279  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_20  arc_capacity_1099  -25
    arc_1_17_20  connected_order_arc_1100  -13
    arc_1_17_20  out_degree_1262  1
    arc_1_17_20  in_degree_1281  1
    arc_1_17_20  original_T_including_depot_unload_1301  1.6292966848558842e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_20  arc_capacity_1099  1
    load_1_17_20  free_load_conservation_1267  1
    load_1_17_20  free_load_conservation_1285  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_21  arc_capacity_1101  -25
    arc_1_17_21  connected_order_arc_1102  -13
    arc_1_17_21  out_degree_1262  1
    arc_1_17_21  in_degree_1287  1
    arc_1_17_21  original_T_including_depot_unload_1301  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_21  arc_capacity_1101  1
    load_1_17_21  free_load_conservation_1267  1
    load_1_17_21  free_load_conservation_1291  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_22  arc_capacity_1103  -25
    arc_1_17_22  connected_order_arc_1104  -13
    arc_1_17_22  out_degree_1262  1
    arc_1_17_22  in_degree_1293  1
    arc_1_17_22  original_T_including_depot_unload_1301  1.3727638439182763e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_22  arc_capacity_1103  1
    load_1_17_22  free_load_conservation_1267  1
    load_1_17_22  free_load_conservation_1297  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_0  arc_capacity_1105  -25
    arc_1_18_0  depot_return_or_bypass_1221  1
    arc_1_18_0  out_degree_1268  1
    arc_1_18_0  original_T_including_depot_unload_1301  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_0  arc_capacity_1105  1
    load_1_18_0  free_load_conservation_1273  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_7  arc_capacity_1106  -25
    arc_1_18_7  connected_order_arc_1107  -13
    arc_1_18_7  in_degree_1223  1
    arc_1_18_7  out_degree_1268  1
    arc_1_18_7  original_T_including_depot_unload_1301  1.1005939447212634e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_7  arc_capacity_1106  1
    load_1_18_7  segment_load_conservation_1226  -1
    load_1_18_7  segment_prefix_lb_1227  1
    load_1_18_7  segment_prefix_ub_1228  1
    load_1_18_7  free_load_conservation_1273  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_8  arc_capacity_1108  -25
    arc_1_18_8  connected_order_arc_1109  -13
    arc_1_18_8  in_degree_1230  1
    arc_1_18_8  out_degree_1268  1
    arc_1_18_8  original_T_including_depot_unload_1301  1.0453757248865720e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_8  arc_capacity_1108  1
    load_1_18_8  segment_load_conservation_1233  -1
    load_1_18_8  segment_prefix_lb_1234  1
    load_1_18_8  segment_prefix_ub_1235  1
    load_1_18_8  free_load_conservation_1273  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_9  arc_capacity_1110  -25
    arc_1_18_9  connected_order_arc_1111  -13
    arc_1_18_9  in_degree_1237  1
    arc_1_18_9  out_degree_1268  1
    arc_1_18_9  original_T_including_depot_unload_1301  7.0350721341213284e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_9  arc_capacity_1110  1
    load_1_18_9  segment_load_conservation_1240  -1
    load_1_18_9  segment_prefix_lb_1241  1
    load_1_18_9  segment_prefix_ub_1242  1
    load_1_18_9  free_load_conservation_1273  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_10  arc_capacity_1112  -25
    arc_1_18_10  connected_order_arc_1113  -13
    arc_1_18_10  in_degree_1244  1
    arc_1_18_10  out_degree_1268  1
    arc_1_18_10  original_T_including_depot_unload_1301  359.975566576564
    MARKER    'MARKER'                 'INTEND'
    load_1_18_10  arc_capacity_1112  1
    load_1_18_10  segment_load_conservation_1247  -1
    load_1_18_10  segment_prefix_lb_1248  1
    load_1_18_10  segment_prefix_ub_1249  1
    load_1_18_10  free_load_conservation_1273  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_15  arc_capacity_1114  -25
    arc_1_18_15  connected_order_arc_1115  -13
    arc_1_18_15  in_degree_1251  1
    arc_1_18_15  out_degree_1268  1
    arc_1_18_15  original_T_including_depot_unload_1301  2.4083746437975364e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_15  arc_capacity_1114  1
    load_1_18_15  free_load_conservation_1255  -1
    load_1_18_15  free_load_conservation_1273  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_16  arc_capacity_1116  -25
    arc_1_18_16  connected_order_arc_1117  -13
    arc_1_18_16  in_degree_1257  1
    arc_1_18_16  out_degree_1268  1
    arc_1_18_16  original_T_including_depot_unload_1301  3.8790073962518773e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_16  arc_capacity_1116  1
    load_1_18_16  free_load_conservation_1261  -1
    load_1_18_16  free_load_conservation_1273  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_17  arc_capacity_1118  -25
    arc_1_18_17  connected_order_arc_1119  -13
    arc_1_18_17  in_degree_1263  1
    arc_1_18_17  out_degree_1268  1
    arc_1_18_17  original_T_including_depot_unload_1301  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_17  arc_capacity_1118  1
    load_1_18_17  free_load_conservation_1267  -1
    load_1_18_17  free_load_conservation_1273  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_19  arc_capacity_1120  -25
    arc_1_18_19  connected_order_arc_1121  -13
    arc_1_18_19  out_degree_1268  1
    arc_1_18_19  in_degree_1275  1
    arc_1_18_19  original_T_including_depot_unload_1301  1.1544376314422677e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_19  arc_capacity_1120  1
    load_1_18_19  free_load_conservation_1273  1
    load_1_18_19  free_load_conservation_1279  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_20  arc_capacity_1122  -25
    arc_1_18_20  connected_order_arc_1123  -13
    arc_1_18_20  out_degree_1268  1
    arc_1_18_20  in_degree_1281  1
    arc_1_18_20  original_T_including_depot_unload_1301  4.7597588586788925e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_20  arc_capacity_1122  1
    load_1_18_20  free_load_conservation_1273  1
    load_1_18_20  free_load_conservation_1285  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_21  arc_capacity_1124  -25
    arc_1_18_21  connected_order_arc_1125  -13
    arc_1_18_21  out_degree_1268  1
    arc_1_18_21  in_degree_1287  1
    arc_1_18_21  original_T_including_depot_unload_1301  8.3486971116736720e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_21  arc_capacity_1124  1
    load_1_18_21  free_load_conservation_1273  1
    load_1_18_21  free_load_conservation_1291  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_22  arc_capacity_1126  -25
    arc_1_18_22  connected_order_arc_1127  -13
    arc_1_18_22  out_degree_1268  1
    arc_1_18_22  in_degree_1293  1
    arc_1_18_22  original_T_including_depot_unload_1301  3.2938591738444967e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_22  arc_capacity_1126  1
    load_1_18_22  free_load_conservation_1273  1
    load_1_18_22  free_load_conservation_1297  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_0  arc_capacity_1128  -25
    arc_1_19_0  depot_return_or_bypass_1221  1
    arc_1_19_0  out_degree_1274  1
    arc_1_19_0  original_T_including_depot_unload_1301  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_0  arc_capacity_1128  1
    load_1_19_0  free_load_conservation_1279  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_7  arc_capacity_1129  -25
    arc_1_19_7  connected_order_arc_1130  -13
    arc_1_19_7  in_degree_1223  1
    arc_1_19_7  out_degree_1274  1
    arc_1_19_7  original_T_including_depot_unload_1301  1.8442669473423912e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_7  arc_capacity_1129  1
    load_1_19_7  segment_load_conservation_1226  -1
    load_1_19_7  segment_prefix_lb_1227  1
    load_1_19_7  segment_prefix_ub_1228  1
    load_1_19_7  free_load_conservation_1279  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_8  arc_capacity_1131  -25
    arc_1_19_8  connected_order_arc_1132  -13
    arc_1_19_8  in_degree_1230  1
    arc_1_19_8  out_degree_1274  1
    arc_1_19_8  original_T_including_depot_unload_1301  2115.53677476792
    MARKER    'MARKER'                 'INTEND'
    load_1_19_8  arc_capacity_1131  1
    load_1_19_8  segment_load_conservation_1233  -1
    load_1_19_8  segment_prefix_lb_1234  1
    load_1_19_8  segment_prefix_ub_1235  1
    load_1_19_8  free_load_conservation_1279  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_9  arc_capacity_1133  -25
    arc_1_19_9  connected_order_arc_1134  -13
    arc_1_19_9  in_degree_1237  1
    arc_1_19_9  out_degree_1274  1
    arc_1_19_9  original_T_including_depot_unload_1301  1.8418804985785646e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_9  arc_capacity_1133  1
    load_1_19_9  segment_load_conservation_1240  -1
    load_1_19_9  segment_prefix_lb_1241  1
    load_1_19_9  segment_prefix_ub_1242  1
    load_1_19_9  free_load_conservation_1279  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_10  arc_capacity_1135  -25
    arc_1_19_10  connected_order_arc_1136  -13
    arc_1_19_10  in_degree_1244  1
    arc_1_19_10  out_degree_1274  1
    arc_1_19_10  original_T_including_depot_unload_1301  1.3857128117205509e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_10  arc_capacity_1135  1
    load_1_19_10  segment_load_conservation_1247  -1
    load_1_19_10  segment_prefix_lb_1248  1
    load_1_19_10  segment_prefix_ub_1249  1
    load_1_19_10  free_load_conservation_1279  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_15  arc_capacity_1137  -25
    arc_1_19_15  connected_order_arc_1138  -13
    arc_1_19_15  in_degree_1251  1
    arc_1_19_15  out_degree_1274  1
    arc_1_19_15  original_T_including_depot_unload_1301  1.2608612406747543e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_15  arc_capacity_1137  1
    load_1_19_15  free_load_conservation_1255  -1
    load_1_19_15  free_load_conservation_1279  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_16  arc_capacity_1139  -25
    arc_1_19_16  connected_order_arc_1140  -13
    arc_1_19_16  in_degree_1257  1
    arc_1_19_16  out_degree_1274  1
    arc_1_19_16  original_T_including_depot_unload_1301  1.4150780419437449e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_16  arc_capacity_1139  1
    load_1_19_16  free_load_conservation_1261  -1
    load_1_19_16  free_load_conservation_1279  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_17  arc_capacity_1141  -25
    arc_1_19_17  connected_order_arc_1142  -13
    arc_1_19_17  in_degree_1263  1
    arc_1_19_17  out_degree_1274  1
    arc_1_19_17  original_T_including_depot_unload_1301  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_17  arc_capacity_1141  1
    load_1_19_17  free_load_conservation_1267  -1
    load_1_19_17  free_load_conservation_1279  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_18  arc_capacity_1143  -25
    arc_1_19_18  connected_order_arc_1144  -13
    arc_1_19_18  in_degree_1269  1
    arc_1_19_18  out_degree_1274  1
    arc_1_19_18  original_T_including_depot_unload_1301  1.1544376314422677e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_18  arc_capacity_1143  1
    load_1_19_18  free_load_conservation_1273  -1
    load_1_19_18  free_load_conservation_1279  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_20  arc_capacity_1145  -25
    arc_1_19_20  connected_order_arc_1146  -13
    arc_1_19_20  out_degree_1274  1
    arc_1_19_20  in_degree_1281  1
    arc_1_19_20  original_T_including_depot_unload_1301  1.2927075446362680e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_20  arc_capacity_1145  1
    load_1_19_20  free_load_conservation_1279  1
    load_1_19_20  free_load_conservation_1285  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_21  arc_capacity_1147  -25
    arc_1_19_21  connected_order_arc_1148  -13
    arc_1_19_21  out_degree_1274  1
    arc_1_19_21  in_degree_1287  1
    arc_1_19_21  original_T_including_depot_unload_1301  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_21  arc_capacity_1147  1
    load_1_19_21  free_load_conservation_1279  1
    load_1_19_21  free_load_conservation_1291  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_22  arc_capacity_1149  -25
    arc_1_19_22  connected_order_arc_1150  -13
    arc_1_19_22  out_degree_1274  1
    arc_1_19_22  in_degree_1293  1
    arc_1_19_22  original_T_including_depot_unload_1301  9.8652191996938075e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_22  arc_capacity_1149  1
    load_1_19_22  free_load_conservation_1279  1
    load_1_19_22  free_load_conservation_1297  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_0  arc_capacity_1151  -25
    arc_1_20_0  depot_return_or_bypass_1221  1
    arc_1_20_0  out_degree_1280  1
    arc_1_20_0  original_T_including_depot_unload_1301  6.6653528395596720e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_0  arc_capacity_1151  1
    load_1_20_0  free_load_conservation_1285  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_7  arc_capacity_1152  -25
    arc_1_20_7  connected_order_arc_1153  -13
    arc_1_20_7  in_degree_1223  1
    arc_1_20_7  out_degree_1280  1
    arc_1_20_7  original_T_including_depot_unload_1301  1.5437191441012344e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_7  arc_capacity_1152  1
    load_1_20_7  segment_load_conservation_1226  -1
    load_1_20_7  segment_prefix_lb_1227  1
    load_1_20_7  segment_prefix_ub_1228  1
    load_1_20_7  free_load_conservation_1285  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_8  arc_capacity_1154  -25
    arc_1_20_8  connected_order_arc_1155  -13
    arc_1_20_8  in_degree_1230  1
    arc_1_20_8  out_degree_1280  1
    arc_1_20_8  original_T_including_depot_unload_1301  1.3251252487627862e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_8  arc_capacity_1154  1
    load_1_20_8  segment_load_conservation_1233  -1
    load_1_20_8  segment_prefix_lb_1234  1
    load_1_20_8  segment_prefix_ub_1235  1
    load_1_20_8  free_load_conservation_1285  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_9  arc_capacity_1156  -25
    arc_1_20_9  connected_order_arc_1157  -13
    arc_1_20_9  in_degree_1237  1
    arc_1_20_9  out_degree_1280  1
    arc_1_20_9  original_T_including_depot_unload_1301  9.1345700487521981e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_9  arc_capacity_1156  1
    load_1_20_9  segment_load_conservation_1240  -1
    load_1_20_9  segment_prefix_lb_1241  1
    load_1_20_9  segment_prefix_ub_1242  1
    load_1_20_9  free_load_conservation_1285  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_10  arc_capacity_1158  -25
    arc_1_20_10  connected_order_arc_1159  -13
    arc_1_20_10  in_degree_1244  1
    arc_1_20_10  out_degree_1280  1
    arc_1_20_10  original_T_including_depot_unload_1301  7.8830763320343567e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_10  arc_capacity_1158  1
    load_1_20_10  segment_load_conservation_1247  -1
    load_1_20_10  segment_prefix_lb_1248  1
    load_1_20_10  segment_prefix_ub_1249  1
    load_1_20_10  free_load_conservation_1285  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_15  arc_capacity_1160  -25
    arc_1_20_15  connected_order_arc_1161  -13
    arc_1_20_15  in_degree_1251  1
    arc_1_20_15  out_degree_1280  1
    arc_1_20_15  original_T_including_depot_unload_1301  2.5147997402163108e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_15  arc_capacity_1160  1
    load_1_20_15  free_load_conservation_1255  -1
    load_1_20_15  free_load_conservation_1285  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_16  arc_capacity_1162  -25
    arc_1_20_16  connected_order_arc_1163  -13
    arc_1_20_16  in_degree_1257  1
    arc_1_20_16  out_degree_1280  1
    arc_1_20_16  original_T_including_depot_unload_1301  2.3649901674897566e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_16  arc_capacity_1162  1
    load_1_20_16  free_load_conservation_1261  -1
    load_1_20_16  free_load_conservation_1285  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_17  arc_capacity_1164  -25
    arc_1_20_17  connected_order_arc_1165  -13
    arc_1_20_17  in_degree_1263  1
    arc_1_20_17  out_degree_1280  1
    arc_1_20_17  original_T_including_depot_unload_1301  1.6292966848558842e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_17  arc_capacity_1164  1
    load_1_20_17  free_load_conservation_1267  -1
    load_1_20_17  free_load_conservation_1285  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_18  arc_capacity_1166  -25
    arc_1_20_18  connected_order_arc_1167  -13
    arc_1_20_18  in_degree_1269  1
    arc_1_20_18  out_degree_1280  1
    arc_1_20_18  original_T_including_depot_unload_1301  4.7597588586788925e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_18  arc_capacity_1166  1
    load_1_20_18  free_load_conservation_1273  -1
    load_1_20_18  free_load_conservation_1285  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_19  arc_capacity_1168  -25
    arc_1_20_19  connected_order_arc_1169  -13
    arc_1_20_19  in_degree_1275  1
    arc_1_20_19  out_degree_1280  1
    arc_1_20_19  original_T_including_depot_unload_1301  1.2927075446362680e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_19  arc_capacity_1168  1
    load_1_20_19  free_load_conservation_1279  -1
    load_1_20_19  free_load_conservation_1285  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_21  arc_capacity_1170  -25
    arc_1_20_21  connected_order_arc_1171  -13
    arc_1_20_21  out_degree_1280  1
    arc_1_20_21  in_degree_1287  1
    arc_1_20_21  original_T_including_depot_unload_1301  1.0758099325648966e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_21  arc_capacity_1170  1
    load_1_20_21  free_load_conservation_1285  1
    load_1_20_21  free_load_conservation_1291  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_22  arc_capacity_1172  -25
    arc_1_20_22  connected_order_arc_1173  -13
    arc_1_20_22  out_degree_1280  1
    arc_1_20_22  in_degree_1293  1
    arc_1_20_22  original_T_including_depot_unload_1301  3.2985327387120213e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_22  arc_capacity_1172  1
    load_1_20_22  free_load_conservation_1285  1
    load_1_20_22  free_load_conservation_1297  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_0  arc_capacity_1174  -25
    arc_1_21_0  depot_return_or_bypass_1221  1
    arc_1_21_0  out_degree_1286  1
    arc_1_21_0  original_T_including_depot_unload_1301  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_0  arc_capacity_1174  1
    load_1_21_0  free_load_conservation_1291  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_7  arc_capacity_1175  -25
    arc_1_21_7  connected_order_arc_1176  -13
    arc_1_21_7  in_degree_1223  1
    arc_1_21_7  out_degree_1286  1
    arc_1_21_7  original_T_including_depot_unload_1301  8.1417957710766450e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_7  arc_capacity_1175  1
    load_1_21_7  segment_load_conservation_1226  -1
    load_1_21_7  segment_prefix_lb_1227  1
    load_1_21_7  segment_prefix_ub_1228  1
    load_1_21_7  free_load_conservation_1291  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_8  arc_capacity_1177  -25
    arc_1_21_8  connected_order_arc_1178  -13
    arc_1_21_8  in_degree_1230  1
    arc_1_21_8  out_degree_1286  1
    arc_1_21_8  original_T_including_depot_unload_1301  2.5572087458878266e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_8  arc_capacity_1177  1
    load_1_21_8  segment_load_conservation_1233  -1
    load_1_21_8  segment_prefix_lb_1234  1
    load_1_21_8  segment_prefix_ub_1235  1
    load_1_21_8  free_load_conservation_1291  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_9  arc_capacity_1179  -25
    arc_1_21_9  connected_order_arc_1180  -13
    arc_1_21_9  in_degree_1237  1
    arc_1_21_9  out_degree_1286  1
    arc_1_21_9  original_T_including_depot_unload_1301  1.6444540482789353e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_9  arc_capacity_1179  1
    load_1_21_9  segment_load_conservation_1240  -1
    load_1_21_9  segment_prefix_lb_1241  1
    load_1_21_9  segment_prefix_ub_1242  1
    load_1_21_9  free_load_conservation_1291  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_10  arc_capacity_1181  -25
    arc_1_21_10  connected_order_arc_1182  -13
    arc_1_21_10  in_degree_1244  1
    arc_1_21_10  out_degree_1286  1
    arc_1_21_10  original_T_including_depot_unload_1301  5.7102904773674652e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_10  arc_capacity_1181  1
    load_1_21_10  segment_load_conservation_1247  -1
    load_1_21_10  segment_prefix_lb_1248  1
    load_1_21_10  segment_prefix_ub_1249  1
    load_1_21_10  free_load_conservation_1291  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_15  arc_capacity_1183  -25
    arc_1_21_15  connected_order_arc_1184  -13
    arc_1_21_15  in_degree_1251  1
    arc_1_21_15  out_degree_1286  1
    arc_1_21_15  original_T_including_depot_unload_1301  8.7684829846426385e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_15  arc_capacity_1183  1
    load_1_21_15  free_load_conservation_1255  -1
    load_1_21_15  free_load_conservation_1291  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_16  arc_capacity_1185  -25
    arc_1_21_16  connected_order_arc_1186  -13
    arc_1_21_16  in_degree_1257  1
    arc_1_21_16  out_degree_1286  1
    arc_1_21_16  original_T_including_depot_unload_1301  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_16  arc_capacity_1185  1
    load_1_21_16  free_load_conservation_1261  -1
    load_1_21_16  free_load_conservation_1291  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_17  arc_capacity_1187  -25
    arc_1_21_17  connected_order_arc_1188  -13
    arc_1_21_17  in_degree_1263  1
    arc_1_21_17  out_degree_1286  1
    arc_1_21_17  original_T_including_depot_unload_1301  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_17  arc_capacity_1187  1
    load_1_21_17  free_load_conservation_1267  -1
    load_1_21_17  free_load_conservation_1291  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_18  arc_capacity_1189  -25
    arc_1_21_18  connected_order_arc_1190  -13
    arc_1_21_18  in_degree_1269  1
    arc_1_21_18  out_degree_1286  1
    arc_1_21_18  original_T_including_depot_unload_1301  8.3486971116736720e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_18  arc_capacity_1189  1
    load_1_21_18  free_load_conservation_1273  -1
    load_1_21_18  free_load_conservation_1291  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_19  arc_capacity_1191  -25
    arc_1_21_19  connected_order_arc_1192  -13
    arc_1_21_19  in_degree_1275  1
    arc_1_21_19  out_degree_1286  1
    arc_1_21_19  original_T_including_depot_unload_1301  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_19  arc_capacity_1191  1
    load_1_21_19  free_load_conservation_1279  -1
    load_1_21_19  free_load_conservation_1291  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_20  arc_capacity_1193  -25
    arc_1_21_20  connected_order_arc_1194  -13
    arc_1_21_20  in_degree_1281  1
    arc_1_21_20  out_degree_1286  1
    arc_1_21_20  original_T_including_depot_unload_1301  1.0758099325648966e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_20  arc_capacity_1193  1
    load_1_21_20  free_load_conservation_1285  -1
    load_1_21_20  free_load_conservation_1291  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_22  arc_capacity_1195  -25
    arc_1_21_22  connected_order_arc_1196  -13
    arc_1_21_22  out_degree_1286  1
    arc_1_21_22  in_degree_1293  1
    arc_1_21_22  original_T_including_depot_unload_1301  1.1341050580477483e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_22  arc_capacity_1195  1
    load_1_21_22  free_load_conservation_1291  1
    load_1_21_22  free_load_conservation_1297  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_0  arc_capacity_1197  -25
    arc_1_22_0  depot_return_or_bypass_1221  1
    arc_1_22_0  out_degree_1292  1
    arc_1_22_0  original_T_including_depot_unload_1301  5.9431738885389052e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_0  arc_capacity_1197  1
    load_1_22_0  free_load_conservation_1297  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_7  arc_capacity_1198  -25
    arc_1_22_7  connected_order_arc_1199  -13
    arc_1_22_7  in_degree_1223  1
    arc_1_22_7  out_degree_1292  1
    arc_1_22_7  original_T_including_depot_unload_1301  1.4171530684324468e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_22_7  arc_capacity_1198  1
    load_1_22_7  segment_load_conservation_1226  -1
    load_1_22_7  segment_prefix_lb_1227  1
    load_1_22_7  segment_prefix_ub_1228  1
    load_1_22_7  free_load_conservation_1297  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_8  arc_capacity_1200  -25
    arc_1_22_8  connected_order_arc_1201  -13
    arc_1_22_8  in_degree_1230  1
    arc_1_22_8  out_degree_1292  1
    arc_1_22_8  original_T_including_depot_unload_1301  1.3593311700505531e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_22_8  arc_capacity_1200  1
    load_1_22_8  segment_load_conservation_1233  -1
    load_1_22_8  segment_prefix_lb_1234  1
    load_1_22_8  segment_prefix_ub_1235  1
    load_1_22_8  free_load_conservation_1297  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_9  arc_capacity_1202  -25
    arc_1_22_9  connected_order_arc_1203  -13
    arc_1_22_9  in_degree_1237  1
    arc_1_22_9  out_degree_1292  1
    arc_1_22_9  original_T_including_depot_unload_1301  987.973588780524
    MARKER    'MARKER'                 'INTEND'
    load_1_22_9  arc_capacity_1202  1
    load_1_22_9  segment_load_conservation_1240  -1
    load_1_22_9  segment_prefix_lb_1241  1
    load_1_22_9  segment_prefix_ub_1242  1
    load_1_22_9  free_load_conservation_1297  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_10  arc_capacity_1204  -25
    arc_1_22_10  connected_order_arc_1205  -13
    arc_1_22_10  in_degree_1244  1
    arc_1_22_10  out_degree_1292  1
    arc_1_22_10  original_T_including_depot_unload_1301  6.8881953094806647e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_10  arc_capacity_1204  1
    load_1_22_10  segment_load_conservation_1247  -1
    load_1_22_10  segment_prefix_lb_1248  1
    load_1_22_10  segment_prefix_ub_1249  1
    load_1_22_10  free_load_conservation_1297  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_15  arc_capacity_1206  -25
    arc_1_22_15  connected_order_arc_1207  -13
    arc_1_22_15  in_degree_1251  1
    arc_1_22_15  out_degree_1292  1
    arc_1_22_15  original_T_including_depot_unload_1301  2.9098466309579254e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_15  arc_capacity_1206  1
    load_1_22_15  free_load_conservation_1255  -1
    load_1_22_15  free_load_conservation_1297  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_16  arc_capacity_1208  -25
    arc_1_22_16  connected_order_arc_1209  -13
    arc_1_22_16  in_degree_1257  1
    arc_1_22_16  out_degree_1292  1
    arc_1_22_16  original_T_including_depot_unload_1301  4.3129452098285111e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_16  arc_capacity_1208  1
    load_1_22_16  free_load_conservation_1261  -1
    load_1_22_16  free_load_conservation_1297  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_17  arc_capacity_1210  -25
    arc_1_22_17  connected_order_arc_1211  -13
    arc_1_22_17  in_degree_1263  1
    arc_1_22_17  out_degree_1292  1
    arc_1_22_17  original_T_including_depot_unload_1301  1.3727638439182763e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_22_17  arc_capacity_1210  1
    load_1_22_17  free_load_conservation_1267  -1
    load_1_22_17  free_load_conservation_1297  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_18  arc_capacity_1212  -25
    arc_1_22_18  connected_order_arc_1213  -13
    arc_1_22_18  in_degree_1269  1
    arc_1_22_18  out_degree_1292  1
    arc_1_22_18  original_T_including_depot_unload_1301  3.2938591738444967e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_18  arc_capacity_1212  1
    load_1_22_18  free_load_conservation_1273  -1
    load_1_22_18  free_load_conservation_1297  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_19  arc_capacity_1214  -25
    arc_1_22_19  connected_order_arc_1215  -13
    arc_1_22_19  in_degree_1275  1
    arc_1_22_19  out_degree_1292  1
    arc_1_22_19  original_T_including_depot_unload_1301  9.8652191996938075e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_19  arc_capacity_1214  1
    load_1_22_19  free_load_conservation_1279  -1
    load_1_22_19  free_load_conservation_1297  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_20  arc_capacity_1216  -25
    arc_1_22_20  connected_order_arc_1217  -13
    arc_1_22_20  in_degree_1281  1
    arc_1_22_20  out_degree_1292  1
    arc_1_22_20  original_T_including_depot_unload_1301  3.2985327387120213e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_20  arc_capacity_1216  1
    load_1_22_20  free_load_conservation_1285  -1
    load_1_22_20  free_load_conservation_1297  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_21  arc_capacity_1218  -25
    arc_1_22_21  connected_order_arc_1219  -13
    arc_1_22_21  in_degree_1287  1
    arc_1_22_21  out_degree_1292  1
    arc_1_22_21  original_T_including_depot_unload_1301  1.1341050580477483e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_22_21  arc_capacity_1218  1
    load_1_22_21  free_load_conservation_1291  -1
    load_1_22_21  free_load_conservation_1297  1
    visit_2_11  out_degree_1593  -1
    visit_2_11  in_degree_1594  -1
    visit_2_11  order_active_lb_1595  -1
    visit_2_11  order_active_ub_1596  -12
    order_2_11  connected_order_arc_1317  -1
    order_2_11  connected_order_arc_1319  -1
    order_2_11  connected_order_arc_1321  -1
    order_2_11  connected_order_arc_1323  -1
    order_2_11  connected_order_arc_1325  -1
    order_2_11  connected_order_arc_1327  -1
    order_2_11  connected_order_arc_1329  -1
    order_2_11  connected_order_arc_1331  -1
    order_2_11  connected_order_arc_1333  -1
    order_2_11  connected_order_arc_1335  -1
    order_2_11  connected_order_arc_1337  -1
    order_2_11  connected_order_arc_1340  1
    order_2_11  connected_order_arc_1363  1
    order_2_11  connected_order_arc_1386  1
    order_2_11  connected_order_arc_1409  1
    order_2_11  connected_order_arc_1432  1
    order_2_11  connected_order_arc_1455  1
    order_2_11  connected_order_arc_1478  1
    order_2_11  connected_order_arc_1501  1
    order_2_11  connected_order_arc_1524  1
    order_2_11  connected_order_arc_1547  1
    order_2_11  connected_order_arc_1570  1
    order_2_11  order_active_lb_1595  1
    order_2_11  order_active_ub_1596  1
    order_2_11  fixed_segment_relative_order_1669  -1
    visit_2_12  out_degree_1600  -1
    visit_2_12  in_degree_1601  -1
    visit_2_12  order_active_lb_1602  -1
    visit_2_12  order_active_ub_1603  -12
    order_2_12  connected_order_arc_1317  1
    order_2_12  connected_order_arc_1340  -1
    order_2_12  connected_order_arc_1342  -1
    order_2_12  connected_order_arc_1344  -1
    order_2_12  connected_order_arc_1346  -1
    order_2_12  connected_order_arc_1348  -1
    order_2_12  connected_order_arc_1350  -1
    order_2_12  connected_order_arc_1352  -1
    order_2_12  connected_order_arc_1354  -1
    order_2_12  connected_order_arc_1356  -1
    order_2_12  connected_order_arc_1358  -1
    order_2_12  connected_order_arc_1360  -1
    order_2_12  connected_order_arc_1365  1
    order_2_12  connected_order_arc_1388  1
    order_2_12  connected_order_arc_1411  1
    order_2_12  connected_order_arc_1434  1
    order_2_12  connected_order_arc_1457  1
    order_2_12  connected_order_arc_1480  1
    order_2_12  connected_order_arc_1503  1
    order_2_12  connected_order_arc_1526  1
    order_2_12  connected_order_arc_1549  1
    order_2_12  connected_order_arc_1572  1
    order_2_12  order_active_lb_1602  1
    order_2_12  order_active_ub_1603  1
    order_2_12  fixed_segment_relative_order_1669  1
    order_2_12  fixed_segment_relative_order_1670  -1
    visit_2_13  out_degree_1607  -1
    visit_2_13  in_degree_1608  -1
    visit_2_13  order_active_lb_1609  -1
    visit_2_13  order_active_ub_1610  -12
    order_2_13  connected_order_arc_1319  1
    order_2_13  connected_order_arc_1342  1
    order_2_13  connected_order_arc_1363  -1
    order_2_13  connected_order_arc_1365  -1
    order_2_13  connected_order_arc_1367  -1
    order_2_13  connected_order_arc_1369  -1
    order_2_13  connected_order_arc_1371  -1
    order_2_13  connected_order_arc_1373  -1
    order_2_13  connected_order_arc_1375  -1
    order_2_13  connected_order_arc_1377  -1
    order_2_13  connected_order_arc_1379  -1
    order_2_13  connected_order_arc_1381  -1
    order_2_13  connected_order_arc_1383  -1
    order_2_13  connected_order_arc_1390  1
    order_2_13  connected_order_arc_1413  1
    order_2_13  connected_order_arc_1436  1
    order_2_13  connected_order_arc_1459  1
    order_2_13  connected_order_arc_1482  1
    order_2_13  connected_order_arc_1505  1
    order_2_13  connected_order_arc_1528  1
    order_2_13  connected_order_arc_1551  1
    order_2_13  connected_order_arc_1574  1
    order_2_13  order_active_lb_1609  1
    order_2_13  order_active_ub_1610  1
    order_2_13  fixed_segment_relative_order_1670  1
    order_2_13  fixed_segment_relative_order_1671  -1
    visit_2_14  out_degree_1614  -1
    visit_2_14  in_degree_1615  -1
    visit_2_14  order_active_lb_1616  -1
    visit_2_14  order_active_ub_1617  -12
    order_2_14  connected_order_arc_1321  1
    order_2_14  connected_order_arc_1344  1
    order_2_14  connected_order_arc_1367  1
    order_2_14  connected_order_arc_1386  -1
    order_2_14  connected_order_arc_1388  -1
    order_2_14  connected_order_arc_1390  -1
    order_2_14  connected_order_arc_1392  -1
    order_2_14  connected_order_arc_1394  -1
    order_2_14  connected_order_arc_1396  -1
    order_2_14  connected_order_arc_1398  -1
    order_2_14  connected_order_arc_1400  -1
    order_2_14  connected_order_arc_1402  -1
    order_2_14  connected_order_arc_1404  -1
    order_2_14  connected_order_arc_1406  -1
    order_2_14  connected_order_arc_1415  1
    order_2_14  connected_order_arc_1438  1
    order_2_14  connected_order_arc_1461  1
    order_2_14  connected_order_arc_1484  1
    order_2_14  connected_order_arc_1507  1
    order_2_14  connected_order_arc_1530  1
    order_2_14  connected_order_arc_1553  1
    order_2_14  connected_order_arc_1576  1
    order_2_14  order_active_lb_1616  1
    order_2_14  order_active_ub_1617  1
    order_2_14  fixed_segment_relative_order_1671  1
    visit_2_15  out_degree_1621  -1
    visit_2_15  in_degree_1622  -1
    visit_2_15  order_active_lb_1623  -1
    visit_2_15  order_active_ub_1624  -12
    visit_2_15  service_visit_def_1625  -1
    order_2_15  connected_order_arc_1323  1
    order_2_15  connected_order_arc_1346  1
    order_2_15  connected_order_arc_1369  1
    order_2_15  connected_order_arc_1392  1
    order_2_15  connected_order_arc_1409  -1
    order_2_15  connected_order_arc_1411  -1
    order_2_15  connected_order_arc_1413  -1
    order_2_15  connected_order_arc_1415  -1
    order_2_15  connected_order_arc_1417  -1
    order_2_15  connected_order_arc_1419  -1
    order_2_15  connected_order_arc_1421  -1
    order_2_15  connected_order_arc_1423  -1
    order_2_15  connected_order_arc_1425  -1
    order_2_15  connected_order_arc_1427  -1
    order_2_15  connected_order_arc_1429  -1
    order_2_15  connected_order_arc_1440  1
    order_2_15  connected_order_arc_1463  1
    order_2_15  connected_order_arc_1486  1
    order_2_15  connected_order_arc_1509  1
    order_2_15  connected_order_arc_1532  1
    order_2_15  connected_order_arc_1555  1
    order_2_15  connected_order_arc_1578  1
    order_2_15  order_active_lb_1623  1
    order_2_15  order_active_ub_1624  1
    visit_2_16  out_degree_1627  -1
    visit_2_16  in_degree_1628  -1
    visit_2_16  order_active_lb_1629  -1
    visit_2_16  order_active_ub_1630  -12
    visit_2_16  service_visit_def_1631  -1
    order_2_16  connected_order_arc_1325  1
    order_2_16  connected_order_arc_1348  1
    order_2_16  connected_order_arc_1371  1
    order_2_16  connected_order_arc_1394  1
    order_2_16  connected_order_arc_1417  1
    order_2_16  connected_order_arc_1432  -1
    order_2_16  connected_order_arc_1434  -1
    order_2_16  connected_order_arc_1436  -1
    order_2_16  connected_order_arc_1438  -1
    order_2_16  connected_order_arc_1440  -1
    order_2_16  connected_order_arc_1442  -1
    order_2_16  connected_order_arc_1444  -1
    order_2_16  connected_order_arc_1446  -1
    order_2_16  connected_order_arc_1448  -1
    order_2_16  connected_order_arc_1450  -1
    order_2_16  connected_order_arc_1452  -1
    order_2_16  connected_order_arc_1465  1
    order_2_16  connected_order_arc_1488  1
    order_2_16  connected_order_arc_1511  1
    order_2_16  connected_order_arc_1534  1
    order_2_16  connected_order_arc_1557  1
    order_2_16  connected_order_arc_1580  1
    order_2_16  order_active_lb_1629  1
    order_2_16  order_active_ub_1630  1
    visit_2_17  out_degree_1633  -1
    visit_2_17  in_degree_1634  -1
    visit_2_17  order_active_lb_1635  -1
    visit_2_17  order_active_ub_1636  -12
    visit_2_17  service_visit_def_1637  -1
    order_2_17  connected_order_arc_1327  1
    order_2_17  connected_order_arc_1350  1
    order_2_17  connected_order_arc_1373  1
    order_2_17  connected_order_arc_1396  1
    order_2_17  connected_order_arc_1419  1
    order_2_17  connected_order_arc_1442  1
    order_2_17  connected_order_arc_1455  -1
    order_2_17  connected_order_arc_1457  -1
    order_2_17  connected_order_arc_1459  -1
    order_2_17  connected_order_arc_1461  -1
    order_2_17  connected_order_arc_1463  -1
    order_2_17  connected_order_arc_1465  -1
    order_2_17  connected_order_arc_1467  -1
    order_2_17  connected_order_arc_1469  -1
    order_2_17  connected_order_arc_1471  -1
    order_2_17  connected_order_arc_1473  -1
    order_2_17  connected_order_arc_1475  -1
    order_2_17  connected_order_arc_1490  1
    order_2_17  connected_order_arc_1513  1
    order_2_17  connected_order_arc_1536  1
    order_2_17  connected_order_arc_1559  1
    order_2_17  connected_order_arc_1582  1
    order_2_17  order_active_lb_1635  1
    order_2_17  order_active_ub_1636  1
    visit_2_18  out_degree_1639  -1
    visit_2_18  in_degree_1640  -1
    visit_2_18  order_active_lb_1641  -1
    visit_2_18  order_active_ub_1642  -12
    visit_2_18  service_visit_def_1643  -1
    order_2_18  connected_order_arc_1329  1
    order_2_18  connected_order_arc_1352  1
    order_2_18  connected_order_arc_1375  1
    order_2_18  connected_order_arc_1398  1
    order_2_18  connected_order_arc_1421  1
    order_2_18  connected_order_arc_1444  1
    order_2_18  connected_order_arc_1467  1
    order_2_18  connected_order_arc_1478  -1
    order_2_18  connected_order_arc_1480  -1
    order_2_18  connected_order_arc_1482  -1
    order_2_18  connected_order_arc_1484  -1
    order_2_18  connected_order_arc_1486  -1
    order_2_18  connected_order_arc_1488  -1
    order_2_18  connected_order_arc_1490  -1
    order_2_18  connected_order_arc_1492  -1
    order_2_18  connected_order_arc_1494  -1
    order_2_18  connected_order_arc_1496  -1
    order_2_18  connected_order_arc_1498  -1
    order_2_18  connected_order_arc_1515  1
    order_2_18  connected_order_arc_1538  1
    order_2_18  connected_order_arc_1561  1
    order_2_18  connected_order_arc_1584  1
    order_2_18  order_active_lb_1641  1
    order_2_18  order_active_ub_1642  1
    visit_2_19  out_degree_1645  -1
    visit_2_19  in_degree_1646  -1
    visit_2_19  order_active_lb_1647  -1
    visit_2_19  order_active_ub_1648  -12
    visit_2_19  service_visit_def_1649  -1
    order_2_19  connected_order_arc_1331  1
    order_2_19  connected_order_arc_1354  1
    order_2_19  connected_order_arc_1377  1
    order_2_19  connected_order_arc_1400  1
    order_2_19  connected_order_arc_1423  1
    order_2_19  connected_order_arc_1446  1
    order_2_19  connected_order_arc_1469  1
    order_2_19  connected_order_arc_1492  1
    order_2_19  connected_order_arc_1501  -1
    order_2_19  connected_order_arc_1503  -1
    order_2_19  connected_order_arc_1505  -1
    order_2_19  connected_order_arc_1507  -1
    order_2_19  connected_order_arc_1509  -1
    order_2_19  connected_order_arc_1511  -1
    order_2_19  connected_order_arc_1513  -1
    order_2_19  connected_order_arc_1515  -1
    order_2_19  connected_order_arc_1517  -1
    order_2_19  connected_order_arc_1519  -1
    order_2_19  connected_order_arc_1521  -1
    order_2_19  connected_order_arc_1540  1
    order_2_19  connected_order_arc_1563  1
    order_2_19  connected_order_arc_1586  1
    order_2_19  order_active_lb_1647  1
    order_2_19  order_active_ub_1648  1
    visit_2_20  out_degree_1651  -1
    visit_2_20  in_degree_1652  -1
    visit_2_20  order_active_lb_1653  -1
    visit_2_20  order_active_ub_1654  -12
    visit_2_20  service_visit_def_1655  -1
    order_2_20  connected_order_arc_1333  1
    order_2_20  connected_order_arc_1356  1
    order_2_20  connected_order_arc_1379  1
    order_2_20  connected_order_arc_1402  1
    order_2_20  connected_order_arc_1425  1
    order_2_20  connected_order_arc_1448  1
    order_2_20  connected_order_arc_1471  1
    order_2_20  connected_order_arc_1494  1
    order_2_20  connected_order_arc_1517  1
    order_2_20  connected_order_arc_1524  -1
    order_2_20  connected_order_arc_1526  -1
    order_2_20  connected_order_arc_1528  -1
    order_2_20  connected_order_arc_1530  -1
    order_2_20  connected_order_arc_1532  -1
    order_2_20  connected_order_arc_1534  -1
    order_2_20  connected_order_arc_1536  -1
    order_2_20  connected_order_arc_1538  -1
    order_2_20  connected_order_arc_1540  -1
    order_2_20  connected_order_arc_1542  -1
    order_2_20  connected_order_arc_1544  -1
    order_2_20  connected_order_arc_1565  1
    order_2_20  connected_order_arc_1588  1
    order_2_20  order_active_lb_1653  1
    order_2_20  order_active_ub_1654  1
    visit_2_21  out_degree_1657  -1
    visit_2_21  in_degree_1658  -1
    visit_2_21  order_active_lb_1659  -1
    visit_2_21  order_active_ub_1660  -12
    visit_2_21  service_visit_def_1661  -1
    order_2_21  connected_order_arc_1335  1
    order_2_21  connected_order_arc_1358  1
    order_2_21  connected_order_arc_1381  1
    order_2_21  connected_order_arc_1404  1
    order_2_21  connected_order_arc_1427  1
    order_2_21  connected_order_arc_1450  1
    order_2_21  connected_order_arc_1473  1
    order_2_21  connected_order_arc_1496  1
    order_2_21  connected_order_arc_1519  1
    order_2_21  connected_order_arc_1542  1
    order_2_21  connected_order_arc_1547  -1
    order_2_21  connected_order_arc_1549  -1
    order_2_21  connected_order_arc_1551  -1
    order_2_21  connected_order_arc_1553  -1
    order_2_21  connected_order_arc_1555  -1
    order_2_21  connected_order_arc_1557  -1
    order_2_21  connected_order_arc_1559  -1
    order_2_21  connected_order_arc_1561  -1
    order_2_21  connected_order_arc_1563  -1
    order_2_21  connected_order_arc_1565  -1
    order_2_21  connected_order_arc_1567  -1
    order_2_21  connected_order_arc_1590  1
    order_2_21  order_active_lb_1659  1
    order_2_21  order_active_ub_1660  1
    visit_2_22  out_degree_1663  -1
    visit_2_22  in_degree_1664  -1
    visit_2_22  order_active_lb_1665  -1
    visit_2_22  order_active_ub_1666  -12
    visit_2_22  service_visit_def_1667  -1
    order_2_22  connected_order_arc_1337  1
    order_2_22  connected_order_arc_1360  1
    order_2_22  connected_order_arc_1383  1
    order_2_22  connected_order_arc_1406  1
    order_2_22  connected_order_arc_1429  1
    order_2_22  connected_order_arc_1452  1
    order_2_22  connected_order_arc_1475  1
    order_2_22  connected_order_arc_1498  1
    order_2_22  connected_order_arc_1521  1
    order_2_22  connected_order_arc_1544  1
    order_2_22  connected_order_arc_1567  1
    order_2_22  connected_order_arc_1570  -1
    order_2_22  connected_order_arc_1572  -1
    order_2_22  connected_order_arc_1574  -1
    order_2_22  connected_order_arc_1576  -1
    order_2_22  connected_order_arc_1578  -1
    order_2_22  connected_order_arc_1580  -1
    order_2_22  connected_order_arc_1582  -1
    order_2_22  connected_order_arc_1584  -1
    order_2_22  connected_order_arc_1586  -1
    order_2_22  connected_order_arc_1588  -1
    order_2_22  connected_order_arc_1590  -1
    order_2_22  order_active_lb_1665  1
    order_2_22  order_active_ub_1666  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_0  arc_capacity_1302  -30
    arc_2_0_0  depot_departure_or_bypass_1591  1
    arc_2_0_0  depot_return_or_bypass_1592  1
    MARKER    'MARKER'                 'INTEND'
    load_2_0_0  arc_capacity_1302  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_11  arc_capacity_1303  -30
    arc_2_0_11  depot_departure_or_bypass_1591  1
    arc_2_0_11  in_degree_1594  1
    arc_2_0_11  original_T_including_depot_unload_1672  1.4567038050199781e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_11  arc_capacity_1303  1
    load_2_0_11  segment_load_conservation_1597  -1
    load_2_0_11  segment_prefix_lb_1598  1
    load_2_0_11  segment_prefix_ub_1599  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_12  arc_capacity_1304  -30
    arc_2_0_12  depot_departure_or_bypass_1591  1
    arc_2_0_12  in_degree_1601  1
    arc_2_0_12  original_T_including_depot_unload_1672  1.2506062209426416e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_12  arc_capacity_1304  1
    load_2_0_12  segment_load_conservation_1604  -1
    load_2_0_12  segment_prefix_lb_1605  1
    load_2_0_12  segment_prefix_ub_1606  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_13  arc_capacity_1305  -30
    arc_2_0_13  depot_departure_or_bypass_1591  1
    arc_2_0_13  in_degree_1608  1
    arc_2_0_13  original_T_including_depot_unload_1672  1.3396590612935172e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_13  arc_capacity_1305  1
    load_2_0_13  segment_load_conservation_1611  -1
    load_2_0_13  segment_prefix_lb_1612  1
    load_2_0_13  segment_prefix_ub_1613  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_14  arc_capacity_1306  -30
    arc_2_0_14  depot_departure_or_bypass_1591  1
    arc_2_0_14  in_degree_1615  1
    arc_2_0_14  original_T_including_depot_unload_1672  9.5330620720858735e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_14  arc_capacity_1306  1
    load_2_0_14  segment_load_conservation_1618  -1
    load_2_0_14  segment_prefix_lb_1619  1
    load_2_0_14  segment_prefix_ub_1620  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_15  arc_capacity_1307  -30
    arc_2_0_15  depot_departure_or_bypass_1591  1
    arc_2_0_15  in_degree_1622  1
    arc_2_0_15  original_T_including_depot_unload_1672  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_15  arc_capacity_1307  1
    load_2_0_15  free_load_conservation_1626  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_16  arc_capacity_1308  -30
    arc_2_0_16  depot_departure_or_bypass_1591  1
    arc_2_0_16  in_degree_1628  1
    arc_2_0_16  original_T_including_depot_unload_1672  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_16  arc_capacity_1308  1
    load_2_0_16  free_load_conservation_1632  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_17  arc_capacity_1309  -30
    arc_2_0_17  depot_departure_or_bypass_1591  1
    arc_2_0_17  in_degree_1634  1
    arc_2_0_17  original_T_including_depot_unload_1672  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_17  arc_capacity_1309  1
    load_2_0_17  free_load_conservation_1638  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_18  arc_capacity_1310  -30
    arc_2_0_18  depot_departure_or_bypass_1591  1
    arc_2_0_18  in_degree_1640  1
    arc_2_0_18  original_T_including_depot_unload_1672  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_18  arc_capacity_1310  1
    load_2_0_18  free_load_conservation_1644  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_19  arc_capacity_1311  -30
    arc_2_0_19  depot_departure_or_bypass_1591  1
    arc_2_0_19  in_degree_1646  1
    arc_2_0_19  original_T_including_depot_unload_1672  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_19  arc_capacity_1311  1
    load_2_0_19  free_load_conservation_1650  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_20  arc_capacity_1312  -30
    arc_2_0_20  depot_departure_or_bypass_1591  1
    arc_2_0_20  in_degree_1652  1
    arc_2_0_20  original_T_including_depot_unload_1672  6.6653528395596720e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_20  arc_capacity_1312  1
    load_2_0_20  free_load_conservation_1656  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_21  arc_capacity_1313  -30
    arc_2_0_21  depot_departure_or_bypass_1591  1
    arc_2_0_21  in_degree_1658  1
    arc_2_0_21  original_T_including_depot_unload_1672  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_21  arc_capacity_1313  1
    load_2_0_21  free_load_conservation_1662  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_22  arc_capacity_1314  -30
    arc_2_0_22  depot_departure_or_bypass_1591  1
    arc_2_0_22  in_degree_1664  1
    arc_2_0_22  original_T_including_depot_unload_1672  5.9431738885389052e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_22  arc_capacity_1314  1
    load_2_0_22  free_load_conservation_1668  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_0  arc_capacity_1315  -30
    arc_2_11_0  depot_return_or_bypass_1592  1
    arc_2_11_0  out_degree_1593  1
    arc_2_11_0  original_T_including_depot_unload_1672  1.4567038050199781e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_0  arc_capacity_1315  1
    load_2_11_0  segment_load_conservation_1597  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_12  arc_capacity_1316  -30
    arc_2_11_12  connected_order_arc_1317  -13
    arc_2_11_12  out_degree_1593  1
    arc_2_11_12  in_degree_1601  1
    arc_2_11_12  original_T_including_depot_unload_1672  5.2746035265689818e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_12  arc_capacity_1316  1
    load_2_11_12  segment_load_conservation_1597  1
    load_2_11_12  segment_load_conservation_1604  -1
    load_2_11_12  segment_prefix_lb_1605  1
    load_2_11_12  segment_prefix_ub_1606  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_13  arc_capacity_1318  -30
    arc_2_11_13  connected_order_arc_1319  -13
    arc_2_11_13  out_degree_1593  1
    arc_2_11_13  in_degree_1608  1
    arc_2_11_13  original_T_including_depot_unload_1672  2362.83310343652
    MARKER    'MARKER'                 'INTEND'
    load_2_11_13  arc_capacity_1318  1
    load_2_11_13  segment_load_conservation_1597  1
    load_2_11_13  segment_load_conservation_1611  -1
    load_2_11_13  segment_prefix_lb_1612  1
    load_2_11_13  segment_prefix_ub_1613  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_14  arc_capacity_1320  -30
    arc_2_11_14  connected_order_arc_1321  -13
    arc_2_11_14  out_degree_1593  1
    arc_2_11_14  in_degree_1615  1
    arc_2_11_14  original_T_including_depot_unload_1672  1.7571531345240103e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_14  arc_capacity_1320  1
    load_2_11_14  segment_load_conservation_1597  1
    load_2_11_14  segment_load_conservation_1618  -1
    load_2_11_14  segment_prefix_lb_1619  1
    load_2_11_14  segment_prefix_ub_1620  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_15  arc_capacity_1322  -30
    arc_2_11_15  connected_order_arc_1323  -13
    arc_2_11_15  out_degree_1593  1
    arc_2_11_15  in_degree_1622  1
    arc_2_11_15  original_T_including_depot_unload_1672  1.4332871320059419e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_15  arc_capacity_1322  1
    load_2_11_15  segment_load_conservation_1597  1
    load_2_11_15  free_load_conservation_1626  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_16  arc_capacity_1324  -30
    arc_2_11_16  connected_order_arc_1325  -13
    arc_2_11_16  out_degree_1593  1
    arc_2_11_16  in_degree_1628  1
    arc_2_11_16  original_T_including_depot_unload_1672  1.5960107821452696e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_16  arc_capacity_1324  1
    load_2_11_16  segment_load_conservation_1597  1
    load_2_11_16  free_load_conservation_1632  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_17  arc_capacity_1326  -30
    arc_2_11_17  connected_order_arc_1327  -13
    arc_2_11_17  out_degree_1593  1
    arc_2_11_17  in_degree_1634  1
    arc_2_11_17  original_T_including_depot_unload_1672  1.2027697073878232e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_17  arc_capacity_1326  1
    load_2_11_17  segment_load_conservation_1597  1
    load_2_11_17  free_load_conservation_1638  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_18  arc_capacity_1328  -30
    arc_2_11_18  connected_order_arc_1329  -13
    arc_2_11_18  out_degree_1593  1
    arc_2_11_18  in_degree_1640  1
    arc_2_11_18  original_T_including_depot_unload_1672  1.2835993572680911e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_18  arc_capacity_1328  1
    load_2_11_18  segment_load_conservation_1597  1
    load_2_11_18  free_load_conservation_1644  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_19  arc_capacity_1330  -30
    arc_2_11_19  connected_order_arc_1331  -13
    arc_2_11_19  out_degree_1593  1
    arc_2_11_19  in_degree_1646  1
    arc_2_11_19  original_T_including_depot_unload_1672  3.1118349756671438e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_19  arc_capacity_1330  1
    load_2_11_19  segment_load_conservation_1597  1
    load_2_11_19  free_load_conservation_1650  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_20  arc_capacity_1332  -30
    arc_2_11_20  connected_order_arc_1333  -13
    arc_2_11_20  out_degree_1593  1
    arc_2_11_20  in_degree_1652  1
    arc_2_11_20  original_T_including_depot_unload_1672  1.5086201853425566e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_20  arc_capacity_1332  1
    load_2_11_20  segment_load_conservation_1597  1
    load_2_11_20  free_load_conservation_1656  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_21  arc_capacity_1334  -30
    arc_2_11_21  connected_order_arc_1335  -13
    arc_2_11_21  out_degree_1593  1
    arc_2_11_21  in_degree_1658  1
    arc_2_11_21  original_T_including_depot_unload_1672  2.0178882184947397e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_21  arc_capacity_1334  1
    load_2_11_21  segment_load_conservation_1597  1
    load_2_11_21  free_load_conservation_1662  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_22  arc_capacity_1336  -30
    arc_2_11_22  connected_order_arc_1337  -13
    arc_2_11_22  out_degree_1593  1
    arc_2_11_22  in_degree_1664  1
    arc_2_11_22  original_T_including_depot_unload_1672  1.1848225970179703e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_22  arc_capacity_1336  1
    load_2_11_22  segment_load_conservation_1597  1
    load_2_11_22  free_load_conservation_1668  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_0  arc_capacity_1338  -30
    arc_2_12_0  depot_return_or_bypass_1592  1
    arc_2_12_0  out_degree_1600  1
    arc_2_12_0  original_T_including_depot_unload_1672  1.2506062209426416e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_0  arc_capacity_1338  1
    load_2_12_0  segment_load_conservation_1604  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_11  arc_capacity_1339  -30
    arc_2_12_11  connected_order_arc_1340  -13
    arc_2_12_11  in_degree_1594  1
    arc_2_12_11  out_degree_1600  1
    arc_2_12_11  original_T_including_depot_unload_1672  5.2746035265689818e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_11  arc_capacity_1339  1
    load_2_12_11  segment_load_conservation_1597  -1
    load_2_12_11  segment_prefix_lb_1598  1
    load_2_12_11  segment_prefix_ub_1599  1
    load_2_12_11  segment_load_conservation_1604  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_13  arc_capacity_1341  -30
    arc_2_12_13  connected_order_arc_1342  -13
    arc_2_12_13  out_degree_1600  1
    arc_2_12_13  in_degree_1608  1
    arc_2_12_13  original_T_including_depot_unload_1672  1.9038107656775676e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_13  arc_capacity_1341  1
    load_2_12_13  segment_load_conservation_1604  1
    load_2_12_13  segment_load_conservation_1611  -1
    load_2_12_13  segment_prefix_lb_1612  1
    load_2_12_13  segment_prefix_ub_1613  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_14  arc_capacity_1343  -30
    arc_2_12_14  connected_order_arc_1344  -13
    arc_2_12_14  out_degree_1600  1
    arc_2_12_14  in_degree_1615  1
    arc_2_12_14  original_T_including_depot_unload_1672  1.2941622036935485e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_14  arc_capacity_1343  1
    load_2_12_14  segment_load_conservation_1604  1
    load_2_12_14  segment_load_conservation_1618  -1
    load_2_12_14  segment_prefix_lb_1619  1
    load_2_12_14  segment_prefix_ub_1620  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_15  arc_capacity_1345  -30
    arc_2_12_15  connected_order_arc_1346  -13
    arc_2_12_15  out_degree_1600  1
    arc_2_12_15  in_degree_1622  1
    arc_2_12_15  original_T_including_depot_unload_1672  1.0874822831610163e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_15  arc_capacity_1345  1
    load_2_12_15  segment_load_conservation_1604  1
    load_2_12_15  free_load_conservation_1626  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_16  arc_capacity_1347  -30
    arc_2_12_16  connected_order_arc_1348  -13
    arc_2_12_16  out_degree_1600  1
    arc_2_12_16  in_degree_1628  1
    arc_2_12_16  original_T_including_depot_unload_1672  1.2335670980381785e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_16  arc_capacity_1347  1
    load_2_12_16  segment_load_conservation_1604  1
    load_2_12_16  free_load_conservation_1632  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_17  arc_capacity_1349  -30
    arc_2_12_17  connected_order_arc_1350  -13
    arc_2_12_17  out_degree_1600  1
    arc_2_12_17  in_degree_1634  1
    arc_2_12_17  original_T_including_depot_unload_1672  1.4255422670497167e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_17  arc_capacity_1349  1
    load_2_12_17  segment_load_conservation_1604  1
    load_2_12_17  free_load_conservation_1638  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_18  arc_capacity_1351  -30
    arc_2_12_18  connected_order_arc_1352  -13
    arc_2_12_18  out_degree_1600  1
    arc_2_12_18  in_degree_1640  1
    arc_2_12_18  original_T_including_depot_unload_1672  1.0138993437494995e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_18  arc_capacity_1351  1
    load_2_12_18  segment_load_conservation_1604  1
    load_2_12_18  free_load_conservation_1644  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_19  arc_capacity_1353  -30
    arc_2_12_19  connected_order_arc_1354  -13
    arc_2_12_19  out_degree_1600  1
    arc_2_12_19  in_degree_1646  1
    arc_2_12_19  original_T_including_depot_unload_1672  2.2865444230199981e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_19  arc_capacity_1353  1
    load_2_12_19  segment_load_conservation_1604  1
    load_2_12_19  free_load_conservation_1650  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_20  arc_capacity_1355  -30
    arc_2_12_20  connected_order_arc_1356  -13
    arc_2_12_20  out_degree_1600  1
    arc_2_12_20  in_degree_1652  1
    arc_2_12_20  original_T_including_depot_unload_1672  1.0917254946216958e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_20  arc_capacity_1355  1
    load_2_12_20  segment_load_conservation_1604  1
    load_2_12_20  free_load_conservation_1656  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_21  arc_capacity_1357  -30
    arc_2_12_21  connected_order_arc_1358  -13
    arc_2_12_21  out_degree_1600  1
    arc_2_12_21  in_degree_1658  1
    arc_2_12_21  original_T_including_depot_unload_1672  1.8362893893653638e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_21  arc_capacity_1357  1
    load_2_12_21  segment_load_conservation_1604  1
    load_2_12_21  free_load_conservation_1662  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_22  arc_capacity_1359  -30
    arc_2_12_22  connected_order_arc_1360  -13
    arc_2_12_22  out_degree_1600  1
    arc_2_12_22  in_degree_1664  1
    arc_2_12_22  original_T_including_depot_unload_1672  8.0231446125927152e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_22  arc_capacity_1359  1
    load_2_12_22  segment_load_conservation_1604  1
    load_2_12_22  free_load_conservation_1668  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_0  arc_capacity_1361  -30
    arc_2_13_0  depot_return_or_bypass_1592  1
    arc_2_13_0  out_degree_1607  1
    arc_2_13_0  original_T_including_depot_unload_1672  1.4501558573355060e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_0  arc_capacity_1361  1
    load_2_13_0  segment_load_conservation_1611  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_11  arc_capacity_1362  -30
    arc_2_13_11  connected_order_arc_1363  -13
    arc_2_13_11  in_degree_1594  1
    arc_2_13_11  out_degree_1607  1
    arc_2_13_11  original_T_including_depot_unload_1672  2.1542021003680966e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_11  arc_capacity_1362  1
    load_2_13_11  segment_load_conservation_1597  -1
    load_2_13_11  segment_prefix_lb_1598  1
    load_2_13_11  segment_prefix_ub_1599  1
    load_2_13_11  segment_load_conservation_1611  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_12  arc_capacity_1364  -30
    arc_2_13_12  connected_order_arc_1365  -13
    arc_2_13_12  in_degree_1601  1
    arc_2_13_12  out_degree_1607  1
    arc_2_13_12  original_T_including_depot_unload_1672  1.6502895430075375e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_12  arc_capacity_1364  1
    load_2_13_12  segment_load_conservation_1604  -1
    load_2_13_12  segment_prefix_lb_1605  1
    load_2_13_12  segment_prefix_ub_1606  1
    load_2_13_12  segment_load_conservation_1611  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_14  arc_capacity_1366  -30
    arc_2_13_14  connected_order_arc_1367  -13
    arc_2_13_14  out_degree_1607  1
    arc_2_13_14  in_degree_1615  1
    arc_2_13_14  original_T_including_depot_unload_1672  5.0525672969651123e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_14  arc_capacity_1366  1
    load_2_13_14  segment_load_conservation_1611  1
    load_2_13_14  segment_load_conservation_1618  -1
    load_2_13_14  segment_prefix_lb_1619  1
    load_2_13_14  segment_prefix_ub_1620  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_15  arc_capacity_1368  -30
    arc_2_13_15  connected_order_arc_1369  -13
    arc_2_13_15  out_degree_1607  1
    arc_2_13_15  in_degree_1622  1
    arc_2_13_15  original_T_including_depot_unload_1672  1.0592524244968324e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_15  arc_capacity_1368  1
    load_2_13_15  segment_load_conservation_1611  1
    load_2_13_15  free_load_conservation_1626  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_16  arc_capacity_1370  -30
    arc_2_13_16  connected_order_arc_1371  -13
    arc_2_13_16  out_degree_1607  1
    arc_2_13_16  in_degree_1628  1
    arc_2_13_16  original_T_including_depot_unload_1672  9.5901863634429412e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_16  arc_capacity_1370  1
    load_2_13_16  segment_load_conservation_1611  1
    load_2_13_16  free_load_conservation_1632  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_17  arc_capacity_1372  -30
    arc_2_13_17  connected_order_arc_1373  -13
    arc_2_13_17  out_degree_1607  1
    arc_2_13_17  in_degree_1634  1
    arc_2_13_17  original_T_including_depot_unload_1672  2.4496137598598170e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_17  arc_capacity_1372  1
    load_2_13_17  segment_load_conservation_1611  1
    load_2_13_17  free_load_conservation_1638  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_18  arc_capacity_1374  -30
    arc_2_13_18  connected_order_arc_1375  -13
    arc_2_13_18  out_degree_1607  1
    arc_2_13_18  in_degree_1640  1
    arc_2_13_18  original_T_including_depot_unload_1672  1.2946770575314561e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_18  arc_capacity_1374  1
    load_2_13_18  segment_load_conservation_1611  1
    load_2_13_18  free_load_conservation_1644  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_19  arc_capacity_1376  -30
    arc_2_13_19  connected_order_arc_1377  -13
    arc_2_13_19  out_degree_1607  1
    arc_2_13_19  in_degree_1646  1
    arc_2_13_19  original_T_including_depot_unload_1672  1.8780729343410642e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_19  arc_capacity_1376  1
    load_2_13_19  segment_load_conservation_1611  1
    load_2_13_19  free_load_conservation_1650  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_20  arc_capacity_1378  -30
    arc_2_13_20  connected_order_arc_1379  -13
    arc_2_13_20  out_degree_1607  1
    arc_2_13_20  in_degree_1652  1
    arc_2_13_20  original_T_including_depot_unload_1672  8.2066682484686987e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_20  arc_capacity_1378  1
    load_2_13_20  segment_load_conservation_1611  1
    load_2_13_20  free_load_conservation_1656  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_21  arc_capacity_1380  -30
    arc_2_13_21  connected_order_arc_1381  -13
    arc_2_13_21  out_degree_1607  1
    arc_2_13_21  in_degree_1658  1
    arc_2_13_21  original_T_including_depot_unload_1672  1.6906177970488723e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_21  arc_capacity_1380  1
    load_2_13_21  segment_load_conservation_1611  1
    load_2_13_21  free_load_conservation_1662  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_22  arc_capacity_1382  -30
    arc_2_13_22  connected_order_arc_1383  -13
    arc_2_13_22  out_degree_1607  1
    arc_2_13_22  in_degree_1664  1
    arc_2_13_22  original_T_including_depot_unload_1672  1.1016218375294079e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_22  arc_capacity_1382  1
    load_2_13_22  segment_load_conservation_1611  1
    load_2_13_22  free_load_conservation_1668  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_0  arc_capacity_1384  -30
    arc_2_14_0  depot_return_or_bypass_1592  1
    arc_2_14_0  out_degree_1614  1
    arc_2_14_0  original_T_including_depot_unload_1672  9.5330620720858735e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_0  arc_capacity_1384  1
    load_2_14_0  segment_load_conservation_1618  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_11  arc_capacity_1385  -30
    arc_2_14_11  connected_order_arc_1386  -13
    arc_2_14_11  in_degree_1594  1
    arc_2_14_11  out_degree_1614  1
    arc_2_14_11  original_T_including_depot_unload_1672  1.7571531345240103e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_11  arc_capacity_1385  1
    load_2_14_11  segment_load_conservation_1597  -1
    load_2_14_11  segment_prefix_lb_1598  1
    load_2_14_11  segment_prefix_ub_1599  1
    load_2_14_11  segment_load_conservation_1618  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_12  arc_capacity_1387  -30
    arc_2_14_12  connected_order_arc_1388  -13
    arc_2_14_12  in_degree_1601  1
    arc_2_14_12  out_degree_1614  1
    arc_2_14_12  original_T_including_depot_unload_1672  1.2941622036935485e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_12  arc_capacity_1387  1
    load_2_14_12  segment_load_conservation_1604  -1
    load_2_14_12  segment_prefix_lb_1605  1
    load_2_14_12  segment_prefix_ub_1606  1
    load_2_14_12  segment_load_conservation_1618  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_13  arc_capacity_1389  -30
    arc_2_14_13  connected_order_arc_1390  -13
    arc_2_14_13  in_degree_1608  1
    arc_2_14_13  out_degree_1614  1
    arc_2_14_13  original_T_including_depot_unload_1672  6.0985881995898160e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_13  arc_capacity_1389  1
    load_2_14_13  segment_load_conservation_1611  -1
    load_2_14_13  segment_prefix_lb_1612  1
    load_2_14_13  segment_prefix_ub_1613  1
    load_2_14_13  segment_load_conservation_1618  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_15  arc_capacity_1391  -30
    arc_2_14_15  connected_order_arc_1392  -13
    arc_2_14_15  out_degree_1614  1
    arc_2_14_15  in_degree_1622  1
    arc_2_14_15  original_T_including_depot_unload_1672  5.5448403235604167e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_15  arc_capacity_1391  1
    load_2_14_15  segment_load_conservation_1618  1
    load_2_14_15  free_load_conservation_1626  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_16  arc_capacity_1393  -30
    arc_2_14_16  connected_order_arc_1394  -13
    arc_2_14_16  out_degree_1614  1
    arc_2_14_16  in_degree_1628  1
    arc_2_14_16  original_T_including_depot_unload_1672  4.6772747357218117e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_16  arc_capacity_1393  1
    load_2_14_16  segment_load_conservation_1618  1
    load_2_14_16  free_load_conservation_1632  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_17  arc_capacity_1395  -30
    arc_2_14_17  connected_order_arc_1396  -13
    arc_2_14_17  out_degree_1614  1
    arc_2_14_17  in_degree_1634  1
    arc_2_14_17  original_T_including_depot_unload_1672  1.9462564869425171e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_17  arc_capacity_1395  1
    load_2_14_17  segment_load_conservation_1618  1
    load_2_14_17  free_load_conservation_1638  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_18  arc_capacity_1397  -30
    arc_2_14_18  connected_order_arc_1398  -13
    arc_2_14_18  out_degree_1614  1
    arc_2_14_18  in_degree_1640  1
    arc_2_14_18  original_T_including_depot_unload_1672  7.8947565022471792e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_18  arc_capacity_1397  1
    load_2_14_18  segment_load_conservation_1618  1
    load_2_14_18  free_load_conservation_1644  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_19  arc_capacity_1399  -30
    arc_2_14_19  connected_order_arc_1400  -13
    arc_2_14_19  out_degree_1614  1
    arc_2_14_19  in_degree_1646  1
    arc_2_14_19  original_T_including_depot_unload_1672  1.5117151439160034e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_19  arc_capacity_1399  1
    load_2_14_19  segment_load_conservation_1618  1
    load_2_14_19  free_load_conservation_1650  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_20  arc_capacity_1401  -30
    arc_2_14_20  connected_order_arc_1402  -13
    arc_2_14_20  out_degree_1614  1
    arc_2_14_20  in_degree_1652  1
    arc_2_14_20  original_T_including_depot_unload_1672  3.1728416035596246e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_20  arc_capacity_1401  1
    load_2_14_20  segment_load_conservation_1618  1
    load_2_14_20  free_load_conservation_1656  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_21  arc_capacity_1403  -30
    arc_2_14_21  connected_order_arc_1404  -13
    arc_2_14_21  out_degree_1614  1
    arc_2_14_21  in_degree_1658  1
    arc_2_14_21  original_T_including_depot_unload_1672  1.2674827380665711e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_21  arc_capacity_1403  1
    load_2_14_21  segment_load_conservation_1618  1
    load_2_14_21  free_load_conservation_1662  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_22  arc_capacity_1405  -30
    arc_2_14_22  connected_order_arc_1406  -13
    arc_2_14_22  out_degree_1614  1
    arc_2_14_22  in_degree_1664  1
    arc_2_14_22  original_T_including_depot_unload_1672  6.2159179673866879e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_22  arc_capacity_1405  1
    load_2_14_22  segment_load_conservation_1618  1
    load_2_14_22  free_load_conservation_1668  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_0  arc_capacity_1407  -30
    arc_2_15_0  depot_return_or_bypass_1592  1
    arc_2_15_0  out_degree_1621  1
    arc_2_15_0  original_T_including_depot_unload_1672  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_0  arc_capacity_1407  1
    load_2_15_0  free_load_conservation_1626  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_11  arc_capacity_1408  -30
    arc_2_15_11  connected_order_arc_1409  -13
    arc_2_15_11  in_degree_1594  1
    arc_2_15_11  out_degree_1621  1
    arc_2_15_11  original_T_including_depot_unload_1672  1.4332871320059419e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_11  arc_capacity_1408  1
    load_2_15_11  segment_load_conservation_1597  -1
    load_2_15_11  segment_prefix_lb_1598  1
    load_2_15_11  segment_prefix_ub_1599  1
    load_2_15_11  free_load_conservation_1626  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_12  arc_capacity_1410  -30
    arc_2_15_12  connected_order_arc_1411  -13
    arc_2_15_12  in_degree_1601  1
    arc_2_15_12  out_degree_1621  1
    arc_2_15_12  original_T_including_depot_unload_1672  1.0874822831610163e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_12  arc_capacity_1410  1
    load_2_15_12  segment_load_conservation_1604  -1
    load_2_15_12  segment_prefix_lb_1605  1
    load_2_15_12  segment_prefix_ub_1606  1
    load_2_15_12  free_load_conservation_1626  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_13  arc_capacity_1412  -30
    arc_2_15_13  connected_order_arc_1413  -13
    arc_2_15_13  in_degree_1608  1
    arc_2_15_13  out_degree_1621  1
    arc_2_15_13  original_T_including_depot_unload_1672  1.0363003610648061e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_13  arc_capacity_1412  1
    load_2_15_13  segment_load_conservation_1611  -1
    load_2_15_13  segment_prefix_lb_1612  1
    load_2_15_13  segment_prefix_ub_1613  1
    load_2_15_13  free_load_conservation_1626  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_14  arc_capacity_1414  -30
    arc_2_15_14  connected_order_arc_1415  -13
    arc_2_15_14  in_degree_1615  1
    arc_2_15_14  out_degree_1621  1
    arc_2_15_14  original_T_including_depot_unload_1672  5.5448403235604167e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_14  arc_capacity_1414  1
    load_2_15_14  segment_load_conservation_1618  -1
    load_2_15_14  segment_prefix_lb_1619  1
    load_2_15_14  segment_prefix_ub_1620  1
    load_2_15_14  free_load_conservation_1626  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_16  arc_capacity_1416  -30
    arc_2_15_16  connected_order_arc_1417  -13
    arc_2_15_16  out_degree_1621  1
    arc_2_15_16  in_degree_1628  1
    arc_2_15_16  original_T_including_depot_unload_1672  1.6597164064313077e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_16  arc_capacity_1416  1
    load_2_15_16  free_load_conservation_1626  1
    load_2_15_16  free_load_conservation_1632  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_17  arc_capacity_1418  -30
    arc_2_15_17  connected_order_arc_1419  -13
    arc_2_15_17  out_degree_1621  1
    arc_2_15_17  in_degree_1634  1
    arc_2_15_17  original_T_including_depot_unload_1672  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_17  arc_capacity_1418  1
    load_2_15_17  free_load_conservation_1626  1
    load_2_15_17  free_load_conservation_1638  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_18  arc_capacity_1420  -30
    arc_2_15_18  connected_order_arc_1421  -13
    arc_2_15_18  out_degree_1621  1
    arc_2_15_18  in_degree_1640  1
    arc_2_15_18  original_T_including_depot_unload_1672  2.4083746437975364e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_18  arc_capacity_1420  1
    load_2_15_18  free_load_conservation_1626  1
    load_2_15_18  free_load_conservation_1644  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_19  arc_capacity_1422  -30
    arc_2_15_19  connected_order_arc_1423  -13
    arc_2_15_19  out_degree_1621  1
    arc_2_15_19  in_degree_1646  1
    arc_2_15_19  original_T_including_depot_unload_1672  1.2608612406747543e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_19  arc_capacity_1422  1
    load_2_15_19  free_load_conservation_1626  1
    load_2_15_19  free_load_conservation_1650  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_20  arc_capacity_1424  -30
    arc_2_15_20  connected_order_arc_1425  -13
    arc_2_15_20  out_degree_1621  1
    arc_2_15_20  in_degree_1652  1
    arc_2_15_20  original_T_including_depot_unload_1672  2.5147997402163108e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_20  arc_capacity_1424  1
    load_2_15_20  free_load_conservation_1626  1
    load_2_15_20  free_load_conservation_1656  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_21  arc_capacity_1426  -30
    arc_2_15_21  connected_order_arc_1427  -13
    arc_2_15_21  out_degree_1621  1
    arc_2_15_21  in_degree_1658  1
    arc_2_15_21  original_T_including_depot_unload_1672  8.7684829846426385e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_21  arc_capacity_1426  1
    load_2_15_21  free_load_conservation_1626  1
    load_2_15_21  free_load_conservation_1662  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_22  arc_capacity_1428  -30
    arc_2_15_22  connected_order_arc_1429  -13
    arc_2_15_22  out_degree_1621  1
    arc_2_15_22  in_degree_1664  1
    arc_2_15_22  original_T_including_depot_unload_1672  2.9098466309579254e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_22  arc_capacity_1428  1
    load_2_15_22  free_load_conservation_1626  1
    load_2_15_22  free_load_conservation_1668  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_0  arc_capacity_1430  -30
    arc_2_16_0  depot_return_or_bypass_1592  1
    arc_2_16_0  out_degree_1627  1
    arc_2_16_0  original_T_including_depot_unload_1672  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_0  arc_capacity_1430  1
    load_2_16_0  free_load_conservation_1632  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_11  arc_capacity_1431  -30
    arc_2_16_11  connected_order_arc_1432  -13
    arc_2_16_11  in_degree_1594  1
    arc_2_16_11  out_degree_1627  1
    arc_2_16_11  original_T_including_depot_unload_1672  1.5960107821452696e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_11  arc_capacity_1431  1
    load_2_16_11  segment_load_conservation_1597  -1
    load_2_16_11  segment_prefix_lb_1598  1
    load_2_16_11  segment_prefix_ub_1599  1
    load_2_16_11  free_load_conservation_1632  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_12  arc_capacity_1433  -30
    arc_2_16_12  connected_order_arc_1434  -13
    arc_2_16_12  in_degree_1601  1
    arc_2_16_12  out_degree_1627  1
    arc_2_16_12  original_T_including_depot_unload_1672  1.2335670980381785e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_12  arc_capacity_1433  1
    load_2_16_12  segment_load_conservation_1604  -1
    load_2_16_12  segment_prefix_lb_1605  1
    load_2_16_12  segment_prefix_ub_1606  1
    load_2_16_12  free_load_conservation_1632  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_13  arc_capacity_1435  -30
    arc_2_16_13  connected_order_arc_1436  -13
    arc_2_16_13  in_degree_1608  1
    arc_2_16_13  out_degree_1627  1
    arc_2_16_13  original_T_including_depot_unload_1672  8.8496780902404032e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_13  arc_capacity_1435  1
    load_2_16_13  segment_load_conservation_1611  -1
    load_2_16_13  segment_prefix_lb_1612  1
    load_2_16_13  segment_prefix_ub_1613  1
    load_2_16_13  free_load_conservation_1632  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_14  arc_capacity_1437  -30
    arc_2_16_14  connected_order_arc_1438  -13
    arc_2_16_14  in_degree_1615  1
    arc_2_16_14  out_degree_1627  1
    arc_2_16_14  original_T_including_depot_unload_1672  4.6772747357218117e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_14  arc_capacity_1437  1
    load_2_16_14  segment_load_conservation_1618  -1
    load_2_16_14  segment_prefix_lb_1619  1
    load_2_16_14  segment_prefix_ub_1620  1
    load_2_16_14  free_load_conservation_1632  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_15  arc_capacity_1439  -30
    arc_2_16_15  connected_order_arc_1440  -13
    arc_2_16_15  in_degree_1622  1
    arc_2_16_15  out_degree_1627  1
    arc_2_16_15  original_T_including_depot_unload_1672  1.6597164064313077e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_15  arc_capacity_1439  1
    load_2_16_15  free_load_conservation_1626  -1
    load_2_16_15  free_load_conservation_1632  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_17  arc_capacity_1441  -30
    arc_2_16_17  connected_order_arc_1442  -13
    arc_2_16_17  out_degree_1627  1
    arc_2_16_17  in_degree_1634  1
    arc_2_16_17  original_T_including_depot_unload_1672  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_17  arc_capacity_1441  1
    load_2_16_17  free_load_conservation_1632  1
    load_2_16_17  free_load_conservation_1638  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_18  arc_capacity_1443  -30
    arc_2_16_18  connected_order_arc_1444  -13
    arc_2_16_18  out_degree_1627  1
    arc_2_16_18  in_degree_1640  1
    arc_2_16_18  original_T_including_depot_unload_1672  3.8790073962518773e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_18  arc_capacity_1443  1
    load_2_16_18  free_load_conservation_1632  1
    load_2_16_18  free_load_conservation_1644  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_19  arc_capacity_1445  -30
    arc_2_16_19  connected_order_arc_1446  -13
    arc_2_16_19  out_degree_1627  1
    arc_2_16_19  in_degree_1646  1
    arc_2_16_19  original_T_including_depot_unload_1672  1.4150780419437449e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_19  arc_capacity_1445  1
    load_2_16_19  free_load_conservation_1632  1
    load_2_16_19  free_load_conservation_1650  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_20  arc_capacity_1447  -30
    arc_2_16_20  connected_order_arc_1448  -13
    arc_2_16_20  out_degree_1627  1
    arc_2_16_20  in_degree_1652  1
    arc_2_16_20  original_T_including_depot_unload_1672  2.3649901674897566e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_20  arc_capacity_1447  1
    load_2_16_20  free_load_conservation_1632  1
    load_2_16_20  free_load_conservation_1656  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_21  arc_capacity_1449  -30
    arc_2_16_21  connected_order_arc_1450  -13
    arc_2_16_21  out_degree_1627  1
    arc_2_16_21  in_degree_1658  1
    arc_2_16_21  original_T_including_depot_unload_1672  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_21  arc_capacity_1449  1
    load_2_16_21  free_load_conservation_1632  1
    load_2_16_21  free_load_conservation_1662  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_22  arc_capacity_1451  -30
    arc_2_16_22  connected_order_arc_1452  -13
    arc_2_16_22  out_degree_1627  1
    arc_2_16_22  in_degree_1664  1
    arc_2_16_22  original_T_including_depot_unload_1672  4.3129452098285111e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_22  arc_capacity_1451  1
    load_2_16_22  free_load_conservation_1632  1
    load_2_16_22  free_load_conservation_1668  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_0  arc_capacity_1453  -30
    arc_2_17_0  depot_return_or_bypass_1592  1
    arc_2_17_0  out_degree_1633  1
    arc_2_17_0  original_T_including_depot_unload_1672  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_0  arc_capacity_1453  1
    load_2_17_0  free_load_conservation_1638  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_11  arc_capacity_1454  -30
    arc_2_17_11  connected_order_arc_1455  -13
    arc_2_17_11  in_degree_1594  1
    arc_2_17_11  out_degree_1633  1
    arc_2_17_11  original_T_including_depot_unload_1672  1.2027697073878232e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_11  arc_capacity_1454  1
    load_2_17_11  segment_load_conservation_1597  -1
    load_2_17_11  segment_prefix_lb_1598  1
    load_2_17_11  segment_prefix_ub_1599  1
    load_2_17_11  free_load_conservation_1638  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_12  arc_capacity_1456  -30
    arc_2_17_12  connected_order_arc_1457  -13
    arc_2_17_12  in_degree_1601  1
    arc_2_17_12  out_degree_1633  1
    arc_2_17_12  original_T_including_depot_unload_1672  1.4255422670497167e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_12  arc_capacity_1456  1
    load_2_17_12  segment_load_conservation_1604  -1
    load_2_17_12  segment_prefix_lb_1605  1
    load_2_17_12  segment_prefix_ub_1606  1
    load_2_17_12  free_load_conservation_1638  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_13  arc_capacity_1458  -30
    arc_2_17_13  connected_order_arc_1459  -13
    arc_2_17_13  in_degree_1608  1
    arc_2_17_13  out_degree_1633  1
    arc_2_17_13  original_T_including_depot_unload_1672  2.4147485851762935e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_13  arc_capacity_1458  1
    load_2_17_13  segment_load_conservation_1611  -1
    load_2_17_13  segment_prefix_lb_1612  1
    load_2_17_13  segment_prefix_ub_1613  1
    load_2_17_13  free_load_conservation_1638  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_14  arc_capacity_1460  -30
    arc_2_17_14  connected_order_arc_1461  -13
    arc_2_17_14  in_degree_1615  1
    arc_2_17_14  out_degree_1633  1
    arc_2_17_14  original_T_including_depot_unload_1672  1.9462564869425171e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_14  arc_capacity_1460  1
    load_2_17_14  segment_load_conservation_1618  -1
    load_2_17_14  segment_prefix_lb_1619  1
    load_2_17_14  segment_prefix_ub_1620  1
    load_2_17_14  free_load_conservation_1638  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_15  arc_capacity_1462  -30
    arc_2_17_15  connected_order_arc_1463  -13
    arc_2_17_15  in_degree_1622  1
    arc_2_17_15  out_degree_1633  1
    arc_2_17_15  original_T_including_depot_unload_1672  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_15  arc_capacity_1462  1
    load_2_17_15  free_load_conservation_1626  -1
    load_2_17_15  free_load_conservation_1638  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_16  arc_capacity_1464  -30
    arc_2_17_16  connected_order_arc_1465  -13
    arc_2_17_16  in_degree_1628  1
    arc_2_17_16  out_degree_1633  1
    arc_2_17_16  original_T_including_depot_unload_1672  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_16  arc_capacity_1464  1
    load_2_17_16  free_load_conservation_1632  -1
    load_2_17_16  free_load_conservation_1638  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_18  arc_capacity_1466  -30
    arc_2_17_18  connected_order_arc_1467  -13
    arc_2_17_18  out_degree_1633  1
    arc_2_17_18  in_degree_1640  1
    arc_2_17_18  original_T_including_depot_unload_1672  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_18  arc_capacity_1466  1
    load_2_17_18  free_load_conservation_1638  1
    load_2_17_18  free_load_conservation_1644  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_19  arc_capacity_1468  -30
    arc_2_17_19  connected_order_arc_1469  -13
    arc_2_17_19  out_degree_1633  1
    arc_2_17_19  in_degree_1646  1
    arc_2_17_19  original_T_including_depot_unload_1672  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_19  arc_capacity_1468  1
    load_2_17_19  free_load_conservation_1638  1
    load_2_17_19  free_load_conservation_1650  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_20  arc_capacity_1470  -30
    arc_2_17_20  connected_order_arc_1471  -13
    arc_2_17_20  out_degree_1633  1
    arc_2_17_20  in_degree_1652  1
    arc_2_17_20  original_T_including_depot_unload_1672  1.6292966848558842e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_20  arc_capacity_1470  1
    load_2_17_20  free_load_conservation_1638  1
    load_2_17_20  free_load_conservation_1656  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_21  arc_capacity_1472  -30
    arc_2_17_21  connected_order_arc_1473  -13
    arc_2_17_21  out_degree_1633  1
    arc_2_17_21  in_degree_1658  1
    arc_2_17_21  original_T_including_depot_unload_1672  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_21  arc_capacity_1472  1
    load_2_17_21  free_load_conservation_1638  1
    load_2_17_21  free_load_conservation_1662  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_22  arc_capacity_1474  -30
    arc_2_17_22  connected_order_arc_1475  -13
    arc_2_17_22  out_degree_1633  1
    arc_2_17_22  in_degree_1664  1
    arc_2_17_22  original_T_including_depot_unload_1672  1.3727638439182763e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_22  arc_capacity_1474  1
    load_2_17_22  free_load_conservation_1638  1
    load_2_17_22  free_load_conservation_1668  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_0  arc_capacity_1476  -30
    arc_2_18_0  depot_return_or_bypass_1592  1
    arc_2_18_0  out_degree_1639  1
    arc_2_18_0  original_T_including_depot_unload_1672  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_0  arc_capacity_1476  1
    load_2_18_0  free_load_conservation_1644  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_11  arc_capacity_1477  -30
    arc_2_18_11  connected_order_arc_1478  -13
    arc_2_18_11  in_degree_1594  1
    arc_2_18_11  out_degree_1639  1
    arc_2_18_11  original_T_including_depot_unload_1672  1.2835993572680911e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_11  arc_capacity_1477  1
    load_2_18_11  segment_load_conservation_1597  -1
    load_2_18_11  segment_prefix_lb_1598  1
    load_2_18_11  segment_prefix_ub_1599  1
    load_2_18_11  free_load_conservation_1644  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_12  arc_capacity_1479  -30
    arc_2_18_12  connected_order_arc_1480  -13
    arc_2_18_12  in_degree_1601  1
    arc_2_18_12  out_degree_1639  1
    arc_2_18_12  original_T_including_depot_unload_1672  1.0138993437494995e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_12  arc_capacity_1479  1
    load_2_18_12  segment_load_conservation_1604  -1
    load_2_18_12  segment_prefix_lb_1605  1
    load_2_18_12  segment_prefix_ub_1606  1
    load_2_18_12  free_load_conservation_1644  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_13  arc_capacity_1481  -30
    arc_2_18_13  connected_order_arc_1482  -13
    arc_2_18_13  in_degree_1608  1
    arc_2_18_13  out_degree_1639  1
    arc_2_18_13  original_T_including_depot_unload_1672  1.2717918724165304e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_13  arc_capacity_1481  1
    load_2_18_13  segment_load_conservation_1611  -1
    load_2_18_13  segment_prefix_lb_1612  1
    load_2_18_13  segment_prefix_ub_1613  1
    load_2_18_13  free_load_conservation_1644  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_14  arc_capacity_1483  -30
    arc_2_18_14  connected_order_arc_1484  -13
    arc_2_18_14  in_degree_1615  1
    arc_2_18_14  out_degree_1639  1
    arc_2_18_14  original_T_including_depot_unload_1672  7.8947565022471792e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_14  arc_capacity_1483  1
    load_2_18_14  segment_load_conservation_1618  -1
    load_2_18_14  segment_prefix_lb_1619  1
    load_2_18_14  segment_prefix_ub_1620  1
    load_2_18_14  free_load_conservation_1644  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_15  arc_capacity_1485  -30
    arc_2_18_15  connected_order_arc_1486  -13
    arc_2_18_15  in_degree_1622  1
    arc_2_18_15  out_degree_1639  1
    arc_2_18_15  original_T_including_depot_unload_1672  2.4083746437975364e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_15  arc_capacity_1485  1
    load_2_18_15  free_load_conservation_1626  -1
    load_2_18_15  free_load_conservation_1644  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_16  arc_capacity_1487  -30
    arc_2_18_16  connected_order_arc_1488  -13
    arc_2_18_16  in_degree_1628  1
    arc_2_18_16  out_degree_1639  1
    arc_2_18_16  original_T_including_depot_unload_1672  3.8790073962518773e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_16  arc_capacity_1487  1
    load_2_18_16  free_load_conservation_1632  -1
    load_2_18_16  free_load_conservation_1644  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_17  arc_capacity_1489  -30
    arc_2_18_17  connected_order_arc_1490  -13
    arc_2_18_17  in_degree_1634  1
    arc_2_18_17  out_degree_1639  1
    arc_2_18_17  original_T_including_depot_unload_1672  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_17  arc_capacity_1489  1
    load_2_18_17  free_load_conservation_1638  -1
    load_2_18_17  free_load_conservation_1644  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_19  arc_capacity_1491  -30
    arc_2_18_19  connected_order_arc_1492  -13
    arc_2_18_19  out_degree_1639  1
    arc_2_18_19  in_degree_1646  1
    arc_2_18_19  original_T_including_depot_unload_1672  1.1544376314422677e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_19  arc_capacity_1491  1
    load_2_18_19  free_load_conservation_1644  1
    load_2_18_19  free_load_conservation_1650  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_20  arc_capacity_1493  -30
    arc_2_18_20  connected_order_arc_1494  -13
    arc_2_18_20  out_degree_1639  1
    arc_2_18_20  in_degree_1652  1
    arc_2_18_20  original_T_including_depot_unload_1672  4.7597588586788925e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_20  arc_capacity_1493  1
    load_2_18_20  free_load_conservation_1644  1
    load_2_18_20  free_load_conservation_1656  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_21  arc_capacity_1495  -30
    arc_2_18_21  connected_order_arc_1496  -13
    arc_2_18_21  out_degree_1639  1
    arc_2_18_21  in_degree_1658  1
    arc_2_18_21  original_T_including_depot_unload_1672  8.3486971116736720e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_21  arc_capacity_1495  1
    load_2_18_21  free_load_conservation_1644  1
    load_2_18_21  free_load_conservation_1662  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_22  arc_capacity_1497  -30
    arc_2_18_22  connected_order_arc_1498  -13
    arc_2_18_22  out_degree_1639  1
    arc_2_18_22  in_degree_1664  1
    arc_2_18_22  original_T_including_depot_unload_1672  3.2938591738444967e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_22  arc_capacity_1497  1
    load_2_18_22  free_load_conservation_1644  1
    load_2_18_22  free_load_conservation_1668  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_0  arc_capacity_1499  -30
    arc_2_19_0  depot_return_or_bypass_1592  1
    arc_2_19_0  out_degree_1645  1
    arc_2_19_0  original_T_including_depot_unload_1672  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_0  arc_capacity_1499  1
    load_2_19_0  free_load_conservation_1650  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_11  arc_capacity_1500  -30
    arc_2_19_11  connected_order_arc_1501  -13
    arc_2_19_11  in_degree_1594  1
    arc_2_19_11  out_degree_1645  1
    arc_2_19_11  original_T_including_depot_unload_1672  3.1118349756671438e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_11  arc_capacity_1500  1
    load_2_19_11  segment_load_conservation_1597  -1
    load_2_19_11  segment_prefix_lb_1598  1
    load_2_19_11  segment_prefix_ub_1599  1
    load_2_19_11  free_load_conservation_1650  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_12  arc_capacity_1502  -30
    arc_2_19_12  connected_order_arc_1503  -13
    arc_2_19_12  in_degree_1601  1
    arc_2_19_12  out_degree_1645  1
    arc_2_19_12  original_T_including_depot_unload_1672  2.2865444230199981e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_12  arc_capacity_1502  1
    load_2_19_12  segment_load_conservation_1604  -1
    load_2_19_12  segment_prefix_lb_1605  1
    load_2_19_12  segment_prefix_ub_1606  1
    load_2_19_12  free_load_conservation_1650  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_13  arc_capacity_1504  -30
    arc_2_19_13  connected_order_arc_1505  -13
    arc_2_19_13  in_degree_1608  1
    arc_2_19_13  out_degree_1645  1
    arc_2_19_13  original_T_including_depot_unload_1672  2.1214998192647863e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_13  arc_capacity_1504  1
    load_2_19_13  segment_load_conservation_1611  -1
    load_2_19_13  segment_prefix_lb_1612  1
    load_2_19_13  segment_prefix_ub_1613  1
    load_2_19_13  free_load_conservation_1650  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_14  arc_capacity_1506  -30
    arc_2_19_14  connected_order_arc_1507  -13
    arc_2_19_14  in_degree_1615  1
    arc_2_19_14  out_degree_1645  1
    arc_2_19_14  original_T_including_depot_unload_1672  1.5117151439160034e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_14  arc_capacity_1506  1
    load_2_19_14  segment_load_conservation_1618  -1
    load_2_19_14  segment_prefix_lb_1619  1
    load_2_19_14  segment_prefix_ub_1620  1
    load_2_19_14  free_load_conservation_1650  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_15  arc_capacity_1508  -30
    arc_2_19_15  connected_order_arc_1509  -13
    arc_2_19_15  in_degree_1622  1
    arc_2_19_15  out_degree_1645  1
    arc_2_19_15  original_T_including_depot_unload_1672  1.2608612406747543e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_15  arc_capacity_1508  1
    load_2_19_15  free_load_conservation_1626  -1
    load_2_19_15  free_load_conservation_1650  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_16  arc_capacity_1510  -30
    arc_2_19_16  connected_order_arc_1511  -13
    arc_2_19_16  in_degree_1628  1
    arc_2_19_16  out_degree_1645  1
    arc_2_19_16  original_T_including_depot_unload_1672  1.4150780419437449e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_16  arc_capacity_1510  1
    load_2_19_16  free_load_conservation_1632  -1
    load_2_19_16  free_load_conservation_1650  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_17  arc_capacity_1512  -30
    arc_2_19_17  connected_order_arc_1513  -13
    arc_2_19_17  in_degree_1634  1
    arc_2_19_17  out_degree_1645  1
    arc_2_19_17  original_T_including_depot_unload_1672  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_17  arc_capacity_1512  1
    load_2_19_17  free_load_conservation_1638  -1
    load_2_19_17  free_load_conservation_1650  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_18  arc_capacity_1514  -30
    arc_2_19_18  connected_order_arc_1515  -13
    arc_2_19_18  in_degree_1640  1
    arc_2_19_18  out_degree_1645  1
    arc_2_19_18  original_T_including_depot_unload_1672  1.1544376314422677e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_18  arc_capacity_1514  1
    load_2_19_18  free_load_conservation_1644  -1
    load_2_19_18  free_load_conservation_1650  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_20  arc_capacity_1516  -30
    arc_2_19_20  connected_order_arc_1517  -13
    arc_2_19_20  out_degree_1645  1
    arc_2_19_20  in_degree_1652  1
    arc_2_19_20  original_T_including_depot_unload_1672  1.2927075446362680e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_20  arc_capacity_1516  1
    load_2_19_20  free_load_conservation_1650  1
    load_2_19_20  free_load_conservation_1656  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_21  arc_capacity_1518  -30
    arc_2_19_21  connected_order_arc_1519  -13
    arc_2_19_21  out_degree_1645  1
    arc_2_19_21  in_degree_1658  1
    arc_2_19_21  original_T_including_depot_unload_1672  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_21  arc_capacity_1518  1
    load_2_19_21  free_load_conservation_1650  1
    load_2_19_21  free_load_conservation_1662  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_22  arc_capacity_1520  -30
    arc_2_19_22  connected_order_arc_1521  -13
    arc_2_19_22  out_degree_1645  1
    arc_2_19_22  in_degree_1664  1
    arc_2_19_22  original_T_including_depot_unload_1672  9.8652191996938075e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_22  arc_capacity_1520  1
    load_2_19_22  free_load_conservation_1650  1
    load_2_19_22  free_load_conservation_1668  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_0  arc_capacity_1522  -30
    arc_2_20_0  depot_return_or_bypass_1592  1
    arc_2_20_0  out_degree_1651  1
    arc_2_20_0  original_T_including_depot_unload_1672  6.6653528395596720e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_0  arc_capacity_1522  1
    load_2_20_0  free_load_conservation_1656  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_11  arc_capacity_1523  -30
    arc_2_20_11  connected_order_arc_1524  -13
    arc_2_20_11  in_degree_1594  1
    arc_2_20_11  out_degree_1651  1
    arc_2_20_11  original_T_including_depot_unload_1672  1.5086201853425566e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_11  arc_capacity_1523  1
    load_2_20_11  segment_load_conservation_1597  -1
    load_2_20_11  segment_prefix_lb_1598  1
    load_2_20_11  segment_prefix_ub_1599  1
    load_2_20_11  free_load_conservation_1656  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_12  arc_capacity_1525  -30
    arc_2_20_12  connected_order_arc_1526  -13
    arc_2_20_12  in_degree_1601  1
    arc_2_20_12  out_degree_1651  1
    arc_2_20_12  original_T_including_depot_unload_1672  1.0917254946216958e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_12  arc_capacity_1525  1
    load_2_20_12  segment_load_conservation_1604  -1
    load_2_20_12  segment_prefix_lb_1605  1
    load_2_20_12  segment_prefix_ub_1606  1
    load_2_20_12  free_load_conservation_1656  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_13  arc_capacity_1527  -30
    arc_2_20_13  connected_order_arc_1528  -13
    arc_2_20_13  in_degree_1608  1
    arc_2_20_13  out_degree_1651  1
    arc_2_20_13  original_T_including_depot_unload_1672  8.6958069185371107e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_13  arc_capacity_1527  1
    load_2_20_13  segment_load_conservation_1611  -1
    load_2_20_13  segment_prefix_lb_1612  1
    load_2_20_13  segment_prefix_ub_1613  1
    load_2_20_13  free_load_conservation_1656  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_14  arc_capacity_1529  -30
    arc_2_20_14  connected_order_arc_1530  -13
    arc_2_20_14  in_degree_1615  1
    arc_2_20_14  out_degree_1651  1
    arc_2_20_14  original_T_including_depot_unload_1672  3.1728416035596246e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_14  arc_capacity_1529  1
    load_2_20_14  segment_load_conservation_1618  -1
    load_2_20_14  segment_prefix_lb_1619  1
    load_2_20_14  segment_prefix_ub_1620  1
    load_2_20_14  free_load_conservation_1656  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_15  arc_capacity_1531  -30
    arc_2_20_15  connected_order_arc_1532  -13
    arc_2_20_15  in_degree_1622  1
    arc_2_20_15  out_degree_1651  1
    arc_2_20_15  original_T_including_depot_unload_1672  2.5147997402163108e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_15  arc_capacity_1531  1
    load_2_20_15  free_load_conservation_1626  -1
    load_2_20_15  free_load_conservation_1656  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_16  arc_capacity_1533  -30
    arc_2_20_16  connected_order_arc_1534  -13
    arc_2_20_16  in_degree_1628  1
    arc_2_20_16  out_degree_1651  1
    arc_2_20_16  original_T_including_depot_unload_1672  2.3649901674897566e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_16  arc_capacity_1533  1
    load_2_20_16  free_load_conservation_1632  -1
    load_2_20_16  free_load_conservation_1656  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_17  arc_capacity_1535  -30
    arc_2_20_17  connected_order_arc_1536  -13
    arc_2_20_17  in_degree_1634  1
    arc_2_20_17  out_degree_1651  1
    arc_2_20_17  original_T_including_depot_unload_1672  1.6292966848558842e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_17  arc_capacity_1535  1
    load_2_20_17  free_load_conservation_1638  -1
    load_2_20_17  free_load_conservation_1656  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_18  arc_capacity_1537  -30
    arc_2_20_18  connected_order_arc_1538  -13
    arc_2_20_18  in_degree_1640  1
    arc_2_20_18  out_degree_1651  1
    arc_2_20_18  original_T_including_depot_unload_1672  4.7597588586788925e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_18  arc_capacity_1537  1
    load_2_20_18  free_load_conservation_1644  -1
    load_2_20_18  free_load_conservation_1656  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_19  arc_capacity_1539  -30
    arc_2_20_19  connected_order_arc_1540  -13
    arc_2_20_19  in_degree_1646  1
    arc_2_20_19  out_degree_1651  1
    arc_2_20_19  original_T_including_depot_unload_1672  1.2927075446362680e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_19  arc_capacity_1539  1
    load_2_20_19  free_load_conservation_1650  -1
    load_2_20_19  free_load_conservation_1656  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_21  arc_capacity_1541  -30
    arc_2_20_21  connected_order_arc_1542  -13
    arc_2_20_21  out_degree_1651  1
    arc_2_20_21  in_degree_1658  1
    arc_2_20_21  original_T_including_depot_unload_1672  1.0758099325648966e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_21  arc_capacity_1541  1
    load_2_20_21  free_load_conservation_1656  1
    load_2_20_21  free_load_conservation_1662  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_22  arc_capacity_1543  -30
    arc_2_20_22  connected_order_arc_1544  -13
    arc_2_20_22  out_degree_1651  1
    arc_2_20_22  in_degree_1664  1
    arc_2_20_22  original_T_including_depot_unload_1672  3.2985327387120213e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_22  arc_capacity_1543  1
    load_2_20_22  free_load_conservation_1656  1
    load_2_20_22  free_load_conservation_1668  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_0  arc_capacity_1545  -30
    arc_2_21_0  depot_return_or_bypass_1592  1
    arc_2_21_0  out_degree_1657  1
    arc_2_21_0  original_T_including_depot_unload_1672  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_0  arc_capacity_1545  1
    load_2_21_0  free_load_conservation_1662  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_11  arc_capacity_1546  -30
    arc_2_21_11  connected_order_arc_1547  -13
    arc_2_21_11  in_degree_1594  1
    arc_2_21_11  out_degree_1657  1
    arc_2_21_11  original_T_including_depot_unload_1672  2.0178882184947397e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_11  arc_capacity_1546  1
    load_2_21_11  segment_load_conservation_1597  -1
    load_2_21_11  segment_prefix_lb_1598  1
    load_2_21_11  segment_prefix_ub_1599  1
    load_2_21_11  free_load_conservation_1662  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_12  arc_capacity_1548  -30
    arc_2_21_12  connected_order_arc_1549  -13
    arc_2_21_12  in_degree_1601  1
    arc_2_21_12  out_degree_1657  1
    arc_2_21_12  original_T_including_depot_unload_1672  1.8362893893653638e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_12  arc_capacity_1548  1
    load_2_21_12  segment_load_conservation_1604  -1
    load_2_21_12  segment_prefix_lb_1605  1
    load_2_21_12  segment_prefix_ub_1606  1
    load_2_21_12  free_load_conservation_1662  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_13  arc_capacity_1550  -30
    arc_2_21_13  connected_order_arc_1551  -13
    arc_2_21_13  in_degree_1608  1
    arc_2_21_13  out_degree_1657  1
    arc_2_21_13  original_T_including_depot_unload_1672  1.4088953223409719e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_13  arc_capacity_1550  1
    load_2_21_13  segment_load_conservation_1611  -1
    load_2_21_13  segment_prefix_lb_1612  1
    load_2_21_13  segment_prefix_ub_1613  1
    load_2_21_13  free_load_conservation_1662  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_14  arc_capacity_1552  -30
    arc_2_21_14  connected_order_arc_1553  -13
    arc_2_21_14  in_degree_1615  1
    arc_2_21_14  out_degree_1657  1
    arc_2_21_14  original_T_including_depot_unload_1672  1.2674827380665711e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_14  arc_capacity_1552  1
    load_2_21_14  segment_load_conservation_1618  -1
    load_2_21_14  segment_prefix_lb_1619  1
    load_2_21_14  segment_prefix_ub_1620  1
    load_2_21_14  free_load_conservation_1662  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_15  arc_capacity_1554  -30
    arc_2_21_15  connected_order_arc_1555  -13
    arc_2_21_15  in_degree_1622  1
    arc_2_21_15  out_degree_1657  1
    arc_2_21_15  original_T_including_depot_unload_1672  8.7684829846426385e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_15  arc_capacity_1554  1
    load_2_21_15  free_load_conservation_1626  -1
    load_2_21_15  free_load_conservation_1662  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_16  arc_capacity_1556  -30
    arc_2_21_16  connected_order_arc_1557  -13
    arc_2_21_16  in_degree_1628  1
    arc_2_21_16  out_degree_1657  1
    arc_2_21_16  original_T_including_depot_unload_1672  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_16  arc_capacity_1556  1
    load_2_21_16  free_load_conservation_1632  -1
    load_2_21_16  free_load_conservation_1662  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_17  arc_capacity_1558  -30
    arc_2_21_17  connected_order_arc_1559  -13
    arc_2_21_17  in_degree_1634  1
    arc_2_21_17  out_degree_1657  1
    arc_2_21_17  original_T_including_depot_unload_1672  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_17  arc_capacity_1558  1
    load_2_21_17  free_load_conservation_1638  -1
    load_2_21_17  free_load_conservation_1662  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_18  arc_capacity_1560  -30
    arc_2_21_18  connected_order_arc_1561  -13
    arc_2_21_18  in_degree_1640  1
    arc_2_21_18  out_degree_1657  1
    arc_2_21_18  original_T_including_depot_unload_1672  8.3486971116736720e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_18  arc_capacity_1560  1
    load_2_21_18  free_load_conservation_1644  -1
    load_2_21_18  free_load_conservation_1662  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_19  arc_capacity_1562  -30
    arc_2_21_19  connected_order_arc_1563  -13
    arc_2_21_19  in_degree_1646  1
    arc_2_21_19  out_degree_1657  1
    arc_2_21_19  original_T_including_depot_unload_1672  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_19  arc_capacity_1562  1
    load_2_21_19  free_load_conservation_1650  -1
    load_2_21_19  free_load_conservation_1662  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_20  arc_capacity_1564  -30
    arc_2_21_20  connected_order_arc_1565  -13
    arc_2_21_20  in_degree_1652  1
    arc_2_21_20  out_degree_1657  1
    arc_2_21_20  original_T_including_depot_unload_1672  1.0758099325648966e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_20  arc_capacity_1564  1
    load_2_21_20  free_load_conservation_1656  -1
    load_2_21_20  free_load_conservation_1662  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_22  arc_capacity_1566  -30
    arc_2_21_22  connected_order_arc_1567  -13
    arc_2_21_22  out_degree_1657  1
    arc_2_21_22  in_degree_1664  1
    arc_2_21_22  original_T_including_depot_unload_1672  1.1341050580477483e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_22  arc_capacity_1566  1
    load_2_21_22  free_load_conservation_1662  1
    load_2_21_22  free_load_conservation_1668  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_0  arc_capacity_1568  -30
    arc_2_22_0  depot_return_or_bypass_1592  1
    arc_2_22_0  out_degree_1663  1
    arc_2_22_0  original_T_including_depot_unload_1672  5.9431738885389052e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_0  arc_capacity_1568  1
    load_2_22_0  free_load_conservation_1668  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_11  arc_capacity_1569  -30
    arc_2_22_11  connected_order_arc_1570  -13
    arc_2_22_11  in_degree_1594  1
    arc_2_22_11  out_degree_1663  1
    arc_2_22_11  original_T_including_depot_unload_1672  1.1848225970179703e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_22_11  arc_capacity_1569  1
    load_2_22_11  segment_load_conservation_1597  -1
    load_2_22_11  segment_prefix_lb_1598  1
    load_2_22_11  segment_prefix_ub_1599  1
    load_2_22_11  free_load_conservation_1668  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_12  arc_capacity_1571  -30
    arc_2_22_12  connected_order_arc_1572  -13
    arc_2_22_12  in_degree_1601  1
    arc_2_22_12  out_degree_1663  1
    arc_2_22_12  original_T_including_depot_unload_1672  8.0231446125927152e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_12  arc_capacity_1571  1
    load_2_22_12  segment_load_conservation_1604  -1
    load_2_22_12  segment_prefix_lb_1605  1
    load_2_22_12  segment_prefix_ub_1606  1
    load_2_22_12  free_load_conservation_1668  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_13  arc_capacity_1573  -30
    arc_2_22_13  connected_order_arc_1574  -13
    arc_2_22_13  in_degree_1608  1
    arc_2_22_13  out_degree_1663  1
    arc_2_22_13  original_T_including_depot_unload_1672  1.1989066345879348e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_22_13  arc_capacity_1573  1
    load_2_22_13  segment_load_conservation_1611  -1
    load_2_22_13  segment_prefix_lb_1612  1
    load_2_22_13  segment_prefix_ub_1613  1
    load_2_22_13  free_load_conservation_1668  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_14  arc_capacity_1575  -30
    arc_2_22_14  connected_order_arc_1576  -13
    arc_2_22_14  in_degree_1615  1
    arc_2_22_14  out_degree_1663  1
    arc_2_22_14  original_T_including_depot_unload_1672  6.2159179673866879e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_14  arc_capacity_1575  1
    load_2_22_14  segment_load_conservation_1618  -1
    load_2_22_14  segment_prefix_lb_1619  1
    load_2_22_14  segment_prefix_ub_1620  1
    load_2_22_14  free_load_conservation_1668  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_15  arc_capacity_1577  -30
    arc_2_22_15  connected_order_arc_1578  -13
    arc_2_22_15  in_degree_1622  1
    arc_2_22_15  out_degree_1663  1
    arc_2_22_15  original_T_including_depot_unload_1672  2.9098466309579254e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_15  arc_capacity_1577  1
    load_2_22_15  free_load_conservation_1626  -1
    load_2_22_15  free_load_conservation_1668  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_16  arc_capacity_1579  -30
    arc_2_22_16  connected_order_arc_1580  -13
    arc_2_22_16  in_degree_1628  1
    arc_2_22_16  out_degree_1663  1
    arc_2_22_16  original_T_including_depot_unload_1672  4.3129452098285111e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_16  arc_capacity_1579  1
    load_2_22_16  free_load_conservation_1632  -1
    load_2_22_16  free_load_conservation_1668  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_17  arc_capacity_1581  -30
    arc_2_22_17  connected_order_arc_1582  -13
    arc_2_22_17  in_degree_1634  1
    arc_2_22_17  out_degree_1663  1
    arc_2_22_17  original_T_including_depot_unload_1672  1.3727638439182763e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_22_17  arc_capacity_1581  1
    load_2_22_17  free_load_conservation_1638  -1
    load_2_22_17  free_load_conservation_1668  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_18  arc_capacity_1583  -30
    arc_2_22_18  connected_order_arc_1584  -13
    arc_2_22_18  in_degree_1640  1
    arc_2_22_18  out_degree_1663  1
    arc_2_22_18  original_T_including_depot_unload_1672  3.2938591738444967e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_18  arc_capacity_1583  1
    load_2_22_18  free_load_conservation_1644  -1
    load_2_22_18  free_load_conservation_1668  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_19  arc_capacity_1585  -30
    arc_2_22_19  connected_order_arc_1586  -13
    arc_2_22_19  in_degree_1646  1
    arc_2_22_19  out_degree_1663  1
    arc_2_22_19  original_T_including_depot_unload_1672  9.8652191996938075e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_19  arc_capacity_1585  1
    load_2_22_19  free_load_conservation_1650  -1
    load_2_22_19  free_load_conservation_1668  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_20  arc_capacity_1587  -30
    arc_2_22_20  connected_order_arc_1588  -13
    arc_2_22_20  in_degree_1652  1
    arc_2_22_20  out_degree_1663  1
    arc_2_22_20  original_T_including_depot_unload_1672  3.2985327387120213e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_20  arc_capacity_1587  1
    load_2_22_20  free_load_conservation_1656  -1
    load_2_22_20  free_load_conservation_1668  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_21  arc_capacity_1589  -30
    arc_2_22_21  connected_order_arc_1590  -13
    arc_2_22_21  in_degree_1658  1
    arc_2_22_21  out_degree_1663  1
    arc_2_22_21  original_T_including_depot_unload_1672  1.1341050580477483e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_22_21  arc_capacity_1589  1
    load_2_22_21  free_load_conservation_1662  -1
    load_2_22_21  free_load_conservation_1668  1
RHS
    RHS1      OBJ       -4.9500000000000005e-01
    RHS1      onehot_6_22  1
    RHS1      onehot_2_57  1
    RHS1      onehot_31_86  1
    RHS1      onehot_9_115  1
    RHS1      onehot_32_144  1
    RHS1      onehot_8_191  1
    RHS1      onehot_16_220  1
    RHS1      onehot_13_263  1
    RHS1      stock_ub_267  34
    RHS1      parent_nonstrict_scope_268  3.7646954911354424e-01
    RHS1      normalization_325  1
    RHS1      connected_order_arc_457  -14
    RHS1      connected_order_arc_459  -14
    RHS1      connected_order_arc_461  -14
    RHS1      connected_order_arc_463  -14
    RHS1      connected_order_arc_465  -14
    RHS1      connected_order_arc_467  -14
    RHS1      connected_order_arc_469  -14
    RHS1      connected_order_arc_471  -14
    RHS1      connected_order_arc_473  -14
    RHS1      connected_order_arc_475  -14
    RHS1      connected_order_arc_477  -14
    RHS1      connected_order_arc_479  -14
    RHS1      connected_order_arc_481  -14
    RHS1      connected_order_arc_484  -14
    RHS1      connected_order_arc_486  -14
    RHS1      connected_order_arc_488  -14
    RHS1      connected_order_arc_490  -14
    RHS1      connected_order_arc_492  -14
    RHS1      connected_order_arc_494  -14
    RHS1      connected_order_arc_496  -14
    RHS1      connected_order_arc_498  -14
    RHS1      connected_order_arc_500  -14
    RHS1      connected_order_arc_502  -14
    RHS1      connected_order_arc_504  -14
    RHS1      connected_order_arc_506  -14
    RHS1      connected_order_arc_508  -14
    RHS1      connected_order_arc_511  -14
    RHS1      connected_order_arc_513  -14
    RHS1      connected_order_arc_515  -14
    RHS1      connected_order_arc_517  -14
    RHS1      connected_order_arc_519  -14
    RHS1      connected_order_arc_521  -14
    RHS1      connected_order_arc_523  -14
    RHS1      connected_order_arc_525  -14
    RHS1      connected_order_arc_527  -14
    RHS1      connected_order_arc_529  -14
    RHS1      connected_order_arc_531  -14
    RHS1      connected_order_arc_533  -14
    RHS1      connected_order_arc_535  -14
    RHS1      connected_order_arc_538  -14
    RHS1      connected_order_arc_540  -14
    RHS1      connected_order_arc_542  -14
    RHS1      connected_order_arc_544  -14
    RHS1      connected_order_arc_546  -14
    RHS1      connected_order_arc_548  -14
    RHS1      connected_order_arc_550  -14
    RHS1      connected_order_arc_552  -14
    RHS1      connected_order_arc_554  -14
    RHS1      connected_order_arc_556  -14
    RHS1      connected_order_arc_558  -14
    RHS1      connected_order_arc_560  -14
    RHS1      connected_order_arc_562  -14
    RHS1      connected_order_arc_565  -14
    RHS1      connected_order_arc_567  -14
    RHS1      connected_order_arc_569  -14
    RHS1      connected_order_arc_571  -14
    RHS1      connected_order_arc_573  -14
    RHS1      connected_order_arc_575  -14
    RHS1      connected_order_arc_577  -14
    RHS1      connected_order_arc_579  -14
    RHS1      connected_order_arc_581  -14
    RHS1      connected_order_arc_583  -14
    RHS1      connected_order_arc_585  -14
    RHS1      connected_order_arc_587  -14
    RHS1      connected_order_arc_589  -14
    RHS1      connected_order_arc_592  -14
    RHS1      connected_order_arc_594  -14
    RHS1      connected_order_arc_596  -14
    RHS1      connected_order_arc_598  -14
    RHS1      connected_order_arc_600  -14
    RHS1      connected_order_arc_602  -14
    RHS1      connected_order_arc_604  -14
    RHS1      connected_order_arc_606  -14
    RHS1      connected_order_arc_608  -14
    RHS1      connected_order_arc_610  -14
    RHS1      connected_order_arc_612  -14
    RHS1      connected_order_arc_614  -14
    RHS1      connected_order_arc_616  -14
    RHS1      connected_order_arc_619  -14
    RHS1      connected_order_arc_621  -14
    RHS1      connected_order_arc_623  -14
    RHS1      connected_order_arc_625  -14
    RHS1      connected_order_arc_627  -14
    RHS1      connected_order_arc_629  -14
    RHS1      connected_order_arc_631  -14
    RHS1      connected_order_arc_633  -14
    RHS1      connected_order_arc_635  -14
    RHS1      connected_order_arc_637  -14
    RHS1      connected_order_arc_639  -14
    RHS1      connected_order_arc_641  -14
    RHS1      connected_order_arc_643  -14
    RHS1      connected_order_arc_646  -14
    RHS1      connected_order_arc_648  -14
    RHS1      connected_order_arc_650  -14
    RHS1      connected_order_arc_652  -14
    RHS1      connected_order_arc_654  -14
    RHS1      connected_order_arc_656  -14
    RHS1      connected_order_arc_658  -14
    RHS1      connected_order_arc_660  -14
    RHS1      connected_order_arc_662  -14
    RHS1      connected_order_arc_664  -14
    RHS1      connected_order_arc_666  -14
    RHS1      connected_order_arc_668  -14
    RHS1      connected_order_arc_670  -14
    RHS1      connected_order_arc_673  -14
    RHS1      connected_order_arc_675  -14
    RHS1      connected_order_arc_677  -14
    RHS1      connected_order_arc_679  -14
    RHS1      connected_order_arc_681  -14
    RHS1      connected_order_arc_683  -14
    RHS1      connected_order_arc_685  -14
    RHS1      connected_order_arc_687  -14
    RHS1      connected_order_arc_689  -14
    RHS1      connected_order_arc_691  -14
    RHS1      connected_order_arc_693  -14
    RHS1      connected_order_arc_695  -14
    RHS1      connected_order_arc_697  -14
    RHS1      connected_order_arc_700  -14
    RHS1      connected_order_arc_702  -14
    RHS1      connected_order_arc_704  -14
    RHS1      connected_order_arc_706  -14
    RHS1      connected_order_arc_708  -14
    RHS1      connected_order_arc_710  -14
    RHS1      connected_order_arc_712  -14
    RHS1      connected_order_arc_714  -14
    RHS1      connected_order_arc_716  -14
    RHS1      connected_order_arc_718  -14
    RHS1      connected_order_arc_720  -14
    RHS1      connected_order_arc_722  -14
    RHS1      connected_order_arc_724  -14
    RHS1      connected_order_arc_727  -14
    RHS1      connected_order_arc_729  -14
    RHS1      connected_order_arc_731  -14
    RHS1      connected_order_arc_733  -14
    RHS1      connected_order_arc_735  -14
    RHS1      connected_order_arc_737  -14
    RHS1      connected_order_arc_739  -14
    RHS1      connected_order_arc_741  -14
    RHS1      connected_order_arc_743  -14
    RHS1      connected_order_arc_745  -14
    RHS1      connected_order_arc_747  -14
    RHS1      connected_order_arc_749  -14
    RHS1      connected_order_arc_751  -14
    RHS1      connected_order_arc_754  -14
    RHS1      connected_order_arc_756  -14
    RHS1      connected_order_arc_758  -14
    RHS1      connected_order_arc_760  -14
    RHS1      connected_order_arc_762  -14
    RHS1      connected_order_arc_764  -14
    RHS1      connected_order_arc_766  -14
    RHS1      connected_order_arc_768  -14
    RHS1      connected_order_arc_770  -14
    RHS1      connected_order_arc_772  -14
    RHS1      connected_order_arc_774  -14
    RHS1      connected_order_arc_776  -14
    RHS1      connected_order_arc_778  -14
    RHS1      connected_order_arc_781  -14
    RHS1      connected_order_arc_783  -14
    RHS1      connected_order_arc_785  -14
    RHS1      connected_order_arc_787  -14
    RHS1      connected_order_arc_789  -14
    RHS1      connected_order_arc_791  -14
    RHS1      connected_order_arc_793  -14
    RHS1      connected_order_arc_795  -14
    RHS1      connected_order_arc_797  -14
    RHS1      connected_order_arc_799  -14
    RHS1      connected_order_arc_801  -14
    RHS1      connected_order_arc_803  -14
    RHS1      connected_order_arc_805  -14
    RHS1      connected_order_arc_808  -14
    RHS1      connected_order_arc_810  -14
    RHS1      connected_order_arc_812  -14
    RHS1      connected_order_arc_814  -14
    RHS1      connected_order_arc_816  -14
    RHS1      connected_order_arc_818  -14
    RHS1      connected_order_arc_820  -14
    RHS1      connected_order_arc_822  -14
    RHS1      connected_order_arc_824  -14
    RHS1      connected_order_arc_826  -14
    RHS1      connected_order_arc_828  -14
    RHS1      connected_order_arc_830  -14
    RHS1      connected_order_arc_832  -14
    RHS1      depot_departure_or_bypass_833  1
    RHS1      depot_return_or_bypass_834  1
    RHS1      segment_load_conservation_839  4
    RHS1      segment_prefix_ub_841  16
    RHS1      segment_load_conservation_846  13
    RHS1      segment_prefix_ub_848  7
    RHS1      segment_load_conservation_853  -8
    RHS1      segment_prefix_lb_854  8
    RHS1      segment_prefix_ub_855  20
    RHS1      segment_load_conservation_860  -4
    RHS1      segment_prefix_lb_861  4
    RHS1      segment_prefix_ub_862  20
    RHS1      segment_load_conservation_867  -6
    RHS1      segment_prefix_lb_868  6
    RHS1      segment_prefix_ub_869  20
    RHS1      segment_load_conservation_874  -7
    RHS1      segment_prefix_lb_875  7
    RHS1      segment_prefix_ub_876  20
    RHS1      fixed_segment_relative_order_925  1
    RHS1      fixed_segment_relative_order_926  1
    RHS1      fixed_segment_relative_order_927  1
    RHS1      fixed_segment_relative_order_928  1
    RHS1      fixed_segment_relative_order_929  1
    RHS1      original_T_including_depot_unload_930  4.4350745803182617e+03
    RHS1      connected_order_arc_946  -12
    RHS1      connected_order_arc_948  -12
    RHS1      connected_order_arc_950  -12
    RHS1      connected_order_arc_952  -12
    RHS1      connected_order_arc_954  -12
    RHS1      connected_order_arc_956  -12
    RHS1      connected_order_arc_958  -12
    RHS1      connected_order_arc_960  -12
    RHS1      connected_order_arc_962  -12
    RHS1      connected_order_arc_964  -12
    RHS1      connected_order_arc_966  -12
    RHS1      connected_order_arc_969  -12
    RHS1      connected_order_arc_971  -12
    RHS1      connected_order_arc_973  -12
    RHS1      connected_order_arc_975  -12
    RHS1      connected_order_arc_977  -12
    RHS1      connected_order_arc_979  -12
    RHS1      connected_order_arc_981  -12
    RHS1      connected_order_arc_983  -12
    RHS1      connected_order_arc_985  -12
    RHS1      connected_order_arc_987  -12
    RHS1      connected_order_arc_989  -12
    RHS1      connected_order_arc_992  -12
    RHS1      connected_order_arc_994  -12
    RHS1      connected_order_arc_996  -12
    RHS1      connected_order_arc_998  -12
    RHS1      connected_order_arc_1000  -12
    RHS1      connected_order_arc_1002  -12
    RHS1      connected_order_arc_1004  -12
    RHS1      connected_order_arc_1006  -12
    RHS1      connected_order_arc_1008  -12
    RHS1      connected_order_arc_1010  -12
    RHS1      connected_order_arc_1012  -12
    RHS1      connected_order_arc_1015  -12
    RHS1      connected_order_arc_1017  -12
    RHS1      connected_order_arc_1019  -12
    RHS1      connected_order_arc_1021  -12
    RHS1      connected_order_arc_1023  -12
    RHS1      connected_order_arc_1025  -12
    RHS1      connected_order_arc_1027  -12
    RHS1      connected_order_arc_1029  -12
    RHS1      connected_order_arc_1031  -12
    RHS1      connected_order_arc_1033  -12
    RHS1      connected_order_arc_1035  -12
    RHS1      connected_order_arc_1038  -12
    RHS1      connected_order_arc_1040  -12
    RHS1      connected_order_arc_1042  -12
    RHS1      connected_order_arc_1044  -12
    RHS1      connected_order_arc_1046  -12
    RHS1      connected_order_arc_1048  -12
    RHS1      connected_order_arc_1050  -12
    RHS1      connected_order_arc_1052  -12
    RHS1      connected_order_arc_1054  -12
    RHS1      connected_order_arc_1056  -12
    RHS1      connected_order_arc_1058  -12
    RHS1      connected_order_arc_1061  -12
    RHS1      connected_order_arc_1063  -12
    RHS1      connected_order_arc_1065  -12
    RHS1      connected_order_arc_1067  -12
    RHS1      connected_order_arc_1069  -12
    RHS1      connected_order_arc_1071  -12
    RHS1      connected_order_arc_1073  -12
    RHS1      connected_order_arc_1075  -12
    RHS1      connected_order_arc_1077  -12
    RHS1      connected_order_arc_1079  -12
    RHS1      connected_order_arc_1081  -12
    RHS1      connected_order_arc_1084  -12
    RHS1      connected_order_arc_1086  -12
    RHS1      connected_order_arc_1088  -12
    RHS1      connected_order_arc_1090  -12
    RHS1      connected_order_arc_1092  -12
    RHS1      connected_order_arc_1094  -12
    RHS1      connected_order_arc_1096  -12
    RHS1      connected_order_arc_1098  -12
    RHS1      connected_order_arc_1100  -12
    RHS1      connected_order_arc_1102  -12
    RHS1      connected_order_arc_1104  -12
    RHS1      connected_order_arc_1107  -12
    RHS1      connected_order_arc_1109  -12
    RHS1      connected_order_arc_1111  -12
    RHS1      connected_order_arc_1113  -12
    RHS1      connected_order_arc_1115  -12
    RHS1      connected_order_arc_1117  -12
    RHS1      connected_order_arc_1119  -12
    RHS1      connected_order_arc_1121  -12
    RHS1      connected_order_arc_1123  -12
    RHS1      connected_order_arc_1125  -12
    RHS1      connected_order_arc_1127  -12
    RHS1      connected_order_arc_1130  -12
    RHS1      connected_order_arc_1132  -12
    RHS1      connected_order_arc_1134  -12
    RHS1      connected_order_arc_1136  -12
    RHS1      connected_order_arc_1138  -12
    RHS1      connected_order_arc_1140  -12
    RHS1      connected_order_arc_1142  -12
    RHS1      connected_order_arc_1144  -12
    RHS1      connected_order_arc_1146  -12
    RHS1      connected_order_arc_1148  -12
    RHS1      connected_order_arc_1150  -12
    RHS1      connected_order_arc_1153  -12
    RHS1      connected_order_arc_1155  -12
    RHS1      connected_order_arc_1157  -12
    RHS1      connected_order_arc_1159  -12
    RHS1      connected_order_arc_1161  -12
    RHS1      connected_order_arc_1163  -12
    RHS1      connected_order_arc_1165  -12
    RHS1      connected_order_arc_1167  -12
    RHS1      connected_order_arc_1169  -12
    RHS1      connected_order_arc_1171  -12
    RHS1      connected_order_arc_1173  -12
    RHS1      connected_order_arc_1176  -12
    RHS1      connected_order_arc_1178  -12
    RHS1      connected_order_arc_1180  -12
    RHS1      connected_order_arc_1182  -12
    RHS1      connected_order_arc_1184  -12
    RHS1      connected_order_arc_1186  -12
    RHS1      connected_order_arc_1188  -12
    RHS1      connected_order_arc_1190  -12
    RHS1      connected_order_arc_1192  -12
    RHS1      connected_order_arc_1194  -12
    RHS1      connected_order_arc_1196  -12
    RHS1      connected_order_arc_1199  -12
    RHS1      connected_order_arc_1201  -12
    RHS1      connected_order_arc_1203  -12
    RHS1      connected_order_arc_1205  -12
    RHS1      connected_order_arc_1207  -12
    RHS1      connected_order_arc_1209  -12
    RHS1      connected_order_arc_1211  -12
    RHS1      connected_order_arc_1213  -12
    RHS1      connected_order_arc_1215  -12
    RHS1      connected_order_arc_1217  -12
    RHS1      connected_order_arc_1219  -12
    RHS1      depot_departure_or_bypass_1220  1
    RHS1      depot_return_or_bypass_1221  1
    RHS1      segment_prefix_ub_1228  19
    RHS1      segment_load_conservation_1233  3
    RHS1      segment_prefix_ub_1235  22
    RHS1      segment_load_conservation_1240  3
    RHS1      segment_prefix_ub_1242  22
    RHS1      segment_load_conservation_1247  -6
    RHS1      segment_prefix_lb_1248  6
    RHS1      segment_prefix_ub_1249  25
    RHS1      fixed_segment_relative_order_1298  1
    RHS1      fixed_segment_relative_order_1299  1
    RHS1      fixed_segment_relative_order_1300  1
    RHS1      original_T_including_depot_unload_1301  2.0518370980504988e+03
    RHS1      connected_order_arc_1317  -12
    RHS1      connected_order_arc_1319  -12
    RHS1      connected_order_arc_1321  -12
    RHS1      connected_order_arc_1323  -12
    RHS1      connected_order_arc_1325  -12
    RHS1      connected_order_arc_1327  -12
    RHS1      connected_order_arc_1329  -12
    RHS1      connected_order_arc_1331  -12
    RHS1      connected_order_arc_1333  -12
    RHS1      connected_order_arc_1335  -12
    RHS1      connected_order_arc_1337  -12
    RHS1      connected_order_arc_1340  -12
    RHS1      connected_order_arc_1342  -12
    RHS1      connected_order_arc_1344  -12
    RHS1      connected_order_arc_1346  -12
    RHS1      connected_order_arc_1348  -12
    RHS1      connected_order_arc_1350  -12
    RHS1      connected_order_arc_1352  -12
    RHS1      connected_order_arc_1354  -12
    RHS1      connected_order_arc_1356  -12
    RHS1      connected_order_arc_1358  -12
    RHS1      connected_order_arc_1360  -12
    RHS1      connected_order_arc_1363  -12
    RHS1      connected_order_arc_1365  -12
    RHS1      connected_order_arc_1367  -12
    RHS1      connected_order_arc_1369  -12
    RHS1      connected_order_arc_1371  -12
    RHS1      connected_order_arc_1373  -12
    RHS1      connected_order_arc_1375  -12
    RHS1      connected_order_arc_1377  -12
    RHS1      connected_order_arc_1379  -12
    RHS1      connected_order_arc_1381  -12
    RHS1      connected_order_arc_1383  -12
    RHS1      connected_order_arc_1386  -12
    RHS1      connected_order_arc_1388  -12
    RHS1      connected_order_arc_1390  -12
    RHS1      connected_order_arc_1392  -12
    RHS1      connected_order_arc_1394  -12
    RHS1      connected_order_arc_1396  -12
    RHS1      connected_order_arc_1398  -12
    RHS1      connected_order_arc_1400  -12
    RHS1      connected_order_arc_1402  -12
    RHS1      connected_order_arc_1404  -12
    RHS1      connected_order_arc_1406  -12
    RHS1      connected_order_arc_1409  -12
    RHS1      connected_order_arc_1411  -12
    RHS1      connected_order_arc_1413  -12
    RHS1      connected_order_arc_1415  -12
    RHS1      connected_order_arc_1417  -12
    RHS1      connected_order_arc_1419  -12
    RHS1      connected_order_arc_1421  -12
    RHS1      connected_order_arc_1423  -12
    RHS1      connected_order_arc_1425  -12
    RHS1      connected_order_arc_1427  -12
    RHS1      connected_order_arc_1429  -12
    RHS1      connected_order_arc_1432  -12
    RHS1      connected_order_arc_1434  -12
    RHS1      connected_order_arc_1436  -12
    RHS1      connected_order_arc_1438  -12
    RHS1      connected_order_arc_1440  -12
    RHS1      connected_order_arc_1442  -12
    RHS1      connected_order_arc_1444  -12
    RHS1      connected_order_arc_1446  -12
    RHS1      connected_order_arc_1448  -12
    RHS1      connected_order_arc_1450  -12
    RHS1      connected_order_arc_1452  -12
    RHS1      connected_order_arc_1455  -12
    RHS1      connected_order_arc_1457  -12
    RHS1      connected_order_arc_1459  -12
    RHS1      connected_order_arc_1461  -12
    RHS1      connected_order_arc_1463  -12
    RHS1      connected_order_arc_1465  -12
    RHS1      connected_order_arc_1467  -12
    RHS1      connected_order_arc_1469  -12
    RHS1      connected_order_arc_1471  -12
    RHS1      connected_order_arc_1473  -12
    RHS1      connected_order_arc_1475  -12
    RHS1      connected_order_arc_1478  -12
    RHS1      connected_order_arc_1480  -12
    RHS1      connected_order_arc_1482  -12
    RHS1      connected_order_arc_1484  -12
    RHS1      connected_order_arc_1486  -12
    RHS1      connected_order_arc_1488  -12
    RHS1      connected_order_arc_1490  -12
    RHS1      connected_order_arc_1492  -12
    RHS1      connected_order_arc_1494  -12
    RHS1      connected_order_arc_1496  -12
    RHS1      connected_order_arc_1498  -12
    RHS1      connected_order_arc_1501  -12
    RHS1      connected_order_arc_1503  -12
    RHS1      connected_order_arc_1505  -12
    RHS1      connected_order_arc_1507  -12
    RHS1      connected_order_arc_1509  -12
    RHS1      connected_order_arc_1511  -12
    RHS1      connected_order_arc_1513  -12
    RHS1      connected_order_arc_1515  -12
    RHS1      connected_order_arc_1517  -12
    RHS1      connected_order_arc_1519  -12
    RHS1      connected_order_arc_1521  -12
    RHS1      connected_order_arc_1524  -12
    RHS1      connected_order_arc_1526  -12
    RHS1      connected_order_arc_1528  -12
    RHS1      connected_order_arc_1530  -12
    RHS1      connected_order_arc_1532  -12
    RHS1      connected_order_arc_1534  -12
    RHS1      connected_order_arc_1536  -12
    RHS1      connected_order_arc_1538  -12
    RHS1      connected_order_arc_1540  -12
    RHS1      connected_order_arc_1542  -12
    RHS1      connected_order_arc_1544  -12
    RHS1      connected_order_arc_1547  -12
    RHS1      connected_order_arc_1549  -12
    RHS1      connected_order_arc_1551  -12
    RHS1      connected_order_arc_1553  -12
    RHS1      connected_order_arc_1555  -12
    RHS1      connected_order_arc_1557  -12
    RHS1      connected_order_arc_1559  -12
    RHS1      connected_order_arc_1561  -12
    RHS1      connected_order_arc_1563  -12
    RHS1      connected_order_arc_1565  -12
    RHS1      connected_order_arc_1567  -12
    RHS1      connected_order_arc_1570  -12
    RHS1      connected_order_arc_1572  -12
    RHS1      connected_order_arc_1574  -12
    RHS1      connected_order_arc_1576  -12
    RHS1      connected_order_arc_1578  -12
    RHS1      connected_order_arc_1580  -12
    RHS1      connected_order_arc_1582  -12
    RHS1      connected_order_arc_1584  -12
    RHS1      connected_order_arc_1586  -12
    RHS1      connected_order_arc_1588  -12
    RHS1      connected_order_arc_1590  -12
    RHS1      depot_departure_or_bypass_1591  1
    RHS1      depot_return_or_bypass_1592  1
    RHS1      segment_load_conservation_1597  3
    RHS1      segment_prefix_ub_1599  27
    RHS1      segment_load_conservation_1604  -1
    RHS1      segment_prefix_lb_1605  1
    RHS1      segment_prefix_ub_1606  30
    RHS1      segment_load_conservation_1611  5
    RHS1      segment_prefix_ub_1613  25
    RHS1      segment_load_conservation_1618  -5
    RHS1      segment_prefix_lb_1619  5
    RHS1      segment_prefix_ub_1620  30
    RHS1      fixed_segment_relative_order_1669  1
    RHS1      fixed_segment_relative_order_1670  1
    RHS1      fixed_segment_relative_order_1671  1
    RHS1      original_T_including_depot_unload_1672  5752.18965781578
BOUNDS
 LO BND1      t         2.4265534275042893e-02
 UP BND1      t         4.1530703055514692e-02
 UP BND1      q         5.4596954911354423e-01
 BV BND1      x_6_0   
 UP BND1      w_6_0     4.1530703055514692e-02
 BV BND1      x_6_1   
 UP BND1      w_6_1     4.1530703055514692e-02
 BV BND1      x_6_2   
 UP BND1      w_6_2     4.1530703055514692e-02
 BV BND1      x_6_3   
 UP BND1      w_6_3     4.1530703055514692e-02
 BV BND1      x_6_4   
 UP BND1      w_6_4     4.1530703055514692e-02
 BV BND1      x_6_5   
 UP BND1      w_6_5     4.1530703055514692e-02
 BV BND1      x_6_6   
 UP BND1      w_6_6     4.1530703055514692e-02
 BV BND1      x_6_7   
 UP BND1      w_6_7     4.1530703055514692e-02
 BV BND1      x_6_8   
 UP BND1      w_6_8     4.1530703055514692e-02
 BV BND1      x_6_9   
 UP BND1      w_6_9     4.1530703055514692e-02
 BV BND1      x_6_10  
 UP BND1      w_6_10    4.1530703055514692e-02
 UP BND1      rho_6     1
 BV BND1      x_2_0   
 UP BND1      w_2_0     4.1530703055514692e-02
 BV BND1      x_2_1   
 UP BND1      w_2_1     4.1530703055514692e-02
 BV BND1      x_2_2   
 UP BND1      w_2_2     4.1530703055514692e-02
 BV BND1      x_2_3   
 UP BND1      w_2_3     4.1530703055514692e-02
 BV BND1      x_2_4   
 UP BND1      w_2_4     4.1530703055514692e-02
 BV BND1      x_2_5   
 UP BND1      w_2_5     4.1530703055514692e-02
 BV BND1      x_2_6   
 UP BND1      w_2_6     4.1530703055514692e-02
 BV BND1      x_2_7   
 UP BND1      w_2_7     4.1530703055514692e-02
 BV BND1      x_2_8   
 UP BND1      w_2_8     4.1530703055514692e-02
 BV BND1      x_2_9   
 UP BND1      w_2_9     4.1530703055514692e-02
 BV BND1      x_2_10  
 UP BND1      w_2_10    4.1530703055514692e-02
 BV BND1      x_2_11  
 UP BND1      w_2_11    4.1530703055514692e-02
 BV BND1      x_2_12  
 UP BND1      w_2_12    4.1530703055514692e-02
 BV BND1      x_2_13  
 UP BND1      w_2_13    4.1530703055514692e-02
 BV BND1      x_2_14  
 UP BND1      w_2_14    4.1530703055514692e-02
 BV BND1      x_2_15  
 UP BND1      w_2_15    4.1530703055514692e-02
 UP BND1      rho_2     1
 BV BND1      x_31_0  
 UP BND1      w_31_0    4.1530703055514692e-02
 BV BND1      x_31_1  
 UP BND1      w_31_1    4.1530703055514692e-02
 BV BND1      x_31_2  
 UP BND1      w_31_2    4.1530703055514692e-02
 BV BND1      x_31_3  
 UP BND1      w_31_3    4.1530703055514692e-02
 BV BND1      x_31_4  
 UP BND1      w_31_4    4.1530703055514692e-02
 BV BND1      x_31_5  
 UP BND1      w_31_5    4.1530703055514692e-02
 BV BND1      x_31_6  
 UP BND1      w_31_6    4.1530703055514692e-02
 BV BND1      x_31_7  
 UP BND1      w_31_7    4.1530703055514692e-02
 BV BND1      x_31_8  
 UP BND1      w_31_8    4.1530703055514692e-02
 BV BND1      x_31_9  
 UP BND1      w_31_9    4.1530703055514692e-02
 BV BND1      x_31_10 
 UP BND1      w_31_10   4.1530703055514692e-02
 BV BND1      x_31_11 
 UP BND1      w_31_11   4.1530703055514692e-02
 BV BND1      x_31_12 
 UP BND1      w_31_12   4.1530703055514692e-02
 UP BND1      rho_31    1
 BV BND1      x_9_0   
 UP BND1      w_9_0     4.1530703055514692e-02
 BV BND1      x_9_1   
 UP BND1      w_9_1     4.1530703055514692e-02
 BV BND1      x_9_2   
 UP BND1      w_9_2     4.1530703055514692e-02
 BV BND1      x_9_3   
 UP BND1      w_9_3     4.1530703055514692e-02
 BV BND1      x_9_4   
 UP BND1      w_9_4     4.1530703055514692e-02
 BV BND1      x_9_5   
 UP BND1      w_9_5     4.1530703055514692e-02
 BV BND1      x_9_6   
 UP BND1      w_9_6     4.1530703055514692e-02
 BV BND1      x_9_7   
 UP BND1      w_9_7     4.1530703055514692e-02
 BV BND1      x_9_8   
 UP BND1      w_9_8     4.1530703055514692e-02
 BV BND1      x_9_9   
 UP BND1      w_9_9     4.1530703055514692e-02
 BV BND1      x_9_10  
 UP BND1      w_9_10    4.1530703055514692e-02
 BV BND1      x_9_11  
 UP BND1      w_9_11    4.1530703055514692e-02
 BV BND1      x_9_12  
 UP BND1      w_9_12    4.1530703055514692e-02
 UP BND1      rho_9     1
 BV BND1      x_32_0  
 UP BND1      w_32_0    4.1530703055514692e-02
 BV BND1      x_32_1  
 UP BND1      w_32_1    4.1530703055514692e-02
 BV BND1      x_32_2  
 UP BND1      w_32_2    4.1530703055514692e-02
 BV BND1      x_32_3  
 UP BND1      w_32_3    4.1530703055514692e-02
 BV BND1      x_32_4  
 UP BND1      w_32_4    4.1530703055514692e-02
 BV BND1      x_32_5  
 UP BND1      w_32_5    4.1530703055514692e-02
 BV BND1      x_32_6  
 UP BND1      w_32_6    4.1530703055514692e-02
 BV BND1      x_32_7  
 UP BND1      w_32_7    4.1530703055514692e-02
 BV BND1      x_32_8  
 UP BND1      w_32_8    4.1530703055514692e-02
 BV BND1      x_32_9  
 UP BND1      w_32_9    4.1530703055514692e-02
 BV BND1      x_32_10 
 UP BND1      w_32_10   4.1530703055514692e-02
 BV BND1      x_32_11 
 UP BND1      w_32_11   4.1530703055514692e-02
 BV BND1      x_32_12 
 UP BND1      w_32_12   4.1530703055514692e-02
 UP BND1      rho_32    1
 BV BND1      x_8_0   
 UP BND1      w_8_0     4.1530703055514692e-02
 BV BND1      x_8_1   
 UP BND1      w_8_1     4.1530703055514692e-02
 BV BND1      x_8_2   
 UP BND1      w_8_2     4.1530703055514692e-02
 BV BND1      x_8_3   
 UP BND1      w_8_3     4.1530703055514692e-02
 BV BND1      x_8_4   
 UP BND1      w_8_4     4.1530703055514692e-02
 BV BND1      x_8_5   
 UP BND1      w_8_5     4.1530703055514692e-02
 BV BND1      x_8_6   
 UP BND1      w_8_6     4.1530703055514692e-02
 BV BND1      x_8_7   
 UP BND1      w_8_7     4.1530703055514692e-02
 BV BND1      x_8_8   
 UP BND1      w_8_8     4.1530703055514692e-02
 BV BND1      x_8_9   
 UP BND1      w_8_9     4.1530703055514692e-02
 BV BND1      x_8_10  
 UP BND1      w_8_10    4.1530703055514692e-02
 BV BND1      x_8_11  
 UP BND1      w_8_11    4.1530703055514692e-02
 BV BND1      x_8_12  
 UP BND1      w_8_12    4.1530703055514692e-02
 BV BND1      x_8_13  
 UP BND1      w_8_13    4.1530703055514692e-02
 BV BND1      x_8_14  
 UP BND1      w_8_14    4.1530703055514692e-02
 BV BND1      x_8_15  
 UP BND1      w_8_15    4.1530703055514692e-02
 BV BND1      x_8_16  
 UP BND1      w_8_16    4.1530703055514692e-02
 BV BND1      x_8_17  
 UP BND1      w_8_17    4.1530703055514692e-02
 BV BND1      x_8_18  
 UP BND1      w_8_18    4.1530703055514692e-02
 BV BND1      x_8_19  
 UP BND1      w_8_19    4.1530703055514692e-02
 BV BND1      x_8_20  
 UP BND1      w_8_20    4.1530703055514692e-02
 BV BND1      x_8_21  
 UP BND1      w_8_21    4.1530703055514692e-02
 UP BND1      rho_8     1
 BV BND1      x_16_0  
 UP BND1      w_16_0    4.1530703055514692e-02
 BV BND1      x_16_1  
 UP BND1      w_16_1    4.1530703055514692e-02
 BV BND1      x_16_2  
 UP BND1      w_16_2    4.1530703055514692e-02
 BV BND1      x_16_3  
 UP BND1      w_16_3    4.1530703055514692e-02
 BV BND1      x_16_4  
 UP BND1      w_16_4    4.1530703055514692e-02
 BV BND1      x_16_5  
 UP BND1      w_16_5    4.1530703055514692e-02
 BV BND1      x_16_6  
 UP BND1      w_16_6    4.1530703055514692e-02
 BV BND1      x_16_7  
 UP BND1      w_16_7    4.1530703055514692e-02
 BV BND1      x_16_8  
 UP BND1      w_16_8    4.1530703055514692e-02
 BV BND1      x_16_9  
 UP BND1      w_16_9    4.1530703055514692e-02
 BV BND1      x_16_10 
 UP BND1      w_16_10   4.1530703055514692e-02
 BV BND1      x_16_11 
 UP BND1      w_16_11   4.1530703055514692e-02
 BV BND1      x_16_12 
 UP BND1      w_16_12   4.1530703055514692e-02
 UP BND1      rho_16    1
 BV BND1      x_13_0  
 UP BND1      w_13_0    4.1530703055514692e-02
 BV BND1      x_13_1  
 UP BND1      w_13_1    4.1530703055514692e-02
 BV BND1      x_13_2  
 UP BND1      w_13_2    4.1530703055514692e-02
 BV BND1      x_13_3  
 UP BND1      w_13_3    4.1530703055514692e-02
 BV BND1      x_13_4  
 UP BND1      w_13_4    4.1530703055514692e-02
 BV BND1      x_13_5  
 UP BND1      w_13_5    4.1530703055514692e-02
 BV BND1      x_13_6  
 UP BND1      w_13_6    4.1530703055514692e-02
 BV BND1      x_13_7  
 UP BND1      w_13_7    4.1530703055514692e-02
 BV BND1      x_13_8  
 UP BND1      w_13_8    4.1530703055514692e-02
 BV BND1      x_13_9  
 UP BND1      w_13_9    4.1530703055514692e-02
 BV BND1      x_13_10 
 UP BND1      w_13_10   4.1530703055514692e-02
 BV BND1      x_13_11 
 UP BND1      w_13_11   4.1530703055514692e-02
 BV BND1      x_13_12 
 UP BND1      w_13_12   4.1530703055514692e-02
 BV BND1      x_13_13 
 UP BND1      w_13_13   4.1530703055514692e-02
 BV BND1      x_13_14 
 UP BND1      w_13_14   4.1530703055514692e-02
 BV BND1      x_13_15 
 UP BND1      w_13_15   4.1530703055514692e-02
 BV BND1      x_13_16 
 UP BND1      w_13_16   4.1530703055514692e-02
 BV BND1      x_13_17 
 UP BND1      w_13_17   4.1530703055514692e-02
 BV BND1      x_13_18 
 UP BND1      w_13_18   4.1530703055514692e-02
 BV BND1      x_13_19 
 UP BND1      w_13_19   4.1530703055514692e-02
 UP BND1      rho_13    1
 UP BND1      a_6_2     1
 UP BND1      a_6_31    1
 UP BND1      a_6_9     1
 UP BND1      a_6_32    1
 UP BND1      a_6_8     1
 UP BND1      a_6_16    1
 UP BND1      a_6_13    1
 UP BND1      a_2_31    1
 UP BND1      a_2_9     1
 UP BND1      a_2_32    1
 UP BND1      a_2_8     1
 UP BND1      a_2_16    1
 UP BND1      a_2_13    1
 UP BND1      a_31_9    1
 UP BND1      a_31_32   1
 UP BND1      a_31_8    1
 UP BND1      a_31_16   1
 UP BND1      a_31_13   1
 UP BND1      a_9_32    1
 UP BND1      a_9_8     1
 UP BND1      a_9_16    1
 UP BND1      a_9_13    1
 UP BND1      a_32_8    1
 UP BND1      a_32_16   1
 UP BND1      a_32_13   1
 UP BND1      a_8_16    1
 UP BND1      a_8_13    1
 UP BND1      a_16_13   1
 BV BND1      service_0_6_0
 BV BND1      service_0_6_2
 BV BND1      service_0_6_3
 BV BND1      service_0_6_4
 BV BND1      service_0_6_5
 BV BND1      service_0_6_6
 BV BND1      service_0_6_7
 BV BND1      service_0_6_8
 BV BND1      service_0_6_9
 BV BND1      service_0_6_10
 BV BND1      service_1_6_0
 BV BND1      service_1_6_2
 BV BND1      service_1_6_3
 BV BND1      service_1_6_4
 BV BND1      service_1_6_5
 BV BND1      service_1_6_6
 BV BND1      service_1_6_7
 BV BND1      service_1_6_8
 BV BND1      service_1_6_9
 BV BND1      service_1_6_10
 BV BND1      service_2_6_0
 BV BND1      service_2_6_2
 BV BND1      service_2_6_3
 BV BND1      service_2_6_4
 BV BND1      service_2_6_5
 BV BND1      service_2_6_6
 BV BND1      service_2_6_7
 BV BND1      service_2_6_8
 BV BND1      service_2_6_9
 BV BND1      service_2_6_10
 BV BND1      service_0_2_1
 BV BND1      service_0_2_2
 BV BND1      service_0_2_3
 BV BND1      service_0_2_4
 BV BND1      service_0_2_5
 BV BND1      service_0_2_6
 BV BND1      service_0_2_7
 BV BND1      service_0_2_8
 BV BND1      service_0_2_9
 BV BND1      service_0_2_10
 BV BND1      service_0_2_11
 BV BND1      service_0_2_12
 BV BND1      service_0_2_13
 BV BND1      service_0_2_14
 BV BND1      service_0_2_15
 BV BND1      service_1_2_1
 BV BND1      service_1_2_2
 BV BND1      service_1_2_3
 BV BND1      service_1_2_4
 BV BND1      service_1_2_5
 BV BND1      service_1_2_6
 BV BND1      service_1_2_7
 BV BND1      service_1_2_8
 BV BND1      service_1_2_9
 BV BND1      service_1_2_10
 BV BND1      service_1_2_11
 BV BND1      service_1_2_12
 BV BND1      service_1_2_13
 BV BND1      service_1_2_14
 BV BND1      service_1_2_15
 BV BND1      service_2_2_1
 BV BND1      service_2_2_2
 BV BND1      service_2_2_3
 BV BND1      service_2_2_4
 BV BND1      service_2_2_5
 BV BND1      service_2_2_6
 BV BND1      service_2_2_7
 BV BND1      service_2_2_8
 BV BND1      service_2_2_9
 BV BND1      service_2_2_10
 BV BND1      service_2_2_11
 BV BND1      service_2_2_12
 BV BND1      service_2_2_13
 BV BND1      service_2_2_14
 BV BND1      service_2_2_15
 BV BND1      service_0_31_0
 BV BND1      service_0_31_1
 BV BND1      service_0_31_3
 BV BND1      service_0_31_4
 BV BND1      service_0_31_5
 BV BND1      service_0_31_6
 BV BND1      service_0_31_7
 BV BND1      service_0_31_8
 BV BND1      service_0_31_9
 BV BND1      service_0_31_10
 BV BND1      service_0_31_11
 BV BND1      service_0_31_12
 BV BND1      service_1_31_0
 BV BND1      service_1_31_1
 BV BND1      service_1_31_3
 BV BND1      service_1_31_4
 BV BND1      service_1_31_5
 BV BND1      service_1_31_6
 BV BND1      service_1_31_7
 BV BND1      service_1_31_8
 BV BND1      service_1_31_9
 BV BND1      service_1_31_10
 BV BND1      service_1_31_11
 BV BND1      service_1_31_12
 BV BND1      service_2_31_0
 BV BND1      service_2_31_1
 BV BND1      service_2_31_3
 BV BND1      service_2_31_4
 BV BND1      service_2_31_5
 BV BND1      service_2_31_6
 BV BND1      service_2_31_7
 BV BND1      service_2_31_8
 BV BND1      service_2_31_9
 BV BND1      service_2_31_10
 BV BND1      service_2_31_11
 BV BND1      service_2_31_12
 BV BND1      service_0_9_0
 BV BND1      service_0_9_1
 BV BND1      service_0_9_2
 BV BND1      service_0_9_3
 BV BND1      service_0_9_4
 BV BND1      service_0_9_5
 BV BND1      service_0_9_6
 BV BND1      service_0_9_7
 BV BND1      service_0_9_9
 BV BND1      service_0_9_10
 BV BND1      service_0_9_11
 BV BND1      service_0_9_12
 BV BND1      service_1_9_0
 BV BND1      service_1_9_1
 BV BND1      service_1_9_2
 BV BND1      service_1_9_3
 BV BND1      service_1_9_4
 BV BND1      service_1_9_5
 BV BND1      service_1_9_6
 BV BND1      service_1_9_7
 BV BND1      service_1_9_9
 BV BND1      service_1_9_10
 BV BND1      service_1_9_11
 BV BND1      service_1_9_12
 BV BND1      service_2_9_0
 BV BND1      service_2_9_1
 BV BND1      service_2_9_2
 BV BND1      service_2_9_3
 BV BND1      service_2_9_4
 BV BND1      service_2_9_5
 BV BND1      service_2_9_6
 BV BND1      service_2_9_7
 BV BND1      service_2_9_9
 BV BND1      service_2_9_10
 BV BND1      service_2_9_11
 BV BND1      service_2_9_12
 BV BND1      service_0_32_1
 BV BND1      service_0_32_2
 BV BND1      service_0_32_3
 BV BND1      service_0_32_4
 BV BND1      service_0_32_5
 BV BND1      service_0_32_6
 BV BND1      service_0_32_7
 BV BND1      service_0_32_8
 BV BND1      service_0_32_9
 BV BND1      service_0_32_10
 BV BND1      service_0_32_11
 BV BND1      service_0_32_12
 BV BND1      service_1_32_1
 BV BND1      service_1_32_2
 BV BND1      service_1_32_3
 BV BND1      service_1_32_4
 BV BND1      service_1_32_5
 BV BND1      service_1_32_6
 BV BND1      service_1_32_7
 BV BND1      service_1_32_8
 BV BND1      service_1_32_9
 BV BND1      service_1_32_10
 BV BND1      service_1_32_11
 BV BND1      service_1_32_12
 BV BND1      service_2_32_1
 BV BND1      service_2_32_2
 BV BND1      service_2_32_3
 BV BND1      service_2_32_4
 BV BND1      service_2_32_5
 BV BND1      service_2_32_6
 BV BND1      service_2_32_7
 BV BND1      service_2_32_8
 BV BND1      service_2_32_9
 BV BND1      service_2_32_10
 BV BND1      service_2_32_11
 BV BND1      service_2_32_12
 BV BND1      service_0_8_0
 BV BND1      service_0_8_1
 BV BND1      service_0_8_2
 BV BND1      service_0_8_3
 BV BND1      service_0_8_4
 BV BND1      service_0_8_5
 BV BND1      service_0_8_6
 BV BND1      service_0_8_7
 BV BND1      service_0_8_8
 BV BND1      service_0_8_9
 BV BND1      service_0_8_10
 BV BND1      service_0_8_11
 BV BND1      service_0_8_12
 BV BND1      service_0_8_13
 BV BND1      service_0_8_14
 BV BND1      service_0_8_16
 BV BND1      service_0_8_17
 BV BND1      service_0_8_18
 BV BND1      service_0_8_19
 BV BND1      service_0_8_20
 BV BND1      service_0_8_21
 BV BND1      service_1_8_0
 BV BND1      service_1_8_1
 BV BND1      service_1_8_2
 BV BND1      service_1_8_3
 BV BND1      service_1_8_4
 BV BND1      service_1_8_5
 BV BND1      service_1_8_6
 BV BND1      service_1_8_7
 BV BND1      service_1_8_8
 BV BND1      service_1_8_9
 BV BND1      service_1_8_10
 BV BND1      service_1_8_11
 BV BND1      service_1_8_12
 BV BND1      service_1_8_13
 BV BND1      service_1_8_14
 BV BND1      service_1_8_16
 BV BND1      service_1_8_17
 BV BND1      service_1_8_18
 BV BND1      service_1_8_19
 BV BND1      service_1_8_20
 BV BND1      service_1_8_21
 BV BND1      service_2_8_0
 BV BND1      service_2_8_1
 BV BND1      service_2_8_2
 BV BND1      service_2_8_3
 BV BND1      service_2_8_4
 BV BND1      service_2_8_5
 BV BND1      service_2_8_6
 BV BND1      service_2_8_7
 BV BND1      service_2_8_8
 BV BND1      service_2_8_9
 BV BND1      service_2_8_10
 BV BND1      service_2_8_11
 BV BND1      service_2_8_12
 BV BND1      service_2_8_13
 BV BND1      service_2_8_14
 BV BND1      service_2_8_16
 BV BND1      service_2_8_17
 BV BND1      service_2_8_18
 BV BND1      service_2_8_19
 BV BND1      service_2_8_20
 BV BND1      service_2_8_21
 BV BND1      service_0_16_0
 BV BND1      service_0_16_2
 BV BND1      service_0_16_3
 BV BND1      service_0_16_4
 BV BND1      service_0_16_5
 BV BND1      service_0_16_6
 BV BND1      service_0_16_7
 BV BND1      service_0_16_8
 BV BND1      service_0_16_9
 BV BND1      service_0_16_10
 BV BND1      service_0_16_11
 BV BND1      service_0_16_12
 BV BND1      service_1_16_0
 BV BND1      service_1_16_2
 BV BND1      service_1_16_3
 BV BND1      service_1_16_4
 BV BND1      service_1_16_5
 BV BND1      service_1_16_6
 BV BND1      service_1_16_7
 BV BND1      service_1_16_8
 BV BND1      service_1_16_9
 BV BND1      service_1_16_10
 BV BND1      service_1_16_11
 BV BND1      service_1_16_12
 BV BND1      service_2_16_0
 BV BND1      service_2_16_2
 BV BND1      service_2_16_3
 BV BND1      service_2_16_4
 BV BND1      service_2_16_5
 BV BND1      service_2_16_6
 BV BND1      service_2_16_7
 BV BND1      service_2_16_8
 BV BND1      service_2_16_9
 BV BND1      service_2_16_10
 BV BND1      service_2_16_11
 BV BND1      service_2_16_12
 BV BND1      service_0_13_0
 BV BND1      service_0_13_1
 BV BND1      service_0_13_2
 BV BND1      service_0_13_3
 BV BND1      service_0_13_4
 BV BND1      service_0_13_5
 BV BND1      service_0_13_6
 BV BND1      service_0_13_7
 BV BND1      service_0_13_8
 BV BND1      service_0_13_9
 BV BND1      service_0_13_10
 BV BND1      service_0_13_11
 BV BND1      service_0_13_12
 BV BND1      service_0_13_14
 BV BND1      service_0_13_15
 BV BND1      service_0_13_16
 BV BND1      service_0_13_17
 BV BND1      service_0_13_18
 BV BND1      service_0_13_19
 BV BND1      service_1_13_0
 BV BND1      service_1_13_1
 BV BND1      service_1_13_2
 BV BND1      service_1_13_3
 BV BND1      service_1_13_4
 BV BND1      service_1_13_5
 BV BND1      service_1_13_6
 BV BND1      service_1_13_7
 BV BND1      service_1_13_8
 BV BND1      service_1_13_9
 BV BND1      service_1_13_10
 BV BND1      service_1_13_11
 BV BND1      service_1_13_12
 BV BND1      service_1_13_14
 BV BND1      service_1_13_15
 BV BND1      service_1_13_16
 BV BND1      service_1_13_17
 BV BND1      service_1_13_18
 BV BND1      service_1_13_19
 BV BND1      service_2_13_0
 BV BND1      service_2_13_1
 BV BND1      service_2_13_2
 BV BND1      service_2_13_3
 BV BND1      service_2_13_4
 BV BND1      service_2_13_5
 BV BND1      service_2_13_6
 BV BND1      service_2_13_7
 BV BND1      service_2_13_8
 BV BND1      service_2_13_9
 BV BND1      service_2_13_10
 BV BND1      service_2_13_11
 BV BND1      service_2_13_12
 BV BND1      service_2_13_14
 BV BND1      service_2_13_15
 BV BND1      service_2_13_16
 BV BND1      service_2_13_17
 BV BND1      service_2_13_18
 BV BND1      service_2_13_19
 FX BND1      visit_0_1  1
 UP BND1      order_0_1  14
 FX BND1      visit_0_2  1
 UP BND1      order_0_2  14
 FX BND1      visit_0_3  1
 UP BND1      order_0_3  14
 FX BND1      visit_0_4  1
 UP BND1      order_0_4  14
 FX BND1      visit_0_5  1
 UP BND1      order_0_5  14
 FX BND1      visit_0_6  1
 UP BND1      order_0_6  14
 UP BND1      visit_0_15  1
 UP BND1      order_0_15  14
 UP BND1      visit_0_16  1
 UP BND1      order_0_16  14
 UP BND1      visit_0_17  1
 UP BND1      order_0_17  14
 UP BND1      visit_0_18  1
 UP BND1      order_0_18  14
 UP BND1      visit_0_19  1
 UP BND1      order_0_19  14
 UP BND1      visit_0_20  1
 UP BND1      order_0_20  14
 UP BND1      visit_0_21  1
 UP BND1      order_0_21  14
 UP BND1      visit_0_22  1
 UP BND1      order_0_22  14
 BV BND1      arc_0_0_0
 FX BND1      load_0_0_0  0
 BV BND1      arc_0_0_1
 FX BND1      load_0_0_1  0
 BV BND1      arc_0_0_2
 FX BND1      load_0_0_2  0
 BV BND1      arc_0_0_3
 FX BND1      load_0_0_3  0
 BV BND1      arc_0_0_4
 FX BND1      load_0_0_4  0
 BV BND1      arc_0_0_5
 FX BND1      load_0_0_5  0
 BV BND1      arc_0_0_6
 FX BND1      load_0_0_6  0
 BV BND1      arc_0_0_15
 FX BND1      load_0_0_15  0
 BV BND1      arc_0_0_16
 FX BND1      load_0_0_16  0
 BV BND1      arc_0_0_17
 FX BND1      load_0_0_17  0
 BV BND1      arc_0_0_18
 FX BND1      load_0_0_18  0
 BV BND1      arc_0_0_19
 FX BND1      load_0_0_19  0
 BV BND1      arc_0_0_20
 FX BND1      load_0_0_20  0
 BV BND1      arc_0_0_21
 FX BND1      load_0_0_21  0
 BV BND1      arc_0_0_22
 FX BND1      load_0_0_22  0
 BV BND1      arc_0_1_0
 UP BND1      load_0_1_0  20
 BV BND1      arc_0_1_2
 UP BND1      load_0_1_2  20
 BV BND1      arc_0_1_3
 UP BND1      load_0_1_3  20
 BV BND1      arc_0_1_4
 UP BND1      load_0_1_4  20
 BV BND1      arc_0_1_5
 UP BND1      load_0_1_5  20
 BV BND1      arc_0_1_6
 UP BND1      load_0_1_6  20
 BV BND1      arc_0_1_15
 UP BND1      load_0_1_15  20
 BV BND1      arc_0_1_16
 UP BND1      load_0_1_16  20
 BV BND1      arc_0_1_17
 UP BND1      load_0_1_17  20
 BV BND1      arc_0_1_18
 UP BND1      load_0_1_18  20
 BV BND1      arc_0_1_19
 UP BND1      load_0_1_19  20
 BV BND1      arc_0_1_20
 UP BND1      load_0_1_20  20
 BV BND1      arc_0_1_21
 UP BND1      load_0_1_21  20
 BV BND1      arc_0_1_22
 UP BND1      load_0_1_22  20
 BV BND1      arc_0_2_0
 UP BND1      load_0_2_0  20
 BV BND1      arc_0_2_1
 UP BND1      load_0_2_1  20
 BV BND1      arc_0_2_3
 UP BND1      load_0_2_3  20
 BV BND1      arc_0_2_4
 UP BND1      load_0_2_4  20
 BV BND1      arc_0_2_5
 UP BND1      load_0_2_5  20
 BV BND1      arc_0_2_6
 UP BND1      load_0_2_6  20
 BV BND1      arc_0_2_15
 UP BND1      load_0_2_15  20
 BV BND1      arc_0_2_16
 UP BND1      load_0_2_16  20
 BV BND1      arc_0_2_17
 UP BND1      load_0_2_17  20
 BV BND1      arc_0_2_18
 UP BND1      load_0_2_18  20
 BV BND1      arc_0_2_19
 UP BND1      load_0_2_19  20
 BV BND1      arc_0_2_20
 UP BND1      load_0_2_20  20
 BV BND1      arc_0_2_21
 UP BND1      load_0_2_21  20
 BV BND1      arc_0_2_22
 UP BND1      load_0_2_22  20
 BV BND1      arc_0_3_0
 UP BND1      load_0_3_0  20
 BV BND1      arc_0_3_1
 UP BND1      load_0_3_1  20
 BV BND1      arc_0_3_2
 UP BND1      load_0_3_2  20
 BV BND1      arc_0_3_4
 UP BND1      load_0_3_4  20
 BV BND1      arc_0_3_5
 UP BND1      load_0_3_5  20
 BV BND1      arc_0_3_6
 UP BND1      load_0_3_6  20
 BV BND1      arc_0_3_15
 UP BND1      load_0_3_15  20
 BV BND1      arc_0_3_16
 UP BND1      load_0_3_16  20
 BV BND1      arc_0_3_17
 UP BND1      load_0_3_17  20
 BV BND1      arc_0_3_18
 UP BND1      load_0_3_18  20
 BV BND1      arc_0_3_19
 UP BND1      load_0_3_19  20
 BV BND1      arc_0_3_20
 UP BND1      load_0_3_20  20
 BV BND1      arc_0_3_21
 UP BND1      load_0_3_21  20
 BV BND1      arc_0_3_22
 UP BND1      load_0_3_22  20
 BV BND1      arc_0_4_0
 UP BND1      load_0_4_0  20
 BV BND1      arc_0_4_1
 UP BND1      load_0_4_1  20
 BV BND1      arc_0_4_2
 UP BND1      load_0_4_2  20
 BV BND1      arc_0_4_3
 UP BND1      load_0_4_3  20
 BV BND1      arc_0_4_5
 UP BND1      load_0_4_5  20
 BV BND1      arc_0_4_6
 UP BND1      load_0_4_6  20
 BV BND1      arc_0_4_15
 UP BND1      load_0_4_15  20
 BV BND1      arc_0_4_16
 UP BND1      load_0_4_16  20
 BV BND1      arc_0_4_17
 UP BND1      load_0_4_17  20
 BV BND1      arc_0_4_18
 UP BND1      load_0_4_18  20
 BV BND1      arc_0_4_19
 UP BND1      load_0_4_19  20
 BV BND1      arc_0_4_20
 UP BND1      load_0_4_20  20
 BV BND1      arc_0_4_21
 UP BND1      load_0_4_21  20
 BV BND1      arc_0_4_22
 UP BND1      load_0_4_22  20
 BV BND1      arc_0_5_0
 UP BND1      load_0_5_0  20
 BV BND1      arc_0_5_1
 UP BND1      load_0_5_1  20
 BV BND1      arc_0_5_2
 UP BND1      load_0_5_2  20
 BV BND1      arc_0_5_3
 UP BND1      load_0_5_3  20
 BV BND1      arc_0_5_4
 UP BND1      load_0_5_4  20
 BV BND1      arc_0_5_6
 UP BND1      load_0_5_6  20
 BV BND1      arc_0_5_15
 UP BND1      load_0_5_15  20
 BV BND1      arc_0_5_16
 UP BND1      load_0_5_16  20
 BV BND1      arc_0_5_17
 UP BND1      load_0_5_17  20
 BV BND1      arc_0_5_18
 UP BND1      load_0_5_18  20
 BV BND1      arc_0_5_19
 UP BND1      load_0_5_19  20
 BV BND1      arc_0_5_20
 UP BND1      load_0_5_20  20
 BV BND1      arc_0_5_21
 UP BND1      load_0_5_21  20
 BV BND1      arc_0_5_22
 UP BND1      load_0_5_22  20
 BV BND1      arc_0_6_0
 UP BND1      load_0_6_0  20
 BV BND1      arc_0_6_1
 UP BND1      load_0_6_1  20
 BV BND1      arc_0_6_2
 UP BND1      load_0_6_2  20
 BV BND1      arc_0_6_3
 UP BND1      load_0_6_3  20
 BV BND1      arc_0_6_4
 UP BND1      load_0_6_4  20
 BV BND1      arc_0_6_5
 UP BND1      load_0_6_5  20
 BV BND1      arc_0_6_15
 UP BND1      load_0_6_15  20
 BV BND1      arc_0_6_16
 UP BND1      load_0_6_16  20
 BV BND1      arc_0_6_17
 UP BND1      load_0_6_17  20
 BV BND1      arc_0_6_18
 UP BND1      load_0_6_18  20
 BV BND1      arc_0_6_19
 UP BND1      load_0_6_19  20
 BV BND1      arc_0_6_20
 UP BND1      load_0_6_20  20
 BV BND1      arc_0_6_21
 UP BND1      load_0_6_21  20
 BV BND1      arc_0_6_22
 UP BND1      load_0_6_22  20
 BV BND1      arc_0_15_0
 UP BND1      load_0_15_0  20
 BV BND1      arc_0_15_1
 UP BND1      load_0_15_1  20
 BV BND1      arc_0_15_2
 UP BND1      load_0_15_2  20
 BV BND1      arc_0_15_3
 UP BND1      load_0_15_3  20
 BV BND1      arc_0_15_4
 UP BND1      load_0_15_4  20
 BV BND1      arc_0_15_5
 UP BND1      load_0_15_5  20
 BV BND1      arc_0_15_6
 UP BND1      load_0_15_6  20
 BV BND1      arc_0_15_16
 UP BND1      load_0_15_16  20
 BV BND1      arc_0_15_17
 UP BND1      load_0_15_17  20
 BV BND1      arc_0_15_18
 UP BND1      load_0_15_18  20
 BV BND1      arc_0_15_19
 UP BND1      load_0_15_19  20
 BV BND1      arc_0_15_20
 UP BND1      load_0_15_20  20
 BV BND1      arc_0_15_21
 UP BND1      load_0_15_21  20
 BV BND1      arc_0_15_22
 UP BND1      load_0_15_22  20
 BV BND1      arc_0_16_0
 UP BND1      load_0_16_0  20
 BV BND1      arc_0_16_1
 UP BND1      load_0_16_1  20
 BV BND1      arc_0_16_2
 UP BND1      load_0_16_2  20
 BV BND1      arc_0_16_3
 UP BND1      load_0_16_3  20
 BV BND1      arc_0_16_4
 UP BND1      load_0_16_4  20
 BV BND1      arc_0_16_5
 UP BND1      load_0_16_5  20
 BV BND1      arc_0_16_6
 UP BND1      load_0_16_6  20
 BV BND1      arc_0_16_15
 UP BND1      load_0_16_15  20
 BV BND1      arc_0_16_17
 UP BND1      load_0_16_17  20
 BV BND1      arc_0_16_18
 UP BND1      load_0_16_18  20
 BV BND1      arc_0_16_19
 UP BND1      load_0_16_19  20
 BV BND1      arc_0_16_20
 UP BND1      load_0_16_20  20
 BV BND1      arc_0_16_21
 UP BND1      load_0_16_21  20
 BV BND1      arc_0_16_22
 UP BND1      load_0_16_22  20
 BV BND1      arc_0_17_0
 UP BND1      load_0_17_0  20
 BV BND1      arc_0_17_1
 UP BND1      load_0_17_1  20
 BV BND1      arc_0_17_2
 UP BND1      load_0_17_2  20
 BV BND1      arc_0_17_3
 UP BND1      load_0_17_3  20
 BV BND1      arc_0_17_4
 UP BND1      load_0_17_4  20
 BV BND1      arc_0_17_5
 UP BND1      load_0_17_5  20
 BV BND1      arc_0_17_6
 UP BND1      load_0_17_6  20
 BV BND1      arc_0_17_15
 UP BND1      load_0_17_15  20
 BV BND1      arc_0_17_16
 UP BND1      load_0_17_16  20
 BV BND1      arc_0_17_18
 UP BND1      load_0_17_18  20
 BV BND1      arc_0_17_19
 UP BND1      load_0_17_19  20
 BV BND1      arc_0_17_20
 UP BND1      load_0_17_20  20
 BV BND1      arc_0_17_21
 UP BND1      load_0_17_21  20
 BV BND1      arc_0_17_22
 UP BND1      load_0_17_22  20
 BV BND1      arc_0_18_0
 UP BND1      load_0_18_0  20
 BV BND1      arc_0_18_1
 UP BND1      load_0_18_1  20
 BV BND1      arc_0_18_2
 UP BND1      load_0_18_2  20
 BV BND1      arc_0_18_3
 UP BND1      load_0_18_3  20
 BV BND1      arc_0_18_4
 UP BND1      load_0_18_4  20
 BV BND1      arc_0_18_5
 UP BND1      load_0_18_5  20
 BV BND1      arc_0_18_6
 UP BND1      load_0_18_6  20
 BV BND1      arc_0_18_15
 UP BND1      load_0_18_15  20
 BV BND1      arc_0_18_16
 UP BND1      load_0_18_16  20
 BV BND1      arc_0_18_17
 UP BND1      load_0_18_17  20
 BV BND1      arc_0_18_19
 UP BND1      load_0_18_19  20
 BV BND1      arc_0_18_20
 UP BND1      load_0_18_20  20
 BV BND1      arc_0_18_21
 UP BND1      load_0_18_21  20
 BV BND1      arc_0_18_22
 UP BND1      load_0_18_22  20
 BV BND1      arc_0_19_0
 UP BND1      load_0_19_0  20
 BV BND1      arc_0_19_1
 UP BND1      load_0_19_1  20
 BV BND1      arc_0_19_2
 UP BND1      load_0_19_2  20
 BV BND1      arc_0_19_3
 UP BND1      load_0_19_3  20
 BV BND1      arc_0_19_4
 UP BND1      load_0_19_4  20
 BV BND1      arc_0_19_5
 UP BND1      load_0_19_5  20
 BV BND1      arc_0_19_6
 UP BND1      load_0_19_6  20
 BV BND1      arc_0_19_15
 UP BND1      load_0_19_15  20
 BV BND1      arc_0_19_16
 UP BND1      load_0_19_16  20
 BV BND1      arc_0_19_17
 UP BND1      load_0_19_17  20
 BV BND1      arc_0_19_18
 UP BND1      load_0_19_18  20
 BV BND1      arc_0_19_20
 UP BND1      load_0_19_20  20
 BV BND1      arc_0_19_21
 UP BND1      load_0_19_21  20
 BV BND1      arc_0_19_22
 UP BND1      load_0_19_22  20
 BV BND1      arc_0_20_0
 UP BND1      load_0_20_0  20
 BV BND1      arc_0_20_1
 UP BND1      load_0_20_1  20
 BV BND1      arc_0_20_2
 UP BND1      load_0_20_2  20
 BV BND1      arc_0_20_3
 UP BND1      load_0_20_3  20
 BV BND1      arc_0_20_4
 UP BND1      load_0_20_4  20
 BV BND1      arc_0_20_5
 UP BND1      load_0_20_5  20
 BV BND1      arc_0_20_6
 UP BND1      load_0_20_6  20
 BV BND1      arc_0_20_15
 UP BND1      load_0_20_15  20
 BV BND1      arc_0_20_16
 UP BND1      load_0_20_16  20
 BV BND1      arc_0_20_17
 UP BND1      load_0_20_17  20
 BV BND1      arc_0_20_18
 UP BND1      load_0_20_18  20
 BV BND1      arc_0_20_19
 UP BND1      load_0_20_19  20
 BV BND1      arc_0_20_21
 UP BND1      load_0_20_21  20
 BV BND1      arc_0_20_22
 UP BND1      load_0_20_22  20
 BV BND1      arc_0_21_0
 UP BND1      load_0_21_0  20
 BV BND1      arc_0_21_1
 UP BND1      load_0_21_1  20
 BV BND1      arc_0_21_2
 UP BND1      load_0_21_2  20
 BV BND1      arc_0_21_3
 UP BND1      load_0_21_3  20
 BV BND1      arc_0_21_4
 UP BND1      load_0_21_4  20
 BV BND1      arc_0_21_5
 UP BND1      load_0_21_5  20
 BV BND1      arc_0_21_6
 UP BND1      load_0_21_6  20
 BV BND1      arc_0_21_15
 UP BND1      load_0_21_15  20
 BV BND1      arc_0_21_16
 UP BND1      load_0_21_16  20
 BV BND1      arc_0_21_17
 UP BND1      load_0_21_17  20
 BV BND1      arc_0_21_18
 UP BND1      load_0_21_18  20
 BV BND1      arc_0_21_19
 UP BND1      load_0_21_19  20
 BV BND1      arc_0_21_20
 UP BND1      load_0_21_20  20
 BV BND1      arc_0_21_22
 UP BND1      load_0_21_22  20
 BV BND1      arc_0_22_0
 UP BND1      load_0_22_0  20
 BV BND1      arc_0_22_1
 UP BND1      load_0_22_1  20
 BV BND1      arc_0_22_2
 UP BND1      load_0_22_2  20
 BV BND1      arc_0_22_3
 UP BND1      load_0_22_3  20
 BV BND1      arc_0_22_4
 UP BND1      load_0_22_4  20
 BV BND1      arc_0_22_5
 UP BND1      load_0_22_5  20
 BV BND1      arc_0_22_6
 UP BND1      load_0_22_6  20
 BV BND1      arc_0_22_15
 UP BND1      load_0_22_15  20
 BV BND1      arc_0_22_16
 UP BND1      load_0_22_16  20
 BV BND1      arc_0_22_17
 UP BND1      load_0_22_17  20
 BV BND1      arc_0_22_18
 UP BND1      load_0_22_18  20
 BV BND1      arc_0_22_19
 UP BND1      load_0_22_19  20
 BV BND1      arc_0_22_20
 UP BND1      load_0_22_20  20
 BV BND1      arc_0_22_21
 UP BND1      load_0_22_21  20
 FX BND1      visit_1_7  1
 UP BND1      order_1_7  12
 FX BND1      visit_1_8  1
 UP BND1      order_1_8  12
 FX BND1      visit_1_9  1
 UP BND1      order_1_9  12
 FX BND1      visit_1_10  1
 UP BND1      order_1_10  12
 UP BND1      visit_1_15  1
 UP BND1      order_1_15  12
 UP BND1      visit_1_16  1
 UP BND1      order_1_16  12
 UP BND1      visit_1_17  1
 UP BND1      order_1_17  12
 UP BND1      visit_1_18  1
 UP BND1      order_1_18  12
 UP BND1      visit_1_19  1
 UP BND1      order_1_19  12
 UP BND1      visit_1_20  1
 UP BND1      order_1_20  12
 UP BND1      visit_1_21  1
 UP BND1      order_1_21  12
 UP BND1      visit_1_22  1
 UP BND1      order_1_22  12
 BV BND1      arc_1_0_0
 FX BND1      load_1_0_0  0
 BV BND1      arc_1_0_7
 FX BND1      load_1_0_7  0
 BV BND1      arc_1_0_8
 FX BND1      load_1_0_8  0
 BV BND1      arc_1_0_9
 FX BND1      load_1_0_9  0
 BV BND1      arc_1_0_10
 FX BND1      load_1_0_10  0
 BV BND1      arc_1_0_15
 FX BND1      load_1_0_15  0
 BV BND1      arc_1_0_16
 FX BND1      load_1_0_16  0
 BV BND1      arc_1_0_17
 FX BND1      load_1_0_17  0
 BV BND1      arc_1_0_18
 FX BND1      load_1_0_18  0
 BV BND1      arc_1_0_19
 FX BND1      load_1_0_19  0
 BV BND1      arc_1_0_20
 FX BND1      load_1_0_20  0
 BV BND1      arc_1_0_21
 FX BND1      load_1_0_21  0
 BV BND1      arc_1_0_22
 FX BND1      load_1_0_22  0
 BV BND1      arc_1_7_0
 UP BND1      load_1_7_0  25
 BV BND1      arc_1_7_8
 UP BND1      load_1_7_8  25
 BV BND1      arc_1_7_9
 UP BND1      load_1_7_9  25
 BV BND1      arc_1_7_10
 UP BND1      load_1_7_10  25
 BV BND1      arc_1_7_15
 UP BND1      load_1_7_15  25
 BV BND1      arc_1_7_16
 UP BND1      load_1_7_16  25
 BV BND1      arc_1_7_17
 UP BND1      load_1_7_17  25
 BV BND1      arc_1_7_18
 UP BND1      load_1_7_18  25
 BV BND1      arc_1_7_19
 UP BND1      load_1_7_19  25
 BV BND1      arc_1_7_20
 UP BND1      load_1_7_20  25
 BV BND1      arc_1_7_21
 UP BND1      load_1_7_21  25
 BV BND1      arc_1_7_22
 UP BND1      load_1_7_22  25
 BV BND1      arc_1_8_0
 UP BND1      load_1_8_0  25
 BV BND1      arc_1_8_7
 UP BND1      load_1_8_7  25
 BV BND1      arc_1_8_9
 UP BND1      load_1_8_9  25
 BV BND1      arc_1_8_10
 UP BND1      load_1_8_10  25
 BV BND1      arc_1_8_15
 UP BND1      load_1_8_15  25
 BV BND1      arc_1_8_16
 UP BND1      load_1_8_16  25
 BV BND1      arc_1_8_17
 UP BND1      load_1_8_17  25
 BV BND1      arc_1_8_18
 UP BND1      load_1_8_18  25
 BV BND1      arc_1_8_19
 UP BND1      load_1_8_19  25
 BV BND1      arc_1_8_20
 UP BND1      load_1_8_20  25
 BV BND1      arc_1_8_21
 UP BND1      load_1_8_21  25
 BV BND1      arc_1_8_22
 UP BND1      load_1_8_22  25
 BV BND1      arc_1_9_0
 UP BND1      load_1_9_0  25
 BV BND1      arc_1_9_7
 UP BND1      load_1_9_7  25
 BV BND1      arc_1_9_8
 UP BND1      load_1_9_8  25
 BV BND1      arc_1_9_10
 UP BND1      load_1_9_10  25
 BV BND1      arc_1_9_15
 UP BND1      load_1_9_15  25
 BV BND1      arc_1_9_16
 UP BND1      load_1_9_16  25
 BV BND1      arc_1_9_17
 UP BND1      load_1_9_17  25
 BV BND1      arc_1_9_18
 UP BND1      load_1_9_18  25
 BV BND1      arc_1_9_19
 UP BND1      load_1_9_19  25
 BV BND1      arc_1_9_20
 UP BND1      load_1_9_20  25
 BV BND1      arc_1_9_21
 UP BND1      load_1_9_21  25
 BV BND1      arc_1_9_22
 UP BND1      load_1_9_22  25
 BV BND1      arc_1_10_0
 UP BND1      load_1_10_0  25
 BV BND1      arc_1_10_7
 UP BND1      load_1_10_7  25
 BV BND1      arc_1_10_8
 UP BND1      load_1_10_8  25
 BV BND1      arc_1_10_9
 UP BND1      load_1_10_9  25
 BV BND1      arc_1_10_15
 UP BND1      load_1_10_15  25
 BV BND1      arc_1_10_16
 UP BND1      load_1_10_16  25
 BV BND1      arc_1_10_17
 UP BND1      load_1_10_17  25
 BV BND1      arc_1_10_18
 UP BND1      load_1_10_18  25
 BV BND1      arc_1_10_19
 UP BND1      load_1_10_19  25
 BV BND1      arc_1_10_20
 UP BND1      load_1_10_20  25
 BV BND1      arc_1_10_21
 UP BND1      load_1_10_21  25
 BV BND1      arc_1_10_22
 UP BND1      load_1_10_22  25
 BV BND1      arc_1_15_0
 UP BND1      load_1_15_0  25
 BV BND1      arc_1_15_7
 UP BND1      load_1_15_7  25
 BV BND1      arc_1_15_8
 UP BND1      load_1_15_8  25
 BV BND1      arc_1_15_9
 UP BND1      load_1_15_9  25
 BV BND1      arc_1_15_10
 UP BND1      load_1_15_10  25
 BV BND1      arc_1_15_16
 UP BND1      load_1_15_16  25
 BV BND1      arc_1_15_17
 UP BND1      load_1_15_17  25
 BV BND1      arc_1_15_18
 UP BND1      load_1_15_18  25
 BV BND1      arc_1_15_19
 UP BND1      load_1_15_19  25
 BV BND1      arc_1_15_20
 UP BND1      load_1_15_20  25
 BV BND1      arc_1_15_21
 UP BND1      load_1_15_21  25
 BV BND1      arc_1_15_22
 UP BND1      load_1_15_22  25
 BV BND1      arc_1_16_0
 UP BND1      load_1_16_0  25
 BV BND1      arc_1_16_7
 UP BND1      load_1_16_7  25
 BV BND1      arc_1_16_8
 UP BND1      load_1_16_8  25
 BV BND1      arc_1_16_9
 UP BND1      load_1_16_9  25
 BV BND1      arc_1_16_10
 UP BND1      load_1_16_10  25
 BV BND1      arc_1_16_15
 UP BND1      load_1_16_15  25
 BV BND1      arc_1_16_17
 UP BND1      load_1_16_17  25
 BV BND1      arc_1_16_18
 UP BND1      load_1_16_18  25
 BV BND1      arc_1_16_19
 UP BND1      load_1_16_19  25
 BV BND1      arc_1_16_20
 UP BND1      load_1_16_20  25
 BV BND1      arc_1_16_21
 UP BND1      load_1_16_21  25
 BV BND1      arc_1_16_22
 UP BND1      load_1_16_22  25
 BV BND1      arc_1_17_0
 UP BND1      load_1_17_0  25
 BV BND1      arc_1_17_7
 UP BND1      load_1_17_7  25
 BV BND1      arc_1_17_8
 UP BND1      load_1_17_8  25
 BV BND1      arc_1_17_9
 UP BND1      load_1_17_9  25
 BV BND1      arc_1_17_10
 UP BND1      load_1_17_10  25
 BV BND1      arc_1_17_15
 UP BND1      load_1_17_15  25
 BV BND1      arc_1_17_16
 UP BND1      load_1_17_16  25
 BV BND1      arc_1_17_18
 UP BND1      load_1_17_18  25
 BV BND1      arc_1_17_19
 UP BND1      load_1_17_19  25
 BV BND1      arc_1_17_20
 UP BND1      load_1_17_20  25
 BV BND1      arc_1_17_21
 UP BND1      load_1_17_21  25
 BV BND1      arc_1_17_22
 UP BND1      load_1_17_22  25
 BV BND1      arc_1_18_0
 UP BND1      load_1_18_0  25
 BV BND1      arc_1_18_7
 UP BND1      load_1_18_7  25
 BV BND1      arc_1_18_8
 UP BND1      load_1_18_8  25
 BV BND1      arc_1_18_9
 UP BND1      load_1_18_9  25
 BV BND1      arc_1_18_10
 UP BND1      load_1_18_10  25
 BV BND1      arc_1_18_15
 UP BND1      load_1_18_15  25
 BV BND1      arc_1_18_16
 UP BND1      load_1_18_16  25
 BV BND1      arc_1_18_17
 UP BND1      load_1_18_17  25
 BV BND1      arc_1_18_19
 UP BND1      load_1_18_19  25
 BV BND1      arc_1_18_20
 UP BND1      load_1_18_20  25
 BV BND1      arc_1_18_21
 UP BND1      load_1_18_21  25
 BV BND1      arc_1_18_22
 UP BND1      load_1_18_22  25
 BV BND1      arc_1_19_0
 UP BND1      load_1_19_0  25
 BV BND1      arc_1_19_7
 UP BND1      load_1_19_7  25
 BV BND1      arc_1_19_8
 UP BND1      load_1_19_8  25
 BV BND1      arc_1_19_9
 UP BND1      load_1_19_9  25
 BV BND1      arc_1_19_10
 UP BND1      load_1_19_10  25
 BV BND1      arc_1_19_15
 UP BND1      load_1_19_15  25
 BV BND1      arc_1_19_16
 UP BND1      load_1_19_16  25
 BV BND1      arc_1_19_17
 UP BND1      load_1_19_17  25
 BV BND1      arc_1_19_18
 UP BND1      load_1_19_18  25
 BV BND1      arc_1_19_20
 UP BND1      load_1_19_20  25
 BV BND1      arc_1_19_21
 UP BND1      load_1_19_21  25
 BV BND1      arc_1_19_22
 UP BND1      load_1_19_22  25
 BV BND1      arc_1_20_0
 UP BND1      load_1_20_0  25
 BV BND1      arc_1_20_7
 UP BND1      load_1_20_7  25
 BV BND1      arc_1_20_8
 UP BND1      load_1_20_8  25
 BV BND1      arc_1_20_9
 UP BND1      load_1_20_9  25
 BV BND1      arc_1_20_10
 UP BND1      load_1_20_10  25
 BV BND1      arc_1_20_15
 UP BND1      load_1_20_15  25
 BV BND1      arc_1_20_16
 UP BND1      load_1_20_16  25
 BV BND1      arc_1_20_17
 UP BND1      load_1_20_17  25
 BV BND1      arc_1_20_18
 UP BND1      load_1_20_18  25
 BV BND1      arc_1_20_19
 UP BND1      load_1_20_19  25
 BV BND1      arc_1_20_21
 UP BND1      load_1_20_21  25
 BV BND1      arc_1_20_22
 UP BND1      load_1_20_22  25
 BV BND1      arc_1_21_0
 UP BND1      load_1_21_0  25
 BV BND1      arc_1_21_7
 UP BND1      load_1_21_7  25
 BV BND1      arc_1_21_8
 UP BND1      load_1_21_8  25
 BV BND1      arc_1_21_9
 UP BND1      load_1_21_9  25
 BV BND1      arc_1_21_10
 UP BND1      load_1_21_10  25
 BV BND1      arc_1_21_15
 UP BND1      load_1_21_15  25
 BV BND1      arc_1_21_16
 UP BND1      load_1_21_16  25
 BV BND1      arc_1_21_17
 UP BND1      load_1_21_17  25
 BV BND1      arc_1_21_18
 UP BND1      load_1_21_18  25
 BV BND1      arc_1_21_19
 UP BND1      load_1_21_19  25
 BV BND1      arc_1_21_20
 UP BND1      load_1_21_20  25
 BV BND1      arc_1_21_22
 UP BND1      load_1_21_22  25
 BV BND1      arc_1_22_0
 UP BND1      load_1_22_0  25
 BV BND1      arc_1_22_7
 UP BND1      load_1_22_7  25
 BV BND1      arc_1_22_8
 UP BND1      load_1_22_8  25
 BV BND1      arc_1_22_9
 UP BND1      load_1_22_9  25
 BV BND1      arc_1_22_10
 UP BND1      load_1_22_10  25
 BV BND1      arc_1_22_15
 UP BND1      load_1_22_15  25
 BV BND1      arc_1_22_16
 UP BND1      load_1_22_16  25
 BV BND1      arc_1_22_17
 UP BND1      load_1_22_17  25
 BV BND1      arc_1_22_18
 UP BND1      load_1_22_18  25
 BV BND1      arc_1_22_19
 UP BND1      load_1_22_19  25
 BV BND1      arc_1_22_20
 UP BND1      load_1_22_20  25
 BV BND1      arc_1_22_21
 UP BND1      load_1_22_21  25
 FX BND1      visit_2_11  1
 UP BND1      order_2_11  12
 FX BND1      visit_2_12  1
 UP BND1      order_2_12  12
 FX BND1      visit_2_13  1
 UP BND1      order_2_13  12
 FX BND1      visit_2_14  1
 UP BND1      order_2_14  12
 UP BND1      visit_2_15  1
 UP BND1      order_2_15  12
 UP BND1      visit_2_16  1
 UP BND1      order_2_16  12
 UP BND1      visit_2_17  1
 UP BND1      order_2_17  12
 UP BND1      visit_2_18  1
 UP BND1      order_2_18  12
 UP BND1      visit_2_19  1
 UP BND1      order_2_19  12
 UP BND1      visit_2_20  1
 UP BND1      order_2_20  12
 UP BND1      visit_2_21  1
 UP BND1      order_2_21  12
 UP BND1      visit_2_22  1
 UP BND1      order_2_22  12
 BV BND1      arc_2_0_0
 FX BND1      load_2_0_0  0
 BV BND1      arc_2_0_11
 FX BND1      load_2_0_11  0
 BV BND1      arc_2_0_12
 FX BND1      load_2_0_12  0
 BV BND1      arc_2_0_13
 FX BND1      load_2_0_13  0
 BV BND1      arc_2_0_14
 FX BND1      load_2_0_14  0
 BV BND1      arc_2_0_15
 FX BND1      load_2_0_15  0
 BV BND1      arc_2_0_16
 FX BND1      load_2_0_16  0
 BV BND1      arc_2_0_17
 FX BND1      load_2_0_17  0
 BV BND1      arc_2_0_18
 FX BND1      load_2_0_18  0
 BV BND1      arc_2_0_19
 FX BND1      load_2_0_19  0
 BV BND1      arc_2_0_20
 FX BND1      load_2_0_20  0
 BV BND1      arc_2_0_21
 FX BND1      load_2_0_21  0
 BV BND1      arc_2_0_22
 FX BND1      load_2_0_22  0
 BV BND1      arc_2_11_0
 UP BND1      load_2_11_0  30
 BV BND1      arc_2_11_12
 UP BND1      load_2_11_12  30
 BV BND1      arc_2_11_13
 UP BND1      load_2_11_13  30
 BV BND1      arc_2_11_14
 UP BND1      load_2_11_14  30
 BV BND1      arc_2_11_15
 UP BND1      load_2_11_15  30
 BV BND1      arc_2_11_16
 UP BND1      load_2_11_16  30
 BV BND1      arc_2_11_17
 UP BND1      load_2_11_17  30
 BV BND1      arc_2_11_18
 UP BND1      load_2_11_18  30
 BV BND1      arc_2_11_19
 UP BND1      load_2_11_19  30
 BV BND1      arc_2_11_20
 UP BND1      load_2_11_20  30
 BV BND1      arc_2_11_21
 UP BND1      load_2_11_21  30
 BV BND1      arc_2_11_22
 UP BND1      load_2_11_22  30
 BV BND1      arc_2_12_0
 UP BND1      load_2_12_0  30
 BV BND1      arc_2_12_11
 UP BND1      load_2_12_11  30
 BV BND1      arc_2_12_13
 UP BND1      load_2_12_13  30
 BV BND1      arc_2_12_14
 UP BND1      load_2_12_14  30
 BV BND1      arc_2_12_15
 UP BND1      load_2_12_15  30
 BV BND1      arc_2_12_16
 UP BND1      load_2_12_16  30
 BV BND1      arc_2_12_17
 UP BND1      load_2_12_17  30
 BV BND1      arc_2_12_18
 UP BND1      load_2_12_18  30
 BV BND1      arc_2_12_19
 UP BND1      load_2_12_19  30
 BV BND1      arc_2_12_20
 UP BND1      load_2_12_20  30
 BV BND1      arc_2_12_21
 UP BND1      load_2_12_21  30
 BV BND1      arc_2_12_22
 UP BND1      load_2_12_22  30
 BV BND1      arc_2_13_0
 UP BND1      load_2_13_0  30
 BV BND1      arc_2_13_11
 UP BND1      load_2_13_11  30
 BV BND1      arc_2_13_12
 UP BND1      load_2_13_12  30
 BV BND1      arc_2_13_14
 UP BND1      load_2_13_14  30
 BV BND1      arc_2_13_15
 UP BND1      load_2_13_15  30
 BV BND1      arc_2_13_16
 UP BND1      load_2_13_16  30
 BV BND1      arc_2_13_17
 UP BND1      load_2_13_17  30
 BV BND1      arc_2_13_18
 UP BND1      load_2_13_18  30
 BV BND1      arc_2_13_19
 UP BND1      load_2_13_19  30
 BV BND1      arc_2_13_20
 UP BND1      load_2_13_20  30
 BV BND1      arc_2_13_21
 UP BND1      load_2_13_21  30
 BV BND1      arc_2_13_22
 UP BND1      load_2_13_22  30
 BV BND1      arc_2_14_0
 UP BND1      load_2_14_0  30
 BV BND1      arc_2_14_11
 UP BND1      load_2_14_11  30
 BV BND1      arc_2_14_12
 UP BND1      load_2_14_12  30
 BV BND1      arc_2_14_13
 UP BND1      load_2_14_13  30
 BV BND1      arc_2_14_15
 UP BND1      load_2_14_15  30
 BV BND1      arc_2_14_16
 UP BND1      load_2_14_16  30
 BV BND1      arc_2_14_17
 UP BND1      load_2_14_17  30
 BV BND1      arc_2_14_18
 UP BND1      load_2_14_18  30
 BV BND1      arc_2_14_19
 UP BND1      load_2_14_19  30
 BV BND1      arc_2_14_20
 UP BND1      load_2_14_20  30
 BV BND1      arc_2_14_21
 UP BND1      load_2_14_21  30
 BV BND1      arc_2_14_22
 UP BND1      load_2_14_22  30
 BV BND1      arc_2_15_0
 UP BND1      load_2_15_0  30
 BV BND1      arc_2_15_11
 UP BND1      load_2_15_11  30
 BV BND1      arc_2_15_12
 UP BND1      load_2_15_12  30
 BV BND1      arc_2_15_13
 UP BND1      load_2_15_13  30
 BV BND1      arc_2_15_14
 UP BND1      load_2_15_14  30
 BV BND1      arc_2_15_16
 UP BND1      load_2_15_16  30
 BV BND1      arc_2_15_17
 UP BND1      load_2_15_17  30
 BV BND1      arc_2_15_18
 UP BND1      load_2_15_18  30
 BV BND1      arc_2_15_19
 UP BND1      load_2_15_19  30
 BV BND1      arc_2_15_20
 UP BND1      load_2_15_20  30
 BV BND1      arc_2_15_21
 UP BND1      load_2_15_21  30
 BV BND1      arc_2_15_22
 UP BND1      load_2_15_22  30
 BV BND1      arc_2_16_0
 UP BND1      load_2_16_0  30
 BV BND1      arc_2_16_11
 UP BND1      load_2_16_11  30
 BV BND1      arc_2_16_12
 UP BND1      load_2_16_12  30
 BV BND1      arc_2_16_13
 UP BND1      load_2_16_13  30
 BV BND1      arc_2_16_14
 UP BND1      load_2_16_14  30
 BV BND1      arc_2_16_15
 UP BND1      load_2_16_15  30
 BV BND1      arc_2_16_17
 UP BND1      load_2_16_17  30
 BV BND1      arc_2_16_18
 UP BND1      load_2_16_18  30
 BV BND1      arc_2_16_19
 UP BND1      load_2_16_19  30
 BV BND1      arc_2_16_20
 UP BND1      load_2_16_20  30
 BV BND1      arc_2_16_21
 UP BND1      load_2_16_21  30
 BV BND1      arc_2_16_22
 UP BND1      load_2_16_22  30
 BV BND1      arc_2_17_0
 UP BND1      load_2_17_0  30
 BV BND1      arc_2_17_11
 UP BND1      load_2_17_11  30
 BV BND1      arc_2_17_12
 UP BND1      load_2_17_12  30
 BV BND1      arc_2_17_13
 UP BND1      load_2_17_13  30
 BV BND1      arc_2_17_14
 UP BND1      load_2_17_14  30
 BV BND1      arc_2_17_15
 UP BND1      load_2_17_15  30
 BV BND1      arc_2_17_16
 UP BND1      load_2_17_16  30
 BV BND1      arc_2_17_18
 UP BND1      load_2_17_18  30
 BV BND1      arc_2_17_19
 UP BND1      load_2_17_19  30
 BV BND1      arc_2_17_20
 UP BND1      load_2_17_20  30
 BV BND1      arc_2_17_21
 UP BND1      load_2_17_21  30
 BV BND1      arc_2_17_22
 UP BND1      load_2_17_22  30
 BV BND1      arc_2_18_0
 UP BND1      load_2_18_0  30
 BV BND1      arc_2_18_11
 UP BND1      load_2_18_11  30
 BV BND1      arc_2_18_12
 UP BND1      load_2_18_12  30
 BV BND1      arc_2_18_13
 UP BND1      load_2_18_13  30
 BV BND1      arc_2_18_14
 UP BND1      load_2_18_14  30
 BV BND1      arc_2_18_15
 UP BND1      load_2_18_15  30
 BV BND1      arc_2_18_16
 UP BND1      load_2_18_16  30
 BV BND1      arc_2_18_17
 UP BND1      load_2_18_17  30
 BV BND1      arc_2_18_19
 UP BND1      load_2_18_19  30
 BV BND1      arc_2_18_20
 UP BND1      load_2_18_20  30
 BV BND1      arc_2_18_21
 UP BND1      load_2_18_21  30
 BV BND1      arc_2_18_22
 UP BND1      load_2_18_22  30
 BV BND1      arc_2_19_0
 UP BND1      load_2_19_0  30
 BV BND1      arc_2_19_11
 UP BND1      load_2_19_11  30
 BV BND1      arc_2_19_12
 UP BND1      load_2_19_12  30
 BV BND1      arc_2_19_13
 UP BND1      load_2_19_13  30
 BV BND1      arc_2_19_14
 UP BND1      load_2_19_14  30
 BV BND1      arc_2_19_15
 UP BND1      load_2_19_15  30
 BV BND1      arc_2_19_16
 UP BND1      load_2_19_16  30
 BV BND1      arc_2_19_17
 UP BND1      load_2_19_17  30
 BV BND1      arc_2_19_18
 UP BND1      load_2_19_18  30
 BV BND1      arc_2_19_20
 UP BND1      load_2_19_20  30
 BV BND1      arc_2_19_21
 UP BND1      load_2_19_21  30
 BV BND1      arc_2_19_22
 UP BND1      load_2_19_22  30
 BV BND1      arc_2_20_0
 UP BND1      load_2_20_0  30
 BV BND1      arc_2_20_11
 UP BND1      load_2_20_11  30
 BV BND1      arc_2_20_12
 UP BND1      load_2_20_12  30
 BV BND1      arc_2_20_13
 UP BND1      load_2_20_13  30
 BV BND1      arc_2_20_14
 UP BND1      load_2_20_14  30
 BV BND1      arc_2_20_15
 UP BND1      load_2_20_15  30
 BV BND1      arc_2_20_16
 UP BND1      load_2_20_16  30
 BV BND1      arc_2_20_17
 UP BND1      load_2_20_17  30
 BV BND1      arc_2_20_18
 UP BND1      load_2_20_18  30
 BV BND1      arc_2_20_19
 UP BND1      load_2_20_19  30
 BV BND1      arc_2_20_21
 UP BND1      load_2_20_21  30
 BV BND1      arc_2_20_22
 UP BND1      load_2_20_22  30
 BV BND1      arc_2_21_0
 UP BND1      load_2_21_0  30
 BV BND1      arc_2_21_11
 UP BND1      load_2_21_11  30
 BV BND1      arc_2_21_12
 UP BND1      load_2_21_12  30
 BV BND1      arc_2_21_13
 UP BND1      load_2_21_13  30
 BV BND1      arc_2_21_14
 UP BND1      load_2_21_14  30
 BV BND1      arc_2_21_15
 UP BND1      load_2_21_15  30
 BV BND1      arc_2_21_16
 UP BND1      load_2_21_16  30
 BV BND1      arc_2_21_17
 UP BND1      load_2_21_17  30
 BV BND1      arc_2_21_18
 UP BND1      load_2_21_18  30
 BV BND1      arc_2_21_19
 UP BND1      load_2_21_19  30
 BV BND1      arc_2_21_20
 UP BND1      load_2_21_20  30
 BV BND1      arc_2_21_22
 UP BND1      load_2_21_22  30
 BV BND1      arc_2_22_0
 UP BND1      load_2_22_0  30
 BV BND1      arc_2_22_11
 UP BND1      load_2_22_11  30
 BV BND1      arc_2_22_12
 UP BND1      load_2_22_12  30
 BV BND1      arc_2_22_13
 UP BND1      load_2_22_13  30
 BV BND1      arc_2_22_14
 UP BND1      load_2_22_14  30
 BV BND1      arc_2_22_15
 UP BND1      load_2_22_15  30
 BV BND1      arc_2_22_16
 UP BND1      load_2_22_16  30
 BV BND1      arc_2_22_17
 UP BND1      load_2_22_17  30
 BV BND1      arc_2_22_18
 UP BND1      load_2_22_18  30
 BV BND1      arc_2_22_19
 UP BND1      load_2_22_19  30
 BV BND1      arc_2_22_20
 UP BND1      load_2_22_20  30
 BV BND1      arc_2_22_21
 UP BND1      load_2_22_21  30
ENDATA
