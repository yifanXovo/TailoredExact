* Signature: 0xc8f4eceacd54edd7
NAME R160_physical_neighborhood
ROWS
 N  OBJ
 G  product_lb_0
 L  product_ub_1
 G  product_lb_2
 L  product_ub_3
 G  product_lb_4
 L  product_ub_5
 G  product_lb_6
 L  product_ub_7
 G  product_lb_8
 L  product_ub_9
 G  product_lb_10
 L  product_ub_11
 G  product_lb_12
 L  product_ub_13
 G  product_lb_14
 L  product_ub_15
 G  product_lb_16
 L  product_ub_17
 G  product_lb_18
 L  product_ub_19
 G  product_lb_20
 L  product_ub_21
 G  product_lb_22
 L  product_ub_23
 G  product_lb_24
 L  product_ub_25
 G  product_lb_26
 L  product_ub_27
 G  product_lb_28
 L  product_ub_29
 G  product_lb_30
 L  product_ub_31
 G  product_lb_32
 L  product_ub_33
 E  onehot_15_34
 E  normalized_mass_15_35
 E  normalized_ratio_15_36
 G  product_lb_37
 L  product_ub_38
 G  product_lb_39
 L  product_ub_40
 G  product_lb_41
 L  product_ub_42
 G  product_lb_43
 L  product_ub_44
 G  product_lb_45
 L  product_ub_46
 G  product_lb_47
 L  product_ub_48
 G  product_lb_49
 L  product_ub_50
 G  product_lb_51
 L  product_ub_52
 G  product_lb_53
 L  product_ub_54
 G  product_lb_55
 L  product_ub_56
 G  product_lb_57
 L  product_ub_58
 G  product_lb_59
 L  product_ub_60
 G  product_lb_61
 L  product_ub_62
 E  onehot_9_63
 E  normalized_mass_9_64
 E  normalized_ratio_9_65
 G  product_lb_66
 L  product_ub_67
 G  product_lb_68
 L  product_ub_69
 G  product_lb_70
 L  product_ub_71
 G  product_lb_72
 L  product_ub_73
 G  product_lb_74
 L  product_ub_75
 G  product_lb_76
 L  product_ub_77
 G  product_lb_78
 L  product_ub_79
 G  product_lb_80
 L  product_ub_81
 G  product_lb_82
 L  product_ub_83
 G  product_lb_84
 L  product_ub_85
 G  product_lb_86
 L  product_ub_87
 G  product_lb_88
 L  product_ub_89
 G  product_lb_90
 L  product_ub_91
 E  onehot_31_92
 E  normalized_mass_31_93
 E  normalized_ratio_31_94
 G  product_lb_95
 L  product_ub_96
 G  product_lb_97
 L  product_ub_98
 G  product_lb_99
 L  product_ub_100
 G  product_lb_101
 L  product_ub_102
 G  product_lb_103
 L  product_ub_104
 G  product_lb_105
 L  product_ub_106
 G  product_lb_107
 L  product_ub_108
 G  product_lb_109
 L  product_ub_110
 G  product_lb_111
 L  product_ub_112
 E  onehot_19_113
 E  normalized_mass_19_114
 E  normalized_ratio_19_115
 G  product_lb_116
 L  product_ub_117
 G  product_lb_118
 L  product_ub_119
 G  product_lb_120
 L  product_ub_121
 G  product_lb_122
 L  product_ub_123
 G  product_lb_124
 L  product_ub_125
 G  product_lb_126
 L  product_ub_127
 G  product_lb_128
 L  product_ub_129
 G  product_lb_130
 L  product_ub_131
 G  product_lb_132
 L  product_ub_133
 G  product_lb_134
 L  product_ub_135
 G  product_lb_136
 L  product_ub_137
 G  product_lb_138
 L  product_ub_139
 G  product_lb_140
 L  product_ub_141
 E  onehot_16_142
 E  normalized_mass_16_143
 E  normalized_ratio_16_144
 G  product_lb_145
 L  product_ub_146
 G  product_lb_147
 L  product_ub_148
 G  product_lb_149
 L  product_ub_150
 G  product_lb_151
 L  product_ub_152
 G  product_lb_153
 L  product_ub_154
 G  product_lb_155
 L  product_ub_156
 G  product_lb_157
 L  product_ub_158
 G  product_lb_159
 L  product_ub_160
 G  product_lb_161
 L  product_ub_162
 G  product_lb_163
 L  product_ub_164
 G  product_lb_165
 L  product_ub_166
 G  product_lb_167
 L  product_ub_168
 G  product_lb_169
 L  product_ub_170
 G  product_lb_171
 L  product_ub_172
 G  product_lb_173
 L  product_ub_174
 G  product_lb_175
 L  product_ub_176
 G  product_lb_177
 L  product_ub_178
 G  product_lb_179
 L  product_ub_180
 G  product_lb_181
 L  product_ub_182
 G  product_lb_183
 L  product_ub_184
 E  onehot_13_185
 E  normalized_mass_13_186
 E  normalized_ratio_13_187
 G  product_lb_188
 L  product_ub_189
 G  product_lb_190
 L  product_ub_191
 G  product_lb_192
 L  product_ub_193
 G  product_lb_194
 L  product_ub_195
 G  product_lb_196
 L  product_ub_197
 G  product_lb_198
 L  product_ub_199
 G  product_lb_200
 L  product_ub_201
 G  product_lb_202
 L  product_ub_203
 G  product_lb_204
 L  product_ub_205
 G  product_lb_206
 L  product_ub_207
 G  product_lb_208
 L  product_ub_209
 G  product_lb_210
 L  product_ub_211
 G  product_lb_212
 L  product_ub_213
 E  onehot_32_214
 E  normalized_mass_32_215
 E  normalized_ratio_32_216
 G  product_lb_217
 L  product_ub_218
 G  product_lb_219
 L  product_ub_220
 G  product_lb_221
 L  product_ub_222
 G  product_lb_223
 L  product_ub_224
 G  product_lb_225
 L  product_ub_226
 G  product_lb_227
 L  product_ub_228
 G  product_lb_229
 L  product_ub_230
 G  product_lb_231
 L  product_ub_232
 G  product_lb_233
 L  product_ub_234
 G  product_lb_235
 L  product_ub_236
 G  product_lb_237
 L  product_ub_238
 G  product_lb_239
 L  product_ub_240
 G  product_lb_241
 L  product_ub_242
 G  product_lb_243
 L  product_ub_244
 G  product_lb_245
 L  product_ub_246
 G  product_lb_247
 L  product_ub_248
 G  product_lb_249
 L  product_ub_250
 E  onehot_17_251
 E  normalized_mass_17_252
 E  normalized_ratio_17_253
 G  stock_lb_254
 L  stock_ub_255
 L  parent_nonstrict_scope_256
 G  block_pair_pos_257
 G  block_pair_neg_258
 G  block_pair_pos_259
 G  block_pair_neg_260
 G  block_pair_pos_261
 G  block_pair_neg_262
 G  block_pair_pos_263
 G  block_pair_neg_264
 G  block_pair_pos_265
 G  block_pair_neg_266
 G  block_pair_pos_267
 G  block_pair_neg_268
 G  block_pair_pos_269
 G  block_pair_neg_270
 G  block_pair_pos_271
 G  block_pair_neg_272
 G  block_pair_pos_273
 G  block_pair_neg_274
 G  block_pair_pos_275
 G  block_pair_neg_276
 G  block_pair_pos_277
 G  block_pair_neg_278
 G  block_pair_pos_279
 G  block_pair_neg_280
 G  block_pair_pos_281
 G  block_pair_neg_282
 G  block_pair_pos_283
 G  block_pair_neg_284
 G  block_pair_pos_285
 G  block_pair_neg_286
 G  block_pair_pos_287
 G  block_pair_neg_288
 G  block_pair_pos_289
 G  block_pair_neg_290
 G  block_pair_pos_291
 G  block_pair_neg_292
 G  block_pair_pos_293
 G  block_pair_neg_294
 G  block_pair_pos_295
 G  block_pair_neg_296
 G  block_pair_pos_297
 G  block_pair_neg_298
 G  block_pair_pos_299
 G  block_pair_neg_300
 G  block_pair_pos_301
 G  block_pair_neg_302
 G  block_pair_pos_303
 G  block_pair_neg_304
 G  block_pair_pos_305
 G  block_pair_neg_306
 G  block_pair_pos_307
 G  block_pair_neg_308
 G  block_pair_pos_309
 G  block_pair_neg_310
 G  block_pair_pos_311
 G  block_pair_neg_312
 E  normalization_313
 G  full_original_Gini_314
 E  unique_nonzero_owner_315
 E  unique_nonzero_owner_316
 E  unique_nonzero_owner_317
 E  unique_nonzero_owner_318
 E  unique_nonzero_owner_319
 E  unique_nonzero_owner_320
 E  unique_nonzero_owner_321
 E  unique_nonzero_owner_322
 E  unique_nonzero_owner_323
 E  unique_nonzero_owner_324
 E  unique_nonzero_owner_325
 E  unique_nonzero_owner_326
 E  unique_nonzero_owner_327
 E  unique_nonzero_owner_328
 E  unique_nonzero_owner_329
 E  unique_nonzero_owner_330
 E  unique_nonzero_owner_331
 E  unique_nonzero_owner_332
 E  unique_nonzero_owner_333
 E  unique_nonzero_owner_334
 E  unique_nonzero_owner_335
 E  unique_nonzero_owner_336
 E  unique_nonzero_owner_337
 E  unique_nonzero_owner_338
 E  unique_nonzero_owner_339
 E  unique_nonzero_owner_340
 E  unique_nonzero_owner_341
 E  unique_nonzero_owner_342
 E  unique_nonzero_owner_343
 E  unique_nonzero_owner_344
 E  unique_nonzero_owner_345
 E  unique_nonzero_owner_346
 E  unique_nonzero_owner_347
 E  unique_nonzero_owner_348
 E  unique_nonzero_owner_349
 E  unique_nonzero_owner_350
 E  unique_nonzero_owner_351
 E  unique_nonzero_owner_352
 E  unique_nonzero_owner_353
 E  unique_nonzero_owner_354
 E  unique_nonzero_owner_355
 E  unique_nonzero_owner_356
 E  unique_nonzero_owner_357
 E  unique_nonzero_owner_358
 E  unique_nonzero_owner_359
 E  unique_nonzero_owner_360
 E  unique_nonzero_owner_361
 E  unique_nonzero_owner_362
 E  unique_nonzero_owner_363
 E  unique_nonzero_owner_364
 E  unique_nonzero_owner_365
 E  unique_nonzero_owner_366
 E  unique_nonzero_owner_367
 E  unique_nonzero_owner_368
 E  unique_nonzero_owner_369
 E  unique_nonzero_owner_370
 E  unique_nonzero_owner_371
 E  unique_nonzero_owner_372
 E  unique_nonzero_owner_373
 E  unique_nonzero_owner_374
 E  unique_nonzero_owner_375
 E  unique_nonzero_owner_376
 E  unique_nonzero_owner_377
 E  unique_nonzero_owner_378
 E  unique_nonzero_owner_379
 E  unique_nonzero_owner_380
 E  unique_nonzero_owner_381
 E  unique_nonzero_owner_382
 E  unique_nonzero_owner_383
 E  unique_nonzero_owner_384
 E  unique_nonzero_owner_385
 E  unique_nonzero_owner_386
 E  unique_nonzero_owner_387
 E  unique_nonzero_owner_388
 E  unique_nonzero_owner_389
 E  unique_nonzero_owner_390
 E  unique_nonzero_owner_391
 E  unique_nonzero_owner_392
 E  unique_nonzero_owner_393
 E  unique_nonzero_owner_394
 E  unique_nonzero_owner_395
 E  unique_nonzero_owner_396
 E  unique_nonzero_owner_397
 E  unique_nonzero_owner_398
 E  unique_nonzero_owner_399
 E  unique_nonzero_owner_400
 E  unique_nonzero_owner_401
 E  unique_nonzero_owner_402
 E  unique_nonzero_owner_403
 E  unique_nonzero_owner_404
 E  unique_nonzero_owner_405
 E  unique_nonzero_owner_406
 E  unique_nonzero_owner_407
 E  unique_nonzero_owner_408
 E  unique_nonzero_owner_409
 E  unique_nonzero_owner_410
 E  unique_nonzero_owner_411
 E  unique_nonzero_owner_412
 E  unique_nonzero_owner_413
 E  unique_nonzero_owner_414
 E  unique_nonzero_owner_415
 E  unique_nonzero_owner_416
 E  unique_nonzero_owner_417
 E  unique_nonzero_owner_418
 E  unique_nonzero_owner_419
 E  unique_nonzero_owner_420
 E  unique_nonzero_owner_421
 L  arc_capacity_422
 L  arc_capacity_423
 L  arc_capacity_424
 L  arc_capacity_425
 L  arc_capacity_426
 L  arc_capacity_427
 L  arc_capacity_428
 L  arc_capacity_429
 L  arc_capacity_430
 L  arc_capacity_431
 L  arc_capacity_432
 L  arc_capacity_433
 L  arc_capacity_434
 L  arc_capacity_435
 L  arc_capacity_436
 G  connected_order_arc_437
 L  arc_capacity_438
 G  connected_order_arc_439
 L  arc_capacity_440
 G  connected_order_arc_441
 L  arc_capacity_442
 G  connected_order_arc_443
 L  arc_capacity_444
 G  connected_order_arc_445
 L  arc_capacity_446
 G  connected_order_arc_447
 L  arc_capacity_448
 G  connected_order_arc_449
 L  arc_capacity_450
 G  connected_order_arc_451
 L  arc_capacity_452
 G  connected_order_arc_453
 L  arc_capacity_454
 G  connected_order_arc_455
 L  arc_capacity_456
 G  connected_order_arc_457
 L  arc_capacity_458
 L  arc_capacity_459
 G  connected_order_arc_460
 L  arc_capacity_461
 G  connected_order_arc_462
 L  arc_capacity_463
 G  connected_order_arc_464
 L  arc_capacity_465
 G  connected_order_arc_466
 L  arc_capacity_467
 G  connected_order_arc_468
 L  arc_capacity_469
 G  connected_order_arc_470
 L  arc_capacity_471
 G  connected_order_arc_472
 L  arc_capacity_473
 G  connected_order_arc_474
 L  arc_capacity_475
 G  connected_order_arc_476
 L  arc_capacity_477
 G  connected_order_arc_478
 L  arc_capacity_479
 G  connected_order_arc_480
 L  arc_capacity_481
 L  arc_capacity_482
 G  connected_order_arc_483
 L  arc_capacity_484
 G  connected_order_arc_485
 L  arc_capacity_486
 G  connected_order_arc_487
 L  arc_capacity_488
 G  connected_order_arc_489
 L  arc_capacity_490
 G  connected_order_arc_491
 L  arc_capacity_492
 G  connected_order_arc_493
 L  arc_capacity_494
 G  connected_order_arc_495
 L  arc_capacity_496
 G  connected_order_arc_497
 L  arc_capacity_498
 G  connected_order_arc_499
 L  arc_capacity_500
 G  connected_order_arc_501
 L  arc_capacity_502
 G  connected_order_arc_503
 L  arc_capacity_504
 L  arc_capacity_505
 G  connected_order_arc_506
 L  arc_capacity_507
 G  connected_order_arc_508
 L  arc_capacity_509
 G  connected_order_arc_510
 L  arc_capacity_511
 G  connected_order_arc_512
 L  arc_capacity_513
 G  connected_order_arc_514
 L  arc_capacity_515
 G  connected_order_arc_516
 L  arc_capacity_517
 G  connected_order_arc_518
 L  arc_capacity_519
 G  connected_order_arc_520
 L  arc_capacity_521
 G  connected_order_arc_522
 L  arc_capacity_523
 G  connected_order_arc_524
 L  arc_capacity_525
 G  connected_order_arc_526
 L  arc_capacity_527
 L  arc_capacity_528
 G  connected_order_arc_529
 L  arc_capacity_530
 G  connected_order_arc_531
 L  arc_capacity_532
 G  connected_order_arc_533
 L  arc_capacity_534
 G  connected_order_arc_535
 L  arc_capacity_536
 G  connected_order_arc_537
 L  arc_capacity_538
 G  connected_order_arc_539
 L  arc_capacity_540
 G  connected_order_arc_541
 L  arc_capacity_542
 G  connected_order_arc_543
 L  arc_capacity_544
 G  connected_order_arc_545
 L  arc_capacity_546
 G  connected_order_arc_547
 L  arc_capacity_548
 G  connected_order_arc_549
 L  arc_capacity_550
 L  arc_capacity_551
 G  connected_order_arc_552
 L  arc_capacity_553
 G  connected_order_arc_554
 L  arc_capacity_555
 G  connected_order_arc_556
 L  arc_capacity_557
 G  connected_order_arc_558
 L  arc_capacity_559
 G  connected_order_arc_560
 L  arc_capacity_561
 G  connected_order_arc_562
 L  arc_capacity_563
 G  connected_order_arc_564
 L  arc_capacity_565
 G  connected_order_arc_566
 L  arc_capacity_567
 G  connected_order_arc_568
 L  arc_capacity_569
 G  connected_order_arc_570
 L  arc_capacity_571
 G  connected_order_arc_572
 L  arc_capacity_573
 L  arc_capacity_574
 G  connected_order_arc_575
 L  arc_capacity_576
 G  connected_order_arc_577
 L  arc_capacity_578
 G  connected_order_arc_579
 L  arc_capacity_580
 G  connected_order_arc_581
 L  arc_capacity_582
 G  connected_order_arc_583
 L  arc_capacity_584
 G  connected_order_arc_585
 L  arc_capacity_586
 G  connected_order_arc_587
 L  arc_capacity_588
 G  connected_order_arc_589
 L  arc_capacity_590
 G  connected_order_arc_591
 L  arc_capacity_592
 G  connected_order_arc_593
 L  arc_capacity_594
 G  connected_order_arc_595
 L  arc_capacity_596
 L  arc_capacity_597
 G  connected_order_arc_598
 L  arc_capacity_599
 G  connected_order_arc_600
 L  arc_capacity_601
 G  connected_order_arc_602
 L  arc_capacity_603
 G  connected_order_arc_604
 L  arc_capacity_605
 G  connected_order_arc_606
 L  arc_capacity_607
 G  connected_order_arc_608
 L  arc_capacity_609
 G  connected_order_arc_610
 L  arc_capacity_611
 G  connected_order_arc_612
 L  arc_capacity_613
 G  connected_order_arc_614
 L  arc_capacity_615
 G  connected_order_arc_616
 L  arc_capacity_617
 G  connected_order_arc_618
 L  arc_capacity_619
 L  arc_capacity_620
 G  connected_order_arc_621
 L  arc_capacity_622
 G  connected_order_arc_623
 L  arc_capacity_624
 G  connected_order_arc_625
 L  arc_capacity_626
 G  connected_order_arc_627
 L  arc_capacity_628
 G  connected_order_arc_629
 L  arc_capacity_630
 G  connected_order_arc_631
 L  arc_capacity_632
 G  connected_order_arc_633
 L  arc_capacity_634
 G  connected_order_arc_635
 L  arc_capacity_636
 G  connected_order_arc_637
 L  arc_capacity_638
 G  connected_order_arc_639
 L  arc_capacity_640
 G  connected_order_arc_641
 L  arc_capacity_642
 L  arc_capacity_643
 G  connected_order_arc_644
 L  arc_capacity_645
 G  connected_order_arc_646
 L  arc_capacity_647
 G  connected_order_arc_648
 L  arc_capacity_649
 G  connected_order_arc_650
 L  arc_capacity_651
 G  connected_order_arc_652
 L  arc_capacity_653
 G  connected_order_arc_654
 L  arc_capacity_655
 G  connected_order_arc_656
 L  arc_capacity_657
 G  connected_order_arc_658
 L  arc_capacity_659
 G  connected_order_arc_660
 L  arc_capacity_661
 G  connected_order_arc_662
 L  arc_capacity_663
 G  connected_order_arc_664
 L  arc_capacity_665
 L  arc_capacity_666
 G  connected_order_arc_667
 L  arc_capacity_668
 G  connected_order_arc_669
 L  arc_capacity_670
 G  connected_order_arc_671
 L  arc_capacity_672
 G  connected_order_arc_673
 L  arc_capacity_674
 G  connected_order_arc_675
 L  arc_capacity_676
 G  connected_order_arc_677
 L  arc_capacity_678
 G  connected_order_arc_679
 L  arc_capacity_680
 G  connected_order_arc_681
 L  arc_capacity_682
 G  connected_order_arc_683
 L  arc_capacity_684
 G  connected_order_arc_685
 L  arc_capacity_686
 G  connected_order_arc_687
 L  arc_capacity_688
 L  arc_capacity_689
 G  connected_order_arc_690
 L  arc_capacity_691
 G  connected_order_arc_692
 L  arc_capacity_693
 G  connected_order_arc_694
 L  arc_capacity_695
 G  connected_order_arc_696
 L  arc_capacity_697
 G  connected_order_arc_698
 L  arc_capacity_699
 G  connected_order_arc_700
 L  arc_capacity_701
 G  connected_order_arc_702
 L  arc_capacity_703
 G  connected_order_arc_704
 L  arc_capacity_705
 G  connected_order_arc_706
 L  arc_capacity_707
 G  connected_order_arc_708
 L  arc_capacity_709
 G  connected_order_arc_710
 E  depot_departure_or_bypass_711
 E  depot_return_or_bypass_712
 E  out_degree_713
 E  in_degree_714
 G  order_active_lb_715
 L  order_active_ub_716
 E  segment_load_conservation_717
 G  segment_prefix_lb_718
 L  segment_prefix_ub_719
 E  out_degree_720
 E  in_degree_721
 G  order_active_lb_722
 L  order_active_ub_723
 E  segment_load_conservation_724
 G  segment_prefix_lb_725
 L  segment_prefix_ub_726
 E  out_degree_727
 E  in_degree_728
 G  order_active_lb_729
 L  order_active_ub_730
 E  segment_load_conservation_731
 G  segment_prefix_lb_732
 L  segment_prefix_ub_733
 E  out_degree_734
 E  in_degree_735
 G  order_active_lb_736
 L  order_active_ub_737
 E  segment_load_conservation_738
 G  segment_prefix_lb_739
 L  segment_prefix_ub_740
 E  out_degree_741
 E  in_degree_742
 G  order_active_lb_743
 L  order_active_ub_744
 E  service_visit_def_745
 E  free_load_conservation_746
 E  out_degree_747
 E  in_degree_748
 G  order_active_lb_749
 L  order_active_ub_750
 E  service_visit_def_751
 E  free_load_conservation_752
 E  out_degree_753
 E  in_degree_754
 G  order_active_lb_755
 L  order_active_ub_756
 E  service_visit_def_757
 E  free_load_conservation_758
 E  out_degree_759
 E  in_degree_760
 G  order_active_lb_761
 L  order_active_ub_762
 E  service_visit_def_763
 E  free_load_conservation_764
 E  out_degree_765
 E  in_degree_766
 G  order_active_lb_767
 L  order_active_ub_768
 E  service_visit_def_769
 E  free_load_conservation_770
 E  out_degree_771
 E  in_degree_772
 G  order_active_lb_773
 L  order_active_ub_774
 E  service_visit_def_775
 E  free_load_conservation_776
 E  out_degree_777
 E  in_degree_778
 G  order_active_lb_779
 L  order_active_ub_780
 E  service_visit_def_781
 E  free_load_conservation_782
 E  out_degree_783
 E  in_degree_784
 G  order_active_lb_785
 L  order_active_ub_786
 E  service_visit_def_787
 E  free_load_conservation_788
 G  fixed_segment_relative_order_789
 G  fixed_segment_relative_order_790
 G  fixed_segment_relative_order_791
 L  original_T_including_depot_unload_792
 L  arc_capacity_793
 L  arc_capacity_794
 L  arc_capacity_795
 L  arc_capacity_796
 L  arc_capacity_797
 L  arc_capacity_798
 L  arc_capacity_799
 L  arc_capacity_800
 L  arc_capacity_801
 L  arc_capacity_802
 L  arc_capacity_803
 L  arc_capacity_804
 L  arc_capacity_805
 L  arc_capacity_806
 L  arc_capacity_807
 L  arc_capacity_808
 G  connected_order_arc_809
 L  arc_capacity_810
 G  connected_order_arc_811
 L  arc_capacity_812
 G  connected_order_arc_813
 L  arc_capacity_814
 G  connected_order_arc_815
 L  arc_capacity_816
 G  connected_order_arc_817
 L  arc_capacity_818
 G  connected_order_arc_819
 L  arc_capacity_820
 G  connected_order_arc_821
 L  arc_capacity_822
 G  connected_order_arc_823
 L  arc_capacity_824
 G  connected_order_arc_825
 L  arc_capacity_826
 G  connected_order_arc_827
 L  arc_capacity_828
 G  connected_order_arc_829
 L  arc_capacity_830
 G  connected_order_arc_831
 L  arc_capacity_832
 L  arc_capacity_833
 G  connected_order_arc_834
 L  arc_capacity_835
 G  connected_order_arc_836
 L  arc_capacity_837
 G  connected_order_arc_838
 L  arc_capacity_839
 G  connected_order_arc_840
 L  arc_capacity_841
 G  connected_order_arc_842
 L  arc_capacity_843
 G  connected_order_arc_844
 L  arc_capacity_845
 G  connected_order_arc_846
 L  arc_capacity_847
 G  connected_order_arc_848
 L  arc_capacity_849
 G  connected_order_arc_850
 L  arc_capacity_851
 G  connected_order_arc_852
 L  arc_capacity_853
 G  connected_order_arc_854
 L  arc_capacity_855
 G  connected_order_arc_856
 L  arc_capacity_857
 L  arc_capacity_858
 G  connected_order_arc_859
 L  arc_capacity_860
 G  connected_order_arc_861
 L  arc_capacity_862
 G  connected_order_arc_863
 L  arc_capacity_864
 G  connected_order_arc_865
 L  arc_capacity_866
 G  connected_order_arc_867
 L  arc_capacity_868
 G  connected_order_arc_869
 L  arc_capacity_870
 G  connected_order_arc_871
 L  arc_capacity_872
 G  connected_order_arc_873
 L  arc_capacity_874
 G  connected_order_arc_875
 L  arc_capacity_876
 G  connected_order_arc_877
 L  arc_capacity_878
 G  connected_order_arc_879
 L  arc_capacity_880
 G  connected_order_arc_881
 L  arc_capacity_882
 L  arc_capacity_883
 G  connected_order_arc_884
 L  arc_capacity_885
 G  connected_order_arc_886
 L  arc_capacity_887
 G  connected_order_arc_888
 L  arc_capacity_889
 G  connected_order_arc_890
 L  arc_capacity_891
 G  connected_order_arc_892
 L  arc_capacity_893
 G  connected_order_arc_894
 L  arc_capacity_895
 G  connected_order_arc_896
 L  arc_capacity_897
 G  connected_order_arc_898
 L  arc_capacity_899
 G  connected_order_arc_900
 L  arc_capacity_901
 G  connected_order_arc_902
 L  arc_capacity_903
 G  connected_order_arc_904
 L  arc_capacity_905
 G  connected_order_arc_906
 L  arc_capacity_907
 L  arc_capacity_908
 G  connected_order_arc_909
 L  arc_capacity_910
 G  connected_order_arc_911
 L  arc_capacity_912
 G  connected_order_arc_913
 L  arc_capacity_914
 G  connected_order_arc_915
 L  arc_capacity_916
 G  connected_order_arc_917
 L  arc_capacity_918
 G  connected_order_arc_919
 L  arc_capacity_920
 G  connected_order_arc_921
 L  arc_capacity_922
 G  connected_order_arc_923
 L  arc_capacity_924
 G  connected_order_arc_925
 L  arc_capacity_926
 G  connected_order_arc_927
 L  arc_capacity_928
 G  connected_order_arc_929
 L  arc_capacity_930
 G  connected_order_arc_931
 L  arc_capacity_932
 L  arc_capacity_933
 G  connected_order_arc_934
 L  arc_capacity_935
 G  connected_order_arc_936
 L  arc_capacity_937
 G  connected_order_arc_938
 L  arc_capacity_939
 G  connected_order_arc_940
 L  arc_capacity_941
 G  connected_order_arc_942
 L  arc_capacity_943
 G  connected_order_arc_944
 L  arc_capacity_945
 G  connected_order_arc_946
 L  arc_capacity_947
 G  connected_order_arc_948
 L  arc_capacity_949
 G  connected_order_arc_950
 L  arc_capacity_951
 G  connected_order_arc_952
 L  arc_capacity_953
 G  connected_order_arc_954
 L  arc_capacity_955
 G  connected_order_arc_956
 L  arc_capacity_957
 L  arc_capacity_958
 G  connected_order_arc_959
 L  arc_capacity_960
 G  connected_order_arc_961
 L  arc_capacity_962
 G  connected_order_arc_963
 L  arc_capacity_964
 G  connected_order_arc_965
 L  arc_capacity_966
 G  connected_order_arc_967
 L  arc_capacity_968
 G  connected_order_arc_969
 L  arc_capacity_970
 G  connected_order_arc_971
 L  arc_capacity_972
 G  connected_order_arc_973
 L  arc_capacity_974
 G  connected_order_arc_975
 L  arc_capacity_976
 G  connected_order_arc_977
 L  arc_capacity_978
 G  connected_order_arc_979
 L  arc_capacity_980
 G  connected_order_arc_981
 L  arc_capacity_982
 L  arc_capacity_983
 G  connected_order_arc_984
 L  arc_capacity_985
 G  connected_order_arc_986
 L  arc_capacity_987
 G  connected_order_arc_988
 L  arc_capacity_989
 G  connected_order_arc_990
 L  arc_capacity_991
 G  connected_order_arc_992
 L  arc_capacity_993
 G  connected_order_arc_994
 L  arc_capacity_995
 G  connected_order_arc_996
 L  arc_capacity_997
 G  connected_order_arc_998
 L  arc_capacity_999
 G  connected_order_arc_1000
 L  arc_capacity_1001
 G  connected_order_arc_1002
 L  arc_capacity_1003
 G  connected_order_arc_1004
 L  arc_capacity_1005
 G  connected_order_arc_1006
 L  arc_capacity_1007
 L  arc_capacity_1008
 G  connected_order_arc_1009
 L  arc_capacity_1010
 G  connected_order_arc_1011
 L  arc_capacity_1012
 G  connected_order_arc_1013
 L  arc_capacity_1014
 G  connected_order_arc_1015
 L  arc_capacity_1016
 G  connected_order_arc_1017
 L  arc_capacity_1018
 G  connected_order_arc_1019
 L  arc_capacity_1020
 G  connected_order_arc_1021
 L  arc_capacity_1022
 G  connected_order_arc_1023
 L  arc_capacity_1024
 G  connected_order_arc_1025
 L  arc_capacity_1026
 G  connected_order_arc_1027
 L  arc_capacity_1028
 G  connected_order_arc_1029
 L  arc_capacity_1030
 G  connected_order_arc_1031
 L  arc_capacity_1032
 L  arc_capacity_1033
 G  connected_order_arc_1034
 L  arc_capacity_1035
 G  connected_order_arc_1036
 L  arc_capacity_1037
 G  connected_order_arc_1038
 L  arc_capacity_1039
 G  connected_order_arc_1040
 L  arc_capacity_1041
 G  connected_order_arc_1042
 L  arc_capacity_1043
 G  connected_order_arc_1044
 L  arc_capacity_1045
 G  connected_order_arc_1046
 L  arc_capacity_1047
 G  connected_order_arc_1048
 L  arc_capacity_1049
 G  connected_order_arc_1050
 L  arc_capacity_1051
 G  connected_order_arc_1052
 L  arc_capacity_1053
 G  connected_order_arc_1054
 L  arc_capacity_1055
 G  connected_order_arc_1056
 L  arc_capacity_1057
 L  arc_capacity_1058
 G  connected_order_arc_1059
 L  arc_capacity_1060
 G  connected_order_arc_1061
 L  arc_capacity_1062
 G  connected_order_arc_1063
 L  arc_capacity_1064
 G  connected_order_arc_1065
 L  arc_capacity_1066
 G  connected_order_arc_1067
 L  arc_capacity_1068
 G  connected_order_arc_1069
 L  arc_capacity_1070
 G  connected_order_arc_1071
 L  arc_capacity_1072
 G  connected_order_arc_1073
 L  arc_capacity_1074
 G  connected_order_arc_1075
 L  arc_capacity_1076
 G  connected_order_arc_1077
 L  arc_capacity_1078
 G  connected_order_arc_1079
 L  arc_capacity_1080
 G  connected_order_arc_1081
 L  arc_capacity_1082
 L  arc_capacity_1083
 G  connected_order_arc_1084
 L  arc_capacity_1085
 G  connected_order_arc_1086
 L  arc_capacity_1087
 G  connected_order_arc_1088
 L  arc_capacity_1089
 G  connected_order_arc_1090
 L  arc_capacity_1091
 G  connected_order_arc_1092
 L  arc_capacity_1093
 G  connected_order_arc_1094
 L  arc_capacity_1095
 G  connected_order_arc_1096
 L  arc_capacity_1097
 G  connected_order_arc_1098
 L  arc_capacity_1099
 G  connected_order_arc_1100
 L  arc_capacity_1101
 G  connected_order_arc_1102
 L  arc_capacity_1103
 G  connected_order_arc_1104
 L  arc_capacity_1105
 G  connected_order_arc_1106
 L  arc_capacity_1107
 L  arc_capacity_1108
 G  connected_order_arc_1109
 L  arc_capacity_1110
 G  connected_order_arc_1111
 L  arc_capacity_1112
 G  connected_order_arc_1113
 L  arc_capacity_1114
 G  connected_order_arc_1115
 L  arc_capacity_1116
 G  connected_order_arc_1117
 L  arc_capacity_1118
 G  connected_order_arc_1119
 L  arc_capacity_1120
 G  connected_order_arc_1121
 L  arc_capacity_1122
 G  connected_order_arc_1123
 L  arc_capacity_1124
 G  connected_order_arc_1125
 L  arc_capacity_1126
 G  connected_order_arc_1127
 L  arc_capacity_1128
 G  connected_order_arc_1129
 L  arc_capacity_1130
 G  connected_order_arc_1131
 E  depot_departure_or_bypass_1132
 E  depot_return_or_bypass_1133
 E  out_degree_1134
 E  in_degree_1135
 G  order_active_lb_1136
 L  order_active_ub_1137
 E  segment_load_conservation_1138
 G  segment_prefix_lb_1139
 L  segment_prefix_ub_1140
 E  out_degree_1141
 E  in_degree_1142
 G  order_active_lb_1143
 L  order_active_ub_1144
 E  segment_load_conservation_1145
 G  segment_prefix_lb_1146
 L  segment_prefix_ub_1147
 E  out_degree_1148
 E  in_degree_1149
 G  order_active_lb_1150
 L  order_active_ub_1151
 E  segment_load_conservation_1152
 G  segment_prefix_lb_1153
 L  segment_prefix_ub_1154
 E  out_degree_1155
 E  in_degree_1156
 G  order_active_lb_1157
 L  order_active_ub_1158
 E  segment_load_conservation_1159
 G  segment_prefix_lb_1160
 L  segment_prefix_ub_1161
 E  out_degree_1162
 E  in_degree_1163
 G  order_active_lb_1164
 L  order_active_ub_1165
 E  segment_load_conservation_1166
 G  segment_prefix_lb_1167
 L  segment_prefix_ub_1168
 E  out_degree_1169
 E  in_degree_1170
 G  order_active_lb_1171
 L  order_active_ub_1172
 E  service_visit_def_1173
 E  free_load_conservation_1174
 E  out_degree_1175
 E  in_degree_1176
 G  order_active_lb_1177
 L  order_active_ub_1178
 E  service_visit_def_1179
 E  free_load_conservation_1180
 E  out_degree_1181
 E  in_degree_1182
 G  order_active_lb_1183
 L  order_active_ub_1184
 E  service_visit_def_1185
 E  free_load_conservation_1186
 E  out_degree_1187
 E  in_degree_1188
 G  order_active_lb_1189
 L  order_active_ub_1190
 E  service_visit_def_1191
 E  free_load_conservation_1192
 E  out_degree_1193
 E  in_degree_1194
 G  order_active_lb_1195
 L  order_active_ub_1196
 E  service_visit_def_1197
 E  free_load_conservation_1198
 E  out_degree_1199
 E  in_degree_1200
 G  order_active_lb_1201
 L  order_active_ub_1202
 E  service_visit_def_1203
 E  free_load_conservation_1204
 E  out_degree_1205
 E  in_degree_1206
 G  order_active_lb_1207
 L  order_active_ub_1208
 E  service_visit_def_1209
 E  free_load_conservation_1210
 E  out_degree_1211
 E  in_degree_1212
 G  order_active_lb_1213
 L  order_active_ub_1214
 E  service_visit_def_1215
 E  free_load_conservation_1216
 G  fixed_segment_relative_order_1217
 G  fixed_segment_relative_order_1218
 G  fixed_segment_relative_order_1219
 G  fixed_segment_relative_order_1220
 L  original_T_including_depot_unload_1221
 L  arc_capacity_1222
 L  arc_capacity_1223
 L  arc_capacity_1224
 L  arc_capacity_1225
 L  arc_capacity_1226
 L  arc_capacity_1227
 L  arc_capacity_1228
 L  arc_capacity_1229
 L  arc_capacity_1230
 L  arc_capacity_1231
 L  arc_capacity_1232
 L  arc_capacity_1233
 L  arc_capacity_1234
 L  arc_capacity_1235
 L  arc_capacity_1236
 G  connected_order_arc_1237
 L  arc_capacity_1238
 G  connected_order_arc_1239
 L  arc_capacity_1240
 G  connected_order_arc_1241
 L  arc_capacity_1242
 G  connected_order_arc_1243
 L  arc_capacity_1244
 G  connected_order_arc_1245
 L  arc_capacity_1246
 G  connected_order_arc_1247
 L  arc_capacity_1248
 G  connected_order_arc_1249
 L  arc_capacity_1250
 G  connected_order_arc_1251
 L  arc_capacity_1252
 G  connected_order_arc_1253
 L  arc_capacity_1254
 G  connected_order_arc_1255
 L  arc_capacity_1256
 G  connected_order_arc_1257
 L  arc_capacity_1258
 L  arc_capacity_1259
 G  connected_order_arc_1260
 L  arc_capacity_1261
 G  connected_order_arc_1262
 L  arc_capacity_1263
 G  connected_order_arc_1264
 L  arc_capacity_1265
 G  connected_order_arc_1266
 L  arc_capacity_1267
 G  connected_order_arc_1268
 L  arc_capacity_1269
 G  connected_order_arc_1270
 L  arc_capacity_1271
 G  connected_order_arc_1272
 L  arc_capacity_1273
 G  connected_order_arc_1274
 L  arc_capacity_1275
 G  connected_order_arc_1276
 L  arc_capacity_1277
 G  connected_order_arc_1278
 L  arc_capacity_1279
 G  connected_order_arc_1280
 L  arc_capacity_1281
 L  arc_capacity_1282
 G  connected_order_arc_1283
 L  arc_capacity_1284
 G  connected_order_arc_1285
 L  arc_capacity_1286
 G  connected_order_arc_1287
 L  arc_capacity_1288
 G  connected_order_arc_1289
 L  arc_capacity_1290
 G  connected_order_arc_1291
 L  arc_capacity_1292
 G  connected_order_arc_1293
 L  arc_capacity_1294
 G  connected_order_arc_1295
 L  arc_capacity_1296
 G  connected_order_arc_1297
 L  arc_capacity_1298
 G  connected_order_arc_1299
 L  arc_capacity_1300
 G  connected_order_arc_1301
 L  arc_capacity_1302
 G  connected_order_arc_1303
 L  arc_capacity_1304
 L  arc_capacity_1305
 G  connected_order_arc_1306
 L  arc_capacity_1307
 G  connected_order_arc_1308
 L  arc_capacity_1309
 G  connected_order_arc_1310
 L  arc_capacity_1311
 G  connected_order_arc_1312
 L  arc_capacity_1313
 G  connected_order_arc_1314
 L  arc_capacity_1315
 G  connected_order_arc_1316
 L  arc_capacity_1317
 G  connected_order_arc_1318
 L  arc_capacity_1319
 G  connected_order_arc_1320
 L  arc_capacity_1321
 G  connected_order_arc_1322
 L  arc_capacity_1323
 G  connected_order_arc_1324
 L  arc_capacity_1325
 G  connected_order_arc_1326
 L  arc_capacity_1327
 L  arc_capacity_1328
 G  connected_order_arc_1329
 L  arc_capacity_1330
 G  connected_order_arc_1331
 L  arc_capacity_1332
 G  connected_order_arc_1333
 L  arc_capacity_1334
 G  connected_order_arc_1335
 L  arc_capacity_1336
 G  connected_order_arc_1337
 L  arc_capacity_1338
 G  connected_order_arc_1339
 L  arc_capacity_1340
 G  connected_order_arc_1341
 L  arc_capacity_1342
 G  connected_order_arc_1343
 L  arc_capacity_1344
 G  connected_order_arc_1345
 L  arc_capacity_1346
 G  connected_order_arc_1347
 L  arc_capacity_1348
 G  connected_order_arc_1349
 L  arc_capacity_1350
 L  arc_capacity_1351
 G  connected_order_arc_1352
 L  arc_capacity_1353
 G  connected_order_arc_1354
 L  arc_capacity_1355
 G  connected_order_arc_1356
 L  arc_capacity_1357
 G  connected_order_arc_1358
 L  arc_capacity_1359
 G  connected_order_arc_1360
 L  arc_capacity_1361
 G  connected_order_arc_1362
 L  arc_capacity_1363
 G  connected_order_arc_1364
 L  arc_capacity_1365
 G  connected_order_arc_1366
 L  arc_capacity_1367
 G  connected_order_arc_1368
 L  arc_capacity_1369
 G  connected_order_arc_1370
 L  arc_capacity_1371
 G  connected_order_arc_1372
 L  arc_capacity_1373
 L  arc_capacity_1374
 G  connected_order_arc_1375
 L  arc_capacity_1376
 G  connected_order_arc_1377
 L  arc_capacity_1378
 G  connected_order_arc_1379
 L  arc_capacity_1380
 G  connected_order_arc_1381
 L  arc_capacity_1382
 G  connected_order_arc_1383
 L  arc_capacity_1384
 G  connected_order_arc_1385
 L  arc_capacity_1386
 G  connected_order_arc_1387
 L  arc_capacity_1388
 G  connected_order_arc_1389
 L  arc_capacity_1390
 G  connected_order_arc_1391
 L  arc_capacity_1392
 G  connected_order_arc_1393
 L  arc_capacity_1394
 G  connected_order_arc_1395
 L  arc_capacity_1396
 L  arc_capacity_1397
 G  connected_order_arc_1398
 L  arc_capacity_1399
 G  connected_order_arc_1400
 L  arc_capacity_1401
 G  connected_order_arc_1402
 L  arc_capacity_1403
 G  connected_order_arc_1404
 L  arc_capacity_1405
 G  connected_order_arc_1406
 L  arc_capacity_1407
 G  connected_order_arc_1408
 L  arc_capacity_1409
 G  connected_order_arc_1410
 L  arc_capacity_1411
 G  connected_order_arc_1412
 L  arc_capacity_1413
 G  connected_order_arc_1414
 L  arc_capacity_1415
 G  connected_order_arc_1416
 L  arc_capacity_1417
 G  connected_order_arc_1418
 L  arc_capacity_1419
 L  arc_capacity_1420
 G  connected_order_arc_1421
 L  arc_capacity_1422
 G  connected_order_arc_1423
 L  arc_capacity_1424
 G  connected_order_arc_1425
 L  arc_capacity_1426
 G  connected_order_arc_1427
 L  arc_capacity_1428
 G  connected_order_arc_1429
 L  arc_capacity_1430
 G  connected_order_arc_1431
 L  arc_capacity_1432
 G  connected_order_arc_1433
 L  arc_capacity_1434
 G  connected_order_arc_1435
 L  arc_capacity_1436
 G  connected_order_arc_1437
 L  arc_capacity_1438
 G  connected_order_arc_1439
 L  arc_capacity_1440
 G  connected_order_arc_1441
 L  arc_capacity_1442
 L  arc_capacity_1443
 G  connected_order_arc_1444
 L  arc_capacity_1445
 G  connected_order_arc_1446
 L  arc_capacity_1447
 G  connected_order_arc_1448
 L  arc_capacity_1449
 G  connected_order_arc_1450
 L  arc_capacity_1451
 G  connected_order_arc_1452
 L  arc_capacity_1453
 G  connected_order_arc_1454
 L  arc_capacity_1455
 G  connected_order_arc_1456
 L  arc_capacity_1457
 G  connected_order_arc_1458
 L  arc_capacity_1459
 G  connected_order_arc_1460
 L  arc_capacity_1461
 G  connected_order_arc_1462
 L  arc_capacity_1463
 G  connected_order_arc_1464
 L  arc_capacity_1465
 L  arc_capacity_1466
 G  connected_order_arc_1467
 L  arc_capacity_1468
 G  connected_order_arc_1469
 L  arc_capacity_1470
 G  connected_order_arc_1471
 L  arc_capacity_1472
 G  connected_order_arc_1473
 L  arc_capacity_1474
 G  connected_order_arc_1475
 L  arc_capacity_1476
 G  connected_order_arc_1477
 L  arc_capacity_1478
 G  connected_order_arc_1479
 L  arc_capacity_1480
 G  connected_order_arc_1481
 L  arc_capacity_1482
 G  connected_order_arc_1483
 L  arc_capacity_1484
 G  connected_order_arc_1485
 L  arc_capacity_1486
 G  connected_order_arc_1487
 L  arc_capacity_1488
 L  arc_capacity_1489
 G  connected_order_arc_1490
 L  arc_capacity_1491
 G  connected_order_arc_1492
 L  arc_capacity_1493
 G  connected_order_arc_1494
 L  arc_capacity_1495
 G  connected_order_arc_1496
 L  arc_capacity_1497
 G  connected_order_arc_1498
 L  arc_capacity_1499
 G  connected_order_arc_1500
 L  arc_capacity_1501
 G  connected_order_arc_1502
 L  arc_capacity_1503
 G  connected_order_arc_1504
 L  arc_capacity_1505
 G  connected_order_arc_1506
 L  arc_capacity_1507
 G  connected_order_arc_1508
 L  arc_capacity_1509
 G  connected_order_arc_1510
 E  depot_departure_or_bypass_1511
 E  depot_return_or_bypass_1512
 E  out_degree_1513
 E  in_degree_1514
 G  order_active_lb_1515
 L  order_active_ub_1516
 E  segment_load_conservation_1517
 G  segment_prefix_lb_1518
 L  segment_prefix_ub_1519
 E  out_degree_1520
 E  in_degree_1521
 G  order_active_lb_1522
 L  order_active_ub_1523
 E  segment_load_conservation_1524
 G  segment_prefix_lb_1525
 L  segment_prefix_ub_1526
 E  out_degree_1527
 E  in_degree_1528
 G  order_active_lb_1529
 L  order_active_ub_1530
 E  segment_load_conservation_1531
 G  segment_prefix_lb_1532
 L  segment_prefix_ub_1533
 E  out_degree_1534
 E  in_degree_1535
 G  order_active_lb_1536
 L  order_active_ub_1537
 E  segment_load_conservation_1538
 G  segment_prefix_lb_1539
 L  segment_prefix_ub_1540
 E  out_degree_1541
 E  in_degree_1542
 G  order_active_lb_1543
 L  order_active_ub_1544
 E  service_visit_def_1545
 E  free_load_conservation_1546
 E  out_degree_1547
 E  in_degree_1548
 G  order_active_lb_1549
 L  order_active_ub_1550
 E  service_visit_def_1551
 E  free_load_conservation_1552
 E  out_degree_1553
 E  in_degree_1554
 G  order_active_lb_1555
 L  order_active_ub_1556
 E  service_visit_def_1557
 E  free_load_conservation_1558
 E  out_degree_1559
 E  in_degree_1560
 G  order_active_lb_1561
 L  order_active_ub_1562
 E  service_visit_def_1563
 E  free_load_conservation_1564
 E  out_degree_1565
 E  in_degree_1566
 G  order_active_lb_1567
 L  order_active_ub_1568
 E  service_visit_def_1569
 E  free_load_conservation_1570
 E  out_degree_1571
 E  in_degree_1572
 G  order_active_lb_1573
 L  order_active_ub_1574
 E  service_visit_def_1575
 E  free_load_conservation_1576
 E  out_degree_1577
 E  in_degree_1578
 G  order_active_lb_1579
 L  order_active_ub_1580
 E  service_visit_def_1581
 E  free_load_conservation_1582
 E  out_degree_1583
 E  in_degree_1584
 G  order_active_lb_1585
 L  order_active_ub_1586
 E  service_visit_def_1587
 E  free_load_conservation_1588
 G  fixed_segment_relative_order_1589
 G  fixed_segment_relative_order_1590
 G  fixed_segment_relative_order_1591
 L  original_T_including_depot_unload_1592
COLUMNS
    t         normalized_mass_15_35  -1
    t         normalized_mass_9_64  -1
    t         normalized_mass_31_93  -1
    t         normalized_mass_19_114  -1
    t         normalized_mass_16_143  -1
    t         normalized_mass_13_186  -1
    t         normalized_mass_32_215  -1
    t         normalized_mass_17_252  -1
    t         normalization_313  2.3890476190476196e+01
    t         full_original_Gini_314  -7.0585714285714317e+01
    q         OBJ       1
    q         parent_nonstrict_scope_256  1
    q         full_original_Gini_314  35
    MARKER    'MARKER'                 'INTORG'
    x_15_0    OBJ       0.06075
    x_15_0    product_lb_0  -2.4792168822839088e-02
    x_15_0    product_ub_1  -4.1857683874867449e-02
    x_15_0    onehot_15_34  1
    x_15_0    parent_nonstrict_scope_256  0.1215
    x_15_0    unique_nonzero_owner_315  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_0    product_lb_0  1
    w_15_0    product_ub_1  1
    w_15_0    normalized_mass_15_35  1
    w_15_0    full_original_Gini_314  -2.3890476190476196e+01
    MARKER    'MARKER'                 'INTORG'
    x_15_1    OBJ       4.7249999999999986e-02
    x_15_1    product_lb_2  -2.4792168822839088e-02
    x_15_1    product_ub_3  -4.1857683874867449e-02
    x_15_1    onehot_15_34  1
    x_15_1    stock_lb_254  1
    x_15_1    stock_ub_255  1
    x_15_1    parent_nonstrict_scope_256  1.0799999999999998e-01
    x_15_1    unique_nonzero_owner_316  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_1    product_lb_2  1
    w_15_1    product_ub_3  1
    w_15_1    normalized_mass_15_35  1
    w_15_1    normalized_ratio_15_36  -1.1111111111111110e-01
    w_15_1    full_original_Gini_314  -2.0890476190476196e+01
    MARKER    'MARKER'                 'INTORG'
    x_15_2    OBJ       0.03375
    x_15_2    product_lb_4  -2.4792168822839088e-02
    x_15_2    product_ub_5  -4.1857683874867449e-02
    x_15_2    onehot_15_34  1
    x_15_2    stock_lb_254  2
    x_15_2    stock_ub_255  2
    x_15_2    parent_nonstrict_scope_256  0.0945
    x_15_2    unique_nonzero_owner_317  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_2    product_lb_4  1
    w_15_2    product_ub_5  1
    w_15_2    normalized_mass_15_35  1
    w_15_2    normalized_ratio_15_36  -2.2222222222222221e-01
    w_15_2    full_original_Gini_314  -1.7890476190476193e+01
    MARKER    'MARKER'                 'INTORG'
    x_15_3    OBJ       2.0250000000000004e-02
    x_15_3    product_lb_6  -2.4792168822839088e-02
    x_15_3    product_ub_7  -4.1857683874867449e-02
    x_15_3    onehot_15_34  1
    x_15_3    stock_lb_254  3
    x_15_3    stock_ub_255  3
    x_15_3    parent_nonstrict_scope_256  0.081
    MARKER    'MARKER'                 'INTEND'
    w_15_3    product_lb_6  1
    w_15_3    product_ub_7  1
    w_15_3    normalized_mass_15_35  1
    w_15_3    normalized_ratio_15_36  -3.3333333333333331e-01
    w_15_3    full_original_Gini_314  -1.4890476190476189e+01
    MARKER    'MARKER'                 'INTORG'
    x_15_4    OBJ       6.7500000000000060e-03
    x_15_4    product_lb_8  -2.4792168822839088e-02
    x_15_4    product_ub_9  -4.1857683874867449e-02
    x_15_4    onehot_15_34  1
    x_15_4    stock_lb_254  4
    x_15_4    stock_ub_255  4
    x_15_4    parent_nonstrict_scope_256  0.0675
    x_15_4    unique_nonzero_owner_318  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_4    product_lb_8  1
    w_15_4    product_ub_9  1
    w_15_4    normalized_mass_15_35  1
    w_15_4    normalized_ratio_15_36  -4.4444444444444442e-01
    w_15_4    full_original_Gini_314  -1.1890476190476187e+01
    MARKER    'MARKER'                 'INTORG'
    x_15_5    OBJ       -6.7500000000000060e-03
    x_15_5    product_lb_10  -2.4792168822839088e-02
    x_15_5    product_ub_11  -4.1857683874867449e-02
    x_15_5    onehot_15_34  1
    x_15_5    stock_lb_254  5
    x_15_5    stock_ub_255  5
    x_15_5    parent_nonstrict_scope_256  5.3999999999999992e-02
    x_15_5    unique_nonzero_owner_319  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_5    product_lb_10  1
    w_15_5    product_ub_11  1
    w_15_5    normalized_mass_15_35  1
    w_15_5    normalized_ratio_15_36  -5.5555555555555558e-01
    w_15_5    full_original_Gini_314  -9.0015873015873016e+00
    MARKER    'MARKER'                 'INTORG'
    x_15_6    OBJ       -2.0249999999999997e-02
    x_15_6    product_lb_12  -2.4792168822839088e-02
    x_15_6    product_ub_13  -4.1857683874867449e-02
    x_15_6    onehot_15_34  1
    x_15_6    stock_lb_254  6
    x_15_6    stock_ub_255  6
    x_15_6    parent_nonstrict_scope_256  0.0405
    x_15_6    unique_nonzero_owner_320  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_6    product_lb_12  1
    w_15_6    product_ub_13  1
    w_15_6    normalized_mass_15_35  1
    w_15_6    normalized_ratio_15_36  -6.6666666666666663e-01
    w_15_6    full_original_Gini_314  -6.49047619047619
    MARKER    'MARKER'                 'INTORG'
    x_15_7    OBJ       -3.3749999999999988e-02
    x_15_7    product_lb_14  -2.4792168822839088e-02
    x_15_7    product_ub_15  -4.1857683874867449e-02
    x_15_7    onehot_15_34  1
    x_15_7    stock_lb_254  7
    x_15_7    stock_ub_255  7
    x_15_7    parent_nonstrict_scope_256  2.7000000000000010e-02
    x_15_7    unique_nonzero_owner_321  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_7    product_lb_14  1
    w_15_7    product_ub_15  1
    w_15_7    normalized_mass_15_35  1
    w_15_7    normalized_ratio_15_36  -7.7777777777777768e-01
    w_15_7    full_original_Gini_314  -4.7047619047619049e+00
    MARKER    'MARKER'                 'INTORG'
    x_15_8    OBJ       -4.7249999999999993e-02
    x_15_8    product_lb_16  -2.4792168822839088e-02
    x_15_8    product_ub_17  -4.1857683874867449e-02
    x_15_8    onehot_15_34  1
    x_15_8    stock_lb_254  8
    x_15_8    stock_ub_255  8
    x_15_8    parent_nonstrict_scope_256  1.3500000000000005e-02
    x_15_8    unique_nonzero_owner_322  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_8    product_lb_16  1
    w_15_8    product_ub_17  1
    w_15_8    normalized_mass_15_35  1
    w_15_8    normalized_ratio_15_36  -8.8888888888888884e-01
    w_15_8    full_original_Gini_314  -4.12063492063492
    MARKER    'MARKER'                 'INTORG'
    x_15_9    OBJ       -0.06075
    x_15_9    product_lb_18  -2.4792168822839088e-02
    x_15_9    product_ub_19  -4.1857683874867449e-02
    x_15_9    onehot_15_34  1
    x_15_9    stock_lb_254  9
    x_15_9    stock_ub_255  9
    x_15_9    unique_nonzero_owner_323  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_9    product_lb_18  1
    w_15_9    product_ub_19  1
    w_15_9    normalized_mass_15_35  1
    w_15_9    normalized_ratio_15_36  -1
    w_15_9    full_original_Gini_314  -4.0095238095238095e+00
    MARKER    'MARKER'                 'INTORG'
    x_15_10   OBJ       -4.7249999999999993e-02
    x_15_10   product_lb_20  -2.4792168822839088e-02
    x_15_10   product_ub_21  -4.1857683874867449e-02
    x_15_10   onehot_15_34  1
    x_15_10   stock_lb_254  10
    x_15_10   stock_ub_255  10
    x_15_10   parent_nonstrict_scope_256  1.3500000000000005e-02
    x_15_10   unique_nonzero_owner_324  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_10   product_lb_20  1
    w_15_10   product_ub_21  1
    w_15_10   normalized_mass_15_35  1
    w_15_10   normalized_ratio_15_36  -1.1111111111111112e+00
    w_15_10   full_original_Gini_314  -6.5650793650793648e+00
    MARKER    'MARKER'                 'INTORG'
    x_15_11   OBJ       -3.3750000000000016e-02
    x_15_11   product_lb_22  -2.4792168822839088e-02
    x_15_11   product_ub_23  -4.1857683874867449e-02
    x_15_11   onehot_15_34  1
    x_15_11   stock_lb_254  11
    x_15_11   stock_ub_255  11
    x_15_11   parent_nonstrict_scope_256  2.6999999999999986e-02
    x_15_11   unique_nonzero_owner_325  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_11   product_lb_22  1
    w_15_11   product_ub_23  1
    w_15_11   normalized_mass_15_35  1
    w_15_11   normalized_ratio_15_36  -1.2222222222222221e+00
    w_15_11   full_original_Gini_314  -9.1650793650793627e+00
    MARKER    'MARKER'                 'INTORG'
    x_15_12   OBJ       -2.0250000000000011e-02
    x_15_12   product_lb_24  -2.4792168822839088e-02
    x_15_12   product_ub_25  -4.1857683874867449e-02
    x_15_12   onehot_15_34  1
    x_15_12   stock_lb_254  12
    x_15_12   stock_ub_255  12
    x_15_12   parent_nonstrict_scope_256  4.0499999999999987e-02
    x_15_12   unique_nonzero_owner_326  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_12   product_lb_24  1
    w_15_12   product_ub_25  1
    w_15_12   normalized_mass_15_35  1
    w_15_12   normalized_ratio_15_36  -1.3333333333333333e+00
    w_15_12   full_original_Gini_314  -1.2109523809523809e+01
    MARKER    'MARKER'                 'INTORG'
    x_15_13   OBJ       -6.7500000000000060e-03
    x_15_13   product_lb_26  -2.4792168822839088e-02
    x_15_13   product_ub_27  -4.1857683874867449e-02
    x_15_13   onehot_15_34  1
    x_15_13   stock_lb_254  13
    x_15_13   stock_ub_255  13
    x_15_13   parent_nonstrict_scope_256  5.3999999999999992e-02
    x_15_13   unique_nonzero_owner_327  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_13   product_lb_26  1
    w_15_13   product_ub_27  1
    w_15_13   normalized_mass_15_35  1
    w_15_13   normalized_ratio_15_36  -1.4444444444444444e+00
    w_15_13   full_original_Gini_314  -1.5109523809523809e+01
    MARKER    'MARKER'                 'INTORG'
    x_15_14   OBJ       6.7499999999999782e-03
    x_15_14   product_lb_28  -2.4792168822839088e-02
    x_15_14   product_ub_29  -4.1857683874867449e-02
    x_15_14   onehot_15_34  1
    x_15_14   stock_lb_254  14
    x_15_14   stock_ub_255  14
    x_15_14   parent_nonstrict_scope_256  6.7499999999999977e-02
    x_15_14   unique_nonzero_owner_328  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_14   product_lb_28  1
    w_15_14   product_ub_29  1
    w_15_14   normalized_mass_15_35  1
    w_15_14   normalized_ratio_15_36  -1.5555555555555554e+00
    w_15_14   full_original_Gini_314  -1.8109523809523807e+01
    MARKER    'MARKER'                 'INTORG'
    x_15_15   OBJ       2.0249999999999976e-02
    x_15_15   product_lb_30  -2.4792168822839088e-02
    x_15_15   product_ub_31  -4.1857683874867449e-02
    x_15_15   onehot_15_34  1
    x_15_15   stock_lb_254  15
    x_15_15   stock_ub_255  15
    x_15_15   parent_nonstrict_scope_256  8.0999999999999975e-02
    x_15_15   unique_nonzero_owner_329  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_15   product_lb_30  1
    w_15_15   product_ub_31  1
    w_15_15   normalized_mass_15_35  1
    w_15_15   normalized_ratio_15_36  -1.6666666666666665e+00
    w_15_15   full_original_Gini_314  -2.1109523809523811e+01
    MARKER    'MARKER'                 'INTORG'
    x_15_16   OBJ       3.3749999999999988e-02
    x_15_16   product_lb_32  -2.4792168822839088e-02
    x_15_16   product_ub_33  -4.1857683874867449e-02
    x_15_16   onehot_15_34  1
    x_15_16   stock_lb_254  16
    x_15_16   stock_ub_255  16
    x_15_16   parent_nonstrict_scope_256  9.4499999999999987e-02
    x_15_16   unique_nonzero_owner_330  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_16   product_lb_32  1
    w_15_16   product_ub_33  1
    w_15_16   normalized_mass_15_35  1
    w_15_16   normalized_ratio_15_36  -1.7777777777777777e+00
    w_15_16   full_original_Gini_314  -2.4109523809523814e+01
    rho_15    normalized_ratio_15_36  1
    rho_15    block_pair_pos_273  -1
    rho_15    block_pair_neg_274  1
    rho_15    block_pair_pos_275  -1
    rho_15    block_pair_neg_276  1
    rho_15    block_pair_pos_277  -1
    rho_15    block_pair_neg_278  1
    rho_15    block_pair_pos_279  -1
    rho_15    block_pair_neg_280  1
    rho_15    block_pair_pos_281  -1
    rho_15    block_pair_neg_282  1
    rho_15    block_pair_pos_283  -1
    rho_15    block_pair_neg_284  1
    rho_15    block_pair_pos_285  -1
    rho_15    block_pair_neg_286  1
    rho_15    normalization_313  1
    MARKER    'MARKER'                 'INTORG'
    x_9_0     OBJ       1.1249999999999993e-02
    x_9_0     product_lb_37  -2.4792168822839088e-02
    x_9_0     product_ub_38  -4.1857683874867449e-02
    x_9_0     onehot_9_63  1
    x_9_0     parent_nonstrict_scope_256  0.0375
    x_9_0     unique_nonzero_owner_331  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_0     product_lb_37  1
    w_9_0     product_ub_38  1
    w_9_0     normalized_mass_9_64  1
    w_9_0     full_original_Gini_314  -2.3890476190476196e+01
    MARKER    'MARKER'                 'INTORG'
    x_9_1     OBJ       3.7499999999999929e-03
    x_9_1     product_lb_39  -2.4792168822839088e-02
    x_9_1     product_ub_40  -4.1857683874867449e-02
    x_9_1     onehot_9_63  1
    x_9_1     stock_lb_254  1
    x_9_1     stock_ub_255  1
    x_9_1     parent_nonstrict_scope_256  0.03
    x_9_1     unique_nonzero_owner_332  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_1     product_lb_39  1
    w_9_1     product_ub_40  1
    w_9_1     normalized_mass_9_64  1
    w_9_1     normalized_ratio_9_65  -0.2
    w_9_1     full_original_Gini_314  -1.8490476190476191e+01
    MARKER    'MARKER'                 'INTORG'
    x_9_2     OBJ       -3.7500000000000068e-03
    x_9_2     product_lb_41  -2.4792168822839088e-02
    x_9_2     product_ub_42  -4.1857683874867449e-02
    x_9_2     onehot_9_63  1
    x_9_2     stock_lb_254  2
    x_9_2     stock_ub_255  2
    x_9_2     parent_nonstrict_scope_256  0.0225
    x_9_2     unique_nonzero_owner_333  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_2     product_lb_41  1
    w_9_2     product_ub_42  1
    w_9_2     normalized_mass_9_64  1
    w_9_2     normalized_ratio_9_65  -0.4
    w_9_2     full_original_Gini_314  -1.3090476190476188e+01
    MARKER    'MARKER'                 'INTORG'
    x_9_3     OBJ       -1.1250000000000010e-02
    x_9_3     product_lb_43  -2.4792168822839088e-02
    x_9_3     product_ub_44  -4.1857683874867449e-02
    x_9_3     onehot_9_63  1
    x_9_3     stock_lb_254  3
    x_9_3     stock_ub_255  3
    x_9_3     parent_nonstrict_scope_256  1.4999999999999996e-02
    x_9_3     unique_nonzero_owner_334  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_3     product_lb_43  1
    w_9_3     product_ub_44  1
    w_9_3     normalized_mass_9_64  1
    w_9_3     normalized_ratio_9_65  -6.0000000000000009e-01
    w_9_3     full_original_Gini_314  -7.8904761904761909e+00
    MARKER    'MARKER'                 'INTORG'
    x_9_4     OBJ       -1.8750000000000010e-02
    x_9_4     product_lb_45  -2.4792168822839088e-02
    x_9_4     product_ub_46  -4.1857683874867449e-02
    x_9_4     onehot_9_63  1
    x_9_4     stock_lb_254  4
    x_9_4     stock_ub_255  4
    x_9_4     parent_nonstrict_scope_256  7.4999999999999980e-03
    x_9_4     unique_nonzero_owner_335  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_4     product_lb_45  1
    w_9_4     product_ub_46  1
    w_9_4     normalized_mass_9_64  1
    w_9_4     normalized_ratio_9_65  -0.8
    w_9_4     full_original_Gini_314  -4.5047619047619065e+00
    MARKER    'MARKER'                 'INTORG'
    x_9_5     OBJ       -2.6250000000000006e-02
    x_9_5     product_lb_47  -2.4792168822839088e-02
    x_9_5     product_ub_48  -4.1857683874867449e-02
    x_9_5     onehot_9_63  1
    x_9_5     stock_lb_254  5
    x_9_5     stock_ub_255  5
    x_9_5     unique_nonzero_owner_336  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_5     product_lb_47  1
    w_9_5     product_ub_48  1
    w_9_5     normalized_mass_9_64  1
    w_9_5     normalized_ratio_9_65  -1
    w_9_5     full_original_Gini_314  -4.0095238095238095e+00
    MARKER    'MARKER'                 'INTORG'
    x_9_6     OBJ       -0.01875
    x_9_6     product_lb_49  -2.4792168822839088e-02
    x_9_6     product_ub_50  -4.1857683874867449e-02
    x_9_6     onehot_9_63  1
    x_9_6     stock_lb_254  6
    x_9_6     stock_ub_255  6
    x_9_6     parent_nonstrict_scope_256  7.5000000000000067e-03
    x_9_6     unique_nonzero_owner_337  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_6     product_lb_49  1
    w_9_6     product_ub_50  1
    w_9_6     normalized_mass_9_64  1
    w_9_6     normalized_ratio_9_65  -1.2000000000000002e+00
    w_9_6     full_original_Gini_314  -8.6095238095238145e+00
    MARKER    'MARKER'                 'INTORG'
    x_9_7     OBJ       -1.1250000000000001e-02
    x_9_7     product_lb_51  -2.4792168822839088e-02
    x_9_7     product_ub_52  -4.1857683874867449e-02
    x_9_7     onehot_9_63  1
    x_9_7     stock_lb_254  7
    x_9_7     stock_ub_255  7
    x_9_7     parent_nonstrict_scope_256  1.5000000000000005e-02
    x_9_7     unique_nonzero_owner_338  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_7     product_lb_51  1
    w_9_7     product_ub_52  1
    w_9_7     normalized_mass_9_64  1
    w_9_7     normalized_ratio_9_65  -1.4000000000000001e+00
    w_9_7     full_original_Gini_314  -1.3909523809523817e+01
    MARKER    'MARKER'                 'INTORG'
    x_9_8     OBJ       -3.7500000000000033e-03
    x_9_8     product_lb_53  -2.4792168822839088e-02
    x_9_8     product_ub_54  -4.1857683874867449e-02
    x_9_8     onehot_9_63  1
    x_9_8     stock_lb_254  8
    x_9_8     stock_ub_255  8
    x_9_8     parent_nonstrict_scope_256  2.2500000000000003e-02
    MARKER    'MARKER'                 'INTEND'
    w_9_8     product_lb_53  1
    w_9_8     product_ub_54  1
    w_9_8     normalized_mass_9_64  1
    w_9_8     normalized_ratio_9_65  -1.6
    w_9_8     full_original_Gini_314  -1.9309523809523810e+01
    MARKER    'MARKER'                 'INTORG'
    x_9_9     OBJ       3.7499999999999929e-03
    x_9_9     product_lb_55  -2.4792168822839088e-02
    x_9_9     product_ub_56  -4.1857683874867449e-02
    x_9_9     onehot_9_63  1
    x_9_9     stock_lb_254  9
    x_9_9     stock_ub_255  9
    x_9_9     parent_nonstrict_scope_256  0.03
    x_9_9     unique_nonzero_owner_339  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_9     product_lb_55  1
    w_9_9     product_ub_56  1
    w_9_9     normalized_mass_9_64  1
    w_9_9     normalized_ratio_9_65  -1.8
    w_9_9     full_original_Gini_314  -2.4709523809523816e+01
    MARKER    'MARKER'                 'INTORG'
    x_9_10    OBJ       1.1249999999999993e-02
    x_9_10    product_lb_57  -2.4792168822839088e-02
    x_9_10    product_ub_58  -4.1857683874867449e-02
    x_9_10    onehot_9_63  1
    x_9_10    stock_lb_254  10
    x_9_10    stock_ub_255  10
    x_9_10    parent_nonstrict_scope_256  0.0375
    x_9_10    unique_nonzero_owner_340  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_10    product_lb_57  1
    w_9_10    product_ub_58  1
    w_9_10    normalized_mass_9_64  1
    w_9_10    normalized_ratio_9_65  -2
    w_9_10    full_original_Gini_314  -3.0109523809523807e+01
    MARKER    'MARKER'                 'INTORG'
    x_9_11    OBJ       0.01875
    x_9_11    product_lb_59  -2.4792168822839088e-02
    x_9_11    product_ub_60  -4.1857683874867449e-02
    x_9_11    onehot_9_63  1
    x_9_11    stock_lb_254  11
    x_9_11    stock_ub_255  11
    x_9_11    parent_nonstrict_scope_256  4.5000000000000005e-02
    x_9_11    unique_nonzero_owner_341  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_11    product_lb_59  1
    w_9_11    product_ub_60  1
    w_9_11    normalized_mass_9_64  1
    w_9_11    normalized_ratio_9_65  -2.2
    w_9_11    full_original_Gini_314  -3.5509523809523806e+01
    MARKER    'MARKER'                 'INTORG'
    x_9_12    OBJ       2.6250000000000006e-02
    x_9_12    product_lb_61  -2.4792168822839088e-02
    x_9_12    product_ub_62  -4.1857683874867449e-02
    x_9_12    onehot_9_63  1
    x_9_12    stock_lb_254  12
    x_9_12    stock_ub_255  12
    x_9_12    parent_nonstrict_scope_256  5.2500000000000012e-02
    x_9_12    unique_nonzero_owner_342  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_12    product_lb_61  1
    w_9_12    product_ub_62  1
    w_9_12    normalized_mass_9_64  1
    w_9_12    normalized_ratio_9_65  -2.4000000000000004e+00
    w_9_12    full_original_Gini_314  -40.9095238095238
    rho_9     normalized_ratio_9_65  1
    rho_9     block_pair_pos_257  -1
    rho_9     block_pair_neg_258  1
    rho_9     block_pair_pos_259  -1
    rho_9     block_pair_neg_260  1
    rho_9     block_pair_pos_261  -1
    rho_9     block_pair_neg_262  1
    rho_9     block_pair_pos_263  -1
    rho_9     block_pair_neg_264  1
    rho_9     block_pair_pos_265  -1
    rho_9     block_pair_neg_266  1
    rho_9     block_pair_pos_267  -1
    rho_9     block_pair_neg_268  1
    rho_9     block_pair_pos_273  1
    rho_9     block_pair_neg_274  -1
    rho_9     normalization_313  1
    MARKER    'MARKER'                 'INTORG'
    x_31_0    OBJ       0.03675
    x_31_0    product_lb_66  -2.4792168822839088e-02
    x_31_0    product_ub_67  -4.1857683874867449e-02
    x_31_0    onehot_31_92  1
    x_31_0    parent_nonstrict_scope_256  0.0735
    x_31_0    unique_nonzero_owner_343  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_0    product_lb_66  1
    w_31_0    product_ub_67  1
    w_31_0    normalized_mass_31_93  1
    w_31_0    full_original_Gini_314  -2.3890476190476196e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_1    OBJ       2.6250000000000002e-02
    x_31_1    product_lb_68  -2.4792168822839088e-02
    x_31_1    product_ub_69  -4.1857683874867449e-02
    x_31_1    onehot_31_92  1
    x_31_1    stock_lb_254  1
    x_31_1    stock_ub_255  1
    x_31_1    parent_nonstrict_scope_256  0.063
    x_31_1    unique_nonzero_owner_344  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_1    product_lb_68  1
    w_31_1    product_ub_69  1
    w_31_1    normalized_mass_31_93  1
    w_31_1    normalized_ratio_31_94  -1.4285714285714285e-01
    w_31_1    full_original_Gini_314  -2.0033333333333339e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_2    OBJ       0.01575
    x_31_2    product_lb_70  -2.4792168822839088e-02
    x_31_2    product_ub_71  -4.1857683874867449e-02
    x_31_2    onehot_31_92  1
    x_31_2    stock_lb_254  2
    x_31_2    stock_ub_255  2
    x_31_2    parent_nonstrict_scope_256  0.0525
    MARKER    'MARKER'                 'INTEND'
    w_31_2    product_lb_70  1
    w_31_2    product_ub_71  1
    w_31_2    normalized_mass_31_93  1
    w_31_2    normalized_ratio_31_94  -2.8571428571428570e-01
    w_31_2    full_original_Gini_314  -1.6176190476190474e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_3    OBJ       5.2499999999999977e-03
    x_31_3    product_lb_72  -2.4792168822839088e-02
    x_31_3    product_ub_73  -4.1857683874867449e-02
    x_31_3    onehot_31_92  1
    x_31_3    stock_lb_254  3
    x_31_3    stock_ub_255  3
    x_31_3    parent_nonstrict_scope_256  4.1999999999999996e-02
    x_31_3    unique_nonzero_owner_345  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_3    product_lb_72  1
    w_31_3    product_ub_73  1
    w_31_3    normalized_mass_31_93  1
    w_31_3    normalized_ratio_31_94  -4.2857142857142855e-01
    w_31_3    full_original_Gini_314  -1.2319047619047618e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_4    OBJ       -5.2499999999999977e-03
    x_31_4    product_lb_74  -2.4792168822839088e-02
    x_31_4    product_ub_75  -4.1857683874867449e-02
    x_31_4    onehot_31_92  1
    x_31_4    stock_lb_254  4
    x_31_4    stock_ub_255  4
    x_31_4    parent_nonstrict_scope_256  0.0315
    x_31_4    unique_nonzero_owner_346  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_4    product_lb_74  1
    w_31_4    product_ub_75  1
    w_31_4    normalized_mass_31_93  1
    w_31_4    normalized_ratio_31_94  -5.7142857142857140e-01
    w_31_4    full_original_Gini_314  -8.6047619047619062e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_5    OBJ       -1.5749999999999993e-02
    x_31_5    product_lb_76  -2.4792168822839088e-02
    x_31_5    product_ub_77  -4.1857683874867449e-02
    x_31_5    onehot_31_92  1
    x_31_5    stock_lb_254  5
    x_31_5    stock_ub_255  5
    x_31_5    parent_nonstrict_scope_256  2.1000000000000005e-02
    x_31_5    unique_nonzero_owner_347  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_5    product_lb_76  1
    w_31_5    product_ub_77  1
    w_31_5    normalized_mass_31_93  1
    w_31_5    normalized_ratio_31_94  -7.1428571428571419e-01
    w_31_5    full_original_Gini_314  -5.4904761904761905e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_6    OBJ       -2.6249999999999996e-02
    x_31_6    product_lb_78  -2.4792168822839088e-02
    x_31_6    product_ub_79  -4.1857683874867449e-02
    x_31_6    onehot_31_92  1
    x_31_6    stock_lb_254  6
    x_31_6    stock_ub_255  6
    x_31_6    parent_nonstrict_scope_256  1.0500000000000002e-02
    x_31_6    unique_nonzero_owner_348  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_6    product_lb_78  1
    w_31_6    product_ub_79  1
    w_31_6    normalized_mass_31_93  1
    w_31_6    normalized_ratio_31_94  -8.5714285714285710e-01
    w_31_6    full_original_Gini_314  -4.1523809523809518e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_7    OBJ       -0.03675
    x_31_7    product_lb_80  -2.4792168822839088e-02
    x_31_7    product_ub_81  -4.1857683874867449e-02
    x_31_7    onehot_31_92  1
    x_31_7    stock_lb_254  7
    x_31_7    stock_ub_255  7
    x_31_7    unique_nonzero_owner_349  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_7    product_lb_80  1
    w_31_7    product_ub_81  1
    w_31_7    normalized_mass_31_93  1
    w_31_7    normalized_ratio_31_94  -1
    w_31_7    full_original_Gini_314  -4.0095238095238095e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_8    OBJ       -2.6250000000000002e-02
    x_31_8    product_lb_82  -2.4792168822839088e-02
    x_31_8    product_ub_83  -4.1857683874867449e-02
    x_31_8    onehot_31_92  1
    x_31_8    stock_lb_254  8
    x_31_8    stock_ub_255  8
    x_31_8    parent_nonstrict_scope_256  1.0499999999999995e-02
    x_31_8    unique_nonzero_owner_350  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_8    product_lb_82  1
    w_31_8    product_ub_83  1
    w_31_8    normalized_mass_31_93  1
    w_31_8    normalized_ratio_31_94  -1.1428571428571428e+00
    w_31_8    full_original_Gini_314  -7.2952380952380924e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_9    OBJ       -1.5750000000000007e-02
    x_31_9    product_lb_84  -2.4792168822839088e-02
    x_31_9    product_ub_85  -4.1857683874867449e-02
    x_31_9    onehot_31_92  1
    x_31_9    stock_lb_254  9
    x_31_9    stock_ub_255  9
    x_31_9    parent_nonstrict_scope_256  2.0999999999999991e-02
    x_31_9    unique_nonzero_owner_351  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_9    product_lb_84  1
    w_31_9    product_ub_85  1
    w_31_9    normalized_mass_31_93  1
    w_31_9    normalized_ratio_31_94  -1.2857142857142856e+00
    w_31_9    full_original_Gini_314  -1.0823809523809516e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_10   OBJ       -5.2500000000000116e-03
    x_31_10   product_lb_86  -2.4792168822839088e-02
    x_31_10   product_ub_87  -4.1857683874867449e-02
    x_31_10   onehot_31_92  1
    x_31_10   stock_lb_254  10
    x_31_10   stock_ub_255  10
    x_31_10   parent_nonstrict_scope_256  3.1499999999999986e-02
    x_31_10   unique_nonzero_owner_352  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_10   product_lb_86  1
    w_31_10   product_ub_87  1
    w_31_10   normalized_mass_31_93  1
    w_31_10   normalized_ratio_31_94  -1.4285714285714284e+00
    w_31_10   full_original_Gini_314  -1.4680952380952379e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_11   OBJ       5.2499999999999977e-03
    x_31_11   product_lb_88  -2.4792168822839088e-02
    x_31_11   product_ub_89  -4.1857683874867449e-02
    x_31_11   onehot_31_92  1
    x_31_11   stock_lb_254  11
    x_31_11   stock_ub_255  11
    x_31_11   parent_nonstrict_scope_256  4.1999999999999996e-02
    x_31_11   unique_nonzero_owner_353  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_11   product_lb_88  1
    w_31_11   product_ub_89  1
    w_31_11   normalized_mass_31_93  1
    w_31_11   normalized_ratio_31_94  -1.5714285714285714e+00
    w_31_11   full_original_Gini_314  -1.8538095238095238e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_12   OBJ       1.5749999999999993e-02
    x_31_12   product_lb_90  -2.4792168822839088e-02
    x_31_12   product_ub_91  -4.1857683874867449e-02
    x_31_12   onehot_31_92  1
    x_31_12   stock_lb_254  12
    x_31_12   stock_ub_255  12
    x_31_12   parent_nonstrict_scope_256  5.2499999999999991e-02
    x_31_12   unique_nonzero_owner_354  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_12   product_lb_90  1
    w_31_12   product_ub_91  1
    w_31_12   normalized_mass_31_93  1
    w_31_12   normalized_ratio_31_94  -1.7142857142857142e+00
    w_31_12   full_original_Gini_314  -2.2395238095238096e+01
    rho_31    normalized_ratio_31_94  1
    rho_31    block_pair_pos_265  1
    rho_31    block_pair_neg_266  -1
    rho_31    block_pair_pos_283  1
    rho_31    block_pair_neg_284  -1
    rho_31    block_pair_pos_301  -1
    rho_31    block_pair_neg_302  1
    rho_31    block_pair_pos_303  -1
    rho_31    block_pair_neg_304  1
    rho_31    block_pair_pos_305  -1
    rho_31    block_pair_neg_306  1
    rho_31    block_pair_pos_307  -1
    rho_31    block_pair_neg_308  1
    rho_31    block_pair_pos_309  -1
    rho_31    block_pair_neg_310  1
    rho_31    normalization_313  1
    MARKER    'MARKER'                 'INTORG'
    x_19_0    OBJ       0.012
    x_19_0    product_lb_95  -2.4792168822839088e-02
    x_19_0    product_ub_96  -4.1857683874867449e-02
    x_19_0    onehot_19_113  1
    x_19_0    parent_nonstrict_scope_256  0.024
    MARKER    'MARKER'                 'INTEND'
    w_19_0    product_lb_95  1
    w_19_0    product_ub_96  1
    w_19_0    normalized_mass_19_114  1
    w_19_0    full_original_Gini_314  -2.3890476190476196e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_1    OBJ       6.0000000000000019e-03
    x_19_1    product_lb_97  -2.4792168822839088e-02
    x_19_1    product_ub_98  -4.1857683874867449e-02
    x_19_1    onehot_19_113  1
    x_19_1    stock_lb_254  1
    x_19_1    stock_ub_255  1
    x_19_1    parent_nonstrict_scope_256  1.8000000000000002e-02
    x_19_1    unique_nonzero_owner_355  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_1    product_lb_97  1
    w_19_1    product_ub_98  1
    w_19_1    normalized_mass_19_114  1
    w_19_1    normalized_ratio_19_115  -0.25
    w_19_1    full_original_Gini_314  -1.7140476190476193e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_2    product_lb_99  -2.4792168822839088e-02
    x_19_2    product_ub_100  -4.1857683874867449e-02
    x_19_2    onehot_19_113  1
    x_19_2    stock_lb_254  2
    x_19_2    stock_ub_255  2
    x_19_2    parent_nonstrict_scope_256  0.012
    x_19_2    unique_nonzero_owner_356  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_2    product_lb_99  1
    w_19_2    product_ub_100  1
    w_19_2    normalized_mass_19_114  1
    w_19_2    normalized_ratio_19_115  -0.5
    w_19_2    full_original_Gini_314  -1.0390476190476189e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_3    OBJ       -0.006
    x_19_3    product_lb_101  -2.4792168822839088e-02
    x_19_3    product_ub_102  -4.1857683874867449e-02
    x_19_3    onehot_19_113  1
    x_19_3    stock_lb_254  3
    x_19_3    stock_ub_255  3
    x_19_3    parent_nonstrict_scope_256  0.006
    x_19_3    unique_nonzero_owner_357  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_3    product_lb_101  1
    w_19_3    product_ub_102  1
    w_19_3    normalized_mass_19_114  1
    w_19_3    normalized_ratio_19_115  -0.75
    w_19_3    full_original_Gini_314  -4.9547619047619040e+00
    MARKER    'MARKER'                 'INTORG'
    x_19_4    OBJ       -0.012
    x_19_4    product_lb_103  -2.4792168822839088e-02
    x_19_4    product_ub_104  -4.1857683874867449e-02
    x_19_4    onehot_19_113  1
    x_19_4    stock_lb_254  4
    x_19_4    stock_ub_255  4
    x_19_4    unique_nonzero_owner_358  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_4    product_lb_103  1
    w_19_4    product_ub_104  1
    w_19_4    normalized_mass_19_114  1
    w_19_4    normalized_ratio_19_115  -1
    w_19_4    full_original_Gini_314  -4.0095238095238095e+00
    MARKER    'MARKER'                 'INTORG'
    x_19_5    OBJ       -0.006
    x_19_5    product_lb_105  -2.4792168822839088e-02
    x_19_5    product_ub_106  -4.1857683874867449e-02
    x_19_5    onehot_19_113  1
    x_19_5    stock_lb_254  5
    x_19_5    stock_ub_255  5
    x_19_5    parent_nonstrict_scope_256  0.006
    x_19_5    unique_nonzero_owner_359  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_5    product_lb_105  1
    w_19_5    product_ub_106  1
    w_19_5    normalized_mass_19_114  1
    w_19_5    normalized_ratio_19_115  -1.25
    w_19_5    full_original_Gini_314  -9.8595238095238109e+00
    MARKER    'MARKER'                 'INTORG'
    x_19_6    product_lb_107  -2.4792168822839088e-02
    x_19_6    product_ub_108  -4.1857683874867449e-02
    x_19_6    onehot_19_113  1
    x_19_6    stock_lb_254  6
    x_19_6    stock_ub_255  6
    x_19_6    parent_nonstrict_scope_256  0.012
    x_19_6    unique_nonzero_owner_360  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_6    product_lb_107  1
    w_19_6    product_ub_108  1
    w_19_6    normalized_mass_19_114  1
    w_19_6    normalized_ratio_19_115  -1.5
    w_19_6    full_original_Gini_314  -1.6609523809523807e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_7    OBJ       6.0000000000000019e-03
    x_19_7    product_lb_109  -2.4792168822839088e-02
    x_19_7    product_ub_110  -4.1857683874867449e-02
    x_19_7    onehot_19_113  1
    x_19_7    stock_lb_254  7
    x_19_7    stock_ub_255  7
    x_19_7    parent_nonstrict_scope_256  1.8000000000000002e-02
    x_19_7    unique_nonzero_owner_361  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_7    product_lb_109  1
    w_19_7    product_ub_110  1
    w_19_7    normalized_mass_19_114  1
    w_19_7    normalized_ratio_19_115  -1.75
    w_19_7    full_original_Gini_314  -2.3359523809523804e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_8    OBJ       0.012
    x_19_8    product_lb_111  -2.4792168822839088e-02
    x_19_8    product_ub_112  -4.1857683874867449e-02
    x_19_8    onehot_19_113  1
    x_19_8    stock_lb_254  8
    x_19_8    stock_ub_255  8
    x_19_8    parent_nonstrict_scope_256  0.024
    x_19_8    unique_nonzero_owner_362  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_8    product_lb_111  1
    w_19_8    product_ub_112  1
    w_19_8    normalized_mass_19_114  1
    w_19_8    normalized_ratio_19_115  -2
    w_19_8    full_original_Gini_314  -3.0109523809523807e+01
    rho_19    normalized_ratio_19_115  1
    rho_19    block_pair_pos_263  1
    rho_19    block_pair_neg_264  -1
    rho_19    block_pair_pos_281  1
    rho_19    block_pair_neg_282  -1
    rho_19    block_pair_pos_293  -1
    rho_19    block_pair_neg_294  1
    rho_19    block_pair_pos_295  -1
    rho_19    block_pair_neg_296  1
    rho_19    block_pair_pos_297  -1
    rho_19    block_pair_neg_298  1
    rho_19    block_pair_pos_299  -1
    rho_19    block_pair_neg_300  1
    rho_19    block_pair_pos_307  1
    rho_19    block_pair_neg_308  -1
    rho_19    normalization_313  1
    MARKER    'MARKER'                 'INTORG'
    x_16_0    OBJ       0.027
    x_16_0    product_lb_116  -2.4792168822839088e-02
    x_16_0    product_ub_117  -4.1857683874867449e-02
    x_16_0    onehot_16_142  1
    x_16_0    parent_nonstrict_scope_256  0.054
    x_16_0    unique_nonzero_owner_363  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_0    product_lb_116  1
    w_16_0    product_ub_117  1
    w_16_0    normalized_mass_16_143  1
    w_16_0    full_original_Gini_314  -2.3890476190476196e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_1    OBJ       0.018
    x_16_1    product_lb_118  -2.4792168822839088e-02
    x_16_1    product_ub_119  -4.1857683874867449e-02
    x_16_1    onehot_16_142  1
    x_16_1    stock_lb_254  1
    x_16_1    stock_ub_255  1
    x_16_1    parent_nonstrict_scope_256  0.045
    MARKER    'MARKER'                 'INTEND'
    w_16_1    product_lb_118  1
    w_16_1    product_ub_119  1
    w_16_1    normalized_mass_16_143  1
    w_16_1    normalized_ratio_16_144  -1.6666666666666666e-01
    w_16_1    full_original_Gini_314  -1.9390476190476189e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_2    OBJ       9.0000000000000045e-03
    x_16_2    product_lb_120  -2.4792168822839088e-02
    x_16_2    product_ub_121  -4.1857683874867449e-02
    x_16_2    onehot_16_142  1
    x_16_2    stock_lb_254  2
    x_16_2    stock_ub_255  2
    x_16_2    parent_nonstrict_scope_256  3.6000000000000004e-02
    x_16_2    unique_nonzero_owner_364  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_2    product_lb_120  1
    w_16_2    product_ub_121  1
    w_16_2    normalized_mass_16_143  1
    w_16_2    normalized_ratio_16_144  -3.3333333333333331e-01
    w_16_2    full_original_Gini_314  -1.4890476190476189e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_3    product_lb_122  -2.4792168822839088e-02
    x_16_3    product_ub_123  -4.1857683874867449e-02
    x_16_3    onehot_16_142  1
    x_16_3    stock_lb_254  3
    x_16_3    stock_ub_255  3
    x_16_3    parent_nonstrict_scope_256  0.027
    x_16_3    unique_nonzero_owner_365  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_3    product_lb_122  1
    w_16_3    product_ub_123  1
    w_16_3    normalized_mass_16_143  1
    w_16_3    normalized_ratio_16_144  -0.5
    w_16_3    full_original_Gini_314  -1.0390476190476189e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_4    OBJ       -8.9999999999999976e-03
    x_16_4    product_lb_124  -2.4792168822839088e-02
    x_16_4    product_ub_125  -4.1857683874867449e-02
    x_16_4    onehot_16_142  1
    x_16_4    stock_lb_254  4
    x_16_4    stock_ub_255  4
    x_16_4    parent_nonstrict_scope_256  1.8000000000000002e-02
    x_16_4    unique_nonzero_owner_366  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_4    product_lb_124  1
    w_16_4    product_ub_125  1
    w_16_4    normalized_mass_16_143  1
    w_16_4    normalized_ratio_16_144  -6.6666666666666663e-01
    w_16_4    full_original_Gini_314  -6.49047619047619
    MARKER    'MARKER'                 'INTORG'
    x_16_5    OBJ       -1.7999999999999995e-02
    x_16_5    product_lb_126  -2.4792168822839088e-02
    x_16_5    product_ub_127  -4.1857683874867449e-02
    x_16_5    onehot_16_142  1
    x_16_5    stock_lb_254  5
    x_16_5    stock_ub_255  5
    x_16_5    parent_nonstrict_scope_256  9.0000000000000045e-03
    x_16_5    unique_nonzero_owner_367  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_5    product_lb_126  1
    w_16_5    product_ub_127  1
    w_16_5    normalized_mass_16_143  1
    w_16_5    normalized_ratio_16_144  -8.3333333333333326e-01
    w_16_5    full_original_Gini_314  -4.2714285714285731e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_6    OBJ       -0.027
    x_16_6    product_lb_128  -2.4792168822839088e-02
    x_16_6    product_ub_129  -4.1857683874867449e-02
    x_16_6    onehot_16_142  1
    x_16_6    stock_lb_254  6
    x_16_6    stock_ub_255  6
    x_16_6    unique_nonzero_owner_368  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_6    product_lb_128  1
    w_16_6    product_ub_129  1
    w_16_6    normalized_mass_16_143  1
    w_16_6    normalized_ratio_16_144  -1
    w_16_6    full_original_Gini_314  -4.0095238095238095e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_7    OBJ       -1.8000000000000009e-02
    x_16_7    product_lb_130  -2.4792168822839088e-02
    x_16_7    product_ub_131  -4.1857683874867449e-02
    x_16_7    onehot_16_142  1
    x_16_7    stock_lb_254  7
    x_16_7    stock_ub_255  7
    x_16_7    parent_nonstrict_scope_256  8.9999999999999924e-03
    x_16_7    unique_nonzero_owner_369  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_7    product_lb_130  1
    w_16_7    product_ub_131  1
    w_16_7    normalized_mass_16_143  1
    w_16_7    normalized_ratio_16_144  -1.1666666666666665e+00
    w_16_7    full_original_Gini_314  -7.8428571428571381e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_8    OBJ       -9.0000000000000045e-03
    x_16_8    product_lb_132  -2.4792168822839088e-02
    x_16_8    product_ub_133  -4.1857683874867449e-02
    x_16_8    onehot_16_142  1
    x_16_8    stock_lb_254  8
    x_16_8    stock_ub_255  8
    x_16_8    parent_nonstrict_scope_256  1.7999999999999995e-02
    x_16_8    unique_nonzero_owner_370  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_8    product_lb_132  1
    w_16_8    product_ub_133  1
    w_16_8    normalized_mass_16_143  1
    w_16_8    normalized_ratio_16_144  -1.3333333333333333e+00
    w_16_8    full_original_Gini_314  -1.2109523809523809e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_9    product_lb_134  -2.4792168822839088e-02
    x_16_9    product_ub_135  -4.1857683874867449e-02
    x_16_9    onehot_16_142  1
    x_16_9    stock_lb_254  9
    x_16_9    stock_ub_255  9
    x_16_9    parent_nonstrict_scope_256  0.027
    x_16_9    unique_nonzero_owner_371  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_9    product_lb_134  1
    w_16_9    product_ub_135  1
    w_16_9    normalized_mass_16_143  1
    w_16_9    normalized_ratio_16_144  -1.5
    w_16_9    full_original_Gini_314  -1.6609523809523807e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_10   OBJ       0.00899999999999999
    x_16_10   product_lb_136  -2.4792168822839088e-02
    x_16_10   product_ub_137  -4.1857683874867449e-02
    x_16_10   onehot_16_142  1
    x_16_10   stock_lb_254  10
    x_16_10   stock_ub_255  10
    x_16_10   parent_nonstrict_scope_256  3.5999999999999990e-02
    x_16_10   unique_nonzero_owner_372  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_10   product_lb_136  1
    w_16_10   product_ub_137  1
    w_16_10   normalized_mass_16_143  1
    w_16_10   normalized_ratio_16_144  -1.6666666666666665e+00
    w_16_10   full_original_Gini_314  -2.1109523809523811e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_11   OBJ       0.018
    x_16_11   product_lb_138  -2.4792168822839088e-02
    x_16_11   product_ub_139  -4.1857683874867449e-02
    x_16_11   onehot_16_142  1
    x_16_11   stock_lb_254  11
    x_16_11   stock_ub_255  11
    x_16_11   parent_nonstrict_scope_256  0.045
    x_16_11   unique_nonzero_owner_373  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_11   product_lb_138  1
    w_16_11   product_ub_139  1
    w_16_11   normalized_mass_16_143  1
    w_16_11   normalized_ratio_16_144  -1.8333333333333333e+00
    w_16_11   full_original_Gini_314  -2.5609523809523807e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_12   OBJ       0.027
    x_16_12   product_lb_140  -2.4792168822839088e-02
    x_16_12   product_ub_141  -4.1857683874867449e-02
    x_16_12   onehot_16_142  1
    x_16_12   stock_lb_254  12
    x_16_12   stock_ub_255  12
    x_16_12   parent_nonstrict_scope_256  0.054
    x_16_12   unique_nonzero_owner_374  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_12   product_lb_140  1
    w_16_12   product_ub_141  1
    w_16_12   normalized_mass_16_143  1
    w_16_12   normalized_ratio_16_144  -2
    w_16_12   full_original_Gini_314  -3.0109523809523807e+01
    rho_16    normalized_ratio_16_144  1
    rho_16    block_pair_pos_259  1
    rho_16    block_pair_neg_260  -1
    rho_16    block_pair_pos_277  1
    rho_16    block_pair_neg_278  -1
    rho_16    block_pair_pos_287  -1
    rho_16    block_pair_neg_288  1
    rho_16    block_pair_pos_289  -1
    rho_16    block_pair_neg_290  1
    rho_16    block_pair_pos_291  -1
    rho_16    block_pair_neg_292  1
    rho_16    block_pair_pos_295  1
    rho_16    block_pair_neg_296  -1
    rho_16    block_pair_pos_303  1
    rho_16    block_pair_neg_304  -1
    rho_16    normalization_313  1
    MARKER    'MARKER'                 'INTORG'
    x_13_0    OBJ       0.03
    x_13_0    product_lb_145  -2.4792168822839088e-02
    x_13_0    product_ub_146  -4.1857683874867449e-02
    x_13_0    onehot_13_185  1
    x_13_0    parent_nonstrict_scope_256  0.096
    x_13_0    unique_nonzero_owner_375  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_0    product_lb_145  1
    w_13_0    product_ub_146  1
    w_13_0    normalized_mass_13_186  1
    w_13_0    full_original_Gini_314  -2.3890476190476196e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_1    OBJ       1.8000000000000002e-02
    x_13_1    product_lb_147  -2.4792168822839088e-02
    x_13_1    product_ub_148  -4.1857683874867449e-02
    x_13_1    onehot_13_185  1
    x_13_1    stock_lb_254  1
    x_13_1    stock_ub_255  1
    x_13_1    parent_nonstrict_scope_256  0.084
    x_13_1    unique_nonzero_owner_376  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_1    product_lb_147  1
    w_13_1    product_ub_148  1
    w_13_1    normalized_mass_13_186  1
    w_13_1    normalized_ratio_13_187  -0.125
    w_13_1    full_original_Gini_314  -2.0515476190476193e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_2    OBJ       6.0000000000000053e-03
    x_13_2    product_lb_149  -2.4792168822839088e-02
    x_13_2    product_ub_150  -4.1857683874867449e-02
    x_13_2    onehot_13_185  1
    x_13_2    stock_lb_254  2
    x_13_2    stock_ub_255  2
    x_13_2    parent_nonstrict_scope_256  7.2000000000000008e-02
    x_13_2    unique_nonzero_owner_377  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_2    product_lb_149  1
    w_13_2    product_ub_150  1
    w_13_2    normalized_mass_13_186  1
    w_13_2    normalized_ratio_13_187  -0.25
    w_13_2    full_original_Gini_314  -1.7140476190476193e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_3    OBJ       -6.0000000000000053e-03
    x_13_3    product_lb_151  -2.4792168822839088e-02
    x_13_3    product_ub_152  -4.1857683874867449e-02
    x_13_3    onehot_13_185  1
    x_13_3    stock_lb_254  3
    x_13_3    stock_ub_255  3
    x_13_3    parent_nonstrict_scope_256  0.06
    x_13_3    unique_nonzero_owner_378  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_3    product_lb_151  1
    w_13_3    product_ub_152  1
    w_13_3    normalized_mass_13_186  1
    w_13_3    normalized_ratio_13_187  -0.375
    w_13_3    full_original_Gini_314  -1.3765476190476189e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_4    OBJ       -1.8000000000000002e-02
    x_13_4    product_lb_153  -2.4792168822839088e-02
    x_13_4    product_ub_154  -4.1857683874867449e-02
    x_13_4    onehot_13_185  1
    x_13_4    stock_lb_254  4
    x_13_4    stock_ub_255  4
    x_13_4    parent_nonstrict_scope_256  0.048
    x_13_4    unique_nonzero_owner_379  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_4    product_lb_153  1
    w_13_4    product_ub_154  1
    w_13_4    normalized_mass_13_186  1
    w_13_4    normalized_ratio_13_187  -0.5
    w_13_4    full_original_Gini_314  -1.0390476190476189e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_5    OBJ       -0.03
    x_13_5    product_lb_155  -2.4792168822839088e-02
    x_13_5    product_ub_156  -4.1857683874867449e-02
    x_13_5    onehot_13_185  1
    x_13_5    stock_lb_254  5
    x_13_5    stock_ub_255  5
    x_13_5    parent_nonstrict_scope_256  3.6000000000000004e-02
    x_13_5    unique_nonzero_owner_380  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_5    product_lb_155  1
    w_13_5    product_ub_156  1
    w_13_5    normalized_mass_13_186  1
    w_13_5    normalized_ratio_13_187  -0.625
    w_13_5    full_original_Gini_314  -7.3654761904761905e+00
    MARKER    'MARKER'                 'INTORG'
    x_13_6    OBJ       -0.042
    x_13_6    product_lb_157  -2.4792168822839088e-02
    x_13_6    product_ub_158  -4.1857683874867449e-02
    x_13_6    onehot_13_185  1
    x_13_6    stock_lb_254  6
    x_13_6    stock_ub_255  6
    x_13_6    parent_nonstrict_scope_256  0.024
    x_13_6    unique_nonzero_owner_381  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_6    product_lb_157  1
    w_13_6    product_ub_158  1
    w_13_6    normalized_mass_13_186  1
    w_13_6    normalized_ratio_13_187  -0.75
    w_13_6    full_original_Gini_314  -4.9547619047619040e+00
    MARKER    'MARKER'                 'INTORG'
    x_13_7    OBJ       -5.4000000000000006e-02
    x_13_7    product_lb_159  -2.4792168822839088e-02
    x_13_7    product_ub_160  -4.1857683874867449e-02
    x_13_7    onehot_13_185  1
    x_13_7    stock_lb_254  7
    x_13_7    stock_ub_255  7
    x_13_7    parent_nonstrict_scope_256  0.012
    x_13_7    unique_nonzero_owner_382  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_7    product_lb_159  1
    w_13_7    product_ub_160  1
    w_13_7    normalized_mass_13_186  1
    w_13_7    normalized_ratio_13_187  -0.875
    w_13_7    full_original_Gini_314  -4.1345238095238095e+00
    MARKER    'MARKER'                 'INTORG'
    x_13_8    OBJ       -0.066
    x_13_8    product_lb_161  -2.4792168822839088e-02
    x_13_8    product_ub_162  -4.1857683874867449e-02
    x_13_8    onehot_13_185  1
    x_13_8    stock_lb_254  8
    x_13_8    stock_ub_255  8
    x_13_8    unique_nonzero_owner_383  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_8    product_lb_161  1
    w_13_8    product_ub_162  1
    w_13_8    normalized_mass_13_186  1
    w_13_8    normalized_ratio_13_187  -1
    w_13_8    full_original_Gini_314  -4.0095238095238095e+00
    MARKER    'MARKER'                 'INTORG'
    x_13_9    OBJ       -5.4000000000000006e-02
    x_13_9    product_lb_163  -2.4792168822839088e-02
    x_13_9    product_ub_164  -4.1857683874867449e-02
    x_13_9    onehot_13_185  1
    x_13_9    stock_lb_254  9
    x_13_9    stock_ub_255  9
    x_13_9    parent_nonstrict_scope_256  0.012
    x_13_9    unique_nonzero_owner_384  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_9    product_lb_163  1
    w_13_9    product_ub_164  1
    w_13_9    normalized_mass_13_186  1
    w_13_9    normalized_ratio_13_187  -1.125
    w_13_9    full_original_Gini_314  -6.8845238095238095e+00
    MARKER    'MARKER'                 'INTORG'
    x_13_10   OBJ       -0.042
    x_13_10   product_lb_165  -2.4792168822839088e-02
    x_13_10   product_ub_166  -4.1857683874867449e-02
    x_13_10   onehot_13_185  1
    x_13_10   stock_lb_254  10
    x_13_10   stock_ub_255  10
    x_13_10   parent_nonstrict_scope_256  0.024
    x_13_10   unique_nonzero_owner_385  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_10   product_lb_165  1
    w_13_10   product_ub_166  1
    w_13_10   normalized_mass_13_186  1
    w_13_10   normalized_ratio_13_187  -1.25
    w_13_10   full_original_Gini_314  -9.8595238095238109e+00
    MARKER    'MARKER'                 'INTORG'
    x_13_11   OBJ       -0.03
    x_13_11   product_lb_167  -2.4792168822839088e-02
    x_13_11   product_ub_168  -4.1857683874867449e-02
    x_13_11   onehot_13_185  1
    x_13_11   stock_lb_254  11
    x_13_11   stock_ub_255  11
    x_13_11   parent_nonstrict_scope_256  3.6000000000000004e-02
    x_13_11   unique_nonzero_owner_386  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_11   product_lb_167  1
    w_13_11   product_ub_168  1
    w_13_11   normalized_mass_13_186  1
    w_13_11   normalized_ratio_13_187  -1.375
    w_13_11   full_original_Gini_314  -1.3234523809523809e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_12   OBJ       -1.8000000000000002e-02
    x_13_12   product_lb_169  -2.4792168822839088e-02
    x_13_12   product_ub_170  -4.1857683874867449e-02
    x_13_12   onehot_13_185  1
    x_13_12   stock_lb_254  12
    x_13_12   stock_ub_255  12
    x_13_12   parent_nonstrict_scope_256  0.048
    x_13_12   unique_nonzero_owner_387  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_12   product_lb_169  1
    w_13_12   product_ub_170  1
    w_13_12   normalized_mass_13_186  1
    w_13_12   normalized_ratio_13_187  -1.5
    w_13_12   full_original_Gini_314  -1.6609523809523807e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_13   OBJ       -6.0000000000000053e-03
    x_13_13   product_lb_171  -2.4792168822839088e-02
    x_13_13   product_ub_172  -4.1857683874867449e-02
    x_13_13   onehot_13_185  1
    x_13_13   stock_lb_254  13
    x_13_13   stock_ub_255  13
    x_13_13   parent_nonstrict_scope_256  0.06
    MARKER    'MARKER'                 'INTEND'
    w_13_13   product_lb_171  1
    w_13_13   product_ub_172  1
    w_13_13   normalized_mass_13_186  1
    w_13_13   normalized_ratio_13_187  -1.625
    w_13_13   full_original_Gini_314  -1.9984523809523807e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_14   OBJ       6.0000000000000053e-03
    x_13_14   product_lb_173  -2.4792168822839088e-02
    x_13_14   product_ub_174  -4.1857683874867449e-02
    x_13_14   onehot_13_185  1
    x_13_14   stock_lb_254  14
    x_13_14   stock_ub_255  14
    x_13_14   parent_nonstrict_scope_256  7.2000000000000008e-02
    x_13_14   unique_nonzero_owner_388  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_14   product_lb_173  1
    w_13_14   product_ub_174  1
    w_13_14   normalized_mass_13_186  1
    w_13_14   normalized_ratio_13_187  -1.75
    w_13_14   full_original_Gini_314  -2.3359523809523804e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_15   OBJ       1.8000000000000002e-02
    x_13_15   product_lb_175  -2.4792168822839088e-02
    x_13_15   product_ub_176  -4.1857683874867449e-02
    x_13_15   onehot_13_185  1
    x_13_15   stock_lb_254  15
    x_13_15   stock_ub_255  15
    x_13_15   parent_nonstrict_scope_256  0.084
    x_13_15   unique_nonzero_owner_389  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_15   product_lb_175  1
    w_13_15   product_ub_176  1
    w_13_15   normalized_mass_13_186  1
    w_13_15   normalized_ratio_13_187  -1.875
    w_13_15   full_original_Gini_314  -2.6734523809523807e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_16   OBJ       0.03
    x_13_16   product_lb_177  -2.4792168822839088e-02
    x_13_16   product_ub_178  -4.1857683874867449e-02
    x_13_16   onehot_13_185  1
    x_13_16   stock_lb_254  16
    x_13_16   stock_ub_255  16
    x_13_16   parent_nonstrict_scope_256  0.096
    x_13_16   unique_nonzero_owner_390  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_16   product_lb_177  1
    w_13_16   product_ub_178  1
    w_13_16   normalized_mass_13_186  1
    w_13_16   normalized_ratio_13_187  -2
    w_13_16   full_original_Gini_314  -3.0109523809523807e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_17   OBJ       4.1999999999999996e-02
    x_13_17   product_lb_179  -2.4792168822839088e-02
    x_13_17   product_ub_180  -4.1857683874867449e-02
    x_13_17   onehot_13_185  1
    x_13_17   stock_lb_254  17
    x_13_17   stock_ub_255  17
    x_13_17   parent_nonstrict_scope_256  0.108
    x_13_17   unique_nonzero_owner_391  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_17   product_lb_179  1
    w_13_17   product_ub_180  1
    w_13_17   normalized_mass_13_186  1
    w_13_17   normalized_ratio_13_187  -2.125
    w_13_17   full_original_Gini_314  -3.3484523809523807e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_18   OBJ       5.3999999999999992e-02
    x_13_18   product_lb_181  -2.4792168822839088e-02
    x_13_18   product_ub_182  -4.1857683874867449e-02
    x_13_18   onehot_13_185  1
    x_13_18   stock_lb_254  18
    x_13_18   stock_ub_255  18
    x_13_18   parent_nonstrict_scope_256  0.12
    x_13_18   unique_nonzero_owner_392  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_18   product_lb_181  1
    w_13_18   product_ub_182  1
    w_13_18   normalized_mass_13_186  1
    w_13_18   normalized_ratio_13_187  -2.25
    w_13_18   full_original_Gini_314  -3.6859523809523807e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_19   OBJ       0.066
    x_13_19   product_lb_183  -2.4792168822839088e-02
    x_13_19   product_ub_184  -4.1857683874867449e-02
    x_13_19   onehot_13_185  1
    x_13_19   stock_lb_254  19
    x_13_19   stock_ub_255  19
    x_13_19   parent_nonstrict_scope_256  0.132
    x_13_19   unique_nonzero_owner_393  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_19   product_lb_183  1
    w_13_19   product_ub_184  1
    w_13_19   normalized_mass_13_186  1
    w_13_19   normalized_ratio_13_187  -2.375
    w_13_19   full_original_Gini_314  -4.0234523809523807e+01
    rho_13    normalized_ratio_13_187  1
    rho_13    block_pair_pos_257  1
    rho_13    block_pair_neg_258  -1
    rho_13    block_pair_pos_269  -1
    rho_13    block_pair_neg_270  1
    rho_13    block_pair_pos_271  -1
    rho_13    block_pair_neg_272  1
    rho_13    block_pair_pos_275  1
    rho_13    block_pair_neg_276  -1
    rho_13    block_pair_pos_287  1
    rho_13    block_pair_neg_288  -1
    rho_13    block_pair_pos_293  1
    rho_13    block_pair_neg_294  -1
    rho_13    block_pair_pos_301  1
    rho_13    block_pair_neg_302  -1
    rho_13    normalization_313  1
    MARKER    'MARKER'                 'INTORG'
    x_32_0    OBJ       1.1249999999999993e-02
    x_32_0    product_lb_188  -2.4792168822839088e-02
    x_32_0    product_ub_189  -4.1857683874867449e-02
    x_32_0    onehot_32_214  1
    x_32_0    parent_nonstrict_scope_256  0.0375
    MARKER    'MARKER'                 'INTEND'
    w_32_0    product_lb_188  1
    w_32_0    product_ub_189  1
    w_32_0    normalized_mass_32_215  1
    w_32_0    full_original_Gini_314  -2.3890476190476196e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_1    OBJ       3.7499999999999929e-03
    x_32_1    product_lb_190  -2.4792168822839088e-02
    x_32_1    product_ub_191  -4.1857683874867449e-02
    x_32_1    onehot_32_214  1
    x_32_1    stock_lb_254  1
    x_32_1    stock_ub_255  1
    x_32_1    parent_nonstrict_scope_256  0.03
    x_32_1    unique_nonzero_owner_394  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_1    product_lb_190  1
    w_32_1    product_ub_191  1
    w_32_1    normalized_mass_32_215  1
    w_32_1    normalized_ratio_32_216  -0.2
    w_32_1    full_original_Gini_314  -1.8490476190476191e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_2    OBJ       -3.7500000000000068e-03
    x_32_2    product_lb_192  -2.4792168822839088e-02
    x_32_2    product_ub_193  -4.1857683874867449e-02
    x_32_2    onehot_32_214  1
    x_32_2    stock_lb_254  2
    x_32_2    stock_ub_255  2
    x_32_2    parent_nonstrict_scope_256  0.0225
    x_32_2    unique_nonzero_owner_395  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_2    product_lb_192  1
    w_32_2    product_ub_193  1
    w_32_2    normalized_mass_32_215  1
    w_32_2    normalized_ratio_32_216  -0.4
    w_32_2    full_original_Gini_314  -1.3090476190476188e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_3    OBJ       -1.1250000000000010e-02
    x_32_3    product_lb_194  -2.4792168822839088e-02
    x_32_3    product_ub_195  -4.1857683874867449e-02
    x_32_3    onehot_32_214  1
    x_32_3    stock_lb_254  3
    x_32_3    stock_ub_255  3
    x_32_3    parent_nonstrict_scope_256  1.4999999999999996e-02
    x_32_3    unique_nonzero_owner_396  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_3    product_lb_194  1
    w_32_3    product_ub_195  1
    w_32_3    normalized_mass_32_215  1
    w_32_3    normalized_ratio_32_216  -6.0000000000000009e-01
    w_32_3    full_original_Gini_314  -7.8904761904761909e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_4    OBJ       -1.8750000000000010e-02
    x_32_4    product_lb_196  -2.4792168822839088e-02
    x_32_4    product_ub_197  -4.1857683874867449e-02
    x_32_4    onehot_32_214  1
    x_32_4    stock_lb_254  4
    x_32_4    stock_ub_255  4
    x_32_4    parent_nonstrict_scope_256  7.4999999999999980e-03
    x_32_4    unique_nonzero_owner_397  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_4    product_lb_196  1
    w_32_4    product_ub_197  1
    w_32_4    normalized_mass_32_215  1
    w_32_4    normalized_ratio_32_216  -0.8
    w_32_4    full_original_Gini_314  -4.5047619047619065e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_5    OBJ       -2.6250000000000006e-02
    x_32_5    product_lb_198  -2.4792168822839088e-02
    x_32_5    product_ub_199  -4.1857683874867449e-02
    x_32_5    onehot_32_214  1
    x_32_5    stock_lb_254  5
    x_32_5    stock_ub_255  5
    x_32_5    unique_nonzero_owner_398  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_5    product_lb_198  1
    w_32_5    product_ub_199  1
    w_32_5    normalized_mass_32_215  1
    w_32_5    normalized_ratio_32_216  -1
    w_32_5    full_original_Gini_314  -4.0095238095238095e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_6    OBJ       -0.01875
    x_32_6    product_lb_200  -2.4792168822839088e-02
    x_32_6    product_ub_201  -4.1857683874867449e-02
    x_32_6    onehot_32_214  1
    x_32_6    stock_lb_254  6
    x_32_6    stock_ub_255  6
    x_32_6    parent_nonstrict_scope_256  7.5000000000000067e-03
    x_32_6    unique_nonzero_owner_399  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_6    product_lb_200  1
    w_32_6    product_ub_201  1
    w_32_6    normalized_mass_32_215  1
    w_32_6    normalized_ratio_32_216  -1.2000000000000002e+00
    w_32_6    full_original_Gini_314  -8.6095238095238145e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_7    OBJ       -1.1250000000000001e-02
    x_32_7    product_lb_202  -2.4792168822839088e-02
    x_32_7    product_ub_203  -4.1857683874867449e-02
    x_32_7    onehot_32_214  1
    x_32_7    stock_lb_254  7
    x_32_7    stock_ub_255  7
    x_32_7    parent_nonstrict_scope_256  1.5000000000000005e-02
    x_32_7    unique_nonzero_owner_400  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_7    product_lb_202  1
    w_32_7    product_ub_203  1
    w_32_7    normalized_mass_32_215  1
    w_32_7    normalized_ratio_32_216  -1.4000000000000001e+00
    w_32_7    full_original_Gini_314  -1.3909523809523817e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_8    OBJ       -3.7500000000000033e-03
    x_32_8    product_lb_204  -2.4792168822839088e-02
    x_32_8    product_ub_205  -4.1857683874867449e-02
    x_32_8    onehot_32_214  1
    x_32_8    stock_lb_254  8
    x_32_8    stock_ub_255  8
    x_32_8    parent_nonstrict_scope_256  2.2500000000000003e-02
    x_32_8    unique_nonzero_owner_401  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_8    product_lb_204  1
    w_32_8    product_ub_205  1
    w_32_8    normalized_mass_32_215  1
    w_32_8    normalized_ratio_32_216  -1.6
    w_32_8    full_original_Gini_314  -1.9309523809523810e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_9    OBJ       3.7499999999999929e-03
    x_32_9    product_lb_206  -2.4792168822839088e-02
    x_32_9    product_ub_207  -4.1857683874867449e-02
    x_32_9    onehot_32_214  1
    x_32_9    stock_lb_254  9
    x_32_9    stock_ub_255  9
    x_32_9    parent_nonstrict_scope_256  0.03
    x_32_9    unique_nonzero_owner_402  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_9    product_lb_206  1
    w_32_9    product_ub_207  1
    w_32_9    normalized_mass_32_215  1
    w_32_9    normalized_ratio_32_216  -1.8
    w_32_9    full_original_Gini_314  -2.4709523809523816e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_10   OBJ       1.1249999999999993e-02
    x_32_10   product_lb_208  -2.4792168822839088e-02
    x_32_10   product_ub_209  -4.1857683874867449e-02
    x_32_10   onehot_32_214  1
    x_32_10   stock_lb_254  10
    x_32_10   stock_ub_255  10
    x_32_10   parent_nonstrict_scope_256  0.0375
    x_32_10   unique_nonzero_owner_403  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_10   product_lb_208  1
    w_32_10   product_ub_209  1
    w_32_10   normalized_mass_32_215  1
    w_32_10   normalized_ratio_32_216  -2
    w_32_10   full_original_Gini_314  -3.0109523809523807e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_11   OBJ       0.01875
    x_32_11   product_lb_210  -2.4792168822839088e-02
    x_32_11   product_ub_211  -4.1857683874867449e-02
    x_32_11   onehot_32_214  1
    x_32_11   stock_lb_254  11
    x_32_11   stock_ub_255  11
    x_32_11   parent_nonstrict_scope_256  4.5000000000000005e-02
    x_32_11   unique_nonzero_owner_404  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_11   product_lb_210  1
    w_32_11   product_ub_211  1
    w_32_11   normalized_mass_32_215  1
    w_32_11   normalized_ratio_32_216  -2.2
    w_32_11   full_original_Gini_314  -3.5509523809523806e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_12   OBJ       2.6250000000000006e-02
    x_32_12   product_lb_212  -2.4792168822839088e-02
    x_32_12   product_ub_213  -4.1857683874867449e-02
    x_32_12   onehot_32_214  1
    x_32_12   stock_lb_254  12
    x_32_12   stock_ub_255  12
    x_32_12   parent_nonstrict_scope_256  5.2500000000000012e-02
    x_32_12   unique_nonzero_owner_405  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_12   product_lb_212  1
    w_32_12   product_ub_213  1
    w_32_12   normalized_mass_32_215  1
    w_32_12   normalized_ratio_32_216  -2.4000000000000004e+00
    w_32_12   full_original_Gini_314  -40.9095238095238
    rho_32    normalized_ratio_32_216  1
    rho_32    block_pair_pos_267  1
    rho_32    block_pair_neg_268  -1
    rho_32    block_pair_pos_271  1
    rho_32    block_pair_neg_272  -1
    rho_32    block_pair_pos_285  1
    rho_32    block_pair_neg_286  -1
    rho_32    block_pair_pos_291  1
    rho_32    block_pair_neg_292  -1
    rho_32    block_pair_pos_299  1
    rho_32    block_pair_neg_300  -1
    rho_32    block_pair_pos_309  1
    rho_32    block_pair_neg_310  -1
    rho_32    block_pair_pos_311  -1
    rho_32    block_pair_neg_312  1
    rho_32    normalization_313  1
    MARKER    'MARKER'                 'INTORG'
    x_17_0    OBJ       0.06075
    x_17_0    product_lb_217  -2.4792168822839088e-02
    x_17_0    product_ub_218  -4.1857683874867449e-02
    x_17_0    onehot_17_251  1
    x_17_0    parent_nonstrict_scope_256  0.1215
    x_17_0    unique_nonzero_owner_406  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_0    product_lb_217  1
    w_17_0    product_ub_218  1
    w_17_0    normalized_mass_17_252  1
    w_17_0    full_original_Gini_314  -2.3890476190476196e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_1    OBJ       4.7249999999999986e-02
    x_17_1    product_lb_219  -2.4792168822839088e-02
    x_17_1    product_ub_220  -4.1857683874867449e-02
    x_17_1    onehot_17_251  1
    x_17_1    stock_lb_254  1
    x_17_1    stock_ub_255  1
    x_17_1    parent_nonstrict_scope_256  1.0799999999999998e-01
    x_17_1    unique_nonzero_owner_407  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_1    product_lb_219  1
    w_17_1    product_ub_220  1
    w_17_1    normalized_mass_17_252  1
    w_17_1    normalized_ratio_17_253  -1.1111111111111110e-01
    w_17_1    full_original_Gini_314  -2.0890476190476196e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_2    OBJ       0.03375
    x_17_2    product_lb_221  -2.4792168822839088e-02
    x_17_2    product_ub_222  -4.1857683874867449e-02
    x_17_2    onehot_17_251  1
    x_17_2    stock_lb_254  2
    x_17_2    stock_ub_255  2
    x_17_2    parent_nonstrict_scope_256  0.0945
    x_17_2    unique_nonzero_owner_408  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_2    product_lb_221  1
    w_17_2    product_ub_222  1
    w_17_2    normalized_mass_17_252  1
    w_17_2    normalized_ratio_17_253  -2.2222222222222221e-01
    w_17_2    full_original_Gini_314  -1.7890476190476193e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_3    OBJ       2.0250000000000004e-02
    x_17_3    product_lb_223  -2.4792168822839088e-02
    x_17_3    product_ub_224  -4.1857683874867449e-02
    x_17_3    onehot_17_251  1
    x_17_3    stock_lb_254  3
    x_17_3    stock_ub_255  3
    x_17_3    parent_nonstrict_scope_256  0.081
    MARKER    'MARKER'                 'INTEND'
    w_17_3    product_lb_223  1
    w_17_3    product_ub_224  1
    w_17_3    normalized_mass_17_252  1
    w_17_3    normalized_ratio_17_253  -3.3333333333333331e-01
    w_17_3    full_original_Gini_314  -1.4890476190476189e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_4    OBJ       6.7500000000000060e-03
    x_17_4    product_lb_225  -2.4792168822839088e-02
    x_17_4    product_ub_226  -4.1857683874867449e-02
    x_17_4    onehot_17_251  1
    x_17_4    stock_lb_254  4
    x_17_4    stock_ub_255  4
    x_17_4    parent_nonstrict_scope_256  0.0675
    x_17_4    unique_nonzero_owner_409  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_4    product_lb_225  1
    w_17_4    product_ub_226  1
    w_17_4    normalized_mass_17_252  1
    w_17_4    normalized_ratio_17_253  -4.4444444444444442e-01
    w_17_4    full_original_Gini_314  -1.1890476190476187e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_5    OBJ       -6.7500000000000060e-03
    x_17_5    product_lb_227  -2.4792168822839088e-02
    x_17_5    product_ub_228  -4.1857683874867449e-02
    x_17_5    onehot_17_251  1
    x_17_5    stock_lb_254  5
    x_17_5    stock_ub_255  5
    x_17_5    parent_nonstrict_scope_256  5.3999999999999992e-02
    x_17_5    unique_nonzero_owner_410  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_5    product_lb_227  1
    w_17_5    product_ub_228  1
    w_17_5    normalized_mass_17_252  1
    w_17_5    normalized_ratio_17_253  -5.5555555555555558e-01
    w_17_5    full_original_Gini_314  -9.0015873015873016e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_6    OBJ       -2.0249999999999997e-02
    x_17_6    product_lb_229  -2.4792168822839088e-02
    x_17_6    product_ub_230  -4.1857683874867449e-02
    x_17_6    onehot_17_251  1
    x_17_6    stock_lb_254  6
    x_17_6    stock_ub_255  6
    x_17_6    parent_nonstrict_scope_256  0.0405
    x_17_6    unique_nonzero_owner_411  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_6    product_lb_229  1
    w_17_6    product_ub_230  1
    w_17_6    normalized_mass_17_252  1
    w_17_6    normalized_ratio_17_253  -6.6666666666666663e-01
    w_17_6    full_original_Gini_314  -6.49047619047619
    MARKER    'MARKER'                 'INTORG'
    x_17_7    OBJ       -3.3749999999999988e-02
    x_17_7    product_lb_231  -2.4792168822839088e-02
    x_17_7    product_ub_232  -4.1857683874867449e-02
    x_17_7    onehot_17_251  1
    x_17_7    stock_lb_254  7
    x_17_7    stock_ub_255  7
    x_17_7    parent_nonstrict_scope_256  2.7000000000000010e-02
    x_17_7    unique_nonzero_owner_412  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_7    product_lb_231  1
    w_17_7    product_ub_232  1
    w_17_7    normalized_mass_17_252  1
    w_17_7    normalized_ratio_17_253  -7.7777777777777768e-01
    w_17_7    full_original_Gini_314  -4.7047619047619049e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_8    OBJ       -4.7249999999999993e-02
    x_17_8    product_lb_233  -2.4792168822839088e-02
    x_17_8    product_ub_234  -4.1857683874867449e-02
    x_17_8    onehot_17_251  1
    x_17_8    stock_lb_254  8
    x_17_8    stock_ub_255  8
    x_17_8    parent_nonstrict_scope_256  1.3500000000000005e-02
    x_17_8    unique_nonzero_owner_413  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_8    product_lb_233  1
    w_17_8    product_ub_234  1
    w_17_8    normalized_mass_17_252  1
    w_17_8    normalized_ratio_17_253  -8.8888888888888884e-01
    w_17_8    full_original_Gini_314  -4.12063492063492
    MARKER    'MARKER'                 'INTORG'
    x_17_9    OBJ       -0.06075
    x_17_9    product_lb_235  -2.4792168822839088e-02
    x_17_9    product_ub_236  -4.1857683874867449e-02
    x_17_9    onehot_17_251  1
    x_17_9    stock_lb_254  9
    x_17_9    stock_ub_255  9
    x_17_9    unique_nonzero_owner_414  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_9    product_lb_235  1
    w_17_9    product_ub_236  1
    w_17_9    normalized_mass_17_252  1
    w_17_9    normalized_ratio_17_253  -1
    w_17_9    full_original_Gini_314  -4.0095238095238095e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_10   OBJ       -4.7249999999999993e-02
    x_17_10   product_lb_237  -2.4792168822839088e-02
    x_17_10   product_ub_238  -4.1857683874867449e-02
    x_17_10   onehot_17_251  1
    x_17_10   stock_lb_254  10
    x_17_10   stock_ub_255  10
    x_17_10   parent_nonstrict_scope_256  1.3500000000000005e-02
    x_17_10   unique_nonzero_owner_415  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_10   product_lb_237  1
    w_17_10   product_ub_238  1
    w_17_10   normalized_mass_17_252  1
    w_17_10   normalized_ratio_17_253  -1.1111111111111112e+00
    w_17_10   full_original_Gini_314  -6.5650793650793648e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_11   OBJ       -3.3750000000000016e-02
    x_17_11   product_lb_239  -2.4792168822839088e-02
    x_17_11   product_ub_240  -4.1857683874867449e-02
    x_17_11   onehot_17_251  1
    x_17_11   stock_lb_254  11
    x_17_11   stock_ub_255  11
    x_17_11   parent_nonstrict_scope_256  2.6999999999999986e-02
    x_17_11   unique_nonzero_owner_416  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_11   product_lb_239  1
    w_17_11   product_ub_240  1
    w_17_11   normalized_mass_17_252  1
    w_17_11   normalized_ratio_17_253  -1.2222222222222221e+00
    w_17_11   full_original_Gini_314  -9.1650793650793627e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_12   OBJ       -2.0250000000000011e-02
    x_17_12   product_lb_241  -2.4792168822839088e-02
    x_17_12   product_ub_242  -4.1857683874867449e-02
    x_17_12   onehot_17_251  1
    x_17_12   stock_lb_254  12
    x_17_12   stock_ub_255  12
    x_17_12   parent_nonstrict_scope_256  4.0499999999999987e-02
    x_17_12   unique_nonzero_owner_417  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_12   product_lb_241  1
    w_17_12   product_ub_242  1
    w_17_12   normalized_mass_17_252  1
    w_17_12   normalized_ratio_17_253  -1.3333333333333333e+00
    w_17_12   full_original_Gini_314  -1.2109523809523809e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_13   OBJ       -6.7500000000000060e-03
    x_17_13   product_lb_243  -2.4792168822839088e-02
    x_17_13   product_ub_244  -4.1857683874867449e-02
    x_17_13   onehot_17_251  1
    x_17_13   stock_lb_254  13
    x_17_13   stock_ub_255  13
    x_17_13   parent_nonstrict_scope_256  5.3999999999999992e-02
    x_17_13   unique_nonzero_owner_418  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_13   product_lb_243  1
    w_17_13   product_ub_244  1
    w_17_13   normalized_mass_17_252  1
    w_17_13   normalized_ratio_17_253  -1.4444444444444444e+00
    w_17_13   full_original_Gini_314  -1.5109523809523809e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_14   OBJ       6.7499999999999782e-03
    x_17_14   product_lb_245  -2.4792168822839088e-02
    x_17_14   product_ub_246  -4.1857683874867449e-02
    x_17_14   onehot_17_251  1
    x_17_14   stock_lb_254  14
    x_17_14   stock_ub_255  14
    x_17_14   parent_nonstrict_scope_256  6.7499999999999977e-02
    x_17_14   unique_nonzero_owner_419  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_14   product_lb_245  1
    w_17_14   product_ub_246  1
    w_17_14   normalized_mass_17_252  1
    w_17_14   normalized_ratio_17_253  -1.5555555555555554e+00
    w_17_14   full_original_Gini_314  -1.8109523809523807e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_15   OBJ       2.0249999999999976e-02
    x_17_15   product_lb_247  -2.4792168822839088e-02
    x_17_15   product_ub_248  -4.1857683874867449e-02
    x_17_15   onehot_17_251  1
    x_17_15   stock_lb_254  15
    x_17_15   stock_ub_255  15
    x_17_15   parent_nonstrict_scope_256  8.0999999999999975e-02
    x_17_15   unique_nonzero_owner_420  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_15   product_lb_247  1
    w_17_15   product_ub_248  1
    w_17_15   normalized_mass_17_252  1
    w_17_15   normalized_ratio_17_253  -1.6666666666666665e+00
    w_17_15   full_original_Gini_314  -2.1109523809523811e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_16   OBJ       3.3749999999999988e-02
    x_17_16   product_lb_249  -2.4792168822839088e-02
    x_17_16   product_ub_250  -4.1857683874867449e-02
    x_17_16   onehot_17_251  1
    x_17_16   stock_lb_254  16
    x_17_16   stock_ub_255  16
    x_17_16   parent_nonstrict_scope_256  9.4499999999999987e-02
    x_17_16   unique_nonzero_owner_421  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_16   product_lb_249  1
    w_17_16   product_ub_250  1
    w_17_16   normalized_mass_17_252  1
    w_17_16   normalized_ratio_17_253  -1.7777777777777777e+00
    w_17_16   full_original_Gini_314  -2.4109523809523814e+01
    rho_17    normalized_ratio_17_253  1
    rho_17    block_pair_pos_261  1
    rho_17    block_pair_neg_262  -1
    rho_17    block_pair_pos_269  1
    rho_17    block_pair_neg_270  -1
    rho_17    block_pair_pos_279  1
    rho_17    block_pair_neg_280  -1
    rho_17    block_pair_pos_289  1
    rho_17    block_pair_neg_290  -1
    rho_17    block_pair_pos_297  1
    rho_17    block_pair_neg_298  -1
    rho_17    block_pair_pos_305  1
    rho_17    block_pair_neg_306  -1
    rho_17    block_pair_pos_311  1
    rho_17    block_pair_neg_312  -1
    rho_17    normalization_313  1
    a_15_9    block_pair_pos_273  1
    a_15_9    block_pair_neg_274  1
    a_15_9    full_original_Gini_314  -1
    a_15_31   block_pair_pos_283  1
    a_15_31   block_pair_neg_284  1
    a_15_31   full_original_Gini_314  -1
    a_15_19   block_pair_pos_281  1
    a_15_19   block_pair_neg_282  1
    a_15_19   full_original_Gini_314  -1
    a_15_16   block_pair_pos_277  1
    a_15_16   block_pair_neg_278  1
    a_15_16   full_original_Gini_314  -1
    a_15_13   block_pair_pos_275  1
    a_15_13   block_pair_neg_276  1
    a_15_13   full_original_Gini_314  -1
    a_15_32   block_pair_pos_285  1
    a_15_32   block_pair_neg_286  1
    a_15_32   full_original_Gini_314  -1
    a_15_17   block_pair_pos_279  1
    a_15_17   block_pair_neg_280  1
    a_15_17   full_original_Gini_314  -1
    a_9_31    block_pair_pos_265  1
    a_9_31    block_pair_neg_266  1
    a_9_31    full_original_Gini_314  -1
    a_9_19    block_pair_pos_263  1
    a_9_19    block_pair_neg_264  1
    a_9_19    full_original_Gini_314  -1
    a_9_16    block_pair_pos_259  1
    a_9_16    block_pair_neg_260  1
    a_9_16    full_original_Gini_314  -1
    a_9_13    block_pair_pos_257  1
    a_9_13    block_pair_neg_258  1
    a_9_13    full_original_Gini_314  -1
    a_9_32    block_pair_pos_267  1
    a_9_32    block_pair_neg_268  1
    a_9_32    full_original_Gini_314  -1
    a_9_17    block_pair_pos_261  1
    a_9_17    block_pair_neg_262  1
    a_9_17    full_original_Gini_314  -1
    a_31_19   block_pair_pos_307  1
    a_31_19   block_pair_neg_308  1
    a_31_19   full_original_Gini_314  -1
    a_31_16   block_pair_pos_303  1
    a_31_16   block_pair_neg_304  1
    a_31_16   full_original_Gini_314  -1
    a_31_13   block_pair_pos_301  1
    a_31_13   block_pair_neg_302  1
    a_31_13   full_original_Gini_314  -1
    a_31_32   block_pair_pos_309  1
    a_31_32   block_pair_neg_310  1
    a_31_32   full_original_Gini_314  -1
    a_31_17   block_pair_pos_305  1
    a_31_17   block_pair_neg_306  1
    a_31_17   full_original_Gini_314  -1
    a_19_16   block_pair_pos_295  1
    a_19_16   block_pair_neg_296  1
    a_19_16   full_original_Gini_314  -1
    a_19_13   block_pair_pos_293  1
    a_19_13   block_pair_neg_294  1
    a_19_13   full_original_Gini_314  -1
    a_19_32   block_pair_pos_299  1
    a_19_32   block_pair_neg_300  1
    a_19_32   full_original_Gini_314  -1
    a_19_17   block_pair_pos_297  1
    a_19_17   block_pair_neg_298  1
    a_19_17   full_original_Gini_314  -1
    a_16_13   block_pair_pos_287  1
    a_16_13   block_pair_neg_288  1
    a_16_13   full_original_Gini_314  -1
    a_16_32   block_pair_pos_291  1
    a_16_32   block_pair_neg_292  1
    a_16_32   full_original_Gini_314  -1
    a_16_17   block_pair_pos_289  1
    a_16_17   block_pair_neg_290  1
    a_16_17   full_original_Gini_314  -1
    a_13_32   block_pair_pos_271  1
    a_13_32   block_pair_neg_272  1
    a_13_32   full_original_Gini_314  -1
    a_13_17   block_pair_pos_269  1
    a_13_17   block_pair_neg_270  1
    a_13_17   full_original_Gini_314  -1
    a_32_17   block_pair_pos_311  1
    a_32_17   block_pair_neg_312  1
    a_32_17   full_original_Gini_314  -1
    MARKER    'MARKER'                 'INTORG'
    service_0_15_0  unique_nonzero_owner_315  1
    service_0_15_0  service_visit_def_745  1
    service_0_15_0  free_load_conservation_746  -3
    service_0_15_0  original_T_including_depot_unload_792  360
    service_0_15_1  unique_nonzero_owner_316  1
    service_0_15_1  service_visit_def_745  1
    service_0_15_1  free_load_conservation_746  -2
    service_0_15_1  original_T_including_depot_unload_792  240
    service_0_15_2  unique_nonzero_owner_317  1
    service_0_15_2  service_visit_def_745  1
    service_0_15_2  free_load_conservation_746  -1
    service_0_15_2  original_T_including_depot_unload_792  120
    service_0_15_4  unique_nonzero_owner_318  1
    service_0_15_4  service_visit_def_745  1
    service_0_15_4  free_load_conservation_746  1
    service_0_15_5  unique_nonzero_owner_319  1
    service_0_15_5  service_visit_def_745  1
    service_0_15_5  free_load_conservation_746  2
    service_0_15_6  unique_nonzero_owner_320  1
    service_0_15_6  service_visit_def_745  1
    service_0_15_6  free_load_conservation_746  3
    service_0_15_7  unique_nonzero_owner_321  1
    service_0_15_7  service_visit_def_745  1
    service_0_15_7  free_load_conservation_746  4
    service_0_15_8  unique_nonzero_owner_322  1
    service_0_15_8  service_visit_def_745  1
    service_0_15_8  free_load_conservation_746  5
    service_0_15_9  unique_nonzero_owner_323  1
    service_0_15_9  service_visit_def_745  1
    service_0_15_9  free_load_conservation_746  6
    service_0_15_10  unique_nonzero_owner_324  1
    service_0_15_10  service_visit_def_745  1
    service_0_15_10  free_load_conservation_746  7
    service_0_15_11  unique_nonzero_owner_325  1
    service_0_15_11  service_visit_def_745  1
    service_0_15_11  free_load_conservation_746  8
    service_0_15_12  unique_nonzero_owner_326  1
    service_0_15_12  service_visit_def_745  1
    service_0_15_12  free_load_conservation_746  9
    service_0_15_13  unique_nonzero_owner_327  1
    service_0_15_13  service_visit_def_745  1
    service_0_15_13  free_load_conservation_746  10
    service_0_15_14  unique_nonzero_owner_328  1
    service_0_15_14  service_visit_def_745  1
    service_0_15_14  free_load_conservation_746  11
    service_0_15_15  unique_nonzero_owner_329  1
    service_0_15_15  service_visit_def_745  1
    service_0_15_15  free_load_conservation_746  12
    service_0_15_16  unique_nonzero_owner_330  1
    service_0_15_16  service_visit_def_745  1
    service_0_15_16  free_load_conservation_746  13
    service_1_15_0  unique_nonzero_owner_315  1
    service_1_15_0  service_visit_def_1173  1
    service_1_15_0  free_load_conservation_1174  -3
    service_1_15_0  original_T_including_depot_unload_1221  360
    service_1_15_1  unique_nonzero_owner_316  1
    service_1_15_1  service_visit_def_1173  1
    service_1_15_1  free_load_conservation_1174  -2
    service_1_15_1  original_T_including_depot_unload_1221  240
    service_1_15_2  unique_nonzero_owner_317  1
    service_1_15_2  service_visit_def_1173  1
    service_1_15_2  free_load_conservation_1174  -1
    service_1_15_2  original_T_including_depot_unload_1221  120
    service_1_15_4  unique_nonzero_owner_318  1
    service_1_15_4  service_visit_def_1173  1
    service_1_15_4  free_load_conservation_1174  1
    service_1_15_5  unique_nonzero_owner_319  1
    service_1_15_5  service_visit_def_1173  1
    service_1_15_5  free_load_conservation_1174  2
    service_1_15_6  unique_nonzero_owner_320  1
    service_1_15_6  service_visit_def_1173  1
    service_1_15_6  free_load_conservation_1174  3
    service_1_15_7  unique_nonzero_owner_321  1
    service_1_15_7  service_visit_def_1173  1
    service_1_15_7  free_load_conservation_1174  4
    service_1_15_8  unique_nonzero_owner_322  1
    service_1_15_8  service_visit_def_1173  1
    service_1_15_8  free_load_conservation_1174  5
    service_1_15_9  unique_nonzero_owner_323  1
    service_1_15_9  service_visit_def_1173  1
    service_1_15_9  free_load_conservation_1174  6
    service_1_15_10  unique_nonzero_owner_324  1
    service_1_15_10  service_visit_def_1173  1
    service_1_15_10  free_load_conservation_1174  7
    service_1_15_11  unique_nonzero_owner_325  1
    service_1_15_11  service_visit_def_1173  1
    service_1_15_11  free_load_conservation_1174  8
    service_1_15_12  unique_nonzero_owner_326  1
    service_1_15_12  service_visit_def_1173  1
    service_1_15_12  free_load_conservation_1174  9
    service_1_15_13  unique_nonzero_owner_327  1
    service_1_15_13  service_visit_def_1173  1
    service_1_15_13  free_load_conservation_1174  10
    service_1_15_14  unique_nonzero_owner_328  1
    service_1_15_14  service_visit_def_1173  1
    service_1_15_14  free_load_conservation_1174  11
    service_1_15_15  unique_nonzero_owner_329  1
    service_1_15_15  service_visit_def_1173  1
    service_1_15_15  free_load_conservation_1174  12
    service_1_15_16  unique_nonzero_owner_330  1
    service_1_15_16  service_visit_def_1173  1
    service_1_15_16  free_load_conservation_1174  13
    service_2_15_0  unique_nonzero_owner_315  1
    service_2_15_0  service_visit_def_1545  1
    service_2_15_0  free_load_conservation_1546  -3
    service_2_15_0  original_T_including_depot_unload_1592  360
    service_2_15_1  unique_nonzero_owner_316  1
    service_2_15_1  service_visit_def_1545  1
    service_2_15_1  free_load_conservation_1546  -2
    service_2_15_1  original_T_including_depot_unload_1592  240
    service_2_15_2  unique_nonzero_owner_317  1
    service_2_15_2  service_visit_def_1545  1
    service_2_15_2  free_load_conservation_1546  -1
    service_2_15_2  original_T_including_depot_unload_1592  120
    service_2_15_4  unique_nonzero_owner_318  1
    service_2_15_4  service_visit_def_1545  1
    service_2_15_4  free_load_conservation_1546  1
    service_2_15_5  unique_nonzero_owner_319  1
    service_2_15_5  service_visit_def_1545  1
    service_2_15_5  free_load_conservation_1546  2
    service_2_15_6  unique_nonzero_owner_320  1
    service_2_15_6  service_visit_def_1545  1
    service_2_15_6  free_load_conservation_1546  3
    service_2_15_7  unique_nonzero_owner_321  1
    service_2_15_7  service_visit_def_1545  1
    service_2_15_7  free_load_conservation_1546  4
    service_2_15_8  unique_nonzero_owner_322  1
    service_2_15_8  service_visit_def_1545  1
    service_2_15_8  free_load_conservation_1546  5
    service_2_15_9  unique_nonzero_owner_323  1
    service_2_15_9  service_visit_def_1545  1
    service_2_15_9  free_load_conservation_1546  6
    service_2_15_10  unique_nonzero_owner_324  1
    service_2_15_10  service_visit_def_1545  1
    service_2_15_10  free_load_conservation_1546  7
    service_2_15_11  unique_nonzero_owner_325  1
    service_2_15_11  service_visit_def_1545  1
    service_2_15_11  free_load_conservation_1546  8
    service_2_15_12  unique_nonzero_owner_326  1
    service_2_15_12  service_visit_def_1545  1
    service_2_15_12  free_load_conservation_1546  9
    service_2_15_13  unique_nonzero_owner_327  1
    service_2_15_13  service_visit_def_1545  1
    service_2_15_13  free_load_conservation_1546  10
    service_2_15_14  unique_nonzero_owner_328  1
    service_2_15_14  service_visit_def_1545  1
    service_2_15_14  free_load_conservation_1546  11
    service_2_15_15  unique_nonzero_owner_329  1
    service_2_15_15  service_visit_def_1545  1
    service_2_15_15  free_load_conservation_1546  12
    service_2_15_16  unique_nonzero_owner_330  1
    service_2_15_16  service_visit_def_1545  1
    service_2_15_16  free_load_conservation_1546  13
    service_0_9_0  unique_nonzero_owner_331  1
    service_0_9_0  service_visit_def_751  1
    service_0_9_0  free_load_conservation_752  -8
    service_0_9_0  original_T_including_depot_unload_792  960
    service_0_9_1  unique_nonzero_owner_332  1
    service_0_9_1  service_visit_def_751  1
    service_0_9_1  free_load_conservation_752  -7
    service_0_9_1  original_T_including_depot_unload_792  840
    service_0_9_2  unique_nonzero_owner_333  1
    service_0_9_2  service_visit_def_751  1
    service_0_9_2  free_load_conservation_752  -6
    service_0_9_2  original_T_including_depot_unload_792  720
    service_0_9_3  unique_nonzero_owner_334  1
    service_0_9_3  service_visit_def_751  1
    service_0_9_3  free_load_conservation_752  -5
    service_0_9_3  original_T_including_depot_unload_792  600
    service_0_9_4  unique_nonzero_owner_335  1
    service_0_9_4  service_visit_def_751  1
    service_0_9_4  free_load_conservation_752  -4
    service_0_9_4  original_T_including_depot_unload_792  480
    service_0_9_5  unique_nonzero_owner_336  1
    service_0_9_5  service_visit_def_751  1
    service_0_9_5  free_load_conservation_752  -3
    service_0_9_5  original_T_including_depot_unload_792  360
    service_0_9_6  unique_nonzero_owner_337  1
    service_0_9_6  service_visit_def_751  1
    service_0_9_6  free_load_conservation_752  -2
    service_0_9_6  original_T_including_depot_unload_792  240
    service_0_9_7  unique_nonzero_owner_338  1
    service_0_9_7  service_visit_def_751  1
    service_0_9_7  free_load_conservation_752  -1
    service_0_9_7  original_T_including_depot_unload_792  120
    service_0_9_9  unique_nonzero_owner_339  1
    service_0_9_9  service_visit_def_751  1
    service_0_9_9  free_load_conservation_752  1
    service_0_9_10  unique_nonzero_owner_340  1
    service_0_9_10  service_visit_def_751  1
    service_0_9_10  free_load_conservation_752  2
    service_0_9_11  unique_nonzero_owner_341  1
    service_0_9_11  service_visit_def_751  1
    service_0_9_11  free_load_conservation_752  3
    service_0_9_12  unique_nonzero_owner_342  1
    service_0_9_12  service_visit_def_751  1
    service_0_9_12  free_load_conservation_752  4
    service_1_9_0  unique_nonzero_owner_331  1
    service_1_9_0  service_visit_def_1179  1
    service_1_9_0  free_load_conservation_1180  -8
    service_1_9_0  original_T_including_depot_unload_1221  960
    service_1_9_1  unique_nonzero_owner_332  1
    service_1_9_1  service_visit_def_1179  1
    service_1_9_1  free_load_conservation_1180  -7
    service_1_9_1  original_T_including_depot_unload_1221  840
    service_1_9_2  unique_nonzero_owner_333  1
    service_1_9_2  service_visit_def_1179  1
    service_1_9_2  free_load_conservation_1180  -6
    service_1_9_2  original_T_including_depot_unload_1221  720
    service_1_9_3  unique_nonzero_owner_334  1
    service_1_9_3  service_visit_def_1179  1
    service_1_9_3  free_load_conservation_1180  -5
    service_1_9_3  original_T_including_depot_unload_1221  600
    service_1_9_4  unique_nonzero_owner_335  1
    service_1_9_4  service_visit_def_1179  1
    service_1_9_4  free_load_conservation_1180  -4
    service_1_9_4  original_T_including_depot_unload_1221  480
    service_1_9_5  unique_nonzero_owner_336  1
    service_1_9_5  service_visit_def_1179  1
    service_1_9_5  free_load_conservation_1180  -3
    service_1_9_5  original_T_including_depot_unload_1221  360
    service_1_9_6  unique_nonzero_owner_337  1
    service_1_9_6  service_visit_def_1179  1
    service_1_9_6  free_load_conservation_1180  -2
    service_1_9_6  original_T_including_depot_unload_1221  240
    service_1_9_7  unique_nonzero_owner_338  1
    service_1_9_7  service_visit_def_1179  1
    service_1_9_7  free_load_conservation_1180  -1
    service_1_9_7  original_T_including_depot_unload_1221  120
    service_1_9_9  unique_nonzero_owner_339  1
    service_1_9_9  service_visit_def_1179  1
    service_1_9_9  free_load_conservation_1180  1
    service_1_9_10  unique_nonzero_owner_340  1
    service_1_9_10  service_visit_def_1179  1
    service_1_9_10  free_load_conservation_1180  2
    service_1_9_11  unique_nonzero_owner_341  1
    service_1_9_11  service_visit_def_1179  1
    service_1_9_11  free_load_conservation_1180  3
    service_1_9_12  unique_nonzero_owner_342  1
    service_1_9_12  service_visit_def_1179  1
    service_1_9_12  free_load_conservation_1180  4
    service_2_9_0  unique_nonzero_owner_331  1
    service_2_9_0  service_visit_def_1551  1
    service_2_9_0  free_load_conservation_1552  -8
    service_2_9_0  original_T_including_depot_unload_1592  960
    service_2_9_1  unique_nonzero_owner_332  1
    service_2_9_1  service_visit_def_1551  1
    service_2_9_1  free_load_conservation_1552  -7
    service_2_9_1  original_T_including_depot_unload_1592  840
    service_2_9_2  unique_nonzero_owner_333  1
    service_2_9_2  service_visit_def_1551  1
    service_2_9_2  free_load_conservation_1552  -6
    service_2_9_2  original_T_including_depot_unload_1592  720
    service_2_9_3  unique_nonzero_owner_334  1
    service_2_9_3  service_visit_def_1551  1
    service_2_9_3  free_load_conservation_1552  -5
    service_2_9_3  original_T_including_depot_unload_1592  600
    service_2_9_4  unique_nonzero_owner_335  1
    service_2_9_4  service_visit_def_1551  1
    service_2_9_4  free_load_conservation_1552  -4
    service_2_9_4  original_T_including_depot_unload_1592  480
    service_2_9_5  unique_nonzero_owner_336  1
    service_2_9_5  service_visit_def_1551  1
    service_2_9_5  free_load_conservation_1552  -3
    service_2_9_5  original_T_including_depot_unload_1592  360
    service_2_9_6  unique_nonzero_owner_337  1
    service_2_9_6  service_visit_def_1551  1
    service_2_9_6  free_load_conservation_1552  -2
    service_2_9_6  original_T_including_depot_unload_1592  240
    service_2_9_7  unique_nonzero_owner_338  1
    service_2_9_7  service_visit_def_1551  1
    service_2_9_7  free_load_conservation_1552  -1
    service_2_9_7  original_T_including_depot_unload_1592  120
    service_2_9_9  unique_nonzero_owner_339  1
    service_2_9_9  service_visit_def_1551  1
    service_2_9_9  free_load_conservation_1552  1
    service_2_9_10  unique_nonzero_owner_340  1
    service_2_9_10  service_visit_def_1551  1
    service_2_9_10  free_load_conservation_1552  2
    service_2_9_11  unique_nonzero_owner_341  1
    service_2_9_11  service_visit_def_1551  1
    service_2_9_11  free_load_conservation_1552  3
    service_2_9_12  unique_nonzero_owner_342  1
    service_2_9_12  service_visit_def_1551  1
    service_2_9_12  free_load_conservation_1552  4
    service_0_31_0  unique_nonzero_owner_343  1
    service_0_31_0  service_visit_def_757  1
    service_0_31_0  free_load_conservation_758  -2
    service_0_31_0  original_T_including_depot_unload_792  240
    service_0_31_1  unique_nonzero_owner_344  1
    service_0_31_1  service_visit_def_757  1
    service_0_31_1  free_load_conservation_758  -1
    service_0_31_1  original_T_including_depot_unload_792  120
    service_0_31_3  unique_nonzero_owner_345  1
    service_0_31_3  service_visit_def_757  1
    service_0_31_3  free_load_conservation_758  1
    service_0_31_4  unique_nonzero_owner_346  1
    service_0_31_4  service_visit_def_757  1
    service_0_31_4  free_load_conservation_758  2
    service_0_31_5  unique_nonzero_owner_347  1
    service_0_31_5  service_visit_def_757  1
    service_0_31_5  free_load_conservation_758  3
    service_0_31_6  unique_nonzero_owner_348  1
    service_0_31_6  service_visit_def_757  1
    service_0_31_6  free_load_conservation_758  4
    service_0_31_7  unique_nonzero_owner_349  1
    service_0_31_7  service_visit_def_757  1
    service_0_31_7  free_load_conservation_758  5
    service_0_31_8  unique_nonzero_owner_350  1
    service_0_31_8  service_visit_def_757  1
    service_0_31_8  free_load_conservation_758  6
    service_0_31_9  unique_nonzero_owner_351  1
    service_0_31_9  service_visit_def_757  1
    service_0_31_9  free_load_conservation_758  7
    service_0_31_10  unique_nonzero_owner_352  1
    service_0_31_10  service_visit_def_757  1
    service_0_31_10  free_load_conservation_758  8
    service_0_31_11  unique_nonzero_owner_353  1
    service_0_31_11  service_visit_def_757  1
    service_0_31_11  free_load_conservation_758  9
    service_0_31_12  unique_nonzero_owner_354  1
    service_0_31_12  service_visit_def_757  1
    service_0_31_12  free_load_conservation_758  10
    service_1_31_0  unique_nonzero_owner_343  1
    service_1_31_0  service_visit_def_1185  1
    service_1_31_0  free_load_conservation_1186  -2
    service_1_31_0  original_T_including_depot_unload_1221  240
    service_1_31_1  unique_nonzero_owner_344  1
    service_1_31_1  service_visit_def_1185  1
    service_1_31_1  free_load_conservation_1186  -1
    service_1_31_1  original_T_including_depot_unload_1221  120
    service_1_31_3  unique_nonzero_owner_345  1
    service_1_31_3  service_visit_def_1185  1
    service_1_31_3  free_load_conservation_1186  1
    service_1_31_4  unique_nonzero_owner_346  1
    service_1_31_4  service_visit_def_1185  1
    service_1_31_4  free_load_conservation_1186  2
    service_1_31_5  unique_nonzero_owner_347  1
    service_1_31_5  service_visit_def_1185  1
    service_1_31_5  free_load_conservation_1186  3
    service_1_31_6  unique_nonzero_owner_348  1
    service_1_31_6  service_visit_def_1185  1
    service_1_31_6  free_load_conservation_1186  4
    service_1_31_7  unique_nonzero_owner_349  1
    service_1_31_7  service_visit_def_1185  1
    service_1_31_7  free_load_conservation_1186  5
    service_1_31_8  unique_nonzero_owner_350  1
    service_1_31_8  service_visit_def_1185  1
    service_1_31_8  free_load_conservation_1186  6
    service_1_31_9  unique_nonzero_owner_351  1
    service_1_31_9  service_visit_def_1185  1
    service_1_31_9  free_load_conservation_1186  7
    service_1_31_10  unique_nonzero_owner_352  1
    service_1_31_10  service_visit_def_1185  1
    service_1_31_10  free_load_conservation_1186  8
    service_1_31_11  unique_nonzero_owner_353  1
    service_1_31_11  service_visit_def_1185  1
    service_1_31_11  free_load_conservation_1186  9
    service_1_31_12  unique_nonzero_owner_354  1
    service_1_31_12  service_visit_def_1185  1
    service_1_31_12  free_load_conservation_1186  10
    service_2_31_0  unique_nonzero_owner_343  1
    service_2_31_0  service_visit_def_1557  1
    service_2_31_0  free_load_conservation_1558  -2
    service_2_31_0  original_T_including_depot_unload_1592  240
    service_2_31_1  unique_nonzero_owner_344  1
    service_2_31_1  service_visit_def_1557  1
    service_2_31_1  free_load_conservation_1558  -1
    service_2_31_1  original_T_including_depot_unload_1592  120
    service_2_31_3  unique_nonzero_owner_345  1
    service_2_31_3  service_visit_def_1557  1
    service_2_31_3  free_load_conservation_1558  1
    service_2_31_4  unique_nonzero_owner_346  1
    service_2_31_4  service_visit_def_1557  1
    service_2_31_4  free_load_conservation_1558  2
    service_2_31_5  unique_nonzero_owner_347  1
    service_2_31_5  service_visit_def_1557  1
    service_2_31_5  free_load_conservation_1558  3
    service_2_31_6  unique_nonzero_owner_348  1
    service_2_31_6  service_visit_def_1557  1
    service_2_31_6  free_load_conservation_1558  4
    service_2_31_7  unique_nonzero_owner_349  1
    service_2_31_7  service_visit_def_1557  1
    service_2_31_7  free_load_conservation_1558  5
    service_2_31_8  unique_nonzero_owner_350  1
    service_2_31_8  service_visit_def_1557  1
    service_2_31_8  free_load_conservation_1558  6
    service_2_31_9  unique_nonzero_owner_351  1
    service_2_31_9  service_visit_def_1557  1
    service_2_31_9  free_load_conservation_1558  7
    service_2_31_10  unique_nonzero_owner_352  1
    service_2_31_10  service_visit_def_1557  1
    service_2_31_10  free_load_conservation_1558  8
    service_2_31_11  unique_nonzero_owner_353  1
    service_2_31_11  service_visit_def_1557  1
    service_2_31_11  free_load_conservation_1558  9
    service_2_31_12  unique_nonzero_owner_354  1
    service_2_31_12  service_visit_def_1557  1
    service_2_31_12  free_load_conservation_1558  10
    service_0_19_1  unique_nonzero_owner_355  1
    service_0_19_1  service_visit_def_763  1
    service_0_19_1  free_load_conservation_764  1
    service_0_19_2  unique_nonzero_owner_356  1
    service_0_19_2  service_visit_def_763  1
    service_0_19_2  free_load_conservation_764  2
    service_0_19_3  unique_nonzero_owner_357  1
    service_0_19_3  service_visit_def_763  1
    service_0_19_3  free_load_conservation_764  3
    service_0_19_4  unique_nonzero_owner_358  1
    service_0_19_4  service_visit_def_763  1
    service_0_19_4  free_load_conservation_764  4
    service_0_19_5  unique_nonzero_owner_359  1
    service_0_19_5  service_visit_def_763  1
    service_0_19_5  free_load_conservation_764  5
    service_0_19_6  unique_nonzero_owner_360  1
    service_0_19_6  service_visit_def_763  1
    service_0_19_6  free_load_conservation_764  6
    service_0_19_7  unique_nonzero_owner_361  1
    service_0_19_7  service_visit_def_763  1
    service_0_19_7  free_load_conservation_764  7
    service_0_19_8  unique_nonzero_owner_362  1
    service_0_19_8  service_visit_def_763  1
    service_0_19_8  free_load_conservation_764  8
    service_1_19_1  unique_nonzero_owner_355  1
    service_1_19_1  service_visit_def_1191  1
    service_1_19_1  free_load_conservation_1192  1
    service_1_19_2  unique_nonzero_owner_356  1
    service_1_19_2  service_visit_def_1191  1
    service_1_19_2  free_load_conservation_1192  2
    service_1_19_3  unique_nonzero_owner_357  1
    service_1_19_3  service_visit_def_1191  1
    service_1_19_3  free_load_conservation_1192  3
    service_1_19_4  unique_nonzero_owner_358  1
    service_1_19_4  service_visit_def_1191  1
    service_1_19_4  free_load_conservation_1192  4
    service_1_19_5  unique_nonzero_owner_359  1
    service_1_19_5  service_visit_def_1191  1
    service_1_19_5  free_load_conservation_1192  5
    service_1_19_6  unique_nonzero_owner_360  1
    service_1_19_6  service_visit_def_1191  1
    service_1_19_6  free_load_conservation_1192  6
    service_1_19_7  unique_nonzero_owner_361  1
    service_1_19_7  service_visit_def_1191  1
    service_1_19_7  free_load_conservation_1192  7
    service_1_19_8  unique_nonzero_owner_362  1
    service_1_19_8  service_visit_def_1191  1
    service_1_19_8  free_load_conservation_1192  8
    service_2_19_1  unique_nonzero_owner_355  1
    service_2_19_1  service_visit_def_1563  1
    service_2_19_1  free_load_conservation_1564  1
    service_2_19_2  unique_nonzero_owner_356  1
    service_2_19_2  service_visit_def_1563  1
    service_2_19_2  free_load_conservation_1564  2
    service_2_19_3  unique_nonzero_owner_357  1
    service_2_19_3  service_visit_def_1563  1
    service_2_19_3  free_load_conservation_1564  3
    service_2_19_4  unique_nonzero_owner_358  1
    service_2_19_4  service_visit_def_1563  1
    service_2_19_4  free_load_conservation_1564  4
    service_2_19_5  unique_nonzero_owner_359  1
    service_2_19_5  service_visit_def_1563  1
    service_2_19_5  free_load_conservation_1564  5
    service_2_19_6  unique_nonzero_owner_360  1
    service_2_19_6  service_visit_def_1563  1
    service_2_19_6  free_load_conservation_1564  6
    service_2_19_7  unique_nonzero_owner_361  1
    service_2_19_7  service_visit_def_1563  1
    service_2_19_7  free_load_conservation_1564  7
    service_2_19_8  unique_nonzero_owner_362  1
    service_2_19_8  service_visit_def_1563  1
    service_2_19_8  free_load_conservation_1564  8
    service_0_16_0  unique_nonzero_owner_363  1
    service_0_16_0  service_visit_def_769  1
    service_0_16_0  free_load_conservation_770  -1
    service_0_16_0  original_T_including_depot_unload_792  120
    service_0_16_2  unique_nonzero_owner_364  1
    service_0_16_2  service_visit_def_769  1
    service_0_16_2  free_load_conservation_770  1
    service_0_16_3  unique_nonzero_owner_365  1
    service_0_16_3  service_visit_def_769  1
    service_0_16_3  free_load_conservation_770  2
    service_0_16_4  unique_nonzero_owner_366  1
    service_0_16_4  service_visit_def_769  1
    service_0_16_4  free_load_conservation_770  3
    service_0_16_5  unique_nonzero_owner_367  1
    service_0_16_5  service_visit_def_769  1
    service_0_16_5  free_load_conservation_770  4
    service_0_16_6  unique_nonzero_owner_368  1
    service_0_16_6  service_visit_def_769  1
    service_0_16_6  free_load_conservation_770  5
    service_0_16_7  unique_nonzero_owner_369  1
    service_0_16_7  service_visit_def_769  1
    service_0_16_7  free_load_conservation_770  6
    service_0_16_8  unique_nonzero_owner_370  1
    service_0_16_8  service_visit_def_769  1
    service_0_16_8  free_load_conservation_770  7
    service_0_16_9  unique_nonzero_owner_371  1
    service_0_16_9  service_visit_def_769  1
    service_0_16_9  free_load_conservation_770  8
    service_0_16_10  unique_nonzero_owner_372  1
    service_0_16_10  service_visit_def_769  1
    service_0_16_10  free_load_conservation_770  9
    service_0_16_11  unique_nonzero_owner_373  1
    service_0_16_11  service_visit_def_769  1
    service_0_16_11  free_load_conservation_770  10
    service_0_16_12  unique_nonzero_owner_374  1
    service_0_16_12  service_visit_def_769  1
    service_0_16_12  free_load_conservation_770  11
    service_1_16_0  unique_nonzero_owner_363  1
    service_1_16_0  service_visit_def_1197  1
    service_1_16_0  free_load_conservation_1198  -1
    service_1_16_0  original_T_including_depot_unload_1221  120
    service_1_16_2  unique_nonzero_owner_364  1
    service_1_16_2  service_visit_def_1197  1
    service_1_16_2  free_load_conservation_1198  1
    service_1_16_3  unique_nonzero_owner_365  1
    service_1_16_3  service_visit_def_1197  1
    service_1_16_3  free_load_conservation_1198  2
    service_1_16_4  unique_nonzero_owner_366  1
    service_1_16_4  service_visit_def_1197  1
    service_1_16_4  free_load_conservation_1198  3
    service_1_16_5  unique_nonzero_owner_367  1
    service_1_16_5  service_visit_def_1197  1
    service_1_16_5  free_load_conservation_1198  4
    service_1_16_6  unique_nonzero_owner_368  1
    service_1_16_6  service_visit_def_1197  1
    service_1_16_6  free_load_conservation_1198  5
    service_1_16_7  unique_nonzero_owner_369  1
    service_1_16_7  service_visit_def_1197  1
    service_1_16_7  free_load_conservation_1198  6
    service_1_16_8  unique_nonzero_owner_370  1
    service_1_16_8  service_visit_def_1197  1
    service_1_16_8  free_load_conservation_1198  7
    service_1_16_9  unique_nonzero_owner_371  1
    service_1_16_9  service_visit_def_1197  1
    service_1_16_9  free_load_conservation_1198  8
    service_1_16_10  unique_nonzero_owner_372  1
    service_1_16_10  service_visit_def_1197  1
    service_1_16_10  free_load_conservation_1198  9
    service_1_16_11  unique_nonzero_owner_373  1
    service_1_16_11  service_visit_def_1197  1
    service_1_16_11  free_load_conservation_1198  10
    service_1_16_12  unique_nonzero_owner_374  1
    service_1_16_12  service_visit_def_1197  1
    service_1_16_12  free_load_conservation_1198  11
    service_2_16_0  unique_nonzero_owner_363  1
    service_2_16_0  service_visit_def_1569  1
    service_2_16_0  free_load_conservation_1570  -1
    service_2_16_0  original_T_including_depot_unload_1592  120
    service_2_16_2  unique_nonzero_owner_364  1
    service_2_16_2  service_visit_def_1569  1
    service_2_16_2  free_load_conservation_1570  1
    service_2_16_3  unique_nonzero_owner_365  1
    service_2_16_3  service_visit_def_1569  1
    service_2_16_3  free_load_conservation_1570  2
    service_2_16_4  unique_nonzero_owner_366  1
    service_2_16_4  service_visit_def_1569  1
    service_2_16_4  free_load_conservation_1570  3
    service_2_16_5  unique_nonzero_owner_367  1
    service_2_16_5  service_visit_def_1569  1
    service_2_16_5  free_load_conservation_1570  4
    service_2_16_6  unique_nonzero_owner_368  1
    service_2_16_6  service_visit_def_1569  1
    service_2_16_6  free_load_conservation_1570  5
    service_2_16_7  unique_nonzero_owner_369  1
    service_2_16_7  service_visit_def_1569  1
    service_2_16_7  free_load_conservation_1570  6
    service_2_16_8  unique_nonzero_owner_370  1
    service_2_16_8  service_visit_def_1569  1
    service_2_16_8  free_load_conservation_1570  7
    service_2_16_9  unique_nonzero_owner_371  1
    service_2_16_9  service_visit_def_1569  1
    service_2_16_9  free_load_conservation_1570  8
    service_2_16_10  unique_nonzero_owner_372  1
    service_2_16_10  service_visit_def_1569  1
    service_2_16_10  free_load_conservation_1570  9
    service_2_16_11  unique_nonzero_owner_373  1
    service_2_16_11  service_visit_def_1569  1
    service_2_16_11  free_load_conservation_1570  10
    service_2_16_12  unique_nonzero_owner_374  1
    service_2_16_12  service_visit_def_1569  1
    service_2_16_12  free_load_conservation_1570  11
    service_0_13_0  unique_nonzero_owner_375  1
    service_0_13_0  service_visit_def_775  1
    service_0_13_0  free_load_conservation_776  -13
    service_0_13_0  original_T_including_depot_unload_792  1560
    service_0_13_1  unique_nonzero_owner_376  1
    service_0_13_1  service_visit_def_775  1
    service_0_13_1  free_load_conservation_776  -12
    service_0_13_1  original_T_including_depot_unload_792  1440
    service_0_13_2  unique_nonzero_owner_377  1
    service_0_13_2  service_visit_def_775  1
    service_0_13_2  free_load_conservation_776  -11
    service_0_13_2  original_T_including_depot_unload_792  1320
    service_0_13_3  unique_nonzero_owner_378  1
    service_0_13_3  service_visit_def_775  1
    service_0_13_3  free_load_conservation_776  -10
    service_0_13_3  original_T_including_depot_unload_792  1200
    service_0_13_4  unique_nonzero_owner_379  1
    service_0_13_4  service_visit_def_775  1
    service_0_13_4  free_load_conservation_776  -9
    service_0_13_4  original_T_including_depot_unload_792  1080
    service_0_13_5  unique_nonzero_owner_380  1
    service_0_13_5  service_visit_def_775  1
    service_0_13_5  free_load_conservation_776  -8
    service_0_13_5  original_T_including_depot_unload_792  960
    service_0_13_6  unique_nonzero_owner_381  1
    service_0_13_6  service_visit_def_775  1
    service_0_13_6  free_load_conservation_776  -7
    service_0_13_6  original_T_including_depot_unload_792  840
    service_0_13_7  unique_nonzero_owner_382  1
    service_0_13_7  service_visit_def_775  1
    service_0_13_7  free_load_conservation_776  -6
    service_0_13_7  original_T_including_depot_unload_792  720
    service_0_13_8  unique_nonzero_owner_383  1
    service_0_13_8  service_visit_def_775  1
    service_0_13_8  free_load_conservation_776  -5
    service_0_13_8  original_T_including_depot_unload_792  600
    service_0_13_9  unique_nonzero_owner_384  1
    service_0_13_9  service_visit_def_775  1
    service_0_13_9  free_load_conservation_776  -4
    service_0_13_9  original_T_including_depot_unload_792  480
    service_0_13_10  unique_nonzero_owner_385  1
    service_0_13_10  service_visit_def_775  1
    service_0_13_10  free_load_conservation_776  -3
    service_0_13_10  original_T_including_depot_unload_792  360
    service_0_13_11  unique_nonzero_owner_386  1
    service_0_13_11  service_visit_def_775  1
    service_0_13_11  free_load_conservation_776  -2
    service_0_13_11  original_T_including_depot_unload_792  240
    service_0_13_12  unique_nonzero_owner_387  1
    service_0_13_12  service_visit_def_775  1
    service_0_13_12  free_load_conservation_776  -1
    service_0_13_12  original_T_including_depot_unload_792  120
    service_0_13_14  unique_nonzero_owner_388  1
    service_0_13_14  service_visit_def_775  1
    service_0_13_14  free_load_conservation_776  1
    service_0_13_15  unique_nonzero_owner_389  1
    service_0_13_15  service_visit_def_775  1
    service_0_13_15  free_load_conservation_776  2
    service_0_13_16  unique_nonzero_owner_390  1
    service_0_13_16  service_visit_def_775  1
    service_0_13_16  free_load_conservation_776  3
    service_0_13_17  unique_nonzero_owner_391  1
    service_0_13_17  service_visit_def_775  1
    service_0_13_17  free_load_conservation_776  4
    service_0_13_18  unique_nonzero_owner_392  1
    service_0_13_18  service_visit_def_775  1
    service_0_13_18  free_load_conservation_776  5
    service_0_13_19  unique_nonzero_owner_393  1
    service_0_13_19  service_visit_def_775  1
    service_0_13_19  free_load_conservation_776  6
    service_1_13_0  unique_nonzero_owner_375  1
    service_1_13_0  service_visit_def_1203  1
    service_1_13_0  free_load_conservation_1204  -13
    service_1_13_0  original_T_including_depot_unload_1221  1560
    service_1_13_1  unique_nonzero_owner_376  1
    service_1_13_1  service_visit_def_1203  1
    service_1_13_1  free_load_conservation_1204  -12
    service_1_13_1  original_T_including_depot_unload_1221  1440
    service_1_13_2  unique_nonzero_owner_377  1
    service_1_13_2  service_visit_def_1203  1
    service_1_13_2  free_load_conservation_1204  -11
    service_1_13_2  original_T_including_depot_unload_1221  1320
    service_1_13_3  unique_nonzero_owner_378  1
    service_1_13_3  service_visit_def_1203  1
    service_1_13_3  free_load_conservation_1204  -10
    service_1_13_3  original_T_including_depot_unload_1221  1200
    service_1_13_4  unique_nonzero_owner_379  1
    service_1_13_4  service_visit_def_1203  1
    service_1_13_4  free_load_conservation_1204  -9
    service_1_13_4  original_T_including_depot_unload_1221  1080
    service_1_13_5  unique_nonzero_owner_380  1
    service_1_13_5  service_visit_def_1203  1
    service_1_13_5  free_load_conservation_1204  -8
    service_1_13_5  original_T_including_depot_unload_1221  960
    service_1_13_6  unique_nonzero_owner_381  1
    service_1_13_6  service_visit_def_1203  1
    service_1_13_6  free_load_conservation_1204  -7
    service_1_13_6  original_T_including_depot_unload_1221  840
    service_1_13_7  unique_nonzero_owner_382  1
    service_1_13_7  service_visit_def_1203  1
    service_1_13_7  free_load_conservation_1204  -6
    service_1_13_7  original_T_including_depot_unload_1221  720
    service_1_13_8  unique_nonzero_owner_383  1
    service_1_13_8  service_visit_def_1203  1
    service_1_13_8  free_load_conservation_1204  -5
    service_1_13_8  original_T_including_depot_unload_1221  600
    service_1_13_9  unique_nonzero_owner_384  1
    service_1_13_9  service_visit_def_1203  1
    service_1_13_9  free_load_conservation_1204  -4
    service_1_13_9  original_T_including_depot_unload_1221  480
    service_1_13_10  unique_nonzero_owner_385  1
    service_1_13_10  service_visit_def_1203  1
    service_1_13_10  free_load_conservation_1204  -3
    service_1_13_10  original_T_including_depot_unload_1221  360
    service_1_13_11  unique_nonzero_owner_386  1
    service_1_13_11  service_visit_def_1203  1
    service_1_13_11  free_load_conservation_1204  -2
    service_1_13_11  original_T_including_depot_unload_1221  240
    service_1_13_12  unique_nonzero_owner_387  1
    service_1_13_12  service_visit_def_1203  1
    service_1_13_12  free_load_conservation_1204  -1
    service_1_13_12  original_T_including_depot_unload_1221  120
    service_1_13_14  unique_nonzero_owner_388  1
    service_1_13_14  service_visit_def_1203  1
    service_1_13_14  free_load_conservation_1204  1
    service_1_13_15  unique_nonzero_owner_389  1
    service_1_13_15  service_visit_def_1203  1
    service_1_13_15  free_load_conservation_1204  2
    service_1_13_16  unique_nonzero_owner_390  1
    service_1_13_16  service_visit_def_1203  1
    service_1_13_16  free_load_conservation_1204  3
    service_1_13_17  unique_nonzero_owner_391  1
    service_1_13_17  service_visit_def_1203  1
    service_1_13_17  free_load_conservation_1204  4
    service_1_13_18  unique_nonzero_owner_392  1
    service_1_13_18  service_visit_def_1203  1
    service_1_13_18  free_load_conservation_1204  5
    service_1_13_19  unique_nonzero_owner_393  1
    service_1_13_19  service_visit_def_1203  1
    service_1_13_19  free_load_conservation_1204  6
    service_2_13_0  unique_nonzero_owner_375  1
    service_2_13_0  service_visit_def_1575  1
    service_2_13_0  free_load_conservation_1576  -13
    service_2_13_0  original_T_including_depot_unload_1592  1560
    service_2_13_1  unique_nonzero_owner_376  1
    service_2_13_1  service_visit_def_1575  1
    service_2_13_1  free_load_conservation_1576  -12
    service_2_13_1  original_T_including_depot_unload_1592  1440
    service_2_13_2  unique_nonzero_owner_377  1
    service_2_13_2  service_visit_def_1575  1
    service_2_13_2  free_load_conservation_1576  -11
    service_2_13_2  original_T_including_depot_unload_1592  1320
    service_2_13_3  unique_nonzero_owner_378  1
    service_2_13_3  service_visit_def_1575  1
    service_2_13_3  free_load_conservation_1576  -10
    service_2_13_3  original_T_including_depot_unload_1592  1200
    service_2_13_4  unique_nonzero_owner_379  1
    service_2_13_4  service_visit_def_1575  1
    service_2_13_4  free_load_conservation_1576  -9
    service_2_13_4  original_T_including_depot_unload_1592  1080
    service_2_13_5  unique_nonzero_owner_380  1
    service_2_13_5  service_visit_def_1575  1
    service_2_13_5  free_load_conservation_1576  -8
    service_2_13_5  original_T_including_depot_unload_1592  960
    service_2_13_6  unique_nonzero_owner_381  1
    service_2_13_6  service_visit_def_1575  1
    service_2_13_6  free_load_conservation_1576  -7
    service_2_13_6  original_T_including_depot_unload_1592  840
    service_2_13_7  unique_nonzero_owner_382  1
    service_2_13_7  service_visit_def_1575  1
    service_2_13_7  free_load_conservation_1576  -6
    service_2_13_7  original_T_including_depot_unload_1592  720
    service_2_13_8  unique_nonzero_owner_383  1
    service_2_13_8  service_visit_def_1575  1
    service_2_13_8  free_load_conservation_1576  -5
    service_2_13_8  original_T_including_depot_unload_1592  600
    service_2_13_9  unique_nonzero_owner_384  1
    service_2_13_9  service_visit_def_1575  1
    service_2_13_9  free_load_conservation_1576  -4
    service_2_13_9  original_T_including_depot_unload_1592  480
    service_2_13_10  unique_nonzero_owner_385  1
    service_2_13_10  service_visit_def_1575  1
    service_2_13_10  free_load_conservation_1576  -3
    service_2_13_10  original_T_including_depot_unload_1592  360
    service_2_13_11  unique_nonzero_owner_386  1
    service_2_13_11  service_visit_def_1575  1
    service_2_13_11  free_load_conservation_1576  -2
    service_2_13_11  original_T_including_depot_unload_1592  240
    service_2_13_12  unique_nonzero_owner_387  1
    service_2_13_12  service_visit_def_1575  1
    service_2_13_12  free_load_conservation_1576  -1
    service_2_13_12  original_T_including_depot_unload_1592  120
    service_2_13_14  unique_nonzero_owner_388  1
    service_2_13_14  service_visit_def_1575  1
    service_2_13_14  free_load_conservation_1576  1
    service_2_13_15  unique_nonzero_owner_389  1
    service_2_13_15  service_visit_def_1575  1
    service_2_13_15  free_load_conservation_1576  2
    service_2_13_16  unique_nonzero_owner_390  1
    service_2_13_16  service_visit_def_1575  1
    service_2_13_16  free_load_conservation_1576  3
    service_2_13_17  unique_nonzero_owner_391  1
    service_2_13_17  service_visit_def_1575  1
    service_2_13_17  free_load_conservation_1576  4
    service_2_13_18  unique_nonzero_owner_392  1
    service_2_13_18  service_visit_def_1575  1
    service_2_13_18  free_load_conservation_1576  5
    service_2_13_19  unique_nonzero_owner_393  1
    service_2_13_19  service_visit_def_1575  1
    service_2_13_19  free_load_conservation_1576  6
    service_0_32_1  unique_nonzero_owner_394  1
    service_0_32_1  service_visit_def_781  1
    service_0_32_1  free_load_conservation_782  1
    service_0_32_2  unique_nonzero_owner_395  1
    service_0_32_2  service_visit_def_781  1
    service_0_32_2  free_load_conservation_782  2
    service_0_32_3  unique_nonzero_owner_396  1
    service_0_32_3  service_visit_def_781  1
    service_0_32_3  free_load_conservation_782  3
    service_0_32_4  unique_nonzero_owner_397  1
    service_0_32_4  service_visit_def_781  1
    service_0_32_4  free_load_conservation_782  4
    service_0_32_5  unique_nonzero_owner_398  1
    service_0_32_5  service_visit_def_781  1
    service_0_32_5  free_load_conservation_782  5
    service_0_32_6  unique_nonzero_owner_399  1
    service_0_32_6  service_visit_def_781  1
    service_0_32_6  free_load_conservation_782  6
    service_0_32_7  unique_nonzero_owner_400  1
    service_0_32_7  service_visit_def_781  1
    service_0_32_7  free_load_conservation_782  7
    service_0_32_8  unique_nonzero_owner_401  1
    service_0_32_8  service_visit_def_781  1
    service_0_32_8  free_load_conservation_782  8
    service_0_32_9  unique_nonzero_owner_402  1
    service_0_32_9  service_visit_def_781  1
    service_0_32_9  free_load_conservation_782  9
    service_0_32_10  unique_nonzero_owner_403  1
    service_0_32_10  service_visit_def_781  1
    service_0_32_10  free_load_conservation_782  10
    service_0_32_11  unique_nonzero_owner_404  1
    service_0_32_11  service_visit_def_781  1
    service_0_32_11  free_load_conservation_782  11
    service_0_32_12  unique_nonzero_owner_405  1
    service_0_32_12  service_visit_def_781  1
    service_0_32_12  free_load_conservation_782  12
    service_1_32_1  unique_nonzero_owner_394  1
    service_1_32_1  service_visit_def_1209  1
    service_1_32_1  free_load_conservation_1210  1
    service_1_32_2  unique_nonzero_owner_395  1
    service_1_32_2  service_visit_def_1209  1
    service_1_32_2  free_load_conservation_1210  2
    service_1_32_3  unique_nonzero_owner_396  1
    service_1_32_3  service_visit_def_1209  1
    service_1_32_3  free_load_conservation_1210  3
    service_1_32_4  unique_nonzero_owner_397  1
    service_1_32_4  service_visit_def_1209  1
    service_1_32_4  free_load_conservation_1210  4
    service_1_32_5  unique_nonzero_owner_398  1
    service_1_32_5  service_visit_def_1209  1
    service_1_32_5  free_load_conservation_1210  5
    service_1_32_6  unique_nonzero_owner_399  1
    service_1_32_6  service_visit_def_1209  1
    service_1_32_6  free_load_conservation_1210  6
    service_1_32_7  unique_nonzero_owner_400  1
    service_1_32_7  service_visit_def_1209  1
    service_1_32_7  free_load_conservation_1210  7
    service_1_32_8  unique_nonzero_owner_401  1
    service_1_32_8  service_visit_def_1209  1
    service_1_32_8  free_load_conservation_1210  8
    service_1_32_9  unique_nonzero_owner_402  1
    service_1_32_9  service_visit_def_1209  1
    service_1_32_9  free_load_conservation_1210  9
    service_1_32_10  unique_nonzero_owner_403  1
    service_1_32_10  service_visit_def_1209  1
    service_1_32_10  free_load_conservation_1210  10
    service_1_32_11  unique_nonzero_owner_404  1
    service_1_32_11  service_visit_def_1209  1
    service_1_32_11  free_load_conservation_1210  11
    service_1_32_12  unique_nonzero_owner_405  1
    service_1_32_12  service_visit_def_1209  1
    service_1_32_12  free_load_conservation_1210  12
    service_2_32_1  unique_nonzero_owner_394  1
    service_2_32_1  service_visit_def_1581  1
    service_2_32_1  free_load_conservation_1582  1
    service_2_32_2  unique_nonzero_owner_395  1
    service_2_32_2  service_visit_def_1581  1
    service_2_32_2  free_load_conservation_1582  2
    service_2_32_3  unique_nonzero_owner_396  1
    service_2_32_3  service_visit_def_1581  1
    service_2_32_3  free_load_conservation_1582  3
    service_2_32_4  unique_nonzero_owner_397  1
    service_2_32_4  service_visit_def_1581  1
    service_2_32_4  free_load_conservation_1582  4
    service_2_32_5  unique_nonzero_owner_398  1
    service_2_32_5  service_visit_def_1581  1
    service_2_32_5  free_load_conservation_1582  5
    service_2_32_6  unique_nonzero_owner_399  1
    service_2_32_6  service_visit_def_1581  1
    service_2_32_6  free_load_conservation_1582  6
    service_2_32_7  unique_nonzero_owner_400  1
    service_2_32_7  service_visit_def_1581  1
    service_2_32_7  free_load_conservation_1582  7
    service_2_32_8  unique_nonzero_owner_401  1
    service_2_32_8  service_visit_def_1581  1
    service_2_32_8  free_load_conservation_1582  8
    service_2_32_9  unique_nonzero_owner_402  1
    service_2_32_9  service_visit_def_1581  1
    service_2_32_9  free_load_conservation_1582  9
    service_2_32_10  unique_nonzero_owner_403  1
    service_2_32_10  service_visit_def_1581  1
    service_2_32_10  free_load_conservation_1582  10
    service_2_32_11  unique_nonzero_owner_404  1
    service_2_32_11  service_visit_def_1581  1
    service_2_32_11  free_load_conservation_1582  11
    service_2_32_12  unique_nonzero_owner_405  1
    service_2_32_12  service_visit_def_1581  1
    service_2_32_12  free_load_conservation_1582  12
    service_0_17_0  unique_nonzero_owner_406  1
    service_0_17_0  service_visit_def_787  1
    service_0_17_0  free_load_conservation_788  -3
    service_0_17_0  original_T_including_depot_unload_792  360
    service_0_17_1  unique_nonzero_owner_407  1
    service_0_17_1  service_visit_def_787  1
    service_0_17_1  free_load_conservation_788  -2
    service_0_17_1  original_T_including_depot_unload_792  240
    service_0_17_2  unique_nonzero_owner_408  1
    service_0_17_2  service_visit_def_787  1
    service_0_17_2  free_load_conservation_788  -1
    service_0_17_2  original_T_including_depot_unload_792  120
    service_0_17_4  unique_nonzero_owner_409  1
    service_0_17_4  service_visit_def_787  1
    service_0_17_4  free_load_conservation_788  1
    service_0_17_5  unique_nonzero_owner_410  1
    service_0_17_5  service_visit_def_787  1
    service_0_17_5  free_load_conservation_788  2
    service_0_17_6  unique_nonzero_owner_411  1
    service_0_17_6  service_visit_def_787  1
    service_0_17_6  free_load_conservation_788  3
    service_0_17_7  unique_nonzero_owner_412  1
    service_0_17_7  service_visit_def_787  1
    service_0_17_7  free_load_conservation_788  4
    service_0_17_8  unique_nonzero_owner_413  1
    service_0_17_8  service_visit_def_787  1
    service_0_17_8  free_load_conservation_788  5
    service_0_17_9  unique_nonzero_owner_414  1
    service_0_17_9  service_visit_def_787  1
    service_0_17_9  free_load_conservation_788  6
    service_0_17_10  unique_nonzero_owner_415  1
    service_0_17_10  service_visit_def_787  1
    service_0_17_10  free_load_conservation_788  7
    service_0_17_11  unique_nonzero_owner_416  1
    service_0_17_11  service_visit_def_787  1
    service_0_17_11  free_load_conservation_788  8
    service_0_17_12  unique_nonzero_owner_417  1
    service_0_17_12  service_visit_def_787  1
    service_0_17_12  free_load_conservation_788  9
    service_0_17_13  unique_nonzero_owner_418  1
    service_0_17_13  service_visit_def_787  1
    service_0_17_13  free_load_conservation_788  10
    service_0_17_14  unique_nonzero_owner_419  1
    service_0_17_14  service_visit_def_787  1
    service_0_17_14  free_load_conservation_788  11
    service_0_17_15  unique_nonzero_owner_420  1
    service_0_17_15  service_visit_def_787  1
    service_0_17_15  free_load_conservation_788  12
    service_0_17_16  unique_nonzero_owner_421  1
    service_0_17_16  service_visit_def_787  1
    service_0_17_16  free_load_conservation_788  13
    service_1_17_0  unique_nonzero_owner_406  1
    service_1_17_0  service_visit_def_1215  1
    service_1_17_0  free_load_conservation_1216  -3
    service_1_17_0  original_T_including_depot_unload_1221  360
    service_1_17_1  unique_nonzero_owner_407  1
    service_1_17_1  service_visit_def_1215  1
    service_1_17_1  free_load_conservation_1216  -2
    service_1_17_1  original_T_including_depot_unload_1221  240
    service_1_17_2  unique_nonzero_owner_408  1
    service_1_17_2  service_visit_def_1215  1
    service_1_17_2  free_load_conservation_1216  -1
    service_1_17_2  original_T_including_depot_unload_1221  120
    service_1_17_4  unique_nonzero_owner_409  1
    service_1_17_4  service_visit_def_1215  1
    service_1_17_4  free_load_conservation_1216  1
    service_1_17_5  unique_nonzero_owner_410  1
    service_1_17_5  service_visit_def_1215  1
    service_1_17_5  free_load_conservation_1216  2
    service_1_17_6  unique_nonzero_owner_411  1
    service_1_17_6  service_visit_def_1215  1
    service_1_17_6  free_load_conservation_1216  3
    service_1_17_7  unique_nonzero_owner_412  1
    service_1_17_7  service_visit_def_1215  1
    service_1_17_7  free_load_conservation_1216  4
    service_1_17_8  unique_nonzero_owner_413  1
    service_1_17_8  service_visit_def_1215  1
    service_1_17_8  free_load_conservation_1216  5
    service_1_17_9  unique_nonzero_owner_414  1
    service_1_17_9  service_visit_def_1215  1
    service_1_17_9  free_load_conservation_1216  6
    service_1_17_10  unique_nonzero_owner_415  1
    service_1_17_10  service_visit_def_1215  1
    service_1_17_10  free_load_conservation_1216  7
    service_1_17_11  unique_nonzero_owner_416  1
    service_1_17_11  service_visit_def_1215  1
    service_1_17_11  free_load_conservation_1216  8
    service_1_17_12  unique_nonzero_owner_417  1
    service_1_17_12  service_visit_def_1215  1
    service_1_17_12  free_load_conservation_1216  9
    service_1_17_13  unique_nonzero_owner_418  1
    service_1_17_13  service_visit_def_1215  1
    service_1_17_13  free_load_conservation_1216  10
    service_1_17_14  unique_nonzero_owner_419  1
    service_1_17_14  service_visit_def_1215  1
    service_1_17_14  free_load_conservation_1216  11
    service_1_17_15  unique_nonzero_owner_420  1
    service_1_17_15  service_visit_def_1215  1
    service_1_17_15  free_load_conservation_1216  12
    service_1_17_16  unique_nonzero_owner_421  1
    service_1_17_16  service_visit_def_1215  1
    service_1_17_16  free_load_conservation_1216  13
    service_2_17_0  unique_nonzero_owner_406  1
    service_2_17_0  service_visit_def_1587  1
    service_2_17_0  free_load_conservation_1588  -3
    service_2_17_0  original_T_including_depot_unload_1592  360
    service_2_17_1  unique_nonzero_owner_407  1
    service_2_17_1  service_visit_def_1587  1
    service_2_17_1  free_load_conservation_1588  -2
    service_2_17_1  original_T_including_depot_unload_1592  240
    service_2_17_2  unique_nonzero_owner_408  1
    service_2_17_2  service_visit_def_1587  1
    service_2_17_2  free_load_conservation_1588  -1
    service_2_17_2  original_T_including_depot_unload_1592  120
    service_2_17_4  unique_nonzero_owner_409  1
    service_2_17_4  service_visit_def_1587  1
    service_2_17_4  free_load_conservation_1588  1
    service_2_17_5  unique_nonzero_owner_410  1
    service_2_17_5  service_visit_def_1587  1
    service_2_17_5  free_load_conservation_1588  2
    service_2_17_6  unique_nonzero_owner_411  1
    service_2_17_6  service_visit_def_1587  1
    service_2_17_6  free_load_conservation_1588  3
    service_2_17_7  unique_nonzero_owner_412  1
    service_2_17_7  service_visit_def_1587  1
    service_2_17_7  free_load_conservation_1588  4
    service_2_17_8  unique_nonzero_owner_413  1
    service_2_17_8  service_visit_def_1587  1
    service_2_17_8  free_load_conservation_1588  5
    service_2_17_9  unique_nonzero_owner_414  1
    service_2_17_9  service_visit_def_1587  1
    service_2_17_9  free_load_conservation_1588  6
    service_2_17_10  unique_nonzero_owner_415  1
    service_2_17_10  service_visit_def_1587  1
    service_2_17_10  free_load_conservation_1588  7
    service_2_17_11  unique_nonzero_owner_416  1
    service_2_17_11  service_visit_def_1587  1
    service_2_17_11  free_load_conservation_1588  8
    service_2_17_12  unique_nonzero_owner_417  1
    service_2_17_12  service_visit_def_1587  1
    service_2_17_12  free_load_conservation_1588  9
    service_2_17_13  unique_nonzero_owner_418  1
    service_2_17_13  service_visit_def_1587  1
    service_2_17_13  free_load_conservation_1588  10
    service_2_17_14  unique_nonzero_owner_419  1
    service_2_17_14  service_visit_def_1587  1
    service_2_17_14  free_load_conservation_1588  11
    service_2_17_15  unique_nonzero_owner_420  1
    service_2_17_15  service_visit_def_1587  1
    service_2_17_15  free_load_conservation_1588  12
    service_2_17_16  unique_nonzero_owner_421  1
    service_2_17_16  service_visit_def_1587  1
    service_2_17_16  free_load_conservation_1588  13
    MARKER    'MARKER'                 'INTEND'
    visit_0_1  out_degree_713  -1
    visit_0_1  in_degree_714  -1
    visit_0_1  order_active_lb_715  -1
    visit_0_1  order_active_ub_716  -12
    order_0_1  connected_order_arc_437  -1
    order_0_1  connected_order_arc_439  -1
    order_0_1  connected_order_arc_441  -1
    order_0_1  connected_order_arc_443  -1
    order_0_1  connected_order_arc_445  -1
    order_0_1  connected_order_arc_447  -1
    order_0_1  connected_order_arc_449  -1
    order_0_1  connected_order_arc_451  -1
    order_0_1  connected_order_arc_453  -1
    order_0_1  connected_order_arc_455  -1
    order_0_1  connected_order_arc_457  -1
    order_0_1  connected_order_arc_460  1
    order_0_1  connected_order_arc_483  1
    order_0_1  connected_order_arc_506  1
    order_0_1  connected_order_arc_529  1
    order_0_1  connected_order_arc_552  1
    order_0_1  connected_order_arc_575  1
    order_0_1  connected_order_arc_598  1
    order_0_1  connected_order_arc_621  1
    order_0_1  connected_order_arc_644  1
    order_0_1  connected_order_arc_667  1
    order_0_1  connected_order_arc_690  1
    order_0_1  order_active_lb_715  1
    order_0_1  order_active_ub_716  1
    order_0_1  fixed_segment_relative_order_789  -1
    visit_0_2  out_degree_720  -1
    visit_0_2  in_degree_721  -1
    visit_0_2  order_active_lb_722  -1
    visit_0_2  order_active_ub_723  -12
    order_0_2  connected_order_arc_437  1
    order_0_2  connected_order_arc_460  -1
    order_0_2  connected_order_arc_462  -1
    order_0_2  connected_order_arc_464  -1
    order_0_2  connected_order_arc_466  -1
    order_0_2  connected_order_arc_468  -1
    order_0_2  connected_order_arc_470  -1
    order_0_2  connected_order_arc_472  -1
    order_0_2  connected_order_arc_474  -1
    order_0_2  connected_order_arc_476  -1
    order_0_2  connected_order_arc_478  -1
    order_0_2  connected_order_arc_480  -1
    order_0_2  connected_order_arc_485  1
    order_0_2  connected_order_arc_508  1
    order_0_2  connected_order_arc_531  1
    order_0_2  connected_order_arc_554  1
    order_0_2  connected_order_arc_577  1
    order_0_2  connected_order_arc_600  1
    order_0_2  connected_order_arc_623  1
    order_0_2  connected_order_arc_646  1
    order_0_2  connected_order_arc_669  1
    order_0_2  connected_order_arc_692  1
    order_0_2  order_active_lb_722  1
    order_0_2  order_active_ub_723  1
    order_0_2  fixed_segment_relative_order_789  1
    order_0_2  fixed_segment_relative_order_790  -1
    visit_0_3  out_degree_727  -1
    visit_0_3  in_degree_728  -1
    visit_0_3  order_active_lb_729  -1
    visit_0_3  order_active_ub_730  -12
    order_0_3  connected_order_arc_439  1
    order_0_3  connected_order_arc_462  1
    order_0_3  connected_order_arc_483  -1
    order_0_3  connected_order_arc_485  -1
    order_0_3  connected_order_arc_487  -1
    order_0_3  connected_order_arc_489  -1
    order_0_3  connected_order_arc_491  -1
    order_0_3  connected_order_arc_493  -1
    order_0_3  connected_order_arc_495  -1
    order_0_3  connected_order_arc_497  -1
    order_0_3  connected_order_arc_499  -1
    order_0_3  connected_order_arc_501  -1
    order_0_3  connected_order_arc_503  -1
    order_0_3  connected_order_arc_510  1
    order_0_3  connected_order_arc_533  1
    order_0_3  connected_order_arc_556  1
    order_0_3  connected_order_arc_579  1
    order_0_3  connected_order_arc_602  1
    order_0_3  connected_order_arc_625  1
    order_0_3  connected_order_arc_648  1
    order_0_3  connected_order_arc_671  1
    order_0_3  connected_order_arc_694  1
    order_0_3  order_active_lb_729  1
    order_0_3  order_active_ub_730  1
    order_0_3  fixed_segment_relative_order_790  1
    order_0_3  fixed_segment_relative_order_791  -1
    visit_0_4  out_degree_734  -1
    visit_0_4  in_degree_735  -1
    visit_0_4  order_active_lb_736  -1
    visit_0_4  order_active_ub_737  -12
    order_0_4  connected_order_arc_441  1
    order_0_4  connected_order_arc_464  1
    order_0_4  connected_order_arc_487  1
    order_0_4  connected_order_arc_506  -1
    order_0_4  connected_order_arc_508  -1
    order_0_4  connected_order_arc_510  -1
    order_0_4  connected_order_arc_512  -1
    order_0_4  connected_order_arc_514  -1
    order_0_4  connected_order_arc_516  -1
    order_0_4  connected_order_arc_518  -1
    order_0_4  connected_order_arc_520  -1
    order_0_4  connected_order_arc_522  -1
    order_0_4  connected_order_arc_524  -1
    order_0_4  connected_order_arc_526  -1
    order_0_4  connected_order_arc_535  1
    order_0_4  connected_order_arc_558  1
    order_0_4  connected_order_arc_581  1
    order_0_4  connected_order_arc_604  1
    order_0_4  connected_order_arc_627  1
    order_0_4  connected_order_arc_650  1
    order_0_4  connected_order_arc_673  1
    order_0_4  connected_order_arc_696  1
    order_0_4  order_active_lb_736  1
    order_0_4  order_active_ub_737  1
    order_0_4  fixed_segment_relative_order_791  1
    visit_0_14  out_degree_741  -1
    visit_0_14  in_degree_742  -1
    visit_0_14  order_active_lb_743  -1
    visit_0_14  order_active_ub_744  -12
    visit_0_14  service_visit_def_745  -1
    order_0_14  connected_order_arc_443  1
    order_0_14  connected_order_arc_466  1
    order_0_14  connected_order_arc_489  1
    order_0_14  connected_order_arc_512  1
    order_0_14  connected_order_arc_529  -1
    order_0_14  connected_order_arc_531  -1
    order_0_14  connected_order_arc_533  -1
    order_0_14  connected_order_arc_535  -1
    order_0_14  connected_order_arc_537  -1
    order_0_14  connected_order_arc_539  -1
    order_0_14  connected_order_arc_541  -1
    order_0_14  connected_order_arc_543  -1
    order_0_14  connected_order_arc_545  -1
    order_0_14  connected_order_arc_547  -1
    order_0_14  connected_order_arc_549  -1
    order_0_14  connected_order_arc_560  1
    order_0_14  connected_order_arc_583  1
    order_0_14  connected_order_arc_606  1
    order_0_14  connected_order_arc_629  1
    order_0_14  connected_order_arc_652  1
    order_0_14  connected_order_arc_675  1
    order_0_14  connected_order_arc_698  1
    order_0_14  order_active_lb_743  1
    order_0_14  order_active_ub_744  1
    visit_0_15  out_degree_747  -1
    visit_0_15  in_degree_748  -1
    visit_0_15  order_active_lb_749  -1
    visit_0_15  order_active_ub_750  -12
    visit_0_15  service_visit_def_751  -1
    order_0_15  connected_order_arc_445  1
    order_0_15  connected_order_arc_468  1
    order_0_15  connected_order_arc_491  1
    order_0_15  connected_order_arc_514  1
    order_0_15  connected_order_arc_537  1
    order_0_15  connected_order_arc_552  -1
    order_0_15  connected_order_arc_554  -1
    order_0_15  connected_order_arc_556  -1
    order_0_15  connected_order_arc_558  -1
    order_0_15  connected_order_arc_560  -1
    order_0_15  connected_order_arc_562  -1
    order_0_15  connected_order_arc_564  -1
    order_0_15  connected_order_arc_566  -1
    order_0_15  connected_order_arc_568  -1
    order_0_15  connected_order_arc_570  -1
    order_0_15  connected_order_arc_572  -1
    order_0_15  connected_order_arc_585  1
    order_0_15  connected_order_arc_608  1
    order_0_15  connected_order_arc_631  1
    order_0_15  connected_order_arc_654  1
    order_0_15  connected_order_arc_677  1
    order_0_15  connected_order_arc_700  1
    order_0_15  order_active_lb_749  1
    order_0_15  order_active_ub_750  1
    visit_0_16  out_degree_753  -1
    visit_0_16  in_degree_754  -1
    visit_0_16  order_active_lb_755  -1
    visit_0_16  order_active_ub_756  -12
    visit_0_16  service_visit_def_757  -1
    order_0_16  connected_order_arc_447  1
    order_0_16  connected_order_arc_470  1
    order_0_16  connected_order_arc_493  1
    order_0_16  connected_order_arc_516  1
    order_0_16  connected_order_arc_539  1
    order_0_16  connected_order_arc_562  1
    order_0_16  connected_order_arc_575  -1
    order_0_16  connected_order_arc_577  -1
    order_0_16  connected_order_arc_579  -1
    order_0_16  connected_order_arc_581  -1
    order_0_16  connected_order_arc_583  -1
    order_0_16  connected_order_arc_585  -1
    order_0_16  connected_order_arc_587  -1
    order_0_16  connected_order_arc_589  -1
    order_0_16  connected_order_arc_591  -1
    order_0_16  connected_order_arc_593  -1
    order_0_16  connected_order_arc_595  -1
    order_0_16  connected_order_arc_610  1
    order_0_16  connected_order_arc_633  1
    order_0_16  connected_order_arc_656  1
    order_0_16  connected_order_arc_679  1
    order_0_16  connected_order_arc_702  1
    order_0_16  order_active_lb_755  1
    order_0_16  order_active_ub_756  1
    visit_0_17  out_degree_759  -1
    visit_0_17  in_degree_760  -1
    visit_0_17  order_active_lb_761  -1
    visit_0_17  order_active_ub_762  -12
    visit_0_17  service_visit_def_763  -1
    order_0_17  connected_order_arc_449  1
    order_0_17  connected_order_arc_472  1
    order_0_17  connected_order_arc_495  1
    order_0_17  connected_order_arc_518  1
    order_0_17  connected_order_arc_541  1
    order_0_17  connected_order_arc_564  1
    order_0_17  connected_order_arc_587  1
    order_0_17  connected_order_arc_598  -1
    order_0_17  connected_order_arc_600  -1
    order_0_17  connected_order_arc_602  -1
    order_0_17  connected_order_arc_604  -1
    order_0_17  connected_order_arc_606  -1
    order_0_17  connected_order_arc_608  -1
    order_0_17  connected_order_arc_610  -1
    order_0_17  connected_order_arc_612  -1
    order_0_17  connected_order_arc_614  -1
    order_0_17  connected_order_arc_616  -1
    order_0_17  connected_order_arc_618  -1
    order_0_17  connected_order_arc_635  1
    order_0_17  connected_order_arc_658  1
    order_0_17  connected_order_arc_681  1
    order_0_17  connected_order_arc_704  1
    order_0_17  order_active_lb_761  1
    order_0_17  order_active_ub_762  1
    visit_0_18  out_degree_765  -1
    visit_0_18  in_degree_766  -1
    visit_0_18  order_active_lb_767  -1
    visit_0_18  order_active_ub_768  -12
    visit_0_18  service_visit_def_769  -1
    order_0_18  connected_order_arc_451  1
    order_0_18  connected_order_arc_474  1
    order_0_18  connected_order_arc_497  1
    order_0_18  connected_order_arc_520  1
    order_0_18  connected_order_arc_543  1
    order_0_18  connected_order_arc_566  1
    order_0_18  connected_order_arc_589  1
    order_0_18  connected_order_arc_612  1
    order_0_18  connected_order_arc_621  -1
    order_0_18  connected_order_arc_623  -1
    order_0_18  connected_order_arc_625  -1
    order_0_18  connected_order_arc_627  -1
    order_0_18  connected_order_arc_629  -1
    order_0_18  connected_order_arc_631  -1
    order_0_18  connected_order_arc_633  -1
    order_0_18  connected_order_arc_635  -1
    order_0_18  connected_order_arc_637  -1
    order_0_18  connected_order_arc_639  -1
    order_0_18  connected_order_arc_641  -1
    order_0_18  connected_order_arc_660  1
    order_0_18  connected_order_arc_683  1
    order_0_18  connected_order_arc_706  1
    order_0_18  order_active_lb_767  1
    order_0_18  order_active_ub_768  1
    visit_0_19  out_degree_771  -1
    visit_0_19  in_degree_772  -1
    visit_0_19  order_active_lb_773  -1
    visit_0_19  order_active_ub_774  -12
    visit_0_19  service_visit_def_775  -1
    order_0_19  connected_order_arc_453  1
    order_0_19  connected_order_arc_476  1
    order_0_19  connected_order_arc_499  1
    order_0_19  connected_order_arc_522  1
    order_0_19  connected_order_arc_545  1
    order_0_19  connected_order_arc_568  1
    order_0_19  connected_order_arc_591  1
    order_0_19  connected_order_arc_614  1
    order_0_19  connected_order_arc_637  1
    order_0_19  connected_order_arc_644  -1
    order_0_19  connected_order_arc_646  -1
    order_0_19  connected_order_arc_648  -1
    order_0_19  connected_order_arc_650  -1
    order_0_19  connected_order_arc_652  -1
    order_0_19  connected_order_arc_654  -1
    order_0_19  connected_order_arc_656  -1
    order_0_19  connected_order_arc_658  -1
    order_0_19  connected_order_arc_660  -1
    order_0_19  connected_order_arc_662  -1
    order_0_19  connected_order_arc_664  -1
    order_0_19  connected_order_arc_685  1
    order_0_19  connected_order_arc_708  1
    order_0_19  order_active_lb_773  1
    order_0_19  order_active_ub_774  1
    visit_0_20  out_degree_777  -1
    visit_0_20  in_degree_778  -1
    visit_0_20  order_active_lb_779  -1
    visit_0_20  order_active_ub_780  -12
    visit_0_20  service_visit_def_781  -1
    order_0_20  connected_order_arc_455  1
    order_0_20  connected_order_arc_478  1
    order_0_20  connected_order_arc_501  1
    order_0_20  connected_order_arc_524  1
    order_0_20  connected_order_arc_547  1
    order_0_20  connected_order_arc_570  1
    order_0_20  connected_order_arc_593  1
    order_0_20  connected_order_arc_616  1
    order_0_20  connected_order_arc_639  1
    order_0_20  connected_order_arc_662  1
    order_0_20  connected_order_arc_667  -1
    order_0_20  connected_order_arc_669  -1
    order_0_20  connected_order_arc_671  -1
    order_0_20  connected_order_arc_673  -1
    order_0_20  connected_order_arc_675  -1
    order_0_20  connected_order_arc_677  -1
    order_0_20  connected_order_arc_679  -1
    order_0_20  connected_order_arc_681  -1
    order_0_20  connected_order_arc_683  -1
    order_0_20  connected_order_arc_685  -1
    order_0_20  connected_order_arc_687  -1
    order_0_20  connected_order_arc_710  1
    order_0_20  order_active_lb_779  1
    order_0_20  order_active_ub_780  1
    visit_0_21  out_degree_783  -1
    visit_0_21  in_degree_784  -1
    visit_0_21  order_active_lb_785  -1
    visit_0_21  order_active_ub_786  -12
    visit_0_21  service_visit_def_787  -1
    order_0_21  connected_order_arc_457  1
    order_0_21  connected_order_arc_480  1
    order_0_21  connected_order_arc_503  1
    order_0_21  connected_order_arc_526  1
    order_0_21  connected_order_arc_549  1
    order_0_21  connected_order_arc_572  1
    order_0_21  connected_order_arc_595  1
    order_0_21  connected_order_arc_618  1
    order_0_21  connected_order_arc_641  1
    order_0_21  connected_order_arc_664  1
    order_0_21  connected_order_arc_687  1
    order_0_21  connected_order_arc_690  -1
    order_0_21  connected_order_arc_692  -1
    order_0_21  connected_order_arc_694  -1
    order_0_21  connected_order_arc_696  -1
    order_0_21  connected_order_arc_698  -1
    order_0_21  connected_order_arc_700  -1
    order_0_21  connected_order_arc_702  -1
    order_0_21  connected_order_arc_704  -1
    order_0_21  connected_order_arc_706  -1
    order_0_21  connected_order_arc_708  -1
    order_0_21  connected_order_arc_710  -1
    order_0_21  order_active_lb_785  1
    order_0_21  order_active_ub_786  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_0  arc_capacity_422  -20
    arc_0_0_0  depot_departure_or_bypass_711  1
    arc_0_0_0  depot_return_or_bypass_712  1
    MARKER    'MARKER'                 'INTEND'
    load_0_0_0  arc_capacity_422  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_1  arc_capacity_423  -20
    arc_0_0_1  depot_departure_or_bypass_711  1
    arc_0_0_1  in_degree_714  1
    arc_0_0_1  original_T_including_depot_unload_792  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_1  arc_capacity_423  1
    load_0_0_1  segment_load_conservation_717  -1
    load_0_0_1  segment_prefix_lb_718  1
    load_0_0_1  segment_prefix_ub_719  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_2  arc_capacity_424  -20
    arc_0_0_2  depot_departure_or_bypass_711  1
    arc_0_0_2  in_degree_721  1
    arc_0_0_2  original_T_including_depot_unload_792  7.2130540230577469e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_2  arc_capacity_424  1
    load_0_0_2  segment_load_conservation_724  -1
    load_0_0_2  segment_prefix_lb_725  1
    load_0_0_2  segment_prefix_ub_726  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_3  arc_capacity_425  -20
    arc_0_0_3  depot_departure_or_bypass_711  1
    arc_0_0_3  in_degree_728  1
    arc_0_0_3  original_T_including_depot_unload_792  4.9403722507151832e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_3  arc_capacity_425  1
    load_0_0_3  segment_load_conservation_731  -1
    load_0_0_3  segment_prefix_lb_732  1
    load_0_0_3  segment_prefix_ub_733  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_4  arc_capacity_426  -20
    arc_0_0_4  depot_departure_or_bypass_711  1
    arc_0_0_4  in_degree_735  1
    arc_0_0_4  original_T_including_depot_unload_792  6.6653528395596720e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_4  arc_capacity_426  1
    load_0_0_4  segment_load_conservation_738  -1
    load_0_0_4  segment_prefix_lb_739  1
    load_0_0_4  segment_prefix_ub_740  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_14  arc_capacity_427  -20
    arc_0_0_14  depot_departure_or_bypass_711  1
    arc_0_0_14  in_degree_742  1
    arc_0_0_14  original_T_including_depot_unload_792  4.6364706268001146e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_14  arc_capacity_427  1
    load_0_0_14  free_load_conservation_746  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_15  arc_capacity_428  -20
    arc_0_0_15  depot_departure_or_bypass_711  1
    arc_0_0_15  in_degree_748  1
    arc_0_0_15  original_T_including_depot_unload_792  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_15  arc_capacity_428  1
    load_0_0_15  free_load_conservation_752  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_16  arc_capacity_429  -20
    arc_0_0_16  depot_departure_or_bypass_711  1
    arc_0_0_16  in_degree_754  1
    arc_0_0_16  original_T_including_depot_unload_792  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_16  arc_capacity_429  1
    load_0_0_16  free_load_conservation_758  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_17  arc_capacity_430  -20
    arc_0_0_17  depot_departure_or_bypass_711  1
    arc_0_0_17  in_degree_760  1
    arc_0_0_17  original_T_including_depot_unload_792  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_17  arc_capacity_430  1
    load_0_0_17  free_load_conservation_764  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_18  arc_capacity_431  -20
    arc_0_0_18  depot_departure_or_bypass_711  1
    arc_0_0_18  in_degree_766  1
    arc_0_0_18  original_T_including_depot_unload_792  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_18  arc_capacity_431  1
    load_0_0_18  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_19  arc_capacity_432  -20
    arc_0_0_19  depot_departure_or_bypass_711  1
    arc_0_0_19  in_degree_772  1
    arc_0_0_19  original_T_including_depot_unload_792  5.9431738885389052e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_19  arc_capacity_432  1
    load_0_0_19  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_20  arc_capacity_433  -20
    arc_0_0_20  depot_departure_or_bypass_711  1
    arc_0_0_20  in_degree_778  1
    arc_0_0_20  original_T_including_depot_unload_792  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_20  arc_capacity_433  1
    load_0_0_20  free_load_conservation_782  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_21  arc_capacity_434  -20
    arc_0_0_21  depot_departure_or_bypass_711  1
    arc_0_0_21  in_degree_784  1
    arc_0_0_21  original_T_including_depot_unload_792  7.2571167924583824e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_21  arc_capacity_434  1
    load_0_0_21  free_load_conservation_788  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_0  arc_capacity_435  -20
    arc_0_1_0  depot_return_or_bypass_712  1
    arc_0_1_0  out_degree_713  1
    arc_0_1_0  original_T_including_depot_unload_792  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_0  arc_capacity_435  1
    load_0_1_0  segment_load_conservation_717  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_2  arc_capacity_436  -20
    arc_0_1_2  connected_order_arc_437  -13
    arc_0_1_2  out_degree_713  1
    arc_0_1_2  in_degree_721  1
    arc_0_1_2  original_T_including_depot_unload_792  4.4733407106545638e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_2  arc_capacity_436  1
    load_0_1_2  segment_load_conservation_717  1
    load_0_1_2  segment_load_conservation_724  -1
    load_0_1_2  segment_prefix_lb_725  1
    load_0_1_2  segment_prefix_ub_726  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_3  arc_capacity_438  -20
    arc_0_1_3  connected_order_arc_439  -13
    arc_0_1_3  out_degree_713  1
    arc_0_1_3  in_degree_728  1
    arc_0_1_3  original_T_including_depot_unload_792  2.2271784981792140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_3  arc_capacity_438  1
    load_0_1_3  segment_load_conservation_717  1
    load_0_1_3  segment_load_conservation_731  -1
    load_0_1_3  segment_prefix_lb_732  1
    load_0_1_3  segment_prefix_ub_733  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_4  arc_capacity_440  -20
    arc_0_1_4  connected_order_arc_441  -13
    arc_0_1_4  out_degree_713  1
    arc_0_1_4  in_degree_735  1
    arc_0_1_4  original_T_including_depot_unload_792  628.141943094385
    MARKER    'MARKER'                 'INTEND'
    load_0_1_4  arc_capacity_440  1
    load_0_1_4  segment_load_conservation_717  1
    load_0_1_4  segment_load_conservation_738  -1
    load_0_1_4  segment_prefix_lb_739  1
    load_0_1_4  segment_prefix_ub_740  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_14  arc_capacity_442  -20
    arc_0_1_14  connected_order_arc_443  -13
    arc_0_1_14  out_degree_713  1
    arc_0_1_14  in_degree_742  1
    arc_0_1_14  original_T_including_depot_unload_792  6.7517249538835438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_14  arc_capacity_442  1
    load_0_1_14  segment_load_conservation_717  1
    load_0_1_14  free_load_conservation_746  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_15  arc_capacity_444  -20
    arc_0_1_15  connected_order_arc_445  -13
    arc_0_1_15  out_degree_713  1
    arc_0_1_15  in_degree_748  1
    arc_0_1_15  original_T_including_depot_unload_792  4.3618991857210159e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_15  arc_capacity_444  1
    load_0_1_15  segment_load_conservation_717  1
    load_0_1_15  free_load_conservation_752  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_16  arc_capacity_446  -20
    arc_0_1_16  connected_order_arc_447  -13
    arc_0_1_16  out_degree_713  1
    arc_0_1_16  in_degree_754  1
    arc_0_1_16  original_T_including_depot_unload_792  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_16  arc_capacity_446  1
    load_0_1_16  segment_load_conservation_717  1
    load_0_1_16  free_load_conservation_758  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_17  arc_capacity_448  -20
    arc_0_1_17  connected_order_arc_449  -13
    arc_0_1_17  out_degree_713  1
    arc_0_1_17  in_degree_760  1
    arc_0_1_17  original_T_including_depot_unload_792  9.3905252655669165e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_17  arc_capacity_448  1
    load_0_1_17  segment_load_conservation_717  1
    load_0_1_17  free_load_conservation_764  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_18  arc_capacity_450  -20
    arc_0_1_18  connected_order_arc_451  -13
    arc_0_1_18  out_degree_713  1
    arc_0_1_18  in_degree_766  1
    arc_0_1_18  original_T_including_depot_unload_792  4.5128490093732506e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_18  arc_capacity_450  1
    load_0_1_18  segment_load_conservation_717  1
    load_0_1_18  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_19  arc_capacity_452  -20
    arc_0_1_19  connected_order_arc_453  -13
    arc_0_1_19  out_degree_713  1
    arc_0_1_19  in_degree_772  1
    arc_0_1_19  original_T_including_depot_unload_792  6.9736186698570737e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_19  arc_capacity_452  1
    load_0_1_19  segment_load_conservation_717  1
    load_0_1_19  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_20  arc_capacity_454  -20
    arc_0_1_20  connected_order_arc_455  -13
    arc_0_1_20  out_degree_713  1
    arc_0_1_20  in_degree_778  1
    arc_0_1_20  original_T_including_depot_unload_792  1.5902582434549993e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_20  arc_capacity_454  1
    load_0_1_20  segment_load_conservation_717  1
    load_0_1_20  free_load_conservation_782  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_21  arc_capacity_456  -20
    arc_0_1_21  connected_order_arc_457  -13
    arc_0_1_21  out_degree_713  1
    arc_0_1_21  in_degree_784  1
    arc_0_1_21  original_T_including_depot_unload_792  8.7876124407720954e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_21  arc_capacity_456  1
    load_0_1_21  segment_load_conservation_717  1
    load_0_1_21  free_load_conservation_788  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_0  arc_capacity_458  -20
    arc_0_2_0  depot_return_or_bypass_712  1
    arc_0_2_0  out_degree_720  1
    arc_0_2_0  original_T_including_depot_unload_792  7.2130540230577469e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_0  arc_capacity_458  1
    load_0_2_0  segment_load_conservation_724  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_1  arc_capacity_459  -20
    arc_0_2_1  connected_order_arc_460  -13
    arc_0_2_1  in_degree_714  1
    arc_0_2_1  out_degree_720  1
    arc_0_2_1  original_T_including_depot_unload_792  4.4733407106545638e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_1  arc_capacity_459  1
    load_0_2_1  segment_load_conservation_717  -1
    load_0_2_1  segment_prefix_lb_718  1
    load_0_2_1  segment_prefix_ub_719  1
    load_0_2_1  segment_load_conservation_724  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_3  arc_capacity_461  -20
    arc_0_2_3  connected_order_arc_462  -13
    arc_0_2_3  out_degree_720  1
    arc_0_2_3  in_degree_728  1
    arc_0_2_3  original_T_including_depot_unload_792  2.2729932910497158e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_3  arc_capacity_461  1
    load_0_2_3  segment_load_conservation_724  1
    load_0_2_3  segment_load_conservation_731  -1
    load_0_2_3  segment_prefix_lb_732  1
    load_0_2_3  segment_prefix_ub_733  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_4  arc_capacity_463  -20
    arc_0_2_4  connected_order_arc_464  -13
    arc_0_2_4  out_degree_720  1
    arc_0_2_4  in_degree_735  1
    arc_0_2_4  original_T_including_depot_unload_792  880.352897387315
    MARKER    'MARKER'                 'INTEND'
    load_0_2_4  arc_capacity_463  1
    load_0_2_4  segment_load_conservation_724  1
    load_0_2_4  segment_load_conservation_738  -1
    load_0_2_4  segment_prefix_lb_739  1
    load_0_2_4  segment_prefix_ub_740  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_14  arc_capacity_465  -20
    arc_0_2_14  connected_order_arc_466  -13
    arc_0_2_14  out_degree_720  1
    arc_0_2_14  in_degree_742  1
    arc_0_2_14  original_T_including_depot_unload_792  1.1090437276384578e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_14  arc_capacity_465  1
    load_0_2_14  segment_load_conservation_724  1
    load_0_2_14  free_load_conservation_746  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_15  arc_capacity_467  -20
    arc_0_2_15  connected_order_arc_468  -13
    arc_0_2_15  out_degree_720  1
    arc_0_2_15  in_degree_748  1
    arc_0_2_15  original_T_including_depot_unload_792  8.6713096341893186e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_15  arc_capacity_467  1
    load_0_2_15  segment_load_conservation_724  1
    load_0_2_15  free_load_conservation_752  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_16  arc_capacity_469  -20
    arc_0_2_16  connected_order_arc_470  -13
    arc_0_2_16  out_degree_720  1
    arc_0_2_16  in_degree_754  1
    arc_0_2_16  original_T_including_depot_unload_792  1.7303231472353602e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_16  arc_capacity_469  1
    load_0_2_16  segment_load_conservation_724  1
    load_0_2_16  free_load_conservation_758  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_17  arc_capacity_471  -20
    arc_0_2_17  connected_order_arc_472  -13
    arc_0_2_17  out_degree_720  1
    arc_0_2_17  in_degree_760  1
    arc_0_2_17  original_T_including_depot_unload_792  1.3669225770244122e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_17  arc_capacity_471  1
    load_0_2_17  segment_load_conservation_724  1
    load_0_2_17  free_load_conservation_764  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_18  arc_capacity_473  -20
    arc_0_2_18  connected_order_arc_474  -13
    arc_0_2_18  out_degree_720  1
    arc_0_2_18  in_degree_766  1
    arc_0_2_18  original_T_including_depot_unload_792  4.6128219015626763e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_18  arc_capacity_473  1
    load_0_2_18  segment_load_conservation_724  1
    load_0_2_18  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_19  arc_capacity_475  -20
    arc_0_2_19  connected_order_arc_476  -13
    arc_0_2_19  out_degree_720  1
    arc_0_2_19  in_degree_772  1
    arc_0_2_19  original_T_including_depot_unload_792  1.0687086794720833e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_19  arc_capacity_475  1
    load_0_2_19  segment_load_conservation_724  1
    load_0_2_19  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_20  arc_capacity_477  -20
    arc_0_2_20  connected_order_arc_478  -13
    arc_0_2_20  out_degree_720  1
    arc_0_2_20  in_degree_778  1
    arc_0_2_20  original_T_including_depot_unload_792  2.0162129512771592e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_20  arc_capacity_477  1
    load_0_2_20  segment_load_conservation_724  1
    load_0_2_20  free_load_conservation_782  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_21  arc_capacity_479  -20
    arc_0_2_21  connected_order_arc_480  -13
    arc_0_2_21  out_degree_720  1
    arc_0_2_21  in_degree_784  1
    arc_0_2_21  original_T_including_depot_unload_792  1.2724370432148053e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_21  arc_capacity_479  1
    load_0_2_21  segment_load_conservation_724  1
    load_0_2_21  free_load_conservation_788  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_0  arc_capacity_481  -20
    arc_0_3_0  depot_return_or_bypass_712  1
    arc_0_3_0  out_degree_727  1
    arc_0_3_0  original_T_including_depot_unload_792  9.5330620720858735e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_0  arc_capacity_481  1
    load_0_3_0  segment_load_conservation_731  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_1  arc_capacity_482  -20
    arc_0_3_1  connected_order_arc_483  -13
    arc_0_3_1  in_degree_714  1
    arc_0_3_1  out_degree_727  1
    arc_0_3_1  original_T_including_depot_unload_792  8.4968861461374138e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_1  arc_capacity_482  1
    load_0_3_1  segment_load_conservation_717  -1
    load_0_3_1  segment_prefix_lb_718  1
    load_0_3_1  segment_prefix_ub_719  1
    load_0_3_1  segment_load_conservation_731  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_2  arc_capacity_484  -20
    arc_0_3_2  connected_order_arc_485  -13
    arc_0_3_2  in_degree_721  1
    arc_0_3_2  out_degree_727  1
    arc_0_3_2  original_T_including_depot_unload_792  9.6598937061987863e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_2  arc_capacity_484  1
    load_0_3_2  segment_load_conservation_724  -1
    load_0_3_2  segment_prefix_lb_725  1
    load_0_3_2  segment_prefix_ub_726  1
    load_0_3_2  segment_load_conservation_731  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_4  arc_capacity_486  -20
    arc_0_3_4  connected_order_arc_487  -13
    arc_0_3_4  out_degree_727  1
    arc_0_3_4  in_degree_735  1
    arc_0_3_4  original_T_including_depot_unload_792  3.1728416035596246e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_4  arc_capacity_486  1
    load_0_3_4  segment_load_conservation_731  1
    load_0_3_4  segment_load_conservation_738  -1
    load_0_3_4  segment_prefix_lb_739  1
    load_0_3_4  segment_prefix_ub_740  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_14  arc_capacity_488  -20
    arc_0_3_14  connected_order_arc_489  -13
    arc_0_3_14  out_degree_727  1
    arc_0_3_14  in_degree_742  1
    arc_0_3_14  original_T_including_depot_unload_792  897.031483121361
    MARKER    'MARKER'                 'INTEND'
    load_0_3_14  arc_capacity_488  1
    load_0_3_14  segment_load_conservation_731  1
    load_0_3_14  free_load_conservation_746  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_15  arc_capacity_490  -20
    arc_0_3_15  connected_order_arc_491  -13
    arc_0_3_15  out_degree_727  1
    arc_0_3_15  in_degree_748  1
    arc_0_3_15  original_T_including_depot_unload_792  7.8947565022471792e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_15  arc_capacity_490  1
    load_0_3_15  segment_load_conservation_731  1
    load_0_3_15  free_load_conservation_752  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_16  arc_capacity_492  -20
    arc_0_3_16  connected_order_arc_493  -13
    arc_0_3_16  out_degree_727  1
    arc_0_3_16  in_degree_754  1
    arc_0_3_16  original_T_including_depot_unload_792  1.9462564869425171e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_16  arc_capacity_492  1
    load_0_3_16  segment_load_conservation_731  1
    load_0_3_16  free_load_conservation_758  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_17  arc_capacity_494  -20
    arc_0_3_17  connected_order_arc_495  -13
    arc_0_3_17  out_degree_727  1
    arc_0_3_17  in_degree_760  1
    arc_0_3_17  original_T_including_depot_unload_792  1.0105932041904148e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_17  arc_capacity_494  1
    load_0_3_17  segment_load_conservation_731  1
    load_0_3_17  free_load_conservation_764  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_18  arc_capacity_496  -20
    arc_0_3_18  connected_order_arc_497  -13
    arc_0_3_18  out_degree_727  1
    arc_0_3_18  in_degree_766  1
    arc_0_3_18  original_T_including_depot_unload_792  1.2674827380665711e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_18  arc_capacity_496  1
    load_0_3_18  segment_load_conservation_731  1
    load_0_3_18  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_19  arc_capacity_498  -20
    arc_0_3_19  connected_order_arc_499  -13
    arc_0_3_19  out_degree_727  1
    arc_0_3_19  in_degree_772  1
    arc_0_3_19  original_T_including_depot_unload_792  6.2159179673866879e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_19  arc_capacity_498  1
    load_0_3_19  segment_load_conservation_731  1
    load_0_3_19  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_20  arc_capacity_500  -20
    arc_0_3_20  connected_order_arc_501  -13
    arc_0_3_20  out_degree_727  1
    arc_0_3_20  in_degree_778  1
    arc_0_3_20  original_T_including_depot_unload_792  1.5117151439160034e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_20  arc_capacity_500  1
    load_0_3_20  segment_load_conservation_731  1
    load_0_3_20  free_load_conservation_782  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_21  arc_capacity_502  -20
    arc_0_3_21  connected_order_arc_503  -13
    arc_0_3_21  out_degree_727  1
    arc_0_3_21  in_degree_784  1
    arc_0_3_21  original_T_including_depot_unload_792  7.9206888044020991e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_21  arc_capacity_502  1
    load_0_3_21  segment_load_conservation_731  1
    load_0_3_21  free_load_conservation_788  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_0  arc_capacity_504  -20
    arc_0_4_0  depot_return_or_bypass_712  1
    arc_0_4_0  out_degree_734  1
    arc_0_4_0  original_T_including_depot_unload_792  6.6653528395596720e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_0  arc_capacity_504  1
    load_0_4_0  segment_load_conservation_738  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_1  arc_capacity_505  -20
    arc_0_4_1  connected_order_arc_506  -13
    arc_0_4_1  in_degree_714  1
    arc_0_4_1  out_degree_734  1
    arc_0_4_1  original_T_including_depot_unload_792  628.141943094385
    MARKER    'MARKER'                 'INTEND'
    load_0_4_1  arc_capacity_505  1
    load_0_4_1  segment_load_conservation_717  -1
    load_0_4_1  segment_prefix_lb_718  1
    load_0_4_1  segment_prefix_ub_719  1
    load_0_4_1  segment_load_conservation_738  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_2  arc_capacity_507  -20
    arc_0_4_2  connected_order_arc_508  -13
    arc_0_4_2  in_degree_721  1
    arc_0_4_2  out_degree_734  1
    arc_0_4_2  original_T_including_depot_unload_792  880.352897387315
    MARKER    'MARKER'                 'INTEND'
    load_0_4_2  arc_capacity_507  1
    load_0_4_2  segment_load_conservation_724  -1
    load_0_4_2  segment_prefix_lb_725  1
    load_0_4_2  segment_prefix_ub_726  1
    load_0_4_2  segment_load_conservation_738  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_3  arc_capacity_509  -20
    arc_0_4_3  connected_order_arc_510  -13
    arc_0_4_3  in_degree_728  1
    arc_0_4_3  out_degree_734  1
    arc_0_4_3  original_T_including_depot_unload_792  750.067997850428
    MARKER    'MARKER'                 'INTEND'
    load_0_4_3  arc_capacity_509  1
    load_0_4_3  segment_load_conservation_731  -1
    load_0_4_3  segment_prefix_lb_732  1
    load_0_4_3  segment_prefix_ub_733  1
    load_0_4_3  segment_load_conservation_738  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_14  arc_capacity_511  -20
    arc_0_4_14  connected_order_arc_512  -13
    arc_0_4_14  out_degree_734  1
    arc_0_4_14  in_degree_742  1
    arc_0_4_14  original_T_including_depot_unload_792  5.8442598457899078e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_14  arc_capacity_511  1
    load_0_4_14  segment_load_conservation_738  1
    load_0_4_14  free_load_conservation_746  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_15  arc_capacity_513  -20
    arc_0_4_15  connected_order_arc_514  -13
    arc_0_4_15  out_degree_734  1
    arc_0_4_15  in_degree_748  1
    arc_0_4_15  original_T_including_depot_unload_792  4.7597588586788925e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_15  arc_capacity_513  1
    load_0_4_15  segment_load_conservation_738  1
    load_0_4_15  free_load_conservation_752  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_16  arc_capacity_515  -20
    arc_0_4_16  connected_order_arc_516  -13
    arc_0_4_16  out_degree_734  1
    arc_0_4_16  in_degree_754  1
    arc_0_4_16  original_T_including_depot_unload_792  1.6292966848558842e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_16  arc_capacity_515  1
    load_0_4_16  segment_load_conservation_738  1
    load_0_4_16  free_load_conservation_758  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_17  arc_capacity_517  -20
    arc_0_4_17  connected_order_arc_518  -13
    arc_0_4_17  out_degree_734  1
    arc_0_4_17  in_degree_760  1
    arc_0_4_17  original_T_including_depot_unload_792  7.2751050611121218e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_17  arc_capacity_517  1
    load_0_4_17  segment_load_conservation_738  1
    load_0_4_17  free_load_conservation_764  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_18  arc_capacity_519  -20
    arc_0_4_18  connected_order_arc_520  -13
    arc_0_4_18  out_degree_734  1
    arc_0_4_18  in_degree_766  1
    arc_0_4_18  original_T_including_depot_unload_792  1.0758099325648966e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_18  arc_capacity_519  1
    load_0_4_18  segment_load_conservation_738  1
    load_0_4_18  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_19  arc_capacity_521  -20
    arc_0_4_19  connected_order_arc_522  -13
    arc_0_4_19  out_degree_734  1
    arc_0_4_19  in_degree_772  1
    arc_0_4_19  original_T_including_depot_unload_792  3.2985327387120213e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_19  arc_capacity_521  1
    load_0_4_19  segment_load_conservation_738  1
    load_0_4_19  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_20  arc_capacity_523  -20
    arc_0_4_20  connected_order_arc_524  -13
    arc_0_4_20  out_degree_734  1
    arc_0_4_20  in_degree_778  1
    arc_0_4_20  original_T_including_depot_unload_792  1.2927075446362680e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_20  arc_capacity_523  1
    load_0_4_20  segment_load_conservation_738  1
    load_0_4_20  free_load_conservation_782  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_21  arc_capacity_525  -20
    arc_0_4_21  connected_order_arc_526  -13
    arc_0_4_21  out_degree_734  1
    arc_0_4_21  in_degree_784  1
    arc_0_4_21  original_T_including_depot_unload_792  5.2996691306068044e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_21  arc_capacity_525  1
    load_0_4_21  segment_load_conservation_738  1
    load_0_4_21  free_load_conservation_788  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_0  arc_capacity_527  -20
    arc_0_14_0  depot_return_or_bypass_712  1
    arc_0_14_0  out_degree_741  1
    arc_0_14_0  original_T_including_depot_unload_792  4.6364706268001146e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_0  arc_capacity_527  1
    load_0_14_0  free_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_1  arc_capacity_528  -20
    arc_0_14_1  connected_order_arc_529  -13
    arc_0_14_1  in_degree_714  1
    arc_0_14_1  out_degree_741  1
    arc_0_14_1  original_T_including_depot_unload_792  6.7517249538835438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_1  arc_capacity_528  1
    load_0_14_1  segment_load_conservation_717  -1
    load_0_14_1  segment_prefix_lb_718  1
    load_0_14_1  segment_prefix_ub_719  1
    load_0_14_1  free_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_2  arc_capacity_530  -20
    arc_0_14_2  connected_order_arc_531  -13
    arc_0_14_2  in_degree_721  1
    arc_0_14_2  out_degree_741  1
    arc_0_14_2  original_T_including_depot_unload_792  1.1090437276384578e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_2  arc_capacity_530  1
    load_0_14_2  segment_load_conservation_724  -1
    load_0_14_2  segment_prefix_lb_725  1
    load_0_14_2  segment_prefix_ub_726  1
    load_0_14_2  free_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_3  arc_capacity_532  -20
    arc_0_14_3  connected_order_arc_533  -13
    arc_0_14_3  in_degree_728  1
    arc_0_14_3  out_degree_741  1
    arc_0_14_3  original_T_including_depot_unload_792  8.9433085313747858e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_3  arc_capacity_532  1
    load_0_14_3  segment_load_conservation_731  -1
    load_0_14_3  segment_prefix_lb_732  1
    load_0_14_3  segment_prefix_ub_733  1
    load_0_14_3  free_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_4  arc_capacity_534  -20
    arc_0_14_4  connected_order_arc_535  -13
    arc_0_14_4  in_degree_735  1
    arc_0_14_4  out_degree_741  1
    arc_0_14_4  original_T_including_depot_unload_792  5.8442598457899078e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_4  arc_capacity_534  1
    load_0_14_4  segment_load_conservation_738  -1
    load_0_14_4  segment_prefix_lb_739  1
    load_0_14_4  segment_prefix_ub_740  1
    load_0_14_4  free_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_15  arc_capacity_536  -20
    arc_0_14_15  connected_order_arc_537  -13
    arc_0_14_15  out_degree_741  1
    arc_0_14_15  in_degree_748  1
    arc_0_14_15  original_T_including_depot_unload_792  2.4191291221621205e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_15  arc_capacity_536  1
    load_0_14_15  free_load_conservation_746  1
    load_0_14_15  free_load_conservation_752  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_16  arc_capacity_538  -20
    arc_0_14_16  connected_order_arc_539  -13
    arc_0_14_16  out_degree_741  1
    arc_0_14_16  in_degree_754  1
    arc_0_14_16  original_T_including_depot_unload_792  1075.72043838369
    MARKER    'MARKER'                 'INTEND'
    load_0_14_16  arc_capacity_538  1
    load_0_14_16  free_load_conservation_746  1
    load_0_14_16  free_load_conservation_758  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_17  arc_capacity_540  -20
    arc_0_14_17  connected_order_arc_541  -13
    arc_0_14_17  out_degree_741  1
    arc_0_14_17  in_degree_760  1
    arc_0_14_17  original_T_including_depot_unload_792  2.6602972191926557e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_17  arc_capacity_540  1
    load_0_14_17  free_load_conservation_746  1
    load_0_14_17  free_load_conservation_764  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_18  arc_capacity_542  -20
    arc_0_14_18  connected_order_arc_543  -13
    arc_0_14_18  out_degree_741  1
    arc_0_14_18  in_degree_766  1
    arc_0_14_18  original_T_including_depot_unload_792  1.0491196843462671e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_18  arc_capacity_542  1
    load_0_14_18  free_load_conservation_746  1
    load_0_14_18  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_19  arc_capacity_544  -20
    arc_0_14_19  connected_order_arc_545  -13
    arc_0_14_19  out_degree_741  1
    arc_0_14_19  in_degree_772  1
    arc_0_14_19  original_T_including_depot_unload_792  2.9706418113632907e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_19  arc_capacity_544  1
    load_0_14_19  free_load_conservation_746  1
    load_0_14_19  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_20  arc_capacity_546  -20
    arc_0_14_20  connected_order_arc_547  -13
    arc_0_14_20  out_degree_741  1
    arc_0_14_20  in_degree_778  1
    arc_0_14_20  original_T_including_depot_unload_792  9.1576870176747968e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_20  arc_capacity_546  1
    load_0_14_20  free_load_conservation_746  1
    load_0_14_20  free_load_conservation_782  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_21  arc_capacity_548  -20
    arc_0_14_21  connected_order_arc_549  -13
    arc_0_14_21  out_degree_741  1
    arc_0_14_21  in_degree_784  1
    arc_0_14_21  original_T_including_depot_unload_792  3.0055050459786975e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_21  arc_capacity_548  1
    load_0_14_21  free_load_conservation_746  1
    load_0_14_21  free_load_conservation_788  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_0  arc_capacity_550  -20
    arc_0_15_0  depot_return_or_bypass_712  1
    arc_0_15_0  out_degree_747  1
    arc_0_15_0  original_T_including_depot_unload_792  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_0  arc_capacity_550  1
    load_0_15_0  free_load_conservation_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_1  arc_capacity_551  -20
    arc_0_15_1  connected_order_arc_552  -13
    arc_0_15_1  in_degree_714  1
    arc_0_15_1  out_degree_747  1
    arc_0_15_1  original_T_including_depot_unload_792  4.3618991857210159e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_1  arc_capacity_551  1
    load_0_15_1  segment_load_conservation_717  -1
    load_0_15_1  segment_prefix_lb_718  1
    load_0_15_1  segment_prefix_ub_719  1
    load_0_15_1  free_load_conservation_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_2  arc_capacity_553  -20
    arc_0_15_2  connected_order_arc_554  -13
    arc_0_15_2  in_degree_721  1
    arc_0_15_2  out_degree_747  1
    arc_0_15_2  original_T_including_depot_unload_792  8.6713096341893186e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_2  arc_capacity_553  1
    load_0_15_2  segment_load_conservation_724  -1
    load_0_15_2  segment_prefix_lb_725  1
    load_0_15_2  segment_prefix_ub_726  1
    load_0_15_2  free_load_conservation_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_3  arc_capacity_555  -20
    arc_0_15_3  connected_order_arc_556  -13
    arc_0_15_3  in_degree_728  1
    arc_0_15_3  out_degree_747  1
    arc_0_15_3  original_T_including_depot_unload_792  6.5332321619697848e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_3  arc_capacity_555  1
    load_0_15_3  segment_load_conservation_731  -1
    load_0_15_3  segment_prefix_lb_732  1
    load_0_15_3  segment_prefix_ub_733  1
    load_0_15_3  free_load_conservation_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_4  arc_capacity_557  -20
    arc_0_15_4  connected_order_arc_558  -13
    arc_0_15_4  in_degree_735  1
    arc_0_15_4  out_degree_747  1
    arc_0_15_4  original_T_including_depot_unload_792  4.7597588586788925e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_4  arc_capacity_557  1
    load_0_15_4  segment_load_conservation_738  -1
    load_0_15_4  segment_prefix_lb_739  1
    load_0_15_4  segment_prefix_ub_740  1
    load_0_15_4  free_load_conservation_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_14  arc_capacity_559  -20
    arc_0_15_14  connected_order_arc_560  -13
    arc_0_15_14  in_degree_742  1
    arc_0_15_14  out_degree_747  1
    arc_0_15_14  original_T_including_depot_unload_792  2.4191291221621205e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_14  arc_capacity_559  1
    load_0_15_14  free_load_conservation_746  -1
    load_0_15_14  free_load_conservation_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_16  arc_capacity_561  -20
    arc_0_15_16  connected_order_arc_562  -13
    arc_0_15_16  out_degree_747  1
    arc_0_15_16  in_degree_754  1
    arc_0_15_16  original_T_including_depot_unload_792  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_16  arc_capacity_561  1
    load_0_15_16  free_load_conservation_752  1
    load_0_15_16  free_load_conservation_758  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_17  arc_capacity_563  -20
    arc_0_15_17  connected_order_arc_564  -13
    arc_0_15_17  out_degree_747  1
    arc_0_15_17  in_degree_760  1
    arc_0_15_17  original_T_including_depot_unload_792  5.0315495126439691e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_17  arc_capacity_563  1
    load_0_15_17  free_load_conservation_752  1
    load_0_15_17  free_load_conservation_764  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_18  arc_capacity_565  -20
    arc_0_15_18  connected_order_arc_566  -13
    arc_0_15_18  out_degree_747  1
    arc_0_15_18  in_degree_766  1
    arc_0_15_18  original_T_including_depot_unload_792  8.3486971116736720e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_18  arc_capacity_565  1
    load_0_15_18  free_load_conservation_752  1
    load_0_15_18  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_19  arc_capacity_567  -20
    arc_0_15_19  connected_order_arc_568  -13
    arc_0_15_19  out_degree_747  1
    arc_0_15_19  in_degree_772  1
    arc_0_15_19  original_T_including_depot_unload_792  3.2938591738444967e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_19  arc_capacity_567  1
    load_0_15_19  free_load_conservation_752  1
    load_0_15_19  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_20  arc_capacity_569  -20
    arc_0_15_20  connected_order_arc_570  -13
    arc_0_15_20  out_degree_747  1
    arc_0_15_20  in_degree_778  1
    arc_0_15_20  original_T_including_depot_unload_792  1.1544376314422677e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_20  arc_capacity_569  1
    load_0_15_20  free_load_conservation_752  1
    load_0_15_20  free_load_conservation_782  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_21  arc_capacity_571  -20
    arc_0_15_21  connected_order_arc_572  -13
    arc_0_15_21  out_degree_747  1
    arc_0_15_21  in_degree_784  1
    arc_0_15_21  original_T_including_depot_unload_792  4.6276703023336785e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_21  arc_capacity_571  1
    load_0_15_21  free_load_conservation_752  1
    load_0_15_21  free_load_conservation_788  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_0  arc_capacity_573  -20
    arc_0_16_0  depot_return_or_bypass_712  1
    arc_0_16_0  out_degree_753  1
    arc_0_16_0  original_T_including_depot_unload_792  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_0  arc_capacity_573  1
    load_0_16_0  free_load_conservation_758  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_1  arc_capacity_574  -20
    arc_0_16_1  connected_order_arc_575  -13
    arc_0_16_1  in_degree_714  1
    arc_0_16_1  out_degree_753  1
    arc_0_16_1  original_T_including_depot_unload_792  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_1  arc_capacity_574  1
    load_0_16_1  segment_load_conservation_717  -1
    load_0_16_1  segment_prefix_lb_718  1
    load_0_16_1  segment_prefix_ub_719  1
    load_0_16_1  free_load_conservation_758  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_2  arc_capacity_576  -20
    arc_0_16_2  connected_order_arc_577  -13
    arc_0_16_2  in_degree_721  1
    arc_0_16_2  out_degree_753  1
    arc_0_16_2  original_T_including_depot_unload_792  1.7303231472353602e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_2  arc_capacity_576  1
    load_0_16_2  segment_load_conservation_724  -1
    load_0_16_2  segment_prefix_lb_725  1
    load_0_16_2  segment_prefix_ub_726  1
    load_0_16_2  free_load_conservation_758  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_3  arc_capacity_578  -20
    arc_0_16_3  connected_order_arc_579  -13
    arc_0_16_3  in_degree_728  1
    arc_0_16_3  out_degree_753  1
    arc_0_16_3  original_T_including_depot_unload_792  1.5184659007075070e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_3  arc_capacity_578  1
    load_0_16_3  segment_load_conservation_731  -1
    load_0_16_3  segment_prefix_lb_732  1
    load_0_16_3  segment_prefix_ub_733  1
    load_0_16_3  free_load_conservation_758  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_4  arc_capacity_580  -20
    arc_0_16_4  connected_order_arc_581  -13
    arc_0_16_4  in_degree_735  1
    arc_0_16_4  out_degree_753  1
    arc_0_16_4  original_T_including_depot_unload_792  1.6292966848558842e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_4  arc_capacity_580  1
    load_0_16_4  segment_load_conservation_738  -1
    load_0_16_4  segment_prefix_lb_739  1
    load_0_16_4  segment_prefix_ub_740  1
    load_0_16_4  free_load_conservation_758  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_14  arc_capacity_582  -20
    arc_0_16_14  connected_order_arc_583  -13
    arc_0_16_14  in_degree_742  1
    arc_0_16_14  out_degree_753  1
    arc_0_16_14  original_T_including_depot_unload_792  1075.72043838369
    MARKER    'MARKER'                 'INTEND'
    load_0_16_14  arc_capacity_582  1
    load_0_16_14  free_load_conservation_746  -1
    load_0_16_14  free_load_conservation_758  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_15  arc_capacity_584  -20
    arc_0_16_15  connected_order_arc_585  -13
    arc_0_16_15  in_degree_748  1
    arc_0_16_15  out_degree_753  1
    arc_0_16_15  original_T_including_depot_unload_792  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_15  arc_capacity_584  1
    load_0_16_15  free_load_conservation_752  -1
    load_0_16_15  free_load_conservation_758  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_17  arc_capacity_586  -20
    arc_0_16_17  connected_order_arc_587  -13
    arc_0_16_17  out_degree_753  1
    arc_0_16_17  in_degree_760  1
    arc_0_16_17  original_T_including_depot_unload_792  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_17  arc_capacity_586  1
    load_0_16_17  free_load_conservation_758  1
    load_0_16_17  free_load_conservation_764  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_18  arc_capacity_588  -20
    arc_0_16_18  connected_order_arc_589  -13
    arc_0_16_18  out_degree_753  1
    arc_0_16_18  in_degree_766  1
    arc_0_16_18  original_T_including_depot_unload_792  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_18  arc_capacity_588  1
    load_0_16_18  free_load_conservation_758  1
    load_0_16_18  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_19  arc_capacity_590  -20
    arc_0_16_19  connected_order_arc_591  -13
    arc_0_16_19  out_degree_753  1
    arc_0_16_19  in_degree_772  1
    arc_0_16_19  original_T_including_depot_unload_792  1.3727638439182763e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_19  arc_capacity_590  1
    load_0_16_19  free_load_conservation_758  1
    load_0_16_19  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_20  arc_capacity_592  -20
    arc_0_16_20  connected_order_arc_593  -13
    arc_0_16_20  out_degree_753  1
    arc_0_16_20  in_degree_778  1
    arc_0_16_20  original_T_including_depot_unload_792  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_20  arc_capacity_592  1
    load_0_16_20  free_load_conservation_758  1
    load_0_16_20  free_load_conservation_782  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_21  arc_capacity_594  -20
    arc_0_16_21  connected_order_arc_595  -13
    arc_0_16_21  out_degree_753  1
    arc_0_16_21  in_degree_784  1
    arc_0_16_21  original_T_including_depot_unload_792  1.3163662834239574e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_21  arc_capacity_594  1
    load_0_16_21  free_load_conservation_758  1
    load_0_16_21  free_load_conservation_788  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_0  arc_capacity_596  -20
    arc_0_17_0  depot_return_or_bypass_712  1
    arc_0_17_0  out_degree_759  1
    arc_0_17_0  original_T_including_depot_unload_792  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_0  arc_capacity_596  1
    load_0_17_0  free_load_conservation_764  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_1  arc_capacity_597  -20
    arc_0_17_1  connected_order_arc_598  -13
    arc_0_17_1  in_degree_714  1
    arc_0_17_1  out_degree_759  1
    arc_0_17_1  original_T_including_depot_unload_792  9.3905252655669165e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_1  arc_capacity_597  1
    load_0_17_1  segment_load_conservation_717  -1
    load_0_17_1  segment_prefix_lb_718  1
    load_0_17_1  segment_prefix_ub_719  1
    load_0_17_1  free_load_conservation_764  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_2  arc_capacity_599  -20
    arc_0_17_2  connected_order_arc_600  -13
    arc_0_17_2  in_degree_721  1
    arc_0_17_2  out_degree_759  1
    arc_0_17_2  original_T_including_depot_unload_792  1.3669225770244122e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_2  arc_capacity_599  1
    load_0_17_2  segment_load_conservation_724  -1
    load_0_17_2  segment_prefix_lb_725  1
    load_0_17_2  segment_prefix_ub_726  1
    load_0_17_2  free_load_conservation_764  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_3  arc_capacity_601  -20
    arc_0_17_3  connected_order_arc_602  -13
    arc_0_17_3  in_degree_728  1
    arc_0_17_3  out_degree_759  1
    arc_0_17_3  original_T_including_depot_unload_792  1.1562172312295786e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_3  arc_capacity_601  1
    load_0_17_3  segment_load_conservation_731  -1
    load_0_17_3  segment_prefix_lb_732  1
    load_0_17_3  segment_prefix_ub_733  1
    load_0_17_3  free_load_conservation_764  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_4  arc_capacity_603  -20
    arc_0_17_4  connected_order_arc_604  -13
    arc_0_17_4  in_degree_735  1
    arc_0_17_4  out_degree_759  1
    arc_0_17_4  original_T_including_depot_unload_792  7.2751050611121218e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_4  arc_capacity_603  1
    load_0_17_4  segment_load_conservation_738  -1
    load_0_17_4  segment_prefix_lb_739  1
    load_0_17_4  segment_prefix_ub_740  1
    load_0_17_4  free_load_conservation_764  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_14  arc_capacity_605  -20
    arc_0_17_14  connected_order_arc_606  -13
    arc_0_17_14  in_degree_742  1
    arc_0_17_14  out_degree_759  1
    arc_0_17_14  original_T_including_depot_unload_792  2.6602972191926557e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_14  arc_capacity_605  1
    load_0_17_14  free_load_conservation_746  -1
    load_0_17_14  free_load_conservation_764  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_15  arc_capacity_607  -20
    arc_0_17_15  connected_order_arc_608  -13
    arc_0_17_15  in_degree_748  1
    arc_0_17_15  out_degree_759  1
    arc_0_17_15  original_T_including_depot_unload_792  5.0315495126439691e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_15  arc_capacity_607  1
    load_0_17_15  free_load_conservation_752  -1
    load_0_17_15  free_load_conservation_764  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_16  arc_capacity_609  -20
    arc_0_17_16  connected_order_arc_610  -13
    arc_0_17_16  in_degree_754  1
    arc_0_17_16  out_degree_759  1
    arc_0_17_16  original_T_including_depot_unload_792  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_16  arc_capacity_609  1
    load_0_17_16  free_load_conservation_758  -1
    load_0_17_16  free_load_conservation_764  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_18  arc_capacity_611  -20
    arc_0_17_18  connected_order_arc_612  -13
    arc_0_17_18  out_degree_759  1
    arc_0_17_18  in_degree_766  1
    arc_0_17_18  original_T_including_depot_unload_792  1.3127274783157229e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_18  arc_capacity_611  1
    load_0_17_18  free_load_conservation_764  1
    load_0_17_18  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_19  arc_capacity_613  -20
    arc_0_17_19  connected_order_arc_614  -13
    arc_0_17_19  out_degree_759  1
    arc_0_17_19  in_degree_772  1
    arc_0_17_19  original_T_including_depot_unload_792  3.9766425523492148e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_19  arc_capacity_613  1
    load_0_17_19  free_load_conservation_764  1
    load_0_17_19  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_20  arc_capacity_615  -20
    arc_0_17_20  connected_order_arc_616  -13
    arc_0_17_20  out_degree_759  1
    arc_0_17_20  in_degree_778  1
    arc_0_17_20  original_T_including_depot_unload_792  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_20  arc_capacity_615  1
    load_0_17_20  free_load_conservation_764  1
    load_0_17_20  free_load_conservation_782  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_21  arc_capacity_617  -20
    arc_0_17_21  connected_order_arc_618  -13
    arc_0_17_21  out_degree_759  1
    arc_0_17_21  in_degree_784  1
    arc_0_17_21  original_T_including_depot_unload_792  2.3059951477332697e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_21  arc_capacity_617  1
    load_0_17_21  free_load_conservation_764  1
    load_0_17_21  free_load_conservation_788  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_0  arc_capacity_619  -20
    arc_0_18_0  depot_return_or_bypass_712  1
    arc_0_18_0  out_degree_765  1
    arc_0_18_0  original_T_including_depot_unload_792  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_0  arc_capacity_619  1
    load_0_18_0  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_1  arc_capacity_620  -20
    arc_0_18_1  connected_order_arc_621  -13
    arc_0_18_1  in_degree_714  1
    arc_0_18_1  out_degree_765  1
    arc_0_18_1  original_T_including_depot_unload_792  4.5128490093732506e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_1  arc_capacity_620  1
    load_0_18_1  segment_load_conservation_717  -1
    load_0_18_1  segment_prefix_lb_718  1
    load_0_18_1  segment_prefix_ub_719  1
    load_0_18_1  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_2  arc_capacity_622  -20
    arc_0_18_2  connected_order_arc_623  -13
    arc_0_18_2  in_degree_721  1
    arc_0_18_2  out_degree_765  1
    arc_0_18_2  original_T_including_depot_unload_792  4.6128219015626763e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_2  arc_capacity_622  1
    load_0_18_2  segment_load_conservation_724  -1
    load_0_18_2  segment_prefix_lb_725  1
    load_0_18_2  segment_prefix_ub_726  1
    load_0_18_2  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_3  arc_capacity_624  -20
    arc_0_18_3  connected_order_arc_625  -13
    arc_0_18_3  in_degree_728  1
    arc_0_18_3  out_degree_765  1
    arc_0_18_3  original_T_including_depot_unload_792  3.7315439746742123e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_3  arc_capacity_624  1
    load_0_18_3  segment_load_conservation_731  -1
    load_0_18_3  segment_prefix_lb_732  1
    load_0_18_3  segment_prefix_ub_733  1
    load_0_18_3  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_4  arc_capacity_626  -20
    arc_0_18_4  connected_order_arc_627  -13
    arc_0_18_4  in_degree_735  1
    arc_0_18_4  out_degree_765  1
    arc_0_18_4  original_T_including_depot_unload_792  1.0758099325648966e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_4  arc_capacity_626  1
    load_0_18_4  segment_load_conservation_738  -1
    load_0_18_4  segment_prefix_lb_739  1
    load_0_18_4  segment_prefix_ub_740  1
    load_0_18_4  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_14  arc_capacity_628  -20
    arc_0_18_14  connected_order_arc_629  -13
    arc_0_18_14  in_degree_742  1
    arc_0_18_14  out_degree_765  1
    arc_0_18_14  original_T_including_depot_unload_792  1.0491196843462671e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_14  arc_capacity_628  1
    load_0_18_14  free_load_conservation_746  -1
    load_0_18_14  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_15  arc_capacity_630  -20
    arc_0_18_15  connected_order_arc_631  -13
    arc_0_18_15  in_degree_748  1
    arc_0_18_15  out_degree_765  1
    arc_0_18_15  original_T_including_depot_unload_792  8.3486971116736720e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_15  arc_capacity_630  1
    load_0_18_15  free_load_conservation_752  -1
    load_0_18_15  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_16  arc_capacity_632  -20
    arc_0_18_16  connected_order_arc_633  -13
    arc_0_18_16  in_degree_754  1
    arc_0_18_16  out_degree_765  1
    arc_0_18_16  original_T_including_depot_unload_792  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_16  arc_capacity_632  1
    load_0_18_16  free_load_conservation_758  -1
    load_0_18_16  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_17  arc_capacity_634  -20
    arc_0_18_17  connected_order_arc_635  -13
    arc_0_18_17  in_degree_760  1
    arc_0_18_17  out_degree_765  1
    arc_0_18_17  original_T_including_depot_unload_792  1.3127274783157229e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_17  arc_capacity_634  1
    load_0_18_17  free_load_conservation_764  -1
    load_0_18_17  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_19  arc_capacity_636  -20
    arc_0_18_19  connected_order_arc_637  -13
    arc_0_18_19  out_degree_765  1
    arc_0_18_19  in_degree_772  1
    arc_0_18_19  original_T_including_depot_unload_792  1.1341050580477483e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_19  arc_capacity_636  1
    load_0_18_19  free_load_conservation_770  1
    load_0_18_19  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_20  arc_capacity_638  -20
    arc_0_18_20  connected_order_arc_639  -13
    arc_0_18_20  out_degree_765  1
    arc_0_18_20  in_degree_778  1
    arc_0_18_20  original_T_including_depot_unload_792  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_20  arc_capacity_638  1
    load_0_18_20  free_load_conservation_770  1
    load_0_18_20  free_load_conservation_782  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_21  arc_capacity_640  -20
    arc_0_18_21  connected_order_arc_641  -13
    arc_0_18_21  out_degree_765  1
    arc_0_18_21  in_degree_784  1
    arc_0_18_21  original_T_including_depot_unload_792  1.2968499029957554e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_21  arc_capacity_640  1
    load_0_18_21  free_load_conservation_770  1
    load_0_18_21  free_load_conservation_788  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_0  arc_capacity_642  -20
    arc_0_19_0  depot_return_or_bypass_712  1
    arc_0_19_0  out_degree_771  1
    arc_0_19_0  original_T_including_depot_unload_792  5.9431738885389052e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_0  arc_capacity_642  1
    load_0_19_0  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_1  arc_capacity_643  -20
    arc_0_19_1  connected_order_arc_644  -13
    arc_0_19_1  in_degree_714  1
    arc_0_19_1  out_degree_771  1
    arc_0_19_1  original_T_including_depot_unload_792  6.9736186698570737e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_1  arc_capacity_643  1
    load_0_19_1  segment_load_conservation_717  -1
    load_0_19_1  segment_prefix_lb_718  1
    load_0_19_1  segment_prefix_ub_719  1
    load_0_19_1  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_2  arc_capacity_645  -20
    arc_0_19_2  connected_order_arc_646  -13
    arc_0_19_2  in_degree_721  1
    arc_0_19_2  out_degree_771  1
    arc_0_19_2  original_T_including_depot_unload_792  1.0687086794720833e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_2  arc_capacity_645  1
    load_0_19_2  segment_load_conservation_724  -1
    load_0_19_2  segment_prefix_lb_725  1
    load_0_19_2  segment_prefix_ub_726  1
    load_0_19_2  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_3  arc_capacity_647  -20
    arc_0_19_3  connected_order_arc_648  -13
    arc_0_19_3  in_degree_728  1
    arc_0_19_3  out_degree_771  1
    arc_0_19_3  original_T_including_depot_unload_792  8.8588784481112123e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_3  arc_capacity_647  1
    load_0_19_3  segment_load_conservation_731  -1
    load_0_19_3  segment_prefix_lb_732  1
    load_0_19_3  segment_prefix_ub_733  1
    load_0_19_3  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_4  arc_capacity_649  -20
    arc_0_19_4  connected_order_arc_650  -13
    arc_0_19_4  in_degree_735  1
    arc_0_19_4  out_degree_771  1
    arc_0_19_4  original_T_including_depot_unload_792  3.2985327387120213e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_4  arc_capacity_649  1
    load_0_19_4  segment_load_conservation_738  -1
    load_0_19_4  segment_prefix_lb_739  1
    load_0_19_4  segment_prefix_ub_740  1
    load_0_19_4  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_14  arc_capacity_651  -20
    arc_0_19_14  connected_order_arc_652  -13
    arc_0_19_14  in_degree_742  1
    arc_0_19_14  out_degree_771  1
    arc_0_19_14  original_T_including_depot_unload_792  2.9706418113632907e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_14  arc_capacity_651  1
    load_0_19_14  free_load_conservation_746  -1
    load_0_19_14  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_15  arc_capacity_653  -20
    arc_0_19_15  connected_order_arc_654  -13
    arc_0_19_15  in_degree_748  1
    arc_0_19_15  out_degree_771  1
    arc_0_19_15  original_T_including_depot_unload_792  3.2938591738444967e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_15  arc_capacity_653  1
    load_0_19_15  free_load_conservation_752  -1
    load_0_19_15  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_16  arc_capacity_655  -20
    arc_0_19_16  connected_order_arc_656  -13
    arc_0_19_16  in_degree_754  1
    arc_0_19_16  out_degree_771  1
    arc_0_19_16  original_T_including_depot_unload_792  1.3727638439182763e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_16  arc_capacity_655  1
    load_0_19_16  free_load_conservation_758  -1
    load_0_19_16  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_17  arc_capacity_657  -20
    arc_0_19_17  connected_order_arc_658  -13
    arc_0_19_17  in_degree_760  1
    arc_0_19_17  out_degree_771  1
    arc_0_19_17  original_T_including_depot_unload_792  3.9766425523492148e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_17  arc_capacity_657  1
    load_0_19_17  free_load_conservation_764  -1
    load_0_19_17  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_18  arc_capacity_659  -20
    arc_0_19_18  connected_order_arc_660  -13
    arc_0_19_18  in_degree_766  1
    arc_0_19_18  out_degree_771  1
    arc_0_19_18  original_T_including_depot_unload_792  1.1341050580477483e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_18  arc_capacity_659  1
    load_0_19_18  free_load_conservation_770  -1
    load_0_19_18  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_20  arc_capacity_661  -20
    arc_0_19_20  connected_order_arc_662  -13
    arc_0_19_20  out_degree_771  1
    arc_0_19_20  in_degree_778  1
    arc_0_19_20  original_T_including_depot_unload_792  9.8652191996938075e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_20  arc_capacity_661  1
    load_0_19_20  free_load_conservation_776  1
    load_0_19_20  free_load_conservation_782  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_21  arc_capacity_663  -20
    arc_0_19_21  connected_order_arc_664  -13
    arc_0_19_21  out_degree_771  1
    arc_0_19_21  in_degree_784  1
    arc_0_19_21  original_T_including_depot_unload_792  2.1481294511470344e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_21  arc_capacity_663  1
    load_0_19_21  free_load_conservation_776  1
    load_0_19_21  free_load_conservation_788  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_0  arc_capacity_665  -20
    arc_0_20_0  depot_return_or_bypass_712  1
    arc_0_20_0  out_degree_777  1
    arc_0_20_0  original_T_including_depot_unload_792  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_0  arc_capacity_665  1
    load_0_20_0  free_load_conservation_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_1  arc_capacity_666  -20
    arc_0_20_1  connected_order_arc_667  -13
    arc_0_20_1  in_degree_714  1
    arc_0_20_1  out_degree_777  1
    arc_0_20_1  original_T_including_depot_unload_792  1.5902582434549993e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_1  arc_capacity_666  1
    load_0_20_1  segment_load_conservation_717  -1
    load_0_20_1  segment_prefix_lb_718  1
    load_0_20_1  segment_prefix_ub_719  1
    load_0_20_1  free_load_conservation_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_2  arc_capacity_668  -20
    arc_0_20_2  connected_order_arc_669  -13
    arc_0_20_2  in_degree_721  1
    arc_0_20_2  out_degree_777  1
    arc_0_20_2  original_T_including_depot_unload_792  2.0162129512771592e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_2  arc_capacity_668  1
    load_0_20_2  segment_load_conservation_724  -1
    load_0_20_2  segment_prefix_lb_725  1
    load_0_20_2  segment_prefix_ub_726  1
    load_0_20_2  free_load_conservation_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_3  arc_capacity_670  -20
    arc_0_20_3  connected_order_arc_671  -13
    arc_0_20_3  in_degree_728  1
    arc_0_20_3  out_degree_777  1
    arc_0_20_3  original_T_including_depot_unload_792  1.8073464544423741e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_3  arc_capacity_670  1
    load_0_20_3  segment_load_conservation_731  -1
    load_0_20_3  segment_prefix_lb_732  1
    load_0_20_3  segment_prefix_ub_733  1
    load_0_20_3  free_load_conservation_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_4  arc_capacity_672  -20
    arc_0_20_4  connected_order_arc_673  -13
    arc_0_20_4  in_degree_735  1
    arc_0_20_4  out_degree_777  1
    arc_0_20_4  original_T_including_depot_unload_792  1.2927075446362680e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_4  arc_capacity_672  1
    load_0_20_4  segment_load_conservation_738  -1
    load_0_20_4  segment_prefix_lb_739  1
    load_0_20_4  segment_prefix_ub_740  1
    load_0_20_4  free_load_conservation_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_14  arc_capacity_674  -20
    arc_0_20_14  connected_order_arc_675  -13
    arc_0_20_14  in_degree_742  1
    arc_0_20_14  out_degree_777  1
    arc_0_20_14  original_T_including_depot_unload_792  9.1576870176747968e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_14  arc_capacity_674  1
    load_0_20_14  free_load_conservation_746  -1
    load_0_20_14  free_load_conservation_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_15  arc_capacity_676  -20
    arc_0_20_15  connected_order_arc_677  -13
    arc_0_20_15  in_degree_748  1
    arc_0_20_15  out_degree_777  1
    arc_0_20_15  original_T_including_depot_unload_792  1.1544376314422677e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_15  arc_capacity_676  1
    load_0_20_15  free_load_conservation_752  -1
    load_0_20_15  free_load_conservation_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_16  arc_capacity_678  -20
    arc_0_20_16  connected_order_arc_679  -13
    arc_0_20_16  in_degree_754  1
    arc_0_20_16  out_degree_777  1
    arc_0_20_16  original_T_including_depot_unload_792  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_16  arc_capacity_678  1
    load_0_20_16  free_load_conservation_758  -1
    load_0_20_16  free_load_conservation_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_17  arc_capacity_680  -20
    arc_0_20_17  connected_order_arc_681  -13
    arc_0_20_17  in_degree_760  1
    arc_0_20_17  out_degree_777  1
    arc_0_20_17  original_T_including_depot_unload_792  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_17  arc_capacity_680  1
    load_0_20_17  free_load_conservation_764  -1
    load_0_20_17  free_load_conservation_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_18  arc_capacity_682  -20
    arc_0_20_18  connected_order_arc_683  -13
    arc_0_20_18  in_degree_766  1
    arc_0_20_18  out_degree_777  1
    arc_0_20_18  original_T_including_depot_unload_792  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_18  arc_capacity_682  1
    load_0_20_18  free_load_conservation_770  -1
    load_0_20_18  free_load_conservation_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_19  arc_capacity_684  -20
    arc_0_20_19  connected_order_arc_685  -13
    arc_0_20_19  in_degree_772  1
    arc_0_20_19  out_degree_777  1
    arc_0_20_19  original_T_including_depot_unload_792  9.8652191996938075e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_19  arc_capacity_684  1
    load_0_20_19  free_load_conservation_776  -1
    load_0_20_19  free_load_conservation_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_21  arc_capacity_686  -20
    arc_0_20_21  connected_order_arc_687  -13
    arc_0_20_21  out_degree_777  1
    arc_0_20_21  in_degree_784  1
    arc_0_20_21  original_T_including_depot_unload_792  7.7190219995954919e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_21  arc_capacity_686  1
    load_0_20_21  free_load_conservation_782  1
    load_0_20_21  free_load_conservation_788  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_0  arc_capacity_688  -20
    arc_0_21_0  depot_return_or_bypass_712  1
    arc_0_21_0  out_degree_783  1
    arc_0_21_0  original_T_including_depot_unload_792  7.2571167924583824e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_0  arc_capacity_688  1
    load_0_21_0  free_load_conservation_788  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_1  arc_capacity_689  -20
    arc_0_21_1  connected_order_arc_690  -13
    arc_0_21_1  in_degree_714  1
    arc_0_21_1  out_degree_783  1
    arc_0_21_1  original_T_including_depot_unload_792  8.7876124407720954e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_1  arc_capacity_689  1
    load_0_21_1  segment_load_conservation_717  -1
    load_0_21_1  segment_prefix_lb_718  1
    load_0_21_1  segment_prefix_ub_719  1
    load_0_21_1  free_load_conservation_788  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_2  arc_capacity_691  -20
    arc_0_21_2  connected_order_arc_692  -13
    arc_0_21_2  in_degree_721  1
    arc_0_21_2  out_degree_783  1
    arc_0_21_2  original_T_including_depot_unload_792  1.2724370432148053e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_2  arc_capacity_691  1
    load_0_21_2  segment_load_conservation_724  -1
    load_0_21_2  segment_prefix_lb_725  1
    load_0_21_2  segment_prefix_ub_726  1
    load_0_21_2  free_load_conservation_788  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_3  arc_capacity_693  -20
    arc_0_21_3  connected_order_arc_694  -13
    arc_0_21_3  in_degree_728  1
    arc_0_21_3  out_degree_783  1
    arc_0_21_3  original_T_including_depot_unload_792  1.0799954902659535e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_3  arc_capacity_693  1
    load_0_21_3  segment_load_conservation_731  -1
    load_0_21_3  segment_prefix_lb_732  1
    load_0_21_3  segment_prefix_ub_733  1
    load_0_21_3  free_load_conservation_788  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_4  arc_capacity_695  -20
    arc_0_21_4  connected_order_arc_696  -13
    arc_0_21_4  in_degree_735  1
    arc_0_21_4  out_degree_783  1
    arc_0_21_4  original_T_including_depot_unload_792  5.2996691306068044e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_4  arc_capacity_695  1
    load_0_21_4  segment_load_conservation_738  -1
    load_0_21_4  segment_prefix_lb_739  1
    load_0_21_4  segment_prefix_ub_740  1
    load_0_21_4  free_load_conservation_788  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_14  arc_capacity_697  -20
    arc_0_21_14  connected_order_arc_698  -13
    arc_0_21_14  in_degree_742  1
    arc_0_21_14  out_degree_783  1
    arc_0_21_14  original_T_including_depot_unload_792  3.0055050459786975e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_14  arc_capacity_697  1
    load_0_21_14  free_load_conservation_746  -1
    load_0_21_14  free_load_conservation_788  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_15  arc_capacity_699  -20
    arc_0_21_15  connected_order_arc_700  -13
    arc_0_21_15  in_degree_748  1
    arc_0_21_15  out_degree_783  1
    arc_0_21_15  original_T_including_depot_unload_792  4.6276703023336785e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_15  arc_capacity_699  1
    load_0_21_15  free_load_conservation_752  -1
    load_0_21_15  free_load_conservation_788  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_16  arc_capacity_701  -20
    arc_0_21_16  connected_order_arc_702  -13
    arc_0_21_16  in_degree_754  1
    arc_0_21_16  out_degree_783  1
    arc_0_21_16  original_T_including_depot_unload_792  1.3163662834239574e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_16  arc_capacity_701  1
    load_0_21_16  free_load_conservation_758  -1
    load_0_21_16  free_load_conservation_788  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_17  arc_capacity_703  -20
    arc_0_21_17  connected_order_arc_704  -13
    arc_0_21_17  in_degree_760  1
    arc_0_21_17  out_degree_783  1
    arc_0_21_17  original_T_including_depot_unload_792  2.3059951477332697e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_17  arc_capacity_703  1
    load_0_21_17  free_load_conservation_764  -1
    load_0_21_17  free_load_conservation_788  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_18  arc_capacity_705  -20
    arc_0_21_18  connected_order_arc_706  -13
    arc_0_21_18  in_degree_766  1
    arc_0_21_18  out_degree_783  1
    arc_0_21_18  original_T_including_depot_unload_792  1.2968499029957554e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_18  arc_capacity_705  1
    load_0_21_18  free_load_conservation_770  -1
    load_0_21_18  free_load_conservation_788  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_19  arc_capacity_707  -20
    arc_0_21_19  connected_order_arc_708  -13
    arc_0_21_19  in_degree_772  1
    arc_0_21_19  out_degree_783  1
    arc_0_21_19  original_T_including_depot_unload_792  2.1481294511470344e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_19  arc_capacity_707  1
    load_0_21_19  free_load_conservation_776  -1
    load_0_21_19  free_load_conservation_788  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_20  arc_capacity_709  -20
    arc_0_21_20  connected_order_arc_710  -13
    arc_0_21_20  in_degree_778  1
    arc_0_21_20  out_degree_783  1
    arc_0_21_20  original_T_including_depot_unload_792  7.7190219995954919e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_20  arc_capacity_709  1
    load_0_21_20  free_load_conservation_782  -1
    load_0_21_20  free_load_conservation_788  1
    visit_1_5  out_degree_1134  -1
    visit_1_5  in_degree_1135  -1
    visit_1_5  order_active_lb_1136  -1
    visit_1_5  order_active_ub_1137  -13
    order_1_5  connected_order_arc_809  -1
    order_1_5  connected_order_arc_811  -1
    order_1_5  connected_order_arc_813  -1
    order_1_5  connected_order_arc_815  -1
    order_1_5  connected_order_arc_817  -1
    order_1_5  connected_order_arc_819  -1
    order_1_5  connected_order_arc_821  -1
    order_1_5  connected_order_arc_823  -1
    order_1_5  connected_order_arc_825  -1
    order_1_5  connected_order_arc_827  -1
    order_1_5  connected_order_arc_829  -1
    order_1_5  connected_order_arc_831  -1
    order_1_5  connected_order_arc_834  1
    order_1_5  connected_order_arc_859  1
    order_1_5  connected_order_arc_884  1
    order_1_5  connected_order_arc_909  1
    order_1_5  connected_order_arc_934  1
    order_1_5  connected_order_arc_959  1
    order_1_5  connected_order_arc_984  1
    order_1_5  connected_order_arc_1009  1
    order_1_5  connected_order_arc_1034  1
    order_1_5  connected_order_arc_1059  1
    order_1_5  connected_order_arc_1084  1
    order_1_5  connected_order_arc_1109  1
    order_1_5  order_active_lb_1136  1
    order_1_5  order_active_ub_1137  1
    order_1_5  fixed_segment_relative_order_1217  -1
    visit_1_6  out_degree_1141  -1
    visit_1_6  in_degree_1142  -1
    visit_1_6  order_active_lb_1143  -1
    visit_1_6  order_active_ub_1144  -13
    order_1_6  connected_order_arc_809  1
    order_1_6  connected_order_arc_834  -1
    order_1_6  connected_order_arc_836  -1
    order_1_6  connected_order_arc_838  -1
    order_1_6  connected_order_arc_840  -1
    order_1_6  connected_order_arc_842  -1
    order_1_6  connected_order_arc_844  -1
    order_1_6  connected_order_arc_846  -1
    order_1_6  connected_order_arc_848  -1
    order_1_6  connected_order_arc_850  -1
    order_1_6  connected_order_arc_852  -1
    order_1_6  connected_order_arc_854  -1
    order_1_6  connected_order_arc_856  -1
    order_1_6  connected_order_arc_861  1
    order_1_6  connected_order_arc_886  1
    order_1_6  connected_order_arc_911  1
    order_1_6  connected_order_arc_936  1
    order_1_6  connected_order_arc_961  1
    order_1_6  connected_order_arc_986  1
    order_1_6  connected_order_arc_1011  1
    order_1_6  connected_order_arc_1036  1
    order_1_6  connected_order_arc_1061  1
    order_1_6  connected_order_arc_1086  1
    order_1_6  connected_order_arc_1111  1
    order_1_6  order_active_lb_1143  1
    order_1_6  order_active_ub_1144  1
    order_1_6  fixed_segment_relative_order_1217  1
    order_1_6  fixed_segment_relative_order_1218  -1
    visit_1_7  out_degree_1148  -1
    visit_1_7  in_degree_1149  -1
    visit_1_7  order_active_lb_1150  -1
    visit_1_7  order_active_ub_1151  -13
    order_1_7  connected_order_arc_811  1
    order_1_7  connected_order_arc_836  1
    order_1_7  connected_order_arc_859  -1
    order_1_7  connected_order_arc_861  -1
    order_1_7  connected_order_arc_863  -1
    order_1_7  connected_order_arc_865  -1
    order_1_7  connected_order_arc_867  -1
    order_1_7  connected_order_arc_869  -1
    order_1_7  connected_order_arc_871  -1
    order_1_7  connected_order_arc_873  -1
    order_1_7  connected_order_arc_875  -1
    order_1_7  connected_order_arc_877  -1
    order_1_7  connected_order_arc_879  -1
    order_1_7  connected_order_arc_881  -1
    order_1_7  connected_order_arc_888  1
    order_1_7  connected_order_arc_913  1
    order_1_7  connected_order_arc_938  1
    order_1_7  connected_order_arc_963  1
    order_1_7  connected_order_arc_988  1
    order_1_7  connected_order_arc_1013  1
    order_1_7  connected_order_arc_1038  1
    order_1_7  connected_order_arc_1063  1
    order_1_7  connected_order_arc_1088  1
    order_1_7  connected_order_arc_1113  1
    order_1_7  order_active_lb_1150  1
    order_1_7  order_active_ub_1151  1
    order_1_7  fixed_segment_relative_order_1218  1
    order_1_7  fixed_segment_relative_order_1219  -1
    visit_1_8  out_degree_1155  -1
    visit_1_8  in_degree_1156  -1
    visit_1_8  order_active_lb_1157  -1
    visit_1_8  order_active_ub_1158  -13
    order_1_8  connected_order_arc_813  1
    order_1_8  connected_order_arc_838  1
    order_1_8  connected_order_arc_863  1
    order_1_8  connected_order_arc_884  -1
    order_1_8  connected_order_arc_886  -1
    order_1_8  connected_order_arc_888  -1
    order_1_8  connected_order_arc_890  -1
    order_1_8  connected_order_arc_892  -1
    order_1_8  connected_order_arc_894  -1
    order_1_8  connected_order_arc_896  -1
    order_1_8  connected_order_arc_898  -1
    order_1_8  connected_order_arc_900  -1
    order_1_8  connected_order_arc_902  -1
    order_1_8  connected_order_arc_904  -1
    order_1_8  connected_order_arc_906  -1
    order_1_8  connected_order_arc_915  1
    order_1_8  connected_order_arc_940  1
    order_1_8  connected_order_arc_965  1
    order_1_8  connected_order_arc_990  1
    order_1_8  connected_order_arc_1015  1
    order_1_8  connected_order_arc_1040  1
    order_1_8  connected_order_arc_1065  1
    order_1_8  connected_order_arc_1090  1
    order_1_8  connected_order_arc_1115  1
    order_1_8  order_active_lb_1157  1
    order_1_8  order_active_ub_1158  1
    order_1_8  fixed_segment_relative_order_1219  1
    order_1_8  fixed_segment_relative_order_1220  -1
    visit_1_9  out_degree_1162  -1
    visit_1_9  in_degree_1163  -1
    visit_1_9  order_active_lb_1164  -1
    visit_1_9  order_active_ub_1165  -13
    order_1_9  connected_order_arc_815  1
    order_1_9  connected_order_arc_840  1
    order_1_9  connected_order_arc_865  1
    order_1_9  connected_order_arc_890  1
    order_1_9  connected_order_arc_909  -1
    order_1_9  connected_order_arc_911  -1
    order_1_9  connected_order_arc_913  -1
    order_1_9  connected_order_arc_915  -1
    order_1_9  connected_order_arc_917  -1
    order_1_9  connected_order_arc_919  -1
    order_1_9  connected_order_arc_921  -1
    order_1_9  connected_order_arc_923  -1
    order_1_9  connected_order_arc_925  -1
    order_1_9  connected_order_arc_927  -1
    order_1_9  connected_order_arc_929  -1
    order_1_9  connected_order_arc_931  -1
    order_1_9  connected_order_arc_942  1
    order_1_9  connected_order_arc_967  1
    order_1_9  connected_order_arc_992  1
    order_1_9  connected_order_arc_1017  1
    order_1_9  connected_order_arc_1042  1
    order_1_9  connected_order_arc_1067  1
    order_1_9  connected_order_arc_1092  1
    order_1_9  connected_order_arc_1117  1
    order_1_9  order_active_lb_1164  1
    order_1_9  order_active_ub_1165  1
    order_1_9  fixed_segment_relative_order_1220  1
    visit_1_14  out_degree_1169  -1
    visit_1_14  in_degree_1170  -1
    visit_1_14  order_active_lb_1171  -1
    visit_1_14  order_active_ub_1172  -13
    visit_1_14  service_visit_def_1173  -1
    order_1_14  connected_order_arc_817  1
    order_1_14  connected_order_arc_842  1
    order_1_14  connected_order_arc_867  1
    order_1_14  connected_order_arc_892  1
    order_1_14  connected_order_arc_917  1
    order_1_14  connected_order_arc_934  -1
    order_1_14  connected_order_arc_936  -1
    order_1_14  connected_order_arc_938  -1
    order_1_14  connected_order_arc_940  -1
    order_1_14  connected_order_arc_942  -1
    order_1_14  connected_order_arc_944  -1
    order_1_14  connected_order_arc_946  -1
    order_1_14  connected_order_arc_948  -1
    order_1_14  connected_order_arc_950  -1
    order_1_14  connected_order_arc_952  -1
    order_1_14  connected_order_arc_954  -1
    order_1_14  connected_order_arc_956  -1
    order_1_14  connected_order_arc_969  1
    order_1_14  connected_order_arc_994  1
    order_1_14  connected_order_arc_1019  1
    order_1_14  connected_order_arc_1044  1
    order_1_14  connected_order_arc_1069  1
    order_1_14  connected_order_arc_1094  1
    order_1_14  connected_order_arc_1119  1
    order_1_14  order_active_lb_1171  1
    order_1_14  order_active_ub_1172  1
    visit_1_15  out_degree_1175  -1
    visit_1_15  in_degree_1176  -1
    visit_1_15  order_active_lb_1177  -1
    visit_1_15  order_active_ub_1178  -13
    visit_1_15  service_visit_def_1179  -1
    order_1_15  connected_order_arc_819  1
    order_1_15  connected_order_arc_844  1
    order_1_15  connected_order_arc_869  1
    order_1_15  connected_order_arc_894  1
    order_1_15  connected_order_arc_919  1
    order_1_15  connected_order_arc_944  1
    order_1_15  connected_order_arc_959  -1
    order_1_15  connected_order_arc_961  -1
    order_1_15  connected_order_arc_963  -1
    order_1_15  connected_order_arc_965  -1
    order_1_15  connected_order_arc_967  -1
    order_1_15  connected_order_arc_969  -1
    order_1_15  connected_order_arc_971  -1
    order_1_15  connected_order_arc_973  -1
    order_1_15  connected_order_arc_975  -1
    order_1_15  connected_order_arc_977  -1
    order_1_15  connected_order_arc_979  -1
    order_1_15  connected_order_arc_981  -1
    order_1_15  connected_order_arc_996  1
    order_1_15  connected_order_arc_1021  1
    order_1_15  connected_order_arc_1046  1
    order_1_15  connected_order_arc_1071  1
    order_1_15  connected_order_arc_1096  1
    order_1_15  connected_order_arc_1121  1
    order_1_15  order_active_lb_1177  1
    order_1_15  order_active_ub_1178  1
    visit_1_16  out_degree_1181  -1
    visit_1_16  in_degree_1182  -1
    visit_1_16  order_active_lb_1183  -1
    visit_1_16  order_active_ub_1184  -13
    visit_1_16  service_visit_def_1185  -1
    order_1_16  connected_order_arc_821  1
    order_1_16  connected_order_arc_846  1
    order_1_16  connected_order_arc_871  1
    order_1_16  connected_order_arc_896  1
    order_1_16  connected_order_arc_921  1
    order_1_16  connected_order_arc_946  1
    order_1_16  connected_order_arc_971  1
    order_1_16  connected_order_arc_984  -1
    order_1_16  connected_order_arc_986  -1
    order_1_16  connected_order_arc_988  -1
    order_1_16  connected_order_arc_990  -1
    order_1_16  connected_order_arc_992  -1
    order_1_16  connected_order_arc_994  -1
    order_1_16  connected_order_arc_996  -1
    order_1_16  connected_order_arc_998  -1
    order_1_16  connected_order_arc_1000  -1
    order_1_16  connected_order_arc_1002  -1
    order_1_16  connected_order_arc_1004  -1
    order_1_16  connected_order_arc_1006  -1
    order_1_16  connected_order_arc_1023  1
    order_1_16  connected_order_arc_1048  1
    order_1_16  connected_order_arc_1073  1
    order_1_16  connected_order_arc_1098  1
    order_1_16  connected_order_arc_1123  1
    order_1_16  order_active_lb_1183  1
    order_1_16  order_active_ub_1184  1
    visit_1_17  out_degree_1187  -1
    visit_1_17  in_degree_1188  -1
    visit_1_17  order_active_lb_1189  -1
    visit_1_17  order_active_ub_1190  -13
    visit_1_17  service_visit_def_1191  -1
    order_1_17  connected_order_arc_823  1
    order_1_17  connected_order_arc_848  1
    order_1_17  connected_order_arc_873  1
    order_1_17  connected_order_arc_898  1
    order_1_17  connected_order_arc_923  1
    order_1_17  connected_order_arc_948  1
    order_1_17  connected_order_arc_973  1
    order_1_17  connected_order_arc_998  1
    order_1_17  connected_order_arc_1009  -1
    order_1_17  connected_order_arc_1011  -1
    order_1_17  connected_order_arc_1013  -1
    order_1_17  connected_order_arc_1015  -1
    order_1_17  connected_order_arc_1017  -1
    order_1_17  connected_order_arc_1019  -1
    order_1_17  connected_order_arc_1021  -1
    order_1_17  connected_order_arc_1023  -1
    order_1_17  connected_order_arc_1025  -1
    order_1_17  connected_order_arc_1027  -1
    order_1_17  connected_order_arc_1029  -1
    order_1_17  connected_order_arc_1031  -1
    order_1_17  connected_order_arc_1050  1
    order_1_17  connected_order_arc_1075  1
    order_1_17  connected_order_arc_1100  1
    order_1_17  connected_order_arc_1125  1
    order_1_17  order_active_lb_1189  1
    order_1_17  order_active_ub_1190  1
    visit_1_18  out_degree_1193  -1
    visit_1_18  in_degree_1194  -1
    visit_1_18  order_active_lb_1195  -1
    visit_1_18  order_active_ub_1196  -13
    visit_1_18  service_visit_def_1197  -1
    order_1_18  connected_order_arc_825  1
    order_1_18  connected_order_arc_850  1
    order_1_18  connected_order_arc_875  1
    order_1_18  connected_order_arc_900  1
    order_1_18  connected_order_arc_925  1
    order_1_18  connected_order_arc_950  1
    order_1_18  connected_order_arc_975  1
    order_1_18  connected_order_arc_1000  1
    order_1_18  connected_order_arc_1025  1
    order_1_18  connected_order_arc_1034  -1
    order_1_18  connected_order_arc_1036  -1
    order_1_18  connected_order_arc_1038  -1
    order_1_18  connected_order_arc_1040  -1
    order_1_18  connected_order_arc_1042  -1
    order_1_18  connected_order_arc_1044  -1
    order_1_18  connected_order_arc_1046  -1
    order_1_18  connected_order_arc_1048  -1
    order_1_18  connected_order_arc_1050  -1
    order_1_18  connected_order_arc_1052  -1
    order_1_18  connected_order_arc_1054  -1
    order_1_18  connected_order_arc_1056  -1
    order_1_18  connected_order_arc_1077  1
    order_1_18  connected_order_arc_1102  1
    order_1_18  connected_order_arc_1127  1
    order_1_18  order_active_lb_1195  1
    order_1_18  order_active_ub_1196  1
    visit_1_19  out_degree_1199  -1
    visit_1_19  in_degree_1200  -1
    visit_1_19  order_active_lb_1201  -1
    visit_1_19  order_active_ub_1202  -13
    visit_1_19  service_visit_def_1203  -1
    order_1_19  connected_order_arc_827  1
    order_1_19  connected_order_arc_852  1
    order_1_19  connected_order_arc_877  1
    order_1_19  connected_order_arc_902  1
    order_1_19  connected_order_arc_927  1
    order_1_19  connected_order_arc_952  1
    order_1_19  connected_order_arc_977  1
    order_1_19  connected_order_arc_1002  1
    order_1_19  connected_order_arc_1027  1
    order_1_19  connected_order_arc_1052  1
    order_1_19  connected_order_arc_1059  -1
    order_1_19  connected_order_arc_1061  -1
    order_1_19  connected_order_arc_1063  -1
    order_1_19  connected_order_arc_1065  -1
    order_1_19  connected_order_arc_1067  -1
    order_1_19  connected_order_arc_1069  -1
    order_1_19  connected_order_arc_1071  -1
    order_1_19  connected_order_arc_1073  -1
    order_1_19  connected_order_arc_1075  -1
    order_1_19  connected_order_arc_1077  -1
    order_1_19  connected_order_arc_1079  -1
    order_1_19  connected_order_arc_1081  -1
    order_1_19  connected_order_arc_1104  1
    order_1_19  connected_order_arc_1129  1
    order_1_19  order_active_lb_1201  1
    order_1_19  order_active_ub_1202  1
    visit_1_20  out_degree_1205  -1
    visit_1_20  in_degree_1206  -1
    visit_1_20  order_active_lb_1207  -1
    visit_1_20  order_active_ub_1208  -13
    visit_1_20  service_visit_def_1209  -1
    order_1_20  connected_order_arc_829  1
    order_1_20  connected_order_arc_854  1
    order_1_20  connected_order_arc_879  1
    order_1_20  connected_order_arc_904  1
    order_1_20  connected_order_arc_929  1
    order_1_20  connected_order_arc_954  1
    order_1_20  connected_order_arc_979  1
    order_1_20  connected_order_arc_1004  1
    order_1_20  connected_order_arc_1029  1
    order_1_20  connected_order_arc_1054  1
    order_1_20  connected_order_arc_1079  1
    order_1_20  connected_order_arc_1084  -1
    order_1_20  connected_order_arc_1086  -1
    order_1_20  connected_order_arc_1088  -1
    order_1_20  connected_order_arc_1090  -1
    order_1_20  connected_order_arc_1092  -1
    order_1_20  connected_order_arc_1094  -1
    order_1_20  connected_order_arc_1096  -1
    order_1_20  connected_order_arc_1098  -1
    order_1_20  connected_order_arc_1100  -1
    order_1_20  connected_order_arc_1102  -1
    order_1_20  connected_order_arc_1104  -1
    order_1_20  connected_order_arc_1106  -1
    order_1_20  connected_order_arc_1131  1
    order_1_20  order_active_lb_1207  1
    order_1_20  order_active_ub_1208  1
    visit_1_21  out_degree_1211  -1
    visit_1_21  in_degree_1212  -1
    visit_1_21  order_active_lb_1213  -1
    visit_1_21  order_active_ub_1214  -13
    visit_1_21  service_visit_def_1215  -1
    order_1_21  connected_order_arc_831  1
    order_1_21  connected_order_arc_856  1
    order_1_21  connected_order_arc_881  1
    order_1_21  connected_order_arc_906  1
    order_1_21  connected_order_arc_931  1
    order_1_21  connected_order_arc_956  1
    order_1_21  connected_order_arc_981  1
    order_1_21  connected_order_arc_1006  1
    order_1_21  connected_order_arc_1031  1
    order_1_21  connected_order_arc_1056  1
    order_1_21  connected_order_arc_1081  1
    order_1_21  connected_order_arc_1106  1
    order_1_21  connected_order_arc_1109  -1
    order_1_21  connected_order_arc_1111  -1
    order_1_21  connected_order_arc_1113  -1
    order_1_21  connected_order_arc_1115  -1
    order_1_21  connected_order_arc_1117  -1
    order_1_21  connected_order_arc_1119  -1
    order_1_21  connected_order_arc_1121  -1
    order_1_21  connected_order_arc_1123  -1
    order_1_21  connected_order_arc_1125  -1
    order_1_21  connected_order_arc_1127  -1
    order_1_21  connected_order_arc_1129  -1
    order_1_21  connected_order_arc_1131  -1
    order_1_21  order_active_lb_1213  1
    order_1_21  order_active_ub_1214  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_0  arc_capacity_793  -25
    arc_1_0_0  depot_departure_or_bypass_1132  1
    arc_1_0_0  depot_return_or_bypass_1133  1
    MARKER    'MARKER'                 'INTEND'
    load_1_0_0  arc_capacity_793  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_5  arc_capacity_794  -25
    arc_1_0_5  depot_departure_or_bypass_1132  1
    arc_1_0_5  in_degree_1135  1
    arc_1_0_5  original_T_including_depot_unload_1221  8.7749189782983967e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_5  arc_capacity_794  1
    load_1_0_5  segment_load_conservation_1138  -1
    load_1_0_5  segment_prefix_lb_1139  1
    load_1_0_5  segment_prefix_ub_1140  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_6  arc_capacity_795  -25
    arc_1_0_6  depot_departure_or_bypass_1132  1
    arc_1_0_6  in_degree_1142  1
    arc_1_0_6  original_T_including_depot_unload_1221  8.7918533905669346e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_6  arc_capacity_795  1
    load_1_0_6  segment_load_conservation_1145  -1
    load_1_0_6  segment_prefix_lb_1146  1
    load_1_0_6  segment_prefix_ub_1147  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_7  arc_capacity_796  -25
    arc_1_0_7  depot_departure_or_bypass_1132  1
    arc_1_0_7  in_degree_1149  1
    arc_1_0_7  original_T_including_depot_unload_1221  7.8195480223834068e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_7  arc_capacity_796  1
    load_1_0_7  segment_load_conservation_1152  -1
    load_1_0_7  segment_prefix_lb_1153  1
    load_1_0_7  segment_prefix_ub_1154  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_8  arc_capacity_797  -25
    arc_1_0_8  depot_departure_or_bypass_1132  1
    arc_1_0_8  in_degree_1156  1
    arc_1_0_8  original_T_including_depot_unload_1221  4.7522445589173662e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_8  arc_capacity_797  1
    load_1_0_8  segment_load_conservation_1159  -1
    load_1_0_8  segment_prefix_lb_1160  1
    load_1_0_8  segment_prefix_ub_1161  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_9  arc_capacity_798  -25
    arc_1_0_9  depot_departure_or_bypass_1132  1
    arc_1_0_9  in_degree_1163  1
    arc_1_0_9  original_T_including_depot_unload_1221  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_9  arc_capacity_798  1
    load_1_0_9  segment_load_conservation_1166  -1
    load_1_0_9  segment_prefix_lb_1167  1
    load_1_0_9  segment_prefix_ub_1168  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_14  arc_capacity_799  -25
    arc_1_0_14  depot_departure_or_bypass_1132  1
    arc_1_0_14  in_degree_1170  1
    arc_1_0_14  original_T_including_depot_unload_1221  4.6364706268001146e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_14  arc_capacity_799  1
    load_1_0_14  free_load_conservation_1174  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_15  arc_capacity_800  -25
    arc_1_0_15  depot_departure_or_bypass_1132  1
    arc_1_0_15  in_degree_1176  1
    arc_1_0_15  original_T_including_depot_unload_1221  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_15  arc_capacity_800  1
    load_1_0_15  free_load_conservation_1180  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_16  arc_capacity_801  -25
    arc_1_0_16  depot_departure_or_bypass_1132  1
    arc_1_0_16  in_degree_1182  1
    arc_1_0_16  original_T_including_depot_unload_1221  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_16  arc_capacity_801  1
    load_1_0_16  free_load_conservation_1186  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_17  arc_capacity_802  -25
    arc_1_0_17  depot_departure_or_bypass_1132  1
    arc_1_0_17  in_degree_1188  1
    arc_1_0_17  original_T_including_depot_unload_1221  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_17  arc_capacity_802  1
    load_1_0_17  free_load_conservation_1192  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_18  arc_capacity_803  -25
    arc_1_0_18  depot_departure_or_bypass_1132  1
    arc_1_0_18  in_degree_1194  1
    arc_1_0_18  original_T_including_depot_unload_1221  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_18  arc_capacity_803  1
    load_1_0_18  free_load_conservation_1198  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_19  arc_capacity_804  -25
    arc_1_0_19  depot_departure_or_bypass_1132  1
    arc_1_0_19  in_degree_1200  1
    arc_1_0_19  original_T_including_depot_unload_1221  5.9431738885389052e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_19  arc_capacity_804  1
    load_1_0_19  free_load_conservation_1204  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_20  arc_capacity_805  -25
    arc_1_0_20  depot_departure_or_bypass_1132  1
    arc_1_0_20  in_degree_1206  1
    arc_1_0_20  original_T_including_depot_unload_1221  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_20  arc_capacity_805  1
    load_1_0_20  free_load_conservation_1210  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_21  arc_capacity_806  -25
    arc_1_0_21  depot_departure_or_bypass_1132  1
    arc_1_0_21  in_degree_1212  1
    arc_1_0_21  original_T_including_depot_unload_1221  7.2571167924583824e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_21  arc_capacity_806  1
    load_1_0_21  free_load_conservation_1216  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_0  arc_capacity_807  -25
    arc_1_5_0  depot_return_or_bypass_1133  1
    arc_1_5_0  out_degree_1134  1
    arc_1_5_0  original_T_including_depot_unload_1221  1.0479182987243917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_0  arc_capacity_807  1
    load_1_5_0  segment_load_conservation_1138  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_6  arc_capacity_808  -25
    arc_1_5_6  connected_order_arc_809  -14
    arc_1_5_6  out_degree_1134  1
    arc_1_5_6  in_degree_1142  1
    arc_1_5_6  original_T_including_depot_unload_1221  2.4155873404211835e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_5_6  arc_capacity_808  1
    load_1_5_6  segment_load_conservation_1138  1
    load_1_5_6  segment_load_conservation_1145  -1
    load_1_5_6  segment_prefix_lb_1146  1
    load_1_5_6  segment_prefix_ub_1147  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_7  arc_capacity_810  -25
    arc_1_5_7  connected_order_arc_811  -14
    arc_1_5_7  out_degree_1134  1
    arc_1_5_7  in_degree_1149  1
    arc_1_5_7  original_T_including_depot_unload_1221  9.9524628735690555e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_5_7  arc_capacity_810  1
    load_1_5_7  segment_load_conservation_1138  1
    load_1_5_7  segment_load_conservation_1152  -1
    load_1_5_7  segment_prefix_lb_1153  1
    load_1_5_7  segment_prefix_ub_1154  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_8  arc_capacity_812  -25
    arc_1_5_8  connected_order_arc_813  -14
    arc_1_5_8  out_degree_1134  1
    arc_1_5_8  in_degree_1156  1
    arc_1_5_8  original_T_including_depot_unload_1221  1.1592640472038677e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_8  arc_capacity_812  1
    load_1_5_8  segment_load_conservation_1138  1
    load_1_5_8  segment_load_conservation_1159  -1
    load_1_5_8  segment_prefix_lb_1160  1
    load_1_5_8  segment_prefix_ub_1161  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_9  arc_capacity_814  -25
    arc_1_5_9  connected_order_arc_815  -14
    arc_1_5_9  out_degree_1134  1
    arc_1_5_9  in_degree_1163  1
    arc_1_5_9  original_T_including_depot_unload_1221  9.2235470209829464e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_5_9  arc_capacity_814  1
    load_1_5_9  segment_load_conservation_1138  1
    load_1_5_9  segment_load_conservation_1166  -1
    load_1_5_9  segment_prefix_lb_1167  1
    load_1_5_9  segment_prefix_ub_1168  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_14  arc_capacity_816  -25
    arc_1_5_14  connected_order_arc_817  -14
    arc_1_5_14  out_degree_1134  1
    arc_1_5_14  in_degree_1170  1
    arc_1_5_14  original_T_including_depot_unload_1221  1.2492199513695298e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_14  arc_capacity_816  1
    load_1_5_14  segment_load_conservation_1138  1
    load_1_5_14  free_load_conservation_1174  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_15  arc_capacity_818  -25
    arc_1_5_15  connected_order_arc_819  -14
    arc_1_5_15  out_degree_1134  1
    arc_1_5_15  in_degree_1176  1
    arc_1_5_15  original_T_including_depot_unload_1221  1.2309802293463208e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_15  arc_capacity_818  1
    load_1_5_15  segment_load_conservation_1138  1
    load_1_5_15  free_load_conservation_1180  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_16  arc_capacity_820  -25
    arc_1_5_16  connected_order_arc_821  -14
    arc_1_5_16  out_degree_1134  1
    arc_1_5_16  in_degree_1182  1
    arc_1_5_16  original_T_including_depot_unload_1221  5.2280951376932137e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_5_16  arc_capacity_820  1
    load_1_5_16  segment_load_conservation_1138  1
    load_1_5_16  free_load_conservation_1186  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_17  arc_capacity_822  -25
    arc_1_5_17  connected_order_arc_823  -14
    arc_1_5_17  out_degree_1134  1
    arc_1_5_17  in_degree_1188  1
    arc_1_5_17  original_T_including_depot_unload_1221  1.3852878731513219e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_17  arc_capacity_822  1
    load_1_5_17  segment_load_conservation_1138  1
    load_1_5_17  free_load_conservation_1192  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_18  arc_capacity_824  -25
    arc_1_5_18  connected_order_arc_825  -14
    arc_1_5_18  out_degree_1134  1
    arc_1_5_18  in_degree_1194  1
    arc_1_5_18  original_T_including_depot_unload_1221  1.0880068546845516e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_18  arc_capacity_824  1
    load_1_5_18  segment_load_conservation_1138  1
    load_1_5_18  free_load_conservation_1198  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_19  arc_capacity_826  -25
    arc_1_5_19  connected_order_arc_827  -14
    arc_1_5_19  out_degree_1134  1
    arc_1_5_19  in_degree_1200  1
    arc_1_5_19  original_T_including_depot_unload_1221  1.5230377993795889e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_19  arc_capacity_826  1
    load_1_5_19  segment_load_conservation_1138  1
    load_1_5_19  free_load_conservation_1204  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_20  arc_capacity_828  -25
    arc_1_5_20  connected_order_arc_829  -14
    arc_1_5_20  out_degree_1134  1
    arc_1_5_20  in_degree_1206  1
    arc_1_5_20  original_T_including_depot_unload_1221  1.7883808204567979e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_20  arc_capacity_828  1
    load_1_5_20  segment_load_conservation_1138  1
    load_1_5_20  free_load_conservation_1210  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_21  arc_capacity_830  -25
    arc_1_5_21  connected_order_arc_831  -14
    arc_1_5_21  out_degree_1134  1
    arc_1_5_21  in_degree_1212  1
    arc_1_5_21  original_T_including_depot_unload_1221  1.5393972350798747e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_21  arc_capacity_830  1
    load_1_5_21  segment_load_conservation_1138  1
    load_1_5_21  free_load_conservation_1216  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_0  arc_capacity_832  -25
    arc_1_6_0  depot_return_or_bypass_1133  1
    arc_1_6_0  out_degree_1141  1
    arc_1_6_0  original_T_including_depot_unload_1221  887.312716328479
    MARKER    'MARKER'                 'INTEND'
    load_1_6_0  arc_capacity_832  1
    load_1_6_0  segment_load_conservation_1145  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_5  arc_capacity_833  -25
    arc_1_6_5  connected_order_arc_834  -14
    arc_1_6_5  in_degree_1135  1
    arc_1_6_5  out_degree_1141  1
    arc_1_6_5  original_T_including_depot_unload_1221  7.8136221151890174e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_5  arc_capacity_833  1
    load_1_6_5  segment_load_conservation_1138  -1
    load_1_6_5  segment_prefix_lb_1139  1
    load_1_6_5  segment_prefix_ub_1140  1
    load_1_6_5  segment_load_conservation_1145  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_7  arc_capacity_835  -25
    arc_1_6_7  connected_order_arc_836  -14
    arc_1_6_7  out_degree_1141  1
    arc_1_6_7  in_degree_1149  1
    arc_1_6_7  original_T_including_depot_unload_1221  1.1119949880978965e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_7  arc_capacity_835  1
    load_1_6_7  segment_load_conservation_1145  1
    load_1_6_7  segment_load_conservation_1152  -1
    load_1_6_7  segment_prefix_lb_1153  1
    load_1_6_7  segment_prefix_ub_1154  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_8  arc_capacity_837  -25
    arc_1_6_8  connected_order_arc_838  -14
    arc_1_6_8  out_degree_1141  1
    arc_1_6_8  in_degree_1156  1
    arc_1_6_8  original_T_including_depot_unload_1221  4.9711893625650669e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_8  arc_capacity_837  1
    load_1_6_8  segment_load_conservation_1145  1
    load_1_6_8  segment_load_conservation_1159  -1
    load_1_6_8  segment_prefix_lb_1160  1
    load_1_6_8  segment_prefix_ub_1161  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_9  arc_capacity_839  -25
    arc_1_6_9  connected_order_arc_840  -14
    arc_1_6_9  out_degree_1141  1
    arc_1_6_9  in_degree_1163  1
    arc_1_6_9  original_T_including_depot_unload_1221  8.4332546654485930e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_9  arc_capacity_839  1
    load_1_6_9  segment_load_conservation_1145  1
    load_1_6_9  segment_load_conservation_1166  -1
    load_1_6_9  segment_prefix_lb_1167  1
    load_1_6_9  segment_prefix_ub_1168  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_14  arc_capacity_841  -25
    arc_1_6_14  connected_order_arc_842  -14
    arc_1_6_14  out_degree_1141  1
    arc_1_6_14  in_degree_1170  1
    arc_1_6_14  original_T_including_depot_unload_1221  1.3473492742338772e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_14  arc_capacity_841  1
    load_1_6_14  segment_load_conservation_1145  1
    load_1_6_14  free_load_conservation_1174  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_15  arc_capacity_843  -25
    arc_1_6_15  connected_order_arc_844  -14
    arc_1_6_15  out_degree_1141  1
    arc_1_6_15  in_degree_1176  1
    arc_1_6_15  original_T_including_depot_unload_1221  1.1485840683203917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_15  arc_capacity_843  1
    load_1_6_15  segment_load_conservation_1145  1
    load_1_6_15  free_load_conservation_1180  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_16  arc_capacity_845  -25
    arc_1_6_16  connected_order_arc_846  -14
    arc_1_6_16  out_degree_1141  1
    arc_1_6_16  in_degree_1182  1
    arc_1_6_16  original_T_including_depot_unload_1221  1.4573788798892317e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_16  arc_capacity_845  1
    load_1_6_16  segment_load_conservation_1145  1
    load_1_6_16  free_load_conservation_1186  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_17  arc_capacity_847  -25
    arc_1_6_17  connected_order_arc_848  -14
    arc_1_6_17  out_degree_1141  1
    arc_1_6_17  in_degree_1188  1
    arc_1_6_17  original_T_including_depot_unload_1221  1.6048175645110312e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_17  arc_capacity_847  1
    load_1_6_17  segment_load_conservation_1145  1
    load_1_6_17  free_load_conservation_1192  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_18  arc_capacity_849  -25
    arc_1_6_18  connected_order_arc_850  -14
    arc_1_6_18  out_degree_1141  1
    arc_1_6_18  in_degree_1194  1
    arc_1_6_18  original_T_including_depot_unload_1221  3.3422575089633142e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_18  arc_capacity_849  1
    load_1_6_18  segment_load_conservation_1145  1
    load_1_6_18  free_load_conservation_1198  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_19  arc_capacity_851  -25
    arc_1_6_19  connected_order_arc_852  -14
    arc_1_6_19  out_degree_1141  1
    arc_1_6_19  in_degree_1200  1
    arc_1_6_19  original_T_including_depot_unload_1221  1.4586590520122220e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_19  arc_capacity_851  1
    load_1_6_19  segment_load_conservation_1145  1
    load_1_6_19  free_load_conservation_1204  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_20  arc_capacity_853  -25
    arc_1_6_20  connected_order_arc_854  -14
    arc_1_6_20  out_degree_1141  1
    arc_1_6_20  in_degree_1206  1
    arc_1_6_20  original_T_including_depot_unload_1221  2226.1143218952
    MARKER    'MARKER'                 'INTEND'
    load_1_6_20  arc_capacity_853  1
    load_1_6_20  segment_load_conservation_1145  1
    load_1_6_20  free_load_conservation_1210  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_21  arc_capacity_855  -25
    arc_1_6_21  connected_order_arc_856  -14
    arc_1_6_21  out_degree_1141  1
    arc_1_6_21  in_degree_1212  1
    arc_1_6_21  original_T_including_depot_unload_1221  1.6110158249463705e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_21  arc_capacity_855  1
    load_1_6_21  segment_load_conservation_1145  1
    load_1_6_21  free_load_conservation_1216  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_0  arc_capacity_857  -25
    arc_1_7_0  depot_return_or_bypass_1133  1
    arc_1_7_0  out_degree_1148  1
    arc_1_7_0  original_T_including_depot_unload_1221  7.8195480223834068e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_0  arc_capacity_857  1
    load_1_7_0  segment_load_conservation_1152  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_5  arc_capacity_858  -25
    arc_1_7_5  connected_order_arc_859  -14
    arc_1_7_5  in_degree_1135  1
    arc_1_7_5  out_degree_1148  1
    arc_1_7_5  original_T_including_depot_unload_1221  7.0804311489116617e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_5  arc_capacity_858  1
    load_1_7_5  segment_load_conservation_1138  -1
    load_1_7_5  segment_prefix_lb_1139  1
    load_1_7_5  segment_prefix_ub_1140  1
    load_1_7_5  segment_load_conservation_1152  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_6  arc_capacity_860  -25
    arc_1_7_6  connected_order_arc_861  -14
    arc_1_7_6  in_degree_1142  1
    arc_1_7_6  out_degree_1148  1
    arc_1_7_6  original_T_including_depot_unload_1221  1.0062397105603651e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_6  arc_capacity_860  1
    load_1_7_6  segment_load_conservation_1145  -1
    load_1_7_6  segment_prefix_lb_1146  1
    load_1_7_6  segment_prefix_ub_1147  1
    load_1_7_6  segment_load_conservation_1152  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_8  arc_capacity_862  -25
    arc_1_7_8  connected_order_arc_863  -14
    arc_1_7_8  out_degree_1148  1
    arc_1_7_8  in_degree_1156  1
    arc_1_7_8  original_T_including_depot_unload_1221  4.1964259385165178e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_8  arc_capacity_862  1
    load_1_7_8  segment_load_conservation_1152  1
    load_1_7_8  segment_load_conservation_1159  -1
    load_1_7_8  segment_prefix_lb_1160  1
    load_1_7_8  segment_prefix_ub_1161  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_9  arc_capacity_864  -25
    arc_1_7_9  connected_order_arc_865  -14
    arc_1_7_9  out_degree_1148  1
    arc_1_7_9  in_degree_1163  1
    arc_1_7_9  original_T_including_depot_unload_1221  7.3394466063263269e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_9  arc_capacity_864  1
    load_1_7_9  segment_load_conservation_1152  1
    load_1_7_9  segment_load_conservation_1166  -1
    load_1_7_9  segment_prefix_lb_1167  1
    load_1_7_9  segment_prefix_ub_1168  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_14  arc_capacity_866  -25
    arc_1_7_14  connected_order_arc_867  -14
    arc_1_7_14  out_degree_1148  1
    arc_1_7_14  in_degree_1170  1
    arc_1_7_14  original_T_including_depot_unload_1221  1.2399741997148888e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_14  arc_capacity_866  1
    load_1_7_14  segment_load_conservation_1152  1
    load_1_7_14  free_load_conservation_1174  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_15  arc_capacity_868  -25
    arc_1_7_15  connected_order_arc_869  -14
    arc_1_7_15  out_degree_1148  1
    arc_1_7_15  in_degree_1176  1
    arc_1_7_15  original_T_including_depot_unload_1221  1.0453757248865720e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_15  arc_capacity_868  1
    load_1_7_15  segment_load_conservation_1152  1
    load_1_7_15  free_load_conservation_1180  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_16  arc_capacity_870  -25
    arc_1_7_16  connected_order_arc_871  -14
    arc_1_7_16  out_degree_1148  1
    arc_1_7_16  in_degree_1182  1
    arc_1_7_16  original_T_including_depot_unload_1221  1.3626829404511475e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_16  arc_capacity_870  1
    load_1_7_16  segment_load_conservation_1152  1
    load_1_7_16  free_load_conservation_1186  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_17  arc_capacity_872  -25
    arc_1_7_17  connected_order_arc_873  -14
    arc_1_7_17  out_degree_1148  1
    arc_1_7_17  in_degree_1188  1
    arc_1_7_17  original_T_including_depot_unload_1221  1.4961553163922974e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_17  arc_capacity_872  1
    load_1_7_17  segment_load_conservation_1152  1
    load_1_7_17  free_load_conservation_1192  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_18  arc_capacity_874  -25
    arc_1_7_18  connected_order_arc_875  -14
    arc_1_7_18  out_degree_1148  1
    arc_1_7_18  in_degree_1194  1
    arc_1_7_18  original_T_including_depot_unload_1221  2.5572087458878266e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_18  arc_capacity_874  1
    load_1_7_18  segment_load_conservation_1152  1
    load_1_7_18  free_load_conservation_1198  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_19  arc_capacity_876  -25
    arc_1_7_19  connected_order_arc_877  -14
    arc_1_7_19  out_degree_1148  1
    arc_1_7_19  in_degree_1200  1
    arc_1_7_19  original_T_including_depot_unload_1221  1.3593311700505531e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_19  arc_capacity_876  1
    load_1_7_19  segment_load_conservation_1152  1
    load_1_7_19  free_load_conservation_1204  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_20  arc_capacity_878  -25
    arc_1_7_20  connected_order_arc_879  -14
    arc_1_7_20  out_degree_1148  1
    arc_1_7_20  in_degree_1206  1
    arc_1_7_20  original_T_including_depot_unload_1221  2115.53677476792
    MARKER    'MARKER'                 'INTEND'
    load_1_7_20  arc_capacity_878  1
    load_1_7_20  segment_load_conservation_1152  1
    load_1_7_20  free_load_conservation_1210  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_21  arc_capacity_880  -25
    arc_1_7_21  connected_order_arc_881  -14
    arc_1_7_21  out_degree_1148  1
    arc_1_7_21  in_degree_1212  1
    arc_1_7_21  original_T_including_depot_unload_1221  1.5070416710648517e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_21  arc_capacity_880  1
    load_1_7_21  segment_load_conservation_1152  1
    load_1_7_21  free_load_conservation_1216  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_0  arc_capacity_882  -25
    arc_1_8_0  depot_return_or_bypass_1133  1
    arc_1_8_0  out_degree_1155  1
    arc_1_8_0  original_T_including_depot_unload_1221  4.7522445589173662e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_0  arc_capacity_882  1
    load_1_8_0  segment_load_conservation_1159  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_5  arc_capacity_883  -25
    arc_1_8_5  connected_order_arc_884  -14
    arc_1_8_5  in_degree_1135  1
    arc_1_8_5  out_degree_1155  1
    arc_1_8_5  original_T_including_depot_unload_1221  9.0121368945211725e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_5  arc_capacity_883  1
    load_1_8_5  segment_load_conservation_1138  -1
    load_1_8_5  segment_prefix_lb_1139  1
    load_1_8_5  segment_prefix_ub_1140  1
    load_1_8_5  segment_load_conservation_1159  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_6  arc_capacity_885  -25
    arc_1_8_6  connected_order_arc_886  -14
    arc_1_8_6  in_degree_1142  1
    arc_1_8_6  out_degree_1155  1
    arc_1_8_6  original_T_including_depot_unload_1221  1.0793944823036150e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_6  arc_capacity_885  1
    load_1_8_6  segment_load_conservation_1145  -1
    load_1_8_6  segment_prefix_lb_1146  1
    load_1_8_6  segment_prefix_ub_1147  1
    load_1_8_6  segment_load_conservation_1159  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_7  arc_capacity_887  -25
    arc_1_8_7  connected_order_arc_888  -14
    arc_1_8_7  in_degree_1149  1
    arc_1_8_7  out_degree_1155  1
    arc_1_8_7  original_T_including_depot_unload_1221  4.1964259385165178e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_7  arc_capacity_887  1
    load_1_8_7  segment_load_conservation_1152  -1
    load_1_8_7  segment_prefix_lb_1153  1
    load_1_8_7  segment_prefix_ub_1154  1
    load_1_8_7  segment_load_conservation_1159  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_9  arc_capacity_889  -25
    arc_1_8_9  connected_order_arc_890  -14
    arc_1_8_9  out_degree_1155  1
    arc_1_8_9  in_degree_1163  1
    arc_1_8_9  original_T_including_depot_unload_1221  4.9232225330062903e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_9  arc_capacity_889  1
    load_1_8_9  segment_load_conservation_1159  1
    load_1_8_9  segment_load_conservation_1166  -1
    load_1_8_9  segment_prefix_lb_1167  1
    load_1_8_9  segment_prefix_ub_1168  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_14  arc_capacity_891  -25
    arc_1_8_14  connected_order_arc_892  -14
    arc_1_8_14  out_degree_1155  1
    arc_1_8_14  in_degree_1170  1
    arc_1_8_14  original_T_including_depot_unload_1221  9.2985081319651772e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_14  arc_capacity_891  1
    load_1_8_14  segment_load_conservation_1159  1
    load_1_8_14  free_load_conservation_1174  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_15  arc_capacity_893  -25
    arc_1_8_15  connected_order_arc_894  -14
    arc_1_8_15  out_degree_1155  1
    arc_1_8_15  in_degree_1176  1
    arc_1_8_15  original_T_including_depot_unload_1221  7.0350721341213284e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_15  arc_capacity_893  1
    load_1_8_15  segment_load_conservation_1159  1
    load_1_8_15  free_load_conservation_1180  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_16  arc_capacity_895  -25
    arc_1_8_16  connected_order_arc_896  -14
    arc_1_8_16  out_degree_1155  1
    arc_1_8_16  in_degree_1182  1
    arc_1_8_16  original_T_including_depot_unload_1221  1.3823927712314810e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_16  arc_capacity_895  1
    load_1_8_16  segment_load_conservation_1159  1
    load_1_8_16  free_load_conservation_1186  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_17  arc_capacity_897  -25
    arc_1_8_17  connected_order_arc_898  -14
    arc_1_8_17  out_degree_1155  1
    arc_1_8_17  in_degree_1188  1
    arc_1_8_17  original_T_including_depot_unload_1221  1.1957430085580884e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_17  arc_capacity_897  1
    load_1_8_17  segment_load_conservation_1159  1
    load_1_8_17  free_load_conservation_1192  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_18  arc_capacity_899  -25
    arc_1_8_18  connected_order_arc_900  -14
    arc_1_8_18  out_degree_1155  1
    arc_1_8_18  in_degree_1194  1
    arc_1_8_18  original_T_including_depot_unload_1221  1.6444540482789353e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_18  arc_capacity_899  1
    load_1_8_18  segment_load_conservation_1159  1
    load_1_8_18  free_load_conservation_1198  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_19  arc_capacity_901  -25
    arc_1_8_19  connected_order_arc_902  -14
    arc_1_8_19  out_degree_1155  1
    arc_1_8_19  in_degree_1200  1
    arc_1_8_19  original_T_including_depot_unload_1221  987.973588780524
    MARKER    'MARKER'                 'INTEND'
    load_1_8_19  arc_capacity_901  1
    load_1_8_19  segment_load_conservation_1159  1
    load_1_8_19  free_load_conservation_1204  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_20  arc_capacity_903  -25
    arc_1_8_20  connected_order_arc_904  -14
    arc_1_8_20  out_degree_1155  1
    arc_1_8_20  in_degree_1206  1
    arc_1_8_20  original_T_including_depot_unload_1221  1.8418804985785646e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_20  arc_capacity_903  1
    load_1_8_20  segment_load_conservation_1159  1
    load_1_8_20  free_load_conservation_1210  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_21  arc_capacity_905  -25
    arc_1_8_21  connected_order_arc_906  -14
    arc_1_8_21  out_degree_1155  1
    arc_1_8_21  in_degree_1212  1
    arc_1_8_21  original_T_including_depot_unload_1221  1.1605914703789122e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_21  arc_capacity_905  1
    load_1_8_21  segment_load_conservation_1159  1
    load_1_8_21  free_load_conservation_1216  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_0  arc_capacity_907  -25
    arc_1_9_0  depot_return_or_bypass_1133  1
    arc_1_9_0  out_degree_1162  1
    arc_1_9_0  original_T_including_depot_unload_1221  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_0  arc_capacity_907  1
    load_1_9_0  segment_load_conservation_1166  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_5  arc_capacity_908  -25
    arc_1_9_5  connected_order_arc_909  -14
    arc_1_9_5  in_degree_1135  1
    arc_1_9_5  out_degree_1162  1
    arc_1_9_5  original_T_including_depot_unload_1221  7.5571464781430223e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_5  arc_capacity_908  1
    load_1_9_5  segment_load_conservation_1138  -1
    load_1_9_5  segment_prefix_lb_1139  1
    load_1_9_5  segment_prefix_ub_1140  1
    load_1_9_5  segment_load_conservation_1166  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_6  arc_capacity_910  -25
    arc_1_9_6  connected_order_arc_911  -14
    arc_1_9_6  in_degree_1142  1
    arc_1_9_6  out_degree_1162  1
    arc_1_9_6  original_T_including_depot_unload_1221  7.5634788469878674e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_6  arc_capacity_910  1
    load_1_9_6  segment_load_conservation_1145  -1
    load_1_9_6  segment_prefix_lb_1146  1
    load_1_9_6  segment_prefix_ub_1147  1
    load_1_9_6  segment_load_conservation_1166  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_7  arc_capacity_912  -25
    arc_1_9_7  connected_order_arc_913  -14
    arc_1_9_7  in_degree_1149  1
    arc_1_9_7  out_degree_1162  1
    arc_1_9_7  original_T_including_depot_unload_1221  7.3394466063263269e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_7  arc_capacity_912  1
    load_1_9_7  segment_load_conservation_1152  -1
    load_1_9_7  segment_prefix_lb_1153  1
    load_1_9_7  segment_prefix_ub_1154  1
    load_1_9_7  segment_load_conservation_1166  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_8  arc_capacity_914  -25
    arc_1_9_8  connected_order_arc_915  -14
    arc_1_9_8  in_degree_1156  1
    arc_1_9_8  out_degree_1162  1
    arc_1_9_8  original_T_including_depot_unload_1221  4.9232225330062903e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_8  arc_capacity_914  1
    load_1_9_8  segment_load_conservation_1159  -1
    load_1_9_8  segment_prefix_lb_1160  1
    load_1_9_8  segment_prefix_ub_1161  1
    load_1_9_8  segment_load_conservation_1166  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_14  arc_capacity_916  -25
    arc_1_9_14  connected_order_arc_917  -14
    arc_1_9_14  out_degree_1162  1
    arc_1_9_14  in_degree_1170  1
    arc_1_9_14  original_T_including_depot_unload_1221  5.1177250003741761e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_14  arc_capacity_916  1
    load_1_9_14  segment_load_conservation_1166  1
    load_1_9_14  free_load_conservation_1174  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_15  arc_capacity_918  -25
    arc_1_9_15  connected_order_arc_919  -14
    arc_1_9_15  out_degree_1162  1
    arc_1_9_15  in_degree_1176  1
    arc_1_9_15  original_T_including_depot_unload_1221  359.975566576564
    MARKER    'MARKER'                 'INTEND'
    load_1_9_15  arc_capacity_918  1
    load_1_9_15  segment_load_conservation_1166  1
    load_1_9_15  free_load_conservation_1180  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_16  arc_capacity_920  -25
    arc_1_9_16  connected_order_arc_921  -14
    arc_1_9_16  out_degree_1162  1
    arc_1_9_16  in_degree_1182  1
    arc_1_9_16  original_T_including_depot_unload_1221  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_16  arc_capacity_920  1
    load_1_9_16  segment_load_conservation_1166  1
    load_1_9_16  free_load_conservation_1186  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_17  arc_capacity_922  -25
    arc_1_9_17  connected_order_arc_923  -14
    arc_1_9_17  out_degree_1162  1
    arc_1_9_17  in_degree_1188  1
    arc_1_9_17  original_T_including_depot_unload_1221  7.6275540057842773e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_17  arc_capacity_922  1
    load_1_9_17  segment_load_conservation_1166  1
    load_1_9_17  free_load_conservation_1192  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_18  arc_capacity_924  -25
    arc_1_9_18  connected_order_arc_925  -14
    arc_1_9_18  out_degree_1162  1
    arc_1_9_18  in_degree_1194  1
    arc_1_9_18  original_T_including_depot_unload_1221  5.7102904773674652e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_18  arc_capacity_924  1
    load_1_9_18  segment_load_conservation_1166  1
    load_1_9_18  free_load_conservation_1198  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_19  arc_capacity_926  -25
    arc_1_9_19  connected_order_arc_927  -14
    arc_1_9_19  out_degree_1162  1
    arc_1_9_19  in_degree_1200  1
    arc_1_9_19  original_T_including_depot_unload_1221  6.8881953094806647e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_19  arc_capacity_926  1
    load_1_9_19  segment_load_conservation_1166  1
    load_1_9_19  free_load_conservation_1204  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_20  arc_capacity_928  -25
    arc_1_9_20  connected_order_arc_929  -14
    arc_1_9_20  out_degree_1162  1
    arc_1_9_20  in_degree_1206  1
    arc_1_9_20  original_T_including_depot_unload_1221  1.3857128117205509e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_20  arc_capacity_928  1
    load_1_9_20  segment_load_conservation_1166  1
    load_1_9_20  free_load_conservation_1210  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_21  arc_capacity_930  -25
    arc_1_9_21  connected_order_arc_931  -14
    arc_1_9_21  out_degree_1162  1
    arc_1_9_21  in_degree_1212  1
    arc_1_9_21  original_T_including_depot_unload_1221  7.9613989083692911e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_21  arc_capacity_930  1
    load_1_9_21  segment_load_conservation_1166  1
    load_1_9_21  free_load_conservation_1216  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_0  arc_capacity_932  -25
    arc_1_14_0  depot_return_or_bypass_1133  1
    arc_1_14_0  out_degree_1169  1
    arc_1_14_0  original_T_including_depot_unload_1221  4.6364706268001146e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_0  arc_capacity_932  1
    load_1_14_0  free_load_conservation_1174  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_5  arc_capacity_933  -25
    arc_1_14_5  connected_order_arc_934  -14
    arc_1_14_5  in_degree_1135  1
    arc_1_14_5  out_degree_1169  1
    arc_1_14_5  original_T_including_depot_unload_1221  1.1724800521319269e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_5  arc_capacity_933  1
    load_1_14_5  segment_load_conservation_1138  -1
    load_1_14_5  segment_prefix_lb_1139  1
    load_1_14_5  segment_prefix_ub_1140  1
    load_1_14_5  free_load_conservation_1174  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_6  arc_capacity_935  -25
    arc_1_14_6  connected_order_arc_936  -14
    arc_1_14_6  in_degree_1142  1
    arc_1_14_6  out_degree_1169  1
    arc_1_14_6  original_T_including_depot_unload_1221  1.0250717569202773e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_6  arc_capacity_935  1
    load_1_14_6  segment_load_conservation_1145  -1
    load_1_14_6  segment_prefix_lb_1146  1
    load_1_14_6  segment_prefix_ub_1147  1
    load_1_14_6  free_load_conservation_1174  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_7  arc_capacity_937  -25
    arc_1_14_7  connected_order_arc_938  -14
    arc_1_14_7  in_degree_1149  1
    arc_1_14_7  out_degree_1169  1
    arc_1_14_7  original_T_including_depot_unload_1221  1.2399741997148888e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_7  arc_capacity_937  1
    load_1_14_7  segment_load_conservation_1152  -1
    load_1_14_7  segment_prefix_lb_1153  1
    load_1_14_7  segment_prefix_ub_1154  1
    load_1_14_7  free_load_conservation_1174  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_8  arc_capacity_939  -25
    arc_1_14_8  connected_order_arc_940  -14
    arc_1_14_8  in_degree_1156  1
    arc_1_14_8  out_degree_1169  1
    arc_1_14_8  original_T_including_depot_unload_1221  9.2985081319651772e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_8  arc_capacity_939  1
    load_1_14_8  segment_load_conservation_1159  -1
    load_1_14_8  segment_prefix_lb_1160  1
    load_1_14_8  segment_prefix_ub_1161  1
    load_1_14_8  free_load_conservation_1174  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_9  arc_capacity_941  -25
    arc_1_14_9  connected_order_arc_942  -14
    arc_1_14_9  in_degree_1163  1
    arc_1_14_9  out_degree_1169  1
    arc_1_14_9  original_T_including_depot_unload_1221  5.1177250003741761e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_9  arc_capacity_941  1
    load_1_14_9  segment_load_conservation_1166  -1
    load_1_14_9  segment_prefix_lb_1167  1
    load_1_14_9  segment_prefix_ub_1168  1
    load_1_14_9  free_load_conservation_1174  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_15  arc_capacity_943  -25
    arc_1_14_15  connected_order_arc_944  -14
    arc_1_14_15  out_degree_1169  1
    arc_1_14_15  in_degree_1176  1
    arc_1_14_15  original_T_including_depot_unload_1221  2.4191291221621205e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_15  arc_capacity_943  1
    load_1_14_15  free_load_conservation_1174  1
    load_1_14_15  free_load_conservation_1180  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_16  arc_capacity_945  -25
    arc_1_14_16  connected_order_arc_946  -14
    arc_1_14_16  out_degree_1169  1
    arc_1_14_16  in_degree_1182  1
    arc_1_14_16  original_T_including_depot_unload_1221  1075.72043838369
    MARKER    'MARKER'                 'INTEND'
    load_1_14_16  arc_capacity_945  1
    load_1_14_16  free_load_conservation_1174  1
    load_1_14_16  free_load_conservation_1186  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_17  arc_capacity_947  -25
    arc_1_14_17  connected_order_arc_948  -14
    arc_1_14_17  out_degree_1169  1
    arc_1_14_17  in_degree_1188  1
    arc_1_14_17  original_T_including_depot_unload_1221  2.6602972191926557e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_17  arc_capacity_947  1
    load_1_14_17  free_load_conservation_1174  1
    load_1_14_17  free_load_conservation_1192  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_18  arc_capacity_949  -25
    arc_1_14_18  connected_order_arc_950  -14
    arc_1_14_18  out_degree_1169  1
    arc_1_14_18  in_degree_1194  1
    arc_1_14_18  original_T_including_depot_unload_1221  1.0491196843462671e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_18  arc_capacity_949  1
    load_1_14_18  free_load_conservation_1174  1
    load_1_14_18  free_load_conservation_1198  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_19  arc_capacity_951  -25
    arc_1_14_19  connected_order_arc_952  -14
    arc_1_14_19  out_degree_1169  1
    arc_1_14_19  in_degree_1200  1
    arc_1_14_19  original_T_including_depot_unload_1221  2.9706418113632907e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_19  arc_capacity_951  1
    load_1_14_19  free_load_conservation_1174  1
    load_1_14_19  free_load_conservation_1204  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_20  arc_capacity_953  -25
    arc_1_14_20  connected_order_arc_954  -14
    arc_1_14_20  out_degree_1169  1
    arc_1_14_20  in_degree_1206  1
    arc_1_14_20  original_T_including_depot_unload_1221  9.1576870176747968e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_20  arc_capacity_953  1
    load_1_14_20  free_load_conservation_1174  1
    load_1_14_20  free_load_conservation_1210  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_21  arc_capacity_955  -25
    arc_1_14_21  connected_order_arc_956  -14
    arc_1_14_21  out_degree_1169  1
    arc_1_14_21  in_degree_1212  1
    arc_1_14_21  original_T_including_depot_unload_1221  3.0055050459786975e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_21  arc_capacity_955  1
    load_1_14_21  free_load_conservation_1174  1
    load_1_14_21  free_load_conservation_1216  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_0  arc_capacity_957  -25
    arc_1_15_0  depot_return_or_bypass_1133  1
    arc_1_15_0  out_degree_1175  1
    arc_1_15_0  original_T_including_depot_unload_1221  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_0  arc_capacity_957  1
    load_1_15_0  free_load_conservation_1180  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_5  arc_capacity_958  -25
    arc_1_15_5  connected_order_arc_959  -14
    arc_1_15_5  in_degree_1135  1
    arc_1_15_5  out_degree_1175  1
    arc_1_15_5  original_T_including_depot_unload_1221  1.1005939447212634e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_5  arc_capacity_958  1
    load_1_15_5  segment_load_conservation_1138  -1
    load_1_15_5  segment_prefix_lb_1139  1
    load_1_15_5  segment_prefix_ub_1140  1
    load_1_15_5  free_load_conservation_1180  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_6  arc_capacity_960  -25
    arc_1_15_6  connected_order_arc_961  -14
    arc_1_15_6  in_degree_1142  1
    arc_1_15_6  out_degree_1175  1
    arc_1_15_6  original_T_including_depot_unload_1221  1.0311494902403294e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_6  arc_capacity_960  1
    load_1_15_6  segment_load_conservation_1145  -1
    load_1_15_6  segment_prefix_lb_1146  1
    load_1_15_6  segment_prefix_ub_1147  1
    load_1_15_6  free_load_conservation_1180  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_7  arc_capacity_962  -25
    arc_1_15_7  connected_order_arc_963  -14
    arc_1_15_7  in_degree_1149  1
    arc_1_15_7  out_degree_1175  1
    arc_1_15_7  original_T_including_depot_unload_1221  1.0453757248865720e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_7  arc_capacity_962  1
    load_1_15_7  segment_load_conservation_1152  -1
    load_1_15_7  segment_prefix_lb_1153  1
    load_1_15_7  segment_prefix_ub_1154  1
    load_1_15_7  free_load_conservation_1180  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_8  arc_capacity_964  -25
    arc_1_15_8  connected_order_arc_965  -14
    arc_1_15_8  in_degree_1156  1
    arc_1_15_8  out_degree_1175  1
    arc_1_15_8  original_T_including_depot_unload_1221  7.0350721341213284e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_8  arc_capacity_964  1
    load_1_15_8  segment_load_conservation_1159  -1
    load_1_15_8  segment_prefix_lb_1160  1
    load_1_15_8  segment_prefix_ub_1161  1
    load_1_15_8  free_load_conservation_1180  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_9  arc_capacity_966  -25
    arc_1_15_9  connected_order_arc_967  -14
    arc_1_15_9  in_degree_1163  1
    arc_1_15_9  out_degree_1175  1
    arc_1_15_9  original_T_including_depot_unload_1221  359.975566576564
    MARKER    'MARKER'                 'INTEND'
    load_1_15_9  arc_capacity_966  1
    load_1_15_9  segment_load_conservation_1166  -1
    load_1_15_9  segment_prefix_lb_1167  1
    load_1_15_9  segment_prefix_ub_1168  1
    load_1_15_9  free_load_conservation_1180  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_14  arc_capacity_968  -25
    arc_1_15_14  connected_order_arc_969  -14
    arc_1_15_14  in_degree_1170  1
    arc_1_15_14  out_degree_1175  1
    arc_1_15_14  original_T_including_depot_unload_1221  2.4191291221621205e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_14  arc_capacity_968  1
    load_1_15_14  free_load_conservation_1174  -1
    load_1_15_14  free_load_conservation_1180  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_16  arc_capacity_970  -25
    arc_1_15_16  connected_order_arc_971  -14
    arc_1_15_16  out_degree_1175  1
    arc_1_15_16  in_degree_1182  1
    arc_1_15_16  original_T_including_depot_unload_1221  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_16  arc_capacity_970  1
    load_1_15_16  free_load_conservation_1180  1
    load_1_15_16  free_load_conservation_1186  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_17  arc_capacity_972  -25
    arc_1_15_17  connected_order_arc_973  -14
    arc_1_15_17  out_degree_1175  1
    arc_1_15_17  in_degree_1188  1
    arc_1_15_17  original_T_including_depot_unload_1221  5.0315495126439691e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_17  arc_capacity_972  1
    load_1_15_17  free_load_conservation_1180  1
    load_1_15_17  free_load_conservation_1192  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_18  arc_capacity_974  -25
    arc_1_15_18  connected_order_arc_975  -14
    arc_1_15_18  out_degree_1175  1
    arc_1_15_18  in_degree_1194  1
    arc_1_15_18  original_T_including_depot_unload_1221  8.3486971116736720e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_18  arc_capacity_974  1
    load_1_15_18  free_load_conservation_1180  1
    load_1_15_18  free_load_conservation_1198  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_19  arc_capacity_976  -25
    arc_1_15_19  connected_order_arc_977  -14
    arc_1_15_19  out_degree_1175  1
    arc_1_15_19  in_degree_1200  1
    arc_1_15_19  original_T_including_depot_unload_1221  3.2938591738444967e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_19  arc_capacity_976  1
    load_1_15_19  free_load_conservation_1180  1
    load_1_15_19  free_load_conservation_1204  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_20  arc_capacity_978  -25
    arc_1_15_20  connected_order_arc_979  -14
    arc_1_15_20  out_degree_1175  1
    arc_1_15_20  in_degree_1206  1
    arc_1_15_20  original_T_including_depot_unload_1221  1.1544376314422677e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_20  arc_capacity_978  1
    load_1_15_20  free_load_conservation_1180  1
    load_1_15_20  free_load_conservation_1210  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_21  arc_capacity_980  -25
    arc_1_15_21  connected_order_arc_981  -14
    arc_1_15_21  out_degree_1175  1
    arc_1_15_21  in_degree_1212  1
    arc_1_15_21  original_T_including_depot_unload_1221  4.6276703023336785e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_21  arc_capacity_980  1
    load_1_15_21  free_load_conservation_1180  1
    load_1_15_21  free_load_conservation_1216  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_0  arc_capacity_982  -25
    arc_1_16_0  depot_return_or_bypass_1133  1
    arc_1_16_0  out_degree_1181  1
    arc_1_16_0  original_T_including_depot_unload_1221  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_0  arc_capacity_982  1
    load_1_16_0  free_load_conservation_1186  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_5  arc_capacity_983  -25
    arc_1_16_5  connected_order_arc_984  -14
    arc_1_16_5  in_degree_1135  1
    arc_1_16_5  out_degree_1181  1
    arc_1_16_5  original_T_including_depot_unload_1221  7.3227602527872671e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_5  arc_capacity_983  1
    load_1_16_5  segment_load_conservation_1138  -1
    load_1_16_5  segment_prefix_lb_1139  1
    load_1_16_5  segment_prefix_ub_1140  1
    load_1_16_5  free_load_conservation_1186  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_6  arc_capacity_985  -25
    arc_1_16_6  connected_order_arc_986  -14
    arc_1_16_6  in_degree_1142  1
    arc_1_16_6  out_degree_1181  1
    arc_1_16_6  original_T_including_depot_unload_1221  3.6824909986567474e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_6  arc_capacity_985  1
    load_1_16_6  segment_load_conservation_1145  -1
    load_1_16_6  segment_prefix_lb_1146  1
    load_1_16_6  segment_prefix_ub_1147  1
    load_1_16_6  free_load_conservation_1186  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_7  arc_capacity_987  -25
    arc_1_16_7  connected_order_arc_988  -14
    arc_1_16_7  in_degree_1149  1
    arc_1_16_7  out_degree_1181  1
    arc_1_16_7  original_T_including_depot_unload_1221  1.3626829404511475e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_7  arc_capacity_987  1
    load_1_16_7  segment_load_conservation_1152  -1
    load_1_16_7  segment_prefix_lb_1153  1
    load_1_16_7  segment_prefix_ub_1154  1
    load_1_16_7  free_load_conservation_1186  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_8  arc_capacity_989  -25
    arc_1_16_8  connected_order_arc_990  -14
    arc_1_16_8  in_degree_1156  1
    arc_1_16_8  out_degree_1181  1
    arc_1_16_8  original_T_including_depot_unload_1221  1.3823927712314810e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_8  arc_capacity_989  1
    load_1_16_8  segment_load_conservation_1159  -1
    load_1_16_8  segment_prefix_lb_1160  1
    load_1_16_8  segment_prefix_ub_1161  1
    load_1_16_8  free_load_conservation_1186  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_9  arc_capacity_991  -25
    arc_1_16_9  connected_order_arc_992  -14
    arc_1_16_9  in_degree_1163  1
    arc_1_16_9  out_degree_1181  1
    arc_1_16_9  original_T_including_depot_unload_1221  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_9  arc_capacity_991  1
    load_1_16_9  segment_load_conservation_1166  -1
    load_1_16_9  segment_prefix_lb_1167  1
    load_1_16_9  segment_prefix_ub_1168  1
    load_1_16_9  free_load_conservation_1186  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_14  arc_capacity_993  -25
    arc_1_16_14  connected_order_arc_994  -14
    arc_1_16_14  in_degree_1170  1
    arc_1_16_14  out_degree_1181  1
    arc_1_16_14  original_T_including_depot_unload_1221  1075.72043838369
    MARKER    'MARKER'                 'INTEND'
    load_1_16_14  arc_capacity_993  1
    load_1_16_14  free_load_conservation_1174  -1
    load_1_16_14  free_load_conservation_1186  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_15  arc_capacity_995  -25
    arc_1_16_15  connected_order_arc_996  -14
    arc_1_16_15  in_degree_1176  1
    arc_1_16_15  out_degree_1181  1
    arc_1_16_15  original_T_including_depot_unload_1221  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_15  arc_capacity_995  1
    load_1_16_15  free_load_conservation_1180  -1
    load_1_16_15  free_load_conservation_1186  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_17  arc_capacity_997  -25
    arc_1_16_17  connected_order_arc_998  -14
    arc_1_16_17  out_degree_1181  1
    arc_1_16_17  in_degree_1188  1
    arc_1_16_17  original_T_including_depot_unload_1221  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_17  arc_capacity_997  1
    load_1_16_17  free_load_conservation_1186  1
    load_1_16_17  free_load_conservation_1192  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_18  arc_capacity_999  -25
    arc_1_16_18  connected_order_arc_1000  -14
    arc_1_16_18  out_degree_1181  1
    arc_1_16_18  in_degree_1194  1
    arc_1_16_18  original_T_including_depot_unload_1221  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_18  arc_capacity_999  1
    load_1_16_18  free_load_conservation_1186  1
    load_1_16_18  free_load_conservation_1198  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_19  arc_capacity_1001  -25
    arc_1_16_19  connected_order_arc_1002  -14
    arc_1_16_19  out_degree_1181  1
    arc_1_16_19  in_degree_1200  1
    arc_1_16_19  original_T_including_depot_unload_1221  1.3727638439182763e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_19  arc_capacity_1001  1
    load_1_16_19  free_load_conservation_1186  1
    load_1_16_19  free_load_conservation_1204  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_20  arc_capacity_1003  -25
    arc_1_16_20  connected_order_arc_1004  -14
    arc_1_16_20  out_degree_1181  1
    arc_1_16_20  in_degree_1206  1
    arc_1_16_20  original_T_including_depot_unload_1221  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_20  arc_capacity_1003  1
    load_1_16_20  free_load_conservation_1186  1
    load_1_16_20  free_load_conservation_1210  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_21  arc_capacity_1005  -25
    arc_1_16_21  connected_order_arc_1006  -14
    arc_1_16_21  out_degree_1181  1
    arc_1_16_21  in_degree_1212  1
    arc_1_16_21  original_T_including_depot_unload_1221  1.3163662834239574e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_21  arc_capacity_1005  1
    load_1_16_21  free_load_conservation_1186  1
    load_1_16_21  free_load_conservation_1216  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_0  arc_capacity_1007  -25
    arc_1_17_0  depot_return_or_bypass_1133  1
    arc_1_17_0  out_degree_1187  1
    arc_1_17_0  original_T_including_depot_unload_1221  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_0  arc_capacity_1007  1
    load_1_17_0  free_load_conservation_1192  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_5  arc_capacity_1008  -25
    arc_1_17_5  connected_order_arc_1009  -14
    arc_1_17_5  in_degree_1135  1
    arc_1_17_5  out_degree_1187  1
    arc_1_17_5  original_T_including_depot_unload_1221  1.3551088510632424e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_5  arc_capacity_1008  1
    load_1_17_5  segment_load_conservation_1138  -1
    load_1_17_5  segment_prefix_lb_1139  1
    load_1_17_5  segment_prefix_ub_1140  1
    load_1_17_5  free_load_conservation_1192  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_6  arc_capacity_1010  -25
    arc_1_17_6  connected_order_arc_1011  -14
    arc_1_17_6  in_degree_1142  1
    arc_1_17_6  out_degree_1187  1
    arc_1_17_6  original_T_including_depot_unload_1221  1.1479472058029019e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_6  arc_capacity_1010  1
    load_1_17_6  segment_load_conservation_1145  -1
    load_1_17_6  segment_prefix_lb_1146  1
    load_1_17_6  segment_prefix_ub_1147  1
    load_1_17_6  free_load_conservation_1192  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_7  arc_capacity_1012  -25
    arc_1_17_7  connected_order_arc_1013  -14
    arc_1_17_7  in_degree_1149  1
    arc_1_17_7  out_degree_1187  1
    arc_1_17_7  original_T_including_depot_unload_1221  1.4961553163922974e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_7  arc_capacity_1012  1
    load_1_17_7  segment_load_conservation_1152  -1
    load_1_17_7  segment_prefix_lb_1153  1
    load_1_17_7  segment_prefix_ub_1154  1
    load_1_17_7  free_load_conservation_1192  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_8  arc_capacity_1014  -25
    arc_1_17_8  connected_order_arc_1015  -14
    arc_1_17_8  in_degree_1156  1
    arc_1_17_8  out_degree_1187  1
    arc_1_17_8  original_T_including_depot_unload_1221  1.1957430085580884e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_8  arc_capacity_1014  1
    load_1_17_8  segment_load_conservation_1159  -1
    load_1_17_8  segment_prefix_lb_1160  1
    load_1_17_8  segment_prefix_ub_1161  1
    load_1_17_8  free_load_conservation_1192  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_9  arc_capacity_1016  -25
    arc_1_17_9  connected_order_arc_1017  -14
    arc_1_17_9  in_degree_1163  1
    arc_1_17_9  out_degree_1187  1
    arc_1_17_9  original_T_including_depot_unload_1221  7.6275540057842773e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_9  arc_capacity_1016  1
    load_1_17_9  segment_load_conservation_1166  -1
    load_1_17_9  segment_prefix_lb_1167  1
    load_1_17_9  segment_prefix_ub_1168  1
    load_1_17_9  free_load_conservation_1192  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_14  arc_capacity_1018  -25
    arc_1_17_14  connected_order_arc_1019  -14
    arc_1_17_14  in_degree_1170  1
    arc_1_17_14  out_degree_1187  1
    arc_1_17_14  original_T_including_depot_unload_1221  2.6602972191926557e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_14  arc_capacity_1018  1
    load_1_17_14  free_load_conservation_1174  -1
    load_1_17_14  free_load_conservation_1192  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_15  arc_capacity_1020  -25
    arc_1_17_15  connected_order_arc_1021  -14
    arc_1_17_15  in_degree_1176  1
    arc_1_17_15  out_degree_1187  1
    arc_1_17_15  original_T_including_depot_unload_1221  5.0315495126439691e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_15  arc_capacity_1020  1
    load_1_17_15  free_load_conservation_1180  -1
    load_1_17_15  free_load_conservation_1192  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_16  arc_capacity_1022  -25
    arc_1_17_16  connected_order_arc_1023  -14
    arc_1_17_16  in_degree_1182  1
    arc_1_17_16  out_degree_1187  1
    arc_1_17_16  original_T_including_depot_unload_1221  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_16  arc_capacity_1022  1
    load_1_17_16  free_load_conservation_1186  -1
    load_1_17_16  free_load_conservation_1192  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_18  arc_capacity_1024  -25
    arc_1_17_18  connected_order_arc_1025  -14
    arc_1_17_18  out_degree_1187  1
    arc_1_17_18  in_degree_1194  1
    arc_1_17_18  original_T_including_depot_unload_1221  1.3127274783157229e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_18  arc_capacity_1024  1
    load_1_17_18  free_load_conservation_1192  1
    load_1_17_18  free_load_conservation_1198  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_19  arc_capacity_1026  -25
    arc_1_17_19  connected_order_arc_1027  -14
    arc_1_17_19  out_degree_1187  1
    arc_1_17_19  in_degree_1200  1
    arc_1_17_19  original_T_including_depot_unload_1221  3.9766425523492148e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_19  arc_capacity_1026  1
    load_1_17_19  free_load_conservation_1192  1
    load_1_17_19  free_load_conservation_1204  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_20  arc_capacity_1028  -25
    arc_1_17_20  connected_order_arc_1029  -14
    arc_1_17_20  out_degree_1187  1
    arc_1_17_20  in_degree_1206  1
    arc_1_17_20  original_T_including_depot_unload_1221  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_20  arc_capacity_1028  1
    load_1_17_20  free_load_conservation_1192  1
    load_1_17_20  free_load_conservation_1210  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_21  arc_capacity_1030  -25
    arc_1_17_21  connected_order_arc_1031  -14
    arc_1_17_21  out_degree_1187  1
    arc_1_17_21  in_degree_1212  1
    arc_1_17_21  original_T_including_depot_unload_1221  2.3059951477332697e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_21  arc_capacity_1030  1
    load_1_17_21  free_load_conservation_1192  1
    load_1_17_21  free_load_conservation_1216  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_0  arc_capacity_1032  -25
    arc_1_18_0  depot_return_or_bypass_1133  1
    arc_1_18_0  out_degree_1193  1
    arc_1_18_0  original_T_including_depot_unload_1221  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_0  arc_capacity_1032  1
    load_1_18_0  free_load_conservation_1198  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_5  arc_capacity_1033  -25
    arc_1_18_5  connected_order_arc_1034  -14
    arc_1_18_5  in_degree_1135  1
    arc_1_18_5  out_degree_1193  1
    arc_1_18_5  original_T_including_depot_unload_1221  8.1417957710766450e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_5  arc_capacity_1033  1
    load_1_18_5  segment_load_conservation_1138  -1
    load_1_18_5  segment_prefix_lb_1139  1
    load_1_18_5  segment_prefix_ub_1140  1
    load_1_18_5  free_load_conservation_1198  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_6  arc_capacity_1035  -25
    arc_1_18_6  connected_order_arc_1036  -14
    arc_1_18_6  in_degree_1142  1
    arc_1_18_6  out_degree_1193  1
    arc_1_18_6  original_T_including_depot_unload_1221  1.0412376551742484e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_6  arc_capacity_1035  1
    load_1_18_6  segment_load_conservation_1145  -1
    load_1_18_6  segment_prefix_lb_1146  1
    load_1_18_6  segment_prefix_ub_1147  1
    load_1_18_6  free_load_conservation_1198  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_7  arc_capacity_1037  -25
    arc_1_18_7  connected_order_arc_1038  -14
    arc_1_18_7  in_degree_1149  1
    arc_1_18_7  out_degree_1193  1
    arc_1_18_7  original_T_including_depot_unload_1221  2.5572087458878266e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_7  arc_capacity_1037  1
    load_1_18_7  segment_load_conservation_1152  -1
    load_1_18_7  segment_prefix_lb_1153  1
    load_1_18_7  segment_prefix_ub_1154  1
    load_1_18_7  free_load_conservation_1198  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_8  arc_capacity_1039  -25
    arc_1_18_8  connected_order_arc_1040  -14
    arc_1_18_8  in_degree_1156  1
    arc_1_18_8  out_degree_1193  1
    arc_1_18_8  original_T_including_depot_unload_1221  1.6444540482789353e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_8  arc_capacity_1039  1
    load_1_18_8  segment_load_conservation_1159  -1
    load_1_18_8  segment_prefix_lb_1160  1
    load_1_18_8  segment_prefix_ub_1161  1
    load_1_18_8  free_load_conservation_1198  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_9  arc_capacity_1041  -25
    arc_1_18_9  connected_order_arc_1042  -14
    arc_1_18_9  in_degree_1163  1
    arc_1_18_9  out_degree_1193  1
    arc_1_18_9  original_T_including_depot_unload_1221  5.7102904773674652e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_9  arc_capacity_1041  1
    load_1_18_9  segment_load_conservation_1166  -1
    load_1_18_9  segment_prefix_lb_1167  1
    load_1_18_9  segment_prefix_ub_1168  1
    load_1_18_9  free_load_conservation_1198  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_14  arc_capacity_1043  -25
    arc_1_18_14  connected_order_arc_1044  -14
    arc_1_18_14  in_degree_1170  1
    arc_1_18_14  out_degree_1193  1
    arc_1_18_14  original_T_including_depot_unload_1221  1.0491196843462671e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_14  arc_capacity_1043  1
    load_1_18_14  free_load_conservation_1174  -1
    load_1_18_14  free_load_conservation_1198  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_15  arc_capacity_1045  -25
    arc_1_18_15  connected_order_arc_1046  -14
    arc_1_18_15  in_degree_1176  1
    arc_1_18_15  out_degree_1193  1
    arc_1_18_15  original_T_including_depot_unload_1221  8.3486971116736720e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_15  arc_capacity_1045  1
    load_1_18_15  free_load_conservation_1180  -1
    load_1_18_15  free_load_conservation_1198  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_16  arc_capacity_1047  -25
    arc_1_18_16  connected_order_arc_1048  -14
    arc_1_18_16  in_degree_1182  1
    arc_1_18_16  out_degree_1193  1
    arc_1_18_16  original_T_including_depot_unload_1221  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_16  arc_capacity_1047  1
    load_1_18_16  free_load_conservation_1186  -1
    load_1_18_16  free_load_conservation_1198  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_17  arc_capacity_1049  -25
    arc_1_18_17  connected_order_arc_1050  -14
    arc_1_18_17  in_degree_1188  1
    arc_1_18_17  out_degree_1193  1
    arc_1_18_17  original_T_including_depot_unload_1221  1.3127274783157229e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_17  arc_capacity_1049  1
    load_1_18_17  free_load_conservation_1192  -1
    load_1_18_17  free_load_conservation_1198  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_19  arc_capacity_1051  -25
    arc_1_18_19  connected_order_arc_1052  -14
    arc_1_18_19  out_degree_1193  1
    arc_1_18_19  in_degree_1200  1
    arc_1_18_19  original_T_including_depot_unload_1221  1.1341050580477483e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_19  arc_capacity_1051  1
    load_1_18_19  free_load_conservation_1198  1
    load_1_18_19  free_load_conservation_1204  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_20  arc_capacity_1053  -25
    arc_1_18_20  connected_order_arc_1054  -14
    arc_1_18_20  out_degree_1193  1
    arc_1_18_20  in_degree_1206  1
    arc_1_18_20  original_T_including_depot_unload_1221  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_20  arc_capacity_1053  1
    load_1_18_20  free_load_conservation_1198  1
    load_1_18_20  free_load_conservation_1210  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_21  arc_capacity_1055  -25
    arc_1_18_21  connected_order_arc_1056  -14
    arc_1_18_21  out_degree_1193  1
    arc_1_18_21  in_degree_1212  1
    arc_1_18_21  original_T_including_depot_unload_1221  1.2968499029957554e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_21  arc_capacity_1055  1
    load_1_18_21  free_load_conservation_1198  1
    load_1_18_21  free_load_conservation_1216  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_0  arc_capacity_1057  -25
    arc_1_19_0  depot_return_or_bypass_1133  1
    arc_1_19_0  out_degree_1199  1
    arc_1_19_0  original_T_including_depot_unload_1221  5.9431738885389052e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_0  arc_capacity_1057  1
    load_1_19_0  free_load_conservation_1204  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_5  arc_capacity_1058  -25
    arc_1_19_5  connected_order_arc_1059  -14
    arc_1_19_5  in_degree_1135  1
    arc_1_19_5  out_degree_1199  1
    arc_1_19_5  original_T_including_depot_unload_1221  1.4171530684324468e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_5  arc_capacity_1058  1
    load_1_19_5  segment_load_conservation_1138  -1
    load_1_19_5  segment_prefix_lb_1139  1
    load_1_19_5  segment_prefix_ub_1140  1
    load_1_19_5  free_load_conservation_1204  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_6  arc_capacity_1060  -25
    arc_1_19_6  connected_order_arc_1061  -14
    arc_1_19_6  in_degree_1142  1
    arc_1_19_6  out_degree_1199  1
    arc_1_19_6  original_T_including_depot_unload_1221  1.3070841601346692e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_6  arc_capacity_1060  1
    load_1_19_6  segment_load_conservation_1145  -1
    load_1_19_6  segment_prefix_lb_1146  1
    load_1_19_6  segment_prefix_ub_1147  1
    load_1_19_6  free_load_conservation_1204  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_7  arc_capacity_1062  -25
    arc_1_19_7  connected_order_arc_1063  -14
    arc_1_19_7  in_degree_1149  1
    arc_1_19_7  out_degree_1199  1
    arc_1_19_7  original_T_including_depot_unload_1221  1.3593311700505531e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_7  arc_capacity_1062  1
    load_1_19_7  segment_load_conservation_1152  -1
    load_1_19_7  segment_prefix_lb_1153  1
    load_1_19_7  segment_prefix_ub_1154  1
    load_1_19_7  free_load_conservation_1204  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_8  arc_capacity_1064  -25
    arc_1_19_8  connected_order_arc_1065  -14
    arc_1_19_8  in_degree_1156  1
    arc_1_19_8  out_degree_1199  1
    arc_1_19_8  original_T_including_depot_unload_1221  987.973588780524
    MARKER    'MARKER'                 'INTEND'
    load_1_19_8  arc_capacity_1064  1
    load_1_19_8  segment_load_conservation_1159  -1
    load_1_19_8  segment_prefix_lb_1160  1
    load_1_19_8  segment_prefix_ub_1161  1
    load_1_19_8  free_load_conservation_1204  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_9  arc_capacity_1066  -25
    arc_1_19_9  connected_order_arc_1067  -14
    arc_1_19_9  in_degree_1163  1
    arc_1_19_9  out_degree_1199  1
    arc_1_19_9  original_T_including_depot_unload_1221  6.8881953094806647e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_9  arc_capacity_1066  1
    load_1_19_9  segment_load_conservation_1166  -1
    load_1_19_9  segment_prefix_lb_1167  1
    load_1_19_9  segment_prefix_ub_1168  1
    load_1_19_9  free_load_conservation_1204  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_14  arc_capacity_1068  -25
    arc_1_19_14  connected_order_arc_1069  -14
    arc_1_19_14  in_degree_1170  1
    arc_1_19_14  out_degree_1199  1
    arc_1_19_14  original_T_including_depot_unload_1221  2.9706418113632907e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_14  arc_capacity_1068  1
    load_1_19_14  free_load_conservation_1174  -1
    load_1_19_14  free_load_conservation_1204  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_15  arc_capacity_1070  -25
    arc_1_19_15  connected_order_arc_1071  -14
    arc_1_19_15  in_degree_1176  1
    arc_1_19_15  out_degree_1199  1
    arc_1_19_15  original_T_including_depot_unload_1221  3.2938591738444967e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_15  arc_capacity_1070  1
    load_1_19_15  free_load_conservation_1180  -1
    load_1_19_15  free_load_conservation_1204  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_16  arc_capacity_1072  -25
    arc_1_19_16  connected_order_arc_1073  -14
    arc_1_19_16  in_degree_1182  1
    arc_1_19_16  out_degree_1199  1
    arc_1_19_16  original_T_including_depot_unload_1221  1.3727638439182763e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_16  arc_capacity_1072  1
    load_1_19_16  free_load_conservation_1186  -1
    load_1_19_16  free_load_conservation_1204  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_17  arc_capacity_1074  -25
    arc_1_19_17  connected_order_arc_1075  -14
    arc_1_19_17  in_degree_1188  1
    arc_1_19_17  out_degree_1199  1
    arc_1_19_17  original_T_including_depot_unload_1221  3.9766425523492148e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_17  arc_capacity_1074  1
    load_1_19_17  free_load_conservation_1192  -1
    load_1_19_17  free_load_conservation_1204  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_18  arc_capacity_1076  -25
    arc_1_19_18  connected_order_arc_1077  -14
    arc_1_19_18  in_degree_1194  1
    arc_1_19_18  out_degree_1199  1
    arc_1_19_18  original_T_including_depot_unload_1221  1.1341050580477483e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_18  arc_capacity_1076  1
    load_1_19_18  free_load_conservation_1198  -1
    load_1_19_18  free_load_conservation_1204  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_20  arc_capacity_1078  -25
    arc_1_19_20  connected_order_arc_1079  -14
    arc_1_19_20  out_degree_1199  1
    arc_1_19_20  in_degree_1206  1
    arc_1_19_20  original_T_including_depot_unload_1221  9.8652191996938075e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_20  arc_capacity_1078  1
    load_1_19_20  free_load_conservation_1204  1
    load_1_19_20  free_load_conservation_1210  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_21  arc_capacity_1080  -25
    arc_1_19_21  connected_order_arc_1081  -14
    arc_1_19_21  out_degree_1199  1
    arc_1_19_21  in_degree_1212  1
    arc_1_19_21  original_T_including_depot_unload_1221  2.1481294511470344e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_21  arc_capacity_1080  1
    load_1_19_21  free_load_conservation_1204  1
    load_1_19_21  free_load_conservation_1216  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_0  arc_capacity_1082  -25
    arc_1_20_0  depot_return_or_bypass_1133  1
    arc_1_20_0  out_degree_1205  1
    arc_1_20_0  original_T_including_depot_unload_1221  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_0  arc_capacity_1082  1
    load_1_20_0  free_load_conservation_1210  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_5  arc_capacity_1083  -25
    arc_1_20_5  connected_order_arc_1084  -14
    arc_1_20_5  in_degree_1135  1
    arc_1_20_5  out_degree_1205  1
    arc_1_20_5  original_T_including_depot_unload_1221  1.8442669473423912e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_5  arc_capacity_1083  1
    load_1_20_5  segment_load_conservation_1138  -1
    load_1_20_5  segment_prefix_lb_1139  1
    load_1_20_5  segment_prefix_ub_1140  1
    load_1_20_5  free_load_conservation_1210  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_6  arc_capacity_1085  -25
    arc_1_20_6  connected_order_arc_1086  -14
    arc_1_20_6  in_degree_1142  1
    arc_1_20_6  out_degree_1205  1
    arc_1_20_6  original_T_including_depot_unload_1221  1.5502221880497036e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_6  arc_capacity_1085  1
    load_1_20_6  segment_load_conservation_1145  -1
    load_1_20_6  segment_prefix_lb_1146  1
    load_1_20_6  segment_prefix_ub_1147  1
    load_1_20_6  free_load_conservation_1210  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_7  arc_capacity_1087  -25
    arc_1_20_7  connected_order_arc_1088  -14
    arc_1_20_7  in_degree_1149  1
    arc_1_20_7  out_degree_1205  1
    arc_1_20_7  original_T_including_depot_unload_1221  2115.53677476792
    MARKER    'MARKER'                 'INTEND'
    load_1_20_7  arc_capacity_1087  1
    load_1_20_7  segment_load_conservation_1152  -1
    load_1_20_7  segment_prefix_lb_1153  1
    load_1_20_7  segment_prefix_ub_1154  1
    load_1_20_7  free_load_conservation_1210  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_8  arc_capacity_1089  -25
    arc_1_20_8  connected_order_arc_1090  -14
    arc_1_20_8  in_degree_1156  1
    arc_1_20_8  out_degree_1205  1
    arc_1_20_8  original_T_including_depot_unload_1221  1.8418804985785646e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_8  arc_capacity_1089  1
    load_1_20_8  segment_load_conservation_1159  -1
    load_1_20_8  segment_prefix_lb_1160  1
    load_1_20_8  segment_prefix_ub_1161  1
    load_1_20_8  free_load_conservation_1210  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_9  arc_capacity_1091  -25
    arc_1_20_9  connected_order_arc_1092  -14
    arc_1_20_9  in_degree_1163  1
    arc_1_20_9  out_degree_1205  1
    arc_1_20_9  original_T_including_depot_unload_1221  1.3857128117205509e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_9  arc_capacity_1091  1
    load_1_20_9  segment_load_conservation_1166  -1
    load_1_20_9  segment_prefix_lb_1167  1
    load_1_20_9  segment_prefix_ub_1168  1
    load_1_20_9  free_load_conservation_1210  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_14  arc_capacity_1093  -25
    arc_1_20_14  connected_order_arc_1094  -14
    arc_1_20_14  in_degree_1170  1
    arc_1_20_14  out_degree_1205  1
    arc_1_20_14  original_T_including_depot_unload_1221  9.1576870176747968e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_14  arc_capacity_1093  1
    load_1_20_14  free_load_conservation_1174  -1
    load_1_20_14  free_load_conservation_1210  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_15  arc_capacity_1095  -25
    arc_1_20_15  connected_order_arc_1096  -14
    arc_1_20_15  in_degree_1176  1
    arc_1_20_15  out_degree_1205  1
    arc_1_20_15  original_T_including_depot_unload_1221  1.1544376314422677e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_15  arc_capacity_1095  1
    load_1_20_15  free_load_conservation_1180  -1
    load_1_20_15  free_load_conservation_1210  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_16  arc_capacity_1097  -25
    arc_1_20_16  connected_order_arc_1098  -14
    arc_1_20_16  in_degree_1182  1
    arc_1_20_16  out_degree_1205  1
    arc_1_20_16  original_T_including_depot_unload_1221  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_16  arc_capacity_1097  1
    load_1_20_16  free_load_conservation_1186  -1
    load_1_20_16  free_load_conservation_1210  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_17  arc_capacity_1099  -25
    arc_1_20_17  connected_order_arc_1100  -14
    arc_1_20_17  in_degree_1188  1
    arc_1_20_17  out_degree_1205  1
    arc_1_20_17  original_T_including_depot_unload_1221  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_17  arc_capacity_1099  1
    load_1_20_17  free_load_conservation_1192  -1
    load_1_20_17  free_load_conservation_1210  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_18  arc_capacity_1101  -25
    arc_1_20_18  connected_order_arc_1102  -14
    arc_1_20_18  in_degree_1194  1
    arc_1_20_18  out_degree_1205  1
    arc_1_20_18  original_T_including_depot_unload_1221  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_18  arc_capacity_1101  1
    load_1_20_18  free_load_conservation_1198  -1
    load_1_20_18  free_load_conservation_1210  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_19  arc_capacity_1103  -25
    arc_1_20_19  connected_order_arc_1104  -14
    arc_1_20_19  in_degree_1200  1
    arc_1_20_19  out_degree_1205  1
    arc_1_20_19  original_T_including_depot_unload_1221  9.8652191996938075e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_19  arc_capacity_1103  1
    load_1_20_19  free_load_conservation_1204  -1
    load_1_20_19  free_load_conservation_1210  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_21  arc_capacity_1105  -25
    arc_1_20_21  connected_order_arc_1106  -14
    arc_1_20_21  out_degree_1205  1
    arc_1_20_21  in_degree_1212  1
    arc_1_20_21  original_T_including_depot_unload_1221  7.7190219995954919e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_21  arc_capacity_1105  1
    load_1_20_21  free_load_conservation_1210  1
    load_1_20_21  free_load_conservation_1216  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_0  arc_capacity_1107  -25
    arc_1_21_0  depot_return_or_bypass_1133  1
    arc_1_21_0  out_degree_1211  1
    arc_1_21_0  original_T_including_depot_unload_1221  7.2571167924583824e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_0  arc_capacity_1107  1
    load_1_21_0  free_load_conservation_1216  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_5  arc_capacity_1108  -25
    arc_1_21_5  connected_order_arc_1109  -14
    arc_1_21_5  in_degree_1135  1
    arc_1_21_5  out_degree_1211  1
    arc_1_21_5  original_T_including_depot_unload_1221  1.4725441282427828e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_5  arc_capacity_1108  1
    load_1_21_5  segment_load_conservation_1138  -1
    load_1_21_5  segment_prefix_lb_1139  1
    load_1_21_5  segment_prefix_ub_1140  1
    load_1_21_5  free_load_conservation_1216  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_6  arc_capacity_1110  -25
    arc_1_21_6  connected_order_arc_1111  -14
    arc_1_21_6  in_degree_1142  1
    arc_1_21_6  out_degree_1211  1
    arc_1_21_6  original_T_including_depot_unload_1221  1.3095620674514091e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_6  arc_capacity_1110  1
    load_1_21_6  segment_load_conservation_1145  -1
    load_1_21_6  segment_prefix_lb_1146  1
    load_1_21_6  segment_prefix_ub_1147  1
    load_1_21_6  free_load_conservation_1216  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_7  arc_capacity_1112  -25
    arc_1_21_7  connected_order_arc_1113  -14
    arc_1_21_7  in_degree_1149  1
    arc_1_21_7  out_degree_1211  1
    arc_1_21_7  original_T_including_depot_unload_1221  1.5070416710648517e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_7  arc_capacity_1112  1
    load_1_21_7  segment_load_conservation_1152  -1
    load_1_21_7  segment_prefix_lb_1153  1
    load_1_21_7  segment_prefix_ub_1154  1
    load_1_21_7  free_load_conservation_1216  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_8  arc_capacity_1114  -25
    arc_1_21_8  connected_order_arc_1115  -14
    arc_1_21_8  in_degree_1156  1
    arc_1_21_8  out_degree_1211  1
    arc_1_21_8  original_T_including_depot_unload_1221  1.1605914703789122e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_8  arc_capacity_1114  1
    load_1_21_8  segment_load_conservation_1159  -1
    load_1_21_8  segment_prefix_lb_1160  1
    load_1_21_8  segment_prefix_ub_1161  1
    load_1_21_8  free_load_conservation_1216  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_9  arc_capacity_1116  -25
    arc_1_21_9  connected_order_arc_1117  -14
    arc_1_21_9  in_degree_1163  1
    arc_1_21_9  out_degree_1211  1
    arc_1_21_9  original_T_including_depot_unload_1221  7.9613989083692911e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_9  arc_capacity_1116  1
    load_1_21_9  segment_load_conservation_1166  -1
    load_1_21_9  segment_prefix_lb_1167  1
    load_1_21_9  segment_prefix_ub_1168  1
    load_1_21_9  free_load_conservation_1216  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_14  arc_capacity_1118  -25
    arc_1_21_14  connected_order_arc_1119  -14
    arc_1_21_14  in_degree_1170  1
    arc_1_21_14  out_degree_1211  1
    arc_1_21_14  original_T_including_depot_unload_1221  3.0055050459786975e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_14  arc_capacity_1118  1
    load_1_21_14  free_load_conservation_1174  -1
    load_1_21_14  free_load_conservation_1216  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_15  arc_capacity_1120  -25
    arc_1_21_15  connected_order_arc_1121  -14
    arc_1_21_15  in_degree_1176  1
    arc_1_21_15  out_degree_1211  1
    arc_1_21_15  original_T_including_depot_unload_1221  4.6276703023336785e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_15  arc_capacity_1120  1
    load_1_21_15  free_load_conservation_1180  -1
    load_1_21_15  free_load_conservation_1216  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_16  arc_capacity_1122  -25
    arc_1_21_16  connected_order_arc_1123  -14
    arc_1_21_16  in_degree_1182  1
    arc_1_21_16  out_degree_1211  1
    arc_1_21_16  original_T_including_depot_unload_1221  1.3163662834239574e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_16  arc_capacity_1122  1
    load_1_21_16  free_load_conservation_1186  -1
    load_1_21_16  free_load_conservation_1216  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_17  arc_capacity_1124  -25
    arc_1_21_17  connected_order_arc_1125  -14
    arc_1_21_17  in_degree_1188  1
    arc_1_21_17  out_degree_1211  1
    arc_1_21_17  original_T_including_depot_unload_1221  2.3059951477332697e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_17  arc_capacity_1124  1
    load_1_21_17  free_load_conservation_1192  -1
    load_1_21_17  free_load_conservation_1216  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_18  arc_capacity_1126  -25
    arc_1_21_18  connected_order_arc_1127  -14
    arc_1_21_18  in_degree_1194  1
    arc_1_21_18  out_degree_1211  1
    arc_1_21_18  original_T_including_depot_unload_1221  1.2968499029957554e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_18  arc_capacity_1126  1
    load_1_21_18  free_load_conservation_1198  -1
    load_1_21_18  free_load_conservation_1216  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_19  arc_capacity_1128  -25
    arc_1_21_19  connected_order_arc_1129  -14
    arc_1_21_19  in_degree_1200  1
    arc_1_21_19  out_degree_1211  1
    arc_1_21_19  original_T_including_depot_unload_1221  2.1481294511470344e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_19  arc_capacity_1128  1
    load_1_21_19  free_load_conservation_1204  -1
    load_1_21_19  free_load_conservation_1216  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_20  arc_capacity_1130  -25
    arc_1_21_20  connected_order_arc_1131  -14
    arc_1_21_20  in_degree_1206  1
    arc_1_21_20  out_degree_1211  1
    arc_1_21_20  original_T_including_depot_unload_1221  7.7190219995954919e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_20  arc_capacity_1130  1
    load_1_21_20  free_load_conservation_1210  -1
    load_1_21_20  free_load_conservation_1216  1
    visit_2_10  out_degree_1513  -1
    visit_2_10  in_degree_1514  -1
    visit_2_10  order_active_lb_1515  -1
    visit_2_10  order_active_ub_1516  -12
    order_2_10  connected_order_arc_1237  -1
    order_2_10  connected_order_arc_1239  -1
    order_2_10  connected_order_arc_1241  -1
    order_2_10  connected_order_arc_1243  -1
    order_2_10  connected_order_arc_1245  -1
    order_2_10  connected_order_arc_1247  -1
    order_2_10  connected_order_arc_1249  -1
    order_2_10  connected_order_arc_1251  -1
    order_2_10  connected_order_arc_1253  -1
    order_2_10  connected_order_arc_1255  -1
    order_2_10  connected_order_arc_1257  -1
    order_2_10  connected_order_arc_1260  1
    order_2_10  connected_order_arc_1283  1
    order_2_10  connected_order_arc_1306  1
    order_2_10  connected_order_arc_1329  1
    order_2_10  connected_order_arc_1352  1
    order_2_10  connected_order_arc_1375  1
    order_2_10  connected_order_arc_1398  1
    order_2_10  connected_order_arc_1421  1
    order_2_10  connected_order_arc_1444  1
    order_2_10  connected_order_arc_1467  1
    order_2_10  connected_order_arc_1490  1
    order_2_10  order_active_lb_1515  1
    order_2_10  order_active_ub_1516  1
    order_2_10  fixed_segment_relative_order_1589  -1
    visit_2_11  out_degree_1520  -1
    visit_2_11  in_degree_1521  -1
    visit_2_11  order_active_lb_1522  -1
    visit_2_11  order_active_ub_1523  -12
    order_2_11  connected_order_arc_1237  1
    order_2_11  connected_order_arc_1260  -1
    order_2_11  connected_order_arc_1262  -1
    order_2_11  connected_order_arc_1264  -1
    order_2_11  connected_order_arc_1266  -1
    order_2_11  connected_order_arc_1268  -1
    order_2_11  connected_order_arc_1270  -1
    order_2_11  connected_order_arc_1272  -1
    order_2_11  connected_order_arc_1274  -1
    order_2_11  connected_order_arc_1276  -1
    order_2_11  connected_order_arc_1278  -1
    order_2_11  connected_order_arc_1280  -1
    order_2_11  connected_order_arc_1285  1
    order_2_11  connected_order_arc_1308  1
    order_2_11  connected_order_arc_1331  1
    order_2_11  connected_order_arc_1354  1
    order_2_11  connected_order_arc_1377  1
    order_2_11  connected_order_arc_1400  1
    order_2_11  connected_order_arc_1423  1
    order_2_11  connected_order_arc_1446  1
    order_2_11  connected_order_arc_1469  1
    order_2_11  connected_order_arc_1492  1
    order_2_11  order_active_lb_1522  1
    order_2_11  order_active_ub_1523  1
    order_2_11  fixed_segment_relative_order_1589  1
    order_2_11  fixed_segment_relative_order_1590  -1
    visit_2_12  out_degree_1527  -1
    visit_2_12  in_degree_1528  -1
    visit_2_12  order_active_lb_1529  -1
    visit_2_12  order_active_ub_1530  -12
    order_2_12  connected_order_arc_1239  1
    order_2_12  connected_order_arc_1262  1
    order_2_12  connected_order_arc_1283  -1
    order_2_12  connected_order_arc_1285  -1
    order_2_12  connected_order_arc_1287  -1
    order_2_12  connected_order_arc_1289  -1
    order_2_12  connected_order_arc_1291  -1
    order_2_12  connected_order_arc_1293  -1
    order_2_12  connected_order_arc_1295  -1
    order_2_12  connected_order_arc_1297  -1
    order_2_12  connected_order_arc_1299  -1
    order_2_12  connected_order_arc_1301  -1
    order_2_12  connected_order_arc_1303  -1
    order_2_12  connected_order_arc_1310  1
    order_2_12  connected_order_arc_1333  1
    order_2_12  connected_order_arc_1356  1
    order_2_12  connected_order_arc_1379  1
    order_2_12  connected_order_arc_1402  1
    order_2_12  connected_order_arc_1425  1
    order_2_12  connected_order_arc_1448  1
    order_2_12  connected_order_arc_1471  1
    order_2_12  connected_order_arc_1494  1
    order_2_12  order_active_lb_1529  1
    order_2_12  order_active_ub_1530  1
    order_2_12  fixed_segment_relative_order_1590  1
    order_2_12  fixed_segment_relative_order_1591  -1
    visit_2_13  out_degree_1534  -1
    visit_2_13  in_degree_1535  -1
    visit_2_13  order_active_lb_1536  -1
    visit_2_13  order_active_ub_1537  -12
    order_2_13  connected_order_arc_1241  1
    order_2_13  connected_order_arc_1264  1
    order_2_13  connected_order_arc_1287  1
    order_2_13  connected_order_arc_1306  -1
    order_2_13  connected_order_arc_1308  -1
    order_2_13  connected_order_arc_1310  -1
    order_2_13  connected_order_arc_1312  -1
    order_2_13  connected_order_arc_1314  -1
    order_2_13  connected_order_arc_1316  -1
    order_2_13  connected_order_arc_1318  -1
    order_2_13  connected_order_arc_1320  -1
    order_2_13  connected_order_arc_1322  -1
    order_2_13  connected_order_arc_1324  -1
    order_2_13  connected_order_arc_1326  -1
    order_2_13  connected_order_arc_1335  1
    order_2_13  connected_order_arc_1358  1
    order_2_13  connected_order_arc_1381  1
    order_2_13  connected_order_arc_1404  1
    order_2_13  connected_order_arc_1427  1
    order_2_13  connected_order_arc_1450  1
    order_2_13  connected_order_arc_1473  1
    order_2_13  connected_order_arc_1496  1
    order_2_13  order_active_lb_1536  1
    order_2_13  order_active_ub_1537  1
    order_2_13  fixed_segment_relative_order_1591  1
    visit_2_14  out_degree_1541  -1
    visit_2_14  in_degree_1542  -1
    visit_2_14  order_active_lb_1543  -1
    visit_2_14  order_active_ub_1544  -12
    visit_2_14  service_visit_def_1545  -1
    order_2_14  connected_order_arc_1243  1
    order_2_14  connected_order_arc_1266  1
    order_2_14  connected_order_arc_1289  1
    order_2_14  connected_order_arc_1312  1
    order_2_14  connected_order_arc_1329  -1
    order_2_14  connected_order_arc_1331  -1
    order_2_14  connected_order_arc_1333  -1
    order_2_14  connected_order_arc_1335  -1
    order_2_14  connected_order_arc_1337  -1
    order_2_14  connected_order_arc_1339  -1
    order_2_14  connected_order_arc_1341  -1
    order_2_14  connected_order_arc_1343  -1
    order_2_14  connected_order_arc_1345  -1
    order_2_14  connected_order_arc_1347  -1
    order_2_14  connected_order_arc_1349  -1
    order_2_14  connected_order_arc_1360  1
    order_2_14  connected_order_arc_1383  1
    order_2_14  connected_order_arc_1406  1
    order_2_14  connected_order_arc_1429  1
    order_2_14  connected_order_arc_1452  1
    order_2_14  connected_order_arc_1475  1
    order_2_14  connected_order_arc_1498  1
    order_2_14  order_active_lb_1543  1
    order_2_14  order_active_ub_1544  1
    visit_2_15  out_degree_1547  -1
    visit_2_15  in_degree_1548  -1
    visit_2_15  order_active_lb_1549  -1
    visit_2_15  order_active_ub_1550  -12
    visit_2_15  service_visit_def_1551  -1
    order_2_15  connected_order_arc_1245  1
    order_2_15  connected_order_arc_1268  1
    order_2_15  connected_order_arc_1291  1
    order_2_15  connected_order_arc_1314  1
    order_2_15  connected_order_arc_1337  1
    order_2_15  connected_order_arc_1352  -1
    order_2_15  connected_order_arc_1354  -1
    order_2_15  connected_order_arc_1356  -1
    order_2_15  connected_order_arc_1358  -1
    order_2_15  connected_order_arc_1360  -1
    order_2_15  connected_order_arc_1362  -1
    order_2_15  connected_order_arc_1364  -1
    order_2_15  connected_order_arc_1366  -1
    order_2_15  connected_order_arc_1368  -1
    order_2_15  connected_order_arc_1370  -1
    order_2_15  connected_order_arc_1372  -1
    order_2_15  connected_order_arc_1385  1
    order_2_15  connected_order_arc_1408  1
    order_2_15  connected_order_arc_1431  1
    order_2_15  connected_order_arc_1454  1
    order_2_15  connected_order_arc_1477  1
    order_2_15  connected_order_arc_1500  1
    order_2_15  order_active_lb_1549  1
    order_2_15  order_active_ub_1550  1
    visit_2_16  out_degree_1553  -1
    visit_2_16  in_degree_1554  -1
    visit_2_16  order_active_lb_1555  -1
    visit_2_16  order_active_ub_1556  -12
    visit_2_16  service_visit_def_1557  -1
    order_2_16  connected_order_arc_1247  1
    order_2_16  connected_order_arc_1270  1
    order_2_16  connected_order_arc_1293  1
    order_2_16  connected_order_arc_1316  1
    order_2_16  connected_order_arc_1339  1
    order_2_16  connected_order_arc_1362  1
    order_2_16  connected_order_arc_1375  -1
    order_2_16  connected_order_arc_1377  -1
    order_2_16  connected_order_arc_1379  -1
    order_2_16  connected_order_arc_1381  -1
    order_2_16  connected_order_arc_1383  -1
    order_2_16  connected_order_arc_1385  -1
    order_2_16  connected_order_arc_1387  -1
    order_2_16  connected_order_arc_1389  -1
    order_2_16  connected_order_arc_1391  -1
    order_2_16  connected_order_arc_1393  -1
    order_2_16  connected_order_arc_1395  -1
    order_2_16  connected_order_arc_1410  1
    order_2_16  connected_order_arc_1433  1
    order_2_16  connected_order_arc_1456  1
    order_2_16  connected_order_arc_1479  1
    order_2_16  connected_order_arc_1502  1
    order_2_16  order_active_lb_1555  1
    order_2_16  order_active_ub_1556  1
    visit_2_17  out_degree_1559  -1
    visit_2_17  in_degree_1560  -1
    visit_2_17  order_active_lb_1561  -1
    visit_2_17  order_active_ub_1562  -12
    visit_2_17  service_visit_def_1563  -1
    order_2_17  connected_order_arc_1249  1
    order_2_17  connected_order_arc_1272  1
    order_2_17  connected_order_arc_1295  1
    order_2_17  connected_order_arc_1318  1
    order_2_17  connected_order_arc_1341  1
    order_2_17  connected_order_arc_1364  1
    order_2_17  connected_order_arc_1387  1
    order_2_17  connected_order_arc_1398  -1
    order_2_17  connected_order_arc_1400  -1
    order_2_17  connected_order_arc_1402  -1
    order_2_17  connected_order_arc_1404  -1
    order_2_17  connected_order_arc_1406  -1
    order_2_17  connected_order_arc_1408  -1
    order_2_17  connected_order_arc_1410  -1
    order_2_17  connected_order_arc_1412  -1
    order_2_17  connected_order_arc_1414  -1
    order_2_17  connected_order_arc_1416  -1
    order_2_17  connected_order_arc_1418  -1
    order_2_17  connected_order_arc_1435  1
    order_2_17  connected_order_arc_1458  1
    order_2_17  connected_order_arc_1481  1
    order_2_17  connected_order_arc_1504  1
    order_2_17  order_active_lb_1561  1
    order_2_17  order_active_ub_1562  1
    visit_2_18  out_degree_1565  -1
    visit_2_18  in_degree_1566  -1
    visit_2_18  order_active_lb_1567  -1
    visit_2_18  order_active_ub_1568  -12
    visit_2_18  service_visit_def_1569  -1
    order_2_18  connected_order_arc_1251  1
    order_2_18  connected_order_arc_1274  1
    order_2_18  connected_order_arc_1297  1
    order_2_18  connected_order_arc_1320  1
    order_2_18  connected_order_arc_1343  1
    order_2_18  connected_order_arc_1366  1
    order_2_18  connected_order_arc_1389  1
    order_2_18  connected_order_arc_1412  1
    order_2_18  connected_order_arc_1421  -1
    order_2_18  connected_order_arc_1423  -1
    order_2_18  connected_order_arc_1425  -1
    order_2_18  connected_order_arc_1427  -1
    order_2_18  connected_order_arc_1429  -1
    order_2_18  connected_order_arc_1431  -1
    order_2_18  connected_order_arc_1433  -1
    order_2_18  connected_order_arc_1435  -1
    order_2_18  connected_order_arc_1437  -1
    order_2_18  connected_order_arc_1439  -1
    order_2_18  connected_order_arc_1441  -1
    order_2_18  connected_order_arc_1460  1
    order_2_18  connected_order_arc_1483  1
    order_2_18  connected_order_arc_1506  1
    order_2_18  order_active_lb_1567  1
    order_2_18  order_active_ub_1568  1
    visit_2_19  out_degree_1571  -1
    visit_2_19  in_degree_1572  -1
    visit_2_19  order_active_lb_1573  -1
    visit_2_19  order_active_ub_1574  -12
    visit_2_19  service_visit_def_1575  -1
    order_2_19  connected_order_arc_1253  1
    order_2_19  connected_order_arc_1276  1
    order_2_19  connected_order_arc_1299  1
    order_2_19  connected_order_arc_1322  1
    order_2_19  connected_order_arc_1345  1
    order_2_19  connected_order_arc_1368  1
    order_2_19  connected_order_arc_1391  1
    order_2_19  connected_order_arc_1414  1
    order_2_19  connected_order_arc_1437  1
    order_2_19  connected_order_arc_1444  -1
    order_2_19  connected_order_arc_1446  -1
    order_2_19  connected_order_arc_1448  -1
    order_2_19  connected_order_arc_1450  -1
    order_2_19  connected_order_arc_1452  -1
    order_2_19  connected_order_arc_1454  -1
    order_2_19  connected_order_arc_1456  -1
    order_2_19  connected_order_arc_1458  -1
    order_2_19  connected_order_arc_1460  -1
    order_2_19  connected_order_arc_1462  -1
    order_2_19  connected_order_arc_1464  -1
    order_2_19  connected_order_arc_1485  1
    order_2_19  connected_order_arc_1508  1
    order_2_19  order_active_lb_1573  1
    order_2_19  order_active_ub_1574  1
    visit_2_20  out_degree_1577  -1
    visit_2_20  in_degree_1578  -1
    visit_2_20  order_active_lb_1579  -1
    visit_2_20  order_active_ub_1580  -12
    visit_2_20  service_visit_def_1581  -1
    order_2_20  connected_order_arc_1255  1
    order_2_20  connected_order_arc_1278  1
    order_2_20  connected_order_arc_1301  1
    order_2_20  connected_order_arc_1324  1
    order_2_20  connected_order_arc_1347  1
    order_2_20  connected_order_arc_1370  1
    order_2_20  connected_order_arc_1393  1
    order_2_20  connected_order_arc_1416  1
    order_2_20  connected_order_arc_1439  1
    order_2_20  connected_order_arc_1462  1
    order_2_20  connected_order_arc_1467  -1
    order_2_20  connected_order_arc_1469  -1
    order_2_20  connected_order_arc_1471  -1
    order_2_20  connected_order_arc_1473  -1
    order_2_20  connected_order_arc_1475  -1
    order_2_20  connected_order_arc_1477  -1
    order_2_20  connected_order_arc_1479  -1
    order_2_20  connected_order_arc_1481  -1
    order_2_20  connected_order_arc_1483  -1
    order_2_20  connected_order_arc_1485  -1
    order_2_20  connected_order_arc_1487  -1
    order_2_20  connected_order_arc_1510  1
    order_2_20  order_active_lb_1579  1
    order_2_20  order_active_ub_1580  1
    visit_2_21  out_degree_1583  -1
    visit_2_21  in_degree_1584  -1
    visit_2_21  order_active_lb_1585  -1
    visit_2_21  order_active_ub_1586  -12
    visit_2_21  service_visit_def_1587  -1
    order_2_21  connected_order_arc_1257  1
    order_2_21  connected_order_arc_1280  1
    order_2_21  connected_order_arc_1303  1
    order_2_21  connected_order_arc_1326  1
    order_2_21  connected_order_arc_1349  1
    order_2_21  connected_order_arc_1372  1
    order_2_21  connected_order_arc_1395  1
    order_2_21  connected_order_arc_1418  1
    order_2_21  connected_order_arc_1441  1
    order_2_21  connected_order_arc_1464  1
    order_2_21  connected_order_arc_1487  1
    order_2_21  connected_order_arc_1490  -1
    order_2_21  connected_order_arc_1492  -1
    order_2_21  connected_order_arc_1494  -1
    order_2_21  connected_order_arc_1496  -1
    order_2_21  connected_order_arc_1498  -1
    order_2_21  connected_order_arc_1500  -1
    order_2_21  connected_order_arc_1502  -1
    order_2_21  connected_order_arc_1504  -1
    order_2_21  connected_order_arc_1506  -1
    order_2_21  connected_order_arc_1508  -1
    order_2_21  connected_order_arc_1510  -1
    order_2_21  order_active_lb_1585  1
    order_2_21  order_active_ub_1586  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_0  arc_capacity_1222  -30
    arc_2_0_0  depot_departure_or_bypass_1511  1
    arc_2_0_0  depot_return_or_bypass_1512  1
    MARKER    'MARKER'                 'INTEND'
    load_2_0_0  arc_capacity_1222  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_10  arc_capacity_1223  -30
    arc_2_0_10  depot_departure_or_bypass_1511  1
    arc_2_0_10  in_degree_1514  1
    arc_2_0_10  original_T_including_depot_unload_1592  1.4567038050199781e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_10  arc_capacity_1223  1
    load_2_0_10  segment_load_conservation_1517  -1
    load_2_0_10  segment_prefix_lb_1518  1
    load_2_0_10  segment_prefix_ub_1519  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_11  arc_capacity_1224  -30
    arc_2_0_11  depot_departure_or_bypass_1511  1
    arc_2_0_11  in_degree_1521  1
    arc_2_0_11  original_T_including_depot_unload_1592  1.2506062209426416e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_11  arc_capacity_1224  1
    load_2_0_11  segment_load_conservation_1524  -1
    load_2_0_11  segment_prefix_lb_1525  1
    load_2_0_11  segment_prefix_ub_1526  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_12  arc_capacity_1225  -30
    arc_2_0_12  depot_departure_or_bypass_1511  1
    arc_2_0_12  in_degree_1528  1
    arc_2_0_12  original_T_including_depot_unload_1592  1.4501558573355060e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_12  arc_capacity_1225  1
    load_2_0_12  segment_load_conservation_1531  -1
    load_2_0_12  segment_prefix_lb_1532  1
    load_2_0_12  segment_prefix_ub_1533  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_13  arc_capacity_1226  -30
    arc_2_0_13  depot_departure_or_bypass_1511  1
    arc_2_0_13  in_degree_1535  1
    arc_2_0_13  original_T_including_depot_unload_1592  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_13  arc_capacity_1226  1
    load_2_0_13  segment_load_conservation_1538  -1
    load_2_0_13  segment_prefix_lb_1539  1
    load_2_0_13  segment_prefix_ub_1540  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_14  arc_capacity_1227  -30
    arc_2_0_14  depot_departure_or_bypass_1511  1
    arc_2_0_14  in_degree_1542  1
    arc_2_0_14  original_T_including_depot_unload_1592  4.6364706268001146e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_14  arc_capacity_1227  1
    load_2_0_14  free_load_conservation_1546  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_15  arc_capacity_1228  -30
    arc_2_0_15  depot_departure_or_bypass_1511  1
    arc_2_0_15  in_degree_1548  1
    arc_2_0_15  original_T_including_depot_unload_1592  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_15  arc_capacity_1228  1
    load_2_0_15  free_load_conservation_1552  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_16  arc_capacity_1229  -30
    arc_2_0_16  depot_departure_or_bypass_1511  1
    arc_2_0_16  in_degree_1554  1
    arc_2_0_16  original_T_including_depot_unload_1592  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_16  arc_capacity_1229  1
    load_2_0_16  free_load_conservation_1558  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_17  arc_capacity_1230  -30
    arc_2_0_17  depot_departure_or_bypass_1511  1
    arc_2_0_17  in_degree_1560  1
    arc_2_0_17  original_T_including_depot_unload_1592  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_17  arc_capacity_1230  1
    load_2_0_17  free_load_conservation_1564  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_18  arc_capacity_1231  -30
    arc_2_0_18  depot_departure_or_bypass_1511  1
    arc_2_0_18  in_degree_1566  1
    arc_2_0_18  original_T_including_depot_unload_1592  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_18  arc_capacity_1231  1
    load_2_0_18  free_load_conservation_1570  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_19  arc_capacity_1232  -30
    arc_2_0_19  depot_departure_or_bypass_1511  1
    arc_2_0_19  in_degree_1572  1
    arc_2_0_19  original_T_including_depot_unload_1592  5.9431738885389052e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_19  arc_capacity_1232  1
    load_2_0_19  free_load_conservation_1576  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_20  arc_capacity_1233  -30
    arc_2_0_20  depot_departure_or_bypass_1511  1
    arc_2_0_20  in_degree_1578  1
    arc_2_0_20  original_T_including_depot_unload_1592  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_20  arc_capacity_1233  1
    load_2_0_20  free_load_conservation_1582  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_21  arc_capacity_1234  -30
    arc_2_0_21  depot_departure_or_bypass_1511  1
    arc_2_0_21  in_degree_1584  1
    arc_2_0_21  original_T_including_depot_unload_1592  7.2571167924583824e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_21  arc_capacity_1234  1
    load_2_0_21  free_load_conservation_1588  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_0  arc_capacity_1235  -30
    arc_2_10_0  depot_return_or_bypass_1512  1
    arc_2_10_0  out_degree_1513  1
    arc_2_10_0  original_T_including_depot_unload_1592  1.4567038050199781e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_0  arc_capacity_1235  1
    load_2_10_0  segment_load_conservation_1517  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_11  arc_capacity_1236  -30
    arc_2_10_11  connected_order_arc_1237  -13
    arc_2_10_11  out_degree_1513  1
    arc_2_10_11  in_degree_1521  1
    arc_2_10_11  original_T_including_depot_unload_1592  5.2746035265689818e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_11  arc_capacity_1236  1
    load_2_10_11  segment_load_conservation_1517  1
    load_2_10_11  segment_load_conservation_1524  -1
    load_2_10_11  segment_prefix_lb_1525  1
    load_2_10_11  segment_prefix_ub_1526  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_12  arc_capacity_1238  -30
    arc_2_10_12  connected_order_arc_1239  -13
    arc_2_10_12  out_degree_1513  1
    arc_2_10_12  in_degree_1528  1
    arc_2_10_12  original_T_including_depot_unload_1592  2.1542021003680966e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_12  arc_capacity_1238  1
    load_2_10_12  segment_load_conservation_1517  1
    load_2_10_12  segment_load_conservation_1531  -1
    load_2_10_12  segment_prefix_lb_1532  1
    load_2_10_12  segment_prefix_ub_1533  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_13  arc_capacity_1240  -30
    arc_2_10_13  connected_order_arc_1241  -13
    arc_2_10_13  out_degree_1513  1
    arc_2_10_13  in_degree_1535  1
    arc_2_10_13  original_T_including_depot_unload_1592  1.4332871320059419e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_13  arc_capacity_1240  1
    load_2_10_13  segment_load_conservation_1517  1
    load_2_10_13  segment_load_conservation_1538  -1
    load_2_10_13  segment_prefix_lb_1539  1
    load_2_10_13  segment_prefix_ub_1540  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_14  arc_capacity_1242  -30
    arc_2_10_14  connected_order_arc_1243  -13
    arc_2_10_14  out_degree_1513  1
    arc_2_10_14  in_degree_1542  1
    arc_2_10_14  original_T_including_depot_unload_1592  1.0428195034234207e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_14  arc_capacity_1242  1
    load_2_10_14  segment_load_conservation_1517  1
    load_2_10_14  free_load_conservation_1546  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_15  arc_capacity_1244  -30
    arc_2_10_15  connected_order_arc_1245  -13
    arc_2_10_15  out_degree_1513  1
    arc_2_10_15  in_degree_1548  1
    arc_2_10_15  original_T_including_depot_unload_1592  1.2835993572680911e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_15  arc_capacity_1244  1
    load_2_10_15  segment_load_conservation_1517  1
    load_2_10_15  free_load_conservation_1552  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_16  arc_capacity_1246  -30
    arc_2_10_16  connected_order_arc_1247  -13
    arc_2_10_16  out_degree_1513  1
    arc_2_10_16  in_degree_1554  1
    arc_2_10_16  original_T_including_depot_unload_1592  1.2027697073878232e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_16  arc_capacity_1246  1
    load_2_10_16  segment_load_conservation_1517  1
    load_2_10_16  free_load_conservation_1558  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_17  arc_capacity_1248  -30
    arc_2_10_17  connected_order_arc_1249  -13
    arc_2_10_17  out_degree_1513  1
    arc_2_10_17  in_degree_1560  1
    arc_2_10_17  original_T_including_depot_unload_1592  8.0219422833177862e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_17  arc_capacity_1248  1
    load_2_10_17  segment_load_conservation_1517  1
    load_2_10_17  free_load_conservation_1564  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_18  arc_capacity_1250  -30
    arc_2_10_18  connected_order_arc_1251  -13
    arc_2_10_18  out_degree_1513  1
    arc_2_10_18  in_degree_1566  1
    arc_2_10_18  original_T_including_depot_unload_1592  2.0178882184947397e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_18  arc_capacity_1250  1
    load_2_10_18  segment_load_conservation_1517  1
    load_2_10_18  free_load_conservation_1570  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_19  arc_capacity_1252  -30
    arc_2_10_19  connected_order_arc_1253  -13
    arc_2_10_19  out_degree_1513  1
    arc_2_10_19  in_degree_1572  1
    arc_2_10_19  original_T_including_depot_unload_1592  1.1848225970179703e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_19  arc_capacity_1252  1
    load_2_10_19  segment_load_conservation_1517  1
    load_2_10_19  free_load_conservation_1576  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_20  arc_capacity_1254  -30
    arc_2_10_20  connected_order_arc_1255  -13
    arc_2_10_20  out_degree_1513  1
    arc_2_10_20  in_degree_1578  1
    arc_2_10_20  original_T_including_depot_unload_1592  3.1118349756671438e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_20  arc_capacity_1254  1
    load_2_10_20  segment_load_conservation_1517  1
    load_2_10_20  free_load_conservation_1582  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_21  arc_capacity_1256  -30
    arc_2_10_21  connected_order_arc_1257  -13
    arc_2_10_21  out_degree_1513  1
    arc_2_10_21  in_degree_1584  1
    arc_2_10_21  original_T_including_depot_unload_1592  9.7877495286142823e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_21  arc_capacity_1256  1
    load_2_10_21  segment_load_conservation_1517  1
    load_2_10_21  free_load_conservation_1588  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_0  arc_capacity_1258  -30
    arc_2_11_0  depot_return_or_bypass_1512  1
    arc_2_11_0  out_degree_1520  1
    arc_2_11_0  original_T_including_depot_unload_1592  1.2506062209426416e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_0  arc_capacity_1258  1
    load_2_11_0  segment_load_conservation_1524  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_10  arc_capacity_1259  -30
    arc_2_11_10  connected_order_arc_1260  -13
    arc_2_11_10  in_degree_1514  1
    arc_2_11_10  out_degree_1520  1
    arc_2_11_10  original_T_including_depot_unload_1592  5.2746035265689818e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_10  arc_capacity_1259  1
    load_2_11_10  segment_load_conservation_1517  -1
    load_2_11_10  segment_prefix_lb_1518  1
    load_2_11_10  segment_prefix_ub_1519  1
    load_2_11_10  segment_load_conservation_1524  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_12  arc_capacity_1261  -30
    arc_2_11_12  connected_order_arc_1262  -13
    arc_2_11_12  out_degree_1520  1
    arc_2_11_12  in_degree_1528  1
    arc_2_11_12  original_T_including_depot_unload_1592  1.6502895430075375e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_12  arc_capacity_1261  1
    load_2_11_12  segment_load_conservation_1524  1
    load_2_11_12  segment_load_conservation_1531  -1
    load_2_11_12  segment_prefix_lb_1532  1
    load_2_11_12  segment_prefix_ub_1533  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_13  arc_capacity_1263  -30
    arc_2_11_13  connected_order_arc_1264  -13
    arc_2_11_13  out_degree_1520  1
    arc_2_11_13  in_degree_1535  1
    arc_2_11_13  original_T_including_depot_unload_1592  1.0874822831610163e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_13  arc_capacity_1263  1
    load_2_11_13  segment_load_conservation_1524  1
    load_2_11_13  segment_load_conservation_1538  -1
    load_2_11_13  segment_prefix_lb_1539  1
    load_2_11_13  segment_prefix_ub_1540  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_14  arc_capacity_1265  -30
    arc_2_11_14  connected_order_arc_1266  -13
    arc_2_11_14  out_degree_1520  1
    arc_2_11_14  in_degree_1542  1
    arc_2_11_14  original_T_including_depot_unload_1592  7.8724938919046190e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_14  arc_capacity_1265  1
    load_2_11_14  segment_load_conservation_1524  1
    load_2_11_14  free_load_conservation_1546  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_15  arc_capacity_1267  -30
    arc_2_11_15  connected_order_arc_1268  -13
    arc_2_11_15  out_degree_1520  1
    arc_2_11_15  in_degree_1548  1
    arc_2_11_15  original_T_including_depot_unload_1592  1.0138993437494995e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_15  arc_capacity_1267  1
    load_2_11_15  segment_load_conservation_1524  1
    load_2_11_15  free_load_conservation_1552  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_16  arc_capacity_1269  -30
    arc_2_11_16  connected_order_arc_1270  -13
    arc_2_11_16  out_degree_1520  1
    arc_2_11_16  in_degree_1554  1
    arc_2_11_16  original_T_including_depot_unload_1592  1.4255422670497167e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_16  arc_capacity_1269  1
    load_2_11_16  segment_load_conservation_1524  1
    load_2_11_16  free_load_conservation_1558  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_17  arc_capacity_1271  -30
    arc_2_11_17  connected_order_arc_1272  -13
    arc_2_11_17  out_degree_1520  1
    arc_2_11_17  in_degree_1560  1
    arc_2_11_17  original_T_including_depot_unload_1592  5.2472086221481925e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_17  arc_capacity_1271  1
    load_2_11_17  segment_load_conservation_1524  1
    load_2_11_17  free_load_conservation_1564  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_18  arc_capacity_1273  -30
    arc_2_11_18  connected_order_arc_1274  -13
    arc_2_11_18  out_degree_1520  1
    arc_2_11_18  in_degree_1566  1
    arc_2_11_18  original_T_including_depot_unload_1592  1.8362893893653638e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_18  arc_capacity_1273  1
    load_2_11_18  segment_load_conservation_1524  1
    load_2_11_18  free_load_conservation_1570  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_19  arc_capacity_1275  -30
    arc_2_11_19  connected_order_arc_1276  -13
    arc_2_11_19  out_degree_1520  1
    arc_2_11_19  in_degree_1572  1
    arc_2_11_19  original_T_including_depot_unload_1592  8.0231446125927152e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_19  arc_capacity_1275  1
    load_2_11_19  segment_load_conservation_1524  1
    load_2_11_19  free_load_conservation_1576  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_20  arc_capacity_1277  -30
    arc_2_11_20  connected_order_arc_1278  -13
    arc_2_11_20  out_degree_1520  1
    arc_2_11_20  in_degree_1578  1
    arc_2_11_20  original_T_including_depot_unload_1592  2.2865444230199981e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_20  arc_capacity_1277  1
    load_2_11_20  segment_load_conservation_1524  1
    load_2_11_20  free_load_conservation_1582  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_21  arc_capacity_1279  -30
    arc_2_11_21  connected_order_arc_1280  -13
    arc_2_11_21  out_degree_1520  1
    arc_2_11_21  in_degree_1584  1
    arc_2_11_21  original_T_including_depot_unload_1592  5.8943244236516807e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_21  arc_capacity_1279  1
    load_2_11_21  segment_load_conservation_1524  1
    load_2_11_21  free_load_conservation_1588  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_0  arc_capacity_1281  -30
    arc_2_12_0  depot_return_or_bypass_1512  1
    arc_2_12_0  out_degree_1527  1
    arc_2_12_0  original_T_including_depot_unload_1592  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_0  arc_capacity_1281  1
    load_2_12_0  segment_load_conservation_1531  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_10  arc_capacity_1282  -30
    arc_2_12_10  connected_order_arc_1283  -13
    arc_2_12_10  in_degree_1514  1
    arc_2_12_10  out_degree_1527  1
    arc_2_12_10  original_T_including_depot_unload_1592  1.5960107821452696e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_10  arc_capacity_1282  1
    load_2_12_10  segment_load_conservation_1517  -1
    load_2_12_10  segment_prefix_lb_1518  1
    load_2_12_10  segment_prefix_ub_1519  1
    load_2_12_10  segment_load_conservation_1531  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_11  arc_capacity_1284  -30
    arc_2_12_11  connected_order_arc_1285  -13
    arc_2_12_11  in_degree_1521  1
    arc_2_12_11  out_degree_1527  1
    arc_2_12_11  original_T_including_depot_unload_1592  1.2335670980381785e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_11  arc_capacity_1284  1
    load_2_12_11  segment_load_conservation_1524  -1
    load_2_12_11  segment_prefix_lb_1525  1
    load_2_12_11  segment_prefix_ub_1526  1
    load_2_12_11  segment_load_conservation_1531  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_13  arc_capacity_1286  -30
    arc_2_12_13  connected_order_arc_1287  -13
    arc_2_12_13  out_degree_1527  1
    arc_2_12_13  in_degree_1535  1
    arc_2_12_13  original_T_including_depot_unload_1592  1.6597164064313077e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_13  arc_capacity_1286  1
    load_2_12_13  segment_load_conservation_1531  1
    load_2_12_13  segment_load_conservation_1538  -1
    load_2_12_13  segment_prefix_lb_1539  1
    load_2_12_13  segment_prefix_ub_1540  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_14  arc_capacity_1288  -30
    arc_2_12_14  connected_order_arc_1289  -13
    arc_2_12_14  out_degree_1527  1
    arc_2_12_14  in_degree_1542  1
    arc_2_12_14  original_T_including_depot_unload_1592  5.8212369880329140e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_14  arc_capacity_1288  1
    load_2_12_14  segment_load_conservation_1531  1
    load_2_12_14  free_load_conservation_1546  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_15  arc_capacity_1290  -30
    arc_2_12_15  connected_order_arc_1291  -13
    arc_2_12_15  out_degree_1527  1
    arc_2_12_15  in_degree_1548  1
    arc_2_12_15  original_T_including_depot_unload_1592  3.8790073962518773e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_15  arc_capacity_1290  1
    load_2_12_15  segment_load_conservation_1531  1
    load_2_12_15  free_load_conservation_1552  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_16  arc_capacity_1292  -30
    arc_2_12_16  connected_order_arc_1293  -13
    arc_2_12_16  out_degree_1527  1
    arc_2_12_16  in_degree_1554  1
    arc_2_12_16  original_T_including_depot_unload_1592  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_16  arc_capacity_1292  1
    load_2_12_16  segment_load_conservation_1531  1
    load_2_12_16  free_load_conservation_1558  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_17  arc_capacity_1294  -30
    arc_2_12_17  connected_order_arc_1295  -13
    arc_2_12_17  out_degree_1527  1
    arc_2_12_17  in_degree_1560  1
    arc_2_12_17  original_T_including_depot_unload_1592  7.9403551275216375e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_17  arc_capacity_1294  1
    load_2_12_17  segment_load_conservation_1531  1
    load_2_12_17  free_load_conservation_1564  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_18  arc_capacity_1296  -30
    arc_2_12_18  connected_order_arc_1297  -13
    arc_2_12_18  out_degree_1527  1
    arc_2_12_18  in_degree_1566  1
    arc_2_12_18  original_T_including_depot_unload_1592  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_18  arc_capacity_1296  1
    load_2_12_18  segment_load_conservation_1531  1
    load_2_12_18  free_load_conservation_1570  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_19  arc_capacity_1298  -30
    arc_2_12_19  connected_order_arc_1299  -13
    arc_2_12_19  out_degree_1527  1
    arc_2_12_19  in_degree_1572  1
    arc_2_12_19  original_T_including_depot_unload_1592  4.3129452098285111e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_19  arc_capacity_1298  1
    load_2_12_19  segment_load_conservation_1531  1
    load_2_12_19  free_load_conservation_1576  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_20  arc_capacity_1300  -30
    arc_2_12_20  connected_order_arc_1301  -13
    arc_2_12_20  out_degree_1527  1
    arc_2_12_20  in_degree_1578  1
    arc_2_12_20  original_T_including_depot_unload_1592  1.4150780419437449e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_20  arc_capacity_1300  1
    load_2_12_20  segment_load_conservation_1531  1
    load_2_12_20  free_load_conservation_1582  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_21  arc_capacity_1302  -30
    arc_2_12_21  connected_order_arc_1303  -13
    arc_2_12_21  out_degree_1527  1
    arc_2_12_21  in_degree_1584  1
    arc_2_12_21  original_T_including_depot_unload_1592  6.4542450829473034e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_21  arc_capacity_1302  1
    load_2_12_21  segment_load_conservation_1531  1
    load_2_12_21  free_load_conservation_1588  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_0  arc_capacity_1304  -30
    arc_2_13_0  depot_return_or_bypass_1512  1
    arc_2_13_0  out_degree_1534  1
    arc_2_13_0  original_T_including_depot_unload_1592  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_0  arc_capacity_1304  1
    load_2_13_0  segment_load_conservation_1538  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_10  arc_capacity_1305  -30
    arc_2_13_10  connected_order_arc_1306  -13
    arc_2_13_10  in_degree_1514  1
    arc_2_13_10  out_degree_1534  1
    arc_2_13_10  original_T_including_depot_unload_1592  1.4332871320059419e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_10  arc_capacity_1305  1
    load_2_13_10  segment_load_conservation_1517  -1
    load_2_13_10  segment_prefix_lb_1518  1
    load_2_13_10  segment_prefix_ub_1519  1
    load_2_13_10  segment_load_conservation_1538  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_11  arc_capacity_1307  -30
    arc_2_13_11  connected_order_arc_1308  -13
    arc_2_13_11  in_degree_1521  1
    arc_2_13_11  out_degree_1534  1
    arc_2_13_11  original_T_including_depot_unload_1592  1.0874822831610163e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_11  arc_capacity_1307  1
    load_2_13_11  segment_load_conservation_1524  -1
    load_2_13_11  segment_prefix_lb_1525  1
    load_2_13_11  segment_prefix_ub_1526  1
    load_2_13_11  segment_load_conservation_1538  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_12  arc_capacity_1309  -30
    arc_2_13_12  connected_order_arc_1310  -13
    arc_2_13_12  in_degree_1528  1
    arc_2_13_12  out_degree_1534  1
    arc_2_13_12  original_T_including_depot_unload_1592  1.0592524244968324e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_12  arc_capacity_1309  1
    load_2_13_12  segment_load_conservation_1531  -1
    load_2_13_12  segment_prefix_lb_1532  1
    load_2_13_12  segment_prefix_ub_1533  1
    load_2_13_12  segment_load_conservation_1538  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_14  arc_capacity_1311  -30
    arc_2_13_14  connected_order_arc_1312  -13
    arc_2_13_14  out_degree_1534  1
    arc_2_13_14  in_degree_1542  1
    arc_2_13_14  original_T_including_depot_unload_1592  4.1665889045115779e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_14  arc_capacity_1311  1
    load_2_13_14  segment_load_conservation_1538  1
    load_2_13_14  free_load_conservation_1546  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_15  arc_capacity_1313  -30
    arc_2_13_15  connected_order_arc_1314  -13
    arc_2_13_15  out_degree_1534  1
    arc_2_13_15  in_degree_1548  1
    arc_2_13_15  original_T_including_depot_unload_1592  2.4083746437975364e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_15  arc_capacity_1313  1
    load_2_13_15  segment_load_conservation_1538  1
    load_2_13_15  free_load_conservation_1552  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_16  arc_capacity_1315  -30
    arc_2_13_16  connected_order_arc_1316  -13
    arc_2_13_16  out_degree_1534  1
    arc_2_13_16  in_degree_1554  1
    arc_2_13_16  original_T_including_depot_unload_1592  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_16  arc_capacity_1315  1
    load_2_13_16  segment_load_conservation_1538  1
    load_2_13_16  free_load_conservation_1558  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_17  arc_capacity_1317  -30
    arc_2_13_17  connected_order_arc_1318  -13
    arc_2_13_17  out_degree_1534  1
    arc_2_13_17  in_degree_1560  1
    arc_2_13_17  original_T_including_depot_unload_1592  6.3111682574558915e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_17  arc_capacity_1317  1
    load_2_13_17  segment_load_conservation_1538  1
    load_2_13_17  free_load_conservation_1564  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_18  arc_capacity_1319  -30
    arc_2_13_18  connected_order_arc_1320  -13
    arc_2_13_18  out_degree_1534  1
    arc_2_13_18  in_degree_1566  1
    arc_2_13_18  original_T_including_depot_unload_1592  8.7684829846426385e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_18  arc_capacity_1319  1
    load_2_13_18  segment_load_conservation_1538  1
    load_2_13_18  free_load_conservation_1570  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_19  arc_capacity_1321  -30
    arc_2_13_19  connected_order_arc_1322  -13
    arc_2_13_19  out_degree_1534  1
    arc_2_13_19  in_degree_1572  1
    arc_2_13_19  original_T_including_depot_unload_1592  2.9098466309579254e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_19  arc_capacity_1321  1
    load_2_13_19  segment_load_conservation_1538  1
    load_2_13_19  free_load_conservation_1576  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_20  arc_capacity_1323  -30
    arc_2_13_20  connected_order_arc_1324  -13
    arc_2_13_20  out_degree_1534  1
    arc_2_13_20  in_degree_1578  1
    arc_2_13_20  original_T_including_depot_unload_1592  1.2608612406747543e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_20  arc_capacity_1323  1
    load_2_13_20  segment_load_conservation_1538  1
    load_2_13_20  free_load_conservation_1582  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_21  arc_capacity_1325  -30
    arc_2_13_21  connected_order_arc_1326  -13
    arc_2_13_21  out_degree_1534  1
    arc_2_13_21  in_degree_1584  1
    arc_2_13_21  original_T_including_depot_unload_1592  4.9831220386775891e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_21  arc_capacity_1325  1
    load_2_13_21  segment_load_conservation_1538  1
    load_2_13_21  free_load_conservation_1588  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_0  arc_capacity_1327  -30
    arc_2_14_0  depot_return_or_bypass_1512  1
    arc_2_14_0  out_degree_1541  1
    arc_2_14_0  original_T_including_depot_unload_1592  4.6364706268001146e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_0  arc_capacity_1327  1
    load_2_14_0  free_load_conservation_1546  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_10  arc_capacity_1328  -30
    arc_2_14_10  connected_order_arc_1329  -13
    arc_2_14_10  in_degree_1514  1
    arc_2_14_10  out_degree_1541  1
    arc_2_14_10  original_T_including_depot_unload_1592  1.0428195034234207e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_10  arc_capacity_1328  1
    load_2_14_10  segment_load_conservation_1517  -1
    load_2_14_10  segment_prefix_lb_1518  1
    load_2_14_10  segment_prefix_ub_1519  1
    load_2_14_10  free_load_conservation_1546  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_11  arc_capacity_1330  -30
    arc_2_14_11  connected_order_arc_1331  -13
    arc_2_14_11  in_degree_1521  1
    arc_2_14_11  out_degree_1541  1
    arc_2_14_11  original_T_including_depot_unload_1592  7.8724938919046190e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_11  arc_capacity_1330  1
    load_2_14_11  segment_load_conservation_1524  -1
    load_2_14_11  segment_prefix_lb_1525  1
    load_2_14_11  segment_prefix_ub_1526  1
    load_2_14_11  free_load_conservation_1546  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_12  arc_capacity_1332  -30
    arc_2_14_12  connected_order_arc_1333  -13
    arc_2_14_12  in_degree_1528  1
    arc_2_14_12  out_degree_1541  1
    arc_2_14_12  original_T_including_depot_unload_1592  1.3898988531263665e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_12  arc_capacity_1332  1
    load_2_14_12  segment_load_conservation_1531  -1
    load_2_14_12  segment_prefix_lb_1532  1
    load_2_14_12  segment_prefix_ub_1533  1
    load_2_14_12  free_load_conservation_1546  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_13  arc_capacity_1334  -30
    arc_2_14_13  connected_order_arc_1335  -13
    arc_2_14_13  in_degree_1535  1
    arc_2_14_13  out_degree_1541  1
    arc_2_14_13  original_T_including_depot_unload_1592  4.1665889045115779e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_13  arc_capacity_1334  1
    load_2_14_13  segment_load_conservation_1538  -1
    load_2_14_13  segment_prefix_lb_1539  1
    load_2_14_13  segment_prefix_ub_1540  1
    load_2_14_13  free_load_conservation_1546  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_15  arc_capacity_1336  -30
    arc_2_14_15  connected_order_arc_1337  -13
    arc_2_14_15  out_degree_1541  1
    arc_2_14_15  in_degree_1548  1
    arc_2_14_15  original_T_including_depot_unload_1592  2.4191291221621205e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_15  arc_capacity_1336  1
    load_2_14_15  free_load_conservation_1546  1
    load_2_14_15  free_load_conservation_1552  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_16  arc_capacity_1338  -30
    arc_2_14_16  connected_order_arc_1339  -13
    arc_2_14_16  out_degree_1541  1
    arc_2_14_16  in_degree_1554  1
    arc_2_14_16  original_T_including_depot_unload_1592  1075.72043838369
    MARKER    'MARKER'                 'INTEND'
    load_2_14_16  arc_capacity_1338  1
    load_2_14_16  free_load_conservation_1546  1
    load_2_14_16  free_load_conservation_1558  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_17  arc_capacity_1340  -30
    arc_2_14_17  connected_order_arc_1341  -13
    arc_2_14_17  out_degree_1541  1
    arc_2_14_17  in_degree_1560  1
    arc_2_14_17  original_T_including_depot_unload_1592  2.6602972191926557e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_17  arc_capacity_1340  1
    load_2_14_17  free_load_conservation_1546  1
    load_2_14_17  free_load_conservation_1564  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_18  arc_capacity_1342  -30
    arc_2_14_18  connected_order_arc_1343  -13
    arc_2_14_18  out_degree_1541  1
    arc_2_14_18  in_degree_1566  1
    arc_2_14_18  original_T_including_depot_unload_1592  1.0491196843462671e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_18  arc_capacity_1342  1
    load_2_14_18  free_load_conservation_1546  1
    load_2_14_18  free_load_conservation_1570  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_19  arc_capacity_1344  -30
    arc_2_14_19  connected_order_arc_1345  -13
    arc_2_14_19  out_degree_1541  1
    arc_2_14_19  in_degree_1572  1
    arc_2_14_19  original_T_including_depot_unload_1592  2.9706418113632907e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_19  arc_capacity_1344  1
    load_2_14_19  free_load_conservation_1546  1
    load_2_14_19  free_load_conservation_1576  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_20  arc_capacity_1346  -30
    arc_2_14_20  connected_order_arc_1347  -13
    arc_2_14_20  out_degree_1541  1
    arc_2_14_20  in_degree_1578  1
    arc_2_14_20  original_T_including_depot_unload_1592  9.1576870176747968e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_20  arc_capacity_1346  1
    load_2_14_20  free_load_conservation_1546  1
    load_2_14_20  free_load_conservation_1582  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_21  arc_capacity_1348  -30
    arc_2_14_21  connected_order_arc_1349  -13
    arc_2_14_21  out_degree_1541  1
    arc_2_14_21  in_degree_1584  1
    arc_2_14_21  original_T_including_depot_unload_1592  3.0055050459786975e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_21  arc_capacity_1348  1
    load_2_14_21  free_load_conservation_1546  1
    load_2_14_21  free_load_conservation_1588  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_0  arc_capacity_1350  -30
    arc_2_15_0  depot_return_or_bypass_1512  1
    arc_2_15_0  out_degree_1547  1
    arc_2_15_0  original_T_including_depot_unload_1592  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_0  arc_capacity_1350  1
    load_2_15_0  free_load_conservation_1552  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_10  arc_capacity_1351  -30
    arc_2_15_10  connected_order_arc_1352  -13
    arc_2_15_10  in_degree_1514  1
    arc_2_15_10  out_degree_1547  1
    arc_2_15_10  original_T_including_depot_unload_1592  1.2835993572680911e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_10  arc_capacity_1351  1
    load_2_15_10  segment_load_conservation_1517  -1
    load_2_15_10  segment_prefix_lb_1518  1
    load_2_15_10  segment_prefix_ub_1519  1
    load_2_15_10  free_load_conservation_1552  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_11  arc_capacity_1353  -30
    arc_2_15_11  connected_order_arc_1354  -13
    arc_2_15_11  in_degree_1521  1
    arc_2_15_11  out_degree_1547  1
    arc_2_15_11  original_T_including_depot_unload_1592  1.0138993437494995e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_11  arc_capacity_1353  1
    load_2_15_11  segment_load_conservation_1524  -1
    load_2_15_11  segment_prefix_lb_1525  1
    load_2_15_11  segment_prefix_ub_1526  1
    load_2_15_11  free_load_conservation_1552  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_12  arc_capacity_1355  -30
    arc_2_15_12  connected_order_arc_1356  -13
    arc_2_15_12  in_degree_1528  1
    arc_2_15_12  out_degree_1547  1
    arc_2_15_12  original_T_including_depot_unload_1592  1.2946770575314561e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_12  arc_capacity_1355  1
    load_2_15_12  segment_load_conservation_1531  -1
    load_2_15_12  segment_prefix_lb_1532  1
    load_2_15_12  segment_prefix_ub_1533  1
    load_2_15_12  free_load_conservation_1552  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_13  arc_capacity_1357  -30
    arc_2_15_13  connected_order_arc_1358  -13
    arc_2_15_13  in_degree_1535  1
    arc_2_15_13  out_degree_1547  1
    arc_2_15_13  original_T_including_depot_unload_1592  2.4083746437975364e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_13  arc_capacity_1357  1
    load_2_15_13  segment_load_conservation_1538  -1
    load_2_15_13  segment_prefix_lb_1539  1
    load_2_15_13  segment_prefix_ub_1540  1
    load_2_15_13  free_load_conservation_1552  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_14  arc_capacity_1359  -30
    arc_2_15_14  connected_order_arc_1360  -13
    arc_2_15_14  in_degree_1542  1
    arc_2_15_14  out_degree_1547  1
    arc_2_15_14  original_T_including_depot_unload_1592  2.4191291221621205e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_14  arc_capacity_1359  1
    load_2_15_14  free_load_conservation_1546  -1
    load_2_15_14  free_load_conservation_1552  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_16  arc_capacity_1361  -30
    arc_2_15_16  connected_order_arc_1362  -13
    arc_2_15_16  out_degree_1547  1
    arc_2_15_16  in_degree_1554  1
    arc_2_15_16  original_T_including_depot_unload_1592  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_16  arc_capacity_1361  1
    load_2_15_16  free_load_conservation_1552  1
    load_2_15_16  free_load_conservation_1558  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_17  arc_capacity_1363  -30
    arc_2_15_17  connected_order_arc_1364  -13
    arc_2_15_17  out_degree_1547  1
    arc_2_15_17  in_degree_1560  1
    arc_2_15_17  original_T_including_depot_unload_1592  5.0315495126439691e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_17  arc_capacity_1363  1
    load_2_15_17  free_load_conservation_1552  1
    load_2_15_17  free_load_conservation_1564  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_18  arc_capacity_1365  -30
    arc_2_15_18  connected_order_arc_1366  -13
    arc_2_15_18  out_degree_1547  1
    arc_2_15_18  in_degree_1566  1
    arc_2_15_18  original_T_including_depot_unload_1592  8.3486971116736720e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_18  arc_capacity_1365  1
    load_2_15_18  free_load_conservation_1552  1
    load_2_15_18  free_load_conservation_1570  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_19  arc_capacity_1367  -30
    arc_2_15_19  connected_order_arc_1368  -13
    arc_2_15_19  out_degree_1547  1
    arc_2_15_19  in_degree_1572  1
    arc_2_15_19  original_T_including_depot_unload_1592  3.2938591738444967e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_19  arc_capacity_1367  1
    load_2_15_19  free_load_conservation_1552  1
    load_2_15_19  free_load_conservation_1576  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_20  arc_capacity_1369  -30
    arc_2_15_20  connected_order_arc_1370  -13
    arc_2_15_20  out_degree_1547  1
    arc_2_15_20  in_degree_1578  1
    arc_2_15_20  original_T_including_depot_unload_1592  1.1544376314422677e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_20  arc_capacity_1369  1
    load_2_15_20  free_load_conservation_1552  1
    load_2_15_20  free_load_conservation_1582  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_21  arc_capacity_1371  -30
    arc_2_15_21  connected_order_arc_1372  -13
    arc_2_15_21  out_degree_1547  1
    arc_2_15_21  in_degree_1584  1
    arc_2_15_21  original_T_including_depot_unload_1592  4.6276703023336785e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_21  arc_capacity_1371  1
    load_2_15_21  free_load_conservation_1552  1
    load_2_15_21  free_load_conservation_1588  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_0  arc_capacity_1373  -30
    arc_2_16_0  depot_return_or_bypass_1512  1
    arc_2_16_0  out_degree_1553  1
    arc_2_16_0  original_T_including_depot_unload_1592  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_0  arc_capacity_1373  1
    load_2_16_0  free_load_conservation_1558  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_10  arc_capacity_1374  -30
    arc_2_16_10  connected_order_arc_1375  -13
    arc_2_16_10  in_degree_1514  1
    arc_2_16_10  out_degree_1553  1
    arc_2_16_10  original_T_including_depot_unload_1592  1.2027697073878232e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_10  arc_capacity_1374  1
    load_2_16_10  segment_load_conservation_1517  -1
    load_2_16_10  segment_prefix_lb_1518  1
    load_2_16_10  segment_prefix_ub_1519  1
    load_2_16_10  free_load_conservation_1558  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_11  arc_capacity_1376  -30
    arc_2_16_11  connected_order_arc_1377  -13
    arc_2_16_11  in_degree_1521  1
    arc_2_16_11  out_degree_1553  1
    arc_2_16_11  original_T_including_depot_unload_1592  1.4255422670497167e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_11  arc_capacity_1376  1
    load_2_16_11  segment_load_conservation_1524  -1
    load_2_16_11  segment_prefix_lb_1525  1
    load_2_16_11  segment_prefix_ub_1526  1
    load_2_16_11  free_load_conservation_1558  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_12  arc_capacity_1378  -30
    arc_2_16_12  connected_order_arc_1379  -13
    arc_2_16_12  in_degree_1528  1
    arc_2_16_12  out_degree_1553  1
    arc_2_16_12  original_T_including_depot_unload_1592  2.4496137598598170e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_12  arc_capacity_1378  1
    load_2_16_12  segment_load_conservation_1531  -1
    load_2_16_12  segment_prefix_lb_1532  1
    load_2_16_12  segment_prefix_ub_1533  1
    load_2_16_12  free_load_conservation_1558  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_13  arc_capacity_1380  -30
    arc_2_16_13  connected_order_arc_1381  -13
    arc_2_16_13  in_degree_1535  1
    arc_2_16_13  out_degree_1553  1
    arc_2_16_13  original_T_including_depot_unload_1592  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_13  arc_capacity_1380  1
    load_2_16_13  segment_load_conservation_1538  -1
    load_2_16_13  segment_prefix_lb_1539  1
    load_2_16_13  segment_prefix_ub_1540  1
    load_2_16_13  free_load_conservation_1558  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_14  arc_capacity_1382  -30
    arc_2_16_14  connected_order_arc_1383  -13
    arc_2_16_14  in_degree_1542  1
    arc_2_16_14  out_degree_1553  1
    arc_2_16_14  original_T_including_depot_unload_1592  1075.72043838369
    MARKER    'MARKER'                 'INTEND'
    load_2_16_14  arc_capacity_1382  1
    load_2_16_14  free_load_conservation_1546  -1
    load_2_16_14  free_load_conservation_1558  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_15  arc_capacity_1384  -30
    arc_2_16_15  connected_order_arc_1385  -13
    arc_2_16_15  in_degree_1548  1
    arc_2_16_15  out_degree_1553  1
    arc_2_16_15  original_T_including_depot_unload_1592  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_15  arc_capacity_1384  1
    load_2_16_15  free_load_conservation_1552  -1
    load_2_16_15  free_load_conservation_1558  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_17  arc_capacity_1386  -30
    arc_2_16_17  connected_order_arc_1387  -13
    arc_2_16_17  out_degree_1553  1
    arc_2_16_17  in_degree_1560  1
    arc_2_16_17  original_T_including_depot_unload_1592  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_17  arc_capacity_1386  1
    load_2_16_17  free_load_conservation_1558  1
    load_2_16_17  free_load_conservation_1564  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_18  arc_capacity_1388  -30
    arc_2_16_18  connected_order_arc_1389  -13
    arc_2_16_18  out_degree_1553  1
    arc_2_16_18  in_degree_1566  1
    arc_2_16_18  original_T_including_depot_unload_1592  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_18  arc_capacity_1388  1
    load_2_16_18  free_load_conservation_1558  1
    load_2_16_18  free_load_conservation_1570  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_19  arc_capacity_1390  -30
    arc_2_16_19  connected_order_arc_1391  -13
    arc_2_16_19  out_degree_1553  1
    arc_2_16_19  in_degree_1572  1
    arc_2_16_19  original_T_including_depot_unload_1592  1.3727638439182763e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_19  arc_capacity_1390  1
    load_2_16_19  free_load_conservation_1558  1
    load_2_16_19  free_load_conservation_1576  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_20  arc_capacity_1392  -30
    arc_2_16_20  connected_order_arc_1393  -13
    arc_2_16_20  out_degree_1553  1
    arc_2_16_20  in_degree_1578  1
    arc_2_16_20  original_T_including_depot_unload_1592  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_20  arc_capacity_1392  1
    load_2_16_20  free_load_conservation_1558  1
    load_2_16_20  free_load_conservation_1582  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_21  arc_capacity_1394  -30
    arc_2_16_21  connected_order_arc_1395  -13
    arc_2_16_21  out_degree_1553  1
    arc_2_16_21  in_degree_1584  1
    arc_2_16_21  original_T_including_depot_unload_1592  1.3163662834239574e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_21  arc_capacity_1394  1
    load_2_16_21  free_load_conservation_1558  1
    load_2_16_21  free_load_conservation_1588  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_0  arc_capacity_1396  -30
    arc_2_17_0  depot_return_or_bypass_1512  1
    arc_2_17_0  out_degree_1559  1
    arc_2_17_0  original_T_including_depot_unload_1592  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_0  arc_capacity_1396  1
    load_2_17_0  free_load_conservation_1564  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_10  arc_capacity_1397  -30
    arc_2_17_10  connected_order_arc_1398  -13
    arc_2_17_10  in_degree_1514  1
    arc_2_17_10  out_degree_1559  1
    arc_2_17_10  original_T_including_depot_unload_1592  8.0219422833177862e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_10  arc_capacity_1397  1
    load_2_17_10  segment_load_conservation_1517  -1
    load_2_17_10  segment_prefix_lb_1518  1
    load_2_17_10  segment_prefix_ub_1519  1
    load_2_17_10  free_load_conservation_1564  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_11  arc_capacity_1399  -30
    arc_2_17_11  connected_order_arc_1400  -13
    arc_2_17_11  in_degree_1521  1
    arc_2_17_11  out_degree_1559  1
    arc_2_17_11  original_T_including_depot_unload_1592  5.2472086221481925e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_11  arc_capacity_1399  1
    load_2_17_11  segment_load_conservation_1524  -1
    load_2_17_11  segment_prefix_lb_1525  1
    load_2_17_11  segment_prefix_ub_1526  1
    load_2_17_11  free_load_conservation_1564  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_12  arc_capacity_1401  -30
    arc_2_17_12  connected_order_arc_1402  -13
    arc_2_17_12  in_degree_1528  1
    arc_2_17_12  out_degree_1559  1
    arc_2_17_12  original_T_including_depot_unload_1592  1.4688211749637876e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_12  arc_capacity_1401  1
    load_2_17_12  segment_load_conservation_1531  -1
    load_2_17_12  segment_prefix_lb_1532  1
    load_2_17_12  segment_prefix_ub_1533  1
    load_2_17_12  free_load_conservation_1564  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_13  arc_capacity_1403  -30
    arc_2_17_13  connected_order_arc_1404  -13
    arc_2_17_13  in_degree_1535  1
    arc_2_17_13  out_degree_1559  1
    arc_2_17_13  original_T_including_depot_unload_1592  6.3111682574558915e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_13  arc_capacity_1403  1
    load_2_17_13  segment_load_conservation_1538  -1
    load_2_17_13  segment_prefix_lb_1539  1
    load_2_17_13  segment_prefix_ub_1540  1
    load_2_17_13  free_load_conservation_1564  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_14  arc_capacity_1405  -30
    arc_2_17_14  connected_order_arc_1406  -13
    arc_2_17_14  in_degree_1542  1
    arc_2_17_14  out_degree_1559  1
    arc_2_17_14  original_T_including_depot_unload_1592  2.6602972191926557e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_14  arc_capacity_1405  1
    load_2_17_14  free_load_conservation_1546  -1
    load_2_17_14  free_load_conservation_1564  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_15  arc_capacity_1407  -30
    arc_2_17_15  connected_order_arc_1408  -13
    arc_2_17_15  in_degree_1548  1
    arc_2_17_15  out_degree_1559  1
    arc_2_17_15  original_T_including_depot_unload_1592  5.0315495126439691e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_15  arc_capacity_1407  1
    load_2_17_15  free_load_conservation_1552  -1
    load_2_17_15  free_load_conservation_1564  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_16  arc_capacity_1409  -30
    arc_2_17_16  connected_order_arc_1410  -13
    arc_2_17_16  in_degree_1554  1
    arc_2_17_16  out_degree_1559  1
    arc_2_17_16  original_T_including_depot_unload_1592  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_16  arc_capacity_1409  1
    load_2_17_16  free_load_conservation_1558  -1
    load_2_17_16  free_load_conservation_1564  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_18  arc_capacity_1411  -30
    arc_2_17_18  connected_order_arc_1412  -13
    arc_2_17_18  out_degree_1559  1
    arc_2_17_18  in_degree_1566  1
    arc_2_17_18  original_T_including_depot_unload_1592  1.3127274783157229e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_18  arc_capacity_1411  1
    load_2_17_18  free_load_conservation_1564  1
    load_2_17_18  free_load_conservation_1570  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_19  arc_capacity_1413  -30
    arc_2_17_19  connected_order_arc_1414  -13
    arc_2_17_19  out_degree_1559  1
    arc_2_17_19  in_degree_1572  1
    arc_2_17_19  original_T_including_depot_unload_1592  3.9766425523492148e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_19  arc_capacity_1413  1
    load_2_17_19  free_load_conservation_1564  1
    load_2_17_19  free_load_conservation_1576  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_20  arc_capacity_1415  -30
    arc_2_17_20  connected_order_arc_1416  -13
    arc_2_17_20  out_degree_1559  1
    arc_2_17_20  in_degree_1578  1
    arc_2_17_20  original_T_including_depot_unload_1592  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_20  arc_capacity_1415  1
    load_2_17_20  free_load_conservation_1564  1
    load_2_17_20  free_load_conservation_1582  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_21  arc_capacity_1417  -30
    arc_2_17_21  connected_order_arc_1418  -13
    arc_2_17_21  out_degree_1559  1
    arc_2_17_21  in_degree_1584  1
    arc_2_17_21  original_T_including_depot_unload_1592  2.3059951477332697e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_21  arc_capacity_1417  1
    load_2_17_21  free_load_conservation_1564  1
    load_2_17_21  free_load_conservation_1588  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_0  arc_capacity_1419  -30
    arc_2_18_0  depot_return_or_bypass_1512  1
    arc_2_18_0  out_degree_1565  1
    arc_2_18_0  original_T_including_depot_unload_1592  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_0  arc_capacity_1419  1
    load_2_18_0  free_load_conservation_1570  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_10  arc_capacity_1420  -30
    arc_2_18_10  connected_order_arc_1421  -13
    arc_2_18_10  in_degree_1514  1
    arc_2_18_10  out_degree_1565  1
    arc_2_18_10  original_T_including_depot_unload_1592  2.0178882184947397e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_10  arc_capacity_1420  1
    load_2_18_10  segment_load_conservation_1517  -1
    load_2_18_10  segment_prefix_lb_1518  1
    load_2_18_10  segment_prefix_ub_1519  1
    load_2_18_10  free_load_conservation_1570  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_11  arc_capacity_1422  -30
    arc_2_18_11  connected_order_arc_1423  -13
    arc_2_18_11  in_degree_1521  1
    arc_2_18_11  out_degree_1565  1
    arc_2_18_11  original_T_including_depot_unload_1592  1.8362893893653638e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_11  arc_capacity_1422  1
    load_2_18_11  segment_load_conservation_1524  -1
    load_2_18_11  segment_prefix_lb_1525  1
    load_2_18_11  segment_prefix_ub_1526  1
    load_2_18_11  free_load_conservation_1570  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_12  arc_capacity_1424  -30
    arc_2_18_12  connected_order_arc_1425  -13
    arc_2_18_12  in_degree_1528  1
    arc_2_18_12  out_degree_1565  1
    arc_2_18_12  original_T_including_depot_unload_1592  1.6906177970488723e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_12  arc_capacity_1424  1
    load_2_18_12  segment_load_conservation_1531  -1
    load_2_18_12  segment_prefix_lb_1532  1
    load_2_18_12  segment_prefix_ub_1533  1
    load_2_18_12  free_load_conservation_1570  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_13  arc_capacity_1426  -30
    arc_2_18_13  connected_order_arc_1427  -13
    arc_2_18_13  in_degree_1535  1
    arc_2_18_13  out_degree_1565  1
    arc_2_18_13  original_T_including_depot_unload_1592  8.7684829846426385e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_13  arc_capacity_1426  1
    load_2_18_13  segment_load_conservation_1538  -1
    load_2_18_13  segment_prefix_lb_1539  1
    load_2_18_13  segment_prefix_ub_1540  1
    load_2_18_13  free_load_conservation_1570  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_14  arc_capacity_1428  -30
    arc_2_18_14  connected_order_arc_1429  -13
    arc_2_18_14  in_degree_1542  1
    arc_2_18_14  out_degree_1565  1
    arc_2_18_14  original_T_including_depot_unload_1592  1.0491196843462671e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_14  arc_capacity_1428  1
    load_2_18_14  free_load_conservation_1546  -1
    load_2_18_14  free_load_conservation_1570  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_15  arc_capacity_1430  -30
    arc_2_18_15  connected_order_arc_1431  -13
    arc_2_18_15  in_degree_1548  1
    arc_2_18_15  out_degree_1565  1
    arc_2_18_15  original_T_including_depot_unload_1592  8.3486971116736720e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_15  arc_capacity_1430  1
    load_2_18_15  free_load_conservation_1552  -1
    load_2_18_15  free_load_conservation_1570  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_16  arc_capacity_1432  -30
    arc_2_18_16  connected_order_arc_1433  -13
    arc_2_18_16  in_degree_1554  1
    arc_2_18_16  out_degree_1565  1
    arc_2_18_16  original_T_including_depot_unload_1592  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_16  arc_capacity_1432  1
    load_2_18_16  free_load_conservation_1558  -1
    load_2_18_16  free_load_conservation_1570  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_17  arc_capacity_1434  -30
    arc_2_18_17  connected_order_arc_1435  -13
    arc_2_18_17  in_degree_1560  1
    arc_2_18_17  out_degree_1565  1
    arc_2_18_17  original_T_including_depot_unload_1592  1.3127274783157229e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_17  arc_capacity_1434  1
    load_2_18_17  free_load_conservation_1564  -1
    load_2_18_17  free_load_conservation_1570  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_19  arc_capacity_1436  -30
    arc_2_18_19  connected_order_arc_1437  -13
    arc_2_18_19  out_degree_1565  1
    arc_2_18_19  in_degree_1572  1
    arc_2_18_19  original_T_including_depot_unload_1592  1.1341050580477483e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_19  arc_capacity_1436  1
    load_2_18_19  free_load_conservation_1570  1
    load_2_18_19  free_load_conservation_1576  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_20  arc_capacity_1438  -30
    arc_2_18_20  connected_order_arc_1439  -13
    arc_2_18_20  out_degree_1565  1
    arc_2_18_20  in_degree_1578  1
    arc_2_18_20  original_T_including_depot_unload_1592  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_20  arc_capacity_1438  1
    load_2_18_20  free_load_conservation_1570  1
    load_2_18_20  free_load_conservation_1582  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_21  arc_capacity_1440  -30
    arc_2_18_21  connected_order_arc_1441  -13
    arc_2_18_21  out_degree_1565  1
    arc_2_18_21  in_degree_1584  1
    arc_2_18_21  original_T_including_depot_unload_1592  1.2968499029957554e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_21  arc_capacity_1440  1
    load_2_18_21  free_load_conservation_1570  1
    load_2_18_21  free_load_conservation_1588  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_0  arc_capacity_1442  -30
    arc_2_19_0  depot_return_or_bypass_1512  1
    arc_2_19_0  out_degree_1571  1
    arc_2_19_0  original_T_including_depot_unload_1592  5.9431738885389052e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_0  arc_capacity_1442  1
    load_2_19_0  free_load_conservation_1576  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_10  arc_capacity_1443  -30
    arc_2_19_10  connected_order_arc_1444  -13
    arc_2_19_10  in_degree_1514  1
    arc_2_19_10  out_degree_1571  1
    arc_2_19_10  original_T_including_depot_unload_1592  1.1848225970179703e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_10  arc_capacity_1443  1
    load_2_19_10  segment_load_conservation_1517  -1
    load_2_19_10  segment_prefix_lb_1518  1
    load_2_19_10  segment_prefix_ub_1519  1
    load_2_19_10  free_load_conservation_1576  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_11  arc_capacity_1445  -30
    arc_2_19_11  connected_order_arc_1446  -13
    arc_2_19_11  in_degree_1521  1
    arc_2_19_11  out_degree_1571  1
    arc_2_19_11  original_T_including_depot_unload_1592  8.0231446125927152e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_11  arc_capacity_1445  1
    load_2_19_11  segment_load_conservation_1524  -1
    load_2_19_11  segment_prefix_lb_1525  1
    load_2_19_11  segment_prefix_ub_1526  1
    load_2_19_11  free_load_conservation_1576  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_12  arc_capacity_1447  -30
    arc_2_19_12  connected_order_arc_1448  -13
    arc_2_19_12  in_degree_1528  1
    arc_2_19_12  out_degree_1571  1
    arc_2_19_12  original_T_including_depot_unload_1592  1.1016218375294079e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_12  arc_capacity_1447  1
    load_2_19_12  segment_load_conservation_1531  -1
    load_2_19_12  segment_prefix_lb_1532  1
    load_2_19_12  segment_prefix_ub_1533  1
    load_2_19_12  free_load_conservation_1576  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_13  arc_capacity_1449  -30
    arc_2_19_13  connected_order_arc_1450  -13
    arc_2_19_13  in_degree_1535  1
    arc_2_19_13  out_degree_1571  1
    arc_2_19_13  original_T_including_depot_unload_1592  2.9098466309579254e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_13  arc_capacity_1449  1
    load_2_19_13  segment_load_conservation_1538  -1
    load_2_19_13  segment_prefix_lb_1539  1
    load_2_19_13  segment_prefix_ub_1540  1
    load_2_19_13  free_load_conservation_1576  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_14  arc_capacity_1451  -30
    arc_2_19_14  connected_order_arc_1452  -13
    arc_2_19_14  in_degree_1542  1
    arc_2_19_14  out_degree_1571  1
    arc_2_19_14  original_T_including_depot_unload_1592  2.9706418113632907e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_14  arc_capacity_1451  1
    load_2_19_14  free_load_conservation_1546  -1
    load_2_19_14  free_load_conservation_1576  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_15  arc_capacity_1453  -30
    arc_2_19_15  connected_order_arc_1454  -13
    arc_2_19_15  in_degree_1548  1
    arc_2_19_15  out_degree_1571  1
    arc_2_19_15  original_T_including_depot_unload_1592  3.2938591738444967e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_15  arc_capacity_1453  1
    load_2_19_15  free_load_conservation_1552  -1
    load_2_19_15  free_load_conservation_1576  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_16  arc_capacity_1455  -30
    arc_2_19_16  connected_order_arc_1456  -13
    arc_2_19_16  in_degree_1554  1
    arc_2_19_16  out_degree_1571  1
    arc_2_19_16  original_T_including_depot_unload_1592  1.3727638439182763e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_16  arc_capacity_1455  1
    load_2_19_16  free_load_conservation_1558  -1
    load_2_19_16  free_load_conservation_1576  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_17  arc_capacity_1457  -30
    arc_2_19_17  connected_order_arc_1458  -13
    arc_2_19_17  in_degree_1560  1
    arc_2_19_17  out_degree_1571  1
    arc_2_19_17  original_T_including_depot_unload_1592  3.9766425523492148e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_17  arc_capacity_1457  1
    load_2_19_17  free_load_conservation_1564  -1
    load_2_19_17  free_load_conservation_1576  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_18  arc_capacity_1459  -30
    arc_2_19_18  connected_order_arc_1460  -13
    arc_2_19_18  in_degree_1566  1
    arc_2_19_18  out_degree_1571  1
    arc_2_19_18  original_T_including_depot_unload_1592  1.1341050580477483e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_18  arc_capacity_1459  1
    load_2_19_18  free_load_conservation_1570  -1
    load_2_19_18  free_load_conservation_1576  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_20  arc_capacity_1461  -30
    arc_2_19_20  connected_order_arc_1462  -13
    arc_2_19_20  out_degree_1571  1
    arc_2_19_20  in_degree_1578  1
    arc_2_19_20  original_T_including_depot_unload_1592  9.8652191996938075e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_20  arc_capacity_1461  1
    load_2_19_20  free_load_conservation_1576  1
    load_2_19_20  free_load_conservation_1582  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_21  arc_capacity_1463  -30
    arc_2_19_21  connected_order_arc_1464  -13
    arc_2_19_21  out_degree_1571  1
    arc_2_19_21  in_degree_1584  1
    arc_2_19_21  original_T_including_depot_unload_1592  2.1481294511470344e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_21  arc_capacity_1463  1
    load_2_19_21  free_load_conservation_1576  1
    load_2_19_21  free_load_conservation_1588  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_0  arc_capacity_1465  -30
    arc_2_20_0  depot_return_or_bypass_1512  1
    arc_2_20_0  out_degree_1577  1
    arc_2_20_0  original_T_including_depot_unload_1592  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_0  arc_capacity_1465  1
    load_2_20_0  free_load_conservation_1582  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_10  arc_capacity_1466  -30
    arc_2_20_10  connected_order_arc_1467  -13
    arc_2_20_10  in_degree_1514  1
    arc_2_20_10  out_degree_1577  1
    arc_2_20_10  original_T_including_depot_unload_1592  3.1118349756671438e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_10  arc_capacity_1466  1
    load_2_20_10  segment_load_conservation_1517  -1
    load_2_20_10  segment_prefix_lb_1518  1
    load_2_20_10  segment_prefix_ub_1519  1
    load_2_20_10  free_load_conservation_1582  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_11  arc_capacity_1468  -30
    arc_2_20_11  connected_order_arc_1469  -13
    arc_2_20_11  in_degree_1521  1
    arc_2_20_11  out_degree_1577  1
    arc_2_20_11  original_T_including_depot_unload_1592  2.2865444230199981e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_11  arc_capacity_1468  1
    load_2_20_11  segment_load_conservation_1524  -1
    load_2_20_11  segment_prefix_lb_1525  1
    load_2_20_11  segment_prefix_ub_1526  1
    load_2_20_11  free_load_conservation_1582  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_12  arc_capacity_1470  -30
    arc_2_20_12  connected_order_arc_1471  -13
    arc_2_20_12  in_degree_1528  1
    arc_2_20_12  out_degree_1577  1
    arc_2_20_12  original_T_including_depot_unload_1592  1.8780729343410642e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_12  arc_capacity_1470  1
    load_2_20_12  segment_load_conservation_1531  -1
    load_2_20_12  segment_prefix_lb_1532  1
    load_2_20_12  segment_prefix_ub_1533  1
    load_2_20_12  free_load_conservation_1582  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_13  arc_capacity_1472  -30
    arc_2_20_13  connected_order_arc_1473  -13
    arc_2_20_13  in_degree_1535  1
    arc_2_20_13  out_degree_1577  1
    arc_2_20_13  original_T_including_depot_unload_1592  1.2608612406747543e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_13  arc_capacity_1472  1
    load_2_20_13  segment_load_conservation_1538  -1
    load_2_20_13  segment_prefix_lb_1539  1
    load_2_20_13  segment_prefix_ub_1540  1
    load_2_20_13  free_load_conservation_1582  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_14  arc_capacity_1474  -30
    arc_2_20_14  connected_order_arc_1475  -13
    arc_2_20_14  in_degree_1542  1
    arc_2_20_14  out_degree_1577  1
    arc_2_20_14  original_T_including_depot_unload_1592  9.1576870176747968e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_14  arc_capacity_1474  1
    load_2_20_14  free_load_conservation_1546  -1
    load_2_20_14  free_load_conservation_1582  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_15  arc_capacity_1476  -30
    arc_2_20_15  connected_order_arc_1477  -13
    arc_2_20_15  in_degree_1548  1
    arc_2_20_15  out_degree_1577  1
    arc_2_20_15  original_T_including_depot_unload_1592  1.1544376314422677e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_15  arc_capacity_1476  1
    load_2_20_15  free_load_conservation_1552  -1
    load_2_20_15  free_load_conservation_1582  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_16  arc_capacity_1478  -30
    arc_2_20_16  connected_order_arc_1479  -13
    arc_2_20_16  in_degree_1554  1
    arc_2_20_16  out_degree_1577  1
    arc_2_20_16  original_T_including_depot_unload_1592  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_16  arc_capacity_1478  1
    load_2_20_16  free_load_conservation_1558  -1
    load_2_20_16  free_load_conservation_1582  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_17  arc_capacity_1480  -30
    arc_2_20_17  connected_order_arc_1481  -13
    arc_2_20_17  in_degree_1560  1
    arc_2_20_17  out_degree_1577  1
    arc_2_20_17  original_T_including_depot_unload_1592  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_17  arc_capacity_1480  1
    load_2_20_17  free_load_conservation_1564  -1
    load_2_20_17  free_load_conservation_1582  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_18  arc_capacity_1482  -30
    arc_2_20_18  connected_order_arc_1483  -13
    arc_2_20_18  in_degree_1566  1
    arc_2_20_18  out_degree_1577  1
    arc_2_20_18  original_T_including_depot_unload_1592  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_18  arc_capacity_1482  1
    load_2_20_18  free_load_conservation_1570  -1
    load_2_20_18  free_load_conservation_1582  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_19  arc_capacity_1484  -30
    arc_2_20_19  connected_order_arc_1485  -13
    arc_2_20_19  in_degree_1572  1
    arc_2_20_19  out_degree_1577  1
    arc_2_20_19  original_T_including_depot_unload_1592  9.8652191996938075e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_19  arc_capacity_1484  1
    load_2_20_19  free_load_conservation_1576  -1
    load_2_20_19  free_load_conservation_1582  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_21  arc_capacity_1486  -30
    arc_2_20_21  connected_order_arc_1487  -13
    arc_2_20_21  out_degree_1577  1
    arc_2_20_21  in_degree_1584  1
    arc_2_20_21  original_T_including_depot_unload_1592  7.7190219995954919e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_21  arc_capacity_1486  1
    load_2_20_21  free_load_conservation_1582  1
    load_2_20_21  free_load_conservation_1588  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_0  arc_capacity_1488  -30
    arc_2_21_0  depot_return_or_bypass_1512  1
    arc_2_21_0  out_degree_1583  1
    arc_2_21_0  original_T_including_depot_unload_1592  7.2571167924583824e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_0  arc_capacity_1488  1
    load_2_21_0  free_load_conservation_1588  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_10  arc_capacity_1489  -30
    arc_2_21_10  connected_order_arc_1490  -13
    arc_2_21_10  in_degree_1514  1
    arc_2_21_10  out_degree_1583  1
    arc_2_21_10  original_T_including_depot_unload_1592  9.7877495286142823e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_10  arc_capacity_1489  1
    load_2_21_10  segment_load_conservation_1517  -1
    load_2_21_10  segment_prefix_lb_1518  1
    load_2_21_10  segment_prefix_ub_1519  1
    load_2_21_10  free_load_conservation_1588  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_11  arc_capacity_1491  -30
    arc_2_21_11  connected_order_arc_1492  -13
    arc_2_21_11  in_degree_1521  1
    arc_2_21_11  out_degree_1583  1
    arc_2_21_11  original_T_including_depot_unload_1592  5.8943244236516807e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_11  arc_capacity_1491  1
    load_2_21_11  segment_load_conservation_1524  -1
    load_2_21_11  segment_prefix_lb_1525  1
    load_2_21_11  segment_prefix_ub_1526  1
    load_2_21_11  free_load_conservation_1588  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_12  arc_capacity_1493  -30
    arc_2_21_12  connected_order_arc_1494  -13
    arc_2_21_12  in_degree_1528  1
    arc_2_21_12  out_degree_1583  1
    arc_2_21_12  original_T_including_depot_unload_1592  1.2399174881238241e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_12  arc_capacity_1493  1
    load_2_21_12  segment_load_conservation_1531  -1
    load_2_21_12  segment_prefix_lb_1532  1
    load_2_21_12  segment_prefix_ub_1533  1
    load_2_21_12  free_load_conservation_1588  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_13  arc_capacity_1495  -30
    arc_2_21_13  connected_order_arc_1496  -13
    arc_2_21_13  in_degree_1535  1
    arc_2_21_13  out_degree_1583  1
    arc_2_21_13  original_T_including_depot_unload_1592  4.9831220386775891e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_13  arc_capacity_1495  1
    load_2_21_13  segment_load_conservation_1538  -1
    load_2_21_13  segment_prefix_lb_1539  1
    load_2_21_13  segment_prefix_ub_1540  1
    load_2_21_13  free_load_conservation_1588  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_14  arc_capacity_1497  -30
    arc_2_21_14  connected_order_arc_1498  -13
    arc_2_21_14  in_degree_1542  1
    arc_2_21_14  out_degree_1583  1
    arc_2_21_14  original_T_including_depot_unload_1592  3.0055050459786975e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_14  arc_capacity_1497  1
    load_2_21_14  free_load_conservation_1546  -1
    load_2_21_14  free_load_conservation_1588  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_15  arc_capacity_1499  -30
    arc_2_21_15  connected_order_arc_1500  -13
    arc_2_21_15  in_degree_1548  1
    arc_2_21_15  out_degree_1583  1
    arc_2_21_15  original_T_including_depot_unload_1592  4.6276703023336785e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_15  arc_capacity_1499  1
    load_2_21_15  free_load_conservation_1552  -1
    load_2_21_15  free_load_conservation_1588  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_16  arc_capacity_1501  -30
    arc_2_21_16  connected_order_arc_1502  -13
    arc_2_21_16  in_degree_1554  1
    arc_2_21_16  out_degree_1583  1
    arc_2_21_16  original_T_including_depot_unload_1592  1.3163662834239574e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_16  arc_capacity_1501  1
    load_2_21_16  free_load_conservation_1558  -1
    load_2_21_16  free_load_conservation_1588  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_17  arc_capacity_1503  -30
    arc_2_21_17  connected_order_arc_1504  -13
    arc_2_21_17  in_degree_1560  1
    arc_2_21_17  out_degree_1583  1
    arc_2_21_17  original_T_including_depot_unload_1592  2.3059951477332697e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_17  arc_capacity_1503  1
    load_2_21_17  free_load_conservation_1564  -1
    load_2_21_17  free_load_conservation_1588  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_18  arc_capacity_1505  -30
    arc_2_21_18  connected_order_arc_1506  -13
    arc_2_21_18  in_degree_1566  1
    arc_2_21_18  out_degree_1583  1
    arc_2_21_18  original_T_including_depot_unload_1592  1.2968499029957554e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_18  arc_capacity_1505  1
    load_2_21_18  free_load_conservation_1570  -1
    load_2_21_18  free_load_conservation_1588  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_19  arc_capacity_1507  -30
    arc_2_21_19  connected_order_arc_1508  -13
    arc_2_21_19  in_degree_1572  1
    arc_2_21_19  out_degree_1583  1
    arc_2_21_19  original_T_including_depot_unload_1592  2.1481294511470344e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_19  arc_capacity_1507  1
    load_2_21_19  free_load_conservation_1576  -1
    load_2_21_19  free_load_conservation_1588  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_20  arc_capacity_1509  -30
    arc_2_21_20  connected_order_arc_1510  -13
    arc_2_21_20  in_degree_1578  1
    arc_2_21_20  out_degree_1583  1
    arc_2_21_20  original_T_including_depot_unload_1592  7.7190219995954919e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_20  arc_capacity_1509  1
    load_2_21_20  free_load_conservation_1582  -1
    load_2_21_20  free_load_conservation_1588  1
RHS
    RHS1      OBJ       -5.4375000000000007e-01
    RHS1      onehot_15_34  1
    RHS1      onehot_9_63  1
    RHS1      onehot_31_92  1
    RHS1      onehot_19_113  1
    RHS1      onehot_16_142  1
    RHS1      onehot_13_185  1
    RHS1      onehot_32_214  1
    RHS1      onehot_17_251  1
    RHS1      stock_ub_255  38
    RHS1      parent_nonstrict_scope_256  2.8354506565812565e-01
    RHS1      normalization_313  1
    RHS1      connected_order_arc_437  -12
    RHS1      connected_order_arc_439  -12
    RHS1      connected_order_arc_441  -12
    RHS1      connected_order_arc_443  -12
    RHS1      connected_order_arc_445  -12
    RHS1      connected_order_arc_447  -12
    RHS1      connected_order_arc_449  -12
    RHS1      connected_order_arc_451  -12
    RHS1      connected_order_arc_453  -12
    RHS1      connected_order_arc_455  -12
    RHS1      connected_order_arc_457  -12
    RHS1      connected_order_arc_460  -12
    RHS1      connected_order_arc_462  -12
    RHS1      connected_order_arc_464  -12
    RHS1      connected_order_arc_466  -12
    RHS1      connected_order_arc_468  -12
    RHS1      connected_order_arc_470  -12
    RHS1      connected_order_arc_472  -12
    RHS1      connected_order_arc_474  -12
    RHS1      connected_order_arc_476  -12
    RHS1      connected_order_arc_478  -12
    RHS1      connected_order_arc_480  -12
    RHS1      connected_order_arc_483  -12
    RHS1      connected_order_arc_485  -12
    RHS1      connected_order_arc_487  -12
    RHS1      connected_order_arc_489  -12
    RHS1      connected_order_arc_491  -12
    RHS1      connected_order_arc_493  -12
    RHS1      connected_order_arc_495  -12
    RHS1      connected_order_arc_497  -12
    RHS1      connected_order_arc_499  -12
    RHS1      connected_order_arc_501  -12
    RHS1      connected_order_arc_503  -12
    RHS1      connected_order_arc_506  -12
    RHS1      connected_order_arc_508  -12
    RHS1      connected_order_arc_510  -12
    RHS1      connected_order_arc_512  -12
    RHS1      connected_order_arc_514  -12
    RHS1      connected_order_arc_516  -12
    RHS1      connected_order_arc_518  -12
    RHS1      connected_order_arc_520  -12
    RHS1      connected_order_arc_522  -12
    RHS1      connected_order_arc_524  -12
    RHS1      connected_order_arc_526  -12
    RHS1      connected_order_arc_529  -12
    RHS1      connected_order_arc_531  -12
    RHS1      connected_order_arc_533  -12
    RHS1      connected_order_arc_535  -12
    RHS1      connected_order_arc_537  -12
    RHS1      connected_order_arc_539  -12
    RHS1      connected_order_arc_541  -12
    RHS1      connected_order_arc_543  -12
    RHS1      connected_order_arc_545  -12
    RHS1      connected_order_arc_547  -12
    RHS1      connected_order_arc_549  -12
    RHS1      connected_order_arc_552  -12
    RHS1      connected_order_arc_554  -12
    RHS1      connected_order_arc_556  -12
    RHS1      connected_order_arc_558  -12
    RHS1      connected_order_arc_560  -12
    RHS1      connected_order_arc_562  -12
    RHS1      connected_order_arc_564  -12
    RHS1      connected_order_arc_566  -12
    RHS1      connected_order_arc_568  -12
    RHS1      connected_order_arc_570  -12
    RHS1      connected_order_arc_572  -12
    RHS1      connected_order_arc_575  -12
    RHS1      connected_order_arc_577  -12
    RHS1      connected_order_arc_579  -12
    RHS1      connected_order_arc_581  -12
    RHS1      connected_order_arc_583  -12
    RHS1      connected_order_arc_585  -12
    RHS1      connected_order_arc_587  -12
    RHS1      connected_order_arc_589  -12
    RHS1      connected_order_arc_591  -12
    RHS1      connected_order_arc_593  -12
    RHS1      connected_order_arc_595  -12
    RHS1      connected_order_arc_598  -12
    RHS1      connected_order_arc_600  -12
    RHS1      connected_order_arc_602  -12
    RHS1      connected_order_arc_604  -12
    RHS1      connected_order_arc_606  -12
    RHS1      connected_order_arc_608  -12
    RHS1      connected_order_arc_610  -12
    RHS1      connected_order_arc_612  -12
    RHS1      connected_order_arc_614  -12
    RHS1      connected_order_arc_616  -12
    RHS1      connected_order_arc_618  -12
    RHS1      connected_order_arc_621  -12
    RHS1      connected_order_arc_623  -12
    RHS1      connected_order_arc_625  -12
    RHS1      connected_order_arc_627  -12
    RHS1      connected_order_arc_629  -12
    RHS1      connected_order_arc_631  -12
    RHS1      connected_order_arc_633  -12
    RHS1      connected_order_arc_635  -12
    RHS1      connected_order_arc_637  -12
    RHS1      connected_order_arc_639  -12
    RHS1      connected_order_arc_641  -12
    RHS1      connected_order_arc_644  -12
    RHS1      connected_order_arc_646  -12
    RHS1      connected_order_arc_648  -12
    RHS1      connected_order_arc_650  -12
    RHS1      connected_order_arc_652  -12
    RHS1      connected_order_arc_654  -12
    RHS1      connected_order_arc_656  -12
    RHS1      connected_order_arc_658  -12
    RHS1      connected_order_arc_660  -12
    RHS1      connected_order_arc_662  -12
    RHS1      connected_order_arc_664  -12
    RHS1      connected_order_arc_667  -12
    RHS1      connected_order_arc_669  -12
    RHS1      connected_order_arc_671  -12
    RHS1      connected_order_arc_673  -12
    RHS1      connected_order_arc_675  -12
    RHS1      connected_order_arc_677  -12
    RHS1      connected_order_arc_679  -12
    RHS1      connected_order_arc_681  -12
    RHS1      connected_order_arc_683  -12
    RHS1      connected_order_arc_685  -12
    RHS1      connected_order_arc_687  -12
    RHS1      connected_order_arc_690  -12
    RHS1      connected_order_arc_692  -12
    RHS1      connected_order_arc_694  -12
    RHS1      connected_order_arc_696  -12
    RHS1      connected_order_arc_698  -12
    RHS1      connected_order_arc_700  -12
    RHS1      connected_order_arc_702  -12
    RHS1      connected_order_arc_704  -12
    RHS1      connected_order_arc_706  -12
    RHS1      connected_order_arc_708  -12
    RHS1      connected_order_arc_710  -12
    RHS1      depot_departure_or_bypass_711  1
    RHS1      depot_return_or_bypass_712  1
    RHS1      segment_load_conservation_717  5
    RHS1      segment_prefix_ub_719  15
    RHS1      segment_load_conservation_724  5
    RHS1      segment_prefix_ub_726  15
    RHS1      segment_load_conservation_731  -8
    RHS1      segment_prefix_lb_732  8
    RHS1      segment_prefix_ub_733  12
    RHS1      segment_load_conservation_738  5
    RHS1      segment_prefix_ub_740  15
    RHS1      fixed_segment_relative_order_789  1
    RHS1      fixed_segment_relative_order_790  1
    RHS1      fixed_segment_relative_order_791  1
    RHS1      original_T_including_depot_unload_792  3.4233852296591995e+03
    RHS1      connected_order_arc_809  -13
    RHS1      connected_order_arc_811  -13
    RHS1      connected_order_arc_813  -13
    RHS1      connected_order_arc_815  -13
    RHS1      connected_order_arc_817  -13
    RHS1      connected_order_arc_819  -13
    RHS1      connected_order_arc_821  -13
    RHS1      connected_order_arc_823  -13
    RHS1      connected_order_arc_825  -13
    RHS1      connected_order_arc_827  -13
    RHS1      connected_order_arc_829  -13
    RHS1      connected_order_arc_831  -13
    RHS1      connected_order_arc_834  -13
    RHS1      connected_order_arc_836  -13
    RHS1      connected_order_arc_838  -13
    RHS1      connected_order_arc_840  -13
    RHS1      connected_order_arc_842  -13
    RHS1      connected_order_arc_844  -13
    RHS1      connected_order_arc_846  -13
    RHS1      connected_order_arc_848  -13
    RHS1      connected_order_arc_850  -13
    RHS1      connected_order_arc_852  -13
    RHS1      connected_order_arc_854  -13
    RHS1      connected_order_arc_856  -13
    RHS1      connected_order_arc_859  -13
    RHS1      connected_order_arc_861  -13
    RHS1      connected_order_arc_863  -13
    RHS1      connected_order_arc_865  -13
    RHS1      connected_order_arc_867  -13
    RHS1      connected_order_arc_869  -13
    RHS1      connected_order_arc_871  -13
    RHS1      connected_order_arc_873  -13
    RHS1      connected_order_arc_875  -13
    RHS1      connected_order_arc_877  -13
    RHS1      connected_order_arc_879  -13
    RHS1      connected_order_arc_881  -13
    RHS1      connected_order_arc_884  -13
    RHS1      connected_order_arc_886  -13
    RHS1      connected_order_arc_888  -13
    RHS1      connected_order_arc_890  -13
    RHS1      connected_order_arc_892  -13
    RHS1      connected_order_arc_894  -13
    RHS1      connected_order_arc_896  -13
    RHS1      connected_order_arc_898  -13
    RHS1      connected_order_arc_900  -13
    RHS1      connected_order_arc_902  -13
    RHS1      connected_order_arc_904  -13
    RHS1      connected_order_arc_906  -13
    RHS1      connected_order_arc_909  -13
    RHS1      connected_order_arc_911  -13
    RHS1      connected_order_arc_913  -13
    RHS1      connected_order_arc_915  -13
    RHS1      connected_order_arc_917  -13
    RHS1      connected_order_arc_919  -13
    RHS1      connected_order_arc_921  -13
    RHS1      connected_order_arc_923  -13
    RHS1      connected_order_arc_925  -13
    RHS1      connected_order_arc_927  -13
    RHS1      connected_order_arc_929  -13
    RHS1      connected_order_arc_931  -13
    RHS1      connected_order_arc_934  -13
    RHS1      connected_order_arc_936  -13
    RHS1      connected_order_arc_938  -13
    RHS1      connected_order_arc_940  -13
    RHS1      connected_order_arc_942  -13
    RHS1      connected_order_arc_944  -13
    RHS1      connected_order_arc_946  -13
    RHS1      connected_order_arc_948  -13
    RHS1      connected_order_arc_950  -13
    RHS1      connected_order_arc_952  -13
    RHS1      connected_order_arc_954  -13
    RHS1      connected_order_arc_956  -13
    RHS1      connected_order_arc_959  -13
    RHS1      connected_order_arc_961  -13
    RHS1      connected_order_arc_963  -13
    RHS1      connected_order_arc_965  -13
    RHS1      connected_order_arc_967  -13
    RHS1      connected_order_arc_969  -13
    RHS1      connected_order_arc_971  -13
    RHS1      connected_order_arc_973  -13
    RHS1      connected_order_arc_975  -13
    RHS1      connected_order_arc_977  -13
    RHS1      connected_order_arc_979  -13
    RHS1      connected_order_arc_981  -13
    RHS1      connected_order_arc_984  -13
    RHS1      connected_order_arc_986  -13
    RHS1      connected_order_arc_988  -13
    RHS1      connected_order_arc_990  -13
    RHS1      connected_order_arc_992  -13
    RHS1      connected_order_arc_994  -13
    RHS1      connected_order_arc_996  -13
    RHS1      connected_order_arc_998  -13
    RHS1      connected_order_arc_1000  -13
    RHS1      connected_order_arc_1002  -13
    RHS1      connected_order_arc_1004  -13
    RHS1      connected_order_arc_1006  -13
    RHS1      connected_order_arc_1009  -13
    RHS1      connected_order_arc_1011  -13
    RHS1      connected_order_arc_1013  -13
    RHS1      connected_order_arc_1015  -13
    RHS1      connected_order_arc_1017  -13
    RHS1      connected_order_arc_1019  -13
    RHS1      connected_order_arc_1021  -13
    RHS1      connected_order_arc_1023  -13
    RHS1      connected_order_arc_1025  -13
    RHS1      connected_order_arc_1027  -13
    RHS1      connected_order_arc_1029  -13
    RHS1      connected_order_arc_1031  -13
    RHS1      connected_order_arc_1034  -13
    RHS1      connected_order_arc_1036  -13
    RHS1      connected_order_arc_1038  -13
    RHS1      connected_order_arc_1040  -13
    RHS1      connected_order_arc_1042  -13
    RHS1      connected_order_arc_1044  -13
    RHS1      connected_order_arc_1046  -13
    RHS1      connected_order_arc_1048  -13
    RHS1      connected_order_arc_1050  -13
    RHS1      connected_order_arc_1052  -13
    RHS1      connected_order_arc_1054  -13
    RHS1      connected_order_arc_1056  -13
    RHS1      connected_order_arc_1059  -13
    RHS1      connected_order_arc_1061  -13
    RHS1      connected_order_arc_1063  -13
    RHS1      connected_order_arc_1065  -13
    RHS1      connected_order_arc_1067  -13
    RHS1      connected_order_arc_1069  -13
    RHS1      connected_order_arc_1071  -13
    RHS1      connected_order_arc_1073  -13
    RHS1      connected_order_arc_1075  -13
    RHS1      connected_order_arc_1077  -13
    RHS1      connected_order_arc_1079  -13
    RHS1      connected_order_arc_1081  -13
    RHS1      connected_order_arc_1084  -13
    RHS1      connected_order_arc_1086  -13
    RHS1      connected_order_arc_1088  -13
    RHS1      connected_order_arc_1090  -13
    RHS1      connected_order_arc_1092  -13
    RHS1      connected_order_arc_1094  -13
    RHS1      connected_order_arc_1096  -13
    RHS1      connected_order_arc_1098  -13
    RHS1      connected_order_arc_1100  -13
    RHS1      connected_order_arc_1102  -13
    RHS1      connected_order_arc_1104  -13
    RHS1      connected_order_arc_1106  -13
    RHS1      connected_order_arc_1109  -13
    RHS1      connected_order_arc_1111  -13
    RHS1      connected_order_arc_1113  -13
    RHS1      connected_order_arc_1115  -13
    RHS1      connected_order_arc_1117  -13
    RHS1      connected_order_arc_1119  -13
    RHS1      connected_order_arc_1121  -13
    RHS1      connected_order_arc_1123  -13
    RHS1      connected_order_arc_1125  -13
    RHS1      connected_order_arc_1127  -13
    RHS1      connected_order_arc_1129  -13
    RHS1      connected_order_arc_1131  -13
    RHS1      depot_departure_or_bypass_1132  1
    RHS1      depot_return_or_bypass_1133  1
    RHS1      segment_load_conservation_1138  6
    RHS1      segment_prefix_ub_1140  19
    RHS1      segment_load_conservation_1145  -5
    RHS1      segment_prefix_lb_1146  6
    RHS1      segment_prefix_ub_1147  25
    RHS1      segment_load_conservation_1152  3
    RHS1      segment_prefix_ub_1154  22
    RHS1      segment_load_conservation_1159  3
    RHS1      segment_prefix_ub_1161  22
    RHS1      segment_load_conservation_1166  -5
    RHS1      segment_prefix_lb_1167  5
    RHS1      segment_prefix_ub_1168  25
    RHS1      fixed_segment_relative_order_1217  1
    RHS1      fixed_segment_relative_order_1218  1
    RHS1      fixed_segment_relative_order_1219  1
    RHS1      fixed_segment_relative_order_1220  1
    RHS1      original_T_including_depot_unload_1221  2.2933958320926176e+03
    RHS1      connected_order_arc_1237  -12
    RHS1      connected_order_arc_1239  -12
    RHS1      connected_order_arc_1241  -12
    RHS1      connected_order_arc_1243  -12
    RHS1      connected_order_arc_1245  -12
    RHS1      connected_order_arc_1247  -12
    RHS1      connected_order_arc_1249  -12
    RHS1      connected_order_arc_1251  -12
    RHS1      connected_order_arc_1253  -12
    RHS1      connected_order_arc_1255  -12
    RHS1      connected_order_arc_1257  -12
    RHS1      connected_order_arc_1260  -12
    RHS1      connected_order_arc_1262  -12
    RHS1      connected_order_arc_1264  -12
    RHS1      connected_order_arc_1266  -12
    RHS1      connected_order_arc_1268  -12
    RHS1      connected_order_arc_1270  -12
    RHS1      connected_order_arc_1272  -12
    RHS1      connected_order_arc_1274  -12
    RHS1      connected_order_arc_1276  -12
    RHS1      connected_order_arc_1278  -12
    RHS1      connected_order_arc_1280  -12
    RHS1      connected_order_arc_1283  -12
    RHS1      connected_order_arc_1285  -12
    RHS1      connected_order_arc_1287  -12
    RHS1      connected_order_arc_1289  -12
    RHS1      connected_order_arc_1291  -12
    RHS1      connected_order_arc_1293  -12
    RHS1      connected_order_arc_1295  -12
    RHS1      connected_order_arc_1297  -12
    RHS1      connected_order_arc_1299  -12
    RHS1      connected_order_arc_1301  -12
    RHS1      connected_order_arc_1303  -12
    RHS1      connected_order_arc_1306  -12
    RHS1      connected_order_arc_1308  -12
    RHS1      connected_order_arc_1310  -12
    RHS1      connected_order_arc_1312  -12
    RHS1      connected_order_arc_1314  -12
    RHS1      connected_order_arc_1316  -12
    RHS1      connected_order_arc_1318  -12
    RHS1      connected_order_arc_1320  -12
    RHS1      connected_order_arc_1322  -12
    RHS1      connected_order_arc_1324  -12
    RHS1      connected_order_arc_1326  -12
    RHS1      connected_order_arc_1329  -12
    RHS1      connected_order_arc_1331  -12
    RHS1      connected_order_arc_1333  -12
    RHS1      connected_order_arc_1335  -12
    RHS1      connected_order_arc_1337  -12
    RHS1      connected_order_arc_1339  -12
    RHS1      connected_order_arc_1341  -12
    RHS1      connected_order_arc_1343  -12
    RHS1      connected_order_arc_1345  -12
    RHS1      connected_order_arc_1347  -12
    RHS1      connected_order_arc_1349  -12
    RHS1      connected_order_arc_1352  -12
    RHS1      connected_order_arc_1354  -12
    RHS1      connected_order_arc_1356  -12
    RHS1      connected_order_arc_1358  -12
    RHS1      connected_order_arc_1360  -12
    RHS1      connected_order_arc_1362  -12
    RHS1      connected_order_arc_1364  -12
    RHS1      connected_order_arc_1366  -12
    RHS1      connected_order_arc_1368  -12
    RHS1      connected_order_arc_1370  -12
    RHS1      connected_order_arc_1372  -12
    RHS1      connected_order_arc_1375  -12
    RHS1      connected_order_arc_1377  -12
    RHS1      connected_order_arc_1379  -12
    RHS1      connected_order_arc_1381  -12
    RHS1      connected_order_arc_1383  -12
    RHS1      connected_order_arc_1385  -12
    RHS1      connected_order_arc_1387  -12
    RHS1      connected_order_arc_1389  -12
    RHS1      connected_order_arc_1391  -12
    RHS1      connected_order_arc_1393  -12
    RHS1      connected_order_arc_1395  -12
    RHS1      connected_order_arc_1398  -12
    RHS1      connected_order_arc_1400  -12
    RHS1      connected_order_arc_1402  -12
    RHS1      connected_order_arc_1404  -12
    RHS1      connected_order_arc_1406  -12
    RHS1      connected_order_arc_1408  -12
    RHS1      connected_order_arc_1410  -12
    RHS1      connected_order_arc_1412  -12
    RHS1      connected_order_arc_1414  -12
    RHS1      connected_order_arc_1416  -12
    RHS1      connected_order_arc_1418  -12
    RHS1      connected_order_arc_1421  -12
    RHS1      connected_order_arc_1423  -12
    RHS1      connected_order_arc_1425  -12
    RHS1      connected_order_arc_1427  -12
    RHS1      connected_order_arc_1429  -12
    RHS1      connected_order_arc_1431  -12
    RHS1      connected_order_arc_1433  -12
    RHS1      connected_order_arc_1435  -12
    RHS1      connected_order_arc_1437  -12
    RHS1      connected_order_arc_1439  -12
    RHS1      connected_order_arc_1441  -12
    RHS1      connected_order_arc_1444  -12
    RHS1      connected_order_arc_1446  -12
    RHS1      connected_order_arc_1448  -12
    RHS1      connected_order_arc_1450  -12
    RHS1      connected_order_arc_1452  -12
    RHS1      connected_order_arc_1454  -12
    RHS1      connected_order_arc_1456  -12
    RHS1      connected_order_arc_1458  -12
    RHS1      connected_order_arc_1460  -12
    RHS1      connected_order_arc_1462  -12
    RHS1      connected_order_arc_1464  -12
    RHS1      connected_order_arc_1467  -12
    RHS1      connected_order_arc_1469  -12
    RHS1      connected_order_arc_1471  -12
    RHS1      connected_order_arc_1473  -12
    RHS1      connected_order_arc_1475  -12
    RHS1      connected_order_arc_1477  -12
    RHS1      connected_order_arc_1479  -12
    RHS1      connected_order_arc_1481  -12
    RHS1      connected_order_arc_1483  -12
    RHS1      connected_order_arc_1485  -12
    RHS1      connected_order_arc_1487  -12
    RHS1      connected_order_arc_1490  -12
    RHS1      connected_order_arc_1492  -12
    RHS1      connected_order_arc_1494  -12
    RHS1      connected_order_arc_1496  -12
    RHS1      connected_order_arc_1498  -12
    RHS1      connected_order_arc_1500  -12
    RHS1      connected_order_arc_1502  -12
    RHS1      connected_order_arc_1504  -12
    RHS1      connected_order_arc_1506  -12
    RHS1      connected_order_arc_1508  -12
    RHS1      connected_order_arc_1510  -12
    RHS1      depot_departure_or_bypass_1511  1
    RHS1      depot_return_or_bypass_1512  1
    RHS1      segment_load_conservation_1517  3
    RHS1      segment_prefix_ub_1519  27
    RHS1      segment_load_conservation_1524  -2
    RHS1      segment_prefix_lb_1525  2
    RHS1      segment_prefix_ub_1526  30
    RHS1      segment_prefix_ub_1533  24
    RHS1      segment_load_conservation_1538  -2
    RHS1      segment_prefix_lb_1539  2
    RHS1      segment_prefix_ub_1540  30
    RHS1      fixed_segment_relative_order_1589  1
    RHS1      fixed_segment_relative_order_1590  1
    RHS1      fixed_segment_relative_order_1591  1
    RHS1      original_T_including_depot_unload_1592  4747.22184879174
BOUNDS
 LO BND1      t         2.4792168822839088e-02
 UP BND1      t         4.1857683874867449e-02
 UP BND1      q         5.1154506565812563e-01
 BV BND1      x_15_0  
 UP BND1      w_15_0    4.1857683874867449e-02
 BV BND1      x_15_1  
 UP BND1      w_15_1    4.1857683874867449e-02
 BV BND1      x_15_2  
 UP BND1      w_15_2    4.1857683874867449e-02
 BV BND1      x_15_3  
 UP BND1      w_15_3    4.1857683874867449e-02
 BV BND1      x_15_4  
 UP BND1      w_15_4    4.1857683874867449e-02
 BV BND1      x_15_5  
 UP BND1      w_15_5    4.1857683874867449e-02
 BV BND1      x_15_6  
 UP BND1      w_15_6    4.1857683874867449e-02
 BV BND1      x_15_7  
 UP BND1      w_15_7    4.1857683874867449e-02
 BV BND1      x_15_8  
 UP BND1      w_15_8    4.1857683874867449e-02
 BV BND1      x_15_9  
 UP BND1      w_15_9    4.1857683874867449e-02
 BV BND1      x_15_10 
 UP BND1      w_15_10   4.1857683874867449e-02
 BV BND1      x_15_11 
 UP BND1      w_15_11   4.1857683874867449e-02
 BV BND1      x_15_12 
 UP BND1      w_15_12   4.1857683874867449e-02
 BV BND1      x_15_13 
 UP BND1      w_15_13   4.1857683874867449e-02
 BV BND1      x_15_14 
 UP BND1      w_15_14   4.1857683874867449e-02
 BV BND1      x_15_15 
 UP BND1      w_15_15   4.1857683874867449e-02
 BV BND1      x_15_16 
 UP BND1      w_15_16   4.1857683874867449e-02
 UP BND1      rho_15    1
 BV BND1      x_9_0   
 UP BND1      w_9_0     4.1857683874867449e-02
 BV BND1      x_9_1   
 UP BND1      w_9_1     4.1857683874867449e-02
 BV BND1      x_9_2   
 UP BND1      w_9_2     4.1857683874867449e-02
 BV BND1      x_9_3   
 UP BND1      w_9_3     4.1857683874867449e-02
 BV BND1      x_9_4   
 UP BND1      w_9_4     4.1857683874867449e-02
 BV BND1      x_9_5   
 UP BND1      w_9_5     4.1857683874867449e-02
 BV BND1      x_9_6   
 UP BND1      w_9_6     4.1857683874867449e-02
 BV BND1      x_9_7   
 UP BND1      w_9_7     4.1857683874867449e-02
 BV BND1      x_9_8   
 UP BND1      w_9_8     4.1857683874867449e-02
 BV BND1      x_9_9   
 UP BND1      w_9_9     4.1857683874867449e-02
 BV BND1      x_9_10  
 UP BND1      w_9_10    4.1857683874867449e-02
 BV BND1      x_9_11  
 UP BND1      w_9_11    4.1857683874867449e-02
 BV BND1      x_9_12  
 UP BND1      w_9_12    4.1857683874867449e-02
 UP BND1      rho_9     1
 BV BND1      x_31_0  
 UP BND1      w_31_0    4.1857683874867449e-02
 BV BND1      x_31_1  
 UP BND1      w_31_1    4.1857683874867449e-02
 BV BND1      x_31_2  
 UP BND1      w_31_2    4.1857683874867449e-02
 BV BND1      x_31_3  
 UP BND1      w_31_3    4.1857683874867449e-02
 BV BND1      x_31_4  
 UP BND1      w_31_4    4.1857683874867449e-02
 BV BND1      x_31_5  
 UP BND1      w_31_5    4.1857683874867449e-02
 BV BND1      x_31_6  
 UP BND1      w_31_6    4.1857683874867449e-02
 BV BND1      x_31_7  
 UP BND1      w_31_7    4.1857683874867449e-02
 BV BND1      x_31_8  
 UP BND1      w_31_8    4.1857683874867449e-02
 BV BND1      x_31_9  
 UP BND1      w_31_9    4.1857683874867449e-02
 BV BND1      x_31_10 
 UP BND1      w_31_10   4.1857683874867449e-02
 BV BND1      x_31_11 
 UP BND1      w_31_11   4.1857683874867449e-02
 BV BND1      x_31_12 
 UP BND1      w_31_12   4.1857683874867449e-02
 UP BND1      rho_31    1
 BV BND1      x_19_0  
 UP BND1      w_19_0    4.1857683874867449e-02
 BV BND1      x_19_1  
 UP BND1      w_19_1    4.1857683874867449e-02
 BV BND1      x_19_2  
 UP BND1      w_19_2    4.1857683874867449e-02
 BV BND1      x_19_3  
 UP BND1      w_19_3    4.1857683874867449e-02
 BV BND1      x_19_4  
 UP BND1      w_19_4    4.1857683874867449e-02
 BV BND1      x_19_5  
 UP BND1      w_19_5    4.1857683874867449e-02
 BV BND1      x_19_6  
 UP BND1      w_19_6    4.1857683874867449e-02
 BV BND1      x_19_7  
 UP BND1      w_19_7    4.1857683874867449e-02
 BV BND1      x_19_8  
 UP BND1      w_19_8    4.1857683874867449e-02
 UP BND1      rho_19    1
 BV BND1      x_16_0  
 UP BND1      w_16_0    4.1857683874867449e-02
 BV BND1      x_16_1  
 UP BND1      w_16_1    4.1857683874867449e-02
 BV BND1      x_16_2  
 UP BND1      w_16_2    4.1857683874867449e-02
 BV BND1      x_16_3  
 UP BND1      w_16_3    4.1857683874867449e-02
 BV BND1      x_16_4  
 UP BND1      w_16_4    4.1857683874867449e-02
 BV BND1      x_16_5  
 UP BND1      w_16_5    4.1857683874867449e-02
 BV BND1      x_16_6  
 UP BND1      w_16_6    4.1857683874867449e-02
 BV BND1      x_16_7  
 UP BND1      w_16_7    4.1857683874867449e-02
 BV BND1      x_16_8  
 UP BND1      w_16_8    4.1857683874867449e-02
 BV BND1      x_16_9  
 UP BND1      w_16_9    4.1857683874867449e-02
 BV BND1      x_16_10 
 UP BND1      w_16_10   4.1857683874867449e-02
 BV BND1      x_16_11 
 UP BND1      w_16_11   4.1857683874867449e-02
 BV BND1      x_16_12 
 UP BND1      w_16_12   4.1857683874867449e-02
 UP BND1      rho_16    1
 BV BND1      x_13_0  
 UP BND1      w_13_0    4.1857683874867449e-02
 BV BND1      x_13_1  
 UP BND1      w_13_1    4.1857683874867449e-02
 BV BND1      x_13_2  
 UP BND1      w_13_2    4.1857683874867449e-02
 BV BND1      x_13_3  
 UP BND1      w_13_3    4.1857683874867449e-02
 BV BND1      x_13_4  
 UP BND1      w_13_4    4.1857683874867449e-02
 BV BND1      x_13_5  
 UP BND1      w_13_5    4.1857683874867449e-02
 BV BND1      x_13_6  
 UP BND1      w_13_6    4.1857683874867449e-02
 BV BND1      x_13_7  
 UP BND1      w_13_7    4.1857683874867449e-02
 BV BND1      x_13_8  
 UP BND1      w_13_8    4.1857683874867449e-02
 BV BND1      x_13_9  
 UP BND1      w_13_9    4.1857683874867449e-02
 BV BND1      x_13_10 
 UP BND1      w_13_10   4.1857683874867449e-02
 BV BND1      x_13_11 
 UP BND1      w_13_11   4.1857683874867449e-02
 BV BND1      x_13_12 
 UP BND1      w_13_12   4.1857683874867449e-02
 BV BND1      x_13_13 
 UP BND1      w_13_13   4.1857683874867449e-02
 BV BND1      x_13_14 
 UP BND1      w_13_14   4.1857683874867449e-02
 BV BND1      x_13_15 
 UP BND1      w_13_15   4.1857683874867449e-02
 BV BND1      x_13_16 
 UP BND1      w_13_16   4.1857683874867449e-02
 BV BND1      x_13_17 
 UP BND1      w_13_17   4.1857683874867449e-02
 BV BND1      x_13_18 
 UP BND1      w_13_18   4.1857683874867449e-02
 BV BND1      x_13_19 
 UP BND1      w_13_19   4.1857683874867449e-02
 UP BND1      rho_13    1
 BV BND1      x_32_0  
 UP BND1      w_32_0    4.1857683874867449e-02
 BV BND1      x_32_1  
 UP BND1      w_32_1    4.1857683874867449e-02
 BV BND1      x_32_2  
 UP BND1      w_32_2    4.1857683874867449e-02
 BV BND1      x_32_3  
 UP BND1      w_32_3    4.1857683874867449e-02
 BV BND1      x_32_4  
 UP BND1      w_32_4    4.1857683874867449e-02
 BV BND1      x_32_5  
 UP BND1      w_32_5    4.1857683874867449e-02
 BV BND1      x_32_6  
 UP BND1      w_32_6    4.1857683874867449e-02
 BV BND1      x_32_7  
 UP BND1      w_32_7    4.1857683874867449e-02
 BV BND1      x_32_8  
 UP BND1      w_32_8    4.1857683874867449e-02
 BV BND1      x_32_9  
 UP BND1      w_32_9    4.1857683874867449e-02
 BV BND1      x_32_10 
 UP BND1      w_32_10   4.1857683874867449e-02
 BV BND1      x_32_11 
 UP BND1      w_32_11   4.1857683874867449e-02
 BV BND1      x_32_12 
 UP BND1      w_32_12   4.1857683874867449e-02
 UP BND1      rho_32    1
 BV BND1      x_17_0  
 UP BND1      w_17_0    4.1857683874867449e-02
 BV BND1      x_17_1  
 UP BND1      w_17_1    4.1857683874867449e-02
 BV BND1      x_17_2  
 UP BND1      w_17_2    4.1857683874867449e-02
 BV BND1      x_17_3  
 UP BND1      w_17_3    4.1857683874867449e-02
 BV BND1      x_17_4  
 UP BND1      w_17_4    4.1857683874867449e-02
 BV BND1      x_17_5  
 UP BND1      w_17_5    4.1857683874867449e-02
 BV BND1      x_17_6  
 UP BND1      w_17_6    4.1857683874867449e-02
 BV BND1      x_17_7  
 UP BND1      w_17_7    4.1857683874867449e-02
 BV BND1      x_17_8  
 UP BND1      w_17_8    4.1857683874867449e-02
 BV BND1      x_17_9  
 UP BND1      w_17_9    4.1857683874867449e-02
 BV BND1      x_17_10 
 UP BND1      w_17_10   4.1857683874867449e-02
 BV BND1      x_17_11 
 UP BND1      w_17_11   4.1857683874867449e-02
 BV BND1      x_17_12 
 UP BND1      w_17_12   4.1857683874867449e-02
 BV BND1      x_17_13 
 UP BND1      w_17_13   4.1857683874867449e-02
 BV BND1      x_17_14 
 UP BND1      w_17_14   4.1857683874867449e-02
 BV BND1      x_17_15 
 UP BND1      w_17_15   4.1857683874867449e-02
 BV BND1      x_17_16 
 UP BND1      w_17_16   4.1857683874867449e-02
 UP BND1      rho_17    1
 UP BND1      a_15_9    1
 UP BND1      a_15_31   1
 UP BND1      a_15_19   1
 UP BND1      a_15_16   1
 UP BND1      a_15_13   1
 UP BND1      a_15_32   1
 UP BND1      a_15_17   1
 UP BND1      a_9_31    1
 UP BND1      a_9_19    1
 UP BND1      a_9_16    1
 UP BND1      a_9_13    1
 UP BND1      a_9_32    1
 UP BND1      a_9_17    1
 UP BND1      a_31_19   1
 UP BND1      a_31_16   1
 UP BND1      a_31_13   1
 UP BND1      a_31_32   1
 UP BND1      a_31_17   1
 UP BND1      a_19_16   1
 UP BND1      a_19_13   1
 UP BND1      a_19_32   1
 UP BND1      a_19_17   1
 UP BND1      a_16_13   1
 UP BND1      a_16_32   1
 UP BND1      a_16_17   1
 UP BND1      a_13_32   1
 UP BND1      a_13_17   1
 UP BND1      a_32_17   1
 BV BND1      service_0_15_0
 BV BND1      service_0_15_1
 BV BND1      service_0_15_2
 BV BND1      service_0_15_4
 BV BND1      service_0_15_5
 BV BND1      service_0_15_6
 BV BND1      service_0_15_7
 BV BND1      service_0_15_8
 BV BND1      service_0_15_9
 BV BND1      service_0_15_10
 BV BND1      service_0_15_11
 BV BND1      service_0_15_12
 BV BND1      service_0_15_13
 BV BND1      service_0_15_14
 BV BND1      service_0_15_15
 BV BND1      service_0_15_16
 BV BND1      service_1_15_0
 BV BND1      service_1_15_1
 BV BND1      service_1_15_2
 BV BND1      service_1_15_4
 BV BND1      service_1_15_5
 BV BND1      service_1_15_6
 BV BND1      service_1_15_7
 BV BND1      service_1_15_8
 BV BND1      service_1_15_9
 BV BND1      service_1_15_10
 BV BND1      service_1_15_11
 BV BND1      service_1_15_12
 BV BND1      service_1_15_13
 BV BND1      service_1_15_14
 BV BND1      service_1_15_15
 BV BND1      service_1_15_16
 BV BND1      service_2_15_0
 BV BND1      service_2_15_1
 BV BND1      service_2_15_2
 BV BND1      service_2_15_4
 BV BND1      service_2_15_5
 BV BND1      service_2_15_6
 BV BND1      service_2_15_7
 BV BND1      service_2_15_8
 BV BND1      service_2_15_9
 BV BND1      service_2_15_10
 BV BND1      service_2_15_11
 BV BND1      service_2_15_12
 BV BND1      service_2_15_13
 BV BND1      service_2_15_14
 BV BND1      service_2_15_15
 BV BND1      service_2_15_16
 BV BND1      service_0_9_0
 BV BND1      service_0_9_1
 BV BND1      service_0_9_2
 BV BND1      service_0_9_3
 BV BND1      service_0_9_4
 BV BND1      service_0_9_5
 BV BND1      service_0_9_6
 BV BND1      service_0_9_7
 BV BND1      service_0_9_9
 BV BND1      service_0_9_10
 BV BND1      service_0_9_11
 BV BND1      service_0_9_12
 BV BND1      service_1_9_0
 BV BND1      service_1_9_1
 BV BND1      service_1_9_2
 BV BND1      service_1_9_3
 BV BND1      service_1_9_4
 BV BND1      service_1_9_5
 BV BND1      service_1_9_6
 BV BND1      service_1_9_7
 BV BND1      service_1_9_9
 BV BND1      service_1_9_10
 BV BND1      service_1_9_11
 BV BND1      service_1_9_12
 BV BND1      service_2_9_0
 BV BND1      service_2_9_1
 BV BND1      service_2_9_2
 BV BND1      service_2_9_3
 BV BND1      service_2_9_4
 BV BND1      service_2_9_5
 BV BND1      service_2_9_6
 BV BND1      service_2_9_7
 BV BND1      service_2_9_9
 BV BND1      service_2_9_10
 BV BND1      service_2_9_11
 BV BND1      service_2_9_12
 BV BND1      service_0_31_0
 BV BND1      service_0_31_1
 BV BND1      service_0_31_3
 BV BND1      service_0_31_4
 BV BND1      service_0_31_5
 BV BND1      service_0_31_6
 BV BND1      service_0_31_7
 BV BND1      service_0_31_8
 BV BND1      service_0_31_9
 BV BND1      service_0_31_10
 BV BND1      service_0_31_11
 BV BND1      service_0_31_12
 BV BND1      service_1_31_0
 BV BND1      service_1_31_1
 BV BND1      service_1_31_3
 BV BND1      service_1_31_4
 BV BND1      service_1_31_5
 BV BND1      service_1_31_6
 BV BND1      service_1_31_7
 BV BND1      service_1_31_8
 BV BND1      service_1_31_9
 BV BND1      service_1_31_10
 BV BND1      service_1_31_11
 BV BND1      service_1_31_12
 BV BND1      service_2_31_0
 BV BND1      service_2_31_1
 BV BND1      service_2_31_3
 BV BND1      service_2_31_4
 BV BND1      service_2_31_5
 BV BND1      service_2_31_6
 BV BND1      service_2_31_7
 BV BND1      service_2_31_8
 BV BND1      service_2_31_9
 BV BND1      service_2_31_10
 BV BND1      service_2_31_11
 BV BND1      service_2_31_12
 BV BND1      service_0_19_1
 BV BND1      service_0_19_2
 BV BND1      service_0_19_3
 BV BND1      service_0_19_4
 BV BND1      service_0_19_5
 BV BND1      service_0_19_6
 BV BND1      service_0_19_7
 BV BND1      service_0_19_8
 BV BND1      service_1_19_1
 BV BND1      service_1_19_2
 BV BND1      service_1_19_3
 BV BND1      service_1_19_4
 BV BND1      service_1_19_5
 BV BND1      service_1_19_6
 BV BND1      service_1_19_7
 BV BND1      service_1_19_8
 BV BND1      service_2_19_1
 BV BND1      service_2_19_2
 BV BND1      service_2_19_3
 BV BND1      service_2_19_4
 BV BND1      service_2_19_5
 BV BND1      service_2_19_6
 BV BND1      service_2_19_7
 BV BND1      service_2_19_8
 BV BND1      service_0_16_0
 BV BND1      service_0_16_2
 BV BND1      service_0_16_3
 BV BND1      service_0_16_4
 BV BND1      service_0_16_5
 BV BND1      service_0_16_6
 BV BND1      service_0_16_7
 BV BND1      service_0_16_8
 BV BND1      service_0_16_9
 BV BND1      service_0_16_10
 BV BND1      service_0_16_11
 BV BND1      service_0_16_12
 BV BND1      service_1_16_0
 BV BND1      service_1_16_2
 BV BND1      service_1_16_3
 BV BND1      service_1_16_4
 BV BND1      service_1_16_5
 BV BND1      service_1_16_6
 BV BND1      service_1_16_7
 BV BND1      service_1_16_8
 BV BND1      service_1_16_9
 BV BND1      service_1_16_10
 BV BND1      service_1_16_11
 BV BND1      service_1_16_12
 BV BND1      service_2_16_0
 BV BND1      service_2_16_2
 BV BND1      service_2_16_3
 BV BND1      service_2_16_4
 BV BND1      service_2_16_5
 BV BND1      service_2_16_6
 BV BND1      service_2_16_7
 BV BND1      service_2_16_8
 BV BND1      service_2_16_9
 BV BND1      service_2_16_10
 BV BND1      service_2_16_11
 BV BND1      service_2_16_12
 BV BND1      service_0_13_0
 BV BND1      service_0_13_1
 BV BND1      service_0_13_2
 BV BND1      service_0_13_3
 BV BND1      service_0_13_4
 BV BND1      service_0_13_5
 BV BND1      service_0_13_6
 BV BND1      service_0_13_7
 BV BND1      service_0_13_8
 BV BND1      service_0_13_9
 BV BND1      service_0_13_10
 BV BND1      service_0_13_11
 BV BND1      service_0_13_12
 BV BND1      service_0_13_14
 BV BND1      service_0_13_15
 BV BND1      service_0_13_16
 BV BND1      service_0_13_17
 BV BND1      service_0_13_18
 BV BND1      service_0_13_19
 BV BND1      service_1_13_0
 BV BND1      service_1_13_1
 BV BND1      service_1_13_2
 BV BND1      service_1_13_3
 BV BND1      service_1_13_4
 BV BND1      service_1_13_5
 BV BND1      service_1_13_6
 BV BND1      service_1_13_7
 BV BND1      service_1_13_8
 BV BND1      service_1_13_9
 BV BND1      service_1_13_10
 BV BND1      service_1_13_11
 BV BND1      service_1_13_12
 BV BND1      service_1_13_14
 BV BND1      service_1_13_15
 BV BND1      service_1_13_16
 BV BND1      service_1_13_17
 BV BND1      service_1_13_18
 BV BND1      service_1_13_19
 BV BND1      service_2_13_0
 BV BND1      service_2_13_1
 BV BND1      service_2_13_2
 BV BND1      service_2_13_3
 BV BND1      service_2_13_4
 BV BND1      service_2_13_5
 BV BND1      service_2_13_6
 BV BND1      service_2_13_7
 BV BND1      service_2_13_8
 BV BND1      service_2_13_9
 BV BND1      service_2_13_10
 BV BND1      service_2_13_11
 BV BND1      service_2_13_12
 BV BND1      service_2_13_14
 BV BND1      service_2_13_15
 BV BND1      service_2_13_16
 BV BND1      service_2_13_17
 BV BND1      service_2_13_18
 BV BND1      service_2_13_19
 BV BND1      service_0_32_1
 BV BND1      service_0_32_2
 BV BND1      service_0_32_3
 BV BND1      service_0_32_4
 BV BND1      service_0_32_5
 BV BND1      service_0_32_6
 BV BND1      service_0_32_7
 BV BND1      service_0_32_8
 BV BND1      service_0_32_9
 BV BND1      service_0_32_10
 BV BND1      service_0_32_11
 BV BND1      service_0_32_12
 BV BND1      service_1_32_1
 BV BND1      service_1_32_2
 BV BND1      service_1_32_3
 BV BND1      service_1_32_4
 BV BND1      service_1_32_5
 BV BND1      service_1_32_6
 BV BND1      service_1_32_7
 BV BND1      service_1_32_8
 BV BND1      service_1_32_9
 BV BND1      service_1_32_10
 BV BND1      service_1_32_11
 BV BND1      service_1_32_12
 BV BND1      service_2_32_1
 BV BND1      service_2_32_2
 BV BND1      service_2_32_3
 BV BND1      service_2_32_4
 BV BND1      service_2_32_5
 BV BND1      service_2_32_6
 BV BND1      service_2_32_7
 BV BND1      service_2_32_8
 BV BND1      service_2_32_9
 BV BND1      service_2_32_10
 BV BND1      service_2_32_11
 BV BND1      service_2_32_12
 BV BND1      service_0_17_0
 BV BND1      service_0_17_1
 BV BND1      service_0_17_2
 BV BND1      service_0_17_4
 BV BND1      service_0_17_5
 BV BND1      service_0_17_6
 BV BND1      service_0_17_7
 BV BND1      service_0_17_8
 BV BND1      service_0_17_9
 BV BND1      service_0_17_10
 BV BND1      service_0_17_11
 BV BND1      service_0_17_12
 BV BND1      service_0_17_13
 BV BND1      service_0_17_14
 BV BND1      service_0_17_15
 BV BND1      service_0_17_16
 BV BND1      service_1_17_0
 BV BND1      service_1_17_1
 BV BND1      service_1_17_2
 BV BND1      service_1_17_4
 BV BND1      service_1_17_5
 BV BND1      service_1_17_6
 BV BND1      service_1_17_7
 BV BND1      service_1_17_8
 BV BND1      service_1_17_9
 BV BND1      service_1_17_10
 BV BND1      service_1_17_11
 BV BND1      service_1_17_12
 BV BND1      service_1_17_13
 BV BND1      service_1_17_14
 BV BND1      service_1_17_15
 BV BND1      service_1_17_16
 BV BND1      service_2_17_0
 BV BND1      service_2_17_1
 BV BND1      service_2_17_2
 BV BND1      service_2_17_4
 BV BND1      service_2_17_5
 BV BND1      service_2_17_6
 BV BND1      service_2_17_7
 BV BND1      service_2_17_8
 BV BND1      service_2_17_9
 BV BND1      service_2_17_10
 BV BND1      service_2_17_11
 BV BND1      service_2_17_12
 BV BND1      service_2_17_13
 BV BND1      service_2_17_14
 BV BND1      service_2_17_15
 BV BND1      service_2_17_16
 FX BND1      visit_0_1  1
 UP BND1      order_0_1  12
 FX BND1      visit_0_2  1
 UP BND1      order_0_2  12
 FX BND1      visit_0_3  1
 UP BND1      order_0_3  12
 FX BND1      visit_0_4  1
 UP BND1      order_0_4  12
 UP BND1      visit_0_14  1
 UP BND1      order_0_14  12
 UP BND1      visit_0_15  1
 UP BND1      order_0_15  12
 UP BND1      visit_0_16  1
 UP BND1      order_0_16  12
 UP BND1      visit_0_17  1
 UP BND1      order_0_17  12
 UP BND1      visit_0_18  1
 UP BND1      order_0_18  12
 UP BND1      visit_0_19  1
 UP BND1      order_0_19  12
 UP BND1      visit_0_20  1
 UP BND1      order_0_20  12
 UP BND1      visit_0_21  1
 UP BND1      order_0_21  12
 BV BND1      arc_0_0_0
 FX BND1      load_0_0_0  0
 BV BND1      arc_0_0_1
 FX BND1      load_0_0_1  0
 BV BND1      arc_0_0_2
 FX BND1      load_0_0_2  0
 BV BND1      arc_0_0_3
 FX BND1      load_0_0_3  0
 BV BND1      arc_0_0_4
 FX BND1      load_0_0_4  0
 BV BND1      arc_0_0_14
 FX BND1      load_0_0_14  0
 BV BND1      arc_0_0_15
 FX BND1      load_0_0_15  0
 BV BND1      arc_0_0_16
 FX BND1      load_0_0_16  0
 BV BND1      arc_0_0_17
 FX BND1      load_0_0_17  0
 BV BND1      arc_0_0_18
 FX BND1      load_0_0_18  0
 BV BND1      arc_0_0_19
 FX BND1      load_0_0_19  0
 BV BND1      arc_0_0_20
 FX BND1      load_0_0_20  0
 BV BND1      arc_0_0_21
 FX BND1      load_0_0_21  0
 BV BND1      arc_0_1_0
 UP BND1      load_0_1_0  20
 BV BND1      arc_0_1_2
 UP BND1      load_0_1_2  20
 BV BND1      arc_0_1_3
 UP BND1      load_0_1_3  20
 BV BND1      arc_0_1_4
 UP BND1      load_0_1_4  20
 BV BND1      arc_0_1_14
 UP BND1      load_0_1_14  20
 BV BND1      arc_0_1_15
 UP BND1      load_0_1_15  20
 BV BND1      arc_0_1_16
 UP BND1      load_0_1_16  20
 BV BND1      arc_0_1_17
 UP BND1      load_0_1_17  20
 BV BND1      arc_0_1_18
 UP BND1      load_0_1_18  20
 BV BND1      arc_0_1_19
 UP BND1      load_0_1_19  20
 BV BND1      arc_0_1_20
 UP BND1      load_0_1_20  20
 BV BND1      arc_0_1_21
 UP BND1      load_0_1_21  20
 BV BND1      arc_0_2_0
 UP BND1      load_0_2_0  20
 BV BND1      arc_0_2_1
 UP BND1      load_0_2_1  20
 BV BND1      arc_0_2_3
 UP BND1      load_0_2_3  20
 BV BND1      arc_0_2_4
 UP BND1      load_0_2_4  20
 BV BND1      arc_0_2_14
 UP BND1      load_0_2_14  20
 BV BND1      arc_0_2_15
 UP BND1      load_0_2_15  20
 BV BND1      arc_0_2_16
 UP BND1      load_0_2_16  20
 BV BND1      arc_0_2_17
 UP BND1      load_0_2_17  20
 BV BND1      arc_0_2_18
 UP BND1      load_0_2_18  20
 BV BND1      arc_0_2_19
 UP BND1      load_0_2_19  20
 BV BND1      arc_0_2_20
 UP BND1      load_0_2_20  20
 BV BND1      arc_0_2_21
 UP BND1      load_0_2_21  20
 BV BND1      arc_0_3_0
 UP BND1      load_0_3_0  20
 BV BND1      arc_0_3_1
 UP BND1      load_0_3_1  20
 BV BND1      arc_0_3_2
 UP BND1      load_0_3_2  20
 BV BND1      arc_0_3_4
 UP BND1      load_0_3_4  20
 BV BND1      arc_0_3_14
 UP BND1      load_0_3_14  20
 BV BND1      arc_0_3_15
 UP BND1      load_0_3_15  20
 BV BND1      arc_0_3_16
 UP BND1      load_0_3_16  20
 BV BND1      arc_0_3_17
 UP BND1      load_0_3_17  20
 BV BND1      arc_0_3_18
 UP BND1      load_0_3_18  20
 BV BND1      arc_0_3_19
 UP BND1      load_0_3_19  20
 BV BND1      arc_0_3_20
 UP BND1      load_0_3_20  20
 BV BND1      arc_0_3_21
 UP BND1      load_0_3_21  20
 BV BND1      arc_0_4_0
 UP BND1      load_0_4_0  20
 BV BND1      arc_0_4_1
 UP BND1      load_0_4_1  20
 BV BND1      arc_0_4_2
 UP BND1      load_0_4_2  20
 BV BND1      arc_0_4_3
 UP BND1      load_0_4_3  20
 BV BND1      arc_0_4_14
 UP BND1      load_0_4_14  20
 BV BND1      arc_0_4_15
 UP BND1      load_0_4_15  20
 BV BND1      arc_0_4_16
 UP BND1      load_0_4_16  20
 BV BND1      arc_0_4_17
 UP BND1      load_0_4_17  20
 BV BND1      arc_0_4_18
 UP BND1      load_0_4_18  20
 BV BND1      arc_0_4_19
 UP BND1      load_0_4_19  20
 BV BND1      arc_0_4_20
 UP BND1      load_0_4_20  20
 BV BND1      arc_0_4_21
 UP BND1      load_0_4_21  20
 BV BND1      arc_0_14_0
 UP BND1      load_0_14_0  20
 BV BND1      arc_0_14_1
 UP BND1      load_0_14_1  20
 BV BND1      arc_0_14_2
 UP BND1      load_0_14_2  20
 BV BND1      arc_0_14_3
 UP BND1      load_0_14_3  20
 BV BND1      arc_0_14_4
 UP BND1      load_0_14_4  20
 BV BND1      arc_0_14_15
 UP BND1      load_0_14_15  20
 BV BND1      arc_0_14_16
 UP BND1      load_0_14_16  20
 BV BND1      arc_0_14_17
 UP BND1      load_0_14_17  20
 BV BND1      arc_0_14_18
 UP BND1      load_0_14_18  20
 BV BND1      arc_0_14_19
 UP BND1      load_0_14_19  20
 BV BND1      arc_0_14_20
 UP BND1      load_0_14_20  20
 BV BND1      arc_0_14_21
 UP BND1      load_0_14_21  20
 BV BND1      arc_0_15_0
 UP BND1      load_0_15_0  20
 BV BND1      arc_0_15_1
 UP BND1      load_0_15_1  20
 BV BND1      arc_0_15_2
 UP BND1      load_0_15_2  20
 BV BND1      arc_0_15_3
 UP BND1      load_0_15_3  20
 BV BND1      arc_0_15_4
 UP BND1      load_0_15_4  20
 BV BND1      arc_0_15_14
 UP BND1      load_0_15_14  20
 BV BND1      arc_0_15_16
 UP BND1      load_0_15_16  20
 BV BND1      arc_0_15_17
 UP BND1      load_0_15_17  20
 BV BND1      arc_0_15_18
 UP BND1      load_0_15_18  20
 BV BND1      arc_0_15_19
 UP BND1      load_0_15_19  20
 BV BND1      arc_0_15_20
 UP BND1      load_0_15_20  20
 BV BND1      arc_0_15_21
 UP BND1      load_0_15_21  20
 BV BND1      arc_0_16_0
 UP BND1      load_0_16_0  20
 BV BND1      arc_0_16_1
 UP BND1      load_0_16_1  20
 BV BND1      arc_0_16_2
 UP BND1      load_0_16_2  20
 BV BND1      arc_0_16_3
 UP BND1      load_0_16_3  20
 BV BND1      arc_0_16_4
 UP BND1      load_0_16_4  20
 BV BND1      arc_0_16_14
 UP BND1      load_0_16_14  20
 BV BND1      arc_0_16_15
 UP BND1      load_0_16_15  20
 BV BND1      arc_0_16_17
 UP BND1      load_0_16_17  20
 BV BND1      arc_0_16_18
 UP BND1      load_0_16_18  20
 BV BND1      arc_0_16_19
 UP BND1      load_0_16_19  20
 BV BND1      arc_0_16_20
 UP BND1      load_0_16_20  20
 BV BND1      arc_0_16_21
 UP BND1      load_0_16_21  20
 BV BND1      arc_0_17_0
 UP BND1      load_0_17_0  20
 BV BND1      arc_0_17_1
 UP BND1      load_0_17_1  20
 BV BND1      arc_0_17_2
 UP BND1      load_0_17_2  20
 BV BND1      arc_0_17_3
 UP BND1      load_0_17_3  20
 BV BND1      arc_0_17_4
 UP BND1      load_0_17_4  20
 BV BND1      arc_0_17_14
 UP BND1      load_0_17_14  20
 BV BND1      arc_0_17_15
 UP BND1      load_0_17_15  20
 BV BND1      arc_0_17_16
 UP BND1      load_0_17_16  20
 BV BND1      arc_0_17_18
 UP BND1      load_0_17_18  20
 BV BND1      arc_0_17_19
 UP BND1      load_0_17_19  20
 BV BND1      arc_0_17_20
 UP BND1      load_0_17_20  20
 BV BND1      arc_0_17_21
 UP BND1      load_0_17_21  20
 BV BND1      arc_0_18_0
 UP BND1      load_0_18_0  20
 BV BND1      arc_0_18_1
 UP BND1      load_0_18_1  20
 BV BND1      arc_0_18_2
 UP BND1      load_0_18_2  20
 BV BND1      arc_0_18_3
 UP BND1      load_0_18_3  20
 BV BND1      arc_0_18_4
 UP BND1      load_0_18_4  20
 BV BND1      arc_0_18_14
 UP BND1      load_0_18_14  20
 BV BND1      arc_0_18_15
 UP BND1      load_0_18_15  20
 BV BND1      arc_0_18_16
 UP BND1      load_0_18_16  20
 BV BND1      arc_0_18_17
 UP BND1      load_0_18_17  20
 BV BND1      arc_0_18_19
 UP BND1      load_0_18_19  20
 BV BND1      arc_0_18_20
 UP BND1      load_0_18_20  20
 BV BND1      arc_0_18_21
 UP BND1      load_0_18_21  20
 BV BND1      arc_0_19_0
 UP BND1      load_0_19_0  20
 BV BND1      arc_0_19_1
 UP BND1      load_0_19_1  20
 BV BND1      arc_0_19_2
 UP BND1      load_0_19_2  20
 BV BND1      arc_0_19_3
 UP BND1      load_0_19_3  20
 BV BND1      arc_0_19_4
 UP BND1      load_0_19_4  20
 BV BND1      arc_0_19_14
 UP BND1      load_0_19_14  20
 BV BND1      arc_0_19_15
 UP BND1      load_0_19_15  20
 BV BND1      arc_0_19_16
 UP BND1      load_0_19_16  20
 BV BND1      arc_0_19_17
 UP BND1      load_0_19_17  20
 BV BND1      arc_0_19_18
 UP BND1      load_0_19_18  20
 BV BND1      arc_0_19_20
 UP BND1      load_0_19_20  20
 BV BND1      arc_0_19_21
 UP BND1      load_0_19_21  20
 BV BND1      arc_0_20_0
 UP BND1      load_0_20_0  20
 BV BND1      arc_0_20_1
 UP BND1      load_0_20_1  20
 BV BND1      arc_0_20_2
 UP BND1      load_0_20_2  20
 BV BND1      arc_0_20_3
 UP BND1      load_0_20_3  20
 BV BND1      arc_0_20_4
 UP BND1      load_0_20_4  20
 BV BND1      arc_0_20_14
 UP BND1      load_0_20_14  20
 BV BND1      arc_0_20_15
 UP BND1      load_0_20_15  20
 BV BND1      arc_0_20_16
 UP BND1      load_0_20_16  20
 BV BND1      arc_0_20_17
 UP BND1      load_0_20_17  20
 BV BND1      arc_0_20_18
 UP BND1      load_0_20_18  20
 BV BND1      arc_0_20_19
 UP BND1      load_0_20_19  20
 BV BND1      arc_0_20_21
 UP BND1      load_0_20_21  20
 BV BND1      arc_0_21_0
 UP BND1      load_0_21_0  20
 BV BND1      arc_0_21_1
 UP BND1      load_0_21_1  20
 BV BND1      arc_0_21_2
 UP BND1      load_0_21_2  20
 BV BND1      arc_0_21_3
 UP BND1      load_0_21_3  20
 BV BND1      arc_0_21_4
 UP BND1      load_0_21_4  20
 BV BND1      arc_0_21_14
 UP BND1      load_0_21_14  20
 BV BND1      arc_0_21_15
 UP BND1      load_0_21_15  20
 BV BND1      arc_0_21_16
 UP BND1      load_0_21_16  20
 BV BND1      arc_0_21_17
 UP BND1      load_0_21_17  20
 BV BND1      arc_0_21_18
 UP BND1      load_0_21_18  20
 BV BND1      arc_0_21_19
 UP BND1      load_0_21_19  20
 BV BND1      arc_0_21_20
 UP BND1      load_0_21_20  20
 FX BND1      visit_1_5  1
 UP BND1      order_1_5  13
 FX BND1      visit_1_6  1
 UP BND1      order_1_6  13
 FX BND1      visit_1_7  1
 UP BND1      order_1_7  13
 FX BND1      visit_1_8  1
 UP BND1      order_1_8  13
 FX BND1      visit_1_9  1
 UP BND1      order_1_9  13
 UP BND1      visit_1_14  1
 UP BND1      order_1_14  13
 UP BND1      visit_1_15  1
 UP BND1      order_1_15  13
 UP BND1      visit_1_16  1
 UP BND1      order_1_16  13
 UP BND1      visit_1_17  1
 UP BND1      order_1_17  13
 UP BND1      visit_1_18  1
 UP BND1      order_1_18  13
 UP BND1      visit_1_19  1
 UP BND1      order_1_19  13
 UP BND1      visit_1_20  1
 UP BND1      order_1_20  13
 UP BND1      visit_1_21  1
 UP BND1      order_1_21  13
 BV BND1      arc_1_0_0
 FX BND1      load_1_0_0  0
 BV BND1      arc_1_0_5
 FX BND1      load_1_0_5  0
 BV BND1      arc_1_0_6
 FX BND1      load_1_0_6  0
 BV BND1      arc_1_0_7
 FX BND1      load_1_0_7  0
 BV BND1      arc_1_0_8
 FX BND1      load_1_0_8  0
 BV BND1      arc_1_0_9
 FX BND1      load_1_0_9  0
 BV BND1      arc_1_0_14
 FX BND1      load_1_0_14  0
 BV BND1      arc_1_0_15
 FX BND1      load_1_0_15  0
 BV BND1      arc_1_0_16
 FX BND1      load_1_0_16  0
 BV BND1      arc_1_0_17
 FX BND1      load_1_0_17  0
 BV BND1      arc_1_0_18
 FX BND1      load_1_0_18  0
 BV BND1      arc_1_0_19
 FX BND1      load_1_0_19  0
 BV BND1      arc_1_0_20
 FX BND1      load_1_0_20  0
 BV BND1      arc_1_0_21
 FX BND1      load_1_0_21  0
 BV BND1      arc_1_5_0
 UP BND1      load_1_5_0  25
 BV BND1      arc_1_5_6
 UP BND1      load_1_5_6  25
 BV BND1      arc_1_5_7
 UP BND1      load_1_5_7  25
 BV BND1      arc_1_5_8
 UP BND1      load_1_5_8  25
 BV BND1      arc_1_5_9
 UP BND1      load_1_5_9  25
 BV BND1      arc_1_5_14
 UP BND1      load_1_5_14  25
 BV BND1      arc_1_5_15
 UP BND1      load_1_5_15  25
 BV BND1      arc_1_5_16
 UP BND1      load_1_5_16  25
 BV BND1      arc_1_5_17
 UP BND1      load_1_5_17  25
 BV BND1      arc_1_5_18
 UP BND1      load_1_5_18  25
 BV BND1      arc_1_5_19
 UP BND1      load_1_5_19  25
 BV BND1      arc_1_5_20
 UP BND1      load_1_5_20  25
 BV BND1      arc_1_5_21
 UP BND1      load_1_5_21  25
 BV BND1      arc_1_6_0
 UP BND1      load_1_6_0  25
 BV BND1      arc_1_6_5
 UP BND1      load_1_6_5  25
 BV BND1      arc_1_6_7
 UP BND1      load_1_6_7  25
 BV BND1      arc_1_6_8
 UP BND1      load_1_6_8  25
 BV BND1      arc_1_6_9
 UP BND1      load_1_6_9  25
 BV BND1      arc_1_6_14
 UP BND1      load_1_6_14  25
 BV BND1      arc_1_6_15
 UP BND1      load_1_6_15  25
 BV BND1      arc_1_6_16
 UP BND1      load_1_6_16  25
 BV BND1      arc_1_6_17
 UP BND1      load_1_6_17  25
 BV BND1      arc_1_6_18
 UP BND1      load_1_6_18  25
 BV BND1      arc_1_6_19
 UP BND1      load_1_6_19  25
 BV BND1      arc_1_6_20
 UP BND1      load_1_6_20  25
 BV BND1      arc_1_6_21
 UP BND1      load_1_6_21  25
 BV BND1      arc_1_7_0
 UP BND1      load_1_7_0  25
 BV BND1      arc_1_7_5
 UP BND1      load_1_7_5  25
 BV BND1      arc_1_7_6
 UP BND1      load_1_7_6  25
 BV BND1      arc_1_7_8
 UP BND1      load_1_7_8  25
 BV BND1      arc_1_7_9
 UP BND1      load_1_7_9  25
 BV BND1      arc_1_7_14
 UP BND1      load_1_7_14  25
 BV BND1      arc_1_7_15
 UP BND1      load_1_7_15  25
 BV BND1      arc_1_7_16
 UP BND1      load_1_7_16  25
 BV BND1      arc_1_7_17
 UP BND1      load_1_7_17  25
 BV BND1      arc_1_7_18
 UP BND1      load_1_7_18  25
 BV BND1      arc_1_7_19
 UP BND1      load_1_7_19  25
 BV BND1      arc_1_7_20
 UP BND1      load_1_7_20  25
 BV BND1      arc_1_7_21
 UP BND1      load_1_7_21  25
 BV BND1      arc_1_8_0
 UP BND1      load_1_8_0  25
 BV BND1      arc_1_8_5
 UP BND1      load_1_8_5  25
 BV BND1      arc_1_8_6
 UP BND1      load_1_8_6  25
 BV BND1      arc_1_8_7
 UP BND1      load_1_8_7  25
 BV BND1      arc_1_8_9
 UP BND1      load_1_8_9  25
 BV BND1      arc_1_8_14
 UP BND1      load_1_8_14  25
 BV BND1      arc_1_8_15
 UP BND1      load_1_8_15  25
 BV BND1      arc_1_8_16
 UP BND1      load_1_8_16  25
 BV BND1      arc_1_8_17
 UP BND1      load_1_8_17  25
 BV BND1      arc_1_8_18
 UP BND1      load_1_8_18  25
 BV BND1      arc_1_8_19
 UP BND1      load_1_8_19  25
 BV BND1      arc_1_8_20
 UP BND1      load_1_8_20  25
 BV BND1      arc_1_8_21
 UP BND1      load_1_8_21  25
 BV BND1      arc_1_9_0
 UP BND1      load_1_9_0  25
 BV BND1      arc_1_9_5
 UP BND1      load_1_9_5  25
 BV BND1      arc_1_9_6
 UP BND1      load_1_9_6  25
 BV BND1      arc_1_9_7
 UP BND1      load_1_9_7  25
 BV BND1      arc_1_9_8
 UP BND1      load_1_9_8  25
 BV BND1      arc_1_9_14
 UP BND1      load_1_9_14  25
 BV BND1      arc_1_9_15
 UP BND1      load_1_9_15  25
 BV BND1      arc_1_9_16
 UP BND1      load_1_9_16  25
 BV BND1      arc_1_9_17
 UP BND1      load_1_9_17  25
 BV BND1      arc_1_9_18
 UP BND1      load_1_9_18  25
 BV BND1      arc_1_9_19
 UP BND1      load_1_9_19  25
 BV BND1      arc_1_9_20
 UP BND1      load_1_9_20  25
 BV BND1      arc_1_9_21
 UP BND1      load_1_9_21  25
 BV BND1      arc_1_14_0
 UP BND1      load_1_14_0  25
 BV BND1      arc_1_14_5
 UP BND1      load_1_14_5  25
 BV BND1      arc_1_14_6
 UP BND1      load_1_14_6  25
 BV BND1      arc_1_14_7
 UP BND1      load_1_14_7  25
 BV BND1      arc_1_14_8
 UP BND1      load_1_14_8  25
 BV BND1      arc_1_14_9
 UP BND1      load_1_14_9  25
 BV BND1      arc_1_14_15
 UP BND1      load_1_14_15  25
 BV BND1      arc_1_14_16
 UP BND1      load_1_14_16  25
 BV BND1      arc_1_14_17
 UP BND1      load_1_14_17  25
 BV BND1      arc_1_14_18
 UP BND1      load_1_14_18  25
 BV BND1      arc_1_14_19
 UP BND1      load_1_14_19  25
 BV BND1      arc_1_14_20
 UP BND1      load_1_14_20  25
 BV BND1      arc_1_14_21
 UP BND1      load_1_14_21  25
 BV BND1      arc_1_15_0
 UP BND1      load_1_15_0  25
 BV BND1      arc_1_15_5
 UP BND1      load_1_15_5  25
 BV BND1      arc_1_15_6
 UP BND1      load_1_15_6  25
 BV BND1      arc_1_15_7
 UP BND1      load_1_15_7  25
 BV BND1      arc_1_15_8
 UP BND1      load_1_15_8  25
 BV BND1      arc_1_15_9
 UP BND1      load_1_15_9  25
 BV BND1      arc_1_15_14
 UP BND1      load_1_15_14  25
 BV BND1      arc_1_15_16
 UP BND1      load_1_15_16  25
 BV BND1      arc_1_15_17
 UP BND1      load_1_15_17  25
 BV BND1      arc_1_15_18
 UP BND1      load_1_15_18  25
 BV BND1      arc_1_15_19
 UP BND1      load_1_15_19  25
 BV BND1      arc_1_15_20
 UP BND1      load_1_15_20  25
 BV BND1      arc_1_15_21
 UP BND1      load_1_15_21  25
 BV BND1      arc_1_16_0
 UP BND1      load_1_16_0  25
 BV BND1      arc_1_16_5
 UP BND1      load_1_16_5  25
 BV BND1      arc_1_16_6
 UP BND1      load_1_16_6  25
 BV BND1      arc_1_16_7
 UP BND1      load_1_16_7  25
 BV BND1      arc_1_16_8
 UP BND1      load_1_16_8  25
 BV BND1      arc_1_16_9
 UP BND1      load_1_16_9  25
 BV BND1      arc_1_16_14
 UP BND1      load_1_16_14  25
 BV BND1      arc_1_16_15
 UP BND1      load_1_16_15  25
 BV BND1      arc_1_16_17
 UP BND1      load_1_16_17  25
 BV BND1      arc_1_16_18
 UP BND1      load_1_16_18  25
 BV BND1      arc_1_16_19
 UP BND1      load_1_16_19  25
 BV BND1      arc_1_16_20
 UP BND1      load_1_16_20  25
 BV BND1      arc_1_16_21
 UP BND1      load_1_16_21  25
 BV BND1      arc_1_17_0
 UP BND1      load_1_17_0  25
 BV BND1      arc_1_17_5
 UP BND1      load_1_17_5  25
 BV BND1      arc_1_17_6
 UP BND1      load_1_17_6  25
 BV BND1      arc_1_17_7
 UP BND1      load_1_17_7  25
 BV BND1      arc_1_17_8
 UP BND1      load_1_17_8  25
 BV BND1      arc_1_17_9
 UP BND1      load_1_17_9  25
 BV BND1      arc_1_17_14
 UP BND1      load_1_17_14  25
 BV BND1      arc_1_17_15
 UP BND1      load_1_17_15  25
 BV BND1      arc_1_17_16
 UP BND1      load_1_17_16  25
 BV BND1      arc_1_17_18
 UP BND1      load_1_17_18  25
 BV BND1      arc_1_17_19
 UP BND1      load_1_17_19  25
 BV BND1      arc_1_17_20
 UP BND1      load_1_17_20  25
 BV BND1      arc_1_17_21
 UP BND1      load_1_17_21  25
 BV BND1      arc_1_18_0
 UP BND1      load_1_18_0  25
 BV BND1      arc_1_18_5
 UP BND1      load_1_18_5  25
 BV BND1      arc_1_18_6
 UP BND1      load_1_18_6  25
 BV BND1      arc_1_18_7
 UP BND1      load_1_18_7  25
 BV BND1      arc_1_18_8
 UP BND1      load_1_18_8  25
 BV BND1      arc_1_18_9
 UP BND1      load_1_18_9  25
 BV BND1      arc_1_18_14
 UP BND1      load_1_18_14  25
 BV BND1      arc_1_18_15
 UP BND1      load_1_18_15  25
 BV BND1      arc_1_18_16
 UP BND1      load_1_18_16  25
 BV BND1      arc_1_18_17
 UP BND1      load_1_18_17  25
 BV BND1      arc_1_18_19
 UP BND1      load_1_18_19  25
 BV BND1      arc_1_18_20
 UP BND1      load_1_18_20  25
 BV BND1      arc_1_18_21
 UP BND1      load_1_18_21  25
 BV BND1      arc_1_19_0
 UP BND1      load_1_19_0  25
 BV BND1      arc_1_19_5
 UP BND1      load_1_19_5  25
 BV BND1      arc_1_19_6
 UP BND1      load_1_19_6  25
 BV BND1      arc_1_19_7
 UP BND1      load_1_19_7  25
 BV BND1      arc_1_19_8
 UP BND1      load_1_19_8  25
 BV BND1      arc_1_19_9
 UP BND1      load_1_19_9  25
 BV BND1      arc_1_19_14
 UP BND1      load_1_19_14  25
 BV BND1      arc_1_19_15
 UP BND1      load_1_19_15  25
 BV BND1      arc_1_19_16
 UP BND1      load_1_19_16  25
 BV BND1      arc_1_19_17
 UP BND1      load_1_19_17  25
 BV BND1      arc_1_19_18
 UP BND1      load_1_19_18  25
 BV BND1      arc_1_19_20
 UP BND1      load_1_19_20  25
 BV BND1      arc_1_19_21
 UP BND1      load_1_19_21  25
 BV BND1      arc_1_20_0
 UP BND1      load_1_20_0  25
 BV BND1      arc_1_20_5
 UP BND1      load_1_20_5  25
 BV BND1      arc_1_20_6
 UP BND1      load_1_20_6  25
 BV BND1      arc_1_20_7
 UP BND1      load_1_20_7  25
 BV BND1      arc_1_20_8
 UP BND1      load_1_20_8  25
 BV BND1      arc_1_20_9
 UP BND1      load_1_20_9  25
 BV BND1      arc_1_20_14
 UP BND1      load_1_20_14  25
 BV BND1      arc_1_20_15
 UP BND1      load_1_20_15  25
 BV BND1      arc_1_20_16
 UP BND1      load_1_20_16  25
 BV BND1      arc_1_20_17
 UP BND1      load_1_20_17  25
 BV BND1      arc_1_20_18
 UP BND1      load_1_20_18  25
 BV BND1      arc_1_20_19
 UP BND1      load_1_20_19  25
 BV BND1      arc_1_20_21
 UP BND1      load_1_20_21  25
 BV BND1      arc_1_21_0
 UP BND1      load_1_21_0  25
 BV BND1      arc_1_21_5
 UP BND1      load_1_21_5  25
 BV BND1      arc_1_21_6
 UP BND1      load_1_21_6  25
 BV BND1      arc_1_21_7
 UP BND1      load_1_21_7  25
 BV BND1      arc_1_21_8
 UP BND1      load_1_21_8  25
 BV BND1      arc_1_21_9
 UP BND1      load_1_21_9  25
 BV BND1      arc_1_21_14
 UP BND1      load_1_21_14  25
 BV BND1      arc_1_21_15
 UP BND1      load_1_21_15  25
 BV BND1      arc_1_21_16
 UP BND1      load_1_21_16  25
 BV BND1      arc_1_21_17
 UP BND1      load_1_21_17  25
 BV BND1      arc_1_21_18
 UP BND1      load_1_21_18  25
 BV BND1      arc_1_21_19
 UP BND1      load_1_21_19  25
 BV BND1      arc_1_21_20
 UP BND1      load_1_21_20  25
 FX BND1      visit_2_10  1
 UP BND1      order_2_10  12
 FX BND1      visit_2_11  1
 UP BND1      order_2_11  12
 FX BND1      visit_2_12  1
 UP BND1      order_2_12  12
 FX BND1      visit_2_13  1
 UP BND1      order_2_13  12
 UP BND1      visit_2_14  1
 UP BND1      order_2_14  12
 UP BND1      visit_2_15  1
 UP BND1      order_2_15  12
 UP BND1      visit_2_16  1
 UP BND1      order_2_16  12
 UP BND1      visit_2_17  1
 UP BND1      order_2_17  12
 UP BND1      visit_2_18  1
 UP BND1      order_2_18  12
 UP BND1      visit_2_19  1
 UP BND1      order_2_19  12
 UP BND1      visit_2_20  1
 UP BND1      order_2_20  12
 UP BND1      visit_2_21  1
 UP BND1      order_2_21  12
 BV BND1      arc_2_0_0
 FX BND1      load_2_0_0  0
 BV BND1      arc_2_0_10
 FX BND1      load_2_0_10  0
 BV BND1      arc_2_0_11
 FX BND1      load_2_0_11  0
 BV BND1      arc_2_0_12
 FX BND1      load_2_0_12  0
 BV BND1      arc_2_0_13
 FX BND1      load_2_0_13  0
 BV BND1      arc_2_0_14
 FX BND1      load_2_0_14  0
 BV BND1      arc_2_0_15
 FX BND1      load_2_0_15  0
 BV BND1      arc_2_0_16
 FX BND1      load_2_0_16  0
 BV BND1      arc_2_0_17
 FX BND1      load_2_0_17  0
 BV BND1      arc_2_0_18
 FX BND1      load_2_0_18  0
 BV BND1      arc_2_0_19
 FX BND1      load_2_0_19  0
 BV BND1      arc_2_0_20
 FX BND1      load_2_0_20  0
 BV BND1      arc_2_0_21
 FX BND1      load_2_0_21  0
 BV BND1      arc_2_10_0
 UP BND1      load_2_10_0  30
 BV BND1      arc_2_10_11
 UP BND1      load_2_10_11  30
 BV BND1      arc_2_10_12
 UP BND1      load_2_10_12  30
 BV BND1      arc_2_10_13
 UP BND1      load_2_10_13  30
 BV BND1      arc_2_10_14
 UP BND1      load_2_10_14  30
 BV BND1      arc_2_10_15
 UP BND1      load_2_10_15  30
 BV BND1      arc_2_10_16
 UP BND1      load_2_10_16  30
 BV BND1      arc_2_10_17
 UP BND1      load_2_10_17  30
 BV BND1      arc_2_10_18
 UP BND1      load_2_10_18  30
 BV BND1      arc_2_10_19
 UP BND1      load_2_10_19  30
 BV BND1      arc_2_10_20
 UP BND1      load_2_10_20  30
 BV BND1      arc_2_10_21
 UP BND1      load_2_10_21  30
 BV BND1      arc_2_11_0
 UP BND1      load_2_11_0  30
 BV BND1      arc_2_11_10
 UP BND1      load_2_11_10  30
 BV BND1      arc_2_11_12
 UP BND1      load_2_11_12  30
 BV BND1      arc_2_11_13
 UP BND1      load_2_11_13  30
 BV BND1      arc_2_11_14
 UP BND1      load_2_11_14  30
 BV BND1      arc_2_11_15
 UP BND1      load_2_11_15  30
 BV BND1      arc_2_11_16
 UP BND1      load_2_11_16  30
 BV BND1      arc_2_11_17
 UP BND1      load_2_11_17  30
 BV BND1      arc_2_11_18
 UP BND1      load_2_11_18  30
 BV BND1      arc_2_11_19
 UP BND1      load_2_11_19  30
 BV BND1      arc_2_11_20
 UP BND1      load_2_11_20  30
 BV BND1      arc_2_11_21
 UP BND1      load_2_11_21  30
 BV BND1      arc_2_12_0
 UP BND1      load_2_12_0  30
 BV BND1      arc_2_12_10
 UP BND1      load_2_12_10  30
 BV BND1      arc_2_12_11
 UP BND1      load_2_12_11  30
 BV BND1      arc_2_12_13
 UP BND1      load_2_12_13  30
 BV BND1      arc_2_12_14
 UP BND1      load_2_12_14  30
 BV BND1      arc_2_12_15
 UP BND1      load_2_12_15  30
 BV BND1      arc_2_12_16
 UP BND1      load_2_12_16  30
 BV BND1      arc_2_12_17
 UP BND1      load_2_12_17  30
 BV BND1      arc_2_12_18
 UP BND1      load_2_12_18  30
 BV BND1      arc_2_12_19
 UP BND1      load_2_12_19  30
 BV BND1      arc_2_12_20
 UP BND1      load_2_12_20  30
 BV BND1      arc_2_12_21
 UP BND1      load_2_12_21  30
 BV BND1      arc_2_13_0
 UP BND1      load_2_13_0  30
 BV BND1      arc_2_13_10
 UP BND1      load_2_13_10  30
 BV BND1      arc_2_13_11
 UP BND1      load_2_13_11  30
 BV BND1      arc_2_13_12
 UP BND1      load_2_13_12  30
 BV BND1      arc_2_13_14
 UP BND1      load_2_13_14  30
 BV BND1      arc_2_13_15
 UP BND1      load_2_13_15  30
 BV BND1      arc_2_13_16
 UP BND1      load_2_13_16  30
 BV BND1      arc_2_13_17
 UP BND1      load_2_13_17  30
 BV BND1      arc_2_13_18
 UP BND1      load_2_13_18  30
 BV BND1      arc_2_13_19
 UP BND1      load_2_13_19  30
 BV BND1      arc_2_13_20
 UP BND1      load_2_13_20  30
 BV BND1      arc_2_13_21
 UP BND1      load_2_13_21  30
 BV BND1      arc_2_14_0
 UP BND1      load_2_14_0  30
 BV BND1      arc_2_14_10
 UP BND1      load_2_14_10  30
 BV BND1      arc_2_14_11
 UP BND1      load_2_14_11  30
 BV BND1      arc_2_14_12
 UP BND1      load_2_14_12  30
 BV BND1      arc_2_14_13
 UP BND1      load_2_14_13  30
 BV BND1      arc_2_14_15
 UP BND1      load_2_14_15  30
 BV BND1      arc_2_14_16
 UP BND1      load_2_14_16  30
 BV BND1      arc_2_14_17
 UP BND1      load_2_14_17  30
 BV BND1      arc_2_14_18
 UP BND1      load_2_14_18  30
 BV BND1      arc_2_14_19
 UP BND1      load_2_14_19  30
 BV BND1      arc_2_14_20
 UP BND1      load_2_14_20  30
 BV BND1      arc_2_14_21
 UP BND1      load_2_14_21  30
 BV BND1      arc_2_15_0
 UP BND1      load_2_15_0  30
 BV BND1      arc_2_15_10
 UP BND1      load_2_15_10  30
 BV BND1      arc_2_15_11
 UP BND1      load_2_15_11  30
 BV BND1      arc_2_15_12
 UP BND1      load_2_15_12  30
 BV BND1      arc_2_15_13
 UP BND1      load_2_15_13  30
 BV BND1      arc_2_15_14
 UP BND1      load_2_15_14  30
 BV BND1      arc_2_15_16
 UP BND1      load_2_15_16  30
 BV BND1      arc_2_15_17
 UP BND1      load_2_15_17  30
 BV BND1      arc_2_15_18
 UP BND1      load_2_15_18  30
 BV BND1      arc_2_15_19
 UP BND1      load_2_15_19  30
 BV BND1      arc_2_15_20
 UP BND1      load_2_15_20  30
 BV BND1      arc_2_15_21
 UP BND1      load_2_15_21  30
 BV BND1      arc_2_16_0
 UP BND1      load_2_16_0  30
 BV BND1      arc_2_16_10
 UP BND1      load_2_16_10  30
 BV BND1      arc_2_16_11
 UP BND1      load_2_16_11  30
 BV BND1      arc_2_16_12
 UP BND1      load_2_16_12  30
 BV BND1      arc_2_16_13
 UP BND1      load_2_16_13  30
 BV BND1      arc_2_16_14
 UP BND1      load_2_16_14  30
 BV BND1      arc_2_16_15
 UP BND1      load_2_16_15  30
 BV BND1      arc_2_16_17
 UP BND1      load_2_16_17  30
 BV BND1      arc_2_16_18
 UP BND1      load_2_16_18  30
 BV BND1      arc_2_16_19
 UP BND1      load_2_16_19  30
 BV BND1      arc_2_16_20
 UP BND1      load_2_16_20  30
 BV BND1      arc_2_16_21
 UP BND1      load_2_16_21  30
 BV BND1      arc_2_17_0
 UP BND1      load_2_17_0  30
 BV BND1      arc_2_17_10
 UP BND1      load_2_17_10  30
 BV BND1      arc_2_17_11
 UP BND1      load_2_17_11  30
 BV BND1      arc_2_17_12
 UP BND1      load_2_17_12  30
 BV BND1      arc_2_17_13
 UP BND1      load_2_17_13  30
 BV BND1      arc_2_17_14
 UP BND1      load_2_17_14  30
 BV BND1      arc_2_17_15
 UP BND1      load_2_17_15  30
 BV BND1      arc_2_17_16
 UP BND1      load_2_17_16  30
 BV BND1      arc_2_17_18
 UP BND1      load_2_17_18  30
 BV BND1      arc_2_17_19
 UP BND1      load_2_17_19  30
 BV BND1      arc_2_17_20
 UP BND1      load_2_17_20  30
 BV BND1      arc_2_17_21
 UP BND1      load_2_17_21  30
 BV BND1      arc_2_18_0
 UP BND1      load_2_18_0  30
 BV BND1      arc_2_18_10
 UP BND1      load_2_18_10  30
 BV BND1      arc_2_18_11
 UP BND1      load_2_18_11  30
 BV BND1      arc_2_18_12
 UP BND1      load_2_18_12  30
 BV BND1      arc_2_18_13
 UP BND1      load_2_18_13  30
 BV BND1      arc_2_18_14
 UP BND1      load_2_18_14  30
 BV BND1      arc_2_18_15
 UP BND1      load_2_18_15  30
 BV BND1      arc_2_18_16
 UP BND1      load_2_18_16  30
 BV BND1      arc_2_18_17
 UP BND1      load_2_18_17  30
 BV BND1      arc_2_18_19
 UP BND1      load_2_18_19  30
 BV BND1      arc_2_18_20
 UP BND1      load_2_18_20  30
 BV BND1      arc_2_18_21
 UP BND1      load_2_18_21  30
 BV BND1      arc_2_19_0
 UP BND1      load_2_19_0  30
 BV BND1      arc_2_19_10
 UP BND1      load_2_19_10  30
 BV BND1      arc_2_19_11
 UP BND1      load_2_19_11  30
 BV BND1      arc_2_19_12
 UP BND1      load_2_19_12  30
 BV BND1      arc_2_19_13
 UP BND1      load_2_19_13  30
 BV BND1      arc_2_19_14
 UP BND1      load_2_19_14  30
 BV BND1      arc_2_19_15
 UP BND1      load_2_19_15  30
 BV BND1      arc_2_19_16
 UP BND1      load_2_19_16  30
 BV BND1      arc_2_19_17
 UP BND1      load_2_19_17  30
 BV BND1      arc_2_19_18
 UP BND1      load_2_19_18  30
 BV BND1      arc_2_19_20
 UP BND1      load_2_19_20  30
 BV BND1      arc_2_19_21
 UP BND1      load_2_19_21  30
 BV BND1      arc_2_20_0
 UP BND1      load_2_20_0  30
 BV BND1      arc_2_20_10
 UP BND1      load_2_20_10  30
 BV BND1      arc_2_20_11
 UP BND1      load_2_20_11  30
 BV BND1      arc_2_20_12
 UP BND1      load_2_20_12  30
 BV BND1      arc_2_20_13
 UP BND1      load_2_20_13  30
 BV BND1      arc_2_20_14
 UP BND1      load_2_20_14  30
 BV BND1      arc_2_20_15
 UP BND1      load_2_20_15  30
 BV BND1      arc_2_20_16
 UP BND1      load_2_20_16  30
 BV BND1      arc_2_20_17
 UP BND1      load_2_20_17  30
 BV BND1      arc_2_20_18
 UP BND1      load_2_20_18  30
 BV BND1      arc_2_20_19
 UP BND1      load_2_20_19  30
 BV BND1      arc_2_20_21
 UP BND1      load_2_20_21  30
 BV BND1      arc_2_21_0
 UP BND1      load_2_21_0  30
 BV BND1      arc_2_21_10
 UP BND1      load_2_21_10  30
 BV BND1      arc_2_21_11
 UP BND1      load_2_21_11  30
 BV BND1      arc_2_21_12
 UP BND1      load_2_21_12  30
 BV BND1      arc_2_21_13
 UP BND1      load_2_21_13  30
 BV BND1      arc_2_21_14
 UP BND1      load_2_21_14  30
 BV BND1      arc_2_21_15
 UP BND1      load_2_21_15  30
 BV BND1      arc_2_21_16
 UP BND1      load_2_21_16  30
 BV BND1      arc_2_21_17
 UP BND1      load_2_21_17  30
 BV BND1      arc_2_21_18
 UP BND1      load_2_21_18  30
 BV BND1      arc_2_21_19
 UP BND1      load_2_21_19  30
 BV BND1      arc_2_21_20
 UP BND1      load_2_21_20  30
ENDATA
