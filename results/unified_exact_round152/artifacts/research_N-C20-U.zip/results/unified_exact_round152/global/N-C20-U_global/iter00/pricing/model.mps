* Signature: 0xf32b5a1ababb4015
NAME 
ROWS
 N  OBJ
 E  onehot_1
 E  mass_1  
 G  R2      
 L  R3      
 G  R4      
 L  R5      
 G  R6      
 L  R7      
 G  R8      
 L  R9      
 G  R10     
 L  R11     
 G  R12     
 L  R13     
 G  R14     
 L  R15     
 G  R16     
 L  R17     
 G  R18     
 L  R19     
 G  R20     
 L  R21     
 G  R22     
 L  R23     
 G  R24     
 L  R25     
 G  R26     
 L  R27     
 G  R28     
 L  R29     
 G  R30     
 L  R31     
 G  R32     
 L  R33     
 G  R34     
 L  R35     
 G  R36     
 L  R37     
 G  R38     
 L  R39     
 G  R40     
 L  R41     
 G  R42     
 L  R43     
 G  R44     
 L  R45     
 G  R46     
 L  R47     
 G  R48     
 L  R49     
 G  R50     
 L  R51     
 E  normalized_inventory_1
 E  normalized_ratio_1
 E  onehot_2
 E  mass_2  
 G  R56     
 L  R57     
 G  R58     
 L  R59     
 G  R60     
 L  R61     
 G  R62     
 L  R63     
 G  R64     
 L  R65     
 G  R66     
 L  R67     
 G  R68     
 L  R69     
 G  R70     
 L  R71     
 G  R72     
 L  R73     
 G  R74     
 L  R75     
 G  R76     
 L  R77     
 G  R78     
 L  R79     
 G  R80     
 L  R81     
 G  R82     
 L  R83     
 G  R84     
 L  R85     
 G  R86     
 L  R87     
 G  R88     
 L  R89     
 G  R90     
 L  R91     
 G  R92     
 L  R93     
 G  R94     
 L  R95     
 G  R96     
 L  R97     
 G  R98     
 L  R99     
 G  R100    
 L  R101    
 G  R102    
 L  R103    
 G  R104    
 L  R105    
 G  R106    
 L  R107    
 E  normalized_inventory_2
 E  normalized_ratio_2
 E  onehot_3
 E  mass_3  
 G  R112    
 L  R113    
 G  R114    
 L  R115    
 G  R116    
 L  R117    
 G  R118    
 L  R119    
 G  R120    
 L  R121    
 G  R122    
 L  R123    
 G  R124    
 L  R125    
 G  R126    
 L  R127    
 G  R128    
 L  R129    
 G  R130    
 L  R131    
 G  R132    
 L  R133    
 G  R134    
 L  R135    
 G  R136    
 L  R137    
 G  R138    
 L  R139    
 G  R140    
 L  R141    
 G  R142    
 L  R143    
 G  R144    
 L  R145    
 G  R146    
 L  R147    
 G  R148    
 L  R149    
 G  R150    
 L  R151    
 G  R152    
 L  R153    
 G  R154    
 L  R155    
 G  R156    
 L  R157    
 G  R158    
 L  R159    
 G  R160    
 L  R161    
 G  R162    
 L  R163    
 G  R164    
 L  R165    
 G  R166    
 L  R167    
 E  normalized_inventory_3
 E  normalized_ratio_3
 E  onehot_4
 E  mass_4  
 G  R172    
 L  R173    
 G  R174    
 L  R175    
 G  R176    
 L  R177    
 G  R178    
 L  R179    
 G  R180    
 L  R181    
 G  R182    
 L  R183    
 G  R184    
 L  R185    
 G  R186    
 L  R187    
 G  R188    
 L  R189    
 G  R190    
 L  R191    
 G  R192    
 L  R193    
 G  R194    
 L  R195    
 G  R196    
 L  R197    
 G  R198    
 L  R199    
 G  R200    
 L  R201    
 G  R202    
 L  R203    
 G  R204    
 L  R205    
 G  R206    
 L  R207    
 G  R208    
 L  R209    
 G  R210    
 L  R211    
 G  R212    
 L  R213    
 G  R214    
 L  R215    
 G  R216    
 L  R217    
 G  R218    
 L  R219    
 G  R220    
 L  R221    
 E  normalized_inventory_4
 E  normalized_ratio_4
 E  onehot_5
 E  mass_5  
 G  R226    
 L  R227    
 G  R228    
 L  R229    
 G  R230    
 L  R231    
 G  R232    
 L  R233    
 G  R234    
 L  R235    
 G  R236    
 L  R237    
 G  R238    
 L  R239    
 G  R240    
 L  R241    
 G  R242    
 L  R243    
 G  R244    
 L  R245    
 G  R246    
 L  R247    
 G  R248    
 L  R249    
 G  R250    
 L  R251    
 G  R252    
 L  R253    
 G  R254    
 L  R255    
 G  R256    
 L  R257    
 G  R258    
 L  R259    
 G  R260    
 L  R261    
 G  R262    
 L  R263    
 G  R264    
 L  R265    
 G  R266    
 L  R267    
 G  R268    
 L  R269    
 E  normalized_inventory_5
 E  normalized_ratio_5
 E  onehot_6
 E  mass_6  
 G  R274    
 L  R275    
 G  R276    
 L  R277    
 G  R278    
 L  R279    
 G  R280    
 L  R281    
 G  R282    
 L  R283    
 G  R284    
 L  R285    
 G  R286    
 L  R287    
 G  R288    
 L  R289    
 G  R290    
 L  R291    
 G  R292    
 L  R293    
 G  R294    
 L  R295    
 G  R296    
 L  R297    
 G  R298    
 L  R299    
 G  R300    
 L  R301    
 G  R302    
 L  R303    
 G  R304    
 L  R305    
 G  R306    
 L  R307    
 G  R308    
 L  R309    
 G  R310    
 L  R311    
 G  R312    
 L  R313    
 G  R314    
 L  R315    
 G  R316    
 L  R317    
 G  R318    
 L  R319    
 G  R320    
 L  R321    
 G  R322    
 L  R323    
 E  normalized_inventory_6
 E  normalized_ratio_6
 E  onehot_7
 E  mass_7  
 G  R328    
 L  R329    
 G  R330    
 L  R331    
 G  R332    
 L  R333    
 G  R334    
 L  R335    
 G  R336    
 L  R337    
 G  R338    
 L  R339    
 G  R340    
 L  R341    
 G  R342    
 L  R343    
 G  R344    
 L  R345    
 G  R346    
 L  R347    
 G  R348    
 L  R349    
 G  R350    
 L  R351    
 G  R352    
 L  R353    
 G  R354    
 L  R355    
 G  R356    
 L  R357    
 G  R358    
 L  R359    
 G  R360    
 L  R361    
 G  R362    
 L  R363    
 G  R364    
 L  R365    
 G  R366    
 L  R367    
 G  R368    
 L  R369    
 G  R370    
 L  R371    
 G  R372    
 L  R373    
 E  normalized_inventory_7
 E  normalized_ratio_7
 E  onehot_8
 E  mass_8  
 G  R378    
 L  R379    
 G  R380    
 L  R381    
 G  R382    
 L  R383    
 G  R384    
 L  R385    
 G  R386    
 L  R387    
 G  R388    
 L  R389    
 G  R390    
 L  R391    
 G  R392    
 L  R393    
 G  R394    
 L  R395    
 G  R396    
 L  R397    
 G  R398    
 L  R399    
 G  R400    
 L  R401    
 G  R402    
 L  R403    
 G  R404    
 L  R405    
 G  R406    
 L  R407    
 G  R408    
 L  R409    
 G  R410    
 L  R411    
 G  R412    
 L  R413    
 G  R414    
 L  R415    
 G  R416    
 L  R417    
 G  R418    
 L  R419    
 G  R420    
 L  R421    
 E  normalized_inventory_8
 E  normalized_ratio_8
 E  onehot_9
 E  mass_9  
 G  R426    
 L  R427    
 G  R428    
 L  R429    
 G  R430    
 L  R431    
 G  R432    
 L  R433    
 G  R434    
 L  R435    
 G  R436    
 L  R437    
 G  R438    
 L  R439    
 G  R440    
 L  R441    
 G  R442    
 L  R443    
 G  R444    
 L  R445    
 G  R446    
 L  R447    
 G  R448    
 L  R449    
 G  R450    
 L  R451    
 G  R452    
 L  R453    
 G  R454    
 L  R455    
 G  R456    
 L  R457    
 G  R458    
 L  R459    
 G  R460    
 L  R461    
 G  R462    
 L  R463    
 G  R464    
 L  R465    
 E  normalized_inventory_9
 E  normalized_ratio_9
 E  onehot_10
 E  mass_10 
 G  R470    
 L  R471    
 G  R472    
 L  R473    
 G  R474    
 L  R475    
 G  R476    
 L  R477    
 G  R478    
 L  R479    
 G  R480    
 L  R481    
 G  R482    
 L  R483    
 G  R484    
 L  R485    
 G  R486    
 L  R487    
 G  R488    
 L  R489    
 G  R490    
 L  R491    
 G  R492    
 L  R493    
 G  R494    
 L  R495    
 G  R496    
 L  R497    
 G  R498    
 L  R499    
 G  R500    
 L  R501    
 G  R502    
 L  R503    
 G  R504    
 L  R505    
 G  R506    
 L  R507    
 G  R508    
 L  R509    
 G  R510    
 L  R511    
 G  R512    
 L  R513    
 G  R514    
 L  R515    
 G  R516    
 L  R517    
 G  R518    
 L  R519    
 G  R520    
 L  R521    
 G  R522    
 L  R523    
 G  R524    
 L  R525    
 G  R526    
 L  R527    
 G  R528    
 L  R529    
 E  normalized_inventory_10
 E  normalized_ratio_10
 E  onehot_11
 E  mass_11 
 G  R534    
 L  R535    
 G  R536    
 L  R537    
 G  R538    
 L  R539    
 G  R540    
 L  R541    
 G  R542    
 L  R543    
 G  R544    
 L  R545    
 G  R546    
 L  R547    
 G  R548    
 L  R549    
 G  R550    
 L  R551    
 G  R552    
 L  R553    
 G  R554    
 L  R555    
 G  R556    
 L  R557    
 G  R558    
 L  R559    
 G  R560    
 L  R561    
 G  R562    
 L  R563    
 G  R564    
 L  R565    
 G  R566    
 L  R567    
 G  R568    
 L  R569    
 G  R570    
 L  R571    
 G  R572    
 L  R573    
 G  R574    
 L  R575    
 G  R576    
 L  R577    
 G  R578    
 L  R579    
 G  R580    
 L  R581    
 G  R582    
 L  R583    
 G  R584    
 L  R585    
 G  R586    
 L  R587    
 G  R588    
 L  R589    
 G  R590    
 L  R591    
 G  R592    
 L  R593    
 G  R594    
 L  R595    
 G  R596    
 L  R597    
 E  normalized_inventory_11
 E  normalized_ratio_11
 E  onehot_12
 E  mass_12 
 G  R602    
 L  R603    
 G  R604    
 L  R605    
 G  R606    
 L  R607    
 G  R608    
 L  R609    
 G  R610    
 L  R611    
 G  R612    
 L  R613    
 G  R614    
 L  R615    
 G  R616    
 L  R617    
 G  R618    
 L  R619    
 G  R620    
 L  R621    
 G  R622    
 L  R623    
 G  R624    
 L  R625    
 G  R626    
 L  R627    
 G  R628    
 L  R629    
 G  R630    
 L  R631    
 G  R632    
 L  R633    
 G  R634    
 L  R635    
 G  R636    
 L  R637    
 G  R638    
 L  R639    
 G  R640    
 L  R641    
 E  normalized_inventory_12
 E  normalized_ratio_12
 E  onehot_13
 E  mass_13 
 G  R646    
 L  R647    
 G  R648    
 L  R649    
 G  R650    
 L  R651    
 G  R652    
 L  R653    
 G  R654    
 L  R655    
 G  R656    
 L  R657    
 G  R658    
 L  R659    
 G  R660    
 L  R661    
 G  R662    
 L  R663    
 G  R664    
 L  R665    
 G  R666    
 L  R667    
 G  R668    
 L  R669    
 G  R670    
 L  R671    
 G  R672    
 L  R673    
 G  R674    
 L  R675    
 G  R676    
 L  R677    
 G  R678    
 L  R679    
 G  R680    
 L  R681    
 G  R682    
 L  R683    
 G  R684    
 L  R685    
 G  R686    
 L  R687    
 G  R688    
 L  R689    
 G  R690    
 L  R691    
 G  R692    
 L  R693    
 G  R694    
 L  R695    
 G  R696    
 L  R697    
 E  normalized_inventory_13
 E  normalized_ratio_13
 E  onehot_14
 E  mass_14 
 G  R702    
 L  R703    
 G  R704    
 L  R705    
 G  R706    
 L  R707    
 G  R708    
 L  R709    
 G  R710    
 L  R711    
 G  R712    
 L  R713    
 G  R714    
 L  R715    
 G  R716    
 L  R717    
 G  R718    
 L  R719    
 G  R720    
 L  R721    
 G  R722    
 L  R723    
 G  R724    
 L  R725    
 G  R726    
 L  R727    
 G  R728    
 L  R729    
 G  R730    
 L  R731    
 G  R732    
 L  R733    
 G  R734    
 L  R735    
 G  R736    
 L  R737    
 G  R738    
 L  R739    
 G  R740    
 L  R741    
 G  R742    
 L  R743    
 G  R744    
 L  R745    
 G  R746    
 L  R747    
 G  R748    
 L  R749    
 E  normalized_inventory_14
 E  normalized_ratio_14
 E  onehot_15
 E  mass_15 
 G  R754    
 L  R755    
 G  R756    
 L  R757    
 G  R758    
 L  R759    
 G  R760    
 L  R761    
 G  R762    
 L  R763    
 G  R764    
 L  R765    
 G  R766    
 L  R767    
 G  R768    
 L  R769    
 G  R770    
 L  R771    
 G  R772    
 L  R773    
 G  R774    
 L  R775    
 G  R776    
 L  R777    
 G  R778    
 L  R779    
 G  R780    
 L  R781    
 G  R782    
 L  R783    
 G  R784    
 L  R785    
 G  R786    
 L  R787    
 G  R788    
 L  R789    
 G  R790    
 L  R791    
 G  R792    
 L  R793    
 G  R794    
 L  R795    
 G  R796    
 L  R797    
 G  R798    
 L  R799    
 G  R800    
 L  R801    
 G  R802    
 L  R803    
 G  R804    
 L  R805    
 G  R806    
 L  R807    
 G  R808    
 L  R809    
 E  normalized_inventory_15
 E  normalized_ratio_15
 E  onehot_16
 E  mass_16 
 G  R814    
 L  R815    
 G  R816    
 L  R817    
 G  R818    
 L  R819    
 G  R820    
 L  R821    
 G  R822    
 L  R823    
 G  R824    
 L  R825    
 G  R826    
 L  R827    
 G  R828    
 L  R829    
 G  R830    
 L  R831    
 G  R832    
 L  R833    
 G  R834    
 L  R835    
 G  R836    
 L  R837    
 G  R838    
 L  R839    
 G  R840    
 L  R841    
 G  R842    
 L  R843    
 G  R844    
 L  R845    
 G  R846    
 L  R847    
 G  R848    
 L  R849    
 G  R850    
 L  R851    
 G  R852    
 L  R853    
 G  R854    
 L  R855    
 G  R856    
 L  R857    
 G  R858    
 L  R859    
 E  normalized_inventory_16
 E  normalized_ratio_16
 E  onehot_17
 E  mass_17 
 G  R864    
 L  R865    
 G  R866    
 L  R867    
 G  R868    
 L  R869    
 G  R870    
 L  R871    
 G  R872    
 L  R873    
 G  R874    
 L  R875    
 G  R876    
 L  R877    
 G  R878    
 L  R879    
 G  R880    
 L  R881    
 G  R882    
 L  R883    
 G  R884    
 L  R885    
 G  R886    
 L  R887    
 G  R888    
 L  R889    
 G  R890    
 L  R891    
 G  R892    
 L  R893    
 G  R894    
 L  R895    
 G  R896    
 L  R897    
 G  R898    
 L  R899    
 G  R900    
 L  R901    
 G  R902    
 L  R903    
 E  normalized_inventory_17
 E  normalized_ratio_17
 E  onehot_18
 E  mass_18 
 G  R908    
 L  R909    
 G  R910    
 L  R911    
 G  R912    
 L  R913    
 G  R914    
 L  R915    
 G  R916    
 L  R917    
 G  R918    
 L  R919    
 G  R920    
 L  R921    
 G  R922    
 L  R923    
 G  R924    
 L  R925    
 G  R926    
 L  R927    
 G  R928    
 L  R929    
 G  R930    
 L  R931    
 G  R932    
 L  R933    
 G  R934    
 L  R935    
 G  R936    
 L  R937    
 G  R938    
 L  R939    
 G  R940    
 L  R941    
 G  R942    
 L  R943    
 G  R944    
 L  R945    
 G  R946    
 L  R947    
 G  R948    
 L  R949    
 G  R950    
 L  R951    
 G  R952    
 L  R953    
 E  normalized_inventory_18
 E  normalized_ratio_18
 E  onehot_19
 E  mass_19 
 G  R958    
 L  R959    
 G  R960    
 L  R961    
 G  R962    
 L  R963    
 G  R964    
 L  R965    
 G  R966    
 L  R967    
 G  R968    
 L  R969    
 G  R970    
 L  R971    
 G  R972    
 L  R973    
 G  R974    
 L  R975    
 G  R976    
 L  R977    
 G  R978    
 L  R979    
 G  R980    
 L  R981    
 G  R982    
 L  R983    
 G  R984    
 L  R985    
 G  R986    
 L  R987    
 G  R988    
 L  R989    
 G  R990    
 L  R991    
 G  R992    
 L  R993    
 G  R994    
 L  R995    
 G  R996    
 L  R997    
 G  R998    
 L  R999    
 G  R1000   
 L  R1001   
 G  R1002   
 L  R1003   
 G  R1004   
 L  R1005   
 E  normalized_inventory_19
 E  normalized_ratio_19
 E  onehot_20
 E  mass_20 
 G  R1010   
 L  R1011   
 G  R1012   
 L  R1013   
 G  R1014   
 L  R1015   
 G  R1016   
 L  R1017   
 G  R1018   
 L  R1019   
 G  R1020   
 L  R1021   
 G  R1022   
 L  R1023   
 G  R1024   
 L  R1025   
 G  R1026   
 L  R1027   
 G  R1028   
 L  R1029   
 G  R1030   
 L  R1031   
 G  R1032   
 L  R1033   
 G  R1034   
 L  R1035   
 G  R1036   
 L  R1037   
 G  R1038   
 L  R1039   
 G  R1040   
 L  R1041   
 G  R1042   
 L  R1043   
 G  R1044   
 L  R1045   
 G  R1046   
 L  R1047   
 G  R1048   
 L  R1049   
 G  R1050   
 L  R1051   
 G  R1052   
 L  R1053   
 G  R1054   
 L  R1055   
 G  R1056   
 L  R1057   
 E  normalized_inventory_20
 E  normalized_ratio_20
 G  hard_lower
 L  hard_upper
 E  normalization
 G  scaled_stock_lower
 L  scaled_stock_upper
 G  R1065   
 G  R1066   
 G  R1067   
 G  R1068   
 G  R1069   
 G  R1070   
 G  R1071   
 G  R1072   
 G  R1073   
 G  R1074   
 G  R1075   
 G  R1076   
 G  R1077   
 G  R1078   
 G  R1079   
 G  R1080   
 G  R1081   
 G  R1082   
 G  R1083   
 G  R1084   
 G  R1085   
 G  R1086   
 G  R1087   
 G  R1088   
 G  R1089   
 G  R1090   
 G  R1091   
 G  R1092   
 G  R1093   
 G  R1094   
 G  R1095   
 G  R1096   
 G  R1097   
 G  R1098   
 G  R1099   
 G  R1100   
 G  R1101   
 G  R1102   
 G  R1103   
 G  R1104   
 G  R1105   
 G  R1106   
 G  R1107   
 G  R1108   
 G  R1109   
 G  R1110   
 G  R1111   
 G  R1112   
 G  R1113   
 G  R1114   
 G  R1115   
 G  R1116   
 G  R1117   
 G  R1118   
 G  R1119   
 G  R1120   
 G  R1121   
 G  R1122   
 G  R1123   
 G  R1124   
 G  R1125   
 G  R1126   
 G  R1127   
 G  R1128   
 G  R1129   
 G  R1130   
 G  R1131   
 G  R1132   
 G  R1133   
 G  R1134   
 G  R1135   
 G  R1136   
 G  R1137   
 G  R1138   
 G  R1139   
 G  R1140   
 G  R1141   
 G  R1142   
 G  R1143   
 G  R1144   
 G  R1145   
 G  R1146   
 G  R1147   
 G  R1148   
 G  R1149   
 G  R1150   
 G  R1151   
 G  R1152   
 G  R1153   
 G  R1154   
 G  R1155   
 G  R1156   
 G  R1157   
 G  R1158   
 G  R1159   
 G  R1160   
 G  R1161   
 G  R1162   
 G  R1163   
 G  R1164   
 G  R1165   
 G  R1166   
 G  R1167   
 G  R1168   
 G  R1169   
 G  R1170   
 G  R1171   
 G  R1172   
 G  R1173   
 G  R1174   
 G  R1175   
 G  R1176   
 G  R1177   
 G  R1178   
 G  R1179   
 G  R1180   
 G  R1181   
 G  R1182   
 G  R1183   
 G  R1184   
 G  R1185   
 G  R1186   
 G  R1187   
 G  R1188   
 G  R1189   
 G  R1190   
 G  R1191   
 G  R1192   
 G  R1193   
 G  R1194   
 G  R1195   
 G  R1196   
 G  R1197   
 G  R1198   
 G  R1199   
 G  R1200   
 G  R1201   
 G  R1202   
 G  R1203   
 G  R1204   
 G  R1205   
 G  R1206   
 G  R1207   
 G  R1208   
 G  R1209   
 G  R1210   
 G  R1211   
 G  R1212   
 G  R1213   
 G  R1214   
 G  R1215   
 G  R1216   
 G  R1217   
 G  R1218   
 G  R1219   
 G  R1220   
 G  R1221   
 G  R1222   
 G  R1223   
 G  R1224   
 G  R1225   
 G  R1226   
 G  R1227   
 G  R1228   
 G  R1229   
 G  R1230   
 G  R1231   
 G  R1232   
 G  R1233   
 G  R1234   
 G  R1235   
 G  R1236   
 G  R1237   
 G  R1238   
 G  R1239   
 G  R1240   
 G  R1241   
 G  R1242   
 G  R1243   
 G  R1244   
 G  R1245   
 G  R1246   
 G  R1247   
 G  R1248   
 G  R1249   
 G  R1250   
 G  R1251   
 G  R1252   
 G  R1253   
 G  R1254   
 G  R1255   
 G  R1256   
 G  R1257   
 G  R1258   
 G  R1259   
 G  R1260   
 G  R1261   
 G  R1262   
 G  R1263   
 G  R1264   
 G  R1265   
 G  R1266   
 G  R1267   
 G  R1268   
 G  R1269   
 G  R1270   
 G  R1271   
 G  R1272   
 G  R1273   
 G  R1274   
 G  R1275   
 G  R1276   
 G  R1277   
 G  R1278   
 G  R1279   
 G  R1280   
 G  R1281   
 G  R1282   
 G  R1283   
 G  R1284   
 G  R1285   
 G  R1286   
 G  R1287   
 G  R1288   
 G  R1289   
 G  R1290   
 G  R1291   
 G  R1292   
 G  R1293   
 G  R1294   
 G  R1295   
 G  R1296   
 G  R1297   
 G  R1298   
 G  R1299   
 G  R1300   
 G  R1301   
 G  R1302   
 G  R1303   
 G  R1304   
 G  R1305   
 G  R1306   
 G  R1307   
 G  R1308   
 G  R1309   
 G  R1310   
 G  R1311   
 G  R1312   
 G  R1313   
 G  R1314   
 G  R1315   
 G  R1316   
 G  R1317   
 G  R1318   
 G  R1319   
 G  R1320   
 G  R1321   
 G  R1322   
 G  R1323   
 G  R1324   
 G  R1325   
 G  R1326   
 G  R1327   
 G  R1328   
 G  R1329   
 G  R1330   
 G  R1331   
 G  R1332   
 G  R1333   
 G  R1334   
 G  R1335   
 G  R1336   
 G  R1337   
 G  R1338   
 G  R1339   
 G  R1340   
 G  R1341   
 G  R1342   
 G  R1343   
 G  R1344   
 G  R1345   
 G  R1346   
 G  R1347   
 G  R1348   
 G  R1349   
 G  R1350   
 G  R1351   
 G  R1352   
 G  R1353   
 G  R1354   
 G  R1355   
 G  R1356   
 G  R1357   
 G  R1358   
 G  R1359   
 G  R1360   
 G  R1361   
 G  R1362   
 G  R1363   
 G  R1364   
 G  R1365   
 G  R1366   
 G  R1367   
 G  R1368   
 G  R1369   
 G  R1370   
 G  R1371   
 G  R1372   
 G  R1373   
 G  R1374   
 G  R1375   
 G  R1376   
 G  R1377   
 G  R1378   
 G  R1379   
 G  R1380   
 G  R1381   
 G  R1382   
 G  R1383   
 G  R1384   
 G  R1385   
 G  R1386   
 G  R1387   
 G  R1388   
 G  R1389   
 G  R1390   
 G  R1391   
 G  R1392   
 G  R1393   
 G  R1394   
 G  R1395   
 G  R1396   
 G  R1397   
 G  R1398   
 G  R1399   
 G  R1400   
 G  R1401   
 G  R1402   
 G  R1403   
 G  R1404   
 G  R1405   
 G  R1406   
 G  R1407   
 G  R1408   
 G  R1409   
 G  R1410   
 G  R1411   
 G  R1412   
 G  R1413   
 G  R1414   
 G  R1415   
 G  R1416   
 G  R1417   
 G  R1418   
 G  R1419   
 G  R1420   
 G  R1421   
 G  R1422   
 G  R1423   
 G  R1424   
 G  R1425   
 G  R1426   
 G  R1427   
 G  R1428   
 G  R1429   
 G  R1430   
 G  R1431   
 G  R1432   
 G  R1433   
 G  R1434   
 G  R1435   
 G  R1436   
 G  R1437   
 G  R1438   
 G  R1439   
 G  R1440   
 G  R1441   
 G  R1442   
 G  R1443   
 G  R1444   
 L  true_G_epigraph
 L  physical_G_upper
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    x[1,0]    OBJ       0.05
    x[1,0]    onehot_1  1
    x[1,0]    R2        -3.9145222845663033e-02
    x[1,0]    R3        -0.0680494916724233
    x[1,1]    OBJ       0.05
    x[1,1]    onehot_1  1
    x[1,1]    R4        -3.9145222845663033e-02
    x[1,1]    R5        -0.0680494916724233
    x[1,1]    hard_lower  1
    x[1,1]    hard_upper  1
    x[1,2]    OBJ       4.9999999999999996e-02
    x[1,2]    onehot_1  1
    x[1,2]    R6        -3.9145222845663033e-02
    x[1,2]    R7        -0.0680494916724233
    x[1,2]    hard_lower  2
    x[1,2]    hard_upper  2
    x[1,3]    OBJ       0.05
    x[1,3]    onehot_1  1
    x[1,3]    R8        -3.9145222845663033e-02
    x[1,3]    R9        -0.0680494916724233
    x[1,3]    hard_lower  3
    x[1,3]    hard_upper  3
    x[1,4]    OBJ       0.05
    x[1,4]    onehot_1  1
    x[1,4]    R10       -3.9145222845663033e-02
    x[1,4]    R11       -0.0680494916724233
    x[1,4]    hard_lower  4
    x[1,4]    hard_upper  4
    x[1,5]    OBJ       0.05
    x[1,5]    onehot_1  1
    x[1,5]    R12       -3.9145222845663033e-02
    x[1,5]    R13       -0.0680494916724233
    x[1,5]    hard_lower  5
    x[1,5]    hard_upper  5
    x[1,6]    OBJ       0.05
    x[1,6]    onehot_1  1
    x[1,6]    R14       -3.9145222845663033e-02
    x[1,6]    R15       -0.0680494916724233
    x[1,6]    hard_lower  6
    x[1,6]    hard_upper  6
    x[1,7]    OBJ       0.05
    x[1,7]    onehot_1  1
    x[1,7]    R16       -3.9145222845663033e-02
    x[1,7]    R17       -0.0680494916724233
    x[1,7]    hard_lower  7
    x[1,7]    hard_upper  7
    x[1,8]    OBJ       0.05
    x[1,8]    onehot_1  1
    x[1,8]    R18       -3.9145222845663033e-02
    x[1,8]    R19       -0.0680494916724233
    x[1,8]    hard_lower  8
    x[1,8]    hard_upper  8
    x[1,9]    OBJ       0.05
    x[1,9]    onehot_1  1
    x[1,9]    R20       -3.9145222845663033e-02
    x[1,9]    R21       -0.0680494916724233
    x[1,9]    hard_lower  9
    x[1,9]    hard_upper  9
    x[1,10]   OBJ       4.9999999999999996e-02
    x[1,10]   onehot_1  1
    x[1,10]   R22       -3.9145222845663033e-02
    x[1,10]   R23       -0.0680494916724233
    x[1,10]   hard_lower  10
    x[1,10]   hard_upper  10
    x[1,11]   OBJ       1.7431264764944385e-18
    x[1,11]   onehot_1  1
    x[1,11]   R24       -3.9145222845663033e-02
    x[1,11]   R25       -0.0680494916724233
    x[1,11]   hard_lower  11
    x[1,11]   hard_upper  11
    x[1,12]   OBJ       0.05
    x[1,12]   onehot_1  1
    x[1,12]   R26       -3.9145222845663033e-02
    x[1,12]   R27       -0.0680494916724233
    x[1,12]   hard_lower  12
    x[1,12]   hard_upper  12
    x[1,13]   OBJ       4.9999999999999996e-02
    x[1,13]   onehot_1  1
    x[1,13]   R28       -3.9145222845663033e-02
    x[1,13]   R29       -0.0680494916724233
    x[1,13]   hard_lower  13
    x[1,13]   hard_upper  13
    x[1,14]   OBJ       4.9999999999999996e-02
    x[1,14]   onehot_1  1
    x[1,14]   R30       -3.9145222845663033e-02
    x[1,14]   R31       -0.0680494916724233
    x[1,14]   hard_lower  14
    x[1,14]   hard_upper  14
    x[1,15]   OBJ       0.05
    x[1,15]   onehot_1  1
    x[1,15]   R32       -3.9145222845663033e-02
    x[1,15]   R33       -0.0680494916724233
    x[1,15]   hard_lower  15
    x[1,15]   hard_upper  15
    x[1,16]   OBJ       0.05
    x[1,16]   onehot_1  1
    x[1,16]   R34       -3.9145222845663033e-02
    x[1,16]   R35       -0.0680494916724233
    x[1,16]   hard_lower  16
    x[1,16]   hard_upper  16
    x[1,17]   OBJ       0.05
    x[1,17]   onehot_1  1
    x[1,17]   R36       -3.9145222845663033e-02
    x[1,17]   R37       -0.0680494916724233
    x[1,17]   hard_lower  17
    x[1,17]   hard_upper  17
    x[1,18]   OBJ       4.9999999999999996e-02
    x[1,18]   onehot_1  1
    x[1,18]   R38       -3.9145222845663033e-02
    x[1,18]   R39       -0.0680494916724233
    x[1,18]   hard_lower  18
    x[1,18]   hard_upper  18
    x[1,19]   OBJ       0.05
    x[1,19]   onehot_1  1
    x[1,19]   R40       -3.9145222845663033e-02
    x[1,19]   R41       -0.0680494916724233
    x[1,19]   hard_lower  19
    x[1,19]   hard_upper  19
    x[1,20]   OBJ       0.05
    x[1,20]   onehot_1  1
    x[1,20]   R42       -3.9145222845663033e-02
    x[1,20]   R43       -0.0680494916724233
    x[1,20]   hard_lower  20
    x[1,20]   hard_upper  20
    x[1,21]   OBJ       0.05
    x[1,21]   onehot_1  1
    x[1,21]   R44       -3.9145222845663033e-02
    x[1,21]   R45       -0.0680494916724233
    x[1,21]   hard_lower  21
    x[1,21]   hard_upper  21
    x[1,22]   OBJ       0.05
    x[1,22]   onehot_1  1
    x[1,22]   R46       -3.9145222845663033e-02
    x[1,22]   R47       -0.0680494916724233
    x[1,22]   hard_lower  22
    x[1,22]   hard_upper  22
    x[1,23]   OBJ       5.0000000000000010e-02
    x[1,23]   onehot_1  1
    x[1,23]   R48       -3.9145222845663033e-02
    x[1,23]   R49       -0.0680494916724233
    x[1,23]   hard_lower  23
    x[1,23]   hard_upper  23
    x[1,24]   OBJ       5.0000000000000010e-02
    x[1,24]   onehot_1  1
    x[1,24]   R50       -3.9145222845663033e-02
    x[1,24]   R51       -0.0680494916724233
    x[1,24]   hard_lower  24
    x[1,24]   hard_upper  24
    x[2,0]    OBJ       5.0000000000000010e-02
    x[2,0]    onehot_2  1
    x[2,0]    R56       -3.9145222845663033e-02
    x[2,0]    R57       -0.0680494916724233
    x[2,1]    OBJ       0.05
    x[2,1]    onehot_2  1
    x[2,1]    R58       -3.9145222845663033e-02
    x[2,1]    R59       -0.0680494916724233
    x[2,1]    hard_lower  1
    x[2,1]    hard_upper  1
    x[2,2]    OBJ       0.05
    x[2,2]    onehot_2  1
    x[2,2]    R60       -3.9145222845663033e-02
    x[2,2]    R61       -0.0680494916724233
    x[2,2]    hard_lower  2
    x[2,2]    hard_upper  2
    x[2,3]    OBJ       0.05
    x[2,3]    onehot_2  1
    x[2,3]    R62       -3.9145222845663033e-02
    x[2,3]    R63       -0.0680494916724233
    x[2,3]    hard_lower  3
    x[2,3]    hard_upper  3
    x[2,4]    OBJ       0.05
    x[2,4]    onehot_2  1
    x[2,4]    R64       -3.9145222845663033e-02
    x[2,4]    R65       -0.0680494916724233
    x[2,4]    hard_lower  4
    x[2,4]    hard_upper  4
    x[2,5]    OBJ       0.05
    x[2,5]    onehot_2  1
    x[2,5]    R66       -3.9145222845663033e-02
    x[2,5]    R67       -0.0680494916724233
    x[2,5]    hard_lower  5
    x[2,5]    hard_upper  5
    x[2,6]    OBJ       5.0000000000000010e-02
    x[2,6]    onehot_2  1
    x[2,6]    R68       -3.9145222845663033e-02
    x[2,6]    R69       -0.0680494916724233
    x[2,6]    hard_lower  6
    x[2,6]    hard_upper  6
    x[2,7]    OBJ       5.0000000000000010e-02
    x[2,7]    onehot_2  1
    x[2,7]    R70       -3.9145222845663033e-02
    x[2,7]    R71       -0.0680494916724233
    x[2,7]    hard_lower  7
    x[2,7]    hard_upper  7
    x[2,8]    OBJ       5.0000000000000010e-02
    x[2,8]    onehot_2  1
    x[2,8]    R72       -3.9145222845663033e-02
    x[2,8]    R73       -0.0680494916724233
    x[2,8]    hard_lower  8
    x[2,8]    hard_upper  8
    x[2,9]    OBJ       0.05
    x[2,9]    onehot_2  1
    x[2,9]    R74       -3.9145222845663033e-02
    x[2,9]    R75       -0.0680494916724233
    x[2,9]    hard_lower  9
    x[2,9]    hard_upper  9
    x[2,10]   OBJ       5.0000000000000010e-02
    x[2,10]   onehot_2  1
    x[2,10]   R76       -3.9145222845663033e-02
    x[2,10]   R77       -0.0680494916724233
    x[2,10]   hard_lower  10
    x[2,10]   hard_upper  10
    x[2,11]   OBJ       5.0000000000000010e-02
    x[2,11]   onehot_2  1
    x[2,11]   R78       -3.9145222845663033e-02
    x[2,11]   R79       -0.0680494916724233
    x[2,11]   hard_lower  11
    x[2,11]   hard_upper  11
    x[2,12]   OBJ       0.05
    x[2,12]   onehot_2  1
    x[2,12]   R80       -3.9145222845663033e-02
    x[2,12]   R81       -0.0680494916724233
    x[2,12]   hard_lower  12
    x[2,12]   hard_upper  12
    x[2,13]   OBJ       0.05
    x[2,13]   onehot_2  1
    x[2,13]   R82       -3.9145222845663033e-02
    x[2,13]   R83       -0.0680494916724233
    x[2,13]   hard_lower  13
    x[2,13]   hard_upper  13
    x[2,14]   OBJ       5.6471577414285437e-18
    x[2,14]   onehot_2  1
    x[2,14]   R84       -3.9145222845663033e-02
    x[2,14]   R85       -0.0680494916724233
    x[2,14]   hard_lower  14
    x[2,14]   hard_upper  14
    x[2,15]   OBJ       5.0000000000000010e-02
    x[2,15]   onehot_2  1
    x[2,15]   R86       -3.9145222845663033e-02
    x[2,15]   R87       -0.0680494916724233
    x[2,15]   hard_lower  15
    x[2,15]   hard_upper  15
    x[2,16]   OBJ       5.0000000000000010e-02
    x[2,16]   onehot_2  1
    x[2,16]   R88       -3.9145222845663033e-02
    x[2,16]   R89       -0.0680494916724233
    x[2,16]   hard_lower  16
    x[2,16]   hard_upper  16
    x[2,17]   OBJ       0.05
    x[2,17]   onehot_2  1
    x[2,17]   R90       -3.9145222845663033e-02
    x[2,17]   R91       -0.0680494916724233
    x[2,17]   hard_lower  17
    x[2,17]   hard_upper  17
    x[2,18]   OBJ       5.0000000000000010e-02
    x[2,18]   onehot_2  1
    x[2,18]   R92       -3.9145222845663033e-02
    x[2,18]   R93       -0.0680494916724233
    x[2,18]   hard_lower  18
    x[2,18]   hard_upper  18
    x[2,19]   OBJ       0.05
    x[2,19]   onehot_2  1
    x[2,19]   R94       -3.9145222845663033e-02
    x[2,19]   R95       -0.0680494916724233
    x[2,19]   hard_lower  19
    x[2,19]   hard_upper  19
    x[2,20]   OBJ       0.05
    x[2,20]   onehot_2  1
    x[2,20]   R96       -3.9145222845663033e-02
    x[2,20]   R97       -0.0680494916724233
    x[2,20]   hard_lower  20
    x[2,20]   hard_upper  20
    x[2,21]   OBJ       0.05
    x[2,21]   onehot_2  1
    x[2,21]   R98       -3.9145222845663033e-02
    x[2,21]   R99       -0.0680494916724233
    x[2,21]   hard_lower  21
    x[2,21]   hard_upper  21
    x[2,22]   OBJ       0.05
    x[2,22]   onehot_2  1
    x[2,22]   R100      -3.9145222845663033e-02
    x[2,22]   R101      -0.0680494916724233
    x[2,22]   hard_lower  22
    x[2,22]   hard_upper  22
    x[2,23]   OBJ       0.05
    x[2,23]   onehot_2  1
    x[2,23]   R102      -3.9145222845663033e-02
    x[2,23]   R103      -0.0680494916724233
    x[2,23]   hard_lower  23
    x[2,23]   hard_upper  23
    x[2,24]   OBJ       5.0000000000000010e-02
    x[2,24]   onehot_2  1
    x[2,24]   R104      -3.9145222845663033e-02
    x[2,24]   R105      -0.0680494916724233
    x[2,24]   hard_lower  24
    x[2,24]   hard_upper  24
    x[2,25]   OBJ       5.0000000000000010e-02
    x[2,25]   onehot_2  1
    x[2,25]   R106      -3.9145222845663033e-02
    x[2,25]   R107      -0.0680494916724233
    x[2,25]   hard_lower  25
    x[2,25]   hard_upper  25
    x[3,0]    OBJ       0.05
    x[3,0]    onehot_3  1
    x[3,0]    R112      -3.9145222845663033e-02
    x[3,0]    R113      -0.0680494916724233
    x[3,1]    OBJ       0.05
    x[3,1]    onehot_3  1
    x[3,1]    R114      -3.9145222845663033e-02
    x[3,1]    R115      -0.0680494916724233
    x[3,1]    hard_lower  1
    x[3,1]    hard_upper  1
    x[3,2]    OBJ       0.05
    x[3,2]    onehot_3  1
    x[3,2]    R116      -3.9145222845663033e-02
    x[3,2]    R117      -0.0680494916724233
    x[3,2]    hard_lower  2
    x[3,2]    hard_upper  2
    x[3,3]    OBJ       4.9999999999999996e-02
    x[3,3]    onehot_3  1
    x[3,3]    R118      -3.9145222845663033e-02
    x[3,3]    R119      -0.0680494916724233
    x[3,3]    hard_lower  3
    x[3,3]    hard_upper  3
    x[3,4]    OBJ       4.9999999999999996e-02
    x[3,4]    onehot_3  1
    x[3,4]    R120      -3.9145222845663033e-02
    x[3,4]    R121      -0.0680494916724233
    x[3,4]    hard_lower  4
    x[3,4]    hard_upper  4
    x[3,5]    OBJ       0.05
    x[3,5]    onehot_3  1
    x[3,5]    R122      -3.9145222845663033e-02
    x[3,5]    R123      -0.0680494916724233
    x[3,5]    hard_lower  5
    x[3,5]    hard_upper  5
    x[3,6]    OBJ       0.05
    x[3,6]    onehot_3  1
    x[3,6]    R124      -3.9145222845663033e-02
    x[3,6]    R125      -0.0680494916724233
    x[3,6]    hard_lower  6
    x[3,6]    hard_upper  6
    x[3,7]    OBJ       0.05
    x[3,7]    onehot_3  1
    x[3,7]    R126      -3.9145222845663033e-02
    x[3,7]    R127      -0.0680494916724233
    x[3,7]    hard_lower  7
    x[3,7]    hard_upper  7
    x[3,8]    OBJ       0.05
    x[3,8]    onehot_3  1
    x[3,8]    R128      -3.9145222845663033e-02
    x[3,8]    R129      -0.0680494916724233
    x[3,8]    hard_lower  8
    x[3,8]    hard_upper  8
    x[3,9]    OBJ       4.9999999999999996e-02
    x[3,9]    onehot_3  1
    x[3,9]    R130      -3.9145222845663033e-02
    x[3,9]    R131      -0.0680494916724233
    x[3,9]    hard_lower  9
    x[3,9]    hard_upper  9
    x[3,10]   OBJ       0.05
    x[3,10]   onehot_3  1
    x[3,10]   R132      -3.9145222845663033e-02
    x[3,10]   R133      -0.0680494916724233
    x[3,10]   hard_lower  10
    x[3,10]   hard_upper  10
    x[3,11]   OBJ       0.05
    x[3,11]   onehot_3  1
    x[3,11]   R134      -3.9145222845663033e-02
    x[3,11]   R135      -0.0680494916724233
    x[3,11]   hard_lower  11
    x[3,11]   hard_upper  11
    x[3,12]   OBJ       4.9999999999999996e-02
    x[3,12]   onehot_3  1
    x[3,12]   R136      -3.9145222845663033e-02
    x[3,12]   R137      -0.0680494916724233
    x[3,12]   hard_lower  12
    x[3,12]   hard_upper  12
    x[3,13]   OBJ       4.9999999999999996e-02
    x[3,13]   onehot_3  1
    x[3,13]   R138      -3.9145222845663033e-02
    x[3,13]   R139      -0.0680494916724233
    x[3,13]   hard_lower  13
    x[3,13]   hard_upper  13
    x[3,14]   OBJ       4.9999999999999996e-02
    x[3,14]   onehot_3  1
    x[3,14]   R140      -3.9145222845663033e-02
    x[3,14]   R141      -0.0680494916724233
    x[3,14]   hard_lower  14
    x[3,14]   hard_upper  14
    x[3,15]   OBJ       1.6206765096615783e-18
    x[3,15]   onehot_3  1
    x[3,15]   R142      -3.9145222845663033e-02
    x[3,15]   R143      -0.0680494916724233
    x[3,15]   hard_lower  15
    x[3,15]   hard_upper  15
    x[3,16]   OBJ       0.05
    x[3,16]   onehot_3  1
    x[3,16]   R144      -3.9145222845663033e-02
    x[3,16]   R145      -0.0680494916724233
    x[3,16]   hard_lower  16
    x[3,16]   hard_upper  16
    x[3,17]   OBJ       4.9999999999999996e-02
    x[3,17]   onehot_3  1
    x[3,17]   R146      -3.9145222845663033e-02
    x[3,17]   R147      -0.0680494916724233
    x[3,17]   hard_lower  17
    x[3,17]   hard_upper  17
    x[3,18]   OBJ       0.05
    x[3,18]   onehot_3  1
    x[3,18]   R148      -3.9145222845663033e-02
    x[3,18]   R149      -0.0680494916724233
    x[3,18]   hard_lower  18
    x[3,18]   hard_upper  18
    x[3,19]   OBJ       0.05
    x[3,19]   onehot_3  1
    x[3,19]   R150      -3.9145222845663033e-02
    x[3,19]   R151      -0.0680494916724233
    x[3,19]   hard_lower  19
    x[3,19]   hard_upper  19
    x[3,20]   OBJ       4.9999999999999996e-02
    x[3,20]   onehot_3  1
    x[3,20]   R152      -3.9145222845663033e-02
    x[3,20]   R153      -0.0680494916724233
    x[3,20]   hard_lower  20
    x[3,20]   hard_upper  20
    x[3,21]   OBJ       0.05
    x[3,21]   onehot_3  1
    x[3,21]   R154      -3.9145222845663033e-02
    x[3,21]   R155      -0.0680494916724233
    x[3,21]   hard_lower  21
    x[3,21]   hard_upper  21
    x[3,22]   OBJ       0.05
    x[3,22]   onehot_3  1
    x[3,22]   R156      -3.9145222845663033e-02
    x[3,22]   R157      -0.0680494916724233
    x[3,22]   hard_lower  22
    x[3,22]   hard_upper  22
    x[3,23]   OBJ       0.05
    x[3,23]   onehot_3  1
    x[3,23]   R158      -3.9145222845663033e-02
    x[3,23]   R159      -0.0680494916724233
    x[3,23]   hard_lower  23
    x[3,23]   hard_upper  23
    x[3,24]   OBJ       0.05
    x[3,24]   onehot_3  1
    x[3,24]   R160      -3.9145222845663033e-02
    x[3,24]   R161      -0.0680494916724233
    x[3,24]   hard_lower  24
    x[3,24]   hard_upper  24
    x[3,25]   OBJ       4.9999999999999996e-02
    x[3,25]   onehot_3  1
    x[3,25]   R162      -3.9145222845663033e-02
    x[3,25]   R163      -0.0680494916724233
    x[3,25]   hard_lower  25
    x[3,25]   hard_upper  25
    x[3,26]   OBJ       4.9999999999999996e-02
    x[3,26]   onehot_3  1
    x[3,26]   R164      -3.9145222845663033e-02
    x[3,26]   R165      -0.0680494916724233
    x[3,26]   hard_lower  26
    x[3,26]   hard_upper  26
    x[3,27]   OBJ       0.05
    x[3,27]   onehot_3  1
    x[3,27]   R166      -3.9145222845663033e-02
    x[3,27]   R167      -0.0680494916724233
    x[3,27]   hard_lower  27
    x[3,27]   hard_upper  27
    x[4,0]    OBJ       0.05
    x[4,0]    onehot_4  1
    x[4,0]    R172      -3.9145222845663033e-02
    x[4,0]    R173      -0.0680494916724233
    x[4,1]    OBJ       0.05
    x[4,1]    onehot_4  1
    x[4,1]    R174      -3.9145222845663033e-02
    x[4,1]    R175      -0.0680494916724233
    x[4,1]    hard_lower  1
    x[4,1]    hard_upper  1
    x[4,2]    OBJ       4.9999999999999996e-02
    x[4,2]    onehot_4  1
    x[4,2]    R176      -3.9145222845663033e-02
    x[4,2]    R177      -0.0680494916724233
    x[4,2]    hard_lower  2
    x[4,2]    hard_upper  2
    x[4,3]    OBJ       0.05
    x[4,3]    onehot_4  1
    x[4,3]    R178      -3.9145222845663033e-02
    x[4,3]    R179      -0.0680494916724233
    x[4,3]    hard_lower  3
    x[4,3]    hard_upper  3
    x[4,4]    OBJ       0.05
    x[4,4]    onehot_4  1
    x[4,4]    R180      -3.9145222845663033e-02
    x[4,4]    R181      -0.0680494916724233
    x[4,4]    hard_lower  4
    x[4,4]    hard_upper  4
    x[4,5]    OBJ       0.05
    x[4,5]    onehot_4  1
    x[4,5]    R182      -3.9145222845663033e-02
    x[4,5]    R183      -0.0680494916724233
    x[4,5]    hard_lower  5
    x[4,5]    hard_upper  5
    x[4,6]    OBJ       0.05
    x[4,6]    onehot_4  1
    x[4,6]    R184      -3.9145222845663033e-02
    x[4,6]    R185      -0.0680494916724233
    x[4,6]    hard_lower  6
    x[4,6]    hard_upper  6
    x[4,7]    OBJ       0.05
    x[4,7]    onehot_4  1
    x[4,7]    R186      -3.9145222845663033e-02
    x[4,7]    R187      -0.0680494916724233
    x[4,7]    hard_lower  7
    x[4,7]    hard_upper  7
    x[4,8]    OBJ       0.05
    x[4,8]    onehot_4  1
    x[4,8]    R188      -3.9145222845663033e-02
    x[4,8]    R189      -0.0680494916724233
    x[4,8]    hard_lower  8
    x[4,8]    hard_upper  8
    x[4,9]    OBJ       0.05
    x[4,9]    onehot_4  1
    x[4,9]    R190      -3.9145222845663033e-02
    x[4,9]    R191      -0.0680494916724233
    x[4,9]    hard_lower  9
    x[4,9]    hard_upper  9
    x[4,10]   OBJ       4.9999999999999996e-02
    x[4,10]   onehot_4  1
    x[4,10]   R192      -3.9145222845663033e-02
    x[4,10]   R193      -0.0680494916724233
    x[4,10]   hard_lower  10
    x[4,10]   hard_upper  10
    x[4,11]   OBJ       1.7431264764944385e-18
    x[4,11]   onehot_4  1
    x[4,11]   R194      -3.9145222845663033e-02
    x[4,11]   R195      -0.0680494916724233
    x[4,11]   hard_lower  11
    x[4,11]   hard_upper  11
    x[4,12]   OBJ       0.05
    x[4,12]   onehot_4  1
    x[4,12]   R196      -3.9145222845663033e-02
    x[4,12]   R197      -0.0680494916724233
    x[4,12]   hard_lower  12
    x[4,12]   hard_upper  12
    x[4,13]   OBJ       4.9999999999999996e-02
    x[4,13]   onehot_4  1
    x[4,13]   R198      -3.9145222845663033e-02
    x[4,13]   R199      -0.0680494916724233
    x[4,13]   hard_lower  13
    x[4,13]   hard_upper  13
    x[4,14]   OBJ       4.9999999999999996e-02
    x[4,14]   onehot_4  1
    x[4,14]   R200      -3.9145222845663033e-02
    x[4,14]   R201      -0.0680494916724233
    x[4,14]   hard_lower  14
    x[4,14]   hard_upper  14
    x[4,15]   OBJ       0.05
    x[4,15]   onehot_4  1
    x[4,15]   R202      -3.9145222845663033e-02
    x[4,15]   R203      -0.0680494916724233
    x[4,15]   hard_lower  15
    x[4,15]   hard_upper  15
    x[4,16]   OBJ       0.05
    x[4,16]   onehot_4  1
    x[4,16]   R204      -3.9145222845663033e-02
    x[4,16]   R205      -0.0680494916724233
    x[4,16]   hard_lower  16
    x[4,16]   hard_upper  16
    x[4,17]   OBJ       0.05
    x[4,17]   onehot_4  1
    x[4,17]   R206      -3.9145222845663033e-02
    x[4,17]   R207      -0.0680494916724233
    x[4,17]   hard_lower  17
    x[4,17]   hard_upper  17
    x[4,18]   OBJ       4.9999999999999996e-02
    x[4,18]   onehot_4  1
    x[4,18]   R208      -3.9145222845663033e-02
    x[4,18]   R209      -0.0680494916724233
    x[4,18]   hard_lower  18
    x[4,18]   hard_upper  18
    x[4,19]   OBJ       0.05
    x[4,19]   onehot_4  1
    x[4,19]   R210      -3.9145222845663033e-02
    x[4,19]   R211      -0.0680494916724233
    x[4,19]   hard_lower  19
    x[4,19]   hard_upper  19
    x[4,20]   OBJ       0.05
    x[4,20]   onehot_4  1
    x[4,20]   R212      -3.9145222845663033e-02
    x[4,20]   R213      -0.0680494916724233
    x[4,20]   hard_lower  20
    x[4,20]   hard_upper  20
    x[4,21]   OBJ       0.05
    x[4,21]   onehot_4  1
    x[4,21]   R214      -3.9145222845663033e-02
    x[4,21]   R215      -0.0680494916724233
    x[4,21]   hard_lower  21
    x[4,21]   hard_upper  21
    x[4,22]   OBJ       0.05
    x[4,22]   onehot_4  1
    x[4,22]   R216      -3.9145222845663033e-02
    x[4,22]   R217      -0.0680494916724233
    x[4,22]   hard_lower  22
    x[4,22]   hard_upper  22
    x[4,23]   OBJ       5.0000000000000010e-02
    x[4,23]   onehot_4  1
    x[4,23]   R218      -3.9145222845663033e-02
    x[4,23]   R219      -0.0680494916724233
    x[4,23]   hard_lower  23
    x[4,23]   hard_upper  23
    x[4,24]   OBJ       5.0000000000000010e-02
    x[4,24]   onehot_4  1
    x[4,24]   R220      -3.9145222845663033e-02
    x[4,24]   R221      -0.0680494916724233
    x[4,24]   hard_lower  24
    x[4,24]   hard_upper  24
    x[5,0]    OBJ       0.05
    x[5,0]    onehot_5  1
    x[5,0]    R226      -3.9145222845663033e-02
    x[5,0]    R227      -0.0680494916724233
    x[5,1]    OBJ       0.05
    x[5,1]    onehot_5  1
    x[5,1]    R228      -3.9145222845663033e-02
    x[5,1]    R229      -0.0680494916724233
    x[5,1]    hard_lower  1
    x[5,1]    hard_upper  1
    x[5,2]    OBJ       4.9999999999999996e-02
    x[5,2]    onehot_5  1
    x[5,2]    R230      -3.9145222845663033e-02
    x[5,2]    R231      -0.0680494916724233
    x[5,2]    hard_lower  2
    x[5,2]    hard_upper  2
    x[5,3]    OBJ       0.05
    x[5,3]    onehot_5  1
    x[5,3]    R232      -3.9145222845663033e-02
    x[5,3]    R233      -0.0680494916724233
    x[5,3]    hard_lower  3
    x[5,3]    hard_upper  3
    x[5,4]    OBJ       0.05
    x[5,4]    onehot_5  1
    x[5,4]    R234      -3.9145222845663033e-02
    x[5,4]    R235      -0.0680494916724233
    x[5,4]    hard_lower  4
    x[5,4]    hard_upper  4
    x[5,5]    OBJ       0.05
    x[5,5]    onehot_5  1
    x[5,5]    R236      -3.9145222845663033e-02
    x[5,5]    R237      -0.0680494916724233
    x[5,5]    hard_lower  5
    x[5,5]    hard_upper  5
    x[5,6]    OBJ       0.05
    x[5,6]    onehot_5  1
    x[5,6]    R238      -3.9145222845663033e-02
    x[5,6]    R239      -0.0680494916724233
    x[5,6]    hard_lower  6
    x[5,6]    hard_upper  6
    x[5,7]    OBJ       0.05
    x[5,7]    onehot_5  1
    x[5,7]    R240      -3.9145222845663033e-02
    x[5,7]    R241      -0.0680494916724233
    x[5,7]    hard_lower  7
    x[5,7]    hard_upper  7
    x[5,8]    OBJ       0.05
    x[5,8]    onehot_5  1
    x[5,8]    R242      -3.9145222845663033e-02
    x[5,8]    R243      -0.0680494916724233
    x[5,8]    hard_lower  8
    x[5,8]    hard_upper  8
    x[5,9]    OBJ       0.05
    x[5,9]    onehot_5  1
    x[5,9]    R244      -3.9145222845663033e-02
    x[5,9]    R245      -0.0680494916724233
    x[5,9]    hard_lower  9
    x[5,9]    hard_upper  9
    x[5,10]   OBJ       4.9999999999999996e-02
    x[5,10]   onehot_5  1
    x[5,10]   R246      -3.9145222845663033e-02
    x[5,10]   R247      -0.0680494916724233
    x[5,10]   hard_lower  10
    x[5,10]   hard_upper  10
    x[5,11]   OBJ       1.7431264764944385e-18
    x[5,11]   onehot_5  1
    x[5,11]   R248      -3.9145222845663033e-02
    x[5,11]   R249      -0.0680494916724233
    x[5,11]   hard_lower  11
    x[5,11]   hard_upper  11
    x[5,12]   OBJ       0.05
    x[5,12]   onehot_5  1
    x[5,12]   R250      -3.9145222845663033e-02
    x[5,12]   R251      -0.0680494916724233
    x[5,12]   hard_lower  12
    x[5,12]   hard_upper  12
    x[5,13]   OBJ       4.9999999999999996e-02
    x[5,13]   onehot_5  1
    x[5,13]   R252      -3.9145222845663033e-02
    x[5,13]   R253      -0.0680494916724233
    x[5,13]   hard_lower  13
    x[5,13]   hard_upper  13
    x[5,14]   OBJ       4.9999999999999996e-02
    x[5,14]   onehot_5  1
    x[5,14]   R254      -3.9145222845663033e-02
    x[5,14]   R255      -0.0680494916724233
    x[5,14]   hard_lower  14
    x[5,14]   hard_upper  14
    x[5,15]   OBJ       0.05
    x[5,15]   onehot_5  1
    x[5,15]   R256      -3.9145222845663033e-02
    x[5,15]   R257      -0.0680494916724233
    x[5,15]   hard_lower  15
    x[5,15]   hard_upper  15
    x[5,16]   OBJ       0.05
    x[5,16]   onehot_5  1
    x[5,16]   R258      -3.9145222845663033e-02
    x[5,16]   R259      -0.0680494916724233
    x[5,16]   hard_lower  16
    x[5,16]   hard_upper  16
    x[5,17]   OBJ       0.05
    x[5,17]   onehot_5  1
    x[5,17]   R260      -3.9145222845663033e-02
    x[5,17]   R261      -0.0680494916724233
    x[5,17]   hard_lower  17
    x[5,17]   hard_upper  17
    x[5,18]   OBJ       -2.4802280951458148e-02
    x[5,18]   onehot_5  1
    x[5,18]   R262      -3.9145222845663033e-02
    x[5,18]   R263      -0.0680494916724233
    x[5,18]   hard_lower  18
    x[5,18]   hard_upper  18
    x[5,19]   OBJ       0.05
    x[5,19]   onehot_5  1
    x[5,19]   R264      -3.9145222845663033e-02
    x[5,19]   R265      -0.0680494916724233
    x[5,19]   hard_lower  19
    x[5,19]   hard_upper  19
    x[5,20]   OBJ       0.05
    x[5,20]   onehot_5  1
    x[5,20]   R266      -3.9145222845663033e-02
    x[5,20]   R267      -0.0680494916724233
    x[5,20]   hard_lower  20
    x[5,20]   hard_upper  20
    x[5,21]   OBJ       0.05
    x[5,21]   onehot_5  1
    x[5,21]   R268      -3.9145222845663033e-02
    x[5,21]   R269      -0.0680494916724233
    x[5,21]   hard_lower  21
    x[5,21]   hard_upper  21
    x[6,0]    OBJ       0.05
    x[6,0]    onehot_6  1
    x[6,0]    R274      -3.9145222845663033e-02
    x[6,0]    R275      -0.0680494916724233
    x[6,1]    OBJ       0.05
    x[6,1]    onehot_6  1
    x[6,1]    R276      -3.9145222845663033e-02
    x[6,1]    R277      -0.0680494916724233
    x[6,1]    hard_lower  1
    x[6,1]    hard_upper  1
    x[6,2]    OBJ       4.9999999999999996e-02
    x[6,2]    onehot_6  1
    x[6,2]    R278      -3.9145222845663033e-02
    x[6,2]    R279      -0.0680494916724233
    x[6,2]    hard_lower  2
    x[6,2]    hard_upper  2
    x[6,3]    OBJ       0.05
    x[6,3]    onehot_6  1
    x[6,3]    R280      -3.9145222845663033e-02
    x[6,3]    R281      -0.0680494916724233
    x[6,3]    hard_lower  3
    x[6,3]    hard_upper  3
    x[6,4]    OBJ       0.05
    x[6,4]    onehot_6  1
    x[6,4]    R282      -3.9145222845663033e-02
    x[6,4]    R283      -0.0680494916724233
    x[6,4]    hard_lower  4
    x[6,4]    hard_upper  4
    x[6,5]    OBJ       0.05
    x[6,5]    onehot_6  1
    x[6,5]    R284      -3.9145222845663033e-02
    x[6,5]    R285      -0.0680494916724233
    x[6,5]    hard_lower  5
    x[6,5]    hard_upper  5
    x[6,6]    OBJ       0.05
    x[6,6]    onehot_6  1
    x[6,6]    R286      -3.9145222845663033e-02
    x[6,6]    R287      -0.0680494916724233
    x[6,6]    hard_lower  6
    x[6,6]    hard_upper  6
    x[6,7]    OBJ       0.05
    x[6,7]    onehot_6  1
    x[6,7]    R288      -3.9145222845663033e-02
    x[6,7]    R289      -0.0680494916724233
    x[6,7]    hard_lower  7
    x[6,7]    hard_upper  7
    x[6,8]    OBJ       0.05
    x[6,8]    onehot_6  1
    x[6,8]    R290      -3.9145222845663033e-02
    x[6,8]    R291      -0.0680494916724233
    x[6,8]    hard_lower  8
    x[6,8]    hard_upper  8
    x[6,9]    OBJ       0.05
    x[6,9]    onehot_6  1
    x[6,9]    R292      -3.9145222845663033e-02
    x[6,9]    R293      -0.0680494916724233
    x[6,9]    hard_lower  9
    x[6,9]    hard_upper  9
    x[6,10]   OBJ       4.9999999999999996e-02
    x[6,10]   onehot_6  1
    x[6,10]   R294      -3.9145222845663033e-02
    x[6,10]   R295      -0.0680494916724233
    x[6,10]   hard_lower  10
    x[6,10]   hard_upper  10
    x[6,11]   OBJ       1.7431264764944385e-18
    x[6,11]   onehot_6  1
    x[6,11]   R296      -3.9145222845663033e-02
    x[6,11]   R297      -0.0680494916724233
    x[6,11]   hard_lower  11
    x[6,11]   hard_upper  11
    x[6,12]   OBJ       0.05
    x[6,12]   onehot_6  1
    x[6,12]   R298      -3.9145222845663033e-02
    x[6,12]   R299      -0.0680494916724233
    x[6,12]   hard_lower  12
    x[6,12]   hard_upper  12
    x[6,13]   OBJ       4.9999999999999996e-02
    x[6,13]   onehot_6  1
    x[6,13]   R300      -3.9145222845663033e-02
    x[6,13]   R301      -0.0680494916724233
    x[6,13]   hard_lower  13
    x[6,13]   hard_upper  13
    x[6,14]   OBJ       4.9999999999999996e-02
    x[6,14]   onehot_6  1
    x[6,14]   R302      -3.9145222845663033e-02
    x[6,14]   R303      -0.0680494916724233
    x[6,14]   hard_lower  14
    x[6,14]   hard_upper  14
    x[6,15]   OBJ       0.05
    x[6,15]   onehot_6  1
    x[6,15]   R304      -3.9145222845663033e-02
    x[6,15]   R305      -0.0680494916724233
    x[6,15]   hard_lower  15
    x[6,15]   hard_upper  15
    x[6,16]   OBJ       0.05
    x[6,16]   onehot_6  1
    x[6,16]   R306      -3.9145222845663033e-02
    x[6,16]   R307      -0.0680494916724233
    x[6,16]   hard_lower  16
    x[6,16]   hard_upper  16
    x[6,17]   OBJ       0.05
    x[6,17]   onehot_6  1
    x[6,17]   R308      -3.9145222845663033e-02
    x[6,17]   R309      -0.0680494916724233
    x[6,17]   hard_lower  17
    x[6,17]   hard_upper  17
    x[6,18]   OBJ       4.9999999999999996e-02
    x[6,18]   onehot_6  1
    x[6,18]   R310      -3.9145222845663033e-02
    x[6,18]   R311      -0.0680494916724233
    x[6,18]   hard_lower  18
    x[6,18]   hard_upper  18
    x[6,19]   OBJ       0.05
    x[6,19]   onehot_6  1
    x[6,19]   R312      -3.9145222845663033e-02
    x[6,19]   R313      -0.0680494916724233
    x[6,19]   hard_lower  19
    x[6,19]   hard_upper  19
    x[6,20]   OBJ       -3.1227845501480833e-02
    x[6,20]   onehot_6  1
    x[6,20]   R314      -3.9145222845663033e-02
    x[6,20]   R315      -0.0680494916724233
    x[6,20]   hard_lower  20
    x[6,20]   hard_upper  20
    x[6,21]   OBJ       0.05
    x[6,21]   onehot_6  1
    x[6,21]   R316      -3.9145222845663033e-02
    x[6,21]   R317      -0.0680494916724233
    x[6,21]   hard_lower  21
    x[6,21]   hard_upper  21
    x[6,22]   OBJ       0.05
    x[6,22]   onehot_6  1
    x[6,22]   R318      -3.9145222845663033e-02
    x[6,22]   R319      -0.0680494916724233
    x[6,22]   hard_lower  22
    x[6,22]   hard_upper  22
    x[6,23]   OBJ       5.0000000000000010e-02
    x[6,23]   onehot_6  1
    x[6,23]   R320      -3.9145222845663033e-02
    x[6,23]   R321      -0.0680494916724233
    x[6,23]   hard_lower  23
    x[6,23]   hard_upper  23
    x[6,24]   OBJ       5.0000000000000010e-02
    x[6,24]   onehot_6  1
    x[6,24]   R322      -3.9145222845663033e-02
    x[6,24]   R323      -0.0680494916724233
    x[6,24]   hard_lower  24
    x[6,24]   hard_upper  24
    x[7,0]    OBJ       0.05
    x[7,0]    onehot_7  1
    x[7,0]    R328      -3.9145222845663033e-02
    x[7,0]    R329      -0.0680494916724233
    x[7,1]    OBJ       0.05
    x[7,1]    onehot_7  1
    x[7,1]    R330      -3.9145222845663033e-02
    x[7,1]    R331      -0.0680494916724233
    x[7,1]    hard_lower  1
    x[7,1]    hard_upper  1
    x[7,2]    OBJ       0.05
    x[7,2]    onehot_7  1
    x[7,2]    R332      -3.9145222845663033e-02
    x[7,2]    R333      -0.0680494916724233
    x[7,2]    hard_lower  2
    x[7,2]    hard_upper  2
    x[7,3]    OBJ       0.05
    x[7,3]    onehot_7  1
    x[7,3]    R334      -3.9145222845663033e-02
    x[7,3]    R335      -0.0680494916724233
    x[7,3]    hard_lower  3
    x[7,3]    hard_upper  3
    x[7,4]    OBJ       0.05
    x[7,4]    onehot_7  1
    x[7,4]    R336      -3.9145222845663033e-02
    x[7,4]    R337      -0.0680494916724233
    x[7,4]    hard_lower  4
    x[7,4]    hard_upper  4
    x[7,5]    OBJ       0.05
    x[7,5]    onehot_7  1
    x[7,5]    R338      -3.9145222845663033e-02
    x[7,5]    R339      -0.0680494916724233
    x[7,5]    hard_lower  5
    x[7,5]    hard_upper  5
    x[7,6]    OBJ       0.05
    x[7,6]    onehot_7  1
    x[7,6]    R340      -3.9145222845663033e-02
    x[7,6]    R341      -0.0680494916724233
    x[7,6]    hard_lower  6
    x[7,6]    hard_upper  6
    x[7,7]    OBJ       4.9999999999999996e-02
    x[7,7]    onehot_7  1
    x[7,7]    R342      -3.9145222845663033e-02
    x[7,7]    R343      -0.0680494916724233
    x[7,7]    hard_lower  7
    x[7,7]    hard_upper  7
    x[7,8]    OBJ       4.9999999999999996e-02
    x[7,8]    onehot_7  1
    x[7,8]    R344      -3.9145222845663033e-02
    x[7,8]    R345      -0.0680494916724233
    x[7,8]    hard_lower  8
    x[7,8]    hard_upper  8
    x[7,9]    OBJ       4.9999999999999996e-02
    x[7,9]    onehot_7  1
    x[7,9]    R346      -3.9145222845663033e-02
    x[7,9]    R347      -0.0680494916724233
    x[7,9]    hard_lower  9
    x[7,9]    hard_upper  9
    x[7,10]   OBJ       2.8812036090286598e-18
    x[7,10]   onehot_7  1
    x[7,10]   R348      -3.9145222845663033e-02
    x[7,10]   R349      -0.0680494916724233
    x[7,10]   hard_lower  10
    x[7,10]   hard_upper  10
    x[7,11]   OBJ       0.05
    x[7,11]   onehot_7  1
    x[7,11]   R350      -3.9145222845663033e-02
    x[7,11]   R351      -0.0680494916724233
    x[7,11]   hard_lower  11
    x[7,11]   hard_upper  11
    x[7,12]   OBJ       0.05
    x[7,12]   onehot_7  1
    x[7,12]   R352      -3.9145222845663033e-02
    x[7,12]   R353      -0.0680494916724233
    x[7,12]   hard_lower  12
    x[7,12]   hard_upper  12
    x[7,13]   OBJ       0.05
    x[7,13]   onehot_7  1
    x[7,13]   R354      -3.9145222845663033e-02
    x[7,13]   R355      -0.0680494916724233
    x[7,13]   hard_lower  13
    x[7,13]   hard_upper  13
    x[7,14]   OBJ       0.05
    x[7,14]   onehot_7  1
    x[7,14]   R356      -3.9145222845663033e-02
    x[7,14]   R357      -0.0680494916724233
    x[7,14]   hard_lower  14
    x[7,14]   hard_upper  14
    x[7,15]   OBJ       0.05
    x[7,15]   onehot_7  1
    x[7,15]   R358      -3.9145222845663033e-02
    x[7,15]   R359      -0.0680494916724233
    x[7,15]   hard_lower  15
    x[7,15]   hard_upper  15
    x[7,16]   OBJ       0.05
    x[7,16]   onehot_7  1
    x[7,16]   R360      -3.9145222845663033e-02
    x[7,16]   R361      -0.0680494916724233
    x[7,16]   hard_lower  16
    x[7,16]   hard_upper  16
    x[7,17]   OBJ       0.05
    x[7,17]   onehot_7  1
    x[7,17]   R362      -3.9145222845663033e-02
    x[7,17]   R363      -0.0680494916724233
    x[7,17]   hard_lower  17
    x[7,17]   hard_upper  17
    x[7,18]   OBJ       0.05
    x[7,18]   onehot_7  1
    x[7,18]   R364      -3.9145222845663033e-02
    x[7,18]   R365      -0.0680494916724233
    x[7,18]   hard_lower  18
    x[7,18]   hard_upper  18
    x[7,19]   OBJ       0.05
    x[7,19]   onehot_7  1
    x[7,19]   R366      -3.9145222845663033e-02
    x[7,19]   R367      -0.0680494916724233
    x[7,19]   hard_lower  19
    x[7,19]   hard_upper  19
    x[7,20]   OBJ       0.05
    x[7,20]   onehot_7  1
    x[7,20]   R368      -3.9145222845663033e-02
    x[7,20]   R369      -0.0680494916724233
    x[7,20]   hard_lower  20
    x[7,20]   hard_upper  20
    x[7,21]   OBJ       0.05
    x[7,21]   onehot_7  1
    x[7,21]   R370      -3.9145222845663033e-02
    x[7,21]   R371      -0.0680494916724233
    x[7,21]   hard_lower  21
    x[7,21]   hard_upper  21
    x[7,22]   OBJ       0.05
    x[7,22]   onehot_7  1
    x[7,22]   R372      -3.9145222845663033e-02
    x[7,22]   R373      -0.0680494916724233
    x[7,22]   hard_lower  22
    x[7,22]   hard_upper  22
    x[8,0]    OBJ       0.05
    x[8,0]    onehot_8  1
    x[8,0]    R378      -3.9145222845663033e-02
    x[8,0]    R379      -0.0680494916724233
    x[8,1]    OBJ       0.05
    x[8,1]    onehot_8  1
    x[8,1]    R380      -3.9145222845663033e-02
    x[8,1]    R381      -0.0680494916724233
    x[8,1]    hard_lower  1
    x[8,1]    hard_upper  1
    x[8,2]    OBJ       4.9999999999999996e-02
    x[8,2]    onehot_8  1
    x[8,2]    R382      -3.9145222845663033e-02
    x[8,2]    R383      -0.0680494916724233
    x[8,2]    hard_lower  2
    x[8,2]    hard_upper  2
    x[8,3]    OBJ       0.05
    x[8,3]    onehot_8  1
    x[8,3]    R384      -3.9145222845663033e-02
    x[8,3]    R385      -0.0680494916724233
    x[8,3]    hard_lower  3
    x[8,3]    hard_upper  3
    x[8,4]    OBJ       0.05
    x[8,4]    onehot_8  1
    x[8,4]    R386      -3.9145222845663033e-02
    x[8,4]    R387      -0.0680494916724233
    x[8,4]    hard_lower  4
    x[8,4]    hard_upper  4
    x[8,5]    OBJ       0.05
    x[8,5]    onehot_8  1
    x[8,5]    R388      -3.9145222845663033e-02
    x[8,5]    R389      -0.0680494916724233
    x[8,5]    hard_lower  5
    x[8,5]    hard_upper  5
    x[8,6]    OBJ       0.05
    x[8,6]    onehot_8  1
    x[8,6]    R390      -3.9145222845663033e-02
    x[8,6]    R391      -0.0680494916724233
    x[8,6]    hard_lower  6
    x[8,6]    hard_upper  6
    x[8,7]    OBJ       0.05
    x[8,7]    onehot_8  1
    x[8,7]    R392      -3.9145222845663033e-02
    x[8,7]    R393      -0.0680494916724233
    x[8,7]    hard_lower  7
    x[8,7]    hard_upper  7
    x[8,8]    OBJ       0.05
    x[8,8]    onehot_8  1
    x[8,8]    R394      -3.9145222845663033e-02
    x[8,8]    R395      -0.0680494916724233
    x[8,8]    hard_lower  8
    x[8,8]    hard_upper  8
    x[8,9]    OBJ       0.05
    x[8,9]    onehot_8  1
    x[8,9]    R396      -3.9145222845663033e-02
    x[8,9]    R397      -0.0680494916724233
    x[8,9]    hard_lower  9
    x[8,9]    hard_upper  9
    x[8,10]   OBJ       4.9999999999999996e-02
    x[8,10]   onehot_8  1
    x[8,10]   R398      -3.9145222845663033e-02
    x[8,10]   R399      -0.0680494916724233
    x[8,10]   hard_lower  10
    x[8,10]   hard_upper  10
    x[8,11]   OBJ       1.7431264764944385e-18
    x[8,11]   onehot_8  1
    x[8,11]   R400      -3.9145222845663033e-02
    x[8,11]   R401      -0.0680494916724233
    x[8,11]   hard_lower  11
    x[8,11]   hard_upper  11
    x[8,12]   OBJ       0.05
    x[8,12]   onehot_8  1
    x[8,12]   R402      -3.9145222845663033e-02
    x[8,12]   R403      -0.0680494916724233
    x[8,12]   hard_lower  12
    x[8,12]   hard_upper  12
    x[8,13]   OBJ       4.9999999999999996e-02
    x[8,13]   onehot_8  1
    x[8,13]   R404      -3.9145222845663033e-02
    x[8,13]   R405      -0.0680494916724233
    x[8,13]   hard_lower  13
    x[8,13]   hard_upper  13
    x[8,14]   OBJ       4.9999999999999996e-02
    x[8,14]   onehot_8  1
    x[8,14]   R406      -3.9145222845663033e-02
    x[8,14]   R407      -0.0680494916724233
    x[8,14]   hard_lower  14
    x[8,14]   hard_upper  14
    x[8,15]   OBJ       0.05
    x[8,15]   onehot_8  1
    x[8,15]   R408      -3.9145222845663033e-02
    x[8,15]   R409      -0.0680494916724233
    x[8,15]   hard_lower  15
    x[8,15]   hard_upper  15
    x[8,16]   OBJ       0.05
    x[8,16]   onehot_8  1
    x[8,16]   R410      -3.9145222845663033e-02
    x[8,16]   R411      -0.0680494916724233
    x[8,16]   hard_lower  16
    x[8,16]   hard_upper  16
    x[8,17]   OBJ       0.05
    x[8,17]   onehot_8  1
    x[8,17]   R412      -3.9145222845663033e-02
    x[8,17]   R413      -0.0680494916724233
    x[8,17]   hard_lower  17
    x[8,17]   hard_upper  17
    x[8,18]   OBJ       4.9999999999999996e-02
    x[8,18]   onehot_8  1
    x[8,18]   R414      -3.9145222845663033e-02
    x[8,18]   R415      -0.0680494916724233
    x[8,18]   hard_lower  18
    x[8,18]   hard_upper  18
    x[8,19]   OBJ       0.05
    x[8,19]   onehot_8  1
    x[8,19]   R416      -3.9145222845663033e-02
    x[8,19]   R417      -0.0680494916724233
    x[8,19]   hard_lower  19
    x[8,19]   hard_upper  19
    x[8,20]   OBJ       0.05
    x[8,20]   onehot_8  1
    x[8,20]   R418      -3.9145222845663033e-02
    x[8,20]   R419      -0.0680494916724233
    x[8,20]   hard_lower  20
    x[8,20]   hard_upper  20
    x[8,21]   OBJ       0.05
    x[8,21]   onehot_8  1
    x[8,21]   R420      -3.9145222845663033e-02
    x[8,21]   R421      -0.0680494916724233
    x[8,21]   hard_lower  21
    x[8,21]   hard_upper  21
    x[9,0]    OBJ       0.05
    x[9,0]    onehot_9  1
    x[9,0]    R426      -3.9145222845663033e-02
    x[9,0]    R427      -0.0680494916724233
    x[9,1]    OBJ       0.05
    x[9,1]    onehot_9  1
    x[9,1]    R428      -3.9145222845663033e-02
    x[9,1]    R429      -0.0680494916724233
    x[9,1]    hard_lower  1
    x[9,1]    hard_upper  1
    x[9,2]    OBJ       0.05
    x[9,2]    onehot_9  1
    x[9,2]    R430      -3.9145222845663033e-02
    x[9,2]    R431      -0.0680494916724233
    x[9,2]    hard_lower  2
    x[9,2]    hard_upper  2
    x[9,3]    OBJ       0.05
    x[9,3]    onehot_9  1
    x[9,3]    R432      -3.9145222845663033e-02
    x[9,3]    R433      -0.0680494916724233
    x[9,3]    hard_lower  3
    x[9,3]    hard_upper  3
    x[9,4]    OBJ       0.05
    x[9,4]    onehot_9  1
    x[9,4]    R434      -3.9145222845663033e-02
    x[9,4]    R435      -0.0680494916724233
    x[9,4]    hard_lower  4
    x[9,4]    hard_upper  4
    x[9,5]    OBJ       0.05
    x[9,5]    onehot_9  1
    x[9,5]    R436      -3.9145222845663033e-02
    x[9,5]    R437      -0.0680494916724233
    x[9,5]    hard_lower  5
    x[9,5]    hard_upper  5
    x[9,6]    OBJ       4.9999999999999996e-02
    x[9,6]    onehot_9  1
    x[9,6]    R438      -3.9145222845663033e-02
    x[9,6]    R439      -0.0680494916724233
    x[9,6]    hard_lower  6
    x[9,6]    hard_upper  6
    x[9,7]    OBJ       4.9999999999999996e-02
    x[9,7]    onehot_9  1
    x[9,7]    R440      -3.9145222845663033e-02
    x[9,7]    R441      -0.0680494916724233
    x[9,7]    hard_lower  7
    x[9,7]    hard_upper  7
    x[9,8]    OBJ       0.05
    x[9,8]    onehot_9  1
    x[9,8]    R442      -3.9145222845663033e-02
    x[9,8]    R443      -0.0680494916724233
    x[9,8]    hard_lower  8
    x[9,8]    hard_upper  8
    x[9,9]    OBJ       2.3337748400464873e-18
    x[9,9]    onehot_9  1
    x[9,9]    R444      -3.9145222845663033e-02
    x[9,9]    R445      -0.0680494916724233
    x[9,9]    hard_lower  9
    x[9,9]    hard_upper  9
    x[9,10]   OBJ       4.9999999999999996e-02
    x[9,10]   onehot_9  1
    x[9,10]   R446      -3.9145222845663033e-02
    x[9,10]   R447      -0.0680494916724233
    x[9,10]   hard_lower  10
    x[9,10]   hard_upper  10
    x[9,11]   OBJ       0.05
    x[9,11]   onehot_9  1
    x[9,11]   R448      -3.9145222845663033e-02
    x[9,11]   R449      -0.0680494916724233
    x[9,11]   hard_lower  11
    x[9,11]   hard_upper  11
    x[9,12]   OBJ       0.05
    x[9,12]   onehot_9  1
    x[9,12]   R450      -3.9145222845663033e-02
    x[9,12]   R451      -0.0680494916724233
    x[9,12]   hard_lower  12
    x[9,12]   hard_upper  12
    x[9,13]   OBJ       0.05
    x[9,13]   onehot_9  1
    x[9,13]   R452      -3.9145222845663033e-02
    x[9,13]   R453      -0.0680494916724233
    x[9,13]   hard_lower  13
    x[9,13]   hard_upper  13
    x[9,14]   OBJ       0.05
    x[9,14]   onehot_9  1
    x[9,14]   R454      -3.9145222845663033e-02
    x[9,14]   R455      -0.0680494916724233
    x[9,14]   hard_lower  14
    x[9,14]   hard_upper  14
    x[9,15]   OBJ       0.05
    x[9,15]   onehot_9  1
    x[9,15]   R456      -3.9145222845663033e-02
    x[9,15]   R457      -0.0680494916724233
    x[9,15]   hard_lower  15
    x[9,15]   hard_upper  15
    x[9,16]   OBJ       0.05
    x[9,16]   onehot_9  1
    x[9,16]   R458      -3.9145222845663033e-02
    x[9,16]   R459      -0.0680494916724233
    x[9,16]   hard_lower  16
    x[9,16]   hard_upper  16
    x[9,17]   OBJ       0.05
    x[9,17]   onehot_9  1
    x[9,17]   R460      -3.9145222845663033e-02
    x[9,17]   R461      -0.0680494916724233
    x[9,17]   hard_lower  17
    x[9,17]   hard_upper  17
    x[9,18]   OBJ       0.05
    x[9,18]   onehot_9  1
    x[9,18]   R462      -3.9145222845663033e-02
    x[9,18]   R463      -0.0680494916724233
    x[9,18]   hard_lower  18
    x[9,18]   hard_upper  18
    x[9,19]   OBJ       4.9999999999999996e-02
    x[9,19]   onehot_9  1
    x[9,19]   R464      -3.9145222845663033e-02
    x[9,19]   R465      -0.0680494916724233
    x[9,19]   hard_lower  19
    x[9,19]   hard_upper  19
    x[10,0]   OBJ       0.05
    x[10,0]   onehot_10  1
    x[10,0]   R470      -3.9145222845663033e-02
    x[10,0]   R471      -0.0680494916724233
    x[10,1]   OBJ       4.9999999999999996e-02
    x[10,1]   onehot_10  1
    x[10,1]   R472      -3.9145222845663033e-02
    x[10,1]   R473      -0.0680494916724233
    x[10,1]   hard_lower  1
    x[10,1]   hard_upper  1
    x[10,2]   OBJ       4.9999999999999996e-02
    x[10,2]   onehot_10  1
    x[10,2]   R474      -3.9145222845663033e-02
    x[10,2]   R475      -0.0680494916724233
    x[10,2]   hard_lower  2
    x[10,2]   hard_upper  2
    x[10,3]   OBJ       4.9999999999999996e-02
    x[10,3]   onehot_10  1
    x[10,3]   R476      -3.9145222845663033e-02
    x[10,3]   R477      -0.0680494916724233
    x[10,3]   hard_lower  3
    x[10,3]   hard_upper  3
    x[10,4]   OBJ       4.9999999999999996e-02
    x[10,4]   onehot_10  1
    x[10,4]   R478      -3.9145222845663033e-02
    x[10,4]   R479      -0.0680494916724233
    x[10,4]   hard_lower  4
    x[10,4]   hard_upper  4
    x[10,5]   OBJ       0.05
    x[10,5]   onehot_10  1
    x[10,5]   R480      -3.9145222845663033e-02
    x[10,5]   R481      -0.0680494916724233
    x[10,5]   hard_lower  5
    x[10,5]   hard_upper  5
    x[10,6]   OBJ       0.05
    x[10,6]   onehot_10  1
    x[10,6]   R482      -3.9145222845663033e-02
    x[10,6]   R483      -0.0680494916724233
    x[10,6]   hard_lower  6
    x[10,6]   hard_upper  6
    x[10,7]   OBJ       0.05
    x[10,7]   onehot_10  1
    x[10,7]   R484      -3.9145222845663033e-02
    x[10,7]   R485      -0.0680494916724233
    x[10,7]   hard_lower  7
    x[10,7]   hard_upper  7
    x[10,8]   OBJ       0.05
    x[10,8]   onehot_10  1
    x[10,8]   R486      -3.9145222845663033e-02
    x[10,8]   R487      -0.0680494916724233
    x[10,8]   hard_lower  8
    x[10,8]   hard_upper  8
    x[10,9]   OBJ       4.9999999999999996e-02
    x[10,9]   onehot_10  1
    x[10,9]   R488      -3.9145222845663033e-02
    x[10,9]   R489      -0.0680494916724233
    x[10,9]   hard_lower  9
    x[10,9]   hard_upper  9
    x[10,10]  OBJ       4.9999999999999996e-02
    x[10,10]  onehot_10  1
    x[10,10]  R490      -3.9145222845663033e-02
    x[10,10]  R491      -0.0680494916724233
    x[10,10]  hard_lower  10
    x[10,10]  hard_upper  10
    x[10,11]  OBJ       0.05
    x[10,11]  onehot_10  1
    x[10,11]  R492      -3.9145222845663033e-02
    x[10,11]  R493      -0.0680494916724233
    x[10,11]  hard_lower  11
    x[10,11]  hard_upper  11
    x[10,12]  OBJ       0.05
    x[10,12]  onehot_10  1
    x[10,12]  R494      -3.9145222845663033e-02
    x[10,12]  R495      -0.0680494916724233
    x[10,12]  hard_lower  12
    x[10,12]  hard_upper  12
    x[10,13]  OBJ       4.9999999999999996e-02
    x[10,13]  onehot_10  1
    x[10,13]  R496      -3.9145222845663033e-02
    x[10,13]  R497      -0.0680494916724233
    x[10,13]  hard_lower  13
    x[10,13]  hard_upper  13
    x[10,14]  OBJ       0.05
    x[10,14]  onehot_10  1
    x[10,14]  R498      -3.9145222845663033e-02
    x[10,14]  R499      -0.0680494916724233
    x[10,14]  hard_lower  14
    x[10,14]  hard_upper  14
    x[10,15]  OBJ       0.05
    x[10,15]  onehot_10  1
    x[10,15]  R500      -3.9145222845663033e-02
    x[10,15]  R501      -0.0680494916724233
    x[10,15]  hard_lower  15
    x[10,15]  hard_upper  15
    x[10,16]  onehot_10  1
    x[10,16]  R502      -3.9145222845663033e-02
    x[10,16]  R503      -0.0680494916724233
    x[10,16]  hard_lower  16
    x[10,16]  hard_upper  16
    x[10,17]  OBJ       0.05
    x[10,17]  onehot_10  1
    x[10,17]  R504      -3.9145222845663033e-02
    x[10,17]  R505      -0.0680494916724233
    x[10,17]  hard_lower  17
    x[10,17]  hard_upper  17
    x[10,18]  OBJ       0.05
    x[10,18]  onehot_10  1
    x[10,18]  R506      -3.9145222845663033e-02
    x[10,18]  R507      -0.0680494916724233
    x[10,18]  hard_lower  18
    x[10,18]  hard_upper  18
    x[10,19]  OBJ       4.9999999999999996e-02
    x[10,19]  onehot_10  1
    x[10,19]  R508      -3.9145222845663033e-02
    x[10,19]  R509      -0.0680494916724233
    x[10,19]  hard_lower  19
    x[10,19]  hard_upper  19
    x[10,20]  OBJ       0.05
    x[10,20]  onehot_10  1
    x[10,20]  R510      -3.9145222845663033e-02
    x[10,20]  R511      -0.0680494916724233
    x[10,20]  hard_lower  20
    x[10,20]  hard_upper  20
    x[10,21]  OBJ       0.05
    x[10,21]  onehot_10  1
    x[10,21]  R512      -3.9145222845663033e-02
    x[10,21]  R513      -0.0680494916724233
    x[10,21]  hard_lower  21
    x[10,21]  hard_upper  21
    x[10,22]  OBJ       4.9999999999999996e-02
    x[10,22]  onehot_10  1
    x[10,22]  R514      -3.9145222845663033e-02
    x[10,22]  R515      -0.0680494916724233
    x[10,22]  hard_lower  22
    x[10,22]  hard_upper  22
    x[10,23]  OBJ       4.9999999999999996e-02
    x[10,23]  onehot_10  1
    x[10,23]  R516      -3.9145222845663033e-02
    x[10,23]  R517      -0.0680494916724233
    x[10,23]  hard_lower  23
    x[10,23]  hard_upper  23
    x[10,24]  OBJ       0.05
    x[10,24]  onehot_10  1
    x[10,24]  R518      -3.9145222845663033e-02
    x[10,24]  R519      -0.0680494916724233
    x[10,24]  hard_lower  24
    x[10,24]  hard_upper  24
    x[10,25]  OBJ       0.05
    x[10,25]  onehot_10  1
    x[10,25]  R520      -3.9145222845663033e-02
    x[10,25]  R521      -0.0680494916724233
    x[10,25]  hard_lower  25
    x[10,25]  hard_upper  25
    x[10,26]  OBJ       0.05
    x[10,26]  onehot_10  1
    x[10,26]  R522      -3.9145222845663033e-02
    x[10,26]  R523      -0.0680494916724233
    x[10,26]  hard_lower  26
    x[10,26]  hard_upper  26
    x[10,27]  OBJ       0.05
    x[10,27]  onehot_10  1
    x[10,27]  R524      -3.9145222845663033e-02
    x[10,27]  R525      -0.0680494916724233
    x[10,27]  hard_lower  27
    x[10,27]  hard_upper  27
    x[10,28]  OBJ       4.9999999999999996e-02
    x[10,28]  onehot_10  1
    x[10,28]  R526      -3.9145222845663033e-02
    x[10,28]  R527      -0.0680494916724233
    x[10,28]  hard_lower  28
    x[10,28]  hard_upper  28
    x[10,29]  OBJ       4.9999999999999996e-02
    x[10,29]  onehot_10  1
    x[10,29]  R528      -3.9145222845663033e-02
    x[10,29]  R529      -0.0680494916724233
    x[10,29]  hard_lower  29
    x[10,29]  hard_upper  29
    x[11,0]   OBJ       0.05
    x[11,0]   onehot_11  1
    x[11,0]   R534      -3.9145222845663033e-02
    x[11,0]   R535      -0.0680494916724233
    x[11,1]   OBJ       4.9999999999999996e-02
    x[11,1]   onehot_11  1
    x[11,1]   R536      -3.9145222845663033e-02
    x[11,1]   R537      -0.0680494916724233
    x[11,1]   hard_lower  1
    x[11,1]   hard_upper  1
    x[11,2]   OBJ       4.9999999999999996e-02
    x[11,2]   onehot_11  1
    x[11,2]   R538      -3.9145222845663033e-02
    x[11,2]   R539      -0.0680494916724233
    x[11,2]   hard_lower  2
    x[11,2]   hard_upper  2
    x[11,3]   OBJ       0.05
    x[11,3]   onehot_11  1
    x[11,3]   R540      -3.9145222845663033e-02
    x[11,3]   R541      -0.0680494916724233
    x[11,3]   hard_lower  3
    x[11,3]   hard_upper  3
    x[11,4]   OBJ       0.05
    x[11,4]   onehot_11  1
    x[11,4]   R542      -3.9145222845663033e-02
    x[11,4]   R543      -0.0680494916724233
    x[11,4]   hard_lower  4
    x[11,4]   hard_upper  4
    x[11,5]   OBJ       4.9999999999999996e-02
    x[11,5]   onehot_11  1
    x[11,5]   R544      -3.9145222845663033e-02
    x[11,5]   R545      -0.0680494916724233
    x[11,5]   hard_lower  5
    x[11,5]   hard_upper  5
    x[11,6]   OBJ       4.9999999999999996e-02
    x[11,6]   onehot_11  1
    x[11,6]   R546      -3.9145222845663033e-02
    x[11,6]   R547      -0.0680494916724233
    x[11,6]   hard_lower  6
    x[11,6]   hard_upper  6
    x[11,7]   OBJ       0.05
    x[11,7]   onehot_11  1
    x[11,7]   R548      -3.9145222845663033e-02
    x[11,7]   R549      -0.0680494916724233
    x[11,7]   hard_lower  7
    x[11,7]   hard_upper  7
    x[11,8]   OBJ       0.05
    x[11,8]   onehot_11  1
    x[11,8]   R550      -3.9145222845663033e-02
    x[11,8]   R551      -0.0680494916724233
    x[11,8]   hard_lower  8
    x[11,8]   hard_upper  8
    x[11,9]   OBJ       0.05
    x[11,9]   onehot_11  1
    x[11,9]   R552      -3.9145222845663033e-02
    x[11,9]   R553      -0.0680494916724233
    x[11,9]   hard_lower  9
    x[11,9]   hard_upper  9
    x[11,10]  OBJ       0.05
    x[11,10]  onehot_11  1
    x[11,10]  R554      -3.9145222845663033e-02
    x[11,10]  R555      -0.0680494916724233
    x[11,10]  hard_lower  10
    x[11,10]  hard_upper  10
    x[11,11]  OBJ       0.05
    x[11,11]  onehot_11  1
    x[11,11]  R556      -3.9145222845663033e-02
    x[11,11]  R557      -0.0680494916724233
    x[11,11]  hard_lower  11
    x[11,11]  hard_upper  11
    x[11,12]  OBJ       4.9999999999999996e-02
    x[11,12]  onehot_11  1
    x[11,12]  R558      -3.9145222845663033e-02
    x[11,12]  R559      -0.0680494916724233
    x[11,12]  hard_lower  12
    x[11,12]  hard_upper  12
    x[11,13]  OBJ       0.05
    x[11,13]  onehot_11  1
    x[11,13]  R560      -3.9145222845663033e-02
    x[11,13]  R561      -0.0680494916724233
    x[11,13]  hard_lower  13
    x[11,13]  hard_upper  13
    x[11,14]  OBJ       0.05
    x[11,14]  onehot_11  1
    x[11,14]  R562      -3.9145222845663033e-02
    x[11,14]  R563      -0.0680494916724233
    x[11,14]  hard_lower  14
    x[11,14]  hard_upper  14
    x[11,15]  OBJ       0.05
    x[11,15]  onehot_11  1
    x[11,15]  R564      -3.9145222845663033e-02
    x[11,15]  R565      -0.0680494916724233
    x[11,15]  hard_lower  15
    x[11,15]  hard_upper  15
    x[11,16]  OBJ       4.9999999999999996e-02
    x[11,16]  onehot_11  1
    x[11,16]  R566      -3.9145222845663033e-02
    x[11,16]  R567      -0.0680494916724233
    x[11,16]  hard_lower  16
    x[11,16]  hard_upper  16
    x[11,17]  OBJ       2.0816681711721684e-18
    x[11,17]  onehot_11  1
    x[11,17]  R568      -3.9145222845663033e-02
    x[11,17]  R569      -0.0680494916724233
    x[11,17]  hard_lower  17
    x[11,17]  hard_upper  17
    x[11,18]  OBJ       0.05
    x[11,18]  onehot_11  1
    x[11,18]  R570      -3.9145222845663033e-02
    x[11,18]  R571      -0.0680494916724233
    x[11,18]  hard_lower  18
    x[11,18]  hard_upper  18
    x[11,19]  OBJ       0.05
    x[11,19]  onehot_11  1
    x[11,19]  R572      -3.9145222845663033e-02
    x[11,19]  R573      -0.0680494916724233
    x[11,19]  hard_lower  19
    x[11,19]  hard_upper  19
    x[11,20]  OBJ       0.05
    x[11,20]  onehot_11  1
    x[11,20]  R574      -3.9145222845663033e-02
    x[11,20]  R575      -0.0680494916724233
    x[11,20]  hard_lower  20
    x[11,20]  hard_upper  20
    x[11,21]  OBJ       4.9999999999999996e-02
    x[11,21]  onehot_11  1
    x[11,21]  R576      -3.9145222845663033e-02
    x[11,21]  R577      -0.0680494916724233
    x[11,21]  hard_lower  21
    x[11,21]  hard_upper  21
    x[11,22]  OBJ       0.05
    x[11,22]  onehot_11  1
    x[11,22]  R578      -3.9145222845663033e-02
    x[11,22]  R579      -0.0680494916724233
    x[11,22]  hard_lower  22
    x[11,22]  hard_upper  22
    x[11,23]  OBJ       0.05
    x[11,23]  onehot_11  1
    x[11,23]  R580      -3.9145222845663033e-02
    x[11,23]  R581      -0.0680494916724233
    x[11,23]  hard_lower  23
    x[11,23]  hard_upper  23
    x[11,24]  OBJ       0.05
    x[11,24]  onehot_11  1
    x[11,24]  R582      -3.9145222845663033e-02
    x[11,24]  R583      -0.0680494916724233
    x[11,24]  hard_lower  24
    x[11,24]  hard_upper  24
    x[11,25]  OBJ       4.9999999999999996e-02
    x[11,25]  onehot_11  1
    x[11,25]  R584      -3.9145222845663033e-02
    x[11,25]  R585      -0.0680494916724233
    x[11,25]  hard_lower  25
    x[11,25]  hard_upper  25
    x[11,26]  OBJ       0.05
    x[11,26]  onehot_11  1
    x[11,26]  R586      -3.9145222845663033e-02
    x[11,26]  R587      -0.0680494916724233
    x[11,26]  hard_lower  26
    x[11,26]  hard_upper  26
    x[11,27]  OBJ       0.05
    x[11,27]  onehot_11  1
    x[11,27]  R588      -3.9145222845663033e-02
    x[11,27]  R589      -0.0680494916724233
    x[11,27]  hard_lower  27
    x[11,27]  hard_upper  27
    x[11,28]  OBJ       0.05
    x[11,28]  onehot_11  1
    x[11,28]  R590      -3.9145222845663033e-02
    x[11,28]  R591      -0.0680494916724233
    x[11,28]  hard_lower  28
    x[11,28]  hard_upper  28
    x[11,29]  OBJ       4.9999999999999996e-02
    x[11,29]  onehot_11  1
    x[11,29]  R592      -3.9145222845663033e-02
    x[11,29]  R593      -0.0680494916724233
    x[11,29]  hard_lower  29
    x[11,29]  hard_upper  29
    x[11,30]  OBJ       4.9999999999999996e-02
    x[11,30]  onehot_11  1
    x[11,30]  R594      -3.9145222845663033e-02
    x[11,30]  R595      -0.0680494916724233
    x[11,30]  hard_lower  30
    x[11,30]  hard_upper  30
    x[11,31]  OBJ       0.05
    x[11,31]  onehot_11  1
    x[11,31]  R596      -3.9145222845663033e-02
    x[11,31]  R597      -0.0680494916724233
    x[11,31]  hard_lower  31
    x[11,31]  hard_upper  31
    x[12,0]   OBJ       0.05
    x[12,0]   onehot_12  1
    x[12,0]   R602      -3.9145222845663033e-02
    x[12,0]   R603      -0.0680494916724233
    x[12,1]   OBJ       0.05
    x[12,1]   onehot_12  1
    x[12,1]   R604      -3.9145222845663033e-02
    x[12,1]   R605      -0.0680494916724233
    x[12,1]   hard_lower  1
    x[12,1]   hard_upper  1
    x[12,2]   OBJ       0.05
    x[12,2]   onehot_12  1
    x[12,2]   R606      -3.9145222845663033e-02
    x[12,2]   R607      -0.0680494916724233
    x[12,2]   hard_lower  2
    x[12,2]   hard_upper  2
    x[12,3]   OBJ       0.05
    x[12,3]   onehot_12  1
    x[12,3]   R608      -3.9145222845663033e-02
    x[12,3]   R609      -0.0680494916724233
    x[12,3]   hard_lower  3
    x[12,3]   hard_upper  3
    x[12,4]   OBJ       0.05
    x[12,4]   onehot_12  1
    x[12,4]   R610      -3.9145222845663033e-02
    x[12,4]   R611      -0.0680494916724233
    x[12,4]   hard_lower  4
    x[12,4]   hard_upper  4
    x[12,5]   OBJ       0.05
    x[12,5]   onehot_12  1
    x[12,5]   R612      -3.9145222845663033e-02
    x[12,5]   R613      -0.0680494916724233
    x[12,5]   hard_lower  5
    x[12,5]   hard_upper  5
    x[12,6]   OBJ       0.05
    x[12,6]   onehot_12  1
    x[12,6]   R614      -3.9145222845663033e-02
    x[12,6]   R615      -0.0680494916724233
    x[12,6]   hard_lower  6
    x[12,6]   hard_upper  6
    x[12,7]   OBJ       4.9999999999999996e-02
    x[12,7]   onehot_12  1
    x[12,7]   R616      -3.9145222845663033e-02
    x[12,7]   R617      -0.0680494916724233
    x[12,7]   hard_lower  7
    x[12,7]   hard_upper  7
    x[12,8]   OBJ       4.9999999999999996e-02
    x[12,8]   onehot_12  1
    x[12,8]   R618      -3.9145222845663033e-02
    x[12,8]   R619      -0.0680494916724233
    x[12,8]   hard_lower  8
    x[12,8]   hard_upper  8
    x[12,9]   OBJ       4.9999999999999996e-02
    x[12,9]   onehot_12  1
    x[12,9]   R620      -3.9145222845663033e-02
    x[12,9]   R621      -0.0680494916724233
    x[12,9]   hard_lower  9
    x[12,9]   hard_upper  9
    x[12,10]  OBJ       2.8812036090286598e-18
    x[12,10]  onehot_12  1
    x[12,10]  R622      -3.9145222845663033e-02
    x[12,10]  R623      -0.0680494916724233
    x[12,10]  hard_lower  10
    x[12,10]  hard_upper  10
    x[12,11]  OBJ       0.05
    x[12,11]  onehot_12  1
    x[12,11]  R624      -3.9145222845663033e-02
    x[12,11]  R625      -0.0680494916724233
    x[12,11]  hard_lower  11
    x[12,11]  hard_upper  11
    x[12,12]  OBJ       0.05
    x[12,12]  onehot_12  1
    x[12,12]  R626      -3.9145222845663033e-02
    x[12,12]  R627      -0.0680494916724233
    x[12,12]  hard_lower  12
    x[12,12]  hard_upper  12
    x[12,13]  OBJ       0.05
    x[12,13]  onehot_12  1
    x[12,13]  R628      -3.9145222845663033e-02
    x[12,13]  R629      -0.0680494916724233
    x[12,13]  hard_lower  13
    x[12,13]  hard_upper  13
    x[12,14]  OBJ       0.05
    x[12,14]  onehot_12  1
    x[12,14]  R630      -3.9145222845663033e-02
    x[12,14]  R631      -0.0680494916724233
    x[12,14]  hard_lower  14
    x[12,14]  hard_upper  14
    x[12,15]  OBJ       0.05
    x[12,15]  onehot_12  1
    x[12,15]  R632      -3.9145222845663033e-02
    x[12,15]  R633      -0.0680494916724233
    x[12,15]  hard_lower  15
    x[12,15]  hard_upper  15
    x[12,16]  OBJ       0.05
    x[12,16]  onehot_12  1
    x[12,16]  R634      -3.9145222845663033e-02
    x[12,16]  R635      -0.0680494916724233
    x[12,16]  hard_lower  16
    x[12,16]  hard_upper  16
    x[12,17]  OBJ       0.05
    x[12,17]  onehot_12  1
    x[12,17]  R636      -3.9145222845663033e-02
    x[12,17]  R637      -0.0680494916724233
    x[12,17]  hard_lower  17
    x[12,17]  hard_upper  17
    x[12,18]  OBJ       -2.9889142618613963e-02
    x[12,18]  onehot_12  1
    x[12,18]  R638      -3.9145222845663033e-02
    x[12,18]  R639      -0.0680494916724233
    x[12,18]  hard_lower  18
    x[12,18]  hard_upper  18
    x[12,19]  OBJ       0.05
    x[12,19]  onehot_12  1
    x[12,19]  R640      -3.9145222845663033e-02
    x[12,19]  R641      -0.0680494916724233
    x[12,19]  hard_lower  19
    x[12,19]  hard_upper  19
    x[13,0]   OBJ       5.0000000000000010e-02
    x[13,0]   onehot_13  1
    x[13,0]   R646      -3.9145222845663033e-02
    x[13,0]   R647      -0.0680494916724233
    x[13,1]   OBJ       4.9999999999999996e-02
    x[13,1]   onehot_13  1
    x[13,1]   R648      -3.9145222845663033e-02
    x[13,1]   R649      -0.0680494916724233
    x[13,1]   hard_lower  1
    x[13,1]   hard_upper  1
    x[13,2]   OBJ       0.05
    x[13,2]   onehot_13  1
    x[13,2]   R650      -3.9145222845663033e-02
    x[13,2]   R651      -0.0680494916724233
    x[13,2]   hard_lower  2
    x[13,2]   hard_upper  2
    x[13,3]   OBJ       4.9999999999999996e-02
    x[13,3]   onehot_13  1
    x[13,3]   R652      -3.9145222845663033e-02
    x[13,3]   R653      -0.0680494916724233
    x[13,3]   hard_lower  3
    x[13,3]   hard_upper  3
    x[13,4]   OBJ       0.05
    x[13,4]   onehot_13  1
    x[13,4]   R654      -3.9145222845663033e-02
    x[13,4]   R655      -0.0680494916724233
    x[13,4]   hard_lower  4
    x[13,4]   hard_upper  4
    x[13,5]   OBJ       0.05
    x[13,5]   onehot_13  1
    x[13,5]   R656      -3.9145222845663033e-02
    x[13,5]   R657      -0.0680494916724233
    x[13,5]   hard_lower  5
    x[13,5]   hard_upper  5
    x[13,6]   OBJ       0.05
    x[13,6]   onehot_13  1
    x[13,6]   R658      -3.9145222845663033e-02
    x[13,6]   R659      -0.0680494916724233
    x[13,6]   hard_lower  6
    x[13,6]   hard_upper  6
    x[13,7]   OBJ       0.05
    x[13,7]   onehot_13  1
    x[13,7]   R660      -3.9145222845663033e-02
    x[13,7]   R661      -0.0680494916724233
    x[13,7]   hard_lower  7
    x[13,7]   hard_upper  7
    x[13,8]   OBJ       0.05
    x[13,8]   onehot_13  1
    x[13,8]   R662      -3.9145222845663033e-02
    x[13,8]   R663      -0.0680494916724233
    x[13,8]   hard_lower  8
    x[13,8]   hard_upper  8
    x[13,9]   OBJ       0.05
    x[13,9]   onehot_13  1
    x[13,9]   R664      -3.9145222845663033e-02
    x[13,9]   R665      -0.0680494916724233
    x[13,9]   hard_lower  9
    x[13,9]   hard_upper  9
    x[13,10]  OBJ       0.05
    x[13,10]  onehot_13  1
    x[13,10]  R666      -3.9145222845663033e-02
    x[13,10]  R667      -0.0680494916724233
    x[13,10]  hard_lower  10
    x[13,10]  hard_upper  10
    x[13,11]  OBJ       5.0000000000000010e-02
    x[13,11]  onehot_13  1
    x[13,11]  R668      -3.9145222845663033e-02
    x[13,11]  R669      -0.0680494916724233
    x[13,11]  hard_lower  11
    x[13,11]  hard_upper  11
    x[13,12]  OBJ       5.0000000000000010e-02
    x[13,12]  onehot_13  1
    x[13,12]  R670      -3.9145222845663033e-02
    x[13,12]  R671      -0.0680494916724233
    x[13,12]  hard_lower  12
    x[13,12]  hard_upper  12
    x[13,13]  OBJ       4.86923001918882e-18
    x[13,13]  onehot_13  1
    x[13,13]  R672      -3.9145222845663033e-02
    x[13,13]  R673      -0.0680494916724233
    x[13,13]  hard_lower  13
    x[13,13]  hard_upper  13
    x[13,14]  OBJ       0.05
    x[13,14]  onehot_13  1
    x[13,14]  R674      -3.9145222845663033e-02
    x[13,14]  R675      -0.0680494916724233
    x[13,14]  hard_lower  14
    x[13,14]  hard_upper  14
    x[13,15]  OBJ       0.05
    x[13,15]  onehot_13  1
    x[13,15]  R676      -3.9145222845663033e-02
    x[13,15]  R677      -0.0680494916724233
    x[13,15]  hard_lower  15
    x[13,15]  hard_upper  15
    x[13,16]  OBJ       0.05
    x[13,16]  onehot_13  1
    x[13,16]  R678      -3.9145222845663033e-02
    x[13,16]  R679      -0.0680494916724233
    x[13,16]  hard_lower  16
    x[13,16]  hard_upper  16
    x[13,17]  OBJ       0.05
    x[13,17]  onehot_13  1
    x[13,17]  R680      -3.9145222845663033e-02
    x[13,17]  R681      -0.0680494916724233
    x[13,17]  hard_lower  17
    x[13,17]  hard_upper  17
    x[13,18]  OBJ       0.05
    x[13,18]  onehot_13  1
    x[13,18]  R682      -3.9145222845663033e-02
    x[13,18]  R683      -0.0680494916724233
    x[13,18]  hard_lower  18
    x[13,18]  hard_upper  18
    x[13,19]  OBJ       0.05
    x[13,19]  onehot_13  1
    x[13,19]  R684      -3.9145222845663033e-02
    x[13,19]  R685      -0.0680494916724233
    x[13,19]  hard_lower  19
    x[13,19]  hard_upper  19
    x[13,20]  OBJ       0.05
    x[13,20]  onehot_13  1
    x[13,20]  R686      -3.9145222845663033e-02
    x[13,20]  R687      -0.0680494916724233
    x[13,20]  hard_lower  20
    x[13,20]  hard_upper  20
    x[13,21]  OBJ       0.05
    x[13,21]  onehot_13  1
    x[13,21]  R688      -3.9145222845663033e-02
    x[13,21]  R689      -0.0680494916724233
    x[13,21]  hard_lower  21
    x[13,21]  hard_upper  21
    x[13,22]  OBJ       5.0000000000000010e-02
    x[13,22]  onehot_13  1
    x[13,22]  R690      -3.9145222845663033e-02
    x[13,22]  R691      -0.0680494916724233
    x[13,22]  hard_lower  22
    x[13,22]  hard_upper  22
    x[13,23]  OBJ       0.05
    x[13,23]  onehot_13  1
    x[13,23]  R692      -3.9145222845663033e-02
    x[13,23]  R693      -0.0680494916724233
    x[13,23]  hard_lower  23
    x[13,23]  hard_upper  23
    x[13,24]  OBJ       4.9999999999999996e-02
    x[13,24]  onehot_13  1
    x[13,24]  R694      -3.9145222845663033e-02
    x[13,24]  R695      -0.0680494916724233
    x[13,24]  hard_lower  24
    x[13,24]  hard_upper  24
    x[13,25]  OBJ       0.05
    x[13,25]  onehot_13  1
    x[13,25]  R696      -3.9145222845663033e-02
    x[13,25]  R697      -0.0680494916724233
    x[13,25]  hard_lower  25
    x[13,25]  hard_upper  25
    x[14,0]   OBJ       5.0000000000000010e-02
    x[14,0]   onehot_14  1
    x[14,0]   R702      -3.9145222845663033e-02
    x[14,0]   R703      -0.0680494916724233
    x[14,1]   OBJ       4.9999999999999996e-02
    x[14,1]   onehot_14  1
    x[14,1]   R704      -3.9145222845663033e-02
    x[14,1]   R705      -0.0680494916724233
    x[14,1]   hard_lower  1
    x[14,1]   hard_upper  1
    x[14,2]   OBJ       0.05
    x[14,2]   onehot_14  1
    x[14,2]   R706      -3.9145222845663033e-02
    x[14,2]   R707      -0.0680494916724233
    x[14,2]   hard_lower  2
    x[14,2]   hard_upper  2
    x[14,3]   OBJ       4.9999999999999996e-02
    x[14,3]   onehot_14  1
    x[14,3]   R708      -3.9145222845663033e-02
    x[14,3]   R709      -0.0680494916724233
    x[14,3]   hard_lower  3
    x[14,3]   hard_upper  3
    x[14,4]   OBJ       0.05
    x[14,4]   onehot_14  1
    x[14,4]   R710      -3.9145222845663033e-02
    x[14,4]   R711      -0.0680494916724233
    x[14,4]   hard_lower  4
    x[14,4]   hard_upper  4
    x[14,5]   OBJ       0.05
    x[14,5]   onehot_14  1
    x[14,5]   R712      -3.9145222845663033e-02
    x[14,5]   R713      -0.0680494916724233
    x[14,5]   hard_lower  5
    x[14,5]   hard_upper  5
    x[14,6]   OBJ       0.05
    x[14,6]   onehot_14  1
    x[14,6]   R714      -3.9145222845663033e-02
    x[14,6]   R715      -0.0680494916724233
    x[14,6]   hard_lower  6
    x[14,6]   hard_upper  6
    x[14,7]   OBJ       0.05
    x[14,7]   onehot_14  1
    x[14,7]   R716      -3.9145222845663033e-02
    x[14,7]   R717      -0.0680494916724233
    x[14,7]   hard_lower  7
    x[14,7]   hard_upper  7
    x[14,8]   OBJ       0.05
    x[14,8]   onehot_14  1
    x[14,8]   R718      -3.9145222845663033e-02
    x[14,8]   R719      -0.0680494916724233
    x[14,8]   hard_lower  8
    x[14,8]   hard_upper  8
    x[14,9]   OBJ       0.05
    x[14,9]   onehot_14  1
    x[14,9]   R720      -3.9145222845663033e-02
    x[14,9]   R721      -0.0680494916724233
    x[14,9]   hard_lower  9
    x[14,9]   hard_upper  9
    x[14,10]  OBJ       0.05
    x[14,10]  onehot_14  1
    x[14,10]  R722      -3.9145222845663033e-02
    x[14,10]  R723      -0.0680494916724233
    x[14,10]  hard_lower  10
    x[14,10]  hard_upper  10
    x[14,11]  OBJ       5.0000000000000010e-02
    x[14,11]  onehot_14  1
    x[14,11]  R724      -3.9145222845663033e-02
    x[14,11]  R725      -0.0680494916724233
    x[14,11]  hard_lower  11
    x[14,11]  hard_upper  11
    x[14,12]  OBJ       5.0000000000000010e-02
    x[14,12]  onehot_14  1
    x[14,12]  R726      -3.9145222845663033e-02
    x[14,12]  R727      -0.0680494916724233
    x[14,12]  hard_lower  12
    x[14,12]  hard_upper  12
    x[14,13]  OBJ       4.86923001918882e-18
    x[14,13]  onehot_14  1
    x[14,13]  R728      -3.9145222845663033e-02
    x[14,13]  R729      -0.0680494916724233
    x[14,13]  hard_lower  13
    x[14,13]  hard_upper  13
    x[14,14]  OBJ       0.05
    x[14,14]  onehot_14  1
    x[14,14]  R730      -3.9145222845663033e-02
    x[14,14]  R731      -0.0680494916724233
    x[14,14]  hard_lower  14
    x[14,14]  hard_upper  14
    x[14,15]  OBJ       0.05
    x[14,15]  onehot_14  1
    x[14,15]  R732      -3.9145222845663033e-02
    x[14,15]  R733      -0.0680494916724233
    x[14,15]  hard_lower  15
    x[14,15]  hard_upper  15
    x[14,16]  OBJ       0.05
    x[14,16]  onehot_14  1
    x[14,16]  R734      -3.9145222845663033e-02
    x[14,16]  R735      -0.0680494916724233
    x[14,16]  hard_lower  16
    x[14,16]  hard_upper  16
    x[14,17]  OBJ       0.05
    x[14,17]  onehot_14  1
    x[14,17]  R736      -3.9145222845663033e-02
    x[14,17]  R737      -0.0680494916724233
    x[14,17]  hard_lower  17
    x[14,17]  hard_upper  17
    x[14,18]  OBJ       0.05
    x[14,18]  onehot_14  1
    x[14,18]  R738      -3.9145222845663033e-02
    x[14,18]  R739      -0.0680494916724233
    x[14,18]  hard_lower  18
    x[14,18]  hard_upper  18
    x[14,19]  OBJ       0.05
    x[14,19]  onehot_14  1
    x[14,19]  R740      -3.9145222845663033e-02
    x[14,19]  R741      -0.0680494916724233
    x[14,19]  hard_lower  19
    x[14,19]  hard_upper  19
    x[14,20]  OBJ       0.05
    x[14,20]  onehot_14  1
    x[14,20]  R742      -3.9145222845663033e-02
    x[14,20]  R743      -0.0680494916724233
    x[14,20]  hard_lower  20
    x[14,20]  hard_upper  20
    x[14,21]  OBJ       0.05
    x[14,21]  onehot_14  1
    x[14,21]  R744      -3.9145222845663033e-02
    x[14,21]  R745      -0.0680494916724233
    x[14,21]  hard_lower  21
    x[14,21]  hard_upper  21
    x[14,22]  OBJ       5.0000000000000010e-02
    x[14,22]  onehot_14  1
    x[14,22]  R746      -3.9145222845663033e-02
    x[14,22]  R747      -0.0680494916724233
    x[14,22]  hard_lower  22
    x[14,22]  hard_upper  22
    x[14,23]  OBJ       0.05
    x[14,23]  onehot_14  1
    x[14,23]  R748      -3.9145222845663033e-02
    x[14,23]  R749      -0.0680494916724233
    x[14,23]  hard_lower  23
    x[14,23]  hard_upper  23
    x[15,0]   OBJ       5.0000000000000010e-02
    x[15,0]   onehot_15  1
    x[15,0]   R754      -3.9145222845663033e-02
    x[15,0]   R755      -0.0680494916724233
    x[15,1]   OBJ       0.05
    x[15,1]   onehot_15  1
    x[15,1]   R756      -3.9145222845663033e-02
    x[15,1]   R757      -0.0680494916724233
    x[15,1]   hard_lower  1
    x[15,1]   hard_upper  1
    x[15,2]   OBJ       0.05
    x[15,2]   onehot_15  1
    x[15,2]   R758      -3.9145222845663033e-02
    x[15,2]   R759      -0.0680494916724233
    x[15,2]   hard_lower  2
    x[15,2]   hard_upper  2
    x[15,3]   OBJ       0.05
    x[15,3]   onehot_15  1
    x[15,3]   R760      -3.9145222845663033e-02
    x[15,3]   R761      -0.0680494916724233
    x[15,3]   hard_lower  3
    x[15,3]   hard_upper  3
    x[15,4]   OBJ       0.05
    x[15,4]   onehot_15  1
    x[15,4]   R762      -3.9145222845663033e-02
    x[15,4]   R763      -0.0680494916724233
    x[15,4]   hard_lower  4
    x[15,4]   hard_upper  4
    x[15,5]   OBJ       0.05
    x[15,5]   onehot_15  1
    x[15,5]   R764      -3.9145222845663033e-02
    x[15,5]   R765      -0.0680494916724233
    x[15,5]   hard_lower  5
    x[15,5]   hard_upper  5
    x[15,6]   OBJ       5.0000000000000010e-02
    x[15,6]   onehot_15  1
    x[15,6]   R766      -3.9145222845663033e-02
    x[15,6]   R767      -0.0680494916724233
    x[15,6]   hard_lower  6
    x[15,6]   hard_upper  6
    x[15,7]   OBJ       5.0000000000000010e-02
    x[15,7]   onehot_15  1
    x[15,7]   R768      -3.9145222845663033e-02
    x[15,7]   R769      -0.0680494916724233
    x[15,7]   hard_lower  7
    x[15,7]   hard_upper  7
    x[15,8]   OBJ       5.0000000000000010e-02
    x[15,8]   onehot_15  1
    x[15,8]   R770      -3.9145222845663033e-02
    x[15,8]   R771      -0.0680494916724233
    x[15,8]   hard_lower  8
    x[15,8]   hard_upper  8
    x[15,9]   OBJ       0.05
    x[15,9]   onehot_15  1
    x[15,9]   R772      -3.9145222845663033e-02
    x[15,9]   R773      -0.0680494916724233
    x[15,9]   hard_lower  9
    x[15,9]   hard_upper  9
    x[15,10]  OBJ       5.0000000000000010e-02
    x[15,10]  onehot_15  1
    x[15,10]  R774      -3.9145222845663033e-02
    x[15,10]  R775      -0.0680494916724233
    x[15,10]  hard_lower  10
    x[15,10]  hard_upper  10
    x[15,11]  OBJ       5.0000000000000010e-02
    x[15,11]  onehot_15  1
    x[15,11]  R776      -3.9145222845663033e-02
    x[15,11]  R777      -0.0680494916724233
    x[15,11]  hard_lower  11
    x[15,11]  hard_upper  11
    x[15,12]  OBJ       0.05
    x[15,12]  onehot_15  1
    x[15,12]  R778      -3.9145222845663033e-02
    x[15,12]  R779      -0.0680494916724233
    x[15,12]  hard_lower  12
    x[15,12]  hard_upper  12
    x[15,13]  OBJ       0.05
    x[15,13]  onehot_15  1
    x[15,13]  R780      -3.9145222845663033e-02
    x[15,13]  R781      -0.0680494916724233
    x[15,13]  hard_lower  13
    x[15,13]  hard_upper  13
    x[15,14]  OBJ       5.6471577414285437e-18
    x[15,14]  onehot_15  1
    x[15,14]  R782      -3.9145222845663033e-02
    x[15,14]  R783      -0.0680494916724233
    x[15,14]  hard_lower  14
    x[15,14]  hard_upper  14
    x[15,15]  OBJ       5.0000000000000010e-02
    x[15,15]  onehot_15  1
    x[15,15]  R784      -3.9145222845663033e-02
    x[15,15]  R785      -0.0680494916724233
    x[15,15]  hard_lower  15
    x[15,15]  hard_upper  15
    x[15,16]  OBJ       5.0000000000000010e-02
    x[15,16]  onehot_15  1
    x[15,16]  R786      -3.9145222845663033e-02
    x[15,16]  R787      -0.0680494916724233
    x[15,16]  hard_lower  16
    x[15,16]  hard_upper  16
    x[15,17]  OBJ       0.05
    x[15,17]  onehot_15  1
    x[15,17]  R788      -3.9145222845663033e-02
    x[15,17]  R789      -0.0680494916724233
    x[15,17]  hard_lower  17
    x[15,17]  hard_upper  17
    x[15,18]  OBJ       5.0000000000000010e-02
    x[15,18]  onehot_15  1
    x[15,18]  R790      -3.9145222845663033e-02
    x[15,18]  R791      -0.0680494916724233
    x[15,18]  hard_lower  18
    x[15,18]  hard_upper  18
    x[15,19]  OBJ       0.05
    x[15,19]  onehot_15  1
    x[15,19]  R792      -3.9145222845663033e-02
    x[15,19]  R793      -0.0680494916724233
    x[15,19]  hard_lower  19
    x[15,19]  hard_upper  19
    x[15,20]  OBJ       0.05
    x[15,20]  onehot_15  1
    x[15,20]  R794      -3.9145222845663033e-02
    x[15,20]  R795      -0.0680494916724233
    x[15,20]  hard_lower  20
    x[15,20]  hard_upper  20
    x[15,21]  OBJ       0.05
    x[15,21]  onehot_15  1
    x[15,21]  R796      -3.9145222845663033e-02
    x[15,21]  R797      -0.0680494916724233
    x[15,21]  hard_lower  21
    x[15,21]  hard_upper  21
    x[15,22]  OBJ       0.05
    x[15,22]  onehot_15  1
    x[15,22]  R798      -3.9145222845663033e-02
    x[15,22]  R799      -0.0680494916724233
    x[15,22]  hard_lower  22
    x[15,22]  hard_upper  22
    x[15,23]  OBJ       0.05
    x[15,23]  onehot_15  1
    x[15,23]  R800      -3.9145222845663033e-02
    x[15,23]  R801      -0.0680494916724233
    x[15,23]  hard_lower  23
    x[15,23]  hard_upper  23
    x[15,24]  OBJ       5.0000000000000010e-02
    x[15,24]  onehot_15  1
    x[15,24]  R802      -3.9145222845663033e-02
    x[15,24]  R803      -0.0680494916724233
    x[15,24]  hard_lower  24
    x[15,24]  hard_upper  24
    x[15,25]  OBJ       5.0000000000000010e-02
    x[15,25]  onehot_15  1
    x[15,25]  R804      -3.9145222845663033e-02
    x[15,25]  R805      -0.0680494916724233
    x[15,25]  hard_lower  25
    x[15,25]  hard_upper  25
    x[15,26]  OBJ       5.0000000000000010e-02
    x[15,26]  onehot_15  1
    x[15,26]  R806      -3.9145222845663033e-02
    x[15,26]  R807      -0.0680494916724233
    x[15,26]  hard_lower  26
    x[15,26]  hard_upper  26
    x[15,27]  OBJ       5.0000000000000010e-02
    x[15,27]  onehot_15  1
    x[15,27]  R808      -3.9145222845663033e-02
    x[15,27]  R809      -0.0680494916724233
    x[15,27]  hard_lower  27
    x[15,27]  hard_upper  27
    x[16,0]   OBJ       0.05
    x[16,0]   onehot_16  1
    x[16,0]   R814      -3.9145222845663033e-02
    x[16,0]   R815      -0.0680494916724233
    x[16,1]   OBJ       4.9999999999999996e-02
    x[16,1]   onehot_16  1
    x[16,1]   R816      -3.9145222845663033e-02
    x[16,1]   R817      -0.0680494916724233
    x[16,1]   hard_lower  1
    x[16,1]   hard_upper  1
    x[16,2]   OBJ       0.05
    x[16,2]   onehot_16  1
    x[16,2]   R818      -3.9145222845663033e-02
    x[16,2]   R819      -0.0680494916724233
    x[16,2]   hard_lower  2
    x[16,2]   hard_upper  2
    x[16,3]   OBJ       0.05
    x[16,3]   onehot_16  1
    x[16,3]   R820      -3.9145222845663033e-02
    x[16,3]   R821      -0.0680494916724233
    x[16,3]   hard_lower  3
    x[16,3]   hard_upper  3
    x[16,4]   OBJ       0.05
    x[16,4]   onehot_16  1
    x[16,4]   R822      -3.9145222845663033e-02
    x[16,4]   R823      -0.0680494916724233
    x[16,4]   hard_lower  4
    x[16,4]   hard_upper  4
    x[16,5]   OBJ       0.05
    x[16,5]   onehot_16  1
    x[16,5]   R824      -3.9145222845663033e-02
    x[16,5]   R825      -0.0680494916724233
    x[16,5]   hard_lower  5
    x[16,5]   hard_upper  5
    x[16,6]   OBJ       0.05
    x[16,6]   onehot_16  1
    x[16,6]   R826      -3.9145222845663033e-02
    x[16,6]   R827      -0.0680494916724233
    x[16,6]   hard_lower  6
    x[16,6]   hard_upper  6
    x[16,7]   OBJ       0.05
    x[16,7]   onehot_16  1
    x[16,7]   R828      -3.9145222845663033e-02
    x[16,7]   R829      -0.0680494916724233
    x[16,7]   hard_lower  7
    x[16,7]   hard_upper  7
    x[16,8]   OBJ       0.05
    x[16,8]   onehot_16  1
    x[16,8]   R830      -3.9145222845663033e-02
    x[16,8]   R831      -0.0680494916724233
    x[16,8]   hard_lower  8
    x[16,8]   hard_upper  8
    x[16,9]   OBJ       0.05
    x[16,9]   onehot_16  1
    x[16,9]   R832      -3.9145222845663033e-02
    x[16,9]   R833      -0.0680494916724233
    x[16,9]   hard_lower  9
    x[16,9]   hard_upper  9
    x[16,10]  OBJ       5.0000000000000010e-02
    x[16,10]  onehot_16  1
    x[16,10]  R834      -3.9145222845663033e-02
    x[16,10]  R835      -0.0680494916724233
    x[16,10]  hard_lower  10
    x[16,10]  hard_upper  10
    x[16,11]  OBJ       5.0000000000000010e-02
    x[16,11]  onehot_16  1
    x[16,11]  R836      -3.9145222845663033e-02
    x[16,11]  R837      -0.0680494916724233
    x[16,11]  hard_lower  11
    x[16,11]  hard_upper  11
    x[16,12]  OBJ       4.1489311985998257e-18
    x[16,12]  onehot_16  1
    x[16,12]  R838      -3.9145222845663033e-02
    x[16,12]  R839      -0.0680494916724233
    x[16,12]  hard_lower  12
    x[16,12]  hard_upper  12
    x[16,13]  OBJ       5.0000000000000010e-02
    x[16,13]  onehot_16  1
    x[16,13]  R840      -3.9145222845663033e-02
    x[16,13]  R841      -0.0680494916724233
    x[16,13]  hard_lower  13
    x[16,13]  hard_upper  13
    x[16,14]  OBJ       0.05
    x[16,14]  onehot_16  1
    x[16,14]  R842      -3.9145222845663033e-02
    x[16,14]  R843      -0.0680494916724233
    x[16,14]  hard_lower  14
    x[16,14]  hard_upper  14
    x[16,15]  OBJ       0.05
    x[16,15]  onehot_16  1
    x[16,15]  R844      -3.9145222845663033e-02
    x[16,15]  R845      -0.0680494916724233
    x[16,15]  hard_lower  15
    x[16,15]  hard_upper  15
    x[16,16]  OBJ       0.05
    x[16,16]  onehot_16  1
    x[16,16]  R846      -3.9145222845663033e-02
    x[16,16]  R847      -0.0680494916724233
    x[16,16]  hard_lower  16
    x[16,16]  hard_upper  16
    x[16,17]  OBJ       0.05
    x[16,17]  onehot_16  1
    x[16,17]  R848      -3.9145222845663033e-02
    x[16,17]  R849      -0.0680494916724233
    x[16,17]  hard_lower  17
    x[16,17]  hard_upper  17
    x[16,18]  OBJ       0.05
    x[16,18]  onehot_16  1
    x[16,18]  R850      -3.9145222845663033e-02
    x[16,18]  R851      -0.0680494916724233
    x[16,18]  hard_lower  18
    x[16,18]  hard_upper  18
    x[16,19]  OBJ       0.05
    x[16,19]  onehot_16  1
    x[16,19]  R852      -3.9145222845663033e-02
    x[16,19]  R853      -0.0680494916724233
    x[16,19]  hard_lower  19
    x[16,19]  hard_upper  19
    x[16,20]  OBJ       0.05
    x[16,20]  onehot_16  1
    x[16,20]  R854      -3.9145222845663033e-02
    x[16,20]  R855      -0.0680494916724233
    x[16,20]  hard_lower  20
    x[16,20]  hard_upper  20
    x[16,21]  OBJ       -2.9179699545013954e-02
    x[16,21]  onehot_16  1
    x[16,21]  R856      -3.9145222845663033e-02
    x[16,21]  R857      -0.0680494916724233
    x[16,21]  hard_lower  21
    x[16,21]  hard_upper  21
    x[16,22]  OBJ       0.05
    x[16,22]  onehot_16  1
    x[16,22]  R858      -3.9145222845663033e-02
    x[16,22]  R859      -0.0680494916724233
    x[16,22]  hard_lower  22
    x[16,22]  hard_upper  22
    x[17,0]   OBJ       0.05
    x[17,0]   onehot_17  1
    x[17,0]   R864      -3.9145222845663033e-02
    x[17,0]   R865      -0.0680494916724233
    x[17,1]   OBJ       4.9999999999999996e-02
    x[17,1]   onehot_17  1
    x[17,1]   R866      -3.9145222845663033e-02
    x[17,1]   R867      -0.0680494916724233
    x[17,1]   hard_lower  1
    x[17,1]   hard_upper  1
    x[17,2]   OBJ       4.9999999999999996e-02
    x[17,2]   onehot_17  1
    x[17,2]   R868      -3.9145222845663033e-02
    x[17,2]   R869      -0.0680494916724233
    x[17,2]   hard_lower  2
    x[17,2]   hard_upper  2
    x[17,3]   OBJ       0.05
    x[17,3]   onehot_17  1
    x[17,3]   R870      -3.9145222845663033e-02
    x[17,3]   R871      -0.0680494916724233
    x[17,3]   hard_lower  3
    x[17,3]   hard_upper  3
    x[17,4]   OBJ       0.05
    x[17,4]   onehot_17  1
    x[17,4]   R872      -3.9145222845663033e-02
    x[17,4]   R873      -0.0680494916724233
    x[17,4]   hard_lower  4
    x[17,4]   hard_upper  4
    x[17,5]   OBJ       4.9999999999999996e-02
    x[17,5]   onehot_17  1
    x[17,5]   R874      -3.9145222845663033e-02
    x[17,5]   R875      -0.0680494916724233
    x[17,5]   hard_lower  5
    x[17,5]   hard_upper  5
    x[17,6]   OBJ       0.05
    x[17,6]   onehot_17  1
    x[17,6]   R876      -3.9145222845663033e-02
    x[17,6]   R877      -0.0680494916724233
    x[17,6]   hard_lower  6
    x[17,6]   hard_upper  6
    x[17,7]   OBJ       0.05
    x[17,7]   onehot_17  1
    x[17,7]   R878      -3.9145222845663033e-02
    x[17,7]   R879      -0.0680494916724233
    x[17,7]   hard_lower  7
    x[17,7]   hard_upper  7
    x[17,8]   onehot_17  1
    x[17,8]   R880      -3.9145222845663033e-02
    x[17,8]   R881      -0.0680494916724233
    x[17,8]   hard_lower  8
    x[17,8]   hard_upper  8
    x[17,9]   OBJ       0.05
    x[17,9]   onehot_17  1
    x[17,9]   R882      -3.9145222845663033e-02
    x[17,9]   R883      -0.0680494916724233
    x[17,9]   hard_lower  9
    x[17,9]   hard_upper  9
    x[17,10]  OBJ       0.05
    x[17,10]  onehot_17  1
    x[17,10]  R884      -3.9145222845663033e-02
    x[17,10]  R885      -0.0680494916724233
    x[17,10]  hard_lower  10
    x[17,10]  hard_upper  10
    x[17,11]  OBJ       4.9999999999999996e-02
    x[17,11]  onehot_17  1
    x[17,11]  R886      -3.9145222845663033e-02
    x[17,11]  R887      -0.0680494916724233
    x[17,11]  hard_lower  11
    x[17,11]  hard_upper  11
    x[17,12]  OBJ       0.05
    x[17,12]  onehot_17  1
    x[17,12]  R888      -3.9145222845663033e-02
    x[17,12]  R889      -0.0680494916724233
    x[17,12]  hard_lower  12
    x[17,12]  hard_upper  12
    x[17,13]  OBJ       0.05
    x[17,13]  onehot_17  1
    x[17,13]  R890      -3.9145222845663033e-02
    x[17,13]  R891      -0.0680494916724233
    x[17,13]  hard_lower  13
    x[17,13]  hard_upper  13
    x[17,14]  OBJ       4.9999999999999996e-02
    x[17,14]  onehot_17  1
    x[17,14]  R892      -3.9145222845663033e-02
    x[17,14]  R893      -0.0680494916724233
    x[17,14]  hard_lower  14
    x[17,14]  hard_upper  14
    x[17,15]  OBJ       4.9999999999999996e-02
    x[17,15]  onehot_17  1
    x[17,15]  R894      -3.9145222845663033e-02
    x[17,15]  R895      -0.0680494916724233
    x[17,15]  hard_lower  15
    x[17,15]  hard_upper  15
    x[17,16]  OBJ       -3.8159539211094932e-02
    x[17,16]  onehot_17  1
    x[17,16]  R896      -3.9145222845663033e-02
    x[17,16]  R897      -0.0680494916724233
    x[17,16]  hard_lower  16
    x[17,16]  hard_upper  16
    x[17,17]  OBJ       0.05
    x[17,17]  onehot_17  1
    x[17,17]  R898      -3.9145222845663033e-02
    x[17,17]  R899      -0.0680494916724233
    x[17,17]  hard_lower  17
    x[17,17]  hard_upper  17
    x[17,18]  OBJ       0.05
    x[17,18]  onehot_17  1
    x[17,18]  R900      -3.9145222845663033e-02
    x[17,18]  R901      -0.0680494916724233
    x[17,18]  hard_lower  18
    x[17,18]  hard_upper  18
    x[17,19]  OBJ       0.05
    x[17,19]  onehot_17  1
    x[17,19]  R902      -3.9145222845663033e-02
    x[17,19]  R903      -0.0680494916724233
    x[17,19]  hard_lower  19
    x[17,19]  hard_upper  19
    x[18,0]   OBJ       0.05
    x[18,0]   onehot_18  1
    x[18,0]   R908      -3.9145222845663033e-02
    x[18,0]   R909      -0.0680494916724233
    x[18,1]   OBJ       0.05
    x[18,1]   onehot_18  1
    x[18,1]   R910      -3.9145222845663033e-02
    x[18,1]   R911      -0.0680494916724233
    x[18,1]   hard_lower  1
    x[18,1]   hard_upper  1
    x[18,2]   OBJ       4.9999999999999996e-02
    x[18,2]   onehot_18  1
    x[18,2]   R912      -3.9145222845663033e-02
    x[18,2]   R913      -0.0680494916724233
    x[18,2]   hard_lower  2
    x[18,2]   hard_upper  2
    x[18,3]   OBJ       0.05
    x[18,3]   onehot_18  1
    x[18,3]   R914      -3.9145222845663033e-02
    x[18,3]   R915      -0.0680494916724233
    x[18,3]   hard_lower  3
    x[18,3]   hard_upper  3
    x[18,4]   OBJ       0.05
    x[18,4]   onehot_18  1
    x[18,4]   R916      -3.9145222845663033e-02
    x[18,4]   R917      -0.0680494916724233
    x[18,4]   hard_lower  4
    x[18,4]   hard_upper  4
    x[18,5]   OBJ       0.05
    x[18,5]   onehot_18  1
    x[18,5]   R918      -3.9145222845663033e-02
    x[18,5]   R919      -0.0680494916724233
    x[18,5]   hard_lower  5
    x[18,5]   hard_upper  5
    x[18,6]   OBJ       0.05
    x[18,6]   onehot_18  1
    x[18,6]   R920      -3.9145222845663033e-02
    x[18,6]   R921      -0.0680494916724233
    x[18,6]   hard_lower  6
    x[18,6]   hard_upper  6
    x[18,7]   OBJ       0.05
    x[18,7]   onehot_18  1
    x[18,7]   R922      -3.9145222845663033e-02
    x[18,7]   R923      -0.0680494916724233
    x[18,7]   hard_lower  7
    x[18,7]   hard_upper  7
    x[18,8]   OBJ       0.05
    x[18,8]   onehot_18  1
    x[18,8]   R924      -3.9145222845663033e-02
    x[18,8]   R925      -0.0680494916724233
    x[18,8]   hard_lower  8
    x[18,8]   hard_upper  8
    x[18,9]   OBJ       0.05
    x[18,9]   onehot_18  1
    x[18,9]   R926      -3.9145222845663033e-02
    x[18,9]   R927      -0.0680494916724233
    x[18,9]   hard_lower  9
    x[18,9]   hard_upper  9
    x[18,10]  OBJ       4.9999999999999996e-02
    x[18,10]  onehot_18  1
    x[18,10]  R928      -3.9145222845663033e-02
    x[18,10]  R929      -0.0680494916724233
    x[18,10]  hard_lower  10
    x[18,10]  hard_upper  10
    x[18,11]  OBJ       1.7431264764944385e-18
    x[18,11]  onehot_18  1
    x[18,11]  R930      -3.9145222845663033e-02
    x[18,11]  R931      -0.0680494916724233
    x[18,11]  hard_lower  11
    x[18,11]  hard_upper  11
    x[18,12]  OBJ       0.05
    x[18,12]  onehot_18  1
    x[18,12]  R932      -3.9145222845663033e-02
    x[18,12]  R933      -0.0680494916724233
    x[18,12]  hard_lower  12
    x[18,12]  hard_upper  12
    x[18,13]  OBJ       4.9999999999999996e-02
    x[18,13]  onehot_18  1
    x[18,13]  R934      -3.9145222845663033e-02
    x[18,13]  R935      -0.0680494916724233
    x[18,13]  hard_lower  13
    x[18,13]  hard_upper  13
    x[18,14]  OBJ       4.9999999999999996e-02
    x[18,14]  onehot_18  1
    x[18,14]  R936      -3.9145222845663033e-02
    x[18,14]  R937      -0.0680494916724233
    x[18,14]  hard_lower  14
    x[18,14]  hard_upper  14
    x[18,15]  OBJ       0.05
    x[18,15]  onehot_18  1
    x[18,15]  R938      -3.9145222845663033e-02
    x[18,15]  R939      -0.0680494916724233
    x[18,15]  hard_lower  15
    x[18,15]  hard_upper  15
    x[18,16]  OBJ       0.05
    x[18,16]  onehot_18  1
    x[18,16]  R940      -3.9145222845663033e-02
    x[18,16]  R941      -0.0680494916724233
    x[18,16]  hard_lower  16
    x[18,16]  hard_upper  16
    x[18,17]  OBJ       0.05
    x[18,17]  onehot_18  1
    x[18,17]  R942      -3.9145222845663033e-02
    x[18,17]  R943      -0.0680494916724233
    x[18,17]  hard_lower  17
    x[18,17]  hard_upper  17
    x[18,18]  OBJ       4.9999999999999996e-02
    x[18,18]  onehot_18  1
    x[18,18]  R944      -3.9145222845663033e-02
    x[18,18]  R945      -0.0680494916724233
    x[18,18]  hard_lower  18
    x[18,18]  hard_upper  18
    x[18,19]  OBJ       0.05
    x[18,19]  onehot_18  1
    x[18,19]  R946      -3.9145222845663033e-02
    x[18,19]  R947      -0.0680494916724233
    x[18,19]  hard_lower  19
    x[18,19]  hard_upper  19
    x[18,20]  OBJ       -3.1633932074429064e-02
    x[18,20]  onehot_18  1
    x[18,20]  R948      -3.9145222845663033e-02
    x[18,20]  R949      -0.0680494916724233
    x[18,20]  hard_lower  20
    x[18,20]  hard_upper  20
    x[18,21]  OBJ       0.05
    x[18,21]  onehot_18  1
    x[18,21]  R950      -3.9145222845663033e-02
    x[18,21]  R951      -0.0680494916724233
    x[18,21]  hard_lower  21
    x[18,21]  hard_upper  21
    x[18,22]  OBJ       0.05
    x[18,22]  onehot_18  1
    x[18,22]  R952      -3.9145222845663033e-02
    x[18,22]  R953      -0.0680494916724233
    x[18,22]  hard_lower  22
    x[18,22]  hard_upper  22
    x[19,0]   OBJ       0.05
    x[19,0]   onehot_19  1
    x[19,0]   R958      -3.9145222845663033e-02
    x[19,0]   R959      -0.0680494916724233
    x[19,1]   OBJ       4.9999999999999996e-02
    x[19,1]   onehot_19  1
    x[19,1]   R960      -3.9145222845663033e-02
    x[19,1]   R961      -0.0680494916724233
    x[19,1]   hard_lower  1
    x[19,1]   hard_upper  1
    x[19,2]   OBJ       0.05
    x[19,2]   onehot_19  1
    x[19,2]   R962      -3.9145222845663033e-02
    x[19,2]   R963      -0.0680494916724233
    x[19,2]   hard_lower  2
    x[19,2]   hard_upper  2
    x[19,3]   OBJ       0.05
    x[19,3]   onehot_19  1
    x[19,3]   R964      -3.9145222845663033e-02
    x[19,3]   R965      -0.0680494916724233
    x[19,3]   hard_lower  3
    x[19,3]   hard_upper  3
    x[19,4]   OBJ       0.05
    x[19,4]   onehot_19  1
    x[19,4]   R966      -3.9145222845663033e-02
    x[19,4]   R967      -0.0680494916724233
    x[19,4]   hard_lower  4
    x[19,4]   hard_upper  4
    x[19,5]   OBJ       0.05
    x[19,5]   onehot_19  1
    x[19,5]   R968      -3.9145222845663033e-02
    x[19,5]   R969      -0.0680494916724233
    x[19,5]   hard_lower  5
    x[19,5]   hard_upper  5
    x[19,6]   OBJ       0.05
    x[19,6]   onehot_19  1
    x[19,6]   R970      -3.9145222845663033e-02
    x[19,6]   R971      -0.0680494916724233
    x[19,6]   hard_lower  6
    x[19,6]   hard_upper  6
    x[19,7]   OBJ       0.05
    x[19,7]   onehot_19  1
    x[19,7]   R972      -3.9145222845663033e-02
    x[19,7]   R973      -0.0680494916724233
    x[19,7]   hard_lower  7
    x[19,7]   hard_upper  7
    x[19,8]   OBJ       0.05
    x[19,8]   onehot_19  1
    x[19,8]   R974      -3.9145222845663033e-02
    x[19,8]   R975      -0.0680494916724233
    x[19,8]   hard_lower  8
    x[19,8]   hard_upper  8
    x[19,9]   OBJ       0.05
    x[19,9]   onehot_19  1
    x[19,9]   R976      -3.9145222845663033e-02
    x[19,9]   R977      -0.0680494916724233
    x[19,9]   hard_lower  9
    x[19,9]   hard_upper  9
    x[19,10]  OBJ       5.0000000000000010e-02
    x[19,10]  onehot_19  1
    x[19,10]  R978      -3.9145222845663033e-02
    x[19,10]  R979      -0.0680494916724233
    x[19,10]  hard_lower  10
    x[19,10]  hard_upper  10
    x[19,11]  OBJ       5.0000000000000010e-02
    x[19,11]  onehot_19  1
    x[19,11]  R980      -3.9145222845663033e-02
    x[19,11]  R981      -0.0680494916724233
    x[19,11]  hard_lower  11
    x[19,11]  hard_upper  11
    x[19,12]  OBJ       4.1489311985998257e-18
    x[19,12]  onehot_19  1
    x[19,12]  R982      -3.9145222845663033e-02
    x[19,12]  R983      -0.0680494916724233
    x[19,12]  hard_lower  12
    x[19,12]  hard_upper  12
    x[19,13]  OBJ       5.0000000000000010e-02
    x[19,13]  onehot_19  1
    x[19,13]  R984      -3.9145222845663033e-02
    x[19,13]  R985      -0.0680494916724233
    x[19,13]  hard_lower  13
    x[19,13]  hard_upper  13
    x[19,14]  OBJ       0.05
    x[19,14]  onehot_19  1
    x[19,14]  R986      -3.9145222845663033e-02
    x[19,14]  R987      -0.0680494916724233
    x[19,14]  hard_lower  14
    x[19,14]  hard_upper  14
    x[19,15]  OBJ       0.05
    x[19,15]  onehot_19  1
    x[19,15]  R988      -3.9145222845663033e-02
    x[19,15]  R989      -0.0680494916724233
    x[19,15]  hard_lower  15
    x[19,15]  hard_upper  15
    x[19,16]  OBJ       0.05
    x[19,16]  onehot_19  1
    x[19,16]  R990      -3.9145222845663033e-02
    x[19,16]  R991      -0.0680494916724233
    x[19,16]  hard_lower  16
    x[19,16]  hard_upper  16
    x[19,17]  OBJ       0.05
    x[19,17]  onehot_19  1
    x[19,17]  R992      -3.9145222845663033e-02
    x[19,17]  R993      -0.0680494916724233
    x[19,17]  hard_lower  17
    x[19,17]  hard_upper  17
    x[19,18]  OBJ       0.05
    x[19,18]  onehot_19  1
    x[19,18]  R994      -3.9145222845663033e-02
    x[19,18]  R995      -0.0680494916724233
    x[19,18]  hard_lower  18
    x[19,18]  hard_upper  18
    x[19,19]  OBJ       0.05
    x[19,19]  onehot_19  1
    x[19,19]  R996      -3.9145222845663033e-02
    x[19,19]  R997      -0.0680494916724233
    x[19,19]  hard_lower  19
    x[19,19]  hard_upper  19
    x[19,20]  OBJ       -2.5624318471888414e-02
    x[19,20]  onehot_19  1
    x[19,20]  R998      -3.9145222845663033e-02
    x[19,20]  R999      -0.0680494916724233
    x[19,20]  hard_lower  20
    x[19,20]  hard_upper  20
    x[19,21]  OBJ       5.0000000000000010e-02
    x[19,21]  onehot_19  1
    x[19,21]  R1000     -3.9145222845663033e-02
    x[19,21]  R1001     -0.0680494916724233
    x[19,21]  hard_lower  21
    x[19,21]  hard_upper  21
    x[19,22]  OBJ       0.05
    x[19,22]  onehot_19  1
    x[19,22]  R1002     -3.9145222845663033e-02
    x[19,22]  R1003     -0.0680494916724233
    x[19,22]  hard_lower  22
    x[19,22]  hard_upper  22
    x[19,23]  OBJ       0.05
    x[19,23]  onehot_19  1
    x[19,23]  R1004     -3.9145222845663033e-02
    x[19,23]  R1005     -0.0680494916724233
    x[19,23]  hard_lower  23
    x[19,23]  hard_upper  23
    x[20,0]   OBJ       5.0000000000000010e-02
    x[20,0]   onehot_20  1
    x[20,0]   R1010     -3.9145222845663033e-02
    x[20,0]   R1011     -0.0680494916724233
    x[20,1]   OBJ       4.9999999999999996e-02
    x[20,1]   onehot_20  1
    x[20,1]   R1012     -3.9145222845663033e-02
    x[20,1]   R1013     -0.0680494916724233
    x[20,1]   hard_lower  1
    x[20,1]   hard_upper  1
    x[20,2]   OBJ       0.05
    x[20,2]   onehot_20  1
    x[20,2]   R1014     -3.9145222845663033e-02
    x[20,2]   R1015     -0.0680494916724233
    x[20,2]   hard_lower  2
    x[20,2]   hard_upper  2
    x[20,3]   OBJ       4.9999999999999996e-02
    x[20,3]   onehot_20  1
    x[20,3]   R1016     -3.9145222845663033e-02
    x[20,3]   R1017     -0.0680494916724233
    x[20,3]   hard_lower  3
    x[20,3]   hard_upper  3
    x[20,4]   OBJ       0.05
    x[20,4]   onehot_20  1
    x[20,4]   R1018     -3.9145222845663033e-02
    x[20,4]   R1019     -0.0680494916724233
    x[20,4]   hard_lower  4
    x[20,4]   hard_upper  4
    x[20,5]   OBJ       0.05
    x[20,5]   onehot_20  1
    x[20,5]   R1020     -3.9145222845663033e-02
    x[20,5]   R1021     -0.0680494916724233
    x[20,5]   hard_lower  5
    x[20,5]   hard_upper  5
    x[20,6]   OBJ       0.05
    x[20,6]   onehot_20  1
    x[20,6]   R1022     -3.9145222845663033e-02
    x[20,6]   R1023     -0.0680494916724233
    x[20,6]   hard_lower  6
    x[20,6]   hard_upper  6
    x[20,7]   OBJ       0.05
    x[20,7]   onehot_20  1
    x[20,7]   R1024     -3.9145222845663033e-02
    x[20,7]   R1025     -0.0680494916724233
    x[20,7]   hard_lower  7
    x[20,7]   hard_upper  7
    x[20,8]   OBJ       0.05
    x[20,8]   onehot_20  1
    x[20,8]   R1026     -3.9145222845663033e-02
    x[20,8]   R1027     -0.0680494916724233
    x[20,8]   hard_lower  8
    x[20,8]   hard_upper  8
    x[20,9]   OBJ       0.05
    x[20,9]   onehot_20  1
    x[20,9]   R1028     -3.9145222845663033e-02
    x[20,9]   R1029     -0.0680494916724233
    x[20,9]   hard_lower  9
    x[20,9]   hard_upper  9
    x[20,10]  OBJ       0.05
    x[20,10]  onehot_20  1
    x[20,10]  R1030     -3.9145222845663033e-02
    x[20,10]  R1031     -0.0680494916724233
    x[20,10]  hard_lower  10
    x[20,10]  hard_upper  10
    x[20,11]  OBJ       5.0000000000000010e-02
    x[20,11]  onehot_20  1
    x[20,11]  R1032     -3.9145222845663033e-02
    x[20,11]  R1033     -0.0680494916724233
    x[20,11]  hard_lower  11
    x[20,11]  hard_upper  11
    x[20,12]  OBJ       5.0000000000000010e-02
    x[20,12]  onehot_20  1
    x[20,12]  R1034     -3.9145222845663033e-02
    x[20,12]  R1035     -0.0680494916724233
    x[20,12]  hard_lower  12
    x[20,12]  hard_upper  12
    x[20,13]  OBJ       4.86923001918882e-18
    x[20,13]  onehot_20  1
    x[20,13]  R1036     -3.9145222845663033e-02
    x[20,13]  R1037     -0.0680494916724233
    x[20,13]  hard_lower  13
    x[20,13]  hard_upper  13
    x[20,14]  OBJ       0.05
    x[20,14]  onehot_20  1
    x[20,14]  R1038     -3.9145222845663033e-02
    x[20,14]  R1039     -0.0680494916724233
    x[20,14]  hard_lower  14
    x[20,14]  hard_upper  14
    x[20,15]  OBJ       0.05
    x[20,15]  onehot_20  1
    x[20,15]  R1040     -3.9145222845663033e-02
    x[20,15]  R1041     -0.0680494916724233
    x[20,15]  hard_lower  15
    x[20,15]  hard_upper  15
    x[20,16]  OBJ       0.05
    x[20,16]  onehot_20  1
    x[20,16]  R1042     -3.9145222845663033e-02
    x[20,16]  R1043     -0.0680494916724233
    x[20,16]  hard_lower  16
    x[20,16]  hard_upper  16
    x[20,17]  OBJ       0.05
    x[20,17]  onehot_20  1
    x[20,17]  R1044     -3.9145222845663033e-02
    x[20,17]  R1045     -0.0680494916724233
    x[20,17]  hard_lower  17
    x[20,17]  hard_upper  17
    x[20,18]  OBJ       0.05
    x[20,18]  onehot_20  1
    x[20,18]  R1046     -3.9145222845663033e-02
    x[20,18]  R1047     -0.0680494916724233
    x[20,18]  hard_lower  18
    x[20,18]  hard_upper  18
    x[20,19]  OBJ       0.05
    x[20,19]  onehot_20  1
    x[20,19]  R1048     -3.9145222845663033e-02
    x[20,19]  R1049     -0.0680494916724233
    x[20,19]  hard_lower  19
    x[20,19]  hard_upper  19
    x[20,20]  OBJ       0.05
    x[20,20]  onehot_20  1
    x[20,20]  R1050     -3.9145222845663033e-02
    x[20,20]  R1051     -0.0680494916724233
    x[20,20]  hard_lower  20
    x[20,20]  hard_upper  20
    x[20,21]  OBJ       -2.4203837671197739e-02
    x[20,21]  onehot_20  1
    x[20,21]  R1052     -3.9145222845663033e-02
    x[20,21]  R1053     -0.0680494916724233
    x[20,21]  hard_lower  21
    x[20,21]  hard_upper  21
    x[20,22]  OBJ       5.0000000000000010e-02
    x[20,22]  onehot_20  1
    x[20,22]  R1054     -3.9145222845663033e-02
    x[20,22]  R1055     -0.0680494916724233
    x[20,22]  hard_lower  22
    x[20,22]  hard_upper  22
    x[20,23]  OBJ       0.05
    x[20,23]  onehot_20  1
    x[20,23]  R1056     -3.9145222845663033e-02
    x[20,23]  R1057     -0.0680494916724233
    x[20,23]  hard_lower  23
    x[20,23]  hard_upper  23
    MARKER    'MARKER'                 'INTEND'
    w[1,0]    mass_1    1
    w[1,0]    R2        1
    w[1,0]    R3        1
    w[1,1]    mass_1    1
    w[1,1]    R4        1
    w[1,1]    R5        1
    w[1,1]    normalized_inventory_1  -1
    w[1,2]    mass_1    1
    w[1,2]    R6        1
    w[1,2]    R7        1
    w[1,2]    normalized_inventory_1  -2
    w[1,3]    mass_1    1
    w[1,3]    R8        1
    w[1,3]    R9        1
    w[1,3]    normalized_inventory_1  -3
    w[1,4]    mass_1    1
    w[1,4]    R10       1
    w[1,4]    R11       1
    w[1,4]    normalized_inventory_1  -4
    w[1,5]    mass_1    1
    w[1,5]    R12       1
    w[1,5]    R13       1
    w[1,5]    normalized_inventory_1  -5
    w[1,6]    mass_1    1
    w[1,6]    R14       1
    w[1,6]    R15       1
    w[1,6]    normalized_inventory_1  -6
    w[1,7]    mass_1    1
    w[1,7]    R16       1
    w[1,7]    R17       1
    w[1,7]    normalized_inventory_1  -7
    w[1,8]    mass_1    1
    w[1,8]    R18       1
    w[1,8]    R19       1
    w[1,8]    normalized_inventory_1  -8
    w[1,9]    mass_1    1
    w[1,9]    R20       1
    w[1,9]    R21       1
    w[1,9]    normalized_inventory_1  -9
    w[1,10]   mass_1    1
    w[1,10]   R22       1
    w[1,10]   R23       1
    w[1,10]   normalized_inventory_1  -10
    w[1,11]   mass_1    1
    w[1,11]   R24       1
    w[1,11]   R25       1
    w[1,11]   normalized_inventory_1  -11
    w[1,12]   mass_1    1
    w[1,12]   R26       1
    w[1,12]   R27       1
    w[1,12]   normalized_inventory_1  -12
    w[1,13]   mass_1    1
    w[1,13]   R28       1
    w[1,13]   R29       1
    w[1,13]   normalized_inventory_1  -13
    w[1,14]   mass_1    1
    w[1,14]   R30       1
    w[1,14]   R31       1
    w[1,14]   normalized_inventory_1  -14
    w[1,15]   mass_1    1
    w[1,15]   R32       1
    w[1,15]   R33       1
    w[1,15]   normalized_inventory_1  -15
    w[1,16]   mass_1    1
    w[1,16]   R34       1
    w[1,16]   R35       1
    w[1,16]   normalized_inventory_1  -16
    w[1,17]   mass_1    1
    w[1,17]   R36       1
    w[1,17]   R37       1
    w[1,17]   normalized_inventory_1  -17
    w[1,18]   mass_1    1
    w[1,18]   R38       1
    w[1,18]   R39       1
    w[1,18]   normalized_inventory_1  -18
    w[1,19]   mass_1    1
    w[1,19]   R40       1
    w[1,19]   R41       1
    w[1,19]   normalized_inventory_1  -19
    w[1,20]   mass_1    1
    w[1,20]   R42       1
    w[1,20]   R43       1
    w[1,20]   normalized_inventory_1  -20
    w[1,21]   mass_1    1
    w[1,21]   R44       1
    w[1,21]   R45       1
    w[1,21]   normalized_inventory_1  -21
    w[1,22]   mass_1    1
    w[1,22]   R46       1
    w[1,22]   R47       1
    w[1,22]   normalized_inventory_1  -22
    w[1,23]   mass_1    1
    w[1,23]   R48       1
    w[1,23]   R49       1
    w[1,23]   normalized_inventory_1  -23
    w[1,24]   mass_1    1
    w[1,24]   R50       1
    w[1,24]   R51       1
    w[1,24]   normalized_inventory_1  -24
    w[2,0]    mass_2    1
    w[2,0]    R56       1
    w[2,0]    R57       1
    w[2,1]    mass_2    1
    w[2,1]    R58       1
    w[2,1]    R59       1
    w[2,1]    normalized_inventory_2  -1
    w[2,2]    mass_2    1
    w[2,2]    R60       1
    w[2,2]    R61       1
    w[2,2]    normalized_inventory_2  -2
    w[2,3]    mass_2    1
    w[2,3]    R62       1
    w[2,3]    R63       1
    w[2,3]    normalized_inventory_2  -3
    w[2,4]    mass_2    1
    w[2,4]    R64       1
    w[2,4]    R65       1
    w[2,4]    normalized_inventory_2  -4
    w[2,5]    mass_2    1
    w[2,5]    R66       1
    w[2,5]    R67       1
    w[2,5]    normalized_inventory_2  -5
    w[2,6]    mass_2    1
    w[2,6]    R68       1
    w[2,6]    R69       1
    w[2,6]    normalized_inventory_2  -6
    w[2,7]    mass_2    1
    w[2,7]    R70       1
    w[2,7]    R71       1
    w[2,7]    normalized_inventory_2  -7
    w[2,8]    mass_2    1
    w[2,8]    R72       1
    w[2,8]    R73       1
    w[2,8]    normalized_inventory_2  -8
    w[2,9]    mass_2    1
    w[2,9]    R74       1
    w[2,9]    R75       1
    w[2,9]    normalized_inventory_2  -9
    w[2,10]   mass_2    1
    w[2,10]   R76       1
    w[2,10]   R77       1
    w[2,10]   normalized_inventory_2  -10
    w[2,11]   mass_2    1
    w[2,11]   R78       1
    w[2,11]   R79       1
    w[2,11]   normalized_inventory_2  -11
    w[2,12]   mass_2    1
    w[2,12]   R80       1
    w[2,12]   R81       1
    w[2,12]   normalized_inventory_2  -12
    w[2,13]   mass_2    1
    w[2,13]   R82       1
    w[2,13]   R83       1
    w[2,13]   normalized_inventory_2  -13
    w[2,14]   mass_2    1
    w[2,14]   R84       1
    w[2,14]   R85       1
    w[2,14]   normalized_inventory_2  -14
    w[2,15]   mass_2    1
    w[2,15]   R86       1
    w[2,15]   R87       1
    w[2,15]   normalized_inventory_2  -15
    w[2,16]   mass_2    1
    w[2,16]   R88       1
    w[2,16]   R89       1
    w[2,16]   normalized_inventory_2  -16
    w[2,17]   mass_2    1
    w[2,17]   R90       1
    w[2,17]   R91       1
    w[2,17]   normalized_inventory_2  -17
    w[2,18]   mass_2    1
    w[2,18]   R92       1
    w[2,18]   R93       1
    w[2,18]   normalized_inventory_2  -18
    w[2,19]   mass_2    1
    w[2,19]   R94       1
    w[2,19]   R95       1
    w[2,19]   normalized_inventory_2  -19
    w[2,20]   mass_2    1
    w[2,20]   R96       1
    w[2,20]   R97       1
    w[2,20]   normalized_inventory_2  -20
    w[2,21]   mass_2    1
    w[2,21]   R98       1
    w[2,21]   R99       1
    w[2,21]   normalized_inventory_2  -21
    w[2,22]   mass_2    1
    w[2,22]   R100      1
    w[2,22]   R101      1
    w[2,22]   normalized_inventory_2  -22
    w[2,23]   mass_2    1
    w[2,23]   R102      1
    w[2,23]   R103      1
    w[2,23]   normalized_inventory_2  -23
    w[2,24]   mass_2    1
    w[2,24]   R104      1
    w[2,24]   R105      1
    w[2,24]   normalized_inventory_2  -24
    w[2,25]   mass_2    1
    w[2,25]   R106      1
    w[2,25]   R107      1
    w[2,25]   normalized_inventory_2  -25
    w[3,0]    mass_3    1
    w[3,0]    R112      1
    w[3,0]    R113      1
    w[3,1]    mass_3    1
    w[3,1]    R114      1
    w[3,1]    R115      1
    w[3,1]    normalized_inventory_3  -1
    w[3,2]    mass_3    1
    w[3,2]    R116      1
    w[3,2]    R117      1
    w[3,2]    normalized_inventory_3  -2
    w[3,3]    mass_3    1
    w[3,3]    R118      1
    w[3,3]    R119      1
    w[3,3]    normalized_inventory_3  -3
    w[3,4]    mass_3    1
    w[3,4]    R120      1
    w[3,4]    R121      1
    w[3,4]    normalized_inventory_3  -4
    w[3,5]    mass_3    1
    w[3,5]    R122      1
    w[3,5]    R123      1
    w[3,5]    normalized_inventory_3  -5
    w[3,6]    mass_3    1
    w[3,6]    R124      1
    w[3,6]    R125      1
    w[3,6]    normalized_inventory_3  -6
    w[3,7]    mass_3    1
    w[3,7]    R126      1
    w[3,7]    R127      1
    w[3,7]    normalized_inventory_3  -7
    w[3,8]    mass_3    1
    w[3,8]    R128      1
    w[3,8]    R129      1
    w[3,8]    normalized_inventory_3  -8
    w[3,9]    mass_3    1
    w[3,9]    R130      1
    w[3,9]    R131      1
    w[3,9]    normalized_inventory_3  -9
    w[3,10]   mass_3    1
    w[3,10]   R132      1
    w[3,10]   R133      1
    w[3,10]   normalized_inventory_3  -10
    w[3,11]   mass_3    1
    w[3,11]   R134      1
    w[3,11]   R135      1
    w[3,11]   normalized_inventory_3  -11
    w[3,12]   mass_3    1
    w[3,12]   R136      1
    w[3,12]   R137      1
    w[3,12]   normalized_inventory_3  -12
    w[3,13]   mass_3    1
    w[3,13]   R138      1
    w[3,13]   R139      1
    w[3,13]   normalized_inventory_3  -13
    w[3,14]   mass_3    1
    w[3,14]   R140      1
    w[3,14]   R141      1
    w[3,14]   normalized_inventory_3  -14
    w[3,15]   mass_3    1
    w[3,15]   R142      1
    w[3,15]   R143      1
    w[3,15]   normalized_inventory_3  -15
    w[3,16]   mass_3    1
    w[3,16]   R144      1
    w[3,16]   R145      1
    w[3,16]   normalized_inventory_3  -16
    w[3,17]   mass_3    1
    w[3,17]   R146      1
    w[3,17]   R147      1
    w[3,17]   normalized_inventory_3  -17
    w[3,18]   mass_3    1
    w[3,18]   R148      1
    w[3,18]   R149      1
    w[3,18]   normalized_inventory_3  -18
    w[3,19]   mass_3    1
    w[3,19]   R150      1
    w[3,19]   R151      1
    w[3,19]   normalized_inventory_3  -19
    w[3,20]   mass_3    1
    w[3,20]   R152      1
    w[3,20]   R153      1
    w[3,20]   normalized_inventory_3  -20
    w[3,21]   mass_3    1
    w[3,21]   R154      1
    w[3,21]   R155      1
    w[3,21]   normalized_inventory_3  -21
    w[3,22]   mass_3    1
    w[3,22]   R156      1
    w[3,22]   R157      1
    w[3,22]   normalized_inventory_3  -22
    w[3,23]   mass_3    1
    w[3,23]   R158      1
    w[3,23]   R159      1
    w[3,23]   normalized_inventory_3  -23
    w[3,24]   mass_3    1
    w[3,24]   R160      1
    w[3,24]   R161      1
    w[3,24]   normalized_inventory_3  -24
    w[3,25]   mass_3    1
    w[3,25]   R162      1
    w[3,25]   R163      1
    w[3,25]   normalized_inventory_3  -25
    w[3,26]   mass_3    1
    w[3,26]   R164      1
    w[3,26]   R165      1
    w[3,26]   normalized_inventory_3  -26
    w[3,27]   mass_3    1
    w[3,27]   R166      1
    w[3,27]   R167      1
    w[3,27]   normalized_inventory_3  -27
    w[4,0]    mass_4    1
    w[4,0]    R172      1
    w[4,0]    R173      1
    w[4,1]    mass_4    1
    w[4,1]    R174      1
    w[4,1]    R175      1
    w[4,1]    normalized_inventory_4  -1
    w[4,2]    mass_4    1
    w[4,2]    R176      1
    w[4,2]    R177      1
    w[4,2]    normalized_inventory_4  -2
    w[4,3]    mass_4    1
    w[4,3]    R178      1
    w[4,3]    R179      1
    w[4,3]    normalized_inventory_4  -3
    w[4,4]    mass_4    1
    w[4,4]    R180      1
    w[4,4]    R181      1
    w[4,4]    normalized_inventory_4  -4
    w[4,5]    mass_4    1
    w[4,5]    R182      1
    w[4,5]    R183      1
    w[4,5]    normalized_inventory_4  -5
    w[4,6]    mass_4    1
    w[4,6]    R184      1
    w[4,6]    R185      1
    w[4,6]    normalized_inventory_4  -6
    w[4,7]    mass_4    1
    w[4,7]    R186      1
    w[4,7]    R187      1
    w[4,7]    normalized_inventory_4  -7
    w[4,8]    mass_4    1
    w[4,8]    R188      1
    w[4,8]    R189      1
    w[4,8]    normalized_inventory_4  -8
    w[4,9]    mass_4    1
    w[4,9]    R190      1
    w[4,9]    R191      1
    w[4,9]    normalized_inventory_4  -9
    w[4,10]   mass_4    1
    w[4,10]   R192      1
    w[4,10]   R193      1
    w[4,10]   normalized_inventory_4  -10
    w[4,11]   mass_4    1
    w[4,11]   R194      1
    w[4,11]   R195      1
    w[4,11]   normalized_inventory_4  -11
    w[4,12]   mass_4    1
    w[4,12]   R196      1
    w[4,12]   R197      1
    w[4,12]   normalized_inventory_4  -12
    w[4,13]   mass_4    1
    w[4,13]   R198      1
    w[4,13]   R199      1
    w[4,13]   normalized_inventory_4  -13
    w[4,14]   mass_4    1
    w[4,14]   R200      1
    w[4,14]   R201      1
    w[4,14]   normalized_inventory_4  -14
    w[4,15]   mass_4    1
    w[4,15]   R202      1
    w[4,15]   R203      1
    w[4,15]   normalized_inventory_4  -15
    w[4,16]   mass_4    1
    w[4,16]   R204      1
    w[4,16]   R205      1
    w[4,16]   normalized_inventory_4  -16
    w[4,17]   mass_4    1
    w[4,17]   R206      1
    w[4,17]   R207      1
    w[4,17]   normalized_inventory_4  -17
    w[4,18]   mass_4    1
    w[4,18]   R208      1
    w[4,18]   R209      1
    w[4,18]   normalized_inventory_4  -18
    w[4,19]   mass_4    1
    w[4,19]   R210      1
    w[4,19]   R211      1
    w[4,19]   normalized_inventory_4  -19
    w[4,20]   mass_4    1
    w[4,20]   R212      1
    w[4,20]   R213      1
    w[4,20]   normalized_inventory_4  -20
    w[4,21]   mass_4    1
    w[4,21]   R214      1
    w[4,21]   R215      1
    w[4,21]   normalized_inventory_4  -21
    w[4,22]   mass_4    1
    w[4,22]   R216      1
    w[4,22]   R217      1
    w[4,22]   normalized_inventory_4  -22
    w[4,23]   mass_4    1
    w[4,23]   R218      1
    w[4,23]   R219      1
    w[4,23]   normalized_inventory_4  -23
    w[4,24]   mass_4    1
    w[4,24]   R220      1
    w[4,24]   R221      1
    w[4,24]   normalized_inventory_4  -24
    w[5,0]    mass_5    1
    w[5,0]    R226      1
    w[5,0]    R227      1
    w[5,1]    mass_5    1
    w[5,1]    R228      1
    w[5,1]    R229      1
    w[5,1]    normalized_inventory_5  -1
    w[5,2]    mass_5    1
    w[5,2]    R230      1
    w[5,2]    R231      1
    w[5,2]    normalized_inventory_5  -2
    w[5,3]    mass_5    1
    w[5,3]    R232      1
    w[5,3]    R233      1
    w[5,3]    normalized_inventory_5  -3
    w[5,4]    mass_5    1
    w[5,4]    R234      1
    w[5,4]    R235      1
    w[5,4]    normalized_inventory_5  -4
    w[5,5]    mass_5    1
    w[5,5]    R236      1
    w[5,5]    R237      1
    w[5,5]    normalized_inventory_5  -5
    w[5,6]    mass_5    1
    w[5,6]    R238      1
    w[5,6]    R239      1
    w[5,6]    normalized_inventory_5  -6
    w[5,7]    mass_5    1
    w[5,7]    R240      1
    w[5,7]    R241      1
    w[5,7]    normalized_inventory_5  -7
    w[5,8]    mass_5    1
    w[5,8]    R242      1
    w[5,8]    R243      1
    w[5,8]    normalized_inventory_5  -8
    w[5,9]    mass_5    1
    w[5,9]    R244      1
    w[5,9]    R245      1
    w[5,9]    normalized_inventory_5  -9
    w[5,10]   mass_5    1
    w[5,10]   R246      1
    w[5,10]   R247      1
    w[5,10]   normalized_inventory_5  -10
    w[5,11]   mass_5    1
    w[5,11]   R248      1
    w[5,11]   R249      1
    w[5,11]   normalized_inventory_5  -11
    w[5,12]   mass_5    1
    w[5,12]   R250      1
    w[5,12]   R251      1
    w[5,12]   normalized_inventory_5  -12
    w[5,13]   mass_5    1
    w[5,13]   R252      1
    w[5,13]   R253      1
    w[5,13]   normalized_inventory_5  -13
    w[5,14]   mass_5    1
    w[5,14]   R254      1
    w[5,14]   R255      1
    w[5,14]   normalized_inventory_5  -14
    w[5,15]   mass_5    1
    w[5,15]   R256      1
    w[5,15]   R257      1
    w[5,15]   normalized_inventory_5  -15
    w[5,16]   mass_5    1
    w[5,16]   R258      1
    w[5,16]   R259      1
    w[5,16]   normalized_inventory_5  -16
    w[5,17]   mass_5    1
    w[5,17]   R260      1
    w[5,17]   R261      1
    w[5,17]   normalized_inventory_5  -17
    w[5,18]   mass_5    1
    w[5,18]   R262      1
    w[5,18]   R263      1
    w[5,18]   normalized_inventory_5  -18
    w[5,19]   mass_5    1
    w[5,19]   R264      1
    w[5,19]   R265      1
    w[5,19]   normalized_inventory_5  -19
    w[5,20]   mass_5    1
    w[5,20]   R266      1
    w[5,20]   R267      1
    w[5,20]   normalized_inventory_5  -20
    w[5,21]   mass_5    1
    w[5,21]   R268      1
    w[5,21]   R269      1
    w[5,21]   normalized_inventory_5  -21
    w[6,0]    mass_6    1
    w[6,0]    R274      1
    w[6,0]    R275      1
    w[6,1]    mass_6    1
    w[6,1]    R276      1
    w[6,1]    R277      1
    w[6,1]    normalized_inventory_6  -1
    w[6,2]    mass_6    1
    w[6,2]    R278      1
    w[6,2]    R279      1
    w[6,2]    normalized_inventory_6  -2
    w[6,3]    mass_6    1
    w[6,3]    R280      1
    w[6,3]    R281      1
    w[6,3]    normalized_inventory_6  -3
    w[6,4]    mass_6    1
    w[6,4]    R282      1
    w[6,4]    R283      1
    w[6,4]    normalized_inventory_6  -4
    w[6,5]    mass_6    1
    w[6,5]    R284      1
    w[6,5]    R285      1
    w[6,5]    normalized_inventory_6  -5
    w[6,6]    mass_6    1
    w[6,6]    R286      1
    w[6,6]    R287      1
    w[6,6]    normalized_inventory_6  -6
    w[6,7]    mass_6    1
    w[6,7]    R288      1
    w[6,7]    R289      1
    w[6,7]    normalized_inventory_6  -7
    w[6,8]    mass_6    1
    w[6,8]    R290      1
    w[6,8]    R291      1
    w[6,8]    normalized_inventory_6  -8
    w[6,9]    mass_6    1
    w[6,9]    R292      1
    w[6,9]    R293      1
    w[6,9]    normalized_inventory_6  -9
    w[6,10]   mass_6    1
    w[6,10]   R294      1
    w[6,10]   R295      1
    w[6,10]   normalized_inventory_6  -10
    w[6,11]   mass_6    1
    w[6,11]   R296      1
    w[6,11]   R297      1
    w[6,11]   normalized_inventory_6  -11
    w[6,12]   mass_6    1
    w[6,12]   R298      1
    w[6,12]   R299      1
    w[6,12]   normalized_inventory_6  -12
    w[6,13]   mass_6    1
    w[6,13]   R300      1
    w[6,13]   R301      1
    w[6,13]   normalized_inventory_6  -13
    w[6,14]   mass_6    1
    w[6,14]   R302      1
    w[6,14]   R303      1
    w[6,14]   normalized_inventory_6  -14
    w[6,15]   mass_6    1
    w[6,15]   R304      1
    w[6,15]   R305      1
    w[6,15]   normalized_inventory_6  -15
    w[6,16]   mass_6    1
    w[6,16]   R306      1
    w[6,16]   R307      1
    w[6,16]   normalized_inventory_6  -16
    w[6,17]   mass_6    1
    w[6,17]   R308      1
    w[6,17]   R309      1
    w[6,17]   normalized_inventory_6  -17
    w[6,18]   mass_6    1
    w[6,18]   R310      1
    w[6,18]   R311      1
    w[6,18]   normalized_inventory_6  -18
    w[6,19]   mass_6    1
    w[6,19]   R312      1
    w[6,19]   R313      1
    w[6,19]   normalized_inventory_6  -19
    w[6,20]   mass_6    1
    w[6,20]   R314      1
    w[6,20]   R315      1
    w[6,20]   normalized_inventory_6  -20
    w[6,21]   mass_6    1
    w[6,21]   R316      1
    w[6,21]   R317      1
    w[6,21]   normalized_inventory_6  -21
    w[6,22]   mass_6    1
    w[6,22]   R318      1
    w[6,22]   R319      1
    w[6,22]   normalized_inventory_6  -22
    w[6,23]   mass_6    1
    w[6,23]   R320      1
    w[6,23]   R321      1
    w[6,23]   normalized_inventory_6  -23
    w[6,24]   mass_6    1
    w[6,24]   R322      1
    w[6,24]   R323      1
    w[6,24]   normalized_inventory_6  -24
    w[7,0]    mass_7    1
    w[7,0]    R328      1
    w[7,0]    R329      1
    w[7,1]    mass_7    1
    w[7,1]    R330      1
    w[7,1]    R331      1
    w[7,1]    normalized_inventory_7  -1
    w[7,2]    mass_7    1
    w[7,2]    R332      1
    w[7,2]    R333      1
    w[7,2]    normalized_inventory_7  -2
    w[7,3]    mass_7    1
    w[7,3]    R334      1
    w[7,3]    R335      1
    w[7,3]    normalized_inventory_7  -3
    w[7,4]    mass_7    1
    w[7,4]    R336      1
    w[7,4]    R337      1
    w[7,4]    normalized_inventory_7  -4
    w[7,5]    mass_7    1
    w[7,5]    R338      1
    w[7,5]    R339      1
    w[7,5]    normalized_inventory_7  -5
    w[7,6]    mass_7    1
    w[7,6]    R340      1
    w[7,6]    R341      1
    w[7,6]    normalized_inventory_7  -6
    w[7,7]    mass_7    1
    w[7,7]    R342      1
    w[7,7]    R343      1
    w[7,7]    normalized_inventory_7  -7
    w[7,8]    mass_7    1
    w[7,8]    R344      1
    w[7,8]    R345      1
    w[7,8]    normalized_inventory_7  -8
    w[7,9]    mass_7    1
    w[7,9]    R346      1
    w[7,9]    R347      1
    w[7,9]    normalized_inventory_7  -9
    w[7,10]   mass_7    1
    w[7,10]   R348      1
    w[7,10]   R349      1
    w[7,10]   normalized_inventory_7  -10
    w[7,11]   mass_7    1
    w[7,11]   R350      1
    w[7,11]   R351      1
    w[7,11]   normalized_inventory_7  -11
    w[7,12]   mass_7    1
    w[7,12]   R352      1
    w[7,12]   R353      1
    w[7,12]   normalized_inventory_7  -12
    w[7,13]   mass_7    1
    w[7,13]   R354      1
    w[7,13]   R355      1
    w[7,13]   normalized_inventory_7  -13
    w[7,14]   mass_7    1
    w[7,14]   R356      1
    w[7,14]   R357      1
    w[7,14]   normalized_inventory_7  -14
    w[7,15]   mass_7    1
    w[7,15]   R358      1
    w[7,15]   R359      1
    w[7,15]   normalized_inventory_7  -15
    w[7,16]   mass_7    1
    w[7,16]   R360      1
    w[7,16]   R361      1
    w[7,16]   normalized_inventory_7  -16
    w[7,17]   mass_7    1
    w[7,17]   R362      1
    w[7,17]   R363      1
    w[7,17]   normalized_inventory_7  -17
    w[7,18]   mass_7    1
    w[7,18]   R364      1
    w[7,18]   R365      1
    w[7,18]   normalized_inventory_7  -18
    w[7,19]   mass_7    1
    w[7,19]   R366      1
    w[7,19]   R367      1
    w[7,19]   normalized_inventory_7  -19
    w[7,20]   mass_7    1
    w[7,20]   R368      1
    w[7,20]   R369      1
    w[7,20]   normalized_inventory_7  -20
    w[7,21]   mass_7    1
    w[7,21]   R370      1
    w[7,21]   R371      1
    w[7,21]   normalized_inventory_7  -21
    w[7,22]   mass_7    1
    w[7,22]   R372      1
    w[7,22]   R373      1
    w[7,22]   normalized_inventory_7  -22
    w[8,0]    mass_8    1
    w[8,0]    R378      1
    w[8,0]    R379      1
    w[8,1]    mass_8    1
    w[8,1]    R380      1
    w[8,1]    R381      1
    w[8,1]    normalized_inventory_8  -1
    w[8,2]    mass_8    1
    w[8,2]    R382      1
    w[8,2]    R383      1
    w[8,2]    normalized_inventory_8  -2
    w[8,3]    mass_8    1
    w[8,3]    R384      1
    w[8,3]    R385      1
    w[8,3]    normalized_inventory_8  -3
    w[8,4]    mass_8    1
    w[8,4]    R386      1
    w[8,4]    R387      1
    w[8,4]    normalized_inventory_8  -4
    w[8,5]    mass_8    1
    w[8,5]    R388      1
    w[8,5]    R389      1
    w[8,5]    normalized_inventory_8  -5
    w[8,6]    mass_8    1
    w[8,6]    R390      1
    w[8,6]    R391      1
    w[8,6]    normalized_inventory_8  -6
    w[8,7]    mass_8    1
    w[8,7]    R392      1
    w[8,7]    R393      1
    w[8,7]    normalized_inventory_8  -7
    w[8,8]    mass_8    1
    w[8,8]    R394      1
    w[8,8]    R395      1
    w[8,8]    normalized_inventory_8  -8
    w[8,9]    mass_8    1
    w[8,9]    R396      1
    w[8,9]    R397      1
    w[8,9]    normalized_inventory_8  -9
    w[8,10]   mass_8    1
    w[8,10]   R398      1
    w[8,10]   R399      1
    w[8,10]   normalized_inventory_8  -10
    w[8,11]   mass_8    1
    w[8,11]   R400      1
    w[8,11]   R401      1
    w[8,11]   normalized_inventory_8  -11
    w[8,12]   mass_8    1
    w[8,12]   R402      1
    w[8,12]   R403      1
    w[8,12]   normalized_inventory_8  -12
    w[8,13]   mass_8    1
    w[8,13]   R404      1
    w[8,13]   R405      1
    w[8,13]   normalized_inventory_8  -13
    w[8,14]   mass_8    1
    w[8,14]   R406      1
    w[8,14]   R407      1
    w[8,14]   normalized_inventory_8  -14
    w[8,15]   mass_8    1
    w[8,15]   R408      1
    w[8,15]   R409      1
    w[8,15]   normalized_inventory_8  -15
    w[8,16]   mass_8    1
    w[8,16]   R410      1
    w[8,16]   R411      1
    w[8,16]   normalized_inventory_8  -16
    w[8,17]   mass_8    1
    w[8,17]   R412      1
    w[8,17]   R413      1
    w[8,17]   normalized_inventory_8  -17
    w[8,18]   mass_8    1
    w[8,18]   R414      1
    w[8,18]   R415      1
    w[8,18]   normalized_inventory_8  -18
    w[8,19]   mass_8    1
    w[8,19]   R416      1
    w[8,19]   R417      1
    w[8,19]   normalized_inventory_8  -19
    w[8,20]   mass_8    1
    w[8,20]   R418      1
    w[8,20]   R419      1
    w[8,20]   normalized_inventory_8  -20
    w[8,21]   mass_8    1
    w[8,21]   R420      1
    w[8,21]   R421      1
    w[8,21]   normalized_inventory_8  -21
    w[9,0]    mass_9    1
    w[9,0]    R426      1
    w[9,0]    R427      1
    w[9,1]    mass_9    1
    w[9,1]    R428      1
    w[9,1]    R429      1
    w[9,1]    normalized_inventory_9  -1
    w[9,2]    mass_9    1
    w[9,2]    R430      1
    w[9,2]    R431      1
    w[9,2]    normalized_inventory_9  -2
    w[9,3]    mass_9    1
    w[9,3]    R432      1
    w[9,3]    R433      1
    w[9,3]    normalized_inventory_9  -3
    w[9,4]    mass_9    1
    w[9,4]    R434      1
    w[9,4]    R435      1
    w[9,4]    normalized_inventory_9  -4
    w[9,5]    mass_9    1
    w[9,5]    R436      1
    w[9,5]    R437      1
    w[9,5]    normalized_inventory_9  -5
    w[9,6]    mass_9    1
    w[9,6]    R438      1
    w[9,6]    R439      1
    w[9,6]    normalized_inventory_9  -6
    w[9,7]    mass_9    1
    w[9,7]    R440      1
    w[9,7]    R441      1
    w[9,7]    normalized_inventory_9  -7
    w[9,8]    mass_9    1
    w[9,8]    R442      1
    w[9,8]    R443      1
    w[9,8]    normalized_inventory_9  -8
    w[9,9]    mass_9    1
    w[9,9]    R444      1
    w[9,9]    R445      1
    w[9,9]    normalized_inventory_9  -9
    w[9,10]   mass_9    1
    w[9,10]   R446      1
    w[9,10]   R447      1
    w[9,10]   normalized_inventory_9  -10
    w[9,11]   mass_9    1
    w[9,11]   R448      1
    w[9,11]   R449      1
    w[9,11]   normalized_inventory_9  -11
    w[9,12]   mass_9    1
    w[9,12]   R450      1
    w[9,12]   R451      1
    w[9,12]   normalized_inventory_9  -12
    w[9,13]   mass_9    1
    w[9,13]   R452      1
    w[9,13]   R453      1
    w[9,13]   normalized_inventory_9  -13
    w[9,14]   mass_9    1
    w[9,14]   R454      1
    w[9,14]   R455      1
    w[9,14]   normalized_inventory_9  -14
    w[9,15]   mass_9    1
    w[9,15]   R456      1
    w[9,15]   R457      1
    w[9,15]   normalized_inventory_9  -15
    w[9,16]   mass_9    1
    w[9,16]   R458      1
    w[9,16]   R459      1
    w[9,16]   normalized_inventory_9  -16
    w[9,17]   mass_9    1
    w[9,17]   R460      1
    w[9,17]   R461      1
    w[9,17]   normalized_inventory_9  -17
    w[9,18]   mass_9    1
    w[9,18]   R462      1
    w[9,18]   R463      1
    w[9,18]   normalized_inventory_9  -18
    w[9,19]   mass_9    1
    w[9,19]   R464      1
    w[9,19]   R465      1
    w[9,19]   normalized_inventory_9  -19
    w[10,0]   mass_10   1
    w[10,0]   R470      1
    w[10,0]   R471      1
    w[10,1]   mass_10   1
    w[10,1]   R472      1
    w[10,1]   R473      1
    w[10,1]   normalized_inventory_10  -1
    w[10,2]   mass_10   1
    w[10,2]   R474      1
    w[10,2]   R475      1
    w[10,2]   normalized_inventory_10  -2
    w[10,3]   mass_10   1
    w[10,3]   R476      1
    w[10,3]   R477      1
    w[10,3]   normalized_inventory_10  -3
    w[10,4]   mass_10   1
    w[10,4]   R478      1
    w[10,4]   R479      1
    w[10,4]   normalized_inventory_10  -4
    w[10,5]   mass_10   1
    w[10,5]   R480      1
    w[10,5]   R481      1
    w[10,5]   normalized_inventory_10  -5
    w[10,6]   mass_10   1
    w[10,6]   R482      1
    w[10,6]   R483      1
    w[10,6]   normalized_inventory_10  -6
    w[10,7]   mass_10   1
    w[10,7]   R484      1
    w[10,7]   R485      1
    w[10,7]   normalized_inventory_10  -7
    w[10,8]   mass_10   1
    w[10,8]   R486      1
    w[10,8]   R487      1
    w[10,8]   normalized_inventory_10  -8
    w[10,9]   mass_10   1
    w[10,9]   R488      1
    w[10,9]   R489      1
    w[10,9]   normalized_inventory_10  -9
    w[10,10]  mass_10   1
    w[10,10]  R490      1
    w[10,10]  R491      1
    w[10,10]  normalized_inventory_10  -10
    w[10,11]  mass_10   1
    w[10,11]  R492      1
    w[10,11]  R493      1
    w[10,11]  normalized_inventory_10  -11
    w[10,12]  mass_10   1
    w[10,12]  R494      1
    w[10,12]  R495      1
    w[10,12]  normalized_inventory_10  -12
    w[10,13]  mass_10   1
    w[10,13]  R496      1
    w[10,13]  R497      1
    w[10,13]  normalized_inventory_10  -13
    w[10,14]  mass_10   1
    w[10,14]  R498      1
    w[10,14]  R499      1
    w[10,14]  normalized_inventory_10  -14
    w[10,15]  mass_10   1
    w[10,15]  R500      1
    w[10,15]  R501      1
    w[10,15]  normalized_inventory_10  -15
    w[10,16]  mass_10   1
    w[10,16]  R502      1
    w[10,16]  R503      1
    w[10,16]  normalized_inventory_10  -16
    w[10,17]  mass_10   1
    w[10,17]  R504      1
    w[10,17]  R505      1
    w[10,17]  normalized_inventory_10  -17
    w[10,18]  mass_10   1
    w[10,18]  R506      1
    w[10,18]  R507      1
    w[10,18]  normalized_inventory_10  -18
    w[10,19]  mass_10   1
    w[10,19]  R508      1
    w[10,19]  R509      1
    w[10,19]  normalized_inventory_10  -19
    w[10,20]  mass_10   1
    w[10,20]  R510      1
    w[10,20]  R511      1
    w[10,20]  normalized_inventory_10  -20
    w[10,21]  mass_10   1
    w[10,21]  R512      1
    w[10,21]  R513      1
    w[10,21]  normalized_inventory_10  -21
    w[10,22]  mass_10   1
    w[10,22]  R514      1
    w[10,22]  R515      1
    w[10,22]  normalized_inventory_10  -22
    w[10,23]  mass_10   1
    w[10,23]  R516      1
    w[10,23]  R517      1
    w[10,23]  normalized_inventory_10  -23
    w[10,24]  mass_10   1
    w[10,24]  R518      1
    w[10,24]  R519      1
    w[10,24]  normalized_inventory_10  -24
    w[10,25]  mass_10   1
    w[10,25]  R520      1
    w[10,25]  R521      1
    w[10,25]  normalized_inventory_10  -25
    w[10,26]  mass_10   1
    w[10,26]  R522      1
    w[10,26]  R523      1
    w[10,26]  normalized_inventory_10  -26
    w[10,27]  mass_10   1
    w[10,27]  R524      1
    w[10,27]  R525      1
    w[10,27]  normalized_inventory_10  -27
    w[10,28]  mass_10   1
    w[10,28]  R526      1
    w[10,28]  R527      1
    w[10,28]  normalized_inventory_10  -28
    w[10,29]  mass_10   1
    w[10,29]  R528      1
    w[10,29]  R529      1
    w[10,29]  normalized_inventory_10  -29
    w[11,0]   mass_11   1
    w[11,0]   R534      1
    w[11,0]   R535      1
    w[11,1]   mass_11   1
    w[11,1]   R536      1
    w[11,1]   R537      1
    w[11,1]   normalized_inventory_11  -1
    w[11,2]   mass_11   1
    w[11,2]   R538      1
    w[11,2]   R539      1
    w[11,2]   normalized_inventory_11  -2
    w[11,3]   mass_11   1
    w[11,3]   R540      1
    w[11,3]   R541      1
    w[11,3]   normalized_inventory_11  -3
    w[11,4]   mass_11   1
    w[11,4]   R542      1
    w[11,4]   R543      1
    w[11,4]   normalized_inventory_11  -4
    w[11,5]   mass_11   1
    w[11,5]   R544      1
    w[11,5]   R545      1
    w[11,5]   normalized_inventory_11  -5
    w[11,6]   mass_11   1
    w[11,6]   R546      1
    w[11,6]   R547      1
    w[11,6]   normalized_inventory_11  -6
    w[11,7]   mass_11   1
    w[11,7]   R548      1
    w[11,7]   R549      1
    w[11,7]   normalized_inventory_11  -7
    w[11,8]   mass_11   1
    w[11,8]   R550      1
    w[11,8]   R551      1
    w[11,8]   normalized_inventory_11  -8
    w[11,9]   mass_11   1
    w[11,9]   R552      1
    w[11,9]   R553      1
    w[11,9]   normalized_inventory_11  -9
    w[11,10]  mass_11   1
    w[11,10]  R554      1
    w[11,10]  R555      1
    w[11,10]  normalized_inventory_11  -10
    w[11,11]  mass_11   1
    w[11,11]  R556      1
    w[11,11]  R557      1
    w[11,11]  normalized_inventory_11  -11
    w[11,12]  mass_11   1
    w[11,12]  R558      1
    w[11,12]  R559      1
    w[11,12]  normalized_inventory_11  -12
    w[11,13]  mass_11   1
    w[11,13]  R560      1
    w[11,13]  R561      1
    w[11,13]  normalized_inventory_11  -13
    w[11,14]  mass_11   1
    w[11,14]  R562      1
    w[11,14]  R563      1
    w[11,14]  normalized_inventory_11  -14
    w[11,15]  mass_11   1
    w[11,15]  R564      1
    w[11,15]  R565      1
    w[11,15]  normalized_inventory_11  -15
    w[11,16]  mass_11   1
    w[11,16]  R566      1
    w[11,16]  R567      1
    w[11,16]  normalized_inventory_11  -16
    w[11,17]  mass_11   1
    w[11,17]  R568      1
    w[11,17]  R569      1
    w[11,17]  normalized_inventory_11  -17
    w[11,18]  mass_11   1
    w[11,18]  R570      1
    w[11,18]  R571      1
    w[11,18]  normalized_inventory_11  -18
    w[11,19]  mass_11   1
    w[11,19]  R572      1
    w[11,19]  R573      1
    w[11,19]  normalized_inventory_11  -19
    w[11,20]  mass_11   1
    w[11,20]  R574      1
    w[11,20]  R575      1
    w[11,20]  normalized_inventory_11  -20
    w[11,21]  mass_11   1
    w[11,21]  R576      1
    w[11,21]  R577      1
    w[11,21]  normalized_inventory_11  -21
    w[11,22]  mass_11   1
    w[11,22]  R578      1
    w[11,22]  R579      1
    w[11,22]  normalized_inventory_11  -22
    w[11,23]  mass_11   1
    w[11,23]  R580      1
    w[11,23]  R581      1
    w[11,23]  normalized_inventory_11  -23
    w[11,24]  mass_11   1
    w[11,24]  R582      1
    w[11,24]  R583      1
    w[11,24]  normalized_inventory_11  -24
    w[11,25]  mass_11   1
    w[11,25]  R584      1
    w[11,25]  R585      1
    w[11,25]  normalized_inventory_11  -25
    w[11,26]  mass_11   1
    w[11,26]  R586      1
    w[11,26]  R587      1
    w[11,26]  normalized_inventory_11  -26
    w[11,27]  mass_11   1
    w[11,27]  R588      1
    w[11,27]  R589      1
    w[11,27]  normalized_inventory_11  -27
    w[11,28]  mass_11   1
    w[11,28]  R590      1
    w[11,28]  R591      1
    w[11,28]  normalized_inventory_11  -28
    w[11,29]  mass_11   1
    w[11,29]  R592      1
    w[11,29]  R593      1
    w[11,29]  normalized_inventory_11  -29
    w[11,30]  mass_11   1
    w[11,30]  R594      1
    w[11,30]  R595      1
    w[11,30]  normalized_inventory_11  -30
    w[11,31]  mass_11   1
    w[11,31]  R596      1
    w[11,31]  R597      1
    w[11,31]  normalized_inventory_11  -31
    w[12,0]   mass_12   1
    w[12,0]   R602      1
    w[12,0]   R603      1
    w[12,1]   mass_12   1
    w[12,1]   R604      1
    w[12,1]   R605      1
    w[12,1]   normalized_inventory_12  -1
    w[12,2]   mass_12   1
    w[12,2]   R606      1
    w[12,2]   R607      1
    w[12,2]   normalized_inventory_12  -2
    w[12,3]   mass_12   1
    w[12,3]   R608      1
    w[12,3]   R609      1
    w[12,3]   normalized_inventory_12  -3
    w[12,4]   mass_12   1
    w[12,4]   R610      1
    w[12,4]   R611      1
    w[12,4]   normalized_inventory_12  -4
    w[12,5]   mass_12   1
    w[12,5]   R612      1
    w[12,5]   R613      1
    w[12,5]   normalized_inventory_12  -5
    w[12,6]   mass_12   1
    w[12,6]   R614      1
    w[12,6]   R615      1
    w[12,6]   normalized_inventory_12  -6
    w[12,7]   mass_12   1
    w[12,7]   R616      1
    w[12,7]   R617      1
    w[12,7]   normalized_inventory_12  -7
    w[12,8]   mass_12   1
    w[12,8]   R618      1
    w[12,8]   R619      1
    w[12,8]   normalized_inventory_12  -8
    w[12,9]   mass_12   1
    w[12,9]   R620      1
    w[12,9]   R621      1
    w[12,9]   normalized_inventory_12  -9
    w[12,10]  mass_12   1
    w[12,10]  R622      1
    w[12,10]  R623      1
    w[12,10]  normalized_inventory_12  -10
    w[12,11]  mass_12   1
    w[12,11]  R624      1
    w[12,11]  R625      1
    w[12,11]  normalized_inventory_12  -11
    w[12,12]  mass_12   1
    w[12,12]  R626      1
    w[12,12]  R627      1
    w[12,12]  normalized_inventory_12  -12
    w[12,13]  mass_12   1
    w[12,13]  R628      1
    w[12,13]  R629      1
    w[12,13]  normalized_inventory_12  -13
    w[12,14]  mass_12   1
    w[12,14]  R630      1
    w[12,14]  R631      1
    w[12,14]  normalized_inventory_12  -14
    w[12,15]  mass_12   1
    w[12,15]  R632      1
    w[12,15]  R633      1
    w[12,15]  normalized_inventory_12  -15
    w[12,16]  mass_12   1
    w[12,16]  R634      1
    w[12,16]  R635      1
    w[12,16]  normalized_inventory_12  -16
    w[12,17]  mass_12   1
    w[12,17]  R636      1
    w[12,17]  R637      1
    w[12,17]  normalized_inventory_12  -17
    w[12,18]  mass_12   1
    w[12,18]  R638      1
    w[12,18]  R639      1
    w[12,18]  normalized_inventory_12  -18
    w[12,19]  mass_12   1
    w[12,19]  R640      1
    w[12,19]  R641      1
    w[12,19]  normalized_inventory_12  -19
    w[13,0]   mass_13   1
    w[13,0]   R646      1
    w[13,0]   R647      1
    w[13,1]   mass_13   1
    w[13,1]   R648      1
    w[13,1]   R649      1
    w[13,1]   normalized_inventory_13  -1
    w[13,2]   mass_13   1
    w[13,2]   R650      1
    w[13,2]   R651      1
    w[13,2]   normalized_inventory_13  -2
    w[13,3]   mass_13   1
    w[13,3]   R652      1
    w[13,3]   R653      1
    w[13,3]   normalized_inventory_13  -3
    w[13,4]   mass_13   1
    w[13,4]   R654      1
    w[13,4]   R655      1
    w[13,4]   normalized_inventory_13  -4
    w[13,5]   mass_13   1
    w[13,5]   R656      1
    w[13,5]   R657      1
    w[13,5]   normalized_inventory_13  -5
    w[13,6]   mass_13   1
    w[13,6]   R658      1
    w[13,6]   R659      1
    w[13,6]   normalized_inventory_13  -6
    w[13,7]   mass_13   1
    w[13,7]   R660      1
    w[13,7]   R661      1
    w[13,7]   normalized_inventory_13  -7
    w[13,8]   mass_13   1
    w[13,8]   R662      1
    w[13,8]   R663      1
    w[13,8]   normalized_inventory_13  -8
    w[13,9]   mass_13   1
    w[13,9]   R664      1
    w[13,9]   R665      1
    w[13,9]   normalized_inventory_13  -9
    w[13,10]  mass_13   1
    w[13,10]  R666      1
    w[13,10]  R667      1
    w[13,10]  normalized_inventory_13  -10
    w[13,11]  mass_13   1
    w[13,11]  R668      1
    w[13,11]  R669      1
    w[13,11]  normalized_inventory_13  -11
    w[13,12]  mass_13   1
    w[13,12]  R670      1
    w[13,12]  R671      1
    w[13,12]  normalized_inventory_13  -12
    w[13,13]  mass_13   1
    w[13,13]  R672      1
    w[13,13]  R673      1
    w[13,13]  normalized_inventory_13  -13
    w[13,14]  mass_13   1
    w[13,14]  R674      1
    w[13,14]  R675      1
    w[13,14]  normalized_inventory_13  -14
    w[13,15]  mass_13   1
    w[13,15]  R676      1
    w[13,15]  R677      1
    w[13,15]  normalized_inventory_13  -15
    w[13,16]  mass_13   1
    w[13,16]  R678      1
    w[13,16]  R679      1
    w[13,16]  normalized_inventory_13  -16
    w[13,17]  mass_13   1
    w[13,17]  R680      1
    w[13,17]  R681      1
    w[13,17]  normalized_inventory_13  -17
    w[13,18]  mass_13   1
    w[13,18]  R682      1
    w[13,18]  R683      1
    w[13,18]  normalized_inventory_13  -18
    w[13,19]  mass_13   1
    w[13,19]  R684      1
    w[13,19]  R685      1
    w[13,19]  normalized_inventory_13  -19
    w[13,20]  mass_13   1
    w[13,20]  R686      1
    w[13,20]  R687      1
    w[13,20]  normalized_inventory_13  -20
    w[13,21]  mass_13   1
    w[13,21]  R688      1
    w[13,21]  R689      1
    w[13,21]  normalized_inventory_13  -21
    w[13,22]  mass_13   1
    w[13,22]  R690      1
    w[13,22]  R691      1
    w[13,22]  normalized_inventory_13  -22
    w[13,23]  mass_13   1
    w[13,23]  R692      1
    w[13,23]  R693      1
    w[13,23]  normalized_inventory_13  -23
    w[13,24]  mass_13   1
    w[13,24]  R694      1
    w[13,24]  R695      1
    w[13,24]  normalized_inventory_13  -24
    w[13,25]  mass_13   1
    w[13,25]  R696      1
    w[13,25]  R697      1
    w[13,25]  normalized_inventory_13  -25
    w[14,0]   mass_14   1
    w[14,0]   R702      1
    w[14,0]   R703      1
    w[14,1]   mass_14   1
    w[14,1]   R704      1
    w[14,1]   R705      1
    w[14,1]   normalized_inventory_14  -1
    w[14,2]   mass_14   1
    w[14,2]   R706      1
    w[14,2]   R707      1
    w[14,2]   normalized_inventory_14  -2
    w[14,3]   mass_14   1
    w[14,3]   R708      1
    w[14,3]   R709      1
    w[14,3]   normalized_inventory_14  -3
    w[14,4]   mass_14   1
    w[14,4]   R710      1
    w[14,4]   R711      1
    w[14,4]   normalized_inventory_14  -4
    w[14,5]   mass_14   1
    w[14,5]   R712      1
    w[14,5]   R713      1
    w[14,5]   normalized_inventory_14  -5
    w[14,6]   mass_14   1
    w[14,6]   R714      1
    w[14,6]   R715      1
    w[14,6]   normalized_inventory_14  -6
    w[14,7]   mass_14   1
    w[14,7]   R716      1
    w[14,7]   R717      1
    w[14,7]   normalized_inventory_14  -7
    w[14,8]   mass_14   1
    w[14,8]   R718      1
    w[14,8]   R719      1
    w[14,8]   normalized_inventory_14  -8
    w[14,9]   mass_14   1
    w[14,9]   R720      1
    w[14,9]   R721      1
    w[14,9]   normalized_inventory_14  -9
    w[14,10]  mass_14   1
    w[14,10]  R722      1
    w[14,10]  R723      1
    w[14,10]  normalized_inventory_14  -10
    w[14,11]  mass_14   1
    w[14,11]  R724      1
    w[14,11]  R725      1
    w[14,11]  normalized_inventory_14  -11
    w[14,12]  mass_14   1
    w[14,12]  R726      1
    w[14,12]  R727      1
    w[14,12]  normalized_inventory_14  -12
    w[14,13]  mass_14   1
    w[14,13]  R728      1
    w[14,13]  R729      1
    w[14,13]  normalized_inventory_14  -13
    w[14,14]  mass_14   1
    w[14,14]  R730      1
    w[14,14]  R731      1
    w[14,14]  normalized_inventory_14  -14
    w[14,15]  mass_14   1
    w[14,15]  R732      1
    w[14,15]  R733      1
    w[14,15]  normalized_inventory_14  -15
    w[14,16]  mass_14   1
    w[14,16]  R734      1
    w[14,16]  R735      1
    w[14,16]  normalized_inventory_14  -16
    w[14,17]  mass_14   1
    w[14,17]  R736      1
    w[14,17]  R737      1
    w[14,17]  normalized_inventory_14  -17
    w[14,18]  mass_14   1
    w[14,18]  R738      1
    w[14,18]  R739      1
    w[14,18]  normalized_inventory_14  -18
    w[14,19]  mass_14   1
    w[14,19]  R740      1
    w[14,19]  R741      1
    w[14,19]  normalized_inventory_14  -19
    w[14,20]  mass_14   1
    w[14,20]  R742      1
    w[14,20]  R743      1
    w[14,20]  normalized_inventory_14  -20
    w[14,21]  mass_14   1
    w[14,21]  R744      1
    w[14,21]  R745      1
    w[14,21]  normalized_inventory_14  -21
    w[14,22]  mass_14   1
    w[14,22]  R746      1
    w[14,22]  R747      1
    w[14,22]  normalized_inventory_14  -22
    w[14,23]  mass_14   1
    w[14,23]  R748      1
    w[14,23]  R749      1
    w[14,23]  normalized_inventory_14  -23
    w[15,0]   mass_15   1
    w[15,0]   R754      1
    w[15,0]   R755      1
    w[15,1]   mass_15   1
    w[15,1]   R756      1
    w[15,1]   R757      1
    w[15,1]   normalized_inventory_15  -1
    w[15,2]   mass_15   1
    w[15,2]   R758      1
    w[15,2]   R759      1
    w[15,2]   normalized_inventory_15  -2
    w[15,3]   mass_15   1
    w[15,3]   R760      1
    w[15,3]   R761      1
    w[15,3]   normalized_inventory_15  -3
    w[15,4]   mass_15   1
    w[15,4]   R762      1
    w[15,4]   R763      1
    w[15,4]   normalized_inventory_15  -4
    w[15,5]   mass_15   1
    w[15,5]   R764      1
    w[15,5]   R765      1
    w[15,5]   normalized_inventory_15  -5
    w[15,6]   mass_15   1
    w[15,6]   R766      1
    w[15,6]   R767      1
    w[15,6]   normalized_inventory_15  -6
    w[15,7]   mass_15   1
    w[15,7]   R768      1
    w[15,7]   R769      1
    w[15,7]   normalized_inventory_15  -7
    w[15,8]   mass_15   1
    w[15,8]   R770      1
    w[15,8]   R771      1
    w[15,8]   normalized_inventory_15  -8
    w[15,9]   mass_15   1
    w[15,9]   R772      1
    w[15,9]   R773      1
    w[15,9]   normalized_inventory_15  -9
    w[15,10]  mass_15   1
    w[15,10]  R774      1
    w[15,10]  R775      1
    w[15,10]  normalized_inventory_15  -10
    w[15,11]  mass_15   1
    w[15,11]  R776      1
    w[15,11]  R777      1
    w[15,11]  normalized_inventory_15  -11
    w[15,12]  mass_15   1
    w[15,12]  R778      1
    w[15,12]  R779      1
    w[15,12]  normalized_inventory_15  -12
    w[15,13]  mass_15   1
    w[15,13]  R780      1
    w[15,13]  R781      1
    w[15,13]  normalized_inventory_15  -13
    w[15,14]  mass_15   1
    w[15,14]  R782      1
    w[15,14]  R783      1
    w[15,14]  normalized_inventory_15  -14
    w[15,15]  mass_15   1
    w[15,15]  R784      1
    w[15,15]  R785      1
    w[15,15]  normalized_inventory_15  -15
    w[15,16]  mass_15   1
    w[15,16]  R786      1
    w[15,16]  R787      1
    w[15,16]  normalized_inventory_15  -16
    w[15,17]  mass_15   1
    w[15,17]  R788      1
    w[15,17]  R789      1
    w[15,17]  normalized_inventory_15  -17
    w[15,18]  mass_15   1
    w[15,18]  R790      1
    w[15,18]  R791      1
    w[15,18]  normalized_inventory_15  -18
    w[15,19]  mass_15   1
    w[15,19]  R792      1
    w[15,19]  R793      1
    w[15,19]  normalized_inventory_15  -19
    w[15,20]  mass_15   1
    w[15,20]  R794      1
    w[15,20]  R795      1
    w[15,20]  normalized_inventory_15  -20
    w[15,21]  mass_15   1
    w[15,21]  R796      1
    w[15,21]  R797      1
    w[15,21]  normalized_inventory_15  -21
    w[15,22]  mass_15   1
    w[15,22]  R798      1
    w[15,22]  R799      1
    w[15,22]  normalized_inventory_15  -22
    w[15,23]  mass_15   1
    w[15,23]  R800      1
    w[15,23]  R801      1
    w[15,23]  normalized_inventory_15  -23
    w[15,24]  mass_15   1
    w[15,24]  R802      1
    w[15,24]  R803      1
    w[15,24]  normalized_inventory_15  -24
    w[15,25]  mass_15   1
    w[15,25]  R804      1
    w[15,25]  R805      1
    w[15,25]  normalized_inventory_15  -25
    w[15,26]  mass_15   1
    w[15,26]  R806      1
    w[15,26]  R807      1
    w[15,26]  normalized_inventory_15  -26
    w[15,27]  mass_15   1
    w[15,27]  R808      1
    w[15,27]  R809      1
    w[15,27]  normalized_inventory_15  -27
    w[16,0]   mass_16   1
    w[16,0]   R814      1
    w[16,0]   R815      1
    w[16,1]   mass_16   1
    w[16,1]   R816      1
    w[16,1]   R817      1
    w[16,1]   normalized_inventory_16  -1
    w[16,2]   mass_16   1
    w[16,2]   R818      1
    w[16,2]   R819      1
    w[16,2]   normalized_inventory_16  -2
    w[16,3]   mass_16   1
    w[16,3]   R820      1
    w[16,3]   R821      1
    w[16,3]   normalized_inventory_16  -3
    w[16,4]   mass_16   1
    w[16,4]   R822      1
    w[16,4]   R823      1
    w[16,4]   normalized_inventory_16  -4
    w[16,5]   mass_16   1
    w[16,5]   R824      1
    w[16,5]   R825      1
    w[16,5]   normalized_inventory_16  -5
    w[16,6]   mass_16   1
    w[16,6]   R826      1
    w[16,6]   R827      1
    w[16,6]   normalized_inventory_16  -6
    w[16,7]   mass_16   1
    w[16,7]   R828      1
    w[16,7]   R829      1
    w[16,7]   normalized_inventory_16  -7
    w[16,8]   mass_16   1
    w[16,8]   R830      1
    w[16,8]   R831      1
    w[16,8]   normalized_inventory_16  -8
    w[16,9]   mass_16   1
    w[16,9]   R832      1
    w[16,9]   R833      1
    w[16,9]   normalized_inventory_16  -9
    w[16,10]  mass_16   1
    w[16,10]  R834      1
    w[16,10]  R835      1
    w[16,10]  normalized_inventory_16  -10
    w[16,11]  mass_16   1
    w[16,11]  R836      1
    w[16,11]  R837      1
    w[16,11]  normalized_inventory_16  -11
    w[16,12]  mass_16   1
    w[16,12]  R838      1
    w[16,12]  R839      1
    w[16,12]  normalized_inventory_16  -12
    w[16,13]  mass_16   1
    w[16,13]  R840      1
    w[16,13]  R841      1
    w[16,13]  normalized_inventory_16  -13
    w[16,14]  mass_16   1
    w[16,14]  R842      1
    w[16,14]  R843      1
    w[16,14]  normalized_inventory_16  -14
    w[16,15]  mass_16   1
    w[16,15]  R844      1
    w[16,15]  R845      1
    w[16,15]  normalized_inventory_16  -15
    w[16,16]  mass_16   1
    w[16,16]  R846      1
    w[16,16]  R847      1
    w[16,16]  normalized_inventory_16  -16
    w[16,17]  mass_16   1
    w[16,17]  R848      1
    w[16,17]  R849      1
    w[16,17]  normalized_inventory_16  -17
    w[16,18]  mass_16   1
    w[16,18]  R850      1
    w[16,18]  R851      1
    w[16,18]  normalized_inventory_16  -18
    w[16,19]  mass_16   1
    w[16,19]  R852      1
    w[16,19]  R853      1
    w[16,19]  normalized_inventory_16  -19
    w[16,20]  mass_16   1
    w[16,20]  R854      1
    w[16,20]  R855      1
    w[16,20]  normalized_inventory_16  -20
    w[16,21]  mass_16   1
    w[16,21]  R856      1
    w[16,21]  R857      1
    w[16,21]  normalized_inventory_16  -21
    w[16,22]  mass_16   1
    w[16,22]  R858      1
    w[16,22]  R859      1
    w[16,22]  normalized_inventory_16  -22
    w[17,0]   mass_17   1
    w[17,0]   R864      1
    w[17,0]   R865      1
    w[17,1]   mass_17   1
    w[17,1]   R866      1
    w[17,1]   R867      1
    w[17,1]   normalized_inventory_17  -1
    w[17,2]   mass_17   1
    w[17,2]   R868      1
    w[17,2]   R869      1
    w[17,2]   normalized_inventory_17  -2
    w[17,3]   mass_17   1
    w[17,3]   R870      1
    w[17,3]   R871      1
    w[17,3]   normalized_inventory_17  -3
    w[17,4]   mass_17   1
    w[17,4]   R872      1
    w[17,4]   R873      1
    w[17,4]   normalized_inventory_17  -4
    w[17,5]   mass_17   1
    w[17,5]   R874      1
    w[17,5]   R875      1
    w[17,5]   normalized_inventory_17  -5
    w[17,6]   mass_17   1
    w[17,6]   R876      1
    w[17,6]   R877      1
    w[17,6]   normalized_inventory_17  -6
    w[17,7]   mass_17   1
    w[17,7]   R878      1
    w[17,7]   R879      1
    w[17,7]   normalized_inventory_17  -7
    w[17,8]   mass_17   1
    w[17,8]   R880      1
    w[17,8]   R881      1
    w[17,8]   normalized_inventory_17  -8
    w[17,9]   mass_17   1
    w[17,9]   R882      1
    w[17,9]   R883      1
    w[17,9]   normalized_inventory_17  -9
    w[17,10]  mass_17   1
    w[17,10]  R884      1
    w[17,10]  R885      1
    w[17,10]  normalized_inventory_17  -10
    w[17,11]  mass_17   1
    w[17,11]  R886      1
    w[17,11]  R887      1
    w[17,11]  normalized_inventory_17  -11
    w[17,12]  mass_17   1
    w[17,12]  R888      1
    w[17,12]  R889      1
    w[17,12]  normalized_inventory_17  -12
    w[17,13]  mass_17   1
    w[17,13]  R890      1
    w[17,13]  R891      1
    w[17,13]  normalized_inventory_17  -13
    w[17,14]  mass_17   1
    w[17,14]  R892      1
    w[17,14]  R893      1
    w[17,14]  normalized_inventory_17  -14
    w[17,15]  mass_17   1
    w[17,15]  R894      1
    w[17,15]  R895      1
    w[17,15]  normalized_inventory_17  -15
    w[17,16]  mass_17   1
    w[17,16]  R896      1
    w[17,16]  R897      1
    w[17,16]  normalized_inventory_17  -16
    w[17,17]  mass_17   1
    w[17,17]  R898      1
    w[17,17]  R899      1
    w[17,17]  normalized_inventory_17  -17
    w[17,18]  mass_17   1
    w[17,18]  R900      1
    w[17,18]  R901      1
    w[17,18]  normalized_inventory_17  -18
    w[17,19]  mass_17   1
    w[17,19]  R902      1
    w[17,19]  R903      1
    w[17,19]  normalized_inventory_17  -19
    w[18,0]   mass_18   1
    w[18,0]   R908      1
    w[18,0]   R909      1
    w[18,1]   mass_18   1
    w[18,1]   R910      1
    w[18,1]   R911      1
    w[18,1]   normalized_inventory_18  -1
    w[18,2]   mass_18   1
    w[18,2]   R912      1
    w[18,2]   R913      1
    w[18,2]   normalized_inventory_18  -2
    w[18,3]   mass_18   1
    w[18,3]   R914      1
    w[18,3]   R915      1
    w[18,3]   normalized_inventory_18  -3
    w[18,4]   mass_18   1
    w[18,4]   R916      1
    w[18,4]   R917      1
    w[18,4]   normalized_inventory_18  -4
    w[18,5]   mass_18   1
    w[18,5]   R918      1
    w[18,5]   R919      1
    w[18,5]   normalized_inventory_18  -5
    w[18,6]   mass_18   1
    w[18,6]   R920      1
    w[18,6]   R921      1
    w[18,6]   normalized_inventory_18  -6
    w[18,7]   mass_18   1
    w[18,7]   R922      1
    w[18,7]   R923      1
    w[18,7]   normalized_inventory_18  -7
    w[18,8]   mass_18   1
    w[18,8]   R924      1
    w[18,8]   R925      1
    w[18,8]   normalized_inventory_18  -8
    w[18,9]   mass_18   1
    w[18,9]   R926      1
    w[18,9]   R927      1
    w[18,9]   normalized_inventory_18  -9
    w[18,10]  mass_18   1
    w[18,10]  R928      1
    w[18,10]  R929      1
    w[18,10]  normalized_inventory_18  -10
    w[18,11]  mass_18   1
    w[18,11]  R930      1
    w[18,11]  R931      1
    w[18,11]  normalized_inventory_18  -11
    w[18,12]  mass_18   1
    w[18,12]  R932      1
    w[18,12]  R933      1
    w[18,12]  normalized_inventory_18  -12
    w[18,13]  mass_18   1
    w[18,13]  R934      1
    w[18,13]  R935      1
    w[18,13]  normalized_inventory_18  -13
    w[18,14]  mass_18   1
    w[18,14]  R936      1
    w[18,14]  R937      1
    w[18,14]  normalized_inventory_18  -14
    w[18,15]  mass_18   1
    w[18,15]  R938      1
    w[18,15]  R939      1
    w[18,15]  normalized_inventory_18  -15
    w[18,16]  mass_18   1
    w[18,16]  R940      1
    w[18,16]  R941      1
    w[18,16]  normalized_inventory_18  -16
    w[18,17]  mass_18   1
    w[18,17]  R942      1
    w[18,17]  R943      1
    w[18,17]  normalized_inventory_18  -17
    w[18,18]  mass_18   1
    w[18,18]  R944      1
    w[18,18]  R945      1
    w[18,18]  normalized_inventory_18  -18
    w[18,19]  mass_18   1
    w[18,19]  R946      1
    w[18,19]  R947      1
    w[18,19]  normalized_inventory_18  -19
    w[18,20]  mass_18   1
    w[18,20]  R948      1
    w[18,20]  R949      1
    w[18,20]  normalized_inventory_18  -20
    w[18,21]  mass_18   1
    w[18,21]  R950      1
    w[18,21]  R951      1
    w[18,21]  normalized_inventory_18  -21
    w[18,22]  mass_18   1
    w[18,22]  R952      1
    w[18,22]  R953      1
    w[18,22]  normalized_inventory_18  -22
    w[19,0]   mass_19   1
    w[19,0]   R958      1
    w[19,0]   R959      1
    w[19,1]   mass_19   1
    w[19,1]   R960      1
    w[19,1]   R961      1
    w[19,1]   normalized_inventory_19  -1
    w[19,2]   mass_19   1
    w[19,2]   R962      1
    w[19,2]   R963      1
    w[19,2]   normalized_inventory_19  -2
    w[19,3]   mass_19   1
    w[19,3]   R964      1
    w[19,3]   R965      1
    w[19,3]   normalized_inventory_19  -3
    w[19,4]   mass_19   1
    w[19,4]   R966      1
    w[19,4]   R967      1
    w[19,4]   normalized_inventory_19  -4
    w[19,5]   mass_19   1
    w[19,5]   R968      1
    w[19,5]   R969      1
    w[19,5]   normalized_inventory_19  -5
    w[19,6]   mass_19   1
    w[19,6]   R970      1
    w[19,6]   R971      1
    w[19,6]   normalized_inventory_19  -6
    w[19,7]   mass_19   1
    w[19,7]   R972      1
    w[19,7]   R973      1
    w[19,7]   normalized_inventory_19  -7
    w[19,8]   mass_19   1
    w[19,8]   R974      1
    w[19,8]   R975      1
    w[19,8]   normalized_inventory_19  -8
    w[19,9]   mass_19   1
    w[19,9]   R976      1
    w[19,9]   R977      1
    w[19,9]   normalized_inventory_19  -9
    w[19,10]  mass_19   1
    w[19,10]  R978      1
    w[19,10]  R979      1
    w[19,10]  normalized_inventory_19  -10
    w[19,11]  mass_19   1
    w[19,11]  R980      1
    w[19,11]  R981      1
    w[19,11]  normalized_inventory_19  -11
    w[19,12]  mass_19   1
    w[19,12]  R982      1
    w[19,12]  R983      1
    w[19,12]  normalized_inventory_19  -12
    w[19,13]  mass_19   1
    w[19,13]  R984      1
    w[19,13]  R985      1
    w[19,13]  normalized_inventory_19  -13
    w[19,14]  mass_19   1
    w[19,14]  R986      1
    w[19,14]  R987      1
    w[19,14]  normalized_inventory_19  -14
    w[19,15]  mass_19   1
    w[19,15]  R988      1
    w[19,15]  R989      1
    w[19,15]  normalized_inventory_19  -15
    w[19,16]  mass_19   1
    w[19,16]  R990      1
    w[19,16]  R991      1
    w[19,16]  normalized_inventory_19  -16
    w[19,17]  mass_19   1
    w[19,17]  R992      1
    w[19,17]  R993      1
    w[19,17]  normalized_inventory_19  -17
    w[19,18]  mass_19   1
    w[19,18]  R994      1
    w[19,18]  R995      1
    w[19,18]  normalized_inventory_19  -18
    w[19,19]  mass_19   1
    w[19,19]  R996      1
    w[19,19]  R997      1
    w[19,19]  normalized_inventory_19  -19
    w[19,20]  mass_19   1
    w[19,20]  R998      1
    w[19,20]  R999      1
    w[19,20]  normalized_inventory_19  -20
    w[19,21]  mass_19   1
    w[19,21]  R1000     1
    w[19,21]  R1001     1
    w[19,21]  normalized_inventory_19  -21
    w[19,22]  mass_19   1
    w[19,22]  R1002     1
    w[19,22]  R1003     1
    w[19,22]  normalized_inventory_19  -22
    w[19,23]  mass_19   1
    w[19,23]  R1004     1
    w[19,23]  R1005     1
    w[19,23]  normalized_inventory_19  -23
    w[20,0]   mass_20   1
    w[20,0]   R1010     1
    w[20,0]   R1011     1
    w[20,1]   mass_20   1
    w[20,1]   R1012     1
    w[20,1]   R1013     1
    w[20,1]   normalized_inventory_20  -1
    w[20,2]   mass_20   1
    w[20,2]   R1014     1
    w[20,2]   R1015     1
    w[20,2]   normalized_inventory_20  -2
    w[20,3]   mass_20   1
    w[20,3]   R1016     1
    w[20,3]   R1017     1
    w[20,3]   normalized_inventory_20  -3
    w[20,4]   mass_20   1
    w[20,4]   R1018     1
    w[20,4]   R1019     1
    w[20,4]   normalized_inventory_20  -4
    w[20,5]   mass_20   1
    w[20,5]   R1020     1
    w[20,5]   R1021     1
    w[20,5]   normalized_inventory_20  -5
    w[20,6]   mass_20   1
    w[20,6]   R1022     1
    w[20,6]   R1023     1
    w[20,6]   normalized_inventory_20  -6
    w[20,7]   mass_20   1
    w[20,7]   R1024     1
    w[20,7]   R1025     1
    w[20,7]   normalized_inventory_20  -7
    w[20,8]   mass_20   1
    w[20,8]   R1026     1
    w[20,8]   R1027     1
    w[20,8]   normalized_inventory_20  -8
    w[20,9]   mass_20   1
    w[20,9]   R1028     1
    w[20,9]   R1029     1
    w[20,9]   normalized_inventory_20  -9
    w[20,10]  mass_20   1
    w[20,10]  R1030     1
    w[20,10]  R1031     1
    w[20,10]  normalized_inventory_20  -10
    w[20,11]  mass_20   1
    w[20,11]  R1032     1
    w[20,11]  R1033     1
    w[20,11]  normalized_inventory_20  -11
    w[20,12]  mass_20   1
    w[20,12]  R1034     1
    w[20,12]  R1035     1
    w[20,12]  normalized_inventory_20  -12
    w[20,13]  mass_20   1
    w[20,13]  R1036     1
    w[20,13]  R1037     1
    w[20,13]  normalized_inventory_20  -13
    w[20,14]  mass_20   1
    w[20,14]  R1038     1
    w[20,14]  R1039     1
    w[20,14]  normalized_inventory_20  -14
    w[20,15]  mass_20   1
    w[20,15]  R1040     1
    w[20,15]  R1041     1
    w[20,15]  normalized_inventory_20  -15
    w[20,16]  mass_20   1
    w[20,16]  R1042     1
    w[20,16]  R1043     1
    w[20,16]  normalized_inventory_20  -16
    w[20,17]  mass_20   1
    w[20,17]  R1044     1
    w[20,17]  R1045     1
    w[20,17]  normalized_inventory_20  -17
    w[20,18]  mass_20   1
    w[20,18]  R1046     1
    w[20,18]  R1047     1
    w[20,18]  normalized_inventory_20  -18
    w[20,19]  mass_20   1
    w[20,19]  R1048     1
    w[20,19]  R1049     1
    w[20,19]  normalized_inventory_20  -19
    w[20,20]  mass_20   1
    w[20,20]  R1050     1
    w[20,20]  R1051     1
    w[20,20]  normalized_inventory_20  -20
    w[20,21]  mass_20   1
    w[20,21]  R1052     1
    w[20,21]  R1053     1
    w[20,21]  normalized_inventory_20  -21
    w[20,22]  mass_20   1
    w[20,22]  R1054     1
    w[20,22]  R1055     1
    w[20,22]  normalized_inventory_20  -22
    w[20,23]  mass_20   1
    w[20,23]  R1056     1
    w[20,23]  R1057     1
    w[20,23]  normalized_inventory_20  -23
    t         mass_1    -1
    t         mass_2    -1
    t         mass_3    -1
    t         mass_4    -1
    t         mass_5    -1
    t         mass_6    -1
    t         mass_7    -1
    t         mass_8    -1
    t         mass_9    -1
    t         mass_10   -1
    t         mass_11   -1
    t         mass_12   -1
    t         mass_13   -1
    t         mass_14   -1
    t         mass_15   -1
    t         mass_16   -1
    t         mass_17   -1
    t         mass_18   -1
    t         mass_19   -1
    t         mass_20   -1
    t         scaled_stock_lower  -211
    t         scaled_stock_upper  -271
    z[1]      normalized_inventory_1  1
    z[1]      normalized_ratio_1  -9.0909090909090912e-02
    z[1]      scaled_stock_lower  1
    z[1]      scaled_stock_upper  1
    z[2]      normalized_inventory_2  1
    z[2]      normalized_ratio_2  -7.1428571428571425e-02
    z[2]      scaled_stock_lower  1
    z[2]      scaled_stock_upper  1
    z[3]      normalized_inventory_3  1
    z[3]      normalized_ratio_3  -6.6666666666666666e-02
    z[3]      scaled_stock_lower  1
    z[3]      scaled_stock_upper  1
    z[4]      normalized_inventory_4  1
    z[4]      normalized_ratio_4  -9.0909090909090912e-02
    z[4]      scaled_stock_lower  1
    z[4]      scaled_stock_upper  1
    z[5]      normalized_inventory_5  1
    z[5]      normalized_ratio_5  -9.0909090909090912e-02
    z[5]      scaled_stock_lower  1
    z[5]      scaled_stock_upper  1
    z[6]      normalized_inventory_6  1
    z[6]      normalized_ratio_6  -9.0909090909090912e-02
    z[6]      scaled_stock_lower  1
    z[6]      scaled_stock_upper  1
    z[7]      normalized_inventory_7  1
    z[7]      normalized_ratio_7  -0.1
    z[7]      scaled_stock_lower  1
    z[7]      scaled_stock_upper  1
    z[8]      normalized_inventory_8  1
    z[8]      normalized_ratio_8  -9.0909090909090912e-02
    z[8]      scaled_stock_lower  1
    z[8]      scaled_stock_upper  1
    z[9]      normalized_inventory_9  1
    z[9]      normalized_ratio_9  -1.1111111111111110e-01
    z[9]      scaled_stock_lower  1
    z[9]      scaled_stock_upper  1
    z[10]     normalized_inventory_10  1
    z[10]     normalized_ratio_10  -0.0625
    z[10]     scaled_stock_lower  1
    z[10]     scaled_stock_upper  1
    z[11]     normalized_inventory_11  1
    z[11]     normalized_ratio_11  -5.8823529411764705e-02
    z[11]     scaled_stock_lower  1
    z[11]     scaled_stock_upper  1
    z[12]     normalized_inventory_12  1
    z[12]     normalized_ratio_12  -0.1
    z[12]     scaled_stock_lower  1
    z[12]     scaled_stock_upper  1
    z[13]     normalized_inventory_13  1
    z[13]     normalized_ratio_13  -7.6923076923076927e-02
    z[13]     scaled_stock_lower  1
    z[13]     scaled_stock_upper  1
    z[14]     normalized_inventory_14  1
    z[14]     normalized_ratio_14  -7.6923076923076927e-02
    z[14]     scaled_stock_lower  1
    z[14]     scaled_stock_upper  1
    z[15]     normalized_inventory_15  1
    z[15]     normalized_ratio_15  -7.1428571428571425e-02
    z[15]     scaled_stock_lower  1
    z[15]     scaled_stock_upper  1
    z[16]     normalized_inventory_16  1
    z[16]     normalized_ratio_16  -8.3333333333333329e-02
    z[16]     scaled_stock_lower  1
    z[16]     scaled_stock_upper  1
    z[17]     normalized_inventory_17  1
    z[17]     normalized_ratio_17  -0.125
    z[17]     scaled_stock_lower  1
    z[17]     scaled_stock_upper  1
    z[18]     normalized_inventory_18  1
    z[18]     normalized_ratio_18  -9.0909090909090912e-02
    z[18]     scaled_stock_lower  1
    z[18]     scaled_stock_upper  1
    z[19]     normalized_inventory_19  1
    z[19]     normalized_ratio_19  -8.3333333333333329e-02
    z[19]     scaled_stock_lower  1
    z[19]     scaled_stock_upper  1
    z[20]     normalized_inventory_20  1
    z[20]     normalized_ratio_20  -7.6923076923076927e-02
    z[20]     scaled_stock_lower  1
    z[20]     scaled_stock_upper  1
    r[1]      normalized_ratio_1  1
    r[1]      normalization  1
    r[1]      R1065     -1
    r[1]      R1066     1
    r[1]      R1067     -1
    r[1]      R1068     1
    r[1]      R1069     -1
    r[1]      R1070     1
    r[1]      R1071     -1
    r[1]      R1072     1
    r[1]      R1073     -1
    r[1]      R1074     1
    r[1]      R1075     -1
    r[1]      R1076     1
    r[1]      R1077     -1
    r[1]      R1078     1
    r[1]      R1079     -1
    r[1]      R1080     1
    r[1]      R1081     -1
    r[1]      R1082     1
    r[1]      R1083     -1
    r[1]      R1084     1
    r[1]      R1085     -1
    r[1]      R1086     1
    r[1]      R1087     -1
    r[1]      R1088     1
    r[1]      R1089     -1
    r[1]      R1090     1
    r[1]      R1091     -1
    r[1]      R1092     1
    r[1]      R1093     -1
    r[1]      R1094     1
    r[1]      R1095     -1
    r[1]      R1096     1
    r[1]      R1097     -1
    r[1]      R1098     1
    r[1]      R1099     -1
    r[1]      R1100     1
    r[1]      R1101     -1
    r[1]      R1102     1
    r[2]      normalized_ratio_2  1
    r[2]      normalization  1
    r[2]      R1065     1
    r[2]      R1066     -1
    r[2]      R1103     -1
    r[2]      R1104     1
    r[2]      R1105     -1
    r[2]      R1106     1
    r[2]      R1107     -1
    r[2]      R1108     1
    r[2]      R1109     -1
    r[2]      R1110     1
    r[2]      R1111     -1
    r[2]      R1112     1
    r[2]      R1113     -1
    r[2]      R1114     1
    r[2]      R1115     -1
    r[2]      R1116     1
    r[2]      R1117     -1
    r[2]      R1118     1
    r[2]      R1119     -1
    r[2]      R1120     1
    r[2]      R1121     -1
    r[2]      R1122     1
    r[2]      R1123     -1
    r[2]      R1124     1
    r[2]      R1125     -1
    r[2]      R1126     1
    r[2]      R1127     -1
    r[2]      R1128     1
    r[2]      R1129     -1
    r[2]      R1130     1
    r[2]      R1131     -1
    r[2]      R1132     1
    r[2]      R1133     -1
    r[2]      R1134     1
    r[2]      R1135     -1
    r[2]      R1136     1
    r[2]      R1137     -1
    r[2]      R1138     1
    r[3]      normalized_ratio_3  1
    r[3]      normalization  1
    r[3]      R1067     1
    r[3]      R1068     -1
    r[3]      R1103     1
    r[3]      R1104     -1
    r[3]      R1139     -1
    r[3]      R1140     1
    r[3]      R1141     -1
    r[3]      R1142     1
    r[3]      R1143     -1
    r[3]      R1144     1
    r[3]      R1145     -1
    r[3]      R1146     1
    r[3]      R1147     -1
    r[3]      R1148     1
    r[3]      R1149     -1
    r[3]      R1150     1
    r[3]      R1151     -1
    r[3]      R1152     1
    r[3]      R1153     -1
    r[3]      R1154     1
    r[3]      R1155     -1
    r[3]      R1156     1
    r[3]      R1157     -1
    r[3]      R1158     1
    r[3]      R1159     -1
    r[3]      R1160     1
    r[3]      R1161     -1
    r[3]      R1162     1
    r[3]      R1163     -1
    r[3]      R1164     1
    r[3]      R1165     -1
    r[3]      R1166     1
    r[3]      R1167     -1
    r[3]      R1168     1
    r[3]      R1169     -1
    r[3]      R1170     1
    r[3]      R1171     -1
    r[3]      R1172     1
    r[4]      normalized_ratio_4  1
    r[4]      normalization  1
    r[4]      R1069     1
    r[4]      R1070     -1
    r[4]      R1105     1
    r[4]      R1106     -1
    r[4]      R1139     1
    r[4]      R1140     -1
    r[4]      R1173     -1
    r[4]      R1174     1
    r[4]      R1175     -1
    r[4]      R1176     1
    r[4]      R1177     -1
    r[4]      R1178     1
    r[4]      R1179     -1
    r[4]      R1180     1
    r[4]      R1181     -1
    r[4]      R1182     1
    r[4]      R1183     -1
    r[4]      R1184     1
    r[4]      R1185     -1
    r[4]      R1186     1
    r[4]      R1187     -1
    r[4]      R1188     1
    r[4]      R1189     -1
    r[4]      R1190     1
    r[4]      R1191     -1
    r[4]      R1192     1
    r[4]      R1193     -1
    r[4]      R1194     1
    r[4]      R1195     -1
    r[4]      R1196     1
    r[4]      R1197     -1
    r[4]      R1198     1
    r[4]      R1199     -1
    r[4]      R1200     1
    r[4]      R1201     -1
    r[4]      R1202     1
    r[4]      R1203     -1
    r[4]      R1204     1
    r[5]      normalized_ratio_5  1
    r[5]      normalization  1
    r[5]      R1071     1
    r[5]      R1072     -1
    r[5]      R1107     1
    r[5]      R1108     -1
    r[5]      R1141     1
    r[5]      R1142     -1
    r[5]      R1173     1
    r[5]      R1174     -1
    r[5]      R1205     -1
    r[5]      R1206     1
    r[5]      R1207     -1
    r[5]      R1208     1
    r[5]      R1209     -1
    r[5]      R1210     1
    r[5]      R1211     -1
    r[5]      R1212     1
    r[5]      R1213     -1
    r[5]      R1214     1
    r[5]      R1215     -1
    r[5]      R1216     1
    r[5]      R1217     -1
    r[5]      R1218     1
    r[5]      R1219     -1
    r[5]      R1220     1
    r[5]      R1221     -1
    r[5]      R1222     1
    r[5]      R1223     -1
    r[5]      R1224     1
    r[5]      R1225     -1
    r[5]      R1226     1
    r[5]      R1227     -1
    r[5]      R1228     1
    r[5]      R1229     -1
    r[5]      R1230     1
    r[5]      R1231     -1
    r[5]      R1232     1
    r[5]      R1233     -1
    r[5]      R1234     1
    r[6]      normalized_ratio_6  1
    r[6]      normalization  1
    r[6]      R1073     1
    r[6]      R1074     -1
    r[6]      R1109     1
    r[6]      R1110     -1
    r[6]      R1143     1
    r[6]      R1144     -1
    r[6]      R1175     1
    r[6]      R1176     -1
    r[6]      R1205     1
    r[6]      R1206     -1
    r[6]      R1235     -1
    r[6]      R1236     1
    r[6]      R1237     -1
    r[6]      R1238     1
    r[6]      R1239     -1
    r[6]      R1240     1
    r[6]      R1241     -1
    r[6]      R1242     1
    r[6]      R1243     -1
    r[6]      R1244     1
    r[6]      R1245     -1
    r[6]      R1246     1
    r[6]      R1247     -1
    r[6]      R1248     1
    r[6]      R1249     -1
    r[6]      R1250     1
    r[6]      R1251     -1
    r[6]      R1252     1
    r[6]      R1253     -1
    r[6]      R1254     1
    r[6]      R1255     -1
    r[6]      R1256     1
    r[6]      R1257     -1
    r[6]      R1258     1
    r[6]      R1259     -1
    r[6]      R1260     1
    r[6]      R1261     -1
    r[6]      R1262     1
    r[7]      normalized_ratio_7  1
    r[7]      normalization  1
    r[7]      R1075     1
    r[7]      R1076     -1
    r[7]      R1111     1
    r[7]      R1112     -1
    r[7]      R1145     1
    r[7]      R1146     -1
    r[7]      R1177     1
    r[7]      R1178     -1
    r[7]      R1207     1
    r[7]      R1208     -1
    r[7]      R1235     1
    r[7]      R1236     -1
    r[7]      R1263     -1
    r[7]      R1264     1
    r[7]      R1265     -1
    r[7]      R1266     1
    r[7]      R1267     -1
    r[7]      R1268     1
    r[7]      R1269     -1
    r[7]      R1270     1
    r[7]      R1271     -1
    r[7]      R1272     1
    r[7]      R1273     -1
    r[7]      R1274     1
    r[7]      R1275     -1
    r[7]      R1276     1
    r[7]      R1277     -1
    r[7]      R1278     1
    r[7]      R1279     -1
    r[7]      R1280     1
    r[7]      R1281     -1
    r[7]      R1282     1
    r[7]      R1283     -1
    r[7]      R1284     1
    r[7]      R1285     -1
    r[7]      R1286     1
    r[7]      R1287     -1
    r[7]      R1288     1
    r[8]      normalized_ratio_8  1
    r[8]      normalization  1
    r[8]      R1077     1
    r[8]      R1078     -1
    r[8]      R1113     1
    r[8]      R1114     -1
    r[8]      R1147     1
    r[8]      R1148     -1
    r[8]      R1179     1
    r[8]      R1180     -1
    r[8]      R1209     1
    r[8]      R1210     -1
    r[8]      R1237     1
    r[8]      R1238     -1
    r[8]      R1263     1
    r[8]      R1264     -1
    r[8]      R1289     -1
    r[8]      R1290     1
    r[8]      R1291     -1
    r[8]      R1292     1
    r[8]      R1293     -1
    r[8]      R1294     1
    r[8]      R1295     -1
    r[8]      R1296     1
    r[8]      R1297     -1
    r[8]      R1298     1
    r[8]      R1299     -1
    r[8]      R1300     1
    r[8]      R1301     -1
    r[8]      R1302     1
    r[8]      R1303     -1
    r[8]      R1304     1
    r[8]      R1305     -1
    r[8]      R1306     1
    r[8]      R1307     -1
    r[8]      R1308     1
    r[8]      R1309     -1
    r[8]      R1310     1
    r[8]      R1311     -1
    r[8]      R1312     1
    r[9]      normalized_ratio_9  1
    r[9]      normalization  1
    r[9]      R1079     1
    r[9]      R1080     -1
    r[9]      R1115     1
    r[9]      R1116     -1
    r[9]      R1149     1
    r[9]      R1150     -1
    r[9]      R1181     1
    r[9]      R1182     -1
    r[9]      R1211     1
    r[9]      R1212     -1
    r[9]      R1239     1
    r[9]      R1240     -1
    r[9]      R1265     1
    r[9]      R1266     -1
    r[9]      R1289     1
    r[9]      R1290     -1
    r[9]      R1313     -1
    r[9]      R1314     1
    r[9]      R1315     -1
    r[9]      R1316     1
    r[9]      R1317     -1
    r[9]      R1318     1
    r[9]      R1319     -1
    r[9]      R1320     1
    r[9]      R1321     -1
    r[9]      R1322     1
    r[9]      R1323     -1
    r[9]      R1324     1
    r[9]      R1325     -1
    r[9]      R1326     1
    r[9]      R1327     -1
    r[9]      R1328     1
    r[9]      R1329     -1
    r[9]      R1330     1
    r[9]      R1331     -1
    r[9]      R1332     1
    r[9]      R1333     -1
    r[9]      R1334     1
    r[10]     normalized_ratio_10  1
    r[10]     normalization  1
    r[10]     R1081     1
    r[10]     R1082     -1
    r[10]     R1117     1
    r[10]     R1118     -1
    r[10]     R1151     1
    r[10]     R1152     -1
    r[10]     R1183     1
    r[10]     R1184     -1
    r[10]     R1213     1
    r[10]     R1214     -1
    r[10]     R1241     1
    r[10]     R1242     -1
    r[10]     R1267     1
    r[10]     R1268     -1
    r[10]     R1291     1
    r[10]     R1292     -1
    r[10]     R1313     1
    r[10]     R1314     -1
    r[10]     R1335     -1
    r[10]     R1336     1
    r[10]     R1337     -1
    r[10]     R1338     1
    r[10]     R1339     -1
    r[10]     R1340     1
    r[10]     R1341     -1
    r[10]     R1342     1
    r[10]     R1343     -1
    r[10]     R1344     1
    r[10]     R1345     -1
    r[10]     R1346     1
    r[10]     R1347     -1
    r[10]     R1348     1
    r[10]     R1349     -1
    r[10]     R1350     1
    r[10]     R1351     -1
    r[10]     R1352     1
    r[10]     R1353     -1
    r[10]     R1354     1
    r[11]     normalized_ratio_11  1
    r[11]     normalization  1
    r[11]     R1083     1
    r[11]     R1084     -1
    r[11]     R1119     1
    r[11]     R1120     -1
    r[11]     R1153     1
    r[11]     R1154     -1
    r[11]     R1185     1
    r[11]     R1186     -1
    r[11]     R1215     1
    r[11]     R1216     -1
    r[11]     R1243     1
    r[11]     R1244     -1
    r[11]     R1269     1
    r[11]     R1270     -1
    r[11]     R1293     1
    r[11]     R1294     -1
    r[11]     R1315     1
    r[11]     R1316     -1
    r[11]     R1335     1
    r[11]     R1336     -1
    r[11]     R1355     -1
    r[11]     R1356     1
    r[11]     R1357     -1
    r[11]     R1358     1
    r[11]     R1359     -1
    r[11]     R1360     1
    r[11]     R1361     -1
    r[11]     R1362     1
    r[11]     R1363     -1
    r[11]     R1364     1
    r[11]     R1365     -1
    r[11]     R1366     1
    r[11]     R1367     -1
    r[11]     R1368     1
    r[11]     R1369     -1
    r[11]     R1370     1
    r[11]     R1371     -1
    r[11]     R1372     1
    r[12]     normalized_ratio_12  1
    r[12]     normalization  1
    r[12]     R1085     1
    r[12]     R1086     -1
    r[12]     R1121     1
    r[12]     R1122     -1
    r[12]     R1155     1
    r[12]     R1156     -1
    r[12]     R1187     1
    r[12]     R1188     -1
    r[12]     R1217     1
    r[12]     R1218     -1
    r[12]     R1245     1
    r[12]     R1246     -1
    r[12]     R1271     1
    r[12]     R1272     -1
    r[12]     R1295     1
    r[12]     R1296     -1
    r[12]     R1317     1
    r[12]     R1318     -1
    r[12]     R1337     1
    r[12]     R1338     -1
    r[12]     R1355     1
    r[12]     R1356     -1
    r[12]     R1373     -1
    r[12]     R1374     1
    r[12]     R1375     -1
    r[12]     R1376     1
    r[12]     R1377     -1
    r[12]     R1378     1
    r[12]     R1379     -1
    r[12]     R1380     1
    r[12]     R1381     -1
    r[12]     R1382     1
    r[12]     R1383     -1
    r[12]     R1384     1
    r[12]     R1385     -1
    r[12]     R1386     1
    r[12]     R1387     -1
    r[12]     R1388     1
    r[13]     normalized_ratio_13  1
    r[13]     normalization  1
    r[13]     R1087     1
    r[13]     R1088     -1
    r[13]     R1123     1
    r[13]     R1124     -1
    r[13]     R1157     1
    r[13]     R1158     -1
    r[13]     R1189     1
    r[13]     R1190     -1
    r[13]     R1219     1
    r[13]     R1220     -1
    r[13]     R1247     1
    r[13]     R1248     -1
    r[13]     R1273     1
    r[13]     R1274     -1
    r[13]     R1297     1
    r[13]     R1298     -1
    r[13]     R1319     1
    r[13]     R1320     -1
    r[13]     R1339     1
    r[13]     R1340     -1
    r[13]     R1357     1
    r[13]     R1358     -1
    r[13]     R1373     1
    r[13]     R1374     -1
    r[13]     R1389     -1
    r[13]     R1390     1
    r[13]     R1391     -1
    r[13]     R1392     1
    r[13]     R1393     -1
    r[13]     R1394     1
    r[13]     R1395     -1
    r[13]     R1396     1
    r[13]     R1397     -1
    r[13]     R1398     1
    r[13]     R1399     -1
    r[13]     R1400     1
    r[13]     R1401     -1
    r[13]     R1402     1
    r[14]     normalized_ratio_14  1
    r[14]     normalization  1
    r[14]     R1089     1
    r[14]     R1090     -1
    r[14]     R1125     1
    r[14]     R1126     -1
    r[14]     R1159     1
    r[14]     R1160     -1
    r[14]     R1191     1
    r[14]     R1192     -1
    r[14]     R1221     1
    r[14]     R1222     -1
    r[14]     R1249     1
    r[14]     R1250     -1
    r[14]     R1275     1
    r[14]     R1276     -1
    r[14]     R1299     1
    r[14]     R1300     -1
    r[14]     R1321     1
    r[14]     R1322     -1
    r[14]     R1341     1
    r[14]     R1342     -1
    r[14]     R1359     1
    r[14]     R1360     -1
    r[14]     R1375     1
    r[14]     R1376     -1
    r[14]     R1389     1
    r[14]     R1390     -1
    r[14]     R1403     -1
    r[14]     R1404     1
    r[14]     R1405     -1
    r[14]     R1406     1
    r[14]     R1407     -1
    r[14]     R1408     1
    r[14]     R1409     -1
    r[14]     R1410     1
    r[14]     R1411     -1
    r[14]     R1412     1
    r[14]     R1413     -1
    r[14]     R1414     1
    r[15]     normalized_ratio_15  1
    r[15]     normalization  1
    r[15]     R1091     1
    r[15]     R1092     -1
    r[15]     R1127     1
    r[15]     R1128     -1
    r[15]     R1161     1
    r[15]     R1162     -1
    r[15]     R1193     1
    r[15]     R1194     -1
    r[15]     R1223     1
    r[15]     R1224     -1
    r[15]     R1251     1
    r[15]     R1252     -1
    r[15]     R1277     1
    r[15]     R1278     -1
    r[15]     R1301     1
    r[15]     R1302     -1
    r[15]     R1323     1
    r[15]     R1324     -1
    r[15]     R1343     1
    r[15]     R1344     -1
    r[15]     R1361     1
    r[15]     R1362     -1
    r[15]     R1377     1
    r[15]     R1378     -1
    r[15]     R1391     1
    r[15]     R1392     -1
    r[15]     R1403     1
    r[15]     R1404     -1
    r[15]     R1415     -1
    r[15]     R1416     1
    r[15]     R1417     -1
    r[15]     R1418     1
    r[15]     R1419     -1
    r[15]     R1420     1
    r[15]     R1421     -1
    r[15]     R1422     1
    r[15]     R1423     -1
    r[15]     R1424     1
    r[16]     normalized_ratio_16  1
    r[16]     normalization  1
    r[16]     R1093     1
    r[16]     R1094     -1
    r[16]     R1129     1
    r[16]     R1130     -1
    r[16]     R1163     1
    r[16]     R1164     -1
    r[16]     R1195     1
    r[16]     R1196     -1
    r[16]     R1225     1
    r[16]     R1226     -1
    r[16]     R1253     1
    r[16]     R1254     -1
    r[16]     R1279     1
    r[16]     R1280     -1
    r[16]     R1303     1
    r[16]     R1304     -1
    r[16]     R1325     1
    r[16]     R1326     -1
    r[16]     R1345     1
    r[16]     R1346     -1
    r[16]     R1363     1
    r[16]     R1364     -1
    r[16]     R1379     1
    r[16]     R1380     -1
    r[16]     R1393     1
    r[16]     R1394     -1
    r[16]     R1405     1
    r[16]     R1406     -1
    r[16]     R1415     1
    r[16]     R1416     -1
    r[16]     R1425     -1
    r[16]     R1426     1
    r[16]     R1427     -1
    r[16]     R1428     1
    r[16]     R1429     -1
    r[16]     R1430     1
    r[16]     R1431     -1
    r[16]     R1432     1
    r[17]     normalized_ratio_17  1
    r[17]     normalization  1
    r[17]     R1095     1
    r[17]     R1096     -1
    r[17]     R1131     1
    r[17]     R1132     -1
    r[17]     R1165     1
    r[17]     R1166     -1
    r[17]     R1197     1
    r[17]     R1198     -1
    r[17]     R1227     1
    r[17]     R1228     -1
    r[17]     R1255     1
    r[17]     R1256     -1
    r[17]     R1281     1
    r[17]     R1282     -1
    r[17]     R1305     1
    r[17]     R1306     -1
    r[17]     R1327     1
    r[17]     R1328     -1
    r[17]     R1347     1
    r[17]     R1348     -1
    r[17]     R1365     1
    r[17]     R1366     -1
    r[17]     R1381     1
    r[17]     R1382     -1
    r[17]     R1395     1
    r[17]     R1396     -1
    r[17]     R1407     1
    r[17]     R1408     -1
    r[17]     R1417     1
    r[17]     R1418     -1
    r[17]     R1425     1
    r[17]     R1426     -1
    r[17]     R1433     -1
    r[17]     R1434     1
    r[17]     R1435     -1
    r[17]     R1436     1
    r[17]     R1437     -1
    r[17]     R1438     1
    r[18]     normalized_ratio_18  1
    r[18]     normalization  1
    r[18]     R1097     1
    r[18]     R1098     -1
    r[18]     R1133     1
    r[18]     R1134     -1
    r[18]     R1167     1
    r[18]     R1168     -1
    r[18]     R1199     1
    r[18]     R1200     -1
    r[18]     R1229     1
    r[18]     R1230     -1
    r[18]     R1257     1
    r[18]     R1258     -1
    r[18]     R1283     1
    r[18]     R1284     -1
    r[18]     R1307     1
    r[18]     R1308     -1
    r[18]     R1329     1
    r[18]     R1330     -1
    r[18]     R1349     1
    r[18]     R1350     -1
    r[18]     R1367     1
    r[18]     R1368     -1
    r[18]     R1383     1
    r[18]     R1384     -1
    r[18]     R1397     1
    r[18]     R1398     -1
    r[18]     R1409     1
    r[18]     R1410     -1
    r[18]     R1419     1
    r[18]     R1420     -1
    r[18]     R1427     1
    r[18]     R1428     -1
    r[18]     R1433     1
    r[18]     R1434     -1
    r[18]     R1439     -1
    r[18]     R1440     1
    r[18]     R1441     -1
    r[18]     R1442     1
    r[19]     normalized_ratio_19  1
    r[19]     normalization  1
    r[19]     R1099     1
    r[19]     R1100     -1
    r[19]     R1135     1
    r[19]     R1136     -1
    r[19]     R1169     1
    r[19]     R1170     -1
    r[19]     R1201     1
    r[19]     R1202     -1
    r[19]     R1231     1
    r[19]     R1232     -1
    r[19]     R1259     1
    r[19]     R1260     -1
    r[19]     R1285     1
    r[19]     R1286     -1
    r[19]     R1309     1
    r[19]     R1310     -1
    r[19]     R1331     1
    r[19]     R1332     -1
    r[19]     R1351     1
    r[19]     R1352     -1
    r[19]     R1369     1
    r[19]     R1370     -1
    r[19]     R1385     1
    r[19]     R1386     -1
    r[19]     R1399     1
    r[19]     R1400     -1
    r[19]     R1411     1
    r[19]     R1412     -1
    r[19]     R1421     1
    r[19]     R1422     -1
    r[19]     R1429     1
    r[19]     R1430     -1
    r[19]     R1435     1
    r[19]     R1436     -1
    r[19]     R1439     1
    r[19]     R1440     -1
    r[19]     R1443     -1
    r[19]     R1444     1
    r[20]     normalized_ratio_20  1
    r[20]     normalization  1
    r[20]     R1101     1
    r[20]     R1102     -1
    r[20]     R1137     1
    r[20]     R1138     -1
    r[20]     R1171     1
    r[20]     R1172     -1
    r[20]     R1203     1
    r[20]     R1204     -1
    r[20]     R1233     1
    r[20]     R1234     -1
    r[20]     R1261     1
    r[20]     R1262     -1
    r[20]     R1287     1
    r[20]     R1288     -1
    r[20]     R1311     1
    r[20]     R1312     -1
    r[20]     R1333     1
    r[20]     R1334     -1
    r[20]     R1353     1
    r[20]     R1354     -1
    r[20]     R1371     1
    r[20]     R1372     -1
    r[20]     R1387     1
    r[20]     R1388     -1
    r[20]     R1401     1
    r[20]     R1402     -1
    r[20]     R1413     1
    r[20]     R1414     -1
    r[20]     R1423     1
    r[20]     R1424     -1
    r[20]     R1431     1
    r[20]     R1432     -1
    r[20]     R1437     1
    r[20]     R1438     -1
    r[20]     R1441     1
    r[20]     R1442     -1
    r[20]     R1443     1
    r[20]     R1444     -1
    a[1,2]    R1065     1
    a[1,2]    R1066     1
    a[1,2]    true_G_epigraph  1
    a[1,2]    physical_G_upper  1
    a[1,3]    R1067     1
    a[1,3]    R1068     1
    a[1,3]    true_G_epigraph  1
    a[1,3]    physical_G_upper  1
    a[1,4]    R1069     1
    a[1,4]    R1070     1
    a[1,4]    true_G_epigraph  1
    a[1,4]    physical_G_upper  1
    a[1,5]    R1071     1
    a[1,5]    R1072     1
    a[1,5]    true_G_epigraph  1
    a[1,5]    physical_G_upper  1
    a[1,6]    R1073     1
    a[1,6]    R1074     1
    a[1,6]    true_G_epigraph  1
    a[1,6]    physical_G_upper  1
    a[1,7]    R1075     1
    a[1,7]    R1076     1
    a[1,7]    true_G_epigraph  1
    a[1,7]    physical_G_upper  1
    a[1,8]    R1077     1
    a[1,8]    R1078     1
    a[1,8]    true_G_epigraph  1
    a[1,8]    physical_G_upper  1
    a[1,9]    R1079     1
    a[1,9]    R1080     1
    a[1,9]    true_G_epigraph  1
    a[1,9]    physical_G_upper  1
    a[1,10]   R1081     1
    a[1,10]   R1082     1
    a[1,10]   true_G_epigraph  1
    a[1,10]   physical_G_upper  1
    a[1,11]   R1083     1
    a[1,11]   R1084     1
    a[1,11]   true_G_epigraph  1
    a[1,11]   physical_G_upper  1
    a[1,12]   R1085     1
    a[1,12]   R1086     1
    a[1,12]   true_G_epigraph  1
    a[1,12]   physical_G_upper  1
    a[1,13]   R1087     1
    a[1,13]   R1088     1
    a[1,13]   true_G_epigraph  1
    a[1,13]   physical_G_upper  1
    a[1,14]   R1089     1
    a[1,14]   R1090     1
    a[1,14]   true_G_epigraph  1
    a[1,14]   physical_G_upper  1
    a[1,15]   R1091     1
    a[1,15]   R1092     1
    a[1,15]   true_G_epigraph  1
    a[1,15]   physical_G_upper  1
    a[1,16]   R1093     1
    a[1,16]   R1094     1
    a[1,16]   true_G_epigraph  1
    a[1,16]   physical_G_upper  1
    a[1,17]   R1095     1
    a[1,17]   R1096     1
    a[1,17]   true_G_epigraph  1
    a[1,17]   physical_G_upper  1
    a[1,18]   R1097     1
    a[1,18]   R1098     1
    a[1,18]   true_G_epigraph  1
    a[1,18]   physical_G_upper  1
    a[1,19]   R1099     1
    a[1,19]   R1100     1
    a[1,19]   true_G_epigraph  1
    a[1,19]   physical_G_upper  1
    a[1,20]   R1101     1
    a[1,20]   R1102     1
    a[1,20]   true_G_epigraph  1
    a[1,20]   physical_G_upper  1
    a[2,3]    R1103     1
    a[2,3]    R1104     1
    a[2,3]    true_G_epigraph  1
    a[2,3]    physical_G_upper  1
    a[2,4]    R1105     1
    a[2,4]    R1106     1
    a[2,4]    true_G_epigraph  1
    a[2,4]    physical_G_upper  1
    a[2,5]    R1107     1
    a[2,5]    R1108     1
    a[2,5]    true_G_epigraph  1
    a[2,5]    physical_G_upper  1
    a[2,6]    R1109     1
    a[2,6]    R1110     1
    a[2,6]    true_G_epigraph  1
    a[2,6]    physical_G_upper  1
    a[2,7]    R1111     1
    a[2,7]    R1112     1
    a[2,7]    true_G_epigraph  1
    a[2,7]    physical_G_upper  1
    a[2,8]    R1113     1
    a[2,8]    R1114     1
    a[2,8]    true_G_epigraph  1
    a[2,8]    physical_G_upper  1
    a[2,9]    R1115     1
    a[2,9]    R1116     1
    a[2,9]    true_G_epigraph  1
    a[2,9]    physical_G_upper  1
    a[2,10]   R1117     1
    a[2,10]   R1118     1
    a[2,10]   true_G_epigraph  1
    a[2,10]   physical_G_upper  1
    a[2,11]   R1119     1
    a[2,11]   R1120     1
    a[2,11]   true_G_epigraph  1
    a[2,11]   physical_G_upper  1
    a[2,12]   R1121     1
    a[2,12]   R1122     1
    a[2,12]   true_G_epigraph  1
    a[2,12]   physical_G_upper  1
    a[2,13]   R1123     1
    a[2,13]   R1124     1
    a[2,13]   true_G_epigraph  1
    a[2,13]   physical_G_upper  1
    a[2,14]   R1125     1
    a[2,14]   R1126     1
    a[2,14]   true_G_epigraph  1
    a[2,14]   physical_G_upper  1
    a[2,15]   R1127     1
    a[2,15]   R1128     1
    a[2,15]   true_G_epigraph  1
    a[2,15]   physical_G_upper  1
    a[2,16]   R1129     1
    a[2,16]   R1130     1
    a[2,16]   true_G_epigraph  1
    a[2,16]   physical_G_upper  1
    a[2,17]   R1131     1
    a[2,17]   R1132     1
    a[2,17]   true_G_epigraph  1
    a[2,17]   physical_G_upper  1
    a[2,18]   R1133     1
    a[2,18]   R1134     1
    a[2,18]   true_G_epigraph  1
    a[2,18]   physical_G_upper  1
    a[2,19]   R1135     1
    a[2,19]   R1136     1
    a[2,19]   true_G_epigraph  1
    a[2,19]   physical_G_upper  1
    a[2,20]   R1137     1
    a[2,20]   R1138     1
    a[2,20]   true_G_epigraph  1
    a[2,20]   physical_G_upper  1
    a[3,4]    R1139     1
    a[3,4]    R1140     1
    a[3,4]    true_G_epigraph  1
    a[3,4]    physical_G_upper  1
    a[3,5]    R1141     1
    a[3,5]    R1142     1
    a[3,5]    true_G_epigraph  1
    a[3,5]    physical_G_upper  1
    a[3,6]    R1143     1
    a[3,6]    R1144     1
    a[3,6]    true_G_epigraph  1
    a[3,6]    physical_G_upper  1
    a[3,7]    R1145     1
    a[3,7]    R1146     1
    a[3,7]    true_G_epigraph  1
    a[3,7]    physical_G_upper  1
    a[3,8]    R1147     1
    a[3,8]    R1148     1
    a[3,8]    true_G_epigraph  1
    a[3,8]    physical_G_upper  1
    a[3,9]    R1149     1
    a[3,9]    R1150     1
    a[3,9]    true_G_epigraph  1
    a[3,9]    physical_G_upper  1
    a[3,10]   R1151     1
    a[3,10]   R1152     1
    a[3,10]   true_G_epigraph  1
    a[3,10]   physical_G_upper  1
    a[3,11]   R1153     1
    a[3,11]   R1154     1
    a[3,11]   true_G_epigraph  1
    a[3,11]   physical_G_upper  1
    a[3,12]   R1155     1
    a[3,12]   R1156     1
    a[3,12]   true_G_epigraph  1
    a[3,12]   physical_G_upper  1
    a[3,13]   R1157     1
    a[3,13]   R1158     1
    a[3,13]   true_G_epigraph  1
    a[3,13]   physical_G_upper  1
    a[3,14]   R1159     1
    a[3,14]   R1160     1
    a[3,14]   true_G_epigraph  1
    a[3,14]   physical_G_upper  1
    a[3,15]   R1161     1
    a[3,15]   R1162     1
    a[3,15]   true_G_epigraph  1
    a[3,15]   physical_G_upper  1
    a[3,16]   R1163     1
    a[3,16]   R1164     1
    a[3,16]   true_G_epigraph  1
    a[3,16]   physical_G_upper  1
    a[3,17]   R1165     1
    a[3,17]   R1166     1
    a[3,17]   true_G_epigraph  1
    a[3,17]   physical_G_upper  1
    a[3,18]   R1167     1
    a[3,18]   R1168     1
    a[3,18]   true_G_epigraph  1
    a[3,18]   physical_G_upper  1
    a[3,19]   R1169     1
    a[3,19]   R1170     1
    a[3,19]   true_G_epigraph  1
    a[3,19]   physical_G_upper  1
    a[3,20]   R1171     1
    a[3,20]   R1172     1
    a[3,20]   true_G_epigraph  1
    a[3,20]   physical_G_upper  1
    a[4,5]    R1173     1
    a[4,5]    R1174     1
    a[4,5]    true_G_epigraph  1
    a[4,5]    physical_G_upper  1
    a[4,6]    R1175     1
    a[4,6]    R1176     1
    a[4,6]    true_G_epigraph  1
    a[4,6]    physical_G_upper  1
    a[4,7]    R1177     1
    a[4,7]    R1178     1
    a[4,7]    true_G_epigraph  1
    a[4,7]    physical_G_upper  1
    a[4,8]    R1179     1
    a[4,8]    R1180     1
    a[4,8]    true_G_epigraph  1
    a[4,8]    physical_G_upper  1
    a[4,9]    R1181     1
    a[4,9]    R1182     1
    a[4,9]    true_G_epigraph  1
    a[4,9]    physical_G_upper  1
    a[4,10]   R1183     1
    a[4,10]   R1184     1
    a[4,10]   true_G_epigraph  1
    a[4,10]   physical_G_upper  1
    a[4,11]   R1185     1
    a[4,11]   R1186     1
    a[4,11]   true_G_epigraph  1
    a[4,11]   physical_G_upper  1
    a[4,12]   R1187     1
    a[4,12]   R1188     1
    a[4,12]   true_G_epigraph  1
    a[4,12]   physical_G_upper  1
    a[4,13]   R1189     1
    a[4,13]   R1190     1
    a[4,13]   true_G_epigraph  1
    a[4,13]   physical_G_upper  1
    a[4,14]   R1191     1
    a[4,14]   R1192     1
    a[4,14]   true_G_epigraph  1
    a[4,14]   physical_G_upper  1
    a[4,15]   R1193     1
    a[4,15]   R1194     1
    a[4,15]   true_G_epigraph  1
    a[4,15]   physical_G_upper  1
    a[4,16]   R1195     1
    a[4,16]   R1196     1
    a[4,16]   true_G_epigraph  1
    a[4,16]   physical_G_upper  1
    a[4,17]   R1197     1
    a[4,17]   R1198     1
    a[4,17]   true_G_epigraph  1
    a[4,17]   physical_G_upper  1
    a[4,18]   R1199     1
    a[4,18]   R1200     1
    a[4,18]   true_G_epigraph  1
    a[4,18]   physical_G_upper  1
    a[4,19]   R1201     1
    a[4,19]   R1202     1
    a[4,19]   true_G_epigraph  1
    a[4,19]   physical_G_upper  1
    a[4,20]   R1203     1
    a[4,20]   R1204     1
    a[4,20]   true_G_epigraph  1
    a[4,20]   physical_G_upper  1
    a[5,6]    R1205     1
    a[5,6]    R1206     1
    a[5,6]    true_G_epigraph  1
    a[5,6]    physical_G_upper  1
    a[5,7]    R1207     1
    a[5,7]    R1208     1
    a[5,7]    true_G_epigraph  1
    a[5,7]    physical_G_upper  1
    a[5,8]    R1209     1
    a[5,8]    R1210     1
    a[5,8]    true_G_epigraph  1
    a[5,8]    physical_G_upper  1
    a[5,9]    R1211     1
    a[5,9]    R1212     1
    a[5,9]    true_G_epigraph  1
    a[5,9]    physical_G_upper  1
    a[5,10]   R1213     1
    a[5,10]   R1214     1
    a[5,10]   true_G_epigraph  1
    a[5,10]   physical_G_upper  1
    a[5,11]   R1215     1
    a[5,11]   R1216     1
    a[5,11]   true_G_epigraph  1
    a[5,11]   physical_G_upper  1
    a[5,12]   R1217     1
    a[5,12]   R1218     1
    a[5,12]   true_G_epigraph  1
    a[5,12]   physical_G_upper  1
    a[5,13]   R1219     1
    a[5,13]   R1220     1
    a[5,13]   true_G_epigraph  1
    a[5,13]   physical_G_upper  1
    a[5,14]   R1221     1
    a[5,14]   R1222     1
    a[5,14]   true_G_epigraph  1
    a[5,14]   physical_G_upper  1
    a[5,15]   R1223     1
    a[5,15]   R1224     1
    a[5,15]   true_G_epigraph  1
    a[5,15]   physical_G_upper  1
    a[5,16]   R1225     1
    a[5,16]   R1226     1
    a[5,16]   true_G_epigraph  1
    a[5,16]   physical_G_upper  1
    a[5,17]   R1227     1
    a[5,17]   R1228     1
    a[5,17]   true_G_epigraph  1
    a[5,17]   physical_G_upper  1
    a[5,18]   R1229     1
    a[5,18]   R1230     1
    a[5,18]   true_G_epigraph  1
    a[5,18]   physical_G_upper  1
    a[5,19]   R1231     1
    a[5,19]   R1232     1
    a[5,19]   true_G_epigraph  1
    a[5,19]   physical_G_upper  1
    a[5,20]   R1233     1
    a[5,20]   R1234     1
    a[5,20]   true_G_epigraph  1
    a[5,20]   physical_G_upper  1
    a[6,7]    R1235     1
    a[6,7]    R1236     1
    a[6,7]    true_G_epigraph  1
    a[6,7]    physical_G_upper  1
    a[6,8]    R1237     1
    a[6,8]    R1238     1
    a[6,8]    true_G_epigraph  1
    a[6,8]    physical_G_upper  1
    a[6,9]    R1239     1
    a[6,9]    R1240     1
    a[6,9]    true_G_epigraph  1
    a[6,9]    physical_G_upper  1
    a[6,10]   R1241     1
    a[6,10]   R1242     1
    a[6,10]   true_G_epigraph  1
    a[6,10]   physical_G_upper  1
    a[6,11]   R1243     1
    a[6,11]   R1244     1
    a[6,11]   true_G_epigraph  1
    a[6,11]   physical_G_upper  1
    a[6,12]   R1245     1
    a[6,12]   R1246     1
    a[6,12]   true_G_epigraph  1
    a[6,12]   physical_G_upper  1
    a[6,13]   R1247     1
    a[6,13]   R1248     1
    a[6,13]   true_G_epigraph  1
    a[6,13]   physical_G_upper  1
    a[6,14]   R1249     1
    a[6,14]   R1250     1
    a[6,14]   true_G_epigraph  1
    a[6,14]   physical_G_upper  1
    a[6,15]   R1251     1
    a[6,15]   R1252     1
    a[6,15]   true_G_epigraph  1
    a[6,15]   physical_G_upper  1
    a[6,16]   R1253     1
    a[6,16]   R1254     1
    a[6,16]   true_G_epigraph  1
    a[6,16]   physical_G_upper  1
    a[6,17]   R1255     1
    a[6,17]   R1256     1
    a[6,17]   true_G_epigraph  1
    a[6,17]   physical_G_upper  1
    a[6,18]   R1257     1
    a[6,18]   R1258     1
    a[6,18]   true_G_epigraph  1
    a[6,18]   physical_G_upper  1
    a[6,19]   R1259     1
    a[6,19]   R1260     1
    a[6,19]   true_G_epigraph  1
    a[6,19]   physical_G_upper  1
    a[6,20]   R1261     1
    a[6,20]   R1262     1
    a[6,20]   true_G_epigraph  1
    a[6,20]   physical_G_upper  1
    a[7,8]    R1263     1
    a[7,8]    R1264     1
    a[7,8]    true_G_epigraph  1
    a[7,8]    physical_G_upper  1
    a[7,9]    R1265     1
    a[7,9]    R1266     1
    a[7,9]    true_G_epigraph  1
    a[7,9]    physical_G_upper  1
    a[7,10]   R1267     1
    a[7,10]   R1268     1
    a[7,10]   true_G_epigraph  1
    a[7,10]   physical_G_upper  1
    a[7,11]   R1269     1
    a[7,11]   R1270     1
    a[7,11]   true_G_epigraph  1
    a[7,11]   physical_G_upper  1
    a[7,12]   R1271     1
    a[7,12]   R1272     1
    a[7,12]   true_G_epigraph  1
    a[7,12]   physical_G_upper  1
    a[7,13]   R1273     1
    a[7,13]   R1274     1
    a[7,13]   true_G_epigraph  1
    a[7,13]   physical_G_upper  1
    a[7,14]   R1275     1
    a[7,14]   R1276     1
    a[7,14]   true_G_epigraph  1
    a[7,14]   physical_G_upper  1
    a[7,15]   R1277     1
    a[7,15]   R1278     1
    a[7,15]   true_G_epigraph  1
    a[7,15]   physical_G_upper  1
    a[7,16]   R1279     1
    a[7,16]   R1280     1
    a[7,16]   true_G_epigraph  1
    a[7,16]   physical_G_upper  1
    a[7,17]   R1281     1
    a[7,17]   R1282     1
    a[7,17]   true_G_epigraph  1
    a[7,17]   physical_G_upper  1
    a[7,18]   R1283     1
    a[7,18]   R1284     1
    a[7,18]   true_G_epigraph  1
    a[7,18]   physical_G_upper  1
    a[7,19]   R1285     1
    a[7,19]   R1286     1
    a[7,19]   true_G_epigraph  1
    a[7,19]   physical_G_upper  1
    a[7,20]   R1287     1
    a[7,20]   R1288     1
    a[7,20]   true_G_epigraph  1
    a[7,20]   physical_G_upper  1
    a[8,9]    R1289     1
    a[8,9]    R1290     1
    a[8,9]    true_G_epigraph  1
    a[8,9]    physical_G_upper  1
    a[8,10]   R1291     1
    a[8,10]   R1292     1
    a[8,10]   true_G_epigraph  1
    a[8,10]   physical_G_upper  1
    a[8,11]   R1293     1
    a[8,11]   R1294     1
    a[8,11]   true_G_epigraph  1
    a[8,11]   physical_G_upper  1
    a[8,12]   R1295     1
    a[8,12]   R1296     1
    a[8,12]   true_G_epigraph  1
    a[8,12]   physical_G_upper  1
    a[8,13]   R1297     1
    a[8,13]   R1298     1
    a[8,13]   true_G_epigraph  1
    a[8,13]   physical_G_upper  1
    a[8,14]   R1299     1
    a[8,14]   R1300     1
    a[8,14]   true_G_epigraph  1
    a[8,14]   physical_G_upper  1
    a[8,15]   R1301     1
    a[8,15]   R1302     1
    a[8,15]   true_G_epigraph  1
    a[8,15]   physical_G_upper  1
    a[8,16]   R1303     1
    a[8,16]   R1304     1
    a[8,16]   true_G_epigraph  1
    a[8,16]   physical_G_upper  1
    a[8,17]   R1305     1
    a[8,17]   R1306     1
    a[8,17]   true_G_epigraph  1
    a[8,17]   physical_G_upper  1
    a[8,18]   R1307     1
    a[8,18]   R1308     1
    a[8,18]   true_G_epigraph  1
    a[8,18]   physical_G_upper  1
    a[8,19]   R1309     1
    a[8,19]   R1310     1
    a[8,19]   true_G_epigraph  1
    a[8,19]   physical_G_upper  1
    a[8,20]   R1311     1
    a[8,20]   R1312     1
    a[8,20]   true_G_epigraph  1
    a[8,20]   physical_G_upper  1
    a[9,10]   R1313     1
    a[9,10]   R1314     1
    a[9,10]   true_G_epigraph  1
    a[9,10]   physical_G_upper  1
    a[9,11]   R1315     1
    a[9,11]   R1316     1
    a[9,11]   true_G_epigraph  1
    a[9,11]   physical_G_upper  1
    a[9,12]   R1317     1
    a[9,12]   R1318     1
    a[9,12]   true_G_epigraph  1
    a[9,12]   physical_G_upper  1
    a[9,13]   R1319     1
    a[9,13]   R1320     1
    a[9,13]   true_G_epigraph  1
    a[9,13]   physical_G_upper  1
    a[9,14]   R1321     1
    a[9,14]   R1322     1
    a[9,14]   true_G_epigraph  1
    a[9,14]   physical_G_upper  1
    a[9,15]   R1323     1
    a[9,15]   R1324     1
    a[9,15]   true_G_epigraph  1
    a[9,15]   physical_G_upper  1
    a[9,16]   R1325     1
    a[9,16]   R1326     1
    a[9,16]   true_G_epigraph  1
    a[9,16]   physical_G_upper  1
    a[9,17]   R1327     1
    a[9,17]   R1328     1
    a[9,17]   true_G_epigraph  1
    a[9,17]   physical_G_upper  1
    a[9,18]   R1329     1
    a[9,18]   R1330     1
    a[9,18]   true_G_epigraph  1
    a[9,18]   physical_G_upper  1
    a[9,19]   R1331     1
    a[9,19]   R1332     1
    a[9,19]   true_G_epigraph  1
    a[9,19]   physical_G_upper  1
    a[9,20]   R1333     1
    a[9,20]   R1334     1
    a[9,20]   true_G_epigraph  1
    a[9,20]   physical_G_upper  1
    a[10,11]  R1335     1
    a[10,11]  R1336     1
    a[10,11]  true_G_epigraph  1
    a[10,11]  physical_G_upper  1
    a[10,12]  R1337     1
    a[10,12]  R1338     1
    a[10,12]  true_G_epigraph  1
    a[10,12]  physical_G_upper  1
    a[10,13]  R1339     1
    a[10,13]  R1340     1
    a[10,13]  true_G_epigraph  1
    a[10,13]  physical_G_upper  1
    a[10,14]  R1341     1
    a[10,14]  R1342     1
    a[10,14]  true_G_epigraph  1
    a[10,14]  physical_G_upper  1
    a[10,15]  R1343     1
    a[10,15]  R1344     1
    a[10,15]  true_G_epigraph  1
    a[10,15]  physical_G_upper  1
    a[10,16]  R1345     1
    a[10,16]  R1346     1
    a[10,16]  true_G_epigraph  1
    a[10,16]  physical_G_upper  1
    a[10,17]  R1347     1
    a[10,17]  R1348     1
    a[10,17]  true_G_epigraph  1
    a[10,17]  physical_G_upper  1
    a[10,18]  R1349     1
    a[10,18]  R1350     1
    a[10,18]  true_G_epigraph  1
    a[10,18]  physical_G_upper  1
    a[10,19]  R1351     1
    a[10,19]  R1352     1
    a[10,19]  true_G_epigraph  1
    a[10,19]  physical_G_upper  1
    a[10,20]  R1353     1
    a[10,20]  R1354     1
    a[10,20]  true_G_epigraph  1
    a[10,20]  physical_G_upper  1
    a[11,12]  R1355     1
    a[11,12]  R1356     1
    a[11,12]  true_G_epigraph  1
    a[11,12]  physical_G_upper  1
    a[11,13]  R1357     1
    a[11,13]  R1358     1
    a[11,13]  true_G_epigraph  1
    a[11,13]  physical_G_upper  1
    a[11,14]  R1359     1
    a[11,14]  R1360     1
    a[11,14]  true_G_epigraph  1
    a[11,14]  physical_G_upper  1
    a[11,15]  R1361     1
    a[11,15]  R1362     1
    a[11,15]  true_G_epigraph  1
    a[11,15]  physical_G_upper  1
    a[11,16]  R1363     1
    a[11,16]  R1364     1
    a[11,16]  true_G_epigraph  1
    a[11,16]  physical_G_upper  1
    a[11,17]  R1365     1
    a[11,17]  R1366     1
    a[11,17]  true_G_epigraph  1
    a[11,17]  physical_G_upper  1
    a[11,18]  R1367     1
    a[11,18]  R1368     1
    a[11,18]  true_G_epigraph  1
    a[11,18]  physical_G_upper  1
    a[11,19]  R1369     1
    a[11,19]  R1370     1
    a[11,19]  true_G_epigraph  1
    a[11,19]  physical_G_upper  1
    a[11,20]  R1371     1
    a[11,20]  R1372     1
    a[11,20]  true_G_epigraph  1
    a[11,20]  physical_G_upper  1
    a[12,13]  R1373     1
    a[12,13]  R1374     1
    a[12,13]  true_G_epigraph  1
    a[12,13]  physical_G_upper  1
    a[12,14]  R1375     1
    a[12,14]  R1376     1
    a[12,14]  true_G_epigraph  1
    a[12,14]  physical_G_upper  1
    a[12,15]  R1377     1
    a[12,15]  R1378     1
    a[12,15]  true_G_epigraph  1
    a[12,15]  physical_G_upper  1
    a[12,16]  R1379     1
    a[12,16]  R1380     1
    a[12,16]  true_G_epigraph  1
    a[12,16]  physical_G_upper  1
    a[12,17]  R1381     1
    a[12,17]  R1382     1
    a[12,17]  true_G_epigraph  1
    a[12,17]  physical_G_upper  1
    a[12,18]  R1383     1
    a[12,18]  R1384     1
    a[12,18]  true_G_epigraph  1
    a[12,18]  physical_G_upper  1
    a[12,19]  R1385     1
    a[12,19]  R1386     1
    a[12,19]  true_G_epigraph  1
    a[12,19]  physical_G_upper  1
    a[12,20]  R1387     1
    a[12,20]  R1388     1
    a[12,20]  true_G_epigraph  1
    a[12,20]  physical_G_upper  1
    a[13,14]  R1389     1
    a[13,14]  R1390     1
    a[13,14]  true_G_epigraph  1
    a[13,14]  physical_G_upper  1
    a[13,15]  R1391     1
    a[13,15]  R1392     1
    a[13,15]  true_G_epigraph  1
    a[13,15]  physical_G_upper  1
    a[13,16]  R1393     1
    a[13,16]  R1394     1
    a[13,16]  true_G_epigraph  1
    a[13,16]  physical_G_upper  1
    a[13,17]  R1395     1
    a[13,17]  R1396     1
    a[13,17]  true_G_epigraph  1
    a[13,17]  physical_G_upper  1
    a[13,18]  R1397     1
    a[13,18]  R1398     1
    a[13,18]  true_G_epigraph  1
    a[13,18]  physical_G_upper  1
    a[13,19]  R1399     1
    a[13,19]  R1400     1
    a[13,19]  true_G_epigraph  1
    a[13,19]  physical_G_upper  1
    a[13,20]  R1401     1
    a[13,20]  R1402     1
    a[13,20]  true_G_epigraph  1
    a[13,20]  physical_G_upper  1
    a[14,15]  R1403     1
    a[14,15]  R1404     1
    a[14,15]  true_G_epigraph  1
    a[14,15]  physical_G_upper  1
    a[14,16]  R1405     1
    a[14,16]  R1406     1
    a[14,16]  true_G_epigraph  1
    a[14,16]  physical_G_upper  1
    a[14,17]  R1407     1
    a[14,17]  R1408     1
    a[14,17]  true_G_epigraph  1
    a[14,17]  physical_G_upper  1
    a[14,18]  R1409     1
    a[14,18]  R1410     1
    a[14,18]  true_G_epigraph  1
    a[14,18]  physical_G_upper  1
    a[14,19]  R1411     1
    a[14,19]  R1412     1
    a[14,19]  true_G_epigraph  1
    a[14,19]  physical_G_upper  1
    a[14,20]  R1413     1
    a[14,20]  R1414     1
    a[14,20]  true_G_epigraph  1
    a[14,20]  physical_G_upper  1
    a[15,16]  R1415     1
    a[15,16]  R1416     1
    a[15,16]  true_G_epigraph  1
    a[15,16]  physical_G_upper  1
    a[15,17]  R1417     1
    a[15,17]  R1418     1
    a[15,17]  true_G_epigraph  1
    a[15,17]  physical_G_upper  1
    a[15,18]  R1419     1
    a[15,18]  R1420     1
    a[15,18]  true_G_epigraph  1
    a[15,18]  physical_G_upper  1
    a[15,19]  R1421     1
    a[15,19]  R1422     1
    a[15,19]  true_G_epigraph  1
    a[15,19]  physical_G_upper  1
    a[15,20]  R1423     1
    a[15,20]  R1424     1
    a[15,20]  true_G_epigraph  1
    a[15,20]  physical_G_upper  1
    a[16,17]  R1425     1
    a[16,17]  R1426     1
    a[16,17]  true_G_epigraph  1
    a[16,17]  physical_G_upper  1
    a[16,18]  R1427     1
    a[16,18]  R1428     1
    a[16,18]  true_G_epigraph  1
    a[16,18]  physical_G_upper  1
    a[16,19]  R1429     1
    a[16,19]  R1430     1
    a[16,19]  true_G_epigraph  1
    a[16,19]  physical_G_upper  1
    a[16,20]  R1431     1
    a[16,20]  R1432     1
    a[16,20]  true_G_epigraph  1
    a[16,20]  physical_G_upper  1
    a[17,18]  R1433     1
    a[17,18]  R1434     1
    a[17,18]  true_G_epigraph  1
    a[17,18]  physical_G_upper  1
    a[17,19]  R1435     1
    a[17,19]  R1436     1
    a[17,19]  true_G_epigraph  1
    a[17,19]  physical_G_upper  1
    a[17,20]  R1437     1
    a[17,20]  R1438     1
    a[17,20]  true_G_epigraph  1
    a[17,20]  physical_G_upper  1
    a[18,19]  R1439     1
    a[18,19]  R1440     1
    a[18,19]  true_G_epigraph  1
    a[18,19]  physical_G_upper  1
    a[18,20]  R1441     1
    a[18,20]  R1442     1
    a[18,20]  true_G_epigraph  1
    a[18,20]  physical_G_upper  1
    a[19,20]  R1443     1
    a[19,20]  R1444     1
    a[19,20]  true_G_epigraph  1
    a[19,20]  physical_G_upper  1
    q         OBJ       1
    q         true_G_epigraph  -20
RHS
    RHS1      onehot_1  1
    RHS1      onehot_2  1
    RHS1      onehot_3  1
    RHS1      onehot_4  1
    RHS1      onehot_5  1
    RHS1      onehot_6  1
    RHS1      onehot_7  1
    RHS1      onehot_8  1
    RHS1      onehot_9  1
    RHS1      onehot_10  1
    RHS1      onehot_11  1
    RHS1      onehot_12  1
    RHS1      onehot_13  1
    RHS1      onehot_14  1
    RHS1      onehot_15  1
    RHS1      onehot_16  1
    RHS1      onehot_17  1
    RHS1      onehot_18  1
    RHS1      onehot_19  1
    RHS1      onehot_20  1
    RHS1      hard_lower  211
    RHS1      hard_upper  271
    RHS1      normalization  1
    RHS1      physical_G_upper  7.5953661356977875e+00
BOUNDS
 BV BND1      x[1,0]  
 BV BND1      x[1,1]  
 BV BND1      x[1,2]  
 BV BND1      x[1,3]  
 BV BND1      x[1,4]  
 BV BND1      x[1,5]  
 BV BND1      x[1,6]  
 BV BND1      x[1,7]  
 BV BND1      x[1,8]  
 BV BND1      x[1,9]  
 BV BND1      x[1,10] 
 BV BND1      x[1,11] 
 BV BND1      x[1,12] 
 BV BND1      x[1,13] 
 BV BND1      x[1,14] 
 BV BND1      x[1,15] 
 BV BND1      x[1,16] 
 BV BND1      x[1,17] 
 BV BND1      x[1,18] 
 BV BND1      x[1,19] 
 BV BND1      x[1,20] 
 BV BND1      x[1,21] 
 BV BND1      x[1,22] 
 BV BND1      x[1,23] 
 BV BND1      x[1,24] 
 BV BND1      x[2,0]  
 BV BND1      x[2,1]  
 BV BND1      x[2,2]  
 BV BND1      x[2,3]  
 BV BND1      x[2,4]  
 BV BND1      x[2,5]  
 BV BND1      x[2,6]  
 BV BND1      x[2,7]  
 BV BND1      x[2,8]  
 BV BND1      x[2,9]  
 BV BND1      x[2,10] 
 BV BND1      x[2,11] 
 BV BND1      x[2,12] 
 BV BND1      x[2,13] 
 BV BND1      x[2,14] 
 BV BND1      x[2,15] 
 BV BND1      x[2,16] 
 BV BND1      x[2,17] 
 BV BND1      x[2,18] 
 BV BND1      x[2,19] 
 BV BND1      x[2,20] 
 BV BND1      x[2,21] 
 BV BND1      x[2,22] 
 BV BND1      x[2,23] 
 BV BND1      x[2,24] 
 BV BND1      x[2,25] 
 BV BND1      x[3,0]  
 BV BND1      x[3,1]  
 BV BND1      x[3,2]  
 BV BND1      x[3,3]  
 BV BND1      x[3,4]  
 BV BND1      x[3,5]  
 BV BND1      x[3,6]  
 BV BND1      x[3,7]  
 BV BND1      x[3,8]  
 BV BND1      x[3,9]  
 BV BND1      x[3,10] 
 BV BND1      x[3,11] 
 BV BND1      x[3,12] 
 BV BND1      x[3,13] 
 BV BND1      x[3,14] 
 BV BND1      x[3,15] 
 BV BND1      x[3,16] 
 BV BND1      x[3,17] 
 BV BND1      x[3,18] 
 BV BND1      x[3,19] 
 BV BND1      x[3,20] 
 BV BND1      x[3,21] 
 BV BND1      x[3,22] 
 BV BND1      x[3,23] 
 BV BND1      x[3,24] 
 BV BND1      x[3,25] 
 BV BND1      x[3,26] 
 BV BND1      x[3,27] 
 BV BND1      x[4,0]  
 BV BND1      x[4,1]  
 BV BND1      x[4,2]  
 BV BND1      x[4,3]  
 BV BND1      x[4,4]  
 BV BND1      x[4,5]  
 BV BND1      x[4,6]  
 BV BND1      x[4,7]  
 BV BND1      x[4,8]  
 BV BND1      x[4,9]  
 BV BND1      x[4,10] 
 BV BND1      x[4,11] 
 BV BND1      x[4,12] 
 BV BND1      x[4,13] 
 BV BND1      x[4,14] 
 BV BND1      x[4,15] 
 BV BND1      x[4,16] 
 BV BND1      x[4,17] 
 BV BND1      x[4,18] 
 BV BND1      x[4,19] 
 BV BND1      x[4,20] 
 BV BND1      x[4,21] 
 BV BND1      x[4,22] 
 BV BND1      x[4,23] 
 BV BND1      x[4,24] 
 BV BND1      x[5,0]  
 BV BND1      x[5,1]  
 BV BND1      x[5,2]  
 BV BND1      x[5,3]  
 BV BND1      x[5,4]  
 BV BND1      x[5,5]  
 BV BND1      x[5,6]  
 BV BND1      x[5,7]  
 BV BND1      x[5,8]  
 BV BND1      x[5,9]  
 BV BND1      x[5,10] 
 BV BND1      x[5,11] 
 BV BND1      x[5,12] 
 BV BND1      x[5,13] 
 BV BND1      x[5,14] 
 BV BND1      x[5,15] 
 BV BND1      x[5,16] 
 BV BND1      x[5,17] 
 BV BND1      x[5,18] 
 BV BND1      x[5,19] 
 BV BND1      x[5,20] 
 BV BND1      x[5,21] 
 BV BND1      x[6,0]  
 BV BND1      x[6,1]  
 BV BND1      x[6,2]  
 BV BND1      x[6,3]  
 BV BND1      x[6,4]  
 BV BND1      x[6,5]  
 BV BND1      x[6,6]  
 BV BND1      x[6,7]  
 BV BND1      x[6,8]  
 BV BND1      x[6,9]  
 BV BND1      x[6,10] 
 BV BND1      x[6,11] 
 BV BND1      x[6,12] 
 BV BND1      x[6,13] 
 BV BND1      x[6,14] 
 BV BND1      x[6,15] 
 BV BND1      x[6,16] 
 BV BND1      x[6,17] 
 BV BND1      x[6,18] 
 BV BND1      x[6,19] 
 BV BND1      x[6,20] 
 BV BND1      x[6,21] 
 BV BND1      x[6,22] 
 BV BND1      x[6,23] 
 BV BND1      x[6,24] 
 BV BND1      x[7,0]  
 BV BND1      x[7,1]  
 BV BND1      x[7,2]  
 BV BND1      x[7,3]  
 BV BND1      x[7,4]  
 BV BND1      x[7,5]  
 BV BND1      x[7,6]  
 BV BND1      x[7,7]  
 BV BND1      x[7,8]  
 BV BND1      x[7,9]  
 BV BND1      x[7,10] 
 BV BND1      x[7,11] 
 BV BND1      x[7,12] 
 BV BND1      x[7,13] 
 BV BND1      x[7,14] 
 BV BND1      x[7,15] 
 BV BND1      x[7,16] 
 BV BND1      x[7,17] 
 BV BND1      x[7,18] 
 BV BND1      x[7,19] 
 BV BND1      x[7,20] 
 BV BND1      x[7,21] 
 BV BND1      x[7,22] 
 BV BND1      x[8,0]  
 BV BND1      x[8,1]  
 BV BND1      x[8,2]  
 BV BND1      x[8,3]  
 BV BND1      x[8,4]  
 BV BND1      x[8,5]  
 BV BND1      x[8,6]  
 BV BND1      x[8,7]  
 BV BND1      x[8,8]  
 BV BND1      x[8,9]  
 BV BND1      x[8,10] 
 BV BND1      x[8,11] 
 BV BND1      x[8,12] 
 BV BND1      x[8,13] 
 BV BND1      x[8,14] 
 BV BND1      x[8,15] 
 BV BND1      x[8,16] 
 BV BND1      x[8,17] 
 BV BND1      x[8,18] 
 BV BND1      x[8,19] 
 BV BND1      x[8,20] 
 BV BND1      x[8,21] 
 BV BND1      x[9,0]  
 BV BND1      x[9,1]  
 BV BND1      x[9,2]  
 BV BND1      x[9,3]  
 BV BND1      x[9,4]  
 BV BND1      x[9,5]  
 BV BND1      x[9,6]  
 BV BND1      x[9,7]  
 BV BND1      x[9,8]  
 BV BND1      x[9,9]  
 BV BND1      x[9,10] 
 BV BND1      x[9,11] 
 BV BND1      x[9,12] 
 BV BND1      x[9,13] 
 BV BND1      x[9,14] 
 BV BND1      x[9,15] 
 BV BND1      x[9,16] 
 BV BND1      x[9,17] 
 BV BND1      x[9,18] 
 BV BND1      x[9,19] 
 BV BND1      x[10,0] 
 BV BND1      x[10,1] 
 BV BND1      x[10,2] 
 BV BND1      x[10,3] 
 BV BND1      x[10,4] 
 BV BND1      x[10,5] 
 BV BND1      x[10,6] 
 BV BND1      x[10,7] 
 BV BND1      x[10,8] 
 BV BND1      x[10,9] 
 BV BND1      x[10,10]
 BV BND1      x[10,11]
 BV BND1      x[10,12]
 BV BND1      x[10,13]
 BV BND1      x[10,14]
 BV BND1      x[10,15]
 BV BND1      x[10,16]
 BV BND1      x[10,17]
 BV BND1      x[10,18]
 BV BND1      x[10,19]
 BV BND1      x[10,20]
 BV BND1      x[10,21]
 BV BND1      x[10,22]
 BV BND1      x[10,23]
 BV BND1      x[10,24]
 BV BND1      x[10,25]
 BV BND1      x[10,26]
 BV BND1      x[10,27]
 BV BND1      x[10,28]
 BV BND1      x[10,29]
 BV BND1      x[11,0] 
 BV BND1      x[11,1] 
 BV BND1      x[11,2] 
 BV BND1      x[11,3] 
 BV BND1      x[11,4] 
 BV BND1      x[11,5] 
 BV BND1      x[11,6] 
 BV BND1      x[11,7] 
 BV BND1      x[11,8] 
 BV BND1      x[11,9] 
 BV BND1      x[11,10]
 BV BND1      x[11,11]
 BV BND1      x[11,12]
 BV BND1      x[11,13]
 BV BND1      x[11,14]
 BV BND1      x[11,15]
 BV BND1      x[11,16]
 BV BND1      x[11,17]
 BV BND1      x[11,18]
 BV BND1      x[11,19]
 BV BND1      x[11,20]
 BV BND1      x[11,21]
 BV BND1      x[11,22]
 BV BND1      x[11,23]
 BV BND1      x[11,24]
 BV BND1      x[11,25]
 BV BND1      x[11,26]
 BV BND1      x[11,27]
 BV BND1      x[11,28]
 BV BND1      x[11,29]
 BV BND1      x[11,30]
 BV BND1      x[11,31]
 BV BND1      x[12,0] 
 BV BND1      x[12,1] 
 BV BND1      x[12,2] 
 BV BND1      x[12,3] 
 BV BND1      x[12,4] 
 BV BND1      x[12,5] 
 BV BND1      x[12,6] 
 BV BND1      x[12,7] 
 BV BND1      x[12,8] 
 BV BND1      x[12,9] 
 BV BND1      x[12,10]
 BV BND1      x[12,11]
 BV BND1      x[12,12]
 BV BND1      x[12,13]
 BV BND1      x[12,14]
 BV BND1      x[12,15]
 BV BND1      x[12,16]
 BV BND1      x[12,17]
 BV BND1      x[12,18]
 BV BND1      x[12,19]
 BV BND1      x[13,0] 
 BV BND1      x[13,1] 
 BV BND1      x[13,2] 
 BV BND1      x[13,3] 
 BV BND1      x[13,4] 
 BV BND1      x[13,5] 
 BV BND1      x[13,6] 
 BV BND1      x[13,7] 
 BV BND1      x[13,8] 
 BV BND1      x[13,9] 
 BV BND1      x[13,10]
 BV BND1      x[13,11]
 BV BND1      x[13,12]
 BV BND1      x[13,13]
 BV BND1      x[13,14]
 BV BND1      x[13,15]
 BV BND1      x[13,16]
 BV BND1      x[13,17]
 BV BND1      x[13,18]
 BV BND1      x[13,19]
 BV BND1      x[13,20]
 BV BND1      x[13,21]
 BV BND1      x[13,22]
 BV BND1      x[13,23]
 BV BND1      x[13,24]
 BV BND1      x[13,25]
 BV BND1      x[14,0] 
 BV BND1      x[14,1] 
 BV BND1      x[14,2] 
 BV BND1      x[14,3] 
 BV BND1      x[14,4] 
 BV BND1      x[14,5] 
 BV BND1      x[14,6] 
 BV BND1      x[14,7] 
 BV BND1      x[14,8] 
 BV BND1      x[14,9] 
 BV BND1      x[14,10]
 BV BND1      x[14,11]
 BV BND1      x[14,12]
 BV BND1      x[14,13]
 BV BND1      x[14,14]
 BV BND1      x[14,15]
 BV BND1      x[14,16]
 BV BND1      x[14,17]
 BV BND1      x[14,18]
 BV BND1      x[14,19]
 BV BND1      x[14,20]
 BV BND1      x[14,21]
 BV BND1      x[14,22]
 BV BND1      x[14,23]
 BV BND1      x[15,0] 
 BV BND1      x[15,1] 
 BV BND1      x[15,2] 
 BV BND1      x[15,3] 
 BV BND1      x[15,4] 
 BV BND1      x[15,5] 
 BV BND1      x[15,6] 
 BV BND1      x[15,7] 
 BV BND1      x[15,8] 
 BV BND1      x[15,9] 
 BV BND1      x[15,10]
 BV BND1      x[15,11]
 BV BND1      x[15,12]
 BV BND1      x[15,13]
 BV BND1      x[15,14]
 BV BND1      x[15,15]
 BV BND1      x[15,16]
 BV BND1      x[15,17]
 BV BND1      x[15,18]
 BV BND1      x[15,19]
 BV BND1      x[15,20]
 BV BND1      x[15,21]
 BV BND1      x[15,22]
 BV BND1      x[15,23]
 BV BND1      x[15,24]
 BV BND1      x[15,25]
 BV BND1      x[15,26]
 BV BND1      x[15,27]
 BV BND1      x[16,0] 
 BV BND1      x[16,1] 
 BV BND1      x[16,2] 
 BV BND1      x[16,3] 
 BV BND1      x[16,4] 
 BV BND1      x[16,5] 
 BV BND1      x[16,6] 
 BV BND1      x[16,7] 
 BV BND1      x[16,8] 
 BV BND1      x[16,9] 
 BV BND1      x[16,10]
 BV BND1      x[16,11]
 BV BND1      x[16,12]
 BV BND1      x[16,13]
 BV BND1      x[16,14]
 BV BND1      x[16,15]
 BV BND1      x[16,16]
 BV BND1      x[16,17]
 BV BND1      x[16,18]
 BV BND1      x[16,19]
 BV BND1      x[16,20]
 BV BND1      x[16,21]
 BV BND1      x[16,22]
 BV BND1      x[17,0] 
 BV BND1      x[17,1] 
 BV BND1      x[17,2] 
 BV BND1      x[17,3] 
 BV BND1      x[17,4] 
 BV BND1      x[17,5] 
 BV BND1      x[17,6] 
 BV BND1      x[17,7] 
 BV BND1      x[17,8] 
 BV BND1      x[17,9] 
 BV BND1      x[17,10]
 BV BND1      x[17,11]
 BV BND1      x[17,12]
 BV BND1      x[17,13]
 BV BND1      x[17,14]
 BV BND1      x[17,15]
 BV BND1      x[17,16]
 BV BND1      x[17,17]
 BV BND1      x[17,18]
 BV BND1      x[17,19]
 BV BND1      x[18,0] 
 BV BND1      x[18,1] 
 BV BND1      x[18,2] 
 BV BND1      x[18,3] 
 BV BND1      x[18,4] 
 BV BND1      x[18,5] 
 BV BND1      x[18,6] 
 BV BND1      x[18,7] 
 BV BND1      x[18,8] 
 BV BND1      x[18,9] 
 BV BND1      x[18,10]
 BV BND1      x[18,11]
 BV BND1      x[18,12]
 BV BND1      x[18,13]
 BV BND1      x[18,14]
 BV BND1      x[18,15]
 BV BND1      x[18,16]
 BV BND1      x[18,17]
 BV BND1      x[18,18]
 BV BND1      x[18,19]
 BV BND1      x[18,20]
 BV BND1      x[18,21]
 BV BND1      x[18,22]
 BV BND1      x[19,0] 
 BV BND1      x[19,1] 
 BV BND1      x[19,2] 
 BV BND1      x[19,3] 
 BV BND1      x[19,4] 
 BV BND1      x[19,5] 
 BV BND1      x[19,6] 
 BV BND1      x[19,7] 
 BV BND1      x[19,8] 
 BV BND1      x[19,9] 
 BV BND1      x[19,10]
 BV BND1      x[19,11]
 BV BND1      x[19,12]
 BV BND1      x[19,13]
 BV BND1      x[19,14]
 BV BND1      x[19,15]
 BV BND1      x[19,16]
 BV BND1      x[19,17]
 BV BND1      x[19,18]
 BV BND1      x[19,19]
 BV BND1      x[19,20]
 BV BND1      x[19,21]
 BV BND1      x[19,22]
 BV BND1      x[19,23]
 BV BND1      x[20,0] 
 BV BND1      x[20,1] 
 BV BND1      x[20,2] 
 BV BND1      x[20,3] 
 BV BND1      x[20,4] 
 BV BND1      x[20,5] 
 BV BND1      x[20,6] 
 BV BND1      x[20,7] 
 BV BND1      x[20,8] 
 BV BND1      x[20,9] 
 BV BND1      x[20,10]
 BV BND1      x[20,11]
 BV BND1      x[20,12]
 BV BND1      x[20,13]
 BV BND1      x[20,14]
 BV BND1      x[20,15]
 BV BND1      x[20,16]
 BV BND1      x[20,17]
 BV BND1      x[20,18]
 BV BND1      x[20,19]
 BV BND1      x[20,20]
 BV BND1      x[20,21]
 BV BND1      x[20,22]
 BV BND1      x[20,23]
 UP BND1      w[1,0]    0.0680494916724233
 UP BND1      w[1,1]    0.0680494916724233
 UP BND1      w[1,2]    0.0680494916724233
 UP BND1      w[1,3]    0.0680494916724233
 UP BND1      w[1,4]    0.0680494916724233
 UP BND1      w[1,5]    0.0680494916724233
 UP BND1      w[1,6]    0.0680494916724233
 UP BND1      w[1,7]    0.0680494916724233
 UP BND1      w[1,8]    0.0680494916724233
 UP BND1      w[1,9]    0.0680494916724233
 UP BND1      w[1,10]   0.0680494916724233
 UP BND1      w[1,11]   0.0680494916724233
 UP BND1      w[1,12]   0.0680494916724233
 UP BND1      w[1,13]   0.0680494916724233
 UP BND1      w[1,14]   0.0680494916724233
 UP BND1      w[1,15]   0.0680494916724233
 UP BND1      w[1,16]   0.0680494916724233
 UP BND1      w[1,17]   0.0680494916724233
 UP BND1      w[1,18]   0.0680494916724233
 UP BND1      w[1,19]   0.0680494916724233
 UP BND1      w[1,20]   0.0680494916724233
 UP BND1      w[1,21]   0.0680494916724233
 UP BND1      w[1,22]   0.0680494916724233
 UP BND1      w[1,23]   0.0680494916724233
 UP BND1      w[1,24]   0.0680494916724233
 UP BND1      w[2,0]    0.0680494916724233
 UP BND1      w[2,1]    0.0680494916724233
 UP BND1      w[2,2]    0.0680494916724233
 UP BND1      w[2,3]    0.0680494916724233
 UP BND1      w[2,4]    0.0680494916724233
 UP BND1      w[2,5]    0.0680494916724233
 UP BND1      w[2,6]    0.0680494916724233
 UP BND1      w[2,7]    0.0680494916724233
 UP BND1      w[2,8]    0.0680494916724233
 UP BND1      w[2,9]    0.0680494916724233
 UP BND1      w[2,10]   0.0680494916724233
 UP BND1      w[2,11]   0.0680494916724233
 UP BND1      w[2,12]   0.0680494916724233
 UP BND1      w[2,13]   0.0680494916724233
 UP BND1      w[2,14]   0.0680494916724233
 UP BND1      w[2,15]   0.0680494916724233
 UP BND1      w[2,16]   0.0680494916724233
 UP BND1      w[2,17]   0.0680494916724233
 UP BND1      w[2,18]   0.0680494916724233
 UP BND1      w[2,19]   0.0680494916724233
 UP BND1      w[2,20]   0.0680494916724233
 UP BND1      w[2,21]   0.0680494916724233
 UP BND1      w[2,22]   0.0680494916724233
 UP BND1      w[2,23]   0.0680494916724233
 UP BND1      w[2,24]   0.0680494916724233
 UP BND1      w[2,25]   0.0680494916724233
 UP BND1      w[3,0]    0.0680494916724233
 UP BND1      w[3,1]    0.0680494916724233
 UP BND1      w[3,2]    0.0680494916724233
 UP BND1      w[3,3]    0.0680494916724233
 UP BND1      w[3,4]    0.0680494916724233
 UP BND1      w[3,5]    0.0680494916724233
 UP BND1      w[3,6]    0.0680494916724233
 UP BND1      w[3,7]    0.0680494916724233
 UP BND1      w[3,8]    0.0680494916724233
 UP BND1      w[3,9]    0.0680494916724233
 UP BND1      w[3,10]   0.0680494916724233
 UP BND1      w[3,11]   0.0680494916724233
 UP BND1      w[3,12]   0.0680494916724233
 UP BND1      w[3,13]   0.0680494916724233
 UP BND1      w[3,14]   0.0680494916724233
 UP BND1      w[3,15]   0.0680494916724233
 UP BND1      w[3,16]   0.0680494916724233
 UP BND1      w[3,17]   0.0680494916724233
 UP BND1      w[3,18]   0.0680494916724233
 UP BND1      w[3,19]   0.0680494916724233
 UP BND1      w[3,20]   0.0680494916724233
 UP BND1      w[3,21]   0.0680494916724233
 UP BND1      w[3,22]   0.0680494916724233
 UP BND1      w[3,23]   0.0680494916724233
 UP BND1      w[3,24]   0.0680494916724233
 UP BND1      w[3,25]   0.0680494916724233
 UP BND1      w[3,26]   0.0680494916724233
 UP BND1      w[3,27]   0.0680494916724233
 UP BND1      w[4,0]    0.0680494916724233
 UP BND1      w[4,1]    0.0680494916724233
 UP BND1      w[4,2]    0.0680494916724233
 UP BND1      w[4,3]    0.0680494916724233
 UP BND1      w[4,4]    0.0680494916724233
 UP BND1      w[4,5]    0.0680494916724233
 UP BND1      w[4,6]    0.0680494916724233
 UP BND1      w[4,7]    0.0680494916724233
 UP BND1      w[4,8]    0.0680494916724233
 UP BND1      w[4,9]    0.0680494916724233
 UP BND1      w[4,10]   0.0680494916724233
 UP BND1      w[4,11]   0.0680494916724233
 UP BND1      w[4,12]   0.0680494916724233
 UP BND1      w[4,13]   0.0680494916724233
 UP BND1      w[4,14]   0.0680494916724233
 UP BND1      w[4,15]   0.0680494916724233
 UP BND1      w[4,16]   0.0680494916724233
 UP BND1      w[4,17]   0.0680494916724233
 UP BND1      w[4,18]   0.0680494916724233
 UP BND1      w[4,19]   0.0680494916724233
 UP BND1      w[4,20]   0.0680494916724233
 UP BND1      w[4,21]   0.0680494916724233
 UP BND1      w[4,22]   0.0680494916724233
 UP BND1      w[4,23]   0.0680494916724233
 UP BND1      w[4,24]   0.0680494916724233
 UP BND1      w[5,0]    0.0680494916724233
 UP BND1      w[5,1]    0.0680494916724233
 UP BND1      w[5,2]    0.0680494916724233
 UP BND1      w[5,3]    0.0680494916724233
 UP BND1      w[5,4]    0.0680494916724233
 UP BND1      w[5,5]    0.0680494916724233
 UP BND1      w[5,6]    0.0680494916724233
 UP BND1      w[5,7]    0.0680494916724233
 UP BND1      w[5,8]    0.0680494916724233
 UP BND1      w[5,9]    0.0680494916724233
 UP BND1      w[5,10]   0.0680494916724233
 UP BND1      w[5,11]   0.0680494916724233
 UP BND1      w[5,12]   0.0680494916724233
 UP BND1      w[5,13]   0.0680494916724233
 UP BND1      w[5,14]   0.0680494916724233
 UP BND1      w[5,15]   0.0680494916724233
 UP BND1      w[5,16]   0.0680494916724233
 UP BND1      w[5,17]   0.0680494916724233
 UP BND1      w[5,18]   0.0680494916724233
 UP BND1      w[5,19]   0.0680494916724233
 UP BND1      w[5,20]   0.0680494916724233
 UP BND1      w[5,21]   0.0680494916724233
 UP BND1      w[6,0]    0.0680494916724233
 UP BND1      w[6,1]    0.0680494916724233
 UP BND1      w[6,2]    0.0680494916724233
 UP BND1      w[6,3]    0.0680494916724233
 UP BND1      w[6,4]    0.0680494916724233
 UP BND1      w[6,5]    0.0680494916724233
 UP BND1      w[6,6]    0.0680494916724233
 UP BND1      w[6,7]    0.0680494916724233
 UP BND1      w[6,8]    0.0680494916724233
 UP BND1      w[6,9]    0.0680494916724233
 UP BND1      w[6,10]   0.0680494916724233
 UP BND1      w[6,11]   0.0680494916724233
 UP BND1      w[6,12]   0.0680494916724233
 UP BND1      w[6,13]   0.0680494916724233
 UP BND1      w[6,14]   0.0680494916724233
 UP BND1      w[6,15]   0.0680494916724233
 UP BND1      w[6,16]   0.0680494916724233
 UP BND1      w[6,17]   0.0680494916724233
 UP BND1      w[6,18]   0.0680494916724233
 UP BND1      w[6,19]   0.0680494916724233
 UP BND1      w[6,20]   0.0680494916724233
 UP BND1      w[6,21]   0.0680494916724233
 UP BND1      w[6,22]   0.0680494916724233
 UP BND1      w[6,23]   0.0680494916724233
 UP BND1      w[6,24]   0.0680494916724233
 UP BND1      w[7,0]    0.0680494916724233
 UP BND1      w[7,1]    0.0680494916724233
 UP BND1      w[7,2]    0.0680494916724233
 UP BND1      w[7,3]    0.0680494916724233
 UP BND1      w[7,4]    0.0680494916724233
 UP BND1      w[7,5]    0.0680494916724233
 UP BND1      w[7,6]    0.0680494916724233
 UP BND1      w[7,7]    0.0680494916724233
 UP BND1      w[7,8]    0.0680494916724233
 UP BND1      w[7,9]    0.0680494916724233
 UP BND1      w[7,10]   0.0680494916724233
 UP BND1      w[7,11]   0.0680494916724233
 UP BND1      w[7,12]   0.0680494916724233
 UP BND1      w[7,13]   0.0680494916724233
 UP BND1      w[7,14]   0.0680494916724233
 UP BND1      w[7,15]   0.0680494916724233
 UP BND1      w[7,16]   0.0680494916724233
 UP BND1      w[7,17]   0.0680494916724233
 UP BND1      w[7,18]   0.0680494916724233
 UP BND1      w[7,19]   0.0680494916724233
 UP BND1      w[7,20]   0.0680494916724233
 UP BND1      w[7,21]   0.0680494916724233
 UP BND1      w[7,22]   0.0680494916724233
 UP BND1      w[8,0]    0.0680494916724233
 UP BND1      w[8,1]    0.0680494916724233
 UP BND1      w[8,2]    0.0680494916724233
 UP BND1      w[8,3]    0.0680494916724233
 UP BND1      w[8,4]    0.0680494916724233
 UP BND1      w[8,5]    0.0680494916724233
 UP BND1      w[8,6]    0.0680494916724233
 UP BND1      w[8,7]    0.0680494916724233
 UP BND1      w[8,8]    0.0680494916724233
 UP BND1      w[8,9]    0.0680494916724233
 UP BND1      w[8,10]   0.0680494916724233
 UP BND1      w[8,11]   0.0680494916724233
 UP BND1      w[8,12]   0.0680494916724233
 UP BND1      w[8,13]   0.0680494916724233
 UP BND1      w[8,14]   0.0680494916724233
 UP BND1      w[8,15]   0.0680494916724233
 UP BND1      w[8,16]   0.0680494916724233
 UP BND1      w[8,17]   0.0680494916724233
 UP BND1      w[8,18]   0.0680494916724233
 UP BND1      w[8,19]   0.0680494916724233
 UP BND1      w[8,20]   0.0680494916724233
 UP BND1      w[8,21]   0.0680494916724233
 UP BND1      w[9,0]    0.0680494916724233
 UP BND1      w[9,1]    0.0680494916724233
 UP BND1      w[9,2]    0.0680494916724233
 UP BND1      w[9,3]    0.0680494916724233
 UP BND1      w[9,4]    0.0680494916724233
 UP BND1      w[9,5]    0.0680494916724233
 UP BND1      w[9,6]    0.0680494916724233
 UP BND1      w[9,7]    0.0680494916724233
 UP BND1      w[9,8]    0.0680494916724233
 UP BND1      w[9,9]    0.0680494916724233
 UP BND1      w[9,10]   0.0680494916724233
 UP BND1      w[9,11]   0.0680494916724233
 UP BND1      w[9,12]   0.0680494916724233
 UP BND1      w[9,13]   0.0680494916724233
 UP BND1      w[9,14]   0.0680494916724233
 UP BND1      w[9,15]   0.0680494916724233
 UP BND1      w[9,16]   0.0680494916724233
 UP BND1      w[9,17]   0.0680494916724233
 UP BND1      w[9,18]   0.0680494916724233
 UP BND1      w[9,19]   0.0680494916724233
 UP BND1      w[10,0]   0.0680494916724233
 UP BND1      w[10,1]   0.0680494916724233
 UP BND1      w[10,2]   0.0680494916724233
 UP BND1      w[10,3]   0.0680494916724233
 UP BND1      w[10,4]   0.0680494916724233
 UP BND1      w[10,5]   0.0680494916724233
 UP BND1      w[10,6]   0.0680494916724233
 UP BND1      w[10,7]   0.0680494916724233
 UP BND1      w[10,8]   0.0680494916724233
 UP BND1      w[10,9]   0.0680494916724233
 UP BND1      w[10,10]  0.0680494916724233
 UP BND1      w[10,11]  0.0680494916724233
 UP BND1      w[10,12]  0.0680494916724233
 UP BND1      w[10,13]  0.0680494916724233
 UP BND1      w[10,14]  0.0680494916724233
 UP BND1      w[10,15]  0.0680494916724233
 UP BND1      w[10,16]  0.0680494916724233
 UP BND1      w[10,17]  0.0680494916724233
 UP BND1      w[10,18]  0.0680494916724233
 UP BND1      w[10,19]  0.0680494916724233
 UP BND1      w[10,20]  0.0680494916724233
 UP BND1      w[10,21]  0.0680494916724233
 UP BND1      w[10,22]  0.0680494916724233
 UP BND1      w[10,23]  0.0680494916724233
 UP BND1      w[10,24]  0.0680494916724233
 UP BND1      w[10,25]  0.0680494916724233
 UP BND1      w[10,26]  0.0680494916724233
 UP BND1      w[10,27]  0.0680494916724233
 UP BND1      w[10,28]  0.0680494916724233
 UP BND1      w[10,29]  0.0680494916724233
 UP BND1      w[11,0]   0.0680494916724233
 UP BND1      w[11,1]   0.0680494916724233
 UP BND1      w[11,2]   0.0680494916724233
 UP BND1      w[11,3]   0.0680494916724233
 UP BND1      w[11,4]   0.0680494916724233
 UP BND1      w[11,5]   0.0680494916724233
 UP BND1      w[11,6]   0.0680494916724233
 UP BND1      w[11,7]   0.0680494916724233
 UP BND1      w[11,8]   0.0680494916724233
 UP BND1      w[11,9]   0.0680494916724233
 UP BND1      w[11,10]  0.0680494916724233
 UP BND1      w[11,11]  0.0680494916724233
 UP BND1      w[11,12]  0.0680494916724233
 UP BND1      w[11,13]  0.0680494916724233
 UP BND1      w[11,14]  0.0680494916724233
 UP BND1      w[11,15]  0.0680494916724233
 UP BND1      w[11,16]  0.0680494916724233
 UP BND1      w[11,17]  0.0680494916724233
 UP BND1      w[11,18]  0.0680494916724233
 UP BND1      w[11,19]  0.0680494916724233
 UP BND1      w[11,20]  0.0680494916724233
 UP BND1      w[11,21]  0.0680494916724233
 UP BND1      w[11,22]  0.0680494916724233
 UP BND1      w[11,23]  0.0680494916724233
 UP BND1      w[11,24]  0.0680494916724233
 UP BND1      w[11,25]  0.0680494916724233
 UP BND1      w[11,26]  0.0680494916724233
 UP BND1      w[11,27]  0.0680494916724233
 UP BND1      w[11,28]  0.0680494916724233
 UP BND1      w[11,29]  0.0680494916724233
 UP BND1      w[11,30]  0.0680494916724233
 UP BND1      w[11,31]  0.0680494916724233
 UP BND1      w[12,0]   0.0680494916724233
 UP BND1      w[12,1]   0.0680494916724233
 UP BND1      w[12,2]   0.0680494916724233
 UP BND1      w[12,3]   0.0680494916724233
 UP BND1      w[12,4]   0.0680494916724233
 UP BND1      w[12,5]   0.0680494916724233
 UP BND1      w[12,6]   0.0680494916724233
 UP BND1      w[12,7]   0.0680494916724233
 UP BND1      w[12,8]   0.0680494916724233
 UP BND1      w[12,9]   0.0680494916724233
 UP BND1      w[12,10]  0.0680494916724233
 UP BND1      w[12,11]  0.0680494916724233
 UP BND1      w[12,12]  0.0680494916724233
 UP BND1      w[12,13]  0.0680494916724233
 UP BND1      w[12,14]  0.0680494916724233
 UP BND1      w[12,15]  0.0680494916724233
 UP BND1      w[12,16]  0.0680494916724233
 UP BND1      w[12,17]  0.0680494916724233
 UP BND1      w[12,18]  0.0680494916724233
 UP BND1      w[12,19]  0.0680494916724233
 UP BND1      w[13,0]   0.0680494916724233
 UP BND1      w[13,1]   0.0680494916724233
 UP BND1      w[13,2]   0.0680494916724233
 UP BND1      w[13,3]   0.0680494916724233
 UP BND1      w[13,4]   0.0680494916724233
 UP BND1      w[13,5]   0.0680494916724233
 UP BND1      w[13,6]   0.0680494916724233
 UP BND1      w[13,7]   0.0680494916724233
 UP BND1      w[13,8]   0.0680494916724233
 UP BND1      w[13,9]   0.0680494916724233
 UP BND1      w[13,10]  0.0680494916724233
 UP BND1      w[13,11]  0.0680494916724233
 UP BND1      w[13,12]  0.0680494916724233
 UP BND1      w[13,13]  0.0680494916724233
 UP BND1      w[13,14]  0.0680494916724233
 UP BND1      w[13,15]  0.0680494916724233
 UP BND1      w[13,16]  0.0680494916724233
 UP BND1      w[13,17]  0.0680494916724233
 UP BND1      w[13,18]  0.0680494916724233
 UP BND1      w[13,19]  0.0680494916724233
 UP BND1      w[13,20]  0.0680494916724233
 UP BND1      w[13,21]  0.0680494916724233
 UP BND1      w[13,22]  0.0680494916724233
 UP BND1      w[13,23]  0.0680494916724233
 UP BND1      w[13,24]  0.0680494916724233
 UP BND1      w[13,25]  0.0680494916724233
 UP BND1      w[14,0]   0.0680494916724233
 UP BND1      w[14,1]   0.0680494916724233
 UP BND1      w[14,2]   0.0680494916724233
 UP BND1      w[14,3]   0.0680494916724233
 UP BND1      w[14,4]   0.0680494916724233
 UP BND1      w[14,5]   0.0680494916724233
 UP BND1      w[14,6]   0.0680494916724233
 UP BND1      w[14,7]   0.0680494916724233
 UP BND1      w[14,8]   0.0680494916724233
 UP BND1      w[14,9]   0.0680494916724233
 UP BND1      w[14,10]  0.0680494916724233
 UP BND1      w[14,11]  0.0680494916724233
 UP BND1      w[14,12]  0.0680494916724233
 UP BND1      w[14,13]  0.0680494916724233
 UP BND1      w[14,14]  0.0680494916724233
 UP BND1      w[14,15]  0.0680494916724233
 UP BND1      w[14,16]  0.0680494916724233
 UP BND1      w[14,17]  0.0680494916724233
 UP BND1      w[14,18]  0.0680494916724233
 UP BND1      w[14,19]  0.0680494916724233
 UP BND1      w[14,20]  0.0680494916724233
 UP BND1      w[14,21]  0.0680494916724233
 UP BND1      w[14,22]  0.0680494916724233
 UP BND1      w[14,23]  0.0680494916724233
 UP BND1      w[15,0]   0.0680494916724233
 UP BND1      w[15,1]   0.0680494916724233
 UP BND1      w[15,2]   0.0680494916724233
 UP BND1      w[15,3]   0.0680494916724233
 UP BND1      w[15,4]   0.0680494916724233
 UP BND1      w[15,5]   0.0680494916724233
 UP BND1      w[15,6]   0.0680494916724233
 UP BND1      w[15,7]   0.0680494916724233
 UP BND1      w[15,8]   0.0680494916724233
 UP BND1      w[15,9]   0.0680494916724233
 UP BND1      w[15,10]  0.0680494916724233
 UP BND1      w[15,11]  0.0680494916724233
 UP BND1      w[15,12]  0.0680494916724233
 UP BND1      w[15,13]  0.0680494916724233
 UP BND1      w[15,14]  0.0680494916724233
 UP BND1      w[15,15]  0.0680494916724233
 UP BND1      w[15,16]  0.0680494916724233
 UP BND1      w[15,17]  0.0680494916724233
 UP BND1      w[15,18]  0.0680494916724233
 UP BND1      w[15,19]  0.0680494916724233
 UP BND1      w[15,20]  0.0680494916724233
 UP BND1      w[15,21]  0.0680494916724233
 UP BND1      w[15,22]  0.0680494916724233
 UP BND1      w[15,23]  0.0680494916724233
 UP BND1      w[15,24]  0.0680494916724233
 UP BND1      w[15,25]  0.0680494916724233
 UP BND1      w[15,26]  0.0680494916724233
 UP BND1      w[15,27]  0.0680494916724233
 UP BND1      w[16,0]   0.0680494916724233
 UP BND1      w[16,1]   0.0680494916724233
 UP BND1      w[16,2]   0.0680494916724233
 UP BND1      w[16,3]   0.0680494916724233
 UP BND1      w[16,4]   0.0680494916724233
 UP BND1      w[16,5]   0.0680494916724233
 UP BND1      w[16,6]   0.0680494916724233
 UP BND1      w[16,7]   0.0680494916724233
 UP BND1      w[16,8]   0.0680494916724233
 UP BND1      w[16,9]   0.0680494916724233
 UP BND1      w[16,10]  0.0680494916724233
 UP BND1      w[16,11]  0.0680494916724233
 UP BND1      w[16,12]  0.0680494916724233
 UP BND1      w[16,13]  0.0680494916724233
 UP BND1      w[16,14]  0.0680494916724233
 UP BND1      w[16,15]  0.0680494916724233
 UP BND1      w[16,16]  0.0680494916724233
 UP BND1      w[16,17]  0.0680494916724233
 UP BND1      w[16,18]  0.0680494916724233
 UP BND1      w[16,19]  0.0680494916724233
 UP BND1      w[16,20]  0.0680494916724233
 UP BND1      w[16,21]  0.0680494916724233
 UP BND1      w[16,22]  0.0680494916724233
 UP BND1      w[17,0]   0.0680494916724233
 UP BND1      w[17,1]   0.0680494916724233
 UP BND1      w[17,2]   0.0680494916724233
 UP BND1      w[17,3]   0.0680494916724233
 UP BND1      w[17,4]   0.0680494916724233
 UP BND1      w[17,5]   0.0680494916724233
 UP BND1      w[17,6]   0.0680494916724233
 UP BND1      w[17,7]   0.0680494916724233
 UP BND1      w[17,8]   0.0680494916724233
 UP BND1      w[17,9]   0.0680494916724233
 UP BND1      w[17,10]  0.0680494916724233
 UP BND1      w[17,11]  0.0680494916724233
 UP BND1      w[17,12]  0.0680494916724233
 UP BND1      w[17,13]  0.0680494916724233
 UP BND1      w[17,14]  0.0680494916724233
 UP BND1      w[17,15]  0.0680494916724233
 UP BND1      w[17,16]  0.0680494916724233
 UP BND1      w[17,17]  0.0680494916724233
 UP BND1      w[17,18]  0.0680494916724233
 UP BND1      w[17,19]  0.0680494916724233
 UP BND1      w[18,0]   0.0680494916724233
 UP BND1      w[18,1]   0.0680494916724233
 UP BND1      w[18,2]   0.0680494916724233
 UP BND1      w[18,3]   0.0680494916724233
 UP BND1      w[18,4]   0.0680494916724233
 UP BND1      w[18,5]   0.0680494916724233
 UP BND1      w[18,6]   0.0680494916724233
 UP BND1      w[18,7]   0.0680494916724233
 UP BND1      w[18,8]   0.0680494916724233
 UP BND1      w[18,9]   0.0680494916724233
 UP BND1      w[18,10]  0.0680494916724233
 UP BND1      w[18,11]  0.0680494916724233
 UP BND1      w[18,12]  0.0680494916724233
 UP BND1      w[18,13]  0.0680494916724233
 UP BND1      w[18,14]  0.0680494916724233
 UP BND1      w[18,15]  0.0680494916724233
 UP BND1      w[18,16]  0.0680494916724233
 UP BND1      w[18,17]  0.0680494916724233
 UP BND1      w[18,18]  0.0680494916724233
 UP BND1      w[18,19]  0.0680494916724233
 UP BND1      w[18,20]  0.0680494916724233
 UP BND1      w[18,21]  0.0680494916724233
 UP BND1      w[18,22]  0.0680494916724233
 UP BND1      w[19,0]   0.0680494916724233
 UP BND1      w[19,1]   0.0680494916724233
 UP BND1      w[19,2]   0.0680494916724233
 UP BND1      w[19,3]   0.0680494916724233
 UP BND1      w[19,4]   0.0680494916724233
 UP BND1      w[19,5]   0.0680494916724233
 UP BND1      w[19,6]   0.0680494916724233
 UP BND1      w[19,7]   0.0680494916724233
 UP BND1      w[19,8]   0.0680494916724233
 UP BND1      w[19,9]   0.0680494916724233
 UP BND1      w[19,10]  0.0680494916724233
 UP BND1      w[19,11]  0.0680494916724233
 UP BND1      w[19,12]  0.0680494916724233
 UP BND1      w[19,13]  0.0680494916724233
 UP BND1      w[19,14]  0.0680494916724233
 UP BND1      w[19,15]  0.0680494916724233
 UP BND1      w[19,16]  0.0680494916724233
 UP BND1      w[19,17]  0.0680494916724233
 UP BND1      w[19,18]  0.0680494916724233
 UP BND1      w[19,19]  0.0680494916724233
 UP BND1      w[19,20]  0.0680494916724233
 UP BND1      w[19,21]  0.0680494916724233
 UP BND1      w[19,22]  0.0680494916724233
 UP BND1      w[19,23]  0.0680494916724233
 UP BND1      w[20,0]   0.0680494916724233
 UP BND1      w[20,1]   0.0680494916724233
 UP BND1      w[20,2]   0.0680494916724233
 UP BND1      w[20,3]   0.0680494916724233
 UP BND1      w[20,4]   0.0680494916724233
 UP BND1      w[20,5]   0.0680494916724233
 UP BND1      w[20,6]   0.0680494916724233
 UP BND1      w[20,7]   0.0680494916724233
 UP BND1      w[20,8]   0.0680494916724233
 UP BND1      w[20,9]   0.0680494916724233
 UP BND1      w[20,10]  0.0680494916724233
 UP BND1      w[20,11]  0.0680494916724233
 UP BND1      w[20,12]  0.0680494916724233
 UP BND1      w[20,13]  0.0680494916724233
 UP BND1      w[20,14]  0.0680494916724233
 UP BND1      w[20,15]  0.0680494916724233
 UP BND1      w[20,16]  0.0680494916724233
 UP BND1      w[20,17]  0.0680494916724233
 UP BND1      w[20,18]  0.0680494916724233
 UP BND1      w[20,19]  0.0680494916724233
 UP BND1      w[20,20]  0.0680494916724233
 UP BND1      w[20,21]  0.0680494916724233
 UP BND1      w[20,22]  0.0680494916724233
 UP BND1      w[20,23]  0.0680494916724233
 LO BND1      t         3.9145222845663033e-02
 UP BND1      t         0.0680494916724233
ENDATA
