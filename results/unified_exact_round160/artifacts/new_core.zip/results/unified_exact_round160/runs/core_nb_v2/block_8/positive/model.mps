* Signature: 0xe01e58087f2dfb21
NAME R160_physical_neighborhood
ROWS
 N  OBJ
 G  product_lb_0
 L  product_ub_1
 G  product_lb_2
 L  product_ub_3
 G  product_lb_4
 L  product_ub_5
 G  product_lb_6
 L  product_ub_7
 G  product_lb_8
 L  product_ub_9
 G  product_lb_10
 L  product_ub_11
 G  product_lb_12
 L  product_ub_13
 G  product_lb_14
 L  product_ub_15
 G  product_lb_16
 L  product_ub_17
 G  product_lb_18
 L  product_ub_19
 G  product_lb_20
 L  product_ub_21
 G  product_lb_22
 L  product_ub_23
 E  onehot_34_24
 E  normalized_mass_34_25
 E  normalized_ratio_34_26
 G  product_lb_27
 L  product_ub_28
 G  product_lb_29
 L  product_ub_30
 G  product_lb_31
 L  product_ub_32
 G  product_lb_33
 L  product_ub_34
 G  product_lb_35
 L  product_ub_36
 G  product_lb_37
 L  product_ub_38
 G  product_lb_39
 L  product_ub_40
 G  product_lb_41
 L  product_ub_42
 G  product_lb_43
 L  product_ub_44
 G  product_lb_45
 L  product_ub_46
 G  product_lb_47
 L  product_ub_48
 G  product_lb_49
 L  product_ub_50
 G  product_lb_51
 L  product_ub_52
 G  product_lb_53
 L  product_ub_54
 G  product_lb_55
 L  product_ub_56
 G  product_lb_57
 L  product_ub_58
 G  product_lb_59
 L  product_ub_60
 E  onehot_33_61
 E  normalized_mass_33_62
 E  normalized_ratio_33_63
 G  product_lb_64
 L  product_ub_65
 G  product_lb_66
 L  product_ub_67
 G  product_lb_68
 L  product_ub_69
 G  product_lb_70
 L  product_ub_71
 G  product_lb_72
 L  product_ub_73
 G  product_lb_74
 L  product_ub_75
 G  product_lb_76
 L  product_ub_77
 G  product_lb_78
 L  product_ub_79
 G  product_lb_80
 L  product_ub_81
 G  product_lb_82
 L  product_ub_83
 G  product_lb_84
 L  product_ub_85
 G  product_lb_86
 L  product_ub_87
 G  product_lb_88
 L  product_ub_89
 E  onehot_31_90
 E  normalized_mass_31_91
 E  normalized_ratio_31_92
 G  product_lb_93
 L  product_ub_94
 G  product_lb_95
 L  product_ub_96
 G  product_lb_97
 L  product_ub_98
 G  product_lb_99
 L  product_ub_100
 G  product_lb_101
 L  product_ub_102
 G  product_lb_103
 L  product_ub_104
 G  product_lb_105
 L  product_ub_106
 G  product_lb_107
 L  product_ub_108
 G  product_lb_109
 L  product_ub_110
 G  product_lb_111
 L  product_ub_112
 G  product_lb_113
 L  product_ub_114
 G  product_lb_115
 L  product_ub_116
 G  product_lb_117
 L  product_ub_118
 G  product_lb_119
 L  product_ub_120
 G  product_lb_121
 L  product_ub_122
 G  product_lb_123
 L  product_ub_124
 E  onehot_27_125
 E  normalized_mass_27_126
 E  normalized_ratio_27_127
 G  product_lb_128
 L  product_ub_129
 G  product_lb_130
 L  product_ub_131
 G  product_lb_132
 L  product_ub_133
 G  product_lb_134
 L  product_ub_135
 G  product_lb_136
 L  product_ub_137
 G  product_lb_138
 L  product_ub_139
 G  product_lb_140
 L  product_ub_141
 G  product_lb_142
 L  product_ub_143
 G  product_lb_144
 L  product_ub_145
 G  product_lb_146
 L  product_ub_147
 G  product_lb_148
 L  product_ub_149
 G  product_lb_150
 L  product_ub_151
 G  product_lb_152
 L  product_ub_153
 E  onehot_32_154
 E  normalized_mass_32_155
 E  normalized_ratio_32_156
 G  product_lb_157
 L  product_ub_158
 G  product_lb_159
 L  product_ub_160
 G  product_lb_161
 L  product_ub_162
 G  product_lb_163
 L  product_ub_164
 G  product_lb_165
 L  product_ub_166
 G  product_lb_167
 L  product_ub_168
 G  product_lb_169
 L  product_ub_170
 G  product_lb_171
 L  product_ub_172
 G  product_lb_173
 L  product_ub_174
 G  product_lb_175
 L  product_ub_176
 G  product_lb_177
 L  product_ub_178
 G  product_lb_179
 L  product_ub_180
 G  product_lb_181
 L  product_ub_182
 G  product_lb_183
 L  product_ub_184
 G  product_lb_185
 L  product_ub_186
 G  product_lb_187
 L  product_ub_188
 E  onehot_24_189
 E  normalized_mass_24_190
 E  normalized_ratio_24_191
 G  product_lb_192
 L  product_ub_193
 G  product_lb_194
 L  product_ub_195
 G  product_lb_196
 L  product_ub_197
 G  product_lb_198
 L  product_ub_199
 G  product_lb_200
 L  product_ub_201
 G  product_lb_202
 L  product_ub_203
 G  product_lb_204
 L  product_ub_205
 G  product_lb_206
 L  product_ub_207
 G  product_lb_208
 L  product_ub_209
 E  onehot_19_210
 E  normalized_mass_19_211
 E  normalized_ratio_19_212
 G  product_lb_213
 L  product_ub_214
 G  product_lb_215
 L  product_ub_216
 G  product_lb_217
 L  product_ub_218
 G  product_lb_219
 L  product_ub_220
 G  product_lb_221
 L  product_ub_222
 G  product_lb_223
 L  product_ub_224
 G  product_lb_225
 L  product_ub_226
 G  product_lb_227
 L  product_ub_228
 G  product_lb_229
 L  product_ub_230
 G  product_lb_231
 L  product_ub_232
 G  product_lb_233
 L  product_ub_234
 G  product_lb_235
 L  product_ub_236
 G  product_lb_237
 L  product_ub_238
 G  product_lb_239
 L  product_ub_240
 G  product_lb_241
 L  product_ub_242
 G  product_lb_243
 L  product_ub_244
 E  onehot_29_245
 E  normalized_mass_29_246
 E  normalized_ratio_29_247
 G  stock_lb_248
 L  stock_ub_249
 L  parent_nonstrict_scope_250
 G  block_pair_pos_251
 G  block_pair_neg_252
 G  block_pair_pos_253
 G  block_pair_neg_254
 G  block_pair_pos_255
 G  block_pair_neg_256
 G  block_pair_pos_257
 G  block_pair_neg_258
 G  block_pair_pos_259
 G  block_pair_neg_260
 G  block_pair_pos_261
 G  block_pair_neg_262
 G  block_pair_pos_263
 G  block_pair_neg_264
 G  block_pair_pos_265
 G  block_pair_neg_266
 G  block_pair_pos_267
 G  block_pair_neg_268
 G  block_pair_pos_269
 G  block_pair_neg_270
 G  block_pair_pos_271
 G  block_pair_neg_272
 G  block_pair_pos_273
 G  block_pair_neg_274
 G  block_pair_pos_275
 G  block_pair_neg_276
 G  block_pair_pos_277
 G  block_pair_neg_278
 G  block_pair_pos_279
 G  block_pair_neg_280
 G  block_pair_pos_281
 G  block_pair_neg_282
 G  block_pair_pos_283
 G  block_pair_neg_284
 G  block_pair_pos_285
 G  block_pair_neg_286
 G  block_pair_pos_287
 G  block_pair_neg_288
 G  block_pair_pos_289
 G  block_pair_neg_290
 G  block_pair_pos_291
 G  block_pair_neg_292
 G  block_pair_pos_293
 G  block_pair_neg_294
 G  block_pair_pos_295
 G  block_pair_neg_296
 G  block_pair_pos_297
 G  block_pair_neg_298
 G  block_pair_pos_299
 G  block_pair_neg_300
 G  block_pair_pos_301
 G  block_pair_neg_302
 G  block_pair_pos_303
 G  block_pair_neg_304
 G  block_pair_pos_305
 G  block_pair_neg_306
 E  normalization_307
 G  full_original_Gini_308
 E  unique_nonzero_owner_309
 E  unique_nonzero_owner_310
 E  unique_nonzero_owner_311
 E  unique_nonzero_owner_312
 E  unique_nonzero_owner_313
 E  unique_nonzero_owner_314
 E  unique_nonzero_owner_315
 E  unique_nonzero_owner_316
 E  unique_nonzero_owner_317
 E  unique_nonzero_owner_318
 E  unique_nonzero_owner_319
 E  unique_nonzero_owner_320
 E  unique_nonzero_owner_321
 E  unique_nonzero_owner_322
 E  unique_nonzero_owner_323
 E  unique_nonzero_owner_324
 E  unique_nonzero_owner_325
 E  unique_nonzero_owner_326
 E  unique_nonzero_owner_327
 E  unique_nonzero_owner_328
 E  unique_nonzero_owner_329
 E  unique_nonzero_owner_330
 E  unique_nonzero_owner_331
 E  unique_nonzero_owner_332
 E  unique_nonzero_owner_333
 E  unique_nonzero_owner_334
 E  unique_nonzero_owner_335
 E  unique_nonzero_owner_336
 E  unique_nonzero_owner_337
 E  unique_nonzero_owner_338
 E  unique_nonzero_owner_339
 E  unique_nonzero_owner_340
 E  unique_nonzero_owner_341
 E  unique_nonzero_owner_342
 E  unique_nonzero_owner_343
 E  unique_nonzero_owner_344
 E  unique_nonzero_owner_345
 E  unique_nonzero_owner_346
 E  unique_nonzero_owner_347
 E  unique_nonzero_owner_348
 E  unique_nonzero_owner_349
 E  unique_nonzero_owner_350
 E  unique_nonzero_owner_351
 E  unique_nonzero_owner_352
 E  unique_nonzero_owner_353
 E  unique_nonzero_owner_354
 E  unique_nonzero_owner_355
 E  unique_nonzero_owner_356
 E  unique_nonzero_owner_357
 E  unique_nonzero_owner_358
 E  unique_nonzero_owner_359
 E  unique_nonzero_owner_360
 E  unique_nonzero_owner_361
 E  unique_nonzero_owner_362
 E  unique_nonzero_owner_363
 E  unique_nonzero_owner_364
 E  unique_nonzero_owner_365
 E  unique_nonzero_owner_366
 E  unique_nonzero_owner_367
 E  unique_nonzero_owner_368
 E  unique_nonzero_owner_369
 E  unique_nonzero_owner_370
 E  unique_nonzero_owner_371
 E  unique_nonzero_owner_372
 E  unique_nonzero_owner_373
 E  unique_nonzero_owner_374
 E  unique_nonzero_owner_375
 E  unique_nonzero_owner_376
 E  unique_nonzero_owner_377
 E  unique_nonzero_owner_378
 E  unique_nonzero_owner_379
 E  unique_nonzero_owner_380
 E  unique_nonzero_owner_381
 E  unique_nonzero_owner_382
 E  unique_nonzero_owner_383
 E  unique_nonzero_owner_384
 E  unique_nonzero_owner_385
 E  unique_nonzero_owner_386
 E  unique_nonzero_owner_387
 E  unique_nonzero_owner_388
 E  unique_nonzero_owner_389
 E  unique_nonzero_owner_390
 E  unique_nonzero_owner_391
 E  unique_nonzero_owner_392
 E  unique_nonzero_owner_393
 E  unique_nonzero_owner_394
 E  unique_nonzero_owner_395
 E  unique_nonzero_owner_396
 E  unique_nonzero_owner_397
 E  unique_nonzero_owner_398
 E  unique_nonzero_owner_399
 E  unique_nonzero_owner_400
 E  unique_nonzero_owner_401
 E  unique_nonzero_owner_402
 E  unique_nonzero_owner_403
 E  unique_nonzero_owner_404
 E  unique_nonzero_owner_405
 E  unique_nonzero_owner_406
 E  unique_nonzero_owner_407
 E  unique_nonzero_owner_408
 E  unique_nonzero_owner_409
 E  unique_nonzero_owner_410
 E  unique_nonzero_owner_411
 E  unique_nonzero_owner_412
 L  arc_capacity_413
 L  arc_capacity_414
 L  arc_capacity_415
 L  arc_capacity_416
 L  arc_capacity_417
 L  arc_capacity_418
 L  arc_capacity_419
 L  arc_capacity_420
 L  arc_capacity_421
 L  arc_capacity_422
 L  arc_capacity_423
 L  arc_capacity_424
 L  arc_capacity_425
 L  arc_capacity_426
 L  arc_capacity_427
 G  connected_order_arc_428
 L  arc_capacity_429
 G  connected_order_arc_430
 L  arc_capacity_431
 G  connected_order_arc_432
 L  arc_capacity_433
 G  connected_order_arc_434
 L  arc_capacity_435
 G  connected_order_arc_436
 L  arc_capacity_437
 G  connected_order_arc_438
 L  arc_capacity_439
 G  connected_order_arc_440
 L  arc_capacity_441
 G  connected_order_arc_442
 L  arc_capacity_443
 G  connected_order_arc_444
 L  arc_capacity_445
 G  connected_order_arc_446
 L  arc_capacity_447
 G  connected_order_arc_448
 L  arc_capacity_449
 L  arc_capacity_450
 G  connected_order_arc_451
 L  arc_capacity_452
 G  connected_order_arc_453
 L  arc_capacity_454
 G  connected_order_arc_455
 L  arc_capacity_456
 G  connected_order_arc_457
 L  arc_capacity_458
 G  connected_order_arc_459
 L  arc_capacity_460
 G  connected_order_arc_461
 L  arc_capacity_462
 G  connected_order_arc_463
 L  arc_capacity_464
 G  connected_order_arc_465
 L  arc_capacity_466
 G  connected_order_arc_467
 L  arc_capacity_468
 G  connected_order_arc_469
 L  arc_capacity_470
 G  connected_order_arc_471
 L  arc_capacity_472
 L  arc_capacity_473
 G  connected_order_arc_474
 L  arc_capacity_475
 G  connected_order_arc_476
 L  arc_capacity_477
 G  connected_order_arc_478
 L  arc_capacity_479
 G  connected_order_arc_480
 L  arc_capacity_481
 G  connected_order_arc_482
 L  arc_capacity_483
 G  connected_order_arc_484
 L  arc_capacity_485
 G  connected_order_arc_486
 L  arc_capacity_487
 G  connected_order_arc_488
 L  arc_capacity_489
 G  connected_order_arc_490
 L  arc_capacity_491
 G  connected_order_arc_492
 L  arc_capacity_493
 G  connected_order_arc_494
 L  arc_capacity_495
 L  arc_capacity_496
 G  connected_order_arc_497
 L  arc_capacity_498
 G  connected_order_arc_499
 L  arc_capacity_500
 G  connected_order_arc_501
 L  arc_capacity_502
 G  connected_order_arc_503
 L  arc_capacity_504
 G  connected_order_arc_505
 L  arc_capacity_506
 G  connected_order_arc_507
 L  arc_capacity_508
 G  connected_order_arc_509
 L  arc_capacity_510
 G  connected_order_arc_511
 L  arc_capacity_512
 G  connected_order_arc_513
 L  arc_capacity_514
 G  connected_order_arc_515
 L  arc_capacity_516
 G  connected_order_arc_517
 L  arc_capacity_518
 L  arc_capacity_519
 G  connected_order_arc_520
 L  arc_capacity_521
 G  connected_order_arc_522
 L  arc_capacity_523
 G  connected_order_arc_524
 L  arc_capacity_525
 G  connected_order_arc_526
 L  arc_capacity_527
 G  connected_order_arc_528
 L  arc_capacity_529
 G  connected_order_arc_530
 L  arc_capacity_531
 G  connected_order_arc_532
 L  arc_capacity_533
 G  connected_order_arc_534
 L  arc_capacity_535
 G  connected_order_arc_536
 L  arc_capacity_537
 G  connected_order_arc_538
 L  arc_capacity_539
 G  connected_order_arc_540
 L  arc_capacity_541
 L  arc_capacity_542
 G  connected_order_arc_543
 L  arc_capacity_544
 G  connected_order_arc_545
 L  arc_capacity_546
 G  connected_order_arc_547
 L  arc_capacity_548
 G  connected_order_arc_549
 L  arc_capacity_550
 G  connected_order_arc_551
 L  arc_capacity_552
 G  connected_order_arc_553
 L  arc_capacity_554
 G  connected_order_arc_555
 L  arc_capacity_556
 G  connected_order_arc_557
 L  arc_capacity_558
 G  connected_order_arc_559
 L  arc_capacity_560
 G  connected_order_arc_561
 L  arc_capacity_562
 G  connected_order_arc_563
 L  arc_capacity_564
 L  arc_capacity_565
 G  connected_order_arc_566
 L  arc_capacity_567
 G  connected_order_arc_568
 L  arc_capacity_569
 G  connected_order_arc_570
 L  arc_capacity_571
 G  connected_order_arc_572
 L  arc_capacity_573
 G  connected_order_arc_574
 L  arc_capacity_575
 G  connected_order_arc_576
 L  arc_capacity_577
 G  connected_order_arc_578
 L  arc_capacity_579
 G  connected_order_arc_580
 L  arc_capacity_581
 G  connected_order_arc_582
 L  arc_capacity_583
 G  connected_order_arc_584
 L  arc_capacity_585
 G  connected_order_arc_586
 L  arc_capacity_587
 L  arc_capacity_588
 G  connected_order_arc_589
 L  arc_capacity_590
 G  connected_order_arc_591
 L  arc_capacity_592
 G  connected_order_arc_593
 L  arc_capacity_594
 G  connected_order_arc_595
 L  arc_capacity_596
 G  connected_order_arc_597
 L  arc_capacity_598
 G  connected_order_arc_599
 L  arc_capacity_600
 G  connected_order_arc_601
 L  arc_capacity_602
 G  connected_order_arc_603
 L  arc_capacity_604
 G  connected_order_arc_605
 L  arc_capacity_606
 G  connected_order_arc_607
 L  arc_capacity_608
 G  connected_order_arc_609
 L  arc_capacity_610
 L  arc_capacity_611
 G  connected_order_arc_612
 L  arc_capacity_613
 G  connected_order_arc_614
 L  arc_capacity_615
 G  connected_order_arc_616
 L  arc_capacity_617
 G  connected_order_arc_618
 L  arc_capacity_619
 G  connected_order_arc_620
 L  arc_capacity_621
 G  connected_order_arc_622
 L  arc_capacity_623
 G  connected_order_arc_624
 L  arc_capacity_625
 G  connected_order_arc_626
 L  arc_capacity_627
 G  connected_order_arc_628
 L  arc_capacity_629
 G  connected_order_arc_630
 L  arc_capacity_631
 G  connected_order_arc_632
 L  arc_capacity_633
 L  arc_capacity_634
 G  connected_order_arc_635
 L  arc_capacity_636
 G  connected_order_arc_637
 L  arc_capacity_638
 G  connected_order_arc_639
 L  arc_capacity_640
 G  connected_order_arc_641
 L  arc_capacity_642
 G  connected_order_arc_643
 L  arc_capacity_644
 G  connected_order_arc_645
 L  arc_capacity_646
 G  connected_order_arc_647
 L  arc_capacity_648
 G  connected_order_arc_649
 L  arc_capacity_650
 G  connected_order_arc_651
 L  arc_capacity_652
 G  connected_order_arc_653
 L  arc_capacity_654
 G  connected_order_arc_655
 L  arc_capacity_656
 L  arc_capacity_657
 G  connected_order_arc_658
 L  arc_capacity_659
 G  connected_order_arc_660
 L  arc_capacity_661
 G  connected_order_arc_662
 L  arc_capacity_663
 G  connected_order_arc_664
 L  arc_capacity_665
 G  connected_order_arc_666
 L  arc_capacity_667
 G  connected_order_arc_668
 L  arc_capacity_669
 G  connected_order_arc_670
 L  arc_capacity_671
 G  connected_order_arc_672
 L  arc_capacity_673
 G  connected_order_arc_674
 L  arc_capacity_675
 G  connected_order_arc_676
 L  arc_capacity_677
 G  connected_order_arc_678
 L  arc_capacity_679
 L  arc_capacity_680
 G  connected_order_arc_681
 L  arc_capacity_682
 G  connected_order_arc_683
 L  arc_capacity_684
 G  connected_order_arc_685
 L  arc_capacity_686
 G  connected_order_arc_687
 L  arc_capacity_688
 G  connected_order_arc_689
 L  arc_capacity_690
 G  connected_order_arc_691
 L  arc_capacity_692
 G  connected_order_arc_693
 L  arc_capacity_694
 G  connected_order_arc_695
 L  arc_capacity_696
 G  connected_order_arc_697
 L  arc_capacity_698
 G  connected_order_arc_699
 L  arc_capacity_700
 G  connected_order_arc_701
 E  depot_departure_or_bypass_702
 E  depot_return_or_bypass_703
 E  out_degree_704
 E  in_degree_705
 G  order_active_lb_706
 L  order_active_ub_707
 E  segment_load_conservation_708
 G  segment_prefix_lb_709
 L  segment_prefix_ub_710
 E  out_degree_711
 E  in_degree_712
 G  order_active_lb_713
 L  order_active_ub_714
 E  segment_load_conservation_715
 G  segment_prefix_lb_716
 L  segment_prefix_ub_717
 E  out_degree_718
 E  in_degree_719
 G  order_active_lb_720
 L  order_active_ub_721
 E  segment_load_conservation_722
 G  segment_prefix_lb_723
 L  segment_prefix_ub_724
 E  out_degree_725
 E  in_degree_726
 G  order_active_lb_727
 L  order_active_ub_728
 E  segment_load_conservation_729
 G  segment_prefix_lb_730
 L  segment_prefix_ub_731
 E  out_degree_732
 E  in_degree_733
 G  order_active_lb_734
 L  order_active_ub_735
 E  service_visit_def_736
 E  free_load_conservation_737
 E  out_degree_738
 E  in_degree_739
 G  order_active_lb_740
 L  order_active_ub_741
 E  service_visit_def_742
 E  free_load_conservation_743
 E  out_degree_744
 E  in_degree_745
 G  order_active_lb_746
 L  order_active_ub_747
 E  service_visit_def_748
 E  free_load_conservation_749
 E  out_degree_750
 E  in_degree_751
 G  order_active_lb_752
 L  order_active_ub_753
 E  service_visit_def_754
 E  free_load_conservation_755
 E  out_degree_756
 E  in_degree_757
 G  order_active_lb_758
 L  order_active_ub_759
 E  service_visit_def_760
 E  free_load_conservation_761
 E  out_degree_762
 E  in_degree_763
 G  order_active_lb_764
 L  order_active_ub_765
 E  service_visit_def_766
 E  free_load_conservation_767
 E  out_degree_768
 E  in_degree_769
 G  order_active_lb_770
 L  order_active_ub_771
 E  service_visit_def_772
 E  free_load_conservation_773
 E  out_degree_774
 E  in_degree_775
 G  order_active_lb_776
 L  order_active_ub_777
 E  service_visit_def_778
 E  free_load_conservation_779
 G  fixed_segment_relative_order_780
 G  fixed_segment_relative_order_781
 G  fixed_segment_relative_order_782
 L  original_T_including_depot_unload_783
 L  arc_capacity_784
 L  arc_capacity_785
 L  arc_capacity_786
 L  arc_capacity_787
 L  arc_capacity_788
 L  arc_capacity_789
 L  arc_capacity_790
 L  arc_capacity_791
 L  arc_capacity_792
 L  arc_capacity_793
 L  arc_capacity_794
 L  arc_capacity_795
 L  arc_capacity_796
 L  arc_capacity_797
 L  arc_capacity_798
 L  arc_capacity_799
 G  connected_order_arc_800
 L  arc_capacity_801
 G  connected_order_arc_802
 L  arc_capacity_803
 G  connected_order_arc_804
 L  arc_capacity_805
 G  connected_order_arc_806
 L  arc_capacity_807
 G  connected_order_arc_808
 L  arc_capacity_809
 G  connected_order_arc_810
 L  arc_capacity_811
 G  connected_order_arc_812
 L  arc_capacity_813
 G  connected_order_arc_814
 L  arc_capacity_815
 G  connected_order_arc_816
 L  arc_capacity_817
 G  connected_order_arc_818
 L  arc_capacity_819
 G  connected_order_arc_820
 L  arc_capacity_821
 G  connected_order_arc_822
 L  arc_capacity_823
 L  arc_capacity_824
 G  connected_order_arc_825
 L  arc_capacity_826
 G  connected_order_arc_827
 L  arc_capacity_828
 G  connected_order_arc_829
 L  arc_capacity_830
 G  connected_order_arc_831
 L  arc_capacity_832
 G  connected_order_arc_833
 L  arc_capacity_834
 G  connected_order_arc_835
 L  arc_capacity_836
 G  connected_order_arc_837
 L  arc_capacity_838
 G  connected_order_arc_839
 L  arc_capacity_840
 G  connected_order_arc_841
 L  arc_capacity_842
 G  connected_order_arc_843
 L  arc_capacity_844
 G  connected_order_arc_845
 L  arc_capacity_846
 G  connected_order_arc_847
 L  arc_capacity_848
 L  arc_capacity_849
 G  connected_order_arc_850
 L  arc_capacity_851
 G  connected_order_arc_852
 L  arc_capacity_853
 G  connected_order_arc_854
 L  arc_capacity_855
 G  connected_order_arc_856
 L  arc_capacity_857
 G  connected_order_arc_858
 L  arc_capacity_859
 G  connected_order_arc_860
 L  arc_capacity_861
 G  connected_order_arc_862
 L  arc_capacity_863
 G  connected_order_arc_864
 L  arc_capacity_865
 G  connected_order_arc_866
 L  arc_capacity_867
 G  connected_order_arc_868
 L  arc_capacity_869
 G  connected_order_arc_870
 L  arc_capacity_871
 G  connected_order_arc_872
 L  arc_capacity_873
 L  arc_capacity_874
 G  connected_order_arc_875
 L  arc_capacity_876
 G  connected_order_arc_877
 L  arc_capacity_878
 G  connected_order_arc_879
 L  arc_capacity_880
 G  connected_order_arc_881
 L  arc_capacity_882
 G  connected_order_arc_883
 L  arc_capacity_884
 G  connected_order_arc_885
 L  arc_capacity_886
 G  connected_order_arc_887
 L  arc_capacity_888
 G  connected_order_arc_889
 L  arc_capacity_890
 G  connected_order_arc_891
 L  arc_capacity_892
 G  connected_order_arc_893
 L  arc_capacity_894
 G  connected_order_arc_895
 L  arc_capacity_896
 G  connected_order_arc_897
 L  arc_capacity_898
 L  arc_capacity_899
 G  connected_order_arc_900
 L  arc_capacity_901
 G  connected_order_arc_902
 L  arc_capacity_903
 G  connected_order_arc_904
 L  arc_capacity_905
 G  connected_order_arc_906
 L  arc_capacity_907
 G  connected_order_arc_908
 L  arc_capacity_909
 G  connected_order_arc_910
 L  arc_capacity_911
 G  connected_order_arc_912
 L  arc_capacity_913
 G  connected_order_arc_914
 L  arc_capacity_915
 G  connected_order_arc_916
 L  arc_capacity_917
 G  connected_order_arc_918
 L  arc_capacity_919
 G  connected_order_arc_920
 L  arc_capacity_921
 G  connected_order_arc_922
 L  arc_capacity_923
 L  arc_capacity_924
 G  connected_order_arc_925
 L  arc_capacity_926
 G  connected_order_arc_927
 L  arc_capacity_928
 G  connected_order_arc_929
 L  arc_capacity_930
 G  connected_order_arc_931
 L  arc_capacity_932
 G  connected_order_arc_933
 L  arc_capacity_934
 G  connected_order_arc_935
 L  arc_capacity_936
 G  connected_order_arc_937
 L  arc_capacity_938
 G  connected_order_arc_939
 L  arc_capacity_940
 G  connected_order_arc_941
 L  arc_capacity_942
 G  connected_order_arc_943
 L  arc_capacity_944
 G  connected_order_arc_945
 L  arc_capacity_946
 G  connected_order_arc_947
 L  arc_capacity_948
 L  arc_capacity_949
 G  connected_order_arc_950
 L  arc_capacity_951
 G  connected_order_arc_952
 L  arc_capacity_953
 G  connected_order_arc_954
 L  arc_capacity_955
 G  connected_order_arc_956
 L  arc_capacity_957
 G  connected_order_arc_958
 L  arc_capacity_959
 G  connected_order_arc_960
 L  arc_capacity_961
 G  connected_order_arc_962
 L  arc_capacity_963
 G  connected_order_arc_964
 L  arc_capacity_965
 G  connected_order_arc_966
 L  arc_capacity_967
 G  connected_order_arc_968
 L  arc_capacity_969
 G  connected_order_arc_970
 L  arc_capacity_971
 G  connected_order_arc_972
 L  arc_capacity_973
 L  arc_capacity_974
 G  connected_order_arc_975
 L  arc_capacity_976
 G  connected_order_arc_977
 L  arc_capacity_978
 G  connected_order_arc_979
 L  arc_capacity_980
 G  connected_order_arc_981
 L  arc_capacity_982
 G  connected_order_arc_983
 L  arc_capacity_984
 G  connected_order_arc_985
 L  arc_capacity_986
 G  connected_order_arc_987
 L  arc_capacity_988
 G  connected_order_arc_989
 L  arc_capacity_990
 G  connected_order_arc_991
 L  arc_capacity_992
 G  connected_order_arc_993
 L  arc_capacity_994
 G  connected_order_arc_995
 L  arc_capacity_996
 G  connected_order_arc_997
 L  arc_capacity_998
 L  arc_capacity_999
 G  connected_order_arc_1000
 L  arc_capacity_1001
 G  connected_order_arc_1002
 L  arc_capacity_1003
 G  connected_order_arc_1004
 L  arc_capacity_1005
 G  connected_order_arc_1006
 L  arc_capacity_1007
 G  connected_order_arc_1008
 L  arc_capacity_1009
 G  connected_order_arc_1010
 L  arc_capacity_1011
 G  connected_order_arc_1012
 L  arc_capacity_1013
 G  connected_order_arc_1014
 L  arc_capacity_1015
 G  connected_order_arc_1016
 L  arc_capacity_1017
 G  connected_order_arc_1018
 L  arc_capacity_1019
 G  connected_order_arc_1020
 L  arc_capacity_1021
 G  connected_order_arc_1022
 L  arc_capacity_1023
 L  arc_capacity_1024
 G  connected_order_arc_1025
 L  arc_capacity_1026
 G  connected_order_arc_1027
 L  arc_capacity_1028
 G  connected_order_arc_1029
 L  arc_capacity_1030
 G  connected_order_arc_1031
 L  arc_capacity_1032
 G  connected_order_arc_1033
 L  arc_capacity_1034
 G  connected_order_arc_1035
 L  arc_capacity_1036
 G  connected_order_arc_1037
 L  arc_capacity_1038
 G  connected_order_arc_1039
 L  arc_capacity_1040
 G  connected_order_arc_1041
 L  arc_capacity_1042
 G  connected_order_arc_1043
 L  arc_capacity_1044
 G  connected_order_arc_1045
 L  arc_capacity_1046
 G  connected_order_arc_1047
 L  arc_capacity_1048
 L  arc_capacity_1049
 G  connected_order_arc_1050
 L  arc_capacity_1051
 G  connected_order_arc_1052
 L  arc_capacity_1053
 G  connected_order_arc_1054
 L  arc_capacity_1055
 G  connected_order_arc_1056
 L  arc_capacity_1057
 G  connected_order_arc_1058
 L  arc_capacity_1059
 G  connected_order_arc_1060
 L  arc_capacity_1061
 G  connected_order_arc_1062
 L  arc_capacity_1063
 G  connected_order_arc_1064
 L  arc_capacity_1065
 G  connected_order_arc_1066
 L  arc_capacity_1067
 G  connected_order_arc_1068
 L  arc_capacity_1069
 G  connected_order_arc_1070
 L  arc_capacity_1071
 G  connected_order_arc_1072
 L  arc_capacity_1073
 L  arc_capacity_1074
 G  connected_order_arc_1075
 L  arc_capacity_1076
 G  connected_order_arc_1077
 L  arc_capacity_1078
 G  connected_order_arc_1079
 L  arc_capacity_1080
 G  connected_order_arc_1081
 L  arc_capacity_1082
 G  connected_order_arc_1083
 L  arc_capacity_1084
 G  connected_order_arc_1085
 L  arc_capacity_1086
 G  connected_order_arc_1087
 L  arc_capacity_1088
 G  connected_order_arc_1089
 L  arc_capacity_1090
 G  connected_order_arc_1091
 L  arc_capacity_1092
 G  connected_order_arc_1093
 L  arc_capacity_1094
 G  connected_order_arc_1095
 L  arc_capacity_1096
 G  connected_order_arc_1097
 L  arc_capacity_1098
 L  arc_capacity_1099
 G  connected_order_arc_1100
 L  arc_capacity_1101
 G  connected_order_arc_1102
 L  arc_capacity_1103
 G  connected_order_arc_1104
 L  arc_capacity_1105
 G  connected_order_arc_1106
 L  arc_capacity_1107
 G  connected_order_arc_1108
 L  arc_capacity_1109
 G  connected_order_arc_1110
 L  arc_capacity_1111
 G  connected_order_arc_1112
 L  arc_capacity_1113
 G  connected_order_arc_1114
 L  arc_capacity_1115
 G  connected_order_arc_1116
 L  arc_capacity_1117
 G  connected_order_arc_1118
 L  arc_capacity_1119
 G  connected_order_arc_1120
 L  arc_capacity_1121
 G  connected_order_arc_1122
 E  depot_departure_or_bypass_1123
 E  depot_return_or_bypass_1124
 E  out_degree_1125
 E  in_degree_1126
 G  order_active_lb_1127
 L  order_active_ub_1128
 E  segment_load_conservation_1129
 G  segment_prefix_lb_1130
 L  segment_prefix_ub_1131
 E  out_degree_1132
 E  in_degree_1133
 G  order_active_lb_1134
 L  order_active_ub_1135
 E  segment_load_conservation_1136
 G  segment_prefix_lb_1137
 L  segment_prefix_ub_1138
 E  out_degree_1139
 E  in_degree_1140
 G  order_active_lb_1141
 L  order_active_ub_1142
 E  segment_load_conservation_1143
 G  segment_prefix_lb_1144
 L  segment_prefix_ub_1145
 E  out_degree_1146
 E  in_degree_1147
 G  order_active_lb_1148
 L  order_active_ub_1149
 E  segment_load_conservation_1150
 G  segment_prefix_lb_1151
 L  segment_prefix_ub_1152
 E  out_degree_1153
 E  in_degree_1154
 G  order_active_lb_1155
 L  order_active_ub_1156
 E  segment_load_conservation_1157
 G  segment_prefix_lb_1158
 L  segment_prefix_ub_1159
 E  out_degree_1160
 E  in_degree_1161
 G  order_active_lb_1162
 L  order_active_ub_1163
 E  service_visit_def_1164
 E  free_load_conservation_1165
 E  out_degree_1166
 E  in_degree_1167
 G  order_active_lb_1168
 L  order_active_ub_1169
 E  service_visit_def_1170
 E  free_load_conservation_1171
 E  out_degree_1172
 E  in_degree_1173
 G  order_active_lb_1174
 L  order_active_ub_1175
 E  service_visit_def_1176
 E  free_load_conservation_1177
 E  out_degree_1178
 E  in_degree_1179
 G  order_active_lb_1180
 L  order_active_ub_1181
 E  service_visit_def_1182
 E  free_load_conservation_1183
 E  out_degree_1184
 E  in_degree_1185
 G  order_active_lb_1186
 L  order_active_ub_1187
 E  service_visit_def_1188
 E  free_load_conservation_1189
 E  out_degree_1190
 E  in_degree_1191
 G  order_active_lb_1192
 L  order_active_ub_1193
 E  service_visit_def_1194
 E  free_load_conservation_1195
 E  out_degree_1196
 E  in_degree_1197
 G  order_active_lb_1198
 L  order_active_ub_1199
 E  service_visit_def_1200
 E  free_load_conservation_1201
 E  out_degree_1202
 E  in_degree_1203
 G  order_active_lb_1204
 L  order_active_ub_1205
 E  service_visit_def_1206
 E  free_load_conservation_1207
 G  fixed_segment_relative_order_1208
 G  fixed_segment_relative_order_1209
 G  fixed_segment_relative_order_1210
 G  fixed_segment_relative_order_1211
 L  original_T_including_depot_unload_1212
 L  arc_capacity_1213
 L  arc_capacity_1214
 L  arc_capacity_1215
 L  arc_capacity_1216
 L  arc_capacity_1217
 L  arc_capacity_1218
 L  arc_capacity_1219
 L  arc_capacity_1220
 L  arc_capacity_1221
 L  arc_capacity_1222
 L  arc_capacity_1223
 L  arc_capacity_1224
 L  arc_capacity_1225
 L  arc_capacity_1226
 G  connected_order_arc_1227
 L  arc_capacity_1228
 G  connected_order_arc_1229
 L  arc_capacity_1230
 G  connected_order_arc_1231
 L  arc_capacity_1232
 G  connected_order_arc_1233
 L  arc_capacity_1234
 G  connected_order_arc_1235
 L  arc_capacity_1236
 G  connected_order_arc_1237
 L  arc_capacity_1238
 G  connected_order_arc_1239
 L  arc_capacity_1240
 G  connected_order_arc_1241
 L  arc_capacity_1242
 G  connected_order_arc_1243
 L  arc_capacity_1244
 G  connected_order_arc_1245
 L  arc_capacity_1246
 L  arc_capacity_1247
 G  connected_order_arc_1248
 L  arc_capacity_1249
 G  connected_order_arc_1250
 L  arc_capacity_1251
 G  connected_order_arc_1252
 L  arc_capacity_1253
 G  connected_order_arc_1254
 L  arc_capacity_1255
 G  connected_order_arc_1256
 L  arc_capacity_1257
 G  connected_order_arc_1258
 L  arc_capacity_1259
 G  connected_order_arc_1260
 L  arc_capacity_1261
 G  connected_order_arc_1262
 L  arc_capacity_1263
 G  connected_order_arc_1264
 L  arc_capacity_1265
 G  connected_order_arc_1266
 L  arc_capacity_1267
 L  arc_capacity_1268
 G  connected_order_arc_1269
 L  arc_capacity_1270
 G  connected_order_arc_1271
 L  arc_capacity_1272
 G  connected_order_arc_1273
 L  arc_capacity_1274
 G  connected_order_arc_1275
 L  arc_capacity_1276
 G  connected_order_arc_1277
 L  arc_capacity_1278
 G  connected_order_arc_1279
 L  arc_capacity_1280
 G  connected_order_arc_1281
 L  arc_capacity_1282
 G  connected_order_arc_1283
 L  arc_capacity_1284
 G  connected_order_arc_1285
 L  arc_capacity_1286
 G  connected_order_arc_1287
 L  arc_capacity_1288
 L  arc_capacity_1289
 G  connected_order_arc_1290
 L  arc_capacity_1291
 G  connected_order_arc_1292
 L  arc_capacity_1293
 G  connected_order_arc_1294
 L  arc_capacity_1295
 G  connected_order_arc_1296
 L  arc_capacity_1297
 G  connected_order_arc_1298
 L  arc_capacity_1299
 G  connected_order_arc_1300
 L  arc_capacity_1301
 G  connected_order_arc_1302
 L  arc_capacity_1303
 G  connected_order_arc_1304
 L  arc_capacity_1305
 G  connected_order_arc_1306
 L  arc_capacity_1307
 G  connected_order_arc_1308
 L  arc_capacity_1309
 L  arc_capacity_1310
 G  connected_order_arc_1311
 L  arc_capacity_1312
 G  connected_order_arc_1313
 L  arc_capacity_1314
 G  connected_order_arc_1315
 L  arc_capacity_1316
 G  connected_order_arc_1317
 L  arc_capacity_1318
 G  connected_order_arc_1319
 L  arc_capacity_1320
 G  connected_order_arc_1321
 L  arc_capacity_1322
 G  connected_order_arc_1323
 L  arc_capacity_1324
 G  connected_order_arc_1325
 L  arc_capacity_1326
 G  connected_order_arc_1327
 L  arc_capacity_1328
 G  connected_order_arc_1329
 L  arc_capacity_1330
 L  arc_capacity_1331
 G  connected_order_arc_1332
 L  arc_capacity_1333
 G  connected_order_arc_1334
 L  arc_capacity_1335
 G  connected_order_arc_1336
 L  arc_capacity_1337
 G  connected_order_arc_1338
 L  arc_capacity_1339
 G  connected_order_arc_1340
 L  arc_capacity_1341
 G  connected_order_arc_1342
 L  arc_capacity_1343
 G  connected_order_arc_1344
 L  arc_capacity_1345
 G  connected_order_arc_1346
 L  arc_capacity_1347
 G  connected_order_arc_1348
 L  arc_capacity_1349
 G  connected_order_arc_1350
 L  arc_capacity_1351
 L  arc_capacity_1352
 G  connected_order_arc_1353
 L  arc_capacity_1354
 G  connected_order_arc_1355
 L  arc_capacity_1356
 G  connected_order_arc_1357
 L  arc_capacity_1358
 G  connected_order_arc_1359
 L  arc_capacity_1360
 G  connected_order_arc_1361
 L  arc_capacity_1362
 G  connected_order_arc_1363
 L  arc_capacity_1364
 G  connected_order_arc_1365
 L  arc_capacity_1366
 G  connected_order_arc_1367
 L  arc_capacity_1368
 G  connected_order_arc_1369
 L  arc_capacity_1370
 G  connected_order_arc_1371
 L  arc_capacity_1372
 L  arc_capacity_1373
 G  connected_order_arc_1374
 L  arc_capacity_1375
 G  connected_order_arc_1376
 L  arc_capacity_1377
 G  connected_order_arc_1378
 L  arc_capacity_1379
 G  connected_order_arc_1380
 L  arc_capacity_1381
 G  connected_order_arc_1382
 L  arc_capacity_1383
 G  connected_order_arc_1384
 L  arc_capacity_1385
 G  connected_order_arc_1386
 L  arc_capacity_1387
 G  connected_order_arc_1388
 L  arc_capacity_1389
 G  connected_order_arc_1390
 L  arc_capacity_1391
 G  connected_order_arc_1392
 L  arc_capacity_1393
 L  arc_capacity_1394
 G  connected_order_arc_1395
 L  arc_capacity_1396
 G  connected_order_arc_1397
 L  arc_capacity_1398
 G  connected_order_arc_1399
 L  arc_capacity_1400
 G  connected_order_arc_1401
 L  arc_capacity_1402
 G  connected_order_arc_1403
 L  arc_capacity_1404
 G  connected_order_arc_1405
 L  arc_capacity_1406
 G  connected_order_arc_1407
 L  arc_capacity_1408
 G  connected_order_arc_1409
 L  arc_capacity_1410
 G  connected_order_arc_1411
 L  arc_capacity_1412
 G  connected_order_arc_1413
 L  arc_capacity_1414
 L  arc_capacity_1415
 G  connected_order_arc_1416
 L  arc_capacity_1417
 G  connected_order_arc_1418
 L  arc_capacity_1419
 G  connected_order_arc_1420
 L  arc_capacity_1421
 G  connected_order_arc_1422
 L  arc_capacity_1423
 G  connected_order_arc_1424
 L  arc_capacity_1425
 G  connected_order_arc_1426
 L  arc_capacity_1427
 G  connected_order_arc_1428
 L  arc_capacity_1429
 G  connected_order_arc_1430
 L  arc_capacity_1431
 G  connected_order_arc_1432
 L  arc_capacity_1433
 G  connected_order_arc_1434
 L  arc_capacity_1435
 L  arc_capacity_1436
 G  connected_order_arc_1437
 L  arc_capacity_1438
 G  connected_order_arc_1439
 L  arc_capacity_1440
 G  connected_order_arc_1441
 L  arc_capacity_1442
 G  connected_order_arc_1443
 L  arc_capacity_1444
 G  connected_order_arc_1445
 L  arc_capacity_1446
 G  connected_order_arc_1447
 L  arc_capacity_1448
 G  connected_order_arc_1449
 L  arc_capacity_1450
 G  connected_order_arc_1451
 L  arc_capacity_1452
 G  connected_order_arc_1453
 L  arc_capacity_1454
 G  connected_order_arc_1455
 E  depot_departure_or_bypass_1456
 E  depot_return_or_bypass_1457
 E  out_degree_1458
 E  in_degree_1459
 G  order_active_lb_1460
 L  order_active_ub_1461
 E  segment_load_conservation_1462
 G  segment_prefix_lb_1463
 L  segment_prefix_ub_1464
 E  out_degree_1465
 E  in_degree_1466
 G  order_active_lb_1467
 L  order_active_ub_1468
 E  segment_load_conservation_1469
 G  segment_prefix_lb_1470
 L  segment_prefix_ub_1471
 E  out_degree_1472
 E  in_degree_1473
 G  order_active_lb_1474
 L  order_active_ub_1475
 E  segment_load_conservation_1476
 G  segment_prefix_lb_1477
 L  segment_prefix_ub_1478
 E  out_degree_1479
 E  in_degree_1480
 G  order_active_lb_1481
 L  order_active_ub_1482
 E  service_visit_def_1483
 E  free_load_conservation_1484
 E  out_degree_1485
 E  in_degree_1486
 G  order_active_lb_1487
 L  order_active_ub_1488
 E  service_visit_def_1489
 E  free_load_conservation_1490
 E  out_degree_1491
 E  in_degree_1492
 G  order_active_lb_1493
 L  order_active_ub_1494
 E  service_visit_def_1495
 E  free_load_conservation_1496
 E  out_degree_1497
 E  in_degree_1498
 G  order_active_lb_1499
 L  order_active_ub_1500
 E  service_visit_def_1501
 E  free_load_conservation_1502
 E  out_degree_1503
 E  in_degree_1504
 G  order_active_lb_1505
 L  order_active_ub_1506
 E  service_visit_def_1507
 E  free_load_conservation_1508
 E  out_degree_1509
 E  in_degree_1510
 G  order_active_lb_1511
 L  order_active_ub_1512
 E  service_visit_def_1513
 E  free_load_conservation_1514
 E  out_degree_1515
 E  in_degree_1516
 G  order_active_lb_1517
 L  order_active_ub_1518
 E  service_visit_def_1519
 E  free_load_conservation_1520
 E  out_degree_1521
 E  in_degree_1522
 G  order_active_lb_1523
 L  order_active_ub_1524
 E  service_visit_def_1525
 E  free_load_conservation_1526
 G  fixed_segment_relative_order_1527
 G  fixed_segment_relative_order_1528
 L  original_T_including_depot_unload_1529
COLUMNS
    t         normalized_mass_34_25  -1
    t         normalized_mass_33_62  -1
    t         normalized_mass_31_91  -1
    t         normalized_mass_27_126  -1
    t         normalized_mass_32_155  -1
    t         normalized_mass_24_190  -1
    t         normalized_mass_19_211  -1
    t         normalized_mass_29_246  -1
    t         normalization_307  2.4085714285714282e+01
    t         full_original_Gini_308  -88.0880952380954
    q         OBJ       1
    q         parent_nonstrict_scope_250  1
    q         full_original_Gini_308  35
    MARKER    'MARKER'                 'INTORG'
    x_34_0    OBJ       1.4999999999999996e-02
    x_34_0    product_lb_0  -2.4643548670983981e-02
    x_34_0    product_ub_1  -4.1518386714157786e-02
    x_34_0    onehot_34_24  1
    x_34_0    parent_nonstrict_scope_250  0.0375
    x_34_0    unique_nonzero_owner_309  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_0    product_lb_0  1
    w_34_0    product_ub_1  1
    w_34_0    normalized_mass_34_25  1
    w_34_0    full_original_Gini_308  -2.4085714285714282e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_1    OBJ       7.4999999999999963e-03
    x_34_1    product_lb_2  -2.4643548670983981e-02
    x_34_1    product_ub_3  -4.1518386714157786e-02
    x_34_1    onehot_34_24  1
    x_34_1    stock_lb_248  1
    x_34_1    stock_ub_249  1
    x_34_1    parent_nonstrict_scope_250  0.03
    MARKER    'MARKER'                 'INTEND'
    w_34_1    product_lb_2  1
    w_34_1    product_ub_3  1
    w_34_1    normalized_mass_34_25  1
    w_34_1    normalized_ratio_34_26  -0.2
    w_34_1    full_original_Gini_308  -1.9085714285714289e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_2    OBJ       -3.4694469519536142e-18
    x_34_2    product_lb_4  -2.4643548670983981e-02
    x_34_2    product_ub_5  -4.1518386714157786e-02
    x_34_2    onehot_34_24  1
    x_34_2    stock_lb_248  2
    x_34_2    stock_ub_249  2
    x_34_2    parent_nonstrict_scope_250  0.0225
    x_34_2    unique_nonzero_owner_310  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_2    product_lb_4  1
    w_34_2    product_ub_5  1
    w_34_2    normalized_mass_34_25  1
    w_34_2    normalized_ratio_34_26  -0.4
    w_34_2    full_original_Gini_308  -1.4485714285714286e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_3    OBJ       -7.5000000000000067e-03
    x_34_3    product_lb_6  -2.4643548670983981e-02
    x_34_3    product_ub_7  -4.1518386714157786e-02
    x_34_3    onehot_34_24  1
    x_34_3    stock_lb_248  3
    x_34_3    stock_ub_249  3
    x_34_3    parent_nonstrict_scope_250  1.4999999999999996e-02
    x_34_3    unique_nonzero_owner_311  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_3    product_lb_6  1
    w_34_3    product_ub_7  1
    w_34_3    normalized_mass_34_25  1
    w_34_3    normalized_ratio_34_26  -6.0000000000000009e-01
    w_34_3    full_original_Gini_308  -9.8857142857142861e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_4    OBJ       -1.5000000000000005e-02
    x_34_4    product_lb_8  -2.4643548670983981e-02
    x_34_4    product_ub_9  -4.1518386714157786e-02
    x_34_4    onehot_34_24  1
    x_34_4    stock_lb_248  4
    x_34_4    stock_ub_249  4
    x_34_4    parent_nonstrict_scope_250  7.4999999999999980e-03
    x_34_4    unique_nonzero_owner_312  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_4    product_lb_8  1
    w_34_4    product_ub_9  1
    w_34_4    normalized_mass_34_25  1
    w_34_4    normalized_ratio_34_26  -0.8
    w_34_4    full_original_Gini_308  -5.9952380952380970e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_5    OBJ       -2.2500000000000003e-02
    x_34_5    product_lb_10  -2.4643548670983981e-02
    x_34_5    product_ub_11  -4.1518386714157786e-02
    x_34_5    onehot_34_24  1
    x_34_5    stock_lb_248  5
    x_34_5    stock_ub_249  5
    x_34_5    unique_nonzero_owner_313  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_5    product_lb_10  1
    w_34_5    product_ub_11  1
    w_34_5    normalized_mass_34_25  1
    w_34_5    normalized_ratio_34_26  -1
    w_34_5    full_original_Gini_308  -4.1142857142857148e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_6    OBJ       -1.4999999999999996e-02
    x_34_6    product_lb_12  -2.4643548670983981e-02
    x_34_6    product_ub_13  -4.1518386714157786e-02
    x_34_6    onehot_34_24  1
    x_34_6    stock_lb_248  6
    x_34_6    stock_ub_249  6
    x_34_6    parent_nonstrict_scope_250  7.5000000000000067e-03
    x_34_6    unique_nonzero_owner_314  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_6    product_lb_12  1
    w_34_6    product_ub_13  1
    w_34_6    normalized_mass_34_25  1
    w_34_6    normalized_ratio_34_26  -1.2000000000000002e+00
    w_34_6    full_original_Gini_308  -8.3142857142857167e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_7    OBJ       -7.4999999999999980e-03
    x_34_7    product_lb_14  -2.4643548670983981e-02
    x_34_7    product_ub_15  -4.1518386714157786e-02
    x_34_7    onehot_34_24  1
    x_34_7    stock_lb_248  7
    x_34_7    stock_ub_249  7
    x_34_7    parent_nonstrict_scope_250  1.5000000000000005e-02
    x_34_7    unique_nonzero_owner_315  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_7    product_lb_14  1
    w_34_7    product_ub_15  1
    w_34_7    normalized_mass_34_25  1
    w_34_7    normalized_ratio_34_26  -1.4000000000000001e+00
    w_34_7    full_original_Gini_308  -1.3714285714285719e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_8    product_lb_16  -2.4643548670983981e-02
    x_34_8    product_ub_17  -4.1518386714157786e-02
    x_34_8    onehot_34_24  1
    x_34_8    stock_lb_248  8
    x_34_8    stock_ub_249  8
    x_34_8    parent_nonstrict_scope_250  2.2500000000000003e-02
    x_34_8    unique_nonzero_owner_316  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_8    product_lb_16  1
    w_34_8    product_ub_17  1
    w_34_8    normalized_mass_34_25  1
    w_34_8    normalized_ratio_34_26  -1.6
    w_34_8    full_original_Gini_308  -1.9114285714285721e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_9    OBJ       7.4999999999999963e-03
    x_34_9    product_lb_18  -2.4643548670983981e-02
    x_34_9    product_ub_19  -4.1518386714157786e-02
    x_34_9    onehot_34_24  1
    x_34_9    stock_lb_248  9
    x_34_9    stock_ub_249  9
    x_34_9    parent_nonstrict_scope_250  0.03
    x_34_9    unique_nonzero_owner_317  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_9    product_lb_18  1
    w_34_9    product_ub_19  1
    w_34_9    normalized_mass_34_25  1
    w_34_9    normalized_ratio_34_26  -1.8
    w_34_9    full_original_Gini_308  -2.4514285714285723e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_10   OBJ       1.4999999999999996e-02
    x_34_10   product_lb_20  -2.4643548670983981e-02
    x_34_10   product_ub_21  -4.1518386714157786e-02
    x_34_10   onehot_34_24  1
    x_34_10   stock_lb_248  10
    x_34_10   stock_ub_249  10
    x_34_10   parent_nonstrict_scope_250  0.0375
    x_34_10   unique_nonzero_owner_318  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_10   product_lb_20  1
    w_34_10   product_ub_21  1
    w_34_10   normalized_mass_34_25  1
    w_34_10   normalized_ratio_34_26  -2
    w_34_10   full_original_Gini_308  -2.9914285714285715e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_11   OBJ       2.2500000000000003e-02
    x_34_11   product_lb_22  -2.4643548670983981e-02
    x_34_11   product_ub_23  -4.1518386714157786e-02
    x_34_11   onehot_34_24  1
    x_34_11   stock_lb_248  11
    x_34_11   stock_ub_249  11
    x_34_11   parent_nonstrict_scope_250  4.5000000000000005e-02
    x_34_11   unique_nonzero_owner_319  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_11   product_lb_22  1
    w_34_11   product_ub_23  1
    w_34_11   normalized_mass_34_25  1
    w_34_11   normalized_ratio_34_26  -2.2
    w_34_11   full_original_Gini_308  -3.5314285714285724e+01
    rho_34    normalized_ratio_34_26  1
    rho_34    block_pair_pos_293  -1
    rho_34    block_pair_neg_294  1
    rho_34    block_pair_pos_295  -1
    rho_34    block_pair_neg_296  1
    rho_34    block_pair_pos_297  -1
    rho_34    block_pair_neg_298  1
    rho_34    block_pair_pos_299  -1
    rho_34    block_pair_neg_300  1
    rho_34    block_pair_pos_301  -1
    rho_34    block_pair_neg_302  1
    rho_34    block_pair_pos_303  -1
    rho_34    block_pair_neg_304  1
    rho_34    block_pair_pos_305  -1
    rho_34    block_pair_neg_306  1
    rho_34    normalization_307  1
    MARKER    'MARKER'                 'INTORG'
    x_33_0    OBJ       2.6250000000000002e-02
    x_33_0    product_lb_27  -2.4643548670983981e-02
    x_33_0    product_ub_28  -4.1518386714157786e-02
    x_33_0    onehot_33_61  1
    x_33_0    parent_nonstrict_scope_250  0.0735
    x_33_0    unique_nonzero_owner_320  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_0    product_lb_27  1
    w_33_0    product_ub_28  1
    w_33_0    normalized_mass_33_62  1
    w_33_0    full_original_Gini_308  -2.4085714285714282e+01
    MARKER    'MARKER'                 'INTORG'
    x_33_1    OBJ       1.5750000000000007e-02
    x_33_1    product_lb_29  -2.4643548670983981e-02
    x_33_1    product_ub_30  -4.1518386714157786e-02
    x_33_1    onehot_33_61  1
    x_33_1    stock_lb_248  1
    x_33_1    stock_ub_249  1
    x_33_1    parent_nonstrict_scope_250  0.063
    MARKER    'MARKER'                 'INTEND'
    w_33_1    product_lb_29  1
    w_33_1    product_ub_30  1
    w_33_1    normalized_mass_33_62  1
    w_33_1    normalized_ratio_33_63  -1.4285714285714285e-01
    w_33_1    full_original_Gini_308  -2.0514285714285720e+01
    MARKER    'MARKER'                 'INTORG'
    x_33_2    OBJ       5.2500000000000047e-03
    x_33_2    product_lb_31  -2.4643548670983981e-02
    x_33_2    product_ub_32  -4.1518386714157786e-02
    x_33_2    onehot_33_61  1
    x_33_2    stock_lb_248  2
    x_33_2    stock_ub_249  2
    x_33_2    parent_nonstrict_scope_250  0.0525
    x_33_2    unique_nonzero_owner_321  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_2    product_lb_31  1
    w_33_2    product_ub_32  1
    w_33_2    normalized_mass_33_62  1
    w_33_2    normalized_ratio_33_63  -2.8571428571428570e-01
    w_33_2    full_original_Gini_308  -1.7114285714285714e+01
    MARKER    'MARKER'                 'INTORG'
    x_33_3    OBJ       -5.2499999999999977e-03
    x_33_3    product_lb_33  -2.4643548670983981e-02
    x_33_3    product_ub_34  -4.1518386714157786e-02
    x_33_3    onehot_33_61  1
    x_33_3    stock_lb_248  3
    x_33_3    stock_ub_249  3
    x_33_3    parent_nonstrict_scope_250  4.1999999999999996e-02
    x_33_3    unique_nonzero_owner_322  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_3    product_lb_33  1
    w_33_3    product_ub_34  1
    w_33_3    normalized_mass_33_62  1
    w_33_3    normalized_ratio_33_63  -4.2857142857142855e-01
    w_33_3    full_original_Gini_308  -1.3828571428571427e+01
    MARKER    'MARKER'                 'INTORG'
    x_33_4    OBJ       -1.5749999999999993e-02
    x_33_4    product_lb_35  -2.4643548670983981e-02
    x_33_4    product_ub_36  -4.1518386714157786e-02
    x_33_4    onehot_33_61  1
    x_33_4    stock_lb_248  4
    x_33_4    stock_ub_249  4
    x_33_4    parent_nonstrict_scope_250  0.0315
    x_33_4    unique_nonzero_owner_323  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_4    product_lb_35  1
    w_33_4    product_ub_36  1
    w_33_4    normalized_mass_33_62  1
    w_33_4    normalized_ratio_33_63  -5.7142857142857140e-01
    w_33_4    full_original_Gini_308  -1.0542857142857146e+01
    MARKER    'MARKER'                 'INTORG'
    x_33_5    OBJ       -2.6249999999999989e-02
    x_33_5    product_lb_37  -2.4643548670983981e-02
    x_33_5    product_ub_38  -4.1518386714157786e-02
    x_33_5    onehot_33_61  1
    x_33_5    stock_lb_248  5
    x_33_5    stock_ub_249  5
    x_33_5    parent_nonstrict_scope_250  2.1000000000000005e-02
    x_33_5    unique_nonzero_owner_324  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_5    product_lb_37  1
    w_33_5    product_ub_38  1
    w_33_5    normalized_mass_33_62  1
    w_33_5    normalized_ratio_33_63  -7.1428571428571419e-01
    w_33_5    full_original_Gini_308  -7.3523809523809529e+00
    MARKER    'MARKER'                 'INTORG'
    x_33_6    OBJ       -3.6749999999999991e-02
    x_33_6    product_lb_39  -2.4643548670983981e-02
    x_33_6    product_ub_40  -4.1518386714157786e-02
    x_33_6    onehot_33_61  1
    x_33_6    stock_lb_248  6
    x_33_6    stock_ub_249  6
    x_33_6    parent_nonstrict_scope_250  1.0500000000000002e-02
    x_33_6    unique_nonzero_owner_325  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_6    product_lb_39  1
    w_33_6    product_ub_40  1
    w_33_6    normalized_mass_33_62  1
    w_33_6    normalized_ratio_33_63  -8.5714285714285710e-01
    w_33_6    full_original_Gini_308  -5.1857142857142859e+00
    MARKER    'MARKER'                 'INTORG'
    x_33_7    OBJ       -4.7249999999999993e-02
    x_33_7    product_lb_41  -2.4643548670983981e-02
    x_33_7    product_ub_42  -4.1518386714157786e-02
    x_33_7    onehot_33_61  1
    x_33_7    stock_lb_248  7
    x_33_7    stock_ub_249  7
    x_33_7    unique_nonzero_owner_326  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_7    product_lb_41  1
    w_33_7    product_ub_42  1
    w_33_7    normalized_mass_33_62  1
    w_33_7    normalized_ratio_33_63  -1
    w_33_7    full_original_Gini_308  -4.1142857142857148e+00
    MARKER    'MARKER'                 'INTORG'
    x_33_8    OBJ       -0.03675
    x_33_8    product_lb_43  -2.4643548670983981e-02
    x_33_8    product_ub_44  -4.1518386714157786e-02
    x_33_8    onehot_33_61  1
    x_33_8    stock_lb_248  8
    x_33_8    stock_ub_249  8
    x_33_8    parent_nonstrict_scope_250  1.0499999999999995e-02
    x_33_8    unique_nonzero_owner_327  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_8    product_lb_43  1
    w_33_8    product_ub_44  1
    w_33_8    normalized_mass_33_62  1
    w_33_8    normalized_ratio_33_63  -1.1428571428571428e+00
    w_33_8    full_original_Gini_308  -7.11428571428571
    MARKER    'MARKER'                 'INTORG'
    x_33_9    OBJ       -2.6250000000000002e-02
    x_33_9    product_lb_45  -2.4643548670983981e-02
    x_33_9    product_ub_46  -4.1518386714157786e-02
    x_33_9    onehot_33_61  1
    x_33_9    stock_lb_248  9
    x_33_9    stock_ub_249  9
    x_33_9    parent_nonstrict_scope_250  2.0999999999999991e-02
    x_33_9    unique_nonzero_owner_328  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_9    product_lb_45  1
    w_33_9    product_ub_46  1
    w_33_9    normalized_mass_33_62  1
    w_33_9    normalized_ratio_33_63  -1.2857142857142856e+00
    w_33_9    full_original_Gini_308  -1.0628571428571423e+01
    MARKER    'MARKER'                 'INTORG'
    x_33_10   OBJ       -1.5750000000000007e-02
    x_33_10   product_lb_47  -2.4643548670983981e-02
    x_33_10   product_ub_48  -4.1518386714157786e-02
    x_33_10   onehot_33_61  1
    x_33_10   stock_lb_248  10
    x_33_10   stock_ub_249  10
    x_33_10   parent_nonstrict_scope_250  3.1499999999999986e-02
    x_33_10   unique_nonzero_owner_329  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_10   product_lb_47  1
    w_33_10   product_ub_48  1
    w_33_10   normalized_mass_33_62  1
    w_33_10   normalized_ratio_33_63  -1.4285714285714284e+00
    w_33_10   full_original_Gini_308  -1.4485714285714284e+01
    MARKER    'MARKER'                 'INTORG'
    x_33_11   OBJ       -5.2499999999999977e-03
    x_33_11   product_lb_49  -2.4643548670983981e-02
    x_33_11   product_ub_50  -4.1518386714157786e-02
    x_33_11   onehot_33_61  1
    x_33_11   stock_lb_248  11
    x_33_11   stock_ub_249  11
    x_33_11   parent_nonstrict_scope_250  4.1999999999999996e-02
    x_33_11   unique_nonzero_owner_330  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_11   product_lb_49  1
    w_33_11   product_ub_50  1
    w_33_11   normalized_mass_33_62  1
    w_33_11   normalized_ratio_33_63  -1.5714285714285714e+00
    w_33_11   full_original_Gini_308  -1.8342857142857145e+01
    MARKER    'MARKER'                 'INTORG'
    x_33_12   OBJ       5.2499999999999977e-03
    x_33_12   product_lb_51  -2.4643548670983981e-02
    x_33_12   product_ub_52  -4.1518386714157786e-02
    x_33_12   onehot_33_61  1
    x_33_12   stock_lb_248  12
    x_33_12   stock_ub_249  12
    x_33_12   parent_nonstrict_scope_250  5.2499999999999991e-02
    x_33_12   unique_nonzero_owner_331  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_12   product_lb_51  1
    w_33_12   product_ub_52  1
    w_33_12   normalized_mass_33_62  1
    w_33_12   normalized_ratio_33_63  -1.7142857142857142e+00
    w_33_12   full_original_Gini_308  -22.2
    MARKER    'MARKER'                 'INTORG'
    x_33_13   OBJ       1.5749999999999993e-02
    x_33_13   product_lb_53  -2.4643548670983981e-02
    x_33_13   product_ub_54  -4.1518386714157786e-02
    x_33_13   onehot_33_61  1
    x_33_13   stock_lb_248  13
    x_33_13   stock_ub_249  13
    x_33_13   parent_nonstrict_scope_250  6.2999999999999987e-02
    x_33_13   unique_nonzero_owner_332  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_13   product_lb_53  1
    w_33_13   product_ub_54  1
    w_33_13   normalized_mass_33_62  1
    w_33_13   normalized_ratio_33_63  -1.8571428571428570e+00
    w_33_13   full_original_Gini_308  -2.6057142857142860e+01
    MARKER    'MARKER'                 'INTORG'
    x_33_14   OBJ       2.6250000000000002e-02
    x_33_14   product_lb_55  -2.4643548670983981e-02
    x_33_14   product_ub_56  -4.1518386714157786e-02
    x_33_14   onehot_33_61  1
    x_33_14   stock_lb_248  14
    x_33_14   stock_ub_249  14
    x_33_14   parent_nonstrict_scope_250  0.0735
    x_33_14   unique_nonzero_owner_333  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_14   product_lb_55  1
    w_33_14   product_ub_56  1
    w_33_14   normalized_mass_33_62  1
    w_33_14   normalized_ratio_33_63  -2
    w_33_14   full_original_Gini_308  -2.9914285714285715e+01
    MARKER    'MARKER'                 'INTORG'
    x_33_15   OBJ       0.03675
    x_33_15   product_lb_57  -2.4643548670983981e-02
    x_33_15   product_ub_58  -4.1518386714157786e-02
    x_33_15   onehot_33_61  1
    x_33_15   stock_lb_248  15
    x_33_15   stock_ub_249  15
    x_33_15   parent_nonstrict_scope_250  8.3999999999999991e-02
    x_33_15   unique_nonzero_owner_334  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_15   product_lb_57  1
    w_33_15   product_ub_58  1
    w_33_15   normalized_mass_33_62  1
    w_33_15   normalized_ratio_33_63  -2.1428571428571428e+00
    w_33_15   full_original_Gini_308  -3.3771428571428565e+01
    MARKER    'MARKER'                 'INTORG'
    x_33_16   OBJ       4.7249999999999993e-02
    x_33_16   product_lb_59  -2.4643548670983981e-02
    x_33_16   product_ub_60  -4.1518386714157786e-02
    x_33_16   onehot_33_61  1
    x_33_16   stock_lb_248  16
    x_33_16   stock_ub_249  16
    x_33_16   parent_nonstrict_scope_250  9.4499999999999987e-02
    x_33_16   unique_nonzero_owner_335  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_16   product_lb_59  1
    w_33_16   product_ub_60  1
    w_33_16   normalized_mass_33_62  1
    w_33_16   normalized_ratio_33_63  -2.2857142857142856e+00
    w_33_16   full_original_Gini_308  -3.7628571428571419e+01
    rho_33    normalized_ratio_33_63  1
    rho_33    block_pair_pos_281  -1
    rho_33    block_pair_neg_282  1
    rho_33    block_pair_pos_283  -1
    rho_33    block_pair_neg_284  1
    rho_33    block_pair_pos_285  -1
    rho_33    block_pair_neg_286  1
    rho_33    block_pair_pos_287  -1
    rho_33    block_pair_neg_288  1
    rho_33    block_pair_pos_289  -1
    rho_33    block_pair_neg_290  1
    rho_33    block_pair_pos_291  -1
    rho_33    block_pair_neg_292  1
    rho_33    block_pair_pos_305  1
    rho_33    block_pair_neg_306  -1
    rho_33    normalization_307  1
    MARKER    'MARKER'                 'INTORG'
    x_31_0    OBJ       0.03675
    x_31_0    product_lb_64  -2.4643548670983981e-02
    x_31_0    product_ub_65  -4.1518386714157786e-02
    x_31_0    onehot_31_90  1
    x_31_0    parent_nonstrict_scope_250  0.0735
    x_31_0    unique_nonzero_owner_336  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_0    product_lb_64  1
    w_31_0    product_ub_65  1
    w_31_0    normalized_mass_31_91  1
    w_31_0    full_original_Gini_308  -2.4085714285714282e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_1    OBJ       2.6250000000000002e-02
    x_31_1    product_lb_66  -2.4643548670983981e-02
    x_31_1    product_ub_67  -4.1518386714157786e-02
    x_31_1    onehot_31_90  1
    x_31_1    stock_lb_248  1
    x_31_1    stock_ub_249  1
    x_31_1    parent_nonstrict_scope_250  0.063
    x_31_1    unique_nonzero_owner_337  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_1    product_lb_66  1
    w_31_1    product_ub_67  1
    w_31_1    normalized_mass_31_91  1
    w_31_1    normalized_ratio_31_92  -1.4285714285714285e-01
    w_31_1    full_original_Gini_308  -2.0514285714285720e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_2    OBJ       0.01575
    x_31_2    product_lb_68  -2.4643548670983981e-02
    x_31_2    product_ub_69  -4.1518386714157786e-02
    x_31_2    onehot_31_90  1
    x_31_2    stock_lb_248  2
    x_31_2    stock_ub_249  2
    x_31_2    parent_nonstrict_scope_250  0.0525
    MARKER    'MARKER'                 'INTEND'
    w_31_2    product_lb_68  1
    w_31_2    product_ub_69  1
    w_31_2    normalized_mass_31_91  1
    w_31_2    normalized_ratio_31_92  -2.8571428571428570e-01
    w_31_2    full_original_Gini_308  -1.7114285714285714e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_3    OBJ       5.2499999999999977e-03
    x_31_3    product_lb_70  -2.4643548670983981e-02
    x_31_3    product_ub_71  -4.1518386714157786e-02
    x_31_3    onehot_31_90  1
    x_31_3    stock_lb_248  3
    x_31_3    stock_ub_249  3
    x_31_3    parent_nonstrict_scope_250  4.1999999999999996e-02
    x_31_3    unique_nonzero_owner_338  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_3    product_lb_70  1
    w_31_3    product_ub_71  1
    w_31_3    normalized_mass_31_91  1
    w_31_3    normalized_ratio_31_92  -4.2857142857142855e-01
    w_31_3    full_original_Gini_308  -1.3828571428571427e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_4    OBJ       -5.2499999999999977e-03
    x_31_4    product_lb_72  -2.4643548670983981e-02
    x_31_4    product_ub_73  -4.1518386714157786e-02
    x_31_4    onehot_31_90  1
    x_31_4    stock_lb_248  4
    x_31_4    stock_ub_249  4
    x_31_4    parent_nonstrict_scope_250  0.0315
    x_31_4    unique_nonzero_owner_339  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_4    product_lb_72  1
    w_31_4    product_ub_73  1
    w_31_4    normalized_mass_31_91  1
    w_31_4    normalized_ratio_31_92  -5.7142857142857140e-01
    w_31_4    full_original_Gini_308  -1.0542857142857146e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_5    OBJ       -1.5749999999999993e-02
    x_31_5    product_lb_74  -2.4643548670983981e-02
    x_31_5    product_ub_75  -4.1518386714157786e-02
    x_31_5    onehot_31_90  1
    x_31_5    stock_lb_248  5
    x_31_5    stock_ub_249  5
    x_31_5    parent_nonstrict_scope_250  2.1000000000000005e-02
    x_31_5    unique_nonzero_owner_340  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_5    product_lb_74  1
    w_31_5    product_ub_75  1
    w_31_5    normalized_mass_31_91  1
    w_31_5    normalized_ratio_31_92  -7.1428571428571419e-01
    w_31_5    full_original_Gini_308  -7.3523809523809529e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_6    OBJ       -2.6249999999999996e-02
    x_31_6    product_lb_76  -2.4643548670983981e-02
    x_31_6    product_ub_77  -4.1518386714157786e-02
    x_31_6    onehot_31_90  1
    x_31_6    stock_lb_248  6
    x_31_6    stock_ub_249  6
    x_31_6    parent_nonstrict_scope_250  1.0500000000000002e-02
    x_31_6    unique_nonzero_owner_341  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_6    product_lb_76  1
    w_31_6    product_ub_77  1
    w_31_6    normalized_mass_31_91  1
    w_31_6    normalized_ratio_31_92  -8.5714285714285710e-01
    w_31_6    full_original_Gini_308  -5.1857142857142859e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_7    OBJ       -0.03675
    x_31_7    product_lb_78  -2.4643548670983981e-02
    x_31_7    product_ub_79  -4.1518386714157786e-02
    x_31_7    onehot_31_90  1
    x_31_7    stock_lb_248  7
    x_31_7    stock_ub_249  7
    x_31_7    unique_nonzero_owner_342  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_7    product_lb_78  1
    w_31_7    product_ub_79  1
    w_31_7    normalized_mass_31_91  1
    w_31_7    normalized_ratio_31_92  -1
    w_31_7    full_original_Gini_308  -4.1142857142857148e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_8    OBJ       -2.6250000000000002e-02
    x_31_8    product_lb_80  -2.4643548670983981e-02
    x_31_8    product_ub_81  -4.1518386714157786e-02
    x_31_8    onehot_31_90  1
    x_31_8    stock_lb_248  8
    x_31_8    stock_ub_249  8
    x_31_8    parent_nonstrict_scope_250  1.0499999999999995e-02
    x_31_8    unique_nonzero_owner_343  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_8    product_lb_80  1
    w_31_8    product_ub_81  1
    w_31_8    normalized_mass_31_91  1
    w_31_8    normalized_ratio_31_92  -1.1428571428571428e+00
    w_31_8    full_original_Gini_308  -7.11428571428571
    MARKER    'MARKER'                 'INTORG'
    x_31_9    OBJ       -1.5750000000000007e-02
    x_31_9    product_lb_82  -2.4643548670983981e-02
    x_31_9    product_ub_83  -4.1518386714157786e-02
    x_31_9    onehot_31_90  1
    x_31_9    stock_lb_248  9
    x_31_9    stock_ub_249  9
    x_31_9    parent_nonstrict_scope_250  2.0999999999999991e-02
    x_31_9    unique_nonzero_owner_344  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_9    product_lb_82  1
    w_31_9    product_ub_83  1
    w_31_9    normalized_mass_31_91  1
    w_31_9    normalized_ratio_31_92  -1.2857142857142856e+00
    w_31_9    full_original_Gini_308  -1.0628571428571423e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_10   OBJ       -5.2500000000000116e-03
    x_31_10   product_lb_84  -2.4643548670983981e-02
    x_31_10   product_ub_85  -4.1518386714157786e-02
    x_31_10   onehot_31_90  1
    x_31_10   stock_lb_248  10
    x_31_10   stock_ub_249  10
    x_31_10   parent_nonstrict_scope_250  3.1499999999999986e-02
    x_31_10   unique_nonzero_owner_345  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_10   product_lb_84  1
    w_31_10   product_ub_85  1
    w_31_10   normalized_mass_31_91  1
    w_31_10   normalized_ratio_31_92  -1.4285714285714284e+00
    w_31_10   full_original_Gini_308  -1.4485714285714284e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_11   OBJ       5.2499999999999977e-03
    x_31_11   product_lb_86  -2.4643548670983981e-02
    x_31_11   product_ub_87  -4.1518386714157786e-02
    x_31_11   onehot_31_90  1
    x_31_11   stock_lb_248  11
    x_31_11   stock_ub_249  11
    x_31_11   parent_nonstrict_scope_250  4.1999999999999996e-02
    x_31_11   unique_nonzero_owner_346  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_11   product_lb_86  1
    w_31_11   product_ub_87  1
    w_31_11   normalized_mass_31_91  1
    w_31_11   normalized_ratio_31_92  -1.5714285714285714e+00
    w_31_11   full_original_Gini_308  -1.8342857142857145e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_12   OBJ       1.5749999999999993e-02
    x_31_12   product_lb_88  -2.4643548670983981e-02
    x_31_12   product_ub_89  -4.1518386714157786e-02
    x_31_12   onehot_31_90  1
    x_31_12   stock_lb_248  12
    x_31_12   stock_ub_249  12
    x_31_12   parent_nonstrict_scope_250  5.2499999999999991e-02
    x_31_12   unique_nonzero_owner_347  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_12   product_lb_88  1
    w_31_12   product_ub_89  1
    w_31_12   normalized_mass_31_91  1
    w_31_12   normalized_ratio_31_92  -1.7142857142857142e+00
    w_31_12   full_original_Gini_308  -22.2
    rho_31    normalized_ratio_31_92  1
    rho_31    block_pair_pos_265  -1
    rho_31    block_pair_neg_266  1
    rho_31    block_pair_pos_267  -1
    rho_31    block_pair_neg_268  1
    rho_31    block_pair_pos_269  -1
    rho_31    block_pair_neg_270  1
    rho_31    block_pair_pos_271  -1
    rho_31    block_pair_neg_272  1
    rho_31    block_pair_pos_273  -1
    rho_31    block_pair_neg_274  1
    rho_31    block_pair_pos_289  1
    rho_31    block_pair_neg_290  -1
    rho_31    block_pair_pos_301  1
    rho_31    block_pair_neg_302  -1
    rho_31    normalization_307  1
    MARKER    'MARKER'                 'INTORG'
    x_27_0    OBJ       0.0315
    x_27_0    product_lb_93  -2.4643548670983981e-02
    x_27_0    product_ub_94  -4.1518386714157786e-02
    x_27_0    onehot_27_125  1
    x_27_0    parent_nonstrict_scope_250  0.0735
    x_27_0    unique_nonzero_owner_348  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_0    product_lb_93  1
    w_27_0    product_ub_94  1
    w_27_0    normalized_mass_27_126  1
    w_27_0    full_original_Gini_308  -2.4085714285714282e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_1    OBJ       2.1000000000000005e-02
    x_27_1    product_lb_95  -2.4643548670983981e-02
    x_27_1    product_ub_96  -4.1518386714157786e-02
    x_27_1    onehot_27_125  1
    x_27_1    stock_lb_248  1
    x_27_1    stock_ub_249  1
    x_27_1    parent_nonstrict_scope_250  0.063
    x_27_1    unique_nonzero_owner_349  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_1    product_lb_95  1
    w_27_1    product_ub_96  1
    w_27_1    normalized_mass_27_126  1
    w_27_1    normalized_ratio_27_127  -1.4285714285714285e-01
    w_27_1    full_original_Gini_308  -2.0514285714285720e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_2    OBJ       1.0500000000000002e-02
    x_27_2    product_lb_97  -2.4643548670983981e-02
    x_27_2    product_ub_98  -4.1518386714157786e-02
    x_27_2    onehot_27_125  1
    x_27_2    stock_lb_248  2
    x_27_2    stock_ub_249  2
    x_27_2    parent_nonstrict_scope_250  0.0525
    x_27_2    unique_nonzero_owner_350  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_2    product_lb_97  1
    w_27_2    product_ub_98  1
    w_27_2    normalized_mass_27_126  1
    w_27_2    normalized_ratio_27_127  -2.8571428571428570e-01
    w_27_2    full_original_Gini_308  -1.7114285714285714e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_3    product_lb_99  -2.4643548670983981e-02
    x_27_3    product_ub_100  -4.1518386714157786e-02
    x_27_3    onehot_27_125  1
    x_27_3    stock_lb_248  3
    x_27_3    stock_ub_249  3
    x_27_3    parent_nonstrict_scope_250  4.1999999999999996e-02
    x_27_3    unique_nonzero_owner_351  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_3    product_lb_99  1
    w_27_3    product_ub_100  1
    w_27_3    normalized_mass_27_126  1
    w_27_3    normalized_ratio_27_127  -4.2857142857142855e-01
    w_27_3    full_original_Gini_308  -1.3828571428571427e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_4    OBJ       -1.0499999999999995e-02
    x_27_4    product_lb_101  -2.4643548670983981e-02
    x_27_4    product_ub_102  -4.1518386714157786e-02
    x_27_4    onehot_27_125  1
    x_27_4    stock_lb_248  4
    x_27_4    stock_ub_249  4
    x_27_4    parent_nonstrict_scope_250  0.0315
    x_27_4    unique_nonzero_owner_352  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_4    product_lb_101  1
    w_27_4    product_ub_102  1
    w_27_4    normalized_mass_27_126  1
    w_27_4    normalized_ratio_27_127  -5.7142857142857140e-01
    w_27_4    full_original_Gini_308  -1.0542857142857146e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_5    OBJ       -2.0999999999999991e-02
    x_27_5    product_lb_103  -2.4643548670983981e-02
    x_27_5    product_ub_104  -4.1518386714157786e-02
    x_27_5    onehot_27_125  1
    x_27_5    stock_lb_248  5
    x_27_5    stock_ub_249  5
    x_27_5    parent_nonstrict_scope_250  2.1000000000000005e-02
    x_27_5    unique_nonzero_owner_353  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_5    product_lb_103  1
    w_27_5    product_ub_104  1
    w_27_5    normalized_mass_27_126  1
    w_27_5    normalized_ratio_27_127  -7.1428571428571419e-01
    w_27_5    full_original_Gini_308  -7.3523809523809529e+00
    MARKER    'MARKER'                 'INTORG'
    x_27_6    OBJ       -3.1499999999999993e-02
    x_27_6    product_lb_105  -2.4643548670983981e-02
    x_27_6    product_ub_106  -4.1518386714157786e-02
    x_27_6    onehot_27_125  1
    x_27_6    stock_lb_248  6
    x_27_6    stock_ub_249  6
    x_27_6    parent_nonstrict_scope_250  1.0500000000000002e-02
    x_27_6    unique_nonzero_owner_354  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_6    product_lb_105  1
    w_27_6    product_ub_106  1
    w_27_6    normalized_mass_27_126  1
    w_27_6    normalized_ratio_27_127  -8.5714285714285710e-01
    w_27_6    full_original_Gini_308  -5.1857142857142859e+00
    MARKER    'MARKER'                 'INTORG'
    x_27_7    OBJ       -4.1999999999999996e-02
    x_27_7    product_lb_107  -2.4643548670983981e-02
    x_27_7    product_ub_108  -4.1518386714157786e-02
    x_27_7    onehot_27_125  1
    x_27_7    stock_lb_248  7
    x_27_7    stock_ub_249  7
    x_27_7    unique_nonzero_owner_355  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_7    product_lb_107  1
    w_27_7    product_ub_108  1
    w_27_7    normalized_mass_27_126  1
    w_27_7    normalized_ratio_27_127  -1
    w_27_7    full_original_Gini_308  -4.1142857142857148e+00
    MARKER    'MARKER'                 'INTORG'
    x_27_8    OBJ       -0.0315
    x_27_8    product_lb_109  -2.4643548670983981e-02
    x_27_8    product_ub_110  -4.1518386714157786e-02
    x_27_8    onehot_27_125  1
    x_27_8    stock_lb_248  8
    x_27_8    stock_ub_249  8
    x_27_8    parent_nonstrict_scope_250  1.0499999999999995e-02
    x_27_8    unique_nonzero_owner_356  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_8    product_lb_109  1
    w_27_8    product_ub_110  1
    w_27_8    normalized_mass_27_126  1
    w_27_8    normalized_ratio_27_127  -1.1428571428571428e+00
    w_27_8    full_original_Gini_308  -7.11428571428571
    MARKER    'MARKER'                 'INTORG'
    x_27_9    OBJ       -2.1000000000000005e-02
    x_27_9    product_lb_111  -2.4643548670983981e-02
    x_27_9    product_ub_112  -4.1518386714157786e-02
    x_27_9    onehot_27_125  1
    x_27_9    stock_lb_248  9
    x_27_9    stock_ub_249  9
    x_27_9    parent_nonstrict_scope_250  2.0999999999999991e-02
    x_27_9    unique_nonzero_owner_357  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_9    product_lb_111  1
    w_27_9    product_ub_112  1
    w_27_9    normalized_mass_27_126  1
    w_27_9    normalized_ratio_27_127  -1.2857142857142856e+00
    w_27_9    full_original_Gini_308  -1.0628571428571423e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_10   OBJ       -1.0500000000000009e-02
    x_27_10   product_lb_113  -2.4643548670983981e-02
    x_27_10   product_ub_114  -4.1518386714157786e-02
    x_27_10   onehot_27_125  1
    x_27_10   stock_lb_248  10
    x_27_10   stock_ub_249  10
    x_27_10   parent_nonstrict_scope_250  3.1499999999999986e-02
    x_27_10   unique_nonzero_owner_358  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_10   product_lb_113  1
    w_27_10   product_ub_114  1
    w_27_10   normalized_mass_27_126  1
    w_27_10   normalized_ratio_27_127  -1.4285714285714284e+00
    w_27_10   full_original_Gini_308  -1.4485714285714284e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_11   product_lb_115  -2.4643548670983981e-02
    x_27_11   product_ub_116  -4.1518386714157786e-02
    x_27_11   onehot_27_125  1
    x_27_11   stock_lb_248  11
    x_27_11   stock_ub_249  11
    x_27_11   parent_nonstrict_scope_250  4.1999999999999996e-02
    MARKER    'MARKER'                 'INTEND'
    w_27_11   product_lb_115  1
    w_27_11   product_ub_116  1
    w_27_11   normalized_mass_27_126  1
    w_27_11   normalized_ratio_27_127  -1.5714285714285714e+00
    w_27_11   full_original_Gini_308  -1.8342857142857145e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_12   OBJ       1.0499999999999995e-02
    x_27_12   product_lb_117  -2.4643548670983981e-02
    x_27_12   product_ub_118  -4.1518386714157786e-02
    x_27_12   onehot_27_125  1
    x_27_12   stock_lb_248  12
    x_27_12   stock_ub_249  12
    x_27_12   parent_nonstrict_scope_250  5.2499999999999991e-02
    x_27_12   unique_nonzero_owner_359  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_12   product_lb_117  1
    w_27_12   product_ub_118  1
    w_27_12   normalized_mass_27_126  1
    w_27_12   normalized_ratio_27_127  -1.7142857142857142e+00
    w_27_12   full_original_Gini_308  -22.2
    MARKER    'MARKER'                 'INTORG'
    x_27_13   OBJ       2.0999999999999991e-02
    x_27_13   product_lb_119  -2.4643548670983981e-02
    x_27_13   product_ub_120  -4.1518386714157786e-02
    x_27_13   onehot_27_125  1
    x_27_13   stock_lb_248  13
    x_27_13   stock_ub_249  13
    x_27_13   parent_nonstrict_scope_250  6.2999999999999987e-02
    x_27_13   unique_nonzero_owner_360  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_13   product_lb_119  1
    w_27_13   product_ub_120  1
    w_27_13   normalized_mass_27_126  1
    w_27_13   normalized_ratio_27_127  -1.8571428571428570e+00
    w_27_13   full_original_Gini_308  -2.6057142857142860e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_14   OBJ       0.0315
    x_27_14   product_lb_121  -2.4643548670983981e-02
    x_27_14   product_ub_122  -4.1518386714157786e-02
    x_27_14   onehot_27_125  1
    x_27_14   stock_lb_248  14
    x_27_14   stock_ub_249  14
    x_27_14   parent_nonstrict_scope_250  0.0735
    x_27_14   unique_nonzero_owner_361  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_14   product_lb_121  1
    w_27_14   product_ub_122  1
    w_27_14   normalized_mass_27_126  1
    w_27_14   normalized_ratio_27_127  -2
    w_27_14   full_original_Gini_308  -2.9914285714285715e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_15   OBJ       4.1999999999999996e-02
    x_27_15   product_lb_123  -2.4643548670983981e-02
    x_27_15   product_ub_124  -4.1518386714157786e-02
    x_27_15   onehot_27_125  1
    x_27_15   stock_lb_248  15
    x_27_15   stock_ub_249  15
    x_27_15   parent_nonstrict_scope_250  8.3999999999999991e-02
    x_27_15   unique_nonzero_owner_362  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_15   product_lb_123  1
    w_27_15   product_ub_124  1
    w_27_15   normalized_mass_27_126  1
    w_27_15   normalized_ratio_27_127  -2.1428571428571428e+00
    w_27_15   full_original_Gini_308  -3.3771428571428565e+01
    rho_27    normalized_ratio_27_127  1
    rho_27    block_pair_pos_257  -1
    rho_27    block_pair_neg_258  1
    rho_27    block_pair_pos_259  -1
    rho_27    block_pair_neg_260  1
    rho_27    block_pair_pos_261  -1
    rho_27    block_pair_neg_262  1
    rho_27    block_pair_pos_263  -1
    rho_27    block_pair_neg_264  1
    rho_27    block_pair_pos_269  1
    rho_27    block_pair_neg_270  -1
    rho_27    block_pair_pos_285  1
    rho_27    block_pair_neg_286  -1
    rho_27    block_pair_pos_297  1
    rho_27    block_pair_neg_298  -1
    rho_27    normalization_307  1
    MARKER    'MARKER'                 'INTORG'
    x_32_0    OBJ       1.1249999999999993e-02
    x_32_0    product_lb_128  -2.4643548670983981e-02
    x_32_0    product_ub_129  -4.1518386714157786e-02
    x_32_0    onehot_32_154  1
    x_32_0    parent_nonstrict_scope_250  0.0375
    MARKER    'MARKER'                 'INTEND'
    w_32_0    product_lb_128  1
    w_32_0    product_ub_129  1
    w_32_0    normalized_mass_32_155  1
    w_32_0    full_original_Gini_308  -2.4085714285714282e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_1    OBJ       3.7499999999999929e-03
    x_32_1    product_lb_130  -2.4643548670983981e-02
    x_32_1    product_ub_131  -4.1518386714157786e-02
    x_32_1    onehot_32_154  1
    x_32_1    stock_lb_248  1
    x_32_1    stock_ub_249  1
    x_32_1    parent_nonstrict_scope_250  0.03
    x_32_1    unique_nonzero_owner_363  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_1    product_lb_130  1
    w_32_1    product_ub_131  1
    w_32_1    normalized_mass_32_155  1
    w_32_1    normalized_ratio_32_156  -0.2
    w_32_1    full_original_Gini_308  -1.9085714285714289e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_2    OBJ       -3.7500000000000068e-03
    x_32_2    product_lb_132  -2.4643548670983981e-02
    x_32_2    product_ub_133  -4.1518386714157786e-02
    x_32_2    onehot_32_154  1
    x_32_2    stock_lb_248  2
    x_32_2    stock_ub_249  2
    x_32_2    parent_nonstrict_scope_250  0.0225
    x_32_2    unique_nonzero_owner_364  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_2    product_lb_132  1
    w_32_2    product_ub_133  1
    w_32_2    normalized_mass_32_155  1
    w_32_2    normalized_ratio_32_156  -0.4
    w_32_2    full_original_Gini_308  -1.4485714285714286e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_3    OBJ       -1.1250000000000010e-02
    x_32_3    product_lb_134  -2.4643548670983981e-02
    x_32_3    product_ub_135  -4.1518386714157786e-02
    x_32_3    onehot_32_154  1
    x_32_3    stock_lb_248  3
    x_32_3    stock_ub_249  3
    x_32_3    parent_nonstrict_scope_250  1.4999999999999996e-02
    x_32_3    unique_nonzero_owner_365  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_3    product_lb_134  1
    w_32_3    product_ub_135  1
    w_32_3    normalized_mass_32_155  1
    w_32_3    normalized_ratio_32_156  -6.0000000000000009e-01
    w_32_3    full_original_Gini_308  -9.8857142857142861e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_4    OBJ       -1.8750000000000010e-02
    x_32_4    product_lb_136  -2.4643548670983981e-02
    x_32_4    product_ub_137  -4.1518386714157786e-02
    x_32_4    onehot_32_154  1
    x_32_4    stock_lb_248  4
    x_32_4    stock_ub_249  4
    x_32_4    parent_nonstrict_scope_250  7.4999999999999980e-03
    x_32_4    unique_nonzero_owner_366  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_4    product_lb_136  1
    w_32_4    product_ub_137  1
    w_32_4    normalized_mass_32_155  1
    w_32_4    normalized_ratio_32_156  -0.8
    w_32_4    full_original_Gini_308  -5.9952380952380970e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_5    OBJ       -2.6250000000000006e-02
    x_32_5    product_lb_138  -2.4643548670983981e-02
    x_32_5    product_ub_139  -4.1518386714157786e-02
    x_32_5    onehot_32_154  1
    x_32_5    stock_lb_248  5
    x_32_5    stock_ub_249  5
    x_32_5    unique_nonzero_owner_367  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_5    product_lb_138  1
    w_32_5    product_ub_139  1
    w_32_5    normalized_mass_32_155  1
    w_32_5    normalized_ratio_32_156  -1
    w_32_5    full_original_Gini_308  -4.1142857142857148e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_6    OBJ       -0.01875
    x_32_6    product_lb_140  -2.4643548670983981e-02
    x_32_6    product_ub_141  -4.1518386714157786e-02
    x_32_6    onehot_32_154  1
    x_32_6    stock_lb_248  6
    x_32_6    stock_ub_249  6
    x_32_6    parent_nonstrict_scope_250  7.5000000000000067e-03
    x_32_6    unique_nonzero_owner_368  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_6    product_lb_140  1
    w_32_6    product_ub_141  1
    w_32_6    normalized_mass_32_155  1
    w_32_6    normalized_ratio_32_156  -1.2000000000000002e+00
    w_32_6    full_original_Gini_308  -8.3142857142857167e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_7    OBJ       -1.1250000000000001e-02
    x_32_7    product_lb_142  -2.4643548670983981e-02
    x_32_7    product_ub_143  -4.1518386714157786e-02
    x_32_7    onehot_32_154  1
    x_32_7    stock_lb_248  7
    x_32_7    stock_ub_249  7
    x_32_7    parent_nonstrict_scope_250  1.5000000000000005e-02
    x_32_7    unique_nonzero_owner_369  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_7    product_lb_142  1
    w_32_7    product_ub_143  1
    w_32_7    normalized_mass_32_155  1
    w_32_7    normalized_ratio_32_156  -1.4000000000000001e+00
    w_32_7    full_original_Gini_308  -1.3714285714285719e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_8    OBJ       -3.7500000000000033e-03
    x_32_8    product_lb_144  -2.4643548670983981e-02
    x_32_8    product_ub_145  -4.1518386714157786e-02
    x_32_8    onehot_32_154  1
    x_32_8    stock_lb_248  8
    x_32_8    stock_ub_249  8
    x_32_8    parent_nonstrict_scope_250  2.2500000000000003e-02
    x_32_8    unique_nonzero_owner_370  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_8    product_lb_144  1
    w_32_8    product_ub_145  1
    w_32_8    normalized_mass_32_155  1
    w_32_8    normalized_ratio_32_156  -1.6
    w_32_8    full_original_Gini_308  -1.9114285714285721e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_9    OBJ       3.7499999999999929e-03
    x_32_9    product_lb_146  -2.4643548670983981e-02
    x_32_9    product_ub_147  -4.1518386714157786e-02
    x_32_9    onehot_32_154  1
    x_32_9    stock_lb_248  9
    x_32_9    stock_ub_249  9
    x_32_9    parent_nonstrict_scope_250  0.03
    x_32_9    unique_nonzero_owner_371  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_9    product_lb_146  1
    w_32_9    product_ub_147  1
    w_32_9    normalized_mass_32_155  1
    w_32_9    normalized_ratio_32_156  -1.8
    w_32_9    full_original_Gini_308  -2.4514285714285723e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_10   OBJ       1.1249999999999993e-02
    x_32_10   product_lb_148  -2.4643548670983981e-02
    x_32_10   product_ub_149  -4.1518386714157786e-02
    x_32_10   onehot_32_154  1
    x_32_10   stock_lb_248  10
    x_32_10   stock_ub_249  10
    x_32_10   parent_nonstrict_scope_250  0.0375
    x_32_10   unique_nonzero_owner_372  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_10   product_lb_148  1
    w_32_10   product_ub_149  1
    w_32_10   normalized_mass_32_155  1
    w_32_10   normalized_ratio_32_156  -2
    w_32_10   full_original_Gini_308  -2.9914285714285715e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_11   OBJ       0.01875
    x_32_11   product_lb_150  -2.4643548670983981e-02
    x_32_11   product_ub_151  -4.1518386714157786e-02
    x_32_11   onehot_32_154  1
    x_32_11   stock_lb_248  11
    x_32_11   stock_ub_249  11
    x_32_11   parent_nonstrict_scope_250  4.5000000000000005e-02
    x_32_11   unique_nonzero_owner_373  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_11   product_lb_150  1
    w_32_11   product_ub_151  1
    w_32_11   normalized_mass_32_155  1
    w_32_11   normalized_ratio_32_156  -2.2
    w_32_11   full_original_Gini_308  -3.5314285714285724e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_12   OBJ       2.6250000000000006e-02
    x_32_12   product_lb_152  -2.4643548670983981e-02
    x_32_12   product_ub_153  -4.1518386714157786e-02
    x_32_12   onehot_32_154  1
    x_32_12   stock_lb_248  12
    x_32_12   stock_ub_249  12
    x_32_12   parent_nonstrict_scope_250  5.2500000000000012e-02
    x_32_12   unique_nonzero_owner_374  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_12   product_lb_152  1
    w_32_12   product_ub_153  1
    w_32_12   normalized_mass_32_155  1
    w_32_12   normalized_ratio_32_156  -2.4000000000000004e+00
    w_32_12   full_original_Gini_308  -4.0714285714285708e+01
    rho_32    normalized_ratio_32_156  1
    rho_32    block_pair_pos_263  1
    rho_32    block_pair_neg_264  -1
    rho_32    block_pair_pos_273  1
    rho_32    block_pair_neg_274  -1
    rho_32    block_pair_pos_275  -1
    rho_32    block_pair_neg_276  1
    rho_32    block_pair_pos_277  -1
    rho_32    block_pair_neg_278  1
    rho_32    block_pair_pos_279  -1
    rho_32    block_pair_neg_280  1
    rho_32    block_pair_pos_291  1
    rho_32    block_pair_neg_292  -1
    rho_32    block_pair_pos_303  1
    rho_32    block_pair_neg_304  -1
    rho_32    normalization_307  1
    MARKER    'MARKER'                 'INTORG'
    x_24_0    OBJ       0.048
    x_24_0    product_lb_157  -2.4643548670983981e-02
    x_24_0    product_ub_158  -4.1518386714157786e-02
    x_24_0    onehot_24_189  1
    x_24_0    parent_nonstrict_scope_250  0.096
    x_24_0    unique_nonzero_owner_375  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_0    product_lb_157  1
    w_24_0    product_ub_158  1
    w_24_0    normalized_mass_24_190  1
    w_24_0    full_original_Gini_308  -2.4085714285714282e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_1    OBJ       3.6000000000000004e-02
    x_24_1    product_lb_159  -2.4643548670983981e-02
    x_24_1    product_ub_160  -4.1518386714157786e-02
    x_24_1    onehot_24_189  1
    x_24_1    stock_lb_248  1
    x_24_1    stock_ub_249  1
    x_24_1    parent_nonstrict_scope_250  0.084
    x_24_1    unique_nonzero_owner_376  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_1    product_lb_159  1
    w_24_1    product_ub_160  1
    w_24_1    normalized_mass_24_190  1
    w_24_1    normalized_ratio_24_191  -0.125
    w_24_1    full_original_Gini_308  -2.0960714285714285e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_2    OBJ       2.4000000000000007e-02
    x_24_2    product_lb_161  -2.4643548670983981e-02
    x_24_2    product_ub_162  -4.1518386714157786e-02
    x_24_2    onehot_24_189  1
    x_24_2    stock_lb_248  2
    x_24_2    stock_ub_249  2
    x_24_2    parent_nonstrict_scope_250  7.2000000000000008e-02
    x_24_2    unique_nonzero_owner_377  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_2    product_lb_161  1
    w_24_2    product_ub_162  1
    w_24_2    normalized_mass_24_190  1
    w_24_2    normalized_ratio_24_191  -0.25
    w_24_2    full_original_Gini_308  -1.7935714285714283e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_3    OBJ       1.1999999999999997e-02
    x_24_3    product_lb_163  -2.4643548670983981e-02
    x_24_3    product_ub_164  -4.1518386714157786e-02
    x_24_3    onehot_24_189  1
    x_24_3    stock_lb_248  3
    x_24_3    stock_ub_249  3
    x_24_3    parent_nonstrict_scope_250  0.06
    x_24_3    unique_nonzero_owner_378  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_3    product_lb_163  1
    w_24_3    product_ub_164  1
    w_24_3    normalized_mass_24_190  1
    w_24_3    normalized_ratio_24_191  -0.375
    w_24_3    full_original_Gini_308  -1.5060714285714285e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_4    product_lb_165  -2.4643548670983981e-02
    x_24_4    product_ub_166  -4.1518386714157786e-02
    x_24_4    onehot_24_189  1
    x_24_4    stock_lb_248  4
    x_24_4    stock_ub_249  4
    x_24_4    parent_nonstrict_scope_250  0.048
    x_24_4    unique_nonzero_owner_379  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_4    product_lb_165  1
    w_24_4    product_ub_166  1
    w_24_4    normalized_mass_24_190  1
    w_24_4    normalized_ratio_24_191  -0.5
    w_24_4    full_original_Gini_308  -1.2185714285714285e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_5    OBJ       -1.1999999999999997e-02
    x_24_5    product_lb_167  -2.4643548670983981e-02
    x_24_5    product_ub_168  -4.1518386714157786e-02
    x_24_5    onehot_24_189  1
    x_24_5    stock_lb_248  5
    x_24_5    stock_ub_249  5
    x_24_5    parent_nonstrict_scope_250  3.6000000000000004e-02
    x_24_5    unique_nonzero_owner_380  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_5    product_lb_167  1
    w_24_5    product_ub_168  1
    w_24_5    normalized_mass_24_190  1
    w_24_5    normalized_ratio_24_191  -0.625
    w_24_5    full_original_Gini_308  -9.3107142857142868e+00
    MARKER    'MARKER'                 'INTORG'
    x_24_6    OBJ       -0.024
    x_24_6    product_lb_169  -2.4643548670983981e-02
    x_24_6    product_ub_170  -4.1518386714157786e-02
    x_24_6    onehot_24_189  1
    x_24_6    stock_lb_248  6
    x_24_6    stock_ub_249  6
    x_24_6    parent_nonstrict_scope_250  0.024
    x_24_6    unique_nonzero_owner_381  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_6    product_lb_169  1
    w_24_6    product_ub_170  1
    w_24_6    normalized_mass_24_190  1
    w_24_6    normalized_ratio_24_191  -0.75
    w_24_6    full_original_Gini_308  -6.7452380952380961e+00
    MARKER    'MARKER'                 'INTORG'
    x_24_7    OBJ       -3.6000000000000004e-02
    x_24_7    product_lb_171  -2.4643548670983981e-02
    x_24_7    product_ub_172  -4.1518386714157786e-02
    x_24_7    onehot_24_189  1
    x_24_7    stock_lb_248  7
    x_24_7    stock_ub_249  7
    x_24_7    parent_nonstrict_scope_250  0.012
    x_24_7    unique_nonzero_owner_382  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_7    product_lb_171  1
    w_24_7    product_ub_172  1
    w_24_7    normalized_mass_24_190  1
    w_24_7    normalized_ratio_24_191  -0.875
    w_24_7    full_original_Gini_308  -4.9892857142857148e+00
    MARKER    'MARKER'                 'INTORG'
    x_24_8    OBJ       -0.048
    x_24_8    product_lb_173  -2.4643548670983981e-02
    x_24_8    product_ub_174  -4.1518386714157786e-02
    x_24_8    onehot_24_189  1
    x_24_8    stock_lb_248  8
    x_24_8    stock_ub_249  8
    x_24_8    unique_nonzero_owner_383  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_8    product_lb_173  1
    w_24_8    product_ub_174  1
    w_24_8    normalized_mass_24_190  1
    w_24_8    normalized_ratio_24_191  -1
    w_24_8    full_original_Gini_308  -4.1142857142857148e+00
    MARKER    'MARKER'                 'INTORG'
    x_24_9    OBJ       -3.6000000000000004e-02
    x_24_9    product_lb_175  -2.4643548670983981e-02
    x_24_9    product_ub_176  -4.1518386714157786e-02
    x_24_9    onehot_24_189  1
    x_24_9    stock_lb_248  9
    x_24_9    stock_ub_249  9
    x_24_9    parent_nonstrict_scope_250  0.012
    x_24_9    unique_nonzero_owner_384  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_9    product_lb_175  1
    w_24_9    product_ub_176  1
    w_24_9    normalized_mass_24_190  1
    w_24_9    normalized_ratio_24_191  -1.125
    w_24_9    full_original_Gini_308  -6.7392857142857148e+00
    MARKER    'MARKER'                 'INTORG'
    x_24_10   OBJ       -0.024
    x_24_10   product_lb_177  -2.4643548670983981e-02
    x_24_10   product_ub_178  -4.1518386714157786e-02
    x_24_10   onehot_24_189  1
    x_24_10   stock_lb_248  10
    x_24_10   stock_ub_249  10
    x_24_10   parent_nonstrict_scope_250  0.024
    x_24_10   unique_nonzero_owner_385  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_10   product_lb_177  1
    w_24_10   product_ub_178  1
    w_24_10   normalized_mass_24_190  1
    w_24_10   normalized_ratio_24_191  -1.25
    w_24_10   full_original_Gini_308  -9.6642857142857146e+00
    MARKER    'MARKER'                 'INTORG'
    x_24_11   OBJ       -1.1999999999999997e-02
    x_24_11   product_lb_179  -2.4643548670983981e-02
    x_24_11   product_ub_180  -4.1518386714157786e-02
    x_24_11   onehot_24_189  1
    x_24_11   stock_lb_248  11
    x_24_11   stock_ub_249  11
    x_24_11   parent_nonstrict_scope_250  3.6000000000000004e-02
    MARKER    'MARKER'                 'INTEND'
    w_24_11   product_lb_179  1
    w_24_11   product_ub_180  1
    w_24_11   normalized_mass_24_190  1
    w_24_11   normalized_ratio_24_191  -1.375
    w_24_11   full_original_Gini_308  -1.3039285714285713e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_12   product_lb_181  -2.4643548670983981e-02
    x_24_12   product_ub_182  -4.1518386714157786e-02
    x_24_12   onehot_24_189  1
    x_24_12   stock_lb_248  12
    x_24_12   stock_ub_249  12
    x_24_12   parent_nonstrict_scope_250  0.048
    x_24_12   unique_nonzero_owner_386  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_12   product_lb_181  1
    w_24_12   product_ub_182  1
    w_24_12   normalized_mass_24_190  1
    w_24_12   normalized_ratio_24_191  -1.5
    w_24_12   full_original_Gini_308  -1.6414285714285718e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_13   OBJ       1.1999999999999997e-02
    x_24_13   product_lb_183  -2.4643548670983981e-02
    x_24_13   product_ub_184  -4.1518386714157786e-02
    x_24_13   onehot_24_189  1
    x_24_13   stock_lb_248  13
    x_24_13   stock_ub_249  13
    x_24_13   parent_nonstrict_scope_250  0.06
    x_24_13   unique_nonzero_owner_387  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_13   product_lb_183  1
    w_24_13   product_ub_184  1
    w_24_13   normalized_mass_24_190  1
    w_24_13   normalized_ratio_24_191  -1.625
    w_24_13   full_original_Gini_308  -1.9789285714285711e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_14   OBJ       2.4000000000000007e-02
    x_24_14   product_lb_185  -2.4643548670983981e-02
    x_24_14   product_ub_186  -4.1518386714157786e-02
    x_24_14   onehot_24_189  1
    x_24_14   stock_lb_248  14
    x_24_14   stock_ub_249  14
    x_24_14   parent_nonstrict_scope_250  7.2000000000000008e-02
    x_24_14   unique_nonzero_owner_388  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_14   product_lb_185  1
    w_24_14   product_ub_186  1
    w_24_14   normalized_mass_24_190  1
    w_24_14   normalized_ratio_24_191  -1.75
    w_24_14   full_original_Gini_308  -2.3164285714285715e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_15   OBJ       3.6000000000000004e-02
    x_24_15   product_lb_187  -2.4643548670983981e-02
    x_24_15   product_ub_188  -4.1518386714157786e-02
    x_24_15   onehot_24_189  1
    x_24_15   stock_lb_248  15
    x_24_15   stock_ub_249  15
    x_24_15   parent_nonstrict_scope_250  0.084
    x_24_15   unique_nonzero_owner_389  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_15   product_lb_187  1
    w_24_15   product_ub_188  1
    w_24_15   normalized_mass_24_190  1
    w_24_15   normalized_ratio_24_191  -1.875
    w_24_15   full_original_Gini_308  -2.6539285714285718e+01
    rho_24    normalized_ratio_24_191  1
    rho_24    block_pair_pos_253  -1
    rho_24    block_pair_neg_254  1
    rho_24    block_pair_pos_255  -1
    rho_24    block_pair_neg_256  1
    rho_24    block_pair_pos_259  1
    rho_24    block_pair_neg_260  -1
    rho_24    block_pair_pos_267  1
    rho_24    block_pair_neg_268  -1
    rho_24    block_pair_pos_277  1
    rho_24    block_pair_neg_278  -1
    rho_24    block_pair_pos_283  1
    rho_24    block_pair_neg_284  -1
    rho_24    block_pair_pos_295  1
    rho_24    block_pair_neg_296  -1
    rho_24    normalization_307  1
    MARKER    'MARKER'                 'INTORG'
    x_19_0    OBJ       0.012
    x_19_0    product_lb_192  -2.4643548670983981e-02
    x_19_0    product_ub_193  -4.1518386714157786e-02
    x_19_0    onehot_19_210  1
    x_19_0    parent_nonstrict_scope_250  0.024
    MARKER    'MARKER'                 'INTEND'
    w_19_0    product_lb_192  1
    w_19_0    product_ub_193  1
    w_19_0    normalized_mass_19_211  1
    w_19_0    full_original_Gini_308  -2.4085714285714282e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_1    OBJ       6.0000000000000019e-03
    x_19_1    product_lb_194  -2.4643548670983981e-02
    x_19_1    product_ub_195  -4.1518386714157786e-02
    x_19_1    onehot_19_210  1
    x_19_1    stock_lb_248  1
    x_19_1    stock_ub_249  1
    x_19_1    parent_nonstrict_scope_250  1.8000000000000002e-02
    x_19_1    unique_nonzero_owner_390  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_1    product_lb_194  1
    w_19_1    product_ub_195  1
    w_19_1    normalized_mass_19_211  1
    w_19_1    normalized_ratio_19_212  -0.25
    w_19_1    full_original_Gini_308  -1.7935714285714283e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_2    product_lb_196  -2.4643548670983981e-02
    x_19_2    product_ub_197  -4.1518386714157786e-02
    x_19_2    onehot_19_210  1
    x_19_2    stock_lb_248  2
    x_19_2    stock_ub_249  2
    x_19_2    parent_nonstrict_scope_250  0.012
    x_19_2    unique_nonzero_owner_391  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_2    product_lb_196  1
    w_19_2    product_ub_197  1
    w_19_2    normalized_mass_19_211  1
    w_19_2    normalized_ratio_19_212  -0.5
    w_19_2    full_original_Gini_308  -1.2185714285714285e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_3    OBJ       -0.006
    x_19_3    product_lb_198  -2.4643548670983981e-02
    x_19_3    product_ub_199  -4.1518386714157786e-02
    x_19_3    onehot_19_210  1
    x_19_3    stock_lb_248  3
    x_19_3    stock_ub_249  3
    x_19_3    parent_nonstrict_scope_250  0.006
    x_19_3    unique_nonzero_owner_392  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_3    product_lb_198  1
    w_19_3    product_ub_199  1
    w_19_3    normalized_mass_19_211  1
    w_19_3    normalized_ratio_19_212  -0.75
    w_19_3    full_original_Gini_308  -6.7452380952380961e+00
    MARKER    'MARKER'                 'INTORG'
    x_19_4    OBJ       -0.012
    x_19_4    product_lb_200  -2.4643548670983981e-02
    x_19_4    product_ub_201  -4.1518386714157786e-02
    x_19_4    onehot_19_210  1
    x_19_4    stock_lb_248  4
    x_19_4    stock_ub_249  4
    x_19_4    unique_nonzero_owner_393  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_4    product_lb_200  1
    w_19_4    product_ub_201  1
    w_19_4    normalized_mass_19_211  1
    w_19_4    normalized_ratio_19_212  -1
    w_19_4    full_original_Gini_308  -4.1142857142857148e+00
    MARKER    'MARKER'                 'INTORG'
    x_19_5    OBJ       -0.006
    x_19_5    product_lb_202  -2.4643548670983981e-02
    x_19_5    product_ub_203  -4.1518386714157786e-02
    x_19_5    onehot_19_210  1
    x_19_5    stock_lb_248  5
    x_19_5    stock_ub_249  5
    x_19_5    parent_nonstrict_scope_250  0.006
    x_19_5    unique_nonzero_owner_394  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_5    product_lb_202  1
    w_19_5    product_ub_203  1
    w_19_5    normalized_mass_19_211  1
    w_19_5    normalized_ratio_19_212  -1.25
    w_19_5    full_original_Gini_308  -9.6642857142857146e+00
    MARKER    'MARKER'                 'INTORG'
    x_19_6    product_lb_204  -2.4643548670983981e-02
    x_19_6    product_ub_205  -4.1518386714157786e-02
    x_19_6    onehot_19_210  1
    x_19_6    stock_lb_248  6
    x_19_6    stock_ub_249  6
    x_19_6    parent_nonstrict_scope_250  0.012
    x_19_6    unique_nonzero_owner_395  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_6    product_lb_204  1
    w_19_6    product_ub_205  1
    w_19_6    normalized_mass_19_211  1
    w_19_6    normalized_ratio_19_212  -1.5
    w_19_6    full_original_Gini_308  -1.6414285714285718e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_7    OBJ       6.0000000000000019e-03
    x_19_7    product_lb_206  -2.4643548670983981e-02
    x_19_7    product_ub_207  -4.1518386714157786e-02
    x_19_7    onehot_19_210  1
    x_19_7    stock_lb_248  7
    x_19_7    stock_ub_249  7
    x_19_7    parent_nonstrict_scope_250  1.8000000000000002e-02
    x_19_7    unique_nonzero_owner_396  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_7    product_lb_206  1
    w_19_7    product_ub_207  1
    w_19_7    normalized_mass_19_211  1
    w_19_7    normalized_ratio_19_212  -1.75
    w_19_7    full_original_Gini_308  -2.3164285714285715e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_8    OBJ       0.012
    x_19_8    product_lb_208  -2.4643548670983981e-02
    x_19_8    product_ub_209  -4.1518386714157786e-02
    x_19_8    onehot_19_210  1
    x_19_8    stock_lb_248  8
    x_19_8    stock_ub_249  8
    x_19_8    parent_nonstrict_scope_250  0.024
    x_19_8    unique_nonzero_owner_397  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_8    product_lb_208  1
    w_19_8    product_ub_209  1
    w_19_8    normalized_mass_19_211  1
    w_19_8    normalized_ratio_19_212  -2
    w_19_8    full_original_Gini_308  -2.9914285714285715e+01
    rho_19    normalized_ratio_19_212  1
    rho_19    block_pair_pos_251  -1
    rho_19    block_pair_neg_252  1
    rho_19    block_pair_pos_253  1
    rho_19    block_pair_neg_254  -1
    rho_19    block_pair_pos_257  1
    rho_19    block_pair_neg_258  -1
    rho_19    block_pair_pos_265  1
    rho_19    block_pair_neg_266  -1
    rho_19    block_pair_pos_275  1
    rho_19    block_pair_neg_276  -1
    rho_19    block_pair_pos_281  1
    rho_19    block_pair_neg_282  -1
    rho_19    block_pair_pos_293  1
    rho_19    block_pair_neg_294  -1
    rho_19    normalization_307  1
    MARKER    'MARKER'                 'INTORG'
    x_29_0    OBJ       0.048
    x_29_0    product_lb_213  -2.4643548670983981e-02
    x_29_0    product_ub_214  -4.1518386714157786e-02
    x_29_0    onehot_29_245  1
    x_29_0    parent_nonstrict_scope_250  0.096
    x_29_0    unique_nonzero_owner_398  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_0    product_lb_213  1
    w_29_0    product_ub_214  1
    w_29_0    normalized_mass_29_246  1
    w_29_0    full_original_Gini_308  -2.4085714285714282e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_1    OBJ       3.6000000000000004e-02
    x_29_1    product_lb_215  -2.4643548670983981e-02
    x_29_1    product_ub_216  -4.1518386714157786e-02
    x_29_1    onehot_29_245  1
    x_29_1    stock_lb_248  1
    x_29_1    stock_ub_249  1
    x_29_1    parent_nonstrict_scope_250  0.084
    x_29_1    unique_nonzero_owner_399  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_1    product_lb_215  1
    w_29_1    product_ub_216  1
    w_29_1    normalized_mass_29_246  1
    w_29_1    normalized_ratio_29_247  -0.125
    w_29_1    full_original_Gini_308  -2.0960714285714285e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_2    OBJ       2.4000000000000007e-02
    x_29_2    product_lb_217  -2.4643548670983981e-02
    x_29_2    product_ub_218  -4.1518386714157786e-02
    x_29_2    onehot_29_245  1
    x_29_2    stock_lb_248  2
    x_29_2    stock_ub_249  2
    x_29_2    parent_nonstrict_scope_250  7.2000000000000008e-02
    x_29_2    unique_nonzero_owner_400  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_2    product_lb_217  1
    w_29_2    product_ub_218  1
    w_29_2    normalized_mass_29_246  1
    w_29_2    normalized_ratio_29_247  -0.25
    w_29_2    full_original_Gini_308  -1.7935714285714283e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_3    OBJ       1.1999999999999997e-02
    x_29_3    product_lb_219  -2.4643548670983981e-02
    x_29_3    product_ub_220  -4.1518386714157786e-02
    x_29_3    onehot_29_245  1
    x_29_3    stock_lb_248  3
    x_29_3    stock_ub_249  3
    x_29_3    parent_nonstrict_scope_250  0.06
    x_29_3    unique_nonzero_owner_401  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_3    product_lb_219  1
    w_29_3    product_ub_220  1
    w_29_3    normalized_mass_29_246  1
    w_29_3    normalized_ratio_29_247  -0.375
    w_29_3    full_original_Gini_308  -1.5060714285714285e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_4    product_lb_221  -2.4643548670983981e-02
    x_29_4    product_ub_222  -4.1518386714157786e-02
    x_29_4    onehot_29_245  1
    x_29_4    stock_lb_248  4
    x_29_4    stock_ub_249  4
    x_29_4    parent_nonstrict_scope_250  0.048
    x_29_4    unique_nonzero_owner_402  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_4    product_lb_221  1
    w_29_4    product_ub_222  1
    w_29_4    normalized_mass_29_246  1
    w_29_4    normalized_ratio_29_247  -0.5
    w_29_4    full_original_Gini_308  -1.2185714285714285e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_5    OBJ       -1.1999999999999997e-02
    x_29_5    product_lb_223  -2.4643548670983981e-02
    x_29_5    product_ub_224  -4.1518386714157786e-02
    x_29_5    onehot_29_245  1
    x_29_5    stock_lb_248  5
    x_29_5    stock_ub_249  5
    x_29_5    parent_nonstrict_scope_250  3.6000000000000004e-02
    x_29_5    unique_nonzero_owner_403  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_5    product_lb_223  1
    w_29_5    product_ub_224  1
    w_29_5    normalized_mass_29_246  1
    w_29_5    normalized_ratio_29_247  -0.625
    w_29_5    full_original_Gini_308  -9.3107142857142868e+00
    MARKER    'MARKER'                 'INTORG'
    x_29_6    OBJ       -0.024
    x_29_6    product_lb_225  -2.4643548670983981e-02
    x_29_6    product_ub_226  -4.1518386714157786e-02
    x_29_6    onehot_29_245  1
    x_29_6    stock_lb_248  6
    x_29_6    stock_ub_249  6
    x_29_6    parent_nonstrict_scope_250  0.024
    x_29_6    unique_nonzero_owner_404  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_6    product_lb_225  1
    w_29_6    product_ub_226  1
    w_29_6    normalized_mass_29_246  1
    w_29_6    normalized_ratio_29_247  -0.75
    w_29_6    full_original_Gini_308  -6.7452380952380961e+00
    MARKER    'MARKER'                 'INTORG'
    x_29_7    OBJ       -3.6000000000000004e-02
    x_29_7    product_lb_227  -2.4643548670983981e-02
    x_29_7    product_ub_228  -4.1518386714157786e-02
    x_29_7    onehot_29_245  1
    x_29_7    stock_lb_248  7
    x_29_7    stock_ub_249  7
    x_29_7    parent_nonstrict_scope_250  0.012
    x_29_7    unique_nonzero_owner_405  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_7    product_lb_227  1
    w_29_7    product_ub_228  1
    w_29_7    normalized_mass_29_246  1
    w_29_7    normalized_ratio_29_247  -0.875
    w_29_7    full_original_Gini_308  -4.9892857142857148e+00
    MARKER    'MARKER'                 'INTORG'
    x_29_8    OBJ       -0.048
    x_29_8    product_lb_229  -2.4643548670983981e-02
    x_29_8    product_ub_230  -4.1518386714157786e-02
    x_29_8    onehot_29_245  1
    x_29_8    stock_lb_248  8
    x_29_8    stock_ub_249  8
    x_29_8    unique_nonzero_owner_406  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_8    product_lb_229  1
    w_29_8    product_ub_230  1
    w_29_8    normalized_mass_29_246  1
    w_29_8    normalized_ratio_29_247  -1
    w_29_8    full_original_Gini_308  -4.1142857142857148e+00
    MARKER    'MARKER'                 'INTORG'
    x_29_9    OBJ       -3.6000000000000004e-02
    x_29_9    product_lb_231  -2.4643548670983981e-02
    x_29_9    product_ub_232  -4.1518386714157786e-02
    x_29_9    onehot_29_245  1
    x_29_9    stock_lb_248  9
    x_29_9    stock_ub_249  9
    x_29_9    parent_nonstrict_scope_250  0.012
    x_29_9    unique_nonzero_owner_407  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_9    product_lb_231  1
    w_29_9    product_ub_232  1
    w_29_9    normalized_mass_29_246  1
    w_29_9    normalized_ratio_29_247  -1.125
    w_29_9    full_original_Gini_308  -6.7392857142857148e+00
    MARKER    'MARKER'                 'INTORG'
    x_29_10   OBJ       -0.024
    x_29_10   product_lb_233  -2.4643548670983981e-02
    x_29_10   product_ub_234  -4.1518386714157786e-02
    x_29_10   onehot_29_245  1
    x_29_10   stock_lb_248  10
    x_29_10   stock_ub_249  10
    x_29_10   parent_nonstrict_scope_250  0.024
    x_29_10   unique_nonzero_owner_408  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_10   product_lb_233  1
    w_29_10   product_ub_234  1
    w_29_10   normalized_mass_29_246  1
    w_29_10   normalized_ratio_29_247  -1.25
    w_29_10   full_original_Gini_308  -9.6642857142857146e+00
    MARKER    'MARKER'                 'INTORG'
    x_29_11   OBJ       -1.1999999999999997e-02
    x_29_11   product_lb_235  -2.4643548670983981e-02
    x_29_11   product_ub_236  -4.1518386714157786e-02
    x_29_11   onehot_29_245  1
    x_29_11   stock_lb_248  11
    x_29_11   stock_ub_249  11
    x_29_11   parent_nonstrict_scope_250  3.6000000000000004e-02
    MARKER    'MARKER'                 'INTEND'
    w_29_11   product_lb_235  1
    w_29_11   product_ub_236  1
    w_29_11   normalized_mass_29_246  1
    w_29_11   normalized_ratio_29_247  -1.375
    w_29_11   full_original_Gini_308  -1.3039285714285713e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_12   product_lb_237  -2.4643548670983981e-02
    x_29_12   product_ub_238  -4.1518386714157786e-02
    x_29_12   onehot_29_245  1
    x_29_12   stock_lb_248  12
    x_29_12   stock_ub_249  12
    x_29_12   parent_nonstrict_scope_250  0.048
    x_29_12   unique_nonzero_owner_409  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_12   product_lb_237  1
    w_29_12   product_ub_238  1
    w_29_12   normalized_mass_29_246  1
    w_29_12   normalized_ratio_29_247  -1.5
    w_29_12   full_original_Gini_308  -1.6414285714285718e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_13   OBJ       1.1999999999999997e-02
    x_29_13   product_lb_239  -2.4643548670983981e-02
    x_29_13   product_ub_240  -4.1518386714157786e-02
    x_29_13   onehot_29_245  1
    x_29_13   stock_lb_248  13
    x_29_13   stock_ub_249  13
    x_29_13   parent_nonstrict_scope_250  0.06
    x_29_13   unique_nonzero_owner_410  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_13   product_lb_239  1
    w_29_13   product_ub_240  1
    w_29_13   normalized_mass_29_246  1
    w_29_13   normalized_ratio_29_247  -1.625
    w_29_13   full_original_Gini_308  -1.9789285714285711e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_14   OBJ       2.4000000000000007e-02
    x_29_14   product_lb_241  -2.4643548670983981e-02
    x_29_14   product_ub_242  -4.1518386714157786e-02
    x_29_14   onehot_29_245  1
    x_29_14   stock_lb_248  14
    x_29_14   stock_ub_249  14
    x_29_14   parent_nonstrict_scope_250  7.2000000000000008e-02
    x_29_14   unique_nonzero_owner_411  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_14   product_lb_241  1
    w_29_14   product_ub_242  1
    w_29_14   normalized_mass_29_246  1
    w_29_14   normalized_ratio_29_247  -1.75
    w_29_14   full_original_Gini_308  -2.3164285714285715e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_15   OBJ       3.6000000000000004e-02
    x_29_15   product_lb_243  -2.4643548670983981e-02
    x_29_15   product_ub_244  -4.1518386714157786e-02
    x_29_15   onehot_29_245  1
    x_29_15   stock_lb_248  15
    x_29_15   stock_ub_249  15
    x_29_15   parent_nonstrict_scope_250  0.084
    x_29_15   unique_nonzero_owner_412  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_15   product_lb_243  1
    w_29_15   product_ub_244  1
    w_29_15   normalized_mass_29_246  1
    w_29_15   normalized_ratio_29_247  -1.875
    w_29_15   full_original_Gini_308  -2.6539285714285718e+01
    rho_29    normalized_ratio_29_247  1
    rho_29    block_pair_pos_251  1
    rho_29    block_pair_neg_252  -1
    rho_29    block_pair_pos_255  1
    rho_29    block_pair_neg_256  -1
    rho_29    block_pair_pos_261  1
    rho_29    block_pair_neg_262  -1
    rho_29    block_pair_pos_271  1
    rho_29    block_pair_neg_272  -1
    rho_29    block_pair_pos_279  1
    rho_29    block_pair_neg_280  -1
    rho_29    block_pair_pos_287  1
    rho_29    block_pair_neg_288  -1
    rho_29    block_pair_pos_299  1
    rho_29    block_pair_neg_300  -1
    rho_29    normalization_307  1
    a_34_33   block_pair_pos_305  1
    a_34_33   block_pair_neg_306  1
    a_34_33   full_original_Gini_308  -1
    a_34_31   block_pair_pos_301  1
    a_34_31   block_pair_neg_302  1
    a_34_31   full_original_Gini_308  -1
    a_34_27   block_pair_pos_297  1
    a_34_27   block_pair_neg_298  1
    a_34_27   full_original_Gini_308  -1
    a_34_32   block_pair_pos_303  1
    a_34_32   block_pair_neg_304  1
    a_34_32   full_original_Gini_308  -1
    a_34_24   block_pair_pos_295  1
    a_34_24   block_pair_neg_296  1
    a_34_24   full_original_Gini_308  -1
    a_34_19   block_pair_pos_293  1
    a_34_19   block_pair_neg_294  1
    a_34_19   full_original_Gini_308  -1
    a_34_29   block_pair_pos_299  1
    a_34_29   block_pair_neg_300  1
    a_34_29   full_original_Gini_308  -1
    a_33_31   block_pair_pos_289  1
    a_33_31   block_pair_neg_290  1
    a_33_31   full_original_Gini_308  -1
    a_33_27   block_pair_pos_285  1
    a_33_27   block_pair_neg_286  1
    a_33_27   full_original_Gini_308  -1
    a_33_32   block_pair_pos_291  1
    a_33_32   block_pair_neg_292  1
    a_33_32   full_original_Gini_308  -1
    a_33_24   block_pair_pos_283  1
    a_33_24   block_pair_neg_284  1
    a_33_24   full_original_Gini_308  -1
    a_33_19   block_pair_pos_281  1
    a_33_19   block_pair_neg_282  1
    a_33_19   full_original_Gini_308  -1
    a_33_29   block_pair_pos_287  1
    a_33_29   block_pair_neg_288  1
    a_33_29   full_original_Gini_308  -1
    a_31_27   block_pair_pos_269  1
    a_31_27   block_pair_neg_270  1
    a_31_27   full_original_Gini_308  -1
    a_31_32   block_pair_pos_273  1
    a_31_32   block_pair_neg_274  1
    a_31_32   full_original_Gini_308  -1
    a_31_24   block_pair_pos_267  1
    a_31_24   block_pair_neg_268  1
    a_31_24   full_original_Gini_308  -1
    a_31_19   block_pair_pos_265  1
    a_31_19   block_pair_neg_266  1
    a_31_19   full_original_Gini_308  -1
    a_31_29   block_pair_pos_271  1
    a_31_29   block_pair_neg_272  1
    a_31_29   full_original_Gini_308  -1
    a_27_32   block_pair_pos_263  1
    a_27_32   block_pair_neg_264  1
    a_27_32   full_original_Gini_308  -1
    a_27_24   block_pair_pos_259  1
    a_27_24   block_pair_neg_260  1
    a_27_24   full_original_Gini_308  -1
    a_27_19   block_pair_pos_257  1
    a_27_19   block_pair_neg_258  1
    a_27_19   full_original_Gini_308  -1
    a_27_29   block_pair_pos_261  1
    a_27_29   block_pair_neg_262  1
    a_27_29   full_original_Gini_308  -1
    a_32_24   block_pair_pos_277  1
    a_32_24   block_pair_neg_278  1
    a_32_24   full_original_Gini_308  -1
    a_32_19   block_pair_pos_275  1
    a_32_19   block_pair_neg_276  1
    a_32_19   full_original_Gini_308  -1
    a_32_29   block_pair_pos_279  1
    a_32_29   block_pair_neg_280  1
    a_32_29   full_original_Gini_308  -1
    a_24_19   block_pair_pos_253  1
    a_24_19   block_pair_neg_254  1
    a_24_19   full_original_Gini_308  -1
    a_24_29   block_pair_pos_255  1
    a_24_29   block_pair_neg_256  1
    a_24_29   full_original_Gini_308  -1
    a_19_29   block_pair_pos_251  1
    a_19_29   block_pair_neg_252  1
    a_19_29   full_original_Gini_308  -1
    MARKER    'MARKER'                 'INTORG'
    service_0_34_0  unique_nonzero_owner_309  1
    service_0_34_0  service_visit_def_736  1
    service_0_34_0  free_load_conservation_737  -1
    service_0_34_0  original_T_including_depot_unload_783  120
    service_0_34_2  unique_nonzero_owner_310  1
    service_0_34_2  service_visit_def_736  1
    service_0_34_2  free_load_conservation_737  1
    service_0_34_3  unique_nonzero_owner_311  1
    service_0_34_3  service_visit_def_736  1
    service_0_34_3  free_load_conservation_737  2
    service_0_34_4  unique_nonzero_owner_312  1
    service_0_34_4  service_visit_def_736  1
    service_0_34_4  free_load_conservation_737  3
    service_0_34_5  unique_nonzero_owner_313  1
    service_0_34_5  service_visit_def_736  1
    service_0_34_5  free_load_conservation_737  4
    service_0_34_6  unique_nonzero_owner_314  1
    service_0_34_6  service_visit_def_736  1
    service_0_34_6  free_load_conservation_737  5
    service_0_34_7  unique_nonzero_owner_315  1
    service_0_34_7  service_visit_def_736  1
    service_0_34_7  free_load_conservation_737  6
    service_0_34_8  unique_nonzero_owner_316  1
    service_0_34_8  service_visit_def_736  1
    service_0_34_8  free_load_conservation_737  7
    service_0_34_9  unique_nonzero_owner_317  1
    service_0_34_9  service_visit_def_736  1
    service_0_34_9  free_load_conservation_737  8
    service_0_34_10  unique_nonzero_owner_318  1
    service_0_34_10  service_visit_def_736  1
    service_0_34_10  free_load_conservation_737  9
    service_0_34_11  unique_nonzero_owner_319  1
    service_0_34_11  service_visit_def_736  1
    service_0_34_11  free_load_conservation_737  10
    service_1_34_0  unique_nonzero_owner_309  1
    service_1_34_0  service_visit_def_1164  1
    service_1_34_0  free_load_conservation_1165  -1
    service_1_34_0  original_T_including_depot_unload_1212  120
    service_1_34_2  unique_nonzero_owner_310  1
    service_1_34_2  service_visit_def_1164  1
    service_1_34_2  free_load_conservation_1165  1
    service_1_34_3  unique_nonzero_owner_311  1
    service_1_34_3  service_visit_def_1164  1
    service_1_34_3  free_load_conservation_1165  2
    service_1_34_4  unique_nonzero_owner_312  1
    service_1_34_4  service_visit_def_1164  1
    service_1_34_4  free_load_conservation_1165  3
    service_1_34_5  unique_nonzero_owner_313  1
    service_1_34_5  service_visit_def_1164  1
    service_1_34_5  free_load_conservation_1165  4
    service_1_34_6  unique_nonzero_owner_314  1
    service_1_34_6  service_visit_def_1164  1
    service_1_34_6  free_load_conservation_1165  5
    service_1_34_7  unique_nonzero_owner_315  1
    service_1_34_7  service_visit_def_1164  1
    service_1_34_7  free_load_conservation_1165  6
    service_1_34_8  unique_nonzero_owner_316  1
    service_1_34_8  service_visit_def_1164  1
    service_1_34_8  free_load_conservation_1165  7
    service_1_34_9  unique_nonzero_owner_317  1
    service_1_34_9  service_visit_def_1164  1
    service_1_34_9  free_load_conservation_1165  8
    service_1_34_10  unique_nonzero_owner_318  1
    service_1_34_10  service_visit_def_1164  1
    service_1_34_10  free_load_conservation_1165  9
    service_1_34_11  unique_nonzero_owner_319  1
    service_1_34_11  service_visit_def_1164  1
    service_1_34_11  free_load_conservation_1165  10
    service_2_34_0  unique_nonzero_owner_309  1
    service_2_34_0  service_visit_def_1483  1
    service_2_34_0  free_load_conservation_1484  -1
    service_2_34_0  original_T_including_depot_unload_1529  120
    service_2_34_2  unique_nonzero_owner_310  1
    service_2_34_2  service_visit_def_1483  1
    service_2_34_2  free_load_conservation_1484  1
    service_2_34_3  unique_nonzero_owner_311  1
    service_2_34_3  service_visit_def_1483  1
    service_2_34_3  free_load_conservation_1484  2
    service_2_34_4  unique_nonzero_owner_312  1
    service_2_34_4  service_visit_def_1483  1
    service_2_34_4  free_load_conservation_1484  3
    service_2_34_5  unique_nonzero_owner_313  1
    service_2_34_5  service_visit_def_1483  1
    service_2_34_5  free_load_conservation_1484  4
    service_2_34_6  unique_nonzero_owner_314  1
    service_2_34_6  service_visit_def_1483  1
    service_2_34_6  free_load_conservation_1484  5
    service_2_34_7  unique_nonzero_owner_315  1
    service_2_34_7  service_visit_def_1483  1
    service_2_34_7  free_load_conservation_1484  6
    service_2_34_8  unique_nonzero_owner_316  1
    service_2_34_8  service_visit_def_1483  1
    service_2_34_8  free_load_conservation_1484  7
    service_2_34_9  unique_nonzero_owner_317  1
    service_2_34_9  service_visit_def_1483  1
    service_2_34_9  free_load_conservation_1484  8
    service_2_34_10  unique_nonzero_owner_318  1
    service_2_34_10  service_visit_def_1483  1
    service_2_34_10  free_load_conservation_1484  9
    service_2_34_11  unique_nonzero_owner_319  1
    service_2_34_11  service_visit_def_1483  1
    service_2_34_11  free_load_conservation_1484  10
    service_0_33_0  unique_nonzero_owner_320  1
    service_0_33_0  service_visit_def_742  1
    service_0_33_0  free_load_conservation_743  -1
    service_0_33_0  original_T_including_depot_unload_783  120
    service_0_33_2  unique_nonzero_owner_321  1
    service_0_33_2  service_visit_def_742  1
    service_0_33_2  free_load_conservation_743  1
    service_0_33_3  unique_nonzero_owner_322  1
    service_0_33_3  service_visit_def_742  1
    service_0_33_3  free_load_conservation_743  2
    service_0_33_4  unique_nonzero_owner_323  1
    service_0_33_4  service_visit_def_742  1
    service_0_33_4  free_load_conservation_743  3
    service_0_33_5  unique_nonzero_owner_324  1
    service_0_33_5  service_visit_def_742  1
    service_0_33_5  free_load_conservation_743  4
    service_0_33_6  unique_nonzero_owner_325  1
    service_0_33_6  service_visit_def_742  1
    service_0_33_6  free_load_conservation_743  5
    service_0_33_7  unique_nonzero_owner_326  1
    service_0_33_7  service_visit_def_742  1
    service_0_33_7  free_load_conservation_743  6
    service_0_33_8  unique_nonzero_owner_327  1
    service_0_33_8  service_visit_def_742  1
    service_0_33_8  free_load_conservation_743  7
    service_0_33_9  unique_nonzero_owner_328  1
    service_0_33_9  service_visit_def_742  1
    service_0_33_9  free_load_conservation_743  8
    service_0_33_10  unique_nonzero_owner_329  1
    service_0_33_10  service_visit_def_742  1
    service_0_33_10  free_load_conservation_743  9
    service_0_33_11  unique_nonzero_owner_330  1
    service_0_33_11  service_visit_def_742  1
    service_0_33_11  free_load_conservation_743  10
    service_0_33_12  unique_nonzero_owner_331  1
    service_0_33_12  service_visit_def_742  1
    service_0_33_12  free_load_conservation_743  11
    service_0_33_13  unique_nonzero_owner_332  1
    service_0_33_13  service_visit_def_742  1
    service_0_33_13  free_load_conservation_743  12
    service_0_33_14  unique_nonzero_owner_333  1
    service_0_33_14  service_visit_def_742  1
    service_0_33_14  free_load_conservation_743  13
    service_0_33_15  unique_nonzero_owner_334  1
    service_0_33_15  service_visit_def_742  1
    service_0_33_15  free_load_conservation_743  14
    service_0_33_16  unique_nonzero_owner_335  1
    service_0_33_16  service_visit_def_742  1
    service_0_33_16  free_load_conservation_743  15
    service_1_33_0  unique_nonzero_owner_320  1
    service_1_33_0  service_visit_def_1170  1
    service_1_33_0  free_load_conservation_1171  -1
    service_1_33_0  original_T_including_depot_unload_1212  120
    service_1_33_2  unique_nonzero_owner_321  1
    service_1_33_2  service_visit_def_1170  1
    service_1_33_2  free_load_conservation_1171  1
    service_1_33_3  unique_nonzero_owner_322  1
    service_1_33_3  service_visit_def_1170  1
    service_1_33_3  free_load_conservation_1171  2
    service_1_33_4  unique_nonzero_owner_323  1
    service_1_33_4  service_visit_def_1170  1
    service_1_33_4  free_load_conservation_1171  3
    service_1_33_5  unique_nonzero_owner_324  1
    service_1_33_5  service_visit_def_1170  1
    service_1_33_5  free_load_conservation_1171  4
    service_1_33_6  unique_nonzero_owner_325  1
    service_1_33_6  service_visit_def_1170  1
    service_1_33_6  free_load_conservation_1171  5
    service_1_33_7  unique_nonzero_owner_326  1
    service_1_33_7  service_visit_def_1170  1
    service_1_33_7  free_load_conservation_1171  6
    service_1_33_8  unique_nonzero_owner_327  1
    service_1_33_8  service_visit_def_1170  1
    service_1_33_8  free_load_conservation_1171  7
    service_1_33_9  unique_nonzero_owner_328  1
    service_1_33_9  service_visit_def_1170  1
    service_1_33_9  free_load_conservation_1171  8
    service_1_33_10  unique_nonzero_owner_329  1
    service_1_33_10  service_visit_def_1170  1
    service_1_33_10  free_load_conservation_1171  9
    service_1_33_11  unique_nonzero_owner_330  1
    service_1_33_11  service_visit_def_1170  1
    service_1_33_11  free_load_conservation_1171  10
    service_1_33_12  unique_nonzero_owner_331  1
    service_1_33_12  service_visit_def_1170  1
    service_1_33_12  free_load_conservation_1171  11
    service_1_33_13  unique_nonzero_owner_332  1
    service_1_33_13  service_visit_def_1170  1
    service_1_33_13  free_load_conservation_1171  12
    service_1_33_14  unique_nonzero_owner_333  1
    service_1_33_14  service_visit_def_1170  1
    service_1_33_14  free_load_conservation_1171  13
    service_1_33_15  unique_nonzero_owner_334  1
    service_1_33_15  service_visit_def_1170  1
    service_1_33_15  free_load_conservation_1171  14
    service_1_33_16  unique_nonzero_owner_335  1
    service_1_33_16  service_visit_def_1170  1
    service_1_33_16  free_load_conservation_1171  15
    service_2_33_0  unique_nonzero_owner_320  1
    service_2_33_0  service_visit_def_1489  1
    service_2_33_0  free_load_conservation_1490  -1
    service_2_33_0  original_T_including_depot_unload_1529  120
    service_2_33_2  unique_nonzero_owner_321  1
    service_2_33_2  service_visit_def_1489  1
    service_2_33_2  free_load_conservation_1490  1
    service_2_33_3  unique_nonzero_owner_322  1
    service_2_33_3  service_visit_def_1489  1
    service_2_33_3  free_load_conservation_1490  2
    service_2_33_4  unique_nonzero_owner_323  1
    service_2_33_4  service_visit_def_1489  1
    service_2_33_4  free_load_conservation_1490  3
    service_2_33_5  unique_nonzero_owner_324  1
    service_2_33_5  service_visit_def_1489  1
    service_2_33_5  free_load_conservation_1490  4
    service_2_33_6  unique_nonzero_owner_325  1
    service_2_33_6  service_visit_def_1489  1
    service_2_33_6  free_load_conservation_1490  5
    service_2_33_7  unique_nonzero_owner_326  1
    service_2_33_7  service_visit_def_1489  1
    service_2_33_7  free_load_conservation_1490  6
    service_2_33_8  unique_nonzero_owner_327  1
    service_2_33_8  service_visit_def_1489  1
    service_2_33_8  free_load_conservation_1490  7
    service_2_33_9  unique_nonzero_owner_328  1
    service_2_33_9  service_visit_def_1489  1
    service_2_33_9  free_load_conservation_1490  8
    service_2_33_10  unique_nonzero_owner_329  1
    service_2_33_10  service_visit_def_1489  1
    service_2_33_10  free_load_conservation_1490  9
    service_2_33_11  unique_nonzero_owner_330  1
    service_2_33_11  service_visit_def_1489  1
    service_2_33_11  free_load_conservation_1490  10
    service_2_33_12  unique_nonzero_owner_331  1
    service_2_33_12  service_visit_def_1489  1
    service_2_33_12  free_load_conservation_1490  11
    service_2_33_13  unique_nonzero_owner_332  1
    service_2_33_13  service_visit_def_1489  1
    service_2_33_13  free_load_conservation_1490  12
    service_2_33_14  unique_nonzero_owner_333  1
    service_2_33_14  service_visit_def_1489  1
    service_2_33_14  free_load_conservation_1490  13
    service_2_33_15  unique_nonzero_owner_334  1
    service_2_33_15  service_visit_def_1489  1
    service_2_33_15  free_load_conservation_1490  14
    service_2_33_16  unique_nonzero_owner_335  1
    service_2_33_16  service_visit_def_1489  1
    service_2_33_16  free_load_conservation_1490  15
    service_0_31_0  unique_nonzero_owner_336  1
    service_0_31_0  service_visit_def_748  1
    service_0_31_0  free_load_conservation_749  -2
    service_0_31_0  original_T_including_depot_unload_783  240
    service_0_31_1  unique_nonzero_owner_337  1
    service_0_31_1  service_visit_def_748  1
    service_0_31_1  free_load_conservation_749  -1
    service_0_31_1  original_T_including_depot_unload_783  120
    service_0_31_3  unique_nonzero_owner_338  1
    service_0_31_3  service_visit_def_748  1
    service_0_31_3  free_load_conservation_749  1
    service_0_31_4  unique_nonzero_owner_339  1
    service_0_31_4  service_visit_def_748  1
    service_0_31_4  free_load_conservation_749  2
    service_0_31_5  unique_nonzero_owner_340  1
    service_0_31_5  service_visit_def_748  1
    service_0_31_5  free_load_conservation_749  3
    service_0_31_6  unique_nonzero_owner_341  1
    service_0_31_6  service_visit_def_748  1
    service_0_31_6  free_load_conservation_749  4
    service_0_31_7  unique_nonzero_owner_342  1
    service_0_31_7  service_visit_def_748  1
    service_0_31_7  free_load_conservation_749  5
    service_0_31_8  unique_nonzero_owner_343  1
    service_0_31_8  service_visit_def_748  1
    service_0_31_8  free_load_conservation_749  6
    service_0_31_9  unique_nonzero_owner_344  1
    service_0_31_9  service_visit_def_748  1
    service_0_31_9  free_load_conservation_749  7
    service_0_31_10  unique_nonzero_owner_345  1
    service_0_31_10  service_visit_def_748  1
    service_0_31_10  free_load_conservation_749  8
    service_0_31_11  unique_nonzero_owner_346  1
    service_0_31_11  service_visit_def_748  1
    service_0_31_11  free_load_conservation_749  9
    service_0_31_12  unique_nonzero_owner_347  1
    service_0_31_12  service_visit_def_748  1
    service_0_31_12  free_load_conservation_749  10
    service_1_31_0  unique_nonzero_owner_336  1
    service_1_31_0  service_visit_def_1176  1
    service_1_31_0  free_load_conservation_1177  -2
    service_1_31_0  original_T_including_depot_unload_1212  240
    service_1_31_1  unique_nonzero_owner_337  1
    service_1_31_1  service_visit_def_1176  1
    service_1_31_1  free_load_conservation_1177  -1
    service_1_31_1  original_T_including_depot_unload_1212  120
    service_1_31_3  unique_nonzero_owner_338  1
    service_1_31_3  service_visit_def_1176  1
    service_1_31_3  free_load_conservation_1177  1
    service_1_31_4  unique_nonzero_owner_339  1
    service_1_31_4  service_visit_def_1176  1
    service_1_31_4  free_load_conservation_1177  2
    service_1_31_5  unique_nonzero_owner_340  1
    service_1_31_5  service_visit_def_1176  1
    service_1_31_5  free_load_conservation_1177  3
    service_1_31_6  unique_nonzero_owner_341  1
    service_1_31_6  service_visit_def_1176  1
    service_1_31_6  free_load_conservation_1177  4
    service_1_31_7  unique_nonzero_owner_342  1
    service_1_31_7  service_visit_def_1176  1
    service_1_31_7  free_load_conservation_1177  5
    service_1_31_8  unique_nonzero_owner_343  1
    service_1_31_8  service_visit_def_1176  1
    service_1_31_8  free_load_conservation_1177  6
    service_1_31_9  unique_nonzero_owner_344  1
    service_1_31_9  service_visit_def_1176  1
    service_1_31_9  free_load_conservation_1177  7
    service_1_31_10  unique_nonzero_owner_345  1
    service_1_31_10  service_visit_def_1176  1
    service_1_31_10  free_load_conservation_1177  8
    service_1_31_11  unique_nonzero_owner_346  1
    service_1_31_11  service_visit_def_1176  1
    service_1_31_11  free_load_conservation_1177  9
    service_1_31_12  unique_nonzero_owner_347  1
    service_1_31_12  service_visit_def_1176  1
    service_1_31_12  free_load_conservation_1177  10
    service_2_31_0  unique_nonzero_owner_336  1
    service_2_31_0  service_visit_def_1495  1
    service_2_31_0  free_load_conservation_1496  -2
    service_2_31_0  original_T_including_depot_unload_1529  240
    service_2_31_1  unique_nonzero_owner_337  1
    service_2_31_1  service_visit_def_1495  1
    service_2_31_1  free_load_conservation_1496  -1
    service_2_31_1  original_T_including_depot_unload_1529  120
    service_2_31_3  unique_nonzero_owner_338  1
    service_2_31_3  service_visit_def_1495  1
    service_2_31_3  free_load_conservation_1496  1
    service_2_31_4  unique_nonzero_owner_339  1
    service_2_31_4  service_visit_def_1495  1
    service_2_31_4  free_load_conservation_1496  2
    service_2_31_5  unique_nonzero_owner_340  1
    service_2_31_5  service_visit_def_1495  1
    service_2_31_5  free_load_conservation_1496  3
    service_2_31_6  unique_nonzero_owner_341  1
    service_2_31_6  service_visit_def_1495  1
    service_2_31_6  free_load_conservation_1496  4
    service_2_31_7  unique_nonzero_owner_342  1
    service_2_31_7  service_visit_def_1495  1
    service_2_31_7  free_load_conservation_1496  5
    service_2_31_8  unique_nonzero_owner_343  1
    service_2_31_8  service_visit_def_1495  1
    service_2_31_8  free_load_conservation_1496  6
    service_2_31_9  unique_nonzero_owner_344  1
    service_2_31_9  service_visit_def_1495  1
    service_2_31_9  free_load_conservation_1496  7
    service_2_31_10  unique_nonzero_owner_345  1
    service_2_31_10  service_visit_def_1495  1
    service_2_31_10  free_load_conservation_1496  8
    service_2_31_11  unique_nonzero_owner_346  1
    service_2_31_11  service_visit_def_1495  1
    service_2_31_11  free_load_conservation_1496  9
    service_2_31_12  unique_nonzero_owner_347  1
    service_2_31_12  service_visit_def_1495  1
    service_2_31_12  free_load_conservation_1496  10
    service_0_27_0  unique_nonzero_owner_348  1
    service_0_27_0  service_visit_def_754  1
    service_0_27_0  free_load_conservation_755  -11
    service_0_27_0  original_T_including_depot_unload_783  1320
    service_0_27_1  unique_nonzero_owner_349  1
    service_0_27_1  service_visit_def_754  1
    service_0_27_1  free_load_conservation_755  -10
    service_0_27_1  original_T_including_depot_unload_783  1200
    service_0_27_2  unique_nonzero_owner_350  1
    service_0_27_2  service_visit_def_754  1
    service_0_27_2  free_load_conservation_755  -9
    service_0_27_2  original_T_including_depot_unload_783  1080
    service_0_27_3  unique_nonzero_owner_351  1
    service_0_27_3  service_visit_def_754  1
    service_0_27_3  free_load_conservation_755  -8
    service_0_27_3  original_T_including_depot_unload_783  960
    service_0_27_4  unique_nonzero_owner_352  1
    service_0_27_4  service_visit_def_754  1
    service_0_27_4  free_load_conservation_755  -7
    service_0_27_4  original_T_including_depot_unload_783  840
    service_0_27_5  unique_nonzero_owner_353  1
    service_0_27_5  service_visit_def_754  1
    service_0_27_5  free_load_conservation_755  -6
    service_0_27_5  original_T_including_depot_unload_783  720
    service_0_27_6  unique_nonzero_owner_354  1
    service_0_27_6  service_visit_def_754  1
    service_0_27_6  free_load_conservation_755  -5
    service_0_27_6  original_T_including_depot_unload_783  600
    service_0_27_7  unique_nonzero_owner_355  1
    service_0_27_7  service_visit_def_754  1
    service_0_27_7  free_load_conservation_755  -4
    service_0_27_7  original_T_including_depot_unload_783  480
    service_0_27_8  unique_nonzero_owner_356  1
    service_0_27_8  service_visit_def_754  1
    service_0_27_8  free_load_conservation_755  -3
    service_0_27_8  original_T_including_depot_unload_783  360
    service_0_27_9  unique_nonzero_owner_357  1
    service_0_27_9  service_visit_def_754  1
    service_0_27_9  free_load_conservation_755  -2
    service_0_27_9  original_T_including_depot_unload_783  240
    service_0_27_10  unique_nonzero_owner_358  1
    service_0_27_10  service_visit_def_754  1
    service_0_27_10  free_load_conservation_755  -1
    service_0_27_10  original_T_including_depot_unload_783  120
    service_0_27_12  unique_nonzero_owner_359  1
    service_0_27_12  service_visit_def_754  1
    service_0_27_12  free_load_conservation_755  1
    service_0_27_13  unique_nonzero_owner_360  1
    service_0_27_13  service_visit_def_754  1
    service_0_27_13  free_load_conservation_755  2
    service_0_27_14  unique_nonzero_owner_361  1
    service_0_27_14  service_visit_def_754  1
    service_0_27_14  free_load_conservation_755  3
    service_0_27_15  unique_nonzero_owner_362  1
    service_0_27_15  service_visit_def_754  1
    service_0_27_15  free_load_conservation_755  4
    service_1_27_0  unique_nonzero_owner_348  1
    service_1_27_0  service_visit_def_1182  1
    service_1_27_0  free_load_conservation_1183  -11
    service_1_27_0  original_T_including_depot_unload_1212  1320
    service_1_27_1  unique_nonzero_owner_349  1
    service_1_27_1  service_visit_def_1182  1
    service_1_27_1  free_load_conservation_1183  -10
    service_1_27_1  original_T_including_depot_unload_1212  1200
    service_1_27_2  unique_nonzero_owner_350  1
    service_1_27_2  service_visit_def_1182  1
    service_1_27_2  free_load_conservation_1183  -9
    service_1_27_2  original_T_including_depot_unload_1212  1080
    service_1_27_3  unique_nonzero_owner_351  1
    service_1_27_3  service_visit_def_1182  1
    service_1_27_3  free_load_conservation_1183  -8
    service_1_27_3  original_T_including_depot_unload_1212  960
    service_1_27_4  unique_nonzero_owner_352  1
    service_1_27_4  service_visit_def_1182  1
    service_1_27_4  free_load_conservation_1183  -7
    service_1_27_4  original_T_including_depot_unload_1212  840
    service_1_27_5  unique_nonzero_owner_353  1
    service_1_27_5  service_visit_def_1182  1
    service_1_27_5  free_load_conservation_1183  -6
    service_1_27_5  original_T_including_depot_unload_1212  720
    service_1_27_6  unique_nonzero_owner_354  1
    service_1_27_6  service_visit_def_1182  1
    service_1_27_6  free_load_conservation_1183  -5
    service_1_27_6  original_T_including_depot_unload_1212  600
    service_1_27_7  unique_nonzero_owner_355  1
    service_1_27_7  service_visit_def_1182  1
    service_1_27_7  free_load_conservation_1183  -4
    service_1_27_7  original_T_including_depot_unload_1212  480
    service_1_27_8  unique_nonzero_owner_356  1
    service_1_27_8  service_visit_def_1182  1
    service_1_27_8  free_load_conservation_1183  -3
    service_1_27_8  original_T_including_depot_unload_1212  360
    service_1_27_9  unique_nonzero_owner_357  1
    service_1_27_9  service_visit_def_1182  1
    service_1_27_9  free_load_conservation_1183  -2
    service_1_27_9  original_T_including_depot_unload_1212  240
    service_1_27_10  unique_nonzero_owner_358  1
    service_1_27_10  service_visit_def_1182  1
    service_1_27_10  free_load_conservation_1183  -1
    service_1_27_10  original_T_including_depot_unload_1212  120
    service_1_27_12  unique_nonzero_owner_359  1
    service_1_27_12  service_visit_def_1182  1
    service_1_27_12  free_load_conservation_1183  1
    service_1_27_13  unique_nonzero_owner_360  1
    service_1_27_13  service_visit_def_1182  1
    service_1_27_13  free_load_conservation_1183  2
    service_1_27_14  unique_nonzero_owner_361  1
    service_1_27_14  service_visit_def_1182  1
    service_1_27_14  free_load_conservation_1183  3
    service_1_27_15  unique_nonzero_owner_362  1
    service_1_27_15  service_visit_def_1182  1
    service_1_27_15  free_load_conservation_1183  4
    service_2_27_0  unique_nonzero_owner_348  1
    service_2_27_0  service_visit_def_1501  1
    service_2_27_0  free_load_conservation_1502  -11
    service_2_27_0  original_T_including_depot_unload_1529  1320
    service_2_27_1  unique_nonzero_owner_349  1
    service_2_27_1  service_visit_def_1501  1
    service_2_27_1  free_load_conservation_1502  -10
    service_2_27_1  original_T_including_depot_unload_1529  1200
    service_2_27_2  unique_nonzero_owner_350  1
    service_2_27_2  service_visit_def_1501  1
    service_2_27_2  free_load_conservation_1502  -9
    service_2_27_2  original_T_including_depot_unload_1529  1080
    service_2_27_3  unique_nonzero_owner_351  1
    service_2_27_3  service_visit_def_1501  1
    service_2_27_3  free_load_conservation_1502  -8
    service_2_27_3  original_T_including_depot_unload_1529  960
    service_2_27_4  unique_nonzero_owner_352  1
    service_2_27_4  service_visit_def_1501  1
    service_2_27_4  free_load_conservation_1502  -7
    service_2_27_4  original_T_including_depot_unload_1529  840
    service_2_27_5  unique_nonzero_owner_353  1
    service_2_27_5  service_visit_def_1501  1
    service_2_27_5  free_load_conservation_1502  -6
    service_2_27_5  original_T_including_depot_unload_1529  720
    service_2_27_6  unique_nonzero_owner_354  1
    service_2_27_6  service_visit_def_1501  1
    service_2_27_6  free_load_conservation_1502  -5
    service_2_27_6  original_T_including_depot_unload_1529  600
    service_2_27_7  unique_nonzero_owner_355  1
    service_2_27_7  service_visit_def_1501  1
    service_2_27_7  free_load_conservation_1502  -4
    service_2_27_7  original_T_including_depot_unload_1529  480
    service_2_27_8  unique_nonzero_owner_356  1
    service_2_27_8  service_visit_def_1501  1
    service_2_27_8  free_load_conservation_1502  -3
    service_2_27_8  original_T_including_depot_unload_1529  360
    service_2_27_9  unique_nonzero_owner_357  1
    service_2_27_9  service_visit_def_1501  1
    service_2_27_9  free_load_conservation_1502  -2
    service_2_27_9  original_T_including_depot_unload_1529  240
    service_2_27_10  unique_nonzero_owner_358  1
    service_2_27_10  service_visit_def_1501  1
    service_2_27_10  free_load_conservation_1502  -1
    service_2_27_10  original_T_including_depot_unload_1529  120
    service_2_27_12  unique_nonzero_owner_359  1
    service_2_27_12  service_visit_def_1501  1
    service_2_27_12  free_load_conservation_1502  1
    service_2_27_13  unique_nonzero_owner_360  1
    service_2_27_13  service_visit_def_1501  1
    service_2_27_13  free_load_conservation_1502  2
    service_2_27_14  unique_nonzero_owner_361  1
    service_2_27_14  service_visit_def_1501  1
    service_2_27_14  free_load_conservation_1502  3
    service_2_27_15  unique_nonzero_owner_362  1
    service_2_27_15  service_visit_def_1501  1
    service_2_27_15  free_load_conservation_1502  4
    service_0_32_1  unique_nonzero_owner_363  1
    service_0_32_1  service_visit_def_760  1
    service_0_32_1  free_load_conservation_761  1
    service_0_32_2  unique_nonzero_owner_364  1
    service_0_32_2  service_visit_def_760  1
    service_0_32_2  free_load_conservation_761  2
    service_0_32_3  unique_nonzero_owner_365  1
    service_0_32_3  service_visit_def_760  1
    service_0_32_3  free_load_conservation_761  3
    service_0_32_4  unique_nonzero_owner_366  1
    service_0_32_4  service_visit_def_760  1
    service_0_32_4  free_load_conservation_761  4
    service_0_32_5  unique_nonzero_owner_367  1
    service_0_32_5  service_visit_def_760  1
    service_0_32_5  free_load_conservation_761  5
    service_0_32_6  unique_nonzero_owner_368  1
    service_0_32_6  service_visit_def_760  1
    service_0_32_6  free_load_conservation_761  6
    service_0_32_7  unique_nonzero_owner_369  1
    service_0_32_7  service_visit_def_760  1
    service_0_32_7  free_load_conservation_761  7
    service_0_32_8  unique_nonzero_owner_370  1
    service_0_32_8  service_visit_def_760  1
    service_0_32_8  free_load_conservation_761  8
    service_0_32_9  unique_nonzero_owner_371  1
    service_0_32_9  service_visit_def_760  1
    service_0_32_9  free_load_conservation_761  9
    service_0_32_10  unique_nonzero_owner_372  1
    service_0_32_10  service_visit_def_760  1
    service_0_32_10  free_load_conservation_761  10
    service_0_32_11  unique_nonzero_owner_373  1
    service_0_32_11  service_visit_def_760  1
    service_0_32_11  free_load_conservation_761  11
    service_0_32_12  unique_nonzero_owner_374  1
    service_0_32_12  service_visit_def_760  1
    service_0_32_12  free_load_conservation_761  12
    service_1_32_1  unique_nonzero_owner_363  1
    service_1_32_1  service_visit_def_1188  1
    service_1_32_1  free_load_conservation_1189  1
    service_1_32_2  unique_nonzero_owner_364  1
    service_1_32_2  service_visit_def_1188  1
    service_1_32_2  free_load_conservation_1189  2
    service_1_32_3  unique_nonzero_owner_365  1
    service_1_32_3  service_visit_def_1188  1
    service_1_32_3  free_load_conservation_1189  3
    service_1_32_4  unique_nonzero_owner_366  1
    service_1_32_4  service_visit_def_1188  1
    service_1_32_4  free_load_conservation_1189  4
    service_1_32_5  unique_nonzero_owner_367  1
    service_1_32_5  service_visit_def_1188  1
    service_1_32_5  free_load_conservation_1189  5
    service_1_32_6  unique_nonzero_owner_368  1
    service_1_32_6  service_visit_def_1188  1
    service_1_32_6  free_load_conservation_1189  6
    service_1_32_7  unique_nonzero_owner_369  1
    service_1_32_7  service_visit_def_1188  1
    service_1_32_7  free_load_conservation_1189  7
    service_1_32_8  unique_nonzero_owner_370  1
    service_1_32_8  service_visit_def_1188  1
    service_1_32_8  free_load_conservation_1189  8
    service_1_32_9  unique_nonzero_owner_371  1
    service_1_32_9  service_visit_def_1188  1
    service_1_32_9  free_load_conservation_1189  9
    service_1_32_10  unique_nonzero_owner_372  1
    service_1_32_10  service_visit_def_1188  1
    service_1_32_10  free_load_conservation_1189  10
    service_1_32_11  unique_nonzero_owner_373  1
    service_1_32_11  service_visit_def_1188  1
    service_1_32_11  free_load_conservation_1189  11
    service_1_32_12  unique_nonzero_owner_374  1
    service_1_32_12  service_visit_def_1188  1
    service_1_32_12  free_load_conservation_1189  12
    service_2_32_1  unique_nonzero_owner_363  1
    service_2_32_1  service_visit_def_1507  1
    service_2_32_1  free_load_conservation_1508  1
    service_2_32_2  unique_nonzero_owner_364  1
    service_2_32_2  service_visit_def_1507  1
    service_2_32_2  free_load_conservation_1508  2
    service_2_32_3  unique_nonzero_owner_365  1
    service_2_32_3  service_visit_def_1507  1
    service_2_32_3  free_load_conservation_1508  3
    service_2_32_4  unique_nonzero_owner_366  1
    service_2_32_4  service_visit_def_1507  1
    service_2_32_4  free_load_conservation_1508  4
    service_2_32_5  unique_nonzero_owner_367  1
    service_2_32_5  service_visit_def_1507  1
    service_2_32_5  free_load_conservation_1508  5
    service_2_32_6  unique_nonzero_owner_368  1
    service_2_32_6  service_visit_def_1507  1
    service_2_32_6  free_load_conservation_1508  6
    service_2_32_7  unique_nonzero_owner_369  1
    service_2_32_7  service_visit_def_1507  1
    service_2_32_7  free_load_conservation_1508  7
    service_2_32_8  unique_nonzero_owner_370  1
    service_2_32_8  service_visit_def_1507  1
    service_2_32_8  free_load_conservation_1508  8
    service_2_32_9  unique_nonzero_owner_371  1
    service_2_32_9  service_visit_def_1507  1
    service_2_32_9  free_load_conservation_1508  9
    service_2_32_10  unique_nonzero_owner_372  1
    service_2_32_10  service_visit_def_1507  1
    service_2_32_10  free_load_conservation_1508  10
    service_2_32_11  unique_nonzero_owner_373  1
    service_2_32_11  service_visit_def_1507  1
    service_2_32_11  free_load_conservation_1508  11
    service_2_32_12  unique_nonzero_owner_374  1
    service_2_32_12  service_visit_def_1507  1
    service_2_32_12  free_load_conservation_1508  12
    service_0_24_0  unique_nonzero_owner_375  1
    service_0_24_0  service_visit_def_766  1
    service_0_24_0  free_load_conservation_767  -11
    service_0_24_0  original_T_including_depot_unload_783  1320
    service_0_24_1  unique_nonzero_owner_376  1
    service_0_24_1  service_visit_def_766  1
    service_0_24_1  free_load_conservation_767  -10
    service_0_24_1  original_T_including_depot_unload_783  1200
    service_0_24_2  unique_nonzero_owner_377  1
    service_0_24_2  service_visit_def_766  1
    service_0_24_2  free_load_conservation_767  -9
    service_0_24_2  original_T_including_depot_unload_783  1080
    service_0_24_3  unique_nonzero_owner_378  1
    service_0_24_3  service_visit_def_766  1
    service_0_24_3  free_load_conservation_767  -8
    service_0_24_3  original_T_including_depot_unload_783  960
    service_0_24_4  unique_nonzero_owner_379  1
    service_0_24_4  service_visit_def_766  1
    service_0_24_4  free_load_conservation_767  -7
    service_0_24_4  original_T_including_depot_unload_783  840
    service_0_24_5  unique_nonzero_owner_380  1
    service_0_24_5  service_visit_def_766  1
    service_0_24_5  free_load_conservation_767  -6
    service_0_24_5  original_T_including_depot_unload_783  720
    service_0_24_6  unique_nonzero_owner_381  1
    service_0_24_6  service_visit_def_766  1
    service_0_24_6  free_load_conservation_767  -5
    service_0_24_6  original_T_including_depot_unload_783  600
    service_0_24_7  unique_nonzero_owner_382  1
    service_0_24_7  service_visit_def_766  1
    service_0_24_7  free_load_conservation_767  -4
    service_0_24_7  original_T_including_depot_unload_783  480
    service_0_24_8  unique_nonzero_owner_383  1
    service_0_24_8  service_visit_def_766  1
    service_0_24_8  free_load_conservation_767  -3
    service_0_24_8  original_T_including_depot_unload_783  360
    service_0_24_9  unique_nonzero_owner_384  1
    service_0_24_9  service_visit_def_766  1
    service_0_24_9  free_load_conservation_767  -2
    service_0_24_9  original_T_including_depot_unload_783  240
    service_0_24_10  unique_nonzero_owner_385  1
    service_0_24_10  service_visit_def_766  1
    service_0_24_10  free_load_conservation_767  -1
    service_0_24_10  original_T_including_depot_unload_783  120
    service_0_24_12  unique_nonzero_owner_386  1
    service_0_24_12  service_visit_def_766  1
    service_0_24_12  free_load_conservation_767  1
    service_0_24_13  unique_nonzero_owner_387  1
    service_0_24_13  service_visit_def_766  1
    service_0_24_13  free_load_conservation_767  2
    service_0_24_14  unique_nonzero_owner_388  1
    service_0_24_14  service_visit_def_766  1
    service_0_24_14  free_load_conservation_767  3
    service_0_24_15  unique_nonzero_owner_389  1
    service_0_24_15  service_visit_def_766  1
    service_0_24_15  free_load_conservation_767  4
    service_1_24_0  unique_nonzero_owner_375  1
    service_1_24_0  service_visit_def_1194  1
    service_1_24_0  free_load_conservation_1195  -11
    service_1_24_0  original_T_including_depot_unload_1212  1320
    service_1_24_1  unique_nonzero_owner_376  1
    service_1_24_1  service_visit_def_1194  1
    service_1_24_1  free_load_conservation_1195  -10
    service_1_24_1  original_T_including_depot_unload_1212  1200
    service_1_24_2  unique_nonzero_owner_377  1
    service_1_24_2  service_visit_def_1194  1
    service_1_24_2  free_load_conservation_1195  -9
    service_1_24_2  original_T_including_depot_unload_1212  1080
    service_1_24_3  unique_nonzero_owner_378  1
    service_1_24_3  service_visit_def_1194  1
    service_1_24_3  free_load_conservation_1195  -8
    service_1_24_3  original_T_including_depot_unload_1212  960
    service_1_24_4  unique_nonzero_owner_379  1
    service_1_24_4  service_visit_def_1194  1
    service_1_24_4  free_load_conservation_1195  -7
    service_1_24_4  original_T_including_depot_unload_1212  840
    service_1_24_5  unique_nonzero_owner_380  1
    service_1_24_5  service_visit_def_1194  1
    service_1_24_5  free_load_conservation_1195  -6
    service_1_24_5  original_T_including_depot_unload_1212  720
    service_1_24_6  unique_nonzero_owner_381  1
    service_1_24_6  service_visit_def_1194  1
    service_1_24_6  free_load_conservation_1195  -5
    service_1_24_6  original_T_including_depot_unload_1212  600
    service_1_24_7  unique_nonzero_owner_382  1
    service_1_24_7  service_visit_def_1194  1
    service_1_24_7  free_load_conservation_1195  -4
    service_1_24_7  original_T_including_depot_unload_1212  480
    service_1_24_8  unique_nonzero_owner_383  1
    service_1_24_8  service_visit_def_1194  1
    service_1_24_8  free_load_conservation_1195  -3
    service_1_24_8  original_T_including_depot_unload_1212  360
    service_1_24_9  unique_nonzero_owner_384  1
    service_1_24_9  service_visit_def_1194  1
    service_1_24_9  free_load_conservation_1195  -2
    service_1_24_9  original_T_including_depot_unload_1212  240
    service_1_24_10  unique_nonzero_owner_385  1
    service_1_24_10  service_visit_def_1194  1
    service_1_24_10  free_load_conservation_1195  -1
    service_1_24_10  original_T_including_depot_unload_1212  120
    service_1_24_12  unique_nonzero_owner_386  1
    service_1_24_12  service_visit_def_1194  1
    service_1_24_12  free_load_conservation_1195  1
    service_1_24_13  unique_nonzero_owner_387  1
    service_1_24_13  service_visit_def_1194  1
    service_1_24_13  free_load_conservation_1195  2
    service_1_24_14  unique_nonzero_owner_388  1
    service_1_24_14  service_visit_def_1194  1
    service_1_24_14  free_load_conservation_1195  3
    service_1_24_15  unique_nonzero_owner_389  1
    service_1_24_15  service_visit_def_1194  1
    service_1_24_15  free_load_conservation_1195  4
    service_2_24_0  unique_nonzero_owner_375  1
    service_2_24_0  service_visit_def_1513  1
    service_2_24_0  free_load_conservation_1514  -11
    service_2_24_0  original_T_including_depot_unload_1529  1320
    service_2_24_1  unique_nonzero_owner_376  1
    service_2_24_1  service_visit_def_1513  1
    service_2_24_1  free_load_conservation_1514  -10
    service_2_24_1  original_T_including_depot_unload_1529  1200
    service_2_24_2  unique_nonzero_owner_377  1
    service_2_24_2  service_visit_def_1513  1
    service_2_24_2  free_load_conservation_1514  -9
    service_2_24_2  original_T_including_depot_unload_1529  1080
    service_2_24_3  unique_nonzero_owner_378  1
    service_2_24_3  service_visit_def_1513  1
    service_2_24_3  free_load_conservation_1514  -8
    service_2_24_3  original_T_including_depot_unload_1529  960
    service_2_24_4  unique_nonzero_owner_379  1
    service_2_24_4  service_visit_def_1513  1
    service_2_24_4  free_load_conservation_1514  -7
    service_2_24_4  original_T_including_depot_unload_1529  840
    service_2_24_5  unique_nonzero_owner_380  1
    service_2_24_5  service_visit_def_1513  1
    service_2_24_5  free_load_conservation_1514  -6
    service_2_24_5  original_T_including_depot_unload_1529  720
    service_2_24_6  unique_nonzero_owner_381  1
    service_2_24_6  service_visit_def_1513  1
    service_2_24_6  free_load_conservation_1514  -5
    service_2_24_6  original_T_including_depot_unload_1529  600
    service_2_24_7  unique_nonzero_owner_382  1
    service_2_24_7  service_visit_def_1513  1
    service_2_24_7  free_load_conservation_1514  -4
    service_2_24_7  original_T_including_depot_unload_1529  480
    service_2_24_8  unique_nonzero_owner_383  1
    service_2_24_8  service_visit_def_1513  1
    service_2_24_8  free_load_conservation_1514  -3
    service_2_24_8  original_T_including_depot_unload_1529  360
    service_2_24_9  unique_nonzero_owner_384  1
    service_2_24_9  service_visit_def_1513  1
    service_2_24_9  free_load_conservation_1514  -2
    service_2_24_9  original_T_including_depot_unload_1529  240
    service_2_24_10  unique_nonzero_owner_385  1
    service_2_24_10  service_visit_def_1513  1
    service_2_24_10  free_load_conservation_1514  -1
    service_2_24_10  original_T_including_depot_unload_1529  120
    service_2_24_12  unique_nonzero_owner_386  1
    service_2_24_12  service_visit_def_1513  1
    service_2_24_12  free_load_conservation_1514  1
    service_2_24_13  unique_nonzero_owner_387  1
    service_2_24_13  service_visit_def_1513  1
    service_2_24_13  free_load_conservation_1514  2
    service_2_24_14  unique_nonzero_owner_388  1
    service_2_24_14  service_visit_def_1513  1
    service_2_24_14  free_load_conservation_1514  3
    service_2_24_15  unique_nonzero_owner_389  1
    service_2_24_15  service_visit_def_1513  1
    service_2_24_15  free_load_conservation_1514  4
    service_0_19_1  unique_nonzero_owner_390  1
    service_0_19_1  service_visit_def_772  1
    service_0_19_1  free_load_conservation_773  1
    service_0_19_2  unique_nonzero_owner_391  1
    service_0_19_2  service_visit_def_772  1
    service_0_19_2  free_load_conservation_773  2
    service_0_19_3  unique_nonzero_owner_392  1
    service_0_19_3  service_visit_def_772  1
    service_0_19_3  free_load_conservation_773  3
    service_0_19_4  unique_nonzero_owner_393  1
    service_0_19_4  service_visit_def_772  1
    service_0_19_4  free_load_conservation_773  4
    service_0_19_5  unique_nonzero_owner_394  1
    service_0_19_5  service_visit_def_772  1
    service_0_19_5  free_load_conservation_773  5
    service_0_19_6  unique_nonzero_owner_395  1
    service_0_19_6  service_visit_def_772  1
    service_0_19_6  free_load_conservation_773  6
    service_0_19_7  unique_nonzero_owner_396  1
    service_0_19_7  service_visit_def_772  1
    service_0_19_7  free_load_conservation_773  7
    service_0_19_8  unique_nonzero_owner_397  1
    service_0_19_8  service_visit_def_772  1
    service_0_19_8  free_load_conservation_773  8
    service_1_19_1  unique_nonzero_owner_390  1
    service_1_19_1  service_visit_def_1200  1
    service_1_19_1  free_load_conservation_1201  1
    service_1_19_2  unique_nonzero_owner_391  1
    service_1_19_2  service_visit_def_1200  1
    service_1_19_2  free_load_conservation_1201  2
    service_1_19_3  unique_nonzero_owner_392  1
    service_1_19_3  service_visit_def_1200  1
    service_1_19_3  free_load_conservation_1201  3
    service_1_19_4  unique_nonzero_owner_393  1
    service_1_19_4  service_visit_def_1200  1
    service_1_19_4  free_load_conservation_1201  4
    service_1_19_5  unique_nonzero_owner_394  1
    service_1_19_5  service_visit_def_1200  1
    service_1_19_5  free_load_conservation_1201  5
    service_1_19_6  unique_nonzero_owner_395  1
    service_1_19_6  service_visit_def_1200  1
    service_1_19_6  free_load_conservation_1201  6
    service_1_19_7  unique_nonzero_owner_396  1
    service_1_19_7  service_visit_def_1200  1
    service_1_19_7  free_load_conservation_1201  7
    service_1_19_8  unique_nonzero_owner_397  1
    service_1_19_8  service_visit_def_1200  1
    service_1_19_8  free_load_conservation_1201  8
    service_2_19_1  unique_nonzero_owner_390  1
    service_2_19_1  service_visit_def_1519  1
    service_2_19_1  free_load_conservation_1520  1
    service_2_19_2  unique_nonzero_owner_391  1
    service_2_19_2  service_visit_def_1519  1
    service_2_19_2  free_load_conservation_1520  2
    service_2_19_3  unique_nonzero_owner_392  1
    service_2_19_3  service_visit_def_1519  1
    service_2_19_3  free_load_conservation_1520  3
    service_2_19_4  unique_nonzero_owner_393  1
    service_2_19_4  service_visit_def_1519  1
    service_2_19_4  free_load_conservation_1520  4
    service_2_19_5  unique_nonzero_owner_394  1
    service_2_19_5  service_visit_def_1519  1
    service_2_19_5  free_load_conservation_1520  5
    service_2_19_6  unique_nonzero_owner_395  1
    service_2_19_6  service_visit_def_1519  1
    service_2_19_6  free_load_conservation_1520  6
    service_2_19_7  unique_nonzero_owner_396  1
    service_2_19_7  service_visit_def_1519  1
    service_2_19_7  free_load_conservation_1520  7
    service_2_19_8  unique_nonzero_owner_397  1
    service_2_19_8  service_visit_def_1519  1
    service_2_19_8  free_load_conservation_1520  8
    service_0_29_0  unique_nonzero_owner_398  1
    service_0_29_0  service_visit_def_778  1
    service_0_29_0  free_load_conservation_779  -11
    service_0_29_0  original_T_including_depot_unload_783  1320
    service_0_29_1  unique_nonzero_owner_399  1
    service_0_29_1  service_visit_def_778  1
    service_0_29_1  free_load_conservation_779  -10
    service_0_29_1  original_T_including_depot_unload_783  1200
    service_0_29_2  unique_nonzero_owner_400  1
    service_0_29_2  service_visit_def_778  1
    service_0_29_2  free_load_conservation_779  -9
    service_0_29_2  original_T_including_depot_unload_783  1080
    service_0_29_3  unique_nonzero_owner_401  1
    service_0_29_3  service_visit_def_778  1
    service_0_29_3  free_load_conservation_779  -8
    service_0_29_3  original_T_including_depot_unload_783  960
    service_0_29_4  unique_nonzero_owner_402  1
    service_0_29_4  service_visit_def_778  1
    service_0_29_4  free_load_conservation_779  -7
    service_0_29_4  original_T_including_depot_unload_783  840
    service_0_29_5  unique_nonzero_owner_403  1
    service_0_29_5  service_visit_def_778  1
    service_0_29_5  free_load_conservation_779  -6
    service_0_29_5  original_T_including_depot_unload_783  720
    service_0_29_6  unique_nonzero_owner_404  1
    service_0_29_6  service_visit_def_778  1
    service_0_29_6  free_load_conservation_779  -5
    service_0_29_6  original_T_including_depot_unload_783  600
    service_0_29_7  unique_nonzero_owner_405  1
    service_0_29_7  service_visit_def_778  1
    service_0_29_7  free_load_conservation_779  -4
    service_0_29_7  original_T_including_depot_unload_783  480
    service_0_29_8  unique_nonzero_owner_406  1
    service_0_29_8  service_visit_def_778  1
    service_0_29_8  free_load_conservation_779  -3
    service_0_29_8  original_T_including_depot_unload_783  360
    service_0_29_9  unique_nonzero_owner_407  1
    service_0_29_9  service_visit_def_778  1
    service_0_29_9  free_load_conservation_779  -2
    service_0_29_9  original_T_including_depot_unload_783  240
    service_0_29_10  unique_nonzero_owner_408  1
    service_0_29_10  service_visit_def_778  1
    service_0_29_10  free_load_conservation_779  -1
    service_0_29_10  original_T_including_depot_unload_783  120
    service_0_29_12  unique_nonzero_owner_409  1
    service_0_29_12  service_visit_def_778  1
    service_0_29_12  free_load_conservation_779  1
    service_0_29_13  unique_nonzero_owner_410  1
    service_0_29_13  service_visit_def_778  1
    service_0_29_13  free_load_conservation_779  2
    service_0_29_14  unique_nonzero_owner_411  1
    service_0_29_14  service_visit_def_778  1
    service_0_29_14  free_load_conservation_779  3
    service_0_29_15  unique_nonzero_owner_412  1
    service_0_29_15  service_visit_def_778  1
    service_0_29_15  free_load_conservation_779  4
    service_1_29_0  unique_nonzero_owner_398  1
    service_1_29_0  service_visit_def_1206  1
    service_1_29_0  free_load_conservation_1207  -11
    service_1_29_0  original_T_including_depot_unload_1212  1320
    service_1_29_1  unique_nonzero_owner_399  1
    service_1_29_1  service_visit_def_1206  1
    service_1_29_1  free_load_conservation_1207  -10
    service_1_29_1  original_T_including_depot_unload_1212  1200
    service_1_29_2  unique_nonzero_owner_400  1
    service_1_29_2  service_visit_def_1206  1
    service_1_29_2  free_load_conservation_1207  -9
    service_1_29_2  original_T_including_depot_unload_1212  1080
    service_1_29_3  unique_nonzero_owner_401  1
    service_1_29_3  service_visit_def_1206  1
    service_1_29_3  free_load_conservation_1207  -8
    service_1_29_3  original_T_including_depot_unload_1212  960
    service_1_29_4  unique_nonzero_owner_402  1
    service_1_29_4  service_visit_def_1206  1
    service_1_29_4  free_load_conservation_1207  -7
    service_1_29_4  original_T_including_depot_unload_1212  840
    service_1_29_5  unique_nonzero_owner_403  1
    service_1_29_5  service_visit_def_1206  1
    service_1_29_5  free_load_conservation_1207  -6
    service_1_29_5  original_T_including_depot_unload_1212  720
    service_1_29_6  unique_nonzero_owner_404  1
    service_1_29_6  service_visit_def_1206  1
    service_1_29_6  free_load_conservation_1207  -5
    service_1_29_6  original_T_including_depot_unload_1212  600
    service_1_29_7  unique_nonzero_owner_405  1
    service_1_29_7  service_visit_def_1206  1
    service_1_29_7  free_load_conservation_1207  -4
    service_1_29_7  original_T_including_depot_unload_1212  480
    service_1_29_8  unique_nonzero_owner_406  1
    service_1_29_8  service_visit_def_1206  1
    service_1_29_8  free_load_conservation_1207  -3
    service_1_29_8  original_T_including_depot_unload_1212  360
    service_1_29_9  unique_nonzero_owner_407  1
    service_1_29_9  service_visit_def_1206  1
    service_1_29_9  free_load_conservation_1207  -2
    service_1_29_9  original_T_including_depot_unload_1212  240
    service_1_29_10  unique_nonzero_owner_408  1
    service_1_29_10  service_visit_def_1206  1
    service_1_29_10  free_load_conservation_1207  -1
    service_1_29_10  original_T_including_depot_unload_1212  120
    service_1_29_12  unique_nonzero_owner_409  1
    service_1_29_12  service_visit_def_1206  1
    service_1_29_12  free_load_conservation_1207  1
    service_1_29_13  unique_nonzero_owner_410  1
    service_1_29_13  service_visit_def_1206  1
    service_1_29_13  free_load_conservation_1207  2
    service_1_29_14  unique_nonzero_owner_411  1
    service_1_29_14  service_visit_def_1206  1
    service_1_29_14  free_load_conservation_1207  3
    service_1_29_15  unique_nonzero_owner_412  1
    service_1_29_15  service_visit_def_1206  1
    service_1_29_15  free_load_conservation_1207  4
    service_2_29_0  unique_nonzero_owner_398  1
    service_2_29_0  service_visit_def_1525  1
    service_2_29_0  free_load_conservation_1526  -11
    service_2_29_0  original_T_including_depot_unload_1529  1320
    service_2_29_1  unique_nonzero_owner_399  1
    service_2_29_1  service_visit_def_1525  1
    service_2_29_1  free_load_conservation_1526  -10
    service_2_29_1  original_T_including_depot_unload_1529  1200
    service_2_29_2  unique_nonzero_owner_400  1
    service_2_29_2  service_visit_def_1525  1
    service_2_29_2  free_load_conservation_1526  -9
    service_2_29_2  original_T_including_depot_unload_1529  1080
    service_2_29_3  unique_nonzero_owner_401  1
    service_2_29_3  service_visit_def_1525  1
    service_2_29_3  free_load_conservation_1526  -8
    service_2_29_3  original_T_including_depot_unload_1529  960
    service_2_29_4  unique_nonzero_owner_402  1
    service_2_29_4  service_visit_def_1525  1
    service_2_29_4  free_load_conservation_1526  -7
    service_2_29_4  original_T_including_depot_unload_1529  840
    service_2_29_5  unique_nonzero_owner_403  1
    service_2_29_5  service_visit_def_1525  1
    service_2_29_5  free_load_conservation_1526  -6
    service_2_29_5  original_T_including_depot_unload_1529  720
    service_2_29_6  unique_nonzero_owner_404  1
    service_2_29_6  service_visit_def_1525  1
    service_2_29_6  free_load_conservation_1526  -5
    service_2_29_6  original_T_including_depot_unload_1529  600
    service_2_29_7  unique_nonzero_owner_405  1
    service_2_29_7  service_visit_def_1525  1
    service_2_29_7  free_load_conservation_1526  -4
    service_2_29_7  original_T_including_depot_unload_1529  480
    service_2_29_8  unique_nonzero_owner_406  1
    service_2_29_8  service_visit_def_1525  1
    service_2_29_8  free_load_conservation_1526  -3
    service_2_29_8  original_T_including_depot_unload_1529  360
    service_2_29_9  unique_nonzero_owner_407  1
    service_2_29_9  service_visit_def_1525  1
    service_2_29_9  free_load_conservation_1526  -2
    service_2_29_9  original_T_including_depot_unload_1529  240
    service_2_29_10  unique_nonzero_owner_408  1
    service_2_29_10  service_visit_def_1525  1
    service_2_29_10  free_load_conservation_1526  -1
    service_2_29_10  original_T_including_depot_unload_1529  120
    service_2_29_12  unique_nonzero_owner_409  1
    service_2_29_12  service_visit_def_1525  1
    service_2_29_12  free_load_conservation_1526  1
    service_2_29_13  unique_nonzero_owner_410  1
    service_2_29_13  service_visit_def_1525  1
    service_2_29_13  free_load_conservation_1526  2
    service_2_29_14  unique_nonzero_owner_411  1
    service_2_29_14  service_visit_def_1525  1
    service_2_29_14  free_load_conservation_1526  3
    service_2_29_15  unique_nonzero_owner_412  1
    service_2_29_15  service_visit_def_1525  1
    service_2_29_15  free_load_conservation_1526  4
    MARKER    'MARKER'                 'INTEND'
    visit_0_1  out_degree_704  -1
    visit_0_1  in_degree_705  -1
    visit_0_1  order_active_lb_706  -1
    visit_0_1  order_active_ub_707  -12
    order_0_1  connected_order_arc_428  -1
    order_0_1  connected_order_arc_430  -1
    order_0_1  connected_order_arc_432  -1
    order_0_1  connected_order_arc_434  -1
    order_0_1  connected_order_arc_436  -1
    order_0_1  connected_order_arc_438  -1
    order_0_1  connected_order_arc_440  -1
    order_0_1  connected_order_arc_442  -1
    order_0_1  connected_order_arc_444  -1
    order_0_1  connected_order_arc_446  -1
    order_0_1  connected_order_arc_448  -1
    order_0_1  connected_order_arc_451  1
    order_0_1  connected_order_arc_474  1
    order_0_1  connected_order_arc_497  1
    order_0_1  connected_order_arc_520  1
    order_0_1  connected_order_arc_543  1
    order_0_1  connected_order_arc_566  1
    order_0_1  connected_order_arc_589  1
    order_0_1  connected_order_arc_612  1
    order_0_1  connected_order_arc_635  1
    order_0_1  connected_order_arc_658  1
    order_0_1  connected_order_arc_681  1
    order_0_1  order_active_lb_706  1
    order_0_1  order_active_ub_707  1
    order_0_1  fixed_segment_relative_order_780  -1
    visit_0_2  out_degree_711  -1
    visit_0_2  in_degree_712  -1
    visit_0_2  order_active_lb_713  -1
    visit_0_2  order_active_ub_714  -12
    order_0_2  connected_order_arc_428  1
    order_0_2  connected_order_arc_451  -1
    order_0_2  connected_order_arc_453  -1
    order_0_2  connected_order_arc_455  -1
    order_0_2  connected_order_arc_457  -1
    order_0_2  connected_order_arc_459  -1
    order_0_2  connected_order_arc_461  -1
    order_0_2  connected_order_arc_463  -1
    order_0_2  connected_order_arc_465  -1
    order_0_2  connected_order_arc_467  -1
    order_0_2  connected_order_arc_469  -1
    order_0_2  connected_order_arc_471  -1
    order_0_2  connected_order_arc_476  1
    order_0_2  connected_order_arc_499  1
    order_0_2  connected_order_arc_522  1
    order_0_2  connected_order_arc_545  1
    order_0_2  connected_order_arc_568  1
    order_0_2  connected_order_arc_591  1
    order_0_2  connected_order_arc_614  1
    order_0_2  connected_order_arc_637  1
    order_0_2  connected_order_arc_660  1
    order_0_2  connected_order_arc_683  1
    order_0_2  order_active_lb_713  1
    order_0_2  order_active_ub_714  1
    order_0_2  fixed_segment_relative_order_780  1
    order_0_2  fixed_segment_relative_order_781  -1
    visit_0_3  out_degree_718  -1
    visit_0_3  in_degree_719  -1
    visit_0_3  order_active_lb_720  -1
    visit_0_3  order_active_ub_721  -12
    order_0_3  connected_order_arc_430  1
    order_0_3  connected_order_arc_453  1
    order_0_3  connected_order_arc_474  -1
    order_0_3  connected_order_arc_476  -1
    order_0_3  connected_order_arc_478  -1
    order_0_3  connected_order_arc_480  -1
    order_0_3  connected_order_arc_482  -1
    order_0_3  connected_order_arc_484  -1
    order_0_3  connected_order_arc_486  -1
    order_0_3  connected_order_arc_488  -1
    order_0_3  connected_order_arc_490  -1
    order_0_3  connected_order_arc_492  -1
    order_0_3  connected_order_arc_494  -1
    order_0_3  connected_order_arc_501  1
    order_0_3  connected_order_arc_524  1
    order_0_3  connected_order_arc_547  1
    order_0_3  connected_order_arc_570  1
    order_0_3  connected_order_arc_593  1
    order_0_3  connected_order_arc_616  1
    order_0_3  connected_order_arc_639  1
    order_0_3  connected_order_arc_662  1
    order_0_3  connected_order_arc_685  1
    order_0_3  order_active_lb_720  1
    order_0_3  order_active_ub_721  1
    order_0_3  fixed_segment_relative_order_781  1
    order_0_3  fixed_segment_relative_order_782  -1
    visit_0_4  out_degree_725  -1
    visit_0_4  in_degree_726  -1
    visit_0_4  order_active_lb_727  -1
    visit_0_4  order_active_ub_728  -12
    order_0_4  connected_order_arc_432  1
    order_0_4  connected_order_arc_455  1
    order_0_4  connected_order_arc_478  1
    order_0_4  connected_order_arc_497  -1
    order_0_4  connected_order_arc_499  -1
    order_0_4  connected_order_arc_501  -1
    order_0_4  connected_order_arc_503  -1
    order_0_4  connected_order_arc_505  -1
    order_0_4  connected_order_arc_507  -1
    order_0_4  connected_order_arc_509  -1
    order_0_4  connected_order_arc_511  -1
    order_0_4  connected_order_arc_513  -1
    order_0_4  connected_order_arc_515  -1
    order_0_4  connected_order_arc_517  -1
    order_0_4  connected_order_arc_526  1
    order_0_4  connected_order_arc_549  1
    order_0_4  connected_order_arc_572  1
    order_0_4  connected_order_arc_595  1
    order_0_4  connected_order_arc_618  1
    order_0_4  connected_order_arc_641  1
    order_0_4  connected_order_arc_664  1
    order_0_4  connected_order_arc_687  1
    order_0_4  order_active_lb_727  1
    order_0_4  order_active_ub_728  1
    order_0_4  fixed_segment_relative_order_782  1
    visit_0_13  out_degree_732  -1
    visit_0_13  in_degree_733  -1
    visit_0_13  order_active_lb_734  -1
    visit_0_13  order_active_ub_735  -12
    visit_0_13  service_visit_def_736  -1
    order_0_13  connected_order_arc_434  1
    order_0_13  connected_order_arc_457  1
    order_0_13  connected_order_arc_480  1
    order_0_13  connected_order_arc_503  1
    order_0_13  connected_order_arc_520  -1
    order_0_13  connected_order_arc_522  -1
    order_0_13  connected_order_arc_524  -1
    order_0_13  connected_order_arc_526  -1
    order_0_13  connected_order_arc_528  -1
    order_0_13  connected_order_arc_530  -1
    order_0_13  connected_order_arc_532  -1
    order_0_13  connected_order_arc_534  -1
    order_0_13  connected_order_arc_536  -1
    order_0_13  connected_order_arc_538  -1
    order_0_13  connected_order_arc_540  -1
    order_0_13  connected_order_arc_551  1
    order_0_13  connected_order_arc_574  1
    order_0_13  connected_order_arc_597  1
    order_0_13  connected_order_arc_620  1
    order_0_13  connected_order_arc_643  1
    order_0_13  connected_order_arc_666  1
    order_0_13  connected_order_arc_689  1
    order_0_13  order_active_lb_734  1
    order_0_13  order_active_ub_735  1
    visit_0_14  out_degree_738  -1
    visit_0_14  in_degree_739  -1
    visit_0_14  order_active_lb_740  -1
    visit_0_14  order_active_ub_741  -12
    visit_0_14  service_visit_def_742  -1
    order_0_14  connected_order_arc_436  1
    order_0_14  connected_order_arc_459  1
    order_0_14  connected_order_arc_482  1
    order_0_14  connected_order_arc_505  1
    order_0_14  connected_order_arc_528  1
    order_0_14  connected_order_arc_543  -1
    order_0_14  connected_order_arc_545  -1
    order_0_14  connected_order_arc_547  -1
    order_0_14  connected_order_arc_549  -1
    order_0_14  connected_order_arc_551  -1
    order_0_14  connected_order_arc_553  -1
    order_0_14  connected_order_arc_555  -1
    order_0_14  connected_order_arc_557  -1
    order_0_14  connected_order_arc_559  -1
    order_0_14  connected_order_arc_561  -1
    order_0_14  connected_order_arc_563  -1
    order_0_14  connected_order_arc_576  1
    order_0_14  connected_order_arc_599  1
    order_0_14  connected_order_arc_622  1
    order_0_14  connected_order_arc_645  1
    order_0_14  connected_order_arc_668  1
    order_0_14  connected_order_arc_691  1
    order_0_14  order_active_lb_740  1
    order_0_14  order_active_ub_741  1
    visit_0_15  out_degree_744  -1
    visit_0_15  in_degree_745  -1
    visit_0_15  order_active_lb_746  -1
    visit_0_15  order_active_ub_747  -12
    visit_0_15  service_visit_def_748  -1
    order_0_15  connected_order_arc_438  1
    order_0_15  connected_order_arc_461  1
    order_0_15  connected_order_arc_484  1
    order_0_15  connected_order_arc_507  1
    order_0_15  connected_order_arc_530  1
    order_0_15  connected_order_arc_553  1
    order_0_15  connected_order_arc_566  -1
    order_0_15  connected_order_arc_568  -1
    order_0_15  connected_order_arc_570  -1
    order_0_15  connected_order_arc_572  -1
    order_0_15  connected_order_arc_574  -1
    order_0_15  connected_order_arc_576  -1
    order_0_15  connected_order_arc_578  -1
    order_0_15  connected_order_arc_580  -1
    order_0_15  connected_order_arc_582  -1
    order_0_15  connected_order_arc_584  -1
    order_0_15  connected_order_arc_586  -1
    order_0_15  connected_order_arc_601  1
    order_0_15  connected_order_arc_624  1
    order_0_15  connected_order_arc_647  1
    order_0_15  connected_order_arc_670  1
    order_0_15  connected_order_arc_693  1
    order_0_15  order_active_lb_746  1
    order_0_15  order_active_ub_747  1
    visit_0_16  out_degree_750  -1
    visit_0_16  in_degree_751  -1
    visit_0_16  order_active_lb_752  -1
    visit_0_16  order_active_ub_753  -12
    visit_0_16  service_visit_def_754  -1
    order_0_16  connected_order_arc_440  1
    order_0_16  connected_order_arc_463  1
    order_0_16  connected_order_arc_486  1
    order_0_16  connected_order_arc_509  1
    order_0_16  connected_order_arc_532  1
    order_0_16  connected_order_arc_555  1
    order_0_16  connected_order_arc_578  1
    order_0_16  connected_order_arc_589  -1
    order_0_16  connected_order_arc_591  -1
    order_0_16  connected_order_arc_593  -1
    order_0_16  connected_order_arc_595  -1
    order_0_16  connected_order_arc_597  -1
    order_0_16  connected_order_arc_599  -1
    order_0_16  connected_order_arc_601  -1
    order_0_16  connected_order_arc_603  -1
    order_0_16  connected_order_arc_605  -1
    order_0_16  connected_order_arc_607  -1
    order_0_16  connected_order_arc_609  -1
    order_0_16  connected_order_arc_626  1
    order_0_16  connected_order_arc_649  1
    order_0_16  connected_order_arc_672  1
    order_0_16  connected_order_arc_695  1
    order_0_16  order_active_lb_752  1
    order_0_16  order_active_ub_753  1
    visit_0_17  out_degree_756  -1
    visit_0_17  in_degree_757  -1
    visit_0_17  order_active_lb_758  -1
    visit_0_17  order_active_ub_759  -12
    visit_0_17  service_visit_def_760  -1
    order_0_17  connected_order_arc_442  1
    order_0_17  connected_order_arc_465  1
    order_0_17  connected_order_arc_488  1
    order_0_17  connected_order_arc_511  1
    order_0_17  connected_order_arc_534  1
    order_0_17  connected_order_arc_557  1
    order_0_17  connected_order_arc_580  1
    order_0_17  connected_order_arc_603  1
    order_0_17  connected_order_arc_612  -1
    order_0_17  connected_order_arc_614  -1
    order_0_17  connected_order_arc_616  -1
    order_0_17  connected_order_arc_618  -1
    order_0_17  connected_order_arc_620  -1
    order_0_17  connected_order_arc_622  -1
    order_0_17  connected_order_arc_624  -1
    order_0_17  connected_order_arc_626  -1
    order_0_17  connected_order_arc_628  -1
    order_0_17  connected_order_arc_630  -1
    order_0_17  connected_order_arc_632  -1
    order_0_17  connected_order_arc_651  1
    order_0_17  connected_order_arc_674  1
    order_0_17  connected_order_arc_697  1
    order_0_17  order_active_lb_758  1
    order_0_17  order_active_ub_759  1
    visit_0_18  out_degree_762  -1
    visit_0_18  in_degree_763  -1
    visit_0_18  order_active_lb_764  -1
    visit_0_18  order_active_ub_765  -12
    visit_0_18  service_visit_def_766  -1
    order_0_18  connected_order_arc_444  1
    order_0_18  connected_order_arc_467  1
    order_0_18  connected_order_arc_490  1
    order_0_18  connected_order_arc_513  1
    order_0_18  connected_order_arc_536  1
    order_0_18  connected_order_arc_559  1
    order_0_18  connected_order_arc_582  1
    order_0_18  connected_order_arc_605  1
    order_0_18  connected_order_arc_628  1
    order_0_18  connected_order_arc_635  -1
    order_0_18  connected_order_arc_637  -1
    order_0_18  connected_order_arc_639  -1
    order_0_18  connected_order_arc_641  -1
    order_0_18  connected_order_arc_643  -1
    order_0_18  connected_order_arc_645  -1
    order_0_18  connected_order_arc_647  -1
    order_0_18  connected_order_arc_649  -1
    order_0_18  connected_order_arc_651  -1
    order_0_18  connected_order_arc_653  -1
    order_0_18  connected_order_arc_655  -1
    order_0_18  connected_order_arc_676  1
    order_0_18  connected_order_arc_699  1
    order_0_18  order_active_lb_764  1
    order_0_18  order_active_ub_765  1
    visit_0_19  out_degree_768  -1
    visit_0_19  in_degree_769  -1
    visit_0_19  order_active_lb_770  -1
    visit_0_19  order_active_ub_771  -12
    visit_0_19  service_visit_def_772  -1
    order_0_19  connected_order_arc_446  1
    order_0_19  connected_order_arc_469  1
    order_0_19  connected_order_arc_492  1
    order_0_19  connected_order_arc_515  1
    order_0_19  connected_order_arc_538  1
    order_0_19  connected_order_arc_561  1
    order_0_19  connected_order_arc_584  1
    order_0_19  connected_order_arc_607  1
    order_0_19  connected_order_arc_630  1
    order_0_19  connected_order_arc_653  1
    order_0_19  connected_order_arc_658  -1
    order_0_19  connected_order_arc_660  -1
    order_0_19  connected_order_arc_662  -1
    order_0_19  connected_order_arc_664  -1
    order_0_19  connected_order_arc_666  -1
    order_0_19  connected_order_arc_668  -1
    order_0_19  connected_order_arc_670  -1
    order_0_19  connected_order_arc_672  -1
    order_0_19  connected_order_arc_674  -1
    order_0_19  connected_order_arc_676  -1
    order_0_19  connected_order_arc_678  -1
    order_0_19  connected_order_arc_701  1
    order_0_19  order_active_lb_770  1
    order_0_19  order_active_ub_771  1
    visit_0_20  out_degree_774  -1
    visit_0_20  in_degree_775  -1
    visit_0_20  order_active_lb_776  -1
    visit_0_20  order_active_ub_777  -12
    visit_0_20  service_visit_def_778  -1
    order_0_20  connected_order_arc_448  1
    order_0_20  connected_order_arc_471  1
    order_0_20  connected_order_arc_494  1
    order_0_20  connected_order_arc_517  1
    order_0_20  connected_order_arc_540  1
    order_0_20  connected_order_arc_563  1
    order_0_20  connected_order_arc_586  1
    order_0_20  connected_order_arc_609  1
    order_0_20  connected_order_arc_632  1
    order_0_20  connected_order_arc_655  1
    order_0_20  connected_order_arc_678  1
    order_0_20  connected_order_arc_681  -1
    order_0_20  connected_order_arc_683  -1
    order_0_20  connected_order_arc_685  -1
    order_0_20  connected_order_arc_687  -1
    order_0_20  connected_order_arc_689  -1
    order_0_20  connected_order_arc_691  -1
    order_0_20  connected_order_arc_693  -1
    order_0_20  connected_order_arc_695  -1
    order_0_20  connected_order_arc_697  -1
    order_0_20  connected_order_arc_699  -1
    order_0_20  connected_order_arc_701  -1
    order_0_20  order_active_lb_776  1
    order_0_20  order_active_ub_777  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_0  arc_capacity_413  -20
    arc_0_0_0  depot_departure_or_bypass_702  1
    arc_0_0_0  depot_return_or_bypass_703  1
    MARKER    'MARKER'                 'INTEND'
    load_0_0_0  arc_capacity_413  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_1  arc_capacity_414  -20
    arc_0_0_1  depot_departure_or_bypass_702  1
    arc_0_0_1  in_degree_705  1
    arc_0_0_1  original_T_including_depot_unload_783  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_1  arc_capacity_414  1
    load_0_0_1  segment_load_conservation_708  -1
    load_0_0_1  segment_prefix_lb_709  1
    load_0_0_1  segment_prefix_ub_710  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_2  arc_capacity_415  -20
    arc_0_0_2  depot_departure_or_bypass_702  1
    arc_0_0_2  in_degree_712  1
    arc_0_0_2  original_T_including_depot_unload_783  5.9431738885389052e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_2  arc_capacity_415  1
    load_0_0_2  segment_load_conservation_715  -1
    load_0_0_2  segment_prefix_lb_716  1
    load_0_0_2  segment_prefix_ub_717  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_3  arc_capacity_416  -20
    arc_0_0_3  depot_departure_or_bypass_702  1
    arc_0_0_3  in_degree_719  1
    arc_0_0_3  original_T_including_depot_unload_783  7.2571167924583824e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_3  arc_capacity_416  1
    load_0_0_3  segment_load_conservation_722  -1
    load_0_0_3  segment_prefix_lb_723  1
    load_0_0_3  segment_prefix_ub_724  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_4  arc_capacity_417  -20
    arc_0_0_4  depot_departure_or_bypass_702  1
    arc_0_0_4  in_degree_726  1
    arc_0_0_4  original_T_including_depot_unload_783  4.6364706268001146e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_4  arc_capacity_417  1
    load_0_0_4  segment_load_conservation_729  -1
    load_0_0_4  segment_prefix_lb_730  1
    load_0_0_4  segment_prefix_ub_731  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_13  arc_capacity_418  -20
    arc_0_0_13  depot_departure_or_bypass_702  1
    arc_0_0_13  in_degree_733  1
    arc_0_0_13  original_T_including_depot_unload_783  1.2751323166566442e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_13  arc_capacity_418  1
    load_0_0_13  free_load_conservation_737  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_14  arc_capacity_419  -20
    arc_0_0_14  depot_departure_or_bypass_702  1
    arc_0_0_14  in_degree_739  1
    arc_0_0_14  original_T_including_depot_unload_783  1.3076700111397606e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_14  arc_capacity_419  1
    load_0_0_14  free_load_conservation_743  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_15  arc_capacity_420  -20
    arc_0_0_15  depot_departure_or_bypass_702  1
    arc_0_0_15  in_degree_745  1
    arc_0_0_15  original_T_including_depot_unload_783  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_15  arc_capacity_420  1
    load_0_0_15  free_load_conservation_749  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_16  arc_capacity_421  -20
    arc_0_0_16  depot_departure_or_bypass_702  1
    arc_0_0_16  in_degree_751  1
    arc_0_0_16  original_T_including_depot_unload_783  1.0088905112952611e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_16  arc_capacity_421  1
    load_0_0_16  free_load_conservation_755  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_17  arc_capacity_422  -20
    arc_0_0_17  depot_departure_or_bypass_702  1
    arc_0_0_17  in_degree_757  1
    arc_0_0_17  original_T_including_depot_unload_783  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_17  arc_capacity_422  1
    load_0_0_17  free_load_conservation_761  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_18  arc_capacity_423  -20
    arc_0_0_18  depot_departure_or_bypass_702  1
    arc_0_0_18  in_degree_763  1
    arc_0_0_18  original_T_including_depot_unload_783  8.7749189782983967e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_18  arc_capacity_423  1
    load_0_0_18  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_19  arc_capacity_424  -20
    arc_0_0_19  depot_departure_or_bypass_702  1
    arc_0_0_19  in_degree_769  1
    arc_0_0_19  original_T_including_depot_unload_783  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_19  arc_capacity_424  1
    load_0_0_19  free_load_conservation_773  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_20  arc_capacity_425  -20
    arc_0_0_20  depot_departure_or_bypass_702  1
    arc_0_0_20  in_degree_775  1
    arc_0_0_20  original_T_including_depot_unload_783  1.0479182987243917e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_20  arc_capacity_425  1
    load_0_0_20  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_0  arc_capacity_426  -20
    arc_0_1_0  depot_return_or_bypass_703  1
    arc_0_1_0  out_degree_704  1
    arc_0_1_0  original_T_including_depot_unload_783  6.6653528395596720e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_0  arc_capacity_426  1
    load_0_1_0  segment_load_conservation_708  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_2  arc_capacity_427  -20
    arc_0_1_2  connected_order_arc_428  -13
    arc_0_1_2  out_degree_704  1
    arc_0_1_2  in_degree_712  1
    arc_0_1_2  original_T_including_depot_unload_783  3.2985327387120213e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_2  arc_capacity_427  1
    load_0_1_2  segment_load_conservation_708  1
    load_0_1_2  segment_load_conservation_715  -1
    load_0_1_2  segment_prefix_lb_716  1
    load_0_1_2  segment_prefix_ub_717  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_3  arc_capacity_429  -20
    arc_0_1_3  connected_order_arc_430  -13
    arc_0_1_3  out_degree_704  1
    arc_0_1_3  in_degree_719  1
    arc_0_1_3  original_T_including_depot_unload_783  5.2996691306068044e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_3  arc_capacity_429  1
    load_0_1_3  segment_load_conservation_708  1
    load_0_1_3  segment_load_conservation_722  -1
    load_0_1_3  segment_prefix_lb_723  1
    load_0_1_3  segment_prefix_ub_724  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_4  arc_capacity_431  -20
    arc_0_1_4  connected_order_arc_432  -13
    arc_0_1_4  out_degree_704  1
    arc_0_1_4  in_degree_726  1
    arc_0_1_4  original_T_including_depot_unload_783  5.8442598457899078e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_4  arc_capacity_431  1
    load_0_1_4  segment_load_conservation_708  1
    load_0_1_4  segment_load_conservation_729  -1
    load_0_1_4  segment_prefix_lb_730  1
    load_0_1_4  segment_prefix_ub_731  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_13  arc_capacity_433  -20
    arc_0_1_13  connected_order_arc_434  -13
    arc_0_1_13  out_degree_704  1
    arc_0_1_13  in_degree_733  1
    arc_0_1_13  original_T_including_depot_unload_783  1.9301430792362414e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_13  arc_capacity_433  1
    load_0_1_13  segment_load_conservation_708  1
    load_0_1_13  free_load_conservation_737  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_14  arc_capacity_435  -20
    arc_0_1_14  connected_order_arc_436  -13
    arc_0_1_14  out_degree_704  1
    arc_0_1_14  in_degree_739  1
    arc_0_1_14  original_T_including_depot_unload_783  1.9423028593151403e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_14  arc_capacity_435  1
    load_0_1_14  segment_load_conservation_708  1
    load_0_1_14  free_load_conservation_743  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_15  arc_capacity_437  -20
    arc_0_1_15  connected_order_arc_438  -13
    arc_0_1_15  out_degree_704  1
    arc_0_1_15  in_degree_745  1
    arc_0_1_15  original_T_including_depot_unload_783  1.6292966848558842e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_15  arc_capacity_437  1
    load_0_1_15  segment_load_conservation_708  1
    load_0_1_15  free_load_conservation_749  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_16  arc_capacity_439  -20
    arc_0_1_16  connected_order_arc_440  -13
    arc_0_1_16  out_degree_704  1
    arc_0_1_16  in_degree_751  1
    arc_0_1_16  original_T_including_depot_unload_783  1.6744862285014353e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_16  arc_capacity_439  1
    load_0_1_16  segment_load_conservation_708  1
    load_0_1_16  free_load_conservation_755  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_17  arc_capacity_441  -20
    arc_0_1_17  connected_order_arc_442  -13
    arc_0_1_17  out_degree_704  1
    arc_0_1_17  in_degree_757  1
    arc_0_1_17  original_T_including_depot_unload_783  1.2927075446362680e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_17  arc_capacity_441  1
    load_0_1_17  segment_load_conservation_708  1
    load_0_1_17  free_load_conservation_761  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_18  arc_capacity_443  -20
    arc_0_1_18  connected_order_arc_444  -13
    arc_0_1_18  out_degree_704  1
    arc_0_1_18  in_degree_763  1
    arc_0_1_18  original_T_including_depot_unload_783  1.5437191441012344e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_18  arc_capacity_443  1
    load_0_1_18  segment_load_conservation_708  1
    load_0_1_18  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_19  arc_capacity_445  -20
    arc_0_1_19  connected_order_arc_446  -13
    arc_0_1_19  out_degree_704  1
    arc_0_1_19  in_degree_769  1
    arc_0_1_19  original_T_including_depot_unload_783  7.2751050611121218e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_19  arc_capacity_445  1
    load_0_1_19  segment_load_conservation_708  1
    load_0_1_19  free_load_conservation_773  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_20  arc_capacity_447  -20
    arc_0_1_20  connected_order_arc_448  -13
    arc_0_1_20  out_degree_704  1
    arc_0_1_20  in_degree_775  1
    arc_0_1_20  original_T_including_depot_unload_783  1.6982456083268751e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_20  arc_capacity_447  1
    load_0_1_20  segment_load_conservation_708  1
    load_0_1_20  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_0  arc_capacity_449  -20
    arc_0_2_0  depot_return_or_bypass_703  1
    arc_0_2_0  out_degree_711  1
    arc_0_2_0  original_T_including_depot_unload_783  5.9431738885389052e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_0  arc_capacity_449  1
    load_0_2_0  segment_load_conservation_715  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_1  arc_capacity_450  -20
    arc_0_2_1  connected_order_arc_451  -13
    arc_0_2_1  in_degree_705  1
    arc_0_2_1  out_degree_711  1
    arc_0_2_1  original_T_including_depot_unload_783  6.9736186698570737e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_1  arc_capacity_450  1
    load_0_2_1  segment_load_conservation_708  -1
    load_0_2_1  segment_prefix_lb_709  1
    load_0_2_1  segment_prefix_ub_710  1
    load_0_2_1  segment_load_conservation_715  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_3  arc_capacity_452  -20
    arc_0_2_3  connected_order_arc_453  -13
    arc_0_2_3  out_degree_711  1
    arc_0_2_3  in_degree_719  1
    arc_0_2_3  original_T_including_depot_unload_783  2.1481294511470344e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_3  arc_capacity_452  1
    load_0_2_3  segment_load_conservation_715  1
    load_0_2_3  segment_load_conservation_722  -1
    load_0_2_3  segment_prefix_lb_723  1
    load_0_2_3  segment_prefix_ub_724  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_4  arc_capacity_454  -20
    arc_0_2_4  connected_order_arc_455  -13
    arc_0_2_4  out_degree_711  1
    arc_0_2_4  in_degree_726  1
    arc_0_2_4  original_T_including_depot_unload_783  2.9706418113632907e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_4  arc_capacity_454  1
    load_0_2_4  segment_load_conservation_715  1
    load_0_2_4  segment_load_conservation_729  -1
    load_0_2_4  segment_prefix_lb_730  1
    load_0_2_4  segment_prefix_ub_731  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_13  arc_capacity_456  -20
    arc_0_2_13  connected_order_arc_457  -13
    arc_0_2_13  out_degree_711  1
    arc_0_2_13  in_degree_733  1
    arc_0_2_13  original_T_including_depot_unload_783  1.8527392017187374e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_13  arc_capacity_456  1
    load_0_2_13  segment_load_conservation_715  1
    load_0_2_13  free_load_conservation_737  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_14  arc_capacity_458  -20
    arc_0_2_14  connected_order_arc_459  -13
    arc_0_2_14  out_degree_711  1
    arc_0_2_14  in_degree_739  1
    arc_0_2_14  original_T_including_depot_unload_783  1.8981998787223574e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_14  arc_capacity_458  1
    load_0_2_14  segment_load_conservation_715  1
    load_0_2_14  free_load_conservation_743  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_15  arc_capacity_460  -20
    arc_0_2_15  connected_order_arc_461  -13
    arc_0_2_15  out_degree_711  1
    arc_0_2_15  in_degree_745  1
    arc_0_2_15  original_T_including_depot_unload_783  1.3727638439182763e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_15  arc_capacity_460  1
    load_0_2_15  segment_load_conservation_715  1
    load_0_2_15  free_load_conservation_749  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_16  arc_capacity_462  -20
    arc_0_2_16  connected_order_arc_463  -13
    arc_0_2_16  out_degree_711  1
    arc_0_2_16  in_degree_751  1
    arc_0_2_16  original_T_including_depot_unload_783  1.5657515083159024e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_16  arc_capacity_462  1
    load_0_2_16  segment_load_conservation_715  1
    load_0_2_16  free_load_conservation_755  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_17  arc_capacity_464  -20
    arc_0_2_17  connected_order_arc_465  -13
    arc_0_2_17  out_degree_711  1
    arc_0_2_17  in_degree_757  1
    arc_0_2_17  original_T_including_depot_unload_783  9.8652191996938075e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_17  arc_capacity_464  1
    load_0_2_17  segment_load_conservation_715  1
    load_0_2_17  free_load_conservation_761  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_18  arc_capacity_466  -20
    arc_0_2_18  connected_order_arc_467  -13
    arc_0_2_18  out_degree_711  1
    arc_0_2_18  in_degree_763  1
    arc_0_2_18  original_T_including_depot_unload_783  1.4171530684324468e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_18  arc_capacity_466  1
    load_0_2_18  segment_load_conservation_715  1
    load_0_2_18  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_19  arc_capacity_468  -20
    arc_0_2_19  connected_order_arc_469  -13
    arc_0_2_19  out_degree_711  1
    arc_0_2_19  in_degree_769  1
    arc_0_2_19  original_T_including_depot_unload_783  3.9766425523492148e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_19  arc_capacity_468  1
    load_0_2_19  segment_load_conservation_715  1
    load_0_2_19  free_load_conservation_773  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_20  arc_capacity_470  -20
    arc_0_2_20  connected_order_arc_471  -13
    arc_0_2_20  out_degree_711  1
    arc_0_2_20  in_degree_775  1
    arc_0_2_20  original_T_including_depot_unload_783  1.5230377993795889e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_20  arc_capacity_470  1
    load_0_2_20  segment_load_conservation_715  1
    load_0_2_20  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_0  arc_capacity_472  -20
    arc_0_3_0  depot_return_or_bypass_703  1
    arc_0_3_0  out_degree_718  1
    arc_0_3_0  original_T_including_depot_unload_783  7.2571167924583824e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_0  arc_capacity_472  1
    load_0_3_0  segment_load_conservation_722  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_1  arc_capacity_473  -20
    arc_0_3_1  connected_order_arc_474  -13
    arc_0_3_1  in_degree_705  1
    arc_0_3_1  out_degree_718  1
    arc_0_3_1  original_T_including_depot_unload_783  8.7876124407720954e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_1  arc_capacity_473  1
    load_0_3_1  segment_load_conservation_708  -1
    load_0_3_1  segment_prefix_lb_709  1
    load_0_3_1  segment_prefix_ub_710  1
    load_0_3_1  segment_load_conservation_722  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_2  arc_capacity_475  -20
    arc_0_3_2  connected_order_arc_476  -13
    arc_0_3_2  in_degree_712  1
    arc_0_3_2  out_degree_718  1
    arc_0_3_2  original_T_including_depot_unload_783  2.1481294511470344e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_2  arc_capacity_475  1
    load_0_3_2  segment_load_conservation_715  -1
    load_0_3_2  segment_prefix_lb_716  1
    load_0_3_2  segment_prefix_ub_717  1
    load_0_3_2  segment_load_conservation_722  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_4  arc_capacity_477  -20
    arc_0_3_4  connected_order_arc_478  -13
    arc_0_3_4  out_degree_718  1
    arc_0_3_4  in_degree_726  1
    arc_0_3_4  original_T_including_depot_unload_783  3.0055050459786975e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_4  arc_capacity_477  1
    load_0_3_4  segment_load_conservation_722  1
    load_0_3_4  segment_load_conservation_729  -1
    load_0_3_4  segment_prefix_lb_730  1
    load_0_3_4  segment_prefix_ub_731  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_13  arc_capacity_479  -20
    arc_0_3_13  connected_order_arc_480  -13
    arc_0_3_13  out_degree_718  1
    arc_0_3_13  in_degree_733  1
    arc_0_3_13  original_T_including_depot_unload_783  1.9321899152907124e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_13  arc_capacity_479  1
    load_0_3_13  segment_load_conservation_722  1
    load_0_3_13  free_load_conservation_737  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_14  arc_capacity_481  -20
    arc_0_3_14  connected_order_arc_482  -13
    arc_0_3_14  out_degree_718  1
    arc_0_3_14  in_degree_739  1
    arc_0_3_14  original_T_including_depot_unload_783  1.9969944943207295e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_14  arc_capacity_481  1
    load_0_3_14  segment_load_conservation_722  1
    load_0_3_14  free_load_conservation_743  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_15  arc_capacity_483  -20
    arc_0_3_15  connected_order_arc_484  -13
    arc_0_3_15  out_degree_718  1
    arc_0_3_15  in_degree_745  1
    arc_0_3_15  original_T_including_depot_unload_783  1.3163662834239574e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_15  arc_capacity_483  1
    load_0_3_15  segment_load_conservation_722  1
    load_0_3_15  free_load_conservation_749  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_16  arc_capacity_485  -20
    arc_0_3_16  connected_order_arc_486  -13
    arc_0_3_16  out_degree_718  1
    arc_0_3_16  in_degree_751  1
    arc_0_3_16  original_T_including_depot_unload_783  1.6299527591666472e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_16  arc_capacity_485  1
    load_0_3_16  segment_load_conservation_722  1
    load_0_3_16  free_load_conservation_755  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_17  arc_capacity_487  -20
    arc_0_3_17  connected_order_arc_488  -13
    arc_0_3_17  out_degree_718  1
    arc_0_3_17  in_degree_757  1
    arc_0_3_17  original_T_including_depot_unload_783  7.7190219995954919e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_17  arc_capacity_487  1
    load_0_3_17  segment_load_conservation_722  1
    load_0_3_17  free_load_conservation_761  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_18  arc_capacity_489  -20
    arc_0_3_18  connected_order_arc_490  -13
    arc_0_3_18  out_degree_718  1
    arc_0_3_18  in_degree_763  1
    arc_0_3_18  original_T_including_depot_unload_783  1.4725441282427828e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_18  arc_capacity_489  1
    load_0_3_18  segment_load_conservation_722  1
    load_0_3_18  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_19  arc_capacity_491  -20
    arc_0_3_19  connected_order_arc_492  -13
    arc_0_3_19  out_degree_718  1
    arc_0_3_19  in_degree_769  1
    arc_0_3_19  original_T_including_depot_unload_783  2.3059951477332697e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_19  arc_capacity_491  1
    load_0_3_19  segment_load_conservation_722  1
    load_0_3_19  free_load_conservation_773  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_20  arc_capacity_493  -20
    arc_0_3_20  connected_order_arc_494  -13
    arc_0_3_20  out_degree_718  1
    arc_0_3_20  in_degree_775  1
    arc_0_3_20  original_T_including_depot_unload_783  1.5393972350798747e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_20  arc_capacity_493  1
    load_0_3_20  segment_load_conservation_722  1
    load_0_3_20  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_0  arc_capacity_495  -20
    arc_0_4_0  depot_return_or_bypass_703  1
    arc_0_4_0  out_degree_725  1
    arc_0_4_0  original_T_including_depot_unload_783  4.6364706268001146e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_0  arc_capacity_495  1
    load_0_4_0  segment_load_conservation_729  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_1  arc_capacity_496  -20
    arc_0_4_1  connected_order_arc_497  -13
    arc_0_4_1  in_degree_705  1
    arc_0_4_1  out_degree_725  1
    arc_0_4_1  original_T_including_depot_unload_783  6.7517249538835438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_1  arc_capacity_496  1
    load_0_4_1  segment_load_conservation_708  -1
    load_0_4_1  segment_prefix_lb_709  1
    load_0_4_1  segment_prefix_ub_710  1
    load_0_4_1  segment_load_conservation_729  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_2  arc_capacity_498  -20
    arc_0_4_2  connected_order_arc_499  -13
    arc_0_4_2  in_degree_712  1
    arc_0_4_2  out_degree_725  1
    arc_0_4_2  original_T_including_depot_unload_783  2.9706418113632907e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_2  arc_capacity_498  1
    load_0_4_2  segment_load_conservation_715  -1
    load_0_4_2  segment_prefix_lb_716  1
    load_0_4_2  segment_prefix_ub_717  1
    load_0_4_2  segment_load_conservation_729  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_3  arc_capacity_500  -20
    arc_0_4_3  connected_order_arc_501  -13
    arc_0_4_3  in_degree_719  1
    arc_0_4_3  out_degree_725  1
    arc_0_4_3  original_T_including_depot_unload_783  3.0055050459786975e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_3  arc_capacity_500  1
    load_0_4_3  segment_load_conservation_722  -1
    load_0_4_3  segment_prefix_lb_723  1
    load_0_4_3  segment_prefix_ub_724  1
    load_0_4_3  segment_load_conservation_729  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_13  arc_capacity_502  -20
    arc_0_4_13  connected_order_arc_503  -13
    arc_0_4_13  out_degree_725  1
    arc_0_4_13  in_degree_733  1
    arc_0_4_13  original_T_including_depot_unload_783  1.6320542581729912e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_13  arc_capacity_502  1
    load_0_4_13  segment_load_conservation_729  1
    load_0_4_13  free_load_conservation_737  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_14  arc_capacity_504  -20
    arc_0_4_14  connected_order_arc_505  -13
    arc_0_4_14  out_degree_725  1
    arc_0_4_14  in_degree_739  1
    arc_0_4_14  original_T_including_depot_unload_783  1.7000764266516874e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_14  arc_capacity_504  1
    load_0_4_14  segment_load_conservation_729  1
    load_0_4_14  free_load_conservation_743  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_15  arc_capacity_506  -20
    arc_0_4_15  connected_order_arc_507  -13
    arc_0_4_15  out_degree_725  1
    arc_0_4_15  in_degree_745  1
    arc_0_4_15  original_T_including_depot_unload_783  1075.72043838369
    MARKER    'MARKER'                 'INTEND'
    load_0_4_15  arc_capacity_506  1
    load_0_4_15  segment_load_conservation_729  1
    load_0_4_15  free_load_conservation_749  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_16  arc_capacity_508  -20
    arc_0_4_16  connected_order_arc_509  -13
    arc_0_4_16  out_degree_725  1
    arc_0_4_16  in_degree_751  1
    arc_0_4_16  original_T_including_depot_unload_783  1.3294477435531232e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_16  arc_capacity_508  1
    load_0_4_16  segment_load_conservation_729  1
    load_0_4_16  free_load_conservation_755  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_17  arc_capacity_510  -20
    arc_0_4_17  connected_order_arc_511  -13
    arc_0_4_17  out_degree_725  1
    arc_0_4_17  in_degree_757  1
    arc_0_4_17  original_T_including_depot_unload_783  9.1576870176747968e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_17  arc_capacity_510  1
    load_0_4_17  segment_load_conservation_729  1
    load_0_4_17  free_load_conservation_761  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_18  arc_capacity_512  -20
    arc_0_4_18  connected_order_arc_513  -13
    arc_0_4_18  out_degree_725  1
    arc_0_4_18  in_degree_763  1
    arc_0_4_18  original_T_including_depot_unload_783  1.1724800521319269e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_18  arc_capacity_512  1
    load_0_4_18  segment_load_conservation_729  1
    load_0_4_18  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_19  arc_capacity_514  -20
    arc_0_4_19  connected_order_arc_515  -13
    arc_0_4_19  out_degree_725  1
    arc_0_4_19  in_degree_769  1
    arc_0_4_19  original_T_including_depot_unload_783  2.6602972191926557e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_19  arc_capacity_514  1
    load_0_4_19  segment_load_conservation_729  1
    load_0_4_19  free_load_conservation_773  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_20  arc_capacity_516  -20
    arc_0_4_20  connected_order_arc_517  -13
    arc_0_4_20  out_degree_725  1
    arc_0_4_20  in_degree_775  1
    arc_0_4_20  original_T_including_depot_unload_783  1.2492199513695298e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_20  arc_capacity_516  1
    load_0_4_20  segment_load_conservation_729  1
    load_0_4_20  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_0  arc_capacity_518  -20
    arc_0_13_0  depot_return_or_bypass_703  1
    arc_0_13_0  out_degree_732  1
    arc_0_13_0  original_T_including_depot_unload_783  1.2751323166566442e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_0  arc_capacity_518  1
    load_0_13_0  free_load_conservation_737  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_1  arc_capacity_519  -20
    arc_0_13_1  connected_order_arc_520  -13
    arc_0_13_1  in_degree_705  1
    arc_0_13_1  out_degree_732  1
    arc_0_13_1  original_T_including_depot_unload_783  1337.70453645659
    MARKER    'MARKER'                 'INTEND'
    load_0_13_1  arc_capacity_519  1
    load_0_13_1  segment_load_conservation_708  -1
    load_0_13_1  segment_prefix_lb_709  1
    load_0_13_1  segment_prefix_ub_710  1
    load_0_13_1  free_load_conservation_737  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_2  arc_capacity_521  -20
    arc_0_13_2  connected_order_arc_522  -13
    arc_0_13_2  in_degree_712  1
    arc_0_13_2  out_degree_732  1
    arc_0_13_2  original_T_including_depot_unload_783  1.8527392017187374e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_2  arc_capacity_521  1
    load_0_13_2  segment_load_conservation_715  -1
    load_0_13_2  segment_prefix_lb_716  1
    load_0_13_2  segment_prefix_ub_717  1
    load_0_13_2  free_load_conservation_737  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_3  arc_capacity_523  -20
    arc_0_13_3  connected_order_arc_524  -13
    arc_0_13_3  in_degree_719  1
    arc_0_13_3  out_degree_732  1
    arc_0_13_3  original_T_including_depot_unload_783  1.9321899152907124e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_3  arc_capacity_523  1
    load_0_13_3  segment_load_conservation_722  -1
    load_0_13_3  segment_prefix_lb_723  1
    load_0_13_3  segment_prefix_ub_724  1
    load_0_13_3  free_load_conservation_737  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_4  arc_capacity_525  -20
    arc_0_13_4  connected_order_arc_526  -13
    arc_0_13_4  in_degree_726  1
    arc_0_13_4  out_degree_732  1
    arc_0_13_4  original_T_including_depot_unload_783  1.6320542581729912e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_4  arc_capacity_525  1
    load_0_13_4  segment_load_conservation_729  -1
    load_0_13_4  segment_prefix_lb_730  1
    load_0_13_4  segment_prefix_ub_731  1
    load_0_13_4  free_load_conservation_737  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_14  arc_capacity_527  -20
    arc_0_13_14  connected_order_arc_528  -13
    arc_0_13_14  out_degree_732  1
    arc_0_13_14  in_degree_739  1
    arc_0_13_14  original_T_including_depot_unload_783  1.9785969874636677e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_14  arc_capacity_527  1
    load_0_13_14  free_load_conservation_737  1
    load_0_13_14  free_load_conservation_743  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_15  arc_capacity_529  -20
    arc_0_13_15  connected_order_arc_530  -13
    arc_0_13_15  out_degree_732  1
    arc_0_13_15  in_degree_745  1
    arc_0_13_15  original_T_including_depot_unload_783  1.1499210972200315e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_15  arc_capacity_529  1
    load_0_13_15  free_load_conservation_737  1
    load_0_13_15  free_load_conservation_749  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_16  arc_capacity_531  -20
    arc_0_13_16  connected_order_arc_532  -13
    arc_0_13_16  out_degree_732  1
    arc_0_13_16  in_degree_751  1
    arc_0_13_16  original_T_including_depot_unload_783  3.2286832955801827e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_16  arc_capacity_531  1
    load_0_13_16  free_load_conservation_737  1
    load_0_13_16  free_load_conservation_755  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_17  arc_capacity_533  -20
    arc_0_13_17  connected_order_arc_534  -13
    arc_0_13_17  out_degree_732  1
    arc_0_13_17  in_degree_757  1
    arc_0_13_17  original_T_including_depot_unload_783  2.3332890980657526e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_17  arc_capacity_533  1
    load_0_13_17  free_load_conservation_737  1
    load_0_13_17  free_load_conservation_761  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_18  arc_capacity_535  -20
    arc_0_13_18  connected_order_arc_536  -13
    arc_0_13_18  out_degree_732  1
    arc_0_13_18  in_degree_763  1
    arc_0_13_18  original_T_including_depot_unload_783  4.8905010520753694e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_18  arc_capacity_535  1
    load_0_13_18  free_load_conservation_737  1
    load_0_13_18  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_19  arc_capacity_537  -20
    arc_0_13_19  connected_order_arc_538  -13
    arc_0_13_19  out_degree_732  1
    arc_0_13_19  in_degree_769  1
    arc_0_13_19  original_T_including_depot_unload_783  1.8319650761318992e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_19  arc_capacity_537  1
    load_0_13_19  free_load_conservation_737  1
    load_0_13_19  free_load_conservation_773  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_20  arc_capacity_539  -20
    arc_0_13_20  connected_order_arc_540  -13
    arc_0_13_20  out_degree_732  1
    arc_0_13_20  in_degree_775  1
    arc_0_13_20  original_T_including_depot_unload_783  6.2793211180612207e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_20  arc_capacity_539  1
    load_0_13_20  free_load_conservation_737  1
    load_0_13_20  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_0  arc_capacity_541  -20
    arc_0_14_0  depot_return_or_bypass_703  1
    arc_0_14_0  out_degree_738  1
    arc_0_14_0  original_T_including_depot_unload_783  1.3076700111397606e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_0  arc_capacity_541  1
    load_0_14_0  free_load_conservation_743  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_1  arc_capacity_542  -20
    arc_0_14_1  connected_order_arc_543  -13
    arc_0_14_1  in_degree_705  1
    arc_0_14_1  out_degree_738  1
    arc_0_14_1  original_T_including_depot_unload_783  1.3286968036345565e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_1  arc_capacity_542  1
    load_0_14_1  segment_load_conservation_708  -1
    load_0_14_1  segment_prefix_lb_709  1
    load_0_14_1  segment_prefix_ub_710  1
    load_0_14_1  free_load_conservation_743  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_2  arc_capacity_544  -20
    arc_0_14_2  connected_order_arc_545  -13
    arc_0_14_2  in_degree_712  1
    arc_0_14_2  out_degree_738  1
    arc_0_14_2  original_T_including_depot_unload_783  1.8981998787223574e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_2  arc_capacity_544  1
    load_0_14_2  segment_load_conservation_715  -1
    load_0_14_2  segment_prefix_lb_716  1
    load_0_14_2  segment_prefix_ub_717  1
    load_0_14_2  free_load_conservation_743  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_3  arc_capacity_546  -20
    arc_0_14_3  connected_order_arc_547  -13
    arc_0_14_3  in_degree_719  1
    arc_0_14_3  out_degree_738  1
    arc_0_14_3  original_T_including_depot_unload_783  1.9969944943207295e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_3  arc_capacity_546  1
    load_0_14_3  segment_load_conservation_722  -1
    load_0_14_3  segment_prefix_lb_723  1
    load_0_14_3  segment_prefix_ub_724  1
    load_0_14_3  free_load_conservation_743  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_4  arc_capacity_548  -20
    arc_0_14_4  connected_order_arc_549  -13
    arc_0_14_4  in_degree_726  1
    arc_0_14_4  out_degree_738  1
    arc_0_14_4  original_T_including_depot_unload_783  1.7000764266516874e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_4  arc_capacity_548  1
    load_0_14_4  segment_load_conservation_729  -1
    load_0_14_4  segment_prefix_lb_730  1
    load_0_14_4  segment_prefix_ub_731  1
    load_0_14_4  free_load_conservation_743  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_13  arc_capacity_550  -20
    arc_0_14_13  connected_order_arc_551  -13
    arc_0_14_13  in_degree_733  1
    arc_0_14_13  out_degree_738  1
    arc_0_14_13  original_T_including_depot_unload_783  1.9785969874636677e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_13  arc_capacity_550  1
    load_0_14_13  free_load_conservation_737  -1
    load_0_14_13  free_load_conservation_743  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_15  arc_capacity_552  -20
    arc_0_14_15  connected_order_arc_553  -13
    arc_0_14_15  out_degree_738  1
    arc_0_14_15  in_degree_745  1
    arc_0_14_15  original_T_including_depot_unload_783  1.3218357148919101e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_15  arc_capacity_552  1
    load_0_14_15  free_load_conservation_743  1
    load_0_14_15  free_load_conservation_749  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_16  arc_capacity_554  -20
    arc_0_14_16  connected_order_arc_555  -13
    arc_0_14_16  out_degree_738  1
    arc_0_14_16  in_degree_751  1
    arc_0_14_16  original_T_including_depot_unload_783  4.6588884124393707e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_16  arc_capacity_554  1
    load_0_14_16  free_load_conservation_743  1
    load_0_14_16  free_load_conservation_755  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_17  arc_capacity_556  -20
    arc_0_14_17  connected_order_arc_557  -13
    arc_0_14_17  out_degree_738  1
    arc_0_14_17  in_degree_757  1
    arc_0_14_17  original_T_including_depot_unload_783  2.4500766064196278e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_17  arc_capacity_556  1
    load_0_14_17  free_load_conservation_743  1
    load_0_14_17  free_load_conservation_761  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_18  arc_capacity_558  -20
    arc_0_14_18  connected_order_arc_559  -13
    arc_0_14_18  out_degree_738  1
    arc_0_14_18  in_degree_763  1
    arc_0_14_18  original_T_including_depot_unload_783  6.2102815646279714e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_18  arc_capacity_558  1
    load_0_14_18  free_load_conservation_743  1
    load_0_14_18  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_19  arc_capacity_560  -20
    arc_0_14_19  connected_order_arc_561  -13
    arc_0_14_19  out_degree_738  1
    arc_0_14_19  in_degree_769  1
    arc_0_14_19  original_T_including_depot_unload_783  1.9170200697382236e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_19  arc_capacity_560  1
    load_0_14_19  free_load_conservation_743  1
    load_0_14_19  free_load_conservation_773  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_20  arc_capacity_562  -20
    arc_0_14_20  connected_order_arc_563  -13
    arc_0_14_20  out_degree_738  1
    arc_0_14_20  in_degree_775  1
    arc_0_14_20  original_T_including_depot_unload_783  8.0531033344008677e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_20  arc_capacity_562  1
    load_0_14_20  free_load_conservation_743  1
    load_0_14_20  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_0  arc_capacity_564  -20
    arc_0_15_0  depot_return_or_bypass_703  1
    arc_0_15_0  out_degree_744  1
    arc_0_15_0  original_T_including_depot_unload_783  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_0  arc_capacity_564  1
    load_0_15_0  free_load_conservation_749  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_1  arc_capacity_565  -20
    arc_0_15_1  connected_order_arc_566  -13
    arc_0_15_1  in_degree_705  1
    arc_0_15_1  out_degree_744  1
    arc_0_15_1  original_T_including_depot_unload_783  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_1  arc_capacity_565  1
    load_0_15_1  segment_load_conservation_708  -1
    load_0_15_1  segment_prefix_lb_709  1
    load_0_15_1  segment_prefix_ub_710  1
    load_0_15_1  free_load_conservation_749  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_2  arc_capacity_567  -20
    arc_0_15_2  connected_order_arc_568  -13
    arc_0_15_2  in_degree_712  1
    arc_0_15_2  out_degree_744  1
    arc_0_15_2  original_T_including_depot_unload_783  1.3727638439182763e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_2  arc_capacity_567  1
    load_0_15_2  segment_load_conservation_715  -1
    load_0_15_2  segment_prefix_lb_716  1
    load_0_15_2  segment_prefix_ub_717  1
    load_0_15_2  free_load_conservation_749  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_3  arc_capacity_569  -20
    arc_0_15_3  connected_order_arc_570  -13
    arc_0_15_3  in_degree_719  1
    arc_0_15_3  out_degree_744  1
    arc_0_15_3  original_T_including_depot_unload_783  1.3163662834239574e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_3  arc_capacity_569  1
    load_0_15_3  segment_load_conservation_722  -1
    load_0_15_3  segment_prefix_lb_723  1
    load_0_15_3  segment_prefix_ub_724  1
    load_0_15_3  free_load_conservation_749  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_4  arc_capacity_571  -20
    arc_0_15_4  connected_order_arc_572  -13
    arc_0_15_4  in_degree_726  1
    arc_0_15_4  out_degree_744  1
    arc_0_15_4  original_T_including_depot_unload_783  1075.72043838369
    MARKER    'MARKER'                 'INTEND'
    load_0_15_4  arc_capacity_571  1
    load_0_15_4  segment_load_conservation_729  -1
    load_0_15_4  segment_prefix_lb_730  1
    load_0_15_4  segment_prefix_ub_731  1
    load_0_15_4  free_load_conservation_749  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_13  arc_capacity_573  -20
    arc_0_15_13  connected_order_arc_574  -13
    arc_0_15_13  in_degree_733  1
    arc_0_15_13  out_degree_744  1
    arc_0_15_13  original_T_including_depot_unload_783  1.1499210972200315e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_13  arc_capacity_573  1
    load_0_15_13  free_load_conservation_737  -1
    load_0_15_13  free_load_conservation_749  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_14  arc_capacity_575  -20
    arc_0_15_14  connected_order_arc_576  -13
    arc_0_15_14  in_degree_739  1
    arc_0_15_14  out_degree_744  1
    arc_0_15_14  original_T_including_depot_unload_783  1.3218357148919101e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_14  arc_capacity_575  1
    load_0_15_14  free_load_conservation_743  -1
    load_0_15_14  free_load_conservation_749  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_16  arc_capacity_577  -20
    arc_0_15_16  connected_order_arc_578  -13
    arc_0_15_16  out_degree_744  1
    arc_0_15_16  in_degree_751  1
    arc_0_15_16  original_T_including_depot_unload_783  861.314419336229
    MARKER    'MARKER'                 'INTEND'
    load_0_15_16  arc_capacity_577  1
    load_0_15_16  free_load_conservation_749  1
    load_0_15_16  free_load_conservation_755  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_17  arc_capacity_579  -20
    arc_0_15_17  connected_order_arc_580  -13
    arc_0_15_17  out_degree_744  1
    arc_0_15_17  in_degree_757  1
    arc_0_15_17  original_T_including_depot_unload_783  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_17  arc_capacity_579  1
    load_0_15_17  free_load_conservation_749  1
    load_0_15_17  free_load_conservation_761  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_18  arc_capacity_581  -20
    arc_0_15_18  connected_order_arc_582  -13
    arc_0_15_18  out_degree_744  1
    arc_0_15_18  in_degree_763  1
    arc_0_15_18  original_T_including_depot_unload_783  7.3227602527872671e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_18  arc_capacity_581  1
    load_0_15_18  free_load_conservation_749  1
    load_0_15_18  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_19  arc_capacity_583  -20
    arc_0_15_19  connected_order_arc_584  -13
    arc_0_15_19  out_degree_744  1
    arc_0_15_19  in_degree_769  1
    arc_0_15_19  original_T_including_depot_unload_783  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_19  arc_capacity_583  1
    load_0_15_19  free_load_conservation_749  1
    load_0_15_19  free_load_conservation_773  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_20  arc_capacity_585  -20
    arc_0_15_20  connected_order_arc_586  -13
    arc_0_15_20  out_degree_744  1
    arc_0_15_20  in_degree_775  1
    arc_0_15_20  original_T_including_depot_unload_783  5.2280951376932137e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_20  arc_capacity_585  1
    load_0_15_20  free_load_conservation_749  1
    load_0_15_20  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_0  arc_capacity_587  -20
    arc_0_16_0  depot_return_or_bypass_703  1
    arc_0_16_0  out_degree_750  1
    arc_0_16_0  original_T_including_depot_unload_783  1.0088905112952611e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_0  arc_capacity_587  1
    load_0_16_0  free_load_conservation_755  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_1  arc_capacity_588  -20
    arc_0_16_1  connected_order_arc_589  -13
    arc_0_16_1  in_degree_705  1
    arc_0_16_1  out_degree_750  1
    arc_0_16_1  original_T_including_depot_unload_783  1.1190931627527086e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_1  arc_capacity_588  1
    load_0_16_1  segment_load_conservation_708  -1
    load_0_16_1  segment_prefix_lb_709  1
    load_0_16_1  segment_prefix_ub_710  1
    load_0_16_1  free_load_conservation_755  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_2  arc_capacity_590  -20
    arc_0_16_2  connected_order_arc_591  -13
    arc_0_16_2  in_degree_712  1
    arc_0_16_2  out_degree_750  1
    arc_0_16_2  original_T_including_depot_unload_783  1.5657515083159024e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_2  arc_capacity_590  1
    load_0_16_2  segment_load_conservation_715  -1
    load_0_16_2  segment_prefix_lb_716  1
    load_0_16_2  segment_prefix_ub_717  1
    load_0_16_2  free_load_conservation_755  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_3  arc_capacity_592  -20
    arc_0_16_3  connected_order_arc_593  -13
    arc_0_16_3  in_degree_719  1
    arc_0_16_3  out_degree_750  1
    arc_0_16_3  original_T_including_depot_unload_783  1.6299527591666472e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_3  arc_capacity_592  1
    load_0_16_3  segment_load_conservation_722  -1
    load_0_16_3  segment_prefix_lb_723  1
    load_0_16_3  segment_prefix_ub_724  1
    load_0_16_3  free_load_conservation_755  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_4  arc_capacity_594  -20
    arc_0_16_4  connected_order_arc_595  -13
    arc_0_16_4  in_degree_726  1
    arc_0_16_4  out_degree_750  1
    arc_0_16_4  original_T_including_depot_unload_783  1.3294477435531232e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_4  arc_capacity_594  1
    load_0_16_4  segment_load_conservation_729  -1
    load_0_16_4  segment_prefix_lb_730  1
    load_0_16_4  segment_prefix_ub_731  1
    load_0_16_4  free_load_conservation_755  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_13  arc_capacity_596  -20
    arc_0_16_13  connected_order_arc_597  -13
    arc_0_16_13  in_degree_733  1
    arc_0_16_13  out_degree_750  1
    arc_0_16_13  original_T_including_depot_unload_783  3.2286832955801827e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_13  arc_capacity_596  1
    load_0_16_13  free_load_conservation_737  -1
    load_0_16_13  free_load_conservation_755  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_14  arc_capacity_598  -20
    arc_0_16_14  connected_order_arc_599  -13
    arc_0_16_14  in_degree_739  1
    arc_0_16_14  out_degree_750  1
    arc_0_16_14  original_T_including_depot_unload_783  4.6588884124393707e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_14  arc_capacity_598  1
    load_0_16_14  free_load_conservation_743  -1
    load_0_16_14  free_load_conservation_755  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_15  arc_capacity_600  -20
    arc_0_16_15  connected_order_arc_601  -13
    arc_0_16_15  in_degree_745  1
    arc_0_16_15  out_degree_750  1
    arc_0_16_15  original_T_including_depot_unload_783  861.314419336229
    MARKER    'MARKER'                 'INTEND'
    load_0_16_15  arc_capacity_600  1
    load_0_16_15  free_load_conservation_749  -1
    load_0_16_15  free_load_conservation_755  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_17  arc_capacity_602  -20
    arc_0_16_17  connected_order_arc_603  -13
    arc_0_16_17  out_degree_750  1
    arc_0_16_17  in_degree_757  1
    arc_0_16_17  original_T_including_depot_unload_783  2.0104743468619281e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_17  arc_capacity_602  1
    load_0_16_17  free_load_conservation_755  1
    load_0_16_17  free_load_conservation_761  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_18  arc_capacity_604  -20
    arc_0_16_18  connected_order_arc_605  -13
    arc_0_16_18  out_degree_750  1
    arc_0_16_18  in_degree_763  1
    arc_0_16_18  original_T_including_depot_unload_783  1.6651295535886251e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_18  arc_capacity_604  1
    load_0_16_18  free_load_conservation_755  1
    load_0_16_18  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_19  arc_capacity_606  -20
    arc_0_16_19  connected_order_arc_607  -13
    arc_0_16_19  out_degree_750  1
    arc_0_16_19  in_degree_769  1
    arc_0_16_19  original_T_including_depot_unload_783  1.5183735648810946e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_19  arc_capacity_606  1
    load_0_16_19  free_load_conservation_755  1
    load_0_16_19  free_load_conservation_773  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_20  arc_capacity_608  -20
    arc_0_16_20  connected_order_arc_609  -13
    arc_0_16_20  out_degree_750  1
    arc_0_16_20  in_degree_775  1
    arc_0_16_20  original_T_including_depot_unload_783  3.6094216796124527e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_20  arc_capacity_608  1
    load_0_16_20  free_load_conservation_755  1
    load_0_16_20  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_0  arc_capacity_610  -20
    arc_0_17_0  depot_return_or_bypass_703  1
    arc_0_17_0  out_degree_756  1
    arc_0_17_0  original_T_including_depot_unload_783  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_0  arc_capacity_610  1
    load_0_17_0  free_load_conservation_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_1  arc_capacity_611  -20
    arc_0_17_1  connected_order_arc_612  -13
    arc_0_17_1  in_degree_705  1
    arc_0_17_1  out_degree_756  1
    arc_0_17_1  original_T_including_depot_unload_783  1.5902582434549993e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_1  arc_capacity_611  1
    load_0_17_1  segment_load_conservation_708  -1
    load_0_17_1  segment_prefix_lb_709  1
    load_0_17_1  segment_prefix_ub_710  1
    load_0_17_1  free_load_conservation_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_2  arc_capacity_613  -20
    arc_0_17_2  connected_order_arc_614  -13
    arc_0_17_2  in_degree_712  1
    arc_0_17_2  out_degree_756  1
    arc_0_17_2  original_T_including_depot_unload_783  9.8652191996938075e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_2  arc_capacity_613  1
    load_0_17_2  segment_load_conservation_715  -1
    load_0_17_2  segment_prefix_lb_716  1
    load_0_17_2  segment_prefix_ub_717  1
    load_0_17_2  free_load_conservation_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_3  arc_capacity_615  -20
    arc_0_17_3  connected_order_arc_616  -13
    arc_0_17_3  in_degree_719  1
    arc_0_17_3  out_degree_756  1
    arc_0_17_3  original_T_including_depot_unload_783  7.7190219995954919e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_3  arc_capacity_615  1
    load_0_17_3  segment_load_conservation_722  -1
    load_0_17_3  segment_prefix_lb_723  1
    load_0_17_3  segment_prefix_ub_724  1
    load_0_17_3  free_load_conservation_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_4  arc_capacity_617  -20
    arc_0_17_4  connected_order_arc_618  -13
    arc_0_17_4  in_degree_726  1
    arc_0_17_4  out_degree_756  1
    arc_0_17_4  original_T_including_depot_unload_783  9.1576870176747968e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_4  arc_capacity_617  1
    load_0_17_4  segment_load_conservation_729  -1
    load_0_17_4  segment_prefix_lb_730  1
    load_0_17_4  segment_prefix_ub_731  1
    load_0_17_4  free_load_conservation_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_13  arc_capacity_619  -20
    arc_0_17_13  connected_order_arc_620  -13
    arc_0_17_13  in_degree_733  1
    arc_0_17_13  out_degree_756  1
    arc_0_17_13  original_T_including_depot_unload_783  2.3332890980657526e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_13  arc_capacity_619  1
    load_0_17_13  free_load_conservation_737  -1
    load_0_17_13  free_load_conservation_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_14  arc_capacity_621  -20
    arc_0_17_14  connected_order_arc_622  -13
    arc_0_17_14  in_degree_739  1
    arc_0_17_14  out_degree_756  1
    arc_0_17_14  original_T_including_depot_unload_783  2.4500766064196278e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_14  arc_capacity_621  1
    load_0_17_14  free_load_conservation_743  -1
    load_0_17_14  free_load_conservation_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_15  arc_capacity_623  -20
    arc_0_17_15  connected_order_arc_624  -13
    arc_0_17_15  in_degree_745  1
    arc_0_17_15  out_degree_756  1
    arc_0_17_15  original_T_including_depot_unload_783  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_15  arc_capacity_623  1
    load_0_17_15  free_load_conservation_749  -1
    load_0_17_15  free_load_conservation_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_16  arc_capacity_625  -20
    arc_0_17_16  connected_order_arc_626  -13
    arc_0_17_16  in_degree_751  1
    arc_0_17_16  out_degree_756  1
    arc_0_17_16  original_T_including_depot_unload_783  2.0104743468619281e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_16  arc_capacity_625  1
    load_0_17_16  free_load_conservation_755  -1
    load_0_17_16  free_load_conservation_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_18  arc_capacity_627  -20
    arc_0_17_18  connected_order_arc_628  -13
    arc_0_17_18  out_degree_756  1
    arc_0_17_18  in_degree_763  1
    arc_0_17_18  original_T_including_depot_unload_783  1.8442669473423912e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_18  arc_capacity_627  1
    load_0_17_18  free_load_conservation_761  1
    load_0_17_18  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_19  arc_capacity_629  -20
    arc_0_17_19  connected_order_arc_630  -13
    arc_0_17_19  out_degree_756  1
    arc_0_17_19  in_degree_769  1
    arc_0_17_19  original_T_including_depot_unload_783  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_19  arc_capacity_629  1
    load_0_17_19  free_load_conservation_761  1
    load_0_17_19  free_load_conservation_773  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_20  arc_capacity_631  -20
    arc_0_17_20  connected_order_arc_632  -13
    arc_0_17_20  out_degree_756  1
    arc_0_17_20  in_degree_775  1
    arc_0_17_20  original_T_including_depot_unload_783  1.7883808204567979e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_20  arc_capacity_631  1
    load_0_17_20  free_load_conservation_761  1
    load_0_17_20  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_0  arc_capacity_633  -20
    arc_0_18_0  depot_return_or_bypass_703  1
    arc_0_18_0  out_degree_762  1
    arc_0_18_0  original_T_including_depot_unload_783  8.7749189782983967e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_0  arc_capacity_633  1
    load_0_18_0  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_1  arc_capacity_634  -20
    arc_0_18_1  connected_order_arc_635  -13
    arc_0_18_1  in_degree_705  1
    arc_0_18_1  out_degree_762  1
    arc_0_18_1  original_T_including_depot_unload_783  1.0170488276971105e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_1  arc_capacity_634  1
    load_0_18_1  segment_load_conservation_708  -1
    load_0_18_1  segment_prefix_lb_709  1
    load_0_18_1  segment_prefix_ub_710  1
    load_0_18_1  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_2  arc_capacity_636  -20
    arc_0_18_2  connected_order_arc_637  -13
    arc_0_18_2  in_degree_712  1
    arc_0_18_2  out_degree_762  1
    arc_0_18_2  original_T_including_depot_unload_783  1.4171530684324468e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_2  arc_capacity_636  1
    load_0_18_2  segment_load_conservation_715  -1
    load_0_18_2  segment_prefix_lb_716  1
    load_0_18_2  segment_prefix_ub_717  1
    load_0_18_2  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_3  arc_capacity_638  -20
    arc_0_18_3  connected_order_arc_639  -13
    arc_0_18_3  in_degree_719  1
    arc_0_18_3  out_degree_762  1
    arc_0_18_3  original_T_including_depot_unload_783  1.4725441282427828e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_3  arc_capacity_638  1
    load_0_18_3  segment_load_conservation_722  -1
    load_0_18_3  segment_prefix_lb_723  1
    load_0_18_3  segment_prefix_ub_724  1
    load_0_18_3  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_4  arc_capacity_640  -20
    arc_0_18_4  connected_order_arc_641  -13
    arc_0_18_4  in_degree_726  1
    arc_0_18_4  out_degree_762  1
    arc_0_18_4  original_T_including_depot_unload_783  1.1724800521319269e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_4  arc_capacity_640  1
    load_0_18_4  segment_load_conservation_729  -1
    load_0_18_4  segment_prefix_lb_730  1
    load_0_18_4  segment_prefix_ub_731  1
    load_0_18_4  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_13  arc_capacity_642  -20
    arc_0_18_13  connected_order_arc_643  -13
    arc_0_18_13  in_degree_733  1
    arc_0_18_13  out_degree_762  1
    arc_0_18_13  original_T_including_depot_unload_783  4.8905010520753694e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_13  arc_capacity_642  1
    load_0_18_13  free_load_conservation_737  -1
    load_0_18_13  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_14  arc_capacity_644  -20
    arc_0_18_14  connected_order_arc_645  -13
    arc_0_18_14  in_degree_739  1
    arc_0_18_14  out_degree_762  1
    arc_0_18_14  original_T_including_depot_unload_783  6.2102815646279714e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_14  arc_capacity_644  1
    load_0_18_14  free_load_conservation_743  -1
    load_0_18_14  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_15  arc_capacity_646  -20
    arc_0_18_15  connected_order_arc_647  -13
    arc_0_18_15  in_degree_745  1
    arc_0_18_15  out_degree_762  1
    arc_0_18_15  original_T_including_depot_unload_783  7.3227602527872671e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_15  arc_capacity_646  1
    load_0_18_15  free_load_conservation_749  -1
    load_0_18_15  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_16  arc_capacity_648  -20
    arc_0_18_16  connected_order_arc_649  -13
    arc_0_18_16  in_degree_751  1
    arc_0_18_16  out_degree_762  1
    arc_0_18_16  original_T_including_depot_unload_783  1.6651295535886251e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_16  arc_capacity_648  1
    load_0_18_16  free_load_conservation_755  -1
    load_0_18_16  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_17  arc_capacity_650  -20
    arc_0_18_17  connected_order_arc_651  -13
    arc_0_18_17  in_degree_757  1
    arc_0_18_17  out_degree_762  1
    arc_0_18_17  original_T_including_depot_unload_783  1.8442669473423912e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_17  arc_capacity_650  1
    load_0_18_17  free_load_conservation_761  -1
    load_0_18_17  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_19  arc_capacity_652  -20
    arc_0_18_19  connected_order_arc_653  -13
    arc_0_18_19  out_degree_762  1
    arc_0_18_19  in_degree_769  1
    arc_0_18_19  original_T_including_depot_unload_783  1.3551088510632424e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_19  arc_capacity_652  1
    load_0_18_19  free_load_conservation_767  1
    load_0_18_19  free_load_conservation_773  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_20  arc_capacity_654  -20
    arc_0_18_20  connected_order_arc_655  -13
    arc_0_18_20  out_degree_762  1
    arc_0_18_20  in_degree_775  1
    arc_0_18_20  original_T_including_depot_unload_783  2.8747557636937808e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_20  arc_capacity_654  1
    load_0_18_20  free_load_conservation_767  1
    load_0_18_20  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_0  arc_capacity_656  -20
    arc_0_19_0  depot_return_or_bypass_703  1
    arc_0_19_0  out_degree_768  1
    arc_0_19_0  original_T_including_depot_unload_783  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_0  arc_capacity_656  1
    load_0_19_0  free_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_1  arc_capacity_657  -20
    arc_0_19_1  connected_order_arc_658  -13
    arc_0_19_1  in_degree_705  1
    arc_0_19_1  out_degree_768  1
    arc_0_19_1  original_T_including_depot_unload_783  9.3905252655669165e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_1  arc_capacity_657  1
    load_0_19_1  segment_load_conservation_708  -1
    load_0_19_1  segment_prefix_lb_709  1
    load_0_19_1  segment_prefix_ub_710  1
    load_0_19_1  free_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_2  arc_capacity_659  -20
    arc_0_19_2  connected_order_arc_660  -13
    arc_0_19_2  in_degree_712  1
    arc_0_19_2  out_degree_768  1
    arc_0_19_2  original_T_including_depot_unload_783  3.9766425523492148e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_2  arc_capacity_659  1
    load_0_19_2  segment_load_conservation_715  -1
    load_0_19_2  segment_prefix_lb_716  1
    load_0_19_2  segment_prefix_ub_717  1
    load_0_19_2  free_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_3  arc_capacity_661  -20
    arc_0_19_3  connected_order_arc_662  -13
    arc_0_19_3  in_degree_719  1
    arc_0_19_3  out_degree_768  1
    arc_0_19_3  original_T_including_depot_unload_783  2.3059951477332697e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_3  arc_capacity_661  1
    load_0_19_3  segment_load_conservation_722  -1
    load_0_19_3  segment_prefix_lb_723  1
    load_0_19_3  segment_prefix_ub_724  1
    load_0_19_3  free_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_4  arc_capacity_663  -20
    arc_0_19_4  connected_order_arc_664  -13
    arc_0_19_4  in_degree_726  1
    arc_0_19_4  out_degree_768  1
    arc_0_19_4  original_T_including_depot_unload_783  2.6602972191926557e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_4  arc_capacity_663  1
    load_0_19_4  segment_load_conservation_729  -1
    load_0_19_4  segment_prefix_lb_730  1
    load_0_19_4  segment_prefix_ub_731  1
    load_0_19_4  free_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_13  arc_capacity_665  -20
    arc_0_19_13  connected_order_arc_666  -13
    arc_0_19_13  in_degree_733  1
    arc_0_19_13  out_degree_768  1
    arc_0_19_13  original_T_including_depot_unload_783  1.8319650761318992e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_13  arc_capacity_665  1
    load_0_19_13  free_load_conservation_737  -1
    load_0_19_13  free_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_14  arc_capacity_667  -20
    arc_0_19_14  connected_order_arc_668  -13
    arc_0_19_14  in_degree_739  1
    arc_0_19_14  out_degree_768  1
    arc_0_19_14  original_T_including_depot_unload_783  1.9170200697382236e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_14  arc_capacity_667  1
    load_0_19_14  free_load_conservation_743  -1
    load_0_19_14  free_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_15  arc_capacity_669  -20
    arc_0_19_15  connected_order_arc_670  -13
    arc_0_19_15  in_degree_745  1
    arc_0_19_15  out_degree_768  1
    arc_0_19_15  original_T_including_depot_unload_783  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_15  arc_capacity_669  1
    load_0_19_15  free_load_conservation_749  -1
    load_0_19_15  free_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_16  arc_capacity_671  -20
    arc_0_19_16  connected_order_arc_672  -13
    arc_0_19_16  in_degree_751  1
    arc_0_19_16  out_degree_768  1
    arc_0_19_16  original_T_including_depot_unload_783  1.5183735648810946e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_16  arc_capacity_671  1
    load_0_19_16  free_load_conservation_755  -1
    load_0_19_16  free_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_17  arc_capacity_673  -20
    arc_0_19_17  connected_order_arc_674  -13
    arc_0_19_17  in_degree_757  1
    arc_0_19_17  out_degree_768  1
    arc_0_19_17  original_T_including_depot_unload_783  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_17  arc_capacity_673  1
    load_0_19_17  free_load_conservation_761  -1
    load_0_19_17  free_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_18  arc_capacity_675  -20
    arc_0_19_18  connected_order_arc_676  -13
    arc_0_19_18  in_degree_763  1
    arc_0_19_18  out_degree_768  1
    arc_0_19_18  original_T_including_depot_unload_783  1.3551088510632424e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_18  arc_capacity_675  1
    load_0_19_18  free_load_conservation_767  -1
    load_0_19_18  free_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_20  arc_capacity_677  -20
    arc_0_19_20  connected_order_arc_678  -13
    arc_0_19_20  out_degree_768  1
    arc_0_19_20  in_degree_775  1
    arc_0_19_20  original_T_including_depot_unload_783  1.3852878731513219e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_20  arc_capacity_677  1
    load_0_19_20  free_load_conservation_773  1
    load_0_19_20  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_0  arc_capacity_679  -20
    arc_0_20_0  depot_return_or_bypass_703  1
    arc_0_20_0  out_degree_774  1
    arc_0_20_0  original_T_including_depot_unload_783  1.0479182987243917e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_0  arc_capacity_679  1
    load_0_20_0  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_1  arc_capacity_680  -20
    arc_0_20_1  connected_order_arc_681  -13
    arc_0_20_1  in_degree_705  1
    arc_0_20_1  out_degree_774  1
    arc_0_20_1  original_T_including_depot_unload_783  1.2336637947519732e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_1  arc_capacity_680  1
    load_0_20_1  segment_load_conservation_708  -1
    load_0_20_1  segment_prefix_lb_709  1
    load_0_20_1  segment_prefix_ub_710  1
    load_0_20_1  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_2  arc_capacity_682  -20
    arc_0_20_2  connected_order_arc_683  -13
    arc_0_20_2  in_degree_712  1
    arc_0_20_2  out_degree_774  1
    arc_0_20_2  original_T_including_depot_unload_783  1.5230377993795889e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_2  arc_capacity_682  1
    load_0_20_2  segment_load_conservation_715  -1
    load_0_20_2  segment_prefix_lb_716  1
    load_0_20_2  segment_prefix_ub_717  1
    load_0_20_2  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_3  arc_capacity_684  -20
    arc_0_20_3  connected_order_arc_685  -13
    arc_0_20_3  in_degree_719  1
    arc_0_20_3  out_degree_774  1
    arc_0_20_3  original_T_including_depot_unload_783  1.5393972350798747e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_3  arc_capacity_684  1
    load_0_20_3  segment_load_conservation_722  -1
    load_0_20_3  segment_prefix_lb_723  1
    load_0_20_3  segment_prefix_ub_724  1
    load_0_20_3  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_4  arc_capacity_686  -20
    arc_0_20_4  connected_order_arc_687  -13
    arc_0_20_4  in_degree_726  1
    arc_0_20_4  out_degree_774  1
    arc_0_20_4  original_T_including_depot_unload_783  1.2492199513695298e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_4  arc_capacity_686  1
    load_0_20_4  segment_load_conservation_729  -1
    load_0_20_4  segment_prefix_lb_730  1
    load_0_20_4  segment_prefix_ub_731  1
    load_0_20_4  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_13  arc_capacity_688  -20
    arc_0_20_13  connected_order_arc_689  -13
    arc_0_20_13  in_degree_733  1
    arc_0_20_13  out_degree_774  1
    arc_0_20_13  original_T_including_depot_unload_783  6.2793211180612207e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_13  arc_capacity_688  1
    load_0_20_13  free_load_conservation_737  -1
    load_0_20_13  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_14  arc_capacity_690  -20
    arc_0_20_14  connected_order_arc_691  -13
    arc_0_20_14  in_degree_739  1
    arc_0_20_14  out_degree_774  1
    arc_0_20_14  original_T_including_depot_unload_783  8.0531033344008677e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_14  arc_capacity_690  1
    load_0_20_14  free_load_conservation_743  -1
    load_0_20_14  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_15  arc_capacity_692  -20
    arc_0_20_15  connected_order_arc_693  -13
    arc_0_20_15  in_degree_745  1
    arc_0_20_15  out_degree_774  1
    arc_0_20_15  original_T_including_depot_unload_783  5.2280951376932137e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_15  arc_capacity_692  1
    load_0_20_15  free_load_conservation_749  -1
    load_0_20_15  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_16  arc_capacity_694  -20
    arc_0_20_16  connected_order_arc_695  -13
    arc_0_20_16  in_degree_751  1
    arc_0_20_16  out_degree_774  1
    arc_0_20_16  original_T_including_depot_unload_783  3.6094216796124527e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_16  arc_capacity_694  1
    load_0_20_16  free_load_conservation_755  -1
    load_0_20_16  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_17  arc_capacity_696  -20
    arc_0_20_17  connected_order_arc_697  -13
    arc_0_20_17  in_degree_757  1
    arc_0_20_17  out_degree_774  1
    arc_0_20_17  original_T_including_depot_unload_783  1.7883808204567979e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_17  arc_capacity_696  1
    load_0_20_17  free_load_conservation_761  -1
    load_0_20_17  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_18  arc_capacity_698  -20
    arc_0_20_18  connected_order_arc_699  -13
    arc_0_20_18  in_degree_763  1
    arc_0_20_18  out_degree_774  1
    arc_0_20_18  original_T_including_depot_unload_783  2.8747557636937808e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_18  arc_capacity_698  1
    load_0_20_18  free_load_conservation_767  -1
    load_0_20_18  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_19  arc_capacity_700  -20
    arc_0_20_19  connected_order_arc_701  -13
    arc_0_20_19  in_degree_769  1
    arc_0_20_19  out_degree_774  1
    arc_0_20_19  original_T_including_depot_unload_783  1.3852878731513219e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_19  arc_capacity_700  1
    load_0_20_19  free_load_conservation_773  -1
    load_0_20_19  free_load_conservation_779  1
    visit_1_5  out_degree_1125  -1
    visit_1_5  in_degree_1126  -1
    visit_1_5  order_active_lb_1127  -1
    visit_1_5  order_active_ub_1128  -13
    order_1_5  connected_order_arc_800  -1
    order_1_5  connected_order_arc_802  -1
    order_1_5  connected_order_arc_804  -1
    order_1_5  connected_order_arc_806  -1
    order_1_5  connected_order_arc_808  -1
    order_1_5  connected_order_arc_810  -1
    order_1_5  connected_order_arc_812  -1
    order_1_5  connected_order_arc_814  -1
    order_1_5  connected_order_arc_816  -1
    order_1_5  connected_order_arc_818  -1
    order_1_5  connected_order_arc_820  -1
    order_1_5  connected_order_arc_822  -1
    order_1_5  connected_order_arc_825  1
    order_1_5  connected_order_arc_850  1
    order_1_5  connected_order_arc_875  1
    order_1_5  connected_order_arc_900  1
    order_1_5  connected_order_arc_925  1
    order_1_5  connected_order_arc_950  1
    order_1_5  connected_order_arc_975  1
    order_1_5  connected_order_arc_1000  1
    order_1_5  connected_order_arc_1025  1
    order_1_5  connected_order_arc_1050  1
    order_1_5  connected_order_arc_1075  1
    order_1_5  connected_order_arc_1100  1
    order_1_5  order_active_lb_1127  1
    order_1_5  order_active_ub_1128  1
    order_1_5  fixed_segment_relative_order_1208  -1
    visit_1_6  out_degree_1132  -1
    visit_1_6  in_degree_1133  -1
    visit_1_6  order_active_lb_1134  -1
    visit_1_6  order_active_ub_1135  -13
    order_1_6  connected_order_arc_800  1
    order_1_6  connected_order_arc_825  -1
    order_1_6  connected_order_arc_827  -1
    order_1_6  connected_order_arc_829  -1
    order_1_6  connected_order_arc_831  -1
    order_1_6  connected_order_arc_833  -1
    order_1_6  connected_order_arc_835  -1
    order_1_6  connected_order_arc_837  -1
    order_1_6  connected_order_arc_839  -1
    order_1_6  connected_order_arc_841  -1
    order_1_6  connected_order_arc_843  -1
    order_1_6  connected_order_arc_845  -1
    order_1_6  connected_order_arc_847  -1
    order_1_6  connected_order_arc_852  1
    order_1_6  connected_order_arc_877  1
    order_1_6  connected_order_arc_902  1
    order_1_6  connected_order_arc_927  1
    order_1_6  connected_order_arc_952  1
    order_1_6  connected_order_arc_977  1
    order_1_6  connected_order_arc_1002  1
    order_1_6  connected_order_arc_1027  1
    order_1_6  connected_order_arc_1052  1
    order_1_6  connected_order_arc_1077  1
    order_1_6  connected_order_arc_1102  1
    order_1_6  order_active_lb_1134  1
    order_1_6  order_active_ub_1135  1
    order_1_6  fixed_segment_relative_order_1208  1
    order_1_6  fixed_segment_relative_order_1209  -1
    visit_1_7  out_degree_1139  -1
    visit_1_7  in_degree_1140  -1
    visit_1_7  order_active_lb_1141  -1
    visit_1_7  order_active_ub_1142  -13
    order_1_7  connected_order_arc_802  1
    order_1_7  connected_order_arc_827  1
    order_1_7  connected_order_arc_850  -1
    order_1_7  connected_order_arc_852  -1
    order_1_7  connected_order_arc_854  -1
    order_1_7  connected_order_arc_856  -1
    order_1_7  connected_order_arc_858  -1
    order_1_7  connected_order_arc_860  -1
    order_1_7  connected_order_arc_862  -1
    order_1_7  connected_order_arc_864  -1
    order_1_7  connected_order_arc_866  -1
    order_1_7  connected_order_arc_868  -1
    order_1_7  connected_order_arc_870  -1
    order_1_7  connected_order_arc_872  -1
    order_1_7  connected_order_arc_879  1
    order_1_7  connected_order_arc_904  1
    order_1_7  connected_order_arc_929  1
    order_1_7  connected_order_arc_954  1
    order_1_7  connected_order_arc_979  1
    order_1_7  connected_order_arc_1004  1
    order_1_7  connected_order_arc_1029  1
    order_1_7  connected_order_arc_1054  1
    order_1_7  connected_order_arc_1079  1
    order_1_7  connected_order_arc_1104  1
    order_1_7  order_active_lb_1141  1
    order_1_7  order_active_ub_1142  1
    order_1_7  fixed_segment_relative_order_1209  1
    order_1_7  fixed_segment_relative_order_1210  -1
    visit_1_8  out_degree_1146  -1
    visit_1_8  in_degree_1147  -1
    visit_1_8  order_active_lb_1148  -1
    visit_1_8  order_active_ub_1149  -13
    order_1_8  connected_order_arc_804  1
    order_1_8  connected_order_arc_829  1
    order_1_8  connected_order_arc_854  1
    order_1_8  connected_order_arc_875  -1
    order_1_8  connected_order_arc_877  -1
    order_1_8  connected_order_arc_879  -1
    order_1_8  connected_order_arc_881  -1
    order_1_8  connected_order_arc_883  -1
    order_1_8  connected_order_arc_885  -1
    order_1_8  connected_order_arc_887  -1
    order_1_8  connected_order_arc_889  -1
    order_1_8  connected_order_arc_891  -1
    order_1_8  connected_order_arc_893  -1
    order_1_8  connected_order_arc_895  -1
    order_1_8  connected_order_arc_897  -1
    order_1_8  connected_order_arc_906  1
    order_1_8  connected_order_arc_931  1
    order_1_8  connected_order_arc_956  1
    order_1_8  connected_order_arc_981  1
    order_1_8  connected_order_arc_1006  1
    order_1_8  connected_order_arc_1031  1
    order_1_8  connected_order_arc_1056  1
    order_1_8  connected_order_arc_1081  1
    order_1_8  connected_order_arc_1106  1
    order_1_8  order_active_lb_1148  1
    order_1_8  order_active_ub_1149  1
    order_1_8  fixed_segment_relative_order_1210  1
    order_1_8  fixed_segment_relative_order_1211  -1
    visit_1_9  out_degree_1153  -1
    visit_1_9  in_degree_1154  -1
    visit_1_9  order_active_lb_1155  -1
    visit_1_9  order_active_ub_1156  -13
    order_1_9  connected_order_arc_806  1
    order_1_9  connected_order_arc_831  1
    order_1_9  connected_order_arc_856  1
    order_1_9  connected_order_arc_881  1
    order_1_9  connected_order_arc_900  -1
    order_1_9  connected_order_arc_902  -1
    order_1_9  connected_order_arc_904  -1
    order_1_9  connected_order_arc_906  -1
    order_1_9  connected_order_arc_908  -1
    order_1_9  connected_order_arc_910  -1
    order_1_9  connected_order_arc_912  -1
    order_1_9  connected_order_arc_914  -1
    order_1_9  connected_order_arc_916  -1
    order_1_9  connected_order_arc_918  -1
    order_1_9  connected_order_arc_920  -1
    order_1_9  connected_order_arc_922  -1
    order_1_9  connected_order_arc_933  1
    order_1_9  connected_order_arc_958  1
    order_1_9  connected_order_arc_983  1
    order_1_9  connected_order_arc_1008  1
    order_1_9  connected_order_arc_1033  1
    order_1_9  connected_order_arc_1058  1
    order_1_9  connected_order_arc_1083  1
    order_1_9  connected_order_arc_1108  1
    order_1_9  order_active_lb_1155  1
    order_1_9  order_active_ub_1156  1
    order_1_9  fixed_segment_relative_order_1211  1
    visit_1_13  out_degree_1160  -1
    visit_1_13  in_degree_1161  -1
    visit_1_13  order_active_lb_1162  -1
    visit_1_13  order_active_ub_1163  -13
    visit_1_13  service_visit_def_1164  -1
    order_1_13  connected_order_arc_808  1
    order_1_13  connected_order_arc_833  1
    order_1_13  connected_order_arc_858  1
    order_1_13  connected_order_arc_883  1
    order_1_13  connected_order_arc_908  1
    order_1_13  connected_order_arc_925  -1
    order_1_13  connected_order_arc_927  -1
    order_1_13  connected_order_arc_929  -1
    order_1_13  connected_order_arc_931  -1
    order_1_13  connected_order_arc_933  -1
    order_1_13  connected_order_arc_935  -1
    order_1_13  connected_order_arc_937  -1
    order_1_13  connected_order_arc_939  -1
    order_1_13  connected_order_arc_941  -1
    order_1_13  connected_order_arc_943  -1
    order_1_13  connected_order_arc_945  -1
    order_1_13  connected_order_arc_947  -1
    order_1_13  connected_order_arc_960  1
    order_1_13  connected_order_arc_985  1
    order_1_13  connected_order_arc_1010  1
    order_1_13  connected_order_arc_1035  1
    order_1_13  connected_order_arc_1060  1
    order_1_13  connected_order_arc_1085  1
    order_1_13  connected_order_arc_1110  1
    order_1_13  order_active_lb_1162  1
    order_1_13  order_active_ub_1163  1
    visit_1_14  out_degree_1166  -1
    visit_1_14  in_degree_1167  -1
    visit_1_14  order_active_lb_1168  -1
    visit_1_14  order_active_ub_1169  -13
    visit_1_14  service_visit_def_1170  -1
    order_1_14  connected_order_arc_810  1
    order_1_14  connected_order_arc_835  1
    order_1_14  connected_order_arc_860  1
    order_1_14  connected_order_arc_885  1
    order_1_14  connected_order_arc_910  1
    order_1_14  connected_order_arc_935  1
    order_1_14  connected_order_arc_950  -1
    order_1_14  connected_order_arc_952  -1
    order_1_14  connected_order_arc_954  -1
    order_1_14  connected_order_arc_956  -1
    order_1_14  connected_order_arc_958  -1
    order_1_14  connected_order_arc_960  -1
    order_1_14  connected_order_arc_962  -1
    order_1_14  connected_order_arc_964  -1
    order_1_14  connected_order_arc_966  -1
    order_1_14  connected_order_arc_968  -1
    order_1_14  connected_order_arc_970  -1
    order_1_14  connected_order_arc_972  -1
    order_1_14  connected_order_arc_987  1
    order_1_14  connected_order_arc_1012  1
    order_1_14  connected_order_arc_1037  1
    order_1_14  connected_order_arc_1062  1
    order_1_14  connected_order_arc_1087  1
    order_1_14  connected_order_arc_1112  1
    order_1_14  order_active_lb_1168  1
    order_1_14  order_active_ub_1169  1
    visit_1_15  out_degree_1172  -1
    visit_1_15  in_degree_1173  -1
    visit_1_15  order_active_lb_1174  -1
    visit_1_15  order_active_ub_1175  -13
    visit_1_15  service_visit_def_1176  -1
    order_1_15  connected_order_arc_812  1
    order_1_15  connected_order_arc_837  1
    order_1_15  connected_order_arc_862  1
    order_1_15  connected_order_arc_887  1
    order_1_15  connected_order_arc_912  1
    order_1_15  connected_order_arc_937  1
    order_1_15  connected_order_arc_962  1
    order_1_15  connected_order_arc_975  -1
    order_1_15  connected_order_arc_977  -1
    order_1_15  connected_order_arc_979  -1
    order_1_15  connected_order_arc_981  -1
    order_1_15  connected_order_arc_983  -1
    order_1_15  connected_order_arc_985  -1
    order_1_15  connected_order_arc_987  -1
    order_1_15  connected_order_arc_989  -1
    order_1_15  connected_order_arc_991  -1
    order_1_15  connected_order_arc_993  -1
    order_1_15  connected_order_arc_995  -1
    order_1_15  connected_order_arc_997  -1
    order_1_15  connected_order_arc_1014  1
    order_1_15  connected_order_arc_1039  1
    order_1_15  connected_order_arc_1064  1
    order_1_15  connected_order_arc_1089  1
    order_1_15  connected_order_arc_1114  1
    order_1_15  order_active_lb_1174  1
    order_1_15  order_active_ub_1175  1
    visit_1_16  out_degree_1178  -1
    visit_1_16  in_degree_1179  -1
    visit_1_16  order_active_lb_1180  -1
    visit_1_16  order_active_ub_1181  -13
    visit_1_16  service_visit_def_1182  -1
    order_1_16  connected_order_arc_814  1
    order_1_16  connected_order_arc_839  1
    order_1_16  connected_order_arc_864  1
    order_1_16  connected_order_arc_889  1
    order_1_16  connected_order_arc_914  1
    order_1_16  connected_order_arc_939  1
    order_1_16  connected_order_arc_964  1
    order_1_16  connected_order_arc_989  1
    order_1_16  connected_order_arc_1000  -1
    order_1_16  connected_order_arc_1002  -1
    order_1_16  connected_order_arc_1004  -1
    order_1_16  connected_order_arc_1006  -1
    order_1_16  connected_order_arc_1008  -1
    order_1_16  connected_order_arc_1010  -1
    order_1_16  connected_order_arc_1012  -1
    order_1_16  connected_order_arc_1014  -1
    order_1_16  connected_order_arc_1016  -1
    order_1_16  connected_order_arc_1018  -1
    order_1_16  connected_order_arc_1020  -1
    order_1_16  connected_order_arc_1022  -1
    order_1_16  connected_order_arc_1041  1
    order_1_16  connected_order_arc_1066  1
    order_1_16  connected_order_arc_1091  1
    order_1_16  connected_order_arc_1116  1
    order_1_16  order_active_lb_1180  1
    order_1_16  order_active_ub_1181  1
    visit_1_17  out_degree_1184  -1
    visit_1_17  in_degree_1185  -1
    visit_1_17  order_active_lb_1186  -1
    visit_1_17  order_active_ub_1187  -13
    visit_1_17  service_visit_def_1188  -1
    order_1_17  connected_order_arc_816  1
    order_1_17  connected_order_arc_841  1
    order_1_17  connected_order_arc_866  1
    order_1_17  connected_order_arc_891  1
    order_1_17  connected_order_arc_916  1
    order_1_17  connected_order_arc_941  1
    order_1_17  connected_order_arc_966  1
    order_1_17  connected_order_arc_991  1
    order_1_17  connected_order_arc_1016  1
    order_1_17  connected_order_arc_1025  -1
    order_1_17  connected_order_arc_1027  -1
    order_1_17  connected_order_arc_1029  -1
    order_1_17  connected_order_arc_1031  -1
    order_1_17  connected_order_arc_1033  -1
    order_1_17  connected_order_arc_1035  -1
    order_1_17  connected_order_arc_1037  -1
    order_1_17  connected_order_arc_1039  -1
    order_1_17  connected_order_arc_1041  -1
    order_1_17  connected_order_arc_1043  -1
    order_1_17  connected_order_arc_1045  -1
    order_1_17  connected_order_arc_1047  -1
    order_1_17  connected_order_arc_1068  1
    order_1_17  connected_order_arc_1093  1
    order_1_17  connected_order_arc_1118  1
    order_1_17  order_active_lb_1186  1
    order_1_17  order_active_ub_1187  1
    visit_1_18  out_degree_1190  -1
    visit_1_18  in_degree_1191  -1
    visit_1_18  order_active_lb_1192  -1
    visit_1_18  order_active_ub_1193  -13
    visit_1_18  service_visit_def_1194  -1
    order_1_18  connected_order_arc_818  1
    order_1_18  connected_order_arc_843  1
    order_1_18  connected_order_arc_868  1
    order_1_18  connected_order_arc_893  1
    order_1_18  connected_order_arc_918  1
    order_1_18  connected_order_arc_943  1
    order_1_18  connected_order_arc_968  1
    order_1_18  connected_order_arc_993  1
    order_1_18  connected_order_arc_1018  1
    order_1_18  connected_order_arc_1043  1
    order_1_18  connected_order_arc_1050  -1
    order_1_18  connected_order_arc_1052  -1
    order_1_18  connected_order_arc_1054  -1
    order_1_18  connected_order_arc_1056  -1
    order_1_18  connected_order_arc_1058  -1
    order_1_18  connected_order_arc_1060  -1
    order_1_18  connected_order_arc_1062  -1
    order_1_18  connected_order_arc_1064  -1
    order_1_18  connected_order_arc_1066  -1
    order_1_18  connected_order_arc_1068  -1
    order_1_18  connected_order_arc_1070  -1
    order_1_18  connected_order_arc_1072  -1
    order_1_18  connected_order_arc_1095  1
    order_1_18  connected_order_arc_1120  1
    order_1_18  order_active_lb_1192  1
    order_1_18  order_active_ub_1193  1
    visit_1_19  out_degree_1196  -1
    visit_1_19  in_degree_1197  -1
    visit_1_19  order_active_lb_1198  -1
    visit_1_19  order_active_ub_1199  -13
    visit_1_19  service_visit_def_1200  -1
    order_1_19  connected_order_arc_820  1
    order_1_19  connected_order_arc_845  1
    order_1_19  connected_order_arc_870  1
    order_1_19  connected_order_arc_895  1
    order_1_19  connected_order_arc_920  1
    order_1_19  connected_order_arc_945  1
    order_1_19  connected_order_arc_970  1
    order_1_19  connected_order_arc_995  1
    order_1_19  connected_order_arc_1020  1
    order_1_19  connected_order_arc_1045  1
    order_1_19  connected_order_arc_1070  1
    order_1_19  connected_order_arc_1075  -1
    order_1_19  connected_order_arc_1077  -1
    order_1_19  connected_order_arc_1079  -1
    order_1_19  connected_order_arc_1081  -1
    order_1_19  connected_order_arc_1083  -1
    order_1_19  connected_order_arc_1085  -1
    order_1_19  connected_order_arc_1087  -1
    order_1_19  connected_order_arc_1089  -1
    order_1_19  connected_order_arc_1091  -1
    order_1_19  connected_order_arc_1093  -1
    order_1_19  connected_order_arc_1095  -1
    order_1_19  connected_order_arc_1097  -1
    order_1_19  connected_order_arc_1122  1
    order_1_19  order_active_lb_1198  1
    order_1_19  order_active_ub_1199  1
    visit_1_20  out_degree_1202  -1
    visit_1_20  in_degree_1203  -1
    visit_1_20  order_active_lb_1204  -1
    visit_1_20  order_active_ub_1205  -13
    visit_1_20  service_visit_def_1206  -1
    order_1_20  connected_order_arc_822  1
    order_1_20  connected_order_arc_847  1
    order_1_20  connected_order_arc_872  1
    order_1_20  connected_order_arc_897  1
    order_1_20  connected_order_arc_922  1
    order_1_20  connected_order_arc_947  1
    order_1_20  connected_order_arc_972  1
    order_1_20  connected_order_arc_997  1
    order_1_20  connected_order_arc_1022  1
    order_1_20  connected_order_arc_1047  1
    order_1_20  connected_order_arc_1072  1
    order_1_20  connected_order_arc_1097  1
    order_1_20  connected_order_arc_1100  -1
    order_1_20  connected_order_arc_1102  -1
    order_1_20  connected_order_arc_1104  -1
    order_1_20  connected_order_arc_1106  -1
    order_1_20  connected_order_arc_1108  -1
    order_1_20  connected_order_arc_1110  -1
    order_1_20  connected_order_arc_1112  -1
    order_1_20  connected_order_arc_1114  -1
    order_1_20  connected_order_arc_1116  -1
    order_1_20  connected_order_arc_1118  -1
    order_1_20  connected_order_arc_1120  -1
    order_1_20  connected_order_arc_1122  -1
    order_1_20  order_active_lb_1204  1
    order_1_20  order_active_ub_1205  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_0  arc_capacity_784  -25
    arc_1_0_0  depot_departure_or_bypass_1123  1
    arc_1_0_0  depot_return_or_bypass_1124  1
    MARKER    'MARKER'                 'INTEND'
    load_1_0_0  arc_capacity_784  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_5  arc_capacity_785  -25
    arc_1_0_5  depot_departure_or_bypass_1123  1
    arc_1_0_5  in_degree_1126  1
    arc_1_0_5  original_T_including_depot_unload_1212  8.7918533905669346e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_5  arc_capacity_785  1
    load_1_0_5  segment_load_conservation_1129  -1
    load_1_0_5  segment_prefix_lb_1130  1
    load_1_0_5  segment_prefix_ub_1131  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_6  arc_capacity_786  -25
    arc_1_0_6  depot_departure_or_bypass_1123  1
    arc_1_0_6  in_degree_1133  1
    arc_1_0_6  original_T_including_depot_unload_1212  1.2801771486108735e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_6  arc_capacity_786  1
    load_1_0_6  segment_load_conservation_1136  -1
    load_1_0_6  segment_prefix_lb_1137  1
    load_1_0_6  segment_prefix_ub_1138  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_7  arc_capacity_787  -25
    arc_1_0_7  depot_departure_or_bypass_1123  1
    arc_1_0_7  in_degree_1140  1
    arc_1_0_7  original_T_including_depot_unload_1212  9.8831482002326163e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_7  arc_capacity_787  1
    load_1_0_7  segment_load_conservation_1143  -1
    load_1_0_7  segment_prefix_lb_1144  1
    load_1_0_7  segment_prefix_ub_1145  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_8  arc_capacity_788  -25
    arc_1_0_8  depot_departure_or_bypass_1123  1
    arc_1_0_8  in_degree_1147  1
    arc_1_0_8  original_T_including_depot_unload_1212  7.8195480223834068e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_8  arc_capacity_788  1
    load_1_0_8  segment_load_conservation_1150  -1
    load_1_0_8  segment_prefix_lb_1151  1
    load_1_0_8  segment_prefix_ub_1152  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_9  arc_capacity_789  -25
    arc_1_0_9  depot_departure_or_bypass_1123  1
    arc_1_0_9  in_degree_1154  1
    arc_1_0_9  original_T_including_depot_unload_1212  887.312716328479
    MARKER    'MARKER'                 'INTEND'
    load_1_0_9  arc_capacity_789  1
    load_1_0_9  segment_load_conservation_1157  -1
    load_1_0_9  segment_prefix_lb_1158  1
    load_1_0_9  segment_prefix_ub_1159  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_13  arc_capacity_790  -25
    arc_1_0_13  depot_departure_or_bypass_1123  1
    arc_1_0_13  in_degree_1161  1
    arc_1_0_13  original_T_including_depot_unload_1212  1.2751323166566442e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_13  arc_capacity_790  1
    load_1_0_13  free_load_conservation_1165  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_14  arc_capacity_791  -25
    arc_1_0_14  depot_departure_or_bypass_1123  1
    arc_1_0_14  in_degree_1167  1
    arc_1_0_14  original_T_including_depot_unload_1212  1.3076700111397606e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_14  arc_capacity_791  1
    load_1_0_14  free_load_conservation_1171  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_15  arc_capacity_792  -25
    arc_1_0_15  depot_departure_or_bypass_1123  1
    arc_1_0_15  in_degree_1173  1
    arc_1_0_15  original_T_including_depot_unload_1212  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_15  arc_capacity_792  1
    load_1_0_15  free_load_conservation_1177  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_16  arc_capacity_793  -25
    arc_1_0_16  depot_departure_or_bypass_1123  1
    arc_1_0_16  in_degree_1179  1
    arc_1_0_16  original_T_including_depot_unload_1212  1.0088905112952611e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_16  arc_capacity_793  1
    load_1_0_16  free_load_conservation_1183  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_17  arc_capacity_794  -25
    arc_1_0_17  depot_departure_or_bypass_1123  1
    arc_1_0_17  in_degree_1185  1
    arc_1_0_17  original_T_including_depot_unload_1212  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_17  arc_capacity_794  1
    load_1_0_17  free_load_conservation_1189  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_18  arc_capacity_795  -25
    arc_1_0_18  depot_departure_or_bypass_1123  1
    arc_1_0_18  in_degree_1191  1
    arc_1_0_18  original_T_including_depot_unload_1212  8.7749189782983967e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_18  arc_capacity_795  1
    load_1_0_18  free_load_conservation_1195  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_19  arc_capacity_796  -25
    arc_1_0_19  depot_departure_or_bypass_1123  1
    arc_1_0_19  in_degree_1197  1
    arc_1_0_19  original_T_including_depot_unload_1212  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_19  arc_capacity_796  1
    load_1_0_19  free_load_conservation_1201  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_20  arc_capacity_797  -25
    arc_1_0_20  depot_departure_or_bypass_1123  1
    arc_1_0_20  in_degree_1203  1
    arc_1_0_20  original_T_including_depot_unload_1212  1.0479182987243917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_20  arc_capacity_797  1
    load_1_0_20  free_load_conservation_1207  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_0  arc_capacity_798  -25
    arc_1_5_0  depot_return_or_bypass_1124  1
    arc_1_5_0  out_degree_1125  1
    arc_1_5_0  original_T_including_depot_unload_1212  8.7918533905669346e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_5_0  arc_capacity_798  1
    load_1_5_0  segment_load_conservation_1129  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_6  arc_capacity_799  -25
    arc_1_5_6  connected_order_arc_800  -14
    arc_1_5_6  out_degree_1125  1
    arc_1_5_6  in_degree_1133  1
    arc_1_5_6  original_T_including_depot_unload_1212  1.3197014959146461e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_6  arc_capacity_799  1
    load_1_5_6  segment_load_conservation_1129  1
    load_1_5_6  segment_load_conservation_1136  -1
    load_1_5_6  segment_prefix_lb_1137  1
    load_1_5_6  segment_prefix_ub_1138  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_7  arc_capacity_801  -25
    arc_1_5_7  connected_order_arc_802  -14
    arc_1_5_7  out_degree_1125  1
    arc_1_5_7  in_degree_1140  1
    arc_1_5_7  original_T_including_depot_unload_1212  1.1360772387139011e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_7  arc_capacity_801  1
    load_1_5_7  segment_load_conservation_1129  1
    load_1_5_7  segment_load_conservation_1143  -1
    load_1_5_7  segment_prefix_lb_1144  1
    load_1_5_7  segment_prefix_ub_1145  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_8  arc_capacity_803  -25
    arc_1_5_8  connected_order_arc_804  -14
    arc_1_5_8  out_degree_1125  1
    arc_1_5_8  in_degree_1147  1
    arc_1_5_8  original_T_including_depot_unload_1212  1.0062397105603651e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_8  arc_capacity_803  1
    load_1_5_8  segment_load_conservation_1129  1
    load_1_5_8  segment_load_conservation_1150  -1
    load_1_5_8  segment_prefix_lb_1151  1
    load_1_5_8  segment_prefix_ub_1152  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_9  arc_capacity_805  -25
    arc_1_5_9  connected_order_arc_806  -14
    arc_1_5_9  out_degree_1125  1
    arc_1_5_9  in_degree_1154  1
    arc_1_5_9  original_T_including_depot_unload_1212  1.0967168052209140e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_9  arc_capacity_805  1
    load_1_5_9  segment_load_conservation_1129  1
    load_1_5_9  segment_load_conservation_1157  -1
    load_1_5_9  segment_prefix_lb_1158  1
    load_1_5_9  segment_prefix_ub_1159  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_13  arc_capacity_807  -25
    arc_1_5_13  connected_order_arc_808  -14
    arc_1_5_13  out_degree_1125  1
    arc_1_5_13  in_degree_1161  1
    arc_1_5_13  original_T_including_depot_unload_1212  8.2035300709080423e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_5_13  arc_capacity_807  1
    load_1_5_13  segment_load_conservation_1129  1
    load_1_5_13  free_load_conservation_1165  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_14  arc_capacity_809  -25
    arc_1_5_14  connected_order_arc_810  -14
    arc_1_5_14  out_degree_1125  1
    arc_1_5_14  in_degree_1167  1
    arc_1_5_14  original_T_including_depot_unload_1212  9.7692852841087415e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_5_14  arc_capacity_809  1
    load_1_5_14  segment_load_conservation_1129  1
    load_1_5_14  free_load_conservation_1171  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_15  arc_capacity_811  -25
    arc_1_5_15  connected_order_arc_812  -14
    arc_1_5_15  out_degree_1125  1
    arc_1_5_15  in_degree_1173  1
    arc_1_5_15  original_T_including_depot_unload_1212  3.6824909986567474e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_5_15  arc_capacity_811  1
    load_1_5_15  segment_load_conservation_1129  1
    load_1_5_15  free_load_conservation_1177  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_16  arc_capacity_813  -25
    arc_1_5_16  connected_order_arc_814  -14
    arc_1_5_16  out_degree_1125  1
    arc_1_5_16  in_degree_1179  1
    arc_1_5_16  original_T_including_depot_unload_1212  5.1107432522690152e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_5_16  arc_capacity_813  1
    load_1_5_16  segment_load_conservation_1129  1
    load_1_5_16  free_load_conservation_1183  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_17  arc_capacity_815  -25
    arc_1_5_17  connected_order_arc_816  -14
    arc_1_5_17  out_degree_1125  1
    arc_1_5_17  in_degree_1185  1
    arc_1_5_17  original_T_including_depot_unload_1212  1.5502221880497036e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_17  arc_capacity_815  1
    load_1_5_17  segment_load_conservation_1129  1
    load_1_5_17  free_load_conservation_1189  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_18  arc_capacity_817  -25
    arc_1_5_18  connected_order_arc_818  -14
    arc_1_5_18  out_degree_1125  1
    arc_1_5_18  in_degree_1191  1
    arc_1_5_18  original_T_including_depot_unload_1212  3.6821827312741834e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_5_18  arc_capacity_817  1
    load_1_5_18  segment_load_conservation_1129  1
    load_1_5_18  free_load_conservation_1195  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_19  arc_capacity_819  -25
    arc_1_5_19  connected_order_arc_820  -14
    arc_1_5_19  out_degree_1125  1
    arc_1_5_19  in_degree_1197  1
    arc_1_5_19  original_T_including_depot_unload_1212  1.1479472058029019e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_19  arc_capacity_819  1
    load_1_5_19  segment_load_conservation_1129  1
    load_1_5_19  free_load_conservation_1201  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_20  arc_capacity_821  -25
    arc_1_5_20  connected_order_arc_822  -14
    arc_1_5_20  out_degree_1125  1
    arc_1_5_20  in_degree_1203  1
    arc_1_5_20  original_T_including_depot_unload_1212  2.4155873404211835e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_5_20  arc_capacity_821  1
    load_1_5_20  segment_load_conservation_1129  1
    load_1_5_20  free_load_conservation_1207  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_0  arc_capacity_823  -25
    arc_1_6_0  depot_return_or_bypass_1124  1
    arc_1_6_0  out_degree_1132  1
    arc_1_6_0  original_T_including_depot_unload_1212  1.2801771486108735e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_0  arc_capacity_823  1
    load_1_6_0  segment_load_conservation_1136  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_5  arc_capacity_824  -25
    arc_1_6_5  connected_order_arc_825  -14
    arc_1_6_5  in_degree_1126  1
    arc_1_6_5  out_degree_1132  1
    arc_1_6_5  original_T_including_depot_unload_1212  1.3197014959146461e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_5  arc_capacity_824  1
    load_1_6_5  segment_load_conservation_1129  -1
    load_1_6_5  segment_prefix_lb_1130  1
    load_1_6_5  segment_prefix_ub_1131  1
    load_1_6_5  segment_load_conservation_1136  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_7  arc_capacity_826  -25
    arc_1_6_7  connected_order_arc_827  -14
    arc_1_6_7  out_degree_1132  1
    arc_1_6_7  in_degree_1140  1
    arc_1_6_7  original_T_including_depot_unload_1212  2.9450332489480053e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_7  arc_capacity_826  1
    load_1_6_7  segment_load_conservation_1136  1
    load_1_6_7  segment_load_conservation_1143  -1
    load_1_6_7  segment_prefix_lb_1144  1
    load_1_6_7  segment_prefix_ub_1145  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_8  arc_capacity_828  -25
    arc_1_6_8  connected_order_arc_829  -14
    arc_1_6_8  out_degree_1132  1
    arc_1_6_8  in_degree_1147  1
    arc_1_6_8  original_T_including_depot_unload_1212  4.9903342483612323e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_8  arc_capacity_828  1
    load_1_6_8  segment_load_conservation_1136  1
    load_1_6_8  segment_load_conservation_1150  -1
    load_1_6_8  segment_prefix_lb_1151  1
    load_1_6_8  segment_prefix_ub_1152  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_9  arc_capacity_830  -25
    arc_1_6_9  connected_order_arc_831  -14
    arc_1_6_9  out_degree_1132  1
    arc_1_6_9  in_degree_1154  1
    arc_1_6_9  original_T_including_depot_unload_1212  4.0010881633455318e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_9  arc_capacity_830  1
    load_1_6_9  segment_load_conservation_1136  1
    load_1_6_9  segment_load_conservation_1157  -1
    load_1_6_9  segment_prefix_lb_1158  1
    load_1_6_9  segment_prefix_ub_1159  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_13  arc_capacity_832  -25
    arc_1_6_13  connected_order_arc_833  -14
    arc_1_6_13  out_degree_1132  1
    arc_1_6_13  in_degree_1161  1
    arc_1_6_13  original_T_including_depot_unload_1212  726.017738185843
    MARKER    'MARKER'                 'INTEND'
    load_1_6_13  arc_capacity_832  1
    load_1_6_13  segment_load_conservation_1136  1
    load_1_6_13  free_load_conservation_1165  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_14  arc_capacity_834  -25
    arc_1_6_14  connected_order_arc_835  -14
    arc_1_6_14  out_degree_1132  1
    arc_1_6_14  in_degree_1167  1
    arc_1_6_14  original_T_including_depot_unload_1212  5.4630148713373910e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_14  arc_capacity_834  1
    load_1_6_14  segment_load_conservation_1136  1
    load_1_6_14  free_load_conservation_1171  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_15  arc_capacity_836  -25
    arc_1_6_15  connected_order_arc_837  -14
    arc_1_6_15  out_degree_1132  1
    arc_1_6_15  in_degree_1173  1
    arc_1_6_15  original_T_including_depot_unload_1212  1.6876944916846833e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_15  arc_capacity_836  1
    load_1_6_15  segment_load_conservation_1136  1
    load_1_6_15  free_load_conservation_1177  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_16  arc_capacity_838  -25
    arc_1_6_16  connected_order_arc_839  -14
    arc_1_6_16  out_degree_1132  1
    arc_1_6_16  in_degree_1179  1
    arc_1_6_16  original_T_including_depot_unload_1212  8.6289703303586691e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_16  arc_capacity_838  1
    load_1_6_16  segment_load_conservation_1136  1
    load_1_6_16  free_load_conservation_1183  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_17  arc_capacity_840  -25
    arc_1_6_17  connected_order_arc_841  -14
    arc_1_6_17  out_degree_1132  1
    arc_1_6_17  in_degree_1185  1
    arc_1_6_17  original_T_including_depot_unload_1212  2.5950001064050621e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_17  arc_capacity_840  1
    load_1_6_17  segment_load_conservation_1136  1
    load_1_6_17  free_load_conservation_1189  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_18  arc_capacity_842  -25
    arc_1_6_18  connected_order_arc_843  -14
    arc_1_6_18  out_degree_1132  1
    arc_1_6_18  in_degree_1191  1
    arc_1_6_18  original_T_including_depot_unload_1212  9.5892865701726816e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_18  arc_capacity_842  1
    load_1_6_18  segment_load_conservation_1136  1
    load_1_6_18  free_load_conservation_1195  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_19  arc_capacity_844  -25
    arc_1_6_19  connected_order_arc_845  -14
    arc_1_6_19  out_degree_1132  1
    arc_1_6_19  in_degree_1197  1
    arc_1_6_19  original_T_including_depot_unload_1212  1.9878052050440085e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_19  arc_capacity_844  1
    load_1_6_19  segment_load_conservation_1136  1
    load_1_6_19  free_load_conservation_1201  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_20  arc_capacity_846  -25
    arc_1_6_20  connected_order_arc_847  -14
    arc_1_6_20  out_degree_1132  1
    arc_1_6_20  in_degree_1203  1
    arc_1_6_20  original_T_including_depot_unload_1212  1.2213551686272770e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_20  arc_capacity_846  1
    load_1_6_20  segment_load_conservation_1136  1
    load_1_6_20  free_load_conservation_1207  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_0  arc_capacity_848  -25
    arc_1_7_0  depot_return_or_bypass_1124  1
    arc_1_7_0  out_degree_1139  1
    arc_1_7_0  original_T_including_depot_unload_1212  9.8831482002326163e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_0  arc_capacity_848  1
    load_1_7_0  segment_load_conservation_1143  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_5  arc_capacity_849  -25
    arc_1_7_5  connected_order_arc_850  -14
    arc_1_7_5  in_degree_1126  1
    arc_1_7_5  out_degree_1139  1
    arc_1_7_5  original_T_including_depot_unload_1212  1.1360772387139011e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_5  arc_capacity_849  1
    load_1_7_5  segment_load_conservation_1129  -1
    load_1_7_5  segment_prefix_lb_1130  1
    load_1_7_5  segment_prefix_ub_1131  1
    load_1_7_5  segment_load_conservation_1143  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_6  arc_capacity_851  -25
    arc_1_7_6  connected_order_arc_852  -14
    arc_1_7_6  in_degree_1133  1
    arc_1_7_6  out_degree_1139  1
    arc_1_7_6  original_T_including_depot_unload_1212  2.9450332489480053e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_6  arc_capacity_851  1
    load_1_7_6  segment_load_conservation_1136  -1
    load_1_7_6  segment_prefix_lb_1137  1
    load_1_7_6  segment_prefix_ub_1138  1
    load_1_7_6  segment_load_conservation_1143  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_8  arc_capacity_853  -25
    arc_1_7_8  connected_order_arc_854  -14
    arc_1_7_8  out_degree_1139  1
    arc_1_7_8  in_degree_1147  1
    arc_1_7_8  original_T_including_depot_unload_1212  2.0644059606137412e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_8  arc_capacity_853  1
    load_1_7_8  segment_load_conservation_1143  1
    load_1_7_8  segment_load_conservation_1150  -1
    load_1_7_8  segment_prefix_lb_1151  1
    load_1_7_8  segment_prefix_ub_1152  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_9  arc_capacity_855  -25
    arc_1_7_9  connected_order_arc_856  -14
    arc_1_7_9  out_degree_1139  1
    arc_1_7_9  in_degree_1154  1
    arc_1_7_9  original_T_including_depot_unload_1212  1.0652142597817847e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_9  arc_capacity_855  1
    load_1_7_9  segment_load_conservation_1143  1
    load_1_7_9  segment_load_conservation_1157  -1
    load_1_7_9  segment_prefix_lb_1158  1
    load_1_7_9  segment_prefix_ub_1159  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_13  arc_capacity_857  -25
    arc_1_7_13  connected_order_arc_858  -14
    arc_1_7_13  out_degree_1139  1
    arc_1_7_13  in_degree_1161  1
    arc_1_7_13  original_T_including_depot_unload_1212  7.3382689952363592e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_13  arc_capacity_857  1
    load_1_7_13  segment_load_conservation_1143  1
    load_1_7_13  free_load_conservation_1165  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_14  arc_capacity_859  -25
    arc_1_7_14  connected_order_arc_860  -14
    arc_1_7_14  out_degree_1139  1
    arc_1_7_14  in_degree_1167  1
    arc_1_7_14  original_T_including_depot_unload_1212  6.0870346483367848e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_14  arc_capacity_859  1
    load_1_7_14  segment_load_conservation_1143  1
    load_1_7_14  free_load_conservation_1171  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_15  arc_capacity_861  -25
    arc_1_7_15  connected_order_arc_862  -14
    arc_1_7_15  out_degree_1139  1
    arc_1_7_15  in_degree_1173  1
    arc_1_7_15  original_T_including_depot_unload_1212  1.5013589792907314e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_15  arc_capacity_861  1
    load_1_7_15  segment_load_conservation_1143  1
    load_1_7_15  free_load_conservation_1177  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_16  arc_capacity_863  -25
    arc_1_7_16  connected_order_arc_864  -14
    arc_1_7_16  out_degree_1139  1
    arc_1_7_16  in_degree_1179  1
    arc_1_7_16  original_T_including_depot_unload_1212  7.5249256121297628e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_16  arc_capacity_863  1
    load_1_7_16  segment_load_conservation_1143  1
    load_1_7_16  free_load_conservation_1183  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_17  arc_capacity_865  -25
    arc_1_7_17  connected_order_arc_866  -14
    arc_1_7_17  out_degree_1139  1
    arc_1_7_17  in_degree_1185  1
    arc_1_7_17  original_T_including_depot_unload_1212  2.3179341182261583e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_17  arc_capacity_865  1
    load_1_7_17  segment_load_conservation_1143  1
    load_1_7_17  free_load_conservation_1189  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_18  arc_capacity_867  -25
    arc_1_7_18  connected_order_arc_868  -14
    arc_1_7_18  out_degree_1139  1
    arc_1_7_18  in_degree_1191  1
    arc_1_7_18  original_T_including_depot_unload_1212  8.0195161088934185e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_18  arc_capacity_867  1
    load_1_7_18  segment_load_conservation_1143  1
    load_1_7_18  free_load_conservation_1195  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_19  arc_capacity_869  -25
    arc_1_7_19  connected_order_arc_870  -14
    arc_1_7_19  out_degree_1139  1
    arc_1_7_19  in_degree_1197  1
    arc_1_7_19  original_T_including_depot_unload_1212  1.7017879962005411e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_19  arc_capacity_869  1
    load_1_7_19  segment_load_conservation_1143  1
    load_1_7_19  free_load_conservation_1201  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_20  arc_capacity_871  -25
    arc_1_7_20  connected_order_arc_872  -14
    arc_1_7_20  out_degree_1139  1
    arc_1_7_20  in_degree_1203  1
    arc_1_7_20  original_T_including_depot_unload_1212  1.0854925215530507e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_20  arc_capacity_871  1
    load_1_7_20  segment_load_conservation_1143  1
    load_1_7_20  free_load_conservation_1207  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_0  arc_capacity_873  -25
    arc_1_8_0  depot_return_or_bypass_1124  1
    arc_1_8_0  out_degree_1146  1
    arc_1_8_0  original_T_including_depot_unload_1212  7.8195480223834068e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_0  arc_capacity_873  1
    load_1_8_0  segment_load_conservation_1150  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_5  arc_capacity_874  -25
    arc_1_8_5  connected_order_arc_875  -14
    arc_1_8_5  in_degree_1126  1
    arc_1_8_5  out_degree_1146  1
    arc_1_8_5  original_T_including_depot_unload_1212  1.0062397105603651e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_5  arc_capacity_874  1
    load_1_8_5  segment_load_conservation_1129  -1
    load_1_8_5  segment_prefix_lb_1130  1
    load_1_8_5  segment_prefix_ub_1131  1
    load_1_8_5  segment_load_conservation_1150  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_6  arc_capacity_876  -25
    arc_1_8_6  connected_order_arc_877  -14
    arc_1_8_6  in_degree_1133  1
    arc_1_8_6  out_degree_1146  1
    arc_1_8_6  original_T_including_depot_unload_1212  4.9903342483612323e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_6  arc_capacity_876  1
    load_1_8_6  segment_load_conservation_1136  -1
    load_1_8_6  segment_prefix_lb_1137  1
    load_1_8_6  segment_prefix_ub_1138  1
    load_1_8_6  segment_load_conservation_1150  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_7  arc_capacity_878  -25
    arc_1_8_7  connected_order_arc_879  -14
    arc_1_8_7  in_degree_1140  1
    arc_1_8_7  out_degree_1146  1
    arc_1_8_7  original_T_including_depot_unload_1212  2.0644059606137412e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_7  arc_capacity_878  1
    load_1_8_7  segment_load_conservation_1143  -1
    load_1_8_7  segment_prefix_lb_1144  1
    load_1_8_7  segment_prefix_ub_1145  1
    load_1_8_7  segment_load_conservation_1150  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_9  arc_capacity_880  -25
    arc_1_8_9  connected_order_arc_881  -14
    arc_1_8_9  out_degree_1146  1
    arc_1_8_9  in_degree_1154  1
    arc_1_8_9  original_T_including_depot_unload_1212  1.1119949880978965e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_9  arc_capacity_880  1
    load_1_8_9  segment_load_conservation_1150  1
    load_1_8_9  segment_load_conservation_1157  -1
    load_1_8_9  segment_prefix_lb_1158  1
    load_1_8_9  segment_prefix_ub_1159  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_13  arc_capacity_882  -25
    arc_1_8_13  connected_order_arc_883  -14
    arc_1_8_13  out_degree_1146  1
    arc_1_8_13  in_degree_1161  1
    arc_1_8_13  original_T_including_depot_unload_1212  7.7248128224166851e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_13  arc_capacity_882  1
    load_1_8_13  segment_load_conservation_1150  1
    load_1_8_13  free_load_conservation_1165  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_14  arc_capacity_884  -25
    arc_1_8_14  connected_order_arc_885  -14
    arc_1_8_14  out_degree_1146  1
    arc_1_8_14  in_degree_1167  1
    arc_1_8_14  original_T_including_depot_unload_1212  6.9492720147205364e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_14  arc_capacity_884  1
    load_1_8_14  segment_load_conservation_1150  1
    load_1_8_14  free_load_conservation_1171  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_15  arc_capacity_886  -25
    arc_1_8_15  connected_order_arc_887  -14
    arc_1_8_15  out_degree_1146  1
    arc_1_8_15  in_degree_1173  1
    arc_1_8_15  original_T_including_depot_unload_1212  1.3626829404511475e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_15  arc_capacity_886  1
    load_1_8_15  segment_load_conservation_1150  1
    load_1_8_15  free_load_conservation_1177  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_16  arc_capacity_888  -25
    arc_1_8_16  connected_order_arc_889  -14
    arc_1_8_16  out_degree_1146  1
    arc_1_8_16  in_degree_1179  1
    arc_1_8_16  original_T_including_depot_unload_1212  7.0141209816069022e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_16  arc_capacity_888  1
    load_1_8_16  segment_load_conservation_1150  1
    load_1_8_16  free_load_conservation_1183  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_17  arc_capacity_890  -25
    arc_1_8_17  connected_order_arc_891  -14
    arc_1_8_17  out_degree_1146  1
    arc_1_8_17  in_degree_1185  1
    arc_1_8_17  original_T_including_depot_unload_1212  2115.53677476792
    MARKER    'MARKER'                 'INTEND'
    load_1_8_17  arc_capacity_890  1
    load_1_8_17  segment_load_conservation_1150  1
    load_1_8_17  free_load_conservation_1189  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_18  arc_capacity_892  -25
    arc_1_8_18  connected_order_arc_893  -14
    arc_1_8_18  out_degree_1146  1
    arc_1_8_18  in_degree_1191  1
    arc_1_8_18  original_T_including_depot_unload_1212  7.0804311489116617e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_18  arc_capacity_892  1
    load_1_8_18  segment_load_conservation_1150  1
    load_1_8_18  free_load_conservation_1195  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_19  arc_capacity_894  -25
    arc_1_8_19  connected_order_arc_895  -14
    arc_1_8_19  out_degree_1146  1
    arc_1_8_19  in_degree_1197  1
    arc_1_8_19  original_T_including_depot_unload_1212  1.4961553163922974e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_19  arc_capacity_894  1
    load_1_8_19  segment_load_conservation_1150  1
    load_1_8_19  free_load_conservation_1201  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_20  arc_capacity_896  -25
    arc_1_8_20  connected_order_arc_897  -14
    arc_1_8_20  out_degree_1146  1
    arc_1_8_20  in_degree_1203  1
    arc_1_8_20  original_T_including_depot_unload_1212  9.9524628735690555e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_20  arc_capacity_896  1
    load_1_8_20  segment_load_conservation_1150  1
    load_1_8_20  free_load_conservation_1207  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_0  arc_capacity_898  -25
    arc_1_9_0  depot_return_or_bypass_1124  1
    arc_1_9_0  out_degree_1153  1
    arc_1_9_0  original_T_including_depot_unload_1212  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_0  arc_capacity_898  1
    load_1_9_0  segment_load_conservation_1157  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_5  arc_capacity_899  -25
    arc_1_9_5  connected_order_arc_900  -14
    arc_1_9_5  in_degree_1126  1
    arc_1_9_5  out_degree_1153  1
    arc_1_9_5  original_T_including_depot_unload_1212  1.0412376551742484e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_5  arc_capacity_899  1
    load_1_9_5  segment_load_conservation_1129  -1
    load_1_9_5  segment_prefix_lb_1130  1
    load_1_9_5  segment_prefix_ub_1131  1
    load_1_9_5  segment_load_conservation_1157  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_6  arc_capacity_901  -25
    arc_1_9_6  connected_order_arc_902  -14
    arc_1_9_6  in_degree_1133  1
    arc_1_9_6  out_degree_1153  1
    arc_1_9_6  original_T_including_depot_unload_1212  7.3287495843240220e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_6  arc_capacity_901  1
    load_1_9_6  segment_load_conservation_1136  -1
    load_1_9_6  segment_prefix_lb_1137  1
    load_1_9_6  segment_prefix_ub_1138  1
    load_1_9_6  segment_load_conservation_1157  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_7  arc_capacity_903  -25
    arc_1_9_7  connected_order_arc_904  -14
    arc_1_9_7  in_degree_1140  1
    arc_1_9_7  out_degree_1153  1
    arc_1_9_7  original_T_including_depot_unload_1212  4.4073908743473044e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_7  arc_capacity_903  1
    load_1_9_7  segment_load_conservation_1143  -1
    load_1_9_7  segment_prefix_lb_1144  1
    load_1_9_7  segment_prefix_ub_1145  1
    load_1_9_7  segment_load_conservation_1157  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_8  arc_capacity_905  -25
    arc_1_9_8  connected_order_arc_906  -14
    arc_1_9_8  in_degree_1147  1
    arc_1_9_8  out_degree_1153  1
    arc_1_9_8  original_T_including_depot_unload_1212  2.5572087458878266e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_8  arc_capacity_905  1
    load_1_9_8  segment_load_conservation_1150  -1
    load_1_9_8  segment_prefix_lb_1151  1
    load_1_9_8  segment_prefix_ub_1152  1
    load_1_9_8  segment_load_conservation_1157  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_13  arc_capacity_907  -25
    arc_1_9_13  connected_order_arc_908  -14
    arc_1_9_13  out_degree_1153  1
    arc_1_9_13  in_degree_1161  1
    arc_1_9_13  original_T_including_depot_unload_1212  990.144803963742
    MARKER    'MARKER'                 'INTEND'
    load_1_9_13  arc_capacity_907  1
    load_1_9_13  segment_load_conservation_1157  1
    load_1_9_13  free_load_conservation_1165  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_14  arc_capacity_909  -25
    arc_1_9_14  connected_order_arc_910  -14
    arc_1_9_14  out_degree_1153  1
    arc_1_9_14  in_degree_1167  1
    arc_1_9_14  original_T_including_depot_unload_1212  9.3685967675232439e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_14  arc_capacity_909  1
    load_1_9_14  segment_load_conservation_1157  1
    load_1_9_14  free_load_conservation_1171  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_15  arc_capacity_911  -25
    arc_1_9_15  connected_order_arc_912  -14
    arc_1_9_15  out_degree_1153  1
    arc_1_9_15  in_degree_1173  1
    arc_1_9_15  original_T_including_depot_unload_1212  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_15  arc_capacity_911  1
    load_1_9_15  segment_load_conservation_1157  1
    load_1_9_15  free_load_conservation_1177  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_16  arc_capacity_913  -25
    arc_1_9_16  connected_order_arc_914  -14
    arc_1_9_16  out_degree_1153  1
    arc_1_9_16  in_degree_1179  1
    arc_1_9_16  original_T_including_depot_unload_1212  8.5502565124349769e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_16  arc_capacity_913  1
    load_1_9_16  segment_load_conservation_1157  1
    load_1_9_16  free_load_conservation_1183  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_17  arc_capacity_915  -25
    arc_1_9_17  connected_order_arc_916  -14
    arc_1_9_17  out_degree_1153  1
    arc_1_9_17  in_degree_1185  1
    arc_1_9_17  original_T_including_depot_unload_1212  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_17  arc_capacity_915  1
    load_1_9_17  segment_load_conservation_1157  1
    load_1_9_17  free_load_conservation_1189  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_18  arc_capacity_917  -25
    arc_1_9_18  connected_order_arc_918  -14
    arc_1_9_18  out_degree_1153  1
    arc_1_9_18  in_degree_1191  1
    arc_1_9_18  original_T_including_depot_unload_1212  8.1417957710766450e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_18  arc_capacity_917  1
    load_1_9_18  segment_load_conservation_1157  1
    load_1_9_18  free_load_conservation_1195  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_19  arc_capacity_919  -25
    arc_1_9_19  connected_order_arc_920  -14
    arc_1_9_19  out_degree_1153  1
    arc_1_9_19  in_degree_1197  1
    arc_1_9_19  original_T_including_depot_unload_1212  1.3127274783157229e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_19  arc_capacity_919  1
    load_1_9_19  segment_load_conservation_1157  1
    load_1_9_19  free_load_conservation_1201  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_20  arc_capacity_921  -25
    arc_1_9_20  connected_order_arc_922  -14
    arc_1_9_20  out_degree_1153  1
    arc_1_9_20  in_degree_1203  1
    arc_1_9_20  original_T_including_depot_unload_1212  1.0880068546845516e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_20  arc_capacity_921  1
    load_1_9_20  segment_load_conservation_1157  1
    load_1_9_20  free_load_conservation_1207  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_0  arc_capacity_923  -25
    arc_1_13_0  depot_return_or_bypass_1124  1
    arc_1_13_0  out_degree_1160  1
    arc_1_13_0  original_T_including_depot_unload_1212  1.2751323166566442e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_0  arc_capacity_923  1
    load_1_13_0  free_load_conservation_1165  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_5  arc_capacity_924  -25
    arc_1_13_5  connected_order_arc_925  -14
    arc_1_13_5  in_degree_1126  1
    arc_1_13_5  out_degree_1160  1
    arc_1_13_5  original_T_including_depot_unload_1212  8.2035300709080423e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_5  arc_capacity_924  1
    load_1_13_5  segment_load_conservation_1129  -1
    load_1_13_5  segment_prefix_lb_1130  1
    load_1_13_5  segment_prefix_ub_1131  1
    load_1_13_5  free_load_conservation_1165  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_6  arc_capacity_926  -25
    arc_1_13_6  connected_order_arc_927  -14
    arc_1_13_6  in_degree_1133  1
    arc_1_13_6  out_degree_1160  1
    arc_1_13_6  original_T_including_depot_unload_1212  726.017738185843
    MARKER    'MARKER'                 'INTEND'
    load_1_13_6  arc_capacity_926  1
    load_1_13_6  segment_load_conservation_1136  -1
    load_1_13_6  segment_prefix_lb_1137  1
    load_1_13_6  segment_prefix_ub_1138  1
    load_1_13_6  free_load_conservation_1165  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_7  arc_capacity_928  -25
    arc_1_13_7  connected_order_arc_929  -14
    arc_1_13_7  in_degree_1140  1
    arc_1_13_7  out_degree_1160  1
    arc_1_13_7  original_T_including_depot_unload_1212  7.3382689952363592e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_7  arc_capacity_928  1
    load_1_13_7  segment_load_conservation_1143  -1
    load_1_13_7  segment_prefix_lb_1144  1
    load_1_13_7  segment_prefix_ub_1145  1
    load_1_13_7  free_load_conservation_1165  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_8  arc_capacity_930  -25
    arc_1_13_8  connected_order_arc_931  -14
    arc_1_13_8  in_degree_1147  1
    arc_1_13_8  out_degree_1160  1
    arc_1_13_8  original_T_including_depot_unload_1212  7.7248128224166851e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_8  arc_capacity_930  1
    load_1_13_8  segment_load_conservation_1150  -1
    load_1_13_8  segment_prefix_lb_1151  1
    load_1_13_8  segment_prefix_ub_1152  1
    load_1_13_8  free_load_conservation_1165  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_9  arc_capacity_932  -25
    arc_1_13_9  connected_order_arc_933  -14
    arc_1_13_9  in_degree_1154  1
    arc_1_13_9  out_degree_1160  1
    arc_1_13_9  original_T_including_depot_unload_1212  7.7983683767935065e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_9  arc_capacity_932  1
    load_1_13_9  segment_load_conservation_1157  -1
    load_1_13_9  segment_prefix_lb_1158  1
    load_1_13_9  segment_prefix_ub_1159  1
    load_1_13_9  free_load_conservation_1165  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_14  arc_capacity_934  -25
    arc_1_13_14  connected_order_arc_935  -14
    arc_1_13_14  out_degree_1160  1
    arc_1_13_14  in_degree_1167  1
    arc_1_13_14  original_T_including_depot_unload_1212  1.9785969874636677e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_14  arc_capacity_934  1
    load_1_13_14  free_load_conservation_1165  1
    load_1_13_14  free_load_conservation_1171  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_15  arc_capacity_936  -25
    arc_1_13_15  connected_order_arc_937  -14
    arc_1_13_15  out_degree_1160  1
    arc_1_13_15  in_degree_1173  1
    arc_1_13_15  original_T_including_depot_unload_1212  1.1499210972200315e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_15  arc_capacity_936  1
    load_1_13_15  free_load_conservation_1165  1
    load_1_13_15  free_load_conservation_1177  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_16  arc_capacity_938  -25
    arc_1_13_16  connected_order_arc_939  -14
    arc_1_13_16  out_degree_1160  1
    arc_1_13_16  in_degree_1179  1
    arc_1_13_16  original_T_including_depot_unload_1212  3.2286832955801827e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_16  arc_capacity_938  1
    load_1_13_16  free_load_conservation_1165  1
    load_1_13_16  free_load_conservation_1183  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_17  arc_capacity_940  -25
    arc_1_13_17  connected_order_arc_941  -14
    arc_1_13_17  out_degree_1160  1
    arc_1_13_17  in_degree_1185  1
    arc_1_13_17  original_T_including_depot_unload_1212  2.3332890980657526e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_17  arc_capacity_940  1
    load_1_13_17  free_load_conservation_1165  1
    load_1_13_17  free_load_conservation_1189  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_18  arc_capacity_942  -25
    arc_1_13_18  connected_order_arc_943  -14
    arc_1_13_18  out_degree_1160  1
    arc_1_13_18  in_degree_1191  1
    arc_1_13_18  original_T_including_depot_unload_1212  4.8905010520753694e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_18  arc_capacity_942  1
    load_1_13_18  free_load_conservation_1165  1
    load_1_13_18  free_load_conservation_1195  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_19  arc_capacity_944  -25
    arc_1_13_19  connected_order_arc_945  -14
    arc_1_13_19  out_degree_1160  1
    arc_1_13_19  in_degree_1197  1
    arc_1_13_19  original_T_including_depot_unload_1212  1.8319650761318992e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_19  arc_capacity_944  1
    load_1_13_19  free_load_conservation_1165  1
    load_1_13_19  free_load_conservation_1201  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_20  arc_capacity_946  -25
    arc_1_13_20  connected_order_arc_947  -14
    arc_1_13_20  out_degree_1160  1
    arc_1_13_20  in_degree_1203  1
    arc_1_13_20  original_T_including_depot_unload_1212  6.2793211180612207e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_20  arc_capacity_946  1
    load_1_13_20  free_load_conservation_1165  1
    load_1_13_20  free_load_conservation_1207  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_0  arc_capacity_948  -25
    arc_1_14_0  depot_return_or_bypass_1124  1
    arc_1_14_0  out_degree_1166  1
    arc_1_14_0  original_T_including_depot_unload_1212  1.3076700111397606e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_0  arc_capacity_948  1
    load_1_14_0  free_load_conservation_1171  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_5  arc_capacity_949  -25
    arc_1_14_5  connected_order_arc_950  -14
    arc_1_14_5  in_degree_1126  1
    arc_1_14_5  out_degree_1166  1
    arc_1_14_5  original_T_including_depot_unload_1212  9.7692852841087415e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_5  arc_capacity_949  1
    load_1_14_5  segment_load_conservation_1129  -1
    load_1_14_5  segment_prefix_lb_1130  1
    load_1_14_5  segment_prefix_ub_1131  1
    load_1_14_5  free_load_conservation_1171  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_6  arc_capacity_951  -25
    arc_1_14_6  connected_order_arc_952  -14
    arc_1_14_6  in_degree_1133  1
    arc_1_14_6  out_degree_1166  1
    arc_1_14_6  original_T_including_depot_unload_1212  5.4630148713373910e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_6  arc_capacity_951  1
    load_1_14_6  segment_load_conservation_1136  -1
    load_1_14_6  segment_prefix_lb_1137  1
    load_1_14_6  segment_prefix_ub_1138  1
    load_1_14_6  free_load_conservation_1171  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_7  arc_capacity_953  -25
    arc_1_14_7  connected_order_arc_954  -14
    arc_1_14_7  in_degree_1140  1
    arc_1_14_7  out_degree_1166  1
    arc_1_14_7  original_T_including_depot_unload_1212  6.0870346483367848e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_7  arc_capacity_953  1
    load_1_14_7  segment_load_conservation_1143  -1
    load_1_14_7  segment_prefix_lb_1144  1
    load_1_14_7  segment_prefix_ub_1145  1
    load_1_14_7  free_load_conservation_1171  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_8  arc_capacity_955  -25
    arc_1_14_8  connected_order_arc_956  -14
    arc_1_14_8  in_degree_1147  1
    arc_1_14_8  out_degree_1166  1
    arc_1_14_8  original_T_including_depot_unload_1212  6.9492720147205364e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_8  arc_capacity_955  1
    load_1_14_8  segment_load_conservation_1150  -1
    load_1_14_8  segment_prefix_lb_1151  1
    load_1_14_8  segment_prefix_ub_1152  1
    load_1_14_8  free_load_conservation_1171  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_9  arc_capacity_957  -25
    arc_1_14_9  connected_order_arc_958  -14
    arc_1_14_9  in_degree_1154  1
    arc_1_14_9  out_degree_1166  1
    arc_1_14_9  original_T_including_depot_unload_1212  6.7554763364087285e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_9  arc_capacity_957  1
    load_1_14_9  segment_load_conservation_1157  -1
    load_1_14_9  segment_prefix_lb_1158  1
    load_1_14_9  segment_prefix_ub_1159  1
    load_1_14_9  free_load_conservation_1171  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_13  arc_capacity_959  -25
    arc_1_14_13  connected_order_arc_960  -14
    arc_1_14_13  in_degree_1161  1
    arc_1_14_13  out_degree_1166  1
    arc_1_14_13  original_T_including_depot_unload_1212  1.9785969874636677e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_13  arc_capacity_959  1
    load_1_14_13  free_load_conservation_1165  -1
    load_1_14_13  free_load_conservation_1171  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_15  arc_capacity_961  -25
    arc_1_14_15  connected_order_arc_962  -14
    arc_1_14_15  out_degree_1166  1
    arc_1_14_15  in_degree_1173  1
    arc_1_14_15  original_T_including_depot_unload_1212  1.3218357148919101e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_15  arc_capacity_961  1
    load_1_14_15  free_load_conservation_1171  1
    load_1_14_15  free_load_conservation_1177  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_16  arc_capacity_963  -25
    arc_1_14_16  connected_order_arc_964  -14
    arc_1_14_16  out_degree_1166  1
    arc_1_14_16  in_degree_1179  1
    arc_1_14_16  original_T_including_depot_unload_1212  4.6588884124393707e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_16  arc_capacity_963  1
    load_1_14_16  free_load_conservation_1171  1
    load_1_14_16  free_load_conservation_1183  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_17  arc_capacity_965  -25
    arc_1_14_17  connected_order_arc_966  -14
    arc_1_14_17  out_degree_1166  1
    arc_1_14_17  in_degree_1185  1
    arc_1_14_17  original_T_including_depot_unload_1212  2.4500766064196278e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_17  arc_capacity_965  1
    load_1_14_17  free_load_conservation_1171  1
    load_1_14_17  free_load_conservation_1189  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_18  arc_capacity_967  -25
    arc_1_14_18  connected_order_arc_968  -14
    arc_1_14_18  out_degree_1166  1
    arc_1_14_18  in_degree_1191  1
    arc_1_14_18  original_T_including_depot_unload_1212  6.2102815646279714e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_18  arc_capacity_967  1
    load_1_14_18  free_load_conservation_1171  1
    load_1_14_18  free_load_conservation_1195  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_19  arc_capacity_969  -25
    arc_1_14_19  connected_order_arc_970  -14
    arc_1_14_19  out_degree_1166  1
    arc_1_14_19  in_degree_1197  1
    arc_1_14_19  original_T_including_depot_unload_1212  1.9170200697382236e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_19  arc_capacity_969  1
    load_1_14_19  free_load_conservation_1171  1
    load_1_14_19  free_load_conservation_1201  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_20  arc_capacity_971  -25
    arc_1_14_20  connected_order_arc_972  -14
    arc_1_14_20  out_degree_1166  1
    arc_1_14_20  in_degree_1203  1
    arc_1_14_20  original_T_including_depot_unload_1212  8.0531033344008677e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_20  arc_capacity_971  1
    load_1_14_20  free_load_conservation_1171  1
    load_1_14_20  free_load_conservation_1207  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_0  arc_capacity_973  -25
    arc_1_15_0  depot_return_or_bypass_1124  1
    arc_1_15_0  out_degree_1172  1
    arc_1_15_0  original_T_including_depot_unload_1212  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_0  arc_capacity_973  1
    load_1_15_0  free_load_conservation_1177  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_5  arc_capacity_974  -25
    arc_1_15_5  connected_order_arc_975  -14
    arc_1_15_5  in_degree_1126  1
    arc_1_15_5  out_degree_1172  1
    arc_1_15_5  original_T_including_depot_unload_1212  3.6824909986567474e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_5  arc_capacity_974  1
    load_1_15_5  segment_load_conservation_1129  -1
    load_1_15_5  segment_prefix_lb_1130  1
    load_1_15_5  segment_prefix_ub_1131  1
    load_1_15_5  free_load_conservation_1177  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_6  arc_capacity_976  -25
    arc_1_15_6  connected_order_arc_977  -14
    arc_1_15_6  in_degree_1133  1
    arc_1_15_6  out_degree_1172  1
    arc_1_15_6  original_T_including_depot_unload_1212  1.6876944916846833e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_6  arc_capacity_976  1
    load_1_15_6  segment_load_conservation_1136  -1
    load_1_15_6  segment_prefix_lb_1137  1
    load_1_15_6  segment_prefix_ub_1138  1
    load_1_15_6  free_load_conservation_1177  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_7  arc_capacity_978  -25
    arc_1_15_7  connected_order_arc_979  -14
    arc_1_15_7  in_degree_1140  1
    arc_1_15_7  out_degree_1172  1
    arc_1_15_7  original_T_including_depot_unload_1212  1.5013589792907314e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_7  arc_capacity_978  1
    load_1_15_7  segment_load_conservation_1143  -1
    load_1_15_7  segment_prefix_lb_1144  1
    load_1_15_7  segment_prefix_ub_1145  1
    load_1_15_7  free_load_conservation_1177  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_8  arc_capacity_980  -25
    arc_1_15_8  connected_order_arc_981  -14
    arc_1_15_8  in_degree_1147  1
    arc_1_15_8  out_degree_1172  1
    arc_1_15_8  original_T_including_depot_unload_1212  1.3626829404511475e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_8  arc_capacity_980  1
    load_1_15_8  segment_load_conservation_1150  -1
    load_1_15_8  segment_prefix_lb_1151  1
    load_1_15_8  segment_prefix_ub_1152  1
    load_1_15_8  free_load_conservation_1177  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_9  arc_capacity_982  -25
    arc_1_15_9  connected_order_arc_983  -14
    arc_1_15_9  in_degree_1154  1
    arc_1_15_9  out_degree_1172  1
    arc_1_15_9  original_T_including_depot_unload_1212  1.4573788798892317e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_9  arc_capacity_982  1
    load_1_15_9  segment_load_conservation_1157  -1
    load_1_15_9  segment_prefix_lb_1158  1
    load_1_15_9  segment_prefix_ub_1159  1
    load_1_15_9  free_load_conservation_1177  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_13  arc_capacity_984  -25
    arc_1_15_13  connected_order_arc_985  -14
    arc_1_15_13  in_degree_1161  1
    arc_1_15_13  out_degree_1172  1
    arc_1_15_13  original_T_including_depot_unload_1212  1.1499210972200315e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_13  arc_capacity_984  1
    load_1_15_13  free_load_conservation_1165  -1
    load_1_15_13  free_load_conservation_1177  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_14  arc_capacity_986  -25
    arc_1_15_14  connected_order_arc_987  -14
    arc_1_15_14  in_degree_1167  1
    arc_1_15_14  out_degree_1172  1
    arc_1_15_14  original_T_including_depot_unload_1212  1.3218357148919101e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_14  arc_capacity_986  1
    load_1_15_14  free_load_conservation_1171  -1
    load_1_15_14  free_load_conservation_1177  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_16  arc_capacity_988  -25
    arc_1_15_16  connected_order_arc_989  -14
    arc_1_15_16  out_degree_1172  1
    arc_1_15_16  in_degree_1179  1
    arc_1_15_16  original_T_including_depot_unload_1212  861.314419336229
    MARKER    'MARKER'                 'INTEND'
    load_1_15_16  arc_capacity_988  1
    load_1_15_16  free_load_conservation_1177  1
    load_1_15_16  free_load_conservation_1183  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_17  arc_capacity_990  -25
    arc_1_15_17  connected_order_arc_991  -14
    arc_1_15_17  out_degree_1172  1
    arc_1_15_17  in_degree_1185  1
    arc_1_15_17  original_T_including_depot_unload_1212  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_17  arc_capacity_990  1
    load_1_15_17  free_load_conservation_1177  1
    load_1_15_17  free_load_conservation_1189  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_18  arc_capacity_992  -25
    arc_1_15_18  connected_order_arc_993  -14
    arc_1_15_18  out_degree_1172  1
    arc_1_15_18  in_degree_1191  1
    arc_1_15_18  original_T_including_depot_unload_1212  7.3227602527872671e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_18  arc_capacity_992  1
    load_1_15_18  free_load_conservation_1177  1
    load_1_15_18  free_load_conservation_1195  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_19  arc_capacity_994  -25
    arc_1_15_19  connected_order_arc_995  -14
    arc_1_15_19  out_degree_1172  1
    arc_1_15_19  in_degree_1197  1
    arc_1_15_19  original_T_including_depot_unload_1212  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_19  arc_capacity_994  1
    load_1_15_19  free_load_conservation_1177  1
    load_1_15_19  free_load_conservation_1201  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_20  arc_capacity_996  -25
    arc_1_15_20  connected_order_arc_997  -14
    arc_1_15_20  out_degree_1172  1
    arc_1_15_20  in_degree_1203  1
    arc_1_15_20  original_T_including_depot_unload_1212  5.2280951376932137e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_20  arc_capacity_996  1
    load_1_15_20  free_load_conservation_1177  1
    load_1_15_20  free_load_conservation_1207  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_0  arc_capacity_998  -25
    arc_1_16_0  depot_return_or_bypass_1124  1
    arc_1_16_0  out_degree_1178  1
    arc_1_16_0  original_T_including_depot_unload_1212  1.0088905112952611e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_0  arc_capacity_998  1
    load_1_16_0  free_load_conservation_1183  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_5  arc_capacity_999  -25
    arc_1_16_5  connected_order_arc_1000  -14
    arc_1_16_5  in_degree_1126  1
    arc_1_16_5  out_degree_1178  1
    arc_1_16_5  original_T_including_depot_unload_1212  5.1107432522690152e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_5  arc_capacity_999  1
    load_1_16_5  segment_load_conservation_1129  -1
    load_1_16_5  segment_prefix_lb_1130  1
    load_1_16_5  segment_prefix_ub_1131  1
    load_1_16_5  free_load_conservation_1183  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_6  arc_capacity_1001  -25
    arc_1_16_6  connected_order_arc_1002  -14
    arc_1_16_6  in_degree_1133  1
    arc_1_16_6  out_degree_1178  1
    arc_1_16_6  original_T_including_depot_unload_1212  8.6289703303586691e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_6  arc_capacity_1001  1
    load_1_16_6  segment_load_conservation_1136  -1
    load_1_16_6  segment_prefix_lb_1137  1
    load_1_16_6  segment_prefix_ub_1138  1
    load_1_16_6  free_load_conservation_1183  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_7  arc_capacity_1003  -25
    arc_1_16_7  connected_order_arc_1004  -14
    arc_1_16_7  in_degree_1140  1
    arc_1_16_7  out_degree_1178  1
    arc_1_16_7  original_T_including_depot_unload_1212  7.5249256121297628e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_7  arc_capacity_1003  1
    load_1_16_7  segment_load_conservation_1143  -1
    load_1_16_7  segment_prefix_lb_1144  1
    load_1_16_7  segment_prefix_ub_1145  1
    load_1_16_7  free_load_conservation_1183  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_8  arc_capacity_1005  -25
    arc_1_16_8  connected_order_arc_1006  -14
    arc_1_16_8  in_degree_1147  1
    arc_1_16_8  out_degree_1178  1
    arc_1_16_8  original_T_including_depot_unload_1212  7.0141209816069022e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_8  arc_capacity_1005  1
    load_1_16_8  segment_load_conservation_1150  -1
    load_1_16_8  segment_prefix_lb_1151  1
    load_1_16_8  segment_prefix_ub_1152  1
    load_1_16_8  free_load_conservation_1183  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_9  arc_capacity_1007  -25
    arc_1_16_9  connected_order_arc_1008  -14
    arc_1_16_9  in_degree_1154  1
    arc_1_16_9  out_degree_1178  1
    arc_1_16_9  original_T_including_depot_unload_1212  754.162661294669
    MARKER    'MARKER'                 'INTEND'
    load_1_16_9  arc_capacity_1007  1
    load_1_16_9  segment_load_conservation_1157  -1
    load_1_16_9  segment_prefix_lb_1158  1
    load_1_16_9  segment_prefix_ub_1159  1
    load_1_16_9  free_load_conservation_1183  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_13  arc_capacity_1009  -25
    arc_1_16_13  connected_order_arc_1010  -14
    arc_1_16_13  in_degree_1161  1
    arc_1_16_13  out_degree_1178  1
    arc_1_16_13  original_T_including_depot_unload_1212  3.2286832955801827e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_13  arc_capacity_1009  1
    load_1_16_13  free_load_conservation_1165  -1
    load_1_16_13  free_load_conservation_1183  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_14  arc_capacity_1011  -25
    arc_1_16_14  connected_order_arc_1012  -14
    arc_1_16_14  in_degree_1167  1
    arc_1_16_14  out_degree_1178  1
    arc_1_16_14  original_T_including_depot_unload_1212  4.6588884124393707e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_14  arc_capacity_1011  1
    load_1_16_14  free_load_conservation_1171  -1
    load_1_16_14  free_load_conservation_1183  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_15  arc_capacity_1013  -25
    arc_1_16_15  connected_order_arc_1014  -14
    arc_1_16_15  in_degree_1173  1
    arc_1_16_15  out_degree_1178  1
    arc_1_16_15  original_T_including_depot_unload_1212  861.314419336229
    MARKER    'MARKER'                 'INTEND'
    load_1_16_15  arc_capacity_1013  1
    load_1_16_15  free_load_conservation_1177  -1
    load_1_16_15  free_load_conservation_1183  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_17  arc_capacity_1015  -25
    arc_1_16_17  connected_order_arc_1016  -14
    arc_1_16_17  out_degree_1178  1
    arc_1_16_17  in_degree_1185  1
    arc_1_16_17  original_T_including_depot_unload_1212  2.0104743468619281e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_17  arc_capacity_1015  1
    load_1_16_17  free_load_conservation_1183  1
    load_1_16_17  free_load_conservation_1189  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_18  arc_capacity_1017  -25
    arc_1_16_18  connected_order_arc_1018  -14
    arc_1_16_18  out_degree_1178  1
    arc_1_16_18  in_degree_1191  1
    arc_1_16_18  original_T_including_depot_unload_1212  1.6651295535886251e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_18  arc_capacity_1017  1
    load_1_16_18  free_load_conservation_1183  1
    load_1_16_18  free_load_conservation_1195  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_19  arc_capacity_1019  -25
    arc_1_16_19  connected_order_arc_1020  -14
    arc_1_16_19  out_degree_1178  1
    arc_1_16_19  in_degree_1197  1
    arc_1_16_19  original_T_including_depot_unload_1212  1.5183735648810946e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_19  arc_capacity_1019  1
    load_1_16_19  free_load_conservation_1183  1
    load_1_16_19  free_load_conservation_1201  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_20  arc_capacity_1021  -25
    arc_1_16_20  connected_order_arc_1022  -14
    arc_1_16_20  out_degree_1178  1
    arc_1_16_20  in_degree_1203  1
    arc_1_16_20  original_T_including_depot_unload_1212  3.6094216796124527e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_20  arc_capacity_1021  1
    load_1_16_20  free_load_conservation_1183  1
    load_1_16_20  free_load_conservation_1207  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_0  arc_capacity_1023  -25
    arc_1_17_0  depot_return_or_bypass_1124  1
    arc_1_17_0  out_degree_1184  1
    arc_1_17_0  original_T_including_depot_unload_1212  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_0  arc_capacity_1023  1
    load_1_17_0  free_load_conservation_1189  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_5  arc_capacity_1024  -25
    arc_1_17_5  connected_order_arc_1025  -14
    arc_1_17_5  in_degree_1126  1
    arc_1_17_5  out_degree_1184  1
    arc_1_17_5  original_T_including_depot_unload_1212  1.5502221880497036e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_5  arc_capacity_1024  1
    load_1_17_5  segment_load_conservation_1129  -1
    load_1_17_5  segment_prefix_lb_1130  1
    load_1_17_5  segment_prefix_ub_1131  1
    load_1_17_5  free_load_conservation_1189  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_6  arc_capacity_1026  -25
    arc_1_17_6  connected_order_arc_1027  -14
    arc_1_17_6  in_degree_1133  1
    arc_1_17_6  out_degree_1184  1
    arc_1_17_6  original_T_including_depot_unload_1212  2.5950001064050621e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_6  arc_capacity_1026  1
    load_1_17_6  segment_load_conservation_1136  -1
    load_1_17_6  segment_prefix_lb_1137  1
    load_1_17_6  segment_prefix_ub_1138  1
    load_1_17_6  free_load_conservation_1189  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_7  arc_capacity_1028  -25
    arc_1_17_7  connected_order_arc_1029  -14
    arc_1_17_7  in_degree_1140  1
    arc_1_17_7  out_degree_1184  1
    arc_1_17_7  original_T_including_depot_unload_1212  2.3179341182261583e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_7  arc_capacity_1028  1
    load_1_17_7  segment_load_conservation_1143  -1
    load_1_17_7  segment_prefix_lb_1144  1
    load_1_17_7  segment_prefix_ub_1145  1
    load_1_17_7  free_load_conservation_1189  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_8  arc_capacity_1030  -25
    arc_1_17_8  connected_order_arc_1031  -14
    arc_1_17_8  in_degree_1147  1
    arc_1_17_8  out_degree_1184  1
    arc_1_17_8  original_T_including_depot_unload_1212  2115.53677476792
    MARKER    'MARKER'                 'INTEND'
    load_1_17_8  arc_capacity_1030  1
    load_1_17_8  segment_load_conservation_1150  -1
    load_1_17_8  segment_prefix_lb_1151  1
    load_1_17_8  segment_prefix_ub_1152  1
    load_1_17_8  free_load_conservation_1189  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_9  arc_capacity_1032  -25
    arc_1_17_9  connected_order_arc_1033  -14
    arc_1_17_9  in_degree_1154  1
    arc_1_17_9  out_degree_1184  1
    arc_1_17_9  original_T_including_depot_unload_1212  2226.1143218952
    MARKER    'MARKER'                 'INTEND'
    load_1_17_9  arc_capacity_1032  1
    load_1_17_9  segment_load_conservation_1157  -1
    load_1_17_9  segment_prefix_lb_1158  1
    load_1_17_9  segment_prefix_ub_1159  1
    load_1_17_9  free_load_conservation_1189  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_13  arc_capacity_1034  -25
    arc_1_17_13  connected_order_arc_1035  -14
    arc_1_17_13  in_degree_1161  1
    arc_1_17_13  out_degree_1184  1
    arc_1_17_13  original_T_including_depot_unload_1212  2.3332890980657526e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_13  arc_capacity_1034  1
    load_1_17_13  free_load_conservation_1165  -1
    load_1_17_13  free_load_conservation_1189  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_14  arc_capacity_1036  -25
    arc_1_17_14  connected_order_arc_1037  -14
    arc_1_17_14  in_degree_1167  1
    arc_1_17_14  out_degree_1184  1
    arc_1_17_14  original_T_including_depot_unload_1212  2.4500766064196278e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_14  arc_capacity_1036  1
    load_1_17_14  free_load_conservation_1171  -1
    load_1_17_14  free_load_conservation_1189  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_15  arc_capacity_1038  -25
    arc_1_17_15  connected_order_arc_1039  -14
    arc_1_17_15  in_degree_1173  1
    arc_1_17_15  out_degree_1184  1
    arc_1_17_15  original_T_including_depot_unload_1212  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_15  arc_capacity_1038  1
    load_1_17_15  free_load_conservation_1177  -1
    load_1_17_15  free_load_conservation_1189  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_16  arc_capacity_1040  -25
    arc_1_17_16  connected_order_arc_1041  -14
    arc_1_17_16  in_degree_1179  1
    arc_1_17_16  out_degree_1184  1
    arc_1_17_16  original_T_including_depot_unload_1212  2.0104743468619281e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_16  arc_capacity_1040  1
    load_1_17_16  free_load_conservation_1183  -1
    load_1_17_16  free_load_conservation_1189  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_18  arc_capacity_1042  -25
    arc_1_17_18  connected_order_arc_1043  -14
    arc_1_17_18  out_degree_1184  1
    arc_1_17_18  in_degree_1191  1
    arc_1_17_18  original_T_including_depot_unload_1212  1.8442669473423912e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_18  arc_capacity_1042  1
    load_1_17_18  free_load_conservation_1189  1
    load_1_17_18  free_load_conservation_1195  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_19  arc_capacity_1044  -25
    arc_1_17_19  connected_order_arc_1045  -14
    arc_1_17_19  out_degree_1184  1
    arc_1_17_19  in_degree_1197  1
    arc_1_17_19  original_T_including_depot_unload_1212  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_19  arc_capacity_1044  1
    load_1_17_19  free_load_conservation_1189  1
    load_1_17_19  free_load_conservation_1201  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_20  arc_capacity_1046  -25
    arc_1_17_20  connected_order_arc_1047  -14
    arc_1_17_20  out_degree_1184  1
    arc_1_17_20  in_degree_1203  1
    arc_1_17_20  original_T_including_depot_unload_1212  1.7883808204567979e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_20  arc_capacity_1046  1
    load_1_17_20  free_load_conservation_1189  1
    load_1_17_20  free_load_conservation_1207  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_0  arc_capacity_1048  -25
    arc_1_18_0  depot_return_or_bypass_1124  1
    arc_1_18_0  out_degree_1190  1
    arc_1_18_0  original_T_including_depot_unload_1212  8.7749189782983967e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_0  arc_capacity_1048  1
    load_1_18_0  free_load_conservation_1195  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_5  arc_capacity_1049  -25
    arc_1_18_5  connected_order_arc_1050  -14
    arc_1_18_5  in_degree_1126  1
    arc_1_18_5  out_degree_1190  1
    arc_1_18_5  original_T_including_depot_unload_1212  3.6821827312741834e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_5  arc_capacity_1049  1
    load_1_18_5  segment_load_conservation_1129  -1
    load_1_18_5  segment_prefix_lb_1130  1
    load_1_18_5  segment_prefix_ub_1131  1
    load_1_18_5  free_load_conservation_1195  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_6  arc_capacity_1051  -25
    arc_1_18_6  connected_order_arc_1052  -14
    arc_1_18_6  in_degree_1133  1
    arc_1_18_6  out_degree_1190  1
    arc_1_18_6  original_T_including_depot_unload_1212  9.5892865701726816e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_6  arc_capacity_1051  1
    load_1_18_6  segment_load_conservation_1136  -1
    load_1_18_6  segment_prefix_lb_1137  1
    load_1_18_6  segment_prefix_ub_1138  1
    load_1_18_6  free_load_conservation_1195  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_7  arc_capacity_1053  -25
    arc_1_18_7  connected_order_arc_1054  -14
    arc_1_18_7  in_degree_1140  1
    arc_1_18_7  out_degree_1190  1
    arc_1_18_7  original_T_including_depot_unload_1212  8.0195161088934185e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_7  arc_capacity_1053  1
    load_1_18_7  segment_load_conservation_1143  -1
    load_1_18_7  segment_prefix_lb_1144  1
    load_1_18_7  segment_prefix_ub_1145  1
    load_1_18_7  free_load_conservation_1195  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_8  arc_capacity_1055  -25
    arc_1_18_8  connected_order_arc_1056  -14
    arc_1_18_8  in_degree_1147  1
    arc_1_18_8  out_degree_1190  1
    arc_1_18_8  original_T_including_depot_unload_1212  7.0804311489116617e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_8  arc_capacity_1055  1
    load_1_18_8  segment_load_conservation_1150  -1
    load_1_18_8  segment_prefix_lb_1151  1
    load_1_18_8  segment_prefix_ub_1152  1
    load_1_18_8  free_load_conservation_1195  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_9  arc_capacity_1057  -25
    arc_1_18_9  connected_order_arc_1058  -14
    arc_1_18_9  in_degree_1154  1
    arc_1_18_9  out_degree_1190  1
    arc_1_18_9  original_T_including_depot_unload_1212  7.8136221151890174e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_9  arc_capacity_1057  1
    load_1_18_9  segment_load_conservation_1157  -1
    load_1_18_9  segment_prefix_lb_1158  1
    load_1_18_9  segment_prefix_ub_1159  1
    load_1_18_9  free_load_conservation_1195  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_13  arc_capacity_1059  -25
    arc_1_18_13  connected_order_arc_1060  -14
    arc_1_18_13  in_degree_1161  1
    arc_1_18_13  out_degree_1190  1
    arc_1_18_13  original_T_including_depot_unload_1212  4.8905010520753694e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_13  arc_capacity_1059  1
    load_1_18_13  free_load_conservation_1165  -1
    load_1_18_13  free_load_conservation_1195  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_14  arc_capacity_1061  -25
    arc_1_18_14  connected_order_arc_1062  -14
    arc_1_18_14  in_degree_1167  1
    arc_1_18_14  out_degree_1190  1
    arc_1_18_14  original_T_including_depot_unload_1212  6.2102815646279714e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_14  arc_capacity_1061  1
    load_1_18_14  free_load_conservation_1171  -1
    load_1_18_14  free_load_conservation_1195  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_15  arc_capacity_1063  -25
    arc_1_18_15  connected_order_arc_1064  -14
    arc_1_18_15  in_degree_1173  1
    arc_1_18_15  out_degree_1190  1
    arc_1_18_15  original_T_including_depot_unload_1212  7.3227602527872671e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_15  arc_capacity_1063  1
    load_1_18_15  free_load_conservation_1177  -1
    load_1_18_15  free_load_conservation_1195  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_16  arc_capacity_1065  -25
    arc_1_18_16  connected_order_arc_1066  -14
    arc_1_18_16  in_degree_1179  1
    arc_1_18_16  out_degree_1190  1
    arc_1_18_16  original_T_including_depot_unload_1212  1.6651295535886251e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_16  arc_capacity_1065  1
    load_1_18_16  free_load_conservation_1183  -1
    load_1_18_16  free_load_conservation_1195  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_17  arc_capacity_1067  -25
    arc_1_18_17  connected_order_arc_1068  -14
    arc_1_18_17  in_degree_1185  1
    arc_1_18_17  out_degree_1190  1
    arc_1_18_17  original_T_including_depot_unload_1212  1.8442669473423912e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_17  arc_capacity_1067  1
    load_1_18_17  free_load_conservation_1189  -1
    load_1_18_17  free_load_conservation_1195  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_19  arc_capacity_1069  -25
    arc_1_18_19  connected_order_arc_1070  -14
    arc_1_18_19  out_degree_1190  1
    arc_1_18_19  in_degree_1197  1
    arc_1_18_19  original_T_including_depot_unload_1212  1.3551088510632424e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_19  arc_capacity_1069  1
    load_1_18_19  free_load_conservation_1195  1
    load_1_18_19  free_load_conservation_1201  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_20  arc_capacity_1071  -25
    arc_1_18_20  connected_order_arc_1072  -14
    arc_1_18_20  out_degree_1190  1
    arc_1_18_20  in_degree_1203  1
    arc_1_18_20  original_T_including_depot_unload_1212  2.8747557636937808e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_20  arc_capacity_1071  1
    load_1_18_20  free_load_conservation_1195  1
    load_1_18_20  free_load_conservation_1207  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_0  arc_capacity_1073  -25
    arc_1_19_0  depot_return_or_bypass_1124  1
    arc_1_19_0  out_degree_1196  1
    arc_1_19_0  original_T_including_depot_unload_1212  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_0  arc_capacity_1073  1
    load_1_19_0  free_load_conservation_1201  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_5  arc_capacity_1074  -25
    arc_1_19_5  connected_order_arc_1075  -14
    arc_1_19_5  in_degree_1126  1
    arc_1_19_5  out_degree_1196  1
    arc_1_19_5  original_T_including_depot_unload_1212  1.1479472058029019e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_5  arc_capacity_1074  1
    load_1_19_5  segment_load_conservation_1129  -1
    load_1_19_5  segment_prefix_lb_1130  1
    load_1_19_5  segment_prefix_ub_1131  1
    load_1_19_5  free_load_conservation_1201  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_6  arc_capacity_1076  -25
    arc_1_19_6  connected_order_arc_1077  -14
    arc_1_19_6  in_degree_1133  1
    arc_1_19_6  out_degree_1196  1
    arc_1_19_6  original_T_including_depot_unload_1212  1.9878052050440085e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_6  arc_capacity_1076  1
    load_1_19_6  segment_load_conservation_1136  -1
    load_1_19_6  segment_prefix_lb_1137  1
    load_1_19_6  segment_prefix_ub_1138  1
    load_1_19_6  free_load_conservation_1201  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_7  arc_capacity_1078  -25
    arc_1_19_7  connected_order_arc_1079  -14
    arc_1_19_7  in_degree_1140  1
    arc_1_19_7  out_degree_1196  1
    arc_1_19_7  original_T_including_depot_unload_1212  1.7017879962005411e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_7  arc_capacity_1078  1
    load_1_19_7  segment_load_conservation_1143  -1
    load_1_19_7  segment_prefix_lb_1144  1
    load_1_19_7  segment_prefix_ub_1145  1
    load_1_19_7  free_load_conservation_1201  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_8  arc_capacity_1080  -25
    arc_1_19_8  connected_order_arc_1081  -14
    arc_1_19_8  in_degree_1147  1
    arc_1_19_8  out_degree_1196  1
    arc_1_19_8  original_T_including_depot_unload_1212  1.4961553163922974e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_8  arc_capacity_1080  1
    load_1_19_8  segment_load_conservation_1150  -1
    load_1_19_8  segment_prefix_lb_1151  1
    load_1_19_8  segment_prefix_ub_1152  1
    load_1_19_8  free_load_conservation_1201  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_9  arc_capacity_1082  -25
    arc_1_19_9  connected_order_arc_1083  -14
    arc_1_19_9  in_degree_1154  1
    arc_1_19_9  out_degree_1196  1
    arc_1_19_9  original_T_including_depot_unload_1212  1.6048175645110312e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_9  arc_capacity_1082  1
    load_1_19_9  segment_load_conservation_1157  -1
    load_1_19_9  segment_prefix_lb_1158  1
    load_1_19_9  segment_prefix_ub_1159  1
    load_1_19_9  free_load_conservation_1201  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_13  arc_capacity_1084  -25
    arc_1_19_13  connected_order_arc_1085  -14
    arc_1_19_13  in_degree_1161  1
    arc_1_19_13  out_degree_1196  1
    arc_1_19_13  original_T_including_depot_unload_1212  1.8319650761318992e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_13  arc_capacity_1084  1
    load_1_19_13  free_load_conservation_1165  -1
    load_1_19_13  free_load_conservation_1201  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_14  arc_capacity_1086  -25
    arc_1_19_14  connected_order_arc_1087  -14
    arc_1_19_14  in_degree_1167  1
    arc_1_19_14  out_degree_1196  1
    arc_1_19_14  original_T_including_depot_unload_1212  1.9170200697382236e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_14  arc_capacity_1086  1
    load_1_19_14  free_load_conservation_1171  -1
    load_1_19_14  free_load_conservation_1201  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_15  arc_capacity_1088  -25
    arc_1_19_15  connected_order_arc_1089  -14
    arc_1_19_15  in_degree_1173  1
    arc_1_19_15  out_degree_1196  1
    arc_1_19_15  original_T_including_depot_unload_1212  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_15  arc_capacity_1088  1
    load_1_19_15  free_load_conservation_1177  -1
    load_1_19_15  free_load_conservation_1201  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_16  arc_capacity_1090  -25
    arc_1_19_16  connected_order_arc_1091  -14
    arc_1_19_16  in_degree_1179  1
    arc_1_19_16  out_degree_1196  1
    arc_1_19_16  original_T_including_depot_unload_1212  1.5183735648810946e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_16  arc_capacity_1090  1
    load_1_19_16  free_load_conservation_1183  -1
    load_1_19_16  free_load_conservation_1201  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_17  arc_capacity_1092  -25
    arc_1_19_17  connected_order_arc_1093  -14
    arc_1_19_17  in_degree_1185  1
    arc_1_19_17  out_degree_1196  1
    arc_1_19_17  original_T_including_depot_unload_1212  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_17  arc_capacity_1092  1
    load_1_19_17  free_load_conservation_1189  -1
    load_1_19_17  free_load_conservation_1201  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_18  arc_capacity_1094  -25
    arc_1_19_18  connected_order_arc_1095  -14
    arc_1_19_18  in_degree_1191  1
    arc_1_19_18  out_degree_1196  1
    arc_1_19_18  original_T_including_depot_unload_1212  1.3551088510632424e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_18  arc_capacity_1094  1
    load_1_19_18  free_load_conservation_1195  -1
    load_1_19_18  free_load_conservation_1201  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_20  arc_capacity_1096  -25
    arc_1_19_20  connected_order_arc_1097  -14
    arc_1_19_20  out_degree_1196  1
    arc_1_19_20  in_degree_1203  1
    arc_1_19_20  original_T_including_depot_unload_1212  1.3852878731513219e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_20  arc_capacity_1096  1
    load_1_19_20  free_load_conservation_1201  1
    load_1_19_20  free_load_conservation_1207  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_0  arc_capacity_1098  -25
    arc_1_20_0  depot_return_or_bypass_1124  1
    arc_1_20_0  out_degree_1202  1
    arc_1_20_0  original_T_including_depot_unload_1212  1.0479182987243917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_0  arc_capacity_1098  1
    load_1_20_0  free_load_conservation_1207  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_5  arc_capacity_1099  -25
    arc_1_20_5  connected_order_arc_1100  -14
    arc_1_20_5  in_degree_1126  1
    arc_1_20_5  out_degree_1202  1
    arc_1_20_5  original_T_including_depot_unload_1212  2.4155873404211835e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_5  arc_capacity_1099  1
    load_1_20_5  segment_load_conservation_1129  -1
    load_1_20_5  segment_prefix_lb_1130  1
    load_1_20_5  segment_prefix_ub_1131  1
    load_1_20_5  free_load_conservation_1207  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_6  arc_capacity_1101  -25
    arc_1_20_6  connected_order_arc_1102  -14
    arc_1_20_6  in_degree_1133  1
    arc_1_20_6  out_degree_1202  1
    arc_1_20_6  original_T_including_depot_unload_1212  1.2213551686272770e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_6  arc_capacity_1101  1
    load_1_20_6  segment_load_conservation_1136  -1
    load_1_20_6  segment_prefix_lb_1137  1
    load_1_20_6  segment_prefix_ub_1138  1
    load_1_20_6  free_load_conservation_1207  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_7  arc_capacity_1103  -25
    arc_1_20_7  connected_order_arc_1104  -14
    arc_1_20_7  in_degree_1140  1
    arc_1_20_7  out_degree_1202  1
    arc_1_20_7  original_T_including_depot_unload_1212  1.0854925215530507e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_7  arc_capacity_1103  1
    load_1_20_7  segment_load_conservation_1143  -1
    load_1_20_7  segment_prefix_lb_1144  1
    load_1_20_7  segment_prefix_ub_1145  1
    load_1_20_7  free_load_conservation_1207  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_8  arc_capacity_1105  -25
    arc_1_20_8  connected_order_arc_1106  -14
    arc_1_20_8  in_degree_1147  1
    arc_1_20_8  out_degree_1202  1
    arc_1_20_8  original_T_including_depot_unload_1212  9.9524628735690555e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_8  arc_capacity_1105  1
    load_1_20_8  segment_load_conservation_1150  -1
    load_1_20_8  segment_prefix_lb_1151  1
    load_1_20_8  segment_prefix_ub_1152  1
    load_1_20_8  free_load_conservation_1207  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_9  arc_capacity_1107  -25
    arc_1_20_9  connected_order_arc_1108  -14
    arc_1_20_9  in_degree_1154  1
    arc_1_20_9  out_degree_1202  1
    arc_1_20_9  original_T_including_depot_unload_1212  1.0684489086573428e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_9  arc_capacity_1107  1
    load_1_20_9  segment_load_conservation_1157  -1
    load_1_20_9  segment_prefix_lb_1158  1
    load_1_20_9  segment_prefix_ub_1159  1
    load_1_20_9  free_load_conservation_1207  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_13  arc_capacity_1109  -25
    arc_1_20_13  connected_order_arc_1110  -14
    arc_1_20_13  in_degree_1161  1
    arc_1_20_13  out_degree_1202  1
    arc_1_20_13  original_T_including_depot_unload_1212  6.2793211180612207e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_13  arc_capacity_1109  1
    load_1_20_13  free_load_conservation_1165  -1
    load_1_20_13  free_load_conservation_1207  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_14  arc_capacity_1111  -25
    arc_1_20_14  connected_order_arc_1112  -14
    arc_1_20_14  in_degree_1167  1
    arc_1_20_14  out_degree_1202  1
    arc_1_20_14  original_T_including_depot_unload_1212  8.0531033344008677e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_14  arc_capacity_1111  1
    load_1_20_14  free_load_conservation_1171  -1
    load_1_20_14  free_load_conservation_1207  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_15  arc_capacity_1113  -25
    arc_1_20_15  connected_order_arc_1114  -14
    arc_1_20_15  in_degree_1173  1
    arc_1_20_15  out_degree_1202  1
    arc_1_20_15  original_T_including_depot_unload_1212  5.2280951376932137e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_15  arc_capacity_1113  1
    load_1_20_15  free_load_conservation_1177  -1
    load_1_20_15  free_load_conservation_1207  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_16  arc_capacity_1115  -25
    arc_1_20_16  connected_order_arc_1116  -14
    arc_1_20_16  in_degree_1179  1
    arc_1_20_16  out_degree_1202  1
    arc_1_20_16  original_T_including_depot_unload_1212  3.6094216796124527e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_16  arc_capacity_1115  1
    load_1_20_16  free_load_conservation_1183  -1
    load_1_20_16  free_load_conservation_1207  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_17  arc_capacity_1117  -25
    arc_1_20_17  connected_order_arc_1118  -14
    arc_1_20_17  in_degree_1185  1
    arc_1_20_17  out_degree_1202  1
    arc_1_20_17  original_T_including_depot_unload_1212  1.7883808204567979e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_17  arc_capacity_1117  1
    load_1_20_17  free_load_conservation_1189  -1
    load_1_20_17  free_load_conservation_1207  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_18  arc_capacity_1119  -25
    arc_1_20_18  connected_order_arc_1120  -14
    arc_1_20_18  in_degree_1191  1
    arc_1_20_18  out_degree_1202  1
    arc_1_20_18  original_T_including_depot_unload_1212  2.8747557636937808e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_18  arc_capacity_1119  1
    load_1_20_18  free_load_conservation_1195  -1
    load_1_20_18  free_load_conservation_1207  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_19  arc_capacity_1121  -25
    arc_1_20_19  connected_order_arc_1122  -14
    arc_1_20_19  in_degree_1197  1
    arc_1_20_19  out_degree_1202  1
    arc_1_20_19  original_T_including_depot_unload_1212  1.3852878731513219e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_19  arc_capacity_1121  1
    load_1_20_19  free_load_conservation_1201  -1
    load_1_20_19  free_load_conservation_1207  1
    visit_2_10  out_degree_1458  -1
    visit_2_10  in_degree_1459  -1
    visit_2_10  order_active_lb_1460  -1
    visit_2_10  order_active_ub_1461  -11
    order_2_10  connected_order_arc_1227  -1
    order_2_10  connected_order_arc_1229  -1
    order_2_10  connected_order_arc_1231  -1
    order_2_10  connected_order_arc_1233  -1
    order_2_10  connected_order_arc_1235  -1
    order_2_10  connected_order_arc_1237  -1
    order_2_10  connected_order_arc_1239  -1
    order_2_10  connected_order_arc_1241  -1
    order_2_10  connected_order_arc_1243  -1
    order_2_10  connected_order_arc_1245  -1
    order_2_10  connected_order_arc_1248  1
    order_2_10  connected_order_arc_1269  1
    order_2_10  connected_order_arc_1290  1
    order_2_10  connected_order_arc_1311  1
    order_2_10  connected_order_arc_1332  1
    order_2_10  connected_order_arc_1353  1
    order_2_10  connected_order_arc_1374  1
    order_2_10  connected_order_arc_1395  1
    order_2_10  connected_order_arc_1416  1
    order_2_10  connected_order_arc_1437  1
    order_2_10  order_active_lb_1460  1
    order_2_10  order_active_ub_1461  1
    order_2_10  fixed_segment_relative_order_1527  -1
    visit_2_11  out_degree_1465  -1
    visit_2_11  in_degree_1466  -1
    visit_2_11  order_active_lb_1467  -1
    visit_2_11  order_active_ub_1468  -11
    order_2_11  connected_order_arc_1227  1
    order_2_11  connected_order_arc_1248  -1
    order_2_11  connected_order_arc_1250  -1
    order_2_11  connected_order_arc_1252  -1
    order_2_11  connected_order_arc_1254  -1
    order_2_11  connected_order_arc_1256  -1
    order_2_11  connected_order_arc_1258  -1
    order_2_11  connected_order_arc_1260  -1
    order_2_11  connected_order_arc_1262  -1
    order_2_11  connected_order_arc_1264  -1
    order_2_11  connected_order_arc_1266  -1
    order_2_11  connected_order_arc_1271  1
    order_2_11  connected_order_arc_1292  1
    order_2_11  connected_order_arc_1313  1
    order_2_11  connected_order_arc_1334  1
    order_2_11  connected_order_arc_1355  1
    order_2_11  connected_order_arc_1376  1
    order_2_11  connected_order_arc_1397  1
    order_2_11  connected_order_arc_1418  1
    order_2_11  connected_order_arc_1439  1
    order_2_11  order_active_lb_1467  1
    order_2_11  order_active_ub_1468  1
    order_2_11  fixed_segment_relative_order_1527  1
    order_2_11  fixed_segment_relative_order_1528  -1
    visit_2_12  out_degree_1472  -1
    visit_2_12  in_degree_1473  -1
    visit_2_12  order_active_lb_1474  -1
    visit_2_12  order_active_ub_1475  -11
    order_2_12  connected_order_arc_1229  1
    order_2_12  connected_order_arc_1250  1
    order_2_12  connected_order_arc_1269  -1
    order_2_12  connected_order_arc_1271  -1
    order_2_12  connected_order_arc_1273  -1
    order_2_12  connected_order_arc_1275  -1
    order_2_12  connected_order_arc_1277  -1
    order_2_12  connected_order_arc_1279  -1
    order_2_12  connected_order_arc_1281  -1
    order_2_12  connected_order_arc_1283  -1
    order_2_12  connected_order_arc_1285  -1
    order_2_12  connected_order_arc_1287  -1
    order_2_12  connected_order_arc_1294  1
    order_2_12  connected_order_arc_1315  1
    order_2_12  connected_order_arc_1336  1
    order_2_12  connected_order_arc_1357  1
    order_2_12  connected_order_arc_1378  1
    order_2_12  connected_order_arc_1399  1
    order_2_12  connected_order_arc_1420  1
    order_2_12  connected_order_arc_1441  1
    order_2_12  order_active_lb_1474  1
    order_2_12  order_active_ub_1475  1
    order_2_12  fixed_segment_relative_order_1528  1
    visit_2_13  out_degree_1479  -1
    visit_2_13  in_degree_1480  -1
    visit_2_13  order_active_lb_1481  -1
    visit_2_13  order_active_ub_1482  -11
    visit_2_13  service_visit_def_1483  -1
    order_2_13  connected_order_arc_1231  1
    order_2_13  connected_order_arc_1252  1
    order_2_13  connected_order_arc_1273  1
    order_2_13  connected_order_arc_1290  -1
    order_2_13  connected_order_arc_1292  -1
    order_2_13  connected_order_arc_1294  -1
    order_2_13  connected_order_arc_1296  -1
    order_2_13  connected_order_arc_1298  -1
    order_2_13  connected_order_arc_1300  -1
    order_2_13  connected_order_arc_1302  -1
    order_2_13  connected_order_arc_1304  -1
    order_2_13  connected_order_arc_1306  -1
    order_2_13  connected_order_arc_1308  -1
    order_2_13  connected_order_arc_1317  1
    order_2_13  connected_order_arc_1338  1
    order_2_13  connected_order_arc_1359  1
    order_2_13  connected_order_arc_1380  1
    order_2_13  connected_order_arc_1401  1
    order_2_13  connected_order_arc_1422  1
    order_2_13  connected_order_arc_1443  1
    order_2_13  order_active_lb_1481  1
    order_2_13  order_active_ub_1482  1
    visit_2_14  out_degree_1485  -1
    visit_2_14  in_degree_1486  -1
    visit_2_14  order_active_lb_1487  -1
    visit_2_14  order_active_ub_1488  -11
    visit_2_14  service_visit_def_1489  -1
    order_2_14  connected_order_arc_1233  1
    order_2_14  connected_order_arc_1254  1
    order_2_14  connected_order_arc_1275  1
    order_2_14  connected_order_arc_1296  1
    order_2_14  connected_order_arc_1311  -1
    order_2_14  connected_order_arc_1313  -1
    order_2_14  connected_order_arc_1315  -1
    order_2_14  connected_order_arc_1317  -1
    order_2_14  connected_order_arc_1319  -1
    order_2_14  connected_order_arc_1321  -1
    order_2_14  connected_order_arc_1323  -1
    order_2_14  connected_order_arc_1325  -1
    order_2_14  connected_order_arc_1327  -1
    order_2_14  connected_order_arc_1329  -1
    order_2_14  connected_order_arc_1340  1
    order_2_14  connected_order_arc_1361  1
    order_2_14  connected_order_arc_1382  1
    order_2_14  connected_order_arc_1403  1
    order_2_14  connected_order_arc_1424  1
    order_2_14  connected_order_arc_1445  1
    order_2_14  order_active_lb_1487  1
    order_2_14  order_active_ub_1488  1
    visit_2_15  out_degree_1491  -1
    visit_2_15  in_degree_1492  -1
    visit_2_15  order_active_lb_1493  -1
    visit_2_15  order_active_ub_1494  -11
    visit_2_15  service_visit_def_1495  -1
    order_2_15  connected_order_arc_1235  1
    order_2_15  connected_order_arc_1256  1
    order_2_15  connected_order_arc_1277  1
    order_2_15  connected_order_arc_1298  1
    order_2_15  connected_order_arc_1319  1
    order_2_15  connected_order_arc_1332  -1
    order_2_15  connected_order_arc_1334  -1
    order_2_15  connected_order_arc_1336  -1
    order_2_15  connected_order_arc_1338  -1
    order_2_15  connected_order_arc_1340  -1
    order_2_15  connected_order_arc_1342  -1
    order_2_15  connected_order_arc_1344  -1
    order_2_15  connected_order_arc_1346  -1
    order_2_15  connected_order_arc_1348  -1
    order_2_15  connected_order_arc_1350  -1
    order_2_15  connected_order_arc_1363  1
    order_2_15  connected_order_arc_1384  1
    order_2_15  connected_order_arc_1405  1
    order_2_15  connected_order_arc_1426  1
    order_2_15  connected_order_arc_1447  1
    order_2_15  order_active_lb_1493  1
    order_2_15  order_active_ub_1494  1
    visit_2_16  out_degree_1497  -1
    visit_2_16  in_degree_1498  -1
    visit_2_16  order_active_lb_1499  -1
    visit_2_16  order_active_ub_1500  -11
    visit_2_16  service_visit_def_1501  -1
    order_2_16  connected_order_arc_1237  1
    order_2_16  connected_order_arc_1258  1
    order_2_16  connected_order_arc_1279  1
    order_2_16  connected_order_arc_1300  1
    order_2_16  connected_order_arc_1321  1
    order_2_16  connected_order_arc_1342  1
    order_2_16  connected_order_arc_1353  -1
    order_2_16  connected_order_arc_1355  -1
    order_2_16  connected_order_arc_1357  -1
    order_2_16  connected_order_arc_1359  -1
    order_2_16  connected_order_arc_1361  -1
    order_2_16  connected_order_arc_1363  -1
    order_2_16  connected_order_arc_1365  -1
    order_2_16  connected_order_arc_1367  -1
    order_2_16  connected_order_arc_1369  -1
    order_2_16  connected_order_arc_1371  -1
    order_2_16  connected_order_arc_1386  1
    order_2_16  connected_order_arc_1407  1
    order_2_16  connected_order_arc_1428  1
    order_2_16  connected_order_arc_1449  1
    order_2_16  order_active_lb_1499  1
    order_2_16  order_active_ub_1500  1
    visit_2_17  out_degree_1503  -1
    visit_2_17  in_degree_1504  -1
    visit_2_17  order_active_lb_1505  -1
    visit_2_17  order_active_ub_1506  -11
    visit_2_17  service_visit_def_1507  -1
    order_2_17  connected_order_arc_1239  1
    order_2_17  connected_order_arc_1260  1
    order_2_17  connected_order_arc_1281  1
    order_2_17  connected_order_arc_1302  1
    order_2_17  connected_order_arc_1323  1
    order_2_17  connected_order_arc_1344  1
    order_2_17  connected_order_arc_1365  1
    order_2_17  connected_order_arc_1374  -1
    order_2_17  connected_order_arc_1376  -1
    order_2_17  connected_order_arc_1378  -1
    order_2_17  connected_order_arc_1380  -1
    order_2_17  connected_order_arc_1382  -1
    order_2_17  connected_order_arc_1384  -1
    order_2_17  connected_order_arc_1386  -1
    order_2_17  connected_order_arc_1388  -1
    order_2_17  connected_order_arc_1390  -1
    order_2_17  connected_order_arc_1392  -1
    order_2_17  connected_order_arc_1409  1
    order_2_17  connected_order_arc_1430  1
    order_2_17  connected_order_arc_1451  1
    order_2_17  order_active_lb_1505  1
    order_2_17  order_active_ub_1506  1
    visit_2_18  out_degree_1509  -1
    visit_2_18  in_degree_1510  -1
    visit_2_18  order_active_lb_1511  -1
    visit_2_18  order_active_ub_1512  -11
    visit_2_18  service_visit_def_1513  -1
    order_2_18  connected_order_arc_1241  1
    order_2_18  connected_order_arc_1262  1
    order_2_18  connected_order_arc_1283  1
    order_2_18  connected_order_arc_1304  1
    order_2_18  connected_order_arc_1325  1
    order_2_18  connected_order_arc_1346  1
    order_2_18  connected_order_arc_1367  1
    order_2_18  connected_order_arc_1388  1
    order_2_18  connected_order_arc_1395  -1
    order_2_18  connected_order_arc_1397  -1
    order_2_18  connected_order_arc_1399  -1
    order_2_18  connected_order_arc_1401  -1
    order_2_18  connected_order_arc_1403  -1
    order_2_18  connected_order_arc_1405  -1
    order_2_18  connected_order_arc_1407  -1
    order_2_18  connected_order_arc_1409  -1
    order_2_18  connected_order_arc_1411  -1
    order_2_18  connected_order_arc_1413  -1
    order_2_18  connected_order_arc_1432  1
    order_2_18  connected_order_arc_1453  1
    order_2_18  order_active_lb_1511  1
    order_2_18  order_active_ub_1512  1
    visit_2_19  out_degree_1515  -1
    visit_2_19  in_degree_1516  -1
    visit_2_19  order_active_lb_1517  -1
    visit_2_19  order_active_ub_1518  -11
    visit_2_19  service_visit_def_1519  -1
    order_2_19  connected_order_arc_1243  1
    order_2_19  connected_order_arc_1264  1
    order_2_19  connected_order_arc_1285  1
    order_2_19  connected_order_arc_1306  1
    order_2_19  connected_order_arc_1327  1
    order_2_19  connected_order_arc_1348  1
    order_2_19  connected_order_arc_1369  1
    order_2_19  connected_order_arc_1390  1
    order_2_19  connected_order_arc_1411  1
    order_2_19  connected_order_arc_1416  -1
    order_2_19  connected_order_arc_1418  -1
    order_2_19  connected_order_arc_1420  -1
    order_2_19  connected_order_arc_1422  -1
    order_2_19  connected_order_arc_1424  -1
    order_2_19  connected_order_arc_1426  -1
    order_2_19  connected_order_arc_1428  -1
    order_2_19  connected_order_arc_1430  -1
    order_2_19  connected_order_arc_1432  -1
    order_2_19  connected_order_arc_1434  -1
    order_2_19  connected_order_arc_1455  1
    order_2_19  order_active_lb_1517  1
    order_2_19  order_active_ub_1518  1
    visit_2_20  out_degree_1521  -1
    visit_2_20  in_degree_1522  -1
    visit_2_20  order_active_lb_1523  -1
    visit_2_20  order_active_ub_1524  -11
    visit_2_20  service_visit_def_1525  -1
    order_2_20  connected_order_arc_1245  1
    order_2_20  connected_order_arc_1266  1
    order_2_20  connected_order_arc_1287  1
    order_2_20  connected_order_arc_1308  1
    order_2_20  connected_order_arc_1329  1
    order_2_20  connected_order_arc_1350  1
    order_2_20  connected_order_arc_1371  1
    order_2_20  connected_order_arc_1392  1
    order_2_20  connected_order_arc_1413  1
    order_2_20  connected_order_arc_1434  1
    order_2_20  connected_order_arc_1437  -1
    order_2_20  connected_order_arc_1439  -1
    order_2_20  connected_order_arc_1441  -1
    order_2_20  connected_order_arc_1443  -1
    order_2_20  connected_order_arc_1445  -1
    order_2_20  connected_order_arc_1447  -1
    order_2_20  connected_order_arc_1449  -1
    order_2_20  connected_order_arc_1451  -1
    order_2_20  connected_order_arc_1453  -1
    order_2_20  connected_order_arc_1455  -1
    order_2_20  order_active_lb_1523  1
    order_2_20  order_active_ub_1524  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_0  arc_capacity_1213  -30
    arc_2_0_0  depot_departure_or_bypass_1456  1
    arc_2_0_0  depot_return_or_bypass_1457  1
    MARKER    'MARKER'                 'INTEND'
    load_2_0_0  arc_capacity_1213  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_10  arc_capacity_1214  -30
    arc_2_0_10  depot_departure_or_bypass_1456  1
    arc_2_0_10  in_degree_1459  1
    arc_2_0_10  original_T_including_depot_unload_1529  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_10  arc_capacity_1214  1
    load_2_0_10  segment_load_conservation_1462  -1
    load_2_0_10  segment_prefix_lb_1463  1
    load_2_0_10  segment_prefix_ub_1464  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_11  arc_capacity_1215  -30
    arc_2_0_11  depot_departure_or_bypass_1456  1
    arc_2_0_11  in_degree_1466  1
    arc_2_0_11  original_T_including_depot_unload_1529  1.2898901502795654e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_11  arc_capacity_1215  1
    load_2_0_11  segment_load_conservation_1469  -1
    load_2_0_11  segment_prefix_lb_1470  1
    load_2_0_11  segment_prefix_ub_1471  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_12  arc_capacity_1216  -30
    arc_2_0_12  depot_departure_or_bypass_1456  1
    arc_2_0_12  in_degree_1473  1
    arc_2_0_12  original_T_including_depot_unload_1529  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_12  arc_capacity_1216  1
    load_2_0_12  segment_load_conservation_1476  -1
    load_2_0_12  segment_prefix_lb_1477  1
    load_2_0_12  segment_prefix_ub_1478  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_13  arc_capacity_1217  -30
    arc_2_0_13  depot_departure_or_bypass_1456  1
    arc_2_0_13  in_degree_1480  1
    arc_2_0_13  original_T_including_depot_unload_1529  1.2751323166566442e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_13  arc_capacity_1217  1
    load_2_0_13  free_load_conservation_1484  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_14  arc_capacity_1218  -30
    arc_2_0_14  depot_departure_or_bypass_1456  1
    arc_2_0_14  in_degree_1486  1
    arc_2_0_14  original_T_including_depot_unload_1529  1.3076700111397606e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_14  arc_capacity_1218  1
    load_2_0_14  free_load_conservation_1490  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_15  arc_capacity_1219  -30
    arc_2_0_15  depot_departure_or_bypass_1456  1
    arc_2_0_15  in_degree_1492  1
    arc_2_0_15  original_T_including_depot_unload_1529  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_15  arc_capacity_1219  1
    load_2_0_15  free_load_conservation_1496  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_16  arc_capacity_1220  -30
    arc_2_0_16  depot_departure_or_bypass_1456  1
    arc_2_0_16  in_degree_1498  1
    arc_2_0_16  original_T_including_depot_unload_1529  1.0088905112952611e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_16  arc_capacity_1220  1
    load_2_0_16  free_load_conservation_1502  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_17  arc_capacity_1221  -30
    arc_2_0_17  depot_departure_or_bypass_1456  1
    arc_2_0_17  in_degree_1504  1
    arc_2_0_17  original_T_including_depot_unload_1529  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_17  arc_capacity_1221  1
    load_2_0_17  free_load_conservation_1508  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_18  arc_capacity_1222  -30
    arc_2_0_18  depot_departure_or_bypass_1456  1
    arc_2_0_18  in_degree_1510  1
    arc_2_0_18  original_T_including_depot_unload_1529  8.7749189782983967e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_18  arc_capacity_1222  1
    load_2_0_18  free_load_conservation_1514  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_19  arc_capacity_1223  -30
    arc_2_0_19  depot_departure_or_bypass_1456  1
    arc_2_0_19  in_degree_1516  1
    arc_2_0_19  original_T_including_depot_unload_1529  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_19  arc_capacity_1223  1
    load_2_0_19  free_load_conservation_1520  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_20  arc_capacity_1224  -30
    arc_2_0_20  depot_departure_or_bypass_1456  1
    arc_2_0_20  in_degree_1522  1
    arc_2_0_20  original_T_including_depot_unload_1529  1.0479182987243917e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_20  arc_capacity_1224  1
    load_2_0_20  free_load_conservation_1526  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_0  arc_capacity_1225  -30
    arc_2_10_0  depot_return_or_bypass_1457  1
    arc_2_10_0  out_degree_1458  1
    arc_2_10_0  original_T_including_depot_unload_1529  9.5330620720858735e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_0  arc_capacity_1225  1
    load_2_10_0  segment_load_conservation_1462  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_11  arc_capacity_1226  -30
    arc_2_10_11  connected_order_arc_1227  -12
    arc_2_10_11  out_degree_1458  1
    arc_2_10_11  in_degree_1466  1
    arc_2_10_11  original_T_including_depot_unload_1529  1.5797541979515834e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_11  arc_capacity_1226  1
    load_2_10_11  segment_load_conservation_1462  1
    load_2_10_11  segment_load_conservation_1469  -1
    load_2_10_11  segment_prefix_lb_1470  1
    load_2_10_11  segment_prefix_ub_1471  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_12  arc_capacity_1228  -30
    arc_2_10_12  connected_order_arc_1229  -12
    arc_2_10_12  out_degree_1458  1
    arc_2_10_12  in_degree_1473  1
    arc_2_10_12  original_T_including_depot_unload_1529  1.0783470469841145e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_12  arc_capacity_1228  1
    load_2_10_12  segment_load_conservation_1462  1
    load_2_10_12  segment_load_conservation_1476  -1
    load_2_10_12  segment_prefix_lb_1477  1
    load_2_10_12  segment_prefix_ub_1478  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_13  arc_capacity_1230  -30
    arc_2_10_13  connected_order_arc_1231  -12
    arc_2_10_13  out_degree_1458  1
    arc_2_10_13  in_degree_1480  1
    arc_2_10_13  original_T_including_depot_unload_1529  2.1849202034001414e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_13  arc_capacity_1230  1
    load_2_10_13  segment_load_conservation_1462  1
    load_2_10_13  free_load_conservation_1484  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_14  arc_capacity_1232  -30
    arc_2_10_14  connected_order_arc_1233  -12
    arc_2_10_14  out_degree_1458  1
    arc_2_10_14  in_degree_1486  1
    arc_2_10_14  original_T_including_depot_unload_1529  2.1777161911815579e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_14  arc_capacity_1232  1
    load_2_10_14  segment_load_conservation_1462  1
    load_2_10_14  free_load_conservation_1490  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_15  arc_capacity_1234  -30
    arc_2_10_15  connected_order_arc_1235  -12
    arc_2_10_15  out_degree_1458  1
    arc_2_10_15  in_degree_1492  1
    arc_2_10_15  original_T_including_depot_unload_1529  1.9462564869425171e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_15  arc_capacity_1234  1
    load_2_10_15  segment_load_conservation_1462  1
    load_2_10_15  free_load_conservation_1496  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_16  arc_capacity_1236  -30
    arc_2_10_16  connected_order_arc_1237  -12
    arc_2_10_16  out_degree_1458  1
    arc_2_10_16  in_degree_1498  1
    arc_2_10_16  original_T_including_depot_unload_1529  1.9482201819157062e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_16  arc_capacity_1236  1
    load_2_10_16  segment_load_conservation_1462  1
    load_2_10_16  free_load_conservation_1502  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_17  arc_capacity_1238  -30
    arc_2_10_17  connected_order_arc_1239  -12
    arc_2_10_17  out_degree_1458  1
    arc_2_10_17  in_degree_1504  1
    arc_2_10_17  original_T_including_depot_unload_1529  1.5117151439160034e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_17  arc_capacity_1238  1
    load_2_10_17  segment_load_conservation_1462  1
    load_2_10_17  free_load_conservation_1508  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_18  arc_capacity_1240  -30
    arc_2_10_18  connected_order_arc_1241  -12
    arc_2_10_18  out_degree_1458  1
    arc_2_10_18  in_degree_1510  1
    arc_2_10_18  original_T_including_depot_unload_1529  1.8269270746185791e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_18  arc_capacity_1240  1
    load_2_10_18  segment_load_conservation_1462  1
    load_2_10_18  free_load_conservation_1514  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_19  arc_capacity_1242  -30
    arc_2_10_19  connected_order_arc_1243  -12
    arc_2_10_19  out_degree_1458  1
    arc_2_10_19  in_degree_1516  1
    arc_2_10_19  original_T_including_depot_unload_1529  1.0105932041904148e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_19  arc_capacity_1242  1
    load_2_10_19  segment_load_conservation_1462  1
    load_2_10_19  free_load_conservation_1520  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_20  arc_capacity_1244  -30
    arc_2_10_20  connected_order_arc_1245  -12
    arc_2_10_20  out_degree_1458  1
    arc_2_10_20  in_degree_1522  1
    arc_2_10_20  original_T_including_depot_unload_1529  1.9981042624472673e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_20  arc_capacity_1244  1
    load_2_10_20  segment_load_conservation_1462  1
    load_2_10_20  free_load_conservation_1526  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_0  arc_capacity_1246  -30
    arc_2_11_0  depot_return_or_bypass_1457  1
    arc_2_11_0  out_degree_1465  1
    arc_2_11_0  original_T_including_depot_unload_1529  1.4567038050199781e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_0  arc_capacity_1246  1
    load_2_11_0  segment_load_conservation_1469  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_10  arc_capacity_1247  -30
    arc_2_11_10  connected_order_arc_1248  -12
    arc_2_11_10  in_degree_1459  1
    arc_2_11_10  out_degree_1465  1
    arc_2_11_10  original_T_including_depot_unload_1529  1.2835993572680911e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_10  arc_capacity_1247  1
    load_2_11_10  segment_load_conservation_1462  -1
    load_2_11_10  segment_prefix_lb_1463  1
    load_2_11_10  segment_prefix_ub_1464  1
    load_2_11_10  segment_load_conservation_1469  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_12  arc_capacity_1249  -30
    arc_2_11_12  connected_order_arc_1250  -12
    arc_2_11_12  out_degree_1465  1
    arc_2_11_12  in_degree_1473  1
    arc_2_11_12  original_T_including_depot_unload_1529  1.4472076573979532e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_12  arc_capacity_1249  1
    load_2_11_12  segment_load_conservation_1469  1
    load_2_11_12  segment_load_conservation_1476  -1
    load_2_11_12  segment_prefix_lb_1477  1
    load_2_11_12  segment_prefix_ub_1478  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_13  arc_capacity_1251  -30
    arc_2_11_13  connected_order_arc_1252  -12
    arc_2_11_13  out_degree_1465  1
    arc_2_11_13  in_degree_1480  1
    arc_2_11_13  original_T_including_depot_unload_1529  2.2638184459267368e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_13  arc_capacity_1251  1
    load_2_11_13  segment_load_conservation_1469  1
    load_2_11_13  free_load_conservation_1484  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_14  arc_capacity_1253  -30
    arc_2_11_14  connected_order_arc_1254  -12
    arc_2_11_14  out_degree_1465  1
    arc_2_11_14  in_degree_1486  1
    arc_2_11_14  original_T_including_depot_unload_1529  2.4002470706280069e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_14  arc_capacity_1253  1
    load_2_11_14  segment_load_conservation_1469  1
    load_2_11_14  free_load_conservation_1490  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_15  arc_capacity_1255  -30
    arc_2_11_15  connected_order_arc_1256  -12
    arc_2_11_15  out_degree_1465  1
    arc_2_11_15  in_degree_1492  1
    arc_2_11_15  original_T_including_depot_unload_1529  1.2027697073878232e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_15  arc_capacity_1255  1
    load_2_11_15  segment_load_conservation_1469  1
    load_2_11_15  free_load_conservation_1496  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_16  arc_capacity_1257  -30
    arc_2_11_16  connected_order_arc_1258  -12
    arc_2_11_16  out_degree_1465  1
    arc_2_11_16  in_degree_1498  1
    arc_2_11_16  original_T_including_depot_unload_1529  1.9434430494183746e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_16  arc_capacity_1257  1
    load_2_11_16  segment_load_conservation_1469  1
    load_2_11_16  free_load_conservation_1502  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_17  arc_capacity_1259  -30
    arc_2_11_17  connected_order_arc_1260  -12
    arc_2_11_17  out_degree_1465  1
    arc_2_11_17  in_degree_1504  1
    arc_2_11_17  original_T_including_depot_unload_1529  3.1118349756671438e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_17  arc_capacity_1259  1
    load_2_11_17  segment_load_conservation_1469  1
    load_2_11_17  free_load_conservation_1508  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_18  arc_capacity_1261  -30
    arc_2_11_18  connected_order_arc_1262  -12
    arc_2_11_18  out_degree_1465  1
    arc_2_11_18  in_degree_1510  1
    arc_2_11_18  original_T_including_depot_unload_1529  1.7809992976396034e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_18  arc_capacity_1261  1
    load_2_11_18  segment_load_conservation_1469  1
    load_2_11_18  free_load_conservation_1514  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_19  arc_capacity_1263  -30
    arc_2_11_19  connected_order_arc_1264  -12
    arc_2_11_19  out_degree_1465  1
    arc_2_11_19  in_degree_1516  1
    arc_2_11_19  original_T_including_depot_unload_1529  8.0219422833177862e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_19  arc_capacity_1263  1
    load_2_11_19  segment_load_conservation_1469  1
    load_2_11_19  free_load_conservation_1520  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_20  arc_capacity_1265  -30
    arc_2_11_20  connected_order_arc_1266  -12
    arc_2_11_20  out_degree_1465  1
    arc_2_11_20  in_degree_1522  1
    arc_2_11_20  original_T_including_depot_unload_1529  1.6785246977297163e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_20  arc_capacity_1265  1
    load_2_11_20  segment_load_conservation_1469  1
    load_2_11_20  free_load_conservation_1526  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_0  arc_capacity_1267  -30
    arc_2_12_0  depot_return_or_bypass_1457  1
    arc_2_12_0  out_degree_1472  1
    arc_2_12_0  original_T_including_depot_unload_1529  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_0  arc_capacity_1267  1
    load_2_12_0  segment_load_conservation_1476  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_10  arc_capacity_1268  -30
    arc_2_12_10  connected_order_arc_1269  -12
    arc_2_12_10  in_degree_1459  1
    arc_2_12_10  out_degree_1472  1
    arc_2_12_10  original_T_including_depot_unload_1529  359.975566576564
    MARKER    'MARKER'                 'INTEND'
    load_2_12_10  arc_capacity_1268  1
    load_2_12_10  segment_load_conservation_1462  -1
    load_2_12_10  segment_prefix_lb_1463  1
    load_2_12_10  segment_prefix_ub_1464  1
    load_2_12_10  segment_load_conservation_1476  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_11  arc_capacity_1270  -30
    arc_2_12_11  connected_order_arc_1271  -12
    arc_2_12_11  in_degree_1466  1
    arc_2_12_11  out_degree_1472  1
    arc_2_12_11  original_T_including_depot_unload_1529  1.2875945644569279e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_11  arc_capacity_1270  1
    load_2_12_11  segment_load_conservation_1469  -1
    load_2_12_11  segment_prefix_lb_1470  1
    load_2_12_11  segment_prefix_ub_1471  1
    load_2_12_11  segment_load_conservation_1476  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_13  arc_capacity_1272  -30
    arc_2_12_13  connected_order_arc_1273  -12
    arc_2_12_13  out_degree_1472  1
    arc_2_12_13  in_degree_1480  1
    arc_2_12_13  original_T_including_depot_unload_1529  1.1663816070445826e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_13  arc_capacity_1272  1
    load_2_12_13  segment_load_conservation_1476  1
    load_2_12_13  free_load_conservation_1484  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_14  arc_capacity_1274  -30
    arc_2_12_14  connected_order_arc_1275  -12
    arc_2_12_14  out_degree_1472  1
    arc_2_12_14  in_degree_1486  1
    arc_2_12_14  original_T_including_depot_unload_1529  1.2100678255370710e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_14  arc_capacity_1274  1
    load_2_12_14  segment_load_conservation_1476  1
    load_2_12_14  free_load_conservation_1490  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_15  arc_capacity_1276  -30
    arc_2_12_15  connected_order_arc_1277  -12
    arc_2_12_15  out_degree_1472  1
    arc_2_12_15  in_degree_1492  1
    arc_2_12_15  original_T_including_depot_unload_1529  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_15  arc_capacity_1276  1
    load_2_12_15  segment_load_conservation_1476  1
    load_2_12_15  free_load_conservation_1496  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_16  arc_capacity_1278  -30
    arc_2_12_16  connected_order_arc_1279  -12
    arc_2_12_16  out_degree_1472  1
    arc_2_12_16  in_degree_1498  1
    arc_2_12_16  original_T_including_depot_unload_1529  8.9135689158237335e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_16  arc_capacity_1278  1
    load_2_12_16  segment_load_conservation_1476  1
    load_2_12_16  free_load_conservation_1502  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_17  arc_capacity_1280  -30
    arc_2_12_17  connected_order_arc_1281  -12
    arc_2_12_17  out_degree_1472  1
    arc_2_12_17  in_degree_1504  1
    arc_2_12_17  original_T_including_depot_unload_1529  1.3857128117205509e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_17  arc_capacity_1280  1
    load_2_12_17  segment_load_conservation_1476  1
    load_2_12_17  free_load_conservation_1508  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_18  arc_capacity_1282  -30
    arc_2_12_18  connected_order_arc_1283  -12
    arc_2_12_18  out_degree_1472  1
    arc_2_12_18  in_degree_1510  1
    arc_2_12_18  original_T_including_depot_unload_1529  7.5571464781430223e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_18  arc_capacity_1282  1
    load_2_12_18  segment_load_conservation_1476  1
    load_2_12_18  free_load_conservation_1514  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_19  arc_capacity_1284  -30
    arc_2_12_19  connected_order_arc_1285  -12
    arc_2_12_19  out_degree_1472  1
    arc_2_12_19  in_degree_1516  1
    arc_2_12_19  original_T_including_depot_unload_1529  7.6275540057842773e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_19  arc_capacity_1284  1
    load_2_12_19  segment_load_conservation_1476  1
    load_2_12_19  free_load_conservation_1520  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_20  arc_capacity_1286  -30
    arc_2_12_20  connected_order_arc_1287  -12
    arc_2_12_20  out_degree_1472  1
    arc_2_12_20  in_degree_1522  1
    arc_2_12_20  original_T_including_depot_unload_1529  9.2235470209829464e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_20  arc_capacity_1286  1
    load_2_12_20  segment_load_conservation_1476  1
    load_2_12_20  free_load_conservation_1526  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_0  arc_capacity_1288  -30
    arc_2_13_0  depot_return_or_bypass_1457  1
    arc_2_13_0  out_degree_1479  1
    arc_2_13_0  original_T_including_depot_unload_1529  1.2751323166566442e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_0  arc_capacity_1288  1
    load_2_13_0  free_load_conservation_1484  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_10  arc_capacity_1289  -30
    arc_2_13_10  connected_order_arc_1290  -12
    arc_2_13_10  in_degree_1459  1
    arc_2_13_10  out_degree_1479  1
    arc_2_13_10  original_T_including_depot_unload_1529  1.5257079162357311e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_10  arc_capacity_1289  1
    load_2_13_10  segment_load_conservation_1462  -1
    load_2_13_10  segment_prefix_lb_1463  1
    load_2_13_10  segment_prefix_ub_1464  1
    load_2_13_10  free_load_conservation_1484  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_11  arc_capacity_1291  -30
    arc_2_13_11  connected_order_arc_1292  -12
    arc_2_13_11  in_degree_1466  1
    arc_2_13_11  out_degree_1479  1
    arc_2_13_11  original_T_including_depot_unload_1529  2.1599714728425283e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_11  arc_capacity_1291  1
    load_2_13_11  segment_load_conservation_1469  -1
    load_2_13_11  segment_prefix_lb_1470  1
    load_2_13_11  segment_prefix_ub_1471  1
    load_2_13_11  free_load_conservation_1484  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_12  arc_capacity_1293  -30
    arc_2_13_12  connected_order_arc_1294  -12
    arc_2_13_12  in_degree_1473  1
    arc_2_13_12  out_degree_1479  1
    arc_2_13_12  original_T_including_depot_unload_1529  1.1663816070445826e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_12  arc_capacity_1293  1
    load_2_13_12  segment_load_conservation_1476  -1
    load_2_13_12  segment_prefix_lb_1477  1
    load_2_13_12  segment_prefix_ub_1478  1
    load_2_13_12  free_load_conservation_1484  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_14  arc_capacity_1295  -30
    arc_2_13_14  connected_order_arc_1296  -12
    arc_2_13_14  out_degree_1479  1
    arc_2_13_14  in_degree_1486  1
    arc_2_13_14  original_T_including_depot_unload_1529  1.9785969874636677e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_14  arc_capacity_1295  1
    load_2_13_14  free_load_conservation_1484  1
    load_2_13_14  free_load_conservation_1490  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_15  arc_capacity_1297  -30
    arc_2_13_15  connected_order_arc_1298  -12
    arc_2_13_15  out_degree_1479  1
    arc_2_13_15  in_degree_1492  1
    arc_2_13_15  original_T_including_depot_unload_1529  1.1499210972200315e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_15  arc_capacity_1297  1
    load_2_13_15  free_load_conservation_1484  1
    load_2_13_15  free_load_conservation_1496  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_16  arc_capacity_1299  -30
    arc_2_13_16  connected_order_arc_1300  -12
    arc_2_13_16  out_degree_1479  1
    arc_2_13_16  in_degree_1498  1
    arc_2_13_16  original_T_including_depot_unload_1529  3.2286832955801827e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_16  arc_capacity_1299  1
    load_2_13_16  free_load_conservation_1484  1
    load_2_13_16  free_load_conservation_1502  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_17  arc_capacity_1301  -30
    arc_2_13_17  connected_order_arc_1302  -12
    arc_2_13_17  out_degree_1479  1
    arc_2_13_17  in_degree_1504  1
    arc_2_13_17  original_T_including_depot_unload_1529  2.3332890980657526e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_17  arc_capacity_1301  1
    load_2_13_17  free_load_conservation_1484  1
    load_2_13_17  free_load_conservation_1508  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_18  arc_capacity_1303  -30
    arc_2_13_18  connected_order_arc_1304  -12
    arc_2_13_18  out_degree_1479  1
    arc_2_13_18  in_degree_1510  1
    arc_2_13_18  original_T_including_depot_unload_1529  4.8905010520753694e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_18  arc_capacity_1303  1
    load_2_13_18  free_load_conservation_1484  1
    load_2_13_18  free_load_conservation_1514  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_19  arc_capacity_1305  -30
    arc_2_13_19  connected_order_arc_1306  -12
    arc_2_13_19  out_degree_1479  1
    arc_2_13_19  in_degree_1516  1
    arc_2_13_19  original_T_including_depot_unload_1529  1.8319650761318992e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_19  arc_capacity_1305  1
    load_2_13_19  free_load_conservation_1484  1
    load_2_13_19  free_load_conservation_1520  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_20  arc_capacity_1307  -30
    arc_2_13_20  connected_order_arc_1308  -12
    arc_2_13_20  out_degree_1479  1
    arc_2_13_20  in_degree_1522  1
    arc_2_13_20  original_T_including_depot_unload_1529  6.2793211180612207e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_20  arc_capacity_1307  1
    load_2_13_20  free_load_conservation_1484  1
    load_2_13_20  free_load_conservation_1526  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_0  arc_capacity_1309  -30
    arc_2_14_0  depot_return_or_bypass_1457  1
    arc_2_14_0  out_degree_1485  1
    arc_2_14_0  original_T_including_depot_unload_1529  1.3076700111397606e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_0  arc_capacity_1309  1
    load_2_14_0  free_load_conservation_1490  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_10  arc_capacity_1310  -30
    arc_2_14_10  connected_order_arc_1311  -12
    arc_2_14_10  in_degree_1459  1
    arc_2_14_10  out_degree_1485  1
    arc_2_14_10  original_T_including_depot_unload_1529  1.5688206371681019e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_10  arc_capacity_1310  1
    load_2_14_10  segment_load_conservation_1462  -1
    load_2_14_10  segment_prefix_lb_1463  1
    load_2_14_10  segment_prefix_ub_1464  1
    load_2_14_10  free_load_conservation_1490  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_11  arc_capacity_1312  -30
    arc_2_14_11  connected_order_arc_1313  -12
    arc_2_14_11  in_degree_1466  1
    arc_2_14_11  out_degree_1485  1
    arc_2_14_11  original_T_including_depot_unload_1529  2.2869898621431917e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_11  arc_capacity_1312  1
    load_2_14_11  segment_load_conservation_1469  -1
    load_2_14_11  segment_prefix_lb_1470  1
    load_2_14_11  segment_prefix_ub_1471  1
    load_2_14_11  free_load_conservation_1490  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_12  arc_capacity_1314  -30
    arc_2_14_12  connected_order_arc_1315  -12
    arc_2_14_12  in_degree_1473  1
    arc_2_14_12  out_degree_1485  1
    arc_2_14_12  original_T_including_depot_unload_1529  1.2100678255370710e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_12  arc_capacity_1314  1
    load_2_14_12  segment_load_conservation_1476  -1
    load_2_14_12  segment_prefix_lb_1477  1
    load_2_14_12  segment_prefix_ub_1478  1
    load_2_14_12  free_load_conservation_1490  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_13  arc_capacity_1316  -30
    arc_2_14_13  connected_order_arc_1317  -12
    arc_2_14_13  in_degree_1480  1
    arc_2_14_13  out_degree_1485  1
    arc_2_14_13  original_T_including_depot_unload_1529  1.9785969874636677e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_13  arc_capacity_1316  1
    load_2_14_13  free_load_conservation_1484  -1
    load_2_14_13  free_load_conservation_1490  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_15  arc_capacity_1318  -30
    arc_2_14_15  connected_order_arc_1319  -12
    arc_2_14_15  out_degree_1485  1
    arc_2_14_15  in_degree_1492  1
    arc_2_14_15  original_T_including_depot_unload_1529  1.3218357148919101e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_15  arc_capacity_1318  1
    load_2_14_15  free_load_conservation_1490  1
    load_2_14_15  free_load_conservation_1496  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_16  arc_capacity_1320  -30
    arc_2_14_16  connected_order_arc_1321  -12
    arc_2_14_16  out_degree_1485  1
    arc_2_14_16  in_degree_1498  1
    arc_2_14_16  original_T_including_depot_unload_1529  4.6588884124393707e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_16  arc_capacity_1320  1
    load_2_14_16  free_load_conservation_1490  1
    load_2_14_16  free_load_conservation_1502  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_17  arc_capacity_1322  -30
    arc_2_14_17  connected_order_arc_1323  -12
    arc_2_14_17  out_degree_1485  1
    arc_2_14_17  in_degree_1504  1
    arc_2_14_17  original_T_including_depot_unload_1529  2.4500766064196278e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_17  arc_capacity_1322  1
    load_2_14_17  free_load_conservation_1490  1
    load_2_14_17  free_load_conservation_1508  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_18  arc_capacity_1324  -30
    arc_2_14_18  connected_order_arc_1325  -12
    arc_2_14_18  out_degree_1485  1
    arc_2_14_18  in_degree_1510  1
    arc_2_14_18  original_T_including_depot_unload_1529  6.2102815646279714e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_18  arc_capacity_1324  1
    load_2_14_18  free_load_conservation_1490  1
    load_2_14_18  free_load_conservation_1514  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_19  arc_capacity_1326  -30
    arc_2_14_19  connected_order_arc_1327  -12
    arc_2_14_19  out_degree_1485  1
    arc_2_14_19  in_degree_1516  1
    arc_2_14_19  original_T_including_depot_unload_1529  1.9170200697382236e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_19  arc_capacity_1326  1
    load_2_14_19  free_load_conservation_1490  1
    load_2_14_19  free_load_conservation_1520  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_20  arc_capacity_1328  -30
    arc_2_14_20  connected_order_arc_1329  -12
    arc_2_14_20  out_degree_1485  1
    arc_2_14_20  in_degree_1522  1
    arc_2_14_20  original_T_including_depot_unload_1529  8.0531033344008677e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_20  arc_capacity_1328  1
    load_2_14_20  free_load_conservation_1490  1
    load_2_14_20  free_load_conservation_1526  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_0  arc_capacity_1330  -30
    arc_2_15_0  depot_return_or_bypass_1457  1
    arc_2_15_0  out_degree_1491  1
    arc_2_15_0  original_T_including_depot_unload_1529  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_0  arc_capacity_1330  1
    load_2_15_0  free_load_conservation_1496  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_10  arc_capacity_1331  -30
    arc_2_15_10  connected_order_arc_1332  -12
    arc_2_15_10  in_degree_1459  1
    arc_2_15_10  out_degree_1491  1
    arc_2_15_10  original_T_including_depot_unload_1529  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_10  arc_capacity_1331  1
    load_2_15_10  segment_load_conservation_1462  -1
    load_2_15_10  segment_prefix_lb_1463  1
    load_2_15_10  segment_prefix_ub_1464  1
    load_2_15_10  free_load_conservation_1496  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_11  arc_capacity_1333  -30
    arc_2_15_11  connected_order_arc_1334  -12
    arc_2_15_11  in_degree_1466  1
    arc_2_15_11  out_degree_1491  1
    arc_2_15_11  original_T_including_depot_unload_1529  1.1490429395374924e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_11  arc_capacity_1333  1
    load_2_15_11  segment_load_conservation_1469  -1
    load_2_15_11  segment_prefix_lb_1470  1
    load_2_15_11  segment_prefix_ub_1471  1
    load_2_15_11  free_load_conservation_1496  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_12  arc_capacity_1335  -30
    arc_2_15_12  connected_order_arc_1336  -12
    arc_2_15_12  in_degree_1473  1
    arc_2_15_12  out_degree_1491  1
    arc_2_15_12  original_T_including_depot_unload_1529  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_12  arc_capacity_1335  1
    load_2_15_12  segment_load_conservation_1476  -1
    load_2_15_12  segment_prefix_lb_1477  1
    load_2_15_12  segment_prefix_ub_1478  1
    load_2_15_12  free_load_conservation_1496  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_13  arc_capacity_1337  -30
    arc_2_15_13  connected_order_arc_1338  -12
    arc_2_15_13  in_degree_1480  1
    arc_2_15_13  out_degree_1491  1
    arc_2_15_13  original_T_including_depot_unload_1529  1.1499210972200315e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_13  arc_capacity_1337  1
    load_2_15_13  free_load_conservation_1484  -1
    load_2_15_13  free_load_conservation_1496  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_14  arc_capacity_1339  -30
    arc_2_15_14  connected_order_arc_1340  -12
    arc_2_15_14  in_degree_1486  1
    arc_2_15_14  out_degree_1491  1
    arc_2_15_14  original_T_including_depot_unload_1529  1.3218357148919101e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_14  arc_capacity_1339  1
    load_2_15_14  free_load_conservation_1490  -1
    load_2_15_14  free_load_conservation_1496  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_16  arc_capacity_1341  -30
    arc_2_15_16  connected_order_arc_1342  -12
    arc_2_15_16  out_degree_1491  1
    arc_2_15_16  in_degree_1498  1
    arc_2_15_16  original_T_including_depot_unload_1529  861.314419336229
    MARKER    'MARKER'                 'INTEND'
    load_2_15_16  arc_capacity_1341  1
    load_2_15_16  free_load_conservation_1496  1
    load_2_15_16  free_load_conservation_1502  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_17  arc_capacity_1343  -30
    arc_2_15_17  connected_order_arc_1344  -12
    arc_2_15_17  out_degree_1491  1
    arc_2_15_17  in_degree_1504  1
    arc_2_15_17  original_T_including_depot_unload_1529  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_17  arc_capacity_1343  1
    load_2_15_17  free_load_conservation_1496  1
    load_2_15_17  free_load_conservation_1508  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_18  arc_capacity_1345  -30
    arc_2_15_18  connected_order_arc_1346  -12
    arc_2_15_18  out_degree_1491  1
    arc_2_15_18  in_degree_1510  1
    arc_2_15_18  original_T_including_depot_unload_1529  7.3227602527872671e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_18  arc_capacity_1345  1
    load_2_15_18  free_load_conservation_1496  1
    load_2_15_18  free_load_conservation_1514  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_19  arc_capacity_1347  -30
    arc_2_15_19  connected_order_arc_1348  -12
    arc_2_15_19  out_degree_1491  1
    arc_2_15_19  in_degree_1516  1
    arc_2_15_19  original_T_including_depot_unload_1529  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_19  arc_capacity_1347  1
    load_2_15_19  free_load_conservation_1496  1
    load_2_15_19  free_load_conservation_1520  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_20  arc_capacity_1349  -30
    arc_2_15_20  connected_order_arc_1350  -12
    arc_2_15_20  out_degree_1491  1
    arc_2_15_20  in_degree_1522  1
    arc_2_15_20  original_T_including_depot_unload_1529  5.2280951376932137e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_20  arc_capacity_1349  1
    load_2_15_20  free_load_conservation_1496  1
    load_2_15_20  free_load_conservation_1526  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_0  arc_capacity_1351  -30
    arc_2_16_0  depot_return_or_bypass_1457  1
    arc_2_16_0  out_degree_1497  1
    arc_2_16_0  original_T_including_depot_unload_1529  1.0088905112952611e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_0  arc_capacity_1351  1
    load_2_16_0  free_load_conservation_1502  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_10  arc_capacity_1352  -30
    arc_2_16_10  connected_order_arc_1353  -12
    arc_2_16_10  in_degree_1459  1
    arc_2_16_10  out_degree_1497  1
    arc_2_16_10  original_T_including_depot_unload_1529  1.2442780266664952e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_10  arc_capacity_1352  1
    load_2_16_10  segment_load_conservation_1462  -1
    load_2_16_10  segment_prefix_lb_1463  1
    load_2_16_10  segment_prefix_ub_1464  1
    load_2_16_10  free_load_conservation_1502  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_11  arc_capacity_1354  -30
    arc_2_16_11  connected_order_arc_1355  -12
    arc_2_16_11  in_degree_1466  1
    arc_2_16_11  out_degree_1497  1
    arc_2_16_11  original_T_including_depot_unload_1529  1.8375396100269363e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_11  arc_capacity_1354  1
    load_2_16_11  segment_load_conservation_1469  -1
    load_2_16_11  segment_prefix_lb_1470  1
    load_2_16_11  segment_prefix_ub_1471  1
    load_2_16_11  free_load_conservation_1502  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_12  arc_capacity_1356  -30
    arc_2_16_12  connected_order_arc_1357  -12
    arc_2_16_12  in_degree_1473  1
    arc_2_16_12  out_degree_1497  1
    arc_2_16_12  original_T_including_depot_unload_1529  8.9135689158237335e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_12  arc_capacity_1356  1
    load_2_16_12  segment_load_conservation_1476  -1
    load_2_16_12  segment_prefix_lb_1477  1
    load_2_16_12  segment_prefix_ub_1478  1
    load_2_16_12  free_load_conservation_1502  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_13  arc_capacity_1358  -30
    arc_2_16_13  connected_order_arc_1359  -12
    arc_2_16_13  in_degree_1480  1
    arc_2_16_13  out_degree_1497  1
    arc_2_16_13  original_T_including_depot_unload_1529  3.2286832955801827e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_13  arc_capacity_1358  1
    load_2_16_13  free_load_conservation_1484  -1
    load_2_16_13  free_load_conservation_1502  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_14  arc_capacity_1360  -30
    arc_2_16_14  connected_order_arc_1361  -12
    arc_2_16_14  in_degree_1486  1
    arc_2_16_14  out_degree_1497  1
    arc_2_16_14  original_T_including_depot_unload_1529  4.6588884124393707e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_14  arc_capacity_1360  1
    load_2_16_14  free_load_conservation_1490  -1
    load_2_16_14  free_load_conservation_1502  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_15  arc_capacity_1362  -30
    arc_2_16_15  connected_order_arc_1363  -12
    arc_2_16_15  in_degree_1492  1
    arc_2_16_15  out_degree_1497  1
    arc_2_16_15  original_T_including_depot_unload_1529  861.314419336229
    MARKER    'MARKER'                 'INTEND'
    load_2_16_15  arc_capacity_1362  1
    load_2_16_15  free_load_conservation_1496  -1
    load_2_16_15  free_load_conservation_1502  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_17  arc_capacity_1364  -30
    arc_2_16_17  connected_order_arc_1365  -12
    arc_2_16_17  out_degree_1497  1
    arc_2_16_17  in_degree_1504  1
    arc_2_16_17  original_T_including_depot_unload_1529  2.0104743468619281e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_17  arc_capacity_1364  1
    load_2_16_17  free_load_conservation_1502  1
    load_2_16_17  free_load_conservation_1508  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_18  arc_capacity_1366  -30
    arc_2_16_18  connected_order_arc_1367  -12
    arc_2_16_18  out_degree_1497  1
    arc_2_16_18  in_degree_1510  1
    arc_2_16_18  original_T_including_depot_unload_1529  1.6651295535886251e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_18  arc_capacity_1366  1
    load_2_16_18  free_load_conservation_1502  1
    load_2_16_18  free_load_conservation_1514  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_19  arc_capacity_1368  -30
    arc_2_16_19  connected_order_arc_1369  -12
    arc_2_16_19  out_degree_1497  1
    arc_2_16_19  in_degree_1516  1
    arc_2_16_19  original_T_including_depot_unload_1529  1.5183735648810946e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_19  arc_capacity_1368  1
    load_2_16_19  free_load_conservation_1502  1
    load_2_16_19  free_load_conservation_1520  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_20  arc_capacity_1370  -30
    arc_2_16_20  connected_order_arc_1371  -12
    arc_2_16_20  out_degree_1497  1
    arc_2_16_20  in_degree_1522  1
    arc_2_16_20  original_T_including_depot_unload_1529  3.6094216796124527e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_20  arc_capacity_1370  1
    load_2_16_20  free_load_conservation_1502  1
    load_2_16_20  free_load_conservation_1526  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_0  arc_capacity_1372  -30
    arc_2_17_0  depot_return_or_bypass_1457  1
    arc_2_17_0  out_degree_1503  1
    arc_2_17_0  original_T_including_depot_unload_1529  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_0  arc_capacity_1372  1
    load_2_17_0  free_load_conservation_1508  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_10  arc_capacity_1373  -30
    arc_2_17_10  connected_order_arc_1374  -12
    arc_2_17_10  in_degree_1459  1
    arc_2_17_10  out_degree_1503  1
    arc_2_17_10  original_T_including_depot_unload_1529  1.1544376314422677e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_10  arc_capacity_1373  1
    load_2_17_10  segment_load_conservation_1462  -1
    load_2_17_10  segment_prefix_lb_1463  1
    load_2_17_10  segment_prefix_ub_1464  1
    load_2_17_10  free_load_conservation_1508  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_11  arc_capacity_1375  -30
    arc_2_17_11  connected_order_arc_1376  -12
    arc_2_17_11  in_degree_1466  1
    arc_2_17_11  out_degree_1503  1
    arc_2_17_11  original_T_including_depot_unload_1529  2.2636464857275848e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_11  arc_capacity_1375  1
    load_2_17_11  segment_load_conservation_1469  -1
    load_2_17_11  segment_prefix_lb_1470  1
    load_2_17_11  segment_prefix_ub_1471  1
    load_2_17_11  free_load_conservation_1508  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_12  arc_capacity_1377  -30
    arc_2_17_12  connected_order_arc_1378  -12
    arc_2_17_12  in_degree_1473  1
    arc_2_17_12  out_degree_1503  1
    arc_2_17_12  original_T_including_depot_unload_1529  1.3857128117205509e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_12  arc_capacity_1377  1
    load_2_17_12  segment_load_conservation_1476  -1
    load_2_17_12  segment_prefix_lb_1477  1
    load_2_17_12  segment_prefix_ub_1478  1
    load_2_17_12  free_load_conservation_1508  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_13  arc_capacity_1379  -30
    arc_2_17_13  connected_order_arc_1380  -12
    arc_2_17_13  in_degree_1480  1
    arc_2_17_13  out_degree_1503  1
    arc_2_17_13  original_T_including_depot_unload_1529  2.3332890980657526e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_13  arc_capacity_1379  1
    load_2_17_13  free_load_conservation_1484  -1
    load_2_17_13  free_load_conservation_1508  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_14  arc_capacity_1381  -30
    arc_2_17_14  connected_order_arc_1382  -12
    arc_2_17_14  in_degree_1486  1
    arc_2_17_14  out_degree_1503  1
    arc_2_17_14  original_T_including_depot_unload_1529  2.4500766064196278e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_14  arc_capacity_1381  1
    load_2_17_14  free_load_conservation_1490  -1
    load_2_17_14  free_load_conservation_1508  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_15  arc_capacity_1383  -30
    arc_2_17_15  connected_order_arc_1384  -12
    arc_2_17_15  in_degree_1492  1
    arc_2_17_15  out_degree_1503  1
    arc_2_17_15  original_T_including_depot_unload_1529  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_15  arc_capacity_1383  1
    load_2_17_15  free_load_conservation_1496  -1
    load_2_17_15  free_load_conservation_1508  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_16  arc_capacity_1385  -30
    arc_2_17_16  connected_order_arc_1386  -12
    arc_2_17_16  in_degree_1498  1
    arc_2_17_16  out_degree_1503  1
    arc_2_17_16  original_T_including_depot_unload_1529  2.0104743468619281e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_16  arc_capacity_1385  1
    load_2_17_16  free_load_conservation_1502  -1
    load_2_17_16  free_load_conservation_1508  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_18  arc_capacity_1387  -30
    arc_2_17_18  connected_order_arc_1388  -12
    arc_2_17_18  out_degree_1503  1
    arc_2_17_18  in_degree_1510  1
    arc_2_17_18  original_T_including_depot_unload_1529  1.8442669473423912e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_18  arc_capacity_1387  1
    load_2_17_18  free_load_conservation_1508  1
    load_2_17_18  free_load_conservation_1514  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_19  arc_capacity_1389  -30
    arc_2_17_19  connected_order_arc_1390  -12
    arc_2_17_19  out_degree_1503  1
    arc_2_17_19  in_degree_1516  1
    arc_2_17_19  original_T_including_depot_unload_1529  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_19  arc_capacity_1389  1
    load_2_17_19  free_load_conservation_1508  1
    load_2_17_19  free_load_conservation_1520  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_20  arc_capacity_1391  -30
    arc_2_17_20  connected_order_arc_1392  -12
    arc_2_17_20  out_degree_1503  1
    arc_2_17_20  in_degree_1522  1
    arc_2_17_20  original_T_including_depot_unload_1529  1.7883808204567979e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_20  arc_capacity_1391  1
    load_2_17_20  free_load_conservation_1508  1
    load_2_17_20  free_load_conservation_1526  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_0  arc_capacity_1393  -30
    arc_2_18_0  depot_return_or_bypass_1457  1
    arc_2_18_0  out_degree_1509  1
    arc_2_18_0  original_T_including_depot_unload_1529  8.7749189782983967e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_0  arc_capacity_1393  1
    load_2_18_0  free_load_conservation_1514  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_10  arc_capacity_1394  -30
    arc_2_18_10  connected_order_arc_1395  -12
    arc_2_18_10  in_degree_1459  1
    arc_2_18_10  out_degree_1509  1
    arc_2_18_10  original_T_including_depot_unload_1529  1.1005939447212634e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_10  arc_capacity_1394  1
    load_2_18_10  segment_load_conservation_1462  -1
    load_2_18_10  segment_prefix_lb_1463  1
    load_2_18_10  segment_prefix_ub_1464  1
    load_2_18_10  free_load_conservation_1514  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_11  arc_capacity_1396  -30
    arc_2_18_11  connected_order_arc_1397  -12
    arc_2_18_11  in_degree_1466  1
    arc_2_18_11  out_degree_1509  1
    arc_2_18_11  original_T_including_depot_unload_1529  1.6726682877661206e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_11  arc_capacity_1396  1
    load_2_18_11  segment_load_conservation_1469  -1
    load_2_18_11  segment_prefix_lb_1470  1
    load_2_18_11  segment_prefix_ub_1471  1
    load_2_18_11  free_load_conservation_1514  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_12  arc_capacity_1398  -30
    arc_2_18_12  connected_order_arc_1399  -12
    arc_2_18_12  in_degree_1473  1
    arc_2_18_12  out_degree_1509  1
    arc_2_18_12  original_T_including_depot_unload_1529  7.5571464781430223e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_12  arc_capacity_1398  1
    load_2_18_12  segment_load_conservation_1476  -1
    load_2_18_12  segment_prefix_lb_1477  1
    load_2_18_12  segment_prefix_ub_1478  1
    load_2_18_12  free_load_conservation_1514  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_13  arc_capacity_1400  -30
    arc_2_18_13  connected_order_arc_1401  -12
    arc_2_18_13  in_degree_1480  1
    arc_2_18_13  out_degree_1509  1
    arc_2_18_13  original_T_including_depot_unload_1529  4.8905010520753694e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_13  arc_capacity_1400  1
    load_2_18_13  free_load_conservation_1484  -1
    load_2_18_13  free_load_conservation_1514  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_14  arc_capacity_1402  -30
    arc_2_18_14  connected_order_arc_1403  -12
    arc_2_18_14  in_degree_1486  1
    arc_2_18_14  out_degree_1509  1
    arc_2_18_14  original_T_including_depot_unload_1529  6.2102815646279714e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_14  arc_capacity_1402  1
    load_2_18_14  free_load_conservation_1490  -1
    load_2_18_14  free_load_conservation_1514  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_15  arc_capacity_1404  -30
    arc_2_18_15  connected_order_arc_1405  -12
    arc_2_18_15  in_degree_1492  1
    arc_2_18_15  out_degree_1509  1
    arc_2_18_15  original_T_including_depot_unload_1529  7.3227602527872671e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_15  arc_capacity_1404  1
    load_2_18_15  free_load_conservation_1496  -1
    load_2_18_15  free_load_conservation_1514  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_16  arc_capacity_1406  -30
    arc_2_18_16  connected_order_arc_1407  -12
    arc_2_18_16  in_degree_1498  1
    arc_2_18_16  out_degree_1509  1
    arc_2_18_16  original_T_including_depot_unload_1529  1.6651295535886251e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_16  arc_capacity_1406  1
    load_2_18_16  free_load_conservation_1502  -1
    load_2_18_16  free_load_conservation_1514  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_17  arc_capacity_1408  -30
    arc_2_18_17  connected_order_arc_1409  -12
    arc_2_18_17  in_degree_1504  1
    arc_2_18_17  out_degree_1509  1
    arc_2_18_17  original_T_including_depot_unload_1529  1.8442669473423912e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_17  arc_capacity_1408  1
    load_2_18_17  free_load_conservation_1508  -1
    load_2_18_17  free_load_conservation_1514  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_19  arc_capacity_1410  -30
    arc_2_18_19  connected_order_arc_1411  -12
    arc_2_18_19  out_degree_1509  1
    arc_2_18_19  in_degree_1516  1
    arc_2_18_19  original_T_including_depot_unload_1529  1.3551088510632424e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_19  arc_capacity_1410  1
    load_2_18_19  free_load_conservation_1514  1
    load_2_18_19  free_load_conservation_1520  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_20  arc_capacity_1412  -30
    arc_2_18_20  connected_order_arc_1413  -12
    arc_2_18_20  out_degree_1509  1
    arc_2_18_20  in_degree_1522  1
    arc_2_18_20  original_T_including_depot_unload_1529  2.8747557636937808e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_20  arc_capacity_1412  1
    load_2_18_20  free_load_conservation_1514  1
    load_2_18_20  free_load_conservation_1526  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_0  arc_capacity_1414  -30
    arc_2_19_0  depot_return_or_bypass_1457  1
    arc_2_19_0  out_degree_1515  1
    arc_2_19_0  original_T_including_depot_unload_1529  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_0  arc_capacity_1414  1
    load_2_19_0  free_load_conservation_1520  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_10  arc_capacity_1415  -30
    arc_2_19_10  connected_order_arc_1416  -12
    arc_2_19_10  in_degree_1459  1
    arc_2_19_10  out_degree_1515  1
    arc_2_19_10  original_T_including_depot_unload_1529  5.0315495126439691e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_10  arc_capacity_1415  1
    load_2_19_10  segment_load_conservation_1462  -1
    load_2_19_10  segment_prefix_lb_1463  1
    load_2_19_10  segment_prefix_ub_1464  1
    load_2_19_10  free_load_conservation_1520  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_11  arc_capacity_1417  -30
    arc_2_19_11  connected_order_arc_1418  -12
    arc_2_19_11  in_degree_1466  1
    arc_2_19_11  out_degree_1515  1
    arc_2_19_11  original_T_including_depot_unload_1529  6.2172856448708023e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_11  arc_capacity_1417  1
    load_2_19_11  segment_load_conservation_1469  -1
    load_2_19_11  segment_prefix_lb_1470  1
    load_2_19_11  segment_prefix_ub_1471  1
    load_2_19_11  free_load_conservation_1520  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_12  arc_capacity_1419  -30
    arc_2_19_12  connected_order_arc_1420  -12
    arc_2_19_12  in_degree_1473  1
    arc_2_19_12  out_degree_1515  1
    arc_2_19_12  original_T_including_depot_unload_1529  7.6275540057842773e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_12  arc_capacity_1419  1
    load_2_19_12  segment_load_conservation_1476  -1
    load_2_19_12  segment_prefix_lb_1477  1
    load_2_19_12  segment_prefix_ub_1478  1
    load_2_19_12  free_load_conservation_1520  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_13  arc_capacity_1421  -30
    arc_2_19_13  connected_order_arc_1422  -12
    arc_2_19_13  in_degree_1480  1
    arc_2_19_13  out_degree_1515  1
    arc_2_19_13  original_T_including_depot_unload_1529  1.8319650761318992e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_13  arc_capacity_1421  1
    load_2_19_13  free_load_conservation_1484  -1
    load_2_19_13  free_load_conservation_1520  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_14  arc_capacity_1423  -30
    arc_2_19_14  connected_order_arc_1424  -12
    arc_2_19_14  in_degree_1486  1
    arc_2_19_14  out_degree_1515  1
    arc_2_19_14  original_T_including_depot_unload_1529  1.9170200697382236e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_14  arc_capacity_1423  1
    load_2_19_14  free_load_conservation_1490  -1
    load_2_19_14  free_load_conservation_1520  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_15  arc_capacity_1425  -30
    arc_2_19_15  connected_order_arc_1426  -12
    arc_2_19_15  in_degree_1492  1
    arc_2_19_15  out_degree_1515  1
    arc_2_19_15  original_T_including_depot_unload_1529  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_15  arc_capacity_1425  1
    load_2_19_15  free_load_conservation_1496  -1
    load_2_19_15  free_load_conservation_1520  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_16  arc_capacity_1427  -30
    arc_2_19_16  connected_order_arc_1428  -12
    arc_2_19_16  in_degree_1498  1
    arc_2_19_16  out_degree_1515  1
    arc_2_19_16  original_T_including_depot_unload_1529  1.5183735648810946e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_16  arc_capacity_1427  1
    load_2_19_16  free_load_conservation_1502  -1
    load_2_19_16  free_load_conservation_1520  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_17  arc_capacity_1429  -30
    arc_2_19_17  connected_order_arc_1430  -12
    arc_2_19_17  in_degree_1504  1
    arc_2_19_17  out_degree_1515  1
    arc_2_19_17  original_T_including_depot_unload_1529  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_17  arc_capacity_1429  1
    load_2_19_17  free_load_conservation_1508  -1
    load_2_19_17  free_load_conservation_1520  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_18  arc_capacity_1431  -30
    arc_2_19_18  connected_order_arc_1432  -12
    arc_2_19_18  in_degree_1510  1
    arc_2_19_18  out_degree_1515  1
    arc_2_19_18  original_T_including_depot_unload_1529  1.3551088510632424e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_18  arc_capacity_1431  1
    load_2_19_18  free_load_conservation_1514  -1
    load_2_19_18  free_load_conservation_1520  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_20  arc_capacity_1433  -30
    arc_2_19_20  connected_order_arc_1434  -12
    arc_2_19_20  out_degree_1515  1
    arc_2_19_20  in_degree_1522  1
    arc_2_19_20  original_T_including_depot_unload_1529  1.3852878731513219e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_20  arc_capacity_1433  1
    load_2_19_20  free_load_conservation_1520  1
    load_2_19_20  free_load_conservation_1526  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_0  arc_capacity_1435  -30
    arc_2_20_0  depot_return_or_bypass_1457  1
    arc_2_20_0  out_degree_1521  1
    arc_2_20_0  original_T_including_depot_unload_1529  1.0479182987243917e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_0  arc_capacity_1435  1
    load_2_20_0  free_load_conservation_1526  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_10  arc_capacity_1436  -30
    arc_2_20_10  connected_order_arc_1437  -12
    arc_2_20_10  in_degree_1459  1
    arc_2_20_10  out_degree_1521  1
    arc_2_20_10  original_T_including_depot_unload_1529  1.2309802293463208e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_10  arc_capacity_1436  1
    load_2_20_10  segment_load_conservation_1462  -1
    load_2_20_10  segment_prefix_lb_1463  1
    load_2_20_10  segment_prefix_ub_1464  1
    load_2_20_10  free_load_conservation_1526  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_11  arc_capacity_1438  -30
    arc_2_20_11  connected_order_arc_1439  -12
    arc_2_20_11  in_degree_1466  1
    arc_2_20_11  out_degree_1521  1
    arc_2_20_11  original_T_including_depot_unload_1529  1.5951553402938971e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_11  arc_capacity_1438  1
    load_2_20_11  segment_load_conservation_1469  -1
    load_2_20_11  segment_prefix_lb_1470  1
    load_2_20_11  segment_prefix_ub_1471  1
    load_2_20_11  free_load_conservation_1526  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_12  arc_capacity_1440  -30
    arc_2_20_12  connected_order_arc_1441  -12
    arc_2_20_12  in_degree_1473  1
    arc_2_20_12  out_degree_1521  1
    arc_2_20_12  original_T_including_depot_unload_1529  9.2235470209829464e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_12  arc_capacity_1440  1
    load_2_20_12  segment_load_conservation_1476  -1
    load_2_20_12  segment_prefix_lb_1477  1
    load_2_20_12  segment_prefix_ub_1478  1
    load_2_20_12  free_load_conservation_1526  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_13  arc_capacity_1442  -30
    arc_2_20_13  connected_order_arc_1443  -12
    arc_2_20_13  in_degree_1480  1
    arc_2_20_13  out_degree_1521  1
    arc_2_20_13  original_T_including_depot_unload_1529  6.2793211180612207e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_13  arc_capacity_1442  1
    load_2_20_13  free_load_conservation_1484  -1
    load_2_20_13  free_load_conservation_1526  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_14  arc_capacity_1444  -30
    arc_2_20_14  connected_order_arc_1445  -12
    arc_2_20_14  in_degree_1486  1
    arc_2_20_14  out_degree_1521  1
    arc_2_20_14  original_T_including_depot_unload_1529  8.0531033344008677e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_14  arc_capacity_1444  1
    load_2_20_14  free_load_conservation_1490  -1
    load_2_20_14  free_load_conservation_1526  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_15  arc_capacity_1446  -30
    arc_2_20_15  connected_order_arc_1447  -12
    arc_2_20_15  in_degree_1492  1
    arc_2_20_15  out_degree_1521  1
    arc_2_20_15  original_T_including_depot_unload_1529  5.2280951376932137e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_15  arc_capacity_1446  1
    load_2_20_15  free_load_conservation_1496  -1
    load_2_20_15  free_load_conservation_1526  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_16  arc_capacity_1448  -30
    arc_2_20_16  connected_order_arc_1449  -12
    arc_2_20_16  in_degree_1498  1
    arc_2_20_16  out_degree_1521  1
    arc_2_20_16  original_T_including_depot_unload_1529  3.6094216796124527e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_16  arc_capacity_1448  1
    load_2_20_16  free_load_conservation_1502  -1
    load_2_20_16  free_load_conservation_1526  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_17  arc_capacity_1450  -30
    arc_2_20_17  connected_order_arc_1451  -12
    arc_2_20_17  in_degree_1504  1
    arc_2_20_17  out_degree_1521  1
    arc_2_20_17  original_T_including_depot_unload_1529  1.7883808204567979e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_17  arc_capacity_1450  1
    load_2_20_17  free_load_conservation_1508  -1
    load_2_20_17  free_load_conservation_1526  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_18  arc_capacity_1452  -30
    arc_2_20_18  connected_order_arc_1453  -12
    arc_2_20_18  in_degree_1510  1
    arc_2_20_18  out_degree_1521  1
    arc_2_20_18  original_T_including_depot_unload_1529  2.8747557636937808e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_18  arc_capacity_1452  1
    load_2_20_18  free_load_conservation_1514  -1
    load_2_20_18  free_load_conservation_1526  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_19  arc_capacity_1454  -30
    arc_2_20_19  connected_order_arc_1455  -12
    arc_2_20_19  in_degree_1516  1
    arc_2_20_19  out_degree_1521  1
    arc_2_20_19  original_T_including_depot_unload_1529  1.3852878731513219e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_19  arc_capacity_1454  1
    load_2_20_19  free_load_conservation_1520  -1
    load_2_20_19  free_load_conservation_1526  1
RHS
    RHS1      OBJ       -0.48675
    RHS1      onehot_34_24  1
    RHS1      onehot_33_61  1
    RHS1      onehot_31_90  1
    RHS1      onehot_27_125  1
    RHS1      onehot_32_154  1
    RHS1      onehot_24_189  1
    RHS1      onehot_19_210  1
    RHS1      onehot_29_245  1
    RHS1      stock_ub_249  33
    RHS1      parent_nonstrict_scope_250  3.4658892740328873e-01
    RHS1      normalization_307  1
    RHS1      connected_order_arc_428  -12
    RHS1      connected_order_arc_430  -12
    RHS1      connected_order_arc_432  -12
    RHS1      connected_order_arc_434  -12
    RHS1      connected_order_arc_436  -12
    RHS1      connected_order_arc_438  -12
    RHS1      connected_order_arc_440  -12
    RHS1      connected_order_arc_442  -12
    RHS1      connected_order_arc_444  -12
    RHS1      connected_order_arc_446  -12
    RHS1      connected_order_arc_448  -12
    RHS1      connected_order_arc_451  -12
    RHS1      connected_order_arc_453  -12
    RHS1      connected_order_arc_455  -12
    RHS1      connected_order_arc_457  -12
    RHS1      connected_order_arc_459  -12
    RHS1      connected_order_arc_461  -12
    RHS1      connected_order_arc_463  -12
    RHS1      connected_order_arc_465  -12
    RHS1      connected_order_arc_467  -12
    RHS1      connected_order_arc_469  -12
    RHS1      connected_order_arc_471  -12
    RHS1      connected_order_arc_474  -12
    RHS1      connected_order_arc_476  -12
    RHS1      connected_order_arc_478  -12
    RHS1      connected_order_arc_480  -12
    RHS1      connected_order_arc_482  -12
    RHS1      connected_order_arc_484  -12
    RHS1      connected_order_arc_486  -12
    RHS1      connected_order_arc_488  -12
    RHS1      connected_order_arc_490  -12
    RHS1      connected_order_arc_492  -12
    RHS1      connected_order_arc_494  -12
    RHS1      connected_order_arc_497  -12
    RHS1      connected_order_arc_499  -12
    RHS1      connected_order_arc_501  -12
    RHS1      connected_order_arc_503  -12
    RHS1      connected_order_arc_505  -12
    RHS1      connected_order_arc_507  -12
    RHS1      connected_order_arc_509  -12
    RHS1      connected_order_arc_511  -12
    RHS1      connected_order_arc_513  -12
    RHS1      connected_order_arc_515  -12
    RHS1      connected_order_arc_517  -12
    RHS1      connected_order_arc_520  -12
    RHS1      connected_order_arc_522  -12
    RHS1      connected_order_arc_524  -12
    RHS1      connected_order_arc_526  -12
    RHS1      connected_order_arc_528  -12
    RHS1      connected_order_arc_530  -12
    RHS1      connected_order_arc_532  -12
    RHS1      connected_order_arc_534  -12
    RHS1      connected_order_arc_536  -12
    RHS1      connected_order_arc_538  -12
    RHS1      connected_order_arc_540  -12
    RHS1      connected_order_arc_543  -12
    RHS1      connected_order_arc_545  -12
    RHS1      connected_order_arc_547  -12
    RHS1      connected_order_arc_549  -12
    RHS1      connected_order_arc_551  -12
    RHS1      connected_order_arc_553  -12
    RHS1      connected_order_arc_555  -12
    RHS1      connected_order_arc_557  -12
    RHS1      connected_order_arc_559  -12
    RHS1      connected_order_arc_561  -12
    RHS1      connected_order_arc_563  -12
    RHS1      connected_order_arc_566  -12
    RHS1      connected_order_arc_568  -12
    RHS1      connected_order_arc_570  -12
    RHS1      connected_order_arc_572  -12
    RHS1      connected_order_arc_574  -12
    RHS1      connected_order_arc_576  -12
    RHS1      connected_order_arc_578  -12
    RHS1      connected_order_arc_580  -12
    RHS1      connected_order_arc_582  -12
    RHS1      connected_order_arc_584  -12
    RHS1      connected_order_arc_586  -12
    RHS1      connected_order_arc_589  -12
    RHS1      connected_order_arc_591  -12
    RHS1      connected_order_arc_593  -12
    RHS1      connected_order_arc_595  -12
    RHS1      connected_order_arc_597  -12
    RHS1      connected_order_arc_599  -12
    RHS1      connected_order_arc_601  -12
    RHS1      connected_order_arc_603  -12
    RHS1      connected_order_arc_605  -12
    RHS1      connected_order_arc_607  -12
    RHS1      connected_order_arc_609  -12
    RHS1      connected_order_arc_612  -12
    RHS1      connected_order_arc_614  -12
    RHS1      connected_order_arc_616  -12
    RHS1      connected_order_arc_618  -12
    RHS1      connected_order_arc_620  -12
    RHS1      connected_order_arc_622  -12
    RHS1      connected_order_arc_624  -12
    RHS1      connected_order_arc_626  -12
    RHS1      connected_order_arc_628  -12
    RHS1      connected_order_arc_630  -12
    RHS1      connected_order_arc_632  -12
    RHS1      connected_order_arc_635  -12
    RHS1      connected_order_arc_637  -12
    RHS1      connected_order_arc_639  -12
    RHS1      connected_order_arc_641  -12
    RHS1      connected_order_arc_643  -12
    RHS1      connected_order_arc_645  -12
    RHS1      connected_order_arc_647  -12
    RHS1      connected_order_arc_649  -12
    RHS1      connected_order_arc_651  -12
    RHS1      connected_order_arc_653  -12
    RHS1      connected_order_arc_655  -12
    RHS1      connected_order_arc_658  -12
    RHS1      connected_order_arc_660  -12
    RHS1      connected_order_arc_662  -12
    RHS1      connected_order_arc_664  -12
    RHS1      connected_order_arc_666  -12
    RHS1      connected_order_arc_668  -12
    RHS1      connected_order_arc_670  -12
    RHS1      connected_order_arc_672  -12
    RHS1      connected_order_arc_674  -12
    RHS1      connected_order_arc_676  -12
    RHS1      connected_order_arc_678  -12
    RHS1      connected_order_arc_681  -12
    RHS1      connected_order_arc_683  -12
    RHS1      connected_order_arc_685  -12
    RHS1      connected_order_arc_687  -12
    RHS1      connected_order_arc_689  -12
    RHS1      connected_order_arc_691  -12
    RHS1      connected_order_arc_693  -12
    RHS1      connected_order_arc_695  -12
    RHS1      connected_order_arc_697  -12
    RHS1      connected_order_arc_699  -12
    RHS1      connected_order_arc_701  -12
    RHS1      depot_departure_or_bypass_702  1
    RHS1      depot_return_or_bypass_703  1
    RHS1      segment_load_conservation_708  6
    RHS1      segment_prefix_ub_710  2
    RHS1      segment_load_conservation_715  6
    RHS1      segment_prefix_ub_717  14
    RHS1      segment_load_conservation_722  -6
    RHS1      segment_prefix_lb_723  6
    RHS1      segment_prefix_ub_724  20
    RHS1      segment_load_conservation_729  -6
    RHS1      segment_prefix_lb_730  6
    RHS1      segment_prefix_ub_731  20
    RHS1      fixed_segment_relative_order_780  1
    RHS1      fixed_segment_relative_order_781  1
    RHS1      fixed_segment_relative_order_782  1
    RHS1      original_T_including_depot_unload_783  1.7585775410128017e+03
    RHS1      connected_order_arc_800  -13
    RHS1      connected_order_arc_802  -13
    RHS1      connected_order_arc_804  -13
    RHS1      connected_order_arc_806  -13
    RHS1      connected_order_arc_808  -13
    RHS1      connected_order_arc_810  -13
    RHS1      connected_order_arc_812  -13
    RHS1      connected_order_arc_814  -13
    RHS1      connected_order_arc_816  -13
    RHS1      connected_order_arc_818  -13
    RHS1      connected_order_arc_820  -13
    RHS1      connected_order_arc_822  -13
    RHS1      connected_order_arc_825  -13
    RHS1      connected_order_arc_827  -13
    RHS1      connected_order_arc_829  -13
    RHS1      connected_order_arc_831  -13
    RHS1      connected_order_arc_833  -13
    RHS1      connected_order_arc_835  -13
    RHS1      connected_order_arc_837  -13
    RHS1      connected_order_arc_839  -13
    RHS1      connected_order_arc_841  -13
    RHS1      connected_order_arc_843  -13
    RHS1      connected_order_arc_845  -13
    RHS1      connected_order_arc_847  -13
    RHS1      connected_order_arc_850  -13
    RHS1      connected_order_arc_852  -13
    RHS1      connected_order_arc_854  -13
    RHS1      connected_order_arc_856  -13
    RHS1      connected_order_arc_858  -13
    RHS1      connected_order_arc_860  -13
    RHS1      connected_order_arc_862  -13
    RHS1      connected_order_arc_864  -13
    RHS1      connected_order_arc_866  -13
    RHS1      connected_order_arc_868  -13
    RHS1      connected_order_arc_870  -13
    RHS1      connected_order_arc_872  -13
    RHS1      connected_order_arc_875  -13
    RHS1      connected_order_arc_877  -13
    RHS1      connected_order_arc_879  -13
    RHS1      connected_order_arc_881  -13
    RHS1      connected_order_arc_883  -13
    RHS1      connected_order_arc_885  -13
    RHS1      connected_order_arc_887  -13
    RHS1      connected_order_arc_889  -13
    RHS1      connected_order_arc_891  -13
    RHS1      connected_order_arc_893  -13
    RHS1      connected_order_arc_895  -13
    RHS1      connected_order_arc_897  -13
    RHS1      connected_order_arc_900  -13
    RHS1      connected_order_arc_902  -13
    RHS1      connected_order_arc_904  -13
    RHS1      connected_order_arc_906  -13
    RHS1      connected_order_arc_908  -13
    RHS1      connected_order_arc_910  -13
    RHS1      connected_order_arc_912  -13
    RHS1      connected_order_arc_914  -13
    RHS1      connected_order_arc_916  -13
    RHS1      connected_order_arc_918  -13
    RHS1      connected_order_arc_920  -13
    RHS1      connected_order_arc_922  -13
    RHS1      connected_order_arc_925  -13
    RHS1      connected_order_arc_927  -13
    RHS1      connected_order_arc_929  -13
    RHS1      connected_order_arc_931  -13
    RHS1      connected_order_arc_933  -13
    RHS1      connected_order_arc_935  -13
    RHS1      connected_order_arc_937  -13
    RHS1      connected_order_arc_939  -13
    RHS1      connected_order_arc_941  -13
    RHS1      connected_order_arc_943  -13
    RHS1      connected_order_arc_945  -13
    RHS1      connected_order_arc_947  -13
    RHS1      connected_order_arc_950  -13
    RHS1      connected_order_arc_952  -13
    RHS1      connected_order_arc_954  -13
    RHS1      connected_order_arc_956  -13
    RHS1      connected_order_arc_958  -13
    RHS1      connected_order_arc_960  -13
    RHS1      connected_order_arc_962  -13
    RHS1      connected_order_arc_964  -13
    RHS1      connected_order_arc_966  -13
    RHS1      connected_order_arc_968  -13
    RHS1      connected_order_arc_970  -13
    RHS1      connected_order_arc_972  -13
    RHS1      connected_order_arc_975  -13
    RHS1      connected_order_arc_977  -13
    RHS1      connected_order_arc_979  -13
    RHS1      connected_order_arc_981  -13
    RHS1      connected_order_arc_983  -13
    RHS1      connected_order_arc_985  -13
    RHS1      connected_order_arc_987  -13
    RHS1      connected_order_arc_989  -13
    RHS1      connected_order_arc_991  -13
    RHS1      connected_order_arc_993  -13
    RHS1      connected_order_arc_995  -13
    RHS1      connected_order_arc_997  -13
    RHS1      connected_order_arc_1000  -13
    RHS1      connected_order_arc_1002  -13
    RHS1      connected_order_arc_1004  -13
    RHS1      connected_order_arc_1006  -13
    RHS1      connected_order_arc_1008  -13
    RHS1      connected_order_arc_1010  -13
    RHS1      connected_order_arc_1012  -13
    RHS1      connected_order_arc_1014  -13
    RHS1      connected_order_arc_1016  -13
    RHS1      connected_order_arc_1018  -13
    RHS1      connected_order_arc_1020  -13
    RHS1      connected_order_arc_1022  -13
    RHS1      connected_order_arc_1025  -13
    RHS1      connected_order_arc_1027  -13
    RHS1      connected_order_arc_1029  -13
    RHS1      connected_order_arc_1031  -13
    RHS1      connected_order_arc_1033  -13
    RHS1      connected_order_arc_1035  -13
    RHS1      connected_order_arc_1037  -13
    RHS1      connected_order_arc_1039  -13
    RHS1      connected_order_arc_1041  -13
    RHS1      connected_order_arc_1043  -13
    RHS1      connected_order_arc_1045  -13
    RHS1      connected_order_arc_1047  -13
    RHS1      connected_order_arc_1050  -13
    RHS1      connected_order_arc_1052  -13
    RHS1      connected_order_arc_1054  -13
    RHS1      connected_order_arc_1056  -13
    RHS1      connected_order_arc_1058  -13
    RHS1      connected_order_arc_1060  -13
    RHS1      connected_order_arc_1062  -13
    RHS1      connected_order_arc_1064  -13
    RHS1      connected_order_arc_1066  -13
    RHS1      connected_order_arc_1068  -13
    RHS1      connected_order_arc_1070  -13
    RHS1      connected_order_arc_1072  -13
    RHS1      connected_order_arc_1075  -13
    RHS1      connected_order_arc_1077  -13
    RHS1      connected_order_arc_1079  -13
    RHS1      connected_order_arc_1081  -13
    RHS1      connected_order_arc_1083  -13
    RHS1      connected_order_arc_1085  -13
    RHS1      connected_order_arc_1087  -13
    RHS1      connected_order_arc_1089  -13
    RHS1      connected_order_arc_1091  -13
    RHS1      connected_order_arc_1093  -13
    RHS1      connected_order_arc_1095  -13
    RHS1      connected_order_arc_1097  -13
    RHS1      connected_order_arc_1100  -13
    RHS1      connected_order_arc_1102  -13
    RHS1      connected_order_arc_1104  -13
    RHS1      connected_order_arc_1106  -13
    RHS1      connected_order_arc_1108  -13
    RHS1      connected_order_arc_1110  -13
    RHS1      connected_order_arc_1112  -13
    RHS1      connected_order_arc_1114  -13
    RHS1      connected_order_arc_1116  -13
    RHS1      connected_order_arc_1118  -13
    RHS1      connected_order_arc_1120  -13
    RHS1      connected_order_arc_1122  -13
    RHS1      depot_departure_or_bypass_1123  1
    RHS1      depot_return_or_bypass_1124  1
    RHS1      segment_load_conservation_1129  -4
    RHS1      segment_prefix_lb_1130  4
    RHS1      segment_prefix_ub_1131  25
    RHS1      segment_load_conservation_1136  5
    RHS1      segment_prefix_ub_1138  20
    RHS1      segment_load_conservation_1143  1
    RHS1      segment_prefix_ub_1145  24
    RHS1      segment_load_conservation_1150  4
    RHS1      segment_prefix_ub_1152  21
    RHS1      segment_load_conservation_1157  -10
    RHS1      segment_prefix_lb_1158  10
    RHS1      segment_prefix_ub_1159  25
    RHS1      fixed_segment_relative_order_1208  1
    RHS1      fixed_segment_relative_order_1209  1
    RHS1      fixed_segment_relative_order_1210  1
    RHS1      fixed_segment_relative_order_1211  1
    RHS1      original_T_including_depot_unload_1212  5.6657742491036688e+03
    RHS1      connected_order_arc_1227  -11
    RHS1      connected_order_arc_1229  -11
    RHS1      connected_order_arc_1231  -11
    RHS1      connected_order_arc_1233  -11
    RHS1      connected_order_arc_1235  -11
    RHS1      connected_order_arc_1237  -11
    RHS1      connected_order_arc_1239  -11
    RHS1      connected_order_arc_1241  -11
    RHS1      connected_order_arc_1243  -11
    RHS1      connected_order_arc_1245  -11
    RHS1      connected_order_arc_1248  -11
    RHS1      connected_order_arc_1250  -11
    RHS1      connected_order_arc_1252  -11
    RHS1      connected_order_arc_1254  -11
    RHS1      connected_order_arc_1256  -11
    RHS1      connected_order_arc_1258  -11
    RHS1      connected_order_arc_1260  -11
    RHS1      connected_order_arc_1262  -11
    RHS1      connected_order_arc_1264  -11
    RHS1      connected_order_arc_1266  -11
    RHS1      connected_order_arc_1269  -11
    RHS1      connected_order_arc_1271  -11
    RHS1      connected_order_arc_1273  -11
    RHS1      connected_order_arc_1275  -11
    RHS1      connected_order_arc_1277  -11
    RHS1      connected_order_arc_1279  -11
    RHS1      connected_order_arc_1281  -11
    RHS1      connected_order_arc_1283  -11
    RHS1      connected_order_arc_1285  -11
    RHS1      connected_order_arc_1287  -11
    RHS1      connected_order_arc_1290  -11
    RHS1      connected_order_arc_1292  -11
    RHS1      connected_order_arc_1294  -11
    RHS1      connected_order_arc_1296  -11
    RHS1      connected_order_arc_1298  -11
    RHS1      connected_order_arc_1300  -11
    RHS1      connected_order_arc_1302  -11
    RHS1      connected_order_arc_1304  -11
    RHS1      connected_order_arc_1306  -11
    RHS1      connected_order_arc_1308  -11
    RHS1      connected_order_arc_1311  -11
    RHS1      connected_order_arc_1313  -11
    RHS1      connected_order_arc_1315  -11
    RHS1      connected_order_arc_1317  -11
    RHS1      connected_order_arc_1319  -11
    RHS1      connected_order_arc_1321  -11
    RHS1      connected_order_arc_1323  -11
    RHS1      connected_order_arc_1325  -11
    RHS1      connected_order_arc_1327  -11
    RHS1      connected_order_arc_1329  -11
    RHS1      connected_order_arc_1332  -11
    RHS1      connected_order_arc_1334  -11
    RHS1      connected_order_arc_1336  -11
    RHS1      connected_order_arc_1338  -11
    RHS1      connected_order_arc_1340  -11
    RHS1      connected_order_arc_1342  -11
    RHS1      connected_order_arc_1344  -11
    RHS1      connected_order_arc_1346  -11
    RHS1      connected_order_arc_1348  -11
    RHS1      connected_order_arc_1350  -11
    RHS1      connected_order_arc_1353  -11
    RHS1      connected_order_arc_1355  -11
    RHS1      connected_order_arc_1357  -11
    RHS1      connected_order_arc_1359  -11
    RHS1      connected_order_arc_1361  -11
    RHS1      connected_order_arc_1363  -11
    RHS1      connected_order_arc_1365  -11
    RHS1      connected_order_arc_1367  -11
    RHS1      connected_order_arc_1369  -11
    RHS1      connected_order_arc_1371  -11
    RHS1      connected_order_arc_1374  -11
    RHS1      connected_order_arc_1376  -11
    RHS1      connected_order_arc_1378  -11
    RHS1      connected_order_arc_1380  -11
    RHS1      connected_order_arc_1382  -11
    RHS1      connected_order_arc_1384  -11
    RHS1      connected_order_arc_1386  -11
    RHS1      connected_order_arc_1388  -11
    RHS1      connected_order_arc_1390  -11
    RHS1      connected_order_arc_1392  -11
    RHS1      connected_order_arc_1395  -11
    RHS1      connected_order_arc_1397  -11
    RHS1      connected_order_arc_1399  -11
    RHS1      connected_order_arc_1401  -11
    RHS1      connected_order_arc_1403  -11
    RHS1      connected_order_arc_1405  -11
    RHS1      connected_order_arc_1407  -11
    RHS1      connected_order_arc_1409  -11
    RHS1      connected_order_arc_1411  -11
    RHS1      connected_order_arc_1413  -11
    RHS1      connected_order_arc_1416  -11
    RHS1      connected_order_arc_1418  -11
    RHS1      connected_order_arc_1420  -11
    RHS1      connected_order_arc_1422  -11
    RHS1      connected_order_arc_1424  -11
    RHS1      connected_order_arc_1426  -11
    RHS1      connected_order_arc_1428  -11
    RHS1      connected_order_arc_1430  -11
    RHS1      connected_order_arc_1432  -11
    RHS1      connected_order_arc_1434  -11
    RHS1      connected_order_arc_1437  -11
    RHS1      connected_order_arc_1439  -11
    RHS1      connected_order_arc_1441  -11
    RHS1      connected_order_arc_1443  -11
    RHS1      connected_order_arc_1445  -11
    RHS1      connected_order_arc_1447  -11
    RHS1      connected_order_arc_1449  -11
    RHS1      connected_order_arc_1451  -11
    RHS1      connected_order_arc_1453  -11
    RHS1      connected_order_arc_1455  -11
    RHS1      depot_departure_or_bypass_1456  1
    RHS1      depot_return_or_bypass_1457  1
    RHS1      segment_load_conservation_1462  2
    RHS1      segment_prefix_ub_1464  23
    RHS1      segment_load_conservation_1469  4
    RHS1      segment_prefix_ub_1471  26
    RHS1      segment_load_conservation_1476  -6
    RHS1      segment_prefix_lb_1477  6
    RHS1      segment_prefix_ub_1478  30
    RHS1      fixed_segment_relative_order_1527  1
    RHS1      fixed_segment_relative_order_1528  1
    RHS1      original_T_including_depot_unload_1529  3.4338663753147712e+03
BOUNDS
 LO BND1      t         2.4643548670983981e-02
 UP BND1      t         4.1518386714157786e-02
 UP BND1      q         5.5058892740328880e-01
 BV BND1      x_34_0  
 UP BND1      w_34_0    4.1518386714157786e-02
 BV BND1      x_34_1  
 UP BND1      w_34_1    4.1518386714157786e-02
 BV BND1      x_34_2  
 UP BND1      w_34_2    4.1518386714157786e-02
 BV BND1      x_34_3  
 UP BND1      w_34_3    4.1518386714157786e-02
 BV BND1      x_34_4  
 UP BND1      w_34_4    4.1518386714157786e-02
 BV BND1      x_34_5  
 UP BND1      w_34_5    4.1518386714157786e-02
 BV BND1      x_34_6  
 UP BND1      w_34_6    4.1518386714157786e-02
 BV BND1      x_34_7  
 UP BND1      w_34_7    4.1518386714157786e-02
 BV BND1      x_34_8  
 UP BND1      w_34_8    4.1518386714157786e-02
 BV BND1      x_34_9  
 UP BND1      w_34_9    4.1518386714157786e-02
 BV BND1      x_34_10 
 UP BND1      w_34_10   4.1518386714157786e-02
 BV BND1      x_34_11 
 UP BND1      w_34_11   4.1518386714157786e-02
 UP BND1      rho_34    1
 BV BND1      x_33_0  
 UP BND1      w_33_0    4.1518386714157786e-02
 BV BND1      x_33_1  
 UP BND1      w_33_1    4.1518386714157786e-02
 BV BND1      x_33_2  
 UP BND1      w_33_2    4.1518386714157786e-02
 BV BND1      x_33_3  
 UP BND1      w_33_3    4.1518386714157786e-02
 BV BND1      x_33_4  
 UP BND1      w_33_4    4.1518386714157786e-02
 BV BND1      x_33_5  
 UP BND1      w_33_5    4.1518386714157786e-02
 BV BND1      x_33_6  
 UP BND1      w_33_6    4.1518386714157786e-02
 BV BND1      x_33_7  
 UP BND1      w_33_7    4.1518386714157786e-02
 BV BND1      x_33_8  
 UP BND1      w_33_8    4.1518386714157786e-02
 BV BND1      x_33_9  
 UP BND1      w_33_9    4.1518386714157786e-02
 BV BND1      x_33_10 
 UP BND1      w_33_10   4.1518386714157786e-02
 BV BND1      x_33_11 
 UP BND1      w_33_11   4.1518386714157786e-02
 BV BND1      x_33_12 
 UP BND1      w_33_12   4.1518386714157786e-02
 BV BND1      x_33_13 
 UP BND1      w_33_13   4.1518386714157786e-02
 BV BND1      x_33_14 
 UP BND1      w_33_14   4.1518386714157786e-02
 BV BND1      x_33_15 
 UP BND1      w_33_15   4.1518386714157786e-02
 BV BND1      x_33_16 
 UP BND1      w_33_16   4.1518386714157786e-02
 UP BND1      rho_33    1
 BV BND1      x_31_0  
 UP BND1      w_31_0    4.1518386714157786e-02
 BV BND1      x_31_1  
 UP BND1      w_31_1    4.1518386714157786e-02
 BV BND1      x_31_2  
 UP BND1      w_31_2    4.1518386714157786e-02
 BV BND1      x_31_3  
 UP BND1      w_31_3    4.1518386714157786e-02
 BV BND1      x_31_4  
 UP BND1      w_31_4    4.1518386714157786e-02
 BV BND1      x_31_5  
 UP BND1      w_31_5    4.1518386714157786e-02
 BV BND1      x_31_6  
 UP BND1      w_31_6    4.1518386714157786e-02
 BV BND1      x_31_7  
 UP BND1      w_31_7    4.1518386714157786e-02
 BV BND1      x_31_8  
 UP BND1      w_31_8    4.1518386714157786e-02
 BV BND1      x_31_9  
 UP BND1      w_31_9    4.1518386714157786e-02
 BV BND1      x_31_10 
 UP BND1      w_31_10   4.1518386714157786e-02
 BV BND1      x_31_11 
 UP BND1      w_31_11   4.1518386714157786e-02
 BV BND1      x_31_12 
 UP BND1      w_31_12   4.1518386714157786e-02
 UP BND1      rho_31    1
 BV BND1      x_27_0  
 UP BND1      w_27_0    4.1518386714157786e-02
 BV BND1      x_27_1  
 UP BND1      w_27_1    4.1518386714157786e-02
 BV BND1      x_27_2  
 UP BND1      w_27_2    4.1518386714157786e-02
 BV BND1      x_27_3  
 UP BND1      w_27_3    4.1518386714157786e-02
 BV BND1      x_27_4  
 UP BND1      w_27_4    4.1518386714157786e-02
 BV BND1      x_27_5  
 UP BND1      w_27_5    4.1518386714157786e-02
 BV BND1      x_27_6  
 UP BND1      w_27_6    4.1518386714157786e-02
 BV BND1      x_27_7  
 UP BND1      w_27_7    4.1518386714157786e-02
 BV BND1      x_27_8  
 UP BND1      w_27_8    4.1518386714157786e-02
 BV BND1      x_27_9  
 UP BND1      w_27_9    4.1518386714157786e-02
 BV BND1      x_27_10 
 UP BND1      w_27_10   4.1518386714157786e-02
 BV BND1      x_27_11 
 UP BND1      w_27_11   4.1518386714157786e-02
 BV BND1      x_27_12 
 UP BND1      w_27_12   4.1518386714157786e-02
 BV BND1      x_27_13 
 UP BND1      w_27_13   4.1518386714157786e-02
 BV BND1      x_27_14 
 UP BND1      w_27_14   4.1518386714157786e-02
 BV BND1      x_27_15 
 UP BND1      w_27_15   4.1518386714157786e-02
 UP BND1      rho_27    1
 BV BND1      x_32_0  
 UP BND1      w_32_0    4.1518386714157786e-02
 BV BND1      x_32_1  
 UP BND1      w_32_1    4.1518386714157786e-02
 BV BND1      x_32_2  
 UP BND1      w_32_2    4.1518386714157786e-02
 BV BND1      x_32_3  
 UP BND1      w_32_3    4.1518386714157786e-02
 BV BND1      x_32_4  
 UP BND1      w_32_4    4.1518386714157786e-02
 BV BND1      x_32_5  
 UP BND1      w_32_5    4.1518386714157786e-02
 BV BND1      x_32_6  
 UP BND1      w_32_6    4.1518386714157786e-02
 BV BND1      x_32_7  
 UP BND1      w_32_7    4.1518386714157786e-02
 BV BND1      x_32_8  
 UP BND1      w_32_8    4.1518386714157786e-02
 BV BND1      x_32_9  
 UP BND1      w_32_9    4.1518386714157786e-02
 BV BND1      x_32_10 
 UP BND1      w_32_10   4.1518386714157786e-02
 BV BND1      x_32_11 
 UP BND1      w_32_11   4.1518386714157786e-02
 BV BND1      x_32_12 
 UP BND1      w_32_12   4.1518386714157786e-02
 UP BND1      rho_32    1
 BV BND1      x_24_0  
 UP BND1      w_24_0    4.1518386714157786e-02
 BV BND1      x_24_1  
 UP BND1      w_24_1    4.1518386714157786e-02
 BV BND1      x_24_2  
 UP BND1      w_24_2    4.1518386714157786e-02
 BV BND1      x_24_3  
 UP BND1      w_24_3    4.1518386714157786e-02
 BV BND1      x_24_4  
 UP BND1      w_24_4    4.1518386714157786e-02
 BV BND1      x_24_5  
 UP BND1      w_24_5    4.1518386714157786e-02
 BV BND1      x_24_6  
 UP BND1      w_24_6    4.1518386714157786e-02
 BV BND1      x_24_7  
 UP BND1      w_24_7    4.1518386714157786e-02
 BV BND1      x_24_8  
 UP BND1      w_24_8    4.1518386714157786e-02
 BV BND1      x_24_9  
 UP BND1      w_24_9    4.1518386714157786e-02
 BV BND1      x_24_10 
 UP BND1      w_24_10   4.1518386714157786e-02
 BV BND1      x_24_11 
 UP BND1      w_24_11   4.1518386714157786e-02
 BV BND1      x_24_12 
 UP BND1      w_24_12   4.1518386714157786e-02
 BV BND1      x_24_13 
 UP BND1      w_24_13   4.1518386714157786e-02
 BV BND1      x_24_14 
 UP BND1      w_24_14   4.1518386714157786e-02
 BV BND1      x_24_15 
 UP BND1      w_24_15   4.1518386714157786e-02
 UP BND1      rho_24    1
 BV BND1      x_19_0  
 UP BND1      w_19_0    4.1518386714157786e-02
 BV BND1      x_19_1  
 UP BND1      w_19_1    4.1518386714157786e-02
 BV BND1      x_19_2  
 UP BND1      w_19_2    4.1518386714157786e-02
 BV BND1      x_19_3  
 UP BND1      w_19_3    4.1518386714157786e-02
 BV BND1      x_19_4  
 UP BND1      w_19_4    4.1518386714157786e-02
 BV BND1      x_19_5  
 UP BND1      w_19_5    4.1518386714157786e-02
 BV BND1      x_19_6  
 UP BND1      w_19_6    4.1518386714157786e-02
 BV BND1      x_19_7  
 UP BND1      w_19_7    4.1518386714157786e-02
 BV BND1      x_19_8  
 UP BND1      w_19_8    4.1518386714157786e-02
 UP BND1      rho_19    1
 BV BND1      x_29_0  
 UP BND1      w_29_0    4.1518386714157786e-02
 BV BND1      x_29_1  
 UP BND1      w_29_1    4.1518386714157786e-02
 BV BND1      x_29_2  
 UP BND1      w_29_2    4.1518386714157786e-02
 BV BND1      x_29_3  
 UP BND1      w_29_3    4.1518386714157786e-02
 BV BND1      x_29_4  
 UP BND1      w_29_4    4.1518386714157786e-02
 BV BND1      x_29_5  
 UP BND1      w_29_5    4.1518386714157786e-02
 BV BND1      x_29_6  
 UP BND1      w_29_6    4.1518386714157786e-02
 BV BND1      x_29_7  
 UP BND1      w_29_7    4.1518386714157786e-02
 BV BND1      x_29_8  
 UP BND1      w_29_8    4.1518386714157786e-02
 BV BND1      x_29_9  
 UP BND1      w_29_9    4.1518386714157786e-02
 BV BND1      x_29_10 
 UP BND1      w_29_10   4.1518386714157786e-02
 BV BND1      x_29_11 
 UP BND1      w_29_11   4.1518386714157786e-02
 BV BND1      x_29_12 
 UP BND1      w_29_12   4.1518386714157786e-02
 BV BND1      x_29_13 
 UP BND1      w_29_13   4.1518386714157786e-02
 BV BND1      x_29_14 
 UP BND1      w_29_14   4.1518386714157786e-02
 BV BND1      x_29_15 
 UP BND1      w_29_15   4.1518386714157786e-02
 UP BND1      rho_29    1
 UP BND1      a_34_33   1
 UP BND1      a_34_31   1
 UP BND1      a_34_27   1
 UP BND1      a_34_32   1
 UP BND1      a_34_24   1
 UP BND1      a_34_19   1
 UP BND1      a_34_29   1
 UP BND1      a_33_31   1
 UP BND1      a_33_27   1
 UP BND1      a_33_32   1
 UP BND1      a_33_24   1
 UP BND1      a_33_19   1
 UP BND1      a_33_29   1
 UP BND1      a_31_27   1
 UP BND1      a_31_32   1
 UP BND1      a_31_24   1
 UP BND1      a_31_19   1
 UP BND1      a_31_29   1
 UP BND1      a_27_32   1
 UP BND1      a_27_24   1
 UP BND1      a_27_19   1
 UP BND1      a_27_29   1
 UP BND1      a_32_24   1
 UP BND1      a_32_19   1
 UP BND1      a_32_29   1
 UP BND1      a_24_19   1
 UP BND1      a_24_29   1
 UP BND1      a_19_29   1
 BV BND1      service_0_34_0
 BV BND1      service_0_34_2
 BV BND1      service_0_34_3
 BV BND1      service_0_34_4
 BV BND1      service_0_34_5
 BV BND1      service_0_34_6
 BV BND1      service_0_34_7
 BV BND1      service_0_34_8
 BV BND1      service_0_34_9
 BV BND1      service_0_34_10
 BV BND1      service_0_34_11
 BV BND1      service_1_34_0
 BV BND1      service_1_34_2
 BV BND1      service_1_34_3
 BV BND1      service_1_34_4
 BV BND1      service_1_34_5
 BV BND1      service_1_34_6
 BV BND1      service_1_34_7
 BV BND1      service_1_34_8
 BV BND1      service_1_34_9
 BV BND1      service_1_34_10
 BV BND1      service_1_34_11
 BV BND1      service_2_34_0
 BV BND1      service_2_34_2
 BV BND1      service_2_34_3
 BV BND1      service_2_34_4
 BV BND1      service_2_34_5
 BV BND1      service_2_34_6
 BV BND1      service_2_34_7
 BV BND1      service_2_34_8
 BV BND1      service_2_34_9
 BV BND1      service_2_34_10
 BV BND1      service_2_34_11
 BV BND1      service_0_33_0
 BV BND1      service_0_33_2
 BV BND1      service_0_33_3
 BV BND1      service_0_33_4
 BV BND1      service_0_33_5
 BV BND1      service_0_33_6
 BV BND1      service_0_33_7
 BV BND1      service_0_33_8
 BV BND1      service_0_33_9
 BV BND1      service_0_33_10
 BV BND1      service_0_33_11
 BV BND1      service_0_33_12
 BV BND1      service_0_33_13
 BV BND1      service_0_33_14
 BV BND1      service_0_33_15
 BV BND1      service_0_33_16
 BV BND1      service_1_33_0
 BV BND1      service_1_33_2
 BV BND1      service_1_33_3
 BV BND1      service_1_33_4
 BV BND1      service_1_33_5
 BV BND1      service_1_33_6
 BV BND1      service_1_33_7
 BV BND1      service_1_33_8
 BV BND1      service_1_33_9
 BV BND1      service_1_33_10
 BV BND1      service_1_33_11
 BV BND1      service_1_33_12
 BV BND1      service_1_33_13
 BV BND1      service_1_33_14
 BV BND1      service_1_33_15
 BV BND1      service_1_33_16
 BV BND1      service_2_33_0
 BV BND1      service_2_33_2
 BV BND1      service_2_33_3
 BV BND1      service_2_33_4
 BV BND1      service_2_33_5
 BV BND1      service_2_33_6
 BV BND1      service_2_33_7
 BV BND1      service_2_33_8
 BV BND1      service_2_33_9
 BV BND1      service_2_33_10
 BV BND1      service_2_33_11
 BV BND1      service_2_33_12
 BV BND1      service_2_33_13
 BV BND1      service_2_33_14
 BV BND1      service_2_33_15
 BV BND1      service_2_33_16
 BV BND1      service_0_31_0
 BV BND1      service_0_31_1
 BV BND1      service_0_31_3
 BV BND1      service_0_31_4
 BV BND1      service_0_31_5
 BV BND1      service_0_31_6
 BV BND1      service_0_31_7
 BV BND1      service_0_31_8
 BV BND1      service_0_31_9
 BV BND1      service_0_31_10
 BV BND1      service_0_31_11
 BV BND1      service_0_31_12
 BV BND1      service_1_31_0
 BV BND1      service_1_31_1
 BV BND1      service_1_31_3
 BV BND1      service_1_31_4
 BV BND1      service_1_31_5
 BV BND1      service_1_31_6
 BV BND1      service_1_31_7
 BV BND1      service_1_31_8
 BV BND1      service_1_31_9
 BV BND1      service_1_31_10
 BV BND1      service_1_31_11
 BV BND1      service_1_31_12
 BV BND1      service_2_31_0
 BV BND1      service_2_31_1
 BV BND1      service_2_31_3
 BV BND1      service_2_31_4
 BV BND1      service_2_31_5
 BV BND1      service_2_31_6
 BV BND1      service_2_31_7
 BV BND1      service_2_31_8
 BV BND1      service_2_31_9
 BV BND1      service_2_31_10
 BV BND1      service_2_31_11
 BV BND1      service_2_31_12
 BV BND1      service_0_27_0
 BV BND1      service_0_27_1
 BV BND1      service_0_27_2
 BV BND1      service_0_27_3
 BV BND1      service_0_27_4
 BV BND1      service_0_27_5
 BV BND1      service_0_27_6
 BV BND1      service_0_27_7
 BV BND1      service_0_27_8
 BV BND1      service_0_27_9
 BV BND1      service_0_27_10
 BV BND1      service_0_27_12
 BV BND1      service_0_27_13
 BV BND1      service_0_27_14
 BV BND1      service_0_27_15
 BV BND1      service_1_27_0
 BV BND1      service_1_27_1
 BV BND1      service_1_27_2
 BV BND1      service_1_27_3
 BV BND1      service_1_27_4
 BV BND1      service_1_27_5
 BV BND1      service_1_27_6
 BV BND1      service_1_27_7
 BV BND1      service_1_27_8
 BV BND1      service_1_27_9
 BV BND1      service_1_27_10
 BV BND1      service_1_27_12
 BV BND1      service_1_27_13
 BV BND1      service_1_27_14
 BV BND1      service_1_27_15
 BV BND1      service_2_27_0
 BV BND1      service_2_27_1
 BV BND1      service_2_27_2
 BV BND1      service_2_27_3
 BV BND1      service_2_27_4
 BV BND1      service_2_27_5
 BV BND1      service_2_27_6
 BV BND1      service_2_27_7
 BV BND1      service_2_27_8
 BV BND1      service_2_27_9
 BV BND1      service_2_27_10
 BV BND1      service_2_27_12
 BV BND1      service_2_27_13
 BV BND1      service_2_27_14
 BV BND1      service_2_27_15
 BV BND1      service_0_32_1
 BV BND1      service_0_32_2
 BV BND1      service_0_32_3
 BV BND1      service_0_32_4
 BV BND1      service_0_32_5
 BV BND1      service_0_32_6
 BV BND1      service_0_32_7
 BV BND1      service_0_32_8
 BV BND1      service_0_32_9
 BV BND1      service_0_32_10
 BV BND1      service_0_32_11
 BV BND1      service_0_32_12
 BV BND1      service_1_32_1
 BV BND1      service_1_32_2
 BV BND1      service_1_32_3
 BV BND1      service_1_32_4
 BV BND1      service_1_32_5
 BV BND1      service_1_32_6
 BV BND1      service_1_32_7
 BV BND1      service_1_32_8
 BV BND1      service_1_32_9
 BV BND1      service_1_32_10
 BV BND1      service_1_32_11
 BV BND1      service_1_32_12
 BV BND1      service_2_32_1
 BV BND1      service_2_32_2
 BV BND1      service_2_32_3
 BV BND1      service_2_32_4
 BV BND1      service_2_32_5
 BV BND1      service_2_32_6
 BV BND1      service_2_32_7
 BV BND1      service_2_32_8
 BV BND1      service_2_32_9
 BV BND1      service_2_32_10
 BV BND1      service_2_32_11
 BV BND1      service_2_32_12
 BV BND1      service_0_24_0
 BV BND1      service_0_24_1
 BV BND1      service_0_24_2
 BV BND1      service_0_24_3
 BV BND1      service_0_24_4
 BV BND1      service_0_24_5
 BV BND1      service_0_24_6
 BV BND1      service_0_24_7
 BV BND1      service_0_24_8
 BV BND1      service_0_24_9
 BV BND1      service_0_24_10
 BV BND1      service_0_24_12
 BV BND1      service_0_24_13
 BV BND1      service_0_24_14
 BV BND1      service_0_24_15
 BV BND1      service_1_24_0
 BV BND1      service_1_24_1
 BV BND1      service_1_24_2
 BV BND1      service_1_24_3
 BV BND1      service_1_24_4
 BV BND1      service_1_24_5
 BV BND1      service_1_24_6
 BV BND1      service_1_24_7
 BV BND1      service_1_24_8
 BV BND1      service_1_24_9
 BV BND1      service_1_24_10
 BV BND1      service_1_24_12
 BV BND1      service_1_24_13
 BV BND1      service_1_24_14
 BV BND1      service_1_24_15
 BV BND1      service_2_24_0
 BV BND1      service_2_24_1
 BV BND1      service_2_24_2
 BV BND1      service_2_24_3
 BV BND1      service_2_24_4
 BV BND1      service_2_24_5
 BV BND1      service_2_24_6
 BV BND1      service_2_24_7
 BV BND1      service_2_24_8
 BV BND1      service_2_24_9
 BV BND1      service_2_24_10
 BV BND1      service_2_24_12
 BV BND1      service_2_24_13
 BV BND1      service_2_24_14
 BV BND1      service_2_24_15
 BV BND1      service_0_19_1
 BV BND1      service_0_19_2
 BV BND1      service_0_19_3
 BV BND1      service_0_19_4
 BV BND1      service_0_19_5
 BV BND1      service_0_19_6
 BV BND1      service_0_19_7
 BV BND1      service_0_19_8
 BV BND1      service_1_19_1
 BV BND1      service_1_19_2
 BV BND1      service_1_19_3
 BV BND1      service_1_19_4
 BV BND1      service_1_19_5
 BV BND1      service_1_19_6
 BV BND1      service_1_19_7
 BV BND1      service_1_19_8
 BV BND1      service_2_19_1
 BV BND1      service_2_19_2
 BV BND1      service_2_19_3
 BV BND1      service_2_19_4
 BV BND1      service_2_19_5
 BV BND1      service_2_19_6
 BV BND1      service_2_19_7
 BV BND1      service_2_19_8
 BV BND1      service_0_29_0
 BV BND1      service_0_29_1
 BV BND1      service_0_29_2
 BV BND1      service_0_29_3
 BV BND1      service_0_29_4
 BV BND1      service_0_29_5
 BV BND1      service_0_29_6
 BV BND1      service_0_29_7
 BV BND1      service_0_29_8
 BV BND1      service_0_29_9
 BV BND1      service_0_29_10
 BV BND1      service_0_29_12
 BV BND1      service_0_29_13
 BV BND1      service_0_29_14
 BV BND1      service_0_29_15
 BV BND1      service_1_29_0
 BV BND1      service_1_29_1
 BV BND1      service_1_29_2
 BV BND1      service_1_29_3
 BV BND1      service_1_29_4
 BV BND1      service_1_29_5
 BV BND1      service_1_29_6
 BV BND1      service_1_29_7
 BV BND1      service_1_29_8
 BV BND1      service_1_29_9
 BV BND1      service_1_29_10
 BV BND1      service_1_29_12
 BV BND1      service_1_29_13
 BV BND1      service_1_29_14
 BV BND1      service_1_29_15
 BV BND1      service_2_29_0
 BV BND1      service_2_29_1
 BV BND1      service_2_29_2
 BV BND1      service_2_29_3
 BV BND1      service_2_29_4
 BV BND1      service_2_29_5
 BV BND1      service_2_29_6
 BV BND1      service_2_29_7
 BV BND1      service_2_29_8
 BV BND1      service_2_29_9
 BV BND1      service_2_29_10
 BV BND1      service_2_29_12
 BV BND1      service_2_29_13
 BV BND1      service_2_29_14
 BV BND1      service_2_29_15
 FX BND1      visit_0_1  1
 UP BND1      order_0_1  12
 FX BND1      visit_0_2  1
 UP BND1      order_0_2  12
 FX BND1      visit_0_3  1
 UP BND1      order_0_3  12
 FX BND1      visit_0_4  1
 UP BND1      order_0_4  12
 UP BND1      visit_0_13  1
 UP BND1      order_0_13  12
 UP BND1      visit_0_14  1
 UP BND1      order_0_14  12
 UP BND1      visit_0_15  1
 UP BND1      order_0_15  12
 UP BND1      visit_0_16  1
 UP BND1      order_0_16  12
 UP BND1      visit_0_17  1
 UP BND1      order_0_17  12
 UP BND1      visit_0_18  1
 UP BND1      order_0_18  12
 UP BND1      visit_0_19  1
 UP BND1      order_0_19  12
 UP BND1      visit_0_20  1
 UP BND1      order_0_20  12
 BV BND1      arc_0_0_0
 FX BND1      load_0_0_0  0
 BV BND1      arc_0_0_1
 FX BND1      load_0_0_1  0
 BV BND1      arc_0_0_2
 FX BND1      load_0_0_2  0
 BV BND1      arc_0_0_3
 FX BND1      load_0_0_3  0
 BV BND1      arc_0_0_4
 FX BND1      load_0_0_4  0
 BV BND1      arc_0_0_13
 FX BND1      load_0_0_13  0
 BV BND1      arc_0_0_14
 FX BND1      load_0_0_14  0
 BV BND1      arc_0_0_15
 FX BND1      load_0_0_15  0
 BV BND1      arc_0_0_16
 FX BND1      load_0_0_16  0
 BV BND1      arc_0_0_17
 FX BND1      load_0_0_17  0
 BV BND1      arc_0_0_18
 FX BND1      load_0_0_18  0
 BV BND1      arc_0_0_19
 FX BND1      load_0_0_19  0
 BV BND1      arc_0_0_20
 FX BND1      load_0_0_20  0
 BV BND1      arc_0_1_0
 UP BND1      load_0_1_0  20
 BV BND1      arc_0_1_2
 UP BND1      load_0_1_2  20
 BV BND1      arc_0_1_3
 UP BND1      load_0_1_3  20
 BV BND1      arc_0_1_4
 UP BND1      load_0_1_4  20
 BV BND1      arc_0_1_13
 UP BND1      load_0_1_13  20
 BV BND1      arc_0_1_14
 UP BND1      load_0_1_14  20
 BV BND1      arc_0_1_15
 UP BND1      load_0_1_15  20
 BV BND1      arc_0_1_16
 UP BND1      load_0_1_16  20
 BV BND1      arc_0_1_17
 UP BND1      load_0_1_17  20
 BV BND1      arc_0_1_18
 UP BND1      load_0_1_18  20
 BV BND1      arc_0_1_19
 UP BND1      load_0_1_19  20
 BV BND1      arc_0_1_20
 UP BND1      load_0_1_20  20
 BV BND1      arc_0_2_0
 UP BND1      load_0_2_0  20
 BV BND1      arc_0_2_1
 UP BND1      load_0_2_1  20
 BV BND1      arc_0_2_3
 UP BND1      load_0_2_3  20
 BV BND1      arc_0_2_4
 UP BND1      load_0_2_4  20
 BV BND1      arc_0_2_13
 UP BND1      load_0_2_13  20
 BV BND1      arc_0_2_14
 UP BND1      load_0_2_14  20
 BV BND1      arc_0_2_15
 UP BND1      load_0_2_15  20
 BV BND1      arc_0_2_16
 UP BND1      load_0_2_16  20
 BV BND1      arc_0_2_17
 UP BND1      load_0_2_17  20
 BV BND1      arc_0_2_18
 UP BND1      load_0_2_18  20
 BV BND1      arc_0_2_19
 UP BND1      load_0_2_19  20
 BV BND1      arc_0_2_20
 UP BND1      load_0_2_20  20
 BV BND1      arc_0_3_0
 UP BND1      load_0_3_0  20
 BV BND1      arc_0_3_1
 UP BND1      load_0_3_1  20
 BV BND1      arc_0_3_2
 UP BND1      load_0_3_2  20
 BV BND1      arc_0_3_4
 UP BND1      load_0_3_4  20
 BV BND1      arc_0_3_13
 UP BND1      load_0_3_13  20
 BV BND1      arc_0_3_14
 UP BND1      load_0_3_14  20
 BV BND1      arc_0_3_15
 UP BND1      load_0_3_15  20
 BV BND1      arc_0_3_16
 UP BND1      load_0_3_16  20
 BV BND1      arc_0_3_17
 UP BND1      load_0_3_17  20
 BV BND1      arc_0_3_18
 UP BND1      load_0_3_18  20
 BV BND1      arc_0_3_19
 UP BND1      load_0_3_19  20
 BV BND1      arc_0_3_20
 UP BND1      load_0_3_20  20
 BV BND1      arc_0_4_0
 UP BND1      load_0_4_0  20
 BV BND1      arc_0_4_1
 UP BND1      load_0_4_1  20
 BV BND1      arc_0_4_2
 UP BND1      load_0_4_2  20
 BV BND1      arc_0_4_3
 UP BND1      load_0_4_3  20
 BV BND1      arc_0_4_13
 UP BND1      load_0_4_13  20
 BV BND1      arc_0_4_14
 UP BND1      load_0_4_14  20
 BV BND1      arc_0_4_15
 UP BND1      load_0_4_15  20
 BV BND1      arc_0_4_16
 UP BND1      load_0_4_16  20
 BV BND1      arc_0_4_17
 UP BND1      load_0_4_17  20
 BV BND1      arc_0_4_18
 UP BND1      load_0_4_18  20
 BV BND1      arc_0_4_19
 UP BND1      load_0_4_19  20
 BV BND1      arc_0_4_20
 UP BND1      load_0_4_20  20
 BV BND1      arc_0_13_0
 UP BND1      load_0_13_0  20
 BV BND1      arc_0_13_1
 UP BND1      load_0_13_1  20
 BV BND1      arc_0_13_2
 UP BND1      load_0_13_2  20
 BV BND1      arc_0_13_3
 UP BND1      load_0_13_3  20
 BV BND1      arc_0_13_4
 UP BND1      load_0_13_4  20
 BV BND1      arc_0_13_14
 UP BND1      load_0_13_14  20
 BV BND1      arc_0_13_15
 UP BND1      load_0_13_15  20
 BV BND1      arc_0_13_16
 UP BND1      load_0_13_16  20
 BV BND1      arc_0_13_17
 UP BND1      load_0_13_17  20
 BV BND1      arc_0_13_18
 UP BND1      load_0_13_18  20
 BV BND1      arc_0_13_19
 UP BND1      load_0_13_19  20
 BV BND1      arc_0_13_20
 UP BND1      load_0_13_20  20
 BV BND1      arc_0_14_0
 UP BND1      load_0_14_0  20
 BV BND1      arc_0_14_1
 UP BND1      load_0_14_1  20
 BV BND1      arc_0_14_2
 UP BND1      load_0_14_2  20
 BV BND1      arc_0_14_3
 UP BND1      load_0_14_3  20
 BV BND1      arc_0_14_4
 UP BND1      load_0_14_4  20
 BV BND1      arc_0_14_13
 UP BND1      load_0_14_13  20
 BV BND1      arc_0_14_15
 UP BND1      load_0_14_15  20
 BV BND1      arc_0_14_16
 UP BND1      load_0_14_16  20
 BV BND1      arc_0_14_17
 UP BND1      load_0_14_17  20
 BV BND1      arc_0_14_18
 UP BND1      load_0_14_18  20
 BV BND1      arc_0_14_19
 UP BND1      load_0_14_19  20
 BV BND1      arc_0_14_20
 UP BND1      load_0_14_20  20
 BV BND1      arc_0_15_0
 UP BND1      load_0_15_0  20
 BV BND1      arc_0_15_1
 UP BND1      load_0_15_1  20
 BV BND1      arc_0_15_2
 UP BND1      load_0_15_2  20
 BV BND1      arc_0_15_3
 UP BND1      load_0_15_3  20
 BV BND1      arc_0_15_4
 UP BND1      load_0_15_4  20
 BV BND1      arc_0_15_13
 UP BND1      load_0_15_13  20
 BV BND1      arc_0_15_14
 UP BND1      load_0_15_14  20
 BV BND1      arc_0_15_16
 UP BND1      load_0_15_16  20
 BV BND1      arc_0_15_17
 UP BND1      load_0_15_17  20
 BV BND1      arc_0_15_18
 UP BND1      load_0_15_18  20
 BV BND1      arc_0_15_19
 UP BND1      load_0_15_19  20
 BV BND1      arc_0_15_20
 UP BND1      load_0_15_20  20
 BV BND1      arc_0_16_0
 UP BND1      load_0_16_0  20
 BV BND1      arc_0_16_1
 UP BND1      load_0_16_1  20
 BV BND1      arc_0_16_2
 UP BND1      load_0_16_2  20
 BV BND1      arc_0_16_3
 UP BND1      load_0_16_3  20
 BV BND1      arc_0_16_4
 UP BND1      load_0_16_4  20
 BV BND1      arc_0_16_13
 UP BND1      load_0_16_13  20
 BV BND1      arc_0_16_14
 UP BND1      load_0_16_14  20
 BV BND1      arc_0_16_15
 UP BND1      load_0_16_15  20
 BV BND1      arc_0_16_17
 UP BND1      load_0_16_17  20
 BV BND1      arc_0_16_18
 UP BND1      load_0_16_18  20
 BV BND1      arc_0_16_19
 UP BND1      load_0_16_19  20
 BV BND1      arc_0_16_20
 UP BND1      load_0_16_20  20
 BV BND1      arc_0_17_0
 UP BND1      load_0_17_0  20
 BV BND1      arc_0_17_1
 UP BND1      load_0_17_1  20
 BV BND1      arc_0_17_2
 UP BND1      load_0_17_2  20
 BV BND1      arc_0_17_3
 UP BND1      load_0_17_3  20
 BV BND1      arc_0_17_4
 UP BND1      load_0_17_4  20
 BV BND1      arc_0_17_13
 UP BND1      load_0_17_13  20
 BV BND1      arc_0_17_14
 UP BND1      load_0_17_14  20
 BV BND1      arc_0_17_15
 UP BND1      load_0_17_15  20
 BV BND1      arc_0_17_16
 UP BND1      load_0_17_16  20
 BV BND1      arc_0_17_18
 UP BND1      load_0_17_18  20
 BV BND1      arc_0_17_19
 UP BND1      load_0_17_19  20
 BV BND1      arc_0_17_20
 UP BND1      load_0_17_20  20
 BV BND1      arc_0_18_0
 UP BND1      load_0_18_0  20
 BV BND1      arc_0_18_1
 UP BND1      load_0_18_1  20
 BV BND1      arc_0_18_2
 UP BND1      load_0_18_2  20
 BV BND1      arc_0_18_3
 UP BND1      load_0_18_3  20
 BV BND1      arc_0_18_4
 UP BND1      load_0_18_4  20
 BV BND1      arc_0_18_13
 UP BND1      load_0_18_13  20
 BV BND1      arc_0_18_14
 UP BND1      load_0_18_14  20
 BV BND1      arc_0_18_15
 UP BND1      load_0_18_15  20
 BV BND1      arc_0_18_16
 UP BND1      load_0_18_16  20
 BV BND1      arc_0_18_17
 UP BND1      load_0_18_17  20
 BV BND1      arc_0_18_19
 UP BND1      load_0_18_19  20
 BV BND1      arc_0_18_20
 UP BND1      load_0_18_20  20
 BV BND1      arc_0_19_0
 UP BND1      load_0_19_0  20
 BV BND1      arc_0_19_1
 UP BND1      load_0_19_1  20
 BV BND1      arc_0_19_2
 UP BND1      load_0_19_2  20
 BV BND1      arc_0_19_3
 UP BND1      load_0_19_3  20
 BV BND1      arc_0_19_4
 UP BND1      load_0_19_4  20
 BV BND1      arc_0_19_13
 UP BND1      load_0_19_13  20
 BV BND1      arc_0_19_14
 UP BND1      load_0_19_14  20
 BV BND1      arc_0_19_15
 UP BND1      load_0_19_15  20
 BV BND1      arc_0_19_16
 UP BND1      load_0_19_16  20
 BV BND1      arc_0_19_17
 UP BND1      load_0_19_17  20
 BV BND1      arc_0_19_18
 UP BND1      load_0_19_18  20
 BV BND1      arc_0_19_20
 UP BND1      load_0_19_20  20
 BV BND1      arc_0_20_0
 UP BND1      load_0_20_0  20
 BV BND1      arc_0_20_1
 UP BND1      load_0_20_1  20
 BV BND1      arc_0_20_2
 UP BND1      load_0_20_2  20
 BV BND1      arc_0_20_3
 UP BND1      load_0_20_3  20
 BV BND1      arc_0_20_4
 UP BND1      load_0_20_4  20
 BV BND1      arc_0_20_13
 UP BND1      load_0_20_13  20
 BV BND1      arc_0_20_14
 UP BND1      load_0_20_14  20
 BV BND1      arc_0_20_15
 UP BND1      load_0_20_15  20
 BV BND1      arc_0_20_16
 UP BND1      load_0_20_16  20
 BV BND1      arc_0_20_17
 UP BND1      load_0_20_17  20
 BV BND1      arc_0_20_18
 UP BND1      load_0_20_18  20
 BV BND1      arc_0_20_19
 UP BND1      load_0_20_19  20
 FX BND1      visit_1_5  1
 UP BND1      order_1_5  13
 FX BND1      visit_1_6  1
 UP BND1      order_1_6  13
 FX BND1      visit_1_7  1
 UP BND1      order_1_7  13
 FX BND1      visit_1_8  1
 UP BND1      order_1_8  13
 FX BND1      visit_1_9  1
 UP BND1      order_1_9  13
 UP BND1      visit_1_13  1
 UP BND1      order_1_13  13
 UP BND1      visit_1_14  1
 UP BND1      order_1_14  13
 UP BND1      visit_1_15  1
 UP BND1      order_1_15  13
 UP BND1      visit_1_16  1
 UP BND1      order_1_16  13
 UP BND1      visit_1_17  1
 UP BND1      order_1_17  13
 UP BND1      visit_1_18  1
 UP BND1      order_1_18  13
 UP BND1      visit_1_19  1
 UP BND1      order_1_19  13
 UP BND1      visit_1_20  1
 UP BND1      order_1_20  13
 BV BND1      arc_1_0_0
 FX BND1      load_1_0_0  0
 BV BND1      arc_1_0_5
 FX BND1      load_1_0_5  0
 BV BND1      arc_1_0_6
 FX BND1      load_1_0_6  0
 BV BND1      arc_1_0_7
 FX BND1      load_1_0_7  0
 BV BND1      arc_1_0_8
 FX BND1      load_1_0_8  0
 BV BND1      arc_1_0_9
 FX BND1      load_1_0_9  0
 BV BND1      arc_1_0_13
 FX BND1      load_1_0_13  0
 BV BND1      arc_1_0_14
 FX BND1      load_1_0_14  0
 BV BND1      arc_1_0_15
 FX BND1      load_1_0_15  0
 BV BND1      arc_1_0_16
 FX BND1      load_1_0_16  0
 BV BND1      arc_1_0_17
 FX BND1      load_1_0_17  0
 BV BND1      arc_1_0_18
 FX BND1      load_1_0_18  0
 BV BND1      arc_1_0_19
 FX BND1      load_1_0_19  0
 BV BND1      arc_1_0_20
 FX BND1      load_1_0_20  0
 BV BND1      arc_1_5_0
 UP BND1      load_1_5_0  25
 BV BND1      arc_1_5_6
 UP BND1      load_1_5_6  25
 BV BND1      arc_1_5_7
 UP BND1      load_1_5_7  25
 BV BND1      arc_1_5_8
 UP BND1      load_1_5_8  25
 BV BND1      arc_1_5_9
 UP BND1      load_1_5_9  25
 BV BND1      arc_1_5_13
 UP BND1      load_1_5_13  25
 BV BND1      arc_1_5_14
 UP BND1      load_1_5_14  25
 BV BND1      arc_1_5_15
 UP BND1      load_1_5_15  25
 BV BND1      arc_1_5_16
 UP BND1      load_1_5_16  25
 BV BND1      arc_1_5_17
 UP BND1      load_1_5_17  25
 BV BND1      arc_1_5_18
 UP BND1      load_1_5_18  25
 BV BND1      arc_1_5_19
 UP BND1      load_1_5_19  25
 BV BND1      arc_1_5_20
 UP BND1      load_1_5_20  25
 BV BND1      arc_1_6_0
 UP BND1      load_1_6_0  25
 BV BND1      arc_1_6_5
 UP BND1      load_1_6_5  25
 BV BND1      arc_1_6_7
 UP BND1      load_1_6_7  25
 BV BND1      arc_1_6_8
 UP BND1      load_1_6_8  25
 BV BND1      arc_1_6_9
 UP BND1      load_1_6_9  25
 BV BND1      arc_1_6_13
 UP BND1      load_1_6_13  25
 BV BND1      arc_1_6_14
 UP BND1      load_1_6_14  25
 BV BND1      arc_1_6_15
 UP BND1      load_1_6_15  25
 BV BND1      arc_1_6_16
 UP BND1      load_1_6_16  25
 BV BND1      arc_1_6_17
 UP BND1      load_1_6_17  25
 BV BND1      arc_1_6_18
 UP BND1      load_1_6_18  25
 BV BND1      arc_1_6_19
 UP BND1      load_1_6_19  25
 BV BND1      arc_1_6_20
 UP BND1      load_1_6_20  25
 BV BND1      arc_1_7_0
 UP BND1      load_1_7_0  25
 BV BND1      arc_1_7_5
 UP BND1      load_1_7_5  25
 BV BND1      arc_1_7_6
 UP BND1      load_1_7_6  25
 BV BND1      arc_1_7_8
 UP BND1      load_1_7_8  25
 BV BND1      arc_1_7_9
 UP BND1      load_1_7_9  25
 BV BND1      arc_1_7_13
 UP BND1      load_1_7_13  25
 BV BND1      arc_1_7_14
 UP BND1      load_1_7_14  25
 BV BND1      arc_1_7_15
 UP BND1      load_1_7_15  25
 BV BND1      arc_1_7_16
 UP BND1      load_1_7_16  25
 BV BND1      arc_1_7_17
 UP BND1      load_1_7_17  25
 BV BND1      arc_1_7_18
 UP BND1      load_1_7_18  25
 BV BND1      arc_1_7_19
 UP BND1      load_1_7_19  25
 BV BND1      arc_1_7_20
 UP BND1      load_1_7_20  25
 BV BND1      arc_1_8_0
 UP BND1      load_1_8_0  25
 BV BND1      arc_1_8_5
 UP BND1      load_1_8_5  25
 BV BND1      arc_1_8_6
 UP BND1      load_1_8_6  25
 BV BND1      arc_1_8_7
 UP BND1      load_1_8_7  25
 BV BND1      arc_1_8_9
 UP BND1      load_1_8_9  25
 BV BND1      arc_1_8_13
 UP BND1      load_1_8_13  25
 BV BND1      arc_1_8_14
 UP BND1      load_1_8_14  25
 BV BND1      arc_1_8_15
 UP BND1      load_1_8_15  25
 BV BND1      arc_1_8_16
 UP BND1      load_1_8_16  25
 BV BND1      arc_1_8_17
 UP BND1      load_1_8_17  25
 BV BND1      arc_1_8_18
 UP BND1      load_1_8_18  25
 BV BND1      arc_1_8_19
 UP BND1      load_1_8_19  25
 BV BND1      arc_1_8_20
 UP BND1      load_1_8_20  25
 BV BND1      arc_1_9_0
 UP BND1      load_1_9_0  25
 BV BND1      arc_1_9_5
 UP BND1      load_1_9_5  25
 BV BND1      arc_1_9_6
 UP BND1      load_1_9_6  25
 BV BND1      arc_1_9_7
 UP BND1      load_1_9_7  25
 BV BND1      arc_1_9_8
 UP BND1      load_1_9_8  25
 BV BND1      arc_1_9_13
 UP BND1      load_1_9_13  25
 BV BND1      arc_1_9_14
 UP BND1      load_1_9_14  25
 BV BND1      arc_1_9_15
 UP BND1      load_1_9_15  25
 BV BND1      arc_1_9_16
 UP BND1      load_1_9_16  25
 BV BND1      arc_1_9_17
 UP BND1      load_1_9_17  25
 BV BND1      arc_1_9_18
 UP BND1      load_1_9_18  25
 BV BND1      arc_1_9_19
 UP BND1      load_1_9_19  25
 BV BND1      arc_1_9_20
 UP BND1      load_1_9_20  25
 BV BND1      arc_1_13_0
 UP BND1      load_1_13_0  25
 BV BND1      arc_1_13_5
 UP BND1      load_1_13_5  25
 BV BND1      arc_1_13_6
 UP BND1      load_1_13_6  25
 BV BND1      arc_1_13_7
 UP BND1      load_1_13_7  25
 BV BND1      arc_1_13_8
 UP BND1      load_1_13_8  25
 BV BND1      arc_1_13_9
 UP BND1      load_1_13_9  25
 BV BND1      arc_1_13_14
 UP BND1      load_1_13_14  25
 BV BND1      arc_1_13_15
 UP BND1      load_1_13_15  25
 BV BND1      arc_1_13_16
 UP BND1      load_1_13_16  25
 BV BND1      arc_1_13_17
 UP BND1      load_1_13_17  25
 BV BND1      arc_1_13_18
 UP BND1      load_1_13_18  25
 BV BND1      arc_1_13_19
 UP BND1      load_1_13_19  25
 BV BND1      arc_1_13_20
 UP BND1      load_1_13_20  25
 BV BND1      arc_1_14_0
 UP BND1      load_1_14_0  25
 BV BND1      arc_1_14_5
 UP BND1      load_1_14_5  25
 BV BND1      arc_1_14_6
 UP BND1      load_1_14_6  25
 BV BND1      arc_1_14_7
 UP BND1      load_1_14_7  25
 BV BND1      arc_1_14_8
 UP BND1      load_1_14_8  25
 BV BND1      arc_1_14_9
 UP BND1      load_1_14_9  25
 BV BND1      arc_1_14_13
 UP BND1      load_1_14_13  25
 BV BND1      arc_1_14_15
 UP BND1      load_1_14_15  25
 BV BND1      arc_1_14_16
 UP BND1      load_1_14_16  25
 BV BND1      arc_1_14_17
 UP BND1      load_1_14_17  25
 BV BND1      arc_1_14_18
 UP BND1      load_1_14_18  25
 BV BND1      arc_1_14_19
 UP BND1      load_1_14_19  25
 BV BND1      arc_1_14_20
 UP BND1      load_1_14_20  25
 BV BND1      arc_1_15_0
 UP BND1      load_1_15_0  25
 BV BND1      arc_1_15_5
 UP BND1      load_1_15_5  25
 BV BND1      arc_1_15_6
 UP BND1      load_1_15_6  25
 BV BND1      arc_1_15_7
 UP BND1      load_1_15_7  25
 BV BND1      arc_1_15_8
 UP BND1      load_1_15_8  25
 BV BND1      arc_1_15_9
 UP BND1      load_1_15_9  25
 BV BND1      arc_1_15_13
 UP BND1      load_1_15_13  25
 BV BND1      arc_1_15_14
 UP BND1      load_1_15_14  25
 BV BND1      arc_1_15_16
 UP BND1      load_1_15_16  25
 BV BND1      arc_1_15_17
 UP BND1      load_1_15_17  25
 BV BND1      arc_1_15_18
 UP BND1      load_1_15_18  25
 BV BND1      arc_1_15_19
 UP BND1      load_1_15_19  25
 BV BND1      arc_1_15_20
 UP BND1      load_1_15_20  25
 BV BND1      arc_1_16_0
 UP BND1      load_1_16_0  25
 BV BND1      arc_1_16_5
 UP BND1      load_1_16_5  25
 BV BND1      arc_1_16_6
 UP BND1      load_1_16_6  25
 BV BND1      arc_1_16_7
 UP BND1      load_1_16_7  25
 BV BND1      arc_1_16_8
 UP BND1      load_1_16_8  25
 BV BND1      arc_1_16_9
 UP BND1      load_1_16_9  25
 BV BND1      arc_1_16_13
 UP BND1      load_1_16_13  25
 BV BND1      arc_1_16_14
 UP BND1      load_1_16_14  25
 BV BND1      arc_1_16_15
 UP BND1      load_1_16_15  25
 BV BND1      arc_1_16_17
 UP BND1      load_1_16_17  25
 BV BND1      arc_1_16_18
 UP BND1      load_1_16_18  25
 BV BND1      arc_1_16_19
 UP BND1      load_1_16_19  25
 BV BND1      arc_1_16_20
 UP BND1      load_1_16_20  25
 BV BND1      arc_1_17_0
 UP BND1      load_1_17_0  25
 BV BND1      arc_1_17_5
 UP BND1      load_1_17_5  25
 BV BND1      arc_1_17_6
 UP BND1      load_1_17_6  25
 BV BND1      arc_1_17_7
 UP BND1      load_1_17_7  25
 BV BND1      arc_1_17_8
 UP BND1      load_1_17_8  25
 BV BND1      arc_1_17_9
 UP BND1      load_1_17_9  25
 BV BND1      arc_1_17_13
 UP BND1      load_1_17_13  25
 BV BND1      arc_1_17_14
 UP BND1      load_1_17_14  25
 BV BND1      arc_1_17_15
 UP BND1      load_1_17_15  25
 BV BND1      arc_1_17_16
 UP BND1      load_1_17_16  25
 BV BND1      arc_1_17_18
 UP BND1      load_1_17_18  25
 BV BND1      arc_1_17_19
 UP BND1      load_1_17_19  25
 BV BND1      arc_1_17_20
 UP BND1      load_1_17_20  25
 BV BND1      arc_1_18_0
 UP BND1      load_1_18_0  25
 BV BND1      arc_1_18_5
 UP BND1      load_1_18_5  25
 BV BND1      arc_1_18_6
 UP BND1      load_1_18_6  25
 BV BND1      arc_1_18_7
 UP BND1      load_1_18_7  25
 BV BND1      arc_1_18_8
 UP BND1      load_1_18_8  25
 BV BND1      arc_1_18_9
 UP BND1      load_1_18_9  25
 BV BND1      arc_1_18_13
 UP BND1      load_1_18_13  25
 BV BND1      arc_1_18_14
 UP BND1      load_1_18_14  25
 BV BND1      arc_1_18_15
 UP BND1      load_1_18_15  25
 BV BND1      arc_1_18_16
 UP BND1      load_1_18_16  25
 BV BND1      arc_1_18_17
 UP BND1      load_1_18_17  25
 BV BND1      arc_1_18_19
 UP BND1      load_1_18_19  25
 BV BND1      arc_1_18_20
 UP BND1      load_1_18_20  25
 BV BND1      arc_1_19_0
 UP BND1      load_1_19_0  25
 BV BND1      arc_1_19_5
 UP BND1      load_1_19_5  25
 BV BND1      arc_1_19_6
 UP BND1      load_1_19_6  25
 BV BND1      arc_1_19_7
 UP BND1      load_1_19_7  25
 BV BND1      arc_1_19_8
 UP BND1      load_1_19_8  25
 BV BND1      arc_1_19_9
 UP BND1      load_1_19_9  25
 BV BND1      arc_1_19_13
 UP BND1      load_1_19_13  25
 BV BND1      arc_1_19_14
 UP BND1      load_1_19_14  25
 BV BND1      arc_1_19_15
 UP BND1      load_1_19_15  25
 BV BND1      arc_1_19_16
 UP BND1      load_1_19_16  25
 BV BND1      arc_1_19_17
 UP BND1      load_1_19_17  25
 BV BND1      arc_1_19_18
 UP BND1      load_1_19_18  25
 BV BND1      arc_1_19_20
 UP BND1      load_1_19_20  25
 BV BND1      arc_1_20_0
 UP BND1      load_1_20_0  25
 BV BND1      arc_1_20_5
 UP BND1      load_1_20_5  25
 BV BND1      arc_1_20_6
 UP BND1      load_1_20_6  25
 BV BND1      arc_1_20_7
 UP BND1      load_1_20_7  25
 BV BND1      arc_1_20_8
 UP BND1      load_1_20_8  25
 BV BND1      arc_1_20_9
 UP BND1      load_1_20_9  25
 BV BND1      arc_1_20_13
 UP BND1      load_1_20_13  25
 BV BND1      arc_1_20_14
 UP BND1      load_1_20_14  25
 BV BND1      arc_1_20_15
 UP BND1      load_1_20_15  25
 BV BND1      arc_1_20_16
 UP BND1      load_1_20_16  25
 BV BND1      arc_1_20_17
 UP BND1      load_1_20_17  25
 BV BND1      arc_1_20_18
 UP BND1      load_1_20_18  25
 BV BND1      arc_1_20_19
 UP BND1      load_1_20_19  25
 FX BND1      visit_2_10  1
 UP BND1      order_2_10  11
 FX BND1      visit_2_11  1
 UP BND1      order_2_11  11
 FX BND1      visit_2_12  1
 UP BND1      order_2_12  11
 UP BND1      visit_2_13  1
 UP BND1      order_2_13  11
 UP BND1      visit_2_14  1
 UP BND1      order_2_14  11
 UP BND1      visit_2_15  1
 UP BND1      order_2_15  11
 UP BND1      visit_2_16  1
 UP BND1      order_2_16  11
 UP BND1      visit_2_17  1
 UP BND1      order_2_17  11
 UP BND1      visit_2_18  1
 UP BND1      order_2_18  11
 UP BND1      visit_2_19  1
 UP BND1      order_2_19  11
 UP BND1      visit_2_20  1
 UP BND1      order_2_20  11
 BV BND1      arc_2_0_0
 FX BND1      load_2_0_0  0
 BV BND1      arc_2_0_10
 FX BND1      load_2_0_10  0
 BV BND1      arc_2_0_11
 FX BND1      load_2_0_11  0
 BV BND1      arc_2_0_12
 FX BND1      load_2_0_12  0
 BV BND1      arc_2_0_13
 FX BND1      load_2_0_13  0
 BV BND1      arc_2_0_14
 FX BND1      load_2_0_14  0
 BV BND1      arc_2_0_15
 FX BND1      load_2_0_15  0
 BV BND1      arc_2_0_16
 FX BND1      load_2_0_16  0
 BV BND1      arc_2_0_17
 FX BND1      load_2_0_17  0
 BV BND1      arc_2_0_18
 FX BND1      load_2_0_18  0
 BV BND1      arc_2_0_19
 FX BND1      load_2_0_19  0
 BV BND1      arc_2_0_20
 FX BND1      load_2_0_20  0
 BV BND1      arc_2_10_0
 UP BND1      load_2_10_0  30
 BV BND1      arc_2_10_11
 UP BND1      load_2_10_11  30
 BV BND1      arc_2_10_12
 UP BND1      load_2_10_12  30
 BV BND1      arc_2_10_13
 UP BND1      load_2_10_13  30
 BV BND1      arc_2_10_14
 UP BND1      load_2_10_14  30
 BV BND1      arc_2_10_15
 UP BND1      load_2_10_15  30
 BV BND1      arc_2_10_16
 UP BND1      load_2_10_16  30
 BV BND1      arc_2_10_17
 UP BND1      load_2_10_17  30
 BV BND1      arc_2_10_18
 UP BND1      load_2_10_18  30
 BV BND1      arc_2_10_19
 UP BND1      load_2_10_19  30
 BV BND1      arc_2_10_20
 UP BND1      load_2_10_20  30
 BV BND1      arc_2_11_0
 UP BND1      load_2_11_0  30
 BV BND1      arc_2_11_10
 UP BND1      load_2_11_10  30
 BV BND1      arc_2_11_12
 UP BND1      load_2_11_12  30
 BV BND1      arc_2_11_13
 UP BND1      load_2_11_13  30
 BV BND1      arc_2_11_14
 UP BND1      load_2_11_14  30
 BV BND1      arc_2_11_15
 UP BND1      load_2_11_15  30
 BV BND1      arc_2_11_16
 UP BND1      load_2_11_16  30
 BV BND1      arc_2_11_17
 UP BND1      load_2_11_17  30
 BV BND1      arc_2_11_18
 UP BND1      load_2_11_18  30
 BV BND1      arc_2_11_19
 UP BND1      load_2_11_19  30
 BV BND1      arc_2_11_20
 UP BND1      load_2_11_20  30
 BV BND1      arc_2_12_0
 UP BND1      load_2_12_0  30
 BV BND1      arc_2_12_10
 UP BND1      load_2_12_10  30
 BV BND1      arc_2_12_11
 UP BND1      load_2_12_11  30
 BV BND1      arc_2_12_13
 UP BND1      load_2_12_13  30
 BV BND1      arc_2_12_14
 UP BND1      load_2_12_14  30
 BV BND1      arc_2_12_15
 UP BND1      load_2_12_15  30
 BV BND1      arc_2_12_16
 UP BND1      load_2_12_16  30
 BV BND1      arc_2_12_17
 UP BND1      load_2_12_17  30
 BV BND1      arc_2_12_18
 UP BND1      load_2_12_18  30
 BV BND1      arc_2_12_19
 UP BND1      load_2_12_19  30
 BV BND1      arc_2_12_20
 UP BND1      load_2_12_20  30
 BV BND1      arc_2_13_0
 UP BND1      load_2_13_0  30
 BV BND1      arc_2_13_10
 UP BND1      load_2_13_10  30
 BV BND1      arc_2_13_11
 UP BND1      load_2_13_11  30
 BV BND1      arc_2_13_12
 UP BND1      load_2_13_12  30
 BV BND1      arc_2_13_14
 UP BND1      load_2_13_14  30
 BV BND1      arc_2_13_15
 UP BND1      load_2_13_15  30
 BV BND1      arc_2_13_16
 UP BND1      load_2_13_16  30
 BV BND1      arc_2_13_17
 UP BND1      load_2_13_17  30
 BV BND1      arc_2_13_18
 UP BND1      load_2_13_18  30
 BV BND1      arc_2_13_19
 UP BND1      load_2_13_19  30
 BV BND1      arc_2_13_20
 UP BND1      load_2_13_20  30
 BV BND1      arc_2_14_0
 UP BND1      load_2_14_0  30
 BV BND1      arc_2_14_10
 UP BND1      load_2_14_10  30
 BV BND1      arc_2_14_11
 UP BND1      load_2_14_11  30
 BV BND1      arc_2_14_12
 UP BND1      load_2_14_12  30
 BV BND1      arc_2_14_13
 UP BND1      load_2_14_13  30
 BV BND1      arc_2_14_15
 UP BND1      load_2_14_15  30
 BV BND1      arc_2_14_16
 UP BND1      load_2_14_16  30
 BV BND1      arc_2_14_17
 UP BND1      load_2_14_17  30
 BV BND1      arc_2_14_18
 UP BND1      load_2_14_18  30
 BV BND1      arc_2_14_19
 UP BND1      load_2_14_19  30
 BV BND1      arc_2_14_20
 UP BND1      load_2_14_20  30
 BV BND1      arc_2_15_0
 UP BND1      load_2_15_0  30
 BV BND1      arc_2_15_10
 UP BND1      load_2_15_10  30
 BV BND1      arc_2_15_11
 UP BND1      load_2_15_11  30
 BV BND1      arc_2_15_12
 UP BND1      load_2_15_12  30
 BV BND1      arc_2_15_13
 UP BND1      load_2_15_13  30
 BV BND1      arc_2_15_14
 UP BND1      load_2_15_14  30
 BV BND1      arc_2_15_16
 UP BND1      load_2_15_16  30
 BV BND1      arc_2_15_17
 UP BND1      load_2_15_17  30
 BV BND1      arc_2_15_18
 UP BND1      load_2_15_18  30
 BV BND1      arc_2_15_19
 UP BND1      load_2_15_19  30
 BV BND1      arc_2_15_20
 UP BND1      load_2_15_20  30
 BV BND1      arc_2_16_0
 UP BND1      load_2_16_0  30
 BV BND1      arc_2_16_10
 UP BND1      load_2_16_10  30
 BV BND1      arc_2_16_11
 UP BND1      load_2_16_11  30
 BV BND1      arc_2_16_12
 UP BND1      load_2_16_12  30
 BV BND1      arc_2_16_13
 UP BND1      load_2_16_13  30
 BV BND1      arc_2_16_14
 UP BND1      load_2_16_14  30
 BV BND1      arc_2_16_15
 UP BND1      load_2_16_15  30
 BV BND1      arc_2_16_17
 UP BND1      load_2_16_17  30
 BV BND1      arc_2_16_18
 UP BND1      load_2_16_18  30
 BV BND1      arc_2_16_19
 UP BND1      load_2_16_19  30
 BV BND1      arc_2_16_20
 UP BND1      load_2_16_20  30
 BV BND1      arc_2_17_0
 UP BND1      load_2_17_0  30
 BV BND1      arc_2_17_10
 UP BND1      load_2_17_10  30
 BV BND1      arc_2_17_11
 UP BND1      load_2_17_11  30
 BV BND1      arc_2_17_12
 UP BND1      load_2_17_12  30
 BV BND1      arc_2_17_13
 UP BND1      load_2_17_13  30
 BV BND1      arc_2_17_14
 UP BND1      load_2_17_14  30
 BV BND1      arc_2_17_15
 UP BND1      load_2_17_15  30
 BV BND1      arc_2_17_16
 UP BND1      load_2_17_16  30
 BV BND1      arc_2_17_18
 UP BND1      load_2_17_18  30
 BV BND1      arc_2_17_19
 UP BND1      load_2_17_19  30
 BV BND1      arc_2_17_20
 UP BND1      load_2_17_20  30
 BV BND1      arc_2_18_0
 UP BND1      load_2_18_0  30
 BV BND1      arc_2_18_10
 UP BND1      load_2_18_10  30
 BV BND1      arc_2_18_11
 UP BND1      load_2_18_11  30
 BV BND1      arc_2_18_12
 UP BND1      load_2_18_12  30
 BV BND1      arc_2_18_13
 UP BND1      load_2_18_13  30
 BV BND1      arc_2_18_14
 UP BND1      load_2_18_14  30
 BV BND1      arc_2_18_15
 UP BND1      load_2_18_15  30
 BV BND1      arc_2_18_16
 UP BND1      load_2_18_16  30
 BV BND1      arc_2_18_17
 UP BND1      load_2_18_17  30
 BV BND1      arc_2_18_19
 UP BND1      load_2_18_19  30
 BV BND1      arc_2_18_20
 UP BND1      load_2_18_20  30
 BV BND1      arc_2_19_0
 UP BND1      load_2_19_0  30
 BV BND1      arc_2_19_10
 UP BND1      load_2_19_10  30
 BV BND1      arc_2_19_11
 UP BND1      load_2_19_11  30
 BV BND1      arc_2_19_12
 UP BND1      load_2_19_12  30
 BV BND1      arc_2_19_13
 UP BND1      load_2_19_13  30
 BV BND1      arc_2_19_14
 UP BND1      load_2_19_14  30
 BV BND1      arc_2_19_15
 UP BND1      load_2_19_15  30
 BV BND1      arc_2_19_16
 UP BND1      load_2_19_16  30
 BV BND1      arc_2_19_17
 UP BND1      load_2_19_17  30
 BV BND1      arc_2_19_18
 UP BND1      load_2_19_18  30
 BV BND1      arc_2_19_20
 UP BND1      load_2_19_20  30
 BV BND1      arc_2_20_0
 UP BND1      load_2_20_0  30
 BV BND1      arc_2_20_10
 UP BND1      load_2_20_10  30
 BV BND1      arc_2_20_11
 UP BND1      load_2_20_11  30
 BV BND1      arc_2_20_12
 UP BND1      load_2_20_12  30
 BV BND1      arc_2_20_13
 UP BND1      load_2_20_13  30
 BV BND1      arc_2_20_14
 UP BND1      load_2_20_14  30
 BV BND1      arc_2_20_15
 UP BND1      load_2_20_15  30
 BV BND1      arc_2_20_16
 UP BND1      load_2_20_16  30
 BV BND1      arc_2_20_17
 UP BND1      load_2_20_17  30
 BV BND1      arc_2_20_18
 UP BND1      load_2_20_18  30
 BV BND1      arc_2_20_19
 UP BND1      load_2_20_19  30
ENDATA
