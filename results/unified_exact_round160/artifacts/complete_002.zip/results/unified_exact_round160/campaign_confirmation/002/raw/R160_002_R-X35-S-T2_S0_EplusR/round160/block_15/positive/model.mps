* Signature: 0xf892cc0566e0fd24
NAME R160_physical_neighborhood
ROWS
 N  OBJ
 G  product_lb_0
 L  product_ub_1
 G  product_lb_2
 L  product_ub_3
 G  product_lb_4
 L  product_ub_5
 G  product_lb_6
 L  product_ub_7
 G  product_lb_8
 L  product_ub_9
 G  product_lb_10
 L  product_ub_11
 G  product_lb_12
 L  product_ub_13
 G  product_lb_14
 L  product_ub_15
 G  product_lb_16
 L  product_ub_17
 G  product_lb_18
 L  product_ub_19
 G  product_lb_20
 L  product_ub_21
 E  onehot_9_22
 E  normalized_mass_9_23
 E  normalized_ratio_9_24
 G  product_lb_25
 L  product_ub_26
 G  product_lb_27
 L  product_ub_28
 G  product_lb_29
 L  product_ub_30
 G  product_lb_31
 L  product_ub_32
 G  product_lb_33
 L  product_ub_34
 G  product_lb_35
 L  product_ub_36
 G  product_lb_37
 L  product_ub_38
 G  product_lb_39
 L  product_ub_40
 G  product_lb_41
 L  product_ub_42
 G  product_lb_43
 L  product_ub_44
 G  product_lb_45
 L  product_ub_46
 E  onehot_11_47
 E  normalized_mass_11_48
 E  normalized_ratio_11_49
 G  product_lb_50
 L  product_ub_51
 G  product_lb_52
 L  product_ub_53
 G  product_lb_54
 L  product_ub_55
 G  product_lb_56
 L  product_ub_57
 G  product_lb_58
 L  product_ub_59
 G  product_lb_60
 L  product_ub_61
 G  product_lb_62
 L  product_ub_63
 G  product_lb_64
 L  product_ub_65
 G  product_lb_66
 L  product_ub_67
 G  product_lb_68
 L  product_ub_69
 G  product_lb_70
 L  product_ub_71
 G  product_lb_72
 L  product_ub_73
 G  product_lb_74
 L  product_ub_75
 G  product_lb_76
 L  product_ub_77
 G  product_lb_78
 L  product_ub_79
 G  product_lb_80
 L  product_ub_81
 E  onehot_34_82
 E  normalized_mass_34_83
 E  normalized_ratio_34_84
 G  product_lb_85
 L  product_ub_86
 G  product_lb_87
 L  product_ub_88
 G  product_lb_89
 L  product_ub_90
 G  product_lb_91
 L  product_ub_92
 G  product_lb_93
 L  product_ub_94
 G  product_lb_95
 L  product_ub_96
 G  product_lb_97
 L  product_ub_98
 E  onehot_10_99
 E  normalized_mass_10_100
 E  normalized_ratio_10_101
 G  product_lb_102
 L  product_ub_103
 G  product_lb_104
 L  product_ub_105
 G  product_lb_106
 L  product_ub_107
 G  product_lb_108
 L  product_ub_109
 G  product_lb_110
 L  product_ub_111
 G  product_lb_112
 L  product_ub_113
 G  product_lb_114
 L  product_ub_115
 G  product_lb_116
 L  product_ub_117
 G  product_lb_118
 L  product_ub_119
 G  product_lb_120
 L  product_ub_121
 G  product_lb_122
 L  product_ub_123
 E  onehot_29_124
 E  normalized_mass_29_125
 E  normalized_ratio_29_126
 G  product_lb_127
 L  product_ub_128
 G  product_lb_129
 L  product_ub_130
 G  product_lb_131
 L  product_ub_132
 G  product_lb_133
 L  product_ub_134
 G  product_lb_135
 L  product_ub_136
 G  product_lb_137
 L  product_ub_138
 G  product_lb_139
 L  product_ub_140
 G  product_lb_141
 L  product_ub_142
 G  product_lb_143
 L  product_ub_144
 E  onehot_13_145
 E  normalized_mass_13_146
 E  normalized_ratio_13_147
 G  product_lb_148
 L  product_ub_149
 G  product_lb_150
 L  product_ub_151
 G  product_lb_152
 L  product_ub_153
 G  product_lb_154
 L  product_ub_155
 G  product_lb_156
 L  product_ub_157
 G  product_lb_158
 L  product_ub_159
 G  product_lb_160
 L  product_ub_161
 E  onehot_27_162
 E  normalized_mass_27_163
 E  normalized_ratio_27_164
 G  product_lb_165
 L  product_ub_166
 G  product_lb_167
 L  product_ub_168
 G  product_lb_169
 L  product_ub_170
 G  product_lb_171
 L  product_ub_172
 G  product_lb_173
 L  product_ub_174
 G  product_lb_175
 L  product_ub_176
 G  product_lb_177
 L  product_ub_178
 G  product_lb_179
 L  product_ub_180
 G  product_lb_181
 L  product_ub_182
 G  product_lb_183
 L  product_ub_184
 G  product_lb_185
 L  product_ub_186
 G  product_lb_187
 L  product_ub_188
 G  product_lb_189
 L  product_ub_190
 E  onehot_8_191
 E  normalized_mass_8_192
 E  normalized_ratio_8_193
 G  stock_lb_194
 L  stock_ub_195
 L  parent_nonstrict_scope_196
 G  block_pair_pos_197
 G  block_pair_neg_198
 G  block_pair_pos_199
 G  block_pair_neg_200
 G  block_pair_pos_201
 G  block_pair_neg_202
 G  block_pair_pos_203
 G  block_pair_neg_204
 G  block_pair_pos_205
 G  block_pair_neg_206
 G  block_pair_pos_207
 G  block_pair_neg_208
 G  block_pair_pos_209
 G  block_pair_neg_210
 G  block_pair_pos_211
 G  block_pair_neg_212
 G  block_pair_pos_213
 G  block_pair_neg_214
 G  block_pair_pos_215
 G  block_pair_neg_216
 G  block_pair_pos_217
 G  block_pair_neg_218
 G  block_pair_pos_219
 G  block_pair_neg_220
 G  block_pair_pos_221
 G  block_pair_neg_222
 G  block_pair_pos_223
 G  block_pair_neg_224
 G  block_pair_pos_225
 G  block_pair_neg_226
 G  block_pair_pos_227
 G  block_pair_neg_228
 G  block_pair_pos_229
 G  block_pair_neg_230
 G  block_pair_pos_231
 G  block_pair_neg_232
 G  block_pair_pos_233
 G  block_pair_neg_234
 G  block_pair_pos_235
 G  block_pair_neg_236
 G  block_pair_pos_237
 G  block_pair_neg_238
 G  block_pair_pos_239
 G  block_pair_neg_240
 G  block_pair_pos_241
 G  block_pair_neg_242
 G  block_pair_pos_243
 G  block_pair_neg_244
 G  block_pair_pos_245
 G  block_pair_neg_246
 G  block_pair_pos_247
 G  block_pair_neg_248
 G  block_pair_pos_249
 G  block_pair_neg_250
 G  block_pair_pos_251
 G  block_pair_neg_252
 E  normalization_253
 G  full_original_Gini_254
 E  unique_nonzero_owner_255
 E  unique_nonzero_owner_256
 E  unique_nonzero_owner_257
 E  unique_nonzero_owner_258
 E  unique_nonzero_owner_259
 E  unique_nonzero_owner_260
 E  unique_nonzero_owner_261
 E  unique_nonzero_owner_262
 E  unique_nonzero_owner_263
 E  unique_nonzero_owner_264
 E  unique_nonzero_owner_265
 E  unique_nonzero_owner_266
 E  unique_nonzero_owner_267
 E  unique_nonzero_owner_268
 E  unique_nonzero_owner_269
 E  unique_nonzero_owner_270
 E  unique_nonzero_owner_271
 E  unique_nonzero_owner_272
 E  unique_nonzero_owner_273
 E  unique_nonzero_owner_274
 E  unique_nonzero_owner_275
 E  unique_nonzero_owner_276
 E  unique_nonzero_owner_277
 E  unique_nonzero_owner_278
 E  unique_nonzero_owner_279
 E  unique_nonzero_owner_280
 E  unique_nonzero_owner_281
 E  unique_nonzero_owner_282
 E  unique_nonzero_owner_283
 E  unique_nonzero_owner_284
 E  unique_nonzero_owner_285
 E  unique_nonzero_owner_286
 E  unique_nonzero_owner_287
 E  unique_nonzero_owner_288
 E  unique_nonzero_owner_289
 E  unique_nonzero_owner_290
 E  unique_nonzero_owner_291
 E  unique_nonzero_owner_292
 E  unique_nonzero_owner_293
 E  unique_nonzero_owner_294
 E  unique_nonzero_owner_295
 E  unique_nonzero_owner_296
 E  unique_nonzero_owner_297
 E  unique_nonzero_owner_298
 E  unique_nonzero_owner_299
 E  unique_nonzero_owner_300
 E  unique_nonzero_owner_301
 E  unique_nonzero_owner_302
 E  unique_nonzero_owner_303
 E  unique_nonzero_owner_304
 E  unique_nonzero_owner_305
 E  unique_nonzero_owner_306
 E  unique_nonzero_owner_307
 E  unique_nonzero_owner_308
 E  unique_nonzero_owner_309
 E  unique_nonzero_owner_310
 E  unique_nonzero_owner_311
 E  unique_nonzero_owner_312
 E  unique_nonzero_owner_313
 E  unique_nonzero_owner_314
 E  unique_nonzero_owner_315
 E  unique_nonzero_owner_316
 E  unique_nonzero_owner_317
 E  unique_nonzero_owner_318
 E  unique_nonzero_owner_319
 E  unique_nonzero_owner_320
 E  unique_nonzero_owner_321
 E  unique_nonzero_owner_322
 E  unique_nonzero_owner_323
 E  unique_nonzero_owner_324
 E  unique_nonzero_owner_325
 E  unique_nonzero_owner_326
 E  unique_nonzero_owner_327
 E  unique_nonzero_owner_328
 E  unique_nonzero_owner_329
 E  unique_nonzero_owner_330
 E  unique_nonzero_owner_331
 L  arc_capacity_332
 L  arc_capacity_333
 L  arc_capacity_334
 L  arc_capacity_335
 L  arc_capacity_336
 L  arc_capacity_337
 L  arc_capacity_338
 L  arc_capacity_339
 L  arc_capacity_340
 L  arc_capacity_341
 L  arc_capacity_342
 L  arc_capacity_343
 L  arc_capacity_344
 L  arc_capacity_345
 L  arc_capacity_346
 L  arc_capacity_347
 G  connected_order_arc_348
 L  arc_capacity_349
 G  connected_order_arc_350
 L  arc_capacity_351
 G  connected_order_arc_352
 L  arc_capacity_353
 G  connected_order_arc_354
 L  arc_capacity_355
 G  connected_order_arc_356
 L  arc_capacity_357
 G  connected_order_arc_358
 L  arc_capacity_359
 G  connected_order_arc_360
 L  arc_capacity_361
 G  connected_order_arc_362
 L  arc_capacity_363
 G  connected_order_arc_364
 L  arc_capacity_365
 G  connected_order_arc_366
 L  arc_capacity_367
 G  connected_order_arc_368
 L  arc_capacity_369
 G  connected_order_arc_370
 L  arc_capacity_371
 L  arc_capacity_372
 G  connected_order_arc_373
 L  arc_capacity_374
 G  connected_order_arc_375
 L  arc_capacity_376
 G  connected_order_arc_377
 L  arc_capacity_378
 G  connected_order_arc_379
 L  arc_capacity_380
 G  connected_order_arc_381
 L  arc_capacity_382
 G  connected_order_arc_383
 L  arc_capacity_384
 G  connected_order_arc_385
 L  arc_capacity_386
 G  connected_order_arc_387
 L  arc_capacity_388
 G  connected_order_arc_389
 L  arc_capacity_390
 G  connected_order_arc_391
 L  arc_capacity_392
 G  connected_order_arc_393
 L  arc_capacity_394
 G  connected_order_arc_395
 L  arc_capacity_396
 L  arc_capacity_397
 G  connected_order_arc_398
 L  arc_capacity_399
 G  connected_order_arc_400
 L  arc_capacity_401
 G  connected_order_arc_402
 L  arc_capacity_403
 G  connected_order_arc_404
 L  arc_capacity_405
 G  connected_order_arc_406
 L  arc_capacity_407
 G  connected_order_arc_408
 L  arc_capacity_409
 G  connected_order_arc_410
 L  arc_capacity_411
 G  connected_order_arc_412
 L  arc_capacity_413
 G  connected_order_arc_414
 L  arc_capacity_415
 G  connected_order_arc_416
 L  arc_capacity_417
 G  connected_order_arc_418
 L  arc_capacity_419
 G  connected_order_arc_420
 L  arc_capacity_421
 L  arc_capacity_422
 G  connected_order_arc_423
 L  arc_capacity_424
 G  connected_order_arc_425
 L  arc_capacity_426
 G  connected_order_arc_427
 L  arc_capacity_428
 G  connected_order_arc_429
 L  arc_capacity_430
 G  connected_order_arc_431
 L  arc_capacity_432
 G  connected_order_arc_433
 L  arc_capacity_434
 G  connected_order_arc_435
 L  arc_capacity_436
 G  connected_order_arc_437
 L  arc_capacity_438
 G  connected_order_arc_439
 L  arc_capacity_440
 G  connected_order_arc_441
 L  arc_capacity_442
 G  connected_order_arc_443
 L  arc_capacity_444
 G  connected_order_arc_445
 L  arc_capacity_446
 L  arc_capacity_447
 G  connected_order_arc_448
 L  arc_capacity_449
 G  connected_order_arc_450
 L  arc_capacity_451
 G  connected_order_arc_452
 L  arc_capacity_453
 G  connected_order_arc_454
 L  arc_capacity_455
 G  connected_order_arc_456
 L  arc_capacity_457
 G  connected_order_arc_458
 L  arc_capacity_459
 G  connected_order_arc_460
 L  arc_capacity_461
 G  connected_order_arc_462
 L  arc_capacity_463
 G  connected_order_arc_464
 L  arc_capacity_465
 G  connected_order_arc_466
 L  arc_capacity_467
 G  connected_order_arc_468
 L  arc_capacity_469
 G  connected_order_arc_470
 L  arc_capacity_471
 L  arc_capacity_472
 G  connected_order_arc_473
 L  arc_capacity_474
 G  connected_order_arc_475
 L  arc_capacity_476
 G  connected_order_arc_477
 L  arc_capacity_478
 G  connected_order_arc_479
 L  arc_capacity_480
 G  connected_order_arc_481
 L  arc_capacity_482
 G  connected_order_arc_483
 L  arc_capacity_484
 G  connected_order_arc_485
 L  arc_capacity_486
 G  connected_order_arc_487
 L  arc_capacity_488
 G  connected_order_arc_489
 L  arc_capacity_490
 G  connected_order_arc_491
 L  arc_capacity_492
 G  connected_order_arc_493
 L  arc_capacity_494
 G  connected_order_arc_495
 L  arc_capacity_496
 L  arc_capacity_497
 G  connected_order_arc_498
 L  arc_capacity_499
 G  connected_order_arc_500
 L  arc_capacity_501
 G  connected_order_arc_502
 L  arc_capacity_503
 G  connected_order_arc_504
 L  arc_capacity_505
 G  connected_order_arc_506
 L  arc_capacity_507
 G  connected_order_arc_508
 L  arc_capacity_509
 G  connected_order_arc_510
 L  arc_capacity_511
 G  connected_order_arc_512
 L  arc_capacity_513
 G  connected_order_arc_514
 L  arc_capacity_515
 G  connected_order_arc_516
 L  arc_capacity_517
 G  connected_order_arc_518
 L  arc_capacity_519
 G  connected_order_arc_520
 L  arc_capacity_521
 L  arc_capacity_522
 G  connected_order_arc_523
 L  arc_capacity_524
 G  connected_order_arc_525
 L  arc_capacity_526
 G  connected_order_arc_527
 L  arc_capacity_528
 G  connected_order_arc_529
 L  arc_capacity_530
 G  connected_order_arc_531
 L  arc_capacity_532
 G  connected_order_arc_533
 L  arc_capacity_534
 G  connected_order_arc_535
 L  arc_capacity_536
 G  connected_order_arc_537
 L  arc_capacity_538
 G  connected_order_arc_539
 L  arc_capacity_540
 G  connected_order_arc_541
 L  arc_capacity_542
 G  connected_order_arc_543
 L  arc_capacity_544
 G  connected_order_arc_545
 L  arc_capacity_546
 L  arc_capacity_547
 G  connected_order_arc_548
 L  arc_capacity_549
 G  connected_order_arc_550
 L  arc_capacity_551
 G  connected_order_arc_552
 L  arc_capacity_553
 G  connected_order_arc_554
 L  arc_capacity_555
 G  connected_order_arc_556
 L  arc_capacity_557
 G  connected_order_arc_558
 L  arc_capacity_559
 G  connected_order_arc_560
 L  arc_capacity_561
 G  connected_order_arc_562
 L  arc_capacity_563
 G  connected_order_arc_564
 L  arc_capacity_565
 G  connected_order_arc_566
 L  arc_capacity_567
 G  connected_order_arc_568
 L  arc_capacity_569
 G  connected_order_arc_570
 L  arc_capacity_571
 L  arc_capacity_572
 G  connected_order_arc_573
 L  arc_capacity_574
 G  connected_order_arc_575
 L  arc_capacity_576
 G  connected_order_arc_577
 L  arc_capacity_578
 G  connected_order_arc_579
 L  arc_capacity_580
 G  connected_order_arc_581
 L  arc_capacity_582
 G  connected_order_arc_583
 L  arc_capacity_584
 G  connected_order_arc_585
 L  arc_capacity_586
 G  connected_order_arc_587
 L  arc_capacity_588
 G  connected_order_arc_589
 L  arc_capacity_590
 G  connected_order_arc_591
 L  arc_capacity_592
 G  connected_order_arc_593
 L  arc_capacity_594
 G  connected_order_arc_595
 L  arc_capacity_596
 L  arc_capacity_597
 G  connected_order_arc_598
 L  arc_capacity_599
 G  connected_order_arc_600
 L  arc_capacity_601
 G  connected_order_arc_602
 L  arc_capacity_603
 G  connected_order_arc_604
 L  arc_capacity_605
 G  connected_order_arc_606
 L  arc_capacity_607
 G  connected_order_arc_608
 L  arc_capacity_609
 G  connected_order_arc_610
 L  arc_capacity_611
 G  connected_order_arc_612
 L  arc_capacity_613
 G  connected_order_arc_614
 L  arc_capacity_615
 G  connected_order_arc_616
 L  arc_capacity_617
 G  connected_order_arc_618
 L  arc_capacity_619
 G  connected_order_arc_620
 L  arc_capacity_621
 L  arc_capacity_622
 G  connected_order_arc_623
 L  arc_capacity_624
 G  connected_order_arc_625
 L  arc_capacity_626
 G  connected_order_arc_627
 L  arc_capacity_628
 G  connected_order_arc_629
 L  arc_capacity_630
 G  connected_order_arc_631
 L  arc_capacity_632
 G  connected_order_arc_633
 L  arc_capacity_634
 G  connected_order_arc_635
 L  arc_capacity_636
 G  connected_order_arc_637
 L  arc_capacity_638
 G  connected_order_arc_639
 L  arc_capacity_640
 G  connected_order_arc_641
 L  arc_capacity_642
 G  connected_order_arc_643
 L  arc_capacity_644
 G  connected_order_arc_645
 L  arc_capacity_646
 L  arc_capacity_647
 G  connected_order_arc_648
 L  arc_capacity_649
 G  connected_order_arc_650
 L  arc_capacity_651
 G  connected_order_arc_652
 L  arc_capacity_653
 G  connected_order_arc_654
 L  arc_capacity_655
 G  connected_order_arc_656
 L  arc_capacity_657
 G  connected_order_arc_658
 L  arc_capacity_659
 G  connected_order_arc_660
 L  arc_capacity_661
 G  connected_order_arc_662
 L  arc_capacity_663
 G  connected_order_arc_664
 L  arc_capacity_665
 G  connected_order_arc_666
 L  arc_capacity_667
 G  connected_order_arc_668
 L  arc_capacity_669
 G  connected_order_arc_670
 E  depot_departure_or_bypass_671
 E  depot_return_or_bypass_672
 E  out_degree_673
 E  in_degree_674
 G  order_active_lb_675
 L  order_active_ub_676
 E  segment_load_conservation_677
 G  segment_prefix_lb_678
 L  segment_prefix_ub_679
 E  out_degree_680
 E  in_degree_681
 G  order_active_lb_682
 L  order_active_ub_683
 E  segment_load_conservation_684
 G  segment_prefix_lb_685
 L  segment_prefix_ub_686
 E  out_degree_687
 E  in_degree_688
 G  order_active_lb_689
 L  order_active_ub_690
 E  segment_load_conservation_691
 G  segment_prefix_lb_692
 L  segment_prefix_ub_693
 E  out_degree_694
 E  in_degree_695
 G  order_active_lb_696
 L  order_active_ub_697
 E  segment_load_conservation_698
 G  segment_prefix_lb_699
 L  segment_prefix_ub_700
 E  out_degree_701
 E  in_degree_702
 G  order_active_lb_703
 L  order_active_ub_704
 E  segment_load_conservation_705
 G  segment_prefix_lb_706
 L  segment_prefix_ub_707
 E  out_degree_708
 E  in_degree_709
 G  order_active_lb_710
 L  order_active_ub_711
 E  service_visit_def_712
 E  free_load_conservation_713
 E  out_degree_714
 E  in_degree_715
 G  order_active_lb_716
 L  order_active_ub_717
 E  service_visit_def_718
 E  free_load_conservation_719
 E  out_degree_720
 E  in_degree_721
 G  order_active_lb_722
 L  order_active_ub_723
 E  service_visit_def_724
 E  free_load_conservation_725
 E  out_degree_726
 E  in_degree_727
 G  order_active_lb_728
 L  order_active_ub_729
 E  service_visit_def_730
 E  free_load_conservation_731
 E  out_degree_732
 E  in_degree_733
 G  order_active_lb_734
 L  order_active_ub_735
 E  service_visit_def_736
 E  free_load_conservation_737
 E  out_degree_738
 E  in_degree_739
 G  order_active_lb_740
 L  order_active_ub_741
 E  service_visit_def_742
 E  free_load_conservation_743
 E  out_degree_744
 E  in_degree_745
 G  order_active_lb_746
 L  order_active_ub_747
 E  service_visit_def_748
 E  free_load_conservation_749
 E  out_degree_750
 E  in_degree_751
 G  order_active_lb_752
 L  order_active_ub_753
 E  service_visit_def_754
 E  free_load_conservation_755
 G  fixed_segment_relative_order_756
 G  fixed_segment_relative_order_757
 G  fixed_segment_relative_order_758
 G  fixed_segment_relative_order_759
 L  original_T_including_depot_unload_760
 L  arc_capacity_761
 L  arc_capacity_762
 L  arc_capacity_763
 L  arc_capacity_764
 L  arc_capacity_765
 L  arc_capacity_766
 L  arc_capacity_767
 L  arc_capacity_768
 L  arc_capacity_769
 L  arc_capacity_770
 L  arc_capacity_771
 L  arc_capacity_772
 L  arc_capacity_773
 L  arc_capacity_774
 L  arc_capacity_775
 G  connected_order_arc_776
 L  arc_capacity_777
 G  connected_order_arc_778
 L  arc_capacity_779
 G  connected_order_arc_780
 L  arc_capacity_781
 G  connected_order_arc_782
 L  arc_capacity_783
 G  connected_order_arc_784
 L  arc_capacity_785
 G  connected_order_arc_786
 L  arc_capacity_787
 G  connected_order_arc_788
 L  arc_capacity_789
 G  connected_order_arc_790
 L  arc_capacity_791
 G  connected_order_arc_792
 L  arc_capacity_793
 G  connected_order_arc_794
 L  arc_capacity_795
 G  connected_order_arc_796
 L  arc_capacity_797
 L  arc_capacity_798
 G  connected_order_arc_799
 L  arc_capacity_800
 G  connected_order_arc_801
 L  arc_capacity_802
 G  connected_order_arc_803
 L  arc_capacity_804
 G  connected_order_arc_805
 L  arc_capacity_806
 G  connected_order_arc_807
 L  arc_capacity_808
 G  connected_order_arc_809
 L  arc_capacity_810
 G  connected_order_arc_811
 L  arc_capacity_812
 G  connected_order_arc_813
 L  arc_capacity_814
 G  connected_order_arc_815
 L  arc_capacity_816
 G  connected_order_arc_817
 L  arc_capacity_818
 G  connected_order_arc_819
 L  arc_capacity_820
 L  arc_capacity_821
 G  connected_order_arc_822
 L  arc_capacity_823
 G  connected_order_arc_824
 L  arc_capacity_825
 G  connected_order_arc_826
 L  arc_capacity_827
 G  connected_order_arc_828
 L  arc_capacity_829
 G  connected_order_arc_830
 L  arc_capacity_831
 G  connected_order_arc_832
 L  arc_capacity_833
 G  connected_order_arc_834
 L  arc_capacity_835
 G  connected_order_arc_836
 L  arc_capacity_837
 G  connected_order_arc_838
 L  arc_capacity_839
 G  connected_order_arc_840
 L  arc_capacity_841
 G  connected_order_arc_842
 L  arc_capacity_843
 L  arc_capacity_844
 G  connected_order_arc_845
 L  arc_capacity_846
 G  connected_order_arc_847
 L  arc_capacity_848
 G  connected_order_arc_849
 L  arc_capacity_850
 G  connected_order_arc_851
 L  arc_capacity_852
 G  connected_order_arc_853
 L  arc_capacity_854
 G  connected_order_arc_855
 L  arc_capacity_856
 G  connected_order_arc_857
 L  arc_capacity_858
 G  connected_order_arc_859
 L  arc_capacity_860
 G  connected_order_arc_861
 L  arc_capacity_862
 G  connected_order_arc_863
 L  arc_capacity_864
 G  connected_order_arc_865
 L  arc_capacity_866
 L  arc_capacity_867
 G  connected_order_arc_868
 L  arc_capacity_869
 G  connected_order_arc_870
 L  arc_capacity_871
 G  connected_order_arc_872
 L  arc_capacity_873
 G  connected_order_arc_874
 L  arc_capacity_875
 G  connected_order_arc_876
 L  arc_capacity_877
 G  connected_order_arc_878
 L  arc_capacity_879
 G  connected_order_arc_880
 L  arc_capacity_881
 G  connected_order_arc_882
 L  arc_capacity_883
 G  connected_order_arc_884
 L  arc_capacity_885
 G  connected_order_arc_886
 L  arc_capacity_887
 G  connected_order_arc_888
 L  arc_capacity_889
 L  arc_capacity_890
 G  connected_order_arc_891
 L  arc_capacity_892
 G  connected_order_arc_893
 L  arc_capacity_894
 G  connected_order_arc_895
 L  arc_capacity_896
 G  connected_order_arc_897
 L  arc_capacity_898
 G  connected_order_arc_899
 L  arc_capacity_900
 G  connected_order_arc_901
 L  arc_capacity_902
 G  connected_order_arc_903
 L  arc_capacity_904
 G  connected_order_arc_905
 L  arc_capacity_906
 G  connected_order_arc_907
 L  arc_capacity_908
 G  connected_order_arc_909
 L  arc_capacity_910
 G  connected_order_arc_911
 L  arc_capacity_912
 L  arc_capacity_913
 G  connected_order_arc_914
 L  arc_capacity_915
 G  connected_order_arc_916
 L  arc_capacity_917
 G  connected_order_arc_918
 L  arc_capacity_919
 G  connected_order_arc_920
 L  arc_capacity_921
 G  connected_order_arc_922
 L  arc_capacity_923
 G  connected_order_arc_924
 L  arc_capacity_925
 G  connected_order_arc_926
 L  arc_capacity_927
 G  connected_order_arc_928
 L  arc_capacity_929
 G  connected_order_arc_930
 L  arc_capacity_931
 G  connected_order_arc_932
 L  arc_capacity_933
 G  connected_order_arc_934
 L  arc_capacity_935
 L  arc_capacity_936
 G  connected_order_arc_937
 L  arc_capacity_938
 G  connected_order_arc_939
 L  arc_capacity_940
 G  connected_order_arc_941
 L  arc_capacity_942
 G  connected_order_arc_943
 L  arc_capacity_944
 G  connected_order_arc_945
 L  arc_capacity_946
 G  connected_order_arc_947
 L  arc_capacity_948
 G  connected_order_arc_949
 L  arc_capacity_950
 G  connected_order_arc_951
 L  arc_capacity_952
 G  connected_order_arc_953
 L  arc_capacity_954
 G  connected_order_arc_955
 L  arc_capacity_956
 G  connected_order_arc_957
 L  arc_capacity_958
 L  arc_capacity_959
 G  connected_order_arc_960
 L  arc_capacity_961
 G  connected_order_arc_962
 L  arc_capacity_963
 G  connected_order_arc_964
 L  arc_capacity_965
 G  connected_order_arc_966
 L  arc_capacity_967
 G  connected_order_arc_968
 L  arc_capacity_969
 G  connected_order_arc_970
 L  arc_capacity_971
 G  connected_order_arc_972
 L  arc_capacity_973
 G  connected_order_arc_974
 L  arc_capacity_975
 G  connected_order_arc_976
 L  arc_capacity_977
 G  connected_order_arc_978
 L  arc_capacity_979
 G  connected_order_arc_980
 L  arc_capacity_981
 L  arc_capacity_982
 G  connected_order_arc_983
 L  arc_capacity_984
 G  connected_order_arc_985
 L  arc_capacity_986
 G  connected_order_arc_987
 L  arc_capacity_988
 G  connected_order_arc_989
 L  arc_capacity_990
 G  connected_order_arc_991
 L  arc_capacity_992
 G  connected_order_arc_993
 L  arc_capacity_994
 G  connected_order_arc_995
 L  arc_capacity_996
 G  connected_order_arc_997
 L  arc_capacity_998
 G  connected_order_arc_999
 L  arc_capacity_1000
 G  connected_order_arc_1001
 L  arc_capacity_1002
 G  connected_order_arc_1003
 L  arc_capacity_1004
 L  arc_capacity_1005
 G  connected_order_arc_1006
 L  arc_capacity_1007
 G  connected_order_arc_1008
 L  arc_capacity_1009
 G  connected_order_arc_1010
 L  arc_capacity_1011
 G  connected_order_arc_1012
 L  arc_capacity_1013
 G  connected_order_arc_1014
 L  arc_capacity_1015
 G  connected_order_arc_1016
 L  arc_capacity_1017
 G  connected_order_arc_1018
 L  arc_capacity_1019
 G  connected_order_arc_1020
 L  arc_capacity_1021
 G  connected_order_arc_1022
 L  arc_capacity_1023
 G  connected_order_arc_1024
 L  arc_capacity_1025
 G  connected_order_arc_1026
 L  arc_capacity_1027
 L  arc_capacity_1028
 G  connected_order_arc_1029
 L  arc_capacity_1030
 G  connected_order_arc_1031
 L  arc_capacity_1032
 G  connected_order_arc_1033
 L  arc_capacity_1034
 G  connected_order_arc_1035
 L  arc_capacity_1036
 G  connected_order_arc_1037
 L  arc_capacity_1038
 G  connected_order_arc_1039
 L  arc_capacity_1040
 G  connected_order_arc_1041
 L  arc_capacity_1042
 G  connected_order_arc_1043
 L  arc_capacity_1044
 G  connected_order_arc_1045
 L  arc_capacity_1046
 G  connected_order_arc_1047
 L  arc_capacity_1048
 G  connected_order_arc_1049
 E  depot_departure_or_bypass_1050
 E  depot_return_or_bypass_1051
 E  out_degree_1052
 E  in_degree_1053
 G  order_active_lb_1054
 L  order_active_ub_1055
 E  segment_load_conservation_1056
 G  segment_prefix_lb_1057
 L  segment_prefix_ub_1058
 E  out_degree_1059
 E  in_degree_1060
 G  order_active_lb_1061
 L  order_active_ub_1062
 E  segment_load_conservation_1063
 G  segment_prefix_lb_1064
 L  segment_prefix_ub_1065
 E  out_degree_1066
 E  in_degree_1067
 G  order_active_lb_1068
 L  order_active_ub_1069
 E  segment_load_conservation_1070
 G  segment_prefix_lb_1071
 L  segment_prefix_ub_1072
 E  out_degree_1073
 E  in_degree_1074
 G  order_active_lb_1075
 L  order_active_ub_1076
 E  segment_load_conservation_1077
 G  segment_prefix_lb_1078
 L  segment_prefix_ub_1079
 E  out_degree_1080
 E  in_degree_1081
 G  order_active_lb_1082
 L  order_active_ub_1083
 E  service_visit_def_1084
 E  free_load_conservation_1085
 E  out_degree_1086
 E  in_degree_1087
 G  order_active_lb_1088
 L  order_active_ub_1089
 E  service_visit_def_1090
 E  free_load_conservation_1091
 E  out_degree_1092
 E  in_degree_1093
 G  order_active_lb_1094
 L  order_active_ub_1095
 E  service_visit_def_1096
 E  free_load_conservation_1097
 E  out_degree_1098
 E  in_degree_1099
 G  order_active_lb_1100
 L  order_active_ub_1101
 E  service_visit_def_1102
 E  free_load_conservation_1103
 E  out_degree_1104
 E  in_degree_1105
 G  order_active_lb_1106
 L  order_active_ub_1107
 E  service_visit_def_1108
 E  free_load_conservation_1109
 E  out_degree_1110
 E  in_degree_1111
 G  order_active_lb_1112
 L  order_active_ub_1113
 E  service_visit_def_1114
 E  free_load_conservation_1115
 E  out_degree_1116
 E  in_degree_1117
 G  order_active_lb_1118
 L  order_active_ub_1119
 E  service_visit_def_1120
 E  free_load_conservation_1121
 E  out_degree_1122
 E  in_degree_1123
 G  order_active_lb_1124
 L  order_active_ub_1125
 E  service_visit_def_1126
 E  free_load_conservation_1127
 G  fixed_segment_relative_order_1128
 G  fixed_segment_relative_order_1129
 G  fixed_segment_relative_order_1130
 L  original_T_including_depot_unload_1131
 L  arc_capacity_1132
 L  arc_capacity_1133
 L  arc_capacity_1134
 L  arc_capacity_1135
 L  arc_capacity_1136
 L  arc_capacity_1137
 L  arc_capacity_1138
 L  arc_capacity_1139
 L  arc_capacity_1140
 L  arc_capacity_1141
 L  arc_capacity_1142
 L  arc_capacity_1143
 L  arc_capacity_1144
 L  arc_capacity_1145
 G  connected_order_arc_1146
 L  arc_capacity_1147
 G  connected_order_arc_1148
 L  arc_capacity_1149
 G  connected_order_arc_1150
 L  arc_capacity_1151
 G  connected_order_arc_1152
 L  arc_capacity_1153
 G  connected_order_arc_1154
 L  arc_capacity_1155
 G  connected_order_arc_1156
 L  arc_capacity_1157
 G  connected_order_arc_1158
 L  arc_capacity_1159
 G  connected_order_arc_1160
 L  arc_capacity_1161
 G  connected_order_arc_1162
 L  arc_capacity_1163
 G  connected_order_arc_1164
 L  arc_capacity_1165
 L  arc_capacity_1166
 G  connected_order_arc_1167
 L  arc_capacity_1168
 G  connected_order_arc_1169
 L  arc_capacity_1170
 G  connected_order_arc_1171
 L  arc_capacity_1172
 G  connected_order_arc_1173
 L  arc_capacity_1174
 G  connected_order_arc_1175
 L  arc_capacity_1176
 G  connected_order_arc_1177
 L  arc_capacity_1178
 G  connected_order_arc_1179
 L  arc_capacity_1180
 G  connected_order_arc_1181
 L  arc_capacity_1182
 G  connected_order_arc_1183
 L  arc_capacity_1184
 G  connected_order_arc_1185
 L  arc_capacity_1186
 L  arc_capacity_1187
 G  connected_order_arc_1188
 L  arc_capacity_1189
 G  connected_order_arc_1190
 L  arc_capacity_1191
 G  connected_order_arc_1192
 L  arc_capacity_1193
 G  connected_order_arc_1194
 L  arc_capacity_1195
 G  connected_order_arc_1196
 L  arc_capacity_1197
 G  connected_order_arc_1198
 L  arc_capacity_1199
 G  connected_order_arc_1200
 L  arc_capacity_1201
 G  connected_order_arc_1202
 L  arc_capacity_1203
 G  connected_order_arc_1204
 L  arc_capacity_1205
 G  connected_order_arc_1206
 L  arc_capacity_1207
 L  arc_capacity_1208
 G  connected_order_arc_1209
 L  arc_capacity_1210
 G  connected_order_arc_1211
 L  arc_capacity_1212
 G  connected_order_arc_1213
 L  arc_capacity_1214
 G  connected_order_arc_1215
 L  arc_capacity_1216
 G  connected_order_arc_1217
 L  arc_capacity_1218
 G  connected_order_arc_1219
 L  arc_capacity_1220
 G  connected_order_arc_1221
 L  arc_capacity_1222
 G  connected_order_arc_1223
 L  arc_capacity_1224
 G  connected_order_arc_1225
 L  arc_capacity_1226
 G  connected_order_arc_1227
 L  arc_capacity_1228
 L  arc_capacity_1229
 G  connected_order_arc_1230
 L  arc_capacity_1231
 G  connected_order_arc_1232
 L  arc_capacity_1233
 G  connected_order_arc_1234
 L  arc_capacity_1235
 G  connected_order_arc_1236
 L  arc_capacity_1237
 G  connected_order_arc_1238
 L  arc_capacity_1239
 G  connected_order_arc_1240
 L  arc_capacity_1241
 G  connected_order_arc_1242
 L  arc_capacity_1243
 G  connected_order_arc_1244
 L  arc_capacity_1245
 G  connected_order_arc_1246
 L  arc_capacity_1247
 G  connected_order_arc_1248
 L  arc_capacity_1249
 L  arc_capacity_1250
 G  connected_order_arc_1251
 L  arc_capacity_1252
 G  connected_order_arc_1253
 L  arc_capacity_1254
 G  connected_order_arc_1255
 L  arc_capacity_1256
 G  connected_order_arc_1257
 L  arc_capacity_1258
 G  connected_order_arc_1259
 L  arc_capacity_1260
 G  connected_order_arc_1261
 L  arc_capacity_1262
 G  connected_order_arc_1263
 L  arc_capacity_1264
 G  connected_order_arc_1265
 L  arc_capacity_1266
 G  connected_order_arc_1267
 L  arc_capacity_1268
 G  connected_order_arc_1269
 L  arc_capacity_1270
 L  arc_capacity_1271
 G  connected_order_arc_1272
 L  arc_capacity_1273
 G  connected_order_arc_1274
 L  arc_capacity_1275
 G  connected_order_arc_1276
 L  arc_capacity_1277
 G  connected_order_arc_1278
 L  arc_capacity_1279
 G  connected_order_arc_1280
 L  arc_capacity_1281
 G  connected_order_arc_1282
 L  arc_capacity_1283
 G  connected_order_arc_1284
 L  arc_capacity_1285
 G  connected_order_arc_1286
 L  arc_capacity_1287
 G  connected_order_arc_1288
 L  arc_capacity_1289
 G  connected_order_arc_1290
 L  arc_capacity_1291
 L  arc_capacity_1292
 G  connected_order_arc_1293
 L  arc_capacity_1294
 G  connected_order_arc_1295
 L  arc_capacity_1296
 G  connected_order_arc_1297
 L  arc_capacity_1298
 G  connected_order_arc_1299
 L  arc_capacity_1300
 G  connected_order_arc_1301
 L  arc_capacity_1302
 G  connected_order_arc_1303
 L  arc_capacity_1304
 G  connected_order_arc_1305
 L  arc_capacity_1306
 G  connected_order_arc_1307
 L  arc_capacity_1308
 G  connected_order_arc_1309
 L  arc_capacity_1310
 G  connected_order_arc_1311
 L  arc_capacity_1312
 L  arc_capacity_1313
 G  connected_order_arc_1314
 L  arc_capacity_1315
 G  connected_order_arc_1316
 L  arc_capacity_1317
 G  connected_order_arc_1318
 L  arc_capacity_1319
 G  connected_order_arc_1320
 L  arc_capacity_1321
 G  connected_order_arc_1322
 L  arc_capacity_1323
 G  connected_order_arc_1324
 L  arc_capacity_1325
 G  connected_order_arc_1326
 L  arc_capacity_1327
 G  connected_order_arc_1328
 L  arc_capacity_1329
 G  connected_order_arc_1330
 L  arc_capacity_1331
 G  connected_order_arc_1332
 L  arc_capacity_1333
 L  arc_capacity_1334
 G  connected_order_arc_1335
 L  arc_capacity_1336
 G  connected_order_arc_1337
 L  arc_capacity_1338
 G  connected_order_arc_1339
 L  arc_capacity_1340
 G  connected_order_arc_1341
 L  arc_capacity_1342
 G  connected_order_arc_1343
 L  arc_capacity_1344
 G  connected_order_arc_1345
 L  arc_capacity_1346
 G  connected_order_arc_1347
 L  arc_capacity_1348
 G  connected_order_arc_1349
 L  arc_capacity_1350
 G  connected_order_arc_1351
 L  arc_capacity_1352
 G  connected_order_arc_1353
 L  arc_capacity_1354
 L  arc_capacity_1355
 G  connected_order_arc_1356
 L  arc_capacity_1357
 G  connected_order_arc_1358
 L  arc_capacity_1359
 G  connected_order_arc_1360
 L  arc_capacity_1361
 G  connected_order_arc_1362
 L  arc_capacity_1363
 G  connected_order_arc_1364
 L  arc_capacity_1365
 G  connected_order_arc_1366
 L  arc_capacity_1367
 G  connected_order_arc_1368
 L  arc_capacity_1369
 G  connected_order_arc_1370
 L  arc_capacity_1371
 G  connected_order_arc_1372
 L  arc_capacity_1373
 G  connected_order_arc_1374
 E  depot_departure_or_bypass_1375
 E  depot_return_or_bypass_1376
 E  out_degree_1377
 E  in_degree_1378
 G  order_active_lb_1379
 L  order_active_ub_1380
 E  segment_load_conservation_1381
 G  segment_prefix_lb_1382
 L  segment_prefix_ub_1383
 E  out_degree_1384
 E  in_degree_1385
 G  order_active_lb_1386
 L  order_active_ub_1387
 E  segment_load_conservation_1388
 G  segment_prefix_lb_1389
 L  segment_prefix_ub_1390
 E  out_degree_1391
 E  in_degree_1392
 G  order_active_lb_1393
 L  order_active_ub_1394
 E  segment_load_conservation_1395
 G  segment_prefix_lb_1396
 L  segment_prefix_ub_1397
 E  out_degree_1398
 E  in_degree_1399
 G  order_active_lb_1400
 L  order_active_ub_1401
 E  service_visit_def_1402
 E  free_load_conservation_1403
 E  out_degree_1404
 E  in_degree_1405
 G  order_active_lb_1406
 L  order_active_ub_1407
 E  service_visit_def_1408
 E  free_load_conservation_1409
 E  out_degree_1410
 E  in_degree_1411
 G  order_active_lb_1412
 L  order_active_ub_1413
 E  service_visit_def_1414
 E  free_load_conservation_1415
 E  out_degree_1416
 E  in_degree_1417
 G  order_active_lb_1418
 L  order_active_ub_1419
 E  service_visit_def_1420
 E  free_load_conservation_1421
 E  out_degree_1422
 E  in_degree_1423
 G  order_active_lb_1424
 L  order_active_ub_1425
 E  service_visit_def_1426
 E  free_load_conservation_1427
 E  out_degree_1428
 E  in_degree_1429
 G  order_active_lb_1430
 L  order_active_ub_1431
 E  service_visit_def_1432
 E  free_load_conservation_1433
 E  out_degree_1434
 E  in_degree_1435
 G  order_active_lb_1436
 L  order_active_ub_1437
 E  service_visit_def_1438
 E  free_load_conservation_1439
 E  out_degree_1440
 E  in_degree_1441
 G  order_active_lb_1442
 L  order_active_ub_1443
 E  service_visit_def_1444
 E  free_load_conservation_1445
 G  fixed_segment_relative_order_1446
 G  fixed_segment_relative_order_1447
 L  original_T_including_depot_unload_1448
COLUMNS
    t         normalized_mass_9_23  -1
    t         normalized_mass_11_48  -1
    t         normalized_mass_34_83  -1
    t         normalized_mass_10_100  -1
    t         normalized_mass_29_125  -1
    t         normalized_mass_13_146  -1
    t         normalized_mass_27_163  -1
    t         normalized_mass_8_192  -1
    t         normalization_253  2.2591666666666665e+01
    t         full_original_Gini_254  -8.8783333333333388e+01
    q         OBJ       1
    q         parent_nonstrict_scope_196  1
    q         full_original_Gini_254  35
    MARKER    'MARKER'                 'INTORG'
    x_9_0     OBJ       1.1636571534741636e-02
    x_9_0     product_lb_0  -2.5996533795467933e-02
    x_9_0     product_ub_1  -4.4264109184846939e-02
    x_9_0     onehot_9_22  1
    x_9_0     parent_nonstrict_scope_196  2.3273143069483273e-02
    x_9_0     unique_nonzero_owner_255  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_0     product_lb_0  1
    w_9_0     product_ub_1  1
    w_9_0     normalized_mass_9_23  1
    w_9_0     full_original_Gini_254  -2.2591666666666665e+01
    MARKER    'MARKER'                 'INTORG'
    x_9_1     OBJ       6.9819429208449833e-03
    x_9_1     product_lb_2  -2.5996533795467933e-02
    x_9_1     product_ub_3  -4.4264109184846939e-02
    x_9_1     onehot_9_22  1
    x_9_1     stock_lb_194  1
    x_9_1     stock_ub_195  1
    x_9_1     parent_nonstrict_scope_196  1.8618514455586620e-02
    x_9_1     unique_nonzero_owner_256  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_1     product_lb_2  1
    w_9_1     product_ub_3  1
    w_9_1     normalized_mass_9_23  1
    w_9_1     normalized_ratio_9_24  -0.2
    w_9_1     full_original_Gini_254  -1.7591666666666672e+01
    MARKER    'MARKER'                 'INTORG'
    x_9_2     OBJ       2.3273143069483266e-03
    x_9_2     product_lb_4  -2.5996533795467933e-02
    x_9_2     product_ub_5  -4.4264109184846939e-02
    x_9_2     onehot_9_22  1
    x_9_2     stock_lb_194  2
    x_9_2     stock_ub_195  2
    x_9_2     parent_nonstrict_scope_196  1.3963885841689963e-02
    MARKER    'MARKER'                 'INTEND'
    w_9_2     product_lb_4  1
    w_9_2     product_ub_5  1
    w_9_2     normalized_mass_9_23  1
    w_9_2     normalized_ratio_9_24  -0.4
    w_9_2     full_original_Gini_254  -1.2724999999999998e+01
    MARKER    'MARKER'                 'INTORG'
    x_9_3     OBJ       -0.00232731430694833
    x_9_3     product_lb_6  -2.5996533795467933e-02
    x_9_3     product_ub_7  -4.4264109184846939e-02
    x_9_3     onehot_9_22  1
    x_9_3     stock_lb_194  3
    x_9_3     stock_ub_195  3
    x_9_3     parent_nonstrict_scope_196  9.3092572277933064e-03
    x_9_3     unique_nonzero_owner_257  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_3     product_lb_6  1
    w_9_3     product_ub_7  1
    w_9_3     normalized_mass_9_23  1
    w_9_3     normalized_ratio_9_24  -6.0000000000000009e-01
    w_9_3     full_original_Gini_254  -8.1249999999999982e+00
    MARKER    'MARKER'                 'INTORG'
    x_9_4     OBJ       -6.9819429208449833e-03
    x_9_4     product_lb_8  -2.5996533795467933e-02
    x_9_4     product_ub_9  -4.4264109184846939e-02
    x_9_4     onehot_9_22  1
    x_9_4     stock_lb_194  4
    x_9_4     stock_ub_195  4
    x_9_4     parent_nonstrict_scope_196  4.6546286138966532e-03
    x_9_4     unique_nonzero_owner_258  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_4     product_lb_8  1
    w_9_4     product_ub_9  1
    w_9_4     normalized_mass_9_23  1
    w_9_4     normalized_ratio_9_24  -0.8
    w_9_4     full_original_Gini_254  -4.6345238095238095e+00
    MARKER    'MARKER'                 'INTORG'
    x_9_5     OBJ       -1.1636571534741636e-02
    x_9_5     product_lb_10  -2.5996533795467933e-02
    x_9_5     product_ub_11  -4.4264109184846939e-02
    x_9_5     onehot_9_22  1
    x_9_5     stock_lb_194  5
    x_9_5     stock_ub_195  5
    x_9_5     unique_nonzero_owner_259  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_5     product_lb_10  1
    w_9_5     product_ub_11  1
    w_9_5     normalized_mass_9_23  1
    w_9_5     normalized_ratio_9_24  -1
    w_9_5     full_original_Gini_254  -5.4083333333333341e+00
    MARKER    'MARKER'                 'INTORG'
    x_9_6     OBJ       -6.9819429208449781e-03
    x_9_6     product_lb_12  -2.5996533795467933e-02
    x_9_6     product_ub_13  -4.4264109184846939e-02
    x_9_6     onehot_9_22  1
    x_9_6     stock_lb_194  6
    x_9_6     stock_ub_195  6
    x_9_6     parent_nonstrict_scope_196  4.6546286138966584e-03
    x_9_6     unique_nonzero_owner_260  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_6     product_lb_12  1
    w_9_6     product_ub_13  1
    w_9_6     normalized_mass_9_23  1
    w_9_6     normalized_ratio_9_24  -1.2000000000000002e+00
    w_9_6     full_original_Gini_254  -1.0408333333333335e+01
    MARKER    'MARKER'                 'INTORG'
    x_9_7     OBJ       -2.3273143069483249e-03
    x_9_7     product_lb_14  -2.5996533795467933e-02
    x_9_7     product_ub_15  -4.4264109184846939e-02
    x_9_7     onehot_9_22  1
    x_9_7     stock_lb_194  7
    x_9_7     stock_ub_195  7
    x_9_7     parent_nonstrict_scope_196  9.3092572277933116e-03
    x_9_7     unique_nonzero_owner_261  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_7     product_lb_14  1
    w_9_7     product_ub_15  1
    w_9_7     normalized_mass_9_23  1
    w_9_7     normalized_ratio_9_24  -1.4000000000000001e+00
    w_9_7     full_original_Gini_254  -1.5408333333333340e+01
    MARKER    'MARKER'                 'INTORG'
    x_9_8     OBJ       0.00232731430694833
    x_9_8     product_lb_16  -2.5996533795467933e-02
    x_9_8     product_ub_17  -4.4264109184846939e-02
    x_9_8     onehot_9_22  1
    x_9_8     stock_lb_194  8
    x_9_8     stock_ub_195  8
    x_9_8     parent_nonstrict_scope_196  1.3963885841689967e-02
    x_9_8     unique_nonzero_owner_262  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_8     product_lb_16  1
    w_9_8     product_ub_17  1
    w_9_8     normalized_mass_9_23  1
    w_9_8     normalized_ratio_9_24  -1.6
    w_9_8     full_original_Gini_254  -2.0608333333333334e+01
    MARKER    'MARKER'                 'INTORG'
    x_9_9     OBJ       6.9819429208449833e-03
    x_9_9     product_lb_18  -2.5996533795467933e-02
    x_9_9     product_ub_19  -4.4264109184846939e-02
    x_9_9     onehot_9_22  1
    x_9_9     stock_lb_194  9
    x_9_9     stock_ub_195  9
    x_9_9     parent_nonstrict_scope_196  1.8618514455586620e-02
    x_9_9     unique_nonzero_owner_263  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_9     product_lb_18  1
    w_9_9     product_ub_19  1
    w_9_9     normalized_mass_9_23  1
    w_9_9     normalized_ratio_9_24  -1.8
    w_9_9     full_original_Gini_254  -2.6008333333333344e+01
    MARKER    'MARKER'                 'INTORG'
    x_9_10    OBJ       1.1636571534741636e-02
    x_9_10    product_lb_20  -2.5996533795467933e-02
    x_9_10    product_ub_21  -4.4264109184846939e-02
    x_9_10    onehot_9_22  1
    x_9_10    stock_lb_194  10
    x_9_10    stock_ub_195  10
    x_9_10    parent_nonstrict_scope_196  2.3273143069483273e-02
    x_9_10    unique_nonzero_owner_264  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_10    product_lb_20  1
    w_9_10    product_ub_21  1
    w_9_10    normalized_mass_9_23  1
    w_9_10    normalized_ratio_9_24  -2
    w_9_10    full_original_Gini_254  -3.1408333333333331e+01
    rho_9     normalized_ratio_9_24  1
    rho_9     block_pair_pos_197  -1
    rho_9     block_pair_neg_198  1
    rho_9     block_pair_pos_199  -1
    rho_9     block_pair_neg_200  1
    rho_9     block_pair_pos_201  -1
    rho_9     block_pair_neg_202  1
    rho_9     block_pair_pos_203  -1
    rho_9     block_pair_neg_204  1
    rho_9     block_pair_pos_205  -1
    rho_9     block_pair_neg_206  1
    rho_9     block_pair_pos_207  -1
    rho_9     block_pair_neg_208  1
    rho_9     block_pair_pos_209  -1
    rho_9     block_pair_neg_210  1
    rho_9     normalization_253  1
    MARKER    'MARKER'                 'INTORG'
    x_11_0    OBJ       1.1636571534741636e-02
    x_11_0    product_lb_25  -2.5996533795467933e-02
    x_11_0    product_ub_26  -4.4264109184846939e-02
    x_11_0    onehot_11_47  1
    x_11_0    parent_nonstrict_scope_196  2.3273143069483273e-02
    x_11_0    unique_nonzero_owner_265  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_0    product_lb_25  1
    w_11_0    product_ub_26  1
    w_11_0    normalized_mass_11_48  1
    w_11_0    full_original_Gini_254  -2.2591666666666665e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_1    OBJ       6.9819429208449833e-03
    x_11_1    product_lb_27  -2.5996533795467933e-02
    x_11_1    product_ub_28  -4.4264109184846939e-02
    x_11_1    onehot_11_47  1
    x_11_1    stock_lb_194  1
    x_11_1    stock_ub_195  1
    x_11_1    parent_nonstrict_scope_196  1.8618514455586620e-02
    x_11_1    unique_nonzero_owner_266  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_1    product_lb_27  1
    w_11_1    product_ub_28  1
    w_11_1    normalized_mass_11_48  1
    w_11_1    normalized_ratio_11_49  -0.2
    w_11_1    full_original_Gini_254  -1.7591666666666672e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_2    OBJ       2.3273143069483266e-03
    x_11_2    product_lb_29  -2.5996533795467933e-02
    x_11_2    product_ub_30  -4.4264109184846939e-02
    x_11_2    onehot_11_47  1
    x_11_2    stock_lb_194  2
    x_11_2    stock_ub_195  2
    x_11_2    parent_nonstrict_scope_196  1.3963885841689963e-02
    x_11_2    unique_nonzero_owner_267  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_2    product_lb_29  1
    w_11_2    product_ub_30  1
    w_11_2    normalized_mass_11_48  1
    w_11_2    normalized_ratio_11_49  -0.4
    w_11_2    full_original_Gini_254  -1.2724999999999998e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_3    OBJ       -0.00232731430694833
    x_11_3    product_lb_31  -2.5996533795467933e-02
    x_11_3    product_ub_32  -4.4264109184846939e-02
    x_11_3    onehot_11_47  1
    x_11_3    stock_lb_194  3
    x_11_3    stock_ub_195  3
    x_11_3    parent_nonstrict_scope_196  9.3092572277933064e-03
    x_11_3    unique_nonzero_owner_268  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_3    product_lb_31  1
    w_11_3    product_ub_32  1
    w_11_3    normalized_mass_11_48  1
    w_11_3    normalized_ratio_11_49  -6.0000000000000009e-01
    w_11_3    full_original_Gini_254  -8.1249999999999982e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_4    OBJ       -6.9819429208449833e-03
    x_11_4    product_lb_33  -2.5996533795467933e-02
    x_11_4    product_ub_34  -4.4264109184846939e-02
    x_11_4    onehot_11_47  1
    x_11_4    stock_lb_194  4
    x_11_4    stock_ub_195  4
    x_11_4    parent_nonstrict_scope_196  4.6546286138966532e-03
    x_11_4    unique_nonzero_owner_269  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_4    product_lb_33  1
    w_11_4    product_ub_34  1
    w_11_4    normalized_mass_11_48  1
    w_11_4    normalized_ratio_11_49  -0.8
    w_11_4    full_original_Gini_254  -4.6345238095238095e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_5    OBJ       -1.1636571534741636e-02
    x_11_5    product_lb_35  -2.5996533795467933e-02
    x_11_5    product_ub_36  -4.4264109184846939e-02
    x_11_5    onehot_11_47  1
    x_11_5    stock_lb_194  5
    x_11_5    stock_ub_195  5
    x_11_5    unique_nonzero_owner_270  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_5    product_lb_35  1
    w_11_5    product_ub_36  1
    w_11_5    normalized_mass_11_48  1
    w_11_5    normalized_ratio_11_49  -1
    w_11_5    full_original_Gini_254  -5.4083333333333341e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_6    OBJ       -6.9819429208449781e-03
    x_11_6    product_lb_37  -2.5996533795467933e-02
    x_11_6    product_ub_38  -4.4264109184846939e-02
    x_11_6    onehot_11_47  1
    x_11_6    stock_lb_194  6
    x_11_6    stock_ub_195  6
    x_11_6    parent_nonstrict_scope_196  4.6546286138966584e-03
    x_11_6    unique_nonzero_owner_271  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_6    product_lb_37  1
    w_11_6    product_ub_38  1
    w_11_6    normalized_mass_11_48  1
    w_11_6    normalized_ratio_11_49  -1.2000000000000002e+00
    w_11_6    full_original_Gini_254  -1.0408333333333335e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_7    OBJ       -2.3273143069483249e-03
    x_11_7    product_lb_39  -2.5996533795467933e-02
    x_11_7    product_ub_40  -4.4264109184846939e-02
    x_11_7    onehot_11_47  1
    x_11_7    stock_lb_194  7
    x_11_7    stock_ub_195  7
    x_11_7    parent_nonstrict_scope_196  9.3092572277933116e-03
    x_11_7    unique_nonzero_owner_272  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_7    product_lb_39  1
    w_11_7    product_ub_40  1
    w_11_7    normalized_mass_11_48  1
    w_11_7    normalized_ratio_11_49  -1.4000000000000001e+00
    w_11_7    full_original_Gini_254  -1.5408333333333340e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_8    OBJ       0.00232731430694833
    x_11_8    product_lb_41  -2.5996533795467933e-02
    x_11_8    product_ub_42  -4.4264109184846939e-02
    x_11_8    onehot_11_47  1
    x_11_8    stock_lb_194  8
    x_11_8    stock_ub_195  8
    x_11_8    parent_nonstrict_scope_196  1.3963885841689967e-02
    MARKER    'MARKER'                 'INTEND'
    w_11_8    product_lb_41  1
    w_11_8    product_ub_42  1
    w_11_8    normalized_mass_11_48  1
    w_11_8    normalized_ratio_11_49  -1.6
    w_11_8    full_original_Gini_254  -2.0608333333333334e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_9    OBJ       6.9819429208449833e-03
    x_11_9    product_lb_43  -2.5996533795467933e-02
    x_11_9    product_ub_44  -4.4264109184846939e-02
    x_11_9    onehot_11_47  1
    x_11_9    stock_lb_194  9
    x_11_9    stock_ub_195  9
    x_11_9    parent_nonstrict_scope_196  1.8618514455586620e-02
    x_11_9    unique_nonzero_owner_273  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_9    product_lb_43  1
    w_11_9    product_ub_44  1
    w_11_9    normalized_mass_11_48  1
    w_11_9    normalized_ratio_11_49  -1.8
    w_11_9    full_original_Gini_254  -2.6008333333333344e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_10   OBJ       1.1636571534741636e-02
    x_11_10   product_lb_45  -2.5996533795467933e-02
    x_11_10   product_ub_46  -4.4264109184846939e-02
    x_11_10   onehot_11_47  1
    x_11_10   stock_lb_194  10
    x_11_10   stock_ub_195  10
    x_11_10   parent_nonstrict_scope_196  2.3273143069483273e-02
    x_11_10   unique_nonzero_owner_274  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_10   product_lb_45  1
    w_11_10   product_ub_46  1
    w_11_10   normalized_mass_11_48  1
    w_11_10   normalized_ratio_11_49  -2
    w_11_10   full_original_Gini_254  -3.1408333333333331e+01
    rho_11    normalized_ratio_11_49  1
    rho_11    block_pair_pos_201  1
    rho_11    block_pair_neg_202  -1
    rho_11    block_pair_pos_219  -1
    rho_11    block_pair_neg_220  1
    rho_11    block_pair_pos_221  -1
    rho_11    block_pair_neg_222  1
    rho_11    block_pair_pos_223  -1
    rho_11    block_pair_neg_224  1
    rho_11    block_pair_pos_225  -1
    rho_11    block_pair_neg_226  1
    rho_11    block_pair_pos_227  -1
    rho_11    block_pair_neg_228  1
    rho_11    block_pair_pos_229  -1
    rho_11    block_pair_neg_230  1
    rho_11    normalization_253  1
    MARKER    'MARKER'                 'INTORG'
    x_34_0    OBJ       2.9789603523644435e-02
    x_34_0    product_lb_50  -2.5996533795467933e-02
    x_34_0    product_ub_51  -4.4264109184846939e-02
    x_34_0    onehot_34_82  1
    x_34_0    parent_nonstrict_scope_196  5.9579207047288869e-02
    x_34_0    unique_nonzero_owner_275  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_0    product_lb_50  1
    w_34_0    product_ub_51  1
    w_34_0    normalized_mass_34_83  1
    w_34_0    full_original_Gini_254  -2.2591666666666665e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_1    OBJ       2.2342202642733327e-02
    x_34_1    product_lb_52  -2.5996533795467933e-02
    x_34_1    product_ub_53  -4.4264109184846939e-02
    x_34_1    onehot_34_82  1
    x_34_1    stock_lb_194  1
    x_34_1    stock_ub_195  1
    x_34_1    parent_nonstrict_scope_196  5.2131806166377762e-02
    x_34_1    unique_nonzero_owner_276  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_1    product_lb_52  1
    w_34_1    product_ub_53  1
    w_34_1    normalized_mass_34_83  1
    w_34_1    normalized_ratio_34_84  -0.125
    w_34_1    full_original_Gini_254  -1.9466666666666669e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_2    OBJ       1.4894801761822219e-02
    x_34_2    product_lb_54  -2.5996533795467933e-02
    x_34_2    product_ub_55  -4.4264109184846939e-02
    x_34_2    onehot_34_82  1
    x_34_2    stock_lb_194  2
    x_34_2    stock_ub_195  2
    x_34_2    parent_nonstrict_scope_196  4.4684405285466654e-02
    MARKER    'MARKER'                 'INTEND'
    w_34_2    product_lb_54  1
    w_34_2    product_ub_55  1
    w_34_2    normalized_mass_34_83  1
    w_34_2    normalized_ratio_34_84  -0.25
    w_34_2    full_original_Gini_254  -1.6341666666666669e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_3    OBJ       7.4474008809111113e-03
    x_34_3    product_lb_56  -2.5996533795467933e-02
    x_34_3    product_ub_57  -4.4264109184846939e-02
    x_34_3    onehot_34_82  1
    x_34_3    stock_lb_194  3
    x_34_3    stock_ub_195  3
    x_34_3    parent_nonstrict_scope_196  3.7237004404555546e-02
    x_34_3    unique_nonzero_owner_277  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_3    product_lb_56  1
    w_34_3    product_ub_57  1
    w_34_3    normalized_mass_34_83  1
    w_34_3    normalized_ratio_34_84  -0.375
    w_34_3    full_original_Gini_254  -1.3299999999999999e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_4    product_lb_58  -2.5996533795467933e-02
    x_34_4    product_ub_59  -4.4264109184846939e-02
    x_34_4    onehot_34_82  1
    x_34_4    stock_lb_194  4
    x_34_4    stock_ub_195  4
    x_34_4    parent_nonstrict_scope_196  2.9789603523644435e-02
    x_34_4    unique_nonzero_owner_278  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_4    product_lb_58  1
    w_34_4    product_ub_59  1
    w_34_4    normalized_mass_34_83  1
    w_34_4    normalized_ratio_34_84  -0.5
    w_34_4    full_original_Gini_254  -10.425
    MARKER    'MARKER'                 'INTORG'
    x_34_5    OBJ       -7.4474008809111078e-03
    x_34_5    product_lb_60  -2.5996533795467933e-02
    x_34_5    product_ub_61  -4.4264109184846939e-02
    x_34_5    onehot_34_82  1
    x_34_5    stock_lb_194  5
    x_34_5    stock_ub_195  5
    x_34_5    parent_nonstrict_scope_196  2.2342202642733327e-02
    x_34_5    unique_nonzero_owner_279  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_5    product_lb_60  1
    w_34_5    product_ub_61  1
    w_34_5    normalized_mass_34_83  1
    w_34_5    normalized_ratio_34_84  -0.625
    w_34_5    full_original_Gini_254  -7.55
    MARKER    'MARKER'                 'INTORG'
    x_34_6    OBJ       -1.4894801761822217e-02
    x_34_6    product_lb_62  -2.5996533795467933e-02
    x_34_6    product_ub_63  -4.4264109184846939e-02
    x_34_6    onehot_34_82  1
    x_34_6    stock_lb_194  6
    x_34_6    stock_ub_195  6
    x_34_6    parent_nonstrict_scope_196  1.4894801761822217e-02
    x_34_6    unique_nonzero_owner_280  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_6    product_lb_62  1
    w_34_6    product_ub_63  1
    w_34_6    normalized_mass_34_83  1
    w_34_6    normalized_ratio_34_84  -0.75
    w_34_6    full_original_Gini_254  -4.9845238095238091e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_7    OBJ       -2.2342202642733327e-02
    x_34_7    product_lb_64  -2.5996533795467933e-02
    x_34_7    product_ub_65  -4.4264109184846939e-02
    x_34_7    onehot_34_82  1
    x_34_7    stock_lb_194  7
    x_34_7    stock_ub_195  7
    x_34_7    parent_nonstrict_scope_196  7.4474008809111087e-03
    x_34_7    unique_nonzero_owner_281  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_7    product_lb_64  1
    w_34_7    product_ub_65  1
    w_34_7    normalized_mass_34_83  1
    w_34_7    normalized_ratio_34_84  -0.875
    w_34_7    full_original_Gini_254  -4.5333333333333341e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_8    OBJ       -2.9789603523644435e-02
    x_34_8    product_lb_66  -2.5996533795467933e-02
    x_34_8    product_ub_67  -4.4264109184846939e-02
    x_34_8    onehot_34_82  1
    x_34_8    stock_lb_194  8
    x_34_8    stock_ub_195  8
    x_34_8    unique_nonzero_owner_282  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_8    product_lb_66  1
    w_34_8    product_ub_67  1
    w_34_8    normalized_mass_34_83  1
    w_34_8    normalized_ratio_34_84  -1
    w_34_8    full_original_Gini_254  -5.4083333333333341e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_9    OBJ       -2.2342202642733327e-02
    x_34_9    product_lb_68  -2.5996533795467933e-02
    x_34_9    product_ub_69  -4.4264109184846939e-02
    x_34_9    onehot_34_82  1
    x_34_9    stock_lb_194  9
    x_34_9    stock_ub_195  9
    x_34_9    parent_nonstrict_scope_196  7.4474008809111087e-03
    x_34_9    unique_nonzero_owner_283  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_9    product_lb_68  1
    w_34_9    product_ub_69  1
    w_34_9    normalized_mass_34_83  1
    w_34_9    normalized_ratio_34_84  -1.125
    w_34_9    full_original_Gini_254  -8.5333333333333332e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_10   OBJ       -1.4894801761822217e-02
    x_34_10   product_lb_70  -2.5996533795467933e-02
    x_34_10   product_ub_71  -4.4264109184846939e-02
    x_34_10   onehot_34_82  1
    x_34_10   stock_lb_194  10
    x_34_10   stock_ub_195  10
    x_34_10   parent_nonstrict_scope_196  1.4894801761822217e-02
    x_34_10   unique_nonzero_owner_284  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_10   product_lb_70  1
    w_34_10   product_ub_71  1
    w_34_10   normalized_mass_34_83  1
    w_34_10   normalized_ratio_34_84  -1.25
    w_34_10   full_original_Gini_254  -1.1658333333333331e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_11   OBJ       -7.4474008809111078e-03
    x_34_11   product_lb_72  -2.5996533795467933e-02
    x_34_11   product_ub_73  -4.4264109184846939e-02
    x_34_11   onehot_34_82  1
    x_34_11   stock_lb_194  11
    x_34_11   stock_ub_195  11
    x_34_11   parent_nonstrict_scope_196  2.2342202642733327e-02
    x_34_11   unique_nonzero_owner_285  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_11   product_lb_72  1
    w_34_11   product_ub_73  1
    w_34_11   normalized_mass_34_83  1
    w_34_11   normalized_ratio_34_84  -1.375
    w_34_11   full_original_Gini_254  -1.4783333333333333e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_12   product_lb_74  -2.5996533795467933e-02
    x_34_12   product_ub_75  -4.4264109184846939e-02
    x_34_12   onehot_34_82  1
    x_34_12   stock_lb_194  12
    x_34_12   stock_ub_195  12
    x_34_12   parent_nonstrict_scope_196  2.9789603523644435e-02
    x_34_12   unique_nonzero_owner_286  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_12   product_lb_74  1
    w_34_12   product_ub_75  1
    w_34_12   normalized_mass_34_83  1
    w_34_12   normalized_ratio_34_84  -1.5
    w_34_12   full_original_Gini_254  -1.7908333333333331e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_13   OBJ       7.4474008809111113e-03
    x_34_13   product_lb_76  -2.5996533795467933e-02
    x_34_13   product_ub_77  -4.4264109184846939e-02
    x_34_13   onehot_34_82  1
    x_34_13   stock_lb_194  13
    x_34_13   stock_ub_195  13
    x_34_13   parent_nonstrict_scope_196  3.7237004404555546e-02
    x_34_13   unique_nonzero_owner_287  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_13   product_lb_76  1
    w_34_13   product_ub_77  1
    w_34_13   normalized_mass_34_83  1
    w_34_13   normalized_ratio_34_84  -1.625
    w_34_13   full_original_Gini_254  -2.1283333333333331e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_14   OBJ       1.4894801761822219e-02
    x_34_14   product_lb_78  -2.5996533795467933e-02
    x_34_14   product_ub_79  -4.4264109184846939e-02
    x_34_14   onehot_34_82  1
    x_34_14   stock_lb_194  14
    x_34_14   stock_ub_195  14
    x_34_14   parent_nonstrict_scope_196  4.4684405285466654e-02
    x_34_14   unique_nonzero_owner_288  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_14   product_lb_78  1
    w_34_14   product_ub_79  1
    w_34_14   normalized_mass_34_83  1
    w_34_14   normalized_ratio_34_84  -1.75
    w_34_14   full_original_Gini_254  -2.4658333333333335e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_15   OBJ       2.2342202642733327e-02
    x_34_15   product_lb_80  -2.5996533795467933e-02
    x_34_15   product_ub_81  -4.4264109184846939e-02
    x_34_15   onehot_34_82  1
    x_34_15   stock_lb_194  15
    x_34_15   stock_ub_195  15
    x_34_15   parent_nonstrict_scope_196  5.2131806166377762e-02
    x_34_15   unique_nonzero_owner_289  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_15   product_lb_80  1
    w_34_15   product_ub_81  1
    w_34_15   normalized_mass_34_83  1
    w_34_15   normalized_ratio_34_84  -1.875
    w_34_15   full_original_Gini_254  -2.8033333333333331e+01
    rho_34    normalized_ratio_34_84  1
    rho_34    block_pair_pos_209  1
    rho_34    block_pair_neg_210  -1
    rho_34    block_pair_pos_229  1
    rho_34    block_pair_neg_230  -1
    rho_34    block_pair_pos_243  -1
    rho_34    block_pair_neg_244  1
    rho_34    block_pair_pos_245  -1
    rho_34    block_pair_neg_246  1
    rho_34    block_pair_pos_247  -1
    rho_34    block_pair_neg_248  1
    rho_34    block_pair_pos_249  -1
    rho_34    block_pair_neg_250  1
    rho_34    block_pair_pos_251  -1
    rho_34    block_pair_neg_252  1
    rho_34    normalization_253  1
    MARKER    'MARKER'                 'INTORG'
    x_10_0    OBJ       4.1891612282083379e-03
    x_10_0    product_lb_85  -2.5996533795467933e-02
    x_10_0    product_ub_86  -4.4264109184846939e-02
    x_10_0    onehot_10_99  1
    x_10_0    parent_nonstrict_scope_196  8.3783224564166758e-03
    x_10_0    unique_nonzero_owner_290  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_0    product_lb_85  1
    w_10_0    product_ub_86  1
    w_10_0    normalized_mass_10_100  1
    w_10_0    full_original_Gini_254  -2.2591666666666665e+01
    MARKER    'MARKER'                 'INTORG'
    x_10_1    OBJ       1.3963870760694466e-03
    x_10_1    product_lb_87  -2.5996533795467933e-02
    x_10_1    product_ub_88  -4.4264109184846939e-02
    x_10_1    onehot_10_99  1
    x_10_1    stock_lb_194  1
    x_10_1    stock_ub_195  1
    x_10_1    parent_nonstrict_scope_196  5.5855483042777845e-03
    x_10_1    unique_nonzero_owner_291  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_1    product_lb_87  1
    w_10_1    product_ub_88  1
    w_10_1    normalized_mass_10_100  1
    w_10_1    normalized_ratio_10_101  -3.3333333333333331e-01
    w_10_1    full_original_Gini_254  -1.4258333333333331e+01
    MARKER    'MARKER'                 'INTORG'
    x_10_2    OBJ       -1.3963870760694457e-03
    x_10_2    product_lb_89  -2.5996533795467933e-02
    x_10_2    product_ub_90  -4.4264109184846939e-02
    x_10_2    onehot_10_99  1
    x_10_2    stock_lb_194  2
    x_10_2    stock_ub_195  2
    x_10_2    parent_nonstrict_scope_196  2.7927741521388922e-03
    x_10_2    unique_nonzero_owner_292  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_2    product_lb_89  1
    w_10_2    product_ub_90  1
    w_10_2    normalized_mass_10_100  1
    w_10_2    normalized_ratio_10_101  -6.6666666666666663e-01
    w_10_2    full_original_Gini_254  -6.5916666666666659e+00
    MARKER    'MARKER'                 'INTORG'
    x_10_3    OBJ       -4.1891612282083379e-03
    x_10_3    product_lb_91  -2.5996533795467933e-02
    x_10_3    product_ub_92  -4.4264109184846939e-02
    x_10_3    onehot_10_99  1
    x_10_3    stock_lb_194  3
    x_10_3    stock_ub_195  3
    x_10_3    unique_nonzero_owner_293  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_3    product_lb_91  1
    w_10_3    product_ub_92  1
    w_10_3    normalized_mass_10_100  1
    w_10_3    normalized_ratio_10_101  -1
    w_10_3    full_original_Gini_254  -5.4083333333333341e+00
    MARKER    'MARKER'                 'INTORG'
    x_10_4    OBJ       -1.3963870760694466e-03
    x_10_4    product_lb_93  -2.5996533795467933e-02
    x_10_4    product_ub_94  -4.4264109184846939e-02
    x_10_4    onehot_10_99  1
    x_10_4    stock_lb_194  4
    x_10_4    stock_ub_195  4
    x_10_4    parent_nonstrict_scope_196  2.7927741521388914e-03
    MARKER    'MARKER'                 'INTEND'
    w_10_4    product_lb_93  1
    w_10_4    product_ub_94  1
    w_10_4    normalized_mass_10_100  1
    w_10_4    normalized_ratio_10_101  -1.3333333333333333e+00
    w_10_4    full_original_Gini_254  -1.3741666666666665e+01
    MARKER    'MARKER'                 'INTORG'
    x_10_5    OBJ       1.3963870760694448e-03
    x_10_5    product_lb_95  -2.5996533795467933e-02
    x_10_5    product_ub_96  -4.4264109184846939e-02
    x_10_5    onehot_10_99  1
    x_10_5    stock_lb_194  5
    x_10_5    stock_ub_195  5
    x_10_5    parent_nonstrict_scope_196  5.5855483042777827e-03
    x_10_5    unique_nonzero_owner_294  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_5    product_lb_95  1
    w_10_5    product_ub_96  1
    w_10_5    normalized_mass_10_100  1
    w_10_5    normalized_ratio_10_101  -1.6666666666666665e+00
    w_10_5    full_original_Gini_254  -2.2408333333333328e+01
    MARKER    'MARKER'                 'INTORG'
    x_10_6    OBJ       4.1891612282083379e-03
    x_10_6    product_lb_97  -2.5996533795467933e-02
    x_10_6    product_ub_98  -4.4264109184846939e-02
    x_10_6    onehot_10_99  1
    x_10_6    stock_lb_194  6
    x_10_6    stock_ub_195  6
    x_10_6    parent_nonstrict_scope_196  8.3783224564166758e-03
    x_10_6    unique_nonzero_owner_295  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_6    product_lb_97  1
    w_10_6    product_ub_98  1
    w_10_6    normalized_mass_10_100  1
    w_10_6    normalized_ratio_10_101  -2
    w_10_6    full_original_Gini_254  -3.1408333333333331e+01
    rho_10    normalized_ratio_10_101  1
    rho_10    block_pair_pos_199  1
    rho_10    block_pair_neg_200  -1
    rho_10    block_pair_pos_211  -1
    rho_10    block_pair_neg_212  1
    rho_10    block_pair_pos_213  -1
    rho_10    block_pair_neg_214  1
    rho_10    block_pair_pos_215  -1
    rho_10    block_pair_neg_216  1
    rho_10    block_pair_pos_217  -1
    rho_10    block_pair_neg_218  1
    rho_10    block_pair_pos_221  1
    rho_10    block_pair_neg_222  -1
    rho_10    block_pair_pos_245  1
    rho_10    block_pair_neg_246  -1
    rho_10    normalization_253  1
    MARKER    'MARKER'                 'INTORG'
    x_29_0    OBJ       1.1636571534741636e-02
    x_29_0    product_lb_102  -2.5996533795467933e-02
    x_29_0    product_ub_103  -4.4264109184846939e-02
    x_29_0    onehot_29_124  1
    x_29_0    parent_nonstrict_scope_196  2.3273143069483273e-02
    x_29_0    unique_nonzero_owner_296  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_0    product_lb_102  1
    w_29_0    product_ub_103  1
    w_29_0    normalized_mass_29_125  1
    w_29_0    full_original_Gini_254  -2.2591666666666665e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_1    OBJ       6.9819429208449833e-03
    x_29_1    product_lb_104  -2.5996533795467933e-02
    x_29_1    product_ub_105  -4.4264109184846939e-02
    x_29_1    onehot_29_124  1
    x_29_1    stock_lb_194  1
    x_29_1    stock_ub_195  1
    x_29_1    parent_nonstrict_scope_196  1.8618514455586620e-02
    MARKER    'MARKER'                 'INTEND'
    w_29_1    product_lb_104  1
    w_29_1    product_ub_105  1
    w_29_1    normalized_mass_29_125  1
    w_29_1    normalized_ratio_29_126  -0.2
    w_29_1    full_original_Gini_254  -1.7591666666666672e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_2    OBJ       2.3273143069483266e-03
    x_29_2    product_lb_106  -2.5996533795467933e-02
    x_29_2    product_ub_107  -4.4264109184846939e-02
    x_29_2    onehot_29_124  1
    x_29_2    stock_lb_194  2
    x_29_2    stock_ub_195  2
    x_29_2    parent_nonstrict_scope_196  1.3963885841689963e-02
    x_29_2    unique_nonzero_owner_297  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_2    product_lb_106  1
    w_29_2    product_ub_107  1
    w_29_2    normalized_mass_29_125  1
    w_29_2    normalized_ratio_29_126  -0.4
    w_29_2    full_original_Gini_254  -1.2724999999999998e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_3    OBJ       -0.00232731430694833
    x_29_3    product_lb_108  -2.5996533795467933e-02
    x_29_3    product_ub_109  -4.4264109184846939e-02
    x_29_3    onehot_29_124  1
    x_29_3    stock_lb_194  3
    x_29_3    stock_ub_195  3
    x_29_3    parent_nonstrict_scope_196  9.3092572277933064e-03
    x_29_3    unique_nonzero_owner_298  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_3    product_lb_108  1
    w_29_3    product_ub_109  1
    w_29_3    normalized_mass_29_125  1
    w_29_3    normalized_ratio_29_126  -6.0000000000000009e-01
    w_29_3    full_original_Gini_254  -8.1249999999999982e+00
    MARKER    'MARKER'                 'INTORG'
    x_29_4    OBJ       -6.9819429208449833e-03
    x_29_4    product_lb_110  -2.5996533795467933e-02
    x_29_4    product_ub_111  -4.4264109184846939e-02
    x_29_4    onehot_29_124  1
    x_29_4    stock_lb_194  4
    x_29_4    stock_ub_195  4
    x_29_4    parent_nonstrict_scope_196  4.6546286138966532e-03
    x_29_4    unique_nonzero_owner_299  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_4    product_lb_110  1
    w_29_4    product_ub_111  1
    w_29_4    normalized_mass_29_125  1
    w_29_4    normalized_ratio_29_126  -0.8
    w_29_4    full_original_Gini_254  -4.6345238095238095e+00
    MARKER    'MARKER'                 'INTORG'
    x_29_5    OBJ       -1.1636571534741636e-02
    x_29_5    product_lb_112  -2.5996533795467933e-02
    x_29_5    product_ub_113  -4.4264109184846939e-02
    x_29_5    onehot_29_124  1
    x_29_5    stock_lb_194  5
    x_29_5    stock_ub_195  5
    x_29_5    unique_nonzero_owner_300  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_5    product_lb_112  1
    w_29_5    product_ub_113  1
    w_29_5    normalized_mass_29_125  1
    w_29_5    normalized_ratio_29_126  -1
    w_29_5    full_original_Gini_254  -5.4083333333333341e+00
    MARKER    'MARKER'                 'INTORG'
    x_29_6    OBJ       -6.9819429208449781e-03
    x_29_6    product_lb_114  -2.5996533795467933e-02
    x_29_6    product_ub_115  -4.4264109184846939e-02
    x_29_6    onehot_29_124  1
    x_29_6    stock_lb_194  6
    x_29_6    stock_ub_195  6
    x_29_6    parent_nonstrict_scope_196  4.6546286138966584e-03
    x_29_6    unique_nonzero_owner_301  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_6    product_lb_114  1
    w_29_6    product_ub_115  1
    w_29_6    normalized_mass_29_125  1
    w_29_6    normalized_ratio_29_126  -1.2000000000000002e+00
    w_29_6    full_original_Gini_254  -1.0408333333333335e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_7    OBJ       -2.3273143069483249e-03
    x_29_7    product_lb_116  -2.5996533795467933e-02
    x_29_7    product_ub_117  -4.4264109184846939e-02
    x_29_7    onehot_29_124  1
    x_29_7    stock_lb_194  7
    x_29_7    stock_ub_195  7
    x_29_7    parent_nonstrict_scope_196  9.3092572277933116e-03
    x_29_7    unique_nonzero_owner_302  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_7    product_lb_116  1
    w_29_7    product_ub_117  1
    w_29_7    normalized_mass_29_125  1
    w_29_7    normalized_ratio_29_126  -1.4000000000000001e+00
    w_29_7    full_original_Gini_254  -1.5408333333333340e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_8    OBJ       0.00232731430694833
    x_29_8    product_lb_118  -2.5996533795467933e-02
    x_29_8    product_ub_119  -4.4264109184846939e-02
    x_29_8    onehot_29_124  1
    x_29_8    stock_lb_194  8
    x_29_8    stock_ub_195  8
    x_29_8    parent_nonstrict_scope_196  1.3963885841689967e-02
    x_29_8    unique_nonzero_owner_303  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_8    product_lb_118  1
    w_29_8    product_ub_119  1
    w_29_8    normalized_mass_29_125  1
    w_29_8    normalized_ratio_29_126  -1.6
    w_29_8    full_original_Gini_254  -2.0608333333333334e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_9    OBJ       6.9819429208449833e-03
    x_29_9    product_lb_120  -2.5996533795467933e-02
    x_29_9    product_ub_121  -4.4264109184846939e-02
    x_29_9    onehot_29_124  1
    x_29_9    stock_lb_194  9
    x_29_9    stock_ub_195  9
    x_29_9    parent_nonstrict_scope_196  1.8618514455586620e-02
    x_29_9    unique_nonzero_owner_304  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_9    product_lb_120  1
    w_29_9    product_ub_121  1
    w_29_9    normalized_mass_29_125  1
    w_29_9    normalized_ratio_29_126  -1.8
    w_29_9    full_original_Gini_254  -2.6008333333333344e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_10   OBJ       1.1636571534741636e-02
    x_29_10   product_lb_122  -2.5996533795467933e-02
    x_29_10   product_ub_123  -4.4264109184846939e-02
    x_29_10   onehot_29_124  1
    x_29_10   stock_lb_194  10
    x_29_10   stock_ub_195  10
    x_29_10   parent_nonstrict_scope_196  2.3273143069483273e-02
    x_29_10   unique_nonzero_owner_305  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_10   product_lb_122  1
    w_29_10   product_ub_123  1
    w_29_10   normalized_mass_29_125  1
    w_29_10   normalized_ratio_29_126  -2
    w_29_10   full_original_Gini_254  -3.1408333333333331e+01
    rho_29    normalized_ratio_29_126  1
    rho_29    block_pair_pos_207  1
    rho_29    block_pair_neg_208  -1
    rho_29    block_pair_pos_217  1
    rho_29    block_pair_neg_218  -1
    rho_29    block_pair_pos_227  1
    rho_29    block_pair_neg_228  -1
    rho_29    block_pair_pos_237  -1
    rho_29    block_pair_neg_238  1
    rho_29    block_pair_pos_239  -1
    rho_29    block_pair_neg_240  1
    rho_29    block_pair_pos_241  -1
    rho_29    block_pair_neg_242  1
    rho_29    block_pair_pos_251  1
    rho_29    block_pair_neg_252  -1
    rho_29    normalization_253  1
    MARKER    'MARKER'                 'INTORG'
    x_13_0    OBJ       7.4474103065332977e-03
    x_13_0    product_lb_127  -2.5996533795467933e-02
    x_13_0    product_ub_128  -4.4264109184846939e-02
    x_13_0    onehot_13_145  1
    x_13_0    parent_nonstrict_scope_196  1.4894820613066595e-02
    x_13_0    unique_nonzero_owner_306  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_0    product_lb_127  1
    w_13_0    product_ub_128  1
    w_13_0    normalized_mass_13_146  1
    w_13_0    full_original_Gini_254  -2.2591666666666665e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_1    OBJ       3.7237051532666493e-03
    x_13_1    product_lb_129  -2.5996533795467933e-02
    x_13_1    product_ub_130  -4.4264109184846939e-02
    x_13_1    onehot_13_145  1
    x_13_1    stock_lb_194  1
    x_13_1    stock_ub_195  1
    x_13_1    parent_nonstrict_scope_196  1.1171115459799947e-02
    x_13_1    unique_nonzero_owner_307  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_1    product_lb_129  1
    w_13_1    product_ub_130  1
    w_13_1    normalized_mass_13_146  1
    w_13_1    normalized_ratio_13_147  -0.25
    w_13_1    full_original_Gini_254  -1.6341666666666669e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_2    product_lb_131  -2.5996533795467933e-02
    x_13_2    product_ub_132  -4.4264109184846939e-02
    x_13_2    onehot_13_145  1
    x_13_2    stock_lb_194  2
    x_13_2    stock_ub_195  2
    x_13_2    parent_nonstrict_scope_196  7.4474103065332977e-03
    x_13_2    unique_nonzero_owner_308  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_2    product_lb_131  1
    w_13_2    product_ub_132  1
    w_13_2    normalized_mass_13_146  1
    w_13_2    normalized_ratio_13_147  -0.5
    w_13_2    full_original_Gini_254  -10.425
    MARKER    'MARKER'                 'INTORG'
    x_13_3    OBJ       -3.7237051532666488e-03
    x_13_3    product_lb_133  -2.5996533795467933e-02
    x_13_3    product_ub_134  -4.4264109184846939e-02
    x_13_3    onehot_13_145  1
    x_13_3    stock_lb_194  3
    x_13_3    stock_ub_195  3
    x_13_3    parent_nonstrict_scope_196  3.7237051532666488e-03
    x_13_3    unique_nonzero_owner_309  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_3    product_lb_133  1
    w_13_3    product_ub_134  1
    w_13_3    normalized_mass_13_146  1
    w_13_3    normalized_ratio_13_147  -0.75
    w_13_3    full_original_Gini_254  -4.9845238095238091e+00
    MARKER    'MARKER'                 'INTORG'
    x_13_4    OBJ       -7.4474103065332977e-03
    x_13_4    product_lb_135  -2.5996533795467933e-02
    x_13_4    product_ub_136  -4.4264109184846939e-02
    x_13_4    onehot_13_145  1
    x_13_4    stock_lb_194  4
    x_13_4    stock_ub_195  4
    x_13_4    unique_nonzero_owner_310  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_4    product_lb_135  1
    w_13_4    product_ub_136  1
    w_13_4    normalized_mass_13_146  1
    w_13_4    normalized_ratio_13_147  -1
    w_13_4    full_original_Gini_254  -5.4083333333333341e+00
    MARKER    'MARKER'                 'INTORG'
    x_13_5    OBJ       -3.7237051532666488e-03
    x_13_5    product_lb_137  -2.5996533795467933e-02
    x_13_5    product_ub_138  -4.4264109184846939e-02
    x_13_5    onehot_13_145  1
    x_13_5    stock_lb_194  5
    x_13_5    stock_ub_195  5
    x_13_5    parent_nonstrict_scope_196  3.7237051532666488e-03
    MARKER    'MARKER'                 'INTEND'
    w_13_5    product_lb_137  1
    w_13_5    product_ub_138  1
    w_13_5    normalized_mass_13_146  1
    w_13_5    normalized_ratio_13_147  -1.25
    w_13_5    full_original_Gini_254  -1.1658333333333331e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_6    product_lb_139  -2.5996533795467933e-02
    x_13_6    product_ub_140  -4.4264109184846939e-02
    x_13_6    onehot_13_145  1
    x_13_6    stock_lb_194  6
    x_13_6    stock_ub_195  6
    x_13_6    parent_nonstrict_scope_196  7.4474103065332977e-03
    x_13_6    unique_nonzero_owner_311  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_6    product_lb_139  1
    w_13_6    product_ub_140  1
    w_13_6    normalized_mass_13_146  1
    w_13_6    normalized_ratio_13_147  -1.5
    w_13_6    full_original_Gini_254  -1.7908333333333331e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_7    OBJ       3.7237051532666493e-03
    x_13_7    product_lb_141  -2.5996533795467933e-02
    x_13_7    product_ub_142  -4.4264109184846939e-02
    x_13_7    onehot_13_145  1
    x_13_7    stock_lb_194  7
    x_13_7    stock_ub_195  7
    x_13_7    parent_nonstrict_scope_196  1.1171115459799947e-02
    x_13_7    unique_nonzero_owner_312  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_7    product_lb_141  1
    w_13_7    product_ub_142  1
    w_13_7    normalized_mass_13_146  1
    w_13_7    normalized_ratio_13_147  -1.75
    w_13_7    full_original_Gini_254  -2.4658333333333335e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_8    OBJ       7.4474103065332977e-03
    x_13_8    product_lb_143  -2.5996533795467933e-02
    x_13_8    product_ub_144  -4.4264109184846939e-02
    x_13_8    onehot_13_145  1
    x_13_8    stock_lb_194  8
    x_13_8    stock_ub_195  8
    x_13_8    parent_nonstrict_scope_196  1.4894820613066595e-02
    x_13_8    unique_nonzero_owner_313  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_8    product_lb_143  1
    w_13_8    product_ub_144  1
    w_13_8    normalized_mass_13_146  1
    w_13_8    normalized_ratio_13_147  -2
    w_13_8    full_original_Gini_254  -3.1408333333333331e+01
    rho_13    normalized_ratio_13_147  1
    rho_13    block_pair_pos_203  1
    rho_13    block_pair_neg_204  -1
    rho_13    block_pair_pos_213  1
    rho_13    block_pair_neg_214  -1
    rho_13    block_pair_pos_223  1
    rho_13    block_pair_neg_224  -1
    rho_13    block_pair_pos_231  -1
    rho_13    block_pair_neg_232  1
    rho_13    block_pair_pos_233  -1
    rho_13    block_pair_neg_234  1
    rho_13    block_pair_pos_239  1
    rho_13    block_pair_neg_240  -1
    rho_13    block_pair_pos_247  1
    rho_13    block_pair_neg_248  -1
    rho_13    normalization_253  1
    MARKER    'MARKER'                 'INTORG'
    x_27_0    OBJ       4.1891612282083379e-03
    x_27_0    product_lb_148  -2.5996533795467933e-02
    x_27_0    product_ub_149  -4.4264109184846939e-02
    x_27_0    onehot_27_162  1
    x_27_0    parent_nonstrict_scope_196  8.3783224564166758e-03
    MARKER    'MARKER'                 'INTEND'
    w_27_0    product_lb_148  1
    w_27_0    product_ub_149  1
    w_27_0    normalized_mass_27_163  1
    w_27_0    full_original_Gini_254  -2.2591666666666665e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_1    OBJ       1.3963870760694466e-03
    x_27_1    product_lb_150  -2.5996533795467933e-02
    x_27_1    product_ub_151  -4.4264109184846939e-02
    x_27_1    onehot_27_162  1
    x_27_1    stock_lb_194  1
    x_27_1    stock_ub_195  1
    x_27_1    parent_nonstrict_scope_196  5.5855483042777845e-03
    x_27_1    unique_nonzero_owner_314  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_1    product_lb_150  1
    w_27_1    product_ub_151  1
    w_27_1    normalized_mass_27_163  1
    w_27_1    normalized_ratio_27_164  -3.3333333333333331e-01
    w_27_1    full_original_Gini_254  -1.4258333333333331e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_2    OBJ       -1.3963870760694457e-03
    x_27_2    product_lb_152  -2.5996533795467933e-02
    x_27_2    product_ub_153  -4.4264109184846939e-02
    x_27_2    onehot_27_162  1
    x_27_2    stock_lb_194  2
    x_27_2    stock_ub_195  2
    x_27_2    parent_nonstrict_scope_196  2.7927741521388922e-03
    x_27_2    unique_nonzero_owner_315  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_2    product_lb_152  1
    w_27_2    product_ub_153  1
    w_27_2    normalized_mass_27_163  1
    w_27_2    normalized_ratio_27_164  -6.6666666666666663e-01
    w_27_2    full_original_Gini_254  -6.5916666666666659e+00
    MARKER    'MARKER'                 'INTORG'
    x_27_3    OBJ       -4.1891612282083379e-03
    x_27_3    product_lb_154  -2.5996533795467933e-02
    x_27_3    product_ub_155  -4.4264109184846939e-02
    x_27_3    onehot_27_162  1
    x_27_3    stock_lb_194  3
    x_27_3    stock_ub_195  3
    x_27_3    unique_nonzero_owner_316  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_3    product_lb_154  1
    w_27_3    product_ub_155  1
    w_27_3    normalized_mass_27_163  1
    w_27_3    normalized_ratio_27_164  -1
    w_27_3    full_original_Gini_254  -5.4083333333333341e+00
    MARKER    'MARKER'                 'INTORG'
    x_27_4    OBJ       -1.3963870760694466e-03
    x_27_4    product_lb_156  -2.5996533795467933e-02
    x_27_4    product_ub_157  -4.4264109184846939e-02
    x_27_4    onehot_27_162  1
    x_27_4    stock_lb_194  4
    x_27_4    stock_ub_195  4
    x_27_4    parent_nonstrict_scope_196  2.7927741521388914e-03
    x_27_4    unique_nonzero_owner_317  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_4    product_lb_156  1
    w_27_4    product_ub_157  1
    w_27_4    normalized_mass_27_163  1
    w_27_4    normalized_ratio_27_164  -1.3333333333333333e+00
    w_27_4    full_original_Gini_254  -1.3741666666666665e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_5    OBJ       1.3963870760694448e-03
    x_27_5    product_lb_158  -2.5996533795467933e-02
    x_27_5    product_ub_159  -4.4264109184846939e-02
    x_27_5    onehot_27_162  1
    x_27_5    stock_lb_194  5
    x_27_5    stock_ub_195  5
    x_27_5    parent_nonstrict_scope_196  5.5855483042777827e-03
    x_27_5    unique_nonzero_owner_318  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_5    product_lb_158  1
    w_27_5    product_ub_159  1
    w_27_5    normalized_mass_27_163  1
    w_27_5    normalized_ratio_27_164  -1.6666666666666665e+00
    w_27_5    full_original_Gini_254  -2.2408333333333328e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_6    OBJ       4.1891612282083379e-03
    x_27_6    product_lb_160  -2.5996533795467933e-02
    x_27_6    product_ub_161  -4.4264109184846939e-02
    x_27_6    onehot_27_162  1
    x_27_6    stock_lb_194  6
    x_27_6    stock_ub_195  6
    x_27_6    parent_nonstrict_scope_196  8.3783224564166758e-03
    x_27_6    unique_nonzero_owner_319  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_6    product_lb_160  1
    w_27_6    product_ub_161  1
    w_27_6    normalized_mass_27_163  1
    w_27_6    normalized_ratio_27_164  -2
    w_27_6    full_original_Gini_254  -3.1408333333333331e+01
    rho_27    normalized_ratio_27_164  1
    rho_27    block_pair_pos_205  1
    rho_27    block_pair_neg_206  -1
    rho_27    block_pair_pos_215  1
    rho_27    block_pair_neg_216  -1
    rho_27    block_pair_pos_225  1
    rho_27    block_pair_neg_226  -1
    rho_27    block_pair_pos_233  1
    rho_27    block_pair_neg_234  -1
    rho_27    block_pair_pos_235  -1
    rho_27    block_pair_neg_236  1
    rho_27    block_pair_pos_241  1
    rho_27    block_pair_neg_242  -1
    rho_27    block_pair_pos_249  1
    rho_27    block_pair_neg_250  -1
    rho_27    normalization_253  1
    MARKER    'MARKER'                 'INTORG'
    x_8_0     OBJ       1.6756644912833352e-02
    x_8_0     product_lb_165  -2.5996533795467933e-02
    x_8_0     product_ub_166  -4.4264109184846939e-02
    x_8_0     onehot_8_191  1
    x_8_0     parent_nonstrict_scope_196  0.0335132898256667
    x_8_0     unique_nonzero_owner_320  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_0     product_lb_165  1
    w_8_0     product_ub_166  1
    w_8_0     normalized_mass_8_192  1
    w_8_0     full_original_Gini_254  -2.2591666666666665e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_1     OBJ       1.1171096608555569e-02
    x_8_1     product_lb_167  -2.5996533795467933e-02
    x_8_1     product_ub_168  -4.4264109184846939e-02
    x_8_1     onehot_8_191  1
    x_8_1     stock_lb_194  1
    x_8_1     stock_ub_195  1
    x_8_1     parent_nonstrict_scope_196  2.7927741521388921e-02
    x_8_1     unique_nonzero_owner_321  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_1     product_lb_167  1
    w_8_1     product_ub_168  1
    w_8_1     normalized_mass_8_192  1
    w_8_1     normalized_ratio_8_193  -1.6666666666666666e-01
    w_8_1     full_original_Gini_254  -18.425
    MARKER    'MARKER'                 'INTORG'
    x_8_2     OBJ       5.5855483042777862e-03
    x_8_2     product_lb_169  -2.5996533795467933e-02
    x_8_2     product_ub_170  -4.4264109184846939e-02
    x_8_2     onehot_8_191  1
    x_8_2     stock_lb_194  2
    x_8_2     stock_ub_195  2
    x_8_2     parent_nonstrict_scope_196  2.2342193217111138e-02
    x_8_2     unique_nonzero_owner_322  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_2     product_lb_169  1
    w_8_2     product_ub_170  1
    w_8_2     normalized_mass_8_192  1
    w_8_2     normalized_ratio_8_193  -3.3333333333333331e-01
    w_8_2     full_original_Gini_254  -1.4258333333333331e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_3     product_lb_171  -2.5996533795467933e-02
    x_8_3     product_ub_172  -4.4264109184846939e-02
    x_8_3     onehot_8_191  1
    x_8_3     stock_lb_194  3
    x_8_3     stock_ub_195  3
    x_8_3     parent_nonstrict_scope_196  1.6756644912833352e-02
    x_8_3     unique_nonzero_owner_323  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_3     product_lb_171  1
    w_8_3     product_ub_172  1
    w_8_3     normalized_mass_8_192  1
    w_8_3     normalized_ratio_8_193  -0.5
    w_8_3     full_original_Gini_254  -10.425
    MARKER    'MARKER'                 'INTORG'
    x_8_4     OBJ       -5.5855483042777827e-03
    x_8_4     product_lb_173  -2.5996533795467933e-02
    x_8_4     product_ub_174  -4.4264109184846939e-02
    x_8_4     onehot_8_191  1
    x_8_4     stock_lb_194  4
    x_8_4     stock_ub_195  4
    x_8_4     parent_nonstrict_scope_196  1.1171096608555569e-02
    x_8_4     unique_nonzero_owner_324  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_4     product_lb_173  1
    w_8_4     product_ub_174  1
    w_8_4     normalized_mass_8_192  1
    w_8_4     normalized_ratio_8_193  -6.6666666666666663e-01
    w_8_4     full_original_Gini_254  -6.5916666666666659e+00
    MARKER    'MARKER'                 'INTORG'
    x_8_5     OBJ       -1.1171096608555565e-02
    x_8_5     product_lb_175  -2.5996533795467933e-02
    x_8_5     product_ub_176  -4.4264109184846939e-02
    x_8_5     onehot_8_191  1
    x_8_5     stock_lb_194  5
    x_8_5     stock_ub_195  5
    x_8_5     parent_nonstrict_scope_196  5.5855483042777862e-03
    x_8_5     unique_nonzero_owner_325  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_5     product_lb_175  1
    w_8_5     product_ub_176  1
    w_8_5     normalized_mass_8_192  1
    w_8_5     normalized_ratio_8_193  -8.3333333333333326e-01
    w_8_5     full_original_Gini_254  -4.4678571428571425e+00
    MARKER    'MARKER'                 'INTORG'
    x_8_6     OBJ       -1.6756644912833352e-02
    x_8_6     product_lb_177  -2.5996533795467933e-02
    x_8_6     product_ub_178  -4.4264109184846939e-02
    x_8_6     onehot_8_191  1
    x_8_6     stock_lb_194  6
    x_8_6     stock_ub_195  6
    x_8_6     unique_nonzero_owner_326  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_6     product_lb_177  1
    w_8_6     product_ub_178  1
    w_8_6     normalized_mass_8_192  1
    w_8_6     normalized_ratio_8_193  -1
    w_8_6     full_original_Gini_254  -5.4083333333333341e+00
    MARKER    'MARKER'                 'INTORG'
    x_8_7     OBJ       -1.1171096608555572e-02
    x_8_7     product_lb_179  -2.5996533795467933e-02
    x_8_7     product_ub_180  -4.4264109184846939e-02
    x_8_7     onehot_8_191  1
    x_8_7     stock_lb_194  7
    x_8_7     stock_ub_195  7
    x_8_7     parent_nonstrict_scope_196  5.5855483042777793e-03
    x_8_7     unique_nonzero_owner_327  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_7     product_lb_179  1
    w_8_7     product_ub_180  1
    w_8_7     normalized_mass_8_192  1
    w_8_7     normalized_ratio_8_193  -1.1666666666666665e+00
    w_8_7     full_original_Gini_254  -9.5749999999999940e+00
    MARKER    'MARKER'                 'INTORG'
    x_8_8     OBJ       -5.5855483042777862e-03
    x_8_8     product_lb_181  -2.5996533795467933e-02
    x_8_8     product_ub_182  -4.4264109184846939e-02
    x_8_8     onehot_8_191  1
    x_8_8     stock_lb_194  8
    x_8_8     stock_ub_195  8
    x_8_8     parent_nonstrict_scope_196  1.1171096608555565e-02
    x_8_8     unique_nonzero_owner_328  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_8     product_lb_181  1
    w_8_8     product_ub_182  1
    w_8_8     normalized_mass_8_192  1
    w_8_8     normalized_ratio_8_193  -1.3333333333333333e+00
    w_8_8     full_original_Gini_254  -1.3741666666666665e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_9     product_lb_183  -2.5996533795467933e-02
    x_8_9     product_ub_184  -4.4264109184846939e-02
    x_8_9     onehot_8_191  1
    x_8_9     stock_lb_194  9
    x_8_9     stock_ub_195  9
    x_8_9     parent_nonstrict_scope_196  1.6756644912833352e-02
    MARKER    'MARKER'                 'INTEND'
    w_8_9     product_lb_183  1
    w_8_9     product_ub_184  1
    w_8_9     normalized_mass_8_192  1
    w_8_9     normalized_ratio_8_193  -1.5
    w_8_9     full_original_Gini_254  -1.7908333333333331e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_10    OBJ       5.5855483042777793e-03
    x_8_10    product_lb_185  -2.5996533795467933e-02
    x_8_10    product_ub_186  -4.4264109184846939e-02
    x_8_10    onehot_8_191  1
    x_8_10    stock_lb_194  10
    x_8_10    stock_ub_195  10
    x_8_10    parent_nonstrict_scope_196  2.2342193217111131e-02
    x_8_10    unique_nonzero_owner_329  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_10    product_lb_185  1
    w_8_10    product_ub_186  1
    w_8_10    normalized_mass_8_192  1
    w_8_10    normalized_ratio_8_193  -1.6666666666666665e+00
    w_8_10    full_original_Gini_254  -2.2408333333333328e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_11    OBJ       1.1171096608555565e-02
    x_8_11    product_lb_187  -2.5996533795467933e-02
    x_8_11    product_ub_188  -4.4264109184846939e-02
    x_8_11    onehot_8_191  1
    x_8_11    stock_lb_194  11
    x_8_11    stock_ub_195  11
    x_8_11    parent_nonstrict_scope_196  2.7927741521388917e-02
    x_8_11    unique_nonzero_owner_330  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_11    product_lb_187  1
    w_8_11    product_ub_188  1
    w_8_11    normalized_mass_8_192  1
    w_8_11    normalized_ratio_8_193  -1.8333333333333333e+00
    w_8_11    full_original_Gini_254  -2.6908333333333328e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_12    OBJ       1.6756644912833352e-02
    x_8_12    product_lb_189  -2.5996533795467933e-02
    x_8_12    product_ub_190  -4.4264109184846939e-02
    x_8_12    onehot_8_191  1
    x_8_12    stock_lb_194  12
    x_8_12    stock_ub_195  12
    x_8_12    parent_nonstrict_scope_196  0.0335132898256667
    x_8_12    unique_nonzero_owner_331  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_12    product_lb_189  1
    w_8_12    product_ub_190  1
    w_8_12    normalized_mass_8_192  1
    w_8_12    normalized_ratio_8_193  -2
    w_8_12    full_original_Gini_254  -3.1408333333333331e+01
    rho_8     normalized_ratio_8_193  1
    rho_8     block_pair_pos_197  1
    rho_8     block_pair_neg_198  -1
    rho_8     block_pair_pos_211  1
    rho_8     block_pair_neg_212  -1
    rho_8     block_pair_pos_219  1
    rho_8     block_pair_neg_220  -1
    rho_8     block_pair_pos_231  1
    rho_8     block_pair_neg_232  -1
    rho_8     block_pair_pos_235  1
    rho_8     block_pair_neg_236  -1
    rho_8     block_pair_pos_237  1
    rho_8     block_pair_neg_238  -1
    rho_8     block_pair_pos_243  1
    rho_8     block_pair_neg_244  -1
    rho_8     normalization_253  1
    a_9_11    block_pair_pos_201  1
    a_9_11    block_pair_neg_202  1
    a_9_11    full_original_Gini_254  -1
    a_9_34    block_pair_pos_209  1
    a_9_34    block_pair_neg_210  1
    a_9_34    full_original_Gini_254  -1
    a_9_10    block_pair_pos_199  1
    a_9_10    block_pair_neg_200  1
    a_9_10    full_original_Gini_254  -1
    a_9_29    block_pair_pos_207  1
    a_9_29    block_pair_neg_208  1
    a_9_29    full_original_Gini_254  -1
    a_9_13    block_pair_pos_203  1
    a_9_13    block_pair_neg_204  1
    a_9_13    full_original_Gini_254  -1
    a_9_27    block_pair_pos_205  1
    a_9_27    block_pair_neg_206  1
    a_9_27    full_original_Gini_254  -1
    a_9_8     block_pair_pos_197  1
    a_9_8     block_pair_neg_198  1
    a_9_8     full_original_Gini_254  -1
    a_11_34   block_pair_pos_229  1
    a_11_34   block_pair_neg_230  1
    a_11_34   full_original_Gini_254  -1
    a_11_10   block_pair_pos_221  1
    a_11_10   block_pair_neg_222  1
    a_11_10   full_original_Gini_254  -1
    a_11_29   block_pair_pos_227  1
    a_11_29   block_pair_neg_228  1
    a_11_29   full_original_Gini_254  -1
    a_11_13   block_pair_pos_223  1
    a_11_13   block_pair_neg_224  1
    a_11_13   full_original_Gini_254  -1
    a_11_27   block_pair_pos_225  1
    a_11_27   block_pair_neg_226  1
    a_11_27   full_original_Gini_254  -1
    a_11_8    block_pair_pos_219  1
    a_11_8    block_pair_neg_220  1
    a_11_8    full_original_Gini_254  -1
    a_34_10   block_pair_pos_245  1
    a_34_10   block_pair_neg_246  1
    a_34_10   full_original_Gini_254  -1
    a_34_29   block_pair_pos_251  1
    a_34_29   block_pair_neg_252  1
    a_34_29   full_original_Gini_254  -1
    a_34_13   block_pair_pos_247  1
    a_34_13   block_pair_neg_248  1
    a_34_13   full_original_Gini_254  -1
    a_34_27   block_pair_pos_249  1
    a_34_27   block_pair_neg_250  1
    a_34_27   full_original_Gini_254  -1
    a_34_8    block_pair_pos_243  1
    a_34_8    block_pair_neg_244  1
    a_34_8    full_original_Gini_254  -1
    a_10_29   block_pair_pos_217  1
    a_10_29   block_pair_neg_218  1
    a_10_29   full_original_Gini_254  -1
    a_10_13   block_pair_pos_213  1
    a_10_13   block_pair_neg_214  1
    a_10_13   full_original_Gini_254  -1
    a_10_27   block_pair_pos_215  1
    a_10_27   block_pair_neg_216  1
    a_10_27   full_original_Gini_254  -1
    a_10_8    block_pair_pos_211  1
    a_10_8    block_pair_neg_212  1
    a_10_8    full_original_Gini_254  -1
    a_29_13   block_pair_pos_239  1
    a_29_13   block_pair_neg_240  1
    a_29_13   full_original_Gini_254  -1
    a_29_27   block_pair_pos_241  1
    a_29_27   block_pair_neg_242  1
    a_29_27   full_original_Gini_254  -1
    a_29_8    block_pair_pos_237  1
    a_29_8    block_pair_neg_238  1
    a_29_8    full_original_Gini_254  -1
    a_13_27   block_pair_pos_233  1
    a_13_27   block_pair_neg_234  1
    a_13_27   full_original_Gini_254  -1
    a_13_8    block_pair_pos_231  1
    a_13_8    block_pair_neg_232  1
    a_13_8    full_original_Gini_254  -1
    a_27_8    block_pair_pos_235  1
    a_27_8    block_pair_neg_236  1
    a_27_8    full_original_Gini_254  -1
    MARKER    'MARKER'                 'INTORG'
    service_0_9_0  unique_nonzero_owner_255  1
    service_0_9_0  service_visit_def_712  1
    service_0_9_0  free_load_conservation_713  -2
    service_0_9_0  original_T_including_depot_unload_760  240
    service_0_9_1  unique_nonzero_owner_256  1
    service_0_9_1  service_visit_def_712  1
    service_0_9_1  free_load_conservation_713  -1
    service_0_9_1  original_T_including_depot_unload_760  120
    service_0_9_3  unique_nonzero_owner_257  1
    service_0_9_3  service_visit_def_712  1
    service_0_9_3  free_load_conservation_713  1
    service_0_9_4  unique_nonzero_owner_258  1
    service_0_9_4  service_visit_def_712  1
    service_0_9_4  free_load_conservation_713  2
    service_0_9_5  unique_nonzero_owner_259  1
    service_0_9_5  service_visit_def_712  1
    service_0_9_5  free_load_conservation_713  3
    service_0_9_6  unique_nonzero_owner_260  1
    service_0_9_6  service_visit_def_712  1
    service_0_9_6  free_load_conservation_713  4
    service_0_9_7  unique_nonzero_owner_261  1
    service_0_9_7  service_visit_def_712  1
    service_0_9_7  free_load_conservation_713  5
    service_0_9_8  unique_nonzero_owner_262  1
    service_0_9_8  service_visit_def_712  1
    service_0_9_8  free_load_conservation_713  6
    service_0_9_9  unique_nonzero_owner_263  1
    service_0_9_9  service_visit_def_712  1
    service_0_9_9  free_load_conservation_713  7
    service_0_9_10  unique_nonzero_owner_264  1
    service_0_9_10  service_visit_def_712  1
    service_0_9_10  free_load_conservation_713  8
    service_1_9_0  unique_nonzero_owner_255  1
    service_1_9_0  service_visit_def_1084  1
    service_1_9_0  free_load_conservation_1085  -2
    service_1_9_0  original_T_including_depot_unload_1131  240
    service_1_9_1  unique_nonzero_owner_256  1
    service_1_9_1  service_visit_def_1084  1
    service_1_9_1  free_load_conservation_1085  -1
    service_1_9_1  original_T_including_depot_unload_1131  120
    service_1_9_3  unique_nonzero_owner_257  1
    service_1_9_3  service_visit_def_1084  1
    service_1_9_3  free_load_conservation_1085  1
    service_1_9_4  unique_nonzero_owner_258  1
    service_1_9_4  service_visit_def_1084  1
    service_1_9_4  free_load_conservation_1085  2
    service_1_9_5  unique_nonzero_owner_259  1
    service_1_9_5  service_visit_def_1084  1
    service_1_9_5  free_load_conservation_1085  3
    service_1_9_6  unique_nonzero_owner_260  1
    service_1_9_6  service_visit_def_1084  1
    service_1_9_6  free_load_conservation_1085  4
    service_1_9_7  unique_nonzero_owner_261  1
    service_1_9_7  service_visit_def_1084  1
    service_1_9_7  free_load_conservation_1085  5
    service_1_9_8  unique_nonzero_owner_262  1
    service_1_9_8  service_visit_def_1084  1
    service_1_9_8  free_load_conservation_1085  6
    service_1_9_9  unique_nonzero_owner_263  1
    service_1_9_9  service_visit_def_1084  1
    service_1_9_9  free_load_conservation_1085  7
    service_1_9_10  unique_nonzero_owner_264  1
    service_1_9_10  service_visit_def_1084  1
    service_1_9_10  free_load_conservation_1085  8
    service_2_9_0  unique_nonzero_owner_255  1
    service_2_9_0  service_visit_def_1402  1
    service_2_9_0  free_load_conservation_1403  -2
    service_2_9_0  original_T_including_depot_unload_1448  240
    service_2_9_1  unique_nonzero_owner_256  1
    service_2_9_1  service_visit_def_1402  1
    service_2_9_1  free_load_conservation_1403  -1
    service_2_9_1  original_T_including_depot_unload_1448  120
    service_2_9_3  unique_nonzero_owner_257  1
    service_2_9_3  service_visit_def_1402  1
    service_2_9_3  free_load_conservation_1403  1
    service_2_9_4  unique_nonzero_owner_258  1
    service_2_9_4  service_visit_def_1402  1
    service_2_9_4  free_load_conservation_1403  2
    service_2_9_5  unique_nonzero_owner_259  1
    service_2_9_5  service_visit_def_1402  1
    service_2_9_5  free_load_conservation_1403  3
    service_2_9_6  unique_nonzero_owner_260  1
    service_2_9_6  service_visit_def_1402  1
    service_2_9_6  free_load_conservation_1403  4
    service_2_9_7  unique_nonzero_owner_261  1
    service_2_9_7  service_visit_def_1402  1
    service_2_9_7  free_load_conservation_1403  5
    service_2_9_8  unique_nonzero_owner_262  1
    service_2_9_8  service_visit_def_1402  1
    service_2_9_8  free_load_conservation_1403  6
    service_2_9_9  unique_nonzero_owner_263  1
    service_2_9_9  service_visit_def_1402  1
    service_2_9_9  free_load_conservation_1403  7
    service_2_9_10  unique_nonzero_owner_264  1
    service_2_9_10  service_visit_def_1402  1
    service_2_9_10  free_load_conservation_1403  8
    service_0_11_0  unique_nonzero_owner_265  1
    service_0_11_0  service_visit_def_718  1
    service_0_11_0  free_load_conservation_719  -8
    service_0_11_0  original_T_including_depot_unload_760  960
    service_0_11_1  unique_nonzero_owner_266  1
    service_0_11_1  service_visit_def_718  1
    service_0_11_1  free_load_conservation_719  -7
    service_0_11_1  original_T_including_depot_unload_760  840
    service_0_11_2  unique_nonzero_owner_267  1
    service_0_11_2  service_visit_def_718  1
    service_0_11_2  free_load_conservation_719  -6
    service_0_11_2  original_T_including_depot_unload_760  720
    service_0_11_3  unique_nonzero_owner_268  1
    service_0_11_3  service_visit_def_718  1
    service_0_11_3  free_load_conservation_719  -5
    service_0_11_3  original_T_including_depot_unload_760  600
    service_0_11_4  unique_nonzero_owner_269  1
    service_0_11_4  service_visit_def_718  1
    service_0_11_4  free_load_conservation_719  -4
    service_0_11_4  original_T_including_depot_unload_760  480
    service_0_11_5  unique_nonzero_owner_270  1
    service_0_11_5  service_visit_def_718  1
    service_0_11_5  free_load_conservation_719  -3
    service_0_11_5  original_T_including_depot_unload_760  360
    service_0_11_6  unique_nonzero_owner_271  1
    service_0_11_6  service_visit_def_718  1
    service_0_11_6  free_load_conservation_719  -2
    service_0_11_6  original_T_including_depot_unload_760  240
    service_0_11_7  unique_nonzero_owner_272  1
    service_0_11_7  service_visit_def_718  1
    service_0_11_7  free_load_conservation_719  -1
    service_0_11_7  original_T_including_depot_unload_760  120
    service_0_11_9  unique_nonzero_owner_273  1
    service_0_11_9  service_visit_def_718  1
    service_0_11_9  free_load_conservation_719  1
    service_0_11_10  unique_nonzero_owner_274  1
    service_0_11_10  service_visit_def_718  1
    service_0_11_10  free_load_conservation_719  2
    service_1_11_0  unique_nonzero_owner_265  1
    service_1_11_0  service_visit_def_1090  1
    service_1_11_0  free_load_conservation_1091  -8
    service_1_11_0  original_T_including_depot_unload_1131  960
    service_1_11_1  unique_nonzero_owner_266  1
    service_1_11_1  service_visit_def_1090  1
    service_1_11_1  free_load_conservation_1091  -7
    service_1_11_1  original_T_including_depot_unload_1131  840
    service_1_11_2  unique_nonzero_owner_267  1
    service_1_11_2  service_visit_def_1090  1
    service_1_11_2  free_load_conservation_1091  -6
    service_1_11_2  original_T_including_depot_unload_1131  720
    service_1_11_3  unique_nonzero_owner_268  1
    service_1_11_3  service_visit_def_1090  1
    service_1_11_3  free_load_conservation_1091  -5
    service_1_11_3  original_T_including_depot_unload_1131  600
    service_1_11_4  unique_nonzero_owner_269  1
    service_1_11_4  service_visit_def_1090  1
    service_1_11_4  free_load_conservation_1091  -4
    service_1_11_4  original_T_including_depot_unload_1131  480
    service_1_11_5  unique_nonzero_owner_270  1
    service_1_11_5  service_visit_def_1090  1
    service_1_11_5  free_load_conservation_1091  -3
    service_1_11_5  original_T_including_depot_unload_1131  360
    service_1_11_6  unique_nonzero_owner_271  1
    service_1_11_6  service_visit_def_1090  1
    service_1_11_6  free_load_conservation_1091  -2
    service_1_11_6  original_T_including_depot_unload_1131  240
    service_1_11_7  unique_nonzero_owner_272  1
    service_1_11_7  service_visit_def_1090  1
    service_1_11_7  free_load_conservation_1091  -1
    service_1_11_7  original_T_including_depot_unload_1131  120
    service_1_11_9  unique_nonzero_owner_273  1
    service_1_11_9  service_visit_def_1090  1
    service_1_11_9  free_load_conservation_1091  1
    service_1_11_10  unique_nonzero_owner_274  1
    service_1_11_10  service_visit_def_1090  1
    service_1_11_10  free_load_conservation_1091  2
    service_2_11_0  unique_nonzero_owner_265  1
    service_2_11_0  service_visit_def_1408  1
    service_2_11_0  free_load_conservation_1409  -8
    service_2_11_0  original_T_including_depot_unload_1448  960
    service_2_11_1  unique_nonzero_owner_266  1
    service_2_11_1  service_visit_def_1408  1
    service_2_11_1  free_load_conservation_1409  -7
    service_2_11_1  original_T_including_depot_unload_1448  840
    service_2_11_2  unique_nonzero_owner_267  1
    service_2_11_2  service_visit_def_1408  1
    service_2_11_2  free_load_conservation_1409  -6
    service_2_11_2  original_T_including_depot_unload_1448  720
    service_2_11_3  unique_nonzero_owner_268  1
    service_2_11_3  service_visit_def_1408  1
    service_2_11_3  free_load_conservation_1409  -5
    service_2_11_3  original_T_including_depot_unload_1448  600
    service_2_11_4  unique_nonzero_owner_269  1
    service_2_11_4  service_visit_def_1408  1
    service_2_11_4  free_load_conservation_1409  -4
    service_2_11_4  original_T_including_depot_unload_1448  480
    service_2_11_5  unique_nonzero_owner_270  1
    service_2_11_5  service_visit_def_1408  1
    service_2_11_5  free_load_conservation_1409  -3
    service_2_11_5  original_T_including_depot_unload_1448  360
    service_2_11_6  unique_nonzero_owner_271  1
    service_2_11_6  service_visit_def_1408  1
    service_2_11_6  free_load_conservation_1409  -2
    service_2_11_6  original_T_including_depot_unload_1448  240
    service_2_11_7  unique_nonzero_owner_272  1
    service_2_11_7  service_visit_def_1408  1
    service_2_11_7  free_load_conservation_1409  -1
    service_2_11_7  original_T_including_depot_unload_1448  120
    service_2_11_9  unique_nonzero_owner_273  1
    service_2_11_9  service_visit_def_1408  1
    service_2_11_9  free_load_conservation_1409  1
    service_2_11_10  unique_nonzero_owner_274  1
    service_2_11_10  service_visit_def_1408  1
    service_2_11_10  free_load_conservation_1409  2
    service_0_34_0  unique_nonzero_owner_275  1
    service_0_34_0  service_visit_def_724  1
    service_0_34_0  free_load_conservation_725  -2
    service_0_34_0  original_T_including_depot_unload_760  240
    service_0_34_1  unique_nonzero_owner_276  1
    service_0_34_1  service_visit_def_724  1
    service_0_34_1  free_load_conservation_725  -1
    service_0_34_1  original_T_including_depot_unload_760  120
    service_0_34_3  unique_nonzero_owner_277  1
    service_0_34_3  service_visit_def_724  1
    service_0_34_3  free_load_conservation_725  1
    service_0_34_4  unique_nonzero_owner_278  1
    service_0_34_4  service_visit_def_724  1
    service_0_34_4  free_load_conservation_725  2
    service_0_34_5  unique_nonzero_owner_279  1
    service_0_34_5  service_visit_def_724  1
    service_0_34_5  free_load_conservation_725  3
    service_0_34_6  unique_nonzero_owner_280  1
    service_0_34_6  service_visit_def_724  1
    service_0_34_6  free_load_conservation_725  4
    service_0_34_7  unique_nonzero_owner_281  1
    service_0_34_7  service_visit_def_724  1
    service_0_34_7  free_load_conservation_725  5
    service_0_34_8  unique_nonzero_owner_282  1
    service_0_34_8  service_visit_def_724  1
    service_0_34_8  free_load_conservation_725  6
    service_0_34_9  unique_nonzero_owner_283  1
    service_0_34_9  service_visit_def_724  1
    service_0_34_9  free_load_conservation_725  7
    service_0_34_10  unique_nonzero_owner_284  1
    service_0_34_10  service_visit_def_724  1
    service_0_34_10  free_load_conservation_725  8
    service_0_34_11  unique_nonzero_owner_285  1
    service_0_34_11  service_visit_def_724  1
    service_0_34_11  free_load_conservation_725  9
    service_0_34_12  unique_nonzero_owner_286  1
    service_0_34_12  service_visit_def_724  1
    service_0_34_12  free_load_conservation_725  10
    service_0_34_13  unique_nonzero_owner_287  1
    service_0_34_13  service_visit_def_724  1
    service_0_34_13  free_load_conservation_725  11
    service_0_34_14  unique_nonzero_owner_288  1
    service_0_34_14  service_visit_def_724  1
    service_0_34_14  free_load_conservation_725  12
    service_0_34_15  unique_nonzero_owner_289  1
    service_0_34_15  service_visit_def_724  1
    service_0_34_15  free_load_conservation_725  13
    service_1_34_0  unique_nonzero_owner_275  1
    service_1_34_0  service_visit_def_1096  1
    service_1_34_0  free_load_conservation_1097  -2
    service_1_34_0  original_T_including_depot_unload_1131  240
    service_1_34_1  unique_nonzero_owner_276  1
    service_1_34_1  service_visit_def_1096  1
    service_1_34_1  free_load_conservation_1097  -1
    service_1_34_1  original_T_including_depot_unload_1131  120
    service_1_34_3  unique_nonzero_owner_277  1
    service_1_34_3  service_visit_def_1096  1
    service_1_34_3  free_load_conservation_1097  1
    service_1_34_4  unique_nonzero_owner_278  1
    service_1_34_4  service_visit_def_1096  1
    service_1_34_4  free_load_conservation_1097  2
    service_1_34_5  unique_nonzero_owner_279  1
    service_1_34_5  service_visit_def_1096  1
    service_1_34_5  free_load_conservation_1097  3
    service_1_34_6  unique_nonzero_owner_280  1
    service_1_34_6  service_visit_def_1096  1
    service_1_34_6  free_load_conservation_1097  4
    service_1_34_7  unique_nonzero_owner_281  1
    service_1_34_7  service_visit_def_1096  1
    service_1_34_7  free_load_conservation_1097  5
    service_1_34_8  unique_nonzero_owner_282  1
    service_1_34_8  service_visit_def_1096  1
    service_1_34_8  free_load_conservation_1097  6
    service_1_34_9  unique_nonzero_owner_283  1
    service_1_34_9  service_visit_def_1096  1
    service_1_34_9  free_load_conservation_1097  7
    service_1_34_10  unique_nonzero_owner_284  1
    service_1_34_10  service_visit_def_1096  1
    service_1_34_10  free_load_conservation_1097  8
    service_1_34_11  unique_nonzero_owner_285  1
    service_1_34_11  service_visit_def_1096  1
    service_1_34_11  free_load_conservation_1097  9
    service_1_34_12  unique_nonzero_owner_286  1
    service_1_34_12  service_visit_def_1096  1
    service_1_34_12  free_load_conservation_1097  10
    service_1_34_13  unique_nonzero_owner_287  1
    service_1_34_13  service_visit_def_1096  1
    service_1_34_13  free_load_conservation_1097  11
    service_1_34_14  unique_nonzero_owner_288  1
    service_1_34_14  service_visit_def_1096  1
    service_1_34_14  free_load_conservation_1097  12
    service_1_34_15  unique_nonzero_owner_289  1
    service_1_34_15  service_visit_def_1096  1
    service_1_34_15  free_load_conservation_1097  13
    service_2_34_0  unique_nonzero_owner_275  1
    service_2_34_0  service_visit_def_1414  1
    service_2_34_0  free_load_conservation_1415  -2
    service_2_34_0  original_T_including_depot_unload_1448  240
    service_2_34_1  unique_nonzero_owner_276  1
    service_2_34_1  service_visit_def_1414  1
    service_2_34_1  free_load_conservation_1415  -1
    service_2_34_1  original_T_including_depot_unload_1448  120
    service_2_34_3  unique_nonzero_owner_277  1
    service_2_34_3  service_visit_def_1414  1
    service_2_34_3  free_load_conservation_1415  1
    service_2_34_4  unique_nonzero_owner_278  1
    service_2_34_4  service_visit_def_1414  1
    service_2_34_4  free_load_conservation_1415  2
    service_2_34_5  unique_nonzero_owner_279  1
    service_2_34_5  service_visit_def_1414  1
    service_2_34_5  free_load_conservation_1415  3
    service_2_34_6  unique_nonzero_owner_280  1
    service_2_34_6  service_visit_def_1414  1
    service_2_34_6  free_load_conservation_1415  4
    service_2_34_7  unique_nonzero_owner_281  1
    service_2_34_7  service_visit_def_1414  1
    service_2_34_7  free_load_conservation_1415  5
    service_2_34_8  unique_nonzero_owner_282  1
    service_2_34_8  service_visit_def_1414  1
    service_2_34_8  free_load_conservation_1415  6
    service_2_34_9  unique_nonzero_owner_283  1
    service_2_34_9  service_visit_def_1414  1
    service_2_34_9  free_load_conservation_1415  7
    service_2_34_10  unique_nonzero_owner_284  1
    service_2_34_10  service_visit_def_1414  1
    service_2_34_10  free_load_conservation_1415  8
    service_2_34_11  unique_nonzero_owner_285  1
    service_2_34_11  service_visit_def_1414  1
    service_2_34_11  free_load_conservation_1415  9
    service_2_34_12  unique_nonzero_owner_286  1
    service_2_34_12  service_visit_def_1414  1
    service_2_34_12  free_load_conservation_1415  10
    service_2_34_13  unique_nonzero_owner_287  1
    service_2_34_13  service_visit_def_1414  1
    service_2_34_13  free_load_conservation_1415  11
    service_2_34_14  unique_nonzero_owner_288  1
    service_2_34_14  service_visit_def_1414  1
    service_2_34_14  free_load_conservation_1415  12
    service_2_34_15  unique_nonzero_owner_289  1
    service_2_34_15  service_visit_def_1414  1
    service_2_34_15  free_load_conservation_1415  13
    service_0_10_0  unique_nonzero_owner_290  1
    service_0_10_0  service_visit_def_730  1
    service_0_10_0  free_load_conservation_731  -4
    service_0_10_0  original_T_including_depot_unload_760  480
    service_0_10_1  unique_nonzero_owner_291  1
    service_0_10_1  service_visit_def_730  1
    service_0_10_1  free_load_conservation_731  -3
    service_0_10_1  original_T_including_depot_unload_760  360
    service_0_10_2  unique_nonzero_owner_292  1
    service_0_10_2  service_visit_def_730  1
    service_0_10_2  free_load_conservation_731  -2
    service_0_10_2  original_T_including_depot_unload_760  240
    service_0_10_3  unique_nonzero_owner_293  1
    service_0_10_3  service_visit_def_730  1
    service_0_10_3  free_load_conservation_731  -1
    service_0_10_3  original_T_including_depot_unload_760  120
    service_0_10_5  unique_nonzero_owner_294  1
    service_0_10_5  service_visit_def_730  1
    service_0_10_5  free_load_conservation_731  1
    service_0_10_6  unique_nonzero_owner_295  1
    service_0_10_6  service_visit_def_730  1
    service_0_10_6  free_load_conservation_731  2
    service_1_10_0  unique_nonzero_owner_290  1
    service_1_10_0  service_visit_def_1102  1
    service_1_10_0  free_load_conservation_1103  -4
    service_1_10_0  original_T_including_depot_unload_1131  480
    service_1_10_1  unique_nonzero_owner_291  1
    service_1_10_1  service_visit_def_1102  1
    service_1_10_1  free_load_conservation_1103  -3
    service_1_10_1  original_T_including_depot_unload_1131  360
    service_1_10_2  unique_nonzero_owner_292  1
    service_1_10_2  service_visit_def_1102  1
    service_1_10_2  free_load_conservation_1103  -2
    service_1_10_2  original_T_including_depot_unload_1131  240
    service_1_10_3  unique_nonzero_owner_293  1
    service_1_10_3  service_visit_def_1102  1
    service_1_10_3  free_load_conservation_1103  -1
    service_1_10_3  original_T_including_depot_unload_1131  120
    service_1_10_5  unique_nonzero_owner_294  1
    service_1_10_5  service_visit_def_1102  1
    service_1_10_5  free_load_conservation_1103  1
    service_1_10_6  unique_nonzero_owner_295  1
    service_1_10_6  service_visit_def_1102  1
    service_1_10_6  free_load_conservation_1103  2
    service_2_10_0  unique_nonzero_owner_290  1
    service_2_10_0  service_visit_def_1420  1
    service_2_10_0  free_load_conservation_1421  -4
    service_2_10_0  original_T_including_depot_unload_1448  480
    service_2_10_1  unique_nonzero_owner_291  1
    service_2_10_1  service_visit_def_1420  1
    service_2_10_1  free_load_conservation_1421  -3
    service_2_10_1  original_T_including_depot_unload_1448  360
    service_2_10_2  unique_nonzero_owner_292  1
    service_2_10_2  service_visit_def_1420  1
    service_2_10_2  free_load_conservation_1421  -2
    service_2_10_2  original_T_including_depot_unload_1448  240
    service_2_10_3  unique_nonzero_owner_293  1
    service_2_10_3  service_visit_def_1420  1
    service_2_10_3  free_load_conservation_1421  -1
    service_2_10_3  original_T_including_depot_unload_1448  120
    service_2_10_5  unique_nonzero_owner_294  1
    service_2_10_5  service_visit_def_1420  1
    service_2_10_5  free_load_conservation_1421  1
    service_2_10_6  unique_nonzero_owner_295  1
    service_2_10_6  service_visit_def_1420  1
    service_2_10_6  free_load_conservation_1421  2
    service_0_29_0  unique_nonzero_owner_296  1
    service_0_29_0  service_visit_def_736  1
    service_0_29_0  free_load_conservation_737  -1
    service_0_29_0  original_T_including_depot_unload_760  120
    service_0_29_2  unique_nonzero_owner_297  1
    service_0_29_2  service_visit_def_736  1
    service_0_29_2  free_load_conservation_737  1
    service_0_29_3  unique_nonzero_owner_298  1
    service_0_29_3  service_visit_def_736  1
    service_0_29_3  free_load_conservation_737  2
    service_0_29_4  unique_nonzero_owner_299  1
    service_0_29_4  service_visit_def_736  1
    service_0_29_4  free_load_conservation_737  3
    service_0_29_5  unique_nonzero_owner_300  1
    service_0_29_5  service_visit_def_736  1
    service_0_29_5  free_load_conservation_737  4
    service_0_29_6  unique_nonzero_owner_301  1
    service_0_29_6  service_visit_def_736  1
    service_0_29_6  free_load_conservation_737  5
    service_0_29_7  unique_nonzero_owner_302  1
    service_0_29_7  service_visit_def_736  1
    service_0_29_7  free_load_conservation_737  6
    service_0_29_8  unique_nonzero_owner_303  1
    service_0_29_8  service_visit_def_736  1
    service_0_29_8  free_load_conservation_737  7
    service_0_29_9  unique_nonzero_owner_304  1
    service_0_29_9  service_visit_def_736  1
    service_0_29_9  free_load_conservation_737  8
    service_0_29_10  unique_nonzero_owner_305  1
    service_0_29_10  service_visit_def_736  1
    service_0_29_10  free_load_conservation_737  9
    service_1_29_0  unique_nonzero_owner_296  1
    service_1_29_0  service_visit_def_1108  1
    service_1_29_0  free_load_conservation_1109  -1
    service_1_29_0  original_T_including_depot_unload_1131  120
    service_1_29_2  unique_nonzero_owner_297  1
    service_1_29_2  service_visit_def_1108  1
    service_1_29_2  free_load_conservation_1109  1
    service_1_29_3  unique_nonzero_owner_298  1
    service_1_29_3  service_visit_def_1108  1
    service_1_29_3  free_load_conservation_1109  2
    service_1_29_4  unique_nonzero_owner_299  1
    service_1_29_4  service_visit_def_1108  1
    service_1_29_4  free_load_conservation_1109  3
    service_1_29_5  unique_nonzero_owner_300  1
    service_1_29_5  service_visit_def_1108  1
    service_1_29_5  free_load_conservation_1109  4
    service_1_29_6  unique_nonzero_owner_301  1
    service_1_29_6  service_visit_def_1108  1
    service_1_29_6  free_load_conservation_1109  5
    service_1_29_7  unique_nonzero_owner_302  1
    service_1_29_7  service_visit_def_1108  1
    service_1_29_7  free_load_conservation_1109  6
    service_1_29_8  unique_nonzero_owner_303  1
    service_1_29_8  service_visit_def_1108  1
    service_1_29_8  free_load_conservation_1109  7
    service_1_29_9  unique_nonzero_owner_304  1
    service_1_29_9  service_visit_def_1108  1
    service_1_29_9  free_load_conservation_1109  8
    service_1_29_10  unique_nonzero_owner_305  1
    service_1_29_10  service_visit_def_1108  1
    service_1_29_10  free_load_conservation_1109  9
    service_2_29_0  unique_nonzero_owner_296  1
    service_2_29_0  service_visit_def_1426  1
    service_2_29_0  free_load_conservation_1427  -1
    service_2_29_0  original_T_including_depot_unload_1448  120
    service_2_29_2  unique_nonzero_owner_297  1
    service_2_29_2  service_visit_def_1426  1
    service_2_29_2  free_load_conservation_1427  1
    service_2_29_3  unique_nonzero_owner_298  1
    service_2_29_3  service_visit_def_1426  1
    service_2_29_3  free_load_conservation_1427  2
    service_2_29_4  unique_nonzero_owner_299  1
    service_2_29_4  service_visit_def_1426  1
    service_2_29_4  free_load_conservation_1427  3
    service_2_29_5  unique_nonzero_owner_300  1
    service_2_29_5  service_visit_def_1426  1
    service_2_29_5  free_load_conservation_1427  4
    service_2_29_6  unique_nonzero_owner_301  1
    service_2_29_6  service_visit_def_1426  1
    service_2_29_6  free_load_conservation_1427  5
    service_2_29_7  unique_nonzero_owner_302  1
    service_2_29_7  service_visit_def_1426  1
    service_2_29_7  free_load_conservation_1427  6
    service_2_29_8  unique_nonzero_owner_303  1
    service_2_29_8  service_visit_def_1426  1
    service_2_29_8  free_load_conservation_1427  7
    service_2_29_9  unique_nonzero_owner_304  1
    service_2_29_9  service_visit_def_1426  1
    service_2_29_9  free_load_conservation_1427  8
    service_2_29_10  unique_nonzero_owner_305  1
    service_2_29_10  service_visit_def_1426  1
    service_2_29_10  free_load_conservation_1427  9
    service_0_13_0  unique_nonzero_owner_306  1
    service_0_13_0  service_visit_def_742  1
    service_0_13_0  free_load_conservation_743  -5
    service_0_13_0  original_T_including_depot_unload_760  600
    service_0_13_1  unique_nonzero_owner_307  1
    service_0_13_1  service_visit_def_742  1
    service_0_13_1  free_load_conservation_743  -4
    service_0_13_1  original_T_including_depot_unload_760  480
    service_0_13_2  unique_nonzero_owner_308  1
    service_0_13_2  service_visit_def_742  1
    service_0_13_2  free_load_conservation_743  -3
    service_0_13_2  original_T_including_depot_unload_760  360
    service_0_13_3  unique_nonzero_owner_309  1
    service_0_13_3  service_visit_def_742  1
    service_0_13_3  free_load_conservation_743  -2
    service_0_13_3  original_T_including_depot_unload_760  240
    service_0_13_4  unique_nonzero_owner_310  1
    service_0_13_4  service_visit_def_742  1
    service_0_13_4  free_load_conservation_743  -1
    service_0_13_4  original_T_including_depot_unload_760  120
    service_0_13_6  unique_nonzero_owner_311  1
    service_0_13_6  service_visit_def_742  1
    service_0_13_6  free_load_conservation_743  1
    service_0_13_7  unique_nonzero_owner_312  1
    service_0_13_7  service_visit_def_742  1
    service_0_13_7  free_load_conservation_743  2
    service_0_13_8  unique_nonzero_owner_313  1
    service_0_13_8  service_visit_def_742  1
    service_0_13_8  free_load_conservation_743  3
    service_1_13_0  unique_nonzero_owner_306  1
    service_1_13_0  service_visit_def_1114  1
    service_1_13_0  free_load_conservation_1115  -5
    service_1_13_0  original_T_including_depot_unload_1131  600
    service_1_13_1  unique_nonzero_owner_307  1
    service_1_13_1  service_visit_def_1114  1
    service_1_13_1  free_load_conservation_1115  -4
    service_1_13_1  original_T_including_depot_unload_1131  480
    service_1_13_2  unique_nonzero_owner_308  1
    service_1_13_2  service_visit_def_1114  1
    service_1_13_2  free_load_conservation_1115  -3
    service_1_13_2  original_T_including_depot_unload_1131  360
    service_1_13_3  unique_nonzero_owner_309  1
    service_1_13_3  service_visit_def_1114  1
    service_1_13_3  free_load_conservation_1115  -2
    service_1_13_3  original_T_including_depot_unload_1131  240
    service_1_13_4  unique_nonzero_owner_310  1
    service_1_13_4  service_visit_def_1114  1
    service_1_13_4  free_load_conservation_1115  -1
    service_1_13_4  original_T_including_depot_unload_1131  120
    service_1_13_6  unique_nonzero_owner_311  1
    service_1_13_6  service_visit_def_1114  1
    service_1_13_6  free_load_conservation_1115  1
    service_1_13_7  unique_nonzero_owner_312  1
    service_1_13_7  service_visit_def_1114  1
    service_1_13_7  free_load_conservation_1115  2
    service_1_13_8  unique_nonzero_owner_313  1
    service_1_13_8  service_visit_def_1114  1
    service_1_13_8  free_load_conservation_1115  3
    service_2_13_0  unique_nonzero_owner_306  1
    service_2_13_0  service_visit_def_1432  1
    service_2_13_0  free_load_conservation_1433  -5
    service_2_13_0  original_T_including_depot_unload_1448  600
    service_2_13_1  unique_nonzero_owner_307  1
    service_2_13_1  service_visit_def_1432  1
    service_2_13_1  free_load_conservation_1433  -4
    service_2_13_1  original_T_including_depot_unload_1448  480
    service_2_13_2  unique_nonzero_owner_308  1
    service_2_13_2  service_visit_def_1432  1
    service_2_13_2  free_load_conservation_1433  -3
    service_2_13_2  original_T_including_depot_unload_1448  360
    service_2_13_3  unique_nonzero_owner_309  1
    service_2_13_3  service_visit_def_1432  1
    service_2_13_3  free_load_conservation_1433  -2
    service_2_13_3  original_T_including_depot_unload_1448  240
    service_2_13_4  unique_nonzero_owner_310  1
    service_2_13_4  service_visit_def_1432  1
    service_2_13_4  free_load_conservation_1433  -1
    service_2_13_4  original_T_including_depot_unload_1448  120
    service_2_13_6  unique_nonzero_owner_311  1
    service_2_13_6  service_visit_def_1432  1
    service_2_13_6  free_load_conservation_1433  1
    service_2_13_7  unique_nonzero_owner_312  1
    service_2_13_7  service_visit_def_1432  1
    service_2_13_7  free_load_conservation_1433  2
    service_2_13_8  unique_nonzero_owner_313  1
    service_2_13_8  service_visit_def_1432  1
    service_2_13_8  free_load_conservation_1433  3
    service_0_27_1  unique_nonzero_owner_314  1
    service_0_27_1  service_visit_def_748  1
    service_0_27_1  free_load_conservation_749  1
    service_0_27_2  unique_nonzero_owner_315  1
    service_0_27_2  service_visit_def_748  1
    service_0_27_2  free_load_conservation_749  2
    service_0_27_3  unique_nonzero_owner_316  1
    service_0_27_3  service_visit_def_748  1
    service_0_27_3  free_load_conservation_749  3
    service_0_27_4  unique_nonzero_owner_317  1
    service_0_27_4  service_visit_def_748  1
    service_0_27_4  free_load_conservation_749  4
    service_0_27_5  unique_nonzero_owner_318  1
    service_0_27_5  service_visit_def_748  1
    service_0_27_5  free_load_conservation_749  5
    service_0_27_6  unique_nonzero_owner_319  1
    service_0_27_6  service_visit_def_748  1
    service_0_27_6  free_load_conservation_749  6
    service_1_27_1  unique_nonzero_owner_314  1
    service_1_27_1  service_visit_def_1120  1
    service_1_27_1  free_load_conservation_1121  1
    service_1_27_2  unique_nonzero_owner_315  1
    service_1_27_2  service_visit_def_1120  1
    service_1_27_2  free_load_conservation_1121  2
    service_1_27_3  unique_nonzero_owner_316  1
    service_1_27_3  service_visit_def_1120  1
    service_1_27_3  free_load_conservation_1121  3
    service_1_27_4  unique_nonzero_owner_317  1
    service_1_27_4  service_visit_def_1120  1
    service_1_27_4  free_load_conservation_1121  4
    service_1_27_5  unique_nonzero_owner_318  1
    service_1_27_5  service_visit_def_1120  1
    service_1_27_5  free_load_conservation_1121  5
    service_1_27_6  unique_nonzero_owner_319  1
    service_1_27_6  service_visit_def_1120  1
    service_1_27_6  free_load_conservation_1121  6
    service_2_27_1  unique_nonzero_owner_314  1
    service_2_27_1  service_visit_def_1438  1
    service_2_27_1  free_load_conservation_1439  1
    service_2_27_2  unique_nonzero_owner_315  1
    service_2_27_2  service_visit_def_1438  1
    service_2_27_2  free_load_conservation_1439  2
    service_2_27_3  unique_nonzero_owner_316  1
    service_2_27_3  service_visit_def_1438  1
    service_2_27_3  free_load_conservation_1439  3
    service_2_27_4  unique_nonzero_owner_317  1
    service_2_27_4  service_visit_def_1438  1
    service_2_27_4  free_load_conservation_1439  4
    service_2_27_5  unique_nonzero_owner_318  1
    service_2_27_5  service_visit_def_1438  1
    service_2_27_5  free_load_conservation_1439  5
    service_2_27_6  unique_nonzero_owner_319  1
    service_2_27_6  service_visit_def_1438  1
    service_2_27_6  free_load_conservation_1439  6
    service_0_8_0  unique_nonzero_owner_320  1
    service_0_8_0  service_visit_def_754  1
    service_0_8_0  free_load_conservation_755  -9
    service_0_8_0  original_T_including_depot_unload_760  1080
    service_0_8_1  unique_nonzero_owner_321  1
    service_0_8_1  service_visit_def_754  1
    service_0_8_1  free_load_conservation_755  -8
    service_0_8_1  original_T_including_depot_unload_760  960
    service_0_8_2  unique_nonzero_owner_322  1
    service_0_8_2  service_visit_def_754  1
    service_0_8_2  free_load_conservation_755  -7
    service_0_8_2  original_T_including_depot_unload_760  840
    service_0_8_3  unique_nonzero_owner_323  1
    service_0_8_3  service_visit_def_754  1
    service_0_8_3  free_load_conservation_755  -6
    service_0_8_3  original_T_including_depot_unload_760  720
    service_0_8_4  unique_nonzero_owner_324  1
    service_0_8_4  service_visit_def_754  1
    service_0_8_4  free_load_conservation_755  -5
    service_0_8_4  original_T_including_depot_unload_760  600
    service_0_8_5  unique_nonzero_owner_325  1
    service_0_8_5  service_visit_def_754  1
    service_0_8_5  free_load_conservation_755  -4
    service_0_8_5  original_T_including_depot_unload_760  480
    service_0_8_6  unique_nonzero_owner_326  1
    service_0_8_6  service_visit_def_754  1
    service_0_8_6  free_load_conservation_755  -3
    service_0_8_6  original_T_including_depot_unload_760  360
    service_0_8_7  unique_nonzero_owner_327  1
    service_0_8_7  service_visit_def_754  1
    service_0_8_7  free_load_conservation_755  -2
    service_0_8_7  original_T_including_depot_unload_760  240
    service_0_8_8  unique_nonzero_owner_328  1
    service_0_8_8  service_visit_def_754  1
    service_0_8_8  free_load_conservation_755  -1
    service_0_8_8  original_T_including_depot_unload_760  120
    service_0_8_10  unique_nonzero_owner_329  1
    service_0_8_10  service_visit_def_754  1
    service_0_8_10  free_load_conservation_755  1
    service_0_8_11  unique_nonzero_owner_330  1
    service_0_8_11  service_visit_def_754  1
    service_0_8_11  free_load_conservation_755  2
    service_0_8_12  unique_nonzero_owner_331  1
    service_0_8_12  service_visit_def_754  1
    service_0_8_12  free_load_conservation_755  3
    service_1_8_0  unique_nonzero_owner_320  1
    service_1_8_0  service_visit_def_1126  1
    service_1_8_0  free_load_conservation_1127  -9
    service_1_8_0  original_T_including_depot_unload_1131  1080
    service_1_8_1  unique_nonzero_owner_321  1
    service_1_8_1  service_visit_def_1126  1
    service_1_8_1  free_load_conservation_1127  -8
    service_1_8_1  original_T_including_depot_unload_1131  960
    service_1_8_2  unique_nonzero_owner_322  1
    service_1_8_2  service_visit_def_1126  1
    service_1_8_2  free_load_conservation_1127  -7
    service_1_8_2  original_T_including_depot_unload_1131  840
    service_1_8_3  unique_nonzero_owner_323  1
    service_1_8_3  service_visit_def_1126  1
    service_1_8_3  free_load_conservation_1127  -6
    service_1_8_3  original_T_including_depot_unload_1131  720
    service_1_8_4  unique_nonzero_owner_324  1
    service_1_8_4  service_visit_def_1126  1
    service_1_8_4  free_load_conservation_1127  -5
    service_1_8_4  original_T_including_depot_unload_1131  600
    service_1_8_5  unique_nonzero_owner_325  1
    service_1_8_5  service_visit_def_1126  1
    service_1_8_5  free_load_conservation_1127  -4
    service_1_8_5  original_T_including_depot_unload_1131  480
    service_1_8_6  unique_nonzero_owner_326  1
    service_1_8_6  service_visit_def_1126  1
    service_1_8_6  free_load_conservation_1127  -3
    service_1_8_6  original_T_including_depot_unload_1131  360
    service_1_8_7  unique_nonzero_owner_327  1
    service_1_8_7  service_visit_def_1126  1
    service_1_8_7  free_load_conservation_1127  -2
    service_1_8_7  original_T_including_depot_unload_1131  240
    service_1_8_8  unique_nonzero_owner_328  1
    service_1_8_8  service_visit_def_1126  1
    service_1_8_8  free_load_conservation_1127  -1
    service_1_8_8  original_T_including_depot_unload_1131  120
    service_1_8_10  unique_nonzero_owner_329  1
    service_1_8_10  service_visit_def_1126  1
    service_1_8_10  free_load_conservation_1127  1
    service_1_8_11  unique_nonzero_owner_330  1
    service_1_8_11  service_visit_def_1126  1
    service_1_8_11  free_load_conservation_1127  2
    service_1_8_12  unique_nonzero_owner_331  1
    service_1_8_12  service_visit_def_1126  1
    service_1_8_12  free_load_conservation_1127  3
    service_2_8_0  unique_nonzero_owner_320  1
    service_2_8_0  service_visit_def_1444  1
    service_2_8_0  free_load_conservation_1445  -9
    service_2_8_0  original_T_including_depot_unload_1448  1080
    service_2_8_1  unique_nonzero_owner_321  1
    service_2_8_1  service_visit_def_1444  1
    service_2_8_1  free_load_conservation_1445  -8
    service_2_8_1  original_T_including_depot_unload_1448  960
    service_2_8_2  unique_nonzero_owner_322  1
    service_2_8_2  service_visit_def_1444  1
    service_2_8_2  free_load_conservation_1445  -7
    service_2_8_2  original_T_including_depot_unload_1448  840
    service_2_8_3  unique_nonzero_owner_323  1
    service_2_8_3  service_visit_def_1444  1
    service_2_8_3  free_load_conservation_1445  -6
    service_2_8_3  original_T_including_depot_unload_1448  720
    service_2_8_4  unique_nonzero_owner_324  1
    service_2_8_4  service_visit_def_1444  1
    service_2_8_4  free_load_conservation_1445  -5
    service_2_8_4  original_T_including_depot_unload_1448  600
    service_2_8_5  unique_nonzero_owner_325  1
    service_2_8_5  service_visit_def_1444  1
    service_2_8_5  free_load_conservation_1445  -4
    service_2_8_5  original_T_including_depot_unload_1448  480
    service_2_8_6  unique_nonzero_owner_326  1
    service_2_8_6  service_visit_def_1444  1
    service_2_8_6  free_load_conservation_1445  -3
    service_2_8_6  original_T_including_depot_unload_1448  360
    service_2_8_7  unique_nonzero_owner_327  1
    service_2_8_7  service_visit_def_1444  1
    service_2_8_7  free_load_conservation_1445  -2
    service_2_8_7  original_T_including_depot_unload_1448  240
    service_2_8_8  unique_nonzero_owner_328  1
    service_2_8_8  service_visit_def_1444  1
    service_2_8_8  free_load_conservation_1445  -1
    service_2_8_8  original_T_including_depot_unload_1448  120
    service_2_8_10  unique_nonzero_owner_329  1
    service_2_8_10  service_visit_def_1444  1
    service_2_8_10  free_load_conservation_1445  1
    service_2_8_11  unique_nonzero_owner_330  1
    service_2_8_11  service_visit_def_1444  1
    service_2_8_11  free_load_conservation_1445  2
    service_2_8_12  unique_nonzero_owner_331  1
    service_2_8_12  service_visit_def_1444  1
    service_2_8_12  free_load_conservation_1445  3
    MARKER    'MARKER'                 'INTEND'
    visit_0_1  out_degree_673  -1
    visit_0_1  in_degree_674  -1
    visit_0_1  order_active_lb_675  -1
    visit_0_1  order_active_ub_676  -13
    order_0_1  connected_order_arc_348  -1
    order_0_1  connected_order_arc_350  -1
    order_0_1  connected_order_arc_352  -1
    order_0_1  connected_order_arc_354  -1
    order_0_1  connected_order_arc_356  -1
    order_0_1  connected_order_arc_358  -1
    order_0_1  connected_order_arc_360  -1
    order_0_1  connected_order_arc_362  -1
    order_0_1  connected_order_arc_364  -1
    order_0_1  connected_order_arc_366  -1
    order_0_1  connected_order_arc_368  -1
    order_0_1  connected_order_arc_370  -1
    order_0_1  connected_order_arc_373  1
    order_0_1  connected_order_arc_398  1
    order_0_1  connected_order_arc_423  1
    order_0_1  connected_order_arc_448  1
    order_0_1  connected_order_arc_473  1
    order_0_1  connected_order_arc_498  1
    order_0_1  connected_order_arc_523  1
    order_0_1  connected_order_arc_548  1
    order_0_1  connected_order_arc_573  1
    order_0_1  connected_order_arc_598  1
    order_0_1  connected_order_arc_623  1
    order_0_1  connected_order_arc_648  1
    order_0_1  order_active_lb_675  1
    order_0_1  order_active_ub_676  1
    order_0_1  fixed_segment_relative_order_756  -1
    visit_0_2  out_degree_680  -1
    visit_0_2  in_degree_681  -1
    visit_0_2  order_active_lb_682  -1
    visit_0_2  order_active_ub_683  -13
    order_0_2  connected_order_arc_348  1
    order_0_2  connected_order_arc_373  -1
    order_0_2  connected_order_arc_375  -1
    order_0_2  connected_order_arc_377  -1
    order_0_2  connected_order_arc_379  -1
    order_0_2  connected_order_arc_381  -1
    order_0_2  connected_order_arc_383  -1
    order_0_2  connected_order_arc_385  -1
    order_0_2  connected_order_arc_387  -1
    order_0_2  connected_order_arc_389  -1
    order_0_2  connected_order_arc_391  -1
    order_0_2  connected_order_arc_393  -1
    order_0_2  connected_order_arc_395  -1
    order_0_2  connected_order_arc_400  1
    order_0_2  connected_order_arc_425  1
    order_0_2  connected_order_arc_450  1
    order_0_2  connected_order_arc_475  1
    order_0_2  connected_order_arc_500  1
    order_0_2  connected_order_arc_525  1
    order_0_2  connected_order_arc_550  1
    order_0_2  connected_order_arc_575  1
    order_0_2  connected_order_arc_600  1
    order_0_2  connected_order_arc_625  1
    order_0_2  connected_order_arc_650  1
    order_0_2  order_active_lb_682  1
    order_0_2  order_active_ub_683  1
    order_0_2  fixed_segment_relative_order_756  1
    order_0_2  fixed_segment_relative_order_757  -1
    visit_0_3  out_degree_687  -1
    visit_0_3  in_degree_688  -1
    visit_0_3  order_active_lb_689  -1
    visit_0_3  order_active_ub_690  -13
    order_0_3  connected_order_arc_350  1
    order_0_3  connected_order_arc_375  1
    order_0_3  connected_order_arc_398  -1
    order_0_3  connected_order_arc_400  -1
    order_0_3  connected_order_arc_402  -1
    order_0_3  connected_order_arc_404  -1
    order_0_3  connected_order_arc_406  -1
    order_0_3  connected_order_arc_408  -1
    order_0_3  connected_order_arc_410  -1
    order_0_3  connected_order_arc_412  -1
    order_0_3  connected_order_arc_414  -1
    order_0_3  connected_order_arc_416  -1
    order_0_3  connected_order_arc_418  -1
    order_0_3  connected_order_arc_420  -1
    order_0_3  connected_order_arc_427  1
    order_0_3  connected_order_arc_452  1
    order_0_3  connected_order_arc_477  1
    order_0_3  connected_order_arc_502  1
    order_0_3  connected_order_arc_527  1
    order_0_3  connected_order_arc_552  1
    order_0_3  connected_order_arc_577  1
    order_0_3  connected_order_arc_602  1
    order_0_3  connected_order_arc_627  1
    order_0_3  connected_order_arc_652  1
    order_0_3  order_active_lb_689  1
    order_0_3  order_active_ub_690  1
    order_0_3  fixed_segment_relative_order_757  1
    order_0_3  fixed_segment_relative_order_758  -1
    visit_0_4  out_degree_694  -1
    visit_0_4  in_degree_695  -1
    visit_0_4  order_active_lb_696  -1
    visit_0_4  order_active_ub_697  -13
    order_0_4  connected_order_arc_352  1
    order_0_4  connected_order_arc_377  1
    order_0_4  connected_order_arc_402  1
    order_0_4  connected_order_arc_423  -1
    order_0_4  connected_order_arc_425  -1
    order_0_4  connected_order_arc_427  -1
    order_0_4  connected_order_arc_429  -1
    order_0_4  connected_order_arc_431  -1
    order_0_4  connected_order_arc_433  -1
    order_0_4  connected_order_arc_435  -1
    order_0_4  connected_order_arc_437  -1
    order_0_4  connected_order_arc_439  -1
    order_0_4  connected_order_arc_441  -1
    order_0_4  connected_order_arc_443  -1
    order_0_4  connected_order_arc_445  -1
    order_0_4  connected_order_arc_454  1
    order_0_4  connected_order_arc_479  1
    order_0_4  connected_order_arc_504  1
    order_0_4  connected_order_arc_529  1
    order_0_4  connected_order_arc_554  1
    order_0_4  connected_order_arc_579  1
    order_0_4  connected_order_arc_604  1
    order_0_4  connected_order_arc_629  1
    order_0_4  connected_order_arc_654  1
    order_0_4  order_active_lb_696  1
    order_0_4  order_active_ub_697  1
    order_0_4  fixed_segment_relative_order_758  1
    order_0_4  fixed_segment_relative_order_759  -1
    visit_0_5  out_degree_701  -1
    visit_0_5  in_degree_702  -1
    visit_0_5  order_active_lb_703  -1
    visit_0_5  order_active_ub_704  -13
    order_0_5  connected_order_arc_354  1
    order_0_5  connected_order_arc_379  1
    order_0_5  connected_order_arc_404  1
    order_0_5  connected_order_arc_429  1
    order_0_5  connected_order_arc_448  -1
    order_0_5  connected_order_arc_450  -1
    order_0_5  connected_order_arc_452  -1
    order_0_5  connected_order_arc_454  -1
    order_0_5  connected_order_arc_456  -1
    order_0_5  connected_order_arc_458  -1
    order_0_5  connected_order_arc_460  -1
    order_0_5  connected_order_arc_462  -1
    order_0_5  connected_order_arc_464  -1
    order_0_5  connected_order_arc_466  -1
    order_0_5  connected_order_arc_468  -1
    order_0_5  connected_order_arc_470  -1
    order_0_5  connected_order_arc_481  1
    order_0_5  connected_order_arc_506  1
    order_0_5  connected_order_arc_531  1
    order_0_5  connected_order_arc_556  1
    order_0_5  connected_order_arc_581  1
    order_0_5  connected_order_arc_606  1
    order_0_5  connected_order_arc_631  1
    order_0_5  connected_order_arc_656  1
    order_0_5  order_active_lb_703  1
    order_0_5  order_active_ub_704  1
    order_0_5  fixed_segment_relative_order_759  1
    visit_0_13  out_degree_708  -1
    visit_0_13  in_degree_709  -1
    visit_0_13  order_active_lb_710  -1
    visit_0_13  order_active_ub_711  -13
    visit_0_13  service_visit_def_712  -1
    order_0_13  connected_order_arc_356  1
    order_0_13  connected_order_arc_381  1
    order_0_13  connected_order_arc_406  1
    order_0_13  connected_order_arc_431  1
    order_0_13  connected_order_arc_456  1
    order_0_13  connected_order_arc_473  -1
    order_0_13  connected_order_arc_475  -1
    order_0_13  connected_order_arc_477  -1
    order_0_13  connected_order_arc_479  -1
    order_0_13  connected_order_arc_481  -1
    order_0_13  connected_order_arc_483  -1
    order_0_13  connected_order_arc_485  -1
    order_0_13  connected_order_arc_487  -1
    order_0_13  connected_order_arc_489  -1
    order_0_13  connected_order_arc_491  -1
    order_0_13  connected_order_arc_493  -1
    order_0_13  connected_order_arc_495  -1
    order_0_13  connected_order_arc_508  1
    order_0_13  connected_order_arc_533  1
    order_0_13  connected_order_arc_558  1
    order_0_13  connected_order_arc_583  1
    order_0_13  connected_order_arc_608  1
    order_0_13  connected_order_arc_633  1
    order_0_13  connected_order_arc_658  1
    order_0_13  order_active_lb_710  1
    order_0_13  order_active_ub_711  1
    visit_0_14  out_degree_714  -1
    visit_0_14  in_degree_715  -1
    visit_0_14  order_active_lb_716  -1
    visit_0_14  order_active_ub_717  -13
    visit_0_14  service_visit_def_718  -1
    order_0_14  connected_order_arc_358  1
    order_0_14  connected_order_arc_383  1
    order_0_14  connected_order_arc_408  1
    order_0_14  connected_order_arc_433  1
    order_0_14  connected_order_arc_458  1
    order_0_14  connected_order_arc_483  1
    order_0_14  connected_order_arc_498  -1
    order_0_14  connected_order_arc_500  -1
    order_0_14  connected_order_arc_502  -1
    order_0_14  connected_order_arc_504  -1
    order_0_14  connected_order_arc_506  -1
    order_0_14  connected_order_arc_508  -1
    order_0_14  connected_order_arc_510  -1
    order_0_14  connected_order_arc_512  -1
    order_0_14  connected_order_arc_514  -1
    order_0_14  connected_order_arc_516  -1
    order_0_14  connected_order_arc_518  -1
    order_0_14  connected_order_arc_520  -1
    order_0_14  connected_order_arc_535  1
    order_0_14  connected_order_arc_560  1
    order_0_14  connected_order_arc_585  1
    order_0_14  connected_order_arc_610  1
    order_0_14  connected_order_arc_635  1
    order_0_14  connected_order_arc_660  1
    order_0_14  order_active_lb_716  1
    order_0_14  order_active_ub_717  1
    visit_0_15  out_degree_720  -1
    visit_0_15  in_degree_721  -1
    visit_0_15  order_active_lb_722  -1
    visit_0_15  order_active_ub_723  -13
    visit_0_15  service_visit_def_724  -1
    order_0_15  connected_order_arc_360  1
    order_0_15  connected_order_arc_385  1
    order_0_15  connected_order_arc_410  1
    order_0_15  connected_order_arc_435  1
    order_0_15  connected_order_arc_460  1
    order_0_15  connected_order_arc_485  1
    order_0_15  connected_order_arc_510  1
    order_0_15  connected_order_arc_523  -1
    order_0_15  connected_order_arc_525  -1
    order_0_15  connected_order_arc_527  -1
    order_0_15  connected_order_arc_529  -1
    order_0_15  connected_order_arc_531  -1
    order_0_15  connected_order_arc_533  -1
    order_0_15  connected_order_arc_535  -1
    order_0_15  connected_order_arc_537  -1
    order_0_15  connected_order_arc_539  -1
    order_0_15  connected_order_arc_541  -1
    order_0_15  connected_order_arc_543  -1
    order_0_15  connected_order_arc_545  -1
    order_0_15  connected_order_arc_562  1
    order_0_15  connected_order_arc_587  1
    order_0_15  connected_order_arc_612  1
    order_0_15  connected_order_arc_637  1
    order_0_15  connected_order_arc_662  1
    order_0_15  order_active_lb_722  1
    order_0_15  order_active_ub_723  1
    visit_0_16  out_degree_726  -1
    visit_0_16  in_degree_727  -1
    visit_0_16  order_active_lb_728  -1
    visit_0_16  order_active_ub_729  -13
    visit_0_16  service_visit_def_730  -1
    order_0_16  connected_order_arc_362  1
    order_0_16  connected_order_arc_387  1
    order_0_16  connected_order_arc_412  1
    order_0_16  connected_order_arc_437  1
    order_0_16  connected_order_arc_462  1
    order_0_16  connected_order_arc_487  1
    order_0_16  connected_order_arc_512  1
    order_0_16  connected_order_arc_537  1
    order_0_16  connected_order_arc_548  -1
    order_0_16  connected_order_arc_550  -1
    order_0_16  connected_order_arc_552  -1
    order_0_16  connected_order_arc_554  -1
    order_0_16  connected_order_arc_556  -1
    order_0_16  connected_order_arc_558  -1
    order_0_16  connected_order_arc_560  -1
    order_0_16  connected_order_arc_562  -1
    order_0_16  connected_order_arc_564  -1
    order_0_16  connected_order_arc_566  -1
    order_0_16  connected_order_arc_568  -1
    order_0_16  connected_order_arc_570  -1
    order_0_16  connected_order_arc_589  1
    order_0_16  connected_order_arc_614  1
    order_0_16  connected_order_arc_639  1
    order_0_16  connected_order_arc_664  1
    order_0_16  order_active_lb_728  1
    order_0_16  order_active_ub_729  1
    visit_0_17  out_degree_732  -1
    visit_0_17  in_degree_733  -1
    visit_0_17  order_active_lb_734  -1
    visit_0_17  order_active_ub_735  -13
    visit_0_17  service_visit_def_736  -1
    order_0_17  connected_order_arc_364  1
    order_0_17  connected_order_arc_389  1
    order_0_17  connected_order_arc_414  1
    order_0_17  connected_order_arc_439  1
    order_0_17  connected_order_arc_464  1
    order_0_17  connected_order_arc_489  1
    order_0_17  connected_order_arc_514  1
    order_0_17  connected_order_arc_539  1
    order_0_17  connected_order_arc_564  1
    order_0_17  connected_order_arc_573  -1
    order_0_17  connected_order_arc_575  -1
    order_0_17  connected_order_arc_577  -1
    order_0_17  connected_order_arc_579  -1
    order_0_17  connected_order_arc_581  -1
    order_0_17  connected_order_arc_583  -1
    order_0_17  connected_order_arc_585  -1
    order_0_17  connected_order_arc_587  -1
    order_0_17  connected_order_arc_589  -1
    order_0_17  connected_order_arc_591  -1
    order_0_17  connected_order_arc_593  -1
    order_0_17  connected_order_arc_595  -1
    order_0_17  connected_order_arc_616  1
    order_0_17  connected_order_arc_641  1
    order_0_17  connected_order_arc_666  1
    order_0_17  order_active_lb_734  1
    order_0_17  order_active_ub_735  1
    visit_0_18  out_degree_738  -1
    visit_0_18  in_degree_739  -1
    visit_0_18  order_active_lb_740  -1
    visit_0_18  order_active_ub_741  -13
    visit_0_18  service_visit_def_742  -1
    order_0_18  connected_order_arc_366  1
    order_0_18  connected_order_arc_391  1
    order_0_18  connected_order_arc_416  1
    order_0_18  connected_order_arc_441  1
    order_0_18  connected_order_arc_466  1
    order_0_18  connected_order_arc_491  1
    order_0_18  connected_order_arc_516  1
    order_0_18  connected_order_arc_541  1
    order_0_18  connected_order_arc_566  1
    order_0_18  connected_order_arc_591  1
    order_0_18  connected_order_arc_598  -1
    order_0_18  connected_order_arc_600  -1
    order_0_18  connected_order_arc_602  -1
    order_0_18  connected_order_arc_604  -1
    order_0_18  connected_order_arc_606  -1
    order_0_18  connected_order_arc_608  -1
    order_0_18  connected_order_arc_610  -1
    order_0_18  connected_order_arc_612  -1
    order_0_18  connected_order_arc_614  -1
    order_0_18  connected_order_arc_616  -1
    order_0_18  connected_order_arc_618  -1
    order_0_18  connected_order_arc_620  -1
    order_0_18  connected_order_arc_643  1
    order_0_18  connected_order_arc_668  1
    order_0_18  order_active_lb_740  1
    order_0_18  order_active_ub_741  1
    visit_0_19  out_degree_744  -1
    visit_0_19  in_degree_745  -1
    visit_0_19  order_active_lb_746  -1
    visit_0_19  order_active_ub_747  -13
    visit_0_19  service_visit_def_748  -1
    order_0_19  connected_order_arc_368  1
    order_0_19  connected_order_arc_393  1
    order_0_19  connected_order_arc_418  1
    order_0_19  connected_order_arc_443  1
    order_0_19  connected_order_arc_468  1
    order_0_19  connected_order_arc_493  1
    order_0_19  connected_order_arc_518  1
    order_0_19  connected_order_arc_543  1
    order_0_19  connected_order_arc_568  1
    order_0_19  connected_order_arc_593  1
    order_0_19  connected_order_arc_618  1
    order_0_19  connected_order_arc_623  -1
    order_0_19  connected_order_arc_625  -1
    order_0_19  connected_order_arc_627  -1
    order_0_19  connected_order_arc_629  -1
    order_0_19  connected_order_arc_631  -1
    order_0_19  connected_order_arc_633  -1
    order_0_19  connected_order_arc_635  -1
    order_0_19  connected_order_arc_637  -1
    order_0_19  connected_order_arc_639  -1
    order_0_19  connected_order_arc_641  -1
    order_0_19  connected_order_arc_643  -1
    order_0_19  connected_order_arc_645  -1
    order_0_19  connected_order_arc_670  1
    order_0_19  order_active_lb_746  1
    order_0_19  order_active_ub_747  1
    visit_0_20  out_degree_750  -1
    visit_0_20  in_degree_751  -1
    visit_0_20  order_active_lb_752  -1
    visit_0_20  order_active_ub_753  -13
    visit_0_20  service_visit_def_754  -1
    order_0_20  connected_order_arc_370  1
    order_0_20  connected_order_arc_395  1
    order_0_20  connected_order_arc_420  1
    order_0_20  connected_order_arc_445  1
    order_0_20  connected_order_arc_470  1
    order_0_20  connected_order_arc_495  1
    order_0_20  connected_order_arc_520  1
    order_0_20  connected_order_arc_545  1
    order_0_20  connected_order_arc_570  1
    order_0_20  connected_order_arc_595  1
    order_0_20  connected_order_arc_620  1
    order_0_20  connected_order_arc_645  1
    order_0_20  connected_order_arc_648  -1
    order_0_20  connected_order_arc_650  -1
    order_0_20  connected_order_arc_652  -1
    order_0_20  connected_order_arc_654  -1
    order_0_20  connected_order_arc_656  -1
    order_0_20  connected_order_arc_658  -1
    order_0_20  connected_order_arc_660  -1
    order_0_20  connected_order_arc_662  -1
    order_0_20  connected_order_arc_664  -1
    order_0_20  connected_order_arc_666  -1
    order_0_20  connected_order_arc_668  -1
    order_0_20  connected_order_arc_670  -1
    order_0_20  order_active_lb_752  1
    order_0_20  order_active_ub_753  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_0  arc_capacity_332  -20
    arc_0_0_0  depot_departure_or_bypass_671  1
    arc_0_0_0  depot_return_or_bypass_672  1
    MARKER    'MARKER'                 'INTEND'
    load_0_0_0  arc_capacity_332  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_1  arc_capacity_333  -20
    arc_0_0_1  depot_departure_or_bypass_671  1
    arc_0_0_1  in_degree_674  1
    arc_0_0_1  original_T_including_depot_unload_760  885.819758595088
    MARKER    'MARKER'                 'INTEND'
    load_0_0_1  arc_capacity_333  1
    load_0_0_1  segment_load_conservation_677  -1
    load_0_0_1  segment_prefix_lb_678  1
    load_0_0_1  segment_prefix_ub_679  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_2  arc_capacity_334  -20
    arc_0_0_2  depot_departure_or_bypass_671  1
    arc_0_0_2  in_degree_681  1
    arc_0_0_2  original_T_including_depot_unload_760  1.1055042743585939e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_2  arc_capacity_334  1
    load_0_0_2  segment_load_conservation_684  -1
    load_0_0_2  segment_prefix_lb_685  1
    load_0_0_2  segment_prefix_ub_686  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_3  arc_capacity_335  -20
    arc_0_0_3  depot_departure_or_bypass_671  1
    arc_0_0_3  in_degree_688  1
    arc_0_0_3  original_T_including_depot_unload_760  9.1137190274562636e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_3  arc_capacity_335  1
    load_0_0_3  segment_load_conservation_691  -1
    load_0_0_3  segment_prefix_lb_692  1
    load_0_0_3  segment_prefix_ub_693  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_4  arc_capacity_336  -20
    arc_0_0_4  depot_departure_or_bypass_671  1
    arc_0_0_4  in_degree_695  1
    arc_0_0_4  original_T_including_depot_unload_760  4.3364857643570593e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_4  arc_capacity_336  1
    load_0_0_4  segment_load_conservation_698  -1
    load_0_0_4  segment_prefix_lb_699  1
    load_0_0_4  segment_prefix_ub_700  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_5  arc_capacity_337  -20
    arc_0_0_5  depot_departure_or_bypass_671  1
    arc_0_0_5  in_degree_702  1
    arc_0_0_5  original_T_including_depot_unload_760  3.9307504957585564e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_5  arc_capacity_337  1
    load_0_0_5  segment_load_conservation_705  -1
    load_0_0_5  segment_prefix_lb_706  1
    load_0_0_5  segment_prefix_ub_707  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_13  arc_capacity_338  -20
    arc_0_0_13  depot_departure_or_bypass_671  1
    arc_0_0_13  in_degree_709  1
    arc_0_0_13  original_T_including_depot_unload_760  6.4256529461228865e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_13  arc_capacity_338  1
    load_0_0_13  free_load_conservation_713  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_14  arc_capacity_339  -20
    arc_0_0_14  depot_departure_or_bypass_671  1
    arc_0_0_14  in_degree_715  1
    arc_0_0_14  original_T_including_depot_unload_760  6.2851955830851955e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_14  arc_capacity_339  1
    load_0_0_14  free_load_conservation_719  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_15  arc_capacity_340  -20
    arc_0_0_15  depot_departure_or_bypass_671  1
    arc_0_0_15  in_degree_721  1
    arc_0_0_15  original_T_including_depot_unload_760  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_15  arc_capacity_340  1
    load_0_0_15  free_load_conservation_725  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_16  arc_capacity_341  -20
    arc_0_0_16  depot_departure_or_bypass_671  1
    arc_0_0_16  in_degree_727  1
    arc_0_0_16  original_T_including_depot_unload_760  6.2904707403788154e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_16  arc_capacity_341  1
    load_0_0_16  free_load_conservation_731  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_17  arc_capacity_342  -20
    arc_0_0_17  depot_departure_or_bypass_671  1
    arc_0_0_17  in_degree_733  1
    arc_0_0_17  original_T_including_depot_unload_760  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_17  arc_capacity_342  1
    load_0_0_17  free_load_conservation_737  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_18  arc_capacity_343  -20
    arc_0_0_18  depot_departure_or_bypass_671  1
    arc_0_0_18  in_degree_739  1
    arc_0_0_18  original_T_including_depot_unload_760  5.2273830510106120e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_18  arc_capacity_343  1
    load_0_0_18  free_load_conservation_743  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_19  arc_capacity_344  -20
    arc_0_0_19  depot_departure_or_bypass_671  1
    arc_0_0_19  in_degree_745  1
    arc_0_0_19  original_T_including_depot_unload_760  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_19  arc_capacity_344  1
    load_0_0_19  free_load_conservation_749  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_20  arc_capacity_345  -20
    arc_0_0_20  depot_departure_or_bypass_671  1
    arc_0_0_20  in_degree_751  1
    arc_0_0_20  original_T_including_depot_unload_760  7.8199183337763486e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_20  arc_capacity_345  1
    load_0_0_20  free_load_conservation_755  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_0  arc_capacity_346  -20
    arc_0_1_0  depot_return_or_bypass_672  1
    arc_0_1_0  out_degree_673  1
    arc_0_1_0  original_T_including_depot_unload_760  885.819758595088
    MARKER    'MARKER'                 'INTEND'
    load_0_1_0  arc_capacity_346  1
    load_0_1_0  segment_load_conservation_677  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_2  arc_capacity_347  -20
    arc_0_1_2  connected_order_arc_348  -14
    arc_0_1_2  out_degree_673  1
    arc_0_1_2  in_degree_681  1
    arc_0_1_2  original_T_including_depot_unload_760  2.1974044543706933e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_2  arc_capacity_347  1
    load_0_1_2  segment_load_conservation_677  1
    load_0_1_2  segment_load_conservation_684  -1
    load_0_1_2  segment_prefix_lb_685  1
    load_0_1_2  segment_prefix_ub_686  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_3  arc_capacity_349  -20
    arc_0_1_3  connected_order_arc_350  -14
    arc_0_1_3  out_degree_673  1
    arc_0_1_3  in_degree_688  1
    arc_0_1_3  original_T_including_depot_unload_760  2.1282400853806328e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_3  arc_capacity_349  1
    load_0_1_3  segment_load_conservation_677  1
    load_0_1_3  segment_load_conservation_691  -1
    load_0_1_3  segment_prefix_lb_692  1
    load_0_1_3  segment_prefix_ub_693  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_4  arc_capacity_351  -20
    arc_0_1_4  connected_order_arc_352  -14
    arc_0_1_4  out_degree_673  1
    arc_0_1_4  in_degree_695  1
    arc_0_1_4  original_T_including_depot_unload_760  5.5115772567966917e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_4  arc_capacity_351  1
    load_0_1_4  segment_load_conservation_677  1
    load_0_1_4  segment_load_conservation_698  -1
    load_0_1_4  segment_prefix_lb_699  1
    load_0_1_4  segment_prefix_ub_700  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_5  arc_capacity_353  -20
    arc_0_1_5  connected_order_arc_354  -14
    arc_0_1_5  out_degree_673  1
    arc_0_1_5  in_degree_702  1
    arc_0_1_5  original_T_including_depot_unload_760  7.4443363933856153e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_5  arc_capacity_353  1
    load_0_1_5  segment_load_conservation_677  1
    load_0_1_5  segment_load_conservation_705  -1
    load_0_1_5  segment_prefix_lb_706  1
    load_0_1_5  segment_prefix_ub_707  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_13  arc_capacity_355  -20
    arc_0_1_13  connected_order_arc_356  -14
    arc_0_1_13  out_degree_673  1
    arc_0_1_13  in_degree_709  1
    arc_0_1_13  original_T_including_depot_unload_760  2.6361257108552718e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_13  arc_capacity_355  1
    load_0_1_13  segment_load_conservation_677  1
    load_0_1_13  free_load_conservation_713  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_14  arc_capacity_357  -20
    arc_0_1_14  connected_order_arc_358  -14
    arc_0_1_14  out_degree_673  1
    arc_0_1_14  in_degree_715  1
    arc_0_1_14  original_T_including_depot_unload_760  2.6477572380586179e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_14  arc_capacity_357  1
    load_0_1_14  segment_load_conservation_677  1
    load_0_1_14  free_load_conservation_719  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_15  arc_capacity_359  -20
    arc_0_1_15  connected_order_arc_360  -14
    arc_0_1_15  out_degree_673  1
    arc_0_1_15  in_degree_721  1
    arc_0_1_15  original_T_including_depot_unload_760  2.3420148578372859e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_15  arc_capacity_359  1
    load_0_1_15  segment_load_conservation_677  1
    load_0_1_15  free_load_conservation_725  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_16  arc_capacity_361  -20
    arc_0_1_16  connected_order_arc_362  -14
    arc_0_1_16  out_degree_673  1
    arc_0_1_16  in_degree_727  1
    arc_0_1_16  original_T_including_depot_unload_760  2.6417860079316790e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_16  arc_capacity_361  1
    load_0_1_16  segment_load_conservation_677  1
    load_0_1_16  free_load_conservation_731  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_17  arc_capacity_363  -20
    arc_0_1_17  connected_order_arc_364  -14
    arc_0_1_17  out_degree_673  1
    arc_0_1_17  in_degree_733  1
    arc_0_1_17  original_T_including_depot_unload_760  1.8786452499301340e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_17  arc_capacity_363  1
    load_0_1_17  segment_load_conservation_677  1
    load_0_1_17  free_load_conservation_737  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_18  arc_capacity_365  -20
    arc_0_1_18  connected_order_arc_366  -14
    arc_0_1_18  out_degree_673  1
    arc_0_1_18  in_degree_739  1
    arc_0_1_18  original_T_including_depot_unload_760  3.9263280945415767e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_18  arc_capacity_365  1
    load_0_1_18  segment_load_conservation_677  1
    load_0_1_18  free_load_conservation_743  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_19  arc_capacity_367  -20
    arc_0_1_19  connected_order_arc_368  -14
    arc_0_1_19  out_degree_673  1
    arc_0_1_19  in_degree_745  1
    arc_0_1_19  original_T_including_depot_unload_760  1.7093216071319850e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_19  arc_capacity_367  1
    load_0_1_19  segment_load_conservation_677  1
    load_0_1_19  free_load_conservation_749  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_20  arc_capacity_369  -20
    arc_0_1_20  connected_order_arc_370  -14
    arc_0_1_20  out_degree_673  1
    arc_0_1_20  in_degree_751  1
    arc_0_1_20  original_T_including_depot_unload_760  1.1216289013953633e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_20  arc_capacity_369  1
    load_0_1_20  segment_load_conservation_677  1
    load_0_1_20  free_load_conservation_755  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_0  arc_capacity_371  -20
    arc_0_2_0  depot_return_or_bypass_672  1
    arc_0_2_0  out_degree_680  1
    arc_0_2_0  original_T_including_depot_unload_760  1163.36883938708
    MARKER    'MARKER'                 'INTEND'
    load_0_2_0  arc_capacity_371  1
    load_0_2_0  segment_load_conservation_684  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_1  arc_capacity_372  -20
    arc_0_2_1  connected_order_arc_373  -14
    arc_0_2_1  in_degree_674  1
    arc_0_2_1  out_degree_680  1
    arc_0_2_1  original_T_including_depot_unload_760  3.5284009487492966e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_1  arc_capacity_372  1
    load_0_2_1  segment_load_conservation_677  -1
    load_0_2_1  segment_prefix_lb_678  1
    load_0_2_1  segment_prefix_ub_679  1
    load_0_2_1  segment_load_conservation_684  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_3  arc_capacity_374  -20
    arc_0_2_3  connected_order_arc_375  -14
    arc_0_2_3  out_degree_680  1
    arc_0_2_3  in_degree_688  1
    arc_0_2_3  original_T_including_depot_unload_760  2.5289455774621715e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_3  arc_capacity_374  1
    load_0_2_3  segment_load_conservation_684  1
    load_0_2_3  segment_load_conservation_691  -1
    load_0_2_3  segment_prefix_lb_692  1
    load_0_2_3  segment_prefix_ub_693  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_4  arc_capacity_376  -20
    arc_0_2_4  connected_order_arc_377  -14
    arc_0_2_4  out_degree_680  1
    arc_0_2_4  in_degree_695  1
    arc_0_2_4  original_T_including_depot_unload_760  8.8827217910440470e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_4  arc_capacity_376  1
    load_0_2_4  segment_load_conservation_684  1
    load_0_2_4  segment_load_conservation_698  -1
    load_0_2_4  segment_prefix_lb_699  1
    load_0_2_4  segment_prefix_ub_700  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_5  arc_capacity_378  -20
    arc_0_2_5  connected_order_arc_379  -14
    arc_0_2_5  out_degree_680  1
    arc_0_2_5  in_degree_702  1
    arc_0_2_5  original_T_including_depot_unload_760  1.0846900527084329e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_5  arc_capacity_378  1
    load_0_2_5  segment_load_conservation_684  1
    load_0_2_5  segment_load_conservation_705  -1
    load_0_2_5  segment_prefix_lb_706  1
    load_0_2_5  segment_prefix_ub_707  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_13  arc_capacity_380  -20
    arc_0_2_13  connected_order_arc_381  -14
    arc_0_2_13  out_degree_680  1
    arc_0_2_13  in_degree_709  1
    arc_0_2_13  original_T_including_depot_unload_760  6.0146431446211739e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_13  arc_capacity_380  1
    load_0_2_13  segment_load_conservation_684  1
    load_0_2_13  free_load_conservation_713  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_14  arc_capacity_382  -20
    arc_0_2_14  connected_order_arc_383  -14
    arc_0_2_14  out_degree_680  1
    arc_0_2_14  in_degree_715  1
    arc_0_2_14  original_T_including_depot_unload_760  5.9232553492869590e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_14  arc_capacity_382  1
    load_0_2_14  segment_load_conservation_684  1
    load_0_2_14  free_load_conservation_719  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_15  arc_capacity_384  -20
    arc_0_2_15  connected_order_arc_385  -14
    arc_0_2_15  out_degree_680  1
    arc_0_2_15  in_degree_721  1
    arc_0_2_15  original_T_including_depot_unload_760  2.6729202257370252e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_15  arc_capacity_384  1
    load_0_2_15  segment_load_conservation_684  1
    load_0_2_15  free_load_conservation_725  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_16  arc_capacity_386  -20
    arc_0_2_16  connected_order_arc_387  -14
    arc_0_2_16  out_degree_680  1
    arc_0_2_16  in_degree_727  1
    arc_0_2_16  original_T_including_depot_unload_760  5.9170757102467792e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_16  arc_capacity_386  1
    load_0_2_16  segment_load_conservation_684  1
    load_0_2_16  free_load_conservation_731  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_17  arc_capacity_388  -20
    arc_0_2_17  connected_order_arc_389  -14
    arc_0_2_17  out_degree_680  1
    arc_0_2_17  in_degree_733  1
    arc_0_2_17  original_T_including_depot_unload_760  2.1132075050355038e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_17  arc_capacity_388  1
    load_0_2_17  segment_load_conservation_684  1
    load_0_2_17  free_load_conservation_737  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_18  arc_capacity_390  -20
    arc_0_2_18  connected_order_arc_391  -14
    arc_0_2_18  out_degree_680  1
    arc_0_2_18  in_degree_739  1
    arc_0_2_18  original_T_including_depot_unload_760  7.2368344003319692e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_18  arc_capacity_390  1
    load_0_2_18  segment_load_conservation_684  1
    load_0_2_18  free_load_conservation_743  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_19  arc_capacity_392  -20
    arc_0_2_19  connected_order_arc_393  -14
    arc_0_2_19  out_degree_680  1
    arc_0_2_19  in_degree_745  1
    arc_0_2_19  original_T_including_depot_unload_760  2.0359275139821484e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_19  arc_capacity_392  1
    load_0_2_19  segment_load_conservation_684  1
    load_0_2_19  free_load_conservation_749  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_20  arc_capacity_394  -20
    arc_0_2_20  connected_order_arc_395  -14
    arc_0_2_20  out_degree_680  1
    arc_0_2_20  in_degree_751  1
    arc_0_2_20  original_T_including_depot_unload_760  4.5764912346489922e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_20  arc_capacity_394  1
    load_0_2_20  segment_load_conservation_684  1
    load_0_2_20  free_load_conservation_755  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_0  arc_capacity_396  -20
    arc_0_3_0  depot_return_or_bypass_672  1
    arc_0_3_0  out_degree_687  1
    arc_0_3_0  original_T_including_depot_unload_760  8.9725048283911053e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_0  arc_capacity_396  1
    load_0_3_0  segment_load_conservation_691  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_1  arc_capacity_397  -20
    arc_0_3_1  connected_order_arc_398  -14
    arc_0_3_1  in_degree_674  1
    arc_0_3_1  out_degree_687  1
    arc_0_3_1  original_T_including_depot_unload_760  3.2756388134900334e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_1  arc_capacity_397  1
    load_0_3_1  segment_load_conservation_677  -1
    load_0_3_1  segment_prefix_lb_678  1
    load_0_3_1  segment_prefix_ub_679  1
    load_0_3_1  segment_load_conservation_691  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_2  arc_capacity_399  -20
    arc_0_3_2  connected_order_arc_400  -14
    arc_0_3_2  in_degree_681  1
    arc_0_3_2  out_degree_687  1
    arc_0_3_2  original_T_including_depot_unload_760  4.1659410744554447e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_2  arc_capacity_399  1
    load_0_3_2  segment_load_conservation_684  -1
    load_0_3_2  segment_prefix_lb_685  1
    load_0_3_2  segment_prefix_ub_686  1
    load_0_3_2  segment_load_conservation_691  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_4  arc_capacity_401  -20
    arc_0_3_4  connected_order_arc_402  -14
    arc_0_3_4  out_degree_687  1
    arc_0_3_4  in_degree_695  1
    arc_0_3_4  original_T_including_depot_unload_760  7.0663858580683063e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_4  arc_capacity_401  1
    load_0_3_4  segment_load_conservation_691  1
    load_0_3_4  segment_load_conservation_698  -1
    load_0_3_4  segment_prefix_lb_699  1
    load_0_3_4  segment_prefix_ub_700  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_5  arc_capacity_403  -20
    arc_0_3_5  connected_order_arc_404  -14
    arc_0_3_5  out_degree_687  1
    arc_0_3_5  in_degree_702  1
    arc_0_3_5  original_T_including_depot_unload_760  8.9891387855174980e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_5  arc_capacity_403  1
    load_0_3_5  segment_load_conservation_691  1
    load_0_3_5  segment_load_conservation_705  -1
    load_0_3_5  segment_prefix_lb_706  1
    load_0_3_5  segment_prefix_ub_707  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_13  arc_capacity_405  -20
    arc_0_3_13  connected_order_arc_406  -14
    arc_0_3_13  out_degree_687  1
    arc_0_3_13  in_degree_709  1
    arc_0_3_13  original_T_including_depot_unload_760  4.5635886855303721e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_13  arc_capacity_405  1
    load_0_3_13  segment_load_conservation_691  1
    load_0_3_13  free_load_conservation_713  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_14  arc_capacity_407  -20
    arc_0_3_14  connected_order_arc_408  -14
    arc_0_3_14  out_degree_687  1
    arc_0_3_14  in_degree_715  1
    arc_0_3_14  original_T_including_depot_unload_760  4.3127471875854752e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_14  arc_capacity_407  1
    load_0_3_14  segment_load_conservation_691  1
    load_0_3_14  free_load_conservation_719  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_15  arc_capacity_409  -20
    arc_0_3_15  connected_order_arc_410  -14
    arc_0_3_15  out_degree_687  1
    arc_0_3_15  in_degree_721  1
    arc_0_3_15  original_T_including_depot_unload_760  2.4438258071820178e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_15  arc_capacity_409  1
    load_0_3_15  segment_load_conservation_691  1
    load_0_3_15  free_load_conservation_725  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_16  arc_capacity_411  -20
    arc_0_3_16  connected_order_arc_412  -14
    arc_0_3_16  out_degree_687  1
    arc_0_3_16  in_degree_727  1
    arc_0_3_16  original_T_including_depot_unload_760  4.3076139952356033e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_16  arc_capacity_411  1
    load_0_3_16  segment_load_conservation_691  1
    load_0_3_16  free_load_conservation_731  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_17  arc_capacity_413  -20
    arc_0_3_17  connected_order_arc_414  -14
    arc_0_3_17  out_degree_687  1
    arc_0_3_17  in_degree_733  1
    arc_0_3_17  original_T_including_depot_unload_760  1.8150519376858174e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_17  arc_capacity_413  1
    load_0_3_17  segment_load_conservation_691  1
    load_0_3_17  free_load_conservation_737  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_18  arc_capacity_415  -20
    arc_0_3_18  connected_order_arc_416  -14
    arc_0_3_18  out_degree_687  1
    arc_0_3_18  in_degree_739  1
    arc_0_3_18  original_T_including_depot_unload_760  5.4635723875297333e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_18  arc_capacity_415  1
    load_0_3_18  segment_load_conservation_691  1
    load_0_3_18  free_load_conservation_743  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_19  arc_capacity_417  -20
    arc_0_3_19  connected_order_arc_418  -14
    arc_0_3_19  out_degree_687  1
    arc_0_3_19  in_degree_745  1
    arc_0_3_19  original_T_including_depot_unload_760  1804.59863156495
    MARKER    'MARKER'                 'INTEND'
    load_0_3_19  arc_capacity_417  1
    load_0_3_19  segment_load_conservation_691  1
    load_0_3_19  free_load_conservation_749  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_20  arc_capacity_419  -20
    arc_0_3_20  connected_order_arc_420  -14
    arc_0_3_20  out_degree_687  1
    arc_0_3_20  in_degree_751  1
    arc_0_3_20  original_T_including_depot_unload_760  3.6797474390734163e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_20  arc_capacity_419  1
    load_0_3_20  segment_load_conservation_691  1
    load_0_3_20  free_load_conservation_755  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_0  arc_capacity_421  -20
    arc_0_4_0  depot_return_or_bypass_672  1
    arc_0_4_0  out_degree_694  1
    arc_0_4_0  original_T_including_depot_unload_760  4.3364857643570593e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_0  arc_capacity_421  1
    load_0_4_0  segment_load_conservation_698  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_1  arc_capacity_422  -20
    arc_0_4_1  connected_order_arc_423  -14
    arc_0_4_1  in_degree_674  1
    arc_0_4_1  out_degree_694  1
    arc_0_4_1  original_T_including_depot_unload_760  5.5115772567966917e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_1  arc_capacity_422  1
    load_0_4_1  segment_load_conservation_677  -1
    load_0_4_1  segment_prefix_lb_678  1
    load_0_4_1  segment_prefix_ub_679  1
    load_0_4_1  segment_load_conservation_698  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_2  arc_capacity_424  -20
    arc_0_4_2  connected_order_arc_425  -14
    arc_0_4_2  in_degree_681  1
    arc_0_4_2  out_degree_694  1
    arc_0_4_2  original_T_including_depot_unload_760  7.6007185336497685e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_2  arc_capacity_424  1
    load_0_4_2  segment_load_conservation_684  -1
    load_0_4_2  segment_prefix_lb_685  1
    load_0_4_2  segment_prefix_ub_686  1
    load_0_4_2  segment_load_conservation_698  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_3  arc_capacity_426  -20
    arc_0_4_3  connected_order_arc_427  -14
    arc_0_4_3  in_degree_688  1
    arc_0_4_3  out_degree_694  1
    arc_0_4_3  original_T_including_depot_unload_760  6.6347574074434863e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_3  arc_capacity_426  1
    load_0_4_3  segment_load_conservation_691  -1
    load_0_4_3  segment_prefix_lb_692  1
    load_0_4_3  segment_prefix_ub_693  1
    load_0_4_3  segment_load_conservation_698  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_5  arc_capacity_428  -20
    arc_0_4_5  connected_order_arc_429  -14
    arc_0_4_5  out_degree_694  1
    arc_0_4_5  in_degree_702  1
    arc_0_4_5  original_T_including_depot_unload_760  1.9684882536425036e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_5  arc_capacity_428  1
    load_0_4_5  segment_load_conservation_698  1
    load_0_4_5  segment_load_conservation_705  -1
    load_0_4_5  segment_prefix_lb_706  1
    load_0_4_5  segment_prefix_ub_707  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_13  arc_capacity_430  -20
    arc_0_4_13  connected_order_arc_431  -14
    arc_0_4_13  out_degree_694  1
    arc_0_4_13  in_degree_709  1
    arc_0_4_13  original_T_including_depot_unload_760  2.8856753867620006e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_13  arc_capacity_430  1
    load_0_4_13  segment_load_conservation_698  1
    load_0_4_13  free_load_conservation_713  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_14  arc_capacity_432  -20
    arc_0_4_14  connected_order_arc_433  -14
    arc_0_4_14  out_degree_694  1
    arc_0_4_14  in_degree_715  1
    arc_0_4_14  original_T_including_depot_unload_760  2.9611166330127878e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_14  arc_capacity_432  1
    load_0_4_14  segment_load_conservation_698  1
    load_0_4_14  free_load_conservation_719  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_15  arc_capacity_434  -20
    arc_0_4_15  connected_order_arc_435  -14
    arc_0_4_15  out_degree_694  1
    arc_0_4_15  in_degree_721  1
    arc_0_4_15  original_T_including_depot_unload_760  1.7908610301589636e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_15  arc_capacity_434  1
    load_0_4_15  segment_load_conservation_698  1
    load_0_4_15  free_load_conservation_725  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_16  arc_capacity_436  -20
    arc_0_4_16  connected_order_arc_437  -14
    arc_0_4_16  out_degree_694  1
    arc_0_4_16  in_degree_727  1
    arc_0_4_16  original_T_including_depot_unload_760  2.9672747884555446e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_16  arc_capacity_436  1
    load_0_4_16  segment_load_conservation_698  1
    load_0_4_16  free_load_conservation_731  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_17  arc_capacity_438  -20
    arc_0_4_17  connected_order_arc_439  -14
    arc_0_4_17  out_degree_694  1
    arc_0_4_17  in_degree_733  1
    arc_0_4_17  original_T_including_depot_unload_760  1.4300244315666421e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_17  arc_capacity_438  1
    load_0_4_17  segment_load_conservation_698  1
    load_0_4_17  free_load_conservation_737  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_18  arc_capacity_440  -20
    arc_0_4_18  connected_order_arc_441  -14
    arc_0_4_18  out_degree_694  1
    arc_0_4_18  in_degree_739  1
    arc_0_4_18  original_T_including_depot_unload_760  1.6552401015053141e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_18  arc_capacity_440  1
    load_0_4_18  segment_load_conservation_698  1
    load_0_4_18  free_load_conservation_743  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_19  arc_capacity_442  -20
    arc_0_4_19  connected_order_arc_443  -14
    arc_0_4_19  out_degree_694  1
    arc_0_4_19  in_degree_745  1
    arc_0_4_19  original_T_including_depot_unload_760  1.1588937665971753e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_19  arc_capacity_442  1
    load_0_4_19  segment_load_conservation_698  1
    load_0_4_19  free_load_conservation_749  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_20  arc_capacity_444  -20
    arc_0_4_20  connected_order_arc_445  -14
    arc_0_4_20  out_degree_694  1
    arc_0_4_20  in_degree_751  1
    arc_0_4_20  original_T_including_depot_unload_760  4.3907641772187384e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_20  arc_capacity_444  1
    load_0_4_20  segment_load_conservation_698  1
    load_0_4_20  free_load_conservation_755  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_0  arc_capacity_446  -20
    arc_0_5_0  depot_return_or_bypass_672  1
    arc_0_5_0  out_degree_701  1
    arc_0_5_0  original_T_including_depot_unload_760  3.8060477410436619e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_0  arc_capacity_446  1
    load_0_5_0  segment_load_conservation_705  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_1  arc_capacity_447  -20
    arc_0_5_1  connected_order_arc_448  -14
    arc_0_5_1  in_degree_674  1
    arc_0_5_1  out_degree_701  1
    arc_0_5_1  original_T_including_depot_unload_760  1035.83277530205
    MARKER    'MARKER'                 'INTEND'
    load_0_5_1  arc_capacity_447  1
    load_0_5_1  segment_load_conservation_677  -1
    load_0_5_1  segment_prefix_lb_678  1
    load_0_5_1  segment_prefix_ub_679  1
    load_0_5_1  segment_load_conservation_705  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_2  arc_capacity_449  -20
    arc_0_5_2  connected_order_arc_450  -14
    arc_0_5_2  in_degree_681  1
    arc_0_5_2  out_degree_701  1
    arc_0_5_2  original_T_including_depot_unload_760  1.2450286067313011e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_2  arc_capacity_449  1
    load_0_5_2  segment_load_conservation_684  -1
    load_0_5_2  segment_prefix_lb_685  1
    load_0_5_2  segment_prefix_ub_686  1
    load_0_5_2  segment_load_conservation_705  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_3  arc_capacity_451  -20
    arc_0_5_3  connected_order_arc_452  -14
    arc_0_5_3  in_degree_688  1
    arc_0_5_3  out_degree_701  1
    arc_0_5_3  original_T_including_depot_unload_760  1.1301442107738828e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_3  arc_capacity_451  1
    load_0_5_3  segment_load_conservation_691  -1
    load_0_5_3  segment_prefix_lb_692  1
    load_0_5_3  segment_prefix_ub_693  1
    load_0_5_3  segment_load_conservation_705  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_4  arc_capacity_453  -20
    arc_0_5_4  connected_order_arc_454  -14
    arc_0_5_4  in_degree_695  1
    arc_0_5_4  out_degree_701  1
    arc_0_5_4  original_T_including_depot_unload_760  4.8520683722319296e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_4  arc_capacity_453  1
    load_0_5_4  segment_load_conservation_698  -1
    load_0_5_4  segment_prefix_lb_699  1
    load_0_5_4  segment_prefix_ub_700  1
    load_0_5_4  segment_load_conservation_705  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_13  arc_capacity_455  -20
    arc_0_5_13  connected_order_arc_456  -14
    arc_0_5_13  out_degree_701  1
    arc_0_5_13  in_degree_709  1
    arc_0_5_13  original_T_including_depot_unload_760  7.7242003812192672e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_13  arc_capacity_455  1
    load_0_5_13  segment_load_conservation_705  1
    load_0_5_13  free_load_conservation_713  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_14  arc_capacity_457  -20
    arc_0_5_14  connected_order_arc_458  -14
    arc_0_5_14  out_degree_701  1
    arc_0_5_14  in_degree_715  1
    arc_0_5_14  original_T_including_depot_unload_760  7.7600923635341769e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_14  arc_capacity_457  1
    load_0_5_14  segment_load_conservation_705  1
    load_0_5_14  free_load_conservation_719  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_15  arc_capacity_459  -20
    arc_0_5_15  connected_order_arc_460  -14
    arc_0_5_15  out_degree_701  1
    arc_0_5_15  in_degree_721  1
    arc_0_5_15  original_T_including_depot_unload_760  1.3072142379397485e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_15  arc_capacity_459  1
    load_0_5_15  segment_load_conservation_705  1
    load_0_5_15  free_load_conservation_725  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_16  arc_capacity_461  -20
    arc_0_5_16  connected_order_arc_462  -14
    arc_0_5_16  out_degree_701  1
    arc_0_5_16  in_degree_727  1
    arc_0_5_16  original_T_including_depot_unload_760  7.7662791174533720e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_16  arc_capacity_461  1
    load_0_5_16  segment_load_conservation_705  1
    load_0_5_16  free_load_conservation_731  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_17  arc_capacity_463  -20
    arc_0_5_17  connected_order_arc_464  -14
    arc_0_5_17  out_degree_701  1
    arc_0_5_17  in_degree_733  1
    arc_0_5_17  original_T_including_depot_unload_760  1.0882276141652012e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_17  arc_capacity_463  1
    load_0_5_17  segment_load_conservation_705  1
    load_0_5_17  free_load_conservation_737  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_18  arc_capacity_465  -20
    arc_0_5_18  connected_order_arc_466  -14
    arc_0_5_18  out_degree_701  1
    arc_0_5_18  in_degree_739  1
    arc_0_5_18  original_T_including_depot_unload_760  6.4485258452666415e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_18  arc_capacity_465  1
    load_0_5_18  segment_load_conservation_705  1
    load_0_5_18  free_load_conservation_743  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_19  arc_capacity_467  -20
    arc_0_5_19  connected_order_arc_468  -14
    arc_0_5_19  out_degree_701  1
    arc_0_5_19  in_degree_745  1
    arc_0_5_19  original_T_including_depot_unload_760  6.7368811350376711e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_19  arc_capacity_467  1
    load_0_5_19  segment_load_conservation_705  1
    load_0_5_19  free_load_conservation_749  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_20  arc_capacity_469  -20
    arc_0_5_20  connected_order_arc_470  -14
    arc_0_5_20  out_degree_701  1
    arc_0_5_20  in_degree_751  1
    arc_0_5_20  original_T_including_depot_unload_760  9.2367088355230590e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_20  arc_capacity_469  1
    load_0_5_20  segment_load_conservation_705  1
    load_0_5_20  free_load_conservation_755  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_0  arc_capacity_471  -20
    arc_0_13_0  depot_return_or_bypass_672  1
    arc_0_13_0  out_degree_708  1
    arc_0_13_0  original_T_including_depot_unload_760  6.4256529461228865e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_0  arc_capacity_471  1
    load_0_13_0  free_load_conservation_713  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_1  arc_capacity_472  -20
    arc_0_13_1  connected_order_arc_473  -14
    arc_0_13_1  in_degree_674  1
    arc_0_13_1  out_degree_708  1
    arc_0_13_1  original_T_including_depot_unload_760  2.6361257108552718e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_1  arc_capacity_472  1
    load_0_13_1  segment_load_conservation_677  -1
    load_0_13_1  segment_prefix_lb_678  1
    load_0_13_1  segment_prefix_ub_679  1
    load_0_13_1  free_load_conservation_713  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_2  arc_capacity_474  -20
    arc_0_13_2  connected_order_arc_475  -14
    arc_0_13_2  in_degree_681  1
    arc_0_13_2  out_degree_708  1
    arc_0_13_2  original_T_including_depot_unload_760  477.665399637945
    MARKER    'MARKER'                 'INTEND'
    load_0_13_2  arc_capacity_474  1
    load_0_13_2  segment_load_conservation_684  -1
    load_0_13_2  segment_prefix_lb_685  1
    load_0_13_2  segment_prefix_ub_686  1
    load_0_13_2  free_load_conservation_713  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_3  arc_capacity_476  -20
    arc_0_13_3  connected_order_arc_477  -14
    arc_0_13_3  in_degree_688  1
    arc_0_13_3  out_degree_708  1
    arc_0_13_3  original_T_including_depot_unload_760  3.8949255894881873e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_3  arc_capacity_476  1
    load_0_13_3  segment_load_conservation_691  -1
    load_0_13_3  segment_prefix_lb_692  1
    load_0_13_3  segment_prefix_ub_693  1
    load_0_13_3  free_load_conservation_713  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_4  arc_capacity_478  -20
    arc_0_13_4  connected_order_arc_479  -14
    arc_0_13_4  in_degree_695  1
    arc_0_13_4  out_degree_708  1
    arc_0_13_4  original_T_including_depot_unload_760  2.8856753867620006e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_4  arc_capacity_478  1
    load_0_13_4  segment_load_conservation_698  -1
    load_0_13_4  segment_prefix_lb_699  1
    load_0_13_4  segment_prefix_ub_700  1
    load_0_13_4  free_load_conservation_713  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_5  arc_capacity_480  -20
    arc_0_13_5  connected_order_arc_481  -14
    arc_0_13_5  in_degree_702  1
    arc_0_13_5  out_degree_708  1
    arc_0_13_5  original_T_including_depot_unload_760  4.8384395388802926e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_5  arc_capacity_480  1
    load_0_13_5  segment_load_conservation_705  -1
    load_0_13_5  segment_prefix_lb_706  1
    load_0_13_5  segment_prefix_ub_707  1
    load_0_13_5  free_load_conservation_713  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_14  arc_capacity_482  -20
    arc_0_13_14  connected_order_arc_483  -14
    arc_0_13_14  out_degree_708  1
    arc_0_13_14  in_degree_715  1
    arc_0_13_14  original_T_including_depot_unload_760  3.5317482243205085e+01
    MARKER    'MARKER'                 'INTEND'
    load_0_13_14  arc_capacity_482  1
    load_0_13_14  free_load_conservation_713  1
    load_0_13_14  free_load_conservation_719  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_15  arc_capacity_484  -20
    arc_0_13_15  connected_order_arc_485  -14
    arc_0_13_15  out_degree_708  1
    arc_0_13_15  in_degree_721  1
    arc_0_13_15  original_T_including_depot_unload_760  2.0790680627934375e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_15  arc_capacity_484  1
    load_0_13_15  free_load_conservation_713  1
    load_0_13_15  free_load_conservation_725  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_16  arc_capacity_486  -20
    arc_0_13_16  connected_order_arc_487  -14
    arc_0_13_16  out_degree_708  1
    arc_0_13_16  in_degree_727  1
    arc_0_13_16  original_T_including_depot_unload_760  3.5426413058949414e+01
    MARKER    'MARKER'                 'INTEND'
    load_0_13_16  arc_capacity_486  1
    load_0_13_16  free_load_conservation_713  1
    load_0_13_16  free_load_conservation_731  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_17  arc_capacity_488  -20
    arc_0_13_17  connected_order_arc_489  -14
    arc_0_13_17  out_degree_708  1
    arc_0_13_17  in_degree_733  1
    arc_0_13_17  original_T_including_depot_unload_760  1.6472719129023171e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_17  arc_capacity_488  1
    load_0_13_17  free_load_conservation_713  1
    load_0_13_17  free_load_conservation_737  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_18  arc_capacity_490  -20
    arc_0_13_18  connected_order_arc_491  -14
    arc_0_13_18  out_degree_708  1
    arc_0_13_18  in_degree_739  1
    arc_0_13_18  original_T_including_depot_unload_760  1.2962070286822930e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_18  arc_capacity_490  1
    load_0_13_18  free_load_conservation_713  1
    load_0_13_18  free_load_conservation_743  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_19  arc_capacity_492  -20
    arc_0_13_19  connected_order_arc_493  -14
    arc_0_13_19  out_degree_708  1
    arc_0_13_19  in_degree_745  1
    arc_0_13_19  original_T_including_depot_unload_760  1.4457797980495495e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_19  arc_capacity_492  1
    load_0_13_19  free_load_conservation_713  1
    load_0_13_19  free_load_conservation_749  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_20  arc_capacity_494  -20
    arc_0_13_20  connected_order_arc_495  -14
    arc_0_13_20  out_degree_708  1
    arc_0_13_20  in_degree_751  1
    arc_0_13_20  original_T_including_depot_unload_760  1.5153540246292351e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_20  arc_capacity_494  1
    load_0_13_20  free_load_conservation_713  1
    load_0_13_20  free_load_conservation_755  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_0  arc_capacity_496  -20
    arc_0_14_0  depot_return_or_bypass_672  1
    arc_0_14_0  out_degree_714  1
    arc_0_14_0  original_T_including_depot_unload_760  6.2851955830851955e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_0  arc_capacity_496  1
    load_0_14_0  free_load_conservation_719  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_1  arc_capacity_497  -20
    arc_0_14_1  connected_order_arc_498  -14
    arc_0_14_1  in_degree_674  1
    arc_0_14_1  out_degree_714  1
    arc_0_14_1  original_T_including_depot_unload_760  2.6477572380586179e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_1  arc_capacity_497  1
    load_0_14_1  segment_load_conservation_677  -1
    load_0_14_1  segment_prefix_lb_678  1
    load_0_14_1  segment_prefix_ub_679  1
    load_0_14_1  free_load_conservation_719  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_2  arc_capacity_499  -20
    arc_0_14_2  connected_order_arc_500  -14
    arc_0_14_2  in_degree_681  1
    arc_0_14_2  out_degree_714  1
    arc_0_14_2  original_T_including_depot_unload_760  4.8268503899521744e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_2  arc_capacity_499  1
    load_0_14_2  segment_load_conservation_684  -1
    load_0_14_2  segment_prefix_lb_685  1
    load_0_14_2  segment_prefix_ub_686  1
    load_0_14_2  free_load_conservation_719  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_3  arc_capacity_501  -20
    arc_0_14_3  connected_order_arc_502  -14
    arc_0_14_3  in_degree_688  1
    arc_0_14_3  out_degree_714  1
    arc_0_14_3  original_T_including_depot_unload_760  3.7143421209022068e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_3  arc_capacity_501  1
    load_0_14_3  segment_load_conservation_691  -1
    load_0_14_3  segment_prefix_lb_692  1
    load_0_14_3  segment_prefix_ub_693  1
    load_0_14_3  free_load_conservation_719  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_4  arc_capacity_503  -20
    arc_0_14_4  connected_order_arc_504  -14
    arc_0_14_4  in_degree_695  1
    arc_0_14_4  out_degree_714  1
    arc_0_14_4  original_T_including_depot_unload_760  2.9611166330127878e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_4  arc_capacity_503  1
    load_0_14_4  segment_load_conservation_698  -1
    load_0_14_4  segment_prefix_lb_699  1
    load_0_14_4  segment_prefix_ub_700  1
    load_0_14_4  free_load_conservation_719  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_5  arc_capacity_505  -20
    arc_0_14_5  connected_order_arc_506  -14
    arc_0_14_5  in_degree_702  1
    arc_0_14_5  out_degree_714  1
    arc_0_14_5  original_T_including_depot_unload_760  4.9283602644772810e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_5  arc_capacity_505  1
    load_0_14_5  segment_load_conservation_705  -1
    load_0_14_5  segment_prefix_lb_706  1
    load_0_14_5  segment_prefix_ub_707  1
    load_0_14_5  free_load_conservation_719  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_13  arc_capacity_507  -20
    arc_0_14_13  connected_order_arc_508  -14
    arc_0_14_13  in_degree_709  1
    arc_0_14_13  out_degree_714  1
    arc_0_14_13  original_T_including_depot_unload_760  3.5317482243205085e+01
    MARKER    'MARKER'                 'INTEND'
    load_0_14_13  arc_capacity_507  1
    load_0_14_13  free_load_conservation_713  -1
    load_0_14_13  free_load_conservation_719  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_15  arc_capacity_509  -20
    arc_0_14_15  connected_order_arc_510  -14
    arc_0_14_15  out_degree_714  1
    arc_0_14_15  in_degree_721  1
    arc_0_14_15  original_T_including_depot_unload_760  2.0832214111784192e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_15  arc_capacity_509  1
    load_0_14_15  free_load_conservation_719  1
    load_0_14_15  free_load_conservation_725  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_16  arc_capacity_511  -20
    arc_0_14_16  connected_order_arc_512  -14
    arc_0_14_16  out_degree_714  1
    arc_0_14_16  in_degree_727  1
    arc_0_14_16  original_T_including_depot_unload_760  6.1926694994249909e-01
    MARKER    'MARKER'                 'INTEND'
    load_0_14_16  arc_capacity_511  1
    load_0_14_16  free_load_conservation_719  1
    load_0_14_16  free_load_conservation_731  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_17  arc_capacity_513  -20
    arc_0_14_17  connected_order_arc_514  -14
    arc_0_14_17  out_degree_714  1
    arc_0_14_17  in_degree_733  1
    arc_0_14_17  original_T_including_depot_unload_760  1.6305450534190286e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_17  arc_capacity_513  1
    load_0_14_17  free_load_conservation_719  1
    load_0_14_17  free_load_conservation_737  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_18  arc_capacity_515  -20
    arc_0_14_18  connected_order_arc_516  -14
    arc_0_14_18  out_degree_714  1
    arc_0_14_18  in_degree_739  1
    arc_0_14_18  original_T_including_depot_unload_760  1.3146996282072985e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_18  arc_capacity_515  1
    load_0_14_18  free_load_conservation_719  1
    load_0_14_18  free_load_conservation_743  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_19  arc_capacity_517  -20
    arc_0_14_19  connected_order_arc_518  -14
    arc_0_14_19  out_degree_714  1
    arc_0_14_19  in_degree_745  1
    arc_0_14_19  original_T_including_depot_unload_760  1.4482979064849126e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_19  arc_capacity_517  1
    load_0_14_19  free_load_conservation_719  1
    load_0_14_19  free_load_conservation_749  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_20  arc_capacity_519  -20
    arc_0_14_20  connected_order_arc_520  -14
    arc_0_14_20  out_degree_714  1
    arc_0_14_20  in_degree_751  1
    arc_0_14_20  original_T_including_depot_unload_760  1.5518157315724611e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_20  arc_capacity_519  1
    load_0_14_20  free_load_conservation_719  1
    load_0_14_20  free_load_conservation_755  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_0  arc_capacity_521  -20
    arc_0_15_0  depot_return_or_bypass_672  1
    arc_0_15_0  out_degree_720  1
    arc_0_15_0  original_T_including_depot_unload_760  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_0  arc_capacity_521  1
    load_0_15_0  free_load_conservation_725  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_1  arc_capacity_522  -20
    arc_0_15_1  connected_order_arc_523  -14
    arc_0_15_1  in_degree_674  1
    arc_0_15_1  out_degree_720  1
    arc_0_15_1  original_T_including_depot_unload_760  2.3420148578372859e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_1  arc_capacity_522  1
    load_0_15_1  segment_load_conservation_677  -1
    load_0_15_1  segment_prefix_lb_678  1
    load_0_15_1  segment_prefix_ub_679  1
    load_0_15_1  free_load_conservation_725  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_2  arc_capacity_524  -20
    arc_0_15_2  connected_order_arc_525  -14
    arc_0_15_2  in_degree_681  1
    arc_0_15_2  out_degree_720  1
    arc_0_15_2  original_T_including_depot_unload_760  2.5477291514674703e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_2  arc_capacity_524  1
    load_0_15_2  segment_load_conservation_684  -1
    load_0_15_2  segment_prefix_lb_685  1
    load_0_15_2  segment_prefix_ub_686  1
    load_0_15_2  free_load_conservation_725  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_3  arc_capacity_526  -20
    arc_0_15_3  connected_order_arc_527  -14
    arc_0_15_3  in_degree_688  1
    arc_0_15_3  out_degree_720  1
    arc_0_15_3  original_T_including_depot_unload_760  2.4332256311874226e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_3  arc_capacity_526  1
    load_0_15_3  segment_load_conservation_691  -1
    load_0_15_3  segment_prefix_lb_692  1
    load_0_15_3  segment_prefix_ub_693  1
    load_0_15_3  free_load_conservation_725  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_4  arc_capacity_528  -20
    arc_0_15_4  connected_order_arc_529  -14
    arc_0_15_4  in_degree_695  1
    arc_0_15_4  out_degree_720  1
    arc_0_15_4  original_T_including_depot_unload_760  1.7908610301589636e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_4  arc_capacity_528  1
    load_0_15_4  segment_load_conservation_698  -1
    load_0_15_4  segment_prefix_lb_699  1
    load_0_15_4  segment_prefix_ub_700  1
    load_0_15_4  free_load_conservation_725  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_5  arc_capacity_530  -20
    arc_0_15_5  connected_order_arc_531  -14
    arc_0_15_5  in_degree_702  1
    arc_0_15_5  out_degree_720  1
    arc_0_15_5  original_T_including_depot_unload_760  1.5992308845216928e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_5  arc_capacity_530  1
    load_0_15_5  segment_load_conservation_705  -1
    load_0_15_5  segment_prefix_lb_706  1
    load_0_15_5  segment_prefix_ub_707  1
    load_0_15_5  free_load_conservation_725  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_13  arc_capacity_532  -20
    arc_0_15_13  connected_order_arc_533  -14
    arc_0_15_13  in_degree_709  1
    arc_0_15_13  out_degree_720  1
    arc_0_15_13  original_T_including_depot_unload_760  2.0790680627934375e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_13  arc_capacity_532  1
    load_0_15_13  free_load_conservation_713  -1
    load_0_15_13  free_load_conservation_725  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_14  arc_capacity_534  -20
    arc_0_15_14  connected_order_arc_535  -14
    arc_0_15_14  in_degree_715  1
    arc_0_15_14  out_degree_720  1
    arc_0_15_14  original_T_including_depot_unload_760  2.0832214111784192e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_14  arc_capacity_534  1
    load_0_15_14  free_load_conservation_719  -1
    load_0_15_14  free_load_conservation_725  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_16  arc_capacity_536  -20
    arc_0_15_16  connected_order_arc_537  -14
    arc_0_15_16  out_degree_720  1
    arc_0_15_16  in_degree_727  1
    arc_0_15_16  original_T_including_depot_unload_760  2.0838401346783280e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_16  arc_capacity_536  1
    load_0_15_16  free_load_conservation_725  1
    load_0_15_16  free_load_conservation_731  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_17  arc_capacity_538  -20
    arc_0_15_17  connected_order_arc_539  -14
    arc_0_15_17  out_degree_720  1
    arc_0_15_17  in_degree_733  1
    arc_0_15_17  original_T_including_depot_unload_760  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_17  arc_capacity_538  1
    load_0_15_17  free_load_conservation_725  1
    load_0_15_17  free_load_conservation_737  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_18  arc_capacity_540  -20
    arc_0_15_18  connected_order_arc_541  -14
    arc_0_15_18  out_degree_720  1
    arc_0_15_18  in_degree_739  1
    arc_0_15_18  original_T_including_depot_unload_760  1.9520133700471852e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_18  arc_capacity_540  1
    load_0_15_18  free_load_conservation_725  1
    load_0_15_18  free_load_conservation_743  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_19  arc_capacity_542  -20
    arc_0_15_19  connected_order_arc_543  -14
    arc_0_15_19  out_degree_720  1
    arc_0_15_19  in_degree_745  1
    arc_0_15_19  original_T_including_depot_unload_760  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_0_15_19  arc_capacity_542  1
    load_0_15_19  free_load_conservation_725  1
    load_0_15_19  free_load_conservation_749  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_20  arc_capacity_544  -20
    arc_0_15_20  connected_order_arc_545  -14
    arc_0_15_20  out_degree_720  1
    arc_0_15_20  in_degree_751  1
    arc_0_15_20  original_T_including_depot_unload_760  2.2299340442558691e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_20  arc_capacity_544  1
    load_0_15_20  free_load_conservation_725  1
    load_0_15_20  free_load_conservation_755  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_0  arc_capacity_546  -20
    arc_0_16_0  depot_return_or_bypass_672  1
    arc_0_16_0  out_degree_726  1
    arc_0_16_0  original_T_including_depot_unload_760  6.2904707403788154e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_0  arc_capacity_546  1
    load_0_16_0  free_load_conservation_731  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_1  arc_capacity_547  -20
    arc_0_16_1  connected_order_arc_548  -14
    arc_0_16_1  in_degree_674  1
    arc_0_16_1  out_degree_726  1
    arc_0_16_1  original_T_including_depot_unload_760  2.6417860079316790e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_1  arc_capacity_547  1
    load_0_16_1  segment_load_conservation_677  -1
    load_0_16_1  segment_prefix_lb_678  1
    load_0_16_1  segment_prefix_ub_679  1
    load_0_16_1  free_load_conservation_731  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_2  arc_capacity_549  -20
    arc_0_16_2  connected_order_arc_550  -14
    arc_0_16_2  in_degree_681  1
    arc_0_16_2  out_degree_726  1
    arc_0_16_2  original_T_including_depot_unload_760  4.8210275478508015e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_2  arc_capacity_549  1
    load_0_16_2  segment_load_conservation_684  -1
    load_0_16_2  segment_prefix_lb_685  1
    load_0_16_2  segment_prefix_ub_686  1
    load_0_16_2  free_load_conservation_731  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_3  arc_capacity_551  -20
    arc_0_16_3  connected_order_arc_552  -14
    arc_0_16_3  in_degree_688  1
    arc_0_16_3  out_degree_726  1
    arc_0_16_3  original_T_including_depot_unload_760  3.7084803914885475e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_3  arc_capacity_551  1
    load_0_16_3  segment_load_conservation_691  -1
    load_0_16_3  segment_prefix_lb_692  1
    load_0_16_3  segment_prefix_ub_693  1
    load_0_16_3  free_load_conservation_731  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_4  arc_capacity_553  -20
    arc_0_16_4  connected_order_arc_554  -14
    arc_0_16_4  in_degree_695  1
    arc_0_16_4  out_degree_726  1
    arc_0_16_4  original_T_including_depot_unload_760  2.9672747884555446e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_4  arc_capacity_553  1
    load_0_16_4  segment_load_conservation_698  -1
    load_0_16_4  segment_prefix_lb_699  1
    load_0_16_4  segment_prefix_ub_700  1
    load_0_16_4  free_load_conservation_731  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_5  arc_capacity_555  -20
    arc_0_16_5  connected_order_arc_556  -14
    arc_0_16_5  in_degree_702  1
    arc_0_16_5  out_degree_726  1
    arc_0_16_5  original_T_including_depot_unload_760  4.9345054001313224e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_5  arc_capacity_555  1
    load_0_16_5  segment_load_conservation_705  -1
    load_0_16_5  segment_prefix_lb_706  1
    load_0_16_5  segment_prefix_ub_707  1
    load_0_16_5  free_load_conservation_731  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_13  arc_capacity_557  -20
    arc_0_16_13  connected_order_arc_558  -14
    arc_0_16_13  in_degree_709  1
    arc_0_16_13  out_degree_726  1
    arc_0_16_13  original_T_including_depot_unload_760  3.5426413058949414e+01
    MARKER    'MARKER'                 'INTEND'
    load_0_16_13  arc_capacity_557  1
    load_0_16_13  free_load_conservation_713  -1
    load_0_16_13  free_load_conservation_731  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_14  arc_capacity_559  -20
    arc_0_16_14  connected_order_arc_560  -14
    arc_0_16_14  in_degree_715  1
    arc_0_16_14  out_degree_726  1
    arc_0_16_14  original_T_including_depot_unload_760  6.1926694994249909e-01
    MARKER    'MARKER'                 'INTEND'
    load_0_16_14  arc_capacity_559  1
    load_0_16_14  free_load_conservation_719  -1
    load_0_16_14  free_load_conservation_731  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_15  arc_capacity_561  -20
    arc_0_16_15  connected_order_arc_562  -14
    arc_0_16_15  in_degree_721  1
    arc_0_16_15  out_degree_726  1
    arc_0_16_15  original_T_including_depot_unload_760  2.0838401346783280e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_15  arc_capacity_561  1
    load_0_16_15  free_load_conservation_725  -1
    load_0_16_15  free_load_conservation_731  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_17  arc_capacity_563  -20
    arc_0_16_17  connected_order_arc_564  -14
    arc_0_16_17  out_degree_726  1
    arc_0_16_17  in_degree_733  1
    arc_0_16_17  original_T_including_depot_unload_760  1.6310373065065476e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_17  arc_capacity_563  1
    load_0_16_17  free_load_conservation_731  1
    load_0_16_17  free_load_conservation_737  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_18  arc_capacity_565  -20
    arc_0_16_18  connected_order_arc_566  -14
    arc_0_16_18  out_degree_726  1
    arc_0_16_18  in_degree_739  1
    arc_0_16_18  original_T_including_depot_unload_760  1.3208911608803092e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_18  arc_capacity_565  1
    load_0_16_18  free_load_conservation_731  1
    load_0_16_18  free_load_conservation_743  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_19  arc_capacity_567  -20
    arc_0_16_19  connected_order_arc_568  -14
    arc_0_16_19  out_degree_726  1
    arc_0_16_19  in_degree_745  1
    arc_0_16_19  original_T_including_depot_unload_760  1.4489149558446036e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_19  arc_capacity_567  1
    load_0_16_19  free_load_conservation_731  1
    load_0_16_19  free_load_conservation_749  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_20  arc_capacity_569  -20
    arc_0_16_20  connected_order_arc_570  -14
    arc_0_16_20  out_degree_726  1
    arc_0_16_20  in_degree_751  1
    arc_0_16_20  original_T_including_depot_unload_760  1.5460798335742169e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_20  arc_capacity_569  1
    load_0_16_20  free_load_conservation_731  1
    load_0_16_20  free_load_conservation_755  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_0  arc_capacity_571  -20
    arc_0_17_0  depot_return_or_bypass_672  1
    arc_0_17_0  out_degree_732  1
    arc_0_17_0  original_T_including_depot_unload_760  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_0  arc_capacity_571  1
    load_0_17_0  free_load_conservation_737  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_1  arc_capacity_572  -20
    arc_0_17_1  connected_order_arc_573  -14
    arc_0_17_1  in_degree_674  1
    arc_0_17_1  out_degree_732  1
    arc_0_17_1  original_T_including_depot_unload_760  1.8786452499301340e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_1  arc_capacity_572  1
    load_0_17_1  segment_load_conservation_677  -1
    load_0_17_1  segment_prefix_lb_678  1
    load_0_17_1  segment_prefix_ub_679  1
    load_0_17_1  free_load_conservation_737  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_2  arc_capacity_574  -20
    arc_0_17_2  connected_order_arc_575  -14
    arc_0_17_2  in_degree_681  1
    arc_0_17_2  out_degree_732  1
    arc_0_17_2  original_T_including_depot_unload_760  2.0959764716808540e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_2  arc_capacity_574  1
    load_0_17_2  segment_load_conservation_684  -1
    load_0_17_2  segment_prefix_lb_685  1
    load_0_17_2  segment_prefix_ub_686  1
    load_0_17_2  free_load_conservation_737  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_3  arc_capacity_576  -20
    arc_0_17_3  connected_order_arc_577  -14
    arc_0_17_3  in_degree_688  1
    arc_0_17_3  out_degree_732  1
    arc_0_17_3  original_T_including_depot_unload_760  1.8631004883789885e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_3  arc_capacity_576  1
    load_0_17_3  segment_load_conservation_691  -1
    load_0_17_3  segment_prefix_lb_692  1
    load_0_17_3  segment_prefix_ub_693  1
    load_0_17_3  free_load_conservation_737  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_4  arc_capacity_578  -20
    arc_0_17_4  connected_order_arc_579  -14
    arc_0_17_4  in_degree_695  1
    arc_0_17_4  out_degree_732  1
    arc_0_17_4  original_T_including_depot_unload_760  1.4300244315666421e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_4  arc_capacity_578  1
    load_0_17_4  segment_load_conservation_698  -1
    load_0_17_4  segment_prefix_lb_699  1
    load_0_17_4  segment_prefix_ub_700  1
    load_0_17_4  free_load_conservation_737  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_5  arc_capacity_580  -20
    arc_0_17_5  connected_order_arc_581  -14
    arc_0_17_5  in_degree_702  1
    arc_0_17_5  out_degree_732  1
    arc_0_17_5  original_T_including_depot_unload_760  1.3246263055739521e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_5  arc_capacity_580  1
    load_0_17_5  segment_load_conservation_705  -1
    load_0_17_5  segment_prefix_lb_706  1
    load_0_17_5  segment_prefix_ub_707  1
    load_0_17_5  free_load_conservation_737  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_13  arc_capacity_582  -20
    arc_0_17_13  connected_order_arc_583  -14
    arc_0_17_13  in_degree_709  1
    arc_0_17_13  out_degree_732  1
    arc_0_17_13  original_T_including_depot_unload_760  1.6472719129023171e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_13  arc_capacity_582  1
    load_0_17_13  free_load_conservation_713  -1
    load_0_17_13  free_load_conservation_737  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_14  arc_capacity_584  -20
    arc_0_17_14  connected_order_arc_585  -14
    arc_0_17_14  in_degree_715  1
    arc_0_17_14  out_degree_732  1
    arc_0_17_14  original_T_including_depot_unload_760  1.6305450534190286e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_14  arc_capacity_584  1
    load_0_17_14  free_load_conservation_719  -1
    load_0_17_14  free_load_conservation_737  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_15  arc_capacity_586  -20
    arc_0_17_15  connected_order_arc_587  -14
    arc_0_17_15  in_degree_721  1
    arc_0_17_15  out_degree_732  1
    arc_0_17_15  original_T_including_depot_unload_760  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_15  arc_capacity_586  1
    load_0_17_15  free_load_conservation_725  -1
    load_0_17_15  free_load_conservation_737  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_16  arc_capacity_588  -20
    arc_0_17_16  connected_order_arc_589  -14
    arc_0_17_16  in_degree_727  1
    arc_0_17_16  out_degree_732  1
    arc_0_17_16  original_T_including_depot_unload_760  1.6310373065065476e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_16  arc_capacity_588  1
    load_0_17_16  free_load_conservation_731  -1
    load_0_17_16  free_load_conservation_737  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_18  arc_capacity_590  -20
    arc_0_17_18  connected_order_arc_591  -14
    arc_0_17_18  out_degree_732  1
    arc_0_17_18  in_degree_739  1
    arc_0_17_18  original_T_including_depot_unload_760  1.5297878372821015e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_18  arc_capacity_590  1
    load_0_17_18  free_load_conservation_737  1
    load_0_17_18  free_load_conservation_743  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_19  arc_capacity_592  -20
    arc_0_17_19  connected_order_arc_593  -14
    arc_0_17_19  out_degree_732  1
    arc_0_17_19  in_degree_745  1
    arc_0_17_19  original_T_including_depot_unload_760  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_19  arc_capacity_592  1
    load_0_17_19  free_load_conservation_737  1
    load_0_17_19  free_load_conservation_749  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_20  arc_capacity_594  -20
    arc_0_17_20  connected_order_arc_595  -14
    arc_0_17_20  out_degree_732  1
    arc_0_17_20  in_degree_751  1
    arc_0_17_20  original_T_including_depot_unload_760  1.7807233899807140e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_20  arc_capacity_594  1
    load_0_17_20  free_load_conservation_737  1
    load_0_17_20  free_load_conservation_755  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_0  arc_capacity_596  -20
    arc_0_18_0  depot_return_or_bypass_672  1
    arc_0_18_0  out_degree_738  1
    arc_0_18_0  original_T_including_depot_unload_760  5.2273830510106120e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_0  arc_capacity_596  1
    load_0_18_0  free_load_conservation_743  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_1  arc_capacity_597  -20
    arc_0_18_1  connected_order_arc_598  -14
    arc_0_18_1  in_degree_674  1
    arc_0_18_1  out_degree_738  1
    arc_0_18_1  original_T_including_depot_unload_760  3.9263280945415767e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_1  arc_capacity_597  1
    load_0_18_1  segment_load_conservation_677  -1
    load_0_18_1  segment_prefix_lb_678  1
    load_0_18_1  segment_prefix_ub_679  1
    load_0_18_1  free_load_conservation_743  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_2  arc_capacity_599  -20
    arc_0_18_2  connected_order_arc_600  -14
    arc_0_18_2  in_degree_681  1
    arc_0_18_2  out_degree_738  1
    arc_0_18_2  original_T_including_depot_unload_760  6.0726027477261266e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_2  arc_capacity_599  1
    load_0_18_2  segment_load_conservation_684  -1
    load_0_18_2  segment_prefix_lb_685  1
    load_0_18_2  segment_prefix_ub_686  1
    load_0_18_2  free_load_conservation_743  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_3  arc_capacity_601  -20
    arc_0_18_3  connected_order_arc_602  -14
    arc_0_18_3  in_degree_688  1
    arc_0_18_3  out_degree_738  1
    arc_0_18_3  original_T_including_depot_unload_760  4.9828630663707764e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_3  arc_capacity_601  1
    load_0_18_3  segment_load_conservation_691  -1
    load_0_18_3  segment_prefix_lb_692  1
    load_0_18_3  segment_prefix_ub_693  1
    load_0_18_3  free_load_conservation_743  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_4  arc_capacity_603  -20
    arc_0_18_4  connected_order_arc_604  -14
    arc_0_18_4  in_degree_695  1
    arc_0_18_4  out_degree_738  1
    arc_0_18_4  original_T_including_depot_unload_760  1.6552401015053141e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_4  arc_capacity_603  1
    load_0_18_4  segment_load_conservation_698  -1
    load_0_18_4  segment_prefix_lb_699  1
    load_0_18_4  segment_prefix_ub_700  1
    load_0_18_4  free_load_conservation_743  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_5  arc_capacity_605  -20
    arc_0_18_5  connected_order_arc_606  -14
    arc_0_18_5  in_degree_702  1
    arc_0_18_5  out_degree_738  1
    arc_0_18_5  original_T_including_depot_unload_760  362.349437569786
    MARKER    'MARKER'                 'INTEND'
    load_0_18_5  arc_capacity_605  1
    load_0_18_5  segment_load_conservation_705  -1
    load_0_18_5  segment_prefix_lb_706  1
    load_0_18_5  segment_prefix_ub_707  1
    load_0_18_5  free_load_conservation_743  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_13  arc_capacity_607  -20
    arc_0_18_13  connected_order_arc_608  -14
    arc_0_18_13  in_degree_709  1
    arc_0_18_13  out_degree_738  1
    arc_0_18_13  original_T_including_depot_unload_760  1.2962070286822930e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_13  arc_capacity_607  1
    load_0_18_13  free_load_conservation_713  -1
    load_0_18_13  free_load_conservation_743  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_14  arc_capacity_609  -20
    arc_0_18_14  connected_order_arc_610  -14
    arc_0_18_14  in_degree_715  1
    arc_0_18_14  out_degree_738  1
    arc_0_18_14  original_T_including_depot_unload_760  1.3146996282072985e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_14  arc_capacity_609  1
    load_0_18_14  free_load_conservation_719  -1
    load_0_18_14  free_load_conservation_743  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_15  arc_capacity_611  -20
    arc_0_18_15  connected_order_arc_612  -14
    arc_0_18_15  in_degree_721  1
    arc_0_18_15  out_degree_738  1
    arc_0_18_15  original_T_including_depot_unload_760  1.9520133700471852e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_15  arc_capacity_611  1
    load_0_18_15  free_load_conservation_725  -1
    load_0_18_15  free_load_conservation_743  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_16  arc_capacity_613  -20
    arc_0_18_16  connected_order_arc_614  -14
    arc_0_18_16  in_degree_727  1
    arc_0_18_16  out_degree_738  1
    arc_0_18_16  original_T_including_depot_unload_760  1.3208911608803092e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_16  arc_capacity_613  1
    load_0_18_16  free_load_conservation_731  -1
    load_0_18_16  free_load_conservation_743  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_17  arc_capacity_615  -20
    arc_0_18_17  connected_order_arc_616  -14
    arc_0_18_17  in_degree_733  1
    arc_0_18_17  out_degree_738  1
    arc_0_18_17  original_T_including_depot_unload_760  1.5297878372821015e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_17  arc_capacity_615  1
    load_0_18_17  free_load_conservation_737  -1
    load_0_18_17  free_load_conservation_743  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_19  arc_capacity_617  -20
    arc_0_18_19  connected_order_arc_618  -14
    arc_0_18_19  out_degree_738  1
    arc_0_18_19  in_degree_745  1
    arc_0_18_19  original_T_including_depot_unload_760  1.3176071585703125e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_19  arc_capacity_617  1
    load_0_18_19  free_load_conservation_743  1
    load_0_18_19  free_load_conservation_749  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_20  arc_capacity_619  -20
    arc_0_18_20  connected_order_arc_620  -14
    arc_0_18_20  out_degree_738  1
    arc_0_18_20  in_degree_751  1
    arc_0_18_20  original_T_including_depot_unload_760  2.8083660458664087e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_20  arc_capacity_619  1
    load_0_18_20  free_load_conservation_743  1
    load_0_18_20  free_load_conservation_755  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_0  arc_capacity_621  -20
    arc_0_19_0  depot_return_or_bypass_672  1
    arc_0_19_0  out_degree_744  1
    arc_0_19_0  original_T_including_depot_unload_760  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_0  arc_capacity_621  1
    load_0_19_0  free_load_conservation_749  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_1  arc_capacity_622  -20
    arc_0_19_1  connected_order_arc_623  -14
    arc_0_19_1  in_degree_674  1
    arc_0_19_1  out_degree_744  1
    arc_0_19_1  original_T_including_depot_unload_760  1.7093216071319850e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_1  arc_capacity_622  1
    load_0_19_1  segment_load_conservation_677  -1
    load_0_19_1  segment_prefix_lb_678  1
    load_0_19_1  segment_prefix_ub_679  1
    load_0_19_1  free_load_conservation_749  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_2  arc_capacity_624  -20
    arc_0_19_2  connected_order_arc_625  -14
    arc_0_19_2  in_degree_681  1
    arc_0_19_2  out_degree_744  1
    arc_0_19_2  original_T_including_depot_unload_760  1.9185455792071525e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_2  arc_capacity_624  1
    load_0_19_2  segment_load_conservation_684  -1
    load_0_19_2  segment_prefix_lb_685  1
    load_0_19_2  segment_prefix_ub_686  1
    load_0_19_2  free_load_conservation_749  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_3  arc_capacity_626  -20
    arc_0_19_3  connected_order_arc_627  -14
    arc_0_19_3  in_degree_688  1
    arc_0_19_3  out_degree_744  1
    arc_0_19_3  original_T_including_depot_unload_760  1.7947282495227562e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_3  arc_capacity_626  1
    load_0_19_3  segment_load_conservation_691  -1
    load_0_19_3  segment_prefix_lb_692  1
    load_0_19_3  segment_prefix_ub_693  1
    load_0_19_3  free_load_conservation_749  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_4  arc_capacity_628  -20
    arc_0_19_4  connected_order_arc_629  -14
    arc_0_19_4  in_degree_695  1
    arc_0_19_4  out_degree_744  1
    arc_0_19_4  original_T_including_depot_unload_760  1.1588937665971753e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_4  arc_capacity_628  1
    load_0_19_4  segment_load_conservation_698  -1
    load_0_19_4  segment_prefix_lb_699  1
    load_0_19_4  segment_prefix_ub_700  1
    load_0_19_4  free_load_conservation_749  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_5  arc_capacity_630  -20
    arc_0_19_5  connected_order_arc_631  -14
    arc_0_19_5  in_degree_702  1
    arc_0_19_5  out_degree_744  1
    arc_0_19_5  original_T_including_depot_unload_760  9.7154140307447824e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_5  arc_capacity_630  1
    load_0_19_5  segment_load_conservation_705  -1
    load_0_19_5  segment_prefix_lb_706  1
    load_0_19_5  segment_prefix_ub_707  1
    load_0_19_5  free_load_conservation_749  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_13  arc_capacity_632  -20
    arc_0_19_13  connected_order_arc_633  -14
    arc_0_19_13  in_degree_709  1
    arc_0_19_13  out_degree_744  1
    arc_0_19_13  original_T_including_depot_unload_760  1.4457797980495495e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_13  arc_capacity_632  1
    load_0_19_13  free_load_conservation_713  -1
    load_0_19_13  free_load_conservation_749  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_14  arc_capacity_634  -20
    arc_0_19_14  connected_order_arc_635  -14
    arc_0_19_14  in_degree_715  1
    arc_0_19_14  out_degree_744  1
    arc_0_19_14  original_T_including_depot_unload_760  1.4482979064849126e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_14  arc_capacity_634  1
    load_0_19_14  free_load_conservation_719  -1
    load_0_19_14  free_load_conservation_749  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_15  arc_capacity_636  -20
    arc_0_19_15  connected_order_arc_637  -14
    arc_0_19_15  in_degree_721  1
    arc_0_19_15  out_degree_744  1
    arc_0_19_15  original_T_including_depot_unload_760  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_0_19_15  arc_capacity_636  1
    load_0_19_15  free_load_conservation_725  -1
    load_0_19_15  free_load_conservation_749  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_16  arc_capacity_638  -20
    arc_0_19_16  connected_order_arc_639  -14
    arc_0_19_16  in_degree_727  1
    arc_0_19_16  out_degree_744  1
    arc_0_19_16  original_T_including_depot_unload_760  1.4489149558446036e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_16  arc_capacity_638  1
    load_0_19_16  free_load_conservation_731  -1
    load_0_19_16  free_load_conservation_749  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_17  arc_capacity_640  -20
    arc_0_19_17  connected_order_arc_641  -14
    arc_0_19_17  in_degree_733  1
    arc_0_19_17  out_degree_744  1
    arc_0_19_17  original_T_including_depot_unload_760  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_17  arc_capacity_640  1
    load_0_19_17  free_load_conservation_737  -1
    load_0_19_17  free_load_conservation_749  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_18  arc_capacity_642  -20
    arc_0_19_18  connected_order_arc_643  -14
    arc_0_19_18  in_degree_739  1
    arc_0_19_18  out_degree_744  1
    arc_0_19_18  original_T_including_depot_unload_760  1.3176071585703125e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_18  arc_capacity_642  1
    load_0_19_18  free_load_conservation_743  -1
    load_0_19_18  free_load_conservation_749  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_20  arc_capacity_644  -20
    arc_0_19_20  connected_order_arc_645  -14
    arc_0_19_20  out_degree_744  1
    arc_0_19_20  in_degree_751  1
    arc_0_19_20  original_T_including_depot_unload_760  1.5971628811503840e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_20  arc_capacity_644  1
    load_0_19_20  free_load_conservation_749  1
    load_0_19_20  free_load_conservation_755  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_0  arc_capacity_646  -20
    arc_0_20_0  depot_return_or_bypass_672  1
    arc_0_20_0  out_degree_750  1
    arc_0_20_0  original_T_including_depot_unload_760  7.8199183337763486e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_0  arc_capacity_646  1
    load_0_20_0  free_load_conservation_755  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_1  arc_capacity_647  -20
    arc_0_20_1  connected_order_arc_648  -14
    arc_0_20_1  in_degree_674  1
    arc_0_20_1  out_degree_750  1
    arc_0_20_1  original_T_including_depot_unload_760  1.1216289013953633e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_1  arc_capacity_647  1
    load_0_20_1  segment_load_conservation_677  -1
    load_0_20_1  segment_prefix_lb_678  1
    load_0_20_1  segment_prefix_ub_679  1
    load_0_20_1  free_load_conservation_755  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_2  arc_capacity_649  -20
    arc_0_20_2  connected_order_arc_650  -14
    arc_0_20_2  in_degree_681  1
    arc_0_20_2  out_degree_750  1
    arc_0_20_2  original_T_including_depot_unload_760  3.2767382990070683e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_2  arc_capacity_649  1
    load_0_20_2  segment_load_conservation_684  -1
    load_0_20_2  segment_prefix_lb_685  1
    load_0_20_2  segment_prefix_ub_686  1
    load_0_20_2  free_load_conservation_755  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_3  arc_capacity_651  -20
    arc_0_20_3  connected_order_arc_652  -14
    arc_0_20_3  in_degree_688  1
    arc_0_20_3  out_degree_750  1
    arc_0_20_3  original_T_including_depot_unload_760  2.7370069334295619e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_3  arc_capacity_651  1
    load_0_20_3  segment_load_conservation_691  -1
    load_0_20_3  segment_prefix_lb_692  1
    load_0_20_3  segment_prefix_ub_693  1
    load_0_20_3  free_load_conservation_755  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_4  arc_capacity_653  -20
    arc_0_20_4  connected_order_arc_654  -14
    arc_0_20_4  in_degree_695  1
    arc_0_20_4  out_degree_750  1
    arc_0_20_4  original_T_including_depot_unload_760  4.3907641772187384e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_4  arc_capacity_653  1
    load_0_20_4  segment_load_conservation_698  -1
    load_0_20_4  segment_prefix_lb_699  1
    load_0_20_4  segment_prefix_ub_700  1
    load_0_20_4  free_load_conservation_755  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_5  arc_capacity_655  -20
    arc_0_20_5  connected_order_arc_656  -14
    arc_0_20_5  in_degree_702  1
    arc_0_20_5  out_degree_750  1
    arc_0_20_5  original_T_including_depot_unload_760  6.3283307285749891e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_5  arc_capacity_655  1
    load_0_20_5  segment_load_conservation_705  -1
    load_0_20_5  segment_prefix_lb_706  1
    load_0_20_5  segment_prefix_ub_707  1
    load_0_20_5  free_load_conservation_755  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_13  arc_capacity_657  -20
    arc_0_20_13  connected_order_arc_658  -14
    arc_0_20_13  in_degree_709  1
    arc_0_20_13  out_degree_750  1
    arc_0_20_13  original_T_including_depot_unload_760  1.5153540246292351e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_13  arc_capacity_657  1
    load_0_20_13  free_load_conservation_713  -1
    load_0_20_13  free_load_conservation_755  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_14  arc_capacity_659  -20
    arc_0_20_14  connected_order_arc_660  -14
    arc_0_20_14  in_degree_715  1
    arc_0_20_14  out_degree_750  1
    arc_0_20_14  original_T_including_depot_unload_760  1.5518157315724611e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_14  arc_capacity_659  1
    load_0_20_14  free_load_conservation_719  -1
    load_0_20_14  free_load_conservation_755  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_15  arc_capacity_661  -20
    arc_0_20_15  connected_order_arc_662  -14
    arc_0_20_15  in_degree_721  1
    arc_0_20_15  out_degree_750  1
    arc_0_20_15  original_T_including_depot_unload_760  2.2299340442558691e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_15  arc_capacity_661  1
    load_0_20_15  free_load_conservation_725  -1
    load_0_20_15  free_load_conservation_755  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_16  arc_capacity_663  -20
    arc_0_20_16  connected_order_arc_664  -14
    arc_0_20_16  in_degree_727  1
    arc_0_20_16  out_degree_750  1
    arc_0_20_16  original_T_including_depot_unload_760  1.5460798335742169e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_16  arc_capacity_663  1
    load_0_20_16  free_load_conservation_731  -1
    load_0_20_16  free_load_conservation_755  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_17  arc_capacity_665  -20
    arc_0_20_17  connected_order_arc_666  -14
    arc_0_20_17  in_degree_733  1
    arc_0_20_17  out_degree_750  1
    arc_0_20_17  original_T_including_depot_unload_760  1.7807233899807140e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_17  arc_capacity_665  1
    load_0_20_17  free_load_conservation_737  -1
    load_0_20_17  free_load_conservation_755  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_18  arc_capacity_667  -20
    arc_0_20_18  connected_order_arc_668  -14
    arc_0_20_18  in_degree_739  1
    arc_0_20_18  out_degree_750  1
    arc_0_20_18  original_T_including_depot_unload_760  2.8083660458664087e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_18  arc_capacity_667  1
    load_0_20_18  free_load_conservation_743  -1
    load_0_20_18  free_load_conservation_755  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_19  arc_capacity_669  -20
    arc_0_20_19  connected_order_arc_670  -14
    arc_0_20_19  in_degree_745  1
    arc_0_20_19  out_degree_750  1
    arc_0_20_19  original_T_including_depot_unload_760  1.5971628811503840e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_19  arc_capacity_669  1
    load_0_20_19  free_load_conservation_749  -1
    load_0_20_19  free_load_conservation_755  1
    visit_1_6  out_degree_1052  -1
    visit_1_6  in_degree_1053  -1
    visit_1_6  order_active_lb_1054  -1
    visit_1_6  order_active_ub_1055  -12
    order_1_6  connected_order_arc_776  -1
    order_1_6  connected_order_arc_778  -1
    order_1_6  connected_order_arc_780  -1
    order_1_6  connected_order_arc_782  -1
    order_1_6  connected_order_arc_784  -1
    order_1_6  connected_order_arc_786  -1
    order_1_6  connected_order_arc_788  -1
    order_1_6  connected_order_arc_790  -1
    order_1_6  connected_order_arc_792  -1
    order_1_6  connected_order_arc_794  -1
    order_1_6  connected_order_arc_796  -1
    order_1_6  connected_order_arc_799  1
    order_1_6  connected_order_arc_822  1
    order_1_6  connected_order_arc_845  1
    order_1_6  connected_order_arc_868  1
    order_1_6  connected_order_arc_891  1
    order_1_6  connected_order_arc_914  1
    order_1_6  connected_order_arc_937  1
    order_1_6  connected_order_arc_960  1
    order_1_6  connected_order_arc_983  1
    order_1_6  connected_order_arc_1006  1
    order_1_6  connected_order_arc_1029  1
    order_1_6  order_active_lb_1054  1
    order_1_6  order_active_ub_1055  1
    order_1_6  fixed_segment_relative_order_1128  -1
    visit_1_7  out_degree_1059  -1
    visit_1_7  in_degree_1060  -1
    visit_1_7  order_active_lb_1061  -1
    visit_1_7  order_active_ub_1062  -12
    order_1_7  connected_order_arc_776  1
    order_1_7  connected_order_arc_799  -1
    order_1_7  connected_order_arc_801  -1
    order_1_7  connected_order_arc_803  -1
    order_1_7  connected_order_arc_805  -1
    order_1_7  connected_order_arc_807  -1
    order_1_7  connected_order_arc_809  -1
    order_1_7  connected_order_arc_811  -1
    order_1_7  connected_order_arc_813  -1
    order_1_7  connected_order_arc_815  -1
    order_1_7  connected_order_arc_817  -1
    order_1_7  connected_order_arc_819  -1
    order_1_7  connected_order_arc_824  1
    order_1_7  connected_order_arc_847  1
    order_1_7  connected_order_arc_870  1
    order_1_7  connected_order_arc_893  1
    order_1_7  connected_order_arc_916  1
    order_1_7  connected_order_arc_939  1
    order_1_7  connected_order_arc_962  1
    order_1_7  connected_order_arc_985  1
    order_1_7  connected_order_arc_1008  1
    order_1_7  connected_order_arc_1031  1
    order_1_7  order_active_lb_1061  1
    order_1_7  order_active_ub_1062  1
    order_1_7  fixed_segment_relative_order_1128  1
    order_1_7  fixed_segment_relative_order_1129  -1
    visit_1_8  out_degree_1066  -1
    visit_1_8  in_degree_1067  -1
    visit_1_8  order_active_lb_1068  -1
    visit_1_8  order_active_ub_1069  -12
    order_1_8  connected_order_arc_778  1
    order_1_8  connected_order_arc_801  1
    order_1_8  connected_order_arc_822  -1
    order_1_8  connected_order_arc_824  -1
    order_1_8  connected_order_arc_826  -1
    order_1_8  connected_order_arc_828  -1
    order_1_8  connected_order_arc_830  -1
    order_1_8  connected_order_arc_832  -1
    order_1_8  connected_order_arc_834  -1
    order_1_8  connected_order_arc_836  -1
    order_1_8  connected_order_arc_838  -1
    order_1_8  connected_order_arc_840  -1
    order_1_8  connected_order_arc_842  -1
    order_1_8  connected_order_arc_849  1
    order_1_8  connected_order_arc_872  1
    order_1_8  connected_order_arc_895  1
    order_1_8  connected_order_arc_918  1
    order_1_8  connected_order_arc_941  1
    order_1_8  connected_order_arc_964  1
    order_1_8  connected_order_arc_987  1
    order_1_8  connected_order_arc_1010  1
    order_1_8  connected_order_arc_1033  1
    order_1_8  order_active_lb_1068  1
    order_1_8  order_active_ub_1069  1
    order_1_8  fixed_segment_relative_order_1129  1
    order_1_8  fixed_segment_relative_order_1130  -1
    visit_1_9  out_degree_1073  -1
    visit_1_9  in_degree_1074  -1
    visit_1_9  order_active_lb_1075  -1
    visit_1_9  order_active_ub_1076  -12
    order_1_9  connected_order_arc_780  1
    order_1_9  connected_order_arc_803  1
    order_1_9  connected_order_arc_826  1
    order_1_9  connected_order_arc_845  -1
    order_1_9  connected_order_arc_847  -1
    order_1_9  connected_order_arc_849  -1
    order_1_9  connected_order_arc_851  -1
    order_1_9  connected_order_arc_853  -1
    order_1_9  connected_order_arc_855  -1
    order_1_9  connected_order_arc_857  -1
    order_1_9  connected_order_arc_859  -1
    order_1_9  connected_order_arc_861  -1
    order_1_9  connected_order_arc_863  -1
    order_1_9  connected_order_arc_865  -1
    order_1_9  connected_order_arc_874  1
    order_1_9  connected_order_arc_897  1
    order_1_9  connected_order_arc_920  1
    order_1_9  connected_order_arc_943  1
    order_1_9  connected_order_arc_966  1
    order_1_9  connected_order_arc_989  1
    order_1_9  connected_order_arc_1012  1
    order_1_9  connected_order_arc_1035  1
    order_1_9  order_active_lb_1075  1
    order_1_9  order_active_ub_1076  1
    order_1_9  fixed_segment_relative_order_1130  1
    visit_1_13  out_degree_1080  -1
    visit_1_13  in_degree_1081  -1
    visit_1_13  order_active_lb_1082  -1
    visit_1_13  order_active_ub_1083  -12
    visit_1_13  service_visit_def_1084  -1
    order_1_13  connected_order_arc_782  1
    order_1_13  connected_order_arc_805  1
    order_1_13  connected_order_arc_828  1
    order_1_13  connected_order_arc_851  1
    order_1_13  connected_order_arc_868  -1
    order_1_13  connected_order_arc_870  -1
    order_1_13  connected_order_arc_872  -1
    order_1_13  connected_order_arc_874  -1
    order_1_13  connected_order_arc_876  -1
    order_1_13  connected_order_arc_878  -1
    order_1_13  connected_order_arc_880  -1
    order_1_13  connected_order_arc_882  -1
    order_1_13  connected_order_arc_884  -1
    order_1_13  connected_order_arc_886  -1
    order_1_13  connected_order_arc_888  -1
    order_1_13  connected_order_arc_899  1
    order_1_13  connected_order_arc_922  1
    order_1_13  connected_order_arc_945  1
    order_1_13  connected_order_arc_968  1
    order_1_13  connected_order_arc_991  1
    order_1_13  connected_order_arc_1014  1
    order_1_13  connected_order_arc_1037  1
    order_1_13  order_active_lb_1082  1
    order_1_13  order_active_ub_1083  1
    visit_1_14  out_degree_1086  -1
    visit_1_14  in_degree_1087  -1
    visit_1_14  order_active_lb_1088  -1
    visit_1_14  order_active_ub_1089  -12
    visit_1_14  service_visit_def_1090  -1
    order_1_14  connected_order_arc_784  1
    order_1_14  connected_order_arc_807  1
    order_1_14  connected_order_arc_830  1
    order_1_14  connected_order_arc_853  1
    order_1_14  connected_order_arc_876  1
    order_1_14  connected_order_arc_891  -1
    order_1_14  connected_order_arc_893  -1
    order_1_14  connected_order_arc_895  -1
    order_1_14  connected_order_arc_897  -1
    order_1_14  connected_order_arc_899  -1
    order_1_14  connected_order_arc_901  -1
    order_1_14  connected_order_arc_903  -1
    order_1_14  connected_order_arc_905  -1
    order_1_14  connected_order_arc_907  -1
    order_1_14  connected_order_arc_909  -1
    order_1_14  connected_order_arc_911  -1
    order_1_14  connected_order_arc_924  1
    order_1_14  connected_order_arc_947  1
    order_1_14  connected_order_arc_970  1
    order_1_14  connected_order_arc_993  1
    order_1_14  connected_order_arc_1016  1
    order_1_14  connected_order_arc_1039  1
    order_1_14  order_active_lb_1088  1
    order_1_14  order_active_ub_1089  1
    visit_1_15  out_degree_1092  -1
    visit_1_15  in_degree_1093  -1
    visit_1_15  order_active_lb_1094  -1
    visit_1_15  order_active_ub_1095  -12
    visit_1_15  service_visit_def_1096  -1
    order_1_15  connected_order_arc_786  1
    order_1_15  connected_order_arc_809  1
    order_1_15  connected_order_arc_832  1
    order_1_15  connected_order_arc_855  1
    order_1_15  connected_order_arc_878  1
    order_1_15  connected_order_arc_901  1
    order_1_15  connected_order_arc_914  -1
    order_1_15  connected_order_arc_916  -1
    order_1_15  connected_order_arc_918  -1
    order_1_15  connected_order_arc_920  -1
    order_1_15  connected_order_arc_922  -1
    order_1_15  connected_order_arc_924  -1
    order_1_15  connected_order_arc_926  -1
    order_1_15  connected_order_arc_928  -1
    order_1_15  connected_order_arc_930  -1
    order_1_15  connected_order_arc_932  -1
    order_1_15  connected_order_arc_934  -1
    order_1_15  connected_order_arc_949  1
    order_1_15  connected_order_arc_972  1
    order_1_15  connected_order_arc_995  1
    order_1_15  connected_order_arc_1018  1
    order_1_15  connected_order_arc_1041  1
    order_1_15  order_active_lb_1094  1
    order_1_15  order_active_ub_1095  1
    visit_1_16  out_degree_1098  -1
    visit_1_16  in_degree_1099  -1
    visit_1_16  order_active_lb_1100  -1
    visit_1_16  order_active_ub_1101  -12
    visit_1_16  service_visit_def_1102  -1
    order_1_16  connected_order_arc_788  1
    order_1_16  connected_order_arc_811  1
    order_1_16  connected_order_arc_834  1
    order_1_16  connected_order_arc_857  1
    order_1_16  connected_order_arc_880  1
    order_1_16  connected_order_arc_903  1
    order_1_16  connected_order_arc_926  1
    order_1_16  connected_order_arc_937  -1
    order_1_16  connected_order_arc_939  -1
    order_1_16  connected_order_arc_941  -1
    order_1_16  connected_order_arc_943  -1
    order_1_16  connected_order_arc_945  -1
    order_1_16  connected_order_arc_947  -1
    order_1_16  connected_order_arc_949  -1
    order_1_16  connected_order_arc_951  -1
    order_1_16  connected_order_arc_953  -1
    order_1_16  connected_order_arc_955  -1
    order_1_16  connected_order_arc_957  -1
    order_1_16  connected_order_arc_974  1
    order_1_16  connected_order_arc_997  1
    order_1_16  connected_order_arc_1020  1
    order_1_16  connected_order_arc_1043  1
    order_1_16  order_active_lb_1100  1
    order_1_16  order_active_ub_1101  1
    visit_1_17  out_degree_1104  -1
    visit_1_17  in_degree_1105  -1
    visit_1_17  order_active_lb_1106  -1
    visit_1_17  order_active_ub_1107  -12
    visit_1_17  service_visit_def_1108  -1
    order_1_17  connected_order_arc_790  1
    order_1_17  connected_order_arc_813  1
    order_1_17  connected_order_arc_836  1
    order_1_17  connected_order_arc_859  1
    order_1_17  connected_order_arc_882  1
    order_1_17  connected_order_arc_905  1
    order_1_17  connected_order_arc_928  1
    order_1_17  connected_order_arc_951  1
    order_1_17  connected_order_arc_960  -1
    order_1_17  connected_order_arc_962  -1
    order_1_17  connected_order_arc_964  -1
    order_1_17  connected_order_arc_966  -1
    order_1_17  connected_order_arc_968  -1
    order_1_17  connected_order_arc_970  -1
    order_1_17  connected_order_arc_972  -1
    order_1_17  connected_order_arc_974  -1
    order_1_17  connected_order_arc_976  -1
    order_1_17  connected_order_arc_978  -1
    order_1_17  connected_order_arc_980  -1
    order_1_17  connected_order_arc_999  1
    order_1_17  connected_order_arc_1022  1
    order_1_17  connected_order_arc_1045  1
    order_1_17  order_active_lb_1106  1
    order_1_17  order_active_ub_1107  1
    visit_1_18  out_degree_1110  -1
    visit_1_18  in_degree_1111  -1
    visit_1_18  order_active_lb_1112  -1
    visit_1_18  order_active_ub_1113  -12
    visit_1_18  service_visit_def_1114  -1
    order_1_18  connected_order_arc_792  1
    order_1_18  connected_order_arc_815  1
    order_1_18  connected_order_arc_838  1
    order_1_18  connected_order_arc_861  1
    order_1_18  connected_order_arc_884  1
    order_1_18  connected_order_arc_907  1
    order_1_18  connected_order_arc_930  1
    order_1_18  connected_order_arc_953  1
    order_1_18  connected_order_arc_976  1
    order_1_18  connected_order_arc_983  -1
    order_1_18  connected_order_arc_985  -1
    order_1_18  connected_order_arc_987  -1
    order_1_18  connected_order_arc_989  -1
    order_1_18  connected_order_arc_991  -1
    order_1_18  connected_order_arc_993  -1
    order_1_18  connected_order_arc_995  -1
    order_1_18  connected_order_arc_997  -1
    order_1_18  connected_order_arc_999  -1
    order_1_18  connected_order_arc_1001  -1
    order_1_18  connected_order_arc_1003  -1
    order_1_18  connected_order_arc_1024  1
    order_1_18  connected_order_arc_1047  1
    order_1_18  order_active_lb_1112  1
    order_1_18  order_active_ub_1113  1
    visit_1_19  out_degree_1116  -1
    visit_1_19  in_degree_1117  -1
    visit_1_19  order_active_lb_1118  -1
    visit_1_19  order_active_ub_1119  -12
    visit_1_19  service_visit_def_1120  -1
    order_1_19  connected_order_arc_794  1
    order_1_19  connected_order_arc_817  1
    order_1_19  connected_order_arc_840  1
    order_1_19  connected_order_arc_863  1
    order_1_19  connected_order_arc_886  1
    order_1_19  connected_order_arc_909  1
    order_1_19  connected_order_arc_932  1
    order_1_19  connected_order_arc_955  1
    order_1_19  connected_order_arc_978  1
    order_1_19  connected_order_arc_1001  1
    order_1_19  connected_order_arc_1006  -1
    order_1_19  connected_order_arc_1008  -1
    order_1_19  connected_order_arc_1010  -1
    order_1_19  connected_order_arc_1012  -1
    order_1_19  connected_order_arc_1014  -1
    order_1_19  connected_order_arc_1016  -1
    order_1_19  connected_order_arc_1018  -1
    order_1_19  connected_order_arc_1020  -1
    order_1_19  connected_order_arc_1022  -1
    order_1_19  connected_order_arc_1024  -1
    order_1_19  connected_order_arc_1026  -1
    order_1_19  connected_order_arc_1049  1
    order_1_19  order_active_lb_1118  1
    order_1_19  order_active_ub_1119  1
    visit_1_20  out_degree_1122  -1
    visit_1_20  in_degree_1123  -1
    visit_1_20  order_active_lb_1124  -1
    visit_1_20  order_active_ub_1125  -12
    visit_1_20  service_visit_def_1126  -1
    order_1_20  connected_order_arc_796  1
    order_1_20  connected_order_arc_819  1
    order_1_20  connected_order_arc_842  1
    order_1_20  connected_order_arc_865  1
    order_1_20  connected_order_arc_888  1
    order_1_20  connected_order_arc_911  1
    order_1_20  connected_order_arc_934  1
    order_1_20  connected_order_arc_957  1
    order_1_20  connected_order_arc_980  1
    order_1_20  connected_order_arc_1003  1
    order_1_20  connected_order_arc_1026  1
    order_1_20  connected_order_arc_1029  -1
    order_1_20  connected_order_arc_1031  -1
    order_1_20  connected_order_arc_1033  -1
    order_1_20  connected_order_arc_1035  -1
    order_1_20  connected_order_arc_1037  -1
    order_1_20  connected_order_arc_1039  -1
    order_1_20  connected_order_arc_1041  -1
    order_1_20  connected_order_arc_1043  -1
    order_1_20  connected_order_arc_1045  -1
    order_1_20  connected_order_arc_1047  -1
    order_1_20  connected_order_arc_1049  -1
    order_1_20  order_active_lb_1124  1
    order_1_20  order_active_ub_1125  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_0  arc_capacity_761  -25
    arc_1_0_0  depot_departure_or_bypass_1050  1
    arc_1_0_0  depot_return_or_bypass_1051  1
    MARKER    'MARKER'                 'INTEND'
    load_1_0_0  arc_capacity_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_6  arc_capacity_762  -25
    arc_1_0_6  depot_departure_or_bypass_1050  1
    arc_1_0_6  in_degree_1053  1
    arc_1_0_6  original_T_including_depot_unload_1131  1.1935953747864173e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_6  arc_capacity_762  1
    load_1_0_6  segment_load_conservation_1056  -1
    load_1_0_6  segment_prefix_lb_1057  1
    load_1_0_6  segment_prefix_ub_1058  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_7  arc_capacity_763  -25
    arc_1_0_7  depot_departure_or_bypass_1050  1
    arc_1_0_7  in_degree_1060  1
    arc_1_0_7  original_T_including_depot_unload_1131  1.4834116102542102e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_7  arc_capacity_763  1
    load_1_0_7  segment_load_conservation_1063  -1
    load_1_0_7  segment_prefix_lb_1064  1
    load_1_0_7  segment_prefix_ub_1065  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_8  arc_capacity_764  -25
    arc_1_0_8  depot_departure_or_bypass_1050  1
    arc_1_0_8  in_degree_1067  1
    arc_1_0_8  original_T_including_depot_unload_1131  5.4911852608328161e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_8  arc_capacity_764  1
    load_1_0_8  segment_load_conservation_1070  -1
    load_1_0_8  segment_prefix_lb_1071  1
    load_1_0_8  segment_prefix_ub_1072  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_9  arc_capacity_765  -25
    arc_1_0_9  depot_departure_or_bypass_1050  1
    arc_1_0_9  in_degree_1074  1
    arc_1_0_9  original_T_including_depot_unload_1131  3.5061909388980052e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_9  arc_capacity_765  1
    load_1_0_9  segment_load_conservation_1077  -1
    load_1_0_9  segment_prefix_lb_1078  1
    load_1_0_9  segment_prefix_ub_1079  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_13  arc_capacity_766  -25
    arc_1_0_13  depot_departure_or_bypass_1050  1
    arc_1_0_13  in_degree_1081  1
    arc_1_0_13  original_T_including_depot_unload_1131  6.4256529461228865e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_13  arc_capacity_766  1
    load_1_0_13  free_load_conservation_1085  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_14  arc_capacity_767  -25
    arc_1_0_14  depot_departure_or_bypass_1050  1
    arc_1_0_14  in_degree_1087  1
    arc_1_0_14  original_T_including_depot_unload_1131  6.2851955830851955e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_14  arc_capacity_767  1
    load_1_0_14  free_load_conservation_1091  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_15  arc_capacity_768  -25
    arc_1_0_15  depot_departure_or_bypass_1050  1
    arc_1_0_15  in_degree_1093  1
    arc_1_0_15  original_T_including_depot_unload_1131  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_15  arc_capacity_768  1
    load_1_0_15  free_load_conservation_1097  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_16  arc_capacity_769  -25
    arc_1_0_16  depot_departure_or_bypass_1050  1
    arc_1_0_16  in_degree_1099  1
    arc_1_0_16  original_T_including_depot_unload_1131  6.2904707403788154e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_16  arc_capacity_769  1
    load_1_0_16  free_load_conservation_1103  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_17  arc_capacity_770  -25
    arc_1_0_17  depot_departure_or_bypass_1050  1
    arc_1_0_17  in_degree_1105  1
    arc_1_0_17  original_T_including_depot_unload_1131  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_17  arc_capacity_770  1
    load_1_0_17  free_load_conservation_1109  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_18  arc_capacity_771  -25
    arc_1_0_18  depot_departure_or_bypass_1050  1
    arc_1_0_18  in_degree_1111  1
    arc_1_0_18  original_T_including_depot_unload_1131  5.2273830510106120e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_18  arc_capacity_771  1
    load_1_0_18  free_load_conservation_1115  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_19  arc_capacity_772  -25
    arc_1_0_19  depot_departure_or_bypass_1050  1
    arc_1_0_19  in_degree_1117  1
    arc_1_0_19  original_T_including_depot_unload_1131  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_19  arc_capacity_772  1
    load_1_0_19  free_load_conservation_1121  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_20  arc_capacity_773  -25
    arc_1_0_20  depot_departure_or_bypass_1050  1
    arc_1_0_20  in_degree_1123  1
    arc_1_0_20  original_T_including_depot_unload_1131  7.8199183337763486e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_20  arc_capacity_773  1
    load_1_0_20  free_load_conservation_1127  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_0  arc_capacity_774  -25
    arc_1_6_0  depot_return_or_bypass_1051  1
    arc_1_6_0  out_degree_1052  1
    arc_1_6_0  original_T_including_depot_unload_1131  7.2047755761928431e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_0  arc_capacity_774  1
    load_1_6_0  segment_load_conservation_1056  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_7  arc_capacity_775  -25
    arc_1_6_7  connected_order_arc_776  -13
    arc_1_6_7  out_degree_1052  1
    arc_1_6_7  in_degree_1060  1
    arc_1_6_7  original_T_including_depot_unload_1131  1.0359917537364215e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_7  arc_capacity_775  1
    load_1_6_7  segment_load_conservation_1056  1
    load_1_6_7  segment_load_conservation_1063  -1
    load_1_6_7  segment_prefix_lb_1064  1
    load_1_6_7  segment_prefix_ub_1065  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_8  arc_capacity_777  -25
    arc_1_6_8  connected_order_arc_778  -13
    arc_1_6_8  out_degree_1052  1
    arc_1_6_8  in_degree_1067  1
    arc_1_6_8  original_T_including_depot_unload_1131  2.9662284735332634e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_8  arc_capacity_777  1
    load_1_6_8  segment_load_conservation_1056  1
    load_1_6_8  segment_load_conservation_1070  -1
    load_1_6_8  segment_prefix_lb_1071  1
    load_1_6_8  segment_prefix_ub_1072  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_9  arc_capacity_779  -25
    arc_1_6_9  connected_order_arc_780  -13
    arc_1_6_9  out_degree_1052  1
    arc_1_6_9  in_degree_1074  1
    arc_1_6_9  original_T_including_depot_unload_1131  3.7747736142736670e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_9  arc_capacity_779  1
    load_1_6_9  segment_load_conservation_1056  1
    load_1_6_9  segment_load_conservation_1077  -1
    load_1_6_9  segment_prefix_lb_1078  1
    load_1_6_9  segment_prefix_ub_1079  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_13  arc_capacity_781  -25
    arc_1_6_13  connected_order_arc_782  -13
    arc_1_6_13  out_degree_1052  1
    arc_1_6_13  in_degree_1081  1
    arc_1_6_13  original_T_including_depot_unload_1131  6.7008394119213415e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_13  arc_capacity_781  1
    load_1_6_13  segment_load_conservation_1056  1
    load_1_6_13  free_load_conservation_1085  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_14  arc_capacity_783  -25
    arc_1_6_14  connected_order_arc_784  -13
    arc_1_6_14  out_degree_1052  1
    arc_1_6_14  in_degree_1087  1
    arc_1_6_14  original_T_including_depot_unload_1131  634.778043158074
    MARKER    'MARKER'                 'INTEND'
    load_1_6_14  arc_capacity_783  1
    load_1_6_14  segment_load_conservation_1056  1
    load_1_6_14  free_load_conservation_1091  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_15  arc_capacity_785  -25
    arc_1_6_15  connected_order_arc_786  -13
    arc_1_6_15  out_degree_1052  1
    arc_1_6_15  in_degree_1093  1
    arc_1_6_15  original_T_including_depot_unload_1131  2.2682175936128497e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_15  arc_capacity_785  1
    load_1_6_15  segment_load_conservation_1056  1
    load_1_6_15  free_load_conservation_1097  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_16  arc_capacity_787  -25
    arc_1_6_16  connected_order_arc_788  -13
    arc_1_6_16  out_degree_1052  1
    arc_1_6_16  in_degree_1099  1
    arc_1_6_16  original_T_including_depot_unload_1131  634.658635437287
    MARKER    'MARKER'                 'INTEND'
    load_1_6_16  arc_capacity_787  1
    load_1_6_16  segment_load_conservation_1056  1
    load_1_6_16  free_load_conservation_1103  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_17  arc_capacity_789  -25
    arc_1_6_17  connected_order_arc_790  -13
    arc_1_6_17  out_degree_1052  1
    arc_1_6_17  in_degree_1105  1
    arc_1_6_17  original_T_including_depot_unload_1131  1.4653145381016172e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_17  arc_capacity_789  1
    load_1_6_17  segment_load_conservation_1056  1
    load_1_6_17  free_load_conservation_1109  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_18  arc_capacity_791  -25
    arc_1_6_18  connected_order_arc_792  -13
    arc_1_6_18  out_degree_1052  1
    arc_1_6_18  in_degree_1111  1
    arc_1_6_18  original_T_including_depot_unload_1131  6.7500260835612892e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_18  arc_capacity_791  1
    load_1_6_18  segment_load_conservation_1056  1
    load_1_6_18  free_load_conservation_1115  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_19  arc_capacity_793  -25
    arc_1_6_19  connected_order_arc_794  -13
    arc_1_6_19  out_degree_1052  1
    arc_1_6_19  in_degree_1117  1
    arc_1_6_19  original_T_including_depot_unload_1131  1.6437981048195304e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_19  arc_capacity_793  1
    load_1_6_19  segment_load_conservation_1056  1
    load_1_6_19  free_load_conservation_1121  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_20  arc_capacity_795  -25
    arc_1_6_20  connected_order_arc_796  -13
    arc_1_6_20  out_degree_1052  1
    arc_1_6_20  in_degree_1123  1
    arc_1_6_20  original_T_including_depot_unload_1131  6.8151832047278333e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_20  arc_capacity_795  1
    load_1_6_20  segment_load_conservation_1056  1
    load_1_6_20  free_load_conservation_1127  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_0  arc_capacity_797  -25
    arc_1_7_0  depot_return_or_bypass_1051  1
    arc_1_7_0  out_degree_1059  1
    arc_1_7_0  original_T_including_depot_unload_1131  1.4834116102542102e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_0  arc_capacity_797  1
    load_1_7_0  segment_load_conservation_1063  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_6  arc_capacity_798  -25
    arc_1_7_6  connected_order_arc_799  -13
    arc_1_7_6  in_degree_1053  1
    arc_1_7_6  out_degree_1059  1
    arc_1_7_6  original_T_including_depot_unload_1131  2.1016283653335277e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_6  arc_capacity_798  1
    load_1_7_6  segment_load_conservation_1056  -1
    load_1_7_6  segment_prefix_lb_1057  1
    load_1_7_6  segment_prefix_ub_1058  1
    load_1_7_6  segment_load_conservation_1063  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_8  arc_capacity_800  -25
    arc_1_7_8  connected_order_arc_801  -13
    arc_1_7_8  out_degree_1059  1
    arc_1_7_8  in_degree_1067  1
    arc_1_7_8  original_T_including_depot_unload_1131  9.7352441264247466e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_8  arc_capacity_800  1
    load_1_7_8  segment_load_conservation_1063  1
    load_1_7_8  segment_load_conservation_1070  -1
    load_1_7_8  segment_prefix_lb_1071  1
    load_1_7_8  segment_prefix_ub_1072  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_9  arc_capacity_802  -25
    arc_1_7_9  connected_order_arc_803  -13
    arc_1_7_9  out_degree_1059  1
    arc_1_7_9  in_degree_1074  1
    arc_1_7_9  original_T_including_depot_unload_1131  1.2769578074048923e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_9  arc_capacity_802  1
    load_1_7_9  segment_load_conservation_1063  1
    load_1_7_9  segment_load_conservation_1077  -1
    load_1_7_9  segment_prefix_lb_1078  1
    load_1_7_9  segment_prefix_ub_1079  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_13  arc_capacity_804  -25
    arc_1_7_13  connected_order_arc_805  -13
    arc_1_7_13  out_degree_1059  1
    arc_1_7_13  in_degree_1081  1
    arc_1_7_13  original_T_including_depot_unload_1131  9.0007741891713113e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_13  arc_capacity_804  1
    load_1_7_13  segment_load_conservation_1063  1
    load_1_7_13  free_load_conservation_1085  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_14  arc_capacity_806  -25
    arc_1_7_14  connected_order_arc_807  -13
    arc_1_7_14  out_degree_1059  1
    arc_1_7_14  in_degree_1087  1
    arc_1_7_14  original_T_including_depot_unload_1131  8.9619134786808888e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_14  arc_capacity_806  1
    load_1_7_14  segment_load_conservation_1063  1
    load_1_7_14  free_load_conservation_1091  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_15  arc_capacity_808  -25
    arc_1_7_15  connected_order_arc_809  -13
    arc_1_7_15  out_degree_1059  1
    arc_1_7_15  in_degree_1093  1
    arc_1_7_15  original_T_including_depot_unload_1131  2.9790156048453791e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_15  arc_capacity_808  1
    load_1_7_15  segment_load_conservation_1063  1
    load_1_7_15  free_load_conservation_1097  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_16  arc_capacity_810  -25
    arc_1_7_16  connected_order_arc_811  -13
    arc_1_7_16  out_degree_1059  1
    arc_1_7_16  in_degree_1099  1
    arc_1_7_16  original_T_including_depot_unload_1131  8.9557394138123709e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_16  arc_capacity_810  1
    load_1_7_16  segment_load_conservation_1063  1
    load_1_7_16  free_load_conservation_1103  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_17  arc_capacity_812  -25
    arc_1_7_17  connected_order_arc_813  -13
    arc_1_7_17  out_degree_1059  1
    arc_1_7_17  in_degree_1105  1
    arc_1_7_17  original_T_including_depot_unload_1131  2.4321008933612479e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_17  arc_capacity_812  1
    load_1_7_17  segment_load_conservation_1063  1
    load_1_7_17  free_load_conservation_1109  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_18  arc_capacity_814  -25
    arc_1_7_18  connected_order_arc_815  -13
    arc_1_7_18  out_degree_1059  1
    arc_1_7_18  in_degree_1111  1
    arc_1_7_18  original_T_including_depot_unload_1131  1.0271253855277889e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_18  arc_capacity_814  1
    load_1_7_18  segment_load_conservation_1063  1
    load_1_7_18  free_load_conservation_1115  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_19  arc_capacity_816  -25
    arc_1_7_19  connected_order_arc_817  -13
    arc_1_7_19  out_degree_1059  1
    arc_1_7_19  in_degree_1117  1
    arc_1_7_19  original_T_including_depot_unload_1131  2.3444750474890211e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_19  arc_capacity_816  1
    load_1_7_19  segment_load_conservation_1063  1
    load_1_7_19  free_load_conservation_1121  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_20  arc_capacity_818  -25
    arc_1_7_20  connected_order_arc_819  -13
    arc_1_7_20  out_degree_1059  1
    arc_1_7_20  in_degree_1123  1
    arc_1_7_20  original_T_including_depot_unload_1131  7.4980220943945562e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_20  arc_capacity_818  1
    load_1_7_20  segment_load_conservation_1063  1
    load_1_7_20  free_load_conservation_1127  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_0  arc_capacity_820  -25
    arc_1_8_0  depot_return_or_bypass_1051  1
    arc_1_8_0  out_degree_1066  1
    arc_1_8_0  original_T_including_depot_unload_1131  5.4911852608328161e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_0  arc_capacity_820  1
    load_1_8_0  segment_load_conservation_1070  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_6  arc_capacity_821  -25
    arc_1_8_6  connected_order_arc_822  -13
    arc_1_8_6  in_degree_1053  1
    arc_1_8_6  out_degree_1066  1
    arc_1_8_6  original_T_including_depot_unload_1131  1.2739580769060942e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_6  arc_capacity_821  1
    load_1_8_6  segment_load_conservation_1056  -1
    load_1_8_6  segment_prefix_lb_1057  1
    load_1_8_6  segment_prefix_ub_1058  1
    load_1_8_6  segment_load_conservation_1070  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_7  arc_capacity_823  -25
    arc_1_8_7  connected_order_arc_824  -13
    arc_1_8_7  in_degree_1060  1
    arc_1_8_7  out_degree_1066  1
    arc_1_8_7  original_T_including_depot_unload_1131  9.7352441264247466e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_7  arc_capacity_823  1
    load_1_8_7  segment_load_conservation_1063  -1
    load_1_8_7  segment_prefix_lb_1064  1
    load_1_8_7  segment_prefix_ub_1065  1
    load_1_8_7  segment_load_conservation_1070  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_9  arc_capacity_825  -25
    arc_1_8_9  connected_order_arc_826  -13
    arc_1_8_9  out_degree_1066  1
    arc_1_8_9  in_degree_1074  1
    arc_1_8_9  original_T_including_depot_unload_1131  3.0614301781508658e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_9  arc_capacity_825  1
    load_1_8_9  segment_load_conservation_1070  1
    load_1_8_9  segment_load_conservation_1077  -1
    load_1_8_9  segment_prefix_lb_1078  1
    load_1_8_9  segment_prefix_ub_1079  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_13  arc_capacity_827  -25
    arc_1_8_13  connected_order_arc_828  -13
    arc_1_8_13  out_degree_1066  1
    arc_1_8_13  in_degree_1081  1
    arc_1_8_13  original_T_including_depot_unload_1131  3.8231967210987659e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_13  arc_capacity_827  1
    load_1_8_13  segment_load_conservation_1070  1
    load_1_8_13  free_load_conservation_1085  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_14  arc_capacity_829  -25
    arc_1_8_14  connected_order_arc_830  -13
    arc_1_8_14  out_degree_1066  1
    arc_1_8_14  in_degree_1087  1
    arc_1_8_14  original_T_including_depot_unload_1131  3.4726967782722494e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_14  arc_capacity_829  1
    load_1_8_14  segment_load_conservation_1070  1
    load_1_8_14  free_load_conservation_1091  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_15  arc_capacity_831  -25
    arc_1_8_15  connected_order_arc_832  -13
    arc_1_8_15  out_degree_1066  1
    arc_1_8_15  in_degree_1093  1
    arc_1_8_15  original_T_including_depot_unload_1131  2.1109553693139742e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_15  arc_capacity_831  1
    load_1_8_15  segment_load_conservation_1070  1
    load_1_8_15  free_load_conservation_1097  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_16  arc_capacity_833  -25
    arc_1_8_16  connected_order_arc_834  -13
    arc_1_8_16  out_degree_1066  1
    arc_1_8_16  in_degree_1099  1
    arc_1_8_16  original_T_including_depot_unload_1131  3.4724611547105854e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_16  arc_capacity_833  1
    load_1_8_16  segment_load_conservation_1070  1
    load_1_8_16  free_load_conservation_1103  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_17  arc_capacity_835  -25
    arc_1_8_17  connected_order_arc_836  -13
    arc_1_8_17  out_degree_1066  1
    arc_1_8_17  in_degree_1105  1
    arc_1_8_17  original_T_including_depot_unload_1131  1.4586348268927468e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_17  arc_capacity_835  1
    load_1_8_17  segment_load_conservation_1070  1
    load_1_8_17  free_load_conservation_1109  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_18  arc_capacity_837  -25
    arc_1_8_18  connected_order_arc_838  -13
    arc_1_8_18  out_degree_1066  1
    arc_1_8_18  in_degree_1111  1
    arc_1_8_18  original_T_including_depot_unload_1131  3.7840168155842611e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_18  arc_capacity_837  1
    load_1_8_18  segment_load_conservation_1070  1
    load_1_8_18  free_load_conservation_1115  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_19  arc_capacity_839  -25
    arc_1_8_19  connected_order_arc_840  -13
    arc_1_8_19  out_degree_1066  1
    arc_1_8_19  in_degree_1117  1
    arc_1_8_19  original_T_including_depot_unload_1131  1.4738339199468992e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_19  arc_capacity_839  1
    load_1_8_19  segment_load_conservation_1070  1
    load_1_8_19  free_load_conservation_1121  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_20  arc_capacity_841  -25
    arc_1_8_20  connected_order_arc_842  -13
    arc_1_8_20  out_degree_1066  1
    arc_1_8_20  in_degree_1123  1
    arc_1_8_20  original_T_including_depot_unload_1131  4.2580398435897172e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_20  arc_capacity_841  1
    load_1_8_20  segment_load_conservation_1070  1
    load_1_8_20  free_load_conservation_1127  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_0  arc_capacity_843  -25
    arc_1_9_0  depot_return_or_bypass_1051  1
    arc_1_9_0  out_degree_1073  1
    arc_1_9_0  original_T_including_depot_unload_1131  3.5061909388980052e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_0  arc_capacity_843  1
    load_1_9_0  segment_load_conservation_1077  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_6  arc_capacity_844  -25
    arc_1_9_6  connected_order_arc_845  -13
    arc_1_9_6  in_degree_1053  1
    arc_1_9_6  out_degree_1073  1
    arc_1_9_6  original_T_including_depot_unload_1131  1.0313568965059917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_6  arc_capacity_844  1
    load_1_9_6  segment_load_conservation_1056  -1
    load_1_9_6  segment_prefix_lb_1057  1
    load_1_9_6  segment_prefix_ub_1058  1
    load_1_9_6  segment_load_conservation_1077  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_7  arc_capacity_846  -25
    arc_1_9_7  connected_order_arc_847  -13
    arc_1_9_7  in_degree_1060  1
    arc_1_9_7  out_degree_1073  1
    arc_1_9_7  original_T_including_depot_unload_1131  1.2769578074048923e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_7  arc_capacity_846  1
    load_1_9_7  segment_load_conservation_1063  -1
    load_1_9_7  segment_prefix_lb_1064  1
    load_1_9_7  segment_prefix_ub_1065  1
    load_1_9_7  segment_load_conservation_1077  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_8  arc_capacity_848  -25
    arc_1_9_8  connected_order_arc_849  -13
    arc_1_9_8  in_degree_1067  1
    arc_1_9_8  out_degree_1073  1
    arc_1_9_8  original_T_including_depot_unload_1131  3.0614301781508658e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_8  arc_capacity_848  1
    load_1_9_8  segment_load_conservation_1070  -1
    load_1_9_8  segment_prefix_lb_1071  1
    load_1_9_8  segment_prefix_ub_1072  1
    load_1_9_8  segment_load_conservation_1077  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_13  arc_capacity_850  -25
    arc_1_9_13  connected_order_arc_851  -13
    arc_1_9_13  out_degree_1073  1
    arc_1_9_13  in_degree_1081  1
    arc_1_9_13  original_T_including_depot_unload_1131  6.0082621405522366e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_13  arc_capacity_850  1
    load_1_9_13  segment_load_conservation_1077  1
    load_1_9_13  free_load_conservation_1085  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_14  arc_capacity_852  -25
    arc_1_9_14  connected_order_arc_853  -13
    arc_1_9_14  out_degree_1073  1
    arc_1_9_14  in_degree_1087  1
    arc_1_9_14  original_T_including_depot_unload_1131  5.7138137092491206e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_14  arc_capacity_852  1
    load_1_9_14  segment_load_conservation_1077  1
    load_1_9_14  free_load_conservation_1091  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_15  arc_capacity_854  -25
    arc_1_9_15  connected_order_arc_855  -13
    arc_1_9_15  out_degree_1073  1
    arc_1_9_15  in_degree_1093  1
    arc_1_9_15  original_T_including_depot_unload_1131  1.8911324761641883e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_15  arc_capacity_854  1
    load_1_9_15  segment_load_conservation_1077  1
    load_1_9_15  free_load_conservation_1097  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_16  arc_capacity_856  -25
    arc_1_9_16  connected_order_arc_857  -13
    arc_1_9_16  out_degree_1073  1
    arc_1_9_16  in_degree_1099  1
    arc_1_9_16  original_T_including_depot_unload_1131  5.7164184935040350e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_16  arc_capacity_856  1
    load_1_9_16  segment_load_conservation_1077  1
    load_1_9_16  free_load_conservation_1103  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_17  arc_capacity_858  -25
    arc_1_9_17  connected_order_arc_859  -13
    arc_1_9_17  out_degree_1073  1
    arc_1_9_17  in_degree_1105  1
    arc_1_9_17  original_T_including_depot_unload_1131  1.1561945146971345e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_17  arc_capacity_858  1
    load_1_9_17  segment_load_conservation_1077  1
    load_1_9_17  free_load_conservation_1109  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_18  arc_capacity_860  -25
    arc_1_9_18  connected_order_arc_861  -13
    arc_1_9_18  out_degree_1073  1
    arc_1_9_18  in_degree_1111  1
    arc_1_9_18  original_T_including_depot_unload_1131  5.3222543932043470e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_18  arc_capacity_860  1
    load_1_9_18  segment_load_conservation_1077  1
    load_1_9_18  free_load_conservation_1115  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_19  arc_capacity_862  -25
    arc_1_9_19  connected_order_arc_863  -13
    arc_1_9_19  out_degree_1073  1
    arc_1_9_19  in_degree_1117  1
    arc_1_9_19  original_T_including_depot_unload_1131  1.2665309635243570e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_19  arc_capacity_862  1
    load_1_9_19  segment_load_conservation_1077  1
    load_1_9_19  free_load_conservation_1121  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_20  arc_capacity_864  -25
    arc_1_9_20  connected_order_arc_865  -13
    arc_1_9_20  out_degree_1073  1
    arc_1_9_20  in_degree_1123  1
    arc_1_9_20  original_T_including_depot_unload_1131  6.9292160543761986e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_20  arc_capacity_864  1
    load_1_9_20  segment_load_conservation_1077  1
    load_1_9_20  free_load_conservation_1127  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_0  arc_capacity_866  -25
    arc_1_13_0  depot_return_or_bypass_1051  1
    arc_1_13_0  out_degree_1080  1
    arc_1_13_0  original_T_including_depot_unload_1131  6.4256529461228865e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_0  arc_capacity_866  1
    load_1_13_0  free_load_conservation_1085  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_6  arc_capacity_867  -25
    arc_1_13_6  connected_order_arc_868  -13
    arc_1_13_6  in_degree_1053  1
    arc_1_13_6  out_degree_1080  1
    arc_1_13_6  original_T_including_depot_unload_1131  1.6269573599812545e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_6  arc_capacity_867  1
    load_1_13_6  segment_load_conservation_1056  -1
    load_1_13_6  segment_prefix_lb_1057  1
    load_1_13_6  segment_prefix_ub_1058  1
    load_1_13_6  free_load_conservation_1085  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_7  arc_capacity_869  -25
    arc_1_13_7  connected_order_arc_870  -13
    arc_1_13_7  in_degree_1060  1
    arc_1_13_7  out_degree_1080  1
    arc_1_13_7  original_T_including_depot_unload_1131  9.0007741891713113e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_7  arc_capacity_869  1
    load_1_13_7  segment_load_conservation_1063  -1
    load_1_13_7  segment_prefix_lb_1064  1
    load_1_13_7  segment_prefix_ub_1065  1
    load_1_13_7  free_load_conservation_1085  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_8  arc_capacity_871  -25
    arc_1_13_8  connected_order_arc_872  -13
    arc_1_13_8  in_degree_1067  1
    arc_1_13_8  out_degree_1080  1
    arc_1_13_8  original_T_including_depot_unload_1131  3.8231967210987659e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_8  arc_capacity_871  1
    load_1_13_8  segment_load_conservation_1070  -1
    load_1_13_8  segment_prefix_lb_1071  1
    load_1_13_8  segment_prefix_ub_1072  1
    load_1_13_8  free_load_conservation_1085  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_9  arc_capacity_873  -25
    arc_1_13_9  connected_order_arc_874  -13
    arc_1_13_9  in_degree_1074  1
    arc_1_13_9  out_degree_1080  1
    arc_1_13_9  original_T_including_depot_unload_1131  6.0082621405522366e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_9  arc_capacity_873  1
    load_1_13_9  segment_load_conservation_1077  -1
    load_1_13_9  segment_prefix_lb_1078  1
    load_1_13_9  segment_prefix_ub_1079  1
    load_1_13_9  free_load_conservation_1085  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_14  arc_capacity_875  -25
    arc_1_13_14  connected_order_arc_876  -13
    arc_1_13_14  out_degree_1080  1
    arc_1_13_14  in_degree_1087  1
    arc_1_13_14  original_T_including_depot_unload_1131  3.5317482243205085e+01
    MARKER    'MARKER'                 'INTEND'
    load_1_13_14  arc_capacity_875  1
    load_1_13_14  free_load_conservation_1085  1
    load_1_13_14  free_load_conservation_1091  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_15  arc_capacity_877  -25
    arc_1_13_15  connected_order_arc_878  -13
    arc_1_13_15  out_degree_1080  1
    arc_1_13_15  in_degree_1093  1
    arc_1_13_15  original_T_including_depot_unload_1131  2.0790680627934375e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_15  arc_capacity_877  1
    load_1_13_15  free_load_conservation_1085  1
    load_1_13_15  free_load_conservation_1097  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_16  arc_capacity_879  -25
    arc_1_13_16  connected_order_arc_880  -13
    arc_1_13_16  out_degree_1080  1
    arc_1_13_16  in_degree_1099  1
    arc_1_13_16  original_T_including_depot_unload_1131  3.5426413058949414e+01
    MARKER    'MARKER'                 'INTEND'
    load_1_13_16  arc_capacity_879  1
    load_1_13_16  free_load_conservation_1085  1
    load_1_13_16  free_load_conservation_1103  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_17  arc_capacity_881  -25
    arc_1_13_17  connected_order_arc_882  -13
    arc_1_13_17  out_degree_1080  1
    arc_1_13_17  in_degree_1105  1
    arc_1_13_17  original_T_including_depot_unload_1131  1.6472719129023171e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_17  arc_capacity_881  1
    load_1_13_17  free_load_conservation_1085  1
    load_1_13_17  free_load_conservation_1109  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_18  arc_capacity_883  -25
    arc_1_13_18  connected_order_arc_884  -13
    arc_1_13_18  out_degree_1080  1
    arc_1_13_18  in_degree_1111  1
    arc_1_13_18  original_T_including_depot_unload_1131  1.2962070286822930e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_18  arc_capacity_883  1
    load_1_13_18  free_load_conservation_1085  1
    load_1_13_18  free_load_conservation_1115  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_19  arc_capacity_885  -25
    arc_1_13_19  connected_order_arc_886  -13
    arc_1_13_19  out_degree_1080  1
    arc_1_13_19  in_degree_1117  1
    arc_1_13_19  original_T_including_depot_unload_1131  1.4457797980495495e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_19  arc_capacity_885  1
    load_1_13_19  free_load_conservation_1085  1
    load_1_13_19  free_load_conservation_1121  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_20  arc_capacity_887  -25
    arc_1_13_20  connected_order_arc_888  -13
    arc_1_13_20  out_degree_1080  1
    arc_1_13_20  in_degree_1123  1
    arc_1_13_20  original_T_including_depot_unload_1131  1.5153540246292351e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_20  arc_capacity_887  1
    load_1_13_20  free_load_conservation_1085  1
    load_1_13_20  free_load_conservation_1127  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_0  arc_capacity_889  -25
    arc_1_14_0  depot_return_or_bypass_1051  1
    arc_1_14_0  out_degree_1086  1
    arc_1_14_0  original_T_including_depot_unload_1131  6.2851955830851955e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_0  arc_capacity_889  1
    load_1_14_0  free_load_conservation_1091  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_6  arc_capacity_890  -25
    arc_1_14_6  connected_order_arc_891  -13
    arc_1_14_6  in_degree_1053  1
    arc_1_14_6  out_degree_1086  1
    arc_1_14_6  original_T_including_depot_unload_1131  1.5954463271473815e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_6  arc_capacity_890  1
    load_1_14_6  segment_load_conservation_1056  -1
    load_1_14_6  segment_prefix_lb_1057  1
    load_1_14_6  segment_prefix_ub_1058  1
    load_1_14_6  free_load_conservation_1091  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_7  arc_capacity_892  -25
    arc_1_14_7  connected_order_arc_893  -13
    arc_1_14_7  in_degree_1060  1
    arc_1_14_7  out_degree_1086  1
    arc_1_14_7  original_T_including_depot_unload_1131  8.9619134786808888e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_7  arc_capacity_892  1
    load_1_14_7  segment_load_conservation_1063  -1
    load_1_14_7  segment_prefix_lb_1064  1
    load_1_14_7  segment_prefix_ub_1065  1
    load_1_14_7  free_load_conservation_1091  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_8  arc_capacity_894  -25
    arc_1_14_8  connected_order_arc_895  -13
    arc_1_14_8  in_degree_1067  1
    arc_1_14_8  out_degree_1086  1
    arc_1_14_8  original_T_including_depot_unload_1131  3.4726967782722494e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_8  arc_capacity_894  1
    load_1_14_8  segment_load_conservation_1070  -1
    load_1_14_8  segment_prefix_lb_1071  1
    load_1_14_8  segment_prefix_ub_1072  1
    load_1_14_8  free_load_conservation_1091  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_9  arc_capacity_896  -25
    arc_1_14_9  connected_order_arc_897  -13
    arc_1_14_9  in_degree_1074  1
    arc_1_14_9  out_degree_1086  1
    arc_1_14_9  original_T_including_depot_unload_1131  5.7138137092491206e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_9  arc_capacity_896  1
    load_1_14_9  segment_load_conservation_1077  -1
    load_1_14_9  segment_prefix_lb_1078  1
    load_1_14_9  segment_prefix_ub_1079  1
    load_1_14_9  free_load_conservation_1091  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_13  arc_capacity_898  -25
    arc_1_14_13  connected_order_arc_899  -13
    arc_1_14_13  in_degree_1081  1
    arc_1_14_13  out_degree_1086  1
    arc_1_14_13  original_T_including_depot_unload_1131  3.5317482243205085e+01
    MARKER    'MARKER'                 'INTEND'
    load_1_14_13  arc_capacity_898  1
    load_1_14_13  free_load_conservation_1085  -1
    load_1_14_13  free_load_conservation_1091  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_15  arc_capacity_900  -25
    arc_1_14_15  connected_order_arc_901  -13
    arc_1_14_15  out_degree_1086  1
    arc_1_14_15  in_degree_1093  1
    arc_1_14_15  original_T_including_depot_unload_1131  2.0832214111784192e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_15  arc_capacity_900  1
    load_1_14_15  free_load_conservation_1091  1
    load_1_14_15  free_load_conservation_1097  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_16  arc_capacity_902  -25
    arc_1_14_16  connected_order_arc_903  -13
    arc_1_14_16  out_degree_1086  1
    arc_1_14_16  in_degree_1099  1
    arc_1_14_16  original_T_including_depot_unload_1131  6.1926694994249909e-01
    MARKER    'MARKER'                 'INTEND'
    load_1_14_16  arc_capacity_902  1
    load_1_14_16  free_load_conservation_1091  1
    load_1_14_16  free_load_conservation_1103  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_17  arc_capacity_904  -25
    arc_1_14_17  connected_order_arc_905  -13
    arc_1_14_17  out_degree_1086  1
    arc_1_14_17  in_degree_1105  1
    arc_1_14_17  original_T_including_depot_unload_1131  1.6305450534190286e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_17  arc_capacity_904  1
    load_1_14_17  free_load_conservation_1091  1
    load_1_14_17  free_load_conservation_1109  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_18  arc_capacity_906  -25
    arc_1_14_18  connected_order_arc_907  -13
    arc_1_14_18  out_degree_1086  1
    arc_1_14_18  in_degree_1111  1
    arc_1_14_18  original_T_including_depot_unload_1131  1.3146996282072985e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_18  arc_capacity_906  1
    load_1_14_18  free_load_conservation_1091  1
    load_1_14_18  free_load_conservation_1115  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_19  arc_capacity_908  -25
    arc_1_14_19  connected_order_arc_909  -13
    arc_1_14_19  out_degree_1086  1
    arc_1_14_19  in_degree_1117  1
    arc_1_14_19  original_T_including_depot_unload_1131  1.4482979064849126e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_19  arc_capacity_908  1
    load_1_14_19  free_load_conservation_1091  1
    load_1_14_19  free_load_conservation_1121  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_20  arc_capacity_910  -25
    arc_1_14_20  connected_order_arc_911  -13
    arc_1_14_20  out_degree_1086  1
    arc_1_14_20  in_degree_1123  1
    arc_1_14_20  original_T_including_depot_unload_1131  1.5518157315724611e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_20  arc_capacity_910  1
    load_1_14_20  free_load_conservation_1091  1
    load_1_14_20  free_load_conservation_1127  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_0  arc_capacity_912  -25
    arc_1_15_0  depot_return_or_bypass_1051  1
    arc_1_15_0  out_degree_1092  1
    arc_1_15_0  original_T_including_depot_unload_1131  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_0  arc_capacity_912  1
    load_1_15_0  free_load_conservation_1097  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_6  arc_capacity_913  -25
    arc_1_15_6  connected_order_arc_914  -13
    arc_1_15_6  in_degree_1053  1
    arc_1_15_6  out_degree_1092  1
    arc_1_15_6  original_T_including_depot_unload_1131  2.1501600514850211e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_6  arc_capacity_913  1
    load_1_15_6  segment_load_conservation_1056  -1
    load_1_15_6  segment_prefix_lb_1057  1
    load_1_15_6  segment_prefix_ub_1058  1
    load_1_15_6  free_load_conservation_1097  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_7  arc_capacity_915  -25
    arc_1_15_7  connected_order_arc_916  -13
    arc_1_15_7  in_degree_1060  1
    arc_1_15_7  out_degree_1092  1
    arc_1_15_7  original_T_including_depot_unload_1131  2.9790156048453791e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_7  arc_capacity_915  1
    load_1_15_7  segment_load_conservation_1063  -1
    load_1_15_7  segment_prefix_lb_1064  1
    load_1_15_7  segment_prefix_ub_1065  1
    load_1_15_7  free_load_conservation_1097  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_8  arc_capacity_917  -25
    arc_1_15_8  connected_order_arc_918  -13
    arc_1_15_8  in_degree_1067  1
    arc_1_15_8  out_degree_1092  1
    arc_1_15_8  original_T_including_depot_unload_1131  2.1109553693139742e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_8  arc_capacity_917  1
    load_1_15_8  segment_load_conservation_1070  -1
    load_1_15_8  segment_prefix_lb_1071  1
    load_1_15_8  segment_prefix_ub_1072  1
    load_1_15_8  free_load_conservation_1097  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_9  arc_capacity_919  -25
    arc_1_15_9  connected_order_arc_920  -13
    arc_1_15_9  in_degree_1074  1
    arc_1_15_9  out_degree_1092  1
    arc_1_15_9  original_T_including_depot_unload_1131  1.8911324761641883e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_9  arc_capacity_919  1
    load_1_15_9  segment_load_conservation_1077  -1
    load_1_15_9  segment_prefix_lb_1078  1
    load_1_15_9  segment_prefix_ub_1079  1
    load_1_15_9  free_load_conservation_1097  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_13  arc_capacity_921  -25
    arc_1_15_13  connected_order_arc_922  -13
    arc_1_15_13  in_degree_1081  1
    arc_1_15_13  out_degree_1092  1
    arc_1_15_13  original_T_including_depot_unload_1131  2.0790680627934375e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_13  arc_capacity_921  1
    load_1_15_13  free_load_conservation_1085  -1
    load_1_15_13  free_load_conservation_1097  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_14  arc_capacity_923  -25
    arc_1_15_14  connected_order_arc_924  -13
    arc_1_15_14  in_degree_1087  1
    arc_1_15_14  out_degree_1092  1
    arc_1_15_14  original_T_including_depot_unload_1131  2.0832214111784192e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_14  arc_capacity_923  1
    load_1_15_14  free_load_conservation_1091  -1
    load_1_15_14  free_load_conservation_1097  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_16  arc_capacity_925  -25
    arc_1_15_16  connected_order_arc_926  -13
    arc_1_15_16  out_degree_1092  1
    arc_1_15_16  in_degree_1099  1
    arc_1_15_16  original_T_including_depot_unload_1131  2.0838401346783280e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_16  arc_capacity_925  1
    load_1_15_16  free_load_conservation_1097  1
    load_1_15_16  free_load_conservation_1103  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_17  arc_capacity_927  -25
    arc_1_15_17  connected_order_arc_928  -13
    arc_1_15_17  out_degree_1092  1
    arc_1_15_17  in_degree_1105  1
    arc_1_15_17  original_T_including_depot_unload_1131  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_17  arc_capacity_927  1
    load_1_15_17  free_load_conservation_1097  1
    load_1_15_17  free_load_conservation_1109  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_18  arc_capacity_929  -25
    arc_1_15_18  connected_order_arc_930  -13
    arc_1_15_18  out_degree_1092  1
    arc_1_15_18  in_degree_1111  1
    arc_1_15_18  original_T_including_depot_unload_1131  1.9520133700471852e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_18  arc_capacity_929  1
    load_1_15_18  free_load_conservation_1097  1
    load_1_15_18  free_load_conservation_1115  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_19  arc_capacity_931  -25
    arc_1_15_19  connected_order_arc_932  -13
    arc_1_15_19  out_degree_1092  1
    arc_1_15_19  in_degree_1117  1
    arc_1_15_19  original_T_including_depot_unload_1131  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_1_15_19  arc_capacity_931  1
    load_1_15_19  free_load_conservation_1097  1
    load_1_15_19  free_load_conservation_1121  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_20  arc_capacity_933  -25
    arc_1_15_20  connected_order_arc_934  -13
    arc_1_15_20  out_degree_1092  1
    arc_1_15_20  in_degree_1123  1
    arc_1_15_20  original_T_including_depot_unload_1131  2.2299340442558691e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_20  arc_capacity_933  1
    load_1_15_20  free_load_conservation_1097  1
    load_1_15_20  free_load_conservation_1127  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_0  arc_capacity_935  -25
    arc_1_16_0  depot_return_or_bypass_1051  1
    arc_1_16_0  out_degree_1098  1
    arc_1_16_0  original_T_including_depot_unload_1131  6.2904707403788154e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_0  arc_capacity_935  1
    load_1_16_0  free_load_conservation_1103  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_6  arc_capacity_936  -25
    arc_1_16_6  connected_order_arc_937  -13
    arc_1_16_6  in_degree_1053  1
    arc_1_16_6  out_degree_1098  1
    arc_1_16_6  original_T_including_depot_unload_1131  1.5956325928039730e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_6  arc_capacity_936  1
    load_1_16_6  segment_load_conservation_1056  -1
    load_1_16_6  segment_prefix_lb_1057  1
    load_1_16_6  segment_prefix_ub_1058  1
    load_1_16_6  free_load_conservation_1103  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_7  arc_capacity_938  -25
    arc_1_16_7  connected_order_arc_939  -13
    arc_1_16_7  in_degree_1060  1
    arc_1_16_7  out_degree_1098  1
    arc_1_16_7  original_T_including_depot_unload_1131  8.9557394138123709e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_7  arc_capacity_938  1
    load_1_16_7  segment_load_conservation_1063  -1
    load_1_16_7  segment_prefix_lb_1064  1
    load_1_16_7  segment_prefix_ub_1065  1
    load_1_16_7  free_load_conservation_1103  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_8  arc_capacity_940  -25
    arc_1_16_8  connected_order_arc_941  -13
    arc_1_16_8  in_degree_1067  1
    arc_1_16_8  out_degree_1098  1
    arc_1_16_8  original_T_including_depot_unload_1131  3.4724611547105854e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_8  arc_capacity_940  1
    load_1_16_8  segment_load_conservation_1070  -1
    load_1_16_8  segment_prefix_lb_1071  1
    load_1_16_8  segment_prefix_ub_1072  1
    load_1_16_8  free_load_conservation_1103  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_9  arc_capacity_942  -25
    arc_1_16_9  connected_order_arc_943  -13
    arc_1_16_9  in_degree_1074  1
    arc_1_16_9  out_degree_1098  1
    arc_1_16_9  original_T_including_depot_unload_1131  5.7164184935040350e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_9  arc_capacity_942  1
    load_1_16_9  segment_load_conservation_1077  -1
    load_1_16_9  segment_prefix_lb_1078  1
    load_1_16_9  segment_prefix_ub_1079  1
    load_1_16_9  free_load_conservation_1103  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_13  arc_capacity_944  -25
    arc_1_16_13  connected_order_arc_945  -13
    arc_1_16_13  in_degree_1081  1
    arc_1_16_13  out_degree_1098  1
    arc_1_16_13  original_T_including_depot_unload_1131  3.5426413058949414e+01
    MARKER    'MARKER'                 'INTEND'
    load_1_16_13  arc_capacity_944  1
    load_1_16_13  free_load_conservation_1085  -1
    load_1_16_13  free_load_conservation_1103  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_14  arc_capacity_946  -25
    arc_1_16_14  connected_order_arc_947  -13
    arc_1_16_14  in_degree_1087  1
    arc_1_16_14  out_degree_1098  1
    arc_1_16_14  original_T_including_depot_unload_1131  6.1926694994249909e-01
    MARKER    'MARKER'                 'INTEND'
    load_1_16_14  arc_capacity_946  1
    load_1_16_14  free_load_conservation_1091  -1
    load_1_16_14  free_load_conservation_1103  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_15  arc_capacity_948  -25
    arc_1_16_15  connected_order_arc_949  -13
    arc_1_16_15  in_degree_1093  1
    arc_1_16_15  out_degree_1098  1
    arc_1_16_15  original_T_including_depot_unload_1131  2.0838401346783280e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_15  arc_capacity_948  1
    load_1_16_15  free_load_conservation_1097  -1
    load_1_16_15  free_load_conservation_1103  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_17  arc_capacity_950  -25
    arc_1_16_17  connected_order_arc_951  -13
    arc_1_16_17  out_degree_1098  1
    arc_1_16_17  in_degree_1105  1
    arc_1_16_17  original_T_including_depot_unload_1131  1.6310373065065476e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_17  arc_capacity_950  1
    load_1_16_17  free_load_conservation_1103  1
    load_1_16_17  free_load_conservation_1109  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_18  arc_capacity_952  -25
    arc_1_16_18  connected_order_arc_953  -13
    arc_1_16_18  out_degree_1098  1
    arc_1_16_18  in_degree_1111  1
    arc_1_16_18  original_T_including_depot_unload_1131  1.3208911608803092e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_18  arc_capacity_952  1
    load_1_16_18  free_load_conservation_1103  1
    load_1_16_18  free_load_conservation_1115  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_19  arc_capacity_954  -25
    arc_1_16_19  connected_order_arc_955  -13
    arc_1_16_19  out_degree_1098  1
    arc_1_16_19  in_degree_1117  1
    arc_1_16_19  original_T_including_depot_unload_1131  1.4489149558446036e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_19  arc_capacity_954  1
    load_1_16_19  free_load_conservation_1103  1
    load_1_16_19  free_load_conservation_1121  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_20  arc_capacity_956  -25
    arc_1_16_20  connected_order_arc_957  -13
    arc_1_16_20  out_degree_1098  1
    arc_1_16_20  in_degree_1123  1
    arc_1_16_20  original_T_including_depot_unload_1131  1.5460798335742169e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_20  arc_capacity_956  1
    load_1_16_20  free_load_conservation_1103  1
    load_1_16_20  free_load_conservation_1127  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_0  arc_capacity_958  -25
    arc_1_17_0  depot_return_or_bypass_1051  1
    arc_1_17_0  out_degree_1104  1
    arc_1_17_0  original_T_including_depot_unload_1131  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_0  arc_capacity_958  1
    load_1_17_0  free_load_conservation_1109  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_6  arc_capacity_959  -25
    arc_1_17_6  connected_order_arc_960  -13
    arc_1_17_6  in_degree_1053  1
    arc_1_17_6  out_degree_1104  1
    arc_1_17_6  original_T_including_depot_unload_1131  9.7453518552189382e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_6  arc_capacity_959  1
    load_1_17_6  segment_load_conservation_1056  -1
    load_1_17_6  segment_prefix_lb_1057  1
    load_1_17_6  segment_prefix_ub_1058  1
    load_1_17_6  free_load_conservation_1109  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_7  arc_capacity_961  -25
    arc_1_17_7  connected_order_arc_962  -13
    arc_1_17_7  in_degree_1060  1
    arc_1_17_7  out_degree_1104  1
    arc_1_17_7  original_T_including_depot_unload_1131  2.4321008933612479e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_7  arc_capacity_961  1
    load_1_17_7  segment_load_conservation_1063  -1
    load_1_17_7  segment_prefix_lb_1064  1
    load_1_17_7  segment_prefix_ub_1065  1
    load_1_17_7  free_load_conservation_1109  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_8  arc_capacity_963  -25
    arc_1_17_8  connected_order_arc_964  -13
    arc_1_17_8  in_degree_1067  1
    arc_1_17_8  out_degree_1104  1
    arc_1_17_8  original_T_including_depot_unload_1131  1.4586348268927468e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_8  arc_capacity_963  1
    load_1_17_8  segment_load_conservation_1070  -1
    load_1_17_8  segment_prefix_lb_1071  1
    load_1_17_8  segment_prefix_ub_1072  1
    load_1_17_8  free_load_conservation_1109  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_9  arc_capacity_965  -25
    arc_1_17_9  connected_order_arc_966  -13
    arc_1_17_9  in_degree_1074  1
    arc_1_17_9  out_degree_1104  1
    arc_1_17_9  original_T_including_depot_unload_1131  1.1561945146971345e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_9  arc_capacity_965  1
    load_1_17_9  segment_load_conservation_1077  -1
    load_1_17_9  segment_prefix_lb_1078  1
    load_1_17_9  segment_prefix_ub_1079  1
    load_1_17_9  free_load_conservation_1109  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_13  arc_capacity_967  -25
    arc_1_17_13  connected_order_arc_968  -13
    arc_1_17_13  in_degree_1081  1
    arc_1_17_13  out_degree_1104  1
    arc_1_17_13  original_T_including_depot_unload_1131  1.6472719129023171e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_13  arc_capacity_967  1
    load_1_17_13  free_load_conservation_1085  -1
    load_1_17_13  free_load_conservation_1109  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_14  arc_capacity_969  -25
    arc_1_17_14  connected_order_arc_970  -13
    arc_1_17_14  in_degree_1087  1
    arc_1_17_14  out_degree_1104  1
    arc_1_17_14  original_T_including_depot_unload_1131  1.6305450534190286e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_14  arc_capacity_969  1
    load_1_17_14  free_load_conservation_1091  -1
    load_1_17_14  free_load_conservation_1109  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_15  arc_capacity_971  -25
    arc_1_17_15  connected_order_arc_972  -13
    arc_1_17_15  in_degree_1093  1
    arc_1_17_15  out_degree_1104  1
    arc_1_17_15  original_T_including_depot_unload_1131  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_15  arc_capacity_971  1
    load_1_17_15  free_load_conservation_1097  -1
    load_1_17_15  free_load_conservation_1109  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_16  arc_capacity_973  -25
    arc_1_17_16  connected_order_arc_974  -13
    arc_1_17_16  in_degree_1099  1
    arc_1_17_16  out_degree_1104  1
    arc_1_17_16  original_T_including_depot_unload_1131  1.6310373065065476e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_16  arc_capacity_973  1
    load_1_17_16  free_load_conservation_1103  -1
    load_1_17_16  free_load_conservation_1109  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_18  arc_capacity_975  -25
    arc_1_17_18  connected_order_arc_976  -13
    arc_1_17_18  out_degree_1104  1
    arc_1_17_18  in_degree_1111  1
    arc_1_17_18  original_T_including_depot_unload_1131  1.5297878372821015e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_18  arc_capacity_975  1
    load_1_17_18  free_load_conservation_1109  1
    load_1_17_18  free_load_conservation_1115  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_19  arc_capacity_977  -25
    arc_1_17_19  connected_order_arc_978  -13
    arc_1_17_19  out_degree_1104  1
    arc_1_17_19  in_degree_1117  1
    arc_1_17_19  original_T_including_depot_unload_1131  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_19  arc_capacity_977  1
    load_1_17_19  free_load_conservation_1109  1
    load_1_17_19  free_load_conservation_1121  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_20  arc_capacity_979  -25
    arc_1_17_20  connected_order_arc_980  -13
    arc_1_17_20  out_degree_1104  1
    arc_1_17_20  in_degree_1123  1
    arc_1_17_20  original_T_including_depot_unload_1131  1.7807233899807140e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_20  arc_capacity_979  1
    load_1_17_20  free_load_conservation_1109  1
    load_1_17_20  free_load_conservation_1127  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_0  arc_capacity_981  -25
    arc_1_18_0  depot_return_or_bypass_1051  1
    arc_1_18_0  out_degree_1110  1
    arc_1_18_0  original_T_including_depot_unload_1131  5.2273830510106120e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_0  arc_capacity_981  1
    load_1_18_0  free_load_conservation_1115  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_6  arc_capacity_982  -25
    arc_1_18_6  connected_order_arc_983  -13
    arc_1_18_6  in_degree_1053  1
    arc_1_18_6  out_degree_1110  1
    arc_1_18_6  original_T_including_depot_unload_1131  1.5634365646683834e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_6  arc_capacity_982  1
    load_1_18_6  segment_load_conservation_1056  -1
    load_1_18_6  segment_prefix_lb_1057  1
    load_1_18_6  segment_prefix_ub_1058  1
    load_1_18_6  free_load_conservation_1115  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_7  arc_capacity_984  -25
    arc_1_18_7  connected_order_arc_985  -13
    arc_1_18_7  in_degree_1060  1
    arc_1_18_7  out_degree_1110  1
    arc_1_18_7  original_T_including_depot_unload_1131  1.0271253855277889e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_7  arc_capacity_984  1
    load_1_18_7  segment_load_conservation_1063  -1
    load_1_18_7  segment_prefix_lb_1064  1
    load_1_18_7  segment_prefix_ub_1065  1
    load_1_18_7  free_load_conservation_1115  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_8  arc_capacity_986  -25
    arc_1_18_8  connected_order_arc_987  -13
    arc_1_18_8  in_degree_1067  1
    arc_1_18_8  out_degree_1110  1
    arc_1_18_8  original_T_including_depot_unload_1131  3.7840168155842611e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_8  arc_capacity_986  1
    load_1_18_8  segment_load_conservation_1070  -1
    load_1_18_8  segment_prefix_lb_1071  1
    load_1_18_8  segment_prefix_ub_1072  1
    load_1_18_8  free_load_conservation_1115  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_9  arc_capacity_988  -25
    arc_1_18_9  connected_order_arc_989  -13
    arc_1_18_9  in_degree_1074  1
    arc_1_18_9  out_degree_1110  1
    arc_1_18_9  original_T_including_depot_unload_1131  5.3222543932043470e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_9  arc_capacity_988  1
    load_1_18_9  segment_load_conservation_1077  -1
    load_1_18_9  segment_prefix_lb_1078  1
    load_1_18_9  segment_prefix_ub_1079  1
    load_1_18_9  free_load_conservation_1115  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_13  arc_capacity_990  -25
    arc_1_18_13  connected_order_arc_991  -13
    arc_1_18_13  in_degree_1081  1
    arc_1_18_13  out_degree_1110  1
    arc_1_18_13  original_T_including_depot_unload_1131  1.2962070286822930e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_13  arc_capacity_990  1
    load_1_18_13  free_load_conservation_1085  -1
    load_1_18_13  free_load_conservation_1115  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_14  arc_capacity_992  -25
    arc_1_18_14  connected_order_arc_993  -13
    arc_1_18_14  in_degree_1087  1
    arc_1_18_14  out_degree_1110  1
    arc_1_18_14  original_T_including_depot_unload_1131  1.3146996282072985e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_14  arc_capacity_992  1
    load_1_18_14  free_load_conservation_1091  -1
    load_1_18_14  free_load_conservation_1115  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_15  arc_capacity_994  -25
    arc_1_18_15  connected_order_arc_995  -13
    arc_1_18_15  in_degree_1093  1
    arc_1_18_15  out_degree_1110  1
    arc_1_18_15  original_T_including_depot_unload_1131  1.9520133700471852e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_15  arc_capacity_994  1
    load_1_18_15  free_load_conservation_1097  -1
    load_1_18_15  free_load_conservation_1115  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_16  arc_capacity_996  -25
    arc_1_18_16  connected_order_arc_997  -13
    arc_1_18_16  in_degree_1099  1
    arc_1_18_16  out_degree_1110  1
    arc_1_18_16  original_T_including_depot_unload_1131  1.3208911608803092e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_16  arc_capacity_996  1
    load_1_18_16  free_load_conservation_1103  -1
    load_1_18_16  free_load_conservation_1115  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_17  arc_capacity_998  -25
    arc_1_18_17  connected_order_arc_999  -13
    arc_1_18_17  in_degree_1105  1
    arc_1_18_17  out_degree_1110  1
    arc_1_18_17  original_T_including_depot_unload_1131  1.5297878372821015e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_17  arc_capacity_998  1
    load_1_18_17  free_load_conservation_1109  -1
    load_1_18_17  free_load_conservation_1115  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_19  arc_capacity_1000  -25
    arc_1_18_19  connected_order_arc_1001  -13
    arc_1_18_19  out_degree_1110  1
    arc_1_18_19  in_degree_1117  1
    arc_1_18_19  original_T_including_depot_unload_1131  1.3176071585703125e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_19  arc_capacity_1000  1
    load_1_18_19  free_load_conservation_1115  1
    load_1_18_19  free_load_conservation_1121  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_20  arc_capacity_1002  -25
    arc_1_18_20  connected_order_arc_1003  -13
    arc_1_18_20  out_degree_1110  1
    arc_1_18_20  in_degree_1123  1
    arc_1_18_20  original_T_including_depot_unload_1131  2.8083660458664087e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_20  arc_capacity_1002  1
    load_1_18_20  free_load_conservation_1115  1
    load_1_18_20  free_load_conservation_1127  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_0  arc_capacity_1004  -25
    arc_1_19_0  depot_return_or_bypass_1051  1
    arc_1_19_0  out_degree_1116  1
    arc_1_19_0  original_T_including_depot_unload_1131  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_0  arc_capacity_1004  1
    load_1_19_0  free_load_conservation_1121  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_6  arc_capacity_1005  -25
    arc_1_19_6  connected_order_arc_1006  -13
    arc_1_19_6  in_degree_1053  1
    arc_1_19_6  out_degree_1116  1
    arc_1_19_6  original_T_including_depot_unload_1131  1.6988291947636669e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_6  arc_capacity_1005  1
    load_1_19_6  segment_load_conservation_1056  -1
    load_1_19_6  segment_prefix_lb_1057  1
    load_1_19_6  segment_prefix_ub_1058  1
    load_1_19_6  free_load_conservation_1121  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_7  arc_capacity_1007  -25
    arc_1_19_7  connected_order_arc_1008  -13
    arc_1_19_7  in_degree_1060  1
    arc_1_19_7  out_degree_1116  1
    arc_1_19_7  original_T_including_depot_unload_1131  2.3444750474890211e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_7  arc_capacity_1007  1
    load_1_19_7  segment_load_conservation_1063  -1
    load_1_19_7  segment_prefix_lb_1064  1
    load_1_19_7  segment_prefix_ub_1065  1
    load_1_19_7  free_load_conservation_1121  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_8  arc_capacity_1009  -25
    arc_1_19_8  connected_order_arc_1010  -13
    arc_1_19_8  in_degree_1067  1
    arc_1_19_8  out_degree_1116  1
    arc_1_19_8  original_T_including_depot_unload_1131  1.4738339199468992e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_8  arc_capacity_1009  1
    load_1_19_8  segment_load_conservation_1070  -1
    load_1_19_8  segment_prefix_lb_1071  1
    load_1_19_8  segment_prefix_ub_1072  1
    load_1_19_8  free_load_conservation_1121  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_9  arc_capacity_1011  -25
    arc_1_19_9  connected_order_arc_1012  -13
    arc_1_19_9  in_degree_1074  1
    arc_1_19_9  out_degree_1116  1
    arc_1_19_9  original_T_including_depot_unload_1131  1.2665309635243570e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_9  arc_capacity_1011  1
    load_1_19_9  segment_load_conservation_1077  -1
    load_1_19_9  segment_prefix_lb_1078  1
    load_1_19_9  segment_prefix_ub_1079  1
    load_1_19_9  free_load_conservation_1121  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_13  arc_capacity_1013  -25
    arc_1_19_13  connected_order_arc_1014  -13
    arc_1_19_13  in_degree_1081  1
    arc_1_19_13  out_degree_1116  1
    arc_1_19_13  original_T_including_depot_unload_1131  1.4457797980495495e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_13  arc_capacity_1013  1
    load_1_19_13  free_load_conservation_1085  -1
    load_1_19_13  free_load_conservation_1121  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_14  arc_capacity_1015  -25
    arc_1_19_14  connected_order_arc_1016  -13
    arc_1_19_14  in_degree_1087  1
    arc_1_19_14  out_degree_1116  1
    arc_1_19_14  original_T_including_depot_unload_1131  1.4482979064849126e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_14  arc_capacity_1015  1
    load_1_19_14  free_load_conservation_1091  -1
    load_1_19_14  free_load_conservation_1121  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_15  arc_capacity_1017  -25
    arc_1_19_15  connected_order_arc_1018  -13
    arc_1_19_15  in_degree_1093  1
    arc_1_19_15  out_degree_1116  1
    arc_1_19_15  original_T_including_depot_unload_1131  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_1_19_15  arc_capacity_1017  1
    load_1_19_15  free_load_conservation_1097  -1
    load_1_19_15  free_load_conservation_1121  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_16  arc_capacity_1019  -25
    arc_1_19_16  connected_order_arc_1020  -13
    arc_1_19_16  in_degree_1099  1
    arc_1_19_16  out_degree_1116  1
    arc_1_19_16  original_T_including_depot_unload_1131  1.4489149558446036e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_16  arc_capacity_1019  1
    load_1_19_16  free_load_conservation_1103  -1
    load_1_19_16  free_load_conservation_1121  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_17  arc_capacity_1021  -25
    arc_1_19_17  connected_order_arc_1022  -13
    arc_1_19_17  in_degree_1105  1
    arc_1_19_17  out_degree_1116  1
    arc_1_19_17  original_T_including_depot_unload_1131  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_17  arc_capacity_1021  1
    load_1_19_17  free_load_conservation_1109  -1
    load_1_19_17  free_load_conservation_1121  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_18  arc_capacity_1023  -25
    arc_1_19_18  connected_order_arc_1024  -13
    arc_1_19_18  in_degree_1111  1
    arc_1_19_18  out_degree_1116  1
    arc_1_19_18  original_T_including_depot_unload_1131  1.3176071585703125e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_18  arc_capacity_1023  1
    load_1_19_18  free_load_conservation_1115  -1
    load_1_19_18  free_load_conservation_1121  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_20  arc_capacity_1025  -25
    arc_1_19_20  connected_order_arc_1026  -13
    arc_1_19_20  out_degree_1116  1
    arc_1_19_20  in_degree_1123  1
    arc_1_19_20  original_T_including_depot_unload_1131  1.5971628811503840e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_20  arc_capacity_1025  1
    load_1_19_20  free_load_conservation_1121  1
    load_1_19_20  free_load_conservation_1127  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_0  arc_capacity_1027  -25
    arc_1_20_0  depot_return_or_bypass_1051  1
    arc_1_20_0  out_degree_1122  1
    arc_1_20_0  original_T_including_depot_unload_1131  7.8199183337763486e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_0  arc_capacity_1027  1
    load_1_20_0  free_load_conservation_1127  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_6  arc_capacity_1028  -25
    arc_1_20_6  connected_order_arc_1029  -13
    arc_1_20_6  in_degree_1053  1
    arc_1_20_6  out_degree_1122  1
    arc_1_20_6  original_T_including_depot_unload_1131  1.6985664713248598e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_6  arc_capacity_1028  1
    load_1_20_6  segment_load_conservation_1056  -1
    load_1_20_6  segment_prefix_lb_1057  1
    load_1_20_6  segment_prefix_ub_1058  1
    load_1_20_6  free_load_conservation_1127  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_7  arc_capacity_1030  -25
    arc_1_20_7  connected_order_arc_1031  -13
    arc_1_20_7  in_degree_1060  1
    arc_1_20_7  out_degree_1122  1
    arc_1_20_7  original_T_including_depot_unload_1131  7.4980220943945562e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_7  arc_capacity_1030  1
    load_1_20_7  segment_load_conservation_1063  -1
    load_1_20_7  segment_prefix_lb_1064  1
    load_1_20_7  segment_prefix_ub_1065  1
    load_1_20_7  free_load_conservation_1127  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_8  arc_capacity_1032  -25
    arc_1_20_8  connected_order_arc_1033  -13
    arc_1_20_8  in_degree_1067  1
    arc_1_20_8  out_degree_1122  1
    arc_1_20_8  original_T_including_depot_unload_1131  4.2580398435897172e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_8  arc_capacity_1032  1
    load_1_20_8  segment_load_conservation_1070  -1
    load_1_20_8  segment_prefix_lb_1071  1
    load_1_20_8  segment_prefix_ub_1072  1
    load_1_20_8  free_load_conservation_1127  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_9  arc_capacity_1034  -25
    arc_1_20_9  connected_order_arc_1035  -13
    arc_1_20_9  in_degree_1074  1
    arc_1_20_9  out_degree_1122  1
    arc_1_20_9  original_T_including_depot_unload_1131  6.9292160543761986e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_9  arc_capacity_1034  1
    load_1_20_9  segment_load_conservation_1077  -1
    load_1_20_9  segment_prefix_lb_1078  1
    load_1_20_9  segment_prefix_ub_1079  1
    load_1_20_9  free_load_conservation_1127  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_13  arc_capacity_1036  -25
    arc_1_20_13  connected_order_arc_1037  -13
    arc_1_20_13  in_degree_1081  1
    arc_1_20_13  out_degree_1122  1
    arc_1_20_13  original_T_including_depot_unload_1131  1.5153540246292351e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_13  arc_capacity_1036  1
    load_1_20_13  free_load_conservation_1085  -1
    load_1_20_13  free_load_conservation_1127  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_14  arc_capacity_1038  -25
    arc_1_20_14  connected_order_arc_1039  -13
    arc_1_20_14  in_degree_1087  1
    arc_1_20_14  out_degree_1122  1
    arc_1_20_14  original_T_including_depot_unload_1131  1.5518157315724611e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_14  arc_capacity_1038  1
    load_1_20_14  free_load_conservation_1091  -1
    load_1_20_14  free_load_conservation_1127  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_15  arc_capacity_1040  -25
    arc_1_20_15  connected_order_arc_1041  -13
    arc_1_20_15  in_degree_1093  1
    arc_1_20_15  out_degree_1122  1
    arc_1_20_15  original_T_including_depot_unload_1131  2.2299340442558691e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_15  arc_capacity_1040  1
    load_1_20_15  free_load_conservation_1097  -1
    load_1_20_15  free_load_conservation_1127  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_16  arc_capacity_1042  -25
    arc_1_20_16  connected_order_arc_1043  -13
    arc_1_20_16  in_degree_1099  1
    arc_1_20_16  out_degree_1122  1
    arc_1_20_16  original_T_including_depot_unload_1131  1.5460798335742169e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_16  arc_capacity_1042  1
    load_1_20_16  free_load_conservation_1103  -1
    load_1_20_16  free_load_conservation_1127  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_17  arc_capacity_1044  -25
    arc_1_20_17  connected_order_arc_1045  -13
    arc_1_20_17  in_degree_1105  1
    arc_1_20_17  out_degree_1122  1
    arc_1_20_17  original_T_including_depot_unload_1131  1.7807233899807140e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_17  arc_capacity_1044  1
    load_1_20_17  free_load_conservation_1109  -1
    load_1_20_17  free_load_conservation_1127  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_18  arc_capacity_1046  -25
    arc_1_20_18  connected_order_arc_1047  -13
    arc_1_20_18  in_degree_1111  1
    arc_1_20_18  out_degree_1122  1
    arc_1_20_18  original_T_including_depot_unload_1131  2.8083660458664087e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_18  arc_capacity_1046  1
    load_1_20_18  free_load_conservation_1115  -1
    load_1_20_18  free_load_conservation_1127  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_19  arc_capacity_1048  -25
    arc_1_20_19  connected_order_arc_1049  -13
    arc_1_20_19  in_degree_1117  1
    arc_1_20_19  out_degree_1122  1
    arc_1_20_19  original_T_including_depot_unload_1131  1.5971628811503840e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_19  arc_capacity_1048  1
    load_1_20_19  free_load_conservation_1121  -1
    load_1_20_19  free_load_conservation_1127  1
    visit_2_10  out_degree_1377  -1
    visit_2_10  in_degree_1378  -1
    visit_2_10  order_active_lb_1379  -1
    visit_2_10  order_active_ub_1380  -11
    order_2_10  connected_order_arc_1146  -1
    order_2_10  connected_order_arc_1148  -1
    order_2_10  connected_order_arc_1150  -1
    order_2_10  connected_order_arc_1152  -1
    order_2_10  connected_order_arc_1154  -1
    order_2_10  connected_order_arc_1156  -1
    order_2_10  connected_order_arc_1158  -1
    order_2_10  connected_order_arc_1160  -1
    order_2_10  connected_order_arc_1162  -1
    order_2_10  connected_order_arc_1164  -1
    order_2_10  connected_order_arc_1167  1
    order_2_10  connected_order_arc_1188  1
    order_2_10  connected_order_arc_1209  1
    order_2_10  connected_order_arc_1230  1
    order_2_10  connected_order_arc_1251  1
    order_2_10  connected_order_arc_1272  1
    order_2_10  connected_order_arc_1293  1
    order_2_10  connected_order_arc_1314  1
    order_2_10  connected_order_arc_1335  1
    order_2_10  connected_order_arc_1356  1
    order_2_10  order_active_lb_1379  1
    order_2_10  order_active_ub_1380  1
    order_2_10  fixed_segment_relative_order_1446  -1
    visit_2_11  out_degree_1384  -1
    visit_2_11  in_degree_1385  -1
    visit_2_11  order_active_lb_1386  -1
    visit_2_11  order_active_ub_1387  -11
    order_2_11  connected_order_arc_1146  1
    order_2_11  connected_order_arc_1167  -1
    order_2_11  connected_order_arc_1169  -1
    order_2_11  connected_order_arc_1171  -1
    order_2_11  connected_order_arc_1173  -1
    order_2_11  connected_order_arc_1175  -1
    order_2_11  connected_order_arc_1177  -1
    order_2_11  connected_order_arc_1179  -1
    order_2_11  connected_order_arc_1181  -1
    order_2_11  connected_order_arc_1183  -1
    order_2_11  connected_order_arc_1185  -1
    order_2_11  connected_order_arc_1190  1
    order_2_11  connected_order_arc_1211  1
    order_2_11  connected_order_arc_1232  1
    order_2_11  connected_order_arc_1253  1
    order_2_11  connected_order_arc_1274  1
    order_2_11  connected_order_arc_1295  1
    order_2_11  connected_order_arc_1316  1
    order_2_11  connected_order_arc_1337  1
    order_2_11  connected_order_arc_1358  1
    order_2_11  order_active_lb_1386  1
    order_2_11  order_active_ub_1387  1
    order_2_11  fixed_segment_relative_order_1446  1
    order_2_11  fixed_segment_relative_order_1447  -1
    visit_2_12  out_degree_1391  -1
    visit_2_12  in_degree_1392  -1
    visit_2_12  order_active_lb_1393  -1
    visit_2_12  order_active_ub_1394  -11
    order_2_12  connected_order_arc_1148  1
    order_2_12  connected_order_arc_1169  1
    order_2_12  connected_order_arc_1188  -1
    order_2_12  connected_order_arc_1190  -1
    order_2_12  connected_order_arc_1192  -1
    order_2_12  connected_order_arc_1194  -1
    order_2_12  connected_order_arc_1196  -1
    order_2_12  connected_order_arc_1198  -1
    order_2_12  connected_order_arc_1200  -1
    order_2_12  connected_order_arc_1202  -1
    order_2_12  connected_order_arc_1204  -1
    order_2_12  connected_order_arc_1206  -1
    order_2_12  connected_order_arc_1213  1
    order_2_12  connected_order_arc_1234  1
    order_2_12  connected_order_arc_1255  1
    order_2_12  connected_order_arc_1276  1
    order_2_12  connected_order_arc_1297  1
    order_2_12  connected_order_arc_1318  1
    order_2_12  connected_order_arc_1339  1
    order_2_12  connected_order_arc_1360  1
    order_2_12  order_active_lb_1393  1
    order_2_12  order_active_ub_1394  1
    order_2_12  fixed_segment_relative_order_1447  1
    visit_2_13  out_degree_1398  -1
    visit_2_13  in_degree_1399  -1
    visit_2_13  order_active_lb_1400  -1
    visit_2_13  order_active_ub_1401  -11
    visit_2_13  service_visit_def_1402  -1
    order_2_13  connected_order_arc_1150  1
    order_2_13  connected_order_arc_1171  1
    order_2_13  connected_order_arc_1192  1
    order_2_13  connected_order_arc_1209  -1
    order_2_13  connected_order_arc_1211  -1
    order_2_13  connected_order_arc_1213  -1
    order_2_13  connected_order_arc_1215  -1
    order_2_13  connected_order_arc_1217  -1
    order_2_13  connected_order_arc_1219  -1
    order_2_13  connected_order_arc_1221  -1
    order_2_13  connected_order_arc_1223  -1
    order_2_13  connected_order_arc_1225  -1
    order_2_13  connected_order_arc_1227  -1
    order_2_13  connected_order_arc_1236  1
    order_2_13  connected_order_arc_1257  1
    order_2_13  connected_order_arc_1278  1
    order_2_13  connected_order_arc_1299  1
    order_2_13  connected_order_arc_1320  1
    order_2_13  connected_order_arc_1341  1
    order_2_13  connected_order_arc_1362  1
    order_2_13  order_active_lb_1400  1
    order_2_13  order_active_ub_1401  1
    visit_2_14  out_degree_1404  -1
    visit_2_14  in_degree_1405  -1
    visit_2_14  order_active_lb_1406  -1
    visit_2_14  order_active_ub_1407  -11
    visit_2_14  service_visit_def_1408  -1
    order_2_14  connected_order_arc_1152  1
    order_2_14  connected_order_arc_1173  1
    order_2_14  connected_order_arc_1194  1
    order_2_14  connected_order_arc_1215  1
    order_2_14  connected_order_arc_1230  -1
    order_2_14  connected_order_arc_1232  -1
    order_2_14  connected_order_arc_1234  -1
    order_2_14  connected_order_arc_1236  -1
    order_2_14  connected_order_arc_1238  -1
    order_2_14  connected_order_arc_1240  -1
    order_2_14  connected_order_arc_1242  -1
    order_2_14  connected_order_arc_1244  -1
    order_2_14  connected_order_arc_1246  -1
    order_2_14  connected_order_arc_1248  -1
    order_2_14  connected_order_arc_1259  1
    order_2_14  connected_order_arc_1280  1
    order_2_14  connected_order_arc_1301  1
    order_2_14  connected_order_arc_1322  1
    order_2_14  connected_order_arc_1343  1
    order_2_14  connected_order_arc_1364  1
    order_2_14  order_active_lb_1406  1
    order_2_14  order_active_ub_1407  1
    visit_2_15  out_degree_1410  -1
    visit_2_15  in_degree_1411  -1
    visit_2_15  order_active_lb_1412  -1
    visit_2_15  order_active_ub_1413  -11
    visit_2_15  service_visit_def_1414  -1
    order_2_15  connected_order_arc_1154  1
    order_2_15  connected_order_arc_1175  1
    order_2_15  connected_order_arc_1196  1
    order_2_15  connected_order_arc_1217  1
    order_2_15  connected_order_arc_1238  1
    order_2_15  connected_order_arc_1251  -1
    order_2_15  connected_order_arc_1253  -1
    order_2_15  connected_order_arc_1255  -1
    order_2_15  connected_order_arc_1257  -1
    order_2_15  connected_order_arc_1259  -1
    order_2_15  connected_order_arc_1261  -1
    order_2_15  connected_order_arc_1263  -1
    order_2_15  connected_order_arc_1265  -1
    order_2_15  connected_order_arc_1267  -1
    order_2_15  connected_order_arc_1269  -1
    order_2_15  connected_order_arc_1282  1
    order_2_15  connected_order_arc_1303  1
    order_2_15  connected_order_arc_1324  1
    order_2_15  connected_order_arc_1345  1
    order_2_15  connected_order_arc_1366  1
    order_2_15  order_active_lb_1412  1
    order_2_15  order_active_ub_1413  1
    visit_2_16  out_degree_1416  -1
    visit_2_16  in_degree_1417  -1
    visit_2_16  order_active_lb_1418  -1
    visit_2_16  order_active_ub_1419  -11
    visit_2_16  service_visit_def_1420  -1
    order_2_16  connected_order_arc_1156  1
    order_2_16  connected_order_arc_1177  1
    order_2_16  connected_order_arc_1198  1
    order_2_16  connected_order_arc_1219  1
    order_2_16  connected_order_arc_1240  1
    order_2_16  connected_order_arc_1261  1
    order_2_16  connected_order_arc_1272  -1
    order_2_16  connected_order_arc_1274  -1
    order_2_16  connected_order_arc_1276  -1
    order_2_16  connected_order_arc_1278  -1
    order_2_16  connected_order_arc_1280  -1
    order_2_16  connected_order_arc_1282  -1
    order_2_16  connected_order_arc_1284  -1
    order_2_16  connected_order_arc_1286  -1
    order_2_16  connected_order_arc_1288  -1
    order_2_16  connected_order_arc_1290  -1
    order_2_16  connected_order_arc_1305  1
    order_2_16  connected_order_arc_1326  1
    order_2_16  connected_order_arc_1347  1
    order_2_16  connected_order_arc_1368  1
    order_2_16  order_active_lb_1418  1
    order_2_16  order_active_ub_1419  1
    visit_2_17  out_degree_1422  -1
    visit_2_17  in_degree_1423  -1
    visit_2_17  order_active_lb_1424  -1
    visit_2_17  order_active_ub_1425  -11
    visit_2_17  service_visit_def_1426  -1
    order_2_17  connected_order_arc_1158  1
    order_2_17  connected_order_arc_1179  1
    order_2_17  connected_order_arc_1200  1
    order_2_17  connected_order_arc_1221  1
    order_2_17  connected_order_arc_1242  1
    order_2_17  connected_order_arc_1263  1
    order_2_17  connected_order_arc_1284  1
    order_2_17  connected_order_arc_1293  -1
    order_2_17  connected_order_arc_1295  -1
    order_2_17  connected_order_arc_1297  -1
    order_2_17  connected_order_arc_1299  -1
    order_2_17  connected_order_arc_1301  -1
    order_2_17  connected_order_arc_1303  -1
    order_2_17  connected_order_arc_1305  -1
    order_2_17  connected_order_arc_1307  -1
    order_2_17  connected_order_arc_1309  -1
    order_2_17  connected_order_arc_1311  -1
    order_2_17  connected_order_arc_1328  1
    order_2_17  connected_order_arc_1349  1
    order_2_17  connected_order_arc_1370  1
    order_2_17  order_active_lb_1424  1
    order_2_17  order_active_ub_1425  1
    visit_2_18  out_degree_1428  -1
    visit_2_18  in_degree_1429  -1
    visit_2_18  order_active_lb_1430  -1
    visit_2_18  order_active_ub_1431  -11
    visit_2_18  service_visit_def_1432  -1
    order_2_18  connected_order_arc_1160  1
    order_2_18  connected_order_arc_1181  1
    order_2_18  connected_order_arc_1202  1
    order_2_18  connected_order_arc_1223  1
    order_2_18  connected_order_arc_1244  1
    order_2_18  connected_order_arc_1265  1
    order_2_18  connected_order_arc_1286  1
    order_2_18  connected_order_arc_1307  1
    order_2_18  connected_order_arc_1314  -1
    order_2_18  connected_order_arc_1316  -1
    order_2_18  connected_order_arc_1318  -1
    order_2_18  connected_order_arc_1320  -1
    order_2_18  connected_order_arc_1322  -1
    order_2_18  connected_order_arc_1324  -1
    order_2_18  connected_order_arc_1326  -1
    order_2_18  connected_order_arc_1328  -1
    order_2_18  connected_order_arc_1330  -1
    order_2_18  connected_order_arc_1332  -1
    order_2_18  connected_order_arc_1351  1
    order_2_18  connected_order_arc_1372  1
    order_2_18  order_active_lb_1430  1
    order_2_18  order_active_ub_1431  1
    visit_2_19  out_degree_1434  -1
    visit_2_19  in_degree_1435  -1
    visit_2_19  order_active_lb_1436  -1
    visit_2_19  order_active_ub_1437  -11
    visit_2_19  service_visit_def_1438  -1
    order_2_19  connected_order_arc_1162  1
    order_2_19  connected_order_arc_1183  1
    order_2_19  connected_order_arc_1204  1
    order_2_19  connected_order_arc_1225  1
    order_2_19  connected_order_arc_1246  1
    order_2_19  connected_order_arc_1267  1
    order_2_19  connected_order_arc_1288  1
    order_2_19  connected_order_arc_1309  1
    order_2_19  connected_order_arc_1330  1
    order_2_19  connected_order_arc_1335  -1
    order_2_19  connected_order_arc_1337  -1
    order_2_19  connected_order_arc_1339  -1
    order_2_19  connected_order_arc_1341  -1
    order_2_19  connected_order_arc_1343  -1
    order_2_19  connected_order_arc_1345  -1
    order_2_19  connected_order_arc_1347  -1
    order_2_19  connected_order_arc_1349  -1
    order_2_19  connected_order_arc_1351  -1
    order_2_19  connected_order_arc_1353  -1
    order_2_19  connected_order_arc_1374  1
    order_2_19  order_active_lb_1436  1
    order_2_19  order_active_ub_1437  1
    visit_2_20  out_degree_1440  -1
    visit_2_20  in_degree_1441  -1
    visit_2_20  order_active_lb_1442  -1
    visit_2_20  order_active_ub_1443  -11
    visit_2_20  service_visit_def_1444  -1
    order_2_20  connected_order_arc_1164  1
    order_2_20  connected_order_arc_1185  1
    order_2_20  connected_order_arc_1206  1
    order_2_20  connected_order_arc_1227  1
    order_2_20  connected_order_arc_1248  1
    order_2_20  connected_order_arc_1269  1
    order_2_20  connected_order_arc_1290  1
    order_2_20  connected_order_arc_1311  1
    order_2_20  connected_order_arc_1332  1
    order_2_20  connected_order_arc_1353  1
    order_2_20  connected_order_arc_1356  -1
    order_2_20  connected_order_arc_1358  -1
    order_2_20  connected_order_arc_1360  -1
    order_2_20  connected_order_arc_1362  -1
    order_2_20  connected_order_arc_1364  -1
    order_2_20  connected_order_arc_1366  -1
    order_2_20  connected_order_arc_1368  -1
    order_2_20  connected_order_arc_1370  -1
    order_2_20  connected_order_arc_1372  -1
    order_2_20  connected_order_arc_1374  -1
    order_2_20  order_active_lb_1442  1
    order_2_20  order_active_ub_1443  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_0  arc_capacity_1132  -30
    arc_2_0_0  depot_departure_or_bypass_1375  1
    arc_2_0_0  depot_return_or_bypass_1376  1
    MARKER    'MARKER'                 'INTEND'
    load_2_0_0  arc_capacity_1132  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_10  arc_capacity_1133  -30
    arc_2_0_10  depot_departure_or_bypass_1375  1
    arc_2_0_10  in_degree_1378  1
    arc_2_0_10  original_T_including_depot_unload_1448  7.9650294035968375e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_10  arc_capacity_1133  1
    load_2_0_10  segment_load_conservation_1381  -1
    load_2_0_10  segment_prefix_lb_1382  1
    load_2_0_10  segment_prefix_ub_1383  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_11  arc_capacity_1134  -30
    arc_2_0_11  depot_departure_or_bypass_1375  1
    arc_2_0_11  in_degree_1385  1
    arc_2_0_11  original_T_including_depot_unload_1448  1.4373810231417410e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_11  arc_capacity_1134  1
    load_2_0_11  segment_load_conservation_1388  -1
    load_2_0_11  segment_prefix_lb_1389  1
    load_2_0_11  segment_prefix_ub_1390  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_12  arc_capacity_1135  -30
    arc_2_0_12  depot_departure_or_bypass_1375  1
    arc_2_0_12  in_degree_1392  1
    arc_2_0_12  original_T_including_depot_unload_1448  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_12  arc_capacity_1135  1
    load_2_0_12  segment_load_conservation_1395  -1
    load_2_0_12  segment_prefix_lb_1396  1
    load_2_0_12  segment_prefix_ub_1397  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_13  arc_capacity_1136  -30
    arc_2_0_13  depot_departure_or_bypass_1375  1
    arc_2_0_13  in_degree_1399  1
    arc_2_0_13  original_T_including_depot_unload_1448  6.4256529461228865e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_13  arc_capacity_1136  1
    load_2_0_13  free_load_conservation_1403  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_14  arc_capacity_1137  -30
    arc_2_0_14  depot_departure_or_bypass_1375  1
    arc_2_0_14  in_degree_1405  1
    arc_2_0_14  original_T_including_depot_unload_1448  6.2851955830851955e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_14  arc_capacity_1137  1
    load_2_0_14  free_load_conservation_1409  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_15  arc_capacity_1138  -30
    arc_2_0_15  depot_departure_or_bypass_1375  1
    arc_2_0_15  in_degree_1411  1
    arc_2_0_15  original_T_including_depot_unload_1448  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_15  arc_capacity_1138  1
    load_2_0_15  free_load_conservation_1415  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_16  arc_capacity_1139  -30
    arc_2_0_16  depot_departure_or_bypass_1375  1
    arc_2_0_16  in_degree_1417  1
    arc_2_0_16  original_T_including_depot_unload_1448  6.2904707403788154e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_16  arc_capacity_1139  1
    load_2_0_16  free_load_conservation_1421  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_17  arc_capacity_1140  -30
    arc_2_0_17  depot_departure_or_bypass_1375  1
    arc_2_0_17  in_degree_1423  1
    arc_2_0_17  original_T_including_depot_unload_1448  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_17  arc_capacity_1140  1
    load_2_0_17  free_load_conservation_1427  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_18  arc_capacity_1141  -30
    arc_2_0_18  depot_departure_or_bypass_1375  1
    arc_2_0_18  in_degree_1429  1
    arc_2_0_18  original_T_including_depot_unload_1448  5.2273830510106120e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_18  arc_capacity_1141  1
    load_2_0_18  free_load_conservation_1433  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_19  arc_capacity_1142  -30
    arc_2_0_19  depot_departure_or_bypass_1375  1
    arc_2_0_19  in_degree_1435  1
    arc_2_0_19  original_T_including_depot_unload_1448  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_19  arc_capacity_1142  1
    load_2_0_19  free_load_conservation_1439  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_20  arc_capacity_1143  -30
    arc_2_0_20  depot_departure_or_bypass_1375  1
    arc_2_0_20  in_degree_1441  1
    arc_2_0_20  original_T_including_depot_unload_1448  7.8199183337763486e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_20  arc_capacity_1143  1
    load_2_0_20  free_load_conservation_1445  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_0  arc_capacity_1144  -30
    arc_2_10_0  depot_return_or_bypass_1376  1
    arc_2_10_0  out_degree_1377  1
    arc_2_10_0  original_T_including_depot_unload_1448  7.9650294035968375e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_0  arc_capacity_1144  1
    load_2_10_0  segment_load_conservation_1381  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_11  arc_capacity_1145  -30
    arc_2_10_11  connected_order_arc_1146  -12
    arc_2_10_11  out_degree_1377  1
    arc_2_10_11  in_degree_1385  1
    arc_2_10_11  original_T_including_depot_unload_1448  7.5681404708111961e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_11  arc_capacity_1145  1
    load_2_10_11  segment_load_conservation_1381  1
    load_2_10_11  segment_load_conservation_1388  -1
    load_2_10_11  segment_prefix_lb_1389  1
    load_2_10_11  segment_prefix_ub_1390  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_12  arc_capacity_1147  -30
    arc_2_10_12  connected_order_arc_1148  -12
    arc_2_10_12  out_degree_1377  1
    arc_2_10_12  in_degree_1392  1
    arc_2_10_12  original_T_including_depot_unload_1448  3.7831268047064754e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_12  arc_capacity_1147  1
    load_2_10_12  segment_load_conservation_1381  1
    load_2_10_12  segment_load_conservation_1395  -1
    load_2_10_12  segment_prefix_lb_1396  1
    load_2_10_12  segment_prefix_ub_1397  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_13  arc_capacity_1149  -30
    arc_2_10_13  connected_order_arc_1150  -12
    arc_2_10_13  out_degree_1377  1
    arc_2_10_13  in_degree_1399  1
    arc_2_10_13  original_T_including_depot_unload_1448  1.4316381888253884e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_13  arc_capacity_1149  1
    load_2_10_13  segment_load_conservation_1381  1
    load_2_10_13  free_load_conservation_1403  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_14  arc_capacity_1151  -30
    arc_2_10_14  connected_order_arc_1152  -12
    arc_2_10_14  out_degree_1377  1
    arc_2_10_14  in_degree_1405  1
    arc_2_10_14  original_T_including_depot_unload_1448  1.4208855669296320e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_14  arc_capacity_1151  1
    load_2_10_14  segment_load_conservation_1381  1
    load_2_10_14  free_load_conservation_1409  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_15  arc_capacity_1153  -30
    arc_2_10_15  connected_order_arc_1154  -12
    arc_2_10_15  out_degree_1377  1
    arc_2_10_15  in_degree_1411  1
    arc_2_10_15  original_T_including_depot_unload_1448  9.8108674361469946e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_15  arc_capacity_1153  1
    load_2_10_15  segment_load_conservation_1381  1
    load_2_10_15  free_load_conservation_1415  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_16  arc_capacity_1155  -30
    arc_2_10_16  connected_order_arc_1156  -12
    arc_2_10_16  out_degree_1377  1
    arc_2_10_16  in_degree_1417  1
    arc_2_10_16  original_T_including_depot_unload_1448  1.4214388997747180e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_16  arc_capacity_1155  1
    load_2_10_16  segment_load_conservation_1381  1
    load_2_10_16  free_load_conservation_1421  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_17  arc_capacity_1157  -30
    arc_2_10_17  connected_order_arc_1158  -12
    arc_2_10_17  out_degree_1377  1
    arc_2_10_17  in_degree_1423  1
    arc_2_10_17  original_T_including_depot_unload_1448  3.5235932354279930e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_17  arc_capacity_1157  1
    load_2_10_17  segment_load_conservation_1381  1
    load_2_10_17  free_load_conservation_1427  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_18  arc_capacity_1159  -30
    arc_2_10_18  connected_order_arc_1160  -12
    arc_2_10_18  out_degree_1377  1
    arc_2_10_18  in_degree_1429  1
    arc_2_10_18  original_T_including_depot_unload_1448  1.3060135543268104e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_18  arc_capacity_1159  1
    load_2_10_18  segment_load_conservation_1381  1
    load_2_10_18  free_load_conservation_1433  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_19  arc_capacity_1161  -30
    arc_2_10_19  connected_order_arc_1162  -12
    arc_2_10_19  out_degree_1377  1
    arc_2_10_19  in_degree_1435  1
    arc_2_10_19  original_T_including_depot_unload_1448  5.4405628017126674e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_19  arc_capacity_1161  1
    load_2_10_19  segment_load_conservation_1381  1
    load_2_10_19  free_load_conservation_1439  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_20  arc_capacity_1163  -30
    arc_2_10_20  connected_order_arc_1164  -12
    arc_2_10_20  out_degree_1377  1
    arc_2_10_20  in_degree_1441  1
    arc_2_10_20  original_T_including_depot_unload_1448  1.5756194178147177e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_20  arc_capacity_1163  1
    load_2_10_20  segment_load_conservation_1381  1
    load_2_10_20  free_load_conservation_1445  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_0  arc_capacity_1165  -30
    arc_2_11_0  depot_return_or_bypass_1376  1
    arc_2_11_0  out_degree_1384  1
    arc_2_11_0  original_T_including_depot_unload_1448  1.6602888921784454e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_0  arc_capacity_1165  1
    load_2_11_0  segment_load_conservation_1388  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_10  arc_capacity_1166  -30
    arc_2_11_10  connected_order_arc_1167  -12
    arc_2_11_10  in_degree_1378  1
    arc_2_11_10  out_degree_1384  1
    arc_2_11_10  original_T_including_depot_unload_1448  1.2177809159572148e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_10  arc_capacity_1166  1
    load_2_11_10  segment_load_conservation_1381  -1
    load_2_11_10  segment_prefix_lb_1382  1
    load_2_11_10  segment_prefix_ub_1383  1
    load_2_11_10  segment_load_conservation_1388  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_12  arc_capacity_1168  -30
    arc_2_11_12  connected_order_arc_1169  -12
    arc_2_11_12  out_degree_1384  1
    arc_2_11_12  in_degree_1392  1
    arc_2_11_12  original_T_including_depot_unload_1448  1.3104307696104611e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_12  arc_capacity_1168  1
    load_2_11_12  segment_load_conservation_1388  1
    load_2_11_12  segment_load_conservation_1395  -1
    load_2_11_12  segment_prefix_lb_1396  1
    load_2_11_12  segment_prefix_ub_1397  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_13  arc_capacity_1170  -30
    arc_2_11_13  connected_order_arc_1171  -12
    arc_2_11_13  out_degree_1384  1
    arc_2_11_13  in_degree_1399  1
    arc_2_11_13  original_T_including_depot_unload_1448  2.2308484254926752e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_13  arc_capacity_1170  1
    load_2_11_13  segment_load_conservation_1388  1
    load_2_11_13  free_load_conservation_1403  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_14  arc_capacity_1172  -30
    arc_2_11_14  connected_order_arc_1173  -12
    arc_2_11_14  out_degree_1384  1
    arc_2_11_14  in_degree_1405  1
    arc_2_11_14  original_T_including_depot_unload_1448  2.2046488102052867e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_14  arc_capacity_1172  1
    load_2_11_14  segment_load_conservation_1388  1
    load_2_11_14  free_load_conservation_1409  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_15  arc_capacity_1174  -30
    arc_2_11_15  connected_order_arc_1175  -12
    arc_2_11_15  out_degree_1384  1
    arc_2_11_15  in_degree_1411  1
    arc_2_11_15  original_T_including_depot_unload_1448  1.9767828664634856e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_15  arc_capacity_1174  1
    load_2_11_15  segment_load_conservation_1388  1
    load_2_11_15  free_load_conservation_1415  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_16  arc_capacity_1176  -30
    arc_2_11_16  connected_order_arc_1177  -12
    arc_2_11_16  out_degree_1384  1
    arc_2_11_16  in_degree_1417  1
    arc_2_11_16  original_T_including_depot_unload_1448  2204.98417103458
    MARKER    'MARKER'                 'INTEND'
    load_2_11_16  arc_capacity_1176  1
    load_2_11_16  segment_load_conservation_1388  1
    load_2_11_16  free_load_conservation_1421  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_17  arc_capacity_1178  -30
    arc_2_11_17  connected_order_arc_1179  -12
    arc_2_11_17  out_degree_1384  1
    arc_2_11_17  in_degree_1423  1
    arc_2_11_17  original_T_including_depot_unload_1448  8.7008776944597639e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_17  arc_capacity_1178  1
    load_2_11_17  segment_load_conservation_1388  1
    load_2_11_17  free_load_conservation_1427  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_18  arc_capacity_1180  -30
    arc_2_11_18  connected_order_arc_1181  -12
    arc_2_11_18  out_degree_1384  1
    arc_2_11_18  in_degree_1429  1
    arc_2_11_18  original_T_including_depot_unload_1448  2.1385293969918903e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_18  arc_capacity_1180  1
    load_2_11_18  segment_load_conservation_1388  1
    load_2_11_18  free_load_conservation_1433  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_19  arc_capacity_1182  -30
    arc_2_11_19  connected_order_arc_1183  -12
    arc_2_11_19  out_degree_1384  1
    arc_2_11_19  in_degree_1435  1
    arc_2_11_19  original_T_including_depot_unload_1448  1.7489191280566063e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_19  arc_capacity_1182  1
    load_2_11_19  segment_load_conservation_1388  1
    load_2_11_19  free_load_conservation_1439  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_20  arc_capacity_1184  -30
    arc_2_11_20  connected_order_arc_1185  -12
    arc_2_11_20  out_degree_1384  1
    arc_2_11_20  in_degree_1441  1
    arc_2_11_20  original_T_including_depot_unload_1448  2.3332921717499753e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_20  arc_capacity_1184  1
    load_2_11_20  segment_load_conservation_1388  1
    load_2_11_20  free_load_conservation_1445  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_0  arc_capacity_1186  -30
    arc_2_12_0  depot_return_or_bypass_1376  1
    arc_2_12_0  out_degree_1391  1
    arc_2_12_0  original_T_including_depot_unload_1448  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_0  arc_capacity_1186  1
    load_2_12_0  segment_load_conservation_1395  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_10  arc_capacity_1187  -30
    arc_2_12_10  connected_order_arc_1188  -12
    arc_2_12_10  in_degree_1378  1
    arc_2_12_10  out_degree_1391  1
    arc_2_12_10  original_T_including_depot_unload_1448  3.7831268047064754e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_10  arc_capacity_1187  1
    load_2_12_10  segment_load_conservation_1381  -1
    load_2_12_10  segment_prefix_lb_1382  1
    load_2_12_10  segment_prefix_ub_1383  1
    load_2_12_10  segment_load_conservation_1395  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_11  arc_capacity_1189  -30
    arc_2_12_11  connected_order_arc_1190  -12
    arc_2_12_11  in_degree_1385  1
    arc_2_12_11  out_degree_1391  1
    arc_2_12_11  original_T_including_depot_unload_1448  1.0984912119828512e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_11  arc_capacity_1189  1
    load_2_12_11  segment_load_conservation_1388  -1
    load_2_12_11  segment_prefix_lb_1389  1
    load_2_12_11  segment_prefix_ub_1390  1
    load_2_12_11  segment_load_conservation_1395  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_13  arc_capacity_1191  -30
    arc_2_12_13  connected_order_arc_1192  -12
    arc_2_12_13  out_degree_1391  1
    arc_2_12_13  in_degree_1399  1
    arc_2_12_13  original_T_including_depot_unload_1448  1.0803844170008674e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_13  arc_capacity_1191  1
    load_2_12_13  segment_load_conservation_1395  1
    load_2_12_13  free_load_conservation_1403  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_14  arc_capacity_1193  -30
    arc_2_12_14  connected_order_arc_1194  -12
    arc_2_12_14  out_degree_1391  1
    arc_2_12_14  in_degree_1405  1
    arc_2_12_14  original_T_including_depot_unload_1448  1.0660093540264595e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_14  arc_capacity_1193  1
    load_2_12_14  segment_load_conservation_1395  1
    load_2_12_14  free_load_conservation_1409  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_15  arc_capacity_1195  -30
    arc_2_12_15  connected_order_arc_1196  -12
    arc_2_12_15  out_degree_1391  1
    arc_2_12_15  in_degree_1411  1
    arc_2_12_15  original_T_including_depot_unload_1448  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_15  arc_capacity_1195  1
    load_2_12_15  segment_load_conservation_1395  1
    load_2_12_15  free_load_conservation_1415  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_16  arc_capacity_1197  -30
    arc_2_12_16  connected_order_arc_1198  -12
    arc_2_12_16  out_degree_1391  1
    arc_2_12_16  in_degree_1417  1
    arc_2_12_16  original_T_including_depot_unload_1448  1.0665299943292241e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_16  arc_capacity_1197  1
    load_2_12_16  segment_load_conservation_1395  1
    load_2_12_16  free_load_conservation_1421  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_17  arc_capacity_1199  -30
    arc_2_12_17  connected_order_arc_1200  -12
    arc_2_12_17  out_degree_1391  1
    arc_2_12_17  in_degree_1423  1
    arc_2_12_17  original_T_including_depot_unload_1448  5.7424143497696048e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_17  arc_capacity_1199  1
    load_2_12_17  segment_load_conservation_1395  1
    load_2_12_17  free_load_conservation_1427  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_18  arc_capacity_1201  -30
    arc_2_12_18  connected_order_arc_1202  -12
    arc_2_12_18  out_degree_1391  1
    arc_2_12_18  in_degree_1429  1
    arc_2_12_18  original_T_including_depot_unload_1448  9.5968099967049886e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_18  arc_capacity_1201  1
    load_2_12_18  segment_load_conservation_1395  1
    load_2_12_18  free_load_conservation_1433  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_19  arc_capacity_1203  -30
    arc_2_12_19  connected_order_arc_1204  -12
    arc_2_12_19  out_degree_1391  1
    arc_2_12_19  in_degree_1435  1
    arc_2_12_19  original_T_including_depot_unload_1448  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_2_12_19  arc_capacity_1203  1
    load_2_12_19  segment_load_conservation_1395  1
    load_2_12_19  free_load_conservation_1439  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_20  arc_capacity_1205  -30
    arc_2_12_20  connected_order_arc_1206  -12
    arc_2_12_20  out_degree_1391  1
    arc_2_12_20  in_degree_1441  1
    arc_2_12_20  original_T_including_depot_unload_1448  1.2188376307261726e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_20  arc_capacity_1205  1
    load_2_12_20  segment_load_conservation_1395  1
    load_2_12_20  free_load_conservation_1445  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_0  arc_capacity_1207  -30
    arc_2_13_0  depot_return_or_bypass_1376  1
    arc_2_13_0  out_degree_1398  1
    arc_2_13_0  original_T_including_depot_unload_1448  6.4256529461228865e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_0  arc_capacity_1207  1
    load_2_13_0  free_load_conservation_1403  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_10  arc_capacity_1208  -30
    arc_2_13_10  connected_order_arc_1209  -12
    arc_2_13_10  in_degree_1378  1
    arc_2_13_10  out_degree_1398  1
    arc_2_13_10  original_T_including_depot_unload_1448  1.4316381888253884e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_10  arc_capacity_1208  1
    load_2_13_10  segment_load_conservation_1381  -1
    load_2_13_10  segment_prefix_lb_1382  1
    load_2_13_10  segment_prefix_ub_1383  1
    load_2_13_10  free_load_conservation_1403  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_11  arc_capacity_1210  -30
    arc_2_13_11  connected_order_arc_1211  -12
    arc_2_13_11  in_degree_1385  1
    arc_2_13_11  out_degree_1398  1
    arc_2_13_11  original_T_including_depot_unload_1448  2.0052615109144283e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_11  arc_capacity_1210  1
    load_2_13_11  segment_load_conservation_1388  -1
    load_2_13_11  segment_prefix_lb_1389  1
    load_2_13_11  segment_prefix_ub_1390  1
    load_2_13_11  free_load_conservation_1403  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_12  arc_capacity_1212  -30
    arc_2_13_12  connected_order_arc_1213  -12
    arc_2_13_12  in_degree_1392  1
    arc_2_13_12  out_degree_1398  1
    arc_2_13_12  original_T_including_depot_unload_1448  1.0803844170008674e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_12  arc_capacity_1212  1
    load_2_13_12  segment_load_conservation_1395  -1
    load_2_13_12  segment_prefix_lb_1396  1
    load_2_13_12  segment_prefix_ub_1397  1
    load_2_13_12  free_load_conservation_1403  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_14  arc_capacity_1214  -30
    arc_2_13_14  connected_order_arc_1215  -12
    arc_2_13_14  out_degree_1398  1
    arc_2_13_14  in_degree_1405  1
    arc_2_13_14  original_T_including_depot_unload_1448  3.5317482243205085e+01
    MARKER    'MARKER'                 'INTEND'
    load_2_13_14  arc_capacity_1214  1
    load_2_13_14  free_load_conservation_1403  1
    load_2_13_14  free_load_conservation_1409  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_15  arc_capacity_1216  -30
    arc_2_13_15  connected_order_arc_1217  -12
    arc_2_13_15  out_degree_1398  1
    arc_2_13_15  in_degree_1411  1
    arc_2_13_15  original_T_including_depot_unload_1448  2.0790680627934375e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_15  arc_capacity_1216  1
    load_2_13_15  free_load_conservation_1403  1
    load_2_13_15  free_load_conservation_1415  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_16  arc_capacity_1218  -30
    arc_2_13_16  connected_order_arc_1219  -12
    arc_2_13_16  out_degree_1398  1
    arc_2_13_16  in_degree_1417  1
    arc_2_13_16  original_T_including_depot_unload_1448  3.5426413058949414e+01
    MARKER    'MARKER'                 'INTEND'
    load_2_13_16  arc_capacity_1218  1
    load_2_13_16  free_load_conservation_1403  1
    load_2_13_16  free_load_conservation_1421  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_17  arc_capacity_1220  -30
    arc_2_13_17  connected_order_arc_1221  -12
    arc_2_13_17  out_degree_1398  1
    arc_2_13_17  in_degree_1423  1
    arc_2_13_17  original_T_including_depot_unload_1448  1.6472719129023171e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_17  arc_capacity_1220  1
    load_2_13_17  free_load_conservation_1403  1
    load_2_13_17  free_load_conservation_1427  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_18  arc_capacity_1222  -30
    arc_2_13_18  connected_order_arc_1223  -12
    arc_2_13_18  out_degree_1398  1
    arc_2_13_18  in_degree_1429  1
    arc_2_13_18  original_T_including_depot_unload_1448  1.2962070286822930e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_18  arc_capacity_1222  1
    load_2_13_18  free_load_conservation_1403  1
    load_2_13_18  free_load_conservation_1433  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_19  arc_capacity_1224  -30
    arc_2_13_19  connected_order_arc_1225  -12
    arc_2_13_19  out_degree_1398  1
    arc_2_13_19  in_degree_1435  1
    arc_2_13_19  original_T_including_depot_unload_1448  1.4457797980495495e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_19  arc_capacity_1224  1
    load_2_13_19  free_load_conservation_1403  1
    load_2_13_19  free_load_conservation_1439  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_20  arc_capacity_1226  -30
    arc_2_13_20  connected_order_arc_1227  -12
    arc_2_13_20  out_degree_1398  1
    arc_2_13_20  in_degree_1441  1
    arc_2_13_20  original_T_including_depot_unload_1448  1.5153540246292351e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_20  arc_capacity_1226  1
    load_2_13_20  free_load_conservation_1403  1
    load_2_13_20  free_load_conservation_1445  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_0  arc_capacity_1228  -30
    arc_2_14_0  depot_return_or_bypass_1376  1
    arc_2_14_0  out_degree_1404  1
    arc_2_14_0  original_T_including_depot_unload_1448  6.2851955830851955e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_0  arc_capacity_1228  1
    load_2_14_0  free_load_conservation_1409  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_10  arc_capacity_1229  -30
    arc_2_14_10  connected_order_arc_1230  -12
    arc_2_14_10  in_degree_1378  1
    arc_2_14_10  out_degree_1404  1
    arc_2_14_10  original_T_including_depot_unload_1448  1.4208855669296320e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_10  arc_capacity_1229  1
    load_2_14_10  segment_load_conservation_1381  -1
    load_2_14_10  segment_prefix_lb_1382  1
    load_2_14_10  segment_prefix_ub_1383  1
    load_2_14_10  free_load_conservation_1409  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_11  arc_capacity_1231  -30
    arc_2_14_11  connected_order_arc_1232  -12
    arc_2_14_11  in_degree_1385  1
    arc_2_14_11  out_degree_1404  1
    arc_2_14_11  original_T_including_depot_unload_1448  2.0045579804597039e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_11  arc_capacity_1231  1
    load_2_14_11  segment_load_conservation_1388  -1
    load_2_14_11  segment_prefix_lb_1389  1
    load_2_14_11  segment_prefix_ub_1390  1
    load_2_14_11  free_load_conservation_1409  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_12  arc_capacity_1233  -30
    arc_2_14_12  connected_order_arc_1234  -12
    arc_2_14_12  in_degree_1392  1
    arc_2_14_12  out_degree_1404  1
    arc_2_14_12  original_T_including_depot_unload_1448  1.0660093540264595e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_12  arc_capacity_1233  1
    load_2_14_12  segment_load_conservation_1395  -1
    load_2_14_12  segment_prefix_lb_1396  1
    load_2_14_12  segment_prefix_ub_1397  1
    load_2_14_12  free_load_conservation_1409  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_13  arc_capacity_1235  -30
    arc_2_14_13  connected_order_arc_1236  -12
    arc_2_14_13  in_degree_1399  1
    arc_2_14_13  out_degree_1404  1
    arc_2_14_13  original_T_including_depot_unload_1448  3.5317482243205085e+01
    MARKER    'MARKER'                 'INTEND'
    load_2_14_13  arc_capacity_1235  1
    load_2_14_13  free_load_conservation_1403  -1
    load_2_14_13  free_load_conservation_1409  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_15  arc_capacity_1237  -30
    arc_2_14_15  connected_order_arc_1238  -12
    arc_2_14_15  out_degree_1404  1
    arc_2_14_15  in_degree_1411  1
    arc_2_14_15  original_T_including_depot_unload_1448  2.0832214111784192e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_15  arc_capacity_1237  1
    load_2_14_15  free_load_conservation_1409  1
    load_2_14_15  free_load_conservation_1415  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_16  arc_capacity_1239  -30
    arc_2_14_16  connected_order_arc_1240  -12
    arc_2_14_16  out_degree_1404  1
    arc_2_14_16  in_degree_1417  1
    arc_2_14_16  original_T_including_depot_unload_1448  6.1926694994249909e-01
    MARKER    'MARKER'                 'INTEND'
    load_2_14_16  arc_capacity_1239  1
    load_2_14_16  free_load_conservation_1409  1
    load_2_14_16  free_load_conservation_1421  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_17  arc_capacity_1241  -30
    arc_2_14_17  connected_order_arc_1242  -12
    arc_2_14_17  out_degree_1404  1
    arc_2_14_17  in_degree_1423  1
    arc_2_14_17  original_T_including_depot_unload_1448  1.6305450534190286e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_17  arc_capacity_1241  1
    load_2_14_17  free_load_conservation_1409  1
    load_2_14_17  free_load_conservation_1427  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_18  arc_capacity_1243  -30
    arc_2_14_18  connected_order_arc_1244  -12
    arc_2_14_18  out_degree_1404  1
    arc_2_14_18  in_degree_1429  1
    arc_2_14_18  original_T_including_depot_unload_1448  1.3146996282072985e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_18  arc_capacity_1243  1
    load_2_14_18  free_load_conservation_1409  1
    load_2_14_18  free_load_conservation_1433  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_19  arc_capacity_1245  -30
    arc_2_14_19  connected_order_arc_1246  -12
    arc_2_14_19  out_degree_1404  1
    arc_2_14_19  in_degree_1435  1
    arc_2_14_19  original_T_including_depot_unload_1448  1.4482979064849126e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_19  arc_capacity_1245  1
    load_2_14_19  free_load_conservation_1409  1
    load_2_14_19  free_load_conservation_1439  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_20  arc_capacity_1247  -30
    arc_2_14_20  connected_order_arc_1248  -12
    arc_2_14_20  out_degree_1404  1
    arc_2_14_20  in_degree_1441  1
    arc_2_14_20  original_T_including_depot_unload_1448  1.5518157315724611e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_20  arc_capacity_1247  1
    load_2_14_20  free_load_conservation_1409  1
    load_2_14_20  free_load_conservation_1445  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_0  arc_capacity_1249  -30
    arc_2_15_0  depot_return_or_bypass_1376  1
    arc_2_15_0  out_degree_1410  1
    arc_2_15_0  original_T_including_depot_unload_1448  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_0  arc_capacity_1249  1
    load_2_15_0  free_load_conservation_1415  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_10  arc_capacity_1250  -30
    arc_2_15_10  connected_order_arc_1251  -12
    arc_2_15_10  in_degree_1378  1
    arc_2_15_10  out_degree_1410  1
    arc_2_15_10  original_T_including_depot_unload_1448  9.8108674361469946e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_10  arc_capacity_1250  1
    load_2_15_10  segment_load_conservation_1381  -1
    load_2_15_10  segment_prefix_lb_1382  1
    load_2_15_10  segment_prefix_ub_1383  1
    load_2_15_10  free_load_conservation_1415  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_11  arc_capacity_1252  -30
    arc_2_15_11  connected_order_arc_1253  -12
    arc_2_15_11  in_degree_1385  1
    arc_2_15_11  out_degree_1410  1
    arc_2_15_11  original_T_including_depot_unload_1448  2.9139628504456829e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_11  arc_capacity_1252  1
    load_2_15_11  segment_load_conservation_1388  -1
    load_2_15_11  segment_prefix_lb_1389  1
    load_2_15_11  segment_prefix_ub_1390  1
    load_2_15_11  free_load_conservation_1415  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_12  arc_capacity_1254  -30
    arc_2_15_12  connected_order_arc_1255  -12
    arc_2_15_12  in_degree_1392  1
    arc_2_15_12  out_degree_1410  1
    arc_2_15_12  original_T_including_depot_unload_1448  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_12  arc_capacity_1254  1
    load_2_15_12  segment_load_conservation_1395  -1
    load_2_15_12  segment_prefix_lb_1396  1
    load_2_15_12  segment_prefix_ub_1397  1
    load_2_15_12  free_load_conservation_1415  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_13  arc_capacity_1256  -30
    arc_2_15_13  connected_order_arc_1257  -12
    arc_2_15_13  in_degree_1399  1
    arc_2_15_13  out_degree_1410  1
    arc_2_15_13  original_T_including_depot_unload_1448  2.0790680627934375e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_13  arc_capacity_1256  1
    load_2_15_13  free_load_conservation_1403  -1
    load_2_15_13  free_load_conservation_1415  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_14  arc_capacity_1258  -30
    arc_2_15_14  connected_order_arc_1259  -12
    arc_2_15_14  in_degree_1405  1
    arc_2_15_14  out_degree_1410  1
    arc_2_15_14  original_T_including_depot_unload_1448  2.0832214111784192e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_14  arc_capacity_1258  1
    load_2_15_14  free_load_conservation_1409  -1
    load_2_15_14  free_load_conservation_1415  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_16  arc_capacity_1260  -30
    arc_2_15_16  connected_order_arc_1261  -12
    arc_2_15_16  out_degree_1410  1
    arc_2_15_16  in_degree_1417  1
    arc_2_15_16  original_T_including_depot_unload_1448  2.0838401346783280e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_16  arc_capacity_1260  1
    load_2_15_16  free_load_conservation_1415  1
    load_2_15_16  free_load_conservation_1421  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_17  arc_capacity_1262  -30
    arc_2_15_17  connected_order_arc_1263  -12
    arc_2_15_17  out_degree_1410  1
    arc_2_15_17  in_degree_1423  1
    arc_2_15_17  original_T_including_depot_unload_1448  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_17  arc_capacity_1262  1
    load_2_15_17  free_load_conservation_1415  1
    load_2_15_17  free_load_conservation_1427  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_18  arc_capacity_1264  -30
    arc_2_15_18  connected_order_arc_1265  -12
    arc_2_15_18  out_degree_1410  1
    arc_2_15_18  in_degree_1429  1
    arc_2_15_18  original_T_including_depot_unload_1448  1.9520133700471852e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_18  arc_capacity_1264  1
    load_2_15_18  free_load_conservation_1415  1
    load_2_15_18  free_load_conservation_1433  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_19  arc_capacity_1266  -30
    arc_2_15_19  connected_order_arc_1267  -12
    arc_2_15_19  out_degree_1410  1
    arc_2_15_19  in_degree_1435  1
    arc_2_15_19  original_T_including_depot_unload_1448  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_2_15_19  arc_capacity_1266  1
    load_2_15_19  free_load_conservation_1415  1
    load_2_15_19  free_load_conservation_1439  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_20  arc_capacity_1268  -30
    arc_2_15_20  connected_order_arc_1269  -12
    arc_2_15_20  out_degree_1410  1
    arc_2_15_20  in_degree_1441  1
    arc_2_15_20  original_T_including_depot_unload_1448  2.2299340442558691e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_20  arc_capacity_1268  1
    load_2_15_20  free_load_conservation_1415  1
    load_2_15_20  free_load_conservation_1445  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_0  arc_capacity_1270  -30
    arc_2_16_0  depot_return_or_bypass_1376  1
    arc_2_16_0  out_degree_1416  1
    arc_2_16_0  original_T_including_depot_unload_1448  6.2904707403788154e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_0  arc_capacity_1270  1
    load_2_16_0  free_load_conservation_1421  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_10  arc_capacity_1271  -30
    arc_2_16_10  connected_order_arc_1272  -12
    arc_2_16_10  in_degree_1378  1
    arc_2_16_10  out_degree_1416  1
    arc_2_16_10  original_T_including_depot_unload_1448  1.4214388997747180e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_10  arc_capacity_1271  1
    load_2_16_10  segment_load_conservation_1381  -1
    load_2_16_10  segment_prefix_lb_1382  1
    load_2_16_10  segment_prefix_ub_1383  1
    load_2_16_10  free_load_conservation_1421  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_11  arc_capacity_1273  -30
    arc_2_16_11  connected_order_arc_1274  -12
    arc_2_16_11  in_degree_1385  1
    arc_2_16_11  out_degree_1416  1
    arc_2_16_11  original_T_including_depot_unload_1448  2.0051673213472504e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_11  arc_capacity_1273  1
    load_2_16_11  segment_load_conservation_1388  -1
    load_2_16_11  segment_prefix_lb_1389  1
    load_2_16_11  segment_prefix_ub_1390  1
    load_2_16_11  free_load_conservation_1421  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_12  arc_capacity_1275  -30
    arc_2_16_12  connected_order_arc_1276  -12
    arc_2_16_12  in_degree_1392  1
    arc_2_16_12  out_degree_1416  1
    arc_2_16_12  original_T_including_depot_unload_1448  1.0665299943292241e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_12  arc_capacity_1275  1
    load_2_16_12  segment_load_conservation_1395  -1
    load_2_16_12  segment_prefix_lb_1396  1
    load_2_16_12  segment_prefix_ub_1397  1
    load_2_16_12  free_load_conservation_1421  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_13  arc_capacity_1277  -30
    arc_2_16_13  connected_order_arc_1278  -12
    arc_2_16_13  in_degree_1399  1
    arc_2_16_13  out_degree_1416  1
    arc_2_16_13  original_T_including_depot_unload_1448  3.5426413058949414e+01
    MARKER    'MARKER'                 'INTEND'
    load_2_16_13  arc_capacity_1277  1
    load_2_16_13  free_load_conservation_1403  -1
    load_2_16_13  free_load_conservation_1421  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_14  arc_capacity_1279  -30
    arc_2_16_14  connected_order_arc_1280  -12
    arc_2_16_14  in_degree_1405  1
    arc_2_16_14  out_degree_1416  1
    arc_2_16_14  original_T_including_depot_unload_1448  6.1926694994249909e-01
    MARKER    'MARKER'                 'INTEND'
    load_2_16_14  arc_capacity_1279  1
    load_2_16_14  free_load_conservation_1409  -1
    load_2_16_14  free_load_conservation_1421  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_15  arc_capacity_1281  -30
    arc_2_16_15  connected_order_arc_1282  -12
    arc_2_16_15  in_degree_1411  1
    arc_2_16_15  out_degree_1416  1
    arc_2_16_15  original_T_including_depot_unload_1448  2.0838401346783280e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_15  arc_capacity_1281  1
    load_2_16_15  free_load_conservation_1415  -1
    load_2_16_15  free_load_conservation_1421  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_17  arc_capacity_1283  -30
    arc_2_16_17  connected_order_arc_1284  -12
    arc_2_16_17  out_degree_1416  1
    arc_2_16_17  in_degree_1423  1
    arc_2_16_17  original_T_including_depot_unload_1448  1.6310373065065476e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_17  arc_capacity_1283  1
    load_2_16_17  free_load_conservation_1421  1
    load_2_16_17  free_load_conservation_1427  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_18  arc_capacity_1285  -30
    arc_2_16_18  connected_order_arc_1286  -12
    arc_2_16_18  out_degree_1416  1
    arc_2_16_18  in_degree_1429  1
    arc_2_16_18  original_T_including_depot_unload_1448  1.3208911608803092e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_18  arc_capacity_1285  1
    load_2_16_18  free_load_conservation_1421  1
    load_2_16_18  free_load_conservation_1433  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_19  arc_capacity_1287  -30
    arc_2_16_19  connected_order_arc_1288  -12
    arc_2_16_19  out_degree_1416  1
    arc_2_16_19  in_degree_1435  1
    arc_2_16_19  original_T_including_depot_unload_1448  1.4489149558446036e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_19  arc_capacity_1287  1
    load_2_16_19  free_load_conservation_1421  1
    load_2_16_19  free_load_conservation_1439  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_20  arc_capacity_1289  -30
    arc_2_16_20  connected_order_arc_1290  -12
    arc_2_16_20  out_degree_1416  1
    arc_2_16_20  in_degree_1441  1
    arc_2_16_20  original_T_including_depot_unload_1448  1.5460798335742169e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_20  arc_capacity_1289  1
    load_2_16_20  free_load_conservation_1421  1
    load_2_16_20  free_load_conservation_1445  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_0  arc_capacity_1291  -30
    arc_2_17_0  depot_return_or_bypass_1376  1
    arc_2_17_0  out_degree_1422  1
    arc_2_17_0  original_T_including_depot_unload_1448  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_0  arc_capacity_1291  1
    load_2_17_0  free_load_conservation_1427  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_10  arc_capacity_1292  -30
    arc_2_17_10  connected_order_arc_1293  -12
    arc_2_17_10  in_degree_1378  1
    arc_2_17_10  out_degree_1422  1
    arc_2_17_10  original_T_including_depot_unload_1448  3.5235932354279930e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_10  arc_capacity_1292  1
    load_2_17_10  segment_load_conservation_1381  -1
    load_2_17_10  segment_prefix_lb_1382  1
    load_2_17_10  segment_prefix_ub_1383  1
    load_2_17_10  free_load_conservation_1427  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_11  arc_capacity_1294  -30
    arc_2_17_11  connected_order_arc_1295  -12
    arc_2_17_11  in_degree_1385  1
    arc_2_17_11  out_degree_1422  1
    arc_2_17_11  original_T_including_depot_unload_1448  925.691754925099
    MARKER    'MARKER'                 'INTEND'
    load_2_17_11  arc_capacity_1294  1
    load_2_17_11  segment_load_conservation_1388  -1
    load_2_17_11  segment_prefix_lb_1389  1
    load_2_17_11  segment_prefix_ub_1390  1
    load_2_17_11  free_load_conservation_1427  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_12  arc_capacity_1296  -30
    arc_2_17_12  connected_order_arc_1297  -12
    arc_2_17_12  in_degree_1392  1
    arc_2_17_12  out_degree_1422  1
    arc_2_17_12  original_T_including_depot_unload_1448  5.7424143497696048e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_12  arc_capacity_1296  1
    load_2_17_12  segment_load_conservation_1395  -1
    load_2_17_12  segment_prefix_lb_1396  1
    load_2_17_12  segment_prefix_ub_1397  1
    load_2_17_12  free_load_conservation_1427  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_13  arc_capacity_1298  -30
    arc_2_17_13  connected_order_arc_1299  -12
    arc_2_17_13  in_degree_1399  1
    arc_2_17_13  out_degree_1422  1
    arc_2_17_13  original_T_including_depot_unload_1448  1.6472719129023171e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_13  arc_capacity_1298  1
    load_2_17_13  free_load_conservation_1403  -1
    load_2_17_13  free_load_conservation_1427  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_14  arc_capacity_1300  -30
    arc_2_17_14  connected_order_arc_1301  -12
    arc_2_17_14  in_degree_1405  1
    arc_2_17_14  out_degree_1422  1
    arc_2_17_14  original_T_including_depot_unload_1448  1.6305450534190286e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_14  arc_capacity_1300  1
    load_2_17_14  free_load_conservation_1409  -1
    load_2_17_14  free_load_conservation_1427  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_15  arc_capacity_1302  -30
    arc_2_17_15  connected_order_arc_1303  -12
    arc_2_17_15  in_degree_1411  1
    arc_2_17_15  out_degree_1422  1
    arc_2_17_15  original_T_including_depot_unload_1448  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_15  arc_capacity_1302  1
    load_2_17_15  free_load_conservation_1415  -1
    load_2_17_15  free_load_conservation_1427  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_16  arc_capacity_1304  -30
    arc_2_17_16  connected_order_arc_1305  -12
    arc_2_17_16  in_degree_1417  1
    arc_2_17_16  out_degree_1422  1
    arc_2_17_16  original_T_including_depot_unload_1448  1.6310373065065476e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_16  arc_capacity_1304  1
    load_2_17_16  free_load_conservation_1421  -1
    load_2_17_16  free_load_conservation_1427  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_18  arc_capacity_1306  -30
    arc_2_17_18  connected_order_arc_1307  -12
    arc_2_17_18  out_degree_1422  1
    arc_2_17_18  in_degree_1429  1
    arc_2_17_18  original_T_including_depot_unload_1448  1.5297878372821015e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_18  arc_capacity_1306  1
    load_2_17_18  free_load_conservation_1427  1
    load_2_17_18  free_load_conservation_1433  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_19  arc_capacity_1308  -30
    arc_2_17_19  connected_order_arc_1309  -12
    arc_2_17_19  out_degree_1422  1
    arc_2_17_19  in_degree_1435  1
    arc_2_17_19  original_T_including_depot_unload_1448  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_19  arc_capacity_1308  1
    load_2_17_19  free_load_conservation_1427  1
    load_2_17_19  free_load_conservation_1439  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_20  arc_capacity_1310  -30
    arc_2_17_20  connected_order_arc_1311  -12
    arc_2_17_20  out_degree_1422  1
    arc_2_17_20  in_degree_1441  1
    arc_2_17_20  original_T_including_depot_unload_1448  1.7807233899807140e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_20  arc_capacity_1310  1
    load_2_17_20  free_load_conservation_1427  1
    load_2_17_20  free_load_conservation_1445  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_0  arc_capacity_1312  -30
    arc_2_18_0  depot_return_or_bypass_1376  1
    arc_2_18_0  out_degree_1428  1
    arc_2_18_0  original_T_including_depot_unload_1448  5.2273830510106120e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_0  arc_capacity_1312  1
    load_2_18_0  free_load_conservation_1433  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_10  arc_capacity_1313  -30
    arc_2_18_10  connected_order_arc_1314  -12
    arc_2_18_10  in_degree_1378  1
    arc_2_18_10  out_degree_1428  1
    arc_2_18_10  original_T_including_depot_unload_1448  1.3060135543268104e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_10  arc_capacity_1313  1
    load_2_18_10  segment_load_conservation_1381  -1
    load_2_18_10  segment_prefix_lb_1382  1
    load_2_18_10  segment_prefix_ub_1383  1
    load_2_18_10  free_load_conservation_1433  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_11  arc_capacity_1315  -30
    arc_2_18_11  connected_order_arc_1316  -12
    arc_2_18_11  in_degree_1385  1
    arc_2_18_11  out_degree_1428  1
    arc_2_18_11  original_T_including_depot_unload_1448  1.8758493536744261e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_11  arc_capacity_1315  1
    load_2_18_11  segment_load_conservation_1388  -1
    load_2_18_11  segment_prefix_lb_1389  1
    load_2_18_11  segment_prefix_ub_1390  1
    load_2_18_11  free_load_conservation_1433  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_12  arc_capacity_1317  -30
    arc_2_18_12  connected_order_arc_1318  -12
    arc_2_18_12  in_degree_1392  1
    arc_2_18_12  out_degree_1428  1
    arc_2_18_12  original_T_including_depot_unload_1448  9.5968099967049886e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_12  arc_capacity_1317  1
    load_2_18_12  segment_load_conservation_1395  -1
    load_2_18_12  segment_prefix_lb_1396  1
    load_2_18_12  segment_prefix_ub_1397  1
    load_2_18_12  free_load_conservation_1433  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_13  arc_capacity_1319  -30
    arc_2_18_13  connected_order_arc_1320  -12
    arc_2_18_13  in_degree_1399  1
    arc_2_18_13  out_degree_1428  1
    arc_2_18_13  original_T_including_depot_unload_1448  1.2962070286822930e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_13  arc_capacity_1319  1
    load_2_18_13  free_load_conservation_1403  -1
    load_2_18_13  free_load_conservation_1433  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_14  arc_capacity_1321  -30
    arc_2_18_14  connected_order_arc_1322  -12
    arc_2_18_14  in_degree_1405  1
    arc_2_18_14  out_degree_1428  1
    arc_2_18_14  original_T_including_depot_unload_1448  1.3146996282072985e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_14  arc_capacity_1321  1
    load_2_18_14  free_load_conservation_1409  -1
    load_2_18_14  free_load_conservation_1433  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_15  arc_capacity_1323  -30
    arc_2_18_15  connected_order_arc_1324  -12
    arc_2_18_15  in_degree_1411  1
    arc_2_18_15  out_degree_1428  1
    arc_2_18_15  original_T_including_depot_unload_1448  1.9520133700471852e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_15  arc_capacity_1323  1
    load_2_18_15  free_load_conservation_1415  -1
    load_2_18_15  free_load_conservation_1433  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_16  arc_capacity_1325  -30
    arc_2_18_16  connected_order_arc_1326  -12
    arc_2_18_16  in_degree_1417  1
    arc_2_18_16  out_degree_1428  1
    arc_2_18_16  original_T_including_depot_unload_1448  1.3208911608803092e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_16  arc_capacity_1325  1
    load_2_18_16  free_load_conservation_1421  -1
    load_2_18_16  free_load_conservation_1433  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_17  arc_capacity_1327  -30
    arc_2_18_17  connected_order_arc_1328  -12
    arc_2_18_17  in_degree_1423  1
    arc_2_18_17  out_degree_1428  1
    arc_2_18_17  original_T_including_depot_unload_1448  1.5297878372821015e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_17  arc_capacity_1327  1
    load_2_18_17  free_load_conservation_1427  -1
    load_2_18_17  free_load_conservation_1433  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_19  arc_capacity_1329  -30
    arc_2_18_19  connected_order_arc_1330  -12
    arc_2_18_19  out_degree_1428  1
    arc_2_18_19  in_degree_1435  1
    arc_2_18_19  original_T_including_depot_unload_1448  1.3176071585703125e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_19  arc_capacity_1329  1
    load_2_18_19  free_load_conservation_1433  1
    load_2_18_19  free_load_conservation_1439  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_20  arc_capacity_1331  -30
    arc_2_18_20  connected_order_arc_1332  -12
    arc_2_18_20  out_degree_1428  1
    arc_2_18_20  in_degree_1441  1
    arc_2_18_20  original_T_including_depot_unload_1448  2.8083660458664087e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_20  arc_capacity_1331  1
    load_2_18_20  free_load_conservation_1433  1
    load_2_18_20  free_load_conservation_1445  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_0  arc_capacity_1333  -30
    arc_2_19_0  depot_return_or_bypass_1376  1
    arc_2_19_0  out_degree_1434  1
    arc_2_19_0  original_T_including_depot_unload_1448  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_0  arc_capacity_1333  1
    load_2_19_0  free_load_conservation_1439  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_10  arc_capacity_1334  -30
    arc_2_19_10  connected_order_arc_1335  -12
    arc_2_19_10  in_degree_1378  1
    arc_2_19_10  out_degree_1434  1
    arc_2_19_10  original_T_including_depot_unload_1448  5.4405628017126674e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_10  arc_capacity_1334  1
    load_2_19_10  segment_load_conservation_1381  -1
    load_2_19_10  segment_prefix_lb_1382  1
    load_2_19_10  segment_prefix_ub_1383  1
    load_2_19_10  free_load_conservation_1439  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_11  arc_capacity_1336  -30
    arc_2_19_11  connected_order_arc_1337  -12
    arc_2_19_11  in_degree_1385  1
    arc_2_19_11  out_degree_1434  1
    arc_2_19_11  original_T_including_depot_unload_1448  5.7914586906741226e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_11  arc_capacity_1336  1
    load_2_19_11  segment_load_conservation_1388  -1
    load_2_19_11  segment_prefix_lb_1389  1
    load_2_19_11  segment_prefix_ub_1390  1
    load_2_19_11  free_load_conservation_1439  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_12  arc_capacity_1338  -30
    arc_2_19_12  connected_order_arc_1339  -12
    arc_2_19_12  in_degree_1392  1
    arc_2_19_12  out_degree_1434  1
    arc_2_19_12  original_T_including_depot_unload_1448  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_2_19_12  arc_capacity_1338  1
    load_2_19_12  segment_load_conservation_1395  -1
    load_2_19_12  segment_prefix_lb_1396  1
    load_2_19_12  segment_prefix_ub_1397  1
    load_2_19_12  free_load_conservation_1439  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_13  arc_capacity_1340  -30
    arc_2_19_13  connected_order_arc_1341  -12
    arc_2_19_13  in_degree_1399  1
    arc_2_19_13  out_degree_1434  1
    arc_2_19_13  original_T_including_depot_unload_1448  1.4457797980495495e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_13  arc_capacity_1340  1
    load_2_19_13  free_load_conservation_1403  -1
    load_2_19_13  free_load_conservation_1439  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_14  arc_capacity_1342  -30
    arc_2_19_14  connected_order_arc_1343  -12
    arc_2_19_14  in_degree_1405  1
    arc_2_19_14  out_degree_1434  1
    arc_2_19_14  original_T_including_depot_unload_1448  1.4482979064849126e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_14  arc_capacity_1342  1
    load_2_19_14  free_load_conservation_1409  -1
    load_2_19_14  free_load_conservation_1439  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_15  arc_capacity_1344  -30
    arc_2_19_15  connected_order_arc_1345  -12
    arc_2_19_15  in_degree_1411  1
    arc_2_19_15  out_degree_1434  1
    arc_2_19_15  original_T_including_depot_unload_1448  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_2_19_15  arc_capacity_1344  1
    load_2_19_15  free_load_conservation_1415  -1
    load_2_19_15  free_load_conservation_1439  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_16  arc_capacity_1346  -30
    arc_2_19_16  connected_order_arc_1347  -12
    arc_2_19_16  in_degree_1417  1
    arc_2_19_16  out_degree_1434  1
    arc_2_19_16  original_T_including_depot_unload_1448  1.4489149558446036e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_16  arc_capacity_1346  1
    load_2_19_16  free_load_conservation_1421  -1
    load_2_19_16  free_load_conservation_1439  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_17  arc_capacity_1348  -30
    arc_2_19_17  connected_order_arc_1349  -12
    arc_2_19_17  in_degree_1423  1
    arc_2_19_17  out_degree_1434  1
    arc_2_19_17  original_T_including_depot_unload_1448  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_17  arc_capacity_1348  1
    load_2_19_17  free_load_conservation_1427  -1
    load_2_19_17  free_load_conservation_1439  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_18  arc_capacity_1350  -30
    arc_2_19_18  connected_order_arc_1351  -12
    arc_2_19_18  in_degree_1429  1
    arc_2_19_18  out_degree_1434  1
    arc_2_19_18  original_T_including_depot_unload_1448  1.3176071585703125e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_18  arc_capacity_1350  1
    load_2_19_18  free_load_conservation_1433  -1
    load_2_19_18  free_load_conservation_1439  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_20  arc_capacity_1352  -30
    arc_2_19_20  connected_order_arc_1353  -12
    arc_2_19_20  out_degree_1434  1
    arc_2_19_20  in_degree_1441  1
    arc_2_19_20  original_T_including_depot_unload_1448  1.5971628811503840e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_20  arc_capacity_1352  1
    load_2_19_20  free_load_conservation_1439  1
    load_2_19_20  free_load_conservation_1445  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_0  arc_capacity_1354  -30
    arc_2_20_0  depot_return_or_bypass_1376  1
    arc_2_20_0  out_degree_1440  1
    arc_2_20_0  original_T_including_depot_unload_1448  7.8199183337763486e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_0  arc_capacity_1354  1
    load_2_20_0  free_load_conservation_1445  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_10  arc_capacity_1355  -30
    arc_2_20_10  connected_order_arc_1356  -12
    arc_2_20_10  in_degree_1378  1
    arc_2_20_10  out_degree_1440  1
    arc_2_20_10  original_T_including_depot_unload_1448  1.5756194178147177e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_10  arc_capacity_1355  1
    load_2_20_10  segment_load_conservation_1381  -1
    load_2_20_10  segment_prefix_lb_1382  1
    load_2_20_10  segment_prefix_ub_1383  1
    load_2_20_10  free_load_conservation_1445  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_11  arc_capacity_1357  -30
    arc_2_20_11  connected_order_arc_1358  -12
    arc_2_20_11  in_degree_1385  1
    arc_2_20_11  out_degree_1440  1
    arc_2_20_11  original_T_including_depot_unload_1448  2.1566797920965496e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_11  arc_capacity_1357  1
    load_2_20_11  segment_load_conservation_1388  -1
    load_2_20_11  segment_prefix_lb_1389  1
    load_2_20_11  segment_prefix_ub_1390  1
    load_2_20_11  free_load_conservation_1445  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_12  arc_capacity_1359  -30
    arc_2_20_12  connected_order_arc_1360  -12
    arc_2_20_12  in_degree_1392  1
    arc_2_20_12  out_degree_1440  1
    arc_2_20_12  original_T_including_depot_unload_1448  1.2188376307261726e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_12  arc_capacity_1359  1
    load_2_20_12  segment_load_conservation_1395  -1
    load_2_20_12  segment_prefix_lb_1396  1
    load_2_20_12  segment_prefix_ub_1397  1
    load_2_20_12  free_load_conservation_1445  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_13  arc_capacity_1361  -30
    arc_2_20_13  connected_order_arc_1362  -12
    arc_2_20_13  in_degree_1399  1
    arc_2_20_13  out_degree_1440  1
    arc_2_20_13  original_T_including_depot_unload_1448  1.5153540246292351e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_13  arc_capacity_1361  1
    load_2_20_13  free_load_conservation_1403  -1
    load_2_20_13  free_load_conservation_1445  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_14  arc_capacity_1363  -30
    arc_2_20_14  connected_order_arc_1364  -12
    arc_2_20_14  in_degree_1405  1
    arc_2_20_14  out_degree_1440  1
    arc_2_20_14  original_T_including_depot_unload_1448  1.5518157315724611e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_14  arc_capacity_1363  1
    load_2_20_14  free_load_conservation_1409  -1
    load_2_20_14  free_load_conservation_1445  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_15  arc_capacity_1365  -30
    arc_2_20_15  connected_order_arc_1366  -12
    arc_2_20_15  in_degree_1411  1
    arc_2_20_15  out_degree_1440  1
    arc_2_20_15  original_T_including_depot_unload_1448  2.2299340442558691e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_15  arc_capacity_1365  1
    load_2_20_15  free_load_conservation_1415  -1
    load_2_20_15  free_load_conservation_1445  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_16  arc_capacity_1367  -30
    arc_2_20_16  connected_order_arc_1368  -12
    arc_2_20_16  in_degree_1417  1
    arc_2_20_16  out_degree_1440  1
    arc_2_20_16  original_T_including_depot_unload_1448  1.5460798335742169e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_16  arc_capacity_1367  1
    load_2_20_16  free_load_conservation_1421  -1
    load_2_20_16  free_load_conservation_1445  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_17  arc_capacity_1369  -30
    arc_2_20_17  connected_order_arc_1370  -12
    arc_2_20_17  in_degree_1423  1
    arc_2_20_17  out_degree_1440  1
    arc_2_20_17  original_T_including_depot_unload_1448  1.7807233899807140e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_17  arc_capacity_1369  1
    load_2_20_17  free_load_conservation_1427  -1
    load_2_20_17  free_load_conservation_1445  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_18  arc_capacity_1371  -30
    arc_2_20_18  connected_order_arc_1372  -12
    arc_2_20_18  in_degree_1429  1
    arc_2_20_18  out_degree_1440  1
    arc_2_20_18  original_T_including_depot_unload_1448  2.8083660458664087e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_18  arc_capacity_1371  1
    load_2_20_18  free_load_conservation_1433  -1
    load_2_20_18  free_load_conservation_1445  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_19  arc_capacity_1373  -30
    arc_2_20_19  connected_order_arc_1374  -12
    arc_2_20_19  in_degree_1435  1
    arc_2_20_19  out_degree_1440  1
    arc_2_20_19  original_T_including_depot_unload_1448  1.5971628811503840e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_19  arc_capacity_1373  1
    load_2_20_19  free_load_conservation_1439  -1
    load_2_20_19  free_load_conservation_1445  1
RHS
    RHS1      OBJ       -2.4166822943482558e-01
    RHS1      onehot_9_22  1
    RHS1      onehot_11_47  1
    RHS1      onehot_34_82  1
    RHS1      onehot_10_99  1
    RHS1      onehot_29_124  1
    RHS1      onehot_13_145  1
    RHS1      onehot_27_162  1
    RHS1      onehot_8_191  1
    RHS1      stock_ub_195  26
    RHS1      parent_nonstrict_scope_196  2.7123372157295011e-01
    RHS1      normalization_253  1
    RHS1      connected_order_arc_348  -13
    RHS1      connected_order_arc_350  -13
    RHS1      connected_order_arc_352  -13
    RHS1      connected_order_arc_354  -13
    RHS1      connected_order_arc_356  -13
    RHS1      connected_order_arc_358  -13
    RHS1      connected_order_arc_360  -13
    RHS1      connected_order_arc_362  -13
    RHS1      connected_order_arc_364  -13
    RHS1      connected_order_arc_366  -13
    RHS1      connected_order_arc_368  -13
    RHS1      connected_order_arc_370  -13
    RHS1      connected_order_arc_373  -13
    RHS1      connected_order_arc_375  -13
    RHS1      connected_order_arc_377  -13
    RHS1      connected_order_arc_379  -13
    RHS1      connected_order_arc_381  -13
    RHS1      connected_order_arc_383  -13
    RHS1      connected_order_arc_385  -13
    RHS1      connected_order_arc_387  -13
    RHS1      connected_order_arc_389  -13
    RHS1      connected_order_arc_391  -13
    RHS1      connected_order_arc_393  -13
    RHS1      connected_order_arc_395  -13
    RHS1      connected_order_arc_398  -13
    RHS1      connected_order_arc_400  -13
    RHS1      connected_order_arc_402  -13
    RHS1      connected_order_arc_404  -13
    RHS1      connected_order_arc_406  -13
    RHS1      connected_order_arc_408  -13
    RHS1      connected_order_arc_410  -13
    RHS1      connected_order_arc_412  -13
    RHS1      connected_order_arc_414  -13
    RHS1      connected_order_arc_416  -13
    RHS1      connected_order_arc_418  -13
    RHS1      connected_order_arc_420  -13
    RHS1      connected_order_arc_423  -13
    RHS1      connected_order_arc_425  -13
    RHS1      connected_order_arc_427  -13
    RHS1      connected_order_arc_429  -13
    RHS1      connected_order_arc_431  -13
    RHS1      connected_order_arc_433  -13
    RHS1      connected_order_arc_435  -13
    RHS1      connected_order_arc_437  -13
    RHS1      connected_order_arc_439  -13
    RHS1      connected_order_arc_441  -13
    RHS1      connected_order_arc_443  -13
    RHS1      connected_order_arc_445  -13
    RHS1      connected_order_arc_448  -13
    RHS1      connected_order_arc_450  -13
    RHS1      connected_order_arc_452  -13
    RHS1      connected_order_arc_454  -13
    RHS1      connected_order_arc_456  -13
    RHS1      connected_order_arc_458  -13
    RHS1      connected_order_arc_460  -13
    RHS1      connected_order_arc_462  -13
    RHS1      connected_order_arc_464  -13
    RHS1      connected_order_arc_466  -13
    RHS1      connected_order_arc_468  -13
    RHS1      connected_order_arc_470  -13
    RHS1      connected_order_arc_473  -13
    RHS1      connected_order_arc_475  -13
    RHS1      connected_order_arc_477  -13
    RHS1      connected_order_arc_479  -13
    RHS1      connected_order_arc_481  -13
    RHS1      connected_order_arc_483  -13
    RHS1      connected_order_arc_485  -13
    RHS1      connected_order_arc_487  -13
    RHS1      connected_order_arc_489  -13
    RHS1      connected_order_arc_491  -13
    RHS1      connected_order_arc_493  -13
    RHS1      connected_order_arc_495  -13
    RHS1      connected_order_arc_498  -13
    RHS1      connected_order_arc_500  -13
    RHS1      connected_order_arc_502  -13
    RHS1      connected_order_arc_504  -13
    RHS1      connected_order_arc_506  -13
    RHS1      connected_order_arc_508  -13
    RHS1      connected_order_arc_510  -13
    RHS1      connected_order_arc_512  -13
    RHS1      connected_order_arc_514  -13
    RHS1      connected_order_arc_516  -13
    RHS1      connected_order_arc_518  -13
    RHS1      connected_order_arc_520  -13
    RHS1      connected_order_arc_523  -13
    RHS1      connected_order_arc_525  -13
    RHS1      connected_order_arc_527  -13
    RHS1      connected_order_arc_529  -13
    RHS1      connected_order_arc_531  -13
    RHS1      connected_order_arc_533  -13
    RHS1      connected_order_arc_535  -13
    RHS1      connected_order_arc_537  -13
    RHS1      connected_order_arc_539  -13
    RHS1      connected_order_arc_541  -13
    RHS1      connected_order_arc_543  -13
    RHS1      connected_order_arc_545  -13
    RHS1      connected_order_arc_548  -13
    RHS1      connected_order_arc_550  -13
    RHS1      connected_order_arc_552  -13
    RHS1      connected_order_arc_554  -13
    RHS1      connected_order_arc_556  -13
    RHS1      connected_order_arc_558  -13
    RHS1      connected_order_arc_560  -13
    RHS1      connected_order_arc_562  -13
    RHS1      connected_order_arc_564  -13
    RHS1      connected_order_arc_566  -13
    RHS1      connected_order_arc_568  -13
    RHS1      connected_order_arc_570  -13
    RHS1      connected_order_arc_573  -13
    RHS1      connected_order_arc_575  -13
    RHS1      connected_order_arc_577  -13
    RHS1      connected_order_arc_579  -13
    RHS1      connected_order_arc_581  -13
    RHS1      connected_order_arc_583  -13
    RHS1      connected_order_arc_585  -13
    RHS1      connected_order_arc_587  -13
    RHS1      connected_order_arc_589  -13
    RHS1      connected_order_arc_591  -13
    RHS1      connected_order_arc_593  -13
    RHS1      connected_order_arc_595  -13
    RHS1      connected_order_arc_598  -13
    RHS1      connected_order_arc_600  -13
    RHS1      connected_order_arc_602  -13
    RHS1      connected_order_arc_604  -13
    RHS1      connected_order_arc_606  -13
    RHS1      connected_order_arc_608  -13
    RHS1      connected_order_arc_610  -13
    RHS1      connected_order_arc_612  -13
    RHS1      connected_order_arc_614  -13
    RHS1      connected_order_arc_616  -13
    RHS1      connected_order_arc_618  -13
    RHS1      connected_order_arc_620  -13
    RHS1      connected_order_arc_623  -13
    RHS1      connected_order_arc_625  -13
    RHS1      connected_order_arc_627  -13
    RHS1      connected_order_arc_629  -13
    RHS1      connected_order_arc_631  -13
    RHS1      connected_order_arc_633  -13
    RHS1      connected_order_arc_635  -13
    RHS1      connected_order_arc_637  -13
    RHS1      connected_order_arc_639  -13
    RHS1      connected_order_arc_641  -13
    RHS1      connected_order_arc_643  -13
    RHS1      connected_order_arc_645  -13
    RHS1      connected_order_arc_648  -13
    RHS1      connected_order_arc_650  -13
    RHS1      connected_order_arc_652  -13
    RHS1      connected_order_arc_654  -13
    RHS1      connected_order_arc_656  -13
    RHS1      connected_order_arc_658  -13
    RHS1      connected_order_arc_660  -13
    RHS1      connected_order_arc_662  -13
    RHS1      connected_order_arc_664  -13
    RHS1      connected_order_arc_666  -13
    RHS1      connected_order_arc_668  -13
    RHS1      connected_order_arc_670  -13
    RHS1      depot_departure_or_bypass_671  1
    RHS1      depot_return_or_bypass_672  1
    RHS1      segment_load_conservation_677  3
    RHS1      segment_prefix_ub_679  17
    RHS1      segment_prefix_lb_685  4
    RHS1      segment_prefix_ub_686  20
    RHS1      segment_load_conservation_691  -9
    RHS1      segment_prefix_lb_692  9
    RHS1      segment_prefix_ub_693  20
    RHS1      segment_load_conservation_698  1
    RHS1      segment_prefix_ub_700  19
    RHS1      segment_prefix_ub_707  15
    RHS1      fixed_segment_relative_order_756  1
    RHS1      fixed_segment_relative_order_757  1
    RHS1      fixed_segment_relative_order_758  1
    RHS1      fixed_segment_relative_order_759  1
    RHS1      original_T_including_depot_unload_760  3.8312061132260587e+03
    RHS1      connected_order_arc_776  -12
    RHS1      connected_order_arc_778  -12
    RHS1      connected_order_arc_780  -12
    RHS1      connected_order_arc_782  -12
    RHS1      connected_order_arc_784  -12
    RHS1      connected_order_arc_786  -12
    RHS1      connected_order_arc_788  -12
    RHS1      connected_order_arc_790  -12
    RHS1      connected_order_arc_792  -12
    RHS1      connected_order_arc_794  -12
    RHS1      connected_order_arc_796  -12
    RHS1      connected_order_arc_799  -12
    RHS1      connected_order_arc_801  -12
    RHS1      connected_order_arc_803  -12
    RHS1      connected_order_arc_805  -12
    RHS1      connected_order_arc_807  -12
    RHS1      connected_order_arc_809  -12
    RHS1      connected_order_arc_811  -12
    RHS1      connected_order_arc_813  -12
    RHS1      connected_order_arc_815  -12
    RHS1      connected_order_arc_817  -12
    RHS1      connected_order_arc_819  -12
    RHS1      connected_order_arc_822  -12
    RHS1      connected_order_arc_824  -12
    RHS1      connected_order_arc_826  -12
    RHS1      connected_order_arc_828  -12
    RHS1      connected_order_arc_830  -12
    RHS1      connected_order_arc_832  -12
    RHS1      connected_order_arc_834  -12
    RHS1      connected_order_arc_836  -12
    RHS1      connected_order_arc_838  -12
    RHS1      connected_order_arc_840  -12
    RHS1      connected_order_arc_842  -12
    RHS1      connected_order_arc_845  -12
    RHS1      connected_order_arc_847  -12
    RHS1      connected_order_arc_849  -12
    RHS1      connected_order_arc_851  -12
    RHS1      connected_order_arc_853  -12
    RHS1      connected_order_arc_855  -12
    RHS1      connected_order_arc_857  -12
    RHS1      connected_order_arc_859  -12
    RHS1      connected_order_arc_861  -12
    RHS1      connected_order_arc_863  -12
    RHS1      connected_order_arc_865  -12
    RHS1      connected_order_arc_868  -12
    RHS1      connected_order_arc_870  -12
    RHS1      connected_order_arc_872  -12
    RHS1      connected_order_arc_874  -12
    RHS1      connected_order_arc_876  -12
    RHS1      connected_order_arc_878  -12
    RHS1      connected_order_arc_880  -12
    RHS1      connected_order_arc_882  -12
    RHS1      connected_order_arc_884  -12
    RHS1      connected_order_arc_886  -12
    RHS1      connected_order_arc_888  -12
    RHS1      connected_order_arc_891  -12
    RHS1      connected_order_arc_893  -12
    RHS1      connected_order_arc_895  -12
    RHS1      connected_order_arc_897  -12
    RHS1      connected_order_arc_899  -12
    RHS1      connected_order_arc_901  -12
    RHS1      connected_order_arc_903  -12
    RHS1      connected_order_arc_905  -12
    RHS1      connected_order_arc_907  -12
    RHS1      connected_order_arc_909  -12
    RHS1      connected_order_arc_911  -12
    RHS1      connected_order_arc_914  -12
    RHS1      connected_order_arc_916  -12
    RHS1      connected_order_arc_918  -12
    RHS1      connected_order_arc_920  -12
    RHS1      connected_order_arc_922  -12
    RHS1      connected_order_arc_924  -12
    RHS1      connected_order_arc_926  -12
    RHS1      connected_order_arc_928  -12
    RHS1      connected_order_arc_930  -12
    RHS1      connected_order_arc_932  -12
    RHS1      connected_order_arc_934  -12
    RHS1      connected_order_arc_937  -12
    RHS1      connected_order_arc_939  -12
    RHS1      connected_order_arc_941  -12
    RHS1      connected_order_arc_943  -12
    RHS1      connected_order_arc_945  -12
    RHS1      connected_order_arc_947  -12
    RHS1      connected_order_arc_949  -12
    RHS1      connected_order_arc_951  -12
    RHS1      connected_order_arc_953  -12
    RHS1      connected_order_arc_955  -12
    RHS1      connected_order_arc_957  -12
    RHS1      connected_order_arc_960  -12
    RHS1      connected_order_arc_962  -12
    RHS1      connected_order_arc_964  -12
    RHS1      connected_order_arc_966  -12
    RHS1      connected_order_arc_968  -12
    RHS1      connected_order_arc_970  -12
    RHS1      connected_order_arc_972  -12
    RHS1      connected_order_arc_974  -12
    RHS1      connected_order_arc_976  -12
    RHS1      connected_order_arc_978  -12
    RHS1      connected_order_arc_980  -12
    RHS1      connected_order_arc_983  -12
    RHS1      connected_order_arc_985  -12
    RHS1      connected_order_arc_987  -12
    RHS1      connected_order_arc_989  -12
    RHS1      connected_order_arc_991  -12
    RHS1      connected_order_arc_993  -12
    RHS1      connected_order_arc_995  -12
    RHS1      connected_order_arc_997  -12
    RHS1      connected_order_arc_999  -12
    RHS1      connected_order_arc_1001  -12
    RHS1      connected_order_arc_1003  -12
    RHS1      connected_order_arc_1006  -12
    RHS1      connected_order_arc_1008  -12
    RHS1      connected_order_arc_1010  -12
    RHS1      connected_order_arc_1012  -12
    RHS1      connected_order_arc_1014  -12
    RHS1      connected_order_arc_1016  -12
    RHS1      connected_order_arc_1018  -12
    RHS1      connected_order_arc_1020  -12
    RHS1      connected_order_arc_1022  -12
    RHS1      connected_order_arc_1024  -12
    RHS1      connected_order_arc_1026  -12
    RHS1      connected_order_arc_1029  -12
    RHS1      connected_order_arc_1031  -12
    RHS1      connected_order_arc_1033  -12
    RHS1      connected_order_arc_1035  -12
    RHS1      connected_order_arc_1037  -12
    RHS1      connected_order_arc_1039  -12
    RHS1      connected_order_arc_1041  -12
    RHS1      connected_order_arc_1043  -12
    RHS1      connected_order_arc_1045  -12
    RHS1      connected_order_arc_1047  -12
    RHS1      connected_order_arc_1049  -12
    RHS1      depot_departure_or_bypass_1050  1
    RHS1      depot_return_or_bypass_1051  1
    RHS1      segment_load_conservation_1056  4
    RHS1      segment_prefix_ub_1058  20
    RHS1      segment_load_conservation_1063  5
    RHS1      segment_prefix_ub_1065  20
    RHS1      segment_load_conservation_1070  -4
    RHS1      segment_prefix_lb_1071  4
    RHS1      segment_prefix_ub_1072  25
    RHS1      segment_load_conservation_1077  -5
    RHS1      segment_prefix_lb_1078  5
    RHS1      segment_prefix_ub_1079  25
    RHS1      fixed_segment_relative_order_1128  1
    RHS1      fixed_segment_relative_order_1129  1
    RHS1      fixed_segment_relative_order_1130  1
    RHS1      original_T_including_depot_unload_1131  4.0180155701548429e+03
    RHS1      connected_order_arc_1146  -11
    RHS1      connected_order_arc_1148  -11
    RHS1      connected_order_arc_1150  -11
    RHS1      connected_order_arc_1152  -11
    RHS1      connected_order_arc_1154  -11
    RHS1      connected_order_arc_1156  -11
    RHS1      connected_order_arc_1158  -11
    RHS1      connected_order_arc_1160  -11
    RHS1      connected_order_arc_1162  -11
    RHS1      connected_order_arc_1164  -11
    RHS1      connected_order_arc_1167  -11
    RHS1      connected_order_arc_1169  -11
    RHS1      connected_order_arc_1171  -11
    RHS1      connected_order_arc_1173  -11
    RHS1      connected_order_arc_1175  -11
    RHS1      connected_order_arc_1177  -11
    RHS1      connected_order_arc_1179  -11
    RHS1      connected_order_arc_1181  -11
    RHS1      connected_order_arc_1183  -11
    RHS1      connected_order_arc_1185  -11
    RHS1      connected_order_arc_1188  -11
    RHS1      connected_order_arc_1190  -11
    RHS1      connected_order_arc_1192  -11
    RHS1      connected_order_arc_1194  -11
    RHS1      connected_order_arc_1196  -11
    RHS1      connected_order_arc_1198  -11
    RHS1      connected_order_arc_1200  -11
    RHS1      connected_order_arc_1202  -11
    RHS1      connected_order_arc_1204  -11
    RHS1      connected_order_arc_1206  -11
    RHS1      connected_order_arc_1209  -11
    RHS1      connected_order_arc_1211  -11
    RHS1      connected_order_arc_1213  -11
    RHS1      connected_order_arc_1215  -11
    RHS1      connected_order_arc_1217  -11
    RHS1      connected_order_arc_1219  -11
    RHS1      connected_order_arc_1221  -11
    RHS1      connected_order_arc_1223  -11
    RHS1      connected_order_arc_1225  -11
    RHS1      connected_order_arc_1227  -11
    RHS1      connected_order_arc_1230  -11
    RHS1      connected_order_arc_1232  -11
    RHS1      connected_order_arc_1234  -11
    RHS1      connected_order_arc_1236  -11
    RHS1      connected_order_arc_1238  -11
    RHS1      connected_order_arc_1240  -11
    RHS1      connected_order_arc_1242  -11
    RHS1      connected_order_arc_1244  -11
    RHS1      connected_order_arc_1246  -11
    RHS1      connected_order_arc_1248  -11
    RHS1      connected_order_arc_1251  -11
    RHS1      connected_order_arc_1253  -11
    RHS1      connected_order_arc_1255  -11
    RHS1      connected_order_arc_1257  -11
    RHS1      connected_order_arc_1259  -11
    RHS1      connected_order_arc_1261  -11
    RHS1      connected_order_arc_1263  -11
    RHS1      connected_order_arc_1265  -11
    RHS1      connected_order_arc_1267  -11
    RHS1      connected_order_arc_1269  -11
    RHS1      connected_order_arc_1272  -11
    RHS1      connected_order_arc_1274  -11
    RHS1      connected_order_arc_1276  -11
    RHS1      connected_order_arc_1278  -11
    RHS1      connected_order_arc_1280  -11
    RHS1      connected_order_arc_1282  -11
    RHS1      connected_order_arc_1284  -11
    RHS1      connected_order_arc_1286  -11
    RHS1      connected_order_arc_1288  -11
    RHS1      connected_order_arc_1290  -11
    RHS1      connected_order_arc_1293  -11
    RHS1      connected_order_arc_1295  -11
    RHS1      connected_order_arc_1297  -11
    RHS1      connected_order_arc_1299  -11
    RHS1      connected_order_arc_1301  -11
    RHS1      connected_order_arc_1303  -11
    RHS1      connected_order_arc_1305  -11
    RHS1      connected_order_arc_1307  -11
    RHS1      connected_order_arc_1309  -11
    RHS1      connected_order_arc_1311  -11
    RHS1      connected_order_arc_1314  -11
    RHS1      connected_order_arc_1316  -11
    RHS1      connected_order_arc_1318  -11
    RHS1      connected_order_arc_1320  -11
    RHS1      connected_order_arc_1322  -11
    RHS1      connected_order_arc_1324  -11
    RHS1      connected_order_arc_1326  -11
    RHS1      connected_order_arc_1328  -11
    RHS1      connected_order_arc_1330  -11
    RHS1      connected_order_arc_1332  -11
    RHS1      connected_order_arc_1335  -11
    RHS1      connected_order_arc_1337  -11
    RHS1      connected_order_arc_1339  -11
    RHS1      connected_order_arc_1341  -11
    RHS1      connected_order_arc_1343  -11
    RHS1      connected_order_arc_1345  -11
    RHS1      connected_order_arc_1347  -11
    RHS1      connected_order_arc_1349  -11
    RHS1      connected_order_arc_1351  -11
    RHS1      connected_order_arc_1353  -11
    RHS1      connected_order_arc_1356  -11
    RHS1      connected_order_arc_1358  -11
    RHS1      connected_order_arc_1360  -11
    RHS1      connected_order_arc_1362  -11
    RHS1      connected_order_arc_1364  -11
    RHS1      connected_order_arc_1366  -11
    RHS1      connected_order_arc_1368  -11
    RHS1      connected_order_arc_1370  -11
    RHS1      connected_order_arc_1372  -11
    RHS1      connected_order_arc_1374  -11
    RHS1      depot_departure_or_bypass_1375  1
    RHS1      depot_return_or_bypass_1376  1
    RHS1      segment_load_conservation_1381  2
    RHS1      segment_prefix_ub_1383  28
    RHS1      segment_load_conservation_1388  1
    RHS1      segment_prefix_lb_1389  2
    RHS1      segment_prefix_ub_1390  28
    RHS1      segment_load_conservation_1395  -3
    RHS1      segment_prefix_lb_1396  3
    RHS1      segment_prefix_ub_1397  30
    RHS1      fixed_segment_relative_order_1446  1
    RHS1      fixed_segment_relative_order_1447  1
    RHS1      original_T_including_depot_unload_1448  3.3317427925191068e+03
BOUNDS
 LO BND1      t         2.5996533795467933e-02
 UP BND1      t         4.4264109184846939e-02
 UP BND1      q         4.1562025520412310e-01
 BV BND1      x_9_0   
 UP BND1      w_9_0     4.4264109184846939e-02
 BV BND1      x_9_1   
 UP BND1      w_9_1     4.4264109184846939e-02
 BV BND1      x_9_2   
 UP BND1      w_9_2     4.4264109184846939e-02
 BV BND1      x_9_3   
 UP BND1      w_9_3     4.4264109184846939e-02
 BV BND1      x_9_4   
 UP BND1      w_9_4     4.4264109184846939e-02
 BV BND1      x_9_5   
 UP BND1      w_9_5     4.4264109184846939e-02
 BV BND1      x_9_6   
 UP BND1      w_9_6     4.4264109184846939e-02
 BV BND1      x_9_7   
 UP BND1      w_9_7     4.4264109184846939e-02
 BV BND1      x_9_8   
 UP BND1      w_9_8     4.4264109184846939e-02
 BV BND1      x_9_9   
 UP BND1      w_9_9     4.4264109184846939e-02
 BV BND1      x_9_10  
 UP BND1      w_9_10    4.4264109184846939e-02
 UP BND1      rho_9     1
 BV BND1      x_11_0  
 UP BND1      w_11_0    4.4264109184846939e-02
 BV BND1      x_11_1  
 UP BND1      w_11_1    4.4264109184846939e-02
 BV BND1      x_11_2  
 UP BND1      w_11_2    4.4264109184846939e-02
 BV BND1      x_11_3  
 UP BND1      w_11_3    4.4264109184846939e-02
 BV BND1      x_11_4  
 UP BND1      w_11_4    4.4264109184846939e-02
 BV BND1      x_11_5  
 UP BND1      w_11_5    4.4264109184846939e-02
 BV BND1      x_11_6  
 UP BND1      w_11_6    4.4264109184846939e-02
 BV BND1      x_11_7  
 UP BND1      w_11_7    4.4264109184846939e-02
 BV BND1      x_11_8  
 UP BND1      w_11_8    4.4264109184846939e-02
 BV BND1      x_11_9  
 UP BND1      w_11_9    4.4264109184846939e-02
 BV BND1      x_11_10 
 UP BND1      w_11_10   4.4264109184846939e-02
 UP BND1      rho_11    1
 BV BND1      x_34_0  
 UP BND1      w_34_0    4.4264109184846939e-02
 BV BND1      x_34_1  
 UP BND1      w_34_1    4.4264109184846939e-02
 BV BND1      x_34_2  
 UP BND1      w_34_2    4.4264109184846939e-02
 BV BND1      x_34_3  
 UP BND1      w_34_3    4.4264109184846939e-02
 BV BND1      x_34_4  
 UP BND1      w_34_4    4.4264109184846939e-02
 BV BND1      x_34_5  
 UP BND1      w_34_5    4.4264109184846939e-02
 BV BND1      x_34_6  
 UP BND1      w_34_6    4.4264109184846939e-02
 BV BND1      x_34_7  
 UP BND1      w_34_7    4.4264109184846939e-02
 BV BND1      x_34_8  
 UP BND1      w_34_8    4.4264109184846939e-02
 BV BND1      x_34_9  
 UP BND1      w_34_9    4.4264109184846939e-02
 BV BND1      x_34_10 
 UP BND1      w_34_10   4.4264109184846939e-02
 BV BND1      x_34_11 
 UP BND1      w_34_11   4.4264109184846939e-02
 BV BND1      x_34_12 
 UP BND1      w_34_12   4.4264109184846939e-02
 BV BND1      x_34_13 
 UP BND1      w_34_13   4.4264109184846939e-02
 BV BND1      x_34_14 
 UP BND1      w_34_14   4.4264109184846939e-02
 BV BND1      x_34_15 
 UP BND1      w_34_15   4.4264109184846939e-02
 UP BND1      rho_34    1
 BV BND1      x_10_0  
 UP BND1      w_10_0    4.4264109184846939e-02
 BV BND1      x_10_1  
 UP BND1      w_10_1    4.4264109184846939e-02
 BV BND1      x_10_2  
 UP BND1      w_10_2    4.4264109184846939e-02
 BV BND1      x_10_3  
 UP BND1      w_10_3    4.4264109184846939e-02
 BV BND1      x_10_4  
 UP BND1      w_10_4    4.4264109184846939e-02
 BV BND1      x_10_5  
 UP BND1      w_10_5    4.4264109184846939e-02
 BV BND1      x_10_6  
 UP BND1      w_10_6    4.4264109184846939e-02
 UP BND1      rho_10    1
 BV BND1      x_29_0  
 UP BND1      w_29_0    4.4264109184846939e-02
 BV BND1      x_29_1  
 UP BND1      w_29_1    4.4264109184846939e-02
 BV BND1      x_29_2  
 UP BND1      w_29_2    4.4264109184846939e-02
 BV BND1      x_29_3  
 UP BND1      w_29_3    4.4264109184846939e-02
 BV BND1      x_29_4  
 UP BND1      w_29_4    4.4264109184846939e-02
 BV BND1      x_29_5  
 UP BND1      w_29_5    4.4264109184846939e-02
 BV BND1      x_29_6  
 UP BND1      w_29_6    4.4264109184846939e-02
 BV BND1      x_29_7  
 UP BND1      w_29_7    4.4264109184846939e-02
 BV BND1      x_29_8  
 UP BND1      w_29_8    4.4264109184846939e-02
 BV BND1      x_29_9  
 UP BND1      w_29_9    4.4264109184846939e-02
 BV BND1      x_29_10 
 UP BND1      w_29_10   4.4264109184846939e-02
 UP BND1      rho_29    1
 BV BND1      x_13_0  
 UP BND1      w_13_0    4.4264109184846939e-02
 BV BND1      x_13_1  
 UP BND1      w_13_1    4.4264109184846939e-02
 BV BND1      x_13_2  
 UP BND1      w_13_2    4.4264109184846939e-02
 BV BND1      x_13_3  
 UP BND1      w_13_3    4.4264109184846939e-02
 BV BND1      x_13_4  
 UP BND1      w_13_4    4.4264109184846939e-02
 BV BND1      x_13_5  
 UP BND1      w_13_5    4.4264109184846939e-02
 BV BND1      x_13_6  
 UP BND1      w_13_6    4.4264109184846939e-02
 BV BND1      x_13_7  
 UP BND1      w_13_7    4.4264109184846939e-02
 BV BND1      x_13_8  
 UP BND1      w_13_8    4.4264109184846939e-02
 UP BND1      rho_13    1
 BV BND1      x_27_0  
 UP BND1      w_27_0    4.4264109184846939e-02
 BV BND1      x_27_1  
 UP BND1      w_27_1    4.4264109184846939e-02
 BV BND1      x_27_2  
 UP BND1      w_27_2    4.4264109184846939e-02
 BV BND1      x_27_3  
 UP BND1      w_27_3    4.4264109184846939e-02
 BV BND1      x_27_4  
 UP BND1      w_27_4    4.4264109184846939e-02
 BV BND1      x_27_5  
 UP BND1      w_27_5    4.4264109184846939e-02
 BV BND1      x_27_6  
 UP BND1      w_27_6    4.4264109184846939e-02
 UP BND1      rho_27    1
 BV BND1      x_8_0   
 UP BND1      w_8_0     4.4264109184846939e-02
 BV BND1      x_8_1   
 UP BND1      w_8_1     4.4264109184846939e-02
 BV BND1      x_8_2   
 UP BND1      w_8_2     4.4264109184846939e-02
 BV BND1      x_8_3   
 UP BND1      w_8_3     4.4264109184846939e-02
 BV BND1      x_8_4   
 UP BND1      w_8_4     4.4264109184846939e-02
 BV BND1      x_8_5   
 UP BND1      w_8_5     4.4264109184846939e-02
 BV BND1      x_8_6   
 UP BND1      w_8_6     4.4264109184846939e-02
 BV BND1      x_8_7   
 UP BND1      w_8_7     4.4264109184846939e-02
 BV BND1      x_8_8   
 UP BND1      w_8_8     4.4264109184846939e-02
 BV BND1      x_8_9   
 UP BND1      w_8_9     4.4264109184846939e-02
 BV BND1      x_8_10  
 UP BND1      w_8_10    4.4264109184846939e-02
 BV BND1      x_8_11  
 UP BND1      w_8_11    4.4264109184846939e-02
 BV BND1      x_8_12  
 UP BND1      w_8_12    4.4264109184846939e-02
 UP BND1      rho_8     1
 UP BND1      a_9_11    1
 UP BND1      a_9_34    1
 UP BND1      a_9_10    1
 UP BND1      a_9_29    1
 UP BND1      a_9_13    1
 UP BND1      a_9_27    1
 UP BND1      a_9_8     1
 UP BND1      a_11_34   1
 UP BND1      a_11_10   1
 UP BND1      a_11_29   1
 UP BND1      a_11_13   1
 UP BND1      a_11_27   1
 UP BND1      a_11_8    1
 UP BND1      a_34_10   1
 UP BND1      a_34_29   1
 UP BND1      a_34_13   1
 UP BND1      a_34_27   1
 UP BND1      a_34_8    1
 UP BND1      a_10_29   1
 UP BND1      a_10_13   1
 UP BND1      a_10_27   1
 UP BND1      a_10_8    1
 UP BND1      a_29_13   1
 UP BND1      a_29_27   1
 UP BND1      a_29_8    1
 UP BND1      a_13_27   1
 UP BND1      a_13_8    1
 UP BND1      a_27_8    1
 BV BND1      service_0_9_0
 BV BND1      service_0_9_1
 BV BND1      service_0_9_3
 BV BND1      service_0_9_4
 BV BND1      service_0_9_5
 BV BND1      service_0_9_6
 BV BND1      service_0_9_7
 BV BND1      service_0_9_8
 BV BND1      service_0_9_9
 BV BND1      service_0_9_10
 BV BND1      service_1_9_0
 BV BND1      service_1_9_1
 BV BND1      service_1_9_3
 BV BND1      service_1_9_4
 BV BND1      service_1_9_5
 BV BND1      service_1_9_6
 BV BND1      service_1_9_7
 BV BND1      service_1_9_8
 BV BND1      service_1_9_9
 BV BND1      service_1_9_10
 BV BND1      service_2_9_0
 BV BND1      service_2_9_1
 BV BND1      service_2_9_3
 BV BND1      service_2_9_4
 BV BND1      service_2_9_5
 BV BND1      service_2_9_6
 BV BND1      service_2_9_7
 BV BND1      service_2_9_8
 BV BND1      service_2_9_9
 BV BND1      service_2_9_10
 BV BND1      service_0_11_0
 BV BND1      service_0_11_1
 BV BND1      service_0_11_2
 BV BND1      service_0_11_3
 BV BND1      service_0_11_4
 BV BND1      service_0_11_5
 BV BND1      service_0_11_6
 BV BND1      service_0_11_7
 BV BND1      service_0_11_9
 BV BND1      service_0_11_10
 BV BND1      service_1_11_0
 BV BND1      service_1_11_1
 BV BND1      service_1_11_2
 BV BND1      service_1_11_3
 BV BND1      service_1_11_4
 BV BND1      service_1_11_5
 BV BND1      service_1_11_6
 BV BND1      service_1_11_7
 BV BND1      service_1_11_9
 BV BND1      service_1_11_10
 BV BND1      service_2_11_0
 BV BND1      service_2_11_1
 BV BND1      service_2_11_2
 BV BND1      service_2_11_3
 BV BND1      service_2_11_4
 BV BND1      service_2_11_5
 BV BND1      service_2_11_6
 BV BND1      service_2_11_7
 BV BND1      service_2_11_9
 BV BND1      service_2_11_10
 BV BND1      service_0_34_0
 BV BND1      service_0_34_1
 BV BND1      service_0_34_3
 BV BND1      service_0_34_4
 BV BND1      service_0_34_5
 BV BND1      service_0_34_6
 BV BND1      service_0_34_7
 BV BND1      service_0_34_8
 BV BND1      service_0_34_9
 BV BND1      service_0_34_10
 BV BND1      service_0_34_11
 BV BND1      service_0_34_12
 BV BND1      service_0_34_13
 BV BND1      service_0_34_14
 BV BND1      service_0_34_15
 BV BND1      service_1_34_0
 BV BND1      service_1_34_1
 BV BND1      service_1_34_3
 BV BND1      service_1_34_4
 BV BND1      service_1_34_5
 BV BND1      service_1_34_6
 BV BND1      service_1_34_7
 BV BND1      service_1_34_8
 BV BND1      service_1_34_9
 BV BND1      service_1_34_10
 BV BND1      service_1_34_11
 BV BND1      service_1_34_12
 BV BND1      service_1_34_13
 BV BND1      service_1_34_14
 BV BND1      service_1_34_15
 BV BND1      service_2_34_0
 BV BND1      service_2_34_1
 BV BND1      service_2_34_3
 BV BND1      service_2_34_4
 BV BND1      service_2_34_5
 BV BND1      service_2_34_6
 BV BND1      service_2_34_7
 BV BND1      service_2_34_8
 BV BND1      service_2_34_9
 BV BND1      service_2_34_10
 BV BND1      service_2_34_11
 BV BND1      service_2_34_12
 BV BND1      service_2_34_13
 BV BND1      service_2_34_14
 BV BND1      service_2_34_15
 BV BND1      service_0_10_0
 BV BND1      service_0_10_1
 BV BND1      service_0_10_2
 BV BND1      service_0_10_3
 BV BND1      service_0_10_5
 BV BND1      service_0_10_6
 BV BND1      service_1_10_0
 BV BND1      service_1_10_1
 BV BND1      service_1_10_2
 BV BND1      service_1_10_3
 BV BND1      service_1_10_5
 BV BND1      service_1_10_6
 BV BND1      service_2_10_0
 BV BND1      service_2_10_1
 BV BND1      service_2_10_2
 BV BND1      service_2_10_3
 BV BND1      service_2_10_5
 BV BND1      service_2_10_6
 BV BND1      service_0_29_0
 BV BND1      service_0_29_2
 BV BND1      service_0_29_3
 BV BND1      service_0_29_4
 BV BND1      service_0_29_5
 BV BND1      service_0_29_6
 BV BND1      service_0_29_7
 BV BND1      service_0_29_8
 BV BND1      service_0_29_9
 BV BND1      service_0_29_10
 BV BND1      service_1_29_0
 BV BND1      service_1_29_2
 BV BND1      service_1_29_3
 BV BND1      service_1_29_4
 BV BND1      service_1_29_5
 BV BND1      service_1_29_6
 BV BND1      service_1_29_7
 BV BND1      service_1_29_8
 BV BND1      service_1_29_9
 BV BND1      service_1_29_10
 BV BND1      service_2_29_0
 BV BND1      service_2_29_2
 BV BND1      service_2_29_3
 BV BND1      service_2_29_4
 BV BND1      service_2_29_5
 BV BND1      service_2_29_6
 BV BND1      service_2_29_7
 BV BND1      service_2_29_8
 BV BND1      service_2_29_9
 BV BND1      service_2_29_10
 BV BND1      service_0_13_0
 BV BND1      service_0_13_1
 BV BND1      service_0_13_2
 BV BND1      service_0_13_3
 BV BND1      service_0_13_4
 BV BND1      service_0_13_6
 BV BND1      service_0_13_7
 BV BND1      service_0_13_8
 BV BND1      service_1_13_0
 BV BND1      service_1_13_1
 BV BND1      service_1_13_2
 BV BND1      service_1_13_3
 BV BND1      service_1_13_4
 BV BND1      service_1_13_6
 BV BND1      service_1_13_7
 BV BND1      service_1_13_8
 BV BND1      service_2_13_0
 BV BND1      service_2_13_1
 BV BND1      service_2_13_2
 BV BND1      service_2_13_3
 BV BND1      service_2_13_4
 BV BND1      service_2_13_6
 BV BND1      service_2_13_7
 BV BND1      service_2_13_8
 BV BND1      service_0_27_1
 BV BND1      service_0_27_2
 BV BND1      service_0_27_3
 BV BND1      service_0_27_4
 BV BND1      service_0_27_5
 BV BND1      service_0_27_6
 BV BND1      service_1_27_1
 BV BND1      service_1_27_2
 BV BND1      service_1_27_3
 BV BND1      service_1_27_4
 BV BND1      service_1_27_5
 BV BND1      service_1_27_6
 BV BND1      service_2_27_1
 BV BND1      service_2_27_2
 BV BND1      service_2_27_3
 BV BND1      service_2_27_4
 BV BND1      service_2_27_5
 BV BND1      service_2_27_6
 BV BND1      service_0_8_0
 BV BND1      service_0_8_1
 BV BND1      service_0_8_2
 BV BND1      service_0_8_3
 BV BND1      service_0_8_4
 BV BND1      service_0_8_5
 BV BND1      service_0_8_6
 BV BND1      service_0_8_7
 BV BND1      service_0_8_8
 BV BND1      service_0_8_10
 BV BND1      service_0_8_11
 BV BND1      service_0_8_12
 BV BND1      service_1_8_0
 BV BND1      service_1_8_1
 BV BND1      service_1_8_2
 BV BND1      service_1_8_3
 BV BND1      service_1_8_4
 BV BND1      service_1_8_5
 BV BND1      service_1_8_6
 BV BND1      service_1_8_7
 BV BND1      service_1_8_8
 BV BND1      service_1_8_10
 BV BND1      service_1_8_11
 BV BND1      service_1_8_12
 BV BND1      service_2_8_0
 BV BND1      service_2_8_1
 BV BND1      service_2_8_2
 BV BND1      service_2_8_3
 BV BND1      service_2_8_4
 BV BND1      service_2_8_5
 BV BND1      service_2_8_6
 BV BND1      service_2_8_7
 BV BND1      service_2_8_8
 BV BND1      service_2_8_10
 BV BND1      service_2_8_11
 BV BND1      service_2_8_12
 FX BND1      visit_0_1  1
 UP BND1      order_0_1  13
 FX BND1      visit_0_2  1
 UP BND1      order_0_2  13
 FX BND1      visit_0_3  1
 UP BND1      order_0_3  13
 FX BND1      visit_0_4  1
 UP BND1      order_0_4  13
 FX BND1      visit_0_5  1
 UP BND1      order_0_5  13
 UP BND1      visit_0_13  1
 UP BND1      order_0_13  13
 UP BND1      visit_0_14  1
 UP BND1      order_0_14  13
 UP BND1      visit_0_15  1
 UP BND1      order_0_15  13
 UP BND1      visit_0_16  1
 UP BND1      order_0_16  13
 UP BND1      visit_0_17  1
 UP BND1      order_0_17  13
 UP BND1      visit_0_18  1
 UP BND1      order_0_18  13
 UP BND1      visit_0_19  1
 UP BND1      order_0_19  13
 UP BND1      visit_0_20  1
 UP BND1      order_0_20  13
 BV BND1      arc_0_0_0
 FX BND1      load_0_0_0  0
 BV BND1      arc_0_0_1
 FX BND1      load_0_0_1  0
 BV BND1      arc_0_0_2
 FX BND1      load_0_0_2  0
 BV BND1      arc_0_0_3
 FX BND1      load_0_0_3  0
 BV BND1      arc_0_0_4
 FX BND1      load_0_0_4  0
 BV BND1      arc_0_0_5
 FX BND1      load_0_0_5  0
 BV BND1      arc_0_0_13
 FX BND1      load_0_0_13  0
 BV BND1      arc_0_0_14
 FX BND1      load_0_0_14  0
 BV BND1      arc_0_0_15
 FX BND1      load_0_0_15  0
 BV BND1      arc_0_0_16
 FX BND1      load_0_0_16  0
 BV BND1      arc_0_0_17
 FX BND1      load_0_0_17  0
 BV BND1      arc_0_0_18
 FX BND1      load_0_0_18  0
 BV BND1      arc_0_0_19
 FX BND1      load_0_0_19  0
 BV BND1      arc_0_0_20
 FX BND1      load_0_0_20  0
 BV BND1      arc_0_1_0
 UP BND1      load_0_1_0  20
 BV BND1      arc_0_1_2
 UP BND1      load_0_1_2  20
 BV BND1      arc_0_1_3
 UP BND1      load_0_1_3  20
 BV BND1      arc_0_1_4
 UP BND1      load_0_1_4  20
 BV BND1      arc_0_1_5
 UP BND1      load_0_1_5  20
 BV BND1      arc_0_1_13
 UP BND1      load_0_1_13  20
 BV BND1      arc_0_1_14
 UP BND1      load_0_1_14  20
 BV BND1      arc_0_1_15
 UP BND1      load_0_1_15  20
 BV BND1      arc_0_1_16
 UP BND1      load_0_1_16  20
 BV BND1      arc_0_1_17
 UP BND1      load_0_1_17  20
 BV BND1      arc_0_1_18
 UP BND1      load_0_1_18  20
 BV BND1      arc_0_1_19
 UP BND1      load_0_1_19  20
 BV BND1      arc_0_1_20
 UP BND1      load_0_1_20  20
 BV BND1      arc_0_2_0
 UP BND1      load_0_2_0  20
 BV BND1      arc_0_2_1
 UP BND1      load_0_2_1  20
 BV BND1      arc_0_2_3
 UP BND1      load_0_2_3  20
 BV BND1      arc_0_2_4
 UP BND1      load_0_2_4  20
 BV BND1      arc_0_2_5
 UP BND1      load_0_2_5  20
 BV BND1      arc_0_2_13
 UP BND1      load_0_2_13  20
 BV BND1      arc_0_2_14
 UP BND1      load_0_2_14  20
 BV BND1      arc_0_2_15
 UP BND1      load_0_2_15  20
 BV BND1      arc_0_2_16
 UP BND1      load_0_2_16  20
 BV BND1      arc_0_2_17
 UP BND1      load_0_2_17  20
 BV BND1      arc_0_2_18
 UP BND1      load_0_2_18  20
 BV BND1      arc_0_2_19
 UP BND1      load_0_2_19  20
 BV BND1      arc_0_2_20
 UP BND1      load_0_2_20  20
 BV BND1      arc_0_3_0
 UP BND1      load_0_3_0  20
 BV BND1      arc_0_3_1
 UP BND1      load_0_3_1  20
 BV BND1      arc_0_3_2
 UP BND1      load_0_3_2  20
 BV BND1      arc_0_3_4
 UP BND1      load_0_3_4  20
 BV BND1      arc_0_3_5
 UP BND1      load_0_3_5  20
 BV BND1      arc_0_3_13
 UP BND1      load_0_3_13  20
 BV BND1      arc_0_3_14
 UP BND1      load_0_3_14  20
 BV BND1      arc_0_3_15
 UP BND1      load_0_3_15  20
 BV BND1      arc_0_3_16
 UP BND1      load_0_3_16  20
 BV BND1      arc_0_3_17
 UP BND1      load_0_3_17  20
 BV BND1      arc_0_3_18
 UP BND1      load_0_3_18  20
 BV BND1      arc_0_3_19
 UP BND1      load_0_3_19  20
 BV BND1      arc_0_3_20
 UP BND1      load_0_3_20  20
 BV BND1      arc_0_4_0
 UP BND1      load_0_4_0  20
 BV BND1      arc_0_4_1
 UP BND1      load_0_4_1  20
 BV BND1      arc_0_4_2
 UP BND1      load_0_4_2  20
 BV BND1      arc_0_4_3
 UP BND1      load_0_4_3  20
 BV BND1      arc_0_4_5
 UP BND1      load_0_4_5  20
 BV BND1      arc_0_4_13
 UP BND1      load_0_4_13  20
 BV BND1      arc_0_4_14
 UP BND1      load_0_4_14  20
 BV BND1      arc_0_4_15
 UP BND1      load_0_4_15  20
 BV BND1      arc_0_4_16
 UP BND1      load_0_4_16  20
 BV BND1      arc_0_4_17
 UP BND1      load_0_4_17  20
 BV BND1      arc_0_4_18
 UP BND1      load_0_4_18  20
 BV BND1      arc_0_4_19
 UP BND1      load_0_4_19  20
 BV BND1      arc_0_4_20
 UP BND1      load_0_4_20  20
 BV BND1      arc_0_5_0
 UP BND1      load_0_5_0  20
 BV BND1      arc_0_5_1
 UP BND1      load_0_5_1  20
 BV BND1      arc_0_5_2
 UP BND1      load_0_5_2  20
 BV BND1      arc_0_5_3
 UP BND1      load_0_5_3  20
 BV BND1      arc_0_5_4
 UP BND1      load_0_5_4  20
 BV BND1      arc_0_5_13
 UP BND1      load_0_5_13  20
 BV BND1      arc_0_5_14
 UP BND1      load_0_5_14  20
 BV BND1      arc_0_5_15
 UP BND1      load_0_5_15  20
 BV BND1      arc_0_5_16
 UP BND1      load_0_5_16  20
 BV BND1      arc_0_5_17
 UP BND1      load_0_5_17  20
 BV BND1      arc_0_5_18
 UP BND1      load_0_5_18  20
 BV BND1      arc_0_5_19
 UP BND1      load_0_5_19  20
 BV BND1      arc_0_5_20
 UP BND1      load_0_5_20  20
 BV BND1      arc_0_13_0
 UP BND1      load_0_13_0  20
 BV BND1      arc_0_13_1
 UP BND1      load_0_13_1  20
 BV BND1      arc_0_13_2
 UP BND1      load_0_13_2  20
 BV BND1      arc_0_13_3
 UP BND1      load_0_13_3  20
 BV BND1      arc_0_13_4
 UP BND1      load_0_13_4  20
 BV BND1      arc_0_13_5
 UP BND1      load_0_13_5  20
 BV BND1      arc_0_13_14
 UP BND1      load_0_13_14  20
 BV BND1      arc_0_13_15
 UP BND1      load_0_13_15  20
 BV BND1      arc_0_13_16
 UP BND1      load_0_13_16  20
 BV BND1      arc_0_13_17
 UP BND1      load_0_13_17  20
 BV BND1      arc_0_13_18
 UP BND1      load_0_13_18  20
 BV BND1      arc_0_13_19
 UP BND1      load_0_13_19  20
 BV BND1      arc_0_13_20
 UP BND1      load_0_13_20  20
 BV BND1      arc_0_14_0
 UP BND1      load_0_14_0  20
 BV BND1      arc_0_14_1
 UP BND1      load_0_14_1  20
 BV BND1      arc_0_14_2
 UP BND1      load_0_14_2  20
 BV BND1      arc_0_14_3
 UP BND1      load_0_14_3  20
 BV BND1      arc_0_14_4
 UP BND1      load_0_14_4  20
 BV BND1      arc_0_14_5
 UP BND1      load_0_14_5  20
 BV BND1      arc_0_14_13
 UP BND1      load_0_14_13  20
 BV BND1      arc_0_14_15
 UP BND1      load_0_14_15  20
 BV BND1      arc_0_14_16
 UP BND1      load_0_14_16  20
 BV BND1      arc_0_14_17
 UP BND1      load_0_14_17  20
 BV BND1      arc_0_14_18
 UP BND1      load_0_14_18  20
 BV BND1      arc_0_14_19
 UP BND1      load_0_14_19  20
 BV BND1      arc_0_14_20
 UP BND1      load_0_14_20  20
 BV BND1      arc_0_15_0
 UP BND1      load_0_15_0  20
 BV BND1      arc_0_15_1
 UP BND1      load_0_15_1  20
 BV BND1      arc_0_15_2
 UP BND1      load_0_15_2  20
 BV BND1      arc_0_15_3
 UP BND1      load_0_15_3  20
 BV BND1      arc_0_15_4
 UP BND1      load_0_15_4  20
 BV BND1      arc_0_15_5
 UP BND1      load_0_15_5  20
 BV BND1      arc_0_15_13
 UP BND1      load_0_15_13  20
 BV BND1      arc_0_15_14
 UP BND1      load_0_15_14  20
 BV BND1      arc_0_15_16
 UP BND1      load_0_15_16  20
 BV BND1      arc_0_15_17
 UP BND1      load_0_15_17  20
 BV BND1      arc_0_15_18
 UP BND1      load_0_15_18  20
 BV BND1      arc_0_15_19
 UP BND1      load_0_15_19  20
 BV BND1      arc_0_15_20
 UP BND1      load_0_15_20  20
 BV BND1      arc_0_16_0
 UP BND1      load_0_16_0  20
 BV BND1      arc_0_16_1
 UP BND1      load_0_16_1  20
 BV BND1      arc_0_16_2
 UP BND1      load_0_16_2  20
 BV BND1      arc_0_16_3
 UP BND1      load_0_16_3  20
 BV BND1      arc_0_16_4
 UP BND1      load_0_16_4  20
 BV BND1      arc_0_16_5
 UP BND1      load_0_16_5  20
 BV BND1      arc_0_16_13
 UP BND1      load_0_16_13  20
 BV BND1      arc_0_16_14
 UP BND1      load_0_16_14  20
 BV BND1      arc_0_16_15
 UP BND1      load_0_16_15  20
 BV BND1      arc_0_16_17
 UP BND1      load_0_16_17  20
 BV BND1      arc_0_16_18
 UP BND1      load_0_16_18  20
 BV BND1      arc_0_16_19
 UP BND1      load_0_16_19  20
 BV BND1      arc_0_16_20
 UP BND1      load_0_16_20  20
 BV BND1      arc_0_17_0
 UP BND1      load_0_17_0  20
 BV BND1      arc_0_17_1
 UP BND1      load_0_17_1  20
 BV BND1      arc_0_17_2
 UP BND1      load_0_17_2  20
 BV BND1      arc_0_17_3
 UP BND1      load_0_17_3  20
 BV BND1      arc_0_17_4
 UP BND1      load_0_17_4  20
 BV BND1      arc_0_17_5
 UP BND1      load_0_17_5  20
 BV BND1      arc_0_17_13
 UP BND1      load_0_17_13  20
 BV BND1      arc_0_17_14
 UP BND1      load_0_17_14  20
 BV BND1      arc_0_17_15
 UP BND1      load_0_17_15  20
 BV BND1      arc_0_17_16
 UP BND1      load_0_17_16  20
 BV BND1      arc_0_17_18
 UP BND1      load_0_17_18  20
 BV BND1      arc_0_17_19
 UP BND1      load_0_17_19  20
 BV BND1      arc_0_17_20
 UP BND1      load_0_17_20  20
 BV BND1      arc_0_18_0
 UP BND1      load_0_18_0  20
 BV BND1      arc_0_18_1
 UP BND1      load_0_18_1  20
 BV BND1      arc_0_18_2
 UP BND1      load_0_18_2  20
 BV BND1      arc_0_18_3
 UP BND1      load_0_18_3  20
 BV BND1      arc_0_18_4
 UP BND1      load_0_18_4  20
 BV BND1      arc_0_18_5
 UP BND1      load_0_18_5  20
 BV BND1      arc_0_18_13
 UP BND1      load_0_18_13  20
 BV BND1      arc_0_18_14
 UP BND1      load_0_18_14  20
 BV BND1      arc_0_18_15
 UP BND1      load_0_18_15  20
 BV BND1      arc_0_18_16
 UP BND1      load_0_18_16  20
 BV BND1      arc_0_18_17
 UP BND1      load_0_18_17  20
 BV BND1      arc_0_18_19
 UP BND1      load_0_18_19  20
 BV BND1      arc_0_18_20
 UP BND1      load_0_18_20  20
 BV BND1      arc_0_19_0
 UP BND1      load_0_19_0  20
 BV BND1      arc_0_19_1
 UP BND1      load_0_19_1  20
 BV BND1      arc_0_19_2
 UP BND1      load_0_19_2  20
 BV BND1      arc_0_19_3
 UP BND1      load_0_19_3  20
 BV BND1      arc_0_19_4
 UP BND1      load_0_19_4  20
 BV BND1      arc_0_19_5
 UP BND1      load_0_19_5  20
 BV BND1      arc_0_19_13
 UP BND1      load_0_19_13  20
 BV BND1      arc_0_19_14
 UP BND1      load_0_19_14  20
 BV BND1      arc_0_19_15
 UP BND1      load_0_19_15  20
 BV BND1      arc_0_19_16
 UP BND1      load_0_19_16  20
 BV BND1      arc_0_19_17
 UP BND1      load_0_19_17  20
 BV BND1      arc_0_19_18
 UP BND1      load_0_19_18  20
 BV BND1      arc_0_19_20
 UP BND1      load_0_19_20  20
 BV BND1      arc_0_20_0
 UP BND1      load_0_20_0  20
 BV BND1      arc_0_20_1
 UP BND1      load_0_20_1  20
 BV BND1      arc_0_20_2
 UP BND1      load_0_20_2  20
 BV BND1      arc_0_20_3
 UP BND1      load_0_20_3  20
 BV BND1      arc_0_20_4
 UP BND1      load_0_20_4  20
 BV BND1      arc_0_20_5
 UP BND1      load_0_20_5  20
 BV BND1      arc_0_20_13
 UP BND1      load_0_20_13  20
 BV BND1      arc_0_20_14
 UP BND1      load_0_20_14  20
 BV BND1      arc_0_20_15
 UP BND1      load_0_20_15  20
 BV BND1      arc_0_20_16
 UP BND1      load_0_20_16  20
 BV BND1      arc_0_20_17
 UP BND1      load_0_20_17  20
 BV BND1      arc_0_20_18
 UP BND1      load_0_20_18  20
 BV BND1      arc_0_20_19
 UP BND1      load_0_20_19  20
 FX BND1      visit_1_6  1
 UP BND1      order_1_6  12
 FX BND1      visit_1_7  1
 UP BND1      order_1_7  12
 FX BND1      visit_1_8  1
 UP BND1      order_1_8  12
 FX BND1      visit_1_9  1
 UP BND1      order_1_9  12
 UP BND1      visit_1_13  1
 UP BND1      order_1_13  12
 UP BND1      visit_1_14  1
 UP BND1      order_1_14  12
 UP BND1      visit_1_15  1
 UP BND1      order_1_15  12
 UP BND1      visit_1_16  1
 UP BND1      order_1_16  12
 UP BND1      visit_1_17  1
 UP BND1      order_1_17  12
 UP BND1      visit_1_18  1
 UP BND1      order_1_18  12
 UP BND1      visit_1_19  1
 UP BND1      order_1_19  12
 UP BND1      visit_1_20  1
 UP BND1      order_1_20  12
 BV BND1      arc_1_0_0
 FX BND1      load_1_0_0  0
 BV BND1      arc_1_0_6
 FX BND1      load_1_0_6  0
 BV BND1      arc_1_0_7
 FX BND1      load_1_0_7  0
 BV BND1      arc_1_0_8
 FX BND1      load_1_0_8  0
 BV BND1      arc_1_0_9
 FX BND1      load_1_0_9  0
 BV BND1      arc_1_0_13
 FX BND1      load_1_0_13  0
 BV BND1      arc_1_0_14
 FX BND1      load_1_0_14  0
 BV BND1      arc_1_0_15
 FX BND1      load_1_0_15  0
 BV BND1      arc_1_0_16
 FX BND1      load_1_0_16  0
 BV BND1      arc_1_0_17
 FX BND1      load_1_0_17  0
 BV BND1      arc_1_0_18
 FX BND1      load_1_0_18  0
 BV BND1      arc_1_0_19
 FX BND1      load_1_0_19  0
 BV BND1      arc_1_0_20
 FX BND1      load_1_0_20  0
 BV BND1      arc_1_6_0
 UP BND1      load_1_6_0  25
 BV BND1      arc_1_6_7
 UP BND1      load_1_6_7  25
 BV BND1      arc_1_6_8
 UP BND1      load_1_6_8  25
 BV BND1      arc_1_6_9
 UP BND1      load_1_6_9  25
 BV BND1      arc_1_6_13
 UP BND1      load_1_6_13  25
 BV BND1      arc_1_6_14
 UP BND1      load_1_6_14  25
 BV BND1      arc_1_6_15
 UP BND1      load_1_6_15  25
 BV BND1      arc_1_6_16
 UP BND1      load_1_6_16  25
 BV BND1      arc_1_6_17
 UP BND1      load_1_6_17  25
 BV BND1      arc_1_6_18
 UP BND1      load_1_6_18  25
 BV BND1      arc_1_6_19
 UP BND1      load_1_6_19  25
 BV BND1      arc_1_6_20
 UP BND1      load_1_6_20  25
 BV BND1      arc_1_7_0
 UP BND1      load_1_7_0  25
 BV BND1      arc_1_7_6
 UP BND1      load_1_7_6  25
 BV BND1      arc_1_7_8
 UP BND1      load_1_7_8  25
 BV BND1      arc_1_7_9
 UP BND1      load_1_7_9  25
 BV BND1      arc_1_7_13
 UP BND1      load_1_7_13  25
 BV BND1      arc_1_7_14
 UP BND1      load_1_7_14  25
 BV BND1      arc_1_7_15
 UP BND1      load_1_7_15  25
 BV BND1      arc_1_7_16
 UP BND1      load_1_7_16  25
 BV BND1      arc_1_7_17
 UP BND1      load_1_7_17  25
 BV BND1      arc_1_7_18
 UP BND1      load_1_7_18  25
 BV BND1      arc_1_7_19
 UP BND1      load_1_7_19  25
 BV BND1      arc_1_7_20
 UP BND1      load_1_7_20  25
 BV BND1      arc_1_8_0
 UP BND1      load_1_8_0  25
 BV BND1      arc_1_8_6
 UP BND1      load_1_8_6  25
 BV BND1      arc_1_8_7
 UP BND1      load_1_8_7  25
 BV BND1      arc_1_8_9
 UP BND1      load_1_8_9  25
 BV BND1      arc_1_8_13
 UP BND1      load_1_8_13  25
 BV BND1      arc_1_8_14
 UP BND1      load_1_8_14  25
 BV BND1      arc_1_8_15
 UP BND1      load_1_8_15  25
 BV BND1      arc_1_8_16
 UP BND1      load_1_8_16  25
 BV BND1      arc_1_8_17
 UP BND1      load_1_8_17  25
 BV BND1      arc_1_8_18
 UP BND1      load_1_8_18  25
 BV BND1      arc_1_8_19
 UP BND1      load_1_8_19  25
 BV BND1      arc_1_8_20
 UP BND1      load_1_8_20  25
 BV BND1      arc_1_9_0
 UP BND1      load_1_9_0  25
 BV BND1      arc_1_9_6
 UP BND1      load_1_9_6  25
 BV BND1      arc_1_9_7
 UP BND1      load_1_9_7  25
 BV BND1      arc_1_9_8
 UP BND1      load_1_9_8  25
 BV BND1      arc_1_9_13
 UP BND1      load_1_9_13  25
 BV BND1      arc_1_9_14
 UP BND1      load_1_9_14  25
 BV BND1      arc_1_9_15
 UP BND1      load_1_9_15  25
 BV BND1      arc_1_9_16
 UP BND1      load_1_9_16  25
 BV BND1      arc_1_9_17
 UP BND1      load_1_9_17  25
 BV BND1      arc_1_9_18
 UP BND1      load_1_9_18  25
 BV BND1      arc_1_9_19
 UP BND1      load_1_9_19  25
 BV BND1      arc_1_9_20
 UP BND1      load_1_9_20  25
 BV BND1      arc_1_13_0
 UP BND1      load_1_13_0  25
 BV BND1      arc_1_13_6
 UP BND1      load_1_13_6  25
 BV BND1      arc_1_13_7
 UP BND1      load_1_13_7  25
 BV BND1      arc_1_13_8
 UP BND1      load_1_13_8  25
 BV BND1      arc_1_13_9
 UP BND1      load_1_13_9  25
 BV BND1      arc_1_13_14
 UP BND1      load_1_13_14  25
 BV BND1      arc_1_13_15
 UP BND1      load_1_13_15  25
 BV BND1      arc_1_13_16
 UP BND1      load_1_13_16  25
 BV BND1      arc_1_13_17
 UP BND1      load_1_13_17  25
 BV BND1      arc_1_13_18
 UP BND1      load_1_13_18  25
 BV BND1      arc_1_13_19
 UP BND1      load_1_13_19  25
 BV BND1      arc_1_13_20
 UP BND1      load_1_13_20  25
 BV BND1      arc_1_14_0
 UP BND1      load_1_14_0  25
 BV BND1      arc_1_14_6
 UP BND1      load_1_14_6  25
 BV BND1      arc_1_14_7
 UP BND1      load_1_14_7  25
 BV BND1      arc_1_14_8
 UP BND1      load_1_14_8  25
 BV BND1      arc_1_14_9
 UP BND1      load_1_14_9  25
 BV BND1      arc_1_14_13
 UP BND1      load_1_14_13  25
 BV BND1      arc_1_14_15
 UP BND1      load_1_14_15  25
 BV BND1      arc_1_14_16
 UP BND1      load_1_14_16  25
 BV BND1      arc_1_14_17
 UP BND1      load_1_14_17  25
 BV BND1      arc_1_14_18
 UP BND1      load_1_14_18  25
 BV BND1      arc_1_14_19
 UP BND1      load_1_14_19  25
 BV BND1      arc_1_14_20
 UP BND1      load_1_14_20  25
 BV BND1      arc_1_15_0
 UP BND1      load_1_15_0  25
 BV BND1      arc_1_15_6
 UP BND1      load_1_15_6  25
 BV BND1      arc_1_15_7
 UP BND1      load_1_15_7  25
 BV BND1      arc_1_15_8
 UP BND1      load_1_15_8  25
 BV BND1      arc_1_15_9
 UP BND1      load_1_15_9  25
 BV BND1      arc_1_15_13
 UP BND1      load_1_15_13  25
 BV BND1      arc_1_15_14
 UP BND1      load_1_15_14  25
 BV BND1      arc_1_15_16
 UP BND1      load_1_15_16  25
 BV BND1      arc_1_15_17
 UP BND1      load_1_15_17  25
 BV BND1      arc_1_15_18
 UP BND1      load_1_15_18  25
 BV BND1      arc_1_15_19
 UP BND1      load_1_15_19  25
 BV BND1      arc_1_15_20
 UP BND1      load_1_15_20  25
 BV BND1      arc_1_16_0
 UP BND1      load_1_16_0  25
 BV BND1      arc_1_16_6
 UP BND1      load_1_16_6  25
 BV BND1      arc_1_16_7
 UP BND1      load_1_16_7  25
 BV BND1      arc_1_16_8
 UP BND1      load_1_16_8  25
 BV BND1      arc_1_16_9
 UP BND1      load_1_16_9  25
 BV BND1      arc_1_16_13
 UP BND1      load_1_16_13  25
 BV BND1      arc_1_16_14
 UP BND1      load_1_16_14  25
 BV BND1      arc_1_16_15
 UP BND1      load_1_16_15  25
 BV BND1      arc_1_16_17
 UP BND1      load_1_16_17  25
 BV BND1      arc_1_16_18
 UP BND1      load_1_16_18  25
 BV BND1      arc_1_16_19
 UP BND1      load_1_16_19  25
 BV BND1      arc_1_16_20
 UP BND1      load_1_16_20  25
 BV BND1      arc_1_17_0
 UP BND1      load_1_17_0  25
 BV BND1      arc_1_17_6
 UP BND1      load_1_17_6  25
 BV BND1      arc_1_17_7
 UP BND1      load_1_17_7  25
 BV BND1      arc_1_17_8
 UP BND1      load_1_17_8  25
 BV BND1      arc_1_17_9
 UP BND1      load_1_17_9  25
 BV BND1      arc_1_17_13
 UP BND1      load_1_17_13  25
 BV BND1      arc_1_17_14
 UP BND1      load_1_17_14  25
 BV BND1      arc_1_17_15
 UP BND1      load_1_17_15  25
 BV BND1      arc_1_17_16
 UP BND1      load_1_17_16  25
 BV BND1      arc_1_17_18
 UP BND1      load_1_17_18  25
 BV BND1      arc_1_17_19
 UP BND1      load_1_17_19  25
 BV BND1      arc_1_17_20
 UP BND1      load_1_17_20  25
 BV BND1      arc_1_18_0
 UP BND1      load_1_18_0  25
 BV BND1      arc_1_18_6
 UP BND1      load_1_18_6  25
 BV BND1      arc_1_18_7
 UP BND1      load_1_18_7  25
 BV BND1      arc_1_18_8
 UP BND1      load_1_18_8  25
 BV BND1      arc_1_18_9
 UP BND1      load_1_18_9  25
 BV BND1      arc_1_18_13
 UP BND1      load_1_18_13  25
 BV BND1      arc_1_18_14
 UP BND1      load_1_18_14  25
 BV BND1      arc_1_18_15
 UP BND1      load_1_18_15  25
 BV BND1      arc_1_18_16
 UP BND1      load_1_18_16  25
 BV BND1      arc_1_18_17
 UP BND1      load_1_18_17  25
 BV BND1      arc_1_18_19
 UP BND1      load_1_18_19  25
 BV BND1      arc_1_18_20
 UP BND1      load_1_18_20  25
 BV BND1      arc_1_19_0
 UP BND1      load_1_19_0  25
 BV BND1      arc_1_19_6
 UP BND1      load_1_19_6  25
 BV BND1      arc_1_19_7
 UP BND1      load_1_19_7  25
 BV BND1      arc_1_19_8
 UP BND1      load_1_19_8  25
 BV BND1      arc_1_19_9
 UP BND1      load_1_19_9  25
 BV BND1      arc_1_19_13
 UP BND1      load_1_19_13  25
 BV BND1      arc_1_19_14
 UP BND1      load_1_19_14  25
 BV BND1      arc_1_19_15
 UP BND1      load_1_19_15  25
 BV BND1      arc_1_19_16
 UP BND1      load_1_19_16  25
 BV BND1      arc_1_19_17
 UP BND1      load_1_19_17  25
 BV BND1      arc_1_19_18
 UP BND1      load_1_19_18  25
 BV BND1      arc_1_19_20
 UP BND1      load_1_19_20  25
 BV BND1      arc_1_20_0
 UP BND1      load_1_20_0  25
 BV BND1      arc_1_20_6
 UP BND1      load_1_20_6  25
 BV BND1      arc_1_20_7
 UP BND1      load_1_20_7  25
 BV BND1      arc_1_20_8
 UP BND1      load_1_20_8  25
 BV BND1      arc_1_20_9
 UP BND1      load_1_20_9  25
 BV BND1      arc_1_20_13
 UP BND1      load_1_20_13  25
 BV BND1      arc_1_20_14
 UP BND1      load_1_20_14  25
 BV BND1      arc_1_20_15
 UP BND1      load_1_20_15  25
 BV BND1      arc_1_20_16
 UP BND1      load_1_20_16  25
 BV BND1      arc_1_20_17
 UP BND1      load_1_20_17  25
 BV BND1      arc_1_20_18
 UP BND1      load_1_20_18  25
 BV BND1      arc_1_20_19
 UP BND1      load_1_20_19  25
 FX BND1      visit_2_10  1
 UP BND1      order_2_10  11
 FX BND1      visit_2_11  1
 UP BND1      order_2_11  11
 FX BND1      visit_2_12  1
 UP BND1      order_2_12  11
 UP BND1      visit_2_13  1
 UP BND1      order_2_13  11
 UP BND1      visit_2_14  1
 UP BND1      order_2_14  11
 UP BND1      visit_2_15  1
 UP BND1      order_2_15  11
 UP BND1      visit_2_16  1
 UP BND1      order_2_16  11
 UP BND1      visit_2_17  1
 UP BND1      order_2_17  11
 UP BND1      visit_2_18  1
 UP BND1      order_2_18  11
 UP BND1      visit_2_19  1
 UP BND1      order_2_19  11
 UP BND1      visit_2_20  1
 UP BND1      order_2_20  11
 BV BND1      arc_2_0_0
 FX BND1      load_2_0_0  0
 BV BND1      arc_2_0_10
 FX BND1      load_2_0_10  0
 BV BND1      arc_2_0_11
 FX BND1      load_2_0_11  0
 BV BND1      arc_2_0_12
 FX BND1      load_2_0_12  0
 BV BND1      arc_2_0_13
 FX BND1      load_2_0_13  0
 BV BND1      arc_2_0_14
 FX BND1      load_2_0_14  0
 BV BND1      arc_2_0_15
 FX BND1      load_2_0_15  0
 BV BND1      arc_2_0_16
 FX BND1      load_2_0_16  0
 BV BND1      arc_2_0_17
 FX BND1      load_2_0_17  0
 BV BND1      arc_2_0_18
 FX BND1      load_2_0_18  0
 BV BND1      arc_2_0_19
 FX BND1      load_2_0_19  0
 BV BND1      arc_2_0_20
 FX BND1      load_2_0_20  0
 BV BND1      arc_2_10_0
 UP BND1      load_2_10_0  30
 BV BND1      arc_2_10_11
 UP BND1      load_2_10_11  30
 BV BND1      arc_2_10_12
 UP BND1      load_2_10_12  30
 BV BND1      arc_2_10_13
 UP BND1      load_2_10_13  30
 BV BND1      arc_2_10_14
 UP BND1      load_2_10_14  30
 BV BND1      arc_2_10_15
 UP BND1      load_2_10_15  30
 BV BND1      arc_2_10_16
 UP BND1      load_2_10_16  30
 BV BND1      arc_2_10_17
 UP BND1      load_2_10_17  30
 BV BND1      arc_2_10_18
 UP BND1      load_2_10_18  30
 BV BND1      arc_2_10_19
 UP BND1      load_2_10_19  30
 BV BND1      arc_2_10_20
 UP BND1      load_2_10_20  30
 BV BND1      arc_2_11_0
 UP BND1      load_2_11_0  30
 BV BND1      arc_2_11_10
 UP BND1      load_2_11_10  30
 BV BND1      arc_2_11_12
 UP BND1      load_2_11_12  30
 BV BND1      arc_2_11_13
 UP BND1      load_2_11_13  30
 BV BND1      arc_2_11_14
 UP BND1      load_2_11_14  30
 BV BND1      arc_2_11_15
 UP BND1      load_2_11_15  30
 BV BND1      arc_2_11_16
 UP BND1      load_2_11_16  30
 BV BND1      arc_2_11_17
 UP BND1      load_2_11_17  30
 BV BND1      arc_2_11_18
 UP BND1      load_2_11_18  30
 BV BND1      arc_2_11_19
 UP BND1      load_2_11_19  30
 BV BND1      arc_2_11_20
 UP BND1      load_2_11_20  30
 BV BND1      arc_2_12_0
 UP BND1      load_2_12_0  30
 BV BND1      arc_2_12_10
 UP BND1      load_2_12_10  30
 BV BND1      arc_2_12_11
 UP BND1      load_2_12_11  30
 BV BND1      arc_2_12_13
 UP BND1      load_2_12_13  30
 BV BND1      arc_2_12_14
 UP BND1      load_2_12_14  30
 BV BND1      arc_2_12_15
 UP BND1      load_2_12_15  30
 BV BND1      arc_2_12_16
 UP BND1      load_2_12_16  30
 BV BND1      arc_2_12_17
 UP BND1      load_2_12_17  30
 BV BND1      arc_2_12_18
 UP BND1      load_2_12_18  30
 BV BND1      arc_2_12_19
 UP BND1      load_2_12_19  30
 BV BND1      arc_2_12_20
 UP BND1      load_2_12_20  30
 BV BND1      arc_2_13_0
 UP BND1      load_2_13_0  30
 BV BND1      arc_2_13_10
 UP BND1      load_2_13_10  30
 BV BND1      arc_2_13_11
 UP BND1      load_2_13_11  30
 BV BND1      arc_2_13_12
 UP BND1      load_2_13_12  30
 BV BND1      arc_2_13_14
 UP BND1      load_2_13_14  30
 BV BND1      arc_2_13_15
 UP BND1      load_2_13_15  30
 BV BND1      arc_2_13_16
 UP BND1      load_2_13_16  30
 BV BND1      arc_2_13_17
 UP BND1      load_2_13_17  30
 BV BND1      arc_2_13_18
 UP BND1      load_2_13_18  30
 BV BND1      arc_2_13_19
 UP BND1      load_2_13_19  30
 BV BND1      arc_2_13_20
 UP BND1      load_2_13_20  30
 BV BND1      arc_2_14_0
 UP BND1      load_2_14_0  30
 BV BND1      arc_2_14_10
 UP BND1      load_2_14_10  30
 BV BND1      arc_2_14_11
 UP BND1      load_2_14_11  30
 BV BND1      arc_2_14_12
 UP BND1      load_2_14_12  30
 BV BND1      arc_2_14_13
 UP BND1      load_2_14_13  30
 BV BND1      arc_2_14_15
 UP BND1      load_2_14_15  30
 BV BND1      arc_2_14_16
 UP BND1      load_2_14_16  30
 BV BND1      arc_2_14_17
 UP BND1      load_2_14_17  30
 BV BND1      arc_2_14_18
 UP BND1      load_2_14_18  30
 BV BND1      arc_2_14_19
 UP BND1      load_2_14_19  30
 BV BND1      arc_2_14_20
 UP BND1      load_2_14_20  30
 BV BND1      arc_2_15_0
 UP BND1      load_2_15_0  30
 BV BND1      arc_2_15_10
 UP BND1      load_2_15_10  30
 BV BND1      arc_2_15_11
 UP BND1      load_2_15_11  30
 BV BND1      arc_2_15_12
 UP BND1      load_2_15_12  30
 BV BND1      arc_2_15_13
 UP BND1      load_2_15_13  30
 BV BND1      arc_2_15_14
 UP BND1      load_2_15_14  30
 BV BND1      arc_2_15_16
 UP BND1      load_2_15_16  30
 BV BND1      arc_2_15_17
 UP BND1      load_2_15_17  30
 BV BND1      arc_2_15_18
 UP BND1      load_2_15_18  30
 BV BND1      arc_2_15_19
 UP BND1      load_2_15_19  30
 BV BND1      arc_2_15_20
 UP BND1      load_2_15_20  30
 BV BND1      arc_2_16_0
 UP BND1      load_2_16_0  30
 BV BND1      arc_2_16_10
 UP BND1      load_2_16_10  30
 BV BND1      arc_2_16_11
 UP BND1      load_2_16_11  30
 BV BND1      arc_2_16_12
 UP BND1      load_2_16_12  30
 BV BND1      arc_2_16_13
 UP BND1      load_2_16_13  30
 BV BND1      arc_2_16_14
 UP BND1      load_2_16_14  30
 BV BND1      arc_2_16_15
 UP BND1      load_2_16_15  30
 BV BND1      arc_2_16_17
 UP BND1      load_2_16_17  30
 BV BND1      arc_2_16_18
 UP BND1      load_2_16_18  30
 BV BND1      arc_2_16_19
 UP BND1      load_2_16_19  30
 BV BND1      arc_2_16_20
 UP BND1      load_2_16_20  30
 BV BND1      arc_2_17_0
 UP BND1      load_2_17_0  30
 BV BND1      arc_2_17_10
 UP BND1      load_2_17_10  30
 BV BND1      arc_2_17_11
 UP BND1      load_2_17_11  30
 BV BND1      arc_2_17_12
 UP BND1      load_2_17_12  30
 BV BND1      arc_2_17_13
 UP BND1      load_2_17_13  30
 BV BND1      arc_2_17_14
 UP BND1      load_2_17_14  30
 BV BND1      arc_2_17_15
 UP BND1      load_2_17_15  30
 BV BND1      arc_2_17_16
 UP BND1      load_2_17_16  30
 BV BND1      arc_2_17_18
 UP BND1      load_2_17_18  30
 BV BND1      arc_2_17_19
 UP BND1      load_2_17_19  30
 BV BND1      arc_2_17_20
 UP BND1      load_2_17_20  30
 BV BND1      arc_2_18_0
 UP BND1      load_2_18_0  30
 BV BND1      arc_2_18_10
 UP BND1      load_2_18_10  30
 BV BND1      arc_2_18_11
 UP BND1      load_2_18_11  30
 BV BND1      arc_2_18_12
 UP BND1      load_2_18_12  30
 BV BND1      arc_2_18_13
 UP BND1      load_2_18_13  30
 BV BND1      arc_2_18_14
 UP BND1      load_2_18_14  30
 BV BND1      arc_2_18_15
 UP BND1      load_2_18_15  30
 BV BND1      arc_2_18_16
 UP BND1      load_2_18_16  30
 BV BND1      arc_2_18_17
 UP BND1      load_2_18_17  30
 BV BND1      arc_2_18_19
 UP BND1      load_2_18_19  30
 BV BND1      arc_2_18_20
 UP BND1      load_2_18_20  30
 BV BND1      arc_2_19_0
 UP BND1      load_2_19_0  30
 BV BND1      arc_2_19_10
 UP BND1      load_2_19_10  30
 BV BND1      arc_2_19_11
 UP BND1      load_2_19_11  30
 BV BND1      arc_2_19_12
 UP BND1      load_2_19_12  30
 BV BND1      arc_2_19_13
 UP BND1      load_2_19_13  30
 BV BND1      arc_2_19_14
 UP BND1      load_2_19_14  30
 BV BND1      arc_2_19_15
 UP BND1      load_2_19_15  30
 BV BND1      arc_2_19_16
 UP BND1      load_2_19_16  30
 BV BND1      arc_2_19_17
 UP BND1      load_2_19_17  30
 BV BND1      arc_2_19_18
 UP BND1      load_2_19_18  30
 BV BND1      arc_2_19_20
 UP BND1      load_2_19_20  30
 BV BND1      arc_2_20_0
 UP BND1      load_2_20_0  30
 BV BND1      arc_2_20_10
 UP BND1      load_2_20_10  30
 BV BND1      arc_2_20_11
 UP BND1      load_2_20_11  30
 BV BND1      arc_2_20_12
 UP BND1      load_2_20_12  30
 BV BND1      arc_2_20_13
 UP BND1      load_2_20_13  30
 BV BND1      arc_2_20_14
 UP BND1      load_2_20_14  30
 BV BND1      arc_2_20_15
 UP BND1      load_2_20_15  30
 BV BND1      arc_2_20_16
 UP BND1      load_2_20_16  30
 BV BND1      arc_2_20_17
 UP BND1      load_2_20_17  30
 BV BND1      arc_2_20_18
 UP BND1      load_2_20_18  30
 BV BND1      arc_2_20_19
 UP BND1      load_2_20_19  30
ENDATA
