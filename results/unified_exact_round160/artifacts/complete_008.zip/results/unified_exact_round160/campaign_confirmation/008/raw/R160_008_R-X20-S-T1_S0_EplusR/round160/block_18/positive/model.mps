* Signature: 0x7afa87846bcdd873
NAME R160_physical_neighborhood
ROWS
 N  OBJ
 G  product_lb_0
 L  product_ub_1
 G  product_lb_2
 L  product_ub_3
 G  product_lb_4
 L  product_ub_5
 G  product_lb_6
 L  product_ub_7
 G  product_lb_8
 L  product_ub_9
 G  product_lb_10
 L  product_ub_11
 G  product_lb_12
 L  product_ub_13
 G  product_lb_14
 L  product_ub_15
 G  product_lb_16
 L  product_ub_17
 G  product_lb_18
 L  product_ub_19
 G  product_lb_20
 L  product_ub_21
 G  product_lb_22
 L  product_ub_23
 G  product_lb_24
 L  product_ub_25
 G  product_lb_26
 L  product_ub_27
 G  product_lb_28
 L  product_ub_29
 G  product_lb_30
 L  product_ub_31
 E  onehot_14_32
 E  normalized_mass_14_33
 E  normalized_ratio_14_34
 G  product_lb_35
 L  product_ub_36
 G  product_lb_37
 L  product_ub_38
 E  onehot_13_39
 E  normalized_mass_13_40
 E  normalized_ratio_13_41
 G  product_lb_42
 L  product_ub_43
 G  product_lb_44
 L  product_ub_45
 G  product_lb_46
 L  product_ub_47
 G  product_lb_48
 L  product_ub_49
 G  product_lb_50
 L  product_ub_51
 G  product_lb_52
 L  product_ub_53
 G  product_lb_54
 L  product_ub_55
 G  product_lb_56
 L  product_ub_57
 G  product_lb_58
 L  product_ub_59
 G  product_lb_60
 L  product_ub_61
 G  product_lb_62
 L  product_ub_63
 G  product_lb_64
 L  product_ub_65
 G  product_lb_66
 L  product_ub_67
 G  product_lb_68
 L  product_ub_69
 G  product_lb_70
 L  product_ub_71
 G  product_lb_72
 L  product_ub_73
 E  onehot_18_74
 E  normalized_mass_18_75
 E  normalized_ratio_18_76
 G  product_lb_77
 L  product_ub_78
 G  product_lb_79
 L  product_ub_80
 G  product_lb_81
 L  product_ub_82
 G  product_lb_83
 L  product_ub_84
 G  product_lb_85
 L  product_ub_86
 G  product_lb_87
 L  product_ub_88
 G  product_lb_89
 L  product_ub_90
 G  product_lb_91
 L  product_ub_92
 G  product_lb_93
 L  product_ub_94
 G  product_lb_95
 L  product_ub_96
 G  product_lb_97
 L  product_ub_98
 G  product_lb_99
 L  product_ub_100
 G  product_lb_101
 L  product_ub_102
 G  product_lb_103
 L  product_ub_104
 G  product_lb_105
 L  product_ub_106
 G  product_lb_107
 L  product_ub_108
 G  product_lb_109
 L  product_ub_110
 E  onehot_17_111
 E  normalized_mass_17_112
 E  normalized_ratio_17_113
 G  product_lb_114
 L  product_ub_115
 G  product_lb_116
 L  product_ub_117
 G  product_lb_118
 L  product_ub_119
 G  product_lb_120
 L  product_ub_121
 G  product_lb_122
 L  product_ub_123
 G  product_lb_124
 L  product_ub_125
 G  product_lb_126
 L  product_ub_127
 G  product_lb_128
 L  product_ub_129
 G  product_lb_130
 L  product_ub_131
 G  product_lb_132
 L  product_ub_133
 G  product_lb_134
 L  product_ub_135
 G  product_lb_136
 L  product_ub_137
 G  product_lb_138
 L  product_ub_139
 G  product_lb_140
 L  product_ub_141
 G  product_lb_142
 L  product_ub_143
 G  product_lb_144
 L  product_ub_145
 E  onehot_20_146
 E  normalized_mass_20_147
 E  normalized_ratio_20_148
 G  product_lb_149
 L  product_ub_150
 G  product_lb_151
 L  product_ub_152
 G  product_lb_153
 L  product_ub_154
 G  product_lb_155
 L  product_ub_156
 G  product_lb_157
 L  product_ub_158
 G  product_lb_159
 L  product_ub_160
 G  product_lb_161
 L  product_ub_162
 G  product_lb_163
 L  product_ub_164
 G  product_lb_165
 L  product_ub_166
 G  product_lb_167
 L  product_ub_168
 G  product_lb_169
 L  product_ub_170
 G  product_lb_171
 L  product_ub_172
 G  product_lb_173
 L  product_ub_174
 G  product_lb_175
 L  product_ub_176
 G  product_lb_177
 L  product_ub_178
 G  product_lb_179
 L  product_ub_180
 E  onehot_12_181
 E  normalized_mass_12_182
 E  normalized_ratio_12_183
 G  product_lb_184
 L  product_ub_185
 G  product_lb_186
 L  product_ub_187
 G  product_lb_188
 L  product_ub_189
 G  product_lb_190
 L  product_ub_191
 G  product_lb_192
 L  product_ub_193
 G  product_lb_194
 L  product_ub_195
 G  product_lb_196
 L  product_ub_197
 G  product_lb_198
 L  product_ub_199
 G  product_lb_200
 L  product_ub_201
 G  product_lb_202
 L  product_ub_203
 G  product_lb_204
 L  product_ub_205
 G  product_lb_206
 L  product_ub_207
 G  product_lb_208
 L  product_ub_209
 G  product_lb_210
 L  product_ub_211
 G  product_lb_212
 L  product_ub_213
 G  product_lb_214
 L  product_ub_215
 E  onehot_1_216
 E  normalized_mass_1_217
 E  normalized_ratio_1_218
 G  product_lb_219
 L  product_ub_220
 G  product_lb_221
 L  product_ub_222
 E  onehot_10_223
 E  normalized_mass_10_224
 E  normalized_ratio_10_225
 G  stock_lb_226
 L  stock_ub_227
 L  parent_nonstrict_scope_228
 G  block_pair_pos_229
 G  block_pair_neg_230
 G  block_pair_pos_231
 G  block_pair_neg_232
 G  block_pair_pos_233
 G  block_pair_neg_234
 G  block_pair_pos_235
 G  block_pair_neg_236
 G  block_pair_pos_237
 G  block_pair_neg_238
 G  block_pair_pos_239
 G  block_pair_neg_240
 G  block_pair_pos_241
 G  block_pair_neg_242
 G  block_pair_pos_243
 G  block_pair_neg_244
 G  block_pair_pos_245
 G  block_pair_neg_246
 G  block_pair_pos_247
 G  block_pair_neg_248
 G  block_pair_pos_249
 G  block_pair_neg_250
 G  block_pair_pos_251
 G  block_pair_neg_252
 G  block_pair_pos_253
 G  block_pair_neg_254
 G  block_pair_pos_255
 G  block_pair_neg_256
 G  block_pair_pos_257
 G  block_pair_neg_258
 G  block_pair_pos_259
 G  block_pair_neg_260
 G  block_pair_pos_261
 G  block_pair_neg_262
 G  block_pair_pos_263
 G  block_pair_neg_264
 G  block_pair_pos_265
 G  block_pair_neg_266
 G  block_pair_pos_267
 G  block_pair_neg_268
 G  block_pair_pos_269
 G  block_pair_neg_270
 G  block_pair_pos_271
 G  block_pair_neg_272
 G  block_pair_pos_273
 G  block_pair_neg_274
 G  block_pair_pos_275
 G  block_pair_neg_276
 G  block_pair_pos_277
 G  block_pair_neg_278
 G  block_pair_pos_279
 G  block_pair_neg_280
 G  block_pair_pos_281
 G  block_pair_neg_282
 G  block_pair_pos_283
 G  block_pair_neg_284
 E  normalization_285
 G  full_original_Gini_286
 E  unique_nonzero_owner_287
 E  unique_nonzero_owner_288
 E  unique_nonzero_owner_289
 E  unique_nonzero_owner_290
 E  unique_nonzero_owner_291
 E  unique_nonzero_owner_292
 E  unique_nonzero_owner_293
 E  unique_nonzero_owner_294
 E  unique_nonzero_owner_295
 E  unique_nonzero_owner_296
 E  unique_nonzero_owner_297
 E  unique_nonzero_owner_298
 E  unique_nonzero_owner_299
 E  unique_nonzero_owner_300
 E  unique_nonzero_owner_301
 E  unique_nonzero_owner_302
 E  unique_nonzero_owner_303
 E  unique_nonzero_owner_304
 E  unique_nonzero_owner_305
 E  unique_nonzero_owner_306
 E  unique_nonzero_owner_307
 E  unique_nonzero_owner_308
 E  unique_nonzero_owner_309
 E  unique_nonzero_owner_310
 E  unique_nonzero_owner_311
 E  unique_nonzero_owner_312
 E  unique_nonzero_owner_313
 E  unique_nonzero_owner_314
 E  unique_nonzero_owner_315
 E  unique_nonzero_owner_316
 E  unique_nonzero_owner_317
 E  unique_nonzero_owner_318
 E  unique_nonzero_owner_319
 E  unique_nonzero_owner_320
 E  unique_nonzero_owner_321
 E  unique_nonzero_owner_322
 E  unique_nonzero_owner_323
 E  unique_nonzero_owner_324
 E  unique_nonzero_owner_325
 E  unique_nonzero_owner_326
 E  unique_nonzero_owner_327
 E  unique_nonzero_owner_328
 E  unique_nonzero_owner_329
 E  unique_nonzero_owner_330
 E  unique_nonzero_owner_331
 E  unique_nonzero_owner_332
 E  unique_nonzero_owner_333
 E  unique_nonzero_owner_334
 E  unique_nonzero_owner_335
 E  unique_nonzero_owner_336
 E  unique_nonzero_owner_337
 E  unique_nonzero_owner_338
 E  unique_nonzero_owner_339
 E  unique_nonzero_owner_340
 E  unique_nonzero_owner_341
 E  unique_nonzero_owner_342
 E  unique_nonzero_owner_343
 E  unique_nonzero_owner_344
 E  unique_nonzero_owner_345
 E  unique_nonzero_owner_346
 E  unique_nonzero_owner_347
 E  unique_nonzero_owner_348
 E  unique_nonzero_owner_349
 E  unique_nonzero_owner_350
 E  unique_nonzero_owner_351
 E  unique_nonzero_owner_352
 E  unique_nonzero_owner_353
 E  unique_nonzero_owner_354
 E  unique_nonzero_owner_355
 E  unique_nonzero_owner_356
 E  unique_nonzero_owner_357
 E  unique_nonzero_owner_358
 E  unique_nonzero_owner_359
 E  unique_nonzero_owner_360
 E  unique_nonzero_owner_361
 E  unique_nonzero_owner_362
 E  unique_nonzero_owner_363
 E  unique_nonzero_owner_364
 E  unique_nonzero_owner_365
 E  unique_nonzero_owner_366
 E  unique_nonzero_owner_367
 E  unique_nonzero_owner_368
 E  unique_nonzero_owner_369
 E  unique_nonzero_owner_370
 E  unique_nonzero_owner_371
 E  unique_nonzero_owner_372
 E  unique_nonzero_owner_373
 E  unique_nonzero_owner_374
 E  unique_nonzero_owner_375
 E  unique_nonzero_owner_376
 E  unique_nonzero_owner_377
 E  unique_nonzero_owner_378
 E  unique_nonzero_owner_379
 L  arc_capacity_380
 L  arc_capacity_381
 L  arc_capacity_382
 L  arc_capacity_383
 L  arc_capacity_384
 L  arc_capacity_385
 L  arc_capacity_386
 L  arc_capacity_387
 L  arc_capacity_388
 L  arc_capacity_389
 L  arc_capacity_390
 L  arc_capacity_391
 L  arc_capacity_392
 L  arc_capacity_393
 L  arc_capacity_394
 L  arc_capacity_395
 L  arc_capacity_396
 L  arc_capacity_397
 G  connected_order_arc_398
 L  arc_capacity_399
 G  connected_order_arc_400
 L  arc_capacity_401
 G  connected_order_arc_402
 L  arc_capacity_403
 G  connected_order_arc_404
 L  arc_capacity_405
 G  connected_order_arc_406
 L  arc_capacity_407
 G  connected_order_arc_408
 L  arc_capacity_409
 G  connected_order_arc_410
 L  arc_capacity_411
 G  connected_order_arc_412
 L  arc_capacity_413
 G  connected_order_arc_414
 L  arc_capacity_415
 G  connected_order_arc_416
 L  arc_capacity_417
 G  connected_order_arc_418
 L  arc_capacity_419
 G  connected_order_arc_420
 L  arc_capacity_421
 G  connected_order_arc_422
 L  arc_capacity_423
 G  connected_order_arc_424
 L  arc_capacity_425
 L  arc_capacity_426
 G  connected_order_arc_427
 L  arc_capacity_428
 G  connected_order_arc_429
 L  arc_capacity_430
 G  connected_order_arc_431
 L  arc_capacity_432
 G  connected_order_arc_433
 L  arc_capacity_434
 G  connected_order_arc_435
 L  arc_capacity_436
 G  connected_order_arc_437
 L  arc_capacity_438
 G  connected_order_arc_439
 L  arc_capacity_440
 G  connected_order_arc_441
 L  arc_capacity_442
 G  connected_order_arc_443
 L  arc_capacity_444
 G  connected_order_arc_445
 L  arc_capacity_446
 G  connected_order_arc_447
 L  arc_capacity_448
 G  connected_order_arc_449
 L  arc_capacity_450
 G  connected_order_arc_451
 L  arc_capacity_452
 G  connected_order_arc_453
 L  arc_capacity_454
 L  arc_capacity_455
 G  connected_order_arc_456
 L  arc_capacity_457
 G  connected_order_arc_458
 L  arc_capacity_459
 G  connected_order_arc_460
 L  arc_capacity_461
 G  connected_order_arc_462
 L  arc_capacity_463
 G  connected_order_arc_464
 L  arc_capacity_465
 G  connected_order_arc_466
 L  arc_capacity_467
 G  connected_order_arc_468
 L  arc_capacity_469
 G  connected_order_arc_470
 L  arc_capacity_471
 G  connected_order_arc_472
 L  arc_capacity_473
 G  connected_order_arc_474
 L  arc_capacity_475
 G  connected_order_arc_476
 L  arc_capacity_477
 G  connected_order_arc_478
 L  arc_capacity_479
 G  connected_order_arc_480
 L  arc_capacity_481
 G  connected_order_arc_482
 L  arc_capacity_483
 L  arc_capacity_484
 G  connected_order_arc_485
 L  arc_capacity_486
 G  connected_order_arc_487
 L  arc_capacity_488
 G  connected_order_arc_489
 L  arc_capacity_490
 G  connected_order_arc_491
 L  arc_capacity_492
 G  connected_order_arc_493
 L  arc_capacity_494
 G  connected_order_arc_495
 L  arc_capacity_496
 G  connected_order_arc_497
 L  arc_capacity_498
 G  connected_order_arc_499
 L  arc_capacity_500
 G  connected_order_arc_501
 L  arc_capacity_502
 G  connected_order_arc_503
 L  arc_capacity_504
 G  connected_order_arc_505
 L  arc_capacity_506
 G  connected_order_arc_507
 L  arc_capacity_508
 G  connected_order_arc_509
 L  arc_capacity_510
 G  connected_order_arc_511
 L  arc_capacity_512
 L  arc_capacity_513
 G  connected_order_arc_514
 L  arc_capacity_515
 G  connected_order_arc_516
 L  arc_capacity_517
 G  connected_order_arc_518
 L  arc_capacity_519
 G  connected_order_arc_520
 L  arc_capacity_521
 G  connected_order_arc_522
 L  arc_capacity_523
 G  connected_order_arc_524
 L  arc_capacity_525
 G  connected_order_arc_526
 L  arc_capacity_527
 G  connected_order_arc_528
 L  arc_capacity_529
 G  connected_order_arc_530
 L  arc_capacity_531
 G  connected_order_arc_532
 L  arc_capacity_533
 G  connected_order_arc_534
 L  arc_capacity_535
 G  connected_order_arc_536
 L  arc_capacity_537
 G  connected_order_arc_538
 L  arc_capacity_539
 G  connected_order_arc_540
 L  arc_capacity_541
 L  arc_capacity_542
 G  connected_order_arc_543
 L  arc_capacity_544
 G  connected_order_arc_545
 L  arc_capacity_546
 G  connected_order_arc_547
 L  arc_capacity_548
 G  connected_order_arc_549
 L  arc_capacity_550
 G  connected_order_arc_551
 L  arc_capacity_552
 G  connected_order_arc_553
 L  arc_capacity_554
 G  connected_order_arc_555
 L  arc_capacity_556
 G  connected_order_arc_557
 L  arc_capacity_558
 G  connected_order_arc_559
 L  arc_capacity_560
 G  connected_order_arc_561
 L  arc_capacity_562
 G  connected_order_arc_563
 L  arc_capacity_564
 G  connected_order_arc_565
 L  arc_capacity_566
 G  connected_order_arc_567
 L  arc_capacity_568
 G  connected_order_arc_569
 L  arc_capacity_570
 L  arc_capacity_571
 G  connected_order_arc_572
 L  arc_capacity_573
 G  connected_order_arc_574
 L  arc_capacity_575
 G  connected_order_arc_576
 L  arc_capacity_577
 G  connected_order_arc_578
 L  arc_capacity_579
 G  connected_order_arc_580
 L  arc_capacity_581
 G  connected_order_arc_582
 L  arc_capacity_583
 G  connected_order_arc_584
 L  arc_capacity_585
 G  connected_order_arc_586
 L  arc_capacity_587
 G  connected_order_arc_588
 L  arc_capacity_589
 G  connected_order_arc_590
 L  arc_capacity_591
 G  connected_order_arc_592
 L  arc_capacity_593
 G  connected_order_arc_594
 L  arc_capacity_595
 G  connected_order_arc_596
 L  arc_capacity_597
 G  connected_order_arc_598
 L  arc_capacity_599
 L  arc_capacity_600
 G  connected_order_arc_601
 L  arc_capacity_602
 G  connected_order_arc_603
 L  arc_capacity_604
 G  connected_order_arc_605
 L  arc_capacity_606
 G  connected_order_arc_607
 L  arc_capacity_608
 G  connected_order_arc_609
 L  arc_capacity_610
 G  connected_order_arc_611
 L  arc_capacity_612
 G  connected_order_arc_613
 L  arc_capacity_614
 G  connected_order_arc_615
 L  arc_capacity_616
 G  connected_order_arc_617
 L  arc_capacity_618
 G  connected_order_arc_619
 L  arc_capacity_620
 G  connected_order_arc_621
 L  arc_capacity_622
 G  connected_order_arc_623
 L  arc_capacity_624
 G  connected_order_arc_625
 L  arc_capacity_626
 G  connected_order_arc_627
 L  arc_capacity_628
 L  arc_capacity_629
 G  connected_order_arc_630
 L  arc_capacity_631
 G  connected_order_arc_632
 L  arc_capacity_633
 G  connected_order_arc_634
 L  arc_capacity_635
 G  connected_order_arc_636
 L  arc_capacity_637
 G  connected_order_arc_638
 L  arc_capacity_639
 G  connected_order_arc_640
 L  arc_capacity_641
 G  connected_order_arc_642
 L  arc_capacity_643
 G  connected_order_arc_644
 L  arc_capacity_645
 G  connected_order_arc_646
 L  arc_capacity_647
 G  connected_order_arc_648
 L  arc_capacity_649
 G  connected_order_arc_650
 L  arc_capacity_651
 G  connected_order_arc_652
 L  arc_capacity_653
 G  connected_order_arc_654
 L  arc_capacity_655
 G  connected_order_arc_656
 L  arc_capacity_657
 L  arc_capacity_658
 G  connected_order_arc_659
 L  arc_capacity_660
 G  connected_order_arc_661
 L  arc_capacity_662
 G  connected_order_arc_663
 L  arc_capacity_664
 G  connected_order_arc_665
 L  arc_capacity_666
 G  connected_order_arc_667
 L  arc_capacity_668
 G  connected_order_arc_669
 L  arc_capacity_670
 G  connected_order_arc_671
 L  arc_capacity_672
 G  connected_order_arc_673
 L  arc_capacity_674
 G  connected_order_arc_675
 L  arc_capacity_676
 G  connected_order_arc_677
 L  arc_capacity_678
 G  connected_order_arc_679
 L  arc_capacity_680
 G  connected_order_arc_681
 L  arc_capacity_682
 G  connected_order_arc_683
 L  arc_capacity_684
 G  connected_order_arc_685
 L  arc_capacity_686
 L  arc_capacity_687
 G  connected_order_arc_688
 L  arc_capacity_689
 G  connected_order_arc_690
 L  arc_capacity_691
 G  connected_order_arc_692
 L  arc_capacity_693
 G  connected_order_arc_694
 L  arc_capacity_695
 G  connected_order_arc_696
 L  arc_capacity_697
 G  connected_order_arc_698
 L  arc_capacity_699
 G  connected_order_arc_700
 L  arc_capacity_701
 G  connected_order_arc_702
 L  arc_capacity_703
 G  connected_order_arc_704
 L  arc_capacity_705
 G  connected_order_arc_706
 L  arc_capacity_707
 G  connected_order_arc_708
 L  arc_capacity_709
 G  connected_order_arc_710
 L  arc_capacity_711
 G  connected_order_arc_712
 L  arc_capacity_713
 G  connected_order_arc_714
 L  arc_capacity_715
 L  arc_capacity_716
 G  connected_order_arc_717
 L  arc_capacity_718
 G  connected_order_arc_719
 L  arc_capacity_720
 G  connected_order_arc_721
 L  arc_capacity_722
 G  connected_order_arc_723
 L  arc_capacity_724
 G  connected_order_arc_725
 L  arc_capacity_726
 G  connected_order_arc_727
 L  arc_capacity_728
 G  connected_order_arc_729
 L  arc_capacity_730
 G  connected_order_arc_731
 L  arc_capacity_732
 G  connected_order_arc_733
 L  arc_capacity_734
 G  connected_order_arc_735
 L  arc_capacity_736
 G  connected_order_arc_737
 L  arc_capacity_738
 G  connected_order_arc_739
 L  arc_capacity_740
 G  connected_order_arc_741
 L  arc_capacity_742
 G  connected_order_arc_743
 L  arc_capacity_744
 L  arc_capacity_745
 G  connected_order_arc_746
 L  arc_capacity_747
 G  connected_order_arc_748
 L  arc_capacity_749
 G  connected_order_arc_750
 L  arc_capacity_751
 G  connected_order_arc_752
 L  arc_capacity_753
 G  connected_order_arc_754
 L  arc_capacity_755
 G  connected_order_arc_756
 L  arc_capacity_757
 G  connected_order_arc_758
 L  arc_capacity_759
 G  connected_order_arc_760
 L  arc_capacity_761
 G  connected_order_arc_762
 L  arc_capacity_763
 G  connected_order_arc_764
 L  arc_capacity_765
 G  connected_order_arc_766
 L  arc_capacity_767
 G  connected_order_arc_768
 L  arc_capacity_769
 G  connected_order_arc_770
 L  arc_capacity_771
 G  connected_order_arc_772
 L  arc_capacity_773
 L  arc_capacity_774
 G  connected_order_arc_775
 L  arc_capacity_776
 G  connected_order_arc_777
 L  arc_capacity_778
 G  connected_order_arc_779
 L  arc_capacity_780
 G  connected_order_arc_781
 L  arc_capacity_782
 G  connected_order_arc_783
 L  arc_capacity_784
 G  connected_order_arc_785
 L  arc_capacity_786
 G  connected_order_arc_787
 L  arc_capacity_788
 G  connected_order_arc_789
 L  arc_capacity_790
 G  connected_order_arc_791
 L  arc_capacity_792
 G  connected_order_arc_793
 L  arc_capacity_794
 G  connected_order_arc_795
 L  arc_capacity_796
 G  connected_order_arc_797
 L  arc_capacity_798
 G  connected_order_arc_799
 L  arc_capacity_800
 G  connected_order_arc_801
 L  arc_capacity_802
 L  arc_capacity_803
 G  connected_order_arc_804
 L  arc_capacity_805
 G  connected_order_arc_806
 L  arc_capacity_807
 G  connected_order_arc_808
 L  arc_capacity_809
 G  connected_order_arc_810
 L  arc_capacity_811
 G  connected_order_arc_812
 L  arc_capacity_813
 G  connected_order_arc_814
 L  arc_capacity_815
 G  connected_order_arc_816
 L  arc_capacity_817
 G  connected_order_arc_818
 L  arc_capacity_819
 G  connected_order_arc_820
 L  arc_capacity_821
 G  connected_order_arc_822
 L  arc_capacity_823
 G  connected_order_arc_824
 L  arc_capacity_825
 G  connected_order_arc_826
 L  arc_capacity_827
 G  connected_order_arc_828
 L  arc_capacity_829
 G  connected_order_arc_830
 E  depot_departure_or_bypass_831
 E  depot_return_or_bypass_832
 E  out_degree_833
 E  in_degree_834
 G  order_active_lb_835
 L  order_active_ub_836
 E  segment_load_conservation_837
 G  segment_prefix_lb_838
 L  segment_prefix_ub_839
 E  out_degree_840
 E  in_degree_841
 G  order_active_lb_842
 L  order_active_ub_843
 E  segment_load_conservation_844
 G  segment_prefix_lb_845
 L  segment_prefix_ub_846
 E  out_degree_847
 E  in_degree_848
 G  order_active_lb_849
 L  order_active_ub_850
 E  segment_load_conservation_851
 G  segment_prefix_lb_852
 L  segment_prefix_ub_853
 E  out_degree_854
 E  in_degree_855
 G  order_active_lb_856
 L  order_active_ub_857
 E  segment_load_conservation_858
 G  segment_prefix_lb_859
 L  segment_prefix_ub_860
 E  out_degree_861
 E  in_degree_862
 G  order_active_lb_863
 L  order_active_ub_864
 E  segment_load_conservation_865
 G  segment_prefix_lb_866
 L  segment_prefix_ub_867
 E  out_degree_868
 E  in_degree_869
 G  order_active_lb_870
 L  order_active_ub_871
 E  segment_load_conservation_872
 G  segment_prefix_lb_873
 L  segment_prefix_ub_874
 E  out_degree_875
 E  in_degree_876
 G  order_active_lb_877
 L  order_active_ub_878
 E  segment_load_conservation_879
 G  segment_prefix_lb_880
 L  segment_prefix_ub_881
 E  out_degree_882
 E  in_degree_883
 G  order_active_lb_884
 L  order_active_ub_885
 E  service_visit_def_886
 E  free_load_conservation_887
 E  out_degree_888
 E  in_degree_889
 G  order_active_lb_890
 L  order_active_ub_891
 E  service_visit_def_892
 E  free_load_conservation_893
 E  out_degree_894
 E  in_degree_895
 G  order_active_lb_896
 L  order_active_ub_897
 E  service_visit_def_898
 E  free_load_conservation_899
 E  out_degree_900
 E  in_degree_901
 G  order_active_lb_902
 L  order_active_ub_903
 E  service_visit_def_904
 E  free_load_conservation_905
 E  out_degree_906
 E  in_degree_907
 G  order_active_lb_908
 L  order_active_ub_909
 E  service_visit_def_910
 E  free_load_conservation_911
 E  out_degree_912
 E  in_degree_913
 G  order_active_lb_914
 L  order_active_ub_915
 E  service_visit_def_916
 E  free_load_conservation_917
 E  out_degree_918
 E  in_degree_919
 G  order_active_lb_920
 L  order_active_ub_921
 E  service_visit_def_922
 E  free_load_conservation_923
 E  out_degree_924
 E  in_degree_925
 G  order_active_lb_926
 L  order_active_ub_927
 E  service_visit_def_928
 E  free_load_conservation_929
 G  fixed_segment_relative_order_930
 G  fixed_segment_relative_order_931
 G  fixed_segment_relative_order_932
 G  fixed_segment_relative_order_933
 G  fixed_segment_relative_order_934
 G  fixed_segment_relative_order_935
 L  original_T_including_depot_unload_936
 L  arc_capacity_937
 L  arc_capacity_938
 L  arc_capacity_939
 L  arc_capacity_940
 L  arc_capacity_941
 L  arc_capacity_942
 L  arc_capacity_943
 L  arc_capacity_944
 L  arc_capacity_945
 L  arc_capacity_946
 L  arc_capacity_947
 L  arc_capacity_948
 G  connected_order_arc_949
 L  arc_capacity_950
 G  connected_order_arc_951
 L  arc_capacity_952
 G  connected_order_arc_953
 L  arc_capacity_954
 G  connected_order_arc_955
 L  arc_capacity_956
 G  connected_order_arc_957
 L  arc_capacity_958
 G  connected_order_arc_959
 L  arc_capacity_960
 G  connected_order_arc_961
 L  arc_capacity_962
 G  connected_order_arc_963
 L  arc_capacity_964
 L  arc_capacity_965
 G  connected_order_arc_966
 L  arc_capacity_967
 G  connected_order_arc_968
 L  arc_capacity_969
 G  connected_order_arc_970
 L  arc_capacity_971
 G  connected_order_arc_972
 L  arc_capacity_973
 G  connected_order_arc_974
 L  arc_capacity_975
 G  connected_order_arc_976
 L  arc_capacity_977
 G  connected_order_arc_978
 L  arc_capacity_979
 G  connected_order_arc_980
 L  arc_capacity_981
 L  arc_capacity_982
 G  connected_order_arc_983
 L  arc_capacity_984
 G  connected_order_arc_985
 L  arc_capacity_986
 G  connected_order_arc_987
 L  arc_capacity_988
 G  connected_order_arc_989
 L  arc_capacity_990
 G  connected_order_arc_991
 L  arc_capacity_992
 G  connected_order_arc_993
 L  arc_capacity_994
 G  connected_order_arc_995
 L  arc_capacity_996
 G  connected_order_arc_997
 L  arc_capacity_998
 L  arc_capacity_999
 G  connected_order_arc_1000
 L  arc_capacity_1001
 G  connected_order_arc_1002
 L  arc_capacity_1003
 G  connected_order_arc_1004
 L  arc_capacity_1005
 G  connected_order_arc_1006
 L  arc_capacity_1007
 G  connected_order_arc_1008
 L  arc_capacity_1009
 G  connected_order_arc_1010
 L  arc_capacity_1011
 G  connected_order_arc_1012
 L  arc_capacity_1013
 G  connected_order_arc_1014
 L  arc_capacity_1015
 L  arc_capacity_1016
 G  connected_order_arc_1017
 L  arc_capacity_1018
 G  connected_order_arc_1019
 L  arc_capacity_1020
 G  connected_order_arc_1021
 L  arc_capacity_1022
 G  connected_order_arc_1023
 L  arc_capacity_1024
 G  connected_order_arc_1025
 L  arc_capacity_1026
 G  connected_order_arc_1027
 L  arc_capacity_1028
 G  connected_order_arc_1029
 L  arc_capacity_1030
 G  connected_order_arc_1031
 L  arc_capacity_1032
 L  arc_capacity_1033
 G  connected_order_arc_1034
 L  arc_capacity_1035
 G  connected_order_arc_1036
 L  arc_capacity_1037
 G  connected_order_arc_1038
 L  arc_capacity_1039
 G  connected_order_arc_1040
 L  arc_capacity_1041
 G  connected_order_arc_1042
 L  arc_capacity_1043
 G  connected_order_arc_1044
 L  arc_capacity_1045
 G  connected_order_arc_1046
 L  arc_capacity_1047
 G  connected_order_arc_1048
 L  arc_capacity_1049
 L  arc_capacity_1050
 G  connected_order_arc_1051
 L  arc_capacity_1052
 G  connected_order_arc_1053
 L  arc_capacity_1054
 G  connected_order_arc_1055
 L  arc_capacity_1056
 G  connected_order_arc_1057
 L  arc_capacity_1058
 G  connected_order_arc_1059
 L  arc_capacity_1060
 G  connected_order_arc_1061
 L  arc_capacity_1062
 G  connected_order_arc_1063
 L  arc_capacity_1064
 G  connected_order_arc_1065
 L  arc_capacity_1066
 L  arc_capacity_1067
 G  connected_order_arc_1068
 L  arc_capacity_1069
 G  connected_order_arc_1070
 L  arc_capacity_1071
 G  connected_order_arc_1072
 L  arc_capacity_1073
 G  connected_order_arc_1074
 L  arc_capacity_1075
 G  connected_order_arc_1076
 L  arc_capacity_1077
 G  connected_order_arc_1078
 L  arc_capacity_1079
 G  connected_order_arc_1080
 L  arc_capacity_1081
 G  connected_order_arc_1082
 L  arc_capacity_1083
 L  arc_capacity_1084
 G  connected_order_arc_1085
 L  arc_capacity_1086
 G  connected_order_arc_1087
 L  arc_capacity_1088
 G  connected_order_arc_1089
 L  arc_capacity_1090
 G  connected_order_arc_1091
 L  arc_capacity_1092
 G  connected_order_arc_1093
 L  arc_capacity_1094
 G  connected_order_arc_1095
 L  arc_capacity_1096
 G  connected_order_arc_1097
 L  arc_capacity_1098
 G  connected_order_arc_1099
 E  depot_departure_or_bypass_1100
 E  depot_return_or_bypass_1101
 E  out_degree_1102
 E  in_degree_1103
 G  order_active_lb_1104
 L  order_active_ub_1105
 E  segment_load_conservation_1106
 G  segment_prefix_lb_1107
 L  segment_prefix_ub_1108
 E  out_degree_1109
 E  in_degree_1110
 G  order_active_lb_1111
 L  order_active_ub_1112
 E  service_visit_def_1113
 E  free_load_conservation_1114
 E  out_degree_1115
 E  in_degree_1116
 G  order_active_lb_1117
 L  order_active_ub_1118
 E  service_visit_def_1119
 E  free_load_conservation_1120
 E  out_degree_1121
 E  in_degree_1122
 G  order_active_lb_1123
 L  order_active_ub_1124
 E  service_visit_def_1125
 E  free_load_conservation_1126
 E  out_degree_1127
 E  in_degree_1128
 G  order_active_lb_1129
 L  order_active_ub_1130
 E  service_visit_def_1131
 E  free_load_conservation_1132
 E  out_degree_1133
 E  in_degree_1134
 G  order_active_lb_1135
 L  order_active_ub_1136
 E  service_visit_def_1137
 E  free_load_conservation_1138
 E  out_degree_1139
 E  in_degree_1140
 G  order_active_lb_1141
 L  order_active_ub_1142
 E  service_visit_def_1143
 E  free_load_conservation_1144
 E  out_degree_1145
 E  in_degree_1146
 G  order_active_lb_1147
 L  order_active_ub_1148
 E  service_visit_def_1149
 E  free_load_conservation_1150
 E  out_degree_1151
 E  in_degree_1152
 G  order_active_lb_1153
 L  order_active_ub_1154
 E  service_visit_def_1155
 E  free_load_conservation_1156
 L  original_T_including_depot_unload_1157
COLUMNS
    t         normalized_mass_14_33  -1
    t         normalized_mass_13_40  -1
    t         normalized_mass_18_75  -1
    t         normalized_mass_17_112  -1
    t         normalized_mass_20_147  -1
    t         normalized_mass_12_182  -1
    t         normalized_mass_1_217  -1
    t         normalized_mass_10_224  -1
    t         normalization_285  8.675
    t         full_original_Gini_286  -30.225
    q         OBJ       1
    q         parent_nonstrict_scope_228  1
    q         full_original_Gini_286  20
    MARKER    'MARKER'                 'INTORG'
    x_14_0    OBJ       3.2863847044708572e-02
    x_14_0    product_lb_0  -4.3669635739740753e-02
    x_14_0    product_ub_1  -1.1527377521625362e-01
    x_14_0    onehot_14_32  1
    x_14_0    parent_nonstrict_scope_228  7.6682309770986667e-02
    x_14_0    unique_nonzero_owner_287  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_0    product_lb_0  1
    w_14_0    product_ub_1  1
    w_14_0    normalized_mass_14_33  1
    w_14_0    full_original_Gini_286  -8.675
    MARKER    'MARKER'                 'INTORG'
    x_14_1    OBJ       2.1909231363139048e-02
    x_14_1    product_lb_2  -4.3669635739740753e-02
    x_14_1    product_ub_3  -1.1527377521625362e-01
    x_14_1    onehot_14_32  1
    x_14_1    stock_lb_226  1
    x_14_1    stock_ub_227  1
    x_14_1    parent_nonstrict_scope_228  6.5727694089417144e-02
    x_14_1    unique_nonzero_owner_288  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_1    product_lb_2  1
    w_14_1    product_ub_3  1
    w_14_1    normalized_mass_14_33  1
    w_14_1    normalized_ratio_14_34  -1.4285714285714285e-01
    w_14_1    full_original_Gini_286  -7.8178571428571457e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_2    OBJ       1.0954615681569524e-02
    x_14_2    product_lb_4  -4.3669635739740753e-02
    x_14_2    product_ub_5  -1.1527377521625362e-01
    x_14_2    onehot_14_32  1
    x_14_2    stock_lb_226  2
    x_14_2    stock_ub_227  2
    x_14_2    parent_nonstrict_scope_228  5.4773078407847620e-02
    x_14_2    unique_nonzero_owner_289  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_2    product_lb_4  1
    w_14_2    product_ub_5  1
    w_14_2    normalized_mass_14_33  1
    w_14_2    normalized_ratio_14_34  -2.8571428571428570e-01
    w_14_2    full_original_Gini_286  -6.9607142857142863e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_3    product_lb_6  -4.3669635739740753e-02
    x_14_3    product_ub_7  -1.1527377521625362e-01
    x_14_3    onehot_14_32  1
    x_14_3    stock_lb_226  3
    x_14_3    stock_ub_227  3
    x_14_3    parent_nonstrict_scope_228  4.3818462726278096e-02
    x_14_3    unique_nonzero_owner_290  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_3    product_lb_6  1
    w_14_3    product_ub_7  1
    w_14_3    normalized_mass_14_33  1
    w_14_3    normalized_ratio_14_34  -4.2857142857142855e-01
    w_14_3    full_original_Gini_286  -6.1035714285714278e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_4    OBJ       -1.0954615681569524e-02
    x_14_4    product_lb_8  -4.3669635739740753e-02
    x_14_4    product_ub_9  -1.1527377521625362e-01
    x_14_4    onehot_14_32  1
    x_14_4    stock_lb_226  4
    x_14_4    stock_ub_227  4
    x_14_4    parent_nonstrict_scope_228  3.2863847044708572e-02
    x_14_4    unique_nonzero_owner_291  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_4    product_lb_8  1
    w_14_4    product_ub_9  1
    w_14_4    normalized_mass_14_33  1
    w_14_4    normalized_ratio_14_34  -5.7142857142857140e-01
    w_14_4    full_original_Gini_286  -5.2464285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_5    OBJ       -2.1909231363139041e-02
    x_14_5    product_lb_10  -4.3669635739740753e-02
    x_14_5    product_ub_11  -1.1527377521625362e-01
    x_14_5    onehot_14_32  1
    x_14_5    stock_lb_226  5
    x_14_5    stock_ub_227  5
    x_14_5    parent_nonstrict_scope_228  2.1909231363139055e-02
    x_14_5    unique_nonzero_owner_292  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_5    product_lb_10  1
    w_14_5    product_ub_11  1
    w_14_5    normalized_mass_14_33  1
    w_14_5    normalized_ratio_14_34  -7.1428571428571419e-01
    w_14_5    full_original_Gini_286  -4.3892857142857151e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_6    OBJ       -3.2863847044708572e-02
    x_14_6    product_lb_12  -4.3669635739740753e-02
    x_14_6    product_ub_13  -1.1527377521625362e-01
    x_14_6    onehot_14_32  1
    x_14_6    stock_lb_226  6
    x_14_6    stock_ub_227  6
    x_14_6    parent_nonstrict_scope_228  1.0954615681569527e-02
    x_14_6    unique_nonzero_owner_293  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_6    product_lb_12  1
    w_14_6    product_ub_13  1
    w_14_6    normalized_mass_14_33  1
    w_14_6    normalized_ratio_14_34  -8.5714285714285710e-01
    w_14_6    full_original_Gini_286  -3.8607142857142858e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_7    OBJ       -4.3818462726278096e-02
    x_14_7    product_lb_14  -4.3669635739740753e-02
    x_14_7    product_ub_15  -1.1527377521625362e-01
    x_14_7    onehot_14_32  1
    x_14_7    stock_lb_226  7
    x_14_7    stock_ub_227  7
    x_14_7    unique_nonzero_owner_294  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_7    product_lb_14  1
    w_14_7    product_ub_15  1
    w_14_7    normalized_mass_14_33  1
    w_14_7    normalized_ratio_14_34  -1
    w_14_7    full_original_Gini_286  -3.575
    MARKER    'MARKER'                 'INTORG'
    x_14_8    OBJ       -3.2863847044708579e-02
    x_14_8    product_lb_16  -4.3669635739740753e-02
    x_14_8    product_ub_17  -1.1527377521625362e-01
    x_14_8    onehot_14_32  1
    x_14_8    stock_lb_226  8
    x_14_8    stock_ub_227  8
    x_14_8    parent_nonstrict_scope_228  1.0954615681569519e-02
    x_14_8    unique_nonzero_owner_295  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_8    product_lb_16  1
    w_14_8    product_ub_17  1
    w_14_8    normalized_mass_14_33  1
    w_14_8    normalized_ratio_14_34  -1.1428571428571428e+00
    w_14_8    full_original_Gini_286  -5.0392857142857128e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_9    OBJ       -2.1909231363139058e-02
    x_14_9    product_lb_18  -4.3669635739740753e-02
    x_14_9    product_ub_19  -1.1527377521625362e-01
    x_14_9    onehot_14_32  1
    x_14_9    stock_lb_226  9
    x_14_9    stock_ub_227  9
    x_14_9    parent_nonstrict_scope_228  2.1909231363139037e-02
    x_14_9    unique_nonzero_owner_296  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_9    product_lb_18  1
    w_14_9    product_ub_19  1
    w_14_9    normalized_mass_14_33  1
    w_14_9    normalized_ratio_14_34  -1.2857142857142856e+00
    w_14_9    full_original_Gini_286  -6.7535714285714272e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_10   OBJ       -1.0954615681569538e-02
    x_14_10   product_lb_20  -4.3669635739740753e-02
    x_14_10   product_ub_21  -1.1527377521625362e-01
    x_14_10   onehot_14_32  1
    x_14_10   stock_lb_226  10
    x_14_10   stock_ub_227  10
    x_14_10   parent_nonstrict_scope_228  3.2863847044708558e-02
    x_14_10   unique_nonzero_owner_297  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_10   product_lb_20  1
    w_14_10   product_ub_21  1
    w_14_10   normalized_mass_14_33  1
    w_14_10   normalized_ratio_14_34  -1.4285714285714284e+00
    w_14_10   full_original_Gini_286  -8.4678571428571434e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_11   product_lb_22  -4.3669635739740753e-02
    x_14_11   product_ub_23  -1.1527377521625362e-01
    x_14_11   onehot_14_32  1
    x_14_11   stock_lb_226  11
    x_14_11   stock_ub_227  11
    x_14_11   parent_nonstrict_scope_228  4.3818462726278096e-02
    MARKER    'MARKER'                 'INTEND'
    w_14_11   product_lb_22  1
    w_14_11   product_ub_23  1
    w_14_11   normalized_mass_14_33  1
    w_14_11   normalized_ratio_14_34  -1.5714285714285714e+00
    w_14_11   full_original_Gini_286  -1.0182142857142855e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_12   OBJ       1.0954615681569517e-02
    x_14_12   product_lb_24  -4.3669635739740753e-02
    x_14_12   product_ub_25  -1.1527377521625362e-01
    x_14_12   onehot_14_32  1
    x_14_12   stock_lb_226  12
    x_14_12   stock_ub_227  12
    x_14_12   parent_nonstrict_scope_228  5.4773078407847613e-02
    x_14_12   unique_nonzero_owner_298  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_12   product_lb_24  1
    w_14_12   product_ub_25  1
    w_14_12   normalized_mass_14_33  1
    w_14_12   normalized_ratio_14_34  -1.7142857142857142e+00
    w_14_12   full_original_Gini_286  -1.1896428571428570e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_13   OBJ       2.1909231363139034e-02
    x_14_13   product_lb_26  -4.3669635739740753e-02
    x_14_13   product_ub_27  -1.1527377521625362e-01
    x_14_13   onehot_14_32  1
    x_14_13   stock_lb_226  13
    x_14_13   stock_ub_227  13
    x_14_13   parent_nonstrict_scope_228  6.5727694089417130e-02
    x_14_13   unique_nonzero_owner_299  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_13   product_lb_26  1
    w_14_13   product_ub_27  1
    w_14_13   normalized_mass_14_33  1
    w_14_13   normalized_ratio_14_34  -1.8571428571428570e+00
    w_14_13   full_original_Gini_286  -1.3610714285714286e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_14   OBJ       3.2863847044708572e-02
    x_14_14   product_lb_28  -4.3669635739740753e-02
    x_14_14   product_ub_29  -1.1527377521625362e-01
    x_14_14   onehot_14_32  1
    x_14_14   stock_lb_226  14
    x_14_14   stock_ub_227  14
    x_14_14   parent_nonstrict_scope_228  7.6682309770986667e-02
    x_14_14   unique_nonzero_owner_300  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_14   product_lb_28  1
    w_14_14   product_ub_29  1
    w_14_14   normalized_mass_14_33  1
    w_14_14   normalized_ratio_14_34  -2
    w_14_14   full_original_Gini_286  -15.325
    MARKER    'MARKER'                 'INTORG'
    x_14_15   OBJ       4.3818462726278096e-02
    x_14_15   product_lb_30  -4.3669635739740753e-02
    x_14_15   product_ub_31  -1.1527377521625362e-01
    x_14_15   onehot_14_32  1
    x_14_15   stock_lb_226  15
    x_14_15   stock_ub_227  15
    x_14_15   parent_nonstrict_scope_228  8.7636925452556191e-02
    x_14_15   unique_nonzero_owner_301  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_15   product_lb_30  1
    w_14_15   product_ub_31  1
    w_14_15   normalized_mass_14_33  1
    w_14_15   normalized_ratio_14_34  -2.1428571428571428e+00
    w_14_15   full_original_Gini_286  -1.7039285714285711e+01
    rho_14    normalized_ratio_14_34  1
    rho_14    block_pair_pos_247  -1
    rho_14    block_pair_neg_248  1
    rho_14    block_pair_pos_249  -1
    rho_14    block_pair_neg_250  1
    rho_14    block_pair_pos_251  -1
    rho_14    block_pair_neg_252  1
    rho_14    block_pair_pos_253  -1
    rho_14    block_pair_neg_254  1
    rho_14    block_pair_pos_255  -1
    rho_14    block_pair_neg_256  1
    rho_14    block_pair_pos_257  -1
    rho_14    block_pair_neg_258  1
    rho_14    block_pair_pos_259  -1
    rho_14    block_pair_neg_260  1
    rho_14    normalization_285  1
    MARKER    'MARKER'                 'INTORG'
    x_13_0    OBJ       6.3380304899829966e-03
    x_13_0    product_lb_35  -4.3669635739740753e-02
    x_13_0    product_ub_36  -1.1527377521625362e-01
    x_13_0    onehot_13_39  1
    x_13_0    parent_nonstrict_scope_228  1.2676060979965993e-02
    MARKER    'MARKER'                 'INTEND'
    w_13_0    product_lb_35  1
    w_13_0    product_ub_36  1
    w_13_0    normalized_mass_13_40  1
    w_13_0    full_original_Gini_286  -8.675
    MARKER    'MARKER'                 'INTORG'
    x_13_1    OBJ       -6.3380304899829966e-03
    x_13_1    product_lb_37  -4.3669635739740753e-02
    x_13_1    product_ub_38  -1.1527377521625362e-01
    x_13_1    onehot_13_39  1
    x_13_1    stock_lb_226  1
    x_13_1    stock_ub_227  1
    x_13_1    unique_nonzero_owner_302  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_1    product_lb_37  1
    w_13_1    product_ub_38  1
    w_13_1    normalized_mass_13_40  1
    w_13_1    normalized_ratio_13_41  -1
    w_13_1    full_original_Gini_286  -3.575
    rho_13    normalized_ratio_13_41  1
    rho_13    block_pair_pos_235  -1
    rho_13    block_pair_neg_236  1
    rho_13    block_pair_pos_237  -1
    rho_13    block_pair_neg_238  1
    rho_13    block_pair_pos_239  -1
    rho_13    block_pair_neg_240  1
    rho_13    block_pair_pos_241  -1
    rho_13    block_pair_neg_242  1
    rho_13    block_pair_pos_243  -1
    rho_13    block_pair_neg_244  1
    rho_13    block_pair_pos_245  -1
    rho_13    block_pair_neg_246  1
    rho_13    block_pair_pos_253  1
    rho_13    block_pair_neg_254  -1
    rho_13    normalization_285  1
    MARKER    'MARKER'                 'INTORG'
    x_18_0    OBJ       3.2863847044708572e-02
    x_18_0    product_lb_42  -4.3669635739740753e-02
    x_18_0    product_ub_43  -1.1527377521625362e-01
    x_18_0    onehot_18_74  1
    x_18_0    parent_nonstrict_scope_228  7.6682309770986667e-02
    MARKER    'MARKER'                 'INTEND'
    w_18_0    product_lb_42  1
    w_18_0    product_ub_43  1
    w_18_0    normalized_mass_18_75  1
    w_18_0    full_original_Gini_286  -8.675
    MARKER    'MARKER'                 'INTORG'
    x_18_1    OBJ       2.1909231363139048e-02
    x_18_1    product_lb_44  -4.3669635739740753e-02
    x_18_1    product_ub_45  -1.1527377521625362e-01
    x_18_1    onehot_18_74  1
    x_18_1    stock_lb_226  1
    x_18_1    stock_ub_227  1
    x_18_1    parent_nonstrict_scope_228  6.5727694089417144e-02
    x_18_1    unique_nonzero_owner_303  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_1    product_lb_44  1
    w_18_1    product_ub_45  1
    w_18_1    normalized_mass_18_75  1
    w_18_1    normalized_ratio_18_76  -1.4285714285714285e-01
    w_18_1    full_original_Gini_286  -7.8178571428571457e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_2    OBJ       1.0954615681569524e-02
    x_18_2    product_lb_46  -4.3669635739740753e-02
    x_18_2    product_ub_47  -1.1527377521625362e-01
    x_18_2    onehot_18_74  1
    x_18_2    stock_lb_226  2
    x_18_2    stock_ub_227  2
    x_18_2    parent_nonstrict_scope_228  5.4773078407847620e-02
    x_18_2    unique_nonzero_owner_304  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_2    product_lb_46  1
    w_18_2    product_ub_47  1
    w_18_2    normalized_mass_18_75  1
    w_18_2    normalized_ratio_18_76  -2.8571428571428570e-01
    w_18_2    full_original_Gini_286  -6.9607142857142863e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_3    product_lb_48  -4.3669635739740753e-02
    x_18_3    product_ub_49  -1.1527377521625362e-01
    x_18_3    onehot_18_74  1
    x_18_3    stock_lb_226  3
    x_18_3    stock_ub_227  3
    x_18_3    parent_nonstrict_scope_228  4.3818462726278096e-02
    x_18_3    unique_nonzero_owner_305  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_3    product_lb_48  1
    w_18_3    product_ub_49  1
    w_18_3    normalized_mass_18_75  1
    w_18_3    normalized_ratio_18_76  -4.2857142857142855e-01
    w_18_3    full_original_Gini_286  -6.1035714285714278e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_4    OBJ       -1.0954615681569524e-02
    x_18_4    product_lb_50  -4.3669635739740753e-02
    x_18_4    product_ub_51  -1.1527377521625362e-01
    x_18_4    onehot_18_74  1
    x_18_4    stock_lb_226  4
    x_18_4    stock_ub_227  4
    x_18_4    parent_nonstrict_scope_228  3.2863847044708572e-02
    x_18_4    unique_nonzero_owner_306  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_4    product_lb_50  1
    w_18_4    product_ub_51  1
    w_18_4    normalized_mass_18_75  1
    w_18_4    normalized_ratio_18_76  -5.7142857142857140e-01
    w_18_4    full_original_Gini_286  -5.2464285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_5    OBJ       -2.1909231363139041e-02
    x_18_5    product_lb_52  -4.3669635739740753e-02
    x_18_5    product_ub_53  -1.1527377521625362e-01
    x_18_5    onehot_18_74  1
    x_18_5    stock_lb_226  5
    x_18_5    stock_ub_227  5
    x_18_5    parent_nonstrict_scope_228  2.1909231363139055e-02
    x_18_5    unique_nonzero_owner_307  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_5    product_lb_52  1
    w_18_5    product_ub_53  1
    w_18_5    normalized_mass_18_75  1
    w_18_5    normalized_ratio_18_76  -7.1428571428571419e-01
    w_18_5    full_original_Gini_286  -4.3892857142857151e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_6    OBJ       -3.2863847044708572e-02
    x_18_6    product_lb_54  -4.3669635739740753e-02
    x_18_6    product_ub_55  -1.1527377521625362e-01
    x_18_6    onehot_18_74  1
    x_18_6    stock_lb_226  6
    x_18_6    stock_ub_227  6
    x_18_6    parent_nonstrict_scope_228  1.0954615681569527e-02
    x_18_6    unique_nonzero_owner_308  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_6    product_lb_54  1
    w_18_6    product_ub_55  1
    w_18_6    normalized_mass_18_75  1
    w_18_6    normalized_ratio_18_76  -8.5714285714285710e-01
    w_18_6    full_original_Gini_286  -3.8607142857142858e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_7    OBJ       -4.3818462726278096e-02
    x_18_7    product_lb_56  -4.3669635739740753e-02
    x_18_7    product_ub_57  -1.1527377521625362e-01
    x_18_7    onehot_18_74  1
    x_18_7    stock_lb_226  7
    x_18_7    stock_ub_227  7
    x_18_7    unique_nonzero_owner_309  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_7    product_lb_56  1
    w_18_7    product_ub_57  1
    w_18_7    normalized_mass_18_75  1
    w_18_7    normalized_ratio_18_76  -1
    w_18_7    full_original_Gini_286  -3.575
    MARKER    'MARKER'                 'INTORG'
    x_18_8    OBJ       -3.2863847044708579e-02
    x_18_8    product_lb_58  -4.3669635739740753e-02
    x_18_8    product_ub_59  -1.1527377521625362e-01
    x_18_8    onehot_18_74  1
    x_18_8    stock_lb_226  8
    x_18_8    stock_ub_227  8
    x_18_8    parent_nonstrict_scope_228  1.0954615681569519e-02
    x_18_8    unique_nonzero_owner_310  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_8    product_lb_58  1
    w_18_8    product_ub_59  1
    w_18_8    normalized_mass_18_75  1
    w_18_8    normalized_ratio_18_76  -1.1428571428571428e+00
    w_18_8    full_original_Gini_286  -5.0392857142857128e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_9    OBJ       -2.1909231363139058e-02
    x_18_9    product_lb_60  -4.3669635739740753e-02
    x_18_9    product_ub_61  -1.1527377521625362e-01
    x_18_9    onehot_18_74  1
    x_18_9    stock_lb_226  9
    x_18_9    stock_ub_227  9
    x_18_9    parent_nonstrict_scope_228  2.1909231363139037e-02
    x_18_9    unique_nonzero_owner_311  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_9    product_lb_60  1
    w_18_9    product_ub_61  1
    w_18_9    normalized_mass_18_75  1
    w_18_9    normalized_ratio_18_76  -1.2857142857142856e+00
    w_18_9    full_original_Gini_286  -6.7535714285714272e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_10   OBJ       -1.0954615681569538e-02
    x_18_10   product_lb_62  -4.3669635739740753e-02
    x_18_10   product_ub_63  -1.1527377521625362e-01
    x_18_10   onehot_18_74  1
    x_18_10   stock_lb_226  10
    x_18_10   stock_ub_227  10
    x_18_10   parent_nonstrict_scope_228  3.2863847044708558e-02
    x_18_10   unique_nonzero_owner_312  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_10   product_lb_62  1
    w_18_10   product_ub_63  1
    w_18_10   normalized_mass_18_75  1
    w_18_10   normalized_ratio_18_76  -1.4285714285714284e+00
    w_18_10   full_original_Gini_286  -8.4678571428571434e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_11   product_lb_64  -4.3669635739740753e-02
    x_18_11   product_ub_65  -1.1527377521625362e-01
    x_18_11   onehot_18_74  1
    x_18_11   stock_lb_226  11
    x_18_11   stock_ub_227  11
    x_18_11   parent_nonstrict_scope_228  4.3818462726278096e-02
    x_18_11   unique_nonzero_owner_313  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_11   product_lb_64  1
    w_18_11   product_ub_65  1
    w_18_11   normalized_mass_18_75  1
    w_18_11   normalized_ratio_18_76  -1.5714285714285714e+00
    w_18_11   full_original_Gini_286  -1.0182142857142855e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_12   OBJ       1.0954615681569517e-02
    x_18_12   product_lb_66  -4.3669635739740753e-02
    x_18_12   product_ub_67  -1.1527377521625362e-01
    x_18_12   onehot_18_74  1
    x_18_12   stock_lb_226  12
    x_18_12   stock_ub_227  12
    x_18_12   parent_nonstrict_scope_228  5.4773078407847613e-02
    x_18_12   unique_nonzero_owner_314  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_12   product_lb_66  1
    w_18_12   product_ub_67  1
    w_18_12   normalized_mass_18_75  1
    w_18_12   normalized_ratio_18_76  -1.7142857142857142e+00
    w_18_12   full_original_Gini_286  -1.1896428571428570e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_13   OBJ       2.1909231363139034e-02
    x_18_13   product_lb_68  -4.3669635739740753e-02
    x_18_13   product_ub_69  -1.1527377521625362e-01
    x_18_13   onehot_18_74  1
    x_18_13   stock_lb_226  13
    x_18_13   stock_ub_227  13
    x_18_13   parent_nonstrict_scope_228  6.5727694089417130e-02
    x_18_13   unique_nonzero_owner_315  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_13   product_lb_68  1
    w_18_13   product_ub_69  1
    w_18_13   normalized_mass_18_75  1
    w_18_13   normalized_ratio_18_76  -1.8571428571428570e+00
    w_18_13   full_original_Gini_286  -1.3610714285714286e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_14   OBJ       3.2863847044708572e-02
    x_18_14   product_lb_70  -4.3669635739740753e-02
    x_18_14   product_ub_71  -1.1527377521625362e-01
    x_18_14   onehot_18_74  1
    x_18_14   stock_lb_226  14
    x_18_14   stock_ub_227  14
    x_18_14   parent_nonstrict_scope_228  7.6682309770986667e-02
    x_18_14   unique_nonzero_owner_316  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_14   product_lb_70  1
    w_18_14   product_ub_71  1
    w_18_14   normalized_mass_18_75  1
    w_18_14   normalized_ratio_18_76  -2
    w_18_14   full_original_Gini_286  -15.325
    MARKER    'MARKER'                 'INTORG'
    x_18_15   OBJ       4.3818462726278096e-02
    x_18_15   product_lb_72  -4.3669635739740753e-02
    x_18_15   product_ub_73  -1.1527377521625362e-01
    x_18_15   onehot_18_74  1
    x_18_15   stock_lb_226  15
    x_18_15   stock_ub_227  15
    x_18_15   parent_nonstrict_scope_228  8.7636925452556191e-02
    x_18_15   unique_nonzero_owner_317  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_15   product_lb_72  1
    w_18_15   product_ub_73  1
    w_18_15   normalized_mass_18_75  1
    w_18_15   normalized_ratio_18_76  -2.1428571428571428e+00
    w_18_15   full_original_Gini_286  -1.7039285714285711e+01
    rho_18    normalized_ratio_18_76  1
    rho_18    block_pair_pos_243  1
    rho_18    block_pair_neg_244  -1
    rho_18    block_pair_pos_257  1
    rho_18    block_pair_neg_258  -1
    rho_18    block_pair_pos_269  -1
    rho_18    block_pair_neg_270  1
    rho_18    block_pair_pos_271  -1
    rho_18    block_pair_neg_272  1
    rho_18    block_pair_pos_273  -1
    rho_18    block_pair_neg_274  1
    rho_18    block_pair_pos_275  -1
    rho_18    block_pair_neg_276  1
    rho_18    block_pair_pos_277  -1
    rho_18    block_pair_neg_278  1
    rho_18    normalization_285  1
    MARKER    'MARKER'                 'INTORG'
    x_17_0    OBJ       6.3380304899829959e-02
    x_17_0    product_lb_77  -4.3669635739740753e-02
    x_17_0    product_ub_78  -1.1527377521625362e-01
    x_17_0    onehot_17_111  1
    x_17_0    parent_nonstrict_scope_228  1.2676060979965992e-01
    x_17_0    unique_nonzero_owner_318  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_0    product_lb_77  1
    w_17_0    product_ub_78  1
    w_17_0    normalized_mass_17_112  1
    w_17_0    full_original_Gini_286  -8.675
    MARKER    'MARKER'                 'INTORG'
    x_17_1    OBJ       4.9295792699867738e-02
    x_17_1    product_lb_79  -4.3669635739740753e-02
    x_17_1    product_ub_80  -1.1527377521625362e-01
    x_17_1    onehot_17_111  1
    x_17_1    stock_lb_226  1
    x_17_1    stock_ub_227  1
    x_17_1    parent_nonstrict_scope_228  1.1267609759969770e-01
    x_17_1    unique_nonzero_owner_319  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_1    product_lb_79  1
    w_17_1    product_ub_80  1
    w_17_1    normalized_mass_17_112  1
    w_17_1    normalized_ratio_17_113  -1.1111111111111110e-01
    w_17_1    full_original_Gini_286  -8.0083333333333329e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_2    OBJ       3.5211280499905531e-02
    x_17_2    product_lb_81  -4.3669635739740753e-02
    x_17_2    product_ub_82  -1.1527377521625362e-01
    x_17_2    onehot_17_111  1
    x_17_2    stock_lb_226  2
    x_17_2    stock_ub_227  2
    x_17_2    parent_nonstrict_scope_228  9.8591585399735490e-02
    x_17_2    unique_nonzero_owner_320  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_2    product_lb_81  1
    w_17_2    product_ub_82  1
    w_17_2    normalized_mass_17_112  1
    w_17_2    normalized_ratio_17_113  -2.2222222222222221e-01
    w_17_2    full_original_Gini_286  -7.3416666666666668e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_3    OBJ       2.1126768299943324e-02
    x_17_3    product_lb_83  -4.3669635739740753e-02
    x_17_3    product_ub_84  -1.1527377521625362e-01
    x_17_3    onehot_17_111  1
    x_17_3    stock_lb_226  3
    x_17_3    stock_ub_227  3
    x_17_3    parent_nonstrict_scope_228  8.4507073199773283e-02
    MARKER    'MARKER'                 'INTEND'
    w_17_3    product_lb_83  1
    w_17_3    product_ub_84  1
    w_17_3    normalized_mass_17_112  1
    w_17_3    normalized_ratio_17_113  -3.3333333333333331e-01
    w_17_3    full_original_Gini_286  -6.6750000000000007e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_4    OBJ       7.0422560999811035e-03
    x_17_4    product_lb_85  -4.3669635739740753e-02
    x_17_4    product_ub_86  -1.1527377521625362e-01
    x_17_4    onehot_17_111  1
    x_17_4    stock_lb_226  4
    x_17_4    stock_ub_227  4
    x_17_4    parent_nonstrict_scope_228  7.0422560999811062e-02
    x_17_4    unique_nonzero_owner_321  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_4    product_lb_85  1
    w_17_4    product_ub_86  1
    w_17_4    normalized_mass_17_112  1
    w_17_4    normalized_ratio_17_113  -4.4444444444444442e-01
    w_17_4    full_original_Gini_286  -6.0083333333333329e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_5    OBJ       -0.00704225609998111
    x_17_5    product_lb_87  -4.3669635739740753e-02
    x_17_5    product_ub_88  -1.1527377521625362e-01
    x_17_5    onehot_17_111  1
    x_17_5    stock_lb_226  5
    x_17_5    stock_ub_227  5
    x_17_5    parent_nonstrict_scope_228  5.6338048799848849e-02
    x_17_5    unique_nonzero_owner_322  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_5    product_lb_87  1
    w_17_5    product_ub_88  1
    w_17_5    normalized_mass_17_112  1
    w_17_5    normalized_ratio_17_113  -5.5555555555555558e-01
    w_17_5    full_original_Gini_286  -5.3416666666666668e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_6    OBJ       -2.1126768299943317e-02
    x_17_6    product_lb_89  -4.3669635739740753e-02
    x_17_6    product_ub_90  -1.1527377521625362e-01
    x_17_6    onehot_17_111  1
    x_17_6    stock_lb_226  6
    x_17_6    stock_ub_227  6
    x_17_6    parent_nonstrict_scope_228  4.2253536599886642e-02
    x_17_6    unique_nonzero_owner_323  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_6    product_lb_89  1
    w_17_6    product_ub_90  1
    w_17_6    normalized_mass_17_112  1
    w_17_6    normalized_ratio_17_113  -6.6666666666666663e-01
    w_17_6    full_original_Gini_286  -4.6750000000000007e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_7    OBJ       -3.5211280499905517e-02
    x_17_7    product_lb_91  -4.3669635739740753e-02
    x_17_7    product_ub_92  -1.1527377521625362e-01
    x_17_7    onehot_17_111  1
    x_17_7    stock_lb_226  7
    x_17_7    stock_ub_227  7
    x_17_7    parent_nonstrict_scope_228  2.8169024399924438e-02
    x_17_7    unique_nonzero_owner_324  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_7    product_lb_91  1
    w_17_7    product_ub_92  1
    w_17_7    normalized_mass_17_112  1
    w_17_7    normalized_ratio_17_113  -7.7777777777777768e-01
    w_17_7    full_original_Gini_286  -4.0638888888888891e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_8    OBJ       -4.9295792699867738e-02
    x_17_8    product_lb_93  -4.3669635739740753e-02
    x_17_8    product_ub_94  -1.1527377521625362e-01
    x_17_8    onehot_17_111  1
    x_17_8    stock_lb_226  8
    x_17_8    stock_ub_227  8
    x_17_8    parent_nonstrict_scope_228  1.4084512199962219e-02
    x_17_8    unique_nonzero_owner_325  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_8    product_lb_93  1
    w_17_8    product_ub_94  1
    w_17_8    normalized_mass_17_112  1
    w_17_8    normalized_ratio_17_113  -8.8888888888888884e-01
    w_17_8    full_original_Gini_286  -3.7972222222222225e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_9    OBJ       -6.3380304899829959e-02
    x_17_9    product_lb_95  -4.3669635739740753e-02
    x_17_9    product_ub_96  -1.1527377521625362e-01
    x_17_9    onehot_17_111  1
    x_17_9    stock_lb_226  9
    x_17_9    stock_ub_227  9
    x_17_9    unique_nonzero_owner_326  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_9    product_lb_95  1
    w_17_9    product_ub_96  1
    w_17_9    normalized_mass_17_112  1
    w_17_9    normalized_ratio_17_113  -1
    w_17_9    full_original_Gini_286  -3.575
    MARKER    'MARKER'                 'INTORG'
    x_17_10   OBJ       -4.9295792699867738e-02
    x_17_10   product_lb_97  -4.3669635739740753e-02
    x_17_10   product_ub_98  -1.1527377521625362e-01
    x_17_10   onehot_17_111  1
    x_17_10   stock_lb_226  10
    x_17_10   stock_ub_227  10
    x_17_10   parent_nonstrict_scope_228  1.4084512199962219e-02
    x_17_10   unique_nonzero_owner_327  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_10   product_lb_97  1
    w_17_10   product_ub_98  1
    w_17_10   normalized_mass_17_112  1
    w_17_10   normalized_ratio_17_113  -1.1111111111111112e+00
    w_17_10   full_original_Gini_286  -4.6861111111111118e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_11   OBJ       -3.5211280499905545e-02
    x_17_11   product_lb_99  -4.3669635739740753e-02
    x_17_11   product_ub_100  -1.1527377521625362e-01
    x_17_11   onehot_17_111  1
    x_17_11   stock_lb_226  11
    x_17_11   stock_ub_227  11
    x_17_11   parent_nonstrict_scope_228  2.8169024399924410e-02
    x_17_11   unique_nonzero_owner_328  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_11   product_lb_99  1
    w_17_11   product_ub_100  1
    w_17_11   normalized_mass_17_112  1
    w_17_11   normalized_ratio_17_113  -1.2222222222222221e+00
    w_17_11   full_original_Gini_286  -5.9916666666666663e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_12   OBJ       -2.1126768299943331e-02
    x_17_12   product_lb_101  -4.3669635739740753e-02
    x_17_12   product_ub_102  -1.1527377521625362e-01
    x_17_12   onehot_17_111  1
    x_17_12   stock_lb_226  12
    x_17_12   stock_ub_227  12
    x_17_12   parent_nonstrict_scope_228  4.2253536599886628e-02
    x_17_12   unique_nonzero_owner_329  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_12   product_lb_101  1
    w_17_12   product_ub_102  1
    w_17_12   normalized_mass_17_112  1
    w_17_12   normalized_ratio_17_113  -1.3333333333333333e+00
    w_17_12   full_original_Gini_286  -7.3249999999999975e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_13   OBJ       -0.00704225609998111
    x_17_13   product_lb_103  -4.3669635739740753e-02
    x_17_13   product_ub_104  -1.1527377521625362e-01
    x_17_13   onehot_17_111  1
    x_17_13   stock_lb_226  13
    x_17_13   stock_ub_227  13
    x_17_13   parent_nonstrict_scope_228  5.6338048799848849e-02
    x_17_13   unique_nonzero_owner_330  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_13   product_lb_103  1
    w_17_13   product_ub_104  1
    w_17_13   normalized_mass_17_112  1
    w_17_13   normalized_ratio_17_113  -1.4444444444444444e+00
    w_17_13   full_original_Gini_286  -8.6583333333333332e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_14   OBJ       7.0422560999810757e-03
    x_17_14   product_lb_105  -4.3669635739740753e-02
    x_17_14   product_ub_106  -1.1527377521625362e-01
    x_17_14   onehot_17_111  1
    x_17_14   stock_lb_226  14
    x_17_14   stock_ub_227  14
    x_17_14   parent_nonstrict_scope_228  7.0422560999811035e-02
    x_17_14   unique_nonzero_owner_331  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_14   product_lb_105  1
    w_17_14   product_ub_106  1
    w_17_14   normalized_mass_17_112  1
    w_17_14   normalized_ratio_17_113  -1.5555555555555554e+00
    w_17_14   full_original_Gini_286  -9.9916666666666654e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_15   OBJ       2.1126768299943297e-02
    x_17_15   product_lb_107  -4.3669635739740753e-02
    x_17_15   product_ub_108  -1.1527377521625362e-01
    x_17_15   onehot_17_111  1
    x_17_15   stock_lb_226  15
    x_17_15   stock_ub_227  15
    x_17_15   parent_nonstrict_scope_228  8.4507073199773255e-02
    x_17_15   unique_nonzero_owner_332  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_15   product_lb_107  1
    w_17_15   product_ub_108  1
    w_17_15   normalized_mass_17_112  1
    w_17_15   normalized_ratio_17_113  -1.6666666666666665e+00
    w_17_15   full_original_Gini_286  -1.1324999999999996e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_16   OBJ       3.5211280499905517e-02
    x_17_16   product_lb_109  -4.3669635739740753e-02
    x_17_16   product_ub_110  -1.1527377521625362e-01
    x_17_16   onehot_17_111  1
    x_17_16   stock_lb_226  16
    x_17_16   stock_ub_227  16
    x_17_16   parent_nonstrict_scope_228  9.8591585399735476e-02
    x_17_16   unique_nonzero_owner_333  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_16   product_lb_109  1
    w_17_16   product_ub_110  1
    w_17_16   normalized_mass_17_112  1
    w_17_16   normalized_ratio_17_113  -1.7777777777777777e+00
    w_17_16   full_original_Gini_286  -1.2658333333333335e+01
    rho_17    normalized_ratio_17_113  1
    rho_17    block_pair_pos_241  1
    rho_17    block_pair_neg_242  -1
    rho_17    block_pair_pos_255  1
    rho_17    block_pair_neg_256  -1
    rho_17    block_pair_pos_261  -1
    rho_17    block_pair_neg_262  1
    rho_17    block_pair_pos_263  -1
    rho_17    block_pair_neg_264  1
    rho_17    block_pair_pos_265  -1
    rho_17    block_pair_neg_266  1
    rho_17    block_pair_pos_267  -1
    rho_17    block_pair_neg_268  1
    rho_17    block_pair_pos_275  1
    rho_17    block_pair_neg_276  -1
    rho_17    normalization_285  1
    MARKER    'MARKER'                 'INTORG'
    x_20_0    OBJ       5.0078236648368350e-02
    x_20_0    product_lb_114  -4.3669635739740753e-02
    x_20_0    product_ub_115  -1.1527377521625362e-01
    x_20_0    onehot_20_146  1
    x_20_0    parent_nonstrict_scope_228  1.0015647329673670e-01
    x_20_0    unique_nonzero_owner_334  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_0    product_lb_114  1
    w_20_0    product_ub_115  1
    w_20_0    normalized_mass_20_147  1
    w_20_0    full_original_Gini_286  -8.675
    MARKER    'MARKER'                 'INTORG'
    x_20_1    OBJ       3.7558677486276261e-02
    x_20_1    product_lb_116  -4.3669635739740753e-02
    x_20_1    product_ub_117  -1.1527377521625362e-01
    x_20_1    onehot_20_146  1
    x_20_1    stock_lb_226  1
    x_20_1    stock_ub_227  1
    x_20_1    parent_nonstrict_scope_228  8.7636914134644611e-02
    x_20_1    unique_nonzero_owner_335  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_1    product_lb_116  1
    w_20_1    product_ub_117  1
    w_20_1    normalized_mass_20_147  1
    w_20_1    normalized_ratio_20_148  -0.125
    w_20_1    full_original_Gini_286  -7.925
    MARKER    'MARKER'                 'INTORG'
    x_20_2    OBJ       2.5039118324184172e-02
    x_20_2    product_lb_118  -4.3669635739740753e-02
    x_20_2    product_ub_119  -1.1527377521625362e-01
    x_20_2    onehot_20_146  1
    x_20_2    stock_lb_226  2
    x_20_2    stock_ub_227  2
    x_20_2    parent_nonstrict_scope_228  7.5117354972552522e-02
    x_20_2    unique_nonzero_owner_336  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_2    product_lb_118  1
    w_20_2    product_ub_119  1
    w_20_2    normalized_mass_20_147  1
    w_20_2    normalized_ratio_20_148  -0.25
    w_20_2    full_original_Gini_286  -7.175
    MARKER    'MARKER'                 'INTORG'
    x_20_3    OBJ       1.2519559162092082e-02
    x_20_3    product_lb_120  -4.3669635739740753e-02
    x_20_3    product_ub_121  -1.1527377521625362e-01
    x_20_3    onehot_20_146  1
    x_20_3    stock_lb_226  3
    x_20_3    stock_ub_227  3
    x_20_3    parent_nonstrict_scope_228  6.2597795810460433e-02
    x_20_3    unique_nonzero_owner_337  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_3    product_lb_120  1
    w_20_3    product_ub_121  1
    w_20_3    normalized_mass_20_147  1
    w_20_3    normalized_ratio_20_148  -0.375
    w_20_3    full_original_Gini_286  -6.425
    MARKER    'MARKER'                 'INTORG'
    x_20_4    product_lb_122  -4.3669635739740753e-02
    x_20_4    product_ub_123  -1.1527377521625362e-01
    x_20_4    onehot_20_146  1
    x_20_4    stock_lb_226  4
    x_20_4    stock_ub_227  4
    x_20_4    parent_nonstrict_scope_228  5.0078236648368350e-02
    x_20_4    unique_nonzero_owner_338  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_4    product_lb_122  1
    w_20_4    product_ub_123  1
    w_20_4    normalized_mass_20_147  1
    w_20_4    normalized_ratio_20_148  -0.5
    w_20_4    full_original_Gini_286  -5.675
    MARKER    'MARKER'                 'INTORG'
    x_20_5    OBJ       -1.2519559162092089e-02
    x_20_5    product_lb_124  -4.3669635739740753e-02
    x_20_5    product_ub_125  -1.1527377521625362e-01
    x_20_5    onehot_20_146  1
    x_20_5    stock_lb_226  5
    x_20_5    stock_ub_227  5
    x_20_5    parent_nonstrict_scope_228  3.7558677486276261e-02
    x_20_5    unique_nonzero_owner_339  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_5    product_lb_124  1
    w_20_5    product_ub_125  1
    w_20_5    normalized_mass_20_147  1
    w_20_5    normalized_ratio_20_148  -0.625
    w_20_5    full_original_Gini_286  -4.925
    MARKER    'MARKER'                 'INTORG'
    x_20_6    OBJ       -2.5039118324184175e-02
    x_20_6    product_lb_126  -4.3669635739740753e-02
    x_20_6    product_ub_127  -1.1527377521625362e-01
    x_20_6    onehot_20_146  1
    x_20_6    stock_lb_226  6
    x_20_6    stock_ub_227  6
    x_20_6    parent_nonstrict_scope_228  2.5039118324184175e-02
    x_20_6    unique_nonzero_owner_340  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_6    product_lb_126  1
    w_20_6    product_ub_127  1
    w_20_6    normalized_mass_20_147  1
    w_20_6    normalized_ratio_20_148  -0.75
    w_20_6    full_original_Gini_286  -4.175
    MARKER    'MARKER'                 'INTORG'
    x_20_7    OBJ       -3.7558677486276261e-02
    x_20_7    product_lb_128  -4.3669635739740753e-02
    x_20_7    product_ub_129  -1.1527377521625362e-01
    x_20_7    onehot_20_146  1
    x_20_7    stock_lb_226  7
    x_20_7    stock_ub_227  7
    x_20_7    parent_nonstrict_scope_228  1.2519559162092088e-02
    x_20_7    unique_nonzero_owner_341  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_7    product_lb_128  1
    w_20_7    product_ub_129  1
    w_20_7    normalized_mass_20_147  1
    w_20_7    normalized_ratio_20_148  -0.875
    w_20_7    full_original_Gini_286  -3.825
    MARKER    'MARKER'                 'INTORG'
    x_20_8    OBJ       -5.0078236648368350e-02
    x_20_8    product_lb_130  -4.3669635739740753e-02
    x_20_8    product_ub_131  -1.1527377521625362e-01
    x_20_8    onehot_20_146  1
    x_20_8    stock_lb_226  8
    x_20_8    stock_ub_227  8
    x_20_8    unique_nonzero_owner_342  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_8    product_lb_130  1
    w_20_8    product_ub_131  1
    w_20_8    normalized_mass_20_147  1
    w_20_8    normalized_ratio_20_148  -1
    w_20_8    full_original_Gini_286  -3.575
    MARKER    'MARKER'                 'INTORG'
    x_20_9    OBJ       -3.7558677486276261e-02
    x_20_9    product_lb_132  -4.3669635739740753e-02
    x_20_9    product_ub_133  -1.1527377521625362e-01
    x_20_9    onehot_20_146  1
    x_20_9    stock_lb_226  9
    x_20_9    stock_ub_227  9
    x_20_9    parent_nonstrict_scope_228  1.2519559162092088e-02
    x_20_9    unique_nonzero_owner_343  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_9    product_lb_132  1
    w_20_9    product_ub_133  1
    w_20_9    normalized_mass_20_147  1
    w_20_9    normalized_ratio_20_148  -1.125
    w_20_9    full_original_Gini_286  -4.825
    MARKER    'MARKER'                 'INTORG'
    x_20_10   OBJ       -2.5039118324184175e-02
    x_20_10   product_lb_134  -4.3669635739740753e-02
    x_20_10   product_ub_135  -1.1527377521625362e-01
    x_20_10   onehot_20_146  1
    x_20_10   stock_lb_226  10
    x_20_10   stock_ub_227  10
    x_20_10   parent_nonstrict_scope_228  2.5039118324184175e-02
    x_20_10   unique_nonzero_owner_344  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_10   product_lb_134  1
    w_20_10   product_ub_135  1
    w_20_10   normalized_mass_20_147  1
    w_20_10   normalized_ratio_20_148  -1.25
    w_20_10   full_original_Gini_286  -6.325
    MARKER    'MARKER'                 'INTORG'
    x_20_11   OBJ       -1.2519559162092089e-02
    x_20_11   product_lb_136  -4.3669635739740753e-02
    x_20_11   product_ub_137  -1.1527377521625362e-01
    x_20_11   onehot_20_146  1
    x_20_11   stock_lb_226  11
    x_20_11   stock_ub_227  11
    x_20_11   parent_nonstrict_scope_228  3.7558677486276261e-02
    x_20_11   unique_nonzero_owner_345  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_11   product_lb_136  1
    w_20_11   product_ub_137  1
    w_20_11   normalized_mass_20_147  1
    w_20_11   normalized_ratio_20_148  -1.375
    w_20_11   full_original_Gini_286  -7.825
    MARKER    'MARKER'                 'INTORG'
    x_20_12   product_lb_138  -4.3669635739740753e-02
    x_20_12   product_ub_139  -1.1527377521625362e-01
    x_20_12   onehot_20_146  1
    x_20_12   stock_lb_226  12
    x_20_12   stock_ub_227  12
    x_20_12   parent_nonstrict_scope_228  5.0078236648368350e-02
    MARKER    'MARKER'                 'INTEND'
    w_20_12   product_lb_138  1
    w_20_12   product_ub_139  1
    w_20_12   normalized_mass_20_147  1
    w_20_12   normalized_ratio_20_148  -1.5
    w_20_12   full_original_Gini_286  -9.325
    MARKER    'MARKER'                 'INTORG'
    x_20_13   OBJ       1.2519559162092082e-02
    x_20_13   product_lb_140  -4.3669635739740753e-02
    x_20_13   product_ub_141  -1.1527377521625362e-01
    x_20_13   onehot_20_146  1
    x_20_13   stock_lb_226  13
    x_20_13   stock_ub_227  13
    x_20_13   parent_nonstrict_scope_228  6.2597795810460433e-02
    x_20_13   unique_nonzero_owner_346  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_13   product_lb_140  1
    w_20_13   product_ub_141  1
    w_20_13   normalized_mass_20_147  1
    w_20_13   normalized_ratio_20_148  -1.625
    w_20_13   full_original_Gini_286  -10.825
    MARKER    'MARKER'                 'INTORG'
    x_20_14   OBJ       2.5039118324184172e-02
    x_20_14   product_lb_142  -4.3669635739740753e-02
    x_20_14   product_ub_143  -1.1527377521625362e-01
    x_20_14   onehot_20_146  1
    x_20_14   stock_lb_226  14
    x_20_14   stock_ub_227  14
    x_20_14   parent_nonstrict_scope_228  7.5117354972552522e-02
    x_20_14   unique_nonzero_owner_347  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_14   product_lb_142  1
    w_20_14   product_ub_143  1
    w_20_14   normalized_mass_20_147  1
    w_20_14   normalized_ratio_20_148  -1.75
    w_20_14   full_original_Gini_286  -12.325
    MARKER    'MARKER'                 'INTORG'
    x_20_15   OBJ       3.7558677486276261e-02
    x_20_15   product_lb_144  -4.3669635739740753e-02
    x_20_15   product_ub_145  -1.1527377521625362e-01
    x_20_15   onehot_20_146  1
    x_20_15   stock_lb_226  15
    x_20_15   stock_ub_227  15
    x_20_15   parent_nonstrict_scope_228  8.7636914134644611e-02
    x_20_15   unique_nonzero_owner_348  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_15   product_lb_144  1
    w_20_15   product_ub_145  1
    w_20_15   normalized_mass_20_147  1
    w_20_15   normalized_ratio_20_148  -1.875
    w_20_15   full_original_Gini_286  -13.825
    rho_20    normalized_ratio_20_148  1
    rho_20    block_pair_pos_245  1
    rho_20    block_pair_neg_246  -1
    rho_20    block_pair_pos_259  1
    rho_20    block_pair_neg_260  -1
    rho_20    block_pair_pos_267  1
    rho_20    block_pair_neg_268  -1
    rho_20    block_pair_pos_277  1
    rho_20    block_pair_neg_278  -1
    rho_20    block_pair_pos_279  -1
    rho_20    block_pair_neg_280  1
    rho_20    block_pair_pos_281  -1
    rho_20    block_pair_neg_282  1
    rho_20    block_pair_pos_283  -1
    rho_20    block_pair_neg_284  1
    rho_20    normalization_285  1
    MARKER    'MARKER'                 'INTORG'
    x_12_0    OBJ       3.2863847044708572e-02
    x_12_0    product_lb_149  -4.3669635739740753e-02
    x_12_0    product_ub_150  -1.1527377521625362e-01
    x_12_0    onehot_12_181  1
    x_12_0    parent_nonstrict_scope_228  7.6682309770986667e-02
    x_12_0    unique_nonzero_owner_349  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_0    product_lb_149  1
    w_12_0    product_ub_150  1
    w_12_0    normalized_mass_12_182  1
    w_12_0    full_original_Gini_286  -8.675
    MARKER    'MARKER'                 'INTORG'
    x_12_1    OBJ       2.1909231363139048e-02
    x_12_1    product_lb_151  -4.3669635739740753e-02
    x_12_1    product_ub_152  -1.1527377521625362e-01
    x_12_1    onehot_12_181  1
    x_12_1    stock_lb_226  1
    x_12_1    stock_ub_227  1
    x_12_1    parent_nonstrict_scope_228  6.5727694089417144e-02
    x_12_1    unique_nonzero_owner_350  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_1    product_lb_151  1
    w_12_1    product_ub_152  1
    w_12_1    normalized_mass_12_182  1
    w_12_1    normalized_ratio_12_183  -1.4285714285714285e-01
    w_12_1    full_original_Gini_286  -7.8178571428571457e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_2    OBJ       1.0954615681569524e-02
    x_12_2    product_lb_153  -4.3669635739740753e-02
    x_12_2    product_ub_154  -1.1527377521625362e-01
    x_12_2    onehot_12_181  1
    x_12_2    stock_lb_226  2
    x_12_2    stock_ub_227  2
    x_12_2    parent_nonstrict_scope_228  5.4773078407847620e-02
    x_12_2    unique_nonzero_owner_351  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_2    product_lb_153  1
    w_12_2    product_ub_154  1
    w_12_2    normalized_mass_12_182  1
    w_12_2    normalized_ratio_12_183  -2.8571428571428570e-01
    w_12_2    full_original_Gini_286  -6.9607142857142863e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_3    product_lb_155  -4.3669635739740753e-02
    x_12_3    product_ub_156  -1.1527377521625362e-01
    x_12_3    onehot_12_181  1
    x_12_3    stock_lb_226  3
    x_12_3    stock_ub_227  3
    x_12_3    parent_nonstrict_scope_228  4.3818462726278096e-02
    x_12_3    unique_nonzero_owner_352  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_3    product_lb_155  1
    w_12_3    product_ub_156  1
    w_12_3    normalized_mass_12_182  1
    w_12_3    normalized_ratio_12_183  -4.2857142857142855e-01
    w_12_3    full_original_Gini_286  -6.1035714285714278e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_4    OBJ       -1.0954615681569524e-02
    x_12_4    product_lb_157  -4.3669635739740753e-02
    x_12_4    product_ub_158  -1.1527377521625362e-01
    x_12_4    onehot_12_181  1
    x_12_4    stock_lb_226  4
    x_12_4    stock_ub_227  4
    x_12_4    parent_nonstrict_scope_228  3.2863847044708572e-02
    x_12_4    unique_nonzero_owner_353  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_4    product_lb_157  1
    w_12_4    product_ub_158  1
    w_12_4    normalized_mass_12_182  1
    w_12_4    normalized_ratio_12_183  -5.7142857142857140e-01
    w_12_4    full_original_Gini_286  -5.2464285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_5    OBJ       -2.1909231363139041e-02
    x_12_5    product_lb_159  -4.3669635739740753e-02
    x_12_5    product_ub_160  -1.1527377521625362e-01
    x_12_5    onehot_12_181  1
    x_12_5    stock_lb_226  5
    x_12_5    stock_ub_227  5
    x_12_5    parent_nonstrict_scope_228  2.1909231363139055e-02
    x_12_5    unique_nonzero_owner_354  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_5    product_lb_159  1
    w_12_5    product_ub_160  1
    w_12_5    normalized_mass_12_182  1
    w_12_5    normalized_ratio_12_183  -7.1428571428571419e-01
    w_12_5    full_original_Gini_286  -4.3892857142857151e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_6    OBJ       -3.2863847044708572e-02
    x_12_6    product_lb_161  -4.3669635739740753e-02
    x_12_6    product_ub_162  -1.1527377521625362e-01
    x_12_6    onehot_12_181  1
    x_12_6    stock_lb_226  6
    x_12_6    stock_ub_227  6
    x_12_6    parent_nonstrict_scope_228  1.0954615681569527e-02
    x_12_6    unique_nonzero_owner_355  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_6    product_lb_161  1
    w_12_6    product_ub_162  1
    w_12_6    normalized_mass_12_182  1
    w_12_6    normalized_ratio_12_183  -8.5714285714285710e-01
    w_12_6    full_original_Gini_286  -3.8607142857142858e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_7    OBJ       -4.3818462726278096e-02
    x_12_7    product_lb_163  -4.3669635739740753e-02
    x_12_7    product_ub_164  -1.1527377521625362e-01
    x_12_7    onehot_12_181  1
    x_12_7    stock_lb_226  7
    x_12_7    stock_ub_227  7
    x_12_7    unique_nonzero_owner_356  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_7    product_lb_163  1
    w_12_7    product_ub_164  1
    w_12_7    normalized_mass_12_182  1
    w_12_7    normalized_ratio_12_183  -1
    w_12_7    full_original_Gini_286  -3.575
    MARKER    'MARKER'                 'INTORG'
    x_12_8    OBJ       -3.2863847044708579e-02
    x_12_8    product_lb_165  -4.3669635739740753e-02
    x_12_8    product_ub_166  -1.1527377521625362e-01
    x_12_8    onehot_12_181  1
    x_12_8    stock_lb_226  8
    x_12_8    stock_ub_227  8
    x_12_8    parent_nonstrict_scope_228  1.0954615681569519e-02
    x_12_8    unique_nonzero_owner_357  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_8    product_lb_165  1
    w_12_8    product_ub_166  1
    w_12_8    normalized_mass_12_182  1
    w_12_8    normalized_ratio_12_183  -1.1428571428571428e+00
    w_12_8    full_original_Gini_286  -5.0392857142857128e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_9    OBJ       -2.1909231363139058e-02
    x_12_9    product_lb_167  -4.3669635739740753e-02
    x_12_9    product_ub_168  -1.1527377521625362e-01
    x_12_9    onehot_12_181  1
    x_12_9    stock_lb_226  9
    x_12_9    stock_ub_227  9
    x_12_9    parent_nonstrict_scope_228  2.1909231363139037e-02
    x_12_9    unique_nonzero_owner_358  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_9    product_lb_167  1
    w_12_9    product_ub_168  1
    w_12_9    normalized_mass_12_182  1
    w_12_9    normalized_ratio_12_183  -1.2857142857142856e+00
    w_12_9    full_original_Gini_286  -6.7535714285714272e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_10   OBJ       -1.0954615681569538e-02
    x_12_10   product_lb_169  -4.3669635739740753e-02
    x_12_10   product_ub_170  -1.1527377521625362e-01
    x_12_10   onehot_12_181  1
    x_12_10   stock_lb_226  10
    x_12_10   stock_ub_227  10
    x_12_10   parent_nonstrict_scope_228  3.2863847044708558e-02
    x_12_10   unique_nonzero_owner_359  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_10   product_lb_169  1
    w_12_10   product_ub_170  1
    w_12_10   normalized_mass_12_182  1
    w_12_10   normalized_ratio_12_183  -1.4285714285714284e+00
    w_12_10   full_original_Gini_286  -8.4678571428571434e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_11   product_lb_171  -4.3669635739740753e-02
    x_12_11   product_ub_172  -1.1527377521625362e-01
    x_12_11   onehot_12_181  1
    x_12_11   stock_lb_226  11
    x_12_11   stock_ub_227  11
    x_12_11   parent_nonstrict_scope_228  4.3818462726278096e-02
    MARKER    'MARKER'                 'INTEND'
    w_12_11   product_lb_171  1
    w_12_11   product_ub_172  1
    w_12_11   normalized_mass_12_182  1
    w_12_11   normalized_ratio_12_183  -1.5714285714285714e+00
    w_12_11   full_original_Gini_286  -1.0182142857142855e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_12   OBJ       1.0954615681569517e-02
    x_12_12   product_lb_173  -4.3669635739740753e-02
    x_12_12   product_ub_174  -1.1527377521625362e-01
    x_12_12   onehot_12_181  1
    x_12_12   stock_lb_226  12
    x_12_12   stock_ub_227  12
    x_12_12   parent_nonstrict_scope_228  5.4773078407847613e-02
    x_12_12   unique_nonzero_owner_360  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_12   product_lb_173  1
    w_12_12   product_ub_174  1
    w_12_12   normalized_mass_12_182  1
    w_12_12   normalized_ratio_12_183  -1.7142857142857142e+00
    w_12_12   full_original_Gini_286  -1.1896428571428570e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_13   OBJ       2.1909231363139034e-02
    x_12_13   product_lb_175  -4.3669635739740753e-02
    x_12_13   product_ub_176  -1.1527377521625362e-01
    x_12_13   onehot_12_181  1
    x_12_13   stock_lb_226  13
    x_12_13   stock_ub_227  13
    x_12_13   parent_nonstrict_scope_228  6.5727694089417130e-02
    x_12_13   unique_nonzero_owner_361  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_13   product_lb_175  1
    w_12_13   product_ub_176  1
    w_12_13   normalized_mass_12_182  1
    w_12_13   normalized_ratio_12_183  -1.8571428571428570e+00
    w_12_13   full_original_Gini_286  -1.3610714285714286e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_14   OBJ       3.2863847044708572e-02
    x_12_14   product_lb_177  -4.3669635739740753e-02
    x_12_14   product_ub_178  -1.1527377521625362e-01
    x_12_14   onehot_12_181  1
    x_12_14   stock_lb_226  14
    x_12_14   stock_ub_227  14
    x_12_14   parent_nonstrict_scope_228  7.6682309770986667e-02
    x_12_14   unique_nonzero_owner_362  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_14   product_lb_177  1
    w_12_14   product_ub_178  1
    w_12_14   normalized_mass_12_182  1
    w_12_14   normalized_ratio_12_183  -2
    w_12_14   full_original_Gini_286  -15.325
    MARKER    'MARKER'                 'INTORG'
    x_12_15   OBJ       4.3818462726278096e-02
    x_12_15   product_lb_179  -4.3669635739740753e-02
    x_12_15   product_ub_180  -1.1527377521625362e-01
    x_12_15   onehot_12_181  1
    x_12_15   stock_lb_226  15
    x_12_15   stock_ub_227  15
    x_12_15   parent_nonstrict_scope_228  8.7636925452556191e-02
    x_12_15   unique_nonzero_owner_363  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_15   product_lb_179  1
    w_12_15   product_ub_180  1
    w_12_15   normalized_mass_12_182  1
    w_12_15   normalized_ratio_12_183  -2.1428571428571428e+00
    w_12_15   full_original_Gini_286  -1.7039285714285711e+01
    rho_12    normalized_ratio_12_183  1
    rho_12    block_pair_pos_231  -1
    rho_12    block_pair_neg_232  1
    rho_12    block_pair_pos_233  -1
    rho_12    block_pair_neg_234  1
    rho_12    block_pair_pos_239  1
    rho_12    block_pair_neg_240  -1
    rho_12    block_pair_pos_251  1
    rho_12    block_pair_neg_252  -1
    rho_12    block_pair_pos_265  1
    rho_12    block_pair_neg_266  -1
    rho_12    block_pair_pos_273  1
    rho_12    block_pair_neg_274  -1
    rho_12    block_pair_pos_283  1
    rho_12    block_pair_neg_284  -1
    rho_12    normalization_285  1
    MARKER    'MARKER'                 'INTORG'
    x_1_0     OBJ       3.2863847044708572e-02
    x_1_0     product_lb_184  -4.3669635739740753e-02
    x_1_0     product_ub_185  -1.1527377521625362e-01
    x_1_0     onehot_1_216  1
    x_1_0     parent_nonstrict_scope_228  7.6682309770986667e-02
    x_1_0     unique_nonzero_owner_364  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_0     product_lb_184  1
    w_1_0     product_ub_185  1
    w_1_0     normalized_mass_1_217  1
    w_1_0     full_original_Gini_286  -8.675
    MARKER    'MARKER'                 'INTORG'
    x_1_1     OBJ       2.1909231363139048e-02
    x_1_1     product_lb_186  -4.3669635739740753e-02
    x_1_1     product_ub_187  -1.1527377521625362e-01
    x_1_1     onehot_1_216  1
    x_1_1     stock_lb_226  1
    x_1_1     stock_ub_227  1
    x_1_1     parent_nonstrict_scope_228  6.5727694089417144e-02
    MARKER    'MARKER'                 'INTEND'
    w_1_1     product_lb_186  1
    w_1_1     product_ub_187  1
    w_1_1     normalized_mass_1_217  1
    w_1_1     normalized_ratio_1_218  -1.4285714285714285e-01
    w_1_1     full_original_Gini_286  -7.8178571428571457e+00
    MARKER    'MARKER'                 'INTORG'
    x_1_2     OBJ       1.0954615681569524e-02
    x_1_2     product_lb_188  -4.3669635739740753e-02
    x_1_2     product_ub_189  -1.1527377521625362e-01
    x_1_2     onehot_1_216  1
    x_1_2     stock_lb_226  2
    x_1_2     stock_ub_227  2
    x_1_2     parent_nonstrict_scope_228  5.4773078407847620e-02
    x_1_2     unique_nonzero_owner_365  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_2     product_lb_188  1
    w_1_2     product_ub_189  1
    w_1_2     normalized_mass_1_217  1
    w_1_2     normalized_ratio_1_218  -2.8571428571428570e-01
    w_1_2     full_original_Gini_286  -6.9607142857142863e+00
    MARKER    'MARKER'                 'INTORG'
    x_1_3     product_lb_190  -4.3669635739740753e-02
    x_1_3     product_ub_191  -1.1527377521625362e-01
    x_1_3     onehot_1_216  1
    x_1_3     stock_lb_226  3
    x_1_3     stock_ub_227  3
    x_1_3     parent_nonstrict_scope_228  4.3818462726278096e-02
    x_1_3     unique_nonzero_owner_366  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_3     product_lb_190  1
    w_1_3     product_ub_191  1
    w_1_3     normalized_mass_1_217  1
    w_1_3     normalized_ratio_1_218  -4.2857142857142855e-01
    w_1_3     full_original_Gini_286  -6.1035714285714278e+00
    MARKER    'MARKER'                 'INTORG'
    x_1_4     OBJ       -1.0954615681569524e-02
    x_1_4     product_lb_192  -4.3669635739740753e-02
    x_1_4     product_ub_193  -1.1527377521625362e-01
    x_1_4     onehot_1_216  1
    x_1_4     stock_lb_226  4
    x_1_4     stock_ub_227  4
    x_1_4     parent_nonstrict_scope_228  3.2863847044708572e-02
    x_1_4     unique_nonzero_owner_367  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_4     product_lb_192  1
    w_1_4     product_ub_193  1
    w_1_4     normalized_mass_1_217  1
    w_1_4     normalized_ratio_1_218  -5.7142857142857140e-01
    w_1_4     full_original_Gini_286  -5.2464285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_1_5     OBJ       -2.1909231363139041e-02
    x_1_5     product_lb_194  -4.3669635739740753e-02
    x_1_5     product_ub_195  -1.1527377521625362e-01
    x_1_5     onehot_1_216  1
    x_1_5     stock_lb_226  5
    x_1_5     stock_ub_227  5
    x_1_5     parent_nonstrict_scope_228  2.1909231363139055e-02
    x_1_5     unique_nonzero_owner_368  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_5     product_lb_194  1
    w_1_5     product_ub_195  1
    w_1_5     normalized_mass_1_217  1
    w_1_5     normalized_ratio_1_218  -7.1428571428571419e-01
    w_1_5     full_original_Gini_286  -4.3892857142857151e+00
    MARKER    'MARKER'                 'INTORG'
    x_1_6     OBJ       -3.2863847044708572e-02
    x_1_6     product_lb_196  -4.3669635739740753e-02
    x_1_6     product_ub_197  -1.1527377521625362e-01
    x_1_6     onehot_1_216  1
    x_1_6     stock_lb_226  6
    x_1_6     stock_ub_227  6
    x_1_6     parent_nonstrict_scope_228  1.0954615681569527e-02
    x_1_6     unique_nonzero_owner_369  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_6     product_lb_196  1
    w_1_6     product_ub_197  1
    w_1_6     normalized_mass_1_217  1
    w_1_6     normalized_ratio_1_218  -8.5714285714285710e-01
    w_1_6     full_original_Gini_286  -3.8607142857142858e+00
    MARKER    'MARKER'                 'INTORG'
    x_1_7     OBJ       -4.3818462726278096e-02
    x_1_7     product_lb_198  -4.3669635739740753e-02
    x_1_7     product_ub_199  -1.1527377521625362e-01
    x_1_7     onehot_1_216  1
    x_1_7     stock_lb_226  7
    x_1_7     stock_ub_227  7
    x_1_7     unique_nonzero_owner_370  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_7     product_lb_198  1
    w_1_7     product_ub_199  1
    w_1_7     normalized_mass_1_217  1
    w_1_7     normalized_ratio_1_218  -1
    w_1_7     full_original_Gini_286  -3.575
    MARKER    'MARKER'                 'INTORG'
    x_1_8     OBJ       -3.2863847044708579e-02
    x_1_8     product_lb_200  -4.3669635739740753e-02
    x_1_8     product_ub_201  -1.1527377521625362e-01
    x_1_8     onehot_1_216  1
    x_1_8     stock_lb_226  8
    x_1_8     stock_ub_227  8
    x_1_8     parent_nonstrict_scope_228  1.0954615681569519e-02
    x_1_8     unique_nonzero_owner_371  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_8     product_lb_200  1
    w_1_8     product_ub_201  1
    w_1_8     normalized_mass_1_217  1
    w_1_8     normalized_ratio_1_218  -1.1428571428571428e+00
    w_1_8     full_original_Gini_286  -5.0392857142857128e+00
    MARKER    'MARKER'                 'INTORG'
    x_1_9     OBJ       -2.1909231363139058e-02
    x_1_9     product_lb_202  -4.3669635739740753e-02
    x_1_9     product_ub_203  -1.1527377521625362e-01
    x_1_9     onehot_1_216  1
    x_1_9     stock_lb_226  9
    x_1_9     stock_ub_227  9
    x_1_9     parent_nonstrict_scope_228  2.1909231363139037e-02
    x_1_9     unique_nonzero_owner_372  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_9     product_lb_202  1
    w_1_9     product_ub_203  1
    w_1_9     normalized_mass_1_217  1
    w_1_9     normalized_ratio_1_218  -1.2857142857142856e+00
    w_1_9     full_original_Gini_286  -6.7535714285714272e+00
    MARKER    'MARKER'                 'INTORG'
    x_1_10    OBJ       -1.0954615681569538e-02
    x_1_10    product_lb_204  -4.3669635739740753e-02
    x_1_10    product_ub_205  -1.1527377521625362e-01
    x_1_10    onehot_1_216  1
    x_1_10    stock_lb_226  10
    x_1_10    stock_ub_227  10
    x_1_10    parent_nonstrict_scope_228  3.2863847044708558e-02
    x_1_10    unique_nonzero_owner_373  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_10    product_lb_204  1
    w_1_10    product_ub_205  1
    w_1_10    normalized_mass_1_217  1
    w_1_10    normalized_ratio_1_218  -1.4285714285714284e+00
    w_1_10    full_original_Gini_286  -8.4678571428571434e+00
    MARKER    'MARKER'                 'INTORG'
    x_1_11    product_lb_206  -4.3669635739740753e-02
    x_1_11    product_ub_207  -1.1527377521625362e-01
    x_1_11    onehot_1_216  1
    x_1_11    stock_lb_226  11
    x_1_11    stock_ub_227  11
    x_1_11    parent_nonstrict_scope_228  4.3818462726278096e-02
    x_1_11    unique_nonzero_owner_374  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_11    product_lb_206  1
    w_1_11    product_ub_207  1
    w_1_11    normalized_mass_1_217  1
    w_1_11    normalized_ratio_1_218  -1.5714285714285714e+00
    w_1_11    full_original_Gini_286  -1.0182142857142855e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_12    OBJ       1.0954615681569517e-02
    x_1_12    product_lb_208  -4.3669635739740753e-02
    x_1_12    product_ub_209  -1.1527377521625362e-01
    x_1_12    onehot_1_216  1
    x_1_12    stock_lb_226  12
    x_1_12    stock_ub_227  12
    x_1_12    parent_nonstrict_scope_228  5.4773078407847613e-02
    x_1_12    unique_nonzero_owner_375  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_12    product_lb_208  1
    w_1_12    product_ub_209  1
    w_1_12    normalized_mass_1_217  1
    w_1_12    normalized_ratio_1_218  -1.7142857142857142e+00
    w_1_12    full_original_Gini_286  -1.1896428571428570e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_13    OBJ       2.1909231363139034e-02
    x_1_13    product_lb_210  -4.3669635739740753e-02
    x_1_13    product_ub_211  -1.1527377521625362e-01
    x_1_13    onehot_1_216  1
    x_1_13    stock_lb_226  13
    x_1_13    stock_ub_227  13
    x_1_13    parent_nonstrict_scope_228  6.5727694089417130e-02
    x_1_13    unique_nonzero_owner_376  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_13    product_lb_210  1
    w_1_13    product_ub_211  1
    w_1_13    normalized_mass_1_217  1
    w_1_13    normalized_ratio_1_218  -1.8571428571428570e+00
    w_1_13    full_original_Gini_286  -1.3610714285714286e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_14    OBJ       3.2863847044708572e-02
    x_1_14    product_lb_212  -4.3669635739740753e-02
    x_1_14    product_ub_213  -1.1527377521625362e-01
    x_1_14    onehot_1_216  1
    x_1_14    stock_lb_226  14
    x_1_14    stock_ub_227  14
    x_1_14    parent_nonstrict_scope_228  7.6682309770986667e-02
    x_1_14    unique_nonzero_owner_377  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_14    product_lb_212  1
    w_1_14    product_ub_213  1
    w_1_14    normalized_mass_1_217  1
    w_1_14    normalized_ratio_1_218  -2
    w_1_14    full_original_Gini_286  -15.325
    MARKER    'MARKER'                 'INTORG'
    x_1_15    OBJ       4.3818462726278096e-02
    x_1_15    product_lb_214  -4.3669635739740753e-02
    x_1_15    product_ub_215  -1.1527377521625362e-01
    x_1_15    onehot_1_216  1
    x_1_15    stock_lb_226  15
    x_1_15    stock_ub_227  15
    x_1_15    parent_nonstrict_scope_228  8.7636925452556191e-02
    x_1_15    unique_nonzero_owner_378  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_15    product_lb_214  1
    w_1_15    product_ub_215  1
    w_1_15    normalized_mass_1_217  1
    w_1_15    normalized_ratio_1_218  -2.1428571428571428e+00
    w_1_15    full_original_Gini_286  -1.7039285714285711e+01
    rho_1     normalized_ratio_1_218  1
    rho_1     block_pair_pos_229  -1
    rho_1     block_pair_neg_230  1
    rho_1     block_pair_pos_231  1
    rho_1     block_pair_neg_232  -1
    rho_1     block_pair_pos_235  1
    rho_1     block_pair_neg_236  -1
    rho_1     block_pair_pos_247  1
    rho_1     block_pair_neg_248  -1
    rho_1     block_pair_pos_261  1
    rho_1     block_pair_neg_262  -1
    rho_1     block_pair_pos_269  1
    rho_1     block_pair_neg_270  -1
    rho_1     block_pair_pos_279  1
    rho_1     block_pair_neg_280  -1
    rho_1     normalization_285  1
    MARKER    'MARKER'                 'INTORG'
    x_10_0    OBJ       6.3380304899829966e-03
    x_10_0    product_lb_219  -4.3669635739740753e-02
    x_10_0    product_ub_220  -1.1527377521625362e-01
    x_10_0    onehot_10_223  1
    x_10_0    parent_nonstrict_scope_228  1.2676060979965993e-02
    MARKER    'MARKER'                 'INTEND'
    w_10_0    product_lb_219  1
    w_10_0    product_ub_220  1
    w_10_0    normalized_mass_10_224  1
    w_10_0    full_original_Gini_286  -8.675
    MARKER    'MARKER'                 'INTORG'
    x_10_1    OBJ       -6.3380304899829966e-03
    x_10_1    product_lb_221  -4.3669635739740753e-02
    x_10_1    product_ub_222  -1.1527377521625362e-01
    x_10_1    onehot_10_223  1
    x_10_1    stock_lb_226  1
    x_10_1    stock_ub_227  1
    x_10_1    unique_nonzero_owner_379  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_1    product_lb_221  1
    w_10_1    product_ub_222  1
    w_10_1    normalized_mass_10_224  1
    w_10_1    normalized_ratio_10_225  -1
    w_10_1    full_original_Gini_286  -3.575
    rho_10    normalized_ratio_10_225  1
    rho_10    block_pair_pos_229  1
    rho_10    block_pair_neg_230  -1
    rho_10    block_pair_pos_233  1
    rho_10    block_pair_neg_234  -1
    rho_10    block_pair_pos_237  1
    rho_10    block_pair_neg_238  -1
    rho_10    block_pair_pos_249  1
    rho_10    block_pair_neg_250  -1
    rho_10    block_pair_pos_263  1
    rho_10    block_pair_neg_264  -1
    rho_10    block_pair_pos_271  1
    rho_10    block_pair_neg_272  -1
    rho_10    block_pair_pos_281  1
    rho_10    block_pair_neg_282  -1
    rho_10    normalization_285  1
    a_14_13   block_pair_pos_253  1
    a_14_13   block_pair_neg_254  1
    a_14_13   full_original_Gini_286  -1
    a_14_18   block_pair_pos_257  1
    a_14_18   block_pair_neg_258  1
    a_14_18   full_original_Gini_286  -1
    a_14_17   block_pair_pos_255  1
    a_14_17   block_pair_neg_256  1
    a_14_17   full_original_Gini_286  -1
    a_14_20   block_pair_pos_259  1
    a_14_20   block_pair_neg_260  1
    a_14_20   full_original_Gini_286  -1
    a_14_12   block_pair_pos_251  1
    a_14_12   block_pair_neg_252  1
    a_14_12   full_original_Gini_286  -1
    a_14_1    block_pair_pos_247  1
    a_14_1    block_pair_neg_248  1
    a_14_1    full_original_Gini_286  -1
    a_14_10   block_pair_pos_249  1
    a_14_10   block_pair_neg_250  1
    a_14_10   full_original_Gini_286  -1
    a_13_18   block_pair_pos_243  1
    a_13_18   block_pair_neg_244  1
    a_13_18   full_original_Gini_286  -1
    a_13_17   block_pair_pos_241  1
    a_13_17   block_pair_neg_242  1
    a_13_17   full_original_Gini_286  -1
    a_13_20   block_pair_pos_245  1
    a_13_20   block_pair_neg_246  1
    a_13_20   full_original_Gini_286  -1
    a_13_12   block_pair_pos_239  1
    a_13_12   block_pair_neg_240  1
    a_13_12   full_original_Gini_286  -1
    a_13_1    block_pair_pos_235  1
    a_13_1    block_pair_neg_236  1
    a_13_1    full_original_Gini_286  -1
    a_13_10   block_pair_pos_237  1
    a_13_10   block_pair_neg_238  1
    a_13_10   full_original_Gini_286  -1
    a_18_17   block_pair_pos_275  1
    a_18_17   block_pair_neg_276  1
    a_18_17   full_original_Gini_286  -1
    a_18_20   block_pair_pos_277  1
    a_18_20   block_pair_neg_278  1
    a_18_20   full_original_Gini_286  -1
    a_18_12   block_pair_pos_273  1
    a_18_12   block_pair_neg_274  1
    a_18_12   full_original_Gini_286  -1
    a_18_1    block_pair_pos_269  1
    a_18_1    block_pair_neg_270  1
    a_18_1    full_original_Gini_286  -1
    a_18_10   block_pair_pos_271  1
    a_18_10   block_pair_neg_272  1
    a_18_10   full_original_Gini_286  -1
    a_17_20   block_pair_pos_267  1
    a_17_20   block_pair_neg_268  1
    a_17_20   full_original_Gini_286  -1
    a_17_12   block_pair_pos_265  1
    a_17_12   block_pair_neg_266  1
    a_17_12   full_original_Gini_286  -1
    a_17_1    block_pair_pos_261  1
    a_17_1    block_pair_neg_262  1
    a_17_1    full_original_Gini_286  -1
    a_17_10   block_pair_pos_263  1
    a_17_10   block_pair_neg_264  1
    a_17_10   full_original_Gini_286  -1
    a_20_12   block_pair_pos_283  1
    a_20_12   block_pair_neg_284  1
    a_20_12   full_original_Gini_286  -1
    a_20_1    block_pair_pos_279  1
    a_20_1    block_pair_neg_280  1
    a_20_1    full_original_Gini_286  -1
    a_20_10   block_pair_pos_281  1
    a_20_10   block_pair_neg_282  1
    a_20_10   full_original_Gini_286  -1
    a_12_1    block_pair_pos_231  1
    a_12_1    block_pair_neg_232  1
    a_12_1    full_original_Gini_286  -1
    a_12_10   block_pair_pos_233  1
    a_12_10   block_pair_neg_234  1
    a_12_10   full_original_Gini_286  -1
    a_1_10    block_pair_pos_229  1
    a_1_10    block_pair_neg_230  1
    a_1_10    full_original_Gini_286  -1
    MARKER    'MARKER'                 'INTORG'
    service_0_14_0  unique_nonzero_owner_287  1
    service_0_14_0  service_visit_def_886  1
    service_0_14_0  free_load_conservation_887  -11
    service_0_14_0  original_T_including_depot_unload_936  1320
    service_0_14_1  unique_nonzero_owner_288  1
    service_0_14_1  service_visit_def_886  1
    service_0_14_1  free_load_conservation_887  -10
    service_0_14_1  original_T_including_depot_unload_936  1200
    service_0_14_2  unique_nonzero_owner_289  1
    service_0_14_2  service_visit_def_886  1
    service_0_14_2  free_load_conservation_887  -9
    service_0_14_2  original_T_including_depot_unload_936  1080
    service_0_14_3  unique_nonzero_owner_290  1
    service_0_14_3  service_visit_def_886  1
    service_0_14_3  free_load_conservation_887  -8
    service_0_14_3  original_T_including_depot_unload_936  960
    service_0_14_4  unique_nonzero_owner_291  1
    service_0_14_4  service_visit_def_886  1
    service_0_14_4  free_load_conservation_887  -7
    service_0_14_4  original_T_including_depot_unload_936  840
    service_0_14_5  unique_nonzero_owner_292  1
    service_0_14_5  service_visit_def_886  1
    service_0_14_5  free_load_conservation_887  -6
    service_0_14_5  original_T_including_depot_unload_936  720
    service_0_14_6  unique_nonzero_owner_293  1
    service_0_14_6  service_visit_def_886  1
    service_0_14_6  free_load_conservation_887  -5
    service_0_14_6  original_T_including_depot_unload_936  600
    service_0_14_7  unique_nonzero_owner_294  1
    service_0_14_7  service_visit_def_886  1
    service_0_14_7  free_load_conservation_887  -4
    service_0_14_7  original_T_including_depot_unload_936  480
    service_0_14_8  unique_nonzero_owner_295  1
    service_0_14_8  service_visit_def_886  1
    service_0_14_8  free_load_conservation_887  -3
    service_0_14_8  original_T_including_depot_unload_936  360
    service_0_14_9  unique_nonzero_owner_296  1
    service_0_14_9  service_visit_def_886  1
    service_0_14_9  free_load_conservation_887  -2
    service_0_14_9  original_T_including_depot_unload_936  240
    service_0_14_10  unique_nonzero_owner_297  1
    service_0_14_10  service_visit_def_886  1
    service_0_14_10  free_load_conservation_887  -1
    service_0_14_10  original_T_including_depot_unload_936  120
    service_0_14_12  unique_nonzero_owner_298  1
    service_0_14_12  service_visit_def_886  1
    service_0_14_12  free_load_conservation_887  1
    service_0_14_13  unique_nonzero_owner_299  1
    service_0_14_13  service_visit_def_886  1
    service_0_14_13  free_load_conservation_887  2
    service_0_14_14  unique_nonzero_owner_300  1
    service_0_14_14  service_visit_def_886  1
    service_0_14_14  free_load_conservation_887  3
    service_0_14_15  unique_nonzero_owner_301  1
    service_0_14_15  service_visit_def_886  1
    service_0_14_15  free_load_conservation_887  4
    service_1_14_0  unique_nonzero_owner_287  1
    service_1_14_0  service_visit_def_1113  1
    service_1_14_0  free_load_conservation_1114  -11
    service_1_14_0  original_T_including_depot_unload_1157  1320
    service_1_14_1  unique_nonzero_owner_288  1
    service_1_14_1  service_visit_def_1113  1
    service_1_14_1  free_load_conservation_1114  -10
    service_1_14_1  original_T_including_depot_unload_1157  1200
    service_1_14_2  unique_nonzero_owner_289  1
    service_1_14_2  service_visit_def_1113  1
    service_1_14_2  free_load_conservation_1114  -9
    service_1_14_2  original_T_including_depot_unload_1157  1080
    service_1_14_3  unique_nonzero_owner_290  1
    service_1_14_3  service_visit_def_1113  1
    service_1_14_3  free_load_conservation_1114  -8
    service_1_14_3  original_T_including_depot_unload_1157  960
    service_1_14_4  unique_nonzero_owner_291  1
    service_1_14_4  service_visit_def_1113  1
    service_1_14_4  free_load_conservation_1114  -7
    service_1_14_4  original_T_including_depot_unload_1157  840
    service_1_14_5  unique_nonzero_owner_292  1
    service_1_14_5  service_visit_def_1113  1
    service_1_14_5  free_load_conservation_1114  -6
    service_1_14_5  original_T_including_depot_unload_1157  720
    service_1_14_6  unique_nonzero_owner_293  1
    service_1_14_6  service_visit_def_1113  1
    service_1_14_6  free_load_conservation_1114  -5
    service_1_14_6  original_T_including_depot_unload_1157  600
    service_1_14_7  unique_nonzero_owner_294  1
    service_1_14_7  service_visit_def_1113  1
    service_1_14_7  free_load_conservation_1114  -4
    service_1_14_7  original_T_including_depot_unload_1157  480
    service_1_14_8  unique_nonzero_owner_295  1
    service_1_14_8  service_visit_def_1113  1
    service_1_14_8  free_load_conservation_1114  -3
    service_1_14_8  original_T_including_depot_unload_1157  360
    service_1_14_9  unique_nonzero_owner_296  1
    service_1_14_9  service_visit_def_1113  1
    service_1_14_9  free_load_conservation_1114  -2
    service_1_14_9  original_T_including_depot_unload_1157  240
    service_1_14_10  unique_nonzero_owner_297  1
    service_1_14_10  service_visit_def_1113  1
    service_1_14_10  free_load_conservation_1114  -1
    service_1_14_10  original_T_including_depot_unload_1157  120
    service_1_14_12  unique_nonzero_owner_298  1
    service_1_14_12  service_visit_def_1113  1
    service_1_14_12  free_load_conservation_1114  1
    service_1_14_13  unique_nonzero_owner_299  1
    service_1_14_13  service_visit_def_1113  1
    service_1_14_13  free_load_conservation_1114  2
    service_1_14_14  unique_nonzero_owner_300  1
    service_1_14_14  service_visit_def_1113  1
    service_1_14_14  free_load_conservation_1114  3
    service_1_14_15  unique_nonzero_owner_301  1
    service_1_14_15  service_visit_def_1113  1
    service_1_14_15  free_load_conservation_1114  4
    service_0_13_1  unique_nonzero_owner_302  1
    service_0_13_1  service_visit_def_892  1
    service_0_13_1  free_load_conservation_893  1
    service_1_13_1  unique_nonzero_owner_302  1
    service_1_13_1  service_visit_def_1119  1
    service_1_13_1  free_load_conservation_1120  1
    service_0_18_1  unique_nonzero_owner_303  1
    service_0_18_1  service_visit_def_898  1
    service_0_18_1  free_load_conservation_899  1
    service_0_18_2  unique_nonzero_owner_304  1
    service_0_18_2  service_visit_def_898  1
    service_0_18_2  free_load_conservation_899  2
    service_0_18_3  unique_nonzero_owner_305  1
    service_0_18_3  service_visit_def_898  1
    service_0_18_3  free_load_conservation_899  3
    service_0_18_4  unique_nonzero_owner_306  1
    service_0_18_4  service_visit_def_898  1
    service_0_18_4  free_load_conservation_899  4
    service_0_18_5  unique_nonzero_owner_307  1
    service_0_18_5  service_visit_def_898  1
    service_0_18_5  free_load_conservation_899  5
    service_0_18_6  unique_nonzero_owner_308  1
    service_0_18_6  service_visit_def_898  1
    service_0_18_6  free_load_conservation_899  6
    service_0_18_7  unique_nonzero_owner_309  1
    service_0_18_7  service_visit_def_898  1
    service_0_18_7  free_load_conservation_899  7
    service_0_18_8  unique_nonzero_owner_310  1
    service_0_18_8  service_visit_def_898  1
    service_0_18_8  free_load_conservation_899  8
    service_0_18_9  unique_nonzero_owner_311  1
    service_0_18_9  service_visit_def_898  1
    service_0_18_9  free_load_conservation_899  9
    service_0_18_10  unique_nonzero_owner_312  1
    service_0_18_10  service_visit_def_898  1
    service_0_18_10  free_load_conservation_899  10
    service_0_18_11  unique_nonzero_owner_313  1
    service_0_18_11  service_visit_def_898  1
    service_0_18_11  free_load_conservation_899  11
    service_0_18_12  unique_nonzero_owner_314  1
    service_0_18_12  service_visit_def_898  1
    service_0_18_12  free_load_conservation_899  12
    service_0_18_13  unique_nonzero_owner_315  1
    service_0_18_13  service_visit_def_898  1
    service_0_18_13  free_load_conservation_899  13
    service_0_18_14  unique_nonzero_owner_316  1
    service_0_18_14  service_visit_def_898  1
    service_0_18_14  free_load_conservation_899  14
    service_0_18_15  unique_nonzero_owner_317  1
    service_0_18_15  service_visit_def_898  1
    service_0_18_15  free_load_conservation_899  15
    service_1_18_1  unique_nonzero_owner_303  1
    service_1_18_1  service_visit_def_1125  1
    service_1_18_1  free_load_conservation_1126  1
    service_1_18_2  unique_nonzero_owner_304  1
    service_1_18_2  service_visit_def_1125  1
    service_1_18_2  free_load_conservation_1126  2
    service_1_18_3  unique_nonzero_owner_305  1
    service_1_18_3  service_visit_def_1125  1
    service_1_18_3  free_load_conservation_1126  3
    service_1_18_4  unique_nonzero_owner_306  1
    service_1_18_4  service_visit_def_1125  1
    service_1_18_4  free_load_conservation_1126  4
    service_1_18_5  unique_nonzero_owner_307  1
    service_1_18_5  service_visit_def_1125  1
    service_1_18_5  free_load_conservation_1126  5
    service_1_18_6  unique_nonzero_owner_308  1
    service_1_18_6  service_visit_def_1125  1
    service_1_18_6  free_load_conservation_1126  6
    service_1_18_7  unique_nonzero_owner_309  1
    service_1_18_7  service_visit_def_1125  1
    service_1_18_7  free_load_conservation_1126  7
    service_1_18_8  unique_nonzero_owner_310  1
    service_1_18_8  service_visit_def_1125  1
    service_1_18_8  free_load_conservation_1126  8
    service_1_18_9  unique_nonzero_owner_311  1
    service_1_18_9  service_visit_def_1125  1
    service_1_18_9  free_load_conservation_1126  9
    service_1_18_10  unique_nonzero_owner_312  1
    service_1_18_10  service_visit_def_1125  1
    service_1_18_10  free_load_conservation_1126  10
    service_1_18_11  unique_nonzero_owner_313  1
    service_1_18_11  service_visit_def_1125  1
    service_1_18_11  free_load_conservation_1126  11
    service_1_18_12  unique_nonzero_owner_314  1
    service_1_18_12  service_visit_def_1125  1
    service_1_18_12  free_load_conservation_1126  12
    service_1_18_13  unique_nonzero_owner_315  1
    service_1_18_13  service_visit_def_1125  1
    service_1_18_13  free_load_conservation_1126  13
    service_1_18_14  unique_nonzero_owner_316  1
    service_1_18_14  service_visit_def_1125  1
    service_1_18_14  free_load_conservation_1126  14
    service_1_18_15  unique_nonzero_owner_317  1
    service_1_18_15  service_visit_def_1125  1
    service_1_18_15  free_load_conservation_1126  15
    service_0_17_0  unique_nonzero_owner_318  1
    service_0_17_0  service_visit_def_904  1
    service_0_17_0  free_load_conservation_905  -3
    service_0_17_0  original_T_including_depot_unload_936  360
    service_0_17_1  unique_nonzero_owner_319  1
    service_0_17_1  service_visit_def_904  1
    service_0_17_1  free_load_conservation_905  -2
    service_0_17_1  original_T_including_depot_unload_936  240
    service_0_17_2  unique_nonzero_owner_320  1
    service_0_17_2  service_visit_def_904  1
    service_0_17_2  free_load_conservation_905  -1
    service_0_17_2  original_T_including_depot_unload_936  120
    service_0_17_4  unique_nonzero_owner_321  1
    service_0_17_4  service_visit_def_904  1
    service_0_17_4  free_load_conservation_905  1
    service_0_17_5  unique_nonzero_owner_322  1
    service_0_17_5  service_visit_def_904  1
    service_0_17_5  free_load_conservation_905  2
    service_0_17_6  unique_nonzero_owner_323  1
    service_0_17_6  service_visit_def_904  1
    service_0_17_6  free_load_conservation_905  3
    service_0_17_7  unique_nonzero_owner_324  1
    service_0_17_7  service_visit_def_904  1
    service_0_17_7  free_load_conservation_905  4
    service_0_17_8  unique_nonzero_owner_325  1
    service_0_17_8  service_visit_def_904  1
    service_0_17_8  free_load_conservation_905  5
    service_0_17_9  unique_nonzero_owner_326  1
    service_0_17_9  service_visit_def_904  1
    service_0_17_9  free_load_conservation_905  6
    service_0_17_10  unique_nonzero_owner_327  1
    service_0_17_10  service_visit_def_904  1
    service_0_17_10  free_load_conservation_905  7
    service_0_17_11  unique_nonzero_owner_328  1
    service_0_17_11  service_visit_def_904  1
    service_0_17_11  free_load_conservation_905  8
    service_0_17_12  unique_nonzero_owner_329  1
    service_0_17_12  service_visit_def_904  1
    service_0_17_12  free_load_conservation_905  9
    service_0_17_13  unique_nonzero_owner_330  1
    service_0_17_13  service_visit_def_904  1
    service_0_17_13  free_load_conservation_905  10
    service_0_17_14  unique_nonzero_owner_331  1
    service_0_17_14  service_visit_def_904  1
    service_0_17_14  free_load_conservation_905  11
    service_0_17_15  unique_nonzero_owner_332  1
    service_0_17_15  service_visit_def_904  1
    service_0_17_15  free_load_conservation_905  12
    service_0_17_16  unique_nonzero_owner_333  1
    service_0_17_16  service_visit_def_904  1
    service_0_17_16  free_load_conservation_905  13
    service_1_17_0  unique_nonzero_owner_318  1
    service_1_17_0  service_visit_def_1131  1
    service_1_17_0  free_load_conservation_1132  -3
    service_1_17_0  original_T_including_depot_unload_1157  360
    service_1_17_1  unique_nonzero_owner_319  1
    service_1_17_1  service_visit_def_1131  1
    service_1_17_1  free_load_conservation_1132  -2
    service_1_17_1  original_T_including_depot_unload_1157  240
    service_1_17_2  unique_nonzero_owner_320  1
    service_1_17_2  service_visit_def_1131  1
    service_1_17_2  free_load_conservation_1132  -1
    service_1_17_2  original_T_including_depot_unload_1157  120
    service_1_17_4  unique_nonzero_owner_321  1
    service_1_17_4  service_visit_def_1131  1
    service_1_17_4  free_load_conservation_1132  1
    service_1_17_5  unique_nonzero_owner_322  1
    service_1_17_5  service_visit_def_1131  1
    service_1_17_5  free_load_conservation_1132  2
    service_1_17_6  unique_nonzero_owner_323  1
    service_1_17_6  service_visit_def_1131  1
    service_1_17_6  free_load_conservation_1132  3
    service_1_17_7  unique_nonzero_owner_324  1
    service_1_17_7  service_visit_def_1131  1
    service_1_17_7  free_load_conservation_1132  4
    service_1_17_8  unique_nonzero_owner_325  1
    service_1_17_8  service_visit_def_1131  1
    service_1_17_8  free_load_conservation_1132  5
    service_1_17_9  unique_nonzero_owner_326  1
    service_1_17_9  service_visit_def_1131  1
    service_1_17_9  free_load_conservation_1132  6
    service_1_17_10  unique_nonzero_owner_327  1
    service_1_17_10  service_visit_def_1131  1
    service_1_17_10  free_load_conservation_1132  7
    service_1_17_11  unique_nonzero_owner_328  1
    service_1_17_11  service_visit_def_1131  1
    service_1_17_11  free_load_conservation_1132  8
    service_1_17_12  unique_nonzero_owner_329  1
    service_1_17_12  service_visit_def_1131  1
    service_1_17_12  free_load_conservation_1132  9
    service_1_17_13  unique_nonzero_owner_330  1
    service_1_17_13  service_visit_def_1131  1
    service_1_17_13  free_load_conservation_1132  10
    service_1_17_14  unique_nonzero_owner_331  1
    service_1_17_14  service_visit_def_1131  1
    service_1_17_14  free_load_conservation_1132  11
    service_1_17_15  unique_nonzero_owner_332  1
    service_1_17_15  service_visit_def_1131  1
    service_1_17_15  free_load_conservation_1132  12
    service_1_17_16  unique_nonzero_owner_333  1
    service_1_17_16  service_visit_def_1131  1
    service_1_17_16  free_load_conservation_1132  13
    service_0_20_0  unique_nonzero_owner_334  1
    service_0_20_0  service_visit_def_910  1
    service_0_20_0  free_load_conservation_911  -12
    service_0_20_0  original_T_including_depot_unload_936  1440
    service_0_20_1  unique_nonzero_owner_335  1
    service_0_20_1  service_visit_def_910  1
    service_0_20_1  free_load_conservation_911  -11
    service_0_20_1  original_T_including_depot_unload_936  1320
    service_0_20_2  unique_nonzero_owner_336  1
    service_0_20_2  service_visit_def_910  1
    service_0_20_2  free_load_conservation_911  -10
    service_0_20_2  original_T_including_depot_unload_936  1200
    service_0_20_3  unique_nonzero_owner_337  1
    service_0_20_3  service_visit_def_910  1
    service_0_20_3  free_load_conservation_911  -9
    service_0_20_3  original_T_including_depot_unload_936  1080
    service_0_20_4  unique_nonzero_owner_338  1
    service_0_20_4  service_visit_def_910  1
    service_0_20_4  free_load_conservation_911  -8
    service_0_20_4  original_T_including_depot_unload_936  960
    service_0_20_5  unique_nonzero_owner_339  1
    service_0_20_5  service_visit_def_910  1
    service_0_20_5  free_load_conservation_911  -7
    service_0_20_5  original_T_including_depot_unload_936  840
    service_0_20_6  unique_nonzero_owner_340  1
    service_0_20_6  service_visit_def_910  1
    service_0_20_6  free_load_conservation_911  -6
    service_0_20_6  original_T_including_depot_unload_936  720
    service_0_20_7  unique_nonzero_owner_341  1
    service_0_20_7  service_visit_def_910  1
    service_0_20_7  free_load_conservation_911  -5
    service_0_20_7  original_T_including_depot_unload_936  600
    service_0_20_8  unique_nonzero_owner_342  1
    service_0_20_8  service_visit_def_910  1
    service_0_20_8  free_load_conservation_911  -4
    service_0_20_8  original_T_including_depot_unload_936  480
    service_0_20_9  unique_nonzero_owner_343  1
    service_0_20_9  service_visit_def_910  1
    service_0_20_9  free_load_conservation_911  -3
    service_0_20_9  original_T_including_depot_unload_936  360
    service_0_20_10  unique_nonzero_owner_344  1
    service_0_20_10  service_visit_def_910  1
    service_0_20_10  free_load_conservation_911  -2
    service_0_20_10  original_T_including_depot_unload_936  240
    service_0_20_11  unique_nonzero_owner_345  1
    service_0_20_11  service_visit_def_910  1
    service_0_20_11  free_load_conservation_911  -1
    service_0_20_11  original_T_including_depot_unload_936  120
    service_0_20_13  unique_nonzero_owner_346  1
    service_0_20_13  service_visit_def_910  1
    service_0_20_13  free_load_conservation_911  1
    service_0_20_14  unique_nonzero_owner_347  1
    service_0_20_14  service_visit_def_910  1
    service_0_20_14  free_load_conservation_911  2
    service_0_20_15  unique_nonzero_owner_348  1
    service_0_20_15  service_visit_def_910  1
    service_0_20_15  free_load_conservation_911  3
    service_1_20_0  unique_nonzero_owner_334  1
    service_1_20_0  service_visit_def_1137  1
    service_1_20_0  free_load_conservation_1138  -12
    service_1_20_0  original_T_including_depot_unload_1157  1440
    service_1_20_1  unique_nonzero_owner_335  1
    service_1_20_1  service_visit_def_1137  1
    service_1_20_1  free_load_conservation_1138  -11
    service_1_20_1  original_T_including_depot_unload_1157  1320
    service_1_20_2  unique_nonzero_owner_336  1
    service_1_20_2  service_visit_def_1137  1
    service_1_20_2  free_load_conservation_1138  -10
    service_1_20_2  original_T_including_depot_unload_1157  1200
    service_1_20_3  unique_nonzero_owner_337  1
    service_1_20_3  service_visit_def_1137  1
    service_1_20_3  free_load_conservation_1138  -9
    service_1_20_3  original_T_including_depot_unload_1157  1080
    service_1_20_4  unique_nonzero_owner_338  1
    service_1_20_4  service_visit_def_1137  1
    service_1_20_4  free_load_conservation_1138  -8
    service_1_20_4  original_T_including_depot_unload_1157  960
    service_1_20_5  unique_nonzero_owner_339  1
    service_1_20_5  service_visit_def_1137  1
    service_1_20_5  free_load_conservation_1138  -7
    service_1_20_5  original_T_including_depot_unload_1157  840
    service_1_20_6  unique_nonzero_owner_340  1
    service_1_20_6  service_visit_def_1137  1
    service_1_20_6  free_load_conservation_1138  -6
    service_1_20_6  original_T_including_depot_unload_1157  720
    service_1_20_7  unique_nonzero_owner_341  1
    service_1_20_7  service_visit_def_1137  1
    service_1_20_7  free_load_conservation_1138  -5
    service_1_20_7  original_T_including_depot_unload_1157  600
    service_1_20_8  unique_nonzero_owner_342  1
    service_1_20_8  service_visit_def_1137  1
    service_1_20_8  free_load_conservation_1138  -4
    service_1_20_8  original_T_including_depot_unload_1157  480
    service_1_20_9  unique_nonzero_owner_343  1
    service_1_20_9  service_visit_def_1137  1
    service_1_20_9  free_load_conservation_1138  -3
    service_1_20_9  original_T_including_depot_unload_1157  360
    service_1_20_10  unique_nonzero_owner_344  1
    service_1_20_10  service_visit_def_1137  1
    service_1_20_10  free_load_conservation_1138  -2
    service_1_20_10  original_T_including_depot_unload_1157  240
    service_1_20_11  unique_nonzero_owner_345  1
    service_1_20_11  service_visit_def_1137  1
    service_1_20_11  free_load_conservation_1138  -1
    service_1_20_11  original_T_including_depot_unload_1157  120
    service_1_20_13  unique_nonzero_owner_346  1
    service_1_20_13  service_visit_def_1137  1
    service_1_20_13  free_load_conservation_1138  1
    service_1_20_14  unique_nonzero_owner_347  1
    service_1_20_14  service_visit_def_1137  1
    service_1_20_14  free_load_conservation_1138  2
    service_1_20_15  unique_nonzero_owner_348  1
    service_1_20_15  service_visit_def_1137  1
    service_1_20_15  free_load_conservation_1138  3
    service_0_12_0  unique_nonzero_owner_349  1
    service_0_12_0  service_visit_def_916  1
    service_0_12_0  free_load_conservation_917  -11
    service_0_12_0  original_T_including_depot_unload_936  1320
    service_0_12_1  unique_nonzero_owner_350  1
    service_0_12_1  service_visit_def_916  1
    service_0_12_1  free_load_conservation_917  -10
    service_0_12_1  original_T_including_depot_unload_936  1200
    service_0_12_2  unique_nonzero_owner_351  1
    service_0_12_2  service_visit_def_916  1
    service_0_12_2  free_load_conservation_917  -9
    service_0_12_2  original_T_including_depot_unload_936  1080
    service_0_12_3  unique_nonzero_owner_352  1
    service_0_12_3  service_visit_def_916  1
    service_0_12_3  free_load_conservation_917  -8
    service_0_12_3  original_T_including_depot_unload_936  960
    service_0_12_4  unique_nonzero_owner_353  1
    service_0_12_4  service_visit_def_916  1
    service_0_12_4  free_load_conservation_917  -7
    service_0_12_4  original_T_including_depot_unload_936  840
    service_0_12_5  unique_nonzero_owner_354  1
    service_0_12_5  service_visit_def_916  1
    service_0_12_5  free_load_conservation_917  -6
    service_0_12_5  original_T_including_depot_unload_936  720
    service_0_12_6  unique_nonzero_owner_355  1
    service_0_12_6  service_visit_def_916  1
    service_0_12_6  free_load_conservation_917  -5
    service_0_12_6  original_T_including_depot_unload_936  600
    service_0_12_7  unique_nonzero_owner_356  1
    service_0_12_7  service_visit_def_916  1
    service_0_12_7  free_load_conservation_917  -4
    service_0_12_7  original_T_including_depot_unload_936  480
    service_0_12_8  unique_nonzero_owner_357  1
    service_0_12_8  service_visit_def_916  1
    service_0_12_8  free_load_conservation_917  -3
    service_0_12_8  original_T_including_depot_unload_936  360
    service_0_12_9  unique_nonzero_owner_358  1
    service_0_12_9  service_visit_def_916  1
    service_0_12_9  free_load_conservation_917  -2
    service_0_12_9  original_T_including_depot_unload_936  240
    service_0_12_10  unique_nonzero_owner_359  1
    service_0_12_10  service_visit_def_916  1
    service_0_12_10  free_load_conservation_917  -1
    service_0_12_10  original_T_including_depot_unload_936  120
    service_0_12_12  unique_nonzero_owner_360  1
    service_0_12_12  service_visit_def_916  1
    service_0_12_12  free_load_conservation_917  1
    service_0_12_13  unique_nonzero_owner_361  1
    service_0_12_13  service_visit_def_916  1
    service_0_12_13  free_load_conservation_917  2
    service_0_12_14  unique_nonzero_owner_362  1
    service_0_12_14  service_visit_def_916  1
    service_0_12_14  free_load_conservation_917  3
    service_0_12_15  unique_nonzero_owner_363  1
    service_0_12_15  service_visit_def_916  1
    service_0_12_15  free_load_conservation_917  4
    service_1_12_0  unique_nonzero_owner_349  1
    service_1_12_0  service_visit_def_1143  1
    service_1_12_0  free_load_conservation_1144  -11
    service_1_12_0  original_T_including_depot_unload_1157  1320
    service_1_12_1  unique_nonzero_owner_350  1
    service_1_12_1  service_visit_def_1143  1
    service_1_12_1  free_load_conservation_1144  -10
    service_1_12_1  original_T_including_depot_unload_1157  1200
    service_1_12_2  unique_nonzero_owner_351  1
    service_1_12_2  service_visit_def_1143  1
    service_1_12_2  free_load_conservation_1144  -9
    service_1_12_2  original_T_including_depot_unload_1157  1080
    service_1_12_3  unique_nonzero_owner_352  1
    service_1_12_3  service_visit_def_1143  1
    service_1_12_3  free_load_conservation_1144  -8
    service_1_12_3  original_T_including_depot_unload_1157  960
    service_1_12_4  unique_nonzero_owner_353  1
    service_1_12_4  service_visit_def_1143  1
    service_1_12_4  free_load_conservation_1144  -7
    service_1_12_4  original_T_including_depot_unload_1157  840
    service_1_12_5  unique_nonzero_owner_354  1
    service_1_12_5  service_visit_def_1143  1
    service_1_12_5  free_load_conservation_1144  -6
    service_1_12_5  original_T_including_depot_unload_1157  720
    service_1_12_6  unique_nonzero_owner_355  1
    service_1_12_6  service_visit_def_1143  1
    service_1_12_6  free_load_conservation_1144  -5
    service_1_12_6  original_T_including_depot_unload_1157  600
    service_1_12_7  unique_nonzero_owner_356  1
    service_1_12_7  service_visit_def_1143  1
    service_1_12_7  free_load_conservation_1144  -4
    service_1_12_7  original_T_including_depot_unload_1157  480
    service_1_12_8  unique_nonzero_owner_357  1
    service_1_12_8  service_visit_def_1143  1
    service_1_12_8  free_load_conservation_1144  -3
    service_1_12_8  original_T_including_depot_unload_1157  360
    service_1_12_9  unique_nonzero_owner_358  1
    service_1_12_9  service_visit_def_1143  1
    service_1_12_9  free_load_conservation_1144  -2
    service_1_12_9  original_T_including_depot_unload_1157  240
    service_1_12_10  unique_nonzero_owner_359  1
    service_1_12_10  service_visit_def_1143  1
    service_1_12_10  free_load_conservation_1144  -1
    service_1_12_10  original_T_including_depot_unload_1157  120
    service_1_12_12  unique_nonzero_owner_360  1
    service_1_12_12  service_visit_def_1143  1
    service_1_12_12  free_load_conservation_1144  1
    service_1_12_13  unique_nonzero_owner_361  1
    service_1_12_13  service_visit_def_1143  1
    service_1_12_13  free_load_conservation_1144  2
    service_1_12_14  unique_nonzero_owner_362  1
    service_1_12_14  service_visit_def_1143  1
    service_1_12_14  free_load_conservation_1144  3
    service_1_12_15  unique_nonzero_owner_363  1
    service_1_12_15  service_visit_def_1143  1
    service_1_12_15  free_load_conservation_1144  4
    service_0_1_0  unique_nonzero_owner_364  1
    service_0_1_0  service_visit_def_922  1
    service_0_1_0  free_load_conservation_923  -1
    service_0_1_0  original_T_including_depot_unload_936  120
    service_0_1_2  unique_nonzero_owner_365  1
    service_0_1_2  service_visit_def_922  1
    service_0_1_2  free_load_conservation_923  1
    service_0_1_3  unique_nonzero_owner_366  1
    service_0_1_3  service_visit_def_922  1
    service_0_1_3  free_load_conservation_923  2
    service_0_1_4  unique_nonzero_owner_367  1
    service_0_1_4  service_visit_def_922  1
    service_0_1_4  free_load_conservation_923  3
    service_0_1_5  unique_nonzero_owner_368  1
    service_0_1_5  service_visit_def_922  1
    service_0_1_5  free_load_conservation_923  4
    service_0_1_6  unique_nonzero_owner_369  1
    service_0_1_6  service_visit_def_922  1
    service_0_1_6  free_load_conservation_923  5
    service_0_1_7  unique_nonzero_owner_370  1
    service_0_1_7  service_visit_def_922  1
    service_0_1_7  free_load_conservation_923  6
    service_0_1_8  unique_nonzero_owner_371  1
    service_0_1_8  service_visit_def_922  1
    service_0_1_8  free_load_conservation_923  7
    service_0_1_9  unique_nonzero_owner_372  1
    service_0_1_9  service_visit_def_922  1
    service_0_1_9  free_load_conservation_923  8
    service_0_1_10  unique_nonzero_owner_373  1
    service_0_1_10  service_visit_def_922  1
    service_0_1_10  free_load_conservation_923  9
    service_0_1_11  unique_nonzero_owner_374  1
    service_0_1_11  service_visit_def_922  1
    service_0_1_11  free_load_conservation_923  10
    service_0_1_12  unique_nonzero_owner_375  1
    service_0_1_12  service_visit_def_922  1
    service_0_1_12  free_load_conservation_923  11
    service_0_1_13  unique_nonzero_owner_376  1
    service_0_1_13  service_visit_def_922  1
    service_0_1_13  free_load_conservation_923  12
    service_0_1_14  unique_nonzero_owner_377  1
    service_0_1_14  service_visit_def_922  1
    service_0_1_14  free_load_conservation_923  13
    service_0_1_15  unique_nonzero_owner_378  1
    service_0_1_15  service_visit_def_922  1
    service_0_1_15  free_load_conservation_923  14
    service_1_1_0  unique_nonzero_owner_364  1
    service_1_1_0  service_visit_def_1149  1
    service_1_1_0  free_load_conservation_1150  -1
    service_1_1_0  original_T_including_depot_unload_1157  120
    service_1_1_2  unique_nonzero_owner_365  1
    service_1_1_2  service_visit_def_1149  1
    service_1_1_2  free_load_conservation_1150  1
    service_1_1_3  unique_nonzero_owner_366  1
    service_1_1_3  service_visit_def_1149  1
    service_1_1_3  free_load_conservation_1150  2
    service_1_1_4  unique_nonzero_owner_367  1
    service_1_1_4  service_visit_def_1149  1
    service_1_1_4  free_load_conservation_1150  3
    service_1_1_5  unique_nonzero_owner_368  1
    service_1_1_5  service_visit_def_1149  1
    service_1_1_5  free_load_conservation_1150  4
    service_1_1_6  unique_nonzero_owner_369  1
    service_1_1_6  service_visit_def_1149  1
    service_1_1_6  free_load_conservation_1150  5
    service_1_1_7  unique_nonzero_owner_370  1
    service_1_1_7  service_visit_def_1149  1
    service_1_1_7  free_load_conservation_1150  6
    service_1_1_8  unique_nonzero_owner_371  1
    service_1_1_8  service_visit_def_1149  1
    service_1_1_8  free_load_conservation_1150  7
    service_1_1_9  unique_nonzero_owner_372  1
    service_1_1_9  service_visit_def_1149  1
    service_1_1_9  free_load_conservation_1150  8
    service_1_1_10  unique_nonzero_owner_373  1
    service_1_1_10  service_visit_def_1149  1
    service_1_1_10  free_load_conservation_1150  9
    service_1_1_11  unique_nonzero_owner_374  1
    service_1_1_11  service_visit_def_1149  1
    service_1_1_11  free_load_conservation_1150  10
    service_1_1_12  unique_nonzero_owner_375  1
    service_1_1_12  service_visit_def_1149  1
    service_1_1_12  free_load_conservation_1150  11
    service_1_1_13  unique_nonzero_owner_376  1
    service_1_1_13  service_visit_def_1149  1
    service_1_1_13  free_load_conservation_1150  12
    service_1_1_14  unique_nonzero_owner_377  1
    service_1_1_14  service_visit_def_1149  1
    service_1_1_14  free_load_conservation_1150  13
    service_1_1_15  unique_nonzero_owner_378  1
    service_1_1_15  service_visit_def_1149  1
    service_1_1_15  free_load_conservation_1150  14
    service_0_10_1  unique_nonzero_owner_379  1
    service_0_10_1  service_visit_def_928  1
    service_0_10_1  free_load_conservation_929  1
    service_1_10_1  unique_nonzero_owner_379  1
    service_1_10_1  service_visit_def_1155  1
    service_1_10_1  free_load_conservation_1156  1
    MARKER    'MARKER'                 'INTEND'
    visit_0_1  out_degree_833  -1
    visit_0_1  in_degree_834  -1
    visit_0_1  order_active_lb_835  -1
    visit_0_1  order_active_ub_836  -15
    order_0_1  connected_order_arc_398  -1
    order_0_1  connected_order_arc_400  -1
    order_0_1  connected_order_arc_402  -1
    order_0_1  connected_order_arc_404  -1
    order_0_1  connected_order_arc_406  -1
    order_0_1  connected_order_arc_408  -1
    order_0_1  connected_order_arc_410  -1
    order_0_1  connected_order_arc_412  -1
    order_0_1  connected_order_arc_414  -1
    order_0_1  connected_order_arc_416  -1
    order_0_1  connected_order_arc_418  -1
    order_0_1  connected_order_arc_420  -1
    order_0_1  connected_order_arc_422  -1
    order_0_1  connected_order_arc_424  -1
    order_0_1  connected_order_arc_427  1
    order_0_1  connected_order_arc_456  1
    order_0_1  connected_order_arc_485  1
    order_0_1  connected_order_arc_514  1
    order_0_1  connected_order_arc_543  1
    order_0_1  connected_order_arc_572  1
    order_0_1  connected_order_arc_601  1
    order_0_1  connected_order_arc_630  1
    order_0_1  connected_order_arc_659  1
    order_0_1  connected_order_arc_688  1
    order_0_1  connected_order_arc_717  1
    order_0_1  connected_order_arc_746  1
    order_0_1  connected_order_arc_775  1
    order_0_1  connected_order_arc_804  1
    order_0_1  order_active_lb_835  1
    order_0_1  order_active_ub_836  1
    order_0_1  fixed_segment_relative_order_930  -1
    visit_0_2  out_degree_840  -1
    visit_0_2  in_degree_841  -1
    visit_0_2  order_active_lb_842  -1
    visit_0_2  order_active_ub_843  -15
    order_0_2  connected_order_arc_398  1
    order_0_2  connected_order_arc_427  -1
    order_0_2  connected_order_arc_429  -1
    order_0_2  connected_order_arc_431  -1
    order_0_2  connected_order_arc_433  -1
    order_0_2  connected_order_arc_435  -1
    order_0_2  connected_order_arc_437  -1
    order_0_2  connected_order_arc_439  -1
    order_0_2  connected_order_arc_441  -1
    order_0_2  connected_order_arc_443  -1
    order_0_2  connected_order_arc_445  -1
    order_0_2  connected_order_arc_447  -1
    order_0_2  connected_order_arc_449  -1
    order_0_2  connected_order_arc_451  -1
    order_0_2  connected_order_arc_453  -1
    order_0_2  connected_order_arc_458  1
    order_0_2  connected_order_arc_487  1
    order_0_2  connected_order_arc_516  1
    order_0_2  connected_order_arc_545  1
    order_0_2  connected_order_arc_574  1
    order_0_2  connected_order_arc_603  1
    order_0_2  connected_order_arc_632  1
    order_0_2  connected_order_arc_661  1
    order_0_2  connected_order_arc_690  1
    order_0_2  connected_order_arc_719  1
    order_0_2  connected_order_arc_748  1
    order_0_2  connected_order_arc_777  1
    order_0_2  connected_order_arc_806  1
    order_0_2  order_active_lb_842  1
    order_0_2  order_active_ub_843  1
    order_0_2  fixed_segment_relative_order_930  1
    order_0_2  fixed_segment_relative_order_931  -1
    visit_0_3  out_degree_847  -1
    visit_0_3  in_degree_848  -1
    visit_0_3  order_active_lb_849  -1
    visit_0_3  order_active_ub_850  -15
    order_0_3  connected_order_arc_400  1
    order_0_3  connected_order_arc_429  1
    order_0_3  connected_order_arc_456  -1
    order_0_3  connected_order_arc_458  -1
    order_0_3  connected_order_arc_460  -1
    order_0_3  connected_order_arc_462  -1
    order_0_3  connected_order_arc_464  -1
    order_0_3  connected_order_arc_466  -1
    order_0_3  connected_order_arc_468  -1
    order_0_3  connected_order_arc_470  -1
    order_0_3  connected_order_arc_472  -1
    order_0_3  connected_order_arc_474  -1
    order_0_3  connected_order_arc_476  -1
    order_0_3  connected_order_arc_478  -1
    order_0_3  connected_order_arc_480  -1
    order_0_3  connected_order_arc_482  -1
    order_0_3  connected_order_arc_489  1
    order_0_3  connected_order_arc_518  1
    order_0_3  connected_order_arc_547  1
    order_0_3  connected_order_arc_576  1
    order_0_3  connected_order_arc_605  1
    order_0_3  connected_order_arc_634  1
    order_0_3  connected_order_arc_663  1
    order_0_3  connected_order_arc_692  1
    order_0_3  connected_order_arc_721  1
    order_0_3  connected_order_arc_750  1
    order_0_3  connected_order_arc_779  1
    order_0_3  connected_order_arc_808  1
    order_0_3  order_active_lb_849  1
    order_0_3  order_active_ub_850  1
    order_0_3  fixed_segment_relative_order_931  1
    order_0_3  fixed_segment_relative_order_932  -1
    visit_0_4  out_degree_854  -1
    visit_0_4  in_degree_855  -1
    visit_0_4  order_active_lb_856  -1
    visit_0_4  order_active_ub_857  -15
    order_0_4  connected_order_arc_402  1
    order_0_4  connected_order_arc_431  1
    order_0_4  connected_order_arc_460  1
    order_0_4  connected_order_arc_485  -1
    order_0_4  connected_order_arc_487  -1
    order_0_4  connected_order_arc_489  -1
    order_0_4  connected_order_arc_491  -1
    order_0_4  connected_order_arc_493  -1
    order_0_4  connected_order_arc_495  -1
    order_0_4  connected_order_arc_497  -1
    order_0_4  connected_order_arc_499  -1
    order_0_4  connected_order_arc_501  -1
    order_0_4  connected_order_arc_503  -1
    order_0_4  connected_order_arc_505  -1
    order_0_4  connected_order_arc_507  -1
    order_0_4  connected_order_arc_509  -1
    order_0_4  connected_order_arc_511  -1
    order_0_4  connected_order_arc_520  1
    order_0_4  connected_order_arc_549  1
    order_0_4  connected_order_arc_578  1
    order_0_4  connected_order_arc_607  1
    order_0_4  connected_order_arc_636  1
    order_0_4  connected_order_arc_665  1
    order_0_4  connected_order_arc_694  1
    order_0_4  connected_order_arc_723  1
    order_0_4  connected_order_arc_752  1
    order_0_4  connected_order_arc_781  1
    order_0_4  connected_order_arc_810  1
    order_0_4  order_active_lb_856  1
    order_0_4  order_active_ub_857  1
    order_0_4  fixed_segment_relative_order_932  1
    order_0_4  fixed_segment_relative_order_933  -1
    visit_0_5  out_degree_861  -1
    visit_0_5  in_degree_862  -1
    visit_0_5  order_active_lb_863  -1
    visit_0_5  order_active_ub_864  -15
    order_0_5  connected_order_arc_404  1
    order_0_5  connected_order_arc_433  1
    order_0_5  connected_order_arc_462  1
    order_0_5  connected_order_arc_491  1
    order_0_5  connected_order_arc_514  -1
    order_0_5  connected_order_arc_516  -1
    order_0_5  connected_order_arc_518  -1
    order_0_5  connected_order_arc_520  -1
    order_0_5  connected_order_arc_522  -1
    order_0_5  connected_order_arc_524  -1
    order_0_5  connected_order_arc_526  -1
    order_0_5  connected_order_arc_528  -1
    order_0_5  connected_order_arc_530  -1
    order_0_5  connected_order_arc_532  -1
    order_0_5  connected_order_arc_534  -1
    order_0_5  connected_order_arc_536  -1
    order_0_5  connected_order_arc_538  -1
    order_0_5  connected_order_arc_540  -1
    order_0_5  connected_order_arc_551  1
    order_0_5  connected_order_arc_580  1
    order_0_5  connected_order_arc_609  1
    order_0_5  connected_order_arc_638  1
    order_0_5  connected_order_arc_667  1
    order_0_5  connected_order_arc_696  1
    order_0_5  connected_order_arc_725  1
    order_0_5  connected_order_arc_754  1
    order_0_5  connected_order_arc_783  1
    order_0_5  connected_order_arc_812  1
    order_0_5  order_active_lb_863  1
    order_0_5  order_active_ub_864  1
    order_0_5  fixed_segment_relative_order_933  1
    order_0_5  fixed_segment_relative_order_934  -1
    visit_0_6  out_degree_868  -1
    visit_0_6  in_degree_869  -1
    visit_0_6  order_active_lb_870  -1
    visit_0_6  order_active_ub_871  -15
    order_0_6  connected_order_arc_406  1
    order_0_6  connected_order_arc_435  1
    order_0_6  connected_order_arc_464  1
    order_0_6  connected_order_arc_493  1
    order_0_6  connected_order_arc_522  1
    order_0_6  connected_order_arc_543  -1
    order_0_6  connected_order_arc_545  -1
    order_0_6  connected_order_arc_547  -1
    order_0_6  connected_order_arc_549  -1
    order_0_6  connected_order_arc_551  -1
    order_0_6  connected_order_arc_553  -1
    order_0_6  connected_order_arc_555  -1
    order_0_6  connected_order_arc_557  -1
    order_0_6  connected_order_arc_559  -1
    order_0_6  connected_order_arc_561  -1
    order_0_6  connected_order_arc_563  -1
    order_0_6  connected_order_arc_565  -1
    order_0_6  connected_order_arc_567  -1
    order_0_6  connected_order_arc_569  -1
    order_0_6  connected_order_arc_582  1
    order_0_6  connected_order_arc_611  1
    order_0_6  connected_order_arc_640  1
    order_0_6  connected_order_arc_669  1
    order_0_6  connected_order_arc_698  1
    order_0_6  connected_order_arc_727  1
    order_0_6  connected_order_arc_756  1
    order_0_6  connected_order_arc_785  1
    order_0_6  connected_order_arc_814  1
    order_0_6  order_active_lb_870  1
    order_0_6  order_active_ub_871  1
    order_0_6  fixed_segment_relative_order_934  1
    order_0_6  fixed_segment_relative_order_935  -1
    visit_0_7  out_degree_875  -1
    visit_0_7  in_degree_876  -1
    visit_0_7  order_active_lb_877  -1
    visit_0_7  order_active_ub_878  -15
    order_0_7  connected_order_arc_408  1
    order_0_7  connected_order_arc_437  1
    order_0_7  connected_order_arc_466  1
    order_0_7  connected_order_arc_495  1
    order_0_7  connected_order_arc_524  1
    order_0_7  connected_order_arc_553  1
    order_0_7  connected_order_arc_572  -1
    order_0_7  connected_order_arc_574  -1
    order_0_7  connected_order_arc_576  -1
    order_0_7  connected_order_arc_578  -1
    order_0_7  connected_order_arc_580  -1
    order_0_7  connected_order_arc_582  -1
    order_0_7  connected_order_arc_584  -1
    order_0_7  connected_order_arc_586  -1
    order_0_7  connected_order_arc_588  -1
    order_0_7  connected_order_arc_590  -1
    order_0_7  connected_order_arc_592  -1
    order_0_7  connected_order_arc_594  -1
    order_0_7  connected_order_arc_596  -1
    order_0_7  connected_order_arc_598  -1
    order_0_7  connected_order_arc_613  1
    order_0_7  connected_order_arc_642  1
    order_0_7  connected_order_arc_671  1
    order_0_7  connected_order_arc_700  1
    order_0_7  connected_order_arc_729  1
    order_0_7  connected_order_arc_758  1
    order_0_7  connected_order_arc_787  1
    order_0_7  connected_order_arc_816  1
    order_0_7  order_active_lb_877  1
    order_0_7  order_active_ub_878  1
    order_0_7  fixed_segment_relative_order_935  1
    visit_0_9  out_degree_882  -1
    visit_0_9  in_degree_883  -1
    visit_0_9  order_active_lb_884  -1
    visit_0_9  order_active_ub_885  -15
    visit_0_9  service_visit_def_886  -1
    order_0_9  connected_order_arc_410  1
    order_0_9  connected_order_arc_439  1
    order_0_9  connected_order_arc_468  1
    order_0_9  connected_order_arc_497  1
    order_0_9  connected_order_arc_526  1
    order_0_9  connected_order_arc_555  1
    order_0_9  connected_order_arc_584  1
    order_0_9  connected_order_arc_601  -1
    order_0_9  connected_order_arc_603  -1
    order_0_9  connected_order_arc_605  -1
    order_0_9  connected_order_arc_607  -1
    order_0_9  connected_order_arc_609  -1
    order_0_9  connected_order_arc_611  -1
    order_0_9  connected_order_arc_613  -1
    order_0_9  connected_order_arc_615  -1
    order_0_9  connected_order_arc_617  -1
    order_0_9  connected_order_arc_619  -1
    order_0_9  connected_order_arc_621  -1
    order_0_9  connected_order_arc_623  -1
    order_0_9  connected_order_arc_625  -1
    order_0_9  connected_order_arc_627  -1
    order_0_9  connected_order_arc_644  1
    order_0_9  connected_order_arc_673  1
    order_0_9  connected_order_arc_702  1
    order_0_9  connected_order_arc_731  1
    order_0_9  connected_order_arc_760  1
    order_0_9  connected_order_arc_789  1
    order_0_9  connected_order_arc_818  1
    order_0_9  order_active_lb_884  1
    order_0_9  order_active_ub_885  1
    visit_0_10  out_degree_888  -1
    visit_0_10  in_degree_889  -1
    visit_0_10  order_active_lb_890  -1
    visit_0_10  order_active_ub_891  -15
    visit_0_10  service_visit_def_892  -1
    order_0_10  connected_order_arc_412  1
    order_0_10  connected_order_arc_441  1
    order_0_10  connected_order_arc_470  1
    order_0_10  connected_order_arc_499  1
    order_0_10  connected_order_arc_528  1
    order_0_10  connected_order_arc_557  1
    order_0_10  connected_order_arc_586  1
    order_0_10  connected_order_arc_615  1
    order_0_10  connected_order_arc_630  -1
    order_0_10  connected_order_arc_632  -1
    order_0_10  connected_order_arc_634  -1
    order_0_10  connected_order_arc_636  -1
    order_0_10  connected_order_arc_638  -1
    order_0_10  connected_order_arc_640  -1
    order_0_10  connected_order_arc_642  -1
    order_0_10  connected_order_arc_644  -1
    order_0_10  connected_order_arc_646  -1
    order_0_10  connected_order_arc_648  -1
    order_0_10  connected_order_arc_650  -1
    order_0_10  connected_order_arc_652  -1
    order_0_10  connected_order_arc_654  -1
    order_0_10  connected_order_arc_656  -1
    order_0_10  connected_order_arc_675  1
    order_0_10  connected_order_arc_704  1
    order_0_10  connected_order_arc_733  1
    order_0_10  connected_order_arc_762  1
    order_0_10  connected_order_arc_791  1
    order_0_10  connected_order_arc_820  1
    order_0_10  order_active_lb_890  1
    order_0_10  order_active_ub_891  1
    visit_0_11  out_degree_894  -1
    visit_0_11  in_degree_895  -1
    visit_0_11  order_active_lb_896  -1
    visit_0_11  order_active_ub_897  -15
    visit_0_11  service_visit_def_898  -1
    order_0_11  connected_order_arc_414  1
    order_0_11  connected_order_arc_443  1
    order_0_11  connected_order_arc_472  1
    order_0_11  connected_order_arc_501  1
    order_0_11  connected_order_arc_530  1
    order_0_11  connected_order_arc_559  1
    order_0_11  connected_order_arc_588  1
    order_0_11  connected_order_arc_617  1
    order_0_11  connected_order_arc_646  1
    order_0_11  connected_order_arc_659  -1
    order_0_11  connected_order_arc_661  -1
    order_0_11  connected_order_arc_663  -1
    order_0_11  connected_order_arc_665  -1
    order_0_11  connected_order_arc_667  -1
    order_0_11  connected_order_arc_669  -1
    order_0_11  connected_order_arc_671  -1
    order_0_11  connected_order_arc_673  -1
    order_0_11  connected_order_arc_675  -1
    order_0_11  connected_order_arc_677  -1
    order_0_11  connected_order_arc_679  -1
    order_0_11  connected_order_arc_681  -1
    order_0_11  connected_order_arc_683  -1
    order_0_11  connected_order_arc_685  -1
    order_0_11  connected_order_arc_706  1
    order_0_11  connected_order_arc_735  1
    order_0_11  connected_order_arc_764  1
    order_0_11  connected_order_arc_793  1
    order_0_11  connected_order_arc_822  1
    order_0_11  order_active_lb_896  1
    order_0_11  order_active_ub_897  1
    visit_0_12  out_degree_900  -1
    visit_0_12  in_degree_901  -1
    visit_0_12  order_active_lb_902  -1
    visit_0_12  order_active_ub_903  -15
    visit_0_12  service_visit_def_904  -1
    order_0_12  connected_order_arc_416  1
    order_0_12  connected_order_arc_445  1
    order_0_12  connected_order_arc_474  1
    order_0_12  connected_order_arc_503  1
    order_0_12  connected_order_arc_532  1
    order_0_12  connected_order_arc_561  1
    order_0_12  connected_order_arc_590  1
    order_0_12  connected_order_arc_619  1
    order_0_12  connected_order_arc_648  1
    order_0_12  connected_order_arc_677  1
    order_0_12  connected_order_arc_688  -1
    order_0_12  connected_order_arc_690  -1
    order_0_12  connected_order_arc_692  -1
    order_0_12  connected_order_arc_694  -1
    order_0_12  connected_order_arc_696  -1
    order_0_12  connected_order_arc_698  -1
    order_0_12  connected_order_arc_700  -1
    order_0_12  connected_order_arc_702  -1
    order_0_12  connected_order_arc_704  -1
    order_0_12  connected_order_arc_706  -1
    order_0_12  connected_order_arc_708  -1
    order_0_12  connected_order_arc_710  -1
    order_0_12  connected_order_arc_712  -1
    order_0_12  connected_order_arc_714  -1
    order_0_12  connected_order_arc_737  1
    order_0_12  connected_order_arc_766  1
    order_0_12  connected_order_arc_795  1
    order_0_12  connected_order_arc_824  1
    order_0_12  order_active_lb_902  1
    order_0_12  order_active_ub_903  1
    visit_0_13  out_degree_906  -1
    visit_0_13  in_degree_907  -1
    visit_0_13  order_active_lb_908  -1
    visit_0_13  order_active_ub_909  -15
    visit_0_13  service_visit_def_910  -1
    order_0_13  connected_order_arc_418  1
    order_0_13  connected_order_arc_447  1
    order_0_13  connected_order_arc_476  1
    order_0_13  connected_order_arc_505  1
    order_0_13  connected_order_arc_534  1
    order_0_13  connected_order_arc_563  1
    order_0_13  connected_order_arc_592  1
    order_0_13  connected_order_arc_621  1
    order_0_13  connected_order_arc_650  1
    order_0_13  connected_order_arc_679  1
    order_0_13  connected_order_arc_708  1
    order_0_13  connected_order_arc_717  -1
    order_0_13  connected_order_arc_719  -1
    order_0_13  connected_order_arc_721  -1
    order_0_13  connected_order_arc_723  -1
    order_0_13  connected_order_arc_725  -1
    order_0_13  connected_order_arc_727  -1
    order_0_13  connected_order_arc_729  -1
    order_0_13  connected_order_arc_731  -1
    order_0_13  connected_order_arc_733  -1
    order_0_13  connected_order_arc_735  -1
    order_0_13  connected_order_arc_737  -1
    order_0_13  connected_order_arc_739  -1
    order_0_13  connected_order_arc_741  -1
    order_0_13  connected_order_arc_743  -1
    order_0_13  connected_order_arc_768  1
    order_0_13  connected_order_arc_797  1
    order_0_13  connected_order_arc_826  1
    order_0_13  order_active_lb_908  1
    order_0_13  order_active_ub_909  1
    visit_0_14  out_degree_912  -1
    visit_0_14  in_degree_913  -1
    visit_0_14  order_active_lb_914  -1
    visit_0_14  order_active_ub_915  -15
    visit_0_14  service_visit_def_916  -1
    order_0_14  connected_order_arc_420  1
    order_0_14  connected_order_arc_449  1
    order_0_14  connected_order_arc_478  1
    order_0_14  connected_order_arc_507  1
    order_0_14  connected_order_arc_536  1
    order_0_14  connected_order_arc_565  1
    order_0_14  connected_order_arc_594  1
    order_0_14  connected_order_arc_623  1
    order_0_14  connected_order_arc_652  1
    order_0_14  connected_order_arc_681  1
    order_0_14  connected_order_arc_710  1
    order_0_14  connected_order_arc_739  1
    order_0_14  connected_order_arc_746  -1
    order_0_14  connected_order_arc_748  -1
    order_0_14  connected_order_arc_750  -1
    order_0_14  connected_order_arc_752  -1
    order_0_14  connected_order_arc_754  -1
    order_0_14  connected_order_arc_756  -1
    order_0_14  connected_order_arc_758  -1
    order_0_14  connected_order_arc_760  -1
    order_0_14  connected_order_arc_762  -1
    order_0_14  connected_order_arc_764  -1
    order_0_14  connected_order_arc_766  -1
    order_0_14  connected_order_arc_768  -1
    order_0_14  connected_order_arc_770  -1
    order_0_14  connected_order_arc_772  -1
    order_0_14  connected_order_arc_799  1
    order_0_14  connected_order_arc_828  1
    order_0_14  order_active_lb_914  1
    order_0_14  order_active_ub_915  1
    visit_0_15  out_degree_918  -1
    visit_0_15  in_degree_919  -1
    visit_0_15  order_active_lb_920  -1
    visit_0_15  order_active_ub_921  -15
    visit_0_15  service_visit_def_922  -1
    order_0_15  connected_order_arc_422  1
    order_0_15  connected_order_arc_451  1
    order_0_15  connected_order_arc_480  1
    order_0_15  connected_order_arc_509  1
    order_0_15  connected_order_arc_538  1
    order_0_15  connected_order_arc_567  1
    order_0_15  connected_order_arc_596  1
    order_0_15  connected_order_arc_625  1
    order_0_15  connected_order_arc_654  1
    order_0_15  connected_order_arc_683  1
    order_0_15  connected_order_arc_712  1
    order_0_15  connected_order_arc_741  1
    order_0_15  connected_order_arc_770  1
    order_0_15  connected_order_arc_775  -1
    order_0_15  connected_order_arc_777  -1
    order_0_15  connected_order_arc_779  -1
    order_0_15  connected_order_arc_781  -1
    order_0_15  connected_order_arc_783  -1
    order_0_15  connected_order_arc_785  -1
    order_0_15  connected_order_arc_787  -1
    order_0_15  connected_order_arc_789  -1
    order_0_15  connected_order_arc_791  -1
    order_0_15  connected_order_arc_793  -1
    order_0_15  connected_order_arc_795  -1
    order_0_15  connected_order_arc_797  -1
    order_0_15  connected_order_arc_799  -1
    order_0_15  connected_order_arc_801  -1
    order_0_15  connected_order_arc_830  1
    order_0_15  order_active_lb_920  1
    order_0_15  order_active_ub_921  1
    visit_0_16  out_degree_924  -1
    visit_0_16  in_degree_925  -1
    visit_0_16  order_active_lb_926  -1
    visit_0_16  order_active_ub_927  -15
    visit_0_16  service_visit_def_928  -1
    order_0_16  connected_order_arc_424  1
    order_0_16  connected_order_arc_453  1
    order_0_16  connected_order_arc_482  1
    order_0_16  connected_order_arc_511  1
    order_0_16  connected_order_arc_540  1
    order_0_16  connected_order_arc_569  1
    order_0_16  connected_order_arc_598  1
    order_0_16  connected_order_arc_627  1
    order_0_16  connected_order_arc_656  1
    order_0_16  connected_order_arc_685  1
    order_0_16  connected_order_arc_714  1
    order_0_16  connected_order_arc_743  1
    order_0_16  connected_order_arc_772  1
    order_0_16  connected_order_arc_801  1
    order_0_16  connected_order_arc_804  -1
    order_0_16  connected_order_arc_806  -1
    order_0_16  connected_order_arc_808  -1
    order_0_16  connected_order_arc_810  -1
    order_0_16  connected_order_arc_812  -1
    order_0_16  connected_order_arc_814  -1
    order_0_16  connected_order_arc_816  -1
    order_0_16  connected_order_arc_818  -1
    order_0_16  connected_order_arc_820  -1
    order_0_16  connected_order_arc_822  -1
    order_0_16  connected_order_arc_824  -1
    order_0_16  connected_order_arc_826  -1
    order_0_16  connected_order_arc_828  -1
    order_0_16  connected_order_arc_830  -1
    order_0_16  order_active_lb_926  1
    order_0_16  order_active_ub_927  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_0  arc_capacity_380  -30
    arc_0_0_0  depot_departure_or_bypass_831  1
    arc_0_0_0  depot_return_or_bypass_832  1
    MARKER    'MARKER'                 'INTEND'
    load_0_0_0  arc_capacity_380  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_1  arc_capacity_381  -30
    arc_0_0_1  depot_departure_or_bypass_831  1
    arc_0_0_1  in_degree_834  1
    arc_0_0_1  original_T_including_depot_unload_936  9.3659929340140741e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_1  arc_capacity_381  1
    load_0_0_1  segment_load_conservation_837  -1
    load_0_0_1  segment_prefix_lb_838  1
    load_0_0_1  segment_prefix_ub_839  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_2  arc_capacity_382  -30
    arc_0_0_2  depot_departure_or_bypass_831  1
    arc_0_0_2  in_degree_841  1
    arc_0_0_2  original_T_including_depot_unload_936  1.2186896810212775e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_2  arc_capacity_382  1
    load_0_0_2  segment_load_conservation_844  -1
    load_0_0_2  segment_prefix_lb_845  1
    load_0_0_2  segment_prefix_ub_846  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_3  arc_capacity_383  -30
    arc_0_0_3  depot_departure_or_bypass_831  1
    arc_0_0_3  in_degree_848  1
    arc_0_0_3  original_T_including_depot_unload_936  9.3133633713881534e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_3  arc_capacity_383  1
    load_0_0_3  segment_load_conservation_851  -1
    load_0_0_3  segment_prefix_lb_852  1
    load_0_0_3  segment_prefix_ub_853  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_4  arc_capacity_384  -30
    arc_0_0_4  depot_departure_or_bypass_831  1
    arc_0_0_4  in_degree_855  1
    arc_0_0_4  original_T_including_depot_unload_936  8.2548955430739034e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_4  arc_capacity_384  1
    load_0_0_4  segment_load_conservation_858  -1
    load_0_0_4  segment_prefix_lb_859  1
    load_0_0_4  segment_prefix_ub_860  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_5  arc_capacity_385  -30
    arc_0_0_5  depot_departure_or_bypass_831  1
    arc_0_0_5  in_degree_862  1
    arc_0_0_5  original_T_including_depot_unload_936  7.4412496590753551e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_5  arc_capacity_385  1
    load_0_0_5  segment_load_conservation_865  -1
    load_0_0_5  segment_prefix_lb_866  1
    load_0_0_5  segment_prefix_ub_867  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_6  arc_capacity_386  -30
    arc_0_0_6  depot_departure_or_bypass_831  1
    arc_0_0_6  in_degree_869  1
    arc_0_0_6  original_T_including_depot_unload_936  5.9631731642067359e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_6  arc_capacity_386  1
    load_0_0_6  segment_load_conservation_872  -1
    load_0_0_6  segment_prefix_lb_873  1
    load_0_0_6  segment_prefix_ub_874  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_7  arc_capacity_387  -30
    arc_0_0_7  depot_departure_or_bypass_831  1
    arc_0_0_7  in_degree_876  1
    arc_0_0_7  original_T_including_depot_unload_936  4.1588440854375170e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_7  arc_capacity_387  1
    load_0_0_7  segment_load_conservation_879  -1
    load_0_0_7  segment_prefix_lb_880  1
    load_0_0_7  segment_prefix_ub_881  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_9  arc_capacity_388  -30
    arc_0_0_9  depot_departure_or_bypass_831  1
    arc_0_0_9  in_degree_883  1
    arc_0_0_9  original_T_including_depot_unload_936  1.8065333212349267e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_9  arc_capacity_388  1
    load_0_0_9  free_load_conservation_887  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_10  arc_capacity_389  -30
    arc_0_0_10  depot_departure_or_bypass_831  1
    arc_0_0_10  in_degree_889  1
    arc_0_0_10  original_T_including_depot_unload_936  1739.61165920636
    MARKER    'MARKER'                 'INTEND'
    load_0_0_10  arc_capacity_389  1
    load_0_0_10  free_load_conservation_893  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_11  arc_capacity_390  -30
    arc_0_0_11  depot_departure_or_bypass_831  1
    arc_0_0_11  in_degree_895  1
    arc_0_0_11  original_T_including_depot_unload_936  2.3234267380118886e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_11  arc_capacity_390  1
    load_0_0_11  free_load_conservation_899  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_12  arc_capacity_391  -30
    arc_0_0_12  depot_departure_or_bypass_831  1
    arc_0_0_12  in_degree_901  1
    arc_0_0_12  original_T_including_depot_unload_936  2.2866763971369810e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_12  arc_capacity_391  1
    load_0_0_12  free_load_conservation_905  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_13  arc_capacity_392  -30
    arc_0_0_13  depot_departure_or_bypass_831  1
    arc_0_0_13  in_degree_907  1
    arc_0_0_13  original_T_including_depot_unload_936  2.0232971184291544e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_13  arc_capacity_392  1
    load_0_0_13  free_load_conservation_911  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_14  arc_capacity_393  -30
    arc_0_0_14  depot_departure_or_bypass_831  1
    arc_0_0_14  in_degree_913  1
    arc_0_0_14  original_T_including_depot_unload_936  3.5937232665424995e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_14  arc_capacity_393  1
    load_0_0_14  free_load_conservation_917  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_15  arc_capacity_394  -30
    arc_0_0_15  depot_departure_or_bypass_831  1
    arc_0_0_15  in_degree_919  1
    arc_0_0_15  original_T_including_depot_unload_936  1.1473865007565566e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_15  arc_capacity_394  1
    load_0_0_15  free_load_conservation_923  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_16  arc_capacity_395  -30
    arc_0_0_16  depot_departure_or_bypass_831  1
    arc_0_0_16  in_degree_925  1
    arc_0_0_16  original_T_including_depot_unload_936  5.2774046204590661e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_16  arc_capacity_395  1
    load_0_0_16  free_load_conservation_929  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_0  arc_capacity_396  -30
    arc_0_1_0  depot_return_or_bypass_832  1
    arc_0_1_0  out_degree_833  1
    arc_0_1_0  original_T_including_depot_unload_936  9.3659929340140741e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_0  arc_capacity_396  1
    load_0_1_0  segment_load_conservation_837  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_2  arc_capacity_397  -30
    arc_0_1_2  connected_order_arc_398  -16
    arc_0_1_2  out_degree_833  1
    arc_0_1_2  in_degree_841  1
    arc_0_1_2  original_T_including_depot_unload_936  2.8260257937815851e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_2  arc_capacity_397  1
    load_0_1_2  segment_load_conservation_837  1
    load_0_1_2  segment_load_conservation_844  -1
    load_0_1_2  segment_prefix_lb_845  1
    load_0_1_2  segment_prefix_ub_846  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_3  arc_capacity_399  -30
    arc_0_1_3  connected_order_arc_400  -16
    arc_0_1_3  out_degree_833  1
    arc_0_1_3  in_degree_848  1
    arc_0_1_3  original_T_including_depot_unload_936  2.9819555494495978e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_3  arc_capacity_399  1
    load_0_1_3  segment_load_conservation_837  1
    load_0_1_3  segment_load_conservation_851  -1
    load_0_1_3  segment_prefix_lb_852  1
    load_0_1_3  segment_prefix_ub_853  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_4  arc_capacity_401  -30
    arc_0_1_4  connected_order_arc_402  -16
    arc_0_1_4  out_degree_833  1
    arc_0_1_4  in_degree_855  1
    arc_0_1_4  original_T_including_depot_unload_936  2.0241950709354862e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_4  arc_capacity_401  1
    load_0_1_4  segment_load_conservation_837  1
    load_0_1_4  segment_load_conservation_858  -1
    load_0_1_4  segment_prefix_lb_859  1
    load_0_1_4  segment_prefix_ub_860  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_5  arc_capacity_403  -30
    arc_0_1_5  connected_order_arc_404  -16
    arc_0_1_5  out_degree_833  1
    arc_0_1_5  in_degree_862  1
    arc_0_1_5  original_T_including_depot_unload_936  2.0082608212298291e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_5  arc_capacity_403  1
    load_0_1_5  segment_load_conservation_837  1
    load_0_1_5  segment_load_conservation_865  -1
    load_0_1_5  segment_prefix_lb_866  1
    load_0_1_5  segment_prefix_ub_867  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_6  arc_capacity_405  -30
    arc_0_1_6  connected_order_arc_406  -16
    arc_0_1_6  out_degree_833  1
    arc_0_1_6  in_degree_869  1
    arc_0_1_6  original_T_including_depot_unload_936  3.4037893208114895e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_6  arc_capacity_405  1
    load_0_1_6  segment_load_conservation_837  1
    load_0_1_6  segment_load_conservation_872  -1
    load_0_1_6  segment_prefix_lb_873  1
    load_0_1_6  segment_prefix_ub_874  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_7  arc_capacity_407  -30
    arc_0_1_7  connected_order_arc_408  -16
    arc_0_1_7  out_degree_833  1
    arc_0_1_7  in_degree_876  1
    arc_0_1_7  original_T_including_depot_unload_936  5.4626430531406254e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_7  arc_capacity_407  1
    load_0_1_7  segment_load_conservation_837  1
    load_0_1_7  segment_load_conservation_879  -1
    load_0_1_7  segment_prefix_lb_880  1
    load_0_1_7  segment_prefix_ub_881  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_9  arc_capacity_409  -30
    arc_0_1_9  connected_order_arc_410  -16
    arc_0_1_9  out_degree_833  1
    arc_0_1_9  in_degree_883  1
    arc_0_1_9  original_T_including_depot_unload_936  2.0021738809925773e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_9  arc_capacity_409  1
    load_0_1_9  segment_load_conservation_837  1
    load_0_1_9  free_load_conservation_887  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_10  arc_capacity_411  -30
    arc_0_1_10  connected_order_arc_412  -16
    arc_0_1_10  out_degree_833  1
    arc_0_1_10  in_degree_889  1
    arc_0_1_10  original_T_including_depot_unload_936  1.9959569014367933e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_10  arc_capacity_411  1
    load_0_1_10  segment_load_conservation_837  1
    load_0_1_10  free_load_conservation_893  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_11  arc_capacity_413  -30
    arc_0_1_11  connected_order_arc_414  -16
    arc_0_1_11  out_degree_833  1
    arc_0_1_11  in_degree_895  1
    arc_0_1_11  original_T_including_depot_unload_936  3.0726580305165480e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_11  arc_capacity_413  1
    load_0_1_11  segment_load_conservation_837  1
    load_0_1_11  free_load_conservation_899  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_12  arc_capacity_415  -30
    arc_0_1_12  connected_order_arc_416  -16
    arc_0_1_12  out_degree_833  1
    arc_0_1_12  in_degree_901  1
    arc_0_1_12  original_T_including_depot_unload_936  2.5292035468949002e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_12  arc_capacity_415  1
    load_0_1_12  segment_load_conservation_837  1
    load_0_1_12  free_load_conservation_905  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_13  arc_capacity_417  -30
    arc_0_1_13  connected_order_arc_418  -16
    arc_0_1_13  out_degree_833  1
    arc_0_1_13  in_degree_907  1
    arc_0_1_13  original_T_including_depot_unload_936  2.8800138602390562e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_13  arc_capacity_417  1
    load_0_1_13  segment_load_conservation_837  1
    load_0_1_13  free_load_conservation_911  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_14  arc_capacity_419  -30
    arc_0_1_14  connected_order_arc_420  -16
    arc_0_1_14  out_degree_833  1
    arc_0_1_14  in_degree_913  1
    arc_0_1_14  original_T_including_depot_unload_936  1.1702148343313254e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_14  arc_capacity_419  1
    load_0_1_14  segment_load_conservation_837  1
    load_0_1_14  free_load_conservation_917  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_15  arc_capacity_421  -30
    arc_0_1_15  connected_order_arc_422  -16
    arc_0_1_15  out_degree_833  1
    arc_0_1_15  in_degree_919  1
    arc_0_1_15  original_T_including_depot_unload_936  4.5058965368847572e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_15  arc_capacity_421  1
    load_0_1_15  segment_load_conservation_837  1
    load_0_1_15  free_load_conservation_923  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_16  arc_capacity_423  -30
    arc_0_1_16  connected_order_arc_424  -16
    arc_0_1_16  out_degree_833  1
    arc_0_1_16  in_degree_925  1
    arc_0_1_16  original_T_including_depot_unload_936  4.4360641393992279e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_16  arc_capacity_423  1
    load_0_1_16  segment_load_conservation_837  1
    load_0_1_16  free_load_conservation_929  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_0  arc_capacity_425  -30
    arc_0_2_0  depot_return_or_bypass_832  1
    arc_0_2_0  out_degree_840  1
    arc_0_2_0  original_T_including_depot_unload_936  1.2186896810212775e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_0  arc_capacity_425  1
    load_0_2_0  segment_load_conservation_844  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_1  arc_capacity_426  -30
    arc_0_2_1  connected_order_arc_427  -16
    arc_0_2_1  in_degree_834  1
    arc_0_2_1  out_degree_840  1
    arc_0_2_1  original_T_including_depot_unload_936  2.8260257937815851e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_1  arc_capacity_426  1
    load_0_2_1  segment_load_conservation_837  -1
    load_0_2_1  segment_prefix_lb_838  1
    load_0_2_1  segment_prefix_ub_839  1
    load_0_2_1  segment_load_conservation_844  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_3  arc_capacity_428  -30
    arc_0_2_3  connected_order_arc_429  -16
    arc_0_2_3  out_degree_840  1
    arc_0_2_3  in_degree_848  1
    arc_0_2_3  original_T_including_depot_unload_936  4.3257823465305182e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_3  arc_capacity_428  1
    load_0_2_3  segment_load_conservation_844  1
    load_0_2_3  segment_load_conservation_851  -1
    load_0_2_3  segment_prefix_lb_852  1
    load_0_2_3  segment_prefix_ub_853  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_4  arc_capacity_430  -30
    arc_0_2_4  connected_order_arc_431  -16
    arc_0_2_4  out_degree_840  1
    arc_0_2_4  in_degree_855  1
    arc_0_2_4  original_T_including_depot_unload_936  4.3124580937307496e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_4  arc_capacity_430  1
    load_0_2_4  segment_load_conservation_844  1
    load_0_2_4  segment_load_conservation_858  -1
    load_0_2_4  segment_prefix_lb_859  1
    load_0_2_4  segment_prefix_ub_860  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_5  arc_capacity_432  -30
    arc_0_2_5  connected_order_arc_433  -16
    arc_0_2_5  out_degree_840  1
    arc_0_2_5  in_degree_862  1
    arc_0_2_5  original_T_including_depot_unload_936  4.7721499161748335e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_5  arc_capacity_432  1
    load_0_2_5  segment_load_conservation_844  1
    load_0_2_5  segment_load_conservation_865  -1
    load_0_2_5  segment_prefix_lb_866  1
    load_0_2_5  segment_prefix_ub_867  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_6  arc_capacity_434  -30
    arc_0_2_6  connected_order_arc_435  -16
    arc_0_2_6  out_degree_840  1
    arc_0_2_6  in_degree_869  1
    arc_0_2_6  original_T_including_depot_unload_936  6.2279118029742506e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_6  arc_capacity_434  1
    load_0_2_6  segment_load_conservation_844  1
    load_0_2_6  segment_load_conservation_872  -1
    load_0_2_6  segment_prefix_lb_873  1
    load_0_2_6  segment_prefix_ub_874  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_7  arc_capacity_436  -30
    arc_0_2_7  connected_order_arc_437  -16
    arc_0_2_7  out_degree_840  1
    arc_0_2_7  in_degree_876  1
    arc_0_2_7  original_T_including_depot_unload_936  8.2210727717430609e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_7  arc_capacity_436  1
    load_0_2_7  segment_load_conservation_844  1
    load_0_2_7  segment_load_conservation_879  -1
    load_0_2_7  segment_prefix_lb_880  1
    load_0_2_7  segment_prefix_ub_881  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_9  arc_capacity_438  -30
    arc_0_2_9  connected_order_arc_439  -16
    arc_0_2_9  out_degree_840  1
    arc_0_2_9  in_degree_883  1
    arc_0_2_9  original_T_including_depot_unload_936  2.1556817566230284e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_9  arc_capacity_438  1
    load_0_2_9  segment_load_conservation_844  1
    load_0_2_9  free_load_conservation_887  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_10  arc_capacity_440  -30
    arc_0_2_10  connected_order_arc_441  -16
    arc_0_2_10  out_degree_840  1
    arc_0_2_10  in_degree_889  1
    arc_0_2_10  original_T_including_depot_unload_936  2.1641391312462424e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_10  arc_capacity_440  1
    load_0_2_10  segment_load_conservation_844  1
    load_0_2_10  free_load_conservation_893  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_11  arc_capacity_442  -30
    arc_0_2_11  connected_order_arc_443  -16
    arc_0_2_11  out_degree_840  1
    arc_0_2_11  in_degree_895  1
    arc_0_2_11  original_T_including_depot_unload_936  3.3076115257178203e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_11  arc_capacity_442  1
    load_0_2_11  segment_load_conservation_844  1
    load_0_2_11  free_load_conservation_899  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_12  arc_capacity_444  -30
    arc_0_2_12  connected_order_arc_445  -16
    arc_0_2_12  out_degree_840  1
    arc_0_2_12  in_degree_901  1
    arc_0_2_12  original_T_including_depot_unload_936  2.6797194604092651e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_12  arc_capacity_444  1
    load_0_2_12  segment_load_conservation_844  1
    load_0_2_12  free_load_conservation_905  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_13  arc_capacity_446  -30
    arc_0_2_13  connected_order_arc_447  -16
    arc_0_2_13  out_degree_840  1
    arc_0_2_13  in_degree_907  1
    arc_0_2_13  original_T_including_depot_unload_936  3.1528795137337825e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_13  arc_capacity_446  1
    load_0_2_13  segment_load_conservation_844  1
    load_0_2_13  free_load_conservation_911  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_14  arc_capacity_448  -30
    arc_0_2_14  connected_order_arc_449  -16
    arc_0_2_14  out_degree_840  1
    arc_0_2_14  in_degree_913  1
    arc_0_2_14  original_T_including_depot_unload_936  1.4485896981484648e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_14  arc_capacity_448  1
    load_0_2_14  segment_load_conservation_844  1
    load_0_2_14  free_load_conservation_917  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_15  arc_capacity_450  -30
    arc_0_2_15  connected_order_arc_451  -16
    arc_0_2_15  out_degree_840  1
    arc_0_2_15  in_degree_919  1
    arc_0_2_15  original_T_including_depot_unload_936  4.4158457011124148e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_15  arc_capacity_450  1
    load_0_2_15  segment_load_conservation_844  1
    load_0_2_15  free_load_conservation_923  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_16  arc_capacity_452  -30
    arc_0_2_16  connected_order_arc_453  -16
    arc_0_2_16  out_degree_840  1
    arc_0_2_16  in_degree_925  1
    arc_0_2_16  original_T_including_depot_unload_936  7.2186296856879846e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_16  arc_capacity_452  1
    load_0_2_16  segment_load_conservation_844  1
    load_0_2_16  free_load_conservation_929  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_0  arc_capacity_454  -30
    arc_0_3_0  depot_return_or_bypass_832  1
    arc_0_3_0  out_degree_847  1
    arc_0_3_0  original_T_including_depot_unload_936  9.3133633713881534e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_0  arc_capacity_454  1
    load_0_3_0  segment_load_conservation_851  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_1  arc_capacity_455  -30
    arc_0_3_1  connected_order_arc_456  -16
    arc_0_3_1  in_degree_834  1
    arc_0_3_1  out_degree_847  1
    arc_0_3_1  original_T_including_depot_unload_936  2.9819555494495978e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_1  arc_capacity_455  1
    load_0_3_1  segment_load_conservation_837  -1
    load_0_3_1  segment_prefix_lb_838  1
    load_0_3_1  segment_prefix_ub_839  1
    load_0_3_1  segment_load_conservation_851  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_2  arc_capacity_457  -30
    arc_0_3_2  connected_order_arc_458  -16
    arc_0_3_2  in_degree_841  1
    arc_0_3_2  out_degree_847  1
    arc_0_3_2  original_T_including_depot_unload_936  4.3257823465305182e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_2  arc_capacity_457  1
    load_0_3_2  segment_load_conservation_844  -1
    load_0_3_2  segment_prefix_lb_845  1
    load_0_3_2  segment_prefix_ub_846  1
    load_0_3_2  segment_load_conservation_851  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_4  arc_capacity_459  -30
    arc_0_3_4  connected_order_arc_460  -16
    arc_0_3_4  out_degree_847  1
    arc_0_3_4  in_degree_855  1
    arc_0_3_4  original_T_including_depot_unload_936  1.5413712102626312e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_4  arc_capacity_459  1
    load_0_3_4  segment_load_conservation_851  1
    load_0_3_4  segment_load_conservation_858  -1
    load_0_3_4  segment_prefix_lb_859  1
    load_0_3_4  segment_prefix_ub_860  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_5  arc_capacity_461  -30
    arc_0_3_5  connected_order_arc_462  -16
    arc_0_3_5  out_degree_847  1
    arc_0_3_5  in_degree_862  1
    arc_0_3_5  original_T_including_depot_unload_936  2.8072002002622634e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_5  arc_capacity_461  1
    load_0_3_5  segment_load_conservation_851  1
    load_0_3_5  segment_load_conservation_865  -1
    load_0_3_5  segment_prefix_lb_866  1
    load_0_3_5  segment_prefix_ub_867  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_6  arc_capacity_463  -30
    arc_0_3_6  connected_order_arc_464  -16
    arc_0_3_6  out_degree_847  1
    arc_0_3_6  in_degree_869  1
    arc_0_3_6  original_T_including_depot_unload_936  4.1557375918514475e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_6  arc_capacity_463  1
    load_0_3_6  segment_load_conservation_851  1
    load_0_3_6  segment_load_conservation_872  -1
    load_0_3_6  segment_prefix_lb_873  1
    load_0_3_6  segment_prefix_ub_874  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_7  arc_capacity_465  -30
    arc_0_3_7  connected_order_arc_466  -16
    arc_0_3_7  out_degree_847  1
    arc_0_3_7  in_degree_876  1
    arc_0_3_7  original_T_including_depot_unload_936  516.598297486096
    MARKER    'MARKER'                 'INTEND'
    load_0_3_7  arc_capacity_465  1
    load_0_3_7  segment_load_conservation_851  1
    load_0_3_7  segment_load_conservation_879  -1
    load_0_3_7  segment_prefix_lb_880  1
    load_0_3_7  segment_prefix_ub_881  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_9  arc_capacity_467  -30
    arc_0_3_9  connected_order_arc_468  -16
    arc_0_3_9  out_degree_847  1
    arc_0_3_9  in_degree_883  1
    arc_0_3_9  original_T_including_depot_unload_936  2.2507610939146793e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_9  arc_capacity_467  1
    load_0_3_9  segment_load_conservation_851  1
    load_0_3_9  free_load_conservation_887  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_10  arc_capacity_469  -30
    arc_0_3_10  connected_order_arc_470  -16
    arc_0_3_10  out_degree_847  1
    arc_0_3_10  in_degree_889  1
    arc_0_3_10  original_T_including_depot_unload_936  2.2339035809798856e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_10  arc_capacity_469  1
    load_0_3_10  segment_load_conservation_851  1
    load_0_3_10  free_load_conservation_893  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_11  arc_capacity_471  -30
    arc_0_3_11  connected_order_arc_472  -16
    arc_0_3_11  out_degree_847  1
    arc_0_3_11  in_degree_895  1
    arc_0_3_11  original_T_including_depot_unload_936  2.8839695646198670e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_11  arc_capacity_471  1
    load_0_3_11  segment_load_conservation_851  1
    load_0_3_11  free_load_conservation_899  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_12  arc_capacity_473  -30
    arc_0_3_12  connected_order_arc_474  -16
    arc_0_3_12  out_degree_847  1
    arc_0_3_12  in_degree_901  1
    arc_0_3_12  original_T_including_depot_unload_936  2.7766616410403444e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_12  arc_capacity_473  1
    load_0_3_12  segment_load_conservation_851  1
    load_0_3_12  free_load_conservation_905  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_13  arc_capacity_475  -30
    arc_0_3_13  connected_order_arc_476  -16
    arc_0_3_13  out_degree_847  1
    arc_0_3_13  in_degree_907  1
    arc_0_3_13  original_T_including_depot_unload_936  2.9442201339702592e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_13  arc_capacity_475  1
    load_0_3_13  segment_load_conservation_851  1
    load_0_3_13  free_load_conservation_911  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_14  arc_capacity_477  -30
    arc_0_3_14  connected_order_arc_478  -16
    arc_0_3_14  out_degree_847  1
    arc_0_3_14  in_degree_913  1
    arc_0_3_14  original_T_including_depot_unload_936  1.2315777010885340e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_14  arc_capacity_477  1
    load_0_3_14  segment_load_conservation_851  1
    load_0_3_14  free_load_conservation_917  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_15  arc_capacity_479  -30
    arc_0_3_15  connected_order_arc_480  -16
    arc_0_3_15  out_degree_847  1
    arc_0_3_15  in_degree_919  1
    arc_0_3_15  original_T_including_depot_unload_936  2.2655310037545112e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_15  arc_capacity_479  1
    load_0_3_15  segment_load_conservation_851  1
    load_0_3_15  free_load_conservation_923  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_16  arc_capacity_481  -30
    arc_0_3_16  connected_order_arc_482  -16
    arc_0_3_16  out_degree_847  1
    arc_0_3_16  in_degree_925  1
    arc_0_3_16  original_T_including_depot_unload_936  5.6231331158364958e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_16  arc_capacity_481  1
    load_0_3_16  segment_load_conservation_851  1
    load_0_3_16  free_load_conservation_929  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_0  arc_capacity_483  -30
    arc_0_4_0  depot_return_or_bypass_832  1
    arc_0_4_0  out_degree_854  1
    arc_0_4_0  original_T_including_depot_unload_936  8.2548955430739034e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_0  arc_capacity_483  1
    load_0_4_0  segment_load_conservation_858  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_1  arc_capacity_484  -30
    arc_0_4_1  connected_order_arc_485  -16
    arc_0_4_1  in_degree_834  1
    arc_0_4_1  out_degree_854  1
    arc_0_4_1  original_T_including_depot_unload_936  2.0241950709354862e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_1  arc_capacity_484  1
    load_0_4_1  segment_load_conservation_837  -1
    load_0_4_1  segment_prefix_lb_838  1
    load_0_4_1  segment_prefix_ub_839  1
    load_0_4_1  segment_load_conservation_858  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_2  arc_capacity_486  -30
    arc_0_4_2  connected_order_arc_487  -16
    arc_0_4_2  in_degree_841  1
    arc_0_4_2  out_degree_854  1
    arc_0_4_2  original_T_including_depot_unload_936  4.3124580937307496e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_2  arc_capacity_486  1
    load_0_4_2  segment_load_conservation_844  -1
    load_0_4_2  segment_prefix_lb_845  1
    load_0_4_2  segment_prefix_ub_846  1
    load_0_4_2  segment_load_conservation_858  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_3  arc_capacity_488  -30
    arc_0_4_3  connected_order_arc_489  -16
    arc_0_4_3  in_degree_848  1
    arc_0_4_3  out_degree_854  1
    arc_0_4_3  original_T_including_depot_unload_936  1.5413712102626312e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_3  arc_capacity_488  1
    load_0_4_3  segment_load_conservation_851  -1
    load_0_4_3  segment_prefix_lb_852  1
    load_0_4_3  segment_prefix_ub_853  1
    load_0_4_3  segment_load_conservation_858  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_5  arc_capacity_490  -30
    arc_0_4_5  connected_order_arc_491  -16
    arc_0_4_5  out_degree_854  1
    arc_0_4_5  in_degree_862  1
    arc_0_4_5  original_T_including_depot_unload_936  1.2673640125672841e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_5  arc_capacity_490  1
    load_0_4_5  segment_load_conservation_858  1
    load_0_4_5  segment_load_conservation_865  -1
    load_0_4_5  segment_prefix_lb_866  1
    load_0_4_5  segment_prefix_ub_867  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_6  arc_capacity_492  -30
    arc_0_4_6  connected_order_arc_493  -16
    arc_0_4_6  out_degree_854  1
    arc_0_4_6  in_degree_869  1
    arc_0_4_6  original_T_including_depot_unload_936  2.6991456262177837e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_6  arc_capacity_492  1
    load_0_4_6  segment_load_conservation_858  1
    load_0_4_6  segment_load_conservation_872  -1
    load_0_4_6  segment_prefix_lb_873  1
    load_0_4_6  segment_prefix_ub_874  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_7  arc_capacity_494  -30
    arc_0_4_7  connected_order_arc_495  -16
    arc_0_4_7  out_degree_854  1
    arc_0_4_7  in_degree_876  1
    arc_0_4_7  original_T_including_depot_unload_936  4.1180717113418365e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_7  arc_capacity_494  1
    load_0_4_7  segment_load_conservation_858  1
    load_0_4_7  segment_load_conservation_879  -1
    load_0_4_7  segment_prefix_lb_880  1
    load_0_4_7  segment_prefix_ub_881  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_9  arc_capacity_496  -30
    arc_0_4_9  connected_order_arc_497  -16
    arc_0_4_9  out_degree_854  1
    arc_0_4_9  in_degree_883  1
    arc_0_4_9  original_T_including_depot_unload_936  2.0979901720969542e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_9  arc_capacity_496  1
    load_0_4_9  segment_load_conservation_858  1
    load_0_4_9  free_load_conservation_887  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_10  arc_capacity_498  -30
    arc_0_4_10  connected_order_arc_499  -16
    arc_0_4_10  out_degree_854  1
    arc_0_4_10  in_degree_889  1
    arc_0_4_10  original_T_including_depot_unload_936  2.0801782775431307e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_10  arc_capacity_498  1
    load_0_4_10  segment_load_conservation_858  1
    load_0_4_10  free_load_conservation_893  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_11  arc_capacity_500  -30
    arc_0_4_11  connected_order_arc_501  -16
    arc_0_4_11  out_degree_854  1
    arc_0_4_11  in_degree_895  1
    arc_0_4_11  original_T_including_depot_unload_936  2.8834086639088187e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_11  arc_capacity_500  1
    load_0_4_11  segment_load_conservation_858  1
    load_0_4_11  free_load_conservation_899  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_12  arc_capacity_502  -30
    arc_0_4_12  connected_order_arc_503  -16
    arc_0_4_12  out_degree_854  1
    arc_0_4_12  in_degree_901  1
    arc_0_4_12  original_T_including_depot_unload_936  2.6235983504802839e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_12  arc_capacity_502  1
    load_0_4_12  segment_load_conservation_858  1
    load_0_4_12  free_load_conservation_905  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_13  arc_capacity_504  -30
    arc_0_4_13  connected_order_arc_505  -16
    arc_0_4_13  out_degree_854  1
    arc_0_4_13  in_degree_907  1
    arc_0_4_13  original_T_including_depot_unload_936  2820.94140713384
    MARKER    'MARKER'                 'INTEND'
    load_0_4_13  arc_capacity_504  1
    load_0_4_13  segment_load_conservation_858  1
    load_0_4_13  free_load_conservation_911  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_14  arc_capacity_506  -30
    arc_0_4_14  connected_order_arc_507  -16
    arc_0_4_14  out_degree_854  1
    arc_0_4_14  in_degree_913  1
    arc_0_4_14  original_T_including_depot_unload_936  1.1046832181240914e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_14  arc_capacity_506  1
    load_0_4_14  segment_load_conservation_858  1
    load_0_4_14  free_load_conservation_917  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_15  arc_capacity_508  -30
    arc_0_4_15  connected_order_arc_509  -16
    arc_0_4_15  out_degree_854  1
    arc_0_4_15  in_degree_919  1
    arc_0_4_15  original_T_including_depot_unload_936  3.7295617536174859e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_15  arc_capacity_508  1
    load_0_4_15  segment_load_conservation_858  1
    load_0_4_15  free_load_conservation_923  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_16  arc_capacity_510  -30
    arc_0_4_16  connected_order_arc_511  -16
    arc_0_4_16  out_degree_854  1
    arc_0_4_16  in_degree_925  1
    arc_0_4_16  original_T_including_depot_unload_936  4.1346687597344868e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_16  arc_capacity_510  1
    load_0_4_16  segment_load_conservation_858  1
    load_0_4_16  free_load_conservation_929  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_0  arc_capacity_512  -30
    arc_0_5_0  depot_return_or_bypass_832  1
    arc_0_5_0  out_degree_861  1
    arc_0_5_0  original_T_including_depot_unload_936  7.4412496590753551e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_0  arc_capacity_512  1
    load_0_5_0  segment_load_conservation_865  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_1  arc_capacity_513  -30
    arc_0_5_1  connected_order_arc_514  -16
    arc_0_5_1  in_degree_834  1
    arc_0_5_1  out_degree_861  1
    arc_0_5_1  original_T_including_depot_unload_936  2.0082608212298291e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_1  arc_capacity_513  1
    load_0_5_1  segment_load_conservation_837  -1
    load_0_5_1  segment_prefix_lb_838  1
    load_0_5_1  segment_prefix_ub_839  1
    load_0_5_1  segment_load_conservation_865  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_2  arc_capacity_515  -30
    arc_0_5_2  connected_order_arc_516  -16
    arc_0_5_2  in_degree_841  1
    arc_0_5_2  out_degree_861  1
    arc_0_5_2  original_T_including_depot_unload_936  4.7721499161748335e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_2  arc_capacity_515  1
    load_0_5_2  segment_load_conservation_844  -1
    load_0_5_2  segment_prefix_lb_845  1
    load_0_5_2  segment_prefix_ub_846  1
    load_0_5_2  segment_load_conservation_865  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_3  arc_capacity_517  -30
    arc_0_5_3  connected_order_arc_518  -16
    arc_0_5_3  in_degree_848  1
    arc_0_5_3  out_degree_861  1
    arc_0_5_3  original_T_including_depot_unload_936  2.8072002002622634e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_3  arc_capacity_517  1
    load_0_5_3  segment_load_conservation_851  -1
    load_0_5_3  segment_prefix_lb_852  1
    load_0_5_3  segment_prefix_ub_853  1
    load_0_5_3  segment_load_conservation_865  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_4  arc_capacity_519  -30
    arc_0_5_4  connected_order_arc_520  -16
    arc_0_5_4  in_degree_855  1
    arc_0_5_4  out_degree_861  1
    arc_0_5_4  original_T_including_depot_unload_936  1.2673640125672841e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_4  arc_capacity_519  1
    load_0_5_4  segment_load_conservation_858  -1
    load_0_5_4  segment_prefix_lb_859  1
    load_0_5_4  segment_prefix_ub_860  1
    load_0_5_4  segment_load_conservation_865  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_6  arc_capacity_521  -30
    arc_0_5_6  connected_order_arc_522  -16
    arc_0_5_6  out_degree_861  1
    arc_0_5_6  in_degree_869  1
    arc_0_5_6  original_T_including_depot_unload_936  1.5701156446555925e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_6  arc_capacity_521  1
    load_0_5_6  segment_load_conservation_865  1
    load_0_5_6  segment_load_conservation_872  -1
    load_0_5_6  segment_prefix_lb_873  1
    load_0_5_6  segment_prefix_ub_874  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_7  arc_capacity_523  -30
    arc_0_5_7  connected_order_arc_524  -16
    arc_0_5_7  out_degree_861  1
    arc_0_5_7  in_degree_876  1
    arc_0_5_7  original_T_including_depot_unload_936  3.4593676445964553e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_7  arc_capacity_523  1
    load_0_5_7  segment_load_conservation_865  1
    load_0_5_7  segment_load_conservation_879  -1
    load_0_5_7  segment_prefix_lb_880  1
    load_0_5_7  segment_prefix_ub_881  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_9  arc_capacity_525  -30
    arc_0_5_9  connected_order_arc_526  -16
    arc_0_5_9  out_degree_861  1
    arc_0_5_9  in_degree_883  1
    arc_0_5_9  original_T_including_depot_unload_936  1.9740618091449423e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_9  arc_capacity_525  1
    load_0_5_9  segment_load_conservation_865  1
    load_0_5_9  free_load_conservation_887  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_10  arc_capacity_527  -30
    arc_0_5_10  connected_order_arc_528  -16
    arc_0_5_10  out_degree_861  1
    arc_0_5_10  in_degree_889  1
    arc_0_5_10  original_T_including_depot_unload_936  1.9548039027038737e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_10  arc_capacity_527  1
    load_0_5_10  segment_load_conservation_865  1
    load_0_5_10  free_load_conservation_893  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_11  arc_capacity_529  -30
    arc_0_5_11  connected_order_arc_530  -16
    arc_0_5_11  out_degree_861  1
    arc_0_5_11  in_degree_895  1
    arc_0_5_11  original_T_including_depot_unload_936  2.8807002034504962e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_11  arc_capacity_529  1
    load_0_5_11  segment_load_conservation_865  1
    load_0_5_11  free_load_conservation_899  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_12  arc_capacity_531  -30
    arc_0_5_12  connected_order_arc_532  -16
    arc_0_5_12  out_degree_861  1
    arc_0_5_12  in_degree_901  1
    arc_0_5_12  original_T_including_depot_unload_936  2.4992063774241742e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_12  arc_capacity_531  1
    load_0_5_12  segment_load_conservation_865  1
    load_0_5_12  free_load_conservation_905  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_13  arc_capacity_533  -30
    arc_0_5_13  connected_order_arc_534  -16
    arc_0_5_13  out_degree_861  1
    arc_0_5_13  in_degree_907  1
    arc_0_5_13  original_T_including_depot_unload_936  2.7168118802834592e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_13  arc_capacity_533  1
    load_0_5_13  segment_load_conservation_865  1
    load_0_5_13  free_load_conservation_911  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_14  arc_capacity_535  -30
    arc_0_5_14  connected_order_arc_536  -16
    arc_0_5_14  out_degree_861  1
    arc_0_5_14  in_degree_913  1
    arc_0_5_14  original_T_including_depot_unload_936  1.0007616644945284e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_14  arc_capacity_535  1
    load_0_5_14  segment_load_conservation_865  1
    load_0_5_14  free_load_conservation_917  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_15  arc_capacity_537  -30
    arc_0_5_15  connected_order_arc_538  -16
    arc_0_5_15  out_degree_861  1
    arc_0_5_15  in_degree_919  1
    arc_0_5_15  original_T_including_depot_unload_936  4.9817963927689311e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_15  arc_capacity_537  1
    load_0_5_15  segment_load_conservation_865  1
    load_0_5_15  free_load_conservation_923  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_16  arc_capacity_539  -30
    arc_0_5_16  connected_order_arc_540  -16
    arc_0_5_16  out_degree_861  1
    arc_0_5_16  in_degree_925  1
    arc_0_5_16  original_T_including_depot_unload_936  291.965990421835
    MARKER    'MARKER'                 'INTEND'
    load_0_5_16  arc_capacity_539  1
    load_0_5_16  segment_load_conservation_865  1
    load_0_5_16  free_load_conservation_929  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_0  arc_capacity_541  -30
    arc_0_6_0  depot_return_or_bypass_832  1
    arc_0_6_0  out_degree_868  1
    arc_0_6_0  original_T_including_depot_unload_936  5.9631731642067359e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_0  arc_capacity_541  1
    load_0_6_0  segment_load_conservation_872  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_1  arc_capacity_542  -30
    arc_0_6_1  connected_order_arc_543  -16
    arc_0_6_1  in_degree_834  1
    arc_0_6_1  out_degree_868  1
    arc_0_6_1  original_T_including_depot_unload_936  3.4037893208114895e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_1  arc_capacity_542  1
    load_0_6_1  segment_load_conservation_837  -1
    load_0_6_1  segment_prefix_lb_838  1
    load_0_6_1  segment_prefix_ub_839  1
    load_0_6_1  segment_load_conservation_872  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_2  arc_capacity_544  -30
    arc_0_6_2  connected_order_arc_545  -16
    arc_0_6_2  in_degree_841  1
    arc_0_6_2  out_degree_868  1
    arc_0_6_2  original_T_including_depot_unload_936  6.2279118029742506e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_2  arc_capacity_544  1
    load_0_6_2  segment_load_conservation_844  -1
    load_0_6_2  segment_prefix_lb_845  1
    load_0_6_2  segment_prefix_ub_846  1
    load_0_6_2  segment_load_conservation_872  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_3  arc_capacity_546  -30
    arc_0_6_3  connected_order_arc_547  -16
    arc_0_6_3  in_degree_848  1
    arc_0_6_3  out_degree_868  1
    arc_0_6_3  original_T_including_depot_unload_936  4.1557375918514475e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_3  arc_capacity_546  1
    load_0_6_3  segment_load_conservation_851  -1
    load_0_6_3  segment_prefix_lb_852  1
    load_0_6_3  segment_prefix_ub_853  1
    load_0_6_3  segment_load_conservation_872  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_4  arc_capacity_548  -30
    arc_0_6_4  connected_order_arc_549  -16
    arc_0_6_4  in_degree_855  1
    arc_0_6_4  out_degree_868  1
    arc_0_6_4  original_T_including_depot_unload_936  2.6991456262177837e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_4  arc_capacity_548  1
    load_0_6_4  segment_load_conservation_858  -1
    load_0_6_4  segment_prefix_lb_859  1
    load_0_6_4  segment_prefix_ub_860  1
    load_0_6_4  segment_load_conservation_872  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_5  arc_capacity_550  -30
    arc_0_6_5  connected_order_arc_551  -16
    arc_0_6_5  in_degree_862  1
    arc_0_6_5  out_degree_868  1
    arc_0_6_5  original_T_including_depot_unload_936  1.5701156446555925e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_5  arc_capacity_550  1
    load_0_6_5  segment_load_conservation_865  -1
    load_0_6_5  segment_prefix_lb_866  1
    load_0_6_5  segment_prefix_ub_867  1
    load_0_6_5  segment_load_conservation_872  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_7  arc_capacity_552  -30
    arc_0_6_7  connected_order_arc_553  -16
    arc_0_6_7  out_degree_868  1
    arc_0_6_7  in_degree_876  1
    arc_0_6_7  original_T_including_depot_unload_936  2.2661537412294956e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_7  arc_capacity_552  1
    load_0_6_7  segment_load_conservation_872  1
    load_0_6_7  segment_load_conservation_879  -1
    load_0_6_7  segment_prefix_lb_880  1
    load_0_6_7  segment_prefix_ub_881  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_9  arc_capacity_554  -30
    arc_0_6_9  connected_order_arc_555  -16
    arc_0_6_9  out_degree_868  1
    arc_0_6_9  in_degree_883  1
    arc_0_6_9  original_T_including_depot_unload_936  1.8739441025189553e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_9  arc_capacity_554  1
    load_0_6_9  segment_load_conservation_872  1
    load_0_6_9  free_load_conservation_887  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_10  arc_capacity_556  -30
    arc_0_6_10  connected_order_arc_557  -16
    arc_0_6_10  out_degree_868  1
    arc_0_6_10  in_degree_889  1
    arc_0_6_10  original_T_including_depot_unload_936  1.8467456333549035e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_10  arc_capacity_556  1
    load_0_6_10  segment_load_conservation_872  1
    load_0_6_10  free_load_conservation_893  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_11  arc_capacity_558  -30
    arc_0_6_11  connected_order_arc_559  -16
    arc_0_6_11  out_degree_868  1
    arc_0_6_11  in_degree_895  1
    arc_0_6_11  original_T_including_depot_unload_936  2.7910579461472848e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_11  arc_capacity_558  1
    load_0_6_11  segment_load_conservation_872  1
    load_0_6_11  free_load_conservation_899  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_12  arc_capacity_560  -30
    arc_0_6_12  connected_order_arc_561  -16
    arc_0_6_12  out_degree_868  1
    arc_0_6_12  in_degree_901  1
    arc_0_6_12  original_T_including_depot_unload_936  2.3958340327791907e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_12  arc_capacity_560  1
    load_0_6_12  segment_load_conservation_872  1
    load_0_6_12  free_load_conservation_905  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_13  arc_capacity_562  -30
    arc_0_6_13  connected_order_arc_563  -16
    arc_0_6_13  out_degree_868  1
    arc_0_6_13  in_degree_907  1
    arc_0_6_13  original_T_including_depot_unload_936  2.5598105628601829e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_13  arc_capacity_562  1
    load_0_6_13  segment_load_conservation_872  1
    load_0_6_13  free_load_conservation_911  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_14  arc_capacity_564  -30
    arc_0_6_14  connected_order_arc_565  -16
    arc_0_6_14  out_degree_868  1
    arc_0_6_14  in_degree_913  1
    arc_0_6_14  original_T_including_depot_unload_936  8.4376826601758887e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_14  arc_capacity_564  1
    load_0_6_14  segment_load_conservation_872  1
    load_0_6_14  free_load_conservation_917  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_15  arc_capacity_566  -30
    arc_0_6_15  connected_order_arc_567  -16
    arc_0_6_15  out_degree_868  1
    arc_0_6_15  in_degree_919  1
    arc_0_6_15  original_T_including_depot_unload_936  6.4057623819624155e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_15  arc_capacity_566  1
    load_0_6_15  segment_load_conservation_872  1
    load_0_6_15  free_load_conservation_923  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_16  arc_capacity_568  -30
    arc_0_6_16  connected_order_arc_569  -16
    arc_0_6_16  out_degree_868  1
    arc_0_6_16  in_degree_925  1
    arc_0_6_16  original_T_including_depot_unload_936  1.4810770279475858e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_16  arc_capacity_568  1
    load_0_6_16  segment_load_conservation_872  1
    load_0_6_16  free_load_conservation_929  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_0  arc_capacity_570  -30
    arc_0_7_0  depot_return_or_bypass_832  1
    arc_0_7_0  out_degree_875  1
    arc_0_7_0  original_T_including_depot_unload_936  4.1588440854375170e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_7_0  arc_capacity_570  1
    load_0_7_0  segment_load_conservation_879  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_1  arc_capacity_571  -30
    arc_0_7_1  connected_order_arc_572  -16
    arc_0_7_1  in_degree_834  1
    arc_0_7_1  out_degree_875  1
    arc_0_7_1  original_T_including_depot_unload_936  5.4626430531406254e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_7_1  arc_capacity_571  1
    load_0_7_1  segment_load_conservation_837  -1
    load_0_7_1  segment_prefix_lb_838  1
    load_0_7_1  segment_prefix_ub_839  1
    load_0_7_1  segment_load_conservation_879  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_2  arc_capacity_573  -30
    arc_0_7_2  connected_order_arc_574  -16
    arc_0_7_2  in_degree_841  1
    arc_0_7_2  out_degree_875  1
    arc_0_7_2  original_T_including_depot_unload_936  8.2210727717430609e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_7_2  arc_capacity_573  1
    load_0_7_2  segment_load_conservation_844  -1
    load_0_7_2  segment_prefix_lb_845  1
    load_0_7_2  segment_prefix_ub_846  1
    load_0_7_2  segment_load_conservation_879  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_3  arc_capacity_575  -30
    arc_0_7_3  connected_order_arc_576  -16
    arc_0_7_3  in_degree_848  1
    arc_0_7_3  out_degree_875  1
    arc_0_7_3  original_T_including_depot_unload_936  516.598297486096
    MARKER    'MARKER'                 'INTEND'
    load_0_7_3  arc_capacity_575  1
    load_0_7_3  segment_load_conservation_851  -1
    load_0_7_3  segment_prefix_lb_852  1
    load_0_7_3  segment_prefix_ub_853  1
    load_0_7_3  segment_load_conservation_879  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_4  arc_capacity_577  -30
    arc_0_7_4  connected_order_arc_578  -16
    arc_0_7_4  in_degree_855  1
    arc_0_7_4  out_degree_875  1
    arc_0_7_4  original_T_including_depot_unload_936  4.1180717113418365e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_7_4  arc_capacity_577  1
    load_0_7_4  segment_load_conservation_858  -1
    load_0_7_4  segment_prefix_lb_859  1
    load_0_7_4  segment_prefix_ub_860  1
    load_0_7_4  segment_load_conservation_879  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_5  arc_capacity_579  -30
    arc_0_7_5  connected_order_arc_580  -16
    arc_0_7_5  in_degree_862  1
    arc_0_7_5  out_degree_875  1
    arc_0_7_5  original_T_including_depot_unload_936  3.4593676445964553e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_7_5  arc_capacity_579  1
    load_0_7_5  segment_load_conservation_865  -1
    load_0_7_5  segment_prefix_lb_866  1
    load_0_7_5  segment_prefix_ub_867  1
    load_0_7_5  segment_load_conservation_879  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_6  arc_capacity_581  -30
    arc_0_7_6  connected_order_arc_582  -16
    arc_0_7_6  in_degree_869  1
    arc_0_7_6  out_degree_875  1
    arc_0_7_6  original_T_including_depot_unload_936  2.2661537412294956e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_7_6  arc_capacity_581  1
    load_0_7_6  segment_load_conservation_872  -1
    load_0_7_6  segment_prefix_lb_873  1
    load_0_7_6  segment_prefix_ub_874  1
    load_0_7_6  segment_load_conservation_879  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_9  arc_capacity_583  -30
    arc_0_7_9  connected_order_arc_584  -16
    arc_0_7_9  out_degree_875  1
    arc_0_7_9  in_degree_883  1
    arc_0_7_9  original_T_including_depot_unload_936  1.9425880448191174e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_7_9  arc_capacity_583  1
    load_0_7_9  segment_load_conservation_879  1
    load_0_7_9  free_load_conservation_887  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_10  arc_capacity_585  -30
    arc_0_7_10  connected_order_arc_586  -16
    arc_0_7_10  out_degree_875  1
    arc_0_7_10  in_degree_889  1
    arc_0_7_10  original_T_including_depot_unload_936  1.9007789738787540e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_7_10  arc_capacity_585  1
    load_0_7_10  segment_load_conservation_879  1
    load_0_7_10  free_load_conservation_893  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_11  arc_capacity_587  -30
    arc_0_7_11  connected_order_arc_588  -16
    arc_0_7_11  out_degree_875  1
    arc_0_7_11  in_degree_895  1
    arc_0_7_11  original_T_including_depot_unload_936  2.5651522766561479e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_7_11  arc_capacity_587  1
    load_0_7_11  segment_load_conservation_879  1
    load_0_7_11  free_load_conservation_899  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_12  arc_capacity_589  -30
    arc_0_7_12  connected_order_arc_590  -16
    arc_0_7_12  out_degree_875  1
    arc_0_7_12  in_degree_901  1
    arc_0_7_12  original_T_including_depot_unload_936  2.4543912353372671e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_7_12  arc_capacity_589  1
    load_0_7_12  segment_load_conservation_879  1
    load_0_7_12  free_load_conservation_905  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_13  arc_capacity_591  -30
    arc_0_7_13  connected_order_arc_592  -16
    arc_0_7_13  out_degree_875  1
    arc_0_7_13  in_degree_907  1
    arc_0_7_13  original_T_including_depot_unload_936  2.4295946549751052e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_7_13  arc_capacity_591  1
    load_0_7_13  segment_load_conservation_879  1
    load_0_7_13  free_load_conservation_911  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_14  arc_capacity_593  -30
    arc_0_7_14  connected_order_arc_594  -16
    arc_0_7_14  out_degree_875  1
    arc_0_7_14  in_degree_913  1
    arc_0_7_14  original_T_including_depot_unload_936  7.2365484333226220e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_7_14  arc_capacity_593  1
    load_0_7_14  segment_load_conservation_879  1
    load_0_7_14  free_load_conservation_917  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_15  arc_capacity_595  -30
    arc_0_7_15  connected_order_arc_596  -16
    arc_0_7_15  out_degree_875  1
    arc_0_7_15  in_degree_919  1
    arc_0_7_15  original_T_including_depot_unload_936  7.3627521985972965e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_7_15  arc_capacity_595  1
    load_0_7_15  segment_load_conservation_879  1
    load_0_7_15  free_load_conservation_923  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_16  arc_capacity_597  -30
    arc_0_7_16  connected_order_arc_598  -16
    arc_0_7_16  out_degree_875  1
    arc_0_7_16  in_degree_925  1
    arc_0_7_16  original_T_including_depot_unload_936  2.6178398366762252e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_7_16  arc_capacity_597  1
    load_0_7_16  segment_load_conservation_879  1
    load_0_7_16  free_load_conservation_929  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_0  arc_capacity_599  -30
    arc_0_9_0  depot_return_or_bypass_832  1
    arc_0_9_0  out_degree_882  1
    arc_0_9_0  original_T_including_depot_unload_936  1.8065333212349267e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_0  arc_capacity_599  1
    load_0_9_0  free_load_conservation_887  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_1  arc_capacity_600  -30
    arc_0_9_1  connected_order_arc_601  -16
    arc_0_9_1  in_degree_834  1
    arc_0_9_1  out_degree_882  1
    arc_0_9_1  original_T_including_depot_unload_936  2.0021738809925773e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_1  arc_capacity_600  1
    load_0_9_1  segment_load_conservation_837  -1
    load_0_9_1  segment_prefix_lb_838  1
    load_0_9_1  segment_prefix_ub_839  1
    load_0_9_1  free_load_conservation_887  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_2  arc_capacity_602  -30
    arc_0_9_2  connected_order_arc_603  -16
    arc_0_9_2  in_degree_841  1
    arc_0_9_2  out_degree_882  1
    arc_0_9_2  original_T_including_depot_unload_936  2.1556817566230284e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_2  arc_capacity_602  1
    load_0_9_2  segment_load_conservation_844  -1
    load_0_9_2  segment_prefix_lb_845  1
    load_0_9_2  segment_prefix_ub_846  1
    load_0_9_2  free_load_conservation_887  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_3  arc_capacity_604  -30
    arc_0_9_3  connected_order_arc_605  -16
    arc_0_9_3  in_degree_848  1
    arc_0_9_3  out_degree_882  1
    arc_0_9_3  original_T_including_depot_unload_936  2.2507610939146793e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_3  arc_capacity_604  1
    load_0_9_3  segment_load_conservation_851  -1
    load_0_9_3  segment_prefix_lb_852  1
    load_0_9_3  segment_prefix_ub_853  1
    load_0_9_3  free_load_conservation_887  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_4  arc_capacity_606  -30
    arc_0_9_4  connected_order_arc_607  -16
    arc_0_9_4  in_degree_855  1
    arc_0_9_4  out_degree_882  1
    arc_0_9_4  original_T_including_depot_unload_936  2.0979901720969542e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_4  arc_capacity_606  1
    load_0_9_4  segment_load_conservation_858  -1
    load_0_9_4  segment_prefix_lb_859  1
    load_0_9_4  segment_prefix_ub_860  1
    load_0_9_4  free_load_conservation_887  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_5  arc_capacity_608  -30
    arc_0_9_5  connected_order_arc_609  -16
    arc_0_9_5  in_degree_862  1
    arc_0_9_5  out_degree_882  1
    arc_0_9_5  original_T_including_depot_unload_936  1.9740618091449423e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_5  arc_capacity_608  1
    load_0_9_5  segment_load_conservation_865  -1
    load_0_9_5  segment_prefix_lb_866  1
    load_0_9_5  segment_prefix_ub_867  1
    load_0_9_5  free_load_conservation_887  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_6  arc_capacity_610  -30
    arc_0_9_6  connected_order_arc_611  -16
    arc_0_9_6  in_degree_869  1
    arc_0_9_6  out_degree_882  1
    arc_0_9_6  original_T_including_depot_unload_936  1.8739441025189553e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_6  arc_capacity_610  1
    load_0_9_6  segment_load_conservation_872  -1
    load_0_9_6  segment_prefix_lb_873  1
    load_0_9_6  segment_prefix_ub_874  1
    load_0_9_6  free_load_conservation_887  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_7  arc_capacity_612  -30
    arc_0_9_7  connected_order_arc_613  -16
    arc_0_9_7  in_degree_876  1
    arc_0_9_7  out_degree_882  1
    arc_0_9_7  original_T_including_depot_unload_936  1.9425880448191174e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_7  arc_capacity_612  1
    load_0_9_7  segment_load_conservation_879  -1
    load_0_9_7  segment_prefix_lb_880  1
    load_0_9_7  segment_prefix_ub_881  1
    load_0_9_7  free_load_conservation_887  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_10  arc_capacity_614  -30
    arc_0_9_10  connected_order_arc_615  -16
    arc_0_9_10  out_degree_882  1
    arc_0_9_10  in_degree_889  1
    arc_0_9_10  original_T_including_depot_unload_936  1.3126251897454844e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_10  arc_capacity_614  1
    load_0_9_10  free_load_conservation_887  1
    load_0_9_10  free_load_conservation_893  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_11  arc_capacity_616  -30
    arc_0_9_11  connected_order_arc_617  -16
    arc_0_9_11  out_degree_882  1
    arc_0_9_11  in_degree_895  1
    arc_0_9_11  original_T_including_depot_unload_936  3.8283958278492823e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_11  arc_capacity_616  1
    load_0_9_11  free_load_conservation_887  1
    load_0_9_11  free_load_conservation_899  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_12  arc_capacity_618  -30
    arc_0_9_12  connected_order_arc_619  -16
    arc_0_9_12  out_degree_882  1
    arc_0_9_12  in_degree_901  1
    arc_0_9_12  original_T_including_depot_unload_936  5.2703432304351884e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_12  arc_capacity_618  1
    load_0_9_12  free_load_conservation_887  1
    load_0_9_12  free_load_conservation_905  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_13  arc_capacity_620  -30
    arc_0_9_13  connected_order_arc_621  -16
    arc_0_9_13  out_degree_882  1
    arc_0_9_13  in_degree_907  1
    arc_0_9_13  original_T_including_depot_unload_936  2.0239755898835604e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_13  arc_capacity_620  1
    load_0_9_13  free_load_conservation_887  1
    load_0_9_13  free_load_conservation_911  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_14  arc_capacity_622  -30
    arc_0_9_14  connected_order_arc_623  -16
    arc_0_9_14  out_degree_882  1
    arc_0_9_14  in_degree_913  1
    arc_0_9_14  original_T_including_depot_unload_936  1.5255932363401953e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_14  arc_capacity_622  1
    load_0_9_14  free_load_conservation_887  1
    load_0_9_14  free_load_conservation_917  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_15  arc_capacity_624  -30
    arc_0_9_15  connected_order_arc_625  -16
    arc_0_9_15  out_degree_882  1
    arc_0_9_15  in_degree_919  1
    arc_0_9_15  original_T_including_depot_unload_936  2.4478438645146789e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_15  arc_capacity_624  1
    load_0_9_15  free_load_conservation_887  1
    load_0_9_15  free_load_conservation_923  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_16  arc_capacity_626  -30
    arc_0_9_16  connected_order_arc_627  -16
    arc_0_9_16  out_degree_882  1
    arc_0_9_16  in_degree_925  1
    arc_0_9_16  original_T_including_depot_unload_936  1.7340603255343296e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_16  arc_capacity_626  1
    load_0_9_16  free_load_conservation_887  1
    load_0_9_16  free_load_conservation_929  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_0  arc_capacity_628  -30
    arc_0_10_0  depot_return_or_bypass_832  1
    arc_0_10_0  out_degree_888  1
    arc_0_10_0  original_T_including_depot_unload_936  1739.61165920636
    MARKER    'MARKER'                 'INTEND'
    load_0_10_0  arc_capacity_628  1
    load_0_10_0  free_load_conservation_893  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_1  arc_capacity_629  -30
    arc_0_10_1  connected_order_arc_630  -16
    arc_0_10_1  in_degree_834  1
    arc_0_10_1  out_degree_888  1
    arc_0_10_1  original_T_including_depot_unload_936  1.9959569014367933e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_1  arc_capacity_629  1
    load_0_10_1  segment_load_conservation_837  -1
    load_0_10_1  segment_prefix_lb_838  1
    load_0_10_1  segment_prefix_ub_839  1
    load_0_10_1  free_load_conservation_893  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_2  arc_capacity_631  -30
    arc_0_10_2  connected_order_arc_632  -16
    arc_0_10_2  in_degree_841  1
    arc_0_10_2  out_degree_888  1
    arc_0_10_2  original_T_including_depot_unload_936  2.1641391312462424e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_2  arc_capacity_631  1
    load_0_10_2  segment_load_conservation_844  -1
    load_0_10_2  segment_prefix_lb_845  1
    load_0_10_2  segment_prefix_ub_846  1
    load_0_10_2  free_load_conservation_893  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_3  arc_capacity_633  -30
    arc_0_10_3  connected_order_arc_634  -16
    arc_0_10_3  in_degree_848  1
    arc_0_10_3  out_degree_888  1
    arc_0_10_3  original_T_including_depot_unload_936  2.2339035809798856e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_3  arc_capacity_633  1
    load_0_10_3  segment_load_conservation_851  -1
    load_0_10_3  segment_prefix_lb_852  1
    load_0_10_3  segment_prefix_ub_853  1
    load_0_10_3  free_load_conservation_893  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_4  arc_capacity_635  -30
    arc_0_10_4  connected_order_arc_636  -16
    arc_0_10_4  in_degree_855  1
    arc_0_10_4  out_degree_888  1
    arc_0_10_4  original_T_including_depot_unload_936  2.0801782775431307e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_4  arc_capacity_635  1
    load_0_10_4  segment_load_conservation_858  -1
    load_0_10_4  segment_prefix_lb_859  1
    load_0_10_4  segment_prefix_ub_860  1
    load_0_10_4  free_load_conservation_893  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_5  arc_capacity_637  -30
    arc_0_10_5  connected_order_arc_638  -16
    arc_0_10_5  in_degree_862  1
    arc_0_10_5  out_degree_888  1
    arc_0_10_5  original_T_including_depot_unload_936  1.9548039027038737e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_5  arc_capacity_637  1
    load_0_10_5  segment_load_conservation_865  -1
    load_0_10_5  segment_prefix_lb_866  1
    load_0_10_5  segment_prefix_ub_867  1
    load_0_10_5  free_load_conservation_893  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_6  arc_capacity_639  -30
    arc_0_10_6  connected_order_arc_640  -16
    arc_0_10_6  in_degree_869  1
    arc_0_10_6  out_degree_888  1
    arc_0_10_6  original_T_including_depot_unload_936  1.8467456333549035e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_6  arc_capacity_639  1
    load_0_10_6  segment_load_conservation_872  -1
    load_0_10_6  segment_prefix_lb_873  1
    load_0_10_6  segment_prefix_ub_874  1
    load_0_10_6  free_load_conservation_893  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_7  arc_capacity_641  -30
    arc_0_10_7  connected_order_arc_642  -16
    arc_0_10_7  in_degree_876  1
    arc_0_10_7  out_degree_888  1
    arc_0_10_7  original_T_including_depot_unload_936  1.9007789738787540e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_7  arc_capacity_641  1
    load_0_10_7  segment_load_conservation_879  -1
    load_0_10_7  segment_prefix_lb_880  1
    load_0_10_7  segment_prefix_ub_881  1
    load_0_10_7  free_load_conservation_893  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_9  arc_capacity_643  -30
    arc_0_10_9  connected_order_arc_644  -16
    arc_0_10_9  in_degree_883  1
    arc_0_10_9  out_degree_888  1
    arc_0_10_9  original_T_including_depot_unload_936  1.3126251897454844e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_10_9  arc_capacity_643  1
    load_0_10_9  free_load_conservation_887  -1
    load_0_10_9  free_load_conservation_893  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_11  arc_capacity_645  -30
    arc_0_10_11  connected_order_arc_646  -16
    arc_0_10_11  out_degree_888  1
    arc_0_10_11  in_degree_895  1
    arc_0_10_11  original_T_including_depot_unload_936  3.7182308190042463e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_11  arc_capacity_645  1
    load_0_10_11  free_load_conservation_893  1
    load_0_10_11  free_load_conservation_899  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_12  arc_capacity_647  -30
    arc_0_10_12  connected_order_arc_648  -16
    arc_0_10_12  out_degree_888  1
    arc_0_10_12  in_degree_901  1
    arc_0_10_12  original_T_including_depot_unload_936  5.5382752177930990e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_10_12  arc_capacity_647  1
    load_0_10_12  free_load_conservation_893  1
    load_0_10_12  free_load_conservation_905  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_13  arc_capacity_649  -30
    arc_0_10_13  connected_order_arc_650  -16
    arc_0_10_13  out_degree_888  1
    arc_0_10_13  in_degree_907  1
    arc_0_10_13  original_T_including_depot_unload_936  1.8934642770867222e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_13  arc_capacity_649  1
    load_0_10_13  free_load_conservation_893  1
    load_0_10_13  free_load_conservation_911  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_14  arc_capacity_651  -30
    arc_0_10_14  connected_order_arc_652  -16
    arc_0_10_14  out_degree_888  1
    arc_0_10_14  in_degree_913  1
    arc_0_10_14  original_T_including_depot_unload_936  1.4443513852547251e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_14  arc_capacity_651  1
    load_0_10_14  free_load_conservation_893  1
    load_0_10_14  free_load_conservation_917  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_15  arc_capacity_653  -30
    arc_0_10_15  connected_order_arc_654  -16
    arc_0_10_15  out_degree_888  1
    arc_0_10_15  in_degree_919  1
    arc_0_10_15  original_T_including_depot_unload_936  2.4369093744670904e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_15  arc_capacity_653  1
    load_0_10_15  free_load_conservation_893  1
    load_0_10_15  free_load_conservation_923  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_16  arc_capacity_655  -30
    arc_0_10_16  connected_order_arc_656  -16
    arc_0_10_16  out_degree_888  1
    arc_0_10_16  in_degree_925  1
    arc_0_10_16  original_T_including_depot_unload_936  1.7037372759708057e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_16  arc_capacity_655  1
    load_0_10_16  free_load_conservation_893  1
    load_0_10_16  free_load_conservation_929  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_0  arc_capacity_657  -30
    arc_0_11_0  depot_return_or_bypass_832  1
    arc_0_11_0  out_degree_894  1
    arc_0_11_0  original_T_including_depot_unload_936  2.3234267380118886e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_0  arc_capacity_657  1
    load_0_11_0  free_load_conservation_899  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_1  arc_capacity_658  -30
    arc_0_11_1  connected_order_arc_659  -16
    arc_0_11_1  in_degree_834  1
    arc_0_11_1  out_degree_894  1
    arc_0_11_1  original_T_including_depot_unload_936  3.0726580305165480e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_1  arc_capacity_658  1
    load_0_11_1  segment_load_conservation_837  -1
    load_0_11_1  segment_prefix_lb_838  1
    load_0_11_1  segment_prefix_ub_839  1
    load_0_11_1  free_load_conservation_899  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_2  arc_capacity_660  -30
    arc_0_11_2  connected_order_arc_661  -16
    arc_0_11_2  in_degree_841  1
    arc_0_11_2  out_degree_894  1
    arc_0_11_2  original_T_including_depot_unload_936  3.3076115257178203e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_2  arc_capacity_660  1
    load_0_11_2  segment_load_conservation_844  -1
    load_0_11_2  segment_prefix_lb_845  1
    load_0_11_2  segment_prefix_ub_846  1
    load_0_11_2  free_load_conservation_899  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_3  arc_capacity_662  -30
    arc_0_11_3  connected_order_arc_663  -16
    arc_0_11_3  in_degree_848  1
    arc_0_11_3  out_degree_894  1
    arc_0_11_3  original_T_including_depot_unload_936  2.8839695646198670e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_3  arc_capacity_662  1
    load_0_11_3  segment_load_conservation_851  -1
    load_0_11_3  segment_prefix_lb_852  1
    load_0_11_3  segment_prefix_ub_853  1
    load_0_11_3  free_load_conservation_899  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_4  arc_capacity_664  -30
    arc_0_11_4  connected_order_arc_665  -16
    arc_0_11_4  in_degree_855  1
    arc_0_11_4  out_degree_894  1
    arc_0_11_4  original_T_including_depot_unload_936  2.8834086639088187e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_4  arc_capacity_664  1
    load_0_11_4  segment_load_conservation_858  -1
    load_0_11_4  segment_prefix_lb_859  1
    load_0_11_4  segment_prefix_ub_860  1
    load_0_11_4  free_load_conservation_899  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_5  arc_capacity_666  -30
    arc_0_11_5  connected_order_arc_667  -16
    arc_0_11_5  in_degree_862  1
    arc_0_11_5  out_degree_894  1
    arc_0_11_5  original_T_including_depot_unload_936  2.8807002034504962e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_5  arc_capacity_666  1
    load_0_11_5  segment_load_conservation_865  -1
    load_0_11_5  segment_prefix_lb_866  1
    load_0_11_5  segment_prefix_ub_867  1
    load_0_11_5  free_load_conservation_899  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_6  arc_capacity_668  -30
    arc_0_11_6  connected_order_arc_669  -16
    arc_0_11_6  in_degree_869  1
    arc_0_11_6  out_degree_894  1
    arc_0_11_6  original_T_including_depot_unload_936  2.7910579461472848e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_6  arc_capacity_668  1
    load_0_11_6  segment_load_conservation_872  -1
    load_0_11_6  segment_prefix_lb_873  1
    load_0_11_6  segment_prefix_ub_874  1
    load_0_11_6  free_load_conservation_899  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_7  arc_capacity_670  -30
    arc_0_11_7  connected_order_arc_671  -16
    arc_0_11_7  in_degree_876  1
    arc_0_11_7  out_degree_894  1
    arc_0_11_7  original_T_including_depot_unload_936  2.5651522766561479e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_7  arc_capacity_670  1
    load_0_11_7  segment_load_conservation_879  -1
    load_0_11_7  segment_prefix_lb_880  1
    load_0_11_7  segment_prefix_ub_881  1
    load_0_11_7  free_load_conservation_899  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_9  arc_capacity_672  -30
    arc_0_11_9  connected_order_arc_673  -16
    arc_0_11_9  in_degree_883  1
    arc_0_11_9  out_degree_894  1
    arc_0_11_9  original_T_including_depot_unload_936  3.8283958278492823e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_9  arc_capacity_672  1
    load_0_11_9  free_load_conservation_887  -1
    load_0_11_9  free_load_conservation_899  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_10  arc_capacity_674  -30
    arc_0_11_10  connected_order_arc_675  -16
    arc_0_11_10  in_degree_889  1
    arc_0_11_10  out_degree_894  1
    arc_0_11_10  original_T_including_depot_unload_936  3.7182308190042463e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_10  arc_capacity_674  1
    load_0_11_10  free_load_conservation_893  -1
    load_0_11_10  free_load_conservation_899  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_12  arc_capacity_676  -30
    arc_0_11_12  connected_order_arc_677  -16
    arc_0_11_12  out_degree_894  1
    arc_0_11_12  in_degree_901  1
    arc_0_11_12  original_T_including_depot_unload_936  4.1686506413165080e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_12  arc_capacity_676  1
    load_0_11_12  free_load_conservation_899  1
    load_0_11_12  free_load_conservation_905  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_13  arc_capacity_678  -30
    arc_0_11_13  connected_order_arc_679  -16
    arc_0_11_13  out_degree_894  1
    arc_0_11_13  in_degree_907  1
    arc_0_11_13  original_T_including_depot_unload_936  2.5683172431027456e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_13  arc_capacity_678  1
    load_0_11_13  free_load_conservation_899  1
    load_0_11_13  free_load_conservation_911  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_14  arc_capacity_680  -30
    arc_0_11_14  connected_order_arc_681  -16
    arc_0_11_14  out_degree_894  1
    arc_0_11_14  in_degree_913  1
    arc_0_11_14  original_T_including_depot_unload_936  2.4160844235310037e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_14  arc_capacity_680  1
    load_0_11_14  free_load_conservation_899  1
    load_0_11_14  free_load_conservation_917  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_15  arc_capacity_682  -30
    arc_0_11_15  connected_order_arc_683  -16
    arc_0_11_15  out_degree_894  1
    arc_0_11_15  in_degree_919  1
    arc_0_11_15  original_T_including_depot_unload_936  2.9878665461125843e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_15  arc_capacity_682  1
    load_0_11_15  free_load_conservation_899  1
    load_0_11_15  free_load_conservation_923  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_16  arc_capacity_684  -30
    arc_0_11_16  connected_order_arc_685  -16
    arc_0_11_16  out_degree_894  1
    arc_0_11_16  in_degree_925  1
    arc_0_11_16  original_T_including_depot_unload_936  2.7957126389480295e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_16  arc_capacity_684  1
    load_0_11_16  free_load_conservation_899  1
    load_0_11_16  free_load_conservation_929  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_0  arc_capacity_686  -30
    arc_0_12_0  depot_return_or_bypass_832  1
    arc_0_12_0  out_degree_900  1
    arc_0_12_0  original_T_including_depot_unload_936  2.2866763971369810e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_0  arc_capacity_686  1
    load_0_12_0  free_load_conservation_905  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_1  arc_capacity_687  -30
    arc_0_12_1  connected_order_arc_688  -16
    arc_0_12_1  in_degree_834  1
    arc_0_12_1  out_degree_900  1
    arc_0_12_1  original_T_including_depot_unload_936  2.5292035468949002e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_1  arc_capacity_687  1
    load_0_12_1  segment_load_conservation_837  -1
    load_0_12_1  segment_prefix_lb_838  1
    load_0_12_1  segment_prefix_ub_839  1
    load_0_12_1  free_load_conservation_905  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_2  arc_capacity_689  -30
    arc_0_12_2  connected_order_arc_690  -16
    arc_0_12_2  in_degree_841  1
    arc_0_12_2  out_degree_900  1
    arc_0_12_2  original_T_including_depot_unload_936  2.6797194604092651e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_2  arc_capacity_689  1
    load_0_12_2  segment_load_conservation_844  -1
    load_0_12_2  segment_prefix_lb_845  1
    load_0_12_2  segment_prefix_ub_846  1
    load_0_12_2  free_load_conservation_905  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_3  arc_capacity_691  -30
    arc_0_12_3  connected_order_arc_692  -16
    arc_0_12_3  in_degree_848  1
    arc_0_12_3  out_degree_900  1
    arc_0_12_3  original_T_including_depot_unload_936  2.7766616410403444e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_3  arc_capacity_691  1
    load_0_12_3  segment_load_conservation_851  -1
    load_0_12_3  segment_prefix_lb_852  1
    load_0_12_3  segment_prefix_ub_853  1
    load_0_12_3  free_load_conservation_905  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_4  arc_capacity_693  -30
    arc_0_12_4  connected_order_arc_694  -16
    arc_0_12_4  in_degree_855  1
    arc_0_12_4  out_degree_900  1
    arc_0_12_4  original_T_including_depot_unload_936  2.6235983504802839e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_4  arc_capacity_693  1
    load_0_12_4  segment_load_conservation_858  -1
    load_0_12_4  segment_prefix_lb_859  1
    load_0_12_4  segment_prefix_ub_860  1
    load_0_12_4  free_load_conservation_905  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_5  arc_capacity_695  -30
    arc_0_12_5  connected_order_arc_696  -16
    arc_0_12_5  in_degree_862  1
    arc_0_12_5  out_degree_900  1
    arc_0_12_5  original_T_including_depot_unload_936  2.4992063774241742e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_5  arc_capacity_695  1
    load_0_12_5  segment_load_conservation_865  -1
    load_0_12_5  segment_prefix_lb_866  1
    load_0_12_5  segment_prefix_ub_867  1
    load_0_12_5  free_load_conservation_905  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_6  arc_capacity_697  -30
    arc_0_12_6  connected_order_arc_698  -16
    arc_0_12_6  in_degree_869  1
    arc_0_12_6  out_degree_900  1
    arc_0_12_6  original_T_including_depot_unload_936  2.3958340327791907e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_6  arc_capacity_697  1
    load_0_12_6  segment_load_conservation_872  -1
    load_0_12_6  segment_prefix_lb_873  1
    load_0_12_6  segment_prefix_ub_874  1
    load_0_12_6  free_load_conservation_905  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_7  arc_capacity_699  -30
    arc_0_12_7  connected_order_arc_700  -16
    arc_0_12_7  in_degree_876  1
    arc_0_12_7  out_degree_900  1
    arc_0_12_7  original_T_including_depot_unload_936  2.4543912353372671e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_7  arc_capacity_699  1
    load_0_12_7  segment_load_conservation_879  -1
    load_0_12_7  segment_prefix_lb_880  1
    load_0_12_7  segment_prefix_ub_881  1
    load_0_12_7  free_load_conservation_905  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_9  arc_capacity_701  -30
    arc_0_12_9  connected_order_arc_702  -16
    arc_0_12_9  in_degree_883  1
    arc_0_12_9  out_degree_900  1
    arc_0_12_9  original_T_including_depot_unload_936  5.2703432304351884e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_9  arc_capacity_701  1
    load_0_12_9  free_load_conservation_887  -1
    load_0_12_9  free_load_conservation_905  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_10  arc_capacity_703  -30
    arc_0_12_10  connected_order_arc_704  -16
    arc_0_12_10  in_degree_889  1
    arc_0_12_10  out_degree_900  1
    arc_0_12_10  original_T_including_depot_unload_936  5.5382752177930990e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_10  arc_capacity_703  1
    load_0_12_10  free_load_conservation_893  -1
    load_0_12_10  free_load_conservation_905  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_11  arc_capacity_705  -30
    arc_0_12_11  connected_order_arc_706  -16
    arc_0_12_11  in_degree_895  1
    arc_0_12_11  out_degree_900  1
    arc_0_12_11  original_T_including_depot_unload_936  4.1686506413165080e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_11  arc_capacity_705  1
    load_0_12_11  free_load_conservation_899  -1
    load_0_12_11  free_load_conservation_905  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_13  arc_capacity_707  -30
    arc_0_12_13  connected_order_arc_708  -16
    arc_0_12_13  out_degree_900  1
    arc_0_12_13  in_degree_907  1
    arc_0_12_13  original_T_including_depot_unload_936  2.0819438297758261e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_13  arc_capacity_707  1
    load_0_12_13  free_load_conservation_905  1
    load_0_12_13  free_load_conservation_911  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_14  arc_capacity_709  -30
    arc_0_12_14  connected_order_arc_710  -16
    arc_0_12_14  out_degree_900  1
    arc_0_12_14  in_degree_913  1
    arc_0_12_14  original_T_including_depot_unload_936  1.9791430726365086e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_14  arc_capacity_709  1
    load_0_12_14  free_load_conservation_905  1
    load_0_12_14  free_load_conservation_917  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_15  arc_capacity_711  -30
    arc_0_12_15  connected_order_arc_712  -16
    arc_0_12_15  out_degree_900  1
    arc_0_12_15  in_degree_919  1
    arc_0_12_15  original_T_including_depot_unload_936  2.9747397208089205e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_15  arc_capacity_711  1
    load_0_12_15  free_load_conservation_905  1
    load_0_12_15  free_load_conservation_923  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_16  arc_capacity_713  -30
    arc_0_12_16  connected_order_arc_714  -16
    arc_0_12_16  out_degree_900  1
    arc_0_12_16  in_degree_925  1
    arc_0_12_16  original_T_including_depot_unload_936  2.2541698308553673e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_16  arc_capacity_713  1
    load_0_12_16  free_load_conservation_905  1
    load_0_12_16  free_load_conservation_929  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_0  arc_capacity_715  -30
    arc_0_13_0  depot_return_or_bypass_832  1
    arc_0_13_0  out_degree_906  1
    arc_0_13_0  original_T_including_depot_unload_936  2.0232971184291544e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_0  arc_capacity_715  1
    load_0_13_0  free_load_conservation_911  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_1  arc_capacity_716  -30
    arc_0_13_1  connected_order_arc_717  -16
    arc_0_13_1  in_degree_834  1
    arc_0_13_1  out_degree_906  1
    arc_0_13_1  original_T_including_depot_unload_936  2.8800138602390562e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_1  arc_capacity_716  1
    load_0_13_1  segment_load_conservation_837  -1
    load_0_13_1  segment_prefix_lb_838  1
    load_0_13_1  segment_prefix_ub_839  1
    load_0_13_1  free_load_conservation_911  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_2  arc_capacity_718  -30
    arc_0_13_2  connected_order_arc_719  -16
    arc_0_13_2  in_degree_841  1
    arc_0_13_2  out_degree_906  1
    arc_0_13_2  original_T_including_depot_unload_936  3.1528795137337825e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_2  arc_capacity_718  1
    load_0_13_2  segment_load_conservation_844  -1
    load_0_13_2  segment_prefix_lb_845  1
    load_0_13_2  segment_prefix_ub_846  1
    load_0_13_2  free_load_conservation_911  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_3  arc_capacity_720  -30
    arc_0_13_3  connected_order_arc_721  -16
    arc_0_13_3  in_degree_848  1
    arc_0_13_3  out_degree_906  1
    arc_0_13_3  original_T_including_depot_unload_936  2.9442201339702592e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_3  arc_capacity_720  1
    load_0_13_3  segment_load_conservation_851  -1
    load_0_13_3  segment_prefix_lb_852  1
    load_0_13_3  segment_prefix_ub_853  1
    load_0_13_3  free_load_conservation_911  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_4  arc_capacity_722  -30
    arc_0_13_4  connected_order_arc_723  -16
    arc_0_13_4  in_degree_855  1
    arc_0_13_4  out_degree_906  1
    arc_0_13_4  original_T_including_depot_unload_936  2820.94140713384
    MARKER    'MARKER'                 'INTEND'
    load_0_13_4  arc_capacity_722  1
    load_0_13_4  segment_load_conservation_858  -1
    load_0_13_4  segment_prefix_lb_859  1
    load_0_13_4  segment_prefix_ub_860  1
    load_0_13_4  free_load_conservation_911  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_5  arc_capacity_724  -30
    arc_0_13_5  connected_order_arc_725  -16
    arc_0_13_5  in_degree_862  1
    arc_0_13_5  out_degree_906  1
    arc_0_13_5  original_T_including_depot_unload_936  2.7168118802834592e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_5  arc_capacity_724  1
    load_0_13_5  segment_load_conservation_865  -1
    load_0_13_5  segment_prefix_lb_866  1
    load_0_13_5  segment_prefix_ub_867  1
    load_0_13_5  free_load_conservation_911  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_6  arc_capacity_726  -30
    arc_0_13_6  connected_order_arc_727  -16
    arc_0_13_6  in_degree_869  1
    arc_0_13_6  out_degree_906  1
    arc_0_13_6  original_T_including_depot_unload_936  2.5598105628601829e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_6  arc_capacity_726  1
    load_0_13_6  segment_load_conservation_872  -1
    load_0_13_6  segment_prefix_lb_873  1
    load_0_13_6  segment_prefix_ub_874  1
    load_0_13_6  free_load_conservation_911  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_7  arc_capacity_728  -30
    arc_0_13_7  connected_order_arc_729  -16
    arc_0_13_7  in_degree_876  1
    arc_0_13_7  out_degree_906  1
    arc_0_13_7  original_T_including_depot_unload_936  2.4295946549751052e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_7  arc_capacity_728  1
    load_0_13_7  segment_load_conservation_879  -1
    load_0_13_7  segment_prefix_lb_880  1
    load_0_13_7  segment_prefix_ub_881  1
    load_0_13_7  free_load_conservation_911  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_9  arc_capacity_730  -30
    arc_0_13_9  connected_order_arc_731  -16
    arc_0_13_9  in_degree_883  1
    arc_0_13_9  out_degree_906  1
    arc_0_13_9  original_T_including_depot_unload_936  2.0239755898835604e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_9  arc_capacity_730  1
    load_0_13_9  free_load_conservation_887  -1
    load_0_13_9  free_load_conservation_911  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_10  arc_capacity_732  -30
    arc_0_13_10  connected_order_arc_733  -16
    arc_0_13_10  in_degree_889  1
    arc_0_13_10  out_degree_906  1
    arc_0_13_10  original_T_including_depot_unload_936  1.8934642770867222e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_10  arc_capacity_732  1
    load_0_13_10  free_load_conservation_893  -1
    load_0_13_10  free_load_conservation_911  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_11  arc_capacity_734  -30
    arc_0_13_11  connected_order_arc_735  -16
    arc_0_13_11  in_degree_895  1
    arc_0_13_11  out_degree_906  1
    arc_0_13_11  original_T_including_depot_unload_936  2.5683172431027456e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_11  arc_capacity_734  1
    load_0_13_11  free_load_conservation_899  -1
    load_0_13_11  free_load_conservation_911  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_12  arc_capacity_736  -30
    arc_0_13_12  connected_order_arc_737  -16
    arc_0_13_12  in_degree_901  1
    arc_0_13_12  out_degree_906  1
    arc_0_13_12  original_T_including_depot_unload_936  2.0819438297758261e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_12  arc_capacity_736  1
    load_0_13_12  free_load_conservation_905  -1
    load_0_13_12  free_load_conservation_911  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_14  arc_capacity_738  -30
    arc_0_13_14  connected_order_arc_739  -16
    arc_0_13_14  out_degree_906  1
    arc_0_13_14  in_degree_913  1
    arc_0_13_14  original_T_including_depot_unload_936  1.7165475198920165e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_14  arc_capacity_738  1
    load_0_13_14  free_load_conservation_911  1
    load_0_13_14  free_load_conservation_917  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_15  arc_capacity_740  -30
    arc_0_13_15  connected_order_arc_741  -16
    arc_0_13_15  out_degree_906  1
    arc_0_13_15  in_degree_919  1
    arc_0_13_15  original_T_including_depot_unload_936  3.1658582590062310e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_15  arc_capacity_740  1
    load_0_13_15  free_load_conservation_911  1
    load_0_13_15  free_load_conservation_923  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_16  arc_capacity_742  -30
    arc_0_13_16  connected_order_arc_743  -16
    arc_0_13_16  out_degree_906  1
    arc_0_13_16  in_degree_925  1
    arc_0_13_16  original_T_including_depot_unload_936  2.4370949895474209e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_16  arc_capacity_742  1
    load_0_13_16  free_load_conservation_911  1
    load_0_13_16  free_load_conservation_929  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_0  arc_capacity_744  -30
    arc_0_14_0  depot_return_or_bypass_832  1
    arc_0_14_0  out_degree_912  1
    arc_0_14_0  original_T_including_depot_unload_936  3.5937232665424995e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_0  arc_capacity_744  1
    load_0_14_0  free_load_conservation_917  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_1  arc_capacity_745  -30
    arc_0_14_1  connected_order_arc_746  -16
    arc_0_14_1  in_degree_834  1
    arc_0_14_1  out_degree_912  1
    arc_0_14_1  original_T_including_depot_unload_936  1.1702148343313254e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_1  arc_capacity_745  1
    load_0_14_1  segment_load_conservation_837  -1
    load_0_14_1  segment_prefix_lb_838  1
    load_0_14_1  segment_prefix_ub_839  1
    load_0_14_1  free_load_conservation_917  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_2  arc_capacity_747  -30
    arc_0_14_2  connected_order_arc_748  -16
    arc_0_14_2  in_degree_841  1
    arc_0_14_2  out_degree_912  1
    arc_0_14_2  original_T_including_depot_unload_936  1.4485896981484648e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_2  arc_capacity_747  1
    load_0_14_2  segment_load_conservation_844  -1
    load_0_14_2  segment_prefix_lb_845  1
    load_0_14_2  segment_prefix_ub_846  1
    load_0_14_2  free_load_conservation_917  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_3  arc_capacity_749  -30
    arc_0_14_3  connected_order_arc_750  -16
    arc_0_14_3  in_degree_848  1
    arc_0_14_3  out_degree_912  1
    arc_0_14_3  original_T_including_depot_unload_936  1.2315777010885340e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_3  arc_capacity_749  1
    load_0_14_3  segment_load_conservation_851  -1
    load_0_14_3  segment_prefix_lb_852  1
    load_0_14_3  segment_prefix_ub_853  1
    load_0_14_3  free_load_conservation_917  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_4  arc_capacity_751  -30
    arc_0_14_4  connected_order_arc_752  -16
    arc_0_14_4  in_degree_855  1
    arc_0_14_4  out_degree_912  1
    arc_0_14_4  original_T_including_depot_unload_936  1.1046832181240914e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_4  arc_capacity_751  1
    load_0_14_4  segment_load_conservation_858  -1
    load_0_14_4  segment_prefix_lb_859  1
    load_0_14_4  segment_prefix_ub_860  1
    load_0_14_4  free_load_conservation_917  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_5  arc_capacity_753  -30
    arc_0_14_5  connected_order_arc_754  -16
    arc_0_14_5  in_degree_862  1
    arc_0_14_5  out_degree_912  1
    arc_0_14_5  original_T_including_depot_unload_936  1.0007616644945284e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_5  arc_capacity_753  1
    load_0_14_5  segment_load_conservation_865  -1
    load_0_14_5  segment_prefix_lb_866  1
    load_0_14_5  segment_prefix_ub_867  1
    load_0_14_5  free_load_conservation_917  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_6  arc_capacity_755  -30
    arc_0_14_6  connected_order_arc_756  -16
    arc_0_14_6  in_degree_869  1
    arc_0_14_6  out_degree_912  1
    arc_0_14_6  original_T_including_depot_unload_936  8.4376826601758887e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_6  arc_capacity_755  1
    load_0_14_6  segment_load_conservation_872  -1
    load_0_14_6  segment_prefix_lb_873  1
    load_0_14_6  segment_prefix_ub_874  1
    load_0_14_6  free_load_conservation_917  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_7  arc_capacity_757  -30
    arc_0_14_7  connected_order_arc_758  -16
    arc_0_14_7  in_degree_876  1
    arc_0_14_7  out_degree_912  1
    arc_0_14_7  original_T_including_depot_unload_936  7.2365484333226220e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_7  arc_capacity_757  1
    load_0_14_7  segment_load_conservation_879  -1
    load_0_14_7  segment_prefix_lb_880  1
    load_0_14_7  segment_prefix_ub_881  1
    load_0_14_7  free_load_conservation_917  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_9  arc_capacity_759  -30
    arc_0_14_9  connected_order_arc_760  -16
    arc_0_14_9  in_degree_883  1
    arc_0_14_9  out_degree_912  1
    arc_0_14_9  original_T_including_depot_unload_936  1.5255932363401953e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_9  arc_capacity_759  1
    load_0_14_9  free_load_conservation_887  -1
    load_0_14_9  free_load_conservation_917  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_10  arc_capacity_761  -30
    arc_0_14_10  connected_order_arc_762  -16
    arc_0_14_10  in_degree_889  1
    arc_0_14_10  out_degree_912  1
    arc_0_14_10  original_T_including_depot_unload_936  1.4443513852547251e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_10  arc_capacity_761  1
    load_0_14_10  free_load_conservation_893  -1
    load_0_14_10  free_load_conservation_917  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_11  arc_capacity_763  -30
    arc_0_14_11  connected_order_arc_764  -16
    arc_0_14_11  in_degree_895  1
    arc_0_14_11  out_degree_912  1
    arc_0_14_11  original_T_including_depot_unload_936  2.4160844235310037e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_11  arc_capacity_763  1
    load_0_14_11  free_load_conservation_899  -1
    load_0_14_11  free_load_conservation_917  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_12  arc_capacity_765  -30
    arc_0_14_12  connected_order_arc_766  -16
    arc_0_14_12  in_degree_901  1
    arc_0_14_12  out_degree_912  1
    arc_0_14_12  original_T_including_depot_unload_936  1.9791430726365086e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_12  arc_capacity_765  1
    load_0_14_12  free_load_conservation_905  -1
    load_0_14_12  free_load_conservation_917  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_13  arc_capacity_767  -30
    arc_0_14_13  connected_order_arc_768  -16
    arc_0_14_13  in_degree_907  1
    arc_0_14_13  out_degree_912  1
    arc_0_14_13  original_T_including_depot_unload_936  1.7165475198920165e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_13  arc_capacity_767  1
    load_0_14_13  free_load_conservation_911  -1
    load_0_14_13  free_load_conservation_917  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_15  arc_capacity_769  -30
    arc_0_14_15  connected_order_arc_770  -16
    arc_0_14_15  out_degree_912  1
    arc_0_14_15  in_degree_919  1
    arc_0_14_15  original_T_including_depot_unload_936  1.4558134627196880e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_15  arc_capacity_769  1
    load_0_14_15  free_load_conservation_917  1
    load_0_14_15  free_load_conservation_923  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_16  arc_capacity_771  -30
    arc_0_14_16  connected_order_arc_772  -16
    arc_0_14_16  out_degree_912  1
    arc_0_14_16  in_degree_925  1
    arc_0_14_16  original_T_including_depot_unload_936  7.2696582003770027e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_16  arc_capacity_771  1
    load_0_14_16  free_load_conservation_917  1
    load_0_14_16  free_load_conservation_929  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_0  arc_capacity_773  -30
    arc_0_15_0  depot_return_or_bypass_832  1
    arc_0_15_0  out_degree_918  1
    arc_0_15_0  original_T_including_depot_unload_936  1.1473865007565566e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_0  arc_capacity_773  1
    load_0_15_0  free_load_conservation_923  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_1  arc_capacity_774  -30
    arc_0_15_1  connected_order_arc_775  -16
    arc_0_15_1  in_degree_834  1
    arc_0_15_1  out_degree_918  1
    arc_0_15_1  original_T_including_depot_unload_936  4.5058965368847572e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_1  arc_capacity_774  1
    load_0_15_1  segment_load_conservation_837  -1
    load_0_15_1  segment_prefix_lb_838  1
    load_0_15_1  segment_prefix_ub_839  1
    load_0_15_1  free_load_conservation_923  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_2  arc_capacity_776  -30
    arc_0_15_2  connected_order_arc_777  -16
    arc_0_15_2  in_degree_841  1
    arc_0_15_2  out_degree_918  1
    arc_0_15_2  original_T_including_depot_unload_936  4.4158457011124148e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_2  arc_capacity_776  1
    load_0_15_2  segment_load_conservation_844  -1
    load_0_15_2  segment_prefix_lb_845  1
    load_0_15_2  segment_prefix_ub_846  1
    load_0_15_2  free_load_conservation_923  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_3  arc_capacity_778  -30
    arc_0_15_3  connected_order_arc_779  -16
    arc_0_15_3  in_degree_848  1
    arc_0_15_3  out_degree_918  1
    arc_0_15_3  original_T_including_depot_unload_936  2.2655310037545112e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_3  arc_capacity_778  1
    load_0_15_3  segment_load_conservation_851  -1
    load_0_15_3  segment_prefix_lb_852  1
    load_0_15_3  segment_prefix_ub_853  1
    load_0_15_3  free_load_conservation_923  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_4  arc_capacity_780  -30
    arc_0_15_4  connected_order_arc_781  -16
    arc_0_15_4  in_degree_855  1
    arc_0_15_4  out_degree_918  1
    arc_0_15_4  original_T_including_depot_unload_936  3.7295617536174859e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_4  arc_capacity_780  1
    load_0_15_4  segment_load_conservation_858  -1
    load_0_15_4  segment_prefix_lb_859  1
    load_0_15_4  segment_prefix_ub_860  1
    load_0_15_4  free_load_conservation_923  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_5  arc_capacity_782  -30
    arc_0_15_5  connected_order_arc_783  -16
    arc_0_15_5  in_degree_862  1
    arc_0_15_5  out_degree_918  1
    arc_0_15_5  original_T_including_depot_unload_936  4.9817963927689311e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_5  arc_capacity_782  1
    load_0_15_5  segment_load_conservation_865  -1
    load_0_15_5  segment_prefix_lb_866  1
    load_0_15_5  segment_prefix_ub_867  1
    load_0_15_5  free_load_conservation_923  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_6  arc_capacity_784  -30
    arc_0_15_6  connected_order_arc_785  -16
    arc_0_15_6  in_degree_869  1
    arc_0_15_6  out_degree_918  1
    arc_0_15_6  original_T_including_depot_unload_936  6.4057623819624155e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_6  arc_capacity_784  1
    load_0_15_6  segment_load_conservation_872  -1
    load_0_15_6  segment_prefix_lb_873  1
    load_0_15_6  segment_prefix_ub_874  1
    load_0_15_6  free_load_conservation_923  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_7  arc_capacity_786  -30
    arc_0_15_7  connected_order_arc_787  -16
    arc_0_15_7  in_degree_876  1
    arc_0_15_7  out_degree_918  1
    arc_0_15_7  original_T_including_depot_unload_936  7.3627521985972965e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_7  arc_capacity_786  1
    load_0_15_7  segment_load_conservation_879  -1
    load_0_15_7  segment_prefix_lb_880  1
    load_0_15_7  segment_prefix_ub_881  1
    load_0_15_7  free_load_conservation_923  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_9  arc_capacity_788  -30
    arc_0_15_9  connected_order_arc_789  -16
    arc_0_15_9  in_degree_883  1
    arc_0_15_9  out_degree_918  1
    arc_0_15_9  original_T_including_depot_unload_936  2.4478438645146789e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_9  arc_capacity_788  1
    load_0_15_9  free_load_conservation_887  -1
    load_0_15_9  free_load_conservation_923  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_10  arc_capacity_790  -30
    arc_0_15_10  connected_order_arc_791  -16
    arc_0_15_10  in_degree_889  1
    arc_0_15_10  out_degree_918  1
    arc_0_15_10  original_T_including_depot_unload_936  2.4369093744670904e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_10  arc_capacity_790  1
    load_0_15_10  free_load_conservation_893  -1
    load_0_15_10  free_load_conservation_923  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_11  arc_capacity_792  -30
    arc_0_15_11  connected_order_arc_793  -16
    arc_0_15_11  in_degree_895  1
    arc_0_15_11  out_degree_918  1
    arc_0_15_11  original_T_including_depot_unload_936  2.9878665461125843e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_11  arc_capacity_792  1
    load_0_15_11  free_load_conservation_899  -1
    load_0_15_11  free_load_conservation_923  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_12  arc_capacity_794  -30
    arc_0_15_12  connected_order_arc_795  -16
    arc_0_15_12  in_degree_901  1
    arc_0_15_12  out_degree_918  1
    arc_0_15_12  original_T_including_depot_unload_936  2.9747397208089205e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_12  arc_capacity_794  1
    load_0_15_12  free_load_conservation_905  -1
    load_0_15_12  free_load_conservation_923  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_13  arc_capacity_796  -30
    arc_0_15_13  connected_order_arc_797  -16
    arc_0_15_13  in_degree_907  1
    arc_0_15_13  out_degree_918  1
    arc_0_15_13  original_T_including_depot_unload_936  3.1658582590062310e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_13  arc_capacity_796  1
    load_0_15_13  free_load_conservation_911  -1
    load_0_15_13  free_load_conservation_923  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_14  arc_capacity_798  -30
    arc_0_15_14  connected_order_arc_799  -16
    arc_0_15_14  in_degree_913  1
    arc_0_15_14  out_degree_918  1
    arc_0_15_14  original_T_including_depot_unload_936  1.4558134627196880e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_14  arc_capacity_798  1
    load_0_15_14  free_load_conservation_917  -1
    load_0_15_14  free_load_conservation_923  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_16  arc_capacity_800  -30
    arc_0_15_16  connected_order_arc_801  -16
    arc_0_15_16  out_degree_918  1
    arc_0_15_16  in_degree_925  1
    arc_0_15_16  original_T_including_depot_unload_936  7.8604521666483390e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_16  arc_capacity_800  1
    load_0_15_16  free_load_conservation_923  1
    load_0_15_16  free_load_conservation_929  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_0  arc_capacity_802  -30
    arc_0_16_0  depot_return_or_bypass_832  1
    arc_0_16_0  out_degree_924  1
    arc_0_16_0  original_T_including_depot_unload_936  5.2774046204590661e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_0  arc_capacity_802  1
    load_0_16_0  free_load_conservation_929  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_1  arc_capacity_803  -30
    arc_0_16_1  connected_order_arc_804  -16
    arc_0_16_1  in_degree_834  1
    arc_0_16_1  out_degree_924  1
    arc_0_16_1  original_T_including_depot_unload_936  4.4360641393992279e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_1  arc_capacity_803  1
    load_0_16_1  segment_load_conservation_837  -1
    load_0_16_1  segment_prefix_lb_838  1
    load_0_16_1  segment_prefix_ub_839  1
    load_0_16_1  free_load_conservation_929  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_2  arc_capacity_805  -30
    arc_0_16_2  connected_order_arc_806  -16
    arc_0_16_2  in_degree_841  1
    arc_0_16_2  out_degree_924  1
    arc_0_16_2  original_T_including_depot_unload_936  7.2186296856879846e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_2  arc_capacity_805  1
    load_0_16_2  segment_load_conservation_844  -1
    load_0_16_2  segment_prefix_lb_845  1
    load_0_16_2  segment_prefix_ub_846  1
    load_0_16_2  free_load_conservation_929  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_3  arc_capacity_807  -30
    arc_0_16_3  connected_order_arc_808  -16
    arc_0_16_3  in_degree_848  1
    arc_0_16_3  out_degree_924  1
    arc_0_16_3  original_T_including_depot_unload_936  5.6231331158364958e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_3  arc_capacity_807  1
    load_0_16_3  segment_load_conservation_851  -1
    load_0_16_3  segment_prefix_lb_852  1
    load_0_16_3  segment_prefix_ub_853  1
    load_0_16_3  free_load_conservation_929  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_4  arc_capacity_809  -30
    arc_0_16_4  connected_order_arc_810  -16
    arc_0_16_4  in_degree_855  1
    arc_0_16_4  out_degree_924  1
    arc_0_16_4  original_T_including_depot_unload_936  4.1346687597344868e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_4  arc_capacity_809  1
    load_0_16_4  segment_load_conservation_858  -1
    load_0_16_4  segment_prefix_lb_859  1
    load_0_16_4  segment_prefix_ub_860  1
    load_0_16_4  free_load_conservation_929  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_5  arc_capacity_811  -30
    arc_0_16_5  connected_order_arc_812  -16
    arc_0_16_5  in_degree_862  1
    arc_0_16_5  out_degree_924  1
    arc_0_16_5  original_T_including_depot_unload_936  291.965990421835
    MARKER    'MARKER'                 'INTEND'
    load_0_16_5  arc_capacity_811  1
    load_0_16_5  segment_load_conservation_865  -1
    load_0_16_5  segment_prefix_lb_866  1
    load_0_16_5  segment_prefix_ub_867  1
    load_0_16_5  free_load_conservation_929  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_6  arc_capacity_813  -30
    arc_0_16_6  connected_order_arc_814  -16
    arc_0_16_6  in_degree_869  1
    arc_0_16_6  out_degree_924  1
    arc_0_16_6  original_T_including_depot_unload_936  1.4810770279475858e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_6  arc_capacity_813  1
    load_0_16_6  segment_load_conservation_872  -1
    load_0_16_6  segment_prefix_lb_873  1
    load_0_16_6  segment_prefix_ub_874  1
    load_0_16_6  free_load_conservation_929  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_7  arc_capacity_815  -30
    arc_0_16_7  connected_order_arc_816  -16
    arc_0_16_7  in_degree_876  1
    arc_0_16_7  out_degree_924  1
    arc_0_16_7  original_T_including_depot_unload_936  2.6178398366762252e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_7  arc_capacity_815  1
    load_0_16_7  segment_load_conservation_879  -1
    load_0_16_7  segment_prefix_lb_880  1
    load_0_16_7  segment_prefix_ub_881  1
    load_0_16_7  free_load_conservation_929  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_9  arc_capacity_817  -30
    arc_0_16_9  connected_order_arc_818  -16
    arc_0_16_9  in_degree_883  1
    arc_0_16_9  out_degree_924  1
    arc_0_16_9  original_T_including_depot_unload_936  1.7340603255343296e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_9  arc_capacity_817  1
    load_0_16_9  free_load_conservation_887  -1
    load_0_16_9  free_load_conservation_929  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_10  arc_capacity_819  -30
    arc_0_16_10  connected_order_arc_820  -16
    arc_0_16_10  in_degree_889  1
    arc_0_16_10  out_degree_924  1
    arc_0_16_10  original_T_including_depot_unload_936  1.7037372759708057e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_10  arc_capacity_819  1
    load_0_16_10  free_load_conservation_893  -1
    load_0_16_10  free_load_conservation_929  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_11  arc_capacity_821  -30
    arc_0_16_11  connected_order_arc_822  -16
    arc_0_16_11  in_degree_895  1
    arc_0_16_11  out_degree_924  1
    arc_0_16_11  original_T_including_depot_unload_936  2.7957126389480295e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_11  arc_capacity_821  1
    load_0_16_11  free_load_conservation_899  -1
    load_0_16_11  free_load_conservation_929  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_12  arc_capacity_823  -30
    arc_0_16_12  connected_order_arc_824  -16
    arc_0_16_12  in_degree_901  1
    arc_0_16_12  out_degree_924  1
    arc_0_16_12  original_T_including_depot_unload_936  2.2541698308553673e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_12  arc_capacity_823  1
    load_0_16_12  free_load_conservation_905  -1
    load_0_16_12  free_load_conservation_929  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_13  arc_capacity_825  -30
    arc_0_16_13  connected_order_arc_826  -16
    arc_0_16_13  in_degree_907  1
    arc_0_16_13  out_degree_924  1
    arc_0_16_13  original_T_including_depot_unload_936  2.4370949895474209e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_13  arc_capacity_825  1
    load_0_16_13  free_load_conservation_911  -1
    load_0_16_13  free_load_conservation_929  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_14  arc_capacity_827  -30
    arc_0_16_14  connected_order_arc_828  -16
    arc_0_16_14  in_degree_913  1
    arc_0_16_14  out_degree_924  1
    arc_0_16_14  original_T_including_depot_unload_936  7.2696582003770027e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_14  arc_capacity_827  1
    load_0_16_14  free_load_conservation_917  -1
    load_0_16_14  free_load_conservation_929  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_15  arc_capacity_829  -30
    arc_0_16_15  connected_order_arc_830  -16
    arc_0_16_15  in_degree_919  1
    arc_0_16_15  out_degree_924  1
    arc_0_16_15  original_T_including_depot_unload_936  7.8604521666483390e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_15  arc_capacity_829  1
    load_0_16_15  free_load_conservation_923  -1
    load_0_16_15  free_load_conservation_929  1
    visit_1_8  out_degree_1102  -1
    visit_1_8  in_degree_1103  -1
    visit_1_8  order_active_lb_1104  -1
    visit_1_8  order_active_ub_1105  -9
    order_1_8  connected_order_arc_949  -1
    order_1_8  connected_order_arc_951  -1
    order_1_8  connected_order_arc_953  -1
    order_1_8  connected_order_arc_955  -1
    order_1_8  connected_order_arc_957  -1
    order_1_8  connected_order_arc_959  -1
    order_1_8  connected_order_arc_961  -1
    order_1_8  connected_order_arc_963  -1
    order_1_8  connected_order_arc_966  1
    order_1_8  connected_order_arc_983  1
    order_1_8  connected_order_arc_1000  1
    order_1_8  connected_order_arc_1017  1
    order_1_8  connected_order_arc_1034  1
    order_1_8  connected_order_arc_1051  1
    order_1_8  connected_order_arc_1068  1
    order_1_8  connected_order_arc_1085  1
    order_1_8  order_active_lb_1104  1
    order_1_8  order_active_ub_1105  1
    visit_1_9  out_degree_1109  -1
    visit_1_9  in_degree_1110  -1
    visit_1_9  order_active_lb_1111  -1
    visit_1_9  order_active_ub_1112  -9
    visit_1_9  service_visit_def_1113  -1
    order_1_9  connected_order_arc_949  1
    order_1_9  connected_order_arc_966  -1
    order_1_9  connected_order_arc_968  -1
    order_1_9  connected_order_arc_970  -1
    order_1_9  connected_order_arc_972  -1
    order_1_9  connected_order_arc_974  -1
    order_1_9  connected_order_arc_976  -1
    order_1_9  connected_order_arc_978  -1
    order_1_9  connected_order_arc_980  -1
    order_1_9  connected_order_arc_985  1
    order_1_9  connected_order_arc_1002  1
    order_1_9  connected_order_arc_1019  1
    order_1_9  connected_order_arc_1036  1
    order_1_9  connected_order_arc_1053  1
    order_1_9  connected_order_arc_1070  1
    order_1_9  connected_order_arc_1087  1
    order_1_9  order_active_lb_1111  1
    order_1_9  order_active_ub_1112  1
    visit_1_10  out_degree_1115  -1
    visit_1_10  in_degree_1116  -1
    visit_1_10  order_active_lb_1117  -1
    visit_1_10  order_active_ub_1118  -9
    visit_1_10  service_visit_def_1119  -1
    order_1_10  connected_order_arc_951  1
    order_1_10  connected_order_arc_968  1
    order_1_10  connected_order_arc_983  -1
    order_1_10  connected_order_arc_985  -1
    order_1_10  connected_order_arc_987  -1
    order_1_10  connected_order_arc_989  -1
    order_1_10  connected_order_arc_991  -1
    order_1_10  connected_order_arc_993  -1
    order_1_10  connected_order_arc_995  -1
    order_1_10  connected_order_arc_997  -1
    order_1_10  connected_order_arc_1004  1
    order_1_10  connected_order_arc_1021  1
    order_1_10  connected_order_arc_1038  1
    order_1_10  connected_order_arc_1055  1
    order_1_10  connected_order_arc_1072  1
    order_1_10  connected_order_arc_1089  1
    order_1_10  order_active_lb_1117  1
    order_1_10  order_active_ub_1118  1
    visit_1_11  out_degree_1121  -1
    visit_1_11  in_degree_1122  -1
    visit_1_11  order_active_lb_1123  -1
    visit_1_11  order_active_ub_1124  -9
    visit_1_11  service_visit_def_1125  -1
    order_1_11  connected_order_arc_953  1
    order_1_11  connected_order_arc_970  1
    order_1_11  connected_order_arc_987  1
    order_1_11  connected_order_arc_1000  -1
    order_1_11  connected_order_arc_1002  -1
    order_1_11  connected_order_arc_1004  -1
    order_1_11  connected_order_arc_1006  -1
    order_1_11  connected_order_arc_1008  -1
    order_1_11  connected_order_arc_1010  -1
    order_1_11  connected_order_arc_1012  -1
    order_1_11  connected_order_arc_1014  -1
    order_1_11  connected_order_arc_1023  1
    order_1_11  connected_order_arc_1040  1
    order_1_11  connected_order_arc_1057  1
    order_1_11  connected_order_arc_1074  1
    order_1_11  connected_order_arc_1091  1
    order_1_11  order_active_lb_1123  1
    order_1_11  order_active_ub_1124  1
    visit_1_12  out_degree_1127  -1
    visit_1_12  in_degree_1128  -1
    visit_1_12  order_active_lb_1129  -1
    visit_1_12  order_active_ub_1130  -9
    visit_1_12  service_visit_def_1131  -1
    order_1_12  connected_order_arc_955  1
    order_1_12  connected_order_arc_972  1
    order_1_12  connected_order_arc_989  1
    order_1_12  connected_order_arc_1006  1
    order_1_12  connected_order_arc_1017  -1
    order_1_12  connected_order_arc_1019  -1
    order_1_12  connected_order_arc_1021  -1
    order_1_12  connected_order_arc_1023  -1
    order_1_12  connected_order_arc_1025  -1
    order_1_12  connected_order_arc_1027  -1
    order_1_12  connected_order_arc_1029  -1
    order_1_12  connected_order_arc_1031  -1
    order_1_12  connected_order_arc_1042  1
    order_1_12  connected_order_arc_1059  1
    order_1_12  connected_order_arc_1076  1
    order_1_12  connected_order_arc_1093  1
    order_1_12  order_active_lb_1129  1
    order_1_12  order_active_ub_1130  1
    visit_1_13  out_degree_1133  -1
    visit_1_13  in_degree_1134  -1
    visit_1_13  order_active_lb_1135  -1
    visit_1_13  order_active_ub_1136  -9
    visit_1_13  service_visit_def_1137  -1
    order_1_13  connected_order_arc_957  1
    order_1_13  connected_order_arc_974  1
    order_1_13  connected_order_arc_991  1
    order_1_13  connected_order_arc_1008  1
    order_1_13  connected_order_arc_1025  1
    order_1_13  connected_order_arc_1034  -1
    order_1_13  connected_order_arc_1036  -1
    order_1_13  connected_order_arc_1038  -1
    order_1_13  connected_order_arc_1040  -1
    order_1_13  connected_order_arc_1042  -1
    order_1_13  connected_order_arc_1044  -1
    order_1_13  connected_order_arc_1046  -1
    order_1_13  connected_order_arc_1048  -1
    order_1_13  connected_order_arc_1061  1
    order_1_13  connected_order_arc_1078  1
    order_1_13  connected_order_arc_1095  1
    order_1_13  order_active_lb_1135  1
    order_1_13  order_active_ub_1136  1
    visit_1_14  out_degree_1139  -1
    visit_1_14  in_degree_1140  -1
    visit_1_14  order_active_lb_1141  -1
    visit_1_14  order_active_ub_1142  -9
    visit_1_14  service_visit_def_1143  -1
    order_1_14  connected_order_arc_959  1
    order_1_14  connected_order_arc_976  1
    order_1_14  connected_order_arc_993  1
    order_1_14  connected_order_arc_1010  1
    order_1_14  connected_order_arc_1027  1
    order_1_14  connected_order_arc_1044  1
    order_1_14  connected_order_arc_1051  -1
    order_1_14  connected_order_arc_1053  -1
    order_1_14  connected_order_arc_1055  -1
    order_1_14  connected_order_arc_1057  -1
    order_1_14  connected_order_arc_1059  -1
    order_1_14  connected_order_arc_1061  -1
    order_1_14  connected_order_arc_1063  -1
    order_1_14  connected_order_arc_1065  -1
    order_1_14  connected_order_arc_1080  1
    order_1_14  connected_order_arc_1097  1
    order_1_14  order_active_lb_1141  1
    order_1_14  order_active_ub_1142  1
    visit_1_15  out_degree_1145  -1
    visit_1_15  in_degree_1146  -1
    visit_1_15  order_active_lb_1147  -1
    visit_1_15  order_active_ub_1148  -9
    visit_1_15  service_visit_def_1149  -1
    order_1_15  connected_order_arc_961  1
    order_1_15  connected_order_arc_978  1
    order_1_15  connected_order_arc_995  1
    order_1_15  connected_order_arc_1012  1
    order_1_15  connected_order_arc_1029  1
    order_1_15  connected_order_arc_1046  1
    order_1_15  connected_order_arc_1063  1
    order_1_15  connected_order_arc_1068  -1
    order_1_15  connected_order_arc_1070  -1
    order_1_15  connected_order_arc_1072  -1
    order_1_15  connected_order_arc_1074  -1
    order_1_15  connected_order_arc_1076  -1
    order_1_15  connected_order_arc_1078  -1
    order_1_15  connected_order_arc_1080  -1
    order_1_15  connected_order_arc_1082  -1
    order_1_15  connected_order_arc_1099  1
    order_1_15  order_active_lb_1147  1
    order_1_15  order_active_ub_1148  1
    visit_1_16  out_degree_1151  -1
    visit_1_16  in_degree_1152  -1
    visit_1_16  order_active_lb_1153  -1
    visit_1_16  order_active_ub_1154  -9
    visit_1_16  service_visit_def_1155  -1
    order_1_16  connected_order_arc_963  1
    order_1_16  connected_order_arc_980  1
    order_1_16  connected_order_arc_997  1
    order_1_16  connected_order_arc_1014  1
    order_1_16  connected_order_arc_1031  1
    order_1_16  connected_order_arc_1048  1
    order_1_16  connected_order_arc_1065  1
    order_1_16  connected_order_arc_1082  1
    order_1_16  connected_order_arc_1085  -1
    order_1_16  connected_order_arc_1087  -1
    order_1_16  connected_order_arc_1089  -1
    order_1_16  connected_order_arc_1091  -1
    order_1_16  connected_order_arc_1093  -1
    order_1_16  connected_order_arc_1095  -1
    order_1_16  connected_order_arc_1097  -1
    order_1_16  connected_order_arc_1099  -1
    order_1_16  order_active_lb_1153  1
    order_1_16  order_active_ub_1154  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_0  arc_capacity_937  -30
    arc_1_0_0  depot_departure_or_bypass_1100  1
    arc_1_0_0  depot_return_or_bypass_1101  1
    MARKER    'MARKER'                 'INTEND'
    load_1_0_0  arc_capacity_937  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_8  arc_capacity_938  -30
    arc_1_0_8  depot_departure_or_bypass_1100  1
    arc_1_0_8  in_degree_1103  1
    arc_1_0_8  original_T_including_depot_unload_1157  4.0782796387128610e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_8  arc_capacity_938  1
    load_1_0_8  segment_load_conservation_1106  -1
    load_1_0_8  segment_prefix_lb_1107  1
    load_1_0_8  segment_prefix_ub_1108  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_9  arc_capacity_939  -30
    arc_1_0_9  depot_departure_or_bypass_1100  1
    arc_1_0_9  in_degree_1110  1
    arc_1_0_9  original_T_including_depot_unload_1157  1.8065333212349267e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_9  arc_capacity_939  1
    load_1_0_9  free_load_conservation_1114  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_10  arc_capacity_940  -30
    arc_1_0_10  depot_departure_or_bypass_1100  1
    arc_1_0_10  in_degree_1116  1
    arc_1_0_10  original_T_including_depot_unload_1157  1739.61165920636
    MARKER    'MARKER'                 'INTEND'
    load_1_0_10  arc_capacity_940  1
    load_1_0_10  free_load_conservation_1120  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_11  arc_capacity_941  -30
    arc_1_0_11  depot_departure_or_bypass_1100  1
    arc_1_0_11  in_degree_1122  1
    arc_1_0_11  original_T_including_depot_unload_1157  2.3234267380118886e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_11  arc_capacity_941  1
    load_1_0_11  free_load_conservation_1126  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_12  arc_capacity_942  -30
    arc_1_0_12  depot_departure_or_bypass_1100  1
    arc_1_0_12  in_degree_1128  1
    arc_1_0_12  original_T_including_depot_unload_1157  2.2866763971369810e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_12  arc_capacity_942  1
    load_1_0_12  free_load_conservation_1132  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_13  arc_capacity_943  -30
    arc_1_0_13  depot_departure_or_bypass_1100  1
    arc_1_0_13  in_degree_1134  1
    arc_1_0_13  original_T_including_depot_unload_1157  2.0232971184291544e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_13  arc_capacity_943  1
    load_1_0_13  free_load_conservation_1138  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_14  arc_capacity_944  -30
    arc_1_0_14  depot_departure_or_bypass_1100  1
    arc_1_0_14  in_degree_1140  1
    arc_1_0_14  original_T_including_depot_unload_1157  3.5937232665424995e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_14  arc_capacity_944  1
    load_1_0_14  free_load_conservation_1144  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_15  arc_capacity_945  -30
    arc_1_0_15  depot_departure_or_bypass_1100  1
    arc_1_0_15  in_degree_1146  1
    arc_1_0_15  original_T_including_depot_unload_1157  1.1473865007565566e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_15  arc_capacity_945  1
    load_1_0_15  free_load_conservation_1150  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_16  arc_capacity_946  -30
    arc_1_0_16  depot_departure_or_bypass_1100  1
    arc_1_0_16  in_degree_1152  1
    arc_1_0_16  original_T_including_depot_unload_1157  5.2774046204590661e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_16  arc_capacity_946  1
    load_1_0_16  free_load_conservation_1156  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_0  arc_capacity_947  -30
    arc_1_8_0  depot_return_or_bypass_1101  1
    arc_1_8_0  out_degree_1102  1
    arc_1_8_0  original_T_including_depot_unload_1157  4.0782796387128610e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_0  arc_capacity_947  1
    load_1_8_0  segment_load_conservation_1106  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_9  arc_capacity_948  -30
    arc_1_8_9  connected_order_arc_949  -10
    arc_1_8_9  out_degree_1102  1
    arc_1_8_9  in_degree_1110  1
    arc_1_8_9  original_T_including_depot_unload_1157  1.7671662790958783e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_9  arc_capacity_948  1
    load_1_8_9  segment_load_conservation_1106  1
    load_1_8_9  free_load_conservation_1114  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_10  arc_capacity_950  -30
    arc_1_8_10  connected_order_arc_951  -10
    arc_1_8_10  out_degree_1102  1
    arc_1_8_10  in_degree_1116  1
    arc_1_8_10  original_T_including_depot_unload_1157  1.7279728905134273e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_10  arc_capacity_950  1
    load_1_8_10  segment_load_conservation_1106  1
    load_1_8_10  free_load_conservation_1120  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_11  arc_capacity_952  -30
    arc_1_8_11  connected_order_arc_953  -10
    arc_1_8_11  out_degree_1102  1
    arc_1_8_11  in_degree_1122  1
    arc_1_8_11  original_T_including_depot_unload_1157  2.6728511574036233e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_11  arc_capacity_952  1
    load_1_8_11  segment_load_conservation_1106  1
    load_1_8_11  free_load_conservation_1126  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_12  arc_capacity_954  -30
    arc_1_8_12  connected_order_arc_955  -10
    arc_1_8_12  out_degree_1102  1
    arc_1_8_12  in_degree_1128  1
    arc_1_8_12  original_T_including_depot_unload_1157  2.2811398160464278e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_12  arc_capacity_954  1
    load_1_8_12  segment_load_conservation_1106  1
    load_1_8_12  free_load_conservation_1132  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_13  arc_capacity_956  -30
    arc_1_8_13  connected_order_arc_957  -10
    arc_1_8_13  out_degree_1102  1
    arc_1_8_13  in_degree_1134  1
    arc_1_8_13  original_T_including_depot_unload_1157  2.3561201725625019e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_13  arc_capacity_956  1
    load_1_8_13  segment_load_conservation_1106  1
    load_1_8_13  free_load_conservation_1138  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_14  arc_capacity_958  -30
    arc_1_8_14  connected_order_arc_959  -10
    arc_1_8_14  out_degree_1102  1
    arc_1_8_14  in_degree_1140  1
    arc_1_8_14  original_T_including_depot_unload_1157  6.3975035388222534e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_14  arc_capacity_958  1
    load_1_8_14  segment_load_conservation_1106  1
    load_1_8_14  free_load_conservation_1144  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_15  arc_capacity_960  -30
    arc_1_8_15  connected_order_arc_961  -10
    arc_1_8_15  out_degree_1102  1
    arc_1_8_15  in_degree_1146  1
    arc_1_8_15  original_T_including_depot_unload_1157  8.2982882938703278e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_15  arc_capacity_960  1
    load_1_8_15  segment_load_conservation_1106  1
    load_1_8_15  free_load_conservation_1150  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_16  arc_capacity_962  -30
    arc_1_8_16  connected_order_arc_963  -10
    arc_1_8_16  out_degree_1102  1
    arc_1_8_16  in_degree_1152  1
    arc_1_8_16  original_T_including_depot_unload_1157  1.2480053261465446e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_16  arc_capacity_962  1
    load_1_8_16  segment_load_conservation_1106  1
    load_1_8_16  free_load_conservation_1156  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_0  arc_capacity_964  -30
    arc_1_9_0  depot_return_or_bypass_1101  1
    arc_1_9_0  out_degree_1109  1
    arc_1_9_0  original_T_including_depot_unload_1157  1.8065333212349267e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_0  arc_capacity_964  1
    load_1_9_0  free_load_conservation_1114  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_8  arc_capacity_965  -30
    arc_1_9_8  connected_order_arc_966  -10
    arc_1_9_8  in_degree_1103  1
    arc_1_9_8  out_degree_1109  1
    arc_1_9_8  original_T_including_depot_unload_1157  1.7671662790958783e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_8  arc_capacity_965  1
    load_1_9_8  segment_load_conservation_1106  -1
    load_1_9_8  segment_prefix_lb_1107  1
    load_1_9_8  segment_prefix_ub_1108  1
    load_1_9_8  free_load_conservation_1114  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_10  arc_capacity_967  -30
    arc_1_9_10  connected_order_arc_968  -10
    arc_1_9_10  out_degree_1109  1
    arc_1_9_10  in_degree_1116  1
    arc_1_9_10  original_T_including_depot_unload_1157  1.3126251897454844e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_10  arc_capacity_967  1
    load_1_9_10  free_load_conservation_1114  1
    load_1_9_10  free_load_conservation_1120  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_11  arc_capacity_969  -30
    arc_1_9_11  connected_order_arc_970  -10
    arc_1_9_11  out_degree_1109  1
    arc_1_9_11  in_degree_1122  1
    arc_1_9_11  original_T_including_depot_unload_1157  3.8283958278492823e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_11  arc_capacity_969  1
    load_1_9_11  free_load_conservation_1114  1
    load_1_9_11  free_load_conservation_1126  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_12  arc_capacity_971  -30
    arc_1_9_12  connected_order_arc_972  -10
    arc_1_9_12  out_degree_1109  1
    arc_1_9_12  in_degree_1128  1
    arc_1_9_12  original_T_including_depot_unload_1157  5.2703432304351884e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_12  arc_capacity_971  1
    load_1_9_12  free_load_conservation_1114  1
    load_1_9_12  free_load_conservation_1132  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_13  arc_capacity_973  -30
    arc_1_9_13  connected_order_arc_974  -10
    arc_1_9_13  out_degree_1109  1
    arc_1_9_13  in_degree_1134  1
    arc_1_9_13  original_T_including_depot_unload_1157  2.0239755898835604e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_13  arc_capacity_973  1
    load_1_9_13  free_load_conservation_1114  1
    load_1_9_13  free_load_conservation_1138  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_14  arc_capacity_975  -30
    arc_1_9_14  connected_order_arc_976  -10
    arc_1_9_14  out_degree_1109  1
    arc_1_9_14  in_degree_1140  1
    arc_1_9_14  original_T_including_depot_unload_1157  1.5255932363401953e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_14  arc_capacity_975  1
    load_1_9_14  free_load_conservation_1114  1
    load_1_9_14  free_load_conservation_1144  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_15  arc_capacity_977  -30
    arc_1_9_15  connected_order_arc_978  -10
    arc_1_9_15  out_degree_1109  1
    arc_1_9_15  in_degree_1146  1
    arc_1_9_15  original_T_including_depot_unload_1157  2.4478438645146789e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_15  arc_capacity_977  1
    load_1_9_15  free_load_conservation_1114  1
    load_1_9_15  free_load_conservation_1150  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_16  arc_capacity_979  -30
    arc_1_9_16  connected_order_arc_980  -10
    arc_1_9_16  out_degree_1109  1
    arc_1_9_16  in_degree_1152  1
    arc_1_9_16  original_T_including_depot_unload_1157  1.7340603255343296e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_16  arc_capacity_979  1
    load_1_9_16  free_load_conservation_1114  1
    load_1_9_16  free_load_conservation_1156  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_0  arc_capacity_981  -30
    arc_1_10_0  depot_return_or_bypass_1101  1
    arc_1_10_0  out_degree_1115  1
    arc_1_10_0  original_T_including_depot_unload_1157  1739.61165920636
    MARKER    'MARKER'                 'INTEND'
    load_1_10_0  arc_capacity_981  1
    load_1_10_0  free_load_conservation_1120  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_8  arc_capacity_982  -30
    arc_1_10_8  connected_order_arc_983  -10
    arc_1_10_8  in_degree_1103  1
    arc_1_10_8  out_degree_1115  1
    arc_1_10_8  original_T_including_depot_unload_1157  1.7279728905134273e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_8  arc_capacity_982  1
    load_1_10_8  segment_load_conservation_1106  -1
    load_1_10_8  segment_prefix_lb_1107  1
    load_1_10_8  segment_prefix_ub_1108  1
    load_1_10_8  free_load_conservation_1120  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_9  arc_capacity_984  -30
    arc_1_10_9  connected_order_arc_985  -10
    arc_1_10_9  in_degree_1110  1
    arc_1_10_9  out_degree_1115  1
    arc_1_10_9  original_T_including_depot_unload_1157  1.3126251897454844e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_9  arc_capacity_984  1
    load_1_10_9  free_load_conservation_1114  -1
    load_1_10_9  free_load_conservation_1120  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_11  arc_capacity_986  -30
    arc_1_10_11  connected_order_arc_987  -10
    arc_1_10_11  out_degree_1115  1
    arc_1_10_11  in_degree_1122  1
    arc_1_10_11  original_T_including_depot_unload_1157  3.7182308190042463e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_11  arc_capacity_986  1
    load_1_10_11  free_load_conservation_1120  1
    load_1_10_11  free_load_conservation_1126  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_12  arc_capacity_988  -30
    arc_1_10_12  connected_order_arc_989  -10
    arc_1_10_12  out_degree_1115  1
    arc_1_10_12  in_degree_1128  1
    arc_1_10_12  original_T_including_depot_unload_1157  5.5382752177930990e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_12  arc_capacity_988  1
    load_1_10_12  free_load_conservation_1120  1
    load_1_10_12  free_load_conservation_1132  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_13  arc_capacity_990  -30
    arc_1_10_13  connected_order_arc_991  -10
    arc_1_10_13  out_degree_1115  1
    arc_1_10_13  in_degree_1134  1
    arc_1_10_13  original_T_including_depot_unload_1157  1.8934642770867222e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_13  arc_capacity_990  1
    load_1_10_13  free_load_conservation_1120  1
    load_1_10_13  free_load_conservation_1138  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_14  arc_capacity_992  -30
    arc_1_10_14  connected_order_arc_993  -10
    arc_1_10_14  out_degree_1115  1
    arc_1_10_14  in_degree_1140  1
    arc_1_10_14  original_T_including_depot_unload_1157  1.4443513852547251e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_14  arc_capacity_992  1
    load_1_10_14  free_load_conservation_1120  1
    load_1_10_14  free_load_conservation_1144  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_15  arc_capacity_994  -30
    arc_1_10_15  connected_order_arc_995  -10
    arc_1_10_15  out_degree_1115  1
    arc_1_10_15  in_degree_1146  1
    arc_1_10_15  original_T_including_depot_unload_1157  2.4369093744670904e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_15  arc_capacity_994  1
    load_1_10_15  free_load_conservation_1120  1
    load_1_10_15  free_load_conservation_1150  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_16  arc_capacity_996  -30
    arc_1_10_16  connected_order_arc_997  -10
    arc_1_10_16  out_degree_1115  1
    arc_1_10_16  in_degree_1152  1
    arc_1_10_16  original_T_including_depot_unload_1157  1.7037372759708057e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_16  arc_capacity_996  1
    load_1_10_16  free_load_conservation_1120  1
    load_1_10_16  free_load_conservation_1156  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_0  arc_capacity_998  -30
    arc_1_11_0  depot_return_or_bypass_1101  1
    arc_1_11_0  out_degree_1121  1
    arc_1_11_0  original_T_including_depot_unload_1157  2.3234267380118886e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_0  arc_capacity_998  1
    load_1_11_0  free_load_conservation_1126  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_8  arc_capacity_999  -30
    arc_1_11_8  connected_order_arc_1000  -10
    arc_1_11_8  in_degree_1103  1
    arc_1_11_8  out_degree_1121  1
    arc_1_11_8  original_T_including_depot_unload_1157  2.6728511574036233e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_8  arc_capacity_999  1
    load_1_11_8  segment_load_conservation_1106  -1
    load_1_11_8  segment_prefix_lb_1107  1
    load_1_11_8  segment_prefix_ub_1108  1
    load_1_11_8  free_load_conservation_1126  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_9  arc_capacity_1001  -30
    arc_1_11_9  connected_order_arc_1002  -10
    arc_1_11_9  in_degree_1110  1
    arc_1_11_9  out_degree_1121  1
    arc_1_11_9  original_T_including_depot_unload_1157  3.8283958278492823e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_9  arc_capacity_1001  1
    load_1_11_9  free_load_conservation_1114  -1
    load_1_11_9  free_load_conservation_1126  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_10  arc_capacity_1003  -30
    arc_1_11_10  connected_order_arc_1004  -10
    arc_1_11_10  in_degree_1116  1
    arc_1_11_10  out_degree_1121  1
    arc_1_11_10  original_T_including_depot_unload_1157  3.7182308190042463e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_10  arc_capacity_1003  1
    load_1_11_10  free_load_conservation_1120  -1
    load_1_11_10  free_load_conservation_1126  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_12  arc_capacity_1005  -30
    arc_1_11_12  connected_order_arc_1006  -10
    arc_1_11_12  out_degree_1121  1
    arc_1_11_12  in_degree_1128  1
    arc_1_11_12  original_T_including_depot_unload_1157  4.1686506413165080e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_12  arc_capacity_1005  1
    load_1_11_12  free_load_conservation_1126  1
    load_1_11_12  free_load_conservation_1132  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_13  arc_capacity_1007  -30
    arc_1_11_13  connected_order_arc_1008  -10
    arc_1_11_13  out_degree_1121  1
    arc_1_11_13  in_degree_1134  1
    arc_1_11_13  original_T_including_depot_unload_1157  2.5683172431027456e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_13  arc_capacity_1007  1
    load_1_11_13  free_load_conservation_1126  1
    load_1_11_13  free_load_conservation_1138  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_14  arc_capacity_1009  -30
    arc_1_11_14  connected_order_arc_1010  -10
    arc_1_11_14  out_degree_1121  1
    arc_1_11_14  in_degree_1140  1
    arc_1_11_14  original_T_including_depot_unload_1157  2.4160844235310037e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_14  arc_capacity_1009  1
    load_1_11_14  free_load_conservation_1126  1
    load_1_11_14  free_load_conservation_1144  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_15  arc_capacity_1011  -30
    arc_1_11_15  connected_order_arc_1012  -10
    arc_1_11_15  out_degree_1121  1
    arc_1_11_15  in_degree_1146  1
    arc_1_11_15  original_T_including_depot_unload_1157  2.9878665461125843e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_15  arc_capacity_1011  1
    load_1_11_15  free_load_conservation_1126  1
    load_1_11_15  free_load_conservation_1150  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_16  arc_capacity_1013  -30
    arc_1_11_16  connected_order_arc_1014  -10
    arc_1_11_16  out_degree_1121  1
    arc_1_11_16  in_degree_1152  1
    arc_1_11_16  original_T_including_depot_unload_1157  2.7957126389480295e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_16  arc_capacity_1013  1
    load_1_11_16  free_load_conservation_1126  1
    load_1_11_16  free_load_conservation_1156  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_0  arc_capacity_1015  -30
    arc_1_12_0  depot_return_or_bypass_1101  1
    arc_1_12_0  out_degree_1127  1
    arc_1_12_0  original_T_including_depot_unload_1157  2.2866763971369810e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_0  arc_capacity_1015  1
    load_1_12_0  free_load_conservation_1132  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_8  arc_capacity_1016  -30
    arc_1_12_8  connected_order_arc_1017  -10
    arc_1_12_8  in_degree_1103  1
    arc_1_12_8  out_degree_1127  1
    arc_1_12_8  original_T_including_depot_unload_1157  2.2811398160464278e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_8  arc_capacity_1016  1
    load_1_12_8  segment_load_conservation_1106  -1
    load_1_12_8  segment_prefix_lb_1107  1
    load_1_12_8  segment_prefix_ub_1108  1
    load_1_12_8  free_load_conservation_1132  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_9  arc_capacity_1018  -30
    arc_1_12_9  connected_order_arc_1019  -10
    arc_1_12_9  in_degree_1110  1
    arc_1_12_9  out_degree_1127  1
    arc_1_12_9  original_T_including_depot_unload_1157  5.2703432304351884e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_9  arc_capacity_1018  1
    load_1_12_9  free_load_conservation_1114  -1
    load_1_12_9  free_load_conservation_1132  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_10  arc_capacity_1020  -30
    arc_1_12_10  connected_order_arc_1021  -10
    arc_1_12_10  in_degree_1116  1
    arc_1_12_10  out_degree_1127  1
    arc_1_12_10  original_T_including_depot_unload_1157  5.5382752177930990e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_10  arc_capacity_1020  1
    load_1_12_10  free_load_conservation_1120  -1
    load_1_12_10  free_load_conservation_1132  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_11  arc_capacity_1022  -30
    arc_1_12_11  connected_order_arc_1023  -10
    arc_1_12_11  in_degree_1122  1
    arc_1_12_11  out_degree_1127  1
    arc_1_12_11  original_T_including_depot_unload_1157  4.1686506413165080e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_11  arc_capacity_1022  1
    load_1_12_11  free_load_conservation_1126  -1
    load_1_12_11  free_load_conservation_1132  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_13  arc_capacity_1024  -30
    arc_1_12_13  connected_order_arc_1025  -10
    arc_1_12_13  out_degree_1127  1
    arc_1_12_13  in_degree_1134  1
    arc_1_12_13  original_T_including_depot_unload_1157  2.0819438297758261e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_13  arc_capacity_1024  1
    load_1_12_13  free_load_conservation_1132  1
    load_1_12_13  free_load_conservation_1138  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_14  arc_capacity_1026  -30
    arc_1_12_14  connected_order_arc_1027  -10
    arc_1_12_14  out_degree_1127  1
    arc_1_12_14  in_degree_1140  1
    arc_1_12_14  original_T_including_depot_unload_1157  1.9791430726365086e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_14  arc_capacity_1026  1
    load_1_12_14  free_load_conservation_1132  1
    load_1_12_14  free_load_conservation_1144  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_15  arc_capacity_1028  -30
    arc_1_12_15  connected_order_arc_1029  -10
    arc_1_12_15  out_degree_1127  1
    arc_1_12_15  in_degree_1146  1
    arc_1_12_15  original_T_including_depot_unload_1157  2.9747397208089205e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_15  arc_capacity_1028  1
    load_1_12_15  free_load_conservation_1132  1
    load_1_12_15  free_load_conservation_1150  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_16  arc_capacity_1030  -30
    arc_1_12_16  connected_order_arc_1031  -10
    arc_1_12_16  out_degree_1127  1
    arc_1_12_16  in_degree_1152  1
    arc_1_12_16  original_T_including_depot_unload_1157  2.2541698308553673e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_16  arc_capacity_1030  1
    load_1_12_16  free_load_conservation_1132  1
    load_1_12_16  free_load_conservation_1156  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_0  arc_capacity_1032  -30
    arc_1_13_0  depot_return_or_bypass_1101  1
    arc_1_13_0  out_degree_1133  1
    arc_1_13_0  original_T_including_depot_unload_1157  2.0232971184291544e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_0  arc_capacity_1032  1
    load_1_13_0  free_load_conservation_1138  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_8  arc_capacity_1033  -30
    arc_1_13_8  connected_order_arc_1034  -10
    arc_1_13_8  in_degree_1103  1
    arc_1_13_8  out_degree_1133  1
    arc_1_13_8  original_T_including_depot_unload_1157  2.3561201725625019e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_8  arc_capacity_1033  1
    load_1_13_8  segment_load_conservation_1106  -1
    load_1_13_8  segment_prefix_lb_1107  1
    load_1_13_8  segment_prefix_ub_1108  1
    load_1_13_8  free_load_conservation_1138  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_9  arc_capacity_1035  -30
    arc_1_13_9  connected_order_arc_1036  -10
    arc_1_13_9  in_degree_1110  1
    arc_1_13_9  out_degree_1133  1
    arc_1_13_9  original_T_including_depot_unload_1157  2.0239755898835604e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_9  arc_capacity_1035  1
    load_1_13_9  free_load_conservation_1114  -1
    load_1_13_9  free_load_conservation_1138  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_10  arc_capacity_1037  -30
    arc_1_13_10  connected_order_arc_1038  -10
    arc_1_13_10  in_degree_1116  1
    arc_1_13_10  out_degree_1133  1
    arc_1_13_10  original_T_including_depot_unload_1157  1.8934642770867222e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_10  arc_capacity_1037  1
    load_1_13_10  free_load_conservation_1120  -1
    load_1_13_10  free_load_conservation_1138  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_11  arc_capacity_1039  -30
    arc_1_13_11  connected_order_arc_1040  -10
    arc_1_13_11  in_degree_1122  1
    arc_1_13_11  out_degree_1133  1
    arc_1_13_11  original_T_including_depot_unload_1157  2.5683172431027456e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_11  arc_capacity_1039  1
    load_1_13_11  free_load_conservation_1126  -1
    load_1_13_11  free_load_conservation_1138  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_12  arc_capacity_1041  -30
    arc_1_13_12  connected_order_arc_1042  -10
    arc_1_13_12  in_degree_1128  1
    arc_1_13_12  out_degree_1133  1
    arc_1_13_12  original_T_including_depot_unload_1157  2.0819438297758261e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_12  arc_capacity_1041  1
    load_1_13_12  free_load_conservation_1132  -1
    load_1_13_12  free_load_conservation_1138  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_14  arc_capacity_1043  -30
    arc_1_13_14  connected_order_arc_1044  -10
    arc_1_13_14  out_degree_1133  1
    arc_1_13_14  in_degree_1140  1
    arc_1_13_14  original_T_including_depot_unload_1157  1.7165475198920165e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_14  arc_capacity_1043  1
    load_1_13_14  free_load_conservation_1138  1
    load_1_13_14  free_load_conservation_1144  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_15  arc_capacity_1045  -30
    arc_1_13_15  connected_order_arc_1046  -10
    arc_1_13_15  out_degree_1133  1
    arc_1_13_15  in_degree_1146  1
    arc_1_13_15  original_T_including_depot_unload_1157  3.1658582590062310e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_15  arc_capacity_1045  1
    load_1_13_15  free_load_conservation_1138  1
    load_1_13_15  free_load_conservation_1150  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_16  arc_capacity_1047  -30
    arc_1_13_16  connected_order_arc_1048  -10
    arc_1_13_16  out_degree_1133  1
    arc_1_13_16  in_degree_1152  1
    arc_1_13_16  original_T_including_depot_unload_1157  2.4370949895474209e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_16  arc_capacity_1047  1
    load_1_13_16  free_load_conservation_1138  1
    load_1_13_16  free_load_conservation_1156  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_0  arc_capacity_1049  -30
    arc_1_14_0  depot_return_or_bypass_1101  1
    arc_1_14_0  out_degree_1139  1
    arc_1_14_0  original_T_including_depot_unload_1157  3.5937232665424995e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_0  arc_capacity_1049  1
    load_1_14_0  free_load_conservation_1144  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_8  arc_capacity_1050  -30
    arc_1_14_8  connected_order_arc_1051  -10
    arc_1_14_8  in_degree_1103  1
    arc_1_14_8  out_degree_1139  1
    arc_1_14_8  original_T_including_depot_unload_1157  6.3975035388222534e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_8  arc_capacity_1050  1
    load_1_14_8  segment_load_conservation_1106  -1
    load_1_14_8  segment_prefix_lb_1107  1
    load_1_14_8  segment_prefix_ub_1108  1
    load_1_14_8  free_load_conservation_1144  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_9  arc_capacity_1052  -30
    arc_1_14_9  connected_order_arc_1053  -10
    arc_1_14_9  in_degree_1110  1
    arc_1_14_9  out_degree_1139  1
    arc_1_14_9  original_T_including_depot_unload_1157  1.5255932363401953e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_9  arc_capacity_1052  1
    load_1_14_9  free_load_conservation_1114  -1
    load_1_14_9  free_load_conservation_1144  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_10  arc_capacity_1054  -30
    arc_1_14_10  connected_order_arc_1055  -10
    arc_1_14_10  in_degree_1116  1
    arc_1_14_10  out_degree_1139  1
    arc_1_14_10  original_T_including_depot_unload_1157  1.4443513852547251e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_10  arc_capacity_1054  1
    load_1_14_10  free_load_conservation_1120  -1
    load_1_14_10  free_load_conservation_1144  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_11  arc_capacity_1056  -30
    arc_1_14_11  connected_order_arc_1057  -10
    arc_1_14_11  in_degree_1122  1
    arc_1_14_11  out_degree_1139  1
    arc_1_14_11  original_T_including_depot_unload_1157  2.4160844235310037e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_11  arc_capacity_1056  1
    load_1_14_11  free_load_conservation_1126  -1
    load_1_14_11  free_load_conservation_1144  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_12  arc_capacity_1058  -30
    arc_1_14_12  connected_order_arc_1059  -10
    arc_1_14_12  in_degree_1128  1
    arc_1_14_12  out_degree_1139  1
    arc_1_14_12  original_T_including_depot_unload_1157  1.9791430726365086e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_12  arc_capacity_1058  1
    load_1_14_12  free_load_conservation_1132  -1
    load_1_14_12  free_load_conservation_1144  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_13  arc_capacity_1060  -30
    arc_1_14_13  connected_order_arc_1061  -10
    arc_1_14_13  in_degree_1134  1
    arc_1_14_13  out_degree_1139  1
    arc_1_14_13  original_T_including_depot_unload_1157  1.7165475198920165e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_13  arc_capacity_1060  1
    load_1_14_13  free_load_conservation_1138  -1
    load_1_14_13  free_load_conservation_1144  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_15  arc_capacity_1062  -30
    arc_1_14_15  connected_order_arc_1063  -10
    arc_1_14_15  out_degree_1139  1
    arc_1_14_15  in_degree_1146  1
    arc_1_14_15  original_T_including_depot_unload_1157  1.4558134627196880e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_15  arc_capacity_1062  1
    load_1_14_15  free_load_conservation_1144  1
    load_1_14_15  free_load_conservation_1150  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_16  arc_capacity_1064  -30
    arc_1_14_16  connected_order_arc_1065  -10
    arc_1_14_16  out_degree_1139  1
    arc_1_14_16  in_degree_1152  1
    arc_1_14_16  original_T_including_depot_unload_1157  7.2696582003770027e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_16  arc_capacity_1064  1
    load_1_14_16  free_load_conservation_1144  1
    load_1_14_16  free_load_conservation_1156  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_0  arc_capacity_1066  -30
    arc_1_15_0  depot_return_or_bypass_1101  1
    arc_1_15_0  out_degree_1145  1
    arc_1_15_0  original_T_including_depot_unload_1157  1.1473865007565566e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_0  arc_capacity_1066  1
    load_1_15_0  free_load_conservation_1150  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_8  arc_capacity_1067  -30
    arc_1_15_8  connected_order_arc_1068  -10
    arc_1_15_8  in_degree_1103  1
    arc_1_15_8  out_degree_1145  1
    arc_1_15_8  original_T_including_depot_unload_1157  8.2982882938703278e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_8  arc_capacity_1067  1
    load_1_15_8  segment_load_conservation_1106  -1
    load_1_15_8  segment_prefix_lb_1107  1
    load_1_15_8  segment_prefix_ub_1108  1
    load_1_15_8  free_load_conservation_1150  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_9  arc_capacity_1069  -30
    arc_1_15_9  connected_order_arc_1070  -10
    arc_1_15_9  in_degree_1110  1
    arc_1_15_9  out_degree_1145  1
    arc_1_15_9  original_T_including_depot_unload_1157  2.4478438645146789e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_9  arc_capacity_1069  1
    load_1_15_9  free_load_conservation_1114  -1
    load_1_15_9  free_load_conservation_1150  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_10  arc_capacity_1071  -30
    arc_1_15_10  connected_order_arc_1072  -10
    arc_1_15_10  in_degree_1116  1
    arc_1_15_10  out_degree_1145  1
    arc_1_15_10  original_T_including_depot_unload_1157  2.4369093744670904e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_10  arc_capacity_1071  1
    load_1_15_10  free_load_conservation_1120  -1
    load_1_15_10  free_load_conservation_1150  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_11  arc_capacity_1073  -30
    arc_1_15_11  connected_order_arc_1074  -10
    arc_1_15_11  in_degree_1122  1
    arc_1_15_11  out_degree_1145  1
    arc_1_15_11  original_T_including_depot_unload_1157  2.9878665461125843e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_11  arc_capacity_1073  1
    load_1_15_11  free_load_conservation_1126  -1
    load_1_15_11  free_load_conservation_1150  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_12  arc_capacity_1075  -30
    arc_1_15_12  connected_order_arc_1076  -10
    arc_1_15_12  in_degree_1128  1
    arc_1_15_12  out_degree_1145  1
    arc_1_15_12  original_T_including_depot_unload_1157  2.9747397208089205e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_12  arc_capacity_1075  1
    load_1_15_12  free_load_conservation_1132  -1
    load_1_15_12  free_load_conservation_1150  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_13  arc_capacity_1077  -30
    arc_1_15_13  connected_order_arc_1078  -10
    arc_1_15_13  in_degree_1134  1
    arc_1_15_13  out_degree_1145  1
    arc_1_15_13  original_T_including_depot_unload_1157  3.1658582590062310e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_13  arc_capacity_1077  1
    load_1_15_13  free_load_conservation_1138  -1
    load_1_15_13  free_load_conservation_1150  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_14  arc_capacity_1079  -30
    arc_1_15_14  connected_order_arc_1080  -10
    arc_1_15_14  in_degree_1140  1
    arc_1_15_14  out_degree_1145  1
    arc_1_15_14  original_T_including_depot_unload_1157  1.4558134627196880e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_14  arc_capacity_1079  1
    load_1_15_14  free_load_conservation_1144  -1
    load_1_15_14  free_load_conservation_1150  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_16  arc_capacity_1081  -30
    arc_1_15_16  connected_order_arc_1082  -10
    arc_1_15_16  out_degree_1145  1
    arc_1_15_16  in_degree_1152  1
    arc_1_15_16  original_T_including_depot_unload_1157  7.8604521666483390e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_16  arc_capacity_1081  1
    load_1_15_16  free_load_conservation_1150  1
    load_1_15_16  free_load_conservation_1156  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_0  arc_capacity_1083  -30
    arc_1_16_0  depot_return_or_bypass_1101  1
    arc_1_16_0  out_degree_1151  1
    arc_1_16_0  original_T_including_depot_unload_1157  5.2774046204590661e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_0  arc_capacity_1083  1
    load_1_16_0  free_load_conservation_1156  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_8  arc_capacity_1084  -30
    arc_1_16_8  connected_order_arc_1085  -10
    arc_1_16_8  in_degree_1103  1
    arc_1_16_8  out_degree_1151  1
    arc_1_16_8  original_T_including_depot_unload_1157  1.2480053261465446e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_8  arc_capacity_1084  1
    load_1_16_8  segment_load_conservation_1106  -1
    load_1_16_8  segment_prefix_lb_1107  1
    load_1_16_8  segment_prefix_ub_1108  1
    load_1_16_8  free_load_conservation_1156  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_9  arc_capacity_1086  -30
    arc_1_16_9  connected_order_arc_1087  -10
    arc_1_16_9  in_degree_1110  1
    arc_1_16_9  out_degree_1151  1
    arc_1_16_9  original_T_including_depot_unload_1157  1.7340603255343296e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_9  arc_capacity_1086  1
    load_1_16_9  free_load_conservation_1114  -1
    load_1_16_9  free_load_conservation_1156  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_10  arc_capacity_1088  -30
    arc_1_16_10  connected_order_arc_1089  -10
    arc_1_16_10  in_degree_1116  1
    arc_1_16_10  out_degree_1151  1
    arc_1_16_10  original_T_including_depot_unload_1157  1.7037372759708057e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_10  arc_capacity_1088  1
    load_1_16_10  free_load_conservation_1120  -1
    load_1_16_10  free_load_conservation_1156  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_11  arc_capacity_1090  -30
    arc_1_16_11  connected_order_arc_1091  -10
    arc_1_16_11  in_degree_1122  1
    arc_1_16_11  out_degree_1151  1
    arc_1_16_11  original_T_including_depot_unload_1157  2.7957126389480295e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_11  arc_capacity_1090  1
    load_1_16_11  free_load_conservation_1126  -1
    load_1_16_11  free_load_conservation_1156  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_12  arc_capacity_1092  -30
    arc_1_16_12  connected_order_arc_1093  -10
    arc_1_16_12  in_degree_1128  1
    arc_1_16_12  out_degree_1151  1
    arc_1_16_12  original_T_including_depot_unload_1157  2.2541698308553673e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_12  arc_capacity_1092  1
    load_1_16_12  free_load_conservation_1132  -1
    load_1_16_12  free_load_conservation_1156  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_13  arc_capacity_1094  -30
    arc_1_16_13  connected_order_arc_1095  -10
    arc_1_16_13  in_degree_1134  1
    arc_1_16_13  out_degree_1151  1
    arc_1_16_13  original_T_including_depot_unload_1157  2.4370949895474209e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_13  arc_capacity_1094  1
    load_1_16_13  free_load_conservation_1138  -1
    load_1_16_13  free_load_conservation_1156  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_14  arc_capacity_1096  -30
    arc_1_16_14  connected_order_arc_1097  -10
    arc_1_16_14  in_degree_1140  1
    arc_1_16_14  out_degree_1151  1
    arc_1_16_14  original_T_including_depot_unload_1157  7.2696582003770027e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_14  arc_capacity_1096  1
    load_1_16_14  free_load_conservation_1144  -1
    load_1_16_14  free_load_conservation_1156  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_15  arc_capacity_1098  -30
    arc_1_16_15  connected_order_arc_1099  -10
    arc_1_16_15  in_degree_1146  1
    arc_1_16_15  out_degree_1151  1
    arc_1_16_15  original_T_including_depot_unload_1157  7.8604521666483390e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_15  arc_capacity_1098  1
    load_1_16_15  free_load_conservation_1150  -1
    load_1_16_15  free_load_conservation_1156  1
RHS
    RHS1      OBJ       -3.8482004348540821e-01
    RHS1      onehot_14_32  1
    RHS1      onehot_13_39  1
    RHS1      onehot_18_74  1
    RHS1      onehot_17_111  1
    RHS1      onehot_20_146  1
    RHS1      onehot_12_181  1
    RHS1      onehot_1_216  1
    RHS1      onehot_10_223  1
    RHS1      stock_ub_227  33
    RHS1      parent_nonstrict_scope_228  6.0608384137772275e-01
    RHS1      normalization_285  1
    RHS1      connected_order_arc_398  -15
    RHS1      connected_order_arc_400  -15
    RHS1      connected_order_arc_402  -15
    RHS1      connected_order_arc_404  -15
    RHS1      connected_order_arc_406  -15
    RHS1      connected_order_arc_408  -15
    RHS1      connected_order_arc_410  -15
    RHS1      connected_order_arc_412  -15
    RHS1      connected_order_arc_414  -15
    RHS1      connected_order_arc_416  -15
    RHS1      connected_order_arc_418  -15
    RHS1      connected_order_arc_420  -15
    RHS1      connected_order_arc_422  -15
    RHS1      connected_order_arc_424  -15
    RHS1      connected_order_arc_427  -15
    RHS1      connected_order_arc_429  -15
    RHS1      connected_order_arc_431  -15
    RHS1      connected_order_arc_433  -15
    RHS1      connected_order_arc_435  -15
    RHS1      connected_order_arc_437  -15
    RHS1      connected_order_arc_439  -15
    RHS1      connected_order_arc_441  -15
    RHS1      connected_order_arc_443  -15
    RHS1      connected_order_arc_445  -15
    RHS1      connected_order_arc_447  -15
    RHS1      connected_order_arc_449  -15
    RHS1      connected_order_arc_451  -15
    RHS1      connected_order_arc_453  -15
    RHS1      connected_order_arc_456  -15
    RHS1      connected_order_arc_458  -15
    RHS1      connected_order_arc_460  -15
    RHS1      connected_order_arc_462  -15
    RHS1      connected_order_arc_464  -15
    RHS1      connected_order_arc_466  -15
    RHS1      connected_order_arc_468  -15
    RHS1      connected_order_arc_470  -15
    RHS1      connected_order_arc_472  -15
    RHS1      connected_order_arc_474  -15
    RHS1      connected_order_arc_476  -15
    RHS1      connected_order_arc_478  -15
    RHS1      connected_order_arc_480  -15
    RHS1      connected_order_arc_482  -15
    RHS1      connected_order_arc_485  -15
    RHS1      connected_order_arc_487  -15
    RHS1      connected_order_arc_489  -15
    RHS1      connected_order_arc_491  -15
    RHS1      connected_order_arc_493  -15
    RHS1      connected_order_arc_495  -15
    RHS1      connected_order_arc_497  -15
    RHS1      connected_order_arc_499  -15
    RHS1      connected_order_arc_501  -15
    RHS1      connected_order_arc_503  -15
    RHS1      connected_order_arc_505  -15
    RHS1      connected_order_arc_507  -15
    RHS1      connected_order_arc_509  -15
    RHS1      connected_order_arc_511  -15
    RHS1      connected_order_arc_514  -15
    RHS1      connected_order_arc_516  -15
    RHS1      connected_order_arc_518  -15
    RHS1      connected_order_arc_520  -15
    RHS1      connected_order_arc_522  -15
    RHS1      connected_order_arc_524  -15
    RHS1      connected_order_arc_526  -15
    RHS1      connected_order_arc_528  -15
    RHS1      connected_order_arc_530  -15
    RHS1      connected_order_arc_532  -15
    RHS1      connected_order_arc_534  -15
    RHS1      connected_order_arc_536  -15
    RHS1      connected_order_arc_538  -15
    RHS1      connected_order_arc_540  -15
    RHS1      connected_order_arc_543  -15
    RHS1      connected_order_arc_545  -15
    RHS1      connected_order_arc_547  -15
    RHS1      connected_order_arc_549  -15
    RHS1      connected_order_arc_551  -15
    RHS1      connected_order_arc_553  -15
    RHS1      connected_order_arc_555  -15
    RHS1      connected_order_arc_557  -15
    RHS1      connected_order_arc_559  -15
    RHS1      connected_order_arc_561  -15
    RHS1      connected_order_arc_563  -15
    RHS1      connected_order_arc_565  -15
    RHS1      connected_order_arc_567  -15
    RHS1      connected_order_arc_569  -15
    RHS1      connected_order_arc_572  -15
    RHS1      connected_order_arc_574  -15
    RHS1      connected_order_arc_576  -15
    RHS1      connected_order_arc_578  -15
    RHS1      connected_order_arc_580  -15
    RHS1      connected_order_arc_582  -15
    RHS1      connected_order_arc_584  -15
    RHS1      connected_order_arc_586  -15
    RHS1      connected_order_arc_588  -15
    RHS1      connected_order_arc_590  -15
    RHS1      connected_order_arc_592  -15
    RHS1      connected_order_arc_594  -15
    RHS1      connected_order_arc_596  -15
    RHS1      connected_order_arc_598  -15
    RHS1      connected_order_arc_601  -15
    RHS1      connected_order_arc_603  -15
    RHS1      connected_order_arc_605  -15
    RHS1      connected_order_arc_607  -15
    RHS1      connected_order_arc_609  -15
    RHS1      connected_order_arc_611  -15
    RHS1      connected_order_arc_613  -15
    RHS1      connected_order_arc_615  -15
    RHS1      connected_order_arc_617  -15
    RHS1      connected_order_arc_619  -15
    RHS1      connected_order_arc_621  -15
    RHS1      connected_order_arc_623  -15
    RHS1      connected_order_arc_625  -15
    RHS1      connected_order_arc_627  -15
    RHS1      connected_order_arc_630  -15
    RHS1      connected_order_arc_632  -15
    RHS1      connected_order_arc_634  -15
    RHS1      connected_order_arc_636  -15
    RHS1      connected_order_arc_638  -15
    RHS1      connected_order_arc_640  -15
    RHS1      connected_order_arc_642  -15
    RHS1      connected_order_arc_644  -15
    RHS1      connected_order_arc_646  -15
    RHS1      connected_order_arc_648  -15
    RHS1      connected_order_arc_650  -15
    RHS1      connected_order_arc_652  -15
    RHS1      connected_order_arc_654  -15
    RHS1      connected_order_arc_656  -15
    RHS1      connected_order_arc_659  -15
    RHS1      connected_order_arc_661  -15
    RHS1      connected_order_arc_663  -15
    RHS1      connected_order_arc_665  -15
    RHS1      connected_order_arc_667  -15
    RHS1      connected_order_arc_669  -15
    RHS1      connected_order_arc_671  -15
    RHS1      connected_order_arc_673  -15
    RHS1      connected_order_arc_675  -15
    RHS1      connected_order_arc_677  -15
    RHS1      connected_order_arc_679  -15
    RHS1      connected_order_arc_681  -15
    RHS1      connected_order_arc_683  -15
    RHS1      connected_order_arc_685  -15
    RHS1      connected_order_arc_688  -15
    RHS1      connected_order_arc_690  -15
    RHS1      connected_order_arc_692  -15
    RHS1      connected_order_arc_694  -15
    RHS1      connected_order_arc_696  -15
    RHS1      connected_order_arc_698  -15
    RHS1      connected_order_arc_700  -15
    RHS1      connected_order_arc_702  -15
    RHS1      connected_order_arc_704  -15
    RHS1      connected_order_arc_706  -15
    RHS1      connected_order_arc_708  -15
    RHS1      connected_order_arc_710  -15
    RHS1      connected_order_arc_712  -15
    RHS1      connected_order_arc_714  -15
    RHS1      connected_order_arc_717  -15
    RHS1      connected_order_arc_719  -15
    RHS1      connected_order_arc_721  -15
    RHS1      connected_order_arc_723  -15
    RHS1      connected_order_arc_725  -15
    RHS1      connected_order_arc_727  -15
    RHS1      connected_order_arc_729  -15
    RHS1      connected_order_arc_731  -15
    RHS1      connected_order_arc_733  -15
    RHS1      connected_order_arc_735  -15
    RHS1      connected_order_arc_737  -15
    RHS1      connected_order_arc_739  -15
    RHS1      connected_order_arc_741  -15
    RHS1      connected_order_arc_743  -15
    RHS1      connected_order_arc_746  -15
    RHS1      connected_order_arc_748  -15
    RHS1      connected_order_arc_750  -15
    RHS1      connected_order_arc_752  -15
    RHS1      connected_order_arc_754  -15
    RHS1      connected_order_arc_756  -15
    RHS1      connected_order_arc_758  -15
    RHS1      connected_order_arc_760  -15
    RHS1      connected_order_arc_762  -15
    RHS1      connected_order_arc_764  -15
    RHS1      connected_order_arc_766  -15
    RHS1      connected_order_arc_768  -15
    RHS1      connected_order_arc_770  -15
    RHS1      connected_order_arc_772  -15
    RHS1      connected_order_arc_775  -15
    RHS1      connected_order_arc_777  -15
    RHS1      connected_order_arc_779  -15
    RHS1      connected_order_arc_781  -15
    RHS1      connected_order_arc_783  -15
    RHS1      connected_order_arc_785  -15
    RHS1      connected_order_arc_787  -15
    RHS1      connected_order_arc_789  -15
    RHS1      connected_order_arc_791  -15
    RHS1      connected_order_arc_793  -15
    RHS1      connected_order_arc_795  -15
    RHS1      connected_order_arc_797  -15
    RHS1      connected_order_arc_799  -15
    RHS1      connected_order_arc_801  -15
    RHS1      connected_order_arc_804  -15
    RHS1      connected_order_arc_806  -15
    RHS1      connected_order_arc_808  -15
    RHS1      connected_order_arc_810  -15
    RHS1      connected_order_arc_812  -15
    RHS1      connected_order_arc_814  -15
    RHS1      connected_order_arc_816  -15
    RHS1      connected_order_arc_818  -15
    RHS1      connected_order_arc_820  -15
    RHS1      connected_order_arc_822  -15
    RHS1      connected_order_arc_824  -15
    RHS1      connected_order_arc_826  -15
    RHS1      connected_order_arc_828  -15
    RHS1      connected_order_arc_830  -15
    RHS1      depot_departure_or_bypass_831  1
    RHS1      depot_return_or_bypass_832  1
    RHS1      segment_load_conservation_837  -1
    RHS1      segment_prefix_lb_838  1
    RHS1      segment_prefix_ub_839  30
    RHS1      segment_load_conservation_844  4
    RHS1      segment_prefix_ub_846  26
    RHS1      segment_load_conservation_851  -1
    RHS1      segment_prefix_lb_852  1
    RHS1      segment_prefix_ub_853  30
    RHS1      segment_load_conservation_858  3
    RHS1      segment_prefix_ub_860  27
    RHS1      segment_load_conservation_865  -1
    RHS1      segment_prefix_lb_866  1
    RHS1      segment_prefix_ub_867  30
    RHS1      segment_load_conservation_872  -3
    RHS1      segment_prefix_lb_873  3
    RHS1      segment_prefix_ub_874  30
    RHS1      segment_load_conservation_879  -1
    RHS1      segment_prefix_lb_880  1
    RHS1      segment_prefix_ub_881  30
    RHS1      fixed_segment_relative_order_930  1
    RHS1      fixed_segment_relative_order_931  1
    RHS1      fixed_segment_relative_order_932  1
    RHS1      fixed_segment_relative_order_933  1
    RHS1      fixed_segment_relative_order_934  1
    RHS1      fixed_segment_relative_order_935  1
    RHS1      original_T_including_depot_unload_936  3960
    RHS1      connected_order_arc_949  -9
    RHS1      connected_order_arc_951  -9
    RHS1      connected_order_arc_953  -9
    RHS1      connected_order_arc_955  -9
    RHS1      connected_order_arc_957  -9
    RHS1      connected_order_arc_959  -9
    RHS1      connected_order_arc_961  -9
    RHS1      connected_order_arc_963  -9
    RHS1      connected_order_arc_966  -9
    RHS1      connected_order_arc_968  -9
    RHS1      connected_order_arc_970  -9
    RHS1      connected_order_arc_972  -9
    RHS1      connected_order_arc_974  -9
    RHS1      connected_order_arc_976  -9
    RHS1      connected_order_arc_978  -9
    RHS1      connected_order_arc_980  -9
    RHS1      connected_order_arc_983  -9
    RHS1      connected_order_arc_985  -9
    RHS1      connected_order_arc_987  -9
    RHS1      connected_order_arc_989  -9
    RHS1      connected_order_arc_991  -9
    RHS1      connected_order_arc_993  -9
    RHS1      connected_order_arc_995  -9
    RHS1      connected_order_arc_997  -9
    RHS1      connected_order_arc_1000  -9
    RHS1      connected_order_arc_1002  -9
    RHS1      connected_order_arc_1004  -9
    RHS1      connected_order_arc_1006  -9
    RHS1      connected_order_arc_1008  -9
    RHS1      connected_order_arc_1010  -9
    RHS1      connected_order_arc_1012  -9
    RHS1      connected_order_arc_1014  -9
    RHS1      connected_order_arc_1017  -9
    RHS1      connected_order_arc_1019  -9
    RHS1      connected_order_arc_1021  -9
    RHS1      connected_order_arc_1023  -9
    RHS1      connected_order_arc_1025  -9
    RHS1      connected_order_arc_1027  -9
    RHS1      connected_order_arc_1029  -9
    RHS1      connected_order_arc_1031  -9
    RHS1      connected_order_arc_1034  -9
    RHS1      connected_order_arc_1036  -9
    RHS1      connected_order_arc_1038  -9
    RHS1      connected_order_arc_1040  -9
    RHS1      connected_order_arc_1042  -9
    RHS1      connected_order_arc_1044  -9
    RHS1      connected_order_arc_1046  -9
    RHS1      connected_order_arc_1048  -9
    RHS1      connected_order_arc_1051  -9
    RHS1      connected_order_arc_1053  -9
    RHS1      connected_order_arc_1055  -9
    RHS1      connected_order_arc_1057  -9
    RHS1      connected_order_arc_1059  -9
    RHS1      connected_order_arc_1061  -9
    RHS1      connected_order_arc_1063  -9
    RHS1      connected_order_arc_1065  -9
    RHS1      connected_order_arc_1068  -9
    RHS1      connected_order_arc_1070  -9
    RHS1      connected_order_arc_1072  -9
    RHS1      connected_order_arc_1074  -9
    RHS1      connected_order_arc_1076  -9
    RHS1      connected_order_arc_1078  -9
    RHS1      connected_order_arc_1080  -9
    RHS1      connected_order_arc_1082  -9
    RHS1      connected_order_arc_1085  -9
    RHS1      connected_order_arc_1087  -9
    RHS1      connected_order_arc_1089  -9
    RHS1      connected_order_arc_1091  -9
    RHS1      connected_order_arc_1093  -9
    RHS1      connected_order_arc_1095  -9
    RHS1      connected_order_arc_1097  -9
    RHS1      connected_order_arc_1099  -9
    RHS1      depot_departure_or_bypass_1100  1
    RHS1      depot_return_or_bypass_1101  1
    RHS1      segment_load_conservation_1106  -5
    RHS1      segment_prefix_lb_1107  5
    RHS1      segment_prefix_ub_1108  30
    RHS1      original_T_including_depot_unload_1157  4800
BOUNDS
 LO BND1      t         4.3669635739740753e-02
 UP BND1      t         1.1527377521625362e-01
 UP BND1      q         6.8949543142985426e-01
 BV BND1      x_14_0  
 UP BND1      w_14_0    1.1527377521625362e-01
 BV BND1      x_14_1  
 UP BND1      w_14_1    1.1527377521625362e-01
 BV BND1      x_14_2  
 UP BND1      w_14_2    1.1527377521625362e-01
 BV BND1      x_14_3  
 UP BND1      w_14_3    1.1527377521625362e-01
 BV BND1      x_14_4  
 UP BND1      w_14_4    1.1527377521625362e-01
 BV BND1      x_14_5  
 UP BND1      w_14_5    1.1527377521625362e-01
 BV BND1      x_14_6  
 UP BND1      w_14_6    1.1527377521625362e-01
 BV BND1      x_14_7  
 UP BND1      w_14_7    1.1527377521625362e-01
 BV BND1      x_14_8  
 UP BND1      w_14_8    1.1527377521625362e-01
 BV BND1      x_14_9  
 UP BND1      w_14_9    1.1527377521625362e-01
 BV BND1      x_14_10 
 UP BND1      w_14_10   1.1527377521625362e-01
 BV BND1      x_14_11 
 UP BND1      w_14_11   1.1527377521625362e-01
 BV BND1      x_14_12 
 UP BND1      w_14_12   1.1527377521625362e-01
 BV BND1      x_14_13 
 UP BND1      w_14_13   1.1527377521625362e-01
 BV BND1      x_14_14 
 UP BND1      w_14_14   1.1527377521625362e-01
 BV BND1      x_14_15 
 UP BND1      w_14_15   1.1527377521625362e-01
 UP BND1      rho_14    1
 BV BND1      x_13_0  
 UP BND1      w_13_0    1.1527377521625362e-01
 BV BND1      x_13_1  
 UP BND1      w_13_1    1.1527377521625362e-01
 UP BND1      rho_13    1
 BV BND1      x_18_0  
 UP BND1      w_18_0    1.1527377521625362e-01
 BV BND1      x_18_1  
 UP BND1      w_18_1    1.1527377521625362e-01
 BV BND1      x_18_2  
 UP BND1      w_18_2    1.1527377521625362e-01
 BV BND1      x_18_3  
 UP BND1      w_18_3    1.1527377521625362e-01
 BV BND1      x_18_4  
 UP BND1      w_18_4    1.1527377521625362e-01
 BV BND1      x_18_5  
 UP BND1      w_18_5    1.1527377521625362e-01
 BV BND1      x_18_6  
 UP BND1      w_18_6    1.1527377521625362e-01
 BV BND1      x_18_7  
 UP BND1      w_18_7    1.1527377521625362e-01
 BV BND1      x_18_8  
 UP BND1      w_18_8    1.1527377521625362e-01
 BV BND1      x_18_9  
 UP BND1      w_18_9    1.1527377521625362e-01
 BV BND1      x_18_10 
 UP BND1      w_18_10   1.1527377521625362e-01
 BV BND1      x_18_11 
 UP BND1      w_18_11   1.1527377521625362e-01
 BV BND1      x_18_12 
 UP BND1      w_18_12   1.1527377521625362e-01
 BV BND1      x_18_13 
 UP BND1      w_18_13   1.1527377521625362e-01
 BV BND1      x_18_14 
 UP BND1      w_18_14   1.1527377521625362e-01
 BV BND1      x_18_15 
 UP BND1      w_18_15   1.1527377521625362e-01
 UP BND1      rho_18    1
 BV BND1      x_17_0  
 UP BND1      w_17_0    1.1527377521625362e-01
 BV BND1      x_17_1  
 UP BND1      w_17_1    1.1527377521625362e-01
 BV BND1      x_17_2  
 UP BND1      w_17_2    1.1527377521625362e-01
 BV BND1      x_17_3  
 UP BND1      w_17_3    1.1527377521625362e-01
 BV BND1      x_17_4  
 UP BND1      w_17_4    1.1527377521625362e-01
 BV BND1      x_17_5  
 UP BND1      w_17_5    1.1527377521625362e-01
 BV BND1      x_17_6  
 UP BND1      w_17_6    1.1527377521625362e-01
 BV BND1      x_17_7  
 UP BND1      w_17_7    1.1527377521625362e-01
 BV BND1      x_17_8  
 UP BND1      w_17_8    1.1527377521625362e-01
 BV BND1      x_17_9  
 UP BND1      w_17_9    1.1527377521625362e-01
 BV BND1      x_17_10 
 UP BND1      w_17_10   1.1527377521625362e-01
 BV BND1      x_17_11 
 UP BND1      w_17_11   1.1527377521625362e-01
 BV BND1      x_17_12 
 UP BND1      w_17_12   1.1527377521625362e-01
 BV BND1      x_17_13 
 UP BND1      w_17_13   1.1527377521625362e-01
 BV BND1      x_17_14 
 UP BND1      w_17_14   1.1527377521625362e-01
 BV BND1      x_17_15 
 UP BND1      w_17_15   1.1527377521625362e-01
 BV BND1      x_17_16 
 UP BND1      w_17_16   1.1527377521625362e-01
 UP BND1      rho_17    1
 BV BND1      x_20_0  
 UP BND1      w_20_0    1.1527377521625362e-01
 BV BND1      x_20_1  
 UP BND1      w_20_1    1.1527377521625362e-01
 BV BND1      x_20_2  
 UP BND1      w_20_2    1.1527377521625362e-01
 BV BND1      x_20_3  
 UP BND1      w_20_3    1.1527377521625362e-01
 BV BND1      x_20_4  
 UP BND1      w_20_4    1.1527377521625362e-01
 BV BND1      x_20_5  
 UP BND1      w_20_5    1.1527377521625362e-01
 BV BND1      x_20_6  
 UP BND1      w_20_6    1.1527377521625362e-01
 BV BND1      x_20_7  
 UP BND1      w_20_7    1.1527377521625362e-01
 BV BND1      x_20_8  
 UP BND1      w_20_8    1.1527377521625362e-01
 BV BND1      x_20_9  
 UP BND1      w_20_9    1.1527377521625362e-01
 BV BND1      x_20_10 
 UP BND1      w_20_10   1.1527377521625362e-01
 BV BND1      x_20_11 
 UP BND1      w_20_11   1.1527377521625362e-01
 BV BND1      x_20_12 
 UP BND1      w_20_12   1.1527377521625362e-01
 BV BND1      x_20_13 
 UP BND1      w_20_13   1.1527377521625362e-01
 BV BND1      x_20_14 
 UP BND1      w_20_14   1.1527377521625362e-01
 BV BND1      x_20_15 
 UP BND1      w_20_15   1.1527377521625362e-01
 UP BND1      rho_20    1
 BV BND1      x_12_0  
 UP BND1      w_12_0    1.1527377521625362e-01
 BV BND1      x_12_1  
 UP BND1      w_12_1    1.1527377521625362e-01
 BV BND1      x_12_2  
 UP BND1      w_12_2    1.1527377521625362e-01
 BV BND1      x_12_3  
 UP BND1      w_12_3    1.1527377521625362e-01
 BV BND1      x_12_4  
 UP BND1      w_12_4    1.1527377521625362e-01
 BV BND1      x_12_5  
 UP BND1      w_12_5    1.1527377521625362e-01
 BV BND1      x_12_6  
 UP BND1      w_12_6    1.1527377521625362e-01
 BV BND1      x_12_7  
 UP BND1      w_12_7    1.1527377521625362e-01
 BV BND1      x_12_8  
 UP BND1      w_12_8    1.1527377521625362e-01
 BV BND1      x_12_9  
 UP BND1      w_12_9    1.1527377521625362e-01
 BV BND1      x_12_10 
 UP BND1      w_12_10   1.1527377521625362e-01
 BV BND1      x_12_11 
 UP BND1      w_12_11   1.1527377521625362e-01
 BV BND1      x_12_12 
 UP BND1      w_12_12   1.1527377521625362e-01
 BV BND1      x_12_13 
 UP BND1      w_12_13   1.1527377521625362e-01
 BV BND1      x_12_14 
 UP BND1      w_12_14   1.1527377521625362e-01
 BV BND1      x_12_15 
 UP BND1      w_12_15   1.1527377521625362e-01
 UP BND1      rho_12    1
 BV BND1      x_1_0   
 UP BND1      w_1_0     1.1527377521625362e-01
 BV BND1      x_1_1   
 UP BND1      w_1_1     1.1527377521625362e-01
 BV BND1      x_1_2   
 UP BND1      w_1_2     1.1527377521625362e-01
 BV BND1      x_1_3   
 UP BND1      w_1_3     1.1527377521625362e-01
 BV BND1      x_1_4   
 UP BND1      w_1_4     1.1527377521625362e-01
 BV BND1      x_1_5   
 UP BND1      w_1_5     1.1527377521625362e-01
 BV BND1      x_1_6   
 UP BND1      w_1_6     1.1527377521625362e-01
 BV BND1      x_1_7   
 UP BND1      w_1_7     1.1527377521625362e-01
 BV BND1      x_1_8   
 UP BND1      w_1_8     1.1527377521625362e-01
 BV BND1      x_1_9   
 UP BND1      w_1_9     1.1527377521625362e-01
 BV BND1      x_1_10  
 UP BND1      w_1_10    1.1527377521625362e-01
 BV BND1      x_1_11  
 UP BND1      w_1_11    1.1527377521625362e-01
 BV BND1      x_1_12  
 UP BND1      w_1_12    1.1527377521625362e-01
 BV BND1      x_1_13  
 UP BND1      w_1_13    1.1527377521625362e-01
 BV BND1      x_1_14  
 UP BND1      w_1_14    1.1527377521625362e-01
 BV BND1      x_1_15  
 UP BND1      w_1_15    1.1527377521625362e-01
 UP BND1      rho_1     1
 BV BND1      x_10_0  
 UP BND1      w_10_0    1.1527377521625362e-01
 BV BND1      x_10_1  
 UP BND1      w_10_1    1.1527377521625362e-01
 UP BND1      rho_10    1
 UP BND1      a_14_13   1
 UP BND1      a_14_18   1
 UP BND1      a_14_17   1
 UP BND1      a_14_20   1
 UP BND1      a_14_12   1
 UP BND1      a_14_1    1
 UP BND1      a_14_10   1
 UP BND1      a_13_18   1
 UP BND1      a_13_17   1
 UP BND1      a_13_20   1
 UP BND1      a_13_12   1
 UP BND1      a_13_1    1
 UP BND1      a_13_10   1
 UP BND1      a_18_17   1
 UP BND1      a_18_20   1
 UP BND1      a_18_12   1
 UP BND1      a_18_1    1
 UP BND1      a_18_10   1
 UP BND1      a_17_20   1
 UP BND1      a_17_12   1
 UP BND1      a_17_1    1
 UP BND1      a_17_10   1
 UP BND1      a_20_12   1
 UP BND1      a_20_1    1
 UP BND1      a_20_10   1
 UP BND1      a_12_1    1
 UP BND1      a_12_10   1
 UP BND1      a_1_10    1
 BV BND1      service_0_14_0
 BV BND1      service_0_14_1
 BV BND1      service_0_14_2
 BV BND1      service_0_14_3
 BV BND1      service_0_14_4
 BV BND1      service_0_14_5
 BV BND1      service_0_14_6
 BV BND1      service_0_14_7
 BV BND1      service_0_14_8
 BV BND1      service_0_14_9
 BV BND1      service_0_14_10
 BV BND1      service_0_14_12
 BV BND1      service_0_14_13
 BV BND1      service_0_14_14
 BV BND1      service_0_14_15
 BV BND1      service_1_14_0
 BV BND1      service_1_14_1
 BV BND1      service_1_14_2
 BV BND1      service_1_14_3
 BV BND1      service_1_14_4
 BV BND1      service_1_14_5
 BV BND1      service_1_14_6
 BV BND1      service_1_14_7
 BV BND1      service_1_14_8
 BV BND1      service_1_14_9
 BV BND1      service_1_14_10
 BV BND1      service_1_14_12
 BV BND1      service_1_14_13
 BV BND1      service_1_14_14
 BV BND1      service_1_14_15
 BV BND1      service_0_13_1
 BV BND1      service_1_13_1
 BV BND1      service_0_18_1
 BV BND1      service_0_18_2
 BV BND1      service_0_18_3
 BV BND1      service_0_18_4
 BV BND1      service_0_18_5
 BV BND1      service_0_18_6
 BV BND1      service_0_18_7
 BV BND1      service_0_18_8
 BV BND1      service_0_18_9
 BV BND1      service_0_18_10
 BV BND1      service_0_18_11
 BV BND1      service_0_18_12
 BV BND1      service_0_18_13
 BV BND1      service_0_18_14
 BV BND1      service_0_18_15
 BV BND1      service_1_18_1
 BV BND1      service_1_18_2
 BV BND1      service_1_18_3
 BV BND1      service_1_18_4
 BV BND1      service_1_18_5
 BV BND1      service_1_18_6
 BV BND1      service_1_18_7
 BV BND1      service_1_18_8
 BV BND1      service_1_18_9
 BV BND1      service_1_18_10
 BV BND1      service_1_18_11
 BV BND1      service_1_18_12
 BV BND1      service_1_18_13
 BV BND1      service_1_18_14
 BV BND1      service_1_18_15
 BV BND1      service_0_17_0
 BV BND1      service_0_17_1
 BV BND1      service_0_17_2
 BV BND1      service_0_17_4
 BV BND1      service_0_17_5
 BV BND1      service_0_17_6
 BV BND1      service_0_17_7
 BV BND1      service_0_17_8
 BV BND1      service_0_17_9
 BV BND1      service_0_17_10
 BV BND1      service_0_17_11
 BV BND1      service_0_17_12
 BV BND1      service_0_17_13
 BV BND1      service_0_17_14
 BV BND1      service_0_17_15
 BV BND1      service_0_17_16
 BV BND1      service_1_17_0
 BV BND1      service_1_17_1
 BV BND1      service_1_17_2
 BV BND1      service_1_17_4
 BV BND1      service_1_17_5
 BV BND1      service_1_17_6
 BV BND1      service_1_17_7
 BV BND1      service_1_17_8
 BV BND1      service_1_17_9
 BV BND1      service_1_17_10
 BV BND1      service_1_17_11
 BV BND1      service_1_17_12
 BV BND1      service_1_17_13
 BV BND1      service_1_17_14
 BV BND1      service_1_17_15
 BV BND1      service_1_17_16
 BV BND1      service_0_20_0
 BV BND1      service_0_20_1
 BV BND1      service_0_20_2
 BV BND1      service_0_20_3
 BV BND1      service_0_20_4
 BV BND1      service_0_20_5
 BV BND1      service_0_20_6
 BV BND1      service_0_20_7
 BV BND1      service_0_20_8
 BV BND1      service_0_20_9
 BV BND1      service_0_20_10
 BV BND1      service_0_20_11
 BV BND1      service_0_20_13
 BV BND1      service_0_20_14
 BV BND1      service_0_20_15
 BV BND1      service_1_20_0
 BV BND1      service_1_20_1
 BV BND1      service_1_20_2
 BV BND1      service_1_20_3
 BV BND1      service_1_20_4
 BV BND1      service_1_20_5
 BV BND1      service_1_20_6
 BV BND1      service_1_20_7
 BV BND1      service_1_20_8
 BV BND1      service_1_20_9
 BV BND1      service_1_20_10
 BV BND1      service_1_20_11
 BV BND1      service_1_20_13
 BV BND1      service_1_20_14
 BV BND1      service_1_20_15
 BV BND1      service_0_12_0
 BV BND1      service_0_12_1
 BV BND1      service_0_12_2
 BV BND1      service_0_12_3
 BV BND1      service_0_12_4
 BV BND1      service_0_12_5
 BV BND1      service_0_12_6
 BV BND1      service_0_12_7
 BV BND1      service_0_12_8
 BV BND1      service_0_12_9
 BV BND1      service_0_12_10
 BV BND1      service_0_12_12
 BV BND1      service_0_12_13
 BV BND1      service_0_12_14
 BV BND1      service_0_12_15
 BV BND1      service_1_12_0
 BV BND1      service_1_12_1
 BV BND1      service_1_12_2
 BV BND1      service_1_12_3
 BV BND1      service_1_12_4
 BV BND1      service_1_12_5
 BV BND1      service_1_12_6
 BV BND1      service_1_12_7
 BV BND1      service_1_12_8
 BV BND1      service_1_12_9
 BV BND1      service_1_12_10
 BV BND1      service_1_12_12
 BV BND1      service_1_12_13
 BV BND1      service_1_12_14
 BV BND1      service_1_12_15
 BV BND1      service_0_1_0
 BV BND1      service_0_1_2
 BV BND1      service_0_1_3
 BV BND1      service_0_1_4
 BV BND1      service_0_1_5
 BV BND1      service_0_1_6
 BV BND1      service_0_1_7
 BV BND1      service_0_1_8
 BV BND1      service_0_1_9
 BV BND1      service_0_1_10
 BV BND1      service_0_1_11
 BV BND1      service_0_1_12
 BV BND1      service_0_1_13
 BV BND1      service_0_1_14
 BV BND1      service_0_1_15
 BV BND1      service_1_1_0
 BV BND1      service_1_1_2
 BV BND1      service_1_1_3
 BV BND1      service_1_1_4
 BV BND1      service_1_1_5
 BV BND1      service_1_1_6
 BV BND1      service_1_1_7
 BV BND1      service_1_1_8
 BV BND1      service_1_1_9
 BV BND1      service_1_1_10
 BV BND1      service_1_1_11
 BV BND1      service_1_1_12
 BV BND1      service_1_1_13
 BV BND1      service_1_1_14
 BV BND1      service_1_1_15
 BV BND1      service_0_10_1
 BV BND1      service_1_10_1
 FX BND1      visit_0_1  1
 UP BND1      order_0_1  15
 FX BND1      visit_0_2  1
 UP BND1      order_0_2  15
 FX BND1      visit_0_3  1
 UP BND1      order_0_3  15
 FX BND1      visit_0_4  1
 UP BND1      order_0_4  15
 FX BND1      visit_0_5  1
 UP BND1      order_0_5  15
 FX BND1      visit_0_6  1
 UP BND1      order_0_6  15
 FX BND1      visit_0_7  1
 UP BND1      order_0_7  15
 UP BND1      visit_0_9  1
 UP BND1      order_0_9  15
 UP BND1      visit_0_10  1
 UP BND1      order_0_10  15
 UP BND1      visit_0_11  1
 UP BND1      order_0_11  15
 UP BND1      visit_0_12  1
 UP BND1      order_0_12  15
 UP BND1      visit_0_13  1
 UP BND1      order_0_13  15
 UP BND1      visit_0_14  1
 UP BND1      order_0_14  15
 UP BND1      visit_0_15  1
 UP BND1      order_0_15  15
 UP BND1      visit_0_16  1
 UP BND1      order_0_16  15
 BV BND1      arc_0_0_0
 FX BND1      load_0_0_0  0
 BV BND1      arc_0_0_1
 FX BND1      load_0_0_1  0
 BV BND1      arc_0_0_2
 FX BND1      load_0_0_2  0
 BV BND1      arc_0_0_3
 FX BND1      load_0_0_3  0
 BV BND1      arc_0_0_4
 FX BND1      load_0_0_4  0
 BV BND1      arc_0_0_5
 FX BND1      load_0_0_5  0
 BV BND1      arc_0_0_6
 FX BND1      load_0_0_6  0
 BV BND1      arc_0_0_7
 FX BND1      load_0_0_7  0
 BV BND1      arc_0_0_9
 FX BND1      load_0_0_9  0
 BV BND1      arc_0_0_10
 FX BND1      load_0_0_10  0
 BV BND1      arc_0_0_11
 FX BND1      load_0_0_11  0
 BV BND1      arc_0_0_12
 FX BND1      load_0_0_12  0
 BV BND1      arc_0_0_13
 FX BND1      load_0_0_13  0
 BV BND1      arc_0_0_14
 FX BND1      load_0_0_14  0
 BV BND1      arc_0_0_15
 FX BND1      load_0_0_15  0
 BV BND1      arc_0_0_16
 FX BND1      load_0_0_16  0
 BV BND1      arc_0_1_0
 UP BND1      load_0_1_0  30
 BV BND1      arc_0_1_2
 UP BND1      load_0_1_2  30
 BV BND1      arc_0_1_3
 UP BND1      load_0_1_3  30
 BV BND1      arc_0_1_4
 UP BND1      load_0_1_4  30
 BV BND1      arc_0_1_5
 UP BND1      load_0_1_5  30
 BV BND1      arc_0_1_6
 UP BND1      load_0_1_6  30
 BV BND1      arc_0_1_7
 UP BND1      load_0_1_7  30
 BV BND1      arc_0_1_9
 UP BND1      load_0_1_9  30
 BV BND1      arc_0_1_10
 UP BND1      load_0_1_10  30
 BV BND1      arc_0_1_11
 UP BND1      load_0_1_11  30
 BV BND1      arc_0_1_12
 UP BND1      load_0_1_12  30
 BV BND1      arc_0_1_13
 UP BND1      load_0_1_13  30
 BV BND1      arc_0_1_14
 UP BND1      load_0_1_14  30
 BV BND1      arc_0_1_15
 UP BND1      load_0_1_15  30
 BV BND1      arc_0_1_16
 UP BND1      load_0_1_16  30
 BV BND1      arc_0_2_0
 UP BND1      load_0_2_0  30
 BV BND1      arc_0_2_1
 UP BND1      load_0_2_1  30
 BV BND1      arc_0_2_3
 UP BND1      load_0_2_3  30
 BV BND1      arc_0_2_4
 UP BND1      load_0_2_4  30
 BV BND1      arc_0_2_5
 UP BND1      load_0_2_5  30
 BV BND1      arc_0_2_6
 UP BND1      load_0_2_6  30
 BV BND1      arc_0_2_7
 UP BND1      load_0_2_7  30
 BV BND1      arc_0_2_9
 UP BND1      load_0_2_9  30
 BV BND1      arc_0_2_10
 UP BND1      load_0_2_10  30
 BV BND1      arc_0_2_11
 UP BND1      load_0_2_11  30
 BV BND1      arc_0_2_12
 UP BND1      load_0_2_12  30
 BV BND1      arc_0_2_13
 UP BND1      load_0_2_13  30
 BV BND1      arc_0_2_14
 UP BND1      load_0_2_14  30
 BV BND1      arc_0_2_15
 UP BND1      load_0_2_15  30
 BV BND1      arc_0_2_16
 UP BND1      load_0_2_16  30
 BV BND1      arc_0_3_0
 UP BND1      load_0_3_0  30
 BV BND1      arc_0_3_1
 UP BND1      load_0_3_1  30
 BV BND1      arc_0_3_2
 UP BND1      load_0_3_2  30
 BV BND1      arc_0_3_4
 UP BND1      load_0_3_4  30
 BV BND1      arc_0_3_5
 UP BND1      load_0_3_5  30
 BV BND1      arc_0_3_6
 UP BND1      load_0_3_6  30
 BV BND1      arc_0_3_7
 UP BND1      load_0_3_7  30
 BV BND1      arc_0_3_9
 UP BND1      load_0_3_9  30
 BV BND1      arc_0_3_10
 UP BND1      load_0_3_10  30
 BV BND1      arc_0_3_11
 UP BND1      load_0_3_11  30
 BV BND1      arc_0_3_12
 UP BND1      load_0_3_12  30
 BV BND1      arc_0_3_13
 UP BND1      load_0_3_13  30
 BV BND1      arc_0_3_14
 UP BND1      load_0_3_14  30
 BV BND1      arc_0_3_15
 UP BND1      load_0_3_15  30
 BV BND1      arc_0_3_16
 UP BND1      load_0_3_16  30
 BV BND1      arc_0_4_0
 UP BND1      load_0_4_0  30
 BV BND1      arc_0_4_1
 UP BND1      load_0_4_1  30
 BV BND1      arc_0_4_2
 UP BND1      load_0_4_2  30
 BV BND1      arc_0_4_3
 UP BND1      load_0_4_3  30
 BV BND1      arc_0_4_5
 UP BND1      load_0_4_5  30
 BV BND1      arc_0_4_6
 UP BND1      load_0_4_6  30
 BV BND1      arc_0_4_7
 UP BND1      load_0_4_7  30
 BV BND1      arc_0_4_9
 UP BND1      load_0_4_9  30
 BV BND1      arc_0_4_10
 UP BND1      load_0_4_10  30
 BV BND1      arc_0_4_11
 UP BND1      load_0_4_11  30
 BV BND1      arc_0_4_12
 UP BND1      load_0_4_12  30
 BV BND1      arc_0_4_13
 UP BND1      load_0_4_13  30
 BV BND1      arc_0_4_14
 UP BND1      load_0_4_14  30
 BV BND1      arc_0_4_15
 UP BND1      load_0_4_15  30
 BV BND1      arc_0_4_16
 UP BND1      load_0_4_16  30
 BV BND1      arc_0_5_0
 UP BND1      load_0_5_0  30
 BV BND1      arc_0_5_1
 UP BND1      load_0_5_1  30
 BV BND1      arc_0_5_2
 UP BND1      load_0_5_2  30
 BV BND1      arc_0_5_3
 UP BND1      load_0_5_3  30
 BV BND1      arc_0_5_4
 UP BND1      load_0_5_4  30
 BV BND1      arc_0_5_6
 UP BND1      load_0_5_6  30
 BV BND1      arc_0_5_7
 UP BND1      load_0_5_7  30
 BV BND1      arc_0_5_9
 UP BND1      load_0_5_9  30
 BV BND1      arc_0_5_10
 UP BND1      load_0_5_10  30
 BV BND1      arc_0_5_11
 UP BND1      load_0_5_11  30
 BV BND1      arc_0_5_12
 UP BND1      load_0_5_12  30
 BV BND1      arc_0_5_13
 UP BND1      load_0_5_13  30
 BV BND1      arc_0_5_14
 UP BND1      load_0_5_14  30
 BV BND1      arc_0_5_15
 UP BND1      load_0_5_15  30
 BV BND1      arc_0_5_16
 UP BND1      load_0_5_16  30
 BV BND1      arc_0_6_0
 UP BND1      load_0_6_0  30
 BV BND1      arc_0_6_1
 UP BND1      load_0_6_1  30
 BV BND1      arc_0_6_2
 UP BND1      load_0_6_2  30
 BV BND1      arc_0_6_3
 UP BND1      load_0_6_3  30
 BV BND1      arc_0_6_4
 UP BND1      load_0_6_4  30
 BV BND1      arc_0_6_5
 UP BND1      load_0_6_5  30
 BV BND1      arc_0_6_7
 UP BND1      load_0_6_7  30
 BV BND1      arc_0_6_9
 UP BND1      load_0_6_9  30
 BV BND1      arc_0_6_10
 UP BND1      load_0_6_10  30
 BV BND1      arc_0_6_11
 UP BND1      load_0_6_11  30
 BV BND1      arc_0_6_12
 UP BND1      load_0_6_12  30
 BV BND1      arc_0_6_13
 UP BND1      load_0_6_13  30
 BV BND1      arc_0_6_14
 UP BND1      load_0_6_14  30
 BV BND1      arc_0_6_15
 UP BND1      load_0_6_15  30
 BV BND1      arc_0_6_16
 UP BND1      load_0_6_16  30
 BV BND1      arc_0_7_0
 UP BND1      load_0_7_0  30
 BV BND1      arc_0_7_1
 UP BND1      load_0_7_1  30
 BV BND1      arc_0_7_2
 UP BND1      load_0_7_2  30
 BV BND1      arc_0_7_3
 UP BND1      load_0_7_3  30
 BV BND1      arc_0_7_4
 UP BND1      load_0_7_4  30
 BV BND1      arc_0_7_5
 UP BND1      load_0_7_5  30
 BV BND1      arc_0_7_6
 UP BND1      load_0_7_6  30
 BV BND1      arc_0_7_9
 UP BND1      load_0_7_9  30
 BV BND1      arc_0_7_10
 UP BND1      load_0_7_10  30
 BV BND1      arc_0_7_11
 UP BND1      load_0_7_11  30
 BV BND1      arc_0_7_12
 UP BND1      load_0_7_12  30
 BV BND1      arc_0_7_13
 UP BND1      load_0_7_13  30
 BV BND1      arc_0_7_14
 UP BND1      load_0_7_14  30
 BV BND1      arc_0_7_15
 UP BND1      load_0_7_15  30
 BV BND1      arc_0_7_16
 UP BND1      load_0_7_16  30
 BV BND1      arc_0_9_0
 UP BND1      load_0_9_0  30
 BV BND1      arc_0_9_1
 UP BND1      load_0_9_1  30
 BV BND1      arc_0_9_2
 UP BND1      load_0_9_2  30
 BV BND1      arc_0_9_3
 UP BND1      load_0_9_3  30
 BV BND1      arc_0_9_4
 UP BND1      load_0_9_4  30
 BV BND1      arc_0_9_5
 UP BND1      load_0_9_5  30
 BV BND1      arc_0_9_6
 UP BND1      load_0_9_6  30
 BV BND1      arc_0_9_7
 UP BND1      load_0_9_7  30
 BV BND1      arc_0_9_10
 UP BND1      load_0_9_10  30
 BV BND1      arc_0_9_11
 UP BND1      load_0_9_11  30
 BV BND1      arc_0_9_12
 UP BND1      load_0_9_12  30
 BV BND1      arc_0_9_13
 UP BND1      load_0_9_13  30
 BV BND1      arc_0_9_14
 UP BND1      load_0_9_14  30
 BV BND1      arc_0_9_15
 UP BND1      load_0_9_15  30
 BV BND1      arc_0_9_16
 UP BND1      load_0_9_16  30
 BV BND1      arc_0_10_0
 UP BND1      load_0_10_0  30
 BV BND1      arc_0_10_1
 UP BND1      load_0_10_1  30
 BV BND1      arc_0_10_2
 UP BND1      load_0_10_2  30
 BV BND1      arc_0_10_3
 UP BND1      load_0_10_3  30
 BV BND1      arc_0_10_4
 UP BND1      load_0_10_4  30
 BV BND1      arc_0_10_5
 UP BND1      load_0_10_5  30
 BV BND1      arc_0_10_6
 UP BND1      load_0_10_6  30
 BV BND1      arc_0_10_7
 UP BND1      load_0_10_7  30
 BV BND1      arc_0_10_9
 UP BND1      load_0_10_9  30
 BV BND1      arc_0_10_11
 UP BND1      load_0_10_11  30
 BV BND1      arc_0_10_12
 UP BND1      load_0_10_12  30
 BV BND1      arc_0_10_13
 UP BND1      load_0_10_13  30
 BV BND1      arc_0_10_14
 UP BND1      load_0_10_14  30
 BV BND1      arc_0_10_15
 UP BND1      load_0_10_15  30
 BV BND1      arc_0_10_16
 UP BND1      load_0_10_16  30
 BV BND1      arc_0_11_0
 UP BND1      load_0_11_0  30
 BV BND1      arc_0_11_1
 UP BND1      load_0_11_1  30
 BV BND1      arc_0_11_2
 UP BND1      load_0_11_2  30
 BV BND1      arc_0_11_3
 UP BND1      load_0_11_3  30
 BV BND1      arc_0_11_4
 UP BND1      load_0_11_4  30
 BV BND1      arc_0_11_5
 UP BND1      load_0_11_5  30
 BV BND1      arc_0_11_6
 UP BND1      load_0_11_6  30
 BV BND1      arc_0_11_7
 UP BND1      load_0_11_7  30
 BV BND1      arc_0_11_9
 UP BND1      load_0_11_9  30
 BV BND1      arc_0_11_10
 UP BND1      load_0_11_10  30
 BV BND1      arc_0_11_12
 UP BND1      load_0_11_12  30
 BV BND1      arc_0_11_13
 UP BND1      load_0_11_13  30
 BV BND1      arc_0_11_14
 UP BND1      load_0_11_14  30
 BV BND1      arc_0_11_15
 UP BND1      load_0_11_15  30
 BV BND1      arc_0_11_16
 UP BND1      load_0_11_16  30
 BV BND1      arc_0_12_0
 UP BND1      load_0_12_0  30
 BV BND1      arc_0_12_1
 UP BND1      load_0_12_1  30
 BV BND1      arc_0_12_2
 UP BND1      load_0_12_2  30
 BV BND1      arc_0_12_3
 UP BND1      load_0_12_3  30
 BV BND1      arc_0_12_4
 UP BND1      load_0_12_4  30
 BV BND1      arc_0_12_5
 UP BND1      load_0_12_5  30
 BV BND1      arc_0_12_6
 UP BND1      load_0_12_6  30
 BV BND1      arc_0_12_7
 UP BND1      load_0_12_7  30
 BV BND1      arc_0_12_9
 UP BND1      load_0_12_9  30
 BV BND1      arc_0_12_10
 UP BND1      load_0_12_10  30
 BV BND1      arc_0_12_11
 UP BND1      load_0_12_11  30
 BV BND1      arc_0_12_13
 UP BND1      load_0_12_13  30
 BV BND1      arc_0_12_14
 UP BND1      load_0_12_14  30
 BV BND1      arc_0_12_15
 UP BND1      load_0_12_15  30
 BV BND1      arc_0_12_16
 UP BND1      load_0_12_16  30
 BV BND1      arc_0_13_0
 UP BND1      load_0_13_0  30
 BV BND1      arc_0_13_1
 UP BND1      load_0_13_1  30
 BV BND1      arc_0_13_2
 UP BND1      load_0_13_2  30
 BV BND1      arc_0_13_3
 UP BND1      load_0_13_3  30
 BV BND1      arc_0_13_4
 UP BND1      load_0_13_4  30
 BV BND1      arc_0_13_5
 UP BND1      load_0_13_5  30
 BV BND1      arc_0_13_6
 UP BND1      load_0_13_6  30
 BV BND1      arc_0_13_7
 UP BND1      load_0_13_7  30
 BV BND1      arc_0_13_9
 UP BND1      load_0_13_9  30
 BV BND1      arc_0_13_10
 UP BND1      load_0_13_10  30
 BV BND1      arc_0_13_11
 UP BND1      load_0_13_11  30
 BV BND1      arc_0_13_12
 UP BND1      load_0_13_12  30
 BV BND1      arc_0_13_14
 UP BND1      load_0_13_14  30
 BV BND1      arc_0_13_15
 UP BND1      load_0_13_15  30
 BV BND1      arc_0_13_16
 UP BND1      load_0_13_16  30
 BV BND1      arc_0_14_0
 UP BND1      load_0_14_0  30
 BV BND1      arc_0_14_1
 UP BND1      load_0_14_1  30
 BV BND1      arc_0_14_2
 UP BND1      load_0_14_2  30
 BV BND1      arc_0_14_3
 UP BND1      load_0_14_3  30
 BV BND1      arc_0_14_4
 UP BND1      load_0_14_4  30
 BV BND1      arc_0_14_5
 UP BND1      load_0_14_5  30
 BV BND1      arc_0_14_6
 UP BND1      load_0_14_6  30
 BV BND1      arc_0_14_7
 UP BND1      load_0_14_7  30
 BV BND1      arc_0_14_9
 UP BND1      load_0_14_9  30
 BV BND1      arc_0_14_10
 UP BND1      load_0_14_10  30
 BV BND1      arc_0_14_11
 UP BND1      load_0_14_11  30
 BV BND1      arc_0_14_12
 UP BND1      load_0_14_12  30
 BV BND1      arc_0_14_13
 UP BND1      load_0_14_13  30
 BV BND1      arc_0_14_15
 UP BND1      load_0_14_15  30
 BV BND1      arc_0_14_16
 UP BND1      load_0_14_16  30
 BV BND1      arc_0_15_0
 UP BND1      load_0_15_0  30
 BV BND1      arc_0_15_1
 UP BND1      load_0_15_1  30
 BV BND1      arc_0_15_2
 UP BND1      load_0_15_2  30
 BV BND1      arc_0_15_3
 UP BND1      load_0_15_3  30
 BV BND1      arc_0_15_4
 UP BND1      load_0_15_4  30
 BV BND1      arc_0_15_5
 UP BND1      load_0_15_5  30
 BV BND1      arc_0_15_6
 UP BND1      load_0_15_6  30
 BV BND1      arc_0_15_7
 UP BND1      load_0_15_7  30
 BV BND1      arc_0_15_9
 UP BND1      load_0_15_9  30
 BV BND1      arc_0_15_10
 UP BND1      load_0_15_10  30
 BV BND1      arc_0_15_11
 UP BND1      load_0_15_11  30
 BV BND1      arc_0_15_12
 UP BND1      load_0_15_12  30
 BV BND1      arc_0_15_13
 UP BND1      load_0_15_13  30
 BV BND1      arc_0_15_14
 UP BND1      load_0_15_14  30
 BV BND1      arc_0_15_16
 UP BND1      load_0_15_16  30
 BV BND1      arc_0_16_0
 UP BND1      load_0_16_0  30
 BV BND1      arc_0_16_1
 UP BND1      load_0_16_1  30
 BV BND1      arc_0_16_2
 UP BND1      load_0_16_2  30
 BV BND1      arc_0_16_3
 UP BND1      load_0_16_3  30
 BV BND1      arc_0_16_4
 UP BND1      load_0_16_4  30
 BV BND1      arc_0_16_5
 UP BND1      load_0_16_5  30
 BV BND1      arc_0_16_6
 UP BND1      load_0_16_6  30
 BV BND1      arc_0_16_7
 UP BND1      load_0_16_7  30
 BV BND1      arc_0_16_9
 UP BND1      load_0_16_9  30
 BV BND1      arc_0_16_10
 UP BND1      load_0_16_10  30
 BV BND1      arc_0_16_11
 UP BND1      load_0_16_11  30
 BV BND1      arc_0_16_12
 UP BND1      load_0_16_12  30
 BV BND1      arc_0_16_13
 UP BND1      load_0_16_13  30
 BV BND1      arc_0_16_14
 UP BND1      load_0_16_14  30
 BV BND1      arc_0_16_15
 UP BND1      load_0_16_15  30
 FX BND1      visit_1_8  1
 UP BND1      order_1_8  9
 UP BND1      visit_1_9  1
 UP BND1      order_1_9  9
 UP BND1      visit_1_10  1
 UP BND1      order_1_10  9
 UP BND1      visit_1_11  1
 UP BND1      order_1_11  9
 UP BND1      visit_1_12  1
 UP BND1      order_1_12  9
 UP BND1      visit_1_13  1
 UP BND1      order_1_13  9
 UP BND1      visit_1_14  1
 UP BND1      order_1_14  9
 UP BND1      visit_1_15  1
 UP BND1      order_1_15  9
 UP BND1      visit_1_16  1
 UP BND1      order_1_16  9
 BV BND1      arc_1_0_0
 FX BND1      load_1_0_0  0
 BV BND1      arc_1_0_8
 FX BND1      load_1_0_8  0
 BV BND1      arc_1_0_9
 FX BND1      load_1_0_9  0
 BV BND1      arc_1_0_10
 FX BND1      load_1_0_10  0
 BV BND1      arc_1_0_11
 FX BND1      load_1_0_11  0
 BV BND1      arc_1_0_12
 FX BND1      load_1_0_12  0
 BV BND1      arc_1_0_13
 FX BND1      load_1_0_13  0
 BV BND1      arc_1_0_14
 FX BND1      load_1_0_14  0
 BV BND1      arc_1_0_15
 FX BND1      load_1_0_15  0
 BV BND1      arc_1_0_16
 FX BND1      load_1_0_16  0
 BV BND1      arc_1_8_0
 UP BND1      load_1_8_0  30
 BV BND1      arc_1_8_9
 UP BND1      load_1_8_9  30
 BV BND1      arc_1_8_10
 UP BND1      load_1_8_10  30
 BV BND1      arc_1_8_11
 UP BND1      load_1_8_11  30
 BV BND1      arc_1_8_12
 UP BND1      load_1_8_12  30
 BV BND1      arc_1_8_13
 UP BND1      load_1_8_13  30
 BV BND1      arc_1_8_14
 UP BND1      load_1_8_14  30
 BV BND1      arc_1_8_15
 UP BND1      load_1_8_15  30
 BV BND1      arc_1_8_16
 UP BND1      load_1_8_16  30
 BV BND1      arc_1_9_0
 UP BND1      load_1_9_0  30
 BV BND1      arc_1_9_8
 UP BND1      load_1_9_8  30
 BV BND1      arc_1_9_10
 UP BND1      load_1_9_10  30
 BV BND1      arc_1_9_11
 UP BND1      load_1_9_11  30
 BV BND1      arc_1_9_12
 UP BND1      load_1_9_12  30
 BV BND1      arc_1_9_13
 UP BND1      load_1_9_13  30
 BV BND1      arc_1_9_14
 UP BND1      load_1_9_14  30
 BV BND1      arc_1_9_15
 UP BND1      load_1_9_15  30
 BV BND1      arc_1_9_16
 UP BND1      load_1_9_16  30
 BV BND1      arc_1_10_0
 UP BND1      load_1_10_0  30
 BV BND1      arc_1_10_8
 UP BND1      load_1_10_8  30
 BV BND1      arc_1_10_9
 UP BND1      load_1_10_9  30
 BV BND1      arc_1_10_11
 UP BND1      load_1_10_11  30
 BV BND1      arc_1_10_12
 UP BND1      load_1_10_12  30
 BV BND1      arc_1_10_13
 UP BND1      load_1_10_13  30
 BV BND1      arc_1_10_14
 UP BND1      load_1_10_14  30
 BV BND1      arc_1_10_15
 UP BND1      load_1_10_15  30
 BV BND1      arc_1_10_16
 UP BND1      load_1_10_16  30
 BV BND1      arc_1_11_0
 UP BND1      load_1_11_0  30
 BV BND1      arc_1_11_8
 UP BND1      load_1_11_8  30
 BV BND1      arc_1_11_9
 UP BND1      load_1_11_9  30
 BV BND1      arc_1_11_10
 UP BND1      load_1_11_10  30
 BV BND1      arc_1_11_12
 UP BND1      load_1_11_12  30
 BV BND1      arc_1_11_13
 UP BND1      load_1_11_13  30
 BV BND1      arc_1_11_14
 UP BND1      load_1_11_14  30
 BV BND1      arc_1_11_15
 UP BND1      load_1_11_15  30
 BV BND1      arc_1_11_16
 UP BND1      load_1_11_16  30
 BV BND1      arc_1_12_0
 UP BND1      load_1_12_0  30
 BV BND1      arc_1_12_8
 UP BND1      load_1_12_8  30
 BV BND1      arc_1_12_9
 UP BND1      load_1_12_9  30
 BV BND1      arc_1_12_10
 UP BND1      load_1_12_10  30
 BV BND1      arc_1_12_11
 UP BND1      load_1_12_11  30
 BV BND1      arc_1_12_13
 UP BND1      load_1_12_13  30
 BV BND1      arc_1_12_14
 UP BND1      load_1_12_14  30
 BV BND1      arc_1_12_15
 UP BND1      load_1_12_15  30
 BV BND1      arc_1_12_16
 UP BND1      load_1_12_16  30
 BV BND1      arc_1_13_0
 UP BND1      load_1_13_0  30
 BV BND1      arc_1_13_8
 UP BND1      load_1_13_8  30
 BV BND1      arc_1_13_9
 UP BND1      load_1_13_9  30
 BV BND1      arc_1_13_10
 UP BND1      load_1_13_10  30
 BV BND1      arc_1_13_11
 UP BND1      load_1_13_11  30
 BV BND1      arc_1_13_12
 UP BND1      load_1_13_12  30
 BV BND1      arc_1_13_14
 UP BND1      load_1_13_14  30
 BV BND1      arc_1_13_15
 UP BND1      load_1_13_15  30
 BV BND1      arc_1_13_16
 UP BND1      load_1_13_16  30
 BV BND1      arc_1_14_0
 UP BND1      load_1_14_0  30
 BV BND1      arc_1_14_8
 UP BND1      load_1_14_8  30
 BV BND1      arc_1_14_9
 UP BND1      load_1_14_9  30
 BV BND1      arc_1_14_10
 UP BND1      load_1_14_10  30
 BV BND1      arc_1_14_11
 UP BND1      load_1_14_11  30
 BV BND1      arc_1_14_12
 UP BND1      load_1_14_12  30
 BV BND1      arc_1_14_13
 UP BND1      load_1_14_13  30
 BV BND1      arc_1_14_15
 UP BND1      load_1_14_15  30
 BV BND1      arc_1_14_16
 UP BND1      load_1_14_16  30
 BV BND1      arc_1_15_0
 UP BND1      load_1_15_0  30
 BV BND1      arc_1_15_8
 UP BND1      load_1_15_8  30
 BV BND1      arc_1_15_9
 UP BND1      load_1_15_9  30
 BV BND1      arc_1_15_10
 UP BND1      load_1_15_10  30
 BV BND1      arc_1_15_11
 UP BND1      load_1_15_11  30
 BV BND1      arc_1_15_12
 UP BND1      load_1_15_12  30
 BV BND1      arc_1_15_13
 UP BND1      load_1_15_13  30
 BV BND1      arc_1_15_14
 UP BND1      load_1_15_14  30
 BV BND1      arc_1_15_16
 UP BND1      load_1_15_16  30
 BV BND1      arc_1_16_0
 UP BND1      load_1_16_0  30
 BV BND1      arc_1_16_8
 UP BND1      load_1_16_8  30
 BV BND1      arc_1_16_9
 UP BND1      load_1_16_9  30
 BV BND1      arc_1_16_10
 UP BND1      load_1_16_10  30
 BV BND1      arc_1_16_11
 UP BND1      load_1_16_11  30
 BV BND1      arc_1_16_12
 UP BND1      load_1_16_12  30
 BV BND1      arc_1_16_13
 UP BND1      load_1_16_13  30
 BV BND1      arc_1_16_14
 UP BND1      load_1_16_14  30
 BV BND1      arc_1_16_15
 UP BND1      load_1_16_15  30
ENDATA
