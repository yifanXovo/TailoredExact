* Signature: 0x4660f1c69ddedbdf
NAME 
ROWS
 N  OBJ
 E  onehot_1
 E  mass_1  
 G  R2      
 L  R3      
 G  R4      
 L  R5      
 G  R6      
 L  R7      
 G  R8      
 L  R9      
 G  R10     
 L  R11     
 E  normalized_inventory_1
 E  normalized_ratio_1
 E  onehot_2
 E  mass_2  
 G  R16     
 L  R17     
 G  R18     
 L  R19     
 G  R20     
 L  R21     
 G  R22     
 L  R23     
 G  R24     
 L  R25     
 E  normalized_inventory_2
 E  normalized_ratio_2
 E  onehot_3
 E  mass_3  
 G  R30     
 L  R31     
 G  R32     
 L  R33     
 G  R34     
 L  R35     
 G  R36     
 L  R37     
 G  R38     
 L  R39     
 E  normalized_inventory_3
 E  normalized_ratio_3
 G  hard_lower
 L  hard_upper
 E  normalization
 G  scaled_stock_lower
 L  scaled_stock_upper
 G  R47     
 G  R48     
 G  R49     
 G  R50     
 G  R51     
 G  R52     
 L  true_G_epigraph
 L  physical_G_upper
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    x[1,0]    OBJ       0.5
    x[1,0]    onehot_1  1
    x[1,0]    R2        -2.2222222222222221e-01
    x[1,0]    R3        -2
    x[1,1]    OBJ       -0.625
    x[1,1]    onehot_1  1
    x[1,1]    R4        -2.2222222222222221e-01
    x[1,1]    R5        -2
    x[1,1]    hard_lower  1
    x[1,1]    hard_upper  1
    x[1,2]    OBJ       0.5
    x[1,2]    onehot_1  1
    x[1,2]    R6        -2.2222222222222221e-01
    x[1,2]    R7        -2
    x[1,2]    hard_lower  2
    x[1,2]    hard_upper  2
    x[1,3]    OBJ       -0.375
    x[1,3]    onehot_1  1
    x[1,3]    R8        -2.2222222222222221e-01
    x[1,3]    R9        -2
    x[1,3]    hard_lower  3
    x[1,3]    hard_upper  3
    x[1,4]    OBJ       0.75
    x[1,4]    onehot_1  1
    x[1,4]    R10       -2.2222222222222221e-01
    x[1,4]    R11       -2
    x[1,4]    hard_lower  4
    x[1,4]    hard_upper  4
    x[2,0]    OBJ       0.5
    x[2,0]    onehot_2  1
    x[2,0]    R16       -2.2222222222222221e-01
    x[2,0]    R17       -2
    x[2,1]    OBJ       -0.5625
    x[2,1]    onehot_2  1
    x[2,1]    R18       -2.2222222222222221e-01
    x[2,1]    R19       -2
    x[2,1]    hard_lower  1
    x[2,1]    hard_upper  1
    x[2,2]    OBJ       0.375
    x[2,2]    onehot_2  1
    x[2,2]    R20       -2.2222222222222221e-01
    x[2,2]    R21       -2
    x[2,2]    hard_lower  2
    x[2,2]    hard_upper  2
    x[2,3]    OBJ       -0.5625
    x[2,3]    onehot_2  1
    x[2,3]    R22       -2.2222222222222221e-01
    x[2,3]    R23       -2
    x[2,3]    hard_lower  3
    x[2,3]    hard_upper  3
    x[2,4]    OBJ       0.5
    x[2,4]    onehot_2  1
    x[2,4]    R24       -2.2222222222222221e-01
    x[2,4]    R25       -2
    x[2,4]    hard_lower  4
    x[2,4]    hard_upper  4
    x[3,0]    OBJ       0.5
    x[3,0]    onehot_3  1
    x[3,0]    R30       -2.2222222222222221e-01
    x[3,0]    R31       -2
    x[3,1]    OBJ       -0.53125
    x[3,1]    onehot_3  1
    x[3,1]    R32       -2.2222222222222221e-01
    x[3,1]    R33       -2
    x[3,1]    hard_lower  1
    x[3,1]    hard_upper  1
    x[3,2]    OBJ       0.4375
    x[3,2]    onehot_3  1
    x[3,2]    R34       -2.2222222222222221e-01
    x[3,2]    R35       -2
    x[3,2]    hard_lower  2
    x[3,2]    hard_upper  2
    x[3,3]    OBJ       -0.59375
    x[3,3]    onehot_3  1
    x[3,3]    R36       -2.2222222222222221e-01
    x[3,3]    R37       -2
    x[3,3]    hard_lower  3
    x[3,3]    hard_upper  3
    x[3,4]    OBJ       0.375
    x[3,4]    onehot_3  1
    x[3,4]    R38       -2.2222222222222221e-01
    x[3,4]    R39       -2
    x[3,4]    hard_lower  4
    x[3,4]    hard_upper  4
    MARKER    'MARKER'                 'INTEND'
    w[1,0]    mass_1    1
    w[1,0]    R2        1
    w[1,0]    R3        1
    w[1,1]    mass_1    1
    w[1,1]    R4        1
    w[1,1]    R5        1
    w[1,1]    normalized_inventory_1  -1
    w[1,2]    mass_1    1
    w[1,2]    R6        1
    w[1,2]    R7        1
    w[1,2]    normalized_inventory_1  -2
    w[1,3]    mass_1    1
    w[1,3]    R8        1
    w[1,3]    R9        1
    w[1,3]    normalized_inventory_1  -3
    w[1,4]    mass_1    1
    w[1,4]    R10       1
    w[1,4]    R11       1
    w[1,4]    normalized_inventory_1  -4
    w[2,0]    mass_2    1
    w[2,0]    R16       1
    w[2,0]    R17       1
    w[2,1]    mass_2    1
    w[2,1]    R18       1
    w[2,1]    R19       1
    w[2,1]    normalized_inventory_2  -1
    w[2,2]    mass_2    1
    w[2,2]    R20       1
    w[2,2]    R21       1
    w[2,2]    normalized_inventory_2  -2
    w[2,3]    mass_2    1
    w[2,3]    R22       1
    w[2,3]    R23       1
    w[2,3]    normalized_inventory_2  -3
    w[2,4]    mass_2    1
    w[2,4]    R24       1
    w[2,4]    R25       1
    w[2,4]    normalized_inventory_2  -4
    w[3,0]    mass_3    1
    w[3,0]    R30       1
    w[3,0]    R31       1
    w[3,1]    mass_3    1
    w[3,1]    R32       1
    w[3,1]    R33       1
    w[3,1]    normalized_inventory_3  -1
    w[3,2]    mass_3    1
    w[3,2]    R34       1
    w[3,2]    R35       1
    w[3,2]    normalized_inventory_3  -2
    w[3,3]    mass_3    1
    w[3,3]    R36       1
    w[3,3]    R37       1
    w[3,3]    normalized_inventory_3  -3
    w[3,4]    mass_3    1
    w[3,4]    R38       1
    w[3,4]    R39       1
    w[3,4]    normalized_inventory_3  -4
    t         mass_1    -1
    t         mass_2    -1
    t         mass_3    -1
    t         scaled_stock_lower  -2
    t         scaled_stock_upper  -5
    z[1]      normalized_inventory_1  1
    z[1]      normalized_ratio_1  -1
    z[1]      scaled_stock_lower  1
    z[1]      scaled_stock_upper  1
    z[2]      normalized_inventory_2  1
    z[2]      normalized_ratio_2  -0.5
    z[2]      scaled_stock_lower  1
    z[2]      scaled_stock_upper  1
    z[3]      normalized_inventory_3  1
    z[3]      normalized_ratio_3  -0.25
    z[3]      scaled_stock_lower  1
    z[3]      scaled_stock_upper  1
    r[1]      normalized_ratio_1  1
    r[1]      normalization  1
    r[1]      R47       -1
    r[1]      R48       1
    r[1]      R49       -1
    r[1]      R50       1
    r[2]      normalized_ratio_2  1
    r[2]      normalization  1
    r[2]      R47       1
    r[2]      R48       -1
    r[2]      R51       -1
    r[2]      R52       1
    r[3]      normalized_ratio_3  1
    r[3]      normalization  1
    r[3]      R49       1
    r[3]      R50       -1
    r[3]      R51       1
    r[3]      R52       -1
    a[1,2]    R47       1
    a[1,2]    R48       1
    a[1,2]    true_G_epigraph  1
    a[1,2]    physical_G_upper  1
    a[1,3]    R49       1
    a[1,3]    R50       1
    a[1,3]    true_G_epigraph  1
    a[1,3]    physical_G_upper  1
    a[2,3]    R51       1
    a[2,3]    R52       1
    a[2,3]    true_G_epigraph  1
    a[2,3]    physical_G_upper  1
    q         OBJ       1
    q         true_G_epigraph  -3
RHS
    RHS1      onehot_1  1
    RHS1      onehot_2  1
    RHS1      onehot_3  1
    RHS1      hard_lower  2
    RHS1      hard_upper  5
    RHS1      normalization  1
    RHS1      physical_G_upper  2.25
BOUNDS
 BV BND1      x[1,0]  
 BV BND1      x[1,1]  
 BV BND1      x[1,2]  
 BV BND1      x[1,3]  
 BV BND1      x[1,4]  
 BV BND1      x[2,0]  
 BV BND1      x[2,1]  
 BV BND1      x[2,2]  
 BV BND1      x[2,3]  
 BV BND1      x[2,4]  
 BV BND1      x[3,0]  
 BV BND1      x[3,1]  
 BV BND1      x[3,2]  
 BV BND1      x[3,3]  
 BV BND1      x[3,4]  
 UP BND1      w[1,0]    2
 UP BND1      w[1,1]    2
 UP BND1      w[1,2]    2
 UP BND1      w[1,3]    2
 UP BND1      w[1,4]    2
 UP BND1      w[2,0]    2
 UP BND1      w[2,1]    2
 UP BND1      w[2,2]    2
 UP BND1      w[2,3]    2
 UP BND1      w[2,4]    2
 UP BND1      w[3,0]    2
 UP BND1      w[3,1]    2
 UP BND1      w[3,2]    2
 UP BND1      w[3,3]    2
 UP BND1      w[3,4]    2
 LO BND1      t         2.2222222222222221e-01
 UP BND1      t         2
ENDATA
