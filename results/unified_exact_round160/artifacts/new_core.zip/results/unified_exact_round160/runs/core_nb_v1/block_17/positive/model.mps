* Signature: 0x645ee25923c2b5fd
NAME R160_physical_neighborhood
ROWS
 N  OBJ
 G  product_lb_0
 L  product_ub_1
 G  product_lb_2
 L  product_ub_3
 G  product_lb_4
 L  product_ub_5
 G  product_lb_6
 L  product_ub_7
 G  product_lb_8
 L  product_ub_9
 G  product_lb_10
 L  product_ub_11
 G  product_lb_12
 L  product_ub_13
 G  product_lb_14
 L  product_ub_15
 G  product_lb_16
 L  product_ub_17
 G  product_lb_18
 L  product_ub_19
 G  product_lb_20
 L  product_ub_21
 G  product_lb_22
 L  product_ub_23
 G  product_lb_24
 L  product_ub_25
 G  product_lb_26
 L  product_ub_27
 G  product_lb_28
 L  product_ub_29
 G  product_lb_30
 L  product_ub_31
 G  product_lb_32
 L  product_ub_33
 G  product_lb_34
 L  product_ub_35
 G  product_lb_36
 L  product_ub_37
 G  product_lb_38
 L  product_ub_39
 E  onehot_1_40
 E  normalized_mass_1_41
 E  normalized_ratio_1_42
 G  product_lb_43
 L  product_ub_44
 G  product_lb_45
 L  product_ub_46
 G  product_lb_47
 L  product_ub_48
 G  product_lb_49
 L  product_ub_50
 G  product_lb_51
 L  product_ub_52
 G  product_lb_53
 L  product_ub_54
 G  product_lb_55
 L  product_ub_56
 G  product_lb_57
 L  product_ub_58
 G  product_lb_59
 L  product_ub_60
 G  product_lb_61
 L  product_ub_62
 G  product_lb_63
 L  product_ub_64
 G  product_lb_65
 L  product_ub_66
 G  product_lb_67
 L  product_ub_68
 G  product_lb_69
 L  product_ub_70
 G  product_lb_71
 L  product_ub_72
 G  product_lb_73
 L  product_ub_74
 E  onehot_2_75
 E  normalized_mass_2_76
 E  normalized_ratio_2_77
 G  product_lb_78
 L  product_ub_79
 G  product_lb_80
 L  product_ub_81
 G  product_lb_82
 L  product_ub_83
 G  product_lb_84
 L  product_ub_85
 G  product_lb_86
 L  product_ub_87
 G  product_lb_88
 L  product_ub_89
 G  product_lb_90
 L  product_ub_91
 G  product_lb_92
 L  product_ub_93
 G  product_lb_94
 L  product_ub_95
 G  product_lb_96
 L  product_ub_97
 G  product_lb_98
 L  product_ub_99
 G  product_lb_100
 L  product_ub_101
 G  product_lb_102
 L  product_ub_103
 E  onehot_31_104
 E  normalized_mass_31_105
 E  normalized_ratio_31_106
 G  product_lb_107
 L  product_ub_108
 G  product_lb_109
 L  product_ub_110
 G  product_lb_111
 L  product_ub_112
 G  product_lb_113
 L  product_ub_114
 G  product_lb_115
 L  product_ub_116
 G  product_lb_117
 L  product_ub_118
 G  product_lb_119
 L  product_ub_120
 G  product_lb_121
 L  product_ub_122
 G  product_lb_123
 L  product_ub_124
 G  product_lb_125
 L  product_ub_126
 G  product_lb_127
 L  product_ub_128
 G  product_lb_129
 L  product_ub_130
 G  product_lb_131
 L  product_ub_132
 G  product_lb_133
 L  product_ub_134
 G  product_lb_135
 L  product_ub_136
 G  product_lb_137
 L  product_ub_138
 G  product_lb_139
 L  product_ub_140
 G  product_lb_141
 L  product_ub_142
 E  onehot_3_143
 E  normalized_mass_3_144
 E  normalized_ratio_3_145
 G  product_lb_146
 L  product_ub_147
 G  product_lb_148
 L  product_ub_149
 G  product_lb_150
 L  product_ub_151
 G  product_lb_152
 L  product_ub_153
 G  product_lb_154
 L  product_ub_155
 G  product_lb_156
 L  product_ub_157
 G  product_lb_158
 L  product_ub_159
 G  product_lb_160
 L  product_ub_161
 G  product_lb_162
 L  product_ub_163
 G  product_lb_164
 L  product_ub_165
 G  product_lb_166
 L  product_ub_167
 G  product_lb_168
 L  product_ub_169
 G  product_lb_170
 L  product_ub_171
 E  onehot_16_172
 E  normalized_mass_16_173
 E  normalized_ratio_16_174
 G  product_lb_175
 L  product_ub_176
 G  product_lb_177
 L  product_ub_178
 G  product_lb_179
 L  product_ub_180
 G  product_lb_181
 L  product_ub_182
 G  product_lb_183
 L  product_ub_184
 G  product_lb_185
 L  product_ub_186
 G  product_lb_187
 L  product_ub_188
 G  product_lb_189
 L  product_ub_190
 G  product_lb_191
 L  product_ub_192
 G  product_lb_193
 L  product_ub_194
 G  product_lb_195
 L  product_ub_196
 G  product_lb_197
 L  product_ub_198
 G  product_lb_199
 L  product_ub_200
 G  product_lb_201
 L  product_ub_202
 G  product_lb_203
 L  product_ub_204
 G  product_lb_205
 L  product_ub_206
 E  onehot_4_207
 E  normalized_mass_4_208
 E  normalized_ratio_4_209
 G  product_lb_210
 L  product_ub_211
 G  product_lb_212
 L  product_ub_213
 G  product_lb_214
 L  product_ub_215
 G  product_lb_216
 L  product_ub_217
 G  product_lb_218
 L  product_ub_219
 G  product_lb_220
 L  product_ub_221
 G  product_lb_222
 L  product_ub_223
 G  product_lb_224
 L  product_ub_225
 G  product_lb_226
 L  product_ub_227
 E  onehot_19_228
 E  normalized_mass_19_229
 E  normalized_ratio_19_230
 G  product_lb_231
 L  product_ub_232
 G  product_lb_233
 L  product_ub_234
 G  product_lb_235
 L  product_ub_236
 G  product_lb_237
 L  product_ub_238
 G  product_lb_239
 L  product_ub_240
 G  product_lb_241
 L  product_ub_242
 G  product_lb_243
 L  product_ub_244
 G  product_lb_245
 L  product_ub_246
 G  product_lb_247
 L  product_ub_248
 G  product_lb_249
 L  product_ub_250
 G  product_lb_251
 L  product_ub_252
 G  product_lb_253
 L  product_ub_254
 G  product_lb_255
 L  product_ub_256
 G  product_lb_257
 L  product_ub_258
 G  product_lb_259
 L  product_ub_260
 G  product_lb_261
 L  product_ub_262
 G  product_lb_263
 L  product_ub_264
 E  onehot_5_265
 E  normalized_mass_5_266
 E  normalized_ratio_5_267
 G  stock_lb_268
 L  stock_ub_269
 L  parent_nonstrict_scope_270
 G  block_pair_pos_271
 G  block_pair_neg_272
 G  block_pair_pos_273
 G  block_pair_neg_274
 G  block_pair_pos_275
 G  block_pair_neg_276
 G  block_pair_pos_277
 G  block_pair_neg_278
 G  block_pair_pos_279
 G  block_pair_neg_280
 G  block_pair_pos_281
 G  block_pair_neg_282
 G  block_pair_pos_283
 G  block_pair_neg_284
 G  block_pair_pos_285
 G  block_pair_neg_286
 G  block_pair_pos_287
 G  block_pair_neg_288
 G  block_pair_pos_289
 G  block_pair_neg_290
 G  block_pair_pos_291
 G  block_pair_neg_292
 G  block_pair_pos_293
 G  block_pair_neg_294
 G  block_pair_pos_295
 G  block_pair_neg_296
 G  block_pair_pos_297
 G  block_pair_neg_298
 G  block_pair_pos_299
 G  block_pair_neg_300
 G  block_pair_pos_301
 G  block_pair_neg_302
 G  block_pair_pos_303
 G  block_pair_neg_304
 G  block_pair_pos_305
 G  block_pair_neg_306
 G  block_pair_pos_307
 G  block_pair_neg_308
 G  block_pair_pos_309
 G  block_pair_neg_310
 G  block_pair_pos_311
 G  block_pair_neg_312
 G  block_pair_pos_313
 G  block_pair_neg_314
 G  block_pair_pos_315
 G  block_pair_neg_316
 G  block_pair_pos_317
 G  block_pair_neg_318
 G  block_pair_pos_319
 G  block_pair_neg_320
 G  block_pair_pos_321
 G  block_pair_neg_322
 G  block_pair_pos_323
 G  block_pair_neg_324
 G  block_pair_pos_325
 G  block_pair_neg_326
 E  normalization_327
 G  full_original_Gini_328
 E  unique_nonzero_owner_329
 E  unique_nonzero_owner_330
 E  unique_nonzero_owner_331
 E  unique_nonzero_owner_332
 E  unique_nonzero_owner_333
 E  unique_nonzero_owner_334
 E  unique_nonzero_owner_335
 E  unique_nonzero_owner_336
 E  unique_nonzero_owner_337
 E  unique_nonzero_owner_338
 E  unique_nonzero_owner_339
 E  unique_nonzero_owner_340
 E  unique_nonzero_owner_341
 E  unique_nonzero_owner_342
 E  unique_nonzero_owner_343
 E  unique_nonzero_owner_344
 E  unique_nonzero_owner_345
 E  unique_nonzero_owner_346
 E  unique_nonzero_owner_347
 E  unique_nonzero_owner_348
 E  unique_nonzero_owner_349
 E  unique_nonzero_owner_350
 E  unique_nonzero_owner_351
 E  unique_nonzero_owner_352
 E  unique_nonzero_owner_353
 E  unique_nonzero_owner_354
 E  unique_nonzero_owner_355
 E  unique_nonzero_owner_356
 E  unique_nonzero_owner_357
 E  unique_nonzero_owner_358
 E  unique_nonzero_owner_359
 E  unique_nonzero_owner_360
 E  unique_nonzero_owner_361
 E  unique_nonzero_owner_362
 E  unique_nonzero_owner_363
 E  unique_nonzero_owner_364
 E  unique_nonzero_owner_365
 E  unique_nonzero_owner_366
 E  unique_nonzero_owner_367
 E  unique_nonzero_owner_368
 E  unique_nonzero_owner_369
 E  unique_nonzero_owner_370
 E  unique_nonzero_owner_371
 E  unique_nonzero_owner_372
 E  unique_nonzero_owner_373
 E  unique_nonzero_owner_374
 E  unique_nonzero_owner_375
 E  unique_nonzero_owner_376
 E  unique_nonzero_owner_377
 E  unique_nonzero_owner_378
 E  unique_nonzero_owner_379
 E  unique_nonzero_owner_380
 E  unique_nonzero_owner_381
 E  unique_nonzero_owner_382
 E  unique_nonzero_owner_383
 E  unique_nonzero_owner_384
 E  unique_nonzero_owner_385
 E  unique_nonzero_owner_386
 E  unique_nonzero_owner_387
 E  unique_nonzero_owner_388
 E  unique_nonzero_owner_389
 E  unique_nonzero_owner_390
 E  unique_nonzero_owner_391
 E  unique_nonzero_owner_392
 E  unique_nonzero_owner_393
 E  unique_nonzero_owner_394
 E  unique_nonzero_owner_395
 E  unique_nonzero_owner_396
 E  unique_nonzero_owner_397
 E  unique_nonzero_owner_398
 E  unique_nonzero_owner_399
 E  unique_nonzero_owner_400
 E  unique_nonzero_owner_401
 E  unique_nonzero_owner_402
 E  unique_nonzero_owner_403
 E  unique_nonzero_owner_404
 E  unique_nonzero_owner_405
 E  unique_nonzero_owner_406
 E  unique_nonzero_owner_407
 E  unique_nonzero_owner_408
 E  unique_nonzero_owner_409
 E  unique_nonzero_owner_410
 E  unique_nonzero_owner_411
 E  unique_nonzero_owner_412
 E  unique_nonzero_owner_413
 E  unique_nonzero_owner_414
 E  unique_nonzero_owner_415
 E  unique_nonzero_owner_416
 E  unique_nonzero_owner_417
 E  unique_nonzero_owner_418
 E  unique_nonzero_owner_419
 E  unique_nonzero_owner_420
 E  unique_nonzero_owner_421
 E  unique_nonzero_owner_422
 E  unique_nonzero_owner_423
 E  unique_nonzero_owner_424
 E  unique_nonzero_owner_425
 E  unique_nonzero_owner_426
 E  unique_nonzero_owner_427
 E  unique_nonzero_owner_428
 E  unique_nonzero_owner_429
 E  unique_nonzero_owner_430
 E  unique_nonzero_owner_431
 E  unique_nonzero_owner_432
 E  unique_nonzero_owner_433
 E  unique_nonzero_owner_434
 E  unique_nonzero_owner_435
 E  unique_nonzero_owner_436
 E  unique_nonzero_owner_437
 E  unique_nonzero_owner_438
 E  unique_nonzero_owner_439
 E  unique_nonzero_owner_440
 E  unique_nonzero_owner_441
 E  unique_nonzero_owner_442
 L  arc_capacity_443
 L  arc_capacity_444
 L  arc_capacity_445
 L  arc_capacity_446
 L  arc_capacity_447
 L  arc_capacity_448
 L  arc_capacity_449
 L  arc_capacity_450
 L  arc_capacity_451
 L  arc_capacity_452
 L  arc_capacity_453
 L  arc_capacity_454
 L  arc_capacity_455
 L  arc_capacity_456
 L  arc_capacity_457
 L  arc_capacity_458
 L  arc_capacity_459
 G  connected_order_arc_460
 L  arc_capacity_461
 G  connected_order_arc_462
 L  arc_capacity_463
 G  connected_order_arc_464
 L  arc_capacity_465
 G  connected_order_arc_466
 L  arc_capacity_467
 G  connected_order_arc_468
 L  arc_capacity_469
 G  connected_order_arc_470
 L  arc_capacity_471
 G  connected_order_arc_472
 L  arc_capacity_473
 G  connected_order_arc_474
 L  arc_capacity_475
 G  connected_order_arc_476
 L  arc_capacity_477
 G  connected_order_arc_478
 L  arc_capacity_479
 G  connected_order_arc_480
 L  arc_capacity_481
 G  connected_order_arc_482
 L  arc_capacity_483
 G  connected_order_arc_484
 L  arc_capacity_485
 L  arc_capacity_486
 G  connected_order_arc_487
 L  arc_capacity_488
 G  connected_order_arc_489
 L  arc_capacity_490
 G  connected_order_arc_491
 L  arc_capacity_492
 G  connected_order_arc_493
 L  arc_capacity_494
 G  connected_order_arc_495
 L  arc_capacity_496
 G  connected_order_arc_497
 L  arc_capacity_498
 G  connected_order_arc_499
 L  arc_capacity_500
 G  connected_order_arc_501
 L  arc_capacity_502
 G  connected_order_arc_503
 L  arc_capacity_504
 G  connected_order_arc_505
 L  arc_capacity_506
 G  connected_order_arc_507
 L  arc_capacity_508
 G  connected_order_arc_509
 L  arc_capacity_510
 G  connected_order_arc_511
 L  arc_capacity_512
 L  arc_capacity_513
 G  connected_order_arc_514
 L  arc_capacity_515
 G  connected_order_arc_516
 L  arc_capacity_517
 G  connected_order_arc_518
 L  arc_capacity_519
 G  connected_order_arc_520
 L  arc_capacity_521
 G  connected_order_arc_522
 L  arc_capacity_523
 G  connected_order_arc_524
 L  arc_capacity_525
 G  connected_order_arc_526
 L  arc_capacity_527
 G  connected_order_arc_528
 L  arc_capacity_529
 G  connected_order_arc_530
 L  arc_capacity_531
 G  connected_order_arc_532
 L  arc_capacity_533
 G  connected_order_arc_534
 L  arc_capacity_535
 G  connected_order_arc_536
 L  arc_capacity_537
 G  connected_order_arc_538
 L  arc_capacity_539
 L  arc_capacity_540
 G  connected_order_arc_541
 L  arc_capacity_542
 G  connected_order_arc_543
 L  arc_capacity_544
 G  connected_order_arc_545
 L  arc_capacity_546
 G  connected_order_arc_547
 L  arc_capacity_548
 G  connected_order_arc_549
 L  arc_capacity_550
 G  connected_order_arc_551
 L  arc_capacity_552
 G  connected_order_arc_553
 L  arc_capacity_554
 G  connected_order_arc_555
 L  arc_capacity_556
 G  connected_order_arc_557
 L  arc_capacity_558
 G  connected_order_arc_559
 L  arc_capacity_560
 G  connected_order_arc_561
 L  arc_capacity_562
 G  connected_order_arc_563
 L  arc_capacity_564
 G  connected_order_arc_565
 L  arc_capacity_566
 L  arc_capacity_567
 G  connected_order_arc_568
 L  arc_capacity_569
 G  connected_order_arc_570
 L  arc_capacity_571
 G  connected_order_arc_572
 L  arc_capacity_573
 G  connected_order_arc_574
 L  arc_capacity_575
 G  connected_order_arc_576
 L  arc_capacity_577
 G  connected_order_arc_578
 L  arc_capacity_579
 G  connected_order_arc_580
 L  arc_capacity_581
 G  connected_order_arc_582
 L  arc_capacity_583
 G  connected_order_arc_584
 L  arc_capacity_585
 G  connected_order_arc_586
 L  arc_capacity_587
 G  connected_order_arc_588
 L  arc_capacity_589
 G  connected_order_arc_590
 L  arc_capacity_591
 G  connected_order_arc_592
 L  arc_capacity_593
 L  arc_capacity_594
 G  connected_order_arc_595
 L  arc_capacity_596
 G  connected_order_arc_597
 L  arc_capacity_598
 G  connected_order_arc_599
 L  arc_capacity_600
 G  connected_order_arc_601
 L  arc_capacity_602
 G  connected_order_arc_603
 L  arc_capacity_604
 G  connected_order_arc_605
 L  arc_capacity_606
 G  connected_order_arc_607
 L  arc_capacity_608
 G  connected_order_arc_609
 L  arc_capacity_610
 G  connected_order_arc_611
 L  arc_capacity_612
 G  connected_order_arc_613
 L  arc_capacity_614
 G  connected_order_arc_615
 L  arc_capacity_616
 G  connected_order_arc_617
 L  arc_capacity_618
 G  connected_order_arc_619
 L  arc_capacity_620
 L  arc_capacity_621
 G  connected_order_arc_622
 L  arc_capacity_623
 G  connected_order_arc_624
 L  arc_capacity_625
 G  connected_order_arc_626
 L  arc_capacity_627
 G  connected_order_arc_628
 L  arc_capacity_629
 G  connected_order_arc_630
 L  arc_capacity_631
 G  connected_order_arc_632
 L  arc_capacity_633
 G  connected_order_arc_634
 L  arc_capacity_635
 G  connected_order_arc_636
 L  arc_capacity_637
 G  connected_order_arc_638
 L  arc_capacity_639
 G  connected_order_arc_640
 L  arc_capacity_641
 G  connected_order_arc_642
 L  arc_capacity_643
 G  connected_order_arc_644
 L  arc_capacity_645
 G  connected_order_arc_646
 L  arc_capacity_647
 L  arc_capacity_648
 G  connected_order_arc_649
 L  arc_capacity_650
 G  connected_order_arc_651
 L  arc_capacity_652
 G  connected_order_arc_653
 L  arc_capacity_654
 G  connected_order_arc_655
 L  arc_capacity_656
 G  connected_order_arc_657
 L  arc_capacity_658
 G  connected_order_arc_659
 L  arc_capacity_660
 G  connected_order_arc_661
 L  arc_capacity_662
 G  connected_order_arc_663
 L  arc_capacity_664
 G  connected_order_arc_665
 L  arc_capacity_666
 G  connected_order_arc_667
 L  arc_capacity_668
 G  connected_order_arc_669
 L  arc_capacity_670
 G  connected_order_arc_671
 L  arc_capacity_672
 G  connected_order_arc_673
 L  arc_capacity_674
 L  arc_capacity_675
 G  connected_order_arc_676
 L  arc_capacity_677
 G  connected_order_arc_678
 L  arc_capacity_679
 G  connected_order_arc_680
 L  arc_capacity_681
 G  connected_order_arc_682
 L  arc_capacity_683
 G  connected_order_arc_684
 L  arc_capacity_685
 G  connected_order_arc_686
 L  arc_capacity_687
 G  connected_order_arc_688
 L  arc_capacity_689
 G  connected_order_arc_690
 L  arc_capacity_691
 G  connected_order_arc_692
 L  arc_capacity_693
 G  connected_order_arc_694
 L  arc_capacity_695
 G  connected_order_arc_696
 L  arc_capacity_697
 G  connected_order_arc_698
 L  arc_capacity_699
 G  connected_order_arc_700
 L  arc_capacity_701
 L  arc_capacity_702
 G  connected_order_arc_703
 L  arc_capacity_704
 G  connected_order_arc_705
 L  arc_capacity_706
 G  connected_order_arc_707
 L  arc_capacity_708
 G  connected_order_arc_709
 L  arc_capacity_710
 G  connected_order_arc_711
 L  arc_capacity_712
 G  connected_order_arc_713
 L  arc_capacity_714
 G  connected_order_arc_715
 L  arc_capacity_716
 G  connected_order_arc_717
 L  arc_capacity_718
 G  connected_order_arc_719
 L  arc_capacity_720
 G  connected_order_arc_721
 L  arc_capacity_722
 G  connected_order_arc_723
 L  arc_capacity_724
 G  connected_order_arc_725
 L  arc_capacity_726
 G  connected_order_arc_727
 L  arc_capacity_728
 L  arc_capacity_729
 G  connected_order_arc_730
 L  arc_capacity_731
 G  connected_order_arc_732
 L  arc_capacity_733
 G  connected_order_arc_734
 L  arc_capacity_735
 G  connected_order_arc_736
 L  arc_capacity_737
 G  connected_order_arc_738
 L  arc_capacity_739
 G  connected_order_arc_740
 L  arc_capacity_741
 G  connected_order_arc_742
 L  arc_capacity_743
 G  connected_order_arc_744
 L  arc_capacity_745
 G  connected_order_arc_746
 L  arc_capacity_747
 G  connected_order_arc_748
 L  arc_capacity_749
 G  connected_order_arc_750
 L  arc_capacity_751
 G  connected_order_arc_752
 L  arc_capacity_753
 G  connected_order_arc_754
 L  arc_capacity_755
 L  arc_capacity_756
 G  connected_order_arc_757
 L  arc_capacity_758
 G  connected_order_arc_759
 L  arc_capacity_760
 G  connected_order_arc_761
 L  arc_capacity_762
 G  connected_order_arc_763
 L  arc_capacity_764
 G  connected_order_arc_765
 L  arc_capacity_766
 G  connected_order_arc_767
 L  arc_capacity_768
 G  connected_order_arc_769
 L  arc_capacity_770
 G  connected_order_arc_771
 L  arc_capacity_772
 G  connected_order_arc_773
 L  arc_capacity_774
 G  connected_order_arc_775
 L  arc_capacity_776
 G  connected_order_arc_777
 L  arc_capacity_778
 G  connected_order_arc_779
 L  arc_capacity_780
 G  connected_order_arc_781
 L  arc_capacity_782
 L  arc_capacity_783
 G  connected_order_arc_784
 L  arc_capacity_785
 G  connected_order_arc_786
 L  arc_capacity_787
 G  connected_order_arc_788
 L  arc_capacity_789
 G  connected_order_arc_790
 L  arc_capacity_791
 G  connected_order_arc_792
 L  arc_capacity_793
 G  connected_order_arc_794
 L  arc_capacity_795
 G  connected_order_arc_796
 L  arc_capacity_797
 G  connected_order_arc_798
 L  arc_capacity_799
 G  connected_order_arc_800
 L  arc_capacity_801
 G  connected_order_arc_802
 L  arc_capacity_803
 G  connected_order_arc_804
 L  arc_capacity_805
 G  connected_order_arc_806
 L  arc_capacity_807
 G  connected_order_arc_808
 L  arc_capacity_809
 L  arc_capacity_810
 G  connected_order_arc_811
 L  arc_capacity_812
 G  connected_order_arc_813
 L  arc_capacity_814
 G  connected_order_arc_815
 L  arc_capacity_816
 G  connected_order_arc_817
 L  arc_capacity_818
 G  connected_order_arc_819
 L  arc_capacity_820
 G  connected_order_arc_821
 L  arc_capacity_822
 G  connected_order_arc_823
 L  arc_capacity_824
 G  connected_order_arc_825
 L  arc_capacity_826
 G  connected_order_arc_827
 L  arc_capacity_828
 G  connected_order_arc_829
 L  arc_capacity_830
 G  connected_order_arc_831
 L  arc_capacity_832
 G  connected_order_arc_833
 L  arc_capacity_834
 G  connected_order_arc_835
 E  depot_departure_or_bypass_836
 E  depot_return_or_bypass_837
 E  out_degree_838
 E  in_degree_839
 G  order_active_lb_840
 L  order_active_ub_841
 E  segment_load_conservation_842
 G  segment_prefix_lb_843
 L  segment_prefix_ub_844
 E  out_degree_845
 E  in_degree_846
 G  order_active_lb_847
 L  order_active_ub_848
 E  segment_load_conservation_849
 G  segment_prefix_lb_850
 L  segment_prefix_ub_851
 E  out_degree_852
 E  in_degree_853
 G  order_active_lb_854
 L  order_active_ub_855
 E  segment_load_conservation_856
 G  segment_prefix_lb_857
 L  segment_prefix_ub_858
 E  out_degree_859
 E  in_degree_860
 G  order_active_lb_861
 L  order_active_ub_862
 E  segment_load_conservation_863
 G  segment_prefix_lb_864
 L  segment_prefix_ub_865
 E  out_degree_866
 E  in_degree_867
 G  order_active_lb_868
 L  order_active_ub_869
 E  segment_load_conservation_870
 G  segment_prefix_lb_871
 L  segment_prefix_ub_872
 E  out_degree_873
 E  in_degree_874
 G  order_active_lb_875
 L  order_active_ub_876
 E  segment_load_conservation_877
 G  segment_prefix_lb_878
 L  segment_prefix_ub_879
 E  out_degree_880
 E  in_degree_881
 G  order_active_lb_882
 L  order_active_ub_883
 E  service_visit_def_884
 E  free_load_conservation_885
 E  out_degree_886
 E  in_degree_887
 G  order_active_lb_888
 L  order_active_ub_889
 E  service_visit_def_890
 E  free_load_conservation_891
 E  out_degree_892
 E  in_degree_893
 G  order_active_lb_894
 L  order_active_ub_895
 E  service_visit_def_896
 E  free_load_conservation_897
 E  out_degree_898
 E  in_degree_899
 G  order_active_lb_900
 L  order_active_ub_901
 E  service_visit_def_902
 E  free_load_conservation_903
 E  out_degree_904
 E  in_degree_905
 G  order_active_lb_906
 L  order_active_ub_907
 E  service_visit_def_908
 E  free_load_conservation_909
 E  out_degree_910
 E  in_degree_911
 G  order_active_lb_912
 L  order_active_ub_913
 E  service_visit_def_914
 E  free_load_conservation_915
 E  out_degree_916
 E  in_degree_917
 G  order_active_lb_918
 L  order_active_ub_919
 E  service_visit_def_920
 E  free_load_conservation_921
 E  out_degree_922
 E  in_degree_923
 G  order_active_lb_924
 L  order_active_ub_925
 E  service_visit_def_926
 E  free_load_conservation_927
 G  fixed_segment_relative_order_928
 G  fixed_segment_relative_order_929
 G  fixed_segment_relative_order_930
 G  fixed_segment_relative_order_931
 G  fixed_segment_relative_order_932
 L  original_T_including_depot_unload_933
 L  arc_capacity_934
 L  arc_capacity_935
 L  arc_capacity_936
 L  arc_capacity_937
 L  arc_capacity_938
 L  arc_capacity_939
 L  arc_capacity_940
 L  arc_capacity_941
 L  arc_capacity_942
 L  arc_capacity_943
 L  arc_capacity_944
 L  arc_capacity_945
 L  arc_capacity_946
 L  arc_capacity_947
 L  arc_capacity_948
 L  arc_capacity_949
 G  connected_order_arc_950
 L  arc_capacity_951
 G  connected_order_arc_952
 L  arc_capacity_953
 G  connected_order_arc_954
 L  arc_capacity_955
 G  connected_order_arc_956
 L  arc_capacity_957
 G  connected_order_arc_958
 L  arc_capacity_959
 G  connected_order_arc_960
 L  arc_capacity_961
 G  connected_order_arc_962
 L  arc_capacity_963
 G  connected_order_arc_964
 L  arc_capacity_965
 G  connected_order_arc_966
 L  arc_capacity_967
 G  connected_order_arc_968
 L  arc_capacity_969
 G  connected_order_arc_970
 L  arc_capacity_971
 G  connected_order_arc_972
 L  arc_capacity_973
 L  arc_capacity_974
 G  connected_order_arc_975
 L  arc_capacity_976
 G  connected_order_arc_977
 L  arc_capacity_978
 G  connected_order_arc_979
 L  arc_capacity_980
 G  connected_order_arc_981
 L  arc_capacity_982
 G  connected_order_arc_983
 L  arc_capacity_984
 G  connected_order_arc_985
 L  arc_capacity_986
 G  connected_order_arc_987
 L  arc_capacity_988
 G  connected_order_arc_989
 L  arc_capacity_990
 G  connected_order_arc_991
 L  arc_capacity_992
 G  connected_order_arc_993
 L  arc_capacity_994
 G  connected_order_arc_995
 L  arc_capacity_996
 G  connected_order_arc_997
 L  arc_capacity_998
 L  arc_capacity_999
 G  connected_order_arc_1000
 L  arc_capacity_1001
 G  connected_order_arc_1002
 L  arc_capacity_1003
 G  connected_order_arc_1004
 L  arc_capacity_1005
 G  connected_order_arc_1006
 L  arc_capacity_1007
 G  connected_order_arc_1008
 L  arc_capacity_1009
 G  connected_order_arc_1010
 L  arc_capacity_1011
 G  connected_order_arc_1012
 L  arc_capacity_1013
 G  connected_order_arc_1014
 L  arc_capacity_1015
 G  connected_order_arc_1016
 L  arc_capacity_1017
 G  connected_order_arc_1018
 L  arc_capacity_1019
 G  connected_order_arc_1020
 L  arc_capacity_1021
 G  connected_order_arc_1022
 L  arc_capacity_1023
 L  arc_capacity_1024
 G  connected_order_arc_1025
 L  arc_capacity_1026
 G  connected_order_arc_1027
 L  arc_capacity_1028
 G  connected_order_arc_1029
 L  arc_capacity_1030
 G  connected_order_arc_1031
 L  arc_capacity_1032
 G  connected_order_arc_1033
 L  arc_capacity_1034
 G  connected_order_arc_1035
 L  arc_capacity_1036
 G  connected_order_arc_1037
 L  arc_capacity_1038
 G  connected_order_arc_1039
 L  arc_capacity_1040
 G  connected_order_arc_1041
 L  arc_capacity_1042
 G  connected_order_arc_1043
 L  arc_capacity_1044
 G  connected_order_arc_1045
 L  arc_capacity_1046
 G  connected_order_arc_1047
 L  arc_capacity_1048
 L  arc_capacity_1049
 G  connected_order_arc_1050
 L  arc_capacity_1051
 G  connected_order_arc_1052
 L  arc_capacity_1053
 G  connected_order_arc_1054
 L  arc_capacity_1055
 G  connected_order_arc_1056
 L  arc_capacity_1057
 G  connected_order_arc_1058
 L  arc_capacity_1059
 G  connected_order_arc_1060
 L  arc_capacity_1061
 G  connected_order_arc_1062
 L  arc_capacity_1063
 G  connected_order_arc_1064
 L  arc_capacity_1065
 G  connected_order_arc_1066
 L  arc_capacity_1067
 G  connected_order_arc_1068
 L  arc_capacity_1069
 G  connected_order_arc_1070
 L  arc_capacity_1071
 G  connected_order_arc_1072
 L  arc_capacity_1073
 L  arc_capacity_1074
 G  connected_order_arc_1075
 L  arc_capacity_1076
 G  connected_order_arc_1077
 L  arc_capacity_1078
 G  connected_order_arc_1079
 L  arc_capacity_1080
 G  connected_order_arc_1081
 L  arc_capacity_1082
 G  connected_order_arc_1083
 L  arc_capacity_1084
 G  connected_order_arc_1085
 L  arc_capacity_1086
 G  connected_order_arc_1087
 L  arc_capacity_1088
 G  connected_order_arc_1089
 L  arc_capacity_1090
 G  connected_order_arc_1091
 L  arc_capacity_1092
 G  connected_order_arc_1093
 L  arc_capacity_1094
 G  connected_order_arc_1095
 L  arc_capacity_1096
 G  connected_order_arc_1097
 L  arc_capacity_1098
 L  arc_capacity_1099
 G  connected_order_arc_1100
 L  arc_capacity_1101
 G  connected_order_arc_1102
 L  arc_capacity_1103
 G  connected_order_arc_1104
 L  arc_capacity_1105
 G  connected_order_arc_1106
 L  arc_capacity_1107
 G  connected_order_arc_1108
 L  arc_capacity_1109
 G  connected_order_arc_1110
 L  arc_capacity_1111
 G  connected_order_arc_1112
 L  arc_capacity_1113
 G  connected_order_arc_1114
 L  arc_capacity_1115
 G  connected_order_arc_1116
 L  arc_capacity_1117
 G  connected_order_arc_1118
 L  arc_capacity_1119
 G  connected_order_arc_1120
 L  arc_capacity_1121
 G  connected_order_arc_1122
 L  arc_capacity_1123
 L  arc_capacity_1124
 G  connected_order_arc_1125
 L  arc_capacity_1126
 G  connected_order_arc_1127
 L  arc_capacity_1128
 G  connected_order_arc_1129
 L  arc_capacity_1130
 G  connected_order_arc_1131
 L  arc_capacity_1132
 G  connected_order_arc_1133
 L  arc_capacity_1134
 G  connected_order_arc_1135
 L  arc_capacity_1136
 G  connected_order_arc_1137
 L  arc_capacity_1138
 G  connected_order_arc_1139
 L  arc_capacity_1140
 G  connected_order_arc_1141
 L  arc_capacity_1142
 G  connected_order_arc_1143
 L  arc_capacity_1144
 G  connected_order_arc_1145
 L  arc_capacity_1146
 G  connected_order_arc_1147
 L  arc_capacity_1148
 L  arc_capacity_1149
 G  connected_order_arc_1150
 L  arc_capacity_1151
 G  connected_order_arc_1152
 L  arc_capacity_1153
 G  connected_order_arc_1154
 L  arc_capacity_1155
 G  connected_order_arc_1156
 L  arc_capacity_1157
 G  connected_order_arc_1158
 L  arc_capacity_1159
 G  connected_order_arc_1160
 L  arc_capacity_1161
 G  connected_order_arc_1162
 L  arc_capacity_1163
 G  connected_order_arc_1164
 L  arc_capacity_1165
 G  connected_order_arc_1166
 L  arc_capacity_1167
 G  connected_order_arc_1168
 L  arc_capacity_1169
 G  connected_order_arc_1170
 L  arc_capacity_1171
 G  connected_order_arc_1172
 L  arc_capacity_1173
 L  arc_capacity_1174
 G  connected_order_arc_1175
 L  arc_capacity_1176
 G  connected_order_arc_1177
 L  arc_capacity_1178
 G  connected_order_arc_1179
 L  arc_capacity_1180
 G  connected_order_arc_1181
 L  arc_capacity_1182
 G  connected_order_arc_1183
 L  arc_capacity_1184
 G  connected_order_arc_1185
 L  arc_capacity_1186
 G  connected_order_arc_1187
 L  arc_capacity_1188
 G  connected_order_arc_1189
 L  arc_capacity_1190
 G  connected_order_arc_1191
 L  arc_capacity_1192
 G  connected_order_arc_1193
 L  arc_capacity_1194
 G  connected_order_arc_1195
 L  arc_capacity_1196
 G  connected_order_arc_1197
 L  arc_capacity_1198
 L  arc_capacity_1199
 G  connected_order_arc_1200
 L  arc_capacity_1201
 G  connected_order_arc_1202
 L  arc_capacity_1203
 G  connected_order_arc_1204
 L  arc_capacity_1205
 G  connected_order_arc_1206
 L  arc_capacity_1207
 G  connected_order_arc_1208
 L  arc_capacity_1209
 G  connected_order_arc_1210
 L  arc_capacity_1211
 G  connected_order_arc_1212
 L  arc_capacity_1213
 G  connected_order_arc_1214
 L  arc_capacity_1215
 G  connected_order_arc_1216
 L  arc_capacity_1217
 G  connected_order_arc_1218
 L  arc_capacity_1219
 G  connected_order_arc_1220
 L  arc_capacity_1221
 G  connected_order_arc_1222
 L  arc_capacity_1223
 L  arc_capacity_1224
 G  connected_order_arc_1225
 L  arc_capacity_1226
 G  connected_order_arc_1227
 L  arc_capacity_1228
 G  connected_order_arc_1229
 L  arc_capacity_1230
 G  connected_order_arc_1231
 L  arc_capacity_1232
 G  connected_order_arc_1233
 L  arc_capacity_1234
 G  connected_order_arc_1235
 L  arc_capacity_1236
 G  connected_order_arc_1237
 L  arc_capacity_1238
 G  connected_order_arc_1239
 L  arc_capacity_1240
 G  connected_order_arc_1241
 L  arc_capacity_1242
 G  connected_order_arc_1243
 L  arc_capacity_1244
 G  connected_order_arc_1245
 L  arc_capacity_1246
 G  connected_order_arc_1247
 L  arc_capacity_1248
 L  arc_capacity_1249
 G  connected_order_arc_1250
 L  arc_capacity_1251
 G  connected_order_arc_1252
 L  arc_capacity_1253
 G  connected_order_arc_1254
 L  arc_capacity_1255
 G  connected_order_arc_1256
 L  arc_capacity_1257
 G  connected_order_arc_1258
 L  arc_capacity_1259
 G  connected_order_arc_1260
 L  arc_capacity_1261
 G  connected_order_arc_1262
 L  arc_capacity_1263
 G  connected_order_arc_1264
 L  arc_capacity_1265
 G  connected_order_arc_1266
 L  arc_capacity_1267
 G  connected_order_arc_1268
 L  arc_capacity_1269
 G  connected_order_arc_1270
 L  arc_capacity_1271
 G  connected_order_arc_1272
 E  depot_departure_or_bypass_1273
 E  depot_return_or_bypass_1274
 E  out_degree_1275
 E  in_degree_1276
 G  order_active_lb_1277
 L  order_active_ub_1278
 E  segment_load_conservation_1279
 G  segment_prefix_lb_1280
 L  segment_prefix_ub_1281
 E  out_degree_1282
 E  in_degree_1283
 G  order_active_lb_1284
 L  order_active_ub_1285
 E  segment_load_conservation_1286
 G  segment_prefix_lb_1287
 L  segment_prefix_ub_1288
 E  out_degree_1289
 E  in_degree_1290
 G  order_active_lb_1291
 L  order_active_ub_1292
 E  segment_load_conservation_1293
 G  segment_prefix_lb_1294
 L  segment_prefix_ub_1295
 E  out_degree_1296
 E  in_degree_1297
 G  order_active_lb_1298
 L  order_active_ub_1299
 E  segment_load_conservation_1300
 G  segment_prefix_lb_1301
 L  segment_prefix_ub_1302
 E  out_degree_1303
 E  in_degree_1304
 G  order_active_lb_1305
 L  order_active_ub_1306
 E  segment_load_conservation_1307
 G  segment_prefix_lb_1308
 L  segment_prefix_ub_1309
 E  out_degree_1310
 E  in_degree_1311
 G  order_active_lb_1312
 L  order_active_ub_1313
 E  service_visit_def_1314
 E  free_load_conservation_1315
 E  out_degree_1316
 E  in_degree_1317
 G  order_active_lb_1318
 L  order_active_ub_1319
 E  service_visit_def_1320
 E  free_load_conservation_1321
 E  out_degree_1322
 E  in_degree_1323
 G  order_active_lb_1324
 L  order_active_ub_1325
 E  service_visit_def_1326
 E  free_load_conservation_1327
 E  out_degree_1328
 E  in_degree_1329
 G  order_active_lb_1330
 L  order_active_ub_1331
 E  service_visit_def_1332
 E  free_load_conservation_1333
 E  out_degree_1334
 E  in_degree_1335
 G  order_active_lb_1336
 L  order_active_ub_1337
 E  service_visit_def_1338
 E  free_load_conservation_1339
 E  out_degree_1340
 E  in_degree_1341
 G  order_active_lb_1342
 L  order_active_ub_1343
 E  service_visit_def_1344
 E  free_load_conservation_1345
 E  out_degree_1346
 E  in_degree_1347
 G  order_active_lb_1348
 L  order_active_ub_1349
 E  service_visit_def_1350
 E  free_load_conservation_1351
 E  out_degree_1352
 E  in_degree_1353
 G  order_active_lb_1354
 L  order_active_ub_1355
 E  service_visit_def_1356
 E  free_load_conservation_1357
 G  fixed_segment_relative_order_1358
 G  fixed_segment_relative_order_1359
 G  fixed_segment_relative_order_1360
 G  fixed_segment_relative_order_1361
 L  original_T_including_depot_unload_1362
 L  arc_capacity_1363
 L  arc_capacity_1364
 L  arc_capacity_1365
 L  arc_capacity_1366
 L  arc_capacity_1367
 L  arc_capacity_1368
 L  arc_capacity_1369
 L  arc_capacity_1370
 L  arc_capacity_1371
 L  arc_capacity_1372
 L  arc_capacity_1373
 L  arc_capacity_1374
 L  arc_capacity_1375
 L  arc_capacity_1376
 G  connected_order_arc_1377
 L  arc_capacity_1378
 G  connected_order_arc_1379
 L  arc_capacity_1380
 G  connected_order_arc_1381
 L  arc_capacity_1382
 G  connected_order_arc_1383
 L  arc_capacity_1384
 G  connected_order_arc_1385
 L  arc_capacity_1386
 G  connected_order_arc_1387
 L  arc_capacity_1388
 G  connected_order_arc_1389
 L  arc_capacity_1390
 G  connected_order_arc_1391
 L  arc_capacity_1392
 G  connected_order_arc_1393
 L  arc_capacity_1394
 G  connected_order_arc_1395
 L  arc_capacity_1396
 L  arc_capacity_1397
 G  connected_order_arc_1398
 L  arc_capacity_1399
 G  connected_order_arc_1400
 L  arc_capacity_1401
 G  connected_order_arc_1402
 L  arc_capacity_1403
 G  connected_order_arc_1404
 L  arc_capacity_1405
 G  connected_order_arc_1406
 L  arc_capacity_1407
 G  connected_order_arc_1408
 L  arc_capacity_1409
 G  connected_order_arc_1410
 L  arc_capacity_1411
 G  connected_order_arc_1412
 L  arc_capacity_1413
 G  connected_order_arc_1414
 L  arc_capacity_1415
 G  connected_order_arc_1416
 L  arc_capacity_1417
 L  arc_capacity_1418
 G  connected_order_arc_1419
 L  arc_capacity_1420
 G  connected_order_arc_1421
 L  arc_capacity_1422
 G  connected_order_arc_1423
 L  arc_capacity_1424
 G  connected_order_arc_1425
 L  arc_capacity_1426
 G  connected_order_arc_1427
 L  arc_capacity_1428
 G  connected_order_arc_1429
 L  arc_capacity_1430
 G  connected_order_arc_1431
 L  arc_capacity_1432
 G  connected_order_arc_1433
 L  arc_capacity_1434
 G  connected_order_arc_1435
 L  arc_capacity_1436
 G  connected_order_arc_1437
 L  arc_capacity_1438
 L  arc_capacity_1439
 G  connected_order_arc_1440
 L  arc_capacity_1441
 G  connected_order_arc_1442
 L  arc_capacity_1443
 G  connected_order_arc_1444
 L  arc_capacity_1445
 G  connected_order_arc_1446
 L  arc_capacity_1447
 G  connected_order_arc_1448
 L  arc_capacity_1449
 G  connected_order_arc_1450
 L  arc_capacity_1451
 G  connected_order_arc_1452
 L  arc_capacity_1453
 G  connected_order_arc_1454
 L  arc_capacity_1455
 G  connected_order_arc_1456
 L  arc_capacity_1457
 G  connected_order_arc_1458
 L  arc_capacity_1459
 L  arc_capacity_1460
 G  connected_order_arc_1461
 L  arc_capacity_1462
 G  connected_order_arc_1463
 L  arc_capacity_1464
 G  connected_order_arc_1465
 L  arc_capacity_1466
 G  connected_order_arc_1467
 L  arc_capacity_1468
 G  connected_order_arc_1469
 L  arc_capacity_1470
 G  connected_order_arc_1471
 L  arc_capacity_1472
 G  connected_order_arc_1473
 L  arc_capacity_1474
 G  connected_order_arc_1475
 L  arc_capacity_1476
 G  connected_order_arc_1477
 L  arc_capacity_1478
 G  connected_order_arc_1479
 L  arc_capacity_1480
 L  arc_capacity_1481
 G  connected_order_arc_1482
 L  arc_capacity_1483
 G  connected_order_arc_1484
 L  arc_capacity_1485
 G  connected_order_arc_1486
 L  arc_capacity_1487
 G  connected_order_arc_1488
 L  arc_capacity_1489
 G  connected_order_arc_1490
 L  arc_capacity_1491
 G  connected_order_arc_1492
 L  arc_capacity_1493
 G  connected_order_arc_1494
 L  arc_capacity_1495
 G  connected_order_arc_1496
 L  arc_capacity_1497
 G  connected_order_arc_1498
 L  arc_capacity_1499
 G  connected_order_arc_1500
 L  arc_capacity_1501
 L  arc_capacity_1502
 G  connected_order_arc_1503
 L  arc_capacity_1504
 G  connected_order_arc_1505
 L  arc_capacity_1506
 G  connected_order_arc_1507
 L  arc_capacity_1508
 G  connected_order_arc_1509
 L  arc_capacity_1510
 G  connected_order_arc_1511
 L  arc_capacity_1512
 G  connected_order_arc_1513
 L  arc_capacity_1514
 G  connected_order_arc_1515
 L  arc_capacity_1516
 G  connected_order_arc_1517
 L  arc_capacity_1518
 G  connected_order_arc_1519
 L  arc_capacity_1520
 G  connected_order_arc_1521
 L  arc_capacity_1522
 L  arc_capacity_1523
 G  connected_order_arc_1524
 L  arc_capacity_1525
 G  connected_order_arc_1526
 L  arc_capacity_1527
 G  connected_order_arc_1528
 L  arc_capacity_1529
 G  connected_order_arc_1530
 L  arc_capacity_1531
 G  connected_order_arc_1532
 L  arc_capacity_1533
 G  connected_order_arc_1534
 L  arc_capacity_1535
 G  connected_order_arc_1536
 L  arc_capacity_1537
 G  connected_order_arc_1538
 L  arc_capacity_1539
 G  connected_order_arc_1540
 L  arc_capacity_1541
 G  connected_order_arc_1542
 L  arc_capacity_1543
 L  arc_capacity_1544
 G  connected_order_arc_1545
 L  arc_capacity_1546
 G  connected_order_arc_1547
 L  arc_capacity_1548
 G  connected_order_arc_1549
 L  arc_capacity_1550
 G  connected_order_arc_1551
 L  arc_capacity_1552
 G  connected_order_arc_1553
 L  arc_capacity_1554
 G  connected_order_arc_1555
 L  arc_capacity_1556
 G  connected_order_arc_1557
 L  arc_capacity_1558
 G  connected_order_arc_1559
 L  arc_capacity_1560
 G  connected_order_arc_1561
 L  arc_capacity_1562
 G  connected_order_arc_1563
 L  arc_capacity_1564
 L  arc_capacity_1565
 G  connected_order_arc_1566
 L  arc_capacity_1567
 G  connected_order_arc_1568
 L  arc_capacity_1569
 G  connected_order_arc_1570
 L  arc_capacity_1571
 G  connected_order_arc_1572
 L  arc_capacity_1573
 G  connected_order_arc_1574
 L  arc_capacity_1575
 G  connected_order_arc_1576
 L  arc_capacity_1577
 G  connected_order_arc_1578
 L  arc_capacity_1579
 G  connected_order_arc_1580
 L  arc_capacity_1581
 G  connected_order_arc_1582
 L  arc_capacity_1583
 G  connected_order_arc_1584
 L  arc_capacity_1585
 L  arc_capacity_1586
 G  connected_order_arc_1587
 L  arc_capacity_1588
 G  connected_order_arc_1589
 L  arc_capacity_1590
 G  connected_order_arc_1591
 L  arc_capacity_1592
 G  connected_order_arc_1593
 L  arc_capacity_1594
 G  connected_order_arc_1595
 L  arc_capacity_1596
 G  connected_order_arc_1597
 L  arc_capacity_1598
 G  connected_order_arc_1599
 L  arc_capacity_1600
 G  connected_order_arc_1601
 L  arc_capacity_1602
 G  connected_order_arc_1603
 L  arc_capacity_1604
 G  connected_order_arc_1605
 E  depot_departure_or_bypass_1606
 E  depot_return_or_bypass_1607
 E  out_degree_1608
 E  in_degree_1609
 G  order_active_lb_1610
 L  order_active_ub_1611
 E  segment_load_conservation_1612
 G  segment_prefix_lb_1613
 L  segment_prefix_ub_1614
 E  out_degree_1615
 E  in_degree_1616
 G  order_active_lb_1617
 L  order_active_ub_1618
 E  segment_load_conservation_1619
 G  segment_prefix_lb_1620
 L  segment_prefix_ub_1621
 E  out_degree_1622
 E  in_degree_1623
 G  order_active_lb_1624
 L  order_active_ub_1625
 E  segment_load_conservation_1626
 G  segment_prefix_lb_1627
 L  segment_prefix_ub_1628
 E  out_degree_1629
 E  in_degree_1630
 G  order_active_lb_1631
 L  order_active_ub_1632
 E  service_visit_def_1633
 E  free_load_conservation_1634
 E  out_degree_1635
 E  in_degree_1636
 G  order_active_lb_1637
 L  order_active_ub_1638
 E  service_visit_def_1639
 E  free_load_conservation_1640
 E  out_degree_1641
 E  in_degree_1642
 G  order_active_lb_1643
 L  order_active_ub_1644
 E  service_visit_def_1645
 E  free_load_conservation_1646
 E  out_degree_1647
 E  in_degree_1648
 G  order_active_lb_1649
 L  order_active_ub_1650
 E  service_visit_def_1651
 E  free_load_conservation_1652
 E  out_degree_1653
 E  in_degree_1654
 G  order_active_lb_1655
 L  order_active_ub_1656
 E  service_visit_def_1657
 E  free_load_conservation_1658
 E  out_degree_1659
 E  in_degree_1660
 G  order_active_lb_1661
 L  order_active_ub_1662
 E  service_visit_def_1663
 E  free_load_conservation_1664
 E  out_degree_1665
 E  in_degree_1666
 G  order_active_lb_1667
 L  order_active_ub_1668
 E  service_visit_def_1669
 E  free_load_conservation_1670
 E  out_degree_1671
 E  in_degree_1672
 G  order_active_lb_1673
 L  order_active_ub_1674
 E  service_visit_def_1675
 E  free_load_conservation_1676
 G  fixed_segment_relative_order_1677
 G  fixed_segment_relative_order_1678
 L  original_T_including_depot_unload_1679
COLUMNS
    t         normalized_mass_1_41  -1
    t         normalized_mass_2_76  -1
    t         normalized_mass_31_105  -1
    t         normalized_mass_3_144  -1
    t         normalized_mass_16_173  -1
    t         normalized_mass_4_208  -1
    t         normalized_mass_19_229  -1
    t         normalized_mass_5_266  -1
    t         normalization_327  2.3776190476190479e+01
    t         full_original_Gini_328  -8.8214285714285765e+01
    q         OBJ       1
    q         parent_nonstrict_scope_270  1
    q         full_original_Gini_328  35
    MARKER    'MARKER'                 'INTORG'
    x_1_0     OBJ       0.075
    x_1_0     product_lb_0  -2.5124876618884330e-02
    x_1_0     product_ub_1  -4.2058882435451639e-02
    x_1_0     onehot_1_40  1
    x_1_0     parent_nonstrict_scope_270  0.15
    x_1_0     unique_nonzero_owner_329  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_0     product_lb_0  1
    w_1_0     product_ub_1  1
    w_1_0     normalized_mass_1_41  1
    w_1_0     full_original_Gini_328  -2.3776190476190479e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_1     OBJ       6.0000000000000012e-02
    x_1_1     product_lb_2  -2.5124876618884330e-02
    x_1_1     product_ub_3  -4.2058882435451639e-02
    x_1_1     onehot_1_40  1
    x_1_1     stock_lb_268  1
    x_1_1     stock_ub_269  1
    x_1_1     parent_nonstrict_scope_270  0.135
    x_1_1     unique_nonzero_owner_330  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_1     product_lb_2  1
    w_1_1     product_ub_3  1
    w_1_1     normalized_mass_1_41  1
    w_1_1     normalized_ratio_1_42  -0.1
    w_1_1     full_original_Gini_328  -2.1076190476190472e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_2     OBJ       0.045
    x_1_2     product_lb_4  -2.5124876618884330e-02
    x_1_2     product_ub_5  -4.2058882435451639e-02
    x_1_2     onehot_1_40  1
    x_1_2     stock_lb_268  2
    x_1_2     stock_ub_269  2
    x_1_2     parent_nonstrict_scope_270  0.12
    MARKER    'MARKER'                 'INTEND'
    w_1_2     product_lb_4  1
    w_1_2     product_ub_5  1
    w_1_2     normalized_mass_1_41  1
    w_1_2     normalized_ratio_1_42  -0.2
    w_1_2     full_original_Gini_328  -1.8376190476190477e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_3     OBJ       0.03
    x_1_3     product_lb_6  -2.5124876618884330e-02
    x_1_3     product_ub_7  -4.2058882435451639e-02
    x_1_3     onehot_1_40  1
    x_1_3     stock_lb_268  3
    x_1_3     stock_ub_269  3
    x_1_3     parent_nonstrict_scope_270  0.105
    x_1_3     unique_nonzero_owner_331  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_3     product_lb_6  1
    w_1_3     product_ub_7  1
    w_1_3     normalized_mass_1_41  1
    w_1_3     normalized_ratio_1_42  -3.0000000000000004e-01
    w_1_3     full_original_Gini_328  -1.5776190476190473e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_4     OBJ       0.015
    x_1_4     product_lb_8  -2.5124876618884330e-02
    x_1_4     product_ub_9  -4.2058882435451639e-02
    x_1_4     onehot_1_40  1
    x_1_4     stock_lb_268  4
    x_1_4     stock_ub_269  4
    x_1_4     parent_nonstrict_scope_270  0.09
    x_1_4     unique_nonzero_owner_332  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_4     product_lb_8  1
    w_1_4     product_ub_9  1
    w_1_4     normalized_mass_1_41  1
    w_1_4     normalized_ratio_1_42  -0.4
    w_1_4     full_original_Gini_328  -1.3276190476190473e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_5     product_lb_10  -2.5124876618884330e-02
    x_1_5     product_ub_11  -4.2058882435451639e-02
    x_1_5     onehot_1_40  1
    x_1_5     stock_lb_268  5
    x_1_5     stock_ub_269  5
    x_1_5     parent_nonstrict_scope_270  0.075
    x_1_5     unique_nonzero_owner_333  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_5     product_lb_10  1
    w_1_5     product_ub_11  1
    w_1_5     normalized_mass_1_41  1
    w_1_5     normalized_ratio_1_42  -0.5
    w_1_5     full_original_Gini_328  -1.0976190476190476e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_6     OBJ       -1.5000000000000013e-02
    x_1_6     product_lb_12  -2.5124876618884330e-02
    x_1_6     product_ub_13  -4.2058882435451639e-02
    x_1_6     onehot_1_40  1
    x_1_6     stock_lb_268  6
    x_1_6     stock_ub_269  6
    x_1_6     parent_nonstrict_scope_270  5.9999999999999984e-02
    x_1_6     unique_nonzero_owner_334  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_6     product_lb_12  1
    w_1_6     product_ub_13  1
    w_1_6     normalized_mass_1_41  1
    w_1_6     normalized_ratio_1_42  -6.0000000000000009e-01
    w_1_6     full_original_Gini_328  -8.6761904761904756e+00
    MARKER    'MARKER'                 'INTORG'
    x_1_7     OBJ       -3.0000000000000006e-02
    x_1_7     product_lb_14  -2.5124876618884330e-02
    x_1_7     product_ub_15  -4.2058882435451639e-02
    x_1_7     onehot_1_40  1
    x_1_7     stock_lb_268  7
    x_1_7     stock_ub_269  7
    x_1_7     parent_nonstrict_scope_270  4.4999999999999991e-02
    x_1_7     unique_nonzero_owner_335  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_7     product_lb_14  1
    w_1_7     product_ub_15  1
    w_1_7     normalized_mass_1_41  1
    w_1_7     normalized_ratio_1_42  -7.0000000000000007e-01
    w_1_7     full_original_Gini_328  -6.7761904761904734e+00
    MARKER    'MARKER'                 'INTORG'
    x_1_8     OBJ       -4.5000000000000005e-02
    x_1_8     product_lb_16  -2.5124876618884330e-02
    x_1_8     product_ub_17  -4.2058882435451639e-02
    x_1_8     onehot_1_40  1
    x_1_8     stock_lb_268  8
    x_1_8     stock_ub_269  8
    x_1_8     parent_nonstrict_scope_270  2.9999999999999992e-02
    x_1_8     unique_nonzero_owner_336  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_8     product_lb_16  1
    w_1_8     product_ub_17  1
    w_1_8     normalized_mass_1_41  1
    w_1_8     normalized_ratio_1_42  -0.8
    w_1_8     full_original_Gini_328  -5.5904761904761919e+00
    MARKER    'MARKER'                 'INTORG'
    x_1_9     OBJ       -0.06
    x_1_9     product_lb_18  -2.5124876618884330e-02
    x_1_9     product_ub_19  -4.2058882435451639e-02
    x_1_9     onehot_1_40  1
    x_1_9     stock_lb_268  9
    x_1_9     stock_ub_269  9
    x_1_9     parent_nonstrict_scope_270  1.4999999999999996e-02
    x_1_9     unique_nonzero_owner_337  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_9     product_lb_18  1
    w_1_9     product_ub_19  1
    w_1_9     normalized_mass_1_41  1
    w_1_9     normalized_ratio_1_42  -0.9
    w_1_9     full_original_Gini_328  -5.0238095238095255e+00
    MARKER    'MARKER'                 'INTORG'
    x_1_10    OBJ       -0.075
    x_1_10    product_lb_20  -2.5124876618884330e-02
    x_1_10    product_ub_21  -4.2058882435451639e-02
    x_1_10    onehot_1_40  1
    x_1_10    stock_lb_268  10
    x_1_10    stock_ub_269  10
    x_1_10    unique_nonzero_owner_338  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_10    product_lb_20  1
    w_1_10    product_ub_21  1
    w_1_10    normalized_mass_1_41  1
    w_1_10    normalized_ratio_1_42  -1
    w_1_10    full_original_Gini_328  -4.5238095238095237e+00
    MARKER    'MARKER'                 'INTORG'
    x_1_11    OBJ       -5.9999999999999984e-02
    x_1_11    product_lb_22  -2.5124876618884330e-02
    x_1_11    product_ub_23  -4.2058882435451639e-02
    x_1_11    onehot_1_40  1
    x_1_11    stock_lb_268  11
    x_1_11    stock_ub_269  11
    x_1_11    parent_nonstrict_scope_270  1.5000000000000013e-02
    x_1_11    unique_nonzero_owner_339  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_11    product_lb_22  1
    w_1_11    product_ub_23  1
    w_1_11    normalized_mass_1_41  1
    w_1_11    normalized_ratio_1_42  -1.1
    w_1_11    full_original_Gini_328  -6.6238095238095269e+00
    MARKER    'MARKER'                 'INTORG'
    x_1_12    OBJ       -4.4999999999999971e-02
    x_1_12    product_lb_24  -2.5124876618884330e-02
    x_1_12    product_ub_25  -4.2058882435451639e-02
    x_1_12    onehot_1_40  1
    x_1_12    stock_lb_268  12
    x_1_12    stock_ub_269  12
    x_1_12    parent_nonstrict_scope_270  3.0000000000000027e-02
    x_1_12    unique_nonzero_owner_340  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_12    product_lb_24  1
    w_1_12    product_ub_25  1
    w_1_12    normalized_mass_1_41  1
    w_1_12    normalized_ratio_1_42  -1.2000000000000002e+00
    w_1_12    full_original_Gini_328  -8.7238095238095283e+00
    MARKER    'MARKER'                 'INTORG'
    x_1_13    OBJ       -2.9999999999999992e-02
    x_1_13    product_lb_26  -2.5124876618884330e-02
    x_1_13    product_ub_27  -4.2058882435451639e-02
    x_1_13    onehot_1_40  1
    x_1_13    stock_lb_268  13
    x_1_13    stock_ub_269  13
    x_1_13    parent_nonstrict_scope_270  4.5000000000000005e-02
    x_1_13    unique_nonzero_owner_341  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_13    product_lb_26  1
    w_1_13    product_ub_27  1
    w_1_13    normalized_mass_1_41  1
    w_1_13    normalized_ratio_1_42  -1.3
    w_1_13    full_original_Gini_328  -1.1323809523809524e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_14    OBJ       -1.4999999999999979e-02
    x_1_14    product_lb_28  -2.5124876618884330e-02
    x_1_14    product_ub_29  -4.2058882435451639e-02
    x_1_14    onehot_1_40  1
    x_1_14    stock_lb_268  14
    x_1_14    stock_ub_269  14
    x_1_14    parent_nonstrict_scope_270  6.0000000000000019e-02
    x_1_14    unique_nonzero_owner_342  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_14    product_lb_28  1
    w_1_14    product_ub_29  1
    w_1_14    normalized_mass_1_41  1
    w_1_14    normalized_ratio_1_42  -1.4000000000000001e+00
    w_1_14    full_original_Gini_328  -1.4023809523809531e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_15    product_lb_30  -2.5124876618884330e-02
    x_1_15    product_ub_31  -4.2058882435451639e-02
    x_1_15    onehot_1_40  1
    x_1_15    stock_lb_268  15
    x_1_15    stock_ub_269  15
    x_1_15    parent_nonstrict_scope_270  0.075
    x_1_15    unique_nonzero_owner_343  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_15    product_lb_30  1
    w_1_15    product_ub_31  1
    w_1_15    normalized_mass_1_41  1
    w_1_15    normalized_ratio_1_42  -1.5
    w_1_15    full_original_Gini_328  -1.6723809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_16    OBJ       1.5000000000000013e-02
    x_1_16    product_lb_32  -2.5124876618884330e-02
    x_1_16    product_ub_33  -4.2058882435451639e-02
    x_1_16    onehot_1_40  1
    x_1_16    stock_lb_268  16
    x_1_16    stock_ub_269  16
    x_1_16    parent_nonstrict_scope_270  9.0000000000000011e-02
    x_1_16    unique_nonzero_owner_344  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_16    product_lb_32  1
    w_1_16    product_ub_33  1
    w_1_16    normalized_mass_1_41  1
    w_1_16    normalized_ratio_1_42  -1.6
    w_1_16    full_original_Gini_328  -1.9423809523809524e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_17    OBJ       3.0000000000000027e-02
    x_1_17    product_lb_34  -2.5124876618884330e-02
    x_1_17    product_ub_35  -4.2058882435451639e-02
    x_1_17    onehot_1_40  1
    x_1_17    stock_lb_268  17
    x_1_17    stock_ub_269  17
    x_1_17    parent_nonstrict_scope_270  1.0500000000000002e-01
    x_1_17    unique_nonzero_owner_345  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_17    product_lb_34  1
    w_1_17    product_ub_35  1
    w_1_17    normalized_mass_1_41  1
    w_1_17    normalized_ratio_1_42  -1.7000000000000002e+00
    w_1_17    full_original_Gini_328  -2.2123809523809523e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_18    OBJ       0.045
    x_1_18    product_lb_36  -2.5124876618884330e-02
    x_1_18    product_ub_37  -4.2058882435451639e-02
    x_1_18    onehot_1_40  1
    x_1_18    stock_lb_268  18
    x_1_18    stock_ub_269  18
    x_1_18    parent_nonstrict_scope_270  0.12
    x_1_18    unique_nonzero_owner_346  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_18    product_lb_36  1
    w_1_18    product_ub_37  1
    w_1_18    normalized_mass_1_41  1
    w_1_18    normalized_ratio_1_42  -1.8
    w_1_18    full_original_Gini_328  -2.4823809523809526e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_19    OBJ       6.0000000000000012e-02
    x_1_19    product_lb_38  -2.5124876618884330e-02
    x_1_19    product_ub_39  -4.2058882435451639e-02
    x_1_19    onehot_1_40  1
    x_1_19    stock_lb_268  19
    x_1_19    stock_ub_269  19
    x_1_19    parent_nonstrict_scope_270  0.135
    x_1_19    unique_nonzero_owner_347  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_19    product_lb_38  1
    w_1_19    product_ub_39  1
    w_1_19    normalized_mass_1_41  1
    w_1_19    normalized_ratio_1_42  -1.9000000000000001e+00
    w_1_19    full_original_Gini_328  -2.7523809523809518e+01
    rho_1     normalized_ratio_1_42  1
    rho_1     block_pair_pos_271  -1
    rho_1     block_pair_neg_272  1
    rho_1     block_pair_pos_273  -1
    rho_1     block_pair_neg_274  1
    rho_1     block_pair_pos_275  -1
    rho_1     block_pair_neg_276  1
    rho_1     block_pair_pos_277  -1
    rho_1     block_pair_neg_278  1
    rho_1     block_pair_pos_279  -1
    rho_1     block_pair_neg_280  1
    rho_1     block_pair_pos_281  -1
    rho_1     block_pair_neg_282  1
    rho_1     block_pair_pos_283  -1
    rho_1     block_pair_neg_284  1
    rho_1     normalization_327  1
    MARKER    'MARKER'                 'INTORG'
    x_2_0     OBJ       0.0315
    x_2_0     product_lb_43  -2.5124876618884330e-02
    x_2_0     product_ub_44  -4.2058882435451639e-02
    x_2_0     onehot_2_75  1
    x_2_0     parent_nonstrict_scope_270  0.0735
    MARKER    'MARKER'                 'INTEND'
    w_2_0     product_lb_43  1
    w_2_0     product_ub_44  1
    w_2_0     normalized_mass_2_76  1
    w_2_0     full_original_Gini_328  -2.3776190476190479e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_1     OBJ       2.1000000000000005e-02
    x_2_1     product_lb_45  -2.5124876618884330e-02
    x_2_1     product_ub_46  -4.2058882435451639e-02
    x_2_1     onehot_2_75  1
    x_2_1     stock_lb_268  1
    x_2_1     stock_ub_269  1
    x_2_1     parent_nonstrict_scope_270  0.063
    x_2_1     unique_nonzero_owner_348  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_1     product_lb_45  1
    w_2_1     product_ub_46  1
    w_2_1     normalized_mass_2_76  1
    w_2_1     normalized_ratio_2_77  -1.4285714285714285e-01
    w_2_1     full_original_Gini_328  -1.9919047619047625e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_2     OBJ       1.0500000000000002e-02
    x_2_2     product_lb_47  -2.5124876618884330e-02
    x_2_2     product_ub_48  -4.2058882435451639e-02
    x_2_2     onehot_2_75  1
    x_2_2     stock_lb_268  2
    x_2_2     stock_ub_269  2
    x_2_2     parent_nonstrict_scope_270  0.0525
    x_2_2     unique_nonzero_owner_349  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_2     product_lb_47  1
    w_2_2     product_ub_48  1
    w_2_2     normalized_mass_2_76  1
    w_2_2     normalized_ratio_2_77  -2.8571428571428570e-01
    w_2_2     full_original_Gini_328  -1.6133333333333333e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_3     product_lb_49  -2.5124876618884330e-02
    x_2_3     product_ub_50  -4.2058882435451639e-02
    x_2_3     onehot_2_75  1
    x_2_3     stock_lb_268  3
    x_2_3     stock_ub_269  3
    x_2_3     parent_nonstrict_scope_270  4.1999999999999996e-02
    x_2_3     unique_nonzero_owner_350  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_3     product_lb_49  1
    w_2_3     product_ub_50  1
    w_2_3     normalized_mass_2_76  1
    w_2_3     normalized_ratio_2_77  -4.2857142857142855e-01
    w_2_3     full_original_Gini_328  -1.2619047619047619e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_4     OBJ       -1.0499999999999995e-02
    x_2_4     product_lb_51  -2.5124876618884330e-02
    x_2_4     product_ub_52  -4.2058882435451639e-02
    x_2_4     onehot_2_75  1
    x_2_4     stock_lb_268  4
    x_2_4     stock_ub_269  4
    x_2_4     parent_nonstrict_scope_270  0.0315
    x_2_4     unique_nonzero_owner_351  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_4     product_lb_51  1
    w_2_4     product_ub_52  1
    w_2_4     normalized_mass_2_76  1
    w_2_4     normalized_ratio_2_77  -5.7142857142857140e-01
    w_2_4     full_original_Gini_328  -9.3333333333333357e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_5     OBJ       -2.0999999999999991e-02
    x_2_5     product_lb_53  -2.5124876618884330e-02
    x_2_5     product_ub_54  -4.2058882435451639e-02
    x_2_5     onehot_2_75  1
    x_2_5     stock_lb_268  5
    x_2_5     stock_ub_269  5
    x_2_5     parent_nonstrict_scope_270  2.1000000000000005e-02
    x_2_5     unique_nonzero_owner_352  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_5     product_lb_53  1
    w_2_5     product_ub_54  1
    w_2_5     normalized_mass_2_76  1
    w_2_5     normalized_ratio_2_77  -7.1428571428571419e-01
    w_2_5     full_original_Gini_328  -6.5047619047619047e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_6     OBJ       -3.1499999999999993e-02
    x_2_6     product_lb_55  -2.5124876618884330e-02
    x_2_6     product_ub_56  -4.2058882435451639e-02
    x_2_6     onehot_2_75  1
    x_2_6     stock_lb_268  6
    x_2_6     stock_ub_269  6
    x_2_6     parent_nonstrict_scope_270  1.0500000000000002e-02
    x_2_6     unique_nonzero_owner_353  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_6     product_lb_55  1
    w_2_6     product_ub_56  1
    w_2_6     normalized_mass_2_76  1
    w_2_6     normalized_ratio_2_77  -8.5714285714285710e-01
    w_2_6     full_original_Gini_328  -5.2380952380952390e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_7     OBJ       -4.1999999999999996e-02
    x_2_7     product_lb_57  -2.5124876618884330e-02
    x_2_7     product_ub_58  -4.2058882435451639e-02
    x_2_7     onehot_2_75  1
    x_2_7     stock_lb_268  7
    x_2_7     stock_ub_269  7
    x_2_7     unique_nonzero_owner_354  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_7     product_lb_57  1
    w_2_7     product_ub_58  1
    w_2_7     normalized_mass_2_76  1
    w_2_7     normalized_ratio_2_77  -1
    w_2_7     full_original_Gini_328  -4.5238095238095237e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_8     OBJ       -0.0315
    x_2_8     product_lb_59  -2.5124876618884330e-02
    x_2_8     product_ub_60  -4.2058882435451639e-02
    x_2_8     onehot_2_75  1
    x_2_8     stock_lb_268  8
    x_2_8     stock_ub_269  8
    x_2_8     parent_nonstrict_scope_270  1.0499999999999995e-02
    x_2_8     unique_nonzero_owner_355  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_8     product_lb_59  1
    w_2_8     product_ub_60  1
    w_2_8     normalized_mass_2_76  1
    w_2_8     normalized_ratio_2_77  -1.1428571428571428e+00
    w_2_8     full_original_Gini_328  -7.5238095238095237e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_9     OBJ       -2.1000000000000005e-02
    x_2_9     product_lb_61  -2.5124876618884330e-02
    x_2_9     product_ub_62  -4.2058882435451639e-02
    x_2_9     onehot_2_75  1
    x_2_9     stock_lb_268  9
    x_2_9     stock_ub_269  9
    x_2_9     parent_nonstrict_scope_270  2.0999999999999991e-02
    x_2_9     unique_nonzero_owner_356  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_9     product_lb_61  1
    w_2_9     product_ub_62  1
    w_2_9     normalized_mass_2_76  1
    w_2_9     normalized_ratio_2_77  -1.2857142857142856e+00
    w_2_9     full_original_Gini_328  -1.0938095238095233e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_10    OBJ       -1.0500000000000009e-02
    x_2_10    product_lb_63  -2.5124876618884330e-02
    x_2_10    product_ub_64  -4.2058882435451639e-02
    x_2_10    onehot_2_75  1
    x_2_10    stock_lb_268  10
    x_2_10    stock_ub_269  10
    x_2_10    parent_nonstrict_scope_270  3.1499999999999986e-02
    x_2_10    unique_nonzero_owner_357  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_10    product_lb_63  1
    w_2_10    product_ub_64  1
    w_2_10    normalized_mass_2_76  1
    w_2_10    normalized_ratio_2_77  -1.4285714285714284e+00
    w_2_10    full_original_Gini_328  -1.4795238095238092e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_11    product_lb_65  -2.5124876618884330e-02
    x_2_11    product_ub_66  -4.2058882435451639e-02
    x_2_11    onehot_2_75  1
    x_2_11    stock_lb_268  11
    x_2_11    stock_ub_269  11
    x_2_11    parent_nonstrict_scope_270  4.1999999999999996e-02
    x_2_11    unique_nonzero_owner_358  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_11    product_lb_65  1
    w_2_11    product_ub_66  1
    w_2_11    normalized_mass_2_76  1
    w_2_11    normalized_ratio_2_77  -1.5714285714285714e+00
    w_2_11    full_original_Gini_328  -1.8652380952380952e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_12    OBJ       1.0499999999999995e-02
    x_2_12    product_lb_67  -2.5124876618884330e-02
    x_2_12    product_ub_68  -4.2058882435451639e-02
    x_2_12    onehot_2_75  1
    x_2_12    stock_lb_268  12
    x_2_12    stock_ub_269  12
    x_2_12    parent_nonstrict_scope_270  5.2499999999999991e-02
    x_2_12    unique_nonzero_owner_359  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_12    product_lb_67  1
    w_2_12    product_ub_68  1
    w_2_12    normalized_mass_2_76  1
    w_2_12    normalized_ratio_2_77  -1.7142857142857142e+00
    w_2_12    full_original_Gini_328  -2.2509523809523806e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_13    OBJ       2.0999999999999991e-02
    x_2_13    product_lb_69  -2.5124876618884330e-02
    x_2_13    product_ub_70  -4.2058882435451639e-02
    x_2_13    onehot_2_75  1
    x_2_13    stock_lb_268  13
    x_2_13    stock_ub_269  13
    x_2_13    parent_nonstrict_scope_270  6.2999999999999987e-02
    x_2_13    unique_nonzero_owner_360  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_13    product_lb_69  1
    w_2_13    product_ub_70  1
    w_2_13    normalized_mass_2_76  1
    w_2_13    normalized_ratio_2_77  -1.8571428571428570e+00
    w_2_13    full_original_Gini_328  -2.6366666666666667e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_14    OBJ       0.0315
    x_2_14    product_lb_71  -2.5124876618884330e-02
    x_2_14    product_ub_72  -4.2058882435451639e-02
    x_2_14    onehot_2_75  1
    x_2_14    stock_lb_268  14
    x_2_14    stock_ub_269  14
    x_2_14    parent_nonstrict_scope_270  0.0735
    x_2_14    unique_nonzero_owner_361  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_14    product_lb_71  1
    w_2_14    product_ub_72  1
    w_2_14    normalized_mass_2_76  1
    w_2_14    normalized_ratio_2_77  -2
    w_2_14    full_original_Gini_328  -3.0223809523809521e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_15    OBJ       4.1999999999999996e-02
    x_2_15    product_lb_73  -2.5124876618884330e-02
    x_2_15    product_ub_74  -4.2058882435451639e-02
    x_2_15    onehot_2_75  1
    x_2_15    stock_lb_268  15
    x_2_15    stock_ub_269  15
    x_2_15    parent_nonstrict_scope_270  8.3999999999999991e-02
    x_2_15    unique_nonzero_owner_362  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_15    product_lb_73  1
    w_2_15    product_ub_74  1
    w_2_15    normalized_mass_2_76  1
    w_2_15    normalized_ratio_2_77  -2.1428571428571428e+00
    w_2_15    full_original_Gini_328  -3.4080952380952375e+01
    rho_2     normalized_ratio_2_77  1
    rho_2     block_pair_pos_271  1
    rho_2     block_pair_neg_272  -1
    rho_2     block_pair_pos_285  -1
    rho_2     block_pair_neg_286  1
    rho_2     block_pair_pos_287  -1
    rho_2     block_pair_neg_288  1
    rho_2     block_pair_pos_289  -1
    rho_2     block_pair_neg_290  1
    rho_2     block_pair_pos_291  -1
    rho_2     block_pair_neg_292  1
    rho_2     block_pair_pos_293  -1
    rho_2     block_pair_neg_294  1
    rho_2     block_pair_pos_295  -1
    rho_2     block_pair_neg_296  1
    rho_2     normalization_327  1
    MARKER    'MARKER'                 'INTORG'
    x_31_0    OBJ       0.03675
    x_31_0    product_lb_78  -2.5124876618884330e-02
    x_31_0    product_ub_79  -4.2058882435451639e-02
    x_31_0    onehot_31_104  1
    x_31_0    parent_nonstrict_scope_270  0.0735
    x_31_0    unique_nonzero_owner_363  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_0    product_lb_78  1
    w_31_0    product_ub_79  1
    w_31_0    normalized_mass_31_105  1
    w_31_0    full_original_Gini_328  -2.3776190476190479e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_1    OBJ       2.6250000000000002e-02
    x_31_1    product_lb_80  -2.5124876618884330e-02
    x_31_1    product_ub_81  -4.2058882435451639e-02
    x_31_1    onehot_31_104  1
    x_31_1    stock_lb_268  1
    x_31_1    stock_ub_269  1
    x_31_1    parent_nonstrict_scope_270  0.063
    x_31_1    unique_nonzero_owner_364  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_1    product_lb_80  1
    w_31_1    product_ub_81  1
    w_31_1    normalized_mass_31_105  1
    w_31_1    normalized_ratio_31_106  -1.4285714285714285e-01
    w_31_1    full_original_Gini_328  -1.9919047619047625e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_2    OBJ       0.01575
    x_31_2    product_lb_82  -2.5124876618884330e-02
    x_31_2    product_ub_83  -4.2058882435451639e-02
    x_31_2    onehot_31_104  1
    x_31_2    stock_lb_268  2
    x_31_2    stock_ub_269  2
    x_31_2    parent_nonstrict_scope_270  0.0525
    MARKER    'MARKER'                 'INTEND'
    w_31_2    product_lb_82  1
    w_31_2    product_ub_83  1
    w_31_2    normalized_mass_31_105  1
    w_31_2    normalized_ratio_31_106  -2.8571428571428570e-01
    w_31_2    full_original_Gini_328  -1.6133333333333333e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_3    OBJ       5.2499999999999977e-03
    x_31_3    product_lb_84  -2.5124876618884330e-02
    x_31_3    product_ub_85  -4.2058882435451639e-02
    x_31_3    onehot_31_104  1
    x_31_3    stock_lb_268  3
    x_31_3    stock_ub_269  3
    x_31_3    parent_nonstrict_scope_270  4.1999999999999996e-02
    x_31_3    unique_nonzero_owner_365  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_3    product_lb_84  1
    w_31_3    product_ub_85  1
    w_31_3    normalized_mass_31_105  1
    w_31_3    normalized_ratio_31_106  -4.2857142857142855e-01
    w_31_3    full_original_Gini_328  -1.2619047619047619e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_4    OBJ       -5.2499999999999977e-03
    x_31_4    product_lb_86  -2.5124876618884330e-02
    x_31_4    product_ub_87  -4.2058882435451639e-02
    x_31_4    onehot_31_104  1
    x_31_4    stock_lb_268  4
    x_31_4    stock_ub_269  4
    x_31_4    parent_nonstrict_scope_270  0.0315
    x_31_4    unique_nonzero_owner_366  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_4    product_lb_86  1
    w_31_4    product_ub_87  1
    w_31_4    normalized_mass_31_105  1
    w_31_4    normalized_ratio_31_106  -5.7142857142857140e-01
    w_31_4    full_original_Gini_328  -9.3333333333333357e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_5    OBJ       -1.5749999999999993e-02
    x_31_5    product_lb_88  -2.5124876618884330e-02
    x_31_5    product_ub_89  -4.2058882435451639e-02
    x_31_5    onehot_31_104  1
    x_31_5    stock_lb_268  5
    x_31_5    stock_ub_269  5
    x_31_5    parent_nonstrict_scope_270  2.1000000000000005e-02
    x_31_5    unique_nonzero_owner_367  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_5    product_lb_88  1
    w_31_5    product_ub_89  1
    w_31_5    normalized_mass_31_105  1
    w_31_5    normalized_ratio_31_106  -7.1428571428571419e-01
    w_31_5    full_original_Gini_328  -6.5047619047619047e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_6    OBJ       -2.6249999999999996e-02
    x_31_6    product_lb_90  -2.5124876618884330e-02
    x_31_6    product_ub_91  -4.2058882435451639e-02
    x_31_6    onehot_31_104  1
    x_31_6    stock_lb_268  6
    x_31_6    stock_ub_269  6
    x_31_6    parent_nonstrict_scope_270  1.0500000000000002e-02
    x_31_6    unique_nonzero_owner_368  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_6    product_lb_90  1
    w_31_6    product_ub_91  1
    w_31_6    normalized_mass_31_105  1
    w_31_6    normalized_ratio_31_106  -8.5714285714285710e-01
    w_31_6    full_original_Gini_328  -5.2380952380952390e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_7    OBJ       -0.03675
    x_31_7    product_lb_92  -2.5124876618884330e-02
    x_31_7    product_ub_93  -4.2058882435451639e-02
    x_31_7    onehot_31_104  1
    x_31_7    stock_lb_268  7
    x_31_7    stock_ub_269  7
    x_31_7    unique_nonzero_owner_369  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_7    product_lb_92  1
    w_31_7    product_ub_93  1
    w_31_7    normalized_mass_31_105  1
    w_31_7    normalized_ratio_31_106  -1
    w_31_7    full_original_Gini_328  -4.5238095238095237e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_8    OBJ       -2.6250000000000002e-02
    x_31_8    product_lb_94  -2.5124876618884330e-02
    x_31_8    product_ub_95  -4.2058882435451639e-02
    x_31_8    onehot_31_104  1
    x_31_8    stock_lb_268  8
    x_31_8    stock_ub_269  8
    x_31_8    parent_nonstrict_scope_270  1.0499999999999995e-02
    x_31_8    unique_nonzero_owner_370  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_8    product_lb_94  1
    w_31_8    product_ub_95  1
    w_31_8    normalized_mass_31_105  1
    w_31_8    normalized_ratio_31_106  -1.1428571428571428e+00
    w_31_8    full_original_Gini_328  -7.5238095238095237e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_9    OBJ       -1.5750000000000007e-02
    x_31_9    product_lb_96  -2.5124876618884330e-02
    x_31_9    product_ub_97  -4.2058882435451639e-02
    x_31_9    onehot_31_104  1
    x_31_9    stock_lb_268  9
    x_31_9    stock_ub_269  9
    x_31_9    parent_nonstrict_scope_270  2.0999999999999991e-02
    x_31_9    unique_nonzero_owner_371  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_9    product_lb_96  1
    w_31_9    product_ub_97  1
    w_31_9    normalized_mass_31_105  1
    w_31_9    normalized_ratio_31_106  -1.2857142857142856e+00
    w_31_9    full_original_Gini_328  -1.0938095238095233e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_10   OBJ       -5.2500000000000116e-03
    x_31_10   product_lb_98  -2.5124876618884330e-02
    x_31_10   product_ub_99  -4.2058882435451639e-02
    x_31_10   onehot_31_104  1
    x_31_10   stock_lb_268  10
    x_31_10   stock_ub_269  10
    x_31_10   parent_nonstrict_scope_270  3.1499999999999986e-02
    x_31_10   unique_nonzero_owner_372  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_10   product_lb_98  1
    w_31_10   product_ub_99  1
    w_31_10   normalized_mass_31_105  1
    w_31_10   normalized_ratio_31_106  -1.4285714285714284e+00
    w_31_10   full_original_Gini_328  -1.4795238095238092e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_11   OBJ       5.2499999999999977e-03
    x_31_11   product_lb_100  -2.5124876618884330e-02
    x_31_11   product_ub_101  -4.2058882435451639e-02
    x_31_11   onehot_31_104  1
    x_31_11   stock_lb_268  11
    x_31_11   stock_ub_269  11
    x_31_11   parent_nonstrict_scope_270  4.1999999999999996e-02
    x_31_11   unique_nonzero_owner_373  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_11   product_lb_100  1
    w_31_11   product_ub_101  1
    w_31_11   normalized_mass_31_105  1
    w_31_11   normalized_ratio_31_106  -1.5714285714285714e+00
    w_31_11   full_original_Gini_328  -1.8652380952380952e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_12   OBJ       1.5749999999999993e-02
    x_31_12   product_lb_102  -2.5124876618884330e-02
    x_31_12   product_ub_103  -4.2058882435451639e-02
    x_31_12   onehot_31_104  1
    x_31_12   stock_lb_268  12
    x_31_12   stock_ub_269  12
    x_31_12   parent_nonstrict_scope_270  5.2499999999999991e-02
    x_31_12   unique_nonzero_owner_374  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_12   product_lb_102  1
    w_31_12   product_ub_103  1
    w_31_12   normalized_mass_31_105  1
    w_31_12   normalized_ratio_31_106  -1.7142857142857142e+00
    w_31_12   full_original_Gini_328  -2.2509523809523806e+01
    rho_31    normalized_ratio_31_106  1
    rho_31    block_pair_pos_283  1
    rho_31    block_pair_neg_284  -1
    rho_31    block_pair_pos_295  1
    rho_31    block_pair_neg_296  -1
    rho_31    block_pair_pos_317  -1
    rho_31    block_pair_neg_318  1
    rho_31    block_pair_pos_319  -1
    rho_31    block_pair_neg_320  1
    rho_31    block_pair_pos_321  -1
    rho_31    block_pair_neg_322  1
    rho_31    block_pair_pos_323  -1
    rho_31    block_pair_neg_324  1
    rho_31    block_pair_pos_325  -1
    rho_31    block_pair_neg_326  1
    rho_31    normalization_327  1
    MARKER    'MARKER'                 'INTORG'
    x_3_0     OBJ       0.042
    x_3_0     product_lb_107  -2.5124876618884330e-02
    x_3_0     product_ub_108  -4.2058882435451639e-02
    x_3_0     onehot_3_143  1
    x_3_0     parent_nonstrict_scope_270  0.096
    x_3_0     unique_nonzero_owner_375  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_0     product_lb_107  1
    w_3_0     product_ub_108  1
    w_3_0     normalized_mass_3_144  1
    w_3_0     full_original_Gini_328  -2.3776190476190479e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_1     OBJ       3.0000000000000006e-02
    x_3_1     product_lb_109  -2.5124876618884330e-02
    x_3_1     product_ub_110  -4.2058882435451639e-02
    x_3_1     onehot_3_143  1
    x_3_1     stock_lb_268  1
    x_3_1     stock_ub_269  1
    x_3_1     parent_nonstrict_scope_270  0.084
    x_3_1     unique_nonzero_owner_376  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_1     product_lb_109  1
    w_3_1     product_ub_110  1
    w_3_1     normalized_mass_3_144  1
    w_3_1     normalized_ratio_3_145  -0.125
    w_3_1     full_original_Gini_328  -2.0401190476190479e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_2     OBJ       1.8000000000000009e-02
    x_3_2     product_lb_111  -2.5124876618884330e-02
    x_3_2     product_ub_112  -4.2058882435451639e-02
    x_3_2     onehot_3_143  1
    x_3_2     stock_lb_268  2
    x_3_2     stock_ub_269  2
    x_3_2     parent_nonstrict_scope_270  7.2000000000000008e-02
    x_3_2     unique_nonzero_owner_377  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_2     product_lb_111  1
    w_3_2     product_ub_112  1
    w_3_2     normalized_mass_3_144  1
    w_3_2     normalized_ratio_3_145  -0.25
    w_3_2     full_original_Gini_328  -1.7026190476190475e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_3     OBJ       5.9999999999999984e-03
    x_3_3     product_lb_113  -2.5124876618884330e-02
    x_3_3     product_ub_114  -4.2058882435451639e-02
    x_3_3     onehot_3_143  1
    x_3_3     stock_lb_268  3
    x_3_3     stock_ub_269  3
    x_3_3     parent_nonstrict_scope_270  0.06
    x_3_3     unique_nonzero_owner_378  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_3     product_lb_113  1
    w_3_3     product_ub_114  1
    w_3_3     normalized_mass_3_144  1
    w_3_3     normalized_ratio_3_145  -0.375
    w_3_3     full_original_Gini_328  -1.3901190476190475e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_4     OBJ       -5.9999999999999984e-03
    x_3_4     product_lb_115  -2.5124876618884330e-02
    x_3_4     product_ub_116  -4.2058882435451639e-02
    x_3_4     onehot_3_143  1
    x_3_4     stock_lb_268  4
    x_3_4     stock_ub_269  4
    x_3_4     parent_nonstrict_scope_270  0.048
    x_3_4     unique_nonzero_owner_379  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_4     product_lb_115  1
    w_3_4     product_ub_116  1
    w_3_4     normalized_mass_3_144  1
    w_3_4     normalized_ratio_3_145  -0.5
    w_3_4     full_original_Gini_328  -1.0976190476190476e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_5     OBJ       -1.7999999999999995e-02
    x_3_5     product_lb_117  -2.5124876618884330e-02
    x_3_5     product_ub_118  -4.2058882435451639e-02
    x_3_5     onehot_3_143  1
    x_3_5     stock_lb_268  5
    x_3_5     stock_ub_269  5
    x_3_5     parent_nonstrict_scope_270  3.6000000000000004e-02
    x_3_5     unique_nonzero_owner_380  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_5     product_lb_117  1
    w_3_5     product_ub_118  1
    w_3_5     normalized_mass_3_144  1
    w_3_5     normalized_ratio_3_145  -0.625
    w_3_5     full_original_Gini_328  -8.2011904761904759e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_6     OBJ       -0.03
    x_3_6     product_lb_119  -2.5124876618884330e-02
    x_3_6     product_ub_120  -4.2058882435451639e-02
    x_3_6     onehot_3_143  1
    x_3_6     stock_lb_268  6
    x_3_6     stock_ub_269  6
    x_3_6     parent_nonstrict_scope_270  0.024
    x_3_6     unique_nonzero_owner_381  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_6     product_lb_119  1
    w_3_6     product_ub_120  1
    w_3_6     normalized_mass_3_144  1
    w_3_6     normalized_ratio_3_145  -0.75
    w_3_6     full_original_Gini_328  -6.0404761904761894e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_7     OBJ       -4.1999999999999996e-02
    x_3_7     product_lb_121  -2.5124876618884330e-02
    x_3_7     product_ub_122  -4.2058882435451639e-02
    x_3_7     onehot_3_143  1
    x_3_7     stock_lb_268  7
    x_3_7     stock_ub_269  7
    x_3_7     parent_nonstrict_scope_270  0.012
    x_3_7     unique_nonzero_owner_382  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_7     product_lb_121  1
    w_3_7     product_ub_122  1
    w_3_7     normalized_mass_3_144  1
    w_3_7     normalized_ratio_3_145  -0.875
    w_3_7     full_original_Gini_328  -5.1488095238095237e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_8     OBJ       -0.054
    x_3_8     product_lb_123  -2.5124876618884330e-02
    x_3_8     product_ub_124  -4.2058882435451639e-02
    x_3_8     onehot_3_143  1
    x_3_8     stock_lb_268  8
    x_3_8     stock_ub_269  8
    x_3_8     unique_nonzero_owner_383  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_8     product_lb_123  1
    w_3_8     product_ub_124  1
    w_3_8     normalized_mass_3_144  1
    w_3_8     normalized_ratio_3_145  -1
    w_3_8     full_original_Gini_328  -4.5238095238095237e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_9     OBJ       -4.1999999999999996e-02
    x_3_9     product_lb_125  -2.5124876618884330e-02
    x_3_9     product_ub_126  -4.2058882435451639e-02
    x_3_9     onehot_3_143  1
    x_3_9     stock_lb_268  9
    x_3_9     stock_ub_269  9
    x_3_9     parent_nonstrict_scope_270  0.012
    x_3_9     unique_nonzero_owner_384  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_9     product_lb_125  1
    w_3_9     product_ub_126  1
    w_3_9     normalized_mass_3_144  1
    w_3_9     normalized_ratio_3_145  -1.125
    w_3_9     full_original_Gini_328  -7.1488095238095237e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_10    OBJ       -0.03
    x_3_10    product_lb_127  -2.5124876618884330e-02
    x_3_10    product_ub_128  -4.2058882435451639e-02
    x_3_10    onehot_3_143  1
    x_3_10    stock_lb_268  10
    x_3_10    stock_ub_269  10
    x_3_10    parent_nonstrict_scope_270  0.024
    x_3_10    unique_nonzero_owner_385  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_10    product_lb_127  1
    w_3_10    product_ub_128  1
    w_3_10    normalized_mass_3_144  1
    w_3_10    normalized_ratio_3_145  -1.25
    w_3_10    full_original_Gini_328  -9.9738095238095248e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_11    OBJ       -1.7999999999999995e-02
    x_3_11    product_lb_129  -2.5124876618884330e-02
    x_3_11    product_ub_130  -4.2058882435451639e-02
    x_3_11    onehot_3_143  1
    x_3_11    stock_lb_268  11
    x_3_11    stock_ub_269  11
    x_3_11    parent_nonstrict_scope_270  3.6000000000000004e-02
    x_3_11    unique_nonzero_owner_386  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_11    product_lb_129  1
    w_3_11    product_ub_130  1
    w_3_11    normalized_mass_3_144  1
    w_3_11    normalized_ratio_3_145  -1.375
    w_3_11    full_original_Gini_328  -1.3348809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_12    OBJ       -5.9999999999999984e-03
    x_3_12    product_lb_131  -2.5124876618884330e-02
    x_3_12    product_ub_132  -4.2058882435451639e-02
    x_3_12    onehot_3_143  1
    x_3_12    stock_lb_268  12
    x_3_12    stock_ub_269  12
    x_3_12    parent_nonstrict_scope_270  0.048
    MARKER    'MARKER'                 'INTEND'
    w_3_12    product_lb_131  1
    w_3_12    product_ub_132  1
    w_3_12    normalized_mass_3_144  1
    w_3_12    normalized_ratio_3_145  -1.5
    w_3_12    full_original_Gini_328  -1.6723809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_13    OBJ       5.9999999999999984e-03
    x_3_13    product_lb_133  -2.5124876618884330e-02
    x_3_13    product_ub_134  -4.2058882435451639e-02
    x_3_13    onehot_3_143  1
    x_3_13    stock_lb_268  13
    x_3_13    stock_ub_269  13
    x_3_13    parent_nonstrict_scope_270  0.06
    x_3_13    unique_nonzero_owner_387  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_13    product_lb_133  1
    w_3_13    product_ub_134  1
    w_3_13    normalized_mass_3_144  1
    w_3_13    normalized_ratio_3_145  -1.625
    w_3_13    full_original_Gini_328  -2.0098809523809521e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_14    OBJ       1.8000000000000009e-02
    x_3_14    product_lb_135  -2.5124876618884330e-02
    x_3_14    product_ub_136  -4.2058882435451639e-02
    x_3_14    onehot_3_143  1
    x_3_14    stock_lb_268  14
    x_3_14    stock_ub_269  14
    x_3_14    parent_nonstrict_scope_270  7.2000000000000008e-02
    x_3_14    unique_nonzero_owner_388  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_14    product_lb_135  1
    w_3_14    product_ub_136  1
    w_3_14    normalized_mass_3_144  1
    w_3_14    normalized_ratio_3_145  -1.75
    w_3_14    full_original_Gini_328  -2.3473809523809521e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_15    OBJ       3.0000000000000006e-02
    x_3_15    product_lb_137  -2.5124876618884330e-02
    x_3_15    product_ub_138  -4.2058882435451639e-02
    x_3_15    onehot_3_143  1
    x_3_15    stock_lb_268  15
    x_3_15    stock_ub_269  15
    x_3_15    parent_nonstrict_scope_270  0.084
    x_3_15    unique_nonzero_owner_389  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_15    product_lb_137  1
    w_3_15    product_ub_138  1
    w_3_15    normalized_mass_3_144  1
    w_3_15    normalized_ratio_3_145  -1.875
    w_3_15    full_original_Gini_328  -2.6848809523809521e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_16    OBJ       0.042
    x_3_16    product_lb_139  -2.5124876618884330e-02
    x_3_16    product_ub_140  -4.2058882435451639e-02
    x_3_16    onehot_3_143  1
    x_3_16    stock_lb_268  16
    x_3_16    stock_ub_269  16
    x_3_16    parent_nonstrict_scope_270  0.096
    x_3_16    unique_nonzero_owner_390  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_16    product_lb_139  1
    w_3_16    product_ub_140  1
    w_3_16    normalized_mass_3_144  1
    w_3_16    normalized_ratio_3_145  -2
    w_3_16    full_original_Gini_328  -3.0223809523809521e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_17    OBJ       0.054
    x_3_17    product_lb_141  -2.5124876618884330e-02
    x_3_17    product_ub_142  -4.2058882435451639e-02
    x_3_17    onehot_3_143  1
    x_3_17    stock_lb_268  17
    x_3_17    stock_ub_269  17
    x_3_17    parent_nonstrict_scope_270  0.108
    x_3_17    unique_nonzero_owner_391  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_17    product_lb_141  1
    w_3_17    product_ub_142  1
    w_3_17    normalized_mass_3_144  1
    w_3_17    normalized_ratio_3_145  -2.125
    w_3_17    full_original_Gini_328  -3.3598809523809521e+01
    rho_3     normalized_ratio_3_145  1
    rho_3     block_pair_pos_273  1
    rho_3     block_pair_neg_274  -1
    rho_3     block_pair_pos_285  1
    rho_3     block_pair_neg_286  -1
    rho_3     block_pair_pos_297  -1
    rho_3     block_pair_neg_298  1
    rho_3     block_pair_pos_299  -1
    rho_3     block_pair_neg_300  1
    rho_3     block_pair_pos_301  -1
    rho_3     block_pair_neg_302  1
    rho_3     block_pair_pos_303  -1
    rho_3     block_pair_neg_304  1
    rho_3     block_pair_pos_317  1
    rho_3     block_pair_neg_318  -1
    rho_3     normalization_327  1
    MARKER    'MARKER'                 'INTORG'
    x_16_0    OBJ       0.027
    x_16_0    product_lb_146  -2.5124876618884330e-02
    x_16_0    product_ub_147  -4.2058882435451639e-02
    x_16_0    onehot_16_172  1
    x_16_0    parent_nonstrict_scope_270  0.054
    x_16_0    unique_nonzero_owner_392  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_0    product_lb_146  1
    w_16_0    product_ub_147  1
    w_16_0    normalized_mass_16_173  1
    w_16_0    full_original_Gini_328  -2.3776190476190479e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_1    OBJ       0.018
    x_16_1    product_lb_148  -2.5124876618884330e-02
    x_16_1    product_ub_149  -4.2058882435451639e-02
    x_16_1    onehot_16_172  1
    x_16_1    stock_lb_268  1
    x_16_1    stock_ub_269  1
    x_16_1    parent_nonstrict_scope_270  0.045
    MARKER    'MARKER'                 'INTEND'
    w_16_1    product_lb_148  1
    w_16_1    product_ub_149  1
    w_16_1    normalized_mass_16_173  1
    w_16_1    normalized_ratio_16_174  -1.6666666666666666e-01
    w_16_1    full_original_Gini_328  -1.9276190476190479e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_2    OBJ       9.0000000000000045e-03
    x_16_2    product_lb_150  -2.5124876618884330e-02
    x_16_2    product_ub_151  -4.2058882435451639e-02
    x_16_2    onehot_16_172  1
    x_16_2    stock_lb_268  2
    x_16_2    stock_ub_269  2
    x_16_2    parent_nonstrict_scope_270  3.6000000000000004e-02
    x_16_2    unique_nonzero_owner_393  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_2    product_lb_150  1
    w_16_2    product_ub_151  1
    w_16_2    normalized_mass_16_173  1
    w_16_2    normalized_ratio_16_174  -3.3333333333333331e-01
    w_16_2    full_original_Gini_328  -1.4942857142857143e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_3    product_lb_152  -2.5124876618884330e-02
    x_16_3    product_ub_153  -4.2058882435451639e-02
    x_16_3    onehot_16_172  1
    x_16_3    stock_lb_268  3
    x_16_3    stock_ub_269  3
    x_16_3    parent_nonstrict_scope_270  0.027
    x_16_3    unique_nonzero_owner_394  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_3    product_lb_152  1
    w_16_3    product_ub_153  1
    w_16_3    normalized_mass_16_173  1
    w_16_3    normalized_ratio_16_174  -0.5
    w_16_3    full_original_Gini_328  -1.0976190476190476e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_4    OBJ       -8.9999999999999976e-03
    x_16_4    product_lb_154  -2.5124876618884330e-02
    x_16_4    product_ub_155  -4.2058882435451639e-02
    x_16_4    onehot_16_172  1
    x_16_4    stock_lb_268  4
    x_16_4    stock_ub_269  4
    x_16_4    parent_nonstrict_scope_270  1.8000000000000002e-02
    x_16_4    unique_nonzero_owner_395  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_4    product_lb_154  1
    w_16_4    product_ub_155  1
    w_16_4    normalized_mass_16_173  1
    w_16_4    normalized_ratio_16_174  -6.6666666666666663e-01
    w_16_4    full_original_Gini_328  -7.4095238095238081e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_5    OBJ       -1.7999999999999995e-02
    x_16_5    product_lb_156  -2.5124876618884330e-02
    x_16_5    product_ub_157  -4.2058882435451639e-02
    x_16_5    onehot_16_172  1
    x_16_5    stock_lb_268  5
    x_16_5    stock_ub_269  5
    x_16_5    parent_nonstrict_scope_270  9.0000000000000045e-03
    x_16_5    unique_nonzero_owner_396  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_5    product_lb_156  1
    w_16_5    product_ub_157  1
    w_16_5    normalized_mass_16_173  1
    w_16_5    normalized_ratio_16_174  -8.3333333333333326e-01
    w_16_5    full_original_Gini_328  -5.3571428571428594e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_6    OBJ       -0.027
    x_16_6    product_lb_158  -2.5124876618884330e-02
    x_16_6    product_ub_159  -4.2058882435451639e-02
    x_16_6    onehot_16_172  1
    x_16_6    stock_lb_268  6
    x_16_6    stock_ub_269  6
    x_16_6    unique_nonzero_owner_397  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_6    product_lb_158  1
    w_16_6    product_ub_159  1
    w_16_6    normalized_mass_16_173  1
    w_16_6    normalized_ratio_16_174  -1
    w_16_6    full_original_Gini_328  -4.5238095238095237e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_7    OBJ       -1.8000000000000009e-02
    x_16_7    product_lb_160  -2.5124876618884330e-02
    x_16_7    product_ub_161  -4.2058882435451639e-02
    x_16_7    onehot_16_172  1
    x_16_7    stock_lb_268  7
    x_16_7    stock_ub_269  7
    x_16_7    parent_nonstrict_scope_270  8.9999999999999924e-03
    x_16_7    unique_nonzero_owner_398  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_7    product_lb_160  1
    w_16_7    product_ub_161  1
    w_16_7    normalized_mass_16_173  1
    w_16_7    normalized_ratio_16_174  -1.1666666666666665e+00
    w_16_7    full_original_Gini_328  -8.0238095238095219e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_8    OBJ       -9.0000000000000045e-03
    x_16_8    product_lb_162  -2.5124876618884330e-02
    x_16_8    product_ub_163  -4.2058882435451639e-02
    x_16_8    onehot_16_172  1
    x_16_8    stock_lb_268  8
    x_16_8    stock_ub_269  8
    x_16_8    parent_nonstrict_scope_270  1.7999999999999995e-02
    x_16_8    unique_nonzero_owner_399  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_8    product_lb_162  1
    w_16_8    product_ub_163  1
    w_16_8    normalized_mass_16_173  1
    w_16_8    normalized_ratio_16_174  -1.3333333333333333e+00
    w_16_8    full_original_Gini_328  -1.2223809523809523e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_9    product_lb_164  -2.5124876618884330e-02
    x_16_9    product_ub_165  -4.2058882435451639e-02
    x_16_9    onehot_16_172  1
    x_16_9    stock_lb_268  9
    x_16_9    stock_ub_269  9
    x_16_9    parent_nonstrict_scope_270  0.027
    x_16_9    unique_nonzero_owner_400  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_9    product_lb_164  1
    w_16_9    product_ub_165  1
    w_16_9    normalized_mass_16_173  1
    w_16_9    normalized_ratio_16_174  -1.5
    w_16_9    full_original_Gini_328  -1.6723809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_10   OBJ       0.00899999999999999
    x_16_10   product_lb_166  -2.5124876618884330e-02
    x_16_10   product_ub_167  -4.2058882435451639e-02
    x_16_10   onehot_16_172  1
    x_16_10   stock_lb_268  10
    x_16_10   stock_ub_269  10
    x_16_10   parent_nonstrict_scope_270  3.5999999999999990e-02
    x_16_10   unique_nonzero_owner_401  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_10   product_lb_166  1
    w_16_10   product_ub_167  1
    w_16_10   normalized_mass_16_173  1
    w_16_10   normalized_ratio_16_174  -1.6666666666666665e+00
    w_16_10   full_original_Gini_328  -2.1223809523809521e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_11   OBJ       0.018
    x_16_11   product_lb_168  -2.5124876618884330e-02
    x_16_11   product_ub_169  -4.2058882435451639e-02
    x_16_11   onehot_16_172  1
    x_16_11   stock_lb_268  11
    x_16_11   stock_ub_269  11
    x_16_11   parent_nonstrict_scope_270  0.045
    x_16_11   unique_nonzero_owner_402  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_11   product_lb_168  1
    w_16_11   product_ub_169  1
    w_16_11   normalized_mass_16_173  1
    w_16_11   normalized_ratio_16_174  -1.8333333333333333e+00
    w_16_11   full_original_Gini_328  -2.5723809523809521e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_12   OBJ       0.027
    x_16_12   product_lb_170  -2.5124876618884330e-02
    x_16_12   product_ub_171  -4.2058882435451639e-02
    x_16_12   onehot_16_172  1
    x_16_12   stock_lb_268  12
    x_16_12   stock_ub_269  12
    x_16_12   parent_nonstrict_scope_270  0.054
    x_16_12   unique_nonzero_owner_403  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_12   product_lb_170  1
    w_16_12   product_ub_171  1
    w_16_12   normalized_mass_16_173  1
    w_16_12   normalized_ratio_16_174  -2
    w_16_12   full_original_Gini_328  -3.0223809523809521e+01
    rho_16    normalized_ratio_16_174  1
    rho_16    block_pair_pos_279  1
    rho_16    block_pair_neg_280  -1
    rho_16    block_pair_pos_291  1
    rho_16    block_pair_neg_292  -1
    rho_16    block_pair_pos_301  1
    rho_16    block_pair_neg_302  -1
    rho_16    block_pair_pos_309  -1
    rho_16    block_pair_neg_310  1
    rho_16    block_pair_pos_311  -1
    rho_16    block_pair_neg_312  1
    rho_16    block_pair_pos_313  -1
    rho_16    block_pair_neg_314  1
    rho_16    block_pair_pos_323  1
    rho_16    block_pair_neg_324  -1
    rho_16    normalization_327  1
    MARKER    'MARKER'                 'INTORG'
    x_4_0     OBJ       0.0315
    x_4_0     product_lb_175  -2.5124876618884330e-02
    x_4_0     product_ub_176  -4.2058882435451639e-02
    x_4_0     onehot_4_207  1
    x_4_0     parent_nonstrict_scope_270  0.0735
    x_4_0     unique_nonzero_owner_404  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_0     product_lb_175  1
    w_4_0     product_ub_176  1
    w_4_0     normalized_mass_4_208  1
    w_4_0     full_original_Gini_328  -2.3776190476190479e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_1     OBJ       2.1000000000000005e-02
    x_4_1     product_lb_177  -2.5124876618884330e-02
    x_4_1     product_ub_178  -4.2058882435451639e-02
    x_4_1     onehot_4_207  1
    x_4_1     stock_lb_268  1
    x_4_1     stock_ub_269  1
    x_4_1     parent_nonstrict_scope_270  0.063
    x_4_1     unique_nonzero_owner_405  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_1     product_lb_177  1
    w_4_1     product_ub_178  1
    w_4_1     normalized_mass_4_208  1
    w_4_1     normalized_ratio_4_209  -1.4285714285714285e-01
    w_4_1     full_original_Gini_328  -1.9919047619047625e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_2     OBJ       1.0500000000000002e-02
    x_4_2     product_lb_179  -2.5124876618884330e-02
    x_4_2     product_ub_180  -4.2058882435451639e-02
    x_4_2     onehot_4_207  1
    x_4_2     stock_lb_268  2
    x_4_2     stock_ub_269  2
    x_4_2     parent_nonstrict_scope_270  0.0525
    x_4_2     unique_nonzero_owner_406  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_2     product_lb_179  1
    w_4_2     product_ub_180  1
    w_4_2     normalized_mass_4_208  1
    w_4_2     normalized_ratio_4_209  -2.8571428571428570e-01
    w_4_2     full_original_Gini_328  -1.6133333333333333e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_3     product_lb_181  -2.5124876618884330e-02
    x_4_3     product_ub_182  -4.2058882435451639e-02
    x_4_3     onehot_4_207  1
    x_4_3     stock_lb_268  3
    x_4_3     stock_ub_269  3
    x_4_3     parent_nonstrict_scope_270  4.1999999999999996e-02
    x_4_3     unique_nonzero_owner_407  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_3     product_lb_181  1
    w_4_3     product_ub_182  1
    w_4_3     normalized_mass_4_208  1
    w_4_3     normalized_ratio_4_209  -4.2857142857142855e-01
    w_4_3     full_original_Gini_328  -1.2619047619047619e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_4     OBJ       -1.0499999999999995e-02
    x_4_4     product_lb_183  -2.5124876618884330e-02
    x_4_4     product_ub_184  -4.2058882435451639e-02
    x_4_4     onehot_4_207  1
    x_4_4     stock_lb_268  4
    x_4_4     stock_ub_269  4
    x_4_4     parent_nonstrict_scope_270  0.0315
    x_4_4     unique_nonzero_owner_408  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_4     product_lb_183  1
    w_4_4     product_ub_184  1
    w_4_4     normalized_mass_4_208  1
    w_4_4     normalized_ratio_4_209  -5.7142857142857140e-01
    w_4_4     full_original_Gini_328  -9.3333333333333357e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_5     OBJ       -2.0999999999999991e-02
    x_4_5     product_lb_185  -2.5124876618884330e-02
    x_4_5     product_ub_186  -4.2058882435451639e-02
    x_4_5     onehot_4_207  1
    x_4_5     stock_lb_268  5
    x_4_5     stock_ub_269  5
    x_4_5     parent_nonstrict_scope_270  2.1000000000000005e-02
    x_4_5     unique_nonzero_owner_409  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_5     product_lb_185  1
    w_4_5     product_ub_186  1
    w_4_5     normalized_mass_4_208  1
    w_4_5     normalized_ratio_4_209  -7.1428571428571419e-01
    w_4_5     full_original_Gini_328  -6.5047619047619047e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_6     OBJ       -3.1499999999999993e-02
    x_4_6     product_lb_187  -2.5124876618884330e-02
    x_4_6     product_ub_188  -4.2058882435451639e-02
    x_4_6     onehot_4_207  1
    x_4_6     stock_lb_268  6
    x_4_6     stock_ub_269  6
    x_4_6     parent_nonstrict_scope_270  1.0500000000000002e-02
    x_4_6     unique_nonzero_owner_410  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_6     product_lb_187  1
    w_4_6     product_ub_188  1
    w_4_6     normalized_mass_4_208  1
    w_4_6     normalized_ratio_4_209  -8.5714285714285710e-01
    w_4_6     full_original_Gini_328  -5.2380952380952390e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_7     OBJ       -4.1999999999999996e-02
    x_4_7     product_lb_189  -2.5124876618884330e-02
    x_4_7     product_ub_190  -4.2058882435451639e-02
    x_4_7     onehot_4_207  1
    x_4_7     stock_lb_268  7
    x_4_7     stock_ub_269  7
    x_4_7     unique_nonzero_owner_411  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_7     product_lb_189  1
    w_4_7     product_ub_190  1
    w_4_7     normalized_mass_4_208  1
    w_4_7     normalized_ratio_4_209  -1
    w_4_7     full_original_Gini_328  -4.5238095238095237e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_8     OBJ       -0.0315
    x_4_8     product_lb_191  -2.5124876618884330e-02
    x_4_8     product_ub_192  -4.2058882435451639e-02
    x_4_8     onehot_4_207  1
    x_4_8     stock_lb_268  8
    x_4_8     stock_ub_269  8
    x_4_8     parent_nonstrict_scope_270  1.0499999999999995e-02
    x_4_8     unique_nonzero_owner_412  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_8     product_lb_191  1
    w_4_8     product_ub_192  1
    w_4_8     normalized_mass_4_208  1
    w_4_8     normalized_ratio_4_209  -1.1428571428571428e+00
    w_4_8     full_original_Gini_328  -7.5238095238095237e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_9     OBJ       -2.1000000000000005e-02
    x_4_9     product_lb_193  -2.5124876618884330e-02
    x_4_9     product_ub_194  -4.2058882435451639e-02
    x_4_9     onehot_4_207  1
    x_4_9     stock_lb_268  9
    x_4_9     stock_ub_269  9
    x_4_9     parent_nonstrict_scope_270  2.0999999999999991e-02
    x_4_9     unique_nonzero_owner_413  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_9     product_lb_193  1
    w_4_9     product_ub_194  1
    w_4_9     normalized_mass_4_208  1
    w_4_9     normalized_ratio_4_209  -1.2857142857142856e+00
    w_4_9     full_original_Gini_328  -1.0938095238095233e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_10    OBJ       -1.0500000000000009e-02
    x_4_10    product_lb_195  -2.5124876618884330e-02
    x_4_10    product_ub_196  -4.2058882435451639e-02
    x_4_10    onehot_4_207  1
    x_4_10    stock_lb_268  10
    x_4_10    stock_ub_269  10
    x_4_10    parent_nonstrict_scope_270  3.1499999999999986e-02
    x_4_10    unique_nonzero_owner_414  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_10    product_lb_195  1
    w_4_10    product_ub_196  1
    w_4_10    normalized_mass_4_208  1
    w_4_10    normalized_ratio_4_209  -1.4285714285714284e+00
    w_4_10    full_original_Gini_328  -1.4795238095238092e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_11    product_lb_197  -2.5124876618884330e-02
    x_4_11    product_ub_198  -4.2058882435451639e-02
    x_4_11    onehot_4_207  1
    x_4_11    stock_lb_268  11
    x_4_11    stock_ub_269  11
    x_4_11    parent_nonstrict_scope_270  4.1999999999999996e-02
    MARKER    'MARKER'                 'INTEND'
    w_4_11    product_lb_197  1
    w_4_11    product_ub_198  1
    w_4_11    normalized_mass_4_208  1
    w_4_11    normalized_ratio_4_209  -1.5714285714285714e+00
    w_4_11    full_original_Gini_328  -1.8652380952380952e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_12    OBJ       1.0499999999999995e-02
    x_4_12    product_lb_199  -2.5124876618884330e-02
    x_4_12    product_ub_200  -4.2058882435451639e-02
    x_4_12    onehot_4_207  1
    x_4_12    stock_lb_268  12
    x_4_12    stock_ub_269  12
    x_4_12    parent_nonstrict_scope_270  5.2499999999999991e-02
    x_4_12    unique_nonzero_owner_415  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_12    product_lb_199  1
    w_4_12    product_ub_200  1
    w_4_12    normalized_mass_4_208  1
    w_4_12    normalized_ratio_4_209  -1.7142857142857142e+00
    w_4_12    full_original_Gini_328  -2.2509523809523806e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_13    OBJ       2.0999999999999991e-02
    x_4_13    product_lb_201  -2.5124876618884330e-02
    x_4_13    product_ub_202  -4.2058882435451639e-02
    x_4_13    onehot_4_207  1
    x_4_13    stock_lb_268  13
    x_4_13    stock_ub_269  13
    x_4_13    parent_nonstrict_scope_270  6.2999999999999987e-02
    x_4_13    unique_nonzero_owner_416  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_13    product_lb_201  1
    w_4_13    product_ub_202  1
    w_4_13    normalized_mass_4_208  1
    w_4_13    normalized_ratio_4_209  -1.8571428571428570e+00
    w_4_13    full_original_Gini_328  -2.6366666666666667e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_14    OBJ       0.0315
    x_4_14    product_lb_203  -2.5124876618884330e-02
    x_4_14    product_ub_204  -4.2058882435451639e-02
    x_4_14    onehot_4_207  1
    x_4_14    stock_lb_268  14
    x_4_14    stock_ub_269  14
    x_4_14    parent_nonstrict_scope_270  0.0735
    x_4_14    unique_nonzero_owner_417  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_14    product_lb_203  1
    w_4_14    product_ub_204  1
    w_4_14    normalized_mass_4_208  1
    w_4_14    normalized_ratio_4_209  -2
    w_4_14    full_original_Gini_328  -3.0223809523809521e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_15    OBJ       4.1999999999999996e-02
    x_4_15    product_lb_205  -2.5124876618884330e-02
    x_4_15    product_ub_206  -4.2058882435451639e-02
    x_4_15    onehot_4_207  1
    x_4_15    stock_lb_268  15
    x_4_15    stock_ub_269  15
    x_4_15    parent_nonstrict_scope_270  8.3999999999999991e-02
    x_4_15    unique_nonzero_owner_418  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_15    product_lb_205  1
    w_4_15    product_ub_206  1
    w_4_15    normalized_mass_4_208  1
    w_4_15    normalized_ratio_4_209  -2.1428571428571428e+00
    w_4_15    full_original_Gini_328  -3.4080952380952375e+01
    rho_4     normalized_ratio_4_209  1
    rho_4     block_pair_pos_275  1
    rho_4     block_pair_neg_276  -1
    rho_4     block_pair_pos_287  1
    rho_4     block_pair_neg_288  -1
    rho_4     block_pair_pos_297  1
    rho_4     block_pair_neg_298  -1
    rho_4     block_pair_pos_305  -1
    rho_4     block_pair_neg_306  1
    rho_4     block_pair_pos_307  -1
    rho_4     block_pair_neg_308  1
    rho_4     block_pair_pos_309  1
    rho_4     block_pair_neg_310  -1
    rho_4     block_pair_pos_319  1
    rho_4     block_pair_neg_320  -1
    rho_4     normalization_327  1
    MARKER    'MARKER'                 'INTORG'
    x_19_0    OBJ       0.012
    x_19_0    product_lb_210  -2.5124876618884330e-02
    x_19_0    product_ub_211  -4.2058882435451639e-02
    x_19_0    onehot_19_228  1
    x_19_0    parent_nonstrict_scope_270  0.024
    MARKER    'MARKER'                 'INTEND'
    w_19_0    product_lb_210  1
    w_19_0    product_ub_211  1
    w_19_0    normalized_mass_19_229  1
    w_19_0    full_original_Gini_328  -2.3776190476190479e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_1    OBJ       6.0000000000000019e-03
    x_19_1    product_lb_212  -2.5124876618884330e-02
    x_19_1    product_ub_213  -4.2058882435451639e-02
    x_19_1    onehot_19_228  1
    x_19_1    stock_lb_268  1
    x_19_1    stock_ub_269  1
    x_19_1    parent_nonstrict_scope_270  1.8000000000000002e-02
    x_19_1    unique_nonzero_owner_419  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_1    product_lb_212  1
    w_19_1    product_ub_213  1
    w_19_1    normalized_mass_19_229  1
    w_19_1    normalized_ratio_19_230  -0.25
    w_19_1    full_original_Gini_328  -1.7026190476190475e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_2    product_lb_214  -2.5124876618884330e-02
    x_19_2    product_ub_215  -4.2058882435451639e-02
    x_19_2    onehot_19_228  1
    x_19_2    stock_lb_268  2
    x_19_2    stock_ub_269  2
    x_19_2    parent_nonstrict_scope_270  0.012
    x_19_2    unique_nonzero_owner_420  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_2    product_lb_214  1
    w_19_2    product_ub_215  1
    w_19_2    normalized_mass_19_229  1
    w_19_2    normalized_ratio_19_230  -0.5
    w_19_2    full_original_Gini_328  -1.0976190476190476e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_3    OBJ       -0.006
    x_19_3    product_lb_216  -2.5124876618884330e-02
    x_19_3    product_ub_217  -4.2058882435451639e-02
    x_19_3    onehot_19_228  1
    x_19_3    stock_lb_268  3
    x_19_3    stock_ub_269  3
    x_19_3    parent_nonstrict_scope_270  0.006
    x_19_3    unique_nonzero_owner_421  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_3    product_lb_216  1
    w_19_3    product_ub_217  1
    w_19_3    normalized_mass_19_229  1
    w_19_3    normalized_ratio_19_230  -0.75
    w_19_3    full_original_Gini_328  -6.0404761904761894e+00
    MARKER    'MARKER'                 'INTORG'
    x_19_4    OBJ       -0.012
    x_19_4    product_lb_218  -2.5124876618884330e-02
    x_19_4    product_ub_219  -4.2058882435451639e-02
    x_19_4    onehot_19_228  1
    x_19_4    stock_lb_268  4
    x_19_4    stock_ub_269  4
    x_19_4    unique_nonzero_owner_422  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_4    product_lb_218  1
    w_19_4    product_ub_219  1
    w_19_4    normalized_mass_19_229  1
    w_19_4    normalized_ratio_19_230  -1
    w_19_4    full_original_Gini_328  -4.5238095238095237e+00
    MARKER    'MARKER'                 'INTORG'
    x_19_5    OBJ       -0.006
    x_19_5    product_lb_220  -2.5124876618884330e-02
    x_19_5    product_ub_221  -4.2058882435451639e-02
    x_19_5    onehot_19_228  1
    x_19_5    stock_lb_268  5
    x_19_5    stock_ub_269  5
    x_19_5    parent_nonstrict_scope_270  0.006
    x_19_5    unique_nonzero_owner_423  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_5    product_lb_220  1
    w_19_5    product_ub_221  1
    w_19_5    normalized_mass_19_229  1
    w_19_5    normalized_ratio_19_230  -1.25
    w_19_5    full_original_Gini_328  -9.9738095238095248e+00
    MARKER    'MARKER'                 'INTORG'
    x_19_6    product_lb_222  -2.5124876618884330e-02
    x_19_6    product_ub_223  -4.2058882435451639e-02
    x_19_6    onehot_19_228  1
    x_19_6    stock_lb_268  6
    x_19_6    stock_ub_269  6
    x_19_6    parent_nonstrict_scope_270  0.012
    x_19_6    unique_nonzero_owner_424  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_6    product_lb_222  1
    w_19_6    product_ub_223  1
    w_19_6    normalized_mass_19_229  1
    w_19_6    normalized_ratio_19_230  -1.5
    w_19_6    full_original_Gini_328  -1.6723809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_7    OBJ       6.0000000000000019e-03
    x_19_7    product_lb_224  -2.5124876618884330e-02
    x_19_7    product_ub_225  -4.2058882435451639e-02
    x_19_7    onehot_19_228  1
    x_19_7    stock_lb_268  7
    x_19_7    stock_ub_269  7
    x_19_7    parent_nonstrict_scope_270  1.8000000000000002e-02
    x_19_7    unique_nonzero_owner_425  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_7    product_lb_224  1
    w_19_7    product_ub_225  1
    w_19_7    normalized_mass_19_229  1
    w_19_7    normalized_ratio_19_230  -1.75
    w_19_7    full_original_Gini_328  -2.3473809523809521e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_8    OBJ       0.012
    x_19_8    product_lb_226  -2.5124876618884330e-02
    x_19_8    product_ub_227  -4.2058882435451639e-02
    x_19_8    onehot_19_228  1
    x_19_8    stock_lb_268  8
    x_19_8    stock_ub_269  8
    x_19_8    parent_nonstrict_scope_270  0.024
    x_19_8    unique_nonzero_owner_426  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_8    product_lb_226  1
    w_19_8    product_ub_227  1
    w_19_8    normalized_mass_19_229  1
    w_19_8    normalized_ratio_19_230  -2
    w_19_8    full_original_Gini_328  -3.0223809523809521e+01
    rho_19    normalized_ratio_19_230  1
    rho_19    block_pair_pos_281  1
    rho_19    block_pair_neg_282  -1
    rho_19    block_pair_pos_293  1
    rho_19    block_pair_neg_294  -1
    rho_19    block_pair_pos_303  1
    rho_19    block_pair_neg_304  -1
    rho_19    block_pair_pos_307  1
    rho_19    block_pair_neg_308  -1
    rho_19    block_pair_pos_313  1
    rho_19    block_pair_neg_314  -1
    rho_19    block_pair_pos_315  -1
    rho_19    block_pair_neg_316  1
    rho_19    block_pair_pos_325  1
    rho_19    block_pair_neg_326  -1
    rho_19    normalization_327  1
    MARKER    'MARKER'                 'INTORG'
    x_5_0     OBJ       0.048
    x_5_0     product_lb_231  -2.5124876618884330e-02
    x_5_0     product_ub_232  -4.2058882435451639e-02
    x_5_0     onehot_5_265  1
    x_5_0     parent_nonstrict_scope_270  0.096
    x_5_0     unique_nonzero_owner_427  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_0     product_lb_231  1
    w_5_0     product_ub_232  1
    w_5_0     normalized_mass_5_266  1
    w_5_0     full_original_Gini_328  -2.3776190476190479e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_1     OBJ       3.6000000000000004e-02
    x_5_1     product_lb_233  -2.5124876618884330e-02
    x_5_1     product_ub_234  -4.2058882435451639e-02
    x_5_1     onehot_5_265  1
    x_5_1     stock_lb_268  1
    x_5_1     stock_ub_269  1
    x_5_1     parent_nonstrict_scope_270  0.084
    x_5_1     unique_nonzero_owner_428  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_1     product_lb_233  1
    w_5_1     product_ub_234  1
    w_5_1     normalized_mass_5_266  1
    w_5_1     normalized_ratio_5_267  -0.125
    w_5_1     full_original_Gini_328  -2.0401190476190479e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_2     OBJ       2.4000000000000007e-02
    x_5_2     product_lb_235  -2.5124876618884330e-02
    x_5_2     product_ub_236  -4.2058882435451639e-02
    x_5_2     onehot_5_265  1
    x_5_2     stock_lb_268  2
    x_5_2     stock_ub_269  2
    x_5_2     parent_nonstrict_scope_270  7.2000000000000008e-02
    MARKER    'MARKER'                 'INTEND'
    w_5_2     product_lb_235  1
    w_5_2     product_ub_236  1
    w_5_2     normalized_mass_5_266  1
    w_5_2     normalized_ratio_5_267  -0.25
    w_5_2     full_original_Gini_328  -1.7026190476190475e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_3     OBJ       1.1999999999999997e-02
    x_5_3     product_lb_237  -2.5124876618884330e-02
    x_5_3     product_ub_238  -4.2058882435451639e-02
    x_5_3     onehot_5_265  1
    x_5_3     stock_lb_268  3
    x_5_3     stock_ub_269  3
    x_5_3     parent_nonstrict_scope_270  0.06
    x_5_3     unique_nonzero_owner_429  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_3     product_lb_237  1
    w_5_3     product_ub_238  1
    w_5_3     normalized_mass_5_266  1
    w_5_3     normalized_ratio_5_267  -0.375
    w_5_3     full_original_Gini_328  -1.3901190476190475e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_4     product_lb_239  -2.5124876618884330e-02
    x_5_4     product_ub_240  -4.2058882435451639e-02
    x_5_4     onehot_5_265  1
    x_5_4     stock_lb_268  4
    x_5_4     stock_ub_269  4
    x_5_4     parent_nonstrict_scope_270  0.048
    x_5_4     unique_nonzero_owner_430  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_4     product_lb_239  1
    w_5_4     product_ub_240  1
    w_5_4     normalized_mass_5_266  1
    w_5_4     normalized_ratio_5_267  -0.5
    w_5_4     full_original_Gini_328  -1.0976190476190476e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_5     OBJ       -1.1999999999999997e-02
    x_5_5     product_lb_241  -2.5124876618884330e-02
    x_5_5     product_ub_242  -4.2058882435451639e-02
    x_5_5     onehot_5_265  1
    x_5_5     stock_lb_268  5
    x_5_5     stock_ub_269  5
    x_5_5     parent_nonstrict_scope_270  3.6000000000000004e-02
    x_5_5     unique_nonzero_owner_431  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_5     product_lb_241  1
    w_5_5     product_ub_242  1
    w_5_5     normalized_mass_5_266  1
    w_5_5     normalized_ratio_5_267  -0.625
    w_5_5     full_original_Gini_328  -8.2011904761904759e+00
    MARKER    'MARKER'                 'INTORG'
    x_5_6     OBJ       -0.024
    x_5_6     product_lb_243  -2.5124876618884330e-02
    x_5_6     product_ub_244  -4.2058882435451639e-02
    x_5_6     onehot_5_265  1
    x_5_6     stock_lb_268  6
    x_5_6     stock_ub_269  6
    x_5_6     parent_nonstrict_scope_270  0.024
    x_5_6     unique_nonzero_owner_432  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_6     product_lb_243  1
    w_5_6     product_ub_244  1
    w_5_6     normalized_mass_5_266  1
    w_5_6     normalized_ratio_5_267  -0.75
    w_5_6     full_original_Gini_328  -6.0404761904761894e+00
    MARKER    'MARKER'                 'INTORG'
    x_5_7     OBJ       -3.6000000000000004e-02
    x_5_7     product_lb_245  -2.5124876618884330e-02
    x_5_7     product_ub_246  -4.2058882435451639e-02
    x_5_7     onehot_5_265  1
    x_5_7     stock_lb_268  7
    x_5_7     stock_ub_269  7
    x_5_7     parent_nonstrict_scope_270  0.012
    x_5_7     unique_nonzero_owner_433  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_7     product_lb_245  1
    w_5_7     product_ub_246  1
    w_5_7     normalized_mass_5_266  1
    w_5_7     normalized_ratio_5_267  -0.875
    w_5_7     full_original_Gini_328  -5.1488095238095237e+00
    MARKER    'MARKER'                 'INTORG'
    x_5_8     OBJ       -0.048
    x_5_8     product_lb_247  -2.5124876618884330e-02
    x_5_8     product_ub_248  -4.2058882435451639e-02
    x_5_8     onehot_5_265  1
    x_5_8     stock_lb_268  8
    x_5_8     stock_ub_269  8
    x_5_8     unique_nonzero_owner_434  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_8     product_lb_247  1
    w_5_8     product_ub_248  1
    w_5_8     normalized_mass_5_266  1
    w_5_8     normalized_ratio_5_267  -1
    w_5_8     full_original_Gini_328  -4.5238095238095237e+00
    MARKER    'MARKER'                 'INTORG'
    x_5_9     OBJ       -3.6000000000000004e-02
    x_5_9     product_lb_249  -2.5124876618884330e-02
    x_5_9     product_ub_250  -4.2058882435451639e-02
    x_5_9     onehot_5_265  1
    x_5_9     stock_lb_268  9
    x_5_9     stock_ub_269  9
    x_5_9     parent_nonstrict_scope_270  0.012
    x_5_9     unique_nonzero_owner_435  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_9     product_lb_249  1
    w_5_9     product_ub_250  1
    w_5_9     normalized_mass_5_266  1
    w_5_9     normalized_ratio_5_267  -1.125
    w_5_9     full_original_Gini_328  -7.1488095238095237e+00
    MARKER    'MARKER'                 'INTORG'
    x_5_10    OBJ       -0.024
    x_5_10    product_lb_251  -2.5124876618884330e-02
    x_5_10    product_ub_252  -4.2058882435451639e-02
    x_5_10    onehot_5_265  1
    x_5_10    stock_lb_268  10
    x_5_10    stock_ub_269  10
    x_5_10    parent_nonstrict_scope_270  0.024
    x_5_10    unique_nonzero_owner_436  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_10    product_lb_251  1
    w_5_10    product_ub_252  1
    w_5_10    normalized_mass_5_266  1
    w_5_10    normalized_ratio_5_267  -1.25
    w_5_10    full_original_Gini_328  -9.9738095238095248e+00
    MARKER    'MARKER'                 'INTORG'
    x_5_11    OBJ       -1.1999999999999997e-02
    x_5_11    product_lb_253  -2.5124876618884330e-02
    x_5_11    product_ub_254  -4.2058882435451639e-02
    x_5_11    onehot_5_265  1
    x_5_11    stock_lb_268  11
    x_5_11    stock_ub_269  11
    x_5_11    parent_nonstrict_scope_270  3.6000000000000004e-02
    x_5_11    unique_nonzero_owner_437  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_11    product_lb_253  1
    w_5_11    product_ub_254  1
    w_5_11    normalized_mass_5_266  1
    w_5_11    normalized_ratio_5_267  -1.375
    w_5_11    full_original_Gini_328  -1.3348809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_12    product_lb_255  -2.5124876618884330e-02
    x_5_12    product_ub_256  -4.2058882435451639e-02
    x_5_12    onehot_5_265  1
    x_5_12    stock_lb_268  12
    x_5_12    stock_ub_269  12
    x_5_12    parent_nonstrict_scope_270  0.048
    x_5_12    unique_nonzero_owner_438  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_12    product_lb_255  1
    w_5_12    product_ub_256  1
    w_5_12    normalized_mass_5_266  1
    w_5_12    normalized_ratio_5_267  -1.5
    w_5_12    full_original_Gini_328  -1.6723809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_13    OBJ       1.1999999999999997e-02
    x_5_13    product_lb_257  -2.5124876618884330e-02
    x_5_13    product_ub_258  -4.2058882435451639e-02
    x_5_13    onehot_5_265  1
    x_5_13    stock_lb_268  13
    x_5_13    stock_ub_269  13
    x_5_13    parent_nonstrict_scope_270  0.06
    x_5_13    unique_nonzero_owner_439  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_13    product_lb_257  1
    w_5_13    product_ub_258  1
    w_5_13    normalized_mass_5_266  1
    w_5_13    normalized_ratio_5_267  -1.625
    w_5_13    full_original_Gini_328  -2.0098809523809521e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_14    OBJ       2.4000000000000007e-02
    x_5_14    product_lb_259  -2.5124876618884330e-02
    x_5_14    product_ub_260  -4.2058882435451639e-02
    x_5_14    onehot_5_265  1
    x_5_14    stock_lb_268  14
    x_5_14    stock_ub_269  14
    x_5_14    parent_nonstrict_scope_270  7.2000000000000008e-02
    x_5_14    unique_nonzero_owner_440  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_14    product_lb_259  1
    w_5_14    product_ub_260  1
    w_5_14    normalized_mass_5_266  1
    w_5_14    normalized_ratio_5_267  -1.75
    w_5_14    full_original_Gini_328  -2.3473809523809521e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_15    OBJ       3.6000000000000004e-02
    x_5_15    product_lb_261  -2.5124876618884330e-02
    x_5_15    product_ub_262  -4.2058882435451639e-02
    x_5_15    onehot_5_265  1
    x_5_15    stock_lb_268  15
    x_5_15    stock_ub_269  15
    x_5_15    parent_nonstrict_scope_270  0.084
    x_5_15    unique_nonzero_owner_441  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_15    product_lb_261  1
    w_5_15    product_ub_262  1
    w_5_15    normalized_mass_5_266  1
    w_5_15    normalized_ratio_5_267  -1.875
    w_5_15    full_original_Gini_328  -2.6848809523809521e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_16    OBJ       0.048
    x_5_16    product_lb_263  -2.5124876618884330e-02
    x_5_16    product_ub_264  -4.2058882435451639e-02
    x_5_16    onehot_5_265  1
    x_5_16    stock_lb_268  16
    x_5_16    stock_ub_269  16
    x_5_16    parent_nonstrict_scope_270  0.096
    x_5_16    unique_nonzero_owner_442  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_16    product_lb_263  1
    w_5_16    product_ub_264  1
    w_5_16    normalized_mass_5_266  1
    w_5_16    normalized_ratio_5_267  -2
    w_5_16    full_original_Gini_328  -3.0223809523809521e+01
    rho_5     normalized_ratio_5_267  1
    rho_5     block_pair_pos_277  1
    rho_5     block_pair_neg_278  -1
    rho_5     block_pair_pos_289  1
    rho_5     block_pair_neg_290  -1
    rho_5     block_pair_pos_299  1
    rho_5     block_pair_neg_300  -1
    rho_5     block_pair_pos_305  1
    rho_5     block_pair_neg_306  -1
    rho_5     block_pair_pos_311  1
    rho_5     block_pair_neg_312  -1
    rho_5     block_pair_pos_315  1
    rho_5     block_pair_neg_316  -1
    rho_5     block_pair_pos_321  1
    rho_5     block_pair_neg_322  -1
    rho_5     normalization_327  1
    a_1_2     block_pair_pos_271  1
    a_1_2     block_pair_neg_272  1
    a_1_2     full_original_Gini_328  -1
    a_1_31    block_pair_pos_283  1
    a_1_31    block_pair_neg_284  1
    a_1_31    full_original_Gini_328  -1
    a_1_3     block_pair_pos_273  1
    a_1_3     block_pair_neg_274  1
    a_1_3     full_original_Gini_328  -1
    a_1_16    block_pair_pos_279  1
    a_1_16    block_pair_neg_280  1
    a_1_16    full_original_Gini_328  -1
    a_1_4     block_pair_pos_275  1
    a_1_4     block_pair_neg_276  1
    a_1_4     full_original_Gini_328  -1
    a_1_19    block_pair_pos_281  1
    a_1_19    block_pair_neg_282  1
    a_1_19    full_original_Gini_328  -1
    a_1_5     block_pair_pos_277  1
    a_1_5     block_pair_neg_278  1
    a_1_5     full_original_Gini_328  -1
    a_2_31    block_pair_pos_295  1
    a_2_31    block_pair_neg_296  1
    a_2_31    full_original_Gini_328  -1
    a_2_3     block_pair_pos_285  1
    a_2_3     block_pair_neg_286  1
    a_2_3     full_original_Gini_328  -1
    a_2_16    block_pair_pos_291  1
    a_2_16    block_pair_neg_292  1
    a_2_16    full_original_Gini_328  -1
    a_2_4     block_pair_pos_287  1
    a_2_4     block_pair_neg_288  1
    a_2_4     full_original_Gini_328  -1
    a_2_19    block_pair_pos_293  1
    a_2_19    block_pair_neg_294  1
    a_2_19    full_original_Gini_328  -1
    a_2_5     block_pair_pos_289  1
    a_2_5     block_pair_neg_290  1
    a_2_5     full_original_Gini_328  -1
    a_31_3    block_pair_pos_317  1
    a_31_3    block_pair_neg_318  1
    a_31_3    full_original_Gini_328  -1
    a_31_16   block_pair_pos_323  1
    a_31_16   block_pair_neg_324  1
    a_31_16   full_original_Gini_328  -1
    a_31_4    block_pair_pos_319  1
    a_31_4    block_pair_neg_320  1
    a_31_4    full_original_Gini_328  -1
    a_31_19   block_pair_pos_325  1
    a_31_19   block_pair_neg_326  1
    a_31_19   full_original_Gini_328  -1
    a_31_5    block_pair_pos_321  1
    a_31_5    block_pair_neg_322  1
    a_31_5    full_original_Gini_328  -1
    a_3_16    block_pair_pos_301  1
    a_3_16    block_pair_neg_302  1
    a_3_16    full_original_Gini_328  -1
    a_3_4     block_pair_pos_297  1
    a_3_4     block_pair_neg_298  1
    a_3_4     full_original_Gini_328  -1
    a_3_19    block_pair_pos_303  1
    a_3_19    block_pair_neg_304  1
    a_3_19    full_original_Gini_328  -1
    a_3_5     block_pair_pos_299  1
    a_3_5     block_pair_neg_300  1
    a_3_5     full_original_Gini_328  -1
    a_16_4    block_pair_pos_309  1
    a_16_4    block_pair_neg_310  1
    a_16_4    full_original_Gini_328  -1
    a_16_19   block_pair_pos_313  1
    a_16_19   block_pair_neg_314  1
    a_16_19   full_original_Gini_328  -1
    a_16_5    block_pair_pos_311  1
    a_16_5    block_pair_neg_312  1
    a_16_5    full_original_Gini_328  -1
    a_4_19    block_pair_pos_307  1
    a_4_19    block_pair_neg_308  1
    a_4_19    full_original_Gini_328  -1
    a_4_5     block_pair_pos_305  1
    a_4_5     block_pair_neg_306  1
    a_4_5     full_original_Gini_328  -1
    a_19_5    block_pair_pos_315  1
    a_19_5    block_pair_neg_316  1
    a_19_5    full_original_Gini_328  -1
    MARKER    'MARKER'                 'INTORG'
    service_0_1_0  unique_nonzero_owner_329  1
    service_0_1_0  service_visit_def_884  1
    service_0_1_0  free_load_conservation_885  -2
    service_0_1_0  original_T_including_depot_unload_933  240
    service_0_1_1  unique_nonzero_owner_330  1
    service_0_1_1  service_visit_def_884  1
    service_0_1_1  free_load_conservation_885  -1
    service_0_1_1  original_T_including_depot_unload_933  120
    service_0_1_3  unique_nonzero_owner_331  1
    service_0_1_3  service_visit_def_884  1
    service_0_1_3  free_load_conservation_885  1
    service_0_1_4  unique_nonzero_owner_332  1
    service_0_1_4  service_visit_def_884  1
    service_0_1_4  free_load_conservation_885  2
    service_0_1_5  unique_nonzero_owner_333  1
    service_0_1_5  service_visit_def_884  1
    service_0_1_5  free_load_conservation_885  3
    service_0_1_6  unique_nonzero_owner_334  1
    service_0_1_6  service_visit_def_884  1
    service_0_1_6  free_load_conservation_885  4
    service_0_1_7  unique_nonzero_owner_335  1
    service_0_1_7  service_visit_def_884  1
    service_0_1_7  free_load_conservation_885  5
    service_0_1_8  unique_nonzero_owner_336  1
    service_0_1_8  service_visit_def_884  1
    service_0_1_8  free_load_conservation_885  6
    service_0_1_9  unique_nonzero_owner_337  1
    service_0_1_9  service_visit_def_884  1
    service_0_1_9  free_load_conservation_885  7
    service_0_1_10  unique_nonzero_owner_338  1
    service_0_1_10  service_visit_def_884  1
    service_0_1_10  free_load_conservation_885  8
    service_0_1_11  unique_nonzero_owner_339  1
    service_0_1_11  service_visit_def_884  1
    service_0_1_11  free_load_conservation_885  9
    service_0_1_12  unique_nonzero_owner_340  1
    service_0_1_12  service_visit_def_884  1
    service_0_1_12  free_load_conservation_885  10
    service_0_1_13  unique_nonzero_owner_341  1
    service_0_1_13  service_visit_def_884  1
    service_0_1_13  free_load_conservation_885  11
    service_0_1_14  unique_nonzero_owner_342  1
    service_0_1_14  service_visit_def_884  1
    service_0_1_14  free_load_conservation_885  12
    service_0_1_15  unique_nonzero_owner_343  1
    service_0_1_15  service_visit_def_884  1
    service_0_1_15  free_load_conservation_885  13
    service_0_1_16  unique_nonzero_owner_344  1
    service_0_1_16  service_visit_def_884  1
    service_0_1_16  free_load_conservation_885  14
    service_0_1_17  unique_nonzero_owner_345  1
    service_0_1_17  service_visit_def_884  1
    service_0_1_17  free_load_conservation_885  15
    service_0_1_18  unique_nonzero_owner_346  1
    service_0_1_18  service_visit_def_884  1
    service_0_1_18  free_load_conservation_885  16
    service_0_1_19  unique_nonzero_owner_347  1
    service_0_1_19  service_visit_def_884  1
    service_0_1_19  free_load_conservation_885  17
    service_1_1_0  unique_nonzero_owner_329  1
    service_1_1_0  service_visit_def_1314  1
    service_1_1_0  free_load_conservation_1315  -2
    service_1_1_0  original_T_including_depot_unload_1362  240
    service_1_1_1  unique_nonzero_owner_330  1
    service_1_1_1  service_visit_def_1314  1
    service_1_1_1  free_load_conservation_1315  -1
    service_1_1_1  original_T_including_depot_unload_1362  120
    service_1_1_3  unique_nonzero_owner_331  1
    service_1_1_3  service_visit_def_1314  1
    service_1_1_3  free_load_conservation_1315  1
    service_1_1_4  unique_nonzero_owner_332  1
    service_1_1_4  service_visit_def_1314  1
    service_1_1_4  free_load_conservation_1315  2
    service_1_1_5  unique_nonzero_owner_333  1
    service_1_1_5  service_visit_def_1314  1
    service_1_1_5  free_load_conservation_1315  3
    service_1_1_6  unique_nonzero_owner_334  1
    service_1_1_6  service_visit_def_1314  1
    service_1_1_6  free_load_conservation_1315  4
    service_1_1_7  unique_nonzero_owner_335  1
    service_1_1_7  service_visit_def_1314  1
    service_1_1_7  free_load_conservation_1315  5
    service_1_1_8  unique_nonzero_owner_336  1
    service_1_1_8  service_visit_def_1314  1
    service_1_1_8  free_load_conservation_1315  6
    service_1_1_9  unique_nonzero_owner_337  1
    service_1_1_9  service_visit_def_1314  1
    service_1_1_9  free_load_conservation_1315  7
    service_1_1_10  unique_nonzero_owner_338  1
    service_1_1_10  service_visit_def_1314  1
    service_1_1_10  free_load_conservation_1315  8
    service_1_1_11  unique_nonzero_owner_339  1
    service_1_1_11  service_visit_def_1314  1
    service_1_1_11  free_load_conservation_1315  9
    service_1_1_12  unique_nonzero_owner_340  1
    service_1_1_12  service_visit_def_1314  1
    service_1_1_12  free_load_conservation_1315  10
    service_1_1_13  unique_nonzero_owner_341  1
    service_1_1_13  service_visit_def_1314  1
    service_1_1_13  free_load_conservation_1315  11
    service_1_1_14  unique_nonzero_owner_342  1
    service_1_1_14  service_visit_def_1314  1
    service_1_1_14  free_load_conservation_1315  12
    service_1_1_15  unique_nonzero_owner_343  1
    service_1_1_15  service_visit_def_1314  1
    service_1_1_15  free_load_conservation_1315  13
    service_1_1_16  unique_nonzero_owner_344  1
    service_1_1_16  service_visit_def_1314  1
    service_1_1_16  free_load_conservation_1315  14
    service_1_1_17  unique_nonzero_owner_345  1
    service_1_1_17  service_visit_def_1314  1
    service_1_1_17  free_load_conservation_1315  15
    service_1_1_18  unique_nonzero_owner_346  1
    service_1_1_18  service_visit_def_1314  1
    service_1_1_18  free_load_conservation_1315  16
    service_1_1_19  unique_nonzero_owner_347  1
    service_1_1_19  service_visit_def_1314  1
    service_1_1_19  free_load_conservation_1315  17
    service_2_1_0  unique_nonzero_owner_329  1
    service_2_1_0  service_visit_def_1633  1
    service_2_1_0  free_load_conservation_1634  -2
    service_2_1_0  original_T_including_depot_unload_1679  240
    service_2_1_1  unique_nonzero_owner_330  1
    service_2_1_1  service_visit_def_1633  1
    service_2_1_1  free_load_conservation_1634  -1
    service_2_1_1  original_T_including_depot_unload_1679  120
    service_2_1_3  unique_nonzero_owner_331  1
    service_2_1_3  service_visit_def_1633  1
    service_2_1_3  free_load_conservation_1634  1
    service_2_1_4  unique_nonzero_owner_332  1
    service_2_1_4  service_visit_def_1633  1
    service_2_1_4  free_load_conservation_1634  2
    service_2_1_5  unique_nonzero_owner_333  1
    service_2_1_5  service_visit_def_1633  1
    service_2_1_5  free_load_conservation_1634  3
    service_2_1_6  unique_nonzero_owner_334  1
    service_2_1_6  service_visit_def_1633  1
    service_2_1_6  free_load_conservation_1634  4
    service_2_1_7  unique_nonzero_owner_335  1
    service_2_1_7  service_visit_def_1633  1
    service_2_1_7  free_load_conservation_1634  5
    service_2_1_8  unique_nonzero_owner_336  1
    service_2_1_8  service_visit_def_1633  1
    service_2_1_8  free_load_conservation_1634  6
    service_2_1_9  unique_nonzero_owner_337  1
    service_2_1_9  service_visit_def_1633  1
    service_2_1_9  free_load_conservation_1634  7
    service_2_1_10  unique_nonzero_owner_338  1
    service_2_1_10  service_visit_def_1633  1
    service_2_1_10  free_load_conservation_1634  8
    service_2_1_11  unique_nonzero_owner_339  1
    service_2_1_11  service_visit_def_1633  1
    service_2_1_11  free_load_conservation_1634  9
    service_2_1_12  unique_nonzero_owner_340  1
    service_2_1_12  service_visit_def_1633  1
    service_2_1_12  free_load_conservation_1634  10
    service_2_1_13  unique_nonzero_owner_341  1
    service_2_1_13  service_visit_def_1633  1
    service_2_1_13  free_load_conservation_1634  11
    service_2_1_14  unique_nonzero_owner_342  1
    service_2_1_14  service_visit_def_1633  1
    service_2_1_14  free_load_conservation_1634  12
    service_2_1_15  unique_nonzero_owner_343  1
    service_2_1_15  service_visit_def_1633  1
    service_2_1_15  free_load_conservation_1634  13
    service_2_1_16  unique_nonzero_owner_344  1
    service_2_1_16  service_visit_def_1633  1
    service_2_1_16  free_load_conservation_1634  14
    service_2_1_17  unique_nonzero_owner_345  1
    service_2_1_17  service_visit_def_1633  1
    service_2_1_17  free_load_conservation_1634  15
    service_2_1_18  unique_nonzero_owner_346  1
    service_2_1_18  service_visit_def_1633  1
    service_2_1_18  free_load_conservation_1634  16
    service_2_1_19  unique_nonzero_owner_347  1
    service_2_1_19  service_visit_def_1633  1
    service_2_1_19  free_load_conservation_1634  17
    service_0_2_1  unique_nonzero_owner_348  1
    service_0_2_1  service_visit_def_890  1
    service_0_2_1  free_load_conservation_891  1
    service_0_2_2  unique_nonzero_owner_349  1
    service_0_2_2  service_visit_def_890  1
    service_0_2_2  free_load_conservation_891  2
    service_0_2_3  unique_nonzero_owner_350  1
    service_0_2_3  service_visit_def_890  1
    service_0_2_3  free_load_conservation_891  3
    service_0_2_4  unique_nonzero_owner_351  1
    service_0_2_4  service_visit_def_890  1
    service_0_2_4  free_load_conservation_891  4
    service_0_2_5  unique_nonzero_owner_352  1
    service_0_2_5  service_visit_def_890  1
    service_0_2_5  free_load_conservation_891  5
    service_0_2_6  unique_nonzero_owner_353  1
    service_0_2_6  service_visit_def_890  1
    service_0_2_6  free_load_conservation_891  6
    service_0_2_7  unique_nonzero_owner_354  1
    service_0_2_7  service_visit_def_890  1
    service_0_2_7  free_load_conservation_891  7
    service_0_2_8  unique_nonzero_owner_355  1
    service_0_2_8  service_visit_def_890  1
    service_0_2_8  free_load_conservation_891  8
    service_0_2_9  unique_nonzero_owner_356  1
    service_0_2_9  service_visit_def_890  1
    service_0_2_9  free_load_conservation_891  9
    service_0_2_10  unique_nonzero_owner_357  1
    service_0_2_10  service_visit_def_890  1
    service_0_2_10  free_load_conservation_891  10
    service_0_2_11  unique_nonzero_owner_358  1
    service_0_2_11  service_visit_def_890  1
    service_0_2_11  free_load_conservation_891  11
    service_0_2_12  unique_nonzero_owner_359  1
    service_0_2_12  service_visit_def_890  1
    service_0_2_12  free_load_conservation_891  12
    service_0_2_13  unique_nonzero_owner_360  1
    service_0_2_13  service_visit_def_890  1
    service_0_2_13  free_load_conservation_891  13
    service_0_2_14  unique_nonzero_owner_361  1
    service_0_2_14  service_visit_def_890  1
    service_0_2_14  free_load_conservation_891  14
    service_0_2_15  unique_nonzero_owner_362  1
    service_0_2_15  service_visit_def_890  1
    service_0_2_15  free_load_conservation_891  15
    service_1_2_1  unique_nonzero_owner_348  1
    service_1_2_1  service_visit_def_1320  1
    service_1_2_1  free_load_conservation_1321  1
    service_1_2_2  unique_nonzero_owner_349  1
    service_1_2_2  service_visit_def_1320  1
    service_1_2_2  free_load_conservation_1321  2
    service_1_2_3  unique_nonzero_owner_350  1
    service_1_2_3  service_visit_def_1320  1
    service_1_2_3  free_load_conservation_1321  3
    service_1_2_4  unique_nonzero_owner_351  1
    service_1_2_4  service_visit_def_1320  1
    service_1_2_4  free_load_conservation_1321  4
    service_1_2_5  unique_nonzero_owner_352  1
    service_1_2_5  service_visit_def_1320  1
    service_1_2_5  free_load_conservation_1321  5
    service_1_2_6  unique_nonzero_owner_353  1
    service_1_2_6  service_visit_def_1320  1
    service_1_2_6  free_load_conservation_1321  6
    service_1_2_7  unique_nonzero_owner_354  1
    service_1_2_7  service_visit_def_1320  1
    service_1_2_7  free_load_conservation_1321  7
    service_1_2_8  unique_nonzero_owner_355  1
    service_1_2_8  service_visit_def_1320  1
    service_1_2_8  free_load_conservation_1321  8
    service_1_2_9  unique_nonzero_owner_356  1
    service_1_2_9  service_visit_def_1320  1
    service_1_2_9  free_load_conservation_1321  9
    service_1_2_10  unique_nonzero_owner_357  1
    service_1_2_10  service_visit_def_1320  1
    service_1_2_10  free_load_conservation_1321  10
    service_1_2_11  unique_nonzero_owner_358  1
    service_1_2_11  service_visit_def_1320  1
    service_1_2_11  free_load_conservation_1321  11
    service_1_2_12  unique_nonzero_owner_359  1
    service_1_2_12  service_visit_def_1320  1
    service_1_2_12  free_load_conservation_1321  12
    service_1_2_13  unique_nonzero_owner_360  1
    service_1_2_13  service_visit_def_1320  1
    service_1_2_13  free_load_conservation_1321  13
    service_1_2_14  unique_nonzero_owner_361  1
    service_1_2_14  service_visit_def_1320  1
    service_1_2_14  free_load_conservation_1321  14
    service_1_2_15  unique_nonzero_owner_362  1
    service_1_2_15  service_visit_def_1320  1
    service_1_2_15  free_load_conservation_1321  15
    service_2_2_1  unique_nonzero_owner_348  1
    service_2_2_1  service_visit_def_1639  1
    service_2_2_1  free_load_conservation_1640  1
    service_2_2_2  unique_nonzero_owner_349  1
    service_2_2_2  service_visit_def_1639  1
    service_2_2_2  free_load_conservation_1640  2
    service_2_2_3  unique_nonzero_owner_350  1
    service_2_2_3  service_visit_def_1639  1
    service_2_2_3  free_load_conservation_1640  3
    service_2_2_4  unique_nonzero_owner_351  1
    service_2_2_4  service_visit_def_1639  1
    service_2_2_4  free_load_conservation_1640  4
    service_2_2_5  unique_nonzero_owner_352  1
    service_2_2_5  service_visit_def_1639  1
    service_2_2_5  free_load_conservation_1640  5
    service_2_2_6  unique_nonzero_owner_353  1
    service_2_2_6  service_visit_def_1639  1
    service_2_2_6  free_load_conservation_1640  6
    service_2_2_7  unique_nonzero_owner_354  1
    service_2_2_7  service_visit_def_1639  1
    service_2_2_7  free_load_conservation_1640  7
    service_2_2_8  unique_nonzero_owner_355  1
    service_2_2_8  service_visit_def_1639  1
    service_2_2_8  free_load_conservation_1640  8
    service_2_2_9  unique_nonzero_owner_356  1
    service_2_2_9  service_visit_def_1639  1
    service_2_2_9  free_load_conservation_1640  9
    service_2_2_10  unique_nonzero_owner_357  1
    service_2_2_10  service_visit_def_1639  1
    service_2_2_10  free_load_conservation_1640  10
    service_2_2_11  unique_nonzero_owner_358  1
    service_2_2_11  service_visit_def_1639  1
    service_2_2_11  free_load_conservation_1640  11
    service_2_2_12  unique_nonzero_owner_359  1
    service_2_2_12  service_visit_def_1639  1
    service_2_2_12  free_load_conservation_1640  12
    service_2_2_13  unique_nonzero_owner_360  1
    service_2_2_13  service_visit_def_1639  1
    service_2_2_13  free_load_conservation_1640  13
    service_2_2_14  unique_nonzero_owner_361  1
    service_2_2_14  service_visit_def_1639  1
    service_2_2_14  free_load_conservation_1640  14
    service_2_2_15  unique_nonzero_owner_362  1
    service_2_2_15  service_visit_def_1639  1
    service_2_2_15  free_load_conservation_1640  15
    service_0_31_0  unique_nonzero_owner_363  1
    service_0_31_0  service_visit_def_896  1
    service_0_31_0  free_load_conservation_897  -2
    service_0_31_0  original_T_including_depot_unload_933  240
    service_0_31_1  unique_nonzero_owner_364  1
    service_0_31_1  service_visit_def_896  1
    service_0_31_1  free_load_conservation_897  -1
    service_0_31_1  original_T_including_depot_unload_933  120
    service_0_31_3  unique_nonzero_owner_365  1
    service_0_31_3  service_visit_def_896  1
    service_0_31_3  free_load_conservation_897  1
    service_0_31_4  unique_nonzero_owner_366  1
    service_0_31_4  service_visit_def_896  1
    service_0_31_4  free_load_conservation_897  2
    service_0_31_5  unique_nonzero_owner_367  1
    service_0_31_5  service_visit_def_896  1
    service_0_31_5  free_load_conservation_897  3
    service_0_31_6  unique_nonzero_owner_368  1
    service_0_31_6  service_visit_def_896  1
    service_0_31_6  free_load_conservation_897  4
    service_0_31_7  unique_nonzero_owner_369  1
    service_0_31_7  service_visit_def_896  1
    service_0_31_7  free_load_conservation_897  5
    service_0_31_8  unique_nonzero_owner_370  1
    service_0_31_8  service_visit_def_896  1
    service_0_31_8  free_load_conservation_897  6
    service_0_31_9  unique_nonzero_owner_371  1
    service_0_31_9  service_visit_def_896  1
    service_0_31_9  free_load_conservation_897  7
    service_0_31_10  unique_nonzero_owner_372  1
    service_0_31_10  service_visit_def_896  1
    service_0_31_10  free_load_conservation_897  8
    service_0_31_11  unique_nonzero_owner_373  1
    service_0_31_11  service_visit_def_896  1
    service_0_31_11  free_load_conservation_897  9
    service_0_31_12  unique_nonzero_owner_374  1
    service_0_31_12  service_visit_def_896  1
    service_0_31_12  free_load_conservation_897  10
    service_1_31_0  unique_nonzero_owner_363  1
    service_1_31_0  service_visit_def_1326  1
    service_1_31_0  free_load_conservation_1327  -2
    service_1_31_0  original_T_including_depot_unload_1362  240
    service_1_31_1  unique_nonzero_owner_364  1
    service_1_31_1  service_visit_def_1326  1
    service_1_31_1  free_load_conservation_1327  -1
    service_1_31_1  original_T_including_depot_unload_1362  120
    service_1_31_3  unique_nonzero_owner_365  1
    service_1_31_3  service_visit_def_1326  1
    service_1_31_3  free_load_conservation_1327  1
    service_1_31_4  unique_nonzero_owner_366  1
    service_1_31_4  service_visit_def_1326  1
    service_1_31_4  free_load_conservation_1327  2
    service_1_31_5  unique_nonzero_owner_367  1
    service_1_31_5  service_visit_def_1326  1
    service_1_31_5  free_load_conservation_1327  3
    service_1_31_6  unique_nonzero_owner_368  1
    service_1_31_6  service_visit_def_1326  1
    service_1_31_6  free_load_conservation_1327  4
    service_1_31_7  unique_nonzero_owner_369  1
    service_1_31_7  service_visit_def_1326  1
    service_1_31_7  free_load_conservation_1327  5
    service_1_31_8  unique_nonzero_owner_370  1
    service_1_31_8  service_visit_def_1326  1
    service_1_31_8  free_load_conservation_1327  6
    service_1_31_9  unique_nonzero_owner_371  1
    service_1_31_9  service_visit_def_1326  1
    service_1_31_9  free_load_conservation_1327  7
    service_1_31_10  unique_nonzero_owner_372  1
    service_1_31_10  service_visit_def_1326  1
    service_1_31_10  free_load_conservation_1327  8
    service_1_31_11  unique_nonzero_owner_373  1
    service_1_31_11  service_visit_def_1326  1
    service_1_31_11  free_load_conservation_1327  9
    service_1_31_12  unique_nonzero_owner_374  1
    service_1_31_12  service_visit_def_1326  1
    service_1_31_12  free_load_conservation_1327  10
    service_2_31_0  unique_nonzero_owner_363  1
    service_2_31_0  service_visit_def_1645  1
    service_2_31_0  free_load_conservation_1646  -2
    service_2_31_0  original_T_including_depot_unload_1679  240
    service_2_31_1  unique_nonzero_owner_364  1
    service_2_31_1  service_visit_def_1645  1
    service_2_31_1  free_load_conservation_1646  -1
    service_2_31_1  original_T_including_depot_unload_1679  120
    service_2_31_3  unique_nonzero_owner_365  1
    service_2_31_3  service_visit_def_1645  1
    service_2_31_3  free_load_conservation_1646  1
    service_2_31_4  unique_nonzero_owner_366  1
    service_2_31_4  service_visit_def_1645  1
    service_2_31_4  free_load_conservation_1646  2
    service_2_31_5  unique_nonzero_owner_367  1
    service_2_31_5  service_visit_def_1645  1
    service_2_31_5  free_load_conservation_1646  3
    service_2_31_6  unique_nonzero_owner_368  1
    service_2_31_6  service_visit_def_1645  1
    service_2_31_6  free_load_conservation_1646  4
    service_2_31_7  unique_nonzero_owner_369  1
    service_2_31_7  service_visit_def_1645  1
    service_2_31_7  free_load_conservation_1646  5
    service_2_31_8  unique_nonzero_owner_370  1
    service_2_31_8  service_visit_def_1645  1
    service_2_31_8  free_load_conservation_1646  6
    service_2_31_9  unique_nonzero_owner_371  1
    service_2_31_9  service_visit_def_1645  1
    service_2_31_9  free_load_conservation_1646  7
    service_2_31_10  unique_nonzero_owner_372  1
    service_2_31_10  service_visit_def_1645  1
    service_2_31_10  free_load_conservation_1646  8
    service_2_31_11  unique_nonzero_owner_373  1
    service_2_31_11  service_visit_def_1645  1
    service_2_31_11  free_load_conservation_1646  9
    service_2_31_12  unique_nonzero_owner_374  1
    service_2_31_12  service_visit_def_1645  1
    service_2_31_12  free_load_conservation_1646  10
    service_0_3_0  unique_nonzero_owner_375  1
    service_0_3_0  service_visit_def_902  1
    service_0_3_0  free_load_conservation_903  -12
    service_0_3_0  original_T_including_depot_unload_933  1440
    service_0_3_1  unique_nonzero_owner_376  1
    service_0_3_1  service_visit_def_902  1
    service_0_3_1  free_load_conservation_903  -11
    service_0_3_1  original_T_including_depot_unload_933  1320
    service_0_3_2  unique_nonzero_owner_377  1
    service_0_3_2  service_visit_def_902  1
    service_0_3_2  free_load_conservation_903  -10
    service_0_3_2  original_T_including_depot_unload_933  1200
    service_0_3_3  unique_nonzero_owner_378  1
    service_0_3_3  service_visit_def_902  1
    service_0_3_3  free_load_conservation_903  -9
    service_0_3_3  original_T_including_depot_unload_933  1080
    service_0_3_4  unique_nonzero_owner_379  1
    service_0_3_4  service_visit_def_902  1
    service_0_3_4  free_load_conservation_903  -8
    service_0_3_4  original_T_including_depot_unload_933  960
    service_0_3_5  unique_nonzero_owner_380  1
    service_0_3_5  service_visit_def_902  1
    service_0_3_5  free_load_conservation_903  -7
    service_0_3_5  original_T_including_depot_unload_933  840
    service_0_3_6  unique_nonzero_owner_381  1
    service_0_3_6  service_visit_def_902  1
    service_0_3_6  free_load_conservation_903  -6
    service_0_3_6  original_T_including_depot_unload_933  720
    service_0_3_7  unique_nonzero_owner_382  1
    service_0_3_7  service_visit_def_902  1
    service_0_3_7  free_load_conservation_903  -5
    service_0_3_7  original_T_including_depot_unload_933  600
    service_0_3_8  unique_nonzero_owner_383  1
    service_0_3_8  service_visit_def_902  1
    service_0_3_8  free_load_conservation_903  -4
    service_0_3_8  original_T_including_depot_unload_933  480
    service_0_3_9  unique_nonzero_owner_384  1
    service_0_3_9  service_visit_def_902  1
    service_0_3_9  free_load_conservation_903  -3
    service_0_3_9  original_T_including_depot_unload_933  360
    service_0_3_10  unique_nonzero_owner_385  1
    service_0_3_10  service_visit_def_902  1
    service_0_3_10  free_load_conservation_903  -2
    service_0_3_10  original_T_including_depot_unload_933  240
    service_0_3_11  unique_nonzero_owner_386  1
    service_0_3_11  service_visit_def_902  1
    service_0_3_11  free_load_conservation_903  -1
    service_0_3_11  original_T_including_depot_unload_933  120
    service_0_3_13  unique_nonzero_owner_387  1
    service_0_3_13  service_visit_def_902  1
    service_0_3_13  free_load_conservation_903  1
    service_0_3_14  unique_nonzero_owner_388  1
    service_0_3_14  service_visit_def_902  1
    service_0_3_14  free_load_conservation_903  2
    service_0_3_15  unique_nonzero_owner_389  1
    service_0_3_15  service_visit_def_902  1
    service_0_3_15  free_load_conservation_903  3
    service_0_3_16  unique_nonzero_owner_390  1
    service_0_3_16  service_visit_def_902  1
    service_0_3_16  free_load_conservation_903  4
    service_0_3_17  unique_nonzero_owner_391  1
    service_0_3_17  service_visit_def_902  1
    service_0_3_17  free_load_conservation_903  5
    service_1_3_0  unique_nonzero_owner_375  1
    service_1_3_0  service_visit_def_1332  1
    service_1_3_0  free_load_conservation_1333  -12
    service_1_3_0  original_T_including_depot_unload_1362  1440
    service_1_3_1  unique_nonzero_owner_376  1
    service_1_3_1  service_visit_def_1332  1
    service_1_3_1  free_load_conservation_1333  -11
    service_1_3_1  original_T_including_depot_unload_1362  1320
    service_1_3_2  unique_nonzero_owner_377  1
    service_1_3_2  service_visit_def_1332  1
    service_1_3_2  free_load_conservation_1333  -10
    service_1_3_2  original_T_including_depot_unload_1362  1200
    service_1_3_3  unique_nonzero_owner_378  1
    service_1_3_3  service_visit_def_1332  1
    service_1_3_3  free_load_conservation_1333  -9
    service_1_3_3  original_T_including_depot_unload_1362  1080
    service_1_3_4  unique_nonzero_owner_379  1
    service_1_3_4  service_visit_def_1332  1
    service_1_3_4  free_load_conservation_1333  -8
    service_1_3_4  original_T_including_depot_unload_1362  960
    service_1_3_5  unique_nonzero_owner_380  1
    service_1_3_5  service_visit_def_1332  1
    service_1_3_5  free_load_conservation_1333  -7
    service_1_3_5  original_T_including_depot_unload_1362  840
    service_1_3_6  unique_nonzero_owner_381  1
    service_1_3_6  service_visit_def_1332  1
    service_1_3_6  free_load_conservation_1333  -6
    service_1_3_6  original_T_including_depot_unload_1362  720
    service_1_3_7  unique_nonzero_owner_382  1
    service_1_3_7  service_visit_def_1332  1
    service_1_3_7  free_load_conservation_1333  -5
    service_1_3_7  original_T_including_depot_unload_1362  600
    service_1_3_8  unique_nonzero_owner_383  1
    service_1_3_8  service_visit_def_1332  1
    service_1_3_8  free_load_conservation_1333  -4
    service_1_3_8  original_T_including_depot_unload_1362  480
    service_1_3_9  unique_nonzero_owner_384  1
    service_1_3_9  service_visit_def_1332  1
    service_1_3_9  free_load_conservation_1333  -3
    service_1_3_9  original_T_including_depot_unload_1362  360
    service_1_3_10  unique_nonzero_owner_385  1
    service_1_3_10  service_visit_def_1332  1
    service_1_3_10  free_load_conservation_1333  -2
    service_1_3_10  original_T_including_depot_unload_1362  240
    service_1_3_11  unique_nonzero_owner_386  1
    service_1_3_11  service_visit_def_1332  1
    service_1_3_11  free_load_conservation_1333  -1
    service_1_3_11  original_T_including_depot_unload_1362  120
    service_1_3_13  unique_nonzero_owner_387  1
    service_1_3_13  service_visit_def_1332  1
    service_1_3_13  free_load_conservation_1333  1
    service_1_3_14  unique_nonzero_owner_388  1
    service_1_3_14  service_visit_def_1332  1
    service_1_3_14  free_load_conservation_1333  2
    service_1_3_15  unique_nonzero_owner_389  1
    service_1_3_15  service_visit_def_1332  1
    service_1_3_15  free_load_conservation_1333  3
    service_1_3_16  unique_nonzero_owner_390  1
    service_1_3_16  service_visit_def_1332  1
    service_1_3_16  free_load_conservation_1333  4
    service_1_3_17  unique_nonzero_owner_391  1
    service_1_3_17  service_visit_def_1332  1
    service_1_3_17  free_load_conservation_1333  5
    service_2_3_0  unique_nonzero_owner_375  1
    service_2_3_0  service_visit_def_1651  1
    service_2_3_0  free_load_conservation_1652  -12
    service_2_3_0  original_T_including_depot_unload_1679  1440
    service_2_3_1  unique_nonzero_owner_376  1
    service_2_3_1  service_visit_def_1651  1
    service_2_3_1  free_load_conservation_1652  -11
    service_2_3_1  original_T_including_depot_unload_1679  1320
    service_2_3_2  unique_nonzero_owner_377  1
    service_2_3_2  service_visit_def_1651  1
    service_2_3_2  free_load_conservation_1652  -10
    service_2_3_2  original_T_including_depot_unload_1679  1200
    service_2_3_3  unique_nonzero_owner_378  1
    service_2_3_3  service_visit_def_1651  1
    service_2_3_3  free_load_conservation_1652  -9
    service_2_3_3  original_T_including_depot_unload_1679  1080
    service_2_3_4  unique_nonzero_owner_379  1
    service_2_3_4  service_visit_def_1651  1
    service_2_3_4  free_load_conservation_1652  -8
    service_2_3_4  original_T_including_depot_unload_1679  960
    service_2_3_5  unique_nonzero_owner_380  1
    service_2_3_5  service_visit_def_1651  1
    service_2_3_5  free_load_conservation_1652  -7
    service_2_3_5  original_T_including_depot_unload_1679  840
    service_2_3_6  unique_nonzero_owner_381  1
    service_2_3_6  service_visit_def_1651  1
    service_2_3_6  free_load_conservation_1652  -6
    service_2_3_6  original_T_including_depot_unload_1679  720
    service_2_3_7  unique_nonzero_owner_382  1
    service_2_3_7  service_visit_def_1651  1
    service_2_3_7  free_load_conservation_1652  -5
    service_2_3_7  original_T_including_depot_unload_1679  600
    service_2_3_8  unique_nonzero_owner_383  1
    service_2_3_8  service_visit_def_1651  1
    service_2_3_8  free_load_conservation_1652  -4
    service_2_3_8  original_T_including_depot_unload_1679  480
    service_2_3_9  unique_nonzero_owner_384  1
    service_2_3_9  service_visit_def_1651  1
    service_2_3_9  free_load_conservation_1652  -3
    service_2_3_9  original_T_including_depot_unload_1679  360
    service_2_3_10  unique_nonzero_owner_385  1
    service_2_3_10  service_visit_def_1651  1
    service_2_3_10  free_load_conservation_1652  -2
    service_2_3_10  original_T_including_depot_unload_1679  240
    service_2_3_11  unique_nonzero_owner_386  1
    service_2_3_11  service_visit_def_1651  1
    service_2_3_11  free_load_conservation_1652  -1
    service_2_3_11  original_T_including_depot_unload_1679  120
    service_2_3_13  unique_nonzero_owner_387  1
    service_2_3_13  service_visit_def_1651  1
    service_2_3_13  free_load_conservation_1652  1
    service_2_3_14  unique_nonzero_owner_388  1
    service_2_3_14  service_visit_def_1651  1
    service_2_3_14  free_load_conservation_1652  2
    service_2_3_15  unique_nonzero_owner_389  1
    service_2_3_15  service_visit_def_1651  1
    service_2_3_15  free_load_conservation_1652  3
    service_2_3_16  unique_nonzero_owner_390  1
    service_2_3_16  service_visit_def_1651  1
    service_2_3_16  free_load_conservation_1652  4
    service_2_3_17  unique_nonzero_owner_391  1
    service_2_3_17  service_visit_def_1651  1
    service_2_3_17  free_load_conservation_1652  5
    service_0_16_0  unique_nonzero_owner_392  1
    service_0_16_0  service_visit_def_908  1
    service_0_16_0  free_load_conservation_909  -1
    service_0_16_0  original_T_including_depot_unload_933  120
    service_0_16_2  unique_nonzero_owner_393  1
    service_0_16_2  service_visit_def_908  1
    service_0_16_2  free_load_conservation_909  1
    service_0_16_3  unique_nonzero_owner_394  1
    service_0_16_3  service_visit_def_908  1
    service_0_16_3  free_load_conservation_909  2
    service_0_16_4  unique_nonzero_owner_395  1
    service_0_16_4  service_visit_def_908  1
    service_0_16_4  free_load_conservation_909  3
    service_0_16_5  unique_nonzero_owner_396  1
    service_0_16_5  service_visit_def_908  1
    service_0_16_5  free_load_conservation_909  4
    service_0_16_6  unique_nonzero_owner_397  1
    service_0_16_6  service_visit_def_908  1
    service_0_16_6  free_load_conservation_909  5
    service_0_16_7  unique_nonzero_owner_398  1
    service_0_16_7  service_visit_def_908  1
    service_0_16_7  free_load_conservation_909  6
    service_0_16_8  unique_nonzero_owner_399  1
    service_0_16_8  service_visit_def_908  1
    service_0_16_8  free_load_conservation_909  7
    service_0_16_9  unique_nonzero_owner_400  1
    service_0_16_9  service_visit_def_908  1
    service_0_16_9  free_load_conservation_909  8
    service_0_16_10  unique_nonzero_owner_401  1
    service_0_16_10  service_visit_def_908  1
    service_0_16_10  free_load_conservation_909  9
    service_0_16_11  unique_nonzero_owner_402  1
    service_0_16_11  service_visit_def_908  1
    service_0_16_11  free_load_conservation_909  10
    service_0_16_12  unique_nonzero_owner_403  1
    service_0_16_12  service_visit_def_908  1
    service_0_16_12  free_load_conservation_909  11
    service_1_16_0  unique_nonzero_owner_392  1
    service_1_16_0  service_visit_def_1338  1
    service_1_16_0  free_load_conservation_1339  -1
    service_1_16_0  original_T_including_depot_unload_1362  120
    service_1_16_2  unique_nonzero_owner_393  1
    service_1_16_2  service_visit_def_1338  1
    service_1_16_2  free_load_conservation_1339  1
    service_1_16_3  unique_nonzero_owner_394  1
    service_1_16_3  service_visit_def_1338  1
    service_1_16_3  free_load_conservation_1339  2
    service_1_16_4  unique_nonzero_owner_395  1
    service_1_16_4  service_visit_def_1338  1
    service_1_16_4  free_load_conservation_1339  3
    service_1_16_5  unique_nonzero_owner_396  1
    service_1_16_5  service_visit_def_1338  1
    service_1_16_5  free_load_conservation_1339  4
    service_1_16_6  unique_nonzero_owner_397  1
    service_1_16_6  service_visit_def_1338  1
    service_1_16_6  free_load_conservation_1339  5
    service_1_16_7  unique_nonzero_owner_398  1
    service_1_16_7  service_visit_def_1338  1
    service_1_16_7  free_load_conservation_1339  6
    service_1_16_8  unique_nonzero_owner_399  1
    service_1_16_8  service_visit_def_1338  1
    service_1_16_8  free_load_conservation_1339  7
    service_1_16_9  unique_nonzero_owner_400  1
    service_1_16_9  service_visit_def_1338  1
    service_1_16_9  free_load_conservation_1339  8
    service_1_16_10  unique_nonzero_owner_401  1
    service_1_16_10  service_visit_def_1338  1
    service_1_16_10  free_load_conservation_1339  9
    service_1_16_11  unique_nonzero_owner_402  1
    service_1_16_11  service_visit_def_1338  1
    service_1_16_11  free_load_conservation_1339  10
    service_1_16_12  unique_nonzero_owner_403  1
    service_1_16_12  service_visit_def_1338  1
    service_1_16_12  free_load_conservation_1339  11
    service_2_16_0  unique_nonzero_owner_392  1
    service_2_16_0  service_visit_def_1657  1
    service_2_16_0  free_load_conservation_1658  -1
    service_2_16_0  original_T_including_depot_unload_1679  120
    service_2_16_2  unique_nonzero_owner_393  1
    service_2_16_2  service_visit_def_1657  1
    service_2_16_2  free_load_conservation_1658  1
    service_2_16_3  unique_nonzero_owner_394  1
    service_2_16_3  service_visit_def_1657  1
    service_2_16_3  free_load_conservation_1658  2
    service_2_16_4  unique_nonzero_owner_395  1
    service_2_16_4  service_visit_def_1657  1
    service_2_16_4  free_load_conservation_1658  3
    service_2_16_5  unique_nonzero_owner_396  1
    service_2_16_5  service_visit_def_1657  1
    service_2_16_5  free_load_conservation_1658  4
    service_2_16_6  unique_nonzero_owner_397  1
    service_2_16_6  service_visit_def_1657  1
    service_2_16_6  free_load_conservation_1658  5
    service_2_16_7  unique_nonzero_owner_398  1
    service_2_16_7  service_visit_def_1657  1
    service_2_16_7  free_load_conservation_1658  6
    service_2_16_8  unique_nonzero_owner_399  1
    service_2_16_8  service_visit_def_1657  1
    service_2_16_8  free_load_conservation_1658  7
    service_2_16_9  unique_nonzero_owner_400  1
    service_2_16_9  service_visit_def_1657  1
    service_2_16_9  free_load_conservation_1658  8
    service_2_16_10  unique_nonzero_owner_401  1
    service_2_16_10  service_visit_def_1657  1
    service_2_16_10  free_load_conservation_1658  9
    service_2_16_11  unique_nonzero_owner_402  1
    service_2_16_11  service_visit_def_1657  1
    service_2_16_11  free_load_conservation_1658  10
    service_2_16_12  unique_nonzero_owner_403  1
    service_2_16_12  service_visit_def_1657  1
    service_2_16_12  free_load_conservation_1658  11
    service_0_4_0  unique_nonzero_owner_404  1
    service_0_4_0  service_visit_def_914  1
    service_0_4_0  free_load_conservation_915  -11
    service_0_4_0  original_T_including_depot_unload_933  1320
    service_0_4_1  unique_nonzero_owner_405  1
    service_0_4_1  service_visit_def_914  1
    service_0_4_1  free_load_conservation_915  -10
    service_0_4_1  original_T_including_depot_unload_933  1200
    service_0_4_2  unique_nonzero_owner_406  1
    service_0_4_2  service_visit_def_914  1
    service_0_4_2  free_load_conservation_915  -9
    service_0_4_2  original_T_including_depot_unload_933  1080
    service_0_4_3  unique_nonzero_owner_407  1
    service_0_4_3  service_visit_def_914  1
    service_0_4_3  free_load_conservation_915  -8
    service_0_4_3  original_T_including_depot_unload_933  960
    service_0_4_4  unique_nonzero_owner_408  1
    service_0_4_4  service_visit_def_914  1
    service_0_4_4  free_load_conservation_915  -7
    service_0_4_4  original_T_including_depot_unload_933  840
    service_0_4_5  unique_nonzero_owner_409  1
    service_0_4_5  service_visit_def_914  1
    service_0_4_5  free_load_conservation_915  -6
    service_0_4_5  original_T_including_depot_unload_933  720
    service_0_4_6  unique_nonzero_owner_410  1
    service_0_4_6  service_visit_def_914  1
    service_0_4_6  free_load_conservation_915  -5
    service_0_4_6  original_T_including_depot_unload_933  600
    service_0_4_7  unique_nonzero_owner_411  1
    service_0_4_7  service_visit_def_914  1
    service_0_4_7  free_load_conservation_915  -4
    service_0_4_7  original_T_including_depot_unload_933  480
    service_0_4_8  unique_nonzero_owner_412  1
    service_0_4_8  service_visit_def_914  1
    service_0_4_8  free_load_conservation_915  -3
    service_0_4_8  original_T_including_depot_unload_933  360
    service_0_4_9  unique_nonzero_owner_413  1
    service_0_4_9  service_visit_def_914  1
    service_0_4_9  free_load_conservation_915  -2
    service_0_4_9  original_T_including_depot_unload_933  240
    service_0_4_10  unique_nonzero_owner_414  1
    service_0_4_10  service_visit_def_914  1
    service_0_4_10  free_load_conservation_915  -1
    service_0_4_10  original_T_including_depot_unload_933  120
    service_0_4_12  unique_nonzero_owner_415  1
    service_0_4_12  service_visit_def_914  1
    service_0_4_12  free_load_conservation_915  1
    service_0_4_13  unique_nonzero_owner_416  1
    service_0_4_13  service_visit_def_914  1
    service_0_4_13  free_load_conservation_915  2
    service_0_4_14  unique_nonzero_owner_417  1
    service_0_4_14  service_visit_def_914  1
    service_0_4_14  free_load_conservation_915  3
    service_0_4_15  unique_nonzero_owner_418  1
    service_0_4_15  service_visit_def_914  1
    service_0_4_15  free_load_conservation_915  4
    service_1_4_0  unique_nonzero_owner_404  1
    service_1_4_0  service_visit_def_1344  1
    service_1_4_0  free_load_conservation_1345  -11
    service_1_4_0  original_T_including_depot_unload_1362  1320
    service_1_4_1  unique_nonzero_owner_405  1
    service_1_4_1  service_visit_def_1344  1
    service_1_4_1  free_load_conservation_1345  -10
    service_1_4_1  original_T_including_depot_unload_1362  1200
    service_1_4_2  unique_nonzero_owner_406  1
    service_1_4_2  service_visit_def_1344  1
    service_1_4_2  free_load_conservation_1345  -9
    service_1_4_2  original_T_including_depot_unload_1362  1080
    service_1_4_3  unique_nonzero_owner_407  1
    service_1_4_3  service_visit_def_1344  1
    service_1_4_3  free_load_conservation_1345  -8
    service_1_4_3  original_T_including_depot_unload_1362  960
    service_1_4_4  unique_nonzero_owner_408  1
    service_1_4_4  service_visit_def_1344  1
    service_1_4_4  free_load_conservation_1345  -7
    service_1_4_4  original_T_including_depot_unload_1362  840
    service_1_4_5  unique_nonzero_owner_409  1
    service_1_4_5  service_visit_def_1344  1
    service_1_4_5  free_load_conservation_1345  -6
    service_1_4_5  original_T_including_depot_unload_1362  720
    service_1_4_6  unique_nonzero_owner_410  1
    service_1_4_6  service_visit_def_1344  1
    service_1_4_6  free_load_conservation_1345  -5
    service_1_4_6  original_T_including_depot_unload_1362  600
    service_1_4_7  unique_nonzero_owner_411  1
    service_1_4_7  service_visit_def_1344  1
    service_1_4_7  free_load_conservation_1345  -4
    service_1_4_7  original_T_including_depot_unload_1362  480
    service_1_4_8  unique_nonzero_owner_412  1
    service_1_4_8  service_visit_def_1344  1
    service_1_4_8  free_load_conservation_1345  -3
    service_1_4_8  original_T_including_depot_unload_1362  360
    service_1_4_9  unique_nonzero_owner_413  1
    service_1_4_9  service_visit_def_1344  1
    service_1_4_9  free_load_conservation_1345  -2
    service_1_4_9  original_T_including_depot_unload_1362  240
    service_1_4_10  unique_nonzero_owner_414  1
    service_1_4_10  service_visit_def_1344  1
    service_1_4_10  free_load_conservation_1345  -1
    service_1_4_10  original_T_including_depot_unload_1362  120
    service_1_4_12  unique_nonzero_owner_415  1
    service_1_4_12  service_visit_def_1344  1
    service_1_4_12  free_load_conservation_1345  1
    service_1_4_13  unique_nonzero_owner_416  1
    service_1_4_13  service_visit_def_1344  1
    service_1_4_13  free_load_conservation_1345  2
    service_1_4_14  unique_nonzero_owner_417  1
    service_1_4_14  service_visit_def_1344  1
    service_1_4_14  free_load_conservation_1345  3
    service_1_4_15  unique_nonzero_owner_418  1
    service_1_4_15  service_visit_def_1344  1
    service_1_4_15  free_load_conservation_1345  4
    service_2_4_0  unique_nonzero_owner_404  1
    service_2_4_0  service_visit_def_1663  1
    service_2_4_0  free_load_conservation_1664  -11
    service_2_4_0  original_T_including_depot_unload_1679  1320
    service_2_4_1  unique_nonzero_owner_405  1
    service_2_4_1  service_visit_def_1663  1
    service_2_4_1  free_load_conservation_1664  -10
    service_2_4_1  original_T_including_depot_unload_1679  1200
    service_2_4_2  unique_nonzero_owner_406  1
    service_2_4_2  service_visit_def_1663  1
    service_2_4_2  free_load_conservation_1664  -9
    service_2_4_2  original_T_including_depot_unload_1679  1080
    service_2_4_3  unique_nonzero_owner_407  1
    service_2_4_3  service_visit_def_1663  1
    service_2_4_3  free_load_conservation_1664  -8
    service_2_4_3  original_T_including_depot_unload_1679  960
    service_2_4_4  unique_nonzero_owner_408  1
    service_2_4_4  service_visit_def_1663  1
    service_2_4_4  free_load_conservation_1664  -7
    service_2_4_4  original_T_including_depot_unload_1679  840
    service_2_4_5  unique_nonzero_owner_409  1
    service_2_4_5  service_visit_def_1663  1
    service_2_4_5  free_load_conservation_1664  -6
    service_2_4_5  original_T_including_depot_unload_1679  720
    service_2_4_6  unique_nonzero_owner_410  1
    service_2_4_6  service_visit_def_1663  1
    service_2_4_6  free_load_conservation_1664  -5
    service_2_4_6  original_T_including_depot_unload_1679  600
    service_2_4_7  unique_nonzero_owner_411  1
    service_2_4_7  service_visit_def_1663  1
    service_2_4_7  free_load_conservation_1664  -4
    service_2_4_7  original_T_including_depot_unload_1679  480
    service_2_4_8  unique_nonzero_owner_412  1
    service_2_4_8  service_visit_def_1663  1
    service_2_4_8  free_load_conservation_1664  -3
    service_2_4_8  original_T_including_depot_unload_1679  360
    service_2_4_9  unique_nonzero_owner_413  1
    service_2_4_9  service_visit_def_1663  1
    service_2_4_9  free_load_conservation_1664  -2
    service_2_4_9  original_T_including_depot_unload_1679  240
    service_2_4_10  unique_nonzero_owner_414  1
    service_2_4_10  service_visit_def_1663  1
    service_2_4_10  free_load_conservation_1664  -1
    service_2_4_10  original_T_including_depot_unload_1679  120
    service_2_4_12  unique_nonzero_owner_415  1
    service_2_4_12  service_visit_def_1663  1
    service_2_4_12  free_load_conservation_1664  1
    service_2_4_13  unique_nonzero_owner_416  1
    service_2_4_13  service_visit_def_1663  1
    service_2_4_13  free_load_conservation_1664  2
    service_2_4_14  unique_nonzero_owner_417  1
    service_2_4_14  service_visit_def_1663  1
    service_2_4_14  free_load_conservation_1664  3
    service_2_4_15  unique_nonzero_owner_418  1
    service_2_4_15  service_visit_def_1663  1
    service_2_4_15  free_load_conservation_1664  4
    service_0_19_1  unique_nonzero_owner_419  1
    service_0_19_1  service_visit_def_920  1
    service_0_19_1  free_load_conservation_921  1
    service_0_19_2  unique_nonzero_owner_420  1
    service_0_19_2  service_visit_def_920  1
    service_0_19_2  free_load_conservation_921  2
    service_0_19_3  unique_nonzero_owner_421  1
    service_0_19_3  service_visit_def_920  1
    service_0_19_3  free_load_conservation_921  3
    service_0_19_4  unique_nonzero_owner_422  1
    service_0_19_4  service_visit_def_920  1
    service_0_19_4  free_load_conservation_921  4
    service_0_19_5  unique_nonzero_owner_423  1
    service_0_19_5  service_visit_def_920  1
    service_0_19_5  free_load_conservation_921  5
    service_0_19_6  unique_nonzero_owner_424  1
    service_0_19_6  service_visit_def_920  1
    service_0_19_6  free_load_conservation_921  6
    service_0_19_7  unique_nonzero_owner_425  1
    service_0_19_7  service_visit_def_920  1
    service_0_19_7  free_load_conservation_921  7
    service_0_19_8  unique_nonzero_owner_426  1
    service_0_19_8  service_visit_def_920  1
    service_0_19_8  free_load_conservation_921  8
    service_1_19_1  unique_nonzero_owner_419  1
    service_1_19_1  service_visit_def_1350  1
    service_1_19_1  free_load_conservation_1351  1
    service_1_19_2  unique_nonzero_owner_420  1
    service_1_19_2  service_visit_def_1350  1
    service_1_19_2  free_load_conservation_1351  2
    service_1_19_3  unique_nonzero_owner_421  1
    service_1_19_3  service_visit_def_1350  1
    service_1_19_3  free_load_conservation_1351  3
    service_1_19_4  unique_nonzero_owner_422  1
    service_1_19_4  service_visit_def_1350  1
    service_1_19_4  free_load_conservation_1351  4
    service_1_19_5  unique_nonzero_owner_423  1
    service_1_19_5  service_visit_def_1350  1
    service_1_19_5  free_load_conservation_1351  5
    service_1_19_6  unique_nonzero_owner_424  1
    service_1_19_6  service_visit_def_1350  1
    service_1_19_6  free_load_conservation_1351  6
    service_1_19_7  unique_nonzero_owner_425  1
    service_1_19_7  service_visit_def_1350  1
    service_1_19_7  free_load_conservation_1351  7
    service_1_19_8  unique_nonzero_owner_426  1
    service_1_19_8  service_visit_def_1350  1
    service_1_19_8  free_load_conservation_1351  8
    service_2_19_1  unique_nonzero_owner_419  1
    service_2_19_1  service_visit_def_1669  1
    service_2_19_1  free_load_conservation_1670  1
    service_2_19_2  unique_nonzero_owner_420  1
    service_2_19_2  service_visit_def_1669  1
    service_2_19_2  free_load_conservation_1670  2
    service_2_19_3  unique_nonzero_owner_421  1
    service_2_19_3  service_visit_def_1669  1
    service_2_19_3  free_load_conservation_1670  3
    service_2_19_4  unique_nonzero_owner_422  1
    service_2_19_4  service_visit_def_1669  1
    service_2_19_4  free_load_conservation_1670  4
    service_2_19_5  unique_nonzero_owner_423  1
    service_2_19_5  service_visit_def_1669  1
    service_2_19_5  free_load_conservation_1670  5
    service_2_19_6  unique_nonzero_owner_424  1
    service_2_19_6  service_visit_def_1669  1
    service_2_19_6  free_load_conservation_1670  6
    service_2_19_7  unique_nonzero_owner_425  1
    service_2_19_7  service_visit_def_1669  1
    service_2_19_7  free_load_conservation_1670  7
    service_2_19_8  unique_nonzero_owner_426  1
    service_2_19_8  service_visit_def_1669  1
    service_2_19_8  free_load_conservation_1670  8
    service_0_5_0  unique_nonzero_owner_427  1
    service_0_5_0  service_visit_def_926  1
    service_0_5_0  free_load_conservation_927  -2
    service_0_5_0  original_T_including_depot_unload_933  240
    service_0_5_1  unique_nonzero_owner_428  1
    service_0_5_1  service_visit_def_926  1
    service_0_5_1  free_load_conservation_927  -1
    service_0_5_1  original_T_including_depot_unload_933  120
    service_0_5_3  unique_nonzero_owner_429  1
    service_0_5_3  service_visit_def_926  1
    service_0_5_3  free_load_conservation_927  1
    service_0_5_4  unique_nonzero_owner_430  1
    service_0_5_4  service_visit_def_926  1
    service_0_5_4  free_load_conservation_927  2
    service_0_5_5  unique_nonzero_owner_431  1
    service_0_5_5  service_visit_def_926  1
    service_0_5_5  free_load_conservation_927  3
    service_0_5_6  unique_nonzero_owner_432  1
    service_0_5_6  service_visit_def_926  1
    service_0_5_6  free_load_conservation_927  4
    service_0_5_7  unique_nonzero_owner_433  1
    service_0_5_7  service_visit_def_926  1
    service_0_5_7  free_load_conservation_927  5
    service_0_5_8  unique_nonzero_owner_434  1
    service_0_5_8  service_visit_def_926  1
    service_0_5_8  free_load_conservation_927  6
    service_0_5_9  unique_nonzero_owner_435  1
    service_0_5_9  service_visit_def_926  1
    service_0_5_9  free_load_conservation_927  7
    service_0_5_10  unique_nonzero_owner_436  1
    service_0_5_10  service_visit_def_926  1
    service_0_5_10  free_load_conservation_927  8
    service_0_5_11  unique_nonzero_owner_437  1
    service_0_5_11  service_visit_def_926  1
    service_0_5_11  free_load_conservation_927  9
    service_0_5_12  unique_nonzero_owner_438  1
    service_0_5_12  service_visit_def_926  1
    service_0_5_12  free_load_conservation_927  10
    service_0_5_13  unique_nonzero_owner_439  1
    service_0_5_13  service_visit_def_926  1
    service_0_5_13  free_load_conservation_927  11
    service_0_5_14  unique_nonzero_owner_440  1
    service_0_5_14  service_visit_def_926  1
    service_0_5_14  free_load_conservation_927  12
    service_0_5_15  unique_nonzero_owner_441  1
    service_0_5_15  service_visit_def_926  1
    service_0_5_15  free_load_conservation_927  13
    service_0_5_16  unique_nonzero_owner_442  1
    service_0_5_16  service_visit_def_926  1
    service_0_5_16  free_load_conservation_927  14
    service_1_5_0  unique_nonzero_owner_427  1
    service_1_5_0  service_visit_def_1356  1
    service_1_5_0  free_load_conservation_1357  -2
    service_1_5_0  original_T_including_depot_unload_1362  240
    service_1_5_1  unique_nonzero_owner_428  1
    service_1_5_1  service_visit_def_1356  1
    service_1_5_1  free_load_conservation_1357  -1
    service_1_5_1  original_T_including_depot_unload_1362  120
    service_1_5_3  unique_nonzero_owner_429  1
    service_1_5_3  service_visit_def_1356  1
    service_1_5_3  free_load_conservation_1357  1
    service_1_5_4  unique_nonzero_owner_430  1
    service_1_5_4  service_visit_def_1356  1
    service_1_5_4  free_load_conservation_1357  2
    service_1_5_5  unique_nonzero_owner_431  1
    service_1_5_5  service_visit_def_1356  1
    service_1_5_5  free_load_conservation_1357  3
    service_1_5_6  unique_nonzero_owner_432  1
    service_1_5_6  service_visit_def_1356  1
    service_1_5_6  free_load_conservation_1357  4
    service_1_5_7  unique_nonzero_owner_433  1
    service_1_5_7  service_visit_def_1356  1
    service_1_5_7  free_load_conservation_1357  5
    service_1_5_8  unique_nonzero_owner_434  1
    service_1_5_8  service_visit_def_1356  1
    service_1_5_8  free_load_conservation_1357  6
    service_1_5_9  unique_nonzero_owner_435  1
    service_1_5_9  service_visit_def_1356  1
    service_1_5_9  free_load_conservation_1357  7
    service_1_5_10  unique_nonzero_owner_436  1
    service_1_5_10  service_visit_def_1356  1
    service_1_5_10  free_load_conservation_1357  8
    service_1_5_11  unique_nonzero_owner_437  1
    service_1_5_11  service_visit_def_1356  1
    service_1_5_11  free_load_conservation_1357  9
    service_1_5_12  unique_nonzero_owner_438  1
    service_1_5_12  service_visit_def_1356  1
    service_1_5_12  free_load_conservation_1357  10
    service_1_5_13  unique_nonzero_owner_439  1
    service_1_5_13  service_visit_def_1356  1
    service_1_5_13  free_load_conservation_1357  11
    service_1_5_14  unique_nonzero_owner_440  1
    service_1_5_14  service_visit_def_1356  1
    service_1_5_14  free_load_conservation_1357  12
    service_1_5_15  unique_nonzero_owner_441  1
    service_1_5_15  service_visit_def_1356  1
    service_1_5_15  free_load_conservation_1357  13
    service_1_5_16  unique_nonzero_owner_442  1
    service_1_5_16  service_visit_def_1356  1
    service_1_5_16  free_load_conservation_1357  14
    service_2_5_0  unique_nonzero_owner_427  1
    service_2_5_0  service_visit_def_1675  1
    service_2_5_0  free_load_conservation_1676  -2
    service_2_5_0  original_T_including_depot_unload_1679  240
    service_2_5_1  unique_nonzero_owner_428  1
    service_2_5_1  service_visit_def_1675  1
    service_2_5_1  free_load_conservation_1676  -1
    service_2_5_1  original_T_including_depot_unload_1679  120
    service_2_5_3  unique_nonzero_owner_429  1
    service_2_5_3  service_visit_def_1675  1
    service_2_5_3  free_load_conservation_1676  1
    service_2_5_4  unique_nonzero_owner_430  1
    service_2_5_4  service_visit_def_1675  1
    service_2_5_4  free_load_conservation_1676  2
    service_2_5_5  unique_nonzero_owner_431  1
    service_2_5_5  service_visit_def_1675  1
    service_2_5_5  free_load_conservation_1676  3
    service_2_5_6  unique_nonzero_owner_432  1
    service_2_5_6  service_visit_def_1675  1
    service_2_5_6  free_load_conservation_1676  4
    service_2_5_7  unique_nonzero_owner_433  1
    service_2_5_7  service_visit_def_1675  1
    service_2_5_7  free_load_conservation_1676  5
    service_2_5_8  unique_nonzero_owner_434  1
    service_2_5_8  service_visit_def_1675  1
    service_2_5_8  free_load_conservation_1676  6
    service_2_5_9  unique_nonzero_owner_435  1
    service_2_5_9  service_visit_def_1675  1
    service_2_5_9  free_load_conservation_1676  7
    service_2_5_10  unique_nonzero_owner_436  1
    service_2_5_10  service_visit_def_1675  1
    service_2_5_10  free_load_conservation_1676  8
    service_2_5_11  unique_nonzero_owner_437  1
    service_2_5_11  service_visit_def_1675  1
    service_2_5_11  free_load_conservation_1676  9
    service_2_5_12  unique_nonzero_owner_438  1
    service_2_5_12  service_visit_def_1675  1
    service_2_5_12  free_load_conservation_1676  10
    service_2_5_13  unique_nonzero_owner_439  1
    service_2_5_13  service_visit_def_1675  1
    service_2_5_13  free_load_conservation_1676  11
    service_2_5_14  unique_nonzero_owner_440  1
    service_2_5_14  service_visit_def_1675  1
    service_2_5_14  free_load_conservation_1676  12
    service_2_5_15  unique_nonzero_owner_441  1
    service_2_5_15  service_visit_def_1675  1
    service_2_5_15  free_load_conservation_1676  13
    service_2_5_16  unique_nonzero_owner_442  1
    service_2_5_16  service_visit_def_1675  1
    service_2_5_16  free_load_conservation_1676  14
    MARKER    'MARKER'                 'INTEND'
    visit_0_1  out_degree_838  -1
    visit_0_1  in_degree_839  -1
    visit_0_1  order_active_lb_840  -1
    visit_0_1  order_active_ub_841  -14
    order_0_1  connected_order_arc_460  -1
    order_0_1  connected_order_arc_462  -1
    order_0_1  connected_order_arc_464  -1
    order_0_1  connected_order_arc_466  -1
    order_0_1  connected_order_arc_468  -1
    order_0_1  connected_order_arc_470  -1
    order_0_1  connected_order_arc_472  -1
    order_0_1  connected_order_arc_474  -1
    order_0_1  connected_order_arc_476  -1
    order_0_1  connected_order_arc_478  -1
    order_0_1  connected_order_arc_480  -1
    order_0_1  connected_order_arc_482  -1
    order_0_1  connected_order_arc_484  -1
    order_0_1  connected_order_arc_487  1
    order_0_1  connected_order_arc_514  1
    order_0_1  connected_order_arc_541  1
    order_0_1  connected_order_arc_568  1
    order_0_1  connected_order_arc_595  1
    order_0_1  connected_order_arc_622  1
    order_0_1  connected_order_arc_649  1
    order_0_1  connected_order_arc_676  1
    order_0_1  connected_order_arc_703  1
    order_0_1  connected_order_arc_730  1
    order_0_1  connected_order_arc_757  1
    order_0_1  connected_order_arc_784  1
    order_0_1  connected_order_arc_811  1
    order_0_1  order_active_lb_840  1
    order_0_1  order_active_ub_841  1
    order_0_1  fixed_segment_relative_order_928  -1
    visit_0_2  out_degree_845  -1
    visit_0_2  in_degree_846  -1
    visit_0_2  order_active_lb_847  -1
    visit_0_2  order_active_ub_848  -14
    order_0_2  connected_order_arc_460  1
    order_0_2  connected_order_arc_487  -1
    order_0_2  connected_order_arc_489  -1
    order_0_2  connected_order_arc_491  -1
    order_0_2  connected_order_arc_493  -1
    order_0_2  connected_order_arc_495  -1
    order_0_2  connected_order_arc_497  -1
    order_0_2  connected_order_arc_499  -1
    order_0_2  connected_order_arc_501  -1
    order_0_2  connected_order_arc_503  -1
    order_0_2  connected_order_arc_505  -1
    order_0_2  connected_order_arc_507  -1
    order_0_2  connected_order_arc_509  -1
    order_0_2  connected_order_arc_511  -1
    order_0_2  connected_order_arc_516  1
    order_0_2  connected_order_arc_543  1
    order_0_2  connected_order_arc_570  1
    order_0_2  connected_order_arc_597  1
    order_0_2  connected_order_arc_624  1
    order_0_2  connected_order_arc_651  1
    order_0_2  connected_order_arc_678  1
    order_0_2  connected_order_arc_705  1
    order_0_2  connected_order_arc_732  1
    order_0_2  connected_order_arc_759  1
    order_0_2  connected_order_arc_786  1
    order_0_2  connected_order_arc_813  1
    order_0_2  order_active_lb_847  1
    order_0_2  order_active_ub_848  1
    order_0_2  fixed_segment_relative_order_928  1
    order_0_2  fixed_segment_relative_order_929  -1
    visit_0_3  out_degree_852  -1
    visit_0_3  in_degree_853  -1
    visit_0_3  order_active_lb_854  -1
    visit_0_3  order_active_ub_855  -14
    order_0_3  connected_order_arc_462  1
    order_0_3  connected_order_arc_489  1
    order_0_3  connected_order_arc_514  -1
    order_0_3  connected_order_arc_516  -1
    order_0_3  connected_order_arc_518  -1
    order_0_3  connected_order_arc_520  -1
    order_0_3  connected_order_arc_522  -1
    order_0_3  connected_order_arc_524  -1
    order_0_3  connected_order_arc_526  -1
    order_0_3  connected_order_arc_528  -1
    order_0_3  connected_order_arc_530  -1
    order_0_3  connected_order_arc_532  -1
    order_0_3  connected_order_arc_534  -1
    order_0_3  connected_order_arc_536  -1
    order_0_3  connected_order_arc_538  -1
    order_0_3  connected_order_arc_545  1
    order_0_3  connected_order_arc_572  1
    order_0_3  connected_order_arc_599  1
    order_0_3  connected_order_arc_626  1
    order_0_3  connected_order_arc_653  1
    order_0_3  connected_order_arc_680  1
    order_0_3  connected_order_arc_707  1
    order_0_3  connected_order_arc_734  1
    order_0_3  connected_order_arc_761  1
    order_0_3  connected_order_arc_788  1
    order_0_3  connected_order_arc_815  1
    order_0_3  order_active_lb_854  1
    order_0_3  order_active_ub_855  1
    order_0_3  fixed_segment_relative_order_929  1
    order_0_3  fixed_segment_relative_order_930  -1
    visit_0_4  out_degree_859  -1
    visit_0_4  in_degree_860  -1
    visit_0_4  order_active_lb_861  -1
    visit_0_4  order_active_ub_862  -14
    order_0_4  connected_order_arc_464  1
    order_0_4  connected_order_arc_491  1
    order_0_4  connected_order_arc_518  1
    order_0_4  connected_order_arc_541  -1
    order_0_4  connected_order_arc_543  -1
    order_0_4  connected_order_arc_545  -1
    order_0_4  connected_order_arc_547  -1
    order_0_4  connected_order_arc_549  -1
    order_0_4  connected_order_arc_551  -1
    order_0_4  connected_order_arc_553  -1
    order_0_4  connected_order_arc_555  -1
    order_0_4  connected_order_arc_557  -1
    order_0_4  connected_order_arc_559  -1
    order_0_4  connected_order_arc_561  -1
    order_0_4  connected_order_arc_563  -1
    order_0_4  connected_order_arc_565  -1
    order_0_4  connected_order_arc_574  1
    order_0_4  connected_order_arc_601  1
    order_0_4  connected_order_arc_628  1
    order_0_4  connected_order_arc_655  1
    order_0_4  connected_order_arc_682  1
    order_0_4  connected_order_arc_709  1
    order_0_4  connected_order_arc_736  1
    order_0_4  connected_order_arc_763  1
    order_0_4  connected_order_arc_790  1
    order_0_4  connected_order_arc_817  1
    order_0_4  order_active_lb_861  1
    order_0_4  order_active_ub_862  1
    order_0_4  fixed_segment_relative_order_930  1
    order_0_4  fixed_segment_relative_order_931  -1
    visit_0_5  out_degree_866  -1
    visit_0_5  in_degree_867  -1
    visit_0_5  order_active_lb_868  -1
    visit_0_5  order_active_ub_869  -14
    order_0_5  connected_order_arc_466  1
    order_0_5  connected_order_arc_493  1
    order_0_5  connected_order_arc_520  1
    order_0_5  connected_order_arc_547  1
    order_0_5  connected_order_arc_568  -1
    order_0_5  connected_order_arc_570  -1
    order_0_5  connected_order_arc_572  -1
    order_0_5  connected_order_arc_574  -1
    order_0_5  connected_order_arc_576  -1
    order_0_5  connected_order_arc_578  -1
    order_0_5  connected_order_arc_580  -1
    order_0_5  connected_order_arc_582  -1
    order_0_5  connected_order_arc_584  -1
    order_0_5  connected_order_arc_586  -1
    order_0_5  connected_order_arc_588  -1
    order_0_5  connected_order_arc_590  -1
    order_0_5  connected_order_arc_592  -1
    order_0_5  connected_order_arc_603  1
    order_0_5  connected_order_arc_630  1
    order_0_5  connected_order_arc_657  1
    order_0_5  connected_order_arc_684  1
    order_0_5  connected_order_arc_711  1
    order_0_5  connected_order_arc_738  1
    order_0_5  connected_order_arc_765  1
    order_0_5  connected_order_arc_792  1
    order_0_5  connected_order_arc_819  1
    order_0_5  order_active_lb_868  1
    order_0_5  order_active_ub_869  1
    order_0_5  fixed_segment_relative_order_931  1
    order_0_5  fixed_segment_relative_order_932  -1
    visit_0_6  out_degree_873  -1
    visit_0_6  in_degree_874  -1
    visit_0_6  order_active_lb_875  -1
    visit_0_6  order_active_ub_876  -14
    order_0_6  connected_order_arc_468  1
    order_0_6  connected_order_arc_495  1
    order_0_6  connected_order_arc_522  1
    order_0_6  connected_order_arc_549  1
    order_0_6  connected_order_arc_576  1
    order_0_6  connected_order_arc_595  -1
    order_0_6  connected_order_arc_597  -1
    order_0_6  connected_order_arc_599  -1
    order_0_6  connected_order_arc_601  -1
    order_0_6  connected_order_arc_603  -1
    order_0_6  connected_order_arc_605  -1
    order_0_6  connected_order_arc_607  -1
    order_0_6  connected_order_arc_609  -1
    order_0_6  connected_order_arc_611  -1
    order_0_6  connected_order_arc_613  -1
    order_0_6  connected_order_arc_615  -1
    order_0_6  connected_order_arc_617  -1
    order_0_6  connected_order_arc_619  -1
    order_0_6  connected_order_arc_632  1
    order_0_6  connected_order_arc_659  1
    order_0_6  connected_order_arc_686  1
    order_0_6  connected_order_arc_713  1
    order_0_6  connected_order_arc_740  1
    order_0_6  connected_order_arc_767  1
    order_0_6  connected_order_arc_794  1
    order_0_6  connected_order_arc_821  1
    order_0_6  order_active_lb_875  1
    order_0_6  order_active_ub_876  1
    order_0_6  fixed_segment_relative_order_932  1
    visit_0_15  out_degree_880  -1
    visit_0_15  in_degree_881  -1
    visit_0_15  order_active_lb_882  -1
    visit_0_15  order_active_ub_883  -14
    visit_0_15  service_visit_def_884  -1
    order_0_15  connected_order_arc_470  1
    order_0_15  connected_order_arc_497  1
    order_0_15  connected_order_arc_524  1
    order_0_15  connected_order_arc_551  1
    order_0_15  connected_order_arc_578  1
    order_0_15  connected_order_arc_605  1
    order_0_15  connected_order_arc_622  -1
    order_0_15  connected_order_arc_624  -1
    order_0_15  connected_order_arc_626  -1
    order_0_15  connected_order_arc_628  -1
    order_0_15  connected_order_arc_630  -1
    order_0_15  connected_order_arc_632  -1
    order_0_15  connected_order_arc_634  -1
    order_0_15  connected_order_arc_636  -1
    order_0_15  connected_order_arc_638  -1
    order_0_15  connected_order_arc_640  -1
    order_0_15  connected_order_arc_642  -1
    order_0_15  connected_order_arc_644  -1
    order_0_15  connected_order_arc_646  -1
    order_0_15  connected_order_arc_661  1
    order_0_15  connected_order_arc_688  1
    order_0_15  connected_order_arc_715  1
    order_0_15  connected_order_arc_742  1
    order_0_15  connected_order_arc_769  1
    order_0_15  connected_order_arc_796  1
    order_0_15  connected_order_arc_823  1
    order_0_15  order_active_lb_882  1
    order_0_15  order_active_ub_883  1
    visit_0_16  out_degree_886  -1
    visit_0_16  in_degree_887  -1
    visit_0_16  order_active_lb_888  -1
    visit_0_16  order_active_ub_889  -14
    visit_0_16  service_visit_def_890  -1
    order_0_16  connected_order_arc_472  1
    order_0_16  connected_order_arc_499  1
    order_0_16  connected_order_arc_526  1
    order_0_16  connected_order_arc_553  1
    order_0_16  connected_order_arc_580  1
    order_0_16  connected_order_arc_607  1
    order_0_16  connected_order_arc_634  1
    order_0_16  connected_order_arc_649  -1
    order_0_16  connected_order_arc_651  -1
    order_0_16  connected_order_arc_653  -1
    order_0_16  connected_order_arc_655  -1
    order_0_16  connected_order_arc_657  -1
    order_0_16  connected_order_arc_659  -1
    order_0_16  connected_order_arc_661  -1
    order_0_16  connected_order_arc_663  -1
    order_0_16  connected_order_arc_665  -1
    order_0_16  connected_order_arc_667  -1
    order_0_16  connected_order_arc_669  -1
    order_0_16  connected_order_arc_671  -1
    order_0_16  connected_order_arc_673  -1
    order_0_16  connected_order_arc_690  1
    order_0_16  connected_order_arc_717  1
    order_0_16  connected_order_arc_744  1
    order_0_16  connected_order_arc_771  1
    order_0_16  connected_order_arc_798  1
    order_0_16  connected_order_arc_825  1
    order_0_16  order_active_lb_888  1
    order_0_16  order_active_ub_889  1
    visit_0_17  out_degree_892  -1
    visit_0_17  in_degree_893  -1
    visit_0_17  order_active_lb_894  -1
    visit_0_17  order_active_ub_895  -14
    visit_0_17  service_visit_def_896  -1
    order_0_17  connected_order_arc_474  1
    order_0_17  connected_order_arc_501  1
    order_0_17  connected_order_arc_528  1
    order_0_17  connected_order_arc_555  1
    order_0_17  connected_order_arc_582  1
    order_0_17  connected_order_arc_609  1
    order_0_17  connected_order_arc_636  1
    order_0_17  connected_order_arc_663  1
    order_0_17  connected_order_arc_676  -1
    order_0_17  connected_order_arc_678  -1
    order_0_17  connected_order_arc_680  -1
    order_0_17  connected_order_arc_682  -1
    order_0_17  connected_order_arc_684  -1
    order_0_17  connected_order_arc_686  -1
    order_0_17  connected_order_arc_688  -1
    order_0_17  connected_order_arc_690  -1
    order_0_17  connected_order_arc_692  -1
    order_0_17  connected_order_arc_694  -1
    order_0_17  connected_order_arc_696  -1
    order_0_17  connected_order_arc_698  -1
    order_0_17  connected_order_arc_700  -1
    order_0_17  connected_order_arc_719  1
    order_0_17  connected_order_arc_746  1
    order_0_17  connected_order_arc_773  1
    order_0_17  connected_order_arc_800  1
    order_0_17  connected_order_arc_827  1
    order_0_17  order_active_lb_894  1
    order_0_17  order_active_ub_895  1
    visit_0_18  out_degree_898  -1
    visit_0_18  in_degree_899  -1
    visit_0_18  order_active_lb_900  -1
    visit_0_18  order_active_ub_901  -14
    visit_0_18  service_visit_def_902  -1
    order_0_18  connected_order_arc_476  1
    order_0_18  connected_order_arc_503  1
    order_0_18  connected_order_arc_530  1
    order_0_18  connected_order_arc_557  1
    order_0_18  connected_order_arc_584  1
    order_0_18  connected_order_arc_611  1
    order_0_18  connected_order_arc_638  1
    order_0_18  connected_order_arc_665  1
    order_0_18  connected_order_arc_692  1
    order_0_18  connected_order_arc_703  -1
    order_0_18  connected_order_arc_705  -1
    order_0_18  connected_order_arc_707  -1
    order_0_18  connected_order_arc_709  -1
    order_0_18  connected_order_arc_711  -1
    order_0_18  connected_order_arc_713  -1
    order_0_18  connected_order_arc_715  -1
    order_0_18  connected_order_arc_717  -1
    order_0_18  connected_order_arc_719  -1
    order_0_18  connected_order_arc_721  -1
    order_0_18  connected_order_arc_723  -1
    order_0_18  connected_order_arc_725  -1
    order_0_18  connected_order_arc_727  -1
    order_0_18  connected_order_arc_748  1
    order_0_18  connected_order_arc_775  1
    order_0_18  connected_order_arc_802  1
    order_0_18  connected_order_arc_829  1
    order_0_18  order_active_lb_900  1
    order_0_18  order_active_ub_901  1
    visit_0_19  out_degree_904  -1
    visit_0_19  in_degree_905  -1
    visit_0_19  order_active_lb_906  -1
    visit_0_19  order_active_ub_907  -14
    visit_0_19  service_visit_def_908  -1
    order_0_19  connected_order_arc_478  1
    order_0_19  connected_order_arc_505  1
    order_0_19  connected_order_arc_532  1
    order_0_19  connected_order_arc_559  1
    order_0_19  connected_order_arc_586  1
    order_0_19  connected_order_arc_613  1
    order_0_19  connected_order_arc_640  1
    order_0_19  connected_order_arc_667  1
    order_0_19  connected_order_arc_694  1
    order_0_19  connected_order_arc_721  1
    order_0_19  connected_order_arc_730  -1
    order_0_19  connected_order_arc_732  -1
    order_0_19  connected_order_arc_734  -1
    order_0_19  connected_order_arc_736  -1
    order_0_19  connected_order_arc_738  -1
    order_0_19  connected_order_arc_740  -1
    order_0_19  connected_order_arc_742  -1
    order_0_19  connected_order_arc_744  -1
    order_0_19  connected_order_arc_746  -1
    order_0_19  connected_order_arc_748  -1
    order_0_19  connected_order_arc_750  -1
    order_0_19  connected_order_arc_752  -1
    order_0_19  connected_order_arc_754  -1
    order_0_19  connected_order_arc_777  1
    order_0_19  connected_order_arc_804  1
    order_0_19  connected_order_arc_831  1
    order_0_19  order_active_lb_906  1
    order_0_19  order_active_ub_907  1
    visit_0_20  out_degree_910  -1
    visit_0_20  in_degree_911  -1
    visit_0_20  order_active_lb_912  -1
    visit_0_20  order_active_ub_913  -14
    visit_0_20  service_visit_def_914  -1
    order_0_20  connected_order_arc_480  1
    order_0_20  connected_order_arc_507  1
    order_0_20  connected_order_arc_534  1
    order_0_20  connected_order_arc_561  1
    order_0_20  connected_order_arc_588  1
    order_0_20  connected_order_arc_615  1
    order_0_20  connected_order_arc_642  1
    order_0_20  connected_order_arc_669  1
    order_0_20  connected_order_arc_696  1
    order_0_20  connected_order_arc_723  1
    order_0_20  connected_order_arc_750  1
    order_0_20  connected_order_arc_757  -1
    order_0_20  connected_order_arc_759  -1
    order_0_20  connected_order_arc_761  -1
    order_0_20  connected_order_arc_763  -1
    order_0_20  connected_order_arc_765  -1
    order_0_20  connected_order_arc_767  -1
    order_0_20  connected_order_arc_769  -1
    order_0_20  connected_order_arc_771  -1
    order_0_20  connected_order_arc_773  -1
    order_0_20  connected_order_arc_775  -1
    order_0_20  connected_order_arc_777  -1
    order_0_20  connected_order_arc_779  -1
    order_0_20  connected_order_arc_781  -1
    order_0_20  connected_order_arc_806  1
    order_0_20  connected_order_arc_833  1
    order_0_20  order_active_lb_912  1
    order_0_20  order_active_ub_913  1
    visit_0_21  out_degree_916  -1
    visit_0_21  in_degree_917  -1
    visit_0_21  order_active_lb_918  -1
    visit_0_21  order_active_ub_919  -14
    visit_0_21  service_visit_def_920  -1
    order_0_21  connected_order_arc_482  1
    order_0_21  connected_order_arc_509  1
    order_0_21  connected_order_arc_536  1
    order_0_21  connected_order_arc_563  1
    order_0_21  connected_order_arc_590  1
    order_0_21  connected_order_arc_617  1
    order_0_21  connected_order_arc_644  1
    order_0_21  connected_order_arc_671  1
    order_0_21  connected_order_arc_698  1
    order_0_21  connected_order_arc_725  1
    order_0_21  connected_order_arc_752  1
    order_0_21  connected_order_arc_779  1
    order_0_21  connected_order_arc_784  -1
    order_0_21  connected_order_arc_786  -1
    order_0_21  connected_order_arc_788  -1
    order_0_21  connected_order_arc_790  -1
    order_0_21  connected_order_arc_792  -1
    order_0_21  connected_order_arc_794  -1
    order_0_21  connected_order_arc_796  -1
    order_0_21  connected_order_arc_798  -1
    order_0_21  connected_order_arc_800  -1
    order_0_21  connected_order_arc_802  -1
    order_0_21  connected_order_arc_804  -1
    order_0_21  connected_order_arc_806  -1
    order_0_21  connected_order_arc_808  -1
    order_0_21  connected_order_arc_835  1
    order_0_21  order_active_lb_918  1
    order_0_21  order_active_ub_919  1
    visit_0_22  out_degree_922  -1
    visit_0_22  in_degree_923  -1
    visit_0_22  order_active_lb_924  -1
    visit_0_22  order_active_ub_925  -14
    visit_0_22  service_visit_def_926  -1
    order_0_22  connected_order_arc_484  1
    order_0_22  connected_order_arc_511  1
    order_0_22  connected_order_arc_538  1
    order_0_22  connected_order_arc_565  1
    order_0_22  connected_order_arc_592  1
    order_0_22  connected_order_arc_619  1
    order_0_22  connected_order_arc_646  1
    order_0_22  connected_order_arc_673  1
    order_0_22  connected_order_arc_700  1
    order_0_22  connected_order_arc_727  1
    order_0_22  connected_order_arc_754  1
    order_0_22  connected_order_arc_781  1
    order_0_22  connected_order_arc_808  1
    order_0_22  connected_order_arc_811  -1
    order_0_22  connected_order_arc_813  -1
    order_0_22  connected_order_arc_815  -1
    order_0_22  connected_order_arc_817  -1
    order_0_22  connected_order_arc_819  -1
    order_0_22  connected_order_arc_821  -1
    order_0_22  connected_order_arc_823  -1
    order_0_22  connected_order_arc_825  -1
    order_0_22  connected_order_arc_827  -1
    order_0_22  connected_order_arc_829  -1
    order_0_22  connected_order_arc_831  -1
    order_0_22  connected_order_arc_833  -1
    order_0_22  connected_order_arc_835  -1
    order_0_22  order_active_lb_924  1
    order_0_22  order_active_ub_925  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_0  arc_capacity_443  -20
    arc_0_0_0  depot_departure_or_bypass_836  1
    arc_0_0_0  depot_return_or_bypass_837  1
    MARKER    'MARKER'                 'INTEND'
    load_0_0_0  arc_capacity_443  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_1  arc_capacity_444  -20
    arc_0_0_1  depot_departure_or_bypass_836  1
    arc_0_0_1  in_degree_839  1
    arc_0_0_1  original_T_including_depot_unload_933  7.2130540230577469e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_1  arc_capacity_444  1
    load_0_0_1  segment_load_conservation_842  -1
    load_0_0_1  segment_prefix_lb_843  1
    load_0_0_1  segment_prefix_ub_844  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_2  arc_capacity_445  -20
    arc_0_0_2  depot_departure_or_bypass_836  1
    arc_0_0_2  in_degree_846  1
    arc_0_0_2  original_T_including_depot_unload_933  4.9403722507151832e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_2  arc_capacity_445  1
    load_0_0_2  segment_load_conservation_849  -1
    load_0_0_2  segment_prefix_lb_850  1
    load_0_0_2  segment_prefix_ub_851  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_3  arc_capacity_446  -20
    arc_0_0_3  depot_departure_or_bypass_836  1
    arc_0_0_3  in_degree_853  1
    arc_0_0_3  original_T_including_depot_unload_933  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_3  arc_capacity_446  1
    load_0_0_3  segment_load_conservation_856  -1
    load_0_0_3  segment_prefix_lb_857  1
    load_0_0_3  segment_prefix_ub_858  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_4  arc_capacity_447  -20
    arc_0_0_4  depot_departure_or_bypass_836  1
    arc_0_0_4  in_degree_860  1
    arc_0_0_4  original_T_including_depot_unload_933  6.6653528395596720e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_4  arc_capacity_447  1
    load_0_0_4  segment_load_conservation_863  -1
    load_0_0_4  segment_prefix_lb_864  1
    load_0_0_4  segment_prefix_ub_865  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_5  arc_capacity_448  -20
    arc_0_0_5  depot_departure_or_bypass_836  1
    arc_0_0_5  in_degree_867  1
    arc_0_0_5  original_T_including_depot_unload_933  5.9431738885389052e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_5  arc_capacity_448  1
    load_0_0_5  segment_load_conservation_870  -1
    load_0_0_5  segment_prefix_lb_871  1
    load_0_0_5  segment_prefix_ub_872  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_6  arc_capacity_449  -20
    arc_0_0_6  depot_departure_or_bypass_836  1
    arc_0_0_6  in_degree_874  1
    arc_0_0_6  original_T_including_depot_unload_933  4.6364706268001146e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_6  arc_capacity_449  1
    load_0_0_6  segment_load_conservation_877  -1
    load_0_0_6  segment_prefix_lb_878  1
    load_0_0_6  segment_prefix_ub_879  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_15  arc_capacity_450  -20
    arc_0_0_15  depot_departure_or_bypass_836  1
    arc_0_0_15  in_degree_881  1
    arc_0_0_15  original_T_including_depot_unload_933  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_15  arc_capacity_450  1
    load_0_0_15  free_load_conservation_885  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_16  arc_capacity_451  -20
    arc_0_0_16  depot_departure_or_bypass_836  1
    arc_0_0_16  in_degree_887  1
    arc_0_0_16  original_T_including_depot_unload_933  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_16  arc_capacity_451  1
    load_0_0_16  free_load_conservation_891  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_17  arc_capacity_452  -20
    arc_0_0_17  depot_departure_or_bypass_836  1
    arc_0_0_17  in_degree_893  1
    arc_0_0_17  original_T_including_depot_unload_933  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_17  arc_capacity_452  1
    load_0_0_17  free_load_conservation_897  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_18  arc_capacity_453  -20
    arc_0_0_18  depot_departure_or_bypass_836  1
    arc_0_0_18  in_degree_899  1
    arc_0_0_18  original_T_including_depot_unload_933  5.4249700630778887e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_18  arc_capacity_453  1
    load_0_0_18  free_load_conservation_903  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_19  arc_capacity_454  -20
    arc_0_0_19  depot_departure_or_bypass_836  1
    arc_0_0_19  in_degree_905  1
    arc_0_0_19  original_T_including_depot_unload_933  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_19  arc_capacity_454  1
    load_0_0_19  free_load_conservation_909  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_20  arc_capacity_455  -20
    arc_0_0_20  depot_departure_or_bypass_836  1
    arc_0_0_20  in_degree_911  1
    arc_0_0_20  original_T_including_depot_unload_933  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_20  arc_capacity_455  1
    load_0_0_20  free_load_conservation_915  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_21  arc_capacity_456  -20
    arc_0_0_21  depot_departure_or_bypass_836  1
    arc_0_0_21  in_degree_917  1
    arc_0_0_21  original_T_including_depot_unload_933  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_21  arc_capacity_456  1
    load_0_0_21  free_load_conservation_921  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_22  arc_capacity_457  -20
    arc_0_0_22  depot_departure_or_bypass_836  1
    arc_0_0_22  in_degree_923  1
    arc_0_0_22  original_T_including_depot_unload_933  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_22  arc_capacity_457  1
    load_0_0_22  free_load_conservation_927  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_0  arc_capacity_458  -20
    arc_0_1_0  depot_return_or_bypass_837  1
    arc_0_1_0  out_degree_838  1
    arc_0_1_0  original_T_including_depot_unload_933  7.2130540230577469e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_0  arc_capacity_458  1
    load_0_1_0  segment_load_conservation_842  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_2  arc_capacity_459  -20
    arc_0_1_2  connected_order_arc_460  -15
    arc_0_1_2  out_degree_838  1
    arc_0_1_2  in_degree_846  1
    arc_0_1_2  original_T_including_depot_unload_933  2.2729932910497158e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_2  arc_capacity_459  1
    load_0_1_2  segment_load_conservation_842  1
    load_0_1_2  segment_load_conservation_849  -1
    load_0_1_2  segment_prefix_lb_850  1
    load_0_1_2  segment_prefix_ub_851  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_3  arc_capacity_461  -20
    arc_0_1_3  connected_order_arc_462  -15
    arc_0_1_3  out_degree_838  1
    arc_0_1_3  in_degree_853  1
    arc_0_1_3  original_T_including_depot_unload_933  7.7772825846942942e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_3  arc_capacity_461  1
    load_0_1_3  segment_load_conservation_842  1
    load_0_1_3  segment_load_conservation_856  -1
    load_0_1_3  segment_prefix_lb_857  1
    load_0_1_3  segment_prefix_ub_858  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_4  arc_capacity_463  -20
    arc_0_1_4  connected_order_arc_464  -15
    arc_0_1_4  out_degree_838  1
    arc_0_1_4  in_degree_860  1
    arc_0_1_4  original_T_including_depot_unload_933  880.352897387315
    MARKER    'MARKER'                 'INTEND'
    load_0_1_4  arc_capacity_463  1
    load_0_1_4  segment_load_conservation_842  1
    load_0_1_4  segment_load_conservation_863  -1
    load_0_1_4  segment_prefix_lb_864  1
    load_0_1_4  segment_prefix_ub_865  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_5  arc_capacity_465  -20
    arc_0_1_5  connected_order_arc_466  -15
    arc_0_1_5  out_degree_838  1
    arc_0_1_5  in_degree_867  1
    arc_0_1_5  original_T_including_depot_unload_933  1.0687086794720833e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_5  arc_capacity_465  1
    load_0_1_5  segment_load_conservation_842  1
    load_0_1_5  segment_load_conservation_870  -1
    load_0_1_5  segment_prefix_lb_871  1
    load_0_1_5  segment_prefix_ub_872  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_6  arc_capacity_467  -20
    arc_0_1_6  connected_order_arc_468  -15
    arc_0_1_6  out_degree_838  1
    arc_0_1_6  in_degree_874  1
    arc_0_1_6  original_T_including_depot_unload_933  1.1090437276384578e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_6  arc_capacity_467  1
    load_0_1_6  segment_load_conservation_842  1
    load_0_1_6  segment_load_conservation_877  -1
    load_0_1_6  segment_prefix_lb_878  1
    load_0_1_6  segment_prefix_ub_879  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_15  arc_capacity_469  -20
    arc_0_1_15  connected_order_arc_470  -15
    arc_0_1_15  out_degree_838  1
    arc_0_1_15  in_degree_881  1
    arc_0_1_15  original_T_including_depot_unload_933  4.9242827332511274e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_15  arc_capacity_469  1
    load_0_1_15  segment_load_conservation_842  1
    load_0_1_15  free_load_conservation_885  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_16  arc_capacity_471  -20
    arc_0_1_16  connected_order_arc_472  -15
    arc_0_1_16  out_degree_838  1
    arc_0_1_16  in_degree_887  1
    arc_0_1_16  original_T_including_depot_unload_933  6.6047504008669523e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_16  arc_capacity_471  1
    load_0_1_16  segment_load_conservation_842  1
    load_0_1_16  free_load_conservation_891  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_17  arc_capacity_473  -20
    arc_0_1_17  connected_order_arc_474  -15
    arc_0_1_17  out_degree_838  1
    arc_0_1_17  in_degree_893  1
    arc_0_1_17  original_T_including_depot_unload_933  1.7303231472353602e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_17  arc_capacity_473  1
    load_0_1_17  segment_load_conservation_842  1
    load_0_1_17  free_load_conservation_897  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_18  arc_capacity_475  -20
    arc_0_1_18  connected_order_arc_476  -15
    arc_0_1_18  out_degree_838  1
    arc_0_1_18  in_degree_899  1
    arc_0_1_18  original_T_including_depot_unload_933  3.2367117212973966e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_18  arc_capacity_475  1
    load_0_1_18  segment_load_conservation_842  1
    load_0_1_18  free_load_conservation_903  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_19  arc_capacity_477  -20
    arc_0_1_19  connected_order_arc_478  -15
    arc_0_1_19  out_degree_838  1
    arc_0_1_19  in_degree_905  1
    arc_0_1_19  original_T_including_depot_unload_933  4.6128219015626763e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_19  arc_capacity_477  1
    load_0_1_19  segment_load_conservation_842  1
    load_0_1_19  free_load_conservation_909  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_20  arc_capacity_479  -20
    arc_0_1_20  connected_order_arc_480  -15
    arc_0_1_20  out_degree_838  1
    arc_0_1_20  in_degree_911  1
    arc_0_1_20  original_T_including_depot_unload_933  4.4733407106545638e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_20  arc_capacity_479  1
    load_0_1_20  segment_load_conservation_842  1
    load_0_1_20  free_load_conservation_915  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_21  arc_capacity_481  -20
    arc_0_1_21  connected_order_arc_482  -15
    arc_0_1_21  out_degree_838  1
    arc_0_1_21  in_degree_917  1
    arc_0_1_21  original_T_including_depot_unload_933  1.3669225770244122e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_21  arc_capacity_481  1
    load_0_1_21  segment_load_conservation_842  1
    load_0_1_21  free_load_conservation_921  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_22  arc_capacity_483  -20
    arc_0_1_22  connected_order_arc_484  -15
    arc_0_1_22  out_degree_838  1
    arc_0_1_22  in_degree_923  1
    arc_0_1_22  original_T_including_depot_unload_933  6.3648699141452130e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_22  arc_capacity_483  1
    load_0_1_22  segment_load_conservation_842  1
    load_0_1_22  free_load_conservation_927  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_0  arc_capacity_485  -20
    arc_0_2_0  depot_return_or_bypass_837  1
    arc_0_2_0  out_degree_845  1
    arc_0_2_0  original_T_including_depot_unload_933  4.9403722507151832e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_0  arc_capacity_485  1
    load_0_2_0  segment_load_conservation_849  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_1  arc_capacity_486  -20
    arc_0_2_1  connected_order_arc_487  -15
    arc_0_2_1  in_degree_839  1
    arc_0_2_1  out_degree_845  1
    arc_0_2_1  original_T_including_depot_unload_933  2.2729932910497158e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_1  arc_capacity_486  1
    load_0_2_1  segment_load_conservation_842  -1
    load_0_2_1  segment_prefix_lb_843  1
    load_0_2_1  segment_prefix_ub_844  1
    load_0_2_1  segment_load_conservation_849  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_3  arc_capacity_488  -20
    arc_0_2_3  connected_order_arc_489  -15
    arc_0_2_3  out_degree_845  1
    arc_0_2_3  in_degree_853  1
    arc_0_2_3  original_T_including_depot_unload_933  5.9934197761098949e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_3  arc_capacity_488  1
    load_0_2_3  segment_load_conservation_849  1
    load_0_2_3  segment_load_conservation_856  -1
    load_0_2_3  segment_prefix_lb_857  1
    load_0_2_3  segment_prefix_ub_858  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_4  arc_capacity_490  -20
    arc_0_2_4  connected_order_arc_491  -15
    arc_0_2_4  out_degree_845  1
    arc_0_2_4  in_degree_860  1
    arc_0_2_4  original_T_including_depot_unload_933  750.067997850428
    MARKER    'MARKER'                 'INTEND'
    load_0_2_4  arc_capacity_490  1
    load_0_2_4  segment_load_conservation_849  1
    load_0_2_4  segment_load_conservation_863  -1
    load_0_2_4  segment_prefix_lb_864  1
    load_0_2_4  segment_prefix_ub_865  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_5  arc_capacity_492  -20
    arc_0_2_5  connected_order_arc_493  -15
    arc_0_2_5  out_degree_845  1
    arc_0_2_5  in_degree_867  1
    arc_0_2_5  original_T_including_depot_unload_933  8.8588784481112123e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_5  arc_capacity_492  1
    load_0_2_5  segment_load_conservation_849  1
    load_0_2_5  segment_load_conservation_870  -1
    load_0_2_5  segment_prefix_lb_871  1
    load_0_2_5  segment_prefix_ub_872  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_6  arc_capacity_494  -20
    arc_0_2_6  connected_order_arc_495  -15
    arc_0_2_6  out_degree_845  1
    arc_0_2_6  in_degree_874  1
    arc_0_2_6  original_T_including_depot_unload_933  8.9433085313747858e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_6  arc_capacity_494  1
    load_0_2_6  segment_load_conservation_849  1
    load_0_2_6  segment_load_conservation_877  -1
    load_0_2_6  segment_prefix_lb_878  1
    load_0_2_6  segment_prefix_ub_879  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_15  arc_capacity_496  -20
    arc_0_2_15  connected_order_arc_497  -15
    arc_0_2_15  out_degree_845  1
    arc_0_2_15  in_degree_881  1
    arc_0_2_15  original_T_including_depot_unload_933  3.4754938304534517e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_15  arc_capacity_496  1
    load_0_2_15  segment_load_conservation_849  1
    load_0_2_15  free_load_conservation_885  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_16  arc_capacity_498  -20
    arc_0_2_16  connected_order_arc_499  -15
    arc_0_2_16  out_degree_845  1
    arc_0_2_16  in_degree_887  1
    arc_0_2_16  original_T_including_depot_unload_933  5.1510428418120409e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_16  arc_capacity_498  1
    load_0_2_16  segment_load_conservation_849  1
    load_0_2_16  free_load_conservation_891  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_17  arc_capacity_500  -20
    arc_0_2_17  connected_order_arc_501  -15
    arc_0_2_17  out_degree_845  1
    arc_0_2_17  in_degree_893  1
    arc_0_2_17  original_T_including_depot_unload_933  1.5184659007075070e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_17  arc_capacity_500  1
    load_0_2_17  segment_load_conservation_849  1
    load_0_2_17  free_load_conservation_897  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_18  arc_capacity_502  -20
    arc_0_2_18  connected_order_arc_503  -15
    arc_0_2_18  out_degree_845  1
    arc_0_2_18  in_degree_899  1
    arc_0_2_18  original_T_including_depot_unload_933  2.3159636865750136e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_18  arc_capacity_502  1
    load_0_2_18  segment_load_conservation_849  1
    load_0_2_18  free_load_conservation_903  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_19  arc_capacity_504  -20
    arc_0_2_19  connected_order_arc_505  -15
    arc_0_2_19  out_degree_845  1
    arc_0_2_19  in_degree_905  1
    arc_0_2_19  original_T_including_depot_unload_933  3.7315439746742123e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_19  arc_capacity_504  1
    load_0_2_19  segment_load_conservation_849  1
    load_0_2_19  free_load_conservation_909  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_20  arc_capacity_506  -20
    arc_0_2_20  connected_order_arc_507  -15
    arc_0_2_20  out_degree_845  1
    arc_0_2_20  in_degree_911  1
    arc_0_2_20  original_T_including_depot_unload_933  2.2271784981792140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_20  arc_capacity_506  1
    load_0_2_20  segment_load_conservation_849  1
    load_0_2_20  free_load_conservation_915  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_21  arc_capacity_508  -20
    arc_0_2_21  connected_order_arc_509  -15
    arc_0_2_21  out_degree_845  1
    arc_0_2_21  in_degree_917  1
    arc_0_2_21  original_T_including_depot_unload_933  1.1562172312295786e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_21  arc_capacity_508  1
    load_0_2_21  segment_load_conservation_849  1
    load_0_2_21  free_load_conservation_921  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_22  arc_capacity_510  -20
    arc_0_2_22  connected_order_arc_511  -15
    arc_0_2_22  out_degree_845  1
    arc_0_2_22  in_degree_923  1
    arc_0_2_22  original_T_including_depot_unload_933  5.7237486782756332e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_22  arc_capacity_510  1
    load_0_2_22  segment_load_conservation_849  1
    load_0_2_22  free_load_conservation_927  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_0  arc_capacity_512  -20
    arc_0_3_0  depot_return_or_bypass_837  1
    arc_0_3_0  out_degree_852  1
    arc_0_3_0  original_T_including_depot_unload_933  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_0  arc_capacity_512  1
    load_0_3_0  segment_load_conservation_856  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_1  arc_capacity_513  -20
    arc_0_3_1  connected_order_arc_514  -15
    arc_0_3_1  in_degree_839  1
    arc_0_3_1  out_degree_852  1
    arc_0_3_1  original_T_including_depot_unload_933  7.7772825846942942e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_1  arc_capacity_513  1
    load_0_3_1  segment_load_conservation_842  -1
    load_0_3_1  segment_prefix_lb_843  1
    load_0_3_1  segment_prefix_ub_844  1
    load_0_3_1  segment_load_conservation_856  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_2  arc_capacity_515  -20
    arc_0_3_2  connected_order_arc_516  -15
    arc_0_3_2  in_degree_846  1
    arc_0_3_2  out_degree_852  1
    arc_0_3_2  original_T_including_depot_unload_933  5.9934197761098949e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_2  arc_capacity_515  1
    load_0_3_2  segment_load_conservation_849  -1
    load_0_3_2  segment_prefix_lb_850  1
    load_0_3_2  segment_prefix_ub_851  1
    load_0_3_2  segment_load_conservation_856  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_4  arc_capacity_517  -20
    arc_0_3_4  connected_order_arc_518  -15
    arc_0_3_4  out_degree_852  1
    arc_0_3_4  in_degree_860  1
    arc_0_3_4  original_T_including_depot_unload_933  2.5147997402163108e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_4  arc_capacity_517  1
    load_0_3_4  segment_load_conservation_856  1
    load_0_3_4  segment_load_conservation_863  -1
    load_0_3_4  segment_prefix_lb_864  1
    load_0_3_4  segment_prefix_ub_865  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_5  arc_capacity_519  -20
    arc_0_3_5  connected_order_arc_520  -15
    arc_0_3_5  out_degree_852  1
    arc_0_3_5  in_degree_867  1
    arc_0_3_5  original_T_including_depot_unload_933  2.9098466309579254e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_5  arc_capacity_519  1
    load_0_3_5  segment_load_conservation_856  1
    load_0_3_5  segment_load_conservation_870  -1
    load_0_3_5  segment_prefix_lb_871  1
    load_0_3_5  segment_prefix_ub_872  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_6  arc_capacity_521  -20
    arc_0_3_6  connected_order_arc_522  -15
    arc_0_3_6  out_degree_852  1
    arc_0_3_6  in_degree_874  1
    arc_0_3_6  original_T_including_depot_unload_933  4.1665889045115779e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_6  arc_capacity_521  1
    load_0_3_6  segment_load_conservation_856  1
    load_0_3_6  segment_load_conservation_877  -1
    load_0_3_6  segment_prefix_lb_878  1
    load_0_3_6  segment_prefix_ub_879  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_15  arc_capacity_523  -20
    arc_0_3_15  connected_order_arc_524  -15
    arc_0_3_15  out_degree_852  1
    arc_0_3_15  in_degree_881  1
    arc_0_3_15  original_T_including_depot_unload_933  2.9376641610717382e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_15  arc_capacity_523  1
    load_0_3_15  segment_load_conservation_856  1
    load_0_3_15  free_load_conservation_885  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_16  arc_capacity_525  -20
    arc_0_3_16  connected_order_arc_526  -15
    arc_0_3_16  out_degree_852  1
    arc_0_3_16  in_degree_887  1
    arc_0_3_16  original_T_including_depot_unload_933  1.6597164064313077e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_16  arc_capacity_525  1
    load_0_3_16  segment_load_conservation_856  1
    load_0_3_16  free_load_conservation_891  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_17  arc_capacity_527  -20
    arc_0_3_17  connected_order_arc_528  -15
    arc_0_3_17  out_degree_852  1
    arc_0_3_17  in_degree_893  1
    arc_0_3_17  original_T_including_depot_unload_933  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_17  arc_capacity_527  1
    load_0_3_17  segment_load_conservation_856  1
    load_0_3_17  free_load_conservation_897  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_18  arc_capacity_529  -20
    arc_0_3_18  connected_order_arc_530  -15
    arc_0_3_18  out_degree_852  1
    arc_0_3_18  in_degree_899  1
    arc_0_3_18  original_T_including_depot_unload_933  4.6789193623835109e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_18  arc_capacity_529  1
    load_0_3_18  segment_load_conservation_856  1
    load_0_3_18  free_load_conservation_903  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_19  arc_capacity_531  -20
    arc_0_3_19  connected_order_arc_532  -15
    arc_0_3_19  out_degree_852  1
    arc_0_3_19  in_degree_905  1
    arc_0_3_19  original_T_including_depot_unload_933  8.7684829846426385e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_19  arc_capacity_531  1
    load_0_3_19  segment_load_conservation_856  1
    load_0_3_19  free_load_conservation_909  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_20  arc_capacity_533  -20
    arc_0_3_20  connected_order_arc_534  -15
    arc_0_3_20  out_degree_852  1
    arc_0_3_20  in_degree_911  1
    arc_0_3_20  original_T_including_depot_unload_933  4.2733962838090457e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_20  arc_capacity_533  1
    load_0_3_20  segment_load_conservation_856  1
    load_0_3_20  free_load_conservation_915  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_21  arc_capacity_535  -20
    arc_0_3_21  connected_order_arc_536  -15
    arc_0_3_21  out_degree_852  1
    arc_0_3_21  in_degree_917  1
    arc_0_3_21  original_T_including_depot_unload_933  6.3111682574558915e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_21  arc_capacity_535  1
    load_0_3_21  segment_load_conservation_856  1
    load_0_3_21  free_load_conservation_921  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_22  arc_capacity_537  -20
    arc_0_3_22  connected_order_arc_538  -15
    arc_0_3_22  out_degree_852  1
    arc_0_3_22  in_degree_923  1
    arc_0_3_22  original_T_including_depot_unload_933  3.9864800790786632e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_22  arc_capacity_537  1
    load_0_3_22  segment_load_conservation_856  1
    load_0_3_22  free_load_conservation_927  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_0  arc_capacity_539  -20
    arc_0_4_0  depot_return_or_bypass_837  1
    arc_0_4_0  out_degree_859  1
    arc_0_4_0  original_T_including_depot_unload_933  6.6653528395596720e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_0  arc_capacity_539  1
    load_0_4_0  segment_load_conservation_863  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_1  arc_capacity_540  -20
    arc_0_4_1  connected_order_arc_541  -15
    arc_0_4_1  in_degree_839  1
    arc_0_4_1  out_degree_859  1
    arc_0_4_1  original_T_including_depot_unload_933  880.352897387315
    MARKER    'MARKER'                 'INTEND'
    load_0_4_1  arc_capacity_540  1
    load_0_4_1  segment_load_conservation_842  -1
    load_0_4_1  segment_prefix_lb_843  1
    load_0_4_1  segment_prefix_ub_844  1
    load_0_4_1  segment_load_conservation_863  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_2  arc_capacity_542  -20
    arc_0_4_2  connected_order_arc_543  -15
    arc_0_4_2  in_degree_846  1
    arc_0_4_2  out_degree_859  1
    arc_0_4_2  original_T_including_depot_unload_933  750.067997850428
    MARKER    'MARKER'                 'INTEND'
    load_0_4_2  arc_capacity_542  1
    load_0_4_2  segment_load_conservation_849  -1
    load_0_4_2  segment_prefix_lb_850  1
    load_0_4_2  segment_prefix_ub_851  1
    load_0_4_2  segment_load_conservation_863  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_3  arc_capacity_544  -20
    arc_0_4_3  connected_order_arc_545  -15
    arc_0_4_3  in_degree_853  1
    arc_0_4_3  out_degree_859  1
    arc_0_4_3  original_T_including_depot_unload_933  2.5147997402163108e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_3  arc_capacity_544  1
    load_0_4_3  segment_load_conservation_856  -1
    load_0_4_3  segment_prefix_lb_857  1
    load_0_4_3  segment_prefix_ub_858  1
    load_0_4_3  segment_load_conservation_863  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_5  arc_capacity_546  -20
    arc_0_4_5  connected_order_arc_547  -15
    arc_0_4_5  out_degree_859  1
    arc_0_4_5  in_degree_867  1
    arc_0_4_5  original_T_including_depot_unload_933  3.2985327387120213e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_5  arc_capacity_546  1
    load_0_4_5  segment_load_conservation_863  1
    load_0_4_5  segment_load_conservation_870  -1
    load_0_4_5  segment_prefix_lb_871  1
    load_0_4_5  segment_prefix_ub_872  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_6  arc_capacity_548  -20
    arc_0_4_6  connected_order_arc_549  -15
    arc_0_4_6  out_degree_859  1
    arc_0_4_6  in_degree_874  1
    arc_0_4_6  original_T_including_depot_unload_933  5.8442598457899078e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_6  arc_capacity_548  1
    load_0_4_6  segment_load_conservation_863  1
    load_0_4_6  segment_load_conservation_877  -1
    load_0_4_6  segment_prefix_lb_878  1
    load_0_4_6  segment_prefix_ub_879  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_15  arc_capacity_550  -20
    arc_0_4_15  connected_order_arc_551  -15
    arc_0_4_15  out_degree_859  1
    arc_0_4_15  in_degree_881  1
    arc_0_4_15  original_T_including_depot_unload_933  4.0284428834016438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_15  arc_capacity_550  1
    load_0_4_15  segment_load_conservation_863  1
    load_0_4_15  free_load_conservation_885  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_16  arc_capacity_552  -20
    arc_0_4_16  connected_order_arc_553  -15
    arc_0_4_16  out_degree_859  1
    arc_0_4_16  in_degree_887  1
    arc_0_4_16  original_T_including_depot_unload_933  2.3649901674897566e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_16  arc_capacity_552  1
    load_0_4_16  segment_load_conservation_863  1
    load_0_4_16  free_load_conservation_891  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_17  arc_capacity_554  -20
    arc_0_4_17  connected_order_arc_555  -15
    arc_0_4_17  out_degree_859  1
    arc_0_4_17  in_degree_893  1
    arc_0_4_17  original_T_including_depot_unload_933  1.6292966848558842e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_17  arc_capacity_554  1
    load_0_4_17  segment_load_conservation_863  1
    load_0_4_17  free_load_conservation_897  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_18  arc_capacity_556  -20
    arc_0_4_18  connected_order_arc_557  -15
    arc_0_4_18  out_degree_859  1
    arc_0_4_18  in_degree_899  1
    arc_0_4_18  original_T_including_depot_unload_933  5.5739415765733247e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_18  arc_capacity_556  1
    load_0_4_18  segment_load_conservation_863  1
    load_0_4_18  free_load_conservation_903  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_19  arc_capacity_558  -20
    arc_0_4_19  connected_order_arc_559  -15
    arc_0_4_19  out_degree_859  1
    arc_0_4_19  in_degree_905  1
    arc_0_4_19  original_T_including_depot_unload_933  1.0758099325648966e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_19  arc_capacity_558  1
    load_0_4_19  segment_load_conservation_863  1
    load_0_4_19  free_load_conservation_909  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_20  arc_capacity_560  -20
    arc_0_4_20  connected_order_arc_561  -15
    arc_0_4_20  out_degree_859  1
    arc_0_4_20  in_degree_911  1
    arc_0_4_20  original_T_including_depot_unload_933  628.141943094385
    MARKER    'MARKER'                 'INTEND'
    load_0_4_20  arc_capacity_560  1
    load_0_4_20  segment_load_conservation_863  1
    load_0_4_20  free_load_conservation_915  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_21  arc_capacity_562  -20
    arc_0_4_21  connected_order_arc_563  -15
    arc_0_4_21  out_degree_859  1
    arc_0_4_21  in_degree_917  1
    arc_0_4_21  original_T_including_depot_unload_933  7.2751050611121218e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_21  arc_capacity_562  1
    load_0_4_21  segment_load_conservation_863  1
    load_0_4_21  free_load_conservation_921  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_22  arc_capacity_564  -20
    arc_0_4_22  connected_order_arc_565  -15
    arc_0_4_22  out_degree_859  1
    arc_0_4_22  in_degree_923  1
    arc_0_4_22  original_T_including_depot_unload_933  3.1069481377857926e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_22  arc_capacity_564  1
    load_0_4_22  segment_load_conservation_863  1
    load_0_4_22  free_load_conservation_927  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_0  arc_capacity_566  -20
    arc_0_5_0  depot_return_or_bypass_837  1
    arc_0_5_0  out_degree_866  1
    arc_0_5_0  original_T_including_depot_unload_933  7.2571167924583824e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_0  arc_capacity_566  1
    load_0_5_0  segment_load_conservation_870  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_1  arc_capacity_567  -20
    arc_0_5_1  connected_order_arc_568  -15
    arc_0_5_1  in_degree_839  1
    arc_0_5_1  out_degree_866  1
    arc_0_5_1  original_T_including_depot_unload_933  1.2724370432148053e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_1  arc_capacity_567  1
    load_0_5_1  segment_load_conservation_842  -1
    load_0_5_1  segment_prefix_lb_843  1
    load_0_5_1  segment_prefix_ub_844  1
    load_0_5_1  segment_load_conservation_870  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_2  arc_capacity_569  -20
    arc_0_5_2  connected_order_arc_570  -15
    arc_0_5_2  in_degree_846  1
    arc_0_5_2  out_degree_866  1
    arc_0_5_2  original_T_including_depot_unload_933  1.0799954902659535e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_2  arc_capacity_569  1
    load_0_5_2  segment_load_conservation_849  -1
    load_0_5_2  segment_prefix_lb_850  1
    load_0_5_2  segment_prefix_ub_851  1
    load_0_5_2  segment_load_conservation_870  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_3  arc_capacity_571  -20
    arc_0_5_3  connected_order_arc_572  -15
    arc_0_5_3  in_degree_853  1
    arc_0_5_3  out_degree_866  1
    arc_0_5_3  original_T_including_depot_unload_933  4.9831220386775891e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_3  arc_capacity_571  1
    load_0_5_3  segment_load_conservation_856  -1
    load_0_5_3  segment_prefix_lb_857  1
    load_0_5_3  segment_prefix_ub_858  1
    load_0_5_3  segment_load_conservation_870  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_4  arc_capacity_573  -20
    arc_0_5_4  connected_order_arc_574  -15
    arc_0_5_4  in_degree_860  1
    arc_0_5_4  out_degree_866  1
    arc_0_5_4  original_T_including_depot_unload_933  5.2996691306068044e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_4  arc_capacity_573  1
    load_0_5_4  segment_load_conservation_863  -1
    load_0_5_4  segment_prefix_lb_864  1
    load_0_5_4  segment_prefix_ub_865  1
    load_0_5_4  segment_load_conservation_870  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_6  arc_capacity_575  -20
    arc_0_5_6  connected_order_arc_576  -15
    arc_0_5_6  out_degree_866  1
    arc_0_5_6  in_degree_874  1
    arc_0_5_6  original_T_including_depot_unload_933  3.0055050459786975e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_6  arc_capacity_575  1
    load_0_5_6  segment_load_conservation_870  1
    load_0_5_6  segment_load_conservation_877  -1
    load_0_5_6  segment_prefix_lb_878  1
    load_0_5_6  segment_prefix_ub_879  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_15  arc_capacity_577  -20
    arc_0_5_15  connected_order_arc_578  -15
    arc_0_5_15  out_degree_866  1
    arc_0_5_15  in_degree_881  1
    arc_0_5_15  original_T_including_depot_unload_933  7.9195606724980928e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_15  arc_capacity_577  1
    load_0_5_15  segment_load_conservation_870  1
    load_0_5_15  free_load_conservation_885  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_16  arc_capacity_579  -20
    arc_0_5_16  connected_order_arc_580  -15
    arc_0_5_16  out_degree_866  1
    arc_0_5_16  in_degree_887  1
    arc_0_5_16  original_T_including_depot_unload_933  6.4542450829473034e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_16  arc_capacity_579  1
    load_0_5_16  segment_load_conservation_870  1
    load_0_5_16  free_load_conservation_891  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_17  arc_capacity_581  -20
    arc_0_5_17  connected_order_arc_582  -15
    arc_0_5_17  out_degree_866  1
    arc_0_5_17  in_degree_893  1
    arc_0_5_17  original_T_including_depot_unload_933  1.3163662834239574e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_17  arc_capacity_581  1
    load_0_5_17  segment_load_conservation_870  1
    load_0_5_17  free_load_conservation_897  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_18  arc_capacity_583  -20
    arc_0_5_18  connected_order_arc_584  -15
    arc_0_5_18  out_degree_866  1
    arc_0_5_18  in_degree_899  1
    arc_0_5_18  original_T_including_depot_unload_933  9.6620394708383776e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_18  arc_capacity_583  1
    load_0_5_18  segment_load_conservation_870  1
    load_0_5_18  free_load_conservation_903  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_19  arc_capacity_585  -20
    arc_0_5_19  connected_order_arc_586  -15
    arc_0_5_19  out_degree_866  1
    arc_0_5_19  in_degree_905  1
    arc_0_5_19  original_T_including_depot_unload_933  1.2968499029957554e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_19  arc_capacity_585  1
    load_0_5_19  segment_load_conservation_870  1
    load_0_5_19  free_load_conservation_909  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_20  arc_capacity_587  -20
    arc_0_5_20  connected_order_arc_588  -15
    arc_0_5_20  out_degree_866  1
    arc_0_5_20  in_degree_911  1
    arc_0_5_20  original_T_including_depot_unload_933  8.7876124407720954e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_20  arc_capacity_587  1
    load_0_5_20  segment_load_conservation_870  1
    load_0_5_20  free_load_conservation_915  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_21  arc_capacity_589  -20
    arc_0_5_21  connected_order_arc_590  -15
    arc_0_5_21  out_degree_866  1
    arc_0_5_21  in_degree_917  1
    arc_0_5_21  original_T_including_depot_unload_933  2.3059951477332697e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_21  arc_capacity_589  1
    load_0_5_21  segment_load_conservation_870  1
    load_0_5_21  free_load_conservation_921  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_22  arc_capacity_591  -20
    arc_0_5_22  connected_order_arc_592  -15
    arc_0_5_22  out_degree_866  1
    arc_0_5_22  in_degree_923  1
    arc_0_5_22  original_T_including_depot_unload_933  8.2707974701454475e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_22  arc_capacity_591  1
    load_0_5_22  segment_load_conservation_870  1
    load_0_5_22  free_load_conservation_927  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_0  arc_capacity_593  -20
    arc_0_6_0  depot_return_or_bypass_837  1
    arc_0_6_0  out_degree_873  1
    arc_0_6_0  original_T_including_depot_unload_933  4.6364706268001146e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_0  arc_capacity_593  1
    load_0_6_0  segment_load_conservation_877  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_1  arc_capacity_594  -20
    arc_0_6_1  connected_order_arc_595  -15
    arc_0_6_1  in_degree_839  1
    arc_0_6_1  out_degree_873  1
    arc_0_6_1  original_T_including_depot_unload_933  1.1090437276384578e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_1  arc_capacity_594  1
    load_0_6_1  segment_load_conservation_842  -1
    load_0_6_1  segment_prefix_lb_843  1
    load_0_6_1  segment_prefix_ub_844  1
    load_0_6_1  segment_load_conservation_877  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_2  arc_capacity_596  -20
    arc_0_6_2  connected_order_arc_597  -15
    arc_0_6_2  in_degree_846  1
    arc_0_6_2  out_degree_873  1
    arc_0_6_2  original_T_including_depot_unload_933  8.9433085313747858e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_2  arc_capacity_596  1
    load_0_6_2  segment_load_conservation_849  -1
    load_0_6_2  segment_prefix_lb_850  1
    load_0_6_2  segment_prefix_ub_851  1
    load_0_6_2  segment_load_conservation_877  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_3  arc_capacity_598  -20
    arc_0_6_3  connected_order_arc_599  -15
    arc_0_6_3  in_degree_853  1
    arc_0_6_3  out_degree_873  1
    arc_0_6_3  original_T_including_depot_unload_933  4.1665889045115779e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_3  arc_capacity_598  1
    load_0_6_3  segment_load_conservation_856  -1
    load_0_6_3  segment_prefix_lb_857  1
    load_0_6_3  segment_prefix_ub_858  1
    load_0_6_3  segment_load_conservation_877  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_4  arc_capacity_600  -20
    arc_0_6_4  connected_order_arc_601  -15
    arc_0_6_4  in_degree_860  1
    arc_0_6_4  out_degree_873  1
    arc_0_6_4  original_T_including_depot_unload_933  5.8442598457899078e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_4  arc_capacity_600  1
    load_0_6_4  segment_load_conservation_863  -1
    load_0_6_4  segment_prefix_lb_864  1
    load_0_6_4  segment_prefix_ub_865  1
    load_0_6_4  segment_load_conservation_877  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_5  arc_capacity_602  -20
    arc_0_6_5  connected_order_arc_603  -15
    arc_0_6_5  in_degree_867  1
    arc_0_6_5  out_degree_873  1
    arc_0_6_5  original_T_including_depot_unload_933  2.9706418113632907e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_5  arc_capacity_602  1
    load_0_6_5  segment_load_conservation_870  -1
    load_0_6_5  segment_prefix_lb_871  1
    load_0_6_5  segment_prefix_ub_872  1
    load_0_6_5  segment_load_conservation_877  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_15  arc_capacity_604  -20
    arc_0_6_15  connected_order_arc_605  -15
    arc_0_6_15  out_degree_873  1
    arc_0_6_15  in_degree_881  1
    arc_0_6_15  original_T_including_depot_unload_933  6.7868877694996661e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_15  arc_capacity_604  1
    load_0_6_15  segment_load_conservation_877  1
    load_0_6_15  free_load_conservation_885  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_16  arc_capacity_606  -20
    arc_0_6_16  connected_order_arc_607  -15
    arc_0_6_16  out_degree_873  1
    arc_0_6_16  in_degree_887  1
    arc_0_6_16  original_T_including_depot_unload_933  5.8212369880329140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_16  arc_capacity_606  1
    load_0_6_16  segment_load_conservation_877  1
    load_0_6_16  free_load_conservation_891  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_17  arc_capacity_608  -20
    arc_0_6_17  connected_order_arc_609  -15
    arc_0_6_17  out_degree_873  1
    arc_0_6_17  in_degree_893  1
    arc_0_6_17  original_T_including_depot_unload_933  1075.72043838369
    MARKER    'MARKER'                 'INTEND'
    load_0_6_17  arc_capacity_608  1
    load_0_6_17  segment_load_conservation_877  1
    load_0_6_17  free_load_conservation_897  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_18  arc_capacity_610  -20
    arc_0_6_18  connected_order_arc_611  -15
    arc_0_6_18  out_degree_873  1
    arc_0_6_18  in_degree_899  1
    arc_0_6_18  original_T_including_depot_unload_933  839.148853987777
    MARKER    'MARKER'                 'INTEND'
    load_0_6_18  arc_capacity_610  1
    load_0_6_18  segment_load_conservation_877  1
    load_0_6_18  free_load_conservation_903  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_19  arc_capacity_612  -20
    arc_0_6_19  connected_order_arc_613  -15
    arc_0_6_19  out_degree_873  1
    arc_0_6_19  in_degree_905  1
    arc_0_6_19  original_T_including_depot_unload_933  1.0491196843462671e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_19  arc_capacity_612  1
    load_0_6_19  segment_load_conservation_877  1
    load_0_6_19  free_load_conservation_909  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_20  arc_capacity_614  -20
    arc_0_6_20  connected_order_arc_615  -15
    arc_0_6_20  out_degree_873  1
    arc_0_6_20  in_degree_911  1
    arc_0_6_20  original_T_including_depot_unload_933  6.7517249538835438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_20  arc_capacity_614  1
    load_0_6_20  segment_load_conservation_877  1
    load_0_6_20  free_load_conservation_915  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_21  arc_capacity_616  -20
    arc_0_6_21  connected_order_arc_617  -15
    arc_0_6_21  out_degree_873  1
    arc_0_6_21  in_degree_917  1
    arc_0_6_21  original_T_including_depot_unload_933  2.6602972191926557e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_21  arc_capacity_616  1
    load_0_6_21  segment_load_conservation_877  1
    load_0_6_21  free_load_conservation_921  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_22  arc_capacity_618  -20
    arc_0_6_22  connected_order_arc_619  -15
    arc_0_6_22  out_degree_873  1
    arc_0_6_22  in_degree_923  1
    arc_0_6_22  original_T_including_depot_unload_933  8.1289340937717509e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_22  arc_capacity_618  1
    load_0_6_22  segment_load_conservation_877  1
    load_0_6_22  free_load_conservation_927  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_0  arc_capacity_620  -20
    arc_0_15_0  depot_return_or_bypass_837  1
    arc_0_15_0  out_degree_880  1
    arc_0_15_0  original_T_including_depot_unload_933  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_0  arc_capacity_620  1
    load_0_15_0  free_load_conservation_885  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_1  arc_capacity_621  -20
    arc_0_15_1  connected_order_arc_622  -15
    arc_0_15_1  in_degree_839  1
    arc_0_15_1  out_degree_880  1
    arc_0_15_1  original_T_including_depot_unload_933  4.9242827332511274e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_1  arc_capacity_621  1
    load_0_15_1  segment_load_conservation_842  -1
    load_0_15_1  segment_prefix_lb_843  1
    load_0_15_1  segment_prefix_ub_844  1
    load_0_15_1  free_load_conservation_885  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_2  arc_capacity_623  -20
    arc_0_15_2  connected_order_arc_624  -15
    arc_0_15_2  in_degree_846  1
    arc_0_15_2  out_degree_880  1
    arc_0_15_2  original_T_including_depot_unload_933  3.4754938304534517e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_2  arc_capacity_623  1
    load_0_15_2  segment_load_conservation_849  -1
    load_0_15_2  segment_prefix_lb_850  1
    load_0_15_2  segment_prefix_ub_851  1
    load_0_15_2  free_load_conservation_885  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_3  arc_capacity_625  -20
    arc_0_15_3  connected_order_arc_626  -15
    arc_0_15_3  in_degree_853  1
    arc_0_15_3  out_degree_880  1
    arc_0_15_3  original_T_including_depot_unload_933  2.9376641610717382e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_3  arc_capacity_625  1
    load_0_15_3  segment_load_conservation_856  -1
    load_0_15_3  segment_prefix_lb_857  1
    load_0_15_3  segment_prefix_ub_858  1
    load_0_15_3  free_load_conservation_885  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_4  arc_capacity_627  -20
    arc_0_15_4  connected_order_arc_628  -15
    arc_0_15_4  in_degree_860  1
    arc_0_15_4  out_degree_880  1
    arc_0_15_4  original_T_including_depot_unload_933  4.0284428834016438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_4  arc_capacity_627  1
    load_0_15_4  segment_load_conservation_863  -1
    load_0_15_4  segment_prefix_lb_864  1
    load_0_15_4  segment_prefix_ub_865  1
    load_0_15_4  free_load_conservation_885  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_5  arc_capacity_629  -20
    arc_0_15_5  connected_order_arc_630  -15
    arc_0_15_5  in_degree_867  1
    arc_0_15_5  out_degree_880  1
    arc_0_15_5  original_T_including_depot_unload_933  5.8227353503177085e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_5  arc_capacity_629  1
    load_0_15_5  segment_load_conservation_870  -1
    load_0_15_5  segment_prefix_lb_871  1
    load_0_15_5  segment_prefix_ub_872  1
    load_0_15_5  free_load_conservation_885  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_6  arc_capacity_631  -20
    arc_0_15_6  connected_order_arc_632  -15
    arc_0_15_6  in_degree_874  1
    arc_0_15_6  out_degree_880  1
    arc_0_15_6  original_T_including_depot_unload_933  6.7868877694996661e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_6  arc_capacity_631  1
    load_0_15_6  segment_load_conservation_877  -1
    load_0_15_6  segment_prefix_lb_878  1
    load_0_15_6  segment_prefix_ub_879  1
    load_0_15_6  free_load_conservation_885  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_16  arc_capacity_633  -20
    arc_0_15_16  connected_order_arc_634  -15
    arc_0_15_16  out_degree_880  1
    arc_0_15_16  in_degree_887  1
    arc_0_15_16  original_T_including_depot_unload_933  1.7053268374267958e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_16  arc_capacity_633  1
    load_0_15_16  free_load_conservation_885  1
    load_0_15_16  free_load_conservation_891  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_17  arc_capacity_635  -20
    arc_0_15_17  connected_order_arc_636  -15
    arc_0_15_17  out_degree_880  1
    arc_0_15_17  in_degree_893  1
    arc_0_15_17  original_T_including_depot_unload_933  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_17  arc_capacity_635  1
    load_0_15_17  free_load_conservation_885  1
    load_0_15_17  free_load_conservation_897  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_18  arc_capacity_637  -20
    arc_0_15_18  connected_order_arc_638  -15
    arc_0_15_18  out_degree_880  1
    arc_0_15_18  in_degree_899  1
    arc_0_15_18  original_T_including_depot_unload_933  1.7461252424213140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_18  arc_capacity_637  1
    load_0_15_18  free_load_conservation_885  1
    load_0_15_18  free_load_conservation_903  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_19  arc_capacity_639  -20
    arc_0_15_19  connected_order_arc_640  -15
    arc_0_15_19  out_degree_880  1
    arc_0_15_19  in_degree_905  1
    arc_0_15_19  original_T_including_depot_unload_933  6.8976718276177132e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_19  arc_capacity_639  1
    load_0_15_19  free_load_conservation_885  1
    load_0_15_19  free_load_conservation_909  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_20  arc_capacity_641  -20
    arc_0_15_20  connected_order_arc_642  -15
    arc_0_15_20  out_degree_880  1
    arc_0_15_20  in_degree_911  1
    arc_0_15_20  original_T_including_depot_unload_933  2.7078292664437623e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_20  arc_capacity_641  1
    load_0_15_20  free_load_conservation_885  1
    load_0_15_20  free_load_conservation_915  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_21  arc_capacity_643  -20
    arc_0_15_21  connected_order_arc_644  -15
    arc_0_15_21  out_degree_880  1
    arc_0_15_21  in_degree_917  1
    arc_0_15_21  original_T_including_depot_unload_933  9.1580557259044724e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_21  arc_capacity_643  1
    load_0_15_21  free_load_conservation_885  1
    load_0_15_21  free_load_conservation_921  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_22  arc_capacity_645  -20
    arc_0_15_22  connected_order_arc_646  -15
    arc_0_15_22  out_degree_880  1
    arc_0_15_22  in_degree_923  1
    arc_0_15_22  original_T_including_depot_unload_933  2.7570828838654035e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_22  arc_capacity_645  1
    load_0_15_22  free_load_conservation_885  1
    load_0_15_22  free_load_conservation_927  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_0  arc_capacity_647  -20
    arc_0_16_0  depot_return_or_bypass_837  1
    arc_0_16_0  out_degree_886  1
    arc_0_16_0  original_T_including_depot_unload_933  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_0  arc_capacity_647  1
    load_0_16_0  free_load_conservation_891  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_1  arc_capacity_648  -20
    arc_0_16_1  connected_order_arc_649  -15
    arc_0_16_1  in_degree_839  1
    arc_0_16_1  out_degree_886  1
    arc_0_16_1  original_T_including_depot_unload_933  6.6047504008669523e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_1  arc_capacity_648  1
    load_0_16_1  segment_load_conservation_842  -1
    load_0_16_1  segment_prefix_lb_843  1
    load_0_16_1  segment_prefix_ub_844  1
    load_0_16_1  free_load_conservation_891  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_2  arc_capacity_650  -20
    arc_0_16_2  connected_order_arc_651  -15
    arc_0_16_2  in_degree_846  1
    arc_0_16_2  out_degree_886  1
    arc_0_16_2  original_T_including_depot_unload_933  5.1510428418120409e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_2  arc_capacity_650  1
    load_0_16_2  segment_load_conservation_849  -1
    load_0_16_2  segment_prefix_lb_850  1
    load_0_16_2  segment_prefix_ub_851  1
    load_0_16_2  free_load_conservation_891  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_3  arc_capacity_652  -20
    arc_0_16_3  connected_order_arc_653  -15
    arc_0_16_3  in_degree_853  1
    arc_0_16_3  out_degree_886  1
    arc_0_16_3  original_T_including_depot_unload_933  1.6597164064313077e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_3  arc_capacity_652  1
    load_0_16_3  segment_load_conservation_856  -1
    load_0_16_3  segment_prefix_lb_857  1
    load_0_16_3  segment_prefix_ub_858  1
    load_0_16_3  free_load_conservation_891  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_4  arc_capacity_654  -20
    arc_0_16_4  connected_order_arc_655  -15
    arc_0_16_4  in_degree_860  1
    arc_0_16_4  out_degree_886  1
    arc_0_16_4  original_T_including_depot_unload_933  2.3649901674897566e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_4  arc_capacity_654  1
    load_0_16_4  segment_load_conservation_863  -1
    load_0_16_4  segment_prefix_lb_864  1
    load_0_16_4  segment_prefix_ub_865  1
    load_0_16_4  free_load_conservation_891  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_5  arc_capacity_656  -20
    arc_0_16_5  connected_order_arc_657  -15
    arc_0_16_5  in_degree_867  1
    arc_0_16_5  out_degree_886  1
    arc_0_16_5  original_T_including_depot_unload_933  4.3129452098285111e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_5  arc_capacity_656  1
    load_0_16_5  segment_load_conservation_870  -1
    load_0_16_5  segment_prefix_lb_871  1
    load_0_16_5  segment_prefix_ub_872  1
    load_0_16_5  free_load_conservation_891  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_6  arc_capacity_658  -20
    arc_0_16_6  connected_order_arc_659  -15
    arc_0_16_6  in_degree_874  1
    arc_0_16_6  out_degree_886  1
    arc_0_16_6  original_T_including_depot_unload_933  5.8212369880329140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_6  arc_capacity_658  1
    load_0_16_6  segment_load_conservation_877  -1
    load_0_16_6  segment_prefix_lb_878  1
    load_0_16_6  segment_prefix_ub_879  1
    load_0_16_6  free_load_conservation_891  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_15  arc_capacity_660  -20
    arc_0_16_15  connected_order_arc_661  -15
    arc_0_16_15  in_degree_881  1
    arc_0_16_15  out_degree_886  1
    arc_0_16_15  original_T_including_depot_unload_933  1.7053268374267958e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_15  arc_capacity_660  1
    load_0_16_15  free_load_conservation_885  -1
    load_0_16_15  free_load_conservation_891  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_17  arc_capacity_662  -20
    arc_0_16_17  connected_order_arc_663  -15
    arc_0_16_17  out_degree_886  1
    arc_0_16_17  in_degree_893  1
    arc_0_16_17  original_T_including_depot_unload_933  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_17  arc_capacity_662  1
    load_0_16_17  free_load_conservation_891  1
    load_0_16_17  free_load_conservation_897  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_18  arc_capacity_664  -20
    arc_0_16_18  connected_order_arc_665  -15
    arc_0_16_18  out_degree_886  1
    arc_0_16_18  in_degree_899  1
    arc_0_16_18  original_T_including_depot_unload_933  3.3800157717255917e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_18  arc_capacity_664  1
    load_0_16_18  free_load_conservation_891  1
    load_0_16_18  free_load_conservation_903  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_19  arc_capacity_666  -20
    arc_0_16_19  connected_order_arc_667  -15
    arc_0_16_19  out_degree_886  1
    arc_0_16_19  in_degree_905  1
    arc_0_16_19  original_T_including_depot_unload_933  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_19  arc_capacity_666  1
    load_0_16_19  free_load_conservation_891  1
    load_0_16_19  free_load_conservation_909  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_20  arc_capacity_668  -20
    arc_0_16_20  connected_order_arc_669  -15
    arc_0_16_20  out_degree_886  1
    arc_0_16_20  in_degree_911  1
    arc_0_16_20  original_T_including_depot_unload_933  3.9758967496529505e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_20  arc_capacity_668  1
    load_0_16_20  free_load_conservation_891  1
    load_0_16_20  free_load_conservation_915  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_21  arc_capacity_670  -20
    arc_0_16_21  connected_order_arc_671  -15
    arc_0_16_21  out_degree_886  1
    arc_0_16_21  in_degree_917  1
    arc_0_16_21  original_T_including_depot_unload_933  7.9403551275216375e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_21  arc_capacity_670  1
    load_0_16_21  free_load_conservation_891  1
    load_0_16_21  free_load_conservation_921  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_22  arc_capacity_672  -20
    arc_0_16_22  connected_order_arc_673  -15
    arc_0_16_22  out_degree_886  1
    arc_0_16_22  in_degree_923  1
    arc_0_16_22  original_T_including_depot_unload_933  2.4111148152767828e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_22  arc_capacity_672  1
    load_0_16_22  free_load_conservation_891  1
    load_0_16_22  free_load_conservation_927  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_0  arc_capacity_674  -20
    arc_0_17_0  depot_return_or_bypass_837  1
    arc_0_17_0  out_degree_892  1
    arc_0_17_0  original_T_including_depot_unload_933  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_0  arc_capacity_674  1
    load_0_17_0  free_load_conservation_897  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_1  arc_capacity_675  -20
    arc_0_17_1  connected_order_arc_676  -15
    arc_0_17_1  in_degree_839  1
    arc_0_17_1  out_degree_892  1
    arc_0_17_1  original_T_including_depot_unload_933  1.7303231472353602e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_1  arc_capacity_675  1
    load_0_17_1  segment_load_conservation_842  -1
    load_0_17_1  segment_prefix_lb_843  1
    load_0_17_1  segment_prefix_ub_844  1
    load_0_17_1  free_load_conservation_897  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_2  arc_capacity_677  -20
    arc_0_17_2  connected_order_arc_678  -15
    arc_0_17_2  in_degree_846  1
    arc_0_17_2  out_degree_892  1
    arc_0_17_2  original_T_including_depot_unload_933  1.5184659007075070e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_2  arc_capacity_677  1
    load_0_17_2  segment_load_conservation_849  -1
    load_0_17_2  segment_prefix_lb_850  1
    load_0_17_2  segment_prefix_ub_851  1
    load_0_17_2  free_load_conservation_897  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_3  arc_capacity_679  -20
    arc_0_17_3  connected_order_arc_680  -15
    arc_0_17_3  in_degree_853  1
    arc_0_17_3  out_degree_892  1
    arc_0_17_3  original_T_including_depot_unload_933  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_3  arc_capacity_679  1
    load_0_17_3  segment_load_conservation_856  -1
    load_0_17_3  segment_prefix_lb_857  1
    load_0_17_3  segment_prefix_ub_858  1
    load_0_17_3  free_load_conservation_897  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_4  arc_capacity_681  -20
    arc_0_17_4  connected_order_arc_682  -15
    arc_0_17_4  in_degree_860  1
    arc_0_17_4  out_degree_892  1
    arc_0_17_4  original_T_including_depot_unload_933  1.6292966848558842e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_4  arc_capacity_681  1
    load_0_17_4  segment_load_conservation_863  -1
    load_0_17_4  segment_prefix_lb_864  1
    load_0_17_4  segment_prefix_ub_865  1
    load_0_17_4  free_load_conservation_897  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_5  arc_capacity_683  -20
    arc_0_17_5  connected_order_arc_684  -15
    arc_0_17_5  in_degree_867  1
    arc_0_17_5  out_degree_892  1
    arc_0_17_5  original_T_including_depot_unload_933  1.3727638439182763e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_5  arc_capacity_683  1
    load_0_17_5  segment_load_conservation_870  -1
    load_0_17_5  segment_prefix_lb_871  1
    load_0_17_5  segment_prefix_ub_872  1
    load_0_17_5  free_load_conservation_897  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_6  arc_capacity_685  -20
    arc_0_17_6  connected_order_arc_686  -15
    arc_0_17_6  in_degree_874  1
    arc_0_17_6  out_degree_892  1
    arc_0_17_6  original_T_including_depot_unload_933  1075.72043838369
    MARKER    'MARKER'                 'INTEND'
    load_0_17_6  arc_capacity_685  1
    load_0_17_6  segment_load_conservation_877  -1
    load_0_17_6  segment_prefix_lb_878  1
    load_0_17_6  segment_prefix_ub_879  1
    load_0_17_6  free_load_conservation_897  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_15  arc_capacity_687  -20
    arc_0_17_15  connected_order_arc_688  -15
    arc_0_17_15  in_degree_881  1
    arc_0_17_15  out_degree_892  1
    arc_0_17_15  original_T_including_depot_unload_933  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_15  arc_capacity_687  1
    load_0_17_15  free_load_conservation_885  -1
    load_0_17_15  free_load_conservation_897  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_16  arc_capacity_689  -20
    arc_0_17_16  connected_order_arc_690  -15
    arc_0_17_16  in_degree_887  1
    arc_0_17_16  out_degree_892  1
    arc_0_17_16  original_T_including_depot_unload_933  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_16  arc_capacity_689  1
    load_0_17_16  free_load_conservation_891  -1
    load_0_17_16  free_load_conservation_897  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_18  arc_capacity_691  -20
    arc_0_17_18  connected_order_arc_692  -15
    arc_0_17_18  out_degree_892  1
    arc_0_17_18  in_degree_899  1
    arc_0_17_18  original_T_including_depot_unload_933  1.6231508478292610e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_18  arc_capacity_691  1
    load_0_17_18  free_load_conservation_897  1
    load_0_17_18  free_load_conservation_903  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_19  arc_capacity_693  -20
    arc_0_17_19  connected_order_arc_694  -15
    arc_0_17_19  out_degree_892  1
    arc_0_17_19  in_degree_905  1
    arc_0_17_19  original_T_including_depot_unload_933  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_19  arc_capacity_693  1
    load_0_17_19  free_load_conservation_897  1
    load_0_17_19  free_load_conservation_909  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_20  arc_capacity_695  -20
    arc_0_17_20  connected_order_arc_696  -15
    arc_0_17_20  out_degree_892  1
    arc_0_17_20  in_degree_911  1
    arc_0_17_20  original_T_including_depot_unload_933  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_20  arc_capacity_695  1
    load_0_17_20  free_load_conservation_897  1
    load_0_17_20  free_load_conservation_915  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_21  arc_capacity_697  -20
    arc_0_17_21  connected_order_arc_698  -15
    arc_0_17_21  out_degree_892  1
    arc_0_17_21  in_degree_917  1
    arc_0_17_21  original_T_including_depot_unload_933  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_21  arc_capacity_697  1
    load_0_17_21  free_load_conservation_897  1
    load_0_17_21  free_load_conservation_921  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_22  arc_capacity_699  -20
    arc_0_17_22  connected_order_arc_700  -15
    arc_0_17_22  out_degree_892  1
    arc_0_17_22  in_degree_923  1
    arc_0_17_22  original_T_including_depot_unload_933  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_22  arc_capacity_699  1
    load_0_17_22  free_load_conservation_897  1
    load_0_17_22  free_load_conservation_927  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_0  arc_capacity_701  -20
    arc_0_18_0  depot_return_or_bypass_837  1
    arc_0_18_0  out_degree_898  1
    arc_0_18_0  original_T_including_depot_unload_933  5.4249700630778887e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_0  arc_capacity_701  1
    load_0_18_0  free_load_conservation_903  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_1  arc_capacity_702  -20
    arc_0_18_1  connected_order_arc_703  -15
    arc_0_18_1  in_degree_839  1
    arc_0_18_1  out_degree_898  1
    arc_0_18_1  original_T_including_depot_unload_933  3.2367117212973966e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_1  arc_capacity_702  1
    load_0_18_1  segment_load_conservation_842  -1
    load_0_18_1  segment_prefix_lb_843  1
    load_0_18_1  segment_prefix_ub_844  1
    load_0_18_1  free_load_conservation_903  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_2  arc_capacity_704  -20
    arc_0_18_2  connected_order_arc_705  -15
    arc_0_18_2  in_degree_846  1
    arc_0_18_2  out_degree_898  1
    arc_0_18_2  original_T_including_depot_unload_933  2.3159636865750136e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_2  arc_capacity_704  1
    load_0_18_2  segment_load_conservation_849  -1
    load_0_18_2  segment_prefix_lb_850  1
    load_0_18_2  segment_prefix_ub_851  1
    load_0_18_2  free_load_conservation_903  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_3  arc_capacity_706  -20
    arc_0_18_3  connected_order_arc_707  -15
    arc_0_18_3  in_degree_853  1
    arc_0_18_3  out_degree_898  1
    arc_0_18_3  original_T_including_depot_unload_933  4.6789193623835109e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_3  arc_capacity_706  1
    load_0_18_3  segment_load_conservation_856  -1
    load_0_18_3  segment_prefix_lb_857  1
    load_0_18_3  segment_prefix_ub_858  1
    load_0_18_3  free_load_conservation_903  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_4  arc_capacity_708  -20
    arc_0_18_4  connected_order_arc_709  -15
    arc_0_18_4  in_degree_860  1
    arc_0_18_4  out_degree_898  1
    arc_0_18_4  original_T_including_depot_unload_933  5.5739415765733247e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_4  arc_capacity_708  1
    load_0_18_4  segment_load_conservation_863  -1
    load_0_18_4  segment_prefix_lb_864  1
    load_0_18_4  segment_prefix_ub_865  1
    load_0_18_4  free_load_conservation_903  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_5  arc_capacity_710  -20
    arc_0_18_5  connected_order_arc_711  -15
    arc_0_18_5  in_degree_867  1
    arc_0_18_5  out_degree_898  1
    arc_0_18_5  original_T_including_depot_unload_933  7.5688558078083690e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_5  arc_capacity_710  1
    load_0_18_5  segment_load_conservation_870  -1
    load_0_18_5  segment_prefix_lb_871  1
    load_0_18_5  segment_prefix_ub_872  1
    load_0_18_5  free_load_conservation_903  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_6  arc_capacity_712  -20
    arc_0_18_6  connected_order_arc_713  -15
    arc_0_18_6  in_degree_874  1
    arc_0_18_6  out_degree_898  1
    arc_0_18_6  original_T_including_depot_unload_933  839.148853987777
    MARKER    'MARKER'                 'INTEND'
    load_0_18_6  arc_capacity_712  1
    load_0_18_6  segment_load_conservation_877  -1
    load_0_18_6  segment_prefix_lb_878  1
    load_0_18_6  segment_prefix_ub_879  1
    load_0_18_6  free_load_conservation_903  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_15  arc_capacity_714  -20
    arc_0_18_15  connected_order_arc_715  -15
    arc_0_18_15  in_degree_881  1
    arc_0_18_15  out_degree_898  1
    arc_0_18_15  original_T_including_depot_unload_933  1.7461252424213140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_15  arc_capacity_714  1
    load_0_18_15  free_load_conservation_885  -1
    load_0_18_15  free_load_conservation_903  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_16  arc_capacity_716  -20
    arc_0_18_16  connected_order_arc_717  -15
    arc_0_18_16  in_degree_887  1
    arc_0_18_16  out_degree_898  1
    arc_0_18_16  original_T_including_depot_unload_933  3.3800157717255917e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_16  arc_capacity_716  1
    load_0_18_16  free_load_conservation_891  -1
    load_0_18_16  free_load_conservation_903  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_17  arc_capacity_718  -20
    arc_0_18_17  connected_order_arc_719  -15
    arc_0_18_17  in_degree_893  1
    arc_0_18_17  out_degree_898  1
    arc_0_18_17  original_T_including_depot_unload_933  1.6231508478292610e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_17  arc_capacity_718  1
    load_0_18_17  free_load_conservation_897  -1
    load_0_18_17  free_load_conservation_903  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_19  arc_capacity_720  -20
    arc_0_18_19  connected_order_arc_721  -15
    arc_0_18_19  out_degree_898  1
    arc_0_18_19  in_degree_905  1
    arc_0_18_19  original_T_including_depot_unload_933  603.649383070884
    MARKER    'MARKER'                 'INTEND'
    load_0_18_19  arc_capacity_720  1
    load_0_18_19  free_load_conservation_903  1
    load_0_18_19  free_load_conservation_909  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_20  arc_capacity_722  -20
    arc_0_18_20  connected_order_arc_723  -15
    arc_0_18_20  out_degree_898  1
    arc_0_18_20  in_degree_911  1
    arc_0_18_20  original_T_including_depot_unload_933  2.8529311190414518e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_20  arc_capacity_722  1
    load_0_18_20  free_load_conservation_903  1
    load_0_18_20  free_load_conservation_915  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_21  arc_capacity_724  -20
    arc_0_18_21  connected_order_arc_725  -15
    arc_0_18_21  out_degree_898  1
    arc_0_18_21  in_degree_917  1
    arc_0_18_21  original_T_including_depot_unload_933  1.0838347754693179e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_21  arc_capacity_724  1
    load_0_18_21  free_load_conservation_903  1
    load_0_18_21  free_load_conservation_921  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_22  arc_capacity_726  -20
    arc_0_18_22  connected_order_arc_727  -15
    arc_0_18_22  out_degree_898  1
    arc_0_18_22  in_degree_923  1
    arc_0_18_22  original_T_including_depot_unload_933  3.4289721135663990e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_22  arc_capacity_726  1
    load_0_18_22  free_load_conservation_903  1
    load_0_18_22  free_load_conservation_927  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_0  arc_capacity_728  -20
    arc_0_19_0  depot_return_or_bypass_837  1
    arc_0_19_0  out_degree_904  1
    arc_0_19_0  original_T_including_depot_unload_933  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_0  arc_capacity_728  1
    load_0_19_0  free_load_conservation_909  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_1  arc_capacity_729  -20
    arc_0_19_1  connected_order_arc_730  -15
    arc_0_19_1  in_degree_839  1
    arc_0_19_1  out_degree_904  1
    arc_0_19_1  original_T_including_depot_unload_933  4.6128219015626763e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_1  arc_capacity_729  1
    load_0_19_1  segment_load_conservation_842  -1
    load_0_19_1  segment_prefix_lb_843  1
    load_0_19_1  segment_prefix_ub_844  1
    load_0_19_1  free_load_conservation_909  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_2  arc_capacity_731  -20
    arc_0_19_2  connected_order_arc_732  -15
    arc_0_19_2  in_degree_846  1
    arc_0_19_2  out_degree_904  1
    arc_0_19_2  original_T_including_depot_unload_933  3.7315439746742123e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_2  arc_capacity_731  1
    load_0_19_2  segment_load_conservation_849  -1
    load_0_19_2  segment_prefix_lb_850  1
    load_0_19_2  segment_prefix_ub_851  1
    load_0_19_2  free_load_conservation_909  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_3  arc_capacity_733  -20
    arc_0_19_3  connected_order_arc_734  -15
    arc_0_19_3  in_degree_853  1
    arc_0_19_3  out_degree_904  1
    arc_0_19_3  original_T_including_depot_unload_933  8.7684829846426385e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_3  arc_capacity_733  1
    load_0_19_3  segment_load_conservation_856  -1
    load_0_19_3  segment_prefix_lb_857  1
    load_0_19_3  segment_prefix_ub_858  1
    load_0_19_3  free_load_conservation_909  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_4  arc_capacity_735  -20
    arc_0_19_4  connected_order_arc_736  -15
    arc_0_19_4  in_degree_860  1
    arc_0_19_4  out_degree_904  1
    arc_0_19_4  original_T_including_depot_unload_933  1.0758099325648966e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_4  arc_capacity_735  1
    load_0_19_4  segment_load_conservation_863  -1
    load_0_19_4  segment_prefix_lb_864  1
    load_0_19_4  segment_prefix_ub_865  1
    load_0_19_4  free_load_conservation_909  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_5  arc_capacity_737  -20
    arc_0_19_5  connected_order_arc_738  -15
    arc_0_19_5  in_degree_867  1
    arc_0_19_5  out_degree_904  1
    arc_0_19_5  original_T_including_depot_unload_933  1.1341050580477483e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_5  arc_capacity_737  1
    load_0_19_5  segment_load_conservation_870  -1
    load_0_19_5  segment_prefix_lb_871  1
    load_0_19_5  segment_prefix_ub_872  1
    load_0_19_5  free_load_conservation_909  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_6  arc_capacity_739  -20
    arc_0_19_6  connected_order_arc_740  -15
    arc_0_19_6  in_degree_874  1
    arc_0_19_6  out_degree_904  1
    arc_0_19_6  original_T_including_depot_unload_933  1.0491196843462671e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_6  arc_capacity_739  1
    load_0_19_6  segment_load_conservation_877  -1
    load_0_19_6  segment_prefix_lb_878  1
    load_0_19_6  segment_prefix_ub_879  1
    load_0_19_6  free_load_conservation_909  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_15  arc_capacity_741  -20
    arc_0_19_15  connected_order_arc_742  -15
    arc_0_19_15  in_degree_881  1
    arc_0_19_15  out_degree_904  1
    arc_0_19_15  original_T_including_depot_unload_933  6.8976718276177132e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_15  arc_capacity_741  1
    load_0_19_15  free_load_conservation_885  -1
    load_0_19_15  free_load_conservation_909  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_16  arc_capacity_743  -20
    arc_0_19_16  connected_order_arc_744  -15
    arc_0_19_16  in_degree_887  1
    arc_0_19_16  out_degree_904  1
    arc_0_19_16  original_T_including_depot_unload_933  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_16  arc_capacity_743  1
    load_0_19_16  free_load_conservation_891  -1
    load_0_19_16  free_load_conservation_909  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_17  arc_capacity_745  -20
    arc_0_19_17  connected_order_arc_746  -15
    arc_0_19_17  in_degree_893  1
    arc_0_19_17  out_degree_904  1
    arc_0_19_17  original_T_including_depot_unload_933  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_17  arc_capacity_745  1
    load_0_19_17  free_load_conservation_897  -1
    load_0_19_17  free_load_conservation_909  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_18  arc_capacity_747  -20
    arc_0_19_18  connected_order_arc_748  -15
    arc_0_19_18  in_degree_899  1
    arc_0_19_18  out_degree_904  1
    arc_0_19_18  original_T_including_depot_unload_933  603.649383070884
    MARKER    'MARKER'                 'INTEND'
    load_0_19_18  arc_capacity_747  1
    load_0_19_18  free_load_conservation_903  -1
    load_0_19_18  free_load_conservation_909  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_20  arc_capacity_749  -20
    arc_0_19_20  connected_order_arc_750  -15
    arc_0_19_20  out_degree_904  1
    arc_0_19_20  in_degree_911  1
    arc_0_19_20  original_T_including_depot_unload_933  4.5128490093732506e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_20  arc_capacity_749  1
    load_0_19_20  free_load_conservation_909  1
    load_0_19_20  free_load_conservation_915  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_21  arc_capacity_751  -20
    arc_0_19_21  connected_order_arc_752  -15
    arc_0_19_21  out_degree_904  1
    arc_0_19_21  in_degree_917  1
    arc_0_19_21  original_T_including_depot_unload_933  1.3127274783157229e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_21  arc_capacity_751  1
    load_0_19_21  free_load_conservation_909  1
    load_0_19_21  free_load_conservation_921  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_22  arc_capacity_753  -20
    arc_0_19_22  connected_order_arc_754  -15
    arc_0_19_22  out_degree_904  1
    arc_0_19_22  in_degree_923  1
    arc_0_19_22  original_T_including_depot_unload_933  9.3962613467893414e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_22  arc_capacity_753  1
    load_0_19_22  free_load_conservation_909  1
    load_0_19_22  free_load_conservation_927  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_0  arc_capacity_755  -20
    arc_0_20_0  depot_return_or_bypass_837  1
    arc_0_20_0  out_degree_910  1
    arc_0_20_0  original_T_including_depot_unload_933  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_0  arc_capacity_755  1
    load_0_20_0  free_load_conservation_915  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_1  arc_capacity_756  -20
    arc_0_20_1  connected_order_arc_757  -15
    arc_0_20_1  in_degree_839  1
    arc_0_20_1  out_degree_910  1
    arc_0_20_1  original_T_including_depot_unload_933  4.4733407106545638e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_1  arc_capacity_756  1
    load_0_20_1  segment_load_conservation_842  -1
    load_0_20_1  segment_prefix_lb_843  1
    load_0_20_1  segment_prefix_ub_844  1
    load_0_20_1  free_load_conservation_915  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_2  arc_capacity_758  -20
    arc_0_20_2  connected_order_arc_759  -15
    arc_0_20_2  in_degree_846  1
    arc_0_20_2  out_degree_910  1
    arc_0_20_2  original_T_including_depot_unload_933  2.2271784981792140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_2  arc_capacity_758  1
    load_0_20_2  segment_load_conservation_849  -1
    load_0_20_2  segment_prefix_lb_850  1
    load_0_20_2  segment_prefix_ub_851  1
    load_0_20_2  free_load_conservation_915  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_3  arc_capacity_760  -20
    arc_0_20_3  connected_order_arc_761  -15
    arc_0_20_3  in_degree_853  1
    arc_0_20_3  out_degree_910  1
    arc_0_20_3  original_T_including_depot_unload_933  4.2733962838090457e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_3  arc_capacity_760  1
    load_0_20_3  segment_load_conservation_856  -1
    load_0_20_3  segment_prefix_lb_857  1
    load_0_20_3  segment_prefix_ub_858  1
    load_0_20_3  free_load_conservation_915  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_4  arc_capacity_762  -20
    arc_0_20_4  connected_order_arc_763  -15
    arc_0_20_4  in_degree_860  1
    arc_0_20_4  out_degree_910  1
    arc_0_20_4  original_T_including_depot_unload_933  628.141943094385
    MARKER    'MARKER'                 'INTEND'
    load_0_20_4  arc_capacity_762  1
    load_0_20_4  segment_load_conservation_863  -1
    load_0_20_4  segment_prefix_lb_864  1
    load_0_20_4  segment_prefix_ub_865  1
    load_0_20_4  free_load_conservation_915  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_5  arc_capacity_764  -20
    arc_0_20_5  connected_order_arc_765  -15
    arc_0_20_5  in_degree_867  1
    arc_0_20_5  out_degree_910  1
    arc_0_20_5  original_T_including_depot_unload_933  6.9736186698570737e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_5  arc_capacity_764  1
    load_0_20_5  segment_load_conservation_870  -1
    load_0_20_5  segment_prefix_lb_871  1
    load_0_20_5  segment_prefix_ub_872  1
    load_0_20_5  free_load_conservation_915  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_6  arc_capacity_766  -20
    arc_0_20_6  connected_order_arc_767  -15
    arc_0_20_6  in_degree_874  1
    arc_0_20_6  out_degree_910  1
    arc_0_20_6  original_T_including_depot_unload_933  6.7517249538835438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_6  arc_capacity_766  1
    load_0_20_6  segment_load_conservation_877  -1
    load_0_20_6  segment_prefix_lb_878  1
    load_0_20_6  segment_prefix_ub_879  1
    load_0_20_6  free_load_conservation_915  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_15  arc_capacity_768  -20
    arc_0_20_15  connected_order_arc_769  -15
    arc_0_20_15  in_degree_881  1
    arc_0_20_15  out_degree_910  1
    arc_0_20_15  original_T_including_depot_unload_933  2.7078292664437623e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_15  arc_capacity_768  1
    load_0_20_15  free_load_conservation_885  -1
    load_0_20_15  free_load_conservation_915  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_16  arc_capacity_770  -20
    arc_0_20_16  connected_order_arc_771  -15
    arc_0_20_16  in_degree_887  1
    arc_0_20_16  out_degree_910  1
    arc_0_20_16  original_T_including_depot_unload_933  3.9758967496529505e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_16  arc_capacity_770  1
    load_0_20_16  free_load_conservation_891  -1
    load_0_20_16  free_load_conservation_915  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_17  arc_capacity_772  -20
    arc_0_20_17  connected_order_arc_773  -15
    arc_0_20_17  in_degree_893  1
    arc_0_20_17  out_degree_910  1
    arc_0_20_17  original_T_including_depot_unload_933  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_17  arc_capacity_772  1
    load_0_20_17  free_load_conservation_897  -1
    load_0_20_17  free_load_conservation_915  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_18  arc_capacity_774  -20
    arc_0_20_18  connected_order_arc_775  -15
    arc_0_20_18  in_degree_899  1
    arc_0_20_18  out_degree_910  1
    arc_0_20_18  original_T_including_depot_unload_933  2.8529311190414518e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_18  arc_capacity_774  1
    load_0_20_18  free_load_conservation_903  -1
    load_0_20_18  free_load_conservation_915  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_19  arc_capacity_776  -20
    arc_0_20_19  connected_order_arc_777  -15
    arc_0_20_19  in_degree_905  1
    arc_0_20_19  out_degree_910  1
    arc_0_20_19  original_T_including_depot_unload_933  4.5128490093732506e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_19  arc_capacity_776  1
    load_0_20_19  free_load_conservation_909  -1
    load_0_20_19  free_load_conservation_915  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_21  arc_capacity_778  -20
    arc_0_20_21  connected_order_arc_779  -15
    arc_0_20_21  out_degree_910  1
    arc_0_20_21  in_degree_917  1
    arc_0_20_21  original_T_including_depot_unload_933  9.3905252655669165e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_21  arc_capacity_778  1
    load_0_20_21  free_load_conservation_915  1
    load_0_20_21  free_load_conservation_921  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_22  arc_capacity_780  -20
    arc_0_20_22  connected_order_arc_781  -15
    arc_0_20_22  out_degree_910  1
    arc_0_20_22  in_degree_923  1
    arc_0_20_22  original_T_including_depot_unload_933  545.439458844012
    MARKER    'MARKER'                 'INTEND'
    load_0_20_22  arc_capacity_780  1
    load_0_20_22  free_load_conservation_915  1
    load_0_20_22  free_load_conservation_927  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_0  arc_capacity_782  -20
    arc_0_21_0  depot_return_or_bypass_837  1
    arc_0_21_0  out_degree_916  1
    arc_0_21_0  original_T_including_depot_unload_933  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_0  arc_capacity_782  1
    load_0_21_0  free_load_conservation_921  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_1  arc_capacity_783  -20
    arc_0_21_1  connected_order_arc_784  -15
    arc_0_21_1  in_degree_839  1
    arc_0_21_1  out_degree_916  1
    arc_0_21_1  original_T_including_depot_unload_933  1.3669225770244122e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_1  arc_capacity_783  1
    load_0_21_1  segment_load_conservation_842  -1
    load_0_21_1  segment_prefix_lb_843  1
    load_0_21_1  segment_prefix_ub_844  1
    load_0_21_1  free_load_conservation_921  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_2  arc_capacity_785  -20
    arc_0_21_2  connected_order_arc_786  -15
    arc_0_21_2  in_degree_846  1
    arc_0_21_2  out_degree_916  1
    arc_0_21_2  original_T_including_depot_unload_933  1.1562172312295786e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_2  arc_capacity_785  1
    load_0_21_2  segment_load_conservation_849  -1
    load_0_21_2  segment_prefix_lb_850  1
    load_0_21_2  segment_prefix_ub_851  1
    load_0_21_2  free_load_conservation_921  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_3  arc_capacity_787  -20
    arc_0_21_3  connected_order_arc_788  -15
    arc_0_21_3  in_degree_853  1
    arc_0_21_3  out_degree_916  1
    arc_0_21_3  original_T_including_depot_unload_933  6.3111682574558915e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_3  arc_capacity_787  1
    load_0_21_3  segment_load_conservation_856  -1
    load_0_21_3  segment_prefix_lb_857  1
    load_0_21_3  segment_prefix_ub_858  1
    load_0_21_3  free_load_conservation_921  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_4  arc_capacity_789  -20
    arc_0_21_4  connected_order_arc_790  -15
    arc_0_21_4  in_degree_860  1
    arc_0_21_4  out_degree_916  1
    arc_0_21_4  original_T_including_depot_unload_933  7.2751050611121218e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_4  arc_capacity_789  1
    load_0_21_4  segment_load_conservation_863  -1
    load_0_21_4  segment_prefix_lb_864  1
    load_0_21_4  segment_prefix_ub_865  1
    load_0_21_4  free_load_conservation_921  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_5  arc_capacity_791  -20
    arc_0_21_5  connected_order_arc_792  -15
    arc_0_21_5  in_degree_867  1
    arc_0_21_5  out_degree_916  1
    arc_0_21_5  original_T_including_depot_unload_933  3.9766425523492148e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_5  arc_capacity_791  1
    load_0_21_5  segment_load_conservation_870  -1
    load_0_21_5  segment_prefix_lb_871  1
    load_0_21_5  segment_prefix_ub_872  1
    load_0_21_5  free_load_conservation_921  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_6  arc_capacity_793  -20
    arc_0_21_6  connected_order_arc_794  -15
    arc_0_21_6  in_degree_874  1
    arc_0_21_6  out_degree_916  1
    arc_0_21_6  original_T_including_depot_unload_933  2.6602972191926557e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_6  arc_capacity_793  1
    load_0_21_6  segment_load_conservation_877  -1
    load_0_21_6  segment_prefix_lb_878  1
    load_0_21_6  segment_prefix_ub_879  1
    load_0_21_6  free_load_conservation_921  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_15  arc_capacity_795  -20
    arc_0_21_15  connected_order_arc_796  -15
    arc_0_21_15  in_degree_881  1
    arc_0_21_15  out_degree_916  1
    arc_0_21_15  original_T_including_depot_unload_933  9.1580557259044724e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_15  arc_capacity_795  1
    load_0_21_15  free_load_conservation_885  -1
    load_0_21_15  free_load_conservation_921  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_16  arc_capacity_797  -20
    arc_0_21_16  connected_order_arc_798  -15
    arc_0_21_16  in_degree_887  1
    arc_0_21_16  out_degree_916  1
    arc_0_21_16  original_T_including_depot_unload_933  7.9403551275216375e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_16  arc_capacity_797  1
    load_0_21_16  free_load_conservation_891  -1
    load_0_21_16  free_load_conservation_921  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_17  arc_capacity_799  -20
    arc_0_21_17  connected_order_arc_800  -15
    arc_0_21_17  in_degree_893  1
    arc_0_21_17  out_degree_916  1
    arc_0_21_17  original_T_including_depot_unload_933  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_17  arc_capacity_799  1
    load_0_21_17  free_load_conservation_897  -1
    load_0_21_17  free_load_conservation_921  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_18  arc_capacity_801  -20
    arc_0_21_18  connected_order_arc_802  -15
    arc_0_21_18  in_degree_899  1
    arc_0_21_18  out_degree_916  1
    arc_0_21_18  original_T_including_depot_unload_933  1.0838347754693179e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_18  arc_capacity_801  1
    load_0_21_18  free_load_conservation_903  -1
    load_0_21_18  free_load_conservation_921  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_19  arc_capacity_803  -20
    arc_0_21_19  connected_order_arc_804  -15
    arc_0_21_19  in_degree_905  1
    arc_0_21_19  out_degree_916  1
    arc_0_21_19  original_T_including_depot_unload_933  1.3127274783157229e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_19  arc_capacity_803  1
    load_0_21_19  free_load_conservation_909  -1
    load_0_21_19  free_load_conservation_921  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_20  arc_capacity_805  -20
    arc_0_21_20  connected_order_arc_806  -15
    arc_0_21_20  in_degree_911  1
    arc_0_21_20  out_degree_916  1
    arc_0_21_20  original_T_including_depot_unload_933  9.3905252655669165e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_20  arc_capacity_805  1
    load_0_21_20  free_load_conservation_915  -1
    load_0_21_20  free_load_conservation_921  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_22  arc_capacity_807  -20
    arc_0_21_22  connected_order_arc_808  -15
    arc_0_21_22  out_degree_916  1
    arc_0_21_22  in_degree_923  1
    arc_0_21_22  original_T_including_depot_unload_933  1.0038065985492663e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_22  arc_capacity_807  1
    load_0_21_22  free_load_conservation_921  1
    load_0_21_22  free_load_conservation_927  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_0  arc_capacity_809  -20
    arc_0_22_0  depot_return_or_bypass_837  1
    arc_0_22_0  out_degree_922  1
    arc_0_22_0  original_T_including_depot_unload_933  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_0  arc_capacity_809  1
    load_0_22_0  free_load_conservation_927  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_1  arc_capacity_810  -20
    arc_0_22_1  connected_order_arc_811  -15
    arc_0_22_1  in_degree_839  1
    arc_0_22_1  out_degree_922  1
    arc_0_22_1  original_T_including_depot_unload_933  6.3648699141452130e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_1  arc_capacity_810  1
    load_0_22_1  segment_load_conservation_842  -1
    load_0_22_1  segment_prefix_lb_843  1
    load_0_22_1  segment_prefix_ub_844  1
    load_0_22_1  free_load_conservation_927  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_2  arc_capacity_812  -20
    arc_0_22_2  connected_order_arc_813  -15
    arc_0_22_2  in_degree_846  1
    arc_0_22_2  out_degree_922  1
    arc_0_22_2  original_T_including_depot_unload_933  5.7237486782756332e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_2  arc_capacity_812  1
    load_0_22_2  segment_load_conservation_849  -1
    load_0_22_2  segment_prefix_lb_850  1
    load_0_22_2  segment_prefix_ub_851  1
    load_0_22_2  free_load_conservation_927  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_3  arc_capacity_814  -20
    arc_0_22_3  connected_order_arc_815  -15
    arc_0_22_3  in_degree_853  1
    arc_0_22_3  out_degree_922  1
    arc_0_22_3  original_T_including_depot_unload_933  3.9864800790786632e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_3  arc_capacity_814  1
    load_0_22_3  segment_load_conservation_856  -1
    load_0_22_3  segment_prefix_lb_857  1
    load_0_22_3  segment_prefix_ub_858  1
    load_0_22_3  free_load_conservation_927  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_4  arc_capacity_816  -20
    arc_0_22_4  connected_order_arc_817  -15
    arc_0_22_4  in_degree_860  1
    arc_0_22_4  out_degree_922  1
    arc_0_22_4  original_T_including_depot_unload_933  3.1069481377857926e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_4  arc_capacity_816  1
    load_0_22_4  segment_load_conservation_863  -1
    load_0_22_4  segment_prefix_lb_864  1
    load_0_22_4  segment_prefix_ub_865  1
    load_0_22_4  free_load_conservation_927  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_5  arc_capacity_818  -20
    arc_0_22_5  connected_order_arc_819  -15
    arc_0_22_5  in_degree_867  1
    arc_0_22_5  out_degree_922  1
    arc_0_22_5  original_T_including_depot_unload_933  6.1561452832791758e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_5  arc_capacity_818  1
    load_0_22_5  segment_load_conservation_870  -1
    load_0_22_5  segment_prefix_lb_871  1
    load_0_22_5  segment_prefix_ub_872  1
    load_0_22_5  free_load_conservation_927  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_6  arc_capacity_820  -20
    arc_0_22_6  connected_order_arc_821  -15
    arc_0_22_6  in_degree_874  1
    arc_0_22_6  out_degree_922  1
    arc_0_22_6  original_T_including_depot_unload_933  8.1289340937717509e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_6  arc_capacity_820  1
    load_0_22_6  segment_load_conservation_877  -1
    load_0_22_6  segment_prefix_lb_878  1
    load_0_22_6  segment_prefix_ub_879  1
    load_0_22_6  free_load_conservation_927  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_15  arc_capacity_822  -20
    arc_0_22_15  connected_order_arc_823  -15
    arc_0_22_15  in_degree_881  1
    arc_0_22_15  out_degree_922  1
    arc_0_22_15  original_T_including_depot_unload_933  2.7570828838654035e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_15  arc_capacity_822  1
    load_0_22_15  free_load_conservation_885  -1
    load_0_22_15  free_load_conservation_927  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_16  arc_capacity_824  -20
    arc_0_22_16  connected_order_arc_825  -15
    arc_0_22_16  in_degree_887  1
    arc_0_22_16  out_degree_922  1
    arc_0_22_16  original_T_including_depot_unload_933  2.4111148152767828e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_16  arc_capacity_824  1
    load_0_22_16  free_load_conservation_891  -1
    load_0_22_16  free_load_conservation_927  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_17  arc_capacity_826  -20
    arc_0_22_17  connected_order_arc_827  -15
    arc_0_22_17  in_degree_893  1
    arc_0_22_17  out_degree_922  1
    arc_0_22_17  original_T_including_depot_unload_933  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_22_17  arc_capacity_826  1
    load_0_22_17  free_load_conservation_897  -1
    load_0_22_17  free_load_conservation_927  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_18  arc_capacity_828  -20
    arc_0_22_18  connected_order_arc_829  -15
    arc_0_22_18  in_degree_899  1
    arc_0_22_18  out_degree_922  1
    arc_0_22_18  original_T_including_depot_unload_933  3.4289721135663990e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_18  arc_capacity_828  1
    load_0_22_18  free_load_conservation_903  -1
    load_0_22_18  free_load_conservation_927  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_19  arc_capacity_830  -20
    arc_0_22_19  connected_order_arc_831  -15
    arc_0_22_19  in_degree_905  1
    arc_0_22_19  out_degree_922  1
    arc_0_22_19  original_T_including_depot_unload_933  9.3962613467893414e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_19  arc_capacity_830  1
    load_0_22_19  free_load_conservation_909  -1
    load_0_22_19  free_load_conservation_927  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_20  arc_capacity_832  -20
    arc_0_22_20  connected_order_arc_833  -15
    arc_0_22_20  in_degree_911  1
    arc_0_22_20  out_degree_922  1
    arc_0_22_20  original_T_including_depot_unload_933  545.439458844012
    MARKER    'MARKER'                 'INTEND'
    load_0_22_20  arc_capacity_832  1
    load_0_22_20  free_load_conservation_915  -1
    load_0_22_20  free_load_conservation_927  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_21  arc_capacity_834  -20
    arc_0_22_21  connected_order_arc_835  -15
    arc_0_22_21  in_degree_917  1
    arc_0_22_21  out_degree_922  1
    arc_0_22_21  original_T_including_depot_unload_933  1.0038065985492663e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_22_21  arc_capacity_834  1
    load_0_22_21  free_load_conservation_921  -1
    load_0_22_21  free_load_conservation_927  1
    visit_1_7  out_degree_1275  -1
    visit_1_7  in_degree_1276  -1
    visit_1_7  order_active_lb_1277  -1
    visit_1_7  order_active_ub_1278  -13
    order_1_7  connected_order_arc_950  -1
    order_1_7  connected_order_arc_952  -1
    order_1_7  connected_order_arc_954  -1
    order_1_7  connected_order_arc_956  -1
    order_1_7  connected_order_arc_958  -1
    order_1_7  connected_order_arc_960  -1
    order_1_7  connected_order_arc_962  -1
    order_1_7  connected_order_arc_964  -1
    order_1_7  connected_order_arc_966  -1
    order_1_7  connected_order_arc_968  -1
    order_1_7  connected_order_arc_970  -1
    order_1_7  connected_order_arc_972  -1
    order_1_7  connected_order_arc_975  1
    order_1_7  connected_order_arc_1000  1
    order_1_7  connected_order_arc_1025  1
    order_1_7  connected_order_arc_1050  1
    order_1_7  connected_order_arc_1075  1
    order_1_7  connected_order_arc_1100  1
    order_1_7  connected_order_arc_1125  1
    order_1_7  connected_order_arc_1150  1
    order_1_7  connected_order_arc_1175  1
    order_1_7  connected_order_arc_1200  1
    order_1_7  connected_order_arc_1225  1
    order_1_7  connected_order_arc_1250  1
    order_1_7  order_active_lb_1277  1
    order_1_7  order_active_ub_1278  1
    order_1_7  fixed_segment_relative_order_1358  -1
    visit_1_8  out_degree_1282  -1
    visit_1_8  in_degree_1283  -1
    visit_1_8  order_active_lb_1284  -1
    visit_1_8  order_active_ub_1285  -13
    order_1_8  connected_order_arc_950  1
    order_1_8  connected_order_arc_975  -1
    order_1_8  connected_order_arc_977  -1
    order_1_8  connected_order_arc_979  -1
    order_1_8  connected_order_arc_981  -1
    order_1_8  connected_order_arc_983  -1
    order_1_8  connected_order_arc_985  -1
    order_1_8  connected_order_arc_987  -1
    order_1_8  connected_order_arc_989  -1
    order_1_8  connected_order_arc_991  -1
    order_1_8  connected_order_arc_993  -1
    order_1_8  connected_order_arc_995  -1
    order_1_8  connected_order_arc_997  -1
    order_1_8  connected_order_arc_1002  1
    order_1_8  connected_order_arc_1027  1
    order_1_8  connected_order_arc_1052  1
    order_1_8  connected_order_arc_1077  1
    order_1_8  connected_order_arc_1102  1
    order_1_8  connected_order_arc_1127  1
    order_1_8  connected_order_arc_1152  1
    order_1_8  connected_order_arc_1177  1
    order_1_8  connected_order_arc_1202  1
    order_1_8  connected_order_arc_1227  1
    order_1_8  connected_order_arc_1252  1
    order_1_8  order_active_lb_1284  1
    order_1_8  order_active_ub_1285  1
    order_1_8  fixed_segment_relative_order_1358  1
    order_1_8  fixed_segment_relative_order_1359  -1
    visit_1_9  out_degree_1289  -1
    visit_1_9  in_degree_1290  -1
    visit_1_9  order_active_lb_1291  -1
    visit_1_9  order_active_ub_1292  -13
    order_1_9  connected_order_arc_952  1
    order_1_9  connected_order_arc_977  1
    order_1_9  connected_order_arc_1000  -1
    order_1_9  connected_order_arc_1002  -1
    order_1_9  connected_order_arc_1004  -1
    order_1_9  connected_order_arc_1006  -1
    order_1_9  connected_order_arc_1008  -1
    order_1_9  connected_order_arc_1010  -1
    order_1_9  connected_order_arc_1012  -1
    order_1_9  connected_order_arc_1014  -1
    order_1_9  connected_order_arc_1016  -1
    order_1_9  connected_order_arc_1018  -1
    order_1_9  connected_order_arc_1020  -1
    order_1_9  connected_order_arc_1022  -1
    order_1_9  connected_order_arc_1029  1
    order_1_9  connected_order_arc_1054  1
    order_1_9  connected_order_arc_1079  1
    order_1_9  connected_order_arc_1104  1
    order_1_9  connected_order_arc_1129  1
    order_1_9  connected_order_arc_1154  1
    order_1_9  connected_order_arc_1179  1
    order_1_9  connected_order_arc_1204  1
    order_1_9  connected_order_arc_1229  1
    order_1_9  connected_order_arc_1254  1
    order_1_9  order_active_lb_1291  1
    order_1_9  order_active_ub_1292  1
    order_1_9  fixed_segment_relative_order_1359  1
    order_1_9  fixed_segment_relative_order_1360  -1
    visit_1_10  out_degree_1296  -1
    visit_1_10  in_degree_1297  -1
    visit_1_10  order_active_lb_1298  -1
    visit_1_10  order_active_ub_1299  -13
    order_1_10  connected_order_arc_954  1
    order_1_10  connected_order_arc_979  1
    order_1_10  connected_order_arc_1004  1
    order_1_10  connected_order_arc_1025  -1
    order_1_10  connected_order_arc_1027  -1
    order_1_10  connected_order_arc_1029  -1
    order_1_10  connected_order_arc_1031  -1
    order_1_10  connected_order_arc_1033  -1
    order_1_10  connected_order_arc_1035  -1
    order_1_10  connected_order_arc_1037  -1
    order_1_10  connected_order_arc_1039  -1
    order_1_10  connected_order_arc_1041  -1
    order_1_10  connected_order_arc_1043  -1
    order_1_10  connected_order_arc_1045  -1
    order_1_10  connected_order_arc_1047  -1
    order_1_10  connected_order_arc_1056  1
    order_1_10  connected_order_arc_1081  1
    order_1_10  connected_order_arc_1106  1
    order_1_10  connected_order_arc_1131  1
    order_1_10  connected_order_arc_1156  1
    order_1_10  connected_order_arc_1181  1
    order_1_10  connected_order_arc_1206  1
    order_1_10  connected_order_arc_1231  1
    order_1_10  connected_order_arc_1256  1
    order_1_10  order_active_lb_1298  1
    order_1_10  order_active_ub_1299  1
    order_1_10  fixed_segment_relative_order_1360  1
    order_1_10  fixed_segment_relative_order_1361  -1
    visit_1_11  out_degree_1303  -1
    visit_1_11  in_degree_1304  -1
    visit_1_11  order_active_lb_1305  -1
    visit_1_11  order_active_ub_1306  -13
    order_1_11  connected_order_arc_956  1
    order_1_11  connected_order_arc_981  1
    order_1_11  connected_order_arc_1006  1
    order_1_11  connected_order_arc_1031  1
    order_1_11  connected_order_arc_1050  -1
    order_1_11  connected_order_arc_1052  -1
    order_1_11  connected_order_arc_1054  -1
    order_1_11  connected_order_arc_1056  -1
    order_1_11  connected_order_arc_1058  -1
    order_1_11  connected_order_arc_1060  -1
    order_1_11  connected_order_arc_1062  -1
    order_1_11  connected_order_arc_1064  -1
    order_1_11  connected_order_arc_1066  -1
    order_1_11  connected_order_arc_1068  -1
    order_1_11  connected_order_arc_1070  -1
    order_1_11  connected_order_arc_1072  -1
    order_1_11  connected_order_arc_1083  1
    order_1_11  connected_order_arc_1108  1
    order_1_11  connected_order_arc_1133  1
    order_1_11  connected_order_arc_1158  1
    order_1_11  connected_order_arc_1183  1
    order_1_11  connected_order_arc_1208  1
    order_1_11  connected_order_arc_1233  1
    order_1_11  connected_order_arc_1258  1
    order_1_11  order_active_lb_1305  1
    order_1_11  order_active_ub_1306  1
    order_1_11  fixed_segment_relative_order_1361  1
    visit_1_15  out_degree_1310  -1
    visit_1_15  in_degree_1311  -1
    visit_1_15  order_active_lb_1312  -1
    visit_1_15  order_active_ub_1313  -13
    visit_1_15  service_visit_def_1314  -1
    order_1_15  connected_order_arc_958  1
    order_1_15  connected_order_arc_983  1
    order_1_15  connected_order_arc_1008  1
    order_1_15  connected_order_arc_1033  1
    order_1_15  connected_order_arc_1058  1
    order_1_15  connected_order_arc_1075  -1
    order_1_15  connected_order_arc_1077  -1
    order_1_15  connected_order_arc_1079  -1
    order_1_15  connected_order_arc_1081  -1
    order_1_15  connected_order_arc_1083  -1
    order_1_15  connected_order_arc_1085  -1
    order_1_15  connected_order_arc_1087  -1
    order_1_15  connected_order_arc_1089  -1
    order_1_15  connected_order_arc_1091  -1
    order_1_15  connected_order_arc_1093  -1
    order_1_15  connected_order_arc_1095  -1
    order_1_15  connected_order_arc_1097  -1
    order_1_15  connected_order_arc_1110  1
    order_1_15  connected_order_arc_1135  1
    order_1_15  connected_order_arc_1160  1
    order_1_15  connected_order_arc_1185  1
    order_1_15  connected_order_arc_1210  1
    order_1_15  connected_order_arc_1235  1
    order_1_15  connected_order_arc_1260  1
    order_1_15  order_active_lb_1312  1
    order_1_15  order_active_ub_1313  1
    visit_1_16  out_degree_1316  -1
    visit_1_16  in_degree_1317  -1
    visit_1_16  order_active_lb_1318  -1
    visit_1_16  order_active_ub_1319  -13
    visit_1_16  service_visit_def_1320  -1
    order_1_16  connected_order_arc_960  1
    order_1_16  connected_order_arc_985  1
    order_1_16  connected_order_arc_1010  1
    order_1_16  connected_order_arc_1035  1
    order_1_16  connected_order_arc_1060  1
    order_1_16  connected_order_arc_1085  1
    order_1_16  connected_order_arc_1100  -1
    order_1_16  connected_order_arc_1102  -1
    order_1_16  connected_order_arc_1104  -1
    order_1_16  connected_order_arc_1106  -1
    order_1_16  connected_order_arc_1108  -1
    order_1_16  connected_order_arc_1110  -1
    order_1_16  connected_order_arc_1112  -1
    order_1_16  connected_order_arc_1114  -1
    order_1_16  connected_order_arc_1116  -1
    order_1_16  connected_order_arc_1118  -1
    order_1_16  connected_order_arc_1120  -1
    order_1_16  connected_order_arc_1122  -1
    order_1_16  connected_order_arc_1137  1
    order_1_16  connected_order_arc_1162  1
    order_1_16  connected_order_arc_1187  1
    order_1_16  connected_order_arc_1212  1
    order_1_16  connected_order_arc_1237  1
    order_1_16  connected_order_arc_1262  1
    order_1_16  order_active_lb_1318  1
    order_1_16  order_active_ub_1319  1
    visit_1_17  out_degree_1322  -1
    visit_1_17  in_degree_1323  -1
    visit_1_17  order_active_lb_1324  -1
    visit_1_17  order_active_ub_1325  -13
    visit_1_17  service_visit_def_1326  -1
    order_1_17  connected_order_arc_962  1
    order_1_17  connected_order_arc_987  1
    order_1_17  connected_order_arc_1012  1
    order_1_17  connected_order_arc_1037  1
    order_1_17  connected_order_arc_1062  1
    order_1_17  connected_order_arc_1087  1
    order_1_17  connected_order_arc_1112  1
    order_1_17  connected_order_arc_1125  -1
    order_1_17  connected_order_arc_1127  -1
    order_1_17  connected_order_arc_1129  -1
    order_1_17  connected_order_arc_1131  -1
    order_1_17  connected_order_arc_1133  -1
    order_1_17  connected_order_arc_1135  -1
    order_1_17  connected_order_arc_1137  -1
    order_1_17  connected_order_arc_1139  -1
    order_1_17  connected_order_arc_1141  -1
    order_1_17  connected_order_arc_1143  -1
    order_1_17  connected_order_arc_1145  -1
    order_1_17  connected_order_arc_1147  -1
    order_1_17  connected_order_arc_1164  1
    order_1_17  connected_order_arc_1189  1
    order_1_17  connected_order_arc_1214  1
    order_1_17  connected_order_arc_1239  1
    order_1_17  connected_order_arc_1264  1
    order_1_17  order_active_lb_1324  1
    order_1_17  order_active_ub_1325  1
    visit_1_18  out_degree_1328  -1
    visit_1_18  in_degree_1329  -1
    visit_1_18  order_active_lb_1330  -1
    visit_1_18  order_active_ub_1331  -13
    visit_1_18  service_visit_def_1332  -1
    order_1_18  connected_order_arc_964  1
    order_1_18  connected_order_arc_989  1
    order_1_18  connected_order_arc_1014  1
    order_1_18  connected_order_arc_1039  1
    order_1_18  connected_order_arc_1064  1
    order_1_18  connected_order_arc_1089  1
    order_1_18  connected_order_arc_1114  1
    order_1_18  connected_order_arc_1139  1
    order_1_18  connected_order_arc_1150  -1
    order_1_18  connected_order_arc_1152  -1
    order_1_18  connected_order_arc_1154  -1
    order_1_18  connected_order_arc_1156  -1
    order_1_18  connected_order_arc_1158  -1
    order_1_18  connected_order_arc_1160  -1
    order_1_18  connected_order_arc_1162  -1
    order_1_18  connected_order_arc_1164  -1
    order_1_18  connected_order_arc_1166  -1
    order_1_18  connected_order_arc_1168  -1
    order_1_18  connected_order_arc_1170  -1
    order_1_18  connected_order_arc_1172  -1
    order_1_18  connected_order_arc_1191  1
    order_1_18  connected_order_arc_1216  1
    order_1_18  connected_order_arc_1241  1
    order_1_18  connected_order_arc_1266  1
    order_1_18  order_active_lb_1330  1
    order_1_18  order_active_ub_1331  1
    visit_1_19  out_degree_1334  -1
    visit_1_19  in_degree_1335  -1
    visit_1_19  order_active_lb_1336  -1
    visit_1_19  order_active_ub_1337  -13
    visit_1_19  service_visit_def_1338  -1
    order_1_19  connected_order_arc_966  1
    order_1_19  connected_order_arc_991  1
    order_1_19  connected_order_arc_1016  1
    order_1_19  connected_order_arc_1041  1
    order_1_19  connected_order_arc_1066  1
    order_1_19  connected_order_arc_1091  1
    order_1_19  connected_order_arc_1116  1
    order_1_19  connected_order_arc_1141  1
    order_1_19  connected_order_arc_1166  1
    order_1_19  connected_order_arc_1175  -1
    order_1_19  connected_order_arc_1177  -1
    order_1_19  connected_order_arc_1179  -1
    order_1_19  connected_order_arc_1181  -1
    order_1_19  connected_order_arc_1183  -1
    order_1_19  connected_order_arc_1185  -1
    order_1_19  connected_order_arc_1187  -1
    order_1_19  connected_order_arc_1189  -1
    order_1_19  connected_order_arc_1191  -1
    order_1_19  connected_order_arc_1193  -1
    order_1_19  connected_order_arc_1195  -1
    order_1_19  connected_order_arc_1197  -1
    order_1_19  connected_order_arc_1218  1
    order_1_19  connected_order_arc_1243  1
    order_1_19  connected_order_arc_1268  1
    order_1_19  order_active_lb_1336  1
    order_1_19  order_active_ub_1337  1
    visit_1_20  out_degree_1340  -1
    visit_1_20  in_degree_1341  -1
    visit_1_20  order_active_lb_1342  -1
    visit_1_20  order_active_ub_1343  -13
    visit_1_20  service_visit_def_1344  -1
    order_1_20  connected_order_arc_968  1
    order_1_20  connected_order_arc_993  1
    order_1_20  connected_order_arc_1018  1
    order_1_20  connected_order_arc_1043  1
    order_1_20  connected_order_arc_1068  1
    order_1_20  connected_order_arc_1093  1
    order_1_20  connected_order_arc_1118  1
    order_1_20  connected_order_arc_1143  1
    order_1_20  connected_order_arc_1168  1
    order_1_20  connected_order_arc_1193  1
    order_1_20  connected_order_arc_1200  -1
    order_1_20  connected_order_arc_1202  -1
    order_1_20  connected_order_arc_1204  -1
    order_1_20  connected_order_arc_1206  -1
    order_1_20  connected_order_arc_1208  -1
    order_1_20  connected_order_arc_1210  -1
    order_1_20  connected_order_arc_1212  -1
    order_1_20  connected_order_arc_1214  -1
    order_1_20  connected_order_arc_1216  -1
    order_1_20  connected_order_arc_1218  -1
    order_1_20  connected_order_arc_1220  -1
    order_1_20  connected_order_arc_1222  -1
    order_1_20  connected_order_arc_1245  1
    order_1_20  connected_order_arc_1270  1
    order_1_20  order_active_lb_1342  1
    order_1_20  order_active_ub_1343  1
    visit_1_21  out_degree_1346  -1
    visit_1_21  in_degree_1347  -1
    visit_1_21  order_active_lb_1348  -1
    visit_1_21  order_active_ub_1349  -13
    visit_1_21  service_visit_def_1350  -1
    order_1_21  connected_order_arc_970  1
    order_1_21  connected_order_arc_995  1
    order_1_21  connected_order_arc_1020  1
    order_1_21  connected_order_arc_1045  1
    order_1_21  connected_order_arc_1070  1
    order_1_21  connected_order_arc_1095  1
    order_1_21  connected_order_arc_1120  1
    order_1_21  connected_order_arc_1145  1
    order_1_21  connected_order_arc_1170  1
    order_1_21  connected_order_arc_1195  1
    order_1_21  connected_order_arc_1220  1
    order_1_21  connected_order_arc_1225  -1
    order_1_21  connected_order_arc_1227  -1
    order_1_21  connected_order_arc_1229  -1
    order_1_21  connected_order_arc_1231  -1
    order_1_21  connected_order_arc_1233  -1
    order_1_21  connected_order_arc_1235  -1
    order_1_21  connected_order_arc_1237  -1
    order_1_21  connected_order_arc_1239  -1
    order_1_21  connected_order_arc_1241  -1
    order_1_21  connected_order_arc_1243  -1
    order_1_21  connected_order_arc_1245  -1
    order_1_21  connected_order_arc_1247  -1
    order_1_21  connected_order_arc_1272  1
    order_1_21  order_active_lb_1348  1
    order_1_21  order_active_ub_1349  1
    visit_1_22  out_degree_1352  -1
    visit_1_22  in_degree_1353  -1
    visit_1_22  order_active_lb_1354  -1
    visit_1_22  order_active_ub_1355  -13
    visit_1_22  service_visit_def_1356  -1
    order_1_22  connected_order_arc_972  1
    order_1_22  connected_order_arc_997  1
    order_1_22  connected_order_arc_1022  1
    order_1_22  connected_order_arc_1047  1
    order_1_22  connected_order_arc_1072  1
    order_1_22  connected_order_arc_1097  1
    order_1_22  connected_order_arc_1122  1
    order_1_22  connected_order_arc_1147  1
    order_1_22  connected_order_arc_1172  1
    order_1_22  connected_order_arc_1197  1
    order_1_22  connected_order_arc_1222  1
    order_1_22  connected_order_arc_1247  1
    order_1_22  connected_order_arc_1250  -1
    order_1_22  connected_order_arc_1252  -1
    order_1_22  connected_order_arc_1254  -1
    order_1_22  connected_order_arc_1256  -1
    order_1_22  connected_order_arc_1258  -1
    order_1_22  connected_order_arc_1260  -1
    order_1_22  connected_order_arc_1262  -1
    order_1_22  connected_order_arc_1264  -1
    order_1_22  connected_order_arc_1266  -1
    order_1_22  connected_order_arc_1268  -1
    order_1_22  connected_order_arc_1270  -1
    order_1_22  connected_order_arc_1272  -1
    order_1_22  order_active_lb_1354  1
    order_1_22  order_active_ub_1355  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_0  arc_capacity_934  -25
    arc_1_0_0  depot_departure_or_bypass_1273  1
    arc_1_0_0  depot_return_or_bypass_1274  1
    MARKER    'MARKER'                 'INTEND'
    load_1_0_0  arc_capacity_934  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_7  arc_capacity_935  -25
    arc_1_0_7  depot_departure_or_bypass_1273  1
    arc_1_0_7  in_degree_1276  1
    arc_1_0_7  original_T_including_depot_unload_1362  8.7749189782983967e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_7  arc_capacity_935  1
    load_1_0_7  segment_load_conservation_1279  -1
    load_1_0_7  segment_prefix_lb_1280  1
    load_1_0_7  segment_prefix_ub_1281  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_8  arc_capacity_936  -25
    arc_1_0_8  depot_departure_or_bypass_1273  1
    arc_1_0_8  in_degree_1283  1
    arc_1_0_8  original_T_including_depot_unload_1362  8.7918533905669346e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_8  arc_capacity_936  1
    load_1_0_8  segment_load_conservation_1286  -1
    load_1_0_8  segment_prefix_lb_1287  1
    load_1_0_8  segment_prefix_ub_1288  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_9  arc_capacity_937  -25
    arc_1_0_9  depot_departure_or_bypass_1273  1
    arc_1_0_9  in_degree_1290  1
    arc_1_0_9  original_T_including_depot_unload_1362  7.8195480223834068e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_9  arc_capacity_937  1
    load_1_0_9  segment_load_conservation_1293  -1
    load_1_0_9  segment_prefix_lb_1294  1
    load_1_0_9  segment_prefix_ub_1295  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_10  arc_capacity_938  -25
    arc_1_0_10  depot_departure_or_bypass_1273  1
    arc_1_0_10  in_degree_1297  1
    arc_1_0_10  original_T_including_depot_unload_1362  4.7522445589173662e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_10  arc_capacity_938  1
    load_1_0_10  segment_load_conservation_1300  -1
    load_1_0_10  segment_prefix_lb_1301  1
    load_1_0_10  segment_prefix_ub_1302  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_11  arc_capacity_939  -25
    arc_1_0_11  depot_departure_or_bypass_1273  1
    arc_1_0_11  in_degree_1304  1
    arc_1_0_11  original_T_including_depot_unload_1362  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_11  arc_capacity_939  1
    load_1_0_11  segment_load_conservation_1307  -1
    load_1_0_11  segment_prefix_lb_1308  1
    load_1_0_11  segment_prefix_ub_1309  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_15  arc_capacity_940  -25
    arc_1_0_15  depot_departure_or_bypass_1273  1
    arc_1_0_15  in_degree_1311  1
    arc_1_0_15  original_T_including_depot_unload_1362  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_15  arc_capacity_940  1
    load_1_0_15  free_load_conservation_1315  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_16  arc_capacity_941  -25
    arc_1_0_16  depot_departure_or_bypass_1273  1
    arc_1_0_16  in_degree_1317  1
    arc_1_0_16  original_T_including_depot_unload_1362  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_16  arc_capacity_941  1
    load_1_0_16  free_load_conservation_1321  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_17  arc_capacity_942  -25
    arc_1_0_17  depot_departure_or_bypass_1273  1
    arc_1_0_17  in_degree_1323  1
    arc_1_0_17  original_T_including_depot_unload_1362  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_17  arc_capacity_942  1
    load_1_0_17  free_load_conservation_1327  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_18  arc_capacity_943  -25
    arc_1_0_18  depot_departure_or_bypass_1273  1
    arc_1_0_18  in_degree_1329  1
    arc_1_0_18  original_T_including_depot_unload_1362  5.4249700630778887e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_18  arc_capacity_943  1
    load_1_0_18  free_load_conservation_1333  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_19  arc_capacity_944  -25
    arc_1_0_19  depot_departure_or_bypass_1273  1
    arc_1_0_19  in_degree_1335  1
    arc_1_0_19  original_T_including_depot_unload_1362  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_19  arc_capacity_944  1
    load_1_0_19  free_load_conservation_1339  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_20  arc_capacity_945  -25
    arc_1_0_20  depot_departure_or_bypass_1273  1
    arc_1_0_20  in_degree_1341  1
    arc_1_0_20  original_T_including_depot_unload_1362  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_20  arc_capacity_945  1
    load_1_0_20  free_load_conservation_1345  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_21  arc_capacity_946  -25
    arc_1_0_21  depot_departure_or_bypass_1273  1
    arc_1_0_21  in_degree_1347  1
    arc_1_0_21  original_T_including_depot_unload_1362  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_21  arc_capacity_946  1
    load_1_0_21  free_load_conservation_1351  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_22  arc_capacity_947  -25
    arc_1_0_22  depot_departure_or_bypass_1273  1
    arc_1_0_22  in_degree_1353  1
    arc_1_0_22  original_T_including_depot_unload_1362  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_22  arc_capacity_947  1
    load_1_0_22  free_load_conservation_1357  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_0  arc_capacity_948  -25
    arc_1_7_0  depot_return_or_bypass_1274  1
    arc_1_7_0  out_degree_1275  1
    arc_1_7_0  original_T_including_depot_unload_1362  1.0479182987243917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_0  arc_capacity_948  1
    load_1_7_0  segment_load_conservation_1279  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_8  arc_capacity_949  -25
    arc_1_7_8  connected_order_arc_950  -14
    arc_1_7_8  out_degree_1275  1
    arc_1_7_8  in_degree_1283  1
    arc_1_7_8  original_T_including_depot_unload_1362  2.4155873404211835e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_8  arc_capacity_949  1
    load_1_7_8  segment_load_conservation_1279  1
    load_1_7_8  segment_load_conservation_1286  -1
    load_1_7_8  segment_prefix_lb_1287  1
    load_1_7_8  segment_prefix_ub_1288  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_9  arc_capacity_951  -25
    arc_1_7_9  connected_order_arc_952  -14
    arc_1_7_9  out_degree_1275  1
    arc_1_7_9  in_degree_1290  1
    arc_1_7_9  original_T_including_depot_unload_1362  9.9524628735690555e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_9  arc_capacity_951  1
    load_1_7_9  segment_load_conservation_1279  1
    load_1_7_9  segment_load_conservation_1293  -1
    load_1_7_9  segment_prefix_lb_1294  1
    load_1_7_9  segment_prefix_ub_1295  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_10  arc_capacity_953  -25
    arc_1_7_10  connected_order_arc_954  -14
    arc_1_7_10  out_degree_1275  1
    arc_1_7_10  in_degree_1297  1
    arc_1_7_10  original_T_including_depot_unload_1362  1.1592640472038677e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_10  arc_capacity_953  1
    load_1_7_10  segment_load_conservation_1279  1
    load_1_7_10  segment_load_conservation_1300  -1
    load_1_7_10  segment_prefix_lb_1301  1
    load_1_7_10  segment_prefix_ub_1302  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_11  arc_capacity_955  -25
    arc_1_7_11  connected_order_arc_956  -14
    arc_1_7_11  out_degree_1275  1
    arc_1_7_11  in_degree_1304  1
    arc_1_7_11  original_T_including_depot_unload_1362  9.2235470209829464e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_11  arc_capacity_955  1
    load_1_7_11  segment_load_conservation_1279  1
    load_1_7_11  segment_load_conservation_1307  -1
    load_1_7_11  segment_prefix_lb_1308  1
    load_1_7_11  segment_prefix_ub_1309  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_15  arc_capacity_957  -25
    arc_1_7_15  connected_order_arc_958  -14
    arc_1_7_15  out_degree_1275  1
    arc_1_7_15  in_degree_1311  1
    arc_1_7_15  original_T_including_depot_unload_1362  1.4829753176244692e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_15  arc_capacity_957  1
    load_1_7_15  segment_load_conservation_1279  1
    load_1_7_15  free_load_conservation_1315  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_16  arc_capacity_959  -25
    arc_1_7_16  connected_order_arc_960  -14
    arc_1_7_16  out_degree_1275  1
    arc_1_7_16  in_degree_1317  1
    arc_1_7_16  original_T_including_depot_unload_1362  1.5393904884690303e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_16  arc_capacity_959  1
    load_1_7_16  segment_load_conservation_1279  1
    load_1_7_16  free_load_conservation_1321  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_17  arc_capacity_961  -25
    arc_1_7_17  connected_order_arc_962  -14
    arc_1_7_17  out_degree_1275  1
    arc_1_7_17  in_degree_1323  1
    arc_1_7_17  original_T_including_depot_unload_1362  5.2280951376932137e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_17  arc_capacity_961  1
    load_1_7_17  segment_load_conservation_1279  1
    load_1_7_17  free_load_conservation_1327  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_18  arc_capacity_963  -25
    arc_1_7_18  connected_order_arc_964  -14
    arc_1_7_18  out_degree_1275  1
    arc_1_7_18  in_degree_1329  1
    arc_1_7_18  original_T_including_depot_unload_1362  1.5145600125783847e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_18  arc_capacity_963  1
    load_1_7_18  segment_load_conservation_1279  1
    load_1_7_18  free_load_conservation_1333  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_19  arc_capacity_965  -25
    arc_1_7_19  connected_order_arc_966  -14
    arc_1_7_19  out_degree_1275  1
    arc_1_7_19  in_degree_1335  1
    arc_1_7_19  original_T_including_depot_unload_1362  1.0880068546845516e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_19  arc_capacity_965  1
    load_1_7_19  segment_load_conservation_1279  1
    load_1_7_19  free_load_conservation_1339  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_20  arc_capacity_967  -25
    arc_1_7_20  connected_order_arc_968  -14
    arc_1_7_20  out_degree_1275  1
    arc_1_7_20  in_degree_1341  1
    arc_1_7_20  original_T_including_depot_unload_1362  1.2336637947519732e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_20  arc_capacity_967  1
    load_1_7_20  segment_load_conservation_1279  1
    load_1_7_20  free_load_conservation_1345  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_21  arc_capacity_969  -25
    arc_1_7_21  connected_order_arc_970  -14
    arc_1_7_21  out_degree_1275  1
    arc_1_7_21  in_degree_1347  1
    arc_1_7_21  original_T_including_depot_unload_1362  1.3852878731513219e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_21  arc_capacity_969  1
    load_1_7_21  segment_load_conservation_1279  1
    load_1_7_21  free_load_conservation_1351  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_22  arc_capacity_971  -25
    arc_1_7_22  connected_order_arc_972  -14
    arc_1_7_22  out_degree_1275  1
    arc_1_7_22  in_degree_1353  1
    arc_1_7_22  original_T_including_depot_unload_1362  1.7520337176349503e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_22  arc_capacity_971  1
    load_1_7_22  segment_load_conservation_1279  1
    load_1_7_22  free_load_conservation_1357  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_0  arc_capacity_973  -25
    arc_1_8_0  depot_return_or_bypass_1274  1
    arc_1_8_0  out_degree_1282  1
    arc_1_8_0  original_T_including_depot_unload_1362  887.312716328479
    MARKER    'MARKER'                 'INTEND'
    load_1_8_0  arc_capacity_973  1
    load_1_8_0  segment_load_conservation_1286  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_7  arc_capacity_974  -25
    arc_1_8_7  connected_order_arc_975  -14
    arc_1_8_7  in_degree_1276  1
    arc_1_8_7  out_degree_1282  1
    arc_1_8_7  original_T_including_depot_unload_1362  7.8136221151890174e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_7  arc_capacity_974  1
    load_1_8_7  segment_load_conservation_1279  -1
    load_1_8_7  segment_prefix_lb_1280  1
    load_1_8_7  segment_prefix_ub_1281  1
    load_1_8_7  segment_load_conservation_1286  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_9  arc_capacity_976  -25
    arc_1_8_9  connected_order_arc_977  -14
    arc_1_8_9  out_degree_1282  1
    arc_1_8_9  in_degree_1290  1
    arc_1_8_9  original_T_including_depot_unload_1362  1.1119949880978965e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_9  arc_capacity_976  1
    load_1_8_9  segment_load_conservation_1286  1
    load_1_8_9  segment_load_conservation_1293  -1
    load_1_8_9  segment_prefix_lb_1294  1
    load_1_8_9  segment_prefix_ub_1295  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_10  arc_capacity_978  -25
    arc_1_8_10  connected_order_arc_979  -14
    arc_1_8_10  out_degree_1282  1
    arc_1_8_10  in_degree_1297  1
    arc_1_8_10  original_T_including_depot_unload_1362  4.9711893625650669e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_10  arc_capacity_978  1
    load_1_8_10  segment_load_conservation_1286  1
    load_1_8_10  segment_load_conservation_1300  -1
    load_1_8_10  segment_prefix_lb_1301  1
    load_1_8_10  segment_prefix_ub_1302  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_11  arc_capacity_980  -25
    arc_1_8_11  connected_order_arc_981  -14
    arc_1_8_11  out_degree_1282  1
    arc_1_8_11  in_degree_1304  1
    arc_1_8_11  original_T_including_depot_unload_1362  8.4332546654485930e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_11  arc_capacity_980  1
    load_1_8_11  segment_load_conservation_1286  1
    load_1_8_11  segment_load_conservation_1307  -1
    load_1_8_11  segment_prefix_lb_1308  1
    load_1_8_11  segment_prefix_ub_1309  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_15  arc_capacity_982  -25
    arc_1_8_15  connected_order_arc_983  -14
    arc_1_8_15  out_degree_1282  1
    arc_1_8_15  in_degree_1311  1
    arc_1_8_15  original_T_including_depot_unload_1362  1.0213043329444467e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_15  arc_capacity_982  1
    load_1_8_15  segment_load_conservation_1286  1
    load_1_8_15  free_load_conservation_1315  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_16  arc_capacity_984  -25
    arc_1_8_16  connected_order_arc_985  -14
    arc_1_8_16  out_degree_1282  1
    arc_1_8_16  in_degree_1317  1
    arc_1_8_16  original_T_including_depot_unload_1362  1.1750055851715294e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_16  arc_capacity_984  1
    load_1_8_16  segment_load_conservation_1286  1
    load_1_8_16  free_load_conservation_1321  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_17  arc_capacity_986  -25
    arc_1_8_17  connected_order_arc_987  -14
    arc_1_8_17  out_degree_1282  1
    arc_1_8_17  in_degree_1323  1
    arc_1_8_17  original_T_including_depot_unload_1362  1.4573788798892317e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_17  arc_capacity_986  1
    load_1_8_17  segment_load_conservation_1286  1
    load_1_8_17  free_load_conservation_1327  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_18  arc_capacity_988  -25
    arc_1_8_18  connected_order_arc_989  -14
    arc_1_8_18  out_degree_1282  1
    arc_1_8_18  in_degree_1329  1
    arc_1_8_18  original_T_including_depot_unload_1362  9.2153450304618127e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_18  arc_capacity_988  1
    load_1_8_18  segment_load_conservation_1286  1
    load_1_8_18  free_load_conservation_1333  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_19  arc_capacity_990  -25
    arc_1_8_19  connected_order_arc_991  -14
    arc_1_8_19  out_degree_1282  1
    arc_1_8_19  in_degree_1335  1
    arc_1_8_19  original_T_including_depot_unload_1362  3.3422575089633142e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_19  arc_capacity_990  1
    load_1_8_19  segment_load_conservation_1286  1
    load_1_8_19  free_load_conservation_1339  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_20  arc_capacity_992  -25
    arc_1_8_20  connected_order_arc_993  -14
    arc_1_8_20  out_degree_1282  1
    arc_1_8_20  in_degree_1341  1
    arc_1_8_20  original_T_including_depot_unload_1362  7.8495921746600118e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_20  arc_capacity_992  1
    load_1_8_20  segment_load_conservation_1286  1
    load_1_8_20  free_load_conservation_1345  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_21  arc_capacity_994  -25
    arc_1_8_21  connected_order_arc_995  -14
    arc_1_8_21  out_degree_1282  1
    arc_1_8_21  in_degree_1347  1
    arc_1_8_21  original_T_including_depot_unload_1362  1.6048175645110312e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_21  arc_capacity_994  1
    load_1_8_21  segment_load_conservation_1286  1
    load_1_8_21  free_load_conservation_1351  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_22  arc_capacity_996  -25
    arc_1_8_22  connected_order_arc_997  -14
    arc_1_8_22  out_degree_1282  1
    arc_1_8_22  in_degree_1353  1
    arc_1_8_22  original_T_including_depot_unload_1362  1.2628291878233333e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_22  arc_capacity_996  1
    load_1_8_22  segment_load_conservation_1286  1
    load_1_8_22  free_load_conservation_1357  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_0  arc_capacity_998  -25
    arc_1_9_0  depot_return_or_bypass_1274  1
    arc_1_9_0  out_degree_1289  1
    arc_1_9_0  original_T_including_depot_unload_1362  7.8195480223834068e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_0  arc_capacity_998  1
    load_1_9_0  segment_load_conservation_1293  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_7  arc_capacity_999  -25
    arc_1_9_7  connected_order_arc_1000  -14
    arc_1_9_7  in_degree_1276  1
    arc_1_9_7  out_degree_1289  1
    arc_1_9_7  original_T_including_depot_unload_1362  7.0804311489116617e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_7  arc_capacity_999  1
    load_1_9_7  segment_load_conservation_1279  -1
    load_1_9_7  segment_prefix_lb_1280  1
    load_1_9_7  segment_prefix_ub_1281  1
    load_1_9_7  segment_load_conservation_1293  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_8  arc_capacity_1001  -25
    arc_1_9_8  connected_order_arc_1002  -14
    arc_1_9_8  in_degree_1283  1
    arc_1_9_8  out_degree_1289  1
    arc_1_9_8  original_T_including_depot_unload_1362  1.0062397105603651e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_8  arc_capacity_1001  1
    load_1_9_8  segment_load_conservation_1286  -1
    load_1_9_8  segment_prefix_lb_1287  1
    load_1_9_8  segment_prefix_ub_1288  1
    load_1_9_8  segment_load_conservation_1293  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_10  arc_capacity_1003  -25
    arc_1_9_10  connected_order_arc_1004  -14
    arc_1_9_10  out_degree_1289  1
    arc_1_9_10  in_degree_1297  1
    arc_1_9_10  original_T_including_depot_unload_1362  4.1964259385165178e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_10  arc_capacity_1003  1
    load_1_9_10  segment_load_conservation_1293  1
    load_1_9_10  segment_load_conservation_1300  -1
    load_1_9_10  segment_prefix_lb_1301  1
    load_1_9_10  segment_prefix_ub_1302  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_11  arc_capacity_1005  -25
    arc_1_9_11  connected_order_arc_1006  -14
    arc_1_9_11  out_degree_1289  1
    arc_1_9_11  in_degree_1304  1
    arc_1_9_11  original_T_including_depot_unload_1362  7.3394466063263269e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_11  arc_capacity_1005  1
    load_1_9_11  segment_load_conservation_1293  1
    load_1_9_11  segment_load_conservation_1307  -1
    load_1_9_11  segment_prefix_lb_1308  1
    load_1_9_11  segment_prefix_ub_1309  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_15  arc_capacity_1007  -25
    arc_1_9_15  connected_order_arc_1008  -14
    arc_1_9_15  out_degree_1289  1
    arc_1_9_15  in_degree_1311  1
    arc_1_9_15  original_T_including_depot_unload_1362  9.4424191477021122e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_15  arc_capacity_1007  1
    load_1_9_15  segment_load_conservation_1293  1
    load_1_9_15  free_load_conservation_1315  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_16  arc_capacity_1009  -25
    arc_1_9_16  connected_order_arc_1010  -14
    arc_1_9_16  out_degree_1289  1
    arc_1_9_16  in_degree_1317  1
    arc_1_9_16  original_T_including_depot_unload_1362  1.0921272639748563e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_16  arc_capacity_1009  1
    load_1_9_16  segment_load_conservation_1293  1
    load_1_9_16  free_load_conservation_1321  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_17  arc_capacity_1011  -25
    arc_1_9_17  connected_order_arc_1012  -14
    arc_1_9_17  out_degree_1289  1
    arc_1_9_17  in_degree_1323  1
    arc_1_9_17  original_T_including_depot_unload_1362  1.3626829404511475e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_17  arc_capacity_1011  1
    load_1_9_17  segment_load_conservation_1293  1
    load_1_9_17  free_load_conservation_1327  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_18  arc_capacity_1013  -25
    arc_1_9_18  connected_order_arc_1014  -14
    arc_1_9_18  out_degree_1289  1
    arc_1_9_18  in_degree_1329  1
    arc_1_9_18  original_T_including_depot_unload_1362  8.5807018379884664e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_18  arc_capacity_1013  1
    load_1_9_18  segment_load_conservation_1293  1
    load_1_9_18  free_load_conservation_1333  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_19  arc_capacity_1015  -25
    arc_1_9_19  connected_order_arc_1016  -14
    arc_1_9_19  out_degree_1289  1
    arc_1_9_19  in_degree_1335  1
    arc_1_9_19  original_T_including_depot_unload_1362  2.5572087458878266e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_19  arc_capacity_1015  1
    load_1_9_19  segment_load_conservation_1293  1
    load_1_9_19  free_load_conservation_1339  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_20  arc_capacity_1017  -25
    arc_1_9_20  connected_order_arc_1018  -14
    arc_1_9_20  out_degree_1289  1
    arc_1_9_20  in_degree_1341  1
    arc_1_9_20  original_T_including_depot_unload_1362  6.9726539003798837e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_20  arc_capacity_1017  1
    load_1_9_20  segment_load_conservation_1293  1
    load_1_9_20  free_load_conservation_1345  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_21  arc_capacity_1019  -25
    arc_1_9_21  connected_order_arc_1020  -14
    arc_1_9_21  out_degree_1289  1
    arc_1_9_21  in_degree_1347  1
    arc_1_9_21  original_T_including_depot_unload_1362  1.4961553163922974e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_21  arc_capacity_1019  1
    load_1_9_21  segment_load_conservation_1293  1
    load_1_9_21  free_load_conservation_1351  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_22  arc_capacity_1021  -25
    arc_1_9_22  connected_order_arc_1022  -14
    arc_1_9_22  out_degree_1289  1
    arc_1_9_22  in_degree_1353  1
    arc_1_9_22  original_T_including_depot_unload_1362  1.1952607376785465e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_22  arc_capacity_1021  1
    load_1_9_22  segment_load_conservation_1293  1
    load_1_9_22  free_load_conservation_1357  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_0  arc_capacity_1023  -25
    arc_1_10_0  depot_return_or_bypass_1274  1
    arc_1_10_0  out_degree_1296  1
    arc_1_10_0  original_T_including_depot_unload_1362  4.7522445589173662e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_0  arc_capacity_1023  1
    load_1_10_0  segment_load_conservation_1300  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_7  arc_capacity_1024  -25
    arc_1_10_7  connected_order_arc_1025  -14
    arc_1_10_7  in_degree_1276  1
    arc_1_10_7  out_degree_1296  1
    arc_1_10_7  original_T_including_depot_unload_1362  9.0121368945211725e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_7  arc_capacity_1024  1
    load_1_10_7  segment_load_conservation_1279  -1
    load_1_10_7  segment_prefix_lb_1280  1
    load_1_10_7  segment_prefix_ub_1281  1
    load_1_10_7  segment_load_conservation_1300  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_8  arc_capacity_1026  -25
    arc_1_10_8  connected_order_arc_1027  -14
    arc_1_10_8  in_degree_1283  1
    arc_1_10_8  out_degree_1296  1
    arc_1_10_8  original_T_including_depot_unload_1362  1.0793944823036150e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_8  arc_capacity_1026  1
    load_1_10_8  segment_load_conservation_1286  -1
    load_1_10_8  segment_prefix_lb_1287  1
    load_1_10_8  segment_prefix_ub_1288  1
    load_1_10_8  segment_load_conservation_1300  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_9  arc_capacity_1028  -25
    arc_1_10_9  connected_order_arc_1029  -14
    arc_1_10_9  in_degree_1290  1
    arc_1_10_9  out_degree_1296  1
    arc_1_10_9  original_T_including_depot_unload_1362  4.1964259385165178e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_9  arc_capacity_1028  1
    load_1_10_9  segment_load_conservation_1293  -1
    load_1_10_9  segment_prefix_lb_1294  1
    load_1_10_9  segment_prefix_ub_1295  1
    load_1_10_9  segment_load_conservation_1300  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_11  arc_capacity_1030  -25
    arc_1_10_11  connected_order_arc_1031  -14
    arc_1_10_11  out_degree_1296  1
    arc_1_10_11  in_degree_1304  1
    arc_1_10_11  original_T_including_depot_unload_1362  4.9232225330062903e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_11  arc_capacity_1030  1
    load_1_10_11  segment_load_conservation_1300  1
    load_1_10_11  segment_load_conservation_1307  -1
    load_1_10_11  segment_prefix_lb_1308  1
    load_1_10_11  segment_prefix_ub_1309  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_15  arc_capacity_1032  -25
    arc_1_10_15  connected_order_arc_1033  -14
    arc_1_10_15  out_degree_1296  1
    arc_1_10_15  in_degree_1311  1
    arc_1_10_15  original_T_including_depot_unload_1362  5.2534086948364859e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_15  arc_capacity_1032  1
    load_1_10_15  segment_load_conservation_1300  1
    load_1_10_15  free_load_conservation_1315  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_16  arc_capacity_1034  -25
    arc_1_10_16  connected_order_arc_1035  -14
    arc_1_10_16  out_degree_1296  1
    arc_1_10_16  in_degree_1317  1
    arc_1_10_16  original_T_including_depot_unload_1362  6.7803521648175558e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_16  arc_capacity_1034  1
    load_1_10_16  segment_load_conservation_1300  1
    load_1_10_16  free_load_conservation_1321  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_17  arc_capacity_1036  -25
    arc_1_10_17  connected_order_arc_1037  -14
    arc_1_10_17  out_degree_1296  1
    arc_1_10_17  in_degree_1323  1
    arc_1_10_17  original_T_including_depot_unload_1362  1.3823927712314810e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_17  arc_capacity_1036  1
    load_1_10_17  segment_load_conservation_1300  1
    load_1_10_17  free_load_conservation_1327  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_18  arc_capacity_1038  -25
    arc_1_10_18  connected_order_arc_1039  -14
    arc_1_10_18  out_degree_1296  1
    arc_1_10_18  in_degree_1329  1
    arc_1_10_18  original_T_including_depot_unload_1362  4.4474809771996007e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_18  arc_capacity_1038  1
    load_1_10_18  segment_load_conservation_1300  1
    load_1_10_18  free_load_conservation_1333  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_19  arc_capacity_1040  -25
    arc_1_10_19  connected_order_arc_1041  -14
    arc_1_10_19  out_degree_1296  1
    arc_1_10_19  in_degree_1335  1
    arc_1_10_19  original_T_including_depot_unload_1362  1.6444540482789353e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_19  arc_capacity_1040  1
    load_1_10_19  segment_load_conservation_1300  1
    load_1_10_19  free_load_conservation_1339  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_20  arc_capacity_1042  -25
    arc_1_10_20  connected_order_arc_1043  -14
    arc_1_10_20  out_degree_1296  1
    arc_1_10_20  in_degree_1341  1
    arc_1_10_20  original_T_including_depot_unload_1362  2.9438424317501273e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_20  arc_capacity_1042  1
    load_1_10_20  segment_load_conservation_1300  1
    load_1_10_20  free_load_conservation_1345  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_21  arc_capacity_1044  -25
    arc_1_10_21  connected_order_arc_1045  -14
    arc_1_10_21  out_degree_1296  1
    arc_1_10_21  in_degree_1347  1
    arc_1_10_21  original_T_including_depot_unload_1362  1.1957430085580884e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_21  arc_capacity_1044  1
    load_1_10_21  segment_load_conservation_1300  1
    load_1_10_21  free_load_conservation_1351  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_22  arc_capacity_1046  -25
    arc_1_10_22  connected_order_arc_1047  -14
    arc_1_10_22  out_degree_1296  1
    arc_1_10_22  in_degree_1353  1
    arc_1_10_22  original_T_including_depot_unload_1362  7.7690262287132452e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_22  arc_capacity_1046  1
    load_1_10_22  segment_load_conservation_1300  1
    load_1_10_22  free_load_conservation_1357  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_0  arc_capacity_1048  -25
    arc_1_11_0  depot_return_or_bypass_1274  1
    arc_1_11_0  out_degree_1303  1
    arc_1_11_0  original_T_including_depot_unload_1362  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_0  arc_capacity_1048  1
    load_1_11_0  segment_load_conservation_1307  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_7  arc_capacity_1049  -25
    arc_1_11_7  connected_order_arc_1050  -14
    arc_1_11_7  in_degree_1276  1
    arc_1_11_7  out_degree_1303  1
    arc_1_11_7  original_T_including_depot_unload_1362  7.5571464781430223e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_7  arc_capacity_1049  1
    load_1_11_7  segment_load_conservation_1279  -1
    load_1_11_7  segment_prefix_lb_1280  1
    load_1_11_7  segment_prefix_ub_1281  1
    load_1_11_7  segment_load_conservation_1307  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_8  arc_capacity_1051  -25
    arc_1_11_8  connected_order_arc_1052  -14
    arc_1_11_8  in_degree_1283  1
    arc_1_11_8  out_degree_1303  1
    arc_1_11_8  original_T_including_depot_unload_1362  7.5634788469878674e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_8  arc_capacity_1051  1
    load_1_11_8  segment_load_conservation_1286  -1
    load_1_11_8  segment_prefix_lb_1287  1
    load_1_11_8  segment_prefix_ub_1288  1
    load_1_11_8  segment_load_conservation_1307  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_9  arc_capacity_1053  -25
    arc_1_11_9  connected_order_arc_1054  -14
    arc_1_11_9  in_degree_1290  1
    arc_1_11_9  out_degree_1303  1
    arc_1_11_9  original_T_including_depot_unload_1362  7.3394466063263269e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_9  arc_capacity_1053  1
    load_1_11_9  segment_load_conservation_1293  -1
    load_1_11_9  segment_prefix_lb_1294  1
    load_1_11_9  segment_prefix_ub_1295  1
    load_1_11_9  segment_load_conservation_1307  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_10  arc_capacity_1055  -25
    arc_1_11_10  connected_order_arc_1056  -14
    arc_1_11_10  in_degree_1297  1
    arc_1_11_10  out_degree_1303  1
    arc_1_11_10  original_T_including_depot_unload_1362  4.9232225330062903e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_10  arc_capacity_1055  1
    load_1_11_10  segment_load_conservation_1300  -1
    load_1_11_10  segment_prefix_lb_1301  1
    load_1_11_10  segment_prefix_ub_1302  1
    load_1_11_10  segment_load_conservation_1307  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_15  arc_capacity_1057  -25
    arc_1_11_15  connected_order_arc_1058  -14
    arc_1_11_15  out_degree_1303  1
    arc_1_11_15  in_degree_1311  1
    arc_1_11_15  original_T_including_depot_unload_1362  5.7354473845222140e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_15  arc_capacity_1057  1
    load_1_11_15  segment_load_conservation_1307  1
    load_1_11_15  free_load_conservation_1315  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_16  arc_capacity_1059  -25
    arc_1_11_16  connected_order_arc_1060  -14
    arc_1_11_16  out_degree_1303  1
    arc_1_11_16  in_degree_1317  1
    arc_1_11_16  original_T_including_depot_unload_1362  6.1704611580490348e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_16  arc_capacity_1059  1
    load_1_11_16  segment_load_conservation_1307  1
    load_1_11_16  free_load_conservation_1321  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_17  arc_capacity_1061  -25
    arc_1_11_17  connected_order_arc_1062  -14
    arc_1_11_17  out_degree_1303  1
    arc_1_11_17  in_degree_1323  1
    arc_1_11_17  original_T_including_depot_unload_1362  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_17  arc_capacity_1061  1
    load_1_11_17  segment_load_conservation_1307  1
    load_1_11_17  free_load_conservation_1327  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_18  arc_capacity_1063  -25
    arc_1_11_18  connected_order_arc_1064  -14
    arc_1_11_18  out_degree_1303  1
    arc_1_11_18  in_degree_1329  1
    arc_1_11_18  original_T_including_depot_unload_1362  6.4572843340219208e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_18  arc_capacity_1063  1
    load_1_11_18  segment_load_conservation_1307  1
    load_1_11_18  free_load_conservation_1333  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_19  arc_capacity_1065  -25
    arc_1_11_19  connected_order_arc_1066  -14
    arc_1_11_19  out_degree_1303  1
    arc_1_11_19  in_degree_1335  1
    arc_1_11_19  original_T_including_depot_unload_1362  5.7102904773674652e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_19  arc_capacity_1065  1
    load_1_11_19  segment_load_conservation_1307  1
    load_1_11_19  free_load_conservation_1339  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_20  arc_capacity_1067  -25
    arc_1_11_20  connected_order_arc_1068  -14
    arc_1_11_20  out_degree_1303  1
    arc_1_11_20  in_degree_1341  1
    arc_1_11_20  original_T_including_depot_unload_1362  3.6658228437834981e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_20  arc_capacity_1067  1
    load_1_11_20  segment_load_conservation_1307  1
    load_1_11_20  free_load_conservation_1345  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_21  arc_capacity_1069  -25
    arc_1_11_21  connected_order_arc_1070  -14
    arc_1_11_21  out_degree_1303  1
    arc_1_11_21  in_degree_1347  1
    arc_1_11_21  original_T_including_depot_unload_1362  7.6275540057842773e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_21  arc_capacity_1069  1
    load_1_11_21  segment_load_conservation_1307  1
    load_1_11_21  free_load_conservation_1351  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_22  arc_capacity_1071  -25
    arc_1_11_22  connected_order_arc_1072  -14
    arc_1_11_22  out_degree_1303  1
    arc_1_11_22  in_degree_1353  1
    arc_1_11_22  original_T_including_depot_unload_1362  8.3393751072629220e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_22  arc_capacity_1071  1
    load_1_11_22  segment_load_conservation_1307  1
    load_1_11_22  free_load_conservation_1357  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_0  arc_capacity_1073  -25
    arc_1_15_0  depot_return_or_bypass_1274  1
    arc_1_15_0  out_degree_1310  1
    arc_1_15_0  original_T_including_depot_unload_1362  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_0  arc_capacity_1073  1
    load_1_15_0  free_load_conservation_1315  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_7  arc_capacity_1074  -25
    arc_1_15_7  connected_order_arc_1075  -14
    arc_1_15_7  in_degree_1276  1
    arc_1_15_7  out_degree_1310  1
    arc_1_15_7  original_T_including_depot_unload_1362  1.2798962893775918e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_7  arc_capacity_1074  1
    load_1_15_7  segment_load_conservation_1279  -1
    load_1_15_7  segment_prefix_lb_1280  1
    load_1_15_7  segment_prefix_ub_1281  1
    load_1_15_7  free_load_conservation_1315  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_8  arc_capacity_1076  -25
    arc_1_15_8  connected_order_arc_1077  -14
    arc_1_15_8  in_degree_1283  1
    arc_1_15_8  out_degree_1310  1
    arc_1_15_8  original_T_including_depot_unload_1362  1.3293032990949939e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_8  arc_capacity_1076  1
    load_1_15_8  segment_load_conservation_1286  -1
    load_1_15_8  segment_prefix_lb_1287  1
    load_1_15_8  segment_prefix_ub_1288  1
    load_1_15_8  free_load_conservation_1315  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_9  arc_capacity_1078  -25
    arc_1_15_9  connected_order_arc_1079  -14
    arc_1_15_9  in_degree_1290  1
    arc_1_15_9  out_degree_1310  1
    arc_1_15_9  original_T_including_depot_unload_1362  9.4424191477021122e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_9  arc_capacity_1078  1
    load_1_15_9  segment_load_conservation_1293  -1
    load_1_15_9  segment_prefix_lb_1294  1
    load_1_15_9  segment_prefix_ub_1295  1
    load_1_15_9  free_load_conservation_1315  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_10  arc_capacity_1080  -25
    arc_1_15_10  connected_order_arc_1081  -14
    arc_1_15_10  in_degree_1297  1
    arc_1_15_10  out_degree_1310  1
    arc_1_15_10  original_T_including_depot_unload_1362  5.2534086948364859e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_10  arc_capacity_1080  1
    load_1_15_10  segment_load_conservation_1300  -1
    load_1_15_10  segment_prefix_lb_1301  1
    load_1_15_10  segment_prefix_ub_1302  1
    load_1_15_10  free_load_conservation_1315  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_11  arc_capacity_1082  -25
    arc_1_15_11  connected_order_arc_1083  -14
    arc_1_15_11  in_degree_1304  1
    arc_1_15_11  out_degree_1310  1
    arc_1_15_11  original_T_including_depot_unload_1362  5.7354473845222140e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_11  arc_capacity_1082  1
    load_1_15_11  segment_load_conservation_1307  -1
    load_1_15_11  segment_prefix_lb_1308  1
    load_1_15_11  segment_prefix_ub_1309  1
    load_1_15_11  free_load_conservation_1315  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_16  arc_capacity_1084  -25
    arc_1_15_16  connected_order_arc_1085  -14
    arc_1_15_16  out_degree_1310  1
    arc_1_15_16  in_degree_1317  1
    arc_1_15_16  original_T_including_depot_unload_1362  1.7053268374267958e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_16  arc_capacity_1084  1
    load_1_15_16  free_load_conservation_1315  1
    load_1_15_16  free_load_conservation_1321  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_17  arc_capacity_1086  -25
    arc_1_15_17  connected_order_arc_1087  -14
    arc_1_15_17  out_degree_1310  1
    arc_1_15_17  in_degree_1323  1
    arc_1_15_17  original_T_including_depot_unload_1362  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_17  arc_capacity_1086  1
    load_1_15_17  free_load_conservation_1315  1
    load_1_15_17  free_load_conservation_1327  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_18  arc_capacity_1088  -25
    arc_1_15_18  connected_order_arc_1089  -14
    arc_1_15_18  out_degree_1310  1
    arc_1_15_18  in_degree_1329  1
    arc_1_15_18  original_T_including_depot_unload_1362  1.7461252424213140e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_18  arc_capacity_1088  1
    load_1_15_18  free_load_conservation_1315  1
    load_1_15_18  free_load_conservation_1333  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_19  arc_capacity_1090  -25
    arc_1_15_19  connected_order_arc_1091  -14
    arc_1_15_19  out_degree_1310  1
    arc_1_15_19  in_degree_1335  1
    arc_1_15_19  original_T_including_depot_unload_1362  6.8976718276177132e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_19  arc_capacity_1090  1
    load_1_15_19  free_load_conservation_1315  1
    load_1_15_19  free_load_conservation_1339  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_20  arc_capacity_1092  -25
    arc_1_15_20  connected_order_arc_1093  -14
    arc_1_15_20  out_degree_1310  1
    arc_1_15_20  in_degree_1341  1
    arc_1_15_20  original_T_including_depot_unload_1362  2.7078292664437623e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_20  arc_capacity_1092  1
    load_1_15_20  free_load_conservation_1315  1
    load_1_15_20  free_load_conservation_1345  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_21  arc_capacity_1094  -25
    arc_1_15_21  connected_order_arc_1095  -14
    arc_1_15_21  out_degree_1310  1
    arc_1_15_21  in_degree_1347  1
    arc_1_15_21  original_T_including_depot_unload_1362  9.1580557259044724e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_21  arc_capacity_1094  1
    load_1_15_21  free_load_conservation_1315  1
    load_1_15_21  free_load_conservation_1351  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_22  arc_capacity_1096  -25
    arc_1_15_22  connected_order_arc_1097  -14
    arc_1_15_22  out_degree_1310  1
    arc_1_15_22  in_degree_1353  1
    arc_1_15_22  original_T_including_depot_unload_1362  2.7570828838654035e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_22  arc_capacity_1096  1
    load_1_15_22  free_load_conservation_1315  1
    load_1_15_22  free_load_conservation_1357  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_0  arc_capacity_1098  -25
    arc_1_16_0  depot_return_or_bypass_1274  1
    arc_1_16_0  out_degree_1316  1
    arc_1_16_0  original_T_including_depot_unload_1362  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_0  arc_capacity_1098  1
    load_1_16_0  free_load_conservation_1321  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_7  arc_capacity_1099  -25
    arc_1_16_7  connected_order_arc_1100  -14
    arc_1_16_7  in_degree_1276  1
    arc_1_16_7  out_degree_1316  1
    arc_1_16_7  original_T_including_depot_unload_1362  1.3600272346134373e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_7  arc_capacity_1099  1
    load_1_16_7  segment_load_conservation_1279  -1
    load_1_16_7  segment_prefix_lb_1280  1
    load_1_16_7  segment_prefix_ub_1281  1
    load_1_16_7  free_load_conservation_1321  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_8  arc_capacity_1101  -25
    arc_1_16_8  connected_order_arc_1102  -14
    arc_1_16_8  in_degree_1283  1
    arc_1_16_8  out_degree_1316  1
    arc_1_16_8  original_T_including_depot_unload_1362  1.3653307388496069e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_8  arc_capacity_1101  1
    load_1_16_8  segment_load_conservation_1286  -1
    load_1_16_8  segment_prefix_lb_1287  1
    load_1_16_8  segment_prefix_ub_1288  1
    load_1_16_8  free_load_conservation_1321  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_9  arc_capacity_1103  -25
    arc_1_16_9  connected_order_arc_1104  -14
    arc_1_16_9  in_degree_1290  1
    arc_1_16_9  out_degree_1316  1
    arc_1_16_9  original_T_including_depot_unload_1362  1.0921272639748563e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_9  arc_capacity_1103  1
    load_1_16_9  segment_load_conservation_1293  -1
    load_1_16_9  segment_prefix_lb_1294  1
    load_1_16_9  segment_prefix_ub_1295  1
    load_1_16_9  free_load_conservation_1321  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_10  arc_capacity_1105  -25
    arc_1_16_10  connected_order_arc_1106  -14
    arc_1_16_10  in_degree_1297  1
    arc_1_16_10  out_degree_1316  1
    arc_1_16_10  original_T_including_depot_unload_1362  6.7803521648175558e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_10  arc_capacity_1105  1
    load_1_16_10  segment_load_conservation_1300  -1
    load_1_16_10  segment_prefix_lb_1301  1
    load_1_16_10  segment_prefix_ub_1302  1
    load_1_16_10  free_load_conservation_1321  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_11  arc_capacity_1107  -25
    arc_1_16_11  connected_order_arc_1108  -14
    arc_1_16_11  in_degree_1304  1
    arc_1_16_11  out_degree_1316  1
    arc_1_16_11  original_T_including_depot_unload_1362  6.1704611580490348e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_11  arc_capacity_1107  1
    load_1_16_11  segment_load_conservation_1307  -1
    load_1_16_11  segment_prefix_lb_1308  1
    load_1_16_11  segment_prefix_ub_1309  1
    load_1_16_11  free_load_conservation_1321  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_15  arc_capacity_1109  -25
    arc_1_16_15  connected_order_arc_1110  -14
    arc_1_16_15  in_degree_1311  1
    arc_1_16_15  out_degree_1316  1
    arc_1_16_15  original_T_including_depot_unload_1362  1.7053268374267958e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_15  arc_capacity_1109  1
    load_1_16_15  free_load_conservation_1315  -1
    load_1_16_15  free_load_conservation_1321  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_17  arc_capacity_1111  -25
    arc_1_16_17  connected_order_arc_1112  -14
    arc_1_16_17  out_degree_1316  1
    arc_1_16_17  in_degree_1323  1
    arc_1_16_17  original_T_including_depot_unload_1362  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_17  arc_capacity_1111  1
    load_1_16_17  free_load_conservation_1321  1
    load_1_16_17  free_load_conservation_1327  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_18  arc_capacity_1113  -25
    arc_1_16_18  connected_order_arc_1114  -14
    arc_1_16_18  out_degree_1316  1
    arc_1_16_18  in_degree_1329  1
    arc_1_16_18  original_T_including_depot_unload_1362  3.3800157717255917e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_18  arc_capacity_1113  1
    load_1_16_18  free_load_conservation_1321  1
    load_1_16_18  free_load_conservation_1333  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_19  arc_capacity_1115  -25
    arc_1_16_19  connected_order_arc_1116  -14
    arc_1_16_19  out_degree_1316  1
    arc_1_16_19  in_degree_1335  1
    arc_1_16_19  original_T_including_depot_unload_1362  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_19  arc_capacity_1115  1
    load_1_16_19  free_load_conservation_1321  1
    load_1_16_19  free_load_conservation_1339  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_20  arc_capacity_1117  -25
    arc_1_16_20  connected_order_arc_1118  -14
    arc_1_16_20  out_degree_1316  1
    arc_1_16_20  in_degree_1341  1
    arc_1_16_20  original_T_including_depot_unload_1362  3.9758967496529505e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_20  arc_capacity_1117  1
    load_1_16_20  free_load_conservation_1321  1
    load_1_16_20  free_load_conservation_1345  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_21  arc_capacity_1119  -25
    arc_1_16_21  connected_order_arc_1120  -14
    arc_1_16_21  out_degree_1316  1
    arc_1_16_21  in_degree_1347  1
    arc_1_16_21  original_T_including_depot_unload_1362  7.9403551275216375e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_21  arc_capacity_1119  1
    load_1_16_21  free_load_conservation_1321  1
    load_1_16_21  free_load_conservation_1351  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_22  arc_capacity_1121  -25
    arc_1_16_22  connected_order_arc_1122  -14
    arc_1_16_22  out_degree_1316  1
    arc_1_16_22  in_degree_1353  1
    arc_1_16_22  original_T_including_depot_unload_1362  2.4111148152767828e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_22  arc_capacity_1121  1
    load_1_16_22  free_load_conservation_1321  1
    load_1_16_22  free_load_conservation_1357  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_0  arc_capacity_1123  -25
    arc_1_17_0  depot_return_or_bypass_1274  1
    arc_1_17_0  out_degree_1322  1
    arc_1_17_0  original_T_including_depot_unload_1362  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_0  arc_capacity_1123  1
    load_1_17_0  free_load_conservation_1327  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_7  arc_capacity_1124  -25
    arc_1_17_7  connected_order_arc_1125  -14
    arc_1_17_7  in_degree_1276  1
    arc_1_17_7  out_degree_1322  1
    arc_1_17_7  original_T_including_depot_unload_1362  7.3227602527872671e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_7  arc_capacity_1124  1
    load_1_17_7  segment_load_conservation_1279  -1
    load_1_17_7  segment_prefix_lb_1280  1
    load_1_17_7  segment_prefix_ub_1281  1
    load_1_17_7  free_load_conservation_1327  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_8  arc_capacity_1126  -25
    arc_1_17_8  connected_order_arc_1127  -14
    arc_1_17_8  in_degree_1283  1
    arc_1_17_8  out_degree_1322  1
    arc_1_17_8  original_T_including_depot_unload_1362  3.6824909986567474e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_8  arc_capacity_1126  1
    load_1_17_8  segment_load_conservation_1286  -1
    load_1_17_8  segment_prefix_lb_1287  1
    load_1_17_8  segment_prefix_ub_1288  1
    load_1_17_8  free_load_conservation_1327  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_9  arc_capacity_1128  -25
    arc_1_17_9  connected_order_arc_1129  -14
    arc_1_17_9  in_degree_1290  1
    arc_1_17_9  out_degree_1322  1
    arc_1_17_9  original_T_including_depot_unload_1362  1.3626829404511475e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_9  arc_capacity_1128  1
    load_1_17_9  segment_load_conservation_1293  -1
    load_1_17_9  segment_prefix_lb_1294  1
    load_1_17_9  segment_prefix_ub_1295  1
    load_1_17_9  free_load_conservation_1327  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_10  arc_capacity_1130  -25
    arc_1_17_10  connected_order_arc_1131  -14
    arc_1_17_10  in_degree_1297  1
    arc_1_17_10  out_degree_1322  1
    arc_1_17_10  original_T_including_depot_unload_1362  1.3823927712314810e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_10  arc_capacity_1130  1
    load_1_17_10  segment_load_conservation_1300  -1
    load_1_17_10  segment_prefix_lb_1301  1
    load_1_17_10  segment_prefix_ub_1302  1
    load_1_17_10  free_load_conservation_1327  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_11  arc_capacity_1132  -25
    arc_1_17_11  connected_order_arc_1133  -14
    arc_1_17_11  in_degree_1304  1
    arc_1_17_11  out_degree_1322  1
    arc_1_17_11  original_T_including_depot_unload_1362  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_11  arc_capacity_1132  1
    load_1_17_11  segment_load_conservation_1307  -1
    load_1_17_11  segment_prefix_lb_1308  1
    load_1_17_11  segment_prefix_ub_1309  1
    load_1_17_11  free_load_conservation_1327  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_15  arc_capacity_1134  -25
    arc_1_17_15  connected_order_arc_1135  -14
    arc_1_17_15  in_degree_1311  1
    arc_1_17_15  out_degree_1322  1
    arc_1_17_15  original_T_including_depot_unload_1362  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_15  arc_capacity_1134  1
    load_1_17_15  free_load_conservation_1315  -1
    load_1_17_15  free_load_conservation_1327  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_16  arc_capacity_1136  -25
    arc_1_17_16  connected_order_arc_1137  -14
    arc_1_17_16  in_degree_1317  1
    arc_1_17_16  out_degree_1322  1
    arc_1_17_16  original_T_including_depot_unload_1362  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_16  arc_capacity_1136  1
    load_1_17_16  free_load_conservation_1321  -1
    load_1_17_16  free_load_conservation_1327  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_18  arc_capacity_1138  -25
    arc_1_17_18  connected_order_arc_1139  -14
    arc_1_17_18  out_degree_1322  1
    arc_1_17_18  in_degree_1329  1
    arc_1_17_18  original_T_including_depot_unload_1362  1.6231508478292610e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_18  arc_capacity_1138  1
    load_1_17_18  free_load_conservation_1327  1
    load_1_17_18  free_load_conservation_1333  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_19  arc_capacity_1140  -25
    arc_1_17_19  connected_order_arc_1141  -14
    arc_1_17_19  out_degree_1322  1
    arc_1_17_19  in_degree_1335  1
    arc_1_17_19  original_T_including_depot_unload_1362  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_19  arc_capacity_1140  1
    load_1_17_19  free_load_conservation_1327  1
    load_1_17_19  free_load_conservation_1339  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_20  arc_capacity_1142  -25
    arc_1_17_20  connected_order_arc_1143  -14
    arc_1_17_20  out_degree_1322  1
    arc_1_17_20  in_degree_1341  1
    arc_1_17_20  original_T_including_depot_unload_1362  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_20  arc_capacity_1142  1
    load_1_17_20  free_load_conservation_1327  1
    load_1_17_20  free_load_conservation_1345  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_21  arc_capacity_1144  -25
    arc_1_17_21  connected_order_arc_1145  -14
    arc_1_17_21  out_degree_1322  1
    arc_1_17_21  in_degree_1347  1
    arc_1_17_21  original_T_including_depot_unload_1362  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_21  arc_capacity_1144  1
    load_1_17_21  free_load_conservation_1327  1
    load_1_17_21  free_load_conservation_1351  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_22  arc_capacity_1146  -25
    arc_1_17_22  connected_order_arc_1147  -14
    arc_1_17_22  out_degree_1322  1
    arc_1_17_22  in_degree_1353  1
    arc_1_17_22  original_T_including_depot_unload_1362  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_22  arc_capacity_1146  1
    load_1_17_22  free_load_conservation_1327  1
    load_1_17_22  free_load_conservation_1357  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_0  arc_capacity_1148  -25
    arc_1_18_0  depot_return_or_bypass_1274  1
    arc_1_18_0  out_degree_1328  1
    arc_1_18_0  original_T_including_depot_unload_1362  5.4249700630778887e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_0  arc_capacity_1148  1
    load_1_18_0  free_load_conservation_1333  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_7  arc_capacity_1149  -25
    arc_1_18_7  connected_order_arc_1150  -14
    arc_1_18_7  in_degree_1276  1
    arc_1_18_7  out_degree_1328  1
    arc_1_18_7  original_T_including_depot_unload_1362  1.2876689365561549e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_7  arc_capacity_1149  1
    load_1_18_7  segment_load_conservation_1279  -1
    load_1_18_7  segment_prefix_lb_1280  1
    load_1_18_7  segment_prefix_ub_1281  1
    load_1_18_7  free_load_conservation_1333  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_8  arc_capacity_1151  -25
    arc_1_18_8  connected_order_arc_1152  -14
    arc_1_18_8  in_degree_1283  1
    arc_1_18_8  out_degree_1328  1
    arc_1_18_8  original_T_including_depot_unload_1362  1.3840439316159188e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_8  arc_capacity_1151  1
    load_1_18_8  segment_load_conservation_1286  -1
    load_1_18_8  segment_prefix_lb_1287  1
    load_1_18_8  segment_prefix_ub_1288  1
    load_1_18_8  free_load_conservation_1333  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_9  arc_capacity_1153  -25
    arc_1_18_9  connected_order_arc_1154  -14
    arc_1_18_9  in_degree_1290  1
    arc_1_18_9  out_degree_1328  1
    arc_1_18_9  original_T_including_depot_unload_1362  8.5807018379884664e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_9  arc_capacity_1153  1
    load_1_18_9  segment_load_conservation_1293  -1
    load_1_18_9  segment_prefix_lb_1294  1
    load_1_18_9  segment_prefix_ub_1295  1
    load_1_18_9  free_load_conservation_1333  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_10  arc_capacity_1155  -25
    arc_1_18_10  connected_order_arc_1156  -14
    arc_1_18_10  in_degree_1297  1
    arc_1_18_10  out_degree_1328  1
    arc_1_18_10  original_T_including_depot_unload_1362  4.4474809771996007e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_10  arc_capacity_1155  1
    load_1_18_10  segment_load_conservation_1300  -1
    load_1_18_10  segment_prefix_lb_1301  1
    load_1_18_10  segment_prefix_ub_1302  1
    load_1_18_10  free_load_conservation_1333  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_11  arc_capacity_1157  -25
    arc_1_18_11  connected_order_arc_1158  -14
    arc_1_18_11  in_degree_1304  1
    arc_1_18_11  out_degree_1328  1
    arc_1_18_11  original_T_including_depot_unload_1362  6.4572843340219208e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_11  arc_capacity_1157  1
    load_1_18_11  segment_load_conservation_1307  -1
    load_1_18_11  segment_prefix_lb_1308  1
    load_1_18_11  segment_prefix_ub_1309  1
    load_1_18_11  free_load_conservation_1333  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_15  arc_capacity_1159  -25
    arc_1_18_15  connected_order_arc_1160  -14
    arc_1_18_15  in_degree_1311  1
    arc_1_18_15  out_degree_1328  1
    arc_1_18_15  original_T_including_depot_unload_1362  1.7461252424213140e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_15  arc_capacity_1159  1
    load_1_18_15  free_load_conservation_1315  -1
    load_1_18_15  free_load_conservation_1333  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_16  arc_capacity_1161  -25
    arc_1_18_16  connected_order_arc_1162  -14
    arc_1_18_16  in_degree_1317  1
    arc_1_18_16  out_degree_1328  1
    arc_1_18_16  original_T_including_depot_unload_1362  3.3800157717255917e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_16  arc_capacity_1161  1
    load_1_18_16  free_load_conservation_1321  -1
    load_1_18_16  free_load_conservation_1333  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_17  arc_capacity_1163  -25
    arc_1_18_17  connected_order_arc_1164  -14
    arc_1_18_17  in_degree_1323  1
    arc_1_18_17  out_degree_1328  1
    arc_1_18_17  original_T_including_depot_unload_1362  1.6231508478292610e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_17  arc_capacity_1163  1
    load_1_18_17  free_load_conservation_1327  -1
    load_1_18_17  free_load_conservation_1333  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_19  arc_capacity_1165  -25
    arc_1_18_19  connected_order_arc_1166  -14
    arc_1_18_19  out_degree_1328  1
    arc_1_18_19  in_degree_1335  1
    arc_1_18_19  original_T_including_depot_unload_1362  603.649383070884
    MARKER    'MARKER'                 'INTEND'
    load_1_18_19  arc_capacity_1165  1
    load_1_18_19  free_load_conservation_1333  1
    load_1_18_19  free_load_conservation_1339  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_20  arc_capacity_1167  -25
    arc_1_18_20  connected_order_arc_1168  -14
    arc_1_18_20  out_degree_1328  1
    arc_1_18_20  in_degree_1341  1
    arc_1_18_20  original_T_including_depot_unload_1362  2.8529311190414518e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_20  arc_capacity_1167  1
    load_1_18_20  free_load_conservation_1333  1
    load_1_18_20  free_load_conservation_1345  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_21  arc_capacity_1169  -25
    arc_1_18_21  connected_order_arc_1170  -14
    arc_1_18_21  out_degree_1328  1
    arc_1_18_21  in_degree_1347  1
    arc_1_18_21  original_T_including_depot_unload_1362  1.0838347754693179e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_21  arc_capacity_1169  1
    load_1_18_21  free_load_conservation_1333  1
    load_1_18_21  free_load_conservation_1351  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_22  arc_capacity_1171  -25
    arc_1_18_22  connected_order_arc_1172  -14
    arc_1_18_22  out_degree_1328  1
    arc_1_18_22  in_degree_1353  1
    arc_1_18_22  original_T_including_depot_unload_1362  3.4289721135663990e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_22  arc_capacity_1171  1
    load_1_18_22  free_load_conservation_1333  1
    load_1_18_22  free_load_conservation_1357  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_0  arc_capacity_1173  -25
    arc_1_19_0  depot_return_or_bypass_1274  1
    arc_1_19_0  out_degree_1334  1
    arc_1_19_0  original_T_including_depot_unload_1362  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_0  arc_capacity_1173  1
    load_1_19_0  free_load_conservation_1339  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_7  arc_capacity_1174  -25
    arc_1_19_7  connected_order_arc_1175  -14
    arc_1_19_7  in_degree_1276  1
    arc_1_19_7  out_degree_1334  1
    arc_1_19_7  original_T_including_depot_unload_1362  8.1417957710766450e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_7  arc_capacity_1174  1
    load_1_19_7  segment_load_conservation_1279  -1
    load_1_19_7  segment_prefix_lb_1280  1
    load_1_19_7  segment_prefix_ub_1281  1
    load_1_19_7  free_load_conservation_1339  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_8  arc_capacity_1176  -25
    arc_1_19_8  connected_order_arc_1177  -14
    arc_1_19_8  in_degree_1283  1
    arc_1_19_8  out_degree_1334  1
    arc_1_19_8  original_T_including_depot_unload_1362  1.0412376551742484e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_8  arc_capacity_1176  1
    load_1_19_8  segment_load_conservation_1286  -1
    load_1_19_8  segment_prefix_lb_1287  1
    load_1_19_8  segment_prefix_ub_1288  1
    load_1_19_8  free_load_conservation_1339  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_9  arc_capacity_1178  -25
    arc_1_19_9  connected_order_arc_1179  -14
    arc_1_19_9  in_degree_1290  1
    arc_1_19_9  out_degree_1334  1
    arc_1_19_9  original_T_including_depot_unload_1362  2.5572087458878266e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_9  arc_capacity_1178  1
    load_1_19_9  segment_load_conservation_1293  -1
    load_1_19_9  segment_prefix_lb_1294  1
    load_1_19_9  segment_prefix_ub_1295  1
    load_1_19_9  free_load_conservation_1339  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_10  arc_capacity_1180  -25
    arc_1_19_10  connected_order_arc_1181  -14
    arc_1_19_10  in_degree_1297  1
    arc_1_19_10  out_degree_1334  1
    arc_1_19_10  original_T_including_depot_unload_1362  1.6444540482789353e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_10  arc_capacity_1180  1
    load_1_19_10  segment_load_conservation_1300  -1
    load_1_19_10  segment_prefix_lb_1301  1
    load_1_19_10  segment_prefix_ub_1302  1
    load_1_19_10  free_load_conservation_1339  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_11  arc_capacity_1182  -25
    arc_1_19_11  connected_order_arc_1183  -14
    arc_1_19_11  in_degree_1304  1
    arc_1_19_11  out_degree_1334  1
    arc_1_19_11  original_T_including_depot_unload_1362  5.7102904773674652e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_11  arc_capacity_1182  1
    load_1_19_11  segment_load_conservation_1307  -1
    load_1_19_11  segment_prefix_lb_1308  1
    load_1_19_11  segment_prefix_ub_1309  1
    load_1_19_11  free_load_conservation_1339  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_15  arc_capacity_1184  -25
    arc_1_19_15  connected_order_arc_1185  -14
    arc_1_19_15  in_degree_1311  1
    arc_1_19_15  out_degree_1334  1
    arc_1_19_15  original_T_including_depot_unload_1362  6.8976718276177132e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_15  arc_capacity_1184  1
    load_1_19_15  free_load_conservation_1315  -1
    load_1_19_15  free_load_conservation_1339  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_16  arc_capacity_1186  -25
    arc_1_19_16  connected_order_arc_1187  -14
    arc_1_19_16  in_degree_1317  1
    arc_1_19_16  out_degree_1334  1
    arc_1_19_16  original_T_including_depot_unload_1362  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_16  arc_capacity_1186  1
    load_1_19_16  free_load_conservation_1321  -1
    load_1_19_16  free_load_conservation_1339  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_17  arc_capacity_1188  -25
    arc_1_19_17  connected_order_arc_1189  -14
    arc_1_19_17  in_degree_1323  1
    arc_1_19_17  out_degree_1334  1
    arc_1_19_17  original_T_including_depot_unload_1362  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_17  arc_capacity_1188  1
    load_1_19_17  free_load_conservation_1327  -1
    load_1_19_17  free_load_conservation_1339  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_18  arc_capacity_1190  -25
    arc_1_19_18  connected_order_arc_1191  -14
    arc_1_19_18  in_degree_1329  1
    arc_1_19_18  out_degree_1334  1
    arc_1_19_18  original_T_including_depot_unload_1362  603.649383070884
    MARKER    'MARKER'                 'INTEND'
    load_1_19_18  arc_capacity_1190  1
    load_1_19_18  free_load_conservation_1333  -1
    load_1_19_18  free_load_conservation_1339  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_20  arc_capacity_1192  -25
    arc_1_19_20  connected_order_arc_1193  -14
    arc_1_19_20  out_degree_1334  1
    arc_1_19_20  in_degree_1341  1
    arc_1_19_20  original_T_including_depot_unload_1362  4.5128490093732506e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_20  arc_capacity_1192  1
    load_1_19_20  free_load_conservation_1339  1
    load_1_19_20  free_load_conservation_1345  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_21  arc_capacity_1194  -25
    arc_1_19_21  connected_order_arc_1195  -14
    arc_1_19_21  out_degree_1334  1
    arc_1_19_21  in_degree_1347  1
    arc_1_19_21  original_T_including_depot_unload_1362  1.3127274783157229e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_21  arc_capacity_1194  1
    load_1_19_21  free_load_conservation_1339  1
    load_1_19_21  free_load_conservation_1351  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_22  arc_capacity_1196  -25
    arc_1_19_22  connected_order_arc_1197  -14
    arc_1_19_22  out_degree_1334  1
    arc_1_19_22  in_degree_1353  1
    arc_1_19_22  original_T_including_depot_unload_1362  9.3962613467893414e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_22  arc_capacity_1196  1
    load_1_19_22  free_load_conservation_1339  1
    load_1_19_22  free_load_conservation_1357  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_0  arc_capacity_1198  -25
    arc_1_20_0  depot_return_or_bypass_1274  1
    arc_1_20_0  out_degree_1340  1
    arc_1_20_0  original_T_including_depot_unload_1362  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_0  arc_capacity_1198  1
    load_1_20_0  free_load_conservation_1345  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_7  arc_capacity_1199  -25
    arc_1_20_7  connected_order_arc_1200  -14
    arc_1_20_7  in_degree_1276  1
    arc_1_20_7  out_degree_1340  1
    arc_1_20_7  original_T_including_depot_unload_1362  1.0170488276971105e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_7  arc_capacity_1199  1
    load_1_20_7  segment_load_conservation_1279  -1
    load_1_20_7  segment_prefix_lb_1280  1
    load_1_20_7  segment_prefix_ub_1281  1
    load_1_20_7  free_load_conservation_1345  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_8  arc_capacity_1201  -25
    arc_1_20_8  connected_order_arc_1202  -14
    arc_1_20_8  in_degree_1283  1
    arc_1_20_8  out_degree_1340  1
    arc_1_20_8  original_T_including_depot_unload_1362  1.0988088346747072e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_8  arc_capacity_1201  1
    load_1_20_8  segment_load_conservation_1286  -1
    load_1_20_8  segment_prefix_lb_1287  1
    load_1_20_8  segment_prefix_ub_1288  1
    load_1_20_8  free_load_conservation_1345  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_9  arc_capacity_1203  -25
    arc_1_20_9  connected_order_arc_1204  -14
    arc_1_20_9  in_degree_1290  1
    arc_1_20_9  out_degree_1340  1
    arc_1_20_9  original_T_including_depot_unload_1362  6.9726539003798837e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_9  arc_capacity_1203  1
    load_1_20_9  segment_load_conservation_1293  -1
    load_1_20_9  segment_prefix_lb_1294  1
    load_1_20_9  segment_prefix_ub_1295  1
    load_1_20_9  free_load_conservation_1345  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_10  arc_capacity_1205  -25
    arc_1_20_10  connected_order_arc_1206  -14
    arc_1_20_10  in_degree_1297  1
    arc_1_20_10  out_degree_1340  1
    arc_1_20_10  original_T_including_depot_unload_1362  2.9438424317501273e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_10  arc_capacity_1205  1
    load_1_20_10  segment_load_conservation_1300  -1
    load_1_20_10  segment_prefix_lb_1301  1
    load_1_20_10  segment_prefix_ub_1302  1
    load_1_20_10  free_load_conservation_1345  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_11  arc_capacity_1207  -25
    arc_1_20_11  connected_order_arc_1208  -14
    arc_1_20_11  in_degree_1304  1
    arc_1_20_11  out_degree_1340  1
    arc_1_20_11  original_T_including_depot_unload_1362  3.6658228437834981e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_11  arc_capacity_1207  1
    load_1_20_11  segment_load_conservation_1307  -1
    load_1_20_11  segment_prefix_lb_1308  1
    load_1_20_11  segment_prefix_ub_1309  1
    load_1_20_11  free_load_conservation_1345  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_15  arc_capacity_1209  -25
    arc_1_20_15  connected_order_arc_1210  -14
    arc_1_20_15  in_degree_1311  1
    arc_1_20_15  out_degree_1340  1
    arc_1_20_15  original_T_including_depot_unload_1362  2.7078292664437623e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_15  arc_capacity_1209  1
    load_1_20_15  free_load_conservation_1315  -1
    load_1_20_15  free_load_conservation_1345  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_16  arc_capacity_1211  -25
    arc_1_20_16  connected_order_arc_1212  -14
    arc_1_20_16  in_degree_1317  1
    arc_1_20_16  out_degree_1340  1
    arc_1_20_16  original_T_including_depot_unload_1362  3.9758967496529505e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_16  arc_capacity_1211  1
    load_1_20_16  free_load_conservation_1321  -1
    load_1_20_16  free_load_conservation_1345  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_17  arc_capacity_1213  -25
    arc_1_20_17  connected_order_arc_1214  -14
    arc_1_20_17  in_degree_1323  1
    arc_1_20_17  out_degree_1340  1
    arc_1_20_17  original_T_including_depot_unload_1362  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_17  arc_capacity_1213  1
    load_1_20_17  free_load_conservation_1327  -1
    load_1_20_17  free_load_conservation_1345  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_18  arc_capacity_1215  -25
    arc_1_20_18  connected_order_arc_1216  -14
    arc_1_20_18  in_degree_1329  1
    arc_1_20_18  out_degree_1340  1
    arc_1_20_18  original_T_including_depot_unload_1362  2.8529311190414518e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_18  arc_capacity_1215  1
    load_1_20_18  free_load_conservation_1333  -1
    load_1_20_18  free_load_conservation_1345  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_19  arc_capacity_1217  -25
    arc_1_20_19  connected_order_arc_1218  -14
    arc_1_20_19  in_degree_1335  1
    arc_1_20_19  out_degree_1340  1
    arc_1_20_19  original_T_including_depot_unload_1362  4.5128490093732506e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_19  arc_capacity_1217  1
    load_1_20_19  free_load_conservation_1339  -1
    load_1_20_19  free_load_conservation_1345  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_21  arc_capacity_1219  -25
    arc_1_20_21  connected_order_arc_1220  -14
    arc_1_20_21  out_degree_1340  1
    arc_1_20_21  in_degree_1347  1
    arc_1_20_21  original_T_including_depot_unload_1362  9.3905252655669165e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_21  arc_capacity_1219  1
    load_1_20_21  free_load_conservation_1345  1
    load_1_20_21  free_load_conservation_1351  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_22  arc_capacity_1221  -25
    arc_1_20_22  connected_order_arc_1222  -14
    arc_1_20_22  out_degree_1340  1
    arc_1_20_22  in_degree_1353  1
    arc_1_20_22  original_T_including_depot_unload_1362  545.439458844012
    MARKER    'MARKER'                 'INTEND'
    load_1_20_22  arc_capacity_1221  1
    load_1_20_22  free_load_conservation_1345  1
    load_1_20_22  free_load_conservation_1357  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_0  arc_capacity_1223  -25
    arc_1_21_0  depot_return_or_bypass_1274  1
    arc_1_21_0  out_degree_1346  1
    arc_1_21_0  original_T_including_depot_unload_1362  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_0  arc_capacity_1223  1
    load_1_21_0  free_load_conservation_1351  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_7  arc_capacity_1224  -25
    arc_1_21_7  connected_order_arc_1225  -14
    arc_1_21_7  in_degree_1276  1
    arc_1_21_7  out_degree_1346  1
    arc_1_21_7  original_T_including_depot_unload_1362  1.3551088510632424e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_7  arc_capacity_1224  1
    load_1_21_7  segment_load_conservation_1279  -1
    load_1_21_7  segment_prefix_lb_1280  1
    load_1_21_7  segment_prefix_ub_1281  1
    load_1_21_7  free_load_conservation_1351  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_8  arc_capacity_1226  -25
    arc_1_21_8  connected_order_arc_1227  -14
    arc_1_21_8  in_degree_1283  1
    arc_1_21_8  out_degree_1346  1
    arc_1_21_8  original_T_including_depot_unload_1362  1.1479472058029019e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_8  arc_capacity_1226  1
    load_1_21_8  segment_load_conservation_1286  -1
    load_1_21_8  segment_prefix_lb_1287  1
    load_1_21_8  segment_prefix_ub_1288  1
    load_1_21_8  free_load_conservation_1351  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_9  arc_capacity_1228  -25
    arc_1_21_9  connected_order_arc_1229  -14
    arc_1_21_9  in_degree_1290  1
    arc_1_21_9  out_degree_1346  1
    arc_1_21_9  original_T_including_depot_unload_1362  1.4961553163922974e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_9  arc_capacity_1228  1
    load_1_21_9  segment_load_conservation_1293  -1
    load_1_21_9  segment_prefix_lb_1294  1
    load_1_21_9  segment_prefix_ub_1295  1
    load_1_21_9  free_load_conservation_1351  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_10  arc_capacity_1230  -25
    arc_1_21_10  connected_order_arc_1231  -14
    arc_1_21_10  in_degree_1297  1
    arc_1_21_10  out_degree_1346  1
    arc_1_21_10  original_T_including_depot_unload_1362  1.1957430085580884e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_10  arc_capacity_1230  1
    load_1_21_10  segment_load_conservation_1300  -1
    load_1_21_10  segment_prefix_lb_1301  1
    load_1_21_10  segment_prefix_ub_1302  1
    load_1_21_10  free_load_conservation_1351  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_11  arc_capacity_1232  -25
    arc_1_21_11  connected_order_arc_1233  -14
    arc_1_21_11  in_degree_1304  1
    arc_1_21_11  out_degree_1346  1
    arc_1_21_11  original_T_including_depot_unload_1362  7.6275540057842773e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_11  arc_capacity_1232  1
    load_1_21_11  segment_load_conservation_1307  -1
    load_1_21_11  segment_prefix_lb_1308  1
    load_1_21_11  segment_prefix_ub_1309  1
    load_1_21_11  free_load_conservation_1351  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_15  arc_capacity_1234  -25
    arc_1_21_15  connected_order_arc_1235  -14
    arc_1_21_15  in_degree_1311  1
    arc_1_21_15  out_degree_1346  1
    arc_1_21_15  original_T_including_depot_unload_1362  9.1580557259044724e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_15  arc_capacity_1234  1
    load_1_21_15  free_load_conservation_1315  -1
    load_1_21_15  free_load_conservation_1351  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_16  arc_capacity_1236  -25
    arc_1_21_16  connected_order_arc_1237  -14
    arc_1_21_16  in_degree_1317  1
    arc_1_21_16  out_degree_1346  1
    arc_1_21_16  original_T_including_depot_unload_1362  7.9403551275216375e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_16  arc_capacity_1236  1
    load_1_21_16  free_load_conservation_1321  -1
    load_1_21_16  free_load_conservation_1351  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_17  arc_capacity_1238  -25
    arc_1_21_17  connected_order_arc_1239  -14
    arc_1_21_17  in_degree_1323  1
    arc_1_21_17  out_degree_1346  1
    arc_1_21_17  original_T_including_depot_unload_1362  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_17  arc_capacity_1238  1
    load_1_21_17  free_load_conservation_1327  -1
    load_1_21_17  free_load_conservation_1351  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_18  arc_capacity_1240  -25
    arc_1_21_18  connected_order_arc_1241  -14
    arc_1_21_18  in_degree_1329  1
    arc_1_21_18  out_degree_1346  1
    arc_1_21_18  original_T_including_depot_unload_1362  1.0838347754693179e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_18  arc_capacity_1240  1
    load_1_21_18  free_load_conservation_1333  -1
    load_1_21_18  free_load_conservation_1351  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_19  arc_capacity_1242  -25
    arc_1_21_19  connected_order_arc_1243  -14
    arc_1_21_19  in_degree_1335  1
    arc_1_21_19  out_degree_1346  1
    arc_1_21_19  original_T_including_depot_unload_1362  1.3127274783157229e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_19  arc_capacity_1242  1
    load_1_21_19  free_load_conservation_1339  -1
    load_1_21_19  free_load_conservation_1351  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_20  arc_capacity_1244  -25
    arc_1_21_20  connected_order_arc_1245  -14
    arc_1_21_20  in_degree_1341  1
    arc_1_21_20  out_degree_1346  1
    arc_1_21_20  original_T_including_depot_unload_1362  9.3905252655669165e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_20  arc_capacity_1244  1
    load_1_21_20  free_load_conservation_1345  -1
    load_1_21_20  free_load_conservation_1351  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_22  arc_capacity_1246  -25
    arc_1_21_22  connected_order_arc_1247  -14
    arc_1_21_22  out_degree_1346  1
    arc_1_21_22  in_degree_1353  1
    arc_1_21_22  original_T_including_depot_unload_1362  1.0038065985492663e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_22  arc_capacity_1246  1
    load_1_21_22  free_load_conservation_1351  1
    load_1_21_22  free_load_conservation_1357  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_0  arc_capacity_1248  -25
    arc_1_22_0  depot_return_or_bypass_1274  1
    arc_1_22_0  out_degree_1352  1
    arc_1_22_0  original_T_including_depot_unload_1362  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_0  arc_capacity_1248  1
    load_1_22_0  free_load_conservation_1357  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_7  arc_capacity_1249  -25
    arc_1_22_7  connected_order_arc_1250  -14
    arc_1_22_7  in_degree_1276  1
    arc_1_22_7  out_degree_1352  1
    arc_1_22_7  original_T_including_depot_unload_1362  1.5546511874277910e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_22_7  arc_capacity_1249  1
    load_1_22_7  segment_load_conservation_1279  -1
    load_1_22_7  segment_prefix_lb_1280  1
    load_1_22_7  segment_prefix_ub_1281  1
    load_1_22_7  free_load_conservation_1357  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_8  arc_capacity_1251  -25
    arc_1_22_8  connected_order_arc_1252  -14
    arc_1_22_8  in_degree_1283  1
    arc_1_22_8  out_degree_1352  1
    arc_1_22_8  original_T_including_depot_unload_1362  1.5892857916507662e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_22_8  arc_capacity_1251  1
    load_1_22_8  segment_load_conservation_1286  -1
    load_1_22_8  segment_prefix_lb_1287  1
    load_1_22_8  segment_prefix_ub_1288  1
    load_1_22_8  free_load_conservation_1357  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_9  arc_capacity_1253  -25
    arc_1_22_9  connected_order_arc_1254  -14
    arc_1_22_9  in_degree_1290  1
    arc_1_22_9  out_degree_1352  1
    arc_1_22_9  original_T_including_depot_unload_1362  1.1952607376785465e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_22_9  arc_capacity_1253  1
    load_1_22_9  segment_load_conservation_1293  -1
    load_1_22_9  segment_prefix_lb_1294  1
    load_1_22_9  segment_prefix_ub_1295  1
    load_1_22_9  free_load_conservation_1357  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_10  arc_capacity_1255  -25
    arc_1_22_10  connected_order_arc_1256  -14
    arc_1_22_10  in_degree_1297  1
    arc_1_22_10  out_degree_1352  1
    arc_1_22_10  original_T_including_depot_unload_1362  7.7690262287132452e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_10  arc_capacity_1255  1
    load_1_22_10  segment_load_conservation_1300  -1
    load_1_22_10  segment_prefix_lb_1301  1
    load_1_22_10  segment_prefix_ub_1302  1
    load_1_22_10  free_load_conservation_1357  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_11  arc_capacity_1257  -25
    arc_1_22_11  connected_order_arc_1258  -14
    arc_1_22_11  in_degree_1304  1
    arc_1_22_11  out_degree_1352  1
    arc_1_22_11  original_T_including_depot_unload_1362  8.3393751072629220e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_11  arc_capacity_1257  1
    load_1_22_11  segment_load_conservation_1307  -1
    load_1_22_11  segment_prefix_lb_1308  1
    load_1_22_11  segment_prefix_ub_1309  1
    load_1_22_11  free_load_conservation_1357  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_15  arc_capacity_1259  -25
    arc_1_22_15  connected_order_arc_1260  -14
    arc_1_22_15  in_degree_1311  1
    arc_1_22_15  out_degree_1352  1
    arc_1_22_15  original_T_including_depot_unload_1362  2.7570828838654035e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_15  arc_capacity_1259  1
    load_1_22_15  free_load_conservation_1315  -1
    load_1_22_15  free_load_conservation_1357  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_16  arc_capacity_1261  -25
    arc_1_22_16  connected_order_arc_1262  -14
    arc_1_22_16  in_degree_1317  1
    arc_1_22_16  out_degree_1352  1
    arc_1_22_16  original_T_including_depot_unload_1362  2.4111148152767828e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_16  arc_capacity_1261  1
    load_1_22_16  free_load_conservation_1321  -1
    load_1_22_16  free_load_conservation_1357  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_17  arc_capacity_1263  -25
    arc_1_22_17  connected_order_arc_1264  -14
    arc_1_22_17  in_degree_1323  1
    arc_1_22_17  out_degree_1352  1
    arc_1_22_17  original_T_including_depot_unload_1362  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_22_17  arc_capacity_1263  1
    load_1_22_17  free_load_conservation_1327  -1
    load_1_22_17  free_load_conservation_1357  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_18  arc_capacity_1265  -25
    arc_1_22_18  connected_order_arc_1266  -14
    arc_1_22_18  in_degree_1329  1
    arc_1_22_18  out_degree_1352  1
    arc_1_22_18  original_T_including_depot_unload_1362  3.4289721135663990e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_18  arc_capacity_1265  1
    load_1_22_18  free_load_conservation_1333  -1
    load_1_22_18  free_load_conservation_1357  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_19  arc_capacity_1267  -25
    arc_1_22_19  connected_order_arc_1268  -14
    arc_1_22_19  in_degree_1335  1
    arc_1_22_19  out_degree_1352  1
    arc_1_22_19  original_T_including_depot_unload_1362  9.3962613467893414e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_19  arc_capacity_1267  1
    load_1_22_19  free_load_conservation_1339  -1
    load_1_22_19  free_load_conservation_1357  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_20  arc_capacity_1269  -25
    arc_1_22_20  connected_order_arc_1270  -14
    arc_1_22_20  in_degree_1341  1
    arc_1_22_20  out_degree_1352  1
    arc_1_22_20  original_T_including_depot_unload_1362  545.439458844012
    MARKER    'MARKER'                 'INTEND'
    load_1_22_20  arc_capacity_1269  1
    load_1_22_20  free_load_conservation_1345  -1
    load_1_22_20  free_load_conservation_1357  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_21  arc_capacity_1271  -25
    arc_1_22_21  connected_order_arc_1272  -14
    arc_1_22_21  in_degree_1347  1
    arc_1_22_21  out_degree_1352  1
    arc_1_22_21  original_T_including_depot_unload_1362  1.0038065985492663e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_22_21  arc_capacity_1271  1
    load_1_22_21  free_load_conservation_1351  -1
    load_1_22_21  free_load_conservation_1357  1
    visit_2_12  out_degree_1608  -1
    visit_2_12  in_degree_1609  -1
    visit_2_12  order_active_lb_1610  -1
    visit_2_12  order_active_ub_1611  -11
    order_2_12  connected_order_arc_1377  -1
    order_2_12  connected_order_arc_1379  -1
    order_2_12  connected_order_arc_1381  -1
    order_2_12  connected_order_arc_1383  -1
    order_2_12  connected_order_arc_1385  -1
    order_2_12  connected_order_arc_1387  -1
    order_2_12  connected_order_arc_1389  -1
    order_2_12  connected_order_arc_1391  -1
    order_2_12  connected_order_arc_1393  -1
    order_2_12  connected_order_arc_1395  -1
    order_2_12  connected_order_arc_1398  1
    order_2_12  connected_order_arc_1419  1
    order_2_12  connected_order_arc_1440  1
    order_2_12  connected_order_arc_1461  1
    order_2_12  connected_order_arc_1482  1
    order_2_12  connected_order_arc_1503  1
    order_2_12  connected_order_arc_1524  1
    order_2_12  connected_order_arc_1545  1
    order_2_12  connected_order_arc_1566  1
    order_2_12  connected_order_arc_1587  1
    order_2_12  order_active_lb_1610  1
    order_2_12  order_active_ub_1611  1
    order_2_12  fixed_segment_relative_order_1677  -1
    visit_2_13  out_degree_1615  -1
    visit_2_13  in_degree_1616  -1
    visit_2_13  order_active_lb_1617  -1
    visit_2_13  order_active_ub_1618  -11
    order_2_13  connected_order_arc_1377  1
    order_2_13  connected_order_arc_1398  -1
    order_2_13  connected_order_arc_1400  -1
    order_2_13  connected_order_arc_1402  -1
    order_2_13  connected_order_arc_1404  -1
    order_2_13  connected_order_arc_1406  -1
    order_2_13  connected_order_arc_1408  -1
    order_2_13  connected_order_arc_1410  -1
    order_2_13  connected_order_arc_1412  -1
    order_2_13  connected_order_arc_1414  -1
    order_2_13  connected_order_arc_1416  -1
    order_2_13  connected_order_arc_1421  1
    order_2_13  connected_order_arc_1442  1
    order_2_13  connected_order_arc_1463  1
    order_2_13  connected_order_arc_1484  1
    order_2_13  connected_order_arc_1505  1
    order_2_13  connected_order_arc_1526  1
    order_2_13  connected_order_arc_1547  1
    order_2_13  connected_order_arc_1568  1
    order_2_13  connected_order_arc_1589  1
    order_2_13  order_active_lb_1617  1
    order_2_13  order_active_ub_1618  1
    order_2_13  fixed_segment_relative_order_1677  1
    order_2_13  fixed_segment_relative_order_1678  -1
    visit_2_14  out_degree_1622  -1
    visit_2_14  in_degree_1623  -1
    visit_2_14  order_active_lb_1624  -1
    visit_2_14  order_active_ub_1625  -11
    order_2_14  connected_order_arc_1379  1
    order_2_14  connected_order_arc_1400  1
    order_2_14  connected_order_arc_1419  -1
    order_2_14  connected_order_arc_1421  -1
    order_2_14  connected_order_arc_1423  -1
    order_2_14  connected_order_arc_1425  -1
    order_2_14  connected_order_arc_1427  -1
    order_2_14  connected_order_arc_1429  -1
    order_2_14  connected_order_arc_1431  -1
    order_2_14  connected_order_arc_1433  -1
    order_2_14  connected_order_arc_1435  -1
    order_2_14  connected_order_arc_1437  -1
    order_2_14  connected_order_arc_1444  1
    order_2_14  connected_order_arc_1465  1
    order_2_14  connected_order_arc_1486  1
    order_2_14  connected_order_arc_1507  1
    order_2_14  connected_order_arc_1528  1
    order_2_14  connected_order_arc_1549  1
    order_2_14  connected_order_arc_1570  1
    order_2_14  connected_order_arc_1591  1
    order_2_14  order_active_lb_1624  1
    order_2_14  order_active_ub_1625  1
    order_2_14  fixed_segment_relative_order_1678  1
    visit_2_15  out_degree_1629  -1
    visit_2_15  in_degree_1630  -1
    visit_2_15  order_active_lb_1631  -1
    visit_2_15  order_active_ub_1632  -11
    visit_2_15  service_visit_def_1633  -1
    order_2_15  connected_order_arc_1381  1
    order_2_15  connected_order_arc_1402  1
    order_2_15  connected_order_arc_1423  1
    order_2_15  connected_order_arc_1440  -1
    order_2_15  connected_order_arc_1442  -1
    order_2_15  connected_order_arc_1444  -1
    order_2_15  connected_order_arc_1446  -1
    order_2_15  connected_order_arc_1448  -1
    order_2_15  connected_order_arc_1450  -1
    order_2_15  connected_order_arc_1452  -1
    order_2_15  connected_order_arc_1454  -1
    order_2_15  connected_order_arc_1456  -1
    order_2_15  connected_order_arc_1458  -1
    order_2_15  connected_order_arc_1467  1
    order_2_15  connected_order_arc_1488  1
    order_2_15  connected_order_arc_1509  1
    order_2_15  connected_order_arc_1530  1
    order_2_15  connected_order_arc_1551  1
    order_2_15  connected_order_arc_1572  1
    order_2_15  connected_order_arc_1593  1
    order_2_15  order_active_lb_1631  1
    order_2_15  order_active_ub_1632  1
    visit_2_16  out_degree_1635  -1
    visit_2_16  in_degree_1636  -1
    visit_2_16  order_active_lb_1637  -1
    visit_2_16  order_active_ub_1638  -11
    visit_2_16  service_visit_def_1639  -1
    order_2_16  connected_order_arc_1383  1
    order_2_16  connected_order_arc_1404  1
    order_2_16  connected_order_arc_1425  1
    order_2_16  connected_order_arc_1446  1
    order_2_16  connected_order_arc_1461  -1
    order_2_16  connected_order_arc_1463  -1
    order_2_16  connected_order_arc_1465  -1
    order_2_16  connected_order_arc_1467  -1
    order_2_16  connected_order_arc_1469  -1
    order_2_16  connected_order_arc_1471  -1
    order_2_16  connected_order_arc_1473  -1
    order_2_16  connected_order_arc_1475  -1
    order_2_16  connected_order_arc_1477  -1
    order_2_16  connected_order_arc_1479  -1
    order_2_16  connected_order_arc_1490  1
    order_2_16  connected_order_arc_1511  1
    order_2_16  connected_order_arc_1532  1
    order_2_16  connected_order_arc_1553  1
    order_2_16  connected_order_arc_1574  1
    order_2_16  connected_order_arc_1595  1
    order_2_16  order_active_lb_1637  1
    order_2_16  order_active_ub_1638  1
    visit_2_17  out_degree_1641  -1
    visit_2_17  in_degree_1642  -1
    visit_2_17  order_active_lb_1643  -1
    visit_2_17  order_active_ub_1644  -11
    visit_2_17  service_visit_def_1645  -1
    order_2_17  connected_order_arc_1385  1
    order_2_17  connected_order_arc_1406  1
    order_2_17  connected_order_arc_1427  1
    order_2_17  connected_order_arc_1448  1
    order_2_17  connected_order_arc_1469  1
    order_2_17  connected_order_arc_1482  -1
    order_2_17  connected_order_arc_1484  -1
    order_2_17  connected_order_arc_1486  -1
    order_2_17  connected_order_arc_1488  -1
    order_2_17  connected_order_arc_1490  -1
    order_2_17  connected_order_arc_1492  -1
    order_2_17  connected_order_arc_1494  -1
    order_2_17  connected_order_arc_1496  -1
    order_2_17  connected_order_arc_1498  -1
    order_2_17  connected_order_arc_1500  -1
    order_2_17  connected_order_arc_1513  1
    order_2_17  connected_order_arc_1534  1
    order_2_17  connected_order_arc_1555  1
    order_2_17  connected_order_arc_1576  1
    order_2_17  connected_order_arc_1597  1
    order_2_17  order_active_lb_1643  1
    order_2_17  order_active_ub_1644  1
    visit_2_18  out_degree_1647  -1
    visit_2_18  in_degree_1648  -1
    visit_2_18  order_active_lb_1649  -1
    visit_2_18  order_active_ub_1650  -11
    visit_2_18  service_visit_def_1651  -1
    order_2_18  connected_order_arc_1387  1
    order_2_18  connected_order_arc_1408  1
    order_2_18  connected_order_arc_1429  1
    order_2_18  connected_order_arc_1450  1
    order_2_18  connected_order_arc_1471  1
    order_2_18  connected_order_arc_1492  1
    order_2_18  connected_order_arc_1503  -1
    order_2_18  connected_order_arc_1505  -1
    order_2_18  connected_order_arc_1507  -1
    order_2_18  connected_order_arc_1509  -1
    order_2_18  connected_order_arc_1511  -1
    order_2_18  connected_order_arc_1513  -1
    order_2_18  connected_order_arc_1515  -1
    order_2_18  connected_order_arc_1517  -1
    order_2_18  connected_order_arc_1519  -1
    order_2_18  connected_order_arc_1521  -1
    order_2_18  connected_order_arc_1536  1
    order_2_18  connected_order_arc_1557  1
    order_2_18  connected_order_arc_1578  1
    order_2_18  connected_order_arc_1599  1
    order_2_18  order_active_lb_1649  1
    order_2_18  order_active_ub_1650  1
    visit_2_19  out_degree_1653  -1
    visit_2_19  in_degree_1654  -1
    visit_2_19  order_active_lb_1655  -1
    visit_2_19  order_active_ub_1656  -11
    visit_2_19  service_visit_def_1657  -1
    order_2_19  connected_order_arc_1389  1
    order_2_19  connected_order_arc_1410  1
    order_2_19  connected_order_arc_1431  1
    order_2_19  connected_order_arc_1452  1
    order_2_19  connected_order_arc_1473  1
    order_2_19  connected_order_arc_1494  1
    order_2_19  connected_order_arc_1515  1
    order_2_19  connected_order_arc_1524  -1
    order_2_19  connected_order_arc_1526  -1
    order_2_19  connected_order_arc_1528  -1
    order_2_19  connected_order_arc_1530  -1
    order_2_19  connected_order_arc_1532  -1
    order_2_19  connected_order_arc_1534  -1
    order_2_19  connected_order_arc_1536  -1
    order_2_19  connected_order_arc_1538  -1
    order_2_19  connected_order_arc_1540  -1
    order_2_19  connected_order_arc_1542  -1
    order_2_19  connected_order_arc_1559  1
    order_2_19  connected_order_arc_1580  1
    order_2_19  connected_order_arc_1601  1
    order_2_19  order_active_lb_1655  1
    order_2_19  order_active_ub_1656  1
    visit_2_20  out_degree_1659  -1
    visit_2_20  in_degree_1660  -1
    visit_2_20  order_active_lb_1661  -1
    visit_2_20  order_active_ub_1662  -11
    visit_2_20  service_visit_def_1663  -1
    order_2_20  connected_order_arc_1391  1
    order_2_20  connected_order_arc_1412  1
    order_2_20  connected_order_arc_1433  1
    order_2_20  connected_order_arc_1454  1
    order_2_20  connected_order_arc_1475  1
    order_2_20  connected_order_arc_1496  1
    order_2_20  connected_order_arc_1517  1
    order_2_20  connected_order_arc_1538  1
    order_2_20  connected_order_arc_1545  -1
    order_2_20  connected_order_arc_1547  -1
    order_2_20  connected_order_arc_1549  -1
    order_2_20  connected_order_arc_1551  -1
    order_2_20  connected_order_arc_1553  -1
    order_2_20  connected_order_arc_1555  -1
    order_2_20  connected_order_arc_1557  -1
    order_2_20  connected_order_arc_1559  -1
    order_2_20  connected_order_arc_1561  -1
    order_2_20  connected_order_arc_1563  -1
    order_2_20  connected_order_arc_1582  1
    order_2_20  connected_order_arc_1603  1
    order_2_20  order_active_lb_1661  1
    order_2_20  order_active_ub_1662  1
    visit_2_21  out_degree_1665  -1
    visit_2_21  in_degree_1666  -1
    visit_2_21  order_active_lb_1667  -1
    visit_2_21  order_active_ub_1668  -11
    visit_2_21  service_visit_def_1669  -1
    order_2_21  connected_order_arc_1393  1
    order_2_21  connected_order_arc_1414  1
    order_2_21  connected_order_arc_1435  1
    order_2_21  connected_order_arc_1456  1
    order_2_21  connected_order_arc_1477  1
    order_2_21  connected_order_arc_1498  1
    order_2_21  connected_order_arc_1519  1
    order_2_21  connected_order_arc_1540  1
    order_2_21  connected_order_arc_1561  1
    order_2_21  connected_order_arc_1566  -1
    order_2_21  connected_order_arc_1568  -1
    order_2_21  connected_order_arc_1570  -1
    order_2_21  connected_order_arc_1572  -1
    order_2_21  connected_order_arc_1574  -1
    order_2_21  connected_order_arc_1576  -1
    order_2_21  connected_order_arc_1578  -1
    order_2_21  connected_order_arc_1580  -1
    order_2_21  connected_order_arc_1582  -1
    order_2_21  connected_order_arc_1584  -1
    order_2_21  connected_order_arc_1605  1
    order_2_21  order_active_lb_1667  1
    order_2_21  order_active_ub_1668  1
    visit_2_22  out_degree_1671  -1
    visit_2_22  in_degree_1672  -1
    visit_2_22  order_active_lb_1673  -1
    visit_2_22  order_active_ub_1674  -11
    visit_2_22  service_visit_def_1675  -1
    order_2_22  connected_order_arc_1395  1
    order_2_22  connected_order_arc_1416  1
    order_2_22  connected_order_arc_1437  1
    order_2_22  connected_order_arc_1458  1
    order_2_22  connected_order_arc_1479  1
    order_2_22  connected_order_arc_1500  1
    order_2_22  connected_order_arc_1521  1
    order_2_22  connected_order_arc_1542  1
    order_2_22  connected_order_arc_1563  1
    order_2_22  connected_order_arc_1584  1
    order_2_22  connected_order_arc_1587  -1
    order_2_22  connected_order_arc_1589  -1
    order_2_22  connected_order_arc_1591  -1
    order_2_22  connected_order_arc_1593  -1
    order_2_22  connected_order_arc_1595  -1
    order_2_22  connected_order_arc_1597  -1
    order_2_22  connected_order_arc_1599  -1
    order_2_22  connected_order_arc_1601  -1
    order_2_22  connected_order_arc_1603  -1
    order_2_22  connected_order_arc_1605  -1
    order_2_22  order_active_lb_1673  1
    order_2_22  order_active_ub_1674  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_0  arc_capacity_1363  -30
    arc_2_0_0  depot_departure_or_bypass_1606  1
    arc_2_0_0  depot_return_or_bypass_1607  1
    MARKER    'MARKER'                 'INTEND'
    load_2_0_0  arc_capacity_1363  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_12  arc_capacity_1364  -30
    arc_2_0_12  depot_departure_or_bypass_1606  1
    arc_2_0_12  in_degree_1609  1
    arc_2_0_12  original_T_including_depot_unload_1679  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_12  arc_capacity_1364  1
    load_2_0_12  segment_load_conservation_1612  -1
    load_2_0_12  segment_prefix_lb_1613  1
    load_2_0_12  segment_prefix_ub_1614  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_13  arc_capacity_1365  -30
    arc_2_0_13  depot_departure_or_bypass_1606  1
    arc_2_0_13  in_degree_1616  1
    arc_2_0_13  original_T_including_depot_unload_1679  1.4567038050199781e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_13  arc_capacity_1365  1
    load_2_0_13  segment_load_conservation_1619  -1
    load_2_0_13  segment_prefix_lb_1620  1
    load_2_0_13  segment_prefix_ub_1621  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_14  arc_capacity_1366  -30
    arc_2_0_14  depot_departure_or_bypass_1606  1
    arc_2_0_14  in_degree_1623  1
    arc_2_0_14  original_T_including_depot_unload_1679  1.4501558573355060e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_14  arc_capacity_1366  1
    load_2_0_14  segment_load_conservation_1626  -1
    load_2_0_14  segment_prefix_lb_1627  1
    load_2_0_14  segment_prefix_ub_1628  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_15  arc_capacity_1367  -30
    arc_2_0_15  depot_departure_or_bypass_1606  1
    arc_2_0_15  in_degree_1630  1
    arc_2_0_15  original_T_including_depot_unload_1679  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_15  arc_capacity_1367  1
    load_2_0_15  free_load_conservation_1634  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_16  arc_capacity_1368  -30
    arc_2_0_16  depot_departure_or_bypass_1606  1
    arc_2_0_16  in_degree_1636  1
    arc_2_0_16  original_T_including_depot_unload_1679  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_16  arc_capacity_1368  1
    load_2_0_16  free_load_conservation_1640  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_17  arc_capacity_1369  -30
    arc_2_0_17  depot_departure_or_bypass_1606  1
    arc_2_0_17  in_degree_1642  1
    arc_2_0_17  original_T_including_depot_unload_1679  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_17  arc_capacity_1369  1
    load_2_0_17  free_load_conservation_1646  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_18  arc_capacity_1370  -30
    arc_2_0_18  depot_departure_or_bypass_1606  1
    arc_2_0_18  in_degree_1648  1
    arc_2_0_18  original_T_including_depot_unload_1679  5.4249700630778887e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_18  arc_capacity_1370  1
    load_2_0_18  free_load_conservation_1652  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_19  arc_capacity_1371  -30
    arc_2_0_19  depot_departure_or_bypass_1606  1
    arc_2_0_19  in_degree_1654  1
    arc_2_0_19  original_T_including_depot_unload_1679  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_19  arc_capacity_1371  1
    load_2_0_19  free_load_conservation_1658  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_20  arc_capacity_1372  -30
    arc_2_0_20  depot_departure_or_bypass_1606  1
    arc_2_0_20  in_degree_1660  1
    arc_2_0_20  original_T_including_depot_unload_1679  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_20  arc_capacity_1372  1
    load_2_0_20  free_load_conservation_1664  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_21  arc_capacity_1373  -30
    arc_2_0_21  depot_departure_or_bypass_1606  1
    arc_2_0_21  in_degree_1666  1
    arc_2_0_21  original_T_including_depot_unload_1679  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_21  arc_capacity_1373  1
    load_2_0_21  free_load_conservation_1670  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_22  arc_capacity_1374  -30
    arc_2_0_22  depot_departure_or_bypass_1606  1
    arc_2_0_22  in_degree_1672  1
    arc_2_0_22  original_T_including_depot_unload_1679  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_22  arc_capacity_1374  1
    load_2_0_22  free_load_conservation_1676  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_0  arc_capacity_1375  -30
    arc_2_12_0  depot_return_or_bypass_1607  1
    arc_2_12_0  out_degree_1608  1
    arc_2_12_0  original_T_including_depot_unload_1679  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_0  arc_capacity_1375  1
    load_2_12_0  segment_load_conservation_1612  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_13  arc_capacity_1376  -30
    arc_2_12_13  connected_order_arc_1377  -12
    arc_2_12_13  out_degree_1608  1
    arc_2_12_13  in_degree_1616  1
    arc_2_12_13  original_T_including_depot_unload_1679  1.2835993572680911e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_13  arc_capacity_1376  1
    load_2_12_13  segment_load_conservation_1612  1
    load_2_12_13  segment_load_conservation_1619  -1
    load_2_12_13  segment_prefix_lb_1620  1
    load_2_12_13  segment_prefix_ub_1621  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_14  arc_capacity_1378  -30
    arc_2_12_14  connected_order_arc_1379  -12
    arc_2_12_14  out_degree_1608  1
    arc_2_12_14  in_degree_1623  1
    arc_2_12_14  original_T_including_depot_unload_1679  1.2946770575314561e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_14  arc_capacity_1378  1
    load_2_12_14  segment_load_conservation_1612  1
    load_2_12_14  segment_load_conservation_1626  -1
    load_2_12_14  segment_prefix_lb_1627  1
    load_2_12_14  segment_prefix_ub_1628  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_15  arc_capacity_1380  -30
    arc_2_12_15  connected_order_arc_1381  -12
    arc_2_12_15  out_degree_1608  1
    arc_2_12_15  in_degree_1630  1
    arc_2_12_15  original_T_including_depot_unload_1679  4.5094949828949649e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_15  arc_capacity_1380  1
    load_2_12_15  segment_load_conservation_1612  1
    load_2_12_15  free_load_conservation_1634  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_16  arc_capacity_1382  -30
    arc_2_12_16  connected_order_arc_1383  -12
    arc_2_12_16  out_degree_1608  1
    arc_2_12_16  in_degree_1636  1
    arc_2_12_16  original_T_including_depot_unload_1679  3.8790073962518773e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_16  arc_capacity_1382  1
    load_2_12_16  segment_load_conservation_1612  1
    load_2_12_16  free_load_conservation_1640  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_17  arc_capacity_1384  -30
    arc_2_12_17  connected_order_arc_1385  -12
    arc_2_12_17  out_degree_1608  1
    arc_2_12_17  in_degree_1642  1
    arc_2_12_17  original_T_including_depot_unload_1679  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_17  arc_capacity_1384  1
    load_2_12_17  segment_load_conservation_1612  1
    load_2_12_17  free_load_conservation_1646  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_18  arc_capacity_1386  -30
    arc_2_12_18  connected_order_arc_1387  -12
    arc_2_12_18  out_degree_1608  1
    arc_2_12_18  in_degree_1648  1
    arc_2_12_18  original_T_including_depot_unload_1679  6.0309764600105484e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_18  arc_capacity_1386  1
    load_2_12_18  segment_load_conservation_1612  1
    load_2_12_18  free_load_conservation_1652  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_19  arc_capacity_1388  -30
    arc_2_12_19  connected_order_arc_1389  -12
    arc_2_12_19  out_degree_1608  1
    arc_2_12_19  in_degree_1654  1
    arc_2_12_19  original_T_including_depot_unload_1679  8.3486971116736720e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_19  arc_capacity_1388  1
    load_2_12_19  segment_load_conservation_1612  1
    load_2_12_19  free_load_conservation_1658  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_20  arc_capacity_1390  -30
    arc_2_12_20  connected_order_arc_1391  -12
    arc_2_12_20  out_degree_1608  1
    arc_2_12_20  in_degree_1660  1
    arc_2_12_20  original_T_including_depot_unload_1679  4.3618991857210159e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_20  arc_capacity_1390  1
    load_2_12_20  segment_load_conservation_1612  1
    load_2_12_20  free_load_conservation_1664  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_21  arc_capacity_1392  -30
    arc_2_12_21  connected_order_arc_1393  -12
    arc_2_12_21  out_degree_1608  1
    arc_2_12_21  in_degree_1666  1
    arc_2_12_21  original_T_including_depot_unload_1679  5.0315495126439691e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_21  arc_capacity_1392  1
    load_2_12_21  segment_load_conservation_1612  1
    load_2_12_21  free_load_conservation_1670  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_22  arc_capacity_1394  -30
    arc_2_12_22  connected_order_arc_1395  -12
    arc_2_12_22  out_degree_1608  1
    arc_2_12_22  in_degree_1672  1
    arc_2_12_22  original_T_including_depot_unload_1679  6.2886632383683013e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_22  arc_capacity_1394  1
    load_2_12_22  segment_load_conservation_1612  1
    load_2_12_22  free_load_conservation_1676  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_0  arc_capacity_1396  -30
    arc_2_13_0  depot_return_or_bypass_1607  1
    arc_2_13_0  out_degree_1615  1
    arc_2_13_0  original_T_including_depot_unload_1679  1.2506062209426416e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_0  arc_capacity_1396  1
    load_2_13_0  segment_load_conservation_1619  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_12  arc_capacity_1397  -30
    arc_2_13_12  connected_order_arc_1398  -12
    arc_2_13_12  in_degree_1609  1
    arc_2_13_12  out_degree_1615  1
    arc_2_13_12  original_T_including_depot_unload_1679  1.0138993437494995e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_12  arc_capacity_1397  1
    load_2_13_12  segment_load_conservation_1612  -1
    load_2_13_12  segment_prefix_lb_1613  1
    load_2_13_12  segment_prefix_ub_1614  1
    load_2_13_12  segment_load_conservation_1619  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_14  arc_capacity_1399  -30
    arc_2_13_14  connected_order_arc_1400  -12
    arc_2_13_14  out_degree_1615  1
    arc_2_13_14  in_degree_1623  1
    arc_2_13_14  original_T_including_depot_unload_1679  1.6502895430075375e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_14  arc_capacity_1399  1
    load_2_13_14  segment_load_conservation_1619  1
    load_2_13_14  segment_load_conservation_1626  -1
    load_2_13_14  segment_prefix_lb_1627  1
    load_2_13_14  segment_prefix_ub_1628  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_15  arc_capacity_1401  -30
    arc_2_13_15  connected_order_arc_1402  -12
    arc_2_13_15  out_degree_1615  1
    arc_2_13_15  in_degree_1630  1
    arc_2_13_15  original_T_including_depot_unload_1679  1.3812305438169078e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_15  arc_capacity_1401  1
    load_2_13_15  segment_load_conservation_1619  1
    load_2_13_15  free_load_conservation_1634  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_16  arc_capacity_1403  -30
    arc_2_13_16  connected_order_arc_1404  -12
    arc_2_13_16  out_degree_1615  1
    arc_2_13_16  in_degree_1636  1
    arc_2_13_16  original_T_including_depot_unload_1679  1.2335670980381785e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_16  arc_capacity_1403  1
    load_2_13_16  segment_load_conservation_1619  1
    load_2_13_16  free_load_conservation_1640  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_17  arc_capacity_1405  -30
    arc_2_13_17  connected_order_arc_1406  -12
    arc_2_13_17  out_degree_1615  1
    arc_2_13_17  in_degree_1642  1
    arc_2_13_17  original_T_including_depot_unload_1679  1.4255422670497167e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_17  arc_capacity_1405  1
    load_2_13_17  segment_load_conservation_1619  1
    load_2_13_17  free_load_conservation_1646  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_18  arc_capacity_1407  -30
    arc_2_13_18  connected_order_arc_1408  -12
    arc_2_13_18  out_degree_1615  1
    arc_2_13_18  in_degree_1648  1
    arc_2_13_18  original_T_including_depot_unload_1679  1.5552905028977075e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_18  arc_capacity_1407  1
    load_2_13_18  segment_load_conservation_1619  1
    load_2_13_18  free_load_conservation_1652  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_19  arc_capacity_1409  -30
    arc_2_13_19  connected_order_arc_1410  -12
    arc_2_13_19  out_degree_1615  1
    arc_2_13_19  in_degree_1654  1
    arc_2_13_19  original_T_including_depot_unload_1679  1.8362893893653638e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_19  arc_capacity_1409  1
    load_2_13_19  segment_load_conservation_1619  1
    load_2_13_19  free_load_conservation_1658  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_20  arc_capacity_1411  -30
    arc_2_13_20  connected_order_arc_1412  -12
    arc_2_13_20  out_degree_1615  1
    arc_2_13_20  in_degree_1660  1
    arc_2_13_20  original_T_including_depot_unload_1679  1.4479451378803963e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_20  arc_capacity_1411  1
    load_2_13_20  segment_load_conservation_1619  1
    load_2_13_20  free_load_conservation_1664  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_21  arc_capacity_1413  -30
    arc_2_13_21  connected_order_arc_1414  -12
    arc_2_13_21  out_degree_1615  1
    arc_2_13_21  in_degree_1666  1
    arc_2_13_21  original_T_including_depot_unload_1679  5.2472086221481925e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_21  arc_capacity_1413  1
    load_2_13_21  segment_load_conservation_1619  1
    load_2_13_21  free_load_conservation_1670  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_22  arc_capacity_1415  -30
    arc_2_13_22  connected_order_arc_1416  -12
    arc_2_13_22  out_degree_1615  1
    arc_2_13_22  in_degree_1672  1
    arc_2_13_22  original_T_including_depot_unload_1679  1.4001236472738528e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_22  arc_capacity_1415  1
    load_2_13_22  segment_load_conservation_1619  1
    load_2_13_22  free_load_conservation_1676  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_0  arc_capacity_1417  -30
    arc_2_14_0  depot_return_or_bypass_1607  1
    arc_2_14_0  out_degree_1622  1
    arc_2_14_0  original_T_including_depot_unload_1679  9.5330620720858735e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_0  arc_capacity_1417  1
    load_2_14_0  segment_load_conservation_1626  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_12  arc_capacity_1418  -30
    arc_2_14_12  connected_order_arc_1419  -12
    arc_2_14_12  in_degree_1609  1
    arc_2_14_12  out_degree_1622  1
    arc_2_14_12  original_T_including_depot_unload_1679  7.8947565022471792e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_12  arc_capacity_1418  1
    load_2_14_12  segment_load_conservation_1612  -1
    load_2_14_12  segment_prefix_lb_1613  1
    load_2_14_12  segment_prefix_ub_1614  1
    load_2_14_12  segment_load_conservation_1626  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_13  arc_capacity_1420  -30
    arc_2_14_13  connected_order_arc_1421  -12
    arc_2_14_13  in_degree_1616  1
    arc_2_14_13  out_degree_1622  1
    arc_2_14_13  original_T_including_depot_unload_1679  1.7571531345240103e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_13  arc_capacity_1420  1
    load_2_14_13  segment_load_conservation_1619  -1
    load_2_14_13  segment_prefix_lb_1620  1
    load_2_14_13  segment_prefix_ub_1621  1
    load_2_14_13  segment_load_conservation_1626  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_15  arc_capacity_1422  -30
    arc_2_14_15  connected_order_arc_1423  -12
    arc_2_14_15  out_degree_1622  1
    arc_2_14_15  in_degree_1630  1
    arc_2_14_15  original_T_including_depot_unload_1679  5.8292761965990132e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_15  arc_capacity_1422  1
    load_2_14_15  segment_load_conservation_1626  1
    load_2_14_15  free_load_conservation_1634  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_16  arc_capacity_1424  -30
    arc_2_14_16  connected_order_arc_1425  -12
    arc_2_14_16  out_degree_1622  1
    arc_2_14_16  in_degree_1636  1
    arc_2_14_16  original_T_including_depot_unload_1679  4.6772747357218117e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_16  arc_capacity_1424  1
    load_2_14_16  segment_load_conservation_1626  1
    load_2_14_16  free_load_conservation_1640  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_17  arc_capacity_1426  -30
    arc_2_14_17  connected_order_arc_1427  -12
    arc_2_14_17  out_degree_1622  1
    arc_2_14_17  in_degree_1642  1
    arc_2_14_17  original_T_including_depot_unload_1679  1.9462564869425171e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_17  arc_capacity_1426  1
    load_2_14_17  segment_load_conservation_1626  1
    load_2_14_17  free_load_conservation_1646  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_18  arc_capacity_1428  -30
    arc_2_14_18  connected_order_arc_1429  -12
    arc_2_14_18  out_degree_1622  1
    arc_2_14_18  in_degree_1648  1
    arc_2_14_18  original_T_including_depot_unload_1679  6.7711923781893620e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_18  arc_capacity_1428  1
    load_2_14_18  segment_load_conservation_1626  1
    load_2_14_18  free_load_conservation_1652  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_19  arc_capacity_1430  -30
    arc_2_14_19  connected_order_arc_1431  -12
    arc_2_14_19  out_degree_1622  1
    arc_2_14_19  in_degree_1654  1
    arc_2_14_19  original_T_including_depot_unload_1679  1.2674827380665711e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_19  arc_capacity_1430  1
    load_2_14_19  segment_load_conservation_1626  1
    load_2_14_19  free_load_conservation_1658  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_20  arc_capacity_1432  -30
    arc_2_14_20  connected_order_arc_1433  -12
    arc_2_14_20  out_degree_1622  1
    arc_2_14_20  in_degree_1660  1
    arc_2_14_20  original_T_including_depot_unload_1679  8.4968861461374138e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_20  arc_capacity_1432  1
    load_2_14_20  segment_load_conservation_1626  1
    load_2_14_20  free_load_conservation_1664  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_21  arc_capacity_1434  -30
    arc_2_14_21  connected_order_arc_1435  -12
    arc_2_14_21  out_degree_1622  1
    arc_2_14_21  in_degree_1666  1
    arc_2_14_21  original_T_including_depot_unload_1679  1.0105932041904148e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_21  arc_capacity_1434  1
    load_2_14_21  segment_load_conservation_1626  1
    load_2_14_21  free_load_conservation_1670  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_22  arc_capacity_1436  -30
    arc_2_14_22  connected_order_arc_1437  -12
    arc_2_14_22  out_degree_1622  1
    arc_2_14_22  in_degree_1672  1
    arc_2_14_22  original_T_including_depot_unload_1679  3.3469758905462760e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_22  arc_capacity_1436  1
    load_2_14_22  segment_load_conservation_1626  1
    load_2_14_22  free_load_conservation_1676  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_0  arc_capacity_1438  -30
    arc_2_15_0  depot_return_or_bypass_1607  1
    arc_2_15_0  out_degree_1629  1
    arc_2_15_0  original_T_including_depot_unload_1679  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_0  arc_capacity_1438  1
    load_2_15_0  free_load_conservation_1634  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_12  arc_capacity_1439  -30
    arc_2_15_12  connected_order_arc_1440  -12
    arc_2_15_12  in_degree_1609  1
    arc_2_15_12  out_degree_1629  1
    arc_2_15_12  original_T_including_depot_unload_1679  4.5094949828949649e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_12  arc_capacity_1439  1
    load_2_15_12  segment_load_conservation_1612  -1
    load_2_15_12  segment_prefix_lb_1613  1
    load_2_15_12  segment_prefix_ub_1614  1
    load_2_15_12  free_load_conservation_1634  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_13  arc_capacity_1441  -30
    arc_2_15_13  connected_order_arc_1442  -12
    arc_2_15_13  in_degree_1616  1
    arc_2_15_13  out_degree_1629  1
    arc_2_15_13  original_T_including_depot_unload_1679  1.7155529120526971e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_13  arc_capacity_1441  1
    load_2_15_13  segment_load_conservation_1619  -1
    load_2_15_13  segment_prefix_lb_1620  1
    load_2_15_13  segment_prefix_ub_1621  1
    load_2_15_13  free_load_conservation_1634  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_14  arc_capacity_1443  -30
    arc_2_15_14  connected_order_arc_1444  -12
    arc_2_15_14  in_degree_1623  1
    arc_2_15_14  out_degree_1629  1
    arc_2_15_14  original_T_including_depot_unload_1679  1.0428409649002836e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_14  arc_capacity_1443  1
    load_2_15_14  segment_load_conservation_1626  -1
    load_2_15_14  segment_prefix_lb_1627  1
    load_2_15_14  segment_prefix_ub_1628  1
    load_2_15_14  free_load_conservation_1634  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_16  arc_capacity_1445  -30
    arc_2_15_16  connected_order_arc_1446  -12
    arc_2_15_16  out_degree_1629  1
    arc_2_15_16  in_degree_1636  1
    arc_2_15_16  original_T_including_depot_unload_1679  1.7053268374267958e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_16  arc_capacity_1445  1
    load_2_15_16  free_load_conservation_1634  1
    load_2_15_16  free_load_conservation_1640  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_17  arc_capacity_1447  -30
    arc_2_15_17  connected_order_arc_1448  -12
    arc_2_15_17  out_degree_1629  1
    arc_2_15_17  in_degree_1642  1
    arc_2_15_17  original_T_including_depot_unload_1679  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_17  arc_capacity_1447  1
    load_2_15_17  free_load_conservation_1634  1
    load_2_15_17  free_load_conservation_1646  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_18  arc_capacity_1449  -30
    arc_2_15_18  connected_order_arc_1450  -12
    arc_2_15_18  out_degree_1629  1
    arc_2_15_18  in_degree_1648  1
    arc_2_15_18  original_T_including_depot_unload_1679  1.7461252424213140e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_18  arc_capacity_1449  1
    load_2_15_18  free_load_conservation_1634  1
    load_2_15_18  free_load_conservation_1652  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_19  arc_capacity_1451  -30
    arc_2_15_19  connected_order_arc_1452  -12
    arc_2_15_19  out_degree_1629  1
    arc_2_15_19  in_degree_1654  1
    arc_2_15_19  original_T_including_depot_unload_1679  6.8976718276177132e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_19  arc_capacity_1451  1
    load_2_15_19  free_load_conservation_1634  1
    load_2_15_19  free_load_conservation_1658  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_20  arc_capacity_1453  -30
    arc_2_15_20  connected_order_arc_1454  -12
    arc_2_15_20  out_degree_1629  1
    arc_2_15_20  in_degree_1660  1
    arc_2_15_20  original_T_including_depot_unload_1679  2.7078292664437623e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_20  arc_capacity_1453  1
    load_2_15_20  free_load_conservation_1634  1
    load_2_15_20  free_load_conservation_1664  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_21  arc_capacity_1455  -30
    arc_2_15_21  connected_order_arc_1456  -12
    arc_2_15_21  out_degree_1629  1
    arc_2_15_21  in_degree_1666  1
    arc_2_15_21  original_T_including_depot_unload_1679  9.1580557259044724e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_21  arc_capacity_1455  1
    load_2_15_21  free_load_conservation_1634  1
    load_2_15_21  free_load_conservation_1670  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_22  arc_capacity_1457  -30
    arc_2_15_22  connected_order_arc_1458  -12
    arc_2_15_22  out_degree_1629  1
    arc_2_15_22  in_degree_1672  1
    arc_2_15_22  original_T_including_depot_unload_1679  2.7570828838654035e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_22  arc_capacity_1457  1
    load_2_15_22  free_load_conservation_1634  1
    load_2_15_22  free_load_conservation_1676  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_0  arc_capacity_1459  -30
    arc_2_16_0  depot_return_or_bypass_1607  1
    arc_2_16_0  out_degree_1635  1
    arc_2_16_0  original_T_including_depot_unload_1679  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_0  arc_capacity_1459  1
    load_2_16_0  free_load_conservation_1640  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_12  arc_capacity_1460  -30
    arc_2_16_12  connected_order_arc_1461  -12
    arc_2_16_12  in_degree_1609  1
    arc_2_16_12  out_degree_1635  1
    arc_2_16_12  original_T_including_depot_unload_1679  3.8790073962518773e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_12  arc_capacity_1460  1
    load_2_16_12  segment_load_conservation_1612  -1
    load_2_16_12  segment_prefix_lb_1613  1
    load_2_16_12  segment_prefix_ub_1614  1
    load_2_16_12  free_load_conservation_1640  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_13  arc_capacity_1462  -30
    arc_2_16_13  connected_order_arc_1463  -12
    arc_2_16_13  in_degree_1616  1
    arc_2_16_13  out_degree_1635  1
    arc_2_16_13  original_T_including_depot_unload_1679  1.5960107821452696e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_13  arc_capacity_1462  1
    load_2_16_13  segment_load_conservation_1619  -1
    load_2_16_13  segment_prefix_lb_1620  1
    load_2_16_13  segment_prefix_ub_1621  1
    load_2_16_13  free_load_conservation_1640  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_14  arc_capacity_1464  -30
    arc_2_16_14  connected_order_arc_1465  -12
    arc_2_16_14  in_degree_1623  1
    arc_2_16_14  out_degree_1635  1
    arc_2_16_14  original_T_including_depot_unload_1679  9.5901863634429412e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_14  arc_capacity_1464  1
    load_2_16_14  segment_load_conservation_1626  -1
    load_2_16_14  segment_prefix_lb_1627  1
    load_2_16_14  segment_prefix_ub_1628  1
    load_2_16_14  free_load_conservation_1640  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_15  arc_capacity_1466  -30
    arc_2_16_15  connected_order_arc_1467  -12
    arc_2_16_15  in_degree_1630  1
    arc_2_16_15  out_degree_1635  1
    arc_2_16_15  original_T_including_depot_unload_1679  1.7053268374267958e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_15  arc_capacity_1466  1
    load_2_16_15  free_load_conservation_1634  -1
    load_2_16_15  free_load_conservation_1640  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_17  arc_capacity_1468  -30
    arc_2_16_17  connected_order_arc_1469  -12
    arc_2_16_17  out_degree_1635  1
    arc_2_16_17  in_degree_1642  1
    arc_2_16_17  original_T_including_depot_unload_1679  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_17  arc_capacity_1468  1
    load_2_16_17  free_load_conservation_1640  1
    load_2_16_17  free_load_conservation_1646  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_18  arc_capacity_1470  -30
    arc_2_16_18  connected_order_arc_1471  -12
    arc_2_16_18  out_degree_1635  1
    arc_2_16_18  in_degree_1648  1
    arc_2_16_18  original_T_including_depot_unload_1679  3.3800157717255917e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_18  arc_capacity_1470  1
    load_2_16_18  free_load_conservation_1640  1
    load_2_16_18  free_load_conservation_1652  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_19  arc_capacity_1472  -30
    arc_2_16_19  connected_order_arc_1473  -12
    arc_2_16_19  out_degree_1635  1
    arc_2_16_19  in_degree_1654  1
    arc_2_16_19  original_T_including_depot_unload_1679  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_19  arc_capacity_1472  1
    load_2_16_19  free_load_conservation_1640  1
    load_2_16_19  free_load_conservation_1658  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_20  arc_capacity_1474  -30
    arc_2_16_20  connected_order_arc_1475  -12
    arc_2_16_20  out_degree_1635  1
    arc_2_16_20  in_degree_1660  1
    arc_2_16_20  original_T_including_depot_unload_1679  3.9758967496529505e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_20  arc_capacity_1474  1
    load_2_16_20  free_load_conservation_1640  1
    load_2_16_20  free_load_conservation_1664  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_21  arc_capacity_1476  -30
    arc_2_16_21  connected_order_arc_1477  -12
    arc_2_16_21  out_degree_1635  1
    arc_2_16_21  in_degree_1666  1
    arc_2_16_21  original_T_including_depot_unload_1679  7.9403551275216375e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_21  arc_capacity_1476  1
    load_2_16_21  free_load_conservation_1640  1
    load_2_16_21  free_load_conservation_1670  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_22  arc_capacity_1478  -30
    arc_2_16_22  connected_order_arc_1479  -12
    arc_2_16_22  out_degree_1635  1
    arc_2_16_22  in_degree_1672  1
    arc_2_16_22  original_T_including_depot_unload_1679  2.4111148152767828e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_22  arc_capacity_1478  1
    load_2_16_22  free_load_conservation_1640  1
    load_2_16_22  free_load_conservation_1676  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_0  arc_capacity_1480  -30
    arc_2_17_0  depot_return_or_bypass_1607  1
    arc_2_17_0  out_degree_1641  1
    arc_2_17_0  original_T_including_depot_unload_1679  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_0  arc_capacity_1480  1
    load_2_17_0  free_load_conservation_1646  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_12  arc_capacity_1481  -30
    arc_2_17_12  connected_order_arc_1482  -12
    arc_2_17_12  in_degree_1609  1
    arc_2_17_12  out_degree_1641  1
    arc_2_17_12  original_T_including_depot_unload_1679  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_12  arc_capacity_1481  1
    load_2_17_12  segment_load_conservation_1612  -1
    load_2_17_12  segment_prefix_lb_1613  1
    load_2_17_12  segment_prefix_ub_1614  1
    load_2_17_12  free_load_conservation_1646  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_13  arc_capacity_1483  -30
    arc_2_17_13  connected_order_arc_1484  -12
    arc_2_17_13  in_degree_1616  1
    arc_2_17_13  out_degree_1641  1
    arc_2_17_13  original_T_including_depot_unload_1679  1.2027697073878232e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_13  arc_capacity_1483  1
    load_2_17_13  segment_load_conservation_1619  -1
    load_2_17_13  segment_prefix_lb_1620  1
    load_2_17_13  segment_prefix_ub_1621  1
    load_2_17_13  free_load_conservation_1646  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_14  arc_capacity_1485  -30
    arc_2_17_14  connected_order_arc_1486  -12
    arc_2_17_14  in_degree_1623  1
    arc_2_17_14  out_degree_1641  1
    arc_2_17_14  original_T_including_depot_unload_1679  2.4496137598598170e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_14  arc_capacity_1485  1
    load_2_17_14  segment_load_conservation_1626  -1
    load_2_17_14  segment_prefix_lb_1627  1
    load_2_17_14  segment_prefix_ub_1628  1
    load_2_17_14  free_load_conservation_1646  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_15  arc_capacity_1487  -30
    arc_2_17_15  connected_order_arc_1488  -12
    arc_2_17_15  in_degree_1630  1
    arc_2_17_15  out_degree_1641  1
    arc_2_17_15  original_T_including_depot_unload_1679  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_15  arc_capacity_1487  1
    load_2_17_15  free_load_conservation_1634  -1
    load_2_17_15  free_load_conservation_1646  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_16  arc_capacity_1489  -30
    arc_2_17_16  connected_order_arc_1490  -12
    arc_2_17_16  in_degree_1636  1
    arc_2_17_16  out_degree_1641  1
    arc_2_17_16  original_T_including_depot_unload_1679  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_16  arc_capacity_1489  1
    load_2_17_16  free_load_conservation_1640  -1
    load_2_17_16  free_load_conservation_1646  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_18  arc_capacity_1491  -30
    arc_2_17_18  connected_order_arc_1492  -12
    arc_2_17_18  out_degree_1641  1
    arc_2_17_18  in_degree_1648  1
    arc_2_17_18  original_T_including_depot_unload_1679  1.6231508478292610e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_18  arc_capacity_1491  1
    load_2_17_18  free_load_conservation_1646  1
    load_2_17_18  free_load_conservation_1652  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_19  arc_capacity_1493  -30
    arc_2_17_19  connected_order_arc_1494  -12
    arc_2_17_19  out_degree_1641  1
    arc_2_17_19  in_degree_1654  1
    arc_2_17_19  original_T_including_depot_unload_1679  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_19  arc_capacity_1493  1
    load_2_17_19  free_load_conservation_1646  1
    load_2_17_19  free_load_conservation_1658  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_20  arc_capacity_1495  -30
    arc_2_17_20  connected_order_arc_1496  -12
    arc_2_17_20  out_degree_1641  1
    arc_2_17_20  in_degree_1660  1
    arc_2_17_20  original_T_including_depot_unload_1679  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_20  arc_capacity_1495  1
    load_2_17_20  free_load_conservation_1646  1
    load_2_17_20  free_load_conservation_1664  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_21  arc_capacity_1497  -30
    arc_2_17_21  connected_order_arc_1498  -12
    arc_2_17_21  out_degree_1641  1
    arc_2_17_21  in_degree_1666  1
    arc_2_17_21  original_T_including_depot_unload_1679  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_21  arc_capacity_1497  1
    load_2_17_21  free_load_conservation_1646  1
    load_2_17_21  free_load_conservation_1670  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_22  arc_capacity_1499  -30
    arc_2_17_22  connected_order_arc_1500  -12
    arc_2_17_22  out_degree_1641  1
    arc_2_17_22  in_degree_1672  1
    arc_2_17_22  original_T_including_depot_unload_1679  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_22  arc_capacity_1499  1
    load_2_17_22  free_load_conservation_1646  1
    load_2_17_22  free_load_conservation_1676  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_0  arc_capacity_1501  -30
    arc_2_18_0  depot_return_or_bypass_1607  1
    arc_2_18_0  out_degree_1647  1
    arc_2_18_0  original_T_including_depot_unload_1679  5.4249700630778887e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_0  arc_capacity_1501  1
    load_2_18_0  free_load_conservation_1652  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_12  arc_capacity_1502  -30
    arc_2_18_12  connected_order_arc_1503  -12
    arc_2_18_12  in_degree_1609  1
    arc_2_18_12  out_degree_1647  1
    arc_2_18_12  original_T_including_depot_unload_1679  6.0309764600105484e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_12  arc_capacity_1502  1
    load_2_18_12  segment_load_conservation_1612  -1
    load_2_18_12  segment_prefix_lb_1613  1
    load_2_18_12  segment_prefix_ub_1614  1
    load_2_18_12  free_load_conservation_1652  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_13  arc_capacity_1504  -30
    arc_2_18_13  connected_order_arc_1505  -12
    arc_2_18_13  in_degree_1616  1
    arc_2_18_13  out_degree_1647  1
    arc_2_18_13  original_T_including_depot_unload_1679  1.8805180645589260e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_13  arc_capacity_1504  1
    load_2_18_13  segment_load_conservation_1619  -1
    load_2_18_13  segment_prefix_lb_1620  1
    load_2_18_13  segment_prefix_ub_1621  1
    load_2_18_13  free_load_conservation_1652  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_14  arc_capacity_1506  -30
    arc_2_18_14  connected_order_arc_1507  -12
    arc_2_18_14  in_degree_1623  1
    arc_2_18_14  out_degree_1647  1
    arc_2_18_14  original_T_including_depot_unload_1679  1.0875821153726588e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_14  arc_capacity_1506  1
    load_2_18_14  segment_load_conservation_1626  -1
    load_2_18_14  segment_prefix_lb_1627  1
    load_2_18_14  segment_prefix_ub_1628  1
    load_2_18_14  free_load_conservation_1652  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_15  arc_capacity_1508  -30
    arc_2_18_15  connected_order_arc_1509  -12
    arc_2_18_15  in_degree_1630  1
    arc_2_18_15  out_degree_1647  1
    arc_2_18_15  original_T_including_depot_unload_1679  1.7461252424213140e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_15  arc_capacity_1508  1
    load_2_18_15  free_load_conservation_1634  -1
    load_2_18_15  free_load_conservation_1652  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_16  arc_capacity_1510  -30
    arc_2_18_16  connected_order_arc_1511  -12
    arc_2_18_16  in_degree_1636  1
    arc_2_18_16  out_degree_1647  1
    arc_2_18_16  original_T_including_depot_unload_1679  3.3800157717255917e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_16  arc_capacity_1510  1
    load_2_18_16  free_load_conservation_1640  -1
    load_2_18_16  free_load_conservation_1652  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_17  arc_capacity_1512  -30
    arc_2_18_17  connected_order_arc_1513  -12
    arc_2_18_17  in_degree_1642  1
    arc_2_18_17  out_degree_1647  1
    arc_2_18_17  original_T_including_depot_unload_1679  1.6231508478292610e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_17  arc_capacity_1512  1
    load_2_18_17  free_load_conservation_1646  -1
    load_2_18_17  free_load_conservation_1652  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_19  arc_capacity_1514  -30
    arc_2_18_19  connected_order_arc_1515  -12
    arc_2_18_19  out_degree_1647  1
    arc_2_18_19  in_degree_1654  1
    arc_2_18_19  original_T_including_depot_unload_1679  603.649383070884
    MARKER    'MARKER'                 'INTEND'
    load_2_18_19  arc_capacity_1514  1
    load_2_18_19  free_load_conservation_1652  1
    load_2_18_19  free_load_conservation_1658  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_20  arc_capacity_1516  -30
    arc_2_18_20  connected_order_arc_1517  -12
    arc_2_18_20  out_degree_1647  1
    arc_2_18_20  in_degree_1660  1
    arc_2_18_20  original_T_including_depot_unload_1679  2.8529311190414518e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_20  arc_capacity_1516  1
    load_2_18_20  free_load_conservation_1652  1
    load_2_18_20  free_load_conservation_1664  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_21  arc_capacity_1518  -30
    arc_2_18_21  connected_order_arc_1519  -12
    arc_2_18_21  out_degree_1647  1
    arc_2_18_21  in_degree_1666  1
    arc_2_18_21  original_T_including_depot_unload_1679  1.0838347754693179e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_21  arc_capacity_1518  1
    load_2_18_21  free_load_conservation_1652  1
    load_2_18_21  free_load_conservation_1670  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_22  arc_capacity_1520  -30
    arc_2_18_22  connected_order_arc_1521  -12
    arc_2_18_22  out_degree_1647  1
    arc_2_18_22  in_degree_1672  1
    arc_2_18_22  original_T_including_depot_unload_1679  3.4289721135663990e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_22  arc_capacity_1520  1
    load_2_18_22  free_load_conservation_1652  1
    load_2_18_22  free_load_conservation_1676  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_0  arc_capacity_1522  -30
    arc_2_19_0  depot_return_or_bypass_1607  1
    arc_2_19_0  out_degree_1653  1
    arc_2_19_0  original_T_including_depot_unload_1679  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_0  arc_capacity_1522  1
    load_2_19_0  free_load_conservation_1658  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_12  arc_capacity_1523  -30
    arc_2_19_12  connected_order_arc_1524  -12
    arc_2_19_12  in_degree_1609  1
    arc_2_19_12  out_degree_1653  1
    arc_2_19_12  original_T_including_depot_unload_1679  8.3486971116736720e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_12  arc_capacity_1523  1
    load_2_19_12  segment_load_conservation_1612  -1
    load_2_19_12  segment_prefix_lb_1613  1
    load_2_19_12  segment_prefix_ub_1614  1
    load_2_19_12  free_load_conservation_1658  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_13  arc_capacity_1525  -30
    arc_2_19_13  connected_order_arc_1526  -12
    arc_2_19_13  in_degree_1616  1
    arc_2_19_13  out_degree_1653  1
    arc_2_19_13  original_T_including_depot_unload_1679  2.0178882184947397e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_13  arc_capacity_1525  1
    load_2_19_13  segment_load_conservation_1619  -1
    load_2_19_13  segment_prefix_lb_1620  1
    load_2_19_13  segment_prefix_ub_1621  1
    load_2_19_13  free_load_conservation_1658  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_14  arc_capacity_1527  -30
    arc_2_19_14  connected_order_arc_1528  -12
    arc_2_19_14  in_degree_1623  1
    arc_2_19_14  out_degree_1653  1
    arc_2_19_14  original_T_including_depot_unload_1679  1.6906177970488723e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_14  arc_capacity_1527  1
    load_2_19_14  segment_load_conservation_1626  -1
    load_2_19_14  segment_prefix_lb_1627  1
    load_2_19_14  segment_prefix_ub_1628  1
    load_2_19_14  free_load_conservation_1658  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_15  arc_capacity_1529  -30
    arc_2_19_15  connected_order_arc_1530  -12
    arc_2_19_15  in_degree_1630  1
    arc_2_19_15  out_degree_1653  1
    arc_2_19_15  original_T_including_depot_unload_1679  6.8976718276177132e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_15  arc_capacity_1529  1
    load_2_19_15  free_load_conservation_1634  -1
    load_2_19_15  free_load_conservation_1658  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_16  arc_capacity_1531  -30
    arc_2_19_16  connected_order_arc_1532  -12
    arc_2_19_16  in_degree_1636  1
    arc_2_19_16  out_degree_1653  1
    arc_2_19_16  original_T_including_depot_unload_1679  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_16  arc_capacity_1531  1
    load_2_19_16  free_load_conservation_1640  -1
    load_2_19_16  free_load_conservation_1658  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_17  arc_capacity_1533  -30
    arc_2_19_17  connected_order_arc_1534  -12
    arc_2_19_17  in_degree_1642  1
    arc_2_19_17  out_degree_1653  1
    arc_2_19_17  original_T_including_depot_unload_1679  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_17  arc_capacity_1533  1
    load_2_19_17  free_load_conservation_1646  -1
    load_2_19_17  free_load_conservation_1658  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_18  arc_capacity_1535  -30
    arc_2_19_18  connected_order_arc_1536  -12
    arc_2_19_18  in_degree_1648  1
    arc_2_19_18  out_degree_1653  1
    arc_2_19_18  original_T_including_depot_unload_1679  603.649383070884
    MARKER    'MARKER'                 'INTEND'
    load_2_19_18  arc_capacity_1535  1
    load_2_19_18  free_load_conservation_1652  -1
    load_2_19_18  free_load_conservation_1658  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_20  arc_capacity_1537  -30
    arc_2_19_20  connected_order_arc_1538  -12
    arc_2_19_20  out_degree_1653  1
    arc_2_19_20  in_degree_1660  1
    arc_2_19_20  original_T_including_depot_unload_1679  4.5128490093732506e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_20  arc_capacity_1537  1
    load_2_19_20  free_load_conservation_1658  1
    load_2_19_20  free_load_conservation_1664  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_21  arc_capacity_1539  -30
    arc_2_19_21  connected_order_arc_1540  -12
    arc_2_19_21  out_degree_1653  1
    arc_2_19_21  in_degree_1666  1
    arc_2_19_21  original_T_including_depot_unload_1679  1.3127274783157229e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_21  arc_capacity_1539  1
    load_2_19_21  free_load_conservation_1658  1
    load_2_19_21  free_load_conservation_1670  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_22  arc_capacity_1541  -30
    arc_2_19_22  connected_order_arc_1542  -12
    arc_2_19_22  out_degree_1653  1
    arc_2_19_22  in_degree_1672  1
    arc_2_19_22  original_T_including_depot_unload_1679  9.3962613467893414e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_22  arc_capacity_1541  1
    load_2_19_22  free_load_conservation_1658  1
    load_2_19_22  free_load_conservation_1676  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_0  arc_capacity_1543  -30
    arc_2_20_0  depot_return_or_bypass_1607  1
    arc_2_20_0  out_degree_1659  1
    arc_2_20_0  original_T_including_depot_unload_1679  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_0  arc_capacity_1543  1
    load_2_20_0  free_load_conservation_1664  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_12  arc_capacity_1544  -30
    arc_2_20_12  connected_order_arc_1545  -12
    arc_2_20_12  in_degree_1609  1
    arc_2_20_12  out_degree_1659  1
    arc_2_20_12  original_T_including_depot_unload_1679  4.3618991857210159e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_12  arc_capacity_1544  1
    load_2_20_12  segment_load_conservation_1612  -1
    load_2_20_12  segment_prefix_lb_1613  1
    load_2_20_12  segment_prefix_ub_1614  1
    load_2_20_12  free_load_conservation_1664  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_13  arc_capacity_1546  -30
    arc_2_20_13  connected_order_arc_1547  -12
    arc_2_20_13  in_degree_1616  1
    arc_2_20_13  out_degree_1659  1
    arc_2_20_13  original_T_including_depot_unload_1679  1.7069358358556344e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_13  arc_capacity_1546  1
    load_2_20_13  segment_load_conservation_1619  -1
    load_2_20_13  segment_prefix_lb_1620  1
    load_2_20_13  segment_prefix_ub_1621  1
    load_2_20_13  free_load_conservation_1664  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_14  arc_capacity_1548  -30
    arc_2_20_14  connected_order_arc_1549  -12
    arc_2_20_14  in_degree_1623  1
    arc_2_20_14  out_degree_1659  1
    arc_2_20_14  original_T_including_depot_unload_1679  1.3132316623300278e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_14  arc_capacity_1548  1
    load_2_20_14  segment_load_conservation_1626  -1
    load_2_20_14  segment_prefix_lb_1627  1
    load_2_20_14  segment_prefix_ub_1628  1
    load_2_20_14  free_load_conservation_1664  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_15  arc_capacity_1550  -30
    arc_2_20_15  connected_order_arc_1551  -12
    arc_2_20_15  in_degree_1630  1
    arc_2_20_15  out_degree_1659  1
    arc_2_20_15  original_T_including_depot_unload_1679  2.7078292664437623e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_15  arc_capacity_1550  1
    load_2_20_15  free_load_conservation_1634  -1
    load_2_20_15  free_load_conservation_1664  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_16  arc_capacity_1552  -30
    arc_2_20_16  connected_order_arc_1553  -12
    arc_2_20_16  in_degree_1636  1
    arc_2_20_16  out_degree_1659  1
    arc_2_20_16  original_T_including_depot_unload_1679  3.9758967496529505e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_16  arc_capacity_1552  1
    load_2_20_16  free_load_conservation_1640  -1
    load_2_20_16  free_load_conservation_1664  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_17  arc_capacity_1554  -30
    arc_2_20_17  connected_order_arc_1555  -12
    arc_2_20_17  in_degree_1642  1
    arc_2_20_17  out_degree_1659  1
    arc_2_20_17  original_T_including_depot_unload_1679  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_17  arc_capacity_1554  1
    load_2_20_17  free_load_conservation_1646  -1
    load_2_20_17  free_load_conservation_1664  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_18  arc_capacity_1556  -30
    arc_2_20_18  connected_order_arc_1557  -12
    arc_2_20_18  in_degree_1648  1
    arc_2_20_18  out_degree_1659  1
    arc_2_20_18  original_T_including_depot_unload_1679  2.8529311190414518e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_18  arc_capacity_1556  1
    load_2_20_18  free_load_conservation_1652  -1
    load_2_20_18  free_load_conservation_1664  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_19  arc_capacity_1558  -30
    arc_2_20_19  connected_order_arc_1559  -12
    arc_2_20_19  in_degree_1654  1
    arc_2_20_19  out_degree_1659  1
    arc_2_20_19  original_T_including_depot_unload_1679  4.5128490093732506e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_19  arc_capacity_1558  1
    load_2_20_19  free_load_conservation_1658  -1
    load_2_20_19  free_load_conservation_1664  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_21  arc_capacity_1560  -30
    arc_2_20_21  connected_order_arc_1561  -12
    arc_2_20_21  out_degree_1659  1
    arc_2_20_21  in_degree_1666  1
    arc_2_20_21  original_T_including_depot_unload_1679  9.3905252655669165e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_21  arc_capacity_1560  1
    load_2_20_21  free_load_conservation_1664  1
    load_2_20_21  free_load_conservation_1670  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_22  arc_capacity_1562  -30
    arc_2_20_22  connected_order_arc_1563  -12
    arc_2_20_22  out_degree_1659  1
    arc_2_20_22  in_degree_1672  1
    arc_2_20_22  original_T_including_depot_unload_1679  545.439458844012
    MARKER    'MARKER'                 'INTEND'
    load_2_20_22  arc_capacity_1562  1
    load_2_20_22  free_load_conservation_1664  1
    load_2_20_22  free_load_conservation_1676  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_0  arc_capacity_1564  -30
    arc_2_21_0  depot_return_or_bypass_1607  1
    arc_2_21_0  out_degree_1665  1
    arc_2_21_0  original_T_including_depot_unload_1679  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_0  arc_capacity_1564  1
    load_2_21_0  free_load_conservation_1670  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_12  arc_capacity_1565  -30
    arc_2_21_12  connected_order_arc_1566  -12
    arc_2_21_12  in_degree_1609  1
    arc_2_21_12  out_degree_1665  1
    arc_2_21_12  original_T_including_depot_unload_1679  5.0315495126439691e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_12  arc_capacity_1565  1
    load_2_21_12  segment_load_conservation_1612  -1
    load_2_21_12  segment_prefix_lb_1613  1
    load_2_21_12  segment_prefix_ub_1614  1
    load_2_21_12  free_load_conservation_1670  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_13  arc_capacity_1567  -30
    arc_2_21_13  connected_order_arc_1568  -12
    arc_2_21_13  in_degree_1616  1
    arc_2_21_13  out_degree_1665  1
    arc_2_21_13  original_T_including_depot_unload_1679  8.0219422833177862e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_13  arc_capacity_1567  1
    load_2_21_13  segment_load_conservation_1619  -1
    load_2_21_13  segment_prefix_lb_1620  1
    load_2_21_13  segment_prefix_ub_1621  1
    load_2_21_13  free_load_conservation_1670  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_14  arc_capacity_1569  -30
    arc_2_21_14  connected_order_arc_1570  -12
    arc_2_21_14  in_degree_1623  1
    arc_2_21_14  out_degree_1665  1
    arc_2_21_14  original_T_including_depot_unload_1679  1.4688211749637876e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_14  arc_capacity_1569  1
    load_2_21_14  segment_load_conservation_1626  -1
    load_2_21_14  segment_prefix_lb_1627  1
    load_2_21_14  segment_prefix_ub_1628  1
    load_2_21_14  free_load_conservation_1670  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_15  arc_capacity_1571  -30
    arc_2_21_15  connected_order_arc_1572  -12
    arc_2_21_15  in_degree_1630  1
    arc_2_21_15  out_degree_1665  1
    arc_2_21_15  original_T_including_depot_unload_1679  9.1580557259044724e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_15  arc_capacity_1571  1
    load_2_21_15  free_load_conservation_1634  -1
    load_2_21_15  free_load_conservation_1670  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_16  arc_capacity_1573  -30
    arc_2_21_16  connected_order_arc_1574  -12
    arc_2_21_16  in_degree_1636  1
    arc_2_21_16  out_degree_1665  1
    arc_2_21_16  original_T_including_depot_unload_1679  7.9403551275216375e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_16  arc_capacity_1573  1
    load_2_21_16  free_load_conservation_1640  -1
    load_2_21_16  free_load_conservation_1670  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_17  arc_capacity_1575  -30
    arc_2_21_17  connected_order_arc_1576  -12
    arc_2_21_17  in_degree_1642  1
    arc_2_21_17  out_degree_1665  1
    arc_2_21_17  original_T_including_depot_unload_1679  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_17  arc_capacity_1575  1
    load_2_21_17  free_load_conservation_1646  -1
    load_2_21_17  free_load_conservation_1670  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_18  arc_capacity_1577  -30
    arc_2_21_18  connected_order_arc_1578  -12
    arc_2_21_18  in_degree_1648  1
    arc_2_21_18  out_degree_1665  1
    arc_2_21_18  original_T_including_depot_unload_1679  1.0838347754693179e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_18  arc_capacity_1577  1
    load_2_21_18  free_load_conservation_1652  -1
    load_2_21_18  free_load_conservation_1670  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_19  arc_capacity_1579  -30
    arc_2_21_19  connected_order_arc_1580  -12
    arc_2_21_19  in_degree_1654  1
    arc_2_21_19  out_degree_1665  1
    arc_2_21_19  original_T_including_depot_unload_1679  1.3127274783157229e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_19  arc_capacity_1579  1
    load_2_21_19  free_load_conservation_1658  -1
    load_2_21_19  free_load_conservation_1670  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_20  arc_capacity_1581  -30
    arc_2_21_20  connected_order_arc_1582  -12
    arc_2_21_20  in_degree_1660  1
    arc_2_21_20  out_degree_1665  1
    arc_2_21_20  original_T_including_depot_unload_1679  9.3905252655669165e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_20  arc_capacity_1581  1
    load_2_21_20  free_load_conservation_1664  -1
    load_2_21_20  free_load_conservation_1670  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_22  arc_capacity_1583  -30
    arc_2_21_22  connected_order_arc_1584  -12
    arc_2_21_22  out_degree_1665  1
    arc_2_21_22  in_degree_1672  1
    arc_2_21_22  original_T_including_depot_unload_1679  1.0038065985492663e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_22  arc_capacity_1583  1
    load_2_21_22  free_load_conservation_1670  1
    load_2_21_22  free_load_conservation_1676  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_0  arc_capacity_1585  -30
    arc_2_22_0  depot_return_or_bypass_1607  1
    arc_2_22_0  out_degree_1671  1
    arc_2_22_0  original_T_including_depot_unload_1679  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_0  arc_capacity_1585  1
    load_2_22_0  free_load_conservation_1676  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_12  arc_capacity_1586  -30
    arc_2_22_12  connected_order_arc_1587  -12
    arc_2_22_12  in_degree_1609  1
    arc_2_22_12  out_degree_1671  1
    arc_2_22_12  original_T_including_depot_unload_1679  6.2886632383683013e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_12  arc_capacity_1586  1
    load_2_22_12  segment_load_conservation_1612  -1
    load_2_22_12  segment_prefix_lb_1613  1
    load_2_22_12  segment_prefix_ub_1614  1
    load_2_22_12  free_load_conservation_1676  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_13  arc_capacity_1588  -30
    arc_2_22_13  connected_order_arc_1589  -12
    arc_2_22_13  in_degree_1616  1
    arc_2_22_13  out_degree_1671  1
    arc_2_22_13  original_T_including_depot_unload_1679  1.7998334548300843e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_22_13  arc_capacity_1588  1
    load_2_22_13  segment_load_conservation_1619  -1
    load_2_22_13  segment_prefix_lb_1620  1
    load_2_22_13  segment_prefix_ub_1621  1
    load_2_22_13  free_load_conservation_1676  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_14  arc_capacity_1590  -30
    arc_2_22_14  connected_order_arc_1591  -12
    arc_2_22_14  in_degree_1623  1
    arc_2_22_14  out_degree_1671  1
    arc_2_22_14  original_T_including_depot_unload_1679  7.6789230776331749e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_14  arc_capacity_1590  1
    load_2_22_14  segment_load_conservation_1626  -1
    load_2_22_14  segment_prefix_lb_1627  1
    load_2_22_14  segment_prefix_ub_1628  1
    load_2_22_14  free_load_conservation_1676  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_15  arc_capacity_1592  -30
    arc_2_22_15  connected_order_arc_1593  -12
    arc_2_22_15  in_degree_1630  1
    arc_2_22_15  out_degree_1671  1
    arc_2_22_15  original_T_including_depot_unload_1679  2.7570828838654035e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_15  arc_capacity_1592  1
    load_2_22_15  free_load_conservation_1634  -1
    load_2_22_15  free_load_conservation_1676  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_16  arc_capacity_1594  -30
    arc_2_22_16  connected_order_arc_1595  -12
    arc_2_22_16  in_degree_1636  1
    arc_2_22_16  out_degree_1671  1
    arc_2_22_16  original_T_including_depot_unload_1679  2.4111148152767828e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_16  arc_capacity_1594  1
    load_2_22_16  free_load_conservation_1640  -1
    load_2_22_16  free_load_conservation_1676  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_17  arc_capacity_1596  -30
    arc_2_22_17  connected_order_arc_1597  -12
    arc_2_22_17  in_degree_1642  1
    arc_2_22_17  out_degree_1671  1
    arc_2_22_17  original_T_including_depot_unload_1679  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_22_17  arc_capacity_1596  1
    load_2_22_17  free_load_conservation_1646  -1
    load_2_22_17  free_load_conservation_1676  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_18  arc_capacity_1598  -30
    arc_2_22_18  connected_order_arc_1599  -12
    arc_2_22_18  in_degree_1648  1
    arc_2_22_18  out_degree_1671  1
    arc_2_22_18  original_T_including_depot_unload_1679  3.4289721135663990e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_18  arc_capacity_1598  1
    load_2_22_18  free_load_conservation_1652  -1
    load_2_22_18  free_load_conservation_1676  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_19  arc_capacity_1600  -30
    arc_2_22_19  connected_order_arc_1601  -12
    arc_2_22_19  in_degree_1654  1
    arc_2_22_19  out_degree_1671  1
    arc_2_22_19  original_T_including_depot_unload_1679  9.3962613467893414e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_19  arc_capacity_1600  1
    load_2_22_19  free_load_conservation_1658  -1
    load_2_22_19  free_load_conservation_1676  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_20  arc_capacity_1602  -30
    arc_2_22_20  connected_order_arc_1603  -12
    arc_2_22_20  in_degree_1660  1
    arc_2_22_20  out_degree_1671  1
    arc_2_22_20  original_T_including_depot_unload_1679  545.439458844012
    MARKER    'MARKER'                 'INTEND'
    load_2_22_20  arc_capacity_1602  1
    load_2_22_20  free_load_conservation_1664  -1
    load_2_22_20  free_load_conservation_1676  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_21  arc_capacity_1604  -30
    arc_2_22_21  connected_order_arc_1605  -12
    arc_2_22_21  in_degree_1666  1
    arc_2_22_21  out_degree_1671  1
    arc_2_22_21  original_T_including_depot_unload_1679  1.0038065985492663e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_22_21  arc_capacity_1604  1
    load_2_22_21  free_load_conservation_1670  -1
    load_2_22_21  free_load_conservation_1676  1
RHS
    RHS1      OBJ       -0.55575
    RHS1      onehot_1_40  1
    RHS1      onehot_2_75  1
    RHS1      onehot_31_104  1
    RHS1      onehot_3_143  1
    RHS1      onehot_16_172  1
    RHS1      onehot_4_207  1
    RHS1      onehot_19_228  1
    RHS1      onehot_5_265  1
    RHS1      stock_ub_269  41
    RHS1      parent_nonstrict_scope_270  3.2148177341474815e-01
    RHS1      normalization_327  1
    RHS1      connected_order_arc_460  -14
    RHS1      connected_order_arc_462  -14
    RHS1      connected_order_arc_464  -14
    RHS1      connected_order_arc_466  -14
    RHS1      connected_order_arc_468  -14
    RHS1      connected_order_arc_470  -14
    RHS1      connected_order_arc_472  -14
    RHS1      connected_order_arc_474  -14
    RHS1      connected_order_arc_476  -14
    RHS1      connected_order_arc_478  -14
    RHS1      connected_order_arc_480  -14
    RHS1      connected_order_arc_482  -14
    RHS1      connected_order_arc_484  -14
    RHS1      connected_order_arc_487  -14
    RHS1      connected_order_arc_489  -14
    RHS1      connected_order_arc_491  -14
    RHS1      connected_order_arc_493  -14
    RHS1      connected_order_arc_495  -14
    RHS1      connected_order_arc_497  -14
    RHS1      connected_order_arc_499  -14
    RHS1      connected_order_arc_501  -14
    RHS1      connected_order_arc_503  -14
    RHS1      connected_order_arc_505  -14
    RHS1      connected_order_arc_507  -14
    RHS1      connected_order_arc_509  -14
    RHS1      connected_order_arc_511  -14
    RHS1      connected_order_arc_514  -14
    RHS1      connected_order_arc_516  -14
    RHS1      connected_order_arc_518  -14
    RHS1      connected_order_arc_520  -14
    RHS1      connected_order_arc_522  -14
    RHS1      connected_order_arc_524  -14
    RHS1      connected_order_arc_526  -14
    RHS1      connected_order_arc_528  -14
    RHS1      connected_order_arc_530  -14
    RHS1      connected_order_arc_532  -14
    RHS1      connected_order_arc_534  -14
    RHS1      connected_order_arc_536  -14
    RHS1      connected_order_arc_538  -14
    RHS1      connected_order_arc_541  -14
    RHS1      connected_order_arc_543  -14
    RHS1      connected_order_arc_545  -14
    RHS1      connected_order_arc_547  -14
    RHS1      connected_order_arc_549  -14
    RHS1      connected_order_arc_551  -14
    RHS1      connected_order_arc_553  -14
    RHS1      connected_order_arc_555  -14
    RHS1      connected_order_arc_557  -14
    RHS1      connected_order_arc_559  -14
    RHS1      connected_order_arc_561  -14
    RHS1      connected_order_arc_563  -14
    RHS1      connected_order_arc_565  -14
    RHS1      connected_order_arc_568  -14
    RHS1      connected_order_arc_570  -14
    RHS1      connected_order_arc_572  -14
    RHS1      connected_order_arc_574  -14
    RHS1      connected_order_arc_576  -14
    RHS1      connected_order_arc_578  -14
    RHS1      connected_order_arc_580  -14
    RHS1      connected_order_arc_582  -14
    RHS1      connected_order_arc_584  -14
    RHS1      connected_order_arc_586  -14
    RHS1      connected_order_arc_588  -14
    RHS1      connected_order_arc_590  -14
    RHS1      connected_order_arc_592  -14
    RHS1      connected_order_arc_595  -14
    RHS1      connected_order_arc_597  -14
    RHS1      connected_order_arc_599  -14
    RHS1      connected_order_arc_601  -14
    RHS1      connected_order_arc_603  -14
    RHS1      connected_order_arc_605  -14
    RHS1      connected_order_arc_607  -14
    RHS1      connected_order_arc_609  -14
    RHS1      connected_order_arc_611  -14
    RHS1      connected_order_arc_613  -14
    RHS1      connected_order_arc_615  -14
    RHS1      connected_order_arc_617  -14
    RHS1      connected_order_arc_619  -14
    RHS1      connected_order_arc_622  -14
    RHS1      connected_order_arc_624  -14
    RHS1      connected_order_arc_626  -14
    RHS1      connected_order_arc_628  -14
    RHS1      connected_order_arc_630  -14
    RHS1      connected_order_arc_632  -14
    RHS1      connected_order_arc_634  -14
    RHS1      connected_order_arc_636  -14
    RHS1      connected_order_arc_638  -14
    RHS1      connected_order_arc_640  -14
    RHS1      connected_order_arc_642  -14
    RHS1      connected_order_arc_644  -14
    RHS1      connected_order_arc_646  -14
    RHS1      connected_order_arc_649  -14
    RHS1      connected_order_arc_651  -14
    RHS1      connected_order_arc_653  -14
    RHS1      connected_order_arc_655  -14
    RHS1      connected_order_arc_657  -14
    RHS1      connected_order_arc_659  -14
    RHS1      connected_order_arc_661  -14
    RHS1      connected_order_arc_663  -14
    RHS1      connected_order_arc_665  -14
    RHS1      connected_order_arc_667  -14
    RHS1      connected_order_arc_669  -14
    RHS1      connected_order_arc_671  -14
    RHS1      connected_order_arc_673  -14
    RHS1      connected_order_arc_676  -14
    RHS1      connected_order_arc_678  -14
    RHS1      connected_order_arc_680  -14
    RHS1      connected_order_arc_682  -14
    RHS1      connected_order_arc_684  -14
    RHS1      connected_order_arc_686  -14
    RHS1      connected_order_arc_688  -14
    RHS1      connected_order_arc_690  -14
    RHS1      connected_order_arc_692  -14
    RHS1      connected_order_arc_694  -14
    RHS1      connected_order_arc_696  -14
    RHS1      connected_order_arc_698  -14
    RHS1      connected_order_arc_700  -14
    RHS1      connected_order_arc_703  -14
    RHS1      connected_order_arc_705  -14
    RHS1      connected_order_arc_707  -14
    RHS1      connected_order_arc_709  -14
    RHS1      connected_order_arc_711  -14
    RHS1      connected_order_arc_713  -14
    RHS1      connected_order_arc_715  -14
    RHS1      connected_order_arc_717  -14
    RHS1      connected_order_arc_719  -14
    RHS1      connected_order_arc_721  -14
    RHS1      connected_order_arc_723  -14
    RHS1      connected_order_arc_725  -14
    RHS1      connected_order_arc_727  -14
    RHS1      connected_order_arc_730  -14
    RHS1      connected_order_arc_732  -14
    RHS1      connected_order_arc_734  -14
    RHS1      connected_order_arc_736  -14
    RHS1      connected_order_arc_738  -14
    RHS1      connected_order_arc_740  -14
    RHS1      connected_order_arc_742  -14
    RHS1      connected_order_arc_744  -14
    RHS1      connected_order_arc_746  -14
    RHS1      connected_order_arc_748  -14
    RHS1      connected_order_arc_750  -14
    RHS1      connected_order_arc_752  -14
    RHS1      connected_order_arc_754  -14
    RHS1      connected_order_arc_757  -14
    RHS1      connected_order_arc_759  -14
    RHS1      connected_order_arc_761  -14
    RHS1      connected_order_arc_763  -14
    RHS1      connected_order_arc_765  -14
    RHS1      connected_order_arc_767  -14
    RHS1      connected_order_arc_769  -14
    RHS1      connected_order_arc_771  -14
    RHS1      connected_order_arc_773  -14
    RHS1      connected_order_arc_775  -14
    RHS1      connected_order_arc_777  -14
    RHS1      connected_order_arc_779  -14
    RHS1      connected_order_arc_781  -14
    RHS1      connected_order_arc_784  -14
    RHS1      connected_order_arc_786  -14
    RHS1      connected_order_arc_788  -14
    RHS1      connected_order_arc_790  -14
    RHS1      connected_order_arc_792  -14
    RHS1      connected_order_arc_794  -14
    RHS1      connected_order_arc_796  -14
    RHS1      connected_order_arc_798  -14
    RHS1      connected_order_arc_800  -14
    RHS1      connected_order_arc_802  -14
    RHS1      connected_order_arc_804  -14
    RHS1      connected_order_arc_806  -14
    RHS1      connected_order_arc_808  -14
    RHS1      connected_order_arc_811  -14
    RHS1      connected_order_arc_813  -14
    RHS1      connected_order_arc_815  -14
    RHS1      connected_order_arc_817  -14
    RHS1      connected_order_arc_819  -14
    RHS1      connected_order_arc_821  -14
    RHS1      connected_order_arc_823  -14
    RHS1      connected_order_arc_825  -14
    RHS1      connected_order_arc_827  -14
    RHS1      connected_order_arc_829  -14
    RHS1      connected_order_arc_831  -14
    RHS1      connected_order_arc_833  -14
    RHS1      connected_order_arc_835  -14
    RHS1      depot_departure_or_bypass_836  1
    RHS1      depot_return_or_bypass_837  1
    RHS1      segment_load_conservation_842  5
    RHS1      segment_prefix_ub_844  15
    RHS1      segment_load_conservation_849  4
    RHS1      segment_prefix_ub_851  16
    RHS1      segment_load_conservation_856  -2
    RHS1      segment_prefix_lb_857  2
    RHS1      segment_prefix_ub_858  20
    RHS1      segment_load_conservation_863  5
    RHS1      segment_prefix_ub_865  15
    RHS1      segment_load_conservation_870  -1
    RHS1      segment_prefix_lb_871  1
    RHS1      segment_prefix_ub_872  15
    RHS1      segment_load_conservation_877  -6
    RHS1      segment_prefix_lb_878  6
    RHS1      segment_prefix_ub_879  20
    RHS1      fixed_segment_relative_order_928  1
    RHS1      fixed_segment_relative_order_929  1
    RHS1      fixed_segment_relative_order_930  1
    RHS1      fixed_segment_relative_order_931  1
    RHS1      fixed_segment_relative_order_932  1
    RHS1      original_T_including_depot_unload_933  4.7051870548852967e+03
    RHS1      connected_order_arc_950  -13
    RHS1      connected_order_arc_952  -13
    RHS1      connected_order_arc_954  -13
    RHS1      connected_order_arc_956  -13
    RHS1      connected_order_arc_958  -13
    RHS1      connected_order_arc_960  -13
    RHS1      connected_order_arc_962  -13
    RHS1      connected_order_arc_964  -13
    RHS1      connected_order_arc_966  -13
    RHS1      connected_order_arc_968  -13
    RHS1      connected_order_arc_970  -13
    RHS1      connected_order_arc_972  -13
    RHS1      connected_order_arc_975  -13
    RHS1      connected_order_arc_977  -13
    RHS1      connected_order_arc_979  -13
    RHS1      connected_order_arc_981  -13
    RHS1      connected_order_arc_983  -13
    RHS1      connected_order_arc_985  -13
    RHS1      connected_order_arc_987  -13
    RHS1      connected_order_arc_989  -13
    RHS1      connected_order_arc_991  -13
    RHS1      connected_order_arc_993  -13
    RHS1      connected_order_arc_995  -13
    RHS1      connected_order_arc_997  -13
    RHS1      connected_order_arc_1000  -13
    RHS1      connected_order_arc_1002  -13
    RHS1      connected_order_arc_1004  -13
    RHS1      connected_order_arc_1006  -13
    RHS1      connected_order_arc_1008  -13
    RHS1      connected_order_arc_1010  -13
    RHS1      connected_order_arc_1012  -13
    RHS1      connected_order_arc_1014  -13
    RHS1      connected_order_arc_1016  -13
    RHS1      connected_order_arc_1018  -13
    RHS1      connected_order_arc_1020  -13
    RHS1      connected_order_arc_1022  -13
    RHS1      connected_order_arc_1025  -13
    RHS1      connected_order_arc_1027  -13
    RHS1      connected_order_arc_1029  -13
    RHS1      connected_order_arc_1031  -13
    RHS1      connected_order_arc_1033  -13
    RHS1      connected_order_arc_1035  -13
    RHS1      connected_order_arc_1037  -13
    RHS1      connected_order_arc_1039  -13
    RHS1      connected_order_arc_1041  -13
    RHS1      connected_order_arc_1043  -13
    RHS1      connected_order_arc_1045  -13
    RHS1      connected_order_arc_1047  -13
    RHS1      connected_order_arc_1050  -13
    RHS1      connected_order_arc_1052  -13
    RHS1      connected_order_arc_1054  -13
    RHS1      connected_order_arc_1056  -13
    RHS1      connected_order_arc_1058  -13
    RHS1      connected_order_arc_1060  -13
    RHS1      connected_order_arc_1062  -13
    RHS1      connected_order_arc_1064  -13
    RHS1      connected_order_arc_1066  -13
    RHS1      connected_order_arc_1068  -13
    RHS1      connected_order_arc_1070  -13
    RHS1      connected_order_arc_1072  -13
    RHS1      connected_order_arc_1075  -13
    RHS1      connected_order_arc_1077  -13
    RHS1      connected_order_arc_1079  -13
    RHS1      connected_order_arc_1081  -13
    RHS1      connected_order_arc_1083  -13
    RHS1      connected_order_arc_1085  -13
    RHS1      connected_order_arc_1087  -13
    RHS1      connected_order_arc_1089  -13
    RHS1      connected_order_arc_1091  -13
    RHS1      connected_order_arc_1093  -13
    RHS1      connected_order_arc_1095  -13
    RHS1      connected_order_arc_1097  -13
    RHS1      connected_order_arc_1100  -13
    RHS1      connected_order_arc_1102  -13
    RHS1      connected_order_arc_1104  -13
    RHS1      connected_order_arc_1106  -13
    RHS1      connected_order_arc_1108  -13
    RHS1      connected_order_arc_1110  -13
    RHS1      connected_order_arc_1112  -13
    RHS1      connected_order_arc_1114  -13
    RHS1      connected_order_arc_1116  -13
    RHS1      connected_order_arc_1118  -13
    RHS1      connected_order_arc_1120  -13
    RHS1      connected_order_arc_1122  -13
    RHS1      connected_order_arc_1125  -13
    RHS1      connected_order_arc_1127  -13
    RHS1      connected_order_arc_1129  -13
    RHS1      connected_order_arc_1131  -13
    RHS1      connected_order_arc_1133  -13
    RHS1      connected_order_arc_1135  -13
    RHS1      connected_order_arc_1137  -13
    RHS1      connected_order_arc_1139  -13
    RHS1      connected_order_arc_1141  -13
    RHS1      connected_order_arc_1143  -13
    RHS1      connected_order_arc_1145  -13
    RHS1      connected_order_arc_1147  -13
    RHS1      connected_order_arc_1150  -13
    RHS1      connected_order_arc_1152  -13
    RHS1      connected_order_arc_1154  -13
    RHS1      connected_order_arc_1156  -13
    RHS1      connected_order_arc_1158  -13
    RHS1      connected_order_arc_1160  -13
    RHS1      connected_order_arc_1162  -13
    RHS1      connected_order_arc_1164  -13
    RHS1      connected_order_arc_1166  -13
    RHS1      connected_order_arc_1168  -13
    RHS1      connected_order_arc_1170  -13
    RHS1      connected_order_arc_1172  -13
    RHS1      connected_order_arc_1175  -13
    RHS1      connected_order_arc_1177  -13
    RHS1      connected_order_arc_1179  -13
    RHS1      connected_order_arc_1181  -13
    RHS1      connected_order_arc_1183  -13
    RHS1      connected_order_arc_1185  -13
    RHS1      connected_order_arc_1187  -13
    RHS1      connected_order_arc_1189  -13
    RHS1      connected_order_arc_1191  -13
    RHS1      connected_order_arc_1193  -13
    RHS1      connected_order_arc_1195  -13
    RHS1      connected_order_arc_1197  -13
    RHS1      connected_order_arc_1200  -13
    RHS1      connected_order_arc_1202  -13
    RHS1      connected_order_arc_1204  -13
    RHS1      connected_order_arc_1206  -13
    RHS1      connected_order_arc_1208  -13
    RHS1      connected_order_arc_1210  -13
    RHS1      connected_order_arc_1212  -13
    RHS1      connected_order_arc_1214  -13
    RHS1      connected_order_arc_1216  -13
    RHS1      connected_order_arc_1218  -13
    RHS1      connected_order_arc_1220  -13
    RHS1      connected_order_arc_1222  -13
    RHS1      connected_order_arc_1225  -13
    RHS1      connected_order_arc_1227  -13
    RHS1      connected_order_arc_1229  -13
    RHS1      connected_order_arc_1231  -13
    RHS1      connected_order_arc_1233  -13
    RHS1      connected_order_arc_1235  -13
    RHS1      connected_order_arc_1237  -13
    RHS1      connected_order_arc_1239  -13
    RHS1      connected_order_arc_1241  -13
    RHS1      connected_order_arc_1243  -13
    RHS1      connected_order_arc_1245  -13
    RHS1      connected_order_arc_1247  -13
    RHS1      connected_order_arc_1250  -13
    RHS1      connected_order_arc_1252  -13
    RHS1      connected_order_arc_1254  -13
    RHS1      connected_order_arc_1256  -13
    RHS1      connected_order_arc_1258  -13
    RHS1      connected_order_arc_1260  -13
    RHS1      connected_order_arc_1262  -13
    RHS1      connected_order_arc_1264  -13
    RHS1      connected_order_arc_1266  -13
    RHS1      connected_order_arc_1268  -13
    RHS1      connected_order_arc_1270  -13
    RHS1      connected_order_arc_1272  -13
    RHS1      depot_departure_or_bypass_1273  1
    RHS1      depot_return_or_bypass_1274  1
    RHS1      segment_load_conservation_1279  6
    RHS1      segment_prefix_ub_1281  19
    RHS1      segment_load_conservation_1286  -5
    RHS1      segment_prefix_lb_1287  6
    RHS1      segment_prefix_ub_1288  25
    RHS1      segment_load_conservation_1293  3
    RHS1      segment_prefix_ub_1295  22
    RHS1      segment_load_conservation_1300  3
    RHS1      segment_prefix_ub_1302  22
    RHS1      segment_load_conservation_1307  -5
    RHS1      segment_prefix_lb_1308  5
    RHS1      segment_prefix_ub_1309  25
    RHS1      fixed_segment_relative_order_1358  1
    RHS1      fixed_segment_relative_order_1359  1
    RHS1      fixed_segment_relative_order_1360  1
    RHS1      fixed_segment_relative_order_1361  1
    RHS1      original_T_including_depot_unload_1362  2.2933958320926176e+03
    RHS1      connected_order_arc_1377  -11
    RHS1      connected_order_arc_1379  -11
    RHS1      connected_order_arc_1381  -11
    RHS1      connected_order_arc_1383  -11
    RHS1      connected_order_arc_1385  -11
    RHS1      connected_order_arc_1387  -11
    RHS1      connected_order_arc_1389  -11
    RHS1      connected_order_arc_1391  -11
    RHS1      connected_order_arc_1393  -11
    RHS1      connected_order_arc_1395  -11
    RHS1      connected_order_arc_1398  -11
    RHS1      connected_order_arc_1400  -11
    RHS1      connected_order_arc_1402  -11
    RHS1      connected_order_arc_1404  -11
    RHS1      connected_order_arc_1406  -11
    RHS1      connected_order_arc_1408  -11
    RHS1      connected_order_arc_1410  -11
    RHS1      connected_order_arc_1412  -11
    RHS1      connected_order_arc_1414  -11
    RHS1      connected_order_arc_1416  -11
    RHS1      connected_order_arc_1419  -11
    RHS1      connected_order_arc_1421  -11
    RHS1      connected_order_arc_1423  -11
    RHS1      connected_order_arc_1425  -11
    RHS1      connected_order_arc_1427  -11
    RHS1      connected_order_arc_1429  -11
    RHS1      connected_order_arc_1431  -11
    RHS1      connected_order_arc_1433  -11
    RHS1      connected_order_arc_1435  -11
    RHS1      connected_order_arc_1437  -11
    RHS1      connected_order_arc_1440  -11
    RHS1      connected_order_arc_1442  -11
    RHS1      connected_order_arc_1444  -11
    RHS1      connected_order_arc_1446  -11
    RHS1      connected_order_arc_1448  -11
    RHS1      connected_order_arc_1450  -11
    RHS1      connected_order_arc_1452  -11
    RHS1      connected_order_arc_1454  -11
    RHS1      connected_order_arc_1456  -11
    RHS1      connected_order_arc_1458  -11
    RHS1      connected_order_arc_1461  -11
    RHS1      connected_order_arc_1463  -11
    RHS1      connected_order_arc_1465  -11
    RHS1      connected_order_arc_1467  -11
    RHS1      connected_order_arc_1469  -11
    RHS1      connected_order_arc_1471  -11
    RHS1      connected_order_arc_1473  -11
    RHS1      connected_order_arc_1475  -11
    RHS1      connected_order_arc_1477  -11
    RHS1      connected_order_arc_1479  -11
    RHS1      connected_order_arc_1482  -11
    RHS1      connected_order_arc_1484  -11
    RHS1      connected_order_arc_1486  -11
    RHS1      connected_order_arc_1488  -11
    RHS1      connected_order_arc_1490  -11
    RHS1      connected_order_arc_1492  -11
    RHS1      connected_order_arc_1494  -11
    RHS1      connected_order_arc_1496  -11
    RHS1      connected_order_arc_1498  -11
    RHS1      connected_order_arc_1500  -11
    RHS1      connected_order_arc_1503  -11
    RHS1      connected_order_arc_1505  -11
    RHS1      connected_order_arc_1507  -11
    RHS1      connected_order_arc_1509  -11
    RHS1      connected_order_arc_1511  -11
    RHS1      connected_order_arc_1513  -11
    RHS1      connected_order_arc_1515  -11
    RHS1      connected_order_arc_1517  -11
    RHS1      connected_order_arc_1519  -11
    RHS1      connected_order_arc_1521  -11
    RHS1      connected_order_arc_1524  -11
    RHS1      connected_order_arc_1526  -11
    RHS1      connected_order_arc_1528  -11
    RHS1      connected_order_arc_1530  -11
    RHS1      connected_order_arc_1532  -11
    RHS1      connected_order_arc_1534  -11
    RHS1      connected_order_arc_1536  -11
    RHS1      connected_order_arc_1538  -11
    RHS1      connected_order_arc_1540  -11
    RHS1      connected_order_arc_1542  -11
    RHS1      connected_order_arc_1545  -11
    RHS1      connected_order_arc_1547  -11
    RHS1      connected_order_arc_1549  -11
    RHS1      connected_order_arc_1551  -11
    RHS1      connected_order_arc_1553  -11
    RHS1      connected_order_arc_1555  -11
    RHS1      connected_order_arc_1557  -11
    RHS1      connected_order_arc_1559  -11
    RHS1      connected_order_arc_1561  -11
    RHS1      connected_order_arc_1563  -11
    RHS1      connected_order_arc_1566  -11
    RHS1      connected_order_arc_1568  -11
    RHS1      connected_order_arc_1570  -11
    RHS1      connected_order_arc_1572  -11
    RHS1      connected_order_arc_1574  -11
    RHS1      connected_order_arc_1576  -11
    RHS1      connected_order_arc_1578  -11
    RHS1      connected_order_arc_1580  -11
    RHS1      connected_order_arc_1582  -11
    RHS1      connected_order_arc_1584  -11
    RHS1      connected_order_arc_1587  -11
    RHS1      connected_order_arc_1589  -11
    RHS1      connected_order_arc_1591  -11
    RHS1      connected_order_arc_1593  -11
    RHS1      connected_order_arc_1595  -11
    RHS1      connected_order_arc_1597  -11
    RHS1      connected_order_arc_1599  -11
    RHS1      connected_order_arc_1601  -11
    RHS1      connected_order_arc_1603  -11
    RHS1      connected_order_arc_1605  -11
    RHS1      depot_departure_or_bypass_1606  1
    RHS1      depot_return_or_bypass_1607  1
    RHS1      segment_load_conservation_1612  2
    RHS1      segment_prefix_ub_1614  28
    RHS1      segment_prefix_ub_1621  27
    RHS1      segment_load_conservation_1626  2
    RHS1      segment_prefix_ub_1628  24
    RHS1      fixed_segment_relative_order_1677  1
    RHS1      fixed_segment_relative_order_1678  1
    RHS1      original_T_including_depot_unload_1679  4.2424928979880842e+03
BOUNDS
 LO BND1      t         2.5124876618884330e-02
 UP BND1      t         4.2058882435451639e-02
 UP BND1      q         5.4048177341474812e-01
 BV BND1      x_1_0   
 UP BND1      w_1_0     4.2058882435451639e-02
 BV BND1      x_1_1   
 UP BND1      w_1_1     4.2058882435451639e-02
 BV BND1      x_1_2   
 UP BND1      w_1_2     4.2058882435451639e-02
 BV BND1      x_1_3   
 UP BND1      w_1_3     4.2058882435451639e-02
 BV BND1      x_1_4   
 UP BND1      w_1_4     4.2058882435451639e-02
 BV BND1      x_1_5   
 UP BND1      w_1_5     4.2058882435451639e-02
 BV BND1      x_1_6   
 UP BND1      w_1_6     4.2058882435451639e-02
 BV BND1      x_1_7   
 UP BND1      w_1_7     4.2058882435451639e-02
 BV BND1      x_1_8   
 UP BND1      w_1_8     4.2058882435451639e-02
 BV BND1      x_1_9   
 UP BND1      w_1_9     4.2058882435451639e-02
 BV BND1      x_1_10  
 UP BND1      w_1_10    4.2058882435451639e-02
 BV BND1      x_1_11  
 UP BND1      w_1_11    4.2058882435451639e-02
 BV BND1      x_1_12  
 UP BND1      w_1_12    4.2058882435451639e-02
 BV BND1      x_1_13  
 UP BND1      w_1_13    4.2058882435451639e-02
 BV BND1      x_1_14  
 UP BND1      w_1_14    4.2058882435451639e-02
 BV BND1      x_1_15  
 UP BND1      w_1_15    4.2058882435451639e-02
 BV BND1      x_1_16  
 UP BND1      w_1_16    4.2058882435451639e-02
 BV BND1      x_1_17  
 UP BND1      w_1_17    4.2058882435451639e-02
 BV BND1      x_1_18  
 UP BND1      w_1_18    4.2058882435451639e-02
 BV BND1      x_1_19  
 UP BND1      w_1_19    4.2058882435451639e-02
 UP BND1      rho_1     1
 BV BND1      x_2_0   
 UP BND1      w_2_0     4.2058882435451639e-02
 BV BND1      x_2_1   
 UP BND1      w_2_1     4.2058882435451639e-02
 BV BND1      x_2_2   
 UP BND1      w_2_2     4.2058882435451639e-02
 BV BND1      x_2_3   
 UP BND1      w_2_3     4.2058882435451639e-02
 BV BND1      x_2_4   
 UP BND1      w_2_4     4.2058882435451639e-02
 BV BND1      x_2_5   
 UP BND1      w_2_5     4.2058882435451639e-02
 BV BND1      x_2_6   
 UP BND1      w_2_6     4.2058882435451639e-02
 BV BND1      x_2_7   
 UP BND1      w_2_7     4.2058882435451639e-02
 BV BND1      x_2_8   
 UP BND1      w_2_8     4.2058882435451639e-02
 BV BND1      x_2_9   
 UP BND1      w_2_9     4.2058882435451639e-02
 BV BND1      x_2_10  
 UP BND1      w_2_10    4.2058882435451639e-02
 BV BND1      x_2_11  
 UP BND1      w_2_11    4.2058882435451639e-02
 BV BND1      x_2_12  
 UP BND1      w_2_12    4.2058882435451639e-02
 BV BND1      x_2_13  
 UP BND1      w_2_13    4.2058882435451639e-02
 BV BND1      x_2_14  
 UP BND1      w_2_14    4.2058882435451639e-02
 BV BND1      x_2_15  
 UP BND1      w_2_15    4.2058882435451639e-02
 UP BND1      rho_2     1
 BV BND1      x_31_0  
 UP BND1      w_31_0    4.2058882435451639e-02
 BV BND1      x_31_1  
 UP BND1      w_31_1    4.2058882435451639e-02
 BV BND1      x_31_2  
 UP BND1      w_31_2    4.2058882435451639e-02
 BV BND1      x_31_3  
 UP BND1      w_31_3    4.2058882435451639e-02
 BV BND1      x_31_4  
 UP BND1      w_31_4    4.2058882435451639e-02
 BV BND1      x_31_5  
 UP BND1      w_31_5    4.2058882435451639e-02
 BV BND1      x_31_6  
 UP BND1      w_31_6    4.2058882435451639e-02
 BV BND1      x_31_7  
 UP BND1      w_31_7    4.2058882435451639e-02
 BV BND1      x_31_8  
 UP BND1      w_31_8    4.2058882435451639e-02
 BV BND1      x_31_9  
 UP BND1      w_31_9    4.2058882435451639e-02
 BV BND1      x_31_10 
 UP BND1      w_31_10   4.2058882435451639e-02
 BV BND1      x_31_11 
 UP BND1      w_31_11   4.2058882435451639e-02
 BV BND1      x_31_12 
 UP BND1      w_31_12   4.2058882435451639e-02
 UP BND1      rho_31    1
 BV BND1      x_3_0   
 UP BND1      w_3_0     4.2058882435451639e-02
 BV BND1      x_3_1   
 UP BND1      w_3_1     4.2058882435451639e-02
 BV BND1      x_3_2   
 UP BND1      w_3_2     4.2058882435451639e-02
 BV BND1      x_3_3   
 UP BND1      w_3_3     4.2058882435451639e-02
 BV BND1      x_3_4   
 UP BND1      w_3_4     4.2058882435451639e-02
 BV BND1      x_3_5   
 UP BND1      w_3_5     4.2058882435451639e-02
 BV BND1      x_3_6   
 UP BND1      w_3_6     4.2058882435451639e-02
 BV BND1      x_3_7   
 UP BND1      w_3_7     4.2058882435451639e-02
 BV BND1      x_3_8   
 UP BND1      w_3_8     4.2058882435451639e-02
 BV BND1      x_3_9   
 UP BND1      w_3_9     4.2058882435451639e-02
 BV BND1      x_3_10  
 UP BND1      w_3_10    4.2058882435451639e-02
 BV BND1      x_3_11  
 UP BND1      w_3_11    4.2058882435451639e-02
 BV BND1      x_3_12  
 UP BND1      w_3_12    4.2058882435451639e-02
 BV BND1      x_3_13  
 UP BND1      w_3_13    4.2058882435451639e-02
 BV BND1      x_3_14  
 UP BND1      w_3_14    4.2058882435451639e-02
 BV BND1      x_3_15  
 UP BND1      w_3_15    4.2058882435451639e-02
 BV BND1      x_3_16  
 UP BND1      w_3_16    4.2058882435451639e-02
 BV BND1      x_3_17  
 UP BND1      w_3_17    4.2058882435451639e-02
 UP BND1      rho_3     1
 BV BND1      x_16_0  
 UP BND1      w_16_0    4.2058882435451639e-02
 BV BND1      x_16_1  
 UP BND1      w_16_1    4.2058882435451639e-02
 BV BND1      x_16_2  
 UP BND1      w_16_2    4.2058882435451639e-02
 BV BND1      x_16_3  
 UP BND1      w_16_3    4.2058882435451639e-02
 BV BND1      x_16_4  
 UP BND1      w_16_4    4.2058882435451639e-02
 BV BND1      x_16_5  
 UP BND1      w_16_5    4.2058882435451639e-02
 BV BND1      x_16_6  
 UP BND1      w_16_6    4.2058882435451639e-02
 BV BND1      x_16_7  
 UP BND1      w_16_7    4.2058882435451639e-02
 BV BND1      x_16_8  
 UP BND1      w_16_8    4.2058882435451639e-02
 BV BND1      x_16_9  
 UP BND1      w_16_9    4.2058882435451639e-02
 BV BND1      x_16_10 
 UP BND1      w_16_10   4.2058882435451639e-02
 BV BND1      x_16_11 
 UP BND1      w_16_11   4.2058882435451639e-02
 BV BND1      x_16_12 
 UP BND1      w_16_12   4.2058882435451639e-02
 UP BND1      rho_16    1
 BV BND1      x_4_0   
 UP BND1      w_4_0     4.2058882435451639e-02
 BV BND1      x_4_1   
 UP BND1      w_4_1     4.2058882435451639e-02
 BV BND1      x_4_2   
 UP BND1      w_4_2     4.2058882435451639e-02
 BV BND1      x_4_3   
 UP BND1      w_4_3     4.2058882435451639e-02
 BV BND1      x_4_4   
 UP BND1      w_4_4     4.2058882435451639e-02
 BV BND1      x_4_5   
 UP BND1      w_4_5     4.2058882435451639e-02
 BV BND1      x_4_6   
 UP BND1      w_4_6     4.2058882435451639e-02
 BV BND1      x_4_7   
 UP BND1      w_4_7     4.2058882435451639e-02
 BV BND1      x_4_8   
 UP BND1      w_4_8     4.2058882435451639e-02
 BV BND1      x_4_9   
 UP BND1      w_4_9     4.2058882435451639e-02
 BV BND1      x_4_10  
 UP BND1      w_4_10    4.2058882435451639e-02
 BV BND1      x_4_11  
 UP BND1      w_4_11    4.2058882435451639e-02
 BV BND1      x_4_12  
 UP BND1      w_4_12    4.2058882435451639e-02
 BV BND1      x_4_13  
 UP BND1      w_4_13    4.2058882435451639e-02
 BV BND1      x_4_14  
 UP BND1      w_4_14    4.2058882435451639e-02
 BV BND1      x_4_15  
 UP BND1      w_4_15    4.2058882435451639e-02
 UP BND1      rho_4     1
 BV BND1      x_19_0  
 UP BND1      w_19_0    4.2058882435451639e-02
 BV BND1      x_19_1  
 UP BND1      w_19_1    4.2058882435451639e-02
 BV BND1      x_19_2  
 UP BND1      w_19_2    4.2058882435451639e-02
 BV BND1      x_19_3  
 UP BND1      w_19_3    4.2058882435451639e-02
 BV BND1      x_19_4  
 UP BND1      w_19_4    4.2058882435451639e-02
 BV BND1      x_19_5  
 UP BND1      w_19_5    4.2058882435451639e-02
 BV BND1      x_19_6  
 UP BND1      w_19_6    4.2058882435451639e-02
 BV BND1      x_19_7  
 UP BND1      w_19_7    4.2058882435451639e-02
 BV BND1      x_19_8  
 UP BND1      w_19_8    4.2058882435451639e-02
 UP BND1      rho_19    1
 BV BND1      x_5_0   
 UP BND1      w_5_0     4.2058882435451639e-02
 BV BND1      x_5_1   
 UP BND1      w_5_1     4.2058882435451639e-02
 BV BND1      x_5_2   
 UP BND1      w_5_2     4.2058882435451639e-02
 BV BND1      x_5_3   
 UP BND1      w_5_3     4.2058882435451639e-02
 BV BND1      x_5_4   
 UP BND1      w_5_4     4.2058882435451639e-02
 BV BND1      x_5_5   
 UP BND1      w_5_5     4.2058882435451639e-02
 BV BND1      x_5_6   
 UP BND1      w_5_6     4.2058882435451639e-02
 BV BND1      x_5_7   
 UP BND1      w_5_7     4.2058882435451639e-02
 BV BND1      x_5_8   
 UP BND1      w_5_8     4.2058882435451639e-02
 BV BND1      x_5_9   
 UP BND1      w_5_9     4.2058882435451639e-02
 BV BND1      x_5_10  
 UP BND1      w_5_10    4.2058882435451639e-02
 BV BND1      x_5_11  
 UP BND1      w_5_11    4.2058882435451639e-02
 BV BND1      x_5_12  
 UP BND1      w_5_12    4.2058882435451639e-02
 BV BND1      x_5_13  
 UP BND1      w_5_13    4.2058882435451639e-02
 BV BND1      x_5_14  
 UP BND1      w_5_14    4.2058882435451639e-02
 BV BND1      x_5_15  
 UP BND1      w_5_15    4.2058882435451639e-02
 BV BND1      x_5_16  
 UP BND1      w_5_16    4.2058882435451639e-02
 UP BND1      rho_5     1
 UP BND1      a_1_2     1
 UP BND1      a_1_31    1
 UP BND1      a_1_3     1
 UP BND1      a_1_16    1
 UP BND1      a_1_4     1
 UP BND1      a_1_19    1
 UP BND1      a_1_5     1
 UP BND1      a_2_31    1
 UP BND1      a_2_3     1
 UP BND1      a_2_16    1
 UP BND1      a_2_4     1
 UP BND1      a_2_19    1
 UP BND1      a_2_5     1
 UP BND1      a_31_3    1
 UP BND1      a_31_16   1
 UP BND1      a_31_4    1
 UP BND1      a_31_19   1
 UP BND1      a_31_5    1
 UP BND1      a_3_16    1
 UP BND1      a_3_4     1
 UP BND1      a_3_19    1
 UP BND1      a_3_5     1
 UP BND1      a_16_4    1
 UP BND1      a_16_19   1
 UP BND1      a_16_5    1
 UP BND1      a_4_19    1
 UP BND1      a_4_5     1
 UP BND1      a_19_5    1
 BV BND1      service_0_1_0
 BV BND1      service_0_1_1
 BV BND1      service_0_1_3
 BV BND1      service_0_1_4
 BV BND1      service_0_1_5
 BV BND1      service_0_1_6
 BV BND1      service_0_1_7
 BV BND1      service_0_1_8
 BV BND1      service_0_1_9
 BV BND1      service_0_1_10
 BV BND1      service_0_1_11
 BV BND1      service_0_1_12
 BV BND1      service_0_1_13
 BV BND1      service_0_1_14
 BV BND1      service_0_1_15
 BV BND1      service_0_1_16
 BV BND1      service_0_1_17
 BV BND1      service_0_1_18
 BV BND1      service_0_1_19
 BV BND1      service_1_1_0
 BV BND1      service_1_1_1
 BV BND1      service_1_1_3
 BV BND1      service_1_1_4
 BV BND1      service_1_1_5
 BV BND1      service_1_1_6
 BV BND1      service_1_1_7
 BV BND1      service_1_1_8
 BV BND1      service_1_1_9
 BV BND1      service_1_1_10
 BV BND1      service_1_1_11
 BV BND1      service_1_1_12
 BV BND1      service_1_1_13
 BV BND1      service_1_1_14
 BV BND1      service_1_1_15
 BV BND1      service_1_1_16
 BV BND1      service_1_1_17
 BV BND1      service_1_1_18
 BV BND1      service_1_1_19
 BV BND1      service_2_1_0
 BV BND1      service_2_1_1
 BV BND1      service_2_1_3
 BV BND1      service_2_1_4
 BV BND1      service_2_1_5
 BV BND1      service_2_1_6
 BV BND1      service_2_1_7
 BV BND1      service_2_1_8
 BV BND1      service_2_1_9
 BV BND1      service_2_1_10
 BV BND1      service_2_1_11
 BV BND1      service_2_1_12
 BV BND1      service_2_1_13
 BV BND1      service_2_1_14
 BV BND1      service_2_1_15
 BV BND1      service_2_1_16
 BV BND1      service_2_1_17
 BV BND1      service_2_1_18
 BV BND1      service_2_1_19
 BV BND1      service_0_2_1
 BV BND1      service_0_2_2
 BV BND1      service_0_2_3
 BV BND1      service_0_2_4
 BV BND1      service_0_2_5
 BV BND1      service_0_2_6
 BV BND1      service_0_2_7
 BV BND1      service_0_2_8
 BV BND1      service_0_2_9
 BV BND1      service_0_2_10
 BV BND1      service_0_2_11
 BV BND1      service_0_2_12
 BV BND1      service_0_2_13
 BV BND1      service_0_2_14
 BV BND1      service_0_2_15
 BV BND1      service_1_2_1
 BV BND1      service_1_2_2
 BV BND1      service_1_2_3
 BV BND1      service_1_2_4
 BV BND1      service_1_2_5
 BV BND1      service_1_2_6
 BV BND1      service_1_2_7
 BV BND1      service_1_2_8
 BV BND1      service_1_2_9
 BV BND1      service_1_2_10
 BV BND1      service_1_2_11
 BV BND1      service_1_2_12
 BV BND1      service_1_2_13
 BV BND1      service_1_2_14
 BV BND1      service_1_2_15
 BV BND1      service_2_2_1
 BV BND1      service_2_2_2
 BV BND1      service_2_2_3
 BV BND1      service_2_2_4
 BV BND1      service_2_2_5
 BV BND1      service_2_2_6
 BV BND1      service_2_2_7
 BV BND1      service_2_2_8
 BV BND1      service_2_2_9
 BV BND1      service_2_2_10
 BV BND1      service_2_2_11
 BV BND1      service_2_2_12
 BV BND1      service_2_2_13
 BV BND1      service_2_2_14
 BV BND1      service_2_2_15
 BV BND1      service_0_31_0
 BV BND1      service_0_31_1
 BV BND1      service_0_31_3
 BV BND1      service_0_31_4
 BV BND1      service_0_31_5
 BV BND1      service_0_31_6
 BV BND1      service_0_31_7
 BV BND1      service_0_31_8
 BV BND1      service_0_31_9
 BV BND1      service_0_31_10
 BV BND1      service_0_31_11
 BV BND1      service_0_31_12
 BV BND1      service_1_31_0
 BV BND1      service_1_31_1
 BV BND1      service_1_31_3
 BV BND1      service_1_31_4
 BV BND1      service_1_31_5
 BV BND1      service_1_31_6
 BV BND1      service_1_31_7
 BV BND1      service_1_31_8
 BV BND1      service_1_31_9
 BV BND1      service_1_31_10
 BV BND1      service_1_31_11
 BV BND1      service_1_31_12
 BV BND1      service_2_31_0
 BV BND1      service_2_31_1
 BV BND1      service_2_31_3
 BV BND1      service_2_31_4
 BV BND1      service_2_31_5
 BV BND1      service_2_31_6
 BV BND1      service_2_31_7
 BV BND1      service_2_31_8
 BV BND1      service_2_31_9
 BV BND1      service_2_31_10
 BV BND1      service_2_31_11
 BV BND1      service_2_31_12
 BV BND1      service_0_3_0
 BV BND1      service_0_3_1
 BV BND1      service_0_3_2
 BV BND1      service_0_3_3
 BV BND1      service_0_3_4
 BV BND1      service_0_3_5
 BV BND1      service_0_3_6
 BV BND1      service_0_3_7
 BV BND1      service_0_3_8
 BV BND1      service_0_3_9
 BV BND1      service_0_3_10
 BV BND1      service_0_3_11
 BV BND1      service_0_3_13
 BV BND1      service_0_3_14
 BV BND1      service_0_3_15
 BV BND1      service_0_3_16
 BV BND1      service_0_3_17
 BV BND1      service_1_3_0
 BV BND1      service_1_3_1
 BV BND1      service_1_3_2
 BV BND1      service_1_3_3
 BV BND1      service_1_3_4
 BV BND1      service_1_3_5
 BV BND1      service_1_3_6
 BV BND1      service_1_3_7
 BV BND1      service_1_3_8
 BV BND1      service_1_3_9
 BV BND1      service_1_3_10
 BV BND1      service_1_3_11
 BV BND1      service_1_3_13
 BV BND1      service_1_3_14
 BV BND1      service_1_3_15
 BV BND1      service_1_3_16
 BV BND1      service_1_3_17
 BV BND1      service_2_3_0
 BV BND1      service_2_3_1
 BV BND1      service_2_3_2
 BV BND1      service_2_3_3
 BV BND1      service_2_3_4
 BV BND1      service_2_3_5
 BV BND1      service_2_3_6
 BV BND1      service_2_3_7
 BV BND1      service_2_3_8
 BV BND1      service_2_3_9
 BV BND1      service_2_3_10
 BV BND1      service_2_3_11
 BV BND1      service_2_3_13
 BV BND1      service_2_3_14
 BV BND1      service_2_3_15
 BV BND1      service_2_3_16
 BV BND1      service_2_3_17
 BV BND1      service_0_16_0
 BV BND1      service_0_16_2
 BV BND1      service_0_16_3
 BV BND1      service_0_16_4
 BV BND1      service_0_16_5
 BV BND1      service_0_16_6
 BV BND1      service_0_16_7
 BV BND1      service_0_16_8
 BV BND1      service_0_16_9
 BV BND1      service_0_16_10
 BV BND1      service_0_16_11
 BV BND1      service_0_16_12
 BV BND1      service_1_16_0
 BV BND1      service_1_16_2
 BV BND1      service_1_16_3
 BV BND1      service_1_16_4
 BV BND1      service_1_16_5
 BV BND1      service_1_16_6
 BV BND1      service_1_16_7
 BV BND1      service_1_16_8
 BV BND1      service_1_16_9
 BV BND1      service_1_16_10
 BV BND1      service_1_16_11
 BV BND1      service_1_16_12
 BV BND1      service_2_16_0
 BV BND1      service_2_16_2
 BV BND1      service_2_16_3
 BV BND1      service_2_16_4
 BV BND1      service_2_16_5
 BV BND1      service_2_16_6
 BV BND1      service_2_16_7
 BV BND1      service_2_16_8
 BV BND1      service_2_16_9
 BV BND1      service_2_16_10
 BV BND1      service_2_16_11
 BV BND1      service_2_16_12
 BV BND1      service_0_4_0
 BV BND1      service_0_4_1
 BV BND1      service_0_4_2
 BV BND1      service_0_4_3
 BV BND1      service_0_4_4
 BV BND1      service_0_4_5
 BV BND1      service_0_4_6
 BV BND1      service_0_4_7
 BV BND1      service_0_4_8
 BV BND1      service_0_4_9
 BV BND1      service_0_4_10
 BV BND1      service_0_4_12
 BV BND1      service_0_4_13
 BV BND1      service_0_4_14
 BV BND1      service_0_4_15
 BV BND1      service_1_4_0
 BV BND1      service_1_4_1
 BV BND1      service_1_4_2
 BV BND1      service_1_4_3
 BV BND1      service_1_4_4
 BV BND1      service_1_4_5
 BV BND1      service_1_4_6
 BV BND1      service_1_4_7
 BV BND1      service_1_4_8
 BV BND1      service_1_4_9
 BV BND1      service_1_4_10
 BV BND1      service_1_4_12
 BV BND1      service_1_4_13
 BV BND1      service_1_4_14
 BV BND1      service_1_4_15
 BV BND1      service_2_4_0
 BV BND1      service_2_4_1
 BV BND1      service_2_4_2
 BV BND1      service_2_4_3
 BV BND1      service_2_4_4
 BV BND1      service_2_4_5
 BV BND1      service_2_4_6
 BV BND1      service_2_4_7
 BV BND1      service_2_4_8
 BV BND1      service_2_4_9
 BV BND1      service_2_4_10
 BV BND1      service_2_4_12
 BV BND1      service_2_4_13
 BV BND1      service_2_4_14
 BV BND1      service_2_4_15
 BV BND1      service_0_19_1
 BV BND1      service_0_19_2
 BV BND1      service_0_19_3
 BV BND1      service_0_19_4
 BV BND1      service_0_19_5
 BV BND1      service_0_19_6
 BV BND1      service_0_19_7
 BV BND1      service_0_19_8
 BV BND1      service_1_19_1
 BV BND1      service_1_19_2
 BV BND1      service_1_19_3
 BV BND1      service_1_19_4
 BV BND1      service_1_19_5
 BV BND1      service_1_19_6
 BV BND1      service_1_19_7
 BV BND1      service_1_19_8
 BV BND1      service_2_19_1
 BV BND1      service_2_19_2
 BV BND1      service_2_19_3
 BV BND1      service_2_19_4
 BV BND1      service_2_19_5
 BV BND1      service_2_19_6
 BV BND1      service_2_19_7
 BV BND1      service_2_19_8
 BV BND1      service_0_5_0
 BV BND1      service_0_5_1
 BV BND1      service_0_5_3
 BV BND1      service_0_5_4
 BV BND1      service_0_5_5
 BV BND1      service_0_5_6
 BV BND1      service_0_5_7
 BV BND1      service_0_5_8
 BV BND1      service_0_5_9
 BV BND1      service_0_5_10
 BV BND1      service_0_5_11
 BV BND1      service_0_5_12
 BV BND1      service_0_5_13
 BV BND1      service_0_5_14
 BV BND1      service_0_5_15
 BV BND1      service_0_5_16
 BV BND1      service_1_5_0
 BV BND1      service_1_5_1
 BV BND1      service_1_5_3
 BV BND1      service_1_5_4
 BV BND1      service_1_5_5
 BV BND1      service_1_5_6
 BV BND1      service_1_5_7
 BV BND1      service_1_5_8
 BV BND1      service_1_5_9
 BV BND1      service_1_5_10
 BV BND1      service_1_5_11
 BV BND1      service_1_5_12
 BV BND1      service_1_5_13
 BV BND1      service_1_5_14
 BV BND1      service_1_5_15
 BV BND1      service_1_5_16
 BV BND1      service_2_5_0
 BV BND1      service_2_5_1
 BV BND1      service_2_5_3
 BV BND1      service_2_5_4
 BV BND1      service_2_5_5
 BV BND1      service_2_5_6
 BV BND1      service_2_5_7
 BV BND1      service_2_5_8
 BV BND1      service_2_5_9
 BV BND1      service_2_5_10
 BV BND1      service_2_5_11
 BV BND1      service_2_5_12
 BV BND1      service_2_5_13
 BV BND1      service_2_5_14
 BV BND1      service_2_5_15
 BV BND1      service_2_5_16
 FX BND1      visit_0_1  1
 UP BND1      order_0_1  14
 FX BND1      visit_0_2  1
 UP BND1      order_0_2  14
 FX BND1      visit_0_3  1
 UP BND1      order_0_3  14
 FX BND1      visit_0_4  1
 UP BND1      order_0_4  14
 FX BND1      visit_0_5  1
 UP BND1      order_0_5  14
 FX BND1      visit_0_6  1
 UP BND1      order_0_6  14
 UP BND1      visit_0_15  1
 UP BND1      order_0_15  14
 UP BND1      visit_0_16  1
 UP BND1      order_0_16  14
 UP BND1      visit_0_17  1
 UP BND1      order_0_17  14
 UP BND1      visit_0_18  1
 UP BND1      order_0_18  14
 UP BND1      visit_0_19  1
 UP BND1      order_0_19  14
 UP BND1      visit_0_20  1
 UP BND1      order_0_20  14
 UP BND1      visit_0_21  1
 UP BND1      order_0_21  14
 UP BND1      visit_0_22  1
 UP BND1      order_0_22  14
 BV BND1      arc_0_0_0
 FX BND1      load_0_0_0  0
 BV BND1      arc_0_0_1
 FX BND1      load_0_0_1  0
 BV BND1      arc_0_0_2
 FX BND1      load_0_0_2  0
 BV BND1      arc_0_0_3
 FX BND1      load_0_0_3  0
 BV BND1      arc_0_0_4
 FX BND1      load_0_0_4  0
 BV BND1      arc_0_0_5
 FX BND1      load_0_0_5  0
 BV BND1      arc_0_0_6
 FX BND1      load_0_0_6  0
 BV BND1      arc_0_0_15
 FX BND1      load_0_0_15  0
 BV BND1      arc_0_0_16
 FX BND1      load_0_0_16  0
 BV BND1      arc_0_0_17
 FX BND1      load_0_0_17  0
 BV BND1      arc_0_0_18
 FX BND1      load_0_0_18  0
 BV BND1      arc_0_0_19
 FX BND1      load_0_0_19  0
 BV BND1      arc_0_0_20
 FX BND1      load_0_0_20  0
 BV BND1      arc_0_0_21
 FX BND1      load_0_0_21  0
 BV BND1      arc_0_0_22
 FX BND1      load_0_0_22  0
 BV BND1      arc_0_1_0
 UP BND1      load_0_1_0  20
 BV BND1      arc_0_1_2
 UP BND1      load_0_1_2  20
 BV BND1      arc_0_1_3
 UP BND1      load_0_1_3  20
 BV BND1      arc_0_1_4
 UP BND1      load_0_1_4  20
 BV BND1      arc_0_1_5
 UP BND1      load_0_1_5  20
 BV BND1      arc_0_1_6
 UP BND1      load_0_1_6  20
 BV BND1      arc_0_1_15
 UP BND1      load_0_1_15  20
 BV BND1      arc_0_1_16
 UP BND1      load_0_1_16  20
 BV BND1      arc_0_1_17
 UP BND1      load_0_1_17  20
 BV BND1      arc_0_1_18
 UP BND1      load_0_1_18  20
 BV BND1      arc_0_1_19
 UP BND1      load_0_1_19  20
 BV BND1      arc_0_1_20
 UP BND1      load_0_1_20  20
 BV BND1      arc_0_1_21
 UP BND1      load_0_1_21  20
 BV BND1      arc_0_1_22
 UP BND1      load_0_1_22  20
 BV BND1      arc_0_2_0
 UP BND1      load_0_2_0  20
 BV BND1      arc_0_2_1
 UP BND1      load_0_2_1  20
 BV BND1      arc_0_2_3
 UP BND1      load_0_2_3  20
 BV BND1      arc_0_2_4
 UP BND1      load_0_2_4  20
 BV BND1      arc_0_2_5
 UP BND1      load_0_2_5  20
 BV BND1      arc_0_2_6
 UP BND1      load_0_2_6  20
 BV BND1      arc_0_2_15
 UP BND1      load_0_2_15  20
 BV BND1      arc_0_2_16
 UP BND1      load_0_2_16  20
 BV BND1      arc_0_2_17
 UP BND1      load_0_2_17  20
 BV BND1      arc_0_2_18
 UP BND1      load_0_2_18  20
 BV BND1      arc_0_2_19
 UP BND1      load_0_2_19  20
 BV BND1      arc_0_2_20
 UP BND1      load_0_2_20  20
 BV BND1      arc_0_2_21
 UP BND1      load_0_2_21  20
 BV BND1      arc_0_2_22
 UP BND1      load_0_2_22  20
 BV BND1      arc_0_3_0
 UP BND1      load_0_3_0  20
 BV BND1      arc_0_3_1
 UP BND1      load_0_3_1  20
 BV BND1      arc_0_3_2
 UP BND1      load_0_3_2  20
 BV BND1      arc_0_3_4
 UP BND1      load_0_3_4  20
 BV BND1      arc_0_3_5
 UP BND1      load_0_3_5  20
 BV BND1      arc_0_3_6
 UP BND1      load_0_3_6  20
 BV BND1      arc_0_3_15
 UP BND1      load_0_3_15  20
 BV BND1      arc_0_3_16
 UP BND1      load_0_3_16  20
 BV BND1      arc_0_3_17
 UP BND1      load_0_3_17  20
 BV BND1      arc_0_3_18
 UP BND1      load_0_3_18  20
 BV BND1      arc_0_3_19
 UP BND1      load_0_3_19  20
 BV BND1      arc_0_3_20
 UP BND1      load_0_3_20  20
 BV BND1      arc_0_3_21
 UP BND1      load_0_3_21  20
 BV BND1      arc_0_3_22
 UP BND1      load_0_3_22  20
 BV BND1      arc_0_4_0
 UP BND1      load_0_4_0  20
 BV BND1      arc_0_4_1
 UP BND1      load_0_4_1  20
 BV BND1      arc_0_4_2
 UP BND1      load_0_4_2  20
 BV BND1      arc_0_4_3
 UP BND1      load_0_4_3  20
 BV BND1      arc_0_4_5
 UP BND1      load_0_4_5  20
 BV BND1      arc_0_4_6
 UP BND1      load_0_4_6  20
 BV BND1      arc_0_4_15
 UP BND1      load_0_4_15  20
 BV BND1      arc_0_4_16
 UP BND1      load_0_4_16  20
 BV BND1      arc_0_4_17
 UP BND1      load_0_4_17  20
 BV BND1      arc_0_4_18
 UP BND1      load_0_4_18  20
 BV BND1      arc_0_4_19
 UP BND1      load_0_4_19  20
 BV BND1      arc_0_4_20
 UP BND1      load_0_4_20  20
 BV BND1      arc_0_4_21
 UP BND1      load_0_4_21  20
 BV BND1      arc_0_4_22
 UP BND1      load_0_4_22  20
 BV BND1      arc_0_5_0
 UP BND1      load_0_5_0  20
 BV BND1      arc_0_5_1
 UP BND1      load_0_5_1  20
 BV BND1      arc_0_5_2
 UP BND1      load_0_5_2  20
 BV BND1      arc_0_5_3
 UP BND1      load_0_5_3  20
 BV BND1      arc_0_5_4
 UP BND1      load_0_5_4  20
 BV BND1      arc_0_5_6
 UP BND1      load_0_5_6  20
 BV BND1      arc_0_5_15
 UP BND1      load_0_5_15  20
 BV BND1      arc_0_5_16
 UP BND1      load_0_5_16  20
 BV BND1      arc_0_5_17
 UP BND1      load_0_5_17  20
 BV BND1      arc_0_5_18
 UP BND1      load_0_5_18  20
 BV BND1      arc_0_5_19
 UP BND1      load_0_5_19  20
 BV BND1      arc_0_5_20
 UP BND1      load_0_5_20  20
 BV BND1      arc_0_5_21
 UP BND1      load_0_5_21  20
 BV BND1      arc_0_5_22
 UP BND1      load_0_5_22  20
 BV BND1      arc_0_6_0
 UP BND1      load_0_6_0  20
 BV BND1      arc_0_6_1
 UP BND1      load_0_6_1  20
 BV BND1      arc_0_6_2
 UP BND1      load_0_6_2  20
 BV BND1      arc_0_6_3
 UP BND1      load_0_6_3  20
 BV BND1      arc_0_6_4
 UP BND1      load_0_6_4  20
 BV BND1      arc_0_6_5
 UP BND1      load_0_6_5  20
 BV BND1      arc_0_6_15
 UP BND1      load_0_6_15  20
 BV BND1      arc_0_6_16
 UP BND1      load_0_6_16  20
 BV BND1      arc_0_6_17
 UP BND1      load_0_6_17  20
 BV BND1      arc_0_6_18
 UP BND1      load_0_6_18  20
 BV BND1      arc_0_6_19
 UP BND1      load_0_6_19  20
 BV BND1      arc_0_6_20
 UP BND1      load_0_6_20  20
 BV BND1      arc_0_6_21
 UP BND1      load_0_6_21  20
 BV BND1      arc_0_6_22
 UP BND1      load_0_6_22  20
 BV BND1      arc_0_15_0
 UP BND1      load_0_15_0  20
 BV BND1      arc_0_15_1
 UP BND1      load_0_15_1  20
 BV BND1      arc_0_15_2
 UP BND1      load_0_15_2  20
 BV BND1      arc_0_15_3
 UP BND1      load_0_15_3  20
 BV BND1      arc_0_15_4
 UP BND1      load_0_15_4  20
 BV BND1      arc_0_15_5
 UP BND1      load_0_15_5  20
 BV BND1      arc_0_15_6
 UP BND1      load_0_15_6  20
 BV BND1      arc_0_15_16
 UP BND1      load_0_15_16  20
 BV BND1      arc_0_15_17
 UP BND1      load_0_15_17  20
 BV BND1      arc_0_15_18
 UP BND1      load_0_15_18  20
 BV BND1      arc_0_15_19
 UP BND1      load_0_15_19  20
 BV BND1      arc_0_15_20
 UP BND1      load_0_15_20  20
 BV BND1      arc_0_15_21
 UP BND1      load_0_15_21  20
 BV BND1      arc_0_15_22
 UP BND1      load_0_15_22  20
 BV BND1      arc_0_16_0
 UP BND1      load_0_16_0  20
 BV BND1      arc_0_16_1
 UP BND1      load_0_16_1  20
 BV BND1      arc_0_16_2
 UP BND1      load_0_16_2  20
 BV BND1      arc_0_16_3
 UP BND1      load_0_16_3  20
 BV BND1      arc_0_16_4
 UP BND1      load_0_16_4  20
 BV BND1      arc_0_16_5
 UP BND1      load_0_16_5  20
 BV BND1      arc_0_16_6
 UP BND1      load_0_16_6  20
 BV BND1      arc_0_16_15
 UP BND1      load_0_16_15  20
 BV BND1      arc_0_16_17
 UP BND1      load_0_16_17  20
 BV BND1      arc_0_16_18
 UP BND1      load_0_16_18  20
 BV BND1      arc_0_16_19
 UP BND1      load_0_16_19  20
 BV BND1      arc_0_16_20
 UP BND1      load_0_16_20  20
 BV BND1      arc_0_16_21
 UP BND1      load_0_16_21  20
 BV BND1      arc_0_16_22
 UP BND1      load_0_16_22  20
 BV BND1      arc_0_17_0
 UP BND1      load_0_17_0  20
 BV BND1      arc_0_17_1
 UP BND1      load_0_17_1  20
 BV BND1      arc_0_17_2
 UP BND1      load_0_17_2  20
 BV BND1      arc_0_17_3
 UP BND1      load_0_17_3  20
 BV BND1      arc_0_17_4
 UP BND1      load_0_17_4  20
 BV BND1      arc_0_17_5
 UP BND1      load_0_17_5  20
 BV BND1      arc_0_17_6
 UP BND1      load_0_17_6  20
 BV BND1      arc_0_17_15
 UP BND1      load_0_17_15  20
 BV BND1      arc_0_17_16
 UP BND1      load_0_17_16  20
 BV BND1      arc_0_17_18
 UP BND1      load_0_17_18  20
 BV BND1      arc_0_17_19
 UP BND1      load_0_17_19  20
 BV BND1      arc_0_17_20
 UP BND1      load_0_17_20  20
 BV BND1      arc_0_17_21
 UP BND1      load_0_17_21  20
 BV BND1      arc_0_17_22
 UP BND1      load_0_17_22  20
 BV BND1      arc_0_18_0
 UP BND1      load_0_18_0  20
 BV BND1      arc_0_18_1
 UP BND1      load_0_18_1  20
 BV BND1      arc_0_18_2
 UP BND1      load_0_18_2  20
 BV BND1      arc_0_18_3
 UP BND1      load_0_18_3  20
 BV BND1      arc_0_18_4
 UP BND1      load_0_18_4  20
 BV BND1      arc_0_18_5
 UP BND1      load_0_18_5  20
 BV BND1      arc_0_18_6
 UP BND1      load_0_18_6  20
 BV BND1      arc_0_18_15
 UP BND1      load_0_18_15  20
 BV BND1      arc_0_18_16
 UP BND1      load_0_18_16  20
 BV BND1      arc_0_18_17
 UP BND1      load_0_18_17  20
 BV BND1      arc_0_18_19
 UP BND1      load_0_18_19  20
 BV BND1      arc_0_18_20
 UP BND1      load_0_18_20  20
 BV BND1      arc_0_18_21
 UP BND1      load_0_18_21  20
 BV BND1      arc_0_18_22
 UP BND1      load_0_18_22  20
 BV BND1      arc_0_19_0
 UP BND1      load_0_19_0  20
 BV BND1      arc_0_19_1
 UP BND1      load_0_19_1  20
 BV BND1      arc_0_19_2
 UP BND1      load_0_19_2  20
 BV BND1      arc_0_19_3
 UP BND1      load_0_19_3  20
 BV BND1      arc_0_19_4
 UP BND1      load_0_19_4  20
 BV BND1      arc_0_19_5
 UP BND1      load_0_19_5  20
 BV BND1      arc_0_19_6
 UP BND1      load_0_19_6  20
 BV BND1      arc_0_19_15
 UP BND1      load_0_19_15  20
 BV BND1      arc_0_19_16
 UP BND1      load_0_19_16  20
 BV BND1      arc_0_19_17
 UP BND1      load_0_19_17  20
 BV BND1      arc_0_19_18
 UP BND1      load_0_19_18  20
 BV BND1      arc_0_19_20
 UP BND1      load_0_19_20  20
 BV BND1      arc_0_19_21
 UP BND1      load_0_19_21  20
 BV BND1      arc_0_19_22
 UP BND1      load_0_19_22  20
 BV BND1      arc_0_20_0
 UP BND1      load_0_20_0  20
 BV BND1      arc_0_20_1
 UP BND1      load_0_20_1  20
 BV BND1      arc_0_20_2
 UP BND1      load_0_20_2  20
 BV BND1      arc_0_20_3
 UP BND1      load_0_20_3  20
 BV BND1      arc_0_20_4
 UP BND1      load_0_20_4  20
 BV BND1      arc_0_20_5
 UP BND1      load_0_20_5  20
 BV BND1      arc_0_20_6
 UP BND1      load_0_20_6  20
 BV BND1      arc_0_20_15
 UP BND1      load_0_20_15  20
 BV BND1      arc_0_20_16
 UP BND1      load_0_20_16  20
 BV BND1      arc_0_20_17
 UP BND1      load_0_20_17  20
 BV BND1      arc_0_20_18
 UP BND1      load_0_20_18  20
 BV BND1      arc_0_20_19
 UP BND1      load_0_20_19  20
 BV BND1      arc_0_20_21
 UP BND1      load_0_20_21  20
 BV BND1      arc_0_20_22
 UP BND1      load_0_20_22  20
 BV BND1      arc_0_21_0
 UP BND1      load_0_21_0  20
 BV BND1      arc_0_21_1
 UP BND1      load_0_21_1  20
 BV BND1      arc_0_21_2
 UP BND1      load_0_21_2  20
 BV BND1      arc_0_21_3
 UP BND1      load_0_21_3  20
 BV BND1      arc_0_21_4
 UP BND1      load_0_21_4  20
 BV BND1      arc_0_21_5
 UP BND1      load_0_21_5  20
 BV BND1      arc_0_21_6
 UP BND1      load_0_21_6  20
 BV BND1      arc_0_21_15
 UP BND1      load_0_21_15  20
 BV BND1      arc_0_21_16
 UP BND1      load_0_21_16  20
 BV BND1      arc_0_21_17
 UP BND1      load_0_21_17  20
 BV BND1      arc_0_21_18
 UP BND1      load_0_21_18  20
 BV BND1      arc_0_21_19
 UP BND1      load_0_21_19  20
 BV BND1      arc_0_21_20
 UP BND1      load_0_21_20  20
 BV BND1      arc_0_21_22
 UP BND1      load_0_21_22  20
 BV BND1      arc_0_22_0
 UP BND1      load_0_22_0  20
 BV BND1      arc_0_22_1
 UP BND1      load_0_22_1  20
 BV BND1      arc_0_22_2
 UP BND1      load_0_22_2  20
 BV BND1      arc_0_22_3
 UP BND1      load_0_22_3  20
 BV BND1      arc_0_22_4
 UP BND1      load_0_22_4  20
 BV BND1      arc_0_22_5
 UP BND1      load_0_22_5  20
 BV BND1      arc_0_22_6
 UP BND1      load_0_22_6  20
 BV BND1      arc_0_22_15
 UP BND1      load_0_22_15  20
 BV BND1      arc_0_22_16
 UP BND1      load_0_22_16  20
 BV BND1      arc_0_22_17
 UP BND1      load_0_22_17  20
 BV BND1      arc_0_22_18
 UP BND1      load_0_22_18  20
 BV BND1      arc_0_22_19
 UP BND1      load_0_22_19  20
 BV BND1      arc_0_22_20
 UP BND1      load_0_22_20  20
 BV BND1      arc_0_22_21
 UP BND1      load_0_22_21  20
 FX BND1      visit_1_7  1
 UP BND1      order_1_7  13
 FX BND1      visit_1_8  1
 UP BND1      order_1_8  13
 FX BND1      visit_1_9  1
 UP BND1      order_1_9  13
 FX BND1      visit_1_10  1
 UP BND1      order_1_10  13
 FX BND1      visit_1_11  1
 UP BND1      order_1_11  13
 UP BND1      visit_1_15  1
 UP BND1      order_1_15  13
 UP BND1      visit_1_16  1
 UP BND1      order_1_16  13
 UP BND1      visit_1_17  1
 UP BND1      order_1_17  13
 UP BND1      visit_1_18  1
 UP BND1      order_1_18  13
 UP BND1      visit_1_19  1
 UP BND1      order_1_19  13
 UP BND1      visit_1_20  1
 UP BND1      order_1_20  13
 UP BND1      visit_1_21  1
 UP BND1      order_1_21  13
 UP BND1      visit_1_22  1
 UP BND1      order_1_22  13
 BV BND1      arc_1_0_0
 FX BND1      load_1_0_0  0
 BV BND1      arc_1_0_7
 FX BND1      load_1_0_7  0
 BV BND1      arc_1_0_8
 FX BND1      load_1_0_8  0
 BV BND1      arc_1_0_9
 FX BND1      load_1_0_9  0
 BV BND1      arc_1_0_10
 FX BND1      load_1_0_10  0
 BV BND1      arc_1_0_11
 FX BND1      load_1_0_11  0
 BV BND1      arc_1_0_15
 FX BND1      load_1_0_15  0
 BV BND1      arc_1_0_16
 FX BND1      load_1_0_16  0
 BV BND1      arc_1_0_17
 FX BND1      load_1_0_17  0
 BV BND1      arc_1_0_18
 FX BND1      load_1_0_18  0
 BV BND1      arc_1_0_19
 FX BND1      load_1_0_19  0
 BV BND1      arc_1_0_20
 FX BND1      load_1_0_20  0
 BV BND1      arc_1_0_21
 FX BND1      load_1_0_21  0
 BV BND1      arc_1_0_22
 FX BND1      load_1_0_22  0
 BV BND1      arc_1_7_0
 UP BND1      load_1_7_0  25
 BV BND1      arc_1_7_8
 UP BND1      load_1_7_8  25
 BV BND1      arc_1_7_9
 UP BND1      load_1_7_9  25
 BV BND1      arc_1_7_10
 UP BND1      load_1_7_10  25
 BV BND1      arc_1_7_11
 UP BND1      load_1_7_11  25
 BV BND1      arc_1_7_15
 UP BND1      load_1_7_15  25
 BV BND1      arc_1_7_16
 UP BND1      load_1_7_16  25
 BV BND1      arc_1_7_17
 UP BND1      load_1_7_17  25
 BV BND1      arc_1_7_18
 UP BND1      load_1_7_18  25
 BV BND1      arc_1_7_19
 UP BND1      load_1_7_19  25
 BV BND1      arc_1_7_20
 UP BND1      load_1_7_20  25
 BV BND1      arc_1_7_21
 UP BND1      load_1_7_21  25
 BV BND1      arc_1_7_22
 UP BND1      load_1_7_22  25
 BV BND1      arc_1_8_0
 UP BND1      load_1_8_0  25
 BV BND1      arc_1_8_7
 UP BND1      load_1_8_7  25
 BV BND1      arc_1_8_9
 UP BND1      load_1_8_9  25
 BV BND1      arc_1_8_10
 UP BND1      load_1_8_10  25
 BV BND1      arc_1_8_11
 UP BND1      load_1_8_11  25
 BV BND1      arc_1_8_15
 UP BND1      load_1_8_15  25
 BV BND1      arc_1_8_16
 UP BND1      load_1_8_16  25
 BV BND1      arc_1_8_17
 UP BND1      load_1_8_17  25
 BV BND1      arc_1_8_18
 UP BND1      load_1_8_18  25
 BV BND1      arc_1_8_19
 UP BND1      load_1_8_19  25
 BV BND1      arc_1_8_20
 UP BND1      load_1_8_20  25
 BV BND1      arc_1_8_21
 UP BND1      load_1_8_21  25
 BV BND1      arc_1_8_22
 UP BND1      load_1_8_22  25
 BV BND1      arc_1_9_0
 UP BND1      load_1_9_0  25
 BV BND1      arc_1_9_7
 UP BND1      load_1_9_7  25
 BV BND1      arc_1_9_8
 UP BND1      load_1_9_8  25
 BV BND1      arc_1_9_10
 UP BND1      load_1_9_10  25
 BV BND1      arc_1_9_11
 UP BND1      load_1_9_11  25
 BV BND1      arc_1_9_15
 UP BND1      load_1_9_15  25
 BV BND1      arc_1_9_16
 UP BND1      load_1_9_16  25
 BV BND1      arc_1_9_17
 UP BND1      load_1_9_17  25
 BV BND1      arc_1_9_18
 UP BND1      load_1_9_18  25
 BV BND1      arc_1_9_19
 UP BND1      load_1_9_19  25
 BV BND1      arc_1_9_20
 UP BND1      load_1_9_20  25
 BV BND1      arc_1_9_21
 UP BND1      load_1_9_21  25
 BV BND1      arc_1_9_22
 UP BND1      load_1_9_22  25
 BV BND1      arc_1_10_0
 UP BND1      load_1_10_0  25
 BV BND1      arc_1_10_7
 UP BND1      load_1_10_7  25
 BV BND1      arc_1_10_8
 UP BND1      load_1_10_8  25
 BV BND1      arc_1_10_9
 UP BND1      load_1_10_9  25
 BV BND1      arc_1_10_11
 UP BND1      load_1_10_11  25
 BV BND1      arc_1_10_15
 UP BND1      load_1_10_15  25
 BV BND1      arc_1_10_16
 UP BND1      load_1_10_16  25
 BV BND1      arc_1_10_17
 UP BND1      load_1_10_17  25
 BV BND1      arc_1_10_18
 UP BND1      load_1_10_18  25
 BV BND1      arc_1_10_19
 UP BND1      load_1_10_19  25
 BV BND1      arc_1_10_20
 UP BND1      load_1_10_20  25
 BV BND1      arc_1_10_21
 UP BND1      load_1_10_21  25
 BV BND1      arc_1_10_22
 UP BND1      load_1_10_22  25
 BV BND1      arc_1_11_0
 UP BND1      load_1_11_0  25
 BV BND1      arc_1_11_7
 UP BND1      load_1_11_7  25
 BV BND1      arc_1_11_8
 UP BND1      load_1_11_8  25
 BV BND1      arc_1_11_9
 UP BND1      load_1_11_9  25
 BV BND1      arc_1_11_10
 UP BND1      load_1_11_10  25
 BV BND1      arc_1_11_15
 UP BND1      load_1_11_15  25
 BV BND1      arc_1_11_16
 UP BND1      load_1_11_16  25
 BV BND1      arc_1_11_17
 UP BND1      load_1_11_17  25
 BV BND1      arc_1_11_18
 UP BND1      load_1_11_18  25
 BV BND1      arc_1_11_19
 UP BND1      load_1_11_19  25
 BV BND1      arc_1_11_20
 UP BND1      load_1_11_20  25
 BV BND1      arc_1_11_21
 UP BND1      load_1_11_21  25
 BV BND1      arc_1_11_22
 UP BND1      load_1_11_22  25
 BV BND1      arc_1_15_0
 UP BND1      load_1_15_0  25
 BV BND1      arc_1_15_7
 UP BND1      load_1_15_7  25
 BV BND1      arc_1_15_8
 UP BND1      load_1_15_8  25
 BV BND1      arc_1_15_9
 UP BND1      load_1_15_9  25
 BV BND1      arc_1_15_10
 UP BND1      load_1_15_10  25
 BV BND1      arc_1_15_11
 UP BND1      load_1_15_11  25
 BV BND1      arc_1_15_16
 UP BND1      load_1_15_16  25
 BV BND1      arc_1_15_17
 UP BND1      load_1_15_17  25
 BV BND1      arc_1_15_18
 UP BND1      load_1_15_18  25
 BV BND1      arc_1_15_19
 UP BND1      load_1_15_19  25
 BV BND1      arc_1_15_20
 UP BND1      load_1_15_20  25
 BV BND1      arc_1_15_21
 UP BND1      load_1_15_21  25
 BV BND1      arc_1_15_22
 UP BND1      load_1_15_22  25
 BV BND1      arc_1_16_0
 UP BND1      load_1_16_0  25
 BV BND1      arc_1_16_7
 UP BND1      load_1_16_7  25
 BV BND1      arc_1_16_8
 UP BND1      load_1_16_8  25
 BV BND1      arc_1_16_9
 UP BND1      load_1_16_9  25
 BV BND1      arc_1_16_10
 UP BND1      load_1_16_10  25
 BV BND1      arc_1_16_11
 UP BND1      load_1_16_11  25
 BV BND1      arc_1_16_15
 UP BND1      load_1_16_15  25
 BV BND1      arc_1_16_17
 UP BND1      load_1_16_17  25
 BV BND1      arc_1_16_18
 UP BND1      load_1_16_18  25
 BV BND1      arc_1_16_19
 UP BND1      load_1_16_19  25
 BV BND1      arc_1_16_20
 UP BND1      load_1_16_20  25
 BV BND1      arc_1_16_21
 UP BND1      load_1_16_21  25
 BV BND1      arc_1_16_22
 UP BND1      load_1_16_22  25
 BV BND1      arc_1_17_0
 UP BND1      load_1_17_0  25
 BV BND1      arc_1_17_7
 UP BND1      load_1_17_7  25
 BV BND1      arc_1_17_8
 UP BND1      load_1_17_8  25
 BV BND1      arc_1_17_9
 UP BND1      load_1_17_9  25
 BV BND1      arc_1_17_10
 UP BND1      load_1_17_10  25
 BV BND1      arc_1_17_11
 UP BND1      load_1_17_11  25
 BV BND1      arc_1_17_15
 UP BND1      load_1_17_15  25
 BV BND1      arc_1_17_16
 UP BND1      load_1_17_16  25
 BV BND1      arc_1_17_18
 UP BND1      load_1_17_18  25
 BV BND1      arc_1_17_19
 UP BND1      load_1_17_19  25
 BV BND1      arc_1_17_20
 UP BND1      load_1_17_20  25
 BV BND1      arc_1_17_21
 UP BND1      load_1_17_21  25
 BV BND1      arc_1_17_22
 UP BND1      load_1_17_22  25
 BV BND1      arc_1_18_0
 UP BND1      load_1_18_0  25
 BV BND1      arc_1_18_7
 UP BND1      load_1_18_7  25
 BV BND1      arc_1_18_8
 UP BND1      load_1_18_8  25
 BV BND1      arc_1_18_9
 UP BND1      load_1_18_9  25
 BV BND1      arc_1_18_10
 UP BND1      load_1_18_10  25
 BV BND1      arc_1_18_11
 UP BND1      load_1_18_11  25
 BV BND1      arc_1_18_15
 UP BND1      load_1_18_15  25
 BV BND1      arc_1_18_16
 UP BND1      load_1_18_16  25
 BV BND1      arc_1_18_17
 UP BND1      load_1_18_17  25
 BV BND1      arc_1_18_19
 UP BND1      load_1_18_19  25
 BV BND1      arc_1_18_20
 UP BND1      load_1_18_20  25
 BV BND1      arc_1_18_21
 UP BND1      load_1_18_21  25
 BV BND1      arc_1_18_22
 UP BND1      load_1_18_22  25
 BV BND1      arc_1_19_0
 UP BND1      load_1_19_0  25
 BV BND1      arc_1_19_7
 UP BND1      load_1_19_7  25
 BV BND1      arc_1_19_8
 UP BND1      load_1_19_8  25
 BV BND1      arc_1_19_9
 UP BND1      load_1_19_9  25
 BV BND1      arc_1_19_10
 UP BND1      load_1_19_10  25
 BV BND1      arc_1_19_11
 UP BND1      load_1_19_11  25
 BV BND1      arc_1_19_15
 UP BND1      load_1_19_15  25
 BV BND1      arc_1_19_16
 UP BND1      load_1_19_16  25
 BV BND1      arc_1_19_17
 UP BND1      load_1_19_17  25
 BV BND1      arc_1_19_18
 UP BND1      load_1_19_18  25
 BV BND1      arc_1_19_20
 UP BND1      load_1_19_20  25
 BV BND1      arc_1_19_21
 UP BND1      load_1_19_21  25
 BV BND1      arc_1_19_22
 UP BND1      load_1_19_22  25
 BV BND1      arc_1_20_0
 UP BND1      load_1_20_0  25
 BV BND1      arc_1_20_7
 UP BND1      load_1_20_7  25
 BV BND1      arc_1_20_8
 UP BND1      load_1_20_8  25
 BV BND1      arc_1_20_9
 UP BND1      load_1_20_9  25
 BV BND1      arc_1_20_10
 UP BND1      load_1_20_10  25
 BV BND1      arc_1_20_11
 UP BND1      load_1_20_11  25
 BV BND1      arc_1_20_15
 UP BND1      load_1_20_15  25
 BV BND1      arc_1_20_16
 UP BND1      load_1_20_16  25
 BV BND1      arc_1_20_17
 UP BND1      load_1_20_17  25
 BV BND1      arc_1_20_18
 UP BND1      load_1_20_18  25
 BV BND1      arc_1_20_19
 UP BND1      load_1_20_19  25
 BV BND1      arc_1_20_21
 UP BND1      load_1_20_21  25
 BV BND1      arc_1_20_22
 UP BND1      load_1_20_22  25
 BV BND1      arc_1_21_0
 UP BND1      load_1_21_0  25
 BV BND1      arc_1_21_7
 UP BND1      load_1_21_7  25
 BV BND1      arc_1_21_8
 UP BND1      load_1_21_8  25
 BV BND1      arc_1_21_9
 UP BND1      load_1_21_9  25
 BV BND1      arc_1_21_10
 UP BND1      load_1_21_10  25
 BV BND1      arc_1_21_11
 UP BND1      load_1_21_11  25
 BV BND1      arc_1_21_15
 UP BND1      load_1_21_15  25
 BV BND1      arc_1_21_16
 UP BND1      load_1_21_16  25
 BV BND1      arc_1_21_17
 UP BND1      load_1_21_17  25
 BV BND1      arc_1_21_18
 UP BND1      load_1_21_18  25
 BV BND1      arc_1_21_19
 UP BND1      load_1_21_19  25
 BV BND1      arc_1_21_20
 UP BND1      load_1_21_20  25
 BV BND1      arc_1_21_22
 UP BND1      load_1_21_22  25
 BV BND1      arc_1_22_0
 UP BND1      load_1_22_0  25
 BV BND1      arc_1_22_7
 UP BND1      load_1_22_7  25
 BV BND1      arc_1_22_8
 UP BND1      load_1_22_8  25
 BV BND1      arc_1_22_9
 UP BND1      load_1_22_9  25
 BV BND1      arc_1_22_10
 UP BND1      load_1_22_10  25
 BV BND1      arc_1_22_11
 UP BND1      load_1_22_11  25
 BV BND1      arc_1_22_15
 UP BND1      load_1_22_15  25
 BV BND1      arc_1_22_16
 UP BND1      load_1_22_16  25
 BV BND1      arc_1_22_17
 UP BND1      load_1_22_17  25
 BV BND1      arc_1_22_18
 UP BND1      load_1_22_18  25
 BV BND1      arc_1_22_19
 UP BND1      load_1_22_19  25
 BV BND1      arc_1_22_20
 UP BND1      load_1_22_20  25
 BV BND1      arc_1_22_21
 UP BND1      load_1_22_21  25
 FX BND1      visit_2_12  1
 UP BND1      order_2_12  11
 FX BND1      visit_2_13  1
 UP BND1      order_2_13  11
 FX BND1      visit_2_14  1
 UP BND1      order_2_14  11
 UP BND1      visit_2_15  1
 UP BND1      order_2_15  11
 UP BND1      visit_2_16  1
 UP BND1      order_2_16  11
 UP BND1      visit_2_17  1
 UP BND1      order_2_17  11
 UP BND1      visit_2_18  1
 UP BND1      order_2_18  11
 UP BND1      visit_2_19  1
 UP BND1      order_2_19  11
 UP BND1      visit_2_20  1
 UP BND1      order_2_20  11
 UP BND1      visit_2_21  1
 UP BND1      order_2_21  11
 UP BND1      visit_2_22  1
 UP BND1      order_2_22  11
 BV BND1      arc_2_0_0
 FX BND1      load_2_0_0  0
 BV BND1      arc_2_0_12
 FX BND1      load_2_0_12  0
 BV BND1      arc_2_0_13
 FX BND1      load_2_0_13  0
 BV BND1      arc_2_0_14
 FX BND1      load_2_0_14  0
 BV BND1      arc_2_0_15
 FX BND1      load_2_0_15  0
 BV BND1      arc_2_0_16
 FX BND1      load_2_0_16  0
 BV BND1      arc_2_0_17
 FX BND1      load_2_0_17  0
 BV BND1      arc_2_0_18
 FX BND1      load_2_0_18  0
 BV BND1      arc_2_0_19
 FX BND1      load_2_0_19  0
 BV BND1      arc_2_0_20
 FX BND1      load_2_0_20  0
 BV BND1      arc_2_0_21
 FX BND1      load_2_0_21  0
 BV BND1      arc_2_0_22
 FX BND1      load_2_0_22  0
 BV BND1      arc_2_12_0
 UP BND1      load_2_12_0  30
 BV BND1      arc_2_12_13
 UP BND1      load_2_12_13  30
 BV BND1      arc_2_12_14
 UP BND1      load_2_12_14  30
 BV BND1      arc_2_12_15
 UP BND1      load_2_12_15  30
 BV BND1      arc_2_12_16
 UP BND1      load_2_12_16  30
 BV BND1      arc_2_12_17
 UP BND1      load_2_12_17  30
 BV BND1      arc_2_12_18
 UP BND1      load_2_12_18  30
 BV BND1      arc_2_12_19
 UP BND1      load_2_12_19  30
 BV BND1      arc_2_12_20
 UP BND1      load_2_12_20  30
 BV BND1      arc_2_12_21
 UP BND1      load_2_12_21  30
 BV BND1      arc_2_12_22
 UP BND1      load_2_12_22  30
 BV BND1      arc_2_13_0
 UP BND1      load_2_13_0  30
 BV BND1      arc_2_13_12
 UP BND1      load_2_13_12  30
 BV BND1      arc_2_13_14
 UP BND1      load_2_13_14  30
 BV BND1      arc_2_13_15
 UP BND1      load_2_13_15  30
 BV BND1      arc_2_13_16
 UP BND1      load_2_13_16  30
 BV BND1      arc_2_13_17
 UP BND1      load_2_13_17  30
 BV BND1      arc_2_13_18
 UP BND1      load_2_13_18  30
 BV BND1      arc_2_13_19
 UP BND1      load_2_13_19  30
 BV BND1      arc_2_13_20
 UP BND1      load_2_13_20  30
 BV BND1      arc_2_13_21
 UP BND1      load_2_13_21  30
 BV BND1      arc_2_13_22
 UP BND1      load_2_13_22  30
 BV BND1      arc_2_14_0
 UP BND1      load_2_14_0  30
 BV BND1      arc_2_14_12
 UP BND1      load_2_14_12  30
 BV BND1      arc_2_14_13
 UP BND1      load_2_14_13  30
 BV BND1      arc_2_14_15
 UP BND1      load_2_14_15  30
 BV BND1      arc_2_14_16
 UP BND1      load_2_14_16  30
 BV BND1      arc_2_14_17
 UP BND1      load_2_14_17  30
 BV BND1      arc_2_14_18
 UP BND1      load_2_14_18  30
 BV BND1      arc_2_14_19
 UP BND1      load_2_14_19  30
 BV BND1      arc_2_14_20
 UP BND1      load_2_14_20  30
 BV BND1      arc_2_14_21
 UP BND1      load_2_14_21  30
 BV BND1      arc_2_14_22
 UP BND1      load_2_14_22  30
 BV BND1      arc_2_15_0
 UP BND1      load_2_15_0  30
 BV BND1      arc_2_15_12
 UP BND1      load_2_15_12  30
 BV BND1      arc_2_15_13
 UP BND1      load_2_15_13  30
 BV BND1      arc_2_15_14
 UP BND1      load_2_15_14  30
 BV BND1      arc_2_15_16
 UP BND1      load_2_15_16  30
 BV BND1      arc_2_15_17
 UP BND1      load_2_15_17  30
 BV BND1      arc_2_15_18
 UP BND1      load_2_15_18  30
 BV BND1      arc_2_15_19
 UP BND1      load_2_15_19  30
 BV BND1      arc_2_15_20
 UP BND1      load_2_15_20  30
 BV BND1      arc_2_15_21
 UP BND1      load_2_15_21  30
 BV BND1      arc_2_15_22
 UP BND1      load_2_15_22  30
 BV BND1      arc_2_16_0
 UP BND1      load_2_16_0  30
 BV BND1      arc_2_16_12
 UP BND1      load_2_16_12  30
 BV BND1      arc_2_16_13
 UP BND1      load_2_16_13  30
 BV BND1      arc_2_16_14
 UP BND1      load_2_16_14  30
 BV BND1      arc_2_16_15
 UP BND1      load_2_16_15  30
 BV BND1      arc_2_16_17
 UP BND1      load_2_16_17  30
 BV BND1      arc_2_16_18
 UP BND1      load_2_16_18  30
 BV BND1      arc_2_16_19
 UP BND1      load_2_16_19  30
 BV BND1      arc_2_16_20
 UP BND1      load_2_16_20  30
 BV BND1      arc_2_16_21
 UP BND1      load_2_16_21  30
 BV BND1      arc_2_16_22
 UP BND1      load_2_16_22  30
 BV BND1      arc_2_17_0
 UP BND1      load_2_17_0  30
 BV BND1      arc_2_17_12
 UP BND1      load_2_17_12  30
 BV BND1      arc_2_17_13
 UP BND1      load_2_17_13  30
 BV BND1      arc_2_17_14
 UP BND1      load_2_17_14  30
 BV BND1      arc_2_17_15
 UP BND1      load_2_17_15  30
 BV BND1      arc_2_17_16
 UP BND1      load_2_17_16  30
 BV BND1      arc_2_17_18
 UP BND1      load_2_17_18  30
 BV BND1      arc_2_17_19
 UP BND1      load_2_17_19  30
 BV BND1      arc_2_17_20
 UP BND1      load_2_17_20  30
 BV BND1      arc_2_17_21
 UP BND1      load_2_17_21  30
 BV BND1      arc_2_17_22
 UP BND1      load_2_17_22  30
 BV BND1      arc_2_18_0
 UP BND1      load_2_18_0  30
 BV BND1      arc_2_18_12
 UP BND1      load_2_18_12  30
 BV BND1      arc_2_18_13
 UP BND1      load_2_18_13  30
 BV BND1      arc_2_18_14
 UP BND1      load_2_18_14  30
 BV BND1      arc_2_18_15
 UP BND1      load_2_18_15  30
 BV BND1      arc_2_18_16
 UP BND1      load_2_18_16  30
 BV BND1      arc_2_18_17
 UP BND1      load_2_18_17  30
 BV BND1      arc_2_18_19
 UP BND1      load_2_18_19  30
 BV BND1      arc_2_18_20
 UP BND1      load_2_18_20  30
 BV BND1      arc_2_18_21
 UP BND1      load_2_18_21  30
 BV BND1      arc_2_18_22
 UP BND1      load_2_18_22  30
 BV BND1      arc_2_19_0
 UP BND1      load_2_19_0  30
 BV BND1      arc_2_19_12
 UP BND1      load_2_19_12  30
 BV BND1      arc_2_19_13
 UP BND1      load_2_19_13  30
 BV BND1      arc_2_19_14
 UP BND1      load_2_19_14  30
 BV BND1      arc_2_19_15
 UP BND1      load_2_19_15  30
 BV BND1      arc_2_19_16
 UP BND1      load_2_19_16  30
 BV BND1      arc_2_19_17
 UP BND1      load_2_19_17  30
 BV BND1      arc_2_19_18
 UP BND1      load_2_19_18  30
 BV BND1      arc_2_19_20
 UP BND1      load_2_19_20  30
 BV BND1      arc_2_19_21
 UP BND1      load_2_19_21  30
 BV BND1      arc_2_19_22
 UP BND1      load_2_19_22  30
 BV BND1      arc_2_20_0
 UP BND1      load_2_20_0  30
 BV BND1      arc_2_20_12
 UP BND1      load_2_20_12  30
 BV BND1      arc_2_20_13
 UP BND1      load_2_20_13  30
 BV BND1      arc_2_20_14
 UP BND1      load_2_20_14  30
 BV BND1      arc_2_20_15
 UP BND1      load_2_20_15  30
 BV BND1      arc_2_20_16
 UP BND1      load_2_20_16  30
 BV BND1      arc_2_20_17
 UP BND1      load_2_20_17  30
 BV BND1      arc_2_20_18
 UP BND1      load_2_20_18  30
 BV BND1      arc_2_20_19
 UP BND1      load_2_20_19  30
 BV BND1      arc_2_20_21
 UP BND1      load_2_20_21  30
 BV BND1      arc_2_20_22
 UP BND1      load_2_20_22  30
 BV BND1      arc_2_21_0
 UP BND1      load_2_21_0  30
 BV BND1      arc_2_21_12
 UP BND1      load_2_21_12  30
 BV BND1      arc_2_21_13
 UP BND1      load_2_21_13  30
 BV BND1      arc_2_21_14
 UP BND1      load_2_21_14  30
 BV BND1      arc_2_21_15
 UP BND1      load_2_21_15  30
 BV BND1      arc_2_21_16
 UP BND1      load_2_21_16  30
 BV BND1      arc_2_21_17
 UP BND1      load_2_21_17  30
 BV BND1      arc_2_21_18
 UP BND1      load_2_21_18  30
 BV BND1      arc_2_21_19
 UP BND1      load_2_21_19  30
 BV BND1      arc_2_21_20
 UP BND1      load_2_21_20  30
 BV BND1      arc_2_21_22
 UP BND1      load_2_21_22  30
 BV BND1      arc_2_22_0
 UP BND1      load_2_22_0  30
 BV BND1      arc_2_22_12
 UP BND1      load_2_22_12  30
 BV BND1      arc_2_22_13
 UP BND1      load_2_22_13  30
 BV BND1      arc_2_22_14
 UP BND1      load_2_22_14  30
 BV BND1      arc_2_22_15
 UP BND1      load_2_22_15  30
 BV BND1      arc_2_22_16
 UP BND1      load_2_22_16  30
 BV BND1      arc_2_22_17
 UP BND1      load_2_22_17  30
 BV BND1      arc_2_22_18
 UP BND1      load_2_22_18  30
 BV BND1      arc_2_22_19
 UP BND1      load_2_22_19  30
 BV BND1      arc_2_22_20
 UP BND1      load_2_22_20  30
 BV BND1      arc_2_22_21
 UP BND1      load_2_22_21  30
ENDATA
