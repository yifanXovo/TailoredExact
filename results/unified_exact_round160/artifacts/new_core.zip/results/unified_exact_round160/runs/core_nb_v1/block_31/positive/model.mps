* Signature: 0xf99287c7d930c179
NAME R160_physical_neighborhood
ROWS
 N  OBJ
 G  product_lb_0
 L  product_ub_1
 G  product_lb_2
 L  product_ub_3
 G  product_lb_4
 L  product_ub_5
 G  product_lb_6
 L  product_ub_7
 G  product_lb_8
 L  product_ub_9
 G  product_lb_10
 L  product_ub_11
 G  product_lb_12
 L  product_ub_13
 G  product_lb_14
 L  product_ub_15
 G  product_lb_16
 L  product_ub_17
 G  product_lb_18
 L  product_ub_19
 G  product_lb_20
 L  product_ub_21
 G  product_lb_22
 L  product_ub_23
 G  product_lb_24
 L  product_ub_25
 G  product_lb_26
 L  product_ub_27
 G  product_lb_28
 L  product_ub_29
 G  product_lb_30
 L  product_ub_31
 E  onehot_27_32
 E  normalized_mass_27_33
 E  normalized_ratio_27_34
 G  product_lb_35
 L  product_ub_36
 G  product_lb_37
 L  product_ub_38
 G  product_lb_39
 L  product_ub_40
 G  product_lb_41
 L  product_ub_42
 G  product_lb_43
 L  product_ub_44
 G  product_lb_45
 L  product_ub_46
 G  product_lb_47
 L  product_ub_48
 G  product_lb_49
 L  product_ub_50
 G  product_lb_51
 L  product_ub_52
 G  product_lb_53
 L  product_ub_54
 G  product_lb_55
 L  product_ub_56
 G  product_lb_57
 L  product_ub_58
 G  product_lb_59
 L  product_ub_60
 G  product_lb_61
 L  product_ub_62
 G  product_lb_63
 L  product_ub_64
 G  product_lb_65
 L  product_ub_66
 E  onehot_24_67
 E  normalized_mass_24_68
 E  normalized_ratio_24_69
 G  product_lb_70
 L  product_ub_71
 G  product_lb_72
 L  product_ub_73
 G  product_lb_74
 L  product_ub_75
 G  product_lb_76
 L  product_ub_77
 G  product_lb_78
 L  product_ub_79
 G  product_lb_80
 L  product_ub_81
 G  product_lb_82
 L  product_ub_83
 G  product_lb_84
 L  product_ub_85
 G  product_lb_86
 L  product_ub_87
 G  product_lb_88
 L  product_ub_89
 G  product_lb_90
 L  product_ub_91
 G  product_lb_92
 L  product_ub_93
 G  product_lb_94
 L  product_ub_95
 E  onehot_31_96
 E  normalized_mass_31_97
 E  normalized_ratio_31_98
 G  product_lb_99
 L  product_ub_100
 G  product_lb_101
 L  product_ub_102
 G  product_lb_103
 L  product_ub_104
 G  product_lb_105
 L  product_ub_106
 G  product_lb_107
 L  product_ub_108
 G  product_lb_109
 L  product_ub_110
 G  product_lb_111
 L  product_ub_112
 G  product_lb_113
 L  product_ub_114
 G  product_lb_115
 L  product_ub_116
 G  product_lb_117
 L  product_ub_118
 G  product_lb_119
 L  product_ub_120
 G  product_lb_121
 L  product_ub_122
 E  onehot_34_123
 E  normalized_mass_34_124
 E  normalized_ratio_34_125
 G  product_lb_126
 L  product_ub_127
 G  product_lb_128
 L  product_ub_129
 G  product_lb_130
 L  product_ub_131
 G  product_lb_132
 L  product_ub_133
 G  product_lb_134
 L  product_ub_135
 G  product_lb_136
 L  product_ub_137
 G  product_lb_138
 L  product_ub_139
 G  product_lb_140
 L  product_ub_141
 G  product_lb_142
 L  product_ub_143
 G  product_lb_144
 L  product_ub_145
 G  product_lb_146
 L  product_ub_147
 G  product_lb_148
 L  product_ub_149
 G  product_lb_150
 L  product_ub_151
 E  onehot_16_152
 E  normalized_mass_16_153
 E  normalized_ratio_16_154
 G  product_lb_155
 L  product_ub_156
 G  product_lb_157
 L  product_ub_158
 G  product_lb_159
 L  product_ub_160
 G  product_lb_161
 L  product_ub_162
 G  product_lb_163
 L  product_ub_164
 G  product_lb_165
 L  product_ub_166
 G  product_lb_167
 L  product_ub_168
 G  product_lb_169
 L  product_ub_170
 G  product_lb_171
 L  product_ub_172
 G  product_lb_173
 L  product_ub_174
 G  product_lb_175
 L  product_ub_176
 G  product_lb_177
 L  product_ub_178
 G  product_lb_179
 L  product_ub_180
 G  product_lb_181
 L  product_ub_182
 G  product_lb_183
 L  product_ub_184
 G  product_lb_185
 L  product_ub_186
 E  onehot_29_187
 E  normalized_mass_29_188
 E  normalized_ratio_29_189
 G  product_lb_190
 L  product_ub_191
 G  product_lb_192
 L  product_ub_193
 G  product_lb_194
 L  product_ub_195
 G  product_lb_196
 L  product_ub_197
 G  product_lb_198
 L  product_ub_199
 G  product_lb_200
 L  product_ub_201
 G  product_lb_202
 L  product_ub_203
 G  product_lb_204
 L  product_ub_205
 G  product_lb_206
 L  product_ub_207
 G  product_lb_208
 L  product_ub_209
 G  product_lb_210
 L  product_ub_211
 G  product_lb_212
 L  product_ub_213
 G  product_lb_214
 L  product_ub_215
 E  onehot_32_216
 E  normalized_mass_32_217
 E  normalized_ratio_32_218
 G  product_lb_219
 L  product_ub_220
 G  product_lb_221
 L  product_ub_222
 G  product_lb_223
 L  product_ub_224
 G  product_lb_225
 L  product_ub_226
 G  product_lb_227
 L  product_ub_228
 G  product_lb_229
 L  product_ub_230
 G  product_lb_231
 L  product_ub_232
 G  product_lb_233
 L  product_ub_234
 G  product_lb_235
 L  product_ub_236
 G  product_lb_237
 L  product_ub_238
 G  product_lb_239
 L  product_ub_240
 G  product_lb_241
 L  product_ub_242
 G  product_lb_243
 L  product_ub_244
 G  product_lb_245
 L  product_ub_246
 G  product_lb_247
 L  product_ub_248
 G  product_lb_249
 L  product_ub_250
 G  product_lb_251
 L  product_ub_252
 E  onehot_33_253
 E  normalized_mass_33_254
 E  normalized_ratio_33_255
 G  stock_lb_256
 L  stock_ub_257
 L  parent_nonstrict_scope_258
 G  block_pair_pos_259
 G  block_pair_neg_260
 G  block_pair_pos_261
 G  block_pair_neg_262
 G  block_pair_pos_263
 G  block_pair_neg_264
 G  block_pair_pos_265
 G  block_pair_neg_266
 G  block_pair_pos_267
 G  block_pair_neg_268
 G  block_pair_pos_269
 G  block_pair_neg_270
 G  block_pair_pos_271
 G  block_pair_neg_272
 G  block_pair_pos_273
 G  block_pair_neg_274
 G  block_pair_pos_275
 G  block_pair_neg_276
 G  block_pair_pos_277
 G  block_pair_neg_278
 G  block_pair_pos_279
 G  block_pair_neg_280
 G  block_pair_pos_281
 G  block_pair_neg_282
 G  block_pair_pos_283
 G  block_pair_neg_284
 G  block_pair_pos_285
 G  block_pair_neg_286
 G  block_pair_pos_287
 G  block_pair_neg_288
 G  block_pair_pos_289
 G  block_pair_neg_290
 G  block_pair_pos_291
 G  block_pair_neg_292
 G  block_pair_pos_293
 G  block_pair_neg_294
 G  block_pair_pos_295
 G  block_pair_neg_296
 G  block_pair_pos_297
 G  block_pair_neg_298
 G  block_pair_pos_299
 G  block_pair_neg_300
 G  block_pair_pos_301
 G  block_pair_neg_302
 G  block_pair_pos_303
 G  block_pair_neg_304
 G  block_pair_pos_305
 G  block_pair_neg_306
 G  block_pair_pos_307
 G  block_pair_neg_308
 G  block_pair_pos_309
 G  block_pair_neg_310
 G  block_pair_pos_311
 G  block_pair_neg_312
 G  block_pair_pos_313
 G  block_pair_neg_314
 E  normalization_315
 G  full_original_Gini_316
 E  unique_nonzero_owner_317
 E  unique_nonzero_owner_318
 E  unique_nonzero_owner_319
 E  unique_nonzero_owner_320
 E  unique_nonzero_owner_321
 E  unique_nonzero_owner_322
 E  unique_nonzero_owner_323
 E  unique_nonzero_owner_324
 E  unique_nonzero_owner_325
 E  unique_nonzero_owner_326
 E  unique_nonzero_owner_327
 E  unique_nonzero_owner_328
 E  unique_nonzero_owner_329
 E  unique_nonzero_owner_330
 E  unique_nonzero_owner_331
 E  unique_nonzero_owner_332
 E  unique_nonzero_owner_333
 E  unique_nonzero_owner_334
 E  unique_nonzero_owner_335
 E  unique_nonzero_owner_336
 E  unique_nonzero_owner_337
 E  unique_nonzero_owner_338
 E  unique_nonzero_owner_339
 E  unique_nonzero_owner_340
 E  unique_nonzero_owner_341
 E  unique_nonzero_owner_342
 E  unique_nonzero_owner_343
 E  unique_nonzero_owner_344
 E  unique_nonzero_owner_345
 E  unique_nonzero_owner_346
 E  unique_nonzero_owner_347
 E  unique_nonzero_owner_348
 E  unique_nonzero_owner_349
 E  unique_nonzero_owner_350
 E  unique_nonzero_owner_351
 E  unique_nonzero_owner_352
 E  unique_nonzero_owner_353
 E  unique_nonzero_owner_354
 E  unique_nonzero_owner_355
 E  unique_nonzero_owner_356
 E  unique_nonzero_owner_357
 E  unique_nonzero_owner_358
 E  unique_nonzero_owner_359
 E  unique_nonzero_owner_360
 E  unique_nonzero_owner_361
 E  unique_nonzero_owner_362
 E  unique_nonzero_owner_363
 E  unique_nonzero_owner_364
 E  unique_nonzero_owner_365
 E  unique_nonzero_owner_366
 E  unique_nonzero_owner_367
 E  unique_nonzero_owner_368
 E  unique_nonzero_owner_369
 E  unique_nonzero_owner_370
 E  unique_nonzero_owner_371
 E  unique_nonzero_owner_372
 E  unique_nonzero_owner_373
 E  unique_nonzero_owner_374
 E  unique_nonzero_owner_375
 E  unique_nonzero_owner_376
 E  unique_nonzero_owner_377
 E  unique_nonzero_owner_378
 E  unique_nonzero_owner_379
 E  unique_nonzero_owner_380
 E  unique_nonzero_owner_381
 E  unique_nonzero_owner_382
 E  unique_nonzero_owner_383
 E  unique_nonzero_owner_384
 E  unique_nonzero_owner_385
 E  unique_nonzero_owner_386
 E  unique_nonzero_owner_387
 E  unique_nonzero_owner_388
 E  unique_nonzero_owner_389
 E  unique_nonzero_owner_390
 E  unique_nonzero_owner_391
 E  unique_nonzero_owner_392
 E  unique_nonzero_owner_393
 E  unique_nonzero_owner_394
 E  unique_nonzero_owner_395
 E  unique_nonzero_owner_396
 E  unique_nonzero_owner_397
 E  unique_nonzero_owner_398
 E  unique_nonzero_owner_399
 E  unique_nonzero_owner_400
 E  unique_nonzero_owner_401
 E  unique_nonzero_owner_402
 E  unique_nonzero_owner_403
 E  unique_nonzero_owner_404
 E  unique_nonzero_owner_405
 E  unique_nonzero_owner_406
 E  unique_nonzero_owner_407
 E  unique_nonzero_owner_408
 E  unique_nonzero_owner_409
 E  unique_nonzero_owner_410
 E  unique_nonzero_owner_411
 E  unique_nonzero_owner_412
 E  unique_nonzero_owner_413
 E  unique_nonzero_owner_414
 E  unique_nonzero_owner_415
 E  unique_nonzero_owner_416
 E  unique_nonzero_owner_417
 E  unique_nonzero_owner_418
 E  unique_nonzero_owner_419
 E  unique_nonzero_owner_420
 E  unique_nonzero_owner_421
 E  unique_nonzero_owner_422
 E  unique_nonzero_owner_423
 E  unique_nonzero_owner_424
 L  arc_capacity_425
 L  arc_capacity_426
 L  arc_capacity_427
 L  arc_capacity_428
 L  arc_capacity_429
 L  arc_capacity_430
 L  arc_capacity_431
 L  arc_capacity_432
 L  arc_capacity_433
 L  arc_capacity_434
 L  arc_capacity_435
 L  arc_capacity_436
 L  arc_capacity_437
 L  arc_capacity_438
 L  arc_capacity_439
 G  connected_order_arc_440
 L  arc_capacity_441
 G  connected_order_arc_442
 L  arc_capacity_443
 G  connected_order_arc_444
 L  arc_capacity_445
 G  connected_order_arc_446
 L  arc_capacity_447
 G  connected_order_arc_448
 L  arc_capacity_449
 G  connected_order_arc_450
 L  arc_capacity_451
 G  connected_order_arc_452
 L  arc_capacity_453
 G  connected_order_arc_454
 L  arc_capacity_455
 G  connected_order_arc_456
 L  arc_capacity_457
 G  connected_order_arc_458
 L  arc_capacity_459
 G  connected_order_arc_460
 L  arc_capacity_461
 L  arc_capacity_462
 G  connected_order_arc_463
 L  arc_capacity_464
 G  connected_order_arc_465
 L  arc_capacity_466
 G  connected_order_arc_467
 L  arc_capacity_468
 G  connected_order_arc_469
 L  arc_capacity_470
 G  connected_order_arc_471
 L  arc_capacity_472
 G  connected_order_arc_473
 L  arc_capacity_474
 G  connected_order_arc_475
 L  arc_capacity_476
 G  connected_order_arc_477
 L  arc_capacity_478
 G  connected_order_arc_479
 L  arc_capacity_480
 G  connected_order_arc_481
 L  arc_capacity_482
 G  connected_order_arc_483
 L  arc_capacity_484
 L  arc_capacity_485
 G  connected_order_arc_486
 L  arc_capacity_487
 G  connected_order_arc_488
 L  arc_capacity_489
 G  connected_order_arc_490
 L  arc_capacity_491
 G  connected_order_arc_492
 L  arc_capacity_493
 G  connected_order_arc_494
 L  arc_capacity_495
 G  connected_order_arc_496
 L  arc_capacity_497
 G  connected_order_arc_498
 L  arc_capacity_499
 G  connected_order_arc_500
 L  arc_capacity_501
 G  connected_order_arc_502
 L  arc_capacity_503
 G  connected_order_arc_504
 L  arc_capacity_505
 G  connected_order_arc_506
 L  arc_capacity_507
 L  arc_capacity_508
 G  connected_order_arc_509
 L  arc_capacity_510
 G  connected_order_arc_511
 L  arc_capacity_512
 G  connected_order_arc_513
 L  arc_capacity_514
 G  connected_order_arc_515
 L  arc_capacity_516
 G  connected_order_arc_517
 L  arc_capacity_518
 G  connected_order_arc_519
 L  arc_capacity_520
 G  connected_order_arc_521
 L  arc_capacity_522
 G  connected_order_arc_523
 L  arc_capacity_524
 G  connected_order_arc_525
 L  arc_capacity_526
 G  connected_order_arc_527
 L  arc_capacity_528
 G  connected_order_arc_529
 L  arc_capacity_530
 L  arc_capacity_531
 G  connected_order_arc_532
 L  arc_capacity_533
 G  connected_order_arc_534
 L  arc_capacity_535
 G  connected_order_arc_536
 L  arc_capacity_537
 G  connected_order_arc_538
 L  arc_capacity_539
 G  connected_order_arc_540
 L  arc_capacity_541
 G  connected_order_arc_542
 L  arc_capacity_543
 G  connected_order_arc_544
 L  arc_capacity_545
 G  connected_order_arc_546
 L  arc_capacity_547
 G  connected_order_arc_548
 L  arc_capacity_549
 G  connected_order_arc_550
 L  arc_capacity_551
 G  connected_order_arc_552
 L  arc_capacity_553
 L  arc_capacity_554
 G  connected_order_arc_555
 L  arc_capacity_556
 G  connected_order_arc_557
 L  arc_capacity_558
 G  connected_order_arc_559
 L  arc_capacity_560
 G  connected_order_arc_561
 L  arc_capacity_562
 G  connected_order_arc_563
 L  arc_capacity_564
 G  connected_order_arc_565
 L  arc_capacity_566
 G  connected_order_arc_567
 L  arc_capacity_568
 G  connected_order_arc_569
 L  arc_capacity_570
 G  connected_order_arc_571
 L  arc_capacity_572
 G  connected_order_arc_573
 L  arc_capacity_574
 G  connected_order_arc_575
 L  arc_capacity_576
 L  arc_capacity_577
 G  connected_order_arc_578
 L  arc_capacity_579
 G  connected_order_arc_580
 L  arc_capacity_581
 G  connected_order_arc_582
 L  arc_capacity_583
 G  connected_order_arc_584
 L  arc_capacity_585
 G  connected_order_arc_586
 L  arc_capacity_587
 G  connected_order_arc_588
 L  arc_capacity_589
 G  connected_order_arc_590
 L  arc_capacity_591
 G  connected_order_arc_592
 L  arc_capacity_593
 G  connected_order_arc_594
 L  arc_capacity_595
 G  connected_order_arc_596
 L  arc_capacity_597
 G  connected_order_arc_598
 L  arc_capacity_599
 L  arc_capacity_600
 G  connected_order_arc_601
 L  arc_capacity_602
 G  connected_order_arc_603
 L  arc_capacity_604
 G  connected_order_arc_605
 L  arc_capacity_606
 G  connected_order_arc_607
 L  arc_capacity_608
 G  connected_order_arc_609
 L  arc_capacity_610
 G  connected_order_arc_611
 L  arc_capacity_612
 G  connected_order_arc_613
 L  arc_capacity_614
 G  connected_order_arc_615
 L  arc_capacity_616
 G  connected_order_arc_617
 L  arc_capacity_618
 G  connected_order_arc_619
 L  arc_capacity_620
 G  connected_order_arc_621
 L  arc_capacity_622
 L  arc_capacity_623
 G  connected_order_arc_624
 L  arc_capacity_625
 G  connected_order_arc_626
 L  arc_capacity_627
 G  connected_order_arc_628
 L  arc_capacity_629
 G  connected_order_arc_630
 L  arc_capacity_631
 G  connected_order_arc_632
 L  arc_capacity_633
 G  connected_order_arc_634
 L  arc_capacity_635
 G  connected_order_arc_636
 L  arc_capacity_637
 G  connected_order_arc_638
 L  arc_capacity_639
 G  connected_order_arc_640
 L  arc_capacity_641
 G  connected_order_arc_642
 L  arc_capacity_643
 G  connected_order_arc_644
 L  arc_capacity_645
 L  arc_capacity_646
 G  connected_order_arc_647
 L  arc_capacity_648
 G  connected_order_arc_649
 L  arc_capacity_650
 G  connected_order_arc_651
 L  arc_capacity_652
 G  connected_order_arc_653
 L  arc_capacity_654
 G  connected_order_arc_655
 L  arc_capacity_656
 G  connected_order_arc_657
 L  arc_capacity_658
 G  connected_order_arc_659
 L  arc_capacity_660
 G  connected_order_arc_661
 L  arc_capacity_662
 G  connected_order_arc_663
 L  arc_capacity_664
 G  connected_order_arc_665
 L  arc_capacity_666
 G  connected_order_arc_667
 L  arc_capacity_668
 L  arc_capacity_669
 G  connected_order_arc_670
 L  arc_capacity_671
 G  connected_order_arc_672
 L  arc_capacity_673
 G  connected_order_arc_674
 L  arc_capacity_675
 G  connected_order_arc_676
 L  arc_capacity_677
 G  connected_order_arc_678
 L  arc_capacity_679
 G  connected_order_arc_680
 L  arc_capacity_681
 G  connected_order_arc_682
 L  arc_capacity_683
 G  connected_order_arc_684
 L  arc_capacity_685
 G  connected_order_arc_686
 L  arc_capacity_687
 G  connected_order_arc_688
 L  arc_capacity_689
 G  connected_order_arc_690
 L  arc_capacity_691
 L  arc_capacity_692
 G  connected_order_arc_693
 L  arc_capacity_694
 G  connected_order_arc_695
 L  arc_capacity_696
 G  connected_order_arc_697
 L  arc_capacity_698
 G  connected_order_arc_699
 L  arc_capacity_700
 G  connected_order_arc_701
 L  arc_capacity_702
 G  connected_order_arc_703
 L  arc_capacity_704
 G  connected_order_arc_705
 L  arc_capacity_706
 G  connected_order_arc_707
 L  arc_capacity_708
 G  connected_order_arc_709
 L  arc_capacity_710
 G  connected_order_arc_711
 L  arc_capacity_712
 G  connected_order_arc_713
 E  depot_departure_or_bypass_714
 E  depot_return_or_bypass_715
 E  out_degree_716
 E  in_degree_717
 G  order_active_lb_718
 L  order_active_ub_719
 E  segment_load_conservation_720
 G  segment_prefix_lb_721
 L  segment_prefix_ub_722
 E  out_degree_723
 E  in_degree_724
 G  order_active_lb_725
 L  order_active_ub_726
 E  segment_load_conservation_727
 G  segment_prefix_lb_728
 L  segment_prefix_ub_729
 E  out_degree_730
 E  in_degree_731
 G  order_active_lb_732
 L  order_active_ub_733
 E  segment_load_conservation_734
 G  segment_prefix_lb_735
 L  segment_prefix_ub_736
 E  out_degree_737
 E  in_degree_738
 G  order_active_lb_739
 L  order_active_ub_740
 E  segment_load_conservation_741
 G  segment_prefix_lb_742
 L  segment_prefix_ub_743
 E  out_degree_744
 E  in_degree_745
 G  order_active_lb_746
 L  order_active_ub_747
 E  service_visit_def_748
 E  free_load_conservation_749
 E  out_degree_750
 E  in_degree_751
 G  order_active_lb_752
 L  order_active_ub_753
 E  service_visit_def_754
 E  free_load_conservation_755
 E  out_degree_756
 E  in_degree_757
 G  order_active_lb_758
 L  order_active_ub_759
 E  service_visit_def_760
 E  free_load_conservation_761
 E  out_degree_762
 E  in_degree_763
 G  order_active_lb_764
 L  order_active_ub_765
 E  service_visit_def_766
 E  free_load_conservation_767
 E  out_degree_768
 E  in_degree_769
 G  order_active_lb_770
 L  order_active_ub_771
 E  service_visit_def_772
 E  free_load_conservation_773
 E  out_degree_774
 E  in_degree_775
 G  order_active_lb_776
 L  order_active_ub_777
 E  service_visit_def_778
 E  free_load_conservation_779
 E  out_degree_780
 E  in_degree_781
 G  order_active_lb_782
 L  order_active_ub_783
 E  service_visit_def_784
 E  free_load_conservation_785
 E  out_degree_786
 E  in_degree_787
 G  order_active_lb_788
 L  order_active_ub_789
 E  service_visit_def_790
 E  free_load_conservation_791
 G  fixed_segment_relative_order_792
 G  fixed_segment_relative_order_793
 G  fixed_segment_relative_order_794
 L  original_T_including_depot_unload_795
 L  arc_capacity_796
 L  arc_capacity_797
 L  arc_capacity_798
 L  arc_capacity_799
 L  arc_capacity_800
 L  arc_capacity_801
 L  arc_capacity_802
 L  arc_capacity_803
 L  arc_capacity_804
 L  arc_capacity_805
 L  arc_capacity_806
 L  arc_capacity_807
 L  arc_capacity_808
 L  arc_capacity_809
 L  arc_capacity_810
 L  arc_capacity_811
 L  arc_capacity_812
 G  connected_order_arc_813
 L  arc_capacity_814
 G  connected_order_arc_815
 L  arc_capacity_816
 G  connected_order_arc_817
 L  arc_capacity_818
 G  connected_order_arc_819
 L  arc_capacity_820
 G  connected_order_arc_821
 L  arc_capacity_822
 G  connected_order_arc_823
 L  arc_capacity_824
 G  connected_order_arc_825
 L  arc_capacity_826
 G  connected_order_arc_827
 L  arc_capacity_828
 G  connected_order_arc_829
 L  arc_capacity_830
 G  connected_order_arc_831
 L  arc_capacity_832
 G  connected_order_arc_833
 L  arc_capacity_834
 G  connected_order_arc_835
 L  arc_capacity_836
 G  connected_order_arc_837
 L  arc_capacity_838
 L  arc_capacity_839
 G  connected_order_arc_840
 L  arc_capacity_841
 G  connected_order_arc_842
 L  arc_capacity_843
 G  connected_order_arc_844
 L  arc_capacity_845
 G  connected_order_arc_846
 L  arc_capacity_847
 G  connected_order_arc_848
 L  arc_capacity_849
 G  connected_order_arc_850
 L  arc_capacity_851
 G  connected_order_arc_852
 L  arc_capacity_853
 G  connected_order_arc_854
 L  arc_capacity_855
 G  connected_order_arc_856
 L  arc_capacity_857
 G  connected_order_arc_858
 L  arc_capacity_859
 G  connected_order_arc_860
 L  arc_capacity_861
 G  connected_order_arc_862
 L  arc_capacity_863
 G  connected_order_arc_864
 L  arc_capacity_865
 L  arc_capacity_866
 G  connected_order_arc_867
 L  arc_capacity_868
 G  connected_order_arc_869
 L  arc_capacity_870
 G  connected_order_arc_871
 L  arc_capacity_872
 G  connected_order_arc_873
 L  arc_capacity_874
 G  connected_order_arc_875
 L  arc_capacity_876
 G  connected_order_arc_877
 L  arc_capacity_878
 G  connected_order_arc_879
 L  arc_capacity_880
 G  connected_order_arc_881
 L  arc_capacity_882
 G  connected_order_arc_883
 L  arc_capacity_884
 G  connected_order_arc_885
 L  arc_capacity_886
 G  connected_order_arc_887
 L  arc_capacity_888
 G  connected_order_arc_889
 L  arc_capacity_890
 G  connected_order_arc_891
 L  arc_capacity_892
 L  arc_capacity_893
 G  connected_order_arc_894
 L  arc_capacity_895
 G  connected_order_arc_896
 L  arc_capacity_897
 G  connected_order_arc_898
 L  arc_capacity_899
 G  connected_order_arc_900
 L  arc_capacity_901
 G  connected_order_arc_902
 L  arc_capacity_903
 G  connected_order_arc_904
 L  arc_capacity_905
 G  connected_order_arc_906
 L  arc_capacity_907
 G  connected_order_arc_908
 L  arc_capacity_909
 G  connected_order_arc_910
 L  arc_capacity_911
 G  connected_order_arc_912
 L  arc_capacity_913
 G  connected_order_arc_914
 L  arc_capacity_915
 G  connected_order_arc_916
 L  arc_capacity_917
 G  connected_order_arc_918
 L  arc_capacity_919
 L  arc_capacity_920
 G  connected_order_arc_921
 L  arc_capacity_922
 G  connected_order_arc_923
 L  arc_capacity_924
 G  connected_order_arc_925
 L  arc_capacity_926
 G  connected_order_arc_927
 L  arc_capacity_928
 G  connected_order_arc_929
 L  arc_capacity_930
 G  connected_order_arc_931
 L  arc_capacity_932
 G  connected_order_arc_933
 L  arc_capacity_934
 G  connected_order_arc_935
 L  arc_capacity_936
 G  connected_order_arc_937
 L  arc_capacity_938
 G  connected_order_arc_939
 L  arc_capacity_940
 G  connected_order_arc_941
 L  arc_capacity_942
 G  connected_order_arc_943
 L  arc_capacity_944
 G  connected_order_arc_945
 L  arc_capacity_946
 L  arc_capacity_947
 G  connected_order_arc_948
 L  arc_capacity_949
 G  connected_order_arc_950
 L  arc_capacity_951
 G  connected_order_arc_952
 L  arc_capacity_953
 G  connected_order_arc_954
 L  arc_capacity_955
 G  connected_order_arc_956
 L  arc_capacity_957
 G  connected_order_arc_958
 L  arc_capacity_959
 G  connected_order_arc_960
 L  arc_capacity_961
 G  connected_order_arc_962
 L  arc_capacity_963
 G  connected_order_arc_964
 L  arc_capacity_965
 G  connected_order_arc_966
 L  arc_capacity_967
 G  connected_order_arc_968
 L  arc_capacity_969
 G  connected_order_arc_970
 L  arc_capacity_971
 G  connected_order_arc_972
 L  arc_capacity_973
 L  arc_capacity_974
 G  connected_order_arc_975
 L  arc_capacity_976
 G  connected_order_arc_977
 L  arc_capacity_978
 G  connected_order_arc_979
 L  arc_capacity_980
 G  connected_order_arc_981
 L  arc_capacity_982
 G  connected_order_arc_983
 L  arc_capacity_984
 G  connected_order_arc_985
 L  arc_capacity_986
 G  connected_order_arc_987
 L  arc_capacity_988
 G  connected_order_arc_989
 L  arc_capacity_990
 G  connected_order_arc_991
 L  arc_capacity_992
 G  connected_order_arc_993
 L  arc_capacity_994
 G  connected_order_arc_995
 L  arc_capacity_996
 G  connected_order_arc_997
 L  arc_capacity_998
 G  connected_order_arc_999
 L  arc_capacity_1000
 L  arc_capacity_1001
 G  connected_order_arc_1002
 L  arc_capacity_1003
 G  connected_order_arc_1004
 L  arc_capacity_1005
 G  connected_order_arc_1006
 L  arc_capacity_1007
 G  connected_order_arc_1008
 L  arc_capacity_1009
 G  connected_order_arc_1010
 L  arc_capacity_1011
 G  connected_order_arc_1012
 L  arc_capacity_1013
 G  connected_order_arc_1014
 L  arc_capacity_1015
 G  connected_order_arc_1016
 L  arc_capacity_1017
 G  connected_order_arc_1018
 L  arc_capacity_1019
 G  connected_order_arc_1020
 L  arc_capacity_1021
 G  connected_order_arc_1022
 L  arc_capacity_1023
 G  connected_order_arc_1024
 L  arc_capacity_1025
 G  connected_order_arc_1026
 L  arc_capacity_1027
 L  arc_capacity_1028
 G  connected_order_arc_1029
 L  arc_capacity_1030
 G  connected_order_arc_1031
 L  arc_capacity_1032
 G  connected_order_arc_1033
 L  arc_capacity_1034
 G  connected_order_arc_1035
 L  arc_capacity_1036
 G  connected_order_arc_1037
 L  arc_capacity_1038
 G  connected_order_arc_1039
 L  arc_capacity_1040
 G  connected_order_arc_1041
 L  arc_capacity_1042
 G  connected_order_arc_1043
 L  arc_capacity_1044
 G  connected_order_arc_1045
 L  arc_capacity_1046
 G  connected_order_arc_1047
 L  arc_capacity_1048
 G  connected_order_arc_1049
 L  arc_capacity_1050
 G  connected_order_arc_1051
 L  arc_capacity_1052
 G  connected_order_arc_1053
 L  arc_capacity_1054
 L  arc_capacity_1055
 G  connected_order_arc_1056
 L  arc_capacity_1057
 G  connected_order_arc_1058
 L  arc_capacity_1059
 G  connected_order_arc_1060
 L  arc_capacity_1061
 G  connected_order_arc_1062
 L  arc_capacity_1063
 G  connected_order_arc_1064
 L  arc_capacity_1065
 G  connected_order_arc_1066
 L  arc_capacity_1067
 G  connected_order_arc_1068
 L  arc_capacity_1069
 G  connected_order_arc_1070
 L  arc_capacity_1071
 G  connected_order_arc_1072
 L  arc_capacity_1073
 G  connected_order_arc_1074
 L  arc_capacity_1075
 G  connected_order_arc_1076
 L  arc_capacity_1077
 G  connected_order_arc_1078
 L  arc_capacity_1079
 G  connected_order_arc_1080
 L  arc_capacity_1081
 L  arc_capacity_1082
 G  connected_order_arc_1083
 L  arc_capacity_1084
 G  connected_order_arc_1085
 L  arc_capacity_1086
 G  connected_order_arc_1087
 L  arc_capacity_1088
 G  connected_order_arc_1089
 L  arc_capacity_1090
 G  connected_order_arc_1091
 L  arc_capacity_1092
 G  connected_order_arc_1093
 L  arc_capacity_1094
 G  connected_order_arc_1095
 L  arc_capacity_1096
 G  connected_order_arc_1097
 L  arc_capacity_1098
 G  connected_order_arc_1099
 L  arc_capacity_1100
 G  connected_order_arc_1101
 L  arc_capacity_1102
 G  connected_order_arc_1103
 L  arc_capacity_1104
 G  connected_order_arc_1105
 L  arc_capacity_1106
 G  connected_order_arc_1107
 L  arc_capacity_1108
 L  arc_capacity_1109
 G  connected_order_arc_1110
 L  arc_capacity_1111
 G  connected_order_arc_1112
 L  arc_capacity_1113
 G  connected_order_arc_1114
 L  arc_capacity_1115
 G  connected_order_arc_1116
 L  arc_capacity_1117
 G  connected_order_arc_1118
 L  arc_capacity_1119
 G  connected_order_arc_1120
 L  arc_capacity_1121
 G  connected_order_arc_1122
 L  arc_capacity_1123
 G  connected_order_arc_1124
 L  arc_capacity_1125
 G  connected_order_arc_1126
 L  arc_capacity_1127
 G  connected_order_arc_1128
 L  arc_capacity_1129
 G  connected_order_arc_1130
 L  arc_capacity_1131
 G  connected_order_arc_1132
 L  arc_capacity_1133
 G  connected_order_arc_1134
 L  arc_capacity_1135
 L  arc_capacity_1136
 G  connected_order_arc_1137
 L  arc_capacity_1138
 G  connected_order_arc_1139
 L  arc_capacity_1140
 G  connected_order_arc_1141
 L  arc_capacity_1142
 G  connected_order_arc_1143
 L  arc_capacity_1144
 G  connected_order_arc_1145
 L  arc_capacity_1146
 G  connected_order_arc_1147
 L  arc_capacity_1148
 G  connected_order_arc_1149
 L  arc_capacity_1150
 G  connected_order_arc_1151
 L  arc_capacity_1152
 G  connected_order_arc_1153
 L  arc_capacity_1154
 G  connected_order_arc_1155
 L  arc_capacity_1156
 G  connected_order_arc_1157
 L  arc_capacity_1158
 G  connected_order_arc_1159
 L  arc_capacity_1160
 G  connected_order_arc_1161
 L  arc_capacity_1162
 L  arc_capacity_1163
 G  connected_order_arc_1164
 L  arc_capacity_1165
 G  connected_order_arc_1166
 L  arc_capacity_1167
 G  connected_order_arc_1168
 L  arc_capacity_1169
 G  connected_order_arc_1170
 L  arc_capacity_1171
 G  connected_order_arc_1172
 L  arc_capacity_1173
 G  connected_order_arc_1174
 L  arc_capacity_1175
 G  connected_order_arc_1176
 L  arc_capacity_1177
 G  connected_order_arc_1178
 L  arc_capacity_1179
 G  connected_order_arc_1180
 L  arc_capacity_1181
 G  connected_order_arc_1182
 L  arc_capacity_1183
 G  connected_order_arc_1184
 L  arc_capacity_1185
 G  connected_order_arc_1186
 L  arc_capacity_1187
 G  connected_order_arc_1188
 E  depot_departure_or_bypass_1189
 E  depot_return_or_bypass_1190
 E  out_degree_1191
 E  in_degree_1192
 G  order_active_lb_1193
 L  order_active_ub_1194
 E  segment_load_conservation_1195
 G  segment_prefix_lb_1196
 L  segment_prefix_ub_1197
 E  out_degree_1198
 E  in_degree_1199
 G  order_active_lb_1200
 L  order_active_ub_1201
 E  segment_load_conservation_1202
 G  segment_prefix_lb_1203
 L  segment_prefix_ub_1204
 E  out_degree_1205
 E  in_degree_1206
 G  order_active_lb_1207
 L  order_active_ub_1208
 E  segment_load_conservation_1209
 G  segment_prefix_lb_1210
 L  segment_prefix_ub_1211
 E  out_degree_1212
 E  in_degree_1213
 G  order_active_lb_1214
 L  order_active_ub_1215
 E  segment_load_conservation_1216
 G  segment_prefix_lb_1217
 L  segment_prefix_ub_1218
 E  out_degree_1219
 E  in_degree_1220
 G  order_active_lb_1221
 L  order_active_ub_1222
 E  segment_load_conservation_1223
 G  segment_prefix_lb_1224
 L  segment_prefix_ub_1225
 E  out_degree_1226
 E  in_degree_1227
 G  order_active_lb_1228
 L  order_active_ub_1229
 E  segment_load_conservation_1230
 G  segment_prefix_lb_1231
 L  segment_prefix_ub_1232
 E  out_degree_1233
 E  in_degree_1234
 G  order_active_lb_1235
 L  order_active_ub_1236
 E  service_visit_def_1237
 E  free_load_conservation_1238
 E  out_degree_1239
 E  in_degree_1240
 G  order_active_lb_1241
 L  order_active_ub_1242
 E  service_visit_def_1243
 E  free_load_conservation_1244
 E  out_degree_1245
 E  in_degree_1246
 G  order_active_lb_1247
 L  order_active_ub_1248
 E  service_visit_def_1249
 E  free_load_conservation_1250
 E  out_degree_1251
 E  in_degree_1252
 G  order_active_lb_1253
 L  order_active_ub_1254
 E  service_visit_def_1255
 E  free_load_conservation_1256
 E  out_degree_1257
 E  in_degree_1258
 G  order_active_lb_1259
 L  order_active_ub_1260
 E  service_visit_def_1261
 E  free_load_conservation_1262
 E  out_degree_1263
 E  in_degree_1264
 G  order_active_lb_1265
 L  order_active_ub_1266
 E  service_visit_def_1267
 E  free_load_conservation_1268
 E  out_degree_1269
 E  in_degree_1270
 G  order_active_lb_1271
 L  order_active_ub_1272
 E  service_visit_def_1273
 E  free_load_conservation_1274
 E  out_degree_1275
 E  in_degree_1276
 G  order_active_lb_1277
 L  order_active_ub_1278
 E  service_visit_def_1279
 E  free_load_conservation_1280
 G  fixed_segment_relative_order_1281
 G  fixed_segment_relative_order_1282
 G  fixed_segment_relative_order_1283
 G  fixed_segment_relative_order_1284
 G  fixed_segment_relative_order_1285
 L  original_T_including_depot_unload_1286
 L  arc_capacity_1287
 L  arc_capacity_1288
 L  arc_capacity_1289
 L  arc_capacity_1290
 L  arc_capacity_1291
 L  arc_capacity_1292
 L  arc_capacity_1293
 L  arc_capacity_1294
 L  arc_capacity_1295
 L  arc_capacity_1296
 L  arc_capacity_1297
 L  arc_capacity_1298
 L  arc_capacity_1299
 L  arc_capacity_1300
 L  arc_capacity_1301
 G  connected_order_arc_1302
 L  arc_capacity_1303
 G  connected_order_arc_1304
 L  arc_capacity_1305
 G  connected_order_arc_1306
 L  arc_capacity_1307
 G  connected_order_arc_1308
 L  arc_capacity_1309
 G  connected_order_arc_1310
 L  arc_capacity_1311
 G  connected_order_arc_1312
 L  arc_capacity_1313
 G  connected_order_arc_1314
 L  arc_capacity_1315
 G  connected_order_arc_1316
 L  arc_capacity_1317
 G  connected_order_arc_1318
 L  arc_capacity_1319
 G  connected_order_arc_1320
 L  arc_capacity_1321
 G  connected_order_arc_1322
 L  arc_capacity_1323
 L  arc_capacity_1324
 G  connected_order_arc_1325
 L  arc_capacity_1326
 G  connected_order_arc_1327
 L  arc_capacity_1328
 G  connected_order_arc_1329
 L  arc_capacity_1330
 G  connected_order_arc_1331
 L  arc_capacity_1332
 G  connected_order_arc_1333
 L  arc_capacity_1334
 G  connected_order_arc_1335
 L  arc_capacity_1336
 G  connected_order_arc_1337
 L  arc_capacity_1338
 G  connected_order_arc_1339
 L  arc_capacity_1340
 G  connected_order_arc_1341
 L  arc_capacity_1342
 G  connected_order_arc_1343
 L  arc_capacity_1344
 G  connected_order_arc_1345
 L  arc_capacity_1346
 L  arc_capacity_1347
 G  connected_order_arc_1348
 L  arc_capacity_1349
 G  connected_order_arc_1350
 L  arc_capacity_1351
 G  connected_order_arc_1352
 L  arc_capacity_1353
 G  connected_order_arc_1354
 L  arc_capacity_1355
 G  connected_order_arc_1356
 L  arc_capacity_1357
 G  connected_order_arc_1358
 L  arc_capacity_1359
 G  connected_order_arc_1360
 L  arc_capacity_1361
 G  connected_order_arc_1362
 L  arc_capacity_1363
 G  connected_order_arc_1364
 L  arc_capacity_1365
 G  connected_order_arc_1366
 L  arc_capacity_1367
 G  connected_order_arc_1368
 L  arc_capacity_1369
 L  arc_capacity_1370
 G  connected_order_arc_1371
 L  arc_capacity_1372
 G  connected_order_arc_1373
 L  arc_capacity_1374
 G  connected_order_arc_1375
 L  arc_capacity_1376
 G  connected_order_arc_1377
 L  arc_capacity_1378
 G  connected_order_arc_1379
 L  arc_capacity_1380
 G  connected_order_arc_1381
 L  arc_capacity_1382
 G  connected_order_arc_1383
 L  arc_capacity_1384
 G  connected_order_arc_1385
 L  arc_capacity_1386
 G  connected_order_arc_1387
 L  arc_capacity_1388
 G  connected_order_arc_1389
 L  arc_capacity_1390
 G  connected_order_arc_1391
 L  arc_capacity_1392
 L  arc_capacity_1393
 G  connected_order_arc_1394
 L  arc_capacity_1395
 G  connected_order_arc_1396
 L  arc_capacity_1397
 G  connected_order_arc_1398
 L  arc_capacity_1399
 G  connected_order_arc_1400
 L  arc_capacity_1401
 G  connected_order_arc_1402
 L  arc_capacity_1403
 G  connected_order_arc_1404
 L  arc_capacity_1405
 G  connected_order_arc_1406
 L  arc_capacity_1407
 G  connected_order_arc_1408
 L  arc_capacity_1409
 G  connected_order_arc_1410
 L  arc_capacity_1411
 G  connected_order_arc_1412
 L  arc_capacity_1413
 G  connected_order_arc_1414
 L  arc_capacity_1415
 L  arc_capacity_1416
 G  connected_order_arc_1417
 L  arc_capacity_1418
 G  connected_order_arc_1419
 L  arc_capacity_1420
 G  connected_order_arc_1421
 L  arc_capacity_1422
 G  connected_order_arc_1423
 L  arc_capacity_1424
 G  connected_order_arc_1425
 L  arc_capacity_1426
 G  connected_order_arc_1427
 L  arc_capacity_1428
 G  connected_order_arc_1429
 L  arc_capacity_1430
 G  connected_order_arc_1431
 L  arc_capacity_1432
 G  connected_order_arc_1433
 L  arc_capacity_1434
 G  connected_order_arc_1435
 L  arc_capacity_1436
 G  connected_order_arc_1437
 L  arc_capacity_1438
 L  arc_capacity_1439
 G  connected_order_arc_1440
 L  arc_capacity_1441
 G  connected_order_arc_1442
 L  arc_capacity_1443
 G  connected_order_arc_1444
 L  arc_capacity_1445
 G  connected_order_arc_1446
 L  arc_capacity_1447
 G  connected_order_arc_1448
 L  arc_capacity_1449
 G  connected_order_arc_1450
 L  arc_capacity_1451
 G  connected_order_arc_1452
 L  arc_capacity_1453
 G  connected_order_arc_1454
 L  arc_capacity_1455
 G  connected_order_arc_1456
 L  arc_capacity_1457
 G  connected_order_arc_1458
 L  arc_capacity_1459
 G  connected_order_arc_1460
 L  arc_capacity_1461
 L  arc_capacity_1462
 G  connected_order_arc_1463
 L  arc_capacity_1464
 G  connected_order_arc_1465
 L  arc_capacity_1466
 G  connected_order_arc_1467
 L  arc_capacity_1468
 G  connected_order_arc_1469
 L  arc_capacity_1470
 G  connected_order_arc_1471
 L  arc_capacity_1472
 G  connected_order_arc_1473
 L  arc_capacity_1474
 G  connected_order_arc_1475
 L  arc_capacity_1476
 G  connected_order_arc_1477
 L  arc_capacity_1478
 G  connected_order_arc_1479
 L  arc_capacity_1480
 G  connected_order_arc_1481
 L  arc_capacity_1482
 G  connected_order_arc_1483
 L  arc_capacity_1484
 L  arc_capacity_1485
 G  connected_order_arc_1486
 L  arc_capacity_1487
 G  connected_order_arc_1488
 L  arc_capacity_1489
 G  connected_order_arc_1490
 L  arc_capacity_1491
 G  connected_order_arc_1492
 L  arc_capacity_1493
 G  connected_order_arc_1494
 L  arc_capacity_1495
 G  connected_order_arc_1496
 L  arc_capacity_1497
 G  connected_order_arc_1498
 L  arc_capacity_1499
 G  connected_order_arc_1500
 L  arc_capacity_1501
 G  connected_order_arc_1502
 L  arc_capacity_1503
 G  connected_order_arc_1504
 L  arc_capacity_1505
 G  connected_order_arc_1506
 L  arc_capacity_1507
 L  arc_capacity_1508
 G  connected_order_arc_1509
 L  arc_capacity_1510
 G  connected_order_arc_1511
 L  arc_capacity_1512
 G  connected_order_arc_1513
 L  arc_capacity_1514
 G  connected_order_arc_1515
 L  arc_capacity_1516
 G  connected_order_arc_1517
 L  arc_capacity_1518
 G  connected_order_arc_1519
 L  arc_capacity_1520
 G  connected_order_arc_1521
 L  arc_capacity_1522
 G  connected_order_arc_1523
 L  arc_capacity_1524
 G  connected_order_arc_1525
 L  arc_capacity_1526
 G  connected_order_arc_1527
 L  arc_capacity_1528
 G  connected_order_arc_1529
 L  arc_capacity_1530
 L  arc_capacity_1531
 G  connected_order_arc_1532
 L  arc_capacity_1533
 G  connected_order_arc_1534
 L  arc_capacity_1535
 G  connected_order_arc_1536
 L  arc_capacity_1537
 G  connected_order_arc_1538
 L  arc_capacity_1539
 G  connected_order_arc_1540
 L  arc_capacity_1541
 G  connected_order_arc_1542
 L  arc_capacity_1543
 G  connected_order_arc_1544
 L  arc_capacity_1545
 G  connected_order_arc_1546
 L  arc_capacity_1547
 G  connected_order_arc_1548
 L  arc_capacity_1549
 G  connected_order_arc_1550
 L  arc_capacity_1551
 G  connected_order_arc_1552
 L  arc_capacity_1553
 L  arc_capacity_1554
 G  connected_order_arc_1555
 L  arc_capacity_1556
 G  connected_order_arc_1557
 L  arc_capacity_1558
 G  connected_order_arc_1559
 L  arc_capacity_1560
 G  connected_order_arc_1561
 L  arc_capacity_1562
 G  connected_order_arc_1563
 L  arc_capacity_1564
 G  connected_order_arc_1565
 L  arc_capacity_1566
 G  connected_order_arc_1567
 L  arc_capacity_1568
 G  connected_order_arc_1569
 L  arc_capacity_1570
 G  connected_order_arc_1571
 L  arc_capacity_1572
 G  connected_order_arc_1573
 L  arc_capacity_1574
 G  connected_order_arc_1575
 E  depot_departure_or_bypass_1576
 E  depot_return_or_bypass_1577
 E  out_degree_1578
 E  in_degree_1579
 G  order_active_lb_1580
 L  order_active_ub_1581
 E  segment_load_conservation_1582
 G  segment_prefix_lb_1583
 L  segment_prefix_ub_1584
 E  out_degree_1585
 E  in_degree_1586
 G  order_active_lb_1587
 L  order_active_ub_1588
 E  segment_load_conservation_1589
 G  segment_prefix_lb_1590
 L  segment_prefix_ub_1591
 E  out_degree_1592
 E  in_degree_1593
 G  order_active_lb_1594
 L  order_active_ub_1595
 E  segment_load_conservation_1596
 G  segment_prefix_lb_1597
 L  segment_prefix_ub_1598
 E  out_degree_1599
 E  in_degree_1600
 G  order_active_lb_1601
 L  order_active_ub_1602
 E  segment_load_conservation_1603
 G  segment_prefix_lb_1604
 L  segment_prefix_ub_1605
 E  out_degree_1606
 E  in_degree_1607
 G  order_active_lb_1608
 L  order_active_ub_1609
 E  service_visit_def_1610
 E  free_load_conservation_1611
 E  out_degree_1612
 E  in_degree_1613
 G  order_active_lb_1614
 L  order_active_ub_1615
 E  service_visit_def_1616
 E  free_load_conservation_1617
 E  out_degree_1618
 E  in_degree_1619
 G  order_active_lb_1620
 L  order_active_ub_1621
 E  service_visit_def_1622
 E  free_load_conservation_1623
 E  out_degree_1624
 E  in_degree_1625
 G  order_active_lb_1626
 L  order_active_ub_1627
 E  service_visit_def_1628
 E  free_load_conservation_1629
 E  out_degree_1630
 E  in_degree_1631
 G  order_active_lb_1632
 L  order_active_ub_1633
 E  service_visit_def_1634
 E  free_load_conservation_1635
 E  out_degree_1636
 E  in_degree_1637
 G  order_active_lb_1638
 L  order_active_ub_1639
 E  service_visit_def_1640
 E  free_load_conservation_1641
 E  out_degree_1642
 E  in_degree_1643
 G  order_active_lb_1644
 L  order_active_ub_1645
 E  service_visit_def_1646
 E  free_load_conservation_1647
 E  out_degree_1648
 E  in_degree_1649
 G  order_active_lb_1650
 L  order_active_ub_1651
 E  service_visit_def_1652
 E  free_load_conservation_1653
 G  fixed_segment_relative_order_1654
 G  fixed_segment_relative_order_1655
 G  fixed_segment_relative_order_1656
 L  original_T_including_depot_unload_1657
COLUMNS
    t         normalized_mass_27_33  -1
    t         normalized_mass_24_68  -1
    t         normalized_mass_31_97  -1
    t         normalized_mass_34_124  -1
    t         normalized_mass_16_153  -1
    t         normalized_mass_29_188  -1
    t         normalized_mass_32_217  -1
    t         normalized_mass_33_254  -1
    t         normalization_315  2.3853968253968254e+01
    t         full_original_Gini_316  -6.5990476190476187e+01
    q         OBJ       1
    q         parent_nonstrict_scope_258  1
    q         full_original_Gini_316  35
    MARKER    'MARKER'                 'INTORG'
    x_27_0    OBJ       0.0315
    x_27_0    product_lb_0  -2.4785097468354542e-02
    x_27_0    product_ub_1  -4.1921746074037140e-02
    x_27_0    onehot_27_32  1
    x_27_0    parent_nonstrict_scope_258  0.0735
    x_27_0    unique_nonzero_owner_317  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_0    product_lb_0  1
    w_27_0    product_ub_1  1
    w_27_0    normalized_mass_27_33  1
    w_27_0    full_original_Gini_316  -2.3853968253968254e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_1    OBJ       2.1000000000000005e-02
    x_27_1    product_lb_2  -2.4785097468354542e-02
    x_27_1    product_ub_3  -4.1921746074037140e-02
    x_27_1    onehot_27_32  1
    x_27_1    stock_lb_256  1
    x_27_1    stock_ub_257  1
    x_27_1    parent_nonstrict_scope_258  0.063
    x_27_1    unique_nonzero_owner_318  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_1    product_lb_2  1
    w_27_1    product_ub_3  1
    w_27_1    normalized_mass_27_33  1
    w_27_1    normalized_ratio_27_34  -1.4285714285714285e-01
    w_27_1    full_original_Gini_316  -1.9996825396825407e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_2    OBJ       1.0500000000000002e-02
    x_27_2    product_lb_4  -2.4785097468354542e-02
    x_27_2    product_ub_5  -4.1921746074037140e-02
    x_27_2    onehot_27_32  1
    x_27_2    stock_lb_256  2
    x_27_2    stock_ub_257  2
    x_27_2    parent_nonstrict_scope_258  0.0525
    x_27_2    unique_nonzero_owner_319  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_2    product_lb_4  1
    w_27_2    product_ub_5  1
    w_27_2    normalized_mass_27_33  1
    w_27_2    normalized_ratio_27_34  -2.8571428571428570e-01
    w_27_2    full_original_Gini_316  -1.6139682539682532e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_3    product_lb_6  -2.4785097468354542e-02
    x_27_3    product_ub_7  -4.1921746074037140e-02
    x_27_3    onehot_27_32  1
    x_27_3    stock_lb_256  3
    x_27_3    stock_ub_257  3
    x_27_3    parent_nonstrict_scope_258  4.1999999999999996e-02
    x_27_3    unique_nonzero_owner_320  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_3    product_lb_6  1
    w_27_3    product_ub_7  1
    w_27_3    normalized_mass_27_33  1
    w_27_3    normalized_ratio_27_34  -4.2857142857142855e-01
    w_27_3    full_original_Gini_316  -1.2282539682539682e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_4    OBJ       -1.0499999999999995e-02
    x_27_4    product_lb_8  -2.4785097468354542e-02
    x_27_4    product_ub_9  -4.1921746074037140e-02
    x_27_4    onehot_27_32  1
    x_27_4    stock_lb_256  4
    x_27_4    stock_ub_257  4
    x_27_4    parent_nonstrict_scope_258  0.0315
    x_27_4    unique_nonzero_owner_321  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_4    product_lb_8  1
    w_27_4    product_ub_9  1
    w_27_4    normalized_mass_27_33  1
    w_27_4    normalized_ratio_27_34  -5.7142857142857140e-01
    w_27_4    full_original_Gini_316  -8.7111111111111121e+00
    MARKER    'MARKER'                 'INTORG'
    x_27_5    OBJ       -2.0999999999999991e-02
    x_27_5    product_lb_10  -2.4785097468354542e-02
    x_27_5    product_ub_11  -4.1921746074037140e-02
    x_27_5    onehot_27_32  1
    x_27_5    stock_lb_256  5
    x_27_5    stock_ub_257  5
    x_27_5    parent_nonstrict_scope_258  2.1000000000000005e-02
    x_27_5    unique_nonzero_owner_322  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_5    product_lb_10  1
    w_27_5    product_ub_11  1
    w_27_5    normalized_mass_27_33  1
    w_27_5    normalized_ratio_27_34  -7.1428571428571419e-01
    w_27_5    full_original_Gini_316  -5.6539682539682543e+00
    MARKER    'MARKER'                 'INTORG'
    x_27_6    OBJ       -3.1499999999999993e-02
    x_27_6    product_lb_12  -2.4785097468354542e-02
    x_27_6    product_ub_13  -4.1921746074037140e-02
    x_27_6    onehot_27_32  1
    x_27_6    stock_lb_256  6
    x_27_6    stock_ub_257  6
    x_27_6    parent_nonstrict_scope_258  1.0500000000000002e-02
    x_27_6    unique_nonzero_owner_323  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_6    product_lb_12  1
    w_27_6    product_ub_13  1
    w_27_6    normalized_mass_27_33  1
    w_27_6    normalized_ratio_27_34  -8.5714285714285710e-01
    w_27_6    full_original_Gini_316  -3.9158730158730153e+00
    MARKER    'MARKER'                 'INTORG'
    x_27_7    OBJ       -4.1999999999999996e-02
    x_27_7    product_lb_14  -2.4785097468354542e-02
    x_27_7    product_ub_15  -4.1921746074037140e-02
    x_27_7    onehot_27_32  1
    x_27_7    stock_lb_256  7
    x_27_7    stock_ub_257  7
    x_27_7    unique_nonzero_owner_324  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_7    product_lb_14  1
    w_27_7    product_ub_15  1
    w_27_7    normalized_mass_27_33  1
    w_27_7    normalized_ratio_27_34  -1
    w_27_7    full_original_Gini_316  -3.6460317460317464e+00
    MARKER    'MARKER'                 'INTORG'
    x_27_8    OBJ       -0.0315
    x_27_8    product_lb_16  -2.4785097468354542e-02
    x_27_8    product_ub_17  -4.1921746074037140e-02
    x_27_8    onehot_27_32  1
    x_27_8    stock_lb_256  8
    x_27_8    stock_ub_257  8
    x_27_8    parent_nonstrict_scope_258  1.0499999999999995e-02
    x_27_8    unique_nonzero_owner_325  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_8    product_lb_16  1
    w_27_8    product_ub_17  1
    w_27_8    normalized_mass_27_33  1
    w_27_8    normalized_ratio_27_34  -1.1428571428571428e+00
    w_27_8    full_original_Gini_316  -7.2174603174603149e+00
    MARKER    'MARKER'                 'INTORG'
    x_27_9    OBJ       -2.1000000000000005e-02
    x_27_9    product_lb_18  -2.4785097468354542e-02
    x_27_9    product_ub_19  -4.1921746074037140e-02
    x_27_9    onehot_27_32  1
    x_27_9    stock_lb_256  9
    x_27_9    stock_ub_257  9
    x_27_9    parent_nonstrict_scope_258  2.0999999999999991e-02
    x_27_9    unique_nonzero_owner_326  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_9    product_lb_18  1
    w_27_9    product_ub_19  1
    w_27_9    normalized_mass_27_33  1
    w_27_9    normalized_ratio_27_34  -1.2857142857142856e+00
    w_27_9    full_original_Gini_316  -1.0860317460317457e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_10   OBJ       -1.0500000000000009e-02
    x_27_10   product_lb_20  -2.4785097468354542e-02
    x_27_10   product_ub_21  -4.1921746074037140e-02
    x_27_10   onehot_27_32  1
    x_27_10   stock_lb_256  10
    x_27_10   stock_ub_257  10
    x_27_10   parent_nonstrict_scope_258  3.1499999999999986e-02
    x_27_10   unique_nonzero_owner_327  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_10   product_lb_20  1
    w_27_10   product_ub_21  1
    w_27_10   normalized_mass_27_33  1
    w_27_10   normalized_ratio_27_34  -1.4285714285714284e+00
    w_27_10   full_original_Gini_316  -1.4717460317460317e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_11   product_lb_22  -2.4785097468354542e-02
    x_27_11   product_ub_23  -4.1921746074037140e-02
    x_27_11   onehot_27_32  1
    x_27_11   stock_lb_256  11
    x_27_11   stock_ub_257  11
    x_27_11   parent_nonstrict_scope_258  4.1999999999999996e-02
    MARKER    'MARKER'                 'INTEND'
    w_27_11   product_lb_22  1
    w_27_11   product_ub_23  1
    w_27_11   normalized_mass_27_33  1
    w_27_11   normalized_ratio_27_34  -1.5714285714285714e+00
    w_27_11   full_original_Gini_316  -1.8574603174603176e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_12   OBJ       1.0499999999999995e-02
    x_27_12   product_lb_24  -2.4785097468354542e-02
    x_27_12   product_ub_25  -4.1921746074037140e-02
    x_27_12   onehot_27_32  1
    x_27_12   stock_lb_256  12
    x_27_12   stock_ub_257  12
    x_27_12   parent_nonstrict_scope_258  5.2499999999999991e-02
    x_27_12   unique_nonzero_owner_328  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_12   product_lb_24  1
    w_27_12   product_ub_25  1
    w_27_12   normalized_mass_27_33  1
    w_27_12   normalized_ratio_27_34  -1.7142857142857142e+00
    w_27_12   full_original_Gini_316  -2.2431746031746030e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_13   OBJ       2.0999999999999991e-02
    x_27_13   product_lb_26  -2.4785097468354542e-02
    x_27_13   product_ub_27  -4.1921746074037140e-02
    x_27_13   onehot_27_32  1
    x_27_13   stock_lb_256  13
    x_27_13   stock_ub_257  13
    x_27_13   parent_nonstrict_scope_258  6.2999999999999987e-02
    x_27_13   unique_nonzero_owner_329  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_13   product_lb_26  1
    w_27_13   product_ub_27  1
    w_27_13   normalized_mass_27_33  1
    w_27_13   normalized_ratio_27_34  -1.8571428571428570e+00
    w_27_13   full_original_Gini_316  -2.6288888888888891e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_14   OBJ       0.0315
    x_27_14   product_lb_28  -2.4785097468354542e-02
    x_27_14   product_ub_29  -4.1921746074037140e-02
    x_27_14   onehot_27_32  1
    x_27_14   stock_lb_256  14
    x_27_14   stock_ub_257  14
    x_27_14   parent_nonstrict_scope_258  0.0735
    x_27_14   unique_nonzero_owner_330  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_14   product_lb_28  1
    w_27_14   product_ub_29  1
    w_27_14   normalized_mass_27_33  1
    w_27_14   normalized_ratio_27_34  -2
    w_27_14   full_original_Gini_316  -3.0146031746031746e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_15   OBJ       4.1999999999999996e-02
    x_27_15   product_lb_30  -2.4785097468354542e-02
    x_27_15   product_ub_31  -4.1921746074037140e-02
    x_27_15   onehot_27_32  1
    x_27_15   stock_lb_256  15
    x_27_15   stock_ub_257  15
    x_27_15   parent_nonstrict_scope_258  8.3999999999999991e-02
    x_27_15   unique_nonzero_owner_331  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_15   product_lb_30  1
    w_27_15   product_ub_31  1
    w_27_15   normalized_mass_27_33  1
    w_27_15   normalized_ratio_27_34  -2.1428571428571428e+00
    w_27_15   full_original_Gini_316  -34.0031746031746
    rho_27    normalized_ratio_27_34  1
    rho_27    block_pair_pos_277  -1
    rho_27    block_pair_neg_278  1
    rho_27    block_pair_pos_279  -1
    rho_27    block_pair_neg_280  1
    rho_27    block_pair_pos_281  -1
    rho_27    block_pair_neg_282  1
    rho_27    block_pair_pos_283  -1
    rho_27    block_pair_neg_284  1
    rho_27    block_pair_pos_285  -1
    rho_27    block_pair_neg_286  1
    rho_27    block_pair_pos_287  -1
    rho_27    block_pair_neg_288  1
    rho_27    block_pair_pos_289  -1
    rho_27    block_pair_neg_290  1
    rho_27    normalization_315  1
    MARKER    'MARKER'                 'INTORG'
    x_24_0    OBJ       0.048
    x_24_0    product_lb_35  -2.4785097468354542e-02
    x_24_0    product_ub_36  -4.1921746074037140e-02
    x_24_0    onehot_24_67  1
    x_24_0    parent_nonstrict_scope_258  0.096
    x_24_0    unique_nonzero_owner_332  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_0    product_lb_35  1
    w_24_0    product_ub_36  1
    w_24_0    normalized_mass_24_68  1
    w_24_0    full_original_Gini_316  -2.3853968253968254e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_1    OBJ       3.6000000000000004e-02
    x_24_1    product_lb_37  -2.4785097468354542e-02
    x_24_1    product_ub_38  -4.1921746074037140e-02
    x_24_1    onehot_24_67  1
    x_24_1    stock_lb_256  1
    x_24_1    stock_ub_257  1
    x_24_1    parent_nonstrict_scope_258  0.084
    x_24_1    unique_nonzero_owner_333  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_1    product_lb_37  1
    w_24_1    product_ub_38  1
    w_24_1    normalized_mass_24_68  1
    w_24_1    normalized_ratio_24_69  -0.125
    w_24_1    full_original_Gini_316  -2.0478968253968254e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_2    OBJ       2.4000000000000007e-02
    x_24_2    product_lb_39  -2.4785097468354542e-02
    x_24_2    product_ub_40  -4.1921746074037140e-02
    x_24_2    onehot_24_67  1
    x_24_2    stock_lb_256  2
    x_24_2    stock_ub_257  2
    x_24_2    parent_nonstrict_scope_258  7.2000000000000008e-02
    x_24_2    unique_nonzero_owner_334  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_2    product_lb_39  1
    w_24_2    product_ub_40  1
    w_24_2    normalized_mass_24_68  1
    w_24_2    normalized_ratio_24_69  -0.25
    w_24_2    full_original_Gini_316  -1.7103968253968254e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_3    OBJ       1.1999999999999997e-02
    x_24_3    product_lb_41  -2.4785097468354542e-02
    x_24_3    product_ub_42  -4.1921746074037140e-02
    x_24_3    onehot_24_67  1
    x_24_3    stock_lb_256  3
    x_24_3    stock_ub_257  3
    x_24_3    parent_nonstrict_scope_258  0.06
    x_24_3    unique_nonzero_owner_335  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_3    product_lb_41  1
    w_24_3    product_ub_42  1
    w_24_3    normalized_mass_24_68  1
    w_24_3    normalized_ratio_24_69  -0.375
    w_24_3    full_original_Gini_316  -1.3728968253968254e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_4    product_lb_43  -2.4785097468354542e-02
    x_24_4    product_ub_44  -4.1921746074037140e-02
    x_24_4    onehot_24_67  1
    x_24_4    stock_lb_256  4
    x_24_4    stock_ub_257  4
    x_24_4    parent_nonstrict_scope_258  0.048
    x_24_4    unique_nonzero_owner_336  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_4    product_lb_43  1
    w_24_4    product_ub_44  1
    w_24_4    normalized_mass_24_68  1
    w_24_4    normalized_ratio_24_69  -0.5
    w_24_4    full_original_Gini_316  -1.0353968253968253e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_5    OBJ       -1.1999999999999997e-02
    x_24_5    product_lb_45  -2.4785097468354542e-02
    x_24_5    product_ub_46  -4.1921746074037140e-02
    x_24_5    onehot_24_67  1
    x_24_5    stock_lb_256  5
    x_24_5    stock_ub_257  5
    x_24_5    parent_nonstrict_scope_258  3.6000000000000004e-02
    x_24_5    unique_nonzero_owner_337  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_5    product_lb_45  1
    w_24_5    product_ub_46  1
    w_24_5    normalized_mass_24_68  1
    w_24_5    normalized_ratio_24_69  -0.625
    w_24_5    full_original_Gini_316  -7.5289682539682534e+00
    MARKER    'MARKER'                 'INTORG'
    x_24_6    OBJ       -0.024
    x_24_6    product_lb_47  -2.4785097468354542e-02
    x_24_6    product_ub_48  -4.1921746074037140e-02
    x_24_6    onehot_24_67  1
    x_24_6    stock_lb_256  6
    x_24_6    stock_ub_257  6
    x_24_6    parent_nonstrict_scope_258  0.024
    x_24_6    unique_nonzero_owner_338  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_6    product_lb_47  1
    w_24_6    product_ub_48  1
    w_24_6    normalized_mass_24_68  1
    w_24_6    normalized_ratio_24_69  -0.75
    w_24_6    full_original_Gini_316  -5.0468253968253958e+00
    MARKER    'MARKER'                 'INTORG'
    x_24_7    OBJ       -3.6000000000000004e-02
    x_24_7    product_lb_49  -2.4785097468354542e-02
    x_24_7    product_ub_50  -4.1921746074037140e-02
    x_24_7    onehot_24_67  1
    x_24_7    stock_lb_256  7
    x_24_7    stock_ub_257  7
    x_24_7    parent_nonstrict_scope_258  0.012
    x_24_7    unique_nonzero_owner_339  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_7    product_lb_49  1
    w_24_7    product_ub_50  1
    w_24_7    normalized_mass_24_68  1
    w_24_7    normalized_ratio_24_69  -0.875
    w_24_7    full_original_Gini_316  -3.8265873015873018e+00
    MARKER    'MARKER'                 'INTORG'
    x_24_8    OBJ       -0.048
    x_24_8    product_lb_51  -2.4785097468354542e-02
    x_24_8    product_ub_52  -4.1921746074037140e-02
    x_24_8    onehot_24_67  1
    x_24_8    stock_lb_256  8
    x_24_8    stock_ub_257  8
    x_24_8    unique_nonzero_owner_340  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_8    product_lb_51  1
    w_24_8    product_ub_52  1
    w_24_8    normalized_mass_24_68  1
    w_24_8    normalized_ratio_24_69  -1
    w_24_8    full_original_Gini_316  -3.6460317460317464e+00
    MARKER    'MARKER'                 'INTORG'
    x_24_9    OBJ       -3.6000000000000004e-02
    x_24_9    product_lb_53  -2.4785097468354542e-02
    x_24_9    product_ub_54  -4.1921746074037140e-02
    x_24_9    onehot_24_67  1
    x_24_9    stock_lb_256  9
    x_24_9    stock_ub_257  9
    x_24_9    parent_nonstrict_scope_258  0.012
    x_24_9    unique_nonzero_owner_341  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_9    product_lb_53  1
    w_24_9    product_ub_54  1
    w_24_9    normalized_mass_24_68  1
    w_24_9    normalized_ratio_24_69  -1.125
    w_24_9    full_original_Gini_316  -6.7710317460317464e+00
    MARKER    'MARKER'                 'INTORG'
    x_24_10   OBJ       -0.024
    x_24_10   product_lb_55  -2.4785097468354542e-02
    x_24_10   product_ub_56  -4.1921746074037140e-02
    x_24_10   onehot_24_67  1
    x_24_10   stock_lb_256  10
    x_24_10   stock_ub_257  10
    x_24_10   parent_nonstrict_scope_258  0.024
    x_24_10   unique_nonzero_owner_342  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_10   product_lb_55  1
    w_24_10   product_ub_56  1
    w_24_10   normalized_mass_24_68  1
    w_24_10   normalized_ratio_24_69  -1.25
    w_24_10   full_original_Gini_316  -9.8960317460317473e+00
    MARKER    'MARKER'                 'INTORG'
    x_24_11   OBJ       -1.1999999999999997e-02
    x_24_11   product_lb_57  -2.4785097468354542e-02
    x_24_11   product_ub_58  -4.1921746074037140e-02
    x_24_11   onehot_24_67  1
    x_24_11   stock_lb_256  11
    x_24_11   stock_ub_257  11
    x_24_11   parent_nonstrict_scope_258  3.6000000000000004e-02
    MARKER    'MARKER'                 'INTEND'
    w_24_11   product_lb_57  1
    w_24_11   product_ub_58  1
    w_24_11   normalized_mass_24_68  1
    w_24_11   normalized_ratio_24_69  -1.375
    w_24_11   full_original_Gini_316  -1.3271031746031746e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_12   product_lb_59  -2.4785097468354542e-02
    x_24_12   product_ub_60  -4.1921746074037140e-02
    x_24_12   onehot_24_67  1
    x_24_12   stock_lb_256  12
    x_24_12   stock_ub_257  12
    x_24_12   parent_nonstrict_scope_258  0.048
    x_24_12   unique_nonzero_owner_343  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_12   product_lb_59  1
    w_24_12   product_ub_60  1
    w_24_12   normalized_mass_24_68  1
    w_24_12   normalized_ratio_24_69  -1.5
    w_24_12   full_original_Gini_316  -1.6646031746031746e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_13   OBJ       1.1999999999999997e-02
    x_24_13   product_lb_61  -2.4785097468354542e-02
    x_24_13   product_ub_62  -4.1921746074037140e-02
    x_24_13   onehot_24_67  1
    x_24_13   stock_lb_256  13
    x_24_13   stock_ub_257  13
    x_24_13   parent_nonstrict_scope_258  0.06
    x_24_13   unique_nonzero_owner_344  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_13   product_lb_61  1
    w_24_13   product_ub_62  1
    w_24_13   normalized_mass_24_68  1
    w_24_13   normalized_ratio_24_69  -1.625
    w_24_13   full_original_Gini_316  -2.0021031746031746e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_14   OBJ       2.4000000000000007e-02
    x_24_14   product_lb_63  -2.4785097468354542e-02
    x_24_14   product_ub_64  -4.1921746074037140e-02
    x_24_14   onehot_24_67  1
    x_24_14   stock_lb_256  14
    x_24_14   stock_ub_257  14
    x_24_14   parent_nonstrict_scope_258  7.2000000000000008e-02
    x_24_14   unique_nonzero_owner_345  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_14   product_lb_63  1
    w_24_14   product_ub_64  1
    w_24_14   normalized_mass_24_68  1
    w_24_14   normalized_ratio_24_69  -1.75
    w_24_14   full_original_Gini_316  -2.3396031746031746e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_15   OBJ       3.6000000000000004e-02
    x_24_15   product_lb_65  -2.4785097468354542e-02
    x_24_15   product_ub_66  -4.1921746074037140e-02
    x_24_15   onehot_24_67  1
    x_24_15   stock_lb_256  15
    x_24_15   stock_ub_257  15
    x_24_15   parent_nonstrict_scope_258  0.084
    x_24_15   unique_nonzero_owner_346  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_15   product_lb_65  1
    w_24_15   product_ub_66  1
    w_24_15   normalized_mass_24_68  1
    w_24_15   normalized_ratio_24_69  -1.875
    w_24_15   full_original_Gini_316  -2.6771031746031746e+01
    rho_24    normalized_ratio_24_69  1
    rho_24    block_pair_pos_265  -1
    rho_24    block_pair_neg_266  1
    rho_24    block_pair_pos_267  -1
    rho_24    block_pair_neg_268  1
    rho_24    block_pair_pos_269  -1
    rho_24    block_pair_neg_270  1
    rho_24    block_pair_pos_271  -1
    rho_24    block_pair_neg_272  1
    rho_24    block_pair_pos_273  -1
    rho_24    block_pair_neg_274  1
    rho_24    block_pair_pos_275  -1
    rho_24    block_pair_neg_276  1
    rho_24    block_pair_pos_279  1
    rho_24    block_pair_neg_280  -1
    rho_24    normalization_315  1
    MARKER    'MARKER'                 'INTORG'
    x_31_0    OBJ       0.03675
    x_31_0    product_lb_70  -2.4785097468354542e-02
    x_31_0    product_ub_71  -4.1921746074037140e-02
    x_31_0    onehot_31_96  1
    x_31_0    parent_nonstrict_scope_258  0.0735
    x_31_0    unique_nonzero_owner_347  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_0    product_lb_70  1
    w_31_0    product_ub_71  1
    w_31_0    normalized_mass_31_97  1
    w_31_0    full_original_Gini_316  -2.3853968253968254e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_1    OBJ       2.6250000000000002e-02
    x_31_1    product_lb_72  -2.4785097468354542e-02
    x_31_1    product_ub_73  -4.1921746074037140e-02
    x_31_1    onehot_31_96  1
    x_31_1    stock_lb_256  1
    x_31_1    stock_ub_257  1
    x_31_1    parent_nonstrict_scope_258  0.063
    x_31_1    unique_nonzero_owner_348  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_1    product_lb_72  1
    w_31_1    product_ub_73  1
    w_31_1    normalized_mass_31_97  1
    w_31_1    normalized_ratio_31_98  -1.4285714285714285e-01
    w_31_1    full_original_Gini_316  -1.9996825396825407e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_2    OBJ       0.01575
    x_31_2    product_lb_74  -2.4785097468354542e-02
    x_31_2    product_ub_75  -4.1921746074037140e-02
    x_31_2    onehot_31_96  1
    x_31_2    stock_lb_256  2
    x_31_2    stock_ub_257  2
    x_31_2    parent_nonstrict_scope_258  0.0525
    MARKER    'MARKER'                 'INTEND'
    w_31_2    product_lb_74  1
    w_31_2    product_ub_75  1
    w_31_2    normalized_mass_31_97  1
    w_31_2    normalized_ratio_31_98  -2.8571428571428570e-01
    w_31_2    full_original_Gini_316  -1.6139682539682532e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_3    OBJ       5.2499999999999977e-03
    x_31_3    product_lb_76  -2.4785097468354542e-02
    x_31_3    product_ub_77  -4.1921746074037140e-02
    x_31_3    onehot_31_96  1
    x_31_3    stock_lb_256  3
    x_31_3    stock_ub_257  3
    x_31_3    parent_nonstrict_scope_258  4.1999999999999996e-02
    x_31_3    unique_nonzero_owner_349  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_3    product_lb_76  1
    w_31_3    product_ub_77  1
    w_31_3    normalized_mass_31_97  1
    w_31_3    normalized_ratio_31_98  -4.2857142857142855e-01
    w_31_3    full_original_Gini_316  -1.2282539682539682e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_4    OBJ       -5.2499999999999977e-03
    x_31_4    product_lb_78  -2.4785097468354542e-02
    x_31_4    product_ub_79  -4.1921746074037140e-02
    x_31_4    onehot_31_96  1
    x_31_4    stock_lb_256  4
    x_31_4    stock_ub_257  4
    x_31_4    parent_nonstrict_scope_258  0.0315
    x_31_4    unique_nonzero_owner_350  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_4    product_lb_78  1
    w_31_4    product_ub_79  1
    w_31_4    normalized_mass_31_97  1
    w_31_4    normalized_ratio_31_98  -5.7142857142857140e-01
    w_31_4    full_original_Gini_316  -8.7111111111111121e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_5    OBJ       -1.5749999999999993e-02
    x_31_5    product_lb_80  -2.4785097468354542e-02
    x_31_5    product_ub_81  -4.1921746074037140e-02
    x_31_5    onehot_31_96  1
    x_31_5    stock_lb_256  5
    x_31_5    stock_ub_257  5
    x_31_5    parent_nonstrict_scope_258  2.1000000000000005e-02
    x_31_5    unique_nonzero_owner_351  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_5    product_lb_80  1
    w_31_5    product_ub_81  1
    w_31_5    normalized_mass_31_97  1
    w_31_5    normalized_ratio_31_98  -7.1428571428571419e-01
    w_31_5    full_original_Gini_316  -5.6539682539682543e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_6    OBJ       -2.6249999999999996e-02
    x_31_6    product_lb_82  -2.4785097468354542e-02
    x_31_6    product_ub_83  -4.1921746074037140e-02
    x_31_6    onehot_31_96  1
    x_31_6    stock_lb_256  6
    x_31_6    stock_ub_257  6
    x_31_6    parent_nonstrict_scope_258  1.0500000000000002e-02
    x_31_6    unique_nonzero_owner_352  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_6    product_lb_82  1
    w_31_6    product_ub_83  1
    w_31_6    normalized_mass_31_97  1
    w_31_6    normalized_ratio_31_98  -8.5714285714285710e-01
    w_31_6    full_original_Gini_316  -3.9158730158730153e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_7    OBJ       -0.03675
    x_31_7    product_lb_84  -2.4785097468354542e-02
    x_31_7    product_ub_85  -4.1921746074037140e-02
    x_31_7    onehot_31_96  1
    x_31_7    stock_lb_256  7
    x_31_7    stock_ub_257  7
    x_31_7    unique_nonzero_owner_353  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_7    product_lb_84  1
    w_31_7    product_ub_85  1
    w_31_7    normalized_mass_31_97  1
    w_31_7    normalized_ratio_31_98  -1
    w_31_7    full_original_Gini_316  -3.6460317460317464e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_8    OBJ       -2.6250000000000002e-02
    x_31_8    product_lb_86  -2.4785097468354542e-02
    x_31_8    product_ub_87  -4.1921746074037140e-02
    x_31_8    onehot_31_96  1
    x_31_8    stock_lb_256  8
    x_31_8    stock_ub_257  8
    x_31_8    parent_nonstrict_scope_258  1.0499999999999995e-02
    x_31_8    unique_nonzero_owner_354  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_8    product_lb_86  1
    w_31_8    product_ub_87  1
    w_31_8    normalized_mass_31_97  1
    w_31_8    normalized_ratio_31_98  -1.1428571428571428e+00
    w_31_8    full_original_Gini_316  -7.2174603174603149e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_9    OBJ       -1.5750000000000007e-02
    x_31_9    product_lb_88  -2.4785097468354542e-02
    x_31_9    product_ub_89  -4.1921746074037140e-02
    x_31_9    onehot_31_96  1
    x_31_9    stock_lb_256  9
    x_31_9    stock_ub_257  9
    x_31_9    parent_nonstrict_scope_258  2.0999999999999991e-02
    x_31_9    unique_nonzero_owner_355  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_9    product_lb_88  1
    w_31_9    product_ub_89  1
    w_31_9    normalized_mass_31_97  1
    w_31_9    normalized_ratio_31_98  -1.2857142857142856e+00
    w_31_9    full_original_Gini_316  -1.0860317460317457e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_10   OBJ       -5.2500000000000116e-03
    x_31_10   product_lb_90  -2.4785097468354542e-02
    x_31_10   product_ub_91  -4.1921746074037140e-02
    x_31_10   onehot_31_96  1
    x_31_10   stock_lb_256  10
    x_31_10   stock_ub_257  10
    x_31_10   parent_nonstrict_scope_258  3.1499999999999986e-02
    x_31_10   unique_nonzero_owner_356  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_10   product_lb_90  1
    w_31_10   product_ub_91  1
    w_31_10   normalized_mass_31_97  1
    w_31_10   normalized_ratio_31_98  -1.4285714285714284e+00
    w_31_10   full_original_Gini_316  -1.4717460317460317e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_11   OBJ       5.2499999999999977e-03
    x_31_11   product_lb_92  -2.4785097468354542e-02
    x_31_11   product_ub_93  -4.1921746074037140e-02
    x_31_11   onehot_31_96  1
    x_31_11   stock_lb_256  11
    x_31_11   stock_ub_257  11
    x_31_11   parent_nonstrict_scope_258  4.1999999999999996e-02
    x_31_11   unique_nonzero_owner_357  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_11   product_lb_92  1
    w_31_11   product_ub_93  1
    w_31_11   normalized_mass_31_97  1
    w_31_11   normalized_ratio_31_98  -1.5714285714285714e+00
    w_31_11   full_original_Gini_316  -1.8574603174603176e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_12   OBJ       1.5749999999999993e-02
    x_31_12   product_lb_94  -2.4785097468354542e-02
    x_31_12   product_ub_95  -4.1921746074037140e-02
    x_31_12   onehot_31_96  1
    x_31_12   stock_lb_256  12
    x_31_12   stock_ub_257  12
    x_31_12   parent_nonstrict_scope_258  5.2499999999999991e-02
    x_31_12   unique_nonzero_owner_358  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_12   product_lb_94  1
    w_31_12   product_ub_95  1
    w_31_12   normalized_mass_31_97  1
    w_31_12   normalized_ratio_31_98  -1.7142857142857142e+00
    w_31_12   full_original_Gini_316  -2.2431746031746030e+01
    rho_31    normalized_ratio_31_98  1
    rho_31    block_pair_pos_269  1
    rho_31    block_pair_neg_270  -1
    rho_31    block_pair_pos_283  1
    rho_31    block_pair_neg_284  -1
    rho_31    block_pair_pos_295  -1
    rho_31    block_pair_neg_296  1
    rho_31    block_pair_pos_297  -1
    rho_31    block_pair_neg_298  1
    rho_31    block_pair_pos_299  -1
    rho_31    block_pair_neg_300  1
    rho_31    block_pair_pos_301  -1
    rho_31    block_pair_neg_302  1
    rho_31    block_pair_pos_303  -1
    rho_31    block_pair_neg_304  1
    rho_31    normalization_315  1
    MARKER    'MARKER'                 'INTORG'
    x_34_0    OBJ       1.4999999999999996e-02
    x_34_0    product_lb_99  -2.4785097468354542e-02
    x_34_0    product_ub_100  -4.1921746074037140e-02
    x_34_0    onehot_34_123  1
    x_34_0    parent_nonstrict_scope_258  0.0375
    x_34_0    unique_nonzero_owner_359  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_0    product_lb_99  1
    w_34_0    product_ub_100  1
    w_34_0    normalized_mass_34_124  1
    w_34_0    full_original_Gini_316  -2.3853968253968254e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_1    OBJ       7.4999999999999963e-03
    x_34_1    product_lb_101  -2.4785097468354542e-02
    x_34_1    product_ub_102  -4.1921746074037140e-02
    x_34_1    onehot_34_123  1
    x_34_1    stock_lb_256  1
    x_34_1    stock_ub_257  1
    x_34_1    parent_nonstrict_scope_258  0.03
    MARKER    'MARKER'                 'INTEND'
    w_34_1    product_lb_101  1
    w_34_1    product_ub_102  1
    w_34_1    normalized_mass_34_124  1
    w_34_1    normalized_ratio_34_125  -0.2
    w_34_1    full_original_Gini_316  -1.8453968253968259e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_2    OBJ       -3.4694469519536142e-18
    x_34_2    product_lb_103  -2.4785097468354542e-02
    x_34_2    product_ub_104  -4.1921746074037140e-02
    x_34_2    onehot_34_123  1
    x_34_2    stock_lb_256  2
    x_34_2    stock_ub_257  2
    x_34_2    parent_nonstrict_scope_258  0.0225
    x_34_2    unique_nonzero_owner_360  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_2    product_lb_103  1
    w_34_2    product_ub_104  1
    w_34_2    normalized_mass_34_124  1
    w_34_2    normalized_ratio_34_125  -0.4
    w_34_2    full_original_Gini_316  -1.3053968253968250e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_3    OBJ       -7.5000000000000067e-03
    x_34_3    product_lb_105  -2.4785097468354542e-02
    x_34_3    product_ub_106  -4.1921746074037140e-02
    x_34_3    onehot_34_123  1
    x_34_3    stock_lb_256  3
    x_34_3    stock_ub_257  3
    x_34_3    parent_nonstrict_scope_258  1.4999999999999996e-02
    x_34_3    unique_nonzero_owner_361  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_3    product_lb_105  1
    w_34_3    product_ub_106  1
    w_34_3    normalized_mass_34_124  1
    w_34_3    normalized_ratio_34_125  -6.0000000000000009e-01
    w_34_3    full_original_Gini_316  -8.0539682539682520e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_4    OBJ       -1.5000000000000005e-02
    x_34_4    product_lb_107  -2.4785097468354542e-02
    x_34_4    product_ub_108  -4.1921746074037140e-02
    x_34_4    onehot_34_123  1
    x_34_4    stock_lb_256  4
    x_34_4    stock_ub_257  4
    x_34_4    parent_nonstrict_scope_258  7.4999999999999980e-03
    x_34_4    unique_nonzero_owner_362  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_4    product_lb_107  1
    w_34_4    product_ub_108  1
    w_34_4    normalized_mass_34_124  1
    w_34_4    normalized_ratio_34_125  -0.8
    w_34_4    full_original_Gini_316  -4.4968253968253968e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_5    OBJ       -2.2500000000000003e-02
    x_34_5    product_lb_109  -2.4785097468354542e-02
    x_34_5    product_ub_110  -4.1921746074037140e-02
    x_34_5    onehot_34_123  1
    x_34_5    stock_lb_256  5
    x_34_5    stock_ub_257  5
    x_34_5    unique_nonzero_owner_363  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_5    product_lb_109  1
    w_34_5    product_ub_110  1
    w_34_5    normalized_mass_34_124  1
    w_34_5    normalized_ratio_34_125  -1
    w_34_5    full_original_Gini_316  -3.6460317460317464e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_6    OBJ       -1.4999999999999996e-02
    x_34_6    product_lb_111  -2.4785097468354542e-02
    x_34_6    product_ub_112  -4.1921746074037140e-02
    x_34_6    onehot_34_123  1
    x_34_6    stock_lb_256  6
    x_34_6    stock_ub_257  6
    x_34_6    parent_nonstrict_scope_258  7.5000000000000067e-03
    x_34_6    unique_nonzero_owner_364  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_6    product_lb_111  1
    w_34_6    product_ub_112  1
    w_34_6    normalized_mass_34_124  1
    w_34_6    normalized_ratio_34_125  -1.2000000000000002e+00
    w_34_6    full_original_Gini_316  -8.6460317460317526e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_7    OBJ       -7.4999999999999980e-03
    x_34_7    product_lb_113  -2.4785097468354542e-02
    x_34_7    product_ub_114  -4.1921746074037140e-02
    x_34_7    onehot_34_123  1
    x_34_7    stock_lb_256  7
    x_34_7    stock_ub_257  7
    x_34_7    parent_nonstrict_scope_258  1.5000000000000005e-02
    x_34_7    unique_nonzero_owner_365  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_7    product_lb_113  1
    w_34_7    product_ub_114  1
    w_34_7    normalized_mass_34_124  1
    w_34_7    normalized_ratio_34_125  -1.4000000000000001e+00
    w_34_7    full_original_Gini_316  -1.3946031746031753e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_8    product_lb_115  -2.4785097468354542e-02
    x_34_8    product_ub_116  -4.1921746074037140e-02
    x_34_8    onehot_34_123  1
    x_34_8    stock_lb_256  8
    x_34_8    stock_ub_257  8
    x_34_8    parent_nonstrict_scope_258  2.2500000000000003e-02
    x_34_8    unique_nonzero_owner_366  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_8    product_lb_115  1
    w_34_8    product_ub_116  1
    w_34_8    normalized_mass_34_124  1
    w_34_8    normalized_ratio_34_125  -1.6
    w_34_8    full_original_Gini_316  -1.9346031746031752e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_9    OBJ       7.4999999999999963e-03
    x_34_9    product_lb_117  -2.4785097468354542e-02
    x_34_9    product_ub_118  -4.1921746074037140e-02
    x_34_9    onehot_34_123  1
    x_34_9    stock_lb_256  9
    x_34_9    stock_ub_257  9
    x_34_9    parent_nonstrict_scope_258  0.03
    x_34_9    unique_nonzero_owner_367  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_9    product_lb_117  1
    w_34_9    product_ub_118  1
    w_34_9    normalized_mass_34_124  1
    w_34_9    normalized_ratio_34_125  -1.8
    w_34_9    full_original_Gini_316  -2.4746031746031754e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_10   OBJ       1.4999999999999996e-02
    x_34_10   product_lb_119  -2.4785097468354542e-02
    x_34_10   product_ub_120  -4.1921746074037140e-02
    x_34_10   onehot_34_123  1
    x_34_10   stock_lb_256  10
    x_34_10   stock_ub_257  10
    x_34_10   parent_nonstrict_scope_258  0.0375
    x_34_10   unique_nonzero_owner_368  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_10   product_lb_119  1
    w_34_10   product_ub_120  1
    w_34_10   normalized_mass_34_124  1
    w_34_10   normalized_ratio_34_125  -2
    w_34_10   full_original_Gini_316  -3.0146031746031746e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_11   OBJ       2.2500000000000003e-02
    x_34_11   product_lb_121  -2.4785097468354542e-02
    x_34_11   product_ub_122  -4.1921746074037140e-02
    x_34_11   onehot_34_123  1
    x_34_11   stock_lb_256  11
    x_34_11   stock_ub_257  11
    x_34_11   parent_nonstrict_scope_258  4.5000000000000005e-02
    x_34_11   unique_nonzero_owner_369  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_11   product_lb_121  1
    w_34_11   product_ub_122  1
    w_34_11   normalized_mass_34_124  1
    w_34_11   normalized_ratio_34_125  -2.2
    w_34_11   full_original_Gini_316  -3.5546031746031751e+01
    rho_34    normalized_ratio_34_125  1
    rho_34    block_pair_pos_275  1
    rho_34    block_pair_neg_276  -1
    rho_34    block_pair_pos_289  1
    rho_34    block_pair_neg_290  -1
    rho_34    block_pair_pos_303  1
    rho_34    block_pair_neg_304  -1
    rho_34    block_pair_pos_307  -1
    rho_34    block_pair_neg_308  1
    rho_34    block_pair_pos_309  -1
    rho_34    block_pair_neg_310  1
    rho_34    block_pair_pos_311  -1
    rho_34    block_pair_neg_312  1
    rho_34    block_pair_pos_313  -1
    rho_34    block_pair_neg_314  1
    rho_34    normalization_315  1
    MARKER    'MARKER'                 'INTORG'
    x_16_0    OBJ       0.027
    x_16_0    product_lb_126  -2.4785097468354542e-02
    x_16_0    product_ub_127  -4.1921746074037140e-02
    x_16_0    onehot_16_152  1
    x_16_0    parent_nonstrict_scope_258  0.054
    x_16_0    unique_nonzero_owner_370  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_0    product_lb_126  1
    w_16_0    product_ub_127  1
    w_16_0    normalized_mass_16_153  1
    w_16_0    full_original_Gini_316  -2.3853968253968254e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_1    OBJ       0.018
    x_16_1    product_lb_128  -2.4785097468354542e-02
    x_16_1    product_ub_129  -4.1921746074037140e-02
    x_16_1    onehot_16_152  1
    x_16_1    stock_lb_256  1
    x_16_1    stock_ub_257  1
    x_16_1    parent_nonstrict_scope_258  0.045
    MARKER    'MARKER'                 'INTEND'
    w_16_1    product_lb_128  1
    w_16_1    product_ub_129  1
    w_16_1    normalized_mass_16_153  1
    w_16_1    normalized_ratio_16_154  -1.6666666666666666e-01
    w_16_1    full_original_Gini_316  -1.9353968253968251e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_2    OBJ       9.0000000000000045e-03
    x_16_2    product_lb_130  -2.4785097468354542e-02
    x_16_2    product_ub_131  -4.1921746074037140e-02
    x_16_2    onehot_16_152  1
    x_16_2    stock_lb_256  2
    x_16_2    stock_ub_257  2
    x_16_2    parent_nonstrict_scope_258  3.6000000000000004e-02
    x_16_2    unique_nonzero_owner_371  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_2    product_lb_130  1
    w_16_2    product_ub_131  1
    w_16_2    normalized_mass_16_153  1
    w_16_2    normalized_ratio_16_154  -3.3333333333333331e-01
    w_16_2    full_original_Gini_316  -1.4853968253968251e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_3    product_lb_132  -2.4785097468354542e-02
    x_16_3    product_ub_133  -4.1921746074037140e-02
    x_16_3    onehot_16_152  1
    x_16_3    stock_lb_256  3
    x_16_3    stock_ub_257  3
    x_16_3    parent_nonstrict_scope_258  0.027
    x_16_3    unique_nonzero_owner_372  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_3    product_lb_132  1
    w_16_3    product_ub_133  1
    w_16_3    normalized_mass_16_153  1
    w_16_3    normalized_ratio_16_154  -0.5
    w_16_3    full_original_Gini_316  -1.0353968253968253e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_4    OBJ       -8.9999999999999976e-03
    x_16_4    product_lb_134  -2.4785097468354542e-02
    x_16_4    product_ub_135  -4.1921746074037140e-02
    x_16_4    onehot_16_152  1
    x_16_4    stock_lb_256  4
    x_16_4    stock_ub_257  4
    x_16_4    parent_nonstrict_scope_258  1.8000000000000002e-02
    x_16_4    unique_nonzero_owner_373  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_4    product_lb_134  1
    w_16_4    product_ub_135  1
    w_16_4    normalized_mass_16_153  1
    w_16_4    normalized_ratio_16_154  -6.6666666666666663e-01
    w_16_4    full_original_Gini_316  -6.6539682539682534e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_5    OBJ       -1.7999999999999995e-02
    x_16_5    product_lb_136  -2.4785097468354542e-02
    x_16_5    product_ub_137  -4.1921746074037140e-02
    x_16_5    onehot_16_152  1
    x_16_5    stock_lb_256  5
    x_16_5    stock_ub_257  5
    x_16_5    parent_nonstrict_scope_258  9.0000000000000045e-03
    x_16_5    unique_nonzero_owner_374  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_5    product_lb_136  1
    w_16_5    product_ub_137  1
    w_16_5    normalized_mass_16_153  1
    w_16_5    normalized_ratio_16_154  -8.3333333333333326e-01
    w_16_5    full_original_Gini_316  -4.1301587301587315e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_6    OBJ       -0.027
    x_16_6    product_lb_138  -2.4785097468354542e-02
    x_16_6    product_ub_139  -4.1921746074037140e-02
    x_16_6    onehot_16_152  1
    x_16_6    stock_lb_256  6
    x_16_6    stock_ub_257  6
    x_16_6    unique_nonzero_owner_375  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_6    product_lb_138  1
    w_16_6    product_ub_139  1
    w_16_6    normalized_mass_16_153  1
    w_16_6    normalized_ratio_16_154  -1
    w_16_6    full_original_Gini_316  -3.6460317460317464e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_7    OBJ       -1.8000000000000009e-02
    x_16_7    product_lb_140  -2.4785097468354542e-02
    x_16_7    product_ub_141  -4.1921746074037140e-02
    x_16_7    onehot_16_152  1
    x_16_7    stock_lb_256  7
    x_16_7    stock_ub_257  7
    x_16_7    parent_nonstrict_scope_258  8.9999999999999924e-03
    x_16_7    unique_nonzero_owner_376  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_7    product_lb_140  1
    w_16_7    product_ub_141  1
    w_16_7    normalized_mass_16_153  1
    w_16_7    normalized_ratio_16_154  -1.1666666666666665e+00
    w_16_7    full_original_Gini_316  -7.8126984126984080e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_8    OBJ       -9.0000000000000045e-03
    x_16_8    product_lb_142  -2.4785097468354542e-02
    x_16_8    product_ub_143  -4.1921746074037140e-02
    x_16_8    onehot_16_152  1
    x_16_8    stock_lb_256  8
    x_16_8    stock_ub_257  8
    x_16_8    parent_nonstrict_scope_258  1.7999999999999995e-02
    x_16_8    unique_nonzero_owner_377  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_8    product_lb_142  1
    w_16_8    product_ub_143  1
    w_16_8    normalized_mass_16_153  1
    w_16_8    normalized_ratio_16_154  -1.3333333333333333e+00
    w_16_8    full_original_Gini_316  -1.2146031746031747e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_9    product_lb_144  -2.4785097468354542e-02
    x_16_9    product_ub_145  -4.1921746074037140e-02
    x_16_9    onehot_16_152  1
    x_16_9    stock_lb_256  9
    x_16_9    stock_ub_257  9
    x_16_9    parent_nonstrict_scope_258  0.027
    x_16_9    unique_nonzero_owner_378  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_9    product_lb_144  1
    w_16_9    product_ub_145  1
    w_16_9    normalized_mass_16_153  1
    w_16_9    normalized_ratio_16_154  -1.5
    w_16_9    full_original_Gini_316  -1.6646031746031746e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_10   OBJ       0.00899999999999999
    x_16_10   product_lb_146  -2.4785097468354542e-02
    x_16_10   product_ub_147  -4.1921746074037140e-02
    x_16_10   onehot_16_152  1
    x_16_10   stock_lb_256  10
    x_16_10   stock_ub_257  10
    x_16_10   parent_nonstrict_scope_258  3.5999999999999990e-02
    x_16_10   unique_nonzero_owner_379  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_10   product_lb_146  1
    w_16_10   product_ub_147  1
    w_16_10   normalized_mass_16_153  1
    w_16_10   normalized_ratio_16_154  -1.6666666666666665e+00
    w_16_10   full_original_Gini_316  -2.1146031746031746e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_11   OBJ       0.018
    x_16_11   product_lb_148  -2.4785097468354542e-02
    x_16_11   product_ub_149  -4.1921746074037140e-02
    x_16_11   onehot_16_152  1
    x_16_11   stock_lb_256  11
    x_16_11   stock_ub_257  11
    x_16_11   parent_nonstrict_scope_258  0.045
    x_16_11   unique_nonzero_owner_380  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_11   product_lb_148  1
    w_16_11   product_ub_149  1
    w_16_11   normalized_mass_16_153  1
    w_16_11   normalized_ratio_16_154  -1.8333333333333333e+00
    w_16_11   full_original_Gini_316  -2.5646031746031742e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_12   OBJ       0.027
    x_16_12   product_lb_150  -2.4785097468354542e-02
    x_16_12   product_ub_151  -4.1921746074037140e-02
    x_16_12   onehot_16_152  1
    x_16_12   stock_lb_256  12
    x_16_12   stock_ub_257  12
    x_16_12   parent_nonstrict_scope_258  0.054
    x_16_12   unique_nonzero_owner_381  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_12   product_lb_150  1
    w_16_12   product_ub_151  1
    w_16_12   normalized_mass_16_153  1
    w_16_12   normalized_ratio_16_154  -2
    w_16_12   full_original_Gini_316  -3.0146031746031746e+01
    rho_16    normalized_ratio_16_154  1
    rho_16    block_pair_pos_259  -1
    rho_16    block_pair_neg_260  1
    rho_16    block_pair_pos_261  -1
    rho_16    block_pair_neg_262  1
    rho_16    block_pair_pos_263  -1
    rho_16    block_pair_neg_264  1
    rho_16    block_pair_pos_265  1
    rho_16    block_pair_neg_266  -1
    rho_16    block_pair_pos_277  1
    rho_16    block_pair_neg_278  -1
    rho_16    block_pair_pos_295  1
    rho_16    block_pair_neg_296  -1
    rho_16    block_pair_pos_307  1
    rho_16    block_pair_neg_308  -1
    rho_16    normalization_315  1
    MARKER    'MARKER'                 'INTORG'
    x_29_0    OBJ       0.048
    x_29_0    product_lb_155  -2.4785097468354542e-02
    x_29_0    product_ub_156  -4.1921746074037140e-02
    x_29_0    onehot_29_187  1
    x_29_0    parent_nonstrict_scope_258  0.096
    x_29_0    unique_nonzero_owner_382  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_0    product_lb_155  1
    w_29_0    product_ub_156  1
    w_29_0    normalized_mass_29_188  1
    w_29_0    full_original_Gini_316  -2.3853968253968254e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_1    OBJ       3.6000000000000004e-02
    x_29_1    product_lb_157  -2.4785097468354542e-02
    x_29_1    product_ub_158  -4.1921746074037140e-02
    x_29_1    onehot_29_187  1
    x_29_1    stock_lb_256  1
    x_29_1    stock_ub_257  1
    x_29_1    parent_nonstrict_scope_258  0.084
    x_29_1    unique_nonzero_owner_383  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_1    product_lb_157  1
    w_29_1    product_ub_158  1
    w_29_1    normalized_mass_29_188  1
    w_29_1    normalized_ratio_29_189  -0.125
    w_29_1    full_original_Gini_316  -2.0478968253968254e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_2    OBJ       2.4000000000000007e-02
    x_29_2    product_lb_159  -2.4785097468354542e-02
    x_29_2    product_ub_160  -4.1921746074037140e-02
    x_29_2    onehot_29_187  1
    x_29_2    stock_lb_256  2
    x_29_2    stock_ub_257  2
    x_29_2    parent_nonstrict_scope_258  7.2000000000000008e-02
    x_29_2    unique_nonzero_owner_384  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_2    product_lb_159  1
    w_29_2    product_ub_160  1
    w_29_2    normalized_mass_29_188  1
    w_29_2    normalized_ratio_29_189  -0.25
    w_29_2    full_original_Gini_316  -1.7103968253968254e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_3    OBJ       1.1999999999999997e-02
    x_29_3    product_lb_161  -2.4785097468354542e-02
    x_29_3    product_ub_162  -4.1921746074037140e-02
    x_29_3    onehot_29_187  1
    x_29_3    stock_lb_256  3
    x_29_3    stock_ub_257  3
    x_29_3    parent_nonstrict_scope_258  0.06
    x_29_3    unique_nonzero_owner_385  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_3    product_lb_161  1
    w_29_3    product_ub_162  1
    w_29_3    normalized_mass_29_188  1
    w_29_3    normalized_ratio_29_189  -0.375
    w_29_3    full_original_Gini_316  -1.3728968253968254e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_4    product_lb_163  -2.4785097468354542e-02
    x_29_4    product_ub_164  -4.1921746074037140e-02
    x_29_4    onehot_29_187  1
    x_29_4    stock_lb_256  4
    x_29_4    stock_ub_257  4
    x_29_4    parent_nonstrict_scope_258  0.048
    x_29_4    unique_nonzero_owner_386  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_4    product_lb_163  1
    w_29_4    product_ub_164  1
    w_29_4    normalized_mass_29_188  1
    w_29_4    normalized_ratio_29_189  -0.5
    w_29_4    full_original_Gini_316  -1.0353968253968253e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_5    OBJ       -1.1999999999999997e-02
    x_29_5    product_lb_165  -2.4785097468354542e-02
    x_29_5    product_ub_166  -4.1921746074037140e-02
    x_29_5    onehot_29_187  1
    x_29_5    stock_lb_256  5
    x_29_5    stock_ub_257  5
    x_29_5    parent_nonstrict_scope_258  3.6000000000000004e-02
    x_29_5    unique_nonzero_owner_387  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_5    product_lb_165  1
    w_29_5    product_ub_166  1
    w_29_5    normalized_mass_29_188  1
    w_29_5    normalized_ratio_29_189  -0.625
    w_29_5    full_original_Gini_316  -7.5289682539682534e+00
    MARKER    'MARKER'                 'INTORG'
    x_29_6    OBJ       -0.024
    x_29_6    product_lb_167  -2.4785097468354542e-02
    x_29_6    product_ub_168  -4.1921746074037140e-02
    x_29_6    onehot_29_187  1
    x_29_6    stock_lb_256  6
    x_29_6    stock_ub_257  6
    x_29_6    parent_nonstrict_scope_258  0.024
    x_29_6    unique_nonzero_owner_388  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_6    product_lb_167  1
    w_29_6    product_ub_168  1
    w_29_6    normalized_mass_29_188  1
    w_29_6    normalized_ratio_29_189  -0.75
    w_29_6    full_original_Gini_316  -5.0468253968253958e+00
    MARKER    'MARKER'                 'INTORG'
    x_29_7    OBJ       -3.6000000000000004e-02
    x_29_7    product_lb_169  -2.4785097468354542e-02
    x_29_7    product_ub_170  -4.1921746074037140e-02
    x_29_7    onehot_29_187  1
    x_29_7    stock_lb_256  7
    x_29_7    stock_ub_257  7
    x_29_7    parent_nonstrict_scope_258  0.012
    x_29_7    unique_nonzero_owner_389  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_7    product_lb_169  1
    w_29_7    product_ub_170  1
    w_29_7    normalized_mass_29_188  1
    w_29_7    normalized_ratio_29_189  -0.875
    w_29_7    full_original_Gini_316  -3.8265873015873018e+00
    MARKER    'MARKER'                 'INTORG'
    x_29_8    OBJ       -0.048
    x_29_8    product_lb_171  -2.4785097468354542e-02
    x_29_8    product_ub_172  -4.1921746074037140e-02
    x_29_8    onehot_29_187  1
    x_29_8    stock_lb_256  8
    x_29_8    stock_ub_257  8
    x_29_8    unique_nonzero_owner_390  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_8    product_lb_171  1
    w_29_8    product_ub_172  1
    w_29_8    normalized_mass_29_188  1
    w_29_8    normalized_ratio_29_189  -1
    w_29_8    full_original_Gini_316  -3.6460317460317464e+00
    MARKER    'MARKER'                 'INTORG'
    x_29_9    OBJ       -3.6000000000000004e-02
    x_29_9    product_lb_173  -2.4785097468354542e-02
    x_29_9    product_ub_174  -4.1921746074037140e-02
    x_29_9    onehot_29_187  1
    x_29_9    stock_lb_256  9
    x_29_9    stock_ub_257  9
    x_29_9    parent_nonstrict_scope_258  0.012
    x_29_9    unique_nonzero_owner_391  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_9    product_lb_173  1
    w_29_9    product_ub_174  1
    w_29_9    normalized_mass_29_188  1
    w_29_9    normalized_ratio_29_189  -1.125
    w_29_9    full_original_Gini_316  -6.7710317460317464e+00
    MARKER    'MARKER'                 'INTORG'
    x_29_10   OBJ       -0.024
    x_29_10   product_lb_175  -2.4785097468354542e-02
    x_29_10   product_ub_176  -4.1921746074037140e-02
    x_29_10   onehot_29_187  1
    x_29_10   stock_lb_256  10
    x_29_10   stock_ub_257  10
    x_29_10   parent_nonstrict_scope_258  0.024
    x_29_10   unique_nonzero_owner_392  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_10   product_lb_175  1
    w_29_10   product_ub_176  1
    w_29_10   normalized_mass_29_188  1
    w_29_10   normalized_ratio_29_189  -1.25
    w_29_10   full_original_Gini_316  -9.8960317460317473e+00
    MARKER    'MARKER'                 'INTORG'
    x_29_11   OBJ       -1.1999999999999997e-02
    x_29_11   product_lb_177  -2.4785097468354542e-02
    x_29_11   product_ub_178  -4.1921746074037140e-02
    x_29_11   onehot_29_187  1
    x_29_11   stock_lb_256  11
    x_29_11   stock_ub_257  11
    x_29_11   parent_nonstrict_scope_258  3.6000000000000004e-02
    MARKER    'MARKER'                 'INTEND'
    w_29_11   product_lb_177  1
    w_29_11   product_ub_178  1
    w_29_11   normalized_mass_29_188  1
    w_29_11   normalized_ratio_29_189  -1.375
    w_29_11   full_original_Gini_316  -1.3271031746031746e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_12   product_lb_179  -2.4785097468354542e-02
    x_29_12   product_ub_180  -4.1921746074037140e-02
    x_29_12   onehot_29_187  1
    x_29_12   stock_lb_256  12
    x_29_12   stock_ub_257  12
    x_29_12   parent_nonstrict_scope_258  0.048
    x_29_12   unique_nonzero_owner_393  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_12   product_lb_179  1
    w_29_12   product_ub_180  1
    w_29_12   normalized_mass_29_188  1
    w_29_12   normalized_ratio_29_189  -1.5
    w_29_12   full_original_Gini_316  -1.6646031746031746e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_13   OBJ       1.1999999999999997e-02
    x_29_13   product_lb_181  -2.4785097468354542e-02
    x_29_13   product_ub_182  -4.1921746074037140e-02
    x_29_13   onehot_29_187  1
    x_29_13   stock_lb_256  13
    x_29_13   stock_ub_257  13
    x_29_13   parent_nonstrict_scope_258  0.06
    x_29_13   unique_nonzero_owner_394  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_13   product_lb_181  1
    w_29_13   product_ub_182  1
    w_29_13   normalized_mass_29_188  1
    w_29_13   normalized_ratio_29_189  -1.625
    w_29_13   full_original_Gini_316  -2.0021031746031746e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_14   OBJ       2.4000000000000007e-02
    x_29_14   product_lb_183  -2.4785097468354542e-02
    x_29_14   product_ub_184  -4.1921746074037140e-02
    x_29_14   onehot_29_187  1
    x_29_14   stock_lb_256  14
    x_29_14   stock_ub_257  14
    x_29_14   parent_nonstrict_scope_258  7.2000000000000008e-02
    x_29_14   unique_nonzero_owner_395  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_14   product_lb_183  1
    w_29_14   product_ub_184  1
    w_29_14   normalized_mass_29_188  1
    w_29_14   normalized_ratio_29_189  -1.75
    w_29_14   full_original_Gini_316  -2.3396031746031746e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_15   OBJ       3.6000000000000004e-02
    x_29_15   product_lb_185  -2.4785097468354542e-02
    x_29_15   product_ub_186  -4.1921746074037140e-02
    x_29_15   onehot_29_187  1
    x_29_15   stock_lb_256  15
    x_29_15   stock_ub_257  15
    x_29_15   parent_nonstrict_scope_258  0.084
    x_29_15   unique_nonzero_owner_396  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_15   product_lb_185  1
    w_29_15   product_ub_186  1
    w_29_15   normalized_mass_29_188  1
    w_29_15   normalized_ratio_29_189  -1.875
    w_29_15   full_original_Gini_316  -2.6771031746031746e+01
    rho_29    normalized_ratio_29_189  1
    rho_29    block_pair_pos_259  1
    rho_29    block_pair_neg_260  -1
    rho_29    block_pair_pos_267  1
    rho_29    block_pair_neg_268  -1
    rho_29    block_pair_pos_281  1
    rho_29    block_pair_neg_282  -1
    rho_29    block_pair_pos_291  -1
    rho_29    block_pair_neg_292  1
    rho_29    block_pair_pos_293  -1
    rho_29    block_pair_neg_294  1
    rho_29    block_pair_pos_297  1
    rho_29    block_pair_neg_298  -1
    rho_29    block_pair_pos_309  1
    rho_29    block_pair_neg_310  -1
    rho_29    normalization_315  1
    MARKER    'MARKER'                 'INTORG'
    x_32_0    OBJ       1.1249999999999993e-02
    x_32_0    product_lb_190  -2.4785097468354542e-02
    x_32_0    product_ub_191  -4.1921746074037140e-02
    x_32_0    onehot_32_216  1
    x_32_0    parent_nonstrict_scope_258  0.0375
    MARKER    'MARKER'                 'INTEND'
    w_32_0    product_lb_190  1
    w_32_0    product_ub_191  1
    w_32_0    normalized_mass_32_217  1
    w_32_0    full_original_Gini_316  -2.3853968253968254e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_1    OBJ       3.7499999999999929e-03
    x_32_1    product_lb_192  -2.4785097468354542e-02
    x_32_1    product_ub_193  -4.1921746074037140e-02
    x_32_1    onehot_32_216  1
    x_32_1    stock_lb_256  1
    x_32_1    stock_ub_257  1
    x_32_1    parent_nonstrict_scope_258  0.03
    x_32_1    unique_nonzero_owner_397  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_1    product_lb_192  1
    w_32_1    product_ub_193  1
    w_32_1    normalized_mass_32_217  1
    w_32_1    normalized_ratio_32_218  -0.2
    w_32_1    full_original_Gini_316  -1.8453968253968259e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_2    OBJ       -3.7500000000000068e-03
    x_32_2    product_lb_194  -2.4785097468354542e-02
    x_32_2    product_ub_195  -4.1921746074037140e-02
    x_32_2    onehot_32_216  1
    x_32_2    stock_lb_256  2
    x_32_2    stock_ub_257  2
    x_32_2    parent_nonstrict_scope_258  0.0225
    x_32_2    unique_nonzero_owner_398  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_2    product_lb_194  1
    w_32_2    product_ub_195  1
    w_32_2    normalized_mass_32_217  1
    w_32_2    normalized_ratio_32_218  -0.4
    w_32_2    full_original_Gini_316  -1.3053968253968250e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_3    OBJ       -1.1250000000000010e-02
    x_32_3    product_lb_196  -2.4785097468354542e-02
    x_32_3    product_ub_197  -4.1921746074037140e-02
    x_32_3    onehot_32_216  1
    x_32_3    stock_lb_256  3
    x_32_3    stock_ub_257  3
    x_32_3    parent_nonstrict_scope_258  1.4999999999999996e-02
    x_32_3    unique_nonzero_owner_399  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_3    product_lb_196  1
    w_32_3    product_ub_197  1
    w_32_3    normalized_mass_32_217  1
    w_32_3    normalized_ratio_32_218  -6.0000000000000009e-01
    w_32_3    full_original_Gini_316  -8.0539682539682520e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_4    OBJ       -1.8750000000000010e-02
    x_32_4    product_lb_198  -2.4785097468354542e-02
    x_32_4    product_ub_199  -4.1921746074037140e-02
    x_32_4    onehot_32_216  1
    x_32_4    stock_lb_256  4
    x_32_4    stock_ub_257  4
    x_32_4    parent_nonstrict_scope_258  7.4999999999999980e-03
    x_32_4    unique_nonzero_owner_400  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_4    product_lb_198  1
    w_32_4    product_ub_199  1
    w_32_4    normalized_mass_32_217  1
    w_32_4    normalized_ratio_32_218  -0.8
    w_32_4    full_original_Gini_316  -4.4968253968253968e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_5    OBJ       -2.6250000000000006e-02
    x_32_5    product_lb_200  -2.4785097468354542e-02
    x_32_5    product_ub_201  -4.1921746074037140e-02
    x_32_5    onehot_32_216  1
    x_32_5    stock_lb_256  5
    x_32_5    stock_ub_257  5
    x_32_5    unique_nonzero_owner_401  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_5    product_lb_200  1
    w_32_5    product_ub_201  1
    w_32_5    normalized_mass_32_217  1
    w_32_5    normalized_ratio_32_218  -1
    w_32_5    full_original_Gini_316  -3.6460317460317464e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_6    OBJ       -0.01875
    x_32_6    product_lb_202  -2.4785097468354542e-02
    x_32_6    product_ub_203  -4.1921746074037140e-02
    x_32_6    onehot_32_216  1
    x_32_6    stock_lb_256  6
    x_32_6    stock_ub_257  6
    x_32_6    parent_nonstrict_scope_258  7.5000000000000067e-03
    x_32_6    unique_nonzero_owner_402  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_6    product_lb_202  1
    w_32_6    product_ub_203  1
    w_32_6    normalized_mass_32_217  1
    w_32_6    normalized_ratio_32_218  -1.2000000000000002e+00
    w_32_6    full_original_Gini_316  -8.6460317460317526e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_7    OBJ       -1.1250000000000001e-02
    x_32_7    product_lb_204  -2.4785097468354542e-02
    x_32_7    product_ub_205  -4.1921746074037140e-02
    x_32_7    onehot_32_216  1
    x_32_7    stock_lb_256  7
    x_32_7    stock_ub_257  7
    x_32_7    parent_nonstrict_scope_258  1.5000000000000005e-02
    x_32_7    unique_nonzero_owner_403  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_7    product_lb_204  1
    w_32_7    product_ub_205  1
    w_32_7    normalized_mass_32_217  1
    w_32_7    normalized_ratio_32_218  -1.4000000000000001e+00
    w_32_7    full_original_Gini_316  -1.3946031746031753e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_8    OBJ       -3.7500000000000033e-03
    x_32_8    product_lb_206  -2.4785097468354542e-02
    x_32_8    product_ub_207  -4.1921746074037140e-02
    x_32_8    onehot_32_216  1
    x_32_8    stock_lb_256  8
    x_32_8    stock_ub_257  8
    x_32_8    parent_nonstrict_scope_258  2.2500000000000003e-02
    x_32_8    unique_nonzero_owner_404  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_8    product_lb_206  1
    w_32_8    product_ub_207  1
    w_32_8    normalized_mass_32_217  1
    w_32_8    normalized_ratio_32_218  -1.6
    w_32_8    full_original_Gini_316  -1.9346031746031752e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_9    OBJ       3.7499999999999929e-03
    x_32_9    product_lb_208  -2.4785097468354542e-02
    x_32_9    product_ub_209  -4.1921746074037140e-02
    x_32_9    onehot_32_216  1
    x_32_9    stock_lb_256  9
    x_32_9    stock_ub_257  9
    x_32_9    parent_nonstrict_scope_258  0.03
    x_32_9    unique_nonzero_owner_405  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_9    product_lb_208  1
    w_32_9    product_ub_209  1
    w_32_9    normalized_mass_32_217  1
    w_32_9    normalized_ratio_32_218  -1.8
    w_32_9    full_original_Gini_316  -2.4746031746031754e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_10   OBJ       1.1249999999999993e-02
    x_32_10   product_lb_210  -2.4785097468354542e-02
    x_32_10   product_ub_211  -4.1921746074037140e-02
    x_32_10   onehot_32_216  1
    x_32_10   stock_lb_256  10
    x_32_10   stock_ub_257  10
    x_32_10   parent_nonstrict_scope_258  0.0375
    x_32_10   unique_nonzero_owner_406  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_10   product_lb_210  1
    w_32_10   product_ub_211  1
    w_32_10   normalized_mass_32_217  1
    w_32_10   normalized_ratio_32_218  -2
    w_32_10   full_original_Gini_316  -3.0146031746031746e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_11   OBJ       0.01875
    x_32_11   product_lb_212  -2.4785097468354542e-02
    x_32_11   product_ub_213  -4.1921746074037140e-02
    x_32_11   onehot_32_216  1
    x_32_11   stock_lb_256  11
    x_32_11   stock_ub_257  11
    x_32_11   parent_nonstrict_scope_258  4.5000000000000005e-02
    x_32_11   unique_nonzero_owner_407  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_11   product_lb_212  1
    w_32_11   product_ub_213  1
    w_32_11   normalized_mass_32_217  1
    w_32_11   normalized_ratio_32_218  -2.2
    w_32_11   full_original_Gini_316  -3.5546031746031751e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_12   OBJ       2.6250000000000006e-02
    x_32_12   product_lb_214  -2.4785097468354542e-02
    x_32_12   product_ub_215  -4.1921746074037140e-02
    x_32_12   onehot_32_216  1
    x_32_12   stock_lb_256  12
    x_32_12   stock_ub_257  12
    x_32_12   parent_nonstrict_scope_258  5.2500000000000012e-02
    x_32_12   unique_nonzero_owner_408  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_12   product_lb_214  1
    w_32_12   product_ub_215  1
    w_32_12   normalized_mass_32_217  1
    w_32_12   normalized_ratio_32_218  -2.4000000000000004e+00
    w_32_12   full_original_Gini_316  -4.0946031746031743e+01
    rho_32    normalized_ratio_32_218  1
    rho_32    block_pair_pos_261  1
    rho_32    block_pair_neg_262  -1
    rho_32    block_pair_pos_271  1
    rho_32    block_pair_neg_272  -1
    rho_32    block_pair_pos_285  1
    rho_32    block_pair_neg_286  -1
    rho_32    block_pair_pos_291  1
    rho_32    block_pair_neg_292  -1
    rho_32    block_pair_pos_299  1
    rho_32    block_pair_neg_300  -1
    rho_32    block_pair_pos_305  -1
    rho_32    block_pair_neg_306  1
    rho_32    block_pair_pos_311  1
    rho_32    block_pair_neg_312  -1
    rho_32    normalization_315  1
    MARKER    'MARKER'                 'INTORG'
    x_33_0    OBJ       2.6250000000000002e-02
    x_33_0    product_lb_219  -2.4785097468354542e-02
    x_33_0    product_ub_220  -4.1921746074037140e-02
    x_33_0    onehot_33_253  1
    x_33_0    parent_nonstrict_scope_258  0.0735
    x_33_0    unique_nonzero_owner_409  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_0    product_lb_219  1
    w_33_0    product_ub_220  1
    w_33_0    normalized_mass_33_254  1
    w_33_0    full_original_Gini_316  -2.3853968253968254e+01
    MARKER    'MARKER'                 'INTORG'
    x_33_1    OBJ       1.5750000000000007e-02
    x_33_1    product_lb_221  -2.4785097468354542e-02
    x_33_1    product_ub_222  -4.1921746074037140e-02
    x_33_1    onehot_33_253  1
    x_33_1    stock_lb_256  1
    x_33_1    stock_ub_257  1
    x_33_1    parent_nonstrict_scope_258  0.063
    MARKER    'MARKER'                 'INTEND'
    w_33_1    product_lb_221  1
    w_33_1    product_ub_222  1
    w_33_1    normalized_mass_33_254  1
    w_33_1    normalized_ratio_33_255  -1.4285714285714285e-01
    w_33_1    full_original_Gini_316  -1.9996825396825407e+01
    MARKER    'MARKER'                 'INTORG'
    x_33_2    OBJ       5.2500000000000047e-03
    x_33_2    product_lb_223  -2.4785097468354542e-02
    x_33_2    product_ub_224  -4.1921746074037140e-02
    x_33_2    onehot_33_253  1
    x_33_2    stock_lb_256  2
    x_33_2    stock_ub_257  2
    x_33_2    parent_nonstrict_scope_258  0.0525
    x_33_2    unique_nonzero_owner_410  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_2    product_lb_223  1
    w_33_2    product_ub_224  1
    w_33_2    normalized_mass_33_254  1
    w_33_2    normalized_ratio_33_255  -2.8571428571428570e-01
    w_33_2    full_original_Gini_316  -1.6139682539682532e+01
    MARKER    'MARKER'                 'INTORG'
    x_33_3    OBJ       -5.2499999999999977e-03
    x_33_3    product_lb_225  -2.4785097468354542e-02
    x_33_3    product_ub_226  -4.1921746074037140e-02
    x_33_3    onehot_33_253  1
    x_33_3    stock_lb_256  3
    x_33_3    stock_ub_257  3
    x_33_3    parent_nonstrict_scope_258  4.1999999999999996e-02
    x_33_3    unique_nonzero_owner_411  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_3    product_lb_225  1
    w_33_3    product_ub_226  1
    w_33_3    normalized_mass_33_254  1
    w_33_3    normalized_ratio_33_255  -4.2857142857142855e-01
    w_33_3    full_original_Gini_316  -1.2282539682539682e+01
    MARKER    'MARKER'                 'INTORG'
    x_33_4    OBJ       -1.5749999999999993e-02
    x_33_4    product_lb_227  -2.4785097468354542e-02
    x_33_4    product_ub_228  -4.1921746074037140e-02
    x_33_4    onehot_33_253  1
    x_33_4    stock_lb_256  4
    x_33_4    stock_ub_257  4
    x_33_4    parent_nonstrict_scope_258  0.0315
    x_33_4    unique_nonzero_owner_412  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_4    product_lb_227  1
    w_33_4    product_ub_228  1
    w_33_4    normalized_mass_33_254  1
    w_33_4    normalized_ratio_33_255  -5.7142857142857140e-01
    w_33_4    full_original_Gini_316  -8.7111111111111121e+00
    MARKER    'MARKER'                 'INTORG'
    x_33_5    OBJ       -2.6249999999999989e-02
    x_33_5    product_lb_229  -2.4785097468354542e-02
    x_33_5    product_ub_230  -4.1921746074037140e-02
    x_33_5    onehot_33_253  1
    x_33_5    stock_lb_256  5
    x_33_5    stock_ub_257  5
    x_33_5    parent_nonstrict_scope_258  2.1000000000000005e-02
    x_33_5    unique_nonzero_owner_413  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_5    product_lb_229  1
    w_33_5    product_ub_230  1
    w_33_5    normalized_mass_33_254  1
    w_33_5    normalized_ratio_33_255  -7.1428571428571419e-01
    w_33_5    full_original_Gini_316  -5.6539682539682543e+00
    MARKER    'MARKER'                 'INTORG'
    x_33_6    OBJ       -3.6749999999999991e-02
    x_33_6    product_lb_231  -2.4785097468354542e-02
    x_33_6    product_ub_232  -4.1921746074037140e-02
    x_33_6    onehot_33_253  1
    x_33_6    stock_lb_256  6
    x_33_6    stock_ub_257  6
    x_33_6    parent_nonstrict_scope_258  1.0500000000000002e-02
    x_33_6    unique_nonzero_owner_414  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_6    product_lb_231  1
    w_33_6    product_ub_232  1
    w_33_6    normalized_mass_33_254  1
    w_33_6    normalized_ratio_33_255  -8.5714285714285710e-01
    w_33_6    full_original_Gini_316  -3.9158730158730153e+00
    MARKER    'MARKER'                 'INTORG'
    x_33_7    OBJ       -4.7249999999999993e-02
    x_33_7    product_lb_233  -2.4785097468354542e-02
    x_33_7    product_ub_234  -4.1921746074037140e-02
    x_33_7    onehot_33_253  1
    x_33_7    stock_lb_256  7
    x_33_7    stock_ub_257  7
    x_33_7    unique_nonzero_owner_415  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_7    product_lb_233  1
    w_33_7    product_ub_234  1
    w_33_7    normalized_mass_33_254  1
    w_33_7    normalized_ratio_33_255  -1
    w_33_7    full_original_Gini_316  -3.6460317460317464e+00
    MARKER    'MARKER'                 'INTORG'
    x_33_8    OBJ       -0.03675
    x_33_8    product_lb_235  -2.4785097468354542e-02
    x_33_8    product_ub_236  -4.1921746074037140e-02
    x_33_8    onehot_33_253  1
    x_33_8    stock_lb_256  8
    x_33_8    stock_ub_257  8
    x_33_8    parent_nonstrict_scope_258  1.0499999999999995e-02
    x_33_8    unique_nonzero_owner_416  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_8    product_lb_235  1
    w_33_8    product_ub_236  1
    w_33_8    normalized_mass_33_254  1
    w_33_8    normalized_ratio_33_255  -1.1428571428571428e+00
    w_33_8    full_original_Gini_316  -7.2174603174603149e+00
    MARKER    'MARKER'                 'INTORG'
    x_33_9    OBJ       -2.6250000000000002e-02
    x_33_9    product_lb_237  -2.4785097468354542e-02
    x_33_9    product_ub_238  -4.1921746074037140e-02
    x_33_9    onehot_33_253  1
    x_33_9    stock_lb_256  9
    x_33_9    stock_ub_257  9
    x_33_9    parent_nonstrict_scope_258  2.0999999999999991e-02
    x_33_9    unique_nonzero_owner_417  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_9    product_lb_237  1
    w_33_9    product_ub_238  1
    w_33_9    normalized_mass_33_254  1
    w_33_9    normalized_ratio_33_255  -1.2857142857142856e+00
    w_33_9    full_original_Gini_316  -1.0860317460317457e+01
    MARKER    'MARKER'                 'INTORG'
    x_33_10   OBJ       -1.5750000000000007e-02
    x_33_10   product_lb_239  -2.4785097468354542e-02
    x_33_10   product_ub_240  -4.1921746074037140e-02
    x_33_10   onehot_33_253  1
    x_33_10   stock_lb_256  10
    x_33_10   stock_ub_257  10
    x_33_10   parent_nonstrict_scope_258  3.1499999999999986e-02
    x_33_10   unique_nonzero_owner_418  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_10   product_lb_239  1
    w_33_10   product_ub_240  1
    w_33_10   normalized_mass_33_254  1
    w_33_10   normalized_ratio_33_255  -1.4285714285714284e+00
    w_33_10   full_original_Gini_316  -1.4717460317460317e+01
    MARKER    'MARKER'                 'INTORG'
    x_33_11   OBJ       -5.2499999999999977e-03
    x_33_11   product_lb_241  -2.4785097468354542e-02
    x_33_11   product_ub_242  -4.1921746074037140e-02
    x_33_11   onehot_33_253  1
    x_33_11   stock_lb_256  11
    x_33_11   stock_ub_257  11
    x_33_11   parent_nonstrict_scope_258  4.1999999999999996e-02
    x_33_11   unique_nonzero_owner_419  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_11   product_lb_241  1
    w_33_11   product_ub_242  1
    w_33_11   normalized_mass_33_254  1
    w_33_11   normalized_ratio_33_255  -1.5714285714285714e+00
    w_33_11   full_original_Gini_316  -1.8574603174603176e+01
    MARKER    'MARKER'                 'INTORG'
    x_33_12   OBJ       5.2499999999999977e-03
    x_33_12   product_lb_243  -2.4785097468354542e-02
    x_33_12   product_ub_244  -4.1921746074037140e-02
    x_33_12   onehot_33_253  1
    x_33_12   stock_lb_256  12
    x_33_12   stock_ub_257  12
    x_33_12   parent_nonstrict_scope_258  5.2499999999999991e-02
    x_33_12   unique_nonzero_owner_420  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_12   product_lb_243  1
    w_33_12   product_ub_244  1
    w_33_12   normalized_mass_33_254  1
    w_33_12   normalized_ratio_33_255  -1.7142857142857142e+00
    w_33_12   full_original_Gini_316  -2.2431746031746030e+01
    MARKER    'MARKER'                 'INTORG'
    x_33_13   OBJ       1.5749999999999993e-02
    x_33_13   product_lb_245  -2.4785097468354542e-02
    x_33_13   product_ub_246  -4.1921746074037140e-02
    x_33_13   onehot_33_253  1
    x_33_13   stock_lb_256  13
    x_33_13   stock_ub_257  13
    x_33_13   parent_nonstrict_scope_258  6.2999999999999987e-02
    x_33_13   unique_nonzero_owner_421  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_13   product_lb_245  1
    w_33_13   product_ub_246  1
    w_33_13   normalized_mass_33_254  1
    w_33_13   normalized_ratio_33_255  -1.8571428571428570e+00
    w_33_13   full_original_Gini_316  -2.6288888888888891e+01
    MARKER    'MARKER'                 'INTORG'
    x_33_14   OBJ       2.6250000000000002e-02
    x_33_14   product_lb_247  -2.4785097468354542e-02
    x_33_14   product_ub_248  -4.1921746074037140e-02
    x_33_14   onehot_33_253  1
    x_33_14   stock_lb_256  14
    x_33_14   stock_ub_257  14
    x_33_14   parent_nonstrict_scope_258  0.0735
    x_33_14   unique_nonzero_owner_422  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_14   product_lb_247  1
    w_33_14   product_ub_248  1
    w_33_14   normalized_mass_33_254  1
    w_33_14   normalized_ratio_33_255  -2
    w_33_14   full_original_Gini_316  -3.0146031746031746e+01
    MARKER    'MARKER'                 'INTORG'
    x_33_15   OBJ       0.03675
    x_33_15   product_lb_249  -2.4785097468354542e-02
    x_33_15   product_ub_250  -4.1921746074037140e-02
    x_33_15   onehot_33_253  1
    x_33_15   stock_lb_256  15
    x_33_15   stock_ub_257  15
    x_33_15   parent_nonstrict_scope_258  8.3999999999999991e-02
    x_33_15   unique_nonzero_owner_423  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_15   product_lb_249  1
    w_33_15   product_ub_250  1
    w_33_15   normalized_mass_33_254  1
    w_33_15   normalized_ratio_33_255  -2.1428571428571428e+00
    w_33_15   full_original_Gini_316  -34.0031746031746
    MARKER    'MARKER'                 'INTORG'
    x_33_16   OBJ       4.7249999999999993e-02
    x_33_16   product_lb_251  -2.4785097468354542e-02
    x_33_16   product_ub_252  -4.1921746074037140e-02
    x_33_16   onehot_33_253  1
    x_33_16   stock_lb_256  16
    x_33_16   stock_ub_257  16
    x_33_16   parent_nonstrict_scope_258  9.4499999999999987e-02
    x_33_16   unique_nonzero_owner_424  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_16   product_lb_251  1
    w_33_16   product_ub_252  1
    w_33_16   normalized_mass_33_254  1
    w_33_16   normalized_ratio_33_255  -2.2857142857142856e+00
    w_33_16   full_original_Gini_316  -3.7860317460317439e+01
    rho_33    normalized_ratio_33_255  1
    rho_33    block_pair_pos_263  1
    rho_33    block_pair_neg_264  -1
    rho_33    block_pair_pos_273  1
    rho_33    block_pair_neg_274  -1
    rho_33    block_pair_pos_287  1
    rho_33    block_pair_neg_288  -1
    rho_33    block_pair_pos_293  1
    rho_33    block_pair_neg_294  -1
    rho_33    block_pair_pos_301  1
    rho_33    block_pair_neg_302  -1
    rho_33    block_pair_pos_305  1
    rho_33    block_pair_neg_306  -1
    rho_33    block_pair_pos_313  1
    rho_33    block_pair_neg_314  -1
    rho_33    normalization_315  1
    a_27_24   block_pair_pos_279  1
    a_27_24   block_pair_neg_280  1
    a_27_24   full_original_Gini_316  -1
    a_27_31   block_pair_pos_283  1
    a_27_31   block_pair_neg_284  1
    a_27_31   full_original_Gini_316  -1
    a_27_34   block_pair_pos_289  1
    a_27_34   block_pair_neg_290  1
    a_27_34   full_original_Gini_316  -1
    a_27_16   block_pair_pos_277  1
    a_27_16   block_pair_neg_278  1
    a_27_16   full_original_Gini_316  -1
    a_27_29   block_pair_pos_281  1
    a_27_29   block_pair_neg_282  1
    a_27_29   full_original_Gini_316  -1
    a_27_32   block_pair_pos_285  1
    a_27_32   block_pair_neg_286  1
    a_27_32   full_original_Gini_316  -1
    a_27_33   block_pair_pos_287  1
    a_27_33   block_pair_neg_288  1
    a_27_33   full_original_Gini_316  -1
    a_24_31   block_pair_pos_269  1
    a_24_31   block_pair_neg_270  1
    a_24_31   full_original_Gini_316  -1
    a_24_34   block_pair_pos_275  1
    a_24_34   block_pair_neg_276  1
    a_24_34   full_original_Gini_316  -1
    a_24_16   block_pair_pos_265  1
    a_24_16   block_pair_neg_266  1
    a_24_16   full_original_Gini_316  -1
    a_24_29   block_pair_pos_267  1
    a_24_29   block_pair_neg_268  1
    a_24_29   full_original_Gini_316  -1
    a_24_32   block_pair_pos_271  1
    a_24_32   block_pair_neg_272  1
    a_24_32   full_original_Gini_316  -1
    a_24_33   block_pair_pos_273  1
    a_24_33   block_pair_neg_274  1
    a_24_33   full_original_Gini_316  -1
    a_31_34   block_pair_pos_303  1
    a_31_34   block_pair_neg_304  1
    a_31_34   full_original_Gini_316  -1
    a_31_16   block_pair_pos_295  1
    a_31_16   block_pair_neg_296  1
    a_31_16   full_original_Gini_316  -1
    a_31_29   block_pair_pos_297  1
    a_31_29   block_pair_neg_298  1
    a_31_29   full_original_Gini_316  -1
    a_31_32   block_pair_pos_299  1
    a_31_32   block_pair_neg_300  1
    a_31_32   full_original_Gini_316  -1
    a_31_33   block_pair_pos_301  1
    a_31_33   block_pair_neg_302  1
    a_31_33   full_original_Gini_316  -1
    a_34_16   block_pair_pos_307  1
    a_34_16   block_pair_neg_308  1
    a_34_16   full_original_Gini_316  -1
    a_34_29   block_pair_pos_309  1
    a_34_29   block_pair_neg_310  1
    a_34_29   full_original_Gini_316  -1
    a_34_32   block_pair_pos_311  1
    a_34_32   block_pair_neg_312  1
    a_34_32   full_original_Gini_316  -1
    a_34_33   block_pair_pos_313  1
    a_34_33   block_pair_neg_314  1
    a_34_33   full_original_Gini_316  -1
    a_16_29   block_pair_pos_259  1
    a_16_29   block_pair_neg_260  1
    a_16_29   full_original_Gini_316  -1
    a_16_32   block_pair_pos_261  1
    a_16_32   block_pair_neg_262  1
    a_16_32   full_original_Gini_316  -1
    a_16_33   block_pair_pos_263  1
    a_16_33   block_pair_neg_264  1
    a_16_33   full_original_Gini_316  -1
    a_29_32   block_pair_pos_291  1
    a_29_32   block_pair_neg_292  1
    a_29_32   full_original_Gini_316  -1
    a_29_33   block_pair_pos_293  1
    a_29_33   block_pair_neg_294  1
    a_29_33   full_original_Gini_316  -1
    a_32_33   block_pair_pos_305  1
    a_32_33   block_pair_neg_306  1
    a_32_33   full_original_Gini_316  -1
    MARKER    'MARKER'                 'INTORG'
    service_0_27_0  unique_nonzero_owner_317  1
    service_0_27_0  service_visit_def_748  1
    service_0_27_0  free_load_conservation_749  -11
    service_0_27_0  original_T_including_depot_unload_795  1320
    service_0_27_1  unique_nonzero_owner_318  1
    service_0_27_1  service_visit_def_748  1
    service_0_27_1  free_load_conservation_749  -10
    service_0_27_1  original_T_including_depot_unload_795  1200
    service_0_27_2  unique_nonzero_owner_319  1
    service_0_27_2  service_visit_def_748  1
    service_0_27_2  free_load_conservation_749  -9
    service_0_27_2  original_T_including_depot_unload_795  1080
    service_0_27_3  unique_nonzero_owner_320  1
    service_0_27_3  service_visit_def_748  1
    service_0_27_3  free_load_conservation_749  -8
    service_0_27_3  original_T_including_depot_unload_795  960
    service_0_27_4  unique_nonzero_owner_321  1
    service_0_27_4  service_visit_def_748  1
    service_0_27_4  free_load_conservation_749  -7
    service_0_27_4  original_T_including_depot_unload_795  840
    service_0_27_5  unique_nonzero_owner_322  1
    service_0_27_5  service_visit_def_748  1
    service_0_27_5  free_load_conservation_749  -6
    service_0_27_5  original_T_including_depot_unload_795  720
    service_0_27_6  unique_nonzero_owner_323  1
    service_0_27_6  service_visit_def_748  1
    service_0_27_6  free_load_conservation_749  -5
    service_0_27_6  original_T_including_depot_unload_795  600
    service_0_27_7  unique_nonzero_owner_324  1
    service_0_27_7  service_visit_def_748  1
    service_0_27_7  free_load_conservation_749  -4
    service_0_27_7  original_T_including_depot_unload_795  480
    service_0_27_8  unique_nonzero_owner_325  1
    service_0_27_8  service_visit_def_748  1
    service_0_27_8  free_load_conservation_749  -3
    service_0_27_8  original_T_including_depot_unload_795  360
    service_0_27_9  unique_nonzero_owner_326  1
    service_0_27_9  service_visit_def_748  1
    service_0_27_9  free_load_conservation_749  -2
    service_0_27_9  original_T_including_depot_unload_795  240
    service_0_27_10  unique_nonzero_owner_327  1
    service_0_27_10  service_visit_def_748  1
    service_0_27_10  free_load_conservation_749  -1
    service_0_27_10  original_T_including_depot_unload_795  120
    service_0_27_12  unique_nonzero_owner_328  1
    service_0_27_12  service_visit_def_748  1
    service_0_27_12  free_load_conservation_749  1
    service_0_27_13  unique_nonzero_owner_329  1
    service_0_27_13  service_visit_def_748  1
    service_0_27_13  free_load_conservation_749  2
    service_0_27_14  unique_nonzero_owner_330  1
    service_0_27_14  service_visit_def_748  1
    service_0_27_14  free_load_conservation_749  3
    service_0_27_15  unique_nonzero_owner_331  1
    service_0_27_15  service_visit_def_748  1
    service_0_27_15  free_load_conservation_749  4
    service_1_27_0  unique_nonzero_owner_317  1
    service_1_27_0  service_visit_def_1237  1
    service_1_27_0  free_load_conservation_1238  -11
    service_1_27_0  original_T_including_depot_unload_1286  1320
    service_1_27_1  unique_nonzero_owner_318  1
    service_1_27_1  service_visit_def_1237  1
    service_1_27_1  free_load_conservation_1238  -10
    service_1_27_1  original_T_including_depot_unload_1286  1200
    service_1_27_2  unique_nonzero_owner_319  1
    service_1_27_2  service_visit_def_1237  1
    service_1_27_2  free_load_conservation_1238  -9
    service_1_27_2  original_T_including_depot_unload_1286  1080
    service_1_27_3  unique_nonzero_owner_320  1
    service_1_27_3  service_visit_def_1237  1
    service_1_27_3  free_load_conservation_1238  -8
    service_1_27_3  original_T_including_depot_unload_1286  960
    service_1_27_4  unique_nonzero_owner_321  1
    service_1_27_4  service_visit_def_1237  1
    service_1_27_4  free_load_conservation_1238  -7
    service_1_27_4  original_T_including_depot_unload_1286  840
    service_1_27_5  unique_nonzero_owner_322  1
    service_1_27_5  service_visit_def_1237  1
    service_1_27_5  free_load_conservation_1238  -6
    service_1_27_5  original_T_including_depot_unload_1286  720
    service_1_27_6  unique_nonzero_owner_323  1
    service_1_27_6  service_visit_def_1237  1
    service_1_27_6  free_load_conservation_1238  -5
    service_1_27_6  original_T_including_depot_unload_1286  600
    service_1_27_7  unique_nonzero_owner_324  1
    service_1_27_7  service_visit_def_1237  1
    service_1_27_7  free_load_conservation_1238  -4
    service_1_27_7  original_T_including_depot_unload_1286  480
    service_1_27_8  unique_nonzero_owner_325  1
    service_1_27_8  service_visit_def_1237  1
    service_1_27_8  free_load_conservation_1238  -3
    service_1_27_8  original_T_including_depot_unload_1286  360
    service_1_27_9  unique_nonzero_owner_326  1
    service_1_27_9  service_visit_def_1237  1
    service_1_27_9  free_load_conservation_1238  -2
    service_1_27_9  original_T_including_depot_unload_1286  240
    service_1_27_10  unique_nonzero_owner_327  1
    service_1_27_10  service_visit_def_1237  1
    service_1_27_10  free_load_conservation_1238  -1
    service_1_27_10  original_T_including_depot_unload_1286  120
    service_1_27_12  unique_nonzero_owner_328  1
    service_1_27_12  service_visit_def_1237  1
    service_1_27_12  free_load_conservation_1238  1
    service_1_27_13  unique_nonzero_owner_329  1
    service_1_27_13  service_visit_def_1237  1
    service_1_27_13  free_load_conservation_1238  2
    service_1_27_14  unique_nonzero_owner_330  1
    service_1_27_14  service_visit_def_1237  1
    service_1_27_14  free_load_conservation_1238  3
    service_1_27_15  unique_nonzero_owner_331  1
    service_1_27_15  service_visit_def_1237  1
    service_1_27_15  free_load_conservation_1238  4
    service_2_27_0  unique_nonzero_owner_317  1
    service_2_27_0  service_visit_def_1610  1
    service_2_27_0  free_load_conservation_1611  -11
    service_2_27_0  original_T_including_depot_unload_1657  1320
    service_2_27_1  unique_nonzero_owner_318  1
    service_2_27_1  service_visit_def_1610  1
    service_2_27_1  free_load_conservation_1611  -10
    service_2_27_1  original_T_including_depot_unload_1657  1200
    service_2_27_2  unique_nonzero_owner_319  1
    service_2_27_2  service_visit_def_1610  1
    service_2_27_2  free_load_conservation_1611  -9
    service_2_27_2  original_T_including_depot_unload_1657  1080
    service_2_27_3  unique_nonzero_owner_320  1
    service_2_27_3  service_visit_def_1610  1
    service_2_27_3  free_load_conservation_1611  -8
    service_2_27_3  original_T_including_depot_unload_1657  960
    service_2_27_4  unique_nonzero_owner_321  1
    service_2_27_4  service_visit_def_1610  1
    service_2_27_4  free_load_conservation_1611  -7
    service_2_27_4  original_T_including_depot_unload_1657  840
    service_2_27_5  unique_nonzero_owner_322  1
    service_2_27_5  service_visit_def_1610  1
    service_2_27_5  free_load_conservation_1611  -6
    service_2_27_5  original_T_including_depot_unload_1657  720
    service_2_27_6  unique_nonzero_owner_323  1
    service_2_27_6  service_visit_def_1610  1
    service_2_27_6  free_load_conservation_1611  -5
    service_2_27_6  original_T_including_depot_unload_1657  600
    service_2_27_7  unique_nonzero_owner_324  1
    service_2_27_7  service_visit_def_1610  1
    service_2_27_7  free_load_conservation_1611  -4
    service_2_27_7  original_T_including_depot_unload_1657  480
    service_2_27_8  unique_nonzero_owner_325  1
    service_2_27_8  service_visit_def_1610  1
    service_2_27_8  free_load_conservation_1611  -3
    service_2_27_8  original_T_including_depot_unload_1657  360
    service_2_27_9  unique_nonzero_owner_326  1
    service_2_27_9  service_visit_def_1610  1
    service_2_27_9  free_load_conservation_1611  -2
    service_2_27_9  original_T_including_depot_unload_1657  240
    service_2_27_10  unique_nonzero_owner_327  1
    service_2_27_10  service_visit_def_1610  1
    service_2_27_10  free_load_conservation_1611  -1
    service_2_27_10  original_T_including_depot_unload_1657  120
    service_2_27_12  unique_nonzero_owner_328  1
    service_2_27_12  service_visit_def_1610  1
    service_2_27_12  free_load_conservation_1611  1
    service_2_27_13  unique_nonzero_owner_329  1
    service_2_27_13  service_visit_def_1610  1
    service_2_27_13  free_load_conservation_1611  2
    service_2_27_14  unique_nonzero_owner_330  1
    service_2_27_14  service_visit_def_1610  1
    service_2_27_14  free_load_conservation_1611  3
    service_2_27_15  unique_nonzero_owner_331  1
    service_2_27_15  service_visit_def_1610  1
    service_2_27_15  free_load_conservation_1611  4
    service_0_24_0  unique_nonzero_owner_332  1
    service_0_24_0  service_visit_def_754  1
    service_0_24_0  free_load_conservation_755  -11
    service_0_24_0  original_T_including_depot_unload_795  1320
    service_0_24_1  unique_nonzero_owner_333  1
    service_0_24_1  service_visit_def_754  1
    service_0_24_1  free_load_conservation_755  -10
    service_0_24_1  original_T_including_depot_unload_795  1200
    service_0_24_2  unique_nonzero_owner_334  1
    service_0_24_2  service_visit_def_754  1
    service_0_24_2  free_load_conservation_755  -9
    service_0_24_2  original_T_including_depot_unload_795  1080
    service_0_24_3  unique_nonzero_owner_335  1
    service_0_24_3  service_visit_def_754  1
    service_0_24_3  free_load_conservation_755  -8
    service_0_24_3  original_T_including_depot_unload_795  960
    service_0_24_4  unique_nonzero_owner_336  1
    service_0_24_4  service_visit_def_754  1
    service_0_24_4  free_load_conservation_755  -7
    service_0_24_4  original_T_including_depot_unload_795  840
    service_0_24_5  unique_nonzero_owner_337  1
    service_0_24_5  service_visit_def_754  1
    service_0_24_5  free_load_conservation_755  -6
    service_0_24_5  original_T_including_depot_unload_795  720
    service_0_24_6  unique_nonzero_owner_338  1
    service_0_24_6  service_visit_def_754  1
    service_0_24_6  free_load_conservation_755  -5
    service_0_24_6  original_T_including_depot_unload_795  600
    service_0_24_7  unique_nonzero_owner_339  1
    service_0_24_7  service_visit_def_754  1
    service_0_24_7  free_load_conservation_755  -4
    service_0_24_7  original_T_including_depot_unload_795  480
    service_0_24_8  unique_nonzero_owner_340  1
    service_0_24_8  service_visit_def_754  1
    service_0_24_8  free_load_conservation_755  -3
    service_0_24_8  original_T_including_depot_unload_795  360
    service_0_24_9  unique_nonzero_owner_341  1
    service_0_24_9  service_visit_def_754  1
    service_0_24_9  free_load_conservation_755  -2
    service_0_24_9  original_T_including_depot_unload_795  240
    service_0_24_10  unique_nonzero_owner_342  1
    service_0_24_10  service_visit_def_754  1
    service_0_24_10  free_load_conservation_755  -1
    service_0_24_10  original_T_including_depot_unload_795  120
    service_0_24_12  unique_nonzero_owner_343  1
    service_0_24_12  service_visit_def_754  1
    service_0_24_12  free_load_conservation_755  1
    service_0_24_13  unique_nonzero_owner_344  1
    service_0_24_13  service_visit_def_754  1
    service_0_24_13  free_load_conservation_755  2
    service_0_24_14  unique_nonzero_owner_345  1
    service_0_24_14  service_visit_def_754  1
    service_0_24_14  free_load_conservation_755  3
    service_0_24_15  unique_nonzero_owner_346  1
    service_0_24_15  service_visit_def_754  1
    service_0_24_15  free_load_conservation_755  4
    service_1_24_0  unique_nonzero_owner_332  1
    service_1_24_0  service_visit_def_1243  1
    service_1_24_0  free_load_conservation_1244  -11
    service_1_24_0  original_T_including_depot_unload_1286  1320
    service_1_24_1  unique_nonzero_owner_333  1
    service_1_24_1  service_visit_def_1243  1
    service_1_24_1  free_load_conservation_1244  -10
    service_1_24_1  original_T_including_depot_unload_1286  1200
    service_1_24_2  unique_nonzero_owner_334  1
    service_1_24_2  service_visit_def_1243  1
    service_1_24_2  free_load_conservation_1244  -9
    service_1_24_2  original_T_including_depot_unload_1286  1080
    service_1_24_3  unique_nonzero_owner_335  1
    service_1_24_3  service_visit_def_1243  1
    service_1_24_3  free_load_conservation_1244  -8
    service_1_24_3  original_T_including_depot_unload_1286  960
    service_1_24_4  unique_nonzero_owner_336  1
    service_1_24_4  service_visit_def_1243  1
    service_1_24_4  free_load_conservation_1244  -7
    service_1_24_4  original_T_including_depot_unload_1286  840
    service_1_24_5  unique_nonzero_owner_337  1
    service_1_24_5  service_visit_def_1243  1
    service_1_24_5  free_load_conservation_1244  -6
    service_1_24_5  original_T_including_depot_unload_1286  720
    service_1_24_6  unique_nonzero_owner_338  1
    service_1_24_6  service_visit_def_1243  1
    service_1_24_6  free_load_conservation_1244  -5
    service_1_24_6  original_T_including_depot_unload_1286  600
    service_1_24_7  unique_nonzero_owner_339  1
    service_1_24_7  service_visit_def_1243  1
    service_1_24_7  free_load_conservation_1244  -4
    service_1_24_7  original_T_including_depot_unload_1286  480
    service_1_24_8  unique_nonzero_owner_340  1
    service_1_24_8  service_visit_def_1243  1
    service_1_24_8  free_load_conservation_1244  -3
    service_1_24_8  original_T_including_depot_unload_1286  360
    service_1_24_9  unique_nonzero_owner_341  1
    service_1_24_9  service_visit_def_1243  1
    service_1_24_9  free_load_conservation_1244  -2
    service_1_24_9  original_T_including_depot_unload_1286  240
    service_1_24_10  unique_nonzero_owner_342  1
    service_1_24_10  service_visit_def_1243  1
    service_1_24_10  free_load_conservation_1244  -1
    service_1_24_10  original_T_including_depot_unload_1286  120
    service_1_24_12  unique_nonzero_owner_343  1
    service_1_24_12  service_visit_def_1243  1
    service_1_24_12  free_load_conservation_1244  1
    service_1_24_13  unique_nonzero_owner_344  1
    service_1_24_13  service_visit_def_1243  1
    service_1_24_13  free_load_conservation_1244  2
    service_1_24_14  unique_nonzero_owner_345  1
    service_1_24_14  service_visit_def_1243  1
    service_1_24_14  free_load_conservation_1244  3
    service_1_24_15  unique_nonzero_owner_346  1
    service_1_24_15  service_visit_def_1243  1
    service_1_24_15  free_load_conservation_1244  4
    service_2_24_0  unique_nonzero_owner_332  1
    service_2_24_0  service_visit_def_1616  1
    service_2_24_0  free_load_conservation_1617  -11
    service_2_24_0  original_T_including_depot_unload_1657  1320
    service_2_24_1  unique_nonzero_owner_333  1
    service_2_24_1  service_visit_def_1616  1
    service_2_24_1  free_load_conservation_1617  -10
    service_2_24_1  original_T_including_depot_unload_1657  1200
    service_2_24_2  unique_nonzero_owner_334  1
    service_2_24_2  service_visit_def_1616  1
    service_2_24_2  free_load_conservation_1617  -9
    service_2_24_2  original_T_including_depot_unload_1657  1080
    service_2_24_3  unique_nonzero_owner_335  1
    service_2_24_3  service_visit_def_1616  1
    service_2_24_3  free_load_conservation_1617  -8
    service_2_24_3  original_T_including_depot_unload_1657  960
    service_2_24_4  unique_nonzero_owner_336  1
    service_2_24_4  service_visit_def_1616  1
    service_2_24_4  free_load_conservation_1617  -7
    service_2_24_4  original_T_including_depot_unload_1657  840
    service_2_24_5  unique_nonzero_owner_337  1
    service_2_24_5  service_visit_def_1616  1
    service_2_24_5  free_load_conservation_1617  -6
    service_2_24_5  original_T_including_depot_unload_1657  720
    service_2_24_6  unique_nonzero_owner_338  1
    service_2_24_6  service_visit_def_1616  1
    service_2_24_6  free_load_conservation_1617  -5
    service_2_24_6  original_T_including_depot_unload_1657  600
    service_2_24_7  unique_nonzero_owner_339  1
    service_2_24_7  service_visit_def_1616  1
    service_2_24_7  free_load_conservation_1617  -4
    service_2_24_7  original_T_including_depot_unload_1657  480
    service_2_24_8  unique_nonzero_owner_340  1
    service_2_24_8  service_visit_def_1616  1
    service_2_24_8  free_load_conservation_1617  -3
    service_2_24_8  original_T_including_depot_unload_1657  360
    service_2_24_9  unique_nonzero_owner_341  1
    service_2_24_9  service_visit_def_1616  1
    service_2_24_9  free_load_conservation_1617  -2
    service_2_24_9  original_T_including_depot_unload_1657  240
    service_2_24_10  unique_nonzero_owner_342  1
    service_2_24_10  service_visit_def_1616  1
    service_2_24_10  free_load_conservation_1617  -1
    service_2_24_10  original_T_including_depot_unload_1657  120
    service_2_24_12  unique_nonzero_owner_343  1
    service_2_24_12  service_visit_def_1616  1
    service_2_24_12  free_load_conservation_1617  1
    service_2_24_13  unique_nonzero_owner_344  1
    service_2_24_13  service_visit_def_1616  1
    service_2_24_13  free_load_conservation_1617  2
    service_2_24_14  unique_nonzero_owner_345  1
    service_2_24_14  service_visit_def_1616  1
    service_2_24_14  free_load_conservation_1617  3
    service_2_24_15  unique_nonzero_owner_346  1
    service_2_24_15  service_visit_def_1616  1
    service_2_24_15  free_load_conservation_1617  4
    service_0_31_0  unique_nonzero_owner_347  1
    service_0_31_0  service_visit_def_760  1
    service_0_31_0  free_load_conservation_761  -2
    service_0_31_0  original_T_including_depot_unload_795  240
    service_0_31_1  unique_nonzero_owner_348  1
    service_0_31_1  service_visit_def_760  1
    service_0_31_1  free_load_conservation_761  -1
    service_0_31_1  original_T_including_depot_unload_795  120
    service_0_31_3  unique_nonzero_owner_349  1
    service_0_31_3  service_visit_def_760  1
    service_0_31_3  free_load_conservation_761  1
    service_0_31_4  unique_nonzero_owner_350  1
    service_0_31_4  service_visit_def_760  1
    service_0_31_4  free_load_conservation_761  2
    service_0_31_5  unique_nonzero_owner_351  1
    service_0_31_5  service_visit_def_760  1
    service_0_31_5  free_load_conservation_761  3
    service_0_31_6  unique_nonzero_owner_352  1
    service_0_31_6  service_visit_def_760  1
    service_0_31_6  free_load_conservation_761  4
    service_0_31_7  unique_nonzero_owner_353  1
    service_0_31_7  service_visit_def_760  1
    service_0_31_7  free_load_conservation_761  5
    service_0_31_8  unique_nonzero_owner_354  1
    service_0_31_8  service_visit_def_760  1
    service_0_31_8  free_load_conservation_761  6
    service_0_31_9  unique_nonzero_owner_355  1
    service_0_31_9  service_visit_def_760  1
    service_0_31_9  free_load_conservation_761  7
    service_0_31_10  unique_nonzero_owner_356  1
    service_0_31_10  service_visit_def_760  1
    service_0_31_10  free_load_conservation_761  8
    service_0_31_11  unique_nonzero_owner_357  1
    service_0_31_11  service_visit_def_760  1
    service_0_31_11  free_load_conservation_761  9
    service_0_31_12  unique_nonzero_owner_358  1
    service_0_31_12  service_visit_def_760  1
    service_0_31_12  free_load_conservation_761  10
    service_1_31_0  unique_nonzero_owner_347  1
    service_1_31_0  service_visit_def_1249  1
    service_1_31_0  free_load_conservation_1250  -2
    service_1_31_0  original_T_including_depot_unload_1286  240
    service_1_31_1  unique_nonzero_owner_348  1
    service_1_31_1  service_visit_def_1249  1
    service_1_31_1  free_load_conservation_1250  -1
    service_1_31_1  original_T_including_depot_unload_1286  120
    service_1_31_3  unique_nonzero_owner_349  1
    service_1_31_3  service_visit_def_1249  1
    service_1_31_3  free_load_conservation_1250  1
    service_1_31_4  unique_nonzero_owner_350  1
    service_1_31_4  service_visit_def_1249  1
    service_1_31_4  free_load_conservation_1250  2
    service_1_31_5  unique_nonzero_owner_351  1
    service_1_31_5  service_visit_def_1249  1
    service_1_31_5  free_load_conservation_1250  3
    service_1_31_6  unique_nonzero_owner_352  1
    service_1_31_6  service_visit_def_1249  1
    service_1_31_6  free_load_conservation_1250  4
    service_1_31_7  unique_nonzero_owner_353  1
    service_1_31_7  service_visit_def_1249  1
    service_1_31_7  free_load_conservation_1250  5
    service_1_31_8  unique_nonzero_owner_354  1
    service_1_31_8  service_visit_def_1249  1
    service_1_31_8  free_load_conservation_1250  6
    service_1_31_9  unique_nonzero_owner_355  1
    service_1_31_9  service_visit_def_1249  1
    service_1_31_9  free_load_conservation_1250  7
    service_1_31_10  unique_nonzero_owner_356  1
    service_1_31_10  service_visit_def_1249  1
    service_1_31_10  free_load_conservation_1250  8
    service_1_31_11  unique_nonzero_owner_357  1
    service_1_31_11  service_visit_def_1249  1
    service_1_31_11  free_load_conservation_1250  9
    service_1_31_12  unique_nonzero_owner_358  1
    service_1_31_12  service_visit_def_1249  1
    service_1_31_12  free_load_conservation_1250  10
    service_2_31_0  unique_nonzero_owner_347  1
    service_2_31_0  service_visit_def_1622  1
    service_2_31_0  free_load_conservation_1623  -2
    service_2_31_0  original_T_including_depot_unload_1657  240
    service_2_31_1  unique_nonzero_owner_348  1
    service_2_31_1  service_visit_def_1622  1
    service_2_31_1  free_load_conservation_1623  -1
    service_2_31_1  original_T_including_depot_unload_1657  120
    service_2_31_3  unique_nonzero_owner_349  1
    service_2_31_3  service_visit_def_1622  1
    service_2_31_3  free_load_conservation_1623  1
    service_2_31_4  unique_nonzero_owner_350  1
    service_2_31_4  service_visit_def_1622  1
    service_2_31_4  free_load_conservation_1623  2
    service_2_31_5  unique_nonzero_owner_351  1
    service_2_31_5  service_visit_def_1622  1
    service_2_31_5  free_load_conservation_1623  3
    service_2_31_6  unique_nonzero_owner_352  1
    service_2_31_6  service_visit_def_1622  1
    service_2_31_6  free_load_conservation_1623  4
    service_2_31_7  unique_nonzero_owner_353  1
    service_2_31_7  service_visit_def_1622  1
    service_2_31_7  free_load_conservation_1623  5
    service_2_31_8  unique_nonzero_owner_354  1
    service_2_31_8  service_visit_def_1622  1
    service_2_31_8  free_load_conservation_1623  6
    service_2_31_9  unique_nonzero_owner_355  1
    service_2_31_9  service_visit_def_1622  1
    service_2_31_9  free_load_conservation_1623  7
    service_2_31_10  unique_nonzero_owner_356  1
    service_2_31_10  service_visit_def_1622  1
    service_2_31_10  free_load_conservation_1623  8
    service_2_31_11  unique_nonzero_owner_357  1
    service_2_31_11  service_visit_def_1622  1
    service_2_31_11  free_load_conservation_1623  9
    service_2_31_12  unique_nonzero_owner_358  1
    service_2_31_12  service_visit_def_1622  1
    service_2_31_12  free_load_conservation_1623  10
    service_0_34_0  unique_nonzero_owner_359  1
    service_0_34_0  service_visit_def_766  1
    service_0_34_0  free_load_conservation_767  -1
    service_0_34_0  original_T_including_depot_unload_795  120
    service_0_34_2  unique_nonzero_owner_360  1
    service_0_34_2  service_visit_def_766  1
    service_0_34_2  free_load_conservation_767  1
    service_0_34_3  unique_nonzero_owner_361  1
    service_0_34_3  service_visit_def_766  1
    service_0_34_3  free_load_conservation_767  2
    service_0_34_4  unique_nonzero_owner_362  1
    service_0_34_4  service_visit_def_766  1
    service_0_34_4  free_load_conservation_767  3
    service_0_34_5  unique_nonzero_owner_363  1
    service_0_34_5  service_visit_def_766  1
    service_0_34_5  free_load_conservation_767  4
    service_0_34_6  unique_nonzero_owner_364  1
    service_0_34_6  service_visit_def_766  1
    service_0_34_6  free_load_conservation_767  5
    service_0_34_7  unique_nonzero_owner_365  1
    service_0_34_7  service_visit_def_766  1
    service_0_34_7  free_load_conservation_767  6
    service_0_34_8  unique_nonzero_owner_366  1
    service_0_34_8  service_visit_def_766  1
    service_0_34_8  free_load_conservation_767  7
    service_0_34_9  unique_nonzero_owner_367  1
    service_0_34_9  service_visit_def_766  1
    service_0_34_9  free_load_conservation_767  8
    service_0_34_10  unique_nonzero_owner_368  1
    service_0_34_10  service_visit_def_766  1
    service_0_34_10  free_load_conservation_767  9
    service_0_34_11  unique_nonzero_owner_369  1
    service_0_34_11  service_visit_def_766  1
    service_0_34_11  free_load_conservation_767  10
    service_1_34_0  unique_nonzero_owner_359  1
    service_1_34_0  service_visit_def_1255  1
    service_1_34_0  free_load_conservation_1256  -1
    service_1_34_0  original_T_including_depot_unload_1286  120
    service_1_34_2  unique_nonzero_owner_360  1
    service_1_34_2  service_visit_def_1255  1
    service_1_34_2  free_load_conservation_1256  1
    service_1_34_3  unique_nonzero_owner_361  1
    service_1_34_3  service_visit_def_1255  1
    service_1_34_3  free_load_conservation_1256  2
    service_1_34_4  unique_nonzero_owner_362  1
    service_1_34_4  service_visit_def_1255  1
    service_1_34_4  free_load_conservation_1256  3
    service_1_34_5  unique_nonzero_owner_363  1
    service_1_34_5  service_visit_def_1255  1
    service_1_34_5  free_load_conservation_1256  4
    service_1_34_6  unique_nonzero_owner_364  1
    service_1_34_6  service_visit_def_1255  1
    service_1_34_6  free_load_conservation_1256  5
    service_1_34_7  unique_nonzero_owner_365  1
    service_1_34_7  service_visit_def_1255  1
    service_1_34_7  free_load_conservation_1256  6
    service_1_34_8  unique_nonzero_owner_366  1
    service_1_34_8  service_visit_def_1255  1
    service_1_34_8  free_load_conservation_1256  7
    service_1_34_9  unique_nonzero_owner_367  1
    service_1_34_9  service_visit_def_1255  1
    service_1_34_9  free_load_conservation_1256  8
    service_1_34_10  unique_nonzero_owner_368  1
    service_1_34_10  service_visit_def_1255  1
    service_1_34_10  free_load_conservation_1256  9
    service_1_34_11  unique_nonzero_owner_369  1
    service_1_34_11  service_visit_def_1255  1
    service_1_34_11  free_load_conservation_1256  10
    service_2_34_0  unique_nonzero_owner_359  1
    service_2_34_0  service_visit_def_1628  1
    service_2_34_0  free_load_conservation_1629  -1
    service_2_34_0  original_T_including_depot_unload_1657  120
    service_2_34_2  unique_nonzero_owner_360  1
    service_2_34_2  service_visit_def_1628  1
    service_2_34_2  free_load_conservation_1629  1
    service_2_34_3  unique_nonzero_owner_361  1
    service_2_34_3  service_visit_def_1628  1
    service_2_34_3  free_load_conservation_1629  2
    service_2_34_4  unique_nonzero_owner_362  1
    service_2_34_4  service_visit_def_1628  1
    service_2_34_4  free_load_conservation_1629  3
    service_2_34_5  unique_nonzero_owner_363  1
    service_2_34_5  service_visit_def_1628  1
    service_2_34_5  free_load_conservation_1629  4
    service_2_34_6  unique_nonzero_owner_364  1
    service_2_34_6  service_visit_def_1628  1
    service_2_34_6  free_load_conservation_1629  5
    service_2_34_7  unique_nonzero_owner_365  1
    service_2_34_7  service_visit_def_1628  1
    service_2_34_7  free_load_conservation_1629  6
    service_2_34_8  unique_nonzero_owner_366  1
    service_2_34_8  service_visit_def_1628  1
    service_2_34_8  free_load_conservation_1629  7
    service_2_34_9  unique_nonzero_owner_367  1
    service_2_34_9  service_visit_def_1628  1
    service_2_34_9  free_load_conservation_1629  8
    service_2_34_10  unique_nonzero_owner_368  1
    service_2_34_10  service_visit_def_1628  1
    service_2_34_10  free_load_conservation_1629  9
    service_2_34_11  unique_nonzero_owner_369  1
    service_2_34_11  service_visit_def_1628  1
    service_2_34_11  free_load_conservation_1629  10
    service_0_16_0  unique_nonzero_owner_370  1
    service_0_16_0  service_visit_def_772  1
    service_0_16_0  free_load_conservation_773  -1
    service_0_16_0  original_T_including_depot_unload_795  120
    service_0_16_2  unique_nonzero_owner_371  1
    service_0_16_2  service_visit_def_772  1
    service_0_16_2  free_load_conservation_773  1
    service_0_16_3  unique_nonzero_owner_372  1
    service_0_16_3  service_visit_def_772  1
    service_0_16_3  free_load_conservation_773  2
    service_0_16_4  unique_nonzero_owner_373  1
    service_0_16_4  service_visit_def_772  1
    service_0_16_4  free_load_conservation_773  3
    service_0_16_5  unique_nonzero_owner_374  1
    service_0_16_5  service_visit_def_772  1
    service_0_16_5  free_load_conservation_773  4
    service_0_16_6  unique_nonzero_owner_375  1
    service_0_16_6  service_visit_def_772  1
    service_0_16_6  free_load_conservation_773  5
    service_0_16_7  unique_nonzero_owner_376  1
    service_0_16_7  service_visit_def_772  1
    service_0_16_7  free_load_conservation_773  6
    service_0_16_8  unique_nonzero_owner_377  1
    service_0_16_8  service_visit_def_772  1
    service_0_16_8  free_load_conservation_773  7
    service_0_16_9  unique_nonzero_owner_378  1
    service_0_16_9  service_visit_def_772  1
    service_0_16_9  free_load_conservation_773  8
    service_0_16_10  unique_nonzero_owner_379  1
    service_0_16_10  service_visit_def_772  1
    service_0_16_10  free_load_conservation_773  9
    service_0_16_11  unique_nonzero_owner_380  1
    service_0_16_11  service_visit_def_772  1
    service_0_16_11  free_load_conservation_773  10
    service_0_16_12  unique_nonzero_owner_381  1
    service_0_16_12  service_visit_def_772  1
    service_0_16_12  free_load_conservation_773  11
    service_1_16_0  unique_nonzero_owner_370  1
    service_1_16_0  service_visit_def_1261  1
    service_1_16_0  free_load_conservation_1262  -1
    service_1_16_0  original_T_including_depot_unload_1286  120
    service_1_16_2  unique_nonzero_owner_371  1
    service_1_16_2  service_visit_def_1261  1
    service_1_16_2  free_load_conservation_1262  1
    service_1_16_3  unique_nonzero_owner_372  1
    service_1_16_3  service_visit_def_1261  1
    service_1_16_3  free_load_conservation_1262  2
    service_1_16_4  unique_nonzero_owner_373  1
    service_1_16_4  service_visit_def_1261  1
    service_1_16_4  free_load_conservation_1262  3
    service_1_16_5  unique_nonzero_owner_374  1
    service_1_16_5  service_visit_def_1261  1
    service_1_16_5  free_load_conservation_1262  4
    service_1_16_6  unique_nonzero_owner_375  1
    service_1_16_6  service_visit_def_1261  1
    service_1_16_6  free_load_conservation_1262  5
    service_1_16_7  unique_nonzero_owner_376  1
    service_1_16_7  service_visit_def_1261  1
    service_1_16_7  free_load_conservation_1262  6
    service_1_16_8  unique_nonzero_owner_377  1
    service_1_16_8  service_visit_def_1261  1
    service_1_16_8  free_load_conservation_1262  7
    service_1_16_9  unique_nonzero_owner_378  1
    service_1_16_9  service_visit_def_1261  1
    service_1_16_9  free_load_conservation_1262  8
    service_1_16_10  unique_nonzero_owner_379  1
    service_1_16_10  service_visit_def_1261  1
    service_1_16_10  free_load_conservation_1262  9
    service_1_16_11  unique_nonzero_owner_380  1
    service_1_16_11  service_visit_def_1261  1
    service_1_16_11  free_load_conservation_1262  10
    service_1_16_12  unique_nonzero_owner_381  1
    service_1_16_12  service_visit_def_1261  1
    service_1_16_12  free_load_conservation_1262  11
    service_2_16_0  unique_nonzero_owner_370  1
    service_2_16_0  service_visit_def_1634  1
    service_2_16_0  free_load_conservation_1635  -1
    service_2_16_0  original_T_including_depot_unload_1657  120
    service_2_16_2  unique_nonzero_owner_371  1
    service_2_16_2  service_visit_def_1634  1
    service_2_16_2  free_load_conservation_1635  1
    service_2_16_3  unique_nonzero_owner_372  1
    service_2_16_3  service_visit_def_1634  1
    service_2_16_3  free_load_conservation_1635  2
    service_2_16_4  unique_nonzero_owner_373  1
    service_2_16_4  service_visit_def_1634  1
    service_2_16_4  free_load_conservation_1635  3
    service_2_16_5  unique_nonzero_owner_374  1
    service_2_16_5  service_visit_def_1634  1
    service_2_16_5  free_load_conservation_1635  4
    service_2_16_6  unique_nonzero_owner_375  1
    service_2_16_6  service_visit_def_1634  1
    service_2_16_6  free_load_conservation_1635  5
    service_2_16_7  unique_nonzero_owner_376  1
    service_2_16_7  service_visit_def_1634  1
    service_2_16_7  free_load_conservation_1635  6
    service_2_16_8  unique_nonzero_owner_377  1
    service_2_16_8  service_visit_def_1634  1
    service_2_16_8  free_load_conservation_1635  7
    service_2_16_9  unique_nonzero_owner_378  1
    service_2_16_9  service_visit_def_1634  1
    service_2_16_9  free_load_conservation_1635  8
    service_2_16_10  unique_nonzero_owner_379  1
    service_2_16_10  service_visit_def_1634  1
    service_2_16_10  free_load_conservation_1635  9
    service_2_16_11  unique_nonzero_owner_380  1
    service_2_16_11  service_visit_def_1634  1
    service_2_16_11  free_load_conservation_1635  10
    service_2_16_12  unique_nonzero_owner_381  1
    service_2_16_12  service_visit_def_1634  1
    service_2_16_12  free_load_conservation_1635  11
    service_0_29_0  unique_nonzero_owner_382  1
    service_0_29_0  service_visit_def_778  1
    service_0_29_0  free_load_conservation_779  -11
    service_0_29_0  original_T_including_depot_unload_795  1320
    service_0_29_1  unique_nonzero_owner_383  1
    service_0_29_1  service_visit_def_778  1
    service_0_29_1  free_load_conservation_779  -10
    service_0_29_1  original_T_including_depot_unload_795  1200
    service_0_29_2  unique_nonzero_owner_384  1
    service_0_29_2  service_visit_def_778  1
    service_0_29_2  free_load_conservation_779  -9
    service_0_29_2  original_T_including_depot_unload_795  1080
    service_0_29_3  unique_nonzero_owner_385  1
    service_0_29_3  service_visit_def_778  1
    service_0_29_3  free_load_conservation_779  -8
    service_0_29_3  original_T_including_depot_unload_795  960
    service_0_29_4  unique_nonzero_owner_386  1
    service_0_29_4  service_visit_def_778  1
    service_0_29_4  free_load_conservation_779  -7
    service_0_29_4  original_T_including_depot_unload_795  840
    service_0_29_5  unique_nonzero_owner_387  1
    service_0_29_5  service_visit_def_778  1
    service_0_29_5  free_load_conservation_779  -6
    service_0_29_5  original_T_including_depot_unload_795  720
    service_0_29_6  unique_nonzero_owner_388  1
    service_0_29_6  service_visit_def_778  1
    service_0_29_6  free_load_conservation_779  -5
    service_0_29_6  original_T_including_depot_unload_795  600
    service_0_29_7  unique_nonzero_owner_389  1
    service_0_29_7  service_visit_def_778  1
    service_0_29_7  free_load_conservation_779  -4
    service_0_29_7  original_T_including_depot_unload_795  480
    service_0_29_8  unique_nonzero_owner_390  1
    service_0_29_8  service_visit_def_778  1
    service_0_29_8  free_load_conservation_779  -3
    service_0_29_8  original_T_including_depot_unload_795  360
    service_0_29_9  unique_nonzero_owner_391  1
    service_0_29_9  service_visit_def_778  1
    service_0_29_9  free_load_conservation_779  -2
    service_0_29_9  original_T_including_depot_unload_795  240
    service_0_29_10  unique_nonzero_owner_392  1
    service_0_29_10  service_visit_def_778  1
    service_0_29_10  free_load_conservation_779  -1
    service_0_29_10  original_T_including_depot_unload_795  120
    service_0_29_12  unique_nonzero_owner_393  1
    service_0_29_12  service_visit_def_778  1
    service_0_29_12  free_load_conservation_779  1
    service_0_29_13  unique_nonzero_owner_394  1
    service_0_29_13  service_visit_def_778  1
    service_0_29_13  free_load_conservation_779  2
    service_0_29_14  unique_nonzero_owner_395  1
    service_0_29_14  service_visit_def_778  1
    service_0_29_14  free_load_conservation_779  3
    service_0_29_15  unique_nonzero_owner_396  1
    service_0_29_15  service_visit_def_778  1
    service_0_29_15  free_load_conservation_779  4
    service_1_29_0  unique_nonzero_owner_382  1
    service_1_29_0  service_visit_def_1267  1
    service_1_29_0  free_load_conservation_1268  -11
    service_1_29_0  original_T_including_depot_unload_1286  1320
    service_1_29_1  unique_nonzero_owner_383  1
    service_1_29_1  service_visit_def_1267  1
    service_1_29_1  free_load_conservation_1268  -10
    service_1_29_1  original_T_including_depot_unload_1286  1200
    service_1_29_2  unique_nonzero_owner_384  1
    service_1_29_2  service_visit_def_1267  1
    service_1_29_2  free_load_conservation_1268  -9
    service_1_29_2  original_T_including_depot_unload_1286  1080
    service_1_29_3  unique_nonzero_owner_385  1
    service_1_29_3  service_visit_def_1267  1
    service_1_29_3  free_load_conservation_1268  -8
    service_1_29_3  original_T_including_depot_unload_1286  960
    service_1_29_4  unique_nonzero_owner_386  1
    service_1_29_4  service_visit_def_1267  1
    service_1_29_4  free_load_conservation_1268  -7
    service_1_29_4  original_T_including_depot_unload_1286  840
    service_1_29_5  unique_nonzero_owner_387  1
    service_1_29_5  service_visit_def_1267  1
    service_1_29_5  free_load_conservation_1268  -6
    service_1_29_5  original_T_including_depot_unload_1286  720
    service_1_29_6  unique_nonzero_owner_388  1
    service_1_29_6  service_visit_def_1267  1
    service_1_29_6  free_load_conservation_1268  -5
    service_1_29_6  original_T_including_depot_unload_1286  600
    service_1_29_7  unique_nonzero_owner_389  1
    service_1_29_7  service_visit_def_1267  1
    service_1_29_7  free_load_conservation_1268  -4
    service_1_29_7  original_T_including_depot_unload_1286  480
    service_1_29_8  unique_nonzero_owner_390  1
    service_1_29_8  service_visit_def_1267  1
    service_1_29_8  free_load_conservation_1268  -3
    service_1_29_8  original_T_including_depot_unload_1286  360
    service_1_29_9  unique_nonzero_owner_391  1
    service_1_29_9  service_visit_def_1267  1
    service_1_29_9  free_load_conservation_1268  -2
    service_1_29_9  original_T_including_depot_unload_1286  240
    service_1_29_10  unique_nonzero_owner_392  1
    service_1_29_10  service_visit_def_1267  1
    service_1_29_10  free_load_conservation_1268  -1
    service_1_29_10  original_T_including_depot_unload_1286  120
    service_1_29_12  unique_nonzero_owner_393  1
    service_1_29_12  service_visit_def_1267  1
    service_1_29_12  free_load_conservation_1268  1
    service_1_29_13  unique_nonzero_owner_394  1
    service_1_29_13  service_visit_def_1267  1
    service_1_29_13  free_load_conservation_1268  2
    service_1_29_14  unique_nonzero_owner_395  1
    service_1_29_14  service_visit_def_1267  1
    service_1_29_14  free_load_conservation_1268  3
    service_1_29_15  unique_nonzero_owner_396  1
    service_1_29_15  service_visit_def_1267  1
    service_1_29_15  free_load_conservation_1268  4
    service_2_29_0  unique_nonzero_owner_382  1
    service_2_29_0  service_visit_def_1640  1
    service_2_29_0  free_load_conservation_1641  -11
    service_2_29_0  original_T_including_depot_unload_1657  1320
    service_2_29_1  unique_nonzero_owner_383  1
    service_2_29_1  service_visit_def_1640  1
    service_2_29_1  free_load_conservation_1641  -10
    service_2_29_1  original_T_including_depot_unload_1657  1200
    service_2_29_2  unique_nonzero_owner_384  1
    service_2_29_2  service_visit_def_1640  1
    service_2_29_2  free_load_conservation_1641  -9
    service_2_29_2  original_T_including_depot_unload_1657  1080
    service_2_29_3  unique_nonzero_owner_385  1
    service_2_29_3  service_visit_def_1640  1
    service_2_29_3  free_load_conservation_1641  -8
    service_2_29_3  original_T_including_depot_unload_1657  960
    service_2_29_4  unique_nonzero_owner_386  1
    service_2_29_4  service_visit_def_1640  1
    service_2_29_4  free_load_conservation_1641  -7
    service_2_29_4  original_T_including_depot_unload_1657  840
    service_2_29_5  unique_nonzero_owner_387  1
    service_2_29_5  service_visit_def_1640  1
    service_2_29_5  free_load_conservation_1641  -6
    service_2_29_5  original_T_including_depot_unload_1657  720
    service_2_29_6  unique_nonzero_owner_388  1
    service_2_29_6  service_visit_def_1640  1
    service_2_29_6  free_load_conservation_1641  -5
    service_2_29_6  original_T_including_depot_unload_1657  600
    service_2_29_7  unique_nonzero_owner_389  1
    service_2_29_7  service_visit_def_1640  1
    service_2_29_7  free_load_conservation_1641  -4
    service_2_29_7  original_T_including_depot_unload_1657  480
    service_2_29_8  unique_nonzero_owner_390  1
    service_2_29_8  service_visit_def_1640  1
    service_2_29_8  free_load_conservation_1641  -3
    service_2_29_8  original_T_including_depot_unload_1657  360
    service_2_29_9  unique_nonzero_owner_391  1
    service_2_29_9  service_visit_def_1640  1
    service_2_29_9  free_load_conservation_1641  -2
    service_2_29_9  original_T_including_depot_unload_1657  240
    service_2_29_10  unique_nonzero_owner_392  1
    service_2_29_10  service_visit_def_1640  1
    service_2_29_10  free_load_conservation_1641  -1
    service_2_29_10  original_T_including_depot_unload_1657  120
    service_2_29_12  unique_nonzero_owner_393  1
    service_2_29_12  service_visit_def_1640  1
    service_2_29_12  free_load_conservation_1641  1
    service_2_29_13  unique_nonzero_owner_394  1
    service_2_29_13  service_visit_def_1640  1
    service_2_29_13  free_load_conservation_1641  2
    service_2_29_14  unique_nonzero_owner_395  1
    service_2_29_14  service_visit_def_1640  1
    service_2_29_14  free_load_conservation_1641  3
    service_2_29_15  unique_nonzero_owner_396  1
    service_2_29_15  service_visit_def_1640  1
    service_2_29_15  free_load_conservation_1641  4
    service_0_32_1  unique_nonzero_owner_397  1
    service_0_32_1  service_visit_def_784  1
    service_0_32_1  free_load_conservation_785  1
    service_0_32_2  unique_nonzero_owner_398  1
    service_0_32_2  service_visit_def_784  1
    service_0_32_2  free_load_conservation_785  2
    service_0_32_3  unique_nonzero_owner_399  1
    service_0_32_3  service_visit_def_784  1
    service_0_32_3  free_load_conservation_785  3
    service_0_32_4  unique_nonzero_owner_400  1
    service_0_32_4  service_visit_def_784  1
    service_0_32_4  free_load_conservation_785  4
    service_0_32_5  unique_nonzero_owner_401  1
    service_0_32_5  service_visit_def_784  1
    service_0_32_5  free_load_conservation_785  5
    service_0_32_6  unique_nonzero_owner_402  1
    service_0_32_6  service_visit_def_784  1
    service_0_32_6  free_load_conservation_785  6
    service_0_32_7  unique_nonzero_owner_403  1
    service_0_32_7  service_visit_def_784  1
    service_0_32_7  free_load_conservation_785  7
    service_0_32_8  unique_nonzero_owner_404  1
    service_0_32_8  service_visit_def_784  1
    service_0_32_8  free_load_conservation_785  8
    service_0_32_9  unique_nonzero_owner_405  1
    service_0_32_9  service_visit_def_784  1
    service_0_32_9  free_load_conservation_785  9
    service_0_32_10  unique_nonzero_owner_406  1
    service_0_32_10  service_visit_def_784  1
    service_0_32_10  free_load_conservation_785  10
    service_0_32_11  unique_nonzero_owner_407  1
    service_0_32_11  service_visit_def_784  1
    service_0_32_11  free_load_conservation_785  11
    service_0_32_12  unique_nonzero_owner_408  1
    service_0_32_12  service_visit_def_784  1
    service_0_32_12  free_load_conservation_785  12
    service_1_32_1  unique_nonzero_owner_397  1
    service_1_32_1  service_visit_def_1273  1
    service_1_32_1  free_load_conservation_1274  1
    service_1_32_2  unique_nonzero_owner_398  1
    service_1_32_2  service_visit_def_1273  1
    service_1_32_2  free_load_conservation_1274  2
    service_1_32_3  unique_nonzero_owner_399  1
    service_1_32_3  service_visit_def_1273  1
    service_1_32_3  free_load_conservation_1274  3
    service_1_32_4  unique_nonzero_owner_400  1
    service_1_32_4  service_visit_def_1273  1
    service_1_32_4  free_load_conservation_1274  4
    service_1_32_5  unique_nonzero_owner_401  1
    service_1_32_5  service_visit_def_1273  1
    service_1_32_5  free_load_conservation_1274  5
    service_1_32_6  unique_nonzero_owner_402  1
    service_1_32_6  service_visit_def_1273  1
    service_1_32_6  free_load_conservation_1274  6
    service_1_32_7  unique_nonzero_owner_403  1
    service_1_32_7  service_visit_def_1273  1
    service_1_32_7  free_load_conservation_1274  7
    service_1_32_8  unique_nonzero_owner_404  1
    service_1_32_8  service_visit_def_1273  1
    service_1_32_8  free_load_conservation_1274  8
    service_1_32_9  unique_nonzero_owner_405  1
    service_1_32_9  service_visit_def_1273  1
    service_1_32_9  free_load_conservation_1274  9
    service_1_32_10  unique_nonzero_owner_406  1
    service_1_32_10  service_visit_def_1273  1
    service_1_32_10  free_load_conservation_1274  10
    service_1_32_11  unique_nonzero_owner_407  1
    service_1_32_11  service_visit_def_1273  1
    service_1_32_11  free_load_conservation_1274  11
    service_1_32_12  unique_nonzero_owner_408  1
    service_1_32_12  service_visit_def_1273  1
    service_1_32_12  free_load_conservation_1274  12
    service_2_32_1  unique_nonzero_owner_397  1
    service_2_32_1  service_visit_def_1646  1
    service_2_32_1  free_load_conservation_1647  1
    service_2_32_2  unique_nonzero_owner_398  1
    service_2_32_2  service_visit_def_1646  1
    service_2_32_2  free_load_conservation_1647  2
    service_2_32_3  unique_nonzero_owner_399  1
    service_2_32_3  service_visit_def_1646  1
    service_2_32_3  free_load_conservation_1647  3
    service_2_32_4  unique_nonzero_owner_400  1
    service_2_32_4  service_visit_def_1646  1
    service_2_32_4  free_load_conservation_1647  4
    service_2_32_5  unique_nonzero_owner_401  1
    service_2_32_5  service_visit_def_1646  1
    service_2_32_5  free_load_conservation_1647  5
    service_2_32_6  unique_nonzero_owner_402  1
    service_2_32_6  service_visit_def_1646  1
    service_2_32_6  free_load_conservation_1647  6
    service_2_32_7  unique_nonzero_owner_403  1
    service_2_32_7  service_visit_def_1646  1
    service_2_32_7  free_load_conservation_1647  7
    service_2_32_8  unique_nonzero_owner_404  1
    service_2_32_8  service_visit_def_1646  1
    service_2_32_8  free_load_conservation_1647  8
    service_2_32_9  unique_nonzero_owner_405  1
    service_2_32_9  service_visit_def_1646  1
    service_2_32_9  free_load_conservation_1647  9
    service_2_32_10  unique_nonzero_owner_406  1
    service_2_32_10  service_visit_def_1646  1
    service_2_32_10  free_load_conservation_1647  10
    service_2_32_11  unique_nonzero_owner_407  1
    service_2_32_11  service_visit_def_1646  1
    service_2_32_11  free_load_conservation_1647  11
    service_2_32_12  unique_nonzero_owner_408  1
    service_2_32_12  service_visit_def_1646  1
    service_2_32_12  free_load_conservation_1647  12
    service_0_33_0  unique_nonzero_owner_409  1
    service_0_33_0  service_visit_def_790  1
    service_0_33_0  free_load_conservation_791  -1
    service_0_33_0  original_T_including_depot_unload_795  120
    service_0_33_2  unique_nonzero_owner_410  1
    service_0_33_2  service_visit_def_790  1
    service_0_33_2  free_load_conservation_791  1
    service_0_33_3  unique_nonzero_owner_411  1
    service_0_33_3  service_visit_def_790  1
    service_0_33_3  free_load_conservation_791  2
    service_0_33_4  unique_nonzero_owner_412  1
    service_0_33_4  service_visit_def_790  1
    service_0_33_4  free_load_conservation_791  3
    service_0_33_5  unique_nonzero_owner_413  1
    service_0_33_5  service_visit_def_790  1
    service_0_33_5  free_load_conservation_791  4
    service_0_33_6  unique_nonzero_owner_414  1
    service_0_33_6  service_visit_def_790  1
    service_0_33_6  free_load_conservation_791  5
    service_0_33_7  unique_nonzero_owner_415  1
    service_0_33_7  service_visit_def_790  1
    service_0_33_7  free_load_conservation_791  6
    service_0_33_8  unique_nonzero_owner_416  1
    service_0_33_8  service_visit_def_790  1
    service_0_33_8  free_load_conservation_791  7
    service_0_33_9  unique_nonzero_owner_417  1
    service_0_33_9  service_visit_def_790  1
    service_0_33_9  free_load_conservation_791  8
    service_0_33_10  unique_nonzero_owner_418  1
    service_0_33_10  service_visit_def_790  1
    service_0_33_10  free_load_conservation_791  9
    service_0_33_11  unique_nonzero_owner_419  1
    service_0_33_11  service_visit_def_790  1
    service_0_33_11  free_load_conservation_791  10
    service_0_33_12  unique_nonzero_owner_420  1
    service_0_33_12  service_visit_def_790  1
    service_0_33_12  free_load_conservation_791  11
    service_0_33_13  unique_nonzero_owner_421  1
    service_0_33_13  service_visit_def_790  1
    service_0_33_13  free_load_conservation_791  12
    service_0_33_14  unique_nonzero_owner_422  1
    service_0_33_14  service_visit_def_790  1
    service_0_33_14  free_load_conservation_791  13
    service_0_33_15  unique_nonzero_owner_423  1
    service_0_33_15  service_visit_def_790  1
    service_0_33_15  free_load_conservation_791  14
    service_0_33_16  unique_nonzero_owner_424  1
    service_0_33_16  service_visit_def_790  1
    service_0_33_16  free_load_conservation_791  15
    service_1_33_0  unique_nonzero_owner_409  1
    service_1_33_0  service_visit_def_1279  1
    service_1_33_0  free_load_conservation_1280  -1
    service_1_33_0  original_T_including_depot_unload_1286  120
    service_1_33_2  unique_nonzero_owner_410  1
    service_1_33_2  service_visit_def_1279  1
    service_1_33_2  free_load_conservation_1280  1
    service_1_33_3  unique_nonzero_owner_411  1
    service_1_33_3  service_visit_def_1279  1
    service_1_33_3  free_load_conservation_1280  2
    service_1_33_4  unique_nonzero_owner_412  1
    service_1_33_4  service_visit_def_1279  1
    service_1_33_4  free_load_conservation_1280  3
    service_1_33_5  unique_nonzero_owner_413  1
    service_1_33_5  service_visit_def_1279  1
    service_1_33_5  free_load_conservation_1280  4
    service_1_33_6  unique_nonzero_owner_414  1
    service_1_33_6  service_visit_def_1279  1
    service_1_33_6  free_load_conservation_1280  5
    service_1_33_7  unique_nonzero_owner_415  1
    service_1_33_7  service_visit_def_1279  1
    service_1_33_7  free_load_conservation_1280  6
    service_1_33_8  unique_nonzero_owner_416  1
    service_1_33_8  service_visit_def_1279  1
    service_1_33_8  free_load_conservation_1280  7
    service_1_33_9  unique_nonzero_owner_417  1
    service_1_33_9  service_visit_def_1279  1
    service_1_33_9  free_load_conservation_1280  8
    service_1_33_10  unique_nonzero_owner_418  1
    service_1_33_10  service_visit_def_1279  1
    service_1_33_10  free_load_conservation_1280  9
    service_1_33_11  unique_nonzero_owner_419  1
    service_1_33_11  service_visit_def_1279  1
    service_1_33_11  free_load_conservation_1280  10
    service_1_33_12  unique_nonzero_owner_420  1
    service_1_33_12  service_visit_def_1279  1
    service_1_33_12  free_load_conservation_1280  11
    service_1_33_13  unique_nonzero_owner_421  1
    service_1_33_13  service_visit_def_1279  1
    service_1_33_13  free_load_conservation_1280  12
    service_1_33_14  unique_nonzero_owner_422  1
    service_1_33_14  service_visit_def_1279  1
    service_1_33_14  free_load_conservation_1280  13
    service_1_33_15  unique_nonzero_owner_423  1
    service_1_33_15  service_visit_def_1279  1
    service_1_33_15  free_load_conservation_1280  14
    service_1_33_16  unique_nonzero_owner_424  1
    service_1_33_16  service_visit_def_1279  1
    service_1_33_16  free_load_conservation_1280  15
    service_2_33_0  unique_nonzero_owner_409  1
    service_2_33_0  service_visit_def_1652  1
    service_2_33_0  free_load_conservation_1653  -1
    service_2_33_0  original_T_including_depot_unload_1657  120
    service_2_33_2  unique_nonzero_owner_410  1
    service_2_33_2  service_visit_def_1652  1
    service_2_33_2  free_load_conservation_1653  1
    service_2_33_3  unique_nonzero_owner_411  1
    service_2_33_3  service_visit_def_1652  1
    service_2_33_3  free_load_conservation_1653  2
    service_2_33_4  unique_nonzero_owner_412  1
    service_2_33_4  service_visit_def_1652  1
    service_2_33_4  free_load_conservation_1653  3
    service_2_33_5  unique_nonzero_owner_413  1
    service_2_33_5  service_visit_def_1652  1
    service_2_33_5  free_load_conservation_1653  4
    service_2_33_6  unique_nonzero_owner_414  1
    service_2_33_6  service_visit_def_1652  1
    service_2_33_6  free_load_conservation_1653  5
    service_2_33_7  unique_nonzero_owner_415  1
    service_2_33_7  service_visit_def_1652  1
    service_2_33_7  free_load_conservation_1653  6
    service_2_33_8  unique_nonzero_owner_416  1
    service_2_33_8  service_visit_def_1652  1
    service_2_33_8  free_load_conservation_1653  7
    service_2_33_9  unique_nonzero_owner_417  1
    service_2_33_9  service_visit_def_1652  1
    service_2_33_9  free_load_conservation_1653  8
    service_2_33_10  unique_nonzero_owner_418  1
    service_2_33_10  service_visit_def_1652  1
    service_2_33_10  free_load_conservation_1653  9
    service_2_33_11  unique_nonzero_owner_419  1
    service_2_33_11  service_visit_def_1652  1
    service_2_33_11  free_load_conservation_1653  10
    service_2_33_12  unique_nonzero_owner_420  1
    service_2_33_12  service_visit_def_1652  1
    service_2_33_12  free_load_conservation_1653  11
    service_2_33_13  unique_nonzero_owner_421  1
    service_2_33_13  service_visit_def_1652  1
    service_2_33_13  free_load_conservation_1653  12
    service_2_33_14  unique_nonzero_owner_422  1
    service_2_33_14  service_visit_def_1652  1
    service_2_33_14  free_load_conservation_1653  13
    service_2_33_15  unique_nonzero_owner_423  1
    service_2_33_15  service_visit_def_1652  1
    service_2_33_15  free_load_conservation_1653  14
    service_2_33_16  unique_nonzero_owner_424  1
    service_2_33_16  service_visit_def_1652  1
    service_2_33_16  free_load_conservation_1653  15
    MARKER    'MARKER'                 'INTEND'
    visit_0_1  out_degree_716  -1
    visit_0_1  in_degree_717  -1
    visit_0_1  order_active_lb_718  -1
    visit_0_1  order_active_ub_719  -12
    order_0_1  connected_order_arc_440  -1
    order_0_1  connected_order_arc_442  -1
    order_0_1  connected_order_arc_444  -1
    order_0_1  connected_order_arc_446  -1
    order_0_1  connected_order_arc_448  -1
    order_0_1  connected_order_arc_450  -1
    order_0_1  connected_order_arc_452  -1
    order_0_1  connected_order_arc_454  -1
    order_0_1  connected_order_arc_456  -1
    order_0_1  connected_order_arc_458  -1
    order_0_1  connected_order_arc_460  -1
    order_0_1  connected_order_arc_463  1
    order_0_1  connected_order_arc_486  1
    order_0_1  connected_order_arc_509  1
    order_0_1  connected_order_arc_532  1
    order_0_1  connected_order_arc_555  1
    order_0_1  connected_order_arc_578  1
    order_0_1  connected_order_arc_601  1
    order_0_1  connected_order_arc_624  1
    order_0_1  connected_order_arc_647  1
    order_0_1  connected_order_arc_670  1
    order_0_1  connected_order_arc_693  1
    order_0_1  order_active_lb_718  1
    order_0_1  order_active_ub_719  1
    order_0_1  fixed_segment_relative_order_792  -1
    visit_0_2  out_degree_723  -1
    visit_0_2  in_degree_724  -1
    visit_0_2  order_active_lb_725  -1
    visit_0_2  order_active_ub_726  -12
    order_0_2  connected_order_arc_440  1
    order_0_2  connected_order_arc_463  -1
    order_0_2  connected_order_arc_465  -1
    order_0_2  connected_order_arc_467  -1
    order_0_2  connected_order_arc_469  -1
    order_0_2  connected_order_arc_471  -1
    order_0_2  connected_order_arc_473  -1
    order_0_2  connected_order_arc_475  -1
    order_0_2  connected_order_arc_477  -1
    order_0_2  connected_order_arc_479  -1
    order_0_2  connected_order_arc_481  -1
    order_0_2  connected_order_arc_483  -1
    order_0_2  connected_order_arc_488  1
    order_0_2  connected_order_arc_511  1
    order_0_2  connected_order_arc_534  1
    order_0_2  connected_order_arc_557  1
    order_0_2  connected_order_arc_580  1
    order_0_2  connected_order_arc_603  1
    order_0_2  connected_order_arc_626  1
    order_0_2  connected_order_arc_649  1
    order_0_2  connected_order_arc_672  1
    order_0_2  connected_order_arc_695  1
    order_0_2  order_active_lb_725  1
    order_0_2  order_active_ub_726  1
    order_0_2  fixed_segment_relative_order_792  1
    order_0_2  fixed_segment_relative_order_793  -1
    visit_0_3  out_degree_730  -1
    visit_0_3  in_degree_731  -1
    visit_0_3  order_active_lb_732  -1
    visit_0_3  order_active_ub_733  -12
    order_0_3  connected_order_arc_442  1
    order_0_3  connected_order_arc_465  1
    order_0_3  connected_order_arc_486  -1
    order_0_3  connected_order_arc_488  -1
    order_0_3  connected_order_arc_490  -1
    order_0_3  connected_order_arc_492  -1
    order_0_3  connected_order_arc_494  -1
    order_0_3  connected_order_arc_496  -1
    order_0_3  connected_order_arc_498  -1
    order_0_3  connected_order_arc_500  -1
    order_0_3  connected_order_arc_502  -1
    order_0_3  connected_order_arc_504  -1
    order_0_3  connected_order_arc_506  -1
    order_0_3  connected_order_arc_513  1
    order_0_3  connected_order_arc_536  1
    order_0_3  connected_order_arc_559  1
    order_0_3  connected_order_arc_582  1
    order_0_3  connected_order_arc_605  1
    order_0_3  connected_order_arc_628  1
    order_0_3  connected_order_arc_651  1
    order_0_3  connected_order_arc_674  1
    order_0_3  connected_order_arc_697  1
    order_0_3  order_active_lb_732  1
    order_0_3  order_active_ub_733  1
    order_0_3  fixed_segment_relative_order_793  1
    order_0_3  fixed_segment_relative_order_794  -1
    visit_0_4  out_degree_737  -1
    visit_0_4  in_degree_738  -1
    visit_0_4  order_active_lb_739  -1
    visit_0_4  order_active_ub_740  -12
    order_0_4  connected_order_arc_444  1
    order_0_4  connected_order_arc_467  1
    order_0_4  connected_order_arc_490  1
    order_0_4  connected_order_arc_509  -1
    order_0_4  connected_order_arc_511  -1
    order_0_4  connected_order_arc_513  -1
    order_0_4  connected_order_arc_515  -1
    order_0_4  connected_order_arc_517  -1
    order_0_4  connected_order_arc_519  -1
    order_0_4  connected_order_arc_521  -1
    order_0_4  connected_order_arc_523  -1
    order_0_4  connected_order_arc_525  -1
    order_0_4  connected_order_arc_527  -1
    order_0_4  connected_order_arc_529  -1
    order_0_4  connected_order_arc_538  1
    order_0_4  connected_order_arc_561  1
    order_0_4  connected_order_arc_584  1
    order_0_4  connected_order_arc_607  1
    order_0_4  connected_order_arc_630  1
    order_0_4  connected_order_arc_653  1
    order_0_4  connected_order_arc_676  1
    order_0_4  connected_order_arc_699  1
    order_0_4  order_active_lb_739  1
    order_0_4  order_active_ub_740  1
    order_0_4  fixed_segment_relative_order_794  1
    visit_0_15  out_degree_744  -1
    visit_0_15  in_degree_745  -1
    visit_0_15  order_active_lb_746  -1
    visit_0_15  order_active_ub_747  -12
    visit_0_15  service_visit_def_748  -1
    order_0_15  connected_order_arc_446  1
    order_0_15  connected_order_arc_469  1
    order_0_15  connected_order_arc_492  1
    order_0_15  connected_order_arc_515  1
    order_0_15  connected_order_arc_532  -1
    order_0_15  connected_order_arc_534  -1
    order_0_15  connected_order_arc_536  -1
    order_0_15  connected_order_arc_538  -1
    order_0_15  connected_order_arc_540  -1
    order_0_15  connected_order_arc_542  -1
    order_0_15  connected_order_arc_544  -1
    order_0_15  connected_order_arc_546  -1
    order_0_15  connected_order_arc_548  -1
    order_0_15  connected_order_arc_550  -1
    order_0_15  connected_order_arc_552  -1
    order_0_15  connected_order_arc_563  1
    order_0_15  connected_order_arc_586  1
    order_0_15  connected_order_arc_609  1
    order_0_15  connected_order_arc_632  1
    order_0_15  connected_order_arc_655  1
    order_0_15  connected_order_arc_678  1
    order_0_15  connected_order_arc_701  1
    order_0_15  order_active_lb_746  1
    order_0_15  order_active_ub_747  1
    visit_0_16  out_degree_750  -1
    visit_0_16  in_degree_751  -1
    visit_0_16  order_active_lb_752  -1
    visit_0_16  order_active_ub_753  -12
    visit_0_16  service_visit_def_754  -1
    order_0_16  connected_order_arc_448  1
    order_0_16  connected_order_arc_471  1
    order_0_16  connected_order_arc_494  1
    order_0_16  connected_order_arc_517  1
    order_0_16  connected_order_arc_540  1
    order_0_16  connected_order_arc_555  -1
    order_0_16  connected_order_arc_557  -1
    order_0_16  connected_order_arc_559  -1
    order_0_16  connected_order_arc_561  -1
    order_0_16  connected_order_arc_563  -1
    order_0_16  connected_order_arc_565  -1
    order_0_16  connected_order_arc_567  -1
    order_0_16  connected_order_arc_569  -1
    order_0_16  connected_order_arc_571  -1
    order_0_16  connected_order_arc_573  -1
    order_0_16  connected_order_arc_575  -1
    order_0_16  connected_order_arc_588  1
    order_0_16  connected_order_arc_611  1
    order_0_16  connected_order_arc_634  1
    order_0_16  connected_order_arc_657  1
    order_0_16  connected_order_arc_680  1
    order_0_16  connected_order_arc_703  1
    order_0_16  order_active_lb_752  1
    order_0_16  order_active_ub_753  1
    visit_0_17  out_degree_756  -1
    visit_0_17  in_degree_757  -1
    visit_0_17  order_active_lb_758  -1
    visit_0_17  order_active_ub_759  -12
    visit_0_17  service_visit_def_760  -1
    order_0_17  connected_order_arc_450  1
    order_0_17  connected_order_arc_473  1
    order_0_17  connected_order_arc_496  1
    order_0_17  connected_order_arc_519  1
    order_0_17  connected_order_arc_542  1
    order_0_17  connected_order_arc_565  1
    order_0_17  connected_order_arc_578  -1
    order_0_17  connected_order_arc_580  -1
    order_0_17  connected_order_arc_582  -1
    order_0_17  connected_order_arc_584  -1
    order_0_17  connected_order_arc_586  -1
    order_0_17  connected_order_arc_588  -1
    order_0_17  connected_order_arc_590  -1
    order_0_17  connected_order_arc_592  -1
    order_0_17  connected_order_arc_594  -1
    order_0_17  connected_order_arc_596  -1
    order_0_17  connected_order_arc_598  -1
    order_0_17  connected_order_arc_613  1
    order_0_17  connected_order_arc_636  1
    order_0_17  connected_order_arc_659  1
    order_0_17  connected_order_arc_682  1
    order_0_17  connected_order_arc_705  1
    order_0_17  order_active_lb_758  1
    order_0_17  order_active_ub_759  1
    visit_0_18  out_degree_762  -1
    visit_0_18  in_degree_763  -1
    visit_0_18  order_active_lb_764  -1
    visit_0_18  order_active_ub_765  -12
    visit_0_18  service_visit_def_766  -1
    order_0_18  connected_order_arc_452  1
    order_0_18  connected_order_arc_475  1
    order_0_18  connected_order_arc_498  1
    order_0_18  connected_order_arc_521  1
    order_0_18  connected_order_arc_544  1
    order_0_18  connected_order_arc_567  1
    order_0_18  connected_order_arc_590  1
    order_0_18  connected_order_arc_601  -1
    order_0_18  connected_order_arc_603  -1
    order_0_18  connected_order_arc_605  -1
    order_0_18  connected_order_arc_607  -1
    order_0_18  connected_order_arc_609  -1
    order_0_18  connected_order_arc_611  -1
    order_0_18  connected_order_arc_613  -1
    order_0_18  connected_order_arc_615  -1
    order_0_18  connected_order_arc_617  -1
    order_0_18  connected_order_arc_619  -1
    order_0_18  connected_order_arc_621  -1
    order_0_18  connected_order_arc_638  1
    order_0_18  connected_order_arc_661  1
    order_0_18  connected_order_arc_684  1
    order_0_18  connected_order_arc_707  1
    order_0_18  order_active_lb_764  1
    order_0_18  order_active_ub_765  1
    visit_0_19  out_degree_768  -1
    visit_0_19  in_degree_769  -1
    visit_0_19  order_active_lb_770  -1
    visit_0_19  order_active_ub_771  -12
    visit_0_19  service_visit_def_772  -1
    order_0_19  connected_order_arc_454  1
    order_0_19  connected_order_arc_477  1
    order_0_19  connected_order_arc_500  1
    order_0_19  connected_order_arc_523  1
    order_0_19  connected_order_arc_546  1
    order_0_19  connected_order_arc_569  1
    order_0_19  connected_order_arc_592  1
    order_0_19  connected_order_arc_615  1
    order_0_19  connected_order_arc_624  -1
    order_0_19  connected_order_arc_626  -1
    order_0_19  connected_order_arc_628  -1
    order_0_19  connected_order_arc_630  -1
    order_0_19  connected_order_arc_632  -1
    order_0_19  connected_order_arc_634  -1
    order_0_19  connected_order_arc_636  -1
    order_0_19  connected_order_arc_638  -1
    order_0_19  connected_order_arc_640  -1
    order_0_19  connected_order_arc_642  -1
    order_0_19  connected_order_arc_644  -1
    order_0_19  connected_order_arc_663  1
    order_0_19  connected_order_arc_686  1
    order_0_19  connected_order_arc_709  1
    order_0_19  order_active_lb_770  1
    order_0_19  order_active_ub_771  1
    visit_0_20  out_degree_774  -1
    visit_0_20  in_degree_775  -1
    visit_0_20  order_active_lb_776  -1
    visit_0_20  order_active_ub_777  -12
    visit_0_20  service_visit_def_778  -1
    order_0_20  connected_order_arc_456  1
    order_0_20  connected_order_arc_479  1
    order_0_20  connected_order_arc_502  1
    order_0_20  connected_order_arc_525  1
    order_0_20  connected_order_arc_548  1
    order_0_20  connected_order_arc_571  1
    order_0_20  connected_order_arc_594  1
    order_0_20  connected_order_arc_617  1
    order_0_20  connected_order_arc_640  1
    order_0_20  connected_order_arc_647  -1
    order_0_20  connected_order_arc_649  -1
    order_0_20  connected_order_arc_651  -1
    order_0_20  connected_order_arc_653  -1
    order_0_20  connected_order_arc_655  -1
    order_0_20  connected_order_arc_657  -1
    order_0_20  connected_order_arc_659  -1
    order_0_20  connected_order_arc_661  -1
    order_0_20  connected_order_arc_663  -1
    order_0_20  connected_order_arc_665  -1
    order_0_20  connected_order_arc_667  -1
    order_0_20  connected_order_arc_688  1
    order_0_20  connected_order_arc_711  1
    order_0_20  order_active_lb_776  1
    order_0_20  order_active_ub_777  1
    visit_0_21  out_degree_780  -1
    visit_0_21  in_degree_781  -1
    visit_0_21  order_active_lb_782  -1
    visit_0_21  order_active_ub_783  -12
    visit_0_21  service_visit_def_784  -1
    order_0_21  connected_order_arc_458  1
    order_0_21  connected_order_arc_481  1
    order_0_21  connected_order_arc_504  1
    order_0_21  connected_order_arc_527  1
    order_0_21  connected_order_arc_550  1
    order_0_21  connected_order_arc_573  1
    order_0_21  connected_order_arc_596  1
    order_0_21  connected_order_arc_619  1
    order_0_21  connected_order_arc_642  1
    order_0_21  connected_order_arc_665  1
    order_0_21  connected_order_arc_670  -1
    order_0_21  connected_order_arc_672  -1
    order_0_21  connected_order_arc_674  -1
    order_0_21  connected_order_arc_676  -1
    order_0_21  connected_order_arc_678  -1
    order_0_21  connected_order_arc_680  -1
    order_0_21  connected_order_arc_682  -1
    order_0_21  connected_order_arc_684  -1
    order_0_21  connected_order_arc_686  -1
    order_0_21  connected_order_arc_688  -1
    order_0_21  connected_order_arc_690  -1
    order_0_21  connected_order_arc_713  1
    order_0_21  order_active_lb_782  1
    order_0_21  order_active_ub_783  1
    visit_0_22  out_degree_786  -1
    visit_0_22  in_degree_787  -1
    visit_0_22  order_active_lb_788  -1
    visit_0_22  order_active_ub_789  -12
    visit_0_22  service_visit_def_790  -1
    order_0_22  connected_order_arc_460  1
    order_0_22  connected_order_arc_483  1
    order_0_22  connected_order_arc_506  1
    order_0_22  connected_order_arc_529  1
    order_0_22  connected_order_arc_552  1
    order_0_22  connected_order_arc_575  1
    order_0_22  connected_order_arc_598  1
    order_0_22  connected_order_arc_621  1
    order_0_22  connected_order_arc_644  1
    order_0_22  connected_order_arc_667  1
    order_0_22  connected_order_arc_690  1
    order_0_22  connected_order_arc_693  -1
    order_0_22  connected_order_arc_695  -1
    order_0_22  connected_order_arc_697  -1
    order_0_22  connected_order_arc_699  -1
    order_0_22  connected_order_arc_701  -1
    order_0_22  connected_order_arc_703  -1
    order_0_22  connected_order_arc_705  -1
    order_0_22  connected_order_arc_707  -1
    order_0_22  connected_order_arc_709  -1
    order_0_22  connected_order_arc_711  -1
    order_0_22  connected_order_arc_713  -1
    order_0_22  order_active_lb_788  1
    order_0_22  order_active_ub_789  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_0  arc_capacity_425  -20
    arc_0_0_0  depot_departure_or_bypass_714  1
    arc_0_0_0  depot_return_or_bypass_715  1
    MARKER    'MARKER'                 'INTEND'
    load_0_0_0  arc_capacity_425  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_1  arc_capacity_426  -20
    arc_0_0_1  depot_departure_or_bypass_714  1
    arc_0_0_1  in_degree_717  1
    arc_0_0_1  original_T_including_depot_unload_795  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_1  arc_capacity_426  1
    load_0_0_1  segment_load_conservation_720  -1
    load_0_0_1  segment_prefix_lb_721  1
    load_0_0_1  segment_prefix_ub_722  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_2  arc_capacity_427  -20
    arc_0_0_2  depot_departure_or_bypass_714  1
    arc_0_0_2  in_degree_724  1
    arc_0_0_2  original_T_including_depot_unload_795  7.2130540230577469e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_2  arc_capacity_427  1
    load_0_0_2  segment_load_conservation_727  -1
    load_0_0_2  segment_prefix_lb_728  1
    load_0_0_2  segment_prefix_ub_729  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_3  arc_capacity_428  -20
    arc_0_0_3  depot_departure_or_bypass_714  1
    arc_0_0_3  in_degree_731  1
    arc_0_0_3  original_T_including_depot_unload_795  4.9403722507151832e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_3  arc_capacity_428  1
    load_0_0_3  segment_load_conservation_734  -1
    load_0_0_3  segment_prefix_lb_735  1
    load_0_0_3  segment_prefix_ub_736  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_4  arc_capacity_429  -20
    arc_0_0_4  depot_departure_or_bypass_714  1
    arc_0_0_4  in_degree_738  1
    arc_0_0_4  original_T_including_depot_unload_795  5.4249700630778887e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_4  arc_capacity_429  1
    load_0_0_4  segment_load_conservation_741  -1
    load_0_0_4  segment_prefix_lb_742  1
    load_0_0_4  segment_prefix_ub_743  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_15  arc_capacity_430  -20
    arc_0_0_15  depot_departure_or_bypass_714  1
    arc_0_0_15  in_degree_745  1
    arc_0_0_15  original_T_including_depot_unload_795  1.0088905112952611e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_15  arc_capacity_430  1
    load_0_0_15  free_load_conservation_749  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_16  arc_capacity_431  -20
    arc_0_0_16  depot_departure_or_bypass_714  1
    arc_0_0_16  in_degree_751  1
    arc_0_0_16  original_T_including_depot_unload_795  8.7749189782983967e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_16  arc_capacity_431  1
    load_0_0_16  free_load_conservation_755  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_17  arc_capacity_432  -20
    arc_0_0_17  depot_departure_or_bypass_714  1
    arc_0_0_17  in_degree_757  1
    arc_0_0_17  original_T_including_depot_unload_795  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_17  arc_capacity_432  1
    load_0_0_17  free_load_conservation_761  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_18  arc_capacity_433  -20
    arc_0_0_18  depot_departure_or_bypass_714  1
    arc_0_0_18  in_degree_763  1
    arc_0_0_18  original_T_including_depot_unload_795  1.2751323166566442e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_18  arc_capacity_433  1
    load_0_0_18  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_19  arc_capacity_434  -20
    arc_0_0_19  depot_departure_or_bypass_714  1
    arc_0_0_19  in_degree_769  1
    arc_0_0_19  original_T_including_depot_unload_795  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_19  arc_capacity_434  1
    load_0_0_19  free_load_conservation_773  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_20  arc_capacity_435  -20
    arc_0_0_20  depot_departure_or_bypass_714  1
    arc_0_0_20  in_degree_775  1
    arc_0_0_20  original_T_including_depot_unload_795  1.0479182987243917e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_20  arc_capacity_435  1
    load_0_0_20  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_21  arc_capacity_436  -20
    arc_0_0_21  depot_departure_or_bypass_714  1
    arc_0_0_21  in_degree_781  1
    arc_0_0_21  original_T_including_depot_unload_795  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_21  arc_capacity_436  1
    load_0_0_21  free_load_conservation_785  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_22  arc_capacity_437  -20
    arc_0_0_22  depot_departure_or_bypass_714  1
    arc_0_0_22  in_degree_787  1
    arc_0_0_22  original_T_including_depot_unload_795  1.3076700111397606e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_22  arc_capacity_437  1
    load_0_0_22  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_0  arc_capacity_438  -20
    arc_0_1_0  depot_return_or_bypass_715  1
    arc_0_1_0  out_degree_716  1
    arc_0_1_0  original_T_including_depot_unload_795  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_0  arc_capacity_438  1
    load_0_1_0  segment_load_conservation_720  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_2  arc_capacity_439  -20
    arc_0_1_2  connected_order_arc_440  -13
    arc_0_1_2  out_degree_716  1
    arc_0_1_2  in_degree_724  1
    arc_0_1_2  original_T_including_depot_unload_795  4.4733407106545638e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_2  arc_capacity_439  1
    load_0_1_2  segment_load_conservation_720  1
    load_0_1_2  segment_load_conservation_727  -1
    load_0_1_2  segment_prefix_lb_728  1
    load_0_1_2  segment_prefix_ub_729  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_3  arc_capacity_441  -20
    arc_0_1_3  connected_order_arc_442  -13
    arc_0_1_3  out_degree_716  1
    arc_0_1_3  in_degree_731  1
    arc_0_1_3  original_T_including_depot_unload_795  2.2271784981792140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_3  arc_capacity_441  1
    load_0_1_3  segment_load_conservation_720  1
    load_0_1_3  segment_load_conservation_734  -1
    load_0_1_3  segment_prefix_lb_735  1
    load_0_1_3  segment_prefix_ub_736  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_4  arc_capacity_443  -20
    arc_0_1_4  connected_order_arc_444  -13
    arc_0_1_4  out_degree_716  1
    arc_0_1_4  in_degree_738  1
    arc_0_1_4  original_T_including_depot_unload_795  2.8529311190414518e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_4  arc_capacity_443  1
    load_0_1_4  segment_load_conservation_720  1
    load_0_1_4  segment_load_conservation_741  -1
    load_0_1_4  segment_prefix_lb_742  1
    load_0_1_4  segment_prefix_ub_743  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_15  arc_capacity_445  -20
    arc_0_1_15  connected_order_arc_446  -13
    arc_0_1_15  out_degree_716  1
    arc_0_1_15  in_degree_745  1
    arc_0_1_15  original_T_including_depot_unload_795  1.1190931627527086e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_15  arc_capacity_445  1
    load_0_1_15  segment_load_conservation_720  1
    load_0_1_15  free_load_conservation_749  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_16  arc_capacity_447  -20
    arc_0_1_16  connected_order_arc_448  -13
    arc_0_1_16  out_degree_716  1
    arc_0_1_16  in_degree_751  1
    arc_0_1_16  original_T_including_depot_unload_795  1.0170488276971105e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_16  arc_capacity_447  1
    load_0_1_16  segment_load_conservation_720  1
    load_0_1_16  free_load_conservation_755  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_17  arc_capacity_449  -20
    arc_0_1_17  connected_order_arc_450  -13
    arc_0_1_17  out_degree_716  1
    arc_0_1_17  in_degree_757  1
    arc_0_1_17  original_T_including_depot_unload_795  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_17  arc_capacity_449  1
    load_0_1_17  segment_load_conservation_720  1
    load_0_1_17  free_load_conservation_761  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_18  arc_capacity_451  -20
    arc_0_1_18  connected_order_arc_452  -13
    arc_0_1_18  out_degree_716  1
    arc_0_1_18  in_degree_763  1
    arc_0_1_18  original_T_including_depot_unload_795  1337.70453645659
    MARKER    'MARKER'                 'INTEND'
    load_0_1_18  arc_capacity_451  1
    load_0_1_18  segment_load_conservation_720  1
    load_0_1_18  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_19  arc_capacity_453  -20
    arc_0_1_19  connected_order_arc_454  -13
    arc_0_1_19  out_degree_716  1
    arc_0_1_19  in_degree_769  1
    arc_0_1_19  original_T_including_depot_unload_795  4.5128490093732506e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_19  arc_capacity_453  1
    load_0_1_19  segment_load_conservation_720  1
    load_0_1_19  free_load_conservation_773  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_20  arc_capacity_455  -20
    arc_0_1_20  connected_order_arc_456  -13
    arc_0_1_20  out_degree_716  1
    arc_0_1_20  in_degree_775  1
    arc_0_1_20  original_T_including_depot_unload_795  1.2336637947519732e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_20  arc_capacity_455  1
    load_0_1_20  segment_load_conservation_720  1
    load_0_1_20  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_21  arc_capacity_457  -20
    arc_0_1_21  connected_order_arc_458  -13
    arc_0_1_21  out_degree_716  1
    arc_0_1_21  in_degree_781  1
    arc_0_1_21  original_T_including_depot_unload_795  1.5902582434549993e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_21  arc_capacity_457  1
    load_0_1_21  segment_load_conservation_720  1
    load_0_1_21  free_load_conservation_785  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_22  arc_capacity_459  -20
    arc_0_1_22  connected_order_arc_460  -13
    arc_0_1_22  out_degree_716  1
    arc_0_1_22  in_degree_787  1
    arc_0_1_22  original_T_including_depot_unload_795  1.3286968036345565e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_22  arc_capacity_459  1
    load_0_1_22  segment_load_conservation_720  1
    load_0_1_22  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_0  arc_capacity_461  -20
    arc_0_2_0  depot_return_or_bypass_715  1
    arc_0_2_0  out_degree_723  1
    arc_0_2_0  original_T_including_depot_unload_795  7.2130540230577469e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_0  arc_capacity_461  1
    load_0_2_0  segment_load_conservation_727  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_1  arc_capacity_462  -20
    arc_0_2_1  connected_order_arc_463  -13
    arc_0_2_1  in_degree_717  1
    arc_0_2_1  out_degree_723  1
    arc_0_2_1  original_T_including_depot_unload_795  4.4733407106545638e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_1  arc_capacity_462  1
    load_0_2_1  segment_load_conservation_720  -1
    load_0_2_1  segment_prefix_lb_721  1
    load_0_2_1  segment_prefix_ub_722  1
    load_0_2_1  segment_load_conservation_727  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_3  arc_capacity_464  -20
    arc_0_2_3  connected_order_arc_465  -13
    arc_0_2_3  out_degree_723  1
    arc_0_2_3  in_degree_731  1
    arc_0_2_3  original_T_including_depot_unload_795  2.2729932910497158e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_3  arc_capacity_464  1
    load_0_2_3  segment_load_conservation_727  1
    load_0_2_3  segment_load_conservation_734  -1
    load_0_2_3  segment_prefix_lb_735  1
    load_0_2_3  segment_prefix_ub_736  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_4  arc_capacity_466  -20
    arc_0_2_4  connected_order_arc_467  -13
    arc_0_2_4  out_degree_723  1
    arc_0_2_4  in_degree_738  1
    arc_0_2_4  original_T_including_depot_unload_795  3.2367117212973966e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_4  arc_capacity_466  1
    load_0_2_4  segment_load_conservation_727  1
    load_0_2_4  segment_load_conservation_741  -1
    load_0_2_4  segment_prefix_lb_742  1
    load_0_2_4  segment_prefix_ub_743  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_15  arc_capacity_468  -20
    arc_0_2_15  connected_order_arc_469  -13
    arc_0_2_15  out_degree_723  1
    arc_0_2_15  in_degree_745  1
    arc_0_2_15  original_T_including_depot_unload_795  1.3140724694688972e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_15  arc_capacity_468  1
    load_0_2_15  segment_load_conservation_727  1
    load_0_2_15  free_load_conservation_749  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_16  arc_capacity_470  -20
    arc_0_2_16  connected_order_arc_471  -13
    arc_0_2_16  out_degree_723  1
    arc_0_2_16  in_degree_751  1
    arc_0_2_16  original_T_including_depot_unload_795  1.2608023164150941e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_16  arc_capacity_470  1
    load_0_2_16  segment_load_conservation_727  1
    load_0_2_16  free_load_conservation_755  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_17  arc_capacity_472  -20
    arc_0_2_17  connected_order_arc_473  -13
    arc_0_2_17  out_degree_723  1
    arc_0_2_17  in_degree_757  1
    arc_0_2_17  original_T_including_depot_unload_795  1.7303231472353602e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_17  arc_capacity_472  1
    load_0_2_17  segment_load_conservation_727  1
    load_0_2_17  free_load_conservation_761  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_18  arc_capacity_474  -20
    arc_0_2_18  connected_order_arc_475  -13
    arc_0_2_18  out_degree_723  1
    arc_0_2_18  in_degree_763  1
    arc_0_2_18  original_T_including_depot_unload_795  1.4452727648139044e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_18  arc_capacity_474  1
    load_0_2_18  segment_load_conservation_727  1
    load_0_2_18  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_19  arc_capacity_476  -20
    arc_0_2_19  connected_order_arc_477  -13
    arc_0_2_19  out_degree_723  1
    arc_0_2_19  in_degree_769  1
    arc_0_2_19  original_T_including_depot_unload_795  4.6128219015626763e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_19  arc_capacity_476  1
    load_0_2_19  segment_load_conservation_727  1
    load_0_2_19  free_load_conservation_773  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_20  arc_capacity_478  -20
    arc_0_2_20  connected_order_arc_479  -13
    arc_0_2_20  out_degree_723  1
    arc_0_2_20  in_degree_775  1
    arc_0_2_20  original_T_including_depot_unload_795  1.5223381412470410e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_20  arc_capacity_478  1
    load_0_2_20  segment_load_conservation_727  1
    load_0_2_20  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_21  arc_capacity_480  -20
    arc_0_2_21  connected_order_arc_481  -13
    arc_0_2_21  out_degree_723  1
    arc_0_2_21  in_degree_781  1
    arc_0_2_21  original_T_including_depot_unload_795  2.0162129512771592e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_21  arc_capacity_480  1
    load_0_2_21  segment_load_conservation_727  1
    load_0_2_21  free_load_conservation_785  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_22  arc_capacity_482  -20
    arc_0_2_22  connected_order_arc_483  -13
    arc_0_2_22  out_degree_723  1
    arc_0_2_22  in_degree_787  1
    arc_0_2_22  original_T_including_depot_unload_795  1.3740068502263614e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_22  arc_capacity_482  1
    load_0_2_22  segment_load_conservation_727  1
    load_0_2_22  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_0  arc_capacity_484  -20
    arc_0_3_0  depot_return_or_bypass_715  1
    arc_0_3_0  out_degree_730  1
    arc_0_3_0  original_T_including_depot_unload_795  4.9403722507151832e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_0  arc_capacity_484  1
    load_0_3_0  segment_load_conservation_734  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_1  arc_capacity_485  -20
    arc_0_3_1  connected_order_arc_486  -13
    arc_0_3_1  in_degree_717  1
    arc_0_3_1  out_degree_730  1
    arc_0_3_1  original_T_including_depot_unload_795  2.2271784981792140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_1  arc_capacity_485  1
    load_0_3_1  segment_load_conservation_720  -1
    load_0_3_1  segment_prefix_lb_721  1
    load_0_3_1  segment_prefix_ub_722  1
    load_0_3_1  segment_load_conservation_734  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_2  arc_capacity_487  -20
    arc_0_3_2  connected_order_arc_488  -13
    arc_0_3_2  in_degree_724  1
    arc_0_3_2  out_degree_730  1
    arc_0_3_2  original_T_including_depot_unload_795  2.2729932910497158e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_2  arc_capacity_487  1
    load_0_3_2  segment_load_conservation_727  -1
    load_0_3_2  segment_prefix_lb_728  1
    load_0_3_2  segment_prefix_ub_729  1
    load_0_3_2  segment_load_conservation_734  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_4  arc_capacity_489  -20
    arc_0_3_4  connected_order_arc_490  -13
    arc_0_3_4  out_degree_730  1
    arc_0_3_4  in_degree_738  1
    arc_0_3_4  original_T_including_depot_unload_795  2.3159636865750136e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_4  arc_capacity_489  1
    load_0_3_4  segment_load_conservation_734  1
    load_0_3_4  segment_load_conservation_741  -1
    load_0_3_4  segment_prefix_lb_742  1
    load_0_3_4  segment_prefix_ub_743  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_15  arc_capacity_491  -20
    arc_0_3_15  connected_order_arc_492  -13
    arc_0_3_15  out_degree_730  1
    arc_0_3_15  in_degree_745  1
    arc_0_3_15  original_T_including_depot_unload_795  1.1768203711166027e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_15  arc_capacity_491  1
    load_0_3_15  segment_load_conservation_734  1
    load_0_3_15  free_load_conservation_749  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_16  arc_capacity_493  -20
    arc_0_3_16  connected_order_arc_494  -13
    arc_0_3_16  out_degree_730  1
    arc_0_3_16  in_degree_751  1
    arc_0_3_16  original_T_including_depot_unload_795  1.1017171222416982e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_16  arc_capacity_493  1
    load_0_3_16  segment_load_conservation_734  1
    load_0_3_16  free_load_conservation_755  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_17  arc_capacity_495  -20
    arc_0_3_17  connected_order_arc_496  -13
    arc_0_3_17  out_degree_730  1
    arc_0_3_17  in_degree_757  1
    arc_0_3_17  original_T_including_depot_unload_795  1.5184659007075070e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_17  arc_capacity_495  1
    load_0_3_17  segment_load_conservation_734  1
    load_0_3_17  free_load_conservation_761  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_18  arc_capacity_497  -20
    arc_0_3_18  connected_order_arc_498  -13
    arc_0_3_18  out_degree_730  1
    arc_0_3_18  in_degree_763  1
    arc_0_3_18  original_T_including_depot_unload_795  1.3500971086898692e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_18  arc_capacity_497  1
    load_0_3_18  segment_load_conservation_734  1
    load_0_3_18  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_19  arc_capacity_499  -20
    arc_0_3_19  connected_order_arc_500  -13
    arc_0_3_19  out_degree_730  1
    arc_0_3_19  in_degree_769  1
    arc_0_3_19  original_T_including_depot_unload_795  3.7315439746742123e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_19  arc_capacity_499  1
    load_0_3_19  segment_load_conservation_734  1
    load_0_3_19  free_load_conservation_773  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_20  arc_capacity_501  -20
    arc_0_3_20  connected_order_arc_502  -13
    arc_0_3_20  out_degree_730  1
    arc_0_3_20  in_degree_775  1
    arc_0_3_20  original_T_including_depot_unload_795  1.3473071485321755e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_20  arc_capacity_501  1
    load_0_3_20  segment_load_conservation_734  1
    load_0_3_20  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_21  arc_capacity_503  -20
    arc_0_3_21  connected_order_arc_504  -13
    arc_0_3_21  out_degree_730  1
    arc_0_3_21  in_degree_781  1
    arc_0_3_21  original_T_including_depot_unload_795  1.8073464544423741e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_21  arc_capacity_503  1
    load_0_3_21  segment_load_conservation_734  1
    load_0_3_21  free_load_conservation_785  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_22  arc_capacity_505  -20
    arc_0_3_22  connected_order_arc_506  -13
    arc_0_3_22  out_degree_730  1
    arc_0_3_22  in_degree_787  1
    arc_0_3_22  original_T_including_depot_unload_795  1.3082661182285894e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_22  arc_capacity_505  1
    load_0_3_22  segment_load_conservation_734  1
    load_0_3_22  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_0  arc_capacity_507  -20
    arc_0_4_0  depot_return_or_bypass_715  1
    arc_0_4_0  out_degree_737  1
    arc_0_4_0  original_T_including_depot_unload_795  4.6364706268001146e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_0  arc_capacity_507  1
    load_0_4_0  segment_load_conservation_741  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_1  arc_capacity_508  -20
    arc_0_4_1  connected_order_arc_509  -13
    arc_0_4_1  in_degree_717  1
    arc_0_4_1  out_degree_737  1
    arc_0_4_1  original_T_including_depot_unload_795  6.7517249538835438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_1  arc_capacity_508  1
    load_0_4_1  segment_load_conservation_720  -1
    load_0_4_1  segment_prefix_lb_721  1
    load_0_4_1  segment_prefix_ub_722  1
    load_0_4_1  segment_load_conservation_741  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_2  arc_capacity_510  -20
    arc_0_4_2  connected_order_arc_511  -13
    arc_0_4_2  in_degree_724  1
    arc_0_4_2  out_degree_737  1
    arc_0_4_2  original_T_including_depot_unload_795  1.1090437276384578e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_2  arc_capacity_510  1
    load_0_4_2  segment_load_conservation_727  -1
    load_0_4_2  segment_prefix_lb_728  1
    load_0_4_2  segment_prefix_ub_729  1
    load_0_4_2  segment_load_conservation_741  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_3  arc_capacity_512  -20
    arc_0_4_3  connected_order_arc_513  -13
    arc_0_4_3  in_degree_731  1
    arc_0_4_3  out_degree_737  1
    arc_0_4_3  original_T_including_depot_unload_795  8.9433085313747858e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_3  arc_capacity_512  1
    load_0_4_3  segment_load_conservation_734  -1
    load_0_4_3  segment_prefix_lb_735  1
    load_0_4_3  segment_prefix_ub_736  1
    load_0_4_3  segment_load_conservation_741  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_15  arc_capacity_514  -20
    arc_0_4_15  connected_order_arc_515  -13
    arc_0_4_15  out_degree_737  1
    arc_0_4_15  in_degree_745  1
    arc_0_4_15  original_T_including_depot_unload_795  1.3294477435531232e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_15  arc_capacity_514  1
    load_0_4_15  segment_load_conservation_741  1
    load_0_4_15  free_load_conservation_749  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_16  arc_capacity_516  -20
    arc_0_4_16  connected_order_arc_517  -13
    arc_0_4_16  out_degree_737  1
    arc_0_4_16  in_degree_751  1
    arc_0_4_16  original_T_including_depot_unload_795  1.1724800521319269e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_16  arc_capacity_516  1
    load_0_4_16  segment_load_conservation_741  1
    load_0_4_16  free_load_conservation_755  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_17  arc_capacity_518  -20
    arc_0_4_17  connected_order_arc_519  -13
    arc_0_4_17  out_degree_737  1
    arc_0_4_17  in_degree_757  1
    arc_0_4_17  original_T_including_depot_unload_795  1075.72043838369
    MARKER    'MARKER'                 'INTEND'
    load_0_4_17  arc_capacity_518  1
    load_0_4_17  segment_load_conservation_741  1
    load_0_4_17  free_load_conservation_761  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_18  arc_capacity_520  -20
    arc_0_4_18  connected_order_arc_521  -13
    arc_0_4_18  out_degree_737  1
    arc_0_4_18  in_degree_763  1
    arc_0_4_18  original_T_including_depot_unload_795  1.6320542581729912e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_18  arc_capacity_520  1
    load_0_4_18  segment_load_conservation_741  1
    load_0_4_18  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_19  arc_capacity_522  -20
    arc_0_4_19  connected_order_arc_523  -13
    arc_0_4_19  out_degree_737  1
    arc_0_4_19  in_degree_769  1
    arc_0_4_19  original_T_including_depot_unload_795  1.0491196843462671e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_19  arc_capacity_522  1
    load_0_4_19  segment_load_conservation_741  1
    load_0_4_19  free_load_conservation_773  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_20  arc_capacity_524  -20
    arc_0_4_20  connected_order_arc_525  -13
    arc_0_4_20  out_degree_737  1
    arc_0_4_20  in_degree_775  1
    arc_0_4_20  original_T_including_depot_unload_795  1.2492199513695298e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_20  arc_capacity_524  1
    load_0_4_20  segment_load_conservation_741  1
    load_0_4_20  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_21  arc_capacity_526  -20
    arc_0_4_21  connected_order_arc_527  -13
    arc_0_4_21  out_degree_737  1
    arc_0_4_21  in_degree_781  1
    arc_0_4_21  original_T_including_depot_unload_795  9.1576870176747968e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_21  arc_capacity_526  1
    load_0_4_21  segment_load_conservation_741  1
    load_0_4_21  free_load_conservation_785  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_22  arc_capacity_528  -20
    arc_0_4_22  connected_order_arc_529  -13
    arc_0_4_22  out_degree_737  1
    arc_0_4_22  in_degree_787  1
    arc_0_4_22  original_T_including_depot_unload_795  1.7000764266516874e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_22  arc_capacity_528  1
    load_0_4_22  segment_load_conservation_741  1
    load_0_4_22  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_0  arc_capacity_530  -20
    arc_0_15_0  depot_return_or_bypass_715  1
    arc_0_15_0  out_degree_744  1
    arc_0_15_0  original_T_including_depot_unload_795  1.0088905112952611e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_0  arc_capacity_530  1
    load_0_15_0  free_load_conservation_749  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_1  arc_capacity_531  -20
    arc_0_15_1  connected_order_arc_532  -13
    arc_0_15_1  in_degree_717  1
    arc_0_15_1  out_degree_744  1
    arc_0_15_1  original_T_including_depot_unload_795  1.1190931627527086e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_1  arc_capacity_531  1
    load_0_15_1  segment_load_conservation_720  -1
    load_0_15_1  segment_prefix_lb_721  1
    load_0_15_1  segment_prefix_ub_722  1
    load_0_15_1  free_load_conservation_749  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_2  arc_capacity_533  -20
    arc_0_15_2  connected_order_arc_534  -13
    arc_0_15_2  in_degree_724  1
    arc_0_15_2  out_degree_744  1
    arc_0_15_2  original_T_including_depot_unload_795  1.3140724694688972e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_2  arc_capacity_533  1
    load_0_15_2  segment_load_conservation_727  -1
    load_0_15_2  segment_prefix_lb_728  1
    load_0_15_2  segment_prefix_ub_729  1
    load_0_15_2  free_load_conservation_749  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_3  arc_capacity_535  -20
    arc_0_15_3  connected_order_arc_536  -13
    arc_0_15_3  in_degree_731  1
    arc_0_15_3  out_degree_744  1
    arc_0_15_3  original_T_including_depot_unload_795  1.1768203711166027e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_3  arc_capacity_535  1
    load_0_15_3  segment_load_conservation_734  -1
    load_0_15_3  segment_prefix_lb_735  1
    load_0_15_3  segment_prefix_ub_736  1
    load_0_15_3  free_load_conservation_749  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_4  arc_capacity_537  -20
    arc_0_15_4  connected_order_arc_538  -13
    arc_0_15_4  in_degree_738  1
    arc_0_15_4  out_degree_744  1
    arc_0_15_4  original_T_including_depot_unload_795  1.3776676659817167e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_4  arc_capacity_537  1
    load_0_15_4  segment_load_conservation_741  -1
    load_0_15_4  segment_prefix_lb_742  1
    load_0_15_4  segment_prefix_ub_743  1
    load_0_15_4  free_load_conservation_749  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_16  arc_capacity_539  -20
    arc_0_15_16  connected_order_arc_540  -13
    arc_0_15_16  out_degree_744  1
    arc_0_15_16  in_degree_751  1
    arc_0_15_16  original_T_including_depot_unload_795  1.6651295535886251e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_16  arc_capacity_539  1
    load_0_15_16  free_load_conservation_749  1
    load_0_15_16  free_load_conservation_755  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_17  arc_capacity_541  -20
    arc_0_15_17  connected_order_arc_542  -13
    arc_0_15_17  out_degree_744  1
    arc_0_15_17  in_degree_757  1
    arc_0_15_17  original_T_including_depot_unload_795  861.314419336229
    MARKER    'MARKER'                 'INTEND'
    load_0_15_17  arc_capacity_541  1
    load_0_15_17  free_load_conservation_749  1
    load_0_15_17  free_load_conservation_761  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_18  arc_capacity_543  -20
    arc_0_15_18  connected_order_arc_544  -13
    arc_0_15_18  out_degree_744  1
    arc_0_15_18  in_degree_763  1
    arc_0_15_18  original_T_including_depot_unload_795  3.2286832955801827e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_18  arc_capacity_543  1
    load_0_15_18  free_load_conservation_749  1
    load_0_15_18  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_19  arc_capacity_545  -20
    arc_0_15_19  connected_order_arc_546  -13
    arc_0_15_19  out_degree_744  1
    arc_0_15_19  in_degree_769  1
    arc_0_15_19  original_T_including_depot_unload_795  8.5502565124349769e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_19  arc_capacity_545  1
    load_0_15_19  free_load_conservation_749  1
    load_0_15_19  free_load_conservation_773  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_20  arc_capacity_547  -20
    arc_0_15_20  connected_order_arc_548  -13
    arc_0_15_20  out_degree_744  1
    arc_0_15_20  in_degree_775  1
    arc_0_15_20  original_T_including_depot_unload_795  3.6094216796124527e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_20  arc_capacity_547  1
    load_0_15_20  free_load_conservation_749  1
    load_0_15_20  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_21  arc_capacity_549  -20
    arc_0_15_21  connected_order_arc_550  -13
    arc_0_15_21  out_degree_744  1
    arc_0_15_21  in_degree_781  1
    arc_0_15_21  original_T_including_depot_unload_795  2.0104743468619281e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_21  arc_capacity_549  1
    load_0_15_21  free_load_conservation_749  1
    load_0_15_21  free_load_conservation_785  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_22  arc_capacity_551  -20
    arc_0_15_22  connected_order_arc_552  -13
    arc_0_15_22  out_degree_744  1
    arc_0_15_22  in_degree_787  1
    arc_0_15_22  original_T_including_depot_unload_795  4.6588884124393707e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_22  arc_capacity_551  1
    load_0_15_22  free_load_conservation_749  1
    load_0_15_22  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_0  arc_capacity_553  -20
    arc_0_16_0  depot_return_or_bypass_715  1
    arc_0_16_0  out_degree_750  1
    arc_0_16_0  original_T_including_depot_unload_795  8.7749189782983967e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_0  arc_capacity_553  1
    load_0_16_0  free_load_conservation_755  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_1  arc_capacity_554  -20
    arc_0_16_1  connected_order_arc_555  -13
    arc_0_16_1  in_degree_717  1
    arc_0_16_1  out_degree_750  1
    arc_0_16_1  original_T_including_depot_unload_795  1.0170488276971105e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_1  arc_capacity_554  1
    load_0_16_1  segment_load_conservation_720  -1
    load_0_16_1  segment_prefix_lb_721  1
    load_0_16_1  segment_prefix_ub_722  1
    load_0_16_1  free_load_conservation_755  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_2  arc_capacity_556  -20
    arc_0_16_2  connected_order_arc_557  -13
    arc_0_16_2  in_degree_724  1
    arc_0_16_2  out_degree_750  1
    arc_0_16_2  original_T_including_depot_unload_795  1.2608023164150941e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_2  arc_capacity_556  1
    load_0_16_2  segment_load_conservation_727  -1
    load_0_16_2  segment_prefix_lb_728  1
    load_0_16_2  segment_prefix_ub_729  1
    load_0_16_2  free_load_conservation_755  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_3  arc_capacity_558  -20
    arc_0_16_3  connected_order_arc_559  -13
    arc_0_16_3  in_degree_731  1
    arc_0_16_3  out_degree_750  1
    arc_0_16_3  original_T_including_depot_unload_795  1.1017171222416982e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_3  arc_capacity_558  1
    load_0_16_3  segment_load_conservation_734  -1
    load_0_16_3  segment_prefix_lb_735  1
    load_0_16_3  segment_prefix_ub_736  1
    load_0_16_3  free_load_conservation_755  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_4  arc_capacity_560  -20
    arc_0_16_4  connected_order_arc_561  -13
    arc_0_16_4  in_degree_738  1
    arc_0_16_4  out_degree_750  1
    arc_0_16_4  original_T_including_depot_unload_795  1.2876689365561549e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_4  arc_capacity_560  1
    load_0_16_4  segment_load_conservation_741  -1
    load_0_16_4  segment_prefix_lb_742  1
    load_0_16_4  segment_prefix_ub_743  1
    load_0_16_4  free_load_conservation_755  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_15  arc_capacity_562  -20
    arc_0_16_15  connected_order_arc_563  -13
    arc_0_16_15  in_degree_745  1
    arc_0_16_15  out_degree_750  1
    arc_0_16_15  original_T_including_depot_unload_795  1.6651295535886251e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_15  arc_capacity_562  1
    load_0_16_15  free_load_conservation_749  -1
    load_0_16_15  free_load_conservation_755  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_17  arc_capacity_564  -20
    arc_0_16_17  connected_order_arc_565  -13
    arc_0_16_17  out_degree_750  1
    arc_0_16_17  in_degree_757  1
    arc_0_16_17  original_T_including_depot_unload_795  7.3227602527872671e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_17  arc_capacity_564  1
    load_0_16_17  free_load_conservation_755  1
    load_0_16_17  free_load_conservation_761  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_18  arc_capacity_566  -20
    arc_0_16_18  connected_order_arc_567  -13
    arc_0_16_18  out_degree_750  1
    arc_0_16_18  in_degree_763  1
    arc_0_16_18  original_T_including_depot_unload_795  4.8905010520753694e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_18  arc_capacity_566  1
    load_0_16_18  free_load_conservation_755  1
    load_0_16_18  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_19  arc_capacity_568  -20
    arc_0_16_19  connected_order_arc_569  -13
    arc_0_16_19  out_degree_750  1
    arc_0_16_19  in_degree_769  1
    arc_0_16_19  original_T_including_depot_unload_795  8.1417957710766450e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_19  arc_capacity_568  1
    load_0_16_19  free_load_conservation_755  1
    load_0_16_19  free_load_conservation_773  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_20  arc_capacity_570  -20
    arc_0_16_20  connected_order_arc_571  -13
    arc_0_16_20  out_degree_750  1
    arc_0_16_20  in_degree_775  1
    arc_0_16_20  original_T_including_depot_unload_795  2.8747557636937808e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_20  arc_capacity_570  1
    load_0_16_20  free_load_conservation_755  1
    load_0_16_20  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_21  arc_capacity_572  -20
    arc_0_16_21  connected_order_arc_573  -13
    arc_0_16_21  out_degree_750  1
    arc_0_16_21  in_degree_781  1
    arc_0_16_21  original_T_including_depot_unload_795  1.8442669473423912e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_21  arc_capacity_572  1
    load_0_16_21  free_load_conservation_755  1
    load_0_16_21  free_load_conservation_785  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_22  arc_capacity_574  -20
    arc_0_16_22  connected_order_arc_575  -13
    arc_0_16_22  out_degree_750  1
    arc_0_16_22  in_degree_787  1
    arc_0_16_22  original_T_including_depot_unload_795  6.2102815646279714e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_22  arc_capacity_574  1
    load_0_16_22  free_load_conservation_755  1
    load_0_16_22  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_0  arc_capacity_576  -20
    arc_0_17_0  depot_return_or_bypass_715  1
    arc_0_17_0  out_degree_756  1
    arc_0_17_0  original_T_including_depot_unload_795  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_0  arc_capacity_576  1
    load_0_17_0  free_load_conservation_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_1  arc_capacity_577  -20
    arc_0_17_1  connected_order_arc_578  -13
    arc_0_17_1  in_degree_717  1
    arc_0_17_1  out_degree_756  1
    arc_0_17_1  original_T_including_depot_unload_795  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_1  arc_capacity_577  1
    load_0_17_1  segment_load_conservation_720  -1
    load_0_17_1  segment_prefix_lb_721  1
    load_0_17_1  segment_prefix_ub_722  1
    load_0_17_1  free_load_conservation_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_2  arc_capacity_579  -20
    arc_0_17_2  connected_order_arc_580  -13
    arc_0_17_2  in_degree_724  1
    arc_0_17_2  out_degree_756  1
    arc_0_17_2  original_T_including_depot_unload_795  1.7303231472353602e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_2  arc_capacity_579  1
    load_0_17_2  segment_load_conservation_727  -1
    load_0_17_2  segment_prefix_lb_728  1
    load_0_17_2  segment_prefix_ub_729  1
    load_0_17_2  free_load_conservation_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_3  arc_capacity_581  -20
    arc_0_17_3  connected_order_arc_582  -13
    arc_0_17_3  in_degree_731  1
    arc_0_17_3  out_degree_756  1
    arc_0_17_3  original_T_including_depot_unload_795  1.5184659007075070e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_3  arc_capacity_581  1
    load_0_17_3  segment_load_conservation_734  -1
    load_0_17_3  segment_prefix_lb_735  1
    load_0_17_3  segment_prefix_ub_736  1
    load_0_17_3  free_load_conservation_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_4  arc_capacity_583  -20
    arc_0_17_4  connected_order_arc_584  -13
    arc_0_17_4  in_degree_738  1
    arc_0_17_4  out_degree_756  1
    arc_0_17_4  original_T_including_depot_unload_795  1.6231508478292610e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_4  arc_capacity_583  1
    load_0_17_4  segment_load_conservation_741  -1
    load_0_17_4  segment_prefix_lb_742  1
    load_0_17_4  segment_prefix_ub_743  1
    load_0_17_4  free_load_conservation_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_15  arc_capacity_585  -20
    arc_0_17_15  connected_order_arc_586  -13
    arc_0_17_15  in_degree_745  1
    arc_0_17_15  out_degree_756  1
    arc_0_17_15  original_T_including_depot_unload_795  861.314419336229
    MARKER    'MARKER'                 'INTEND'
    load_0_17_15  arc_capacity_585  1
    load_0_17_15  free_load_conservation_749  -1
    load_0_17_15  free_load_conservation_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_16  arc_capacity_587  -20
    arc_0_17_16  connected_order_arc_588  -13
    arc_0_17_16  in_degree_751  1
    arc_0_17_16  out_degree_756  1
    arc_0_17_16  original_T_including_depot_unload_795  7.3227602527872671e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_16  arc_capacity_587  1
    load_0_17_16  free_load_conservation_755  -1
    load_0_17_16  free_load_conservation_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_18  arc_capacity_589  -20
    arc_0_17_18  connected_order_arc_590  -13
    arc_0_17_18  out_degree_756  1
    arc_0_17_18  in_degree_763  1
    arc_0_17_18  original_T_including_depot_unload_795  1.1499210972200315e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_18  arc_capacity_589  1
    load_0_17_18  free_load_conservation_761  1
    load_0_17_18  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_19  arc_capacity_591  -20
    arc_0_17_19  connected_order_arc_592  -13
    arc_0_17_19  out_degree_756  1
    arc_0_17_19  in_degree_769  1
    arc_0_17_19  original_T_including_depot_unload_795  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_19  arc_capacity_591  1
    load_0_17_19  free_load_conservation_761  1
    load_0_17_19  free_load_conservation_773  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_20  arc_capacity_593  -20
    arc_0_17_20  connected_order_arc_594  -13
    arc_0_17_20  out_degree_756  1
    arc_0_17_20  in_degree_775  1
    arc_0_17_20  original_T_including_depot_unload_795  5.2280951376932137e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_20  arc_capacity_593  1
    load_0_17_20  free_load_conservation_761  1
    load_0_17_20  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_21  arc_capacity_595  -20
    arc_0_17_21  connected_order_arc_596  -13
    arc_0_17_21  out_degree_756  1
    arc_0_17_21  in_degree_781  1
    arc_0_17_21  original_T_including_depot_unload_795  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_21  arc_capacity_595  1
    load_0_17_21  free_load_conservation_761  1
    load_0_17_21  free_load_conservation_785  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_22  arc_capacity_597  -20
    arc_0_17_22  connected_order_arc_598  -13
    arc_0_17_22  out_degree_756  1
    arc_0_17_22  in_degree_787  1
    arc_0_17_22  original_T_including_depot_unload_795  1.3218357148919101e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_22  arc_capacity_597  1
    load_0_17_22  free_load_conservation_761  1
    load_0_17_22  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_0  arc_capacity_599  -20
    arc_0_18_0  depot_return_or_bypass_715  1
    arc_0_18_0  out_degree_762  1
    arc_0_18_0  original_T_including_depot_unload_795  1.2751323166566442e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_0  arc_capacity_599  1
    load_0_18_0  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_1  arc_capacity_600  -20
    arc_0_18_1  connected_order_arc_601  -13
    arc_0_18_1  in_degree_717  1
    arc_0_18_1  out_degree_762  1
    arc_0_18_1  original_T_including_depot_unload_795  1337.70453645659
    MARKER    'MARKER'                 'INTEND'
    load_0_18_1  arc_capacity_600  1
    load_0_18_1  segment_load_conservation_720  -1
    load_0_18_1  segment_prefix_lb_721  1
    load_0_18_1  segment_prefix_ub_722  1
    load_0_18_1  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_2  arc_capacity_602  -20
    arc_0_18_2  connected_order_arc_603  -13
    arc_0_18_2  in_degree_724  1
    arc_0_18_2  out_degree_762  1
    arc_0_18_2  original_T_including_depot_unload_795  1.4452727648139044e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_2  arc_capacity_602  1
    load_0_18_2  segment_load_conservation_727  -1
    load_0_18_2  segment_prefix_lb_728  1
    load_0_18_2  segment_prefix_ub_729  1
    load_0_18_2  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_3  arc_capacity_604  -20
    arc_0_18_3  connected_order_arc_605  -13
    arc_0_18_3  in_degree_731  1
    arc_0_18_3  out_degree_762  1
    arc_0_18_3  original_T_including_depot_unload_795  1.3500971086898692e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_3  arc_capacity_604  1
    load_0_18_3  segment_load_conservation_734  -1
    load_0_18_3  segment_prefix_lb_735  1
    load_0_18_3  segment_prefix_ub_736  1
    load_0_18_3  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_4  arc_capacity_606  -20
    arc_0_18_4  connected_order_arc_607  -13
    arc_0_18_4  in_degree_738  1
    arc_0_18_4  out_degree_762  1
    arc_0_18_4  original_T_including_depot_unload_795  1.5695454967512389e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_4  arc_capacity_606  1
    load_0_18_4  segment_load_conservation_741  -1
    load_0_18_4  segment_prefix_lb_742  1
    load_0_18_4  segment_prefix_ub_743  1
    load_0_18_4  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_15  arc_capacity_608  -20
    arc_0_18_15  connected_order_arc_609  -13
    arc_0_18_15  in_degree_745  1
    arc_0_18_15  out_degree_762  1
    arc_0_18_15  original_T_including_depot_unload_795  3.2286832955801827e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_15  arc_capacity_608  1
    load_0_18_15  free_load_conservation_749  -1
    load_0_18_15  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_16  arc_capacity_610  -20
    arc_0_18_16  connected_order_arc_611  -13
    arc_0_18_16  in_degree_751  1
    arc_0_18_16  out_degree_762  1
    arc_0_18_16  original_T_including_depot_unload_795  4.8905010520753694e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_16  arc_capacity_610  1
    load_0_18_16  free_load_conservation_755  -1
    load_0_18_16  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_17  arc_capacity_612  -20
    arc_0_18_17  connected_order_arc_613  -13
    arc_0_18_17  in_degree_757  1
    arc_0_18_17  out_degree_762  1
    arc_0_18_17  original_T_including_depot_unload_795  1.1499210972200315e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_17  arc_capacity_612  1
    load_0_18_17  free_load_conservation_761  -1
    load_0_18_17  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_19  arc_capacity_614  -20
    arc_0_18_19  connected_order_arc_615  -13
    arc_0_18_19  out_degree_762  1
    arc_0_18_19  in_degree_769  1
    arc_0_18_19  original_T_including_depot_unload_795  990.144803963742
    MARKER    'MARKER'                 'INTEND'
    load_0_18_19  arc_capacity_614  1
    load_0_18_19  free_load_conservation_767  1
    load_0_18_19  free_load_conservation_773  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_20  arc_capacity_616  -20
    arc_0_18_20  connected_order_arc_617  -13
    arc_0_18_20  out_degree_762  1
    arc_0_18_20  in_degree_775  1
    arc_0_18_20  original_T_including_depot_unload_795  6.2793211180612207e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_20  arc_capacity_616  1
    load_0_18_20  free_load_conservation_767  1
    load_0_18_20  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_21  arc_capacity_618  -20
    arc_0_18_21  connected_order_arc_619  -13
    arc_0_18_21  out_degree_762  1
    arc_0_18_21  in_degree_781  1
    arc_0_18_21  original_T_including_depot_unload_795  2.3332890980657526e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_21  arc_capacity_618  1
    load_0_18_21  free_load_conservation_767  1
    load_0_18_21  free_load_conservation_785  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_22  arc_capacity_620  -20
    arc_0_18_22  connected_order_arc_621  -13
    arc_0_18_22  out_degree_762  1
    arc_0_18_22  in_degree_787  1
    arc_0_18_22  original_T_including_depot_unload_795  1.9785969874636677e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_22  arc_capacity_620  1
    load_0_18_22  free_load_conservation_767  1
    load_0_18_22  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_0  arc_capacity_622  -20
    arc_0_19_0  depot_return_or_bypass_715  1
    arc_0_19_0  out_degree_768  1
    arc_0_19_0  original_T_including_depot_unload_795  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_0  arc_capacity_622  1
    load_0_19_0  free_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_1  arc_capacity_623  -20
    arc_0_19_1  connected_order_arc_624  -13
    arc_0_19_1  in_degree_717  1
    arc_0_19_1  out_degree_768  1
    arc_0_19_1  original_T_including_depot_unload_795  4.5128490093732506e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_1  arc_capacity_623  1
    load_0_19_1  segment_load_conservation_720  -1
    load_0_19_1  segment_prefix_lb_721  1
    load_0_19_1  segment_prefix_ub_722  1
    load_0_19_1  free_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_2  arc_capacity_625  -20
    arc_0_19_2  connected_order_arc_626  -13
    arc_0_19_2  in_degree_724  1
    arc_0_19_2  out_degree_768  1
    arc_0_19_2  original_T_including_depot_unload_795  4.6128219015626763e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_2  arc_capacity_625  1
    load_0_19_2  segment_load_conservation_727  -1
    load_0_19_2  segment_prefix_lb_728  1
    load_0_19_2  segment_prefix_ub_729  1
    load_0_19_2  free_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_3  arc_capacity_627  -20
    arc_0_19_3  connected_order_arc_628  -13
    arc_0_19_3  in_degree_731  1
    arc_0_19_3  out_degree_768  1
    arc_0_19_3  original_T_including_depot_unload_795  3.7315439746742123e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_3  arc_capacity_627  1
    load_0_19_3  segment_load_conservation_734  -1
    load_0_19_3  segment_prefix_lb_735  1
    load_0_19_3  segment_prefix_ub_736  1
    load_0_19_3  free_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_4  arc_capacity_629  -20
    arc_0_19_4  connected_order_arc_630  -13
    arc_0_19_4  in_degree_738  1
    arc_0_19_4  out_degree_768  1
    arc_0_19_4  original_T_including_depot_unload_795  603.649383070884
    MARKER    'MARKER'                 'INTEND'
    load_0_19_4  arc_capacity_629  1
    load_0_19_4  segment_load_conservation_741  -1
    load_0_19_4  segment_prefix_lb_742  1
    load_0_19_4  segment_prefix_ub_743  1
    load_0_19_4  free_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_15  arc_capacity_631  -20
    arc_0_19_15  connected_order_arc_632  -13
    arc_0_19_15  in_degree_745  1
    arc_0_19_15  out_degree_768  1
    arc_0_19_15  original_T_including_depot_unload_795  8.5502565124349769e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_15  arc_capacity_631  1
    load_0_19_15  free_load_conservation_749  -1
    load_0_19_15  free_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_16  arc_capacity_633  -20
    arc_0_19_16  connected_order_arc_634  -13
    arc_0_19_16  in_degree_751  1
    arc_0_19_16  out_degree_768  1
    arc_0_19_16  original_T_including_depot_unload_795  8.1417957710766450e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_16  arc_capacity_633  1
    load_0_19_16  free_load_conservation_755  -1
    load_0_19_16  free_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_17  arc_capacity_635  -20
    arc_0_19_17  connected_order_arc_636  -13
    arc_0_19_17  in_degree_757  1
    arc_0_19_17  out_degree_768  1
    arc_0_19_17  original_T_including_depot_unload_795  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_17  arc_capacity_635  1
    load_0_19_17  free_load_conservation_761  -1
    load_0_19_17  free_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_18  arc_capacity_637  -20
    arc_0_19_18  connected_order_arc_638  -13
    arc_0_19_18  in_degree_763  1
    arc_0_19_18  out_degree_768  1
    arc_0_19_18  original_T_including_depot_unload_795  990.144803963742
    MARKER    'MARKER'                 'INTEND'
    load_0_19_18  arc_capacity_637  1
    load_0_19_18  free_load_conservation_767  -1
    load_0_19_18  free_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_20  arc_capacity_639  -20
    arc_0_19_20  connected_order_arc_640  -13
    arc_0_19_20  out_degree_768  1
    arc_0_19_20  in_degree_775  1
    arc_0_19_20  original_T_including_depot_unload_795  1.0880068546845516e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_20  arc_capacity_639  1
    load_0_19_20  free_load_conservation_773  1
    load_0_19_20  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_21  arc_capacity_641  -20
    arc_0_19_21  connected_order_arc_642  -13
    arc_0_19_21  out_degree_768  1
    arc_0_19_21  in_degree_781  1
    arc_0_19_21  original_T_including_depot_unload_795  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_21  arc_capacity_641  1
    load_0_19_21  free_load_conservation_773  1
    load_0_19_21  free_load_conservation_785  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_22  arc_capacity_643  -20
    arc_0_19_22  connected_order_arc_644  -13
    arc_0_19_22  out_degree_768  1
    arc_0_19_22  in_degree_787  1
    arc_0_19_22  original_T_including_depot_unload_795  9.3685967675232439e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_22  arc_capacity_643  1
    load_0_19_22  free_load_conservation_773  1
    load_0_19_22  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_0  arc_capacity_645  -20
    arc_0_20_0  depot_return_or_bypass_715  1
    arc_0_20_0  out_degree_774  1
    arc_0_20_0  original_T_including_depot_unload_795  1.0479182987243917e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_0  arc_capacity_645  1
    load_0_20_0  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_1  arc_capacity_646  -20
    arc_0_20_1  connected_order_arc_647  -13
    arc_0_20_1  in_degree_717  1
    arc_0_20_1  out_degree_774  1
    arc_0_20_1  original_T_including_depot_unload_795  1.2336637947519732e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_1  arc_capacity_646  1
    load_0_20_1  segment_load_conservation_720  -1
    load_0_20_1  segment_prefix_lb_721  1
    load_0_20_1  segment_prefix_ub_722  1
    load_0_20_1  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_2  arc_capacity_648  -20
    arc_0_20_2  connected_order_arc_649  -13
    arc_0_20_2  in_degree_724  1
    arc_0_20_2  out_degree_774  1
    arc_0_20_2  original_T_including_depot_unload_795  1.5223381412470410e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_2  arc_capacity_648  1
    load_0_20_2  segment_load_conservation_727  -1
    load_0_20_2  segment_prefix_lb_728  1
    load_0_20_2  segment_prefix_ub_729  1
    load_0_20_2  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_3  arc_capacity_650  -20
    arc_0_20_3  connected_order_arc_651  -13
    arc_0_20_3  in_degree_731  1
    arc_0_20_3  out_degree_774  1
    arc_0_20_3  original_T_including_depot_unload_795  1.3473071485321755e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_3  arc_capacity_650  1
    load_0_20_3  segment_load_conservation_734  -1
    load_0_20_3  segment_prefix_lb_735  1
    load_0_20_3  segment_prefix_ub_736  1
    load_0_20_3  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_4  arc_capacity_652  -20
    arc_0_20_4  connected_order_arc_653  -13
    arc_0_20_4  in_degree_738  1
    arc_0_20_4  out_degree_774  1
    arc_0_20_4  original_T_including_depot_unload_795  1.5145600125783847e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_4  arc_capacity_652  1
    load_0_20_4  segment_load_conservation_741  -1
    load_0_20_4  segment_prefix_lb_742  1
    load_0_20_4  segment_prefix_ub_743  1
    load_0_20_4  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_15  arc_capacity_654  -20
    arc_0_20_15  connected_order_arc_655  -13
    arc_0_20_15  in_degree_745  1
    arc_0_20_15  out_degree_774  1
    arc_0_20_15  original_T_including_depot_unload_795  3.6094216796124527e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_15  arc_capacity_654  1
    load_0_20_15  free_load_conservation_749  -1
    load_0_20_15  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_16  arc_capacity_656  -20
    arc_0_20_16  connected_order_arc_657  -13
    arc_0_20_16  in_degree_751  1
    arc_0_20_16  out_degree_774  1
    arc_0_20_16  original_T_including_depot_unload_795  2.8747557636937808e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_16  arc_capacity_656  1
    load_0_20_16  free_load_conservation_755  -1
    load_0_20_16  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_17  arc_capacity_658  -20
    arc_0_20_17  connected_order_arc_659  -13
    arc_0_20_17  in_degree_757  1
    arc_0_20_17  out_degree_774  1
    arc_0_20_17  original_T_including_depot_unload_795  5.2280951376932137e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_17  arc_capacity_658  1
    load_0_20_17  free_load_conservation_761  -1
    load_0_20_17  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_18  arc_capacity_660  -20
    arc_0_20_18  connected_order_arc_661  -13
    arc_0_20_18  in_degree_763  1
    arc_0_20_18  out_degree_774  1
    arc_0_20_18  original_T_including_depot_unload_795  6.2793211180612207e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_18  arc_capacity_660  1
    load_0_20_18  free_load_conservation_767  -1
    load_0_20_18  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_19  arc_capacity_662  -20
    arc_0_20_19  connected_order_arc_663  -13
    arc_0_20_19  in_degree_769  1
    arc_0_20_19  out_degree_774  1
    arc_0_20_19  original_T_including_depot_unload_795  1.0880068546845516e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_19  arc_capacity_662  1
    load_0_20_19  free_load_conservation_773  -1
    load_0_20_19  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_21  arc_capacity_664  -20
    arc_0_20_21  connected_order_arc_665  -13
    arc_0_20_21  out_degree_774  1
    arc_0_20_21  in_degree_781  1
    arc_0_20_21  original_T_including_depot_unload_795  1.7883808204567979e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_21  arc_capacity_664  1
    load_0_20_21  free_load_conservation_779  1
    load_0_20_21  free_load_conservation_785  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_22  arc_capacity_666  -20
    arc_0_20_22  connected_order_arc_667  -13
    arc_0_20_22  out_degree_774  1
    arc_0_20_22  in_degree_787  1
    arc_0_20_22  original_T_including_depot_unload_795  8.0531033344008677e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_22  arc_capacity_666  1
    load_0_20_22  free_load_conservation_779  1
    load_0_20_22  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_0  arc_capacity_668  -20
    arc_0_21_0  depot_return_or_bypass_715  1
    arc_0_21_0  out_degree_780  1
    arc_0_21_0  original_T_including_depot_unload_795  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_0  arc_capacity_668  1
    load_0_21_0  free_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_1  arc_capacity_669  -20
    arc_0_21_1  connected_order_arc_670  -13
    arc_0_21_1  in_degree_717  1
    arc_0_21_1  out_degree_780  1
    arc_0_21_1  original_T_including_depot_unload_795  1.5902582434549993e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_1  arc_capacity_669  1
    load_0_21_1  segment_load_conservation_720  -1
    load_0_21_1  segment_prefix_lb_721  1
    load_0_21_1  segment_prefix_ub_722  1
    load_0_21_1  free_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_2  arc_capacity_671  -20
    arc_0_21_2  connected_order_arc_672  -13
    arc_0_21_2  in_degree_724  1
    arc_0_21_2  out_degree_780  1
    arc_0_21_2  original_T_including_depot_unload_795  2.0162129512771592e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_2  arc_capacity_671  1
    load_0_21_2  segment_load_conservation_727  -1
    load_0_21_2  segment_prefix_lb_728  1
    load_0_21_2  segment_prefix_ub_729  1
    load_0_21_2  free_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_3  arc_capacity_673  -20
    arc_0_21_3  connected_order_arc_674  -13
    arc_0_21_3  in_degree_731  1
    arc_0_21_3  out_degree_780  1
    arc_0_21_3  original_T_including_depot_unload_795  1.8073464544423741e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_3  arc_capacity_673  1
    load_0_21_3  segment_load_conservation_734  -1
    load_0_21_3  segment_prefix_lb_735  1
    load_0_21_3  segment_prefix_ub_736  1
    load_0_21_3  free_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_4  arc_capacity_675  -20
    arc_0_21_4  connected_order_arc_676  -13
    arc_0_21_4  in_degree_738  1
    arc_0_21_4  out_degree_780  1
    arc_0_21_4  original_T_including_depot_unload_795  1.7249161387293191e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_4  arc_capacity_675  1
    load_0_21_4  segment_load_conservation_741  -1
    load_0_21_4  segment_prefix_lb_742  1
    load_0_21_4  segment_prefix_ub_743  1
    load_0_21_4  free_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_15  arc_capacity_677  -20
    arc_0_21_15  connected_order_arc_678  -13
    arc_0_21_15  in_degree_745  1
    arc_0_21_15  out_degree_780  1
    arc_0_21_15  original_T_including_depot_unload_795  2.0104743468619281e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_15  arc_capacity_677  1
    load_0_21_15  free_load_conservation_749  -1
    load_0_21_15  free_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_16  arc_capacity_679  -20
    arc_0_21_16  connected_order_arc_680  -13
    arc_0_21_16  in_degree_751  1
    arc_0_21_16  out_degree_780  1
    arc_0_21_16  original_T_including_depot_unload_795  1.8442669473423912e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_16  arc_capacity_679  1
    load_0_21_16  free_load_conservation_755  -1
    load_0_21_16  free_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_17  arc_capacity_681  -20
    arc_0_21_17  connected_order_arc_682  -13
    arc_0_21_17  in_degree_757  1
    arc_0_21_17  out_degree_780  1
    arc_0_21_17  original_T_including_depot_unload_795  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_17  arc_capacity_681  1
    load_0_21_17  free_load_conservation_761  -1
    load_0_21_17  free_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_18  arc_capacity_683  -20
    arc_0_21_18  connected_order_arc_684  -13
    arc_0_21_18  in_degree_763  1
    arc_0_21_18  out_degree_780  1
    arc_0_21_18  original_T_including_depot_unload_795  2.3332890980657526e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_18  arc_capacity_683  1
    load_0_21_18  free_load_conservation_767  -1
    load_0_21_18  free_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_19  arc_capacity_685  -20
    arc_0_21_19  connected_order_arc_686  -13
    arc_0_21_19  in_degree_769  1
    arc_0_21_19  out_degree_780  1
    arc_0_21_19  original_T_including_depot_unload_795  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_19  arc_capacity_685  1
    load_0_21_19  free_load_conservation_773  -1
    load_0_21_19  free_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_20  arc_capacity_687  -20
    arc_0_21_20  connected_order_arc_688  -13
    arc_0_21_20  in_degree_775  1
    arc_0_21_20  out_degree_780  1
    arc_0_21_20  original_T_including_depot_unload_795  1.7883808204567979e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_20  arc_capacity_687  1
    load_0_21_20  free_load_conservation_779  -1
    load_0_21_20  free_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_22  arc_capacity_689  -20
    arc_0_21_22  connected_order_arc_690  -13
    arc_0_21_22  out_degree_780  1
    arc_0_21_22  in_degree_787  1
    arc_0_21_22  original_T_including_depot_unload_795  2.4500766064196278e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_22  arc_capacity_689  1
    load_0_21_22  free_load_conservation_785  1
    load_0_21_22  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_0  arc_capacity_691  -20
    arc_0_22_0  depot_return_or_bypass_715  1
    arc_0_22_0  out_degree_786  1
    arc_0_22_0  original_T_including_depot_unload_795  1.3076700111397606e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_22_0  arc_capacity_691  1
    load_0_22_0  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_1  arc_capacity_692  -20
    arc_0_22_1  connected_order_arc_693  -13
    arc_0_22_1  in_degree_717  1
    arc_0_22_1  out_degree_786  1
    arc_0_22_1  original_T_including_depot_unload_795  1.3286968036345565e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_22_1  arc_capacity_692  1
    load_0_22_1  segment_load_conservation_720  -1
    load_0_22_1  segment_prefix_lb_721  1
    load_0_22_1  segment_prefix_ub_722  1
    load_0_22_1  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_2  arc_capacity_694  -20
    arc_0_22_2  connected_order_arc_695  -13
    arc_0_22_2  in_degree_724  1
    arc_0_22_2  out_degree_786  1
    arc_0_22_2  original_T_including_depot_unload_795  1.3740068502263614e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_22_2  arc_capacity_694  1
    load_0_22_2  segment_load_conservation_727  -1
    load_0_22_2  segment_prefix_lb_728  1
    load_0_22_2  segment_prefix_ub_729  1
    load_0_22_2  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_3  arc_capacity_696  -20
    arc_0_22_3  connected_order_arc_697  -13
    arc_0_22_3  in_degree_731  1
    arc_0_22_3  out_degree_786  1
    arc_0_22_3  original_T_including_depot_unload_795  1.3082661182285894e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_22_3  arc_capacity_696  1
    load_0_22_3  segment_load_conservation_734  -1
    load_0_22_3  segment_prefix_lb_735  1
    load_0_22_3  segment_prefix_ub_736  1
    load_0_22_3  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_4  arc_capacity_698  -20
    arc_0_22_4  connected_order_arc_699  -13
    arc_0_22_4  in_degree_738  1
    arc_0_22_4  out_degree_786  1
    arc_0_22_4  original_T_including_depot_unload_795  1.5356938236745739e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_22_4  arc_capacity_698  1
    load_0_22_4  segment_load_conservation_741  -1
    load_0_22_4  segment_prefix_lb_742  1
    load_0_22_4  segment_prefix_ub_743  1
    load_0_22_4  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_15  arc_capacity_700  -20
    arc_0_22_15  connected_order_arc_701  -13
    arc_0_22_15  in_degree_745  1
    arc_0_22_15  out_degree_786  1
    arc_0_22_15  original_T_including_depot_unload_795  4.6588884124393707e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_15  arc_capacity_700  1
    load_0_22_15  free_load_conservation_749  -1
    load_0_22_15  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_16  arc_capacity_702  -20
    arc_0_22_16  connected_order_arc_703  -13
    arc_0_22_16  in_degree_751  1
    arc_0_22_16  out_degree_786  1
    arc_0_22_16  original_T_including_depot_unload_795  6.2102815646279714e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_16  arc_capacity_702  1
    load_0_22_16  free_load_conservation_755  -1
    load_0_22_16  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_17  arc_capacity_704  -20
    arc_0_22_17  connected_order_arc_705  -13
    arc_0_22_17  in_degree_757  1
    arc_0_22_17  out_degree_786  1
    arc_0_22_17  original_T_including_depot_unload_795  1.3218357148919101e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_22_17  arc_capacity_704  1
    load_0_22_17  free_load_conservation_761  -1
    load_0_22_17  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_18  arc_capacity_706  -20
    arc_0_22_18  connected_order_arc_707  -13
    arc_0_22_18  in_degree_763  1
    arc_0_22_18  out_degree_786  1
    arc_0_22_18  original_T_including_depot_unload_795  1.9785969874636677e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_18  arc_capacity_706  1
    load_0_22_18  free_load_conservation_767  -1
    load_0_22_18  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_19  arc_capacity_708  -20
    arc_0_22_19  connected_order_arc_709  -13
    arc_0_22_19  in_degree_769  1
    arc_0_22_19  out_degree_786  1
    arc_0_22_19  original_T_including_depot_unload_795  9.3685967675232439e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_19  arc_capacity_708  1
    load_0_22_19  free_load_conservation_773  -1
    load_0_22_19  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_20  arc_capacity_710  -20
    arc_0_22_20  connected_order_arc_711  -13
    arc_0_22_20  in_degree_775  1
    arc_0_22_20  out_degree_786  1
    arc_0_22_20  original_T_including_depot_unload_795  8.0531033344008677e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_20  arc_capacity_710  1
    load_0_22_20  free_load_conservation_779  -1
    load_0_22_20  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_21  arc_capacity_712  -20
    arc_0_22_21  connected_order_arc_713  -13
    arc_0_22_21  in_degree_781  1
    arc_0_22_21  out_degree_786  1
    arc_0_22_21  original_T_including_depot_unload_795  2.4500766064196278e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_22_21  arc_capacity_712  1
    load_0_22_21  free_load_conservation_785  -1
    load_0_22_21  free_load_conservation_791  1
    visit_1_5  out_degree_1191  -1
    visit_1_5  in_degree_1192  -1
    visit_1_5  order_active_lb_1193  -1
    visit_1_5  order_active_ub_1194  -14
    order_1_5  connected_order_arc_813  -1
    order_1_5  connected_order_arc_815  -1
    order_1_5  connected_order_arc_817  -1
    order_1_5  connected_order_arc_819  -1
    order_1_5  connected_order_arc_821  -1
    order_1_5  connected_order_arc_823  -1
    order_1_5  connected_order_arc_825  -1
    order_1_5  connected_order_arc_827  -1
    order_1_5  connected_order_arc_829  -1
    order_1_5  connected_order_arc_831  -1
    order_1_5  connected_order_arc_833  -1
    order_1_5  connected_order_arc_835  -1
    order_1_5  connected_order_arc_837  -1
    order_1_5  connected_order_arc_840  1
    order_1_5  connected_order_arc_867  1
    order_1_5  connected_order_arc_894  1
    order_1_5  connected_order_arc_921  1
    order_1_5  connected_order_arc_948  1
    order_1_5  connected_order_arc_975  1
    order_1_5  connected_order_arc_1002  1
    order_1_5  connected_order_arc_1029  1
    order_1_5  connected_order_arc_1056  1
    order_1_5  connected_order_arc_1083  1
    order_1_5  connected_order_arc_1110  1
    order_1_5  connected_order_arc_1137  1
    order_1_5  connected_order_arc_1164  1
    order_1_5  order_active_lb_1193  1
    order_1_5  order_active_ub_1194  1
    order_1_5  fixed_segment_relative_order_1281  -1
    visit_1_6  out_degree_1198  -1
    visit_1_6  in_degree_1199  -1
    visit_1_6  order_active_lb_1200  -1
    visit_1_6  order_active_ub_1201  -14
    order_1_6  connected_order_arc_813  1
    order_1_6  connected_order_arc_840  -1
    order_1_6  connected_order_arc_842  -1
    order_1_6  connected_order_arc_844  -1
    order_1_6  connected_order_arc_846  -1
    order_1_6  connected_order_arc_848  -1
    order_1_6  connected_order_arc_850  -1
    order_1_6  connected_order_arc_852  -1
    order_1_6  connected_order_arc_854  -1
    order_1_6  connected_order_arc_856  -1
    order_1_6  connected_order_arc_858  -1
    order_1_6  connected_order_arc_860  -1
    order_1_6  connected_order_arc_862  -1
    order_1_6  connected_order_arc_864  -1
    order_1_6  connected_order_arc_869  1
    order_1_6  connected_order_arc_896  1
    order_1_6  connected_order_arc_923  1
    order_1_6  connected_order_arc_950  1
    order_1_6  connected_order_arc_977  1
    order_1_6  connected_order_arc_1004  1
    order_1_6  connected_order_arc_1031  1
    order_1_6  connected_order_arc_1058  1
    order_1_6  connected_order_arc_1085  1
    order_1_6  connected_order_arc_1112  1
    order_1_6  connected_order_arc_1139  1
    order_1_6  connected_order_arc_1166  1
    order_1_6  order_active_lb_1200  1
    order_1_6  order_active_ub_1201  1
    order_1_6  fixed_segment_relative_order_1281  1
    order_1_6  fixed_segment_relative_order_1282  -1
    visit_1_7  out_degree_1205  -1
    visit_1_7  in_degree_1206  -1
    visit_1_7  order_active_lb_1207  -1
    visit_1_7  order_active_ub_1208  -14
    order_1_7  connected_order_arc_815  1
    order_1_7  connected_order_arc_842  1
    order_1_7  connected_order_arc_867  -1
    order_1_7  connected_order_arc_869  -1
    order_1_7  connected_order_arc_871  -1
    order_1_7  connected_order_arc_873  -1
    order_1_7  connected_order_arc_875  -1
    order_1_7  connected_order_arc_877  -1
    order_1_7  connected_order_arc_879  -1
    order_1_7  connected_order_arc_881  -1
    order_1_7  connected_order_arc_883  -1
    order_1_7  connected_order_arc_885  -1
    order_1_7  connected_order_arc_887  -1
    order_1_7  connected_order_arc_889  -1
    order_1_7  connected_order_arc_891  -1
    order_1_7  connected_order_arc_898  1
    order_1_7  connected_order_arc_925  1
    order_1_7  connected_order_arc_952  1
    order_1_7  connected_order_arc_979  1
    order_1_7  connected_order_arc_1006  1
    order_1_7  connected_order_arc_1033  1
    order_1_7  connected_order_arc_1060  1
    order_1_7  connected_order_arc_1087  1
    order_1_7  connected_order_arc_1114  1
    order_1_7  connected_order_arc_1141  1
    order_1_7  connected_order_arc_1168  1
    order_1_7  order_active_lb_1207  1
    order_1_7  order_active_ub_1208  1
    order_1_7  fixed_segment_relative_order_1282  1
    order_1_7  fixed_segment_relative_order_1283  -1
    visit_1_8  out_degree_1212  -1
    visit_1_8  in_degree_1213  -1
    visit_1_8  order_active_lb_1214  -1
    visit_1_8  order_active_ub_1215  -14
    order_1_8  connected_order_arc_817  1
    order_1_8  connected_order_arc_844  1
    order_1_8  connected_order_arc_871  1
    order_1_8  connected_order_arc_894  -1
    order_1_8  connected_order_arc_896  -1
    order_1_8  connected_order_arc_898  -1
    order_1_8  connected_order_arc_900  -1
    order_1_8  connected_order_arc_902  -1
    order_1_8  connected_order_arc_904  -1
    order_1_8  connected_order_arc_906  -1
    order_1_8  connected_order_arc_908  -1
    order_1_8  connected_order_arc_910  -1
    order_1_8  connected_order_arc_912  -1
    order_1_8  connected_order_arc_914  -1
    order_1_8  connected_order_arc_916  -1
    order_1_8  connected_order_arc_918  -1
    order_1_8  connected_order_arc_927  1
    order_1_8  connected_order_arc_954  1
    order_1_8  connected_order_arc_981  1
    order_1_8  connected_order_arc_1008  1
    order_1_8  connected_order_arc_1035  1
    order_1_8  connected_order_arc_1062  1
    order_1_8  connected_order_arc_1089  1
    order_1_8  connected_order_arc_1116  1
    order_1_8  connected_order_arc_1143  1
    order_1_8  connected_order_arc_1170  1
    order_1_8  order_active_lb_1214  1
    order_1_8  order_active_ub_1215  1
    order_1_8  fixed_segment_relative_order_1283  1
    order_1_8  fixed_segment_relative_order_1284  -1
    visit_1_9  out_degree_1219  -1
    visit_1_9  in_degree_1220  -1
    visit_1_9  order_active_lb_1221  -1
    visit_1_9  order_active_ub_1222  -14
    order_1_9  connected_order_arc_819  1
    order_1_9  connected_order_arc_846  1
    order_1_9  connected_order_arc_873  1
    order_1_9  connected_order_arc_900  1
    order_1_9  connected_order_arc_921  -1
    order_1_9  connected_order_arc_923  -1
    order_1_9  connected_order_arc_925  -1
    order_1_9  connected_order_arc_927  -1
    order_1_9  connected_order_arc_929  -1
    order_1_9  connected_order_arc_931  -1
    order_1_9  connected_order_arc_933  -1
    order_1_9  connected_order_arc_935  -1
    order_1_9  connected_order_arc_937  -1
    order_1_9  connected_order_arc_939  -1
    order_1_9  connected_order_arc_941  -1
    order_1_9  connected_order_arc_943  -1
    order_1_9  connected_order_arc_945  -1
    order_1_9  connected_order_arc_956  1
    order_1_9  connected_order_arc_983  1
    order_1_9  connected_order_arc_1010  1
    order_1_9  connected_order_arc_1037  1
    order_1_9  connected_order_arc_1064  1
    order_1_9  connected_order_arc_1091  1
    order_1_9  connected_order_arc_1118  1
    order_1_9  connected_order_arc_1145  1
    order_1_9  connected_order_arc_1172  1
    order_1_9  order_active_lb_1221  1
    order_1_9  order_active_ub_1222  1
    order_1_9  fixed_segment_relative_order_1284  1
    order_1_9  fixed_segment_relative_order_1285  -1
    visit_1_10  out_degree_1226  -1
    visit_1_10  in_degree_1227  -1
    visit_1_10  order_active_lb_1228  -1
    visit_1_10  order_active_ub_1229  -14
    order_1_10  connected_order_arc_821  1
    order_1_10  connected_order_arc_848  1
    order_1_10  connected_order_arc_875  1
    order_1_10  connected_order_arc_902  1
    order_1_10  connected_order_arc_929  1
    order_1_10  connected_order_arc_948  -1
    order_1_10  connected_order_arc_950  -1
    order_1_10  connected_order_arc_952  -1
    order_1_10  connected_order_arc_954  -1
    order_1_10  connected_order_arc_956  -1
    order_1_10  connected_order_arc_958  -1
    order_1_10  connected_order_arc_960  -1
    order_1_10  connected_order_arc_962  -1
    order_1_10  connected_order_arc_964  -1
    order_1_10  connected_order_arc_966  -1
    order_1_10  connected_order_arc_968  -1
    order_1_10  connected_order_arc_970  -1
    order_1_10  connected_order_arc_972  -1
    order_1_10  connected_order_arc_985  1
    order_1_10  connected_order_arc_1012  1
    order_1_10  connected_order_arc_1039  1
    order_1_10  connected_order_arc_1066  1
    order_1_10  connected_order_arc_1093  1
    order_1_10  connected_order_arc_1120  1
    order_1_10  connected_order_arc_1147  1
    order_1_10  connected_order_arc_1174  1
    order_1_10  order_active_lb_1228  1
    order_1_10  order_active_ub_1229  1
    order_1_10  fixed_segment_relative_order_1285  1
    visit_1_15  out_degree_1233  -1
    visit_1_15  in_degree_1234  -1
    visit_1_15  order_active_lb_1235  -1
    visit_1_15  order_active_ub_1236  -14
    visit_1_15  service_visit_def_1237  -1
    order_1_15  connected_order_arc_823  1
    order_1_15  connected_order_arc_850  1
    order_1_15  connected_order_arc_877  1
    order_1_15  connected_order_arc_904  1
    order_1_15  connected_order_arc_931  1
    order_1_15  connected_order_arc_958  1
    order_1_15  connected_order_arc_975  -1
    order_1_15  connected_order_arc_977  -1
    order_1_15  connected_order_arc_979  -1
    order_1_15  connected_order_arc_981  -1
    order_1_15  connected_order_arc_983  -1
    order_1_15  connected_order_arc_985  -1
    order_1_15  connected_order_arc_987  -1
    order_1_15  connected_order_arc_989  -1
    order_1_15  connected_order_arc_991  -1
    order_1_15  connected_order_arc_993  -1
    order_1_15  connected_order_arc_995  -1
    order_1_15  connected_order_arc_997  -1
    order_1_15  connected_order_arc_999  -1
    order_1_15  connected_order_arc_1014  1
    order_1_15  connected_order_arc_1041  1
    order_1_15  connected_order_arc_1068  1
    order_1_15  connected_order_arc_1095  1
    order_1_15  connected_order_arc_1122  1
    order_1_15  connected_order_arc_1149  1
    order_1_15  connected_order_arc_1176  1
    order_1_15  order_active_lb_1235  1
    order_1_15  order_active_ub_1236  1
    visit_1_16  out_degree_1239  -1
    visit_1_16  in_degree_1240  -1
    visit_1_16  order_active_lb_1241  -1
    visit_1_16  order_active_ub_1242  -14
    visit_1_16  service_visit_def_1243  -1
    order_1_16  connected_order_arc_825  1
    order_1_16  connected_order_arc_852  1
    order_1_16  connected_order_arc_879  1
    order_1_16  connected_order_arc_906  1
    order_1_16  connected_order_arc_933  1
    order_1_16  connected_order_arc_960  1
    order_1_16  connected_order_arc_987  1
    order_1_16  connected_order_arc_1002  -1
    order_1_16  connected_order_arc_1004  -1
    order_1_16  connected_order_arc_1006  -1
    order_1_16  connected_order_arc_1008  -1
    order_1_16  connected_order_arc_1010  -1
    order_1_16  connected_order_arc_1012  -1
    order_1_16  connected_order_arc_1014  -1
    order_1_16  connected_order_arc_1016  -1
    order_1_16  connected_order_arc_1018  -1
    order_1_16  connected_order_arc_1020  -1
    order_1_16  connected_order_arc_1022  -1
    order_1_16  connected_order_arc_1024  -1
    order_1_16  connected_order_arc_1026  -1
    order_1_16  connected_order_arc_1043  1
    order_1_16  connected_order_arc_1070  1
    order_1_16  connected_order_arc_1097  1
    order_1_16  connected_order_arc_1124  1
    order_1_16  connected_order_arc_1151  1
    order_1_16  connected_order_arc_1178  1
    order_1_16  order_active_lb_1241  1
    order_1_16  order_active_ub_1242  1
    visit_1_17  out_degree_1245  -1
    visit_1_17  in_degree_1246  -1
    visit_1_17  order_active_lb_1247  -1
    visit_1_17  order_active_ub_1248  -14
    visit_1_17  service_visit_def_1249  -1
    order_1_17  connected_order_arc_827  1
    order_1_17  connected_order_arc_854  1
    order_1_17  connected_order_arc_881  1
    order_1_17  connected_order_arc_908  1
    order_1_17  connected_order_arc_935  1
    order_1_17  connected_order_arc_962  1
    order_1_17  connected_order_arc_989  1
    order_1_17  connected_order_arc_1016  1
    order_1_17  connected_order_arc_1029  -1
    order_1_17  connected_order_arc_1031  -1
    order_1_17  connected_order_arc_1033  -1
    order_1_17  connected_order_arc_1035  -1
    order_1_17  connected_order_arc_1037  -1
    order_1_17  connected_order_arc_1039  -1
    order_1_17  connected_order_arc_1041  -1
    order_1_17  connected_order_arc_1043  -1
    order_1_17  connected_order_arc_1045  -1
    order_1_17  connected_order_arc_1047  -1
    order_1_17  connected_order_arc_1049  -1
    order_1_17  connected_order_arc_1051  -1
    order_1_17  connected_order_arc_1053  -1
    order_1_17  connected_order_arc_1072  1
    order_1_17  connected_order_arc_1099  1
    order_1_17  connected_order_arc_1126  1
    order_1_17  connected_order_arc_1153  1
    order_1_17  connected_order_arc_1180  1
    order_1_17  order_active_lb_1247  1
    order_1_17  order_active_ub_1248  1
    visit_1_18  out_degree_1251  -1
    visit_1_18  in_degree_1252  -1
    visit_1_18  order_active_lb_1253  -1
    visit_1_18  order_active_ub_1254  -14
    visit_1_18  service_visit_def_1255  -1
    order_1_18  connected_order_arc_829  1
    order_1_18  connected_order_arc_856  1
    order_1_18  connected_order_arc_883  1
    order_1_18  connected_order_arc_910  1
    order_1_18  connected_order_arc_937  1
    order_1_18  connected_order_arc_964  1
    order_1_18  connected_order_arc_991  1
    order_1_18  connected_order_arc_1018  1
    order_1_18  connected_order_arc_1045  1
    order_1_18  connected_order_arc_1056  -1
    order_1_18  connected_order_arc_1058  -1
    order_1_18  connected_order_arc_1060  -1
    order_1_18  connected_order_arc_1062  -1
    order_1_18  connected_order_arc_1064  -1
    order_1_18  connected_order_arc_1066  -1
    order_1_18  connected_order_arc_1068  -1
    order_1_18  connected_order_arc_1070  -1
    order_1_18  connected_order_arc_1072  -1
    order_1_18  connected_order_arc_1074  -1
    order_1_18  connected_order_arc_1076  -1
    order_1_18  connected_order_arc_1078  -1
    order_1_18  connected_order_arc_1080  -1
    order_1_18  connected_order_arc_1101  1
    order_1_18  connected_order_arc_1128  1
    order_1_18  connected_order_arc_1155  1
    order_1_18  connected_order_arc_1182  1
    order_1_18  order_active_lb_1253  1
    order_1_18  order_active_ub_1254  1
    visit_1_19  out_degree_1257  -1
    visit_1_19  in_degree_1258  -1
    visit_1_19  order_active_lb_1259  -1
    visit_1_19  order_active_ub_1260  -14
    visit_1_19  service_visit_def_1261  -1
    order_1_19  connected_order_arc_831  1
    order_1_19  connected_order_arc_858  1
    order_1_19  connected_order_arc_885  1
    order_1_19  connected_order_arc_912  1
    order_1_19  connected_order_arc_939  1
    order_1_19  connected_order_arc_966  1
    order_1_19  connected_order_arc_993  1
    order_1_19  connected_order_arc_1020  1
    order_1_19  connected_order_arc_1047  1
    order_1_19  connected_order_arc_1074  1
    order_1_19  connected_order_arc_1083  -1
    order_1_19  connected_order_arc_1085  -1
    order_1_19  connected_order_arc_1087  -1
    order_1_19  connected_order_arc_1089  -1
    order_1_19  connected_order_arc_1091  -1
    order_1_19  connected_order_arc_1093  -1
    order_1_19  connected_order_arc_1095  -1
    order_1_19  connected_order_arc_1097  -1
    order_1_19  connected_order_arc_1099  -1
    order_1_19  connected_order_arc_1101  -1
    order_1_19  connected_order_arc_1103  -1
    order_1_19  connected_order_arc_1105  -1
    order_1_19  connected_order_arc_1107  -1
    order_1_19  connected_order_arc_1130  1
    order_1_19  connected_order_arc_1157  1
    order_1_19  connected_order_arc_1184  1
    order_1_19  order_active_lb_1259  1
    order_1_19  order_active_ub_1260  1
    visit_1_20  out_degree_1263  -1
    visit_1_20  in_degree_1264  -1
    visit_1_20  order_active_lb_1265  -1
    visit_1_20  order_active_ub_1266  -14
    visit_1_20  service_visit_def_1267  -1
    order_1_20  connected_order_arc_833  1
    order_1_20  connected_order_arc_860  1
    order_1_20  connected_order_arc_887  1
    order_1_20  connected_order_arc_914  1
    order_1_20  connected_order_arc_941  1
    order_1_20  connected_order_arc_968  1
    order_1_20  connected_order_arc_995  1
    order_1_20  connected_order_arc_1022  1
    order_1_20  connected_order_arc_1049  1
    order_1_20  connected_order_arc_1076  1
    order_1_20  connected_order_arc_1103  1
    order_1_20  connected_order_arc_1110  -1
    order_1_20  connected_order_arc_1112  -1
    order_1_20  connected_order_arc_1114  -1
    order_1_20  connected_order_arc_1116  -1
    order_1_20  connected_order_arc_1118  -1
    order_1_20  connected_order_arc_1120  -1
    order_1_20  connected_order_arc_1122  -1
    order_1_20  connected_order_arc_1124  -1
    order_1_20  connected_order_arc_1126  -1
    order_1_20  connected_order_arc_1128  -1
    order_1_20  connected_order_arc_1130  -1
    order_1_20  connected_order_arc_1132  -1
    order_1_20  connected_order_arc_1134  -1
    order_1_20  connected_order_arc_1159  1
    order_1_20  connected_order_arc_1186  1
    order_1_20  order_active_lb_1265  1
    order_1_20  order_active_ub_1266  1
    visit_1_21  out_degree_1269  -1
    visit_1_21  in_degree_1270  -1
    visit_1_21  order_active_lb_1271  -1
    visit_1_21  order_active_ub_1272  -14
    visit_1_21  service_visit_def_1273  -1
    order_1_21  connected_order_arc_835  1
    order_1_21  connected_order_arc_862  1
    order_1_21  connected_order_arc_889  1
    order_1_21  connected_order_arc_916  1
    order_1_21  connected_order_arc_943  1
    order_1_21  connected_order_arc_970  1
    order_1_21  connected_order_arc_997  1
    order_1_21  connected_order_arc_1024  1
    order_1_21  connected_order_arc_1051  1
    order_1_21  connected_order_arc_1078  1
    order_1_21  connected_order_arc_1105  1
    order_1_21  connected_order_arc_1132  1
    order_1_21  connected_order_arc_1137  -1
    order_1_21  connected_order_arc_1139  -1
    order_1_21  connected_order_arc_1141  -1
    order_1_21  connected_order_arc_1143  -1
    order_1_21  connected_order_arc_1145  -1
    order_1_21  connected_order_arc_1147  -1
    order_1_21  connected_order_arc_1149  -1
    order_1_21  connected_order_arc_1151  -1
    order_1_21  connected_order_arc_1153  -1
    order_1_21  connected_order_arc_1155  -1
    order_1_21  connected_order_arc_1157  -1
    order_1_21  connected_order_arc_1159  -1
    order_1_21  connected_order_arc_1161  -1
    order_1_21  connected_order_arc_1188  1
    order_1_21  order_active_lb_1271  1
    order_1_21  order_active_ub_1272  1
    visit_1_22  out_degree_1275  -1
    visit_1_22  in_degree_1276  -1
    visit_1_22  order_active_lb_1277  -1
    visit_1_22  order_active_ub_1278  -14
    visit_1_22  service_visit_def_1279  -1
    order_1_22  connected_order_arc_837  1
    order_1_22  connected_order_arc_864  1
    order_1_22  connected_order_arc_891  1
    order_1_22  connected_order_arc_918  1
    order_1_22  connected_order_arc_945  1
    order_1_22  connected_order_arc_972  1
    order_1_22  connected_order_arc_999  1
    order_1_22  connected_order_arc_1026  1
    order_1_22  connected_order_arc_1053  1
    order_1_22  connected_order_arc_1080  1
    order_1_22  connected_order_arc_1107  1
    order_1_22  connected_order_arc_1134  1
    order_1_22  connected_order_arc_1161  1
    order_1_22  connected_order_arc_1164  -1
    order_1_22  connected_order_arc_1166  -1
    order_1_22  connected_order_arc_1168  -1
    order_1_22  connected_order_arc_1170  -1
    order_1_22  connected_order_arc_1172  -1
    order_1_22  connected_order_arc_1174  -1
    order_1_22  connected_order_arc_1176  -1
    order_1_22  connected_order_arc_1178  -1
    order_1_22  connected_order_arc_1180  -1
    order_1_22  connected_order_arc_1182  -1
    order_1_22  connected_order_arc_1184  -1
    order_1_22  connected_order_arc_1186  -1
    order_1_22  connected_order_arc_1188  -1
    order_1_22  order_active_lb_1277  1
    order_1_22  order_active_ub_1278  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_0  arc_capacity_796  -25
    arc_1_0_0  depot_departure_or_bypass_1189  1
    arc_1_0_0  depot_return_or_bypass_1190  1
    MARKER    'MARKER'                 'INTEND'
    load_1_0_0  arc_capacity_796  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_5  arc_capacity_797  -25
    arc_1_0_5  depot_departure_or_bypass_1189  1
    arc_1_0_5  in_degree_1192  1
    arc_1_0_5  original_T_including_depot_unload_1286  8.7918533905669346e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_5  arc_capacity_797  1
    load_1_0_5  segment_load_conservation_1195  -1
    load_1_0_5  segment_prefix_lb_1196  1
    load_1_0_5  segment_prefix_ub_1197  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_6  arc_capacity_798  -25
    arc_1_0_6  depot_departure_or_bypass_1189  1
    arc_1_0_6  in_degree_1199  1
    arc_1_0_6  original_T_including_depot_unload_1286  1.2801771486108735e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_6  arc_capacity_798  1
    load_1_0_6  segment_load_conservation_1202  -1
    load_1_0_6  segment_prefix_lb_1203  1
    load_1_0_6  segment_prefix_ub_1204  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_7  arc_capacity_799  -25
    arc_1_0_7  depot_departure_or_bypass_1189  1
    arc_1_0_7  in_degree_1206  1
    arc_1_0_7  original_T_including_depot_unload_1286  887.312716328479
    MARKER    'MARKER'                 'INTEND'
    load_1_0_7  arc_capacity_799  1
    load_1_0_7  segment_load_conservation_1209  -1
    load_1_0_7  segment_prefix_lb_1210  1
    load_1_0_7  segment_prefix_ub_1211  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_8  arc_capacity_800  -25
    arc_1_0_8  depot_departure_or_bypass_1189  1
    arc_1_0_8  in_degree_1213  1
    arc_1_0_8  original_T_including_depot_unload_1286  7.8195480223834068e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_8  arc_capacity_800  1
    load_1_0_8  segment_load_conservation_1216  -1
    load_1_0_8  segment_prefix_lb_1217  1
    load_1_0_8  segment_prefix_ub_1218  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_9  arc_capacity_801  -25
    arc_1_0_9  depot_departure_or_bypass_1189  1
    arc_1_0_9  in_degree_1220  1
    arc_1_0_9  original_T_including_depot_unload_1286  4.7522445589173662e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_9  arc_capacity_801  1
    load_1_0_9  segment_load_conservation_1223  -1
    load_1_0_9  segment_prefix_lb_1224  1
    load_1_0_9  segment_prefix_ub_1225  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_10  arc_capacity_802  -25
    arc_1_0_10  depot_departure_or_bypass_1189  1
    arc_1_0_10  in_degree_1227  1
    arc_1_0_10  original_T_including_depot_unload_1286  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_10  arc_capacity_802  1
    load_1_0_10  segment_load_conservation_1230  -1
    load_1_0_10  segment_prefix_lb_1231  1
    load_1_0_10  segment_prefix_ub_1232  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_15  arc_capacity_803  -25
    arc_1_0_15  depot_departure_or_bypass_1189  1
    arc_1_0_15  in_degree_1234  1
    arc_1_0_15  original_T_including_depot_unload_1286  1.0088905112952611e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_15  arc_capacity_803  1
    load_1_0_15  free_load_conservation_1238  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_16  arc_capacity_804  -25
    arc_1_0_16  depot_departure_or_bypass_1189  1
    arc_1_0_16  in_degree_1240  1
    arc_1_0_16  original_T_including_depot_unload_1286  8.7749189782983967e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_16  arc_capacity_804  1
    load_1_0_16  free_load_conservation_1244  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_17  arc_capacity_805  -25
    arc_1_0_17  depot_departure_or_bypass_1189  1
    arc_1_0_17  in_degree_1246  1
    arc_1_0_17  original_T_including_depot_unload_1286  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_17  arc_capacity_805  1
    load_1_0_17  free_load_conservation_1250  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_18  arc_capacity_806  -25
    arc_1_0_18  depot_departure_or_bypass_1189  1
    arc_1_0_18  in_degree_1252  1
    arc_1_0_18  original_T_including_depot_unload_1286  1.2751323166566442e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_18  arc_capacity_806  1
    load_1_0_18  free_load_conservation_1256  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_19  arc_capacity_807  -25
    arc_1_0_19  depot_departure_or_bypass_1189  1
    arc_1_0_19  in_degree_1258  1
    arc_1_0_19  original_T_including_depot_unload_1286  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_19  arc_capacity_807  1
    load_1_0_19  free_load_conservation_1262  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_20  arc_capacity_808  -25
    arc_1_0_20  depot_departure_or_bypass_1189  1
    arc_1_0_20  in_degree_1264  1
    arc_1_0_20  original_T_including_depot_unload_1286  1.0479182987243917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_20  arc_capacity_808  1
    load_1_0_20  free_load_conservation_1268  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_21  arc_capacity_809  -25
    arc_1_0_21  depot_departure_or_bypass_1189  1
    arc_1_0_21  in_degree_1270  1
    arc_1_0_21  original_T_including_depot_unload_1286  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_21  arc_capacity_809  1
    load_1_0_21  free_load_conservation_1274  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_22  arc_capacity_810  -25
    arc_1_0_22  depot_departure_or_bypass_1189  1
    arc_1_0_22  in_degree_1276  1
    arc_1_0_22  original_T_including_depot_unload_1286  1.3076700111397606e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_22  arc_capacity_810  1
    load_1_0_22  free_load_conservation_1280  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_0  arc_capacity_811  -25
    arc_1_5_0  depot_return_or_bypass_1190  1
    arc_1_5_0  out_degree_1191  1
    arc_1_5_0  original_T_including_depot_unload_1286  8.7918533905669346e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_5_0  arc_capacity_811  1
    load_1_5_0  segment_load_conservation_1195  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_6  arc_capacity_812  -25
    arc_1_5_6  connected_order_arc_813  -15
    arc_1_5_6  out_degree_1191  1
    arc_1_5_6  in_degree_1199  1
    arc_1_5_6  original_T_including_depot_unload_1286  1.3197014959146461e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_6  arc_capacity_812  1
    load_1_5_6  segment_load_conservation_1195  1
    load_1_5_6  segment_load_conservation_1202  -1
    load_1_5_6  segment_prefix_lb_1203  1
    load_1_5_6  segment_prefix_ub_1204  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_7  arc_capacity_814  -25
    arc_1_5_7  connected_order_arc_815  -15
    arc_1_5_7  out_degree_1191  1
    arc_1_5_7  in_degree_1206  1
    arc_1_5_7  original_T_including_depot_unload_1286  1.0967168052209140e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_7  arc_capacity_814  1
    load_1_5_7  segment_load_conservation_1195  1
    load_1_5_7  segment_load_conservation_1209  -1
    load_1_5_7  segment_prefix_lb_1210  1
    load_1_5_7  segment_prefix_ub_1211  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_8  arc_capacity_816  -25
    arc_1_5_8  connected_order_arc_817  -15
    arc_1_5_8  out_degree_1191  1
    arc_1_5_8  in_degree_1213  1
    arc_1_5_8  original_T_including_depot_unload_1286  1.0062397105603651e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_8  arc_capacity_816  1
    load_1_5_8  segment_load_conservation_1195  1
    load_1_5_8  segment_load_conservation_1216  -1
    load_1_5_8  segment_prefix_lb_1217  1
    load_1_5_8  segment_prefix_ub_1218  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_9  arc_capacity_818  -25
    arc_1_5_9  connected_order_arc_819  -15
    arc_1_5_9  out_degree_1191  1
    arc_1_5_9  in_degree_1220  1
    arc_1_5_9  original_T_including_depot_unload_1286  1.0793944823036150e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_9  arc_capacity_818  1
    load_1_5_9  segment_load_conservation_1195  1
    load_1_5_9  segment_load_conservation_1223  -1
    load_1_5_9  segment_prefix_lb_1224  1
    load_1_5_9  segment_prefix_ub_1225  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_10  arc_capacity_820  -25
    arc_1_5_10  connected_order_arc_821  -15
    arc_1_5_10  out_degree_1191  1
    arc_1_5_10  in_degree_1227  1
    arc_1_5_10  original_T_including_depot_unload_1286  7.5634788469878674e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_5_10  arc_capacity_820  1
    load_1_5_10  segment_load_conservation_1195  1
    load_1_5_10  segment_load_conservation_1230  -1
    load_1_5_10  segment_prefix_lb_1231  1
    load_1_5_10  segment_prefix_ub_1232  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_15  arc_capacity_822  -25
    arc_1_5_15  connected_order_arc_823  -15
    arc_1_5_15  out_degree_1191  1
    arc_1_5_15  in_degree_1234  1
    arc_1_5_15  original_T_including_depot_unload_1286  5.1107432522690152e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_5_15  arc_capacity_822  1
    load_1_5_15  segment_load_conservation_1195  1
    load_1_5_15  free_load_conservation_1238  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_16  arc_capacity_824  -25
    arc_1_5_16  connected_order_arc_825  -15
    arc_1_5_16  out_degree_1191  1
    arc_1_5_16  in_degree_1240  1
    arc_1_5_16  original_T_including_depot_unload_1286  3.6821827312741834e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_5_16  arc_capacity_824  1
    load_1_5_16  segment_load_conservation_1195  1
    load_1_5_16  free_load_conservation_1244  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_17  arc_capacity_826  -25
    arc_1_5_17  connected_order_arc_827  -15
    arc_1_5_17  out_degree_1191  1
    arc_1_5_17  in_degree_1246  1
    arc_1_5_17  original_T_including_depot_unload_1286  3.6824909986567474e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_5_17  arc_capacity_826  1
    load_1_5_17  segment_load_conservation_1195  1
    load_1_5_17  free_load_conservation_1250  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_18  arc_capacity_828  -25
    arc_1_5_18  connected_order_arc_829  -15
    arc_1_5_18  out_degree_1191  1
    arc_1_5_18  in_degree_1252  1
    arc_1_5_18  original_T_including_depot_unload_1286  8.2035300709080423e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_5_18  arc_capacity_828  1
    load_1_5_18  segment_load_conservation_1195  1
    load_1_5_18  free_load_conservation_1256  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_19  arc_capacity_830  -25
    arc_1_5_19  connected_order_arc_831  -15
    arc_1_5_19  out_degree_1191  1
    arc_1_5_19  in_degree_1258  1
    arc_1_5_19  original_T_including_depot_unload_1286  1.0412376551742484e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_19  arc_capacity_830  1
    load_1_5_19  segment_load_conservation_1195  1
    load_1_5_19  free_load_conservation_1262  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_20  arc_capacity_832  -25
    arc_1_5_20  connected_order_arc_833  -15
    arc_1_5_20  out_degree_1191  1
    arc_1_5_20  in_degree_1264  1
    arc_1_5_20  original_T_including_depot_unload_1286  2.4155873404211835e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_5_20  arc_capacity_832  1
    load_1_5_20  segment_load_conservation_1195  1
    load_1_5_20  free_load_conservation_1268  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_21  arc_capacity_834  -25
    arc_1_5_21  connected_order_arc_835  -15
    arc_1_5_21  out_degree_1191  1
    arc_1_5_21  in_degree_1270  1
    arc_1_5_21  original_T_including_depot_unload_1286  1.5502221880497036e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_21  arc_capacity_834  1
    load_1_5_21  segment_load_conservation_1195  1
    load_1_5_21  free_load_conservation_1274  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_22  arc_capacity_836  -25
    arc_1_5_22  connected_order_arc_837  -15
    arc_1_5_22  out_degree_1191  1
    arc_1_5_22  in_degree_1276  1
    arc_1_5_22  original_T_including_depot_unload_1286  9.7692852841087415e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_5_22  arc_capacity_836  1
    load_1_5_22  segment_load_conservation_1195  1
    load_1_5_22  free_load_conservation_1280  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_0  arc_capacity_838  -25
    arc_1_6_0  depot_return_or_bypass_1190  1
    arc_1_6_0  out_degree_1198  1
    arc_1_6_0  original_T_including_depot_unload_1286  9.8831482002326163e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_0  arc_capacity_838  1
    load_1_6_0  segment_load_conservation_1202  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_5  arc_capacity_839  -25
    arc_1_6_5  connected_order_arc_840  -15
    arc_1_6_5  in_degree_1192  1
    arc_1_6_5  out_degree_1198  1
    arc_1_6_5  original_T_including_depot_unload_1286  1.1360772387139011e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_5  arc_capacity_839  1
    load_1_6_5  segment_load_conservation_1195  -1
    load_1_6_5  segment_prefix_lb_1196  1
    load_1_6_5  segment_prefix_ub_1197  1
    load_1_6_5  segment_load_conservation_1202  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_7  arc_capacity_841  -25
    arc_1_6_7  connected_order_arc_842  -15
    arc_1_6_7  out_degree_1198  1
    arc_1_6_7  in_degree_1206  1
    arc_1_6_7  original_T_including_depot_unload_1286  1.0652142597817847e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_7  arc_capacity_841  1
    load_1_6_7  segment_load_conservation_1202  1
    load_1_6_7  segment_load_conservation_1209  -1
    load_1_6_7  segment_prefix_lb_1210  1
    load_1_6_7  segment_prefix_ub_1211  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_8  arc_capacity_843  -25
    arc_1_6_8  connected_order_arc_844  -15
    arc_1_6_8  out_degree_1198  1
    arc_1_6_8  in_degree_1213  1
    arc_1_6_8  original_T_including_depot_unload_1286  2.0644059606137412e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_8  arc_capacity_843  1
    load_1_6_8  segment_load_conservation_1202  1
    load_1_6_8  segment_load_conservation_1216  -1
    load_1_6_8  segment_prefix_lb_1217  1
    load_1_6_8  segment_prefix_ub_1218  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_9  arc_capacity_845  -25
    arc_1_6_9  connected_order_arc_846  -15
    arc_1_6_9  out_degree_1198  1
    arc_1_6_9  in_degree_1220  1
    arc_1_6_9  original_T_including_depot_unload_1286  6.0342879231962252e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_9  arc_capacity_845  1
    load_1_6_9  segment_load_conservation_1202  1
    load_1_6_9  segment_load_conservation_1223  -1
    load_1_6_9  segment_prefix_lb_1224  1
    load_1_6_9  segment_prefix_ub_1225  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_10  arc_capacity_847  -25
    arc_1_6_10  connected_order_arc_848  -15
    arc_1_6_10  out_degree_1198  1
    arc_1_6_10  in_degree_1227  1
    arc_1_6_10  original_T_including_depot_unload_1286  9.3918874471053675e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_10  arc_capacity_847  1
    load_1_6_10  segment_load_conservation_1202  1
    load_1_6_10  segment_load_conservation_1230  -1
    load_1_6_10  segment_prefix_lb_1231  1
    load_1_6_10  segment_prefix_ub_1232  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_15  arc_capacity_849  -25
    arc_1_6_15  connected_order_arc_850  -15
    arc_1_6_15  out_degree_1198  1
    arc_1_6_15  in_degree_1234  1
    arc_1_6_15  original_T_including_depot_unload_1286  7.5249256121297628e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_15  arc_capacity_849  1
    load_1_6_15  segment_load_conservation_1202  1
    load_1_6_15  free_load_conservation_1238  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_16  arc_capacity_851  -25
    arc_1_6_16  connected_order_arc_852  -15
    arc_1_6_16  out_degree_1198  1
    arc_1_6_16  in_degree_1240  1
    arc_1_6_16  original_T_including_depot_unload_1286  8.0195161088934185e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_16  arc_capacity_851  1
    load_1_6_16  segment_load_conservation_1202  1
    load_1_6_16  free_load_conservation_1244  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_17  arc_capacity_853  -25
    arc_1_6_17  connected_order_arc_854  -15
    arc_1_6_17  out_degree_1198  1
    arc_1_6_17  in_degree_1246  1
    arc_1_6_17  original_T_including_depot_unload_1286  1.5013589792907314e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_17  arc_capacity_853  1
    load_1_6_17  segment_load_conservation_1202  1
    load_1_6_17  free_load_conservation_1250  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_18  arc_capacity_855  -25
    arc_1_6_18  connected_order_arc_856  -15
    arc_1_6_18  out_degree_1198  1
    arc_1_6_18  in_degree_1252  1
    arc_1_6_18  original_T_including_depot_unload_1286  7.3382689952363592e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_18  arc_capacity_855  1
    load_1_6_18  segment_load_conservation_1202  1
    load_1_6_18  free_load_conservation_1256  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_19  arc_capacity_857  -25
    arc_1_6_19  connected_order_arc_858  -15
    arc_1_6_19  out_degree_1198  1
    arc_1_6_19  in_degree_1258  1
    arc_1_6_19  original_T_including_depot_unload_1286  4.4073908743473044e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_19  arc_capacity_857  1
    load_1_6_19  segment_load_conservation_1202  1
    load_1_6_19  free_load_conservation_1262  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_20  arc_capacity_859  -25
    arc_1_6_20  connected_order_arc_860  -15
    arc_1_6_20  out_degree_1198  1
    arc_1_6_20  in_degree_1264  1
    arc_1_6_20  original_T_including_depot_unload_1286  1.0854925215530507e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_20  arc_capacity_859  1
    load_1_6_20  segment_load_conservation_1202  1
    load_1_6_20  free_load_conservation_1268  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_21  arc_capacity_861  -25
    arc_1_6_21  connected_order_arc_862  -15
    arc_1_6_21  out_degree_1198  1
    arc_1_6_21  in_degree_1270  1
    arc_1_6_21  original_T_including_depot_unload_1286  2.3179341182261583e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_21  arc_capacity_861  1
    load_1_6_21  segment_load_conservation_1202  1
    load_1_6_21  free_load_conservation_1274  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_22  arc_capacity_863  -25
    arc_1_6_22  connected_order_arc_864  -15
    arc_1_6_22  out_degree_1198  1
    arc_1_6_22  in_degree_1276  1
    arc_1_6_22  original_T_including_depot_unload_1286  6.0870346483367848e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_22  arc_capacity_863  1
    load_1_6_22  segment_load_conservation_1202  1
    load_1_6_22  free_load_conservation_1280  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_0  arc_capacity_865  -25
    arc_1_7_0  depot_return_or_bypass_1190  1
    arc_1_7_0  out_degree_1205  1
    arc_1_7_0  original_T_including_depot_unload_1286  887.312716328479
    MARKER    'MARKER'                 'INTEND'
    load_1_7_0  arc_capacity_865  1
    load_1_7_0  segment_load_conservation_1209  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_5  arc_capacity_866  -25
    arc_1_7_5  connected_order_arc_867  -15
    arc_1_7_5  in_degree_1192  1
    arc_1_7_5  out_degree_1205  1
    arc_1_7_5  original_T_including_depot_unload_1286  1.0967168052209140e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_5  arc_capacity_866  1
    load_1_7_5  segment_load_conservation_1195  -1
    load_1_7_5  segment_prefix_lb_1196  1
    load_1_7_5  segment_prefix_ub_1197  1
    load_1_7_5  segment_load_conservation_1209  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_6  arc_capacity_868  -25
    arc_1_7_6  connected_order_arc_869  -15
    arc_1_7_6  in_degree_1199  1
    arc_1_7_6  out_degree_1205  1
    arc_1_7_6  original_T_including_depot_unload_1286  4.0010881633455318e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_6  arc_capacity_868  1
    load_1_7_6  segment_load_conservation_1202  -1
    load_1_7_6  segment_prefix_lb_1203  1
    load_1_7_6  segment_prefix_ub_1204  1
    load_1_7_6  segment_load_conservation_1209  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_8  arc_capacity_870  -25
    arc_1_7_8  connected_order_arc_871  -15
    arc_1_7_8  out_degree_1205  1
    arc_1_7_8  in_degree_1213  1
    arc_1_7_8  original_T_including_depot_unload_1286  1.1119949880978965e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_8  arc_capacity_870  1
    load_1_7_8  segment_load_conservation_1209  1
    load_1_7_8  segment_load_conservation_1216  -1
    load_1_7_8  segment_prefix_lb_1217  1
    load_1_7_8  segment_prefix_ub_1218  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_9  arc_capacity_872  -25
    arc_1_7_9  connected_order_arc_873  -15
    arc_1_7_9  out_degree_1205  1
    arc_1_7_9  in_degree_1220  1
    arc_1_7_9  original_T_including_depot_unload_1286  4.9711893625650669e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_9  arc_capacity_872  1
    load_1_7_9  segment_load_conservation_1209  1
    load_1_7_9  segment_load_conservation_1223  -1
    load_1_7_9  segment_prefix_lb_1224  1
    load_1_7_9  segment_prefix_ub_1225  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_10  arc_capacity_874  -25
    arc_1_7_10  connected_order_arc_875  -15
    arc_1_7_10  out_degree_1205  1
    arc_1_7_10  in_degree_1227  1
    arc_1_7_10  original_T_including_depot_unload_1286  8.4332546654485930e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_10  arc_capacity_874  1
    load_1_7_10  segment_load_conservation_1209  1
    load_1_7_10  segment_load_conservation_1230  -1
    load_1_7_10  segment_prefix_lb_1231  1
    load_1_7_10  segment_prefix_ub_1232  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_15  arc_capacity_876  -25
    arc_1_7_15  connected_order_arc_877  -15
    arc_1_7_15  out_degree_1205  1
    arc_1_7_15  in_degree_1234  1
    arc_1_7_15  original_T_including_depot_unload_1286  754.162661294669
    MARKER    'MARKER'                 'INTEND'
    load_1_7_15  arc_capacity_876  1
    load_1_7_15  segment_load_conservation_1209  1
    load_1_7_15  free_load_conservation_1238  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_16  arc_capacity_878  -25
    arc_1_7_16  connected_order_arc_879  -15
    arc_1_7_16  out_degree_1205  1
    arc_1_7_16  in_degree_1240  1
    arc_1_7_16  original_T_including_depot_unload_1286  7.8136221151890174e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_16  arc_capacity_878  1
    load_1_7_16  segment_load_conservation_1209  1
    load_1_7_16  free_load_conservation_1244  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_17  arc_capacity_880  -25
    arc_1_7_17  connected_order_arc_881  -15
    arc_1_7_17  out_degree_1205  1
    arc_1_7_17  in_degree_1246  1
    arc_1_7_17  original_T_including_depot_unload_1286  1.4573788798892317e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_17  arc_capacity_880  1
    load_1_7_17  segment_load_conservation_1209  1
    load_1_7_17  free_load_conservation_1250  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_18  arc_capacity_882  -25
    arc_1_7_18  connected_order_arc_883  -15
    arc_1_7_18  out_degree_1205  1
    arc_1_7_18  in_degree_1252  1
    arc_1_7_18  original_T_including_depot_unload_1286  7.7983683767935065e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_18  arc_capacity_882  1
    load_1_7_18  segment_load_conservation_1209  1
    load_1_7_18  free_load_conservation_1256  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_19  arc_capacity_884  -25
    arc_1_7_19  connected_order_arc_885  -15
    arc_1_7_19  out_degree_1205  1
    arc_1_7_19  in_degree_1258  1
    arc_1_7_19  original_T_including_depot_unload_1286  3.3422575089633142e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_19  arc_capacity_884  1
    load_1_7_19  segment_load_conservation_1209  1
    load_1_7_19  free_load_conservation_1262  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_20  arc_capacity_886  -25
    arc_1_7_20  connected_order_arc_887  -15
    arc_1_7_20  out_degree_1205  1
    arc_1_7_20  in_degree_1264  1
    arc_1_7_20  original_T_including_depot_unload_1286  1.0684489086573428e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_20  arc_capacity_886  1
    load_1_7_20  segment_load_conservation_1209  1
    load_1_7_20  free_load_conservation_1268  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_21  arc_capacity_888  -25
    arc_1_7_21  connected_order_arc_889  -15
    arc_1_7_21  out_degree_1205  1
    arc_1_7_21  in_degree_1270  1
    arc_1_7_21  original_T_including_depot_unload_1286  2226.1143218952
    MARKER    'MARKER'                 'INTEND'
    load_1_7_21  arc_capacity_888  1
    load_1_7_21  segment_load_conservation_1209  1
    load_1_7_21  free_load_conservation_1274  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_22  arc_capacity_890  -25
    arc_1_7_22  connected_order_arc_891  -15
    arc_1_7_22  out_degree_1205  1
    arc_1_7_22  in_degree_1276  1
    arc_1_7_22  original_T_including_depot_unload_1286  6.7554763364087285e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_22  arc_capacity_890  1
    load_1_7_22  segment_load_conservation_1209  1
    load_1_7_22  free_load_conservation_1280  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_0  arc_capacity_892  -25
    arc_1_8_0  depot_return_or_bypass_1190  1
    arc_1_8_0  out_degree_1212  1
    arc_1_8_0  original_T_including_depot_unload_1286  7.8195480223834068e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_0  arc_capacity_892  1
    load_1_8_0  segment_load_conservation_1216  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_5  arc_capacity_893  -25
    arc_1_8_5  connected_order_arc_894  -15
    arc_1_8_5  in_degree_1192  1
    arc_1_8_5  out_degree_1212  1
    arc_1_8_5  original_T_including_depot_unload_1286  1.0062397105603651e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_5  arc_capacity_893  1
    load_1_8_5  segment_load_conservation_1195  -1
    load_1_8_5  segment_prefix_lb_1196  1
    load_1_8_5  segment_prefix_ub_1197  1
    load_1_8_5  segment_load_conservation_1216  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_6  arc_capacity_895  -25
    arc_1_8_6  connected_order_arc_896  -15
    arc_1_8_6  in_degree_1199  1
    arc_1_8_6  out_degree_1212  1
    arc_1_8_6  original_T_including_depot_unload_1286  4.9903342483612323e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_6  arc_capacity_895  1
    load_1_8_6  segment_load_conservation_1202  -1
    load_1_8_6  segment_prefix_lb_1203  1
    load_1_8_6  segment_prefix_ub_1204  1
    load_1_8_6  segment_load_conservation_1216  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_7  arc_capacity_897  -25
    arc_1_8_7  connected_order_arc_898  -15
    arc_1_8_7  in_degree_1206  1
    arc_1_8_7  out_degree_1212  1
    arc_1_8_7  original_T_including_depot_unload_1286  1.1119949880978965e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_7  arc_capacity_897  1
    load_1_8_7  segment_load_conservation_1209  -1
    load_1_8_7  segment_prefix_lb_1210  1
    load_1_8_7  segment_prefix_ub_1211  1
    load_1_8_7  segment_load_conservation_1216  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_9  arc_capacity_899  -25
    arc_1_8_9  connected_order_arc_900  -15
    arc_1_8_9  out_degree_1212  1
    arc_1_8_9  in_degree_1220  1
    arc_1_8_9  original_T_including_depot_unload_1286  4.1964259385165178e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_9  arc_capacity_899  1
    load_1_8_9  segment_load_conservation_1216  1
    load_1_8_9  segment_load_conservation_1223  -1
    load_1_8_9  segment_prefix_lb_1224  1
    load_1_8_9  segment_prefix_ub_1225  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_10  arc_capacity_901  -25
    arc_1_8_10  connected_order_arc_902  -15
    arc_1_8_10  out_degree_1212  1
    arc_1_8_10  in_degree_1227  1
    arc_1_8_10  original_T_including_depot_unload_1286  7.3394466063263269e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_10  arc_capacity_901  1
    load_1_8_10  segment_load_conservation_1216  1
    load_1_8_10  segment_load_conservation_1230  -1
    load_1_8_10  segment_prefix_lb_1231  1
    load_1_8_10  segment_prefix_ub_1232  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_15  arc_capacity_903  -25
    arc_1_8_15  connected_order_arc_904  -15
    arc_1_8_15  out_degree_1212  1
    arc_1_8_15  in_degree_1234  1
    arc_1_8_15  original_T_including_depot_unload_1286  7.0141209816069022e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_15  arc_capacity_903  1
    load_1_8_15  segment_load_conservation_1216  1
    load_1_8_15  free_load_conservation_1238  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_16  arc_capacity_905  -25
    arc_1_8_16  connected_order_arc_906  -15
    arc_1_8_16  out_degree_1212  1
    arc_1_8_16  in_degree_1240  1
    arc_1_8_16  original_T_including_depot_unload_1286  7.0804311489116617e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_16  arc_capacity_905  1
    load_1_8_16  segment_load_conservation_1216  1
    load_1_8_16  free_load_conservation_1244  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_17  arc_capacity_907  -25
    arc_1_8_17  connected_order_arc_908  -15
    arc_1_8_17  out_degree_1212  1
    arc_1_8_17  in_degree_1246  1
    arc_1_8_17  original_T_including_depot_unload_1286  1.3626829404511475e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_17  arc_capacity_907  1
    load_1_8_17  segment_load_conservation_1216  1
    load_1_8_17  free_load_conservation_1250  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_18  arc_capacity_909  -25
    arc_1_8_18  connected_order_arc_910  -15
    arc_1_8_18  out_degree_1212  1
    arc_1_8_18  in_degree_1252  1
    arc_1_8_18  original_T_including_depot_unload_1286  7.7248128224166851e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_18  arc_capacity_909  1
    load_1_8_18  segment_load_conservation_1216  1
    load_1_8_18  free_load_conservation_1256  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_19  arc_capacity_911  -25
    arc_1_8_19  connected_order_arc_912  -15
    arc_1_8_19  out_degree_1212  1
    arc_1_8_19  in_degree_1258  1
    arc_1_8_19  original_T_including_depot_unload_1286  2.5572087458878266e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_19  arc_capacity_911  1
    load_1_8_19  segment_load_conservation_1216  1
    load_1_8_19  free_load_conservation_1262  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_20  arc_capacity_913  -25
    arc_1_8_20  connected_order_arc_914  -15
    arc_1_8_20  out_degree_1212  1
    arc_1_8_20  in_degree_1264  1
    arc_1_8_20  original_T_including_depot_unload_1286  9.9524628735690555e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_20  arc_capacity_913  1
    load_1_8_20  segment_load_conservation_1216  1
    load_1_8_20  free_load_conservation_1268  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_21  arc_capacity_915  -25
    arc_1_8_21  connected_order_arc_916  -15
    arc_1_8_21  out_degree_1212  1
    arc_1_8_21  in_degree_1270  1
    arc_1_8_21  original_T_including_depot_unload_1286  2115.53677476792
    MARKER    'MARKER'                 'INTEND'
    load_1_8_21  arc_capacity_915  1
    load_1_8_21  segment_load_conservation_1216  1
    load_1_8_21  free_load_conservation_1274  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_22  arc_capacity_917  -25
    arc_1_8_22  connected_order_arc_918  -15
    arc_1_8_22  out_degree_1212  1
    arc_1_8_22  in_degree_1276  1
    arc_1_8_22  original_T_including_depot_unload_1286  6.9492720147205364e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_22  arc_capacity_917  1
    load_1_8_22  segment_load_conservation_1216  1
    load_1_8_22  free_load_conservation_1280  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_0  arc_capacity_919  -25
    arc_1_9_0  depot_return_or_bypass_1190  1
    arc_1_9_0  out_degree_1219  1
    arc_1_9_0  original_T_including_depot_unload_1286  4.7522445589173662e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_0  arc_capacity_919  1
    load_1_9_0  segment_load_conservation_1223  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_5  arc_capacity_920  -25
    arc_1_9_5  connected_order_arc_921  -15
    arc_1_9_5  in_degree_1192  1
    arc_1_9_5  out_degree_1219  1
    arc_1_9_5  original_T_including_depot_unload_1286  1.0793944823036150e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_5  arc_capacity_920  1
    load_1_9_5  segment_load_conservation_1195  -1
    load_1_9_5  segment_prefix_lb_1196  1
    load_1_9_5  segment_prefix_ub_1197  1
    load_1_9_5  segment_load_conservation_1223  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_6  arc_capacity_922  -25
    arc_1_9_6  connected_order_arc_923  -15
    arc_1_9_6  in_degree_1199  1
    arc_1_9_6  out_degree_1219  1
    arc_1_9_6  original_T_including_depot_unload_1286  8.9356126423557316e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_6  arc_capacity_922  1
    load_1_9_6  segment_load_conservation_1202  -1
    load_1_9_6  segment_prefix_lb_1203  1
    load_1_9_6  segment_prefix_ub_1204  1
    load_1_9_6  segment_load_conservation_1223  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_7  arc_capacity_924  -25
    arc_1_9_7  connected_order_arc_925  -15
    arc_1_9_7  in_degree_1206  1
    arc_1_9_7  out_degree_1219  1
    arc_1_9_7  original_T_including_depot_unload_1286  4.9711893625650669e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_7  arc_capacity_924  1
    load_1_9_7  segment_load_conservation_1209  -1
    load_1_9_7  segment_prefix_lb_1210  1
    load_1_9_7  segment_prefix_ub_1211  1
    load_1_9_7  segment_load_conservation_1223  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_8  arc_capacity_926  -25
    arc_1_9_8  connected_order_arc_927  -15
    arc_1_9_8  in_degree_1213  1
    arc_1_9_8  out_degree_1219  1
    arc_1_9_8  original_T_including_depot_unload_1286  4.1964259385165178e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_8  arc_capacity_926  1
    load_1_9_8  segment_load_conservation_1216  -1
    load_1_9_8  segment_prefix_lb_1217  1
    load_1_9_8  segment_prefix_ub_1218  1
    load_1_9_8  segment_load_conservation_1223  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_10  arc_capacity_928  -25
    arc_1_9_10  connected_order_arc_929  -15
    arc_1_9_10  out_degree_1219  1
    arc_1_9_10  in_degree_1227  1
    arc_1_9_10  original_T_including_depot_unload_1286  4.9232225330062903e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_10  arc_capacity_928  1
    load_1_9_10  segment_load_conservation_1223  1
    load_1_9_10  segment_load_conservation_1230  -1
    load_1_9_10  segment_prefix_lb_1231  1
    load_1_9_10  segment_prefix_ub_1232  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_15  arc_capacity_930  -25
    arc_1_9_15  connected_order_arc_931  -15
    arc_1_9_15  out_degree_1219  1
    arc_1_9_15  in_degree_1234  1
    arc_1_9_15  original_T_including_depot_unload_1286  9.6554407723795373e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_15  arc_capacity_930  1
    load_1_9_15  segment_load_conservation_1223  1
    load_1_9_15  free_load_conservation_1238  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_16  arc_capacity_932  -25
    arc_1_9_16  connected_order_arc_933  -15
    arc_1_9_16  out_degree_1219  1
    arc_1_9_16  in_degree_1240  1
    arc_1_9_16  original_T_including_depot_unload_1286  9.0121368945211725e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_16  arc_capacity_932  1
    load_1_9_16  segment_load_conservation_1223  1
    load_1_9_16  free_load_conservation_1244  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_17  arc_capacity_934  -25
    arc_1_9_17  connected_order_arc_935  -15
    arc_1_9_17  out_degree_1219  1
    arc_1_9_17  in_degree_1246  1
    arc_1_9_17  original_T_including_depot_unload_1286  1.3823927712314810e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_17  arc_capacity_934  1
    load_1_9_17  segment_load_conservation_1223  1
    load_1_9_17  free_load_conservation_1250  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_18  arc_capacity_936  -25
    arc_1_9_18  connected_order_arc_937  -15
    arc_1_9_18  out_degree_1219  1
    arc_1_9_18  in_degree_1252  1
    arc_1_9_18  original_T_including_depot_unload_1286  1.1310682908759807e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_18  arc_capacity_936  1
    load_1_9_18  segment_load_conservation_1223  1
    load_1_9_18  free_load_conservation_1256  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_19  arc_capacity_938  -25
    arc_1_9_19  connected_order_arc_939  -15
    arc_1_9_19  out_degree_1219  1
    arc_1_9_19  in_degree_1258  1
    arc_1_9_19  original_T_including_depot_unload_1286  1.6444540482789353e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_19  arc_capacity_938  1
    load_1_9_19  segment_load_conservation_1223  1
    load_1_9_19  free_load_conservation_1262  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_20  arc_capacity_940  -25
    arc_1_9_20  connected_order_arc_941  -15
    arc_1_9_20  out_degree_1219  1
    arc_1_9_20  in_degree_1264  1
    arc_1_9_20  original_T_including_depot_unload_1286  1.1592640472038677e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_20  arc_capacity_940  1
    load_1_9_20  segment_load_conservation_1223  1
    load_1_9_20  free_load_conservation_1268  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_21  arc_capacity_942  -25
    arc_1_9_21  connected_order_arc_943  -15
    arc_1_9_21  out_degree_1219  1
    arc_1_9_21  in_degree_1270  1
    arc_1_9_21  original_T_including_depot_unload_1286  1.8418804985785646e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_21  arc_capacity_942  1
    load_1_9_21  segment_load_conservation_1223  1
    load_1_9_21  free_load_conservation_1274  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_22  arc_capacity_944  -25
    arc_1_9_22  connected_order_arc_945  -15
    arc_1_9_22  out_degree_1219  1
    arc_1_9_22  in_degree_1276  1
    arc_1_9_22  original_T_including_depot_unload_1286  1.0910343836035740e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_22  arc_capacity_944  1
    load_1_9_22  segment_load_conservation_1223  1
    load_1_9_22  free_load_conservation_1280  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_0  arc_capacity_946  -25
    arc_1_10_0  depot_return_or_bypass_1190  1
    arc_1_10_0  out_degree_1226  1
    arc_1_10_0  original_T_including_depot_unload_1286  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_0  arc_capacity_946  1
    load_1_10_0  segment_load_conservation_1230  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_5  arc_capacity_947  -25
    arc_1_10_5  connected_order_arc_948  -15
    arc_1_10_5  in_degree_1192  1
    arc_1_10_5  out_degree_1226  1
    arc_1_10_5  original_T_including_depot_unload_1286  7.5634788469878674e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_5  arc_capacity_947  1
    load_1_10_5  segment_load_conservation_1195  -1
    load_1_10_5  segment_prefix_lb_1196  1
    load_1_10_5  segment_prefix_ub_1197  1
    load_1_10_5  segment_load_conservation_1230  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_6  arc_capacity_949  -25
    arc_1_10_6  connected_order_arc_950  -15
    arc_1_10_6  in_degree_1199  1
    arc_1_10_6  out_degree_1226  1
    arc_1_10_6  original_T_including_depot_unload_1286  1.2253808824170035e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_6  arc_capacity_949  1
    load_1_10_6  segment_load_conservation_1202  -1
    load_1_10_6  segment_prefix_lb_1203  1
    load_1_10_6  segment_prefix_ub_1204  1
    load_1_10_6  segment_load_conservation_1230  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_7  arc_capacity_951  -25
    arc_1_10_7  connected_order_arc_952  -15
    arc_1_10_7  in_degree_1206  1
    arc_1_10_7  out_degree_1226  1
    arc_1_10_7  original_T_including_depot_unload_1286  8.4332546654485930e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_7  arc_capacity_951  1
    load_1_10_7  segment_load_conservation_1209  -1
    load_1_10_7  segment_prefix_lb_1210  1
    load_1_10_7  segment_prefix_ub_1211  1
    load_1_10_7  segment_load_conservation_1230  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_8  arc_capacity_953  -25
    arc_1_10_8  connected_order_arc_954  -15
    arc_1_10_8  in_degree_1213  1
    arc_1_10_8  out_degree_1226  1
    arc_1_10_8  original_T_including_depot_unload_1286  7.3394466063263269e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_8  arc_capacity_953  1
    load_1_10_8  segment_load_conservation_1216  -1
    load_1_10_8  segment_prefix_lb_1217  1
    load_1_10_8  segment_prefix_ub_1218  1
    load_1_10_8  segment_load_conservation_1230  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_9  arc_capacity_955  -25
    arc_1_10_9  connected_order_arc_956  -15
    arc_1_10_9  in_degree_1220  1
    arc_1_10_9  out_degree_1226  1
    arc_1_10_9  original_T_including_depot_unload_1286  4.9232225330062903e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_9  arc_capacity_955  1
    load_1_10_9  segment_load_conservation_1223  -1
    load_1_10_9  segment_prefix_lb_1224  1
    load_1_10_9  segment_prefix_ub_1225  1
    load_1_10_9  segment_load_conservation_1230  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_15  arc_capacity_957  -25
    arc_1_10_15  connected_order_arc_958  -15
    arc_1_10_15  out_degree_1226  1
    arc_1_10_15  in_degree_1234  1
    arc_1_10_15  original_T_including_depot_unload_1286  8.9135689158237335e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_15  arc_capacity_957  1
    load_1_10_15  segment_load_conservation_1230  1
    load_1_10_15  free_load_conservation_1238  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_16  arc_capacity_959  -25
    arc_1_10_16  connected_order_arc_960  -15
    arc_1_10_16  out_degree_1226  1
    arc_1_10_16  in_degree_1240  1
    arc_1_10_16  original_T_including_depot_unload_1286  7.5571464781430223e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_16  arc_capacity_959  1
    load_1_10_16  segment_load_conservation_1230  1
    load_1_10_16  free_load_conservation_1244  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_17  arc_capacity_961  -25
    arc_1_10_17  connected_order_arc_962  -15
    arc_1_10_17  out_degree_1226  1
    arc_1_10_17  in_degree_1246  1
    arc_1_10_17  original_T_including_depot_unload_1286  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_17  arc_capacity_961  1
    load_1_10_17  segment_load_conservation_1230  1
    load_1_10_17  free_load_conservation_1250  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_18  arc_capacity_963  -25
    arc_1_10_18  connected_order_arc_964  -15
    arc_1_10_18  out_degree_1226  1
    arc_1_10_18  in_degree_1252  1
    arc_1_10_18  original_T_including_depot_unload_1286  1.1663816070445826e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_18  arc_capacity_963  1
    load_1_10_18  segment_load_conservation_1230  1
    load_1_10_18  free_load_conservation_1256  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_19  arc_capacity_965  -25
    arc_1_10_19  connected_order_arc_966  -15
    arc_1_10_19  out_degree_1226  1
    arc_1_10_19  in_degree_1258  1
    arc_1_10_19  original_T_including_depot_unload_1286  5.7102904773674652e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_19  arc_capacity_965  1
    load_1_10_19  segment_load_conservation_1230  1
    load_1_10_19  free_load_conservation_1262  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_20  arc_capacity_967  -25
    arc_1_10_20  connected_order_arc_968  -15
    arc_1_10_20  out_degree_1226  1
    arc_1_10_20  in_degree_1264  1
    arc_1_10_20  original_T_including_depot_unload_1286  9.2235470209829464e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_20  arc_capacity_967  1
    load_1_10_20  segment_load_conservation_1230  1
    load_1_10_20  free_load_conservation_1268  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_21  arc_capacity_969  -25
    arc_1_10_21  connected_order_arc_970  -15
    arc_1_10_21  out_degree_1226  1
    arc_1_10_21  in_degree_1270  1
    arc_1_10_21  original_T_including_depot_unload_1286  1.3857128117205509e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_21  arc_capacity_969  1
    load_1_10_21  segment_load_conservation_1230  1
    load_1_10_21  free_load_conservation_1274  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_22  arc_capacity_971  -25
    arc_1_10_22  connected_order_arc_972  -15
    arc_1_10_22  out_degree_1226  1
    arc_1_10_22  in_degree_1276  1
    arc_1_10_22  original_T_including_depot_unload_1286  1.2100678255370710e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_22  arc_capacity_971  1
    load_1_10_22  segment_load_conservation_1230  1
    load_1_10_22  free_load_conservation_1280  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_0  arc_capacity_973  -25
    arc_1_15_0  depot_return_or_bypass_1190  1
    arc_1_15_0  out_degree_1233  1
    arc_1_15_0  original_T_including_depot_unload_1286  1.0088905112952611e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_0  arc_capacity_973  1
    load_1_15_0  free_load_conservation_1238  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_5  arc_capacity_974  -25
    arc_1_15_5  connected_order_arc_975  -15
    arc_1_15_5  in_degree_1192  1
    arc_1_15_5  out_degree_1233  1
    arc_1_15_5  original_T_including_depot_unload_1286  5.1107432522690152e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_5  arc_capacity_974  1
    load_1_15_5  segment_load_conservation_1195  -1
    load_1_15_5  segment_prefix_lb_1196  1
    load_1_15_5  segment_prefix_ub_1197  1
    load_1_15_5  free_load_conservation_1238  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_6  arc_capacity_976  -25
    arc_1_15_6  connected_order_arc_977  -15
    arc_1_15_6  in_degree_1199  1
    arc_1_15_6  out_degree_1233  1
    arc_1_15_6  original_T_including_depot_unload_1286  8.6289703303586691e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_6  arc_capacity_976  1
    load_1_15_6  segment_load_conservation_1202  -1
    load_1_15_6  segment_prefix_lb_1203  1
    load_1_15_6  segment_prefix_ub_1204  1
    load_1_15_6  free_load_conservation_1238  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_7  arc_capacity_978  -25
    arc_1_15_7  connected_order_arc_979  -15
    arc_1_15_7  in_degree_1206  1
    arc_1_15_7  out_degree_1233  1
    arc_1_15_7  original_T_including_depot_unload_1286  754.162661294669
    MARKER    'MARKER'                 'INTEND'
    load_1_15_7  arc_capacity_978  1
    load_1_15_7  segment_load_conservation_1209  -1
    load_1_15_7  segment_prefix_lb_1210  1
    load_1_15_7  segment_prefix_ub_1211  1
    load_1_15_7  free_load_conservation_1238  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_8  arc_capacity_980  -25
    arc_1_15_8  connected_order_arc_981  -15
    arc_1_15_8  in_degree_1213  1
    arc_1_15_8  out_degree_1233  1
    arc_1_15_8  original_T_including_depot_unload_1286  7.0141209816069022e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_8  arc_capacity_980  1
    load_1_15_8  segment_load_conservation_1216  -1
    load_1_15_8  segment_prefix_lb_1217  1
    load_1_15_8  segment_prefix_ub_1218  1
    load_1_15_8  free_load_conservation_1238  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_9  arc_capacity_982  -25
    arc_1_15_9  connected_order_arc_983  -15
    arc_1_15_9  in_degree_1220  1
    arc_1_15_9  out_degree_1233  1
    arc_1_15_9  original_T_including_depot_unload_1286  9.6554407723795373e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_9  arc_capacity_982  1
    load_1_15_9  segment_load_conservation_1223  -1
    load_1_15_9  segment_prefix_lb_1224  1
    load_1_15_9  segment_prefix_ub_1225  1
    load_1_15_9  free_load_conservation_1238  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_10  arc_capacity_984  -25
    arc_1_15_10  connected_order_arc_985  -15
    arc_1_15_10  in_degree_1227  1
    arc_1_15_10  out_degree_1233  1
    arc_1_15_10  original_T_including_depot_unload_1286  8.9135689158237335e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_10  arc_capacity_984  1
    load_1_15_10  segment_load_conservation_1230  -1
    load_1_15_10  segment_prefix_lb_1231  1
    load_1_15_10  segment_prefix_ub_1232  1
    load_1_15_10  free_load_conservation_1238  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_16  arc_capacity_986  -25
    arc_1_15_16  connected_order_arc_987  -15
    arc_1_15_16  out_degree_1233  1
    arc_1_15_16  in_degree_1240  1
    arc_1_15_16  original_T_including_depot_unload_1286  1.6651295535886251e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_16  arc_capacity_986  1
    load_1_15_16  free_load_conservation_1238  1
    load_1_15_16  free_load_conservation_1244  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_17  arc_capacity_988  -25
    arc_1_15_17  connected_order_arc_989  -15
    arc_1_15_17  out_degree_1233  1
    arc_1_15_17  in_degree_1246  1
    arc_1_15_17  original_T_including_depot_unload_1286  861.314419336229
    MARKER    'MARKER'                 'INTEND'
    load_1_15_17  arc_capacity_988  1
    load_1_15_17  free_load_conservation_1238  1
    load_1_15_17  free_load_conservation_1250  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_18  arc_capacity_990  -25
    arc_1_15_18  connected_order_arc_991  -15
    arc_1_15_18  out_degree_1233  1
    arc_1_15_18  in_degree_1252  1
    arc_1_15_18  original_T_including_depot_unload_1286  3.2286832955801827e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_18  arc_capacity_990  1
    load_1_15_18  free_load_conservation_1238  1
    load_1_15_18  free_load_conservation_1256  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_19  arc_capacity_992  -25
    arc_1_15_19  connected_order_arc_993  -15
    arc_1_15_19  out_degree_1233  1
    arc_1_15_19  in_degree_1258  1
    arc_1_15_19  original_T_including_depot_unload_1286  8.5502565124349769e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_19  arc_capacity_992  1
    load_1_15_19  free_load_conservation_1238  1
    load_1_15_19  free_load_conservation_1262  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_20  arc_capacity_994  -25
    arc_1_15_20  connected_order_arc_995  -15
    arc_1_15_20  out_degree_1233  1
    arc_1_15_20  in_degree_1264  1
    arc_1_15_20  original_T_including_depot_unload_1286  3.6094216796124527e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_20  arc_capacity_994  1
    load_1_15_20  free_load_conservation_1238  1
    load_1_15_20  free_load_conservation_1268  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_21  arc_capacity_996  -25
    arc_1_15_21  connected_order_arc_997  -15
    arc_1_15_21  out_degree_1233  1
    arc_1_15_21  in_degree_1270  1
    arc_1_15_21  original_T_including_depot_unload_1286  2.0104743468619281e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_21  arc_capacity_996  1
    load_1_15_21  free_load_conservation_1238  1
    load_1_15_21  free_load_conservation_1274  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_22  arc_capacity_998  -25
    arc_1_15_22  connected_order_arc_999  -15
    arc_1_15_22  out_degree_1233  1
    arc_1_15_22  in_degree_1276  1
    arc_1_15_22  original_T_including_depot_unload_1286  4.6588884124393707e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_22  arc_capacity_998  1
    load_1_15_22  free_load_conservation_1238  1
    load_1_15_22  free_load_conservation_1280  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_0  arc_capacity_1000  -25
    arc_1_16_0  depot_return_or_bypass_1190  1
    arc_1_16_0  out_degree_1239  1
    arc_1_16_0  original_T_including_depot_unload_1286  8.7749189782983967e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_0  arc_capacity_1000  1
    load_1_16_0  free_load_conservation_1244  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_5  arc_capacity_1001  -25
    arc_1_16_5  connected_order_arc_1002  -15
    arc_1_16_5  in_degree_1192  1
    arc_1_16_5  out_degree_1239  1
    arc_1_16_5  original_T_including_depot_unload_1286  3.6821827312741834e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_5  arc_capacity_1001  1
    load_1_16_5  segment_load_conservation_1195  -1
    load_1_16_5  segment_prefix_lb_1196  1
    load_1_16_5  segment_prefix_ub_1197  1
    load_1_16_5  free_load_conservation_1244  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_6  arc_capacity_1003  -25
    arc_1_16_6  connected_order_arc_1004  -15
    arc_1_16_6  in_degree_1199  1
    arc_1_16_6  out_degree_1239  1
    arc_1_16_6  original_T_including_depot_unload_1286  9.5892865701726816e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_6  arc_capacity_1003  1
    load_1_16_6  segment_load_conservation_1202  -1
    load_1_16_6  segment_prefix_lb_1203  1
    load_1_16_6  segment_prefix_ub_1204  1
    load_1_16_6  free_load_conservation_1244  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_7  arc_capacity_1005  -25
    arc_1_16_7  connected_order_arc_1006  -15
    arc_1_16_7  in_degree_1206  1
    arc_1_16_7  out_degree_1239  1
    arc_1_16_7  original_T_including_depot_unload_1286  7.8136221151890174e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_7  arc_capacity_1005  1
    load_1_16_7  segment_load_conservation_1209  -1
    load_1_16_7  segment_prefix_lb_1210  1
    load_1_16_7  segment_prefix_ub_1211  1
    load_1_16_7  free_load_conservation_1244  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_8  arc_capacity_1007  -25
    arc_1_16_8  connected_order_arc_1008  -15
    arc_1_16_8  in_degree_1213  1
    arc_1_16_8  out_degree_1239  1
    arc_1_16_8  original_T_including_depot_unload_1286  7.0804311489116617e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_8  arc_capacity_1007  1
    load_1_16_8  segment_load_conservation_1216  -1
    load_1_16_8  segment_prefix_lb_1217  1
    load_1_16_8  segment_prefix_ub_1218  1
    load_1_16_8  free_load_conservation_1244  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_9  arc_capacity_1009  -25
    arc_1_16_9  connected_order_arc_1010  -15
    arc_1_16_9  in_degree_1220  1
    arc_1_16_9  out_degree_1239  1
    arc_1_16_9  original_T_including_depot_unload_1286  9.0121368945211725e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_9  arc_capacity_1009  1
    load_1_16_9  segment_load_conservation_1223  -1
    load_1_16_9  segment_prefix_lb_1224  1
    load_1_16_9  segment_prefix_ub_1225  1
    load_1_16_9  free_load_conservation_1244  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_10  arc_capacity_1011  -25
    arc_1_16_10  connected_order_arc_1012  -15
    arc_1_16_10  in_degree_1227  1
    arc_1_16_10  out_degree_1239  1
    arc_1_16_10  original_T_including_depot_unload_1286  7.5571464781430223e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_10  arc_capacity_1011  1
    load_1_16_10  segment_load_conservation_1230  -1
    load_1_16_10  segment_prefix_lb_1231  1
    load_1_16_10  segment_prefix_ub_1232  1
    load_1_16_10  free_load_conservation_1244  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_15  arc_capacity_1013  -25
    arc_1_16_15  connected_order_arc_1014  -15
    arc_1_16_15  in_degree_1234  1
    arc_1_16_15  out_degree_1239  1
    arc_1_16_15  original_T_including_depot_unload_1286  1.6651295535886251e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_15  arc_capacity_1013  1
    load_1_16_15  free_load_conservation_1238  -1
    load_1_16_15  free_load_conservation_1244  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_17  arc_capacity_1015  -25
    arc_1_16_17  connected_order_arc_1016  -15
    arc_1_16_17  out_degree_1239  1
    arc_1_16_17  in_degree_1246  1
    arc_1_16_17  original_T_including_depot_unload_1286  7.3227602527872671e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_17  arc_capacity_1015  1
    load_1_16_17  free_load_conservation_1244  1
    load_1_16_17  free_load_conservation_1250  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_18  arc_capacity_1017  -25
    arc_1_16_18  connected_order_arc_1018  -15
    arc_1_16_18  out_degree_1239  1
    arc_1_16_18  in_degree_1252  1
    arc_1_16_18  original_T_including_depot_unload_1286  4.8905010520753694e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_18  arc_capacity_1017  1
    load_1_16_18  free_load_conservation_1244  1
    load_1_16_18  free_load_conservation_1256  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_19  arc_capacity_1019  -25
    arc_1_16_19  connected_order_arc_1020  -15
    arc_1_16_19  out_degree_1239  1
    arc_1_16_19  in_degree_1258  1
    arc_1_16_19  original_T_including_depot_unload_1286  8.1417957710766450e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_19  arc_capacity_1019  1
    load_1_16_19  free_load_conservation_1244  1
    load_1_16_19  free_load_conservation_1262  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_20  arc_capacity_1021  -25
    arc_1_16_20  connected_order_arc_1022  -15
    arc_1_16_20  out_degree_1239  1
    arc_1_16_20  in_degree_1264  1
    arc_1_16_20  original_T_including_depot_unload_1286  2.8747557636937808e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_20  arc_capacity_1021  1
    load_1_16_20  free_load_conservation_1244  1
    load_1_16_20  free_load_conservation_1268  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_21  arc_capacity_1023  -25
    arc_1_16_21  connected_order_arc_1024  -15
    arc_1_16_21  out_degree_1239  1
    arc_1_16_21  in_degree_1270  1
    arc_1_16_21  original_T_including_depot_unload_1286  1.8442669473423912e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_21  arc_capacity_1023  1
    load_1_16_21  free_load_conservation_1244  1
    load_1_16_21  free_load_conservation_1274  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_22  arc_capacity_1025  -25
    arc_1_16_22  connected_order_arc_1026  -15
    arc_1_16_22  out_degree_1239  1
    arc_1_16_22  in_degree_1276  1
    arc_1_16_22  original_T_including_depot_unload_1286  6.2102815646279714e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_22  arc_capacity_1025  1
    load_1_16_22  free_load_conservation_1244  1
    load_1_16_22  free_load_conservation_1280  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_0  arc_capacity_1027  -25
    arc_1_17_0  depot_return_or_bypass_1190  1
    arc_1_17_0  out_degree_1245  1
    arc_1_17_0  original_T_including_depot_unload_1286  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_0  arc_capacity_1027  1
    load_1_17_0  free_load_conservation_1250  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_5  arc_capacity_1028  -25
    arc_1_17_5  connected_order_arc_1029  -15
    arc_1_17_5  in_degree_1192  1
    arc_1_17_5  out_degree_1245  1
    arc_1_17_5  original_T_including_depot_unload_1286  3.6824909986567474e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_5  arc_capacity_1028  1
    load_1_17_5  segment_load_conservation_1195  -1
    load_1_17_5  segment_prefix_lb_1196  1
    load_1_17_5  segment_prefix_ub_1197  1
    load_1_17_5  free_load_conservation_1250  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_6  arc_capacity_1030  -25
    arc_1_17_6  connected_order_arc_1031  -15
    arc_1_17_6  in_degree_1199  1
    arc_1_17_6  out_degree_1245  1
    arc_1_17_6  original_T_including_depot_unload_1286  1.6876944916846833e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_6  arc_capacity_1030  1
    load_1_17_6  segment_load_conservation_1202  -1
    load_1_17_6  segment_prefix_lb_1203  1
    load_1_17_6  segment_prefix_ub_1204  1
    load_1_17_6  free_load_conservation_1250  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_7  arc_capacity_1032  -25
    arc_1_17_7  connected_order_arc_1033  -15
    arc_1_17_7  in_degree_1206  1
    arc_1_17_7  out_degree_1245  1
    arc_1_17_7  original_T_including_depot_unload_1286  1.4573788798892317e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_7  arc_capacity_1032  1
    load_1_17_7  segment_load_conservation_1209  -1
    load_1_17_7  segment_prefix_lb_1210  1
    load_1_17_7  segment_prefix_ub_1211  1
    load_1_17_7  free_load_conservation_1250  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_8  arc_capacity_1034  -25
    arc_1_17_8  connected_order_arc_1035  -15
    arc_1_17_8  in_degree_1213  1
    arc_1_17_8  out_degree_1245  1
    arc_1_17_8  original_T_including_depot_unload_1286  1.3626829404511475e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_8  arc_capacity_1034  1
    load_1_17_8  segment_load_conservation_1216  -1
    load_1_17_8  segment_prefix_lb_1217  1
    load_1_17_8  segment_prefix_ub_1218  1
    load_1_17_8  free_load_conservation_1250  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_9  arc_capacity_1036  -25
    arc_1_17_9  connected_order_arc_1037  -15
    arc_1_17_9  in_degree_1220  1
    arc_1_17_9  out_degree_1245  1
    arc_1_17_9  original_T_including_depot_unload_1286  1.3823927712314810e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_9  arc_capacity_1036  1
    load_1_17_9  segment_load_conservation_1223  -1
    load_1_17_9  segment_prefix_lb_1224  1
    load_1_17_9  segment_prefix_ub_1225  1
    load_1_17_9  free_load_conservation_1250  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_10  arc_capacity_1038  -25
    arc_1_17_10  connected_order_arc_1039  -15
    arc_1_17_10  in_degree_1227  1
    arc_1_17_10  out_degree_1245  1
    arc_1_17_10  original_T_including_depot_unload_1286  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_10  arc_capacity_1038  1
    load_1_17_10  segment_load_conservation_1230  -1
    load_1_17_10  segment_prefix_lb_1231  1
    load_1_17_10  segment_prefix_ub_1232  1
    load_1_17_10  free_load_conservation_1250  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_15  arc_capacity_1040  -25
    arc_1_17_15  connected_order_arc_1041  -15
    arc_1_17_15  in_degree_1234  1
    arc_1_17_15  out_degree_1245  1
    arc_1_17_15  original_T_including_depot_unload_1286  861.314419336229
    MARKER    'MARKER'                 'INTEND'
    load_1_17_15  arc_capacity_1040  1
    load_1_17_15  free_load_conservation_1238  -1
    load_1_17_15  free_load_conservation_1250  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_16  arc_capacity_1042  -25
    arc_1_17_16  connected_order_arc_1043  -15
    arc_1_17_16  in_degree_1240  1
    arc_1_17_16  out_degree_1245  1
    arc_1_17_16  original_T_including_depot_unload_1286  7.3227602527872671e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_16  arc_capacity_1042  1
    load_1_17_16  free_load_conservation_1244  -1
    load_1_17_16  free_load_conservation_1250  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_18  arc_capacity_1044  -25
    arc_1_17_18  connected_order_arc_1045  -15
    arc_1_17_18  out_degree_1245  1
    arc_1_17_18  in_degree_1252  1
    arc_1_17_18  original_T_including_depot_unload_1286  1.1499210972200315e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_18  arc_capacity_1044  1
    load_1_17_18  free_load_conservation_1250  1
    load_1_17_18  free_load_conservation_1256  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_19  arc_capacity_1046  -25
    arc_1_17_19  connected_order_arc_1047  -15
    arc_1_17_19  out_degree_1245  1
    arc_1_17_19  in_degree_1258  1
    arc_1_17_19  original_T_including_depot_unload_1286  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_19  arc_capacity_1046  1
    load_1_17_19  free_load_conservation_1250  1
    load_1_17_19  free_load_conservation_1262  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_20  arc_capacity_1048  -25
    arc_1_17_20  connected_order_arc_1049  -15
    arc_1_17_20  out_degree_1245  1
    arc_1_17_20  in_degree_1264  1
    arc_1_17_20  original_T_including_depot_unload_1286  5.2280951376932137e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_20  arc_capacity_1048  1
    load_1_17_20  free_load_conservation_1250  1
    load_1_17_20  free_load_conservation_1268  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_21  arc_capacity_1050  -25
    arc_1_17_21  connected_order_arc_1051  -15
    arc_1_17_21  out_degree_1245  1
    arc_1_17_21  in_degree_1270  1
    arc_1_17_21  original_T_including_depot_unload_1286  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_21  arc_capacity_1050  1
    load_1_17_21  free_load_conservation_1250  1
    load_1_17_21  free_load_conservation_1274  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_22  arc_capacity_1052  -25
    arc_1_17_22  connected_order_arc_1053  -15
    arc_1_17_22  out_degree_1245  1
    arc_1_17_22  in_degree_1276  1
    arc_1_17_22  original_T_including_depot_unload_1286  1.3218357148919101e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_22  arc_capacity_1052  1
    load_1_17_22  free_load_conservation_1250  1
    load_1_17_22  free_load_conservation_1280  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_0  arc_capacity_1054  -25
    arc_1_18_0  depot_return_or_bypass_1190  1
    arc_1_18_0  out_degree_1251  1
    arc_1_18_0  original_T_including_depot_unload_1286  1.2751323166566442e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_0  arc_capacity_1054  1
    load_1_18_0  free_load_conservation_1256  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_5  arc_capacity_1055  -25
    arc_1_18_5  connected_order_arc_1056  -15
    arc_1_18_5  in_degree_1192  1
    arc_1_18_5  out_degree_1251  1
    arc_1_18_5  original_T_including_depot_unload_1286  8.2035300709080423e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_5  arc_capacity_1055  1
    load_1_18_5  segment_load_conservation_1195  -1
    load_1_18_5  segment_prefix_lb_1196  1
    load_1_18_5  segment_prefix_ub_1197  1
    load_1_18_5  free_load_conservation_1256  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_6  arc_capacity_1057  -25
    arc_1_18_6  connected_order_arc_1058  -15
    arc_1_18_6  in_degree_1199  1
    arc_1_18_6  out_degree_1251  1
    arc_1_18_6  original_T_including_depot_unload_1286  726.017738185843
    MARKER    'MARKER'                 'INTEND'
    load_1_18_6  arc_capacity_1057  1
    load_1_18_6  segment_load_conservation_1202  -1
    load_1_18_6  segment_prefix_lb_1203  1
    load_1_18_6  segment_prefix_ub_1204  1
    load_1_18_6  free_load_conservation_1256  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_7  arc_capacity_1059  -25
    arc_1_18_7  connected_order_arc_1060  -15
    arc_1_18_7  in_degree_1206  1
    arc_1_18_7  out_degree_1251  1
    arc_1_18_7  original_T_including_depot_unload_1286  7.7983683767935065e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_7  arc_capacity_1059  1
    load_1_18_7  segment_load_conservation_1209  -1
    load_1_18_7  segment_prefix_lb_1210  1
    load_1_18_7  segment_prefix_ub_1211  1
    load_1_18_7  free_load_conservation_1256  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_8  arc_capacity_1061  -25
    arc_1_18_8  connected_order_arc_1062  -15
    arc_1_18_8  in_degree_1213  1
    arc_1_18_8  out_degree_1251  1
    arc_1_18_8  original_T_including_depot_unload_1286  7.7248128224166851e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_8  arc_capacity_1061  1
    load_1_18_8  segment_load_conservation_1216  -1
    load_1_18_8  segment_prefix_lb_1217  1
    load_1_18_8  segment_prefix_ub_1218  1
    load_1_18_8  free_load_conservation_1256  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_9  arc_capacity_1063  -25
    arc_1_18_9  connected_order_arc_1064  -15
    arc_1_18_9  in_degree_1220  1
    arc_1_18_9  out_degree_1251  1
    arc_1_18_9  original_T_including_depot_unload_1286  1.1310682908759807e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_9  arc_capacity_1063  1
    load_1_18_9  segment_load_conservation_1223  -1
    load_1_18_9  segment_prefix_lb_1224  1
    load_1_18_9  segment_prefix_ub_1225  1
    load_1_18_9  free_load_conservation_1256  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_10  arc_capacity_1065  -25
    arc_1_18_10  connected_order_arc_1066  -15
    arc_1_18_10  in_degree_1227  1
    arc_1_18_10  out_degree_1251  1
    arc_1_18_10  original_T_including_depot_unload_1286  1.1663816070445826e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_10  arc_capacity_1065  1
    load_1_18_10  segment_load_conservation_1230  -1
    load_1_18_10  segment_prefix_lb_1231  1
    load_1_18_10  segment_prefix_ub_1232  1
    load_1_18_10  free_load_conservation_1256  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_15  arc_capacity_1067  -25
    arc_1_18_15  connected_order_arc_1068  -15
    arc_1_18_15  in_degree_1234  1
    arc_1_18_15  out_degree_1251  1
    arc_1_18_15  original_T_including_depot_unload_1286  3.2286832955801827e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_15  arc_capacity_1067  1
    load_1_18_15  free_load_conservation_1238  -1
    load_1_18_15  free_load_conservation_1256  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_16  arc_capacity_1069  -25
    arc_1_18_16  connected_order_arc_1070  -15
    arc_1_18_16  in_degree_1240  1
    arc_1_18_16  out_degree_1251  1
    arc_1_18_16  original_T_including_depot_unload_1286  4.8905010520753694e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_16  arc_capacity_1069  1
    load_1_18_16  free_load_conservation_1244  -1
    load_1_18_16  free_load_conservation_1256  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_17  arc_capacity_1071  -25
    arc_1_18_17  connected_order_arc_1072  -15
    arc_1_18_17  in_degree_1246  1
    arc_1_18_17  out_degree_1251  1
    arc_1_18_17  original_T_including_depot_unload_1286  1.1499210972200315e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_17  arc_capacity_1071  1
    load_1_18_17  free_load_conservation_1250  -1
    load_1_18_17  free_load_conservation_1256  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_19  arc_capacity_1073  -25
    arc_1_18_19  connected_order_arc_1074  -15
    arc_1_18_19  out_degree_1251  1
    arc_1_18_19  in_degree_1258  1
    arc_1_18_19  original_T_including_depot_unload_1286  990.144803963742
    MARKER    'MARKER'                 'INTEND'
    load_1_18_19  arc_capacity_1073  1
    load_1_18_19  free_load_conservation_1256  1
    load_1_18_19  free_load_conservation_1262  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_20  arc_capacity_1075  -25
    arc_1_18_20  connected_order_arc_1076  -15
    arc_1_18_20  out_degree_1251  1
    arc_1_18_20  in_degree_1264  1
    arc_1_18_20  original_T_including_depot_unload_1286  6.2793211180612207e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_20  arc_capacity_1075  1
    load_1_18_20  free_load_conservation_1256  1
    load_1_18_20  free_load_conservation_1268  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_21  arc_capacity_1077  -25
    arc_1_18_21  connected_order_arc_1078  -15
    arc_1_18_21  out_degree_1251  1
    arc_1_18_21  in_degree_1270  1
    arc_1_18_21  original_T_including_depot_unload_1286  2.3332890980657526e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_21  arc_capacity_1077  1
    load_1_18_21  free_load_conservation_1256  1
    load_1_18_21  free_load_conservation_1274  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_22  arc_capacity_1079  -25
    arc_1_18_22  connected_order_arc_1080  -15
    arc_1_18_22  out_degree_1251  1
    arc_1_18_22  in_degree_1276  1
    arc_1_18_22  original_T_including_depot_unload_1286  1.9785969874636677e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_22  arc_capacity_1079  1
    load_1_18_22  free_load_conservation_1256  1
    load_1_18_22  free_load_conservation_1280  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_0  arc_capacity_1081  -25
    arc_1_19_0  depot_return_or_bypass_1190  1
    arc_1_19_0  out_degree_1257  1
    arc_1_19_0  original_T_including_depot_unload_1286  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_0  arc_capacity_1081  1
    load_1_19_0  free_load_conservation_1262  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_5  arc_capacity_1082  -25
    arc_1_19_5  connected_order_arc_1083  -15
    arc_1_19_5  in_degree_1192  1
    arc_1_19_5  out_degree_1257  1
    arc_1_19_5  original_T_including_depot_unload_1286  1.0412376551742484e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_5  arc_capacity_1082  1
    load_1_19_5  segment_load_conservation_1195  -1
    load_1_19_5  segment_prefix_lb_1196  1
    load_1_19_5  segment_prefix_ub_1197  1
    load_1_19_5  free_load_conservation_1262  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_6  arc_capacity_1084  -25
    arc_1_19_6  connected_order_arc_1085  -15
    arc_1_19_6  in_degree_1199  1
    arc_1_19_6  out_degree_1257  1
    arc_1_19_6  original_T_including_depot_unload_1286  7.3287495843240220e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_6  arc_capacity_1084  1
    load_1_19_6  segment_load_conservation_1202  -1
    load_1_19_6  segment_prefix_lb_1203  1
    load_1_19_6  segment_prefix_ub_1204  1
    load_1_19_6  free_load_conservation_1262  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_7  arc_capacity_1086  -25
    arc_1_19_7  connected_order_arc_1087  -15
    arc_1_19_7  in_degree_1206  1
    arc_1_19_7  out_degree_1257  1
    arc_1_19_7  original_T_including_depot_unload_1286  3.3422575089633142e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_7  arc_capacity_1086  1
    load_1_19_7  segment_load_conservation_1209  -1
    load_1_19_7  segment_prefix_lb_1210  1
    load_1_19_7  segment_prefix_ub_1211  1
    load_1_19_7  free_load_conservation_1262  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_8  arc_capacity_1088  -25
    arc_1_19_8  connected_order_arc_1089  -15
    arc_1_19_8  in_degree_1213  1
    arc_1_19_8  out_degree_1257  1
    arc_1_19_8  original_T_including_depot_unload_1286  2.5572087458878266e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_8  arc_capacity_1088  1
    load_1_19_8  segment_load_conservation_1216  -1
    load_1_19_8  segment_prefix_lb_1217  1
    load_1_19_8  segment_prefix_ub_1218  1
    load_1_19_8  free_load_conservation_1262  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_9  arc_capacity_1090  -25
    arc_1_19_9  connected_order_arc_1091  -15
    arc_1_19_9  in_degree_1220  1
    arc_1_19_9  out_degree_1257  1
    arc_1_19_9  original_T_including_depot_unload_1286  1.6444540482789353e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_9  arc_capacity_1090  1
    load_1_19_9  segment_load_conservation_1223  -1
    load_1_19_9  segment_prefix_lb_1224  1
    load_1_19_9  segment_prefix_ub_1225  1
    load_1_19_9  free_load_conservation_1262  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_10  arc_capacity_1092  -25
    arc_1_19_10  connected_order_arc_1093  -15
    arc_1_19_10  in_degree_1227  1
    arc_1_19_10  out_degree_1257  1
    arc_1_19_10  original_T_including_depot_unload_1286  5.7102904773674652e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_10  arc_capacity_1092  1
    load_1_19_10  segment_load_conservation_1230  -1
    load_1_19_10  segment_prefix_lb_1231  1
    load_1_19_10  segment_prefix_ub_1232  1
    load_1_19_10  free_load_conservation_1262  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_15  arc_capacity_1094  -25
    arc_1_19_15  connected_order_arc_1095  -15
    arc_1_19_15  in_degree_1234  1
    arc_1_19_15  out_degree_1257  1
    arc_1_19_15  original_T_including_depot_unload_1286  8.5502565124349769e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_15  arc_capacity_1094  1
    load_1_19_15  free_load_conservation_1238  -1
    load_1_19_15  free_load_conservation_1262  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_16  arc_capacity_1096  -25
    arc_1_19_16  connected_order_arc_1097  -15
    arc_1_19_16  in_degree_1240  1
    arc_1_19_16  out_degree_1257  1
    arc_1_19_16  original_T_including_depot_unload_1286  8.1417957710766450e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_16  arc_capacity_1096  1
    load_1_19_16  free_load_conservation_1244  -1
    load_1_19_16  free_load_conservation_1262  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_17  arc_capacity_1098  -25
    arc_1_19_17  connected_order_arc_1099  -15
    arc_1_19_17  in_degree_1246  1
    arc_1_19_17  out_degree_1257  1
    arc_1_19_17  original_T_including_depot_unload_1286  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_17  arc_capacity_1098  1
    load_1_19_17  free_load_conservation_1250  -1
    load_1_19_17  free_load_conservation_1262  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_18  arc_capacity_1100  -25
    arc_1_19_18  connected_order_arc_1101  -15
    arc_1_19_18  in_degree_1252  1
    arc_1_19_18  out_degree_1257  1
    arc_1_19_18  original_T_including_depot_unload_1286  990.144803963742
    MARKER    'MARKER'                 'INTEND'
    load_1_19_18  arc_capacity_1100  1
    load_1_19_18  free_load_conservation_1256  -1
    load_1_19_18  free_load_conservation_1262  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_20  arc_capacity_1102  -25
    arc_1_19_20  connected_order_arc_1103  -15
    arc_1_19_20  out_degree_1257  1
    arc_1_19_20  in_degree_1264  1
    arc_1_19_20  original_T_including_depot_unload_1286  1.0880068546845516e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_20  arc_capacity_1102  1
    load_1_19_20  free_load_conservation_1262  1
    load_1_19_20  free_load_conservation_1268  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_21  arc_capacity_1104  -25
    arc_1_19_21  connected_order_arc_1105  -15
    arc_1_19_21  out_degree_1257  1
    arc_1_19_21  in_degree_1270  1
    arc_1_19_21  original_T_including_depot_unload_1286  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_21  arc_capacity_1104  1
    load_1_19_21  free_load_conservation_1262  1
    load_1_19_21  free_load_conservation_1274  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_22  arc_capacity_1106  -25
    arc_1_19_22  connected_order_arc_1107  -15
    arc_1_19_22  out_degree_1257  1
    arc_1_19_22  in_degree_1276  1
    arc_1_19_22  original_T_including_depot_unload_1286  9.3685967675232439e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_22  arc_capacity_1106  1
    load_1_19_22  free_load_conservation_1262  1
    load_1_19_22  free_load_conservation_1280  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_0  arc_capacity_1108  -25
    arc_1_20_0  depot_return_or_bypass_1190  1
    arc_1_20_0  out_degree_1263  1
    arc_1_20_0  original_T_including_depot_unload_1286  1.0479182987243917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_0  arc_capacity_1108  1
    load_1_20_0  free_load_conservation_1268  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_5  arc_capacity_1109  -25
    arc_1_20_5  connected_order_arc_1110  -15
    arc_1_20_5  in_degree_1192  1
    arc_1_20_5  out_degree_1263  1
    arc_1_20_5  original_T_including_depot_unload_1286  2.4155873404211835e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_5  arc_capacity_1109  1
    load_1_20_5  segment_load_conservation_1195  -1
    load_1_20_5  segment_prefix_lb_1196  1
    load_1_20_5  segment_prefix_ub_1197  1
    load_1_20_5  free_load_conservation_1268  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_6  arc_capacity_1111  -25
    arc_1_20_6  connected_order_arc_1112  -15
    arc_1_20_6  in_degree_1199  1
    arc_1_20_6  out_degree_1263  1
    arc_1_20_6  original_T_including_depot_unload_1286  1.2213551686272770e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_6  arc_capacity_1111  1
    load_1_20_6  segment_load_conservation_1202  -1
    load_1_20_6  segment_prefix_lb_1203  1
    load_1_20_6  segment_prefix_ub_1204  1
    load_1_20_6  free_load_conservation_1268  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_7  arc_capacity_1113  -25
    arc_1_20_7  connected_order_arc_1114  -15
    arc_1_20_7  in_degree_1206  1
    arc_1_20_7  out_degree_1263  1
    arc_1_20_7  original_T_including_depot_unload_1286  1.0684489086573428e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_7  arc_capacity_1113  1
    load_1_20_7  segment_load_conservation_1209  -1
    load_1_20_7  segment_prefix_lb_1210  1
    load_1_20_7  segment_prefix_ub_1211  1
    load_1_20_7  free_load_conservation_1268  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_8  arc_capacity_1115  -25
    arc_1_20_8  connected_order_arc_1116  -15
    arc_1_20_8  in_degree_1213  1
    arc_1_20_8  out_degree_1263  1
    arc_1_20_8  original_T_including_depot_unload_1286  9.9524628735690555e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_8  arc_capacity_1115  1
    load_1_20_8  segment_load_conservation_1216  -1
    load_1_20_8  segment_prefix_lb_1217  1
    load_1_20_8  segment_prefix_ub_1218  1
    load_1_20_8  free_load_conservation_1268  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_9  arc_capacity_1117  -25
    arc_1_20_9  connected_order_arc_1118  -15
    arc_1_20_9  in_degree_1220  1
    arc_1_20_9  out_degree_1263  1
    arc_1_20_9  original_T_including_depot_unload_1286  1.1592640472038677e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_9  arc_capacity_1117  1
    load_1_20_9  segment_load_conservation_1223  -1
    load_1_20_9  segment_prefix_lb_1224  1
    load_1_20_9  segment_prefix_ub_1225  1
    load_1_20_9  free_load_conservation_1268  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_10  arc_capacity_1119  -25
    arc_1_20_10  connected_order_arc_1120  -15
    arc_1_20_10  in_degree_1227  1
    arc_1_20_10  out_degree_1263  1
    arc_1_20_10  original_T_including_depot_unload_1286  9.2235470209829464e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_10  arc_capacity_1119  1
    load_1_20_10  segment_load_conservation_1230  -1
    load_1_20_10  segment_prefix_lb_1231  1
    load_1_20_10  segment_prefix_ub_1232  1
    load_1_20_10  free_load_conservation_1268  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_15  arc_capacity_1121  -25
    arc_1_20_15  connected_order_arc_1122  -15
    arc_1_20_15  in_degree_1234  1
    arc_1_20_15  out_degree_1263  1
    arc_1_20_15  original_T_including_depot_unload_1286  3.6094216796124527e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_15  arc_capacity_1121  1
    load_1_20_15  free_load_conservation_1238  -1
    load_1_20_15  free_load_conservation_1268  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_16  arc_capacity_1123  -25
    arc_1_20_16  connected_order_arc_1124  -15
    arc_1_20_16  in_degree_1240  1
    arc_1_20_16  out_degree_1263  1
    arc_1_20_16  original_T_including_depot_unload_1286  2.8747557636937808e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_16  arc_capacity_1123  1
    load_1_20_16  free_load_conservation_1244  -1
    load_1_20_16  free_load_conservation_1268  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_17  arc_capacity_1125  -25
    arc_1_20_17  connected_order_arc_1126  -15
    arc_1_20_17  in_degree_1246  1
    arc_1_20_17  out_degree_1263  1
    arc_1_20_17  original_T_including_depot_unload_1286  5.2280951376932137e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_17  arc_capacity_1125  1
    load_1_20_17  free_load_conservation_1250  -1
    load_1_20_17  free_load_conservation_1268  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_18  arc_capacity_1127  -25
    arc_1_20_18  connected_order_arc_1128  -15
    arc_1_20_18  in_degree_1252  1
    arc_1_20_18  out_degree_1263  1
    arc_1_20_18  original_T_including_depot_unload_1286  6.2793211180612207e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_18  arc_capacity_1127  1
    load_1_20_18  free_load_conservation_1256  -1
    load_1_20_18  free_load_conservation_1268  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_19  arc_capacity_1129  -25
    arc_1_20_19  connected_order_arc_1130  -15
    arc_1_20_19  in_degree_1258  1
    arc_1_20_19  out_degree_1263  1
    arc_1_20_19  original_T_including_depot_unload_1286  1.0880068546845516e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_19  arc_capacity_1129  1
    load_1_20_19  free_load_conservation_1262  -1
    load_1_20_19  free_load_conservation_1268  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_21  arc_capacity_1131  -25
    arc_1_20_21  connected_order_arc_1132  -15
    arc_1_20_21  out_degree_1263  1
    arc_1_20_21  in_degree_1270  1
    arc_1_20_21  original_T_including_depot_unload_1286  1.7883808204567979e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_21  arc_capacity_1131  1
    load_1_20_21  free_load_conservation_1268  1
    load_1_20_21  free_load_conservation_1274  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_22  arc_capacity_1133  -25
    arc_1_20_22  connected_order_arc_1134  -15
    arc_1_20_22  out_degree_1263  1
    arc_1_20_22  in_degree_1276  1
    arc_1_20_22  original_T_including_depot_unload_1286  8.0531033344008677e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_22  arc_capacity_1133  1
    load_1_20_22  free_load_conservation_1268  1
    load_1_20_22  free_load_conservation_1280  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_0  arc_capacity_1135  -25
    arc_1_21_0  depot_return_or_bypass_1190  1
    arc_1_21_0  out_degree_1269  1
    arc_1_21_0  original_T_including_depot_unload_1286  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_0  arc_capacity_1135  1
    load_1_21_0  free_load_conservation_1274  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_5  arc_capacity_1136  -25
    arc_1_21_5  connected_order_arc_1137  -15
    arc_1_21_5  in_degree_1192  1
    arc_1_21_5  out_degree_1269  1
    arc_1_21_5  original_T_including_depot_unload_1286  1.5502221880497036e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_5  arc_capacity_1136  1
    load_1_21_5  segment_load_conservation_1195  -1
    load_1_21_5  segment_prefix_lb_1196  1
    load_1_21_5  segment_prefix_ub_1197  1
    load_1_21_5  free_load_conservation_1274  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_6  arc_capacity_1138  -25
    arc_1_21_6  connected_order_arc_1139  -15
    arc_1_21_6  in_degree_1199  1
    arc_1_21_6  out_degree_1269  1
    arc_1_21_6  original_T_including_depot_unload_1286  2.5950001064050621e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_6  arc_capacity_1138  1
    load_1_21_6  segment_load_conservation_1202  -1
    load_1_21_6  segment_prefix_lb_1203  1
    load_1_21_6  segment_prefix_ub_1204  1
    load_1_21_6  free_load_conservation_1274  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_7  arc_capacity_1140  -25
    arc_1_21_7  connected_order_arc_1141  -15
    arc_1_21_7  in_degree_1206  1
    arc_1_21_7  out_degree_1269  1
    arc_1_21_7  original_T_including_depot_unload_1286  2226.1143218952
    MARKER    'MARKER'                 'INTEND'
    load_1_21_7  arc_capacity_1140  1
    load_1_21_7  segment_load_conservation_1209  -1
    load_1_21_7  segment_prefix_lb_1210  1
    load_1_21_7  segment_prefix_ub_1211  1
    load_1_21_7  free_load_conservation_1274  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_8  arc_capacity_1142  -25
    arc_1_21_8  connected_order_arc_1143  -15
    arc_1_21_8  in_degree_1213  1
    arc_1_21_8  out_degree_1269  1
    arc_1_21_8  original_T_including_depot_unload_1286  2115.53677476792
    MARKER    'MARKER'                 'INTEND'
    load_1_21_8  arc_capacity_1142  1
    load_1_21_8  segment_load_conservation_1216  -1
    load_1_21_8  segment_prefix_lb_1217  1
    load_1_21_8  segment_prefix_ub_1218  1
    load_1_21_8  free_load_conservation_1274  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_9  arc_capacity_1144  -25
    arc_1_21_9  connected_order_arc_1145  -15
    arc_1_21_9  in_degree_1220  1
    arc_1_21_9  out_degree_1269  1
    arc_1_21_9  original_T_including_depot_unload_1286  1.8418804985785646e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_9  arc_capacity_1144  1
    load_1_21_9  segment_load_conservation_1223  -1
    load_1_21_9  segment_prefix_lb_1224  1
    load_1_21_9  segment_prefix_ub_1225  1
    load_1_21_9  free_load_conservation_1274  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_10  arc_capacity_1146  -25
    arc_1_21_10  connected_order_arc_1147  -15
    arc_1_21_10  in_degree_1227  1
    arc_1_21_10  out_degree_1269  1
    arc_1_21_10  original_T_including_depot_unload_1286  1.3857128117205509e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_10  arc_capacity_1146  1
    load_1_21_10  segment_load_conservation_1230  -1
    load_1_21_10  segment_prefix_lb_1231  1
    load_1_21_10  segment_prefix_ub_1232  1
    load_1_21_10  free_load_conservation_1274  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_15  arc_capacity_1148  -25
    arc_1_21_15  connected_order_arc_1149  -15
    arc_1_21_15  in_degree_1234  1
    arc_1_21_15  out_degree_1269  1
    arc_1_21_15  original_T_including_depot_unload_1286  2.0104743468619281e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_15  arc_capacity_1148  1
    load_1_21_15  free_load_conservation_1238  -1
    load_1_21_15  free_load_conservation_1274  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_16  arc_capacity_1150  -25
    arc_1_21_16  connected_order_arc_1151  -15
    arc_1_21_16  in_degree_1240  1
    arc_1_21_16  out_degree_1269  1
    arc_1_21_16  original_T_including_depot_unload_1286  1.8442669473423912e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_16  arc_capacity_1150  1
    load_1_21_16  free_load_conservation_1244  -1
    load_1_21_16  free_load_conservation_1274  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_17  arc_capacity_1152  -25
    arc_1_21_17  connected_order_arc_1153  -15
    arc_1_21_17  in_degree_1246  1
    arc_1_21_17  out_degree_1269  1
    arc_1_21_17  original_T_including_depot_unload_1286  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_17  arc_capacity_1152  1
    load_1_21_17  free_load_conservation_1250  -1
    load_1_21_17  free_load_conservation_1274  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_18  arc_capacity_1154  -25
    arc_1_21_18  connected_order_arc_1155  -15
    arc_1_21_18  in_degree_1252  1
    arc_1_21_18  out_degree_1269  1
    arc_1_21_18  original_T_including_depot_unload_1286  2.3332890980657526e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_18  arc_capacity_1154  1
    load_1_21_18  free_load_conservation_1256  -1
    load_1_21_18  free_load_conservation_1274  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_19  arc_capacity_1156  -25
    arc_1_21_19  connected_order_arc_1157  -15
    arc_1_21_19  in_degree_1258  1
    arc_1_21_19  out_degree_1269  1
    arc_1_21_19  original_T_including_depot_unload_1286  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_19  arc_capacity_1156  1
    load_1_21_19  free_load_conservation_1262  -1
    load_1_21_19  free_load_conservation_1274  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_20  arc_capacity_1158  -25
    arc_1_21_20  connected_order_arc_1159  -15
    arc_1_21_20  in_degree_1264  1
    arc_1_21_20  out_degree_1269  1
    arc_1_21_20  original_T_including_depot_unload_1286  1.7883808204567979e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_20  arc_capacity_1158  1
    load_1_21_20  free_load_conservation_1268  -1
    load_1_21_20  free_load_conservation_1274  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_22  arc_capacity_1160  -25
    arc_1_21_22  connected_order_arc_1161  -15
    arc_1_21_22  out_degree_1269  1
    arc_1_21_22  in_degree_1276  1
    arc_1_21_22  original_T_including_depot_unload_1286  2.4500766064196278e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_22  arc_capacity_1160  1
    load_1_21_22  free_load_conservation_1274  1
    load_1_21_22  free_load_conservation_1280  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_0  arc_capacity_1162  -25
    arc_1_22_0  depot_return_or_bypass_1190  1
    arc_1_22_0  out_degree_1275  1
    arc_1_22_0  original_T_including_depot_unload_1286  1.3076700111397606e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_22_0  arc_capacity_1162  1
    load_1_22_0  free_load_conservation_1280  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_5  arc_capacity_1163  -25
    arc_1_22_5  connected_order_arc_1164  -15
    arc_1_22_5  in_degree_1192  1
    arc_1_22_5  out_degree_1275  1
    arc_1_22_5  original_T_including_depot_unload_1286  9.7692852841087415e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_5  arc_capacity_1163  1
    load_1_22_5  segment_load_conservation_1195  -1
    load_1_22_5  segment_prefix_lb_1196  1
    load_1_22_5  segment_prefix_ub_1197  1
    load_1_22_5  free_load_conservation_1280  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_6  arc_capacity_1165  -25
    arc_1_22_6  connected_order_arc_1166  -15
    arc_1_22_6  in_degree_1199  1
    arc_1_22_6  out_degree_1275  1
    arc_1_22_6  original_T_including_depot_unload_1286  5.4630148713373910e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_6  arc_capacity_1165  1
    load_1_22_6  segment_load_conservation_1202  -1
    load_1_22_6  segment_prefix_lb_1203  1
    load_1_22_6  segment_prefix_ub_1204  1
    load_1_22_6  free_load_conservation_1280  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_7  arc_capacity_1167  -25
    arc_1_22_7  connected_order_arc_1168  -15
    arc_1_22_7  in_degree_1206  1
    arc_1_22_7  out_degree_1275  1
    arc_1_22_7  original_T_including_depot_unload_1286  6.7554763364087285e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_7  arc_capacity_1167  1
    load_1_22_7  segment_load_conservation_1209  -1
    load_1_22_7  segment_prefix_lb_1210  1
    load_1_22_7  segment_prefix_ub_1211  1
    load_1_22_7  free_load_conservation_1280  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_8  arc_capacity_1169  -25
    arc_1_22_8  connected_order_arc_1170  -15
    arc_1_22_8  in_degree_1213  1
    arc_1_22_8  out_degree_1275  1
    arc_1_22_8  original_T_including_depot_unload_1286  6.9492720147205364e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_8  arc_capacity_1169  1
    load_1_22_8  segment_load_conservation_1216  -1
    load_1_22_8  segment_prefix_lb_1217  1
    load_1_22_8  segment_prefix_ub_1218  1
    load_1_22_8  free_load_conservation_1280  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_9  arc_capacity_1171  -25
    arc_1_22_9  connected_order_arc_1172  -15
    arc_1_22_9  in_degree_1220  1
    arc_1_22_9  out_degree_1275  1
    arc_1_22_9  original_T_including_depot_unload_1286  1.0910343836035740e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_22_9  arc_capacity_1171  1
    load_1_22_9  segment_load_conservation_1223  -1
    load_1_22_9  segment_prefix_lb_1224  1
    load_1_22_9  segment_prefix_ub_1225  1
    load_1_22_9  free_load_conservation_1280  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_10  arc_capacity_1173  -25
    arc_1_22_10  connected_order_arc_1174  -15
    arc_1_22_10  in_degree_1227  1
    arc_1_22_10  out_degree_1275  1
    arc_1_22_10  original_T_including_depot_unload_1286  1.2100678255370710e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_22_10  arc_capacity_1173  1
    load_1_22_10  segment_load_conservation_1230  -1
    load_1_22_10  segment_prefix_lb_1231  1
    load_1_22_10  segment_prefix_ub_1232  1
    load_1_22_10  free_load_conservation_1280  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_15  arc_capacity_1175  -25
    arc_1_22_15  connected_order_arc_1176  -15
    arc_1_22_15  in_degree_1234  1
    arc_1_22_15  out_degree_1275  1
    arc_1_22_15  original_T_including_depot_unload_1286  4.6588884124393707e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_15  arc_capacity_1175  1
    load_1_22_15  free_load_conservation_1238  -1
    load_1_22_15  free_load_conservation_1280  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_16  arc_capacity_1177  -25
    arc_1_22_16  connected_order_arc_1178  -15
    arc_1_22_16  in_degree_1240  1
    arc_1_22_16  out_degree_1275  1
    arc_1_22_16  original_T_including_depot_unload_1286  6.2102815646279714e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_16  arc_capacity_1177  1
    load_1_22_16  free_load_conservation_1244  -1
    load_1_22_16  free_load_conservation_1280  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_17  arc_capacity_1179  -25
    arc_1_22_17  connected_order_arc_1180  -15
    arc_1_22_17  in_degree_1246  1
    arc_1_22_17  out_degree_1275  1
    arc_1_22_17  original_T_including_depot_unload_1286  1.3218357148919101e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_22_17  arc_capacity_1179  1
    load_1_22_17  free_load_conservation_1250  -1
    load_1_22_17  free_load_conservation_1280  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_18  arc_capacity_1181  -25
    arc_1_22_18  connected_order_arc_1182  -15
    arc_1_22_18  in_degree_1252  1
    arc_1_22_18  out_degree_1275  1
    arc_1_22_18  original_T_including_depot_unload_1286  1.9785969874636677e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_18  arc_capacity_1181  1
    load_1_22_18  free_load_conservation_1256  -1
    load_1_22_18  free_load_conservation_1280  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_19  arc_capacity_1183  -25
    arc_1_22_19  connected_order_arc_1184  -15
    arc_1_22_19  in_degree_1258  1
    arc_1_22_19  out_degree_1275  1
    arc_1_22_19  original_T_including_depot_unload_1286  9.3685967675232439e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_19  arc_capacity_1183  1
    load_1_22_19  free_load_conservation_1262  -1
    load_1_22_19  free_load_conservation_1280  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_20  arc_capacity_1185  -25
    arc_1_22_20  connected_order_arc_1186  -15
    arc_1_22_20  in_degree_1264  1
    arc_1_22_20  out_degree_1275  1
    arc_1_22_20  original_T_including_depot_unload_1286  8.0531033344008677e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_20  arc_capacity_1185  1
    load_1_22_20  free_load_conservation_1268  -1
    load_1_22_20  free_load_conservation_1280  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_21  arc_capacity_1187  -25
    arc_1_22_21  connected_order_arc_1188  -15
    arc_1_22_21  in_degree_1270  1
    arc_1_22_21  out_degree_1275  1
    arc_1_22_21  original_T_including_depot_unload_1286  2.4500766064196278e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_22_21  arc_capacity_1187  1
    load_1_22_21  free_load_conservation_1274  -1
    load_1_22_21  free_load_conservation_1280  1
    visit_2_11  out_degree_1578  -1
    visit_2_11  in_degree_1579  -1
    visit_2_11  order_active_lb_1580  -1
    visit_2_11  order_active_ub_1581  -12
    order_2_11  connected_order_arc_1302  -1
    order_2_11  connected_order_arc_1304  -1
    order_2_11  connected_order_arc_1306  -1
    order_2_11  connected_order_arc_1308  -1
    order_2_11  connected_order_arc_1310  -1
    order_2_11  connected_order_arc_1312  -1
    order_2_11  connected_order_arc_1314  -1
    order_2_11  connected_order_arc_1316  -1
    order_2_11  connected_order_arc_1318  -1
    order_2_11  connected_order_arc_1320  -1
    order_2_11  connected_order_arc_1322  -1
    order_2_11  connected_order_arc_1325  1
    order_2_11  connected_order_arc_1348  1
    order_2_11  connected_order_arc_1371  1
    order_2_11  connected_order_arc_1394  1
    order_2_11  connected_order_arc_1417  1
    order_2_11  connected_order_arc_1440  1
    order_2_11  connected_order_arc_1463  1
    order_2_11  connected_order_arc_1486  1
    order_2_11  connected_order_arc_1509  1
    order_2_11  connected_order_arc_1532  1
    order_2_11  connected_order_arc_1555  1
    order_2_11  order_active_lb_1580  1
    order_2_11  order_active_ub_1581  1
    order_2_11  fixed_segment_relative_order_1654  -1
    visit_2_12  out_degree_1585  -1
    visit_2_12  in_degree_1586  -1
    visit_2_12  order_active_lb_1587  -1
    visit_2_12  order_active_ub_1588  -12
    order_2_12  connected_order_arc_1302  1
    order_2_12  connected_order_arc_1325  -1
    order_2_12  connected_order_arc_1327  -1
    order_2_12  connected_order_arc_1329  -1
    order_2_12  connected_order_arc_1331  -1
    order_2_12  connected_order_arc_1333  -1
    order_2_12  connected_order_arc_1335  -1
    order_2_12  connected_order_arc_1337  -1
    order_2_12  connected_order_arc_1339  -1
    order_2_12  connected_order_arc_1341  -1
    order_2_12  connected_order_arc_1343  -1
    order_2_12  connected_order_arc_1345  -1
    order_2_12  connected_order_arc_1350  1
    order_2_12  connected_order_arc_1373  1
    order_2_12  connected_order_arc_1396  1
    order_2_12  connected_order_arc_1419  1
    order_2_12  connected_order_arc_1442  1
    order_2_12  connected_order_arc_1465  1
    order_2_12  connected_order_arc_1488  1
    order_2_12  connected_order_arc_1511  1
    order_2_12  connected_order_arc_1534  1
    order_2_12  connected_order_arc_1557  1
    order_2_12  order_active_lb_1587  1
    order_2_12  order_active_ub_1588  1
    order_2_12  fixed_segment_relative_order_1654  1
    order_2_12  fixed_segment_relative_order_1655  -1
    visit_2_13  out_degree_1592  -1
    visit_2_13  in_degree_1593  -1
    visit_2_13  order_active_lb_1594  -1
    visit_2_13  order_active_ub_1595  -12
    order_2_13  connected_order_arc_1304  1
    order_2_13  connected_order_arc_1327  1
    order_2_13  connected_order_arc_1348  -1
    order_2_13  connected_order_arc_1350  -1
    order_2_13  connected_order_arc_1352  -1
    order_2_13  connected_order_arc_1354  -1
    order_2_13  connected_order_arc_1356  -1
    order_2_13  connected_order_arc_1358  -1
    order_2_13  connected_order_arc_1360  -1
    order_2_13  connected_order_arc_1362  -1
    order_2_13  connected_order_arc_1364  -1
    order_2_13  connected_order_arc_1366  -1
    order_2_13  connected_order_arc_1368  -1
    order_2_13  connected_order_arc_1375  1
    order_2_13  connected_order_arc_1398  1
    order_2_13  connected_order_arc_1421  1
    order_2_13  connected_order_arc_1444  1
    order_2_13  connected_order_arc_1467  1
    order_2_13  connected_order_arc_1490  1
    order_2_13  connected_order_arc_1513  1
    order_2_13  connected_order_arc_1536  1
    order_2_13  connected_order_arc_1559  1
    order_2_13  order_active_lb_1594  1
    order_2_13  order_active_ub_1595  1
    order_2_13  fixed_segment_relative_order_1655  1
    order_2_13  fixed_segment_relative_order_1656  -1
    visit_2_14  out_degree_1599  -1
    visit_2_14  in_degree_1600  -1
    visit_2_14  order_active_lb_1601  -1
    visit_2_14  order_active_ub_1602  -12
    order_2_14  connected_order_arc_1306  1
    order_2_14  connected_order_arc_1329  1
    order_2_14  connected_order_arc_1352  1
    order_2_14  connected_order_arc_1371  -1
    order_2_14  connected_order_arc_1373  -1
    order_2_14  connected_order_arc_1375  -1
    order_2_14  connected_order_arc_1377  -1
    order_2_14  connected_order_arc_1379  -1
    order_2_14  connected_order_arc_1381  -1
    order_2_14  connected_order_arc_1383  -1
    order_2_14  connected_order_arc_1385  -1
    order_2_14  connected_order_arc_1387  -1
    order_2_14  connected_order_arc_1389  -1
    order_2_14  connected_order_arc_1391  -1
    order_2_14  connected_order_arc_1400  1
    order_2_14  connected_order_arc_1423  1
    order_2_14  connected_order_arc_1446  1
    order_2_14  connected_order_arc_1469  1
    order_2_14  connected_order_arc_1492  1
    order_2_14  connected_order_arc_1515  1
    order_2_14  connected_order_arc_1538  1
    order_2_14  connected_order_arc_1561  1
    order_2_14  order_active_lb_1601  1
    order_2_14  order_active_ub_1602  1
    order_2_14  fixed_segment_relative_order_1656  1
    visit_2_15  out_degree_1606  -1
    visit_2_15  in_degree_1607  -1
    visit_2_15  order_active_lb_1608  -1
    visit_2_15  order_active_ub_1609  -12
    visit_2_15  service_visit_def_1610  -1
    order_2_15  connected_order_arc_1308  1
    order_2_15  connected_order_arc_1331  1
    order_2_15  connected_order_arc_1354  1
    order_2_15  connected_order_arc_1377  1
    order_2_15  connected_order_arc_1394  -1
    order_2_15  connected_order_arc_1396  -1
    order_2_15  connected_order_arc_1398  -1
    order_2_15  connected_order_arc_1400  -1
    order_2_15  connected_order_arc_1402  -1
    order_2_15  connected_order_arc_1404  -1
    order_2_15  connected_order_arc_1406  -1
    order_2_15  connected_order_arc_1408  -1
    order_2_15  connected_order_arc_1410  -1
    order_2_15  connected_order_arc_1412  -1
    order_2_15  connected_order_arc_1414  -1
    order_2_15  connected_order_arc_1425  1
    order_2_15  connected_order_arc_1448  1
    order_2_15  connected_order_arc_1471  1
    order_2_15  connected_order_arc_1494  1
    order_2_15  connected_order_arc_1517  1
    order_2_15  connected_order_arc_1540  1
    order_2_15  connected_order_arc_1563  1
    order_2_15  order_active_lb_1608  1
    order_2_15  order_active_ub_1609  1
    visit_2_16  out_degree_1612  -1
    visit_2_16  in_degree_1613  -1
    visit_2_16  order_active_lb_1614  -1
    visit_2_16  order_active_ub_1615  -12
    visit_2_16  service_visit_def_1616  -1
    order_2_16  connected_order_arc_1310  1
    order_2_16  connected_order_arc_1333  1
    order_2_16  connected_order_arc_1356  1
    order_2_16  connected_order_arc_1379  1
    order_2_16  connected_order_arc_1402  1
    order_2_16  connected_order_arc_1417  -1
    order_2_16  connected_order_arc_1419  -1
    order_2_16  connected_order_arc_1421  -1
    order_2_16  connected_order_arc_1423  -1
    order_2_16  connected_order_arc_1425  -1
    order_2_16  connected_order_arc_1427  -1
    order_2_16  connected_order_arc_1429  -1
    order_2_16  connected_order_arc_1431  -1
    order_2_16  connected_order_arc_1433  -1
    order_2_16  connected_order_arc_1435  -1
    order_2_16  connected_order_arc_1437  -1
    order_2_16  connected_order_arc_1450  1
    order_2_16  connected_order_arc_1473  1
    order_2_16  connected_order_arc_1496  1
    order_2_16  connected_order_arc_1519  1
    order_2_16  connected_order_arc_1542  1
    order_2_16  connected_order_arc_1565  1
    order_2_16  order_active_lb_1614  1
    order_2_16  order_active_ub_1615  1
    visit_2_17  out_degree_1618  -1
    visit_2_17  in_degree_1619  -1
    visit_2_17  order_active_lb_1620  -1
    visit_2_17  order_active_ub_1621  -12
    visit_2_17  service_visit_def_1622  -1
    order_2_17  connected_order_arc_1312  1
    order_2_17  connected_order_arc_1335  1
    order_2_17  connected_order_arc_1358  1
    order_2_17  connected_order_arc_1381  1
    order_2_17  connected_order_arc_1404  1
    order_2_17  connected_order_arc_1427  1
    order_2_17  connected_order_arc_1440  -1
    order_2_17  connected_order_arc_1442  -1
    order_2_17  connected_order_arc_1444  -1
    order_2_17  connected_order_arc_1446  -1
    order_2_17  connected_order_arc_1448  -1
    order_2_17  connected_order_arc_1450  -1
    order_2_17  connected_order_arc_1452  -1
    order_2_17  connected_order_arc_1454  -1
    order_2_17  connected_order_arc_1456  -1
    order_2_17  connected_order_arc_1458  -1
    order_2_17  connected_order_arc_1460  -1
    order_2_17  connected_order_arc_1475  1
    order_2_17  connected_order_arc_1498  1
    order_2_17  connected_order_arc_1521  1
    order_2_17  connected_order_arc_1544  1
    order_2_17  connected_order_arc_1567  1
    order_2_17  order_active_lb_1620  1
    order_2_17  order_active_ub_1621  1
    visit_2_18  out_degree_1624  -1
    visit_2_18  in_degree_1625  -1
    visit_2_18  order_active_lb_1626  -1
    visit_2_18  order_active_ub_1627  -12
    visit_2_18  service_visit_def_1628  -1
    order_2_18  connected_order_arc_1314  1
    order_2_18  connected_order_arc_1337  1
    order_2_18  connected_order_arc_1360  1
    order_2_18  connected_order_arc_1383  1
    order_2_18  connected_order_arc_1406  1
    order_2_18  connected_order_arc_1429  1
    order_2_18  connected_order_arc_1452  1
    order_2_18  connected_order_arc_1463  -1
    order_2_18  connected_order_arc_1465  -1
    order_2_18  connected_order_arc_1467  -1
    order_2_18  connected_order_arc_1469  -1
    order_2_18  connected_order_arc_1471  -1
    order_2_18  connected_order_arc_1473  -1
    order_2_18  connected_order_arc_1475  -1
    order_2_18  connected_order_arc_1477  -1
    order_2_18  connected_order_arc_1479  -1
    order_2_18  connected_order_arc_1481  -1
    order_2_18  connected_order_arc_1483  -1
    order_2_18  connected_order_arc_1500  1
    order_2_18  connected_order_arc_1523  1
    order_2_18  connected_order_arc_1546  1
    order_2_18  connected_order_arc_1569  1
    order_2_18  order_active_lb_1626  1
    order_2_18  order_active_ub_1627  1
    visit_2_19  out_degree_1630  -1
    visit_2_19  in_degree_1631  -1
    visit_2_19  order_active_lb_1632  -1
    visit_2_19  order_active_ub_1633  -12
    visit_2_19  service_visit_def_1634  -1
    order_2_19  connected_order_arc_1316  1
    order_2_19  connected_order_arc_1339  1
    order_2_19  connected_order_arc_1362  1
    order_2_19  connected_order_arc_1385  1
    order_2_19  connected_order_arc_1408  1
    order_2_19  connected_order_arc_1431  1
    order_2_19  connected_order_arc_1454  1
    order_2_19  connected_order_arc_1477  1
    order_2_19  connected_order_arc_1486  -1
    order_2_19  connected_order_arc_1488  -1
    order_2_19  connected_order_arc_1490  -1
    order_2_19  connected_order_arc_1492  -1
    order_2_19  connected_order_arc_1494  -1
    order_2_19  connected_order_arc_1496  -1
    order_2_19  connected_order_arc_1498  -1
    order_2_19  connected_order_arc_1500  -1
    order_2_19  connected_order_arc_1502  -1
    order_2_19  connected_order_arc_1504  -1
    order_2_19  connected_order_arc_1506  -1
    order_2_19  connected_order_arc_1525  1
    order_2_19  connected_order_arc_1548  1
    order_2_19  connected_order_arc_1571  1
    order_2_19  order_active_lb_1632  1
    order_2_19  order_active_ub_1633  1
    visit_2_20  out_degree_1636  -1
    visit_2_20  in_degree_1637  -1
    visit_2_20  order_active_lb_1638  -1
    visit_2_20  order_active_ub_1639  -12
    visit_2_20  service_visit_def_1640  -1
    order_2_20  connected_order_arc_1318  1
    order_2_20  connected_order_arc_1341  1
    order_2_20  connected_order_arc_1364  1
    order_2_20  connected_order_arc_1387  1
    order_2_20  connected_order_arc_1410  1
    order_2_20  connected_order_arc_1433  1
    order_2_20  connected_order_arc_1456  1
    order_2_20  connected_order_arc_1479  1
    order_2_20  connected_order_arc_1502  1
    order_2_20  connected_order_arc_1509  -1
    order_2_20  connected_order_arc_1511  -1
    order_2_20  connected_order_arc_1513  -1
    order_2_20  connected_order_arc_1515  -1
    order_2_20  connected_order_arc_1517  -1
    order_2_20  connected_order_arc_1519  -1
    order_2_20  connected_order_arc_1521  -1
    order_2_20  connected_order_arc_1523  -1
    order_2_20  connected_order_arc_1525  -1
    order_2_20  connected_order_arc_1527  -1
    order_2_20  connected_order_arc_1529  -1
    order_2_20  connected_order_arc_1550  1
    order_2_20  connected_order_arc_1573  1
    order_2_20  order_active_lb_1638  1
    order_2_20  order_active_ub_1639  1
    visit_2_21  out_degree_1642  -1
    visit_2_21  in_degree_1643  -1
    visit_2_21  order_active_lb_1644  -1
    visit_2_21  order_active_ub_1645  -12
    visit_2_21  service_visit_def_1646  -1
    order_2_21  connected_order_arc_1320  1
    order_2_21  connected_order_arc_1343  1
    order_2_21  connected_order_arc_1366  1
    order_2_21  connected_order_arc_1389  1
    order_2_21  connected_order_arc_1412  1
    order_2_21  connected_order_arc_1435  1
    order_2_21  connected_order_arc_1458  1
    order_2_21  connected_order_arc_1481  1
    order_2_21  connected_order_arc_1504  1
    order_2_21  connected_order_arc_1527  1
    order_2_21  connected_order_arc_1532  -1
    order_2_21  connected_order_arc_1534  -1
    order_2_21  connected_order_arc_1536  -1
    order_2_21  connected_order_arc_1538  -1
    order_2_21  connected_order_arc_1540  -1
    order_2_21  connected_order_arc_1542  -1
    order_2_21  connected_order_arc_1544  -1
    order_2_21  connected_order_arc_1546  -1
    order_2_21  connected_order_arc_1548  -1
    order_2_21  connected_order_arc_1550  -1
    order_2_21  connected_order_arc_1552  -1
    order_2_21  connected_order_arc_1575  1
    order_2_21  order_active_lb_1644  1
    order_2_21  order_active_ub_1645  1
    visit_2_22  out_degree_1648  -1
    visit_2_22  in_degree_1649  -1
    visit_2_22  order_active_lb_1650  -1
    visit_2_22  order_active_ub_1651  -12
    visit_2_22  service_visit_def_1652  -1
    order_2_22  connected_order_arc_1322  1
    order_2_22  connected_order_arc_1345  1
    order_2_22  connected_order_arc_1368  1
    order_2_22  connected_order_arc_1391  1
    order_2_22  connected_order_arc_1414  1
    order_2_22  connected_order_arc_1437  1
    order_2_22  connected_order_arc_1460  1
    order_2_22  connected_order_arc_1483  1
    order_2_22  connected_order_arc_1506  1
    order_2_22  connected_order_arc_1529  1
    order_2_22  connected_order_arc_1552  1
    order_2_22  connected_order_arc_1555  -1
    order_2_22  connected_order_arc_1557  -1
    order_2_22  connected_order_arc_1559  -1
    order_2_22  connected_order_arc_1561  -1
    order_2_22  connected_order_arc_1563  -1
    order_2_22  connected_order_arc_1565  -1
    order_2_22  connected_order_arc_1567  -1
    order_2_22  connected_order_arc_1569  -1
    order_2_22  connected_order_arc_1571  -1
    order_2_22  connected_order_arc_1573  -1
    order_2_22  connected_order_arc_1575  -1
    order_2_22  order_active_lb_1650  1
    order_2_22  order_active_ub_1651  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_0  arc_capacity_1287  -30
    arc_2_0_0  depot_departure_or_bypass_1576  1
    arc_2_0_0  depot_return_or_bypass_1577  1
    MARKER    'MARKER'                 'INTEND'
    load_2_0_0  arc_capacity_1287  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_11  arc_capacity_1288  -30
    arc_2_0_11  depot_departure_or_bypass_1576  1
    arc_2_0_11  in_degree_1579  1
    arc_2_0_11  original_T_including_depot_unload_1657  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_11  arc_capacity_1288  1
    load_2_0_11  segment_load_conservation_1582  -1
    load_2_0_11  segment_prefix_lb_1583  1
    load_2_0_11  segment_prefix_ub_1584  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_12  arc_capacity_1289  -30
    arc_2_0_12  depot_departure_or_bypass_1576  1
    arc_2_0_12  in_degree_1586  1
    arc_2_0_12  original_T_including_depot_unload_1657  1.4567038050199781e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_12  arc_capacity_1289  1
    load_2_0_12  segment_load_conservation_1589  -1
    load_2_0_12  segment_prefix_lb_1590  1
    load_2_0_12  segment_prefix_ub_1591  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_13  arc_capacity_1290  -30
    arc_2_0_13  depot_departure_or_bypass_1576  1
    arc_2_0_13  in_degree_1593  1
    arc_2_0_13  original_T_including_depot_unload_1657  1.2506062209426416e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_13  arc_capacity_1290  1
    load_2_0_13  segment_load_conservation_1596  -1
    load_2_0_13  segment_prefix_lb_1597  1
    load_2_0_13  segment_prefix_ub_1598  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_14  arc_capacity_1291  -30
    arc_2_0_14  depot_departure_or_bypass_1576  1
    arc_2_0_14  in_degree_1600  1
    arc_2_0_14  original_T_including_depot_unload_1657  1.4501558573355060e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_14  arc_capacity_1291  1
    load_2_0_14  segment_load_conservation_1603  -1
    load_2_0_14  segment_prefix_lb_1604  1
    load_2_0_14  segment_prefix_ub_1605  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_15  arc_capacity_1292  -30
    arc_2_0_15  depot_departure_or_bypass_1576  1
    arc_2_0_15  in_degree_1607  1
    arc_2_0_15  original_T_including_depot_unload_1657  1.0088905112952611e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_15  arc_capacity_1292  1
    load_2_0_15  free_load_conservation_1611  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_16  arc_capacity_1293  -30
    arc_2_0_16  depot_departure_or_bypass_1576  1
    arc_2_0_16  in_degree_1613  1
    arc_2_0_16  original_T_including_depot_unload_1657  8.7749189782983967e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_16  arc_capacity_1293  1
    load_2_0_16  free_load_conservation_1617  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_17  arc_capacity_1294  -30
    arc_2_0_17  depot_departure_or_bypass_1576  1
    arc_2_0_17  in_degree_1619  1
    arc_2_0_17  original_T_including_depot_unload_1657  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_17  arc_capacity_1294  1
    load_2_0_17  free_load_conservation_1623  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_18  arc_capacity_1295  -30
    arc_2_0_18  depot_departure_or_bypass_1576  1
    arc_2_0_18  in_degree_1625  1
    arc_2_0_18  original_T_including_depot_unload_1657  1.2751323166566442e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_18  arc_capacity_1295  1
    load_2_0_18  free_load_conservation_1629  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_19  arc_capacity_1296  -30
    arc_2_0_19  depot_departure_or_bypass_1576  1
    arc_2_0_19  in_degree_1631  1
    arc_2_0_19  original_T_including_depot_unload_1657  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_19  arc_capacity_1296  1
    load_2_0_19  free_load_conservation_1635  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_20  arc_capacity_1297  -30
    arc_2_0_20  depot_departure_or_bypass_1576  1
    arc_2_0_20  in_degree_1637  1
    arc_2_0_20  original_T_including_depot_unload_1657  1.0479182987243917e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_20  arc_capacity_1297  1
    load_2_0_20  free_load_conservation_1641  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_21  arc_capacity_1298  -30
    arc_2_0_21  depot_departure_or_bypass_1576  1
    arc_2_0_21  in_degree_1643  1
    arc_2_0_21  original_T_including_depot_unload_1657  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_21  arc_capacity_1298  1
    load_2_0_21  free_load_conservation_1647  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_22  arc_capacity_1299  -30
    arc_2_0_22  depot_departure_or_bypass_1576  1
    arc_2_0_22  in_degree_1649  1
    arc_2_0_22  original_T_including_depot_unload_1657  1.3076700111397606e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_22  arc_capacity_1299  1
    load_2_0_22  free_load_conservation_1653  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_0  arc_capacity_1300  -30
    arc_2_11_0  depot_return_or_bypass_1577  1
    arc_2_11_0  out_degree_1578  1
    arc_2_11_0  original_T_including_depot_unload_1657  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_0  arc_capacity_1300  1
    load_2_11_0  segment_load_conservation_1582  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_12  arc_capacity_1301  -30
    arc_2_11_12  connected_order_arc_1302  -13
    arc_2_11_12  out_degree_1578  1
    arc_2_11_12  in_degree_1586  1
    arc_2_11_12  original_T_including_depot_unload_1657  1.2835993572680911e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_12  arc_capacity_1301  1
    load_2_11_12  segment_load_conservation_1582  1
    load_2_11_12  segment_load_conservation_1589  -1
    load_2_11_12  segment_prefix_lb_1590  1
    load_2_11_12  segment_prefix_ub_1591  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_13  arc_capacity_1303  -30
    arc_2_11_13  connected_order_arc_1304  -13
    arc_2_11_13  out_degree_1578  1
    arc_2_11_13  in_degree_1593  1
    arc_2_11_13  original_T_including_depot_unload_1657  1.0138993437494995e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_13  arc_capacity_1303  1
    load_2_11_13  segment_load_conservation_1582  1
    load_2_11_13  segment_load_conservation_1596  -1
    load_2_11_13  segment_prefix_lb_1597  1
    load_2_11_13  segment_prefix_ub_1598  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_14  arc_capacity_1305  -30
    arc_2_11_14  connected_order_arc_1306  -13
    arc_2_11_14  out_degree_1578  1
    arc_2_11_14  in_degree_1600  1
    arc_2_11_14  original_T_including_depot_unload_1657  1.2946770575314561e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_14  arc_capacity_1305  1
    load_2_11_14  segment_load_conservation_1582  1
    load_2_11_14  segment_load_conservation_1603  -1
    load_2_11_14  segment_prefix_lb_1604  1
    load_2_11_14  segment_prefix_ub_1605  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_15  arc_capacity_1307  -30
    arc_2_11_15  connected_order_arc_1308  -13
    arc_2_11_15  out_degree_1578  1
    arc_2_11_15  in_degree_1607  1
    arc_2_11_15  original_T_including_depot_unload_1657  1.2442780266664952e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_15  arc_capacity_1307  1
    load_2_11_15  segment_load_conservation_1582  1
    load_2_11_15  free_load_conservation_1611  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_16  arc_capacity_1309  -30
    arc_2_11_16  connected_order_arc_1310  -13
    arc_2_11_16  out_degree_1578  1
    arc_2_11_16  in_degree_1613  1
    arc_2_11_16  original_T_including_depot_unload_1657  1.1005939447212634e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_16  arc_capacity_1309  1
    load_2_11_16  segment_load_conservation_1582  1
    load_2_11_16  free_load_conservation_1617  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_17  arc_capacity_1311  -30
    arc_2_11_17  connected_order_arc_1312  -13
    arc_2_11_17  out_degree_1578  1
    arc_2_11_17  in_degree_1619  1
    arc_2_11_17  original_T_including_depot_unload_1657  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_17  arc_capacity_1311  1
    load_2_11_17  segment_load_conservation_1582  1
    load_2_11_17  free_load_conservation_1623  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_18  arc_capacity_1313  -30
    arc_2_11_18  connected_order_arc_1314  -13
    arc_2_11_18  out_degree_1578  1
    arc_2_11_18  in_degree_1625  1
    arc_2_11_18  original_T_including_depot_unload_1657  1.5257079162357311e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_18  arc_capacity_1313  1
    load_2_11_18  segment_load_conservation_1582  1
    load_2_11_18  free_load_conservation_1629  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_19  arc_capacity_1315  -30
    arc_2_11_19  connected_order_arc_1316  -13
    arc_2_11_19  out_degree_1578  1
    arc_2_11_19  in_degree_1631  1
    arc_2_11_19  original_T_including_depot_unload_1657  8.3486971116736720e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_19  arc_capacity_1315  1
    load_2_11_19  segment_load_conservation_1582  1
    load_2_11_19  free_load_conservation_1635  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_20  arc_capacity_1317  -30
    arc_2_11_20  connected_order_arc_1318  -13
    arc_2_11_20  out_degree_1578  1
    arc_2_11_20  in_degree_1637  1
    arc_2_11_20  original_T_including_depot_unload_1657  1.2309802293463208e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_20  arc_capacity_1317  1
    load_2_11_20  segment_load_conservation_1582  1
    load_2_11_20  free_load_conservation_1641  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_21  arc_capacity_1319  -30
    arc_2_11_21  connected_order_arc_1320  -13
    arc_2_11_21  out_degree_1578  1
    arc_2_11_21  in_degree_1643  1
    arc_2_11_21  original_T_including_depot_unload_1657  1.1544376314422677e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_21  arc_capacity_1319  1
    load_2_11_21  segment_load_conservation_1582  1
    load_2_11_21  free_load_conservation_1647  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_22  arc_capacity_1321  -30
    arc_2_11_22  connected_order_arc_1322  -13
    arc_2_11_22  out_degree_1578  1
    arc_2_11_22  in_degree_1649  1
    arc_2_11_22  original_T_including_depot_unload_1657  1.5688206371681019e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_22  arc_capacity_1321  1
    load_2_11_22  segment_load_conservation_1582  1
    load_2_11_22  free_load_conservation_1653  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_0  arc_capacity_1323  -30
    arc_2_12_0  depot_return_or_bypass_1577  1
    arc_2_12_0  out_degree_1585  1
    arc_2_12_0  original_T_including_depot_unload_1657  1.4567038050199781e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_0  arc_capacity_1323  1
    load_2_12_0  segment_load_conservation_1589  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_11  arc_capacity_1324  -30
    arc_2_12_11  connected_order_arc_1325  -13
    arc_2_12_11  in_degree_1579  1
    arc_2_12_11  out_degree_1585  1
    arc_2_12_11  original_T_including_depot_unload_1657  1.2835993572680911e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_11  arc_capacity_1324  1
    load_2_12_11  segment_load_conservation_1582  -1
    load_2_12_11  segment_prefix_lb_1583  1
    load_2_12_11  segment_prefix_ub_1584  1
    load_2_12_11  segment_load_conservation_1589  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_13  arc_capacity_1326  -30
    arc_2_12_13  connected_order_arc_1327  -13
    arc_2_12_13  out_degree_1585  1
    arc_2_12_13  in_degree_1593  1
    arc_2_12_13  original_T_including_depot_unload_1657  5.2746035265689818e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_13  arc_capacity_1326  1
    load_2_12_13  segment_load_conservation_1589  1
    load_2_12_13  segment_load_conservation_1596  -1
    load_2_12_13  segment_prefix_lb_1597  1
    load_2_12_13  segment_prefix_ub_1598  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_14  arc_capacity_1328  -30
    arc_2_12_14  connected_order_arc_1329  -13
    arc_2_12_14  out_degree_1585  1
    arc_2_12_14  in_degree_1600  1
    arc_2_12_14  original_T_including_depot_unload_1657  2.1542021003680966e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_14  arc_capacity_1328  1
    load_2_12_14  segment_load_conservation_1589  1
    load_2_12_14  segment_load_conservation_1603  -1
    load_2_12_14  segment_prefix_lb_1604  1
    load_2_12_14  segment_prefix_ub_1605  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_15  arc_capacity_1330  -30
    arc_2_12_15  connected_order_arc_1331  -13
    arc_2_12_15  out_degree_1585  1
    arc_2_12_15  in_degree_1607  1
    arc_2_12_15  original_T_including_depot_unload_1657  1.9434430494183746e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_15  arc_capacity_1330  1
    load_2_12_15  segment_load_conservation_1589  1
    load_2_12_15  free_load_conservation_1611  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_16  arc_capacity_1332  -30
    arc_2_12_16  connected_order_arc_1333  -13
    arc_2_12_16  out_degree_1585  1
    arc_2_12_16  in_degree_1613  1
    arc_2_12_16  original_T_including_depot_unload_1657  1.7809992976396034e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_16  arc_capacity_1332  1
    load_2_12_16  segment_load_conservation_1589  1
    load_2_12_16  free_load_conservation_1617  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_17  arc_capacity_1334  -30
    arc_2_12_17  connected_order_arc_1335  -13
    arc_2_12_17  out_degree_1585  1
    arc_2_12_17  in_degree_1619  1
    arc_2_12_17  original_T_including_depot_unload_1657  1.2027697073878232e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_17  arc_capacity_1334  1
    load_2_12_17  segment_load_conservation_1589  1
    load_2_12_17  free_load_conservation_1623  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_18  arc_capacity_1336  -30
    arc_2_12_18  connected_order_arc_1337  -13
    arc_2_12_18  out_degree_1585  1
    arc_2_12_18  in_degree_1625  1
    arc_2_12_18  original_T_including_depot_unload_1657  2.2638184459267368e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_18  arc_capacity_1336  1
    load_2_12_18  segment_load_conservation_1589  1
    load_2_12_18  free_load_conservation_1629  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_19  arc_capacity_1338  -30
    arc_2_12_19  connected_order_arc_1339  -13
    arc_2_12_19  out_degree_1585  1
    arc_2_12_19  in_degree_1631  1
    arc_2_12_19  original_T_including_depot_unload_1657  2.0178882184947397e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_19  arc_capacity_1338  1
    load_2_12_19  segment_load_conservation_1589  1
    load_2_12_19  free_load_conservation_1635  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_20  arc_capacity_1340  -30
    arc_2_12_20  connected_order_arc_1341  -13
    arc_2_12_20  out_degree_1585  1
    arc_2_12_20  in_degree_1637  1
    arc_2_12_20  original_T_including_depot_unload_1657  1.6785246977297163e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_20  arc_capacity_1340  1
    load_2_12_20  segment_load_conservation_1589  1
    load_2_12_20  free_load_conservation_1641  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_21  arc_capacity_1342  -30
    arc_2_12_21  connected_order_arc_1343  -13
    arc_2_12_21  out_degree_1585  1
    arc_2_12_21  in_degree_1643  1
    arc_2_12_21  original_T_including_depot_unload_1657  3.1118349756671438e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_21  arc_capacity_1342  1
    load_2_12_21  segment_load_conservation_1589  1
    load_2_12_21  free_load_conservation_1647  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_22  arc_capacity_1344  -30
    arc_2_12_22  connected_order_arc_1345  -13
    arc_2_12_22  out_degree_1585  1
    arc_2_12_22  in_degree_1649  1
    arc_2_12_22  original_T_including_depot_unload_1657  2.4002470706280069e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_22  arc_capacity_1344  1
    load_2_12_22  segment_load_conservation_1589  1
    load_2_12_22  free_load_conservation_1653  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_0  arc_capacity_1346  -30
    arc_2_13_0  depot_return_or_bypass_1577  1
    arc_2_13_0  out_degree_1592  1
    arc_2_13_0  original_T_including_depot_unload_1657  1.2506062209426416e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_0  arc_capacity_1346  1
    load_2_13_0  segment_load_conservation_1596  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_11  arc_capacity_1347  -30
    arc_2_13_11  connected_order_arc_1348  -13
    arc_2_13_11  in_degree_1579  1
    arc_2_13_11  out_degree_1592  1
    arc_2_13_11  original_T_including_depot_unload_1657  1.0138993437494995e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_11  arc_capacity_1347  1
    load_2_13_11  segment_load_conservation_1582  -1
    load_2_13_11  segment_prefix_lb_1583  1
    load_2_13_11  segment_prefix_ub_1584  1
    load_2_13_11  segment_load_conservation_1596  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_12  arc_capacity_1349  -30
    arc_2_13_12  connected_order_arc_1350  -13
    arc_2_13_12  in_degree_1586  1
    arc_2_13_12  out_degree_1592  1
    arc_2_13_12  original_T_including_depot_unload_1657  5.2746035265689818e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_12  arc_capacity_1349  1
    load_2_13_12  segment_load_conservation_1589  -1
    load_2_13_12  segment_prefix_lb_1590  1
    load_2_13_12  segment_prefix_ub_1591  1
    load_2_13_12  segment_load_conservation_1596  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_14  arc_capacity_1351  -30
    arc_2_13_14  connected_order_arc_1352  -13
    arc_2_13_14  out_degree_1592  1
    arc_2_13_14  in_degree_1600  1
    arc_2_13_14  original_T_including_depot_unload_1657  1.6502895430075375e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_14  arc_capacity_1351  1
    load_2_13_14  segment_load_conservation_1596  1
    load_2_13_14  segment_load_conservation_1603  -1
    load_2_13_14  segment_prefix_lb_1604  1
    load_2_13_14  segment_prefix_ub_1605  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_15  arc_capacity_1353  -30
    arc_2_13_15  connected_order_arc_1354  -13
    arc_2_13_15  out_degree_1592  1
    arc_2_13_15  in_degree_1607  1
    arc_2_13_15  original_T_including_depot_unload_1657  1.9912760202020529e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_15  arc_capacity_1353  1
    load_2_13_15  segment_load_conservation_1596  1
    load_2_13_15  free_load_conservation_1611  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_16  arc_capacity_1355  -30
    arc_2_13_16  connected_order_arc_1356  -13
    arc_2_13_16  out_degree_1592  1
    arc_2_13_16  in_degree_1613  1
    arc_2_13_16  original_T_including_depot_unload_1657  1.8250469514445369e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_16  arc_capacity_1355  1
    load_2_13_16  segment_load_conservation_1596  1
    load_2_13_16  free_load_conservation_1617  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_17  arc_capacity_1357  -30
    arc_2_13_17  connected_order_arc_1358  -13
    arc_2_13_17  out_degree_1592  1
    arc_2_13_17  in_degree_1619  1
    arc_2_13_17  original_T_including_depot_unload_1657  1.4255422670497167e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_17  arc_capacity_1357  1
    load_2_13_17  segment_load_conservation_1596  1
    load_2_13_17  free_load_conservation_1623  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_18  arc_capacity_1359  -30
    arc_2_13_18  connected_order_arc_1360  -13
    arc_2_13_18  out_degree_1592  1
    arc_2_13_18  in_degree_1625  1
    arc_2_13_18  original_T_including_depot_unload_1657  2.3116686621879485e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_18  arc_capacity_1359  1
    load_2_13_18  segment_load_conservation_1596  1
    load_2_13_18  free_load_conservation_1629  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_19  arc_capacity_1361  -30
    arc_2_13_19  connected_order_arc_1362  -13
    arc_2_13_19  out_degree_1592  1
    arc_2_13_19  in_degree_1631  1
    arc_2_13_19  original_T_including_depot_unload_1657  1.8362893893653638e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_19  arc_capacity_1361  1
    load_2_13_19  segment_load_conservation_1596  1
    load_2_13_19  free_load_conservation_1635  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_20  arc_capacity_1363  -30
    arc_2_13_20  connected_order_arc_1364  -13
    arc_2_13_20  out_degree_1592  1
    arc_2_13_20  in_degree_1637  1
    arc_2_13_20  original_T_including_depot_unload_1657  1.8050468619497597e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_20  arc_capacity_1363  1
    load_2_13_20  segment_load_conservation_1596  1
    load_2_13_20  free_load_conservation_1641  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_21  arc_capacity_1365  -30
    arc_2_13_21  connected_order_arc_1366  -13
    arc_2_13_21  out_degree_1592  1
    arc_2_13_21  in_degree_1643  1
    arc_2_13_21  original_T_including_depot_unload_1657  2.2865444230199981e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_21  arc_capacity_1365  1
    load_2_13_21  segment_load_conservation_1596  1
    load_2_13_21  free_load_conservation_1647  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_22  arc_capacity_1367  -30
    arc_2_13_22  connected_order_arc_1368  -13
    arc_2_13_22  out_degree_1592  1
    arc_2_13_22  in_degree_1649  1
    arc_2_13_22  original_T_including_depot_unload_1657  2412.70187975598
    MARKER    'MARKER'                 'INTEND'
    load_2_13_22  arc_capacity_1367  1
    load_2_13_22  segment_load_conservation_1596  1
    load_2_13_22  free_load_conservation_1653  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_0  arc_capacity_1369  -30
    arc_2_14_0  depot_return_or_bypass_1577  1
    arc_2_14_0  out_degree_1599  1
    arc_2_14_0  original_T_including_depot_unload_1657  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_0  arc_capacity_1369  1
    load_2_14_0  segment_load_conservation_1603  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_11  arc_capacity_1370  -30
    arc_2_14_11  connected_order_arc_1371  -13
    arc_2_14_11  in_degree_1579  1
    arc_2_14_11  out_degree_1599  1
    arc_2_14_11  original_T_including_depot_unload_1657  2.4083746437975364e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_11  arc_capacity_1370  1
    load_2_14_11  segment_load_conservation_1582  -1
    load_2_14_11  segment_prefix_lb_1583  1
    load_2_14_11  segment_prefix_ub_1584  1
    load_2_14_11  segment_load_conservation_1603  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_12  arc_capacity_1372  -30
    arc_2_14_12  connected_order_arc_1373  -13
    arc_2_14_12  in_degree_1586  1
    arc_2_14_12  out_degree_1599  1
    arc_2_14_12  original_T_including_depot_unload_1657  1.4332871320059419e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_12  arc_capacity_1372  1
    load_2_14_12  segment_load_conservation_1589  -1
    load_2_14_12  segment_prefix_lb_1590  1
    load_2_14_12  segment_prefix_ub_1591  1
    load_2_14_12  segment_load_conservation_1603  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_13  arc_capacity_1374  -30
    arc_2_14_13  connected_order_arc_1375  -13
    arc_2_14_13  in_degree_1593  1
    arc_2_14_13  out_degree_1599  1
    arc_2_14_13  original_T_including_depot_unload_1657  1.0874822831610163e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_13  arc_capacity_1374  1
    load_2_14_13  segment_load_conservation_1596  -1
    load_2_14_13  segment_prefix_lb_1597  1
    load_2_14_13  segment_prefix_ub_1598  1
    load_2_14_13  segment_load_conservation_1603  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_15  arc_capacity_1376  -30
    arc_2_14_15  connected_order_arc_1377  -13
    arc_2_14_15  out_degree_1599  1
    arc_2_14_15  in_degree_1607  1
    arc_2_14_15  original_T_including_depot_unload_1657  1.4252778892498145e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_15  arc_capacity_1376  1
    load_2_14_15  segment_load_conservation_1603  1
    load_2_14_15  free_load_conservation_1611  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_16  arc_capacity_1378  -30
    arc_2_14_16  connected_order_arc_1379  -13
    arc_2_14_16  out_degree_1599  1
    arc_2_14_16  in_degree_1613  1
    arc_2_14_16  original_T_including_depot_unload_1657  1.2927779971523576e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_16  arc_capacity_1378  1
    load_2_14_16  segment_load_conservation_1603  1
    load_2_14_16  free_load_conservation_1617  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_17  arc_capacity_1380  -30
    arc_2_14_17  connected_order_arc_1381  -13
    arc_2_14_17  out_degree_1599  1
    arc_2_14_17  in_degree_1619  1
    arc_2_14_17  original_T_including_depot_unload_1657  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_17  arc_capacity_1380  1
    load_2_14_17  segment_load_conservation_1603  1
    load_2_14_17  free_load_conservation_1623  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_18  arc_capacity_1382  -30
    arc_2_14_18  connected_order_arc_1383  -13
    arc_2_14_18  out_degree_1599  1
    arc_2_14_18  in_degree_1625  1
    arc_2_14_18  original_T_including_depot_unload_1657  1.6865101452371027e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_18  arc_capacity_1382  1
    load_2_14_18  segment_load_conservation_1603  1
    load_2_14_18  free_load_conservation_1629  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_19  arc_capacity_1384  -30
    arc_2_14_19  connected_order_arc_1385  -13
    arc_2_14_19  out_degree_1599  1
    arc_2_14_19  in_degree_1631  1
    arc_2_14_19  original_T_including_depot_unload_1657  8.7684829846426385e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_19  arc_capacity_1384  1
    load_2_14_19  segment_load_conservation_1603  1
    load_2_14_19  free_load_conservation_1635  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_20  arc_capacity_1386  -30
    arc_2_14_20  connected_order_arc_1387  -13
    arc_2_14_20  out_degree_1599  1
    arc_2_14_20  in_degree_1637  1
    arc_2_14_20  original_T_including_depot_unload_1657  1.4479585101303876e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_20  arc_capacity_1386  1
    load_2_14_20  segment_load_conservation_1603  1
    load_2_14_20  free_load_conservation_1641  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_21  arc_capacity_1388  -30
    arc_2_14_21  connected_order_arc_1389  -13
    arc_2_14_21  out_degree_1599  1
    arc_2_14_21  in_degree_1643  1
    arc_2_14_21  original_T_including_depot_unload_1657  1.2608612406747543e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_21  arc_capacity_1388  1
    load_2_14_21  segment_load_conservation_1603  1
    load_2_14_21  free_load_conservation_1647  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_22  arc_capacity_1390  -30
    arc_2_14_22  connected_order_arc_1391  -13
    arc_2_14_22  out_degree_1599  1
    arc_2_14_22  in_degree_1649  1
    arc_2_14_22  original_T_including_depot_unload_1657  1706.88312024691
    MARKER    'MARKER'                 'INTEND'
    load_2_14_22  arc_capacity_1390  1
    load_2_14_22  segment_load_conservation_1603  1
    load_2_14_22  free_load_conservation_1653  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_0  arc_capacity_1392  -30
    arc_2_15_0  depot_return_or_bypass_1577  1
    arc_2_15_0  out_degree_1606  1
    arc_2_15_0  original_T_including_depot_unload_1657  1.0088905112952611e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_0  arc_capacity_1392  1
    load_2_15_0  free_load_conservation_1611  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_11  arc_capacity_1393  -30
    arc_2_15_11  connected_order_arc_1394  -13
    arc_2_15_11  in_degree_1579  1
    arc_2_15_11  out_degree_1606  1
    arc_2_15_11  original_T_including_depot_unload_1657  1.2442780266664952e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_11  arc_capacity_1393  1
    load_2_15_11  segment_load_conservation_1582  -1
    load_2_15_11  segment_prefix_lb_1583  1
    load_2_15_11  segment_prefix_ub_1584  1
    load_2_15_11  free_load_conservation_1611  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_12  arc_capacity_1395  -30
    arc_2_15_12  connected_order_arc_1396  -13
    arc_2_15_12  in_degree_1586  1
    arc_2_15_12  out_degree_1606  1
    arc_2_15_12  original_T_including_depot_unload_1657  1.9434430494183746e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_12  arc_capacity_1395  1
    load_2_15_12  segment_load_conservation_1589  -1
    load_2_15_12  segment_prefix_lb_1590  1
    load_2_15_12  segment_prefix_ub_1591  1
    load_2_15_12  free_load_conservation_1611  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_13  arc_capacity_1397  -30
    arc_2_15_13  connected_order_arc_1398  -13
    arc_2_15_13  in_degree_1593  1
    arc_2_15_13  out_degree_1606  1
    arc_2_15_13  original_T_including_depot_unload_1657  1.9912760202020529e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_13  arc_capacity_1397  1
    load_2_15_13  segment_load_conservation_1596  -1
    load_2_15_13  segment_prefix_lb_1597  1
    load_2_15_13  segment_prefix_ub_1598  1
    load_2_15_13  free_load_conservation_1611  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_14  arc_capacity_1399  -30
    arc_2_15_14  connected_order_arc_1400  -13
    arc_2_15_14  in_degree_1600  1
    arc_2_15_14  out_degree_1606  1
    arc_2_15_14  original_T_including_depot_unload_1657  2.4292147347743676e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_14  arc_capacity_1399  1
    load_2_15_14  segment_load_conservation_1603  -1
    load_2_15_14  segment_prefix_lb_1604  1
    load_2_15_14  segment_prefix_ub_1605  1
    load_2_15_14  free_load_conservation_1611  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_16  arc_capacity_1401  -30
    arc_2_15_16  connected_order_arc_1402  -13
    arc_2_15_16  out_degree_1606  1
    arc_2_15_16  in_degree_1613  1
    arc_2_15_16  original_T_including_depot_unload_1657  1.6651295535886251e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_16  arc_capacity_1401  1
    load_2_15_16  free_load_conservation_1611  1
    load_2_15_16  free_load_conservation_1617  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_17  arc_capacity_1403  -30
    arc_2_15_17  connected_order_arc_1404  -13
    arc_2_15_17  out_degree_1606  1
    arc_2_15_17  in_degree_1619  1
    arc_2_15_17  original_T_including_depot_unload_1657  861.314419336229
    MARKER    'MARKER'                 'INTEND'
    load_2_15_17  arc_capacity_1403  1
    load_2_15_17  free_load_conservation_1611  1
    load_2_15_17  free_load_conservation_1623  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_18  arc_capacity_1405  -30
    arc_2_15_18  connected_order_arc_1406  -13
    arc_2_15_18  out_degree_1606  1
    arc_2_15_18  in_degree_1625  1
    arc_2_15_18  original_T_including_depot_unload_1657  3.2286832955801827e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_18  arc_capacity_1405  1
    load_2_15_18  free_load_conservation_1611  1
    load_2_15_18  free_load_conservation_1629  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_19  arc_capacity_1407  -30
    arc_2_15_19  connected_order_arc_1408  -13
    arc_2_15_19  out_degree_1606  1
    arc_2_15_19  in_degree_1631  1
    arc_2_15_19  original_T_including_depot_unload_1657  8.5502565124349769e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_19  arc_capacity_1407  1
    load_2_15_19  free_load_conservation_1611  1
    load_2_15_19  free_load_conservation_1635  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_20  arc_capacity_1409  -30
    arc_2_15_20  connected_order_arc_1410  -13
    arc_2_15_20  out_degree_1606  1
    arc_2_15_20  in_degree_1637  1
    arc_2_15_20  original_T_including_depot_unload_1657  3.6094216796124527e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_20  arc_capacity_1409  1
    load_2_15_20  free_load_conservation_1611  1
    load_2_15_20  free_load_conservation_1641  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_21  arc_capacity_1411  -30
    arc_2_15_21  connected_order_arc_1412  -13
    arc_2_15_21  out_degree_1606  1
    arc_2_15_21  in_degree_1643  1
    arc_2_15_21  original_T_including_depot_unload_1657  2.0104743468619281e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_21  arc_capacity_1411  1
    load_2_15_21  free_load_conservation_1611  1
    load_2_15_21  free_load_conservation_1647  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_22  arc_capacity_1413  -30
    arc_2_15_22  connected_order_arc_1414  -13
    arc_2_15_22  out_degree_1606  1
    arc_2_15_22  in_degree_1649  1
    arc_2_15_22  original_T_including_depot_unload_1657  4.6588884124393707e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_22  arc_capacity_1413  1
    load_2_15_22  free_load_conservation_1611  1
    load_2_15_22  free_load_conservation_1653  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_0  arc_capacity_1415  -30
    arc_2_16_0  depot_return_or_bypass_1577  1
    arc_2_16_0  out_degree_1612  1
    arc_2_16_0  original_T_including_depot_unload_1657  8.7749189782983967e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_0  arc_capacity_1415  1
    load_2_16_0  free_load_conservation_1617  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_11  arc_capacity_1416  -30
    arc_2_16_11  connected_order_arc_1417  -13
    arc_2_16_11  in_degree_1579  1
    arc_2_16_11  out_degree_1612  1
    arc_2_16_11  original_T_including_depot_unload_1657  1.1005939447212634e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_11  arc_capacity_1416  1
    load_2_16_11  segment_load_conservation_1582  -1
    load_2_16_11  segment_prefix_lb_1583  1
    load_2_16_11  segment_prefix_ub_1584  1
    load_2_16_11  free_load_conservation_1617  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_12  arc_capacity_1418  -30
    arc_2_16_12  connected_order_arc_1419  -13
    arc_2_16_12  in_degree_1586  1
    arc_2_16_12  out_degree_1612  1
    arc_2_16_12  original_T_including_depot_unload_1657  1.7809992976396034e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_12  arc_capacity_1418  1
    load_2_16_12  segment_load_conservation_1589  -1
    load_2_16_12  segment_prefix_lb_1590  1
    load_2_16_12  segment_prefix_ub_1591  1
    load_2_16_12  free_load_conservation_1617  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_13  arc_capacity_1420  -30
    arc_2_16_13  connected_order_arc_1421  -13
    arc_2_16_13  in_degree_1593  1
    arc_2_16_13  out_degree_1612  1
    arc_2_16_13  original_T_including_depot_unload_1657  1.8250469514445369e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_13  arc_capacity_1420  1
    load_2_16_13  segment_load_conservation_1596  -1
    load_2_16_13  segment_prefix_lb_1597  1
    load_2_16_13  segment_prefix_ub_1598  1
    load_2_16_13  free_load_conservation_1617  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_14  arc_capacity_1422  -30
    arc_2_16_14  connected_order_arc_1423  -13
    arc_2_16_14  in_degree_1600  1
    arc_2_16_14  out_degree_1612  1
    arc_2_16_14  original_T_including_depot_unload_1657  2.3158028257381197e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_14  arc_capacity_1422  1
    load_2_16_14  segment_load_conservation_1603  -1
    load_2_16_14  segment_prefix_lb_1604  1
    load_2_16_14  segment_prefix_ub_1605  1
    load_2_16_14  free_load_conservation_1617  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_15  arc_capacity_1424  -30
    arc_2_16_15  connected_order_arc_1425  -13
    arc_2_16_15  in_degree_1607  1
    arc_2_16_15  out_degree_1612  1
    arc_2_16_15  original_T_including_depot_unload_1657  1.6651295535886251e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_15  arc_capacity_1424  1
    load_2_16_15  free_load_conservation_1611  -1
    load_2_16_15  free_load_conservation_1617  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_17  arc_capacity_1426  -30
    arc_2_16_17  connected_order_arc_1427  -13
    arc_2_16_17  out_degree_1612  1
    arc_2_16_17  in_degree_1619  1
    arc_2_16_17  original_T_including_depot_unload_1657  7.3227602527872671e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_17  arc_capacity_1426  1
    load_2_16_17  free_load_conservation_1617  1
    load_2_16_17  free_load_conservation_1623  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_18  arc_capacity_1428  -30
    arc_2_16_18  connected_order_arc_1429  -13
    arc_2_16_18  out_degree_1612  1
    arc_2_16_18  in_degree_1625  1
    arc_2_16_18  original_T_including_depot_unload_1657  4.8905010520753694e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_18  arc_capacity_1428  1
    load_2_16_18  free_load_conservation_1617  1
    load_2_16_18  free_load_conservation_1629  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_19  arc_capacity_1430  -30
    arc_2_16_19  connected_order_arc_1431  -13
    arc_2_16_19  out_degree_1612  1
    arc_2_16_19  in_degree_1631  1
    arc_2_16_19  original_T_including_depot_unload_1657  8.1417957710766450e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_19  arc_capacity_1430  1
    load_2_16_19  free_load_conservation_1617  1
    load_2_16_19  free_load_conservation_1635  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_20  arc_capacity_1432  -30
    arc_2_16_20  connected_order_arc_1433  -13
    arc_2_16_20  out_degree_1612  1
    arc_2_16_20  in_degree_1637  1
    arc_2_16_20  original_T_including_depot_unload_1657  2.8747557636937808e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_20  arc_capacity_1432  1
    load_2_16_20  free_load_conservation_1617  1
    load_2_16_20  free_load_conservation_1641  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_21  arc_capacity_1434  -30
    arc_2_16_21  connected_order_arc_1435  -13
    arc_2_16_21  out_degree_1612  1
    arc_2_16_21  in_degree_1643  1
    arc_2_16_21  original_T_including_depot_unload_1657  1.8442669473423912e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_21  arc_capacity_1434  1
    load_2_16_21  free_load_conservation_1617  1
    load_2_16_21  free_load_conservation_1647  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_22  arc_capacity_1436  -30
    arc_2_16_22  connected_order_arc_1437  -13
    arc_2_16_22  out_degree_1612  1
    arc_2_16_22  in_degree_1649  1
    arc_2_16_22  original_T_including_depot_unload_1657  6.2102815646279714e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_22  arc_capacity_1436  1
    load_2_16_22  free_load_conservation_1617  1
    load_2_16_22  free_load_conservation_1653  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_0  arc_capacity_1438  -30
    arc_2_17_0  depot_return_or_bypass_1577  1
    arc_2_17_0  out_degree_1618  1
    arc_2_17_0  original_T_including_depot_unload_1657  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_0  arc_capacity_1438  1
    load_2_17_0  free_load_conservation_1623  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_11  arc_capacity_1439  -30
    arc_2_17_11  connected_order_arc_1440  -13
    arc_2_17_11  in_degree_1579  1
    arc_2_17_11  out_degree_1618  1
    arc_2_17_11  original_T_including_depot_unload_1657  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_11  arc_capacity_1439  1
    load_2_17_11  segment_load_conservation_1582  -1
    load_2_17_11  segment_prefix_lb_1583  1
    load_2_17_11  segment_prefix_ub_1584  1
    load_2_17_11  free_load_conservation_1623  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_12  arc_capacity_1441  -30
    arc_2_17_12  connected_order_arc_1442  -13
    arc_2_17_12  in_degree_1586  1
    arc_2_17_12  out_degree_1618  1
    arc_2_17_12  original_T_including_depot_unload_1657  1.2027697073878232e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_12  arc_capacity_1441  1
    load_2_17_12  segment_load_conservation_1589  -1
    load_2_17_12  segment_prefix_lb_1590  1
    load_2_17_12  segment_prefix_ub_1591  1
    load_2_17_12  free_load_conservation_1623  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_13  arc_capacity_1443  -30
    arc_2_17_13  connected_order_arc_1444  -13
    arc_2_17_13  in_degree_1593  1
    arc_2_17_13  out_degree_1618  1
    arc_2_17_13  original_T_including_depot_unload_1657  1.4255422670497167e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_13  arc_capacity_1443  1
    load_2_17_13  segment_load_conservation_1596  -1
    load_2_17_13  segment_prefix_lb_1597  1
    load_2_17_13  segment_prefix_ub_1598  1
    load_2_17_13  free_load_conservation_1623  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_14  arc_capacity_1445  -30
    arc_2_17_14  connected_order_arc_1446  -13
    arc_2_17_14  in_degree_1600  1
    arc_2_17_14  out_degree_1618  1
    arc_2_17_14  original_T_including_depot_unload_1657  2.4496137598598170e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_14  arc_capacity_1445  1
    load_2_17_14  segment_load_conservation_1603  -1
    load_2_17_14  segment_prefix_lb_1604  1
    load_2_17_14  segment_prefix_ub_1605  1
    load_2_17_14  free_load_conservation_1623  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_15  arc_capacity_1447  -30
    arc_2_17_15  connected_order_arc_1448  -13
    arc_2_17_15  in_degree_1607  1
    arc_2_17_15  out_degree_1618  1
    arc_2_17_15  original_T_including_depot_unload_1657  861.314419336229
    MARKER    'MARKER'                 'INTEND'
    load_2_17_15  arc_capacity_1447  1
    load_2_17_15  free_load_conservation_1611  -1
    load_2_17_15  free_load_conservation_1623  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_16  arc_capacity_1449  -30
    arc_2_17_16  connected_order_arc_1450  -13
    arc_2_17_16  in_degree_1613  1
    arc_2_17_16  out_degree_1618  1
    arc_2_17_16  original_T_including_depot_unload_1657  7.3227602527872671e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_16  arc_capacity_1449  1
    load_2_17_16  free_load_conservation_1617  -1
    load_2_17_16  free_load_conservation_1623  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_18  arc_capacity_1451  -30
    arc_2_17_18  connected_order_arc_1452  -13
    arc_2_17_18  out_degree_1618  1
    arc_2_17_18  in_degree_1625  1
    arc_2_17_18  original_T_including_depot_unload_1657  1.1499210972200315e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_18  arc_capacity_1451  1
    load_2_17_18  free_load_conservation_1623  1
    load_2_17_18  free_load_conservation_1629  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_19  arc_capacity_1453  -30
    arc_2_17_19  connected_order_arc_1454  -13
    arc_2_17_19  out_degree_1618  1
    arc_2_17_19  in_degree_1631  1
    arc_2_17_19  original_T_including_depot_unload_1657  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_19  arc_capacity_1453  1
    load_2_17_19  free_load_conservation_1623  1
    load_2_17_19  free_load_conservation_1635  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_20  arc_capacity_1455  -30
    arc_2_17_20  connected_order_arc_1456  -13
    arc_2_17_20  out_degree_1618  1
    arc_2_17_20  in_degree_1637  1
    arc_2_17_20  original_T_including_depot_unload_1657  5.2280951376932137e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_20  arc_capacity_1455  1
    load_2_17_20  free_load_conservation_1623  1
    load_2_17_20  free_load_conservation_1641  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_21  arc_capacity_1457  -30
    arc_2_17_21  connected_order_arc_1458  -13
    arc_2_17_21  out_degree_1618  1
    arc_2_17_21  in_degree_1643  1
    arc_2_17_21  original_T_including_depot_unload_1657  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_21  arc_capacity_1457  1
    load_2_17_21  free_load_conservation_1623  1
    load_2_17_21  free_load_conservation_1647  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_22  arc_capacity_1459  -30
    arc_2_17_22  connected_order_arc_1460  -13
    arc_2_17_22  out_degree_1618  1
    arc_2_17_22  in_degree_1649  1
    arc_2_17_22  original_T_including_depot_unload_1657  1.3218357148919101e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_22  arc_capacity_1459  1
    load_2_17_22  free_load_conservation_1623  1
    load_2_17_22  free_load_conservation_1653  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_0  arc_capacity_1461  -30
    arc_2_18_0  depot_return_or_bypass_1577  1
    arc_2_18_0  out_degree_1624  1
    arc_2_18_0  original_T_including_depot_unload_1657  1.2751323166566442e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_0  arc_capacity_1461  1
    load_2_18_0  free_load_conservation_1629  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_11  arc_capacity_1462  -30
    arc_2_18_11  connected_order_arc_1463  -13
    arc_2_18_11  in_degree_1579  1
    arc_2_18_11  out_degree_1624  1
    arc_2_18_11  original_T_including_depot_unload_1657  1.5257079162357311e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_11  arc_capacity_1462  1
    load_2_18_11  segment_load_conservation_1582  -1
    load_2_18_11  segment_prefix_lb_1583  1
    load_2_18_11  segment_prefix_ub_1584  1
    load_2_18_11  free_load_conservation_1629  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_12  arc_capacity_1464  -30
    arc_2_18_12  connected_order_arc_1465  -13
    arc_2_18_12  in_degree_1586  1
    arc_2_18_12  out_degree_1624  1
    arc_2_18_12  original_T_including_depot_unload_1657  2.2638184459267368e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_12  arc_capacity_1464  1
    load_2_18_12  segment_load_conservation_1589  -1
    load_2_18_12  segment_prefix_lb_1590  1
    load_2_18_12  segment_prefix_ub_1591  1
    load_2_18_12  free_load_conservation_1629  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_13  arc_capacity_1466  -30
    arc_2_18_13  connected_order_arc_1467  -13
    arc_2_18_13  in_degree_1593  1
    arc_2_18_13  out_degree_1624  1
    arc_2_18_13  original_T_including_depot_unload_1657  2.3116686621879485e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_13  arc_capacity_1466  1
    load_2_18_13  segment_load_conservation_1596  -1
    load_2_18_13  segment_prefix_lb_1597  1
    load_2_18_13  segment_prefix_ub_1598  1
    load_2_18_13  free_load_conservation_1629  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_14  arc_capacity_1468  -30
    arc_2_18_14  connected_order_arc_1469  -13
    arc_2_18_14  in_degree_1600  1
    arc_2_18_14  out_degree_1624  1
    arc_2_18_14  original_T_including_depot_unload_1657  2.6480695040561745e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_14  arc_capacity_1468  1
    load_2_18_14  segment_load_conservation_1603  -1
    load_2_18_14  segment_prefix_lb_1604  1
    load_2_18_14  segment_prefix_ub_1605  1
    load_2_18_14  free_load_conservation_1629  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_15  arc_capacity_1470  -30
    arc_2_18_15  connected_order_arc_1471  -13
    arc_2_18_15  in_degree_1607  1
    arc_2_18_15  out_degree_1624  1
    arc_2_18_15  original_T_including_depot_unload_1657  3.2286832955801827e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_15  arc_capacity_1470  1
    load_2_18_15  free_load_conservation_1611  -1
    load_2_18_15  free_load_conservation_1629  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_16  arc_capacity_1472  -30
    arc_2_18_16  connected_order_arc_1473  -13
    arc_2_18_16  in_degree_1613  1
    arc_2_18_16  out_degree_1624  1
    arc_2_18_16  original_T_including_depot_unload_1657  4.8905010520753694e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_16  arc_capacity_1472  1
    load_2_18_16  free_load_conservation_1617  -1
    load_2_18_16  free_load_conservation_1629  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_17  arc_capacity_1474  -30
    arc_2_18_17  connected_order_arc_1475  -13
    arc_2_18_17  in_degree_1619  1
    arc_2_18_17  out_degree_1624  1
    arc_2_18_17  original_T_including_depot_unload_1657  1.1499210972200315e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_17  arc_capacity_1474  1
    load_2_18_17  free_load_conservation_1623  -1
    load_2_18_17  free_load_conservation_1629  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_19  arc_capacity_1476  -30
    arc_2_18_19  connected_order_arc_1477  -13
    arc_2_18_19  out_degree_1624  1
    arc_2_18_19  in_degree_1631  1
    arc_2_18_19  original_T_including_depot_unload_1657  990.144803963742
    MARKER    'MARKER'                 'INTEND'
    load_2_18_19  arc_capacity_1476  1
    load_2_18_19  free_load_conservation_1629  1
    load_2_18_19  free_load_conservation_1635  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_20  arc_capacity_1478  -30
    arc_2_18_20  connected_order_arc_1479  -13
    arc_2_18_20  out_degree_1624  1
    arc_2_18_20  in_degree_1637  1
    arc_2_18_20  original_T_including_depot_unload_1657  6.2793211180612207e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_20  arc_capacity_1478  1
    load_2_18_20  free_load_conservation_1629  1
    load_2_18_20  free_load_conservation_1641  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_21  arc_capacity_1480  -30
    arc_2_18_21  connected_order_arc_1481  -13
    arc_2_18_21  out_degree_1624  1
    arc_2_18_21  in_degree_1643  1
    arc_2_18_21  original_T_including_depot_unload_1657  2.3332890980657526e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_21  arc_capacity_1480  1
    load_2_18_21  free_load_conservation_1629  1
    load_2_18_21  free_load_conservation_1647  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_22  arc_capacity_1482  -30
    arc_2_18_22  connected_order_arc_1483  -13
    arc_2_18_22  out_degree_1624  1
    arc_2_18_22  in_degree_1649  1
    arc_2_18_22  original_T_including_depot_unload_1657  1.9785969874636677e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_22  arc_capacity_1482  1
    load_2_18_22  free_load_conservation_1629  1
    load_2_18_22  free_load_conservation_1653  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_0  arc_capacity_1484  -30
    arc_2_19_0  depot_return_or_bypass_1577  1
    arc_2_19_0  out_degree_1630  1
    arc_2_19_0  original_T_including_depot_unload_1657  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_0  arc_capacity_1484  1
    load_2_19_0  free_load_conservation_1635  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_11  arc_capacity_1485  -30
    arc_2_19_11  connected_order_arc_1486  -13
    arc_2_19_11  in_degree_1579  1
    arc_2_19_11  out_degree_1630  1
    arc_2_19_11  original_T_including_depot_unload_1657  8.3486971116736720e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_11  arc_capacity_1485  1
    load_2_19_11  segment_load_conservation_1582  -1
    load_2_19_11  segment_prefix_lb_1583  1
    load_2_19_11  segment_prefix_ub_1584  1
    load_2_19_11  free_load_conservation_1635  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_12  arc_capacity_1487  -30
    arc_2_19_12  connected_order_arc_1488  -13
    arc_2_19_12  in_degree_1586  1
    arc_2_19_12  out_degree_1630  1
    arc_2_19_12  original_T_including_depot_unload_1657  2.0178882184947397e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_12  arc_capacity_1487  1
    load_2_19_12  segment_load_conservation_1589  -1
    load_2_19_12  segment_prefix_lb_1590  1
    load_2_19_12  segment_prefix_ub_1591  1
    load_2_19_12  free_load_conservation_1635  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_13  arc_capacity_1489  -30
    arc_2_19_13  connected_order_arc_1490  -13
    arc_2_19_13  in_degree_1593  1
    arc_2_19_13  out_degree_1630  1
    arc_2_19_13  original_T_including_depot_unload_1657  1.8362893893653638e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_13  arc_capacity_1489  1
    load_2_19_13  segment_load_conservation_1596  -1
    load_2_19_13  segment_prefix_lb_1597  1
    load_2_19_13  segment_prefix_ub_1598  1
    load_2_19_13  free_load_conservation_1635  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_14  arc_capacity_1491  -30
    arc_2_19_14  connected_order_arc_1492  -13
    arc_2_19_14  in_degree_1600  1
    arc_2_19_14  out_degree_1630  1
    arc_2_19_14  original_T_including_depot_unload_1657  1.6906177970488723e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_14  arc_capacity_1491  1
    load_2_19_14  segment_load_conservation_1603  -1
    load_2_19_14  segment_prefix_lb_1604  1
    load_2_19_14  segment_prefix_ub_1605  1
    load_2_19_14  free_load_conservation_1635  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_15  arc_capacity_1493  -30
    arc_2_19_15  connected_order_arc_1494  -13
    arc_2_19_15  in_degree_1607  1
    arc_2_19_15  out_degree_1630  1
    arc_2_19_15  original_T_including_depot_unload_1657  8.5502565124349769e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_15  arc_capacity_1493  1
    load_2_19_15  free_load_conservation_1611  -1
    load_2_19_15  free_load_conservation_1635  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_16  arc_capacity_1495  -30
    arc_2_19_16  connected_order_arc_1496  -13
    arc_2_19_16  in_degree_1613  1
    arc_2_19_16  out_degree_1630  1
    arc_2_19_16  original_T_including_depot_unload_1657  8.1417957710766450e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_16  arc_capacity_1495  1
    load_2_19_16  free_load_conservation_1617  -1
    load_2_19_16  free_load_conservation_1635  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_17  arc_capacity_1497  -30
    arc_2_19_17  connected_order_arc_1498  -13
    arc_2_19_17  in_degree_1619  1
    arc_2_19_17  out_degree_1630  1
    arc_2_19_17  original_T_including_depot_unload_1657  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_17  arc_capacity_1497  1
    load_2_19_17  free_load_conservation_1623  -1
    load_2_19_17  free_load_conservation_1635  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_18  arc_capacity_1499  -30
    arc_2_19_18  connected_order_arc_1500  -13
    arc_2_19_18  in_degree_1625  1
    arc_2_19_18  out_degree_1630  1
    arc_2_19_18  original_T_including_depot_unload_1657  990.144803963742
    MARKER    'MARKER'                 'INTEND'
    load_2_19_18  arc_capacity_1499  1
    load_2_19_18  free_load_conservation_1629  -1
    load_2_19_18  free_load_conservation_1635  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_20  arc_capacity_1501  -30
    arc_2_19_20  connected_order_arc_1502  -13
    arc_2_19_20  out_degree_1630  1
    arc_2_19_20  in_degree_1637  1
    arc_2_19_20  original_T_including_depot_unload_1657  1.0880068546845516e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_20  arc_capacity_1501  1
    load_2_19_20  free_load_conservation_1635  1
    load_2_19_20  free_load_conservation_1641  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_21  arc_capacity_1503  -30
    arc_2_19_21  connected_order_arc_1504  -13
    arc_2_19_21  out_degree_1630  1
    arc_2_19_21  in_degree_1643  1
    arc_2_19_21  original_T_including_depot_unload_1657  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_21  arc_capacity_1503  1
    load_2_19_21  free_load_conservation_1635  1
    load_2_19_21  free_load_conservation_1647  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_22  arc_capacity_1505  -30
    arc_2_19_22  connected_order_arc_1506  -13
    arc_2_19_22  out_degree_1630  1
    arc_2_19_22  in_degree_1649  1
    arc_2_19_22  original_T_including_depot_unload_1657  9.3685967675232439e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_22  arc_capacity_1505  1
    load_2_19_22  free_load_conservation_1635  1
    load_2_19_22  free_load_conservation_1653  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_0  arc_capacity_1507  -30
    arc_2_20_0  depot_return_or_bypass_1577  1
    arc_2_20_0  out_degree_1636  1
    arc_2_20_0  original_T_including_depot_unload_1657  1.0479182987243917e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_0  arc_capacity_1507  1
    load_2_20_0  free_load_conservation_1641  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_11  arc_capacity_1508  -30
    arc_2_20_11  connected_order_arc_1509  -13
    arc_2_20_11  in_degree_1579  1
    arc_2_20_11  out_degree_1636  1
    arc_2_20_11  original_T_including_depot_unload_1657  1.2309802293463208e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_11  arc_capacity_1508  1
    load_2_20_11  segment_load_conservation_1582  -1
    load_2_20_11  segment_prefix_lb_1583  1
    load_2_20_11  segment_prefix_ub_1584  1
    load_2_20_11  free_load_conservation_1641  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_12  arc_capacity_1510  -30
    arc_2_20_12  connected_order_arc_1511  -13
    arc_2_20_12  in_degree_1586  1
    arc_2_20_12  out_degree_1636  1
    arc_2_20_12  original_T_including_depot_unload_1657  1.6785246977297163e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_12  arc_capacity_1510  1
    load_2_20_12  segment_load_conservation_1589  -1
    load_2_20_12  segment_prefix_lb_1590  1
    load_2_20_12  segment_prefix_ub_1591  1
    load_2_20_12  free_load_conservation_1641  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_13  arc_capacity_1512  -30
    arc_2_20_13  connected_order_arc_1513  -13
    arc_2_20_13  in_degree_1593  1
    arc_2_20_13  out_degree_1636  1
    arc_2_20_13  original_T_including_depot_unload_1657  1.8050468619497597e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_13  arc_capacity_1512  1
    load_2_20_13  segment_load_conservation_1596  -1
    load_2_20_13  segment_prefix_lb_1597  1
    load_2_20_13  segment_prefix_ub_1598  1
    load_2_20_13  free_load_conservation_1641  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_14  arc_capacity_1514  -30
    arc_2_20_14  connected_order_arc_1515  -13
    arc_2_20_14  in_degree_1600  1
    arc_2_20_14  out_degree_1636  1
    arc_2_20_14  original_T_including_depot_unload_1657  2.4977279292860885e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_14  arc_capacity_1514  1
    load_2_20_14  segment_load_conservation_1603  -1
    load_2_20_14  segment_prefix_lb_1604  1
    load_2_20_14  segment_prefix_ub_1605  1
    load_2_20_14  free_load_conservation_1641  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_15  arc_capacity_1516  -30
    arc_2_20_15  connected_order_arc_1517  -13
    arc_2_20_15  in_degree_1607  1
    arc_2_20_15  out_degree_1636  1
    arc_2_20_15  original_T_including_depot_unload_1657  3.6094216796124527e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_15  arc_capacity_1516  1
    load_2_20_15  free_load_conservation_1611  -1
    load_2_20_15  free_load_conservation_1641  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_16  arc_capacity_1518  -30
    arc_2_20_16  connected_order_arc_1519  -13
    arc_2_20_16  in_degree_1613  1
    arc_2_20_16  out_degree_1636  1
    arc_2_20_16  original_T_including_depot_unload_1657  2.8747557636937808e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_16  arc_capacity_1518  1
    load_2_20_16  free_load_conservation_1617  -1
    load_2_20_16  free_load_conservation_1641  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_17  arc_capacity_1520  -30
    arc_2_20_17  connected_order_arc_1521  -13
    arc_2_20_17  in_degree_1619  1
    arc_2_20_17  out_degree_1636  1
    arc_2_20_17  original_T_including_depot_unload_1657  5.2280951376932137e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_17  arc_capacity_1520  1
    load_2_20_17  free_load_conservation_1623  -1
    load_2_20_17  free_load_conservation_1641  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_18  arc_capacity_1522  -30
    arc_2_20_18  connected_order_arc_1523  -13
    arc_2_20_18  in_degree_1625  1
    arc_2_20_18  out_degree_1636  1
    arc_2_20_18  original_T_including_depot_unload_1657  6.2793211180612207e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_18  arc_capacity_1522  1
    load_2_20_18  free_load_conservation_1629  -1
    load_2_20_18  free_load_conservation_1641  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_19  arc_capacity_1524  -30
    arc_2_20_19  connected_order_arc_1525  -13
    arc_2_20_19  in_degree_1631  1
    arc_2_20_19  out_degree_1636  1
    arc_2_20_19  original_T_including_depot_unload_1657  1.0880068546845516e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_19  arc_capacity_1524  1
    load_2_20_19  free_load_conservation_1635  -1
    load_2_20_19  free_load_conservation_1641  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_21  arc_capacity_1526  -30
    arc_2_20_21  connected_order_arc_1527  -13
    arc_2_20_21  out_degree_1636  1
    arc_2_20_21  in_degree_1643  1
    arc_2_20_21  original_T_including_depot_unload_1657  1.7883808204567979e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_21  arc_capacity_1526  1
    load_2_20_21  free_load_conservation_1641  1
    load_2_20_21  free_load_conservation_1647  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_22  arc_capacity_1528  -30
    arc_2_20_22  connected_order_arc_1529  -13
    arc_2_20_22  out_degree_1636  1
    arc_2_20_22  in_degree_1649  1
    arc_2_20_22  original_T_including_depot_unload_1657  8.0531033344008677e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_22  arc_capacity_1528  1
    load_2_20_22  free_load_conservation_1641  1
    load_2_20_22  free_load_conservation_1653  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_0  arc_capacity_1530  -30
    arc_2_21_0  depot_return_or_bypass_1577  1
    arc_2_21_0  out_degree_1642  1
    arc_2_21_0  original_T_including_depot_unload_1657  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_0  arc_capacity_1530  1
    load_2_21_0  free_load_conservation_1647  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_11  arc_capacity_1531  -30
    arc_2_21_11  connected_order_arc_1532  -13
    arc_2_21_11  in_degree_1579  1
    arc_2_21_11  out_degree_1642  1
    arc_2_21_11  original_T_including_depot_unload_1657  1.1544376314422677e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_11  arc_capacity_1531  1
    load_2_21_11  segment_load_conservation_1582  -1
    load_2_21_11  segment_prefix_lb_1583  1
    load_2_21_11  segment_prefix_ub_1584  1
    load_2_21_11  free_load_conservation_1647  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_12  arc_capacity_1533  -30
    arc_2_21_12  connected_order_arc_1534  -13
    arc_2_21_12  in_degree_1586  1
    arc_2_21_12  out_degree_1642  1
    arc_2_21_12  original_T_including_depot_unload_1657  3.1118349756671438e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_12  arc_capacity_1533  1
    load_2_21_12  segment_load_conservation_1589  -1
    load_2_21_12  segment_prefix_lb_1590  1
    load_2_21_12  segment_prefix_ub_1591  1
    load_2_21_12  free_load_conservation_1647  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_13  arc_capacity_1535  -30
    arc_2_21_13  connected_order_arc_1536  -13
    arc_2_21_13  in_degree_1593  1
    arc_2_21_13  out_degree_1642  1
    arc_2_21_13  original_T_including_depot_unload_1657  2.2865444230199981e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_13  arc_capacity_1535  1
    load_2_21_13  segment_load_conservation_1596  -1
    load_2_21_13  segment_prefix_lb_1597  1
    load_2_21_13  segment_prefix_ub_1598  1
    load_2_21_13  free_load_conservation_1647  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_14  arc_capacity_1537  -30
    arc_2_21_14  connected_order_arc_1538  -13
    arc_2_21_14  in_degree_1600  1
    arc_2_21_14  out_degree_1642  1
    arc_2_21_14  original_T_including_depot_unload_1657  1.8780729343410642e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_14  arc_capacity_1537  1
    load_2_21_14  segment_load_conservation_1603  -1
    load_2_21_14  segment_prefix_lb_1604  1
    load_2_21_14  segment_prefix_ub_1605  1
    load_2_21_14  free_load_conservation_1647  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_15  arc_capacity_1539  -30
    arc_2_21_15  connected_order_arc_1540  -13
    arc_2_21_15  in_degree_1607  1
    arc_2_21_15  out_degree_1642  1
    arc_2_21_15  original_T_including_depot_unload_1657  2.0104743468619281e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_15  arc_capacity_1539  1
    load_2_21_15  free_load_conservation_1611  -1
    load_2_21_15  free_load_conservation_1647  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_16  arc_capacity_1541  -30
    arc_2_21_16  connected_order_arc_1542  -13
    arc_2_21_16  in_degree_1613  1
    arc_2_21_16  out_degree_1642  1
    arc_2_21_16  original_T_including_depot_unload_1657  1.8442669473423912e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_16  arc_capacity_1541  1
    load_2_21_16  free_load_conservation_1617  -1
    load_2_21_16  free_load_conservation_1647  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_17  arc_capacity_1543  -30
    arc_2_21_17  connected_order_arc_1544  -13
    arc_2_21_17  in_degree_1619  1
    arc_2_21_17  out_degree_1642  1
    arc_2_21_17  original_T_including_depot_unload_1657  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_17  arc_capacity_1543  1
    load_2_21_17  free_load_conservation_1623  -1
    load_2_21_17  free_load_conservation_1647  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_18  arc_capacity_1545  -30
    arc_2_21_18  connected_order_arc_1546  -13
    arc_2_21_18  in_degree_1625  1
    arc_2_21_18  out_degree_1642  1
    arc_2_21_18  original_T_including_depot_unload_1657  2.3332890980657526e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_18  arc_capacity_1545  1
    load_2_21_18  free_load_conservation_1629  -1
    load_2_21_18  free_load_conservation_1647  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_19  arc_capacity_1547  -30
    arc_2_21_19  connected_order_arc_1548  -13
    arc_2_21_19  in_degree_1631  1
    arc_2_21_19  out_degree_1642  1
    arc_2_21_19  original_T_including_depot_unload_1657  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_19  arc_capacity_1547  1
    load_2_21_19  free_load_conservation_1635  -1
    load_2_21_19  free_load_conservation_1647  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_20  arc_capacity_1549  -30
    arc_2_21_20  connected_order_arc_1550  -13
    arc_2_21_20  in_degree_1637  1
    arc_2_21_20  out_degree_1642  1
    arc_2_21_20  original_T_including_depot_unload_1657  1.7883808204567979e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_20  arc_capacity_1549  1
    load_2_21_20  free_load_conservation_1641  -1
    load_2_21_20  free_load_conservation_1647  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_22  arc_capacity_1551  -30
    arc_2_21_22  connected_order_arc_1552  -13
    arc_2_21_22  out_degree_1642  1
    arc_2_21_22  in_degree_1649  1
    arc_2_21_22  original_T_including_depot_unload_1657  2.4500766064196278e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_22  arc_capacity_1551  1
    load_2_21_22  free_load_conservation_1647  1
    load_2_21_22  free_load_conservation_1653  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_0  arc_capacity_1553  -30
    arc_2_22_0  depot_return_or_bypass_1577  1
    arc_2_22_0  out_degree_1648  1
    arc_2_22_0  original_T_including_depot_unload_1657  1.3076700111397606e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_22_0  arc_capacity_1553  1
    load_2_22_0  free_load_conservation_1653  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_11  arc_capacity_1554  -30
    arc_2_22_11  connected_order_arc_1555  -13
    arc_2_22_11  in_degree_1579  1
    arc_2_22_11  out_degree_1648  1
    arc_2_22_11  original_T_including_depot_unload_1657  1.5688206371681019e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_22_11  arc_capacity_1554  1
    load_2_22_11  segment_load_conservation_1582  -1
    load_2_22_11  segment_prefix_lb_1583  1
    load_2_22_11  segment_prefix_ub_1584  1
    load_2_22_11  free_load_conservation_1653  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_12  arc_capacity_1556  -30
    arc_2_22_12  connected_order_arc_1557  -13
    arc_2_22_12  in_degree_1586  1
    arc_2_22_12  out_degree_1648  1
    arc_2_22_12  original_T_including_depot_unload_1657  2.4002470706280069e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_22_12  arc_capacity_1556  1
    load_2_22_12  segment_load_conservation_1589  -1
    load_2_22_12  segment_prefix_lb_1590  1
    load_2_22_12  segment_prefix_ub_1591  1
    load_2_22_12  free_load_conservation_1653  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_13  arc_capacity_1558  -30
    arc_2_22_13  connected_order_arc_1559  -13
    arc_2_22_13  in_degree_1593  1
    arc_2_22_13  out_degree_1648  1
    arc_2_22_13  original_T_including_depot_unload_1657  2412.70187975598
    MARKER    'MARKER'                 'INTEND'
    load_2_22_13  arc_capacity_1558  1
    load_2_22_13  segment_load_conservation_1596  -1
    load_2_22_13  segment_prefix_lb_1597  1
    load_2_22_13  segment_prefix_ub_1598  1
    load_2_22_13  free_load_conservation_1653  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_14  arc_capacity_1560  -30
    arc_2_22_14  connected_order_arc_1561  -13
    arc_2_22_14  in_degree_1600  1
    arc_2_22_14  out_degree_1648  1
    arc_2_22_14  original_T_including_depot_unload_1657  2.6227054239003946e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_22_14  arc_capacity_1560  1
    load_2_22_14  segment_load_conservation_1603  -1
    load_2_22_14  segment_prefix_lb_1604  1
    load_2_22_14  segment_prefix_ub_1605  1
    load_2_22_14  free_load_conservation_1653  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_15  arc_capacity_1562  -30
    arc_2_22_15  connected_order_arc_1563  -13
    arc_2_22_15  in_degree_1607  1
    arc_2_22_15  out_degree_1648  1
    arc_2_22_15  original_T_including_depot_unload_1657  4.6588884124393707e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_15  arc_capacity_1562  1
    load_2_22_15  free_load_conservation_1611  -1
    load_2_22_15  free_load_conservation_1653  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_16  arc_capacity_1564  -30
    arc_2_22_16  connected_order_arc_1565  -13
    arc_2_22_16  in_degree_1613  1
    arc_2_22_16  out_degree_1648  1
    arc_2_22_16  original_T_including_depot_unload_1657  6.2102815646279714e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_16  arc_capacity_1564  1
    load_2_22_16  free_load_conservation_1617  -1
    load_2_22_16  free_load_conservation_1653  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_17  arc_capacity_1566  -30
    arc_2_22_17  connected_order_arc_1567  -13
    arc_2_22_17  in_degree_1619  1
    arc_2_22_17  out_degree_1648  1
    arc_2_22_17  original_T_including_depot_unload_1657  1.3218357148919101e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_22_17  arc_capacity_1566  1
    load_2_22_17  free_load_conservation_1623  -1
    load_2_22_17  free_load_conservation_1653  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_18  arc_capacity_1568  -30
    arc_2_22_18  connected_order_arc_1569  -13
    arc_2_22_18  in_degree_1625  1
    arc_2_22_18  out_degree_1648  1
    arc_2_22_18  original_T_including_depot_unload_1657  1.9785969874636677e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_18  arc_capacity_1568  1
    load_2_22_18  free_load_conservation_1629  -1
    load_2_22_18  free_load_conservation_1653  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_19  arc_capacity_1570  -30
    arc_2_22_19  connected_order_arc_1571  -13
    arc_2_22_19  in_degree_1631  1
    arc_2_22_19  out_degree_1648  1
    arc_2_22_19  original_T_including_depot_unload_1657  9.3685967675232439e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_19  arc_capacity_1570  1
    load_2_22_19  free_load_conservation_1635  -1
    load_2_22_19  free_load_conservation_1653  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_20  arc_capacity_1572  -30
    arc_2_22_20  connected_order_arc_1573  -13
    arc_2_22_20  in_degree_1637  1
    arc_2_22_20  out_degree_1648  1
    arc_2_22_20  original_T_including_depot_unload_1657  8.0531033344008677e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_20  arc_capacity_1572  1
    load_2_22_20  free_load_conservation_1641  -1
    load_2_22_20  free_load_conservation_1653  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_21  arc_capacity_1574  -30
    arc_2_22_21  connected_order_arc_1575  -13
    arc_2_22_21  in_degree_1643  1
    arc_2_22_21  out_degree_1648  1
    arc_2_22_21  original_T_including_depot_unload_1657  2.4500766064196278e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_22_21  arc_capacity_1574  1
    load_2_22_21  free_load_conservation_1647  -1
    load_2_22_21  free_load_conservation_1653  1
RHS
    RHS1      OBJ       -0.51375
    RHS1      onehot_27_32  1
    RHS1      onehot_24_67  1
    RHS1      onehot_31_96  1
    RHS1      onehot_34_123  1
    RHS1      onehot_16_152  1
    RHS1      onehot_29_187  1
    RHS1      onehot_32_216  1
    RHS1      onehot_33_253  1
    RHS1      stock_ub_257  38
    RHS1      parent_nonstrict_scope_258  2.7407157375771529e-01
    RHS1      normalization_315  1
    RHS1      connected_order_arc_440  -12
    RHS1      connected_order_arc_442  -12
    RHS1      connected_order_arc_444  -12
    RHS1      connected_order_arc_446  -12
    RHS1      connected_order_arc_448  -12
    RHS1      connected_order_arc_450  -12
    RHS1      connected_order_arc_452  -12
    RHS1      connected_order_arc_454  -12
    RHS1      connected_order_arc_456  -12
    RHS1      connected_order_arc_458  -12
    RHS1      connected_order_arc_460  -12
    RHS1      connected_order_arc_463  -12
    RHS1      connected_order_arc_465  -12
    RHS1      connected_order_arc_467  -12
    RHS1      connected_order_arc_469  -12
    RHS1      connected_order_arc_471  -12
    RHS1      connected_order_arc_473  -12
    RHS1      connected_order_arc_475  -12
    RHS1      connected_order_arc_477  -12
    RHS1      connected_order_arc_479  -12
    RHS1      connected_order_arc_481  -12
    RHS1      connected_order_arc_483  -12
    RHS1      connected_order_arc_486  -12
    RHS1      connected_order_arc_488  -12
    RHS1      connected_order_arc_490  -12
    RHS1      connected_order_arc_492  -12
    RHS1      connected_order_arc_494  -12
    RHS1      connected_order_arc_496  -12
    RHS1      connected_order_arc_498  -12
    RHS1      connected_order_arc_500  -12
    RHS1      connected_order_arc_502  -12
    RHS1      connected_order_arc_504  -12
    RHS1      connected_order_arc_506  -12
    RHS1      connected_order_arc_509  -12
    RHS1      connected_order_arc_511  -12
    RHS1      connected_order_arc_513  -12
    RHS1      connected_order_arc_515  -12
    RHS1      connected_order_arc_517  -12
    RHS1      connected_order_arc_519  -12
    RHS1      connected_order_arc_521  -12
    RHS1      connected_order_arc_523  -12
    RHS1      connected_order_arc_525  -12
    RHS1      connected_order_arc_527  -12
    RHS1      connected_order_arc_529  -12
    RHS1      connected_order_arc_532  -12
    RHS1      connected_order_arc_534  -12
    RHS1      connected_order_arc_536  -12
    RHS1      connected_order_arc_538  -12
    RHS1      connected_order_arc_540  -12
    RHS1      connected_order_arc_542  -12
    RHS1      connected_order_arc_544  -12
    RHS1      connected_order_arc_546  -12
    RHS1      connected_order_arc_548  -12
    RHS1      connected_order_arc_550  -12
    RHS1      connected_order_arc_552  -12
    RHS1      connected_order_arc_555  -12
    RHS1      connected_order_arc_557  -12
    RHS1      connected_order_arc_559  -12
    RHS1      connected_order_arc_561  -12
    RHS1      connected_order_arc_563  -12
    RHS1      connected_order_arc_565  -12
    RHS1      connected_order_arc_567  -12
    RHS1      connected_order_arc_569  -12
    RHS1      connected_order_arc_571  -12
    RHS1      connected_order_arc_573  -12
    RHS1      connected_order_arc_575  -12
    RHS1      connected_order_arc_578  -12
    RHS1      connected_order_arc_580  -12
    RHS1      connected_order_arc_582  -12
    RHS1      connected_order_arc_584  -12
    RHS1      connected_order_arc_586  -12
    RHS1      connected_order_arc_588  -12
    RHS1      connected_order_arc_590  -12
    RHS1      connected_order_arc_592  -12
    RHS1      connected_order_arc_594  -12
    RHS1      connected_order_arc_596  -12
    RHS1      connected_order_arc_598  -12
    RHS1      connected_order_arc_601  -12
    RHS1      connected_order_arc_603  -12
    RHS1      connected_order_arc_605  -12
    RHS1      connected_order_arc_607  -12
    RHS1      connected_order_arc_609  -12
    RHS1      connected_order_arc_611  -12
    RHS1      connected_order_arc_613  -12
    RHS1      connected_order_arc_615  -12
    RHS1      connected_order_arc_617  -12
    RHS1      connected_order_arc_619  -12
    RHS1      connected_order_arc_621  -12
    RHS1      connected_order_arc_624  -12
    RHS1      connected_order_arc_626  -12
    RHS1      connected_order_arc_628  -12
    RHS1      connected_order_arc_630  -12
    RHS1      connected_order_arc_632  -12
    RHS1      connected_order_arc_634  -12
    RHS1      connected_order_arc_636  -12
    RHS1      connected_order_arc_638  -12
    RHS1      connected_order_arc_640  -12
    RHS1      connected_order_arc_642  -12
    RHS1      connected_order_arc_644  -12
    RHS1      connected_order_arc_647  -12
    RHS1      connected_order_arc_649  -12
    RHS1      connected_order_arc_651  -12
    RHS1      connected_order_arc_653  -12
    RHS1      connected_order_arc_655  -12
    RHS1      connected_order_arc_657  -12
    RHS1      connected_order_arc_659  -12
    RHS1      connected_order_arc_661  -12
    RHS1      connected_order_arc_663  -12
    RHS1      connected_order_arc_665  -12
    RHS1      connected_order_arc_667  -12
    RHS1      connected_order_arc_670  -12
    RHS1      connected_order_arc_672  -12
    RHS1      connected_order_arc_674  -12
    RHS1      connected_order_arc_676  -12
    RHS1      connected_order_arc_678  -12
    RHS1      connected_order_arc_680  -12
    RHS1      connected_order_arc_682  -12
    RHS1      connected_order_arc_684  -12
    RHS1      connected_order_arc_686  -12
    RHS1      connected_order_arc_688  -12
    RHS1      connected_order_arc_690  -12
    RHS1      connected_order_arc_693  -12
    RHS1      connected_order_arc_695  -12
    RHS1      connected_order_arc_697  -12
    RHS1      connected_order_arc_699  -12
    RHS1      connected_order_arc_701  -12
    RHS1      connected_order_arc_703  -12
    RHS1      connected_order_arc_705  -12
    RHS1      connected_order_arc_707  -12
    RHS1      connected_order_arc_709  -12
    RHS1      connected_order_arc_711  -12
    RHS1      connected_order_arc_713  -12
    RHS1      depot_departure_or_bypass_714  1
    RHS1      depot_return_or_bypass_715  1
    RHS1      segment_load_conservation_720  5
    RHS1      segment_prefix_ub_722  15
    RHS1      segment_load_conservation_727  5
    RHS1      segment_prefix_ub_729  15
    RHS1      segment_load_conservation_734  4
    RHS1      segment_prefix_ub_736  16
    RHS1      segment_load_conservation_741  -14
    RHS1      segment_prefix_lb_742  14
    RHS1      segment_prefix_ub_743  16
    RHS1      fixed_segment_relative_order_792  1
    RHS1      fixed_segment_relative_order_793  1
    RHS1      fixed_segment_relative_order_794  1
    RHS1      original_T_including_depot_unload_795  1.6964019822822393e+03
    RHS1      connected_order_arc_813  -14
    RHS1      connected_order_arc_815  -14
    RHS1      connected_order_arc_817  -14
    RHS1      connected_order_arc_819  -14
    RHS1      connected_order_arc_821  -14
    RHS1      connected_order_arc_823  -14
    RHS1      connected_order_arc_825  -14
    RHS1      connected_order_arc_827  -14
    RHS1      connected_order_arc_829  -14
    RHS1      connected_order_arc_831  -14
    RHS1      connected_order_arc_833  -14
    RHS1      connected_order_arc_835  -14
    RHS1      connected_order_arc_837  -14
    RHS1      connected_order_arc_840  -14
    RHS1      connected_order_arc_842  -14
    RHS1      connected_order_arc_844  -14
    RHS1      connected_order_arc_846  -14
    RHS1      connected_order_arc_848  -14
    RHS1      connected_order_arc_850  -14
    RHS1      connected_order_arc_852  -14
    RHS1      connected_order_arc_854  -14
    RHS1      connected_order_arc_856  -14
    RHS1      connected_order_arc_858  -14
    RHS1      connected_order_arc_860  -14
    RHS1      connected_order_arc_862  -14
    RHS1      connected_order_arc_864  -14
    RHS1      connected_order_arc_867  -14
    RHS1      connected_order_arc_869  -14
    RHS1      connected_order_arc_871  -14
    RHS1      connected_order_arc_873  -14
    RHS1      connected_order_arc_875  -14
    RHS1      connected_order_arc_877  -14
    RHS1      connected_order_arc_879  -14
    RHS1      connected_order_arc_881  -14
    RHS1      connected_order_arc_883  -14
    RHS1      connected_order_arc_885  -14
    RHS1      connected_order_arc_887  -14
    RHS1      connected_order_arc_889  -14
    RHS1      connected_order_arc_891  -14
    RHS1      connected_order_arc_894  -14
    RHS1      connected_order_arc_896  -14
    RHS1      connected_order_arc_898  -14
    RHS1      connected_order_arc_900  -14
    RHS1      connected_order_arc_902  -14
    RHS1      connected_order_arc_904  -14
    RHS1      connected_order_arc_906  -14
    RHS1      connected_order_arc_908  -14
    RHS1      connected_order_arc_910  -14
    RHS1      connected_order_arc_912  -14
    RHS1      connected_order_arc_914  -14
    RHS1      connected_order_arc_916  -14
    RHS1      connected_order_arc_918  -14
    RHS1      connected_order_arc_921  -14
    RHS1      connected_order_arc_923  -14
    RHS1      connected_order_arc_925  -14
    RHS1      connected_order_arc_927  -14
    RHS1      connected_order_arc_929  -14
    RHS1      connected_order_arc_931  -14
    RHS1      connected_order_arc_933  -14
    RHS1      connected_order_arc_935  -14
    RHS1      connected_order_arc_937  -14
    RHS1      connected_order_arc_939  -14
    RHS1      connected_order_arc_941  -14
    RHS1      connected_order_arc_943  -14
    RHS1      connected_order_arc_945  -14
    RHS1      connected_order_arc_948  -14
    RHS1      connected_order_arc_950  -14
    RHS1      connected_order_arc_952  -14
    RHS1      connected_order_arc_954  -14
    RHS1      connected_order_arc_956  -14
    RHS1      connected_order_arc_958  -14
    RHS1      connected_order_arc_960  -14
    RHS1      connected_order_arc_962  -14
    RHS1      connected_order_arc_964  -14
    RHS1      connected_order_arc_966  -14
    RHS1      connected_order_arc_968  -14
    RHS1      connected_order_arc_970  -14
    RHS1      connected_order_arc_972  -14
    RHS1      connected_order_arc_975  -14
    RHS1      connected_order_arc_977  -14
    RHS1      connected_order_arc_979  -14
    RHS1      connected_order_arc_981  -14
    RHS1      connected_order_arc_983  -14
    RHS1      connected_order_arc_985  -14
    RHS1      connected_order_arc_987  -14
    RHS1      connected_order_arc_989  -14
    RHS1      connected_order_arc_991  -14
    RHS1      connected_order_arc_993  -14
    RHS1      connected_order_arc_995  -14
    RHS1      connected_order_arc_997  -14
    RHS1      connected_order_arc_999  -14
    RHS1      connected_order_arc_1002  -14
    RHS1      connected_order_arc_1004  -14
    RHS1      connected_order_arc_1006  -14
    RHS1      connected_order_arc_1008  -14
    RHS1      connected_order_arc_1010  -14
    RHS1      connected_order_arc_1012  -14
    RHS1      connected_order_arc_1014  -14
    RHS1      connected_order_arc_1016  -14
    RHS1      connected_order_arc_1018  -14
    RHS1      connected_order_arc_1020  -14
    RHS1      connected_order_arc_1022  -14
    RHS1      connected_order_arc_1024  -14
    RHS1      connected_order_arc_1026  -14
    RHS1      connected_order_arc_1029  -14
    RHS1      connected_order_arc_1031  -14
    RHS1      connected_order_arc_1033  -14
    RHS1      connected_order_arc_1035  -14
    RHS1      connected_order_arc_1037  -14
    RHS1      connected_order_arc_1039  -14
    RHS1      connected_order_arc_1041  -14
    RHS1      connected_order_arc_1043  -14
    RHS1      connected_order_arc_1045  -14
    RHS1      connected_order_arc_1047  -14
    RHS1      connected_order_arc_1049  -14
    RHS1      connected_order_arc_1051  -14
    RHS1      connected_order_arc_1053  -14
    RHS1      connected_order_arc_1056  -14
    RHS1      connected_order_arc_1058  -14
    RHS1      connected_order_arc_1060  -14
    RHS1      connected_order_arc_1062  -14
    RHS1      connected_order_arc_1064  -14
    RHS1      connected_order_arc_1066  -14
    RHS1      connected_order_arc_1068  -14
    RHS1      connected_order_arc_1070  -14
    RHS1      connected_order_arc_1072  -14
    RHS1      connected_order_arc_1074  -14
    RHS1      connected_order_arc_1076  -14
    RHS1      connected_order_arc_1078  -14
    RHS1      connected_order_arc_1080  -14
    RHS1      connected_order_arc_1083  -14
    RHS1      connected_order_arc_1085  -14
    RHS1      connected_order_arc_1087  -14
    RHS1      connected_order_arc_1089  -14
    RHS1      connected_order_arc_1091  -14
    RHS1      connected_order_arc_1093  -14
    RHS1      connected_order_arc_1095  -14
    RHS1      connected_order_arc_1097  -14
    RHS1      connected_order_arc_1099  -14
    RHS1      connected_order_arc_1101  -14
    RHS1      connected_order_arc_1103  -14
    RHS1      connected_order_arc_1105  -14
    RHS1      connected_order_arc_1107  -14
    RHS1      connected_order_arc_1110  -14
    RHS1      connected_order_arc_1112  -14
    RHS1      connected_order_arc_1114  -14
    RHS1      connected_order_arc_1116  -14
    RHS1      connected_order_arc_1118  -14
    RHS1      connected_order_arc_1120  -14
    RHS1      connected_order_arc_1122  -14
    RHS1      connected_order_arc_1124  -14
    RHS1      connected_order_arc_1126  -14
    RHS1      connected_order_arc_1128  -14
    RHS1      connected_order_arc_1130  -14
    RHS1      connected_order_arc_1132  -14
    RHS1      connected_order_arc_1134  -14
    RHS1      connected_order_arc_1137  -14
    RHS1      connected_order_arc_1139  -14
    RHS1      connected_order_arc_1141  -14
    RHS1      connected_order_arc_1143  -14
    RHS1      connected_order_arc_1145  -14
    RHS1      connected_order_arc_1147  -14
    RHS1      connected_order_arc_1149  -14
    RHS1      connected_order_arc_1151  -14
    RHS1      connected_order_arc_1153  -14
    RHS1      connected_order_arc_1155  -14
    RHS1      connected_order_arc_1157  -14
    RHS1      connected_order_arc_1159  -14
    RHS1      connected_order_arc_1161  -14
    RHS1      connected_order_arc_1164  -14
    RHS1      connected_order_arc_1166  -14
    RHS1      connected_order_arc_1168  -14
    RHS1      connected_order_arc_1170  -14
    RHS1      connected_order_arc_1172  -14
    RHS1      connected_order_arc_1174  -14
    RHS1      connected_order_arc_1176  -14
    RHS1      connected_order_arc_1178  -14
    RHS1      connected_order_arc_1180  -14
    RHS1      connected_order_arc_1182  -14
    RHS1      connected_order_arc_1184  -14
    RHS1      connected_order_arc_1186  -14
    RHS1      connected_order_arc_1188  -14
    RHS1      depot_departure_or_bypass_1189  1
    RHS1      depot_return_or_bypass_1190  1
    RHS1      segment_load_conservation_1195  -4
    RHS1      segment_prefix_lb_1196  4
    RHS1      segment_prefix_ub_1197  25
    RHS1      segment_load_conservation_1202  7
    RHS1      segment_prefix_ub_1204  18
    RHS1      segment_load_conservation_1209  -5
    RHS1      segment_prefix_lb_1210  5
    RHS1      segment_prefix_ub_1211  25
    RHS1      segment_load_conservation_1216  3
    RHS1      segment_prefix_ub_1218  22
    RHS1      segment_load_conservation_1223  2
    RHS1      segment_prefix_ub_1225  23
    RHS1      segment_load_conservation_1230  -5
    RHS1      segment_prefix_lb_1231  5
    RHS1      segment_prefix_ub_1232  25
    RHS1      fixed_segment_relative_order_1281  1
    RHS1      fixed_segment_relative_order_1282  1
    RHS1      fixed_segment_relative_order_1283  1
    RHS1      fixed_segment_relative_order_1284  1
    RHS1      fixed_segment_relative_order_1285  1
    RHS1      original_T_including_depot_unload_1286  5465.4966751052
    RHS1      connected_order_arc_1302  -12
    RHS1      connected_order_arc_1304  -12
    RHS1      connected_order_arc_1306  -12
    RHS1      connected_order_arc_1308  -12
    RHS1      connected_order_arc_1310  -12
    RHS1      connected_order_arc_1312  -12
    RHS1      connected_order_arc_1314  -12
    RHS1      connected_order_arc_1316  -12
    RHS1      connected_order_arc_1318  -12
    RHS1      connected_order_arc_1320  -12
    RHS1      connected_order_arc_1322  -12
    RHS1      connected_order_arc_1325  -12
    RHS1      connected_order_arc_1327  -12
    RHS1      connected_order_arc_1329  -12
    RHS1      connected_order_arc_1331  -12
    RHS1      connected_order_arc_1333  -12
    RHS1      connected_order_arc_1335  -12
    RHS1      connected_order_arc_1337  -12
    RHS1      connected_order_arc_1339  -12
    RHS1      connected_order_arc_1341  -12
    RHS1      connected_order_arc_1343  -12
    RHS1      connected_order_arc_1345  -12
    RHS1      connected_order_arc_1348  -12
    RHS1      connected_order_arc_1350  -12
    RHS1      connected_order_arc_1352  -12
    RHS1      connected_order_arc_1354  -12
    RHS1      connected_order_arc_1356  -12
    RHS1      connected_order_arc_1358  -12
    RHS1      connected_order_arc_1360  -12
    RHS1      connected_order_arc_1362  -12
    RHS1      connected_order_arc_1364  -12
    RHS1      connected_order_arc_1366  -12
    RHS1      connected_order_arc_1368  -12
    RHS1      connected_order_arc_1371  -12
    RHS1      connected_order_arc_1373  -12
    RHS1      connected_order_arc_1375  -12
    RHS1      connected_order_arc_1377  -12
    RHS1      connected_order_arc_1379  -12
    RHS1      connected_order_arc_1381  -12
    RHS1      connected_order_arc_1383  -12
    RHS1      connected_order_arc_1385  -12
    RHS1      connected_order_arc_1387  -12
    RHS1      connected_order_arc_1389  -12
    RHS1      connected_order_arc_1391  -12
    RHS1      connected_order_arc_1394  -12
    RHS1      connected_order_arc_1396  -12
    RHS1      connected_order_arc_1398  -12
    RHS1      connected_order_arc_1400  -12
    RHS1      connected_order_arc_1402  -12
    RHS1      connected_order_arc_1404  -12
    RHS1      connected_order_arc_1406  -12
    RHS1      connected_order_arc_1408  -12
    RHS1      connected_order_arc_1410  -12
    RHS1      connected_order_arc_1412  -12
    RHS1      connected_order_arc_1414  -12
    RHS1      connected_order_arc_1417  -12
    RHS1      connected_order_arc_1419  -12
    RHS1      connected_order_arc_1421  -12
    RHS1      connected_order_arc_1423  -12
    RHS1      connected_order_arc_1425  -12
    RHS1      connected_order_arc_1427  -12
    RHS1      connected_order_arc_1429  -12
    RHS1      connected_order_arc_1431  -12
    RHS1      connected_order_arc_1433  -12
    RHS1      connected_order_arc_1435  -12
    RHS1      connected_order_arc_1437  -12
    RHS1      connected_order_arc_1440  -12
    RHS1      connected_order_arc_1442  -12
    RHS1      connected_order_arc_1444  -12
    RHS1      connected_order_arc_1446  -12
    RHS1      connected_order_arc_1448  -12
    RHS1      connected_order_arc_1450  -12
    RHS1      connected_order_arc_1452  -12
    RHS1      connected_order_arc_1454  -12
    RHS1      connected_order_arc_1456  -12
    RHS1      connected_order_arc_1458  -12
    RHS1      connected_order_arc_1460  -12
    RHS1      connected_order_arc_1463  -12
    RHS1      connected_order_arc_1465  -12
    RHS1      connected_order_arc_1467  -12
    RHS1      connected_order_arc_1469  -12
    RHS1      connected_order_arc_1471  -12
    RHS1      connected_order_arc_1473  -12
    RHS1      connected_order_arc_1475  -12
    RHS1      connected_order_arc_1477  -12
    RHS1      connected_order_arc_1479  -12
    RHS1      connected_order_arc_1481  -12
    RHS1      connected_order_arc_1483  -12
    RHS1      connected_order_arc_1486  -12
    RHS1      connected_order_arc_1488  -12
    RHS1      connected_order_arc_1490  -12
    RHS1      connected_order_arc_1492  -12
    RHS1      connected_order_arc_1494  -12
    RHS1      connected_order_arc_1496  -12
    RHS1      connected_order_arc_1498  -12
    RHS1      connected_order_arc_1500  -12
    RHS1      connected_order_arc_1502  -12
    RHS1      connected_order_arc_1504  -12
    RHS1      connected_order_arc_1506  -12
    RHS1      connected_order_arc_1509  -12
    RHS1      connected_order_arc_1511  -12
    RHS1      connected_order_arc_1513  -12
    RHS1      connected_order_arc_1515  -12
    RHS1      connected_order_arc_1517  -12
    RHS1      connected_order_arc_1519  -12
    RHS1      connected_order_arc_1521  -12
    RHS1      connected_order_arc_1523  -12
    RHS1      connected_order_arc_1525  -12
    RHS1      connected_order_arc_1527  -12
    RHS1      connected_order_arc_1529  -12
    RHS1      connected_order_arc_1532  -12
    RHS1      connected_order_arc_1534  -12
    RHS1      connected_order_arc_1536  -12
    RHS1      connected_order_arc_1538  -12
    RHS1      connected_order_arc_1540  -12
    RHS1      connected_order_arc_1542  -12
    RHS1      connected_order_arc_1544  -12
    RHS1      connected_order_arc_1546  -12
    RHS1      connected_order_arc_1548  -12
    RHS1      connected_order_arc_1550  -12
    RHS1      connected_order_arc_1552  -12
    RHS1      connected_order_arc_1555  -12
    RHS1      connected_order_arc_1557  -12
    RHS1      connected_order_arc_1559  -12
    RHS1      connected_order_arc_1561  -12
    RHS1      connected_order_arc_1563  -12
    RHS1      connected_order_arc_1565  -12
    RHS1      connected_order_arc_1567  -12
    RHS1      connected_order_arc_1569  -12
    RHS1      connected_order_arc_1571  -12
    RHS1      connected_order_arc_1573  -12
    RHS1      connected_order_arc_1575  -12
    RHS1      depot_departure_or_bypass_1576  1
    RHS1      depot_return_or_bypass_1577  1
    RHS1      segment_load_conservation_1582  3
    RHS1      segment_prefix_ub_1584  27
    RHS1      segment_load_conservation_1589  3
    RHS1      segment_prefix_ub_1591  27
    RHS1      segment_load_conservation_1596  -2
    RHS1      segment_prefix_lb_1597  2
    RHS1      segment_prefix_ub_1598  30
    RHS1      segment_load_conservation_1603  -2
    RHS1      segment_prefix_lb_1604  2
    RHS1      segment_prefix_ub_1605  24
    RHS1      fixed_segment_relative_order_1654  1
    RHS1      fixed_segment_relative_order_1655  1
    RHS1      fixed_segment_relative_order_1656  1
    RHS1      original_T_including_depot_unload_1657  4.2212502081486091e+03
BOUNDS
 LO BND1      t         2.4785097468354542e-02
 UP BND1      t         4.1921746074037140e-02
 UP BND1      q         4.9007157375771537e-01
 BV BND1      x_27_0  
 UP BND1      w_27_0    4.1921746074037140e-02
 BV BND1      x_27_1  
 UP BND1      w_27_1    4.1921746074037140e-02
 BV BND1      x_27_2  
 UP BND1      w_27_2    4.1921746074037140e-02
 BV BND1      x_27_3  
 UP BND1      w_27_3    4.1921746074037140e-02
 BV BND1      x_27_4  
 UP BND1      w_27_4    4.1921746074037140e-02
 BV BND1      x_27_5  
 UP BND1      w_27_5    4.1921746074037140e-02
 BV BND1      x_27_6  
 UP BND1      w_27_6    4.1921746074037140e-02
 BV BND1      x_27_7  
 UP BND1      w_27_7    4.1921746074037140e-02
 BV BND1      x_27_8  
 UP BND1      w_27_8    4.1921746074037140e-02
 BV BND1      x_27_9  
 UP BND1      w_27_9    4.1921746074037140e-02
 BV BND1      x_27_10 
 UP BND1      w_27_10   4.1921746074037140e-02
 BV BND1      x_27_11 
 UP BND1      w_27_11   4.1921746074037140e-02
 BV BND1      x_27_12 
 UP BND1      w_27_12   4.1921746074037140e-02
 BV BND1      x_27_13 
 UP BND1      w_27_13   4.1921746074037140e-02
 BV BND1      x_27_14 
 UP BND1      w_27_14   4.1921746074037140e-02
 BV BND1      x_27_15 
 UP BND1      w_27_15   4.1921746074037140e-02
 UP BND1      rho_27    1
 BV BND1      x_24_0  
 UP BND1      w_24_0    4.1921746074037140e-02
 BV BND1      x_24_1  
 UP BND1      w_24_1    4.1921746074037140e-02
 BV BND1      x_24_2  
 UP BND1      w_24_2    4.1921746074037140e-02
 BV BND1      x_24_3  
 UP BND1      w_24_3    4.1921746074037140e-02
 BV BND1      x_24_4  
 UP BND1      w_24_4    4.1921746074037140e-02
 BV BND1      x_24_5  
 UP BND1      w_24_5    4.1921746074037140e-02
 BV BND1      x_24_6  
 UP BND1      w_24_6    4.1921746074037140e-02
 BV BND1      x_24_7  
 UP BND1      w_24_7    4.1921746074037140e-02
 BV BND1      x_24_8  
 UP BND1      w_24_8    4.1921746074037140e-02
 BV BND1      x_24_9  
 UP BND1      w_24_9    4.1921746074037140e-02
 BV BND1      x_24_10 
 UP BND1      w_24_10   4.1921746074037140e-02
 BV BND1      x_24_11 
 UP BND1      w_24_11   4.1921746074037140e-02
 BV BND1      x_24_12 
 UP BND1      w_24_12   4.1921746074037140e-02
 BV BND1      x_24_13 
 UP BND1      w_24_13   4.1921746074037140e-02
 BV BND1      x_24_14 
 UP BND1      w_24_14   4.1921746074037140e-02
 BV BND1      x_24_15 
 UP BND1      w_24_15   4.1921746074037140e-02
 UP BND1      rho_24    1
 BV BND1      x_31_0  
 UP BND1      w_31_0    4.1921746074037140e-02
 BV BND1      x_31_1  
 UP BND1      w_31_1    4.1921746074037140e-02
 BV BND1      x_31_2  
 UP BND1      w_31_2    4.1921746074037140e-02
 BV BND1      x_31_3  
 UP BND1      w_31_3    4.1921746074037140e-02
 BV BND1      x_31_4  
 UP BND1      w_31_4    4.1921746074037140e-02
 BV BND1      x_31_5  
 UP BND1      w_31_5    4.1921746074037140e-02
 BV BND1      x_31_6  
 UP BND1      w_31_6    4.1921746074037140e-02
 BV BND1      x_31_7  
 UP BND1      w_31_7    4.1921746074037140e-02
 BV BND1      x_31_8  
 UP BND1      w_31_8    4.1921746074037140e-02
 BV BND1      x_31_9  
 UP BND1      w_31_9    4.1921746074037140e-02
 BV BND1      x_31_10 
 UP BND1      w_31_10   4.1921746074037140e-02
 BV BND1      x_31_11 
 UP BND1      w_31_11   4.1921746074037140e-02
 BV BND1      x_31_12 
 UP BND1      w_31_12   4.1921746074037140e-02
 UP BND1      rho_31    1
 BV BND1      x_34_0  
 UP BND1      w_34_0    4.1921746074037140e-02
 BV BND1      x_34_1  
 UP BND1      w_34_1    4.1921746074037140e-02
 BV BND1      x_34_2  
 UP BND1      w_34_2    4.1921746074037140e-02
 BV BND1      x_34_3  
 UP BND1      w_34_3    4.1921746074037140e-02
 BV BND1      x_34_4  
 UP BND1      w_34_4    4.1921746074037140e-02
 BV BND1      x_34_5  
 UP BND1      w_34_5    4.1921746074037140e-02
 BV BND1      x_34_6  
 UP BND1      w_34_6    4.1921746074037140e-02
 BV BND1      x_34_7  
 UP BND1      w_34_7    4.1921746074037140e-02
 BV BND1      x_34_8  
 UP BND1      w_34_8    4.1921746074037140e-02
 BV BND1      x_34_9  
 UP BND1      w_34_9    4.1921746074037140e-02
 BV BND1      x_34_10 
 UP BND1      w_34_10   4.1921746074037140e-02
 BV BND1      x_34_11 
 UP BND1      w_34_11   4.1921746074037140e-02
 UP BND1      rho_34    1
 BV BND1      x_16_0  
 UP BND1      w_16_0    4.1921746074037140e-02
 BV BND1      x_16_1  
 UP BND1      w_16_1    4.1921746074037140e-02
 BV BND1      x_16_2  
 UP BND1      w_16_2    4.1921746074037140e-02
 BV BND1      x_16_3  
 UP BND1      w_16_3    4.1921746074037140e-02
 BV BND1      x_16_4  
 UP BND1      w_16_4    4.1921746074037140e-02
 BV BND1      x_16_5  
 UP BND1      w_16_5    4.1921746074037140e-02
 BV BND1      x_16_6  
 UP BND1      w_16_6    4.1921746074037140e-02
 BV BND1      x_16_7  
 UP BND1      w_16_7    4.1921746074037140e-02
 BV BND1      x_16_8  
 UP BND1      w_16_8    4.1921746074037140e-02
 BV BND1      x_16_9  
 UP BND1      w_16_9    4.1921746074037140e-02
 BV BND1      x_16_10 
 UP BND1      w_16_10   4.1921746074037140e-02
 BV BND1      x_16_11 
 UP BND1      w_16_11   4.1921746074037140e-02
 BV BND1      x_16_12 
 UP BND1      w_16_12   4.1921746074037140e-02
 UP BND1      rho_16    1
 BV BND1      x_29_0  
 UP BND1      w_29_0    4.1921746074037140e-02
 BV BND1      x_29_1  
 UP BND1      w_29_1    4.1921746074037140e-02
 BV BND1      x_29_2  
 UP BND1      w_29_2    4.1921746074037140e-02
 BV BND1      x_29_3  
 UP BND1      w_29_3    4.1921746074037140e-02
 BV BND1      x_29_4  
 UP BND1      w_29_4    4.1921746074037140e-02
 BV BND1      x_29_5  
 UP BND1      w_29_5    4.1921746074037140e-02
 BV BND1      x_29_6  
 UP BND1      w_29_6    4.1921746074037140e-02
 BV BND1      x_29_7  
 UP BND1      w_29_7    4.1921746074037140e-02
 BV BND1      x_29_8  
 UP BND1      w_29_8    4.1921746074037140e-02
 BV BND1      x_29_9  
 UP BND1      w_29_9    4.1921746074037140e-02
 BV BND1      x_29_10 
 UP BND1      w_29_10   4.1921746074037140e-02
 BV BND1      x_29_11 
 UP BND1      w_29_11   4.1921746074037140e-02
 BV BND1      x_29_12 
 UP BND1      w_29_12   4.1921746074037140e-02
 BV BND1      x_29_13 
 UP BND1      w_29_13   4.1921746074037140e-02
 BV BND1      x_29_14 
 UP BND1      w_29_14   4.1921746074037140e-02
 BV BND1      x_29_15 
 UP BND1      w_29_15   4.1921746074037140e-02
 UP BND1      rho_29    1
 BV BND1      x_32_0  
 UP BND1      w_32_0    4.1921746074037140e-02
 BV BND1      x_32_1  
 UP BND1      w_32_1    4.1921746074037140e-02
 BV BND1      x_32_2  
 UP BND1      w_32_2    4.1921746074037140e-02
 BV BND1      x_32_3  
 UP BND1      w_32_3    4.1921746074037140e-02
 BV BND1      x_32_4  
 UP BND1      w_32_4    4.1921746074037140e-02
 BV BND1      x_32_5  
 UP BND1      w_32_5    4.1921746074037140e-02
 BV BND1      x_32_6  
 UP BND1      w_32_6    4.1921746074037140e-02
 BV BND1      x_32_7  
 UP BND1      w_32_7    4.1921746074037140e-02
 BV BND1      x_32_8  
 UP BND1      w_32_8    4.1921746074037140e-02
 BV BND1      x_32_9  
 UP BND1      w_32_9    4.1921746074037140e-02
 BV BND1      x_32_10 
 UP BND1      w_32_10   4.1921746074037140e-02
 BV BND1      x_32_11 
 UP BND1      w_32_11   4.1921746074037140e-02
 BV BND1      x_32_12 
 UP BND1      w_32_12   4.1921746074037140e-02
 UP BND1      rho_32    1
 BV BND1      x_33_0  
 UP BND1      w_33_0    4.1921746074037140e-02
 BV BND1      x_33_1  
 UP BND1      w_33_1    4.1921746074037140e-02
 BV BND1      x_33_2  
 UP BND1      w_33_2    4.1921746074037140e-02
 BV BND1      x_33_3  
 UP BND1      w_33_3    4.1921746074037140e-02
 BV BND1      x_33_4  
 UP BND1      w_33_4    4.1921746074037140e-02
 BV BND1      x_33_5  
 UP BND1      w_33_5    4.1921746074037140e-02
 BV BND1      x_33_6  
 UP BND1      w_33_6    4.1921746074037140e-02
 BV BND1      x_33_7  
 UP BND1      w_33_7    4.1921746074037140e-02
 BV BND1      x_33_8  
 UP BND1      w_33_8    4.1921746074037140e-02
 BV BND1      x_33_9  
 UP BND1      w_33_9    4.1921746074037140e-02
 BV BND1      x_33_10 
 UP BND1      w_33_10   4.1921746074037140e-02
 BV BND1      x_33_11 
 UP BND1      w_33_11   4.1921746074037140e-02
 BV BND1      x_33_12 
 UP BND1      w_33_12   4.1921746074037140e-02
 BV BND1      x_33_13 
 UP BND1      w_33_13   4.1921746074037140e-02
 BV BND1      x_33_14 
 UP BND1      w_33_14   4.1921746074037140e-02
 BV BND1      x_33_15 
 UP BND1      w_33_15   4.1921746074037140e-02
 BV BND1      x_33_16 
 UP BND1      w_33_16   4.1921746074037140e-02
 UP BND1      rho_33    1
 UP BND1      a_27_24   1
 UP BND1      a_27_31   1
 UP BND1      a_27_34   1
 UP BND1      a_27_16   1
 UP BND1      a_27_29   1
 UP BND1      a_27_32   1
 UP BND1      a_27_33   1
 UP BND1      a_24_31   1
 UP BND1      a_24_34   1
 UP BND1      a_24_16   1
 UP BND1      a_24_29   1
 UP BND1      a_24_32   1
 UP BND1      a_24_33   1
 UP BND1      a_31_34   1
 UP BND1      a_31_16   1
 UP BND1      a_31_29   1
 UP BND1      a_31_32   1
 UP BND1      a_31_33   1
 UP BND1      a_34_16   1
 UP BND1      a_34_29   1
 UP BND1      a_34_32   1
 UP BND1      a_34_33   1
 UP BND1      a_16_29   1
 UP BND1      a_16_32   1
 UP BND1      a_16_33   1
 UP BND1      a_29_32   1
 UP BND1      a_29_33   1
 UP BND1      a_32_33   1
 BV BND1      service_0_27_0
 BV BND1      service_0_27_1
 BV BND1      service_0_27_2
 BV BND1      service_0_27_3
 BV BND1      service_0_27_4
 BV BND1      service_0_27_5
 BV BND1      service_0_27_6
 BV BND1      service_0_27_7
 BV BND1      service_0_27_8
 BV BND1      service_0_27_9
 BV BND1      service_0_27_10
 BV BND1      service_0_27_12
 BV BND1      service_0_27_13
 BV BND1      service_0_27_14
 BV BND1      service_0_27_15
 BV BND1      service_1_27_0
 BV BND1      service_1_27_1
 BV BND1      service_1_27_2
 BV BND1      service_1_27_3
 BV BND1      service_1_27_4
 BV BND1      service_1_27_5
 BV BND1      service_1_27_6
 BV BND1      service_1_27_7
 BV BND1      service_1_27_8
 BV BND1      service_1_27_9
 BV BND1      service_1_27_10
 BV BND1      service_1_27_12
 BV BND1      service_1_27_13
 BV BND1      service_1_27_14
 BV BND1      service_1_27_15
 BV BND1      service_2_27_0
 BV BND1      service_2_27_1
 BV BND1      service_2_27_2
 BV BND1      service_2_27_3
 BV BND1      service_2_27_4
 BV BND1      service_2_27_5
 BV BND1      service_2_27_6
 BV BND1      service_2_27_7
 BV BND1      service_2_27_8
 BV BND1      service_2_27_9
 BV BND1      service_2_27_10
 BV BND1      service_2_27_12
 BV BND1      service_2_27_13
 BV BND1      service_2_27_14
 BV BND1      service_2_27_15
 BV BND1      service_0_24_0
 BV BND1      service_0_24_1
 BV BND1      service_0_24_2
 BV BND1      service_0_24_3
 BV BND1      service_0_24_4
 BV BND1      service_0_24_5
 BV BND1      service_0_24_6
 BV BND1      service_0_24_7
 BV BND1      service_0_24_8
 BV BND1      service_0_24_9
 BV BND1      service_0_24_10
 BV BND1      service_0_24_12
 BV BND1      service_0_24_13
 BV BND1      service_0_24_14
 BV BND1      service_0_24_15
 BV BND1      service_1_24_0
 BV BND1      service_1_24_1
 BV BND1      service_1_24_2
 BV BND1      service_1_24_3
 BV BND1      service_1_24_4
 BV BND1      service_1_24_5
 BV BND1      service_1_24_6
 BV BND1      service_1_24_7
 BV BND1      service_1_24_8
 BV BND1      service_1_24_9
 BV BND1      service_1_24_10
 BV BND1      service_1_24_12
 BV BND1      service_1_24_13
 BV BND1      service_1_24_14
 BV BND1      service_1_24_15
 BV BND1      service_2_24_0
 BV BND1      service_2_24_1
 BV BND1      service_2_24_2
 BV BND1      service_2_24_3
 BV BND1      service_2_24_4
 BV BND1      service_2_24_5
 BV BND1      service_2_24_6
 BV BND1      service_2_24_7
 BV BND1      service_2_24_8
 BV BND1      service_2_24_9
 BV BND1      service_2_24_10
 BV BND1      service_2_24_12
 BV BND1      service_2_24_13
 BV BND1      service_2_24_14
 BV BND1      service_2_24_15
 BV BND1      service_0_31_0
 BV BND1      service_0_31_1
 BV BND1      service_0_31_3
 BV BND1      service_0_31_4
 BV BND1      service_0_31_5
 BV BND1      service_0_31_6
 BV BND1      service_0_31_7
 BV BND1      service_0_31_8
 BV BND1      service_0_31_9
 BV BND1      service_0_31_10
 BV BND1      service_0_31_11
 BV BND1      service_0_31_12
 BV BND1      service_1_31_0
 BV BND1      service_1_31_1
 BV BND1      service_1_31_3
 BV BND1      service_1_31_4
 BV BND1      service_1_31_5
 BV BND1      service_1_31_6
 BV BND1      service_1_31_7
 BV BND1      service_1_31_8
 BV BND1      service_1_31_9
 BV BND1      service_1_31_10
 BV BND1      service_1_31_11
 BV BND1      service_1_31_12
 BV BND1      service_2_31_0
 BV BND1      service_2_31_1
 BV BND1      service_2_31_3
 BV BND1      service_2_31_4
 BV BND1      service_2_31_5
 BV BND1      service_2_31_6
 BV BND1      service_2_31_7
 BV BND1      service_2_31_8
 BV BND1      service_2_31_9
 BV BND1      service_2_31_10
 BV BND1      service_2_31_11
 BV BND1      service_2_31_12
 BV BND1      service_0_34_0
 BV BND1      service_0_34_2
 BV BND1      service_0_34_3
 BV BND1      service_0_34_4
 BV BND1      service_0_34_5
 BV BND1      service_0_34_6
 BV BND1      service_0_34_7
 BV BND1      service_0_34_8
 BV BND1      service_0_34_9
 BV BND1      service_0_34_10
 BV BND1      service_0_34_11
 BV BND1      service_1_34_0
 BV BND1      service_1_34_2
 BV BND1      service_1_34_3
 BV BND1      service_1_34_4
 BV BND1      service_1_34_5
 BV BND1      service_1_34_6
 BV BND1      service_1_34_7
 BV BND1      service_1_34_8
 BV BND1      service_1_34_9
 BV BND1      service_1_34_10
 BV BND1      service_1_34_11
 BV BND1      service_2_34_0
 BV BND1      service_2_34_2
 BV BND1      service_2_34_3
 BV BND1      service_2_34_4
 BV BND1      service_2_34_5
 BV BND1      service_2_34_6
 BV BND1      service_2_34_7
 BV BND1      service_2_34_8
 BV BND1      service_2_34_9
 BV BND1      service_2_34_10
 BV BND1      service_2_34_11
 BV BND1      service_0_16_0
 BV BND1      service_0_16_2
 BV BND1      service_0_16_3
 BV BND1      service_0_16_4
 BV BND1      service_0_16_5
 BV BND1      service_0_16_6
 BV BND1      service_0_16_7
 BV BND1      service_0_16_8
 BV BND1      service_0_16_9
 BV BND1      service_0_16_10
 BV BND1      service_0_16_11
 BV BND1      service_0_16_12
 BV BND1      service_1_16_0
 BV BND1      service_1_16_2
 BV BND1      service_1_16_3
 BV BND1      service_1_16_4
 BV BND1      service_1_16_5
 BV BND1      service_1_16_6
 BV BND1      service_1_16_7
 BV BND1      service_1_16_8
 BV BND1      service_1_16_9
 BV BND1      service_1_16_10
 BV BND1      service_1_16_11
 BV BND1      service_1_16_12
 BV BND1      service_2_16_0
 BV BND1      service_2_16_2
 BV BND1      service_2_16_3
 BV BND1      service_2_16_4
 BV BND1      service_2_16_5
 BV BND1      service_2_16_6
 BV BND1      service_2_16_7
 BV BND1      service_2_16_8
 BV BND1      service_2_16_9
 BV BND1      service_2_16_10
 BV BND1      service_2_16_11
 BV BND1      service_2_16_12
 BV BND1      service_0_29_0
 BV BND1      service_0_29_1
 BV BND1      service_0_29_2
 BV BND1      service_0_29_3
 BV BND1      service_0_29_4
 BV BND1      service_0_29_5
 BV BND1      service_0_29_6
 BV BND1      service_0_29_7
 BV BND1      service_0_29_8
 BV BND1      service_0_29_9
 BV BND1      service_0_29_10
 BV BND1      service_0_29_12
 BV BND1      service_0_29_13
 BV BND1      service_0_29_14
 BV BND1      service_0_29_15
 BV BND1      service_1_29_0
 BV BND1      service_1_29_1
 BV BND1      service_1_29_2
 BV BND1      service_1_29_3
 BV BND1      service_1_29_4
 BV BND1      service_1_29_5
 BV BND1      service_1_29_6
 BV BND1      service_1_29_7
 BV BND1      service_1_29_8
 BV BND1      service_1_29_9
 BV BND1      service_1_29_10
 BV BND1      service_1_29_12
 BV BND1      service_1_29_13
 BV BND1      service_1_29_14
 BV BND1      service_1_29_15
 BV BND1      service_2_29_0
 BV BND1      service_2_29_1
 BV BND1      service_2_29_2
 BV BND1      service_2_29_3
 BV BND1      service_2_29_4
 BV BND1      service_2_29_5
 BV BND1      service_2_29_6
 BV BND1      service_2_29_7
 BV BND1      service_2_29_8
 BV BND1      service_2_29_9
 BV BND1      service_2_29_10
 BV BND1      service_2_29_12
 BV BND1      service_2_29_13
 BV BND1      service_2_29_14
 BV BND1      service_2_29_15
 BV BND1      service_0_32_1
 BV BND1      service_0_32_2
 BV BND1      service_0_32_3
 BV BND1      service_0_32_4
 BV BND1      service_0_32_5
 BV BND1      service_0_32_6
 BV BND1      service_0_32_7
 BV BND1      service_0_32_8
 BV BND1      service_0_32_9
 BV BND1      service_0_32_10
 BV BND1      service_0_32_11
 BV BND1      service_0_32_12
 BV BND1      service_1_32_1
 BV BND1      service_1_32_2
 BV BND1      service_1_32_3
 BV BND1      service_1_32_4
 BV BND1      service_1_32_5
 BV BND1      service_1_32_6
 BV BND1      service_1_32_7
 BV BND1      service_1_32_8
 BV BND1      service_1_32_9
 BV BND1      service_1_32_10
 BV BND1      service_1_32_11
 BV BND1      service_1_32_12
 BV BND1      service_2_32_1
 BV BND1      service_2_32_2
 BV BND1      service_2_32_3
 BV BND1      service_2_32_4
 BV BND1      service_2_32_5
 BV BND1      service_2_32_6
 BV BND1      service_2_32_7
 BV BND1      service_2_32_8
 BV BND1      service_2_32_9
 BV BND1      service_2_32_10
 BV BND1      service_2_32_11
 BV BND1      service_2_32_12
 BV BND1      service_0_33_0
 BV BND1      service_0_33_2
 BV BND1      service_0_33_3
 BV BND1      service_0_33_4
 BV BND1      service_0_33_5
 BV BND1      service_0_33_6
 BV BND1      service_0_33_7
 BV BND1      service_0_33_8
 BV BND1      service_0_33_9
 BV BND1      service_0_33_10
 BV BND1      service_0_33_11
 BV BND1      service_0_33_12
 BV BND1      service_0_33_13
 BV BND1      service_0_33_14
 BV BND1      service_0_33_15
 BV BND1      service_0_33_16
 BV BND1      service_1_33_0
 BV BND1      service_1_33_2
 BV BND1      service_1_33_3
 BV BND1      service_1_33_4
 BV BND1      service_1_33_5
 BV BND1      service_1_33_6
 BV BND1      service_1_33_7
 BV BND1      service_1_33_8
 BV BND1      service_1_33_9
 BV BND1      service_1_33_10
 BV BND1      service_1_33_11
 BV BND1      service_1_33_12
 BV BND1      service_1_33_13
 BV BND1      service_1_33_14
 BV BND1      service_1_33_15
 BV BND1      service_1_33_16
 BV BND1      service_2_33_0
 BV BND1      service_2_33_2
 BV BND1      service_2_33_3
 BV BND1      service_2_33_4
 BV BND1      service_2_33_5
 BV BND1      service_2_33_6
 BV BND1      service_2_33_7
 BV BND1      service_2_33_8
 BV BND1      service_2_33_9
 BV BND1      service_2_33_10
 BV BND1      service_2_33_11
 BV BND1      service_2_33_12
 BV BND1      service_2_33_13
 BV BND1      service_2_33_14
 BV BND1      service_2_33_15
 BV BND1      service_2_33_16
 FX BND1      visit_0_1  1
 UP BND1      order_0_1  12
 FX BND1      visit_0_2  1
 UP BND1      order_0_2  12
 FX BND1      visit_0_3  1
 UP BND1      order_0_3  12
 FX BND1      visit_0_4  1
 UP BND1      order_0_4  12
 UP BND1      visit_0_15  1
 UP BND1      order_0_15  12
 UP BND1      visit_0_16  1
 UP BND1      order_0_16  12
 UP BND1      visit_0_17  1
 UP BND1      order_0_17  12
 UP BND1      visit_0_18  1
 UP BND1      order_0_18  12
 UP BND1      visit_0_19  1
 UP BND1      order_0_19  12
 UP BND1      visit_0_20  1
 UP BND1      order_0_20  12
 UP BND1      visit_0_21  1
 UP BND1      order_0_21  12
 UP BND1      visit_0_22  1
 UP BND1      order_0_22  12
 BV BND1      arc_0_0_0
 FX BND1      load_0_0_0  0
 BV BND1      arc_0_0_1
 FX BND1      load_0_0_1  0
 BV BND1      arc_0_0_2
 FX BND1      load_0_0_2  0
 BV BND1      arc_0_0_3
 FX BND1      load_0_0_3  0
 BV BND1      arc_0_0_4
 FX BND1      load_0_0_4  0
 BV BND1      arc_0_0_15
 FX BND1      load_0_0_15  0
 BV BND1      arc_0_0_16
 FX BND1      load_0_0_16  0
 BV BND1      arc_0_0_17
 FX BND1      load_0_0_17  0
 BV BND1      arc_0_0_18
 FX BND1      load_0_0_18  0
 BV BND1      arc_0_0_19
 FX BND1      load_0_0_19  0
 BV BND1      arc_0_0_20
 FX BND1      load_0_0_20  0
 BV BND1      arc_0_0_21
 FX BND1      load_0_0_21  0
 BV BND1      arc_0_0_22
 FX BND1      load_0_0_22  0
 BV BND1      arc_0_1_0
 UP BND1      load_0_1_0  20
 BV BND1      arc_0_1_2
 UP BND1      load_0_1_2  20
 BV BND1      arc_0_1_3
 UP BND1      load_0_1_3  20
 BV BND1      arc_0_1_4
 UP BND1      load_0_1_4  20
 BV BND1      arc_0_1_15
 UP BND1      load_0_1_15  20
 BV BND1      arc_0_1_16
 UP BND1      load_0_1_16  20
 BV BND1      arc_0_1_17
 UP BND1      load_0_1_17  20
 BV BND1      arc_0_1_18
 UP BND1      load_0_1_18  20
 BV BND1      arc_0_1_19
 UP BND1      load_0_1_19  20
 BV BND1      arc_0_1_20
 UP BND1      load_0_1_20  20
 BV BND1      arc_0_1_21
 UP BND1      load_0_1_21  20
 BV BND1      arc_0_1_22
 UP BND1      load_0_1_22  20
 BV BND1      arc_0_2_0
 UP BND1      load_0_2_0  20
 BV BND1      arc_0_2_1
 UP BND1      load_0_2_1  20
 BV BND1      arc_0_2_3
 UP BND1      load_0_2_3  20
 BV BND1      arc_0_2_4
 UP BND1      load_0_2_4  20
 BV BND1      arc_0_2_15
 UP BND1      load_0_2_15  20
 BV BND1      arc_0_2_16
 UP BND1      load_0_2_16  20
 BV BND1      arc_0_2_17
 UP BND1      load_0_2_17  20
 BV BND1      arc_0_2_18
 UP BND1      load_0_2_18  20
 BV BND1      arc_0_2_19
 UP BND1      load_0_2_19  20
 BV BND1      arc_0_2_20
 UP BND1      load_0_2_20  20
 BV BND1      arc_0_2_21
 UP BND1      load_0_2_21  20
 BV BND1      arc_0_2_22
 UP BND1      load_0_2_22  20
 BV BND1      arc_0_3_0
 UP BND1      load_0_3_0  20
 BV BND1      arc_0_3_1
 UP BND1      load_0_3_1  20
 BV BND1      arc_0_3_2
 UP BND1      load_0_3_2  20
 BV BND1      arc_0_3_4
 UP BND1      load_0_3_4  20
 BV BND1      arc_0_3_15
 UP BND1      load_0_3_15  20
 BV BND1      arc_0_3_16
 UP BND1      load_0_3_16  20
 BV BND1      arc_0_3_17
 UP BND1      load_0_3_17  20
 BV BND1      arc_0_3_18
 UP BND1      load_0_3_18  20
 BV BND1      arc_0_3_19
 UP BND1      load_0_3_19  20
 BV BND1      arc_0_3_20
 UP BND1      load_0_3_20  20
 BV BND1      arc_0_3_21
 UP BND1      load_0_3_21  20
 BV BND1      arc_0_3_22
 UP BND1      load_0_3_22  20
 BV BND1      arc_0_4_0
 UP BND1      load_0_4_0  20
 BV BND1      arc_0_4_1
 UP BND1      load_0_4_1  20
 BV BND1      arc_0_4_2
 UP BND1      load_0_4_2  20
 BV BND1      arc_0_4_3
 UP BND1      load_0_4_3  20
 BV BND1      arc_0_4_15
 UP BND1      load_0_4_15  20
 BV BND1      arc_0_4_16
 UP BND1      load_0_4_16  20
 BV BND1      arc_0_4_17
 UP BND1      load_0_4_17  20
 BV BND1      arc_0_4_18
 UP BND1      load_0_4_18  20
 BV BND1      arc_0_4_19
 UP BND1      load_0_4_19  20
 BV BND1      arc_0_4_20
 UP BND1      load_0_4_20  20
 BV BND1      arc_0_4_21
 UP BND1      load_0_4_21  20
 BV BND1      arc_0_4_22
 UP BND1      load_0_4_22  20
 BV BND1      arc_0_15_0
 UP BND1      load_0_15_0  20
 BV BND1      arc_0_15_1
 UP BND1      load_0_15_1  20
 BV BND1      arc_0_15_2
 UP BND1      load_0_15_2  20
 BV BND1      arc_0_15_3
 UP BND1      load_0_15_3  20
 BV BND1      arc_0_15_4
 UP BND1      load_0_15_4  20
 BV BND1      arc_0_15_16
 UP BND1      load_0_15_16  20
 BV BND1      arc_0_15_17
 UP BND1      load_0_15_17  20
 BV BND1      arc_0_15_18
 UP BND1      load_0_15_18  20
 BV BND1      arc_0_15_19
 UP BND1      load_0_15_19  20
 BV BND1      arc_0_15_20
 UP BND1      load_0_15_20  20
 BV BND1      arc_0_15_21
 UP BND1      load_0_15_21  20
 BV BND1      arc_0_15_22
 UP BND1      load_0_15_22  20
 BV BND1      arc_0_16_0
 UP BND1      load_0_16_0  20
 BV BND1      arc_0_16_1
 UP BND1      load_0_16_1  20
 BV BND1      arc_0_16_2
 UP BND1      load_0_16_2  20
 BV BND1      arc_0_16_3
 UP BND1      load_0_16_3  20
 BV BND1      arc_0_16_4
 UP BND1      load_0_16_4  20
 BV BND1      arc_0_16_15
 UP BND1      load_0_16_15  20
 BV BND1      arc_0_16_17
 UP BND1      load_0_16_17  20
 BV BND1      arc_0_16_18
 UP BND1      load_0_16_18  20
 BV BND1      arc_0_16_19
 UP BND1      load_0_16_19  20
 BV BND1      arc_0_16_20
 UP BND1      load_0_16_20  20
 BV BND1      arc_0_16_21
 UP BND1      load_0_16_21  20
 BV BND1      arc_0_16_22
 UP BND1      load_0_16_22  20
 BV BND1      arc_0_17_0
 UP BND1      load_0_17_0  20
 BV BND1      arc_0_17_1
 UP BND1      load_0_17_1  20
 BV BND1      arc_0_17_2
 UP BND1      load_0_17_2  20
 BV BND1      arc_0_17_3
 UP BND1      load_0_17_3  20
 BV BND1      arc_0_17_4
 UP BND1      load_0_17_4  20
 BV BND1      arc_0_17_15
 UP BND1      load_0_17_15  20
 BV BND1      arc_0_17_16
 UP BND1      load_0_17_16  20
 BV BND1      arc_0_17_18
 UP BND1      load_0_17_18  20
 BV BND1      arc_0_17_19
 UP BND1      load_0_17_19  20
 BV BND1      arc_0_17_20
 UP BND1      load_0_17_20  20
 BV BND1      arc_0_17_21
 UP BND1      load_0_17_21  20
 BV BND1      arc_0_17_22
 UP BND1      load_0_17_22  20
 BV BND1      arc_0_18_0
 UP BND1      load_0_18_0  20
 BV BND1      arc_0_18_1
 UP BND1      load_0_18_1  20
 BV BND1      arc_0_18_2
 UP BND1      load_0_18_2  20
 BV BND1      arc_0_18_3
 UP BND1      load_0_18_3  20
 BV BND1      arc_0_18_4
 UP BND1      load_0_18_4  20
 BV BND1      arc_0_18_15
 UP BND1      load_0_18_15  20
 BV BND1      arc_0_18_16
 UP BND1      load_0_18_16  20
 BV BND1      arc_0_18_17
 UP BND1      load_0_18_17  20
 BV BND1      arc_0_18_19
 UP BND1      load_0_18_19  20
 BV BND1      arc_0_18_20
 UP BND1      load_0_18_20  20
 BV BND1      arc_0_18_21
 UP BND1      load_0_18_21  20
 BV BND1      arc_0_18_22
 UP BND1      load_0_18_22  20
 BV BND1      arc_0_19_0
 UP BND1      load_0_19_0  20
 BV BND1      arc_0_19_1
 UP BND1      load_0_19_1  20
 BV BND1      arc_0_19_2
 UP BND1      load_0_19_2  20
 BV BND1      arc_0_19_3
 UP BND1      load_0_19_3  20
 BV BND1      arc_0_19_4
 UP BND1      load_0_19_4  20
 BV BND1      arc_0_19_15
 UP BND1      load_0_19_15  20
 BV BND1      arc_0_19_16
 UP BND1      load_0_19_16  20
 BV BND1      arc_0_19_17
 UP BND1      load_0_19_17  20
 BV BND1      arc_0_19_18
 UP BND1      load_0_19_18  20
 BV BND1      arc_0_19_20
 UP BND1      load_0_19_20  20
 BV BND1      arc_0_19_21
 UP BND1      load_0_19_21  20
 BV BND1      arc_0_19_22
 UP BND1      load_0_19_22  20
 BV BND1      arc_0_20_0
 UP BND1      load_0_20_0  20
 BV BND1      arc_0_20_1
 UP BND1      load_0_20_1  20
 BV BND1      arc_0_20_2
 UP BND1      load_0_20_2  20
 BV BND1      arc_0_20_3
 UP BND1      load_0_20_3  20
 BV BND1      arc_0_20_4
 UP BND1      load_0_20_4  20
 BV BND1      arc_0_20_15
 UP BND1      load_0_20_15  20
 BV BND1      arc_0_20_16
 UP BND1      load_0_20_16  20
 BV BND1      arc_0_20_17
 UP BND1      load_0_20_17  20
 BV BND1      arc_0_20_18
 UP BND1      load_0_20_18  20
 BV BND1      arc_0_20_19
 UP BND1      load_0_20_19  20
 BV BND1      arc_0_20_21
 UP BND1      load_0_20_21  20
 BV BND1      arc_0_20_22
 UP BND1      load_0_20_22  20
 BV BND1      arc_0_21_0
 UP BND1      load_0_21_0  20
 BV BND1      arc_0_21_1
 UP BND1      load_0_21_1  20
 BV BND1      arc_0_21_2
 UP BND1      load_0_21_2  20
 BV BND1      arc_0_21_3
 UP BND1      load_0_21_3  20
 BV BND1      arc_0_21_4
 UP BND1      load_0_21_4  20
 BV BND1      arc_0_21_15
 UP BND1      load_0_21_15  20
 BV BND1      arc_0_21_16
 UP BND1      load_0_21_16  20
 BV BND1      arc_0_21_17
 UP BND1      load_0_21_17  20
 BV BND1      arc_0_21_18
 UP BND1      load_0_21_18  20
 BV BND1      arc_0_21_19
 UP BND1      load_0_21_19  20
 BV BND1      arc_0_21_20
 UP BND1      load_0_21_20  20
 BV BND1      arc_0_21_22
 UP BND1      load_0_21_22  20
 BV BND1      arc_0_22_0
 UP BND1      load_0_22_0  20
 BV BND1      arc_0_22_1
 UP BND1      load_0_22_1  20
 BV BND1      arc_0_22_2
 UP BND1      load_0_22_2  20
 BV BND1      arc_0_22_3
 UP BND1      load_0_22_3  20
 BV BND1      arc_0_22_4
 UP BND1      load_0_22_4  20
 BV BND1      arc_0_22_15
 UP BND1      load_0_22_15  20
 BV BND1      arc_0_22_16
 UP BND1      load_0_22_16  20
 BV BND1      arc_0_22_17
 UP BND1      load_0_22_17  20
 BV BND1      arc_0_22_18
 UP BND1      load_0_22_18  20
 BV BND1      arc_0_22_19
 UP BND1      load_0_22_19  20
 BV BND1      arc_0_22_20
 UP BND1      load_0_22_20  20
 BV BND1      arc_0_22_21
 UP BND1      load_0_22_21  20
 FX BND1      visit_1_5  1
 UP BND1      order_1_5  14
 FX BND1      visit_1_6  1
 UP BND1      order_1_6  14
 FX BND1      visit_1_7  1
 UP BND1      order_1_7  14
 FX BND1      visit_1_8  1
 UP BND1      order_1_8  14
 FX BND1      visit_1_9  1
 UP BND1      order_1_9  14
 FX BND1      visit_1_10  1
 UP BND1      order_1_10  14
 UP BND1      visit_1_15  1
 UP BND1      order_1_15  14
 UP BND1      visit_1_16  1
 UP BND1      order_1_16  14
 UP BND1      visit_1_17  1
 UP BND1      order_1_17  14
 UP BND1      visit_1_18  1
 UP BND1      order_1_18  14
 UP BND1      visit_1_19  1
 UP BND1      order_1_19  14
 UP BND1      visit_1_20  1
 UP BND1      order_1_20  14
 UP BND1      visit_1_21  1
 UP BND1      order_1_21  14
 UP BND1      visit_1_22  1
 UP BND1      order_1_22  14
 BV BND1      arc_1_0_0
 FX BND1      load_1_0_0  0
 BV BND1      arc_1_0_5
 FX BND1      load_1_0_5  0
 BV BND1      arc_1_0_6
 FX BND1      load_1_0_6  0
 BV BND1      arc_1_0_7
 FX BND1      load_1_0_7  0
 BV BND1      arc_1_0_8
 FX BND1      load_1_0_8  0
 BV BND1      arc_1_0_9
 FX BND1      load_1_0_9  0
 BV BND1      arc_1_0_10
 FX BND1      load_1_0_10  0
 BV BND1      arc_1_0_15
 FX BND1      load_1_0_15  0
 BV BND1      arc_1_0_16
 FX BND1      load_1_0_16  0
 BV BND1      arc_1_0_17
 FX BND1      load_1_0_17  0
 BV BND1      arc_1_0_18
 FX BND1      load_1_0_18  0
 BV BND1      arc_1_0_19
 FX BND1      load_1_0_19  0
 BV BND1      arc_1_0_20
 FX BND1      load_1_0_20  0
 BV BND1      arc_1_0_21
 FX BND1      load_1_0_21  0
 BV BND1      arc_1_0_22
 FX BND1      load_1_0_22  0
 BV BND1      arc_1_5_0
 UP BND1      load_1_5_0  25
 BV BND1      arc_1_5_6
 UP BND1      load_1_5_6  25
 BV BND1      arc_1_5_7
 UP BND1      load_1_5_7  25
 BV BND1      arc_1_5_8
 UP BND1      load_1_5_8  25
 BV BND1      arc_1_5_9
 UP BND1      load_1_5_9  25
 BV BND1      arc_1_5_10
 UP BND1      load_1_5_10  25
 BV BND1      arc_1_5_15
 UP BND1      load_1_5_15  25
 BV BND1      arc_1_5_16
 UP BND1      load_1_5_16  25
 BV BND1      arc_1_5_17
 UP BND1      load_1_5_17  25
 BV BND1      arc_1_5_18
 UP BND1      load_1_5_18  25
 BV BND1      arc_1_5_19
 UP BND1      load_1_5_19  25
 BV BND1      arc_1_5_20
 UP BND1      load_1_5_20  25
 BV BND1      arc_1_5_21
 UP BND1      load_1_5_21  25
 BV BND1      arc_1_5_22
 UP BND1      load_1_5_22  25
 BV BND1      arc_1_6_0
 UP BND1      load_1_6_0  25
 BV BND1      arc_1_6_5
 UP BND1      load_1_6_5  25
 BV BND1      arc_1_6_7
 UP BND1      load_1_6_7  25
 BV BND1      arc_1_6_8
 UP BND1      load_1_6_8  25
 BV BND1      arc_1_6_9
 UP BND1      load_1_6_9  25
 BV BND1      arc_1_6_10
 UP BND1      load_1_6_10  25
 BV BND1      arc_1_6_15
 UP BND1      load_1_6_15  25
 BV BND1      arc_1_6_16
 UP BND1      load_1_6_16  25
 BV BND1      arc_1_6_17
 UP BND1      load_1_6_17  25
 BV BND1      arc_1_6_18
 UP BND1      load_1_6_18  25
 BV BND1      arc_1_6_19
 UP BND1      load_1_6_19  25
 BV BND1      arc_1_6_20
 UP BND1      load_1_6_20  25
 BV BND1      arc_1_6_21
 UP BND1      load_1_6_21  25
 BV BND1      arc_1_6_22
 UP BND1      load_1_6_22  25
 BV BND1      arc_1_7_0
 UP BND1      load_1_7_0  25
 BV BND1      arc_1_7_5
 UP BND1      load_1_7_5  25
 BV BND1      arc_1_7_6
 UP BND1      load_1_7_6  25
 BV BND1      arc_1_7_8
 UP BND1      load_1_7_8  25
 BV BND1      arc_1_7_9
 UP BND1      load_1_7_9  25
 BV BND1      arc_1_7_10
 UP BND1      load_1_7_10  25
 BV BND1      arc_1_7_15
 UP BND1      load_1_7_15  25
 BV BND1      arc_1_7_16
 UP BND1      load_1_7_16  25
 BV BND1      arc_1_7_17
 UP BND1      load_1_7_17  25
 BV BND1      arc_1_7_18
 UP BND1      load_1_7_18  25
 BV BND1      arc_1_7_19
 UP BND1      load_1_7_19  25
 BV BND1      arc_1_7_20
 UP BND1      load_1_7_20  25
 BV BND1      arc_1_7_21
 UP BND1      load_1_7_21  25
 BV BND1      arc_1_7_22
 UP BND1      load_1_7_22  25
 BV BND1      arc_1_8_0
 UP BND1      load_1_8_0  25
 BV BND1      arc_1_8_5
 UP BND1      load_1_8_5  25
 BV BND1      arc_1_8_6
 UP BND1      load_1_8_6  25
 BV BND1      arc_1_8_7
 UP BND1      load_1_8_7  25
 BV BND1      arc_1_8_9
 UP BND1      load_1_8_9  25
 BV BND1      arc_1_8_10
 UP BND1      load_1_8_10  25
 BV BND1      arc_1_8_15
 UP BND1      load_1_8_15  25
 BV BND1      arc_1_8_16
 UP BND1      load_1_8_16  25
 BV BND1      arc_1_8_17
 UP BND1      load_1_8_17  25
 BV BND1      arc_1_8_18
 UP BND1      load_1_8_18  25
 BV BND1      arc_1_8_19
 UP BND1      load_1_8_19  25
 BV BND1      arc_1_8_20
 UP BND1      load_1_8_20  25
 BV BND1      arc_1_8_21
 UP BND1      load_1_8_21  25
 BV BND1      arc_1_8_22
 UP BND1      load_1_8_22  25
 BV BND1      arc_1_9_0
 UP BND1      load_1_9_0  25
 BV BND1      arc_1_9_5
 UP BND1      load_1_9_5  25
 BV BND1      arc_1_9_6
 UP BND1      load_1_9_6  25
 BV BND1      arc_1_9_7
 UP BND1      load_1_9_7  25
 BV BND1      arc_1_9_8
 UP BND1      load_1_9_8  25
 BV BND1      arc_1_9_10
 UP BND1      load_1_9_10  25
 BV BND1      arc_1_9_15
 UP BND1      load_1_9_15  25
 BV BND1      arc_1_9_16
 UP BND1      load_1_9_16  25
 BV BND1      arc_1_9_17
 UP BND1      load_1_9_17  25
 BV BND1      arc_1_9_18
 UP BND1      load_1_9_18  25
 BV BND1      arc_1_9_19
 UP BND1      load_1_9_19  25
 BV BND1      arc_1_9_20
 UP BND1      load_1_9_20  25
 BV BND1      arc_1_9_21
 UP BND1      load_1_9_21  25
 BV BND1      arc_1_9_22
 UP BND1      load_1_9_22  25
 BV BND1      arc_1_10_0
 UP BND1      load_1_10_0  25
 BV BND1      arc_1_10_5
 UP BND1      load_1_10_5  25
 BV BND1      arc_1_10_6
 UP BND1      load_1_10_6  25
 BV BND1      arc_1_10_7
 UP BND1      load_1_10_7  25
 BV BND1      arc_1_10_8
 UP BND1      load_1_10_8  25
 BV BND1      arc_1_10_9
 UP BND1      load_1_10_9  25
 BV BND1      arc_1_10_15
 UP BND1      load_1_10_15  25
 BV BND1      arc_1_10_16
 UP BND1      load_1_10_16  25
 BV BND1      arc_1_10_17
 UP BND1      load_1_10_17  25
 BV BND1      arc_1_10_18
 UP BND1      load_1_10_18  25
 BV BND1      arc_1_10_19
 UP BND1      load_1_10_19  25
 BV BND1      arc_1_10_20
 UP BND1      load_1_10_20  25
 BV BND1      arc_1_10_21
 UP BND1      load_1_10_21  25
 BV BND1      arc_1_10_22
 UP BND1      load_1_10_22  25
 BV BND1      arc_1_15_0
 UP BND1      load_1_15_0  25
 BV BND1      arc_1_15_5
 UP BND1      load_1_15_5  25
 BV BND1      arc_1_15_6
 UP BND1      load_1_15_6  25
 BV BND1      arc_1_15_7
 UP BND1      load_1_15_7  25
 BV BND1      arc_1_15_8
 UP BND1      load_1_15_8  25
 BV BND1      arc_1_15_9
 UP BND1      load_1_15_9  25
 BV BND1      arc_1_15_10
 UP BND1      load_1_15_10  25
 BV BND1      arc_1_15_16
 UP BND1      load_1_15_16  25
 BV BND1      arc_1_15_17
 UP BND1      load_1_15_17  25
 BV BND1      arc_1_15_18
 UP BND1      load_1_15_18  25
 BV BND1      arc_1_15_19
 UP BND1      load_1_15_19  25
 BV BND1      arc_1_15_20
 UP BND1      load_1_15_20  25
 BV BND1      arc_1_15_21
 UP BND1      load_1_15_21  25
 BV BND1      arc_1_15_22
 UP BND1      load_1_15_22  25
 BV BND1      arc_1_16_0
 UP BND1      load_1_16_0  25
 BV BND1      arc_1_16_5
 UP BND1      load_1_16_5  25
 BV BND1      arc_1_16_6
 UP BND1      load_1_16_6  25
 BV BND1      arc_1_16_7
 UP BND1      load_1_16_7  25
 BV BND1      arc_1_16_8
 UP BND1      load_1_16_8  25
 BV BND1      arc_1_16_9
 UP BND1      load_1_16_9  25
 BV BND1      arc_1_16_10
 UP BND1      load_1_16_10  25
 BV BND1      arc_1_16_15
 UP BND1      load_1_16_15  25
 BV BND1      arc_1_16_17
 UP BND1      load_1_16_17  25
 BV BND1      arc_1_16_18
 UP BND1      load_1_16_18  25
 BV BND1      arc_1_16_19
 UP BND1      load_1_16_19  25
 BV BND1      arc_1_16_20
 UP BND1      load_1_16_20  25
 BV BND1      arc_1_16_21
 UP BND1      load_1_16_21  25
 BV BND1      arc_1_16_22
 UP BND1      load_1_16_22  25
 BV BND1      arc_1_17_0
 UP BND1      load_1_17_0  25
 BV BND1      arc_1_17_5
 UP BND1      load_1_17_5  25
 BV BND1      arc_1_17_6
 UP BND1      load_1_17_6  25
 BV BND1      arc_1_17_7
 UP BND1      load_1_17_7  25
 BV BND1      arc_1_17_8
 UP BND1      load_1_17_8  25
 BV BND1      arc_1_17_9
 UP BND1      load_1_17_9  25
 BV BND1      arc_1_17_10
 UP BND1      load_1_17_10  25
 BV BND1      arc_1_17_15
 UP BND1      load_1_17_15  25
 BV BND1      arc_1_17_16
 UP BND1      load_1_17_16  25
 BV BND1      arc_1_17_18
 UP BND1      load_1_17_18  25
 BV BND1      arc_1_17_19
 UP BND1      load_1_17_19  25
 BV BND1      arc_1_17_20
 UP BND1      load_1_17_20  25
 BV BND1      arc_1_17_21
 UP BND1      load_1_17_21  25
 BV BND1      arc_1_17_22
 UP BND1      load_1_17_22  25
 BV BND1      arc_1_18_0
 UP BND1      load_1_18_0  25
 BV BND1      arc_1_18_5
 UP BND1      load_1_18_5  25
 BV BND1      arc_1_18_6
 UP BND1      load_1_18_6  25
 BV BND1      arc_1_18_7
 UP BND1      load_1_18_7  25
 BV BND1      arc_1_18_8
 UP BND1      load_1_18_8  25
 BV BND1      arc_1_18_9
 UP BND1      load_1_18_9  25
 BV BND1      arc_1_18_10
 UP BND1      load_1_18_10  25
 BV BND1      arc_1_18_15
 UP BND1      load_1_18_15  25
 BV BND1      arc_1_18_16
 UP BND1      load_1_18_16  25
 BV BND1      arc_1_18_17
 UP BND1      load_1_18_17  25
 BV BND1      arc_1_18_19
 UP BND1      load_1_18_19  25
 BV BND1      arc_1_18_20
 UP BND1      load_1_18_20  25
 BV BND1      arc_1_18_21
 UP BND1      load_1_18_21  25
 BV BND1      arc_1_18_22
 UP BND1      load_1_18_22  25
 BV BND1      arc_1_19_0
 UP BND1      load_1_19_0  25
 BV BND1      arc_1_19_5
 UP BND1      load_1_19_5  25
 BV BND1      arc_1_19_6
 UP BND1      load_1_19_6  25
 BV BND1      arc_1_19_7
 UP BND1      load_1_19_7  25
 BV BND1      arc_1_19_8
 UP BND1      load_1_19_8  25
 BV BND1      arc_1_19_9
 UP BND1      load_1_19_9  25
 BV BND1      arc_1_19_10
 UP BND1      load_1_19_10  25
 BV BND1      arc_1_19_15
 UP BND1      load_1_19_15  25
 BV BND1      arc_1_19_16
 UP BND1      load_1_19_16  25
 BV BND1      arc_1_19_17
 UP BND1      load_1_19_17  25
 BV BND1      arc_1_19_18
 UP BND1      load_1_19_18  25
 BV BND1      arc_1_19_20
 UP BND1      load_1_19_20  25
 BV BND1      arc_1_19_21
 UP BND1      load_1_19_21  25
 BV BND1      arc_1_19_22
 UP BND1      load_1_19_22  25
 BV BND1      arc_1_20_0
 UP BND1      load_1_20_0  25
 BV BND1      arc_1_20_5
 UP BND1      load_1_20_5  25
 BV BND1      arc_1_20_6
 UP BND1      load_1_20_6  25
 BV BND1      arc_1_20_7
 UP BND1      load_1_20_7  25
 BV BND1      arc_1_20_8
 UP BND1      load_1_20_8  25
 BV BND1      arc_1_20_9
 UP BND1      load_1_20_9  25
 BV BND1      arc_1_20_10
 UP BND1      load_1_20_10  25
 BV BND1      arc_1_20_15
 UP BND1      load_1_20_15  25
 BV BND1      arc_1_20_16
 UP BND1      load_1_20_16  25
 BV BND1      arc_1_20_17
 UP BND1      load_1_20_17  25
 BV BND1      arc_1_20_18
 UP BND1      load_1_20_18  25
 BV BND1      arc_1_20_19
 UP BND1      load_1_20_19  25
 BV BND1      arc_1_20_21
 UP BND1      load_1_20_21  25
 BV BND1      arc_1_20_22
 UP BND1      load_1_20_22  25
 BV BND1      arc_1_21_0
 UP BND1      load_1_21_0  25
 BV BND1      arc_1_21_5
 UP BND1      load_1_21_5  25
 BV BND1      arc_1_21_6
 UP BND1      load_1_21_6  25
 BV BND1      arc_1_21_7
 UP BND1      load_1_21_7  25
 BV BND1      arc_1_21_8
 UP BND1      load_1_21_8  25
 BV BND1      arc_1_21_9
 UP BND1      load_1_21_9  25
 BV BND1      arc_1_21_10
 UP BND1      load_1_21_10  25
 BV BND1      arc_1_21_15
 UP BND1      load_1_21_15  25
 BV BND1      arc_1_21_16
 UP BND1      load_1_21_16  25
 BV BND1      arc_1_21_17
 UP BND1      load_1_21_17  25
 BV BND1      arc_1_21_18
 UP BND1      load_1_21_18  25
 BV BND1      arc_1_21_19
 UP BND1      load_1_21_19  25
 BV BND1      arc_1_21_20
 UP BND1      load_1_21_20  25
 BV BND1      arc_1_21_22
 UP BND1      load_1_21_22  25
 BV BND1      arc_1_22_0
 UP BND1      load_1_22_0  25
 BV BND1      arc_1_22_5
 UP BND1      load_1_22_5  25
 BV BND1      arc_1_22_6
 UP BND1      load_1_22_6  25
 BV BND1      arc_1_22_7
 UP BND1      load_1_22_7  25
 BV BND1      arc_1_22_8
 UP BND1      load_1_22_8  25
 BV BND1      arc_1_22_9
 UP BND1      load_1_22_9  25
 BV BND1      arc_1_22_10
 UP BND1      load_1_22_10  25
 BV BND1      arc_1_22_15
 UP BND1      load_1_22_15  25
 BV BND1      arc_1_22_16
 UP BND1      load_1_22_16  25
 BV BND1      arc_1_22_17
 UP BND1      load_1_22_17  25
 BV BND1      arc_1_22_18
 UP BND1      load_1_22_18  25
 BV BND1      arc_1_22_19
 UP BND1      load_1_22_19  25
 BV BND1      arc_1_22_20
 UP BND1      load_1_22_20  25
 BV BND1      arc_1_22_21
 UP BND1      load_1_22_21  25
 FX BND1      visit_2_11  1
 UP BND1      order_2_11  12
 FX BND1      visit_2_12  1
 UP BND1      order_2_12  12
 FX BND1      visit_2_13  1
 UP BND1      order_2_13  12
 FX BND1      visit_2_14  1
 UP BND1      order_2_14  12
 UP BND1      visit_2_15  1
 UP BND1      order_2_15  12
 UP BND1      visit_2_16  1
 UP BND1      order_2_16  12
 UP BND1      visit_2_17  1
 UP BND1      order_2_17  12
 UP BND1      visit_2_18  1
 UP BND1      order_2_18  12
 UP BND1      visit_2_19  1
 UP BND1      order_2_19  12
 UP BND1      visit_2_20  1
 UP BND1      order_2_20  12
 UP BND1      visit_2_21  1
 UP BND1      order_2_21  12
 UP BND1      visit_2_22  1
 UP BND1      order_2_22  12
 BV BND1      arc_2_0_0
 FX BND1      load_2_0_0  0
 BV BND1      arc_2_0_11
 FX BND1      load_2_0_11  0
 BV BND1      arc_2_0_12
 FX BND1      load_2_0_12  0
 BV BND1      arc_2_0_13
 FX BND1      load_2_0_13  0
 BV BND1      arc_2_0_14
 FX BND1      load_2_0_14  0
 BV BND1      arc_2_0_15
 FX BND1      load_2_0_15  0
 BV BND1      arc_2_0_16
 FX BND1      load_2_0_16  0
 BV BND1      arc_2_0_17
 FX BND1      load_2_0_17  0
 BV BND1      arc_2_0_18
 FX BND1      load_2_0_18  0
 BV BND1      arc_2_0_19
 FX BND1      load_2_0_19  0
 BV BND1      arc_2_0_20
 FX BND1      load_2_0_20  0
 BV BND1      arc_2_0_21
 FX BND1      load_2_0_21  0
 BV BND1      arc_2_0_22
 FX BND1      load_2_0_22  0
 BV BND1      arc_2_11_0
 UP BND1      load_2_11_0  30
 BV BND1      arc_2_11_12
 UP BND1      load_2_11_12  30
 BV BND1      arc_2_11_13
 UP BND1      load_2_11_13  30
 BV BND1      arc_2_11_14
 UP BND1      load_2_11_14  30
 BV BND1      arc_2_11_15
 UP BND1      load_2_11_15  30
 BV BND1      arc_2_11_16
 UP BND1      load_2_11_16  30
 BV BND1      arc_2_11_17
 UP BND1      load_2_11_17  30
 BV BND1      arc_2_11_18
 UP BND1      load_2_11_18  30
 BV BND1      arc_2_11_19
 UP BND1      load_2_11_19  30
 BV BND1      arc_2_11_20
 UP BND1      load_2_11_20  30
 BV BND1      arc_2_11_21
 UP BND1      load_2_11_21  30
 BV BND1      arc_2_11_22
 UP BND1      load_2_11_22  30
 BV BND1      arc_2_12_0
 UP BND1      load_2_12_0  30
 BV BND1      arc_2_12_11
 UP BND1      load_2_12_11  30
 BV BND1      arc_2_12_13
 UP BND1      load_2_12_13  30
 BV BND1      arc_2_12_14
 UP BND1      load_2_12_14  30
 BV BND1      arc_2_12_15
 UP BND1      load_2_12_15  30
 BV BND1      arc_2_12_16
 UP BND1      load_2_12_16  30
 BV BND1      arc_2_12_17
 UP BND1      load_2_12_17  30
 BV BND1      arc_2_12_18
 UP BND1      load_2_12_18  30
 BV BND1      arc_2_12_19
 UP BND1      load_2_12_19  30
 BV BND1      arc_2_12_20
 UP BND1      load_2_12_20  30
 BV BND1      arc_2_12_21
 UP BND1      load_2_12_21  30
 BV BND1      arc_2_12_22
 UP BND1      load_2_12_22  30
 BV BND1      arc_2_13_0
 UP BND1      load_2_13_0  30
 BV BND1      arc_2_13_11
 UP BND1      load_2_13_11  30
 BV BND1      arc_2_13_12
 UP BND1      load_2_13_12  30
 BV BND1      arc_2_13_14
 UP BND1      load_2_13_14  30
 BV BND1      arc_2_13_15
 UP BND1      load_2_13_15  30
 BV BND1      arc_2_13_16
 UP BND1      load_2_13_16  30
 BV BND1      arc_2_13_17
 UP BND1      load_2_13_17  30
 BV BND1      arc_2_13_18
 UP BND1      load_2_13_18  30
 BV BND1      arc_2_13_19
 UP BND1      load_2_13_19  30
 BV BND1      arc_2_13_20
 UP BND1      load_2_13_20  30
 BV BND1      arc_2_13_21
 UP BND1      load_2_13_21  30
 BV BND1      arc_2_13_22
 UP BND1      load_2_13_22  30
 BV BND1      arc_2_14_0
 UP BND1      load_2_14_0  30
 BV BND1      arc_2_14_11
 UP BND1      load_2_14_11  30
 BV BND1      arc_2_14_12
 UP BND1      load_2_14_12  30
 BV BND1      arc_2_14_13
 UP BND1      load_2_14_13  30
 BV BND1      arc_2_14_15
 UP BND1      load_2_14_15  30
 BV BND1      arc_2_14_16
 UP BND1      load_2_14_16  30
 BV BND1      arc_2_14_17
 UP BND1      load_2_14_17  30
 BV BND1      arc_2_14_18
 UP BND1      load_2_14_18  30
 BV BND1      arc_2_14_19
 UP BND1      load_2_14_19  30
 BV BND1      arc_2_14_20
 UP BND1      load_2_14_20  30
 BV BND1      arc_2_14_21
 UP BND1      load_2_14_21  30
 BV BND1      arc_2_14_22
 UP BND1      load_2_14_22  30
 BV BND1      arc_2_15_0
 UP BND1      load_2_15_0  30
 BV BND1      arc_2_15_11
 UP BND1      load_2_15_11  30
 BV BND1      arc_2_15_12
 UP BND1      load_2_15_12  30
 BV BND1      arc_2_15_13
 UP BND1      load_2_15_13  30
 BV BND1      arc_2_15_14
 UP BND1      load_2_15_14  30
 BV BND1      arc_2_15_16
 UP BND1      load_2_15_16  30
 BV BND1      arc_2_15_17
 UP BND1      load_2_15_17  30
 BV BND1      arc_2_15_18
 UP BND1      load_2_15_18  30
 BV BND1      arc_2_15_19
 UP BND1      load_2_15_19  30
 BV BND1      arc_2_15_20
 UP BND1      load_2_15_20  30
 BV BND1      arc_2_15_21
 UP BND1      load_2_15_21  30
 BV BND1      arc_2_15_22
 UP BND1      load_2_15_22  30
 BV BND1      arc_2_16_0
 UP BND1      load_2_16_0  30
 BV BND1      arc_2_16_11
 UP BND1      load_2_16_11  30
 BV BND1      arc_2_16_12
 UP BND1      load_2_16_12  30
 BV BND1      arc_2_16_13
 UP BND1      load_2_16_13  30
 BV BND1      arc_2_16_14
 UP BND1      load_2_16_14  30
 BV BND1      arc_2_16_15
 UP BND1      load_2_16_15  30
 BV BND1      arc_2_16_17
 UP BND1      load_2_16_17  30
 BV BND1      arc_2_16_18
 UP BND1      load_2_16_18  30
 BV BND1      arc_2_16_19
 UP BND1      load_2_16_19  30
 BV BND1      arc_2_16_20
 UP BND1      load_2_16_20  30
 BV BND1      arc_2_16_21
 UP BND1      load_2_16_21  30
 BV BND1      arc_2_16_22
 UP BND1      load_2_16_22  30
 BV BND1      arc_2_17_0
 UP BND1      load_2_17_0  30
 BV BND1      arc_2_17_11
 UP BND1      load_2_17_11  30
 BV BND1      arc_2_17_12
 UP BND1      load_2_17_12  30
 BV BND1      arc_2_17_13
 UP BND1      load_2_17_13  30
 BV BND1      arc_2_17_14
 UP BND1      load_2_17_14  30
 BV BND1      arc_2_17_15
 UP BND1      load_2_17_15  30
 BV BND1      arc_2_17_16
 UP BND1      load_2_17_16  30
 BV BND1      arc_2_17_18
 UP BND1      load_2_17_18  30
 BV BND1      arc_2_17_19
 UP BND1      load_2_17_19  30
 BV BND1      arc_2_17_20
 UP BND1      load_2_17_20  30
 BV BND1      arc_2_17_21
 UP BND1      load_2_17_21  30
 BV BND1      arc_2_17_22
 UP BND1      load_2_17_22  30
 BV BND1      arc_2_18_0
 UP BND1      load_2_18_0  30
 BV BND1      arc_2_18_11
 UP BND1      load_2_18_11  30
 BV BND1      arc_2_18_12
 UP BND1      load_2_18_12  30
 BV BND1      arc_2_18_13
 UP BND1      load_2_18_13  30
 BV BND1      arc_2_18_14
 UP BND1      load_2_18_14  30
 BV BND1      arc_2_18_15
 UP BND1      load_2_18_15  30
 BV BND1      arc_2_18_16
 UP BND1      load_2_18_16  30
 BV BND1      arc_2_18_17
 UP BND1      load_2_18_17  30
 BV BND1      arc_2_18_19
 UP BND1      load_2_18_19  30
 BV BND1      arc_2_18_20
 UP BND1      load_2_18_20  30
 BV BND1      arc_2_18_21
 UP BND1      load_2_18_21  30
 BV BND1      arc_2_18_22
 UP BND1      load_2_18_22  30
 BV BND1      arc_2_19_0
 UP BND1      load_2_19_0  30
 BV BND1      arc_2_19_11
 UP BND1      load_2_19_11  30
 BV BND1      arc_2_19_12
 UP BND1      load_2_19_12  30
 BV BND1      arc_2_19_13
 UP BND1      load_2_19_13  30
 BV BND1      arc_2_19_14
 UP BND1      load_2_19_14  30
 BV BND1      arc_2_19_15
 UP BND1      load_2_19_15  30
 BV BND1      arc_2_19_16
 UP BND1      load_2_19_16  30
 BV BND1      arc_2_19_17
 UP BND1      load_2_19_17  30
 BV BND1      arc_2_19_18
 UP BND1      load_2_19_18  30
 BV BND1      arc_2_19_20
 UP BND1      load_2_19_20  30
 BV BND1      arc_2_19_21
 UP BND1      load_2_19_21  30
 BV BND1      arc_2_19_22
 UP BND1      load_2_19_22  30
 BV BND1      arc_2_20_0
 UP BND1      load_2_20_0  30
 BV BND1      arc_2_20_11
 UP BND1      load_2_20_11  30
 BV BND1      arc_2_20_12
 UP BND1      load_2_20_12  30
 BV BND1      arc_2_20_13
 UP BND1      load_2_20_13  30
 BV BND1      arc_2_20_14
 UP BND1      load_2_20_14  30
 BV BND1      arc_2_20_15
 UP BND1      load_2_20_15  30
 BV BND1      arc_2_20_16
 UP BND1      load_2_20_16  30
 BV BND1      arc_2_20_17
 UP BND1      load_2_20_17  30
 BV BND1      arc_2_20_18
 UP BND1      load_2_20_18  30
 BV BND1      arc_2_20_19
 UP BND1      load_2_20_19  30
 BV BND1      arc_2_20_21
 UP BND1      load_2_20_21  30
 BV BND1      arc_2_20_22
 UP BND1      load_2_20_22  30
 BV BND1      arc_2_21_0
 UP BND1      load_2_21_0  30
 BV BND1      arc_2_21_11
 UP BND1      load_2_21_11  30
 BV BND1      arc_2_21_12
 UP BND1      load_2_21_12  30
 BV BND1      arc_2_21_13
 UP BND1      load_2_21_13  30
 BV BND1      arc_2_21_14
 UP BND1      load_2_21_14  30
 BV BND1      arc_2_21_15
 UP BND1      load_2_21_15  30
 BV BND1      arc_2_21_16
 UP BND1      load_2_21_16  30
 BV BND1      arc_2_21_17
 UP BND1      load_2_21_17  30
 BV BND1      arc_2_21_18
 UP BND1      load_2_21_18  30
 BV BND1      arc_2_21_19
 UP BND1      load_2_21_19  30
 BV BND1      arc_2_21_20
 UP BND1      load_2_21_20  30
 BV BND1      arc_2_21_22
 UP BND1      load_2_21_22  30
 BV BND1      arc_2_22_0
 UP BND1      load_2_22_0  30
 BV BND1      arc_2_22_11
 UP BND1      load_2_22_11  30
 BV BND1      arc_2_22_12
 UP BND1      load_2_22_12  30
 BV BND1      arc_2_22_13
 UP BND1      load_2_22_13  30
 BV BND1      arc_2_22_14
 UP BND1      load_2_22_14  30
 BV BND1      arc_2_22_15
 UP BND1      load_2_22_15  30
 BV BND1      arc_2_22_16
 UP BND1      load_2_22_16  30
 BV BND1      arc_2_22_17
 UP BND1      load_2_22_17  30
 BV BND1      arc_2_22_18
 UP BND1      load_2_22_18  30
 BV BND1      arc_2_22_19
 UP BND1      load_2_22_19  30
 BV BND1      arc_2_22_20
 UP BND1      load_2_22_20  30
 BV BND1      arc_2_22_21
 UP BND1      load_2_22_21  30
ENDATA
