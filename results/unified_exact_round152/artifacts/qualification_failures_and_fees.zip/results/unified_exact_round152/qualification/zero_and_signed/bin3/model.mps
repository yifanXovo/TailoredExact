* Signature: 0x72e9770e79c17915
NAME 
ROWS
 N  OBJ
 E  onehot_1
 E  inventory_1
 E  ratio_1 
 E  onehot_2
 E  inventory_2
 E  ratio_2 
 G  R6      
 G  R7      
 G  hard_lower
 L  hard_upper
 G  bin_lower
 L  bin_upper
 L  surrogate_G
 L  physical_G_upper
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    x[1,0]    OBJ       0.5
    x[1,0]    onehot_1  1
    x[1,1]    OBJ       -0.5625
    x[1,1]    onehot_1  1
    x[1,1]    inventory_1  -1
    x[1,3]    OBJ       -0.5625
    x[1,3]    onehot_1  1
    x[1,3]    inventory_1  -3
    x[2,0]    OBJ       -0.5
    x[2,0]    onehot_2  1
    x[2,1]    OBJ       0.375
    x[2,1]    onehot_2  1
    x[2,1]    inventory_2  -1
    x[2,2]    OBJ       -0.5
    x[2,2]    onehot_2  1
    x[2,2]    inventory_2  -2
    MARKER    'MARKER'                 'INTEND'
    Y[1]      inventory_1  1
    Y[1]      ratio_1   -0.5
    Y[1]      hard_lower  1
    Y[1]      hard_upper  1
    Y[2]      inventory_2  1
    Y[2]      ratio_2   -1
    Y[2]      hard_lower  1
    Y[2]      hard_upper  1
    r[1]      ratio_1   1
    r[1]      R6        -1
    r[1]      R7        1
    r[1]      bin_lower  1
    r[1]      bin_upper  1
    r[1]      physical_G_upper  -1
    r[2]      ratio_2   1
    r[2]      R6        1
    r[2]      R7        -1
    r[2]      bin_lower  1
    r[2]      bin_upper  1
    r[2]      physical_G_upper  -1
    a[1,2]    R6        1
    a[1,2]    R7        1
    a[1,2]    surrogate_G  1
    a[1,2]    physical_G_upper  1
    q         OBJ       1
    q         surrogate_G  -4.1649312786339028e+00
RHS
    RHS1      onehot_1  1
    RHS1      onehot_2  1
    RHS1      hard_upper  3
    RHS1      bin_lower  1.4577259475218660e+00
    RHS1      bin_upper  2.0824656393169514e+00
BOUNDS
 BV BND1      x[1,0]  
 BV BND1      x[1,1]  
 BV BND1      x[1,3]  
 BV BND1      x[2,0]  
 BV BND1      x[2,1]  
 BV BND1      x[2,2]  
 LO BND1      q         0.2
ENDATA
