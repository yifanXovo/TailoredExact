* Signature: 0x6fe3fc47849ee738
NAME R160_physical_neighborhood
ROWS
 N  OBJ
 G  product_lb_0
 L  product_ub_1
 G  product_lb_2
 L  product_ub_3
 G  product_lb_4
 L  product_ub_5
 G  product_lb_6
 L  product_ub_7
 G  product_lb_8
 L  product_ub_9
 G  product_lb_10
 L  product_ub_11
 G  product_lb_12
 L  product_ub_13
 G  product_lb_14
 L  product_ub_15
 G  product_lb_16
 L  product_ub_17
 G  product_lb_18
 L  product_ub_19
 G  product_lb_20
 L  product_ub_21
 G  product_lb_22
 L  product_ub_23
 G  product_lb_24
 L  product_ub_25
 G  product_lb_26
 L  product_ub_27
 G  product_lb_28
 L  product_ub_29
 G  product_lb_30
 L  product_ub_31
 G  product_lb_32
 L  product_ub_33
 E  onehot_17_34
 E  normalized_mass_17_35
 E  normalized_ratio_17_36
 G  product_lb_37
 L  product_ub_38
 G  product_lb_39
 L  product_ub_40
 G  product_lb_41
 L  product_ub_42
 G  product_lb_43
 L  product_ub_44
 G  product_lb_45
 L  product_ub_46
 G  product_lb_47
 L  product_ub_48
 G  product_lb_49
 L  product_ub_50
 G  product_lb_51
 L  product_ub_52
 G  product_lb_53
 L  product_ub_54
 G  product_lb_55
 L  product_ub_56
 G  product_lb_57
 L  product_ub_58
 G  product_lb_59
 L  product_ub_60
 G  product_lb_61
 L  product_ub_62
 G  product_lb_63
 L  product_ub_64
 G  product_lb_65
 L  product_ub_66
 G  product_lb_67
 L  product_ub_68
 E  onehot_14_69
 E  normalized_mass_14_70
 E  normalized_ratio_14_71
 G  product_lb_72
 L  product_ub_73
 G  product_lb_74
 L  product_ub_75
 G  product_lb_76
 L  product_ub_77
 G  product_lb_78
 L  product_ub_79
 G  product_lb_80
 L  product_ub_81
 G  product_lb_82
 L  product_ub_83
 G  product_lb_84
 L  product_ub_85
 G  product_lb_86
 L  product_ub_87
 G  product_lb_88
 L  product_ub_89
 G  product_lb_90
 L  product_ub_91
 G  product_lb_92
 L  product_ub_93
 G  product_lb_94
 L  product_ub_95
 G  product_lb_96
 L  product_ub_97
 G  product_lb_98
 L  product_ub_99
 G  product_lb_100
 L  product_ub_101
 G  product_lb_102
 L  product_ub_103
 E  onehot_18_104
 E  normalized_mass_18_105
 E  normalized_ratio_18_106
 G  product_lb_107
 L  product_ub_108
 G  product_lb_109
 L  product_ub_110
 E  onehot_13_111
 E  normalized_mass_13_112
 E  normalized_ratio_13_113
 G  product_lb_114
 L  product_ub_115
 G  product_lb_116
 L  product_ub_117
 G  product_lb_118
 L  product_ub_119
 G  product_lb_120
 L  product_ub_121
 G  product_lb_122
 L  product_ub_123
 G  product_lb_124
 L  product_ub_125
 G  product_lb_126
 L  product_ub_127
 G  product_lb_128
 L  product_ub_129
 G  product_lb_130
 L  product_ub_131
 G  product_lb_132
 L  product_ub_133
 G  product_lb_134
 L  product_ub_135
 G  product_lb_136
 L  product_ub_137
 G  product_lb_138
 L  product_ub_139
 G  product_lb_140
 L  product_ub_141
 G  product_lb_142
 L  product_ub_143
 G  product_lb_144
 L  product_ub_145
 E  onehot_20_146
 E  normalized_mass_20_147
 E  normalized_ratio_20_148
 G  product_lb_149
 L  product_ub_150
 G  product_lb_151
 L  product_ub_152
 G  product_lb_153
 L  product_ub_154
 G  product_lb_155
 L  product_ub_156
 G  product_lb_157
 L  product_ub_158
 G  product_lb_159
 L  product_ub_160
 G  product_lb_161
 L  product_ub_162
 G  product_lb_163
 L  product_ub_164
 G  product_lb_165
 L  product_ub_166
 G  product_lb_167
 L  product_ub_168
 G  product_lb_169
 L  product_ub_170
 G  product_lb_171
 L  product_ub_172
 G  product_lb_173
 L  product_ub_174
 G  product_lb_175
 L  product_ub_176
 G  product_lb_177
 L  product_ub_178
 G  product_lb_179
 L  product_ub_180
 E  onehot_12_181
 E  normalized_mass_12_182
 E  normalized_ratio_12_183
 G  product_lb_184
 L  product_ub_185
 G  product_lb_186
 L  product_ub_187
 G  product_lb_188
 L  product_ub_189
 G  product_lb_190
 L  product_ub_191
 G  product_lb_192
 L  product_ub_193
 G  product_lb_194
 L  product_ub_195
 G  product_lb_196
 L  product_ub_197
 G  product_lb_198
 L  product_ub_199
 G  product_lb_200
 L  product_ub_201
 G  product_lb_202
 L  product_ub_203
 G  product_lb_204
 L  product_ub_205
 G  product_lb_206
 L  product_ub_207
 G  product_lb_208
 L  product_ub_209
 G  product_lb_210
 L  product_ub_211
 G  product_lb_212
 L  product_ub_213
 G  product_lb_214
 L  product_ub_215
 E  onehot_11_216
 E  normalized_mass_11_217
 E  normalized_ratio_11_218
 G  product_lb_219
 L  product_ub_220
 G  product_lb_221
 L  product_ub_222
 E  onehot_10_223
 E  normalized_mass_10_224
 E  normalized_ratio_10_225
 G  stock_lb_226
 L  stock_ub_227
 L  parent_nonstrict_scope_228
 G  block_pair_pos_229
 G  block_pair_neg_230
 G  block_pair_pos_231
 G  block_pair_neg_232
 G  block_pair_pos_233
 G  block_pair_neg_234
 G  block_pair_pos_235
 G  block_pair_neg_236
 G  block_pair_pos_237
 G  block_pair_neg_238
 G  block_pair_pos_239
 G  block_pair_neg_240
 G  block_pair_pos_241
 G  block_pair_neg_242
 G  block_pair_pos_243
 G  block_pair_neg_244
 G  block_pair_pos_245
 G  block_pair_neg_246
 G  block_pair_pos_247
 G  block_pair_neg_248
 G  block_pair_pos_249
 G  block_pair_neg_250
 G  block_pair_pos_251
 G  block_pair_neg_252
 G  block_pair_pos_253
 G  block_pair_neg_254
 G  block_pair_pos_255
 G  block_pair_neg_256
 G  block_pair_pos_257
 G  block_pair_neg_258
 G  block_pair_pos_259
 G  block_pair_neg_260
 G  block_pair_pos_261
 G  block_pair_neg_262
 G  block_pair_pos_263
 G  block_pair_neg_264
 G  block_pair_pos_265
 G  block_pair_neg_266
 G  block_pair_pos_267
 G  block_pair_neg_268
 G  block_pair_pos_269
 G  block_pair_neg_270
 G  block_pair_pos_271
 G  block_pair_neg_272
 G  block_pair_pos_273
 G  block_pair_neg_274
 G  block_pair_pos_275
 G  block_pair_neg_276
 G  block_pair_pos_277
 G  block_pair_neg_278
 G  block_pair_pos_279
 G  block_pair_neg_280
 G  block_pair_pos_281
 G  block_pair_neg_282
 G  block_pair_pos_283
 G  block_pair_neg_284
 E  normalization_285
 G  full_original_Gini_286
 E  unique_nonzero_owner_287
 E  unique_nonzero_owner_288
 E  unique_nonzero_owner_289
 E  unique_nonzero_owner_290
 E  unique_nonzero_owner_291
 E  unique_nonzero_owner_292
 E  unique_nonzero_owner_293
 E  unique_nonzero_owner_294
 E  unique_nonzero_owner_295
 E  unique_nonzero_owner_296
 E  unique_nonzero_owner_297
 E  unique_nonzero_owner_298
 E  unique_nonzero_owner_299
 E  unique_nonzero_owner_300
 E  unique_nonzero_owner_301
 E  unique_nonzero_owner_302
 E  unique_nonzero_owner_303
 E  unique_nonzero_owner_304
 E  unique_nonzero_owner_305
 E  unique_nonzero_owner_306
 E  unique_nonzero_owner_307
 E  unique_nonzero_owner_308
 E  unique_nonzero_owner_309
 E  unique_nonzero_owner_310
 E  unique_nonzero_owner_311
 E  unique_nonzero_owner_312
 E  unique_nonzero_owner_313
 E  unique_nonzero_owner_314
 E  unique_nonzero_owner_315
 E  unique_nonzero_owner_316
 E  unique_nonzero_owner_317
 E  unique_nonzero_owner_318
 E  unique_nonzero_owner_319
 E  unique_nonzero_owner_320
 E  unique_nonzero_owner_321
 E  unique_nonzero_owner_322
 E  unique_nonzero_owner_323
 E  unique_nonzero_owner_324
 E  unique_nonzero_owner_325
 E  unique_nonzero_owner_326
 E  unique_nonzero_owner_327
 E  unique_nonzero_owner_328
 E  unique_nonzero_owner_329
 E  unique_nonzero_owner_330
 E  unique_nonzero_owner_331
 E  unique_nonzero_owner_332
 E  unique_nonzero_owner_333
 E  unique_nonzero_owner_334
 E  unique_nonzero_owner_335
 E  unique_nonzero_owner_336
 E  unique_nonzero_owner_337
 E  unique_nonzero_owner_338
 E  unique_nonzero_owner_339
 E  unique_nonzero_owner_340
 E  unique_nonzero_owner_341
 E  unique_nonzero_owner_342
 E  unique_nonzero_owner_343
 E  unique_nonzero_owner_344
 E  unique_nonzero_owner_345
 E  unique_nonzero_owner_346
 E  unique_nonzero_owner_347
 E  unique_nonzero_owner_348
 E  unique_nonzero_owner_349
 E  unique_nonzero_owner_350
 E  unique_nonzero_owner_351
 E  unique_nonzero_owner_352
 E  unique_nonzero_owner_353
 E  unique_nonzero_owner_354
 E  unique_nonzero_owner_355
 E  unique_nonzero_owner_356
 E  unique_nonzero_owner_357
 E  unique_nonzero_owner_358
 E  unique_nonzero_owner_359
 E  unique_nonzero_owner_360
 E  unique_nonzero_owner_361
 E  unique_nonzero_owner_362
 E  unique_nonzero_owner_363
 E  unique_nonzero_owner_364
 E  unique_nonzero_owner_365
 E  unique_nonzero_owner_366
 E  unique_nonzero_owner_367
 E  unique_nonzero_owner_368
 E  unique_nonzero_owner_369
 E  unique_nonzero_owner_370
 E  unique_nonzero_owner_371
 E  unique_nonzero_owner_372
 E  unique_nonzero_owner_373
 E  unique_nonzero_owner_374
 E  unique_nonzero_owner_375
 E  unique_nonzero_owner_376
 E  unique_nonzero_owner_377
 E  unique_nonzero_owner_378
 E  unique_nonzero_owner_379
 L  arc_capacity_380
 L  arc_capacity_381
 L  arc_capacity_382
 L  arc_capacity_383
 L  arc_capacity_384
 L  arc_capacity_385
 L  arc_capacity_386
 L  arc_capacity_387
 L  arc_capacity_388
 L  arc_capacity_389
 L  arc_capacity_390
 L  arc_capacity_391
 L  arc_capacity_392
 L  arc_capacity_393
 L  arc_capacity_394
 L  arc_capacity_395
 L  arc_capacity_396
 G  connected_order_arc_397
 L  arc_capacity_398
 G  connected_order_arc_399
 L  arc_capacity_400
 G  connected_order_arc_401
 L  arc_capacity_402
 G  connected_order_arc_403
 L  arc_capacity_404
 G  connected_order_arc_405
 L  arc_capacity_406
 G  connected_order_arc_407
 L  arc_capacity_408
 G  connected_order_arc_409
 L  arc_capacity_410
 G  connected_order_arc_411
 L  arc_capacity_412
 G  connected_order_arc_413
 L  arc_capacity_414
 G  connected_order_arc_415
 L  arc_capacity_416
 G  connected_order_arc_417
 L  arc_capacity_418
 G  connected_order_arc_419
 L  arc_capacity_420
 G  connected_order_arc_421
 L  arc_capacity_422
 L  arc_capacity_423
 G  connected_order_arc_424
 L  arc_capacity_425
 G  connected_order_arc_426
 L  arc_capacity_427
 G  connected_order_arc_428
 L  arc_capacity_429
 G  connected_order_arc_430
 L  arc_capacity_431
 G  connected_order_arc_432
 L  arc_capacity_433
 G  connected_order_arc_434
 L  arc_capacity_435
 G  connected_order_arc_436
 L  arc_capacity_437
 G  connected_order_arc_438
 L  arc_capacity_439
 G  connected_order_arc_440
 L  arc_capacity_441
 G  connected_order_arc_442
 L  arc_capacity_443
 G  connected_order_arc_444
 L  arc_capacity_445
 G  connected_order_arc_446
 L  arc_capacity_447
 G  connected_order_arc_448
 L  arc_capacity_449
 L  arc_capacity_450
 G  connected_order_arc_451
 L  arc_capacity_452
 G  connected_order_arc_453
 L  arc_capacity_454
 G  connected_order_arc_455
 L  arc_capacity_456
 G  connected_order_arc_457
 L  arc_capacity_458
 G  connected_order_arc_459
 L  arc_capacity_460
 G  connected_order_arc_461
 L  arc_capacity_462
 G  connected_order_arc_463
 L  arc_capacity_464
 G  connected_order_arc_465
 L  arc_capacity_466
 G  connected_order_arc_467
 L  arc_capacity_468
 G  connected_order_arc_469
 L  arc_capacity_470
 G  connected_order_arc_471
 L  arc_capacity_472
 G  connected_order_arc_473
 L  arc_capacity_474
 G  connected_order_arc_475
 L  arc_capacity_476
 L  arc_capacity_477
 G  connected_order_arc_478
 L  arc_capacity_479
 G  connected_order_arc_480
 L  arc_capacity_481
 G  connected_order_arc_482
 L  arc_capacity_483
 G  connected_order_arc_484
 L  arc_capacity_485
 G  connected_order_arc_486
 L  arc_capacity_487
 G  connected_order_arc_488
 L  arc_capacity_489
 G  connected_order_arc_490
 L  arc_capacity_491
 G  connected_order_arc_492
 L  arc_capacity_493
 G  connected_order_arc_494
 L  arc_capacity_495
 G  connected_order_arc_496
 L  arc_capacity_497
 G  connected_order_arc_498
 L  arc_capacity_499
 G  connected_order_arc_500
 L  arc_capacity_501
 G  connected_order_arc_502
 L  arc_capacity_503
 L  arc_capacity_504
 G  connected_order_arc_505
 L  arc_capacity_506
 G  connected_order_arc_507
 L  arc_capacity_508
 G  connected_order_arc_509
 L  arc_capacity_510
 G  connected_order_arc_511
 L  arc_capacity_512
 G  connected_order_arc_513
 L  arc_capacity_514
 G  connected_order_arc_515
 L  arc_capacity_516
 G  connected_order_arc_517
 L  arc_capacity_518
 G  connected_order_arc_519
 L  arc_capacity_520
 G  connected_order_arc_521
 L  arc_capacity_522
 G  connected_order_arc_523
 L  arc_capacity_524
 G  connected_order_arc_525
 L  arc_capacity_526
 G  connected_order_arc_527
 L  arc_capacity_528
 G  connected_order_arc_529
 L  arc_capacity_530
 L  arc_capacity_531
 G  connected_order_arc_532
 L  arc_capacity_533
 G  connected_order_arc_534
 L  arc_capacity_535
 G  connected_order_arc_536
 L  arc_capacity_537
 G  connected_order_arc_538
 L  arc_capacity_539
 G  connected_order_arc_540
 L  arc_capacity_541
 G  connected_order_arc_542
 L  arc_capacity_543
 G  connected_order_arc_544
 L  arc_capacity_545
 G  connected_order_arc_546
 L  arc_capacity_547
 G  connected_order_arc_548
 L  arc_capacity_549
 G  connected_order_arc_550
 L  arc_capacity_551
 G  connected_order_arc_552
 L  arc_capacity_553
 G  connected_order_arc_554
 L  arc_capacity_555
 G  connected_order_arc_556
 L  arc_capacity_557
 L  arc_capacity_558
 G  connected_order_arc_559
 L  arc_capacity_560
 G  connected_order_arc_561
 L  arc_capacity_562
 G  connected_order_arc_563
 L  arc_capacity_564
 G  connected_order_arc_565
 L  arc_capacity_566
 G  connected_order_arc_567
 L  arc_capacity_568
 G  connected_order_arc_569
 L  arc_capacity_570
 G  connected_order_arc_571
 L  arc_capacity_572
 G  connected_order_arc_573
 L  arc_capacity_574
 G  connected_order_arc_575
 L  arc_capacity_576
 G  connected_order_arc_577
 L  arc_capacity_578
 G  connected_order_arc_579
 L  arc_capacity_580
 G  connected_order_arc_581
 L  arc_capacity_582
 G  connected_order_arc_583
 L  arc_capacity_584
 L  arc_capacity_585
 G  connected_order_arc_586
 L  arc_capacity_587
 G  connected_order_arc_588
 L  arc_capacity_589
 G  connected_order_arc_590
 L  arc_capacity_591
 G  connected_order_arc_592
 L  arc_capacity_593
 G  connected_order_arc_594
 L  arc_capacity_595
 G  connected_order_arc_596
 L  arc_capacity_597
 G  connected_order_arc_598
 L  arc_capacity_599
 G  connected_order_arc_600
 L  arc_capacity_601
 G  connected_order_arc_602
 L  arc_capacity_603
 G  connected_order_arc_604
 L  arc_capacity_605
 G  connected_order_arc_606
 L  arc_capacity_607
 G  connected_order_arc_608
 L  arc_capacity_609
 G  connected_order_arc_610
 L  arc_capacity_611
 L  arc_capacity_612
 G  connected_order_arc_613
 L  arc_capacity_614
 G  connected_order_arc_615
 L  arc_capacity_616
 G  connected_order_arc_617
 L  arc_capacity_618
 G  connected_order_arc_619
 L  arc_capacity_620
 G  connected_order_arc_621
 L  arc_capacity_622
 G  connected_order_arc_623
 L  arc_capacity_624
 G  connected_order_arc_625
 L  arc_capacity_626
 G  connected_order_arc_627
 L  arc_capacity_628
 G  connected_order_arc_629
 L  arc_capacity_630
 G  connected_order_arc_631
 L  arc_capacity_632
 G  connected_order_arc_633
 L  arc_capacity_634
 G  connected_order_arc_635
 L  arc_capacity_636
 G  connected_order_arc_637
 L  arc_capacity_638
 L  arc_capacity_639
 G  connected_order_arc_640
 L  arc_capacity_641
 G  connected_order_arc_642
 L  arc_capacity_643
 G  connected_order_arc_644
 L  arc_capacity_645
 G  connected_order_arc_646
 L  arc_capacity_647
 G  connected_order_arc_648
 L  arc_capacity_649
 G  connected_order_arc_650
 L  arc_capacity_651
 G  connected_order_arc_652
 L  arc_capacity_653
 G  connected_order_arc_654
 L  arc_capacity_655
 G  connected_order_arc_656
 L  arc_capacity_657
 G  connected_order_arc_658
 L  arc_capacity_659
 G  connected_order_arc_660
 L  arc_capacity_661
 G  connected_order_arc_662
 L  arc_capacity_663
 G  connected_order_arc_664
 L  arc_capacity_665
 L  arc_capacity_666
 G  connected_order_arc_667
 L  arc_capacity_668
 G  connected_order_arc_669
 L  arc_capacity_670
 G  connected_order_arc_671
 L  arc_capacity_672
 G  connected_order_arc_673
 L  arc_capacity_674
 G  connected_order_arc_675
 L  arc_capacity_676
 G  connected_order_arc_677
 L  arc_capacity_678
 G  connected_order_arc_679
 L  arc_capacity_680
 G  connected_order_arc_681
 L  arc_capacity_682
 G  connected_order_arc_683
 L  arc_capacity_684
 G  connected_order_arc_685
 L  arc_capacity_686
 G  connected_order_arc_687
 L  arc_capacity_688
 G  connected_order_arc_689
 L  arc_capacity_690
 G  connected_order_arc_691
 L  arc_capacity_692
 L  arc_capacity_693
 G  connected_order_arc_694
 L  arc_capacity_695
 G  connected_order_arc_696
 L  arc_capacity_697
 G  connected_order_arc_698
 L  arc_capacity_699
 G  connected_order_arc_700
 L  arc_capacity_701
 G  connected_order_arc_702
 L  arc_capacity_703
 G  connected_order_arc_704
 L  arc_capacity_705
 G  connected_order_arc_706
 L  arc_capacity_707
 G  connected_order_arc_708
 L  arc_capacity_709
 G  connected_order_arc_710
 L  arc_capacity_711
 G  connected_order_arc_712
 L  arc_capacity_713
 G  connected_order_arc_714
 L  arc_capacity_715
 G  connected_order_arc_716
 L  arc_capacity_717
 G  connected_order_arc_718
 L  arc_capacity_719
 L  arc_capacity_720
 G  connected_order_arc_721
 L  arc_capacity_722
 G  connected_order_arc_723
 L  arc_capacity_724
 G  connected_order_arc_725
 L  arc_capacity_726
 G  connected_order_arc_727
 L  arc_capacity_728
 G  connected_order_arc_729
 L  arc_capacity_730
 G  connected_order_arc_731
 L  arc_capacity_732
 G  connected_order_arc_733
 L  arc_capacity_734
 G  connected_order_arc_735
 L  arc_capacity_736
 G  connected_order_arc_737
 L  arc_capacity_738
 G  connected_order_arc_739
 L  arc_capacity_740
 G  connected_order_arc_741
 L  arc_capacity_742
 G  connected_order_arc_743
 L  arc_capacity_744
 G  connected_order_arc_745
 L  arc_capacity_746
 L  arc_capacity_747
 G  connected_order_arc_748
 L  arc_capacity_749
 G  connected_order_arc_750
 L  arc_capacity_751
 G  connected_order_arc_752
 L  arc_capacity_753
 G  connected_order_arc_754
 L  arc_capacity_755
 G  connected_order_arc_756
 L  arc_capacity_757
 G  connected_order_arc_758
 L  arc_capacity_759
 G  connected_order_arc_760
 L  arc_capacity_761
 G  connected_order_arc_762
 L  arc_capacity_763
 G  connected_order_arc_764
 L  arc_capacity_765
 G  connected_order_arc_766
 L  arc_capacity_767
 G  connected_order_arc_768
 L  arc_capacity_769
 G  connected_order_arc_770
 L  arc_capacity_771
 G  connected_order_arc_772
 E  depot_departure_or_bypass_773
 E  depot_return_or_bypass_774
 E  out_degree_775
 E  in_degree_776
 G  order_active_lb_777
 L  order_active_ub_778
 E  segment_load_conservation_779
 G  segment_prefix_lb_780
 L  segment_prefix_ub_781
 E  out_degree_782
 E  in_degree_783
 G  order_active_lb_784
 L  order_active_ub_785
 E  segment_load_conservation_786
 G  segment_prefix_lb_787
 L  segment_prefix_ub_788
 E  out_degree_789
 E  in_degree_790
 G  order_active_lb_791
 L  order_active_ub_792
 E  segment_load_conservation_793
 G  segment_prefix_lb_794
 L  segment_prefix_ub_795
 E  out_degree_796
 E  in_degree_797
 G  order_active_lb_798
 L  order_active_ub_799
 E  segment_load_conservation_800
 G  segment_prefix_lb_801
 L  segment_prefix_ub_802
 E  out_degree_803
 E  in_degree_804
 G  order_active_lb_805
 L  order_active_ub_806
 E  segment_load_conservation_807
 G  segment_prefix_lb_808
 L  segment_prefix_ub_809
 E  out_degree_810
 E  in_degree_811
 G  order_active_lb_812
 L  order_active_ub_813
 E  segment_load_conservation_814
 G  segment_prefix_lb_815
 L  segment_prefix_ub_816
 E  out_degree_817
 E  in_degree_818
 G  order_active_lb_819
 L  order_active_ub_820
 E  service_visit_def_821
 E  free_load_conservation_822
 E  out_degree_823
 E  in_degree_824
 G  order_active_lb_825
 L  order_active_ub_826
 E  service_visit_def_827
 E  free_load_conservation_828
 E  out_degree_829
 E  in_degree_830
 G  order_active_lb_831
 L  order_active_ub_832
 E  service_visit_def_833
 E  free_load_conservation_834
 E  out_degree_835
 E  in_degree_836
 G  order_active_lb_837
 L  order_active_ub_838
 E  service_visit_def_839
 E  free_load_conservation_840
 E  out_degree_841
 E  in_degree_842
 G  order_active_lb_843
 L  order_active_ub_844
 E  service_visit_def_845
 E  free_load_conservation_846
 E  out_degree_847
 E  in_degree_848
 G  order_active_lb_849
 L  order_active_ub_850
 E  service_visit_def_851
 E  free_load_conservation_852
 E  out_degree_853
 E  in_degree_854
 G  order_active_lb_855
 L  order_active_ub_856
 E  service_visit_def_857
 E  free_load_conservation_858
 E  out_degree_859
 E  in_degree_860
 G  order_active_lb_861
 L  order_active_ub_862
 E  service_visit_def_863
 E  free_load_conservation_864
 G  fixed_segment_relative_order_865
 G  fixed_segment_relative_order_866
 G  fixed_segment_relative_order_867
 G  fixed_segment_relative_order_868
 G  fixed_segment_relative_order_869
 L  original_T_including_depot_unload_870
 L  arc_capacity_871
 L  arc_capacity_872
 L  arc_capacity_873
 L  arc_capacity_874
 L  arc_capacity_875
 L  arc_capacity_876
 L  arc_capacity_877
 L  arc_capacity_878
 L  arc_capacity_879
 L  arc_capacity_880
 L  arc_capacity_881
 L  arc_capacity_882
 G  connected_order_arc_883
 L  arc_capacity_884
 G  connected_order_arc_885
 L  arc_capacity_886
 G  connected_order_arc_887
 L  arc_capacity_888
 G  connected_order_arc_889
 L  arc_capacity_890
 G  connected_order_arc_891
 L  arc_capacity_892
 G  connected_order_arc_893
 L  arc_capacity_894
 G  connected_order_arc_895
 L  arc_capacity_896
 G  connected_order_arc_897
 L  arc_capacity_898
 L  arc_capacity_899
 G  connected_order_arc_900
 L  arc_capacity_901
 G  connected_order_arc_902
 L  arc_capacity_903
 G  connected_order_arc_904
 L  arc_capacity_905
 G  connected_order_arc_906
 L  arc_capacity_907
 G  connected_order_arc_908
 L  arc_capacity_909
 G  connected_order_arc_910
 L  arc_capacity_911
 G  connected_order_arc_912
 L  arc_capacity_913
 G  connected_order_arc_914
 L  arc_capacity_915
 L  arc_capacity_916
 G  connected_order_arc_917
 L  arc_capacity_918
 G  connected_order_arc_919
 L  arc_capacity_920
 G  connected_order_arc_921
 L  arc_capacity_922
 G  connected_order_arc_923
 L  arc_capacity_924
 G  connected_order_arc_925
 L  arc_capacity_926
 G  connected_order_arc_927
 L  arc_capacity_928
 G  connected_order_arc_929
 L  arc_capacity_930
 G  connected_order_arc_931
 L  arc_capacity_932
 L  arc_capacity_933
 G  connected_order_arc_934
 L  arc_capacity_935
 G  connected_order_arc_936
 L  arc_capacity_937
 G  connected_order_arc_938
 L  arc_capacity_939
 G  connected_order_arc_940
 L  arc_capacity_941
 G  connected_order_arc_942
 L  arc_capacity_943
 G  connected_order_arc_944
 L  arc_capacity_945
 G  connected_order_arc_946
 L  arc_capacity_947
 G  connected_order_arc_948
 L  arc_capacity_949
 L  arc_capacity_950
 G  connected_order_arc_951
 L  arc_capacity_952
 G  connected_order_arc_953
 L  arc_capacity_954
 G  connected_order_arc_955
 L  arc_capacity_956
 G  connected_order_arc_957
 L  arc_capacity_958
 G  connected_order_arc_959
 L  arc_capacity_960
 G  connected_order_arc_961
 L  arc_capacity_962
 G  connected_order_arc_963
 L  arc_capacity_964
 G  connected_order_arc_965
 L  arc_capacity_966
 L  arc_capacity_967
 G  connected_order_arc_968
 L  arc_capacity_969
 G  connected_order_arc_970
 L  arc_capacity_971
 G  connected_order_arc_972
 L  arc_capacity_973
 G  connected_order_arc_974
 L  arc_capacity_975
 G  connected_order_arc_976
 L  arc_capacity_977
 G  connected_order_arc_978
 L  arc_capacity_979
 G  connected_order_arc_980
 L  arc_capacity_981
 G  connected_order_arc_982
 L  arc_capacity_983
 L  arc_capacity_984
 G  connected_order_arc_985
 L  arc_capacity_986
 G  connected_order_arc_987
 L  arc_capacity_988
 G  connected_order_arc_989
 L  arc_capacity_990
 G  connected_order_arc_991
 L  arc_capacity_992
 G  connected_order_arc_993
 L  arc_capacity_994
 G  connected_order_arc_995
 L  arc_capacity_996
 G  connected_order_arc_997
 L  arc_capacity_998
 G  connected_order_arc_999
 L  arc_capacity_1000
 L  arc_capacity_1001
 G  connected_order_arc_1002
 L  arc_capacity_1003
 G  connected_order_arc_1004
 L  arc_capacity_1005
 G  connected_order_arc_1006
 L  arc_capacity_1007
 G  connected_order_arc_1008
 L  arc_capacity_1009
 G  connected_order_arc_1010
 L  arc_capacity_1011
 G  connected_order_arc_1012
 L  arc_capacity_1013
 G  connected_order_arc_1014
 L  arc_capacity_1015
 G  connected_order_arc_1016
 L  arc_capacity_1017
 L  arc_capacity_1018
 G  connected_order_arc_1019
 L  arc_capacity_1020
 G  connected_order_arc_1021
 L  arc_capacity_1022
 G  connected_order_arc_1023
 L  arc_capacity_1024
 G  connected_order_arc_1025
 L  arc_capacity_1026
 G  connected_order_arc_1027
 L  arc_capacity_1028
 G  connected_order_arc_1029
 L  arc_capacity_1030
 G  connected_order_arc_1031
 L  arc_capacity_1032
 G  connected_order_arc_1033
 E  depot_departure_or_bypass_1034
 E  depot_return_or_bypass_1035
 E  out_degree_1036
 E  in_degree_1037
 G  order_active_lb_1038
 L  order_active_ub_1039
 E  segment_load_conservation_1040
 G  segment_prefix_lb_1041
 L  segment_prefix_ub_1042
 E  out_degree_1043
 E  in_degree_1044
 G  order_active_lb_1045
 L  order_active_ub_1046
 E  service_visit_def_1047
 E  free_load_conservation_1048
 E  out_degree_1049
 E  in_degree_1050
 G  order_active_lb_1051
 L  order_active_ub_1052
 E  service_visit_def_1053
 E  free_load_conservation_1054
 E  out_degree_1055
 E  in_degree_1056
 G  order_active_lb_1057
 L  order_active_ub_1058
 E  service_visit_def_1059
 E  free_load_conservation_1060
 E  out_degree_1061
 E  in_degree_1062
 G  order_active_lb_1063
 L  order_active_ub_1064
 E  service_visit_def_1065
 E  free_load_conservation_1066
 E  out_degree_1067
 E  in_degree_1068
 G  order_active_lb_1069
 L  order_active_ub_1070
 E  service_visit_def_1071
 E  free_load_conservation_1072
 E  out_degree_1073
 E  in_degree_1074
 G  order_active_lb_1075
 L  order_active_ub_1076
 E  service_visit_def_1077
 E  free_load_conservation_1078
 E  out_degree_1079
 E  in_degree_1080
 G  order_active_lb_1081
 L  order_active_ub_1082
 E  service_visit_def_1083
 E  free_load_conservation_1084
 E  out_degree_1085
 E  in_degree_1086
 G  order_active_lb_1087
 L  order_active_ub_1088
 E  service_visit_def_1089
 E  free_load_conservation_1090
 L  original_T_including_depot_unload_1091
COLUMNS
    t         normalized_mass_17_35  -1
    t         normalized_mass_14_70  -1
    t         normalized_mass_18_105  -1
    t         normalized_mass_13_112  -1
    t         normalized_mass_20_147  -1
    t         normalized_mass_12_182  -1
    t         normalized_mass_11_217  -1
    t         normalized_mass_10_224  -1
    t         normalization_285  7.2964285714285708e+00
    t         full_original_Gini_286  -3.5060714285714283e+01
    q         OBJ       1
    q         parent_nonstrict_scope_228  1
    q         full_original_Gini_286  20
    MARKER    'MARKER'                 'INTORG'
    x_17_0    OBJ       6.3380304899829959e-02
    x_17_0    product_lb_0  -4.7052672853174743e-02
    x_17_0    product_ub_1  -1.3705335291252085e-01
    x_17_0    onehot_17_34  1
    x_17_0    parent_nonstrict_scope_228  1.2676060979965992e-01
    x_17_0    unique_nonzero_owner_287  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_0    product_lb_0  1
    w_17_0    product_ub_1  1
    w_17_0    normalized_mass_17_35  1
    w_17_0    full_original_Gini_286  -7.2964285714285708e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_1    OBJ       4.9295792699867738e-02
    x_17_1    product_lb_2  -4.7052672853174743e-02
    x_17_1    product_ub_3  -1.3705335291252085e-01
    x_17_1    onehot_17_34  1
    x_17_1    stock_lb_226  1
    x_17_1    stock_ub_227  1
    x_17_1    parent_nonstrict_scope_228  1.1267609759969770e-01
    x_17_1    unique_nonzero_owner_288  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_1    product_lb_2  1
    w_17_1    product_ub_3  1
    w_17_1    normalized_mass_17_35  1
    w_17_1    normalized_ratio_17_36  -1.1111111111111110e-01
    w_17_1    full_original_Gini_286  -6.8519841269841262e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_2    OBJ       3.5211280499905531e-02
    x_17_2    product_lb_4  -4.7052672853174743e-02
    x_17_2    product_ub_5  -1.3705335291252085e-01
    x_17_2    onehot_17_34  1
    x_17_2    stock_lb_226  2
    x_17_2    stock_ub_227  2
    x_17_2    parent_nonstrict_scope_228  9.8591585399735490e-02
    x_17_2    unique_nonzero_owner_289  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_2    product_lb_4  1
    w_17_2    product_ub_5  1
    w_17_2    normalized_mass_17_35  1
    w_17_2    normalized_ratio_17_36  -2.2222222222222221e-01
    w_17_2    full_original_Gini_286  -6.4075396825396824e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_3    OBJ       2.1126768299943324e-02
    x_17_3    product_lb_6  -4.7052672853174743e-02
    x_17_3    product_ub_7  -1.3705335291252085e-01
    x_17_3    onehot_17_34  1
    x_17_3    stock_lb_226  3
    x_17_3    stock_ub_227  3
    x_17_3    parent_nonstrict_scope_228  8.4507073199773283e-02
    MARKER    'MARKER'                 'INTEND'
    w_17_3    product_lb_6  1
    w_17_3    product_ub_7  1
    w_17_3    normalized_mass_17_35  1
    w_17_3    normalized_ratio_17_36  -3.3333333333333331e-01
    w_17_3    full_original_Gini_286  -5.9630952380952387e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_4    OBJ       7.0422560999811035e-03
    x_17_4    product_lb_8  -4.7052672853174743e-02
    x_17_4    product_ub_9  -1.3705335291252085e-01
    x_17_4    onehot_17_34  1
    x_17_4    stock_lb_226  4
    x_17_4    stock_ub_227  4
    x_17_4    parent_nonstrict_scope_228  7.0422560999811062e-02
    x_17_4    unique_nonzero_owner_290  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_4    product_lb_8  1
    w_17_4    product_ub_9  1
    w_17_4    normalized_mass_17_35  1
    w_17_4    normalized_ratio_17_36  -4.4444444444444442e-01
    w_17_4    full_original_Gini_286  -5.5186507936507940e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_5    OBJ       -0.00704225609998111
    x_17_5    product_lb_10  -4.7052672853174743e-02
    x_17_5    product_ub_11  -1.3705335291252085e-01
    x_17_5    onehot_17_34  1
    x_17_5    stock_lb_226  5
    x_17_5    stock_ub_227  5
    x_17_5    parent_nonstrict_scope_228  5.6338048799848849e-02
    x_17_5    unique_nonzero_owner_291  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_5    product_lb_10  1
    w_17_5    product_ub_11  1
    w_17_5    normalized_mass_17_35  1
    w_17_5    normalized_ratio_17_36  -5.5555555555555558e-01
    w_17_5    full_original_Gini_286  -5.0742063492063485e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_6    OBJ       -2.1126768299943317e-02
    x_17_6    product_lb_12  -4.7052672853174743e-02
    x_17_6    product_ub_13  -1.3705335291252085e-01
    x_17_6    onehot_17_34  1
    x_17_6    stock_lb_226  6
    x_17_6    stock_ub_227  6
    x_17_6    parent_nonstrict_scope_228  4.2253536599886642e-02
    x_17_6    unique_nonzero_owner_292  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_6    product_lb_12  1
    w_17_6    product_ub_13  1
    w_17_6    normalized_mass_17_35  1
    w_17_6    normalized_ratio_17_36  -6.6666666666666663e-01
    w_17_6    full_original_Gini_286  -4.9535714285714292e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_7    OBJ       -3.5211280499905517e-02
    x_17_7    product_lb_14  -4.7052672853174743e-02
    x_17_7    product_ub_15  -1.3705335291252085e-01
    x_17_7    onehot_17_34  1
    x_17_7    stock_lb_226  7
    x_17_7    stock_ub_227  7
    x_17_7    parent_nonstrict_scope_228  2.8169024399924438e-02
    x_17_7    unique_nonzero_owner_293  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_7    product_lb_14  1
    w_17_7    product_ub_15  1
    w_17_7    normalized_mass_17_35  1
    w_17_7    normalized_ratio_17_36  -7.7777777777777768e-01
    w_17_7    full_original_Gini_286  -4.9535714285714283e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_8    OBJ       -4.9295792699867738e-02
    x_17_8    product_lb_16  -4.7052672853174743e-02
    x_17_8    product_ub_17  -1.3705335291252085e-01
    x_17_8    onehot_17_34  1
    x_17_8    stock_lb_226  8
    x_17_8    stock_ub_227  8
    x_17_8    parent_nonstrict_scope_228  1.4084512199962219e-02
    x_17_8    unique_nonzero_owner_294  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_8    product_lb_16  1
    w_17_8    product_ub_17  1
    w_17_8    normalized_mass_17_35  1
    w_17_8    normalized_ratio_17_36  -8.8888888888888884e-01
    w_17_8    full_original_Gini_286  -4.9535714285714292e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_9    OBJ       -6.3380304899829959e-02
    x_17_9    product_lb_18  -4.7052672853174743e-02
    x_17_9    product_ub_19  -1.3705335291252085e-01
    x_17_9    onehot_17_34  1
    x_17_9    stock_lb_226  9
    x_17_9    stock_ub_227  9
    x_17_9    unique_nonzero_owner_295  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_9    product_lb_18  1
    w_17_9    product_ub_19  1
    w_17_9    normalized_mass_17_35  1
    w_17_9    normalized_ratio_17_36  -1
    w_17_9    full_original_Gini_286  -4.9535714285714283e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_10   OBJ       -4.9295792699867738e-02
    x_17_10   product_lb_20  -4.7052672853174743e-02
    x_17_10   product_ub_21  -1.3705335291252085e-01
    x_17_10   onehot_17_34  1
    x_17_10   stock_lb_226  10
    x_17_10   stock_ub_227  10
    x_17_10   parent_nonstrict_scope_228  1.4084512199962219e-02
    x_17_10   unique_nonzero_owner_296  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_10   product_lb_20  1
    w_17_10   product_ub_21  1
    w_17_10   normalized_mass_17_35  1
    w_17_10   normalized_ratio_17_36  -1.1111111111111112e+00
    w_17_10   full_original_Gini_286  -6.06468253968254
    MARKER    'MARKER'                 'INTORG'
    x_17_11   OBJ       -3.5211280499905545e-02
    x_17_11   product_lb_22  -4.7052672853174743e-02
    x_17_11   product_ub_23  -1.3705335291252085e-01
    x_17_11   onehot_17_34  1
    x_17_11   stock_lb_226  11
    x_17_11   stock_ub_227  11
    x_17_11   parent_nonstrict_scope_228  2.8169024399924410e-02
    x_17_11   unique_nonzero_owner_297  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_11   product_lb_22  1
    w_17_11   product_ub_23  1
    w_17_11   normalized_mass_17_35  1
    w_17_11   normalized_ratio_17_36  -1.2222222222222221e+00
    w_17_11   full_original_Gini_286  -7.3702380952380953e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_12   OBJ       -2.1126768299943331e-02
    x_17_12   product_lb_24  -4.7052672853174743e-02
    x_17_12   product_ub_25  -1.3705335291252085e-01
    x_17_12   onehot_17_34  1
    x_17_12   stock_lb_226  12
    x_17_12   stock_ub_227  12
    x_17_12   parent_nonstrict_scope_228  4.2253536599886628e-02
    x_17_12   unique_nonzero_owner_298  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_12   product_lb_24  1
    w_17_12   product_ub_25  1
    w_17_12   normalized_mass_17_35  1
    w_17_12   normalized_ratio_17_36  -1.3333333333333333e+00
    w_17_12   full_original_Gini_286  -8.7035714285714256e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_13   OBJ       -0.00704225609998111
    x_17_13   product_lb_26  -4.7052672853174743e-02
    x_17_13   product_ub_27  -1.3705335291252085e-01
    x_17_13   onehot_17_34  1
    x_17_13   stock_lb_226  13
    x_17_13   stock_ub_227  13
    x_17_13   parent_nonstrict_scope_228  5.6338048799848849e-02
    x_17_13   unique_nonzero_owner_299  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_13   product_lb_26  1
    w_17_13   product_ub_27  1
    w_17_13   normalized_mass_17_35  1
    w_17_13   normalized_ratio_17_36  -1.4444444444444444e+00
    w_17_13   full_original_Gini_286  -1.0036904761904763e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_14   OBJ       7.0422560999810757e-03
    x_17_14   product_lb_28  -4.7052672853174743e-02
    x_17_14   product_ub_29  -1.3705335291252085e-01
    x_17_14   onehot_17_34  1
    x_17_14   stock_lb_226  14
    x_17_14   stock_ub_227  14
    x_17_14   parent_nonstrict_scope_228  7.0422560999811035e-02
    x_17_14   unique_nonzero_owner_300  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_14   product_lb_28  1
    w_17_14   product_ub_29  1
    w_17_14   normalized_mass_17_35  1
    w_17_14   normalized_ratio_17_36  -1.5555555555555554e+00
    w_17_14   full_original_Gini_286  -1.1370238095238093e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_15   OBJ       2.1126768299943297e-02
    x_17_15   product_lb_30  -4.7052672853174743e-02
    x_17_15   product_ub_31  -1.3705335291252085e-01
    x_17_15   onehot_17_34  1
    x_17_15   stock_lb_226  15
    x_17_15   stock_ub_227  15
    x_17_15   parent_nonstrict_scope_228  8.4507073199773255e-02
    x_17_15   unique_nonzero_owner_301  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_15   product_lb_30  1
    w_17_15   product_ub_31  1
    w_17_15   normalized_mass_17_35  1
    w_17_15   normalized_ratio_17_36  -1.6666666666666665e+00
    w_17_15   full_original_Gini_286  -1.2703571428571424e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_16   OBJ       3.5211280499905517e-02
    x_17_16   product_lb_32  -4.7052672853174743e-02
    x_17_16   product_ub_33  -1.3705335291252085e-01
    x_17_16   onehot_17_34  1
    x_17_16   stock_lb_226  16
    x_17_16   stock_ub_227  16
    x_17_16   parent_nonstrict_scope_228  9.8591585399735476e-02
    x_17_16   unique_nonzero_owner_302  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_16   product_lb_32  1
    w_17_16   product_ub_33  1
    w_17_16   normalized_mass_17_35  1
    w_17_16   normalized_ratio_17_36  -1.7777777777777777e+00
    w_17_16   full_original_Gini_286  -1.4036904761904765e+01
    rho_17    normalized_ratio_17_36  1
    rho_17    block_pair_pos_255  -1
    rho_17    block_pair_neg_256  1
    rho_17    block_pair_pos_257  -1
    rho_17    block_pair_neg_258  1
    rho_17    block_pair_pos_259  -1
    rho_17    block_pair_neg_260  1
    rho_17    block_pair_pos_261  -1
    rho_17    block_pair_neg_262  1
    rho_17    block_pair_pos_263  -1
    rho_17    block_pair_neg_264  1
    rho_17    block_pair_pos_265  -1
    rho_17    block_pair_neg_266  1
    rho_17    block_pair_pos_267  -1
    rho_17    block_pair_neg_268  1
    rho_17    normalization_285  1
    MARKER    'MARKER'                 'INTORG'
    x_14_0    OBJ       3.2863847044708572e-02
    x_14_0    product_lb_37  -4.7052672853174743e-02
    x_14_0    product_ub_38  -1.3705335291252085e-01
    x_14_0    onehot_14_69  1
    x_14_0    parent_nonstrict_scope_228  7.6682309770986667e-02
    x_14_0    unique_nonzero_owner_303  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_0    product_lb_37  1
    w_14_0    product_ub_38  1
    w_14_0    normalized_mass_14_70  1
    w_14_0    full_original_Gini_286  -7.2964285714285708e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_1    OBJ       2.1909231363139048e-02
    x_14_1    product_lb_39  -4.7052672853174743e-02
    x_14_1    product_ub_40  -1.3705335291252085e-01
    x_14_1    onehot_14_69  1
    x_14_1    stock_lb_226  1
    x_14_1    stock_ub_227  1
    x_14_1    parent_nonstrict_scope_228  6.5727694089417144e-02
    x_14_1    unique_nonzero_owner_304  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_1    product_lb_39  1
    w_14_1    product_ub_40  1
    w_14_1    normalized_mass_14_70  1
    w_14_1    normalized_ratio_14_71  -1.4285714285714285e-01
    w_14_1    full_original_Gini_286  -6.7250000000000005e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_2    OBJ       1.0954615681569524e-02
    x_14_2    product_lb_41  -4.7052672853174743e-02
    x_14_2    product_ub_42  -1.3705335291252085e-01
    x_14_2    onehot_14_69  1
    x_14_2    stock_lb_226  2
    x_14_2    stock_ub_227  2
    x_14_2    parent_nonstrict_scope_228  5.4773078407847620e-02
    x_14_2    unique_nonzero_owner_305  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_2    product_lb_41  1
    w_14_2    product_ub_42  1
    w_14_2    normalized_mass_14_70  1
    w_14_2    normalized_ratio_14_71  -2.8571428571428570e-01
    w_14_2    full_original_Gini_286  -6.1535714285714294e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_3    product_lb_43  -4.7052672853174743e-02
    x_14_3    product_ub_44  -1.3705335291252085e-01
    x_14_3    onehot_14_69  1
    x_14_3    stock_lb_226  3
    x_14_3    stock_ub_227  3
    x_14_3    parent_nonstrict_scope_228  4.3818462726278096e-02
    x_14_3    unique_nonzero_owner_306  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_3    product_lb_43  1
    w_14_3    product_ub_44  1
    w_14_3    normalized_mass_14_70  1
    w_14_3    normalized_ratio_14_71  -4.2857142857142855e-01
    w_14_3    full_original_Gini_286  -5.5821428571428573e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_4    OBJ       -1.0954615681569524e-02
    x_14_4    product_lb_45  -4.7052672853174743e-02
    x_14_4    product_ub_46  -1.3705335291252085e-01
    x_14_4    onehot_14_69  1
    x_14_4    stock_lb_226  4
    x_14_4    stock_ub_227  4
    x_14_4    parent_nonstrict_scope_228  3.2863847044708572e-02
    x_14_4    unique_nonzero_owner_307  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_4    product_lb_45  1
    w_14_4    product_ub_46  1
    w_14_4    normalized_mass_14_70  1
    w_14_4    normalized_ratio_14_71  -5.7142857142857140e-01
    w_14_4    full_original_Gini_286  -5.0107142857142852e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_5    OBJ       -2.1909231363139041e-02
    x_14_5    product_lb_47  -4.7052672853174743e-02
    x_14_5    product_ub_48  -1.3705335291252085e-01
    x_14_5    onehot_14_69  1
    x_14_5    stock_lb_226  5
    x_14_5    stock_ub_227  5
    x_14_5    parent_nonstrict_scope_228  2.1909231363139055e-02
    x_14_5    unique_nonzero_owner_308  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_5    product_lb_47  1
    w_14_5    product_ub_48  1
    w_14_5    normalized_mass_14_70  1
    w_14_5    normalized_ratio_14_71  -7.1428571428571419e-01
    w_14_5    full_original_Gini_286  -4.9535714285714283e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_6    OBJ       -3.2863847044708572e-02
    x_14_6    product_lb_49  -4.7052672853174743e-02
    x_14_6    product_ub_50  -1.3705335291252085e-01
    x_14_6    onehot_14_69  1
    x_14_6    stock_lb_226  6
    x_14_6    stock_ub_227  6
    x_14_6    parent_nonstrict_scope_228  1.0954615681569527e-02
    x_14_6    unique_nonzero_owner_309  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_6    product_lb_49  1
    w_14_6    product_ub_50  1
    w_14_6    normalized_mass_14_70  1
    w_14_6    normalized_ratio_14_71  -8.5714285714285710e-01
    w_14_6    full_original_Gini_286  -4.9535714285714283e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_7    OBJ       -4.3818462726278096e-02
    x_14_7    product_lb_51  -4.7052672853174743e-02
    x_14_7    product_ub_52  -1.3705335291252085e-01
    x_14_7    onehot_14_69  1
    x_14_7    stock_lb_226  7
    x_14_7    stock_ub_227  7
    x_14_7    unique_nonzero_owner_310  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_7    product_lb_51  1
    w_14_7    product_ub_52  1
    w_14_7    normalized_mass_14_70  1
    w_14_7    normalized_ratio_14_71  -1
    w_14_7    full_original_Gini_286  -4.9535714285714283e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_8    OBJ       -3.2863847044708579e-02
    x_14_8    product_lb_53  -4.7052672853174743e-02
    x_14_8    product_ub_54  -1.3705335291252085e-01
    x_14_8    onehot_14_69  1
    x_14_8    stock_lb_226  8
    x_14_8    stock_ub_227  8
    x_14_8    parent_nonstrict_scope_228  1.0954615681569519e-02
    x_14_8    unique_nonzero_owner_311  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_8    product_lb_53  1
    w_14_8    product_ub_54  1
    w_14_8    normalized_mass_14_70  1
    w_14_8    normalized_ratio_14_71  -1.1428571428571428e+00
    w_14_8    full_original_Gini_286  -6.4178571428571409e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_9    OBJ       -2.1909231363139058e-02
    x_14_9    product_lb_55  -4.7052672853174743e-02
    x_14_9    product_ub_56  -1.3705335291252085e-01
    x_14_9    onehot_14_69  1
    x_14_9    stock_lb_226  9
    x_14_9    stock_ub_227  9
    x_14_9    parent_nonstrict_scope_228  2.1909231363139037e-02
    x_14_9    unique_nonzero_owner_312  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_9    product_lb_55  1
    w_14_9    product_ub_56  1
    w_14_9    normalized_mass_14_70  1
    w_14_9    normalized_ratio_14_71  -1.2857142857142856e+00
    w_14_9    full_original_Gini_286  -8.1321428571428562e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_10   OBJ       -1.0954615681569538e-02
    x_14_10   product_lb_57  -4.7052672853174743e-02
    x_14_10   product_ub_58  -1.3705335291252085e-01
    x_14_10   onehot_14_69  1
    x_14_10   stock_lb_226  10
    x_14_10   stock_ub_227  10
    x_14_10   parent_nonstrict_scope_228  3.2863847044708558e-02
    x_14_10   unique_nonzero_owner_313  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_10   product_lb_57  1
    w_14_10   product_ub_58  1
    w_14_10   normalized_mass_14_70  1
    w_14_10   normalized_ratio_14_71  -1.4285714285714284e+00
    w_14_10   full_original_Gini_286  -9.8464285714285715e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_11   product_lb_59  -4.7052672853174743e-02
    x_14_11   product_ub_60  -1.3705335291252085e-01
    x_14_11   onehot_14_69  1
    x_14_11   stock_lb_226  11
    x_14_11   stock_ub_227  11
    x_14_11   parent_nonstrict_scope_228  4.3818462726278096e-02
    MARKER    'MARKER'                 'INTEND'
    w_14_11   product_lb_59  1
    w_14_11   product_ub_60  1
    w_14_11   normalized_mass_14_70  1
    w_14_11   normalized_ratio_14_71  -1.5714285714285714e+00
    w_14_11   full_original_Gini_286  -1.1560714285714283e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_12   OBJ       1.0954615681569517e-02
    x_14_12   product_lb_61  -4.7052672853174743e-02
    x_14_12   product_ub_62  -1.3705335291252085e-01
    x_14_12   onehot_14_69  1
    x_14_12   stock_lb_226  12
    x_14_12   stock_ub_227  12
    x_14_12   parent_nonstrict_scope_228  5.4773078407847613e-02
    x_14_12   unique_nonzero_owner_314  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_12   product_lb_61  1
    w_14_12   product_ub_62  1
    w_14_12   normalized_mass_14_70  1
    w_14_12   normalized_ratio_14_71  -1.7142857142857142e+00
    w_14_12   full_original_Gini_286  -1.3274999999999997e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_13   OBJ       2.1909231363139034e-02
    x_14_13   product_lb_63  -4.7052672853174743e-02
    x_14_13   product_ub_64  -1.3705335291252085e-01
    x_14_13   onehot_14_69  1
    x_14_13   stock_lb_226  13
    x_14_13   stock_ub_227  13
    x_14_13   parent_nonstrict_scope_228  6.5727694089417130e-02
    x_14_13   unique_nonzero_owner_315  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_13   product_lb_63  1
    w_14_13   product_ub_64  1
    w_14_13   normalized_mass_14_70  1
    w_14_13   normalized_ratio_14_71  -1.8571428571428570e+00
    w_14_13   full_original_Gini_286  -1.4989285714285714e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_14   OBJ       3.2863847044708572e-02
    x_14_14   product_lb_65  -4.7052672853174743e-02
    x_14_14   product_ub_66  -1.3705335291252085e-01
    x_14_14   onehot_14_69  1
    x_14_14   stock_lb_226  14
    x_14_14   stock_ub_227  14
    x_14_14   parent_nonstrict_scope_228  7.6682309770986667e-02
    x_14_14   unique_nonzero_owner_316  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_14   product_lb_65  1
    w_14_14   product_ub_66  1
    w_14_14   normalized_mass_14_70  1
    w_14_14   normalized_ratio_14_71  -2
    w_14_14   full_original_Gini_286  -1.6703571428571429e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_15   OBJ       4.3818462726278096e-02
    x_14_15   product_lb_67  -4.7052672853174743e-02
    x_14_15   product_ub_68  -1.3705335291252085e-01
    x_14_15   onehot_14_69  1
    x_14_15   stock_lb_226  15
    x_14_15   stock_ub_227  15
    x_14_15   parent_nonstrict_scope_228  8.7636925452556191e-02
    x_14_15   unique_nonzero_owner_317  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_15   product_lb_67  1
    w_14_15   product_ub_68  1
    w_14_15   normalized_mass_14_70  1
    w_14_15   normalized_ratio_14_71  -2.1428571428571428e+00
    w_14_15   full_original_Gini_286  -1.8417857142857141e+01
    rho_14    normalized_ratio_14_71  1
    rho_14    block_pair_pos_243  -1
    rho_14    block_pair_neg_244  1
    rho_14    block_pair_pos_245  -1
    rho_14    block_pair_neg_246  1
    rho_14    block_pair_pos_247  -1
    rho_14    block_pair_neg_248  1
    rho_14    block_pair_pos_249  -1
    rho_14    block_pair_neg_250  1
    rho_14    block_pair_pos_251  -1
    rho_14    block_pair_neg_252  1
    rho_14    block_pair_pos_253  -1
    rho_14    block_pair_neg_254  1
    rho_14    block_pair_pos_263  1
    rho_14    block_pair_neg_264  -1
    rho_14    normalization_285  1
    MARKER    'MARKER'                 'INTORG'
    x_18_0    OBJ       3.2863847044708572e-02
    x_18_0    product_lb_72  -4.7052672853174743e-02
    x_18_0    product_ub_73  -1.3705335291252085e-01
    x_18_0    onehot_18_104  1
    x_18_0    parent_nonstrict_scope_228  7.6682309770986667e-02
    MARKER    'MARKER'                 'INTEND'
    w_18_0    product_lb_72  1
    w_18_0    product_ub_73  1
    w_18_0    normalized_mass_18_105  1
    w_18_0    full_original_Gini_286  -7.2964285714285708e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_1    OBJ       2.1909231363139048e-02
    x_18_1    product_lb_74  -4.7052672853174743e-02
    x_18_1    product_ub_75  -1.3705335291252085e-01
    x_18_1    onehot_18_104  1
    x_18_1    stock_lb_226  1
    x_18_1    stock_ub_227  1
    x_18_1    parent_nonstrict_scope_228  6.5727694089417144e-02
    x_18_1    unique_nonzero_owner_318  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_1    product_lb_74  1
    w_18_1    product_ub_75  1
    w_18_1    normalized_mass_18_105  1
    w_18_1    normalized_ratio_18_106  -1.4285714285714285e-01
    w_18_1    full_original_Gini_286  -6.7250000000000005e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_2    OBJ       1.0954615681569524e-02
    x_18_2    product_lb_76  -4.7052672853174743e-02
    x_18_2    product_ub_77  -1.3705335291252085e-01
    x_18_2    onehot_18_104  1
    x_18_2    stock_lb_226  2
    x_18_2    stock_ub_227  2
    x_18_2    parent_nonstrict_scope_228  5.4773078407847620e-02
    x_18_2    unique_nonzero_owner_319  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_2    product_lb_76  1
    w_18_2    product_ub_77  1
    w_18_2    normalized_mass_18_105  1
    w_18_2    normalized_ratio_18_106  -2.8571428571428570e-01
    w_18_2    full_original_Gini_286  -6.1535714285714294e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_3    product_lb_78  -4.7052672853174743e-02
    x_18_3    product_ub_79  -1.3705335291252085e-01
    x_18_3    onehot_18_104  1
    x_18_3    stock_lb_226  3
    x_18_3    stock_ub_227  3
    x_18_3    parent_nonstrict_scope_228  4.3818462726278096e-02
    x_18_3    unique_nonzero_owner_320  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_3    product_lb_78  1
    w_18_3    product_ub_79  1
    w_18_3    normalized_mass_18_105  1
    w_18_3    normalized_ratio_18_106  -4.2857142857142855e-01
    w_18_3    full_original_Gini_286  -5.5821428571428573e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_4    OBJ       -1.0954615681569524e-02
    x_18_4    product_lb_80  -4.7052672853174743e-02
    x_18_4    product_ub_81  -1.3705335291252085e-01
    x_18_4    onehot_18_104  1
    x_18_4    stock_lb_226  4
    x_18_4    stock_ub_227  4
    x_18_4    parent_nonstrict_scope_228  3.2863847044708572e-02
    x_18_4    unique_nonzero_owner_321  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_4    product_lb_80  1
    w_18_4    product_ub_81  1
    w_18_4    normalized_mass_18_105  1
    w_18_4    normalized_ratio_18_106  -5.7142857142857140e-01
    w_18_4    full_original_Gini_286  -5.0107142857142852e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_5    OBJ       -2.1909231363139041e-02
    x_18_5    product_lb_82  -4.7052672853174743e-02
    x_18_5    product_ub_83  -1.3705335291252085e-01
    x_18_5    onehot_18_104  1
    x_18_5    stock_lb_226  5
    x_18_5    stock_ub_227  5
    x_18_5    parent_nonstrict_scope_228  2.1909231363139055e-02
    x_18_5    unique_nonzero_owner_322  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_5    product_lb_82  1
    w_18_5    product_ub_83  1
    w_18_5    normalized_mass_18_105  1
    w_18_5    normalized_ratio_18_106  -7.1428571428571419e-01
    w_18_5    full_original_Gini_286  -4.9535714285714283e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_6    OBJ       -3.2863847044708572e-02
    x_18_6    product_lb_84  -4.7052672853174743e-02
    x_18_6    product_ub_85  -1.3705335291252085e-01
    x_18_6    onehot_18_104  1
    x_18_6    stock_lb_226  6
    x_18_6    stock_ub_227  6
    x_18_6    parent_nonstrict_scope_228  1.0954615681569527e-02
    x_18_6    unique_nonzero_owner_323  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_6    product_lb_84  1
    w_18_6    product_ub_85  1
    w_18_6    normalized_mass_18_105  1
    w_18_6    normalized_ratio_18_106  -8.5714285714285710e-01
    w_18_6    full_original_Gini_286  -4.9535714285714283e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_7    OBJ       -4.3818462726278096e-02
    x_18_7    product_lb_86  -4.7052672853174743e-02
    x_18_7    product_ub_87  -1.3705335291252085e-01
    x_18_7    onehot_18_104  1
    x_18_7    stock_lb_226  7
    x_18_7    stock_ub_227  7
    x_18_7    unique_nonzero_owner_324  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_7    product_lb_86  1
    w_18_7    product_ub_87  1
    w_18_7    normalized_mass_18_105  1
    w_18_7    normalized_ratio_18_106  -1
    w_18_7    full_original_Gini_286  -4.9535714285714283e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_8    OBJ       -3.2863847044708579e-02
    x_18_8    product_lb_88  -4.7052672853174743e-02
    x_18_8    product_ub_89  -1.3705335291252085e-01
    x_18_8    onehot_18_104  1
    x_18_8    stock_lb_226  8
    x_18_8    stock_ub_227  8
    x_18_8    parent_nonstrict_scope_228  1.0954615681569519e-02
    x_18_8    unique_nonzero_owner_325  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_8    product_lb_88  1
    w_18_8    product_ub_89  1
    w_18_8    normalized_mass_18_105  1
    w_18_8    normalized_ratio_18_106  -1.1428571428571428e+00
    w_18_8    full_original_Gini_286  -6.4178571428571409e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_9    OBJ       -2.1909231363139058e-02
    x_18_9    product_lb_90  -4.7052672853174743e-02
    x_18_9    product_ub_91  -1.3705335291252085e-01
    x_18_9    onehot_18_104  1
    x_18_9    stock_lb_226  9
    x_18_9    stock_ub_227  9
    x_18_9    parent_nonstrict_scope_228  2.1909231363139037e-02
    x_18_9    unique_nonzero_owner_326  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_9    product_lb_90  1
    w_18_9    product_ub_91  1
    w_18_9    normalized_mass_18_105  1
    w_18_9    normalized_ratio_18_106  -1.2857142857142856e+00
    w_18_9    full_original_Gini_286  -8.1321428571428562e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_10   OBJ       -1.0954615681569538e-02
    x_18_10   product_lb_92  -4.7052672853174743e-02
    x_18_10   product_ub_93  -1.3705335291252085e-01
    x_18_10   onehot_18_104  1
    x_18_10   stock_lb_226  10
    x_18_10   stock_ub_227  10
    x_18_10   parent_nonstrict_scope_228  3.2863847044708558e-02
    x_18_10   unique_nonzero_owner_327  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_10   product_lb_92  1
    w_18_10   product_ub_93  1
    w_18_10   normalized_mass_18_105  1
    w_18_10   normalized_ratio_18_106  -1.4285714285714284e+00
    w_18_10   full_original_Gini_286  -9.8464285714285715e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_11   product_lb_94  -4.7052672853174743e-02
    x_18_11   product_ub_95  -1.3705335291252085e-01
    x_18_11   onehot_18_104  1
    x_18_11   stock_lb_226  11
    x_18_11   stock_ub_227  11
    x_18_11   parent_nonstrict_scope_228  4.3818462726278096e-02
    x_18_11   unique_nonzero_owner_328  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_11   product_lb_94  1
    w_18_11   product_ub_95  1
    w_18_11   normalized_mass_18_105  1
    w_18_11   normalized_ratio_18_106  -1.5714285714285714e+00
    w_18_11   full_original_Gini_286  -1.1560714285714283e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_12   OBJ       1.0954615681569517e-02
    x_18_12   product_lb_96  -4.7052672853174743e-02
    x_18_12   product_ub_97  -1.3705335291252085e-01
    x_18_12   onehot_18_104  1
    x_18_12   stock_lb_226  12
    x_18_12   stock_ub_227  12
    x_18_12   parent_nonstrict_scope_228  5.4773078407847613e-02
    x_18_12   unique_nonzero_owner_329  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_12   product_lb_96  1
    w_18_12   product_ub_97  1
    w_18_12   normalized_mass_18_105  1
    w_18_12   normalized_ratio_18_106  -1.7142857142857142e+00
    w_18_12   full_original_Gini_286  -1.3274999999999997e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_13   OBJ       2.1909231363139034e-02
    x_18_13   product_lb_98  -4.7052672853174743e-02
    x_18_13   product_ub_99  -1.3705335291252085e-01
    x_18_13   onehot_18_104  1
    x_18_13   stock_lb_226  13
    x_18_13   stock_ub_227  13
    x_18_13   parent_nonstrict_scope_228  6.5727694089417130e-02
    x_18_13   unique_nonzero_owner_330  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_13   product_lb_98  1
    w_18_13   product_ub_99  1
    w_18_13   normalized_mass_18_105  1
    w_18_13   normalized_ratio_18_106  -1.8571428571428570e+00
    w_18_13   full_original_Gini_286  -1.4989285714285714e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_14   OBJ       3.2863847044708572e-02
    x_18_14   product_lb_100  -4.7052672853174743e-02
    x_18_14   product_ub_101  -1.3705335291252085e-01
    x_18_14   onehot_18_104  1
    x_18_14   stock_lb_226  14
    x_18_14   stock_ub_227  14
    x_18_14   parent_nonstrict_scope_228  7.6682309770986667e-02
    x_18_14   unique_nonzero_owner_331  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_14   product_lb_100  1
    w_18_14   product_ub_101  1
    w_18_14   normalized_mass_18_105  1
    w_18_14   normalized_ratio_18_106  -2
    w_18_14   full_original_Gini_286  -1.6703571428571429e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_15   OBJ       4.3818462726278096e-02
    x_18_15   product_lb_102  -4.7052672853174743e-02
    x_18_15   product_ub_103  -1.3705335291252085e-01
    x_18_15   onehot_18_104  1
    x_18_15   stock_lb_226  15
    x_18_15   stock_ub_227  15
    x_18_15   parent_nonstrict_scope_228  8.7636925452556191e-02
    x_18_15   unique_nonzero_owner_332  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_15   product_lb_102  1
    w_18_15   product_ub_103  1
    w_18_15   normalized_mass_18_105  1
    w_18_15   normalized_ratio_18_106  -2.1428571428571428e+00
    w_18_15   full_original_Gini_286  -1.8417857142857141e+01
    rho_18    normalized_ratio_18_106  1
    rho_18    block_pair_pos_251  1
    rho_18    block_pair_neg_252  -1
    rho_18    block_pair_pos_265  1
    rho_18    block_pair_neg_266  -1
    rho_18    block_pair_pos_269  -1
    rho_18    block_pair_neg_270  1
    rho_18    block_pair_pos_271  -1
    rho_18    block_pair_neg_272  1
    rho_18    block_pair_pos_273  -1
    rho_18    block_pair_neg_274  1
    rho_18    block_pair_pos_275  -1
    rho_18    block_pair_neg_276  1
    rho_18    block_pair_pos_277  -1
    rho_18    block_pair_neg_278  1
    rho_18    normalization_285  1
    MARKER    'MARKER'                 'INTORG'
    x_13_0    OBJ       6.3380304899829966e-03
    x_13_0    product_lb_107  -4.7052672853174743e-02
    x_13_0    product_ub_108  -1.3705335291252085e-01
    x_13_0    onehot_13_111  1
    x_13_0    parent_nonstrict_scope_228  1.2676060979965993e-02
    MARKER    'MARKER'                 'INTEND'
    w_13_0    product_lb_107  1
    w_13_0    product_ub_108  1
    w_13_0    normalized_mass_13_112  1
    w_13_0    full_original_Gini_286  -7.2964285714285708e+00
    MARKER    'MARKER'                 'INTORG'
    x_13_1    OBJ       -6.3380304899829966e-03
    x_13_1    product_lb_109  -4.7052672853174743e-02
    x_13_1    product_ub_110  -1.3705335291252085e-01
    x_13_1    onehot_13_111  1
    x_13_1    stock_lb_226  1
    x_13_1    stock_ub_227  1
    x_13_1    unique_nonzero_owner_333  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_1    product_lb_109  1
    w_13_1    product_ub_110  1
    w_13_1    normalized_mass_13_112  1
    w_13_1    normalized_ratio_13_113  -1
    w_13_1    full_original_Gini_286  -4.9535714285714283e+00
    rho_13    normalized_ratio_13_113  1
    rho_13    block_pair_pos_235  -1
    rho_13    block_pair_neg_236  1
    rho_13    block_pair_pos_237  -1
    rho_13    block_pair_neg_238  1
    rho_13    block_pair_pos_239  -1
    rho_13    block_pair_neg_240  1
    rho_13    block_pair_pos_241  -1
    rho_13    block_pair_neg_242  1
    rho_13    block_pair_pos_249  1
    rho_13    block_pair_neg_250  -1
    rho_13    block_pair_pos_261  1
    rho_13    block_pair_neg_262  -1
    rho_13    block_pair_pos_275  1
    rho_13    block_pair_neg_276  -1
    rho_13    normalization_285  1
    MARKER    'MARKER'                 'INTORG'
    x_20_0    OBJ       5.0078236648368350e-02
    x_20_0    product_lb_114  -4.7052672853174743e-02
    x_20_0    product_ub_115  -1.3705335291252085e-01
    x_20_0    onehot_20_146  1
    x_20_0    parent_nonstrict_scope_228  1.0015647329673670e-01
    x_20_0    unique_nonzero_owner_334  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_0    product_lb_114  1
    w_20_0    product_ub_115  1
    w_20_0    normalized_mass_20_147  1
    w_20_0    full_original_Gini_286  -7.2964285714285708e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_1    OBJ       3.7558677486276261e-02
    x_20_1    product_lb_116  -4.7052672853174743e-02
    x_20_1    product_ub_117  -1.3705335291252085e-01
    x_20_1    onehot_20_146  1
    x_20_1    stock_lb_226  1
    x_20_1    stock_ub_227  1
    x_20_1    parent_nonstrict_scope_228  8.7636914134644611e-02
    x_20_1    unique_nonzero_owner_335  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_1    product_lb_116  1
    w_20_1    product_ub_117  1
    w_20_1    normalized_mass_20_147  1
    w_20_1    normalized_ratio_20_148  -0.125
    w_20_1    full_original_Gini_286  -6.7964285714285708e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_2    OBJ       2.5039118324184172e-02
    x_20_2    product_lb_118  -4.7052672853174743e-02
    x_20_2    product_ub_119  -1.3705335291252085e-01
    x_20_2    onehot_20_146  1
    x_20_2    stock_lb_226  2
    x_20_2    stock_ub_227  2
    x_20_2    parent_nonstrict_scope_228  7.5117354972552522e-02
    x_20_2    unique_nonzero_owner_336  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_2    product_lb_118  1
    w_20_2    product_ub_119  1
    w_20_2    normalized_mass_20_147  1
    w_20_2    normalized_ratio_20_148  -0.25
    w_20_2    full_original_Gini_286  -6.2964285714285708e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_3    OBJ       1.2519559162092082e-02
    x_20_3    product_lb_120  -4.7052672853174743e-02
    x_20_3    product_ub_121  -1.3705335291252085e-01
    x_20_3    onehot_20_146  1
    x_20_3    stock_lb_226  3
    x_20_3    stock_ub_227  3
    x_20_3    parent_nonstrict_scope_228  6.2597795810460433e-02
    x_20_3    unique_nonzero_owner_337  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_3    product_lb_120  1
    w_20_3    product_ub_121  1
    w_20_3    normalized_mass_20_147  1
    w_20_3    normalized_ratio_20_148  -0.375
    w_20_3    full_original_Gini_286  -5.7964285714285708e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_4    product_lb_122  -4.7052672853174743e-02
    x_20_4    product_ub_123  -1.3705335291252085e-01
    x_20_4    onehot_20_146  1
    x_20_4    stock_lb_226  4
    x_20_4    stock_ub_227  4
    x_20_4    parent_nonstrict_scope_228  5.0078236648368350e-02
    x_20_4    unique_nonzero_owner_338  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_4    product_lb_122  1
    w_20_4    product_ub_123  1
    w_20_4    normalized_mass_20_147  1
    w_20_4    normalized_ratio_20_148  -0.5
    w_20_4    full_original_Gini_286  -5.2964285714285708e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_5    OBJ       -1.2519559162092089e-02
    x_20_5    product_lb_124  -4.7052672853174743e-02
    x_20_5    product_ub_125  -1.3705335291252085e-01
    x_20_5    onehot_20_146  1
    x_20_5    stock_lb_226  5
    x_20_5    stock_ub_227  5
    x_20_5    parent_nonstrict_scope_228  3.7558677486276261e-02
    x_20_5    unique_nonzero_owner_339  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_5    product_lb_124  1
    w_20_5    product_ub_125  1
    w_20_5    normalized_mass_20_147  1
    w_20_5    normalized_ratio_20_148  -0.625
    w_20_5    full_original_Gini_286  -4.9535714285714292e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_6    OBJ       -2.5039118324184175e-02
    x_20_6    product_lb_126  -4.7052672853174743e-02
    x_20_6    product_ub_127  -1.3705335291252085e-01
    x_20_6    onehot_20_146  1
    x_20_6    stock_lb_226  6
    x_20_6    stock_ub_227  6
    x_20_6    parent_nonstrict_scope_228  2.5039118324184175e-02
    x_20_6    unique_nonzero_owner_340  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_6    product_lb_126  1
    w_20_6    product_ub_127  1
    w_20_6    normalized_mass_20_147  1
    w_20_6    normalized_ratio_20_148  -0.75
    w_20_6    full_original_Gini_286  -4.9535714285714292e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_7    OBJ       -3.7558677486276261e-02
    x_20_7    product_lb_128  -4.7052672853174743e-02
    x_20_7    product_ub_129  -1.3705335291252085e-01
    x_20_7    onehot_20_146  1
    x_20_7    stock_lb_226  7
    x_20_7    stock_ub_227  7
    x_20_7    parent_nonstrict_scope_228  1.2519559162092088e-02
    x_20_7    unique_nonzero_owner_341  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_7    product_lb_128  1
    w_20_7    product_ub_129  1
    w_20_7    normalized_mass_20_147  1
    w_20_7    normalized_ratio_20_148  -0.875
    w_20_7    full_original_Gini_286  -4.9535714285714283e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_8    OBJ       -5.0078236648368350e-02
    x_20_8    product_lb_130  -4.7052672853174743e-02
    x_20_8    product_ub_131  -1.3705335291252085e-01
    x_20_8    onehot_20_146  1
    x_20_8    stock_lb_226  8
    x_20_8    stock_ub_227  8
    x_20_8    unique_nonzero_owner_342  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_8    product_lb_130  1
    w_20_8    product_ub_131  1
    w_20_8    normalized_mass_20_147  1
    w_20_8    normalized_ratio_20_148  -1
    w_20_8    full_original_Gini_286  -4.9535714285714283e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_9    OBJ       -3.7558677486276261e-02
    x_20_9    product_lb_132  -4.7052672853174743e-02
    x_20_9    product_ub_133  -1.3705335291252085e-01
    x_20_9    onehot_20_146  1
    x_20_9    stock_lb_226  9
    x_20_9    stock_ub_227  9
    x_20_9    parent_nonstrict_scope_228  1.2519559162092088e-02
    x_20_9    unique_nonzero_owner_343  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_9    product_lb_132  1
    w_20_9    product_ub_133  1
    w_20_9    normalized_mass_20_147  1
    w_20_9    normalized_ratio_20_148  -1.125
    w_20_9    full_original_Gini_286  -6.2035714285714292e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_10   OBJ       -2.5039118324184175e-02
    x_20_10   product_lb_134  -4.7052672853174743e-02
    x_20_10   product_ub_135  -1.3705335291252085e-01
    x_20_10   onehot_20_146  1
    x_20_10   stock_lb_226  10
    x_20_10   stock_ub_227  10
    x_20_10   parent_nonstrict_scope_228  2.5039118324184175e-02
    x_20_10   unique_nonzero_owner_344  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_10   product_lb_134  1
    w_20_10   product_ub_135  1
    w_20_10   normalized_mass_20_147  1
    w_20_10   normalized_ratio_20_148  -1.25
    w_20_10   full_original_Gini_286  -7.7035714285714292e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_11   OBJ       -1.2519559162092089e-02
    x_20_11   product_lb_136  -4.7052672853174743e-02
    x_20_11   product_ub_137  -1.3705335291252085e-01
    x_20_11   onehot_20_146  1
    x_20_11   stock_lb_226  11
    x_20_11   stock_ub_227  11
    x_20_11   parent_nonstrict_scope_228  3.7558677486276261e-02
    x_20_11   unique_nonzero_owner_345  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_11   product_lb_136  1
    w_20_11   product_ub_137  1
    w_20_11   normalized_mass_20_147  1
    w_20_11   normalized_ratio_20_148  -1.375
    w_20_11   full_original_Gini_286  -9.20357142857143
    MARKER    'MARKER'                 'INTORG'
    x_20_12   product_lb_138  -4.7052672853174743e-02
    x_20_12   product_ub_139  -1.3705335291252085e-01
    x_20_12   onehot_20_146  1
    x_20_12   stock_lb_226  12
    x_20_12   stock_ub_227  12
    x_20_12   parent_nonstrict_scope_228  5.0078236648368350e-02
    MARKER    'MARKER'                 'INTEND'
    w_20_12   product_lb_138  1
    w_20_12   product_ub_139  1
    w_20_12   normalized_mass_20_147  1
    w_20_12   normalized_ratio_20_148  -1.5
    w_20_12   full_original_Gini_286  -1.0703571428571429e+01
    MARKER    'MARKER'                 'INTORG'
    x_20_13   OBJ       1.2519559162092082e-02
    x_20_13   product_lb_140  -4.7052672853174743e-02
    x_20_13   product_ub_141  -1.3705335291252085e-01
    x_20_13   onehot_20_146  1
    x_20_13   stock_lb_226  13
    x_20_13   stock_ub_227  13
    x_20_13   parent_nonstrict_scope_228  6.2597795810460433e-02
    x_20_13   unique_nonzero_owner_346  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_13   product_lb_140  1
    w_20_13   product_ub_141  1
    w_20_13   normalized_mass_20_147  1
    w_20_13   normalized_ratio_20_148  -1.625
    w_20_13   full_original_Gini_286  -1.2203571428571429e+01
    MARKER    'MARKER'                 'INTORG'
    x_20_14   OBJ       2.5039118324184172e-02
    x_20_14   product_lb_142  -4.7052672853174743e-02
    x_20_14   product_ub_143  -1.3705335291252085e-01
    x_20_14   onehot_20_146  1
    x_20_14   stock_lb_226  14
    x_20_14   stock_ub_227  14
    x_20_14   parent_nonstrict_scope_228  7.5117354972552522e-02
    x_20_14   unique_nonzero_owner_347  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_14   product_lb_142  1
    w_20_14   product_ub_143  1
    w_20_14   normalized_mass_20_147  1
    w_20_14   normalized_ratio_20_148  -1.75
    w_20_14   full_original_Gini_286  -1.3703571428571429e+01
    MARKER    'MARKER'                 'INTORG'
    x_20_15   OBJ       3.7558677486276261e-02
    x_20_15   product_lb_144  -4.7052672853174743e-02
    x_20_15   product_ub_145  -1.3705335291252085e-01
    x_20_15   onehot_20_146  1
    x_20_15   stock_lb_226  15
    x_20_15   stock_ub_227  15
    x_20_15   parent_nonstrict_scope_228  8.7636914134644611e-02
    x_20_15   unique_nonzero_owner_348  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_15   product_lb_144  1
    w_20_15   product_ub_145  1
    w_20_15   normalized_mass_20_147  1
    w_20_15   normalized_ratio_20_148  -1.875
    w_20_15   full_original_Gini_286  -1.5203571428571429e+01
    rho_20    normalized_ratio_20_148  1
    rho_20    block_pair_pos_241  1
    rho_20    block_pair_neg_242  -1
    rho_20    block_pair_pos_253  1
    rho_20    block_pair_neg_254  -1
    rho_20    block_pair_pos_267  1
    rho_20    block_pair_neg_268  -1
    rho_20    block_pair_pos_277  1
    rho_20    block_pair_neg_278  -1
    rho_20    block_pair_pos_279  -1
    rho_20    block_pair_neg_280  1
    rho_20    block_pair_pos_281  -1
    rho_20    block_pair_neg_282  1
    rho_20    block_pair_pos_283  -1
    rho_20    block_pair_neg_284  1
    rho_20    normalization_285  1
    MARKER    'MARKER'                 'INTORG'
    x_12_0    OBJ       3.2863847044708572e-02
    x_12_0    product_lb_149  -4.7052672853174743e-02
    x_12_0    product_ub_150  -1.3705335291252085e-01
    x_12_0    onehot_12_181  1
    x_12_0    parent_nonstrict_scope_228  7.6682309770986667e-02
    x_12_0    unique_nonzero_owner_349  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_0    product_lb_149  1
    w_12_0    product_ub_150  1
    w_12_0    normalized_mass_12_182  1
    w_12_0    full_original_Gini_286  -7.2964285714285708e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_1    OBJ       2.1909231363139048e-02
    x_12_1    product_lb_151  -4.7052672853174743e-02
    x_12_1    product_ub_152  -1.3705335291252085e-01
    x_12_1    onehot_12_181  1
    x_12_1    stock_lb_226  1
    x_12_1    stock_ub_227  1
    x_12_1    parent_nonstrict_scope_228  6.5727694089417144e-02
    x_12_1    unique_nonzero_owner_350  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_1    product_lb_151  1
    w_12_1    product_ub_152  1
    w_12_1    normalized_mass_12_182  1
    w_12_1    normalized_ratio_12_183  -1.4285714285714285e-01
    w_12_1    full_original_Gini_286  -6.7250000000000005e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_2    OBJ       1.0954615681569524e-02
    x_12_2    product_lb_153  -4.7052672853174743e-02
    x_12_2    product_ub_154  -1.3705335291252085e-01
    x_12_2    onehot_12_181  1
    x_12_2    stock_lb_226  2
    x_12_2    stock_ub_227  2
    x_12_2    parent_nonstrict_scope_228  5.4773078407847620e-02
    x_12_2    unique_nonzero_owner_351  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_2    product_lb_153  1
    w_12_2    product_ub_154  1
    w_12_2    normalized_mass_12_182  1
    w_12_2    normalized_ratio_12_183  -2.8571428571428570e-01
    w_12_2    full_original_Gini_286  -6.1535714285714294e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_3    product_lb_155  -4.7052672853174743e-02
    x_12_3    product_ub_156  -1.3705335291252085e-01
    x_12_3    onehot_12_181  1
    x_12_3    stock_lb_226  3
    x_12_3    stock_ub_227  3
    x_12_3    parent_nonstrict_scope_228  4.3818462726278096e-02
    x_12_3    unique_nonzero_owner_352  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_3    product_lb_155  1
    w_12_3    product_ub_156  1
    w_12_3    normalized_mass_12_182  1
    w_12_3    normalized_ratio_12_183  -4.2857142857142855e-01
    w_12_3    full_original_Gini_286  -5.5821428571428573e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_4    OBJ       -1.0954615681569524e-02
    x_12_4    product_lb_157  -4.7052672853174743e-02
    x_12_4    product_ub_158  -1.3705335291252085e-01
    x_12_4    onehot_12_181  1
    x_12_4    stock_lb_226  4
    x_12_4    stock_ub_227  4
    x_12_4    parent_nonstrict_scope_228  3.2863847044708572e-02
    x_12_4    unique_nonzero_owner_353  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_4    product_lb_157  1
    w_12_4    product_ub_158  1
    w_12_4    normalized_mass_12_182  1
    w_12_4    normalized_ratio_12_183  -5.7142857142857140e-01
    w_12_4    full_original_Gini_286  -5.0107142857142852e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_5    OBJ       -2.1909231363139041e-02
    x_12_5    product_lb_159  -4.7052672853174743e-02
    x_12_5    product_ub_160  -1.3705335291252085e-01
    x_12_5    onehot_12_181  1
    x_12_5    stock_lb_226  5
    x_12_5    stock_ub_227  5
    x_12_5    parent_nonstrict_scope_228  2.1909231363139055e-02
    x_12_5    unique_nonzero_owner_354  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_5    product_lb_159  1
    w_12_5    product_ub_160  1
    w_12_5    normalized_mass_12_182  1
    w_12_5    normalized_ratio_12_183  -7.1428571428571419e-01
    w_12_5    full_original_Gini_286  -4.9535714285714283e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_6    OBJ       -3.2863847044708572e-02
    x_12_6    product_lb_161  -4.7052672853174743e-02
    x_12_6    product_ub_162  -1.3705335291252085e-01
    x_12_6    onehot_12_181  1
    x_12_6    stock_lb_226  6
    x_12_6    stock_ub_227  6
    x_12_6    parent_nonstrict_scope_228  1.0954615681569527e-02
    x_12_6    unique_nonzero_owner_355  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_6    product_lb_161  1
    w_12_6    product_ub_162  1
    w_12_6    normalized_mass_12_182  1
    w_12_6    normalized_ratio_12_183  -8.5714285714285710e-01
    w_12_6    full_original_Gini_286  -4.9535714285714283e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_7    OBJ       -4.3818462726278096e-02
    x_12_7    product_lb_163  -4.7052672853174743e-02
    x_12_7    product_ub_164  -1.3705335291252085e-01
    x_12_7    onehot_12_181  1
    x_12_7    stock_lb_226  7
    x_12_7    stock_ub_227  7
    x_12_7    unique_nonzero_owner_356  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_7    product_lb_163  1
    w_12_7    product_ub_164  1
    w_12_7    normalized_mass_12_182  1
    w_12_7    normalized_ratio_12_183  -1
    w_12_7    full_original_Gini_286  -4.9535714285714283e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_8    OBJ       -3.2863847044708579e-02
    x_12_8    product_lb_165  -4.7052672853174743e-02
    x_12_8    product_ub_166  -1.3705335291252085e-01
    x_12_8    onehot_12_181  1
    x_12_8    stock_lb_226  8
    x_12_8    stock_ub_227  8
    x_12_8    parent_nonstrict_scope_228  1.0954615681569519e-02
    x_12_8    unique_nonzero_owner_357  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_8    product_lb_165  1
    w_12_8    product_ub_166  1
    w_12_8    normalized_mass_12_182  1
    w_12_8    normalized_ratio_12_183  -1.1428571428571428e+00
    w_12_8    full_original_Gini_286  -6.4178571428571409e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_9    OBJ       -2.1909231363139058e-02
    x_12_9    product_lb_167  -4.7052672853174743e-02
    x_12_9    product_ub_168  -1.3705335291252085e-01
    x_12_9    onehot_12_181  1
    x_12_9    stock_lb_226  9
    x_12_9    stock_ub_227  9
    x_12_9    parent_nonstrict_scope_228  2.1909231363139037e-02
    x_12_9    unique_nonzero_owner_358  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_9    product_lb_167  1
    w_12_9    product_ub_168  1
    w_12_9    normalized_mass_12_182  1
    w_12_9    normalized_ratio_12_183  -1.2857142857142856e+00
    w_12_9    full_original_Gini_286  -8.1321428571428562e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_10   OBJ       -1.0954615681569538e-02
    x_12_10   product_lb_169  -4.7052672853174743e-02
    x_12_10   product_ub_170  -1.3705335291252085e-01
    x_12_10   onehot_12_181  1
    x_12_10   stock_lb_226  10
    x_12_10   stock_ub_227  10
    x_12_10   parent_nonstrict_scope_228  3.2863847044708558e-02
    x_12_10   unique_nonzero_owner_359  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_10   product_lb_169  1
    w_12_10   product_ub_170  1
    w_12_10   normalized_mass_12_182  1
    w_12_10   normalized_ratio_12_183  -1.4285714285714284e+00
    w_12_10   full_original_Gini_286  -9.8464285714285715e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_11   product_lb_171  -4.7052672853174743e-02
    x_12_11   product_ub_172  -1.3705335291252085e-01
    x_12_11   onehot_12_181  1
    x_12_11   stock_lb_226  11
    x_12_11   stock_ub_227  11
    x_12_11   parent_nonstrict_scope_228  4.3818462726278096e-02
    MARKER    'MARKER'                 'INTEND'
    w_12_11   product_lb_171  1
    w_12_11   product_ub_172  1
    w_12_11   normalized_mass_12_182  1
    w_12_11   normalized_ratio_12_183  -1.5714285714285714e+00
    w_12_11   full_original_Gini_286  -1.1560714285714283e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_12   OBJ       1.0954615681569517e-02
    x_12_12   product_lb_173  -4.7052672853174743e-02
    x_12_12   product_ub_174  -1.3705335291252085e-01
    x_12_12   onehot_12_181  1
    x_12_12   stock_lb_226  12
    x_12_12   stock_ub_227  12
    x_12_12   parent_nonstrict_scope_228  5.4773078407847613e-02
    x_12_12   unique_nonzero_owner_360  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_12   product_lb_173  1
    w_12_12   product_ub_174  1
    w_12_12   normalized_mass_12_182  1
    w_12_12   normalized_ratio_12_183  -1.7142857142857142e+00
    w_12_12   full_original_Gini_286  -1.3274999999999997e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_13   OBJ       2.1909231363139034e-02
    x_12_13   product_lb_175  -4.7052672853174743e-02
    x_12_13   product_ub_176  -1.3705335291252085e-01
    x_12_13   onehot_12_181  1
    x_12_13   stock_lb_226  13
    x_12_13   stock_ub_227  13
    x_12_13   parent_nonstrict_scope_228  6.5727694089417130e-02
    x_12_13   unique_nonzero_owner_361  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_13   product_lb_175  1
    w_12_13   product_ub_176  1
    w_12_13   normalized_mass_12_182  1
    w_12_13   normalized_ratio_12_183  -1.8571428571428570e+00
    w_12_13   full_original_Gini_286  -1.4989285714285714e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_14   OBJ       3.2863847044708572e-02
    x_12_14   product_lb_177  -4.7052672853174743e-02
    x_12_14   product_ub_178  -1.3705335291252085e-01
    x_12_14   onehot_12_181  1
    x_12_14   stock_lb_226  14
    x_12_14   stock_ub_227  14
    x_12_14   parent_nonstrict_scope_228  7.6682309770986667e-02
    x_12_14   unique_nonzero_owner_362  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_14   product_lb_177  1
    w_12_14   product_ub_178  1
    w_12_14   normalized_mass_12_182  1
    w_12_14   normalized_ratio_12_183  -2
    w_12_14   full_original_Gini_286  -1.6703571428571429e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_15   OBJ       4.3818462726278096e-02
    x_12_15   product_lb_179  -4.7052672853174743e-02
    x_12_15   product_ub_180  -1.3705335291252085e-01
    x_12_15   onehot_12_181  1
    x_12_15   stock_lb_226  15
    x_12_15   stock_ub_227  15
    x_12_15   parent_nonstrict_scope_228  8.7636925452556191e-02
    x_12_15   unique_nonzero_owner_363  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_15   product_lb_179  1
    w_12_15   product_ub_180  1
    w_12_15   normalized_mass_12_182  1
    w_12_15   normalized_ratio_12_183  -2.1428571428571428e+00
    w_12_15   full_original_Gini_286  -1.8417857142857141e+01
    rho_12    normalized_ratio_12_183  1
    rho_12    block_pair_pos_231  -1
    rho_12    block_pair_neg_232  1
    rho_12    block_pair_pos_233  -1
    rho_12    block_pair_neg_234  1
    rho_12    block_pair_pos_239  1
    rho_12    block_pair_neg_240  -1
    rho_12    block_pair_pos_247  1
    rho_12    block_pair_neg_248  -1
    rho_12    block_pair_pos_259  1
    rho_12    block_pair_neg_260  -1
    rho_12    block_pair_pos_273  1
    rho_12    block_pair_neg_274  -1
    rho_12    block_pair_pos_283  1
    rho_12    block_pair_neg_284  -1
    rho_12    normalization_285  1
    MARKER    'MARKER'                 'INTORG'
    x_11_0    OBJ       5.0078236648368350e-02
    x_11_0    product_lb_184  -4.7052672853174743e-02
    x_11_0    product_ub_185  -1.3705335291252085e-01
    x_11_0    onehot_11_216  1
    x_11_0    parent_nonstrict_scope_228  1.0015647329673670e-01
    x_11_0    unique_nonzero_owner_364  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_0    product_lb_184  1
    w_11_0    product_ub_185  1
    w_11_0    normalized_mass_11_217  1
    w_11_0    full_original_Gini_286  -7.2964285714285708e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_1    OBJ       3.7558677486276261e-02
    x_11_1    product_lb_186  -4.7052672853174743e-02
    x_11_1    product_ub_187  -1.3705335291252085e-01
    x_11_1    onehot_11_216  1
    x_11_1    stock_lb_226  1
    x_11_1    stock_ub_227  1
    x_11_1    parent_nonstrict_scope_228  8.7636914134644611e-02
    MARKER    'MARKER'                 'INTEND'
    w_11_1    product_lb_186  1
    w_11_1    product_ub_187  1
    w_11_1    normalized_mass_11_217  1
    w_11_1    normalized_ratio_11_218  -0.125
    w_11_1    full_original_Gini_286  -6.7964285714285708e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_2    OBJ       2.5039118324184172e-02
    x_11_2    product_lb_188  -4.7052672853174743e-02
    x_11_2    product_ub_189  -1.3705335291252085e-01
    x_11_2    onehot_11_216  1
    x_11_2    stock_lb_226  2
    x_11_2    stock_ub_227  2
    x_11_2    parent_nonstrict_scope_228  7.5117354972552522e-02
    x_11_2    unique_nonzero_owner_365  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_2    product_lb_188  1
    w_11_2    product_ub_189  1
    w_11_2    normalized_mass_11_217  1
    w_11_2    normalized_ratio_11_218  -0.25
    w_11_2    full_original_Gini_286  -6.2964285714285708e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_3    OBJ       1.2519559162092082e-02
    x_11_3    product_lb_190  -4.7052672853174743e-02
    x_11_3    product_ub_191  -1.3705335291252085e-01
    x_11_3    onehot_11_216  1
    x_11_3    stock_lb_226  3
    x_11_3    stock_ub_227  3
    x_11_3    parent_nonstrict_scope_228  6.2597795810460433e-02
    x_11_3    unique_nonzero_owner_366  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_3    product_lb_190  1
    w_11_3    product_ub_191  1
    w_11_3    normalized_mass_11_217  1
    w_11_3    normalized_ratio_11_218  -0.375
    w_11_3    full_original_Gini_286  -5.7964285714285708e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_4    product_lb_192  -4.7052672853174743e-02
    x_11_4    product_ub_193  -1.3705335291252085e-01
    x_11_4    onehot_11_216  1
    x_11_4    stock_lb_226  4
    x_11_4    stock_ub_227  4
    x_11_4    parent_nonstrict_scope_228  5.0078236648368350e-02
    x_11_4    unique_nonzero_owner_367  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_4    product_lb_192  1
    w_11_4    product_ub_193  1
    w_11_4    normalized_mass_11_217  1
    w_11_4    normalized_ratio_11_218  -0.5
    w_11_4    full_original_Gini_286  -5.2964285714285708e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_5    OBJ       -1.2519559162092089e-02
    x_11_5    product_lb_194  -4.7052672853174743e-02
    x_11_5    product_ub_195  -1.3705335291252085e-01
    x_11_5    onehot_11_216  1
    x_11_5    stock_lb_226  5
    x_11_5    stock_ub_227  5
    x_11_5    parent_nonstrict_scope_228  3.7558677486276261e-02
    x_11_5    unique_nonzero_owner_368  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_5    product_lb_194  1
    w_11_5    product_ub_195  1
    w_11_5    normalized_mass_11_217  1
    w_11_5    normalized_ratio_11_218  -0.625
    w_11_5    full_original_Gini_286  -4.9535714285714292e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_6    OBJ       -2.5039118324184175e-02
    x_11_6    product_lb_196  -4.7052672853174743e-02
    x_11_6    product_ub_197  -1.3705335291252085e-01
    x_11_6    onehot_11_216  1
    x_11_6    stock_lb_226  6
    x_11_6    stock_ub_227  6
    x_11_6    parent_nonstrict_scope_228  2.5039118324184175e-02
    x_11_6    unique_nonzero_owner_369  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_6    product_lb_196  1
    w_11_6    product_ub_197  1
    w_11_6    normalized_mass_11_217  1
    w_11_6    normalized_ratio_11_218  -0.75
    w_11_6    full_original_Gini_286  -4.9535714285714292e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_7    OBJ       -3.7558677486276261e-02
    x_11_7    product_lb_198  -4.7052672853174743e-02
    x_11_7    product_ub_199  -1.3705335291252085e-01
    x_11_7    onehot_11_216  1
    x_11_7    stock_lb_226  7
    x_11_7    stock_ub_227  7
    x_11_7    parent_nonstrict_scope_228  1.2519559162092088e-02
    x_11_7    unique_nonzero_owner_370  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_7    product_lb_198  1
    w_11_7    product_ub_199  1
    w_11_7    normalized_mass_11_217  1
    w_11_7    normalized_ratio_11_218  -0.875
    w_11_7    full_original_Gini_286  -4.9535714285714283e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_8    OBJ       -5.0078236648368350e-02
    x_11_8    product_lb_200  -4.7052672853174743e-02
    x_11_8    product_ub_201  -1.3705335291252085e-01
    x_11_8    onehot_11_216  1
    x_11_8    stock_lb_226  8
    x_11_8    stock_ub_227  8
    x_11_8    unique_nonzero_owner_371  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_8    product_lb_200  1
    w_11_8    product_ub_201  1
    w_11_8    normalized_mass_11_217  1
    w_11_8    normalized_ratio_11_218  -1
    w_11_8    full_original_Gini_286  -4.9535714285714283e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_9    OBJ       -3.7558677486276261e-02
    x_11_9    product_lb_202  -4.7052672853174743e-02
    x_11_9    product_ub_203  -1.3705335291252085e-01
    x_11_9    onehot_11_216  1
    x_11_9    stock_lb_226  9
    x_11_9    stock_ub_227  9
    x_11_9    parent_nonstrict_scope_228  1.2519559162092088e-02
    x_11_9    unique_nonzero_owner_372  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_9    product_lb_202  1
    w_11_9    product_ub_203  1
    w_11_9    normalized_mass_11_217  1
    w_11_9    normalized_ratio_11_218  -1.125
    w_11_9    full_original_Gini_286  -6.2035714285714292e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_10   OBJ       -2.5039118324184175e-02
    x_11_10   product_lb_204  -4.7052672853174743e-02
    x_11_10   product_ub_205  -1.3705335291252085e-01
    x_11_10   onehot_11_216  1
    x_11_10   stock_lb_226  10
    x_11_10   stock_ub_227  10
    x_11_10   parent_nonstrict_scope_228  2.5039118324184175e-02
    x_11_10   unique_nonzero_owner_373  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_10   product_lb_204  1
    w_11_10   product_ub_205  1
    w_11_10   normalized_mass_11_217  1
    w_11_10   normalized_ratio_11_218  -1.25
    w_11_10   full_original_Gini_286  -7.7035714285714292e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_11   OBJ       -1.2519559162092089e-02
    x_11_11   product_lb_206  -4.7052672853174743e-02
    x_11_11   product_ub_207  -1.3705335291252085e-01
    x_11_11   onehot_11_216  1
    x_11_11   stock_lb_226  11
    x_11_11   stock_ub_227  11
    x_11_11   parent_nonstrict_scope_228  3.7558677486276261e-02
    x_11_11   unique_nonzero_owner_374  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_11   product_lb_206  1
    w_11_11   product_ub_207  1
    w_11_11   normalized_mass_11_217  1
    w_11_11   normalized_ratio_11_218  -1.375
    w_11_11   full_original_Gini_286  -9.20357142857143
    MARKER    'MARKER'                 'INTORG'
    x_11_12   product_lb_208  -4.7052672853174743e-02
    x_11_12   product_ub_209  -1.3705335291252085e-01
    x_11_12   onehot_11_216  1
    x_11_12   stock_lb_226  12
    x_11_12   stock_ub_227  12
    x_11_12   parent_nonstrict_scope_228  5.0078236648368350e-02
    x_11_12   unique_nonzero_owner_375  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_12   product_lb_208  1
    w_11_12   product_ub_209  1
    w_11_12   normalized_mass_11_217  1
    w_11_12   normalized_ratio_11_218  -1.5
    w_11_12   full_original_Gini_286  -1.0703571428571429e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_13   OBJ       1.2519559162092082e-02
    x_11_13   product_lb_210  -4.7052672853174743e-02
    x_11_13   product_ub_211  -1.3705335291252085e-01
    x_11_13   onehot_11_216  1
    x_11_13   stock_lb_226  13
    x_11_13   stock_ub_227  13
    x_11_13   parent_nonstrict_scope_228  6.2597795810460433e-02
    x_11_13   unique_nonzero_owner_376  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_13   product_lb_210  1
    w_11_13   product_ub_211  1
    w_11_13   normalized_mass_11_217  1
    w_11_13   normalized_ratio_11_218  -1.625
    w_11_13   full_original_Gini_286  -1.2203571428571429e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_14   OBJ       2.5039118324184172e-02
    x_11_14   product_lb_212  -4.7052672853174743e-02
    x_11_14   product_ub_213  -1.3705335291252085e-01
    x_11_14   onehot_11_216  1
    x_11_14   stock_lb_226  14
    x_11_14   stock_ub_227  14
    x_11_14   parent_nonstrict_scope_228  7.5117354972552522e-02
    x_11_14   unique_nonzero_owner_377  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_14   product_lb_212  1
    w_11_14   product_ub_213  1
    w_11_14   normalized_mass_11_217  1
    w_11_14   normalized_ratio_11_218  -1.75
    w_11_14   full_original_Gini_286  -1.3703571428571429e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_15   OBJ       3.7558677486276261e-02
    x_11_15   product_lb_214  -4.7052672853174743e-02
    x_11_15   product_ub_215  -1.3705335291252085e-01
    x_11_15   onehot_11_216  1
    x_11_15   stock_lb_226  15
    x_11_15   stock_ub_227  15
    x_11_15   parent_nonstrict_scope_228  8.7636914134644611e-02
    x_11_15   unique_nonzero_owner_378  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_15   product_lb_214  1
    w_11_15   product_ub_215  1
    w_11_15   normalized_mass_11_217  1
    w_11_15   normalized_ratio_11_218  -1.875
    w_11_15   full_original_Gini_286  -1.5203571428571429e+01
    rho_11    normalized_ratio_11_218  1
    rho_11    block_pair_pos_229  -1
    rho_11    block_pair_neg_230  1
    rho_11    block_pair_pos_233  1
    rho_11    block_pair_neg_234  -1
    rho_11    block_pair_pos_237  1
    rho_11    block_pair_neg_238  -1
    rho_11    block_pair_pos_245  1
    rho_11    block_pair_neg_246  -1
    rho_11    block_pair_pos_257  1
    rho_11    block_pair_neg_258  -1
    rho_11    block_pair_pos_271  1
    rho_11    block_pair_neg_272  -1
    rho_11    block_pair_pos_281  1
    rho_11    block_pair_neg_282  -1
    rho_11    normalization_285  1
    MARKER    'MARKER'                 'INTORG'
    x_10_0    OBJ       6.3380304899829966e-03
    x_10_0    product_lb_219  -4.7052672853174743e-02
    x_10_0    product_ub_220  -1.3705335291252085e-01
    x_10_0    onehot_10_223  1
    x_10_0    parent_nonstrict_scope_228  1.2676060979965993e-02
    MARKER    'MARKER'                 'INTEND'
    w_10_0    product_lb_219  1
    w_10_0    product_ub_220  1
    w_10_0    normalized_mass_10_224  1
    w_10_0    full_original_Gini_286  -7.2964285714285708e+00
    MARKER    'MARKER'                 'INTORG'
    x_10_1    OBJ       -6.3380304899829966e-03
    x_10_1    product_lb_221  -4.7052672853174743e-02
    x_10_1    product_ub_222  -1.3705335291252085e-01
    x_10_1    onehot_10_223  1
    x_10_1    stock_lb_226  1
    x_10_1    stock_ub_227  1
    x_10_1    unique_nonzero_owner_379  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_1    product_lb_221  1
    w_10_1    product_ub_222  1
    w_10_1    normalized_mass_10_224  1
    w_10_1    normalized_ratio_10_225  -1
    w_10_1    full_original_Gini_286  -4.9535714285714283e+00
    rho_10    normalized_ratio_10_225  1
    rho_10    block_pair_pos_229  1
    rho_10    block_pair_neg_230  -1
    rho_10    block_pair_pos_231  1
    rho_10    block_pair_neg_232  -1
    rho_10    block_pair_pos_235  1
    rho_10    block_pair_neg_236  -1
    rho_10    block_pair_pos_243  1
    rho_10    block_pair_neg_244  -1
    rho_10    block_pair_pos_255  1
    rho_10    block_pair_neg_256  -1
    rho_10    block_pair_pos_269  1
    rho_10    block_pair_neg_270  -1
    rho_10    block_pair_pos_279  1
    rho_10    block_pair_neg_280  -1
    rho_10    normalization_285  1
    a_17_14   block_pair_pos_263  1
    a_17_14   block_pair_neg_264  1
    a_17_14   full_original_Gini_286  -1
    a_17_18   block_pair_pos_265  1
    a_17_18   block_pair_neg_266  1
    a_17_18   full_original_Gini_286  -1
    a_17_13   block_pair_pos_261  1
    a_17_13   block_pair_neg_262  1
    a_17_13   full_original_Gini_286  -1
    a_17_20   block_pair_pos_267  1
    a_17_20   block_pair_neg_268  1
    a_17_20   full_original_Gini_286  -1
    a_17_12   block_pair_pos_259  1
    a_17_12   block_pair_neg_260  1
    a_17_12   full_original_Gini_286  -1
    a_17_11   block_pair_pos_257  1
    a_17_11   block_pair_neg_258  1
    a_17_11   full_original_Gini_286  -1
    a_17_10   block_pair_pos_255  1
    a_17_10   block_pair_neg_256  1
    a_17_10   full_original_Gini_286  -1
    a_14_18   block_pair_pos_251  1
    a_14_18   block_pair_neg_252  1
    a_14_18   full_original_Gini_286  -1
    a_14_13   block_pair_pos_249  1
    a_14_13   block_pair_neg_250  1
    a_14_13   full_original_Gini_286  -1
    a_14_20   block_pair_pos_253  1
    a_14_20   block_pair_neg_254  1
    a_14_20   full_original_Gini_286  -1
    a_14_12   block_pair_pos_247  1
    a_14_12   block_pair_neg_248  1
    a_14_12   full_original_Gini_286  -1
    a_14_11   block_pair_pos_245  1
    a_14_11   block_pair_neg_246  1
    a_14_11   full_original_Gini_286  -1
    a_14_10   block_pair_pos_243  1
    a_14_10   block_pair_neg_244  1
    a_14_10   full_original_Gini_286  -1
    a_18_13   block_pair_pos_275  1
    a_18_13   block_pair_neg_276  1
    a_18_13   full_original_Gini_286  -1
    a_18_20   block_pair_pos_277  1
    a_18_20   block_pair_neg_278  1
    a_18_20   full_original_Gini_286  -1
    a_18_12   block_pair_pos_273  1
    a_18_12   block_pair_neg_274  1
    a_18_12   full_original_Gini_286  -1
    a_18_11   block_pair_pos_271  1
    a_18_11   block_pair_neg_272  1
    a_18_11   full_original_Gini_286  -1
    a_18_10   block_pair_pos_269  1
    a_18_10   block_pair_neg_270  1
    a_18_10   full_original_Gini_286  -1
    a_13_20   block_pair_pos_241  1
    a_13_20   block_pair_neg_242  1
    a_13_20   full_original_Gini_286  -1
    a_13_12   block_pair_pos_239  1
    a_13_12   block_pair_neg_240  1
    a_13_12   full_original_Gini_286  -1
    a_13_11   block_pair_pos_237  1
    a_13_11   block_pair_neg_238  1
    a_13_11   full_original_Gini_286  -1
    a_13_10   block_pair_pos_235  1
    a_13_10   block_pair_neg_236  1
    a_13_10   full_original_Gini_286  -1
    a_20_12   block_pair_pos_283  1
    a_20_12   block_pair_neg_284  1
    a_20_12   full_original_Gini_286  -1
    a_20_11   block_pair_pos_281  1
    a_20_11   block_pair_neg_282  1
    a_20_11   full_original_Gini_286  -1
    a_20_10   block_pair_pos_279  1
    a_20_10   block_pair_neg_280  1
    a_20_10   full_original_Gini_286  -1
    a_12_11   block_pair_pos_233  1
    a_12_11   block_pair_neg_234  1
    a_12_11   full_original_Gini_286  -1
    a_12_10   block_pair_pos_231  1
    a_12_10   block_pair_neg_232  1
    a_12_10   full_original_Gini_286  -1
    a_11_10   block_pair_pos_229  1
    a_11_10   block_pair_neg_230  1
    a_11_10   full_original_Gini_286  -1
    MARKER    'MARKER'                 'INTORG'
    service_0_17_0  unique_nonzero_owner_287  1
    service_0_17_0  service_visit_def_821  1
    service_0_17_0  free_load_conservation_822  -3
    service_0_17_0  original_T_including_depot_unload_870  360
    service_0_17_1  unique_nonzero_owner_288  1
    service_0_17_1  service_visit_def_821  1
    service_0_17_1  free_load_conservation_822  -2
    service_0_17_1  original_T_including_depot_unload_870  240
    service_0_17_2  unique_nonzero_owner_289  1
    service_0_17_2  service_visit_def_821  1
    service_0_17_2  free_load_conservation_822  -1
    service_0_17_2  original_T_including_depot_unload_870  120
    service_0_17_4  unique_nonzero_owner_290  1
    service_0_17_4  service_visit_def_821  1
    service_0_17_4  free_load_conservation_822  1
    service_0_17_5  unique_nonzero_owner_291  1
    service_0_17_5  service_visit_def_821  1
    service_0_17_5  free_load_conservation_822  2
    service_0_17_6  unique_nonzero_owner_292  1
    service_0_17_6  service_visit_def_821  1
    service_0_17_6  free_load_conservation_822  3
    service_0_17_7  unique_nonzero_owner_293  1
    service_0_17_7  service_visit_def_821  1
    service_0_17_7  free_load_conservation_822  4
    service_0_17_8  unique_nonzero_owner_294  1
    service_0_17_8  service_visit_def_821  1
    service_0_17_8  free_load_conservation_822  5
    service_0_17_9  unique_nonzero_owner_295  1
    service_0_17_9  service_visit_def_821  1
    service_0_17_9  free_load_conservation_822  6
    service_0_17_10  unique_nonzero_owner_296  1
    service_0_17_10  service_visit_def_821  1
    service_0_17_10  free_load_conservation_822  7
    service_0_17_11  unique_nonzero_owner_297  1
    service_0_17_11  service_visit_def_821  1
    service_0_17_11  free_load_conservation_822  8
    service_0_17_12  unique_nonzero_owner_298  1
    service_0_17_12  service_visit_def_821  1
    service_0_17_12  free_load_conservation_822  9
    service_0_17_13  unique_nonzero_owner_299  1
    service_0_17_13  service_visit_def_821  1
    service_0_17_13  free_load_conservation_822  10
    service_0_17_14  unique_nonzero_owner_300  1
    service_0_17_14  service_visit_def_821  1
    service_0_17_14  free_load_conservation_822  11
    service_0_17_15  unique_nonzero_owner_301  1
    service_0_17_15  service_visit_def_821  1
    service_0_17_15  free_load_conservation_822  12
    service_0_17_16  unique_nonzero_owner_302  1
    service_0_17_16  service_visit_def_821  1
    service_0_17_16  free_load_conservation_822  13
    service_1_17_0  unique_nonzero_owner_287  1
    service_1_17_0  service_visit_def_1047  1
    service_1_17_0  free_load_conservation_1048  -3
    service_1_17_0  original_T_including_depot_unload_1091  360
    service_1_17_1  unique_nonzero_owner_288  1
    service_1_17_1  service_visit_def_1047  1
    service_1_17_1  free_load_conservation_1048  -2
    service_1_17_1  original_T_including_depot_unload_1091  240
    service_1_17_2  unique_nonzero_owner_289  1
    service_1_17_2  service_visit_def_1047  1
    service_1_17_2  free_load_conservation_1048  -1
    service_1_17_2  original_T_including_depot_unload_1091  120
    service_1_17_4  unique_nonzero_owner_290  1
    service_1_17_4  service_visit_def_1047  1
    service_1_17_4  free_load_conservation_1048  1
    service_1_17_5  unique_nonzero_owner_291  1
    service_1_17_5  service_visit_def_1047  1
    service_1_17_5  free_load_conservation_1048  2
    service_1_17_6  unique_nonzero_owner_292  1
    service_1_17_6  service_visit_def_1047  1
    service_1_17_6  free_load_conservation_1048  3
    service_1_17_7  unique_nonzero_owner_293  1
    service_1_17_7  service_visit_def_1047  1
    service_1_17_7  free_load_conservation_1048  4
    service_1_17_8  unique_nonzero_owner_294  1
    service_1_17_8  service_visit_def_1047  1
    service_1_17_8  free_load_conservation_1048  5
    service_1_17_9  unique_nonzero_owner_295  1
    service_1_17_9  service_visit_def_1047  1
    service_1_17_9  free_load_conservation_1048  6
    service_1_17_10  unique_nonzero_owner_296  1
    service_1_17_10  service_visit_def_1047  1
    service_1_17_10  free_load_conservation_1048  7
    service_1_17_11  unique_nonzero_owner_297  1
    service_1_17_11  service_visit_def_1047  1
    service_1_17_11  free_load_conservation_1048  8
    service_1_17_12  unique_nonzero_owner_298  1
    service_1_17_12  service_visit_def_1047  1
    service_1_17_12  free_load_conservation_1048  9
    service_1_17_13  unique_nonzero_owner_299  1
    service_1_17_13  service_visit_def_1047  1
    service_1_17_13  free_load_conservation_1048  10
    service_1_17_14  unique_nonzero_owner_300  1
    service_1_17_14  service_visit_def_1047  1
    service_1_17_14  free_load_conservation_1048  11
    service_1_17_15  unique_nonzero_owner_301  1
    service_1_17_15  service_visit_def_1047  1
    service_1_17_15  free_load_conservation_1048  12
    service_1_17_16  unique_nonzero_owner_302  1
    service_1_17_16  service_visit_def_1047  1
    service_1_17_16  free_load_conservation_1048  13
    service_0_14_0  unique_nonzero_owner_303  1
    service_0_14_0  service_visit_def_827  1
    service_0_14_0  free_load_conservation_828  -11
    service_0_14_0  original_T_including_depot_unload_870  1320
    service_0_14_1  unique_nonzero_owner_304  1
    service_0_14_1  service_visit_def_827  1
    service_0_14_1  free_load_conservation_828  -10
    service_0_14_1  original_T_including_depot_unload_870  1200
    service_0_14_2  unique_nonzero_owner_305  1
    service_0_14_2  service_visit_def_827  1
    service_0_14_2  free_load_conservation_828  -9
    service_0_14_2  original_T_including_depot_unload_870  1080
    service_0_14_3  unique_nonzero_owner_306  1
    service_0_14_3  service_visit_def_827  1
    service_0_14_3  free_load_conservation_828  -8
    service_0_14_3  original_T_including_depot_unload_870  960
    service_0_14_4  unique_nonzero_owner_307  1
    service_0_14_4  service_visit_def_827  1
    service_0_14_4  free_load_conservation_828  -7
    service_0_14_4  original_T_including_depot_unload_870  840
    service_0_14_5  unique_nonzero_owner_308  1
    service_0_14_5  service_visit_def_827  1
    service_0_14_5  free_load_conservation_828  -6
    service_0_14_5  original_T_including_depot_unload_870  720
    service_0_14_6  unique_nonzero_owner_309  1
    service_0_14_6  service_visit_def_827  1
    service_0_14_6  free_load_conservation_828  -5
    service_0_14_6  original_T_including_depot_unload_870  600
    service_0_14_7  unique_nonzero_owner_310  1
    service_0_14_7  service_visit_def_827  1
    service_0_14_7  free_load_conservation_828  -4
    service_0_14_7  original_T_including_depot_unload_870  480
    service_0_14_8  unique_nonzero_owner_311  1
    service_0_14_8  service_visit_def_827  1
    service_0_14_8  free_load_conservation_828  -3
    service_0_14_8  original_T_including_depot_unload_870  360
    service_0_14_9  unique_nonzero_owner_312  1
    service_0_14_9  service_visit_def_827  1
    service_0_14_9  free_load_conservation_828  -2
    service_0_14_9  original_T_including_depot_unload_870  240
    service_0_14_10  unique_nonzero_owner_313  1
    service_0_14_10  service_visit_def_827  1
    service_0_14_10  free_load_conservation_828  -1
    service_0_14_10  original_T_including_depot_unload_870  120
    service_0_14_12  unique_nonzero_owner_314  1
    service_0_14_12  service_visit_def_827  1
    service_0_14_12  free_load_conservation_828  1
    service_0_14_13  unique_nonzero_owner_315  1
    service_0_14_13  service_visit_def_827  1
    service_0_14_13  free_load_conservation_828  2
    service_0_14_14  unique_nonzero_owner_316  1
    service_0_14_14  service_visit_def_827  1
    service_0_14_14  free_load_conservation_828  3
    service_0_14_15  unique_nonzero_owner_317  1
    service_0_14_15  service_visit_def_827  1
    service_0_14_15  free_load_conservation_828  4
    service_1_14_0  unique_nonzero_owner_303  1
    service_1_14_0  service_visit_def_1053  1
    service_1_14_0  free_load_conservation_1054  -11
    service_1_14_0  original_T_including_depot_unload_1091  1320
    service_1_14_1  unique_nonzero_owner_304  1
    service_1_14_1  service_visit_def_1053  1
    service_1_14_1  free_load_conservation_1054  -10
    service_1_14_1  original_T_including_depot_unload_1091  1200
    service_1_14_2  unique_nonzero_owner_305  1
    service_1_14_2  service_visit_def_1053  1
    service_1_14_2  free_load_conservation_1054  -9
    service_1_14_2  original_T_including_depot_unload_1091  1080
    service_1_14_3  unique_nonzero_owner_306  1
    service_1_14_3  service_visit_def_1053  1
    service_1_14_3  free_load_conservation_1054  -8
    service_1_14_3  original_T_including_depot_unload_1091  960
    service_1_14_4  unique_nonzero_owner_307  1
    service_1_14_4  service_visit_def_1053  1
    service_1_14_4  free_load_conservation_1054  -7
    service_1_14_4  original_T_including_depot_unload_1091  840
    service_1_14_5  unique_nonzero_owner_308  1
    service_1_14_5  service_visit_def_1053  1
    service_1_14_5  free_load_conservation_1054  -6
    service_1_14_5  original_T_including_depot_unload_1091  720
    service_1_14_6  unique_nonzero_owner_309  1
    service_1_14_6  service_visit_def_1053  1
    service_1_14_6  free_load_conservation_1054  -5
    service_1_14_6  original_T_including_depot_unload_1091  600
    service_1_14_7  unique_nonzero_owner_310  1
    service_1_14_7  service_visit_def_1053  1
    service_1_14_7  free_load_conservation_1054  -4
    service_1_14_7  original_T_including_depot_unload_1091  480
    service_1_14_8  unique_nonzero_owner_311  1
    service_1_14_8  service_visit_def_1053  1
    service_1_14_8  free_load_conservation_1054  -3
    service_1_14_8  original_T_including_depot_unload_1091  360
    service_1_14_9  unique_nonzero_owner_312  1
    service_1_14_9  service_visit_def_1053  1
    service_1_14_9  free_load_conservation_1054  -2
    service_1_14_9  original_T_including_depot_unload_1091  240
    service_1_14_10  unique_nonzero_owner_313  1
    service_1_14_10  service_visit_def_1053  1
    service_1_14_10  free_load_conservation_1054  -1
    service_1_14_10  original_T_including_depot_unload_1091  120
    service_1_14_12  unique_nonzero_owner_314  1
    service_1_14_12  service_visit_def_1053  1
    service_1_14_12  free_load_conservation_1054  1
    service_1_14_13  unique_nonzero_owner_315  1
    service_1_14_13  service_visit_def_1053  1
    service_1_14_13  free_load_conservation_1054  2
    service_1_14_14  unique_nonzero_owner_316  1
    service_1_14_14  service_visit_def_1053  1
    service_1_14_14  free_load_conservation_1054  3
    service_1_14_15  unique_nonzero_owner_317  1
    service_1_14_15  service_visit_def_1053  1
    service_1_14_15  free_load_conservation_1054  4
    service_0_18_1  unique_nonzero_owner_318  1
    service_0_18_1  service_visit_def_833  1
    service_0_18_1  free_load_conservation_834  1
    service_0_18_2  unique_nonzero_owner_319  1
    service_0_18_2  service_visit_def_833  1
    service_0_18_2  free_load_conservation_834  2
    service_0_18_3  unique_nonzero_owner_320  1
    service_0_18_3  service_visit_def_833  1
    service_0_18_3  free_load_conservation_834  3
    service_0_18_4  unique_nonzero_owner_321  1
    service_0_18_4  service_visit_def_833  1
    service_0_18_4  free_load_conservation_834  4
    service_0_18_5  unique_nonzero_owner_322  1
    service_0_18_5  service_visit_def_833  1
    service_0_18_5  free_load_conservation_834  5
    service_0_18_6  unique_nonzero_owner_323  1
    service_0_18_6  service_visit_def_833  1
    service_0_18_6  free_load_conservation_834  6
    service_0_18_7  unique_nonzero_owner_324  1
    service_0_18_7  service_visit_def_833  1
    service_0_18_7  free_load_conservation_834  7
    service_0_18_8  unique_nonzero_owner_325  1
    service_0_18_8  service_visit_def_833  1
    service_0_18_8  free_load_conservation_834  8
    service_0_18_9  unique_nonzero_owner_326  1
    service_0_18_9  service_visit_def_833  1
    service_0_18_9  free_load_conservation_834  9
    service_0_18_10  unique_nonzero_owner_327  1
    service_0_18_10  service_visit_def_833  1
    service_0_18_10  free_load_conservation_834  10
    service_0_18_11  unique_nonzero_owner_328  1
    service_0_18_11  service_visit_def_833  1
    service_0_18_11  free_load_conservation_834  11
    service_0_18_12  unique_nonzero_owner_329  1
    service_0_18_12  service_visit_def_833  1
    service_0_18_12  free_load_conservation_834  12
    service_0_18_13  unique_nonzero_owner_330  1
    service_0_18_13  service_visit_def_833  1
    service_0_18_13  free_load_conservation_834  13
    service_0_18_14  unique_nonzero_owner_331  1
    service_0_18_14  service_visit_def_833  1
    service_0_18_14  free_load_conservation_834  14
    service_0_18_15  unique_nonzero_owner_332  1
    service_0_18_15  service_visit_def_833  1
    service_0_18_15  free_load_conservation_834  15
    service_1_18_1  unique_nonzero_owner_318  1
    service_1_18_1  service_visit_def_1059  1
    service_1_18_1  free_load_conservation_1060  1
    service_1_18_2  unique_nonzero_owner_319  1
    service_1_18_2  service_visit_def_1059  1
    service_1_18_2  free_load_conservation_1060  2
    service_1_18_3  unique_nonzero_owner_320  1
    service_1_18_3  service_visit_def_1059  1
    service_1_18_3  free_load_conservation_1060  3
    service_1_18_4  unique_nonzero_owner_321  1
    service_1_18_4  service_visit_def_1059  1
    service_1_18_4  free_load_conservation_1060  4
    service_1_18_5  unique_nonzero_owner_322  1
    service_1_18_5  service_visit_def_1059  1
    service_1_18_5  free_load_conservation_1060  5
    service_1_18_6  unique_nonzero_owner_323  1
    service_1_18_6  service_visit_def_1059  1
    service_1_18_6  free_load_conservation_1060  6
    service_1_18_7  unique_nonzero_owner_324  1
    service_1_18_7  service_visit_def_1059  1
    service_1_18_7  free_load_conservation_1060  7
    service_1_18_8  unique_nonzero_owner_325  1
    service_1_18_8  service_visit_def_1059  1
    service_1_18_8  free_load_conservation_1060  8
    service_1_18_9  unique_nonzero_owner_326  1
    service_1_18_9  service_visit_def_1059  1
    service_1_18_9  free_load_conservation_1060  9
    service_1_18_10  unique_nonzero_owner_327  1
    service_1_18_10  service_visit_def_1059  1
    service_1_18_10  free_load_conservation_1060  10
    service_1_18_11  unique_nonzero_owner_328  1
    service_1_18_11  service_visit_def_1059  1
    service_1_18_11  free_load_conservation_1060  11
    service_1_18_12  unique_nonzero_owner_329  1
    service_1_18_12  service_visit_def_1059  1
    service_1_18_12  free_load_conservation_1060  12
    service_1_18_13  unique_nonzero_owner_330  1
    service_1_18_13  service_visit_def_1059  1
    service_1_18_13  free_load_conservation_1060  13
    service_1_18_14  unique_nonzero_owner_331  1
    service_1_18_14  service_visit_def_1059  1
    service_1_18_14  free_load_conservation_1060  14
    service_1_18_15  unique_nonzero_owner_332  1
    service_1_18_15  service_visit_def_1059  1
    service_1_18_15  free_load_conservation_1060  15
    service_0_13_1  unique_nonzero_owner_333  1
    service_0_13_1  service_visit_def_839  1
    service_0_13_1  free_load_conservation_840  1
    service_1_13_1  unique_nonzero_owner_333  1
    service_1_13_1  service_visit_def_1065  1
    service_1_13_1  free_load_conservation_1066  1
    service_0_20_0  unique_nonzero_owner_334  1
    service_0_20_0  service_visit_def_845  1
    service_0_20_0  free_load_conservation_846  -12
    service_0_20_0  original_T_including_depot_unload_870  1440
    service_0_20_1  unique_nonzero_owner_335  1
    service_0_20_1  service_visit_def_845  1
    service_0_20_1  free_load_conservation_846  -11
    service_0_20_1  original_T_including_depot_unload_870  1320
    service_0_20_2  unique_nonzero_owner_336  1
    service_0_20_2  service_visit_def_845  1
    service_0_20_2  free_load_conservation_846  -10
    service_0_20_2  original_T_including_depot_unload_870  1200
    service_0_20_3  unique_nonzero_owner_337  1
    service_0_20_3  service_visit_def_845  1
    service_0_20_3  free_load_conservation_846  -9
    service_0_20_3  original_T_including_depot_unload_870  1080
    service_0_20_4  unique_nonzero_owner_338  1
    service_0_20_4  service_visit_def_845  1
    service_0_20_4  free_load_conservation_846  -8
    service_0_20_4  original_T_including_depot_unload_870  960
    service_0_20_5  unique_nonzero_owner_339  1
    service_0_20_5  service_visit_def_845  1
    service_0_20_5  free_load_conservation_846  -7
    service_0_20_5  original_T_including_depot_unload_870  840
    service_0_20_6  unique_nonzero_owner_340  1
    service_0_20_6  service_visit_def_845  1
    service_0_20_6  free_load_conservation_846  -6
    service_0_20_6  original_T_including_depot_unload_870  720
    service_0_20_7  unique_nonzero_owner_341  1
    service_0_20_7  service_visit_def_845  1
    service_0_20_7  free_load_conservation_846  -5
    service_0_20_7  original_T_including_depot_unload_870  600
    service_0_20_8  unique_nonzero_owner_342  1
    service_0_20_8  service_visit_def_845  1
    service_0_20_8  free_load_conservation_846  -4
    service_0_20_8  original_T_including_depot_unload_870  480
    service_0_20_9  unique_nonzero_owner_343  1
    service_0_20_9  service_visit_def_845  1
    service_0_20_9  free_load_conservation_846  -3
    service_0_20_9  original_T_including_depot_unload_870  360
    service_0_20_10  unique_nonzero_owner_344  1
    service_0_20_10  service_visit_def_845  1
    service_0_20_10  free_load_conservation_846  -2
    service_0_20_10  original_T_including_depot_unload_870  240
    service_0_20_11  unique_nonzero_owner_345  1
    service_0_20_11  service_visit_def_845  1
    service_0_20_11  free_load_conservation_846  -1
    service_0_20_11  original_T_including_depot_unload_870  120
    service_0_20_13  unique_nonzero_owner_346  1
    service_0_20_13  service_visit_def_845  1
    service_0_20_13  free_load_conservation_846  1
    service_0_20_14  unique_nonzero_owner_347  1
    service_0_20_14  service_visit_def_845  1
    service_0_20_14  free_load_conservation_846  2
    service_0_20_15  unique_nonzero_owner_348  1
    service_0_20_15  service_visit_def_845  1
    service_0_20_15  free_load_conservation_846  3
    service_1_20_0  unique_nonzero_owner_334  1
    service_1_20_0  service_visit_def_1071  1
    service_1_20_0  free_load_conservation_1072  -12
    service_1_20_0  original_T_including_depot_unload_1091  1440
    service_1_20_1  unique_nonzero_owner_335  1
    service_1_20_1  service_visit_def_1071  1
    service_1_20_1  free_load_conservation_1072  -11
    service_1_20_1  original_T_including_depot_unload_1091  1320
    service_1_20_2  unique_nonzero_owner_336  1
    service_1_20_2  service_visit_def_1071  1
    service_1_20_2  free_load_conservation_1072  -10
    service_1_20_2  original_T_including_depot_unload_1091  1200
    service_1_20_3  unique_nonzero_owner_337  1
    service_1_20_3  service_visit_def_1071  1
    service_1_20_3  free_load_conservation_1072  -9
    service_1_20_3  original_T_including_depot_unload_1091  1080
    service_1_20_4  unique_nonzero_owner_338  1
    service_1_20_4  service_visit_def_1071  1
    service_1_20_4  free_load_conservation_1072  -8
    service_1_20_4  original_T_including_depot_unload_1091  960
    service_1_20_5  unique_nonzero_owner_339  1
    service_1_20_5  service_visit_def_1071  1
    service_1_20_5  free_load_conservation_1072  -7
    service_1_20_5  original_T_including_depot_unload_1091  840
    service_1_20_6  unique_nonzero_owner_340  1
    service_1_20_6  service_visit_def_1071  1
    service_1_20_6  free_load_conservation_1072  -6
    service_1_20_6  original_T_including_depot_unload_1091  720
    service_1_20_7  unique_nonzero_owner_341  1
    service_1_20_7  service_visit_def_1071  1
    service_1_20_7  free_load_conservation_1072  -5
    service_1_20_7  original_T_including_depot_unload_1091  600
    service_1_20_8  unique_nonzero_owner_342  1
    service_1_20_8  service_visit_def_1071  1
    service_1_20_8  free_load_conservation_1072  -4
    service_1_20_8  original_T_including_depot_unload_1091  480
    service_1_20_9  unique_nonzero_owner_343  1
    service_1_20_9  service_visit_def_1071  1
    service_1_20_9  free_load_conservation_1072  -3
    service_1_20_9  original_T_including_depot_unload_1091  360
    service_1_20_10  unique_nonzero_owner_344  1
    service_1_20_10  service_visit_def_1071  1
    service_1_20_10  free_load_conservation_1072  -2
    service_1_20_10  original_T_including_depot_unload_1091  240
    service_1_20_11  unique_nonzero_owner_345  1
    service_1_20_11  service_visit_def_1071  1
    service_1_20_11  free_load_conservation_1072  -1
    service_1_20_11  original_T_including_depot_unload_1091  120
    service_1_20_13  unique_nonzero_owner_346  1
    service_1_20_13  service_visit_def_1071  1
    service_1_20_13  free_load_conservation_1072  1
    service_1_20_14  unique_nonzero_owner_347  1
    service_1_20_14  service_visit_def_1071  1
    service_1_20_14  free_load_conservation_1072  2
    service_1_20_15  unique_nonzero_owner_348  1
    service_1_20_15  service_visit_def_1071  1
    service_1_20_15  free_load_conservation_1072  3
    service_0_12_0  unique_nonzero_owner_349  1
    service_0_12_0  service_visit_def_851  1
    service_0_12_0  free_load_conservation_852  -11
    service_0_12_0  original_T_including_depot_unload_870  1320
    service_0_12_1  unique_nonzero_owner_350  1
    service_0_12_1  service_visit_def_851  1
    service_0_12_1  free_load_conservation_852  -10
    service_0_12_1  original_T_including_depot_unload_870  1200
    service_0_12_2  unique_nonzero_owner_351  1
    service_0_12_2  service_visit_def_851  1
    service_0_12_2  free_load_conservation_852  -9
    service_0_12_2  original_T_including_depot_unload_870  1080
    service_0_12_3  unique_nonzero_owner_352  1
    service_0_12_3  service_visit_def_851  1
    service_0_12_3  free_load_conservation_852  -8
    service_0_12_3  original_T_including_depot_unload_870  960
    service_0_12_4  unique_nonzero_owner_353  1
    service_0_12_4  service_visit_def_851  1
    service_0_12_4  free_load_conservation_852  -7
    service_0_12_4  original_T_including_depot_unload_870  840
    service_0_12_5  unique_nonzero_owner_354  1
    service_0_12_5  service_visit_def_851  1
    service_0_12_5  free_load_conservation_852  -6
    service_0_12_5  original_T_including_depot_unload_870  720
    service_0_12_6  unique_nonzero_owner_355  1
    service_0_12_6  service_visit_def_851  1
    service_0_12_6  free_load_conservation_852  -5
    service_0_12_6  original_T_including_depot_unload_870  600
    service_0_12_7  unique_nonzero_owner_356  1
    service_0_12_7  service_visit_def_851  1
    service_0_12_7  free_load_conservation_852  -4
    service_0_12_7  original_T_including_depot_unload_870  480
    service_0_12_8  unique_nonzero_owner_357  1
    service_0_12_8  service_visit_def_851  1
    service_0_12_8  free_load_conservation_852  -3
    service_0_12_8  original_T_including_depot_unload_870  360
    service_0_12_9  unique_nonzero_owner_358  1
    service_0_12_9  service_visit_def_851  1
    service_0_12_9  free_load_conservation_852  -2
    service_0_12_9  original_T_including_depot_unload_870  240
    service_0_12_10  unique_nonzero_owner_359  1
    service_0_12_10  service_visit_def_851  1
    service_0_12_10  free_load_conservation_852  -1
    service_0_12_10  original_T_including_depot_unload_870  120
    service_0_12_12  unique_nonzero_owner_360  1
    service_0_12_12  service_visit_def_851  1
    service_0_12_12  free_load_conservation_852  1
    service_0_12_13  unique_nonzero_owner_361  1
    service_0_12_13  service_visit_def_851  1
    service_0_12_13  free_load_conservation_852  2
    service_0_12_14  unique_nonzero_owner_362  1
    service_0_12_14  service_visit_def_851  1
    service_0_12_14  free_load_conservation_852  3
    service_0_12_15  unique_nonzero_owner_363  1
    service_0_12_15  service_visit_def_851  1
    service_0_12_15  free_load_conservation_852  4
    service_1_12_0  unique_nonzero_owner_349  1
    service_1_12_0  service_visit_def_1077  1
    service_1_12_0  free_load_conservation_1078  -11
    service_1_12_0  original_T_including_depot_unload_1091  1320
    service_1_12_1  unique_nonzero_owner_350  1
    service_1_12_1  service_visit_def_1077  1
    service_1_12_1  free_load_conservation_1078  -10
    service_1_12_1  original_T_including_depot_unload_1091  1200
    service_1_12_2  unique_nonzero_owner_351  1
    service_1_12_2  service_visit_def_1077  1
    service_1_12_2  free_load_conservation_1078  -9
    service_1_12_2  original_T_including_depot_unload_1091  1080
    service_1_12_3  unique_nonzero_owner_352  1
    service_1_12_3  service_visit_def_1077  1
    service_1_12_3  free_load_conservation_1078  -8
    service_1_12_3  original_T_including_depot_unload_1091  960
    service_1_12_4  unique_nonzero_owner_353  1
    service_1_12_4  service_visit_def_1077  1
    service_1_12_4  free_load_conservation_1078  -7
    service_1_12_4  original_T_including_depot_unload_1091  840
    service_1_12_5  unique_nonzero_owner_354  1
    service_1_12_5  service_visit_def_1077  1
    service_1_12_5  free_load_conservation_1078  -6
    service_1_12_5  original_T_including_depot_unload_1091  720
    service_1_12_6  unique_nonzero_owner_355  1
    service_1_12_6  service_visit_def_1077  1
    service_1_12_6  free_load_conservation_1078  -5
    service_1_12_6  original_T_including_depot_unload_1091  600
    service_1_12_7  unique_nonzero_owner_356  1
    service_1_12_7  service_visit_def_1077  1
    service_1_12_7  free_load_conservation_1078  -4
    service_1_12_7  original_T_including_depot_unload_1091  480
    service_1_12_8  unique_nonzero_owner_357  1
    service_1_12_8  service_visit_def_1077  1
    service_1_12_8  free_load_conservation_1078  -3
    service_1_12_8  original_T_including_depot_unload_1091  360
    service_1_12_9  unique_nonzero_owner_358  1
    service_1_12_9  service_visit_def_1077  1
    service_1_12_9  free_load_conservation_1078  -2
    service_1_12_9  original_T_including_depot_unload_1091  240
    service_1_12_10  unique_nonzero_owner_359  1
    service_1_12_10  service_visit_def_1077  1
    service_1_12_10  free_load_conservation_1078  -1
    service_1_12_10  original_T_including_depot_unload_1091  120
    service_1_12_12  unique_nonzero_owner_360  1
    service_1_12_12  service_visit_def_1077  1
    service_1_12_12  free_load_conservation_1078  1
    service_1_12_13  unique_nonzero_owner_361  1
    service_1_12_13  service_visit_def_1077  1
    service_1_12_13  free_load_conservation_1078  2
    service_1_12_14  unique_nonzero_owner_362  1
    service_1_12_14  service_visit_def_1077  1
    service_1_12_14  free_load_conservation_1078  3
    service_1_12_15  unique_nonzero_owner_363  1
    service_1_12_15  service_visit_def_1077  1
    service_1_12_15  free_load_conservation_1078  4
    service_0_11_0  unique_nonzero_owner_364  1
    service_0_11_0  service_visit_def_857  1
    service_0_11_0  free_load_conservation_858  -1
    service_0_11_0  original_T_including_depot_unload_870  120
    service_0_11_2  unique_nonzero_owner_365  1
    service_0_11_2  service_visit_def_857  1
    service_0_11_2  free_load_conservation_858  1
    service_0_11_3  unique_nonzero_owner_366  1
    service_0_11_3  service_visit_def_857  1
    service_0_11_3  free_load_conservation_858  2
    service_0_11_4  unique_nonzero_owner_367  1
    service_0_11_4  service_visit_def_857  1
    service_0_11_4  free_load_conservation_858  3
    service_0_11_5  unique_nonzero_owner_368  1
    service_0_11_5  service_visit_def_857  1
    service_0_11_5  free_load_conservation_858  4
    service_0_11_6  unique_nonzero_owner_369  1
    service_0_11_6  service_visit_def_857  1
    service_0_11_6  free_load_conservation_858  5
    service_0_11_7  unique_nonzero_owner_370  1
    service_0_11_7  service_visit_def_857  1
    service_0_11_7  free_load_conservation_858  6
    service_0_11_8  unique_nonzero_owner_371  1
    service_0_11_8  service_visit_def_857  1
    service_0_11_8  free_load_conservation_858  7
    service_0_11_9  unique_nonzero_owner_372  1
    service_0_11_9  service_visit_def_857  1
    service_0_11_9  free_load_conservation_858  8
    service_0_11_10  unique_nonzero_owner_373  1
    service_0_11_10  service_visit_def_857  1
    service_0_11_10  free_load_conservation_858  9
    service_0_11_11  unique_nonzero_owner_374  1
    service_0_11_11  service_visit_def_857  1
    service_0_11_11  free_load_conservation_858  10
    service_0_11_12  unique_nonzero_owner_375  1
    service_0_11_12  service_visit_def_857  1
    service_0_11_12  free_load_conservation_858  11
    service_0_11_13  unique_nonzero_owner_376  1
    service_0_11_13  service_visit_def_857  1
    service_0_11_13  free_load_conservation_858  12
    service_0_11_14  unique_nonzero_owner_377  1
    service_0_11_14  service_visit_def_857  1
    service_0_11_14  free_load_conservation_858  13
    service_0_11_15  unique_nonzero_owner_378  1
    service_0_11_15  service_visit_def_857  1
    service_0_11_15  free_load_conservation_858  14
    service_1_11_0  unique_nonzero_owner_364  1
    service_1_11_0  service_visit_def_1083  1
    service_1_11_0  free_load_conservation_1084  -1
    service_1_11_0  original_T_including_depot_unload_1091  120
    service_1_11_2  unique_nonzero_owner_365  1
    service_1_11_2  service_visit_def_1083  1
    service_1_11_2  free_load_conservation_1084  1
    service_1_11_3  unique_nonzero_owner_366  1
    service_1_11_3  service_visit_def_1083  1
    service_1_11_3  free_load_conservation_1084  2
    service_1_11_4  unique_nonzero_owner_367  1
    service_1_11_4  service_visit_def_1083  1
    service_1_11_4  free_load_conservation_1084  3
    service_1_11_5  unique_nonzero_owner_368  1
    service_1_11_5  service_visit_def_1083  1
    service_1_11_5  free_load_conservation_1084  4
    service_1_11_6  unique_nonzero_owner_369  1
    service_1_11_6  service_visit_def_1083  1
    service_1_11_6  free_load_conservation_1084  5
    service_1_11_7  unique_nonzero_owner_370  1
    service_1_11_7  service_visit_def_1083  1
    service_1_11_7  free_load_conservation_1084  6
    service_1_11_8  unique_nonzero_owner_371  1
    service_1_11_8  service_visit_def_1083  1
    service_1_11_8  free_load_conservation_1084  7
    service_1_11_9  unique_nonzero_owner_372  1
    service_1_11_9  service_visit_def_1083  1
    service_1_11_9  free_load_conservation_1084  8
    service_1_11_10  unique_nonzero_owner_373  1
    service_1_11_10  service_visit_def_1083  1
    service_1_11_10  free_load_conservation_1084  9
    service_1_11_11  unique_nonzero_owner_374  1
    service_1_11_11  service_visit_def_1083  1
    service_1_11_11  free_load_conservation_1084  10
    service_1_11_12  unique_nonzero_owner_375  1
    service_1_11_12  service_visit_def_1083  1
    service_1_11_12  free_load_conservation_1084  11
    service_1_11_13  unique_nonzero_owner_376  1
    service_1_11_13  service_visit_def_1083  1
    service_1_11_13  free_load_conservation_1084  12
    service_1_11_14  unique_nonzero_owner_377  1
    service_1_11_14  service_visit_def_1083  1
    service_1_11_14  free_load_conservation_1084  13
    service_1_11_15  unique_nonzero_owner_378  1
    service_1_11_15  service_visit_def_1083  1
    service_1_11_15  free_load_conservation_1084  14
    service_0_10_1  unique_nonzero_owner_379  1
    service_0_10_1  service_visit_def_863  1
    service_0_10_1  free_load_conservation_864  1
    service_1_10_1  unique_nonzero_owner_379  1
    service_1_10_1  service_visit_def_1089  1
    service_1_10_1  free_load_conservation_1090  1
    MARKER    'MARKER'                 'INTEND'
    visit_0_1  out_degree_775  -1
    visit_0_1  in_degree_776  -1
    visit_0_1  order_active_lb_777  -1
    visit_0_1  order_active_ub_778  -14
    order_0_1  connected_order_arc_397  -1
    order_0_1  connected_order_arc_399  -1
    order_0_1  connected_order_arc_401  -1
    order_0_1  connected_order_arc_403  -1
    order_0_1  connected_order_arc_405  -1
    order_0_1  connected_order_arc_407  -1
    order_0_1  connected_order_arc_409  -1
    order_0_1  connected_order_arc_411  -1
    order_0_1  connected_order_arc_413  -1
    order_0_1  connected_order_arc_415  -1
    order_0_1  connected_order_arc_417  -1
    order_0_1  connected_order_arc_419  -1
    order_0_1  connected_order_arc_421  -1
    order_0_1  connected_order_arc_424  1
    order_0_1  connected_order_arc_451  1
    order_0_1  connected_order_arc_478  1
    order_0_1  connected_order_arc_505  1
    order_0_1  connected_order_arc_532  1
    order_0_1  connected_order_arc_559  1
    order_0_1  connected_order_arc_586  1
    order_0_1  connected_order_arc_613  1
    order_0_1  connected_order_arc_640  1
    order_0_1  connected_order_arc_667  1
    order_0_1  connected_order_arc_694  1
    order_0_1  connected_order_arc_721  1
    order_0_1  connected_order_arc_748  1
    order_0_1  order_active_lb_777  1
    order_0_1  order_active_ub_778  1
    order_0_1  fixed_segment_relative_order_865  -1
    visit_0_2  out_degree_782  -1
    visit_0_2  in_degree_783  -1
    visit_0_2  order_active_lb_784  -1
    visit_0_2  order_active_ub_785  -14
    order_0_2  connected_order_arc_397  1
    order_0_2  connected_order_arc_424  -1
    order_0_2  connected_order_arc_426  -1
    order_0_2  connected_order_arc_428  -1
    order_0_2  connected_order_arc_430  -1
    order_0_2  connected_order_arc_432  -1
    order_0_2  connected_order_arc_434  -1
    order_0_2  connected_order_arc_436  -1
    order_0_2  connected_order_arc_438  -1
    order_0_2  connected_order_arc_440  -1
    order_0_2  connected_order_arc_442  -1
    order_0_2  connected_order_arc_444  -1
    order_0_2  connected_order_arc_446  -1
    order_0_2  connected_order_arc_448  -1
    order_0_2  connected_order_arc_453  1
    order_0_2  connected_order_arc_480  1
    order_0_2  connected_order_arc_507  1
    order_0_2  connected_order_arc_534  1
    order_0_2  connected_order_arc_561  1
    order_0_2  connected_order_arc_588  1
    order_0_2  connected_order_arc_615  1
    order_0_2  connected_order_arc_642  1
    order_0_2  connected_order_arc_669  1
    order_0_2  connected_order_arc_696  1
    order_0_2  connected_order_arc_723  1
    order_0_2  connected_order_arc_750  1
    order_0_2  order_active_lb_784  1
    order_0_2  order_active_ub_785  1
    order_0_2  fixed_segment_relative_order_865  1
    order_0_2  fixed_segment_relative_order_866  -1
    visit_0_3  out_degree_789  -1
    visit_0_3  in_degree_790  -1
    visit_0_3  order_active_lb_791  -1
    visit_0_3  order_active_ub_792  -14
    order_0_3  connected_order_arc_399  1
    order_0_3  connected_order_arc_426  1
    order_0_3  connected_order_arc_451  -1
    order_0_3  connected_order_arc_453  -1
    order_0_3  connected_order_arc_455  -1
    order_0_3  connected_order_arc_457  -1
    order_0_3  connected_order_arc_459  -1
    order_0_3  connected_order_arc_461  -1
    order_0_3  connected_order_arc_463  -1
    order_0_3  connected_order_arc_465  -1
    order_0_3  connected_order_arc_467  -1
    order_0_3  connected_order_arc_469  -1
    order_0_3  connected_order_arc_471  -1
    order_0_3  connected_order_arc_473  -1
    order_0_3  connected_order_arc_475  -1
    order_0_3  connected_order_arc_482  1
    order_0_3  connected_order_arc_509  1
    order_0_3  connected_order_arc_536  1
    order_0_3  connected_order_arc_563  1
    order_0_3  connected_order_arc_590  1
    order_0_3  connected_order_arc_617  1
    order_0_3  connected_order_arc_644  1
    order_0_3  connected_order_arc_671  1
    order_0_3  connected_order_arc_698  1
    order_0_3  connected_order_arc_725  1
    order_0_3  connected_order_arc_752  1
    order_0_3  order_active_lb_791  1
    order_0_3  order_active_ub_792  1
    order_0_3  fixed_segment_relative_order_866  1
    order_0_3  fixed_segment_relative_order_867  -1
    visit_0_4  out_degree_796  -1
    visit_0_4  in_degree_797  -1
    visit_0_4  order_active_lb_798  -1
    visit_0_4  order_active_ub_799  -14
    order_0_4  connected_order_arc_401  1
    order_0_4  connected_order_arc_428  1
    order_0_4  connected_order_arc_455  1
    order_0_4  connected_order_arc_478  -1
    order_0_4  connected_order_arc_480  -1
    order_0_4  connected_order_arc_482  -1
    order_0_4  connected_order_arc_484  -1
    order_0_4  connected_order_arc_486  -1
    order_0_4  connected_order_arc_488  -1
    order_0_4  connected_order_arc_490  -1
    order_0_4  connected_order_arc_492  -1
    order_0_4  connected_order_arc_494  -1
    order_0_4  connected_order_arc_496  -1
    order_0_4  connected_order_arc_498  -1
    order_0_4  connected_order_arc_500  -1
    order_0_4  connected_order_arc_502  -1
    order_0_4  connected_order_arc_511  1
    order_0_4  connected_order_arc_538  1
    order_0_4  connected_order_arc_565  1
    order_0_4  connected_order_arc_592  1
    order_0_4  connected_order_arc_619  1
    order_0_4  connected_order_arc_646  1
    order_0_4  connected_order_arc_673  1
    order_0_4  connected_order_arc_700  1
    order_0_4  connected_order_arc_727  1
    order_0_4  connected_order_arc_754  1
    order_0_4  order_active_lb_798  1
    order_0_4  order_active_ub_799  1
    order_0_4  fixed_segment_relative_order_867  1
    order_0_4  fixed_segment_relative_order_868  -1
    visit_0_5  out_degree_803  -1
    visit_0_5  in_degree_804  -1
    visit_0_5  order_active_lb_805  -1
    visit_0_5  order_active_ub_806  -14
    order_0_5  connected_order_arc_403  1
    order_0_5  connected_order_arc_430  1
    order_0_5  connected_order_arc_457  1
    order_0_5  connected_order_arc_484  1
    order_0_5  connected_order_arc_505  -1
    order_0_5  connected_order_arc_507  -1
    order_0_5  connected_order_arc_509  -1
    order_0_5  connected_order_arc_511  -1
    order_0_5  connected_order_arc_513  -1
    order_0_5  connected_order_arc_515  -1
    order_0_5  connected_order_arc_517  -1
    order_0_5  connected_order_arc_519  -1
    order_0_5  connected_order_arc_521  -1
    order_0_5  connected_order_arc_523  -1
    order_0_5  connected_order_arc_525  -1
    order_0_5  connected_order_arc_527  -1
    order_0_5  connected_order_arc_529  -1
    order_0_5  connected_order_arc_540  1
    order_0_5  connected_order_arc_567  1
    order_0_5  connected_order_arc_594  1
    order_0_5  connected_order_arc_621  1
    order_0_5  connected_order_arc_648  1
    order_0_5  connected_order_arc_675  1
    order_0_5  connected_order_arc_702  1
    order_0_5  connected_order_arc_729  1
    order_0_5  connected_order_arc_756  1
    order_0_5  order_active_lb_805  1
    order_0_5  order_active_ub_806  1
    order_0_5  fixed_segment_relative_order_868  1
    order_0_5  fixed_segment_relative_order_869  -1
    visit_0_6  out_degree_810  -1
    visit_0_6  in_degree_811  -1
    visit_0_6  order_active_lb_812  -1
    visit_0_6  order_active_ub_813  -14
    order_0_6  connected_order_arc_405  1
    order_0_6  connected_order_arc_432  1
    order_0_6  connected_order_arc_459  1
    order_0_6  connected_order_arc_486  1
    order_0_6  connected_order_arc_513  1
    order_0_6  connected_order_arc_532  -1
    order_0_6  connected_order_arc_534  -1
    order_0_6  connected_order_arc_536  -1
    order_0_6  connected_order_arc_538  -1
    order_0_6  connected_order_arc_540  -1
    order_0_6  connected_order_arc_542  -1
    order_0_6  connected_order_arc_544  -1
    order_0_6  connected_order_arc_546  -1
    order_0_6  connected_order_arc_548  -1
    order_0_6  connected_order_arc_550  -1
    order_0_6  connected_order_arc_552  -1
    order_0_6  connected_order_arc_554  -1
    order_0_6  connected_order_arc_556  -1
    order_0_6  connected_order_arc_569  1
    order_0_6  connected_order_arc_596  1
    order_0_6  connected_order_arc_623  1
    order_0_6  connected_order_arc_650  1
    order_0_6  connected_order_arc_677  1
    order_0_6  connected_order_arc_704  1
    order_0_6  connected_order_arc_731  1
    order_0_6  connected_order_arc_758  1
    order_0_6  order_active_lb_812  1
    order_0_6  order_active_ub_813  1
    order_0_6  fixed_segment_relative_order_869  1
    visit_0_8  out_degree_817  -1
    visit_0_8  in_degree_818  -1
    visit_0_8  order_active_lb_819  -1
    visit_0_8  order_active_ub_820  -14
    visit_0_8  service_visit_def_821  -1
    order_0_8  connected_order_arc_407  1
    order_0_8  connected_order_arc_434  1
    order_0_8  connected_order_arc_461  1
    order_0_8  connected_order_arc_488  1
    order_0_8  connected_order_arc_515  1
    order_0_8  connected_order_arc_542  1
    order_0_8  connected_order_arc_559  -1
    order_0_8  connected_order_arc_561  -1
    order_0_8  connected_order_arc_563  -1
    order_0_8  connected_order_arc_565  -1
    order_0_8  connected_order_arc_567  -1
    order_0_8  connected_order_arc_569  -1
    order_0_8  connected_order_arc_571  -1
    order_0_8  connected_order_arc_573  -1
    order_0_8  connected_order_arc_575  -1
    order_0_8  connected_order_arc_577  -1
    order_0_8  connected_order_arc_579  -1
    order_0_8  connected_order_arc_581  -1
    order_0_8  connected_order_arc_583  -1
    order_0_8  connected_order_arc_598  1
    order_0_8  connected_order_arc_625  1
    order_0_8  connected_order_arc_652  1
    order_0_8  connected_order_arc_679  1
    order_0_8  connected_order_arc_706  1
    order_0_8  connected_order_arc_733  1
    order_0_8  connected_order_arc_760  1
    order_0_8  order_active_lb_819  1
    order_0_8  order_active_ub_820  1
    visit_0_9  out_degree_823  -1
    visit_0_9  in_degree_824  -1
    visit_0_9  order_active_lb_825  -1
    visit_0_9  order_active_ub_826  -14
    visit_0_9  service_visit_def_827  -1
    order_0_9  connected_order_arc_409  1
    order_0_9  connected_order_arc_436  1
    order_0_9  connected_order_arc_463  1
    order_0_9  connected_order_arc_490  1
    order_0_9  connected_order_arc_517  1
    order_0_9  connected_order_arc_544  1
    order_0_9  connected_order_arc_571  1
    order_0_9  connected_order_arc_586  -1
    order_0_9  connected_order_arc_588  -1
    order_0_9  connected_order_arc_590  -1
    order_0_9  connected_order_arc_592  -1
    order_0_9  connected_order_arc_594  -1
    order_0_9  connected_order_arc_596  -1
    order_0_9  connected_order_arc_598  -1
    order_0_9  connected_order_arc_600  -1
    order_0_9  connected_order_arc_602  -1
    order_0_9  connected_order_arc_604  -1
    order_0_9  connected_order_arc_606  -1
    order_0_9  connected_order_arc_608  -1
    order_0_9  connected_order_arc_610  -1
    order_0_9  connected_order_arc_627  1
    order_0_9  connected_order_arc_654  1
    order_0_9  connected_order_arc_681  1
    order_0_9  connected_order_arc_708  1
    order_0_9  connected_order_arc_735  1
    order_0_9  connected_order_arc_762  1
    order_0_9  order_active_lb_825  1
    order_0_9  order_active_ub_826  1
    visit_0_10  out_degree_829  -1
    visit_0_10  in_degree_830  -1
    visit_0_10  order_active_lb_831  -1
    visit_0_10  order_active_ub_832  -14
    visit_0_10  service_visit_def_833  -1
    order_0_10  connected_order_arc_411  1
    order_0_10  connected_order_arc_438  1
    order_0_10  connected_order_arc_465  1
    order_0_10  connected_order_arc_492  1
    order_0_10  connected_order_arc_519  1
    order_0_10  connected_order_arc_546  1
    order_0_10  connected_order_arc_573  1
    order_0_10  connected_order_arc_600  1
    order_0_10  connected_order_arc_613  -1
    order_0_10  connected_order_arc_615  -1
    order_0_10  connected_order_arc_617  -1
    order_0_10  connected_order_arc_619  -1
    order_0_10  connected_order_arc_621  -1
    order_0_10  connected_order_arc_623  -1
    order_0_10  connected_order_arc_625  -1
    order_0_10  connected_order_arc_627  -1
    order_0_10  connected_order_arc_629  -1
    order_0_10  connected_order_arc_631  -1
    order_0_10  connected_order_arc_633  -1
    order_0_10  connected_order_arc_635  -1
    order_0_10  connected_order_arc_637  -1
    order_0_10  connected_order_arc_656  1
    order_0_10  connected_order_arc_683  1
    order_0_10  connected_order_arc_710  1
    order_0_10  connected_order_arc_737  1
    order_0_10  connected_order_arc_764  1
    order_0_10  order_active_lb_831  1
    order_0_10  order_active_ub_832  1
    visit_0_11  out_degree_835  -1
    visit_0_11  in_degree_836  -1
    visit_0_11  order_active_lb_837  -1
    visit_0_11  order_active_ub_838  -14
    visit_0_11  service_visit_def_839  -1
    order_0_11  connected_order_arc_413  1
    order_0_11  connected_order_arc_440  1
    order_0_11  connected_order_arc_467  1
    order_0_11  connected_order_arc_494  1
    order_0_11  connected_order_arc_521  1
    order_0_11  connected_order_arc_548  1
    order_0_11  connected_order_arc_575  1
    order_0_11  connected_order_arc_602  1
    order_0_11  connected_order_arc_629  1
    order_0_11  connected_order_arc_640  -1
    order_0_11  connected_order_arc_642  -1
    order_0_11  connected_order_arc_644  -1
    order_0_11  connected_order_arc_646  -1
    order_0_11  connected_order_arc_648  -1
    order_0_11  connected_order_arc_650  -1
    order_0_11  connected_order_arc_652  -1
    order_0_11  connected_order_arc_654  -1
    order_0_11  connected_order_arc_656  -1
    order_0_11  connected_order_arc_658  -1
    order_0_11  connected_order_arc_660  -1
    order_0_11  connected_order_arc_662  -1
    order_0_11  connected_order_arc_664  -1
    order_0_11  connected_order_arc_685  1
    order_0_11  connected_order_arc_712  1
    order_0_11  connected_order_arc_739  1
    order_0_11  connected_order_arc_766  1
    order_0_11  order_active_lb_837  1
    order_0_11  order_active_ub_838  1
    visit_0_12  out_degree_841  -1
    visit_0_12  in_degree_842  -1
    visit_0_12  order_active_lb_843  -1
    visit_0_12  order_active_ub_844  -14
    visit_0_12  service_visit_def_845  -1
    order_0_12  connected_order_arc_415  1
    order_0_12  connected_order_arc_442  1
    order_0_12  connected_order_arc_469  1
    order_0_12  connected_order_arc_496  1
    order_0_12  connected_order_arc_523  1
    order_0_12  connected_order_arc_550  1
    order_0_12  connected_order_arc_577  1
    order_0_12  connected_order_arc_604  1
    order_0_12  connected_order_arc_631  1
    order_0_12  connected_order_arc_658  1
    order_0_12  connected_order_arc_667  -1
    order_0_12  connected_order_arc_669  -1
    order_0_12  connected_order_arc_671  -1
    order_0_12  connected_order_arc_673  -1
    order_0_12  connected_order_arc_675  -1
    order_0_12  connected_order_arc_677  -1
    order_0_12  connected_order_arc_679  -1
    order_0_12  connected_order_arc_681  -1
    order_0_12  connected_order_arc_683  -1
    order_0_12  connected_order_arc_685  -1
    order_0_12  connected_order_arc_687  -1
    order_0_12  connected_order_arc_689  -1
    order_0_12  connected_order_arc_691  -1
    order_0_12  connected_order_arc_714  1
    order_0_12  connected_order_arc_741  1
    order_0_12  connected_order_arc_768  1
    order_0_12  order_active_lb_843  1
    order_0_12  order_active_ub_844  1
    visit_0_13  out_degree_847  -1
    visit_0_13  in_degree_848  -1
    visit_0_13  order_active_lb_849  -1
    visit_0_13  order_active_ub_850  -14
    visit_0_13  service_visit_def_851  -1
    order_0_13  connected_order_arc_417  1
    order_0_13  connected_order_arc_444  1
    order_0_13  connected_order_arc_471  1
    order_0_13  connected_order_arc_498  1
    order_0_13  connected_order_arc_525  1
    order_0_13  connected_order_arc_552  1
    order_0_13  connected_order_arc_579  1
    order_0_13  connected_order_arc_606  1
    order_0_13  connected_order_arc_633  1
    order_0_13  connected_order_arc_660  1
    order_0_13  connected_order_arc_687  1
    order_0_13  connected_order_arc_694  -1
    order_0_13  connected_order_arc_696  -1
    order_0_13  connected_order_arc_698  -1
    order_0_13  connected_order_arc_700  -1
    order_0_13  connected_order_arc_702  -1
    order_0_13  connected_order_arc_704  -1
    order_0_13  connected_order_arc_706  -1
    order_0_13  connected_order_arc_708  -1
    order_0_13  connected_order_arc_710  -1
    order_0_13  connected_order_arc_712  -1
    order_0_13  connected_order_arc_714  -1
    order_0_13  connected_order_arc_716  -1
    order_0_13  connected_order_arc_718  -1
    order_0_13  connected_order_arc_743  1
    order_0_13  connected_order_arc_770  1
    order_0_13  order_active_lb_849  1
    order_0_13  order_active_ub_850  1
    visit_0_14  out_degree_853  -1
    visit_0_14  in_degree_854  -1
    visit_0_14  order_active_lb_855  -1
    visit_0_14  order_active_ub_856  -14
    visit_0_14  service_visit_def_857  -1
    order_0_14  connected_order_arc_419  1
    order_0_14  connected_order_arc_446  1
    order_0_14  connected_order_arc_473  1
    order_0_14  connected_order_arc_500  1
    order_0_14  connected_order_arc_527  1
    order_0_14  connected_order_arc_554  1
    order_0_14  connected_order_arc_581  1
    order_0_14  connected_order_arc_608  1
    order_0_14  connected_order_arc_635  1
    order_0_14  connected_order_arc_662  1
    order_0_14  connected_order_arc_689  1
    order_0_14  connected_order_arc_716  1
    order_0_14  connected_order_arc_721  -1
    order_0_14  connected_order_arc_723  -1
    order_0_14  connected_order_arc_725  -1
    order_0_14  connected_order_arc_727  -1
    order_0_14  connected_order_arc_729  -1
    order_0_14  connected_order_arc_731  -1
    order_0_14  connected_order_arc_733  -1
    order_0_14  connected_order_arc_735  -1
    order_0_14  connected_order_arc_737  -1
    order_0_14  connected_order_arc_739  -1
    order_0_14  connected_order_arc_741  -1
    order_0_14  connected_order_arc_743  -1
    order_0_14  connected_order_arc_745  -1
    order_0_14  connected_order_arc_772  1
    order_0_14  order_active_lb_855  1
    order_0_14  order_active_ub_856  1
    visit_0_15  out_degree_859  -1
    visit_0_15  in_degree_860  -1
    visit_0_15  order_active_lb_861  -1
    visit_0_15  order_active_ub_862  -14
    visit_0_15  service_visit_def_863  -1
    order_0_15  connected_order_arc_421  1
    order_0_15  connected_order_arc_448  1
    order_0_15  connected_order_arc_475  1
    order_0_15  connected_order_arc_502  1
    order_0_15  connected_order_arc_529  1
    order_0_15  connected_order_arc_556  1
    order_0_15  connected_order_arc_583  1
    order_0_15  connected_order_arc_610  1
    order_0_15  connected_order_arc_637  1
    order_0_15  connected_order_arc_664  1
    order_0_15  connected_order_arc_691  1
    order_0_15  connected_order_arc_718  1
    order_0_15  connected_order_arc_745  1
    order_0_15  connected_order_arc_748  -1
    order_0_15  connected_order_arc_750  -1
    order_0_15  connected_order_arc_752  -1
    order_0_15  connected_order_arc_754  -1
    order_0_15  connected_order_arc_756  -1
    order_0_15  connected_order_arc_758  -1
    order_0_15  connected_order_arc_760  -1
    order_0_15  connected_order_arc_762  -1
    order_0_15  connected_order_arc_764  -1
    order_0_15  connected_order_arc_766  -1
    order_0_15  connected_order_arc_768  -1
    order_0_15  connected_order_arc_770  -1
    order_0_15  connected_order_arc_772  -1
    order_0_15  order_active_lb_861  1
    order_0_15  order_active_ub_862  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_0  arc_capacity_380  -30
    arc_0_0_0  depot_departure_or_bypass_773  1
    arc_0_0_0  depot_return_or_bypass_774  1
    MARKER    'MARKER'                 'INTEND'
    load_0_0_0  arc_capacity_380  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_1  arc_capacity_381  -30
    arc_0_0_1  depot_departure_or_bypass_773  1
    arc_0_0_1  in_degree_776  1
    arc_0_0_1  original_T_including_depot_unload_870  8.2548955430739034e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_1  arc_capacity_381  1
    load_0_0_1  segment_load_conservation_779  -1
    load_0_0_1  segment_prefix_lb_780  1
    load_0_0_1  segment_prefix_ub_781  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_2  arc_capacity_382  -30
    arc_0_0_2  depot_departure_or_bypass_773  1
    arc_0_0_2  in_degree_783  1
    arc_0_0_2  original_T_including_depot_unload_870  1.1473865007565566e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_2  arc_capacity_382  1
    load_0_0_2  segment_load_conservation_786  -1
    load_0_0_2  segment_prefix_lb_787  1
    load_0_0_2  segment_prefix_ub_788  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_3  arc_capacity_383  -30
    arc_0_0_3  depot_departure_or_bypass_773  1
    arc_0_0_3  in_degree_790  1
    arc_0_0_3  original_T_including_depot_unload_870  1.2186896810212775e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_3  arc_capacity_383  1
    load_0_0_3  segment_load_conservation_793  -1
    load_0_0_3  segment_prefix_lb_794  1
    load_0_0_3  segment_prefix_ub_795  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_4  arc_capacity_384  -30
    arc_0_0_4  depot_departure_or_bypass_773  1
    arc_0_0_4  in_degree_797  1
    arc_0_0_4  original_T_including_depot_unload_870  9.3659929340140741e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_4  arc_capacity_384  1
    load_0_0_4  segment_load_conservation_800  -1
    load_0_0_4  segment_prefix_lb_801  1
    load_0_0_4  segment_prefix_ub_802  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_5  arc_capacity_385  -30
    arc_0_0_5  depot_departure_or_bypass_773  1
    arc_0_0_5  in_degree_804  1
    arc_0_0_5  original_T_including_depot_unload_870  7.4412496590753551e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_5  arc_capacity_385  1
    load_0_0_5  segment_load_conservation_807  -1
    load_0_0_5  segment_prefix_lb_808  1
    load_0_0_5  segment_prefix_ub_809  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_6  arc_capacity_386  -30
    arc_0_0_6  depot_departure_or_bypass_773  1
    arc_0_0_6  in_degree_811  1
    arc_0_0_6  original_T_including_depot_unload_870  5.9631731642067359e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_6  arc_capacity_386  1
    load_0_0_6  segment_load_conservation_814  -1
    load_0_0_6  segment_prefix_lb_815  1
    load_0_0_6  segment_prefix_ub_816  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_8  arc_capacity_387  -30
    arc_0_0_8  depot_departure_or_bypass_773  1
    arc_0_0_8  in_degree_818  1
    arc_0_0_8  original_T_including_depot_unload_870  2.2866763971369810e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_8  arc_capacity_387  1
    load_0_0_8  free_load_conservation_822  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_9  arc_capacity_388  -30
    arc_0_0_9  depot_departure_or_bypass_773  1
    arc_0_0_9  in_degree_824  1
    arc_0_0_9  original_T_including_depot_unload_870  1.8065333212349267e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_9  arc_capacity_388  1
    load_0_0_9  free_load_conservation_828  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_10  arc_capacity_389  -30
    arc_0_0_10  depot_departure_or_bypass_773  1
    arc_0_0_10  in_degree_830  1
    arc_0_0_10  original_T_including_depot_unload_870  2.3234267380118886e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_10  arc_capacity_389  1
    load_0_0_10  free_load_conservation_834  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_11  arc_capacity_390  -30
    arc_0_0_11  depot_departure_or_bypass_773  1
    arc_0_0_11  in_degree_836  1
    arc_0_0_11  original_T_including_depot_unload_870  1739.61165920636
    MARKER    'MARKER'                 'INTEND'
    load_0_0_11  arc_capacity_390  1
    load_0_0_11  free_load_conservation_840  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_12  arc_capacity_391  -30
    arc_0_0_12  depot_departure_or_bypass_773  1
    arc_0_0_12  in_degree_842  1
    arc_0_0_12  original_T_including_depot_unload_870  2.0232971184291544e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_12  arc_capacity_391  1
    load_0_0_12  free_load_conservation_846  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_13  arc_capacity_392  -30
    arc_0_0_13  depot_departure_or_bypass_773  1
    arc_0_0_13  in_degree_848  1
    arc_0_0_13  original_T_including_depot_unload_870  3.5937232665424995e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_13  arc_capacity_392  1
    load_0_0_13  free_load_conservation_852  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_14  arc_capacity_393  -30
    arc_0_0_14  depot_departure_or_bypass_773  1
    arc_0_0_14  in_degree_854  1
    arc_0_0_14  original_T_including_depot_unload_870  4.0782796387128610e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_14  arc_capacity_393  1
    load_0_0_14  free_load_conservation_858  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_15  arc_capacity_394  -30
    arc_0_0_15  depot_departure_or_bypass_773  1
    arc_0_0_15  in_degree_860  1
    arc_0_0_15  original_T_including_depot_unload_870  5.2774046204590661e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_15  arc_capacity_394  1
    load_0_0_15  free_load_conservation_864  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_0  arc_capacity_395  -30
    arc_0_1_0  depot_return_or_bypass_774  1
    arc_0_1_0  out_degree_775  1
    arc_0_1_0  original_T_including_depot_unload_870  8.2548955430739034e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_0  arc_capacity_395  1
    load_0_1_0  segment_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_2  arc_capacity_396  -30
    arc_0_1_2  connected_order_arc_397  -15
    arc_0_1_2  out_degree_775  1
    arc_0_1_2  in_degree_783  1
    arc_0_1_2  original_T_including_depot_unload_870  3.7295617536174859e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_2  arc_capacity_396  1
    load_0_1_2  segment_load_conservation_779  1
    load_0_1_2  segment_load_conservation_786  -1
    load_0_1_2  segment_prefix_lb_787  1
    load_0_1_2  segment_prefix_ub_788  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_3  arc_capacity_398  -30
    arc_0_1_3  connected_order_arc_399  -15
    arc_0_1_3  out_degree_775  1
    arc_0_1_3  in_degree_790  1
    arc_0_1_3  original_T_including_depot_unload_870  4.3124580937307496e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_3  arc_capacity_398  1
    load_0_1_3  segment_load_conservation_779  1
    load_0_1_3  segment_load_conservation_793  -1
    load_0_1_3  segment_prefix_lb_794  1
    load_0_1_3  segment_prefix_ub_795  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_4  arc_capacity_400  -30
    arc_0_1_4  connected_order_arc_401  -15
    arc_0_1_4  out_degree_775  1
    arc_0_1_4  in_degree_797  1
    arc_0_1_4  original_T_including_depot_unload_870  2.0241950709354862e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_4  arc_capacity_400  1
    load_0_1_4  segment_load_conservation_779  1
    load_0_1_4  segment_load_conservation_800  -1
    load_0_1_4  segment_prefix_lb_801  1
    load_0_1_4  segment_prefix_ub_802  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_5  arc_capacity_402  -30
    arc_0_1_5  connected_order_arc_403  -15
    arc_0_1_5  out_degree_775  1
    arc_0_1_5  in_degree_804  1
    arc_0_1_5  original_T_including_depot_unload_870  1.2673640125672841e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_5  arc_capacity_402  1
    load_0_1_5  segment_load_conservation_779  1
    load_0_1_5  segment_load_conservation_807  -1
    load_0_1_5  segment_prefix_lb_808  1
    load_0_1_5  segment_prefix_ub_809  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_6  arc_capacity_404  -30
    arc_0_1_6  connected_order_arc_405  -15
    arc_0_1_6  out_degree_775  1
    arc_0_1_6  in_degree_811  1
    arc_0_1_6  original_T_including_depot_unload_870  2.6991456262177837e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_6  arc_capacity_404  1
    load_0_1_6  segment_load_conservation_779  1
    load_0_1_6  segment_load_conservation_814  -1
    load_0_1_6  segment_prefix_lb_815  1
    load_0_1_6  segment_prefix_ub_816  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_8  arc_capacity_406  -30
    arc_0_1_8  connected_order_arc_407  -15
    arc_0_1_8  out_degree_775  1
    arc_0_1_8  in_degree_818  1
    arc_0_1_8  original_T_including_depot_unload_870  2.6235983504802839e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_8  arc_capacity_406  1
    load_0_1_8  segment_load_conservation_779  1
    load_0_1_8  free_load_conservation_822  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_9  arc_capacity_408  -30
    arc_0_1_9  connected_order_arc_409  -15
    arc_0_1_9  out_degree_775  1
    arc_0_1_9  in_degree_824  1
    arc_0_1_9  original_T_including_depot_unload_870  2.0979901720969542e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_9  arc_capacity_408  1
    load_0_1_9  segment_load_conservation_779  1
    load_0_1_9  free_load_conservation_828  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_10  arc_capacity_410  -30
    arc_0_1_10  connected_order_arc_411  -15
    arc_0_1_10  out_degree_775  1
    arc_0_1_10  in_degree_830  1
    arc_0_1_10  original_T_including_depot_unload_870  2.8834086639088187e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_10  arc_capacity_410  1
    load_0_1_10  segment_load_conservation_779  1
    load_0_1_10  free_load_conservation_834  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_11  arc_capacity_412  -30
    arc_0_1_11  connected_order_arc_413  -15
    arc_0_1_11  out_degree_775  1
    arc_0_1_11  in_degree_836  1
    arc_0_1_11  original_T_including_depot_unload_870  2.0801782775431307e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_11  arc_capacity_412  1
    load_0_1_11  segment_load_conservation_779  1
    load_0_1_11  free_load_conservation_840  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_12  arc_capacity_414  -30
    arc_0_1_12  connected_order_arc_415  -15
    arc_0_1_12  out_degree_775  1
    arc_0_1_12  in_degree_842  1
    arc_0_1_12  original_T_including_depot_unload_870  2820.94140713384
    MARKER    'MARKER'                 'INTEND'
    load_0_1_12  arc_capacity_414  1
    load_0_1_12  segment_load_conservation_779  1
    load_0_1_12  free_load_conservation_846  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_13  arc_capacity_416  -30
    arc_0_1_13  connected_order_arc_417  -15
    arc_0_1_13  out_degree_775  1
    arc_0_1_13  in_degree_848  1
    arc_0_1_13  original_T_including_depot_unload_870  1.1046832181240914e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_13  arc_capacity_416  1
    load_0_1_13  segment_load_conservation_779  1
    load_0_1_13  free_load_conservation_852  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_14  arc_capacity_418  -30
    arc_0_1_14  connected_order_arc_419  -15
    arc_0_1_14  out_degree_775  1
    arc_0_1_14  in_degree_854  1
    arc_0_1_14  original_T_including_depot_unload_870  4.6739130846957909e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_14  arc_capacity_418  1
    load_0_1_14  segment_load_conservation_779  1
    load_0_1_14  free_load_conservation_858  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_15  arc_capacity_420  -30
    arc_0_1_15  connected_order_arc_421  -15
    arc_0_1_15  out_degree_775  1
    arc_0_1_15  in_degree_860  1
    arc_0_1_15  original_T_including_depot_unload_870  4.1346687597344868e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_15  arc_capacity_420  1
    load_0_1_15  segment_load_conservation_779  1
    load_0_1_15  free_load_conservation_864  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_0  arc_capacity_422  -30
    arc_0_2_0  depot_return_or_bypass_774  1
    arc_0_2_0  out_degree_782  1
    arc_0_2_0  original_T_including_depot_unload_870  1.1473865007565566e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_0  arc_capacity_422  1
    load_0_2_0  segment_load_conservation_786  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_1  arc_capacity_423  -30
    arc_0_2_1  connected_order_arc_424  -15
    arc_0_2_1  in_degree_776  1
    arc_0_2_1  out_degree_782  1
    arc_0_2_1  original_T_including_depot_unload_870  3.7295617536174859e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_1  arc_capacity_423  1
    load_0_2_1  segment_load_conservation_779  -1
    load_0_2_1  segment_prefix_lb_780  1
    load_0_2_1  segment_prefix_ub_781  1
    load_0_2_1  segment_load_conservation_786  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_3  arc_capacity_425  -30
    arc_0_2_3  connected_order_arc_426  -15
    arc_0_2_3  out_degree_782  1
    arc_0_2_3  in_degree_790  1
    arc_0_2_3  original_T_including_depot_unload_870  4.4158457011124148e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_3  arc_capacity_425  1
    load_0_2_3  segment_load_conservation_786  1
    load_0_2_3  segment_load_conservation_793  -1
    load_0_2_3  segment_prefix_lb_794  1
    load_0_2_3  segment_prefix_ub_795  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_4  arc_capacity_427  -30
    arc_0_2_4  connected_order_arc_428  -15
    arc_0_2_4  out_degree_782  1
    arc_0_2_4  in_degree_797  1
    arc_0_2_4  original_T_including_depot_unload_870  4.5058965368847572e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_4  arc_capacity_427  1
    load_0_2_4  segment_load_conservation_786  1
    load_0_2_4  segment_load_conservation_800  -1
    load_0_2_4  segment_prefix_lb_801  1
    load_0_2_4  segment_prefix_ub_802  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_5  arc_capacity_429  -30
    arc_0_2_5  connected_order_arc_430  -15
    arc_0_2_5  out_degree_782  1
    arc_0_2_5  in_degree_804  1
    arc_0_2_5  original_T_including_depot_unload_870  4.9817963927689311e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_5  arc_capacity_429  1
    load_0_2_5  segment_load_conservation_786  1
    load_0_2_5  segment_load_conservation_807  -1
    load_0_2_5  segment_prefix_lb_808  1
    load_0_2_5  segment_prefix_ub_809  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_6  arc_capacity_431  -30
    arc_0_2_6  connected_order_arc_432  -15
    arc_0_2_6  out_degree_782  1
    arc_0_2_6  in_degree_811  1
    arc_0_2_6  original_T_including_depot_unload_870  6.4057623819624155e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_6  arc_capacity_431  1
    load_0_2_6  segment_load_conservation_786  1
    load_0_2_6  segment_load_conservation_814  -1
    load_0_2_6  segment_prefix_lb_815  1
    load_0_2_6  segment_prefix_ub_816  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_8  arc_capacity_433  -30
    arc_0_2_8  connected_order_arc_434  -15
    arc_0_2_8  out_degree_782  1
    arc_0_2_8  in_degree_818  1
    arc_0_2_8  original_T_including_depot_unload_870  2.9747397208089205e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_8  arc_capacity_433  1
    load_0_2_8  segment_load_conservation_786  1
    load_0_2_8  free_load_conservation_822  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_9  arc_capacity_435  -30
    arc_0_2_9  connected_order_arc_436  -15
    arc_0_2_9  out_degree_782  1
    arc_0_2_9  in_degree_824  1
    arc_0_2_9  original_T_including_depot_unload_870  2.4478438645146789e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_9  arc_capacity_435  1
    load_0_2_9  segment_load_conservation_786  1
    load_0_2_9  free_load_conservation_828  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_10  arc_capacity_437  -30
    arc_0_2_10  connected_order_arc_438  -15
    arc_0_2_10  out_degree_782  1
    arc_0_2_10  in_degree_830  1
    arc_0_2_10  original_T_including_depot_unload_870  2.9878665461125843e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_10  arc_capacity_437  1
    load_0_2_10  segment_load_conservation_786  1
    load_0_2_10  free_load_conservation_834  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_11  arc_capacity_439  -30
    arc_0_2_11  connected_order_arc_440  -15
    arc_0_2_11  out_degree_782  1
    arc_0_2_11  in_degree_836  1
    arc_0_2_11  original_T_including_depot_unload_870  2.4369093744670904e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_11  arc_capacity_439  1
    load_0_2_11  segment_load_conservation_786  1
    load_0_2_11  free_load_conservation_840  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_12  arc_capacity_441  -30
    arc_0_2_12  connected_order_arc_442  -15
    arc_0_2_12  out_degree_782  1
    arc_0_2_12  in_degree_842  1
    arc_0_2_12  original_T_including_depot_unload_870  3.1658582590062310e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_12  arc_capacity_441  1
    load_0_2_12  segment_load_conservation_786  1
    load_0_2_12  free_load_conservation_846  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_13  arc_capacity_443  -30
    arc_0_2_13  connected_order_arc_444  -15
    arc_0_2_13  out_degree_782  1
    arc_0_2_13  in_degree_848  1
    arc_0_2_13  original_T_including_depot_unload_870  1.4558134627196880e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_13  arc_capacity_443  1
    load_0_2_13  segment_load_conservation_786  1
    load_0_2_13  free_load_conservation_852  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_14  arc_capacity_445  -30
    arc_0_2_14  connected_order_arc_446  -15
    arc_0_2_14  out_degree_782  1
    arc_0_2_14  in_degree_854  1
    arc_0_2_14  original_T_including_depot_unload_870  8.2982882938703278e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_14  arc_capacity_445  1
    load_0_2_14  segment_load_conservation_786  1
    load_0_2_14  free_load_conservation_858  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_15  arc_capacity_447  -30
    arc_0_2_15  connected_order_arc_448  -15
    arc_0_2_15  out_degree_782  1
    arc_0_2_15  in_degree_860  1
    arc_0_2_15  original_T_including_depot_unload_870  7.8604521666483390e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_15  arc_capacity_447  1
    load_0_2_15  segment_load_conservation_786  1
    load_0_2_15  free_load_conservation_864  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_0  arc_capacity_449  -30
    arc_0_3_0  depot_return_or_bypass_774  1
    arc_0_3_0  out_degree_789  1
    arc_0_3_0  original_T_including_depot_unload_870  1.2186896810212775e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_0  arc_capacity_449  1
    load_0_3_0  segment_load_conservation_793  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_1  arc_capacity_450  -30
    arc_0_3_1  connected_order_arc_451  -15
    arc_0_3_1  in_degree_776  1
    arc_0_3_1  out_degree_789  1
    arc_0_3_1  original_T_including_depot_unload_870  4.3124580937307496e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_1  arc_capacity_450  1
    load_0_3_1  segment_load_conservation_779  -1
    load_0_3_1  segment_prefix_lb_780  1
    load_0_3_1  segment_prefix_ub_781  1
    load_0_3_1  segment_load_conservation_793  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_2  arc_capacity_452  -30
    arc_0_3_2  connected_order_arc_453  -15
    arc_0_3_2  in_degree_783  1
    arc_0_3_2  out_degree_789  1
    arc_0_3_2  original_T_including_depot_unload_870  4.4158457011124148e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_2  arc_capacity_452  1
    load_0_3_2  segment_load_conservation_786  -1
    load_0_3_2  segment_prefix_lb_787  1
    load_0_3_2  segment_prefix_ub_788  1
    load_0_3_2  segment_load_conservation_793  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_4  arc_capacity_454  -30
    arc_0_3_4  connected_order_arc_455  -15
    arc_0_3_4  out_degree_789  1
    arc_0_3_4  in_degree_797  1
    arc_0_3_4  original_T_including_depot_unload_870  2.8260257937815851e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_4  arc_capacity_454  1
    load_0_3_4  segment_load_conservation_793  1
    load_0_3_4  segment_load_conservation_800  -1
    load_0_3_4  segment_prefix_lb_801  1
    load_0_3_4  segment_prefix_ub_802  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_5  arc_capacity_456  -30
    arc_0_3_5  connected_order_arc_457  -15
    arc_0_3_5  out_degree_789  1
    arc_0_3_5  in_degree_804  1
    arc_0_3_5  original_T_including_depot_unload_870  4.7721499161748335e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_5  arc_capacity_456  1
    load_0_3_5  segment_load_conservation_793  1
    load_0_3_5  segment_load_conservation_807  -1
    load_0_3_5  segment_prefix_lb_808  1
    load_0_3_5  segment_prefix_ub_809  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_6  arc_capacity_458  -30
    arc_0_3_6  connected_order_arc_459  -15
    arc_0_3_6  out_degree_789  1
    arc_0_3_6  in_degree_811  1
    arc_0_3_6  original_T_including_depot_unload_870  6.2279118029742506e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_6  arc_capacity_458  1
    load_0_3_6  segment_load_conservation_793  1
    load_0_3_6  segment_load_conservation_814  -1
    load_0_3_6  segment_prefix_lb_815  1
    load_0_3_6  segment_prefix_ub_816  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_8  arc_capacity_460  -30
    arc_0_3_8  connected_order_arc_461  -15
    arc_0_3_8  out_degree_789  1
    arc_0_3_8  in_degree_818  1
    arc_0_3_8  original_T_including_depot_unload_870  2.6797194604092651e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_8  arc_capacity_460  1
    load_0_3_8  segment_load_conservation_793  1
    load_0_3_8  free_load_conservation_822  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_9  arc_capacity_462  -30
    arc_0_3_9  connected_order_arc_463  -15
    arc_0_3_9  out_degree_789  1
    arc_0_3_9  in_degree_824  1
    arc_0_3_9  original_T_including_depot_unload_870  2.1556817566230284e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_9  arc_capacity_462  1
    load_0_3_9  segment_load_conservation_793  1
    load_0_3_9  free_load_conservation_828  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_10  arc_capacity_464  -30
    arc_0_3_10  connected_order_arc_465  -15
    arc_0_3_10  out_degree_789  1
    arc_0_3_10  in_degree_830  1
    arc_0_3_10  original_T_including_depot_unload_870  3.3076115257178203e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_10  arc_capacity_464  1
    load_0_3_10  segment_load_conservation_793  1
    load_0_3_10  free_load_conservation_834  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_11  arc_capacity_466  -30
    arc_0_3_11  connected_order_arc_467  -15
    arc_0_3_11  out_degree_789  1
    arc_0_3_11  in_degree_836  1
    arc_0_3_11  original_T_including_depot_unload_870  2.1641391312462424e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_11  arc_capacity_466  1
    load_0_3_11  segment_load_conservation_793  1
    load_0_3_11  free_load_conservation_840  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_12  arc_capacity_468  -30
    arc_0_3_12  connected_order_arc_469  -15
    arc_0_3_12  out_degree_789  1
    arc_0_3_12  in_degree_842  1
    arc_0_3_12  original_T_including_depot_unload_870  3.1528795137337825e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_12  arc_capacity_468  1
    load_0_3_12  segment_load_conservation_793  1
    load_0_3_12  free_load_conservation_846  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_13  arc_capacity_470  -30
    arc_0_3_13  connected_order_arc_471  -15
    arc_0_3_13  out_degree_789  1
    arc_0_3_13  in_degree_848  1
    arc_0_3_13  original_T_including_depot_unload_870  1.4485896981484648e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_13  arc_capacity_470  1
    load_0_3_13  segment_load_conservation_793  1
    load_0_3_13  free_load_conservation_852  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_14  arc_capacity_472  -30
    arc_0_3_14  connected_order_arc_473  -15
    arc_0_3_14  out_degree_789  1
    arc_0_3_14  in_degree_854  1
    arc_0_3_14  original_T_including_depot_unload_870  8.2145202724109538e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_14  arc_capacity_472  1
    load_0_3_14  segment_load_conservation_793  1
    load_0_3_14  free_load_conservation_858  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_15  arc_capacity_474  -30
    arc_0_3_15  connected_order_arc_475  -15
    arc_0_3_15  out_degree_789  1
    arc_0_3_15  in_degree_860  1
    arc_0_3_15  original_T_including_depot_unload_870  7.2186296856879846e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_15  arc_capacity_474  1
    load_0_3_15  segment_load_conservation_793  1
    load_0_3_15  free_load_conservation_864  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_0  arc_capacity_476  -30
    arc_0_4_0  depot_return_or_bypass_774  1
    arc_0_4_0  out_degree_796  1
    arc_0_4_0  original_T_including_depot_unload_870  9.3659929340140741e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_0  arc_capacity_476  1
    load_0_4_0  segment_load_conservation_800  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_1  arc_capacity_477  -30
    arc_0_4_1  connected_order_arc_478  -15
    arc_0_4_1  in_degree_776  1
    arc_0_4_1  out_degree_796  1
    arc_0_4_1  original_T_including_depot_unload_870  2.0241950709354862e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_1  arc_capacity_477  1
    load_0_4_1  segment_load_conservation_779  -1
    load_0_4_1  segment_prefix_lb_780  1
    load_0_4_1  segment_prefix_ub_781  1
    load_0_4_1  segment_load_conservation_800  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_2  arc_capacity_479  -30
    arc_0_4_2  connected_order_arc_480  -15
    arc_0_4_2  in_degree_783  1
    arc_0_4_2  out_degree_796  1
    arc_0_4_2  original_T_including_depot_unload_870  4.5058965368847572e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_2  arc_capacity_479  1
    load_0_4_2  segment_load_conservation_786  -1
    load_0_4_2  segment_prefix_lb_787  1
    load_0_4_2  segment_prefix_ub_788  1
    load_0_4_2  segment_load_conservation_800  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_3  arc_capacity_481  -30
    arc_0_4_3  connected_order_arc_482  -15
    arc_0_4_3  in_degree_790  1
    arc_0_4_3  out_degree_796  1
    arc_0_4_3  original_T_including_depot_unload_870  2.8260257937815851e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_3  arc_capacity_481  1
    load_0_4_3  segment_load_conservation_793  -1
    load_0_4_3  segment_prefix_lb_794  1
    load_0_4_3  segment_prefix_ub_795  1
    load_0_4_3  segment_load_conservation_800  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_5  arc_capacity_483  -30
    arc_0_4_5  connected_order_arc_484  -15
    arc_0_4_5  out_degree_796  1
    arc_0_4_5  in_degree_804  1
    arc_0_4_5  original_T_including_depot_unload_870  2.0082608212298291e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_5  arc_capacity_483  1
    load_0_4_5  segment_load_conservation_800  1
    load_0_4_5  segment_load_conservation_807  -1
    load_0_4_5  segment_prefix_lb_808  1
    load_0_4_5  segment_prefix_ub_809  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_6  arc_capacity_485  -30
    arc_0_4_6  connected_order_arc_486  -15
    arc_0_4_6  out_degree_796  1
    arc_0_4_6  in_degree_811  1
    arc_0_4_6  original_T_including_depot_unload_870  3.4037893208114895e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_6  arc_capacity_485  1
    load_0_4_6  segment_load_conservation_800  1
    load_0_4_6  segment_load_conservation_814  -1
    load_0_4_6  segment_prefix_lb_815  1
    load_0_4_6  segment_prefix_ub_816  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_8  arc_capacity_487  -30
    arc_0_4_8  connected_order_arc_488  -15
    arc_0_4_8  out_degree_796  1
    arc_0_4_8  in_degree_818  1
    arc_0_4_8  original_T_including_depot_unload_870  2.5292035468949002e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_8  arc_capacity_487  1
    load_0_4_8  segment_load_conservation_800  1
    load_0_4_8  free_load_conservation_822  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_9  arc_capacity_489  -30
    arc_0_4_9  connected_order_arc_490  -15
    arc_0_4_9  out_degree_796  1
    arc_0_4_9  in_degree_824  1
    arc_0_4_9  original_T_including_depot_unload_870  2.0021738809925773e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_9  arc_capacity_489  1
    load_0_4_9  segment_load_conservation_800  1
    load_0_4_9  free_load_conservation_828  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_10  arc_capacity_491  -30
    arc_0_4_10  connected_order_arc_492  -15
    arc_0_4_10  out_degree_796  1
    arc_0_4_10  in_degree_830  1
    arc_0_4_10  original_T_including_depot_unload_870  3.0726580305165480e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_10  arc_capacity_491  1
    load_0_4_10  segment_load_conservation_800  1
    load_0_4_10  free_load_conservation_834  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_11  arc_capacity_493  -30
    arc_0_4_11  connected_order_arc_494  -15
    arc_0_4_11  out_degree_796  1
    arc_0_4_11  in_degree_836  1
    arc_0_4_11  original_T_including_depot_unload_870  1.9959569014367933e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_11  arc_capacity_493  1
    load_0_4_11  segment_load_conservation_800  1
    load_0_4_11  free_load_conservation_840  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_12  arc_capacity_495  -30
    arc_0_4_12  connected_order_arc_496  -15
    arc_0_4_12  out_degree_796  1
    arc_0_4_12  in_degree_842  1
    arc_0_4_12  original_T_including_depot_unload_870  2.8800138602390562e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_12  arc_capacity_495  1
    load_0_4_12  segment_load_conservation_800  1
    load_0_4_12  free_load_conservation_846  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_13  arc_capacity_497  -30
    arc_0_4_13  connected_order_arc_498  -15
    arc_0_4_13  out_degree_796  1
    arc_0_4_13  in_degree_848  1
    arc_0_4_13  original_T_including_depot_unload_870  1.1702148343313254e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_13  arc_capacity_497  1
    load_0_4_13  segment_load_conservation_800  1
    load_0_4_13  free_load_conservation_852  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_14  arc_capacity_499  -30
    arc_0_4_14  connected_order_arc_500  -15
    arc_0_4_14  out_degree_796  1
    arc_0_4_14  in_degree_854  1
    arc_0_4_14  original_T_including_depot_unload_870  5.3918604589472477e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_14  arc_capacity_499  1
    load_0_4_14  segment_load_conservation_800  1
    load_0_4_14  free_load_conservation_858  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_15  arc_capacity_501  -30
    arc_0_4_15  connected_order_arc_502  -15
    arc_0_4_15  out_degree_796  1
    arc_0_4_15  in_degree_860  1
    arc_0_4_15  original_T_including_depot_unload_870  4.4360641393992279e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_15  arc_capacity_501  1
    load_0_4_15  segment_load_conservation_800  1
    load_0_4_15  free_load_conservation_864  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_0  arc_capacity_503  -30
    arc_0_5_0  depot_return_or_bypass_774  1
    arc_0_5_0  out_degree_803  1
    arc_0_5_0  original_T_including_depot_unload_870  7.4412496590753551e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_0  arc_capacity_503  1
    load_0_5_0  segment_load_conservation_807  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_1  arc_capacity_504  -30
    arc_0_5_1  connected_order_arc_505  -15
    arc_0_5_1  in_degree_776  1
    arc_0_5_1  out_degree_803  1
    arc_0_5_1  original_T_including_depot_unload_870  1.2673640125672841e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_1  arc_capacity_504  1
    load_0_5_1  segment_load_conservation_779  -1
    load_0_5_1  segment_prefix_lb_780  1
    load_0_5_1  segment_prefix_ub_781  1
    load_0_5_1  segment_load_conservation_807  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_2  arc_capacity_506  -30
    arc_0_5_2  connected_order_arc_507  -15
    arc_0_5_2  in_degree_783  1
    arc_0_5_2  out_degree_803  1
    arc_0_5_2  original_T_including_depot_unload_870  4.9817963927689311e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_2  arc_capacity_506  1
    load_0_5_2  segment_load_conservation_786  -1
    load_0_5_2  segment_prefix_lb_787  1
    load_0_5_2  segment_prefix_ub_788  1
    load_0_5_2  segment_load_conservation_807  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_3  arc_capacity_508  -30
    arc_0_5_3  connected_order_arc_509  -15
    arc_0_5_3  in_degree_790  1
    arc_0_5_3  out_degree_803  1
    arc_0_5_3  original_T_including_depot_unload_870  4.7721499161748335e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_3  arc_capacity_508  1
    load_0_5_3  segment_load_conservation_793  -1
    load_0_5_3  segment_prefix_lb_794  1
    load_0_5_3  segment_prefix_ub_795  1
    load_0_5_3  segment_load_conservation_807  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_4  arc_capacity_510  -30
    arc_0_5_4  connected_order_arc_511  -15
    arc_0_5_4  in_degree_797  1
    arc_0_5_4  out_degree_803  1
    arc_0_5_4  original_T_including_depot_unload_870  2.0082608212298291e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_4  arc_capacity_510  1
    load_0_5_4  segment_load_conservation_800  -1
    load_0_5_4  segment_prefix_lb_801  1
    load_0_5_4  segment_prefix_ub_802  1
    load_0_5_4  segment_load_conservation_807  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_6  arc_capacity_512  -30
    arc_0_5_6  connected_order_arc_513  -15
    arc_0_5_6  out_degree_803  1
    arc_0_5_6  in_degree_811  1
    arc_0_5_6  original_T_including_depot_unload_870  1.5701156446555925e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_6  arc_capacity_512  1
    load_0_5_6  segment_load_conservation_807  1
    load_0_5_6  segment_load_conservation_814  -1
    load_0_5_6  segment_prefix_lb_815  1
    load_0_5_6  segment_prefix_ub_816  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_8  arc_capacity_514  -30
    arc_0_5_8  connected_order_arc_515  -15
    arc_0_5_8  out_degree_803  1
    arc_0_5_8  in_degree_818  1
    arc_0_5_8  original_T_including_depot_unload_870  2.4992063774241742e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_8  arc_capacity_514  1
    load_0_5_8  segment_load_conservation_807  1
    load_0_5_8  free_load_conservation_822  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_9  arc_capacity_516  -30
    arc_0_5_9  connected_order_arc_517  -15
    arc_0_5_9  out_degree_803  1
    arc_0_5_9  in_degree_824  1
    arc_0_5_9  original_T_including_depot_unload_870  1.9740618091449423e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_9  arc_capacity_516  1
    load_0_5_9  segment_load_conservation_807  1
    load_0_5_9  free_load_conservation_828  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_10  arc_capacity_518  -30
    arc_0_5_10  connected_order_arc_519  -15
    arc_0_5_10  out_degree_803  1
    arc_0_5_10  in_degree_830  1
    arc_0_5_10  original_T_including_depot_unload_870  2.8807002034504962e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_10  arc_capacity_518  1
    load_0_5_10  segment_load_conservation_807  1
    load_0_5_10  free_load_conservation_834  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_11  arc_capacity_520  -30
    arc_0_5_11  connected_order_arc_521  -15
    arc_0_5_11  out_degree_803  1
    arc_0_5_11  in_degree_836  1
    arc_0_5_11  original_T_including_depot_unload_870  1.9548039027038737e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_11  arc_capacity_520  1
    load_0_5_11  segment_load_conservation_807  1
    load_0_5_11  free_load_conservation_840  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_12  arc_capacity_522  -30
    arc_0_5_12  connected_order_arc_523  -15
    arc_0_5_12  out_degree_803  1
    arc_0_5_12  in_degree_842  1
    arc_0_5_12  original_T_including_depot_unload_870  2.7168118802834592e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_12  arc_capacity_522  1
    load_0_5_12  segment_load_conservation_807  1
    load_0_5_12  free_load_conservation_846  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_13  arc_capacity_524  -30
    arc_0_5_13  connected_order_arc_525  -15
    arc_0_5_13  out_degree_803  1
    arc_0_5_13  in_degree_848  1
    arc_0_5_13  original_T_including_depot_unload_870  1.0007616644945284e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_13  arc_capacity_524  1
    load_0_5_13  segment_load_conservation_807  1
    load_0_5_13  free_load_conservation_852  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_14  arc_capacity_526  -30
    arc_0_5_14  connected_order_arc_527  -15
    arc_0_5_14  out_degree_803  1
    arc_0_5_14  in_degree_854  1
    arc_0_5_14  original_T_including_depot_unload_870  3.6114004430677619e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_14  arc_capacity_526  1
    load_0_5_14  segment_load_conservation_807  1
    load_0_5_14  free_load_conservation_858  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_15  arc_capacity_528  -30
    arc_0_5_15  connected_order_arc_529  -15
    arc_0_5_15  out_degree_803  1
    arc_0_5_15  in_degree_860  1
    arc_0_5_15  original_T_including_depot_unload_870  291.965990421835
    MARKER    'MARKER'                 'INTEND'
    load_0_5_15  arc_capacity_528  1
    load_0_5_15  segment_load_conservation_807  1
    load_0_5_15  free_load_conservation_864  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_0  arc_capacity_530  -30
    arc_0_6_0  depot_return_or_bypass_774  1
    arc_0_6_0  out_degree_810  1
    arc_0_6_0  original_T_including_depot_unload_870  5.9631731642067359e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_0  arc_capacity_530  1
    load_0_6_0  segment_load_conservation_814  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_1  arc_capacity_531  -30
    arc_0_6_1  connected_order_arc_532  -15
    arc_0_6_1  in_degree_776  1
    arc_0_6_1  out_degree_810  1
    arc_0_6_1  original_T_including_depot_unload_870  2.6991456262177837e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_1  arc_capacity_531  1
    load_0_6_1  segment_load_conservation_779  -1
    load_0_6_1  segment_prefix_lb_780  1
    load_0_6_1  segment_prefix_ub_781  1
    load_0_6_1  segment_load_conservation_814  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_2  arc_capacity_533  -30
    arc_0_6_2  connected_order_arc_534  -15
    arc_0_6_2  in_degree_783  1
    arc_0_6_2  out_degree_810  1
    arc_0_6_2  original_T_including_depot_unload_870  6.4057623819624155e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_2  arc_capacity_533  1
    load_0_6_2  segment_load_conservation_786  -1
    load_0_6_2  segment_prefix_lb_787  1
    load_0_6_2  segment_prefix_ub_788  1
    load_0_6_2  segment_load_conservation_814  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_3  arc_capacity_535  -30
    arc_0_6_3  connected_order_arc_536  -15
    arc_0_6_3  in_degree_790  1
    arc_0_6_3  out_degree_810  1
    arc_0_6_3  original_T_including_depot_unload_870  6.2279118029742506e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_3  arc_capacity_535  1
    load_0_6_3  segment_load_conservation_793  -1
    load_0_6_3  segment_prefix_lb_794  1
    load_0_6_3  segment_prefix_ub_795  1
    load_0_6_3  segment_load_conservation_814  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_4  arc_capacity_537  -30
    arc_0_6_4  connected_order_arc_538  -15
    arc_0_6_4  in_degree_797  1
    arc_0_6_4  out_degree_810  1
    arc_0_6_4  original_T_including_depot_unload_870  3.4037893208114895e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_4  arc_capacity_537  1
    load_0_6_4  segment_load_conservation_800  -1
    load_0_6_4  segment_prefix_lb_801  1
    load_0_6_4  segment_prefix_ub_802  1
    load_0_6_4  segment_load_conservation_814  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_5  arc_capacity_539  -30
    arc_0_6_5  connected_order_arc_540  -15
    arc_0_6_5  in_degree_804  1
    arc_0_6_5  out_degree_810  1
    arc_0_6_5  original_T_including_depot_unload_870  1.5701156446555925e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_5  arc_capacity_539  1
    load_0_6_5  segment_load_conservation_807  -1
    load_0_6_5  segment_prefix_lb_808  1
    load_0_6_5  segment_prefix_ub_809  1
    load_0_6_5  segment_load_conservation_814  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_8  arc_capacity_541  -30
    arc_0_6_8  connected_order_arc_542  -15
    arc_0_6_8  out_degree_810  1
    arc_0_6_8  in_degree_818  1
    arc_0_6_8  original_T_including_depot_unload_870  2.3958340327791907e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_8  arc_capacity_541  1
    load_0_6_8  segment_load_conservation_814  1
    load_0_6_8  free_load_conservation_822  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_9  arc_capacity_543  -30
    arc_0_6_9  connected_order_arc_544  -15
    arc_0_6_9  out_degree_810  1
    arc_0_6_9  in_degree_824  1
    arc_0_6_9  original_T_including_depot_unload_870  1.8739441025189553e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_9  arc_capacity_543  1
    load_0_6_9  segment_load_conservation_814  1
    load_0_6_9  free_load_conservation_828  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_10  arc_capacity_545  -30
    arc_0_6_10  connected_order_arc_546  -15
    arc_0_6_10  out_degree_810  1
    arc_0_6_10  in_degree_830  1
    arc_0_6_10  original_T_including_depot_unload_870  2.7910579461472848e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_10  arc_capacity_545  1
    load_0_6_10  segment_load_conservation_814  1
    load_0_6_10  free_load_conservation_834  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_11  arc_capacity_547  -30
    arc_0_6_11  connected_order_arc_548  -15
    arc_0_6_11  out_degree_810  1
    arc_0_6_11  in_degree_836  1
    arc_0_6_11  original_T_including_depot_unload_870  1.8467456333549035e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_11  arc_capacity_547  1
    load_0_6_11  segment_load_conservation_814  1
    load_0_6_11  free_load_conservation_840  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_12  arc_capacity_549  -30
    arc_0_6_12  connected_order_arc_550  -15
    arc_0_6_12  out_degree_810  1
    arc_0_6_12  in_degree_842  1
    arc_0_6_12  original_T_including_depot_unload_870  2.5598105628601829e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_12  arc_capacity_549  1
    load_0_6_12  segment_load_conservation_814  1
    load_0_6_12  free_load_conservation_846  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_13  arc_capacity_551  -30
    arc_0_6_13  connected_order_arc_552  -15
    arc_0_6_13  out_degree_810  1
    arc_0_6_13  in_degree_848  1
    arc_0_6_13  original_T_including_depot_unload_870  8.4376826601758887e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_13  arc_capacity_551  1
    load_0_6_13  segment_load_conservation_814  1
    load_0_6_13  free_load_conservation_852  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_14  arc_capacity_553  -30
    arc_0_6_14  connected_order_arc_554  -15
    arc_0_6_14  out_degree_810  1
    arc_0_6_14  in_degree_854  1
    arc_0_6_14  original_T_including_depot_unload_870  2.0430160967046345e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_14  arc_capacity_553  1
    load_0_6_14  segment_load_conservation_814  1
    load_0_6_14  free_load_conservation_858  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_15  arc_capacity_555  -30
    arc_0_6_15  connected_order_arc_556  -15
    arc_0_6_15  out_degree_810  1
    arc_0_6_15  in_degree_860  1
    arc_0_6_15  original_T_including_depot_unload_870  1.4810770279475858e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_15  arc_capacity_555  1
    load_0_6_15  segment_load_conservation_814  1
    load_0_6_15  free_load_conservation_864  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_0  arc_capacity_557  -30
    arc_0_8_0  depot_return_or_bypass_774  1
    arc_0_8_0  out_degree_817  1
    arc_0_8_0  original_T_including_depot_unload_870  2.2866763971369810e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_8_0  arc_capacity_557  1
    load_0_8_0  free_load_conservation_822  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_1  arc_capacity_558  -30
    arc_0_8_1  connected_order_arc_559  -15
    arc_0_8_1  in_degree_776  1
    arc_0_8_1  out_degree_817  1
    arc_0_8_1  original_T_including_depot_unload_870  2.6235983504802839e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_8_1  arc_capacity_558  1
    load_0_8_1  segment_load_conservation_779  -1
    load_0_8_1  segment_prefix_lb_780  1
    load_0_8_1  segment_prefix_ub_781  1
    load_0_8_1  free_load_conservation_822  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_2  arc_capacity_560  -30
    arc_0_8_2  connected_order_arc_561  -15
    arc_0_8_2  in_degree_783  1
    arc_0_8_2  out_degree_817  1
    arc_0_8_2  original_T_including_depot_unload_870  2.9747397208089205e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_8_2  arc_capacity_560  1
    load_0_8_2  segment_load_conservation_786  -1
    load_0_8_2  segment_prefix_lb_787  1
    load_0_8_2  segment_prefix_ub_788  1
    load_0_8_2  free_load_conservation_822  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_3  arc_capacity_562  -30
    arc_0_8_3  connected_order_arc_563  -15
    arc_0_8_3  in_degree_790  1
    arc_0_8_3  out_degree_817  1
    arc_0_8_3  original_T_including_depot_unload_870  2.6797194604092651e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_8_3  arc_capacity_562  1
    load_0_8_3  segment_load_conservation_793  -1
    load_0_8_3  segment_prefix_lb_794  1
    load_0_8_3  segment_prefix_ub_795  1
    load_0_8_3  free_load_conservation_822  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_4  arc_capacity_564  -30
    arc_0_8_4  connected_order_arc_565  -15
    arc_0_8_4  in_degree_797  1
    arc_0_8_4  out_degree_817  1
    arc_0_8_4  original_T_including_depot_unload_870  2.5292035468949002e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_8_4  arc_capacity_564  1
    load_0_8_4  segment_load_conservation_800  -1
    load_0_8_4  segment_prefix_lb_801  1
    load_0_8_4  segment_prefix_ub_802  1
    load_0_8_4  free_load_conservation_822  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_5  arc_capacity_566  -30
    arc_0_8_5  connected_order_arc_567  -15
    arc_0_8_5  in_degree_804  1
    arc_0_8_5  out_degree_817  1
    arc_0_8_5  original_T_including_depot_unload_870  2.4992063774241742e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_8_5  arc_capacity_566  1
    load_0_8_5  segment_load_conservation_807  -1
    load_0_8_5  segment_prefix_lb_808  1
    load_0_8_5  segment_prefix_ub_809  1
    load_0_8_5  free_load_conservation_822  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_6  arc_capacity_568  -30
    arc_0_8_6  connected_order_arc_569  -15
    arc_0_8_6  in_degree_811  1
    arc_0_8_6  out_degree_817  1
    arc_0_8_6  original_T_including_depot_unload_870  2.3958340327791907e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_8_6  arc_capacity_568  1
    load_0_8_6  segment_load_conservation_814  -1
    load_0_8_6  segment_prefix_lb_815  1
    load_0_8_6  segment_prefix_ub_816  1
    load_0_8_6  free_load_conservation_822  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_9  arc_capacity_570  -30
    arc_0_8_9  connected_order_arc_571  -15
    arc_0_8_9  out_degree_817  1
    arc_0_8_9  in_degree_824  1
    arc_0_8_9  original_T_including_depot_unload_870  5.2703432304351884e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_9  arc_capacity_570  1
    load_0_8_9  free_load_conservation_822  1
    load_0_8_9  free_load_conservation_828  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_10  arc_capacity_572  -30
    arc_0_8_10  connected_order_arc_573  -15
    arc_0_8_10  out_degree_817  1
    arc_0_8_10  in_degree_830  1
    arc_0_8_10  original_T_including_depot_unload_870  4.1686506413165080e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_8_10  arc_capacity_572  1
    load_0_8_10  free_load_conservation_822  1
    load_0_8_10  free_load_conservation_834  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_11  arc_capacity_574  -30
    arc_0_8_11  connected_order_arc_575  -15
    arc_0_8_11  out_degree_817  1
    arc_0_8_11  in_degree_836  1
    arc_0_8_11  original_T_including_depot_unload_870  5.5382752177930990e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_11  arc_capacity_574  1
    load_0_8_11  free_load_conservation_822  1
    load_0_8_11  free_load_conservation_840  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_12  arc_capacity_576  -30
    arc_0_8_12  connected_order_arc_577  -15
    arc_0_8_12  out_degree_817  1
    arc_0_8_12  in_degree_842  1
    arc_0_8_12  original_T_including_depot_unload_870  2.0819438297758261e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_8_12  arc_capacity_576  1
    load_0_8_12  free_load_conservation_822  1
    load_0_8_12  free_load_conservation_846  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_13  arc_capacity_578  -30
    arc_0_8_13  connected_order_arc_579  -15
    arc_0_8_13  out_degree_817  1
    arc_0_8_13  in_degree_848  1
    arc_0_8_13  original_T_including_depot_unload_870  1.9791430726365086e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_8_13  arc_capacity_578  1
    load_0_8_13  free_load_conservation_822  1
    load_0_8_13  free_load_conservation_852  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_14  arc_capacity_580  -30
    arc_0_8_14  connected_order_arc_581  -15
    arc_0_8_14  out_degree_817  1
    arc_0_8_14  in_degree_854  1
    arc_0_8_14  original_T_including_depot_unload_870  2.2811398160464278e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_8_14  arc_capacity_580  1
    load_0_8_14  free_load_conservation_822  1
    load_0_8_14  free_load_conservation_858  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_15  arc_capacity_582  -30
    arc_0_8_15  connected_order_arc_583  -15
    arc_0_8_15  out_degree_817  1
    arc_0_8_15  in_degree_860  1
    arc_0_8_15  original_T_including_depot_unload_870  2.2541698308553673e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_8_15  arc_capacity_582  1
    load_0_8_15  free_load_conservation_822  1
    load_0_8_15  free_load_conservation_864  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_0  arc_capacity_584  -30
    arc_0_9_0  depot_return_or_bypass_774  1
    arc_0_9_0  out_degree_823  1
    arc_0_9_0  original_T_including_depot_unload_870  1.8065333212349267e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_0  arc_capacity_584  1
    load_0_9_0  free_load_conservation_828  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_1  arc_capacity_585  -30
    arc_0_9_1  connected_order_arc_586  -15
    arc_0_9_1  in_degree_776  1
    arc_0_9_1  out_degree_823  1
    arc_0_9_1  original_T_including_depot_unload_870  2.0979901720969542e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_1  arc_capacity_585  1
    load_0_9_1  segment_load_conservation_779  -1
    load_0_9_1  segment_prefix_lb_780  1
    load_0_9_1  segment_prefix_ub_781  1
    load_0_9_1  free_load_conservation_828  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_2  arc_capacity_587  -30
    arc_0_9_2  connected_order_arc_588  -15
    arc_0_9_2  in_degree_783  1
    arc_0_9_2  out_degree_823  1
    arc_0_9_2  original_T_including_depot_unload_870  2.4478438645146789e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_2  arc_capacity_587  1
    load_0_9_2  segment_load_conservation_786  -1
    load_0_9_2  segment_prefix_lb_787  1
    load_0_9_2  segment_prefix_ub_788  1
    load_0_9_2  free_load_conservation_828  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_3  arc_capacity_589  -30
    arc_0_9_3  connected_order_arc_590  -15
    arc_0_9_3  in_degree_790  1
    arc_0_9_3  out_degree_823  1
    arc_0_9_3  original_T_including_depot_unload_870  2.1556817566230284e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_3  arc_capacity_589  1
    load_0_9_3  segment_load_conservation_793  -1
    load_0_9_3  segment_prefix_lb_794  1
    load_0_9_3  segment_prefix_ub_795  1
    load_0_9_3  free_load_conservation_828  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_4  arc_capacity_591  -30
    arc_0_9_4  connected_order_arc_592  -15
    arc_0_9_4  in_degree_797  1
    arc_0_9_4  out_degree_823  1
    arc_0_9_4  original_T_including_depot_unload_870  2.0021738809925773e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_4  arc_capacity_591  1
    load_0_9_4  segment_load_conservation_800  -1
    load_0_9_4  segment_prefix_lb_801  1
    load_0_9_4  segment_prefix_ub_802  1
    load_0_9_4  free_load_conservation_828  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_5  arc_capacity_593  -30
    arc_0_9_5  connected_order_arc_594  -15
    arc_0_9_5  in_degree_804  1
    arc_0_9_5  out_degree_823  1
    arc_0_9_5  original_T_including_depot_unload_870  1.9740618091449423e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_5  arc_capacity_593  1
    load_0_9_5  segment_load_conservation_807  -1
    load_0_9_5  segment_prefix_lb_808  1
    load_0_9_5  segment_prefix_ub_809  1
    load_0_9_5  free_load_conservation_828  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_6  arc_capacity_595  -30
    arc_0_9_6  connected_order_arc_596  -15
    arc_0_9_6  in_degree_811  1
    arc_0_9_6  out_degree_823  1
    arc_0_9_6  original_T_including_depot_unload_870  1.8739441025189553e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_6  arc_capacity_595  1
    load_0_9_6  segment_load_conservation_814  -1
    load_0_9_6  segment_prefix_lb_815  1
    load_0_9_6  segment_prefix_ub_816  1
    load_0_9_6  free_load_conservation_828  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_8  arc_capacity_597  -30
    arc_0_9_8  connected_order_arc_598  -15
    arc_0_9_8  in_degree_818  1
    arc_0_9_8  out_degree_823  1
    arc_0_9_8  original_T_including_depot_unload_870  5.2703432304351884e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_8  arc_capacity_597  1
    load_0_9_8  free_load_conservation_822  -1
    load_0_9_8  free_load_conservation_828  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_10  arc_capacity_599  -30
    arc_0_9_10  connected_order_arc_600  -15
    arc_0_9_10  out_degree_823  1
    arc_0_9_10  in_degree_830  1
    arc_0_9_10  original_T_including_depot_unload_870  3.8283958278492823e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_10  arc_capacity_599  1
    load_0_9_10  free_load_conservation_828  1
    load_0_9_10  free_load_conservation_834  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_11  arc_capacity_601  -30
    arc_0_9_11  connected_order_arc_602  -15
    arc_0_9_11  out_degree_823  1
    arc_0_9_11  in_degree_836  1
    arc_0_9_11  original_T_including_depot_unload_870  1.3126251897454844e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_11  arc_capacity_601  1
    load_0_9_11  free_load_conservation_828  1
    load_0_9_11  free_load_conservation_840  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_12  arc_capacity_603  -30
    arc_0_9_12  connected_order_arc_604  -15
    arc_0_9_12  out_degree_823  1
    arc_0_9_12  in_degree_842  1
    arc_0_9_12  original_T_including_depot_unload_870  2.0239755898835604e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_12  arc_capacity_603  1
    load_0_9_12  free_load_conservation_828  1
    load_0_9_12  free_load_conservation_846  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_13  arc_capacity_605  -30
    arc_0_9_13  connected_order_arc_606  -15
    arc_0_9_13  out_degree_823  1
    arc_0_9_13  in_degree_848  1
    arc_0_9_13  original_T_including_depot_unload_870  1.5255932363401953e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_13  arc_capacity_605  1
    load_0_9_13  free_load_conservation_828  1
    load_0_9_13  free_load_conservation_852  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_14  arc_capacity_607  -30
    arc_0_9_14  connected_order_arc_608  -15
    arc_0_9_14  out_degree_823  1
    arc_0_9_14  in_degree_854  1
    arc_0_9_14  original_T_including_depot_unload_870  1.7671662790958783e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_14  arc_capacity_607  1
    load_0_9_14  free_load_conservation_828  1
    load_0_9_14  free_load_conservation_858  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_15  arc_capacity_609  -30
    arc_0_9_15  connected_order_arc_610  -15
    arc_0_9_15  out_degree_823  1
    arc_0_9_15  in_degree_860  1
    arc_0_9_15  original_T_including_depot_unload_870  1.7340603255343296e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_15  arc_capacity_609  1
    load_0_9_15  free_load_conservation_828  1
    load_0_9_15  free_load_conservation_864  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_0  arc_capacity_611  -30
    arc_0_10_0  depot_return_or_bypass_774  1
    arc_0_10_0  out_degree_829  1
    arc_0_10_0  original_T_including_depot_unload_870  2.3234267380118886e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_0  arc_capacity_611  1
    load_0_10_0  free_load_conservation_834  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_1  arc_capacity_612  -30
    arc_0_10_1  connected_order_arc_613  -15
    arc_0_10_1  in_degree_776  1
    arc_0_10_1  out_degree_829  1
    arc_0_10_1  original_T_including_depot_unload_870  2.8834086639088187e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_1  arc_capacity_612  1
    load_0_10_1  segment_load_conservation_779  -1
    load_0_10_1  segment_prefix_lb_780  1
    load_0_10_1  segment_prefix_ub_781  1
    load_0_10_1  free_load_conservation_834  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_2  arc_capacity_614  -30
    arc_0_10_2  connected_order_arc_615  -15
    arc_0_10_2  in_degree_783  1
    arc_0_10_2  out_degree_829  1
    arc_0_10_2  original_T_including_depot_unload_870  2.9878665461125843e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_2  arc_capacity_614  1
    load_0_10_2  segment_load_conservation_786  -1
    load_0_10_2  segment_prefix_lb_787  1
    load_0_10_2  segment_prefix_ub_788  1
    load_0_10_2  free_load_conservation_834  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_3  arc_capacity_616  -30
    arc_0_10_3  connected_order_arc_617  -15
    arc_0_10_3  in_degree_790  1
    arc_0_10_3  out_degree_829  1
    arc_0_10_3  original_T_including_depot_unload_870  3.3076115257178203e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_3  arc_capacity_616  1
    load_0_10_3  segment_load_conservation_793  -1
    load_0_10_3  segment_prefix_lb_794  1
    load_0_10_3  segment_prefix_ub_795  1
    load_0_10_3  free_load_conservation_834  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_4  arc_capacity_618  -30
    arc_0_10_4  connected_order_arc_619  -15
    arc_0_10_4  in_degree_797  1
    arc_0_10_4  out_degree_829  1
    arc_0_10_4  original_T_including_depot_unload_870  3.0726580305165480e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_4  arc_capacity_618  1
    load_0_10_4  segment_load_conservation_800  -1
    load_0_10_4  segment_prefix_lb_801  1
    load_0_10_4  segment_prefix_ub_802  1
    load_0_10_4  free_load_conservation_834  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_5  arc_capacity_620  -30
    arc_0_10_5  connected_order_arc_621  -15
    arc_0_10_5  in_degree_804  1
    arc_0_10_5  out_degree_829  1
    arc_0_10_5  original_T_including_depot_unload_870  2.8807002034504962e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_5  arc_capacity_620  1
    load_0_10_5  segment_load_conservation_807  -1
    load_0_10_5  segment_prefix_lb_808  1
    load_0_10_5  segment_prefix_ub_809  1
    load_0_10_5  free_load_conservation_834  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_6  arc_capacity_622  -30
    arc_0_10_6  connected_order_arc_623  -15
    arc_0_10_6  in_degree_811  1
    arc_0_10_6  out_degree_829  1
    arc_0_10_6  original_T_including_depot_unload_870  2.7910579461472848e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_6  arc_capacity_622  1
    load_0_10_6  segment_load_conservation_814  -1
    load_0_10_6  segment_prefix_lb_815  1
    load_0_10_6  segment_prefix_ub_816  1
    load_0_10_6  free_load_conservation_834  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_8  arc_capacity_624  -30
    arc_0_10_8  connected_order_arc_625  -15
    arc_0_10_8  in_degree_818  1
    arc_0_10_8  out_degree_829  1
    arc_0_10_8  original_T_including_depot_unload_870  4.1686506413165080e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_8  arc_capacity_624  1
    load_0_10_8  free_load_conservation_822  -1
    load_0_10_8  free_load_conservation_834  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_9  arc_capacity_626  -30
    arc_0_10_9  connected_order_arc_627  -15
    arc_0_10_9  in_degree_824  1
    arc_0_10_9  out_degree_829  1
    arc_0_10_9  original_T_including_depot_unload_870  3.8283958278492823e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_9  arc_capacity_626  1
    load_0_10_9  free_load_conservation_828  -1
    load_0_10_9  free_load_conservation_834  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_11  arc_capacity_628  -30
    arc_0_10_11  connected_order_arc_629  -15
    arc_0_10_11  out_degree_829  1
    arc_0_10_11  in_degree_836  1
    arc_0_10_11  original_T_including_depot_unload_870  3.7182308190042463e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_11  arc_capacity_628  1
    load_0_10_11  free_load_conservation_834  1
    load_0_10_11  free_load_conservation_840  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_12  arc_capacity_630  -30
    arc_0_10_12  connected_order_arc_631  -15
    arc_0_10_12  out_degree_829  1
    arc_0_10_12  in_degree_842  1
    arc_0_10_12  original_T_including_depot_unload_870  2.5683172431027456e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_12  arc_capacity_630  1
    load_0_10_12  free_load_conservation_834  1
    load_0_10_12  free_load_conservation_846  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_13  arc_capacity_632  -30
    arc_0_10_13  connected_order_arc_633  -15
    arc_0_10_13  out_degree_829  1
    arc_0_10_13  in_degree_848  1
    arc_0_10_13  original_T_including_depot_unload_870  2.4160844235310037e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_13  arc_capacity_632  1
    load_0_10_13  free_load_conservation_834  1
    load_0_10_13  free_load_conservation_852  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_14  arc_capacity_634  -30
    arc_0_10_14  connected_order_arc_635  -15
    arc_0_10_14  out_degree_829  1
    arc_0_10_14  in_degree_854  1
    arc_0_10_14  original_T_including_depot_unload_870  2.6728511574036233e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_14  arc_capacity_634  1
    load_0_10_14  free_load_conservation_834  1
    load_0_10_14  free_load_conservation_858  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_15  arc_capacity_636  -30
    arc_0_10_15  connected_order_arc_637  -15
    arc_0_10_15  out_degree_829  1
    arc_0_10_15  in_degree_860  1
    arc_0_10_15  original_T_including_depot_unload_870  2.7957126389480295e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_15  arc_capacity_636  1
    load_0_10_15  free_load_conservation_834  1
    load_0_10_15  free_load_conservation_864  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_0  arc_capacity_638  -30
    arc_0_11_0  depot_return_or_bypass_774  1
    arc_0_11_0  out_degree_835  1
    arc_0_11_0  original_T_including_depot_unload_870  1739.61165920636
    MARKER    'MARKER'                 'INTEND'
    load_0_11_0  arc_capacity_638  1
    load_0_11_0  free_load_conservation_840  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_1  arc_capacity_639  -30
    arc_0_11_1  connected_order_arc_640  -15
    arc_0_11_1  in_degree_776  1
    arc_0_11_1  out_degree_835  1
    arc_0_11_1  original_T_including_depot_unload_870  2.0801782775431307e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_1  arc_capacity_639  1
    load_0_11_1  segment_load_conservation_779  -1
    load_0_11_1  segment_prefix_lb_780  1
    load_0_11_1  segment_prefix_ub_781  1
    load_0_11_1  free_load_conservation_840  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_2  arc_capacity_641  -30
    arc_0_11_2  connected_order_arc_642  -15
    arc_0_11_2  in_degree_783  1
    arc_0_11_2  out_degree_835  1
    arc_0_11_2  original_T_including_depot_unload_870  2.4369093744670904e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_2  arc_capacity_641  1
    load_0_11_2  segment_load_conservation_786  -1
    load_0_11_2  segment_prefix_lb_787  1
    load_0_11_2  segment_prefix_ub_788  1
    load_0_11_2  free_load_conservation_840  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_3  arc_capacity_643  -30
    arc_0_11_3  connected_order_arc_644  -15
    arc_0_11_3  in_degree_790  1
    arc_0_11_3  out_degree_835  1
    arc_0_11_3  original_T_including_depot_unload_870  2.1641391312462424e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_3  arc_capacity_643  1
    load_0_11_3  segment_load_conservation_793  -1
    load_0_11_3  segment_prefix_lb_794  1
    load_0_11_3  segment_prefix_ub_795  1
    load_0_11_3  free_load_conservation_840  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_4  arc_capacity_645  -30
    arc_0_11_4  connected_order_arc_646  -15
    arc_0_11_4  in_degree_797  1
    arc_0_11_4  out_degree_835  1
    arc_0_11_4  original_T_including_depot_unload_870  1.9959569014367933e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_4  arc_capacity_645  1
    load_0_11_4  segment_load_conservation_800  -1
    load_0_11_4  segment_prefix_lb_801  1
    load_0_11_4  segment_prefix_ub_802  1
    load_0_11_4  free_load_conservation_840  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_5  arc_capacity_647  -30
    arc_0_11_5  connected_order_arc_648  -15
    arc_0_11_5  in_degree_804  1
    arc_0_11_5  out_degree_835  1
    arc_0_11_5  original_T_including_depot_unload_870  1.9548039027038737e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_5  arc_capacity_647  1
    load_0_11_5  segment_load_conservation_807  -1
    load_0_11_5  segment_prefix_lb_808  1
    load_0_11_5  segment_prefix_ub_809  1
    load_0_11_5  free_load_conservation_840  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_6  arc_capacity_649  -30
    arc_0_11_6  connected_order_arc_650  -15
    arc_0_11_6  in_degree_811  1
    arc_0_11_6  out_degree_835  1
    arc_0_11_6  original_T_including_depot_unload_870  1.8467456333549035e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_6  arc_capacity_649  1
    load_0_11_6  segment_load_conservation_814  -1
    load_0_11_6  segment_prefix_lb_815  1
    load_0_11_6  segment_prefix_ub_816  1
    load_0_11_6  free_load_conservation_840  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_8  arc_capacity_651  -30
    arc_0_11_8  connected_order_arc_652  -15
    arc_0_11_8  in_degree_818  1
    arc_0_11_8  out_degree_835  1
    arc_0_11_8  original_T_including_depot_unload_870  5.5382752177930990e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_11_8  arc_capacity_651  1
    load_0_11_8  free_load_conservation_822  -1
    load_0_11_8  free_load_conservation_840  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_9  arc_capacity_653  -30
    arc_0_11_9  connected_order_arc_654  -15
    arc_0_11_9  in_degree_824  1
    arc_0_11_9  out_degree_835  1
    arc_0_11_9  original_T_including_depot_unload_870  1.3126251897454844e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_11_9  arc_capacity_653  1
    load_0_11_9  free_load_conservation_828  -1
    load_0_11_9  free_load_conservation_840  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_10  arc_capacity_655  -30
    arc_0_11_10  connected_order_arc_656  -15
    arc_0_11_10  in_degree_830  1
    arc_0_11_10  out_degree_835  1
    arc_0_11_10  original_T_including_depot_unload_870  3.7182308190042463e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_10  arc_capacity_655  1
    load_0_11_10  free_load_conservation_834  -1
    load_0_11_10  free_load_conservation_840  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_12  arc_capacity_657  -30
    arc_0_11_12  connected_order_arc_658  -15
    arc_0_11_12  out_degree_835  1
    arc_0_11_12  in_degree_842  1
    arc_0_11_12  original_T_including_depot_unload_870  1.8934642770867222e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_12  arc_capacity_657  1
    load_0_11_12  free_load_conservation_840  1
    load_0_11_12  free_load_conservation_846  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_13  arc_capacity_659  -30
    arc_0_11_13  connected_order_arc_660  -15
    arc_0_11_13  out_degree_835  1
    arc_0_11_13  in_degree_848  1
    arc_0_11_13  original_T_including_depot_unload_870  1.4443513852547251e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_13  arc_capacity_659  1
    load_0_11_13  free_load_conservation_840  1
    load_0_11_13  free_load_conservation_852  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_14  arc_capacity_661  -30
    arc_0_11_14  connected_order_arc_662  -15
    arc_0_11_14  out_degree_835  1
    arc_0_11_14  in_degree_854  1
    arc_0_11_14  original_T_including_depot_unload_870  1.7279728905134273e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_14  arc_capacity_661  1
    load_0_11_14  free_load_conservation_840  1
    load_0_11_14  free_load_conservation_858  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_15  arc_capacity_663  -30
    arc_0_11_15  connected_order_arc_664  -15
    arc_0_11_15  out_degree_835  1
    arc_0_11_15  in_degree_860  1
    arc_0_11_15  original_T_including_depot_unload_870  1.7037372759708057e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_15  arc_capacity_663  1
    load_0_11_15  free_load_conservation_840  1
    load_0_11_15  free_load_conservation_864  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_0  arc_capacity_665  -30
    arc_0_12_0  depot_return_or_bypass_774  1
    arc_0_12_0  out_degree_841  1
    arc_0_12_0  original_T_including_depot_unload_870  2.0232971184291544e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_0  arc_capacity_665  1
    load_0_12_0  free_load_conservation_846  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_1  arc_capacity_666  -30
    arc_0_12_1  connected_order_arc_667  -15
    arc_0_12_1  in_degree_776  1
    arc_0_12_1  out_degree_841  1
    arc_0_12_1  original_T_including_depot_unload_870  2820.94140713384
    MARKER    'MARKER'                 'INTEND'
    load_0_12_1  arc_capacity_666  1
    load_0_12_1  segment_load_conservation_779  -1
    load_0_12_1  segment_prefix_lb_780  1
    load_0_12_1  segment_prefix_ub_781  1
    load_0_12_1  free_load_conservation_846  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_2  arc_capacity_668  -30
    arc_0_12_2  connected_order_arc_669  -15
    arc_0_12_2  in_degree_783  1
    arc_0_12_2  out_degree_841  1
    arc_0_12_2  original_T_including_depot_unload_870  3.1658582590062310e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_2  arc_capacity_668  1
    load_0_12_2  segment_load_conservation_786  -1
    load_0_12_2  segment_prefix_lb_787  1
    load_0_12_2  segment_prefix_ub_788  1
    load_0_12_2  free_load_conservation_846  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_3  arc_capacity_670  -30
    arc_0_12_3  connected_order_arc_671  -15
    arc_0_12_3  in_degree_790  1
    arc_0_12_3  out_degree_841  1
    arc_0_12_3  original_T_including_depot_unload_870  3.1528795137337825e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_3  arc_capacity_670  1
    load_0_12_3  segment_load_conservation_793  -1
    load_0_12_3  segment_prefix_lb_794  1
    load_0_12_3  segment_prefix_ub_795  1
    load_0_12_3  free_load_conservation_846  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_4  arc_capacity_672  -30
    arc_0_12_4  connected_order_arc_673  -15
    arc_0_12_4  in_degree_797  1
    arc_0_12_4  out_degree_841  1
    arc_0_12_4  original_T_including_depot_unload_870  2.8800138602390562e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_4  arc_capacity_672  1
    load_0_12_4  segment_load_conservation_800  -1
    load_0_12_4  segment_prefix_lb_801  1
    load_0_12_4  segment_prefix_ub_802  1
    load_0_12_4  free_load_conservation_846  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_5  arc_capacity_674  -30
    arc_0_12_5  connected_order_arc_675  -15
    arc_0_12_5  in_degree_804  1
    arc_0_12_5  out_degree_841  1
    arc_0_12_5  original_T_including_depot_unload_870  2.7168118802834592e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_5  arc_capacity_674  1
    load_0_12_5  segment_load_conservation_807  -1
    load_0_12_5  segment_prefix_lb_808  1
    load_0_12_5  segment_prefix_ub_809  1
    load_0_12_5  free_load_conservation_846  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_6  arc_capacity_676  -30
    arc_0_12_6  connected_order_arc_677  -15
    arc_0_12_6  in_degree_811  1
    arc_0_12_6  out_degree_841  1
    arc_0_12_6  original_T_including_depot_unload_870  2.5598105628601829e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_6  arc_capacity_676  1
    load_0_12_6  segment_load_conservation_814  -1
    load_0_12_6  segment_prefix_lb_815  1
    load_0_12_6  segment_prefix_ub_816  1
    load_0_12_6  free_load_conservation_846  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_8  arc_capacity_678  -30
    arc_0_12_8  connected_order_arc_679  -15
    arc_0_12_8  in_degree_818  1
    arc_0_12_8  out_degree_841  1
    arc_0_12_8  original_T_including_depot_unload_870  2.0819438297758261e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_8  arc_capacity_678  1
    load_0_12_8  free_load_conservation_822  -1
    load_0_12_8  free_load_conservation_846  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_9  arc_capacity_680  -30
    arc_0_12_9  connected_order_arc_681  -15
    arc_0_12_9  in_degree_824  1
    arc_0_12_9  out_degree_841  1
    arc_0_12_9  original_T_including_depot_unload_870  2.0239755898835604e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_9  arc_capacity_680  1
    load_0_12_9  free_load_conservation_828  -1
    load_0_12_9  free_load_conservation_846  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_10  arc_capacity_682  -30
    arc_0_12_10  connected_order_arc_683  -15
    arc_0_12_10  in_degree_830  1
    arc_0_12_10  out_degree_841  1
    arc_0_12_10  original_T_including_depot_unload_870  2.5683172431027456e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_10  arc_capacity_682  1
    load_0_12_10  free_load_conservation_834  -1
    load_0_12_10  free_load_conservation_846  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_11  arc_capacity_684  -30
    arc_0_12_11  connected_order_arc_685  -15
    arc_0_12_11  in_degree_836  1
    arc_0_12_11  out_degree_841  1
    arc_0_12_11  original_T_including_depot_unload_870  1.8934642770867222e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_11  arc_capacity_684  1
    load_0_12_11  free_load_conservation_840  -1
    load_0_12_11  free_load_conservation_846  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_13  arc_capacity_686  -30
    arc_0_12_13  connected_order_arc_687  -15
    arc_0_12_13  out_degree_841  1
    arc_0_12_13  in_degree_848  1
    arc_0_12_13  original_T_including_depot_unload_870  1.7165475198920165e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_13  arc_capacity_686  1
    load_0_12_13  free_load_conservation_846  1
    load_0_12_13  free_load_conservation_852  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_14  arc_capacity_688  -30
    arc_0_12_14  connected_order_arc_689  -15
    arc_0_12_14  out_degree_841  1
    arc_0_12_14  in_degree_854  1
    arc_0_12_14  original_T_including_depot_unload_870  2.3561201725625019e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_14  arc_capacity_688  1
    load_0_12_14  free_load_conservation_846  1
    load_0_12_14  free_load_conservation_858  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_15  arc_capacity_690  -30
    arc_0_12_15  connected_order_arc_691  -15
    arc_0_12_15  out_degree_841  1
    arc_0_12_15  in_degree_860  1
    arc_0_12_15  original_T_including_depot_unload_870  2.4370949895474209e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_15  arc_capacity_690  1
    load_0_12_15  free_load_conservation_846  1
    load_0_12_15  free_load_conservation_864  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_0  arc_capacity_692  -30
    arc_0_13_0  depot_return_or_bypass_774  1
    arc_0_13_0  out_degree_847  1
    arc_0_13_0  original_T_including_depot_unload_870  3.5937232665424995e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_0  arc_capacity_692  1
    load_0_13_0  free_load_conservation_852  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_1  arc_capacity_693  -30
    arc_0_13_1  connected_order_arc_694  -15
    arc_0_13_1  in_degree_776  1
    arc_0_13_1  out_degree_847  1
    arc_0_13_1  original_T_including_depot_unload_870  1.1046832181240914e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_1  arc_capacity_693  1
    load_0_13_1  segment_load_conservation_779  -1
    load_0_13_1  segment_prefix_lb_780  1
    load_0_13_1  segment_prefix_ub_781  1
    load_0_13_1  free_load_conservation_852  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_2  arc_capacity_695  -30
    arc_0_13_2  connected_order_arc_696  -15
    arc_0_13_2  in_degree_783  1
    arc_0_13_2  out_degree_847  1
    arc_0_13_2  original_T_including_depot_unload_870  1.4558134627196880e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_2  arc_capacity_695  1
    load_0_13_2  segment_load_conservation_786  -1
    load_0_13_2  segment_prefix_lb_787  1
    load_0_13_2  segment_prefix_ub_788  1
    load_0_13_2  free_load_conservation_852  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_3  arc_capacity_697  -30
    arc_0_13_3  connected_order_arc_698  -15
    arc_0_13_3  in_degree_790  1
    arc_0_13_3  out_degree_847  1
    arc_0_13_3  original_T_including_depot_unload_870  1.4485896981484648e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_3  arc_capacity_697  1
    load_0_13_3  segment_load_conservation_793  -1
    load_0_13_3  segment_prefix_lb_794  1
    load_0_13_3  segment_prefix_ub_795  1
    load_0_13_3  free_load_conservation_852  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_4  arc_capacity_699  -30
    arc_0_13_4  connected_order_arc_700  -15
    arc_0_13_4  in_degree_797  1
    arc_0_13_4  out_degree_847  1
    arc_0_13_4  original_T_including_depot_unload_870  1.1702148343313254e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_4  arc_capacity_699  1
    load_0_13_4  segment_load_conservation_800  -1
    load_0_13_4  segment_prefix_lb_801  1
    load_0_13_4  segment_prefix_ub_802  1
    load_0_13_4  free_load_conservation_852  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_5  arc_capacity_701  -30
    arc_0_13_5  connected_order_arc_702  -15
    arc_0_13_5  in_degree_804  1
    arc_0_13_5  out_degree_847  1
    arc_0_13_5  original_T_including_depot_unload_870  1.0007616644945284e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_5  arc_capacity_701  1
    load_0_13_5  segment_load_conservation_807  -1
    load_0_13_5  segment_prefix_lb_808  1
    load_0_13_5  segment_prefix_ub_809  1
    load_0_13_5  free_load_conservation_852  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_6  arc_capacity_703  -30
    arc_0_13_6  connected_order_arc_704  -15
    arc_0_13_6  in_degree_811  1
    arc_0_13_6  out_degree_847  1
    arc_0_13_6  original_T_including_depot_unload_870  8.4376826601758887e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_6  arc_capacity_703  1
    load_0_13_6  segment_load_conservation_814  -1
    load_0_13_6  segment_prefix_lb_815  1
    load_0_13_6  segment_prefix_ub_816  1
    load_0_13_6  free_load_conservation_852  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_8  arc_capacity_705  -30
    arc_0_13_8  connected_order_arc_706  -15
    arc_0_13_8  in_degree_818  1
    arc_0_13_8  out_degree_847  1
    arc_0_13_8  original_T_including_depot_unload_870  1.9791430726365086e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_8  arc_capacity_705  1
    load_0_13_8  free_load_conservation_822  -1
    load_0_13_8  free_load_conservation_852  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_9  arc_capacity_707  -30
    arc_0_13_9  connected_order_arc_708  -15
    arc_0_13_9  in_degree_824  1
    arc_0_13_9  out_degree_847  1
    arc_0_13_9  original_T_including_depot_unload_870  1.5255932363401953e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_9  arc_capacity_707  1
    load_0_13_9  free_load_conservation_828  -1
    load_0_13_9  free_load_conservation_852  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_10  arc_capacity_709  -30
    arc_0_13_10  connected_order_arc_710  -15
    arc_0_13_10  in_degree_830  1
    arc_0_13_10  out_degree_847  1
    arc_0_13_10  original_T_including_depot_unload_870  2.4160844235310037e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_10  arc_capacity_709  1
    load_0_13_10  free_load_conservation_834  -1
    load_0_13_10  free_load_conservation_852  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_11  arc_capacity_711  -30
    arc_0_13_11  connected_order_arc_712  -15
    arc_0_13_11  in_degree_836  1
    arc_0_13_11  out_degree_847  1
    arc_0_13_11  original_T_including_depot_unload_870  1.4443513852547251e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_11  arc_capacity_711  1
    load_0_13_11  free_load_conservation_840  -1
    load_0_13_11  free_load_conservation_852  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_12  arc_capacity_713  -30
    arc_0_13_12  connected_order_arc_714  -15
    arc_0_13_12  in_degree_842  1
    arc_0_13_12  out_degree_847  1
    arc_0_13_12  original_T_including_depot_unload_870  1.7165475198920165e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_12  arc_capacity_713  1
    load_0_13_12  free_load_conservation_846  -1
    load_0_13_12  free_load_conservation_852  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_14  arc_capacity_715  -30
    arc_0_13_14  connected_order_arc_716  -15
    arc_0_13_14  out_degree_847  1
    arc_0_13_14  in_degree_854  1
    arc_0_13_14  original_T_including_depot_unload_870  6.3975035388222534e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_14  arc_capacity_715  1
    load_0_13_14  free_load_conservation_852  1
    load_0_13_14  free_load_conservation_858  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_15  arc_capacity_717  -30
    arc_0_13_15  connected_order_arc_718  -15
    arc_0_13_15  out_degree_847  1
    arc_0_13_15  in_degree_860  1
    arc_0_13_15  original_T_including_depot_unload_870  7.2696582003770027e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_15  arc_capacity_717  1
    load_0_13_15  free_load_conservation_852  1
    load_0_13_15  free_load_conservation_864  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_0  arc_capacity_719  -30
    arc_0_14_0  depot_return_or_bypass_774  1
    arc_0_14_0  out_degree_853  1
    arc_0_14_0  original_T_including_depot_unload_870  4.0782796387128610e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_0  arc_capacity_719  1
    load_0_14_0  free_load_conservation_858  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_1  arc_capacity_720  -30
    arc_0_14_1  connected_order_arc_721  -15
    arc_0_14_1  in_degree_776  1
    arc_0_14_1  out_degree_853  1
    arc_0_14_1  original_T_including_depot_unload_870  4.6739130846957909e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_1  arc_capacity_720  1
    load_0_14_1  segment_load_conservation_779  -1
    load_0_14_1  segment_prefix_lb_780  1
    load_0_14_1  segment_prefix_ub_781  1
    load_0_14_1  free_load_conservation_858  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_2  arc_capacity_722  -30
    arc_0_14_2  connected_order_arc_723  -15
    arc_0_14_2  in_degree_783  1
    arc_0_14_2  out_degree_853  1
    arc_0_14_2  original_T_including_depot_unload_870  8.2982882938703278e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_2  arc_capacity_722  1
    load_0_14_2  segment_load_conservation_786  -1
    load_0_14_2  segment_prefix_lb_787  1
    load_0_14_2  segment_prefix_ub_788  1
    load_0_14_2  free_load_conservation_858  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_3  arc_capacity_724  -30
    arc_0_14_3  connected_order_arc_725  -15
    arc_0_14_3  in_degree_790  1
    arc_0_14_3  out_degree_853  1
    arc_0_14_3  original_T_including_depot_unload_870  8.2145202724109538e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_3  arc_capacity_724  1
    load_0_14_3  segment_load_conservation_793  -1
    load_0_14_3  segment_prefix_lb_794  1
    load_0_14_3  segment_prefix_ub_795  1
    load_0_14_3  free_load_conservation_858  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_4  arc_capacity_726  -30
    arc_0_14_4  connected_order_arc_727  -15
    arc_0_14_4  in_degree_797  1
    arc_0_14_4  out_degree_853  1
    arc_0_14_4  original_T_including_depot_unload_870  5.3918604589472477e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_4  arc_capacity_726  1
    load_0_14_4  segment_load_conservation_800  -1
    load_0_14_4  segment_prefix_lb_801  1
    load_0_14_4  segment_prefix_ub_802  1
    load_0_14_4  free_load_conservation_858  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_5  arc_capacity_728  -30
    arc_0_14_5  connected_order_arc_729  -15
    arc_0_14_5  in_degree_804  1
    arc_0_14_5  out_degree_853  1
    arc_0_14_5  original_T_including_depot_unload_870  3.6114004430677619e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_5  arc_capacity_728  1
    load_0_14_5  segment_load_conservation_807  -1
    load_0_14_5  segment_prefix_lb_808  1
    load_0_14_5  segment_prefix_ub_809  1
    load_0_14_5  free_load_conservation_858  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_6  arc_capacity_730  -30
    arc_0_14_6  connected_order_arc_731  -15
    arc_0_14_6  in_degree_811  1
    arc_0_14_6  out_degree_853  1
    arc_0_14_6  original_T_including_depot_unload_870  2.0430160967046345e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_6  arc_capacity_730  1
    load_0_14_6  segment_load_conservation_814  -1
    load_0_14_6  segment_prefix_lb_815  1
    load_0_14_6  segment_prefix_ub_816  1
    load_0_14_6  free_load_conservation_858  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_8  arc_capacity_732  -30
    arc_0_14_8  connected_order_arc_733  -15
    arc_0_14_8  in_degree_818  1
    arc_0_14_8  out_degree_853  1
    arc_0_14_8  original_T_including_depot_unload_870  2.2811398160464278e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_8  arc_capacity_732  1
    load_0_14_8  free_load_conservation_822  -1
    load_0_14_8  free_load_conservation_858  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_9  arc_capacity_734  -30
    arc_0_14_9  connected_order_arc_735  -15
    arc_0_14_9  in_degree_824  1
    arc_0_14_9  out_degree_853  1
    arc_0_14_9  original_T_including_depot_unload_870  1.7671662790958783e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_9  arc_capacity_734  1
    load_0_14_9  free_load_conservation_828  -1
    load_0_14_9  free_load_conservation_858  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_10  arc_capacity_736  -30
    arc_0_14_10  connected_order_arc_737  -15
    arc_0_14_10  in_degree_830  1
    arc_0_14_10  out_degree_853  1
    arc_0_14_10  original_T_including_depot_unload_870  2.6728511574036233e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_10  arc_capacity_736  1
    load_0_14_10  free_load_conservation_834  -1
    load_0_14_10  free_load_conservation_858  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_11  arc_capacity_738  -30
    arc_0_14_11  connected_order_arc_739  -15
    arc_0_14_11  in_degree_836  1
    arc_0_14_11  out_degree_853  1
    arc_0_14_11  original_T_including_depot_unload_870  1.7279728905134273e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_11  arc_capacity_738  1
    load_0_14_11  free_load_conservation_840  -1
    load_0_14_11  free_load_conservation_858  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_12  arc_capacity_740  -30
    arc_0_14_12  connected_order_arc_741  -15
    arc_0_14_12  in_degree_842  1
    arc_0_14_12  out_degree_853  1
    arc_0_14_12  original_T_including_depot_unload_870  2.3561201725625019e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_12  arc_capacity_740  1
    load_0_14_12  free_load_conservation_846  -1
    load_0_14_12  free_load_conservation_858  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_13  arc_capacity_742  -30
    arc_0_14_13  connected_order_arc_743  -15
    arc_0_14_13  in_degree_848  1
    arc_0_14_13  out_degree_853  1
    arc_0_14_13  original_T_including_depot_unload_870  6.3975035388222534e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_13  arc_capacity_742  1
    load_0_14_13  free_load_conservation_852  -1
    load_0_14_13  free_load_conservation_858  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_15  arc_capacity_744  -30
    arc_0_14_15  connected_order_arc_745  -15
    arc_0_14_15  out_degree_853  1
    arc_0_14_15  in_degree_860  1
    arc_0_14_15  original_T_including_depot_unload_870  1.2480053261465446e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_15  arc_capacity_744  1
    load_0_14_15  free_load_conservation_858  1
    load_0_14_15  free_load_conservation_864  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_0  arc_capacity_746  -30
    arc_0_15_0  depot_return_or_bypass_774  1
    arc_0_15_0  out_degree_859  1
    arc_0_15_0  original_T_including_depot_unload_870  5.2774046204590661e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_0  arc_capacity_746  1
    load_0_15_0  free_load_conservation_864  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_1  arc_capacity_747  -30
    arc_0_15_1  connected_order_arc_748  -15
    arc_0_15_1  in_degree_776  1
    arc_0_15_1  out_degree_859  1
    arc_0_15_1  original_T_including_depot_unload_870  4.1346687597344868e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_1  arc_capacity_747  1
    load_0_15_1  segment_load_conservation_779  -1
    load_0_15_1  segment_prefix_lb_780  1
    load_0_15_1  segment_prefix_ub_781  1
    load_0_15_1  free_load_conservation_864  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_2  arc_capacity_749  -30
    arc_0_15_2  connected_order_arc_750  -15
    arc_0_15_2  in_degree_783  1
    arc_0_15_2  out_degree_859  1
    arc_0_15_2  original_T_including_depot_unload_870  7.8604521666483390e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_2  arc_capacity_749  1
    load_0_15_2  segment_load_conservation_786  -1
    load_0_15_2  segment_prefix_lb_787  1
    load_0_15_2  segment_prefix_ub_788  1
    load_0_15_2  free_load_conservation_864  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_3  arc_capacity_751  -30
    arc_0_15_3  connected_order_arc_752  -15
    arc_0_15_3  in_degree_790  1
    arc_0_15_3  out_degree_859  1
    arc_0_15_3  original_T_including_depot_unload_870  7.2186296856879846e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_3  arc_capacity_751  1
    load_0_15_3  segment_load_conservation_793  -1
    load_0_15_3  segment_prefix_lb_794  1
    load_0_15_3  segment_prefix_ub_795  1
    load_0_15_3  free_load_conservation_864  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_4  arc_capacity_753  -30
    arc_0_15_4  connected_order_arc_754  -15
    arc_0_15_4  in_degree_797  1
    arc_0_15_4  out_degree_859  1
    arc_0_15_4  original_T_including_depot_unload_870  4.4360641393992279e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_4  arc_capacity_753  1
    load_0_15_4  segment_load_conservation_800  -1
    load_0_15_4  segment_prefix_lb_801  1
    load_0_15_4  segment_prefix_ub_802  1
    load_0_15_4  free_load_conservation_864  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_5  arc_capacity_755  -30
    arc_0_15_5  connected_order_arc_756  -15
    arc_0_15_5  in_degree_804  1
    arc_0_15_5  out_degree_859  1
    arc_0_15_5  original_T_including_depot_unload_870  291.965990421835
    MARKER    'MARKER'                 'INTEND'
    load_0_15_5  arc_capacity_755  1
    load_0_15_5  segment_load_conservation_807  -1
    load_0_15_5  segment_prefix_lb_808  1
    load_0_15_5  segment_prefix_ub_809  1
    load_0_15_5  free_load_conservation_864  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_6  arc_capacity_757  -30
    arc_0_15_6  connected_order_arc_758  -15
    arc_0_15_6  in_degree_811  1
    arc_0_15_6  out_degree_859  1
    arc_0_15_6  original_T_including_depot_unload_870  1.4810770279475858e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_6  arc_capacity_757  1
    load_0_15_6  segment_load_conservation_814  -1
    load_0_15_6  segment_prefix_lb_815  1
    load_0_15_6  segment_prefix_ub_816  1
    load_0_15_6  free_load_conservation_864  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_8  arc_capacity_759  -30
    arc_0_15_8  connected_order_arc_760  -15
    arc_0_15_8  in_degree_818  1
    arc_0_15_8  out_degree_859  1
    arc_0_15_8  original_T_including_depot_unload_870  2.2541698308553673e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_8  arc_capacity_759  1
    load_0_15_8  free_load_conservation_822  -1
    load_0_15_8  free_load_conservation_864  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_9  arc_capacity_761  -30
    arc_0_15_9  connected_order_arc_762  -15
    arc_0_15_9  in_degree_824  1
    arc_0_15_9  out_degree_859  1
    arc_0_15_9  original_T_including_depot_unload_870  1.7340603255343296e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_9  arc_capacity_761  1
    load_0_15_9  free_load_conservation_828  -1
    load_0_15_9  free_load_conservation_864  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_10  arc_capacity_763  -30
    arc_0_15_10  connected_order_arc_764  -15
    arc_0_15_10  in_degree_830  1
    arc_0_15_10  out_degree_859  1
    arc_0_15_10  original_T_including_depot_unload_870  2.7957126389480295e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_10  arc_capacity_763  1
    load_0_15_10  free_load_conservation_834  -1
    load_0_15_10  free_load_conservation_864  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_11  arc_capacity_765  -30
    arc_0_15_11  connected_order_arc_766  -15
    arc_0_15_11  in_degree_836  1
    arc_0_15_11  out_degree_859  1
    arc_0_15_11  original_T_including_depot_unload_870  1.7037372759708057e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_11  arc_capacity_765  1
    load_0_15_11  free_load_conservation_840  -1
    load_0_15_11  free_load_conservation_864  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_12  arc_capacity_767  -30
    arc_0_15_12  connected_order_arc_768  -15
    arc_0_15_12  in_degree_842  1
    arc_0_15_12  out_degree_859  1
    arc_0_15_12  original_T_including_depot_unload_870  2.4370949895474209e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_12  arc_capacity_767  1
    load_0_15_12  free_load_conservation_846  -1
    load_0_15_12  free_load_conservation_864  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_13  arc_capacity_769  -30
    arc_0_15_13  connected_order_arc_770  -15
    arc_0_15_13  in_degree_848  1
    arc_0_15_13  out_degree_859  1
    arc_0_15_13  original_T_including_depot_unload_870  7.2696582003770027e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_13  arc_capacity_769  1
    load_0_15_13  free_load_conservation_852  -1
    load_0_15_13  free_load_conservation_864  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_14  arc_capacity_771  -30
    arc_0_15_14  connected_order_arc_772  -15
    arc_0_15_14  in_degree_854  1
    arc_0_15_14  out_degree_859  1
    arc_0_15_14  original_T_including_depot_unload_870  1.2480053261465446e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_14  arc_capacity_771  1
    load_0_15_14  free_load_conservation_858  -1
    load_0_15_14  free_load_conservation_864  1
    visit_1_7  out_degree_1036  -1
    visit_1_7  in_degree_1037  -1
    visit_1_7  order_active_lb_1038  -1
    visit_1_7  order_active_ub_1039  -9
    order_1_7  connected_order_arc_883  -1
    order_1_7  connected_order_arc_885  -1
    order_1_7  connected_order_arc_887  -1
    order_1_7  connected_order_arc_889  -1
    order_1_7  connected_order_arc_891  -1
    order_1_7  connected_order_arc_893  -1
    order_1_7  connected_order_arc_895  -1
    order_1_7  connected_order_arc_897  -1
    order_1_7  connected_order_arc_900  1
    order_1_7  connected_order_arc_917  1
    order_1_7  connected_order_arc_934  1
    order_1_7  connected_order_arc_951  1
    order_1_7  connected_order_arc_968  1
    order_1_7  connected_order_arc_985  1
    order_1_7  connected_order_arc_1002  1
    order_1_7  connected_order_arc_1019  1
    order_1_7  order_active_lb_1038  1
    order_1_7  order_active_ub_1039  1
    visit_1_8  out_degree_1043  -1
    visit_1_8  in_degree_1044  -1
    visit_1_8  order_active_lb_1045  -1
    visit_1_8  order_active_ub_1046  -9
    visit_1_8  service_visit_def_1047  -1
    order_1_8  connected_order_arc_883  1
    order_1_8  connected_order_arc_900  -1
    order_1_8  connected_order_arc_902  -1
    order_1_8  connected_order_arc_904  -1
    order_1_8  connected_order_arc_906  -1
    order_1_8  connected_order_arc_908  -1
    order_1_8  connected_order_arc_910  -1
    order_1_8  connected_order_arc_912  -1
    order_1_8  connected_order_arc_914  -1
    order_1_8  connected_order_arc_919  1
    order_1_8  connected_order_arc_936  1
    order_1_8  connected_order_arc_953  1
    order_1_8  connected_order_arc_970  1
    order_1_8  connected_order_arc_987  1
    order_1_8  connected_order_arc_1004  1
    order_1_8  connected_order_arc_1021  1
    order_1_8  order_active_lb_1045  1
    order_1_8  order_active_ub_1046  1
    visit_1_9  out_degree_1049  -1
    visit_1_9  in_degree_1050  -1
    visit_1_9  order_active_lb_1051  -1
    visit_1_9  order_active_ub_1052  -9
    visit_1_9  service_visit_def_1053  -1
    order_1_9  connected_order_arc_885  1
    order_1_9  connected_order_arc_902  1
    order_1_9  connected_order_arc_917  -1
    order_1_9  connected_order_arc_919  -1
    order_1_9  connected_order_arc_921  -1
    order_1_9  connected_order_arc_923  -1
    order_1_9  connected_order_arc_925  -1
    order_1_9  connected_order_arc_927  -1
    order_1_9  connected_order_arc_929  -1
    order_1_9  connected_order_arc_931  -1
    order_1_9  connected_order_arc_938  1
    order_1_9  connected_order_arc_955  1
    order_1_9  connected_order_arc_972  1
    order_1_9  connected_order_arc_989  1
    order_1_9  connected_order_arc_1006  1
    order_1_9  connected_order_arc_1023  1
    order_1_9  order_active_lb_1051  1
    order_1_9  order_active_ub_1052  1
    visit_1_10  out_degree_1055  -1
    visit_1_10  in_degree_1056  -1
    visit_1_10  order_active_lb_1057  -1
    visit_1_10  order_active_ub_1058  -9
    visit_1_10  service_visit_def_1059  -1
    order_1_10  connected_order_arc_887  1
    order_1_10  connected_order_arc_904  1
    order_1_10  connected_order_arc_921  1
    order_1_10  connected_order_arc_934  -1
    order_1_10  connected_order_arc_936  -1
    order_1_10  connected_order_arc_938  -1
    order_1_10  connected_order_arc_940  -1
    order_1_10  connected_order_arc_942  -1
    order_1_10  connected_order_arc_944  -1
    order_1_10  connected_order_arc_946  -1
    order_1_10  connected_order_arc_948  -1
    order_1_10  connected_order_arc_957  1
    order_1_10  connected_order_arc_974  1
    order_1_10  connected_order_arc_991  1
    order_1_10  connected_order_arc_1008  1
    order_1_10  connected_order_arc_1025  1
    order_1_10  order_active_lb_1057  1
    order_1_10  order_active_ub_1058  1
    visit_1_11  out_degree_1061  -1
    visit_1_11  in_degree_1062  -1
    visit_1_11  order_active_lb_1063  -1
    visit_1_11  order_active_ub_1064  -9
    visit_1_11  service_visit_def_1065  -1
    order_1_11  connected_order_arc_889  1
    order_1_11  connected_order_arc_906  1
    order_1_11  connected_order_arc_923  1
    order_1_11  connected_order_arc_940  1
    order_1_11  connected_order_arc_951  -1
    order_1_11  connected_order_arc_953  -1
    order_1_11  connected_order_arc_955  -1
    order_1_11  connected_order_arc_957  -1
    order_1_11  connected_order_arc_959  -1
    order_1_11  connected_order_arc_961  -1
    order_1_11  connected_order_arc_963  -1
    order_1_11  connected_order_arc_965  -1
    order_1_11  connected_order_arc_976  1
    order_1_11  connected_order_arc_993  1
    order_1_11  connected_order_arc_1010  1
    order_1_11  connected_order_arc_1027  1
    order_1_11  order_active_lb_1063  1
    order_1_11  order_active_ub_1064  1
    visit_1_12  out_degree_1067  -1
    visit_1_12  in_degree_1068  -1
    visit_1_12  order_active_lb_1069  -1
    visit_1_12  order_active_ub_1070  -9
    visit_1_12  service_visit_def_1071  -1
    order_1_12  connected_order_arc_891  1
    order_1_12  connected_order_arc_908  1
    order_1_12  connected_order_arc_925  1
    order_1_12  connected_order_arc_942  1
    order_1_12  connected_order_arc_959  1
    order_1_12  connected_order_arc_968  -1
    order_1_12  connected_order_arc_970  -1
    order_1_12  connected_order_arc_972  -1
    order_1_12  connected_order_arc_974  -1
    order_1_12  connected_order_arc_976  -1
    order_1_12  connected_order_arc_978  -1
    order_1_12  connected_order_arc_980  -1
    order_1_12  connected_order_arc_982  -1
    order_1_12  connected_order_arc_995  1
    order_1_12  connected_order_arc_1012  1
    order_1_12  connected_order_arc_1029  1
    order_1_12  order_active_lb_1069  1
    order_1_12  order_active_ub_1070  1
    visit_1_13  out_degree_1073  -1
    visit_1_13  in_degree_1074  -1
    visit_1_13  order_active_lb_1075  -1
    visit_1_13  order_active_ub_1076  -9
    visit_1_13  service_visit_def_1077  -1
    order_1_13  connected_order_arc_893  1
    order_1_13  connected_order_arc_910  1
    order_1_13  connected_order_arc_927  1
    order_1_13  connected_order_arc_944  1
    order_1_13  connected_order_arc_961  1
    order_1_13  connected_order_arc_978  1
    order_1_13  connected_order_arc_985  -1
    order_1_13  connected_order_arc_987  -1
    order_1_13  connected_order_arc_989  -1
    order_1_13  connected_order_arc_991  -1
    order_1_13  connected_order_arc_993  -1
    order_1_13  connected_order_arc_995  -1
    order_1_13  connected_order_arc_997  -1
    order_1_13  connected_order_arc_999  -1
    order_1_13  connected_order_arc_1014  1
    order_1_13  connected_order_arc_1031  1
    order_1_13  order_active_lb_1075  1
    order_1_13  order_active_ub_1076  1
    visit_1_14  out_degree_1079  -1
    visit_1_14  in_degree_1080  -1
    visit_1_14  order_active_lb_1081  -1
    visit_1_14  order_active_ub_1082  -9
    visit_1_14  service_visit_def_1083  -1
    order_1_14  connected_order_arc_895  1
    order_1_14  connected_order_arc_912  1
    order_1_14  connected_order_arc_929  1
    order_1_14  connected_order_arc_946  1
    order_1_14  connected_order_arc_963  1
    order_1_14  connected_order_arc_980  1
    order_1_14  connected_order_arc_997  1
    order_1_14  connected_order_arc_1002  -1
    order_1_14  connected_order_arc_1004  -1
    order_1_14  connected_order_arc_1006  -1
    order_1_14  connected_order_arc_1008  -1
    order_1_14  connected_order_arc_1010  -1
    order_1_14  connected_order_arc_1012  -1
    order_1_14  connected_order_arc_1014  -1
    order_1_14  connected_order_arc_1016  -1
    order_1_14  connected_order_arc_1033  1
    order_1_14  order_active_lb_1081  1
    order_1_14  order_active_ub_1082  1
    visit_1_15  out_degree_1085  -1
    visit_1_15  in_degree_1086  -1
    visit_1_15  order_active_lb_1087  -1
    visit_1_15  order_active_ub_1088  -9
    visit_1_15  service_visit_def_1089  -1
    order_1_15  connected_order_arc_897  1
    order_1_15  connected_order_arc_914  1
    order_1_15  connected_order_arc_931  1
    order_1_15  connected_order_arc_948  1
    order_1_15  connected_order_arc_965  1
    order_1_15  connected_order_arc_982  1
    order_1_15  connected_order_arc_999  1
    order_1_15  connected_order_arc_1016  1
    order_1_15  connected_order_arc_1019  -1
    order_1_15  connected_order_arc_1021  -1
    order_1_15  connected_order_arc_1023  -1
    order_1_15  connected_order_arc_1025  -1
    order_1_15  connected_order_arc_1027  -1
    order_1_15  connected_order_arc_1029  -1
    order_1_15  connected_order_arc_1031  -1
    order_1_15  connected_order_arc_1033  -1
    order_1_15  order_active_lb_1087  1
    order_1_15  order_active_ub_1088  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_0  arc_capacity_871  -30
    arc_1_0_0  depot_departure_or_bypass_1034  1
    arc_1_0_0  depot_return_or_bypass_1035  1
    MARKER    'MARKER'                 'INTEND'
    load_1_0_0  arc_capacity_871  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_7  arc_capacity_872  -30
    arc_1_0_7  depot_departure_or_bypass_1034  1
    arc_1_0_7  in_degree_1037  1
    arc_1_0_7  original_T_including_depot_unload_1091  4.1588440854375170e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_7  arc_capacity_872  1
    load_1_0_7  segment_load_conservation_1040  -1
    load_1_0_7  segment_prefix_lb_1041  1
    load_1_0_7  segment_prefix_ub_1042  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_8  arc_capacity_873  -30
    arc_1_0_8  depot_departure_or_bypass_1034  1
    arc_1_0_8  in_degree_1044  1
    arc_1_0_8  original_T_including_depot_unload_1091  2.2866763971369810e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_8  arc_capacity_873  1
    load_1_0_8  free_load_conservation_1048  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_9  arc_capacity_874  -30
    arc_1_0_9  depot_departure_or_bypass_1034  1
    arc_1_0_9  in_degree_1050  1
    arc_1_0_9  original_T_including_depot_unload_1091  1.8065333212349267e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_9  arc_capacity_874  1
    load_1_0_9  free_load_conservation_1054  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_10  arc_capacity_875  -30
    arc_1_0_10  depot_departure_or_bypass_1034  1
    arc_1_0_10  in_degree_1056  1
    arc_1_0_10  original_T_including_depot_unload_1091  2.3234267380118886e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_10  arc_capacity_875  1
    load_1_0_10  free_load_conservation_1060  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_11  arc_capacity_876  -30
    arc_1_0_11  depot_departure_or_bypass_1034  1
    arc_1_0_11  in_degree_1062  1
    arc_1_0_11  original_T_including_depot_unload_1091  1739.61165920636
    MARKER    'MARKER'                 'INTEND'
    load_1_0_11  arc_capacity_876  1
    load_1_0_11  free_load_conservation_1066  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_12  arc_capacity_877  -30
    arc_1_0_12  depot_departure_or_bypass_1034  1
    arc_1_0_12  in_degree_1068  1
    arc_1_0_12  original_T_including_depot_unload_1091  2.0232971184291544e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_12  arc_capacity_877  1
    load_1_0_12  free_load_conservation_1072  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_13  arc_capacity_878  -30
    arc_1_0_13  depot_departure_or_bypass_1034  1
    arc_1_0_13  in_degree_1074  1
    arc_1_0_13  original_T_including_depot_unload_1091  3.5937232665424995e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_13  arc_capacity_878  1
    load_1_0_13  free_load_conservation_1078  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_14  arc_capacity_879  -30
    arc_1_0_14  depot_departure_or_bypass_1034  1
    arc_1_0_14  in_degree_1080  1
    arc_1_0_14  original_T_including_depot_unload_1091  4.0782796387128610e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_14  arc_capacity_879  1
    load_1_0_14  free_load_conservation_1084  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_15  arc_capacity_880  -30
    arc_1_0_15  depot_departure_or_bypass_1034  1
    arc_1_0_15  in_degree_1086  1
    arc_1_0_15  original_T_including_depot_unload_1091  5.2774046204590661e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_15  arc_capacity_880  1
    load_1_0_15  free_load_conservation_1090  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_0  arc_capacity_881  -30
    arc_1_7_0  depot_return_or_bypass_1035  1
    arc_1_7_0  out_degree_1036  1
    arc_1_7_0  original_T_including_depot_unload_1091  4.1588440854375170e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_0  arc_capacity_881  1
    load_1_7_0  segment_load_conservation_1040  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_8  arc_capacity_882  -30
    arc_1_7_8  connected_order_arc_883  -10
    arc_1_7_8  out_degree_1036  1
    arc_1_7_8  in_degree_1044  1
    arc_1_7_8  original_T_including_depot_unload_1091  2.4543912353372671e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_8  arc_capacity_882  1
    load_1_7_8  segment_load_conservation_1040  1
    load_1_7_8  free_load_conservation_1048  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_9  arc_capacity_884  -30
    arc_1_7_9  connected_order_arc_885  -10
    arc_1_7_9  out_degree_1036  1
    arc_1_7_9  in_degree_1050  1
    arc_1_7_9  original_T_including_depot_unload_1091  1.9425880448191174e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_9  arc_capacity_884  1
    load_1_7_9  segment_load_conservation_1040  1
    load_1_7_9  free_load_conservation_1054  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_10  arc_capacity_886  -30
    arc_1_7_10  connected_order_arc_887  -10
    arc_1_7_10  out_degree_1036  1
    arc_1_7_10  in_degree_1056  1
    arc_1_7_10  original_T_including_depot_unload_1091  2.5651522766561479e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_10  arc_capacity_886  1
    load_1_7_10  segment_load_conservation_1040  1
    load_1_7_10  free_load_conservation_1060  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_11  arc_capacity_888  -30
    arc_1_7_11  connected_order_arc_889  -10
    arc_1_7_11  out_degree_1036  1
    arc_1_7_11  in_degree_1062  1
    arc_1_7_11  original_T_including_depot_unload_1091  1.9007789738787540e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_11  arc_capacity_888  1
    load_1_7_11  segment_load_conservation_1040  1
    load_1_7_11  free_load_conservation_1066  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_12  arc_capacity_890  -30
    arc_1_7_12  connected_order_arc_891  -10
    arc_1_7_12  out_degree_1036  1
    arc_1_7_12  in_degree_1068  1
    arc_1_7_12  original_T_including_depot_unload_1091  2.4295946549751052e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_12  arc_capacity_890  1
    load_1_7_12  segment_load_conservation_1040  1
    load_1_7_12  free_load_conservation_1072  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_13  arc_capacity_892  -30
    arc_1_7_13  connected_order_arc_893  -10
    arc_1_7_13  out_degree_1036  1
    arc_1_7_13  in_degree_1074  1
    arc_1_7_13  original_T_including_depot_unload_1091  7.2365484333226220e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_13  arc_capacity_892  1
    load_1_7_13  segment_load_conservation_1040  1
    load_1_7_13  free_load_conservation_1078  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_14  arc_capacity_894  -30
    arc_1_7_14  connected_order_arc_895  -10
    arc_1_7_14  out_degree_1036  1
    arc_1_7_14  in_degree_1080  1
    arc_1_7_14  original_T_including_depot_unload_1091  1.7839442696984972e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_14  arc_capacity_894  1
    load_1_7_14  segment_load_conservation_1040  1
    load_1_7_14  free_load_conservation_1084  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_15  arc_capacity_896  -30
    arc_1_7_15  connected_order_arc_897  -10
    arc_1_7_15  out_degree_1036  1
    arc_1_7_15  in_degree_1086  1
    arc_1_7_15  original_T_including_depot_unload_1091  2.6178398366762252e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_15  arc_capacity_896  1
    load_1_7_15  segment_load_conservation_1040  1
    load_1_7_15  free_load_conservation_1090  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_0  arc_capacity_898  -30
    arc_1_8_0  depot_return_or_bypass_1035  1
    arc_1_8_0  out_degree_1043  1
    arc_1_8_0  original_T_including_depot_unload_1091  2.2866763971369810e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_0  arc_capacity_898  1
    load_1_8_0  free_load_conservation_1048  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_7  arc_capacity_899  -30
    arc_1_8_7  connected_order_arc_900  -10
    arc_1_8_7  in_degree_1037  1
    arc_1_8_7  out_degree_1043  1
    arc_1_8_7  original_T_including_depot_unload_1091  2.4543912353372671e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_7  arc_capacity_899  1
    load_1_8_7  segment_load_conservation_1040  -1
    load_1_8_7  segment_prefix_lb_1041  1
    load_1_8_7  segment_prefix_ub_1042  1
    load_1_8_7  free_load_conservation_1048  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_9  arc_capacity_901  -30
    arc_1_8_9  connected_order_arc_902  -10
    arc_1_8_9  out_degree_1043  1
    arc_1_8_9  in_degree_1050  1
    arc_1_8_9  original_T_including_depot_unload_1091  5.2703432304351884e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_9  arc_capacity_901  1
    load_1_8_9  free_load_conservation_1048  1
    load_1_8_9  free_load_conservation_1054  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_10  arc_capacity_903  -30
    arc_1_8_10  connected_order_arc_904  -10
    arc_1_8_10  out_degree_1043  1
    arc_1_8_10  in_degree_1056  1
    arc_1_8_10  original_T_including_depot_unload_1091  4.1686506413165080e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_10  arc_capacity_903  1
    load_1_8_10  free_load_conservation_1048  1
    load_1_8_10  free_load_conservation_1060  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_11  arc_capacity_905  -30
    arc_1_8_11  connected_order_arc_906  -10
    arc_1_8_11  out_degree_1043  1
    arc_1_8_11  in_degree_1062  1
    arc_1_8_11  original_T_including_depot_unload_1091  5.5382752177930990e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_11  arc_capacity_905  1
    load_1_8_11  free_load_conservation_1048  1
    load_1_8_11  free_load_conservation_1066  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_12  arc_capacity_907  -30
    arc_1_8_12  connected_order_arc_908  -10
    arc_1_8_12  out_degree_1043  1
    arc_1_8_12  in_degree_1068  1
    arc_1_8_12  original_T_including_depot_unload_1091  2.0819438297758261e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_12  arc_capacity_907  1
    load_1_8_12  free_load_conservation_1048  1
    load_1_8_12  free_load_conservation_1072  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_13  arc_capacity_909  -30
    arc_1_8_13  connected_order_arc_910  -10
    arc_1_8_13  out_degree_1043  1
    arc_1_8_13  in_degree_1074  1
    arc_1_8_13  original_T_including_depot_unload_1091  1.9791430726365086e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_13  arc_capacity_909  1
    load_1_8_13  free_load_conservation_1048  1
    load_1_8_13  free_load_conservation_1078  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_14  arc_capacity_911  -30
    arc_1_8_14  connected_order_arc_912  -10
    arc_1_8_14  out_degree_1043  1
    arc_1_8_14  in_degree_1080  1
    arc_1_8_14  original_T_including_depot_unload_1091  2.2811398160464278e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_14  arc_capacity_911  1
    load_1_8_14  free_load_conservation_1048  1
    load_1_8_14  free_load_conservation_1084  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_15  arc_capacity_913  -30
    arc_1_8_15  connected_order_arc_914  -10
    arc_1_8_15  out_degree_1043  1
    arc_1_8_15  in_degree_1086  1
    arc_1_8_15  original_T_including_depot_unload_1091  2.2541698308553673e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_15  arc_capacity_913  1
    load_1_8_15  free_load_conservation_1048  1
    load_1_8_15  free_load_conservation_1090  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_0  arc_capacity_915  -30
    arc_1_9_0  depot_return_or_bypass_1035  1
    arc_1_9_0  out_degree_1049  1
    arc_1_9_0  original_T_including_depot_unload_1091  1.8065333212349267e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_0  arc_capacity_915  1
    load_1_9_0  free_load_conservation_1054  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_7  arc_capacity_916  -30
    arc_1_9_7  connected_order_arc_917  -10
    arc_1_9_7  in_degree_1037  1
    arc_1_9_7  out_degree_1049  1
    arc_1_9_7  original_T_including_depot_unload_1091  1.9425880448191174e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_7  arc_capacity_916  1
    load_1_9_7  segment_load_conservation_1040  -1
    load_1_9_7  segment_prefix_lb_1041  1
    load_1_9_7  segment_prefix_ub_1042  1
    load_1_9_7  free_load_conservation_1054  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_8  arc_capacity_918  -30
    arc_1_9_8  connected_order_arc_919  -10
    arc_1_9_8  in_degree_1044  1
    arc_1_9_8  out_degree_1049  1
    arc_1_9_8  original_T_including_depot_unload_1091  5.2703432304351884e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_8  arc_capacity_918  1
    load_1_9_8  free_load_conservation_1048  -1
    load_1_9_8  free_load_conservation_1054  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_10  arc_capacity_920  -30
    arc_1_9_10  connected_order_arc_921  -10
    arc_1_9_10  out_degree_1049  1
    arc_1_9_10  in_degree_1056  1
    arc_1_9_10  original_T_including_depot_unload_1091  3.8283958278492823e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_10  arc_capacity_920  1
    load_1_9_10  free_load_conservation_1054  1
    load_1_9_10  free_load_conservation_1060  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_11  arc_capacity_922  -30
    arc_1_9_11  connected_order_arc_923  -10
    arc_1_9_11  out_degree_1049  1
    arc_1_9_11  in_degree_1062  1
    arc_1_9_11  original_T_including_depot_unload_1091  1.3126251897454844e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_11  arc_capacity_922  1
    load_1_9_11  free_load_conservation_1054  1
    load_1_9_11  free_load_conservation_1066  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_12  arc_capacity_924  -30
    arc_1_9_12  connected_order_arc_925  -10
    arc_1_9_12  out_degree_1049  1
    arc_1_9_12  in_degree_1068  1
    arc_1_9_12  original_T_including_depot_unload_1091  2.0239755898835604e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_12  arc_capacity_924  1
    load_1_9_12  free_load_conservation_1054  1
    load_1_9_12  free_load_conservation_1072  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_13  arc_capacity_926  -30
    arc_1_9_13  connected_order_arc_927  -10
    arc_1_9_13  out_degree_1049  1
    arc_1_9_13  in_degree_1074  1
    arc_1_9_13  original_T_including_depot_unload_1091  1.5255932363401953e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_13  arc_capacity_926  1
    load_1_9_13  free_load_conservation_1054  1
    load_1_9_13  free_load_conservation_1078  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_14  arc_capacity_928  -30
    arc_1_9_14  connected_order_arc_929  -10
    arc_1_9_14  out_degree_1049  1
    arc_1_9_14  in_degree_1080  1
    arc_1_9_14  original_T_including_depot_unload_1091  1.7671662790958783e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_14  arc_capacity_928  1
    load_1_9_14  free_load_conservation_1054  1
    load_1_9_14  free_load_conservation_1084  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_15  arc_capacity_930  -30
    arc_1_9_15  connected_order_arc_931  -10
    arc_1_9_15  out_degree_1049  1
    arc_1_9_15  in_degree_1086  1
    arc_1_9_15  original_T_including_depot_unload_1091  1.7340603255343296e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_15  arc_capacity_930  1
    load_1_9_15  free_load_conservation_1054  1
    load_1_9_15  free_load_conservation_1090  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_0  arc_capacity_932  -30
    arc_1_10_0  depot_return_or_bypass_1035  1
    arc_1_10_0  out_degree_1055  1
    arc_1_10_0  original_T_including_depot_unload_1091  2.3234267380118886e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_0  arc_capacity_932  1
    load_1_10_0  free_load_conservation_1060  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_7  arc_capacity_933  -30
    arc_1_10_7  connected_order_arc_934  -10
    arc_1_10_7  in_degree_1037  1
    arc_1_10_7  out_degree_1055  1
    arc_1_10_7  original_T_including_depot_unload_1091  2.5651522766561479e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_7  arc_capacity_933  1
    load_1_10_7  segment_load_conservation_1040  -1
    load_1_10_7  segment_prefix_lb_1041  1
    load_1_10_7  segment_prefix_ub_1042  1
    load_1_10_7  free_load_conservation_1060  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_8  arc_capacity_935  -30
    arc_1_10_8  connected_order_arc_936  -10
    arc_1_10_8  in_degree_1044  1
    arc_1_10_8  out_degree_1055  1
    arc_1_10_8  original_T_including_depot_unload_1091  4.1686506413165080e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_8  arc_capacity_935  1
    load_1_10_8  free_load_conservation_1048  -1
    load_1_10_8  free_load_conservation_1060  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_9  arc_capacity_937  -30
    arc_1_10_9  connected_order_arc_938  -10
    arc_1_10_9  in_degree_1050  1
    arc_1_10_9  out_degree_1055  1
    arc_1_10_9  original_T_including_depot_unload_1091  3.8283958278492823e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_9  arc_capacity_937  1
    load_1_10_9  free_load_conservation_1054  -1
    load_1_10_9  free_load_conservation_1060  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_11  arc_capacity_939  -30
    arc_1_10_11  connected_order_arc_940  -10
    arc_1_10_11  out_degree_1055  1
    arc_1_10_11  in_degree_1062  1
    arc_1_10_11  original_T_including_depot_unload_1091  3.7182308190042463e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_11  arc_capacity_939  1
    load_1_10_11  free_load_conservation_1060  1
    load_1_10_11  free_load_conservation_1066  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_12  arc_capacity_941  -30
    arc_1_10_12  connected_order_arc_942  -10
    arc_1_10_12  out_degree_1055  1
    arc_1_10_12  in_degree_1068  1
    arc_1_10_12  original_T_including_depot_unload_1091  2.5683172431027456e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_12  arc_capacity_941  1
    load_1_10_12  free_load_conservation_1060  1
    load_1_10_12  free_load_conservation_1072  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_13  arc_capacity_943  -30
    arc_1_10_13  connected_order_arc_944  -10
    arc_1_10_13  out_degree_1055  1
    arc_1_10_13  in_degree_1074  1
    arc_1_10_13  original_T_including_depot_unload_1091  2.4160844235310037e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_13  arc_capacity_943  1
    load_1_10_13  free_load_conservation_1060  1
    load_1_10_13  free_load_conservation_1078  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_14  arc_capacity_945  -30
    arc_1_10_14  connected_order_arc_946  -10
    arc_1_10_14  out_degree_1055  1
    arc_1_10_14  in_degree_1080  1
    arc_1_10_14  original_T_including_depot_unload_1091  2.6728511574036233e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_14  arc_capacity_945  1
    load_1_10_14  free_load_conservation_1060  1
    load_1_10_14  free_load_conservation_1084  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_15  arc_capacity_947  -30
    arc_1_10_15  connected_order_arc_948  -10
    arc_1_10_15  out_degree_1055  1
    arc_1_10_15  in_degree_1086  1
    arc_1_10_15  original_T_including_depot_unload_1091  2.7957126389480295e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_15  arc_capacity_947  1
    load_1_10_15  free_load_conservation_1060  1
    load_1_10_15  free_load_conservation_1090  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_0  arc_capacity_949  -30
    arc_1_11_0  depot_return_or_bypass_1035  1
    arc_1_11_0  out_degree_1061  1
    arc_1_11_0  original_T_including_depot_unload_1091  1739.61165920636
    MARKER    'MARKER'                 'INTEND'
    load_1_11_0  arc_capacity_949  1
    load_1_11_0  free_load_conservation_1066  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_7  arc_capacity_950  -30
    arc_1_11_7  connected_order_arc_951  -10
    arc_1_11_7  in_degree_1037  1
    arc_1_11_7  out_degree_1061  1
    arc_1_11_7  original_T_including_depot_unload_1091  1.9007789738787540e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_7  arc_capacity_950  1
    load_1_11_7  segment_load_conservation_1040  -1
    load_1_11_7  segment_prefix_lb_1041  1
    load_1_11_7  segment_prefix_ub_1042  1
    load_1_11_7  free_load_conservation_1066  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_8  arc_capacity_952  -30
    arc_1_11_8  connected_order_arc_953  -10
    arc_1_11_8  in_degree_1044  1
    arc_1_11_8  out_degree_1061  1
    arc_1_11_8  original_T_including_depot_unload_1091  5.5382752177930990e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_8  arc_capacity_952  1
    load_1_11_8  free_load_conservation_1048  -1
    load_1_11_8  free_load_conservation_1066  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_9  arc_capacity_954  -30
    arc_1_11_9  connected_order_arc_955  -10
    arc_1_11_9  in_degree_1050  1
    arc_1_11_9  out_degree_1061  1
    arc_1_11_9  original_T_including_depot_unload_1091  1.3126251897454844e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_9  arc_capacity_954  1
    load_1_11_9  free_load_conservation_1054  -1
    load_1_11_9  free_load_conservation_1066  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_10  arc_capacity_956  -30
    arc_1_11_10  connected_order_arc_957  -10
    arc_1_11_10  in_degree_1056  1
    arc_1_11_10  out_degree_1061  1
    arc_1_11_10  original_T_including_depot_unload_1091  3.7182308190042463e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_10  arc_capacity_956  1
    load_1_11_10  free_load_conservation_1060  -1
    load_1_11_10  free_load_conservation_1066  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_12  arc_capacity_958  -30
    arc_1_11_12  connected_order_arc_959  -10
    arc_1_11_12  out_degree_1061  1
    arc_1_11_12  in_degree_1068  1
    arc_1_11_12  original_T_including_depot_unload_1091  1.8934642770867222e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_12  arc_capacity_958  1
    load_1_11_12  free_load_conservation_1066  1
    load_1_11_12  free_load_conservation_1072  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_13  arc_capacity_960  -30
    arc_1_11_13  connected_order_arc_961  -10
    arc_1_11_13  out_degree_1061  1
    arc_1_11_13  in_degree_1074  1
    arc_1_11_13  original_T_including_depot_unload_1091  1.4443513852547251e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_13  arc_capacity_960  1
    load_1_11_13  free_load_conservation_1066  1
    load_1_11_13  free_load_conservation_1078  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_14  arc_capacity_962  -30
    arc_1_11_14  connected_order_arc_963  -10
    arc_1_11_14  out_degree_1061  1
    arc_1_11_14  in_degree_1080  1
    arc_1_11_14  original_T_including_depot_unload_1091  1.7279728905134273e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_14  arc_capacity_962  1
    load_1_11_14  free_load_conservation_1066  1
    load_1_11_14  free_load_conservation_1084  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_15  arc_capacity_964  -30
    arc_1_11_15  connected_order_arc_965  -10
    arc_1_11_15  out_degree_1061  1
    arc_1_11_15  in_degree_1086  1
    arc_1_11_15  original_T_including_depot_unload_1091  1.7037372759708057e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_15  arc_capacity_964  1
    load_1_11_15  free_load_conservation_1066  1
    load_1_11_15  free_load_conservation_1090  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_0  arc_capacity_966  -30
    arc_1_12_0  depot_return_or_bypass_1035  1
    arc_1_12_0  out_degree_1067  1
    arc_1_12_0  original_T_including_depot_unload_1091  2.0232971184291544e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_0  arc_capacity_966  1
    load_1_12_0  free_load_conservation_1072  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_7  arc_capacity_967  -30
    arc_1_12_7  connected_order_arc_968  -10
    arc_1_12_7  in_degree_1037  1
    arc_1_12_7  out_degree_1067  1
    arc_1_12_7  original_T_including_depot_unload_1091  2.4295946549751052e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_7  arc_capacity_967  1
    load_1_12_7  segment_load_conservation_1040  -1
    load_1_12_7  segment_prefix_lb_1041  1
    load_1_12_7  segment_prefix_ub_1042  1
    load_1_12_7  free_load_conservation_1072  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_8  arc_capacity_969  -30
    arc_1_12_8  connected_order_arc_970  -10
    arc_1_12_8  in_degree_1044  1
    arc_1_12_8  out_degree_1067  1
    arc_1_12_8  original_T_including_depot_unload_1091  2.0819438297758261e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_8  arc_capacity_969  1
    load_1_12_8  free_load_conservation_1048  -1
    load_1_12_8  free_load_conservation_1072  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_9  arc_capacity_971  -30
    arc_1_12_9  connected_order_arc_972  -10
    arc_1_12_9  in_degree_1050  1
    arc_1_12_9  out_degree_1067  1
    arc_1_12_9  original_T_including_depot_unload_1091  2.0239755898835604e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_9  arc_capacity_971  1
    load_1_12_9  free_load_conservation_1054  -1
    load_1_12_9  free_load_conservation_1072  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_10  arc_capacity_973  -30
    arc_1_12_10  connected_order_arc_974  -10
    arc_1_12_10  in_degree_1056  1
    arc_1_12_10  out_degree_1067  1
    arc_1_12_10  original_T_including_depot_unload_1091  2.5683172431027456e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_10  arc_capacity_973  1
    load_1_12_10  free_load_conservation_1060  -1
    load_1_12_10  free_load_conservation_1072  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_11  arc_capacity_975  -30
    arc_1_12_11  connected_order_arc_976  -10
    arc_1_12_11  in_degree_1062  1
    arc_1_12_11  out_degree_1067  1
    arc_1_12_11  original_T_including_depot_unload_1091  1.8934642770867222e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_11  arc_capacity_975  1
    load_1_12_11  free_load_conservation_1066  -1
    load_1_12_11  free_load_conservation_1072  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_13  arc_capacity_977  -30
    arc_1_12_13  connected_order_arc_978  -10
    arc_1_12_13  out_degree_1067  1
    arc_1_12_13  in_degree_1074  1
    arc_1_12_13  original_T_including_depot_unload_1091  1.7165475198920165e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_13  arc_capacity_977  1
    load_1_12_13  free_load_conservation_1072  1
    load_1_12_13  free_load_conservation_1078  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_14  arc_capacity_979  -30
    arc_1_12_14  connected_order_arc_980  -10
    arc_1_12_14  out_degree_1067  1
    arc_1_12_14  in_degree_1080  1
    arc_1_12_14  original_T_including_depot_unload_1091  2.3561201725625019e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_14  arc_capacity_979  1
    load_1_12_14  free_load_conservation_1072  1
    load_1_12_14  free_load_conservation_1084  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_15  arc_capacity_981  -30
    arc_1_12_15  connected_order_arc_982  -10
    arc_1_12_15  out_degree_1067  1
    arc_1_12_15  in_degree_1086  1
    arc_1_12_15  original_T_including_depot_unload_1091  2.4370949895474209e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_15  arc_capacity_981  1
    load_1_12_15  free_load_conservation_1072  1
    load_1_12_15  free_load_conservation_1090  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_0  arc_capacity_983  -30
    arc_1_13_0  depot_return_or_bypass_1035  1
    arc_1_13_0  out_degree_1073  1
    arc_1_13_0  original_T_including_depot_unload_1091  3.5937232665424995e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_0  arc_capacity_983  1
    load_1_13_0  free_load_conservation_1078  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_7  arc_capacity_984  -30
    arc_1_13_7  connected_order_arc_985  -10
    arc_1_13_7  in_degree_1037  1
    arc_1_13_7  out_degree_1073  1
    arc_1_13_7  original_T_including_depot_unload_1091  7.2365484333226220e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_7  arc_capacity_984  1
    load_1_13_7  segment_load_conservation_1040  -1
    load_1_13_7  segment_prefix_lb_1041  1
    load_1_13_7  segment_prefix_ub_1042  1
    load_1_13_7  free_load_conservation_1078  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_8  arc_capacity_986  -30
    arc_1_13_8  connected_order_arc_987  -10
    arc_1_13_8  in_degree_1044  1
    arc_1_13_8  out_degree_1073  1
    arc_1_13_8  original_T_including_depot_unload_1091  1.9791430726365086e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_8  arc_capacity_986  1
    load_1_13_8  free_load_conservation_1048  -1
    load_1_13_8  free_load_conservation_1078  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_9  arc_capacity_988  -30
    arc_1_13_9  connected_order_arc_989  -10
    arc_1_13_9  in_degree_1050  1
    arc_1_13_9  out_degree_1073  1
    arc_1_13_9  original_T_including_depot_unload_1091  1.5255932363401953e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_9  arc_capacity_988  1
    load_1_13_9  free_load_conservation_1054  -1
    load_1_13_9  free_load_conservation_1078  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_10  arc_capacity_990  -30
    arc_1_13_10  connected_order_arc_991  -10
    arc_1_13_10  in_degree_1056  1
    arc_1_13_10  out_degree_1073  1
    arc_1_13_10  original_T_including_depot_unload_1091  2.4160844235310037e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_10  arc_capacity_990  1
    load_1_13_10  free_load_conservation_1060  -1
    load_1_13_10  free_load_conservation_1078  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_11  arc_capacity_992  -30
    arc_1_13_11  connected_order_arc_993  -10
    arc_1_13_11  in_degree_1062  1
    arc_1_13_11  out_degree_1073  1
    arc_1_13_11  original_T_including_depot_unload_1091  1.4443513852547251e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_11  arc_capacity_992  1
    load_1_13_11  free_load_conservation_1066  -1
    load_1_13_11  free_load_conservation_1078  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_12  arc_capacity_994  -30
    arc_1_13_12  connected_order_arc_995  -10
    arc_1_13_12  in_degree_1068  1
    arc_1_13_12  out_degree_1073  1
    arc_1_13_12  original_T_including_depot_unload_1091  1.7165475198920165e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_12  arc_capacity_994  1
    load_1_13_12  free_load_conservation_1072  -1
    load_1_13_12  free_load_conservation_1078  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_14  arc_capacity_996  -30
    arc_1_13_14  connected_order_arc_997  -10
    arc_1_13_14  out_degree_1073  1
    arc_1_13_14  in_degree_1080  1
    arc_1_13_14  original_T_including_depot_unload_1091  6.3975035388222534e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_14  arc_capacity_996  1
    load_1_13_14  free_load_conservation_1078  1
    load_1_13_14  free_load_conservation_1084  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_15  arc_capacity_998  -30
    arc_1_13_15  connected_order_arc_999  -10
    arc_1_13_15  out_degree_1073  1
    arc_1_13_15  in_degree_1086  1
    arc_1_13_15  original_T_including_depot_unload_1091  7.2696582003770027e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_15  arc_capacity_998  1
    load_1_13_15  free_load_conservation_1078  1
    load_1_13_15  free_load_conservation_1090  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_0  arc_capacity_1000  -30
    arc_1_14_0  depot_return_or_bypass_1035  1
    arc_1_14_0  out_degree_1079  1
    arc_1_14_0  original_T_including_depot_unload_1091  4.0782796387128610e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_0  arc_capacity_1000  1
    load_1_14_0  free_load_conservation_1084  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_7  arc_capacity_1001  -30
    arc_1_14_7  connected_order_arc_1002  -10
    arc_1_14_7  in_degree_1037  1
    arc_1_14_7  out_degree_1079  1
    arc_1_14_7  original_T_including_depot_unload_1091  1.7839442696984972e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_7  arc_capacity_1001  1
    load_1_14_7  segment_load_conservation_1040  -1
    load_1_14_7  segment_prefix_lb_1041  1
    load_1_14_7  segment_prefix_ub_1042  1
    load_1_14_7  free_load_conservation_1084  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_8  arc_capacity_1003  -30
    arc_1_14_8  connected_order_arc_1004  -10
    arc_1_14_8  in_degree_1044  1
    arc_1_14_8  out_degree_1079  1
    arc_1_14_8  original_T_including_depot_unload_1091  2.2811398160464278e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_8  arc_capacity_1003  1
    load_1_14_8  free_load_conservation_1048  -1
    load_1_14_8  free_load_conservation_1084  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_9  arc_capacity_1005  -30
    arc_1_14_9  connected_order_arc_1006  -10
    arc_1_14_9  in_degree_1050  1
    arc_1_14_9  out_degree_1079  1
    arc_1_14_9  original_T_including_depot_unload_1091  1.7671662790958783e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_9  arc_capacity_1005  1
    load_1_14_9  free_load_conservation_1054  -1
    load_1_14_9  free_load_conservation_1084  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_10  arc_capacity_1007  -30
    arc_1_14_10  connected_order_arc_1008  -10
    arc_1_14_10  in_degree_1056  1
    arc_1_14_10  out_degree_1079  1
    arc_1_14_10  original_T_including_depot_unload_1091  2.6728511574036233e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_10  arc_capacity_1007  1
    load_1_14_10  free_load_conservation_1060  -1
    load_1_14_10  free_load_conservation_1084  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_11  arc_capacity_1009  -30
    arc_1_14_11  connected_order_arc_1010  -10
    arc_1_14_11  in_degree_1062  1
    arc_1_14_11  out_degree_1079  1
    arc_1_14_11  original_T_including_depot_unload_1091  1.7279728905134273e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_11  arc_capacity_1009  1
    load_1_14_11  free_load_conservation_1066  -1
    load_1_14_11  free_load_conservation_1084  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_12  arc_capacity_1011  -30
    arc_1_14_12  connected_order_arc_1012  -10
    arc_1_14_12  in_degree_1068  1
    arc_1_14_12  out_degree_1079  1
    arc_1_14_12  original_T_including_depot_unload_1091  2.3561201725625019e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_12  arc_capacity_1011  1
    load_1_14_12  free_load_conservation_1072  -1
    load_1_14_12  free_load_conservation_1084  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_13  arc_capacity_1013  -30
    arc_1_14_13  connected_order_arc_1014  -10
    arc_1_14_13  in_degree_1074  1
    arc_1_14_13  out_degree_1079  1
    arc_1_14_13  original_T_including_depot_unload_1091  6.3975035388222534e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_13  arc_capacity_1013  1
    load_1_14_13  free_load_conservation_1078  -1
    load_1_14_13  free_load_conservation_1084  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_15  arc_capacity_1015  -30
    arc_1_14_15  connected_order_arc_1016  -10
    arc_1_14_15  out_degree_1079  1
    arc_1_14_15  in_degree_1086  1
    arc_1_14_15  original_T_including_depot_unload_1091  1.2480053261465446e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_15  arc_capacity_1015  1
    load_1_14_15  free_load_conservation_1084  1
    load_1_14_15  free_load_conservation_1090  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_0  arc_capacity_1017  -30
    arc_1_15_0  depot_return_or_bypass_1035  1
    arc_1_15_0  out_degree_1085  1
    arc_1_15_0  original_T_including_depot_unload_1091  5.2774046204590661e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_0  arc_capacity_1017  1
    load_1_15_0  free_load_conservation_1090  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_7  arc_capacity_1018  -30
    arc_1_15_7  connected_order_arc_1019  -10
    arc_1_15_7  in_degree_1037  1
    arc_1_15_7  out_degree_1085  1
    arc_1_15_7  original_T_including_depot_unload_1091  2.6178398366762252e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_7  arc_capacity_1018  1
    load_1_15_7  segment_load_conservation_1040  -1
    load_1_15_7  segment_prefix_lb_1041  1
    load_1_15_7  segment_prefix_ub_1042  1
    load_1_15_7  free_load_conservation_1090  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_8  arc_capacity_1020  -30
    arc_1_15_8  connected_order_arc_1021  -10
    arc_1_15_8  in_degree_1044  1
    arc_1_15_8  out_degree_1085  1
    arc_1_15_8  original_T_including_depot_unload_1091  2.2541698308553673e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_8  arc_capacity_1020  1
    load_1_15_8  free_load_conservation_1048  -1
    load_1_15_8  free_load_conservation_1090  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_9  arc_capacity_1022  -30
    arc_1_15_9  connected_order_arc_1023  -10
    arc_1_15_9  in_degree_1050  1
    arc_1_15_9  out_degree_1085  1
    arc_1_15_9  original_T_including_depot_unload_1091  1.7340603255343296e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_9  arc_capacity_1022  1
    load_1_15_9  free_load_conservation_1054  -1
    load_1_15_9  free_load_conservation_1090  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_10  arc_capacity_1024  -30
    arc_1_15_10  connected_order_arc_1025  -10
    arc_1_15_10  in_degree_1056  1
    arc_1_15_10  out_degree_1085  1
    arc_1_15_10  original_T_including_depot_unload_1091  2.7957126389480295e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_10  arc_capacity_1024  1
    load_1_15_10  free_load_conservation_1060  -1
    load_1_15_10  free_load_conservation_1090  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_11  arc_capacity_1026  -30
    arc_1_15_11  connected_order_arc_1027  -10
    arc_1_15_11  in_degree_1062  1
    arc_1_15_11  out_degree_1085  1
    arc_1_15_11  original_T_including_depot_unload_1091  1.7037372759708057e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_11  arc_capacity_1026  1
    load_1_15_11  free_load_conservation_1066  -1
    load_1_15_11  free_load_conservation_1090  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_12  arc_capacity_1028  -30
    arc_1_15_12  connected_order_arc_1029  -10
    arc_1_15_12  in_degree_1068  1
    arc_1_15_12  out_degree_1085  1
    arc_1_15_12  original_T_including_depot_unload_1091  2.4370949895474209e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_12  arc_capacity_1028  1
    load_1_15_12  free_load_conservation_1072  -1
    load_1_15_12  free_load_conservation_1090  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_13  arc_capacity_1030  -30
    arc_1_15_13  connected_order_arc_1031  -10
    arc_1_15_13  in_degree_1074  1
    arc_1_15_13  out_degree_1085  1
    arc_1_15_13  original_T_including_depot_unload_1091  7.2696582003770027e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_13  arc_capacity_1030  1
    load_1_15_13  free_load_conservation_1078  -1
    load_1_15_13  free_load_conservation_1090  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_14  arc_capacity_1032  -30
    arc_1_15_14  connected_order_arc_1033  -10
    arc_1_15_14  in_degree_1080  1
    arc_1_15_14  out_degree_1085  1
    arc_1_15_14  original_T_including_depot_unload_1091  1.2480053261465446e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_14  arc_capacity_1032  1
    load_1_15_14  free_load_conservation_1084  -1
    load_1_15_14  free_load_conservation_1090  1
RHS
    RHS1      OBJ       -4.1940533673394620e-01
    RHS1      onehot_17_34  1
    RHS1      onehot_14_69  1
    RHS1      onehot_18_104  1
    RHS1      onehot_13_111  1
    RHS1      onehot_20_146  1
    RHS1      onehot_12_181  1
    RHS1      onehot_11_216  1
    RHS1      onehot_10_223  1
    RHS1      stock_ub_227  37
    RHS1      parent_nonstrict_scope_228  6.4131681871110269e-01
    RHS1      normalization_285  1
    RHS1      connected_order_arc_397  -14
    RHS1      connected_order_arc_399  -14
    RHS1      connected_order_arc_401  -14
    RHS1      connected_order_arc_403  -14
    RHS1      connected_order_arc_405  -14
    RHS1      connected_order_arc_407  -14
    RHS1      connected_order_arc_409  -14
    RHS1      connected_order_arc_411  -14
    RHS1      connected_order_arc_413  -14
    RHS1      connected_order_arc_415  -14
    RHS1      connected_order_arc_417  -14
    RHS1      connected_order_arc_419  -14
    RHS1      connected_order_arc_421  -14
    RHS1      connected_order_arc_424  -14
    RHS1      connected_order_arc_426  -14
    RHS1      connected_order_arc_428  -14
    RHS1      connected_order_arc_430  -14
    RHS1      connected_order_arc_432  -14
    RHS1      connected_order_arc_434  -14
    RHS1      connected_order_arc_436  -14
    RHS1      connected_order_arc_438  -14
    RHS1      connected_order_arc_440  -14
    RHS1      connected_order_arc_442  -14
    RHS1      connected_order_arc_444  -14
    RHS1      connected_order_arc_446  -14
    RHS1      connected_order_arc_448  -14
    RHS1      connected_order_arc_451  -14
    RHS1      connected_order_arc_453  -14
    RHS1      connected_order_arc_455  -14
    RHS1      connected_order_arc_457  -14
    RHS1      connected_order_arc_459  -14
    RHS1      connected_order_arc_461  -14
    RHS1      connected_order_arc_463  -14
    RHS1      connected_order_arc_465  -14
    RHS1      connected_order_arc_467  -14
    RHS1      connected_order_arc_469  -14
    RHS1      connected_order_arc_471  -14
    RHS1      connected_order_arc_473  -14
    RHS1      connected_order_arc_475  -14
    RHS1      connected_order_arc_478  -14
    RHS1      connected_order_arc_480  -14
    RHS1      connected_order_arc_482  -14
    RHS1      connected_order_arc_484  -14
    RHS1      connected_order_arc_486  -14
    RHS1      connected_order_arc_488  -14
    RHS1      connected_order_arc_490  -14
    RHS1      connected_order_arc_492  -14
    RHS1      connected_order_arc_494  -14
    RHS1      connected_order_arc_496  -14
    RHS1      connected_order_arc_498  -14
    RHS1      connected_order_arc_500  -14
    RHS1      connected_order_arc_502  -14
    RHS1      connected_order_arc_505  -14
    RHS1      connected_order_arc_507  -14
    RHS1      connected_order_arc_509  -14
    RHS1      connected_order_arc_511  -14
    RHS1      connected_order_arc_513  -14
    RHS1      connected_order_arc_515  -14
    RHS1      connected_order_arc_517  -14
    RHS1      connected_order_arc_519  -14
    RHS1      connected_order_arc_521  -14
    RHS1      connected_order_arc_523  -14
    RHS1      connected_order_arc_525  -14
    RHS1      connected_order_arc_527  -14
    RHS1      connected_order_arc_529  -14
    RHS1      connected_order_arc_532  -14
    RHS1      connected_order_arc_534  -14
    RHS1      connected_order_arc_536  -14
    RHS1      connected_order_arc_538  -14
    RHS1      connected_order_arc_540  -14
    RHS1      connected_order_arc_542  -14
    RHS1      connected_order_arc_544  -14
    RHS1      connected_order_arc_546  -14
    RHS1      connected_order_arc_548  -14
    RHS1      connected_order_arc_550  -14
    RHS1      connected_order_arc_552  -14
    RHS1      connected_order_arc_554  -14
    RHS1      connected_order_arc_556  -14
    RHS1      connected_order_arc_559  -14
    RHS1      connected_order_arc_561  -14
    RHS1      connected_order_arc_563  -14
    RHS1      connected_order_arc_565  -14
    RHS1      connected_order_arc_567  -14
    RHS1      connected_order_arc_569  -14
    RHS1      connected_order_arc_571  -14
    RHS1      connected_order_arc_573  -14
    RHS1      connected_order_arc_575  -14
    RHS1      connected_order_arc_577  -14
    RHS1      connected_order_arc_579  -14
    RHS1      connected_order_arc_581  -14
    RHS1      connected_order_arc_583  -14
    RHS1      connected_order_arc_586  -14
    RHS1      connected_order_arc_588  -14
    RHS1      connected_order_arc_590  -14
    RHS1      connected_order_arc_592  -14
    RHS1      connected_order_arc_594  -14
    RHS1      connected_order_arc_596  -14
    RHS1      connected_order_arc_598  -14
    RHS1      connected_order_arc_600  -14
    RHS1      connected_order_arc_602  -14
    RHS1      connected_order_arc_604  -14
    RHS1      connected_order_arc_606  -14
    RHS1      connected_order_arc_608  -14
    RHS1      connected_order_arc_610  -14
    RHS1      connected_order_arc_613  -14
    RHS1      connected_order_arc_615  -14
    RHS1      connected_order_arc_617  -14
    RHS1      connected_order_arc_619  -14
    RHS1      connected_order_arc_621  -14
    RHS1      connected_order_arc_623  -14
    RHS1      connected_order_arc_625  -14
    RHS1      connected_order_arc_627  -14
    RHS1      connected_order_arc_629  -14
    RHS1      connected_order_arc_631  -14
    RHS1      connected_order_arc_633  -14
    RHS1      connected_order_arc_635  -14
    RHS1      connected_order_arc_637  -14
    RHS1      connected_order_arc_640  -14
    RHS1      connected_order_arc_642  -14
    RHS1      connected_order_arc_644  -14
    RHS1      connected_order_arc_646  -14
    RHS1      connected_order_arc_648  -14
    RHS1      connected_order_arc_650  -14
    RHS1      connected_order_arc_652  -14
    RHS1      connected_order_arc_654  -14
    RHS1      connected_order_arc_656  -14
    RHS1      connected_order_arc_658  -14
    RHS1      connected_order_arc_660  -14
    RHS1      connected_order_arc_662  -14
    RHS1      connected_order_arc_664  -14
    RHS1      connected_order_arc_667  -14
    RHS1      connected_order_arc_669  -14
    RHS1      connected_order_arc_671  -14
    RHS1      connected_order_arc_673  -14
    RHS1      connected_order_arc_675  -14
    RHS1      connected_order_arc_677  -14
    RHS1      connected_order_arc_679  -14
    RHS1      connected_order_arc_681  -14
    RHS1      connected_order_arc_683  -14
    RHS1      connected_order_arc_685  -14
    RHS1      connected_order_arc_687  -14
    RHS1      connected_order_arc_689  -14
    RHS1      connected_order_arc_691  -14
    RHS1      connected_order_arc_694  -14
    RHS1      connected_order_arc_696  -14
    RHS1      connected_order_arc_698  -14
    RHS1      connected_order_arc_700  -14
    RHS1      connected_order_arc_702  -14
    RHS1      connected_order_arc_704  -14
    RHS1      connected_order_arc_706  -14
    RHS1      connected_order_arc_708  -14
    RHS1      connected_order_arc_710  -14
    RHS1      connected_order_arc_712  -14
    RHS1      connected_order_arc_714  -14
    RHS1      connected_order_arc_716  -14
    RHS1      connected_order_arc_718  -14
    RHS1      connected_order_arc_721  -14
    RHS1      connected_order_arc_723  -14
    RHS1      connected_order_arc_725  -14
    RHS1      connected_order_arc_727  -14
    RHS1      connected_order_arc_729  -14
    RHS1      connected_order_arc_731  -14
    RHS1      connected_order_arc_733  -14
    RHS1      connected_order_arc_735  -14
    RHS1      connected_order_arc_737  -14
    RHS1      connected_order_arc_739  -14
    RHS1      connected_order_arc_741  -14
    RHS1      connected_order_arc_743  -14
    RHS1      connected_order_arc_745  -14
    RHS1      connected_order_arc_748  -14
    RHS1      connected_order_arc_750  -14
    RHS1      connected_order_arc_752  -14
    RHS1      connected_order_arc_754  -14
    RHS1      connected_order_arc_756  -14
    RHS1      connected_order_arc_758  -14
    RHS1      connected_order_arc_760  -14
    RHS1      connected_order_arc_762  -14
    RHS1      connected_order_arc_764  -14
    RHS1      connected_order_arc_766  -14
    RHS1      connected_order_arc_768  -14
    RHS1      connected_order_arc_770  -14
    RHS1      connected_order_arc_772  -14
    RHS1      depot_departure_or_bypass_773  1
    RHS1      depot_return_or_bypass_774  1
    RHS1      segment_load_conservation_779  3
    RHS1      segment_prefix_ub_781  27
    RHS1      segment_load_conservation_786  -3
    RHS1      segment_prefix_lb_787  3
    RHS1      segment_prefix_ub_788  30
    RHS1      segment_load_conservation_793  4
    RHS1      segment_prefix_ub_795  26
    RHS1      segment_load_conservation_800  -1
    RHS1      segment_prefix_lb_801  1
    RHS1      segment_prefix_ub_802  30
    RHS1      segment_load_conservation_807  -1
    RHS1      segment_prefix_lb_808  1
    RHS1      segment_prefix_ub_809  30
    RHS1      segment_load_conservation_814  -2
    RHS1      segment_prefix_lb_815  2
    RHS1      segment_prefix_ub_816  30
    RHS1      fixed_segment_relative_order_865  1
    RHS1      fixed_segment_relative_order_866  1
    RHS1      fixed_segment_relative_order_867  1
    RHS1      fixed_segment_relative_order_868  1
    RHS1      fixed_segment_relative_order_869  1
    RHS1      original_T_including_depot_unload_870  3960
    RHS1      connected_order_arc_883  -9
    RHS1      connected_order_arc_885  -9
    RHS1      connected_order_arc_887  -9
    RHS1      connected_order_arc_889  -9
    RHS1      connected_order_arc_891  -9
    RHS1      connected_order_arc_893  -9
    RHS1      connected_order_arc_895  -9
    RHS1      connected_order_arc_897  -9
    RHS1      connected_order_arc_900  -9
    RHS1      connected_order_arc_902  -9
    RHS1      connected_order_arc_904  -9
    RHS1      connected_order_arc_906  -9
    RHS1      connected_order_arc_908  -9
    RHS1      connected_order_arc_910  -9
    RHS1      connected_order_arc_912  -9
    RHS1      connected_order_arc_914  -9
    RHS1      connected_order_arc_917  -9
    RHS1      connected_order_arc_919  -9
    RHS1      connected_order_arc_921  -9
    RHS1      connected_order_arc_923  -9
    RHS1      connected_order_arc_925  -9
    RHS1      connected_order_arc_927  -9
    RHS1      connected_order_arc_929  -9
    RHS1      connected_order_arc_931  -9
    RHS1      connected_order_arc_934  -9
    RHS1      connected_order_arc_936  -9
    RHS1      connected_order_arc_938  -9
    RHS1      connected_order_arc_940  -9
    RHS1      connected_order_arc_942  -9
    RHS1      connected_order_arc_944  -9
    RHS1      connected_order_arc_946  -9
    RHS1      connected_order_arc_948  -9
    RHS1      connected_order_arc_951  -9
    RHS1      connected_order_arc_953  -9
    RHS1      connected_order_arc_955  -9
    RHS1      connected_order_arc_957  -9
    RHS1      connected_order_arc_959  -9
    RHS1      connected_order_arc_961  -9
    RHS1      connected_order_arc_963  -9
    RHS1      connected_order_arc_965  -9
    RHS1      connected_order_arc_968  -9
    RHS1      connected_order_arc_970  -9
    RHS1      connected_order_arc_972  -9
    RHS1      connected_order_arc_974  -9
    RHS1      connected_order_arc_976  -9
    RHS1      connected_order_arc_978  -9
    RHS1      connected_order_arc_980  -9
    RHS1      connected_order_arc_982  -9
    RHS1      connected_order_arc_985  -9
    RHS1      connected_order_arc_987  -9
    RHS1      connected_order_arc_989  -9
    RHS1      connected_order_arc_991  -9
    RHS1      connected_order_arc_993  -9
    RHS1      connected_order_arc_995  -9
    RHS1      connected_order_arc_997  -9
    RHS1      connected_order_arc_999  -9
    RHS1      connected_order_arc_1002  -9
    RHS1      connected_order_arc_1004  -9
    RHS1      connected_order_arc_1006  -9
    RHS1      connected_order_arc_1008  -9
    RHS1      connected_order_arc_1010  -9
    RHS1      connected_order_arc_1012  -9
    RHS1      connected_order_arc_1014  -9
    RHS1      connected_order_arc_1016  -9
    RHS1      connected_order_arc_1019  -9
    RHS1      connected_order_arc_1021  -9
    RHS1      connected_order_arc_1023  -9
    RHS1      connected_order_arc_1025  -9
    RHS1      connected_order_arc_1027  -9
    RHS1      connected_order_arc_1029  -9
    RHS1      connected_order_arc_1031  -9
    RHS1      connected_order_arc_1033  -9
    RHS1      depot_departure_or_bypass_1034  1
    RHS1      depot_return_or_bypass_1035  1
    RHS1      segment_load_conservation_1040  -1
    RHS1      segment_prefix_lb_1041  1
    RHS1      segment_prefix_ub_1042  30
    RHS1      original_T_including_depot_unload_1091  4800
BOUNDS
 LO BND1      t         4.7052672853174743e-02
 UP BND1      t         1.3705335291252085e-01
 UP BND1      q         0.753053928089682
 BV BND1      x_17_0  
 UP BND1      w_17_0    1.3705335291252085e-01
 BV BND1      x_17_1  
 UP BND1      w_17_1    1.3705335291252085e-01
 BV BND1      x_17_2  
 UP BND1      w_17_2    1.3705335291252085e-01
 BV BND1      x_17_3  
 UP BND1      w_17_3    1.3705335291252085e-01
 BV BND1      x_17_4  
 UP BND1      w_17_4    1.3705335291252085e-01
 BV BND1      x_17_5  
 UP BND1      w_17_5    1.3705335291252085e-01
 BV BND1      x_17_6  
 UP BND1      w_17_6    1.3705335291252085e-01
 BV BND1      x_17_7  
 UP BND1      w_17_7    1.3705335291252085e-01
 BV BND1      x_17_8  
 UP BND1      w_17_8    1.3705335291252085e-01
 BV BND1      x_17_9  
 UP BND1      w_17_9    1.3705335291252085e-01
 BV BND1      x_17_10 
 UP BND1      w_17_10   1.3705335291252085e-01
 BV BND1      x_17_11 
 UP BND1      w_17_11   1.3705335291252085e-01
 BV BND1      x_17_12 
 UP BND1      w_17_12   1.3705335291252085e-01
 BV BND1      x_17_13 
 UP BND1      w_17_13   1.3705335291252085e-01
 BV BND1      x_17_14 
 UP BND1      w_17_14   1.3705335291252085e-01
 BV BND1      x_17_15 
 UP BND1      w_17_15   1.3705335291252085e-01
 BV BND1      x_17_16 
 UP BND1      w_17_16   1.3705335291252085e-01
 UP BND1      rho_17    1
 BV BND1      x_14_0  
 UP BND1      w_14_0    1.3705335291252085e-01
 BV BND1      x_14_1  
 UP BND1      w_14_1    1.3705335291252085e-01
 BV BND1      x_14_2  
 UP BND1      w_14_2    1.3705335291252085e-01
 BV BND1      x_14_3  
 UP BND1      w_14_3    1.3705335291252085e-01
 BV BND1      x_14_4  
 UP BND1      w_14_4    1.3705335291252085e-01
 BV BND1      x_14_5  
 UP BND1      w_14_5    1.3705335291252085e-01
 BV BND1      x_14_6  
 UP BND1      w_14_6    1.3705335291252085e-01
 BV BND1      x_14_7  
 UP BND1      w_14_7    1.3705335291252085e-01
 BV BND1      x_14_8  
 UP BND1      w_14_8    1.3705335291252085e-01
 BV BND1      x_14_9  
 UP BND1      w_14_9    1.3705335291252085e-01
 BV BND1      x_14_10 
 UP BND1      w_14_10   1.3705335291252085e-01
 BV BND1      x_14_11 
 UP BND1      w_14_11   1.3705335291252085e-01
 BV BND1      x_14_12 
 UP BND1      w_14_12   1.3705335291252085e-01
 BV BND1      x_14_13 
 UP BND1      w_14_13   1.3705335291252085e-01
 BV BND1      x_14_14 
 UP BND1      w_14_14   1.3705335291252085e-01
 BV BND1      x_14_15 
 UP BND1      w_14_15   1.3705335291252085e-01
 UP BND1      rho_14    1
 BV BND1      x_18_0  
 UP BND1      w_18_0    1.3705335291252085e-01
 BV BND1      x_18_1  
 UP BND1      w_18_1    1.3705335291252085e-01
 BV BND1      x_18_2  
 UP BND1      w_18_2    1.3705335291252085e-01
 BV BND1      x_18_3  
 UP BND1      w_18_3    1.3705335291252085e-01
 BV BND1      x_18_4  
 UP BND1      w_18_4    1.3705335291252085e-01
 BV BND1      x_18_5  
 UP BND1      w_18_5    1.3705335291252085e-01
 BV BND1      x_18_6  
 UP BND1      w_18_6    1.3705335291252085e-01
 BV BND1      x_18_7  
 UP BND1      w_18_7    1.3705335291252085e-01
 BV BND1      x_18_8  
 UP BND1      w_18_8    1.3705335291252085e-01
 BV BND1      x_18_9  
 UP BND1      w_18_9    1.3705335291252085e-01
 BV BND1      x_18_10 
 UP BND1      w_18_10   1.3705335291252085e-01
 BV BND1      x_18_11 
 UP BND1      w_18_11   1.3705335291252085e-01
 BV BND1      x_18_12 
 UP BND1      w_18_12   1.3705335291252085e-01
 BV BND1      x_18_13 
 UP BND1      w_18_13   1.3705335291252085e-01
 BV BND1      x_18_14 
 UP BND1      w_18_14   1.3705335291252085e-01
 BV BND1      x_18_15 
 UP BND1      w_18_15   1.3705335291252085e-01
 UP BND1      rho_18    1
 BV BND1      x_13_0  
 UP BND1      w_13_0    1.3705335291252085e-01
 BV BND1      x_13_1  
 UP BND1      w_13_1    1.3705335291252085e-01
 UP BND1      rho_13    1
 BV BND1      x_20_0  
 UP BND1      w_20_0    1.3705335291252085e-01
 BV BND1      x_20_1  
 UP BND1      w_20_1    1.3705335291252085e-01
 BV BND1      x_20_2  
 UP BND1      w_20_2    1.3705335291252085e-01
 BV BND1      x_20_3  
 UP BND1      w_20_3    1.3705335291252085e-01
 BV BND1      x_20_4  
 UP BND1      w_20_4    1.3705335291252085e-01
 BV BND1      x_20_5  
 UP BND1      w_20_5    1.3705335291252085e-01
 BV BND1      x_20_6  
 UP BND1      w_20_6    1.3705335291252085e-01
 BV BND1      x_20_7  
 UP BND1      w_20_7    1.3705335291252085e-01
 BV BND1      x_20_8  
 UP BND1      w_20_8    1.3705335291252085e-01
 BV BND1      x_20_9  
 UP BND1      w_20_9    1.3705335291252085e-01
 BV BND1      x_20_10 
 UP BND1      w_20_10   1.3705335291252085e-01
 BV BND1      x_20_11 
 UP BND1      w_20_11   1.3705335291252085e-01
 BV BND1      x_20_12 
 UP BND1      w_20_12   1.3705335291252085e-01
 BV BND1      x_20_13 
 UP BND1      w_20_13   1.3705335291252085e-01
 BV BND1      x_20_14 
 UP BND1      w_20_14   1.3705335291252085e-01
 BV BND1      x_20_15 
 UP BND1      w_20_15   1.3705335291252085e-01
 UP BND1      rho_20    1
 BV BND1      x_12_0  
 UP BND1      w_12_0    1.3705335291252085e-01
 BV BND1      x_12_1  
 UP BND1      w_12_1    1.3705335291252085e-01
 BV BND1      x_12_2  
 UP BND1      w_12_2    1.3705335291252085e-01
 BV BND1      x_12_3  
 UP BND1      w_12_3    1.3705335291252085e-01
 BV BND1      x_12_4  
 UP BND1      w_12_4    1.3705335291252085e-01
 BV BND1      x_12_5  
 UP BND1      w_12_5    1.3705335291252085e-01
 BV BND1      x_12_6  
 UP BND1      w_12_6    1.3705335291252085e-01
 BV BND1      x_12_7  
 UP BND1      w_12_7    1.3705335291252085e-01
 BV BND1      x_12_8  
 UP BND1      w_12_8    1.3705335291252085e-01
 BV BND1      x_12_9  
 UP BND1      w_12_9    1.3705335291252085e-01
 BV BND1      x_12_10 
 UP BND1      w_12_10   1.3705335291252085e-01
 BV BND1      x_12_11 
 UP BND1      w_12_11   1.3705335291252085e-01
 BV BND1      x_12_12 
 UP BND1      w_12_12   1.3705335291252085e-01
 BV BND1      x_12_13 
 UP BND1      w_12_13   1.3705335291252085e-01
 BV BND1      x_12_14 
 UP BND1      w_12_14   1.3705335291252085e-01
 BV BND1      x_12_15 
 UP BND1      w_12_15   1.3705335291252085e-01
 UP BND1      rho_12    1
 BV BND1      x_11_0  
 UP BND1      w_11_0    1.3705335291252085e-01
 BV BND1      x_11_1  
 UP BND1      w_11_1    1.3705335291252085e-01
 BV BND1      x_11_2  
 UP BND1      w_11_2    1.3705335291252085e-01
 BV BND1      x_11_3  
 UP BND1      w_11_3    1.3705335291252085e-01
 BV BND1      x_11_4  
 UP BND1      w_11_4    1.3705335291252085e-01
 BV BND1      x_11_5  
 UP BND1      w_11_5    1.3705335291252085e-01
 BV BND1      x_11_6  
 UP BND1      w_11_6    1.3705335291252085e-01
 BV BND1      x_11_7  
 UP BND1      w_11_7    1.3705335291252085e-01
 BV BND1      x_11_8  
 UP BND1      w_11_8    1.3705335291252085e-01
 BV BND1      x_11_9  
 UP BND1      w_11_9    1.3705335291252085e-01
 BV BND1      x_11_10 
 UP BND1      w_11_10   1.3705335291252085e-01
 BV BND1      x_11_11 
 UP BND1      w_11_11   1.3705335291252085e-01
 BV BND1      x_11_12 
 UP BND1      w_11_12   1.3705335291252085e-01
 BV BND1      x_11_13 
 UP BND1      w_11_13   1.3705335291252085e-01
 BV BND1      x_11_14 
 UP BND1      w_11_14   1.3705335291252085e-01
 BV BND1      x_11_15 
 UP BND1      w_11_15   1.3705335291252085e-01
 UP BND1      rho_11    1
 BV BND1      x_10_0  
 UP BND1      w_10_0    1.3705335291252085e-01
 BV BND1      x_10_1  
 UP BND1      w_10_1    1.3705335291252085e-01
 UP BND1      rho_10    1
 UP BND1      a_17_14   1
 UP BND1      a_17_18   1
 UP BND1      a_17_13   1
 UP BND1      a_17_20   1
 UP BND1      a_17_12   1
 UP BND1      a_17_11   1
 UP BND1      a_17_10   1
 UP BND1      a_14_18   1
 UP BND1      a_14_13   1
 UP BND1      a_14_20   1
 UP BND1      a_14_12   1
 UP BND1      a_14_11   1
 UP BND1      a_14_10   1
 UP BND1      a_18_13   1
 UP BND1      a_18_20   1
 UP BND1      a_18_12   1
 UP BND1      a_18_11   1
 UP BND1      a_18_10   1
 UP BND1      a_13_20   1
 UP BND1      a_13_12   1
 UP BND1      a_13_11   1
 UP BND1      a_13_10   1
 UP BND1      a_20_12   1
 UP BND1      a_20_11   1
 UP BND1      a_20_10   1
 UP BND1      a_12_11   1
 UP BND1      a_12_10   1
 UP BND1      a_11_10   1
 BV BND1      service_0_17_0
 BV BND1      service_0_17_1
 BV BND1      service_0_17_2
 BV BND1      service_0_17_4
 BV BND1      service_0_17_5
 BV BND1      service_0_17_6
 BV BND1      service_0_17_7
 BV BND1      service_0_17_8
 BV BND1      service_0_17_9
 BV BND1      service_0_17_10
 BV BND1      service_0_17_11
 BV BND1      service_0_17_12
 BV BND1      service_0_17_13
 BV BND1      service_0_17_14
 BV BND1      service_0_17_15
 BV BND1      service_0_17_16
 BV BND1      service_1_17_0
 BV BND1      service_1_17_1
 BV BND1      service_1_17_2
 BV BND1      service_1_17_4
 BV BND1      service_1_17_5
 BV BND1      service_1_17_6
 BV BND1      service_1_17_7
 BV BND1      service_1_17_8
 BV BND1      service_1_17_9
 BV BND1      service_1_17_10
 BV BND1      service_1_17_11
 BV BND1      service_1_17_12
 BV BND1      service_1_17_13
 BV BND1      service_1_17_14
 BV BND1      service_1_17_15
 BV BND1      service_1_17_16
 BV BND1      service_0_14_0
 BV BND1      service_0_14_1
 BV BND1      service_0_14_2
 BV BND1      service_0_14_3
 BV BND1      service_0_14_4
 BV BND1      service_0_14_5
 BV BND1      service_0_14_6
 BV BND1      service_0_14_7
 BV BND1      service_0_14_8
 BV BND1      service_0_14_9
 BV BND1      service_0_14_10
 BV BND1      service_0_14_12
 BV BND1      service_0_14_13
 BV BND1      service_0_14_14
 BV BND1      service_0_14_15
 BV BND1      service_1_14_0
 BV BND1      service_1_14_1
 BV BND1      service_1_14_2
 BV BND1      service_1_14_3
 BV BND1      service_1_14_4
 BV BND1      service_1_14_5
 BV BND1      service_1_14_6
 BV BND1      service_1_14_7
 BV BND1      service_1_14_8
 BV BND1      service_1_14_9
 BV BND1      service_1_14_10
 BV BND1      service_1_14_12
 BV BND1      service_1_14_13
 BV BND1      service_1_14_14
 BV BND1      service_1_14_15
 BV BND1      service_0_18_1
 BV BND1      service_0_18_2
 BV BND1      service_0_18_3
 BV BND1      service_0_18_4
 BV BND1      service_0_18_5
 BV BND1      service_0_18_6
 BV BND1      service_0_18_7
 BV BND1      service_0_18_8
 BV BND1      service_0_18_9
 BV BND1      service_0_18_10
 BV BND1      service_0_18_11
 BV BND1      service_0_18_12
 BV BND1      service_0_18_13
 BV BND1      service_0_18_14
 BV BND1      service_0_18_15
 BV BND1      service_1_18_1
 BV BND1      service_1_18_2
 BV BND1      service_1_18_3
 BV BND1      service_1_18_4
 BV BND1      service_1_18_5
 BV BND1      service_1_18_6
 BV BND1      service_1_18_7
 BV BND1      service_1_18_8
 BV BND1      service_1_18_9
 BV BND1      service_1_18_10
 BV BND1      service_1_18_11
 BV BND1      service_1_18_12
 BV BND1      service_1_18_13
 BV BND1      service_1_18_14
 BV BND1      service_1_18_15
 BV BND1      service_0_13_1
 BV BND1      service_1_13_1
 BV BND1      service_0_20_0
 BV BND1      service_0_20_1
 BV BND1      service_0_20_2
 BV BND1      service_0_20_3
 BV BND1      service_0_20_4
 BV BND1      service_0_20_5
 BV BND1      service_0_20_6
 BV BND1      service_0_20_7
 BV BND1      service_0_20_8
 BV BND1      service_0_20_9
 BV BND1      service_0_20_10
 BV BND1      service_0_20_11
 BV BND1      service_0_20_13
 BV BND1      service_0_20_14
 BV BND1      service_0_20_15
 BV BND1      service_1_20_0
 BV BND1      service_1_20_1
 BV BND1      service_1_20_2
 BV BND1      service_1_20_3
 BV BND1      service_1_20_4
 BV BND1      service_1_20_5
 BV BND1      service_1_20_6
 BV BND1      service_1_20_7
 BV BND1      service_1_20_8
 BV BND1      service_1_20_9
 BV BND1      service_1_20_10
 BV BND1      service_1_20_11
 BV BND1      service_1_20_13
 BV BND1      service_1_20_14
 BV BND1      service_1_20_15
 BV BND1      service_0_12_0
 BV BND1      service_0_12_1
 BV BND1      service_0_12_2
 BV BND1      service_0_12_3
 BV BND1      service_0_12_4
 BV BND1      service_0_12_5
 BV BND1      service_0_12_6
 BV BND1      service_0_12_7
 BV BND1      service_0_12_8
 BV BND1      service_0_12_9
 BV BND1      service_0_12_10
 BV BND1      service_0_12_12
 BV BND1      service_0_12_13
 BV BND1      service_0_12_14
 BV BND1      service_0_12_15
 BV BND1      service_1_12_0
 BV BND1      service_1_12_1
 BV BND1      service_1_12_2
 BV BND1      service_1_12_3
 BV BND1      service_1_12_4
 BV BND1      service_1_12_5
 BV BND1      service_1_12_6
 BV BND1      service_1_12_7
 BV BND1      service_1_12_8
 BV BND1      service_1_12_9
 BV BND1      service_1_12_10
 BV BND1      service_1_12_12
 BV BND1      service_1_12_13
 BV BND1      service_1_12_14
 BV BND1      service_1_12_15
 BV BND1      service_0_11_0
 BV BND1      service_0_11_2
 BV BND1      service_0_11_3
 BV BND1      service_0_11_4
 BV BND1      service_0_11_5
 BV BND1      service_0_11_6
 BV BND1      service_0_11_7
 BV BND1      service_0_11_8
 BV BND1      service_0_11_9
 BV BND1      service_0_11_10
 BV BND1      service_0_11_11
 BV BND1      service_0_11_12
 BV BND1      service_0_11_13
 BV BND1      service_0_11_14
 BV BND1      service_0_11_15
 BV BND1      service_1_11_0
 BV BND1      service_1_11_2
 BV BND1      service_1_11_3
 BV BND1      service_1_11_4
 BV BND1      service_1_11_5
 BV BND1      service_1_11_6
 BV BND1      service_1_11_7
 BV BND1      service_1_11_8
 BV BND1      service_1_11_9
 BV BND1      service_1_11_10
 BV BND1      service_1_11_11
 BV BND1      service_1_11_12
 BV BND1      service_1_11_13
 BV BND1      service_1_11_14
 BV BND1      service_1_11_15
 BV BND1      service_0_10_1
 BV BND1      service_1_10_1
 FX BND1      visit_0_1  1
 UP BND1      order_0_1  14
 FX BND1      visit_0_2  1
 UP BND1      order_0_2  14
 FX BND1      visit_0_3  1
 UP BND1      order_0_3  14
 FX BND1      visit_0_4  1
 UP BND1      order_0_4  14
 FX BND1      visit_0_5  1
 UP BND1      order_0_5  14
 FX BND1      visit_0_6  1
 UP BND1      order_0_6  14
 UP BND1      visit_0_8  1
 UP BND1      order_0_8  14
 UP BND1      visit_0_9  1
 UP BND1      order_0_9  14
 UP BND1      visit_0_10  1
 UP BND1      order_0_10  14
 UP BND1      visit_0_11  1
 UP BND1      order_0_11  14
 UP BND1      visit_0_12  1
 UP BND1      order_0_12  14
 UP BND1      visit_0_13  1
 UP BND1      order_0_13  14
 UP BND1      visit_0_14  1
 UP BND1      order_0_14  14
 UP BND1      visit_0_15  1
 UP BND1      order_0_15  14
 BV BND1      arc_0_0_0
 FX BND1      load_0_0_0  0
 BV BND1      arc_0_0_1
 FX BND1      load_0_0_1  0
 BV BND1      arc_0_0_2
 FX BND1      load_0_0_2  0
 BV BND1      arc_0_0_3
 FX BND1      load_0_0_3  0
 BV BND1      arc_0_0_4
 FX BND1      load_0_0_4  0
 BV BND1      arc_0_0_5
 FX BND1      load_0_0_5  0
 BV BND1      arc_0_0_6
 FX BND1      load_0_0_6  0
 BV BND1      arc_0_0_8
 FX BND1      load_0_0_8  0
 BV BND1      arc_0_0_9
 FX BND1      load_0_0_9  0
 BV BND1      arc_0_0_10
 FX BND1      load_0_0_10  0
 BV BND1      arc_0_0_11
 FX BND1      load_0_0_11  0
 BV BND1      arc_0_0_12
 FX BND1      load_0_0_12  0
 BV BND1      arc_0_0_13
 FX BND1      load_0_0_13  0
 BV BND1      arc_0_0_14
 FX BND1      load_0_0_14  0
 BV BND1      arc_0_0_15
 FX BND1      load_0_0_15  0
 BV BND1      arc_0_1_0
 UP BND1      load_0_1_0  30
 BV BND1      arc_0_1_2
 UP BND1      load_0_1_2  30
 BV BND1      arc_0_1_3
 UP BND1      load_0_1_3  30
 BV BND1      arc_0_1_4
 UP BND1      load_0_1_4  30
 BV BND1      arc_0_1_5
 UP BND1      load_0_1_5  30
 BV BND1      arc_0_1_6
 UP BND1      load_0_1_6  30
 BV BND1      arc_0_1_8
 UP BND1      load_0_1_8  30
 BV BND1      arc_0_1_9
 UP BND1      load_0_1_9  30
 BV BND1      arc_0_1_10
 UP BND1      load_0_1_10  30
 BV BND1      arc_0_1_11
 UP BND1      load_0_1_11  30
 BV BND1      arc_0_1_12
 UP BND1      load_0_1_12  30
 BV BND1      arc_0_1_13
 UP BND1      load_0_1_13  30
 BV BND1      arc_0_1_14
 UP BND1      load_0_1_14  30
 BV BND1      arc_0_1_15
 UP BND1      load_0_1_15  30
 BV BND1      arc_0_2_0
 UP BND1      load_0_2_0  30
 BV BND1      arc_0_2_1
 UP BND1      load_0_2_1  30
 BV BND1      arc_0_2_3
 UP BND1      load_0_2_3  30
 BV BND1      arc_0_2_4
 UP BND1      load_0_2_4  30
 BV BND1      arc_0_2_5
 UP BND1      load_0_2_5  30
 BV BND1      arc_0_2_6
 UP BND1      load_0_2_6  30
 BV BND1      arc_0_2_8
 UP BND1      load_0_2_8  30
 BV BND1      arc_0_2_9
 UP BND1      load_0_2_9  30
 BV BND1      arc_0_2_10
 UP BND1      load_0_2_10  30
 BV BND1      arc_0_2_11
 UP BND1      load_0_2_11  30
 BV BND1      arc_0_2_12
 UP BND1      load_0_2_12  30
 BV BND1      arc_0_2_13
 UP BND1      load_0_2_13  30
 BV BND1      arc_0_2_14
 UP BND1      load_0_2_14  30
 BV BND1      arc_0_2_15
 UP BND1      load_0_2_15  30
 BV BND1      arc_0_3_0
 UP BND1      load_0_3_0  30
 BV BND1      arc_0_3_1
 UP BND1      load_0_3_1  30
 BV BND1      arc_0_3_2
 UP BND1      load_0_3_2  30
 BV BND1      arc_0_3_4
 UP BND1      load_0_3_4  30
 BV BND1      arc_0_3_5
 UP BND1      load_0_3_5  30
 BV BND1      arc_0_3_6
 UP BND1      load_0_3_6  30
 BV BND1      arc_0_3_8
 UP BND1      load_0_3_8  30
 BV BND1      arc_0_3_9
 UP BND1      load_0_3_9  30
 BV BND1      arc_0_3_10
 UP BND1      load_0_3_10  30
 BV BND1      arc_0_3_11
 UP BND1      load_0_3_11  30
 BV BND1      arc_0_3_12
 UP BND1      load_0_3_12  30
 BV BND1      arc_0_3_13
 UP BND1      load_0_3_13  30
 BV BND1      arc_0_3_14
 UP BND1      load_0_3_14  30
 BV BND1      arc_0_3_15
 UP BND1      load_0_3_15  30
 BV BND1      arc_0_4_0
 UP BND1      load_0_4_0  30
 BV BND1      arc_0_4_1
 UP BND1      load_0_4_1  30
 BV BND1      arc_0_4_2
 UP BND1      load_0_4_2  30
 BV BND1      arc_0_4_3
 UP BND1      load_0_4_3  30
 BV BND1      arc_0_4_5
 UP BND1      load_0_4_5  30
 BV BND1      arc_0_4_6
 UP BND1      load_0_4_6  30
 BV BND1      arc_0_4_8
 UP BND1      load_0_4_8  30
 BV BND1      arc_0_4_9
 UP BND1      load_0_4_9  30
 BV BND1      arc_0_4_10
 UP BND1      load_0_4_10  30
 BV BND1      arc_0_4_11
 UP BND1      load_0_4_11  30
 BV BND1      arc_0_4_12
 UP BND1      load_0_4_12  30
 BV BND1      arc_0_4_13
 UP BND1      load_0_4_13  30
 BV BND1      arc_0_4_14
 UP BND1      load_0_4_14  30
 BV BND1      arc_0_4_15
 UP BND1      load_0_4_15  30
 BV BND1      arc_0_5_0
 UP BND1      load_0_5_0  30
 BV BND1      arc_0_5_1
 UP BND1      load_0_5_1  30
 BV BND1      arc_0_5_2
 UP BND1      load_0_5_2  30
 BV BND1      arc_0_5_3
 UP BND1      load_0_5_3  30
 BV BND1      arc_0_5_4
 UP BND1      load_0_5_4  30
 BV BND1      arc_0_5_6
 UP BND1      load_0_5_6  30
 BV BND1      arc_0_5_8
 UP BND1      load_0_5_8  30
 BV BND1      arc_0_5_9
 UP BND1      load_0_5_9  30
 BV BND1      arc_0_5_10
 UP BND1      load_0_5_10  30
 BV BND1      arc_0_5_11
 UP BND1      load_0_5_11  30
 BV BND1      arc_0_5_12
 UP BND1      load_0_5_12  30
 BV BND1      arc_0_5_13
 UP BND1      load_0_5_13  30
 BV BND1      arc_0_5_14
 UP BND1      load_0_5_14  30
 BV BND1      arc_0_5_15
 UP BND1      load_0_5_15  30
 BV BND1      arc_0_6_0
 UP BND1      load_0_6_0  30
 BV BND1      arc_0_6_1
 UP BND1      load_0_6_1  30
 BV BND1      arc_0_6_2
 UP BND1      load_0_6_2  30
 BV BND1      arc_0_6_3
 UP BND1      load_0_6_3  30
 BV BND1      arc_0_6_4
 UP BND1      load_0_6_4  30
 BV BND1      arc_0_6_5
 UP BND1      load_0_6_5  30
 BV BND1      arc_0_6_8
 UP BND1      load_0_6_8  30
 BV BND1      arc_0_6_9
 UP BND1      load_0_6_9  30
 BV BND1      arc_0_6_10
 UP BND1      load_0_6_10  30
 BV BND1      arc_0_6_11
 UP BND1      load_0_6_11  30
 BV BND1      arc_0_6_12
 UP BND1      load_0_6_12  30
 BV BND1      arc_0_6_13
 UP BND1      load_0_6_13  30
 BV BND1      arc_0_6_14
 UP BND1      load_0_6_14  30
 BV BND1      arc_0_6_15
 UP BND1      load_0_6_15  30
 BV BND1      arc_0_8_0
 UP BND1      load_0_8_0  30
 BV BND1      arc_0_8_1
 UP BND1      load_0_8_1  30
 BV BND1      arc_0_8_2
 UP BND1      load_0_8_2  30
 BV BND1      arc_0_8_3
 UP BND1      load_0_8_3  30
 BV BND1      arc_0_8_4
 UP BND1      load_0_8_4  30
 BV BND1      arc_0_8_5
 UP BND1      load_0_8_5  30
 BV BND1      arc_0_8_6
 UP BND1      load_0_8_6  30
 BV BND1      arc_0_8_9
 UP BND1      load_0_8_9  30
 BV BND1      arc_0_8_10
 UP BND1      load_0_8_10  30
 BV BND1      arc_0_8_11
 UP BND1      load_0_8_11  30
 BV BND1      arc_0_8_12
 UP BND1      load_0_8_12  30
 BV BND1      arc_0_8_13
 UP BND1      load_0_8_13  30
 BV BND1      arc_0_8_14
 UP BND1      load_0_8_14  30
 BV BND1      arc_0_8_15
 UP BND1      load_0_8_15  30
 BV BND1      arc_0_9_0
 UP BND1      load_0_9_0  30
 BV BND1      arc_0_9_1
 UP BND1      load_0_9_1  30
 BV BND1      arc_0_9_2
 UP BND1      load_0_9_2  30
 BV BND1      arc_0_9_3
 UP BND1      load_0_9_3  30
 BV BND1      arc_0_9_4
 UP BND1      load_0_9_4  30
 BV BND1      arc_0_9_5
 UP BND1      load_0_9_5  30
 BV BND1      arc_0_9_6
 UP BND1      load_0_9_6  30
 BV BND1      arc_0_9_8
 UP BND1      load_0_9_8  30
 BV BND1      arc_0_9_10
 UP BND1      load_0_9_10  30
 BV BND1      arc_0_9_11
 UP BND1      load_0_9_11  30
 BV BND1      arc_0_9_12
 UP BND1      load_0_9_12  30
 BV BND1      arc_0_9_13
 UP BND1      load_0_9_13  30
 BV BND1      arc_0_9_14
 UP BND1      load_0_9_14  30
 BV BND1      arc_0_9_15
 UP BND1      load_0_9_15  30
 BV BND1      arc_0_10_0
 UP BND1      load_0_10_0  30
 BV BND1      arc_0_10_1
 UP BND1      load_0_10_1  30
 BV BND1      arc_0_10_2
 UP BND1      load_0_10_2  30
 BV BND1      arc_0_10_3
 UP BND1      load_0_10_3  30
 BV BND1      arc_0_10_4
 UP BND1      load_0_10_4  30
 BV BND1      arc_0_10_5
 UP BND1      load_0_10_5  30
 BV BND1      arc_0_10_6
 UP BND1      load_0_10_6  30
 BV BND1      arc_0_10_8
 UP BND1      load_0_10_8  30
 BV BND1      arc_0_10_9
 UP BND1      load_0_10_9  30
 BV BND1      arc_0_10_11
 UP BND1      load_0_10_11  30
 BV BND1      arc_0_10_12
 UP BND1      load_0_10_12  30
 BV BND1      arc_0_10_13
 UP BND1      load_0_10_13  30
 BV BND1      arc_0_10_14
 UP BND1      load_0_10_14  30
 BV BND1      arc_0_10_15
 UP BND1      load_0_10_15  30
 BV BND1      arc_0_11_0
 UP BND1      load_0_11_0  30
 BV BND1      arc_0_11_1
 UP BND1      load_0_11_1  30
 BV BND1      arc_0_11_2
 UP BND1      load_0_11_2  30
 BV BND1      arc_0_11_3
 UP BND1      load_0_11_3  30
 BV BND1      arc_0_11_4
 UP BND1      load_0_11_4  30
 BV BND1      arc_0_11_5
 UP BND1      load_0_11_5  30
 BV BND1      arc_0_11_6
 UP BND1      load_0_11_6  30
 BV BND1      arc_0_11_8
 UP BND1      load_0_11_8  30
 BV BND1      arc_0_11_9
 UP BND1      load_0_11_9  30
 BV BND1      arc_0_11_10
 UP BND1      load_0_11_10  30
 BV BND1      arc_0_11_12
 UP BND1      load_0_11_12  30
 BV BND1      arc_0_11_13
 UP BND1      load_0_11_13  30
 BV BND1      arc_0_11_14
 UP BND1      load_0_11_14  30
 BV BND1      arc_0_11_15
 UP BND1      load_0_11_15  30
 BV BND1      arc_0_12_0
 UP BND1      load_0_12_0  30
 BV BND1      arc_0_12_1
 UP BND1      load_0_12_1  30
 BV BND1      arc_0_12_2
 UP BND1      load_0_12_2  30
 BV BND1      arc_0_12_3
 UP BND1      load_0_12_3  30
 BV BND1      arc_0_12_4
 UP BND1      load_0_12_4  30
 BV BND1      arc_0_12_5
 UP BND1      load_0_12_5  30
 BV BND1      arc_0_12_6
 UP BND1      load_0_12_6  30
 BV BND1      arc_0_12_8
 UP BND1      load_0_12_8  30
 BV BND1      arc_0_12_9
 UP BND1      load_0_12_9  30
 BV BND1      arc_0_12_10
 UP BND1      load_0_12_10  30
 BV BND1      arc_0_12_11
 UP BND1      load_0_12_11  30
 BV BND1      arc_0_12_13
 UP BND1      load_0_12_13  30
 BV BND1      arc_0_12_14
 UP BND1      load_0_12_14  30
 BV BND1      arc_0_12_15
 UP BND1      load_0_12_15  30
 BV BND1      arc_0_13_0
 UP BND1      load_0_13_0  30
 BV BND1      arc_0_13_1
 UP BND1      load_0_13_1  30
 BV BND1      arc_0_13_2
 UP BND1      load_0_13_2  30
 BV BND1      arc_0_13_3
 UP BND1      load_0_13_3  30
 BV BND1      arc_0_13_4
 UP BND1      load_0_13_4  30
 BV BND1      arc_0_13_5
 UP BND1      load_0_13_5  30
 BV BND1      arc_0_13_6
 UP BND1      load_0_13_6  30
 BV BND1      arc_0_13_8
 UP BND1      load_0_13_8  30
 BV BND1      arc_0_13_9
 UP BND1      load_0_13_9  30
 BV BND1      arc_0_13_10
 UP BND1      load_0_13_10  30
 BV BND1      arc_0_13_11
 UP BND1      load_0_13_11  30
 BV BND1      arc_0_13_12
 UP BND1      load_0_13_12  30
 BV BND1      arc_0_13_14
 UP BND1      load_0_13_14  30
 BV BND1      arc_0_13_15
 UP BND1      load_0_13_15  30
 BV BND1      arc_0_14_0
 UP BND1      load_0_14_0  30
 BV BND1      arc_0_14_1
 UP BND1      load_0_14_1  30
 BV BND1      arc_0_14_2
 UP BND1      load_0_14_2  30
 BV BND1      arc_0_14_3
 UP BND1      load_0_14_3  30
 BV BND1      arc_0_14_4
 UP BND1      load_0_14_4  30
 BV BND1      arc_0_14_5
 UP BND1      load_0_14_5  30
 BV BND1      arc_0_14_6
 UP BND1      load_0_14_6  30
 BV BND1      arc_0_14_8
 UP BND1      load_0_14_8  30
 BV BND1      arc_0_14_9
 UP BND1      load_0_14_9  30
 BV BND1      arc_0_14_10
 UP BND1      load_0_14_10  30
 BV BND1      arc_0_14_11
 UP BND1      load_0_14_11  30
 BV BND1      arc_0_14_12
 UP BND1      load_0_14_12  30
 BV BND1      arc_0_14_13
 UP BND1      load_0_14_13  30
 BV BND1      arc_0_14_15
 UP BND1      load_0_14_15  30
 BV BND1      arc_0_15_0
 UP BND1      load_0_15_0  30
 BV BND1      arc_0_15_1
 UP BND1      load_0_15_1  30
 BV BND1      arc_0_15_2
 UP BND1      load_0_15_2  30
 BV BND1      arc_0_15_3
 UP BND1      load_0_15_3  30
 BV BND1      arc_0_15_4
 UP BND1      load_0_15_4  30
 BV BND1      arc_0_15_5
 UP BND1      load_0_15_5  30
 BV BND1      arc_0_15_6
 UP BND1      load_0_15_6  30
 BV BND1      arc_0_15_8
 UP BND1      load_0_15_8  30
 BV BND1      arc_0_15_9
 UP BND1      load_0_15_9  30
 BV BND1      arc_0_15_10
 UP BND1      load_0_15_10  30
 BV BND1      arc_0_15_11
 UP BND1      load_0_15_11  30
 BV BND1      arc_0_15_12
 UP BND1      load_0_15_12  30
 BV BND1      arc_0_15_13
 UP BND1      load_0_15_13  30
 BV BND1      arc_0_15_14
 UP BND1      load_0_15_14  30
 FX BND1      visit_1_7  1
 UP BND1      order_1_7  9
 UP BND1      visit_1_8  1
 UP BND1      order_1_8  9
 UP BND1      visit_1_9  1
 UP BND1      order_1_9  9
 UP BND1      visit_1_10  1
 UP BND1      order_1_10  9
 UP BND1      visit_1_11  1
 UP BND1      order_1_11  9
 UP BND1      visit_1_12  1
 UP BND1      order_1_12  9
 UP BND1      visit_1_13  1
 UP BND1      order_1_13  9
 UP BND1      visit_1_14  1
 UP BND1      order_1_14  9
 UP BND1      visit_1_15  1
 UP BND1      order_1_15  9
 BV BND1      arc_1_0_0
 FX BND1      load_1_0_0  0
 BV BND1      arc_1_0_7
 FX BND1      load_1_0_7  0
 BV BND1      arc_1_0_8
 FX BND1      load_1_0_8  0
 BV BND1      arc_1_0_9
 FX BND1      load_1_0_9  0
 BV BND1      arc_1_0_10
 FX BND1      load_1_0_10  0
 BV BND1      arc_1_0_11
 FX BND1      load_1_0_11  0
 BV BND1      arc_1_0_12
 FX BND1      load_1_0_12  0
 BV BND1      arc_1_0_13
 FX BND1      load_1_0_13  0
 BV BND1      arc_1_0_14
 FX BND1      load_1_0_14  0
 BV BND1      arc_1_0_15
 FX BND1      load_1_0_15  0
 BV BND1      arc_1_7_0
 UP BND1      load_1_7_0  30
 BV BND1      arc_1_7_8
 UP BND1      load_1_7_8  30
 BV BND1      arc_1_7_9
 UP BND1      load_1_7_9  30
 BV BND1      arc_1_7_10
 UP BND1      load_1_7_10  30
 BV BND1      arc_1_7_11
 UP BND1      load_1_7_11  30
 BV BND1      arc_1_7_12
 UP BND1      load_1_7_12  30
 BV BND1      arc_1_7_13
 UP BND1      load_1_7_13  30
 BV BND1      arc_1_7_14
 UP BND1      load_1_7_14  30
 BV BND1      arc_1_7_15
 UP BND1      load_1_7_15  30
 BV BND1      arc_1_8_0
 UP BND1      load_1_8_0  30
 BV BND1      arc_1_8_7
 UP BND1      load_1_8_7  30
 BV BND1      arc_1_8_9
 UP BND1      load_1_8_9  30
 BV BND1      arc_1_8_10
 UP BND1      load_1_8_10  30
 BV BND1      arc_1_8_11
 UP BND1      load_1_8_11  30
 BV BND1      arc_1_8_12
 UP BND1      load_1_8_12  30
 BV BND1      arc_1_8_13
 UP BND1      load_1_8_13  30
 BV BND1      arc_1_8_14
 UP BND1      load_1_8_14  30
 BV BND1      arc_1_8_15
 UP BND1      load_1_8_15  30
 BV BND1      arc_1_9_0
 UP BND1      load_1_9_0  30
 BV BND1      arc_1_9_7
 UP BND1      load_1_9_7  30
 BV BND1      arc_1_9_8
 UP BND1      load_1_9_8  30
 BV BND1      arc_1_9_10
 UP BND1      load_1_9_10  30
 BV BND1      arc_1_9_11
 UP BND1      load_1_9_11  30
 BV BND1      arc_1_9_12
 UP BND1      load_1_9_12  30
 BV BND1      arc_1_9_13
 UP BND1      load_1_9_13  30
 BV BND1      arc_1_9_14
 UP BND1      load_1_9_14  30
 BV BND1      arc_1_9_15
 UP BND1      load_1_9_15  30
 BV BND1      arc_1_10_0
 UP BND1      load_1_10_0  30
 BV BND1      arc_1_10_7
 UP BND1      load_1_10_7  30
 BV BND1      arc_1_10_8
 UP BND1      load_1_10_8  30
 BV BND1      arc_1_10_9
 UP BND1      load_1_10_9  30
 BV BND1      arc_1_10_11
 UP BND1      load_1_10_11  30
 BV BND1      arc_1_10_12
 UP BND1      load_1_10_12  30
 BV BND1      arc_1_10_13
 UP BND1      load_1_10_13  30
 BV BND1      arc_1_10_14
 UP BND1      load_1_10_14  30
 BV BND1      arc_1_10_15
 UP BND1      load_1_10_15  30
 BV BND1      arc_1_11_0
 UP BND1      load_1_11_0  30
 BV BND1      arc_1_11_7
 UP BND1      load_1_11_7  30
 BV BND1      arc_1_11_8
 UP BND1      load_1_11_8  30
 BV BND1      arc_1_11_9
 UP BND1      load_1_11_9  30
 BV BND1      arc_1_11_10
 UP BND1      load_1_11_10  30
 BV BND1      arc_1_11_12
 UP BND1      load_1_11_12  30
 BV BND1      arc_1_11_13
 UP BND1      load_1_11_13  30
 BV BND1      arc_1_11_14
 UP BND1      load_1_11_14  30
 BV BND1      arc_1_11_15
 UP BND1      load_1_11_15  30
 BV BND1      arc_1_12_0
 UP BND1      load_1_12_0  30
 BV BND1      arc_1_12_7
 UP BND1      load_1_12_7  30
 BV BND1      arc_1_12_8
 UP BND1      load_1_12_8  30
 BV BND1      arc_1_12_9
 UP BND1      load_1_12_9  30
 BV BND1      arc_1_12_10
 UP BND1      load_1_12_10  30
 BV BND1      arc_1_12_11
 UP BND1      load_1_12_11  30
 BV BND1      arc_1_12_13
 UP BND1      load_1_12_13  30
 BV BND1      arc_1_12_14
 UP BND1      load_1_12_14  30
 BV BND1      arc_1_12_15
 UP BND1      load_1_12_15  30
 BV BND1      arc_1_13_0
 UP BND1      load_1_13_0  30
 BV BND1      arc_1_13_7
 UP BND1      load_1_13_7  30
 BV BND1      arc_1_13_8
 UP BND1      load_1_13_8  30
 BV BND1      arc_1_13_9
 UP BND1      load_1_13_9  30
 BV BND1      arc_1_13_10
 UP BND1      load_1_13_10  30
 BV BND1      arc_1_13_11
 UP BND1      load_1_13_11  30
 BV BND1      arc_1_13_12
 UP BND1      load_1_13_12  30
 BV BND1      arc_1_13_14
 UP BND1      load_1_13_14  30
 BV BND1      arc_1_13_15
 UP BND1      load_1_13_15  30
 BV BND1      arc_1_14_0
 UP BND1      load_1_14_0  30
 BV BND1      arc_1_14_7
 UP BND1      load_1_14_7  30
 BV BND1      arc_1_14_8
 UP BND1      load_1_14_8  30
 BV BND1      arc_1_14_9
 UP BND1      load_1_14_9  30
 BV BND1      arc_1_14_10
 UP BND1      load_1_14_10  30
 BV BND1      arc_1_14_11
 UP BND1      load_1_14_11  30
 BV BND1      arc_1_14_12
 UP BND1      load_1_14_12  30
 BV BND1      arc_1_14_13
 UP BND1      load_1_14_13  30
 BV BND1      arc_1_14_15
 UP BND1      load_1_14_15  30
 BV BND1      arc_1_15_0
 UP BND1      load_1_15_0  30
 BV BND1      arc_1_15_7
 UP BND1      load_1_15_7  30
 BV BND1      arc_1_15_8
 UP BND1      load_1_15_8  30
 BV BND1      arc_1_15_9
 UP BND1      load_1_15_9  30
 BV BND1      arc_1_15_10
 UP BND1      load_1_15_10  30
 BV BND1      arc_1_15_11
 UP BND1      load_1_15_11  30
 BV BND1      arc_1_15_12
 UP BND1      load_1_15_12  30
 BV BND1      arc_1_15_13
 UP BND1      load_1_15_13  30
 BV BND1      arc_1_15_14
 UP BND1      load_1_15_14  30
ENDATA
