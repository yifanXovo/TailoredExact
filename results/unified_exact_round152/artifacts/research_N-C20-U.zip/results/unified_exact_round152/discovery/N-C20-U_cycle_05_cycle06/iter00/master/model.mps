* Signature: 0xd561a8079dc54f89
NAME 
OBJSENSE MAX
ROWS
 N  OBJ
 L  column_0
 L  column_1
 L  column_2
 L  column_3
 L  column_4
 L  column_5
 L  column_6
 L  column_7
 L  column_8
 L  column_9
 L  column_10
 L  column_11
COLUMNS
    psi[1,11]  OBJ       1
    psi[1,11]  column_0  1
    psi[1,11]  column_1  1
    psi[1,11]  column_2  1
    psi[1,11]  column_3  1
    psi[1,11]  column_4  1
    psi[1,11]  column_5  1
    psi[1,11]  column_6  1
    psi[1,11]  column_7  1
    psi[1,11]  column_8  1
    psi[1,11]  column_9  1
    psi[1,11]  column_10  1
    psi[1,11]  column_11  1
    psi[2,14]  OBJ       1
    psi[2,14]  column_0  1
    psi[2,14]  column_1  1
    psi[2,14]  column_2  1
    psi[2,14]  column_3  1
    psi[2,14]  column_4  1
    psi[2,14]  column_5  1
    psi[2,14]  column_6  1
    psi[2,14]  column_7  1
    psi[2,14]  column_8  1
    psi[2,14]  column_9  1
    psi[2,14]  column_10  1
    psi[2,14]  column_11  1
    psi[3,15]  OBJ       1
    psi[3,15]  column_0  1
    psi[3,15]  column_1  1
    psi[3,15]  column_2  1
    psi[3,15]  column_3  1
    psi[3,15]  column_4  1
    psi[3,15]  column_5  1
    psi[3,15]  column_6  1
    psi[3,15]  column_7  1
    psi[3,15]  column_8  1
    psi[3,15]  column_9  1
    psi[3,15]  column_10  1
    psi[3,15]  column_11  1
    psi[4,11]  OBJ       1
    psi[4,11]  column_0  1
    psi[4,11]  column_1  1
    psi[4,11]  column_2  1
    psi[4,11]  column_3  1
    psi[4,11]  column_4  1
    psi[4,11]  column_5  1
    psi[4,11]  column_6  1
    psi[4,11]  column_7  1
    psi[4,11]  column_8  1
    psi[4,11]  column_9  1
    psi[4,11]  column_10  1
    psi[4,11]  column_11  1
    psi[5,11]  OBJ       5.6631607516364657e-01
    psi[5,11]  column_0  1
    psi[5,11]  column_1  1
    psi[5,11]  column_2  1
    psi[5,11]  column_3  1
    psi[5,11]  column_4  1
    psi[5,11]  column_5  1
    psi[5,11]  column_6  1
    psi[5,12]  OBJ       0.0610970307456171
    psi[5,12]  column_7  1
    psi[5,12]  column_8  1
    psi[5,18]  OBJ       3.7258689409073642e-01
    psi[5,18]  column_9  1
    psi[5,18]  column_10  1
    psi[5,18]  column_11  1
    psi[6,11]  OBJ       7.0342163451324757e-01
    psi[6,11]  column_0  1
    psi[6,11]  column_1  1
    psi[6,11]  column_2  1
    psi[6,11]  column_3  1
    psi[6,11]  column_4  1
    psi[6,11]  column_5  1
    psi[6,11]  column_7  1
    psi[6,11]  column_9  1
    psi[6,11]  column_10  1
    psi[6,20]  OBJ       2.9657836548675243e-01
    psi[6,20]  column_6  1
    psi[6,20]  column_8  1
    psi[6,20]  column_11  1
    psi[7,10]  OBJ       1
    psi[7,10]  column_0  1
    psi[7,10]  column_1  1
    psi[7,10]  column_2  1
    psi[7,10]  column_3  1
    psi[7,10]  column_4  1
    psi[7,10]  column_5  1
    psi[7,10]  column_6  1
    psi[7,10]  column_7  1
    psi[7,10]  column_8  1
    psi[7,10]  column_9  1
    psi[7,10]  column_10  1
    psi[7,10]  column_11  1
    psi[8,11]  OBJ       1
    psi[8,11]  column_0  1
    psi[8,11]  column_1  1
    psi[8,11]  column_2  1
    psi[8,11]  column_3  1
    psi[8,11]  column_4  1
    psi[8,11]  column_5  1
    psi[8,11]  column_6  1
    psi[8,11]  column_7  1
    psi[8,11]  column_8  1
    psi[8,11]  column_9  1
    psi[8,11]  column_10  1
    psi[8,11]  column_11  1
    psi[9,9]  OBJ       1
    psi[9,9]  column_0  1
    psi[9,9]  column_1  1
    psi[9,9]  column_2  1
    psi[9,9]  column_3  1
    psi[9,9]  column_4  1
    psi[9,9]  column_5  1
    psi[9,9]  column_6  1
    psi[9,9]  column_7  1
    psi[9,9]  column_8  1
    psi[9,9]  column_9  1
    psi[9,9]  column_10  1
    psi[9,9]  column_11  1
    psi[10,16]  OBJ       1
    psi[10,16]  column_0  1
    psi[10,16]  column_1  1
    psi[10,16]  column_2  1
    psi[10,16]  column_3  1
    psi[10,16]  column_4  1
    psi[10,16]  column_5  1
    psi[10,16]  column_6  1
    psi[10,16]  column_7  1
    psi[10,16]  column_8  1
    psi[10,16]  column_9  1
    psi[10,16]  column_10  1
    psi[10,16]  column_11  1
    psi[11,17]  OBJ       1
    psi[11,17]  column_0  1
    psi[11,17]  column_1  1
    psi[11,17]  column_2  1
    psi[11,17]  column_3  1
    psi[11,17]  column_4  1
    psi[11,17]  column_5  1
    psi[11,17]  column_6  1
    psi[11,17]  column_7  1
    psi[11,17]  column_8  1
    psi[11,17]  column_9  1
    psi[11,17]  column_10  1
    psi[11,17]  column_11  1
    psi[12,10]  OBJ       6.9668121711582143e-01
    psi[12,10]  column_0  1
    psi[12,10]  column_1  1
    psi[12,10]  column_2  1
    psi[12,10]  column_3  1
    psi[12,10]  column_4  1
    psi[12,10]  column_5  1
    psi[12,10]  column_7  1
    psi[12,10]  column_9  1
    psi[12,18]  OBJ       3.0331878288417852e-01
    psi[12,18]  column_6  1
    psi[12,18]  column_8  1
    psi[12,18]  column_10  1
    psi[12,18]  column_11  1
    psi[13,13]  OBJ       1
    psi[13,13]  column_0  1
    psi[13,13]  column_1  1
    psi[13,13]  column_2  1
    psi[13,13]  column_3  1
    psi[13,13]  column_4  1
    psi[13,13]  column_5  1
    psi[13,13]  column_6  1
    psi[13,13]  column_7  1
    psi[13,13]  column_8  1
    psi[13,13]  column_9  1
    psi[13,13]  column_10  1
    psi[13,13]  column_11  1
    psi[14,13]  OBJ       1
    psi[14,13]  column_0  1
    psi[14,13]  column_1  1
    psi[14,13]  column_2  1
    psi[14,13]  column_3  1
    psi[14,13]  column_4  1
    psi[14,13]  column_5  1
    psi[14,13]  column_6  1
    psi[14,13]  column_7  1
    psi[14,13]  column_8  1
    psi[14,13]  column_9  1
    psi[14,13]  column_10  1
    psi[14,13]  column_11  1
    psi[15,14]  OBJ       1
    psi[15,14]  column_0  1
    psi[15,14]  column_1  1
    psi[15,14]  column_2  1
    psi[15,14]  column_3  1
    psi[15,14]  column_4  1
    psi[15,14]  column_5  1
    psi[15,14]  column_6  1
    psi[15,14]  column_7  1
    psi[15,14]  column_8  1
    psi[15,14]  column_9  1
    psi[15,14]  column_10  1
    psi[15,14]  column_11  1
    psi[16,12]  OBJ       6.5546817122598466e-01
    psi[16,12]  column_0  1
    psi[16,12]  column_1  1
    psi[16,12]  column_2  1
    psi[16,12]  column_3  1
    psi[16,12]  column_7  1
    psi[16,12]  column_9  1
    psi[16,12]  column_11  1
    psi[16,13]  OBJ       2.3615767909753060e-02
    psi[16,13]  column_4  1
    psi[16,13]  column_10  1
    psi[16,21]  OBJ       3.2091606086426222e-01
    psi[16,21]  column_5  1
    psi[16,21]  column_6  1
    psi[16,21]  column_8  1
    psi[17,8]  OBJ       7.2197446966494672e-01
    psi[17,8]  column_0  1
    psi[17,8]  column_1  1
    psi[17,8]  column_2  1
    psi[17,8]  column_3  1
    psi[17,8]  column_6  1
    psi[17,8]  column_8  1
    psi[17,8]  column_9  1
    psi[17,8]  column_11  1
    psi[17,9]  OBJ       4.0423433174526124e-02
    psi[17,9]  column_4  1
    psi[17,9]  column_7  1
    psi[17,9]  column_10  1
    psi[17,16]  OBJ       2.3760209716052716e-01
    psi[17,16]  column_5  1
    psi[18,11]  OBJ       7.0342163451324768e-01
    psi[18,11]  column_0  1
    psi[18,11]  column_1  1
    psi[18,11]  column_4  1
    psi[18,11]  column_6  1
    psi[18,11]  column_7  1
    psi[18,11]  column_8  1
    psi[18,11]  column_9  1
    psi[18,11]  column_11  1
    psi[18,20]  OBJ       2.9657836548675232e-01
    psi[18,20]  column_2  1
    psi[18,20]  column_3  1
    psi[18,20]  column_5  1
    psi[18,20]  column_10  1
    psi[19,12]  OBJ       6.3601746053898578e-01
    psi[19,12]  column_0  1
    psi[19,12]  column_4  1
    psi[19,12]  column_5  1
    psi[19,12]  column_6  1
    psi[19,12]  column_7  1
    psi[19,12]  column_8  1
    psi[19,12]  column_10  1
    psi[19,12]  column_11  1
    psi[19,20]  OBJ       3.6398253946101422e-01
    psi[19,20]  column_1  1
    psi[19,20]  column_2  1
    psi[19,20]  column_3  1
    psi[19,20]  column_9  1
    psi[20,13]  OBJ       0.605685582250568
    psi[20,13]  column_0  1
    psi[20,13]  column_2  1
    psi[20,13]  column_5  1
    psi[20,13]  column_6  1
    psi[20,13]  column_8  1
    psi[20,13]  column_10  1
    psi[20,13]  column_11  1
    psi[20,21]  OBJ       3.9431441774943204e-01
    psi[20,21]  column_1  1
    psi[20,21]  column_3  1
    psi[20,21]  column_4  1
    psi[20,21]  column_7  1
    psi[20,21]  column_9  1
    a         OBJ       1
    a         column_0  1
    a         column_1  1
    a         column_2  1
    a         column_3  1
    a         column_4  1
    a         column_5  1
    a         column_6  1
    a         column_7  1
    a         column_8  1
    a         column_9  1
    a         column_10  1
    a         column_11  1
RHS
    RHS1      column_0  2.3037127760972e-17
    RHS1      column_1  5.4337349397590377e-02
    RHS1      column_2  6.2552891396332883e-02
    RHS1      column_3  8.1694968885138719e-02
    RHS1      column_4  3.6178236108973395e-02
    RHS1      column_5  9.7834843907351476e-02
    RHS1      column_6  9.0296687665108746e-02
    RHS1      column_7  3.6437833074566765e-02
    RHS1      column_8  9.2562234365513071e-02
    RHS1      column_9  7.4630437094544311e-02
    RHS1      column_10  9.1779366631816822e-02
    RHS1      column_11  8.6928104575163423e-02
BOUNDS
 FX BND1      psi[1,11]  0
 FX BND1      psi[2,14]  0
 FX BND1      psi[3,15]  0
 FX BND1      psi[4,11]  0
 FX BND1      psi[5,11]  0
 LO BND1      psi[5,12]  -0.05
 UP BND1      psi[5,12]  0.05
 LO BND1      psi[5,18]  -0.05
 UP BND1      psi[5,18]  0.05
 FX BND1      psi[6,11]  0
 LO BND1      psi[6,20]  -0.05
 UP BND1      psi[6,20]  0.05
 FX BND1      psi[7,10]  0
 FX BND1      psi[8,11]  0
 FX BND1      psi[9,9]  0
 FX BND1      psi[10,16]  0
 FX BND1      psi[11,17]  0
 FX BND1      psi[12,10]  0
 LO BND1      psi[12,18]  -0.05
 UP BND1      psi[12,18]  0.05
 FX BND1      psi[13,13]  0
 FX BND1      psi[14,13]  0
 FX BND1      psi[15,14]  0
 FX BND1      psi[16,12]  0
 LO BND1      psi[16,13]  -0.05
 UP BND1      psi[16,13]  0.05
 LO BND1      psi[16,21]  -0.05
 UP BND1      psi[16,21]  0.05
 FX BND1      psi[17,8]  0
 LO BND1      psi[17,9]  -0.05
 UP BND1      psi[17,9]  0.05
 LO BND1      psi[17,16]  -0.05
 UP BND1      psi[17,16]  0.05
 FX BND1      psi[18,11]  0
 LO BND1      psi[18,20]  -0.05
 UP BND1      psi[18,20]  0.05
 FX BND1      psi[19,12]  0
 LO BND1      psi[19,20]  -0.05
 UP BND1      psi[19,20]  0.05
 FX BND1      psi[20,13]  0
 LO BND1      psi[20,21]  -0.05
 UP BND1      psi[20,21]  0.05
 FR BND1      a       
ENDATA
