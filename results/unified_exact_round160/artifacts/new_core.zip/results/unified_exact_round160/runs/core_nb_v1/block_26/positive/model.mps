* Signature: 0xaa6aa0e1400efbdd
NAME R160_physical_neighborhood
ROWS
 N  OBJ
 G  product_lb_0
 L  product_ub_1
 G  product_lb_2
 L  product_ub_3
 G  product_lb_4
 L  product_ub_5
 G  product_lb_6
 L  product_ub_7
 G  product_lb_8
 L  product_ub_9
 G  product_lb_10
 L  product_ub_11
 G  product_lb_12
 L  product_ub_13
 G  product_lb_14
 L  product_ub_15
 G  product_lb_16
 L  product_ub_17
 G  product_lb_18
 L  product_ub_19
 G  product_lb_20
 L  product_ub_21
 G  product_lb_22
 L  product_ub_23
 G  product_lb_24
 L  product_ub_25
 G  product_lb_26
 L  product_ub_27
 G  product_lb_28
 L  product_ub_29
 G  product_lb_30
 L  product_ub_31
 G  product_lb_32
 L  product_ub_33
 G  product_lb_34
 L  product_ub_35
 E  onehot_18_36
 E  normalized_mass_18_37
 E  normalized_ratio_18_38
 G  product_lb_39
 L  product_ub_40
 G  product_lb_41
 L  product_ub_42
 G  product_lb_43
 L  product_ub_44
 G  product_lb_45
 L  product_ub_46
 G  product_lb_47
 L  product_ub_48
 G  product_lb_49
 L  product_ub_50
 G  product_lb_51
 L  product_ub_52
 G  product_lb_53
 L  product_ub_54
 G  product_lb_55
 L  product_ub_56
 G  product_lb_57
 L  product_ub_58
 G  product_lb_59
 L  product_ub_60
 G  product_lb_61
 L  product_ub_62
 G  product_lb_63
 L  product_ub_64
 E  onehot_22_65
 E  normalized_mass_22_66
 E  normalized_ratio_22_67
 G  product_lb_68
 L  product_ub_69
 G  product_lb_70
 L  product_ub_71
 G  product_lb_72
 L  product_ub_73
 G  product_lb_74
 L  product_ub_75
 G  product_lb_76
 L  product_ub_77
 G  product_lb_78
 L  product_ub_79
 G  product_lb_80
 L  product_ub_81
 G  product_lb_82
 L  product_ub_83
 G  product_lb_84
 L  product_ub_85
 G  product_lb_86
 L  product_ub_87
 G  product_lb_88
 L  product_ub_89
 G  product_lb_90
 L  product_ub_91
 G  product_lb_92
 L  product_ub_93
 E  onehot_31_94
 E  normalized_mass_31_95
 E  normalized_ratio_31_96
 G  product_lb_97
 L  product_ub_98
 G  product_lb_99
 L  product_ub_100
 G  product_lb_101
 L  product_ub_102
 G  product_lb_103
 L  product_ub_104
 G  product_lb_105
 L  product_ub_106
 G  product_lb_107
 L  product_ub_108
 G  product_lb_109
 L  product_ub_110
 G  product_lb_111
 L  product_ub_112
 G  product_lb_113
 L  product_ub_114
 G  product_lb_115
 L  product_ub_116
 G  product_lb_117
 L  product_ub_118
 G  product_lb_119
 L  product_ub_120
 G  product_lb_121
 L  product_ub_122
 G  product_lb_123
 L  product_ub_124
 G  product_lb_125
 L  product_ub_126
 G  product_lb_127
 L  product_ub_128
 E  onehot_14_129
 E  normalized_mass_14_130
 E  normalized_ratio_14_131
 G  product_lb_132
 L  product_ub_133
 G  product_lb_134
 L  product_ub_135
 G  product_lb_136
 L  product_ub_137
 G  product_lb_138
 L  product_ub_139
 G  product_lb_140
 L  product_ub_141
 G  product_lb_142
 L  product_ub_143
 G  product_lb_144
 L  product_ub_145
 G  product_lb_146
 L  product_ub_147
 G  product_lb_148
 L  product_ub_149
 G  product_lb_150
 L  product_ub_151
 G  product_lb_152
 L  product_ub_153
 G  product_lb_154
 L  product_ub_155
 G  product_lb_156
 L  product_ub_157
 E  onehot_16_158
 E  normalized_mass_16_159
 E  normalized_ratio_16_160
 G  product_lb_161
 L  product_ub_162
 G  product_lb_163
 L  product_ub_164
 G  product_lb_165
 L  product_ub_166
 G  product_lb_167
 L  product_ub_168
 G  product_lb_169
 L  product_ub_170
 G  product_lb_171
 L  product_ub_172
 G  product_lb_173
 L  product_ub_174
 G  product_lb_175
 L  product_ub_176
 G  product_lb_177
 L  product_ub_178
 G  product_lb_179
 L  product_ub_180
 G  product_lb_181
 L  product_ub_182
 G  product_lb_183
 L  product_ub_184
 G  product_lb_185
 L  product_ub_186
 G  product_lb_187
 L  product_ub_188
 G  product_lb_189
 L  product_ub_190
 G  product_lb_191
 L  product_ub_192
 G  product_lb_193
 L  product_ub_194
 E  onehot_5_195
 E  normalized_mass_5_196
 E  normalized_ratio_5_197
 G  product_lb_198
 L  product_ub_199
 G  product_lb_200
 L  product_ub_201
 G  product_lb_202
 L  product_ub_203
 G  product_lb_204
 L  product_ub_205
 G  product_lb_206
 L  product_ub_207
 G  product_lb_208
 L  product_ub_209
 G  product_lb_210
 L  product_ub_211
 G  product_lb_212
 L  product_ub_213
 G  product_lb_214
 L  product_ub_215
 G  product_lb_216
 L  product_ub_217
 G  product_lb_218
 L  product_ub_219
 G  product_lb_220
 L  product_ub_221
 G  product_lb_222
 L  product_ub_223
 E  onehot_32_224
 E  normalized_mass_32_225
 E  normalized_ratio_32_226
 G  product_lb_227
 L  product_ub_228
 G  product_lb_229
 L  product_ub_230
 G  product_lb_231
 L  product_ub_232
 G  product_lb_233
 L  product_ub_234
 G  product_lb_235
 L  product_ub_236
 G  product_lb_237
 L  product_ub_238
 G  product_lb_239
 L  product_ub_240
 G  product_lb_241
 L  product_ub_242
 G  product_lb_243
 L  product_ub_244
 G  product_lb_245
 L  product_ub_246
 G  product_lb_247
 L  product_ub_248
 G  product_lb_249
 L  product_ub_250
 G  product_lb_251
 L  product_ub_252
 G  product_lb_253
 L  product_ub_254
 G  product_lb_255
 L  product_ub_256
 G  product_lb_257
 L  product_ub_258
 G  product_lb_259
 L  product_ub_260
 G  product_lb_261
 L  product_ub_262
 E  onehot_3_263
 E  normalized_mass_3_264
 E  normalized_ratio_3_265
 G  stock_lb_266
 L  stock_ub_267
 L  parent_nonstrict_scope_268
 G  block_pair_pos_269
 G  block_pair_neg_270
 G  block_pair_pos_271
 G  block_pair_neg_272
 G  block_pair_pos_273
 G  block_pair_neg_274
 G  block_pair_pos_275
 G  block_pair_neg_276
 G  block_pair_pos_277
 G  block_pair_neg_278
 G  block_pair_pos_279
 G  block_pair_neg_280
 G  block_pair_pos_281
 G  block_pair_neg_282
 G  block_pair_pos_283
 G  block_pair_neg_284
 G  block_pair_pos_285
 G  block_pair_neg_286
 G  block_pair_pos_287
 G  block_pair_neg_288
 G  block_pair_pos_289
 G  block_pair_neg_290
 G  block_pair_pos_291
 G  block_pair_neg_292
 G  block_pair_pos_293
 G  block_pair_neg_294
 G  block_pair_pos_295
 G  block_pair_neg_296
 G  block_pair_pos_297
 G  block_pair_neg_298
 G  block_pair_pos_299
 G  block_pair_neg_300
 G  block_pair_pos_301
 G  block_pair_neg_302
 G  block_pair_pos_303
 G  block_pair_neg_304
 G  block_pair_pos_305
 G  block_pair_neg_306
 G  block_pair_pos_307
 G  block_pair_neg_308
 G  block_pair_pos_309
 G  block_pair_neg_310
 G  block_pair_pos_311
 G  block_pair_neg_312
 G  block_pair_pos_313
 G  block_pair_neg_314
 G  block_pair_pos_315
 G  block_pair_neg_316
 G  block_pair_pos_317
 G  block_pair_neg_318
 G  block_pair_pos_319
 G  block_pair_neg_320
 G  block_pair_pos_321
 G  block_pair_neg_322
 G  block_pair_pos_323
 G  block_pair_neg_324
 E  normalization_325
 G  full_original_Gini_326
 E  unique_nonzero_owner_327
 E  unique_nonzero_owner_328
 E  unique_nonzero_owner_329
 E  unique_nonzero_owner_330
 E  unique_nonzero_owner_331
 E  unique_nonzero_owner_332
 E  unique_nonzero_owner_333
 E  unique_nonzero_owner_334
 E  unique_nonzero_owner_335
 E  unique_nonzero_owner_336
 E  unique_nonzero_owner_337
 E  unique_nonzero_owner_338
 E  unique_nonzero_owner_339
 E  unique_nonzero_owner_340
 E  unique_nonzero_owner_341
 E  unique_nonzero_owner_342
 E  unique_nonzero_owner_343
 E  unique_nonzero_owner_344
 E  unique_nonzero_owner_345
 E  unique_nonzero_owner_346
 E  unique_nonzero_owner_347
 E  unique_nonzero_owner_348
 E  unique_nonzero_owner_349
 E  unique_nonzero_owner_350
 E  unique_nonzero_owner_351
 E  unique_nonzero_owner_352
 E  unique_nonzero_owner_353
 E  unique_nonzero_owner_354
 E  unique_nonzero_owner_355
 E  unique_nonzero_owner_356
 E  unique_nonzero_owner_357
 E  unique_nonzero_owner_358
 E  unique_nonzero_owner_359
 E  unique_nonzero_owner_360
 E  unique_nonzero_owner_361
 E  unique_nonzero_owner_362
 E  unique_nonzero_owner_363
 E  unique_nonzero_owner_364
 E  unique_nonzero_owner_365
 E  unique_nonzero_owner_366
 E  unique_nonzero_owner_367
 E  unique_nonzero_owner_368
 E  unique_nonzero_owner_369
 E  unique_nonzero_owner_370
 E  unique_nonzero_owner_371
 E  unique_nonzero_owner_372
 E  unique_nonzero_owner_373
 E  unique_nonzero_owner_374
 E  unique_nonzero_owner_375
 E  unique_nonzero_owner_376
 E  unique_nonzero_owner_377
 E  unique_nonzero_owner_378
 E  unique_nonzero_owner_379
 E  unique_nonzero_owner_380
 E  unique_nonzero_owner_381
 E  unique_nonzero_owner_382
 E  unique_nonzero_owner_383
 E  unique_nonzero_owner_384
 E  unique_nonzero_owner_385
 E  unique_nonzero_owner_386
 E  unique_nonzero_owner_387
 E  unique_nonzero_owner_388
 E  unique_nonzero_owner_389
 E  unique_nonzero_owner_390
 E  unique_nonzero_owner_391
 E  unique_nonzero_owner_392
 E  unique_nonzero_owner_393
 E  unique_nonzero_owner_394
 E  unique_nonzero_owner_395
 E  unique_nonzero_owner_396
 E  unique_nonzero_owner_397
 E  unique_nonzero_owner_398
 E  unique_nonzero_owner_399
 E  unique_nonzero_owner_400
 E  unique_nonzero_owner_401
 E  unique_nonzero_owner_402
 E  unique_nonzero_owner_403
 E  unique_nonzero_owner_404
 E  unique_nonzero_owner_405
 E  unique_nonzero_owner_406
 E  unique_nonzero_owner_407
 E  unique_nonzero_owner_408
 E  unique_nonzero_owner_409
 E  unique_nonzero_owner_410
 E  unique_nonzero_owner_411
 E  unique_nonzero_owner_412
 E  unique_nonzero_owner_413
 E  unique_nonzero_owner_414
 E  unique_nonzero_owner_415
 E  unique_nonzero_owner_416
 E  unique_nonzero_owner_417
 E  unique_nonzero_owner_418
 E  unique_nonzero_owner_419
 E  unique_nonzero_owner_420
 E  unique_nonzero_owner_421
 E  unique_nonzero_owner_422
 E  unique_nonzero_owner_423
 E  unique_nonzero_owner_424
 E  unique_nonzero_owner_425
 E  unique_nonzero_owner_426
 E  unique_nonzero_owner_427
 E  unique_nonzero_owner_428
 E  unique_nonzero_owner_429
 E  unique_nonzero_owner_430
 E  unique_nonzero_owner_431
 E  unique_nonzero_owner_432
 E  unique_nonzero_owner_433
 E  unique_nonzero_owner_434
 E  unique_nonzero_owner_435
 E  unique_nonzero_owner_436
 E  unique_nonzero_owner_437
 E  unique_nonzero_owner_438
 E  unique_nonzero_owner_439
 L  arc_capacity_440
 L  arc_capacity_441
 L  arc_capacity_442
 L  arc_capacity_443
 L  arc_capacity_444
 L  arc_capacity_445
 L  arc_capacity_446
 L  arc_capacity_447
 L  arc_capacity_448
 L  arc_capacity_449
 L  arc_capacity_450
 L  arc_capacity_451
 L  arc_capacity_452
 L  arc_capacity_453
 L  arc_capacity_454
 L  arc_capacity_455
 L  arc_capacity_456
 G  connected_order_arc_457
 L  arc_capacity_458
 G  connected_order_arc_459
 L  arc_capacity_460
 G  connected_order_arc_461
 L  arc_capacity_462
 G  connected_order_arc_463
 L  arc_capacity_464
 G  connected_order_arc_465
 L  arc_capacity_466
 G  connected_order_arc_467
 L  arc_capacity_468
 G  connected_order_arc_469
 L  arc_capacity_470
 G  connected_order_arc_471
 L  arc_capacity_472
 G  connected_order_arc_473
 L  arc_capacity_474
 G  connected_order_arc_475
 L  arc_capacity_476
 G  connected_order_arc_477
 L  arc_capacity_478
 G  connected_order_arc_479
 L  arc_capacity_480
 G  connected_order_arc_481
 L  arc_capacity_482
 L  arc_capacity_483
 G  connected_order_arc_484
 L  arc_capacity_485
 G  connected_order_arc_486
 L  arc_capacity_487
 G  connected_order_arc_488
 L  arc_capacity_489
 G  connected_order_arc_490
 L  arc_capacity_491
 G  connected_order_arc_492
 L  arc_capacity_493
 G  connected_order_arc_494
 L  arc_capacity_495
 G  connected_order_arc_496
 L  arc_capacity_497
 G  connected_order_arc_498
 L  arc_capacity_499
 G  connected_order_arc_500
 L  arc_capacity_501
 G  connected_order_arc_502
 L  arc_capacity_503
 G  connected_order_arc_504
 L  arc_capacity_505
 G  connected_order_arc_506
 L  arc_capacity_507
 G  connected_order_arc_508
 L  arc_capacity_509
 L  arc_capacity_510
 G  connected_order_arc_511
 L  arc_capacity_512
 G  connected_order_arc_513
 L  arc_capacity_514
 G  connected_order_arc_515
 L  arc_capacity_516
 G  connected_order_arc_517
 L  arc_capacity_518
 G  connected_order_arc_519
 L  arc_capacity_520
 G  connected_order_arc_521
 L  arc_capacity_522
 G  connected_order_arc_523
 L  arc_capacity_524
 G  connected_order_arc_525
 L  arc_capacity_526
 G  connected_order_arc_527
 L  arc_capacity_528
 G  connected_order_arc_529
 L  arc_capacity_530
 G  connected_order_arc_531
 L  arc_capacity_532
 G  connected_order_arc_533
 L  arc_capacity_534
 G  connected_order_arc_535
 L  arc_capacity_536
 L  arc_capacity_537
 G  connected_order_arc_538
 L  arc_capacity_539
 G  connected_order_arc_540
 L  arc_capacity_541
 G  connected_order_arc_542
 L  arc_capacity_543
 G  connected_order_arc_544
 L  arc_capacity_545
 G  connected_order_arc_546
 L  arc_capacity_547
 G  connected_order_arc_548
 L  arc_capacity_549
 G  connected_order_arc_550
 L  arc_capacity_551
 G  connected_order_arc_552
 L  arc_capacity_553
 G  connected_order_arc_554
 L  arc_capacity_555
 G  connected_order_arc_556
 L  arc_capacity_557
 G  connected_order_arc_558
 L  arc_capacity_559
 G  connected_order_arc_560
 L  arc_capacity_561
 G  connected_order_arc_562
 L  arc_capacity_563
 L  arc_capacity_564
 G  connected_order_arc_565
 L  arc_capacity_566
 G  connected_order_arc_567
 L  arc_capacity_568
 G  connected_order_arc_569
 L  arc_capacity_570
 G  connected_order_arc_571
 L  arc_capacity_572
 G  connected_order_arc_573
 L  arc_capacity_574
 G  connected_order_arc_575
 L  arc_capacity_576
 G  connected_order_arc_577
 L  arc_capacity_578
 G  connected_order_arc_579
 L  arc_capacity_580
 G  connected_order_arc_581
 L  arc_capacity_582
 G  connected_order_arc_583
 L  arc_capacity_584
 G  connected_order_arc_585
 L  arc_capacity_586
 G  connected_order_arc_587
 L  arc_capacity_588
 G  connected_order_arc_589
 L  arc_capacity_590
 L  arc_capacity_591
 G  connected_order_arc_592
 L  arc_capacity_593
 G  connected_order_arc_594
 L  arc_capacity_595
 G  connected_order_arc_596
 L  arc_capacity_597
 G  connected_order_arc_598
 L  arc_capacity_599
 G  connected_order_arc_600
 L  arc_capacity_601
 G  connected_order_arc_602
 L  arc_capacity_603
 G  connected_order_arc_604
 L  arc_capacity_605
 G  connected_order_arc_606
 L  arc_capacity_607
 G  connected_order_arc_608
 L  arc_capacity_609
 G  connected_order_arc_610
 L  arc_capacity_611
 G  connected_order_arc_612
 L  arc_capacity_613
 G  connected_order_arc_614
 L  arc_capacity_615
 G  connected_order_arc_616
 L  arc_capacity_617
 L  arc_capacity_618
 G  connected_order_arc_619
 L  arc_capacity_620
 G  connected_order_arc_621
 L  arc_capacity_622
 G  connected_order_arc_623
 L  arc_capacity_624
 G  connected_order_arc_625
 L  arc_capacity_626
 G  connected_order_arc_627
 L  arc_capacity_628
 G  connected_order_arc_629
 L  arc_capacity_630
 G  connected_order_arc_631
 L  arc_capacity_632
 G  connected_order_arc_633
 L  arc_capacity_634
 G  connected_order_arc_635
 L  arc_capacity_636
 G  connected_order_arc_637
 L  arc_capacity_638
 G  connected_order_arc_639
 L  arc_capacity_640
 G  connected_order_arc_641
 L  arc_capacity_642
 G  connected_order_arc_643
 L  arc_capacity_644
 L  arc_capacity_645
 G  connected_order_arc_646
 L  arc_capacity_647
 G  connected_order_arc_648
 L  arc_capacity_649
 G  connected_order_arc_650
 L  arc_capacity_651
 G  connected_order_arc_652
 L  arc_capacity_653
 G  connected_order_arc_654
 L  arc_capacity_655
 G  connected_order_arc_656
 L  arc_capacity_657
 G  connected_order_arc_658
 L  arc_capacity_659
 G  connected_order_arc_660
 L  arc_capacity_661
 G  connected_order_arc_662
 L  arc_capacity_663
 G  connected_order_arc_664
 L  arc_capacity_665
 G  connected_order_arc_666
 L  arc_capacity_667
 G  connected_order_arc_668
 L  arc_capacity_669
 G  connected_order_arc_670
 L  arc_capacity_671
 L  arc_capacity_672
 G  connected_order_arc_673
 L  arc_capacity_674
 G  connected_order_arc_675
 L  arc_capacity_676
 G  connected_order_arc_677
 L  arc_capacity_678
 G  connected_order_arc_679
 L  arc_capacity_680
 G  connected_order_arc_681
 L  arc_capacity_682
 G  connected_order_arc_683
 L  arc_capacity_684
 G  connected_order_arc_685
 L  arc_capacity_686
 G  connected_order_arc_687
 L  arc_capacity_688
 G  connected_order_arc_689
 L  arc_capacity_690
 G  connected_order_arc_691
 L  arc_capacity_692
 G  connected_order_arc_693
 L  arc_capacity_694
 G  connected_order_arc_695
 L  arc_capacity_696
 G  connected_order_arc_697
 L  arc_capacity_698
 L  arc_capacity_699
 G  connected_order_arc_700
 L  arc_capacity_701
 G  connected_order_arc_702
 L  arc_capacity_703
 G  connected_order_arc_704
 L  arc_capacity_705
 G  connected_order_arc_706
 L  arc_capacity_707
 G  connected_order_arc_708
 L  arc_capacity_709
 G  connected_order_arc_710
 L  arc_capacity_711
 G  connected_order_arc_712
 L  arc_capacity_713
 G  connected_order_arc_714
 L  arc_capacity_715
 G  connected_order_arc_716
 L  arc_capacity_717
 G  connected_order_arc_718
 L  arc_capacity_719
 G  connected_order_arc_720
 L  arc_capacity_721
 G  connected_order_arc_722
 L  arc_capacity_723
 G  connected_order_arc_724
 L  arc_capacity_725
 L  arc_capacity_726
 G  connected_order_arc_727
 L  arc_capacity_728
 G  connected_order_arc_729
 L  arc_capacity_730
 G  connected_order_arc_731
 L  arc_capacity_732
 G  connected_order_arc_733
 L  arc_capacity_734
 G  connected_order_arc_735
 L  arc_capacity_736
 G  connected_order_arc_737
 L  arc_capacity_738
 G  connected_order_arc_739
 L  arc_capacity_740
 G  connected_order_arc_741
 L  arc_capacity_742
 G  connected_order_arc_743
 L  arc_capacity_744
 G  connected_order_arc_745
 L  arc_capacity_746
 G  connected_order_arc_747
 L  arc_capacity_748
 G  connected_order_arc_749
 L  arc_capacity_750
 G  connected_order_arc_751
 L  arc_capacity_752
 L  arc_capacity_753
 G  connected_order_arc_754
 L  arc_capacity_755
 G  connected_order_arc_756
 L  arc_capacity_757
 G  connected_order_arc_758
 L  arc_capacity_759
 G  connected_order_arc_760
 L  arc_capacity_761
 G  connected_order_arc_762
 L  arc_capacity_763
 G  connected_order_arc_764
 L  arc_capacity_765
 G  connected_order_arc_766
 L  arc_capacity_767
 G  connected_order_arc_768
 L  arc_capacity_769
 G  connected_order_arc_770
 L  arc_capacity_771
 G  connected_order_arc_772
 L  arc_capacity_773
 G  connected_order_arc_774
 L  arc_capacity_775
 G  connected_order_arc_776
 L  arc_capacity_777
 G  connected_order_arc_778
 L  arc_capacity_779
 L  arc_capacity_780
 G  connected_order_arc_781
 L  arc_capacity_782
 G  connected_order_arc_783
 L  arc_capacity_784
 G  connected_order_arc_785
 L  arc_capacity_786
 G  connected_order_arc_787
 L  arc_capacity_788
 G  connected_order_arc_789
 L  arc_capacity_790
 G  connected_order_arc_791
 L  arc_capacity_792
 G  connected_order_arc_793
 L  arc_capacity_794
 G  connected_order_arc_795
 L  arc_capacity_796
 G  connected_order_arc_797
 L  arc_capacity_798
 G  connected_order_arc_799
 L  arc_capacity_800
 G  connected_order_arc_801
 L  arc_capacity_802
 G  connected_order_arc_803
 L  arc_capacity_804
 G  connected_order_arc_805
 L  arc_capacity_806
 L  arc_capacity_807
 G  connected_order_arc_808
 L  arc_capacity_809
 G  connected_order_arc_810
 L  arc_capacity_811
 G  connected_order_arc_812
 L  arc_capacity_813
 G  connected_order_arc_814
 L  arc_capacity_815
 G  connected_order_arc_816
 L  arc_capacity_817
 G  connected_order_arc_818
 L  arc_capacity_819
 G  connected_order_arc_820
 L  arc_capacity_821
 G  connected_order_arc_822
 L  arc_capacity_823
 G  connected_order_arc_824
 L  arc_capacity_825
 G  connected_order_arc_826
 L  arc_capacity_827
 G  connected_order_arc_828
 L  arc_capacity_829
 G  connected_order_arc_830
 L  arc_capacity_831
 G  connected_order_arc_832
 E  depot_departure_or_bypass_833
 E  depot_return_or_bypass_834
 E  out_degree_835
 E  in_degree_836
 G  order_active_lb_837
 L  order_active_ub_838
 E  segment_load_conservation_839
 G  segment_prefix_lb_840
 L  segment_prefix_ub_841
 E  out_degree_842
 E  in_degree_843
 G  order_active_lb_844
 L  order_active_ub_845
 E  segment_load_conservation_846
 G  segment_prefix_lb_847
 L  segment_prefix_ub_848
 E  out_degree_849
 E  in_degree_850
 G  order_active_lb_851
 L  order_active_ub_852
 E  segment_load_conservation_853
 G  segment_prefix_lb_854
 L  segment_prefix_ub_855
 E  out_degree_856
 E  in_degree_857
 G  order_active_lb_858
 L  order_active_ub_859
 E  segment_load_conservation_860
 G  segment_prefix_lb_861
 L  segment_prefix_ub_862
 E  out_degree_863
 E  in_degree_864
 G  order_active_lb_865
 L  order_active_ub_866
 E  segment_load_conservation_867
 G  segment_prefix_lb_868
 L  segment_prefix_ub_869
 E  out_degree_870
 E  in_degree_871
 G  order_active_lb_872
 L  order_active_ub_873
 E  segment_load_conservation_874
 G  segment_prefix_lb_875
 L  segment_prefix_ub_876
 E  out_degree_877
 E  in_degree_878
 G  order_active_lb_879
 L  order_active_ub_880
 E  service_visit_def_881
 E  free_load_conservation_882
 E  out_degree_883
 E  in_degree_884
 G  order_active_lb_885
 L  order_active_ub_886
 E  service_visit_def_887
 E  free_load_conservation_888
 E  out_degree_889
 E  in_degree_890
 G  order_active_lb_891
 L  order_active_ub_892
 E  service_visit_def_893
 E  free_load_conservation_894
 E  out_degree_895
 E  in_degree_896
 G  order_active_lb_897
 L  order_active_ub_898
 E  service_visit_def_899
 E  free_load_conservation_900
 E  out_degree_901
 E  in_degree_902
 G  order_active_lb_903
 L  order_active_ub_904
 E  service_visit_def_905
 E  free_load_conservation_906
 E  out_degree_907
 E  in_degree_908
 G  order_active_lb_909
 L  order_active_ub_910
 E  service_visit_def_911
 E  free_load_conservation_912
 E  out_degree_913
 E  in_degree_914
 G  order_active_lb_915
 L  order_active_ub_916
 E  service_visit_def_917
 E  free_load_conservation_918
 E  out_degree_919
 E  in_degree_920
 G  order_active_lb_921
 L  order_active_ub_922
 E  service_visit_def_923
 E  free_load_conservation_924
 G  fixed_segment_relative_order_925
 G  fixed_segment_relative_order_926
 G  fixed_segment_relative_order_927
 G  fixed_segment_relative_order_928
 G  fixed_segment_relative_order_929
 L  original_T_including_depot_unload_930
 L  arc_capacity_931
 L  arc_capacity_932
 L  arc_capacity_933
 L  arc_capacity_934
 L  arc_capacity_935
 L  arc_capacity_936
 L  arc_capacity_937
 L  arc_capacity_938
 L  arc_capacity_939
 L  arc_capacity_940
 L  arc_capacity_941
 L  arc_capacity_942
 L  arc_capacity_943
 L  arc_capacity_944
 L  arc_capacity_945
 L  arc_capacity_946
 G  connected_order_arc_947
 L  arc_capacity_948
 G  connected_order_arc_949
 L  arc_capacity_950
 G  connected_order_arc_951
 L  arc_capacity_952
 G  connected_order_arc_953
 L  arc_capacity_954
 G  connected_order_arc_955
 L  arc_capacity_956
 G  connected_order_arc_957
 L  arc_capacity_958
 G  connected_order_arc_959
 L  arc_capacity_960
 G  connected_order_arc_961
 L  arc_capacity_962
 G  connected_order_arc_963
 L  arc_capacity_964
 G  connected_order_arc_965
 L  arc_capacity_966
 G  connected_order_arc_967
 L  arc_capacity_968
 G  connected_order_arc_969
 L  arc_capacity_970
 L  arc_capacity_971
 G  connected_order_arc_972
 L  arc_capacity_973
 G  connected_order_arc_974
 L  arc_capacity_975
 G  connected_order_arc_976
 L  arc_capacity_977
 G  connected_order_arc_978
 L  arc_capacity_979
 G  connected_order_arc_980
 L  arc_capacity_981
 G  connected_order_arc_982
 L  arc_capacity_983
 G  connected_order_arc_984
 L  arc_capacity_985
 G  connected_order_arc_986
 L  arc_capacity_987
 G  connected_order_arc_988
 L  arc_capacity_989
 G  connected_order_arc_990
 L  arc_capacity_991
 G  connected_order_arc_992
 L  arc_capacity_993
 G  connected_order_arc_994
 L  arc_capacity_995
 L  arc_capacity_996
 G  connected_order_arc_997
 L  arc_capacity_998
 G  connected_order_arc_999
 L  arc_capacity_1000
 G  connected_order_arc_1001
 L  arc_capacity_1002
 G  connected_order_arc_1003
 L  arc_capacity_1004
 G  connected_order_arc_1005
 L  arc_capacity_1006
 G  connected_order_arc_1007
 L  arc_capacity_1008
 G  connected_order_arc_1009
 L  arc_capacity_1010
 G  connected_order_arc_1011
 L  arc_capacity_1012
 G  connected_order_arc_1013
 L  arc_capacity_1014
 G  connected_order_arc_1015
 L  arc_capacity_1016
 G  connected_order_arc_1017
 L  arc_capacity_1018
 G  connected_order_arc_1019
 L  arc_capacity_1020
 L  arc_capacity_1021
 G  connected_order_arc_1022
 L  arc_capacity_1023
 G  connected_order_arc_1024
 L  arc_capacity_1025
 G  connected_order_arc_1026
 L  arc_capacity_1027
 G  connected_order_arc_1028
 L  arc_capacity_1029
 G  connected_order_arc_1030
 L  arc_capacity_1031
 G  connected_order_arc_1032
 L  arc_capacity_1033
 G  connected_order_arc_1034
 L  arc_capacity_1035
 G  connected_order_arc_1036
 L  arc_capacity_1037
 G  connected_order_arc_1038
 L  arc_capacity_1039
 G  connected_order_arc_1040
 L  arc_capacity_1041
 G  connected_order_arc_1042
 L  arc_capacity_1043
 G  connected_order_arc_1044
 L  arc_capacity_1045
 L  arc_capacity_1046
 G  connected_order_arc_1047
 L  arc_capacity_1048
 G  connected_order_arc_1049
 L  arc_capacity_1050
 G  connected_order_arc_1051
 L  arc_capacity_1052
 G  connected_order_arc_1053
 L  arc_capacity_1054
 G  connected_order_arc_1055
 L  arc_capacity_1056
 G  connected_order_arc_1057
 L  arc_capacity_1058
 G  connected_order_arc_1059
 L  arc_capacity_1060
 G  connected_order_arc_1061
 L  arc_capacity_1062
 G  connected_order_arc_1063
 L  arc_capacity_1064
 G  connected_order_arc_1065
 L  arc_capacity_1066
 G  connected_order_arc_1067
 L  arc_capacity_1068
 G  connected_order_arc_1069
 L  arc_capacity_1070
 L  arc_capacity_1071
 G  connected_order_arc_1072
 L  arc_capacity_1073
 G  connected_order_arc_1074
 L  arc_capacity_1075
 G  connected_order_arc_1076
 L  arc_capacity_1077
 G  connected_order_arc_1078
 L  arc_capacity_1079
 G  connected_order_arc_1080
 L  arc_capacity_1081
 G  connected_order_arc_1082
 L  arc_capacity_1083
 G  connected_order_arc_1084
 L  arc_capacity_1085
 G  connected_order_arc_1086
 L  arc_capacity_1087
 G  connected_order_arc_1088
 L  arc_capacity_1089
 G  connected_order_arc_1090
 L  arc_capacity_1091
 G  connected_order_arc_1092
 L  arc_capacity_1093
 G  connected_order_arc_1094
 L  arc_capacity_1095
 L  arc_capacity_1096
 G  connected_order_arc_1097
 L  arc_capacity_1098
 G  connected_order_arc_1099
 L  arc_capacity_1100
 G  connected_order_arc_1101
 L  arc_capacity_1102
 G  connected_order_arc_1103
 L  arc_capacity_1104
 G  connected_order_arc_1105
 L  arc_capacity_1106
 G  connected_order_arc_1107
 L  arc_capacity_1108
 G  connected_order_arc_1109
 L  arc_capacity_1110
 G  connected_order_arc_1111
 L  arc_capacity_1112
 G  connected_order_arc_1113
 L  arc_capacity_1114
 G  connected_order_arc_1115
 L  arc_capacity_1116
 G  connected_order_arc_1117
 L  arc_capacity_1118
 G  connected_order_arc_1119
 L  arc_capacity_1120
 L  arc_capacity_1121
 G  connected_order_arc_1122
 L  arc_capacity_1123
 G  connected_order_arc_1124
 L  arc_capacity_1125
 G  connected_order_arc_1126
 L  arc_capacity_1127
 G  connected_order_arc_1128
 L  arc_capacity_1129
 G  connected_order_arc_1130
 L  arc_capacity_1131
 G  connected_order_arc_1132
 L  arc_capacity_1133
 G  connected_order_arc_1134
 L  arc_capacity_1135
 G  connected_order_arc_1136
 L  arc_capacity_1137
 G  connected_order_arc_1138
 L  arc_capacity_1139
 G  connected_order_arc_1140
 L  arc_capacity_1141
 G  connected_order_arc_1142
 L  arc_capacity_1143
 G  connected_order_arc_1144
 L  arc_capacity_1145
 L  arc_capacity_1146
 G  connected_order_arc_1147
 L  arc_capacity_1148
 G  connected_order_arc_1149
 L  arc_capacity_1150
 G  connected_order_arc_1151
 L  arc_capacity_1152
 G  connected_order_arc_1153
 L  arc_capacity_1154
 G  connected_order_arc_1155
 L  arc_capacity_1156
 G  connected_order_arc_1157
 L  arc_capacity_1158
 G  connected_order_arc_1159
 L  arc_capacity_1160
 G  connected_order_arc_1161
 L  arc_capacity_1162
 G  connected_order_arc_1163
 L  arc_capacity_1164
 G  connected_order_arc_1165
 L  arc_capacity_1166
 G  connected_order_arc_1167
 L  arc_capacity_1168
 G  connected_order_arc_1169
 L  arc_capacity_1170
 L  arc_capacity_1171
 G  connected_order_arc_1172
 L  arc_capacity_1173
 G  connected_order_arc_1174
 L  arc_capacity_1175
 G  connected_order_arc_1176
 L  arc_capacity_1177
 G  connected_order_arc_1178
 L  arc_capacity_1179
 G  connected_order_arc_1180
 L  arc_capacity_1181
 G  connected_order_arc_1182
 L  arc_capacity_1183
 G  connected_order_arc_1184
 L  arc_capacity_1185
 G  connected_order_arc_1186
 L  arc_capacity_1187
 G  connected_order_arc_1188
 L  arc_capacity_1189
 G  connected_order_arc_1190
 L  arc_capacity_1191
 G  connected_order_arc_1192
 L  arc_capacity_1193
 G  connected_order_arc_1194
 L  arc_capacity_1195
 L  arc_capacity_1196
 G  connected_order_arc_1197
 L  arc_capacity_1198
 G  connected_order_arc_1199
 L  arc_capacity_1200
 G  connected_order_arc_1201
 L  arc_capacity_1202
 G  connected_order_arc_1203
 L  arc_capacity_1204
 G  connected_order_arc_1205
 L  arc_capacity_1206
 G  connected_order_arc_1207
 L  arc_capacity_1208
 G  connected_order_arc_1209
 L  arc_capacity_1210
 G  connected_order_arc_1211
 L  arc_capacity_1212
 G  connected_order_arc_1213
 L  arc_capacity_1214
 G  connected_order_arc_1215
 L  arc_capacity_1216
 G  connected_order_arc_1217
 L  arc_capacity_1218
 G  connected_order_arc_1219
 L  arc_capacity_1220
 L  arc_capacity_1221
 G  connected_order_arc_1222
 L  arc_capacity_1223
 G  connected_order_arc_1224
 L  arc_capacity_1225
 G  connected_order_arc_1226
 L  arc_capacity_1227
 G  connected_order_arc_1228
 L  arc_capacity_1229
 G  connected_order_arc_1230
 L  arc_capacity_1231
 G  connected_order_arc_1232
 L  arc_capacity_1233
 G  connected_order_arc_1234
 L  arc_capacity_1235
 G  connected_order_arc_1236
 L  arc_capacity_1237
 G  connected_order_arc_1238
 L  arc_capacity_1239
 G  connected_order_arc_1240
 L  arc_capacity_1241
 G  connected_order_arc_1242
 L  arc_capacity_1243
 G  connected_order_arc_1244
 L  arc_capacity_1245
 L  arc_capacity_1246
 G  connected_order_arc_1247
 L  arc_capacity_1248
 G  connected_order_arc_1249
 L  arc_capacity_1250
 G  connected_order_arc_1251
 L  arc_capacity_1252
 G  connected_order_arc_1253
 L  arc_capacity_1254
 G  connected_order_arc_1255
 L  arc_capacity_1256
 G  connected_order_arc_1257
 L  arc_capacity_1258
 G  connected_order_arc_1259
 L  arc_capacity_1260
 G  connected_order_arc_1261
 L  arc_capacity_1262
 G  connected_order_arc_1263
 L  arc_capacity_1264
 G  connected_order_arc_1265
 L  arc_capacity_1266
 G  connected_order_arc_1267
 L  arc_capacity_1268
 G  connected_order_arc_1269
 E  depot_departure_or_bypass_1270
 E  depot_return_or_bypass_1271
 E  out_degree_1272
 E  in_degree_1273
 G  order_active_lb_1274
 L  order_active_ub_1275
 E  segment_load_conservation_1276
 G  segment_prefix_lb_1277
 L  segment_prefix_ub_1278
 E  out_degree_1279
 E  in_degree_1280
 G  order_active_lb_1281
 L  order_active_ub_1282
 E  segment_load_conservation_1283
 G  segment_prefix_lb_1284
 L  segment_prefix_ub_1285
 E  out_degree_1286
 E  in_degree_1287
 G  order_active_lb_1288
 L  order_active_ub_1289
 E  segment_load_conservation_1290
 G  segment_prefix_lb_1291
 L  segment_prefix_ub_1292
 E  out_degree_1293
 E  in_degree_1294
 G  order_active_lb_1295
 L  order_active_ub_1296
 E  segment_load_conservation_1297
 G  segment_prefix_lb_1298
 L  segment_prefix_ub_1299
 E  out_degree_1300
 E  in_degree_1301
 G  order_active_lb_1302
 L  order_active_ub_1303
 E  segment_load_conservation_1304
 G  segment_prefix_lb_1305
 L  segment_prefix_ub_1306
 E  out_degree_1307
 E  in_degree_1308
 G  order_active_lb_1309
 L  order_active_ub_1310
 E  service_visit_def_1311
 E  free_load_conservation_1312
 E  out_degree_1313
 E  in_degree_1314
 G  order_active_lb_1315
 L  order_active_ub_1316
 E  service_visit_def_1317
 E  free_load_conservation_1318
 E  out_degree_1319
 E  in_degree_1320
 G  order_active_lb_1321
 L  order_active_ub_1322
 E  service_visit_def_1323
 E  free_load_conservation_1324
 E  out_degree_1325
 E  in_degree_1326
 G  order_active_lb_1327
 L  order_active_ub_1328
 E  service_visit_def_1329
 E  free_load_conservation_1330
 E  out_degree_1331
 E  in_degree_1332
 G  order_active_lb_1333
 L  order_active_ub_1334
 E  service_visit_def_1335
 E  free_load_conservation_1336
 E  out_degree_1337
 E  in_degree_1338
 G  order_active_lb_1339
 L  order_active_ub_1340
 E  service_visit_def_1341
 E  free_load_conservation_1342
 E  out_degree_1343
 E  in_degree_1344
 G  order_active_lb_1345
 L  order_active_ub_1346
 E  service_visit_def_1347
 E  free_load_conservation_1348
 E  out_degree_1349
 E  in_degree_1350
 G  order_active_lb_1351
 L  order_active_ub_1352
 E  service_visit_def_1353
 E  free_load_conservation_1354
 G  fixed_segment_relative_order_1355
 G  fixed_segment_relative_order_1356
 G  fixed_segment_relative_order_1357
 G  fixed_segment_relative_order_1358
 L  original_T_including_depot_unload_1359
 L  arc_capacity_1360
 L  arc_capacity_1361
 L  arc_capacity_1362
 L  arc_capacity_1363
 L  arc_capacity_1364
 L  arc_capacity_1365
 L  arc_capacity_1366
 L  arc_capacity_1367
 L  arc_capacity_1368
 L  arc_capacity_1369
 L  arc_capacity_1370
 L  arc_capacity_1371
 L  arc_capacity_1372
 L  arc_capacity_1373
 L  arc_capacity_1374
 L  arc_capacity_1375
 G  connected_order_arc_1376
 L  arc_capacity_1377
 G  connected_order_arc_1378
 L  arc_capacity_1379
 G  connected_order_arc_1380
 L  arc_capacity_1381
 G  connected_order_arc_1382
 L  arc_capacity_1383
 G  connected_order_arc_1384
 L  arc_capacity_1385
 G  connected_order_arc_1386
 L  arc_capacity_1387
 G  connected_order_arc_1388
 L  arc_capacity_1389
 G  connected_order_arc_1390
 L  arc_capacity_1391
 G  connected_order_arc_1392
 L  arc_capacity_1393
 G  connected_order_arc_1394
 L  arc_capacity_1395
 G  connected_order_arc_1396
 L  arc_capacity_1397
 G  connected_order_arc_1398
 L  arc_capacity_1399
 L  arc_capacity_1400
 G  connected_order_arc_1401
 L  arc_capacity_1402
 G  connected_order_arc_1403
 L  arc_capacity_1404
 G  connected_order_arc_1405
 L  arc_capacity_1406
 G  connected_order_arc_1407
 L  arc_capacity_1408
 G  connected_order_arc_1409
 L  arc_capacity_1410
 G  connected_order_arc_1411
 L  arc_capacity_1412
 G  connected_order_arc_1413
 L  arc_capacity_1414
 G  connected_order_arc_1415
 L  arc_capacity_1416
 G  connected_order_arc_1417
 L  arc_capacity_1418
 G  connected_order_arc_1419
 L  arc_capacity_1420
 G  connected_order_arc_1421
 L  arc_capacity_1422
 G  connected_order_arc_1423
 L  arc_capacity_1424
 L  arc_capacity_1425
 G  connected_order_arc_1426
 L  arc_capacity_1427
 G  connected_order_arc_1428
 L  arc_capacity_1429
 G  connected_order_arc_1430
 L  arc_capacity_1431
 G  connected_order_arc_1432
 L  arc_capacity_1433
 G  connected_order_arc_1434
 L  arc_capacity_1435
 G  connected_order_arc_1436
 L  arc_capacity_1437
 G  connected_order_arc_1438
 L  arc_capacity_1439
 G  connected_order_arc_1440
 L  arc_capacity_1441
 G  connected_order_arc_1442
 L  arc_capacity_1443
 G  connected_order_arc_1444
 L  arc_capacity_1445
 G  connected_order_arc_1446
 L  arc_capacity_1447
 G  connected_order_arc_1448
 L  arc_capacity_1449
 L  arc_capacity_1450
 G  connected_order_arc_1451
 L  arc_capacity_1452
 G  connected_order_arc_1453
 L  arc_capacity_1454
 G  connected_order_arc_1455
 L  arc_capacity_1456
 G  connected_order_arc_1457
 L  arc_capacity_1458
 G  connected_order_arc_1459
 L  arc_capacity_1460
 G  connected_order_arc_1461
 L  arc_capacity_1462
 G  connected_order_arc_1463
 L  arc_capacity_1464
 G  connected_order_arc_1465
 L  arc_capacity_1466
 G  connected_order_arc_1467
 L  arc_capacity_1468
 G  connected_order_arc_1469
 L  arc_capacity_1470
 G  connected_order_arc_1471
 L  arc_capacity_1472
 G  connected_order_arc_1473
 L  arc_capacity_1474
 L  arc_capacity_1475
 G  connected_order_arc_1476
 L  arc_capacity_1477
 G  connected_order_arc_1478
 L  arc_capacity_1479
 G  connected_order_arc_1480
 L  arc_capacity_1481
 G  connected_order_arc_1482
 L  arc_capacity_1483
 G  connected_order_arc_1484
 L  arc_capacity_1485
 G  connected_order_arc_1486
 L  arc_capacity_1487
 G  connected_order_arc_1488
 L  arc_capacity_1489
 G  connected_order_arc_1490
 L  arc_capacity_1491
 G  connected_order_arc_1492
 L  arc_capacity_1493
 G  connected_order_arc_1494
 L  arc_capacity_1495
 G  connected_order_arc_1496
 L  arc_capacity_1497
 G  connected_order_arc_1498
 L  arc_capacity_1499
 L  arc_capacity_1500
 G  connected_order_arc_1501
 L  arc_capacity_1502
 G  connected_order_arc_1503
 L  arc_capacity_1504
 G  connected_order_arc_1505
 L  arc_capacity_1506
 G  connected_order_arc_1507
 L  arc_capacity_1508
 G  connected_order_arc_1509
 L  arc_capacity_1510
 G  connected_order_arc_1511
 L  arc_capacity_1512
 G  connected_order_arc_1513
 L  arc_capacity_1514
 G  connected_order_arc_1515
 L  arc_capacity_1516
 G  connected_order_arc_1517
 L  arc_capacity_1518
 G  connected_order_arc_1519
 L  arc_capacity_1520
 G  connected_order_arc_1521
 L  arc_capacity_1522
 G  connected_order_arc_1523
 L  arc_capacity_1524
 L  arc_capacity_1525
 G  connected_order_arc_1526
 L  arc_capacity_1527
 G  connected_order_arc_1528
 L  arc_capacity_1529
 G  connected_order_arc_1530
 L  arc_capacity_1531
 G  connected_order_arc_1532
 L  arc_capacity_1533
 G  connected_order_arc_1534
 L  arc_capacity_1535
 G  connected_order_arc_1536
 L  arc_capacity_1537
 G  connected_order_arc_1538
 L  arc_capacity_1539
 G  connected_order_arc_1540
 L  arc_capacity_1541
 G  connected_order_arc_1542
 L  arc_capacity_1543
 G  connected_order_arc_1544
 L  arc_capacity_1545
 G  connected_order_arc_1546
 L  arc_capacity_1547
 G  connected_order_arc_1548
 L  arc_capacity_1549
 L  arc_capacity_1550
 G  connected_order_arc_1551
 L  arc_capacity_1552
 G  connected_order_arc_1553
 L  arc_capacity_1554
 G  connected_order_arc_1555
 L  arc_capacity_1556
 G  connected_order_arc_1557
 L  arc_capacity_1558
 G  connected_order_arc_1559
 L  arc_capacity_1560
 G  connected_order_arc_1561
 L  arc_capacity_1562
 G  connected_order_arc_1563
 L  arc_capacity_1564
 G  connected_order_arc_1565
 L  arc_capacity_1566
 G  connected_order_arc_1567
 L  arc_capacity_1568
 G  connected_order_arc_1569
 L  arc_capacity_1570
 G  connected_order_arc_1571
 L  arc_capacity_1572
 G  connected_order_arc_1573
 L  arc_capacity_1574
 L  arc_capacity_1575
 G  connected_order_arc_1576
 L  arc_capacity_1577
 G  connected_order_arc_1578
 L  arc_capacity_1579
 G  connected_order_arc_1580
 L  arc_capacity_1581
 G  connected_order_arc_1582
 L  arc_capacity_1583
 G  connected_order_arc_1584
 L  arc_capacity_1585
 G  connected_order_arc_1586
 L  arc_capacity_1587
 G  connected_order_arc_1588
 L  arc_capacity_1589
 G  connected_order_arc_1590
 L  arc_capacity_1591
 G  connected_order_arc_1592
 L  arc_capacity_1593
 G  connected_order_arc_1594
 L  arc_capacity_1595
 G  connected_order_arc_1596
 L  arc_capacity_1597
 G  connected_order_arc_1598
 L  arc_capacity_1599
 L  arc_capacity_1600
 G  connected_order_arc_1601
 L  arc_capacity_1602
 G  connected_order_arc_1603
 L  arc_capacity_1604
 G  connected_order_arc_1605
 L  arc_capacity_1606
 G  connected_order_arc_1607
 L  arc_capacity_1608
 G  connected_order_arc_1609
 L  arc_capacity_1610
 G  connected_order_arc_1611
 L  arc_capacity_1612
 G  connected_order_arc_1613
 L  arc_capacity_1614
 G  connected_order_arc_1615
 L  arc_capacity_1616
 G  connected_order_arc_1617
 L  arc_capacity_1618
 G  connected_order_arc_1619
 L  arc_capacity_1620
 G  connected_order_arc_1621
 L  arc_capacity_1622
 G  connected_order_arc_1623
 L  arc_capacity_1624
 L  arc_capacity_1625
 G  connected_order_arc_1626
 L  arc_capacity_1627
 G  connected_order_arc_1628
 L  arc_capacity_1629
 G  connected_order_arc_1630
 L  arc_capacity_1631
 G  connected_order_arc_1632
 L  arc_capacity_1633
 G  connected_order_arc_1634
 L  arc_capacity_1635
 G  connected_order_arc_1636
 L  arc_capacity_1637
 G  connected_order_arc_1638
 L  arc_capacity_1639
 G  connected_order_arc_1640
 L  arc_capacity_1641
 G  connected_order_arc_1642
 L  arc_capacity_1643
 G  connected_order_arc_1644
 L  arc_capacity_1645
 G  connected_order_arc_1646
 L  arc_capacity_1647
 G  connected_order_arc_1648
 L  arc_capacity_1649
 L  arc_capacity_1650
 G  connected_order_arc_1651
 L  arc_capacity_1652
 G  connected_order_arc_1653
 L  arc_capacity_1654
 G  connected_order_arc_1655
 L  arc_capacity_1656
 G  connected_order_arc_1657
 L  arc_capacity_1658
 G  connected_order_arc_1659
 L  arc_capacity_1660
 G  connected_order_arc_1661
 L  arc_capacity_1662
 G  connected_order_arc_1663
 L  arc_capacity_1664
 G  connected_order_arc_1665
 L  arc_capacity_1666
 G  connected_order_arc_1667
 L  arc_capacity_1668
 G  connected_order_arc_1669
 L  arc_capacity_1670
 G  connected_order_arc_1671
 L  arc_capacity_1672
 G  connected_order_arc_1673
 L  arc_capacity_1674
 L  arc_capacity_1675
 G  connected_order_arc_1676
 L  arc_capacity_1677
 G  connected_order_arc_1678
 L  arc_capacity_1679
 G  connected_order_arc_1680
 L  arc_capacity_1681
 G  connected_order_arc_1682
 L  arc_capacity_1683
 G  connected_order_arc_1684
 L  arc_capacity_1685
 G  connected_order_arc_1686
 L  arc_capacity_1687
 G  connected_order_arc_1688
 L  arc_capacity_1689
 G  connected_order_arc_1690
 L  arc_capacity_1691
 G  connected_order_arc_1692
 L  arc_capacity_1693
 G  connected_order_arc_1694
 L  arc_capacity_1695
 G  connected_order_arc_1696
 L  arc_capacity_1697
 G  connected_order_arc_1698
 E  depot_departure_or_bypass_1699
 E  depot_return_or_bypass_1700
 E  out_degree_1701
 E  in_degree_1702
 G  order_active_lb_1703
 L  order_active_ub_1704
 E  segment_load_conservation_1705
 G  segment_prefix_lb_1706
 L  segment_prefix_ub_1707
 E  out_degree_1708
 E  in_degree_1709
 G  order_active_lb_1710
 L  order_active_ub_1711
 E  segment_load_conservation_1712
 G  segment_prefix_lb_1713
 L  segment_prefix_ub_1714
 E  out_degree_1715
 E  in_degree_1716
 G  order_active_lb_1717
 L  order_active_ub_1718
 E  segment_load_conservation_1719
 G  segment_prefix_lb_1720
 L  segment_prefix_ub_1721
 E  out_degree_1722
 E  in_degree_1723
 G  order_active_lb_1724
 L  order_active_ub_1725
 E  segment_load_conservation_1726
 G  segment_prefix_lb_1727
 L  segment_prefix_ub_1728
 E  out_degree_1729
 E  in_degree_1730
 G  order_active_lb_1731
 L  order_active_ub_1732
 E  segment_load_conservation_1733
 G  segment_prefix_lb_1734
 L  segment_prefix_ub_1735
 E  out_degree_1736
 E  in_degree_1737
 G  order_active_lb_1738
 L  order_active_ub_1739
 E  service_visit_def_1740
 E  free_load_conservation_1741
 E  out_degree_1742
 E  in_degree_1743
 G  order_active_lb_1744
 L  order_active_ub_1745
 E  service_visit_def_1746
 E  free_load_conservation_1747
 E  out_degree_1748
 E  in_degree_1749
 G  order_active_lb_1750
 L  order_active_ub_1751
 E  service_visit_def_1752
 E  free_load_conservation_1753
 E  out_degree_1754
 E  in_degree_1755
 G  order_active_lb_1756
 L  order_active_ub_1757
 E  service_visit_def_1758
 E  free_load_conservation_1759
 E  out_degree_1760
 E  in_degree_1761
 G  order_active_lb_1762
 L  order_active_ub_1763
 E  service_visit_def_1764
 E  free_load_conservation_1765
 E  out_degree_1766
 E  in_degree_1767
 G  order_active_lb_1768
 L  order_active_ub_1769
 E  service_visit_def_1770
 E  free_load_conservation_1771
 E  out_degree_1772
 E  in_degree_1773
 G  order_active_lb_1774
 L  order_active_ub_1775
 E  service_visit_def_1776
 E  free_load_conservation_1777
 E  out_degree_1778
 E  in_degree_1779
 G  order_active_lb_1780
 L  order_active_ub_1781
 E  service_visit_def_1782
 E  free_load_conservation_1783
 G  fixed_segment_relative_order_1784
 G  fixed_segment_relative_order_1785
 G  fixed_segment_relative_order_1786
 G  fixed_segment_relative_order_1787
 L  original_T_including_depot_unload_1788
COLUMNS
    t         normalized_mass_18_37  -1
    t         normalized_mass_22_66  -1
    t         normalized_mass_31_95  -1
    t         normalized_mass_14_130  -1
    t         normalized_mass_16_159  -1
    t         normalized_mass_5_196  -1
    t         normalized_mass_32_225  -1
    t         normalized_mass_3_264  -1
    t         normalization_325  2.3834920634920639e+01
    t         full_original_Gini_326  -74.4809523809525
    q         OBJ       1
    q         parent_nonstrict_scope_268  1
    q         full_original_Gini_326  35
    MARKER    'MARKER'                 'INTORG'
    x_18_0    OBJ       0.06075
    x_18_0    product_lb_0  -2.5101601721227582e-02
    x_18_0    product_ub_1  -4.1955247735790492e-02
    x_18_0    onehot_18_36  1
    x_18_0    parent_nonstrict_scope_268  0.1215
    x_18_0    unique_nonzero_owner_327  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_0    product_lb_0  1
    w_18_0    product_ub_1  1
    w_18_0    normalized_mass_18_37  1
    w_18_0    full_original_Gini_326  -2.3834920634920639e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_1    OBJ       4.7249999999999986e-02
    x_18_1    product_lb_2  -2.5101601721227582e-02
    x_18_1    product_ub_3  -4.1955247735790492e-02
    x_18_1    onehot_18_36  1
    x_18_1    stock_lb_266  1
    x_18_1    stock_ub_267  1
    x_18_1    parent_nonstrict_scope_268  1.0799999999999998e-01
    x_18_1    unique_nonzero_owner_328  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_1    product_lb_2  1
    w_18_1    product_ub_3  1
    w_18_1    normalized_mass_18_37  1
    w_18_1    normalized_ratio_18_38  -1.1111111111111110e-01
    w_18_1    full_original_Gini_326  -2.0834920634920639e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_2    OBJ       0.03375
    x_18_2    product_lb_4  -2.5101601721227582e-02
    x_18_2    product_ub_5  -4.1955247735790492e-02
    x_18_2    onehot_18_36  1
    x_18_2    stock_lb_266  2
    x_18_2    stock_ub_267  2
    x_18_2    parent_nonstrict_scope_268  0.0945
    x_18_2    unique_nonzero_owner_329  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_2    product_lb_4  1
    w_18_2    product_ub_5  1
    w_18_2    normalized_mass_18_37  1
    w_18_2    normalized_ratio_18_38  -2.2222222222222221e-01
    w_18_2    full_original_Gini_326  -1.7834920634920639e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_3    OBJ       2.0250000000000004e-02
    x_18_3    product_lb_6  -2.5101601721227582e-02
    x_18_3    product_ub_7  -4.1955247735790492e-02
    x_18_3    onehot_18_36  1
    x_18_3    stock_lb_266  3
    x_18_3    stock_ub_267  3
    x_18_3    parent_nonstrict_scope_268  0.081
    x_18_3    unique_nonzero_owner_330  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_3    product_lb_6  1
    w_18_3    product_ub_7  1
    w_18_3    normalized_mass_18_37  1
    w_18_3    normalized_ratio_18_38  -3.3333333333333331e-01
    w_18_3    full_original_Gini_326  -1.4834920634920634e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_4    OBJ       6.7500000000000060e-03
    x_18_4    product_lb_8  -2.5101601721227582e-02
    x_18_4    product_ub_9  -4.1955247735790492e-02
    x_18_4    onehot_18_36  1
    x_18_4    stock_lb_266  4
    x_18_4    stock_ub_267  4
    x_18_4    parent_nonstrict_scope_268  0.0675
    x_18_4    unique_nonzero_owner_331  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_4    product_lb_8  1
    w_18_4    product_ub_9  1
    w_18_4    normalized_mass_18_37  1
    w_18_4    normalized_ratio_18_38  -4.4444444444444442e-01
    w_18_4    full_original_Gini_326  -1.1834920634920634e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_5    OBJ       -6.7500000000000060e-03
    x_18_5    product_lb_10  -2.5101601721227582e-02
    x_18_5    product_ub_11  -4.1955247735790492e-02
    x_18_5    onehot_18_36  1
    x_18_5    stock_lb_266  5
    x_18_5    stock_ub_267  5
    x_18_5    parent_nonstrict_scope_268  5.3999999999999992e-02
    x_18_5    unique_nonzero_owner_332  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_5    product_lb_10  1
    w_18_5    product_ub_11  1
    w_18_5    normalized_mass_18_37  1
    w_18_5    normalized_ratio_18_38  -5.5555555555555558e-01
    w_18_5    full_original_Gini_326  -9.0571428571428569e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_6    OBJ       -2.0249999999999997e-02
    x_18_6    product_lb_12  -2.5101601721227582e-02
    x_18_6    product_ub_13  -4.1955247735790492e-02
    x_18_6    onehot_18_36  1
    x_18_6    stock_lb_266  6
    x_18_6    stock_ub_267  6
    x_18_6    parent_nonstrict_scope_268  0.0405
    x_18_6    unique_nonzero_owner_333  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_6    product_lb_12  1
    w_18_6    product_ub_13  1
    w_18_6    normalized_mass_18_37  1
    w_18_6    normalized_ratio_18_38  -6.6666666666666663e-01
    w_18_6    full_original_Gini_326  -6.7682539682539673e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_7    OBJ       -3.3749999999999988e-02
    x_18_7    product_lb_14  -2.5101601721227582e-02
    x_18_7    product_ub_15  -4.1955247735790492e-02
    x_18_7    onehot_18_36  1
    x_18_7    stock_lb_266  7
    x_18_7    stock_ub_267  7
    x_18_7    parent_nonstrict_scope_268  2.7000000000000010e-02
    x_18_7    unique_nonzero_owner_334  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_7    product_lb_14  1
    w_18_7    product_ub_15  1
    w_18_7    normalized_mass_18_37  1
    w_18_7    normalized_ratio_18_38  -7.7777777777777768e-01
    w_18_7    full_original_Gini_326  -5.0936507936507942e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_8    OBJ       -4.7249999999999993e-02
    x_18_8    product_lb_16  -2.5101601721227582e-02
    x_18_8    product_ub_17  -4.1955247735790492e-02
    x_18_8    onehot_18_36  1
    x_18_8    stock_lb_266  8
    x_18_8    stock_ub_267  8
    x_18_8    parent_nonstrict_scope_268  1.3500000000000005e-02
    x_18_8    unique_nonzero_owner_335  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_8    product_lb_16  1
    w_18_8    product_ub_17  1
    w_18_8    normalized_mass_18_37  1
    w_18_8    normalized_ratio_18_38  -8.8888888888888884e-01
    w_18_8    full_original_Gini_326  -4.1761904761904756e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_9    OBJ       -0.06075
    x_18_9    product_lb_18  -2.5101601721227582e-02
    x_18_9    product_ub_19  -4.1955247735790492e-02
    x_18_9    onehot_18_36  1
    x_18_9    stock_lb_266  9
    x_18_9    stock_ub_267  9
    x_18_9    unique_nonzero_owner_336  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_9    product_lb_18  1
    w_18_9    product_ub_19  1
    w_18_9    normalized_mass_18_37  1
    w_18_9    normalized_ratio_18_38  -1
    w_18_9    full_original_Gini_326  -4.0650793650793648e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_10   OBJ       -4.7249999999999993e-02
    x_18_10   product_lb_20  -2.5101601721227582e-02
    x_18_10   product_ub_21  -4.1955247735790492e-02
    x_18_10   onehot_18_36  1
    x_18_10   stock_lb_266  10
    x_18_10   stock_ub_267  10
    x_18_10   parent_nonstrict_scope_268  1.3500000000000005e-02
    x_18_10   unique_nonzero_owner_337  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_10   product_lb_20  1
    w_18_10   product_ub_21  1
    w_18_10   normalized_mass_18_37  1
    w_18_10   normalized_ratio_18_38  -1.1111111111111112e+00
    w_18_10   full_original_Gini_326  -6.62063492063492
    MARKER    'MARKER'                 'INTORG'
    x_18_11   OBJ       -3.3750000000000016e-02
    x_18_11   product_lb_22  -2.5101601721227582e-02
    x_18_11   product_ub_23  -4.1955247735790492e-02
    x_18_11   onehot_18_36  1
    x_18_11   stock_lb_266  11
    x_18_11   stock_ub_267  11
    x_18_11   parent_nonstrict_scope_268  2.6999999999999986e-02
    x_18_11   unique_nonzero_owner_338  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_11   product_lb_22  1
    w_18_11   product_ub_23  1
    w_18_11   normalized_mass_18_37  1
    w_18_11   normalized_ratio_18_38  -1.2222222222222221e+00
    w_18_11   full_original_Gini_326  -9.2206349206349181e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_12   OBJ       -2.0250000000000011e-02
    x_18_12   product_lb_24  -2.5101601721227582e-02
    x_18_12   product_ub_25  -4.1955247735790492e-02
    x_18_12   onehot_18_36  1
    x_18_12   stock_lb_266  12
    x_18_12   stock_ub_267  12
    x_18_12   parent_nonstrict_scope_268  4.0499999999999987e-02
    MARKER    'MARKER'                 'INTEND'
    w_18_12   product_lb_24  1
    w_18_12   product_ub_25  1
    w_18_12   normalized_mass_18_37  1
    w_18_12   normalized_ratio_18_38  -1.3333333333333333e+00
    w_18_12   full_original_Gini_326  -1.2165079365079364e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_13   OBJ       -6.7500000000000060e-03
    x_18_13   product_lb_26  -2.5101601721227582e-02
    x_18_13   product_ub_27  -4.1955247735790492e-02
    x_18_13   onehot_18_36  1
    x_18_13   stock_lb_266  13
    x_18_13   stock_ub_267  13
    x_18_13   parent_nonstrict_scope_268  5.3999999999999992e-02
    x_18_13   unique_nonzero_owner_339  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_13   product_lb_26  1
    w_18_13   product_ub_27  1
    w_18_13   normalized_mass_18_37  1
    w_18_13   normalized_ratio_18_38  -1.4444444444444444e+00
    w_18_13   full_original_Gini_326  -1.5165079365079366e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_14   OBJ       6.7499999999999782e-03
    x_18_14   product_lb_28  -2.5101601721227582e-02
    x_18_14   product_ub_29  -4.1955247735790492e-02
    x_18_14   onehot_18_36  1
    x_18_14   stock_lb_266  14
    x_18_14   stock_ub_267  14
    x_18_14   parent_nonstrict_scope_268  6.7499999999999977e-02
    x_18_14   unique_nonzero_owner_340  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_14   product_lb_28  1
    w_18_14   product_ub_29  1
    w_18_14   normalized_mass_18_37  1
    w_18_14   normalized_ratio_18_38  -1.5555555555555554e+00
    w_18_14   full_original_Gini_326  -1.8165079365079357e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_15   OBJ       2.0249999999999976e-02
    x_18_15   product_lb_30  -2.5101601721227582e-02
    x_18_15   product_ub_31  -4.1955247735790492e-02
    x_18_15   onehot_18_36  1
    x_18_15   stock_lb_266  15
    x_18_15   stock_ub_267  15
    x_18_15   parent_nonstrict_scope_268  8.0999999999999975e-02
    x_18_15   unique_nonzero_owner_341  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_15   product_lb_30  1
    w_18_15   product_ub_31  1
    w_18_15   normalized_mass_18_37  1
    w_18_15   normalized_ratio_18_38  -1.6666666666666665e+00
    w_18_15   full_original_Gini_326  -2.1165079365079368e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_16   OBJ       3.3749999999999988e-02
    x_18_16   product_lb_32  -2.5101601721227582e-02
    x_18_16   product_ub_33  -4.1955247735790492e-02
    x_18_16   onehot_18_36  1
    x_18_16   stock_lb_266  16
    x_18_16   stock_ub_267  16
    x_18_16   parent_nonstrict_scope_268  9.4499999999999987e-02
    x_18_16   unique_nonzero_owner_342  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_16   product_lb_32  1
    w_18_16   product_ub_33  1
    w_18_16   normalized_mass_18_37  1
    w_18_16   normalized_ratio_18_38  -1.7777777777777777e+00
    w_18_16   full_original_Gini_326  -2.4165079365079372e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_17   OBJ       4.7249999999999986e-02
    x_18_17   product_lb_34  -2.5101601721227582e-02
    x_18_17   product_ub_35  -4.1955247735790492e-02
    x_18_17   onehot_18_36  1
    x_18_17   stock_lb_266  17
    x_18_17   stock_ub_267  17
    x_18_17   parent_nonstrict_scope_268  1.0799999999999998e-01
    x_18_17   unique_nonzero_owner_343  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_17   product_lb_34  1
    w_18_17   product_ub_35  1
    w_18_17   normalized_mass_18_37  1
    w_18_17   normalized_ratio_18_38  -1.8888888888888888e+00
    w_18_17   full_original_Gini_326  -2.7165079365079368e+01
    rho_18    normalized_ratio_18_38  1
    rho_18    block_pair_pos_287  -1
    rho_18    block_pair_neg_288  1
    rho_18    block_pair_pos_289  -1
    rho_18    block_pair_neg_290  1
    rho_18    block_pair_pos_291  -1
    rho_18    block_pair_neg_292  1
    rho_18    block_pair_pos_293  -1
    rho_18    block_pair_neg_294  1
    rho_18    block_pair_pos_295  -1
    rho_18    block_pair_neg_296  1
    rho_18    block_pair_pos_297  -1
    rho_18    block_pair_neg_298  1
    rho_18    block_pair_pos_299  -1
    rho_18    block_pair_neg_300  1
    rho_18    normalization_325  1
    MARKER    'MARKER'                 'INTORG'
    x_22_0    OBJ       0.027
    x_22_0    product_lb_39  -2.5101601721227582e-02
    x_22_0    product_ub_40  -4.1955247735790492e-02
    x_22_0    onehot_22_65  1
    x_22_0    parent_nonstrict_scope_268  0.054
    x_22_0    unique_nonzero_owner_344  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_0    product_lb_39  1
    w_22_0    product_ub_40  1
    w_22_0    normalized_mass_22_66  1
    w_22_0    full_original_Gini_326  -2.3834920634920639e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_1    OBJ       0.018
    x_22_1    product_lb_41  -2.5101601721227582e-02
    x_22_1    product_ub_42  -4.1955247735790492e-02
    x_22_1    onehot_22_65  1
    x_22_1    stock_lb_266  1
    x_22_1    stock_ub_267  1
    x_22_1    parent_nonstrict_scope_268  0.045
    x_22_1    unique_nonzero_owner_345  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_1    product_lb_41  1
    w_22_1    product_ub_42  1
    w_22_1    normalized_mass_22_66  1
    w_22_1    normalized_ratio_22_67  -1.6666666666666666e-01
    w_22_1    full_original_Gini_326  -1.9334920634920636e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_2    OBJ       9.0000000000000045e-03
    x_22_2    product_lb_43  -2.5101601721227582e-02
    x_22_2    product_ub_44  -4.1955247735790492e-02
    x_22_2    onehot_22_65  1
    x_22_2    stock_lb_266  2
    x_22_2    stock_ub_267  2
    x_22_2    parent_nonstrict_scope_268  3.6000000000000004e-02
    x_22_2    unique_nonzero_owner_346  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_2    product_lb_43  1
    w_22_2    product_ub_44  1
    w_22_2    normalized_mass_22_66  1
    w_22_2    normalized_ratio_22_67  -3.3333333333333331e-01
    w_22_2    full_original_Gini_326  -1.4834920634920634e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_3    product_lb_45  -2.5101601721227582e-02
    x_22_3    product_ub_46  -4.1955247735790492e-02
    x_22_3    onehot_22_65  1
    x_22_3    stock_lb_266  3
    x_22_3    stock_ub_267  3
    x_22_3    parent_nonstrict_scope_268  0.027
    x_22_3    unique_nonzero_owner_347  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_3    product_lb_45  1
    w_22_3    product_ub_46  1
    w_22_3    normalized_mass_22_66  1
    w_22_3    normalized_ratio_22_67  -0.5
    w_22_3    full_original_Gini_326  -1.0334920634920634e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_4    OBJ       -8.9999999999999976e-03
    x_22_4    product_lb_47  -2.5101601721227582e-02
    x_22_4    product_ub_48  -4.1955247735790492e-02
    x_22_4    onehot_22_65  1
    x_22_4    stock_lb_266  4
    x_22_4    stock_ub_267  4
    x_22_4    parent_nonstrict_scope_268  1.8000000000000002e-02
    x_22_4    unique_nonzero_owner_348  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_4    product_lb_47  1
    w_22_4    product_ub_48  1
    w_22_4    normalized_mass_22_66  1
    w_22_4    normalized_ratio_22_67  -6.6666666666666663e-01
    w_22_4    full_original_Gini_326  -6.7682539682539673e+00
    MARKER    'MARKER'                 'INTORG'
    x_22_5    OBJ       -1.7999999999999995e-02
    x_22_5    product_lb_49  -2.5101601721227582e-02
    x_22_5    product_ub_50  -4.1955247735790492e-02
    x_22_5    onehot_22_65  1
    x_22_5    stock_lb_266  5
    x_22_5    stock_ub_267  5
    x_22_5    parent_nonstrict_scope_268  9.0000000000000045e-03
    x_22_5    unique_nonzero_owner_349  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_5    product_lb_49  1
    w_22_5    product_ub_50  1
    w_22_5    normalized_mass_22_66  1
    w_22_5    normalized_ratio_22_67  -8.3333333333333326e-01
    w_22_5    full_original_Gini_326  -4.5492063492063526e+00
    MARKER    'MARKER'                 'INTORG'
    x_22_6    OBJ       -0.027
    x_22_6    product_lb_51  -2.5101601721227582e-02
    x_22_6    product_ub_52  -4.1955247735790492e-02
    x_22_6    onehot_22_65  1
    x_22_6    stock_lb_266  6
    x_22_6    stock_ub_267  6
    x_22_6    unique_nonzero_owner_350  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_6    product_lb_51  1
    w_22_6    product_ub_52  1
    w_22_6    normalized_mass_22_66  1
    w_22_6    normalized_ratio_22_67  -1
    w_22_6    full_original_Gini_326  -4.0650793650793648e+00
    MARKER    'MARKER'                 'INTORG'
    x_22_7    OBJ       -1.8000000000000009e-02
    x_22_7    product_lb_53  -2.5101601721227582e-02
    x_22_7    product_ub_54  -4.1955247735790492e-02
    x_22_7    onehot_22_65  1
    x_22_7    stock_lb_266  7
    x_22_7    stock_ub_267  7
    x_22_7    parent_nonstrict_scope_268  8.9999999999999924e-03
    x_22_7    unique_nonzero_owner_351  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_7    product_lb_53  1
    w_22_7    product_ub_54  1
    w_22_7    normalized_mass_22_66  1
    w_22_7    normalized_ratio_22_67  -1.1666666666666665e+00
    w_22_7    full_original_Gini_326  -7.8984126984126934e+00
    MARKER    'MARKER'                 'INTORG'
    x_22_8    OBJ       -9.0000000000000045e-03
    x_22_8    product_lb_55  -2.5101601721227582e-02
    x_22_8    product_ub_56  -4.1955247735790492e-02
    x_22_8    onehot_22_65  1
    x_22_8    stock_lb_266  8
    x_22_8    stock_ub_267  8
    x_22_8    parent_nonstrict_scope_268  1.7999999999999995e-02
    MARKER    'MARKER'                 'INTEND'
    w_22_8    product_lb_55  1
    w_22_8    product_ub_56  1
    w_22_8    normalized_mass_22_66  1
    w_22_8    normalized_ratio_22_67  -1.3333333333333333e+00
    w_22_8    full_original_Gini_326  -1.2165079365079364e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_9    product_lb_57  -2.5101601721227582e-02
    x_22_9    product_ub_58  -4.1955247735790492e-02
    x_22_9    onehot_22_65  1
    x_22_9    stock_lb_266  9
    x_22_9    stock_ub_267  9
    x_22_9    parent_nonstrict_scope_268  0.027
    x_22_9    unique_nonzero_owner_352  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_9    product_lb_57  1
    w_22_9    product_ub_58  1
    w_22_9    normalized_mass_22_66  1
    w_22_9    normalized_ratio_22_67  -1.5
    w_22_9    full_original_Gini_326  -1.6665079365079364e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_10   OBJ       0.00899999999999999
    x_22_10   product_lb_59  -2.5101601721227582e-02
    x_22_10   product_ub_60  -4.1955247735790492e-02
    x_22_10   onehot_22_65  1
    x_22_10   stock_lb_266  10
    x_22_10   stock_ub_267  10
    x_22_10   parent_nonstrict_scope_268  3.5999999999999990e-02
    x_22_10   unique_nonzero_owner_353  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_10   product_lb_59  1
    w_22_10   product_ub_60  1
    w_22_10   normalized_mass_22_66  1
    w_22_10   normalized_ratio_22_67  -1.6666666666666665e+00
    w_22_10   full_original_Gini_326  -2.1165079365079368e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_11   OBJ       0.018
    x_22_11   product_lb_61  -2.5101601721227582e-02
    x_22_11   product_ub_62  -4.1955247735790492e-02
    x_22_11   onehot_22_65  1
    x_22_11   stock_lb_266  11
    x_22_11   stock_ub_267  11
    x_22_11   parent_nonstrict_scope_268  0.045
    x_22_11   unique_nonzero_owner_354  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_11   product_lb_61  1
    w_22_11   product_ub_62  1
    w_22_11   normalized_mass_22_66  1
    w_22_11   normalized_ratio_22_67  -1.8333333333333333e+00
    w_22_11   full_original_Gini_326  -2.5665079365079361e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_12   OBJ       0.027
    x_22_12   product_lb_63  -2.5101601721227582e-02
    x_22_12   product_ub_64  -4.1955247735790492e-02
    x_22_12   onehot_22_65  1
    x_22_12   stock_lb_266  12
    x_22_12   stock_ub_267  12
    x_22_12   parent_nonstrict_scope_268  0.054
    x_22_12   unique_nonzero_owner_355  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_12   product_lb_63  1
    w_22_12   product_ub_64  1
    w_22_12   normalized_mass_22_66  1
    w_22_12   normalized_ratio_22_67  -2
    w_22_12   full_original_Gini_326  -3.0165079365079361e+01
    rho_22    normalized_ratio_22_67  1
    rho_22    block_pair_pos_295  1
    rho_22    block_pair_neg_296  -1
    rho_22    block_pair_pos_301  -1
    rho_22    block_pair_neg_302  1
    rho_22    block_pair_pos_303  -1
    rho_22    block_pair_neg_304  1
    rho_22    block_pair_pos_305  -1
    rho_22    block_pair_neg_306  1
    rho_22    block_pair_pos_307  -1
    rho_22    block_pair_neg_308  1
    rho_22    block_pair_pos_309  -1
    rho_22    block_pair_neg_310  1
    rho_22    block_pair_pos_311  -1
    rho_22    block_pair_neg_312  1
    rho_22    normalization_325  1
    MARKER    'MARKER'                 'INTORG'
    x_31_0    OBJ       0.03675
    x_31_0    product_lb_68  -2.5101601721227582e-02
    x_31_0    product_ub_69  -4.1955247735790492e-02
    x_31_0    onehot_31_94  1
    x_31_0    parent_nonstrict_scope_268  0.0735
    x_31_0    unique_nonzero_owner_356  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_0    product_lb_68  1
    w_31_0    product_ub_69  1
    w_31_0    normalized_mass_31_95  1
    w_31_0    full_original_Gini_326  -2.3834920634920639e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_1    OBJ       2.6250000000000002e-02
    x_31_1    product_lb_70  -2.5101601721227582e-02
    x_31_1    product_ub_71  -4.1955247735790492e-02
    x_31_1    onehot_31_94  1
    x_31_1    stock_lb_266  1
    x_31_1    stock_ub_267  1
    x_31_1    parent_nonstrict_scope_268  0.063
    x_31_1    unique_nonzero_owner_357  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_1    product_lb_70  1
    w_31_1    product_ub_71  1
    w_31_1    normalized_mass_31_95  1
    w_31_1    normalized_ratio_31_96  -1.4285714285714285e-01
    w_31_1    full_original_Gini_326  -1.9977777777777781e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_2    OBJ       0.01575
    x_31_2    product_lb_72  -2.5101601721227582e-02
    x_31_2    product_ub_73  -4.1955247735790492e-02
    x_31_2    onehot_31_94  1
    x_31_2    stock_lb_266  2
    x_31_2    stock_ub_267  2
    x_31_2    parent_nonstrict_scope_268  0.0525
    MARKER    'MARKER'                 'INTEND'
    w_31_2    product_lb_72  1
    w_31_2    product_ub_73  1
    w_31_2    normalized_mass_31_95  1
    w_31_2    normalized_ratio_31_96  -2.8571428571428570e-01
    w_31_2    full_original_Gini_326  -1.6120634920634917e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_3    OBJ       5.2499999999999977e-03
    x_31_3    product_lb_74  -2.5101601721227582e-02
    x_31_3    product_ub_75  -4.1955247735790492e-02
    x_31_3    onehot_31_94  1
    x_31_3    stock_lb_266  3
    x_31_3    stock_ub_267  3
    x_31_3    parent_nonstrict_scope_268  4.1999999999999996e-02
    x_31_3    unique_nonzero_owner_358  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_3    product_lb_74  1
    w_31_3    product_ub_75  1
    w_31_3    normalized_mass_31_95  1
    w_31_3    normalized_ratio_31_96  -4.2857142857142855e-01
    w_31_3    full_original_Gini_326  -1.2263492063492063e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_4    OBJ       -5.2499999999999977e-03
    x_31_4    product_lb_76  -2.5101601721227582e-02
    x_31_4    product_ub_77  -4.1955247735790492e-02
    x_31_4    onehot_31_94  1
    x_31_4    stock_lb_266  4
    x_31_4    stock_ub_267  4
    x_31_4    parent_nonstrict_scope_268  0.0315
    x_31_4    unique_nonzero_owner_359  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_4    product_lb_76  1
    w_31_4    product_ub_77  1
    w_31_4    normalized_mass_31_95  1
    w_31_4    normalized_ratio_31_96  -5.7142857142857140e-01
    w_31_4    full_original_Gini_326  -8.6920634920634932e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_5    OBJ       -1.5749999999999993e-02
    x_31_5    product_lb_78  -2.5101601721227582e-02
    x_31_5    product_ub_79  -4.1955247735790492e-02
    x_31_5    onehot_31_94  1
    x_31_5    stock_lb_266  5
    x_31_5    stock_ub_267  5
    x_31_5    parent_nonstrict_scope_268  2.1000000000000005e-02
    x_31_5    unique_nonzero_owner_360  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_5    product_lb_78  1
    w_31_5    product_ub_79  1
    w_31_5    normalized_mass_31_95  1
    w_31_5    normalized_ratio_31_96  -7.1428571428571419e-01
    w_31_5    full_original_Gini_326  -5.8634920634920631e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_6    OBJ       -2.6249999999999996e-02
    x_31_6    product_lb_80  -2.5101601721227582e-02
    x_31_6    product_ub_81  -4.1955247735790492e-02
    x_31_6    onehot_31_94  1
    x_31_6    stock_lb_266  6
    x_31_6    stock_ub_267  6
    x_31_6    parent_nonstrict_scope_268  1.0500000000000002e-02
    x_31_6    unique_nonzero_owner_361  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_6    product_lb_80  1
    w_31_6    product_ub_81  1
    w_31_6    normalized_mass_31_95  1
    w_31_6    normalized_ratio_31_96  -8.5714285714285710e-01
    w_31_6    full_original_Gini_326  -4.3349206349206346e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_7    OBJ       -0.03675
    x_31_7    product_lb_82  -2.5101601721227582e-02
    x_31_7    product_ub_83  -4.1955247735790492e-02
    x_31_7    onehot_31_94  1
    x_31_7    stock_lb_266  7
    x_31_7    stock_ub_267  7
    x_31_7    unique_nonzero_owner_362  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_7    product_lb_82  1
    w_31_7    product_ub_83  1
    w_31_7    normalized_mass_31_95  1
    w_31_7    normalized_ratio_31_96  -1
    w_31_7    full_original_Gini_326  -4.0650793650793648e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_8    OBJ       -2.6250000000000002e-02
    x_31_8    product_lb_84  -2.5101601721227582e-02
    x_31_8    product_ub_85  -4.1955247735790492e-02
    x_31_8    onehot_31_94  1
    x_31_8    stock_lb_266  8
    x_31_8    stock_ub_267  8
    x_31_8    parent_nonstrict_scope_268  1.0499999999999995e-02
    x_31_8    unique_nonzero_owner_363  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_8    product_lb_84  1
    w_31_8    product_ub_85  1
    w_31_8    normalized_mass_31_95  1
    w_31_8    normalized_ratio_31_96  -1.1428571428571428e+00
    w_31_8    full_original_Gini_326  -7.3507936507936478e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_9    OBJ       -1.5750000000000007e-02
    x_31_9    product_lb_86  -2.5101601721227582e-02
    x_31_9    product_ub_87  -4.1955247735790492e-02
    x_31_9    onehot_31_94  1
    x_31_9    stock_lb_266  9
    x_31_9    stock_ub_267  9
    x_31_9    parent_nonstrict_scope_268  2.0999999999999991e-02
    x_31_9    unique_nonzero_owner_364  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_9    product_lb_86  1
    w_31_9    product_ub_87  1
    w_31_9    normalized_mass_31_95  1
    w_31_9    normalized_ratio_31_96  -1.2857142857142856e+00
    w_31_9    full_original_Gini_326  -1.0879365079365073e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_10   OBJ       -5.2500000000000116e-03
    x_31_10   product_lb_88  -2.5101601721227582e-02
    x_31_10   product_ub_89  -4.1955247735790492e-02
    x_31_10   onehot_31_94  1
    x_31_10   stock_lb_266  10
    x_31_10   stock_ub_267  10
    x_31_10   parent_nonstrict_scope_268  3.1499999999999986e-02
    x_31_10   unique_nonzero_owner_365  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_10   product_lb_88  1
    w_31_10   product_ub_89  1
    w_31_10   normalized_mass_31_95  1
    w_31_10   normalized_ratio_31_96  -1.4285714285714284e+00
    w_31_10   full_original_Gini_326  -1.4736507936507936e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_11   OBJ       5.2499999999999977e-03
    x_31_11   product_lb_90  -2.5101601721227582e-02
    x_31_11   product_ub_91  -4.1955247735790492e-02
    x_31_11   onehot_31_94  1
    x_31_11   stock_lb_266  11
    x_31_11   stock_ub_267  11
    x_31_11   parent_nonstrict_scope_268  4.1999999999999996e-02
    x_31_11   unique_nonzero_owner_366  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_11   product_lb_90  1
    w_31_11   product_ub_91  1
    w_31_11   normalized_mass_31_95  1
    w_31_11   normalized_ratio_31_96  -1.5714285714285714e+00
    w_31_11   full_original_Gini_326  -1.8593650793650792e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_12   OBJ       1.5749999999999993e-02
    x_31_12   product_lb_92  -2.5101601721227582e-02
    x_31_12   product_ub_93  -4.1955247735790492e-02
    x_31_12   onehot_31_94  1
    x_31_12   stock_lb_266  12
    x_31_12   stock_ub_267  12
    x_31_12   parent_nonstrict_scope_268  5.2499999999999991e-02
    x_31_12   unique_nonzero_owner_367  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_12   product_lb_92  1
    w_31_12   product_ub_93  1
    w_31_12   normalized_mass_31_95  1
    w_31_12   normalized_ratio_31_96  -1.7142857142857142e+00
    w_31_12   full_original_Gini_326  -2.2450793650793653e+01
    rho_31    normalized_ratio_31_96  1
    rho_31    block_pair_pos_297  1
    rho_31    block_pair_neg_298  -1
    rho_31    block_pair_pos_309  1
    rho_31    block_pair_neg_310  -1
    rho_31    block_pair_pos_313  -1
    rho_31    block_pair_neg_314  1
    rho_31    block_pair_pos_315  -1
    rho_31    block_pair_neg_316  1
    rho_31    block_pair_pos_317  -1
    rho_31    block_pair_neg_318  1
    rho_31    block_pair_pos_319  -1
    rho_31    block_pair_neg_320  1
    rho_31    block_pair_pos_321  -1
    rho_31    block_pair_neg_322  1
    rho_31    normalization_325  1
    MARKER    'MARKER'                 'INTORG'
    x_14_0    OBJ       0.048
    x_14_0    product_lb_97  -2.5101601721227582e-02
    x_14_0    product_ub_98  -4.1955247735790492e-02
    x_14_0    onehot_14_129  1
    x_14_0    parent_nonstrict_scope_268  0.096
    x_14_0    unique_nonzero_owner_368  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_0    product_lb_97  1
    w_14_0    product_ub_98  1
    w_14_0    normalized_mass_14_130  1
    w_14_0    full_original_Gini_326  -2.3834920634920639e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_1    OBJ       3.6000000000000004e-02
    x_14_1    product_lb_99  -2.5101601721227582e-02
    x_14_1    product_ub_100  -4.1955247735790492e-02
    x_14_1    onehot_14_129  1
    x_14_1    stock_lb_266  1
    x_14_1    stock_ub_267  1
    x_14_1    parent_nonstrict_scope_268  0.084
    x_14_1    unique_nonzero_owner_369  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_1    product_lb_99  1
    w_14_1    product_ub_100  1
    w_14_1    normalized_mass_14_130  1
    w_14_1    normalized_ratio_14_131  -0.125
    w_14_1    full_original_Gini_326  -2.0459920634920636e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_2    OBJ       2.4000000000000007e-02
    x_14_2    product_lb_101  -2.5101601721227582e-02
    x_14_2    product_ub_102  -4.1955247735790492e-02
    x_14_2    onehot_14_129  1
    x_14_2    stock_lb_266  2
    x_14_2    stock_ub_267  2
    x_14_2    parent_nonstrict_scope_268  7.2000000000000008e-02
    MARKER    'MARKER'                 'INTEND'
    w_14_2    product_lb_101  1
    w_14_2    product_ub_102  1
    w_14_2    normalized_mass_14_130  1
    w_14_2    normalized_ratio_14_131  -0.25
    w_14_2    full_original_Gini_326  -1.7084920634920636e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_3    OBJ       1.1999999999999997e-02
    x_14_3    product_lb_103  -2.5101601721227582e-02
    x_14_3    product_ub_104  -4.1955247735790492e-02
    x_14_3    onehot_14_129  1
    x_14_3    stock_lb_266  3
    x_14_3    stock_ub_267  3
    x_14_3    parent_nonstrict_scope_268  0.06
    x_14_3    unique_nonzero_owner_370  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_3    product_lb_103  1
    w_14_3    product_ub_104  1
    w_14_3    normalized_mass_14_130  1
    w_14_3    normalized_ratio_14_131  -0.375
    w_14_3    full_original_Gini_326  -1.3709920634920634e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_4    product_lb_105  -2.5101601721227582e-02
    x_14_4    product_ub_106  -4.1955247735790492e-02
    x_14_4    onehot_14_129  1
    x_14_4    stock_lb_266  4
    x_14_4    stock_ub_267  4
    x_14_4    parent_nonstrict_scope_268  0.048
    x_14_4    unique_nonzero_owner_371  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_4    product_lb_105  1
    w_14_4    product_ub_106  1
    w_14_4    normalized_mass_14_130  1
    w_14_4    normalized_ratio_14_131  -0.5
    w_14_4    full_original_Gini_326  -1.0334920634920634e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_5    OBJ       -1.1999999999999997e-02
    x_14_5    product_lb_107  -2.5101601721227582e-02
    x_14_5    product_ub_108  -4.1955247735790492e-02
    x_14_5    onehot_14_129  1
    x_14_5    stock_lb_266  5
    x_14_5    stock_ub_267  5
    x_14_5    parent_nonstrict_scope_268  3.6000000000000004e-02
    x_14_5    unique_nonzero_owner_372  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_5    product_lb_107  1
    w_14_5    product_ub_108  1
    w_14_5    normalized_mass_14_130  1
    w_14_5    normalized_ratio_14_131  -0.625
    w_14_5    full_original_Gini_326  -7.5599206349206352e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_6    OBJ       -0.024
    x_14_6    product_lb_109  -2.5101601721227582e-02
    x_14_6    product_ub_110  -4.1955247735790492e-02
    x_14_6    onehot_14_129  1
    x_14_6    stock_lb_266  6
    x_14_6    stock_ub_267  6
    x_14_6    parent_nonstrict_scope_268  0.024
    x_14_6    unique_nonzero_owner_373  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_6    product_lb_109  1
    w_14_6    product_ub_110  1
    w_14_6    normalized_mass_14_130  1
    w_14_6    normalized_ratio_14_131  -0.75
    w_14_6    full_original_Gini_326  -5.3992063492063487e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_7    OBJ       -3.6000000000000004e-02
    x_14_7    product_lb_111  -2.5101601721227582e-02
    x_14_7    product_ub_112  -4.1955247735790492e-02
    x_14_7    onehot_14_129  1
    x_14_7    stock_lb_266  7
    x_14_7    stock_ub_267  7
    x_14_7    parent_nonstrict_scope_268  0.012
    x_14_7    unique_nonzero_owner_374  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_7    product_lb_111  1
    w_14_7    product_ub_112  1
    w_14_7    normalized_mass_14_130  1
    w_14_7    normalized_ratio_14_131  -0.875
    w_14_7    full_original_Gini_326  -4.24563492063492
    MARKER    'MARKER'                 'INTORG'
    x_14_8    OBJ       -0.048
    x_14_8    product_lb_113  -2.5101601721227582e-02
    x_14_8    product_ub_114  -4.1955247735790492e-02
    x_14_8    onehot_14_129  1
    x_14_8    stock_lb_266  8
    x_14_8    stock_ub_267  8
    x_14_8    unique_nonzero_owner_375  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_8    product_lb_113  1
    w_14_8    product_ub_114  1
    w_14_8    normalized_mass_14_130  1
    w_14_8    normalized_ratio_14_131  -1
    w_14_8    full_original_Gini_326  -4.0650793650793648e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_9    OBJ       -3.6000000000000004e-02
    x_14_9    product_lb_115  -2.5101601721227582e-02
    x_14_9    product_ub_116  -4.1955247735790492e-02
    x_14_9    onehot_14_129  1
    x_14_9    stock_lb_266  9
    x_14_9    stock_ub_267  9
    x_14_9    parent_nonstrict_scope_268  0.012
    x_14_9    unique_nonzero_owner_376  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_9    product_lb_115  1
    w_14_9    product_ub_116  1
    w_14_9    normalized_mass_14_130  1
    w_14_9    normalized_ratio_14_131  -1.125
    w_14_9    full_original_Gini_326  -6.9400793650793648e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_10   OBJ       -0.024
    x_14_10   product_lb_117  -2.5101601721227582e-02
    x_14_10   product_ub_118  -4.1955247735790492e-02
    x_14_10   onehot_14_129  1
    x_14_10   stock_lb_266  10
    x_14_10   stock_ub_267  10
    x_14_10   parent_nonstrict_scope_268  0.024
    x_14_10   unique_nonzero_owner_377  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_10   product_lb_117  1
    w_14_10   product_ub_118  1
    w_14_10   normalized_mass_14_130  1
    w_14_10   normalized_ratio_14_131  -1.25
    w_14_10   full_original_Gini_326  -9.9150793650793663e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_11   OBJ       -1.1999999999999997e-02
    x_14_11   product_lb_119  -2.5101601721227582e-02
    x_14_11   product_ub_120  -4.1955247735790492e-02
    x_14_11   onehot_14_129  1
    x_14_11   stock_lb_266  11
    x_14_11   stock_ub_267  11
    x_14_11   parent_nonstrict_scope_268  3.6000000000000004e-02
    x_14_11   unique_nonzero_owner_378  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_11   product_lb_119  1
    w_14_11   product_ub_120  1
    w_14_11   normalized_mass_14_130  1
    w_14_11   normalized_ratio_14_131  -1.375
    w_14_11   full_original_Gini_326  -1.3290079365079366e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_12   product_lb_121  -2.5101601721227582e-02
    x_14_12   product_ub_122  -4.1955247735790492e-02
    x_14_12   onehot_14_129  1
    x_14_12   stock_lb_266  12
    x_14_12   stock_ub_267  12
    x_14_12   parent_nonstrict_scope_268  0.048
    x_14_12   unique_nonzero_owner_379  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_12   product_lb_121  1
    w_14_12   product_ub_122  1
    w_14_12   normalized_mass_14_130  1
    w_14_12   normalized_ratio_14_131  -1.5
    w_14_12   full_original_Gini_326  -1.6665079365079364e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_13   OBJ       1.1999999999999997e-02
    x_14_13   product_lb_123  -2.5101601721227582e-02
    x_14_13   product_ub_124  -4.1955247735790492e-02
    x_14_13   onehot_14_129  1
    x_14_13   stock_lb_266  13
    x_14_13   stock_ub_267  13
    x_14_13   parent_nonstrict_scope_268  0.06
    x_14_13   unique_nonzero_owner_380  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_13   product_lb_123  1
    w_14_13   product_ub_124  1
    w_14_13   normalized_mass_14_130  1
    w_14_13   normalized_ratio_14_131  -1.625
    w_14_13   full_original_Gini_326  -2.0040079365079364e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_14   OBJ       2.4000000000000007e-02
    x_14_14   product_lb_125  -2.5101601721227582e-02
    x_14_14   product_ub_126  -4.1955247735790492e-02
    x_14_14   onehot_14_129  1
    x_14_14   stock_lb_266  14
    x_14_14   stock_ub_267  14
    x_14_14   parent_nonstrict_scope_268  7.2000000000000008e-02
    x_14_14   unique_nonzero_owner_381  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_14   product_lb_125  1
    w_14_14   product_ub_126  1
    w_14_14   normalized_mass_14_130  1
    w_14_14   normalized_ratio_14_131  -1.75
    w_14_14   full_original_Gini_326  -2.3415079365079361e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_15   OBJ       3.6000000000000004e-02
    x_14_15   product_lb_127  -2.5101601721227582e-02
    x_14_15   product_ub_128  -4.1955247735790492e-02
    x_14_15   onehot_14_129  1
    x_14_15   stock_lb_266  15
    x_14_15   stock_ub_267  15
    x_14_15   parent_nonstrict_scope_268  0.084
    x_14_15   unique_nonzero_owner_382  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_15   product_lb_127  1
    w_14_15   product_ub_128  1
    w_14_15   normalized_mass_14_130  1
    w_14_15   normalized_ratio_14_131  -1.875
    w_14_15   full_original_Gini_326  -2.6790079365079361e+01
    rho_14    normalized_ratio_14_131  1
    rho_14    block_pair_pos_273  -1
    rho_14    block_pair_neg_274  1
    rho_14    block_pair_pos_275  -1
    rho_14    block_pair_neg_276  1
    rho_14    block_pair_pos_277  -1
    rho_14    block_pair_neg_278  1
    rho_14    block_pair_pos_279  -1
    rho_14    block_pair_neg_280  1
    rho_14    block_pair_pos_291  1
    rho_14    block_pair_neg_292  -1
    rho_14    block_pair_pos_305  1
    rho_14    block_pair_neg_306  -1
    rho_14    block_pair_pos_317  1
    rho_14    block_pair_neg_318  -1
    rho_14    normalization_325  1
    MARKER    'MARKER'                 'INTORG'
    x_16_0    OBJ       0.027
    x_16_0    product_lb_132  -2.5101601721227582e-02
    x_16_0    product_ub_133  -4.1955247735790492e-02
    x_16_0    onehot_16_158  1
    x_16_0    parent_nonstrict_scope_268  0.054
    x_16_0    unique_nonzero_owner_383  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_0    product_lb_132  1
    w_16_0    product_ub_133  1
    w_16_0    normalized_mass_16_159  1
    w_16_0    full_original_Gini_326  -2.3834920634920639e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_1    OBJ       0.018
    x_16_1    product_lb_134  -2.5101601721227582e-02
    x_16_1    product_ub_135  -4.1955247735790492e-02
    x_16_1    onehot_16_158  1
    x_16_1    stock_lb_266  1
    x_16_1    stock_ub_267  1
    x_16_1    parent_nonstrict_scope_268  0.045
    MARKER    'MARKER'                 'INTEND'
    w_16_1    product_lb_134  1
    w_16_1    product_ub_135  1
    w_16_1    normalized_mass_16_159  1
    w_16_1    normalized_ratio_16_160  -1.6666666666666666e-01
    w_16_1    full_original_Gini_326  -1.9334920634920636e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_2    OBJ       9.0000000000000045e-03
    x_16_2    product_lb_136  -2.5101601721227582e-02
    x_16_2    product_ub_137  -4.1955247735790492e-02
    x_16_2    onehot_16_158  1
    x_16_2    stock_lb_266  2
    x_16_2    stock_ub_267  2
    x_16_2    parent_nonstrict_scope_268  3.6000000000000004e-02
    x_16_2    unique_nonzero_owner_384  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_2    product_lb_136  1
    w_16_2    product_ub_137  1
    w_16_2    normalized_mass_16_159  1
    w_16_2    normalized_ratio_16_160  -3.3333333333333331e-01
    w_16_2    full_original_Gini_326  -1.4834920634920634e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_3    product_lb_138  -2.5101601721227582e-02
    x_16_3    product_ub_139  -4.1955247735790492e-02
    x_16_3    onehot_16_158  1
    x_16_3    stock_lb_266  3
    x_16_3    stock_ub_267  3
    x_16_3    parent_nonstrict_scope_268  0.027
    x_16_3    unique_nonzero_owner_385  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_3    product_lb_138  1
    w_16_3    product_ub_139  1
    w_16_3    normalized_mass_16_159  1
    w_16_3    normalized_ratio_16_160  -0.5
    w_16_3    full_original_Gini_326  -1.0334920634920634e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_4    OBJ       -8.9999999999999976e-03
    x_16_4    product_lb_140  -2.5101601721227582e-02
    x_16_4    product_ub_141  -4.1955247735790492e-02
    x_16_4    onehot_16_158  1
    x_16_4    stock_lb_266  4
    x_16_4    stock_ub_267  4
    x_16_4    parent_nonstrict_scope_268  1.8000000000000002e-02
    x_16_4    unique_nonzero_owner_386  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_4    product_lb_140  1
    w_16_4    product_ub_141  1
    w_16_4    normalized_mass_16_159  1
    w_16_4    normalized_ratio_16_160  -6.6666666666666663e-01
    w_16_4    full_original_Gini_326  -6.7682539682539673e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_5    OBJ       -1.7999999999999995e-02
    x_16_5    product_lb_142  -2.5101601721227582e-02
    x_16_5    product_ub_143  -4.1955247735790492e-02
    x_16_5    onehot_16_158  1
    x_16_5    stock_lb_266  5
    x_16_5    stock_ub_267  5
    x_16_5    parent_nonstrict_scope_268  9.0000000000000045e-03
    x_16_5    unique_nonzero_owner_387  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_5    product_lb_142  1
    w_16_5    product_ub_143  1
    w_16_5    normalized_mass_16_159  1
    w_16_5    normalized_ratio_16_160  -8.3333333333333326e-01
    w_16_5    full_original_Gini_326  -4.5492063492063526e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_6    OBJ       -0.027
    x_16_6    product_lb_144  -2.5101601721227582e-02
    x_16_6    product_ub_145  -4.1955247735790492e-02
    x_16_6    onehot_16_158  1
    x_16_6    stock_lb_266  6
    x_16_6    stock_ub_267  6
    x_16_6    unique_nonzero_owner_388  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_6    product_lb_144  1
    w_16_6    product_ub_145  1
    w_16_6    normalized_mass_16_159  1
    w_16_6    normalized_ratio_16_160  -1
    w_16_6    full_original_Gini_326  -4.0650793650793648e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_7    OBJ       -1.8000000000000009e-02
    x_16_7    product_lb_146  -2.5101601721227582e-02
    x_16_7    product_ub_147  -4.1955247735790492e-02
    x_16_7    onehot_16_158  1
    x_16_7    stock_lb_266  7
    x_16_7    stock_ub_267  7
    x_16_7    parent_nonstrict_scope_268  8.9999999999999924e-03
    x_16_7    unique_nonzero_owner_389  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_7    product_lb_146  1
    w_16_7    product_ub_147  1
    w_16_7    normalized_mass_16_159  1
    w_16_7    normalized_ratio_16_160  -1.1666666666666665e+00
    w_16_7    full_original_Gini_326  -7.8984126984126934e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_8    OBJ       -9.0000000000000045e-03
    x_16_8    product_lb_148  -2.5101601721227582e-02
    x_16_8    product_ub_149  -4.1955247735790492e-02
    x_16_8    onehot_16_158  1
    x_16_8    stock_lb_266  8
    x_16_8    stock_ub_267  8
    x_16_8    parent_nonstrict_scope_268  1.7999999999999995e-02
    x_16_8    unique_nonzero_owner_390  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_8    product_lb_148  1
    w_16_8    product_ub_149  1
    w_16_8    normalized_mass_16_159  1
    w_16_8    normalized_ratio_16_160  -1.3333333333333333e+00
    w_16_8    full_original_Gini_326  -1.2165079365079364e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_9    product_lb_150  -2.5101601721227582e-02
    x_16_9    product_ub_151  -4.1955247735790492e-02
    x_16_9    onehot_16_158  1
    x_16_9    stock_lb_266  9
    x_16_9    stock_ub_267  9
    x_16_9    parent_nonstrict_scope_268  0.027
    x_16_9    unique_nonzero_owner_391  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_9    product_lb_150  1
    w_16_9    product_ub_151  1
    w_16_9    normalized_mass_16_159  1
    w_16_9    normalized_ratio_16_160  -1.5
    w_16_9    full_original_Gini_326  -1.6665079365079364e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_10   OBJ       0.00899999999999999
    x_16_10   product_lb_152  -2.5101601721227582e-02
    x_16_10   product_ub_153  -4.1955247735790492e-02
    x_16_10   onehot_16_158  1
    x_16_10   stock_lb_266  10
    x_16_10   stock_ub_267  10
    x_16_10   parent_nonstrict_scope_268  3.5999999999999990e-02
    x_16_10   unique_nonzero_owner_392  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_10   product_lb_152  1
    w_16_10   product_ub_153  1
    w_16_10   normalized_mass_16_159  1
    w_16_10   normalized_ratio_16_160  -1.6666666666666665e+00
    w_16_10   full_original_Gini_326  -2.1165079365079368e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_11   OBJ       0.018
    x_16_11   product_lb_154  -2.5101601721227582e-02
    x_16_11   product_ub_155  -4.1955247735790492e-02
    x_16_11   onehot_16_158  1
    x_16_11   stock_lb_266  11
    x_16_11   stock_ub_267  11
    x_16_11   parent_nonstrict_scope_268  0.045
    x_16_11   unique_nonzero_owner_393  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_11   product_lb_154  1
    w_16_11   product_ub_155  1
    w_16_11   normalized_mass_16_159  1
    w_16_11   normalized_ratio_16_160  -1.8333333333333333e+00
    w_16_11   full_original_Gini_326  -2.5665079365079361e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_12   OBJ       0.027
    x_16_12   product_lb_156  -2.5101601721227582e-02
    x_16_12   product_ub_157  -4.1955247735790492e-02
    x_16_12   onehot_16_158  1
    x_16_12   stock_lb_266  12
    x_16_12   stock_ub_267  12
    x_16_12   parent_nonstrict_scope_268  0.054
    x_16_12   unique_nonzero_owner_394  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_12   product_lb_156  1
    w_16_12   product_ub_157  1
    w_16_12   normalized_mass_16_159  1
    w_16_12   normalized_ratio_16_160  -2
    w_16_12   full_original_Gini_326  -3.0165079365079361e+01
    rho_16    normalized_ratio_16_160  1
    rho_16    block_pair_pos_277  1
    rho_16    block_pair_neg_278  -1
    rho_16    block_pair_pos_281  -1
    rho_16    block_pair_neg_282  1
    rho_16    block_pair_pos_283  -1
    rho_16    block_pair_neg_284  1
    rho_16    block_pair_pos_285  -1
    rho_16    block_pair_neg_286  1
    rho_16    block_pair_pos_293  1
    rho_16    block_pair_neg_294  -1
    rho_16    block_pair_pos_307  1
    rho_16    block_pair_neg_308  -1
    rho_16    block_pair_pos_319  1
    rho_16    block_pair_neg_320  -1
    rho_16    normalization_325  1
    MARKER    'MARKER'                 'INTORG'
    x_5_0     OBJ       0.048
    x_5_0     product_lb_161  -2.5101601721227582e-02
    x_5_0     product_ub_162  -4.1955247735790492e-02
    x_5_0     onehot_5_195  1
    x_5_0     parent_nonstrict_scope_268  0.096
    x_5_0     unique_nonzero_owner_395  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_0     product_lb_161  1
    w_5_0     product_ub_162  1
    w_5_0     normalized_mass_5_196  1
    w_5_0     full_original_Gini_326  -2.3834920634920639e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_1     OBJ       3.6000000000000004e-02
    x_5_1     product_lb_163  -2.5101601721227582e-02
    x_5_1     product_ub_164  -4.1955247735790492e-02
    x_5_1     onehot_5_195  1
    x_5_1     stock_lb_266  1
    x_5_1     stock_ub_267  1
    x_5_1     parent_nonstrict_scope_268  0.084
    x_5_1     unique_nonzero_owner_396  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_1     product_lb_163  1
    w_5_1     product_ub_164  1
    w_5_1     normalized_mass_5_196  1
    w_5_1     normalized_ratio_5_197  -0.125
    w_5_1     full_original_Gini_326  -2.0459920634920636e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_2     OBJ       2.4000000000000007e-02
    x_5_2     product_lb_165  -2.5101601721227582e-02
    x_5_2     product_ub_166  -4.1955247735790492e-02
    x_5_2     onehot_5_195  1
    x_5_2     stock_lb_266  2
    x_5_2     stock_ub_267  2
    x_5_2     parent_nonstrict_scope_268  7.2000000000000008e-02
    MARKER    'MARKER'                 'INTEND'
    w_5_2     product_lb_165  1
    w_5_2     product_ub_166  1
    w_5_2     normalized_mass_5_196  1
    w_5_2     normalized_ratio_5_197  -0.25
    w_5_2     full_original_Gini_326  -1.7084920634920636e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_3     OBJ       1.1999999999999997e-02
    x_5_3     product_lb_167  -2.5101601721227582e-02
    x_5_3     product_ub_168  -4.1955247735790492e-02
    x_5_3     onehot_5_195  1
    x_5_3     stock_lb_266  3
    x_5_3     stock_ub_267  3
    x_5_3     parent_nonstrict_scope_268  0.06
    x_5_3     unique_nonzero_owner_397  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_3     product_lb_167  1
    w_5_3     product_ub_168  1
    w_5_3     normalized_mass_5_196  1
    w_5_3     normalized_ratio_5_197  -0.375
    w_5_3     full_original_Gini_326  -1.3709920634920634e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_4     product_lb_169  -2.5101601721227582e-02
    x_5_4     product_ub_170  -4.1955247735790492e-02
    x_5_4     onehot_5_195  1
    x_5_4     stock_lb_266  4
    x_5_4     stock_ub_267  4
    x_5_4     parent_nonstrict_scope_268  0.048
    x_5_4     unique_nonzero_owner_398  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_4     product_lb_169  1
    w_5_4     product_ub_170  1
    w_5_4     normalized_mass_5_196  1
    w_5_4     normalized_ratio_5_197  -0.5
    w_5_4     full_original_Gini_326  -1.0334920634920634e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_5     OBJ       -1.1999999999999997e-02
    x_5_5     product_lb_171  -2.5101601721227582e-02
    x_5_5     product_ub_172  -4.1955247735790492e-02
    x_5_5     onehot_5_195  1
    x_5_5     stock_lb_266  5
    x_5_5     stock_ub_267  5
    x_5_5     parent_nonstrict_scope_268  3.6000000000000004e-02
    x_5_5     unique_nonzero_owner_399  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_5     product_lb_171  1
    w_5_5     product_ub_172  1
    w_5_5     normalized_mass_5_196  1
    w_5_5     normalized_ratio_5_197  -0.625
    w_5_5     full_original_Gini_326  -7.5599206349206352e+00
    MARKER    'MARKER'                 'INTORG'
    x_5_6     OBJ       -0.024
    x_5_6     product_lb_173  -2.5101601721227582e-02
    x_5_6     product_ub_174  -4.1955247735790492e-02
    x_5_6     onehot_5_195  1
    x_5_6     stock_lb_266  6
    x_5_6     stock_ub_267  6
    x_5_6     parent_nonstrict_scope_268  0.024
    x_5_6     unique_nonzero_owner_400  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_6     product_lb_173  1
    w_5_6     product_ub_174  1
    w_5_6     normalized_mass_5_196  1
    w_5_6     normalized_ratio_5_197  -0.75
    w_5_6     full_original_Gini_326  -5.3992063492063487e+00
    MARKER    'MARKER'                 'INTORG'
    x_5_7     OBJ       -3.6000000000000004e-02
    x_5_7     product_lb_175  -2.5101601721227582e-02
    x_5_7     product_ub_176  -4.1955247735790492e-02
    x_5_7     onehot_5_195  1
    x_5_7     stock_lb_266  7
    x_5_7     stock_ub_267  7
    x_5_7     parent_nonstrict_scope_268  0.012
    x_5_7     unique_nonzero_owner_401  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_7     product_lb_175  1
    w_5_7     product_ub_176  1
    w_5_7     normalized_mass_5_196  1
    w_5_7     normalized_ratio_5_197  -0.875
    w_5_7     full_original_Gini_326  -4.24563492063492
    MARKER    'MARKER'                 'INTORG'
    x_5_8     OBJ       -0.048
    x_5_8     product_lb_177  -2.5101601721227582e-02
    x_5_8     product_ub_178  -4.1955247735790492e-02
    x_5_8     onehot_5_195  1
    x_5_8     stock_lb_266  8
    x_5_8     stock_ub_267  8
    x_5_8     unique_nonzero_owner_402  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_8     product_lb_177  1
    w_5_8     product_ub_178  1
    w_5_8     normalized_mass_5_196  1
    w_5_8     normalized_ratio_5_197  -1
    w_5_8     full_original_Gini_326  -4.0650793650793648e+00
    MARKER    'MARKER'                 'INTORG'
    x_5_9     OBJ       -3.6000000000000004e-02
    x_5_9     product_lb_179  -2.5101601721227582e-02
    x_5_9     product_ub_180  -4.1955247735790492e-02
    x_5_9     onehot_5_195  1
    x_5_9     stock_lb_266  9
    x_5_9     stock_ub_267  9
    x_5_9     parent_nonstrict_scope_268  0.012
    x_5_9     unique_nonzero_owner_403  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_9     product_lb_179  1
    w_5_9     product_ub_180  1
    w_5_9     normalized_mass_5_196  1
    w_5_9     normalized_ratio_5_197  -1.125
    w_5_9     full_original_Gini_326  -6.9400793650793648e+00
    MARKER    'MARKER'                 'INTORG'
    x_5_10    OBJ       -0.024
    x_5_10    product_lb_181  -2.5101601721227582e-02
    x_5_10    product_ub_182  -4.1955247735790492e-02
    x_5_10    onehot_5_195  1
    x_5_10    stock_lb_266  10
    x_5_10    stock_ub_267  10
    x_5_10    parent_nonstrict_scope_268  0.024
    x_5_10    unique_nonzero_owner_404  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_10    product_lb_181  1
    w_5_10    product_ub_182  1
    w_5_10    normalized_mass_5_196  1
    w_5_10    normalized_ratio_5_197  -1.25
    w_5_10    full_original_Gini_326  -9.9150793650793663e+00
    MARKER    'MARKER'                 'INTORG'
    x_5_11    OBJ       -1.1999999999999997e-02
    x_5_11    product_lb_183  -2.5101601721227582e-02
    x_5_11    product_ub_184  -4.1955247735790492e-02
    x_5_11    onehot_5_195  1
    x_5_11    stock_lb_266  11
    x_5_11    stock_ub_267  11
    x_5_11    parent_nonstrict_scope_268  3.6000000000000004e-02
    x_5_11    unique_nonzero_owner_405  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_11    product_lb_183  1
    w_5_11    product_ub_184  1
    w_5_11    normalized_mass_5_196  1
    w_5_11    normalized_ratio_5_197  -1.375
    w_5_11    full_original_Gini_326  -1.3290079365079366e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_12    product_lb_185  -2.5101601721227582e-02
    x_5_12    product_ub_186  -4.1955247735790492e-02
    x_5_12    onehot_5_195  1
    x_5_12    stock_lb_266  12
    x_5_12    stock_ub_267  12
    x_5_12    parent_nonstrict_scope_268  0.048
    x_5_12    unique_nonzero_owner_406  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_12    product_lb_185  1
    w_5_12    product_ub_186  1
    w_5_12    normalized_mass_5_196  1
    w_5_12    normalized_ratio_5_197  -1.5
    w_5_12    full_original_Gini_326  -1.6665079365079364e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_13    OBJ       1.1999999999999997e-02
    x_5_13    product_lb_187  -2.5101601721227582e-02
    x_5_13    product_ub_188  -4.1955247735790492e-02
    x_5_13    onehot_5_195  1
    x_5_13    stock_lb_266  13
    x_5_13    stock_ub_267  13
    x_5_13    parent_nonstrict_scope_268  0.06
    x_5_13    unique_nonzero_owner_407  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_13    product_lb_187  1
    w_5_13    product_ub_188  1
    w_5_13    normalized_mass_5_196  1
    w_5_13    normalized_ratio_5_197  -1.625
    w_5_13    full_original_Gini_326  -2.0040079365079364e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_14    OBJ       2.4000000000000007e-02
    x_5_14    product_lb_189  -2.5101601721227582e-02
    x_5_14    product_ub_190  -4.1955247735790492e-02
    x_5_14    onehot_5_195  1
    x_5_14    stock_lb_266  14
    x_5_14    stock_ub_267  14
    x_5_14    parent_nonstrict_scope_268  7.2000000000000008e-02
    x_5_14    unique_nonzero_owner_408  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_14    product_lb_189  1
    w_5_14    product_ub_190  1
    w_5_14    normalized_mass_5_196  1
    w_5_14    normalized_ratio_5_197  -1.75
    w_5_14    full_original_Gini_326  -2.3415079365079361e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_15    OBJ       3.6000000000000004e-02
    x_5_15    product_lb_191  -2.5101601721227582e-02
    x_5_15    product_ub_192  -4.1955247735790492e-02
    x_5_15    onehot_5_195  1
    x_5_15    stock_lb_266  15
    x_5_15    stock_ub_267  15
    x_5_15    parent_nonstrict_scope_268  0.084
    x_5_15    unique_nonzero_owner_409  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_15    product_lb_191  1
    w_5_15    product_ub_192  1
    w_5_15    normalized_mass_5_196  1
    w_5_15    normalized_ratio_5_197  -1.875
    w_5_15    full_original_Gini_326  -2.6790079365079361e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_16    OBJ       0.048
    x_5_16    product_lb_193  -2.5101601721227582e-02
    x_5_16    product_ub_194  -4.1955247735790492e-02
    x_5_16    onehot_5_195  1
    x_5_16    stock_lb_266  16
    x_5_16    stock_ub_267  16
    x_5_16    parent_nonstrict_scope_268  0.096
    x_5_16    unique_nonzero_owner_410  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_16    product_lb_193  1
    w_5_16    product_ub_194  1
    w_5_16    normalized_mass_5_196  1
    w_5_16    normalized_ratio_5_197  -2
    w_5_16    full_original_Gini_326  -3.0165079365079361e+01
    rho_5     normalized_ratio_5_197  1
    rho_5     block_pair_pos_269  -1
    rho_5     block_pair_neg_270  1
    rho_5     block_pair_pos_271  -1
    rho_5     block_pair_neg_272  1
    rho_5     block_pair_pos_275  1
    rho_5     block_pair_neg_276  -1
    rho_5     block_pair_pos_283  1
    rho_5     block_pair_neg_284  -1
    rho_5     block_pair_pos_289  1
    rho_5     block_pair_neg_290  -1
    rho_5     block_pair_pos_303  1
    rho_5     block_pair_neg_304  -1
    rho_5     block_pair_pos_315  1
    rho_5     block_pair_neg_316  -1
    rho_5     normalization_325  1
    MARKER    'MARKER'                 'INTORG'
    x_32_0    OBJ       1.1249999999999993e-02
    x_32_0    product_lb_198  -2.5101601721227582e-02
    x_32_0    product_ub_199  -4.1955247735790492e-02
    x_32_0    onehot_32_224  1
    x_32_0    parent_nonstrict_scope_268  0.0375
    MARKER    'MARKER'                 'INTEND'
    w_32_0    product_lb_198  1
    w_32_0    product_ub_199  1
    w_32_0    normalized_mass_32_225  1
    w_32_0    full_original_Gini_326  -2.3834920634920639e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_1    OBJ       3.7499999999999929e-03
    x_32_1    product_lb_200  -2.5101601721227582e-02
    x_32_1    product_ub_201  -4.1955247735790492e-02
    x_32_1    onehot_32_224  1
    x_32_1    stock_lb_266  1
    x_32_1    stock_ub_267  1
    x_32_1    parent_nonstrict_scope_268  0.03
    x_32_1    unique_nonzero_owner_411  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_1    product_lb_200  1
    w_32_1    product_ub_201  1
    w_32_1    normalized_mass_32_225  1
    w_32_1    normalized_ratio_32_226  -0.2
    w_32_1    full_original_Gini_326  -1.8434920634920640e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_2    OBJ       -3.7500000000000068e-03
    x_32_2    product_lb_202  -2.5101601721227582e-02
    x_32_2    product_ub_203  -4.1955247735790492e-02
    x_32_2    onehot_32_224  1
    x_32_2    stock_lb_266  2
    x_32_2    stock_ub_267  2
    x_32_2    parent_nonstrict_scope_268  0.0225
    x_32_2    unique_nonzero_owner_412  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_2    product_lb_202  1
    w_32_2    product_ub_203  1
    w_32_2    normalized_mass_32_225  1
    w_32_2    normalized_ratio_32_226  -0.4
    w_32_2    full_original_Gini_326  -1.3034920634920631e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_3    OBJ       -1.1250000000000010e-02
    x_32_3    product_lb_204  -2.5101601721227582e-02
    x_32_3    product_ub_205  -4.1955247735790492e-02
    x_32_3    onehot_32_224  1
    x_32_3    stock_lb_266  3
    x_32_3    stock_ub_267  3
    x_32_3    parent_nonstrict_scope_268  1.4999999999999996e-02
    x_32_3    unique_nonzero_owner_413  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_3    product_lb_204  1
    w_32_3    product_ub_205  1
    w_32_3    normalized_mass_32_225  1
    w_32_3    normalized_ratio_32_226  -6.0000000000000009e-01
    w_32_3    full_original_Gini_326  -8.0349206349206348e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_4    OBJ       -1.8750000000000010e-02
    x_32_4    product_lb_206  -2.5101601721227582e-02
    x_32_4    product_ub_207  -4.1955247735790492e-02
    x_32_4    onehot_32_224  1
    x_32_4    stock_lb_266  4
    x_32_4    stock_ub_267  4
    x_32_4    parent_nonstrict_scope_268  7.4999999999999980e-03
    x_32_4    unique_nonzero_owner_414  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_4    product_lb_206  1
    w_32_4    product_ub_207  1
    w_32_4    normalized_mass_32_225  1
    w_32_4    normalized_ratio_32_226  -0.8
    w_32_4    full_original_Gini_326  -4.8492063492063515e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_5    OBJ       -2.6250000000000006e-02
    x_32_5    product_lb_208  -2.5101601721227582e-02
    x_32_5    product_ub_209  -4.1955247735790492e-02
    x_32_5    onehot_32_224  1
    x_32_5    stock_lb_266  5
    x_32_5    stock_ub_267  5
    x_32_5    unique_nonzero_owner_415  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_5    product_lb_208  1
    w_32_5    product_ub_209  1
    w_32_5    normalized_mass_32_225  1
    w_32_5    normalized_ratio_32_226  -1
    w_32_5    full_original_Gini_326  -4.0650793650793648e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_6    OBJ       -0.01875
    x_32_6    product_lb_210  -2.5101601721227582e-02
    x_32_6    product_ub_211  -4.1955247735790492e-02
    x_32_6    onehot_32_224  1
    x_32_6    stock_lb_266  6
    x_32_6    stock_ub_267  6
    x_32_6    parent_nonstrict_scope_268  7.5000000000000067e-03
    x_32_6    unique_nonzero_owner_416  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_6    product_lb_210  1
    w_32_6    product_ub_211  1
    w_32_6    normalized_mass_32_225  1
    w_32_6    normalized_ratio_32_226  -1.2000000000000002e+00
    w_32_6    full_original_Gini_326  -8.6650793650793680e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_7    OBJ       -1.1250000000000001e-02
    x_32_7    product_lb_212  -2.5101601721227582e-02
    x_32_7    product_ub_213  -4.1955247735790492e-02
    x_32_7    onehot_32_224  1
    x_32_7    stock_lb_266  7
    x_32_7    stock_ub_267  7
    x_32_7    parent_nonstrict_scope_268  1.5000000000000005e-02
    x_32_7    unique_nonzero_owner_417  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_7    product_lb_212  1
    w_32_7    product_ub_213  1
    w_32_7    normalized_mass_32_225  1
    w_32_7    normalized_ratio_32_226  -1.4000000000000001e+00
    w_32_7    full_original_Gini_326  -1.3965079365079371e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_8    OBJ       -3.7500000000000033e-03
    x_32_8    product_lb_214  -2.5101601721227582e-02
    x_32_8    product_ub_215  -4.1955247735790492e-02
    x_32_8    onehot_32_224  1
    x_32_8    stock_lb_266  8
    x_32_8    stock_ub_267  8
    x_32_8    parent_nonstrict_scope_268  2.2500000000000003e-02
    x_32_8    unique_nonzero_owner_418  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_8    product_lb_214  1
    w_32_8    product_ub_215  1
    w_32_8    normalized_mass_32_225  1
    w_32_8    normalized_ratio_32_226  -1.6
    w_32_8    full_original_Gini_326  -1.9365079365079371e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_9    OBJ       3.7499999999999929e-03
    x_32_9    product_lb_216  -2.5101601721227582e-02
    x_32_9    product_ub_217  -4.1955247735790492e-02
    x_32_9    onehot_32_224  1
    x_32_9    stock_lb_266  9
    x_32_9    stock_ub_267  9
    x_32_9    parent_nonstrict_scope_268  0.03
    x_32_9    unique_nonzero_owner_419  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_9    product_lb_216  1
    w_32_9    product_ub_217  1
    w_32_9    normalized_mass_32_225  1
    w_32_9    normalized_ratio_32_226  -1.8
    w_32_9    full_original_Gini_326  -2.4765079365079369e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_10   OBJ       1.1249999999999993e-02
    x_32_10   product_lb_218  -2.5101601721227582e-02
    x_32_10   product_ub_219  -4.1955247735790492e-02
    x_32_10   onehot_32_224  1
    x_32_10   stock_lb_266  10
    x_32_10   stock_ub_267  10
    x_32_10   parent_nonstrict_scope_268  0.0375
    x_32_10   unique_nonzero_owner_420  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_10   product_lb_218  1
    w_32_10   product_ub_219  1
    w_32_10   normalized_mass_32_225  1
    w_32_10   normalized_ratio_32_226  -2
    w_32_10   full_original_Gini_326  -3.0165079365079361e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_11   OBJ       0.01875
    x_32_11   product_lb_220  -2.5101601721227582e-02
    x_32_11   product_ub_221  -4.1955247735790492e-02
    x_32_11   onehot_32_224  1
    x_32_11   stock_lb_266  11
    x_32_11   stock_ub_267  11
    x_32_11   parent_nonstrict_scope_268  4.5000000000000005e-02
    x_32_11   unique_nonzero_owner_421  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_11   product_lb_220  1
    w_32_11   product_ub_221  1
    w_32_11   normalized_mass_32_225  1
    w_32_11   normalized_ratio_32_226  -2.2
    w_32_11   full_original_Gini_326  -3.5565079365079363e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_12   OBJ       2.6250000000000006e-02
    x_32_12   product_lb_222  -2.5101601721227582e-02
    x_32_12   product_ub_223  -4.1955247735790492e-02
    x_32_12   onehot_32_224  1
    x_32_12   stock_lb_266  12
    x_32_12   stock_ub_267  12
    x_32_12   parent_nonstrict_scope_268  5.2500000000000012e-02
    x_32_12   unique_nonzero_owner_422  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_12   product_lb_222  1
    w_32_12   product_ub_223  1
    w_32_12   normalized_mass_32_225  1
    w_32_12   normalized_ratio_32_226  -2.4000000000000004e+00
    w_32_12   full_original_Gini_326  -4.0965079365079362e+01
    rho_32    normalized_ratio_32_226  1
    rho_32    block_pair_pos_271  1
    rho_32    block_pair_neg_272  -1
    rho_32    block_pair_pos_279  1
    rho_32    block_pair_neg_280  -1
    rho_32    block_pair_pos_285  1
    rho_32    block_pair_neg_286  -1
    rho_32    block_pair_pos_299  1
    rho_32    block_pair_neg_300  -1
    rho_32    block_pair_pos_311  1
    rho_32    block_pair_neg_312  -1
    rho_32    block_pair_pos_321  1
    rho_32    block_pair_neg_322  -1
    rho_32    block_pair_pos_323  -1
    rho_32    block_pair_neg_324  1
    rho_32    normalization_325  1
    MARKER    'MARKER'                 'INTORG'
    x_3_0     OBJ       0.042
    x_3_0     product_lb_227  -2.5101601721227582e-02
    x_3_0     product_ub_228  -4.1955247735790492e-02
    x_3_0     onehot_3_263  1
    x_3_0     parent_nonstrict_scope_268  0.096
    x_3_0     unique_nonzero_owner_423  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_0     product_lb_227  1
    w_3_0     product_ub_228  1
    w_3_0     normalized_mass_3_264  1
    w_3_0     full_original_Gini_326  -2.3834920634920639e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_1     OBJ       3.0000000000000006e-02
    x_3_1     product_lb_229  -2.5101601721227582e-02
    x_3_1     product_ub_230  -4.1955247735790492e-02
    x_3_1     onehot_3_263  1
    x_3_1     stock_lb_266  1
    x_3_1     stock_ub_267  1
    x_3_1     parent_nonstrict_scope_268  0.084
    x_3_1     unique_nonzero_owner_424  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_1     product_lb_229  1
    w_3_1     product_ub_230  1
    w_3_1     normalized_mass_3_264  1
    w_3_1     normalized_ratio_3_265  -0.125
    w_3_1     full_original_Gini_326  -2.0459920634920636e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_2     OBJ       1.8000000000000009e-02
    x_3_2     product_lb_231  -2.5101601721227582e-02
    x_3_2     product_ub_232  -4.1955247735790492e-02
    x_3_2     onehot_3_263  1
    x_3_2     stock_lb_266  2
    x_3_2     stock_ub_267  2
    x_3_2     parent_nonstrict_scope_268  7.2000000000000008e-02
    x_3_2     unique_nonzero_owner_425  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_2     product_lb_231  1
    w_3_2     product_ub_232  1
    w_3_2     normalized_mass_3_264  1
    w_3_2     normalized_ratio_3_265  -0.25
    w_3_2     full_original_Gini_326  -1.7084920634920636e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_3     OBJ       5.9999999999999984e-03
    x_3_3     product_lb_233  -2.5101601721227582e-02
    x_3_3     product_ub_234  -4.1955247735790492e-02
    x_3_3     onehot_3_263  1
    x_3_3     stock_lb_266  3
    x_3_3     stock_ub_267  3
    x_3_3     parent_nonstrict_scope_268  0.06
    x_3_3     unique_nonzero_owner_426  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_3     product_lb_233  1
    w_3_3     product_ub_234  1
    w_3_3     normalized_mass_3_264  1
    w_3_3     normalized_ratio_3_265  -0.375
    w_3_3     full_original_Gini_326  -1.3709920634920634e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_4     OBJ       -5.9999999999999984e-03
    x_3_4     product_lb_235  -2.5101601721227582e-02
    x_3_4     product_ub_236  -4.1955247735790492e-02
    x_3_4     onehot_3_263  1
    x_3_4     stock_lb_266  4
    x_3_4     stock_ub_267  4
    x_3_4     parent_nonstrict_scope_268  0.048
    x_3_4     unique_nonzero_owner_427  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_4     product_lb_235  1
    w_3_4     product_ub_236  1
    w_3_4     normalized_mass_3_264  1
    w_3_4     normalized_ratio_3_265  -0.5
    w_3_4     full_original_Gini_326  -1.0334920634920634e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_5     OBJ       -1.7999999999999995e-02
    x_3_5     product_lb_237  -2.5101601721227582e-02
    x_3_5     product_ub_238  -4.1955247735790492e-02
    x_3_5     onehot_3_263  1
    x_3_5     stock_lb_266  5
    x_3_5     stock_ub_267  5
    x_3_5     parent_nonstrict_scope_268  3.6000000000000004e-02
    x_3_5     unique_nonzero_owner_428  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_5     product_lb_237  1
    w_3_5     product_ub_238  1
    w_3_5     normalized_mass_3_264  1
    w_3_5     normalized_ratio_3_265  -0.625
    w_3_5     full_original_Gini_326  -7.5599206349206352e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_6     OBJ       -0.03
    x_3_6     product_lb_239  -2.5101601721227582e-02
    x_3_6     product_ub_240  -4.1955247735790492e-02
    x_3_6     onehot_3_263  1
    x_3_6     stock_lb_266  6
    x_3_6     stock_ub_267  6
    x_3_6     parent_nonstrict_scope_268  0.024
    x_3_6     unique_nonzero_owner_429  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_6     product_lb_239  1
    w_3_6     product_ub_240  1
    w_3_6     normalized_mass_3_264  1
    w_3_6     normalized_ratio_3_265  -0.75
    w_3_6     full_original_Gini_326  -5.3992063492063487e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_7     OBJ       -4.1999999999999996e-02
    x_3_7     product_lb_241  -2.5101601721227582e-02
    x_3_7     product_ub_242  -4.1955247735790492e-02
    x_3_7     onehot_3_263  1
    x_3_7     stock_lb_266  7
    x_3_7     stock_ub_267  7
    x_3_7     parent_nonstrict_scope_268  0.012
    x_3_7     unique_nonzero_owner_430  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_7     product_lb_241  1
    w_3_7     product_ub_242  1
    w_3_7     normalized_mass_3_264  1
    w_3_7     normalized_ratio_3_265  -0.875
    w_3_7     full_original_Gini_326  -4.24563492063492
    MARKER    'MARKER'                 'INTORG'
    x_3_8     OBJ       -0.054
    x_3_8     product_lb_243  -2.5101601721227582e-02
    x_3_8     product_ub_244  -4.1955247735790492e-02
    x_3_8     onehot_3_263  1
    x_3_8     stock_lb_266  8
    x_3_8     stock_ub_267  8
    x_3_8     unique_nonzero_owner_431  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_8     product_lb_243  1
    w_3_8     product_ub_244  1
    w_3_8     normalized_mass_3_264  1
    w_3_8     normalized_ratio_3_265  -1
    w_3_8     full_original_Gini_326  -4.0650793650793648e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_9     OBJ       -4.1999999999999996e-02
    x_3_9     product_lb_245  -2.5101601721227582e-02
    x_3_9     product_ub_246  -4.1955247735790492e-02
    x_3_9     onehot_3_263  1
    x_3_9     stock_lb_266  9
    x_3_9     stock_ub_267  9
    x_3_9     parent_nonstrict_scope_268  0.012
    x_3_9     unique_nonzero_owner_432  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_9     product_lb_245  1
    w_3_9     product_ub_246  1
    w_3_9     normalized_mass_3_264  1
    w_3_9     normalized_ratio_3_265  -1.125
    w_3_9     full_original_Gini_326  -6.9400793650793648e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_10    OBJ       -0.03
    x_3_10    product_lb_247  -2.5101601721227582e-02
    x_3_10    product_ub_248  -4.1955247735790492e-02
    x_3_10    onehot_3_263  1
    x_3_10    stock_lb_266  10
    x_3_10    stock_ub_267  10
    x_3_10    parent_nonstrict_scope_268  0.024
    x_3_10    unique_nonzero_owner_433  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_10    product_lb_247  1
    w_3_10    product_ub_248  1
    w_3_10    normalized_mass_3_264  1
    w_3_10    normalized_ratio_3_265  -1.25
    w_3_10    full_original_Gini_326  -9.9150793650793663e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_11    OBJ       -1.7999999999999995e-02
    x_3_11    product_lb_249  -2.5101601721227582e-02
    x_3_11    product_ub_250  -4.1955247735790492e-02
    x_3_11    onehot_3_263  1
    x_3_11    stock_lb_266  11
    x_3_11    stock_ub_267  11
    x_3_11    parent_nonstrict_scope_268  3.6000000000000004e-02
    x_3_11    unique_nonzero_owner_434  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_11    product_lb_249  1
    w_3_11    product_ub_250  1
    w_3_11    normalized_mass_3_264  1
    w_3_11    normalized_ratio_3_265  -1.375
    w_3_11    full_original_Gini_326  -1.3290079365079366e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_12    OBJ       -5.9999999999999984e-03
    x_3_12    product_lb_251  -2.5101601721227582e-02
    x_3_12    product_ub_252  -4.1955247735790492e-02
    x_3_12    onehot_3_263  1
    x_3_12    stock_lb_266  12
    x_3_12    stock_ub_267  12
    x_3_12    parent_nonstrict_scope_268  0.048
    MARKER    'MARKER'                 'INTEND'
    w_3_12    product_lb_251  1
    w_3_12    product_ub_252  1
    w_3_12    normalized_mass_3_264  1
    w_3_12    normalized_ratio_3_265  -1.5
    w_3_12    full_original_Gini_326  -1.6665079365079364e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_13    OBJ       5.9999999999999984e-03
    x_3_13    product_lb_253  -2.5101601721227582e-02
    x_3_13    product_ub_254  -4.1955247735790492e-02
    x_3_13    onehot_3_263  1
    x_3_13    stock_lb_266  13
    x_3_13    stock_ub_267  13
    x_3_13    parent_nonstrict_scope_268  0.06
    x_3_13    unique_nonzero_owner_435  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_13    product_lb_253  1
    w_3_13    product_ub_254  1
    w_3_13    normalized_mass_3_264  1
    w_3_13    normalized_ratio_3_265  -1.625
    w_3_13    full_original_Gini_326  -2.0040079365079364e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_14    OBJ       1.8000000000000009e-02
    x_3_14    product_lb_255  -2.5101601721227582e-02
    x_3_14    product_ub_256  -4.1955247735790492e-02
    x_3_14    onehot_3_263  1
    x_3_14    stock_lb_266  14
    x_3_14    stock_ub_267  14
    x_3_14    parent_nonstrict_scope_268  7.2000000000000008e-02
    x_3_14    unique_nonzero_owner_436  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_14    product_lb_255  1
    w_3_14    product_ub_256  1
    w_3_14    normalized_mass_3_264  1
    w_3_14    normalized_ratio_3_265  -1.75
    w_3_14    full_original_Gini_326  -2.3415079365079361e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_15    OBJ       3.0000000000000006e-02
    x_3_15    product_lb_257  -2.5101601721227582e-02
    x_3_15    product_ub_258  -4.1955247735790492e-02
    x_3_15    onehot_3_263  1
    x_3_15    stock_lb_266  15
    x_3_15    stock_ub_267  15
    x_3_15    parent_nonstrict_scope_268  0.084
    x_3_15    unique_nonzero_owner_437  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_15    product_lb_257  1
    w_3_15    product_ub_258  1
    w_3_15    normalized_mass_3_264  1
    w_3_15    normalized_ratio_3_265  -1.875
    w_3_15    full_original_Gini_326  -2.6790079365079361e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_16    OBJ       0.042
    x_3_16    product_lb_259  -2.5101601721227582e-02
    x_3_16    product_ub_260  -4.1955247735790492e-02
    x_3_16    onehot_3_263  1
    x_3_16    stock_lb_266  16
    x_3_16    stock_ub_267  16
    x_3_16    parent_nonstrict_scope_268  0.096
    x_3_16    unique_nonzero_owner_438  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_16    product_lb_259  1
    w_3_16    product_ub_260  1
    w_3_16    normalized_mass_3_264  1
    w_3_16    normalized_ratio_3_265  -2
    w_3_16    full_original_Gini_326  -3.0165079365079361e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_17    OBJ       0.054
    x_3_17    product_lb_261  -2.5101601721227582e-02
    x_3_17    product_ub_262  -4.1955247735790492e-02
    x_3_17    onehot_3_263  1
    x_3_17    stock_lb_266  17
    x_3_17    stock_ub_267  17
    x_3_17    parent_nonstrict_scope_268  0.108
    x_3_17    unique_nonzero_owner_439  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_17    product_lb_261  1
    w_3_17    product_ub_262  1
    w_3_17    normalized_mass_3_264  1
    w_3_17    normalized_ratio_3_265  -2.125
    w_3_17    full_original_Gini_326  -3.3540079365079364e+01
    rho_3     normalized_ratio_3_265  1
    rho_3     block_pair_pos_269  1
    rho_3     block_pair_neg_270  -1
    rho_3     block_pair_pos_273  1
    rho_3     block_pair_neg_274  -1
    rho_3     block_pair_pos_281  1
    rho_3     block_pair_neg_282  -1
    rho_3     block_pair_pos_287  1
    rho_3     block_pair_neg_288  -1
    rho_3     block_pair_pos_301  1
    rho_3     block_pair_neg_302  -1
    rho_3     block_pair_pos_313  1
    rho_3     block_pair_neg_314  -1
    rho_3     block_pair_pos_323  1
    rho_3     block_pair_neg_324  -1
    rho_3     normalization_325  1
    a_18_22   block_pair_pos_295  1
    a_18_22   block_pair_neg_296  1
    a_18_22   full_original_Gini_326  -1
    a_18_31   block_pair_pos_297  1
    a_18_31   block_pair_neg_298  1
    a_18_31   full_original_Gini_326  -1
    a_18_14   block_pair_pos_291  1
    a_18_14   block_pair_neg_292  1
    a_18_14   full_original_Gini_326  -1
    a_18_16   block_pair_pos_293  1
    a_18_16   block_pair_neg_294  1
    a_18_16   full_original_Gini_326  -1
    a_18_5    block_pair_pos_289  1
    a_18_5    block_pair_neg_290  1
    a_18_5    full_original_Gini_326  -1
    a_18_32   block_pair_pos_299  1
    a_18_32   block_pair_neg_300  1
    a_18_32   full_original_Gini_326  -1
    a_18_3    block_pair_pos_287  1
    a_18_3    block_pair_neg_288  1
    a_18_3    full_original_Gini_326  -1
    a_22_31   block_pair_pos_309  1
    a_22_31   block_pair_neg_310  1
    a_22_31   full_original_Gini_326  -1
    a_22_14   block_pair_pos_305  1
    a_22_14   block_pair_neg_306  1
    a_22_14   full_original_Gini_326  -1
    a_22_16   block_pair_pos_307  1
    a_22_16   block_pair_neg_308  1
    a_22_16   full_original_Gini_326  -1
    a_22_5    block_pair_pos_303  1
    a_22_5    block_pair_neg_304  1
    a_22_5    full_original_Gini_326  -1
    a_22_32   block_pair_pos_311  1
    a_22_32   block_pair_neg_312  1
    a_22_32   full_original_Gini_326  -1
    a_22_3    block_pair_pos_301  1
    a_22_3    block_pair_neg_302  1
    a_22_3    full_original_Gini_326  -1
    a_31_14   block_pair_pos_317  1
    a_31_14   block_pair_neg_318  1
    a_31_14   full_original_Gini_326  -1
    a_31_16   block_pair_pos_319  1
    a_31_16   block_pair_neg_320  1
    a_31_16   full_original_Gini_326  -1
    a_31_5    block_pair_pos_315  1
    a_31_5    block_pair_neg_316  1
    a_31_5    full_original_Gini_326  -1
    a_31_32   block_pair_pos_321  1
    a_31_32   block_pair_neg_322  1
    a_31_32   full_original_Gini_326  -1
    a_31_3    block_pair_pos_313  1
    a_31_3    block_pair_neg_314  1
    a_31_3    full_original_Gini_326  -1
    a_14_16   block_pair_pos_277  1
    a_14_16   block_pair_neg_278  1
    a_14_16   full_original_Gini_326  -1
    a_14_5    block_pair_pos_275  1
    a_14_5    block_pair_neg_276  1
    a_14_5    full_original_Gini_326  -1
    a_14_32   block_pair_pos_279  1
    a_14_32   block_pair_neg_280  1
    a_14_32   full_original_Gini_326  -1
    a_14_3    block_pair_pos_273  1
    a_14_3    block_pair_neg_274  1
    a_14_3    full_original_Gini_326  -1
    a_16_5    block_pair_pos_283  1
    a_16_5    block_pair_neg_284  1
    a_16_5    full_original_Gini_326  -1
    a_16_32   block_pair_pos_285  1
    a_16_32   block_pair_neg_286  1
    a_16_32   full_original_Gini_326  -1
    a_16_3    block_pair_pos_281  1
    a_16_3    block_pair_neg_282  1
    a_16_3    full_original_Gini_326  -1
    a_5_32    block_pair_pos_271  1
    a_5_32    block_pair_neg_272  1
    a_5_32    full_original_Gini_326  -1
    a_5_3     block_pair_pos_269  1
    a_5_3     block_pair_neg_270  1
    a_5_3     full_original_Gini_326  -1
    a_32_3    block_pair_pos_323  1
    a_32_3    block_pair_neg_324  1
    a_32_3    full_original_Gini_326  -1
    MARKER    'MARKER'                 'INTORG'
    service_0_18_0  unique_nonzero_owner_327  1
    service_0_18_0  service_visit_def_881  1
    service_0_18_0  free_load_conservation_882  -12
    service_0_18_0  original_T_including_depot_unload_930  1440
    service_0_18_1  unique_nonzero_owner_328  1
    service_0_18_1  service_visit_def_881  1
    service_0_18_1  free_load_conservation_882  -11
    service_0_18_1  original_T_including_depot_unload_930  1320
    service_0_18_2  unique_nonzero_owner_329  1
    service_0_18_2  service_visit_def_881  1
    service_0_18_2  free_load_conservation_882  -10
    service_0_18_2  original_T_including_depot_unload_930  1200
    service_0_18_3  unique_nonzero_owner_330  1
    service_0_18_3  service_visit_def_881  1
    service_0_18_3  free_load_conservation_882  -9
    service_0_18_3  original_T_including_depot_unload_930  1080
    service_0_18_4  unique_nonzero_owner_331  1
    service_0_18_4  service_visit_def_881  1
    service_0_18_4  free_load_conservation_882  -8
    service_0_18_4  original_T_including_depot_unload_930  960
    service_0_18_5  unique_nonzero_owner_332  1
    service_0_18_5  service_visit_def_881  1
    service_0_18_5  free_load_conservation_882  -7
    service_0_18_5  original_T_including_depot_unload_930  840
    service_0_18_6  unique_nonzero_owner_333  1
    service_0_18_6  service_visit_def_881  1
    service_0_18_6  free_load_conservation_882  -6
    service_0_18_6  original_T_including_depot_unload_930  720
    service_0_18_7  unique_nonzero_owner_334  1
    service_0_18_7  service_visit_def_881  1
    service_0_18_7  free_load_conservation_882  -5
    service_0_18_7  original_T_including_depot_unload_930  600
    service_0_18_8  unique_nonzero_owner_335  1
    service_0_18_8  service_visit_def_881  1
    service_0_18_8  free_load_conservation_882  -4
    service_0_18_8  original_T_including_depot_unload_930  480
    service_0_18_9  unique_nonzero_owner_336  1
    service_0_18_9  service_visit_def_881  1
    service_0_18_9  free_load_conservation_882  -3
    service_0_18_9  original_T_including_depot_unload_930  360
    service_0_18_10  unique_nonzero_owner_337  1
    service_0_18_10  service_visit_def_881  1
    service_0_18_10  free_load_conservation_882  -2
    service_0_18_10  original_T_including_depot_unload_930  240
    service_0_18_11  unique_nonzero_owner_338  1
    service_0_18_11  service_visit_def_881  1
    service_0_18_11  free_load_conservation_882  -1
    service_0_18_11  original_T_including_depot_unload_930  120
    service_0_18_13  unique_nonzero_owner_339  1
    service_0_18_13  service_visit_def_881  1
    service_0_18_13  free_load_conservation_882  1
    service_0_18_14  unique_nonzero_owner_340  1
    service_0_18_14  service_visit_def_881  1
    service_0_18_14  free_load_conservation_882  2
    service_0_18_15  unique_nonzero_owner_341  1
    service_0_18_15  service_visit_def_881  1
    service_0_18_15  free_load_conservation_882  3
    service_0_18_16  unique_nonzero_owner_342  1
    service_0_18_16  service_visit_def_881  1
    service_0_18_16  free_load_conservation_882  4
    service_0_18_17  unique_nonzero_owner_343  1
    service_0_18_17  service_visit_def_881  1
    service_0_18_17  free_load_conservation_882  5
    service_1_18_0  unique_nonzero_owner_327  1
    service_1_18_0  service_visit_def_1311  1
    service_1_18_0  free_load_conservation_1312  -12
    service_1_18_0  original_T_including_depot_unload_1359  1440
    service_1_18_1  unique_nonzero_owner_328  1
    service_1_18_1  service_visit_def_1311  1
    service_1_18_1  free_load_conservation_1312  -11
    service_1_18_1  original_T_including_depot_unload_1359  1320
    service_1_18_2  unique_nonzero_owner_329  1
    service_1_18_2  service_visit_def_1311  1
    service_1_18_2  free_load_conservation_1312  -10
    service_1_18_2  original_T_including_depot_unload_1359  1200
    service_1_18_3  unique_nonzero_owner_330  1
    service_1_18_3  service_visit_def_1311  1
    service_1_18_3  free_load_conservation_1312  -9
    service_1_18_3  original_T_including_depot_unload_1359  1080
    service_1_18_4  unique_nonzero_owner_331  1
    service_1_18_4  service_visit_def_1311  1
    service_1_18_4  free_load_conservation_1312  -8
    service_1_18_4  original_T_including_depot_unload_1359  960
    service_1_18_5  unique_nonzero_owner_332  1
    service_1_18_5  service_visit_def_1311  1
    service_1_18_5  free_load_conservation_1312  -7
    service_1_18_5  original_T_including_depot_unload_1359  840
    service_1_18_6  unique_nonzero_owner_333  1
    service_1_18_6  service_visit_def_1311  1
    service_1_18_6  free_load_conservation_1312  -6
    service_1_18_6  original_T_including_depot_unload_1359  720
    service_1_18_7  unique_nonzero_owner_334  1
    service_1_18_7  service_visit_def_1311  1
    service_1_18_7  free_load_conservation_1312  -5
    service_1_18_7  original_T_including_depot_unload_1359  600
    service_1_18_8  unique_nonzero_owner_335  1
    service_1_18_8  service_visit_def_1311  1
    service_1_18_8  free_load_conservation_1312  -4
    service_1_18_8  original_T_including_depot_unload_1359  480
    service_1_18_9  unique_nonzero_owner_336  1
    service_1_18_9  service_visit_def_1311  1
    service_1_18_9  free_load_conservation_1312  -3
    service_1_18_9  original_T_including_depot_unload_1359  360
    service_1_18_10  unique_nonzero_owner_337  1
    service_1_18_10  service_visit_def_1311  1
    service_1_18_10  free_load_conservation_1312  -2
    service_1_18_10  original_T_including_depot_unload_1359  240
    service_1_18_11  unique_nonzero_owner_338  1
    service_1_18_11  service_visit_def_1311  1
    service_1_18_11  free_load_conservation_1312  -1
    service_1_18_11  original_T_including_depot_unload_1359  120
    service_1_18_13  unique_nonzero_owner_339  1
    service_1_18_13  service_visit_def_1311  1
    service_1_18_13  free_load_conservation_1312  1
    service_1_18_14  unique_nonzero_owner_340  1
    service_1_18_14  service_visit_def_1311  1
    service_1_18_14  free_load_conservation_1312  2
    service_1_18_15  unique_nonzero_owner_341  1
    service_1_18_15  service_visit_def_1311  1
    service_1_18_15  free_load_conservation_1312  3
    service_1_18_16  unique_nonzero_owner_342  1
    service_1_18_16  service_visit_def_1311  1
    service_1_18_16  free_load_conservation_1312  4
    service_1_18_17  unique_nonzero_owner_343  1
    service_1_18_17  service_visit_def_1311  1
    service_1_18_17  free_load_conservation_1312  5
    service_2_18_0  unique_nonzero_owner_327  1
    service_2_18_0  service_visit_def_1740  1
    service_2_18_0  free_load_conservation_1741  -12
    service_2_18_0  original_T_including_depot_unload_1788  1440
    service_2_18_1  unique_nonzero_owner_328  1
    service_2_18_1  service_visit_def_1740  1
    service_2_18_1  free_load_conservation_1741  -11
    service_2_18_1  original_T_including_depot_unload_1788  1320
    service_2_18_2  unique_nonzero_owner_329  1
    service_2_18_2  service_visit_def_1740  1
    service_2_18_2  free_load_conservation_1741  -10
    service_2_18_2  original_T_including_depot_unload_1788  1200
    service_2_18_3  unique_nonzero_owner_330  1
    service_2_18_3  service_visit_def_1740  1
    service_2_18_3  free_load_conservation_1741  -9
    service_2_18_3  original_T_including_depot_unload_1788  1080
    service_2_18_4  unique_nonzero_owner_331  1
    service_2_18_4  service_visit_def_1740  1
    service_2_18_4  free_load_conservation_1741  -8
    service_2_18_4  original_T_including_depot_unload_1788  960
    service_2_18_5  unique_nonzero_owner_332  1
    service_2_18_5  service_visit_def_1740  1
    service_2_18_5  free_load_conservation_1741  -7
    service_2_18_5  original_T_including_depot_unload_1788  840
    service_2_18_6  unique_nonzero_owner_333  1
    service_2_18_6  service_visit_def_1740  1
    service_2_18_6  free_load_conservation_1741  -6
    service_2_18_6  original_T_including_depot_unload_1788  720
    service_2_18_7  unique_nonzero_owner_334  1
    service_2_18_7  service_visit_def_1740  1
    service_2_18_7  free_load_conservation_1741  -5
    service_2_18_7  original_T_including_depot_unload_1788  600
    service_2_18_8  unique_nonzero_owner_335  1
    service_2_18_8  service_visit_def_1740  1
    service_2_18_8  free_load_conservation_1741  -4
    service_2_18_8  original_T_including_depot_unload_1788  480
    service_2_18_9  unique_nonzero_owner_336  1
    service_2_18_9  service_visit_def_1740  1
    service_2_18_9  free_load_conservation_1741  -3
    service_2_18_9  original_T_including_depot_unload_1788  360
    service_2_18_10  unique_nonzero_owner_337  1
    service_2_18_10  service_visit_def_1740  1
    service_2_18_10  free_load_conservation_1741  -2
    service_2_18_10  original_T_including_depot_unload_1788  240
    service_2_18_11  unique_nonzero_owner_338  1
    service_2_18_11  service_visit_def_1740  1
    service_2_18_11  free_load_conservation_1741  -1
    service_2_18_11  original_T_including_depot_unload_1788  120
    service_2_18_13  unique_nonzero_owner_339  1
    service_2_18_13  service_visit_def_1740  1
    service_2_18_13  free_load_conservation_1741  1
    service_2_18_14  unique_nonzero_owner_340  1
    service_2_18_14  service_visit_def_1740  1
    service_2_18_14  free_load_conservation_1741  2
    service_2_18_15  unique_nonzero_owner_341  1
    service_2_18_15  service_visit_def_1740  1
    service_2_18_15  free_load_conservation_1741  3
    service_2_18_16  unique_nonzero_owner_342  1
    service_2_18_16  service_visit_def_1740  1
    service_2_18_16  free_load_conservation_1741  4
    service_2_18_17  unique_nonzero_owner_343  1
    service_2_18_17  service_visit_def_1740  1
    service_2_18_17  free_load_conservation_1741  5
    service_0_22_0  unique_nonzero_owner_344  1
    service_0_22_0  service_visit_def_887  1
    service_0_22_0  free_load_conservation_888  -8
    service_0_22_0  original_T_including_depot_unload_930  960
    service_0_22_1  unique_nonzero_owner_345  1
    service_0_22_1  service_visit_def_887  1
    service_0_22_1  free_load_conservation_888  -7
    service_0_22_1  original_T_including_depot_unload_930  840
    service_0_22_2  unique_nonzero_owner_346  1
    service_0_22_2  service_visit_def_887  1
    service_0_22_2  free_load_conservation_888  -6
    service_0_22_2  original_T_including_depot_unload_930  720
    service_0_22_3  unique_nonzero_owner_347  1
    service_0_22_3  service_visit_def_887  1
    service_0_22_3  free_load_conservation_888  -5
    service_0_22_3  original_T_including_depot_unload_930  600
    service_0_22_4  unique_nonzero_owner_348  1
    service_0_22_4  service_visit_def_887  1
    service_0_22_4  free_load_conservation_888  -4
    service_0_22_4  original_T_including_depot_unload_930  480
    service_0_22_5  unique_nonzero_owner_349  1
    service_0_22_5  service_visit_def_887  1
    service_0_22_5  free_load_conservation_888  -3
    service_0_22_5  original_T_including_depot_unload_930  360
    service_0_22_6  unique_nonzero_owner_350  1
    service_0_22_6  service_visit_def_887  1
    service_0_22_6  free_load_conservation_888  -2
    service_0_22_6  original_T_including_depot_unload_930  240
    service_0_22_7  unique_nonzero_owner_351  1
    service_0_22_7  service_visit_def_887  1
    service_0_22_7  free_load_conservation_888  -1
    service_0_22_7  original_T_including_depot_unload_930  120
    service_0_22_9  unique_nonzero_owner_352  1
    service_0_22_9  service_visit_def_887  1
    service_0_22_9  free_load_conservation_888  1
    service_0_22_10  unique_nonzero_owner_353  1
    service_0_22_10  service_visit_def_887  1
    service_0_22_10  free_load_conservation_888  2
    service_0_22_11  unique_nonzero_owner_354  1
    service_0_22_11  service_visit_def_887  1
    service_0_22_11  free_load_conservation_888  3
    service_0_22_12  unique_nonzero_owner_355  1
    service_0_22_12  service_visit_def_887  1
    service_0_22_12  free_load_conservation_888  4
    service_1_22_0  unique_nonzero_owner_344  1
    service_1_22_0  service_visit_def_1317  1
    service_1_22_0  free_load_conservation_1318  -8
    service_1_22_0  original_T_including_depot_unload_1359  960
    service_1_22_1  unique_nonzero_owner_345  1
    service_1_22_1  service_visit_def_1317  1
    service_1_22_1  free_load_conservation_1318  -7
    service_1_22_1  original_T_including_depot_unload_1359  840
    service_1_22_2  unique_nonzero_owner_346  1
    service_1_22_2  service_visit_def_1317  1
    service_1_22_2  free_load_conservation_1318  -6
    service_1_22_2  original_T_including_depot_unload_1359  720
    service_1_22_3  unique_nonzero_owner_347  1
    service_1_22_3  service_visit_def_1317  1
    service_1_22_3  free_load_conservation_1318  -5
    service_1_22_3  original_T_including_depot_unload_1359  600
    service_1_22_4  unique_nonzero_owner_348  1
    service_1_22_4  service_visit_def_1317  1
    service_1_22_4  free_load_conservation_1318  -4
    service_1_22_4  original_T_including_depot_unload_1359  480
    service_1_22_5  unique_nonzero_owner_349  1
    service_1_22_5  service_visit_def_1317  1
    service_1_22_5  free_load_conservation_1318  -3
    service_1_22_5  original_T_including_depot_unload_1359  360
    service_1_22_6  unique_nonzero_owner_350  1
    service_1_22_6  service_visit_def_1317  1
    service_1_22_6  free_load_conservation_1318  -2
    service_1_22_6  original_T_including_depot_unload_1359  240
    service_1_22_7  unique_nonzero_owner_351  1
    service_1_22_7  service_visit_def_1317  1
    service_1_22_7  free_load_conservation_1318  -1
    service_1_22_7  original_T_including_depot_unload_1359  120
    service_1_22_9  unique_nonzero_owner_352  1
    service_1_22_9  service_visit_def_1317  1
    service_1_22_9  free_load_conservation_1318  1
    service_1_22_10  unique_nonzero_owner_353  1
    service_1_22_10  service_visit_def_1317  1
    service_1_22_10  free_load_conservation_1318  2
    service_1_22_11  unique_nonzero_owner_354  1
    service_1_22_11  service_visit_def_1317  1
    service_1_22_11  free_load_conservation_1318  3
    service_1_22_12  unique_nonzero_owner_355  1
    service_1_22_12  service_visit_def_1317  1
    service_1_22_12  free_load_conservation_1318  4
    service_2_22_0  unique_nonzero_owner_344  1
    service_2_22_0  service_visit_def_1746  1
    service_2_22_0  free_load_conservation_1747  -8
    service_2_22_0  original_T_including_depot_unload_1788  960
    service_2_22_1  unique_nonzero_owner_345  1
    service_2_22_1  service_visit_def_1746  1
    service_2_22_1  free_load_conservation_1747  -7
    service_2_22_1  original_T_including_depot_unload_1788  840
    service_2_22_2  unique_nonzero_owner_346  1
    service_2_22_2  service_visit_def_1746  1
    service_2_22_2  free_load_conservation_1747  -6
    service_2_22_2  original_T_including_depot_unload_1788  720
    service_2_22_3  unique_nonzero_owner_347  1
    service_2_22_3  service_visit_def_1746  1
    service_2_22_3  free_load_conservation_1747  -5
    service_2_22_3  original_T_including_depot_unload_1788  600
    service_2_22_4  unique_nonzero_owner_348  1
    service_2_22_4  service_visit_def_1746  1
    service_2_22_4  free_load_conservation_1747  -4
    service_2_22_4  original_T_including_depot_unload_1788  480
    service_2_22_5  unique_nonzero_owner_349  1
    service_2_22_5  service_visit_def_1746  1
    service_2_22_5  free_load_conservation_1747  -3
    service_2_22_5  original_T_including_depot_unload_1788  360
    service_2_22_6  unique_nonzero_owner_350  1
    service_2_22_6  service_visit_def_1746  1
    service_2_22_6  free_load_conservation_1747  -2
    service_2_22_6  original_T_including_depot_unload_1788  240
    service_2_22_7  unique_nonzero_owner_351  1
    service_2_22_7  service_visit_def_1746  1
    service_2_22_7  free_load_conservation_1747  -1
    service_2_22_7  original_T_including_depot_unload_1788  120
    service_2_22_9  unique_nonzero_owner_352  1
    service_2_22_9  service_visit_def_1746  1
    service_2_22_9  free_load_conservation_1747  1
    service_2_22_10  unique_nonzero_owner_353  1
    service_2_22_10  service_visit_def_1746  1
    service_2_22_10  free_load_conservation_1747  2
    service_2_22_11  unique_nonzero_owner_354  1
    service_2_22_11  service_visit_def_1746  1
    service_2_22_11  free_load_conservation_1747  3
    service_2_22_12  unique_nonzero_owner_355  1
    service_2_22_12  service_visit_def_1746  1
    service_2_22_12  free_load_conservation_1747  4
    service_0_31_0  unique_nonzero_owner_356  1
    service_0_31_0  service_visit_def_893  1
    service_0_31_0  free_load_conservation_894  -2
    service_0_31_0  original_T_including_depot_unload_930  240
    service_0_31_1  unique_nonzero_owner_357  1
    service_0_31_1  service_visit_def_893  1
    service_0_31_1  free_load_conservation_894  -1
    service_0_31_1  original_T_including_depot_unload_930  120
    service_0_31_3  unique_nonzero_owner_358  1
    service_0_31_3  service_visit_def_893  1
    service_0_31_3  free_load_conservation_894  1
    service_0_31_4  unique_nonzero_owner_359  1
    service_0_31_4  service_visit_def_893  1
    service_0_31_4  free_load_conservation_894  2
    service_0_31_5  unique_nonzero_owner_360  1
    service_0_31_5  service_visit_def_893  1
    service_0_31_5  free_load_conservation_894  3
    service_0_31_6  unique_nonzero_owner_361  1
    service_0_31_6  service_visit_def_893  1
    service_0_31_6  free_load_conservation_894  4
    service_0_31_7  unique_nonzero_owner_362  1
    service_0_31_7  service_visit_def_893  1
    service_0_31_7  free_load_conservation_894  5
    service_0_31_8  unique_nonzero_owner_363  1
    service_0_31_8  service_visit_def_893  1
    service_0_31_8  free_load_conservation_894  6
    service_0_31_9  unique_nonzero_owner_364  1
    service_0_31_9  service_visit_def_893  1
    service_0_31_9  free_load_conservation_894  7
    service_0_31_10  unique_nonzero_owner_365  1
    service_0_31_10  service_visit_def_893  1
    service_0_31_10  free_load_conservation_894  8
    service_0_31_11  unique_nonzero_owner_366  1
    service_0_31_11  service_visit_def_893  1
    service_0_31_11  free_load_conservation_894  9
    service_0_31_12  unique_nonzero_owner_367  1
    service_0_31_12  service_visit_def_893  1
    service_0_31_12  free_load_conservation_894  10
    service_1_31_0  unique_nonzero_owner_356  1
    service_1_31_0  service_visit_def_1323  1
    service_1_31_0  free_load_conservation_1324  -2
    service_1_31_0  original_T_including_depot_unload_1359  240
    service_1_31_1  unique_nonzero_owner_357  1
    service_1_31_1  service_visit_def_1323  1
    service_1_31_1  free_load_conservation_1324  -1
    service_1_31_1  original_T_including_depot_unload_1359  120
    service_1_31_3  unique_nonzero_owner_358  1
    service_1_31_3  service_visit_def_1323  1
    service_1_31_3  free_load_conservation_1324  1
    service_1_31_4  unique_nonzero_owner_359  1
    service_1_31_4  service_visit_def_1323  1
    service_1_31_4  free_load_conservation_1324  2
    service_1_31_5  unique_nonzero_owner_360  1
    service_1_31_5  service_visit_def_1323  1
    service_1_31_5  free_load_conservation_1324  3
    service_1_31_6  unique_nonzero_owner_361  1
    service_1_31_6  service_visit_def_1323  1
    service_1_31_6  free_load_conservation_1324  4
    service_1_31_7  unique_nonzero_owner_362  1
    service_1_31_7  service_visit_def_1323  1
    service_1_31_7  free_load_conservation_1324  5
    service_1_31_8  unique_nonzero_owner_363  1
    service_1_31_8  service_visit_def_1323  1
    service_1_31_8  free_load_conservation_1324  6
    service_1_31_9  unique_nonzero_owner_364  1
    service_1_31_9  service_visit_def_1323  1
    service_1_31_9  free_load_conservation_1324  7
    service_1_31_10  unique_nonzero_owner_365  1
    service_1_31_10  service_visit_def_1323  1
    service_1_31_10  free_load_conservation_1324  8
    service_1_31_11  unique_nonzero_owner_366  1
    service_1_31_11  service_visit_def_1323  1
    service_1_31_11  free_load_conservation_1324  9
    service_1_31_12  unique_nonzero_owner_367  1
    service_1_31_12  service_visit_def_1323  1
    service_1_31_12  free_load_conservation_1324  10
    service_2_31_0  unique_nonzero_owner_356  1
    service_2_31_0  service_visit_def_1752  1
    service_2_31_0  free_load_conservation_1753  -2
    service_2_31_0  original_T_including_depot_unload_1788  240
    service_2_31_1  unique_nonzero_owner_357  1
    service_2_31_1  service_visit_def_1752  1
    service_2_31_1  free_load_conservation_1753  -1
    service_2_31_1  original_T_including_depot_unload_1788  120
    service_2_31_3  unique_nonzero_owner_358  1
    service_2_31_3  service_visit_def_1752  1
    service_2_31_3  free_load_conservation_1753  1
    service_2_31_4  unique_nonzero_owner_359  1
    service_2_31_4  service_visit_def_1752  1
    service_2_31_4  free_load_conservation_1753  2
    service_2_31_5  unique_nonzero_owner_360  1
    service_2_31_5  service_visit_def_1752  1
    service_2_31_5  free_load_conservation_1753  3
    service_2_31_6  unique_nonzero_owner_361  1
    service_2_31_6  service_visit_def_1752  1
    service_2_31_6  free_load_conservation_1753  4
    service_2_31_7  unique_nonzero_owner_362  1
    service_2_31_7  service_visit_def_1752  1
    service_2_31_7  free_load_conservation_1753  5
    service_2_31_8  unique_nonzero_owner_363  1
    service_2_31_8  service_visit_def_1752  1
    service_2_31_8  free_load_conservation_1753  6
    service_2_31_9  unique_nonzero_owner_364  1
    service_2_31_9  service_visit_def_1752  1
    service_2_31_9  free_load_conservation_1753  7
    service_2_31_10  unique_nonzero_owner_365  1
    service_2_31_10  service_visit_def_1752  1
    service_2_31_10  free_load_conservation_1753  8
    service_2_31_11  unique_nonzero_owner_366  1
    service_2_31_11  service_visit_def_1752  1
    service_2_31_11  free_load_conservation_1753  9
    service_2_31_12  unique_nonzero_owner_367  1
    service_2_31_12  service_visit_def_1752  1
    service_2_31_12  free_load_conservation_1753  10
    service_0_14_0  unique_nonzero_owner_368  1
    service_0_14_0  service_visit_def_899  1
    service_0_14_0  free_load_conservation_900  -2
    service_0_14_0  original_T_including_depot_unload_930  240
    service_0_14_1  unique_nonzero_owner_369  1
    service_0_14_1  service_visit_def_899  1
    service_0_14_1  free_load_conservation_900  -1
    service_0_14_1  original_T_including_depot_unload_930  120
    service_0_14_3  unique_nonzero_owner_370  1
    service_0_14_3  service_visit_def_899  1
    service_0_14_3  free_load_conservation_900  1
    service_0_14_4  unique_nonzero_owner_371  1
    service_0_14_4  service_visit_def_899  1
    service_0_14_4  free_load_conservation_900  2
    service_0_14_5  unique_nonzero_owner_372  1
    service_0_14_5  service_visit_def_899  1
    service_0_14_5  free_load_conservation_900  3
    service_0_14_6  unique_nonzero_owner_373  1
    service_0_14_6  service_visit_def_899  1
    service_0_14_6  free_load_conservation_900  4
    service_0_14_7  unique_nonzero_owner_374  1
    service_0_14_7  service_visit_def_899  1
    service_0_14_7  free_load_conservation_900  5
    service_0_14_8  unique_nonzero_owner_375  1
    service_0_14_8  service_visit_def_899  1
    service_0_14_8  free_load_conservation_900  6
    service_0_14_9  unique_nonzero_owner_376  1
    service_0_14_9  service_visit_def_899  1
    service_0_14_9  free_load_conservation_900  7
    service_0_14_10  unique_nonzero_owner_377  1
    service_0_14_10  service_visit_def_899  1
    service_0_14_10  free_load_conservation_900  8
    service_0_14_11  unique_nonzero_owner_378  1
    service_0_14_11  service_visit_def_899  1
    service_0_14_11  free_load_conservation_900  9
    service_0_14_12  unique_nonzero_owner_379  1
    service_0_14_12  service_visit_def_899  1
    service_0_14_12  free_load_conservation_900  10
    service_0_14_13  unique_nonzero_owner_380  1
    service_0_14_13  service_visit_def_899  1
    service_0_14_13  free_load_conservation_900  11
    service_0_14_14  unique_nonzero_owner_381  1
    service_0_14_14  service_visit_def_899  1
    service_0_14_14  free_load_conservation_900  12
    service_0_14_15  unique_nonzero_owner_382  1
    service_0_14_15  service_visit_def_899  1
    service_0_14_15  free_load_conservation_900  13
    service_1_14_0  unique_nonzero_owner_368  1
    service_1_14_0  service_visit_def_1329  1
    service_1_14_0  free_load_conservation_1330  -2
    service_1_14_0  original_T_including_depot_unload_1359  240
    service_1_14_1  unique_nonzero_owner_369  1
    service_1_14_1  service_visit_def_1329  1
    service_1_14_1  free_load_conservation_1330  -1
    service_1_14_1  original_T_including_depot_unload_1359  120
    service_1_14_3  unique_nonzero_owner_370  1
    service_1_14_3  service_visit_def_1329  1
    service_1_14_3  free_load_conservation_1330  1
    service_1_14_4  unique_nonzero_owner_371  1
    service_1_14_4  service_visit_def_1329  1
    service_1_14_4  free_load_conservation_1330  2
    service_1_14_5  unique_nonzero_owner_372  1
    service_1_14_5  service_visit_def_1329  1
    service_1_14_5  free_load_conservation_1330  3
    service_1_14_6  unique_nonzero_owner_373  1
    service_1_14_6  service_visit_def_1329  1
    service_1_14_6  free_load_conservation_1330  4
    service_1_14_7  unique_nonzero_owner_374  1
    service_1_14_7  service_visit_def_1329  1
    service_1_14_7  free_load_conservation_1330  5
    service_1_14_8  unique_nonzero_owner_375  1
    service_1_14_8  service_visit_def_1329  1
    service_1_14_8  free_load_conservation_1330  6
    service_1_14_9  unique_nonzero_owner_376  1
    service_1_14_9  service_visit_def_1329  1
    service_1_14_9  free_load_conservation_1330  7
    service_1_14_10  unique_nonzero_owner_377  1
    service_1_14_10  service_visit_def_1329  1
    service_1_14_10  free_load_conservation_1330  8
    service_1_14_11  unique_nonzero_owner_378  1
    service_1_14_11  service_visit_def_1329  1
    service_1_14_11  free_load_conservation_1330  9
    service_1_14_12  unique_nonzero_owner_379  1
    service_1_14_12  service_visit_def_1329  1
    service_1_14_12  free_load_conservation_1330  10
    service_1_14_13  unique_nonzero_owner_380  1
    service_1_14_13  service_visit_def_1329  1
    service_1_14_13  free_load_conservation_1330  11
    service_1_14_14  unique_nonzero_owner_381  1
    service_1_14_14  service_visit_def_1329  1
    service_1_14_14  free_load_conservation_1330  12
    service_1_14_15  unique_nonzero_owner_382  1
    service_1_14_15  service_visit_def_1329  1
    service_1_14_15  free_load_conservation_1330  13
    service_2_14_0  unique_nonzero_owner_368  1
    service_2_14_0  service_visit_def_1758  1
    service_2_14_0  free_load_conservation_1759  -2
    service_2_14_0  original_T_including_depot_unload_1788  240
    service_2_14_1  unique_nonzero_owner_369  1
    service_2_14_1  service_visit_def_1758  1
    service_2_14_1  free_load_conservation_1759  -1
    service_2_14_1  original_T_including_depot_unload_1788  120
    service_2_14_3  unique_nonzero_owner_370  1
    service_2_14_3  service_visit_def_1758  1
    service_2_14_3  free_load_conservation_1759  1
    service_2_14_4  unique_nonzero_owner_371  1
    service_2_14_4  service_visit_def_1758  1
    service_2_14_4  free_load_conservation_1759  2
    service_2_14_5  unique_nonzero_owner_372  1
    service_2_14_5  service_visit_def_1758  1
    service_2_14_5  free_load_conservation_1759  3
    service_2_14_6  unique_nonzero_owner_373  1
    service_2_14_6  service_visit_def_1758  1
    service_2_14_6  free_load_conservation_1759  4
    service_2_14_7  unique_nonzero_owner_374  1
    service_2_14_7  service_visit_def_1758  1
    service_2_14_7  free_load_conservation_1759  5
    service_2_14_8  unique_nonzero_owner_375  1
    service_2_14_8  service_visit_def_1758  1
    service_2_14_8  free_load_conservation_1759  6
    service_2_14_9  unique_nonzero_owner_376  1
    service_2_14_9  service_visit_def_1758  1
    service_2_14_9  free_load_conservation_1759  7
    service_2_14_10  unique_nonzero_owner_377  1
    service_2_14_10  service_visit_def_1758  1
    service_2_14_10  free_load_conservation_1759  8
    service_2_14_11  unique_nonzero_owner_378  1
    service_2_14_11  service_visit_def_1758  1
    service_2_14_11  free_load_conservation_1759  9
    service_2_14_12  unique_nonzero_owner_379  1
    service_2_14_12  service_visit_def_1758  1
    service_2_14_12  free_load_conservation_1759  10
    service_2_14_13  unique_nonzero_owner_380  1
    service_2_14_13  service_visit_def_1758  1
    service_2_14_13  free_load_conservation_1759  11
    service_2_14_14  unique_nonzero_owner_381  1
    service_2_14_14  service_visit_def_1758  1
    service_2_14_14  free_load_conservation_1759  12
    service_2_14_15  unique_nonzero_owner_382  1
    service_2_14_15  service_visit_def_1758  1
    service_2_14_15  free_load_conservation_1759  13
    service_0_16_0  unique_nonzero_owner_383  1
    service_0_16_0  service_visit_def_905  1
    service_0_16_0  free_load_conservation_906  -1
    service_0_16_0  original_T_including_depot_unload_930  120
    service_0_16_2  unique_nonzero_owner_384  1
    service_0_16_2  service_visit_def_905  1
    service_0_16_2  free_load_conservation_906  1
    service_0_16_3  unique_nonzero_owner_385  1
    service_0_16_3  service_visit_def_905  1
    service_0_16_3  free_load_conservation_906  2
    service_0_16_4  unique_nonzero_owner_386  1
    service_0_16_4  service_visit_def_905  1
    service_0_16_4  free_load_conservation_906  3
    service_0_16_5  unique_nonzero_owner_387  1
    service_0_16_5  service_visit_def_905  1
    service_0_16_5  free_load_conservation_906  4
    service_0_16_6  unique_nonzero_owner_388  1
    service_0_16_6  service_visit_def_905  1
    service_0_16_6  free_load_conservation_906  5
    service_0_16_7  unique_nonzero_owner_389  1
    service_0_16_7  service_visit_def_905  1
    service_0_16_7  free_load_conservation_906  6
    service_0_16_8  unique_nonzero_owner_390  1
    service_0_16_8  service_visit_def_905  1
    service_0_16_8  free_load_conservation_906  7
    service_0_16_9  unique_nonzero_owner_391  1
    service_0_16_9  service_visit_def_905  1
    service_0_16_9  free_load_conservation_906  8
    service_0_16_10  unique_nonzero_owner_392  1
    service_0_16_10  service_visit_def_905  1
    service_0_16_10  free_load_conservation_906  9
    service_0_16_11  unique_nonzero_owner_393  1
    service_0_16_11  service_visit_def_905  1
    service_0_16_11  free_load_conservation_906  10
    service_0_16_12  unique_nonzero_owner_394  1
    service_0_16_12  service_visit_def_905  1
    service_0_16_12  free_load_conservation_906  11
    service_1_16_0  unique_nonzero_owner_383  1
    service_1_16_0  service_visit_def_1335  1
    service_1_16_0  free_load_conservation_1336  -1
    service_1_16_0  original_T_including_depot_unload_1359  120
    service_1_16_2  unique_nonzero_owner_384  1
    service_1_16_2  service_visit_def_1335  1
    service_1_16_2  free_load_conservation_1336  1
    service_1_16_3  unique_nonzero_owner_385  1
    service_1_16_3  service_visit_def_1335  1
    service_1_16_3  free_load_conservation_1336  2
    service_1_16_4  unique_nonzero_owner_386  1
    service_1_16_4  service_visit_def_1335  1
    service_1_16_4  free_load_conservation_1336  3
    service_1_16_5  unique_nonzero_owner_387  1
    service_1_16_5  service_visit_def_1335  1
    service_1_16_5  free_load_conservation_1336  4
    service_1_16_6  unique_nonzero_owner_388  1
    service_1_16_6  service_visit_def_1335  1
    service_1_16_6  free_load_conservation_1336  5
    service_1_16_7  unique_nonzero_owner_389  1
    service_1_16_7  service_visit_def_1335  1
    service_1_16_7  free_load_conservation_1336  6
    service_1_16_8  unique_nonzero_owner_390  1
    service_1_16_8  service_visit_def_1335  1
    service_1_16_8  free_load_conservation_1336  7
    service_1_16_9  unique_nonzero_owner_391  1
    service_1_16_9  service_visit_def_1335  1
    service_1_16_9  free_load_conservation_1336  8
    service_1_16_10  unique_nonzero_owner_392  1
    service_1_16_10  service_visit_def_1335  1
    service_1_16_10  free_load_conservation_1336  9
    service_1_16_11  unique_nonzero_owner_393  1
    service_1_16_11  service_visit_def_1335  1
    service_1_16_11  free_load_conservation_1336  10
    service_1_16_12  unique_nonzero_owner_394  1
    service_1_16_12  service_visit_def_1335  1
    service_1_16_12  free_load_conservation_1336  11
    service_2_16_0  unique_nonzero_owner_383  1
    service_2_16_0  service_visit_def_1764  1
    service_2_16_0  free_load_conservation_1765  -1
    service_2_16_0  original_T_including_depot_unload_1788  120
    service_2_16_2  unique_nonzero_owner_384  1
    service_2_16_2  service_visit_def_1764  1
    service_2_16_2  free_load_conservation_1765  1
    service_2_16_3  unique_nonzero_owner_385  1
    service_2_16_3  service_visit_def_1764  1
    service_2_16_3  free_load_conservation_1765  2
    service_2_16_4  unique_nonzero_owner_386  1
    service_2_16_4  service_visit_def_1764  1
    service_2_16_4  free_load_conservation_1765  3
    service_2_16_5  unique_nonzero_owner_387  1
    service_2_16_5  service_visit_def_1764  1
    service_2_16_5  free_load_conservation_1765  4
    service_2_16_6  unique_nonzero_owner_388  1
    service_2_16_6  service_visit_def_1764  1
    service_2_16_6  free_load_conservation_1765  5
    service_2_16_7  unique_nonzero_owner_389  1
    service_2_16_7  service_visit_def_1764  1
    service_2_16_7  free_load_conservation_1765  6
    service_2_16_8  unique_nonzero_owner_390  1
    service_2_16_8  service_visit_def_1764  1
    service_2_16_8  free_load_conservation_1765  7
    service_2_16_9  unique_nonzero_owner_391  1
    service_2_16_9  service_visit_def_1764  1
    service_2_16_9  free_load_conservation_1765  8
    service_2_16_10  unique_nonzero_owner_392  1
    service_2_16_10  service_visit_def_1764  1
    service_2_16_10  free_load_conservation_1765  9
    service_2_16_11  unique_nonzero_owner_393  1
    service_2_16_11  service_visit_def_1764  1
    service_2_16_11  free_load_conservation_1765  10
    service_2_16_12  unique_nonzero_owner_394  1
    service_2_16_12  service_visit_def_1764  1
    service_2_16_12  free_load_conservation_1765  11
    service_0_5_0  unique_nonzero_owner_395  1
    service_0_5_0  service_visit_def_911  1
    service_0_5_0  free_load_conservation_912  -2
    service_0_5_0  original_T_including_depot_unload_930  240
    service_0_5_1  unique_nonzero_owner_396  1
    service_0_5_1  service_visit_def_911  1
    service_0_5_1  free_load_conservation_912  -1
    service_0_5_1  original_T_including_depot_unload_930  120
    service_0_5_3  unique_nonzero_owner_397  1
    service_0_5_3  service_visit_def_911  1
    service_0_5_3  free_load_conservation_912  1
    service_0_5_4  unique_nonzero_owner_398  1
    service_0_5_4  service_visit_def_911  1
    service_0_5_4  free_load_conservation_912  2
    service_0_5_5  unique_nonzero_owner_399  1
    service_0_5_5  service_visit_def_911  1
    service_0_5_5  free_load_conservation_912  3
    service_0_5_6  unique_nonzero_owner_400  1
    service_0_5_6  service_visit_def_911  1
    service_0_5_6  free_load_conservation_912  4
    service_0_5_7  unique_nonzero_owner_401  1
    service_0_5_7  service_visit_def_911  1
    service_0_5_7  free_load_conservation_912  5
    service_0_5_8  unique_nonzero_owner_402  1
    service_0_5_8  service_visit_def_911  1
    service_0_5_8  free_load_conservation_912  6
    service_0_5_9  unique_nonzero_owner_403  1
    service_0_5_9  service_visit_def_911  1
    service_0_5_9  free_load_conservation_912  7
    service_0_5_10  unique_nonzero_owner_404  1
    service_0_5_10  service_visit_def_911  1
    service_0_5_10  free_load_conservation_912  8
    service_0_5_11  unique_nonzero_owner_405  1
    service_0_5_11  service_visit_def_911  1
    service_0_5_11  free_load_conservation_912  9
    service_0_5_12  unique_nonzero_owner_406  1
    service_0_5_12  service_visit_def_911  1
    service_0_5_12  free_load_conservation_912  10
    service_0_5_13  unique_nonzero_owner_407  1
    service_0_5_13  service_visit_def_911  1
    service_0_5_13  free_load_conservation_912  11
    service_0_5_14  unique_nonzero_owner_408  1
    service_0_5_14  service_visit_def_911  1
    service_0_5_14  free_load_conservation_912  12
    service_0_5_15  unique_nonzero_owner_409  1
    service_0_5_15  service_visit_def_911  1
    service_0_5_15  free_load_conservation_912  13
    service_0_5_16  unique_nonzero_owner_410  1
    service_0_5_16  service_visit_def_911  1
    service_0_5_16  free_load_conservation_912  14
    service_1_5_0  unique_nonzero_owner_395  1
    service_1_5_0  service_visit_def_1341  1
    service_1_5_0  free_load_conservation_1342  -2
    service_1_5_0  original_T_including_depot_unload_1359  240
    service_1_5_1  unique_nonzero_owner_396  1
    service_1_5_1  service_visit_def_1341  1
    service_1_5_1  free_load_conservation_1342  -1
    service_1_5_1  original_T_including_depot_unload_1359  120
    service_1_5_3  unique_nonzero_owner_397  1
    service_1_5_3  service_visit_def_1341  1
    service_1_5_3  free_load_conservation_1342  1
    service_1_5_4  unique_nonzero_owner_398  1
    service_1_5_4  service_visit_def_1341  1
    service_1_5_4  free_load_conservation_1342  2
    service_1_5_5  unique_nonzero_owner_399  1
    service_1_5_5  service_visit_def_1341  1
    service_1_5_5  free_load_conservation_1342  3
    service_1_5_6  unique_nonzero_owner_400  1
    service_1_5_6  service_visit_def_1341  1
    service_1_5_6  free_load_conservation_1342  4
    service_1_5_7  unique_nonzero_owner_401  1
    service_1_5_7  service_visit_def_1341  1
    service_1_5_7  free_load_conservation_1342  5
    service_1_5_8  unique_nonzero_owner_402  1
    service_1_5_8  service_visit_def_1341  1
    service_1_5_8  free_load_conservation_1342  6
    service_1_5_9  unique_nonzero_owner_403  1
    service_1_5_9  service_visit_def_1341  1
    service_1_5_9  free_load_conservation_1342  7
    service_1_5_10  unique_nonzero_owner_404  1
    service_1_5_10  service_visit_def_1341  1
    service_1_5_10  free_load_conservation_1342  8
    service_1_5_11  unique_nonzero_owner_405  1
    service_1_5_11  service_visit_def_1341  1
    service_1_5_11  free_load_conservation_1342  9
    service_1_5_12  unique_nonzero_owner_406  1
    service_1_5_12  service_visit_def_1341  1
    service_1_5_12  free_load_conservation_1342  10
    service_1_5_13  unique_nonzero_owner_407  1
    service_1_5_13  service_visit_def_1341  1
    service_1_5_13  free_load_conservation_1342  11
    service_1_5_14  unique_nonzero_owner_408  1
    service_1_5_14  service_visit_def_1341  1
    service_1_5_14  free_load_conservation_1342  12
    service_1_5_15  unique_nonzero_owner_409  1
    service_1_5_15  service_visit_def_1341  1
    service_1_5_15  free_load_conservation_1342  13
    service_1_5_16  unique_nonzero_owner_410  1
    service_1_5_16  service_visit_def_1341  1
    service_1_5_16  free_load_conservation_1342  14
    service_2_5_0  unique_nonzero_owner_395  1
    service_2_5_0  service_visit_def_1770  1
    service_2_5_0  free_load_conservation_1771  -2
    service_2_5_0  original_T_including_depot_unload_1788  240
    service_2_5_1  unique_nonzero_owner_396  1
    service_2_5_1  service_visit_def_1770  1
    service_2_5_1  free_load_conservation_1771  -1
    service_2_5_1  original_T_including_depot_unload_1788  120
    service_2_5_3  unique_nonzero_owner_397  1
    service_2_5_3  service_visit_def_1770  1
    service_2_5_3  free_load_conservation_1771  1
    service_2_5_4  unique_nonzero_owner_398  1
    service_2_5_4  service_visit_def_1770  1
    service_2_5_4  free_load_conservation_1771  2
    service_2_5_5  unique_nonzero_owner_399  1
    service_2_5_5  service_visit_def_1770  1
    service_2_5_5  free_load_conservation_1771  3
    service_2_5_6  unique_nonzero_owner_400  1
    service_2_5_6  service_visit_def_1770  1
    service_2_5_6  free_load_conservation_1771  4
    service_2_5_7  unique_nonzero_owner_401  1
    service_2_5_7  service_visit_def_1770  1
    service_2_5_7  free_load_conservation_1771  5
    service_2_5_8  unique_nonzero_owner_402  1
    service_2_5_8  service_visit_def_1770  1
    service_2_5_8  free_load_conservation_1771  6
    service_2_5_9  unique_nonzero_owner_403  1
    service_2_5_9  service_visit_def_1770  1
    service_2_5_9  free_load_conservation_1771  7
    service_2_5_10  unique_nonzero_owner_404  1
    service_2_5_10  service_visit_def_1770  1
    service_2_5_10  free_load_conservation_1771  8
    service_2_5_11  unique_nonzero_owner_405  1
    service_2_5_11  service_visit_def_1770  1
    service_2_5_11  free_load_conservation_1771  9
    service_2_5_12  unique_nonzero_owner_406  1
    service_2_5_12  service_visit_def_1770  1
    service_2_5_12  free_load_conservation_1771  10
    service_2_5_13  unique_nonzero_owner_407  1
    service_2_5_13  service_visit_def_1770  1
    service_2_5_13  free_load_conservation_1771  11
    service_2_5_14  unique_nonzero_owner_408  1
    service_2_5_14  service_visit_def_1770  1
    service_2_5_14  free_load_conservation_1771  12
    service_2_5_15  unique_nonzero_owner_409  1
    service_2_5_15  service_visit_def_1770  1
    service_2_5_15  free_load_conservation_1771  13
    service_2_5_16  unique_nonzero_owner_410  1
    service_2_5_16  service_visit_def_1770  1
    service_2_5_16  free_load_conservation_1771  14
    service_0_32_1  unique_nonzero_owner_411  1
    service_0_32_1  service_visit_def_917  1
    service_0_32_1  free_load_conservation_918  1
    service_0_32_2  unique_nonzero_owner_412  1
    service_0_32_2  service_visit_def_917  1
    service_0_32_2  free_load_conservation_918  2
    service_0_32_3  unique_nonzero_owner_413  1
    service_0_32_3  service_visit_def_917  1
    service_0_32_3  free_load_conservation_918  3
    service_0_32_4  unique_nonzero_owner_414  1
    service_0_32_4  service_visit_def_917  1
    service_0_32_4  free_load_conservation_918  4
    service_0_32_5  unique_nonzero_owner_415  1
    service_0_32_5  service_visit_def_917  1
    service_0_32_5  free_load_conservation_918  5
    service_0_32_6  unique_nonzero_owner_416  1
    service_0_32_6  service_visit_def_917  1
    service_0_32_6  free_load_conservation_918  6
    service_0_32_7  unique_nonzero_owner_417  1
    service_0_32_7  service_visit_def_917  1
    service_0_32_7  free_load_conservation_918  7
    service_0_32_8  unique_nonzero_owner_418  1
    service_0_32_8  service_visit_def_917  1
    service_0_32_8  free_load_conservation_918  8
    service_0_32_9  unique_nonzero_owner_419  1
    service_0_32_9  service_visit_def_917  1
    service_0_32_9  free_load_conservation_918  9
    service_0_32_10  unique_nonzero_owner_420  1
    service_0_32_10  service_visit_def_917  1
    service_0_32_10  free_load_conservation_918  10
    service_0_32_11  unique_nonzero_owner_421  1
    service_0_32_11  service_visit_def_917  1
    service_0_32_11  free_load_conservation_918  11
    service_0_32_12  unique_nonzero_owner_422  1
    service_0_32_12  service_visit_def_917  1
    service_0_32_12  free_load_conservation_918  12
    service_1_32_1  unique_nonzero_owner_411  1
    service_1_32_1  service_visit_def_1347  1
    service_1_32_1  free_load_conservation_1348  1
    service_1_32_2  unique_nonzero_owner_412  1
    service_1_32_2  service_visit_def_1347  1
    service_1_32_2  free_load_conservation_1348  2
    service_1_32_3  unique_nonzero_owner_413  1
    service_1_32_3  service_visit_def_1347  1
    service_1_32_3  free_load_conservation_1348  3
    service_1_32_4  unique_nonzero_owner_414  1
    service_1_32_4  service_visit_def_1347  1
    service_1_32_4  free_load_conservation_1348  4
    service_1_32_5  unique_nonzero_owner_415  1
    service_1_32_5  service_visit_def_1347  1
    service_1_32_5  free_load_conservation_1348  5
    service_1_32_6  unique_nonzero_owner_416  1
    service_1_32_6  service_visit_def_1347  1
    service_1_32_6  free_load_conservation_1348  6
    service_1_32_7  unique_nonzero_owner_417  1
    service_1_32_7  service_visit_def_1347  1
    service_1_32_7  free_load_conservation_1348  7
    service_1_32_8  unique_nonzero_owner_418  1
    service_1_32_8  service_visit_def_1347  1
    service_1_32_8  free_load_conservation_1348  8
    service_1_32_9  unique_nonzero_owner_419  1
    service_1_32_9  service_visit_def_1347  1
    service_1_32_9  free_load_conservation_1348  9
    service_1_32_10  unique_nonzero_owner_420  1
    service_1_32_10  service_visit_def_1347  1
    service_1_32_10  free_load_conservation_1348  10
    service_1_32_11  unique_nonzero_owner_421  1
    service_1_32_11  service_visit_def_1347  1
    service_1_32_11  free_load_conservation_1348  11
    service_1_32_12  unique_nonzero_owner_422  1
    service_1_32_12  service_visit_def_1347  1
    service_1_32_12  free_load_conservation_1348  12
    service_2_32_1  unique_nonzero_owner_411  1
    service_2_32_1  service_visit_def_1776  1
    service_2_32_1  free_load_conservation_1777  1
    service_2_32_2  unique_nonzero_owner_412  1
    service_2_32_2  service_visit_def_1776  1
    service_2_32_2  free_load_conservation_1777  2
    service_2_32_3  unique_nonzero_owner_413  1
    service_2_32_3  service_visit_def_1776  1
    service_2_32_3  free_load_conservation_1777  3
    service_2_32_4  unique_nonzero_owner_414  1
    service_2_32_4  service_visit_def_1776  1
    service_2_32_4  free_load_conservation_1777  4
    service_2_32_5  unique_nonzero_owner_415  1
    service_2_32_5  service_visit_def_1776  1
    service_2_32_5  free_load_conservation_1777  5
    service_2_32_6  unique_nonzero_owner_416  1
    service_2_32_6  service_visit_def_1776  1
    service_2_32_6  free_load_conservation_1777  6
    service_2_32_7  unique_nonzero_owner_417  1
    service_2_32_7  service_visit_def_1776  1
    service_2_32_7  free_load_conservation_1777  7
    service_2_32_8  unique_nonzero_owner_418  1
    service_2_32_8  service_visit_def_1776  1
    service_2_32_8  free_load_conservation_1777  8
    service_2_32_9  unique_nonzero_owner_419  1
    service_2_32_9  service_visit_def_1776  1
    service_2_32_9  free_load_conservation_1777  9
    service_2_32_10  unique_nonzero_owner_420  1
    service_2_32_10  service_visit_def_1776  1
    service_2_32_10  free_load_conservation_1777  10
    service_2_32_11  unique_nonzero_owner_421  1
    service_2_32_11  service_visit_def_1776  1
    service_2_32_11  free_load_conservation_1777  11
    service_2_32_12  unique_nonzero_owner_422  1
    service_2_32_12  service_visit_def_1776  1
    service_2_32_12  free_load_conservation_1777  12
    service_0_3_0  unique_nonzero_owner_423  1
    service_0_3_0  service_visit_def_923  1
    service_0_3_0  free_load_conservation_924  -12
    service_0_3_0  original_T_including_depot_unload_930  1440
    service_0_3_1  unique_nonzero_owner_424  1
    service_0_3_1  service_visit_def_923  1
    service_0_3_1  free_load_conservation_924  -11
    service_0_3_1  original_T_including_depot_unload_930  1320
    service_0_3_2  unique_nonzero_owner_425  1
    service_0_3_2  service_visit_def_923  1
    service_0_3_2  free_load_conservation_924  -10
    service_0_3_2  original_T_including_depot_unload_930  1200
    service_0_3_3  unique_nonzero_owner_426  1
    service_0_3_3  service_visit_def_923  1
    service_0_3_3  free_load_conservation_924  -9
    service_0_3_3  original_T_including_depot_unload_930  1080
    service_0_3_4  unique_nonzero_owner_427  1
    service_0_3_4  service_visit_def_923  1
    service_0_3_4  free_load_conservation_924  -8
    service_0_3_4  original_T_including_depot_unload_930  960
    service_0_3_5  unique_nonzero_owner_428  1
    service_0_3_5  service_visit_def_923  1
    service_0_3_5  free_load_conservation_924  -7
    service_0_3_5  original_T_including_depot_unload_930  840
    service_0_3_6  unique_nonzero_owner_429  1
    service_0_3_6  service_visit_def_923  1
    service_0_3_6  free_load_conservation_924  -6
    service_0_3_6  original_T_including_depot_unload_930  720
    service_0_3_7  unique_nonzero_owner_430  1
    service_0_3_7  service_visit_def_923  1
    service_0_3_7  free_load_conservation_924  -5
    service_0_3_7  original_T_including_depot_unload_930  600
    service_0_3_8  unique_nonzero_owner_431  1
    service_0_3_8  service_visit_def_923  1
    service_0_3_8  free_load_conservation_924  -4
    service_0_3_8  original_T_including_depot_unload_930  480
    service_0_3_9  unique_nonzero_owner_432  1
    service_0_3_9  service_visit_def_923  1
    service_0_3_9  free_load_conservation_924  -3
    service_0_3_9  original_T_including_depot_unload_930  360
    service_0_3_10  unique_nonzero_owner_433  1
    service_0_3_10  service_visit_def_923  1
    service_0_3_10  free_load_conservation_924  -2
    service_0_3_10  original_T_including_depot_unload_930  240
    service_0_3_11  unique_nonzero_owner_434  1
    service_0_3_11  service_visit_def_923  1
    service_0_3_11  free_load_conservation_924  -1
    service_0_3_11  original_T_including_depot_unload_930  120
    service_0_3_13  unique_nonzero_owner_435  1
    service_0_3_13  service_visit_def_923  1
    service_0_3_13  free_load_conservation_924  1
    service_0_3_14  unique_nonzero_owner_436  1
    service_0_3_14  service_visit_def_923  1
    service_0_3_14  free_load_conservation_924  2
    service_0_3_15  unique_nonzero_owner_437  1
    service_0_3_15  service_visit_def_923  1
    service_0_3_15  free_load_conservation_924  3
    service_0_3_16  unique_nonzero_owner_438  1
    service_0_3_16  service_visit_def_923  1
    service_0_3_16  free_load_conservation_924  4
    service_0_3_17  unique_nonzero_owner_439  1
    service_0_3_17  service_visit_def_923  1
    service_0_3_17  free_load_conservation_924  5
    service_1_3_0  unique_nonzero_owner_423  1
    service_1_3_0  service_visit_def_1353  1
    service_1_3_0  free_load_conservation_1354  -12
    service_1_3_0  original_T_including_depot_unload_1359  1440
    service_1_3_1  unique_nonzero_owner_424  1
    service_1_3_1  service_visit_def_1353  1
    service_1_3_1  free_load_conservation_1354  -11
    service_1_3_1  original_T_including_depot_unload_1359  1320
    service_1_3_2  unique_nonzero_owner_425  1
    service_1_3_2  service_visit_def_1353  1
    service_1_3_2  free_load_conservation_1354  -10
    service_1_3_2  original_T_including_depot_unload_1359  1200
    service_1_3_3  unique_nonzero_owner_426  1
    service_1_3_3  service_visit_def_1353  1
    service_1_3_3  free_load_conservation_1354  -9
    service_1_3_3  original_T_including_depot_unload_1359  1080
    service_1_3_4  unique_nonzero_owner_427  1
    service_1_3_4  service_visit_def_1353  1
    service_1_3_4  free_load_conservation_1354  -8
    service_1_3_4  original_T_including_depot_unload_1359  960
    service_1_3_5  unique_nonzero_owner_428  1
    service_1_3_5  service_visit_def_1353  1
    service_1_3_5  free_load_conservation_1354  -7
    service_1_3_5  original_T_including_depot_unload_1359  840
    service_1_3_6  unique_nonzero_owner_429  1
    service_1_3_6  service_visit_def_1353  1
    service_1_3_6  free_load_conservation_1354  -6
    service_1_3_6  original_T_including_depot_unload_1359  720
    service_1_3_7  unique_nonzero_owner_430  1
    service_1_3_7  service_visit_def_1353  1
    service_1_3_7  free_load_conservation_1354  -5
    service_1_3_7  original_T_including_depot_unload_1359  600
    service_1_3_8  unique_nonzero_owner_431  1
    service_1_3_8  service_visit_def_1353  1
    service_1_3_8  free_load_conservation_1354  -4
    service_1_3_8  original_T_including_depot_unload_1359  480
    service_1_3_9  unique_nonzero_owner_432  1
    service_1_3_9  service_visit_def_1353  1
    service_1_3_9  free_load_conservation_1354  -3
    service_1_3_9  original_T_including_depot_unload_1359  360
    service_1_3_10  unique_nonzero_owner_433  1
    service_1_3_10  service_visit_def_1353  1
    service_1_3_10  free_load_conservation_1354  -2
    service_1_3_10  original_T_including_depot_unload_1359  240
    service_1_3_11  unique_nonzero_owner_434  1
    service_1_3_11  service_visit_def_1353  1
    service_1_3_11  free_load_conservation_1354  -1
    service_1_3_11  original_T_including_depot_unload_1359  120
    service_1_3_13  unique_nonzero_owner_435  1
    service_1_3_13  service_visit_def_1353  1
    service_1_3_13  free_load_conservation_1354  1
    service_1_3_14  unique_nonzero_owner_436  1
    service_1_3_14  service_visit_def_1353  1
    service_1_3_14  free_load_conservation_1354  2
    service_1_3_15  unique_nonzero_owner_437  1
    service_1_3_15  service_visit_def_1353  1
    service_1_3_15  free_load_conservation_1354  3
    service_1_3_16  unique_nonzero_owner_438  1
    service_1_3_16  service_visit_def_1353  1
    service_1_3_16  free_load_conservation_1354  4
    service_1_3_17  unique_nonzero_owner_439  1
    service_1_3_17  service_visit_def_1353  1
    service_1_3_17  free_load_conservation_1354  5
    service_2_3_0  unique_nonzero_owner_423  1
    service_2_3_0  service_visit_def_1782  1
    service_2_3_0  free_load_conservation_1783  -12
    service_2_3_0  original_T_including_depot_unload_1788  1440
    service_2_3_1  unique_nonzero_owner_424  1
    service_2_3_1  service_visit_def_1782  1
    service_2_3_1  free_load_conservation_1783  -11
    service_2_3_1  original_T_including_depot_unload_1788  1320
    service_2_3_2  unique_nonzero_owner_425  1
    service_2_3_2  service_visit_def_1782  1
    service_2_3_2  free_load_conservation_1783  -10
    service_2_3_2  original_T_including_depot_unload_1788  1200
    service_2_3_3  unique_nonzero_owner_426  1
    service_2_3_3  service_visit_def_1782  1
    service_2_3_3  free_load_conservation_1783  -9
    service_2_3_3  original_T_including_depot_unload_1788  1080
    service_2_3_4  unique_nonzero_owner_427  1
    service_2_3_4  service_visit_def_1782  1
    service_2_3_4  free_load_conservation_1783  -8
    service_2_3_4  original_T_including_depot_unload_1788  960
    service_2_3_5  unique_nonzero_owner_428  1
    service_2_3_5  service_visit_def_1782  1
    service_2_3_5  free_load_conservation_1783  -7
    service_2_3_5  original_T_including_depot_unload_1788  840
    service_2_3_6  unique_nonzero_owner_429  1
    service_2_3_6  service_visit_def_1782  1
    service_2_3_6  free_load_conservation_1783  -6
    service_2_3_6  original_T_including_depot_unload_1788  720
    service_2_3_7  unique_nonzero_owner_430  1
    service_2_3_7  service_visit_def_1782  1
    service_2_3_7  free_load_conservation_1783  -5
    service_2_3_7  original_T_including_depot_unload_1788  600
    service_2_3_8  unique_nonzero_owner_431  1
    service_2_3_8  service_visit_def_1782  1
    service_2_3_8  free_load_conservation_1783  -4
    service_2_3_8  original_T_including_depot_unload_1788  480
    service_2_3_9  unique_nonzero_owner_432  1
    service_2_3_9  service_visit_def_1782  1
    service_2_3_9  free_load_conservation_1783  -3
    service_2_3_9  original_T_including_depot_unload_1788  360
    service_2_3_10  unique_nonzero_owner_433  1
    service_2_3_10  service_visit_def_1782  1
    service_2_3_10  free_load_conservation_1783  -2
    service_2_3_10  original_T_including_depot_unload_1788  240
    service_2_3_11  unique_nonzero_owner_434  1
    service_2_3_11  service_visit_def_1782  1
    service_2_3_11  free_load_conservation_1783  -1
    service_2_3_11  original_T_including_depot_unload_1788  120
    service_2_3_13  unique_nonzero_owner_435  1
    service_2_3_13  service_visit_def_1782  1
    service_2_3_13  free_load_conservation_1783  1
    service_2_3_14  unique_nonzero_owner_436  1
    service_2_3_14  service_visit_def_1782  1
    service_2_3_14  free_load_conservation_1783  2
    service_2_3_15  unique_nonzero_owner_437  1
    service_2_3_15  service_visit_def_1782  1
    service_2_3_15  free_load_conservation_1783  3
    service_2_3_16  unique_nonzero_owner_438  1
    service_2_3_16  service_visit_def_1782  1
    service_2_3_16  free_load_conservation_1783  4
    service_2_3_17  unique_nonzero_owner_439  1
    service_2_3_17  service_visit_def_1782  1
    service_2_3_17  free_load_conservation_1783  5
    MARKER    'MARKER'                 'INTEND'
    visit_0_1  out_degree_835  -1
    visit_0_1  in_degree_836  -1
    visit_0_1  order_active_lb_837  -1
    visit_0_1  order_active_ub_838  -14
    order_0_1  connected_order_arc_457  -1
    order_0_1  connected_order_arc_459  -1
    order_0_1  connected_order_arc_461  -1
    order_0_1  connected_order_arc_463  -1
    order_0_1  connected_order_arc_465  -1
    order_0_1  connected_order_arc_467  -1
    order_0_1  connected_order_arc_469  -1
    order_0_1  connected_order_arc_471  -1
    order_0_1  connected_order_arc_473  -1
    order_0_1  connected_order_arc_475  -1
    order_0_1  connected_order_arc_477  -1
    order_0_1  connected_order_arc_479  -1
    order_0_1  connected_order_arc_481  -1
    order_0_1  connected_order_arc_484  1
    order_0_1  connected_order_arc_511  1
    order_0_1  connected_order_arc_538  1
    order_0_1  connected_order_arc_565  1
    order_0_1  connected_order_arc_592  1
    order_0_1  connected_order_arc_619  1
    order_0_1  connected_order_arc_646  1
    order_0_1  connected_order_arc_673  1
    order_0_1  connected_order_arc_700  1
    order_0_1  connected_order_arc_727  1
    order_0_1  connected_order_arc_754  1
    order_0_1  connected_order_arc_781  1
    order_0_1  connected_order_arc_808  1
    order_0_1  order_active_lb_837  1
    order_0_1  order_active_ub_838  1
    order_0_1  fixed_segment_relative_order_925  -1
    visit_0_2  out_degree_842  -1
    visit_0_2  in_degree_843  -1
    visit_0_2  order_active_lb_844  -1
    visit_0_2  order_active_ub_845  -14
    order_0_2  connected_order_arc_457  1
    order_0_2  connected_order_arc_484  -1
    order_0_2  connected_order_arc_486  -1
    order_0_2  connected_order_arc_488  -1
    order_0_2  connected_order_arc_490  -1
    order_0_2  connected_order_arc_492  -1
    order_0_2  connected_order_arc_494  -1
    order_0_2  connected_order_arc_496  -1
    order_0_2  connected_order_arc_498  -1
    order_0_2  connected_order_arc_500  -1
    order_0_2  connected_order_arc_502  -1
    order_0_2  connected_order_arc_504  -1
    order_0_2  connected_order_arc_506  -1
    order_0_2  connected_order_arc_508  -1
    order_0_2  connected_order_arc_513  1
    order_0_2  connected_order_arc_540  1
    order_0_2  connected_order_arc_567  1
    order_0_2  connected_order_arc_594  1
    order_0_2  connected_order_arc_621  1
    order_0_2  connected_order_arc_648  1
    order_0_2  connected_order_arc_675  1
    order_0_2  connected_order_arc_702  1
    order_0_2  connected_order_arc_729  1
    order_0_2  connected_order_arc_756  1
    order_0_2  connected_order_arc_783  1
    order_0_2  connected_order_arc_810  1
    order_0_2  order_active_lb_844  1
    order_0_2  order_active_ub_845  1
    order_0_2  fixed_segment_relative_order_925  1
    order_0_2  fixed_segment_relative_order_926  -1
    visit_0_3  out_degree_849  -1
    visit_0_3  in_degree_850  -1
    visit_0_3  order_active_lb_851  -1
    visit_0_3  order_active_ub_852  -14
    order_0_3  connected_order_arc_459  1
    order_0_3  connected_order_arc_486  1
    order_0_3  connected_order_arc_511  -1
    order_0_3  connected_order_arc_513  -1
    order_0_3  connected_order_arc_515  -1
    order_0_3  connected_order_arc_517  -1
    order_0_3  connected_order_arc_519  -1
    order_0_3  connected_order_arc_521  -1
    order_0_3  connected_order_arc_523  -1
    order_0_3  connected_order_arc_525  -1
    order_0_3  connected_order_arc_527  -1
    order_0_3  connected_order_arc_529  -1
    order_0_3  connected_order_arc_531  -1
    order_0_3  connected_order_arc_533  -1
    order_0_3  connected_order_arc_535  -1
    order_0_3  connected_order_arc_542  1
    order_0_3  connected_order_arc_569  1
    order_0_3  connected_order_arc_596  1
    order_0_3  connected_order_arc_623  1
    order_0_3  connected_order_arc_650  1
    order_0_3  connected_order_arc_677  1
    order_0_3  connected_order_arc_704  1
    order_0_3  connected_order_arc_731  1
    order_0_3  connected_order_arc_758  1
    order_0_3  connected_order_arc_785  1
    order_0_3  connected_order_arc_812  1
    order_0_3  order_active_lb_851  1
    order_0_3  order_active_ub_852  1
    order_0_3  fixed_segment_relative_order_926  1
    order_0_3  fixed_segment_relative_order_927  -1
    visit_0_4  out_degree_856  -1
    visit_0_4  in_degree_857  -1
    visit_0_4  order_active_lb_858  -1
    visit_0_4  order_active_ub_859  -14
    order_0_4  connected_order_arc_461  1
    order_0_4  connected_order_arc_488  1
    order_0_4  connected_order_arc_515  1
    order_0_4  connected_order_arc_538  -1
    order_0_4  connected_order_arc_540  -1
    order_0_4  connected_order_arc_542  -1
    order_0_4  connected_order_arc_544  -1
    order_0_4  connected_order_arc_546  -1
    order_0_4  connected_order_arc_548  -1
    order_0_4  connected_order_arc_550  -1
    order_0_4  connected_order_arc_552  -1
    order_0_4  connected_order_arc_554  -1
    order_0_4  connected_order_arc_556  -1
    order_0_4  connected_order_arc_558  -1
    order_0_4  connected_order_arc_560  -1
    order_0_4  connected_order_arc_562  -1
    order_0_4  connected_order_arc_571  1
    order_0_4  connected_order_arc_598  1
    order_0_4  connected_order_arc_625  1
    order_0_4  connected_order_arc_652  1
    order_0_4  connected_order_arc_679  1
    order_0_4  connected_order_arc_706  1
    order_0_4  connected_order_arc_733  1
    order_0_4  connected_order_arc_760  1
    order_0_4  connected_order_arc_787  1
    order_0_4  connected_order_arc_814  1
    order_0_4  order_active_lb_858  1
    order_0_4  order_active_ub_859  1
    order_0_4  fixed_segment_relative_order_927  1
    order_0_4  fixed_segment_relative_order_928  -1
    visit_0_5  out_degree_863  -1
    visit_0_5  in_degree_864  -1
    visit_0_5  order_active_lb_865  -1
    visit_0_5  order_active_ub_866  -14
    order_0_5  connected_order_arc_463  1
    order_0_5  connected_order_arc_490  1
    order_0_5  connected_order_arc_517  1
    order_0_5  connected_order_arc_544  1
    order_0_5  connected_order_arc_565  -1
    order_0_5  connected_order_arc_567  -1
    order_0_5  connected_order_arc_569  -1
    order_0_5  connected_order_arc_571  -1
    order_0_5  connected_order_arc_573  -1
    order_0_5  connected_order_arc_575  -1
    order_0_5  connected_order_arc_577  -1
    order_0_5  connected_order_arc_579  -1
    order_0_5  connected_order_arc_581  -1
    order_0_5  connected_order_arc_583  -1
    order_0_5  connected_order_arc_585  -1
    order_0_5  connected_order_arc_587  -1
    order_0_5  connected_order_arc_589  -1
    order_0_5  connected_order_arc_600  1
    order_0_5  connected_order_arc_627  1
    order_0_5  connected_order_arc_654  1
    order_0_5  connected_order_arc_681  1
    order_0_5  connected_order_arc_708  1
    order_0_5  connected_order_arc_735  1
    order_0_5  connected_order_arc_762  1
    order_0_5  connected_order_arc_789  1
    order_0_5  connected_order_arc_816  1
    order_0_5  order_active_lb_865  1
    order_0_5  order_active_ub_866  1
    order_0_5  fixed_segment_relative_order_928  1
    order_0_5  fixed_segment_relative_order_929  -1
    visit_0_6  out_degree_870  -1
    visit_0_6  in_degree_871  -1
    visit_0_6  order_active_lb_872  -1
    visit_0_6  order_active_ub_873  -14
    order_0_6  connected_order_arc_465  1
    order_0_6  connected_order_arc_492  1
    order_0_6  connected_order_arc_519  1
    order_0_6  connected_order_arc_546  1
    order_0_6  connected_order_arc_573  1
    order_0_6  connected_order_arc_592  -1
    order_0_6  connected_order_arc_594  -1
    order_0_6  connected_order_arc_596  -1
    order_0_6  connected_order_arc_598  -1
    order_0_6  connected_order_arc_600  -1
    order_0_6  connected_order_arc_602  -1
    order_0_6  connected_order_arc_604  -1
    order_0_6  connected_order_arc_606  -1
    order_0_6  connected_order_arc_608  -1
    order_0_6  connected_order_arc_610  -1
    order_0_6  connected_order_arc_612  -1
    order_0_6  connected_order_arc_614  -1
    order_0_6  connected_order_arc_616  -1
    order_0_6  connected_order_arc_629  1
    order_0_6  connected_order_arc_656  1
    order_0_6  connected_order_arc_683  1
    order_0_6  connected_order_arc_710  1
    order_0_6  connected_order_arc_737  1
    order_0_6  connected_order_arc_764  1
    order_0_6  connected_order_arc_791  1
    order_0_6  connected_order_arc_818  1
    order_0_6  order_active_lb_872  1
    order_0_6  order_active_ub_873  1
    order_0_6  fixed_segment_relative_order_929  1
    visit_0_17  out_degree_877  -1
    visit_0_17  in_degree_878  -1
    visit_0_17  order_active_lb_879  -1
    visit_0_17  order_active_ub_880  -14
    visit_0_17  service_visit_def_881  -1
    order_0_17  connected_order_arc_467  1
    order_0_17  connected_order_arc_494  1
    order_0_17  connected_order_arc_521  1
    order_0_17  connected_order_arc_548  1
    order_0_17  connected_order_arc_575  1
    order_0_17  connected_order_arc_602  1
    order_0_17  connected_order_arc_619  -1
    order_0_17  connected_order_arc_621  -1
    order_0_17  connected_order_arc_623  -1
    order_0_17  connected_order_arc_625  -1
    order_0_17  connected_order_arc_627  -1
    order_0_17  connected_order_arc_629  -1
    order_0_17  connected_order_arc_631  -1
    order_0_17  connected_order_arc_633  -1
    order_0_17  connected_order_arc_635  -1
    order_0_17  connected_order_arc_637  -1
    order_0_17  connected_order_arc_639  -1
    order_0_17  connected_order_arc_641  -1
    order_0_17  connected_order_arc_643  -1
    order_0_17  connected_order_arc_658  1
    order_0_17  connected_order_arc_685  1
    order_0_17  connected_order_arc_712  1
    order_0_17  connected_order_arc_739  1
    order_0_17  connected_order_arc_766  1
    order_0_17  connected_order_arc_793  1
    order_0_17  connected_order_arc_820  1
    order_0_17  order_active_lb_879  1
    order_0_17  order_active_ub_880  1
    visit_0_18  out_degree_883  -1
    visit_0_18  in_degree_884  -1
    visit_0_18  order_active_lb_885  -1
    visit_0_18  order_active_ub_886  -14
    visit_0_18  service_visit_def_887  -1
    order_0_18  connected_order_arc_469  1
    order_0_18  connected_order_arc_496  1
    order_0_18  connected_order_arc_523  1
    order_0_18  connected_order_arc_550  1
    order_0_18  connected_order_arc_577  1
    order_0_18  connected_order_arc_604  1
    order_0_18  connected_order_arc_631  1
    order_0_18  connected_order_arc_646  -1
    order_0_18  connected_order_arc_648  -1
    order_0_18  connected_order_arc_650  -1
    order_0_18  connected_order_arc_652  -1
    order_0_18  connected_order_arc_654  -1
    order_0_18  connected_order_arc_656  -1
    order_0_18  connected_order_arc_658  -1
    order_0_18  connected_order_arc_660  -1
    order_0_18  connected_order_arc_662  -1
    order_0_18  connected_order_arc_664  -1
    order_0_18  connected_order_arc_666  -1
    order_0_18  connected_order_arc_668  -1
    order_0_18  connected_order_arc_670  -1
    order_0_18  connected_order_arc_687  1
    order_0_18  connected_order_arc_714  1
    order_0_18  connected_order_arc_741  1
    order_0_18  connected_order_arc_768  1
    order_0_18  connected_order_arc_795  1
    order_0_18  connected_order_arc_822  1
    order_0_18  order_active_lb_885  1
    order_0_18  order_active_ub_886  1
    visit_0_19  out_degree_889  -1
    visit_0_19  in_degree_890  -1
    visit_0_19  order_active_lb_891  -1
    visit_0_19  order_active_ub_892  -14
    visit_0_19  service_visit_def_893  -1
    order_0_19  connected_order_arc_471  1
    order_0_19  connected_order_arc_498  1
    order_0_19  connected_order_arc_525  1
    order_0_19  connected_order_arc_552  1
    order_0_19  connected_order_arc_579  1
    order_0_19  connected_order_arc_606  1
    order_0_19  connected_order_arc_633  1
    order_0_19  connected_order_arc_660  1
    order_0_19  connected_order_arc_673  -1
    order_0_19  connected_order_arc_675  -1
    order_0_19  connected_order_arc_677  -1
    order_0_19  connected_order_arc_679  -1
    order_0_19  connected_order_arc_681  -1
    order_0_19  connected_order_arc_683  -1
    order_0_19  connected_order_arc_685  -1
    order_0_19  connected_order_arc_687  -1
    order_0_19  connected_order_arc_689  -1
    order_0_19  connected_order_arc_691  -1
    order_0_19  connected_order_arc_693  -1
    order_0_19  connected_order_arc_695  -1
    order_0_19  connected_order_arc_697  -1
    order_0_19  connected_order_arc_716  1
    order_0_19  connected_order_arc_743  1
    order_0_19  connected_order_arc_770  1
    order_0_19  connected_order_arc_797  1
    order_0_19  connected_order_arc_824  1
    order_0_19  order_active_lb_891  1
    order_0_19  order_active_ub_892  1
    visit_0_20  out_degree_895  -1
    visit_0_20  in_degree_896  -1
    visit_0_20  order_active_lb_897  -1
    visit_0_20  order_active_ub_898  -14
    visit_0_20  service_visit_def_899  -1
    order_0_20  connected_order_arc_473  1
    order_0_20  connected_order_arc_500  1
    order_0_20  connected_order_arc_527  1
    order_0_20  connected_order_arc_554  1
    order_0_20  connected_order_arc_581  1
    order_0_20  connected_order_arc_608  1
    order_0_20  connected_order_arc_635  1
    order_0_20  connected_order_arc_662  1
    order_0_20  connected_order_arc_689  1
    order_0_20  connected_order_arc_700  -1
    order_0_20  connected_order_arc_702  -1
    order_0_20  connected_order_arc_704  -1
    order_0_20  connected_order_arc_706  -1
    order_0_20  connected_order_arc_708  -1
    order_0_20  connected_order_arc_710  -1
    order_0_20  connected_order_arc_712  -1
    order_0_20  connected_order_arc_714  -1
    order_0_20  connected_order_arc_716  -1
    order_0_20  connected_order_arc_718  -1
    order_0_20  connected_order_arc_720  -1
    order_0_20  connected_order_arc_722  -1
    order_0_20  connected_order_arc_724  -1
    order_0_20  connected_order_arc_745  1
    order_0_20  connected_order_arc_772  1
    order_0_20  connected_order_arc_799  1
    order_0_20  connected_order_arc_826  1
    order_0_20  order_active_lb_897  1
    order_0_20  order_active_ub_898  1
    visit_0_21  out_degree_901  -1
    visit_0_21  in_degree_902  -1
    visit_0_21  order_active_lb_903  -1
    visit_0_21  order_active_ub_904  -14
    visit_0_21  service_visit_def_905  -1
    order_0_21  connected_order_arc_475  1
    order_0_21  connected_order_arc_502  1
    order_0_21  connected_order_arc_529  1
    order_0_21  connected_order_arc_556  1
    order_0_21  connected_order_arc_583  1
    order_0_21  connected_order_arc_610  1
    order_0_21  connected_order_arc_637  1
    order_0_21  connected_order_arc_664  1
    order_0_21  connected_order_arc_691  1
    order_0_21  connected_order_arc_718  1
    order_0_21  connected_order_arc_727  -1
    order_0_21  connected_order_arc_729  -1
    order_0_21  connected_order_arc_731  -1
    order_0_21  connected_order_arc_733  -1
    order_0_21  connected_order_arc_735  -1
    order_0_21  connected_order_arc_737  -1
    order_0_21  connected_order_arc_739  -1
    order_0_21  connected_order_arc_741  -1
    order_0_21  connected_order_arc_743  -1
    order_0_21  connected_order_arc_745  -1
    order_0_21  connected_order_arc_747  -1
    order_0_21  connected_order_arc_749  -1
    order_0_21  connected_order_arc_751  -1
    order_0_21  connected_order_arc_774  1
    order_0_21  connected_order_arc_801  1
    order_0_21  connected_order_arc_828  1
    order_0_21  order_active_lb_903  1
    order_0_21  order_active_ub_904  1
    visit_0_22  out_degree_907  -1
    visit_0_22  in_degree_908  -1
    visit_0_22  order_active_lb_909  -1
    visit_0_22  order_active_ub_910  -14
    visit_0_22  service_visit_def_911  -1
    order_0_22  connected_order_arc_477  1
    order_0_22  connected_order_arc_504  1
    order_0_22  connected_order_arc_531  1
    order_0_22  connected_order_arc_558  1
    order_0_22  connected_order_arc_585  1
    order_0_22  connected_order_arc_612  1
    order_0_22  connected_order_arc_639  1
    order_0_22  connected_order_arc_666  1
    order_0_22  connected_order_arc_693  1
    order_0_22  connected_order_arc_720  1
    order_0_22  connected_order_arc_747  1
    order_0_22  connected_order_arc_754  -1
    order_0_22  connected_order_arc_756  -1
    order_0_22  connected_order_arc_758  -1
    order_0_22  connected_order_arc_760  -1
    order_0_22  connected_order_arc_762  -1
    order_0_22  connected_order_arc_764  -1
    order_0_22  connected_order_arc_766  -1
    order_0_22  connected_order_arc_768  -1
    order_0_22  connected_order_arc_770  -1
    order_0_22  connected_order_arc_772  -1
    order_0_22  connected_order_arc_774  -1
    order_0_22  connected_order_arc_776  -1
    order_0_22  connected_order_arc_778  -1
    order_0_22  connected_order_arc_803  1
    order_0_22  connected_order_arc_830  1
    order_0_22  order_active_lb_909  1
    order_0_22  order_active_ub_910  1
    visit_0_23  out_degree_913  -1
    visit_0_23  in_degree_914  -1
    visit_0_23  order_active_lb_915  -1
    visit_0_23  order_active_ub_916  -14
    visit_0_23  service_visit_def_917  -1
    order_0_23  connected_order_arc_479  1
    order_0_23  connected_order_arc_506  1
    order_0_23  connected_order_arc_533  1
    order_0_23  connected_order_arc_560  1
    order_0_23  connected_order_arc_587  1
    order_0_23  connected_order_arc_614  1
    order_0_23  connected_order_arc_641  1
    order_0_23  connected_order_arc_668  1
    order_0_23  connected_order_arc_695  1
    order_0_23  connected_order_arc_722  1
    order_0_23  connected_order_arc_749  1
    order_0_23  connected_order_arc_776  1
    order_0_23  connected_order_arc_781  -1
    order_0_23  connected_order_arc_783  -1
    order_0_23  connected_order_arc_785  -1
    order_0_23  connected_order_arc_787  -1
    order_0_23  connected_order_arc_789  -1
    order_0_23  connected_order_arc_791  -1
    order_0_23  connected_order_arc_793  -1
    order_0_23  connected_order_arc_795  -1
    order_0_23  connected_order_arc_797  -1
    order_0_23  connected_order_arc_799  -1
    order_0_23  connected_order_arc_801  -1
    order_0_23  connected_order_arc_803  -1
    order_0_23  connected_order_arc_805  -1
    order_0_23  connected_order_arc_832  1
    order_0_23  order_active_lb_915  1
    order_0_23  order_active_ub_916  1
    visit_0_24  out_degree_919  -1
    visit_0_24  in_degree_920  -1
    visit_0_24  order_active_lb_921  -1
    visit_0_24  order_active_ub_922  -14
    visit_0_24  service_visit_def_923  -1
    order_0_24  connected_order_arc_481  1
    order_0_24  connected_order_arc_508  1
    order_0_24  connected_order_arc_535  1
    order_0_24  connected_order_arc_562  1
    order_0_24  connected_order_arc_589  1
    order_0_24  connected_order_arc_616  1
    order_0_24  connected_order_arc_643  1
    order_0_24  connected_order_arc_670  1
    order_0_24  connected_order_arc_697  1
    order_0_24  connected_order_arc_724  1
    order_0_24  connected_order_arc_751  1
    order_0_24  connected_order_arc_778  1
    order_0_24  connected_order_arc_805  1
    order_0_24  connected_order_arc_808  -1
    order_0_24  connected_order_arc_810  -1
    order_0_24  connected_order_arc_812  -1
    order_0_24  connected_order_arc_814  -1
    order_0_24  connected_order_arc_816  -1
    order_0_24  connected_order_arc_818  -1
    order_0_24  connected_order_arc_820  -1
    order_0_24  connected_order_arc_822  -1
    order_0_24  connected_order_arc_824  -1
    order_0_24  connected_order_arc_826  -1
    order_0_24  connected_order_arc_828  -1
    order_0_24  connected_order_arc_830  -1
    order_0_24  connected_order_arc_832  -1
    order_0_24  order_active_lb_921  1
    order_0_24  order_active_ub_922  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_0  arc_capacity_440  -20
    arc_0_0_0  depot_departure_or_bypass_833  1
    arc_0_0_0  depot_return_or_bypass_834  1
    MARKER    'MARKER'                 'INTEND'
    load_0_0_0  arc_capacity_440  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_1  arc_capacity_441  -20
    arc_0_0_1  depot_departure_or_bypass_833  1
    arc_0_0_1  in_degree_836  1
    arc_0_0_1  original_T_including_depot_unload_930  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_1  arc_capacity_441  1
    load_0_0_1  segment_load_conservation_839  -1
    load_0_0_1  segment_prefix_lb_840  1
    load_0_0_1  segment_prefix_ub_841  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_2  arc_capacity_442  -20
    arc_0_0_2  depot_departure_or_bypass_833  1
    arc_0_0_2  in_degree_843  1
    arc_0_0_2  original_T_including_depot_unload_930  7.2130540230577469e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_2  arc_capacity_442  1
    load_0_0_2  segment_load_conservation_846  -1
    load_0_0_2  segment_prefix_lb_847  1
    load_0_0_2  segment_prefix_ub_848  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_3  arc_capacity_443  -20
    arc_0_0_3  depot_departure_or_bypass_833  1
    arc_0_0_3  in_degree_850  1
    arc_0_0_3  original_T_including_depot_unload_930  4.9403722507151832e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_3  arc_capacity_443  1
    load_0_0_3  segment_load_conservation_853  -1
    load_0_0_3  segment_prefix_lb_854  1
    load_0_0_3  segment_prefix_ub_855  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_4  arc_capacity_444  -20
    arc_0_0_4  depot_departure_or_bypass_833  1
    arc_0_0_4  in_degree_857  1
    arc_0_0_4  original_T_including_depot_unload_930  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_4  arc_capacity_444  1
    load_0_0_4  segment_load_conservation_860  -1
    load_0_0_4  segment_prefix_lb_861  1
    load_0_0_4  segment_prefix_ub_862  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_5  arc_capacity_445  -20
    arc_0_0_5  depot_departure_or_bypass_833  1
    arc_0_0_5  in_degree_864  1
    arc_0_0_5  original_T_including_depot_unload_930  6.6653528395596720e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_5  arc_capacity_445  1
    load_0_0_5  segment_load_conservation_867  -1
    load_0_0_5  segment_prefix_lb_868  1
    load_0_0_5  segment_prefix_ub_869  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_6  arc_capacity_446  -20
    arc_0_0_6  depot_departure_or_bypass_833  1
    arc_0_0_6  in_degree_871  1
    arc_0_0_6  original_T_including_depot_unload_930  5.9431738885389052e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_6  arc_capacity_446  1
    load_0_0_6  segment_load_conservation_874  -1
    load_0_0_6  segment_prefix_lb_875  1
    load_0_0_6  segment_prefix_ub_876  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_17  arc_capacity_447  -20
    arc_0_0_17  depot_departure_or_bypass_833  1
    arc_0_0_17  in_degree_878  1
    arc_0_0_17  original_T_including_depot_unload_930  1.3396590612935172e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_17  arc_capacity_447  1
    load_0_0_17  free_load_conservation_882  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_18  arc_capacity_448  -20
    arc_0_0_18  depot_departure_or_bypass_833  1
    arc_0_0_18  in_degree_884  1
    arc_0_0_18  original_T_including_depot_unload_930  1.4501558573355060e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_18  arc_capacity_448  1
    load_0_0_18  free_load_conservation_888  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_19  arc_capacity_449  -20
    arc_0_0_19  depot_departure_or_bypass_833  1
    arc_0_0_19  in_degree_890  1
    arc_0_0_19  original_T_including_depot_unload_930  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_19  arc_capacity_449  1
    load_0_0_19  free_load_conservation_894  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_20  arc_capacity_450  -20
    arc_0_0_20  depot_departure_or_bypass_833  1
    arc_0_0_20  in_degree_896  1
    arc_0_0_20  original_T_including_depot_unload_930  9.5330620720858735e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_20  arc_capacity_450  1
    load_0_0_20  free_load_conservation_900  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_21  arc_capacity_451  -20
    arc_0_0_21  depot_departure_or_bypass_833  1
    arc_0_0_21  in_degree_902  1
    arc_0_0_21  original_T_including_depot_unload_930  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_21  arc_capacity_451  1
    load_0_0_21  free_load_conservation_906  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_22  arc_capacity_452  -20
    arc_0_0_22  depot_departure_or_bypass_833  1
    arc_0_0_22  in_degree_908  1
    arc_0_0_22  original_T_including_depot_unload_930  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_22  arc_capacity_452  1
    load_0_0_22  free_load_conservation_912  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_23  arc_capacity_453  -20
    arc_0_0_23  depot_departure_or_bypass_833  1
    arc_0_0_23  in_degree_914  1
    arc_0_0_23  original_T_including_depot_unload_930  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_23  arc_capacity_453  1
    load_0_0_23  free_load_conservation_918  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_24  arc_capacity_454  -20
    arc_0_0_24  depot_departure_or_bypass_833  1
    arc_0_0_24  in_degree_920  1
    arc_0_0_24  original_T_including_depot_unload_930  5.4249700630778887e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_24  arc_capacity_454  1
    load_0_0_24  free_load_conservation_924  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_0  arc_capacity_455  -20
    arc_0_1_0  depot_return_or_bypass_834  1
    arc_0_1_0  out_degree_835  1
    arc_0_1_0  original_T_including_depot_unload_930  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_0  arc_capacity_455  1
    load_0_1_0  segment_load_conservation_839  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_2  arc_capacity_456  -20
    arc_0_1_2  connected_order_arc_457  -15
    arc_0_1_2  out_degree_835  1
    arc_0_1_2  in_degree_843  1
    arc_0_1_2  original_T_including_depot_unload_930  4.4733407106545638e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_2  arc_capacity_456  1
    load_0_1_2  segment_load_conservation_839  1
    load_0_1_2  segment_load_conservation_846  -1
    load_0_1_2  segment_prefix_lb_847  1
    load_0_1_2  segment_prefix_ub_848  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_3  arc_capacity_458  -20
    arc_0_1_3  connected_order_arc_459  -15
    arc_0_1_3  out_degree_835  1
    arc_0_1_3  in_degree_850  1
    arc_0_1_3  original_T_including_depot_unload_930  2.2271784981792140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_3  arc_capacity_458  1
    load_0_1_3  segment_load_conservation_839  1
    load_0_1_3  segment_load_conservation_853  -1
    load_0_1_3  segment_prefix_lb_854  1
    load_0_1_3  segment_prefix_ub_855  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_4  arc_capacity_460  -20
    arc_0_1_4  connected_order_arc_461  -15
    arc_0_1_4  out_degree_835  1
    arc_0_1_4  in_degree_857  1
    arc_0_1_4  original_T_including_depot_unload_930  2.7078292664437623e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_4  arc_capacity_460  1
    load_0_1_4  segment_load_conservation_839  1
    load_0_1_4  segment_load_conservation_860  -1
    load_0_1_4  segment_prefix_lb_861  1
    load_0_1_4  segment_prefix_ub_862  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_5  arc_capacity_462  -20
    arc_0_1_5  connected_order_arc_463  -15
    arc_0_1_5  out_degree_835  1
    arc_0_1_5  in_degree_864  1
    arc_0_1_5  original_T_including_depot_unload_930  628.141943094385
    MARKER    'MARKER'                 'INTEND'
    load_0_1_5  arc_capacity_462  1
    load_0_1_5  segment_load_conservation_839  1
    load_0_1_5  segment_load_conservation_867  -1
    load_0_1_5  segment_prefix_lb_868  1
    load_0_1_5  segment_prefix_ub_869  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_6  arc_capacity_464  -20
    arc_0_1_6  connected_order_arc_465  -15
    arc_0_1_6  out_degree_835  1
    arc_0_1_6  in_degree_871  1
    arc_0_1_6  original_T_including_depot_unload_930  6.9736186698570737e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_6  arc_capacity_464  1
    load_0_1_6  segment_load_conservation_839  1
    load_0_1_6  segment_load_conservation_874  -1
    load_0_1_6  segment_prefix_lb_875  1
    load_0_1_6  segment_prefix_ub_876  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_17  arc_capacity_466  -20
    arc_0_1_17  connected_order_arc_467  -15
    arc_0_1_17  out_degree_835  1
    arc_0_1_17  in_degree_878  1
    arc_0_1_17  original_T_including_depot_unload_930  1.1260666281343611e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_17  arc_capacity_466  1
    load_0_1_17  segment_load_conservation_839  1
    load_0_1_17  free_load_conservation_882  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_18  arc_capacity_468  -20
    arc_0_1_18  connected_order_arc_469  -15
    arc_0_1_18  out_degree_835  1
    arc_0_1_18  in_degree_884  1
    arc_0_1_18  original_T_including_depot_unload_930  1.3132316623300278e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_18  arc_capacity_468  1
    load_0_1_18  segment_load_conservation_839  1
    load_0_1_18  free_load_conservation_888  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_19  arc_capacity_470  -20
    arc_0_1_19  connected_order_arc_471  -15
    arc_0_1_19  out_degree_835  1
    arc_0_1_19  in_degree_890  1
    arc_0_1_19  original_T_including_depot_unload_930  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_19  arc_capacity_470  1
    load_0_1_19  segment_load_conservation_839  1
    load_0_1_19  free_load_conservation_894  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_20  arc_capacity_472  -20
    arc_0_1_20  connected_order_arc_473  -15
    arc_0_1_20  out_degree_835  1
    arc_0_1_20  in_degree_896  1
    arc_0_1_20  original_T_including_depot_unload_930  8.4968861461374138e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_20  arc_capacity_472  1
    load_0_1_20  segment_load_conservation_839  1
    load_0_1_20  free_load_conservation_900  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_21  arc_capacity_474  -20
    arc_0_1_21  connected_order_arc_475  -15
    arc_0_1_21  out_degree_835  1
    arc_0_1_21  in_degree_902  1
    arc_0_1_21  original_T_including_depot_unload_930  4.5128490093732506e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_21  arc_capacity_474  1
    load_0_1_21  segment_load_conservation_839  1
    load_0_1_21  free_load_conservation_906  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_22  arc_capacity_476  -20
    arc_0_1_22  connected_order_arc_477  -15
    arc_0_1_22  out_degree_835  1
    arc_0_1_22  in_degree_908  1
    arc_0_1_22  original_T_including_depot_unload_930  545.439458844012
    MARKER    'MARKER'                 'INTEND'
    load_0_1_22  arc_capacity_476  1
    load_0_1_22  segment_load_conservation_839  1
    load_0_1_22  free_load_conservation_912  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_23  arc_capacity_478  -20
    arc_0_1_23  connected_order_arc_479  -15
    arc_0_1_23  out_degree_835  1
    arc_0_1_23  in_degree_914  1
    arc_0_1_23  original_T_including_depot_unload_930  1.5902582434549993e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_23  arc_capacity_478  1
    load_0_1_23  segment_load_conservation_839  1
    load_0_1_23  free_load_conservation_918  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_24  arc_capacity_480  -20
    arc_0_1_24  connected_order_arc_481  -15
    arc_0_1_24  out_degree_835  1
    arc_0_1_24  in_degree_920  1
    arc_0_1_24  original_T_including_depot_unload_930  2.8529311190414518e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_24  arc_capacity_480  1
    load_0_1_24  segment_load_conservation_839  1
    load_0_1_24  free_load_conservation_924  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_0  arc_capacity_482  -20
    arc_0_2_0  depot_return_or_bypass_834  1
    arc_0_2_0  out_degree_842  1
    arc_0_2_0  original_T_including_depot_unload_930  7.2130540230577469e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_0  arc_capacity_482  1
    load_0_2_0  segment_load_conservation_846  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_1  arc_capacity_483  -20
    arc_0_2_1  connected_order_arc_484  -15
    arc_0_2_1  in_degree_836  1
    arc_0_2_1  out_degree_842  1
    arc_0_2_1  original_T_including_depot_unload_930  4.4733407106545638e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_1  arc_capacity_483  1
    load_0_2_1  segment_load_conservation_839  -1
    load_0_2_1  segment_prefix_lb_840  1
    load_0_2_1  segment_prefix_ub_841  1
    load_0_2_1  segment_load_conservation_846  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_3  arc_capacity_485  -20
    arc_0_2_3  connected_order_arc_486  -15
    arc_0_2_3  out_degree_842  1
    arc_0_2_3  in_degree_850  1
    arc_0_2_3  original_T_including_depot_unload_930  2.2729932910497158e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_3  arc_capacity_485  1
    load_0_2_3  segment_load_conservation_846  1
    load_0_2_3  segment_load_conservation_853  -1
    load_0_2_3  segment_prefix_lb_854  1
    load_0_2_3  segment_prefix_ub_855  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_4  arc_capacity_487  -20
    arc_0_2_4  connected_order_arc_488  -15
    arc_0_2_4  out_degree_842  1
    arc_0_2_4  in_degree_857  1
    arc_0_2_4  original_T_including_depot_unload_930  4.9242827332511274e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_4  arc_capacity_487  1
    load_0_2_4  segment_load_conservation_846  1
    load_0_2_4  segment_load_conservation_860  -1
    load_0_2_4  segment_prefix_lb_861  1
    load_0_2_4  segment_prefix_ub_862  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_5  arc_capacity_489  -20
    arc_0_2_5  connected_order_arc_490  -15
    arc_0_2_5  out_degree_842  1
    arc_0_2_5  in_degree_864  1
    arc_0_2_5  original_T_including_depot_unload_930  880.352897387315
    MARKER    'MARKER'                 'INTEND'
    load_0_2_5  arc_capacity_489  1
    load_0_2_5  segment_load_conservation_846  1
    load_0_2_5  segment_load_conservation_867  -1
    load_0_2_5  segment_prefix_lb_868  1
    load_0_2_5  segment_prefix_ub_869  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_6  arc_capacity_491  -20
    arc_0_2_6  connected_order_arc_492  -15
    arc_0_2_6  out_degree_842  1
    arc_0_2_6  in_degree_871  1
    arc_0_2_6  original_T_including_depot_unload_930  1.0687086794720833e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_6  arc_capacity_491  1
    load_0_2_6  segment_load_conservation_846  1
    load_0_2_6  segment_load_conservation_874  -1
    load_0_2_6  segment_prefix_lb_875  1
    load_0_2_6  segment_prefix_ub_876  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_17  arc_capacity_493  -20
    arc_0_2_17  connected_order_arc_494  -15
    arc_0_2_17  out_degree_842  1
    arc_0_2_17  in_degree_878  1
    arc_0_2_17  original_T_including_depot_unload_930  9.7093568976197776e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_17  arc_capacity_493  1
    load_0_2_17  segment_load_conservation_846  1
    load_0_2_17  free_load_conservation_882  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_18  arc_capacity_495  -20
    arc_0_2_18  connected_order_arc_496  -15
    arc_0_2_18  out_degree_842  1
    arc_0_2_18  in_degree_884  1
    arc_0_2_18  original_T_including_depot_unload_930  1.3110718450902477e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_18  arc_capacity_495  1
    load_0_2_18  segment_load_conservation_846  1
    load_0_2_18  free_load_conservation_888  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_19  arc_capacity_497  -20
    arc_0_2_19  connected_order_arc_498  -15
    arc_0_2_19  out_degree_842  1
    arc_0_2_19  in_degree_890  1
    arc_0_2_19  original_T_including_depot_unload_930  1.7303231472353602e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_19  arc_capacity_497  1
    load_0_2_19  segment_load_conservation_846  1
    load_0_2_19  free_load_conservation_894  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_20  arc_capacity_499  -20
    arc_0_2_20  connected_order_arc_500  -15
    arc_0_2_20  out_degree_842  1
    arc_0_2_20  in_degree_896  1
    arc_0_2_20  original_T_including_depot_unload_930  9.6598937061987863e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_20  arc_capacity_499  1
    load_0_2_20  segment_load_conservation_846  1
    load_0_2_20  free_load_conservation_900  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_21  arc_capacity_501  -20
    arc_0_2_21  connected_order_arc_502  -15
    arc_0_2_21  out_degree_842  1
    arc_0_2_21  in_degree_902  1
    arc_0_2_21  original_T_including_depot_unload_930  4.6128219015626763e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_21  arc_capacity_501  1
    load_0_2_21  segment_load_conservation_846  1
    load_0_2_21  free_load_conservation_906  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_22  arc_capacity_503  -20
    arc_0_2_22  connected_order_arc_504  -15
    arc_0_2_22  out_degree_842  1
    arc_0_2_22  in_degree_908  1
    arc_0_2_22  original_T_including_depot_unload_930  6.3648699141452130e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_22  arc_capacity_503  1
    load_0_2_22  segment_load_conservation_846  1
    load_0_2_22  free_load_conservation_912  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_23  arc_capacity_505  -20
    arc_0_2_23  connected_order_arc_506  -15
    arc_0_2_23  out_degree_842  1
    arc_0_2_23  in_degree_914  1
    arc_0_2_23  original_T_including_depot_unload_930  2.0162129512771592e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_23  arc_capacity_505  1
    load_0_2_23  segment_load_conservation_846  1
    load_0_2_23  free_load_conservation_918  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_24  arc_capacity_507  -20
    arc_0_2_24  connected_order_arc_508  -15
    arc_0_2_24  out_degree_842  1
    arc_0_2_24  in_degree_920  1
    arc_0_2_24  original_T_including_depot_unload_930  3.2367117212973966e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_24  arc_capacity_507  1
    load_0_2_24  segment_load_conservation_846  1
    load_0_2_24  free_load_conservation_924  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_0  arc_capacity_509  -20
    arc_0_3_0  depot_return_or_bypass_834  1
    arc_0_3_0  out_degree_849  1
    arc_0_3_0  original_T_including_depot_unload_930  4.9403722507151832e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_0  arc_capacity_509  1
    load_0_3_0  segment_load_conservation_853  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_1  arc_capacity_510  -20
    arc_0_3_1  connected_order_arc_511  -15
    arc_0_3_1  in_degree_836  1
    arc_0_3_1  out_degree_849  1
    arc_0_3_1  original_T_including_depot_unload_930  2.2271784981792140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_1  arc_capacity_510  1
    load_0_3_1  segment_load_conservation_839  -1
    load_0_3_1  segment_prefix_lb_840  1
    load_0_3_1  segment_prefix_ub_841  1
    load_0_3_1  segment_load_conservation_853  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_2  arc_capacity_512  -20
    arc_0_3_2  connected_order_arc_513  -15
    arc_0_3_2  in_degree_843  1
    arc_0_3_2  out_degree_849  1
    arc_0_3_2  original_T_including_depot_unload_930  2.2729932910497158e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_2  arc_capacity_512  1
    load_0_3_2  segment_load_conservation_846  -1
    load_0_3_2  segment_prefix_lb_847  1
    load_0_3_2  segment_prefix_ub_848  1
    load_0_3_2  segment_load_conservation_853  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_4  arc_capacity_514  -20
    arc_0_3_4  connected_order_arc_515  -15
    arc_0_3_4  out_degree_849  1
    arc_0_3_4  in_degree_857  1
    arc_0_3_4  original_T_including_depot_unload_930  3.4754938304534517e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_4  arc_capacity_514  1
    load_0_3_4  segment_load_conservation_853  1
    load_0_3_4  segment_load_conservation_860  -1
    load_0_3_4  segment_prefix_lb_861  1
    load_0_3_4  segment_prefix_ub_862  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_5  arc_capacity_516  -20
    arc_0_3_5  connected_order_arc_517  -15
    arc_0_3_5  out_degree_849  1
    arc_0_3_5  in_degree_864  1
    arc_0_3_5  original_T_including_depot_unload_930  750.067997850428
    MARKER    'MARKER'                 'INTEND'
    load_0_3_5  arc_capacity_516  1
    load_0_3_5  segment_load_conservation_853  1
    load_0_3_5  segment_load_conservation_867  -1
    load_0_3_5  segment_prefix_lb_868  1
    load_0_3_5  segment_prefix_ub_869  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_6  arc_capacity_518  -20
    arc_0_3_6  connected_order_arc_519  -15
    arc_0_3_6  out_degree_849  1
    arc_0_3_6  in_degree_871  1
    arc_0_3_6  original_T_including_depot_unload_930  8.8588784481112123e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_6  arc_capacity_518  1
    load_0_3_6  segment_load_conservation_853  1
    load_0_3_6  segment_load_conservation_874  -1
    load_0_3_6  segment_prefix_lb_875  1
    load_0_3_6  segment_prefix_ub_876  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_17  arc_capacity_520  -20
    arc_0_3_17  connected_order_arc_521  -15
    arc_0_3_17  out_degree_849  1
    arc_0_3_17  in_degree_878  1
    arc_0_3_17  original_T_including_depot_unload_930  1.0510800781097112e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_17  arc_capacity_520  1
    load_0_3_17  segment_load_conservation_853  1
    load_0_3_17  free_load_conservation_882  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_18  arc_capacity_522  -20
    arc_0_3_18  connected_order_arc_523  -15
    arc_0_3_18  out_degree_849  1
    arc_0_3_18  in_degree_884  1
    arc_0_3_18  original_T_including_depot_unload_930  1.3174943724568802e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_18  arc_capacity_522  1
    load_0_3_18  segment_load_conservation_853  1
    load_0_3_18  free_load_conservation_888  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_19  arc_capacity_524  -20
    arc_0_3_19  connected_order_arc_525  -15
    arc_0_3_19  out_degree_849  1
    arc_0_3_19  in_degree_890  1
    arc_0_3_19  original_T_including_depot_unload_930  1.5184659007075070e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_19  arc_capacity_524  1
    load_0_3_19  segment_load_conservation_853  1
    load_0_3_19  free_load_conservation_894  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_20  arc_capacity_526  -20
    arc_0_3_20  connected_order_arc_527  -15
    arc_0_3_20  out_degree_849  1
    arc_0_3_20  in_degree_896  1
    arc_0_3_20  original_T_including_depot_unload_930  904.837890445026
    MARKER    'MARKER'                 'INTEND'
    load_0_3_20  arc_capacity_526  1
    load_0_3_20  segment_load_conservation_853  1
    load_0_3_20  free_load_conservation_900  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_21  arc_capacity_528  -20
    arc_0_3_21  connected_order_arc_529  -15
    arc_0_3_21  out_degree_849  1
    arc_0_3_21  in_degree_902  1
    arc_0_3_21  original_T_including_depot_unload_930  3.7315439746742123e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_21  arc_capacity_528  1
    load_0_3_21  segment_load_conservation_853  1
    load_0_3_21  free_load_conservation_906  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_22  arc_capacity_530  -20
    arc_0_3_22  connected_order_arc_531  -15
    arc_0_3_22  out_degree_849  1
    arc_0_3_22  in_degree_908  1
    arc_0_3_22  original_T_including_depot_unload_930  5.7237486782756332e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_22  arc_capacity_530  1
    load_0_3_22  segment_load_conservation_853  1
    load_0_3_22  free_load_conservation_912  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_23  arc_capacity_532  -20
    arc_0_3_23  connected_order_arc_533  -15
    arc_0_3_23  out_degree_849  1
    arc_0_3_23  in_degree_914  1
    arc_0_3_23  original_T_including_depot_unload_930  1.8073464544423741e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_23  arc_capacity_532  1
    load_0_3_23  segment_load_conservation_853  1
    load_0_3_23  free_load_conservation_918  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_24  arc_capacity_534  -20
    arc_0_3_24  connected_order_arc_535  -15
    arc_0_3_24  out_degree_849  1
    arc_0_3_24  in_degree_920  1
    arc_0_3_24  original_T_including_depot_unload_930  2.3159636865750136e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_24  arc_capacity_534  1
    load_0_3_24  segment_load_conservation_853  1
    load_0_3_24  free_load_conservation_924  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_0  arc_capacity_536  -20
    arc_0_4_0  depot_return_or_bypass_834  1
    arc_0_4_0  out_degree_856  1
    arc_0_4_0  original_T_including_depot_unload_930  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_0  arc_capacity_536  1
    load_0_4_0  segment_load_conservation_860  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_1  arc_capacity_537  -20
    arc_0_4_1  connected_order_arc_538  -15
    arc_0_4_1  in_degree_836  1
    arc_0_4_1  out_degree_856  1
    arc_0_4_1  original_T_including_depot_unload_930  2.7078292664437623e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_1  arc_capacity_537  1
    load_0_4_1  segment_load_conservation_839  -1
    load_0_4_1  segment_prefix_lb_840  1
    load_0_4_1  segment_prefix_ub_841  1
    load_0_4_1  segment_load_conservation_860  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_2  arc_capacity_539  -20
    arc_0_4_2  connected_order_arc_540  -15
    arc_0_4_2  in_degree_843  1
    arc_0_4_2  out_degree_856  1
    arc_0_4_2  original_T_including_depot_unload_930  4.9242827332511274e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_2  arc_capacity_539  1
    load_0_4_2  segment_load_conservation_846  -1
    load_0_4_2  segment_prefix_lb_847  1
    load_0_4_2  segment_prefix_ub_848  1
    load_0_4_2  segment_load_conservation_860  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_3  arc_capacity_541  -20
    arc_0_4_3  connected_order_arc_542  -15
    arc_0_4_3  in_degree_850  1
    arc_0_4_3  out_degree_856  1
    arc_0_4_3  original_T_including_depot_unload_930  3.4754938304534517e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_3  arc_capacity_541  1
    load_0_4_3  segment_load_conservation_853  -1
    load_0_4_3  segment_prefix_lb_854  1
    load_0_4_3  segment_prefix_ub_855  1
    load_0_4_3  segment_load_conservation_860  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_5  arc_capacity_543  -20
    arc_0_4_5  connected_order_arc_544  -15
    arc_0_4_5  out_degree_856  1
    arc_0_4_5  in_degree_864  1
    arc_0_4_5  original_T_including_depot_unload_930  4.0284428834016438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_5  arc_capacity_543  1
    load_0_4_5  segment_load_conservation_860  1
    load_0_4_5  segment_load_conservation_867  -1
    load_0_4_5  segment_prefix_lb_868  1
    load_0_4_5  segment_prefix_ub_869  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_6  arc_capacity_545  -20
    arc_0_4_6  connected_order_arc_546  -15
    arc_0_4_6  out_degree_856  1
    arc_0_4_6  in_degree_871  1
    arc_0_4_6  original_T_including_depot_unload_930  5.8227353503177085e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_6  arc_capacity_545  1
    load_0_4_6  segment_load_conservation_860  1
    load_0_4_6  segment_load_conservation_874  -1
    load_0_4_6  segment_prefix_lb_875  1
    load_0_4_6  segment_prefix_ub_876  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_17  arc_capacity_547  -20
    arc_0_4_17  connected_order_arc_548  -15
    arc_0_4_17  out_degree_856  1
    arc_0_4_17  in_degree_878  1
    arc_0_4_17  original_T_including_depot_unload_930  8.8580487162181055e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_17  arc_capacity_547  1
    load_0_4_17  segment_load_conservation_860  1
    load_0_4_17  free_load_conservation_882  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_18  arc_capacity_549  -20
    arc_0_4_18  connected_order_arc_550  -15
    arc_0_4_18  out_degree_856  1
    arc_0_4_18  in_degree_884  1
    arc_0_4_18  original_T_including_depot_unload_930  1.0428409649002836e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_18  arc_capacity_549  1
    load_0_4_18  segment_load_conservation_860  1
    load_0_4_18  free_load_conservation_888  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_19  arc_capacity_551  -20
    arc_0_4_19  connected_order_arc_552  -15
    arc_0_4_19  out_degree_856  1
    arc_0_4_19  in_degree_890  1
    arc_0_4_19  original_T_including_depot_unload_930  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_19  arc_capacity_551  1
    load_0_4_19  segment_load_conservation_860  1
    load_0_4_19  free_load_conservation_894  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_20  arc_capacity_553  -20
    arc_0_4_20  connected_order_arc_554  -15
    arc_0_4_20  out_degree_856  1
    arc_0_4_20  in_degree_896  1
    arc_0_4_20  original_T_including_depot_unload_930  5.8292761965990132e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_20  arc_capacity_553  1
    load_0_4_20  segment_load_conservation_860  1
    load_0_4_20  free_load_conservation_900  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_21  arc_capacity_555  -20
    arc_0_4_21  connected_order_arc_556  -15
    arc_0_4_21  out_degree_856  1
    arc_0_4_21  in_degree_902  1
    arc_0_4_21  original_T_including_depot_unload_930  6.8976718276177132e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_21  arc_capacity_555  1
    load_0_4_21  segment_load_conservation_860  1
    load_0_4_21  free_load_conservation_906  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_22  arc_capacity_557  -20
    arc_0_4_22  connected_order_arc_558  -15
    arc_0_4_22  out_degree_856  1
    arc_0_4_22  in_degree_908  1
    arc_0_4_22  original_T_including_depot_unload_930  2.7570828838654035e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_22  arc_capacity_557  1
    load_0_4_22  segment_load_conservation_860  1
    load_0_4_22  free_load_conservation_912  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_23  arc_capacity_559  -20
    arc_0_4_23  connected_order_arc_560  -15
    arc_0_4_23  out_degree_856  1
    arc_0_4_23  in_degree_914  1
    arc_0_4_23  original_T_including_depot_unload_930  1.5530568652263394e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_23  arc_capacity_559  1
    load_0_4_23  segment_load_conservation_860  1
    load_0_4_23  free_load_conservation_918  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_24  arc_capacity_561  -20
    arc_0_4_24  connected_order_arc_562  -15
    arc_0_4_24  out_degree_856  1
    arc_0_4_24  in_degree_920  1
    arc_0_4_24  original_T_including_depot_unload_930  1.7461252424213140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_24  arc_capacity_561  1
    load_0_4_24  segment_load_conservation_860  1
    load_0_4_24  free_load_conservation_924  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_0  arc_capacity_563  -20
    arc_0_5_0  depot_return_or_bypass_834  1
    arc_0_5_0  out_degree_863  1
    arc_0_5_0  original_T_including_depot_unload_930  6.6653528395596720e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_0  arc_capacity_563  1
    load_0_5_0  segment_load_conservation_867  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_1  arc_capacity_564  -20
    arc_0_5_1  connected_order_arc_565  -15
    arc_0_5_1  in_degree_836  1
    arc_0_5_1  out_degree_863  1
    arc_0_5_1  original_T_including_depot_unload_930  628.141943094385
    MARKER    'MARKER'                 'INTEND'
    load_0_5_1  arc_capacity_564  1
    load_0_5_1  segment_load_conservation_839  -1
    load_0_5_1  segment_prefix_lb_840  1
    load_0_5_1  segment_prefix_ub_841  1
    load_0_5_1  segment_load_conservation_867  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_2  arc_capacity_566  -20
    arc_0_5_2  connected_order_arc_567  -15
    arc_0_5_2  in_degree_843  1
    arc_0_5_2  out_degree_863  1
    arc_0_5_2  original_T_including_depot_unload_930  880.352897387315
    MARKER    'MARKER'                 'INTEND'
    load_0_5_2  arc_capacity_566  1
    load_0_5_2  segment_load_conservation_846  -1
    load_0_5_2  segment_prefix_lb_847  1
    load_0_5_2  segment_prefix_ub_848  1
    load_0_5_2  segment_load_conservation_867  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_3  arc_capacity_568  -20
    arc_0_5_3  connected_order_arc_569  -15
    arc_0_5_3  in_degree_850  1
    arc_0_5_3  out_degree_863  1
    arc_0_5_3  original_T_including_depot_unload_930  750.067997850428
    MARKER    'MARKER'                 'INTEND'
    load_0_5_3  arc_capacity_568  1
    load_0_5_3  segment_load_conservation_853  -1
    load_0_5_3  segment_prefix_lb_854  1
    load_0_5_3  segment_prefix_ub_855  1
    load_0_5_3  segment_load_conservation_867  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_4  arc_capacity_570  -20
    arc_0_5_4  connected_order_arc_571  -15
    arc_0_5_4  in_degree_857  1
    arc_0_5_4  out_degree_863  1
    arc_0_5_4  original_T_including_depot_unload_930  4.0284428834016438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_4  arc_capacity_570  1
    load_0_5_4  segment_load_conservation_860  -1
    load_0_5_4  segment_prefix_lb_861  1
    load_0_5_4  segment_prefix_ub_862  1
    load_0_5_4  segment_load_conservation_867  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_6  arc_capacity_572  -20
    arc_0_5_6  connected_order_arc_573  -15
    arc_0_5_6  out_degree_863  1
    arc_0_5_6  in_degree_871  1
    arc_0_5_6  original_T_including_depot_unload_930  3.2985327387120213e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_6  arc_capacity_572  1
    load_0_5_6  segment_load_conservation_867  1
    load_0_5_6  segment_load_conservation_874  -1
    load_0_5_6  segment_prefix_lb_875  1
    load_0_5_6  segment_prefix_ub_876  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_17  arc_capacity_574  -20
    arc_0_5_17  connected_order_arc_575  -15
    arc_0_5_17  out_degree_863  1
    arc_0_5_17  in_degree_878  1
    arc_0_5_17  original_T_including_depot_unload_930  8.6958069185371107e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_17  arc_capacity_574  1
    load_0_5_17  segment_load_conservation_867  1
    load_0_5_17  free_load_conservation_882  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_18  arc_capacity_576  -20
    arc_0_5_18  connected_order_arc_577  -15
    arc_0_5_18  out_degree_863  1
    arc_0_5_18  in_degree_884  1
    arc_0_5_18  original_T_including_depot_unload_930  8.2066682484686987e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_18  arc_capacity_576  1
    load_0_5_18  segment_load_conservation_867  1
    load_0_5_18  free_load_conservation_888  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_19  arc_capacity_578  -20
    arc_0_5_19  connected_order_arc_579  -15
    arc_0_5_19  out_degree_863  1
    arc_0_5_19  in_degree_890  1
    arc_0_5_19  original_T_including_depot_unload_930  1.6292966848558842e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_19  arc_capacity_578  1
    load_0_5_19  segment_load_conservation_867  1
    load_0_5_19  free_load_conservation_894  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_20  arc_capacity_580  -20
    arc_0_5_20  connected_order_arc_581  -15
    arc_0_5_20  out_degree_863  1
    arc_0_5_20  in_degree_896  1
    arc_0_5_20  original_T_including_depot_unload_930  3.1728416035596246e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_20  arc_capacity_580  1
    load_0_5_20  segment_load_conservation_867  1
    load_0_5_20  free_load_conservation_900  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_21  arc_capacity_582  -20
    arc_0_5_21  connected_order_arc_583  -15
    arc_0_5_21  out_degree_863  1
    arc_0_5_21  in_degree_902  1
    arc_0_5_21  original_T_including_depot_unload_930  1.0758099325648966e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_21  arc_capacity_582  1
    load_0_5_21  segment_load_conservation_867  1
    load_0_5_21  free_load_conservation_906  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_22  arc_capacity_584  -20
    arc_0_5_22  connected_order_arc_585  -15
    arc_0_5_22  out_degree_863  1
    arc_0_5_22  in_degree_908  1
    arc_0_5_22  original_T_including_depot_unload_930  3.1069481377857926e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_22  arc_capacity_584  1
    load_0_5_22  segment_load_conservation_867  1
    load_0_5_22  free_load_conservation_912  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_23  arc_capacity_586  -20
    arc_0_5_23  connected_order_arc_587  -15
    arc_0_5_23  out_degree_863  1
    arc_0_5_23  in_degree_914  1
    arc_0_5_23  original_T_including_depot_unload_930  1.2927075446362680e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_23  arc_capacity_586  1
    load_0_5_23  segment_load_conservation_867  1
    load_0_5_23  free_load_conservation_918  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_24  arc_capacity_588  -20
    arc_0_5_24  connected_order_arc_589  -15
    arc_0_5_24  out_degree_863  1
    arc_0_5_24  in_degree_920  1
    arc_0_5_24  original_T_including_depot_unload_930  5.5739415765733247e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_24  arc_capacity_588  1
    load_0_5_24  segment_load_conservation_867  1
    load_0_5_24  free_load_conservation_924  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_0  arc_capacity_590  -20
    arc_0_6_0  depot_return_or_bypass_834  1
    arc_0_6_0  out_degree_870  1
    arc_0_6_0  original_T_including_depot_unload_930  4.6364706268001146e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_0  arc_capacity_590  1
    load_0_6_0  segment_load_conservation_874  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_1  arc_capacity_591  -20
    arc_0_6_1  connected_order_arc_592  -15
    arc_0_6_1  in_degree_836  1
    arc_0_6_1  out_degree_870  1
    arc_0_6_1  original_T_including_depot_unload_930  6.7517249538835438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_1  arc_capacity_591  1
    load_0_6_1  segment_load_conservation_839  -1
    load_0_6_1  segment_prefix_lb_840  1
    load_0_6_1  segment_prefix_ub_841  1
    load_0_6_1  segment_load_conservation_874  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_2  arc_capacity_593  -20
    arc_0_6_2  connected_order_arc_594  -15
    arc_0_6_2  in_degree_843  1
    arc_0_6_2  out_degree_870  1
    arc_0_6_2  original_T_including_depot_unload_930  1.1090437276384578e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_2  arc_capacity_593  1
    load_0_6_2  segment_load_conservation_846  -1
    load_0_6_2  segment_prefix_lb_847  1
    load_0_6_2  segment_prefix_ub_848  1
    load_0_6_2  segment_load_conservation_874  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_3  arc_capacity_595  -20
    arc_0_6_3  connected_order_arc_596  -15
    arc_0_6_3  in_degree_850  1
    arc_0_6_3  out_degree_870  1
    arc_0_6_3  original_T_including_depot_unload_930  8.9433085313747858e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_3  arc_capacity_595  1
    load_0_6_3  segment_load_conservation_853  -1
    load_0_6_3  segment_prefix_lb_854  1
    load_0_6_3  segment_prefix_ub_855  1
    load_0_6_3  segment_load_conservation_874  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_4  arc_capacity_597  -20
    arc_0_6_4  connected_order_arc_598  -15
    arc_0_6_4  in_degree_857  1
    arc_0_6_4  out_degree_870  1
    arc_0_6_4  original_T_including_depot_unload_930  6.7868877694996661e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_4  arc_capacity_597  1
    load_0_6_4  segment_load_conservation_860  -1
    load_0_6_4  segment_prefix_lb_861  1
    load_0_6_4  segment_prefix_ub_862  1
    load_0_6_4  segment_load_conservation_874  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_5  arc_capacity_599  -20
    arc_0_6_5  connected_order_arc_600  -15
    arc_0_6_5  in_degree_864  1
    arc_0_6_5  out_degree_870  1
    arc_0_6_5  original_T_including_depot_unload_930  5.8442598457899078e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_5  arc_capacity_599  1
    load_0_6_5  segment_load_conservation_867  -1
    load_0_6_5  segment_prefix_lb_868  1
    load_0_6_5  segment_prefix_ub_869  1
    load_0_6_5  segment_load_conservation_874  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_17  arc_capacity_601  -20
    arc_0_6_17  connected_order_arc_602  -15
    arc_0_6_17  out_degree_870  1
    arc_0_6_17  in_degree_878  1
    arc_0_6_17  original_T_including_depot_unload_930  1.4399299780980639e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_17  arc_capacity_601  1
    load_0_6_17  segment_load_conservation_874  1
    load_0_6_17  free_load_conservation_882  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_18  arc_capacity_603  -20
    arc_0_6_18  connected_order_arc_604  -15
    arc_0_6_18  out_degree_870  1
    arc_0_6_18  in_degree_884  1
    arc_0_6_18  original_T_including_depot_unload_930  1.3898988531263665e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_18  arc_capacity_603  1
    load_0_6_18  segment_load_conservation_874  1
    load_0_6_18  free_load_conservation_888  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_19  arc_capacity_605  -20
    arc_0_6_19  connected_order_arc_606  -15
    arc_0_6_19  out_degree_870  1
    arc_0_6_19  in_degree_890  1
    arc_0_6_19  original_T_including_depot_unload_930  1075.72043838369
    MARKER    'MARKER'                 'INTEND'
    load_0_6_19  arc_capacity_605  1
    load_0_6_19  segment_load_conservation_874  1
    load_0_6_19  free_load_conservation_894  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_20  arc_capacity_607  -20
    arc_0_6_20  connected_order_arc_608  -15
    arc_0_6_20  out_degree_870  1
    arc_0_6_20  in_degree_896  1
    arc_0_6_20  original_T_including_depot_unload_930  897.031483121361
    MARKER    'MARKER'                 'INTEND'
    load_0_6_20  arc_capacity_607  1
    load_0_6_20  segment_load_conservation_874  1
    load_0_6_20  free_load_conservation_900  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_21  arc_capacity_609  -20
    arc_0_6_21  connected_order_arc_610  -15
    arc_0_6_21  out_degree_870  1
    arc_0_6_21  in_degree_902  1
    arc_0_6_21  original_T_including_depot_unload_930  1.0491196843462671e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_21  arc_capacity_609  1
    load_0_6_21  segment_load_conservation_874  1
    load_0_6_21  free_load_conservation_906  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_22  arc_capacity_611  -20
    arc_0_6_22  connected_order_arc_612  -15
    arc_0_6_22  out_degree_870  1
    arc_0_6_22  in_degree_908  1
    arc_0_6_22  original_T_including_depot_unload_930  8.1289340937717509e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_22  arc_capacity_611  1
    load_0_6_22  segment_load_conservation_874  1
    load_0_6_22  free_load_conservation_912  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_23  arc_capacity_613  -20
    arc_0_6_23  connected_order_arc_614  -15
    arc_0_6_23  out_degree_870  1
    arc_0_6_23  in_degree_914  1
    arc_0_6_23  original_T_including_depot_unload_930  9.1576870176747968e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_23  arc_capacity_613  1
    load_0_6_23  segment_load_conservation_874  1
    load_0_6_23  free_load_conservation_918  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_24  arc_capacity_615  -20
    arc_0_6_24  connected_order_arc_616  -15
    arc_0_6_24  out_degree_870  1
    arc_0_6_24  in_degree_920  1
    arc_0_6_24  original_T_including_depot_unload_930  839.148853987777
    MARKER    'MARKER'                 'INTEND'
    load_0_6_24  arc_capacity_615  1
    load_0_6_24  segment_load_conservation_874  1
    load_0_6_24  free_load_conservation_924  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_0  arc_capacity_617  -20
    arc_0_17_0  depot_return_or_bypass_834  1
    arc_0_17_0  out_degree_877  1
    arc_0_17_0  original_T_including_depot_unload_930  1.3396590612935172e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_0  arc_capacity_617  1
    load_0_17_0  free_load_conservation_882  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_1  arc_capacity_618  -20
    arc_0_17_1  connected_order_arc_619  -15
    arc_0_17_1  in_degree_836  1
    arc_0_17_1  out_degree_877  1
    arc_0_17_1  original_T_including_depot_unload_930  1.1260666281343611e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_1  arc_capacity_618  1
    load_0_17_1  segment_load_conservation_839  -1
    load_0_17_1  segment_prefix_lb_840  1
    load_0_17_1  segment_prefix_ub_841  1
    load_0_17_1  free_load_conservation_882  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_2  arc_capacity_620  -20
    arc_0_17_2  connected_order_arc_621  -15
    arc_0_17_2  in_degree_843  1
    arc_0_17_2  out_degree_877  1
    arc_0_17_2  original_T_including_depot_unload_930  9.7093568976197776e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_2  arc_capacity_620  1
    load_0_17_2  segment_load_conservation_846  -1
    load_0_17_2  segment_prefix_lb_847  1
    load_0_17_2  segment_prefix_ub_848  1
    load_0_17_2  free_load_conservation_882  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_3  arc_capacity_622  -20
    arc_0_17_3  connected_order_arc_623  -15
    arc_0_17_3  in_degree_850  1
    arc_0_17_3  out_degree_877  1
    arc_0_17_3  original_T_including_depot_unload_930  1.0510800781097112e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_3  arc_capacity_622  1
    load_0_17_3  segment_load_conservation_853  -1
    load_0_17_3  segment_prefix_lb_854  1
    load_0_17_3  segment_prefix_ub_855  1
    load_0_17_3  free_load_conservation_882  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_4  arc_capacity_624  -20
    arc_0_17_4  connected_order_arc_625  -15
    arc_0_17_4  in_degree_857  1
    arc_0_17_4  out_degree_877  1
    arc_0_17_4  original_T_including_depot_unload_930  8.8580487162181055e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_4  arc_capacity_624  1
    load_0_17_4  segment_load_conservation_860  -1
    load_0_17_4  segment_prefix_lb_861  1
    load_0_17_4  segment_prefix_ub_862  1
    load_0_17_4  free_load_conservation_882  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_5  arc_capacity_626  -20
    arc_0_17_5  connected_order_arc_627  -15
    arc_0_17_5  in_degree_864  1
    arc_0_17_5  out_degree_877  1
    arc_0_17_5  original_T_including_depot_unload_930  8.6958069185371107e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_5  arc_capacity_626  1
    load_0_17_5  segment_load_conservation_867  -1
    load_0_17_5  segment_prefix_lb_868  1
    load_0_17_5  segment_prefix_ub_869  1
    load_0_17_5  free_load_conservation_882  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_6  arc_capacity_628  -20
    arc_0_17_6  connected_order_arc_629  -15
    arc_0_17_6  in_degree_871  1
    arc_0_17_6  out_degree_877  1
    arc_0_17_6  original_T_including_depot_unload_930  1.1989066345879348e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_6  arc_capacity_628  1
    load_0_17_6  segment_load_conservation_874  -1
    load_0_17_6  segment_prefix_lb_875  1
    load_0_17_6  segment_prefix_ub_876  1
    load_0_17_6  free_load_conservation_882  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_18  arc_capacity_630  -20
    arc_0_17_18  connected_order_arc_631  -15
    arc_0_17_18  out_degree_877  1
    arc_0_17_18  in_degree_884  1
    arc_0_17_18  original_T_including_depot_unload_930  4.8781034218421996e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_18  arc_capacity_630  1
    load_0_17_18  free_load_conservation_882  1
    load_0_17_18  free_load_conservation_888  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_19  arc_capacity_632  -20
    arc_0_17_19  connected_order_arc_633  -15
    arc_0_17_19  out_degree_877  1
    arc_0_17_19  in_degree_890  1
    arc_0_17_19  original_T_including_depot_unload_930  2.4147485851762935e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_19  arc_capacity_632  1
    load_0_17_19  free_load_conservation_882  1
    load_0_17_19  free_load_conservation_894  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_20  arc_capacity_634  -20
    arc_0_17_20  connected_order_arc_635  -15
    arc_0_17_20  out_degree_877  1
    arc_0_17_20  in_degree_896  1
    arc_0_17_20  original_T_including_depot_unload_930  6.0985881995898160e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_20  arc_capacity_634  1
    load_0_17_20  free_load_conservation_882  1
    load_0_17_20  free_load_conservation_900  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_21  arc_capacity_636  -20
    arc_0_17_21  connected_order_arc_637  -15
    arc_0_17_21  out_degree_877  1
    arc_0_17_21  in_degree_902  1
    arc_0_17_21  original_T_including_depot_unload_930  1.4088953223409719e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_21  arc_capacity_636  1
    load_0_17_21  free_load_conservation_882  1
    load_0_17_21  free_load_conservation_906  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_22  arc_capacity_638  -20
    arc_0_17_22  connected_order_arc_639  -15
    arc_0_17_22  out_degree_877  1
    arc_0_17_22  in_degree_908  1
    arc_0_17_22  original_T_including_depot_unload_930  6.4419272207888969e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_22  arc_capacity_638  1
    load_0_17_22  free_load_conservation_882  1
    load_0_17_22  free_load_conservation_912  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_23  arc_capacity_640  -20
    arc_0_17_23  connected_order_arc_641  -15
    arc_0_17_23  out_degree_877  1
    arc_0_17_23  in_degree_914  1
    arc_0_17_23  original_T_including_depot_unload_930  2.1214998192647863e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_23  arc_capacity_640  1
    load_0_17_23  free_load_conservation_882  1
    load_0_17_23  free_load_conservation_918  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_24  arc_capacity_642  -20
    arc_0_17_24  connected_order_arc_643  -15
    arc_0_17_24  out_degree_877  1
    arc_0_17_24  in_degree_920  1
    arc_0_17_24  original_T_including_depot_unload_930  8.4962277657921186e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_24  arc_capacity_642  1
    load_0_17_24  free_load_conservation_882  1
    load_0_17_24  free_load_conservation_924  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_0  arc_capacity_644  -20
    arc_0_18_0  depot_return_or_bypass_834  1
    arc_0_18_0  out_degree_883  1
    arc_0_18_0  original_T_including_depot_unload_930  1.4501558573355060e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_0  arc_capacity_644  1
    load_0_18_0  free_load_conservation_888  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_1  arc_capacity_645  -20
    arc_0_18_1  connected_order_arc_646  -15
    arc_0_18_1  in_degree_836  1
    arc_0_18_1  out_degree_883  1
    arc_0_18_1  original_T_including_depot_unload_930  1.3132316623300278e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_1  arc_capacity_645  1
    load_0_18_1  segment_load_conservation_839  -1
    load_0_18_1  segment_prefix_lb_840  1
    load_0_18_1  segment_prefix_ub_841  1
    load_0_18_1  free_load_conservation_888  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_2  arc_capacity_647  -20
    arc_0_18_2  connected_order_arc_648  -15
    arc_0_18_2  in_degree_843  1
    arc_0_18_2  out_degree_883  1
    arc_0_18_2  original_T_including_depot_unload_930  1.3110718450902477e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_2  arc_capacity_647  1
    load_0_18_2  segment_load_conservation_846  -1
    load_0_18_2  segment_prefix_lb_847  1
    load_0_18_2  segment_prefix_ub_848  1
    load_0_18_2  free_load_conservation_888  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_3  arc_capacity_649  -20
    arc_0_18_3  connected_order_arc_650  -15
    arc_0_18_3  in_degree_850  1
    arc_0_18_3  out_degree_883  1
    arc_0_18_3  original_T_including_depot_unload_930  1.3174943724568802e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_3  arc_capacity_649  1
    load_0_18_3  segment_load_conservation_853  -1
    load_0_18_3  segment_prefix_lb_854  1
    load_0_18_3  segment_prefix_ub_855  1
    load_0_18_3  free_load_conservation_888  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_4  arc_capacity_651  -20
    arc_0_18_4  connected_order_arc_652  -15
    arc_0_18_4  in_degree_857  1
    arc_0_18_4  out_degree_883  1
    arc_0_18_4  original_T_including_depot_unload_930  1.0428409649002836e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_4  arc_capacity_651  1
    load_0_18_4  segment_load_conservation_860  -1
    load_0_18_4  segment_prefix_lb_861  1
    load_0_18_4  segment_prefix_ub_862  1
    load_0_18_4  free_load_conservation_888  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_5  arc_capacity_653  -20
    arc_0_18_5  connected_order_arc_654  -15
    arc_0_18_5  in_degree_864  1
    arc_0_18_5  out_degree_883  1
    arc_0_18_5  original_T_including_depot_unload_930  8.2066682484686987e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_5  arc_capacity_653  1
    load_0_18_5  segment_load_conservation_867  -1
    load_0_18_5  segment_prefix_lb_868  1
    load_0_18_5  segment_prefix_ub_869  1
    load_0_18_5  free_load_conservation_888  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_6  arc_capacity_655  -20
    arc_0_18_6  connected_order_arc_656  -15
    arc_0_18_6  in_degree_871  1
    arc_0_18_6  out_degree_883  1
    arc_0_18_6  original_T_including_depot_unload_930  1.1016218375294079e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_6  arc_capacity_655  1
    load_0_18_6  segment_load_conservation_874  -1
    load_0_18_6  segment_prefix_lb_875  1
    load_0_18_6  segment_prefix_ub_876  1
    load_0_18_6  free_load_conservation_888  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_17  arc_capacity_657  -20
    arc_0_18_17  connected_order_arc_658  -15
    arc_0_18_17  in_degree_878  1
    arc_0_18_17  out_degree_883  1
    arc_0_18_17  original_T_including_depot_unload_930  4.8781034218421996e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_17  arc_capacity_657  1
    load_0_18_17  free_load_conservation_882  -1
    load_0_18_17  free_load_conservation_888  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_19  arc_capacity_659  -20
    arc_0_18_19  connected_order_arc_660  -15
    arc_0_18_19  out_degree_883  1
    arc_0_18_19  in_degree_890  1
    arc_0_18_19  original_T_including_depot_unload_930  2.4496137598598170e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_19  arc_capacity_659  1
    load_0_18_19  free_load_conservation_888  1
    load_0_18_19  free_load_conservation_894  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_20  arc_capacity_661  -20
    arc_0_18_20  connected_order_arc_662  -15
    arc_0_18_20  out_degree_883  1
    arc_0_18_20  in_degree_896  1
    arc_0_18_20  original_T_including_depot_unload_930  5.0525672969651123e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_20  arc_capacity_661  1
    load_0_18_20  free_load_conservation_888  1
    load_0_18_20  free_load_conservation_900  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_21  arc_capacity_663  -20
    arc_0_18_21  connected_order_arc_664  -15
    arc_0_18_21  out_degree_883  1
    arc_0_18_21  in_degree_902  1
    arc_0_18_21  original_T_including_depot_unload_930  1.6906177970488723e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_21  arc_capacity_663  1
    load_0_18_21  free_load_conservation_888  1
    load_0_18_21  free_load_conservation_906  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_22  arc_capacity_665  -20
    arc_0_18_22  connected_order_arc_666  -15
    arc_0_18_22  out_degree_883  1
    arc_0_18_22  in_degree_908  1
    arc_0_18_22  original_T_including_depot_unload_930  7.6789230776331749e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_22  arc_capacity_665  1
    load_0_18_22  free_load_conservation_888  1
    load_0_18_22  free_load_conservation_912  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_23  arc_capacity_667  -20
    arc_0_18_23  connected_order_arc_668  -15
    arc_0_18_23  out_degree_883  1
    arc_0_18_23  in_degree_914  1
    arc_0_18_23  original_T_including_depot_unload_930  1.8780729343410642e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_23  arc_capacity_667  1
    load_0_18_23  free_load_conservation_888  1
    load_0_18_23  free_load_conservation_918  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_24  arc_capacity_669  -20
    arc_0_18_24  connected_order_arc_670  -15
    arc_0_18_24  out_degree_883  1
    arc_0_18_24  in_degree_920  1
    arc_0_18_24  original_T_including_depot_unload_930  1.0875821153726588e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_24  arc_capacity_669  1
    load_0_18_24  free_load_conservation_888  1
    load_0_18_24  free_load_conservation_924  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_0  arc_capacity_671  -20
    arc_0_19_0  depot_return_or_bypass_834  1
    arc_0_19_0  out_degree_889  1
    arc_0_19_0  original_T_including_depot_unload_930  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_0  arc_capacity_671  1
    load_0_19_0  free_load_conservation_894  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_1  arc_capacity_672  -20
    arc_0_19_1  connected_order_arc_673  -15
    arc_0_19_1  in_degree_836  1
    arc_0_19_1  out_degree_889  1
    arc_0_19_1  original_T_including_depot_unload_930  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_1  arc_capacity_672  1
    load_0_19_1  segment_load_conservation_839  -1
    load_0_19_1  segment_prefix_lb_840  1
    load_0_19_1  segment_prefix_ub_841  1
    load_0_19_1  free_load_conservation_894  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_2  arc_capacity_674  -20
    arc_0_19_2  connected_order_arc_675  -15
    arc_0_19_2  in_degree_843  1
    arc_0_19_2  out_degree_889  1
    arc_0_19_2  original_T_including_depot_unload_930  1.7303231472353602e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_2  arc_capacity_674  1
    load_0_19_2  segment_load_conservation_846  -1
    load_0_19_2  segment_prefix_lb_847  1
    load_0_19_2  segment_prefix_ub_848  1
    load_0_19_2  free_load_conservation_894  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_3  arc_capacity_676  -20
    arc_0_19_3  connected_order_arc_677  -15
    arc_0_19_3  in_degree_850  1
    arc_0_19_3  out_degree_889  1
    arc_0_19_3  original_T_including_depot_unload_930  1.5184659007075070e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_3  arc_capacity_676  1
    load_0_19_3  segment_load_conservation_853  -1
    load_0_19_3  segment_prefix_lb_854  1
    load_0_19_3  segment_prefix_ub_855  1
    load_0_19_3  free_load_conservation_894  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_4  arc_capacity_678  -20
    arc_0_19_4  connected_order_arc_679  -15
    arc_0_19_4  in_degree_857  1
    arc_0_19_4  out_degree_889  1
    arc_0_19_4  original_T_including_depot_unload_930  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_4  arc_capacity_678  1
    load_0_19_4  segment_load_conservation_860  -1
    load_0_19_4  segment_prefix_lb_861  1
    load_0_19_4  segment_prefix_ub_862  1
    load_0_19_4  free_load_conservation_894  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_5  arc_capacity_680  -20
    arc_0_19_5  connected_order_arc_681  -15
    arc_0_19_5  in_degree_864  1
    arc_0_19_5  out_degree_889  1
    arc_0_19_5  original_T_including_depot_unload_930  1.6292966848558842e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_5  arc_capacity_680  1
    load_0_19_5  segment_load_conservation_867  -1
    load_0_19_5  segment_prefix_lb_868  1
    load_0_19_5  segment_prefix_ub_869  1
    load_0_19_5  free_load_conservation_894  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_6  arc_capacity_682  -20
    arc_0_19_6  connected_order_arc_683  -15
    arc_0_19_6  in_degree_871  1
    arc_0_19_6  out_degree_889  1
    arc_0_19_6  original_T_including_depot_unload_930  1.3727638439182763e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_6  arc_capacity_682  1
    load_0_19_6  segment_load_conservation_874  -1
    load_0_19_6  segment_prefix_lb_875  1
    load_0_19_6  segment_prefix_ub_876  1
    load_0_19_6  free_load_conservation_894  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_17  arc_capacity_684  -20
    arc_0_19_17  connected_order_arc_685  -15
    arc_0_19_17  in_degree_878  1
    arc_0_19_17  out_degree_889  1
    arc_0_19_17  original_T_including_depot_unload_930  2.4147485851762935e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_17  arc_capacity_684  1
    load_0_19_17  free_load_conservation_882  -1
    load_0_19_17  free_load_conservation_894  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_18  arc_capacity_686  -20
    arc_0_19_18  connected_order_arc_687  -15
    arc_0_19_18  in_degree_884  1
    arc_0_19_18  out_degree_889  1
    arc_0_19_18  original_T_including_depot_unload_930  2.4496137598598170e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_18  arc_capacity_686  1
    load_0_19_18  free_load_conservation_888  -1
    load_0_19_18  free_load_conservation_894  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_20  arc_capacity_688  -20
    arc_0_19_20  connected_order_arc_689  -15
    arc_0_19_20  out_degree_889  1
    arc_0_19_20  in_degree_896  1
    arc_0_19_20  original_T_including_depot_unload_930  1.9462564869425171e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_20  arc_capacity_688  1
    load_0_19_20  free_load_conservation_894  1
    load_0_19_20  free_load_conservation_900  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_21  arc_capacity_690  -20
    arc_0_19_21  connected_order_arc_691  -15
    arc_0_19_21  out_degree_889  1
    arc_0_19_21  in_degree_902  1
    arc_0_19_21  original_T_including_depot_unload_930  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_21  arc_capacity_690  1
    load_0_19_21  free_load_conservation_894  1
    load_0_19_21  free_load_conservation_906  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_22  arc_capacity_692  -20
    arc_0_19_22  connected_order_arc_693  -15
    arc_0_19_22  out_degree_889  1
    arc_0_19_22  in_degree_908  1
    arc_0_19_22  original_T_including_depot_unload_930  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_22  arc_capacity_692  1
    load_0_19_22  free_load_conservation_894  1
    load_0_19_22  free_load_conservation_912  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_23  arc_capacity_694  -20
    arc_0_19_23  connected_order_arc_695  -15
    arc_0_19_23  out_degree_889  1
    arc_0_19_23  in_degree_914  1
    arc_0_19_23  original_T_including_depot_unload_930  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_23  arc_capacity_694  1
    load_0_19_23  free_load_conservation_894  1
    load_0_19_23  free_load_conservation_918  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_24  arc_capacity_696  -20
    arc_0_19_24  connected_order_arc_697  -15
    arc_0_19_24  out_degree_889  1
    arc_0_19_24  in_degree_920  1
    arc_0_19_24  original_T_including_depot_unload_930  1.6231508478292610e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_24  arc_capacity_696  1
    load_0_19_24  free_load_conservation_894  1
    load_0_19_24  free_load_conservation_924  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_0  arc_capacity_698  -20
    arc_0_20_0  depot_return_or_bypass_834  1
    arc_0_20_0  out_degree_895  1
    arc_0_20_0  original_T_including_depot_unload_930  9.5330620720858735e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_0  arc_capacity_698  1
    load_0_20_0  free_load_conservation_900  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_1  arc_capacity_699  -20
    arc_0_20_1  connected_order_arc_700  -15
    arc_0_20_1  in_degree_836  1
    arc_0_20_1  out_degree_895  1
    arc_0_20_1  original_T_including_depot_unload_930  8.4968861461374138e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_1  arc_capacity_699  1
    load_0_20_1  segment_load_conservation_839  -1
    load_0_20_1  segment_prefix_lb_840  1
    load_0_20_1  segment_prefix_ub_841  1
    load_0_20_1  free_load_conservation_900  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_2  arc_capacity_701  -20
    arc_0_20_2  connected_order_arc_702  -15
    arc_0_20_2  in_degree_843  1
    arc_0_20_2  out_degree_895  1
    arc_0_20_2  original_T_including_depot_unload_930  9.6598937061987863e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_2  arc_capacity_701  1
    load_0_20_2  segment_load_conservation_846  -1
    load_0_20_2  segment_prefix_lb_847  1
    load_0_20_2  segment_prefix_ub_848  1
    load_0_20_2  free_load_conservation_900  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_3  arc_capacity_703  -20
    arc_0_20_3  connected_order_arc_704  -15
    arc_0_20_3  in_degree_850  1
    arc_0_20_3  out_degree_895  1
    arc_0_20_3  original_T_including_depot_unload_930  904.837890445026
    MARKER    'MARKER'                 'INTEND'
    load_0_20_3  arc_capacity_703  1
    load_0_20_3  segment_load_conservation_853  -1
    load_0_20_3  segment_prefix_lb_854  1
    load_0_20_3  segment_prefix_ub_855  1
    load_0_20_3  free_load_conservation_900  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_4  arc_capacity_705  -20
    arc_0_20_4  connected_order_arc_706  -15
    arc_0_20_4  in_degree_857  1
    arc_0_20_4  out_degree_895  1
    arc_0_20_4  original_T_including_depot_unload_930  5.8292761965990132e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_4  arc_capacity_705  1
    load_0_20_4  segment_load_conservation_860  -1
    load_0_20_4  segment_prefix_lb_861  1
    load_0_20_4  segment_prefix_ub_862  1
    load_0_20_4  free_load_conservation_900  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_5  arc_capacity_707  -20
    arc_0_20_5  connected_order_arc_708  -15
    arc_0_20_5  in_degree_864  1
    arc_0_20_5  out_degree_895  1
    arc_0_20_5  original_T_including_depot_unload_930  3.1728416035596246e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_5  arc_capacity_707  1
    load_0_20_5  segment_load_conservation_867  -1
    load_0_20_5  segment_prefix_lb_868  1
    load_0_20_5  segment_prefix_ub_869  1
    load_0_20_5  free_load_conservation_900  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_6  arc_capacity_709  -20
    arc_0_20_6  connected_order_arc_710  -15
    arc_0_20_6  in_degree_871  1
    arc_0_20_6  out_degree_895  1
    arc_0_20_6  original_T_including_depot_unload_930  6.2159179673866879e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_6  arc_capacity_709  1
    load_0_20_6  segment_load_conservation_874  -1
    load_0_20_6  segment_prefix_lb_875  1
    load_0_20_6  segment_prefix_ub_876  1
    load_0_20_6  free_load_conservation_900  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_17  arc_capacity_711  -20
    arc_0_20_17  connected_order_arc_712  -15
    arc_0_20_17  in_degree_878  1
    arc_0_20_17  out_degree_895  1
    arc_0_20_17  original_T_including_depot_unload_930  6.0985881995898160e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_17  arc_capacity_711  1
    load_0_20_17  free_load_conservation_882  -1
    load_0_20_17  free_load_conservation_900  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_18  arc_capacity_713  -20
    arc_0_20_18  connected_order_arc_714  -15
    arc_0_20_18  in_degree_884  1
    arc_0_20_18  out_degree_895  1
    arc_0_20_18  original_T_including_depot_unload_930  5.0525672969651123e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_18  arc_capacity_713  1
    load_0_20_18  free_load_conservation_888  -1
    load_0_20_18  free_load_conservation_900  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_19  arc_capacity_715  -20
    arc_0_20_19  connected_order_arc_716  -15
    arc_0_20_19  in_degree_890  1
    arc_0_20_19  out_degree_895  1
    arc_0_20_19  original_T_including_depot_unload_930  1.9462564869425171e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_19  arc_capacity_715  1
    load_0_20_19  free_load_conservation_894  -1
    load_0_20_19  free_load_conservation_900  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_21  arc_capacity_717  -20
    arc_0_20_21  connected_order_arc_718  -15
    arc_0_20_21  out_degree_895  1
    arc_0_20_21  in_degree_902  1
    arc_0_20_21  original_T_including_depot_unload_930  1.2674827380665711e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_21  arc_capacity_717  1
    load_0_20_21  free_load_conservation_900  1
    load_0_20_21  free_load_conservation_906  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_22  arc_capacity_719  -20
    arc_0_20_22  connected_order_arc_720  -15
    arc_0_20_22  out_degree_895  1
    arc_0_20_22  in_degree_908  1
    arc_0_20_22  original_T_including_depot_unload_930  3.3469758905462760e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_22  arc_capacity_719  1
    load_0_20_22  free_load_conservation_900  1
    load_0_20_22  free_load_conservation_912  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_23  arc_capacity_721  -20
    arc_0_20_23  connected_order_arc_722  -15
    arc_0_20_23  out_degree_895  1
    arc_0_20_23  in_degree_914  1
    arc_0_20_23  original_T_including_depot_unload_930  1.5117151439160034e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_23  arc_capacity_721  1
    load_0_20_23  free_load_conservation_900  1
    load_0_20_23  free_load_conservation_918  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_24  arc_capacity_723  -20
    arc_0_20_24  connected_order_arc_724  -15
    arc_0_20_24  out_degree_895  1
    arc_0_20_24  in_degree_920  1
    arc_0_20_24  original_T_including_depot_unload_930  6.7711923781893620e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_24  arc_capacity_723  1
    load_0_20_24  free_load_conservation_900  1
    load_0_20_24  free_load_conservation_924  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_0  arc_capacity_725  -20
    arc_0_21_0  depot_return_or_bypass_834  1
    arc_0_21_0  out_degree_901  1
    arc_0_21_0  original_T_including_depot_unload_930  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_0  arc_capacity_725  1
    load_0_21_0  free_load_conservation_906  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_1  arc_capacity_726  -20
    arc_0_21_1  connected_order_arc_727  -15
    arc_0_21_1  in_degree_836  1
    arc_0_21_1  out_degree_901  1
    arc_0_21_1  original_T_including_depot_unload_930  4.5128490093732506e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_1  arc_capacity_726  1
    load_0_21_1  segment_load_conservation_839  -1
    load_0_21_1  segment_prefix_lb_840  1
    load_0_21_1  segment_prefix_ub_841  1
    load_0_21_1  free_load_conservation_906  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_2  arc_capacity_728  -20
    arc_0_21_2  connected_order_arc_729  -15
    arc_0_21_2  in_degree_843  1
    arc_0_21_2  out_degree_901  1
    arc_0_21_2  original_T_including_depot_unload_930  4.6128219015626763e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_2  arc_capacity_728  1
    load_0_21_2  segment_load_conservation_846  -1
    load_0_21_2  segment_prefix_lb_847  1
    load_0_21_2  segment_prefix_ub_848  1
    load_0_21_2  free_load_conservation_906  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_3  arc_capacity_730  -20
    arc_0_21_3  connected_order_arc_731  -15
    arc_0_21_3  in_degree_850  1
    arc_0_21_3  out_degree_901  1
    arc_0_21_3  original_T_including_depot_unload_930  3.7315439746742123e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_3  arc_capacity_730  1
    load_0_21_3  segment_load_conservation_853  -1
    load_0_21_3  segment_prefix_lb_854  1
    load_0_21_3  segment_prefix_ub_855  1
    load_0_21_3  free_load_conservation_906  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_4  arc_capacity_732  -20
    arc_0_21_4  connected_order_arc_733  -15
    arc_0_21_4  in_degree_857  1
    arc_0_21_4  out_degree_901  1
    arc_0_21_4  original_T_including_depot_unload_930  6.8976718276177132e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_4  arc_capacity_732  1
    load_0_21_4  segment_load_conservation_860  -1
    load_0_21_4  segment_prefix_lb_861  1
    load_0_21_4  segment_prefix_ub_862  1
    load_0_21_4  free_load_conservation_906  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_5  arc_capacity_734  -20
    arc_0_21_5  connected_order_arc_735  -15
    arc_0_21_5  in_degree_864  1
    arc_0_21_5  out_degree_901  1
    arc_0_21_5  original_T_including_depot_unload_930  1.0758099325648966e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_5  arc_capacity_734  1
    load_0_21_5  segment_load_conservation_867  -1
    load_0_21_5  segment_prefix_lb_868  1
    load_0_21_5  segment_prefix_ub_869  1
    load_0_21_5  free_load_conservation_906  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_6  arc_capacity_736  -20
    arc_0_21_6  connected_order_arc_737  -15
    arc_0_21_6  in_degree_871  1
    arc_0_21_6  out_degree_901  1
    arc_0_21_6  original_T_including_depot_unload_930  1.1341050580477483e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_6  arc_capacity_736  1
    load_0_21_6  segment_load_conservation_874  -1
    load_0_21_6  segment_prefix_lb_875  1
    load_0_21_6  segment_prefix_ub_876  1
    load_0_21_6  free_load_conservation_906  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_17  arc_capacity_738  -20
    arc_0_21_17  connected_order_arc_739  -15
    arc_0_21_17  in_degree_878  1
    arc_0_21_17  out_degree_901  1
    arc_0_21_17  original_T_including_depot_unload_930  1.4088953223409719e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_17  arc_capacity_738  1
    load_0_21_17  free_load_conservation_882  -1
    load_0_21_17  free_load_conservation_906  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_18  arc_capacity_740  -20
    arc_0_21_18  connected_order_arc_741  -15
    arc_0_21_18  in_degree_884  1
    arc_0_21_18  out_degree_901  1
    arc_0_21_18  original_T_including_depot_unload_930  1.6906177970488723e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_18  arc_capacity_740  1
    load_0_21_18  free_load_conservation_888  -1
    load_0_21_18  free_load_conservation_906  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_19  arc_capacity_742  -20
    arc_0_21_19  connected_order_arc_743  -15
    arc_0_21_19  in_degree_890  1
    arc_0_21_19  out_degree_901  1
    arc_0_21_19  original_T_including_depot_unload_930  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_19  arc_capacity_742  1
    load_0_21_19  free_load_conservation_894  -1
    load_0_21_19  free_load_conservation_906  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_20  arc_capacity_744  -20
    arc_0_21_20  connected_order_arc_745  -15
    arc_0_21_20  in_degree_896  1
    arc_0_21_20  out_degree_901  1
    arc_0_21_20  original_T_including_depot_unload_930  1.2674827380665711e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_20  arc_capacity_744  1
    load_0_21_20  free_load_conservation_900  -1
    load_0_21_20  free_load_conservation_906  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_22  arc_capacity_746  -20
    arc_0_21_22  connected_order_arc_747  -15
    arc_0_21_22  out_degree_901  1
    arc_0_21_22  in_degree_908  1
    arc_0_21_22  original_T_including_depot_unload_930  9.3962613467893414e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_22  arc_capacity_746  1
    load_0_21_22  free_load_conservation_906  1
    load_0_21_22  free_load_conservation_912  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_23  arc_capacity_748  -20
    arc_0_21_23  connected_order_arc_749  -15
    arc_0_21_23  out_degree_901  1
    arc_0_21_23  in_degree_914  1
    arc_0_21_23  original_T_including_depot_unload_930  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_23  arc_capacity_748  1
    load_0_21_23  free_load_conservation_906  1
    load_0_21_23  free_load_conservation_918  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_24  arc_capacity_750  -20
    arc_0_21_24  connected_order_arc_751  -15
    arc_0_21_24  out_degree_901  1
    arc_0_21_24  in_degree_920  1
    arc_0_21_24  original_T_including_depot_unload_930  603.649383070884
    MARKER    'MARKER'                 'INTEND'
    load_0_21_24  arc_capacity_750  1
    load_0_21_24  free_load_conservation_906  1
    load_0_21_24  free_load_conservation_924  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_0  arc_capacity_752  -20
    arc_0_22_0  depot_return_or_bypass_834  1
    arc_0_22_0  out_degree_907  1
    arc_0_22_0  original_T_including_depot_unload_930  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_0  arc_capacity_752  1
    load_0_22_0  free_load_conservation_912  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_1  arc_capacity_753  -20
    arc_0_22_1  connected_order_arc_754  -15
    arc_0_22_1  in_degree_836  1
    arc_0_22_1  out_degree_907  1
    arc_0_22_1  original_T_including_depot_unload_930  545.439458844012
    MARKER    'MARKER'                 'INTEND'
    load_0_22_1  arc_capacity_753  1
    load_0_22_1  segment_load_conservation_839  -1
    load_0_22_1  segment_prefix_lb_840  1
    load_0_22_1  segment_prefix_ub_841  1
    load_0_22_1  free_load_conservation_912  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_2  arc_capacity_755  -20
    arc_0_22_2  connected_order_arc_756  -15
    arc_0_22_2  in_degree_843  1
    arc_0_22_2  out_degree_907  1
    arc_0_22_2  original_T_including_depot_unload_930  6.3648699141452130e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_2  arc_capacity_755  1
    load_0_22_2  segment_load_conservation_846  -1
    load_0_22_2  segment_prefix_lb_847  1
    load_0_22_2  segment_prefix_ub_848  1
    load_0_22_2  free_load_conservation_912  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_3  arc_capacity_757  -20
    arc_0_22_3  connected_order_arc_758  -15
    arc_0_22_3  in_degree_850  1
    arc_0_22_3  out_degree_907  1
    arc_0_22_3  original_T_including_depot_unload_930  5.7237486782756332e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_3  arc_capacity_757  1
    load_0_22_3  segment_load_conservation_853  -1
    load_0_22_3  segment_prefix_lb_854  1
    load_0_22_3  segment_prefix_ub_855  1
    load_0_22_3  free_load_conservation_912  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_4  arc_capacity_759  -20
    arc_0_22_4  connected_order_arc_760  -15
    arc_0_22_4  in_degree_857  1
    arc_0_22_4  out_degree_907  1
    arc_0_22_4  original_T_including_depot_unload_930  2.7570828838654035e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_4  arc_capacity_759  1
    load_0_22_4  segment_load_conservation_860  -1
    load_0_22_4  segment_prefix_lb_861  1
    load_0_22_4  segment_prefix_ub_862  1
    load_0_22_4  free_load_conservation_912  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_5  arc_capacity_761  -20
    arc_0_22_5  connected_order_arc_762  -15
    arc_0_22_5  in_degree_864  1
    arc_0_22_5  out_degree_907  1
    arc_0_22_5  original_T_including_depot_unload_930  3.1069481377857926e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_5  arc_capacity_761  1
    load_0_22_5  segment_load_conservation_867  -1
    load_0_22_5  segment_prefix_lb_868  1
    load_0_22_5  segment_prefix_ub_869  1
    load_0_22_5  free_load_conservation_912  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_6  arc_capacity_763  -20
    arc_0_22_6  connected_order_arc_764  -15
    arc_0_22_6  in_degree_871  1
    arc_0_22_6  out_degree_907  1
    arc_0_22_6  original_T_including_depot_unload_930  6.1561452832791758e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_6  arc_capacity_763  1
    load_0_22_6  segment_load_conservation_874  -1
    load_0_22_6  segment_prefix_lb_875  1
    load_0_22_6  segment_prefix_ub_876  1
    load_0_22_6  free_load_conservation_912  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_17  arc_capacity_765  -20
    arc_0_22_17  connected_order_arc_766  -15
    arc_0_22_17  in_degree_878  1
    arc_0_22_17  out_degree_907  1
    arc_0_22_17  original_T_including_depot_unload_930  6.4419272207888969e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_17  arc_capacity_765  1
    load_0_22_17  free_load_conservation_882  -1
    load_0_22_17  free_load_conservation_912  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_18  arc_capacity_767  -20
    arc_0_22_18  connected_order_arc_768  -15
    arc_0_22_18  in_degree_884  1
    arc_0_22_18  out_degree_907  1
    arc_0_22_18  original_T_including_depot_unload_930  7.6789230776331749e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_18  arc_capacity_767  1
    load_0_22_18  free_load_conservation_888  -1
    load_0_22_18  free_load_conservation_912  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_19  arc_capacity_769  -20
    arc_0_22_19  connected_order_arc_770  -15
    arc_0_22_19  in_degree_890  1
    arc_0_22_19  out_degree_907  1
    arc_0_22_19  original_T_including_depot_unload_930  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_22_19  arc_capacity_769  1
    load_0_22_19  free_load_conservation_894  -1
    load_0_22_19  free_load_conservation_912  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_20  arc_capacity_771  -20
    arc_0_22_20  connected_order_arc_772  -15
    arc_0_22_20  in_degree_896  1
    arc_0_22_20  out_degree_907  1
    arc_0_22_20  original_T_including_depot_unload_930  3.3469758905462760e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_20  arc_capacity_771  1
    load_0_22_20  free_load_conservation_900  -1
    load_0_22_20  free_load_conservation_912  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_21  arc_capacity_773  -20
    arc_0_22_21  connected_order_arc_774  -15
    arc_0_22_21  in_degree_902  1
    arc_0_22_21  out_degree_907  1
    arc_0_22_21  original_T_including_depot_unload_930  9.3962613467893414e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_21  arc_capacity_773  1
    load_0_22_21  free_load_conservation_906  -1
    load_0_22_21  free_load_conservation_912  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_23  arc_capacity_775  -20
    arc_0_22_23  connected_order_arc_776  -15
    arc_0_22_23  out_degree_907  1
    arc_0_22_23  in_degree_914  1
    arc_0_22_23  original_T_including_depot_unload_930  1.5968108380866881e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_22_23  arc_capacity_775  1
    load_0_22_23  free_load_conservation_912  1
    load_0_22_23  free_load_conservation_918  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_24  arc_capacity_777  -20
    arc_0_22_24  connected_order_arc_778  -15
    arc_0_22_24  out_degree_907  1
    arc_0_22_24  in_degree_920  1
    arc_0_22_24  original_T_including_depot_unload_930  3.4289721135663990e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_24  arc_capacity_777  1
    load_0_22_24  free_load_conservation_912  1
    load_0_22_24  free_load_conservation_924  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_23_0  arc_capacity_779  -20
    arc_0_23_0  depot_return_or_bypass_834  1
    arc_0_23_0  out_degree_913  1
    arc_0_23_0  original_T_including_depot_unload_930  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_23_0  arc_capacity_779  1
    load_0_23_0  free_load_conservation_918  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_23_1  arc_capacity_780  -20
    arc_0_23_1  connected_order_arc_781  -15
    arc_0_23_1  in_degree_836  1
    arc_0_23_1  out_degree_913  1
    arc_0_23_1  original_T_including_depot_unload_930  1.5902582434549993e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_23_1  arc_capacity_780  1
    load_0_23_1  segment_load_conservation_839  -1
    load_0_23_1  segment_prefix_lb_840  1
    load_0_23_1  segment_prefix_ub_841  1
    load_0_23_1  free_load_conservation_918  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_23_2  arc_capacity_782  -20
    arc_0_23_2  connected_order_arc_783  -15
    arc_0_23_2  in_degree_843  1
    arc_0_23_2  out_degree_913  1
    arc_0_23_2  original_T_including_depot_unload_930  2.0162129512771592e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_23_2  arc_capacity_782  1
    load_0_23_2  segment_load_conservation_846  -1
    load_0_23_2  segment_prefix_lb_847  1
    load_0_23_2  segment_prefix_ub_848  1
    load_0_23_2  free_load_conservation_918  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_23_3  arc_capacity_784  -20
    arc_0_23_3  connected_order_arc_785  -15
    arc_0_23_3  in_degree_850  1
    arc_0_23_3  out_degree_913  1
    arc_0_23_3  original_T_including_depot_unload_930  1.8073464544423741e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_23_3  arc_capacity_784  1
    load_0_23_3  segment_load_conservation_853  -1
    load_0_23_3  segment_prefix_lb_854  1
    load_0_23_3  segment_prefix_ub_855  1
    load_0_23_3  free_load_conservation_918  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_23_4  arc_capacity_786  -20
    arc_0_23_4  connected_order_arc_787  -15
    arc_0_23_4  in_degree_857  1
    arc_0_23_4  out_degree_913  1
    arc_0_23_4  original_T_including_depot_unload_930  1.5530568652263394e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_23_4  arc_capacity_786  1
    load_0_23_4  segment_load_conservation_860  -1
    load_0_23_4  segment_prefix_lb_861  1
    load_0_23_4  segment_prefix_ub_862  1
    load_0_23_4  free_load_conservation_918  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_23_5  arc_capacity_788  -20
    arc_0_23_5  connected_order_arc_789  -15
    arc_0_23_5  in_degree_864  1
    arc_0_23_5  out_degree_913  1
    arc_0_23_5  original_T_including_depot_unload_930  1.2927075446362680e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_23_5  arc_capacity_788  1
    load_0_23_5  segment_load_conservation_867  -1
    load_0_23_5  segment_prefix_lb_868  1
    load_0_23_5  segment_prefix_ub_869  1
    load_0_23_5  free_load_conservation_918  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_23_6  arc_capacity_790  -20
    arc_0_23_6  connected_order_arc_791  -15
    arc_0_23_6  in_degree_871  1
    arc_0_23_6  out_degree_913  1
    arc_0_23_6  original_T_including_depot_unload_930  9.8652191996938075e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_23_6  arc_capacity_790  1
    load_0_23_6  segment_load_conservation_874  -1
    load_0_23_6  segment_prefix_lb_875  1
    load_0_23_6  segment_prefix_ub_876  1
    load_0_23_6  free_load_conservation_918  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_23_17  arc_capacity_792  -20
    arc_0_23_17  connected_order_arc_793  -15
    arc_0_23_17  in_degree_878  1
    arc_0_23_17  out_degree_913  1
    arc_0_23_17  original_T_including_depot_unload_930  2.1214998192647863e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_23_17  arc_capacity_792  1
    load_0_23_17  free_load_conservation_882  -1
    load_0_23_17  free_load_conservation_918  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_23_18  arc_capacity_794  -20
    arc_0_23_18  connected_order_arc_795  -15
    arc_0_23_18  in_degree_884  1
    arc_0_23_18  out_degree_913  1
    arc_0_23_18  original_T_including_depot_unload_930  1.8780729343410642e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_23_18  arc_capacity_794  1
    load_0_23_18  free_load_conservation_888  -1
    load_0_23_18  free_load_conservation_918  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_23_19  arc_capacity_796  -20
    arc_0_23_19  connected_order_arc_797  -15
    arc_0_23_19  in_degree_890  1
    arc_0_23_19  out_degree_913  1
    arc_0_23_19  original_T_including_depot_unload_930  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_23_19  arc_capacity_796  1
    load_0_23_19  free_load_conservation_894  -1
    load_0_23_19  free_load_conservation_918  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_23_20  arc_capacity_798  -20
    arc_0_23_20  connected_order_arc_799  -15
    arc_0_23_20  in_degree_896  1
    arc_0_23_20  out_degree_913  1
    arc_0_23_20  original_T_including_depot_unload_930  1.5117151439160034e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_23_20  arc_capacity_798  1
    load_0_23_20  free_load_conservation_900  -1
    load_0_23_20  free_load_conservation_918  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_23_21  arc_capacity_800  -20
    arc_0_23_21  connected_order_arc_801  -15
    arc_0_23_21  in_degree_902  1
    arc_0_23_21  out_degree_913  1
    arc_0_23_21  original_T_including_depot_unload_930  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_23_21  arc_capacity_800  1
    load_0_23_21  free_load_conservation_906  -1
    load_0_23_21  free_load_conservation_918  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_23_22  arc_capacity_802  -20
    arc_0_23_22  connected_order_arc_803  -15
    arc_0_23_22  in_degree_908  1
    arc_0_23_22  out_degree_913  1
    arc_0_23_22  original_T_including_depot_unload_930  1.5968108380866881e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_23_22  arc_capacity_802  1
    load_0_23_22  free_load_conservation_912  -1
    load_0_23_22  free_load_conservation_918  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_23_24  arc_capacity_804  -20
    arc_0_23_24  connected_order_arc_805  -15
    arc_0_23_24  out_degree_913  1
    arc_0_23_24  in_degree_920  1
    arc_0_23_24  original_T_including_depot_unload_930  1.7249161387293191e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_23_24  arc_capacity_804  1
    load_0_23_24  free_load_conservation_918  1
    load_0_23_24  free_load_conservation_924  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_24_0  arc_capacity_806  -20
    arc_0_24_0  depot_return_or_bypass_834  1
    arc_0_24_0  out_degree_919  1
    arc_0_24_0  original_T_including_depot_unload_930  5.4249700630778887e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_24_0  arc_capacity_806  1
    load_0_24_0  free_load_conservation_924  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_24_1  arc_capacity_807  -20
    arc_0_24_1  connected_order_arc_808  -15
    arc_0_24_1  in_degree_836  1
    arc_0_24_1  out_degree_919  1
    arc_0_24_1  original_T_including_depot_unload_930  2.8529311190414518e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_24_1  arc_capacity_807  1
    load_0_24_1  segment_load_conservation_839  -1
    load_0_24_1  segment_prefix_lb_840  1
    load_0_24_1  segment_prefix_ub_841  1
    load_0_24_1  free_load_conservation_924  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_24_2  arc_capacity_809  -20
    arc_0_24_2  connected_order_arc_810  -15
    arc_0_24_2  in_degree_843  1
    arc_0_24_2  out_degree_919  1
    arc_0_24_2  original_T_including_depot_unload_930  3.2367117212973966e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_24_2  arc_capacity_809  1
    load_0_24_2  segment_load_conservation_846  -1
    load_0_24_2  segment_prefix_lb_847  1
    load_0_24_2  segment_prefix_ub_848  1
    load_0_24_2  free_load_conservation_924  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_24_3  arc_capacity_811  -20
    arc_0_24_3  connected_order_arc_812  -15
    arc_0_24_3  in_degree_850  1
    arc_0_24_3  out_degree_919  1
    arc_0_24_3  original_T_including_depot_unload_930  2.3159636865750136e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_24_3  arc_capacity_811  1
    load_0_24_3  segment_load_conservation_853  -1
    load_0_24_3  segment_prefix_lb_854  1
    load_0_24_3  segment_prefix_ub_855  1
    load_0_24_3  free_load_conservation_924  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_24_4  arc_capacity_813  -20
    arc_0_24_4  connected_order_arc_814  -15
    arc_0_24_4  in_degree_857  1
    arc_0_24_4  out_degree_919  1
    arc_0_24_4  original_T_including_depot_unload_930  1.7461252424213140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_24_4  arc_capacity_813  1
    load_0_24_4  segment_load_conservation_860  -1
    load_0_24_4  segment_prefix_lb_861  1
    load_0_24_4  segment_prefix_ub_862  1
    load_0_24_4  free_load_conservation_924  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_24_5  arc_capacity_815  -20
    arc_0_24_5  connected_order_arc_816  -15
    arc_0_24_5  in_degree_864  1
    arc_0_24_5  out_degree_919  1
    arc_0_24_5  original_T_including_depot_unload_930  5.5739415765733247e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_24_5  arc_capacity_815  1
    load_0_24_5  segment_load_conservation_867  -1
    load_0_24_5  segment_prefix_lb_868  1
    load_0_24_5  segment_prefix_ub_869  1
    load_0_24_5  free_load_conservation_924  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_24_6  arc_capacity_817  -20
    arc_0_24_6  connected_order_arc_818  -15
    arc_0_24_6  in_degree_871  1
    arc_0_24_6  out_degree_919  1
    arc_0_24_6  original_T_including_depot_unload_930  7.5688558078083690e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_24_6  arc_capacity_817  1
    load_0_24_6  segment_load_conservation_874  -1
    load_0_24_6  segment_prefix_lb_875  1
    load_0_24_6  segment_prefix_ub_876  1
    load_0_24_6  free_load_conservation_924  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_24_17  arc_capacity_819  -20
    arc_0_24_17  connected_order_arc_820  -15
    arc_0_24_17  in_degree_878  1
    arc_0_24_17  out_degree_919  1
    arc_0_24_17  original_T_including_depot_unload_930  8.4962277657921186e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_24_17  arc_capacity_819  1
    load_0_24_17  free_load_conservation_882  -1
    load_0_24_17  free_load_conservation_924  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_24_18  arc_capacity_821  -20
    arc_0_24_18  connected_order_arc_822  -15
    arc_0_24_18  in_degree_884  1
    arc_0_24_18  out_degree_919  1
    arc_0_24_18  original_T_including_depot_unload_930  1.0875821153726588e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_24_18  arc_capacity_821  1
    load_0_24_18  free_load_conservation_888  -1
    load_0_24_18  free_load_conservation_924  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_24_19  arc_capacity_823  -20
    arc_0_24_19  connected_order_arc_824  -15
    arc_0_24_19  in_degree_890  1
    arc_0_24_19  out_degree_919  1
    arc_0_24_19  original_T_including_depot_unload_930  1.6231508478292610e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_24_19  arc_capacity_823  1
    load_0_24_19  free_load_conservation_894  -1
    load_0_24_19  free_load_conservation_924  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_24_20  arc_capacity_825  -20
    arc_0_24_20  connected_order_arc_826  -15
    arc_0_24_20  in_degree_896  1
    arc_0_24_20  out_degree_919  1
    arc_0_24_20  original_T_including_depot_unload_930  6.7711923781893620e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_24_20  arc_capacity_825  1
    load_0_24_20  free_load_conservation_900  -1
    load_0_24_20  free_load_conservation_924  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_24_21  arc_capacity_827  -20
    arc_0_24_21  connected_order_arc_828  -15
    arc_0_24_21  in_degree_902  1
    arc_0_24_21  out_degree_919  1
    arc_0_24_21  original_T_including_depot_unload_930  603.649383070884
    MARKER    'MARKER'                 'INTEND'
    load_0_24_21  arc_capacity_827  1
    load_0_24_21  free_load_conservation_906  -1
    load_0_24_21  free_load_conservation_924  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_24_22  arc_capacity_829  -20
    arc_0_24_22  connected_order_arc_830  -15
    arc_0_24_22  in_degree_908  1
    arc_0_24_22  out_degree_919  1
    arc_0_24_22  original_T_including_depot_unload_930  3.4289721135663990e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_24_22  arc_capacity_829  1
    load_0_24_22  free_load_conservation_912  -1
    load_0_24_22  free_load_conservation_924  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_24_23  arc_capacity_831  -20
    arc_0_24_23  connected_order_arc_832  -15
    arc_0_24_23  in_degree_914  1
    arc_0_24_23  out_degree_919  1
    arc_0_24_23  original_T_including_depot_unload_930  1.7249161387293191e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_24_23  arc_capacity_831  1
    load_0_24_23  free_load_conservation_918  -1
    load_0_24_23  free_load_conservation_924  1
    visit_1_7  out_degree_1272  -1
    visit_1_7  in_degree_1273  -1
    visit_1_7  order_active_lb_1274  -1
    visit_1_7  order_active_ub_1275  -13
    order_1_7  connected_order_arc_947  -1
    order_1_7  connected_order_arc_949  -1
    order_1_7  connected_order_arc_951  -1
    order_1_7  connected_order_arc_953  -1
    order_1_7  connected_order_arc_955  -1
    order_1_7  connected_order_arc_957  -1
    order_1_7  connected_order_arc_959  -1
    order_1_7  connected_order_arc_961  -1
    order_1_7  connected_order_arc_963  -1
    order_1_7  connected_order_arc_965  -1
    order_1_7  connected_order_arc_967  -1
    order_1_7  connected_order_arc_969  -1
    order_1_7  connected_order_arc_972  1
    order_1_7  connected_order_arc_997  1
    order_1_7  connected_order_arc_1022  1
    order_1_7  connected_order_arc_1047  1
    order_1_7  connected_order_arc_1072  1
    order_1_7  connected_order_arc_1097  1
    order_1_7  connected_order_arc_1122  1
    order_1_7  connected_order_arc_1147  1
    order_1_7  connected_order_arc_1172  1
    order_1_7  connected_order_arc_1197  1
    order_1_7  connected_order_arc_1222  1
    order_1_7  connected_order_arc_1247  1
    order_1_7  order_active_lb_1274  1
    order_1_7  order_active_ub_1275  1
    order_1_7  fixed_segment_relative_order_1355  -1
    visit_1_8  out_degree_1279  -1
    visit_1_8  in_degree_1280  -1
    visit_1_8  order_active_lb_1281  -1
    visit_1_8  order_active_ub_1282  -13
    order_1_8  connected_order_arc_947  1
    order_1_8  connected_order_arc_972  -1
    order_1_8  connected_order_arc_974  -1
    order_1_8  connected_order_arc_976  -1
    order_1_8  connected_order_arc_978  -1
    order_1_8  connected_order_arc_980  -1
    order_1_8  connected_order_arc_982  -1
    order_1_8  connected_order_arc_984  -1
    order_1_8  connected_order_arc_986  -1
    order_1_8  connected_order_arc_988  -1
    order_1_8  connected_order_arc_990  -1
    order_1_8  connected_order_arc_992  -1
    order_1_8  connected_order_arc_994  -1
    order_1_8  connected_order_arc_999  1
    order_1_8  connected_order_arc_1024  1
    order_1_8  connected_order_arc_1049  1
    order_1_8  connected_order_arc_1074  1
    order_1_8  connected_order_arc_1099  1
    order_1_8  connected_order_arc_1124  1
    order_1_8  connected_order_arc_1149  1
    order_1_8  connected_order_arc_1174  1
    order_1_8  connected_order_arc_1199  1
    order_1_8  connected_order_arc_1224  1
    order_1_8  connected_order_arc_1249  1
    order_1_8  order_active_lb_1281  1
    order_1_8  order_active_ub_1282  1
    order_1_8  fixed_segment_relative_order_1355  1
    order_1_8  fixed_segment_relative_order_1356  -1
    visit_1_9  out_degree_1286  -1
    visit_1_9  in_degree_1287  -1
    visit_1_9  order_active_lb_1288  -1
    visit_1_9  order_active_ub_1289  -13
    order_1_9  connected_order_arc_949  1
    order_1_9  connected_order_arc_974  1
    order_1_9  connected_order_arc_997  -1
    order_1_9  connected_order_arc_999  -1
    order_1_9  connected_order_arc_1001  -1
    order_1_9  connected_order_arc_1003  -1
    order_1_9  connected_order_arc_1005  -1
    order_1_9  connected_order_arc_1007  -1
    order_1_9  connected_order_arc_1009  -1
    order_1_9  connected_order_arc_1011  -1
    order_1_9  connected_order_arc_1013  -1
    order_1_9  connected_order_arc_1015  -1
    order_1_9  connected_order_arc_1017  -1
    order_1_9  connected_order_arc_1019  -1
    order_1_9  connected_order_arc_1026  1
    order_1_9  connected_order_arc_1051  1
    order_1_9  connected_order_arc_1076  1
    order_1_9  connected_order_arc_1101  1
    order_1_9  connected_order_arc_1126  1
    order_1_9  connected_order_arc_1151  1
    order_1_9  connected_order_arc_1176  1
    order_1_9  connected_order_arc_1201  1
    order_1_9  connected_order_arc_1226  1
    order_1_9  connected_order_arc_1251  1
    order_1_9  order_active_lb_1288  1
    order_1_9  order_active_ub_1289  1
    order_1_9  fixed_segment_relative_order_1356  1
    order_1_9  fixed_segment_relative_order_1357  -1
    visit_1_10  out_degree_1293  -1
    visit_1_10  in_degree_1294  -1
    visit_1_10  order_active_lb_1295  -1
    visit_1_10  order_active_ub_1296  -13
    order_1_10  connected_order_arc_951  1
    order_1_10  connected_order_arc_976  1
    order_1_10  connected_order_arc_1001  1
    order_1_10  connected_order_arc_1022  -1
    order_1_10  connected_order_arc_1024  -1
    order_1_10  connected_order_arc_1026  -1
    order_1_10  connected_order_arc_1028  -1
    order_1_10  connected_order_arc_1030  -1
    order_1_10  connected_order_arc_1032  -1
    order_1_10  connected_order_arc_1034  -1
    order_1_10  connected_order_arc_1036  -1
    order_1_10  connected_order_arc_1038  -1
    order_1_10  connected_order_arc_1040  -1
    order_1_10  connected_order_arc_1042  -1
    order_1_10  connected_order_arc_1044  -1
    order_1_10  connected_order_arc_1053  1
    order_1_10  connected_order_arc_1078  1
    order_1_10  connected_order_arc_1103  1
    order_1_10  connected_order_arc_1128  1
    order_1_10  connected_order_arc_1153  1
    order_1_10  connected_order_arc_1178  1
    order_1_10  connected_order_arc_1203  1
    order_1_10  connected_order_arc_1228  1
    order_1_10  connected_order_arc_1253  1
    order_1_10  order_active_lb_1295  1
    order_1_10  order_active_ub_1296  1
    order_1_10  fixed_segment_relative_order_1357  1
    order_1_10  fixed_segment_relative_order_1358  -1
    visit_1_11  out_degree_1300  -1
    visit_1_11  in_degree_1301  -1
    visit_1_11  order_active_lb_1302  -1
    visit_1_11  order_active_ub_1303  -13
    order_1_11  connected_order_arc_953  1
    order_1_11  connected_order_arc_978  1
    order_1_11  connected_order_arc_1003  1
    order_1_11  connected_order_arc_1028  1
    order_1_11  connected_order_arc_1047  -1
    order_1_11  connected_order_arc_1049  -1
    order_1_11  connected_order_arc_1051  -1
    order_1_11  connected_order_arc_1053  -1
    order_1_11  connected_order_arc_1055  -1
    order_1_11  connected_order_arc_1057  -1
    order_1_11  connected_order_arc_1059  -1
    order_1_11  connected_order_arc_1061  -1
    order_1_11  connected_order_arc_1063  -1
    order_1_11  connected_order_arc_1065  -1
    order_1_11  connected_order_arc_1067  -1
    order_1_11  connected_order_arc_1069  -1
    order_1_11  connected_order_arc_1080  1
    order_1_11  connected_order_arc_1105  1
    order_1_11  connected_order_arc_1130  1
    order_1_11  connected_order_arc_1155  1
    order_1_11  connected_order_arc_1180  1
    order_1_11  connected_order_arc_1205  1
    order_1_11  connected_order_arc_1230  1
    order_1_11  connected_order_arc_1255  1
    order_1_11  order_active_lb_1302  1
    order_1_11  order_active_ub_1303  1
    order_1_11  fixed_segment_relative_order_1358  1
    visit_1_17  out_degree_1307  -1
    visit_1_17  in_degree_1308  -1
    visit_1_17  order_active_lb_1309  -1
    visit_1_17  order_active_ub_1310  -13
    visit_1_17  service_visit_def_1311  -1
    order_1_17  connected_order_arc_955  1
    order_1_17  connected_order_arc_980  1
    order_1_17  connected_order_arc_1005  1
    order_1_17  connected_order_arc_1030  1
    order_1_17  connected_order_arc_1055  1
    order_1_17  connected_order_arc_1072  -1
    order_1_17  connected_order_arc_1074  -1
    order_1_17  connected_order_arc_1076  -1
    order_1_17  connected_order_arc_1078  -1
    order_1_17  connected_order_arc_1080  -1
    order_1_17  connected_order_arc_1082  -1
    order_1_17  connected_order_arc_1084  -1
    order_1_17  connected_order_arc_1086  -1
    order_1_17  connected_order_arc_1088  -1
    order_1_17  connected_order_arc_1090  -1
    order_1_17  connected_order_arc_1092  -1
    order_1_17  connected_order_arc_1094  -1
    order_1_17  connected_order_arc_1107  1
    order_1_17  connected_order_arc_1132  1
    order_1_17  connected_order_arc_1157  1
    order_1_17  connected_order_arc_1182  1
    order_1_17  connected_order_arc_1207  1
    order_1_17  connected_order_arc_1232  1
    order_1_17  connected_order_arc_1257  1
    order_1_17  order_active_lb_1309  1
    order_1_17  order_active_ub_1310  1
    visit_1_18  out_degree_1313  -1
    visit_1_18  in_degree_1314  -1
    visit_1_18  order_active_lb_1315  -1
    visit_1_18  order_active_ub_1316  -13
    visit_1_18  service_visit_def_1317  -1
    order_1_18  connected_order_arc_957  1
    order_1_18  connected_order_arc_982  1
    order_1_18  connected_order_arc_1007  1
    order_1_18  connected_order_arc_1032  1
    order_1_18  connected_order_arc_1057  1
    order_1_18  connected_order_arc_1082  1
    order_1_18  connected_order_arc_1097  -1
    order_1_18  connected_order_arc_1099  -1
    order_1_18  connected_order_arc_1101  -1
    order_1_18  connected_order_arc_1103  -1
    order_1_18  connected_order_arc_1105  -1
    order_1_18  connected_order_arc_1107  -1
    order_1_18  connected_order_arc_1109  -1
    order_1_18  connected_order_arc_1111  -1
    order_1_18  connected_order_arc_1113  -1
    order_1_18  connected_order_arc_1115  -1
    order_1_18  connected_order_arc_1117  -1
    order_1_18  connected_order_arc_1119  -1
    order_1_18  connected_order_arc_1134  1
    order_1_18  connected_order_arc_1159  1
    order_1_18  connected_order_arc_1184  1
    order_1_18  connected_order_arc_1209  1
    order_1_18  connected_order_arc_1234  1
    order_1_18  connected_order_arc_1259  1
    order_1_18  order_active_lb_1315  1
    order_1_18  order_active_ub_1316  1
    visit_1_19  out_degree_1319  -1
    visit_1_19  in_degree_1320  -1
    visit_1_19  order_active_lb_1321  -1
    visit_1_19  order_active_ub_1322  -13
    visit_1_19  service_visit_def_1323  -1
    order_1_19  connected_order_arc_959  1
    order_1_19  connected_order_arc_984  1
    order_1_19  connected_order_arc_1009  1
    order_1_19  connected_order_arc_1034  1
    order_1_19  connected_order_arc_1059  1
    order_1_19  connected_order_arc_1084  1
    order_1_19  connected_order_arc_1109  1
    order_1_19  connected_order_arc_1122  -1
    order_1_19  connected_order_arc_1124  -1
    order_1_19  connected_order_arc_1126  -1
    order_1_19  connected_order_arc_1128  -1
    order_1_19  connected_order_arc_1130  -1
    order_1_19  connected_order_arc_1132  -1
    order_1_19  connected_order_arc_1134  -1
    order_1_19  connected_order_arc_1136  -1
    order_1_19  connected_order_arc_1138  -1
    order_1_19  connected_order_arc_1140  -1
    order_1_19  connected_order_arc_1142  -1
    order_1_19  connected_order_arc_1144  -1
    order_1_19  connected_order_arc_1161  1
    order_1_19  connected_order_arc_1186  1
    order_1_19  connected_order_arc_1211  1
    order_1_19  connected_order_arc_1236  1
    order_1_19  connected_order_arc_1261  1
    order_1_19  order_active_lb_1321  1
    order_1_19  order_active_ub_1322  1
    visit_1_20  out_degree_1325  -1
    visit_1_20  in_degree_1326  -1
    visit_1_20  order_active_lb_1327  -1
    visit_1_20  order_active_ub_1328  -13
    visit_1_20  service_visit_def_1329  -1
    order_1_20  connected_order_arc_961  1
    order_1_20  connected_order_arc_986  1
    order_1_20  connected_order_arc_1011  1
    order_1_20  connected_order_arc_1036  1
    order_1_20  connected_order_arc_1061  1
    order_1_20  connected_order_arc_1086  1
    order_1_20  connected_order_arc_1111  1
    order_1_20  connected_order_arc_1136  1
    order_1_20  connected_order_arc_1147  -1
    order_1_20  connected_order_arc_1149  -1
    order_1_20  connected_order_arc_1151  -1
    order_1_20  connected_order_arc_1153  -1
    order_1_20  connected_order_arc_1155  -1
    order_1_20  connected_order_arc_1157  -1
    order_1_20  connected_order_arc_1159  -1
    order_1_20  connected_order_arc_1161  -1
    order_1_20  connected_order_arc_1163  -1
    order_1_20  connected_order_arc_1165  -1
    order_1_20  connected_order_arc_1167  -1
    order_1_20  connected_order_arc_1169  -1
    order_1_20  connected_order_arc_1188  1
    order_1_20  connected_order_arc_1213  1
    order_1_20  connected_order_arc_1238  1
    order_1_20  connected_order_arc_1263  1
    order_1_20  order_active_lb_1327  1
    order_1_20  order_active_ub_1328  1
    visit_1_21  out_degree_1331  -1
    visit_1_21  in_degree_1332  -1
    visit_1_21  order_active_lb_1333  -1
    visit_1_21  order_active_ub_1334  -13
    visit_1_21  service_visit_def_1335  -1
    order_1_21  connected_order_arc_963  1
    order_1_21  connected_order_arc_988  1
    order_1_21  connected_order_arc_1013  1
    order_1_21  connected_order_arc_1038  1
    order_1_21  connected_order_arc_1063  1
    order_1_21  connected_order_arc_1088  1
    order_1_21  connected_order_arc_1113  1
    order_1_21  connected_order_arc_1138  1
    order_1_21  connected_order_arc_1163  1
    order_1_21  connected_order_arc_1172  -1
    order_1_21  connected_order_arc_1174  -1
    order_1_21  connected_order_arc_1176  -1
    order_1_21  connected_order_arc_1178  -1
    order_1_21  connected_order_arc_1180  -1
    order_1_21  connected_order_arc_1182  -1
    order_1_21  connected_order_arc_1184  -1
    order_1_21  connected_order_arc_1186  -1
    order_1_21  connected_order_arc_1188  -1
    order_1_21  connected_order_arc_1190  -1
    order_1_21  connected_order_arc_1192  -1
    order_1_21  connected_order_arc_1194  -1
    order_1_21  connected_order_arc_1215  1
    order_1_21  connected_order_arc_1240  1
    order_1_21  connected_order_arc_1265  1
    order_1_21  order_active_lb_1333  1
    order_1_21  order_active_ub_1334  1
    visit_1_22  out_degree_1337  -1
    visit_1_22  in_degree_1338  -1
    visit_1_22  order_active_lb_1339  -1
    visit_1_22  order_active_ub_1340  -13
    visit_1_22  service_visit_def_1341  -1
    order_1_22  connected_order_arc_965  1
    order_1_22  connected_order_arc_990  1
    order_1_22  connected_order_arc_1015  1
    order_1_22  connected_order_arc_1040  1
    order_1_22  connected_order_arc_1065  1
    order_1_22  connected_order_arc_1090  1
    order_1_22  connected_order_arc_1115  1
    order_1_22  connected_order_arc_1140  1
    order_1_22  connected_order_arc_1165  1
    order_1_22  connected_order_arc_1190  1
    order_1_22  connected_order_arc_1197  -1
    order_1_22  connected_order_arc_1199  -1
    order_1_22  connected_order_arc_1201  -1
    order_1_22  connected_order_arc_1203  -1
    order_1_22  connected_order_arc_1205  -1
    order_1_22  connected_order_arc_1207  -1
    order_1_22  connected_order_arc_1209  -1
    order_1_22  connected_order_arc_1211  -1
    order_1_22  connected_order_arc_1213  -1
    order_1_22  connected_order_arc_1215  -1
    order_1_22  connected_order_arc_1217  -1
    order_1_22  connected_order_arc_1219  -1
    order_1_22  connected_order_arc_1242  1
    order_1_22  connected_order_arc_1267  1
    order_1_22  order_active_lb_1339  1
    order_1_22  order_active_ub_1340  1
    visit_1_23  out_degree_1343  -1
    visit_1_23  in_degree_1344  -1
    visit_1_23  order_active_lb_1345  -1
    visit_1_23  order_active_ub_1346  -13
    visit_1_23  service_visit_def_1347  -1
    order_1_23  connected_order_arc_967  1
    order_1_23  connected_order_arc_992  1
    order_1_23  connected_order_arc_1017  1
    order_1_23  connected_order_arc_1042  1
    order_1_23  connected_order_arc_1067  1
    order_1_23  connected_order_arc_1092  1
    order_1_23  connected_order_arc_1117  1
    order_1_23  connected_order_arc_1142  1
    order_1_23  connected_order_arc_1167  1
    order_1_23  connected_order_arc_1192  1
    order_1_23  connected_order_arc_1217  1
    order_1_23  connected_order_arc_1222  -1
    order_1_23  connected_order_arc_1224  -1
    order_1_23  connected_order_arc_1226  -1
    order_1_23  connected_order_arc_1228  -1
    order_1_23  connected_order_arc_1230  -1
    order_1_23  connected_order_arc_1232  -1
    order_1_23  connected_order_arc_1234  -1
    order_1_23  connected_order_arc_1236  -1
    order_1_23  connected_order_arc_1238  -1
    order_1_23  connected_order_arc_1240  -1
    order_1_23  connected_order_arc_1242  -1
    order_1_23  connected_order_arc_1244  -1
    order_1_23  connected_order_arc_1269  1
    order_1_23  order_active_lb_1345  1
    order_1_23  order_active_ub_1346  1
    visit_1_24  out_degree_1349  -1
    visit_1_24  in_degree_1350  -1
    visit_1_24  order_active_lb_1351  -1
    visit_1_24  order_active_ub_1352  -13
    visit_1_24  service_visit_def_1353  -1
    order_1_24  connected_order_arc_969  1
    order_1_24  connected_order_arc_994  1
    order_1_24  connected_order_arc_1019  1
    order_1_24  connected_order_arc_1044  1
    order_1_24  connected_order_arc_1069  1
    order_1_24  connected_order_arc_1094  1
    order_1_24  connected_order_arc_1119  1
    order_1_24  connected_order_arc_1144  1
    order_1_24  connected_order_arc_1169  1
    order_1_24  connected_order_arc_1194  1
    order_1_24  connected_order_arc_1219  1
    order_1_24  connected_order_arc_1244  1
    order_1_24  connected_order_arc_1247  -1
    order_1_24  connected_order_arc_1249  -1
    order_1_24  connected_order_arc_1251  -1
    order_1_24  connected_order_arc_1253  -1
    order_1_24  connected_order_arc_1255  -1
    order_1_24  connected_order_arc_1257  -1
    order_1_24  connected_order_arc_1259  -1
    order_1_24  connected_order_arc_1261  -1
    order_1_24  connected_order_arc_1263  -1
    order_1_24  connected_order_arc_1265  -1
    order_1_24  connected_order_arc_1267  -1
    order_1_24  connected_order_arc_1269  -1
    order_1_24  order_active_lb_1351  1
    order_1_24  order_active_ub_1352  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_0  arc_capacity_931  -25
    arc_1_0_0  depot_departure_or_bypass_1270  1
    arc_1_0_0  depot_return_or_bypass_1271  1
    MARKER    'MARKER'                 'INTEND'
    load_1_0_0  arc_capacity_931  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_7  arc_capacity_932  -25
    arc_1_0_7  depot_departure_or_bypass_1270  1
    arc_1_0_7  in_degree_1273  1
    arc_1_0_7  original_T_including_depot_unload_1359  8.7749189782983967e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_7  arc_capacity_932  1
    load_1_0_7  segment_load_conservation_1276  -1
    load_1_0_7  segment_prefix_lb_1277  1
    load_1_0_7  segment_prefix_ub_1278  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_8  arc_capacity_933  -25
    arc_1_0_8  depot_departure_or_bypass_1270  1
    arc_1_0_8  in_degree_1280  1
    arc_1_0_8  original_T_including_depot_unload_1359  8.7918533905669346e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_8  arc_capacity_933  1
    load_1_0_8  segment_load_conservation_1283  -1
    load_1_0_8  segment_prefix_lb_1284  1
    load_1_0_8  segment_prefix_ub_1285  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_9  arc_capacity_934  -25
    arc_1_0_9  depot_departure_or_bypass_1270  1
    arc_1_0_9  in_degree_1287  1
    arc_1_0_9  original_T_including_depot_unload_1359  7.8195480223834068e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_9  arc_capacity_934  1
    load_1_0_9  segment_load_conservation_1290  -1
    load_1_0_9  segment_prefix_lb_1291  1
    load_1_0_9  segment_prefix_ub_1292  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_10  arc_capacity_935  -25
    arc_1_0_10  depot_departure_or_bypass_1270  1
    arc_1_0_10  in_degree_1294  1
    arc_1_0_10  original_T_including_depot_unload_1359  4.7522445589173662e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_10  arc_capacity_935  1
    load_1_0_10  segment_load_conservation_1297  -1
    load_1_0_10  segment_prefix_lb_1298  1
    load_1_0_10  segment_prefix_ub_1299  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_11  arc_capacity_936  -25
    arc_1_0_11  depot_departure_or_bypass_1270  1
    arc_1_0_11  in_degree_1301  1
    arc_1_0_11  original_T_including_depot_unload_1359  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_11  arc_capacity_936  1
    load_1_0_11  segment_load_conservation_1304  -1
    load_1_0_11  segment_prefix_lb_1305  1
    load_1_0_11  segment_prefix_ub_1306  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_17  arc_capacity_937  -25
    arc_1_0_17  depot_departure_or_bypass_1270  1
    arc_1_0_17  in_degree_1308  1
    arc_1_0_17  original_T_including_depot_unload_1359  1.3396590612935172e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_17  arc_capacity_937  1
    load_1_0_17  free_load_conservation_1312  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_18  arc_capacity_938  -25
    arc_1_0_18  depot_departure_or_bypass_1270  1
    arc_1_0_18  in_degree_1314  1
    arc_1_0_18  original_T_including_depot_unload_1359  1.4501558573355060e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_18  arc_capacity_938  1
    load_1_0_18  free_load_conservation_1318  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_19  arc_capacity_939  -25
    arc_1_0_19  depot_departure_or_bypass_1270  1
    arc_1_0_19  in_degree_1320  1
    arc_1_0_19  original_T_including_depot_unload_1359  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_19  arc_capacity_939  1
    load_1_0_19  free_load_conservation_1324  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_20  arc_capacity_940  -25
    arc_1_0_20  depot_departure_or_bypass_1270  1
    arc_1_0_20  in_degree_1326  1
    arc_1_0_20  original_T_including_depot_unload_1359  9.5330620720858735e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_20  arc_capacity_940  1
    load_1_0_20  free_load_conservation_1330  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_21  arc_capacity_941  -25
    arc_1_0_21  depot_departure_or_bypass_1270  1
    arc_1_0_21  in_degree_1332  1
    arc_1_0_21  original_T_including_depot_unload_1359  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_21  arc_capacity_941  1
    load_1_0_21  free_load_conservation_1336  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_22  arc_capacity_942  -25
    arc_1_0_22  depot_departure_or_bypass_1270  1
    arc_1_0_22  in_degree_1338  1
    arc_1_0_22  original_T_including_depot_unload_1359  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_22  arc_capacity_942  1
    load_1_0_22  free_load_conservation_1342  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_23  arc_capacity_943  -25
    arc_1_0_23  depot_departure_or_bypass_1270  1
    arc_1_0_23  in_degree_1344  1
    arc_1_0_23  original_T_including_depot_unload_1359  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_23  arc_capacity_943  1
    load_1_0_23  free_load_conservation_1348  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_24  arc_capacity_944  -25
    arc_1_0_24  depot_departure_or_bypass_1270  1
    arc_1_0_24  in_degree_1350  1
    arc_1_0_24  original_T_including_depot_unload_1359  5.4249700630778887e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_24  arc_capacity_944  1
    load_1_0_24  free_load_conservation_1354  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_0  arc_capacity_945  -25
    arc_1_7_0  depot_return_or_bypass_1271  1
    arc_1_7_0  out_degree_1272  1
    arc_1_7_0  original_T_including_depot_unload_1359  1.0479182987243917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_0  arc_capacity_945  1
    load_1_7_0  segment_load_conservation_1276  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_8  arc_capacity_946  -25
    arc_1_7_8  connected_order_arc_947  -14
    arc_1_7_8  out_degree_1272  1
    arc_1_7_8  in_degree_1280  1
    arc_1_7_8  original_T_including_depot_unload_1359  2.4155873404211835e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_8  arc_capacity_946  1
    load_1_7_8  segment_load_conservation_1276  1
    load_1_7_8  segment_load_conservation_1283  -1
    load_1_7_8  segment_prefix_lb_1284  1
    load_1_7_8  segment_prefix_ub_1285  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_9  arc_capacity_948  -25
    arc_1_7_9  connected_order_arc_949  -14
    arc_1_7_9  out_degree_1272  1
    arc_1_7_9  in_degree_1287  1
    arc_1_7_9  original_T_including_depot_unload_1359  9.9524628735690555e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_9  arc_capacity_948  1
    load_1_7_9  segment_load_conservation_1276  1
    load_1_7_9  segment_load_conservation_1290  -1
    load_1_7_9  segment_prefix_lb_1291  1
    load_1_7_9  segment_prefix_ub_1292  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_10  arc_capacity_950  -25
    arc_1_7_10  connected_order_arc_951  -14
    arc_1_7_10  out_degree_1272  1
    arc_1_7_10  in_degree_1294  1
    arc_1_7_10  original_T_including_depot_unload_1359  1.1592640472038677e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_10  arc_capacity_950  1
    load_1_7_10  segment_load_conservation_1276  1
    load_1_7_10  segment_load_conservation_1297  -1
    load_1_7_10  segment_prefix_lb_1298  1
    load_1_7_10  segment_prefix_ub_1299  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_11  arc_capacity_952  -25
    arc_1_7_11  connected_order_arc_953  -14
    arc_1_7_11  out_degree_1272  1
    arc_1_7_11  in_degree_1301  1
    arc_1_7_11  original_T_including_depot_unload_1359  9.2235470209829464e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_11  arc_capacity_952  1
    load_1_7_11  segment_load_conservation_1276  1
    load_1_7_11  segment_load_conservation_1304  -1
    load_1_7_11  segment_prefix_lb_1305  1
    load_1_7_11  segment_prefix_ub_1306  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_17  arc_capacity_954  -25
    arc_1_7_17  connected_order_arc_955  -14
    arc_1_7_17  out_degree_1272  1
    arc_1_7_17  in_degree_1308  1
    arc_1_7_17  original_T_including_depot_unload_1359  2.3595978160229652e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_17  arc_capacity_954  1
    load_1_7_17  segment_load_conservation_1276  1
    load_1_7_17  free_load_conservation_1312  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_18  arc_capacity_956  -25
    arc_1_7_18  connected_order_arc_957  -14
    arc_1_7_18  out_degree_1272  1
    arc_1_7_18  in_degree_1314  1
    arc_1_7_18  original_T_including_depot_unload_1359  2.4977279292860885e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_18  arc_capacity_956  1
    load_1_7_18  segment_load_conservation_1276  1
    load_1_7_18  free_load_conservation_1318  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_19  arc_capacity_958  -25
    arc_1_7_19  connected_order_arc_959  -14
    arc_1_7_19  out_degree_1272  1
    arc_1_7_19  in_degree_1320  1
    arc_1_7_19  original_T_including_depot_unload_1359  5.2280951376932137e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_19  arc_capacity_958  1
    load_1_7_19  segment_load_conservation_1276  1
    load_1_7_19  free_load_conservation_1324  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_20  arc_capacity_960  -25
    arc_1_7_20  connected_order_arc_961  -14
    arc_1_7_20  out_degree_1272  1
    arc_1_7_20  in_degree_1326  1
    arc_1_7_20  original_T_including_depot_unload_1359  1.9981042624472673e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_20  arc_capacity_960  1
    load_1_7_20  segment_load_conservation_1276  1
    load_1_7_20  free_load_conservation_1330  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_21  arc_capacity_962  -25
    arc_1_7_21  connected_order_arc_963  -14
    arc_1_7_21  out_degree_1272  1
    arc_1_7_21  in_degree_1332  1
    arc_1_7_21  original_T_including_depot_unload_1359  1.0880068546845516e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_21  arc_capacity_962  1
    load_1_7_21  segment_load_conservation_1276  1
    load_1_7_21  free_load_conservation_1336  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_22  arc_capacity_964  -25
    arc_1_7_22  connected_order_arc_965  -14
    arc_1_7_22  out_degree_1272  1
    arc_1_7_22  in_degree_1338  1
    arc_1_7_22  original_T_including_depot_unload_1359  1.7520337176349503e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_22  arc_capacity_964  1
    load_1_7_22  segment_load_conservation_1276  1
    load_1_7_22  free_load_conservation_1342  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_23  arc_capacity_966  -25
    arc_1_7_23  connected_order_arc_967  -14
    arc_1_7_23  out_degree_1272  1
    arc_1_7_23  in_degree_1344  1
    arc_1_7_23  original_T_including_depot_unload_1359  1.7883808204567979e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_23  arc_capacity_966  1
    load_1_7_23  segment_load_conservation_1276  1
    load_1_7_23  free_load_conservation_1348  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_24  arc_capacity_968  -25
    arc_1_7_24  connected_order_arc_969  -14
    arc_1_7_24  out_degree_1272  1
    arc_1_7_24  in_degree_1350  1
    arc_1_7_24  original_T_including_depot_unload_1359  1.5145600125783847e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_24  arc_capacity_968  1
    load_1_7_24  segment_load_conservation_1276  1
    load_1_7_24  free_load_conservation_1354  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_0  arc_capacity_970  -25
    arc_1_8_0  depot_return_or_bypass_1271  1
    arc_1_8_0  out_degree_1279  1
    arc_1_8_0  original_T_including_depot_unload_1359  887.312716328479
    MARKER    'MARKER'                 'INTEND'
    load_1_8_0  arc_capacity_970  1
    load_1_8_0  segment_load_conservation_1283  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_7  arc_capacity_971  -25
    arc_1_8_7  connected_order_arc_972  -14
    arc_1_8_7  in_degree_1273  1
    arc_1_8_7  out_degree_1279  1
    arc_1_8_7  original_T_including_depot_unload_1359  7.8136221151890174e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_7  arc_capacity_971  1
    load_1_8_7  segment_load_conservation_1276  -1
    load_1_8_7  segment_prefix_lb_1277  1
    load_1_8_7  segment_prefix_ub_1278  1
    load_1_8_7  segment_load_conservation_1283  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_9  arc_capacity_973  -25
    arc_1_8_9  connected_order_arc_974  -14
    arc_1_8_9  out_degree_1279  1
    arc_1_8_9  in_degree_1287  1
    arc_1_8_9  original_T_including_depot_unload_1359  1.1119949880978965e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_9  arc_capacity_973  1
    load_1_8_9  segment_load_conservation_1283  1
    load_1_8_9  segment_load_conservation_1290  -1
    load_1_8_9  segment_prefix_lb_1291  1
    load_1_8_9  segment_prefix_ub_1292  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_10  arc_capacity_975  -25
    arc_1_8_10  connected_order_arc_976  -14
    arc_1_8_10  out_degree_1279  1
    arc_1_8_10  in_degree_1294  1
    arc_1_8_10  original_T_including_depot_unload_1359  4.9711893625650669e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_10  arc_capacity_975  1
    load_1_8_10  segment_load_conservation_1283  1
    load_1_8_10  segment_load_conservation_1297  -1
    load_1_8_10  segment_prefix_lb_1298  1
    load_1_8_10  segment_prefix_ub_1299  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_11  arc_capacity_977  -25
    arc_1_8_11  connected_order_arc_978  -14
    arc_1_8_11  out_degree_1279  1
    arc_1_8_11  in_degree_1301  1
    arc_1_8_11  original_T_including_depot_unload_1359  8.4332546654485930e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_11  arc_capacity_977  1
    load_1_8_11  segment_load_conservation_1283  1
    load_1_8_11  segment_load_conservation_1304  -1
    load_1_8_11  segment_prefix_lb_1305  1
    load_1_8_11  segment_prefix_ub_1306  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_17  arc_capacity_979  -25
    arc_1_8_17  connected_order_arc_980  -14
    arc_1_8_17  out_degree_1279  1
    arc_1_8_17  in_degree_1308  1
    arc_1_8_17  original_T_including_depot_unload_1359  1.6809955292555005e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_17  arc_capacity_979  1
    load_1_8_17  segment_load_conservation_1283  1
    load_1_8_17  free_load_conservation_1312  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_18  arc_capacity_981  -25
    arc_1_8_18  connected_order_arc_982  -14
    arc_1_8_18  out_degree_1279  1
    arc_1_8_18  in_degree_1314  1
    arc_1_8_18  original_T_including_depot_unload_1359  1.9996644912858792e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_18  arc_capacity_981  1
    load_1_8_18  segment_load_conservation_1283  1
    load_1_8_18  free_load_conservation_1318  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_19  arc_capacity_983  -25
    arc_1_8_19  connected_order_arc_984  -14
    arc_1_8_19  out_degree_1279  1
    arc_1_8_19  in_degree_1320  1
    arc_1_8_19  original_T_including_depot_unload_1359  1.4573788798892317e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_19  arc_capacity_983  1
    load_1_8_19  segment_load_conservation_1283  1
    load_1_8_19  free_load_conservation_1324  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_20  arc_capacity_985  -25
    arc_1_8_20  connected_order_arc_986  -14
    arc_1_8_20  out_degree_1279  1
    arc_1_8_20  in_degree_1326  1
    arc_1_8_20  original_T_including_depot_unload_1359  1.5942479163822793e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_20  arc_capacity_985  1
    load_1_8_20  segment_load_conservation_1283  1
    load_1_8_20  free_load_conservation_1330  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_21  arc_capacity_987  -25
    arc_1_8_21  connected_order_arc_988  -14
    arc_1_8_21  out_degree_1279  1
    arc_1_8_21  in_degree_1332  1
    arc_1_8_21  original_T_including_depot_unload_1359  3.3422575089633142e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_21  arc_capacity_987  1
    load_1_8_21  segment_load_conservation_1283  1
    load_1_8_21  free_load_conservation_1336  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_22  arc_capacity_989  -25
    arc_1_8_22  connected_order_arc_990  -14
    arc_1_8_22  out_degree_1279  1
    arc_1_8_22  in_degree_1338  1
    arc_1_8_22  original_T_including_depot_unload_1359  1.2628291878233333e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_22  arc_capacity_989  1
    load_1_8_22  segment_load_conservation_1283  1
    load_1_8_22  free_load_conservation_1342  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_23  arc_capacity_991  -25
    arc_1_8_23  connected_order_arc_992  -14
    arc_1_8_23  out_degree_1279  1
    arc_1_8_23  in_degree_1344  1
    arc_1_8_23  original_T_including_depot_unload_1359  2226.1143218952
    MARKER    'MARKER'                 'INTEND'
    load_1_8_23  arc_capacity_991  1
    load_1_8_23  segment_load_conservation_1283  1
    load_1_8_23  free_load_conservation_1348  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_24  arc_capacity_993  -25
    arc_1_8_24  connected_order_arc_994  -14
    arc_1_8_24  out_degree_1279  1
    arc_1_8_24  in_degree_1350  1
    arc_1_8_24  original_T_including_depot_unload_1359  9.2153450304618127e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_24  arc_capacity_993  1
    load_1_8_24  segment_load_conservation_1283  1
    load_1_8_24  free_load_conservation_1354  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_0  arc_capacity_995  -25
    arc_1_9_0  depot_return_or_bypass_1271  1
    arc_1_9_0  out_degree_1286  1
    arc_1_9_0  original_T_including_depot_unload_1359  7.8195480223834068e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_0  arc_capacity_995  1
    load_1_9_0  segment_load_conservation_1290  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_7  arc_capacity_996  -25
    arc_1_9_7  connected_order_arc_997  -14
    arc_1_9_7  in_degree_1273  1
    arc_1_9_7  out_degree_1286  1
    arc_1_9_7  original_T_including_depot_unload_1359  7.0804311489116617e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_7  arc_capacity_996  1
    load_1_9_7  segment_load_conservation_1276  -1
    load_1_9_7  segment_prefix_lb_1277  1
    load_1_9_7  segment_prefix_ub_1278  1
    load_1_9_7  segment_load_conservation_1290  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_8  arc_capacity_998  -25
    arc_1_9_8  connected_order_arc_999  -14
    arc_1_9_8  in_degree_1280  1
    arc_1_9_8  out_degree_1286  1
    arc_1_9_8  original_T_including_depot_unload_1359  1.0062397105603651e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_8  arc_capacity_998  1
    load_1_9_8  segment_load_conservation_1283  -1
    load_1_9_8  segment_prefix_lb_1284  1
    load_1_9_8  segment_prefix_ub_1285  1
    load_1_9_8  segment_load_conservation_1290  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_10  arc_capacity_1000  -25
    arc_1_9_10  connected_order_arc_1001  -14
    arc_1_9_10  out_degree_1286  1
    arc_1_9_10  in_degree_1294  1
    arc_1_9_10  original_T_including_depot_unload_1359  4.1964259385165178e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_10  arc_capacity_1000  1
    load_1_9_10  segment_load_conservation_1290  1
    load_1_9_10  segment_load_conservation_1297  -1
    load_1_9_10  segment_prefix_lb_1298  1
    load_1_9_10  segment_prefix_ub_1299  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_11  arc_capacity_1002  -25
    arc_1_9_11  connected_order_arc_1003  -14
    arc_1_9_11  out_degree_1286  1
    arc_1_9_11  in_degree_1301  1
    arc_1_9_11  original_T_including_depot_unload_1359  7.3394466063263269e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_11  arc_capacity_1002  1
    load_1_9_11  segment_load_conservation_1290  1
    load_1_9_11  segment_load_conservation_1304  -1
    load_1_9_11  segment_prefix_lb_1305  1
    load_1_9_11  segment_prefix_ub_1306  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_17  arc_capacity_1004  -25
    arc_1_9_17  connected_order_arc_1005  -14
    arc_1_9_17  out_degree_1286  1
    arc_1_9_17  in_degree_1308  1
    arc_1_9_17  original_T_including_depot_unload_1359  1.6461188122693993e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_17  arc_capacity_1004  1
    load_1_9_17  segment_load_conservation_1290  1
    load_1_9_17  free_load_conservation_1312  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_18  arc_capacity_1006  -25
    arc_1_9_18  connected_order_arc_1007  -14
    arc_1_9_18  out_degree_1286  1
    arc_1_9_18  in_degree_1314  1
    arc_1_9_18  original_T_including_depot_unload_1359  1.9436220397684422e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_18  arc_capacity_1006  1
    load_1_9_18  segment_load_conservation_1290  1
    load_1_9_18  free_load_conservation_1318  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_19  arc_capacity_1008  -25
    arc_1_9_19  connected_order_arc_1009  -14
    arc_1_9_19  out_degree_1286  1
    arc_1_9_19  in_degree_1320  1
    arc_1_9_19  original_T_including_depot_unload_1359  1.3626829404511475e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_19  arc_capacity_1008  1
    load_1_9_19  segment_load_conservation_1290  1
    load_1_9_19  free_load_conservation_1324  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_20  arc_capacity_1010  -25
    arc_1_9_20  connected_order_arc_1011  -14
    arc_1_9_20  out_degree_1286  1
    arc_1_9_20  in_degree_1326  1
    arc_1_9_20  original_T_including_depot_unload_1359  1.5230919127946252e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_20  arc_capacity_1010  1
    load_1_9_20  segment_load_conservation_1290  1
    load_1_9_20  free_load_conservation_1330  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_21  arc_capacity_1012  -25
    arc_1_9_21  connected_order_arc_1013  -14
    arc_1_9_21  out_degree_1286  1
    arc_1_9_21  in_degree_1332  1
    arc_1_9_21  original_T_including_depot_unload_1359  2.5572087458878266e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_21  arc_capacity_1012  1
    load_1_9_21  segment_load_conservation_1290  1
    load_1_9_21  free_load_conservation_1336  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_22  arc_capacity_1014  -25
    arc_1_9_22  connected_order_arc_1015  -14
    arc_1_9_22  out_degree_1286  1
    arc_1_9_22  in_degree_1338  1
    arc_1_9_22  original_T_including_depot_unload_1359  1.1952607376785465e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_22  arc_capacity_1014  1
    load_1_9_22  segment_load_conservation_1290  1
    load_1_9_22  free_load_conservation_1342  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_23  arc_capacity_1016  -25
    arc_1_9_23  connected_order_arc_1017  -14
    arc_1_9_23  out_degree_1286  1
    arc_1_9_23  in_degree_1344  1
    arc_1_9_23  original_T_including_depot_unload_1359  2115.53677476792
    MARKER    'MARKER'                 'INTEND'
    load_1_9_23  arc_capacity_1016  1
    load_1_9_23  segment_load_conservation_1290  1
    load_1_9_23  free_load_conservation_1348  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_24  arc_capacity_1018  -25
    arc_1_9_24  connected_order_arc_1019  -14
    arc_1_9_24  out_degree_1286  1
    arc_1_9_24  in_degree_1350  1
    arc_1_9_24  original_T_including_depot_unload_1359  8.5807018379884664e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_24  arc_capacity_1018  1
    load_1_9_24  segment_load_conservation_1290  1
    load_1_9_24  free_load_conservation_1354  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_0  arc_capacity_1020  -25
    arc_1_10_0  depot_return_or_bypass_1271  1
    arc_1_10_0  out_degree_1293  1
    arc_1_10_0  original_T_including_depot_unload_1359  4.7522445589173662e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_0  arc_capacity_1020  1
    load_1_10_0  segment_load_conservation_1297  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_7  arc_capacity_1021  -25
    arc_1_10_7  connected_order_arc_1022  -14
    arc_1_10_7  in_degree_1273  1
    arc_1_10_7  out_degree_1293  1
    arc_1_10_7  original_T_including_depot_unload_1359  9.0121368945211725e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_7  arc_capacity_1021  1
    load_1_10_7  segment_load_conservation_1276  -1
    load_1_10_7  segment_prefix_lb_1277  1
    load_1_10_7  segment_prefix_ub_1278  1
    load_1_10_7  segment_load_conservation_1297  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_8  arc_capacity_1023  -25
    arc_1_10_8  connected_order_arc_1024  -14
    arc_1_10_8  in_degree_1280  1
    arc_1_10_8  out_degree_1293  1
    arc_1_10_8  original_T_including_depot_unload_1359  1.0793944823036150e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_8  arc_capacity_1023  1
    load_1_10_8  segment_load_conservation_1283  -1
    load_1_10_8  segment_prefix_lb_1284  1
    load_1_10_8  segment_prefix_ub_1285  1
    load_1_10_8  segment_load_conservation_1297  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_9  arc_capacity_1025  -25
    arc_1_10_9  connected_order_arc_1026  -14
    arc_1_10_9  in_degree_1287  1
    arc_1_10_9  out_degree_1293  1
    arc_1_10_9  original_T_including_depot_unload_1359  4.1964259385165178e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_9  arc_capacity_1025  1
    load_1_10_9  segment_load_conservation_1290  -1
    load_1_10_9  segment_prefix_lb_1291  1
    load_1_10_9  segment_prefix_ub_1292  1
    load_1_10_9  segment_load_conservation_1297  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_11  arc_capacity_1027  -25
    arc_1_10_11  connected_order_arc_1028  -14
    arc_1_10_11  out_degree_1293  1
    arc_1_10_11  in_degree_1301  1
    arc_1_10_11  original_T_including_depot_unload_1359  4.9232225330062903e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_11  arc_capacity_1027  1
    load_1_10_11  segment_load_conservation_1297  1
    load_1_10_11  segment_load_conservation_1304  -1
    load_1_10_11  segment_prefix_lb_1305  1
    load_1_10_11  segment_prefix_ub_1306  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_17  arc_capacity_1029  -25
    arc_1_10_17  connected_order_arc_1030  -14
    arc_1_10_17  out_degree_1293  1
    arc_1_10_17  in_degree_1308  1
    arc_1_10_17  original_T_including_depot_unload_1359  1.2686001679750689e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_17  arc_capacity_1029  1
    load_1_10_17  segment_load_conservation_1297  1
    load_1_10_17  free_load_conservation_1312  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_18  arc_capacity_1031  -25
    arc_1_10_18  connected_order_arc_1032  -14
    arc_1_10_18  out_degree_1293  1
    arc_1_10_18  in_degree_1314  1
    arc_1_10_18  original_T_including_depot_unload_1359  1.5322275462532455e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_18  arc_capacity_1031  1
    load_1_10_18  segment_load_conservation_1297  1
    load_1_10_18  free_load_conservation_1318  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_19  arc_capacity_1033  -25
    arc_1_10_19  connected_order_arc_1034  -14
    arc_1_10_19  out_degree_1293  1
    arc_1_10_19  in_degree_1320  1
    arc_1_10_19  original_T_including_depot_unload_1359  1.3823927712314810e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_19  arc_capacity_1033  1
    load_1_10_19  segment_load_conservation_1297  1
    load_1_10_19  free_load_conservation_1324  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_20  arc_capacity_1035  -25
    arc_1_10_20  connected_order_arc_1036  -14
    arc_1_10_20  out_degree_1293  1
    arc_1_10_20  in_degree_1326  1
    arc_1_10_20  original_T_including_depot_unload_1359  1.1034987922840380e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_20  arc_capacity_1035  1
    load_1_10_20  segment_load_conservation_1297  1
    load_1_10_20  free_load_conservation_1330  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_21  arc_capacity_1037  -25
    arc_1_10_21  connected_order_arc_1038  -14
    arc_1_10_21  out_degree_1293  1
    arc_1_10_21  in_degree_1332  1
    arc_1_10_21  original_T_including_depot_unload_1359  1.6444540482789353e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_21  arc_capacity_1037  1
    load_1_10_21  segment_load_conservation_1297  1
    load_1_10_21  free_load_conservation_1336  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_22  arc_capacity_1039  -25
    arc_1_10_22  connected_order_arc_1040  -14
    arc_1_10_22  out_degree_1293  1
    arc_1_10_22  in_degree_1338  1
    arc_1_10_22  original_T_including_depot_unload_1359  7.7690262287132452e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_22  arc_capacity_1039  1
    load_1_10_22  segment_load_conservation_1297  1
    load_1_10_22  free_load_conservation_1342  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_23  arc_capacity_1041  -25
    arc_1_10_23  connected_order_arc_1042  -14
    arc_1_10_23  out_degree_1293  1
    arc_1_10_23  in_degree_1344  1
    arc_1_10_23  original_T_including_depot_unload_1359  1.8418804985785646e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_23  arc_capacity_1041  1
    load_1_10_23  segment_load_conservation_1297  1
    load_1_10_23  free_load_conservation_1348  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_24  arc_capacity_1043  -25
    arc_1_10_24  connected_order_arc_1044  -14
    arc_1_10_24  out_degree_1293  1
    arc_1_10_24  in_degree_1350  1
    arc_1_10_24  original_T_including_depot_unload_1359  4.4474809771996007e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_24  arc_capacity_1043  1
    load_1_10_24  segment_load_conservation_1297  1
    load_1_10_24  free_load_conservation_1354  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_0  arc_capacity_1045  -25
    arc_1_11_0  depot_return_or_bypass_1271  1
    arc_1_11_0  out_degree_1300  1
    arc_1_11_0  original_T_including_depot_unload_1359  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_0  arc_capacity_1045  1
    load_1_11_0  segment_load_conservation_1304  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_7  arc_capacity_1046  -25
    arc_1_11_7  connected_order_arc_1047  -14
    arc_1_11_7  in_degree_1273  1
    arc_1_11_7  out_degree_1300  1
    arc_1_11_7  original_T_including_depot_unload_1359  7.5571464781430223e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_7  arc_capacity_1046  1
    load_1_11_7  segment_load_conservation_1276  -1
    load_1_11_7  segment_prefix_lb_1277  1
    load_1_11_7  segment_prefix_ub_1278  1
    load_1_11_7  segment_load_conservation_1304  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_8  arc_capacity_1048  -25
    arc_1_11_8  connected_order_arc_1049  -14
    arc_1_11_8  in_degree_1280  1
    arc_1_11_8  out_degree_1300  1
    arc_1_11_8  original_T_including_depot_unload_1359  7.5634788469878674e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_8  arc_capacity_1048  1
    load_1_11_8  segment_load_conservation_1283  -1
    load_1_11_8  segment_prefix_lb_1284  1
    load_1_11_8  segment_prefix_ub_1285  1
    load_1_11_8  segment_load_conservation_1304  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_9  arc_capacity_1050  -25
    arc_1_11_9  connected_order_arc_1051  -14
    arc_1_11_9  in_degree_1287  1
    arc_1_11_9  out_degree_1300  1
    arc_1_11_9  original_T_including_depot_unload_1359  7.3394466063263269e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_9  arc_capacity_1050  1
    load_1_11_9  segment_load_conservation_1290  -1
    load_1_11_9  segment_prefix_lb_1291  1
    load_1_11_9  segment_prefix_ub_1292  1
    load_1_11_9  segment_load_conservation_1304  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_10  arc_capacity_1052  -25
    arc_1_11_10  connected_order_arc_1053  -14
    arc_1_11_10  in_degree_1294  1
    arc_1_11_10  out_degree_1300  1
    arc_1_11_10  original_T_including_depot_unload_1359  4.9232225330062903e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_10  arc_capacity_1052  1
    load_1_11_10  segment_load_conservation_1297  -1
    load_1_11_10  segment_prefix_lb_1298  1
    load_1_11_10  segment_prefix_ub_1299  1
    load_1_11_10  segment_load_conservation_1304  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_17  arc_capacity_1054  -25
    arc_1_11_17  connected_order_arc_1055  -14
    arc_1_11_17  out_degree_1300  1
    arc_1_11_17  in_degree_1308  1
    arc_1_11_17  original_T_including_depot_unload_1359  1.4593103211867947e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_17  arc_capacity_1054  1
    load_1_11_17  segment_load_conservation_1304  1
    load_1_11_17  free_load_conservation_1312  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_18  arc_capacity_1056  -25
    arc_1_11_18  connected_order_arc_1057  -14
    arc_1_11_18  out_degree_1300  1
    arc_1_11_18  in_degree_1314  1
    arc_1_11_18  original_T_including_depot_unload_1359  1.5757088859257728e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_18  arc_capacity_1056  1
    load_1_11_18  segment_load_conservation_1304  1
    load_1_11_18  free_load_conservation_1318  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_19  arc_capacity_1058  -25
    arc_1_11_19  connected_order_arc_1059  -14
    arc_1_11_19  out_degree_1300  1
    arc_1_11_19  in_degree_1320  1
    arc_1_11_19  original_T_including_depot_unload_1359  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_19  arc_capacity_1058  1
    load_1_11_19  segment_load_conservation_1304  1
    load_1_11_19  free_load_conservation_1324  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_20  arc_capacity_1060  -25
    arc_1_11_20  connected_order_arc_1061  -14
    arc_1_11_20  out_degree_1300  1
    arc_1_11_20  in_degree_1326  1
    arc_1_11_20  original_T_including_depot_unload_1359  1.0783470469841145e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_20  arc_capacity_1060  1
    load_1_11_20  segment_load_conservation_1304  1
    load_1_11_20  free_load_conservation_1330  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_21  arc_capacity_1062  -25
    arc_1_11_21  connected_order_arc_1063  -14
    arc_1_11_21  out_degree_1300  1
    arc_1_11_21  in_degree_1332  1
    arc_1_11_21  original_T_including_depot_unload_1359  5.7102904773674652e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_21  arc_capacity_1062  1
    load_1_11_21  segment_load_conservation_1304  1
    load_1_11_21  free_load_conservation_1336  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_22  arc_capacity_1064  -25
    arc_1_11_22  connected_order_arc_1065  -14
    arc_1_11_22  out_degree_1300  1
    arc_1_11_22  in_degree_1338  1
    arc_1_11_22  original_T_including_depot_unload_1359  8.3393751072629220e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_22  arc_capacity_1064  1
    load_1_11_22  segment_load_conservation_1304  1
    load_1_11_22  free_load_conservation_1342  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_23  arc_capacity_1066  -25
    arc_1_11_23  connected_order_arc_1067  -14
    arc_1_11_23  out_degree_1300  1
    arc_1_11_23  in_degree_1344  1
    arc_1_11_23  original_T_including_depot_unload_1359  1.3857128117205509e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_23  arc_capacity_1066  1
    load_1_11_23  segment_load_conservation_1304  1
    load_1_11_23  free_load_conservation_1348  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_24  arc_capacity_1068  -25
    arc_1_11_24  connected_order_arc_1069  -14
    arc_1_11_24  out_degree_1300  1
    arc_1_11_24  in_degree_1350  1
    arc_1_11_24  original_T_including_depot_unload_1359  6.4572843340219208e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_24  arc_capacity_1068  1
    load_1_11_24  segment_load_conservation_1304  1
    load_1_11_24  free_load_conservation_1354  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_0  arc_capacity_1070  -25
    arc_1_17_0  depot_return_or_bypass_1271  1
    arc_1_17_0  out_degree_1307  1
    arc_1_17_0  original_T_including_depot_unload_1359  1.3396590612935172e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_0  arc_capacity_1070  1
    load_1_17_0  free_load_conservation_1312  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_7  arc_capacity_1071  -25
    arc_1_17_7  connected_order_arc_1072  -14
    arc_1_17_7  in_degree_1273  1
    arc_1_17_7  out_degree_1307  1
    arc_1_17_7  original_T_including_depot_unload_1359  2.1372888672431886e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_7  arc_capacity_1071  1
    load_1_17_7  segment_load_conservation_1276  -1
    load_1_17_7  segment_prefix_lb_1277  1
    load_1_17_7  segment_prefix_ub_1278  1
    load_1_17_7  free_load_conservation_1312  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_8  arc_capacity_1073  -25
    arc_1_17_8  connected_order_arc_1074  -14
    arc_1_17_8  in_degree_1280  1
    arc_1_17_8  out_degree_1307  1
    arc_1_17_8  original_T_including_depot_unload_1359  2.2144644790128582e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_8  arc_capacity_1073  1
    load_1_17_8  segment_load_conservation_1283  -1
    load_1_17_8  segment_prefix_lb_1284  1
    load_1_17_8  segment_prefix_ub_1285  1
    load_1_17_8  free_load_conservation_1312  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_9  arc_capacity_1075  -25
    arc_1_17_9  connected_order_arc_1076  -14
    arc_1_17_9  in_degree_1287  1
    arc_1_17_9  out_degree_1307  1
    arc_1_17_9  original_T_including_depot_unload_1359  1.6461188122693993e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_9  arc_capacity_1075  1
    load_1_17_9  segment_load_conservation_1290  -1
    load_1_17_9  segment_prefix_lb_1291  1
    load_1_17_9  segment_prefix_ub_1292  1
    load_1_17_9  free_load_conservation_1312  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_10  arc_capacity_1077  -25
    arc_1_17_10  connected_order_arc_1078  -14
    arc_1_17_10  in_degree_1294  1
    arc_1_17_10  out_degree_1307  1
    arc_1_17_10  original_T_including_depot_unload_1359  1.2686001679750689e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_10  arc_capacity_1077  1
    load_1_17_10  segment_load_conservation_1297  -1
    load_1_17_10  segment_prefix_lb_1298  1
    load_1_17_10  segment_prefix_ub_1299  1
    load_1_17_10  free_load_conservation_1312  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_11  arc_capacity_1079  -25
    arc_1_17_11  connected_order_arc_1080  -14
    arc_1_17_11  in_degree_1301  1
    arc_1_17_11  out_degree_1307  1
    arc_1_17_11  original_T_including_depot_unload_1359  1.4593103211867947e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_11  arc_capacity_1079  1
    load_1_17_11  segment_load_conservation_1304  -1
    load_1_17_11  segment_prefix_lb_1305  1
    load_1_17_11  segment_prefix_ub_1306  1
    load_1_17_11  free_load_conservation_1312  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_18  arc_capacity_1081  -25
    arc_1_17_18  connected_order_arc_1082  -14
    arc_1_17_18  out_degree_1307  1
    arc_1_17_18  in_degree_1314  1
    arc_1_17_18  original_T_including_depot_unload_1359  4.8781034218421996e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_18  arc_capacity_1081  1
    load_1_17_18  free_load_conservation_1312  1
    load_1_17_18  free_load_conservation_1318  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_19  arc_capacity_1083  -25
    arc_1_17_19  connected_order_arc_1084  -14
    arc_1_17_19  out_degree_1307  1
    arc_1_17_19  in_degree_1320  1
    arc_1_17_19  original_T_including_depot_unload_1359  2.4147485851762935e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_19  arc_capacity_1083  1
    load_1_17_19  free_load_conservation_1312  1
    load_1_17_19  free_load_conservation_1324  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_20  arc_capacity_1085  -25
    arc_1_17_20  connected_order_arc_1086  -14
    arc_1_17_20  out_degree_1307  1
    arc_1_17_20  in_degree_1326  1
    arc_1_17_20  original_T_including_depot_unload_1359  6.0985881995898160e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_20  arc_capacity_1085  1
    load_1_17_20  free_load_conservation_1312  1
    load_1_17_20  free_load_conservation_1330  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_21  arc_capacity_1087  -25
    arc_1_17_21  connected_order_arc_1088  -14
    arc_1_17_21  out_degree_1307  1
    arc_1_17_21  in_degree_1332  1
    arc_1_17_21  original_T_including_depot_unload_1359  1.4088953223409719e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_21  arc_capacity_1087  1
    load_1_17_21  free_load_conservation_1312  1
    load_1_17_21  free_load_conservation_1336  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_22  arc_capacity_1089  -25
    arc_1_17_22  connected_order_arc_1090  -14
    arc_1_17_22  out_degree_1307  1
    arc_1_17_22  in_degree_1338  1
    arc_1_17_22  original_T_including_depot_unload_1359  6.4419272207888969e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_22  arc_capacity_1089  1
    load_1_17_22  free_load_conservation_1312  1
    load_1_17_22  free_load_conservation_1342  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_23  arc_capacity_1091  -25
    arc_1_17_23  connected_order_arc_1092  -14
    arc_1_17_23  out_degree_1307  1
    arc_1_17_23  in_degree_1344  1
    arc_1_17_23  original_T_including_depot_unload_1359  2.1214998192647863e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_23  arc_capacity_1091  1
    load_1_17_23  free_load_conservation_1312  1
    load_1_17_23  free_load_conservation_1348  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_24  arc_capacity_1093  -25
    arc_1_17_24  connected_order_arc_1094  -14
    arc_1_17_24  out_degree_1307  1
    arc_1_17_24  in_degree_1350  1
    arc_1_17_24  original_T_including_depot_unload_1359  8.4962277657921186e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_24  arc_capacity_1093  1
    load_1_17_24  free_load_conservation_1312  1
    load_1_17_24  free_load_conservation_1354  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_0  arc_capacity_1095  -25
    arc_1_18_0  depot_return_or_bypass_1271  1
    arc_1_18_0  out_degree_1313  1
    arc_1_18_0  original_T_including_depot_unload_1359  1.4501558573355060e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_0  arc_capacity_1095  1
    load_1_18_0  free_load_conservation_1318  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_7  arc_capacity_1096  -25
    arc_1_18_7  connected_order_arc_1097  -14
    arc_1_18_7  in_degree_1273  1
    arc_1_18_7  out_degree_1313  1
    arc_1_18_7  original_T_including_depot_unload_1359  2.3158028257381197e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_7  arc_capacity_1096  1
    load_1_18_7  segment_load_conservation_1276  -1
    load_1_18_7  segment_prefix_lb_1277  1
    load_1_18_7  segment_prefix_ub_1278  1
    load_1_18_7  free_load_conservation_1318  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_8  arc_capacity_1098  -25
    arc_1_18_8  connected_order_arc_1099  -14
    arc_1_18_8  in_degree_1280  1
    arc_1_18_8  out_degree_1313  1
    arc_1_18_8  original_T_including_depot_unload_1359  2.3168138409467269e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_8  arc_capacity_1098  1
    load_1_18_8  segment_load_conservation_1283  -1
    load_1_18_8  segment_prefix_lb_1284  1
    load_1_18_8  segment_prefix_ub_1285  1
    load_1_18_8  free_load_conservation_1318  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_9  arc_capacity_1100  -25
    arc_1_18_9  connected_order_arc_1101  -14
    arc_1_18_9  in_degree_1287  1
    arc_1_18_9  out_degree_1313  1
    arc_1_18_9  original_T_including_depot_unload_1359  1.9436220397684422e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_9  arc_capacity_1100  1
    load_1_18_9  segment_load_conservation_1290  -1
    load_1_18_9  segment_prefix_lb_1291  1
    load_1_18_9  segment_prefix_ub_1292  1
    load_1_18_9  free_load_conservation_1318  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_10  arc_capacity_1102  -25
    arc_1_18_10  connected_order_arc_1103  -14
    arc_1_18_10  in_degree_1294  1
    arc_1_18_10  out_degree_1313  1
    arc_1_18_10  original_T_including_depot_unload_1359  1.5322275462532455e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_10  arc_capacity_1102  1
    load_1_18_10  segment_load_conservation_1297  -1
    load_1_18_10  segment_prefix_lb_1298  1
    load_1_18_10  segment_prefix_ub_1299  1
    load_1_18_10  free_load_conservation_1318  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_11  arc_capacity_1104  -25
    arc_1_18_11  connected_order_arc_1105  -14
    arc_1_18_11  in_degree_1301  1
    arc_1_18_11  out_degree_1313  1
    arc_1_18_11  original_T_including_depot_unload_1359  1.5757088859257728e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_11  arc_capacity_1104  1
    load_1_18_11  segment_load_conservation_1304  -1
    load_1_18_11  segment_prefix_lb_1305  1
    load_1_18_11  segment_prefix_ub_1306  1
    load_1_18_11  free_load_conservation_1318  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_17  arc_capacity_1106  -25
    arc_1_18_17  connected_order_arc_1107  -14
    arc_1_18_17  in_degree_1308  1
    arc_1_18_17  out_degree_1313  1
    arc_1_18_17  original_T_including_depot_unload_1359  4.8781034218421996e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_17  arc_capacity_1106  1
    load_1_18_17  free_load_conservation_1312  -1
    load_1_18_17  free_load_conservation_1318  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_19  arc_capacity_1108  -25
    arc_1_18_19  connected_order_arc_1109  -14
    arc_1_18_19  out_degree_1313  1
    arc_1_18_19  in_degree_1320  1
    arc_1_18_19  original_T_including_depot_unload_1359  2.4496137598598170e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_19  arc_capacity_1108  1
    load_1_18_19  free_load_conservation_1318  1
    load_1_18_19  free_load_conservation_1324  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_20  arc_capacity_1110  -25
    arc_1_18_20  connected_order_arc_1111  -14
    arc_1_18_20  out_degree_1313  1
    arc_1_18_20  in_degree_1326  1
    arc_1_18_20  original_T_including_depot_unload_1359  5.0525672969651123e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_20  arc_capacity_1110  1
    load_1_18_20  free_load_conservation_1318  1
    load_1_18_20  free_load_conservation_1330  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_21  arc_capacity_1112  -25
    arc_1_18_21  connected_order_arc_1113  -14
    arc_1_18_21  out_degree_1313  1
    arc_1_18_21  in_degree_1332  1
    arc_1_18_21  original_T_including_depot_unload_1359  1.6906177970488723e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_21  arc_capacity_1112  1
    load_1_18_21  free_load_conservation_1318  1
    load_1_18_21  free_load_conservation_1336  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_22  arc_capacity_1114  -25
    arc_1_18_22  connected_order_arc_1115  -14
    arc_1_18_22  out_degree_1313  1
    arc_1_18_22  in_degree_1338  1
    arc_1_18_22  original_T_including_depot_unload_1359  7.6789230776331749e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_22  arc_capacity_1114  1
    load_1_18_22  free_load_conservation_1318  1
    load_1_18_22  free_load_conservation_1342  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_23  arc_capacity_1116  -25
    arc_1_18_23  connected_order_arc_1117  -14
    arc_1_18_23  out_degree_1313  1
    arc_1_18_23  in_degree_1344  1
    arc_1_18_23  original_T_including_depot_unload_1359  1.8780729343410642e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_23  arc_capacity_1116  1
    load_1_18_23  free_load_conservation_1318  1
    load_1_18_23  free_load_conservation_1348  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_24  arc_capacity_1118  -25
    arc_1_18_24  connected_order_arc_1119  -14
    arc_1_18_24  out_degree_1313  1
    arc_1_18_24  in_degree_1350  1
    arc_1_18_24  original_T_including_depot_unload_1359  1.0875821153726588e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_24  arc_capacity_1118  1
    load_1_18_24  free_load_conservation_1318  1
    load_1_18_24  free_load_conservation_1354  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_0  arc_capacity_1120  -25
    arc_1_19_0  depot_return_or_bypass_1271  1
    arc_1_19_0  out_degree_1319  1
    arc_1_19_0  original_T_including_depot_unload_1359  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_0  arc_capacity_1120  1
    load_1_19_0  free_load_conservation_1324  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_7  arc_capacity_1121  -25
    arc_1_19_7  connected_order_arc_1122  -14
    arc_1_19_7  in_degree_1273  1
    arc_1_19_7  out_degree_1319  1
    arc_1_19_7  original_T_including_depot_unload_1359  7.3227602527872671e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_7  arc_capacity_1121  1
    load_1_19_7  segment_load_conservation_1276  -1
    load_1_19_7  segment_prefix_lb_1277  1
    load_1_19_7  segment_prefix_ub_1278  1
    load_1_19_7  free_load_conservation_1324  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_8  arc_capacity_1123  -25
    arc_1_19_8  connected_order_arc_1124  -14
    arc_1_19_8  in_degree_1280  1
    arc_1_19_8  out_degree_1319  1
    arc_1_19_8  original_T_including_depot_unload_1359  3.6824909986567474e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_8  arc_capacity_1123  1
    load_1_19_8  segment_load_conservation_1283  -1
    load_1_19_8  segment_prefix_lb_1284  1
    load_1_19_8  segment_prefix_ub_1285  1
    load_1_19_8  free_load_conservation_1324  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_9  arc_capacity_1125  -25
    arc_1_19_9  connected_order_arc_1126  -14
    arc_1_19_9  in_degree_1287  1
    arc_1_19_9  out_degree_1319  1
    arc_1_19_9  original_T_including_depot_unload_1359  1.3626829404511475e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_9  arc_capacity_1125  1
    load_1_19_9  segment_load_conservation_1290  -1
    load_1_19_9  segment_prefix_lb_1291  1
    load_1_19_9  segment_prefix_ub_1292  1
    load_1_19_9  free_load_conservation_1324  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_10  arc_capacity_1127  -25
    arc_1_19_10  connected_order_arc_1128  -14
    arc_1_19_10  in_degree_1294  1
    arc_1_19_10  out_degree_1319  1
    arc_1_19_10  original_T_including_depot_unload_1359  1.3823927712314810e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_10  arc_capacity_1127  1
    load_1_19_10  segment_load_conservation_1297  -1
    load_1_19_10  segment_prefix_lb_1298  1
    load_1_19_10  segment_prefix_ub_1299  1
    load_1_19_10  free_load_conservation_1324  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_11  arc_capacity_1129  -25
    arc_1_19_11  connected_order_arc_1130  -14
    arc_1_19_11  in_degree_1301  1
    arc_1_19_11  out_degree_1319  1
    arc_1_19_11  original_T_including_depot_unload_1359  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_11  arc_capacity_1129  1
    load_1_19_11  segment_load_conservation_1304  -1
    load_1_19_11  segment_prefix_lb_1305  1
    load_1_19_11  segment_prefix_ub_1306  1
    load_1_19_11  free_load_conservation_1324  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_17  arc_capacity_1131  -25
    arc_1_19_17  connected_order_arc_1132  -14
    arc_1_19_17  in_degree_1308  1
    arc_1_19_17  out_degree_1319  1
    arc_1_19_17  original_T_including_depot_unload_1359  2.4147485851762935e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_17  arc_capacity_1131  1
    load_1_19_17  free_load_conservation_1312  -1
    load_1_19_17  free_load_conservation_1324  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_18  arc_capacity_1133  -25
    arc_1_19_18  connected_order_arc_1134  -14
    arc_1_19_18  in_degree_1314  1
    arc_1_19_18  out_degree_1319  1
    arc_1_19_18  original_T_including_depot_unload_1359  2.4496137598598170e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_18  arc_capacity_1133  1
    load_1_19_18  free_load_conservation_1318  -1
    load_1_19_18  free_load_conservation_1324  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_20  arc_capacity_1135  -25
    arc_1_19_20  connected_order_arc_1136  -14
    arc_1_19_20  out_degree_1319  1
    arc_1_19_20  in_degree_1326  1
    arc_1_19_20  original_T_including_depot_unload_1359  1.9462564869425171e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_20  arc_capacity_1135  1
    load_1_19_20  free_load_conservation_1324  1
    load_1_19_20  free_load_conservation_1330  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_21  arc_capacity_1137  -25
    arc_1_19_21  connected_order_arc_1138  -14
    arc_1_19_21  out_degree_1319  1
    arc_1_19_21  in_degree_1332  1
    arc_1_19_21  original_T_including_depot_unload_1359  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_21  arc_capacity_1137  1
    load_1_19_21  free_load_conservation_1324  1
    load_1_19_21  free_load_conservation_1336  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_22  arc_capacity_1139  -25
    arc_1_19_22  connected_order_arc_1140  -14
    arc_1_19_22  out_degree_1319  1
    arc_1_19_22  in_degree_1338  1
    arc_1_19_22  original_T_including_depot_unload_1359  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_22  arc_capacity_1139  1
    load_1_19_22  free_load_conservation_1324  1
    load_1_19_22  free_load_conservation_1342  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_23  arc_capacity_1141  -25
    arc_1_19_23  connected_order_arc_1142  -14
    arc_1_19_23  out_degree_1319  1
    arc_1_19_23  in_degree_1344  1
    arc_1_19_23  original_T_including_depot_unload_1359  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_23  arc_capacity_1141  1
    load_1_19_23  free_load_conservation_1324  1
    load_1_19_23  free_load_conservation_1348  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_24  arc_capacity_1143  -25
    arc_1_19_24  connected_order_arc_1144  -14
    arc_1_19_24  out_degree_1319  1
    arc_1_19_24  in_degree_1350  1
    arc_1_19_24  original_T_including_depot_unload_1359  1.6231508478292610e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_24  arc_capacity_1143  1
    load_1_19_24  free_load_conservation_1324  1
    load_1_19_24  free_load_conservation_1354  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_0  arc_capacity_1145  -25
    arc_1_20_0  depot_return_or_bypass_1271  1
    arc_1_20_0  out_degree_1325  1
    arc_1_20_0  original_T_including_depot_unload_1359  9.5330620720858735e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_0  arc_capacity_1145  1
    load_1_20_0  free_load_conservation_1330  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_7  arc_capacity_1146  -25
    arc_1_20_7  connected_order_arc_1147  -14
    arc_1_20_7  in_degree_1273  1
    arc_1_20_7  out_degree_1325  1
    arc_1_20_7  original_T_including_depot_unload_1359  1.8269270746185791e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_7  arc_capacity_1146  1
    load_1_20_7  segment_load_conservation_1276  -1
    load_1_20_7  segment_prefix_lb_1277  1
    load_1_20_7  segment_prefix_ub_1278  1
    load_1_20_7  free_load_conservation_1330  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_8  arc_capacity_1148  -25
    arc_1_20_8  connected_order_arc_1149  -14
    arc_1_20_8  in_degree_1280  1
    arc_1_20_8  out_degree_1325  1
    arc_1_20_8  original_T_including_depot_unload_1359  1.8130068061837439e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_8  arc_capacity_1148  1
    load_1_20_8  segment_load_conservation_1283  -1
    load_1_20_8  segment_prefix_lb_1284  1
    load_1_20_8  segment_prefix_ub_1285  1
    load_1_20_8  free_load_conservation_1330  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_9  arc_capacity_1150  -25
    arc_1_20_9  connected_order_arc_1151  -14
    arc_1_20_9  in_degree_1287  1
    arc_1_20_9  out_degree_1325  1
    arc_1_20_9  original_T_including_depot_unload_1359  1.5230919127946252e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_9  arc_capacity_1150  1
    load_1_20_9  segment_load_conservation_1290  -1
    load_1_20_9  segment_prefix_lb_1291  1
    load_1_20_9  segment_prefix_ub_1292  1
    load_1_20_9  free_load_conservation_1330  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_10  arc_capacity_1152  -25
    arc_1_20_10  connected_order_arc_1153  -14
    arc_1_20_10  in_degree_1294  1
    arc_1_20_10  out_degree_1325  1
    arc_1_20_10  original_T_including_depot_unload_1359  1.1034987922840380e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_10  arc_capacity_1152  1
    load_1_20_10  segment_load_conservation_1297  -1
    load_1_20_10  segment_prefix_lb_1298  1
    load_1_20_10  segment_prefix_ub_1299  1
    load_1_20_10  free_load_conservation_1330  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_11  arc_capacity_1154  -25
    arc_1_20_11  connected_order_arc_1155  -14
    arc_1_20_11  in_degree_1301  1
    arc_1_20_11  out_degree_1325  1
    arc_1_20_11  original_T_including_depot_unload_1359  1.0783470469841145e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_11  arc_capacity_1154  1
    load_1_20_11  segment_load_conservation_1304  -1
    load_1_20_11  segment_prefix_lb_1305  1
    load_1_20_11  segment_prefix_ub_1306  1
    load_1_20_11  free_load_conservation_1330  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_17  arc_capacity_1156  -25
    arc_1_20_17  connected_order_arc_1157  -14
    arc_1_20_17  in_degree_1308  1
    arc_1_20_17  out_degree_1325  1
    arc_1_20_17  original_T_including_depot_unload_1359  6.0985881995898160e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_17  arc_capacity_1156  1
    load_1_20_17  free_load_conservation_1312  -1
    load_1_20_17  free_load_conservation_1330  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_18  arc_capacity_1158  -25
    arc_1_20_18  connected_order_arc_1159  -14
    arc_1_20_18  in_degree_1314  1
    arc_1_20_18  out_degree_1325  1
    arc_1_20_18  original_T_including_depot_unload_1359  5.0525672969651123e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_18  arc_capacity_1158  1
    load_1_20_18  free_load_conservation_1318  -1
    load_1_20_18  free_load_conservation_1330  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_19  arc_capacity_1160  -25
    arc_1_20_19  connected_order_arc_1161  -14
    arc_1_20_19  in_degree_1320  1
    arc_1_20_19  out_degree_1325  1
    arc_1_20_19  original_T_including_depot_unload_1359  1.9462564869425171e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_19  arc_capacity_1160  1
    load_1_20_19  free_load_conservation_1324  -1
    load_1_20_19  free_load_conservation_1330  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_21  arc_capacity_1162  -25
    arc_1_20_21  connected_order_arc_1163  -14
    arc_1_20_21  out_degree_1325  1
    arc_1_20_21  in_degree_1332  1
    arc_1_20_21  original_T_including_depot_unload_1359  1.2674827380665711e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_21  arc_capacity_1162  1
    load_1_20_21  free_load_conservation_1330  1
    load_1_20_21  free_load_conservation_1336  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_22  arc_capacity_1164  -25
    arc_1_20_22  connected_order_arc_1165  -14
    arc_1_20_22  out_degree_1325  1
    arc_1_20_22  in_degree_1338  1
    arc_1_20_22  original_T_including_depot_unload_1359  3.3469758905462760e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_22  arc_capacity_1164  1
    load_1_20_22  free_load_conservation_1330  1
    load_1_20_22  free_load_conservation_1342  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_23  arc_capacity_1166  -25
    arc_1_20_23  connected_order_arc_1167  -14
    arc_1_20_23  out_degree_1325  1
    arc_1_20_23  in_degree_1344  1
    arc_1_20_23  original_T_including_depot_unload_1359  1.5117151439160034e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_23  arc_capacity_1166  1
    load_1_20_23  free_load_conservation_1330  1
    load_1_20_23  free_load_conservation_1348  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_24  arc_capacity_1168  -25
    arc_1_20_24  connected_order_arc_1169  -14
    arc_1_20_24  out_degree_1325  1
    arc_1_20_24  in_degree_1350  1
    arc_1_20_24  original_T_including_depot_unload_1359  6.7711923781893620e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_24  arc_capacity_1168  1
    load_1_20_24  free_load_conservation_1330  1
    load_1_20_24  free_load_conservation_1354  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_0  arc_capacity_1170  -25
    arc_1_21_0  depot_return_or_bypass_1271  1
    arc_1_21_0  out_degree_1331  1
    arc_1_21_0  original_T_including_depot_unload_1359  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_0  arc_capacity_1170  1
    load_1_21_0  free_load_conservation_1336  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_7  arc_capacity_1171  -25
    arc_1_21_7  connected_order_arc_1172  -14
    arc_1_21_7  in_degree_1273  1
    arc_1_21_7  out_degree_1331  1
    arc_1_21_7  original_T_including_depot_unload_1359  8.1417957710766450e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_7  arc_capacity_1171  1
    load_1_21_7  segment_load_conservation_1276  -1
    load_1_21_7  segment_prefix_lb_1277  1
    load_1_21_7  segment_prefix_ub_1278  1
    load_1_21_7  free_load_conservation_1336  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_8  arc_capacity_1173  -25
    arc_1_21_8  connected_order_arc_1174  -14
    arc_1_21_8  in_degree_1280  1
    arc_1_21_8  out_degree_1331  1
    arc_1_21_8  original_T_including_depot_unload_1359  1.0412376551742484e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_8  arc_capacity_1173  1
    load_1_21_8  segment_load_conservation_1283  -1
    load_1_21_8  segment_prefix_lb_1284  1
    load_1_21_8  segment_prefix_ub_1285  1
    load_1_21_8  free_load_conservation_1336  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_9  arc_capacity_1175  -25
    arc_1_21_9  connected_order_arc_1176  -14
    arc_1_21_9  in_degree_1287  1
    arc_1_21_9  out_degree_1331  1
    arc_1_21_9  original_T_including_depot_unload_1359  2.5572087458878266e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_9  arc_capacity_1175  1
    load_1_21_9  segment_load_conservation_1290  -1
    load_1_21_9  segment_prefix_lb_1291  1
    load_1_21_9  segment_prefix_ub_1292  1
    load_1_21_9  free_load_conservation_1336  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_10  arc_capacity_1177  -25
    arc_1_21_10  connected_order_arc_1178  -14
    arc_1_21_10  in_degree_1294  1
    arc_1_21_10  out_degree_1331  1
    arc_1_21_10  original_T_including_depot_unload_1359  1.6444540482789353e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_10  arc_capacity_1177  1
    load_1_21_10  segment_load_conservation_1297  -1
    load_1_21_10  segment_prefix_lb_1298  1
    load_1_21_10  segment_prefix_ub_1299  1
    load_1_21_10  free_load_conservation_1336  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_11  arc_capacity_1179  -25
    arc_1_21_11  connected_order_arc_1180  -14
    arc_1_21_11  in_degree_1301  1
    arc_1_21_11  out_degree_1331  1
    arc_1_21_11  original_T_including_depot_unload_1359  5.7102904773674652e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_11  arc_capacity_1179  1
    load_1_21_11  segment_load_conservation_1304  -1
    load_1_21_11  segment_prefix_lb_1305  1
    load_1_21_11  segment_prefix_ub_1306  1
    load_1_21_11  free_load_conservation_1336  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_17  arc_capacity_1181  -25
    arc_1_21_17  connected_order_arc_1182  -14
    arc_1_21_17  in_degree_1308  1
    arc_1_21_17  out_degree_1331  1
    arc_1_21_17  original_T_including_depot_unload_1359  1.4088953223409719e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_17  arc_capacity_1181  1
    load_1_21_17  free_load_conservation_1312  -1
    load_1_21_17  free_load_conservation_1336  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_18  arc_capacity_1183  -25
    arc_1_21_18  connected_order_arc_1184  -14
    arc_1_21_18  in_degree_1314  1
    arc_1_21_18  out_degree_1331  1
    arc_1_21_18  original_T_including_depot_unload_1359  1.6906177970488723e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_18  arc_capacity_1183  1
    load_1_21_18  free_load_conservation_1318  -1
    load_1_21_18  free_load_conservation_1336  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_19  arc_capacity_1185  -25
    arc_1_21_19  connected_order_arc_1186  -14
    arc_1_21_19  in_degree_1320  1
    arc_1_21_19  out_degree_1331  1
    arc_1_21_19  original_T_including_depot_unload_1359  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_19  arc_capacity_1185  1
    load_1_21_19  free_load_conservation_1324  -1
    load_1_21_19  free_load_conservation_1336  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_20  arc_capacity_1187  -25
    arc_1_21_20  connected_order_arc_1188  -14
    arc_1_21_20  in_degree_1326  1
    arc_1_21_20  out_degree_1331  1
    arc_1_21_20  original_T_including_depot_unload_1359  1.2674827380665711e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_20  arc_capacity_1187  1
    load_1_21_20  free_load_conservation_1330  -1
    load_1_21_20  free_load_conservation_1336  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_22  arc_capacity_1189  -25
    arc_1_21_22  connected_order_arc_1190  -14
    arc_1_21_22  out_degree_1331  1
    arc_1_21_22  in_degree_1338  1
    arc_1_21_22  original_T_including_depot_unload_1359  9.3962613467893414e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_22  arc_capacity_1189  1
    load_1_21_22  free_load_conservation_1336  1
    load_1_21_22  free_load_conservation_1342  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_23  arc_capacity_1191  -25
    arc_1_21_23  connected_order_arc_1192  -14
    arc_1_21_23  out_degree_1331  1
    arc_1_21_23  in_degree_1344  1
    arc_1_21_23  original_T_including_depot_unload_1359  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_23  arc_capacity_1191  1
    load_1_21_23  free_load_conservation_1336  1
    load_1_21_23  free_load_conservation_1348  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_24  arc_capacity_1193  -25
    arc_1_21_24  connected_order_arc_1194  -14
    arc_1_21_24  out_degree_1331  1
    arc_1_21_24  in_degree_1350  1
    arc_1_21_24  original_T_including_depot_unload_1359  603.649383070884
    MARKER    'MARKER'                 'INTEND'
    load_1_21_24  arc_capacity_1193  1
    load_1_21_24  free_load_conservation_1336  1
    load_1_21_24  free_load_conservation_1354  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_0  arc_capacity_1195  -25
    arc_1_22_0  depot_return_or_bypass_1271  1
    arc_1_22_0  out_degree_1337  1
    arc_1_22_0  original_T_including_depot_unload_1359  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_0  arc_capacity_1195  1
    load_1_22_0  free_load_conservation_1342  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_7  arc_capacity_1196  -25
    arc_1_22_7  connected_order_arc_1197  -14
    arc_1_22_7  in_degree_1273  1
    arc_1_22_7  out_degree_1337  1
    arc_1_22_7  original_T_including_depot_unload_1359  1.5546511874277910e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_22_7  arc_capacity_1196  1
    load_1_22_7  segment_load_conservation_1276  -1
    load_1_22_7  segment_prefix_lb_1277  1
    load_1_22_7  segment_prefix_ub_1278  1
    load_1_22_7  free_load_conservation_1342  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_8  arc_capacity_1198  -25
    arc_1_22_8  connected_order_arc_1199  -14
    arc_1_22_8  in_degree_1280  1
    arc_1_22_8  out_degree_1337  1
    arc_1_22_8  original_T_including_depot_unload_1359  1.5892857916507662e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_22_8  arc_capacity_1198  1
    load_1_22_8  segment_load_conservation_1283  -1
    load_1_22_8  segment_prefix_lb_1284  1
    load_1_22_8  segment_prefix_ub_1285  1
    load_1_22_8  free_load_conservation_1342  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_9  arc_capacity_1200  -25
    arc_1_22_9  connected_order_arc_1201  -14
    arc_1_22_9  in_degree_1287  1
    arc_1_22_9  out_degree_1337  1
    arc_1_22_9  original_T_including_depot_unload_1359  1.1952607376785465e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_22_9  arc_capacity_1200  1
    load_1_22_9  segment_load_conservation_1290  -1
    load_1_22_9  segment_prefix_lb_1291  1
    load_1_22_9  segment_prefix_ub_1292  1
    load_1_22_9  free_load_conservation_1342  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_10  arc_capacity_1202  -25
    arc_1_22_10  connected_order_arc_1203  -14
    arc_1_22_10  in_degree_1294  1
    arc_1_22_10  out_degree_1337  1
    arc_1_22_10  original_T_including_depot_unload_1359  7.7690262287132452e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_10  arc_capacity_1202  1
    load_1_22_10  segment_load_conservation_1297  -1
    load_1_22_10  segment_prefix_lb_1298  1
    load_1_22_10  segment_prefix_ub_1299  1
    load_1_22_10  free_load_conservation_1342  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_11  arc_capacity_1204  -25
    arc_1_22_11  connected_order_arc_1205  -14
    arc_1_22_11  in_degree_1301  1
    arc_1_22_11  out_degree_1337  1
    arc_1_22_11  original_T_including_depot_unload_1359  8.3393751072629220e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_11  arc_capacity_1204  1
    load_1_22_11  segment_load_conservation_1304  -1
    load_1_22_11  segment_prefix_lb_1305  1
    load_1_22_11  segment_prefix_ub_1306  1
    load_1_22_11  free_load_conservation_1342  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_17  arc_capacity_1206  -25
    arc_1_22_17  connected_order_arc_1207  -14
    arc_1_22_17  in_degree_1308  1
    arc_1_22_17  out_degree_1337  1
    arc_1_22_17  original_T_including_depot_unload_1359  6.4419272207888969e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_17  arc_capacity_1206  1
    load_1_22_17  free_load_conservation_1312  -1
    load_1_22_17  free_load_conservation_1342  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_18  arc_capacity_1208  -25
    arc_1_22_18  connected_order_arc_1209  -14
    arc_1_22_18  in_degree_1314  1
    arc_1_22_18  out_degree_1337  1
    arc_1_22_18  original_T_including_depot_unload_1359  7.6789230776331749e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_18  arc_capacity_1208  1
    load_1_22_18  free_load_conservation_1318  -1
    load_1_22_18  free_load_conservation_1342  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_19  arc_capacity_1210  -25
    arc_1_22_19  connected_order_arc_1211  -14
    arc_1_22_19  in_degree_1320  1
    arc_1_22_19  out_degree_1337  1
    arc_1_22_19  original_T_including_depot_unload_1359  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_22_19  arc_capacity_1210  1
    load_1_22_19  free_load_conservation_1324  -1
    load_1_22_19  free_load_conservation_1342  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_20  arc_capacity_1212  -25
    arc_1_22_20  connected_order_arc_1213  -14
    arc_1_22_20  in_degree_1326  1
    arc_1_22_20  out_degree_1337  1
    arc_1_22_20  original_T_including_depot_unload_1359  3.3469758905462760e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_20  arc_capacity_1212  1
    load_1_22_20  free_load_conservation_1330  -1
    load_1_22_20  free_load_conservation_1342  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_21  arc_capacity_1214  -25
    arc_1_22_21  connected_order_arc_1215  -14
    arc_1_22_21  in_degree_1332  1
    arc_1_22_21  out_degree_1337  1
    arc_1_22_21  original_T_including_depot_unload_1359  9.3962613467893414e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_21  arc_capacity_1214  1
    load_1_22_21  free_load_conservation_1336  -1
    load_1_22_21  free_load_conservation_1342  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_23  arc_capacity_1216  -25
    arc_1_22_23  connected_order_arc_1217  -14
    arc_1_22_23  out_degree_1337  1
    arc_1_22_23  in_degree_1344  1
    arc_1_22_23  original_T_including_depot_unload_1359  1.5968108380866881e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_22_23  arc_capacity_1216  1
    load_1_22_23  free_load_conservation_1342  1
    load_1_22_23  free_load_conservation_1348  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_24  arc_capacity_1218  -25
    arc_1_22_24  connected_order_arc_1219  -14
    arc_1_22_24  out_degree_1337  1
    arc_1_22_24  in_degree_1350  1
    arc_1_22_24  original_T_including_depot_unload_1359  3.4289721135663990e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_24  arc_capacity_1218  1
    load_1_22_24  free_load_conservation_1342  1
    load_1_22_24  free_load_conservation_1354  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_23_0  arc_capacity_1220  -25
    arc_1_23_0  depot_return_or_bypass_1271  1
    arc_1_23_0  out_degree_1343  1
    arc_1_23_0  original_T_including_depot_unload_1359  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_23_0  arc_capacity_1220  1
    load_1_23_0  free_load_conservation_1348  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_23_7  arc_capacity_1221  -25
    arc_1_23_7  connected_order_arc_1222  -14
    arc_1_23_7  in_degree_1273  1
    arc_1_23_7  out_degree_1343  1
    arc_1_23_7  original_T_including_depot_unload_1359  1.8442669473423912e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_23_7  arc_capacity_1221  1
    load_1_23_7  segment_load_conservation_1276  -1
    load_1_23_7  segment_prefix_lb_1277  1
    load_1_23_7  segment_prefix_ub_1278  1
    load_1_23_7  free_load_conservation_1348  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_23_8  arc_capacity_1223  -25
    arc_1_23_8  connected_order_arc_1224  -14
    arc_1_23_8  in_degree_1280  1
    arc_1_23_8  out_degree_1343  1
    arc_1_23_8  original_T_including_depot_unload_1359  1.5502221880497036e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_23_8  arc_capacity_1223  1
    load_1_23_8  segment_load_conservation_1283  -1
    load_1_23_8  segment_prefix_lb_1284  1
    load_1_23_8  segment_prefix_ub_1285  1
    load_1_23_8  free_load_conservation_1348  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_23_9  arc_capacity_1225  -25
    arc_1_23_9  connected_order_arc_1226  -14
    arc_1_23_9  in_degree_1287  1
    arc_1_23_9  out_degree_1343  1
    arc_1_23_9  original_T_including_depot_unload_1359  2115.53677476792
    MARKER    'MARKER'                 'INTEND'
    load_1_23_9  arc_capacity_1225  1
    load_1_23_9  segment_load_conservation_1290  -1
    load_1_23_9  segment_prefix_lb_1291  1
    load_1_23_9  segment_prefix_ub_1292  1
    load_1_23_9  free_load_conservation_1348  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_23_10  arc_capacity_1227  -25
    arc_1_23_10  connected_order_arc_1228  -14
    arc_1_23_10  in_degree_1294  1
    arc_1_23_10  out_degree_1343  1
    arc_1_23_10  original_T_including_depot_unload_1359  1.8418804985785646e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_23_10  arc_capacity_1227  1
    load_1_23_10  segment_load_conservation_1297  -1
    load_1_23_10  segment_prefix_lb_1298  1
    load_1_23_10  segment_prefix_ub_1299  1
    load_1_23_10  free_load_conservation_1348  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_23_11  arc_capacity_1229  -25
    arc_1_23_11  connected_order_arc_1230  -14
    arc_1_23_11  in_degree_1301  1
    arc_1_23_11  out_degree_1343  1
    arc_1_23_11  original_T_including_depot_unload_1359  1.3857128117205509e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_23_11  arc_capacity_1229  1
    load_1_23_11  segment_load_conservation_1304  -1
    load_1_23_11  segment_prefix_lb_1305  1
    load_1_23_11  segment_prefix_ub_1306  1
    load_1_23_11  free_load_conservation_1348  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_23_17  arc_capacity_1231  -25
    arc_1_23_17  connected_order_arc_1232  -14
    arc_1_23_17  in_degree_1308  1
    arc_1_23_17  out_degree_1343  1
    arc_1_23_17  original_T_including_depot_unload_1359  2.1214998192647863e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_23_17  arc_capacity_1231  1
    load_1_23_17  free_load_conservation_1312  -1
    load_1_23_17  free_load_conservation_1348  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_23_18  arc_capacity_1233  -25
    arc_1_23_18  connected_order_arc_1234  -14
    arc_1_23_18  in_degree_1314  1
    arc_1_23_18  out_degree_1343  1
    arc_1_23_18  original_T_including_depot_unload_1359  1.8780729343410642e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_23_18  arc_capacity_1233  1
    load_1_23_18  free_load_conservation_1318  -1
    load_1_23_18  free_load_conservation_1348  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_23_19  arc_capacity_1235  -25
    arc_1_23_19  connected_order_arc_1236  -14
    arc_1_23_19  in_degree_1320  1
    arc_1_23_19  out_degree_1343  1
    arc_1_23_19  original_T_including_depot_unload_1359  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_23_19  arc_capacity_1235  1
    load_1_23_19  free_load_conservation_1324  -1
    load_1_23_19  free_load_conservation_1348  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_23_20  arc_capacity_1237  -25
    arc_1_23_20  connected_order_arc_1238  -14
    arc_1_23_20  in_degree_1326  1
    arc_1_23_20  out_degree_1343  1
    arc_1_23_20  original_T_including_depot_unload_1359  1.5117151439160034e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_23_20  arc_capacity_1237  1
    load_1_23_20  free_load_conservation_1330  -1
    load_1_23_20  free_load_conservation_1348  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_23_21  arc_capacity_1239  -25
    arc_1_23_21  connected_order_arc_1240  -14
    arc_1_23_21  in_degree_1332  1
    arc_1_23_21  out_degree_1343  1
    arc_1_23_21  original_T_including_depot_unload_1359  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_23_21  arc_capacity_1239  1
    load_1_23_21  free_load_conservation_1336  -1
    load_1_23_21  free_load_conservation_1348  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_23_22  arc_capacity_1241  -25
    arc_1_23_22  connected_order_arc_1242  -14
    arc_1_23_22  in_degree_1338  1
    arc_1_23_22  out_degree_1343  1
    arc_1_23_22  original_T_including_depot_unload_1359  1.5968108380866881e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_23_22  arc_capacity_1241  1
    load_1_23_22  free_load_conservation_1342  -1
    load_1_23_22  free_load_conservation_1348  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_23_24  arc_capacity_1243  -25
    arc_1_23_24  connected_order_arc_1244  -14
    arc_1_23_24  out_degree_1343  1
    arc_1_23_24  in_degree_1350  1
    arc_1_23_24  original_T_including_depot_unload_1359  1.7249161387293191e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_23_24  arc_capacity_1243  1
    load_1_23_24  free_load_conservation_1348  1
    load_1_23_24  free_load_conservation_1354  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_24_0  arc_capacity_1245  -25
    arc_1_24_0  depot_return_or_bypass_1271  1
    arc_1_24_0  out_degree_1349  1
    arc_1_24_0  original_T_including_depot_unload_1359  5.4249700630778887e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_24_0  arc_capacity_1245  1
    load_1_24_0  free_load_conservation_1354  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_24_7  arc_capacity_1246  -25
    arc_1_24_7  connected_order_arc_1247  -14
    arc_1_24_7  in_degree_1273  1
    arc_1_24_7  out_degree_1349  1
    arc_1_24_7  original_T_including_depot_unload_1359  1.2876689365561549e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_24_7  arc_capacity_1246  1
    load_1_24_7  segment_load_conservation_1276  -1
    load_1_24_7  segment_prefix_lb_1277  1
    load_1_24_7  segment_prefix_ub_1278  1
    load_1_24_7  free_load_conservation_1354  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_24_8  arc_capacity_1248  -25
    arc_1_24_8  connected_order_arc_1249  -14
    arc_1_24_8  in_degree_1280  1
    arc_1_24_8  out_degree_1349  1
    arc_1_24_8  original_T_including_depot_unload_1359  1.3840439316159188e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_24_8  arc_capacity_1248  1
    load_1_24_8  segment_load_conservation_1283  -1
    load_1_24_8  segment_prefix_lb_1284  1
    load_1_24_8  segment_prefix_ub_1285  1
    load_1_24_8  free_load_conservation_1354  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_24_9  arc_capacity_1250  -25
    arc_1_24_9  connected_order_arc_1251  -14
    arc_1_24_9  in_degree_1287  1
    arc_1_24_9  out_degree_1349  1
    arc_1_24_9  original_T_including_depot_unload_1359  8.5807018379884664e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_24_9  arc_capacity_1250  1
    load_1_24_9  segment_load_conservation_1290  -1
    load_1_24_9  segment_prefix_lb_1291  1
    load_1_24_9  segment_prefix_ub_1292  1
    load_1_24_9  free_load_conservation_1354  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_24_10  arc_capacity_1252  -25
    arc_1_24_10  connected_order_arc_1253  -14
    arc_1_24_10  in_degree_1294  1
    arc_1_24_10  out_degree_1349  1
    arc_1_24_10  original_T_including_depot_unload_1359  4.4474809771996007e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_24_10  arc_capacity_1252  1
    load_1_24_10  segment_load_conservation_1297  -1
    load_1_24_10  segment_prefix_lb_1298  1
    load_1_24_10  segment_prefix_ub_1299  1
    load_1_24_10  free_load_conservation_1354  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_24_11  arc_capacity_1254  -25
    arc_1_24_11  connected_order_arc_1255  -14
    arc_1_24_11  in_degree_1301  1
    arc_1_24_11  out_degree_1349  1
    arc_1_24_11  original_T_including_depot_unload_1359  6.4572843340219208e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_24_11  arc_capacity_1254  1
    load_1_24_11  segment_load_conservation_1304  -1
    load_1_24_11  segment_prefix_lb_1305  1
    load_1_24_11  segment_prefix_ub_1306  1
    load_1_24_11  free_load_conservation_1354  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_24_17  arc_capacity_1256  -25
    arc_1_24_17  connected_order_arc_1257  -14
    arc_1_24_17  in_degree_1308  1
    arc_1_24_17  out_degree_1349  1
    arc_1_24_17  original_T_including_depot_unload_1359  8.4962277657921186e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_24_17  arc_capacity_1256  1
    load_1_24_17  free_load_conservation_1312  -1
    load_1_24_17  free_load_conservation_1354  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_24_18  arc_capacity_1258  -25
    arc_1_24_18  connected_order_arc_1259  -14
    arc_1_24_18  in_degree_1314  1
    arc_1_24_18  out_degree_1349  1
    arc_1_24_18  original_T_including_depot_unload_1359  1.0875821153726588e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_24_18  arc_capacity_1258  1
    load_1_24_18  free_load_conservation_1318  -1
    load_1_24_18  free_load_conservation_1354  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_24_19  arc_capacity_1260  -25
    arc_1_24_19  connected_order_arc_1261  -14
    arc_1_24_19  in_degree_1320  1
    arc_1_24_19  out_degree_1349  1
    arc_1_24_19  original_T_including_depot_unload_1359  1.6231508478292610e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_24_19  arc_capacity_1260  1
    load_1_24_19  free_load_conservation_1324  -1
    load_1_24_19  free_load_conservation_1354  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_24_20  arc_capacity_1262  -25
    arc_1_24_20  connected_order_arc_1263  -14
    arc_1_24_20  in_degree_1326  1
    arc_1_24_20  out_degree_1349  1
    arc_1_24_20  original_T_including_depot_unload_1359  6.7711923781893620e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_24_20  arc_capacity_1262  1
    load_1_24_20  free_load_conservation_1330  -1
    load_1_24_20  free_load_conservation_1354  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_24_21  arc_capacity_1264  -25
    arc_1_24_21  connected_order_arc_1265  -14
    arc_1_24_21  in_degree_1332  1
    arc_1_24_21  out_degree_1349  1
    arc_1_24_21  original_T_including_depot_unload_1359  603.649383070884
    MARKER    'MARKER'                 'INTEND'
    load_1_24_21  arc_capacity_1264  1
    load_1_24_21  free_load_conservation_1336  -1
    load_1_24_21  free_load_conservation_1354  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_24_22  arc_capacity_1266  -25
    arc_1_24_22  connected_order_arc_1267  -14
    arc_1_24_22  in_degree_1338  1
    arc_1_24_22  out_degree_1349  1
    arc_1_24_22  original_T_including_depot_unload_1359  3.4289721135663990e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_24_22  arc_capacity_1266  1
    load_1_24_22  free_load_conservation_1342  -1
    load_1_24_22  free_load_conservation_1354  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_24_23  arc_capacity_1268  -25
    arc_1_24_23  connected_order_arc_1269  -14
    arc_1_24_23  in_degree_1344  1
    arc_1_24_23  out_degree_1349  1
    arc_1_24_23  original_T_including_depot_unload_1359  1.7249161387293191e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_24_23  arc_capacity_1268  1
    load_1_24_23  free_load_conservation_1348  -1
    load_1_24_23  free_load_conservation_1354  1
    visit_2_12  out_degree_1701  -1
    visit_2_12  in_degree_1702  -1
    visit_2_12  order_active_lb_1703  -1
    visit_2_12  order_active_ub_1704  -13
    order_2_12  connected_order_arc_1376  -1
    order_2_12  connected_order_arc_1378  -1
    order_2_12  connected_order_arc_1380  -1
    order_2_12  connected_order_arc_1382  -1
    order_2_12  connected_order_arc_1384  -1
    order_2_12  connected_order_arc_1386  -1
    order_2_12  connected_order_arc_1388  -1
    order_2_12  connected_order_arc_1390  -1
    order_2_12  connected_order_arc_1392  -1
    order_2_12  connected_order_arc_1394  -1
    order_2_12  connected_order_arc_1396  -1
    order_2_12  connected_order_arc_1398  -1
    order_2_12  connected_order_arc_1401  1
    order_2_12  connected_order_arc_1426  1
    order_2_12  connected_order_arc_1451  1
    order_2_12  connected_order_arc_1476  1
    order_2_12  connected_order_arc_1501  1
    order_2_12  connected_order_arc_1526  1
    order_2_12  connected_order_arc_1551  1
    order_2_12  connected_order_arc_1576  1
    order_2_12  connected_order_arc_1601  1
    order_2_12  connected_order_arc_1626  1
    order_2_12  connected_order_arc_1651  1
    order_2_12  connected_order_arc_1676  1
    order_2_12  order_active_lb_1703  1
    order_2_12  order_active_ub_1704  1
    order_2_12  fixed_segment_relative_order_1784  -1
    visit_2_13  out_degree_1708  -1
    visit_2_13  in_degree_1709  -1
    visit_2_13  order_active_lb_1710  -1
    visit_2_13  order_active_ub_1711  -13
    order_2_13  connected_order_arc_1376  1
    order_2_13  connected_order_arc_1401  -1
    order_2_13  connected_order_arc_1403  -1
    order_2_13  connected_order_arc_1405  -1
    order_2_13  connected_order_arc_1407  -1
    order_2_13  connected_order_arc_1409  -1
    order_2_13  connected_order_arc_1411  -1
    order_2_13  connected_order_arc_1413  -1
    order_2_13  connected_order_arc_1415  -1
    order_2_13  connected_order_arc_1417  -1
    order_2_13  connected_order_arc_1419  -1
    order_2_13  connected_order_arc_1421  -1
    order_2_13  connected_order_arc_1423  -1
    order_2_13  connected_order_arc_1428  1
    order_2_13  connected_order_arc_1453  1
    order_2_13  connected_order_arc_1478  1
    order_2_13  connected_order_arc_1503  1
    order_2_13  connected_order_arc_1528  1
    order_2_13  connected_order_arc_1553  1
    order_2_13  connected_order_arc_1578  1
    order_2_13  connected_order_arc_1603  1
    order_2_13  connected_order_arc_1628  1
    order_2_13  connected_order_arc_1653  1
    order_2_13  connected_order_arc_1678  1
    order_2_13  order_active_lb_1710  1
    order_2_13  order_active_ub_1711  1
    order_2_13  fixed_segment_relative_order_1784  1
    order_2_13  fixed_segment_relative_order_1785  -1
    visit_2_14  out_degree_1715  -1
    visit_2_14  in_degree_1716  -1
    visit_2_14  order_active_lb_1717  -1
    visit_2_14  order_active_ub_1718  -13
    order_2_14  connected_order_arc_1378  1
    order_2_14  connected_order_arc_1403  1
    order_2_14  connected_order_arc_1426  -1
    order_2_14  connected_order_arc_1428  -1
    order_2_14  connected_order_arc_1430  -1
    order_2_14  connected_order_arc_1432  -1
    order_2_14  connected_order_arc_1434  -1
    order_2_14  connected_order_arc_1436  -1
    order_2_14  connected_order_arc_1438  -1
    order_2_14  connected_order_arc_1440  -1
    order_2_14  connected_order_arc_1442  -1
    order_2_14  connected_order_arc_1444  -1
    order_2_14  connected_order_arc_1446  -1
    order_2_14  connected_order_arc_1448  -1
    order_2_14  connected_order_arc_1455  1
    order_2_14  connected_order_arc_1480  1
    order_2_14  connected_order_arc_1505  1
    order_2_14  connected_order_arc_1530  1
    order_2_14  connected_order_arc_1555  1
    order_2_14  connected_order_arc_1580  1
    order_2_14  connected_order_arc_1605  1
    order_2_14  connected_order_arc_1630  1
    order_2_14  connected_order_arc_1655  1
    order_2_14  connected_order_arc_1680  1
    order_2_14  order_active_lb_1717  1
    order_2_14  order_active_ub_1718  1
    order_2_14  fixed_segment_relative_order_1785  1
    order_2_14  fixed_segment_relative_order_1786  -1
    visit_2_15  out_degree_1722  -1
    visit_2_15  in_degree_1723  -1
    visit_2_15  order_active_lb_1724  -1
    visit_2_15  order_active_ub_1725  -13
    order_2_15  connected_order_arc_1380  1
    order_2_15  connected_order_arc_1405  1
    order_2_15  connected_order_arc_1430  1
    order_2_15  connected_order_arc_1451  -1
    order_2_15  connected_order_arc_1453  -1
    order_2_15  connected_order_arc_1455  -1
    order_2_15  connected_order_arc_1457  -1
    order_2_15  connected_order_arc_1459  -1
    order_2_15  connected_order_arc_1461  -1
    order_2_15  connected_order_arc_1463  -1
    order_2_15  connected_order_arc_1465  -1
    order_2_15  connected_order_arc_1467  -1
    order_2_15  connected_order_arc_1469  -1
    order_2_15  connected_order_arc_1471  -1
    order_2_15  connected_order_arc_1473  -1
    order_2_15  connected_order_arc_1482  1
    order_2_15  connected_order_arc_1507  1
    order_2_15  connected_order_arc_1532  1
    order_2_15  connected_order_arc_1557  1
    order_2_15  connected_order_arc_1582  1
    order_2_15  connected_order_arc_1607  1
    order_2_15  connected_order_arc_1632  1
    order_2_15  connected_order_arc_1657  1
    order_2_15  connected_order_arc_1682  1
    order_2_15  order_active_lb_1724  1
    order_2_15  order_active_ub_1725  1
    order_2_15  fixed_segment_relative_order_1786  1
    order_2_15  fixed_segment_relative_order_1787  -1
    visit_2_16  out_degree_1729  -1
    visit_2_16  in_degree_1730  -1
    visit_2_16  order_active_lb_1731  -1
    visit_2_16  order_active_ub_1732  -13
    order_2_16  connected_order_arc_1382  1
    order_2_16  connected_order_arc_1407  1
    order_2_16  connected_order_arc_1432  1
    order_2_16  connected_order_arc_1457  1
    order_2_16  connected_order_arc_1476  -1
    order_2_16  connected_order_arc_1478  -1
    order_2_16  connected_order_arc_1480  -1
    order_2_16  connected_order_arc_1482  -1
    order_2_16  connected_order_arc_1484  -1
    order_2_16  connected_order_arc_1486  -1
    order_2_16  connected_order_arc_1488  -1
    order_2_16  connected_order_arc_1490  -1
    order_2_16  connected_order_arc_1492  -1
    order_2_16  connected_order_arc_1494  -1
    order_2_16  connected_order_arc_1496  -1
    order_2_16  connected_order_arc_1498  -1
    order_2_16  connected_order_arc_1509  1
    order_2_16  connected_order_arc_1534  1
    order_2_16  connected_order_arc_1559  1
    order_2_16  connected_order_arc_1584  1
    order_2_16  connected_order_arc_1609  1
    order_2_16  connected_order_arc_1634  1
    order_2_16  connected_order_arc_1659  1
    order_2_16  connected_order_arc_1684  1
    order_2_16  order_active_lb_1731  1
    order_2_16  order_active_ub_1732  1
    order_2_16  fixed_segment_relative_order_1787  1
    visit_2_17  out_degree_1736  -1
    visit_2_17  in_degree_1737  -1
    visit_2_17  order_active_lb_1738  -1
    visit_2_17  order_active_ub_1739  -13
    visit_2_17  service_visit_def_1740  -1
    order_2_17  connected_order_arc_1384  1
    order_2_17  connected_order_arc_1409  1
    order_2_17  connected_order_arc_1434  1
    order_2_17  connected_order_arc_1459  1
    order_2_17  connected_order_arc_1484  1
    order_2_17  connected_order_arc_1501  -1
    order_2_17  connected_order_arc_1503  -1
    order_2_17  connected_order_arc_1505  -1
    order_2_17  connected_order_arc_1507  -1
    order_2_17  connected_order_arc_1509  -1
    order_2_17  connected_order_arc_1511  -1
    order_2_17  connected_order_arc_1513  -1
    order_2_17  connected_order_arc_1515  -1
    order_2_17  connected_order_arc_1517  -1
    order_2_17  connected_order_arc_1519  -1
    order_2_17  connected_order_arc_1521  -1
    order_2_17  connected_order_arc_1523  -1
    order_2_17  connected_order_arc_1536  1
    order_2_17  connected_order_arc_1561  1
    order_2_17  connected_order_arc_1586  1
    order_2_17  connected_order_arc_1611  1
    order_2_17  connected_order_arc_1636  1
    order_2_17  connected_order_arc_1661  1
    order_2_17  connected_order_arc_1686  1
    order_2_17  order_active_lb_1738  1
    order_2_17  order_active_ub_1739  1
    visit_2_18  out_degree_1742  -1
    visit_2_18  in_degree_1743  -1
    visit_2_18  order_active_lb_1744  -1
    visit_2_18  order_active_ub_1745  -13
    visit_2_18  service_visit_def_1746  -1
    order_2_18  connected_order_arc_1386  1
    order_2_18  connected_order_arc_1411  1
    order_2_18  connected_order_arc_1436  1
    order_2_18  connected_order_arc_1461  1
    order_2_18  connected_order_arc_1486  1
    order_2_18  connected_order_arc_1511  1
    order_2_18  connected_order_arc_1526  -1
    order_2_18  connected_order_arc_1528  -1
    order_2_18  connected_order_arc_1530  -1
    order_2_18  connected_order_arc_1532  -1
    order_2_18  connected_order_arc_1534  -1
    order_2_18  connected_order_arc_1536  -1
    order_2_18  connected_order_arc_1538  -1
    order_2_18  connected_order_arc_1540  -1
    order_2_18  connected_order_arc_1542  -1
    order_2_18  connected_order_arc_1544  -1
    order_2_18  connected_order_arc_1546  -1
    order_2_18  connected_order_arc_1548  -1
    order_2_18  connected_order_arc_1563  1
    order_2_18  connected_order_arc_1588  1
    order_2_18  connected_order_arc_1613  1
    order_2_18  connected_order_arc_1638  1
    order_2_18  connected_order_arc_1663  1
    order_2_18  connected_order_arc_1688  1
    order_2_18  order_active_lb_1744  1
    order_2_18  order_active_ub_1745  1
    visit_2_19  out_degree_1748  -1
    visit_2_19  in_degree_1749  -1
    visit_2_19  order_active_lb_1750  -1
    visit_2_19  order_active_ub_1751  -13
    visit_2_19  service_visit_def_1752  -1
    order_2_19  connected_order_arc_1388  1
    order_2_19  connected_order_arc_1413  1
    order_2_19  connected_order_arc_1438  1
    order_2_19  connected_order_arc_1463  1
    order_2_19  connected_order_arc_1488  1
    order_2_19  connected_order_arc_1513  1
    order_2_19  connected_order_arc_1538  1
    order_2_19  connected_order_arc_1551  -1
    order_2_19  connected_order_arc_1553  -1
    order_2_19  connected_order_arc_1555  -1
    order_2_19  connected_order_arc_1557  -1
    order_2_19  connected_order_arc_1559  -1
    order_2_19  connected_order_arc_1561  -1
    order_2_19  connected_order_arc_1563  -1
    order_2_19  connected_order_arc_1565  -1
    order_2_19  connected_order_arc_1567  -1
    order_2_19  connected_order_arc_1569  -1
    order_2_19  connected_order_arc_1571  -1
    order_2_19  connected_order_arc_1573  -1
    order_2_19  connected_order_arc_1590  1
    order_2_19  connected_order_arc_1615  1
    order_2_19  connected_order_arc_1640  1
    order_2_19  connected_order_arc_1665  1
    order_2_19  connected_order_arc_1690  1
    order_2_19  order_active_lb_1750  1
    order_2_19  order_active_ub_1751  1
    visit_2_20  out_degree_1754  -1
    visit_2_20  in_degree_1755  -1
    visit_2_20  order_active_lb_1756  -1
    visit_2_20  order_active_ub_1757  -13
    visit_2_20  service_visit_def_1758  -1
    order_2_20  connected_order_arc_1390  1
    order_2_20  connected_order_arc_1415  1
    order_2_20  connected_order_arc_1440  1
    order_2_20  connected_order_arc_1465  1
    order_2_20  connected_order_arc_1490  1
    order_2_20  connected_order_arc_1515  1
    order_2_20  connected_order_arc_1540  1
    order_2_20  connected_order_arc_1565  1
    order_2_20  connected_order_arc_1576  -1
    order_2_20  connected_order_arc_1578  -1
    order_2_20  connected_order_arc_1580  -1
    order_2_20  connected_order_arc_1582  -1
    order_2_20  connected_order_arc_1584  -1
    order_2_20  connected_order_arc_1586  -1
    order_2_20  connected_order_arc_1588  -1
    order_2_20  connected_order_arc_1590  -1
    order_2_20  connected_order_arc_1592  -1
    order_2_20  connected_order_arc_1594  -1
    order_2_20  connected_order_arc_1596  -1
    order_2_20  connected_order_arc_1598  -1
    order_2_20  connected_order_arc_1617  1
    order_2_20  connected_order_arc_1642  1
    order_2_20  connected_order_arc_1667  1
    order_2_20  connected_order_arc_1692  1
    order_2_20  order_active_lb_1756  1
    order_2_20  order_active_ub_1757  1
    visit_2_21  out_degree_1760  -1
    visit_2_21  in_degree_1761  -1
    visit_2_21  order_active_lb_1762  -1
    visit_2_21  order_active_ub_1763  -13
    visit_2_21  service_visit_def_1764  -1
    order_2_21  connected_order_arc_1392  1
    order_2_21  connected_order_arc_1417  1
    order_2_21  connected_order_arc_1442  1
    order_2_21  connected_order_arc_1467  1
    order_2_21  connected_order_arc_1492  1
    order_2_21  connected_order_arc_1517  1
    order_2_21  connected_order_arc_1542  1
    order_2_21  connected_order_arc_1567  1
    order_2_21  connected_order_arc_1592  1
    order_2_21  connected_order_arc_1601  -1
    order_2_21  connected_order_arc_1603  -1
    order_2_21  connected_order_arc_1605  -1
    order_2_21  connected_order_arc_1607  -1
    order_2_21  connected_order_arc_1609  -1
    order_2_21  connected_order_arc_1611  -1
    order_2_21  connected_order_arc_1613  -1
    order_2_21  connected_order_arc_1615  -1
    order_2_21  connected_order_arc_1617  -1
    order_2_21  connected_order_arc_1619  -1
    order_2_21  connected_order_arc_1621  -1
    order_2_21  connected_order_arc_1623  -1
    order_2_21  connected_order_arc_1644  1
    order_2_21  connected_order_arc_1669  1
    order_2_21  connected_order_arc_1694  1
    order_2_21  order_active_lb_1762  1
    order_2_21  order_active_ub_1763  1
    visit_2_22  out_degree_1766  -1
    visit_2_22  in_degree_1767  -1
    visit_2_22  order_active_lb_1768  -1
    visit_2_22  order_active_ub_1769  -13
    visit_2_22  service_visit_def_1770  -1
    order_2_22  connected_order_arc_1394  1
    order_2_22  connected_order_arc_1419  1
    order_2_22  connected_order_arc_1444  1
    order_2_22  connected_order_arc_1469  1
    order_2_22  connected_order_arc_1494  1
    order_2_22  connected_order_arc_1519  1
    order_2_22  connected_order_arc_1544  1
    order_2_22  connected_order_arc_1569  1
    order_2_22  connected_order_arc_1594  1
    order_2_22  connected_order_arc_1619  1
    order_2_22  connected_order_arc_1626  -1
    order_2_22  connected_order_arc_1628  -1
    order_2_22  connected_order_arc_1630  -1
    order_2_22  connected_order_arc_1632  -1
    order_2_22  connected_order_arc_1634  -1
    order_2_22  connected_order_arc_1636  -1
    order_2_22  connected_order_arc_1638  -1
    order_2_22  connected_order_arc_1640  -1
    order_2_22  connected_order_arc_1642  -1
    order_2_22  connected_order_arc_1644  -1
    order_2_22  connected_order_arc_1646  -1
    order_2_22  connected_order_arc_1648  -1
    order_2_22  connected_order_arc_1671  1
    order_2_22  connected_order_arc_1696  1
    order_2_22  order_active_lb_1768  1
    order_2_22  order_active_ub_1769  1
    visit_2_23  out_degree_1772  -1
    visit_2_23  in_degree_1773  -1
    visit_2_23  order_active_lb_1774  -1
    visit_2_23  order_active_ub_1775  -13
    visit_2_23  service_visit_def_1776  -1
    order_2_23  connected_order_arc_1396  1
    order_2_23  connected_order_arc_1421  1
    order_2_23  connected_order_arc_1446  1
    order_2_23  connected_order_arc_1471  1
    order_2_23  connected_order_arc_1496  1
    order_2_23  connected_order_arc_1521  1
    order_2_23  connected_order_arc_1546  1
    order_2_23  connected_order_arc_1571  1
    order_2_23  connected_order_arc_1596  1
    order_2_23  connected_order_arc_1621  1
    order_2_23  connected_order_arc_1646  1
    order_2_23  connected_order_arc_1651  -1
    order_2_23  connected_order_arc_1653  -1
    order_2_23  connected_order_arc_1655  -1
    order_2_23  connected_order_arc_1657  -1
    order_2_23  connected_order_arc_1659  -1
    order_2_23  connected_order_arc_1661  -1
    order_2_23  connected_order_arc_1663  -1
    order_2_23  connected_order_arc_1665  -1
    order_2_23  connected_order_arc_1667  -1
    order_2_23  connected_order_arc_1669  -1
    order_2_23  connected_order_arc_1671  -1
    order_2_23  connected_order_arc_1673  -1
    order_2_23  connected_order_arc_1698  1
    order_2_23  order_active_lb_1774  1
    order_2_23  order_active_ub_1775  1
    visit_2_24  out_degree_1778  -1
    visit_2_24  in_degree_1779  -1
    visit_2_24  order_active_lb_1780  -1
    visit_2_24  order_active_ub_1781  -13
    visit_2_24  service_visit_def_1782  -1
    order_2_24  connected_order_arc_1398  1
    order_2_24  connected_order_arc_1423  1
    order_2_24  connected_order_arc_1448  1
    order_2_24  connected_order_arc_1473  1
    order_2_24  connected_order_arc_1498  1
    order_2_24  connected_order_arc_1523  1
    order_2_24  connected_order_arc_1548  1
    order_2_24  connected_order_arc_1573  1
    order_2_24  connected_order_arc_1598  1
    order_2_24  connected_order_arc_1623  1
    order_2_24  connected_order_arc_1648  1
    order_2_24  connected_order_arc_1673  1
    order_2_24  connected_order_arc_1676  -1
    order_2_24  connected_order_arc_1678  -1
    order_2_24  connected_order_arc_1680  -1
    order_2_24  connected_order_arc_1682  -1
    order_2_24  connected_order_arc_1684  -1
    order_2_24  connected_order_arc_1686  -1
    order_2_24  connected_order_arc_1688  -1
    order_2_24  connected_order_arc_1690  -1
    order_2_24  connected_order_arc_1692  -1
    order_2_24  connected_order_arc_1694  -1
    order_2_24  connected_order_arc_1696  -1
    order_2_24  connected_order_arc_1698  -1
    order_2_24  order_active_lb_1780  1
    order_2_24  order_active_ub_1781  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_0  arc_capacity_1360  -30
    arc_2_0_0  depot_departure_or_bypass_1699  1
    arc_2_0_0  depot_return_or_bypass_1700  1
    MARKER    'MARKER'                 'INTEND'
    load_2_0_0  arc_capacity_1360  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_12  arc_capacity_1361  -30
    arc_2_0_12  depot_departure_or_bypass_1699  1
    arc_2_0_12  in_degree_1702  1
    arc_2_0_12  original_T_including_depot_unload_1788  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_12  arc_capacity_1361  1
    load_2_0_12  segment_load_conservation_1705  -1
    load_2_0_12  segment_prefix_lb_1706  1
    load_2_0_12  segment_prefix_ub_1707  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_13  arc_capacity_1362  -30
    arc_2_0_13  depot_departure_or_bypass_1699  1
    arc_2_0_13  in_degree_1709  1
    arc_2_0_13  original_T_including_depot_unload_1788  1.4567038050199781e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_13  arc_capacity_1362  1
    load_2_0_13  segment_load_conservation_1712  -1
    load_2_0_13  segment_prefix_lb_1713  1
    load_2_0_13  segment_prefix_ub_1714  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_14  arc_capacity_1363  -30
    arc_2_0_14  depot_departure_or_bypass_1699  1
    arc_2_0_14  in_degree_1716  1
    arc_2_0_14  original_T_including_depot_unload_1788  1.2506062209426416e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_14  arc_capacity_1363  1
    load_2_0_14  segment_load_conservation_1719  -1
    load_2_0_14  segment_prefix_lb_1720  1
    load_2_0_14  segment_prefix_ub_1721  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_15  arc_capacity_1364  -30
    arc_2_0_15  depot_departure_or_bypass_1699  1
    arc_2_0_15  in_degree_1723  1
    arc_2_0_15  original_T_including_depot_unload_1788  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_15  arc_capacity_1364  1
    load_2_0_15  segment_load_conservation_1726  -1
    load_2_0_15  segment_prefix_lb_1727  1
    load_2_0_15  segment_prefix_ub_1728  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_16  arc_capacity_1365  -30
    arc_2_0_16  depot_departure_or_bypass_1699  1
    arc_2_0_16  in_degree_1730  1
    arc_2_0_16  original_T_including_depot_unload_1788  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_16  arc_capacity_1365  1
    load_2_0_16  segment_load_conservation_1733  -1
    load_2_0_16  segment_prefix_lb_1734  1
    load_2_0_16  segment_prefix_ub_1735  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_17  arc_capacity_1366  -30
    arc_2_0_17  depot_departure_or_bypass_1699  1
    arc_2_0_17  in_degree_1737  1
    arc_2_0_17  original_T_including_depot_unload_1788  1.3396590612935172e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_17  arc_capacity_1366  1
    load_2_0_17  free_load_conservation_1741  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_18  arc_capacity_1367  -30
    arc_2_0_18  depot_departure_or_bypass_1699  1
    arc_2_0_18  in_degree_1743  1
    arc_2_0_18  original_T_including_depot_unload_1788  1.4501558573355060e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_18  arc_capacity_1367  1
    load_2_0_18  free_load_conservation_1747  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_19  arc_capacity_1368  -30
    arc_2_0_19  depot_departure_or_bypass_1699  1
    arc_2_0_19  in_degree_1749  1
    arc_2_0_19  original_T_including_depot_unload_1788  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_19  arc_capacity_1368  1
    load_2_0_19  free_load_conservation_1753  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_20  arc_capacity_1369  -30
    arc_2_0_20  depot_departure_or_bypass_1699  1
    arc_2_0_20  in_degree_1755  1
    arc_2_0_20  original_T_including_depot_unload_1788  9.5330620720858735e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_20  arc_capacity_1369  1
    load_2_0_20  free_load_conservation_1759  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_21  arc_capacity_1370  -30
    arc_2_0_21  depot_departure_or_bypass_1699  1
    arc_2_0_21  in_degree_1761  1
    arc_2_0_21  original_T_including_depot_unload_1788  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_21  arc_capacity_1370  1
    load_2_0_21  free_load_conservation_1765  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_22  arc_capacity_1371  -30
    arc_2_0_22  depot_departure_or_bypass_1699  1
    arc_2_0_22  in_degree_1767  1
    arc_2_0_22  original_T_including_depot_unload_1788  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_22  arc_capacity_1371  1
    load_2_0_22  free_load_conservation_1771  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_23  arc_capacity_1372  -30
    arc_2_0_23  depot_departure_or_bypass_1699  1
    arc_2_0_23  in_degree_1773  1
    arc_2_0_23  original_T_including_depot_unload_1788  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_23  arc_capacity_1372  1
    load_2_0_23  free_load_conservation_1777  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_24  arc_capacity_1373  -30
    arc_2_0_24  depot_departure_or_bypass_1699  1
    arc_2_0_24  in_degree_1779  1
    arc_2_0_24  original_T_including_depot_unload_1788  5.4249700630778887e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_24  arc_capacity_1373  1
    load_2_0_24  free_load_conservation_1783  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_0  arc_capacity_1374  -30
    arc_2_12_0  depot_return_or_bypass_1700  1
    arc_2_12_0  out_degree_1701  1
    arc_2_12_0  original_T_including_depot_unload_1788  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_0  arc_capacity_1374  1
    load_2_12_0  segment_load_conservation_1705  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_13  arc_capacity_1375  -30
    arc_2_12_13  connected_order_arc_1376  -14
    arc_2_12_13  out_degree_1701  1
    arc_2_12_13  in_degree_1709  1
    arc_2_12_13  original_T_including_depot_unload_1788  1.2835993572680911e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_13  arc_capacity_1375  1
    load_2_12_13  segment_load_conservation_1705  1
    load_2_12_13  segment_load_conservation_1712  -1
    load_2_12_13  segment_prefix_lb_1713  1
    load_2_12_13  segment_prefix_ub_1714  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_14  arc_capacity_1377  -30
    arc_2_12_14  connected_order_arc_1378  -14
    arc_2_12_14  out_degree_1701  1
    arc_2_12_14  in_degree_1716  1
    arc_2_12_14  original_T_including_depot_unload_1788  1.0138993437494995e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_14  arc_capacity_1377  1
    load_2_12_14  segment_load_conservation_1705  1
    load_2_12_14  segment_load_conservation_1719  -1
    load_2_12_14  segment_prefix_lb_1720  1
    load_2_12_14  segment_prefix_ub_1721  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_15  arc_capacity_1379  -30
    arc_2_12_15  connected_order_arc_1380  -14
    arc_2_12_15  out_degree_1701  1
    arc_2_12_15  in_degree_1723  1
    arc_2_12_15  original_T_including_depot_unload_1788  3.8790073962518773e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_15  arc_capacity_1379  1
    load_2_12_15  segment_load_conservation_1705  1
    load_2_12_15  segment_load_conservation_1726  -1
    load_2_12_15  segment_prefix_lb_1727  1
    load_2_12_15  segment_prefix_ub_1728  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_16  arc_capacity_1381  -30
    arc_2_12_16  connected_order_arc_1382  -14
    arc_2_12_16  out_degree_1701  1
    arc_2_12_16  in_degree_1730  1
    arc_2_12_16  original_T_including_depot_unload_1788  2.4083746437975364e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_16  arc_capacity_1381  1
    load_2_12_16  segment_load_conservation_1705  1
    load_2_12_16  segment_load_conservation_1733  -1
    load_2_12_16  segment_prefix_lb_1734  1
    load_2_12_16  segment_prefix_ub_1735  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_17  arc_capacity_1383  -30
    arc_2_12_17  connected_order_arc_1384  -14
    arc_2_12_17  out_degree_1701  1
    arc_2_12_17  in_degree_1737  1
    arc_2_12_17  original_T_including_depot_unload_1788  1.2717918724165304e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_17  arc_capacity_1383  1
    load_2_12_17  segment_load_conservation_1705  1
    load_2_12_17  free_load_conservation_1741  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_18  arc_capacity_1385  -30
    arc_2_12_18  connected_order_arc_1386  -14
    arc_2_12_18  out_degree_1701  1
    arc_2_12_18  in_degree_1743  1
    arc_2_12_18  original_T_including_depot_unload_1788  1.2946770575314561e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_18  arc_capacity_1385  1
    load_2_12_18  segment_load_conservation_1705  1
    load_2_12_18  free_load_conservation_1747  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_19  arc_capacity_1387  -30
    arc_2_12_19  connected_order_arc_1388  -14
    arc_2_12_19  out_degree_1701  1
    arc_2_12_19  in_degree_1749  1
    arc_2_12_19  original_T_including_depot_unload_1788  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_19  arc_capacity_1387  1
    load_2_12_19  segment_load_conservation_1705  1
    load_2_12_19  free_load_conservation_1753  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_20  arc_capacity_1389  -30
    arc_2_12_20  connected_order_arc_1390  -14
    arc_2_12_20  out_degree_1701  1
    arc_2_12_20  in_degree_1755  1
    arc_2_12_20  original_T_including_depot_unload_1788  7.8947565022471792e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_20  arc_capacity_1389  1
    load_2_12_20  segment_load_conservation_1705  1
    load_2_12_20  free_load_conservation_1759  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_21  arc_capacity_1391  -30
    arc_2_12_21  connected_order_arc_1392  -14
    arc_2_12_21  out_degree_1701  1
    arc_2_12_21  in_degree_1761  1
    arc_2_12_21  original_T_including_depot_unload_1788  8.3486971116736720e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_21  arc_capacity_1391  1
    load_2_12_21  segment_load_conservation_1705  1
    load_2_12_21  free_load_conservation_1765  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_22  arc_capacity_1393  -30
    arc_2_12_22  connected_order_arc_1394  -14
    arc_2_12_22  out_degree_1701  1
    arc_2_12_22  in_degree_1767  1
    arc_2_12_22  original_T_including_depot_unload_1788  6.2886632383683013e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_22  arc_capacity_1393  1
    load_2_12_22  segment_load_conservation_1705  1
    load_2_12_22  free_load_conservation_1771  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_23  arc_capacity_1395  -30
    arc_2_12_23  connected_order_arc_1396  -14
    arc_2_12_23  out_degree_1701  1
    arc_2_12_23  in_degree_1773  1
    arc_2_12_23  original_T_including_depot_unload_1788  1.1544376314422677e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_23  arc_capacity_1395  1
    load_2_12_23  segment_load_conservation_1705  1
    load_2_12_23  free_load_conservation_1777  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_24  arc_capacity_1397  -30
    arc_2_12_24  connected_order_arc_1398  -14
    arc_2_12_24  out_degree_1701  1
    arc_2_12_24  in_degree_1779  1
    arc_2_12_24  original_T_including_depot_unload_1788  6.0309764600105484e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_24  arc_capacity_1397  1
    load_2_12_24  segment_load_conservation_1705  1
    load_2_12_24  free_load_conservation_1783  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_0  arc_capacity_1399  -30
    arc_2_13_0  depot_return_or_bypass_1700  1
    arc_2_13_0  out_degree_1708  1
    arc_2_13_0  original_T_including_depot_unload_1788  1.4567038050199781e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_0  arc_capacity_1399  1
    load_2_13_0  segment_load_conservation_1712  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_12  arc_capacity_1400  -30
    arc_2_13_12  connected_order_arc_1401  -14
    arc_2_13_12  in_degree_1702  1
    arc_2_13_12  out_degree_1708  1
    arc_2_13_12  original_T_including_depot_unload_1788  1.2835993572680911e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_12  arc_capacity_1400  1
    load_2_13_12  segment_load_conservation_1705  -1
    load_2_13_12  segment_prefix_lb_1706  1
    load_2_13_12  segment_prefix_ub_1707  1
    load_2_13_12  segment_load_conservation_1712  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_14  arc_capacity_1402  -30
    arc_2_13_14  connected_order_arc_1403  -14
    arc_2_13_14  out_degree_1708  1
    arc_2_13_14  in_degree_1716  1
    arc_2_13_14  original_T_including_depot_unload_1788  5.2746035265689818e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_14  arc_capacity_1402  1
    load_2_13_14  segment_load_conservation_1712  1
    load_2_13_14  segment_load_conservation_1719  -1
    load_2_13_14  segment_prefix_lb_1720  1
    load_2_13_14  segment_prefix_ub_1721  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_15  arc_capacity_1404  -30
    arc_2_13_15  connected_order_arc_1405  -14
    arc_2_13_15  out_degree_1708  1
    arc_2_13_15  in_degree_1723  1
    arc_2_13_15  original_T_including_depot_unload_1788  1.5960107821452696e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_15  arc_capacity_1404  1
    load_2_13_15  segment_load_conservation_1712  1
    load_2_13_15  segment_load_conservation_1726  -1
    load_2_13_15  segment_prefix_lb_1727  1
    load_2_13_15  segment_prefix_ub_1728  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_16  arc_capacity_1406  -30
    arc_2_13_16  connected_order_arc_1407  -14
    arc_2_13_16  out_degree_1708  1
    arc_2_13_16  in_degree_1730  1
    arc_2_13_16  original_T_including_depot_unload_1788  1.4332871320059419e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_16  arc_capacity_1406  1
    load_2_13_16  segment_load_conservation_1712  1
    load_2_13_16  segment_load_conservation_1733  -1
    load_2_13_16  segment_prefix_lb_1734  1
    load_2_13_16  segment_prefix_ub_1735  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_17  arc_capacity_1408  -30
    arc_2_13_17  connected_order_arc_1409  -14
    arc_2_13_17  out_degree_1708  1
    arc_2_13_17  in_degree_1737  1
    arc_2_13_17  original_T_including_depot_unload_1788  2362.83310343652
    MARKER    'MARKER'                 'INTEND'
    load_2_13_17  arc_capacity_1408  1
    load_2_13_17  segment_load_conservation_1712  1
    load_2_13_17  free_load_conservation_1741  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_18  arc_capacity_1410  -30
    arc_2_13_18  connected_order_arc_1411  -14
    arc_2_13_18  out_degree_1708  1
    arc_2_13_18  in_degree_1743  1
    arc_2_13_18  original_T_including_depot_unload_1788  2.1542021003680966e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_18  arc_capacity_1410  1
    load_2_13_18  segment_load_conservation_1712  1
    load_2_13_18  free_load_conservation_1747  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_19  arc_capacity_1412  -30
    arc_2_13_19  connected_order_arc_1413  -14
    arc_2_13_19  out_degree_1708  1
    arc_2_13_19  in_degree_1749  1
    arc_2_13_19  original_T_including_depot_unload_1788  1.2027697073878232e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_19  arc_capacity_1412  1
    load_2_13_19  segment_load_conservation_1712  1
    load_2_13_19  free_load_conservation_1753  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_20  arc_capacity_1414  -30
    arc_2_13_20  connected_order_arc_1415  -14
    arc_2_13_20  out_degree_1708  1
    arc_2_13_20  in_degree_1755  1
    arc_2_13_20  original_T_including_depot_unload_1788  1.7571531345240103e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_20  arc_capacity_1414  1
    load_2_13_20  segment_load_conservation_1712  1
    load_2_13_20  free_load_conservation_1759  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_21  arc_capacity_1416  -30
    arc_2_13_21  connected_order_arc_1417  -14
    arc_2_13_21  out_degree_1708  1
    arc_2_13_21  in_degree_1761  1
    arc_2_13_21  original_T_including_depot_unload_1788  2.0178882184947397e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_21  arc_capacity_1416  1
    load_2_13_21  segment_load_conservation_1712  1
    load_2_13_21  free_load_conservation_1765  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_22  arc_capacity_1418  -30
    arc_2_13_22  connected_order_arc_1419  -14
    arc_2_13_22  out_degree_1708  1
    arc_2_13_22  in_degree_1767  1
    arc_2_13_22  original_T_including_depot_unload_1788  1.7998334548300843e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_22  arc_capacity_1418  1
    load_2_13_22  segment_load_conservation_1712  1
    load_2_13_22  free_load_conservation_1771  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_23  arc_capacity_1420  -30
    arc_2_13_23  connected_order_arc_1421  -14
    arc_2_13_23  out_degree_1708  1
    arc_2_13_23  in_degree_1773  1
    arc_2_13_23  original_T_including_depot_unload_1788  3.1118349756671438e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_23  arc_capacity_1420  1
    load_2_13_23  segment_load_conservation_1712  1
    load_2_13_23  free_load_conservation_1777  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_24  arc_capacity_1422  -30
    arc_2_13_24  connected_order_arc_1423  -14
    arc_2_13_24  out_degree_1708  1
    arc_2_13_24  in_degree_1779  1
    arc_2_13_24  original_T_including_depot_unload_1788  1.8805180645589260e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_24  arc_capacity_1422  1
    load_2_13_24  segment_load_conservation_1712  1
    load_2_13_24  free_load_conservation_1783  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_0  arc_capacity_1424  -30
    arc_2_14_0  depot_return_or_bypass_1700  1
    arc_2_14_0  out_degree_1715  1
    arc_2_14_0  original_T_including_depot_unload_1788  1.2506062209426416e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_0  arc_capacity_1424  1
    load_2_14_0  segment_load_conservation_1719  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_12  arc_capacity_1425  -30
    arc_2_14_12  connected_order_arc_1426  -14
    arc_2_14_12  in_degree_1702  1
    arc_2_14_12  out_degree_1715  1
    arc_2_14_12  original_T_including_depot_unload_1788  1.0138993437494995e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_12  arc_capacity_1425  1
    load_2_14_12  segment_load_conservation_1705  -1
    load_2_14_12  segment_prefix_lb_1706  1
    load_2_14_12  segment_prefix_ub_1707  1
    load_2_14_12  segment_load_conservation_1719  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_13  arc_capacity_1427  -30
    arc_2_14_13  connected_order_arc_1428  -14
    arc_2_14_13  in_degree_1709  1
    arc_2_14_13  out_degree_1715  1
    arc_2_14_13  original_T_including_depot_unload_1788  5.2746035265689818e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_13  arc_capacity_1427  1
    load_2_14_13  segment_load_conservation_1712  -1
    load_2_14_13  segment_prefix_lb_1713  1
    load_2_14_13  segment_prefix_ub_1714  1
    load_2_14_13  segment_load_conservation_1719  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_15  arc_capacity_1429  -30
    arc_2_14_15  connected_order_arc_1430  -14
    arc_2_14_15  out_degree_1715  1
    arc_2_14_15  in_degree_1723  1
    arc_2_14_15  original_T_including_depot_unload_1788  1.2335670980381785e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_15  arc_capacity_1429  1
    load_2_14_15  segment_load_conservation_1719  1
    load_2_14_15  segment_load_conservation_1726  -1
    load_2_14_15  segment_prefix_lb_1727  1
    load_2_14_15  segment_prefix_ub_1728  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_16  arc_capacity_1431  -30
    arc_2_14_16  connected_order_arc_1432  -14
    arc_2_14_16  out_degree_1715  1
    arc_2_14_16  in_degree_1730  1
    arc_2_14_16  original_T_including_depot_unload_1788  1.0874822831610163e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_16  arc_capacity_1431  1
    load_2_14_16  segment_load_conservation_1719  1
    load_2_14_16  segment_load_conservation_1733  -1
    load_2_14_16  segment_prefix_lb_1734  1
    load_2_14_16  segment_prefix_ub_1735  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_17  arc_capacity_1433  -30
    arc_2_14_17  connected_order_arc_1434  -14
    arc_2_14_17  out_degree_1715  1
    arc_2_14_17  in_degree_1737  1
    arc_2_14_17  original_T_including_depot_unload_1788  1.9038107656775676e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_17  arc_capacity_1433  1
    load_2_14_17  segment_load_conservation_1719  1
    load_2_14_17  free_load_conservation_1741  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_18  arc_capacity_1435  -30
    arc_2_14_18  connected_order_arc_1436  -14
    arc_2_14_18  out_degree_1715  1
    arc_2_14_18  in_degree_1743  1
    arc_2_14_18  original_T_including_depot_unload_1788  1.6502895430075375e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_18  arc_capacity_1435  1
    load_2_14_18  segment_load_conservation_1719  1
    load_2_14_18  free_load_conservation_1747  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_19  arc_capacity_1437  -30
    arc_2_14_19  connected_order_arc_1438  -14
    arc_2_14_19  out_degree_1715  1
    arc_2_14_19  in_degree_1749  1
    arc_2_14_19  original_T_including_depot_unload_1788  1.4255422670497167e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_19  arc_capacity_1437  1
    load_2_14_19  segment_load_conservation_1719  1
    load_2_14_19  free_load_conservation_1753  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_20  arc_capacity_1439  -30
    arc_2_14_20  connected_order_arc_1440  -14
    arc_2_14_20  out_degree_1715  1
    arc_2_14_20  in_degree_1755  1
    arc_2_14_20  original_T_including_depot_unload_1788  1.2941622036935485e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_20  arc_capacity_1439  1
    load_2_14_20  segment_load_conservation_1719  1
    load_2_14_20  free_load_conservation_1759  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_21  arc_capacity_1441  -30
    arc_2_14_21  connected_order_arc_1442  -14
    arc_2_14_21  out_degree_1715  1
    arc_2_14_21  in_degree_1761  1
    arc_2_14_21  original_T_including_depot_unload_1788  1.8362893893653638e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_21  arc_capacity_1441  1
    load_2_14_21  segment_load_conservation_1719  1
    load_2_14_21  free_load_conservation_1765  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_22  arc_capacity_1443  -30
    arc_2_14_22  connected_order_arc_1444  -14
    arc_2_14_22  out_degree_1715  1
    arc_2_14_22  in_degree_1767  1
    arc_2_14_22  original_T_including_depot_unload_1788  1.4001236472738528e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_22  arc_capacity_1443  1
    load_2_14_22  segment_load_conservation_1719  1
    load_2_14_22  free_load_conservation_1771  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_23  arc_capacity_1445  -30
    arc_2_14_23  connected_order_arc_1446  -14
    arc_2_14_23  out_degree_1715  1
    arc_2_14_23  in_degree_1773  1
    arc_2_14_23  original_T_including_depot_unload_1788  2.2865444230199981e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_23  arc_capacity_1445  1
    load_2_14_23  segment_load_conservation_1719  1
    load_2_14_23  free_load_conservation_1777  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_24  arc_capacity_1447  -30
    arc_2_14_24  connected_order_arc_1448  -14
    arc_2_14_24  out_degree_1715  1
    arc_2_14_24  in_degree_1779  1
    arc_2_14_24  original_T_including_depot_unload_1788  1.5552905028977075e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_24  arc_capacity_1447  1
    load_2_14_24  segment_load_conservation_1719  1
    load_2_14_24  free_load_conservation_1783  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_0  arc_capacity_1449  -30
    arc_2_15_0  depot_return_or_bypass_1700  1
    arc_2_15_0  out_degree_1722  1
    arc_2_15_0  original_T_including_depot_unload_1788  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_0  arc_capacity_1449  1
    load_2_15_0  segment_load_conservation_1726  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_12  arc_capacity_1450  -30
    arc_2_15_12  connected_order_arc_1451  -14
    arc_2_15_12  in_degree_1702  1
    arc_2_15_12  out_degree_1722  1
    arc_2_15_12  original_T_including_depot_unload_1788  3.8790073962518773e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_12  arc_capacity_1450  1
    load_2_15_12  segment_load_conservation_1705  -1
    load_2_15_12  segment_prefix_lb_1706  1
    load_2_15_12  segment_prefix_ub_1707  1
    load_2_15_12  segment_load_conservation_1726  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_13  arc_capacity_1452  -30
    arc_2_15_13  connected_order_arc_1453  -14
    arc_2_15_13  in_degree_1709  1
    arc_2_15_13  out_degree_1722  1
    arc_2_15_13  original_T_including_depot_unload_1788  1.5960107821452696e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_13  arc_capacity_1452  1
    load_2_15_13  segment_load_conservation_1712  -1
    load_2_15_13  segment_prefix_lb_1713  1
    load_2_15_13  segment_prefix_ub_1714  1
    load_2_15_13  segment_load_conservation_1726  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_14  arc_capacity_1454  -30
    arc_2_15_14  connected_order_arc_1455  -14
    arc_2_15_14  in_degree_1716  1
    arc_2_15_14  out_degree_1722  1
    arc_2_15_14  original_T_including_depot_unload_1788  1.2335670980381785e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_14  arc_capacity_1454  1
    load_2_15_14  segment_load_conservation_1719  -1
    load_2_15_14  segment_prefix_lb_1720  1
    load_2_15_14  segment_prefix_ub_1721  1
    load_2_15_14  segment_load_conservation_1726  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_16  arc_capacity_1456  -30
    arc_2_15_16  connected_order_arc_1457  -14
    arc_2_15_16  out_degree_1722  1
    arc_2_15_16  in_degree_1730  1
    arc_2_15_16  original_T_including_depot_unload_1788  1.6597164064313077e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_16  arc_capacity_1456  1
    load_2_15_16  segment_load_conservation_1726  1
    load_2_15_16  segment_load_conservation_1733  -1
    load_2_15_16  segment_prefix_lb_1734  1
    load_2_15_16  segment_prefix_ub_1735  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_17  arc_capacity_1458  -30
    arc_2_15_17  connected_order_arc_1459  -14
    arc_2_15_17  out_degree_1722  1
    arc_2_15_17  in_degree_1737  1
    arc_2_15_17  original_T_including_depot_unload_1788  8.8496780902404032e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_17  arc_capacity_1458  1
    load_2_15_17  segment_load_conservation_1726  1
    load_2_15_17  free_load_conservation_1741  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_18  arc_capacity_1460  -30
    arc_2_15_18  connected_order_arc_1461  -14
    arc_2_15_18  out_degree_1722  1
    arc_2_15_18  in_degree_1743  1
    arc_2_15_18  original_T_including_depot_unload_1788  9.5901863634429412e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_18  arc_capacity_1460  1
    load_2_15_18  segment_load_conservation_1726  1
    load_2_15_18  free_load_conservation_1747  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_19  arc_capacity_1462  -30
    arc_2_15_19  connected_order_arc_1463  -14
    arc_2_15_19  out_degree_1722  1
    arc_2_15_19  in_degree_1749  1
    arc_2_15_19  original_T_including_depot_unload_1788  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_19  arc_capacity_1462  1
    load_2_15_19  segment_load_conservation_1726  1
    load_2_15_19  free_load_conservation_1753  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_20  arc_capacity_1464  -30
    arc_2_15_20  connected_order_arc_1465  -14
    arc_2_15_20  out_degree_1722  1
    arc_2_15_20  in_degree_1755  1
    arc_2_15_20  original_T_including_depot_unload_1788  4.6772747357218117e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_20  arc_capacity_1464  1
    load_2_15_20  segment_load_conservation_1726  1
    load_2_15_20  free_load_conservation_1759  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_21  arc_capacity_1466  -30
    arc_2_15_21  connected_order_arc_1467  -14
    arc_2_15_21  out_degree_1722  1
    arc_2_15_21  in_degree_1761  1
    arc_2_15_21  original_T_including_depot_unload_1788  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_21  arc_capacity_1466  1
    load_2_15_21  segment_load_conservation_1726  1
    load_2_15_21  free_load_conservation_1765  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_22  arc_capacity_1468  -30
    arc_2_15_22  connected_order_arc_1469  -14
    arc_2_15_22  out_degree_1722  1
    arc_2_15_22  in_degree_1767  1
    arc_2_15_22  original_T_including_depot_unload_1788  2.4111148152767828e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_22  arc_capacity_1468  1
    load_2_15_22  segment_load_conservation_1726  1
    load_2_15_22  free_load_conservation_1771  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_23  arc_capacity_1470  -30
    arc_2_15_23  connected_order_arc_1471  -14
    arc_2_15_23  out_degree_1722  1
    arc_2_15_23  in_degree_1773  1
    arc_2_15_23  original_T_including_depot_unload_1788  1.4150780419437449e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_23  arc_capacity_1470  1
    load_2_15_23  segment_load_conservation_1726  1
    load_2_15_23  free_load_conservation_1777  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_24  arc_capacity_1472  -30
    arc_2_15_24  connected_order_arc_1473  -14
    arc_2_15_24  out_degree_1722  1
    arc_2_15_24  in_degree_1779  1
    arc_2_15_24  original_T_including_depot_unload_1788  3.3800157717255917e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_24  arc_capacity_1472  1
    load_2_15_24  segment_load_conservation_1726  1
    load_2_15_24  free_load_conservation_1783  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_0  arc_capacity_1474  -30
    arc_2_16_0  depot_return_or_bypass_1700  1
    arc_2_16_0  out_degree_1729  1
    arc_2_16_0  original_T_including_depot_unload_1788  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_0  arc_capacity_1474  1
    load_2_16_0  segment_load_conservation_1733  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_12  arc_capacity_1475  -30
    arc_2_16_12  connected_order_arc_1476  -14
    arc_2_16_12  in_degree_1702  1
    arc_2_16_12  out_degree_1729  1
    arc_2_16_12  original_T_including_depot_unload_1788  2.4083746437975364e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_12  arc_capacity_1475  1
    load_2_16_12  segment_load_conservation_1705  -1
    load_2_16_12  segment_prefix_lb_1706  1
    load_2_16_12  segment_prefix_ub_1707  1
    load_2_16_12  segment_load_conservation_1733  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_13  arc_capacity_1477  -30
    arc_2_16_13  connected_order_arc_1478  -14
    arc_2_16_13  in_degree_1709  1
    arc_2_16_13  out_degree_1729  1
    arc_2_16_13  original_T_including_depot_unload_1788  1.4332871320059419e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_13  arc_capacity_1477  1
    load_2_16_13  segment_load_conservation_1712  -1
    load_2_16_13  segment_prefix_lb_1713  1
    load_2_16_13  segment_prefix_ub_1714  1
    load_2_16_13  segment_load_conservation_1733  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_14  arc_capacity_1479  -30
    arc_2_16_14  connected_order_arc_1480  -14
    arc_2_16_14  in_degree_1716  1
    arc_2_16_14  out_degree_1729  1
    arc_2_16_14  original_T_including_depot_unload_1788  1.0874822831610163e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_14  arc_capacity_1479  1
    load_2_16_14  segment_load_conservation_1719  -1
    load_2_16_14  segment_prefix_lb_1720  1
    load_2_16_14  segment_prefix_ub_1721  1
    load_2_16_14  segment_load_conservation_1733  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_15  arc_capacity_1481  -30
    arc_2_16_15  connected_order_arc_1482  -14
    arc_2_16_15  in_degree_1723  1
    arc_2_16_15  out_degree_1729  1
    arc_2_16_15  original_T_including_depot_unload_1788  1.6597164064313077e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_15  arc_capacity_1481  1
    load_2_16_15  segment_load_conservation_1726  -1
    load_2_16_15  segment_prefix_lb_1727  1
    load_2_16_15  segment_prefix_ub_1728  1
    load_2_16_15  segment_load_conservation_1733  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_17  arc_capacity_1483  -30
    arc_2_16_17  connected_order_arc_1484  -14
    arc_2_16_17  out_degree_1729  1
    arc_2_16_17  in_degree_1737  1
    arc_2_16_17  original_T_including_depot_unload_1788  1.0363003610648061e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_17  arc_capacity_1483  1
    load_2_16_17  segment_load_conservation_1733  1
    load_2_16_17  free_load_conservation_1741  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_18  arc_capacity_1485  -30
    arc_2_16_18  connected_order_arc_1486  -14
    arc_2_16_18  out_degree_1729  1
    arc_2_16_18  in_degree_1743  1
    arc_2_16_18  original_T_including_depot_unload_1788  1.0592524244968324e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_18  arc_capacity_1485  1
    load_2_16_18  segment_load_conservation_1733  1
    load_2_16_18  free_load_conservation_1747  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_19  arc_capacity_1487  -30
    arc_2_16_19  connected_order_arc_1488  -14
    arc_2_16_19  out_degree_1729  1
    arc_2_16_19  in_degree_1749  1
    arc_2_16_19  original_T_including_depot_unload_1788  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_19  arc_capacity_1487  1
    load_2_16_19  segment_load_conservation_1733  1
    load_2_16_19  free_load_conservation_1753  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_20  arc_capacity_1489  -30
    arc_2_16_20  connected_order_arc_1490  -14
    arc_2_16_20  out_degree_1729  1
    arc_2_16_20  in_degree_1755  1
    arc_2_16_20  original_T_including_depot_unload_1788  5.5448403235604167e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_20  arc_capacity_1489  1
    load_2_16_20  segment_load_conservation_1733  1
    load_2_16_20  free_load_conservation_1759  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_21  arc_capacity_1491  -30
    arc_2_16_21  connected_order_arc_1492  -14
    arc_2_16_21  out_degree_1729  1
    arc_2_16_21  in_degree_1761  1
    arc_2_16_21  original_T_including_depot_unload_1788  8.7684829846426385e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_21  arc_capacity_1491  1
    load_2_16_21  segment_load_conservation_1733  1
    load_2_16_21  free_load_conservation_1765  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_22  arc_capacity_1493  -30
    arc_2_16_22  connected_order_arc_1494  -14
    arc_2_16_22  out_degree_1729  1
    arc_2_16_22  in_degree_1767  1
    arc_2_16_22  original_T_including_depot_unload_1788  3.9864800790786632e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_22  arc_capacity_1493  1
    load_2_16_22  segment_load_conservation_1733  1
    load_2_16_22  free_load_conservation_1771  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_23  arc_capacity_1495  -30
    arc_2_16_23  connected_order_arc_1496  -14
    arc_2_16_23  out_degree_1729  1
    arc_2_16_23  in_degree_1773  1
    arc_2_16_23  original_T_including_depot_unload_1788  1.2608612406747543e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_23  arc_capacity_1495  1
    load_2_16_23  segment_load_conservation_1733  1
    load_2_16_23  free_load_conservation_1777  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_24  arc_capacity_1497  -30
    arc_2_16_24  connected_order_arc_1498  -14
    arc_2_16_24  out_degree_1729  1
    arc_2_16_24  in_degree_1779  1
    arc_2_16_24  original_T_including_depot_unload_1788  4.6789193623835109e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_24  arc_capacity_1497  1
    load_2_16_24  segment_load_conservation_1733  1
    load_2_16_24  free_load_conservation_1783  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_0  arc_capacity_1499  -30
    arc_2_17_0  depot_return_or_bypass_1700  1
    arc_2_17_0  out_degree_1736  1
    arc_2_17_0  original_T_including_depot_unload_1788  1.3396590612935172e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_0  arc_capacity_1499  1
    load_2_17_0  free_load_conservation_1741  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_12  arc_capacity_1500  -30
    arc_2_17_12  connected_order_arc_1501  -14
    arc_2_17_12  in_degree_1702  1
    arc_2_17_12  out_degree_1736  1
    arc_2_17_12  original_T_including_depot_unload_1788  1.2717918724165304e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_12  arc_capacity_1500  1
    load_2_17_12  segment_load_conservation_1705  -1
    load_2_17_12  segment_prefix_lb_1706  1
    load_2_17_12  segment_prefix_ub_1707  1
    load_2_17_12  free_load_conservation_1741  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_13  arc_capacity_1502  -30
    arc_2_17_13  connected_order_arc_1503  -14
    arc_2_17_13  in_degree_1709  1
    arc_2_17_13  out_degree_1736  1
    arc_2_17_13  original_T_including_depot_unload_1788  2362.83310343652
    MARKER    'MARKER'                 'INTEND'
    load_2_17_13  arc_capacity_1502  1
    load_2_17_13  segment_load_conservation_1712  -1
    load_2_17_13  segment_prefix_lb_1713  1
    load_2_17_13  segment_prefix_ub_1714  1
    load_2_17_13  free_load_conservation_1741  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_14  arc_capacity_1504  -30
    arc_2_17_14  connected_order_arc_1505  -14
    arc_2_17_14  in_degree_1716  1
    arc_2_17_14  out_degree_1736  1
    arc_2_17_14  original_T_including_depot_unload_1788  1.9038107656775676e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_14  arc_capacity_1504  1
    load_2_17_14  segment_load_conservation_1719  -1
    load_2_17_14  segment_prefix_lb_1720  1
    load_2_17_14  segment_prefix_ub_1721  1
    load_2_17_14  free_load_conservation_1741  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_15  arc_capacity_1506  -30
    arc_2_17_15  connected_order_arc_1507  -14
    arc_2_17_15  in_degree_1723  1
    arc_2_17_15  out_degree_1736  1
    arc_2_17_15  original_T_including_depot_unload_1788  8.8496780902404032e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_15  arc_capacity_1506  1
    load_2_17_15  segment_load_conservation_1726  -1
    load_2_17_15  segment_prefix_lb_1727  1
    load_2_17_15  segment_prefix_ub_1728  1
    load_2_17_15  free_load_conservation_1741  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_16  arc_capacity_1508  -30
    arc_2_17_16  connected_order_arc_1509  -14
    arc_2_17_16  in_degree_1730  1
    arc_2_17_16  out_degree_1736  1
    arc_2_17_16  original_T_including_depot_unload_1788  1.0363003610648061e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_16  arc_capacity_1508  1
    load_2_17_16  segment_load_conservation_1733  -1
    load_2_17_16  segment_prefix_lb_1734  1
    load_2_17_16  segment_prefix_ub_1735  1
    load_2_17_16  free_load_conservation_1741  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_18  arc_capacity_1510  -30
    arc_2_17_18  connected_order_arc_1511  -14
    arc_2_17_18  out_degree_1736  1
    arc_2_17_18  in_degree_1743  1
    arc_2_17_18  original_T_including_depot_unload_1788  4.8781034218421996e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_18  arc_capacity_1510  1
    load_2_17_18  free_load_conservation_1741  1
    load_2_17_18  free_load_conservation_1747  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_19  arc_capacity_1512  -30
    arc_2_17_19  connected_order_arc_1513  -14
    arc_2_17_19  out_degree_1736  1
    arc_2_17_19  in_degree_1749  1
    arc_2_17_19  original_T_including_depot_unload_1788  2.4147485851762935e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_19  arc_capacity_1512  1
    load_2_17_19  free_load_conservation_1741  1
    load_2_17_19  free_load_conservation_1753  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_20  arc_capacity_1514  -30
    arc_2_17_20  connected_order_arc_1515  -14
    arc_2_17_20  out_degree_1736  1
    arc_2_17_20  in_degree_1755  1
    arc_2_17_20  original_T_including_depot_unload_1788  6.0985881995898160e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_20  arc_capacity_1514  1
    load_2_17_20  free_load_conservation_1741  1
    load_2_17_20  free_load_conservation_1759  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_21  arc_capacity_1516  -30
    arc_2_17_21  connected_order_arc_1517  -14
    arc_2_17_21  out_degree_1736  1
    arc_2_17_21  in_degree_1761  1
    arc_2_17_21  original_T_including_depot_unload_1788  1.4088953223409719e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_21  arc_capacity_1516  1
    load_2_17_21  free_load_conservation_1741  1
    load_2_17_21  free_load_conservation_1765  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_22  arc_capacity_1518  -30
    arc_2_17_22  connected_order_arc_1519  -14
    arc_2_17_22  out_degree_1736  1
    arc_2_17_22  in_degree_1767  1
    arc_2_17_22  original_T_including_depot_unload_1788  6.4419272207888969e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_22  arc_capacity_1518  1
    load_2_17_22  free_load_conservation_1741  1
    load_2_17_22  free_load_conservation_1771  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_23  arc_capacity_1520  -30
    arc_2_17_23  connected_order_arc_1521  -14
    arc_2_17_23  out_degree_1736  1
    arc_2_17_23  in_degree_1773  1
    arc_2_17_23  original_T_including_depot_unload_1788  2.1214998192647863e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_23  arc_capacity_1520  1
    load_2_17_23  free_load_conservation_1741  1
    load_2_17_23  free_load_conservation_1777  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_24  arc_capacity_1522  -30
    arc_2_17_24  connected_order_arc_1523  -14
    arc_2_17_24  out_degree_1736  1
    arc_2_17_24  in_degree_1779  1
    arc_2_17_24  original_T_including_depot_unload_1788  8.4962277657921186e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_24  arc_capacity_1522  1
    load_2_17_24  free_load_conservation_1741  1
    load_2_17_24  free_load_conservation_1783  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_0  arc_capacity_1524  -30
    arc_2_18_0  depot_return_or_bypass_1700  1
    arc_2_18_0  out_degree_1742  1
    arc_2_18_0  original_T_including_depot_unload_1788  1.4501558573355060e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_0  arc_capacity_1524  1
    load_2_18_0  free_load_conservation_1747  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_12  arc_capacity_1525  -30
    arc_2_18_12  connected_order_arc_1526  -14
    arc_2_18_12  in_degree_1702  1
    arc_2_18_12  out_degree_1742  1
    arc_2_18_12  original_T_including_depot_unload_1788  1.2946770575314561e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_12  arc_capacity_1525  1
    load_2_18_12  segment_load_conservation_1705  -1
    load_2_18_12  segment_prefix_lb_1706  1
    load_2_18_12  segment_prefix_ub_1707  1
    load_2_18_12  free_load_conservation_1747  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_13  arc_capacity_1527  -30
    arc_2_18_13  connected_order_arc_1528  -14
    arc_2_18_13  in_degree_1709  1
    arc_2_18_13  out_degree_1742  1
    arc_2_18_13  original_T_including_depot_unload_1788  2.1542021003680966e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_13  arc_capacity_1527  1
    load_2_18_13  segment_load_conservation_1712  -1
    load_2_18_13  segment_prefix_lb_1713  1
    load_2_18_13  segment_prefix_ub_1714  1
    load_2_18_13  free_load_conservation_1747  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_14  arc_capacity_1529  -30
    arc_2_18_14  connected_order_arc_1530  -14
    arc_2_18_14  in_degree_1716  1
    arc_2_18_14  out_degree_1742  1
    arc_2_18_14  original_T_including_depot_unload_1788  1.6502895430075375e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_14  arc_capacity_1529  1
    load_2_18_14  segment_load_conservation_1719  -1
    load_2_18_14  segment_prefix_lb_1720  1
    load_2_18_14  segment_prefix_ub_1721  1
    load_2_18_14  free_load_conservation_1747  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_15  arc_capacity_1531  -30
    arc_2_18_15  connected_order_arc_1532  -14
    arc_2_18_15  in_degree_1723  1
    arc_2_18_15  out_degree_1742  1
    arc_2_18_15  original_T_including_depot_unload_1788  9.5901863634429412e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_15  arc_capacity_1531  1
    load_2_18_15  segment_load_conservation_1726  -1
    load_2_18_15  segment_prefix_lb_1727  1
    load_2_18_15  segment_prefix_ub_1728  1
    load_2_18_15  free_load_conservation_1747  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_16  arc_capacity_1533  -30
    arc_2_18_16  connected_order_arc_1534  -14
    arc_2_18_16  in_degree_1730  1
    arc_2_18_16  out_degree_1742  1
    arc_2_18_16  original_T_including_depot_unload_1788  1.0592524244968324e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_16  arc_capacity_1533  1
    load_2_18_16  segment_load_conservation_1733  -1
    load_2_18_16  segment_prefix_lb_1734  1
    load_2_18_16  segment_prefix_ub_1735  1
    load_2_18_16  free_load_conservation_1747  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_17  arc_capacity_1535  -30
    arc_2_18_17  connected_order_arc_1536  -14
    arc_2_18_17  in_degree_1737  1
    arc_2_18_17  out_degree_1742  1
    arc_2_18_17  original_T_including_depot_unload_1788  4.8781034218421996e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_17  arc_capacity_1535  1
    load_2_18_17  free_load_conservation_1741  -1
    load_2_18_17  free_load_conservation_1747  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_19  arc_capacity_1537  -30
    arc_2_18_19  connected_order_arc_1538  -14
    arc_2_18_19  out_degree_1742  1
    arc_2_18_19  in_degree_1749  1
    arc_2_18_19  original_T_including_depot_unload_1788  2.4496137598598170e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_19  arc_capacity_1537  1
    load_2_18_19  free_load_conservation_1747  1
    load_2_18_19  free_load_conservation_1753  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_20  arc_capacity_1539  -30
    arc_2_18_20  connected_order_arc_1540  -14
    arc_2_18_20  out_degree_1742  1
    arc_2_18_20  in_degree_1755  1
    arc_2_18_20  original_T_including_depot_unload_1788  5.0525672969651123e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_20  arc_capacity_1539  1
    load_2_18_20  free_load_conservation_1747  1
    load_2_18_20  free_load_conservation_1759  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_21  arc_capacity_1541  -30
    arc_2_18_21  connected_order_arc_1542  -14
    arc_2_18_21  out_degree_1742  1
    arc_2_18_21  in_degree_1761  1
    arc_2_18_21  original_T_including_depot_unload_1788  1.6906177970488723e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_21  arc_capacity_1541  1
    load_2_18_21  free_load_conservation_1747  1
    load_2_18_21  free_load_conservation_1765  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_22  arc_capacity_1543  -30
    arc_2_18_22  connected_order_arc_1544  -14
    arc_2_18_22  out_degree_1742  1
    arc_2_18_22  in_degree_1767  1
    arc_2_18_22  original_T_including_depot_unload_1788  7.6789230776331749e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_22  arc_capacity_1543  1
    load_2_18_22  free_load_conservation_1747  1
    load_2_18_22  free_load_conservation_1771  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_23  arc_capacity_1545  -30
    arc_2_18_23  connected_order_arc_1546  -14
    arc_2_18_23  out_degree_1742  1
    arc_2_18_23  in_degree_1773  1
    arc_2_18_23  original_T_including_depot_unload_1788  1.8780729343410642e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_23  arc_capacity_1545  1
    load_2_18_23  free_load_conservation_1747  1
    load_2_18_23  free_load_conservation_1777  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_24  arc_capacity_1547  -30
    arc_2_18_24  connected_order_arc_1548  -14
    arc_2_18_24  out_degree_1742  1
    arc_2_18_24  in_degree_1779  1
    arc_2_18_24  original_T_including_depot_unload_1788  1.0875821153726588e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_24  arc_capacity_1547  1
    load_2_18_24  free_load_conservation_1747  1
    load_2_18_24  free_load_conservation_1783  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_0  arc_capacity_1549  -30
    arc_2_19_0  depot_return_or_bypass_1700  1
    arc_2_19_0  out_degree_1748  1
    arc_2_19_0  original_T_including_depot_unload_1788  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_0  arc_capacity_1549  1
    load_2_19_0  free_load_conservation_1753  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_12  arc_capacity_1550  -30
    arc_2_19_12  connected_order_arc_1551  -14
    arc_2_19_12  in_degree_1702  1
    arc_2_19_12  out_degree_1748  1
    arc_2_19_12  original_T_including_depot_unload_1788  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_12  arc_capacity_1550  1
    load_2_19_12  segment_load_conservation_1705  -1
    load_2_19_12  segment_prefix_lb_1706  1
    load_2_19_12  segment_prefix_ub_1707  1
    load_2_19_12  free_load_conservation_1753  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_13  arc_capacity_1552  -30
    arc_2_19_13  connected_order_arc_1553  -14
    arc_2_19_13  in_degree_1709  1
    arc_2_19_13  out_degree_1748  1
    arc_2_19_13  original_T_including_depot_unload_1788  1.2027697073878232e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_13  arc_capacity_1552  1
    load_2_19_13  segment_load_conservation_1712  -1
    load_2_19_13  segment_prefix_lb_1713  1
    load_2_19_13  segment_prefix_ub_1714  1
    load_2_19_13  free_load_conservation_1753  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_14  arc_capacity_1554  -30
    arc_2_19_14  connected_order_arc_1555  -14
    arc_2_19_14  in_degree_1716  1
    arc_2_19_14  out_degree_1748  1
    arc_2_19_14  original_T_including_depot_unload_1788  1.4255422670497167e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_14  arc_capacity_1554  1
    load_2_19_14  segment_load_conservation_1719  -1
    load_2_19_14  segment_prefix_lb_1720  1
    load_2_19_14  segment_prefix_ub_1721  1
    load_2_19_14  free_load_conservation_1753  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_15  arc_capacity_1556  -30
    arc_2_19_15  connected_order_arc_1557  -14
    arc_2_19_15  in_degree_1723  1
    arc_2_19_15  out_degree_1748  1
    arc_2_19_15  original_T_including_depot_unload_1788  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_15  arc_capacity_1556  1
    load_2_19_15  segment_load_conservation_1726  -1
    load_2_19_15  segment_prefix_lb_1727  1
    load_2_19_15  segment_prefix_ub_1728  1
    load_2_19_15  free_load_conservation_1753  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_16  arc_capacity_1558  -30
    arc_2_19_16  connected_order_arc_1559  -14
    arc_2_19_16  in_degree_1730  1
    arc_2_19_16  out_degree_1748  1
    arc_2_19_16  original_T_including_depot_unload_1788  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_16  arc_capacity_1558  1
    load_2_19_16  segment_load_conservation_1733  -1
    load_2_19_16  segment_prefix_lb_1734  1
    load_2_19_16  segment_prefix_ub_1735  1
    load_2_19_16  free_load_conservation_1753  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_17  arc_capacity_1560  -30
    arc_2_19_17  connected_order_arc_1561  -14
    arc_2_19_17  in_degree_1737  1
    arc_2_19_17  out_degree_1748  1
    arc_2_19_17  original_T_including_depot_unload_1788  2.4147485851762935e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_17  arc_capacity_1560  1
    load_2_19_17  free_load_conservation_1741  -1
    load_2_19_17  free_load_conservation_1753  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_18  arc_capacity_1562  -30
    arc_2_19_18  connected_order_arc_1563  -14
    arc_2_19_18  in_degree_1743  1
    arc_2_19_18  out_degree_1748  1
    arc_2_19_18  original_T_including_depot_unload_1788  2.4496137598598170e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_18  arc_capacity_1562  1
    load_2_19_18  free_load_conservation_1747  -1
    load_2_19_18  free_load_conservation_1753  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_20  arc_capacity_1564  -30
    arc_2_19_20  connected_order_arc_1565  -14
    arc_2_19_20  out_degree_1748  1
    arc_2_19_20  in_degree_1755  1
    arc_2_19_20  original_T_including_depot_unload_1788  1.9462564869425171e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_20  arc_capacity_1564  1
    load_2_19_20  free_load_conservation_1753  1
    load_2_19_20  free_load_conservation_1759  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_21  arc_capacity_1566  -30
    arc_2_19_21  connected_order_arc_1567  -14
    arc_2_19_21  out_degree_1748  1
    arc_2_19_21  in_degree_1761  1
    arc_2_19_21  original_T_including_depot_unload_1788  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_21  arc_capacity_1566  1
    load_2_19_21  free_load_conservation_1753  1
    load_2_19_21  free_load_conservation_1765  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_22  arc_capacity_1568  -30
    arc_2_19_22  connected_order_arc_1569  -14
    arc_2_19_22  out_degree_1748  1
    arc_2_19_22  in_degree_1767  1
    arc_2_19_22  original_T_including_depot_unload_1788  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_22  arc_capacity_1568  1
    load_2_19_22  free_load_conservation_1753  1
    load_2_19_22  free_load_conservation_1771  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_23  arc_capacity_1570  -30
    arc_2_19_23  connected_order_arc_1571  -14
    arc_2_19_23  out_degree_1748  1
    arc_2_19_23  in_degree_1773  1
    arc_2_19_23  original_T_including_depot_unload_1788  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_23  arc_capacity_1570  1
    load_2_19_23  free_load_conservation_1753  1
    load_2_19_23  free_load_conservation_1777  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_24  arc_capacity_1572  -30
    arc_2_19_24  connected_order_arc_1573  -14
    arc_2_19_24  out_degree_1748  1
    arc_2_19_24  in_degree_1779  1
    arc_2_19_24  original_T_including_depot_unload_1788  1.6231508478292610e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_24  arc_capacity_1572  1
    load_2_19_24  free_load_conservation_1753  1
    load_2_19_24  free_load_conservation_1783  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_0  arc_capacity_1574  -30
    arc_2_20_0  depot_return_or_bypass_1700  1
    arc_2_20_0  out_degree_1754  1
    arc_2_20_0  original_T_including_depot_unload_1788  9.5330620720858735e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_0  arc_capacity_1574  1
    load_2_20_0  free_load_conservation_1759  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_12  arc_capacity_1575  -30
    arc_2_20_12  connected_order_arc_1576  -14
    arc_2_20_12  in_degree_1702  1
    arc_2_20_12  out_degree_1754  1
    arc_2_20_12  original_T_including_depot_unload_1788  7.8947565022471792e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_12  arc_capacity_1575  1
    load_2_20_12  segment_load_conservation_1705  -1
    load_2_20_12  segment_prefix_lb_1706  1
    load_2_20_12  segment_prefix_ub_1707  1
    load_2_20_12  free_load_conservation_1759  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_13  arc_capacity_1577  -30
    arc_2_20_13  connected_order_arc_1578  -14
    arc_2_20_13  in_degree_1709  1
    arc_2_20_13  out_degree_1754  1
    arc_2_20_13  original_T_including_depot_unload_1788  1.7571531345240103e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_13  arc_capacity_1577  1
    load_2_20_13  segment_load_conservation_1712  -1
    load_2_20_13  segment_prefix_lb_1713  1
    load_2_20_13  segment_prefix_ub_1714  1
    load_2_20_13  free_load_conservation_1759  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_14  arc_capacity_1579  -30
    arc_2_20_14  connected_order_arc_1580  -14
    arc_2_20_14  in_degree_1716  1
    arc_2_20_14  out_degree_1754  1
    arc_2_20_14  original_T_including_depot_unload_1788  1.2941622036935485e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_14  arc_capacity_1579  1
    load_2_20_14  segment_load_conservation_1719  -1
    load_2_20_14  segment_prefix_lb_1720  1
    load_2_20_14  segment_prefix_ub_1721  1
    load_2_20_14  free_load_conservation_1759  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_15  arc_capacity_1581  -30
    arc_2_20_15  connected_order_arc_1582  -14
    arc_2_20_15  in_degree_1723  1
    arc_2_20_15  out_degree_1754  1
    arc_2_20_15  original_T_including_depot_unload_1788  4.6772747357218117e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_15  arc_capacity_1581  1
    load_2_20_15  segment_load_conservation_1726  -1
    load_2_20_15  segment_prefix_lb_1727  1
    load_2_20_15  segment_prefix_ub_1728  1
    load_2_20_15  free_load_conservation_1759  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_16  arc_capacity_1583  -30
    arc_2_20_16  connected_order_arc_1584  -14
    arc_2_20_16  in_degree_1730  1
    arc_2_20_16  out_degree_1754  1
    arc_2_20_16  original_T_including_depot_unload_1788  5.5448403235604167e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_16  arc_capacity_1583  1
    load_2_20_16  segment_load_conservation_1733  -1
    load_2_20_16  segment_prefix_lb_1734  1
    load_2_20_16  segment_prefix_ub_1735  1
    load_2_20_16  free_load_conservation_1759  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_17  arc_capacity_1585  -30
    arc_2_20_17  connected_order_arc_1586  -14
    arc_2_20_17  in_degree_1737  1
    arc_2_20_17  out_degree_1754  1
    arc_2_20_17  original_T_including_depot_unload_1788  6.0985881995898160e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_17  arc_capacity_1585  1
    load_2_20_17  free_load_conservation_1741  -1
    load_2_20_17  free_load_conservation_1759  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_18  arc_capacity_1587  -30
    arc_2_20_18  connected_order_arc_1588  -14
    arc_2_20_18  in_degree_1743  1
    arc_2_20_18  out_degree_1754  1
    arc_2_20_18  original_T_including_depot_unload_1788  5.0525672969651123e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_18  arc_capacity_1587  1
    load_2_20_18  free_load_conservation_1747  -1
    load_2_20_18  free_load_conservation_1759  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_19  arc_capacity_1589  -30
    arc_2_20_19  connected_order_arc_1590  -14
    arc_2_20_19  in_degree_1749  1
    arc_2_20_19  out_degree_1754  1
    arc_2_20_19  original_T_including_depot_unload_1788  1.9462564869425171e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_19  arc_capacity_1589  1
    load_2_20_19  free_load_conservation_1753  -1
    load_2_20_19  free_load_conservation_1759  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_21  arc_capacity_1591  -30
    arc_2_20_21  connected_order_arc_1592  -14
    arc_2_20_21  out_degree_1754  1
    arc_2_20_21  in_degree_1761  1
    arc_2_20_21  original_T_including_depot_unload_1788  1.2674827380665711e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_21  arc_capacity_1591  1
    load_2_20_21  free_load_conservation_1759  1
    load_2_20_21  free_load_conservation_1765  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_22  arc_capacity_1593  -30
    arc_2_20_22  connected_order_arc_1594  -14
    arc_2_20_22  out_degree_1754  1
    arc_2_20_22  in_degree_1767  1
    arc_2_20_22  original_T_including_depot_unload_1788  3.3469758905462760e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_22  arc_capacity_1593  1
    load_2_20_22  free_load_conservation_1759  1
    load_2_20_22  free_load_conservation_1771  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_23  arc_capacity_1595  -30
    arc_2_20_23  connected_order_arc_1596  -14
    arc_2_20_23  out_degree_1754  1
    arc_2_20_23  in_degree_1773  1
    arc_2_20_23  original_T_including_depot_unload_1788  1.5117151439160034e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_23  arc_capacity_1595  1
    load_2_20_23  free_load_conservation_1759  1
    load_2_20_23  free_load_conservation_1777  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_24  arc_capacity_1597  -30
    arc_2_20_24  connected_order_arc_1598  -14
    arc_2_20_24  out_degree_1754  1
    arc_2_20_24  in_degree_1779  1
    arc_2_20_24  original_T_including_depot_unload_1788  6.7711923781893620e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_24  arc_capacity_1597  1
    load_2_20_24  free_load_conservation_1759  1
    load_2_20_24  free_load_conservation_1783  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_0  arc_capacity_1599  -30
    arc_2_21_0  depot_return_or_bypass_1700  1
    arc_2_21_0  out_degree_1760  1
    arc_2_21_0  original_T_including_depot_unload_1788  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_0  arc_capacity_1599  1
    load_2_21_0  free_load_conservation_1765  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_12  arc_capacity_1600  -30
    arc_2_21_12  connected_order_arc_1601  -14
    arc_2_21_12  in_degree_1702  1
    arc_2_21_12  out_degree_1760  1
    arc_2_21_12  original_T_including_depot_unload_1788  8.3486971116736720e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_12  arc_capacity_1600  1
    load_2_21_12  segment_load_conservation_1705  -1
    load_2_21_12  segment_prefix_lb_1706  1
    load_2_21_12  segment_prefix_ub_1707  1
    load_2_21_12  free_load_conservation_1765  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_13  arc_capacity_1602  -30
    arc_2_21_13  connected_order_arc_1603  -14
    arc_2_21_13  in_degree_1709  1
    arc_2_21_13  out_degree_1760  1
    arc_2_21_13  original_T_including_depot_unload_1788  2.0178882184947397e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_13  arc_capacity_1602  1
    load_2_21_13  segment_load_conservation_1712  -1
    load_2_21_13  segment_prefix_lb_1713  1
    load_2_21_13  segment_prefix_ub_1714  1
    load_2_21_13  free_load_conservation_1765  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_14  arc_capacity_1604  -30
    arc_2_21_14  connected_order_arc_1605  -14
    arc_2_21_14  in_degree_1716  1
    arc_2_21_14  out_degree_1760  1
    arc_2_21_14  original_T_including_depot_unload_1788  1.8362893893653638e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_14  arc_capacity_1604  1
    load_2_21_14  segment_load_conservation_1719  -1
    load_2_21_14  segment_prefix_lb_1720  1
    load_2_21_14  segment_prefix_ub_1721  1
    load_2_21_14  free_load_conservation_1765  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_15  arc_capacity_1606  -30
    arc_2_21_15  connected_order_arc_1607  -14
    arc_2_21_15  in_degree_1723  1
    arc_2_21_15  out_degree_1760  1
    arc_2_21_15  original_T_including_depot_unload_1788  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_15  arc_capacity_1606  1
    load_2_21_15  segment_load_conservation_1726  -1
    load_2_21_15  segment_prefix_lb_1727  1
    load_2_21_15  segment_prefix_ub_1728  1
    load_2_21_15  free_load_conservation_1765  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_16  arc_capacity_1608  -30
    arc_2_21_16  connected_order_arc_1609  -14
    arc_2_21_16  in_degree_1730  1
    arc_2_21_16  out_degree_1760  1
    arc_2_21_16  original_T_including_depot_unload_1788  8.7684829846426385e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_16  arc_capacity_1608  1
    load_2_21_16  segment_load_conservation_1733  -1
    load_2_21_16  segment_prefix_lb_1734  1
    load_2_21_16  segment_prefix_ub_1735  1
    load_2_21_16  free_load_conservation_1765  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_17  arc_capacity_1610  -30
    arc_2_21_17  connected_order_arc_1611  -14
    arc_2_21_17  in_degree_1737  1
    arc_2_21_17  out_degree_1760  1
    arc_2_21_17  original_T_including_depot_unload_1788  1.4088953223409719e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_17  arc_capacity_1610  1
    load_2_21_17  free_load_conservation_1741  -1
    load_2_21_17  free_load_conservation_1765  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_18  arc_capacity_1612  -30
    arc_2_21_18  connected_order_arc_1613  -14
    arc_2_21_18  in_degree_1743  1
    arc_2_21_18  out_degree_1760  1
    arc_2_21_18  original_T_including_depot_unload_1788  1.6906177970488723e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_18  arc_capacity_1612  1
    load_2_21_18  free_load_conservation_1747  -1
    load_2_21_18  free_load_conservation_1765  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_19  arc_capacity_1614  -30
    arc_2_21_19  connected_order_arc_1615  -14
    arc_2_21_19  in_degree_1749  1
    arc_2_21_19  out_degree_1760  1
    arc_2_21_19  original_T_including_depot_unload_1788  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_19  arc_capacity_1614  1
    load_2_21_19  free_load_conservation_1753  -1
    load_2_21_19  free_load_conservation_1765  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_20  arc_capacity_1616  -30
    arc_2_21_20  connected_order_arc_1617  -14
    arc_2_21_20  in_degree_1755  1
    arc_2_21_20  out_degree_1760  1
    arc_2_21_20  original_T_including_depot_unload_1788  1.2674827380665711e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_20  arc_capacity_1616  1
    load_2_21_20  free_load_conservation_1759  -1
    load_2_21_20  free_load_conservation_1765  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_22  arc_capacity_1618  -30
    arc_2_21_22  connected_order_arc_1619  -14
    arc_2_21_22  out_degree_1760  1
    arc_2_21_22  in_degree_1767  1
    arc_2_21_22  original_T_including_depot_unload_1788  9.3962613467893414e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_22  arc_capacity_1618  1
    load_2_21_22  free_load_conservation_1765  1
    load_2_21_22  free_load_conservation_1771  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_23  arc_capacity_1620  -30
    arc_2_21_23  connected_order_arc_1621  -14
    arc_2_21_23  out_degree_1760  1
    arc_2_21_23  in_degree_1773  1
    arc_2_21_23  original_T_including_depot_unload_1788  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_23  arc_capacity_1620  1
    load_2_21_23  free_load_conservation_1765  1
    load_2_21_23  free_load_conservation_1777  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_24  arc_capacity_1622  -30
    arc_2_21_24  connected_order_arc_1623  -14
    arc_2_21_24  out_degree_1760  1
    arc_2_21_24  in_degree_1779  1
    arc_2_21_24  original_T_including_depot_unload_1788  603.649383070884
    MARKER    'MARKER'                 'INTEND'
    load_2_21_24  arc_capacity_1622  1
    load_2_21_24  free_load_conservation_1765  1
    load_2_21_24  free_load_conservation_1783  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_0  arc_capacity_1624  -30
    arc_2_22_0  depot_return_or_bypass_1700  1
    arc_2_22_0  out_degree_1766  1
    arc_2_22_0  original_T_including_depot_unload_1788  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_0  arc_capacity_1624  1
    load_2_22_0  free_load_conservation_1771  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_12  arc_capacity_1625  -30
    arc_2_22_12  connected_order_arc_1626  -14
    arc_2_22_12  in_degree_1702  1
    arc_2_22_12  out_degree_1766  1
    arc_2_22_12  original_T_including_depot_unload_1788  6.2886632383683013e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_12  arc_capacity_1625  1
    load_2_22_12  segment_load_conservation_1705  -1
    load_2_22_12  segment_prefix_lb_1706  1
    load_2_22_12  segment_prefix_ub_1707  1
    load_2_22_12  free_load_conservation_1771  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_13  arc_capacity_1627  -30
    arc_2_22_13  connected_order_arc_1628  -14
    arc_2_22_13  in_degree_1709  1
    arc_2_22_13  out_degree_1766  1
    arc_2_22_13  original_T_including_depot_unload_1788  1.7998334548300843e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_22_13  arc_capacity_1627  1
    load_2_22_13  segment_load_conservation_1712  -1
    load_2_22_13  segment_prefix_lb_1713  1
    load_2_22_13  segment_prefix_ub_1714  1
    load_2_22_13  free_load_conservation_1771  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_14  arc_capacity_1629  -30
    arc_2_22_14  connected_order_arc_1630  -14
    arc_2_22_14  in_degree_1716  1
    arc_2_22_14  out_degree_1766  1
    arc_2_22_14  original_T_including_depot_unload_1788  1.4001236472738528e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_22_14  arc_capacity_1629  1
    load_2_22_14  segment_load_conservation_1719  -1
    load_2_22_14  segment_prefix_lb_1720  1
    load_2_22_14  segment_prefix_ub_1721  1
    load_2_22_14  free_load_conservation_1771  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_15  arc_capacity_1631  -30
    arc_2_22_15  connected_order_arc_1632  -14
    arc_2_22_15  in_degree_1723  1
    arc_2_22_15  out_degree_1766  1
    arc_2_22_15  original_T_including_depot_unload_1788  2.4111148152767828e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_15  arc_capacity_1631  1
    load_2_22_15  segment_load_conservation_1726  -1
    load_2_22_15  segment_prefix_lb_1727  1
    load_2_22_15  segment_prefix_ub_1728  1
    load_2_22_15  free_load_conservation_1771  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_16  arc_capacity_1633  -30
    arc_2_22_16  connected_order_arc_1634  -14
    arc_2_22_16  in_degree_1730  1
    arc_2_22_16  out_degree_1766  1
    arc_2_22_16  original_T_including_depot_unload_1788  3.9864800790786632e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_16  arc_capacity_1633  1
    load_2_22_16  segment_load_conservation_1733  -1
    load_2_22_16  segment_prefix_lb_1734  1
    load_2_22_16  segment_prefix_ub_1735  1
    load_2_22_16  free_load_conservation_1771  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_17  arc_capacity_1635  -30
    arc_2_22_17  connected_order_arc_1636  -14
    arc_2_22_17  in_degree_1737  1
    arc_2_22_17  out_degree_1766  1
    arc_2_22_17  original_T_including_depot_unload_1788  6.4419272207888969e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_17  arc_capacity_1635  1
    load_2_22_17  free_load_conservation_1741  -1
    load_2_22_17  free_load_conservation_1771  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_18  arc_capacity_1637  -30
    arc_2_22_18  connected_order_arc_1638  -14
    arc_2_22_18  in_degree_1743  1
    arc_2_22_18  out_degree_1766  1
    arc_2_22_18  original_T_including_depot_unload_1788  7.6789230776331749e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_18  arc_capacity_1637  1
    load_2_22_18  free_load_conservation_1747  -1
    load_2_22_18  free_load_conservation_1771  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_19  arc_capacity_1639  -30
    arc_2_22_19  connected_order_arc_1640  -14
    arc_2_22_19  in_degree_1749  1
    arc_2_22_19  out_degree_1766  1
    arc_2_22_19  original_T_including_depot_unload_1788  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_22_19  arc_capacity_1639  1
    load_2_22_19  free_load_conservation_1753  -1
    load_2_22_19  free_load_conservation_1771  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_20  arc_capacity_1641  -30
    arc_2_22_20  connected_order_arc_1642  -14
    arc_2_22_20  in_degree_1755  1
    arc_2_22_20  out_degree_1766  1
    arc_2_22_20  original_T_including_depot_unload_1788  3.3469758905462760e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_20  arc_capacity_1641  1
    load_2_22_20  free_load_conservation_1759  -1
    load_2_22_20  free_load_conservation_1771  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_21  arc_capacity_1643  -30
    arc_2_22_21  connected_order_arc_1644  -14
    arc_2_22_21  in_degree_1761  1
    arc_2_22_21  out_degree_1766  1
    arc_2_22_21  original_T_including_depot_unload_1788  9.3962613467893414e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_21  arc_capacity_1643  1
    load_2_22_21  free_load_conservation_1765  -1
    load_2_22_21  free_load_conservation_1771  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_23  arc_capacity_1645  -30
    arc_2_22_23  connected_order_arc_1646  -14
    arc_2_22_23  out_degree_1766  1
    arc_2_22_23  in_degree_1773  1
    arc_2_22_23  original_T_including_depot_unload_1788  1.5968108380866881e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_22_23  arc_capacity_1645  1
    load_2_22_23  free_load_conservation_1771  1
    load_2_22_23  free_load_conservation_1777  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_24  arc_capacity_1647  -30
    arc_2_22_24  connected_order_arc_1648  -14
    arc_2_22_24  out_degree_1766  1
    arc_2_22_24  in_degree_1779  1
    arc_2_22_24  original_T_including_depot_unload_1788  3.4289721135663990e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_24  arc_capacity_1647  1
    load_2_22_24  free_load_conservation_1771  1
    load_2_22_24  free_load_conservation_1783  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_23_0  arc_capacity_1649  -30
    arc_2_23_0  depot_return_or_bypass_1700  1
    arc_2_23_0  out_degree_1772  1
    arc_2_23_0  original_T_including_depot_unload_1788  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_23_0  arc_capacity_1649  1
    load_2_23_0  free_load_conservation_1777  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_23_12  arc_capacity_1650  -30
    arc_2_23_12  connected_order_arc_1651  -14
    arc_2_23_12  in_degree_1702  1
    arc_2_23_12  out_degree_1772  1
    arc_2_23_12  original_T_including_depot_unload_1788  1.1544376314422677e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_23_12  arc_capacity_1650  1
    load_2_23_12  segment_load_conservation_1705  -1
    load_2_23_12  segment_prefix_lb_1706  1
    load_2_23_12  segment_prefix_ub_1707  1
    load_2_23_12  free_load_conservation_1777  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_23_13  arc_capacity_1652  -30
    arc_2_23_13  connected_order_arc_1653  -14
    arc_2_23_13  in_degree_1709  1
    arc_2_23_13  out_degree_1772  1
    arc_2_23_13  original_T_including_depot_unload_1788  3.1118349756671438e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_23_13  arc_capacity_1652  1
    load_2_23_13  segment_load_conservation_1712  -1
    load_2_23_13  segment_prefix_lb_1713  1
    load_2_23_13  segment_prefix_ub_1714  1
    load_2_23_13  free_load_conservation_1777  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_23_14  arc_capacity_1654  -30
    arc_2_23_14  connected_order_arc_1655  -14
    arc_2_23_14  in_degree_1716  1
    arc_2_23_14  out_degree_1772  1
    arc_2_23_14  original_T_including_depot_unload_1788  2.2865444230199981e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_23_14  arc_capacity_1654  1
    load_2_23_14  segment_load_conservation_1719  -1
    load_2_23_14  segment_prefix_lb_1720  1
    load_2_23_14  segment_prefix_ub_1721  1
    load_2_23_14  free_load_conservation_1777  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_23_15  arc_capacity_1656  -30
    arc_2_23_15  connected_order_arc_1657  -14
    arc_2_23_15  in_degree_1723  1
    arc_2_23_15  out_degree_1772  1
    arc_2_23_15  original_T_including_depot_unload_1788  1.4150780419437449e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_23_15  arc_capacity_1656  1
    load_2_23_15  segment_load_conservation_1726  -1
    load_2_23_15  segment_prefix_lb_1727  1
    load_2_23_15  segment_prefix_ub_1728  1
    load_2_23_15  free_load_conservation_1777  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_23_16  arc_capacity_1658  -30
    arc_2_23_16  connected_order_arc_1659  -14
    arc_2_23_16  in_degree_1730  1
    arc_2_23_16  out_degree_1772  1
    arc_2_23_16  original_T_including_depot_unload_1788  1.2608612406747543e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_23_16  arc_capacity_1658  1
    load_2_23_16  segment_load_conservation_1733  -1
    load_2_23_16  segment_prefix_lb_1734  1
    load_2_23_16  segment_prefix_ub_1735  1
    load_2_23_16  free_load_conservation_1777  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_23_17  arc_capacity_1660  -30
    arc_2_23_17  connected_order_arc_1661  -14
    arc_2_23_17  in_degree_1737  1
    arc_2_23_17  out_degree_1772  1
    arc_2_23_17  original_T_including_depot_unload_1788  2.1214998192647863e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_23_17  arc_capacity_1660  1
    load_2_23_17  free_load_conservation_1741  -1
    load_2_23_17  free_load_conservation_1777  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_23_18  arc_capacity_1662  -30
    arc_2_23_18  connected_order_arc_1663  -14
    arc_2_23_18  in_degree_1743  1
    arc_2_23_18  out_degree_1772  1
    arc_2_23_18  original_T_including_depot_unload_1788  1.8780729343410642e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_23_18  arc_capacity_1662  1
    load_2_23_18  free_load_conservation_1747  -1
    load_2_23_18  free_load_conservation_1777  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_23_19  arc_capacity_1664  -30
    arc_2_23_19  connected_order_arc_1665  -14
    arc_2_23_19  in_degree_1749  1
    arc_2_23_19  out_degree_1772  1
    arc_2_23_19  original_T_including_depot_unload_1788  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_23_19  arc_capacity_1664  1
    load_2_23_19  free_load_conservation_1753  -1
    load_2_23_19  free_load_conservation_1777  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_23_20  arc_capacity_1666  -30
    arc_2_23_20  connected_order_arc_1667  -14
    arc_2_23_20  in_degree_1755  1
    arc_2_23_20  out_degree_1772  1
    arc_2_23_20  original_T_including_depot_unload_1788  1.5117151439160034e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_23_20  arc_capacity_1666  1
    load_2_23_20  free_load_conservation_1759  -1
    load_2_23_20  free_load_conservation_1777  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_23_21  arc_capacity_1668  -30
    arc_2_23_21  connected_order_arc_1669  -14
    arc_2_23_21  in_degree_1761  1
    arc_2_23_21  out_degree_1772  1
    arc_2_23_21  original_T_including_depot_unload_1788  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_23_21  arc_capacity_1668  1
    load_2_23_21  free_load_conservation_1765  -1
    load_2_23_21  free_load_conservation_1777  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_23_22  arc_capacity_1670  -30
    arc_2_23_22  connected_order_arc_1671  -14
    arc_2_23_22  in_degree_1767  1
    arc_2_23_22  out_degree_1772  1
    arc_2_23_22  original_T_including_depot_unload_1788  1.5968108380866881e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_23_22  arc_capacity_1670  1
    load_2_23_22  free_load_conservation_1771  -1
    load_2_23_22  free_load_conservation_1777  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_23_24  arc_capacity_1672  -30
    arc_2_23_24  connected_order_arc_1673  -14
    arc_2_23_24  out_degree_1772  1
    arc_2_23_24  in_degree_1779  1
    arc_2_23_24  original_T_including_depot_unload_1788  1.7249161387293191e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_23_24  arc_capacity_1672  1
    load_2_23_24  free_load_conservation_1777  1
    load_2_23_24  free_load_conservation_1783  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_24_0  arc_capacity_1674  -30
    arc_2_24_0  depot_return_or_bypass_1700  1
    arc_2_24_0  out_degree_1778  1
    arc_2_24_0  original_T_including_depot_unload_1788  5.4249700630778887e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_24_0  arc_capacity_1674  1
    load_2_24_0  free_load_conservation_1783  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_24_12  arc_capacity_1675  -30
    arc_2_24_12  connected_order_arc_1676  -14
    arc_2_24_12  in_degree_1702  1
    arc_2_24_12  out_degree_1778  1
    arc_2_24_12  original_T_including_depot_unload_1788  6.0309764600105484e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_24_12  arc_capacity_1675  1
    load_2_24_12  segment_load_conservation_1705  -1
    load_2_24_12  segment_prefix_lb_1706  1
    load_2_24_12  segment_prefix_ub_1707  1
    load_2_24_12  free_load_conservation_1783  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_24_13  arc_capacity_1677  -30
    arc_2_24_13  connected_order_arc_1678  -14
    arc_2_24_13  in_degree_1709  1
    arc_2_24_13  out_degree_1778  1
    arc_2_24_13  original_T_including_depot_unload_1788  1.8805180645589260e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_24_13  arc_capacity_1677  1
    load_2_24_13  segment_load_conservation_1712  -1
    load_2_24_13  segment_prefix_lb_1713  1
    load_2_24_13  segment_prefix_ub_1714  1
    load_2_24_13  free_load_conservation_1783  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_24_14  arc_capacity_1679  -30
    arc_2_24_14  connected_order_arc_1680  -14
    arc_2_24_14  in_degree_1716  1
    arc_2_24_14  out_degree_1778  1
    arc_2_24_14  original_T_including_depot_unload_1788  1.5552905028977075e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_24_14  arc_capacity_1679  1
    load_2_24_14  segment_load_conservation_1719  -1
    load_2_24_14  segment_prefix_lb_1720  1
    load_2_24_14  segment_prefix_ub_1721  1
    load_2_24_14  free_load_conservation_1783  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_24_15  arc_capacity_1681  -30
    arc_2_24_15  connected_order_arc_1682  -14
    arc_2_24_15  in_degree_1723  1
    arc_2_24_15  out_degree_1778  1
    arc_2_24_15  original_T_including_depot_unload_1788  3.3800157717255917e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_24_15  arc_capacity_1681  1
    load_2_24_15  segment_load_conservation_1726  -1
    load_2_24_15  segment_prefix_lb_1727  1
    load_2_24_15  segment_prefix_ub_1728  1
    load_2_24_15  free_load_conservation_1783  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_24_16  arc_capacity_1683  -30
    arc_2_24_16  connected_order_arc_1684  -14
    arc_2_24_16  in_degree_1730  1
    arc_2_24_16  out_degree_1778  1
    arc_2_24_16  original_T_including_depot_unload_1788  4.6789193623835109e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_24_16  arc_capacity_1683  1
    load_2_24_16  segment_load_conservation_1733  -1
    load_2_24_16  segment_prefix_lb_1734  1
    load_2_24_16  segment_prefix_ub_1735  1
    load_2_24_16  free_load_conservation_1783  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_24_17  arc_capacity_1685  -30
    arc_2_24_17  connected_order_arc_1686  -14
    arc_2_24_17  in_degree_1737  1
    arc_2_24_17  out_degree_1778  1
    arc_2_24_17  original_T_including_depot_unload_1788  8.4962277657921186e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_24_17  arc_capacity_1685  1
    load_2_24_17  free_load_conservation_1741  -1
    load_2_24_17  free_load_conservation_1783  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_24_18  arc_capacity_1687  -30
    arc_2_24_18  connected_order_arc_1688  -14
    arc_2_24_18  in_degree_1743  1
    arc_2_24_18  out_degree_1778  1
    arc_2_24_18  original_T_including_depot_unload_1788  1.0875821153726588e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_24_18  arc_capacity_1687  1
    load_2_24_18  free_load_conservation_1747  -1
    load_2_24_18  free_load_conservation_1783  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_24_19  arc_capacity_1689  -30
    arc_2_24_19  connected_order_arc_1690  -14
    arc_2_24_19  in_degree_1749  1
    arc_2_24_19  out_degree_1778  1
    arc_2_24_19  original_T_including_depot_unload_1788  1.6231508478292610e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_24_19  arc_capacity_1689  1
    load_2_24_19  free_load_conservation_1753  -1
    load_2_24_19  free_load_conservation_1783  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_24_20  arc_capacity_1691  -30
    arc_2_24_20  connected_order_arc_1692  -14
    arc_2_24_20  in_degree_1755  1
    arc_2_24_20  out_degree_1778  1
    arc_2_24_20  original_T_including_depot_unload_1788  6.7711923781893620e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_24_20  arc_capacity_1691  1
    load_2_24_20  free_load_conservation_1759  -1
    load_2_24_20  free_load_conservation_1783  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_24_21  arc_capacity_1693  -30
    arc_2_24_21  connected_order_arc_1694  -14
    arc_2_24_21  in_degree_1761  1
    arc_2_24_21  out_degree_1778  1
    arc_2_24_21  original_T_including_depot_unload_1788  603.649383070884
    MARKER    'MARKER'                 'INTEND'
    load_2_24_21  arc_capacity_1693  1
    load_2_24_21  free_load_conservation_1765  -1
    load_2_24_21  free_load_conservation_1783  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_24_22  arc_capacity_1695  -30
    arc_2_24_22  connected_order_arc_1696  -14
    arc_2_24_22  in_degree_1767  1
    arc_2_24_22  out_degree_1778  1
    arc_2_24_22  original_T_including_depot_unload_1788  3.4289721135663990e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_24_22  arc_capacity_1695  1
    load_2_24_22  free_load_conservation_1771  -1
    load_2_24_22  free_load_conservation_1783  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_24_23  arc_capacity_1697  -30
    arc_2_24_23  connected_order_arc_1698  -14
    arc_2_24_23  in_degree_1773  1
    arc_2_24_23  out_degree_1778  1
    arc_2_24_23  original_T_including_depot_unload_1788  1.7249161387293191e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_24_23  arc_capacity_1697  1
    load_2_24_23  free_load_conservation_1777  -1
    load_2_24_23  free_load_conservation_1783  1
RHS
    RHS1      OBJ       -5.3775000000000006e-01
    RHS1      onehot_18_36  1
    RHS1      onehot_22_65  1
    RHS1      onehot_31_94  1
    RHS1      onehot_14_129  1
    RHS1      onehot_16_158  1
    RHS1      onehot_5_195  1
    RHS1      onehot_32_224  1
    RHS1      onehot_3_263  1
    RHS1      stock_ub_267  41
    RHS1      parent_nonstrict_scope_268  3.0154506565812556e-01
    RHS1      normalization_325  1
    RHS1      connected_order_arc_457  -14
    RHS1      connected_order_arc_459  -14
    RHS1      connected_order_arc_461  -14
    RHS1      connected_order_arc_463  -14
    RHS1      connected_order_arc_465  -14
    RHS1      connected_order_arc_467  -14
    RHS1      connected_order_arc_469  -14
    RHS1      connected_order_arc_471  -14
    RHS1      connected_order_arc_473  -14
    RHS1      connected_order_arc_475  -14
    RHS1      connected_order_arc_477  -14
    RHS1      connected_order_arc_479  -14
    RHS1      connected_order_arc_481  -14
    RHS1      connected_order_arc_484  -14
    RHS1      connected_order_arc_486  -14
    RHS1      connected_order_arc_488  -14
    RHS1      connected_order_arc_490  -14
    RHS1      connected_order_arc_492  -14
    RHS1      connected_order_arc_494  -14
    RHS1      connected_order_arc_496  -14
    RHS1      connected_order_arc_498  -14
    RHS1      connected_order_arc_500  -14
    RHS1      connected_order_arc_502  -14
    RHS1      connected_order_arc_504  -14
    RHS1      connected_order_arc_506  -14
    RHS1      connected_order_arc_508  -14
    RHS1      connected_order_arc_511  -14
    RHS1      connected_order_arc_513  -14
    RHS1      connected_order_arc_515  -14
    RHS1      connected_order_arc_517  -14
    RHS1      connected_order_arc_519  -14
    RHS1      connected_order_arc_521  -14
    RHS1      connected_order_arc_523  -14
    RHS1      connected_order_arc_525  -14
    RHS1      connected_order_arc_527  -14
    RHS1      connected_order_arc_529  -14
    RHS1      connected_order_arc_531  -14
    RHS1      connected_order_arc_533  -14
    RHS1      connected_order_arc_535  -14
    RHS1      connected_order_arc_538  -14
    RHS1      connected_order_arc_540  -14
    RHS1      connected_order_arc_542  -14
    RHS1      connected_order_arc_544  -14
    RHS1      connected_order_arc_546  -14
    RHS1      connected_order_arc_548  -14
    RHS1      connected_order_arc_550  -14
    RHS1      connected_order_arc_552  -14
    RHS1      connected_order_arc_554  -14
    RHS1      connected_order_arc_556  -14
    RHS1      connected_order_arc_558  -14
    RHS1      connected_order_arc_560  -14
    RHS1      connected_order_arc_562  -14
    RHS1      connected_order_arc_565  -14
    RHS1      connected_order_arc_567  -14
    RHS1      connected_order_arc_569  -14
    RHS1      connected_order_arc_571  -14
    RHS1      connected_order_arc_573  -14
    RHS1      connected_order_arc_575  -14
    RHS1      connected_order_arc_577  -14
    RHS1      connected_order_arc_579  -14
    RHS1      connected_order_arc_581  -14
    RHS1      connected_order_arc_583  -14
    RHS1      connected_order_arc_585  -14
    RHS1      connected_order_arc_587  -14
    RHS1      connected_order_arc_589  -14
    RHS1      connected_order_arc_592  -14
    RHS1      connected_order_arc_594  -14
    RHS1      connected_order_arc_596  -14
    RHS1      connected_order_arc_598  -14
    RHS1      connected_order_arc_600  -14
    RHS1      connected_order_arc_602  -14
    RHS1      connected_order_arc_604  -14
    RHS1      connected_order_arc_606  -14
    RHS1      connected_order_arc_608  -14
    RHS1      connected_order_arc_610  -14
    RHS1      connected_order_arc_612  -14
    RHS1      connected_order_arc_614  -14
    RHS1      connected_order_arc_616  -14
    RHS1      connected_order_arc_619  -14
    RHS1      connected_order_arc_621  -14
    RHS1      connected_order_arc_623  -14
    RHS1      connected_order_arc_625  -14
    RHS1      connected_order_arc_627  -14
    RHS1      connected_order_arc_629  -14
    RHS1      connected_order_arc_631  -14
    RHS1      connected_order_arc_633  -14
    RHS1      connected_order_arc_635  -14
    RHS1      connected_order_arc_637  -14
    RHS1      connected_order_arc_639  -14
    RHS1      connected_order_arc_641  -14
    RHS1      connected_order_arc_643  -14
    RHS1      connected_order_arc_646  -14
    RHS1      connected_order_arc_648  -14
    RHS1      connected_order_arc_650  -14
    RHS1      connected_order_arc_652  -14
    RHS1      connected_order_arc_654  -14
    RHS1      connected_order_arc_656  -14
    RHS1      connected_order_arc_658  -14
    RHS1      connected_order_arc_660  -14
    RHS1      connected_order_arc_662  -14
    RHS1      connected_order_arc_664  -14
    RHS1      connected_order_arc_666  -14
    RHS1      connected_order_arc_668  -14
    RHS1      connected_order_arc_670  -14
    RHS1      connected_order_arc_673  -14
    RHS1      connected_order_arc_675  -14
    RHS1      connected_order_arc_677  -14
    RHS1      connected_order_arc_679  -14
    RHS1      connected_order_arc_681  -14
    RHS1      connected_order_arc_683  -14
    RHS1      connected_order_arc_685  -14
    RHS1      connected_order_arc_687  -14
    RHS1      connected_order_arc_689  -14
    RHS1      connected_order_arc_691  -14
    RHS1      connected_order_arc_693  -14
    RHS1      connected_order_arc_695  -14
    RHS1      connected_order_arc_697  -14
    RHS1      connected_order_arc_700  -14
    RHS1      connected_order_arc_702  -14
    RHS1      connected_order_arc_704  -14
    RHS1      connected_order_arc_706  -14
    RHS1      connected_order_arc_708  -14
    RHS1      connected_order_arc_710  -14
    RHS1      connected_order_arc_712  -14
    RHS1      connected_order_arc_714  -14
    RHS1      connected_order_arc_716  -14
    RHS1      connected_order_arc_718  -14
    RHS1      connected_order_arc_720  -14
    RHS1      connected_order_arc_722  -14
    RHS1      connected_order_arc_724  -14
    RHS1      connected_order_arc_727  -14
    RHS1      connected_order_arc_729  -14
    RHS1      connected_order_arc_731  -14
    RHS1      connected_order_arc_733  -14
    RHS1      connected_order_arc_735  -14
    RHS1      connected_order_arc_737  -14
    RHS1      connected_order_arc_739  -14
    RHS1      connected_order_arc_741  -14
    RHS1      connected_order_arc_743  -14
    RHS1      connected_order_arc_745  -14
    RHS1      connected_order_arc_747  -14
    RHS1      connected_order_arc_749  -14
    RHS1      connected_order_arc_751  -14
    RHS1      connected_order_arc_754  -14
    RHS1      connected_order_arc_756  -14
    RHS1      connected_order_arc_758  -14
    RHS1      connected_order_arc_760  -14
    RHS1      connected_order_arc_762  -14
    RHS1      connected_order_arc_764  -14
    RHS1      connected_order_arc_766  -14
    RHS1      connected_order_arc_768  -14
    RHS1      connected_order_arc_770  -14
    RHS1      connected_order_arc_772  -14
    RHS1      connected_order_arc_774  -14
    RHS1      connected_order_arc_776  -14
    RHS1      connected_order_arc_778  -14
    RHS1      connected_order_arc_781  -14
    RHS1      connected_order_arc_783  -14
    RHS1      connected_order_arc_785  -14
    RHS1      connected_order_arc_787  -14
    RHS1      connected_order_arc_789  -14
    RHS1      connected_order_arc_791  -14
    RHS1      connected_order_arc_793  -14
    RHS1      connected_order_arc_795  -14
    RHS1      connected_order_arc_797  -14
    RHS1      connected_order_arc_799  -14
    RHS1      connected_order_arc_801  -14
    RHS1      connected_order_arc_803  -14
    RHS1      connected_order_arc_805  -14
    RHS1      connected_order_arc_808  -14
    RHS1      connected_order_arc_810  -14
    RHS1      connected_order_arc_812  -14
    RHS1      connected_order_arc_814  -14
    RHS1      connected_order_arc_816  -14
    RHS1      connected_order_arc_818  -14
    RHS1      connected_order_arc_820  -14
    RHS1      connected_order_arc_822  -14
    RHS1      connected_order_arc_824  -14
    RHS1      connected_order_arc_826  -14
    RHS1      connected_order_arc_828  -14
    RHS1      connected_order_arc_830  -14
    RHS1      connected_order_arc_832  -14
    RHS1      depot_departure_or_bypass_833  1
    RHS1      depot_return_or_bypass_834  1
    RHS1      segment_load_conservation_839  5
    RHS1      segment_prefix_ub_841  15
    RHS1      segment_load_conservation_846  5
    RHS1      segment_prefix_ub_848  15
    RHS1      segment_load_conservation_853  4
    RHS1      segment_prefix_ub_855  16
    RHS1      segment_load_conservation_860  -8
    RHS1      segment_prefix_lb_861  8
    RHS1      segment_prefix_ub_862  20
    RHS1      segment_load_conservation_867  5
    RHS1      segment_prefix_ub_869  15
    RHS1      segment_load_conservation_874  -7
    RHS1      segment_prefix_lb_875  7
    RHS1      segment_prefix_ub_876  15
    RHS1      fixed_segment_relative_order_925  1
    RHS1      fixed_segment_relative_order_926  1
    RHS1      fixed_segment_relative_order_927  1
    RHS1      fixed_segment_relative_order_928  1
    RHS1      fixed_segment_relative_order_929  1
    RHS1      original_T_including_depot_unload_930  3.6085578181927040e+03
    RHS1      connected_order_arc_947  -13
    RHS1      connected_order_arc_949  -13
    RHS1      connected_order_arc_951  -13
    RHS1      connected_order_arc_953  -13
    RHS1      connected_order_arc_955  -13
    RHS1      connected_order_arc_957  -13
    RHS1      connected_order_arc_959  -13
    RHS1      connected_order_arc_961  -13
    RHS1      connected_order_arc_963  -13
    RHS1      connected_order_arc_965  -13
    RHS1      connected_order_arc_967  -13
    RHS1      connected_order_arc_969  -13
    RHS1      connected_order_arc_972  -13
    RHS1      connected_order_arc_974  -13
    RHS1      connected_order_arc_976  -13
    RHS1      connected_order_arc_978  -13
    RHS1      connected_order_arc_980  -13
    RHS1      connected_order_arc_982  -13
    RHS1      connected_order_arc_984  -13
    RHS1      connected_order_arc_986  -13
    RHS1      connected_order_arc_988  -13
    RHS1      connected_order_arc_990  -13
    RHS1      connected_order_arc_992  -13
    RHS1      connected_order_arc_994  -13
    RHS1      connected_order_arc_997  -13
    RHS1      connected_order_arc_999  -13
    RHS1      connected_order_arc_1001  -13
    RHS1      connected_order_arc_1003  -13
    RHS1      connected_order_arc_1005  -13
    RHS1      connected_order_arc_1007  -13
    RHS1      connected_order_arc_1009  -13
    RHS1      connected_order_arc_1011  -13
    RHS1      connected_order_arc_1013  -13
    RHS1      connected_order_arc_1015  -13
    RHS1      connected_order_arc_1017  -13
    RHS1      connected_order_arc_1019  -13
    RHS1      connected_order_arc_1022  -13
    RHS1      connected_order_arc_1024  -13
    RHS1      connected_order_arc_1026  -13
    RHS1      connected_order_arc_1028  -13
    RHS1      connected_order_arc_1030  -13
    RHS1      connected_order_arc_1032  -13
    RHS1      connected_order_arc_1034  -13
    RHS1      connected_order_arc_1036  -13
    RHS1      connected_order_arc_1038  -13
    RHS1      connected_order_arc_1040  -13
    RHS1      connected_order_arc_1042  -13
    RHS1      connected_order_arc_1044  -13
    RHS1      connected_order_arc_1047  -13
    RHS1      connected_order_arc_1049  -13
    RHS1      connected_order_arc_1051  -13
    RHS1      connected_order_arc_1053  -13
    RHS1      connected_order_arc_1055  -13
    RHS1      connected_order_arc_1057  -13
    RHS1      connected_order_arc_1059  -13
    RHS1      connected_order_arc_1061  -13
    RHS1      connected_order_arc_1063  -13
    RHS1      connected_order_arc_1065  -13
    RHS1      connected_order_arc_1067  -13
    RHS1      connected_order_arc_1069  -13
    RHS1      connected_order_arc_1072  -13
    RHS1      connected_order_arc_1074  -13
    RHS1      connected_order_arc_1076  -13
    RHS1      connected_order_arc_1078  -13
    RHS1      connected_order_arc_1080  -13
    RHS1      connected_order_arc_1082  -13
    RHS1      connected_order_arc_1084  -13
    RHS1      connected_order_arc_1086  -13
    RHS1      connected_order_arc_1088  -13
    RHS1      connected_order_arc_1090  -13
    RHS1      connected_order_arc_1092  -13
    RHS1      connected_order_arc_1094  -13
    RHS1      connected_order_arc_1097  -13
    RHS1      connected_order_arc_1099  -13
    RHS1      connected_order_arc_1101  -13
    RHS1      connected_order_arc_1103  -13
    RHS1      connected_order_arc_1105  -13
    RHS1      connected_order_arc_1107  -13
    RHS1      connected_order_arc_1109  -13
    RHS1      connected_order_arc_1111  -13
    RHS1      connected_order_arc_1113  -13
    RHS1      connected_order_arc_1115  -13
    RHS1      connected_order_arc_1117  -13
    RHS1      connected_order_arc_1119  -13
    RHS1      connected_order_arc_1122  -13
    RHS1      connected_order_arc_1124  -13
    RHS1      connected_order_arc_1126  -13
    RHS1      connected_order_arc_1128  -13
    RHS1      connected_order_arc_1130  -13
    RHS1      connected_order_arc_1132  -13
    RHS1      connected_order_arc_1134  -13
    RHS1      connected_order_arc_1136  -13
    RHS1      connected_order_arc_1138  -13
    RHS1      connected_order_arc_1140  -13
    RHS1      connected_order_arc_1142  -13
    RHS1      connected_order_arc_1144  -13
    RHS1      connected_order_arc_1147  -13
    RHS1      connected_order_arc_1149  -13
    RHS1      connected_order_arc_1151  -13
    RHS1      connected_order_arc_1153  -13
    RHS1      connected_order_arc_1155  -13
    RHS1      connected_order_arc_1157  -13
    RHS1      connected_order_arc_1159  -13
    RHS1      connected_order_arc_1161  -13
    RHS1      connected_order_arc_1163  -13
    RHS1      connected_order_arc_1165  -13
    RHS1      connected_order_arc_1167  -13
    RHS1      connected_order_arc_1169  -13
    RHS1      connected_order_arc_1172  -13
    RHS1      connected_order_arc_1174  -13
    RHS1      connected_order_arc_1176  -13
    RHS1      connected_order_arc_1178  -13
    RHS1      connected_order_arc_1180  -13
    RHS1      connected_order_arc_1182  -13
    RHS1      connected_order_arc_1184  -13
    RHS1      connected_order_arc_1186  -13
    RHS1      connected_order_arc_1188  -13
    RHS1      connected_order_arc_1190  -13
    RHS1      connected_order_arc_1192  -13
    RHS1      connected_order_arc_1194  -13
    RHS1      connected_order_arc_1197  -13
    RHS1      connected_order_arc_1199  -13
    RHS1      connected_order_arc_1201  -13
    RHS1      connected_order_arc_1203  -13
    RHS1      connected_order_arc_1205  -13
    RHS1      connected_order_arc_1207  -13
    RHS1      connected_order_arc_1209  -13
    RHS1      connected_order_arc_1211  -13
    RHS1      connected_order_arc_1213  -13
    RHS1      connected_order_arc_1215  -13
    RHS1      connected_order_arc_1217  -13
    RHS1      connected_order_arc_1219  -13
    RHS1      connected_order_arc_1222  -13
    RHS1      connected_order_arc_1224  -13
    RHS1      connected_order_arc_1226  -13
    RHS1      connected_order_arc_1228  -13
    RHS1      connected_order_arc_1230  -13
    RHS1      connected_order_arc_1232  -13
    RHS1      connected_order_arc_1234  -13
    RHS1      connected_order_arc_1236  -13
    RHS1      connected_order_arc_1238  -13
    RHS1      connected_order_arc_1240  -13
    RHS1      connected_order_arc_1242  -13
    RHS1      connected_order_arc_1244  -13
    RHS1      connected_order_arc_1247  -13
    RHS1      connected_order_arc_1249  -13
    RHS1      connected_order_arc_1251  -13
    RHS1      connected_order_arc_1253  -13
    RHS1      connected_order_arc_1255  -13
    RHS1      connected_order_arc_1257  -13
    RHS1      connected_order_arc_1259  -13
    RHS1      connected_order_arc_1261  -13
    RHS1      connected_order_arc_1263  -13
    RHS1      connected_order_arc_1265  -13
    RHS1      connected_order_arc_1267  -13
    RHS1      connected_order_arc_1269  -13
    RHS1      depot_departure_or_bypass_1270  1
    RHS1      depot_return_or_bypass_1271  1
    RHS1      segment_load_conservation_1276  6
    RHS1      segment_prefix_ub_1278  19
    RHS1      segment_load_conservation_1283  -5
    RHS1      segment_prefix_lb_1284  6
    RHS1      segment_prefix_ub_1285  25
    RHS1      segment_load_conservation_1290  3
    RHS1      segment_prefix_ub_1292  22
    RHS1      segment_load_conservation_1297  3
    RHS1      segment_prefix_ub_1299  22
    RHS1      segment_load_conservation_1304  -5
    RHS1      segment_prefix_lb_1305  5
    RHS1      segment_prefix_ub_1306  25
    RHS1      fixed_segment_relative_order_1355  1
    RHS1      fixed_segment_relative_order_1356  1
    RHS1      fixed_segment_relative_order_1357  1
    RHS1      fixed_segment_relative_order_1358  1
    RHS1      original_T_including_depot_unload_1359  2.2933958320926176e+03
    RHS1      connected_order_arc_1376  -13
    RHS1      connected_order_arc_1378  -13
    RHS1      connected_order_arc_1380  -13
    RHS1      connected_order_arc_1382  -13
    RHS1      connected_order_arc_1384  -13
    RHS1      connected_order_arc_1386  -13
    RHS1      connected_order_arc_1388  -13
    RHS1      connected_order_arc_1390  -13
    RHS1      connected_order_arc_1392  -13
    RHS1      connected_order_arc_1394  -13
    RHS1      connected_order_arc_1396  -13
    RHS1      connected_order_arc_1398  -13
    RHS1      connected_order_arc_1401  -13
    RHS1      connected_order_arc_1403  -13
    RHS1      connected_order_arc_1405  -13
    RHS1      connected_order_arc_1407  -13
    RHS1      connected_order_arc_1409  -13
    RHS1      connected_order_arc_1411  -13
    RHS1      connected_order_arc_1413  -13
    RHS1      connected_order_arc_1415  -13
    RHS1      connected_order_arc_1417  -13
    RHS1      connected_order_arc_1419  -13
    RHS1      connected_order_arc_1421  -13
    RHS1      connected_order_arc_1423  -13
    RHS1      connected_order_arc_1426  -13
    RHS1      connected_order_arc_1428  -13
    RHS1      connected_order_arc_1430  -13
    RHS1      connected_order_arc_1432  -13
    RHS1      connected_order_arc_1434  -13
    RHS1      connected_order_arc_1436  -13
    RHS1      connected_order_arc_1438  -13
    RHS1      connected_order_arc_1440  -13
    RHS1      connected_order_arc_1442  -13
    RHS1      connected_order_arc_1444  -13
    RHS1      connected_order_arc_1446  -13
    RHS1      connected_order_arc_1448  -13
    RHS1      connected_order_arc_1451  -13
    RHS1      connected_order_arc_1453  -13
    RHS1      connected_order_arc_1455  -13
    RHS1      connected_order_arc_1457  -13
    RHS1      connected_order_arc_1459  -13
    RHS1      connected_order_arc_1461  -13
    RHS1      connected_order_arc_1463  -13
    RHS1      connected_order_arc_1465  -13
    RHS1      connected_order_arc_1467  -13
    RHS1      connected_order_arc_1469  -13
    RHS1      connected_order_arc_1471  -13
    RHS1      connected_order_arc_1473  -13
    RHS1      connected_order_arc_1476  -13
    RHS1      connected_order_arc_1478  -13
    RHS1      connected_order_arc_1480  -13
    RHS1      connected_order_arc_1482  -13
    RHS1      connected_order_arc_1484  -13
    RHS1      connected_order_arc_1486  -13
    RHS1      connected_order_arc_1488  -13
    RHS1      connected_order_arc_1490  -13
    RHS1      connected_order_arc_1492  -13
    RHS1      connected_order_arc_1494  -13
    RHS1      connected_order_arc_1496  -13
    RHS1      connected_order_arc_1498  -13
    RHS1      connected_order_arc_1501  -13
    RHS1      connected_order_arc_1503  -13
    RHS1      connected_order_arc_1505  -13
    RHS1      connected_order_arc_1507  -13
    RHS1      connected_order_arc_1509  -13
    RHS1      connected_order_arc_1511  -13
    RHS1      connected_order_arc_1513  -13
    RHS1      connected_order_arc_1515  -13
    RHS1      connected_order_arc_1517  -13
    RHS1      connected_order_arc_1519  -13
    RHS1      connected_order_arc_1521  -13
    RHS1      connected_order_arc_1523  -13
    RHS1      connected_order_arc_1526  -13
    RHS1      connected_order_arc_1528  -13
    RHS1      connected_order_arc_1530  -13
    RHS1      connected_order_arc_1532  -13
    RHS1      connected_order_arc_1534  -13
    RHS1      connected_order_arc_1536  -13
    RHS1      connected_order_arc_1538  -13
    RHS1      connected_order_arc_1540  -13
    RHS1      connected_order_arc_1542  -13
    RHS1      connected_order_arc_1544  -13
    RHS1      connected_order_arc_1546  -13
    RHS1      connected_order_arc_1548  -13
    RHS1      connected_order_arc_1551  -13
    RHS1      connected_order_arc_1553  -13
    RHS1      connected_order_arc_1555  -13
    RHS1      connected_order_arc_1557  -13
    RHS1      connected_order_arc_1559  -13
    RHS1      connected_order_arc_1561  -13
    RHS1      connected_order_arc_1563  -13
    RHS1      connected_order_arc_1565  -13
    RHS1      connected_order_arc_1567  -13
    RHS1      connected_order_arc_1569  -13
    RHS1      connected_order_arc_1571  -13
    RHS1      connected_order_arc_1573  -13
    RHS1      connected_order_arc_1576  -13
    RHS1      connected_order_arc_1578  -13
    RHS1      connected_order_arc_1580  -13
    RHS1      connected_order_arc_1582  -13
    RHS1      connected_order_arc_1584  -13
    RHS1      connected_order_arc_1586  -13
    RHS1      connected_order_arc_1588  -13
    RHS1      connected_order_arc_1590  -13
    RHS1      connected_order_arc_1592  -13
    RHS1      connected_order_arc_1594  -13
    RHS1      connected_order_arc_1596  -13
    RHS1      connected_order_arc_1598  -13
    RHS1      connected_order_arc_1601  -13
    RHS1      connected_order_arc_1603  -13
    RHS1      connected_order_arc_1605  -13
    RHS1      connected_order_arc_1607  -13
    RHS1      connected_order_arc_1609  -13
    RHS1      connected_order_arc_1611  -13
    RHS1      connected_order_arc_1613  -13
    RHS1      connected_order_arc_1615  -13
    RHS1      connected_order_arc_1617  -13
    RHS1      connected_order_arc_1619  -13
    RHS1      connected_order_arc_1621  -13
    RHS1      connected_order_arc_1623  -13
    RHS1      connected_order_arc_1626  -13
    RHS1      connected_order_arc_1628  -13
    RHS1      connected_order_arc_1630  -13
    RHS1      connected_order_arc_1632  -13
    RHS1      connected_order_arc_1634  -13
    RHS1      connected_order_arc_1636  -13
    RHS1      connected_order_arc_1638  -13
    RHS1      connected_order_arc_1640  -13
    RHS1      connected_order_arc_1642  -13
    RHS1      connected_order_arc_1644  -13
    RHS1      connected_order_arc_1646  -13
    RHS1      connected_order_arc_1648  -13
    RHS1      connected_order_arc_1651  -13
    RHS1      connected_order_arc_1653  -13
    RHS1      connected_order_arc_1655  -13
    RHS1      connected_order_arc_1657  -13
    RHS1      connected_order_arc_1659  -13
    RHS1      connected_order_arc_1661  -13
    RHS1      connected_order_arc_1663  -13
    RHS1      connected_order_arc_1665  -13
    RHS1      connected_order_arc_1667  -13
    RHS1      connected_order_arc_1669  -13
    RHS1      connected_order_arc_1671  -13
    RHS1      connected_order_arc_1673  -13
    RHS1      connected_order_arc_1676  -13
    RHS1      connected_order_arc_1678  -13
    RHS1      connected_order_arc_1680  -13
    RHS1      connected_order_arc_1682  -13
    RHS1      connected_order_arc_1684  -13
    RHS1      connected_order_arc_1686  -13
    RHS1      connected_order_arc_1688  -13
    RHS1      connected_order_arc_1690  -13
    RHS1      connected_order_arc_1692  -13
    RHS1      connected_order_arc_1694  -13
    RHS1      connected_order_arc_1696  -13
    RHS1      connected_order_arc_1698  -13
    RHS1      depot_departure_or_bypass_1699  1
    RHS1      depot_return_or_bypass_1700  1
    RHS1      segment_load_conservation_1705  3
    RHS1      segment_prefix_ub_1707  27
    RHS1      segment_load_conservation_1712  3
    RHS1      segment_prefix_ub_1714  27
    RHS1      segment_load_conservation_1719  -2
    RHS1      segment_prefix_lb_1720  2
    RHS1      segment_prefix_ub_1721  30
    RHS1      segment_load_conservation_1726  -6
    RHS1      segment_prefix_lb_1727  6
    RHS1      segment_prefix_ub_1728  30
    RHS1      segment_load_conservation_1733  -2
    RHS1      segment_prefix_lb_1734  2
    RHS1      segment_prefix_ub_1735  30
    RHS1      fixed_segment_relative_order_1784  1
    RHS1      fixed_segment_relative_order_1785  1
    RHS1      fixed_segment_relative_order_1786  1
    RHS1      fixed_segment_relative_order_1787  1
    RHS1      original_T_including_depot_unload_1788  6480
BOUNDS
 LO BND1      t         2.5101601721227582e-02
 UP BND1      t         4.1955247735790492e-02
 UP BND1      q         5.1154506565812563e-01
 BV BND1      x_18_0  
 UP BND1      w_18_0    4.1955247735790492e-02
 BV BND1      x_18_1  
 UP BND1      w_18_1    4.1955247735790492e-02
 BV BND1      x_18_2  
 UP BND1      w_18_2    4.1955247735790492e-02
 BV BND1      x_18_3  
 UP BND1      w_18_3    4.1955247735790492e-02
 BV BND1      x_18_4  
 UP BND1      w_18_4    4.1955247735790492e-02
 BV BND1      x_18_5  
 UP BND1      w_18_5    4.1955247735790492e-02
 BV BND1      x_18_6  
 UP BND1      w_18_6    4.1955247735790492e-02
 BV BND1      x_18_7  
 UP BND1      w_18_7    4.1955247735790492e-02
 BV BND1      x_18_8  
 UP BND1      w_18_8    4.1955247735790492e-02
 BV BND1      x_18_9  
 UP BND1      w_18_9    4.1955247735790492e-02
 BV BND1      x_18_10 
 UP BND1      w_18_10   4.1955247735790492e-02
 BV BND1      x_18_11 
 UP BND1      w_18_11   4.1955247735790492e-02
 BV BND1      x_18_12 
 UP BND1      w_18_12   4.1955247735790492e-02
 BV BND1      x_18_13 
 UP BND1      w_18_13   4.1955247735790492e-02
 BV BND1      x_18_14 
 UP BND1      w_18_14   4.1955247735790492e-02
 BV BND1      x_18_15 
 UP BND1      w_18_15   4.1955247735790492e-02
 BV BND1      x_18_16 
 UP BND1      w_18_16   4.1955247735790492e-02
 BV BND1      x_18_17 
 UP BND1      w_18_17   4.1955247735790492e-02
 UP BND1      rho_18    1
 BV BND1      x_22_0  
 UP BND1      w_22_0    4.1955247735790492e-02
 BV BND1      x_22_1  
 UP BND1      w_22_1    4.1955247735790492e-02
 BV BND1      x_22_2  
 UP BND1      w_22_2    4.1955247735790492e-02
 BV BND1      x_22_3  
 UP BND1      w_22_3    4.1955247735790492e-02
 BV BND1      x_22_4  
 UP BND1      w_22_4    4.1955247735790492e-02
 BV BND1      x_22_5  
 UP BND1      w_22_5    4.1955247735790492e-02
 BV BND1      x_22_6  
 UP BND1      w_22_6    4.1955247735790492e-02
 BV BND1      x_22_7  
 UP BND1      w_22_7    4.1955247735790492e-02
 BV BND1      x_22_8  
 UP BND1      w_22_8    4.1955247735790492e-02
 BV BND1      x_22_9  
 UP BND1      w_22_9    4.1955247735790492e-02
 BV BND1      x_22_10 
 UP BND1      w_22_10   4.1955247735790492e-02
 BV BND1      x_22_11 
 UP BND1      w_22_11   4.1955247735790492e-02
 BV BND1      x_22_12 
 UP BND1      w_22_12   4.1955247735790492e-02
 UP BND1      rho_22    1
 BV BND1      x_31_0  
 UP BND1      w_31_0    4.1955247735790492e-02
 BV BND1      x_31_1  
 UP BND1      w_31_1    4.1955247735790492e-02
 BV BND1      x_31_2  
 UP BND1      w_31_2    4.1955247735790492e-02
 BV BND1      x_31_3  
 UP BND1      w_31_3    4.1955247735790492e-02
 BV BND1      x_31_4  
 UP BND1      w_31_4    4.1955247735790492e-02
 BV BND1      x_31_5  
 UP BND1      w_31_5    4.1955247735790492e-02
 BV BND1      x_31_6  
 UP BND1      w_31_6    4.1955247735790492e-02
 BV BND1      x_31_7  
 UP BND1      w_31_7    4.1955247735790492e-02
 BV BND1      x_31_8  
 UP BND1      w_31_8    4.1955247735790492e-02
 BV BND1      x_31_9  
 UP BND1      w_31_9    4.1955247735790492e-02
 BV BND1      x_31_10 
 UP BND1      w_31_10   4.1955247735790492e-02
 BV BND1      x_31_11 
 UP BND1      w_31_11   4.1955247735790492e-02
 BV BND1      x_31_12 
 UP BND1      w_31_12   4.1955247735790492e-02
 UP BND1      rho_31    1
 BV BND1      x_14_0  
 UP BND1      w_14_0    4.1955247735790492e-02
 BV BND1      x_14_1  
 UP BND1      w_14_1    4.1955247735790492e-02
 BV BND1      x_14_2  
 UP BND1      w_14_2    4.1955247735790492e-02
 BV BND1      x_14_3  
 UP BND1      w_14_3    4.1955247735790492e-02
 BV BND1      x_14_4  
 UP BND1      w_14_4    4.1955247735790492e-02
 BV BND1      x_14_5  
 UP BND1      w_14_5    4.1955247735790492e-02
 BV BND1      x_14_6  
 UP BND1      w_14_6    4.1955247735790492e-02
 BV BND1      x_14_7  
 UP BND1      w_14_7    4.1955247735790492e-02
 BV BND1      x_14_8  
 UP BND1      w_14_8    4.1955247735790492e-02
 BV BND1      x_14_9  
 UP BND1      w_14_9    4.1955247735790492e-02
 BV BND1      x_14_10 
 UP BND1      w_14_10   4.1955247735790492e-02
 BV BND1      x_14_11 
 UP BND1      w_14_11   4.1955247735790492e-02
 BV BND1      x_14_12 
 UP BND1      w_14_12   4.1955247735790492e-02
 BV BND1      x_14_13 
 UP BND1      w_14_13   4.1955247735790492e-02
 BV BND1      x_14_14 
 UP BND1      w_14_14   4.1955247735790492e-02
 BV BND1      x_14_15 
 UP BND1      w_14_15   4.1955247735790492e-02
 UP BND1      rho_14    1
 BV BND1      x_16_0  
 UP BND1      w_16_0    4.1955247735790492e-02
 BV BND1      x_16_1  
 UP BND1      w_16_1    4.1955247735790492e-02
 BV BND1      x_16_2  
 UP BND1      w_16_2    4.1955247735790492e-02
 BV BND1      x_16_3  
 UP BND1      w_16_3    4.1955247735790492e-02
 BV BND1      x_16_4  
 UP BND1      w_16_4    4.1955247735790492e-02
 BV BND1      x_16_5  
 UP BND1      w_16_5    4.1955247735790492e-02
 BV BND1      x_16_6  
 UP BND1      w_16_6    4.1955247735790492e-02
 BV BND1      x_16_7  
 UP BND1      w_16_7    4.1955247735790492e-02
 BV BND1      x_16_8  
 UP BND1      w_16_8    4.1955247735790492e-02
 BV BND1      x_16_9  
 UP BND1      w_16_9    4.1955247735790492e-02
 BV BND1      x_16_10 
 UP BND1      w_16_10   4.1955247735790492e-02
 BV BND1      x_16_11 
 UP BND1      w_16_11   4.1955247735790492e-02
 BV BND1      x_16_12 
 UP BND1      w_16_12   4.1955247735790492e-02
 UP BND1      rho_16    1
 BV BND1      x_5_0   
 UP BND1      w_5_0     4.1955247735790492e-02
 BV BND1      x_5_1   
 UP BND1      w_5_1     4.1955247735790492e-02
 BV BND1      x_5_2   
 UP BND1      w_5_2     4.1955247735790492e-02
 BV BND1      x_5_3   
 UP BND1      w_5_3     4.1955247735790492e-02
 BV BND1      x_5_4   
 UP BND1      w_5_4     4.1955247735790492e-02
 BV BND1      x_5_5   
 UP BND1      w_5_5     4.1955247735790492e-02
 BV BND1      x_5_6   
 UP BND1      w_5_6     4.1955247735790492e-02
 BV BND1      x_5_7   
 UP BND1      w_5_7     4.1955247735790492e-02
 BV BND1      x_5_8   
 UP BND1      w_5_8     4.1955247735790492e-02
 BV BND1      x_5_9   
 UP BND1      w_5_9     4.1955247735790492e-02
 BV BND1      x_5_10  
 UP BND1      w_5_10    4.1955247735790492e-02
 BV BND1      x_5_11  
 UP BND1      w_5_11    4.1955247735790492e-02
 BV BND1      x_5_12  
 UP BND1      w_5_12    4.1955247735790492e-02
 BV BND1      x_5_13  
 UP BND1      w_5_13    4.1955247735790492e-02
 BV BND1      x_5_14  
 UP BND1      w_5_14    4.1955247735790492e-02
 BV BND1      x_5_15  
 UP BND1      w_5_15    4.1955247735790492e-02
 BV BND1      x_5_16  
 UP BND1      w_5_16    4.1955247735790492e-02
 UP BND1      rho_5     1
 BV BND1      x_32_0  
 UP BND1      w_32_0    4.1955247735790492e-02
 BV BND1      x_32_1  
 UP BND1      w_32_1    4.1955247735790492e-02
 BV BND1      x_32_2  
 UP BND1      w_32_2    4.1955247735790492e-02
 BV BND1      x_32_3  
 UP BND1      w_32_3    4.1955247735790492e-02
 BV BND1      x_32_4  
 UP BND1      w_32_4    4.1955247735790492e-02
 BV BND1      x_32_5  
 UP BND1      w_32_5    4.1955247735790492e-02
 BV BND1      x_32_6  
 UP BND1      w_32_6    4.1955247735790492e-02
 BV BND1      x_32_7  
 UP BND1      w_32_7    4.1955247735790492e-02
 BV BND1      x_32_8  
 UP BND1      w_32_8    4.1955247735790492e-02
 BV BND1      x_32_9  
 UP BND1      w_32_9    4.1955247735790492e-02
 BV BND1      x_32_10 
 UP BND1      w_32_10   4.1955247735790492e-02
 BV BND1      x_32_11 
 UP BND1      w_32_11   4.1955247735790492e-02
 BV BND1      x_32_12 
 UP BND1      w_32_12   4.1955247735790492e-02
 UP BND1      rho_32    1
 BV BND1      x_3_0   
 UP BND1      w_3_0     4.1955247735790492e-02
 BV BND1      x_3_1   
 UP BND1      w_3_1     4.1955247735790492e-02
 BV BND1      x_3_2   
 UP BND1      w_3_2     4.1955247735790492e-02
 BV BND1      x_3_3   
 UP BND1      w_3_3     4.1955247735790492e-02
 BV BND1      x_3_4   
 UP BND1      w_3_4     4.1955247735790492e-02
 BV BND1      x_3_5   
 UP BND1      w_3_5     4.1955247735790492e-02
 BV BND1      x_3_6   
 UP BND1      w_3_6     4.1955247735790492e-02
 BV BND1      x_3_7   
 UP BND1      w_3_7     4.1955247735790492e-02
 BV BND1      x_3_8   
 UP BND1      w_3_8     4.1955247735790492e-02
 BV BND1      x_3_9   
 UP BND1      w_3_9     4.1955247735790492e-02
 BV BND1      x_3_10  
 UP BND1      w_3_10    4.1955247735790492e-02
 BV BND1      x_3_11  
 UP BND1      w_3_11    4.1955247735790492e-02
 BV BND1      x_3_12  
 UP BND1      w_3_12    4.1955247735790492e-02
 BV BND1      x_3_13  
 UP BND1      w_3_13    4.1955247735790492e-02
 BV BND1      x_3_14  
 UP BND1      w_3_14    4.1955247735790492e-02
 BV BND1      x_3_15  
 UP BND1      w_3_15    4.1955247735790492e-02
 BV BND1      x_3_16  
 UP BND1      w_3_16    4.1955247735790492e-02
 BV BND1      x_3_17  
 UP BND1      w_3_17    4.1955247735790492e-02
 UP BND1      rho_3     1
 UP BND1      a_18_22   1
 UP BND1      a_18_31   1
 UP BND1      a_18_14   1
 UP BND1      a_18_16   1
 UP BND1      a_18_5    1
 UP BND1      a_18_32   1
 UP BND1      a_18_3    1
 UP BND1      a_22_31   1
 UP BND1      a_22_14   1
 UP BND1      a_22_16   1
 UP BND1      a_22_5    1
 UP BND1      a_22_32   1
 UP BND1      a_22_3    1
 UP BND1      a_31_14   1
 UP BND1      a_31_16   1
 UP BND1      a_31_5    1
 UP BND1      a_31_32   1
 UP BND1      a_31_3    1
 UP BND1      a_14_16   1
 UP BND1      a_14_5    1
 UP BND1      a_14_32   1
 UP BND1      a_14_3    1
 UP BND1      a_16_5    1
 UP BND1      a_16_32   1
 UP BND1      a_16_3    1
 UP BND1      a_5_32    1
 UP BND1      a_5_3     1
 UP BND1      a_32_3    1
 BV BND1      service_0_18_0
 BV BND1      service_0_18_1
 BV BND1      service_0_18_2
 BV BND1      service_0_18_3
 BV BND1      service_0_18_4
 BV BND1      service_0_18_5
 BV BND1      service_0_18_6
 BV BND1      service_0_18_7
 BV BND1      service_0_18_8
 BV BND1      service_0_18_9
 BV BND1      service_0_18_10
 BV BND1      service_0_18_11
 BV BND1      service_0_18_13
 BV BND1      service_0_18_14
 BV BND1      service_0_18_15
 BV BND1      service_0_18_16
 BV BND1      service_0_18_17
 BV BND1      service_1_18_0
 BV BND1      service_1_18_1
 BV BND1      service_1_18_2
 BV BND1      service_1_18_3
 BV BND1      service_1_18_4
 BV BND1      service_1_18_5
 BV BND1      service_1_18_6
 BV BND1      service_1_18_7
 BV BND1      service_1_18_8
 BV BND1      service_1_18_9
 BV BND1      service_1_18_10
 BV BND1      service_1_18_11
 BV BND1      service_1_18_13
 BV BND1      service_1_18_14
 BV BND1      service_1_18_15
 BV BND1      service_1_18_16
 BV BND1      service_1_18_17
 BV BND1      service_2_18_0
 BV BND1      service_2_18_1
 BV BND1      service_2_18_2
 BV BND1      service_2_18_3
 BV BND1      service_2_18_4
 BV BND1      service_2_18_5
 BV BND1      service_2_18_6
 BV BND1      service_2_18_7
 BV BND1      service_2_18_8
 BV BND1      service_2_18_9
 BV BND1      service_2_18_10
 BV BND1      service_2_18_11
 BV BND1      service_2_18_13
 BV BND1      service_2_18_14
 BV BND1      service_2_18_15
 BV BND1      service_2_18_16
 BV BND1      service_2_18_17
 BV BND1      service_0_22_0
 BV BND1      service_0_22_1
 BV BND1      service_0_22_2
 BV BND1      service_0_22_3
 BV BND1      service_0_22_4
 BV BND1      service_0_22_5
 BV BND1      service_0_22_6
 BV BND1      service_0_22_7
 BV BND1      service_0_22_9
 BV BND1      service_0_22_10
 BV BND1      service_0_22_11
 BV BND1      service_0_22_12
 BV BND1      service_1_22_0
 BV BND1      service_1_22_1
 BV BND1      service_1_22_2
 BV BND1      service_1_22_3
 BV BND1      service_1_22_4
 BV BND1      service_1_22_5
 BV BND1      service_1_22_6
 BV BND1      service_1_22_7
 BV BND1      service_1_22_9
 BV BND1      service_1_22_10
 BV BND1      service_1_22_11
 BV BND1      service_1_22_12
 BV BND1      service_2_22_0
 BV BND1      service_2_22_1
 BV BND1      service_2_22_2
 BV BND1      service_2_22_3
 BV BND1      service_2_22_4
 BV BND1      service_2_22_5
 BV BND1      service_2_22_6
 BV BND1      service_2_22_7
 BV BND1      service_2_22_9
 BV BND1      service_2_22_10
 BV BND1      service_2_22_11
 BV BND1      service_2_22_12
 BV BND1      service_0_31_0
 BV BND1      service_0_31_1
 BV BND1      service_0_31_3
 BV BND1      service_0_31_4
 BV BND1      service_0_31_5
 BV BND1      service_0_31_6
 BV BND1      service_0_31_7
 BV BND1      service_0_31_8
 BV BND1      service_0_31_9
 BV BND1      service_0_31_10
 BV BND1      service_0_31_11
 BV BND1      service_0_31_12
 BV BND1      service_1_31_0
 BV BND1      service_1_31_1
 BV BND1      service_1_31_3
 BV BND1      service_1_31_4
 BV BND1      service_1_31_5
 BV BND1      service_1_31_6
 BV BND1      service_1_31_7
 BV BND1      service_1_31_8
 BV BND1      service_1_31_9
 BV BND1      service_1_31_10
 BV BND1      service_1_31_11
 BV BND1      service_1_31_12
 BV BND1      service_2_31_0
 BV BND1      service_2_31_1
 BV BND1      service_2_31_3
 BV BND1      service_2_31_4
 BV BND1      service_2_31_5
 BV BND1      service_2_31_6
 BV BND1      service_2_31_7
 BV BND1      service_2_31_8
 BV BND1      service_2_31_9
 BV BND1      service_2_31_10
 BV BND1      service_2_31_11
 BV BND1      service_2_31_12
 BV BND1      service_0_14_0
 BV BND1      service_0_14_1
 BV BND1      service_0_14_3
 BV BND1      service_0_14_4
 BV BND1      service_0_14_5
 BV BND1      service_0_14_6
 BV BND1      service_0_14_7
 BV BND1      service_0_14_8
 BV BND1      service_0_14_9
 BV BND1      service_0_14_10
 BV BND1      service_0_14_11
 BV BND1      service_0_14_12
 BV BND1      service_0_14_13
 BV BND1      service_0_14_14
 BV BND1      service_0_14_15
 BV BND1      service_1_14_0
 BV BND1      service_1_14_1
 BV BND1      service_1_14_3
 BV BND1      service_1_14_4
 BV BND1      service_1_14_5
 BV BND1      service_1_14_6
 BV BND1      service_1_14_7
 BV BND1      service_1_14_8
 BV BND1      service_1_14_9
 BV BND1      service_1_14_10
 BV BND1      service_1_14_11
 BV BND1      service_1_14_12
 BV BND1      service_1_14_13
 BV BND1      service_1_14_14
 BV BND1      service_1_14_15
 BV BND1      service_2_14_0
 BV BND1      service_2_14_1
 BV BND1      service_2_14_3
 BV BND1      service_2_14_4
 BV BND1      service_2_14_5
 BV BND1      service_2_14_6
 BV BND1      service_2_14_7
 BV BND1      service_2_14_8
 BV BND1      service_2_14_9
 BV BND1      service_2_14_10
 BV BND1      service_2_14_11
 BV BND1      service_2_14_12
 BV BND1      service_2_14_13
 BV BND1      service_2_14_14
 BV BND1      service_2_14_15
 BV BND1      service_0_16_0
 BV BND1      service_0_16_2
 BV BND1      service_0_16_3
 BV BND1      service_0_16_4
 BV BND1      service_0_16_5
 BV BND1      service_0_16_6
 BV BND1      service_0_16_7
 BV BND1      service_0_16_8
 BV BND1      service_0_16_9
 BV BND1      service_0_16_10
 BV BND1      service_0_16_11
 BV BND1      service_0_16_12
 BV BND1      service_1_16_0
 BV BND1      service_1_16_2
 BV BND1      service_1_16_3
 BV BND1      service_1_16_4
 BV BND1      service_1_16_5
 BV BND1      service_1_16_6
 BV BND1      service_1_16_7
 BV BND1      service_1_16_8
 BV BND1      service_1_16_9
 BV BND1      service_1_16_10
 BV BND1      service_1_16_11
 BV BND1      service_1_16_12
 BV BND1      service_2_16_0
 BV BND1      service_2_16_2
 BV BND1      service_2_16_3
 BV BND1      service_2_16_4
 BV BND1      service_2_16_5
 BV BND1      service_2_16_6
 BV BND1      service_2_16_7
 BV BND1      service_2_16_8
 BV BND1      service_2_16_9
 BV BND1      service_2_16_10
 BV BND1      service_2_16_11
 BV BND1      service_2_16_12
 BV BND1      service_0_5_0
 BV BND1      service_0_5_1
 BV BND1      service_0_5_3
 BV BND1      service_0_5_4
 BV BND1      service_0_5_5
 BV BND1      service_0_5_6
 BV BND1      service_0_5_7
 BV BND1      service_0_5_8
 BV BND1      service_0_5_9
 BV BND1      service_0_5_10
 BV BND1      service_0_5_11
 BV BND1      service_0_5_12
 BV BND1      service_0_5_13
 BV BND1      service_0_5_14
 BV BND1      service_0_5_15
 BV BND1      service_0_5_16
 BV BND1      service_1_5_0
 BV BND1      service_1_5_1
 BV BND1      service_1_5_3
 BV BND1      service_1_5_4
 BV BND1      service_1_5_5
 BV BND1      service_1_5_6
 BV BND1      service_1_5_7
 BV BND1      service_1_5_8
 BV BND1      service_1_5_9
 BV BND1      service_1_5_10
 BV BND1      service_1_5_11
 BV BND1      service_1_5_12
 BV BND1      service_1_5_13
 BV BND1      service_1_5_14
 BV BND1      service_1_5_15
 BV BND1      service_1_5_16
 BV BND1      service_2_5_0
 BV BND1      service_2_5_1
 BV BND1      service_2_5_3
 BV BND1      service_2_5_4
 BV BND1      service_2_5_5
 BV BND1      service_2_5_6
 BV BND1      service_2_5_7
 BV BND1      service_2_5_8
 BV BND1      service_2_5_9
 BV BND1      service_2_5_10
 BV BND1      service_2_5_11
 BV BND1      service_2_5_12
 BV BND1      service_2_5_13
 BV BND1      service_2_5_14
 BV BND1      service_2_5_15
 BV BND1      service_2_5_16
 BV BND1      service_0_32_1
 BV BND1      service_0_32_2
 BV BND1      service_0_32_3
 BV BND1      service_0_32_4
 BV BND1      service_0_32_5
 BV BND1      service_0_32_6
 BV BND1      service_0_32_7
 BV BND1      service_0_32_8
 BV BND1      service_0_32_9
 BV BND1      service_0_32_10
 BV BND1      service_0_32_11
 BV BND1      service_0_32_12
 BV BND1      service_1_32_1
 BV BND1      service_1_32_2
 BV BND1      service_1_32_3
 BV BND1      service_1_32_4
 BV BND1      service_1_32_5
 BV BND1      service_1_32_6
 BV BND1      service_1_32_7
 BV BND1      service_1_32_8
 BV BND1      service_1_32_9
 BV BND1      service_1_32_10
 BV BND1      service_1_32_11
 BV BND1      service_1_32_12
 BV BND1      service_2_32_1
 BV BND1      service_2_32_2
 BV BND1      service_2_32_3
 BV BND1      service_2_32_4
 BV BND1      service_2_32_5
 BV BND1      service_2_32_6
 BV BND1      service_2_32_7
 BV BND1      service_2_32_8
 BV BND1      service_2_32_9
 BV BND1      service_2_32_10
 BV BND1      service_2_32_11
 BV BND1      service_2_32_12
 BV BND1      service_0_3_0
 BV BND1      service_0_3_1
 BV BND1      service_0_3_2
 BV BND1      service_0_3_3
 BV BND1      service_0_3_4
 BV BND1      service_0_3_5
 BV BND1      service_0_3_6
 BV BND1      service_0_3_7
 BV BND1      service_0_3_8
 BV BND1      service_0_3_9
 BV BND1      service_0_3_10
 BV BND1      service_0_3_11
 BV BND1      service_0_3_13
 BV BND1      service_0_3_14
 BV BND1      service_0_3_15
 BV BND1      service_0_3_16
 BV BND1      service_0_3_17
 BV BND1      service_1_3_0
 BV BND1      service_1_3_1
 BV BND1      service_1_3_2
 BV BND1      service_1_3_3
 BV BND1      service_1_3_4
 BV BND1      service_1_3_5
 BV BND1      service_1_3_6
 BV BND1      service_1_3_7
 BV BND1      service_1_3_8
 BV BND1      service_1_3_9
 BV BND1      service_1_3_10
 BV BND1      service_1_3_11
 BV BND1      service_1_3_13
 BV BND1      service_1_3_14
 BV BND1      service_1_3_15
 BV BND1      service_1_3_16
 BV BND1      service_1_3_17
 BV BND1      service_2_3_0
 BV BND1      service_2_3_1
 BV BND1      service_2_3_2
 BV BND1      service_2_3_3
 BV BND1      service_2_3_4
 BV BND1      service_2_3_5
 BV BND1      service_2_3_6
 BV BND1      service_2_3_7
 BV BND1      service_2_3_8
 BV BND1      service_2_3_9
 BV BND1      service_2_3_10
 BV BND1      service_2_3_11
 BV BND1      service_2_3_13
 BV BND1      service_2_3_14
 BV BND1      service_2_3_15
 BV BND1      service_2_3_16
 BV BND1      service_2_3_17
 FX BND1      visit_0_1  1
 UP BND1      order_0_1  14
 FX BND1      visit_0_2  1
 UP BND1      order_0_2  14
 FX BND1      visit_0_3  1
 UP BND1      order_0_3  14
 FX BND1      visit_0_4  1
 UP BND1      order_0_4  14
 FX BND1      visit_0_5  1
 UP BND1      order_0_5  14
 FX BND1      visit_0_6  1
 UP BND1      order_0_6  14
 UP BND1      visit_0_17  1
 UP BND1      order_0_17  14
 UP BND1      visit_0_18  1
 UP BND1      order_0_18  14
 UP BND1      visit_0_19  1
 UP BND1      order_0_19  14
 UP BND1      visit_0_20  1
 UP BND1      order_0_20  14
 UP BND1      visit_0_21  1
 UP BND1      order_0_21  14
 UP BND1      visit_0_22  1
 UP BND1      order_0_22  14
 UP BND1      visit_0_23  1
 UP BND1      order_0_23  14
 UP BND1      visit_0_24  1
 UP BND1      order_0_24  14
 BV BND1      arc_0_0_0
 FX BND1      load_0_0_0  0
 BV BND1      arc_0_0_1
 FX BND1      load_0_0_1  0
 BV BND1      arc_0_0_2
 FX BND1      load_0_0_2  0
 BV BND1      arc_0_0_3
 FX BND1      load_0_0_3  0
 BV BND1      arc_0_0_4
 FX BND1      load_0_0_4  0
 BV BND1      arc_0_0_5
 FX BND1      load_0_0_5  0
 BV BND1      arc_0_0_6
 FX BND1      load_0_0_6  0
 BV BND1      arc_0_0_17
 FX BND1      load_0_0_17  0
 BV BND1      arc_0_0_18
 FX BND1      load_0_0_18  0
 BV BND1      arc_0_0_19
 FX BND1      load_0_0_19  0
 BV BND1      arc_0_0_20
 FX BND1      load_0_0_20  0
 BV BND1      arc_0_0_21
 FX BND1      load_0_0_21  0
 BV BND1      arc_0_0_22
 FX BND1      load_0_0_22  0
 BV BND1      arc_0_0_23
 FX BND1      load_0_0_23  0
 BV BND1      arc_0_0_24
 FX BND1      load_0_0_24  0
 BV BND1      arc_0_1_0
 UP BND1      load_0_1_0  20
 BV BND1      arc_0_1_2
 UP BND1      load_0_1_2  20
 BV BND1      arc_0_1_3
 UP BND1      load_0_1_3  20
 BV BND1      arc_0_1_4
 UP BND1      load_0_1_4  20
 BV BND1      arc_0_1_5
 UP BND1      load_0_1_5  20
 BV BND1      arc_0_1_6
 UP BND1      load_0_1_6  20
 BV BND1      arc_0_1_17
 UP BND1      load_0_1_17  20
 BV BND1      arc_0_1_18
 UP BND1      load_0_1_18  20
 BV BND1      arc_0_1_19
 UP BND1      load_0_1_19  20
 BV BND1      arc_0_1_20
 UP BND1      load_0_1_20  20
 BV BND1      arc_0_1_21
 UP BND1      load_0_1_21  20
 BV BND1      arc_0_1_22
 UP BND1      load_0_1_22  20
 BV BND1      arc_0_1_23
 UP BND1      load_0_1_23  20
 BV BND1      arc_0_1_24
 UP BND1      load_0_1_24  20
 BV BND1      arc_0_2_0
 UP BND1      load_0_2_0  20
 BV BND1      arc_0_2_1
 UP BND1      load_0_2_1  20
 BV BND1      arc_0_2_3
 UP BND1      load_0_2_3  20
 BV BND1      arc_0_2_4
 UP BND1      load_0_2_4  20
 BV BND1      arc_0_2_5
 UP BND1      load_0_2_5  20
 BV BND1      arc_0_2_6
 UP BND1      load_0_2_6  20
 BV BND1      arc_0_2_17
 UP BND1      load_0_2_17  20
 BV BND1      arc_0_2_18
 UP BND1      load_0_2_18  20
 BV BND1      arc_0_2_19
 UP BND1      load_0_2_19  20
 BV BND1      arc_0_2_20
 UP BND1      load_0_2_20  20
 BV BND1      arc_0_2_21
 UP BND1      load_0_2_21  20
 BV BND1      arc_0_2_22
 UP BND1      load_0_2_22  20
 BV BND1      arc_0_2_23
 UP BND1      load_0_2_23  20
 BV BND1      arc_0_2_24
 UP BND1      load_0_2_24  20
 BV BND1      arc_0_3_0
 UP BND1      load_0_3_0  20
 BV BND1      arc_0_3_1
 UP BND1      load_0_3_1  20
 BV BND1      arc_0_3_2
 UP BND1      load_0_3_2  20
 BV BND1      arc_0_3_4
 UP BND1      load_0_3_4  20
 BV BND1      arc_0_3_5
 UP BND1      load_0_3_5  20
 BV BND1      arc_0_3_6
 UP BND1      load_0_3_6  20
 BV BND1      arc_0_3_17
 UP BND1      load_0_3_17  20
 BV BND1      arc_0_3_18
 UP BND1      load_0_3_18  20
 BV BND1      arc_0_3_19
 UP BND1      load_0_3_19  20
 BV BND1      arc_0_3_20
 UP BND1      load_0_3_20  20
 BV BND1      arc_0_3_21
 UP BND1      load_0_3_21  20
 BV BND1      arc_0_3_22
 UP BND1      load_0_3_22  20
 BV BND1      arc_0_3_23
 UP BND1      load_0_3_23  20
 BV BND1      arc_0_3_24
 UP BND1      load_0_3_24  20
 BV BND1      arc_0_4_0
 UP BND1      load_0_4_0  20
 BV BND1      arc_0_4_1
 UP BND1      load_0_4_1  20
 BV BND1      arc_0_4_2
 UP BND1      load_0_4_2  20
 BV BND1      arc_0_4_3
 UP BND1      load_0_4_3  20
 BV BND1      arc_0_4_5
 UP BND1      load_0_4_5  20
 BV BND1      arc_0_4_6
 UP BND1      load_0_4_6  20
 BV BND1      arc_0_4_17
 UP BND1      load_0_4_17  20
 BV BND1      arc_0_4_18
 UP BND1      load_0_4_18  20
 BV BND1      arc_0_4_19
 UP BND1      load_0_4_19  20
 BV BND1      arc_0_4_20
 UP BND1      load_0_4_20  20
 BV BND1      arc_0_4_21
 UP BND1      load_0_4_21  20
 BV BND1      arc_0_4_22
 UP BND1      load_0_4_22  20
 BV BND1      arc_0_4_23
 UP BND1      load_0_4_23  20
 BV BND1      arc_0_4_24
 UP BND1      load_0_4_24  20
 BV BND1      arc_0_5_0
 UP BND1      load_0_5_0  20
 BV BND1      arc_0_5_1
 UP BND1      load_0_5_1  20
 BV BND1      arc_0_5_2
 UP BND1      load_0_5_2  20
 BV BND1      arc_0_5_3
 UP BND1      load_0_5_3  20
 BV BND1      arc_0_5_4
 UP BND1      load_0_5_4  20
 BV BND1      arc_0_5_6
 UP BND1      load_0_5_6  20
 BV BND1      arc_0_5_17
 UP BND1      load_0_5_17  20
 BV BND1      arc_0_5_18
 UP BND1      load_0_5_18  20
 BV BND1      arc_0_5_19
 UP BND1      load_0_5_19  20
 BV BND1      arc_0_5_20
 UP BND1      load_0_5_20  20
 BV BND1      arc_0_5_21
 UP BND1      load_0_5_21  20
 BV BND1      arc_0_5_22
 UP BND1      load_0_5_22  20
 BV BND1      arc_0_5_23
 UP BND1      load_0_5_23  20
 BV BND1      arc_0_5_24
 UP BND1      load_0_5_24  20
 BV BND1      arc_0_6_0
 UP BND1      load_0_6_0  20
 BV BND1      arc_0_6_1
 UP BND1      load_0_6_1  20
 BV BND1      arc_0_6_2
 UP BND1      load_0_6_2  20
 BV BND1      arc_0_6_3
 UP BND1      load_0_6_3  20
 BV BND1      arc_0_6_4
 UP BND1      load_0_6_4  20
 BV BND1      arc_0_6_5
 UP BND1      load_0_6_5  20
 BV BND1      arc_0_6_17
 UP BND1      load_0_6_17  20
 BV BND1      arc_0_6_18
 UP BND1      load_0_6_18  20
 BV BND1      arc_0_6_19
 UP BND1      load_0_6_19  20
 BV BND1      arc_0_6_20
 UP BND1      load_0_6_20  20
 BV BND1      arc_0_6_21
 UP BND1      load_0_6_21  20
 BV BND1      arc_0_6_22
 UP BND1      load_0_6_22  20
 BV BND1      arc_0_6_23
 UP BND1      load_0_6_23  20
 BV BND1      arc_0_6_24
 UP BND1      load_0_6_24  20
 BV BND1      arc_0_17_0
 UP BND1      load_0_17_0  20
 BV BND1      arc_0_17_1
 UP BND1      load_0_17_1  20
 BV BND1      arc_0_17_2
 UP BND1      load_0_17_2  20
 BV BND1      arc_0_17_3
 UP BND1      load_0_17_3  20
 BV BND1      arc_0_17_4
 UP BND1      load_0_17_4  20
 BV BND1      arc_0_17_5
 UP BND1      load_0_17_5  20
 BV BND1      arc_0_17_6
 UP BND1      load_0_17_6  20
 BV BND1      arc_0_17_18
 UP BND1      load_0_17_18  20
 BV BND1      arc_0_17_19
 UP BND1      load_0_17_19  20
 BV BND1      arc_0_17_20
 UP BND1      load_0_17_20  20
 BV BND1      arc_0_17_21
 UP BND1      load_0_17_21  20
 BV BND1      arc_0_17_22
 UP BND1      load_0_17_22  20
 BV BND1      arc_0_17_23
 UP BND1      load_0_17_23  20
 BV BND1      arc_0_17_24
 UP BND1      load_0_17_24  20
 BV BND1      arc_0_18_0
 UP BND1      load_0_18_0  20
 BV BND1      arc_0_18_1
 UP BND1      load_0_18_1  20
 BV BND1      arc_0_18_2
 UP BND1      load_0_18_2  20
 BV BND1      arc_0_18_3
 UP BND1      load_0_18_3  20
 BV BND1      arc_0_18_4
 UP BND1      load_0_18_4  20
 BV BND1      arc_0_18_5
 UP BND1      load_0_18_5  20
 BV BND1      arc_0_18_6
 UP BND1      load_0_18_6  20
 BV BND1      arc_0_18_17
 UP BND1      load_0_18_17  20
 BV BND1      arc_0_18_19
 UP BND1      load_0_18_19  20
 BV BND1      arc_0_18_20
 UP BND1      load_0_18_20  20
 BV BND1      arc_0_18_21
 UP BND1      load_0_18_21  20
 BV BND1      arc_0_18_22
 UP BND1      load_0_18_22  20
 BV BND1      arc_0_18_23
 UP BND1      load_0_18_23  20
 BV BND1      arc_0_18_24
 UP BND1      load_0_18_24  20
 BV BND1      arc_0_19_0
 UP BND1      load_0_19_0  20
 BV BND1      arc_0_19_1
 UP BND1      load_0_19_1  20
 BV BND1      arc_0_19_2
 UP BND1      load_0_19_2  20
 BV BND1      arc_0_19_3
 UP BND1      load_0_19_3  20
 BV BND1      arc_0_19_4
 UP BND1      load_0_19_4  20
 BV BND1      arc_0_19_5
 UP BND1      load_0_19_5  20
 BV BND1      arc_0_19_6
 UP BND1      load_0_19_6  20
 BV BND1      arc_0_19_17
 UP BND1      load_0_19_17  20
 BV BND1      arc_0_19_18
 UP BND1      load_0_19_18  20
 BV BND1      arc_0_19_20
 UP BND1      load_0_19_20  20
 BV BND1      arc_0_19_21
 UP BND1      load_0_19_21  20
 BV BND1      arc_0_19_22
 UP BND1      load_0_19_22  20
 BV BND1      arc_0_19_23
 UP BND1      load_0_19_23  20
 BV BND1      arc_0_19_24
 UP BND1      load_0_19_24  20
 BV BND1      arc_0_20_0
 UP BND1      load_0_20_0  20
 BV BND1      arc_0_20_1
 UP BND1      load_0_20_1  20
 BV BND1      arc_0_20_2
 UP BND1      load_0_20_2  20
 BV BND1      arc_0_20_3
 UP BND1      load_0_20_3  20
 BV BND1      arc_0_20_4
 UP BND1      load_0_20_4  20
 BV BND1      arc_0_20_5
 UP BND1      load_0_20_5  20
 BV BND1      arc_0_20_6
 UP BND1      load_0_20_6  20
 BV BND1      arc_0_20_17
 UP BND1      load_0_20_17  20
 BV BND1      arc_0_20_18
 UP BND1      load_0_20_18  20
 BV BND1      arc_0_20_19
 UP BND1      load_0_20_19  20
 BV BND1      arc_0_20_21
 UP BND1      load_0_20_21  20
 BV BND1      arc_0_20_22
 UP BND1      load_0_20_22  20
 BV BND1      arc_0_20_23
 UP BND1      load_0_20_23  20
 BV BND1      arc_0_20_24
 UP BND1      load_0_20_24  20
 BV BND1      arc_0_21_0
 UP BND1      load_0_21_0  20
 BV BND1      arc_0_21_1
 UP BND1      load_0_21_1  20
 BV BND1      arc_0_21_2
 UP BND1      load_0_21_2  20
 BV BND1      arc_0_21_3
 UP BND1      load_0_21_3  20
 BV BND1      arc_0_21_4
 UP BND1      load_0_21_4  20
 BV BND1      arc_0_21_5
 UP BND1      load_0_21_5  20
 BV BND1      arc_0_21_6
 UP BND1      load_0_21_6  20
 BV BND1      arc_0_21_17
 UP BND1      load_0_21_17  20
 BV BND1      arc_0_21_18
 UP BND1      load_0_21_18  20
 BV BND1      arc_0_21_19
 UP BND1      load_0_21_19  20
 BV BND1      arc_0_21_20
 UP BND1      load_0_21_20  20
 BV BND1      arc_0_21_22
 UP BND1      load_0_21_22  20
 BV BND1      arc_0_21_23
 UP BND1      load_0_21_23  20
 BV BND1      arc_0_21_24
 UP BND1      load_0_21_24  20
 BV BND1      arc_0_22_0
 UP BND1      load_0_22_0  20
 BV BND1      arc_0_22_1
 UP BND1      load_0_22_1  20
 BV BND1      arc_0_22_2
 UP BND1      load_0_22_2  20
 BV BND1      arc_0_22_3
 UP BND1      load_0_22_3  20
 BV BND1      arc_0_22_4
 UP BND1      load_0_22_4  20
 BV BND1      arc_0_22_5
 UP BND1      load_0_22_5  20
 BV BND1      arc_0_22_6
 UP BND1      load_0_22_6  20
 BV BND1      arc_0_22_17
 UP BND1      load_0_22_17  20
 BV BND1      arc_0_22_18
 UP BND1      load_0_22_18  20
 BV BND1      arc_0_22_19
 UP BND1      load_0_22_19  20
 BV BND1      arc_0_22_20
 UP BND1      load_0_22_20  20
 BV BND1      arc_0_22_21
 UP BND1      load_0_22_21  20
 BV BND1      arc_0_22_23
 UP BND1      load_0_22_23  20
 BV BND1      arc_0_22_24
 UP BND1      load_0_22_24  20
 BV BND1      arc_0_23_0
 UP BND1      load_0_23_0  20
 BV BND1      arc_0_23_1
 UP BND1      load_0_23_1  20
 BV BND1      arc_0_23_2
 UP BND1      load_0_23_2  20
 BV BND1      arc_0_23_3
 UP BND1      load_0_23_3  20
 BV BND1      arc_0_23_4
 UP BND1      load_0_23_4  20
 BV BND1      arc_0_23_5
 UP BND1      load_0_23_5  20
 BV BND1      arc_0_23_6
 UP BND1      load_0_23_6  20
 BV BND1      arc_0_23_17
 UP BND1      load_0_23_17  20
 BV BND1      arc_0_23_18
 UP BND1      load_0_23_18  20
 BV BND1      arc_0_23_19
 UP BND1      load_0_23_19  20
 BV BND1      arc_0_23_20
 UP BND1      load_0_23_20  20
 BV BND1      arc_0_23_21
 UP BND1      load_0_23_21  20
 BV BND1      arc_0_23_22
 UP BND1      load_0_23_22  20
 BV BND1      arc_0_23_24
 UP BND1      load_0_23_24  20
 BV BND1      arc_0_24_0
 UP BND1      load_0_24_0  20
 BV BND1      arc_0_24_1
 UP BND1      load_0_24_1  20
 BV BND1      arc_0_24_2
 UP BND1      load_0_24_2  20
 BV BND1      arc_0_24_3
 UP BND1      load_0_24_3  20
 BV BND1      arc_0_24_4
 UP BND1      load_0_24_4  20
 BV BND1      arc_0_24_5
 UP BND1      load_0_24_5  20
 BV BND1      arc_0_24_6
 UP BND1      load_0_24_6  20
 BV BND1      arc_0_24_17
 UP BND1      load_0_24_17  20
 BV BND1      arc_0_24_18
 UP BND1      load_0_24_18  20
 BV BND1      arc_0_24_19
 UP BND1      load_0_24_19  20
 BV BND1      arc_0_24_20
 UP BND1      load_0_24_20  20
 BV BND1      arc_0_24_21
 UP BND1      load_0_24_21  20
 BV BND1      arc_0_24_22
 UP BND1      load_0_24_22  20
 BV BND1      arc_0_24_23
 UP BND1      load_0_24_23  20
 FX BND1      visit_1_7  1
 UP BND1      order_1_7  13
 FX BND1      visit_1_8  1
 UP BND1      order_1_8  13
 FX BND1      visit_1_9  1
 UP BND1      order_1_9  13
 FX BND1      visit_1_10  1
 UP BND1      order_1_10  13
 FX BND1      visit_1_11  1
 UP BND1      order_1_11  13
 UP BND1      visit_1_17  1
 UP BND1      order_1_17  13
 UP BND1      visit_1_18  1
 UP BND1      order_1_18  13
 UP BND1      visit_1_19  1
 UP BND1      order_1_19  13
 UP BND1      visit_1_20  1
 UP BND1      order_1_20  13
 UP BND1      visit_1_21  1
 UP BND1      order_1_21  13
 UP BND1      visit_1_22  1
 UP BND1      order_1_22  13
 UP BND1      visit_1_23  1
 UP BND1      order_1_23  13
 UP BND1      visit_1_24  1
 UP BND1      order_1_24  13
 BV BND1      arc_1_0_0
 FX BND1      load_1_0_0  0
 BV BND1      arc_1_0_7
 FX BND1      load_1_0_7  0
 BV BND1      arc_1_0_8
 FX BND1      load_1_0_8  0
 BV BND1      arc_1_0_9
 FX BND1      load_1_0_9  0
 BV BND1      arc_1_0_10
 FX BND1      load_1_0_10  0
 BV BND1      arc_1_0_11
 FX BND1      load_1_0_11  0
 BV BND1      arc_1_0_17
 FX BND1      load_1_0_17  0
 BV BND1      arc_1_0_18
 FX BND1      load_1_0_18  0
 BV BND1      arc_1_0_19
 FX BND1      load_1_0_19  0
 BV BND1      arc_1_0_20
 FX BND1      load_1_0_20  0
 BV BND1      arc_1_0_21
 FX BND1      load_1_0_21  0
 BV BND1      arc_1_0_22
 FX BND1      load_1_0_22  0
 BV BND1      arc_1_0_23
 FX BND1      load_1_0_23  0
 BV BND1      arc_1_0_24
 FX BND1      load_1_0_24  0
 BV BND1      arc_1_7_0
 UP BND1      load_1_7_0  25
 BV BND1      arc_1_7_8
 UP BND1      load_1_7_8  25
 BV BND1      arc_1_7_9
 UP BND1      load_1_7_9  25
 BV BND1      arc_1_7_10
 UP BND1      load_1_7_10  25
 BV BND1      arc_1_7_11
 UP BND1      load_1_7_11  25
 BV BND1      arc_1_7_17
 UP BND1      load_1_7_17  25
 BV BND1      arc_1_7_18
 UP BND1      load_1_7_18  25
 BV BND1      arc_1_7_19
 UP BND1      load_1_7_19  25
 BV BND1      arc_1_7_20
 UP BND1      load_1_7_20  25
 BV BND1      arc_1_7_21
 UP BND1      load_1_7_21  25
 BV BND1      arc_1_7_22
 UP BND1      load_1_7_22  25
 BV BND1      arc_1_7_23
 UP BND1      load_1_7_23  25
 BV BND1      arc_1_7_24
 UP BND1      load_1_7_24  25
 BV BND1      arc_1_8_0
 UP BND1      load_1_8_0  25
 BV BND1      arc_1_8_7
 UP BND1      load_1_8_7  25
 BV BND1      arc_1_8_9
 UP BND1      load_1_8_9  25
 BV BND1      arc_1_8_10
 UP BND1      load_1_8_10  25
 BV BND1      arc_1_8_11
 UP BND1      load_1_8_11  25
 BV BND1      arc_1_8_17
 UP BND1      load_1_8_17  25
 BV BND1      arc_1_8_18
 UP BND1      load_1_8_18  25
 BV BND1      arc_1_8_19
 UP BND1      load_1_8_19  25
 BV BND1      arc_1_8_20
 UP BND1      load_1_8_20  25
 BV BND1      arc_1_8_21
 UP BND1      load_1_8_21  25
 BV BND1      arc_1_8_22
 UP BND1      load_1_8_22  25
 BV BND1      arc_1_8_23
 UP BND1      load_1_8_23  25
 BV BND1      arc_1_8_24
 UP BND1      load_1_8_24  25
 BV BND1      arc_1_9_0
 UP BND1      load_1_9_0  25
 BV BND1      arc_1_9_7
 UP BND1      load_1_9_7  25
 BV BND1      arc_1_9_8
 UP BND1      load_1_9_8  25
 BV BND1      arc_1_9_10
 UP BND1      load_1_9_10  25
 BV BND1      arc_1_9_11
 UP BND1      load_1_9_11  25
 BV BND1      arc_1_9_17
 UP BND1      load_1_9_17  25
 BV BND1      arc_1_9_18
 UP BND1      load_1_9_18  25
 BV BND1      arc_1_9_19
 UP BND1      load_1_9_19  25
 BV BND1      arc_1_9_20
 UP BND1      load_1_9_20  25
 BV BND1      arc_1_9_21
 UP BND1      load_1_9_21  25
 BV BND1      arc_1_9_22
 UP BND1      load_1_9_22  25
 BV BND1      arc_1_9_23
 UP BND1      load_1_9_23  25
 BV BND1      arc_1_9_24
 UP BND1      load_1_9_24  25
 BV BND1      arc_1_10_0
 UP BND1      load_1_10_0  25
 BV BND1      arc_1_10_7
 UP BND1      load_1_10_7  25
 BV BND1      arc_1_10_8
 UP BND1      load_1_10_8  25
 BV BND1      arc_1_10_9
 UP BND1      load_1_10_9  25
 BV BND1      arc_1_10_11
 UP BND1      load_1_10_11  25
 BV BND1      arc_1_10_17
 UP BND1      load_1_10_17  25
 BV BND1      arc_1_10_18
 UP BND1      load_1_10_18  25
 BV BND1      arc_1_10_19
 UP BND1      load_1_10_19  25
 BV BND1      arc_1_10_20
 UP BND1      load_1_10_20  25
 BV BND1      arc_1_10_21
 UP BND1      load_1_10_21  25
 BV BND1      arc_1_10_22
 UP BND1      load_1_10_22  25
 BV BND1      arc_1_10_23
 UP BND1      load_1_10_23  25
 BV BND1      arc_1_10_24
 UP BND1      load_1_10_24  25
 BV BND1      arc_1_11_0
 UP BND1      load_1_11_0  25
 BV BND1      arc_1_11_7
 UP BND1      load_1_11_7  25
 BV BND1      arc_1_11_8
 UP BND1      load_1_11_8  25
 BV BND1      arc_1_11_9
 UP BND1      load_1_11_9  25
 BV BND1      arc_1_11_10
 UP BND1      load_1_11_10  25
 BV BND1      arc_1_11_17
 UP BND1      load_1_11_17  25
 BV BND1      arc_1_11_18
 UP BND1      load_1_11_18  25
 BV BND1      arc_1_11_19
 UP BND1      load_1_11_19  25
 BV BND1      arc_1_11_20
 UP BND1      load_1_11_20  25
 BV BND1      arc_1_11_21
 UP BND1      load_1_11_21  25
 BV BND1      arc_1_11_22
 UP BND1      load_1_11_22  25
 BV BND1      arc_1_11_23
 UP BND1      load_1_11_23  25
 BV BND1      arc_1_11_24
 UP BND1      load_1_11_24  25
 BV BND1      arc_1_17_0
 UP BND1      load_1_17_0  25
 BV BND1      arc_1_17_7
 UP BND1      load_1_17_7  25
 BV BND1      arc_1_17_8
 UP BND1      load_1_17_8  25
 BV BND1      arc_1_17_9
 UP BND1      load_1_17_9  25
 BV BND1      arc_1_17_10
 UP BND1      load_1_17_10  25
 BV BND1      arc_1_17_11
 UP BND1      load_1_17_11  25
 BV BND1      arc_1_17_18
 UP BND1      load_1_17_18  25
 BV BND1      arc_1_17_19
 UP BND1      load_1_17_19  25
 BV BND1      arc_1_17_20
 UP BND1      load_1_17_20  25
 BV BND1      arc_1_17_21
 UP BND1      load_1_17_21  25
 BV BND1      arc_1_17_22
 UP BND1      load_1_17_22  25
 BV BND1      arc_1_17_23
 UP BND1      load_1_17_23  25
 BV BND1      arc_1_17_24
 UP BND1      load_1_17_24  25
 BV BND1      arc_1_18_0
 UP BND1      load_1_18_0  25
 BV BND1      arc_1_18_7
 UP BND1      load_1_18_7  25
 BV BND1      arc_1_18_8
 UP BND1      load_1_18_8  25
 BV BND1      arc_1_18_9
 UP BND1      load_1_18_9  25
 BV BND1      arc_1_18_10
 UP BND1      load_1_18_10  25
 BV BND1      arc_1_18_11
 UP BND1      load_1_18_11  25
 BV BND1      arc_1_18_17
 UP BND1      load_1_18_17  25
 BV BND1      arc_1_18_19
 UP BND1      load_1_18_19  25
 BV BND1      arc_1_18_20
 UP BND1      load_1_18_20  25
 BV BND1      arc_1_18_21
 UP BND1      load_1_18_21  25
 BV BND1      arc_1_18_22
 UP BND1      load_1_18_22  25
 BV BND1      arc_1_18_23
 UP BND1      load_1_18_23  25
 BV BND1      arc_1_18_24
 UP BND1      load_1_18_24  25
 BV BND1      arc_1_19_0
 UP BND1      load_1_19_0  25
 BV BND1      arc_1_19_7
 UP BND1      load_1_19_7  25
 BV BND1      arc_1_19_8
 UP BND1      load_1_19_8  25
 BV BND1      arc_1_19_9
 UP BND1      load_1_19_9  25
 BV BND1      arc_1_19_10
 UP BND1      load_1_19_10  25
 BV BND1      arc_1_19_11
 UP BND1      load_1_19_11  25
 BV BND1      arc_1_19_17
 UP BND1      load_1_19_17  25
 BV BND1      arc_1_19_18
 UP BND1      load_1_19_18  25
 BV BND1      arc_1_19_20
 UP BND1      load_1_19_20  25
 BV BND1      arc_1_19_21
 UP BND1      load_1_19_21  25
 BV BND1      arc_1_19_22
 UP BND1      load_1_19_22  25
 BV BND1      arc_1_19_23
 UP BND1      load_1_19_23  25
 BV BND1      arc_1_19_24
 UP BND1      load_1_19_24  25
 BV BND1      arc_1_20_0
 UP BND1      load_1_20_0  25
 BV BND1      arc_1_20_7
 UP BND1      load_1_20_7  25
 BV BND1      arc_1_20_8
 UP BND1      load_1_20_8  25
 BV BND1      arc_1_20_9
 UP BND1      load_1_20_9  25
 BV BND1      arc_1_20_10
 UP BND1      load_1_20_10  25
 BV BND1      arc_1_20_11
 UP BND1      load_1_20_11  25
 BV BND1      arc_1_20_17
 UP BND1      load_1_20_17  25
 BV BND1      arc_1_20_18
 UP BND1      load_1_20_18  25
 BV BND1      arc_1_20_19
 UP BND1      load_1_20_19  25
 BV BND1      arc_1_20_21
 UP BND1      load_1_20_21  25
 BV BND1      arc_1_20_22
 UP BND1      load_1_20_22  25
 BV BND1      arc_1_20_23
 UP BND1      load_1_20_23  25
 BV BND1      arc_1_20_24
 UP BND1      load_1_20_24  25
 BV BND1      arc_1_21_0
 UP BND1      load_1_21_0  25
 BV BND1      arc_1_21_7
 UP BND1      load_1_21_7  25
 BV BND1      arc_1_21_8
 UP BND1      load_1_21_8  25
 BV BND1      arc_1_21_9
 UP BND1      load_1_21_9  25
 BV BND1      arc_1_21_10
 UP BND1      load_1_21_10  25
 BV BND1      arc_1_21_11
 UP BND1      load_1_21_11  25
 BV BND1      arc_1_21_17
 UP BND1      load_1_21_17  25
 BV BND1      arc_1_21_18
 UP BND1      load_1_21_18  25
 BV BND1      arc_1_21_19
 UP BND1      load_1_21_19  25
 BV BND1      arc_1_21_20
 UP BND1      load_1_21_20  25
 BV BND1      arc_1_21_22
 UP BND1      load_1_21_22  25
 BV BND1      arc_1_21_23
 UP BND1      load_1_21_23  25
 BV BND1      arc_1_21_24
 UP BND1      load_1_21_24  25
 BV BND1      arc_1_22_0
 UP BND1      load_1_22_0  25
 BV BND1      arc_1_22_7
 UP BND1      load_1_22_7  25
 BV BND1      arc_1_22_8
 UP BND1      load_1_22_8  25
 BV BND1      arc_1_22_9
 UP BND1      load_1_22_9  25
 BV BND1      arc_1_22_10
 UP BND1      load_1_22_10  25
 BV BND1      arc_1_22_11
 UP BND1      load_1_22_11  25
 BV BND1      arc_1_22_17
 UP BND1      load_1_22_17  25
 BV BND1      arc_1_22_18
 UP BND1      load_1_22_18  25
 BV BND1      arc_1_22_19
 UP BND1      load_1_22_19  25
 BV BND1      arc_1_22_20
 UP BND1      load_1_22_20  25
 BV BND1      arc_1_22_21
 UP BND1      load_1_22_21  25
 BV BND1      arc_1_22_23
 UP BND1      load_1_22_23  25
 BV BND1      arc_1_22_24
 UP BND1      load_1_22_24  25
 BV BND1      arc_1_23_0
 UP BND1      load_1_23_0  25
 BV BND1      arc_1_23_7
 UP BND1      load_1_23_7  25
 BV BND1      arc_1_23_8
 UP BND1      load_1_23_8  25
 BV BND1      arc_1_23_9
 UP BND1      load_1_23_9  25
 BV BND1      arc_1_23_10
 UP BND1      load_1_23_10  25
 BV BND1      arc_1_23_11
 UP BND1      load_1_23_11  25
 BV BND1      arc_1_23_17
 UP BND1      load_1_23_17  25
 BV BND1      arc_1_23_18
 UP BND1      load_1_23_18  25
 BV BND1      arc_1_23_19
 UP BND1      load_1_23_19  25
 BV BND1      arc_1_23_20
 UP BND1      load_1_23_20  25
 BV BND1      arc_1_23_21
 UP BND1      load_1_23_21  25
 BV BND1      arc_1_23_22
 UP BND1      load_1_23_22  25
 BV BND1      arc_1_23_24
 UP BND1      load_1_23_24  25
 BV BND1      arc_1_24_0
 UP BND1      load_1_24_0  25
 BV BND1      arc_1_24_7
 UP BND1      load_1_24_7  25
 BV BND1      arc_1_24_8
 UP BND1      load_1_24_8  25
 BV BND1      arc_1_24_9
 UP BND1      load_1_24_9  25
 BV BND1      arc_1_24_10
 UP BND1      load_1_24_10  25
 BV BND1      arc_1_24_11
 UP BND1      load_1_24_11  25
 BV BND1      arc_1_24_17
 UP BND1      load_1_24_17  25
 BV BND1      arc_1_24_18
 UP BND1      load_1_24_18  25
 BV BND1      arc_1_24_19
 UP BND1      load_1_24_19  25
 BV BND1      arc_1_24_20
 UP BND1      load_1_24_20  25
 BV BND1      arc_1_24_21
 UP BND1      load_1_24_21  25
 BV BND1      arc_1_24_22
 UP BND1      load_1_24_22  25
 BV BND1      arc_1_24_23
 UP BND1      load_1_24_23  25
 FX BND1      visit_2_12  1
 UP BND1      order_2_12  13
 FX BND1      visit_2_13  1
 UP BND1      order_2_13  13
 FX BND1      visit_2_14  1
 UP BND1      order_2_14  13
 FX BND1      visit_2_15  1
 UP BND1      order_2_15  13
 FX BND1      visit_2_16  1
 UP BND1      order_2_16  13
 UP BND1      visit_2_17  1
 UP BND1      order_2_17  13
 UP BND1      visit_2_18  1
 UP BND1      order_2_18  13
 UP BND1      visit_2_19  1
 UP BND1      order_2_19  13
 UP BND1      visit_2_20  1
 UP BND1      order_2_20  13
 UP BND1      visit_2_21  1
 UP BND1      order_2_21  13
 UP BND1      visit_2_22  1
 UP BND1      order_2_22  13
 UP BND1      visit_2_23  1
 UP BND1      order_2_23  13
 UP BND1      visit_2_24  1
 UP BND1      order_2_24  13
 BV BND1      arc_2_0_0
 FX BND1      load_2_0_0  0
 BV BND1      arc_2_0_12
 FX BND1      load_2_0_12  0
 BV BND1      arc_2_0_13
 FX BND1      load_2_0_13  0
 BV BND1      arc_2_0_14
 FX BND1      load_2_0_14  0
 BV BND1      arc_2_0_15
 FX BND1      load_2_0_15  0
 BV BND1      arc_2_0_16
 FX BND1      load_2_0_16  0
 BV BND1      arc_2_0_17
 FX BND1      load_2_0_17  0
 BV BND1      arc_2_0_18
 FX BND1      load_2_0_18  0
 BV BND1      arc_2_0_19
 FX BND1      load_2_0_19  0
 BV BND1      arc_2_0_20
 FX BND1      load_2_0_20  0
 BV BND1      arc_2_0_21
 FX BND1      load_2_0_21  0
 BV BND1      arc_2_0_22
 FX BND1      load_2_0_22  0
 BV BND1      arc_2_0_23
 FX BND1      load_2_0_23  0
 BV BND1      arc_2_0_24
 FX BND1      load_2_0_24  0
 BV BND1      arc_2_12_0
 UP BND1      load_2_12_0  30
 BV BND1      arc_2_12_13
 UP BND1      load_2_12_13  30
 BV BND1      arc_2_12_14
 UP BND1      load_2_12_14  30
 BV BND1      arc_2_12_15
 UP BND1      load_2_12_15  30
 BV BND1      arc_2_12_16
 UP BND1      load_2_12_16  30
 BV BND1      arc_2_12_17
 UP BND1      load_2_12_17  30
 BV BND1      arc_2_12_18
 UP BND1      load_2_12_18  30
 BV BND1      arc_2_12_19
 UP BND1      load_2_12_19  30
 BV BND1      arc_2_12_20
 UP BND1      load_2_12_20  30
 BV BND1      arc_2_12_21
 UP BND1      load_2_12_21  30
 BV BND1      arc_2_12_22
 UP BND1      load_2_12_22  30
 BV BND1      arc_2_12_23
 UP BND1      load_2_12_23  30
 BV BND1      arc_2_12_24
 UP BND1      load_2_12_24  30
 BV BND1      arc_2_13_0
 UP BND1      load_2_13_0  30
 BV BND1      arc_2_13_12
 UP BND1      load_2_13_12  30
 BV BND1      arc_2_13_14
 UP BND1      load_2_13_14  30
 BV BND1      arc_2_13_15
 UP BND1      load_2_13_15  30
 BV BND1      arc_2_13_16
 UP BND1      load_2_13_16  30
 BV BND1      arc_2_13_17
 UP BND1      load_2_13_17  30
 BV BND1      arc_2_13_18
 UP BND1      load_2_13_18  30
 BV BND1      arc_2_13_19
 UP BND1      load_2_13_19  30
 BV BND1      arc_2_13_20
 UP BND1      load_2_13_20  30
 BV BND1      arc_2_13_21
 UP BND1      load_2_13_21  30
 BV BND1      arc_2_13_22
 UP BND1      load_2_13_22  30
 BV BND1      arc_2_13_23
 UP BND1      load_2_13_23  30
 BV BND1      arc_2_13_24
 UP BND1      load_2_13_24  30
 BV BND1      arc_2_14_0
 UP BND1      load_2_14_0  30
 BV BND1      arc_2_14_12
 UP BND1      load_2_14_12  30
 BV BND1      arc_2_14_13
 UP BND1      load_2_14_13  30
 BV BND1      arc_2_14_15
 UP BND1      load_2_14_15  30
 BV BND1      arc_2_14_16
 UP BND1      load_2_14_16  30
 BV BND1      arc_2_14_17
 UP BND1      load_2_14_17  30
 BV BND1      arc_2_14_18
 UP BND1      load_2_14_18  30
 BV BND1      arc_2_14_19
 UP BND1      load_2_14_19  30
 BV BND1      arc_2_14_20
 UP BND1      load_2_14_20  30
 BV BND1      arc_2_14_21
 UP BND1      load_2_14_21  30
 BV BND1      arc_2_14_22
 UP BND1      load_2_14_22  30
 BV BND1      arc_2_14_23
 UP BND1      load_2_14_23  30
 BV BND1      arc_2_14_24
 UP BND1      load_2_14_24  30
 BV BND1      arc_2_15_0
 UP BND1      load_2_15_0  30
 BV BND1      arc_2_15_12
 UP BND1      load_2_15_12  30
 BV BND1      arc_2_15_13
 UP BND1      load_2_15_13  30
 BV BND1      arc_2_15_14
 UP BND1      load_2_15_14  30
 BV BND1      arc_2_15_16
 UP BND1      load_2_15_16  30
 BV BND1      arc_2_15_17
 UP BND1      load_2_15_17  30
 BV BND1      arc_2_15_18
 UP BND1      load_2_15_18  30
 BV BND1      arc_2_15_19
 UP BND1      load_2_15_19  30
 BV BND1      arc_2_15_20
 UP BND1      load_2_15_20  30
 BV BND1      arc_2_15_21
 UP BND1      load_2_15_21  30
 BV BND1      arc_2_15_22
 UP BND1      load_2_15_22  30
 BV BND1      arc_2_15_23
 UP BND1      load_2_15_23  30
 BV BND1      arc_2_15_24
 UP BND1      load_2_15_24  30
 BV BND1      arc_2_16_0
 UP BND1      load_2_16_0  30
 BV BND1      arc_2_16_12
 UP BND1      load_2_16_12  30
 BV BND1      arc_2_16_13
 UP BND1      load_2_16_13  30
 BV BND1      arc_2_16_14
 UP BND1      load_2_16_14  30
 BV BND1      arc_2_16_15
 UP BND1      load_2_16_15  30
 BV BND1      arc_2_16_17
 UP BND1      load_2_16_17  30
 BV BND1      arc_2_16_18
 UP BND1      load_2_16_18  30
 BV BND1      arc_2_16_19
 UP BND1      load_2_16_19  30
 BV BND1      arc_2_16_20
 UP BND1      load_2_16_20  30
 BV BND1      arc_2_16_21
 UP BND1      load_2_16_21  30
 BV BND1      arc_2_16_22
 UP BND1      load_2_16_22  30
 BV BND1      arc_2_16_23
 UP BND1      load_2_16_23  30
 BV BND1      arc_2_16_24
 UP BND1      load_2_16_24  30
 BV BND1      arc_2_17_0
 UP BND1      load_2_17_0  30
 BV BND1      arc_2_17_12
 UP BND1      load_2_17_12  30
 BV BND1      arc_2_17_13
 UP BND1      load_2_17_13  30
 BV BND1      arc_2_17_14
 UP BND1      load_2_17_14  30
 BV BND1      arc_2_17_15
 UP BND1      load_2_17_15  30
 BV BND1      arc_2_17_16
 UP BND1      load_2_17_16  30
 BV BND1      arc_2_17_18
 UP BND1      load_2_17_18  30
 BV BND1      arc_2_17_19
 UP BND1      load_2_17_19  30
 BV BND1      arc_2_17_20
 UP BND1      load_2_17_20  30
 BV BND1      arc_2_17_21
 UP BND1      load_2_17_21  30
 BV BND1      arc_2_17_22
 UP BND1      load_2_17_22  30
 BV BND1      arc_2_17_23
 UP BND1      load_2_17_23  30
 BV BND1      arc_2_17_24
 UP BND1      load_2_17_24  30
 BV BND1      arc_2_18_0
 UP BND1      load_2_18_0  30
 BV BND1      arc_2_18_12
 UP BND1      load_2_18_12  30
 BV BND1      arc_2_18_13
 UP BND1      load_2_18_13  30
 BV BND1      arc_2_18_14
 UP BND1      load_2_18_14  30
 BV BND1      arc_2_18_15
 UP BND1      load_2_18_15  30
 BV BND1      arc_2_18_16
 UP BND1      load_2_18_16  30
 BV BND1      arc_2_18_17
 UP BND1      load_2_18_17  30
 BV BND1      arc_2_18_19
 UP BND1      load_2_18_19  30
 BV BND1      arc_2_18_20
 UP BND1      load_2_18_20  30
 BV BND1      arc_2_18_21
 UP BND1      load_2_18_21  30
 BV BND1      arc_2_18_22
 UP BND1      load_2_18_22  30
 BV BND1      arc_2_18_23
 UP BND1      load_2_18_23  30
 BV BND1      arc_2_18_24
 UP BND1      load_2_18_24  30
 BV BND1      arc_2_19_0
 UP BND1      load_2_19_0  30
 BV BND1      arc_2_19_12
 UP BND1      load_2_19_12  30
 BV BND1      arc_2_19_13
 UP BND1      load_2_19_13  30
 BV BND1      arc_2_19_14
 UP BND1      load_2_19_14  30
 BV BND1      arc_2_19_15
 UP BND1      load_2_19_15  30
 BV BND1      arc_2_19_16
 UP BND1      load_2_19_16  30
 BV BND1      arc_2_19_17
 UP BND1      load_2_19_17  30
 BV BND1      arc_2_19_18
 UP BND1      load_2_19_18  30
 BV BND1      arc_2_19_20
 UP BND1      load_2_19_20  30
 BV BND1      arc_2_19_21
 UP BND1      load_2_19_21  30
 BV BND1      arc_2_19_22
 UP BND1      load_2_19_22  30
 BV BND1      arc_2_19_23
 UP BND1      load_2_19_23  30
 BV BND1      arc_2_19_24
 UP BND1      load_2_19_24  30
 BV BND1      arc_2_20_0
 UP BND1      load_2_20_0  30
 BV BND1      arc_2_20_12
 UP BND1      load_2_20_12  30
 BV BND1      arc_2_20_13
 UP BND1      load_2_20_13  30
 BV BND1      arc_2_20_14
 UP BND1      load_2_20_14  30
 BV BND1      arc_2_20_15
 UP BND1      load_2_20_15  30
 BV BND1      arc_2_20_16
 UP BND1      load_2_20_16  30
 BV BND1      arc_2_20_17
 UP BND1      load_2_20_17  30
 BV BND1      arc_2_20_18
 UP BND1      load_2_20_18  30
 BV BND1      arc_2_20_19
 UP BND1      load_2_20_19  30
 BV BND1      arc_2_20_21
 UP BND1      load_2_20_21  30
 BV BND1      arc_2_20_22
 UP BND1      load_2_20_22  30
 BV BND1      arc_2_20_23
 UP BND1      load_2_20_23  30
 BV BND1      arc_2_20_24
 UP BND1      load_2_20_24  30
 BV BND1      arc_2_21_0
 UP BND1      load_2_21_0  30
 BV BND1      arc_2_21_12
 UP BND1      load_2_21_12  30
 BV BND1      arc_2_21_13
 UP BND1      load_2_21_13  30
 BV BND1      arc_2_21_14
 UP BND1      load_2_21_14  30
 BV BND1      arc_2_21_15
 UP BND1      load_2_21_15  30
 BV BND1      arc_2_21_16
 UP BND1      load_2_21_16  30
 BV BND1      arc_2_21_17
 UP BND1      load_2_21_17  30
 BV BND1      arc_2_21_18
 UP BND1      load_2_21_18  30
 BV BND1      arc_2_21_19
 UP BND1      load_2_21_19  30
 BV BND1      arc_2_21_20
 UP BND1      load_2_21_20  30
 BV BND1      arc_2_21_22
 UP BND1      load_2_21_22  30
 BV BND1      arc_2_21_23
 UP BND1      load_2_21_23  30
 BV BND1      arc_2_21_24
 UP BND1      load_2_21_24  30
 BV BND1      arc_2_22_0
 UP BND1      load_2_22_0  30
 BV BND1      arc_2_22_12
 UP BND1      load_2_22_12  30
 BV BND1      arc_2_22_13
 UP BND1      load_2_22_13  30
 BV BND1      arc_2_22_14
 UP BND1      load_2_22_14  30
 BV BND1      arc_2_22_15
 UP BND1      load_2_22_15  30
 BV BND1      arc_2_22_16
 UP BND1      load_2_22_16  30
 BV BND1      arc_2_22_17
 UP BND1      load_2_22_17  30
 BV BND1      arc_2_22_18
 UP BND1      load_2_22_18  30
 BV BND1      arc_2_22_19
 UP BND1      load_2_22_19  30
 BV BND1      arc_2_22_20
 UP BND1      load_2_22_20  30
 BV BND1      arc_2_22_21
 UP BND1      load_2_22_21  30
 BV BND1      arc_2_22_23
 UP BND1      load_2_22_23  30
 BV BND1      arc_2_22_24
 UP BND1      load_2_22_24  30
 BV BND1      arc_2_23_0
 UP BND1      load_2_23_0  30
 BV BND1      arc_2_23_12
 UP BND1      load_2_23_12  30
 BV BND1      arc_2_23_13
 UP BND1      load_2_23_13  30
 BV BND1      arc_2_23_14
 UP BND1      load_2_23_14  30
 BV BND1      arc_2_23_15
 UP BND1      load_2_23_15  30
 BV BND1      arc_2_23_16
 UP BND1      load_2_23_16  30
 BV BND1      arc_2_23_17
 UP BND1      load_2_23_17  30
 BV BND1      arc_2_23_18
 UP BND1      load_2_23_18  30
 BV BND1      arc_2_23_19
 UP BND1      load_2_23_19  30
 BV BND1      arc_2_23_20
 UP BND1      load_2_23_20  30
 BV BND1      arc_2_23_21
 UP BND1      load_2_23_21  30
 BV BND1      arc_2_23_22
 UP BND1      load_2_23_22  30
 BV BND1      arc_2_23_24
 UP BND1      load_2_23_24  30
 BV BND1      arc_2_24_0
 UP BND1      load_2_24_0  30
 BV BND1      arc_2_24_12
 UP BND1      load_2_24_12  30
 BV BND1      arc_2_24_13
 UP BND1      load_2_24_13  30
 BV BND1      arc_2_24_14
 UP BND1      load_2_24_14  30
 BV BND1      arc_2_24_15
 UP BND1      load_2_24_15  30
 BV BND1      arc_2_24_16
 UP BND1      load_2_24_16  30
 BV BND1      arc_2_24_17
 UP BND1      load_2_24_17  30
 BV BND1      arc_2_24_18
 UP BND1      load_2_24_18  30
 BV BND1      arc_2_24_19
 UP BND1      load_2_24_19  30
 BV BND1      arc_2_24_20
 UP BND1      load_2_24_20  30
 BV BND1      arc_2_24_21
 UP BND1      load_2_24_21  30
 BV BND1      arc_2_24_22
 UP BND1      load_2_24_22  30
 BV BND1      arc_2_24_23
 UP BND1      load_2_24_23  30
ENDATA
