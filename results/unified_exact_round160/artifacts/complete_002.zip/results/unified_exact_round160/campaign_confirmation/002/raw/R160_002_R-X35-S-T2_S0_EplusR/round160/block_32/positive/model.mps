* Signature: 0x9cb5a972b06db44c
NAME R160_physical_neighborhood
ROWS
 N  OBJ
 G  product_lb_0
 L  product_ub_1
 G  product_lb_2
 L  product_ub_3
 G  product_lb_4
 L  product_ub_5
 G  product_lb_6
 L  product_ub_7
 G  product_lb_8
 L  product_ub_9
 G  product_lb_10
 L  product_ub_11
 G  product_lb_12
 L  product_ub_13
 G  product_lb_14
 L  product_ub_15
 G  product_lb_16
 L  product_ub_17
 G  product_lb_18
 L  product_ub_19
 G  product_lb_20
 L  product_ub_21
 G  product_lb_22
 L  product_ub_23
 G  product_lb_24
 L  product_ub_25
 G  product_lb_26
 L  product_ub_27
 G  product_lb_28
 L  product_ub_29
 G  product_lb_30
 L  product_ub_31
 E  onehot_24_32
 E  normalized_mass_24_33
 E  normalized_ratio_24_34
 G  product_lb_35
 L  product_ub_36
 G  product_lb_37
 L  product_ub_38
 G  product_lb_39
 L  product_ub_40
 G  product_lb_41
 L  product_ub_42
 G  product_lb_43
 L  product_ub_44
 G  product_lb_45
 L  product_ub_46
 G  product_lb_47
 L  product_ub_48
 G  product_lb_49
 L  product_ub_50
 G  product_lb_51
 L  product_ub_52
 E  onehot_30_53
 E  normalized_mass_30_54
 E  normalized_ratio_30_55
 G  product_lb_56
 L  product_ub_57
 G  product_lb_58
 L  product_ub_59
 G  product_lb_60
 L  product_ub_61
 G  product_lb_62
 L  product_ub_63
 G  product_lb_64
 L  product_ub_65
 G  product_lb_66
 L  product_ub_67
 G  product_lb_68
 L  product_ub_69
 G  product_lb_70
 L  product_ub_71
 G  product_lb_72
 L  product_ub_73
 G  product_lb_74
 L  product_ub_75
 G  product_lb_76
 L  product_ub_77
 G  product_lb_78
 L  product_ub_79
 G  product_lb_80
 L  product_ub_81
 G  product_lb_82
 L  product_ub_83
 G  product_lb_84
 L  product_ub_85
 G  product_lb_86
 L  product_ub_87
 E  onehot_34_88
 E  normalized_mass_34_89
 E  normalized_ratio_34_90
 G  product_lb_91
 L  product_ub_92
 G  product_lb_93
 L  product_ub_94
 G  product_lb_95
 L  product_ub_96
 G  product_lb_97
 L  product_ub_98
 G  product_lb_99
 L  product_ub_100
 G  product_lb_101
 L  product_ub_102
 G  product_lb_103
 L  product_ub_104
 E  onehot_28_105
 E  normalized_mass_28_106
 E  normalized_ratio_28_107
 G  product_lb_108
 L  product_ub_109
 G  product_lb_110
 L  product_ub_111
 G  product_lb_112
 L  product_ub_113
 G  product_lb_114
 L  product_ub_115
 G  product_lb_116
 L  product_ub_117
 G  product_lb_118
 L  product_ub_119
 G  product_lb_120
 L  product_ub_121
 G  product_lb_122
 L  product_ub_123
 G  product_lb_124
 L  product_ub_125
 G  product_lb_126
 L  product_ub_127
 G  product_lb_128
 L  product_ub_129
 E  onehot_29_130
 E  normalized_mass_29_131
 E  normalized_ratio_29_132
 G  product_lb_133
 L  product_ub_134
 G  product_lb_135
 L  product_ub_136
 G  product_lb_137
 L  product_ub_138
 G  product_lb_139
 L  product_ub_140
 G  product_lb_141
 L  product_ub_142
 G  product_lb_143
 L  product_ub_144
 G  product_lb_145
 L  product_ub_146
 G  product_lb_147
 L  product_ub_148
 G  product_lb_149
 L  product_ub_150
 G  product_lb_151
 L  product_ub_152
 G  product_lb_153
 L  product_ub_154
 G  product_lb_155
 L  product_ub_156
 G  product_lb_157
 L  product_ub_158
 G  product_lb_159
 L  product_ub_160
 G  product_lb_161
 L  product_ub_162
 G  product_lb_163
 L  product_ub_164
 E  onehot_16_165
 E  normalized_mass_16_166
 E  normalized_ratio_16_167
 G  product_lb_168
 L  product_ub_169
 G  product_lb_170
 L  product_ub_171
 G  product_lb_172
 L  product_ub_173
 G  product_lb_174
 L  product_ub_175
 G  product_lb_176
 L  product_ub_177
 G  product_lb_178
 L  product_ub_179
 G  product_lb_180
 L  product_ub_181
 E  onehot_27_182
 E  normalized_mass_27_183
 E  normalized_ratio_27_184
 G  product_lb_185
 L  product_ub_186
 G  product_lb_187
 L  product_ub_188
 G  product_lb_189
 L  product_ub_190
 G  product_lb_191
 L  product_ub_192
 G  product_lb_193
 L  product_ub_194
 G  product_lb_195
 L  product_ub_196
 G  product_lb_197
 L  product_ub_198
 G  product_lb_199
 L  product_ub_200
 G  product_lb_201
 L  product_ub_202
 G  product_lb_203
 L  product_ub_204
 G  product_lb_205
 L  product_ub_206
 G  product_lb_207
 L  product_ub_208
 G  product_lb_209
 L  product_ub_210
 G  product_lb_211
 L  product_ub_212
 G  product_lb_213
 L  product_ub_214
 G  product_lb_215
 L  product_ub_216
 E  onehot_22_217
 E  normalized_mass_22_218
 E  normalized_ratio_22_219
 G  stock_lb_220
 L  stock_ub_221
 L  parent_nonstrict_scope_222
 G  block_pair_pos_223
 G  block_pair_neg_224
 G  block_pair_pos_225
 G  block_pair_neg_226
 G  block_pair_pos_227
 G  block_pair_neg_228
 G  block_pair_pos_229
 G  block_pair_neg_230
 G  block_pair_pos_231
 G  block_pair_neg_232
 G  block_pair_pos_233
 G  block_pair_neg_234
 G  block_pair_pos_235
 G  block_pair_neg_236
 G  block_pair_pos_237
 G  block_pair_neg_238
 G  block_pair_pos_239
 G  block_pair_neg_240
 G  block_pair_pos_241
 G  block_pair_neg_242
 G  block_pair_pos_243
 G  block_pair_neg_244
 G  block_pair_pos_245
 G  block_pair_neg_246
 G  block_pair_pos_247
 G  block_pair_neg_248
 G  block_pair_pos_249
 G  block_pair_neg_250
 G  block_pair_pos_251
 G  block_pair_neg_252
 G  block_pair_pos_253
 G  block_pair_neg_254
 G  block_pair_pos_255
 G  block_pair_neg_256
 G  block_pair_pos_257
 G  block_pair_neg_258
 G  block_pair_pos_259
 G  block_pair_neg_260
 G  block_pair_pos_261
 G  block_pair_neg_262
 G  block_pair_pos_263
 G  block_pair_neg_264
 G  block_pair_pos_265
 G  block_pair_neg_266
 G  block_pair_pos_267
 G  block_pair_neg_268
 G  block_pair_pos_269
 G  block_pair_neg_270
 G  block_pair_pos_271
 G  block_pair_neg_272
 G  block_pair_pos_273
 G  block_pair_neg_274
 G  block_pair_pos_275
 G  block_pair_neg_276
 G  block_pair_pos_277
 G  block_pair_neg_278
 E  normalization_279
 G  full_original_Gini_280
 E  unique_nonzero_owner_281
 E  unique_nonzero_owner_282
 E  unique_nonzero_owner_283
 E  unique_nonzero_owner_284
 E  unique_nonzero_owner_285
 E  unique_nonzero_owner_286
 E  unique_nonzero_owner_287
 E  unique_nonzero_owner_288
 E  unique_nonzero_owner_289
 E  unique_nonzero_owner_290
 E  unique_nonzero_owner_291
 E  unique_nonzero_owner_292
 E  unique_nonzero_owner_293
 E  unique_nonzero_owner_294
 E  unique_nonzero_owner_295
 E  unique_nonzero_owner_296
 E  unique_nonzero_owner_297
 E  unique_nonzero_owner_298
 E  unique_nonzero_owner_299
 E  unique_nonzero_owner_300
 E  unique_nonzero_owner_301
 E  unique_nonzero_owner_302
 E  unique_nonzero_owner_303
 E  unique_nonzero_owner_304
 E  unique_nonzero_owner_305
 E  unique_nonzero_owner_306
 E  unique_nonzero_owner_307
 E  unique_nonzero_owner_308
 E  unique_nonzero_owner_309
 E  unique_nonzero_owner_310
 E  unique_nonzero_owner_311
 E  unique_nonzero_owner_312
 E  unique_nonzero_owner_313
 E  unique_nonzero_owner_314
 E  unique_nonzero_owner_315
 E  unique_nonzero_owner_316
 E  unique_nonzero_owner_317
 E  unique_nonzero_owner_318
 E  unique_nonzero_owner_319
 E  unique_nonzero_owner_320
 E  unique_nonzero_owner_321
 E  unique_nonzero_owner_322
 E  unique_nonzero_owner_323
 E  unique_nonzero_owner_324
 E  unique_nonzero_owner_325
 E  unique_nonzero_owner_326
 E  unique_nonzero_owner_327
 E  unique_nonzero_owner_328
 E  unique_nonzero_owner_329
 E  unique_nonzero_owner_330
 E  unique_nonzero_owner_331
 E  unique_nonzero_owner_332
 E  unique_nonzero_owner_333
 E  unique_nonzero_owner_334
 E  unique_nonzero_owner_335
 E  unique_nonzero_owner_336
 E  unique_nonzero_owner_337
 E  unique_nonzero_owner_338
 E  unique_nonzero_owner_339
 E  unique_nonzero_owner_340
 E  unique_nonzero_owner_341
 E  unique_nonzero_owner_342
 E  unique_nonzero_owner_343
 E  unique_nonzero_owner_344
 E  unique_nonzero_owner_345
 E  unique_nonzero_owner_346
 E  unique_nonzero_owner_347
 E  unique_nonzero_owner_348
 E  unique_nonzero_owner_349
 E  unique_nonzero_owner_350
 E  unique_nonzero_owner_351
 E  unique_nonzero_owner_352
 E  unique_nonzero_owner_353
 E  unique_nonzero_owner_354
 E  unique_nonzero_owner_355
 E  unique_nonzero_owner_356
 E  unique_nonzero_owner_357
 E  unique_nonzero_owner_358
 E  unique_nonzero_owner_359
 E  unique_nonzero_owner_360
 E  unique_nonzero_owner_361
 E  unique_nonzero_owner_362
 E  unique_nonzero_owner_363
 E  unique_nonzero_owner_364
 E  unique_nonzero_owner_365
 E  unique_nonzero_owner_366
 E  unique_nonzero_owner_367
 E  unique_nonzero_owner_368
 E  unique_nonzero_owner_369
 E  unique_nonzero_owner_370
 L  arc_capacity_371
 L  arc_capacity_372
 L  arc_capacity_373
 L  arc_capacity_374
 L  arc_capacity_375
 L  arc_capacity_376
 L  arc_capacity_377
 L  arc_capacity_378
 L  arc_capacity_379
 L  arc_capacity_380
 L  arc_capacity_381
 L  arc_capacity_382
 L  arc_capacity_383
 L  arc_capacity_384
 L  arc_capacity_385
 G  connected_order_arc_386
 L  arc_capacity_387
 G  connected_order_arc_388
 L  arc_capacity_389
 G  connected_order_arc_390
 L  arc_capacity_391
 G  connected_order_arc_392
 L  arc_capacity_393
 G  connected_order_arc_394
 L  arc_capacity_395
 G  connected_order_arc_396
 L  arc_capacity_397
 G  connected_order_arc_398
 L  arc_capacity_399
 G  connected_order_arc_400
 L  arc_capacity_401
 G  connected_order_arc_402
 L  arc_capacity_403
 G  connected_order_arc_404
 L  arc_capacity_405
 G  connected_order_arc_406
 L  arc_capacity_407
 L  arc_capacity_408
 G  connected_order_arc_409
 L  arc_capacity_410
 G  connected_order_arc_411
 L  arc_capacity_412
 G  connected_order_arc_413
 L  arc_capacity_414
 G  connected_order_arc_415
 L  arc_capacity_416
 G  connected_order_arc_417
 L  arc_capacity_418
 G  connected_order_arc_419
 L  arc_capacity_420
 G  connected_order_arc_421
 L  arc_capacity_422
 G  connected_order_arc_423
 L  arc_capacity_424
 G  connected_order_arc_425
 L  arc_capacity_426
 G  connected_order_arc_427
 L  arc_capacity_428
 G  connected_order_arc_429
 L  arc_capacity_430
 L  arc_capacity_431
 G  connected_order_arc_432
 L  arc_capacity_433
 G  connected_order_arc_434
 L  arc_capacity_435
 G  connected_order_arc_436
 L  arc_capacity_437
 G  connected_order_arc_438
 L  arc_capacity_439
 G  connected_order_arc_440
 L  arc_capacity_441
 G  connected_order_arc_442
 L  arc_capacity_443
 G  connected_order_arc_444
 L  arc_capacity_445
 G  connected_order_arc_446
 L  arc_capacity_447
 G  connected_order_arc_448
 L  arc_capacity_449
 G  connected_order_arc_450
 L  arc_capacity_451
 G  connected_order_arc_452
 L  arc_capacity_453
 L  arc_capacity_454
 G  connected_order_arc_455
 L  arc_capacity_456
 G  connected_order_arc_457
 L  arc_capacity_458
 G  connected_order_arc_459
 L  arc_capacity_460
 G  connected_order_arc_461
 L  arc_capacity_462
 G  connected_order_arc_463
 L  arc_capacity_464
 G  connected_order_arc_465
 L  arc_capacity_466
 G  connected_order_arc_467
 L  arc_capacity_468
 G  connected_order_arc_469
 L  arc_capacity_470
 G  connected_order_arc_471
 L  arc_capacity_472
 G  connected_order_arc_473
 L  arc_capacity_474
 G  connected_order_arc_475
 L  arc_capacity_476
 L  arc_capacity_477
 G  connected_order_arc_478
 L  arc_capacity_479
 G  connected_order_arc_480
 L  arc_capacity_481
 G  connected_order_arc_482
 L  arc_capacity_483
 G  connected_order_arc_484
 L  arc_capacity_485
 G  connected_order_arc_486
 L  arc_capacity_487
 G  connected_order_arc_488
 L  arc_capacity_489
 G  connected_order_arc_490
 L  arc_capacity_491
 G  connected_order_arc_492
 L  arc_capacity_493
 G  connected_order_arc_494
 L  arc_capacity_495
 G  connected_order_arc_496
 L  arc_capacity_497
 G  connected_order_arc_498
 L  arc_capacity_499
 L  arc_capacity_500
 G  connected_order_arc_501
 L  arc_capacity_502
 G  connected_order_arc_503
 L  arc_capacity_504
 G  connected_order_arc_505
 L  arc_capacity_506
 G  connected_order_arc_507
 L  arc_capacity_508
 G  connected_order_arc_509
 L  arc_capacity_510
 G  connected_order_arc_511
 L  arc_capacity_512
 G  connected_order_arc_513
 L  arc_capacity_514
 G  connected_order_arc_515
 L  arc_capacity_516
 G  connected_order_arc_517
 L  arc_capacity_518
 G  connected_order_arc_519
 L  arc_capacity_520
 G  connected_order_arc_521
 L  arc_capacity_522
 L  arc_capacity_523
 G  connected_order_arc_524
 L  arc_capacity_525
 G  connected_order_arc_526
 L  arc_capacity_527
 G  connected_order_arc_528
 L  arc_capacity_529
 G  connected_order_arc_530
 L  arc_capacity_531
 G  connected_order_arc_532
 L  arc_capacity_533
 G  connected_order_arc_534
 L  arc_capacity_535
 G  connected_order_arc_536
 L  arc_capacity_537
 G  connected_order_arc_538
 L  arc_capacity_539
 G  connected_order_arc_540
 L  arc_capacity_541
 G  connected_order_arc_542
 L  arc_capacity_543
 G  connected_order_arc_544
 L  arc_capacity_545
 L  arc_capacity_546
 G  connected_order_arc_547
 L  arc_capacity_548
 G  connected_order_arc_549
 L  arc_capacity_550
 G  connected_order_arc_551
 L  arc_capacity_552
 G  connected_order_arc_553
 L  arc_capacity_554
 G  connected_order_arc_555
 L  arc_capacity_556
 G  connected_order_arc_557
 L  arc_capacity_558
 G  connected_order_arc_559
 L  arc_capacity_560
 G  connected_order_arc_561
 L  arc_capacity_562
 G  connected_order_arc_563
 L  arc_capacity_564
 G  connected_order_arc_565
 L  arc_capacity_566
 G  connected_order_arc_567
 L  arc_capacity_568
 L  arc_capacity_569
 G  connected_order_arc_570
 L  arc_capacity_571
 G  connected_order_arc_572
 L  arc_capacity_573
 G  connected_order_arc_574
 L  arc_capacity_575
 G  connected_order_arc_576
 L  arc_capacity_577
 G  connected_order_arc_578
 L  arc_capacity_579
 G  connected_order_arc_580
 L  arc_capacity_581
 G  connected_order_arc_582
 L  arc_capacity_583
 G  connected_order_arc_584
 L  arc_capacity_585
 G  connected_order_arc_586
 L  arc_capacity_587
 G  connected_order_arc_588
 L  arc_capacity_589
 G  connected_order_arc_590
 L  arc_capacity_591
 L  arc_capacity_592
 G  connected_order_arc_593
 L  arc_capacity_594
 G  connected_order_arc_595
 L  arc_capacity_596
 G  connected_order_arc_597
 L  arc_capacity_598
 G  connected_order_arc_599
 L  arc_capacity_600
 G  connected_order_arc_601
 L  arc_capacity_602
 G  connected_order_arc_603
 L  arc_capacity_604
 G  connected_order_arc_605
 L  arc_capacity_606
 G  connected_order_arc_607
 L  arc_capacity_608
 G  connected_order_arc_609
 L  arc_capacity_610
 G  connected_order_arc_611
 L  arc_capacity_612
 G  connected_order_arc_613
 L  arc_capacity_614
 L  arc_capacity_615
 G  connected_order_arc_616
 L  arc_capacity_617
 G  connected_order_arc_618
 L  arc_capacity_619
 G  connected_order_arc_620
 L  arc_capacity_621
 G  connected_order_arc_622
 L  arc_capacity_623
 G  connected_order_arc_624
 L  arc_capacity_625
 G  connected_order_arc_626
 L  arc_capacity_627
 G  connected_order_arc_628
 L  arc_capacity_629
 G  connected_order_arc_630
 L  arc_capacity_631
 G  connected_order_arc_632
 L  arc_capacity_633
 G  connected_order_arc_634
 L  arc_capacity_635
 G  connected_order_arc_636
 L  arc_capacity_637
 L  arc_capacity_638
 G  connected_order_arc_639
 L  arc_capacity_640
 G  connected_order_arc_641
 L  arc_capacity_642
 G  connected_order_arc_643
 L  arc_capacity_644
 G  connected_order_arc_645
 L  arc_capacity_646
 G  connected_order_arc_647
 L  arc_capacity_648
 G  connected_order_arc_649
 L  arc_capacity_650
 G  connected_order_arc_651
 L  arc_capacity_652
 G  connected_order_arc_653
 L  arc_capacity_654
 G  connected_order_arc_655
 L  arc_capacity_656
 G  connected_order_arc_657
 L  arc_capacity_658
 G  connected_order_arc_659
 E  depot_departure_or_bypass_660
 E  depot_return_or_bypass_661
 E  out_degree_662
 E  in_degree_663
 G  order_active_lb_664
 L  order_active_ub_665
 E  segment_load_conservation_666
 G  segment_prefix_lb_667
 L  segment_prefix_ub_668
 E  out_degree_669
 E  in_degree_670
 G  order_active_lb_671
 L  order_active_ub_672
 E  segment_load_conservation_673
 G  segment_prefix_lb_674
 L  segment_prefix_ub_675
 E  out_degree_676
 E  in_degree_677
 G  order_active_lb_678
 L  order_active_ub_679
 E  segment_load_conservation_680
 G  segment_prefix_lb_681
 L  segment_prefix_ub_682
 E  out_degree_683
 E  in_degree_684
 G  order_active_lb_685
 L  order_active_ub_686
 E  segment_load_conservation_687
 G  segment_prefix_lb_688
 L  segment_prefix_ub_689
 E  out_degree_690
 E  in_degree_691
 G  order_active_lb_692
 L  order_active_ub_693
 E  service_visit_def_694
 E  free_load_conservation_695
 E  out_degree_696
 E  in_degree_697
 G  order_active_lb_698
 L  order_active_ub_699
 E  service_visit_def_700
 E  free_load_conservation_701
 E  out_degree_702
 E  in_degree_703
 G  order_active_lb_704
 L  order_active_ub_705
 E  service_visit_def_706
 E  free_load_conservation_707
 E  out_degree_708
 E  in_degree_709
 G  order_active_lb_710
 L  order_active_ub_711
 E  service_visit_def_712
 E  free_load_conservation_713
 E  out_degree_714
 E  in_degree_715
 G  order_active_lb_716
 L  order_active_ub_717
 E  service_visit_def_718
 E  free_load_conservation_719
 E  out_degree_720
 E  in_degree_721
 G  order_active_lb_722
 L  order_active_ub_723
 E  service_visit_def_724
 E  free_load_conservation_725
 E  out_degree_726
 E  in_degree_727
 G  order_active_lb_728
 L  order_active_ub_729
 E  service_visit_def_730
 E  free_load_conservation_731
 E  out_degree_732
 E  in_degree_733
 G  order_active_lb_734
 L  order_active_ub_735
 E  service_visit_def_736
 E  free_load_conservation_737
 G  fixed_segment_relative_order_738
 G  fixed_segment_relative_order_739
 G  fixed_segment_relative_order_740
 L  original_T_including_depot_unload_741
 L  arc_capacity_742
 L  arc_capacity_743
 L  arc_capacity_744
 L  arc_capacity_745
 L  arc_capacity_746
 L  arc_capacity_747
 L  arc_capacity_748
 L  arc_capacity_749
 L  arc_capacity_750
 L  arc_capacity_751
 L  arc_capacity_752
 L  arc_capacity_753
 L  arc_capacity_754
 L  arc_capacity_755
 G  connected_order_arc_756
 L  arc_capacity_757
 G  connected_order_arc_758
 L  arc_capacity_759
 G  connected_order_arc_760
 L  arc_capacity_761
 G  connected_order_arc_762
 L  arc_capacity_763
 G  connected_order_arc_764
 L  arc_capacity_765
 G  connected_order_arc_766
 L  arc_capacity_767
 G  connected_order_arc_768
 L  arc_capacity_769
 G  connected_order_arc_770
 L  arc_capacity_771
 G  connected_order_arc_772
 L  arc_capacity_773
 G  connected_order_arc_774
 L  arc_capacity_775
 L  arc_capacity_776
 G  connected_order_arc_777
 L  arc_capacity_778
 G  connected_order_arc_779
 L  arc_capacity_780
 G  connected_order_arc_781
 L  arc_capacity_782
 G  connected_order_arc_783
 L  arc_capacity_784
 G  connected_order_arc_785
 L  arc_capacity_786
 G  connected_order_arc_787
 L  arc_capacity_788
 G  connected_order_arc_789
 L  arc_capacity_790
 G  connected_order_arc_791
 L  arc_capacity_792
 G  connected_order_arc_793
 L  arc_capacity_794
 G  connected_order_arc_795
 L  arc_capacity_796
 L  arc_capacity_797
 G  connected_order_arc_798
 L  arc_capacity_799
 G  connected_order_arc_800
 L  arc_capacity_801
 G  connected_order_arc_802
 L  arc_capacity_803
 G  connected_order_arc_804
 L  arc_capacity_805
 G  connected_order_arc_806
 L  arc_capacity_807
 G  connected_order_arc_808
 L  arc_capacity_809
 G  connected_order_arc_810
 L  arc_capacity_811
 G  connected_order_arc_812
 L  arc_capacity_813
 G  connected_order_arc_814
 L  arc_capacity_815
 G  connected_order_arc_816
 L  arc_capacity_817
 L  arc_capacity_818
 G  connected_order_arc_819
 L  arc_capacity_820
 G  connected_order_arc_821
 L  arc_capacity_822
 G  connected_order_arc_823
 L  arc_capacity_824
 G  connected_order_arc_825
 L  arc_capacity_826
 G  connected_order_arc_827
 L  arc_capacity_828
 G  connected_order_arc_829
 L  arc_capacity_830
 G  connected_order_arc_831
 L  arc_capacity_832
 G  connected_order_arc_833
 L  arc_capacity_834
 G  connected_order_arc_835
 L  arc_capacity_836
 G  connected_order_arc_837
 L  arc_capacity_838
 L  arc_capacity_839
 G  connected_order_arc_840
 L  arc_capacity_841
 G  connected_order_arc_842
 L  arc_capacity_843
 G  connected_order_arc_844
 L  arc_capacity_845
 G  connected_order_arc_846
 L  arc_capacity_847
 G  connected_order_arc_848
 L  arc_capacity_849
 G  connected_order_arc_850
 L  arc_capacity_851
 G  connected_order_arc_852
 L  arc_capacity_853
 G  connected_order_arc_854
 L  arc_capacity_855
 G  connected_order_arc_856
 L  arc_capacity_857
 G  connected_order_arc_858
 L  arc_capacity_859
 L  arc_capacity_860
 G  connected_order_arc_861
 L  arc_capacity_862
 G  connected_order_arc_863
 L  arc_capacity_864
 G  connected_order_arc_865
 L  arc_capacity_866
 G  connected_order_arc_867
 L  arc_capacity_868
 G  connected_order_arc_869
 L  arc_capacity_870
 G  connected_order_arc_871
 L  arc_capacity_872
 G  connected_order_arc_873
 L  arc_capacity_874
 G  connected_order_arc_875
 L  arc_capacity_876
 G  connected_order_arc_877
 L  arc_capacity_878
 G  connected_order_arc_879
 L  arc_capacity_880
 L  arc_capacity_881
 G  connected_order_arc_882
 L  arc_capacity_883
 G  connected_order_arc_884
 L  arc_capacity_885
 G  connected_order_arc_886
 L  arc_capacity_887
 G  connected_order_arc_888
 L  arc_capacity_889
 G  connected_order_arc_890
 L  arc_capacity_891
 G  connected_order_arc_892
 L  arc_capacity_893
 G  connected_order_arc_894
 L  arc_capacity_895
 G  connected_order_arc_896
 L  arc_capacity_897
 G  connected_order_arc_898
 L  arc_capacity_899
 G  connected_order_arc_900
 L  arc_capacity_901
 L  arc_capacity_902
 G  connected_order_arc_903
 L  arc_capacity_904
 G  connected_order_arc_905
 L  arc_capacity_906
 G  connected_order_arc_907
 L  arc_capacity_908
 G  connected_order_arc_909
 L  arc_capacity_910
 G  connected_order_arc_911
 L  arc_capacity_912
 G  connected_order_arc_913
 L  arc_capacity_914
 G  connected_order_arc_915
 L  arc_capacity_916
 G  connected_order_arc_917
 L  arc_capacity_918
 G  connected_order_arc_919
 L  arc_capacity_920
 G  connected_order_arc_921
 L  arc_capacity_922
 L  arc_capacity_923
 G  connected_order_arc_924
 L  arc_capacity_925
 G  connected_order_arc_926
 L  arc_capacity_927
 G  connected_order_arc_928
 L  arc_capacity_929
 G  connected_order_arc_930
 L  arc_capacity_931
 G  connected_order_arc_932
 L  arc_capacity_933
 G  connected_order_arc_934
 L  arc_capacity_935
 G  connected_order_arc_936
 L  arc_capacity_937
 G  connected_order_arc_938
 L  arc_capacity_939
 G  connected_order_arc_940
 L  arc_capacity_941
 G  connected_order_arc_942
 L  arc_capacity_943
 L  arc_capacity_944
 G  connected_order_arc_945
 L  arc_capacity_946
 G  connected_order_arc_947
 L  arc_capacity_948
 G  connected_order_arc_949
 L  arc_capacity_950
 G  connected_order_arc_951
 L  arc_capacity_952
 G  connected_order_arc_953
 L  arc_capacity_954
 G  connected_order_arc_955
 L  arc_capacity_956
 G  connected_order_arc_957
 L  arc_capacity_958
 G  connected_order_arc_959
 L  arc_capacity_960
 G  connected_order_arc_961
 L  arc_capacity_962
 G  connected_order_arc_963
 L  arc_capacity_964
 L  arc_capacity_965
 G  connected_order_arc_966
 L  arc_capacity_967
 G  connected_order_arc_968
 L  arc_capacity_969
 G  connected_order_arc_970
 L  arc_capacity_971
 G  connected_order_arc_972
 L  arc_capacity_973
 G  connected_order_arc_974
 L  arc_capacity_975
 G  connected_order_arc_976
 L  arc_capacity_977
 G  connected_order_arc_978
 L  arc_capacity_979
 G  connected_order_arc_980
 L  arc_capacity_981
 G  connected_order_arc_982
 L  arc_capacity_983
 G  connected_order_arc_984
 E  depot_departure_or_bypass_985
 E  depot_return_or_bypass_986
 E  out_degree_987
 E  in_degree_988
 G  order_active_lb_989
 L  order_active_ub_990
 E  segment_load_conservation_991
 G  segment_prefix_lb_992
 L  segment_prefix_ub_993
 E  out_degree_994
 E  in_degree_995
 G  order_active_lb_996
 L  order_active_ub_997
 E  segment_load_conservation_998
 G  segment_prefix_lb_999
 L  segment_prefix_ub_1000
 E  out_degree_1001
 E  in_degree_1002
 G  order_active_lb_1003
 L  order_active_ub_1004
 E  segment_load_conservation_1005
 G  segment_prefix_lb_1006
 L  segment_prefix_ub_1007
 E  out_degree_1008
 E  in_degree_1009
 G  order_active_lb_1010
 L  order_active_ub_1011
 E  service_visit_def_1012
 E  free_load_conservation_1013
 E  out_degree_1014
 E  in_degree_1015
 G  order_active_lb_1016
 L  order_active_ub_1017
 E  service_visit_def_1018
 E  free_load_conservation_1019
 E  out_degree_1020
 E  in_degree_1021
 G  order_active_lb_1022
 L  order_active_ub_1023
 E  service_visit_def_1024
 E  free_load_conservation_1025
 E  out_degree_1026
 E  in_degree_1027
 G  order_active_lb_1028
 L  order_active_ub_1029
 E  service_visit_def_1030
 E  free_load_conservation_1031
 E  out_degree_1032
 E  in_degree_1033
 G  order_active_lb_1034
 L  order_active_ub_1035
 E  service_visit_def_1036
 E  free_load_conservation_1037
 E  out_degree_1038
 E  in_degree_1039
 G  order_active_lb_1040
 L  order_active_ub_1041
 E  service_visit_def_1042
 E  free_load_conservation_1043
 E  out_degree_1044
 E  in_degree_1045
 G  order_active_lb_1046
 L  order_active_ub_1047
 E  service_visit_def_1048
 E  free_load_conservation_1049
 E  out_degree_1050
 E  in_degree_1051
 G  order_active_lb_1052
 L  order_active_ub_1053
 E  service_visit_def_1054
 E  free_load_conservation_1055
 G  fixed_segment_relative_order_1056
 G  fixed_segment_relative_order_1057
 L  original_T_including_depot_unload_1058
 L  arc_capacity_1059
 L  arc_capacity_1060
 L  arc_capacity_1061
 L  arc_capacity_1062
 L  arc_capacity_1063
 L  arc_capacity_1064
 L  arc_capacity_1065
 L  arc_capacity_1066
 L  arc_capacity_1067
 L  arc_capacity_1068
 L  arc_capacity_1069
 L  arc_capacity_1070
 L  arc_capacity_1071
 L  arc_capacity_1072
 L  arc_capacity_1073
 G  connected_order_arc_1074
 L  arc_capacity_1075
 G  connected_order_arc_1076
 L  arc_capacity_1077
 G  connected_order_arc_1078
 L  arc_capacity_1079
 G  connected_order_arc_1080
 L  arc_capacity_1081
 G  connected_order_arc_1082
 L  arc_capacity_1083
 G  connected_order_arc_1084
 L  arc_capacity_1085
 G  connected_order_arc_1086
 L  arc_capacity_1087
 G  connected_order_arc_1088
 L  arc_capacity_1089
 G  connected_order_arc_1090
 L  arc_capacity_1091
 G  connected_order_arc_1092
 L  arc_capacity_1093
 G  connected_order_arc_1094
 L  arc_capacity_1095
 L  arc_capacity_1096
 G  connected_order_arc_1097
 L  arc_capacity_1098
 G  connected_order_arc_1099
 L  arc_capacity_1100
 G  connected_order_arc_1101
 L  arc_capacity_1102
 G  connected_order_arc_1103
 L  arc_capacity_1104
 G  connected_order_arc_1105
 L  arc_capacity_1106
 G  connected_order_arc_1107
 L  arc_capacity_1108
 G  connected_order_arc_1109
 L  arc_capacity_1110
 G  connected_order_arc_1111
 L  arc_capacity_1112
 G  connected_order_arc_1113
 L  arc_capacity_1114
 G  connected_order_arc_1115
 L  arc_capacity_1116
 G  connected_order_arc_1117
 L  arc_capacity_1118
 L  arc_capacity_1119
 G  connected_order_arc_1120
 L  arc_capacity_1121
 G  connected_order_arc_1122
 L  arc_capacity_1123
 G  connected_order_arc_1124
 L  arc_capacity_1125
 G  connected_order_arc_1126
 L  arc_capacity_1127
 G  connected_order_arc_1128
 L  arc_capacity_1129
 G  connected_order_arc_1130
 L  arc_capacity_1131
 G  connected_order_arc_1132
 L  arc_capacity_1133
 G  connected_order_arc_1134
 L  arc_capacity_1135
 G  connected_order_arc_1136
 L  arc_capacity_1137
 G  connected_order_arc_1138
 L  arc_capacity_1139
 G  connected_order_arc_1140
 L  arc_capacity_1141
 L  arc_capacity_1142
 G  connected_order_arc_1143
 L  arc_capacity_1144
 G  connected_order_arc_1145
 L  arc_capacity_1146
 G  connected_order_arc_1147
 L  arc_capacity_1148
 G  connected_order_arc_1149
 L  arc_capacity_1150
 G  connected_order_arc_1151
 L  arc_capacity_1152
 G  connected_order_arc_1153
 L  arc_capacity_1154
 G  connected_order_arc_1155
 L  arc_capacity_1156
 G  connected_order_arc_1157
 L  arc_capacity_1158
 G  connected_order_arc_1159
 L  arc_capacity_1160
 G  connected_order_arc_1161
 L  arc_capacity_1162
 G  connected_order_arc_1163
 L  arc_capacity_1164
 L  arc_capacity_1165
 G  connected_order_arc_1166
 L  arc_capacity_1167
 G  connected_order_arc_1168
 L  arc_capacity_1169
 G  connected_order_arc_1170
 L  arc_capacity_1171
 G  connected_order_arc_1172
 L  arc_capacity_1173
 G  connected_order_arc_1174
 L  arc_capacity_1175
 G  connected_order_arc_1176
 L  arc_capacity_1177
 G  connected_order_arc_1178
 L  arc_capacity_1179
 G  connected_order_arc_1180
 L  arc_capacity_1181
 G  connected_order_arc_1182
 L  arc_capacity_1183
 G  connected_order_arc_1184
 L  arc_capacity_1185
 G  connected_order_arc_1186
 L  arc_capacity_1187
 L  arc_capacity_1188
 G  connected_order_arc_1189
 L  arc_capacity_1190
 G  connected_order_arc_1191
 L  arc_capacity_1192
 G  connected_order_arc_1193
 L  arc_capacity_1194
 G  connected_order_arc_1195
 L  arc_capacity_1196
 G  connected_order_arc_1197
 L  arc_capacity_1198
 G  connected_order_arc_1199
 L  arc_capacity_1200
 G  connected_order_arc_1201
 L  arc_capacity_1202
 G  connected_order_arc_1203
 L  arc_capacity_1204
 G  connected_order_arc_1205
 L  arc_capacity_1206
 G  connected_order_arc_1207
 L  arc_capacity_1208
 G  connected_order_arc_1209
 L  arc_capacity_1210
 L  arc_capacity_1211
 G  connected_order_arc_1212
 L  arc_capacity_1213
 G  connected_order_arc_1214
 L  arc_capacity_1215
 G  connected_order_arc_1216
 L  arc_capacity_1217
 G  connected_order_arc_1218
 L  arc_capacity_1219
 G  connected_order_arc_1220
 L  arc_capacity_1221
 G  connected_order_arc_1222
 L  arc_capacity_1223
 G  connected_order_arc_1224
 L  arc_capacity_1225
 G  connected_order_arc_1226
 L  arc_capacity_1227
 G  connected_order_arc_1228
 L  arc_capacity_1229
 G  connected_order_arc_1230
 L  arc_capacity_1231
 G  connected_order_arc_1232
 L  arc_capacity_1233
 L  arc_capacity_1234
 G  connected_order_arc_1235
 L  arc_capacity_1236
 G  connected_order_arc_1237
 L  arc_capacity_1238
 G  connected_order_arc_1239
 L  arc_capacity_1240
 G  connected_order_arc_1241
 L  arc_capacity_1242
 G  connected_order_arc_1243
 L  arc_capacity_1244
 G  connected_order_arc_1245
 L  arc_capacity_1246
 G  connected_order_arc_1247
 L  arc_capacity_1248
 G  connected_order_arc_1249
 L  arc_capacity_1250
 G  connected_order_arc_1251
 L  arc_capacity_1252
 G  connected_order_arc_1253
 L  arc_capacity_1254
 G  connected_order_arc_1255
 L  arc_capacity_1256
 L  arc_capacity_1257
 G  connected_order_arc_1258
 L  arc_capacity_1259
 G  connected_order_arc_1260
 L  arc_capacity_1261
 G  connected_order_arc_1262
 L  arc_capacity_1263
 G  connected_order_arc_1264
 L  arc_capacity_1265
 G  connected_order_arc_1266
 L  arc_capacity_1267
 G  connected_order_arc_1268
 L  arc_capacity_1269
 G  connected_order_arc_1270
 L  arc_capacity_1271
 G  connected_order_arc_1272
 L  arc_capacity_1273
 G  connected_order_arc_1274
 L  arc_capacity_1275
 G  connected_order_arc_1276
 L  arc_capacity_1277
 G  connected_order_arc_1278
 L  arc_capacity_1279
 L  arc_capacity_1280
 G  connected_order_arc_1281
 L  arc_capacity_1282
 G  connected_order_arc_1283
 L  arc_capacity_1284
 G  connected_order_arc_1285
 L  arc_capacity_1286
 G  connected_order_arc_1287
 L  arc_capacity_1288
 G  connected_order_arc_1289
 L  arc_capacity_1290
 G  connected_order_arc_1291
 L  arc_capacity_1292
 G  connected_order_arc_1293
 L  arc_capacity_1294
 G  connected_order_arc_1295
 L  arc_capacity_1296
 G  connected_order_arc_1297
 L  arc_capacity_1298
 G  connected_order_arc_1299
 L  arc_capacity_1300
 G  connected_order_arc_1301
 L  arc_capacity_1302
 L  arc_capacity_1303
 G  connected_order_arc_1304
 L  arc_capacity_1305
 G  connected_order_arc_1306
 L  arc_capacity_1307
 G  connected_order_arc_1308
 L  arc_capacity_1309
 G  connected_order_arc_1310
 L  arc_capacity_1311
 G  connected_order_arc_1312
 L  arc_capacity_1313
 G  connected_order_arc_1314
 L  arc_capacity_1315
 G  connected_order_arc_1316
 L  arc_capacity_1317
 G  connected_order_arc_1318
 L  arc_capacity_1319
 G  connected_order_arc_1320
 L  arc_capacity_1321
 G  connected_order_arc_1322
 L  arc_capacity_1323
 G  connected_order_arc_1324
 L  arc_capacity_1325
 L  arc_capacity_1326
 G  connected_order_arc_1327
 L  arc_capacity_1328
 G  connected_order_arc_1329
 L  arc_capacity_1330
 G  connected_order_arc_1331
 L  arc_capacity_1332
 G  connected_order_arc_1333
 L  arc_capacity_1334
 G  connected_order_arc_1335
 L  arc_capacity_1336
 G  connected_order_arc_1337
 L  arc_capacity_1338
 G  connected_order_arc_1339
 L  arc_capacity_1340
 G  connected_order_arc_1341
 L  arc_capacity_1342
 G  connected_order_arc_1343
 L  arc_capacity_1344
 G  connected_order_arc_1345
 L  arc_capacity_1346
 G  connected_order_arc_1347
 E  depot_departure_or_bypass_1348
 E  depot_return_or_bypass_1349
 E  out_degree_1350
 E  in_degree_1351
 G  order_active_lb_1352
 L  order_active_ub_1353
 E  segment_load_conservation_1354
 G  segment_prefix_lb_1355
 L  segment_prefix_ub_1356
 E  out_degree_1357
 E  in_degree_1358
 G  order_active_lb_1359
 L  order_active_ub_1360
 E  segment_load_conservation_1361
 G  segment_prefix_lb_1362
 L  segment_prefix_ub_1363
 E  out_degree_1364
 E  in_degree_1365
 G  order_active_lb_1366
 L  order_active_ub_1367
 E  segment_load_conservation_1368
 G  segment_prefix_lb_1369
 L  segment_prefix_ub_1370
 E  out_degree_1371
 E  in_degree_1372
 G  order_active_lb_1373
 L  order_active_ub_1374
 E  segment_load_conservation_1375
 G  segment_prefix_lb_1376
 L  segment_prefix_ub_1377
 E  out_degree_1378
 E  in_degree_1379
 G  order_active_lb_1380
 L  order_active_ub_1381
 E  service_visit_def_1382
 E  free_load_conservation_1383
 E  out_degree_1384
 E  in_degree_1385
 G  order_active_lb_1386
 L  order_active_ub_1387
 E  service_visit_def_1388
 E  free_load_conservation_1389
 E  out_degree_1390
 E  in_degree_1391
 G  order_active_lb_1392
 L  order_active_ub_1393
 E  service_visit_def_1394
 E  free_load_conservation_1395
 E  out_degree_1396
 E  in_degree_1397
 G  order_active_lb_1398
 L  order_active_ub_1399
 E  service_visit_def_1400
 E  free_load_conservation_1401
 E  out_degree_1402
 E  in_degree_1403
 G  order_active_lb_1404
 L  order_active_ub_1405
 E  service_visit_def_1406
 E  free_load_conservation_1407
 E  out_degree_1408
 E  in_degree_1409
 G  order_active_lb_1410
 L  order_active_ub_1411
 E  service_visit_def_1412
 E  free_load_conservation_1413
 E  out_degree_1414
 E  in_degree_1415
 G  order_active_lb_1416
 L  order_active_ub_1417
 E  service_visit_def_1418
 E  free_load_conservation_1419
 E  out_degree_1420
 E  in_degree_1421
 G  order_active_lb_1422
 L  order_active_ub_1423
 E  service_visit_def_1424
 E  free_load_conservation_1425
 G  fixed_segment_relative_order_1426
 G  fixed_segment_relative_order_1427
 G  fixed_segment_relative_order_1428
 L  original_T_including_depot_unload_1429
COLUMNS
    t         normalized_mass_24_33  -1
    t         normalized_mass_30_54  -1
    t         normalized_mass_34_89  -1
    t         normalized_mass_28_106  -1
    t         normalized_mass_29_131  -1
    t         normalized_mass_16_166  -1
    t         normalized_mass_27_183  -1
    t         normalized_mass_22_218  -1
    t         normalization_279  2.3861904761904764e+01
    t         full_original_Gini_280  -7.5914285714285768e+01
    q         OBJ       1
    q         parent_nonstrict_scope_222  1
    q         full_original_Gini_280  35
    MARKER    'MARKER'                 'INTORG'
    x_24_0    OBJ       2.9789603523644435e-02
    x_24_0    product_lb_0  -2.5233560635620170e-02
    x_24_0    product_ub_1  -4.1907802833807628e-02
    x_24_0    onehot_24_32  1
    x_24_0    parent_nonstrict_scope_222  5.9579207047288869e-02
    x_24_0    unique_nonzero_owner_281  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_0    product_lb_0  1
    w_24_0    product_ub_1  1
    w_24_0    normalized_mass_24_33  1
    w_24_0    full_original_Gini_280  -2.3861904761904764e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_1    OBJ       2.2342202642733327e-02
    x_24_1    product_lb_2  -2.5233560635620170e-02
    x_24_1    product_ub_3  -4.1907802833807628e-02
    x_24_1    onehot_24_32  1
    x_24_1    stock_lb_220  1
    x_24_1    stock_ub_221  1
    x_24_1    parent_nonstrict_scope_222  5.2131806166377762e-02
    x_24_1    unique_nonzero_owner_282  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_1    product_lb_2  1
    w_24_1    product_ub_3  1
    w_24_1    normalized_mass_24_33  1
    w_24_1    normalized_ratio_24_34  -0.125
    w_24_1    full_original_Gini_280  -2.0736904761904764e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_2    OBJ       1.4894801761822219e-02
    x_24_2    product_lb_4  -2.5233560635620170e-02
    x_24_2    product_ub_5  -4.1907802833807628e-02
    x_24_2    onehot_24_32  1
    x_24_2    stock_lb_220  2
    x_24_2    stock_ub_221  2
    x_24_2    parent_nonstrict_scope_222  4.4684405285466654e-02
    x_24_2    unique_nonzero_owner_283  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_2    product_lb_4  1
    w_24_2    product_ub_5  1
    w_24_2    normalized_mass_24_33  1
    w_24_2    normalized_ratio_24_34  -0.25
    w_24_2    full_original_Gini_280  -1.7611904761904764e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_3    OBJ       7.4474008809111113e-03
    x_24_3    product_lb_6  -2.5233560635620170e-02
    x_24_3    product_ub_7  -4.1907802833807628e-02
    x_24_3    onehot_24_32  1
    x_24_3    stock_lb_220  3
    x_24_3    stock_ub_221  3
    x_24_3    parent_nonstrict_scope_222  3.7237004404555546e-02
    x_24_3    unique_nonzero_owner_284  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_3    product_lb_6  1
    w_24_3    product_ub_7  1
    w_24_3    normalized_mass_24_33  1
    w_24_3    normalized_ratio_24_34  -0.375
    w_24_3    full_original_Gini_280  -1.4486904761904762e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_4    product_lb_8  -2.5233560635620170e-02
    x_24_4    product_ub_9  -4.1907802833807628e-02
    x_24_4    onehot_24_32  1
    x_24_4    stock_lb_220  4
    x_24_4    stock_ub_221  4
    x_24_4    parent_nonstrict_scope_222  2.9789603523644435e-02
    x_24_4    unique_nonzero_owner_285  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_4    product_lb_8  1
    w_24_4    product_ub_9  1
    w_24_4    normalized_mass_24_33  1
    w_24_4    normalized_ratio_24_34  -0.5
    w_24_4    full_original_Gini_280  -1.1361904761904762e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_5    OBJ       -7.4474008809111078e-03
    x_24_5    product_lb_10  -2.5233560635620170e-02
    x_24_5    product_ub_11  -4.1907802833807628e-02
    x_24_5    onehot_24_32  1
    x_24_5    stock_lb_220  5
    x_24_5    stock_ub_221  5
    x_24_5    parent_nonstrict_scope_222  2.2342202642733327e-02
    x_24_5    unique_nonzero_owner_286  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_5    product_lb_10  1
    w_24_5    product_ub_11  1
    w_24_5    normalized_mass_24_33  1
    w_24_5    normalized_ratio_24_34  -0.625
    w_24_5    full_original_Gini_280  -8.2369047619047624e+00
    MARKER    'MARKER'                 'INTORG'
    x_24_6    OBJ       -1.4894801761822217e-02
    x_24_6    product_lb_12  -2.5233560635620170e-02
    x_24_6    product_ub_13  -4.1907802833807628e-02
    x_24_6    onehot_24_32  1
    x_24_6    stock_lb_220  6
    x_24_6    stock_ub_221  6
    x_24_6    parent_nonstrict_scope_222  1.4894801761822217e-02
    x_24_6    unique_nonzero_owner_287  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_6    product_lb_12  1
    w_24_6    product_ub_13  1
    w_24_6    normalized_mass_24_33  1
    w_24_6    normalized_ratio_24_34  -0.75
    w_24_6    full_original_Gini_280  -5.2785714285714276e+00
    MARKER    'MARKER'                 'INTORG'
    x_24_7    OBJ       -2.2342202642733327e-02
    x_24_7    product_lb_14  -2.5233560635620170e-02
    x_24_7    product_ub_15  -4.1907802833807628e-02
    x_24_7    onehot_24_32  1
    x_24_7    stock_lb_220  7
    x_24_7    stock_ub_221  7
    x_24_7    parent_nonstrict_scope_222  7.4474008809111087e-03
    x_24_7    unique_nonzero_owner_288  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_7    product_lb_14  1
    w_24_7    product_ub_15  1
    w_24_7    normalized_mass_24_33  1
    w_24_7    normalized_ratio_24_34  -0.875
    w_24_7    full_original_Gini_280  -4.0130952380952385e+00
    MARKER    'MARKER'                 'INTORG'
    x_24_8    OBJ       -2.9789603523644435e-02
    x_24_8    product_lb_16  -2.5233560635620170e-02
    x_24_8    product_ub_17  -4.1907802833807628e-02
    x_24_8    onehot_24_32  1
    x_24_8    stock_lb_220  8
    x_24_8    stock_ub_221  8
    x_24_8    unique_nonzero_owner_289  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_8    product_lb_16  1
    w_24_8    product_ub_17  1
    w_24_8    normalized_mass_24_33  1
    w_24_8    normalized_ratio_24_34  -1
    w_24_8    full_original_Gini_280  -4.1380952380952385e+00
    MARKER    'MARKER'                 'INTORG'
    x_24_9    OBJ       -2.2342202642733327e-02
    x_24_9    product_lb_18  -2.5233560635620170e-02
    x_24_9    product_ub_19  -4.1907802833807628e-02
    x_24_9    onehot_24_32  1
    x_24_9    stock_lb_220  9
    x_24_9    stock_ub_221  9
    x_24_9    parent_nonstrict_scope_222  7.4474008809111087e-03
    x_24_9    unique_nonzero_owner_290  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_9    product_lb_18  1
    w_24_9    product_ub_19  1
    w_24_9    normalized_mass_24_33  1
    w_24_9    normalized_ratio_24_34  -1.125
    w_24_9    full_original_Gini_280  -7.2630952380952385e+00
    MARKER    'MARKER'                 'INTORG'
    x_24_10   OBJ       -1.4894801761822217e-02
    x_24_10   product_lb_20  -2.5233560635620170e-02
    x_24_10   product_ub_21  -4.1907802833807628e-02
    x_24_10   onehot_24_32  1
    x_24_10   stock_lb_220  10
    x_24_10   stock_ub_221  10
    x_24_10   parent_nonstrict_scope_222  1.4894801761822217e-02
    x_24_10   unique_nonzero_owner_291  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_10   product_lb_20  1
    w_24_10   product_ub_21  1
    w_24_10   normalized_mass_24_33  1
    w_24_10   normalized_ratio_24_34  -1.25
    w_24_10   full_original_Gini_280  -1.0388095238095238e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_11   OBJ       -7.4474008809111078e-03
    x_24_11   product_lb_22  -2.5233560635620170e-02
    x_24_11   product_ub_23  -4.1907802833807628e-02
    x_24_11   onehot_24_32  1
    x_24_11   stock_lb_220  11
    x_24_11   stock_ub_221  11
    x_24_11   parent_nonstrict_scope_222  2.2342202642733327e-02
    x_24_11   unique_nonzero_owner_292  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_11   product_lb_22  1
    w_24_11   product_ub_23  1
    w_24_11   normalized_mass_24_33  1
    w_24_11   normalized_ratio_24_34  -1.375
    w_24_11   full_original_Gini_280  -1.3513095238095238e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_12   product_lb_24  -2.5233560635620170e-02
    x_24_12   product_ub_25  -4.1907802833807628e-02
    x_24_12   onehot_24_32  1
    x_24_12   stock_lb_220  12
    x_24_12   stock_ub_221  12
    x_24_12   parent_nonstrict_scope_222  2.9789603523644435e-02
    x_24_12   unique_nonzero_owner_293  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_12   product_lb_24  1
    w_24_12   product_ub_25  1
    w_24_12   normalized_mass_24_33  1
    w_24_12   normalized_ratio_24_34  -1.5
    w_24_12   full_original_Gini_280  -1.6638095238095239e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_13   OBJ       7.4474008809111113e-03
    x_24_13   product_lb_26  -2.5233560635620170e-02
    x_24_13   product_ub_27  -4.1907802833807628e-02
    x_24_13   onehot_24_32  1
    x_24_13   stock_lb_220  13
    x_24_13   stock_ub_221  13
    x_24_13   parent_nonstrict_scope_222  3.7237004404555546e-02
    MARKER    'MARKER'                 'INTEND'
    w_24_13   product_lb_26  1
    w_24_13   product_ub_27  1
    w_24_13   normalized_mass_24_33  1
    w_24_13   normalized_ratio_24_34  -1.625
    w_24_13   full_original_Gini_280  -2.0013095238095236e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_14   OBJ       1.4894801761822219e-02
    x_24_14   product_lb_28  -2.5233560635620170e-02
    x_24_14   product_ub_29  -4.1907802833807628e-02
    x_24_14   onehot_24_32  1
    x_24_14   stock_lb_220  14
    x_24_14   stock_ub_221  14
    x_24_14   parent_nonstrict_scope_222  4.4684405285466654e-02
    x_24_14   unique_nonzero_owner_294  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_14   product_lb_28  1
    w_24_14   product_ub_29  1
    w_24_14   normalized_mass_24_33  1
    w_24_14   normalized_ratio_24_34  -1.75
    w_24_14   full_original_Gini_280  -2.3388095238095236e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_15   OBJ       2.2342202642733327e-02
    x_24_15   product_lb_30  -2.5233560635620170e-02
    x_24_15   product_ub_31  -4.1907802833807628e-02
    x_24_15   onehot_24_32  1
    x_24_15   stock_lb_220  15
    x_24_15   stock_ub_221  15
    x_24_15   parent_nonstrict_scope_222  5.2131806166377762e-02
    x_24_15   unique_nonzero_owner_295  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_15   product_lb_30  1
    w_24_15   product_ub_31  1
    w_24_15   normalized_mass_24_33  1
    w_24_15   normalized_ratio_24_34  -1.875
    w_24_15   full_original_Gini_280  -2.6763095238095232e+01
    rho_24    normalized_ratio_24_34  1
    rho_24    block_pair_pos_227  -1
    rho_24    block_pair_neg_228  1
    rho_24    block_pair_pos_229  -1
    rho_24    block_pair_neg_230  1
    rho_24    block_pair_pos_231  -1
    rho_24    block_pair_neg_232  1
    rho_24    block_pair_pos_233  -1
    rho_24    block_pair_neg_234  1
    rho_24    block_pair_pos_235  -1
    rho_24    block_pair_neg_236  1
    rho_24    block_pair_pos_237  -1
    rho_24    block_pair_neg_238  1
    rho_24    block_pair_pos_239  -1
    rho_24    block_pair_neg_240  1
    rho_24    normalization_279  1
    MARKER    'MARKER'                 'INTORG'
    x_30_0    OBJ       7.4474103065332977e-03
    x_30_0    product_lb_35  -2.5233560635620170e-02
    x_30_0    product_ub_36  -4.1907802833807628e-02
    x_30_0    onehot_30_53  1
    x_30_0    parent_nonstrict_scope_222  1.4894820613066595e-02
    x_30_0    unique_nonzero_owner_296  -1
    MARKER    'MARKER'                 'INTEND'
    w_30_0    product_lb_35  1
    w_30_0    product_ub_36  1
    w_30_0    normalized_mass_30_54  1
    w_30_0    full_original_Gini_280  -2.3861904761904764e+01
    MARKER    'MARKER'                 'INTORG'
    x_30_1    OBJ       3.7237051532666493e-03
    x_30_1    product_lb_37  -2.5233560635620170e-02
    x_30_1    product_ub_38  -4.1907802833807628e-02
    x_30_1    onehot_30_53  1
    x_30_1    stock_lb_220  1
    x_30_1    stock_ub_221  1
    x_30_1    parent_nonstrict_scope_222  1.1171115459799947e-02
    x_30_1    unique_nonzero_owner_297  -1
    MARKER    'MARKER'                 'INTEND'
    w_30_1    product_lb_37  1
    w_30_1    product_ub_38  1
    w_30_1    normalized_mass_30_54  1
    w_30_1    normalized_ratio_30_55  -0.25
    w_30_1    full_original_Gini_280  -1.7611904761904764e+01
    MARKER    'MARKER'                 'INTORG'
    x_30_2    product_lb_39  -2.5233560635620170e-02
    x_30_2    product_ub_40  -4.1907802833807628e-02
    x_30_2    onehot_30_53  1
    x_30_2    stock_lb_220  2
    x_30_2    stock_ub_221  2
    x_30_2    parent_nonstrict_scope_222  7.4474103065332977e-03
    x_30_2    unique_nonzero_owner_298  -1
    MARKER    'MARKER'                 'INTEND'
    w_30_2    product_lb_39  1
    w_30_2    product_ub_40  1
    w_30_2    normalized_mass_30_54  1
    w_30_2    normalized_ratio_30_55  -0.5
    w_30_2    full_original_Gini_280  -1.1361904761904762e+01
    MARKER    'MARKER'                 'INTORG'
    x_30_3    OBJ       -3.7237051532666488e-03
    x_30_3    product_lb_41  -2.5233560635620170e-02
    x_30_3    product_ub_42  -4.1907802833807628e-02
    x_30_3    onehot_30_53  1
    x_30_3    stock_lb_220  3
    x_30_3    stock_ub_221  3
    x_30_3    parent_nonstrict_scope_222  3.7237051532666488e-03
    x_30_3    unique_nonzero_owner_299  -1
    MARKER    'MARKER'                 'INTEND'
    w_30_3    product_lb_41  1
    w_30_3    product_ub_42  1
    w_30_3    normalized_mass_30_54  1
    w_30_3    normalized_ratio_30_55  -0.75
    w_30_3    full_original_Gini_280  -5.2785714285714276e+00
    MARKER    'MARKER'                 'INTORG'
    x_30_4    OBJ       -7.4474103065332977e-03
    x_30_4    product_lb_43  -2.5233560635620170e-02
    x_30_4    product_ub_44  -4.1907802833807628e-02
    x_30_4    onehot_30_53  1
    x_30_4    stock_lb_220  4
    x_30_4    stock_ub_221  4
    x_30_4    unique_nonzero_owner_300  -1
    MARKER    'MARKER'                 'INTEND'
    w_30_4    product_lb_43  1
    w_30_4    product_ub_44  1
    w_30_4    normalized_mass_30_54  1
    w_30_4    normalized_ratio_30_55  -1
    w_30_4    full_original_Gini_280  -4.1380952380952385e+00
    MARKER    'MARKER'                 'INTORG'
    x_30_5    OBJ       -3.7237051532666488e-03
    x_30_5    product_lb_45  -2.5233560635620170e-02
    x_30_5    product_ub_46  -4.1907802833807628e-02
    x_30_5    onehot_30_53  1
    x_30_5    stock_lb_220  5
    x_30_5    stock_ub_221  5
    x_30_5    parent_nonstrict_scope_222  3.7237051532666488e-03
    MARKER    'MARKER'                 'INTEND'
    w_30_5    product_lb_45  1
    w_30_5    product_ub_46  1
    w_30_5    normalized_mass_30_54  1
    w_30_5    normalized_ratio_30_55  -1.25
    w_30_5    full_original_Gini_280  -1.0388095238095238e+01
    MARKER    'MARKER'                 'INTORG'
    x_30_6    product_lb_47  -2.5233560635620170e-02
    x_30_6    product_ub_48  -4.1907802833807628e-02
    x_30_6    onehot_30_53  1
    x_30_6    stock_lb_220  6
    x_30_6    stock_ub_221  6
    x_30_6    parent_nonstrict_scope_222  7.4474103065332977e-03
    x_30_6    unique_nonzero_owner_301  -1
    MARKER    'MARKER'                 'INTEND'
    w_30_6    product_lb_47  1
    w_30_6    product_ub_48  1
    w_30_6    normalized_mass_30_54  1
    w_30_6    normalized_ratio_30_55  -1.5
    w_30_6    full_original_Gini_280  -1.6638095238095239e+01
    MARKER    'MARKER'                 'INTORG'
    x_30_7    OBJ       3.7237051532666493e-03
    x_30_7    product_lb_49  -2.5233560635620170e-02
    x_30_7    product_ub_50  -4.1907802833807628e-02
    x_30_7    onehot_30_53  1
    x_30_7    stock_lb_220  7
    x_30_7    stock_ub_221  7
    x_30_7    parent_nonstrict_scope_222  1.1171115459799947e-02
    x_30_7    unique_nonzero_owner_302  -1
    MARKER    'MARKER'                 'INTEND'
    w_30_7    product_lb_49  1
    w_30_7    product_ub_50  1
    w_30_7    normalized_mass_30_54  1
    w_30_7    normalized_ratio_30_55  -1.75
    w_30_7    full_original_Gini_280  -2.3388095238095236e+01
    MARKER    'MARKER'                 'INTORG'
    x_30_8    OBJ       7.4474103065332977e-03
    x_30_8    product_lb_51  -2.5233560635620170e-02
    x_30_8    product_ub_52  -4.1907802833807628e-02
    x_30_8    onehot_30_53  1
    x_30_8    stock_lb_220  8
    x_30_8    stock_ub_221  8
    x_30_8    parent_nonstrict_scope_222  1.4894820613066595e-02
    x_30_8    unique_nonzero_owner_303  -1
    MARKER    'MARKER'                 'INTEND'
    w_30_8    product_lb_51  1
    w_30_8    product_ub_52  1
    w_30_8    normalized_mass_30_54  1
    w_30_8    normalized_ratio_30_55  -2
    w_30_8    full_original_Gini_280  -3.0138095238095232e+01
    rho_30    normalized_ratio_30_55  1
    rho_30    block_pair_pos_237  1
    rho_30    block_pair_neg_238  -1
    rho_30    block_pair_pos_257  -1
    rho_30    block_pair_neg_258  1
    rho_30    block_pair_pos_259  -1
    rho_30    block_pair_neg_260  1
    rho_30    block_pair_pos_261  -1
    rho_30    block_pair_neg_262  1
    rho_30    block_pair_pos_263  -1
    rho_30    block_pair_neg_264  1
    rho_30    block_pair_pos_265  -1
    rho_30    block_pair_neg_266  1
    rho_30    block_pair_pos_267  -1
    rho_30    block_pair_neg_268  1
    rho_30    normalization_279  1
    MARKER    'MARKER'                 'INTORG'
    x_34_0    OBJ       2.9789603523644435e-02
    x_34_0    product_lb_56  -2.5233560635620170e-02
    x_34_0    product_ub_57  -4.1907802833807628e-02
    x_34_0    onehot_34_88  1
    x_34_0    parent_nonstrict_scope_222  5.9579207047288869e-02
    x_34_0    unique_nonzero_owner_304  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_0    product_lb_56  1
    w_34_0    product_ub_57  1
    w_34_0    normalized_mass_34_89  1
    w_34_0    full_original_Gini_280  -2.3861904761904764e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_1    OBJ       2.2342202642733327e-02
    x_34_1    product_lb_58  -2.5233560635620170e-02
    x_34_1    product_ub_59  -4.1907802833807628e-02
    x_34_1    onehot_34_88  1
    x_34_1    stock_lb_220  1
    x_34_1    stock_ub_221  1
    x_34_1    parent_nonstrict_scope_222  5.2131806166377762e-02
    x_34_1    unique_nonzero_owner_305  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_1    product_lb_58  1
    w_34_1    product_ub_59  1
    w_34_1    normalized_mass_34_89  1
    w_34_1    normalized_ratio_34_90  -0.125
    w_34_1    full_original_Gini_280  -2.0736904761904764e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_2    OBJ       1.4894801761822219e-02
    x_34_2    product_lb_60  -2.5233560635620170e-02
    x_34_2    product_ub_61  -4.1907802833807628e-02
    x_34_2    onehot_34_88  1
    x_34_2    stock_lb_220  2
    x_34_2    stock_ub_221  2
    x_34_2    parent_nonstrict_scope_222  4.4684405285466654e-02
    MARKER    'MARKER'                 'INTEND'
    w_34_2    product_lb_60  1
    w_34_2    product_ub_61  1
    w_34_2    normalized_mass_34_89  1
    w_34_2    normalized_ratio_34_90  -0.25
    w_34_2    full_original_Gini_280  -1.7611904761904764e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_3    OBJ       7.4474008809111113e-03
    x_34_3    product_lb_62  -2.5233560635620170e-02
    x_34_3    product_ub_63  -4.1907802833807628e-02
    x_34_3    onehot_34_88  1
    x_34_3    stock_lb_220  3
    x_34_3    stock_ub_221  3
    x_34_3    parent_nonstrict_scope_222  3.7237004404555546e-02
    x_34_3    unique_nonzero_owner_306  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_3    product_lb_62  1
    w_34_3    product_ub_63  1
    w_34_3    normalized_mass_34_89  1
    w_34_3    normalized_ratio_34_90  -0.375
    w_34_3    full_original_Gini_280  -1.4486904761904762e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_4    product_lb_64  -2.5233560635620170e-02
    x_34_4    product_ub_65  -4.1907802833807628e-02
    x_34_4    onehot_34_88  1
    x_34_4    stock_lb_220  4
    x_34_4    stock_ub_221  4
    x_34_4    parent_nonstrict_scope_222  2.9789603523644435e-02
    x_34_4    unique_nonzero_owner_307  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_4    product_lb_64  1
    w_34_4    product_ub_65  1
    w_34_4    normalized_mass_34_89  1
    w_34_4    normalized_ratio_34_90  -0.5
    w_34_4    full_original_Gini_280  -1.1361904761904762e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_5    OBJ       -7.4474008809111078e-03
    x_34_5    product_lb_66  -2.5233560635620170e-02
    x_34_5    product_ub_67  -4.1907802833807628e-02
    x_34_5    onehot_34_88  1
    x_34_5    stock_lb_220  5
    x_34_5    stock_ub_221  5
    x_34_5    parent_nonstrict_scope_222  2.2342202642733327e-02
    x_34_5    unique_nonzero_owner_308  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_5    product_lb_66  1
    w_34_5    product_ub_67  1
    w_34_5    normalized_mass_34_89  1
    w_34_5    normalized_ratio_34_90  -0.625
    w_34_5    full_original_Gini_280  -8.2369047619047624e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_6    OBJ       -1.4894801761822217e-02
    x_34_6    product_lb_68  -2.5233560635620170e-02
    x_34_6    product_ub_69  -4.1907802833807628e-02
    x_34_6    onehot_34_88  1
    x_34_6    stock_lb_220  6
    x_34_6    stock_ub_221  6
    x_34_6    parent_nonstrict_scope_222  1.4894801761822217e-02
    x_34_6    unique_nonzero_owner_309  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_6    product_lb_68  1
    w_34_6    product_ub_69  1
    w_34_6    normalized_mass_34_89  1
    w_34_6    normalized_ratio_34_90  -0.75
    w_34_6    full_original_Gini_280  -5.2785714285714276e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_7    OBJ       -2.2342202642733327e-02
    x_34_7    product_lb_70  -2.5233560635620170e-02
    x_34_7    product_ub_71  -4.1907802833807628e-02
    x_34_7    onehot_34_88  1
    x_34_7    stock_lb_220  7
    x_34_7    stock_ub_221  7
    x_34_7    parent_nonstrict_scope_222  7.4474008809111087e-03
    x_34_7    unique_nonzero_owner_310  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_7    product_lb_70  1
    w_34_7    product_ub_71  1
    w_34_7    normalized_mass_34_89  1
    w_34_7    normalized_ratio_34_90  -0.875
    w_34_7    full_original_Gini_280  -4.0130952380952385e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_8    OBJ       -2.9789603523644435e-02
    x_34_8    product_lb_72  -2.5233560635620170e-02
    x_34_8    product_ub_73  -4.1907802833807628e-02
    x_34_8    onehot_34_88  1
    x_34_8    stock_lb_220  8
    x_34_8    stock_ub_221  8
    x_34_8    unique_nonzero_owner_311  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_8    product_lb_72  1
    w_34_8    product_ub_73  1
    w_34_8    normalized_mass_34_89  1
    w_34_8    normalized_ratio_34_90  -1
    w_34_8    full_original_Gini_280  -4.1380952380952385e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_9    OBJ       -2.2342202642733327e-02
    x_34_9    product_lb_74  -2.5233560635620170e-02
    x_34_9    product_ub_75  -4.1907802833807628e-02
    x_34_9    onehot_34_88  1
    x_34_9    stock_lb_220  9
    x_34_9    stock_ub_221  9
    x_34_9    parent_nonstrict_scope_222  7.4474008809111087e-03
    x_34_9    unique_nonzero_owner_312  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_9    product_lb_74  1
    w_34_9    product_ub_75  1
    w_34_9    normalized_mass_34_89  1
    w_34_9    normalized_ratio_34_90  -1.125
    w_34_9    full_original_Gini_280  -7.2630952380952385e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_10   OBJ       -1.4894801761822217e-02
    x_34_10   product_lb_76  -2.5233560635620170e-02
    x_34_10   product_ub_77  -4.1907802833807628e-02
    x_34_10   onehot_34_88  1
    x_34_10   stock_lb_220  10
    x_34_10   stock_ub_221  10
    x_34_10   parent_nonstrict_scope_222  1.4894801761822217e-02
    x_34_10   unique_nonzero_owner_313  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_10   product_lb_76  1
    w_34_10   product_ub_77  1
    w_34_10   normalized_mass_34_89  1
    w_34_10   normalized_ratio_34_90  -1.25
    w_34_10   full_original_Gini_280  -1.0388095238095238e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_11   OBJ       -7.4474008809111078e-03
    x_34_11   product_lb_78  -2.5233560635620170e-02
    x_34_11   product_ub_79  -4.1907802833807628e-02
    x_34_11   onehot_34_88  1
    x_34_11   stock_lb_220  11
    x_34_11   stock_ub_221  11
    x_34_11   parent_nonstrict_scope_222  2.2342202642733327e-02
    x_34_11   unique_nonzero_owner_314  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_11   product_lb_78  1
    w_34_11   product_ub_79  1
    w_34_11   normalized_mass_34_89  1
    w_34_11   normalized_ratio_34_90  -1.375
    w_34_11   full_original_Gini_280  -1.3513095238095238e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_12   product_lb_80  -2.5233560635620170e-02
    x_34_12   product_ub_81  -4.1907802833807628e-02
    x_34_12   onehot_34_88  1
    x_34_12   stock_lb_220  12
    x_34_12   stock_ub_221  12
    x_34_12   parent_nonstrict_scope_222  2.9789603523644435e-02
    x_34_12   unique_nonzero_owner_315  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_12   product_lb_80  1
    w_34_12   product_ub_81  1
    w_34_12   normalized_mass_34_89  1
    w_34_12   normalized_ratio_34_90  -1.5
    w_34_12   full_original_Gini_280  -1.6638095238095239e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_13   OBJ       7.4474008809111113e-03
    x_34_13   product_lb_82  -2.5233560635620170e-02
    x_34_13   product_ub_83  -4.1907802833807628e-02
    x_34_13   onehot_34_88  1
    x_34_13   stock_lb_220  13
    x_34_13   stock_ub_221  13
    x_34_13   parent_nonstrict_scope_222  3.7237004404555546e-02
    x_34_13   unique_nonzero_owner_316  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_13   product_lb_82  1
    w_34_13   product_ub_83  1
    w_34_13   normalized_mass_34_89  1
    w_34_13   normalized_ratio_34_90  -1.625
    w_34_13   full_original_Gini_280  -2.0013095238095236e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_14   OBJ       1.4894801761822219e-02
    x_34_14   product_lb_84  -2.5233560635620170e-02
    x_34_14   product_ub_85  -4.1907802833807628e-02
    x_34_14   onehot_34_88  1
    x_34_14   stock_lb_220  14
    x_34_14   stock_ub_221  14
    x_34_14   parent_nonstrict_scope_222  4.4684405285466654e-02
    x_34_14   unique_nonzero_owner_317  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_14   product_lb_84  1
    w_34_14   product_ub_85  1
    w_34_14   normalized_mass_34_89  1
    w_34_14   normalized_ratio_34_90  -1.75
    w_34_14   full_original_Gini_280  -2.3388095238095236e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_15   OBJ       2.2342202642733327e-02
    x_34_15   product_lb_86  -2.5233560635620170e-02
    x_34_15   product_ub_87  -4.1907802833807628e-02
    x_34_15   onehot_34_88  1
    x_34_15   stock_lb_220  15
    x_34_15   stock_ub_221  15
    x_34_15   parent_nonstrict_scope_222  5.2131806166377762e-02
    x_34_15   unique_nonzero_owner_318  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_15   product_lb_86  1
    w_34_15   product_ub_87  1
    w_34_15   normalized_mass_34_89  1
    w_34_15   normalized_ratio_34_90  -1.875
    w_34_15   full_original_Gini_280  -2.6763095238095232e+01
    rho_34    normalized_ratio_34_90  1
    rho_34    block_pair_pos_239  1
    rho_34    block_pair_neg_240  -1
    rho_34    block_pair_pos_267  1
    rho_34    block_pair_neg_268  -1
    rho_34    block_pair_pos_269  -1
    rho_34    block_pair_neg_270  1
    rho_34    block_pair_pos_271  -1
    rho_34    block_pair_neg_272  1
    rho_34    block_pair_pos_273  -1
    rho_34    block_pair_neg_274  1
    rho_34    block_pair_pos_275  -1
    rho_34    block_pair_neg_276  1
    rho_34    block_pair_pos_277  -1
    rho_34    block_pair_neg_278  1
    rho_34    normalization_279  1
    MARKER    'MARKER'                 'INTORG'
    x_28_0    OBJ       4.1891612282083379e-03
    x_28_0    product_lb_91  -2.5233560635620170e-02
    x_28_0    product_ub_92  -4.1907802833807628e-02
    x_28_0    onehot_28_105  1
    x_28_0    parent_nonstrict_scope_222  8.3783224564166758e-03
    x_28_0    unique_nonzero_owner_319  -1
    MARKER    'MARKER'                 'INTEND'
    w_28_0    product_lb_91  1
    w_28_0    product_ub_92  1
    w_28_0    normalized_mass_28_106  1
    w_28_0    full_original_Gini_280  -2.3861904761904764e+01
    MARKER    'MARKER'                 'INTORG'
    x_28_1    OBJ       1.3963870760694466e-03
    x_28_1    product_lb_93  -2.5233560635620170e-02
    x_28_1    product_ub_94  -4.1907802833807628e-02
    x_28_1    onehot_28_105  1
    x_28_1    stock_lb_220  1
    x_28_1    stock_ub_221  1
    x_28_1    parent_nonstrict_scope_222  5.5855483042777845e-03
    MARKER    'MARKER'                 'INTEND'
    w_28_1    product_lb_93  1
    w_28_1    product_ub_94  1
    w_28_1    normalized_mass_28_106  1
    w_28_1    normalized_ratio_28_107  -3.3333333333333331e-01
    w_28_1    full_original_Gini_280  -1.5528571428571425e+01
    MARKER    'MARKER'                 'INTORG'
    x_28_2    OBJ       -1.3963870760694457e-03
    x_28_2    product_lb_95  -2.5233560635620170e-02
    x_28_2    product_ub_96  -4.1907802833807628e-02
    x_28_2    onehot_28_105  1
    x_28_2    stock_lb_220  2
    x_28_2    stock_ub_221  2
    x_28_2    parent_nonstrict_scope_222  2.7927741521388922e-03
    x_28_2    unique_nonzero_owner_320  -1
    MARKER    'MARKER'                 'INTEND'
    w_28_2    product_lb_95  1
    w_28_2    product_ub_96  1
    w_28_2    normalized_mass_28_106  1
    w_28_2    normalized_ratio_28_107  -6.6666666666666663e-01
    w_28_2    full_original_Gini_280  -7.1952380952380937e+00
    MARKER    'MARKER'                 'INTORG'
    x_28_3    OBJ       -4.1891612282083379e-03
    x_28_3    product_lb_97  -2.5233560635620170e-02
    x_28_3    product_ub_98  -4.1907802833807628e-02
    x_28_3    onehot_28_105  1
    x_28_3    stock_lb_220  3
    x_28_3    stock_ub_221  3
    x_28_3    unique_nonzero_owner_321  -1
    MARKER    'MARKER'                 'INTEND'
    w_28_3    product_lb_97  1
    w_28_3    product_ub_98  1
    w_28_3    normalized_mass_28_106  1
    w_28_3    normalized_ratio_28_107  -1
    w_28_3    full_original_Gini_280  -4.1380952380952385e+00
    MARKER    'MARKER'                 'INTORG'
    x_28_4    OBJ       -1.3963870760694466e-03
    x_28_4    product_lb_99  -2.5233560635620170e-02
    x_28_4    product_ub_100  -4.1907802833807628e-02
    x_28_4    onehot_28_105  1
    x_28_4    stock_lb_220  4
    x_28_4    stock_ub_221  4
    x_28_4    parent_nonstrict_scope_222  2.7927741521388914e-03
    x_28_4    unique_nonzero_owner_322  -1
    MARKER    'MARKER'                 'INTEND'
    w_28_4    product_lb_99  1
    w_28_4    product_ub_100  1
    w_28_4    normalized_mass_28_106  1
    w_28_4    normalized_ratio_28_107  -1.3333333333333333e+00
    w_28_4    full_original_Gini_280  -1.2471428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_28_5    OBJ       1.3963870760694448e-03
    x_28_5    product_lb_101  -2.5233560635620170e-02
    x_28_5    product_ub_102  -4.1907802833807628e-02
    x_28_5    onehot_28_105  1
    x_28_5    stock_lb_220  5
    x_28_5    stock_ub_221  5
    x_28_5    parent_nonstrict_scope_222  5.5855483042777827e-03
    x_28_5    unique_nonzero_owner_323  -1
    MARKER    'MARKER'                 'INTEND'
    w_28_5    product_lb_101  1
    w_28_5    product_ub_102  1
    w_28_5    normalized_mass_28_106  1
    w_28_5    normalized_ratio_28_107  -1.6666666666666665e+00
    w_28_5    full_original_Gini_280  -2.1138095238095236e+01
    MARKER    'MARKER'                 'INTORG'
    x_28_6    OBJ       4.1891612282083379e-03
    x_28_6    product_lb_103  -2.5233560635620170e-02
    x_28_6    product_ub_104  -4.1907802833807628e-02
    x_28_6    onehot_28_105  1
    x_28_6    stock_lb_220  6
    x_28_6    stock_ub_221  6
    x_28_6    parent_nonstrict_scope_222  8.3783224564166758e-03
    x_28_6    unique_nonzero_owner_324  -1
    MARKER    'MARKER'                 'INTEND'
    w_28_6    product_lb_103  1
    w_28_6    product_ub_104  1
    w_28_6    normalized_mass_28_106  1
    w_28_6    normalized_ratio_28_107  -2
    w_28_6    full_original_Gini_280  -3.0138095238095232e+01
    rho_28    normalized_ratio_28_107  1
    rho_28    block_pair_pos_233  1
    rho_28    block_pair_neg_234  -1
    rho_28    block_pair_pos_243  -1
    rho_28    block_pair_neg_244  1
    rho_28    block_pair_pos_245  -1
    rho_28    block_pair_neg_246  1
    rho_28    block_pair_pos_247  -1
    rho_28    block_pair_neg_248  1
    rho_28    block_pair_pos_249  -1
    rho_28    block_pair_neg_250  1
    rho_28    block_pair_pos_263  1
    rho_28    block_pair_neg_264  -1
    rho_28    block_pair_pos_275  1
    rho_28    block_pair_neg_276  -1
    rho_28    normalization_279  1
    MARKER    'MARKER'                 'INTORG'
    x_29_0    OBJ       1.1636571534741636e-02
    x_29_0    product_lb_108  -2.5233560635620170e-02
    x_29_0    product_ub_109  -4.1907802833807628e-02
    x_29_0    onehot_29_130  1
    x_29_0    parent_nonstrict_scope_222  2.3273143069483273e-02
    x_29_0    unique_nonzero_owner_325  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_0    product_lb_108  1
    w_29_0    product_ub_109  1
    w_29_0    normalized_mass_29_131  1
    w_29_0    full_original_Gini_280  -2.3861904761904764e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_1    OBJ       6.9819429208449833e-03
    x_29_1    product_lb_110  -2.5233560635620170e-02
    x_29_1    product_ub_111  -4.1907802833807628e-02
    x_29_1    onehot_29_130  1
    x_29_1    stock_lb_220  1
    x_29_1    stock_ub_221  1
    x_29_1    parent_nonstrict_scope_222  1.8618514455586620e-02
    MARKER    'MARKER'                 'INTEND'
    w_29_1    product_lb_110  1
    w_29_1    product_ub_111  1
    w_29_1    normalized_mass_29_131  1
    w_29_1    normalized_ratio_29_132  -0.2
    w_29_1    full_original_Gini_280  -1.8861904761904768e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_2    OBJ       2.3273143069483266e-03
    x_29_2    product_lb_112  -2.5233560635620170e-02
    x_29_2    product_ub_113  -4.1907802833807628e-02
    x_29_2    onehot_29_130  1
    x_29_2    stock_lb_220  2
    x_29_2    stock_ub_221  2
    x_29_2    parent_nonstrict_scope_222  1.3963885841689963e-02
    x_29_2    unique_nonzero_owner_326  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_2    product_lb_112  1
    w_29_2    product_ub_113  1
    w_29_2    normalized_mass_29_131  1
    w_29_2    normalized_ratio_29_132  -0.4
    w_29_2    full_original_Gini_280  -1.3861904761904757e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_3    OBJ       -0.00232731430694833
    x_29_3    product_lb_114  -2.5233560635620170e-02
    x_29_3    product_ub_115  -4.1907802833807628e-02
    x_29_3    onehot_29_130  1
    x_29_3    stock_lb_220  3
    x_29_3    stock_ub_221  3
    x_29_3    parent_nonstrict_scope_222  9.3092572277933064e-03
    x_29_3    unique_nonzero_owner_327  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_3    product_lb_114  1
    w_29_3    product_ub_115  1
    w_29_3    normalized_mass_29_131  1
    w_29_3    normalized_ratio_29_132  -6.0000000000000009e-01
    w_29_3    full_original_Gini_280  -8.8619047619047642e+00
    MARKER    'MARKER'                 'INTORG'
    x_29_4    OBJ       -6.9819429208449833e-03
    x_29_4    product_lb_116  -2.5233560635620170e-02
    x_29_4    product_ub_117  -4.1907802833807628e-02
    x_29_4    onehot_29_130  1
    x_29_4    stock_lb_220  4
    x_29_4    stock_ub_221  4
    x_29_4    parent_nonstrict_scope_222  4.6546286138966532e-03
    x_29_4    unique_nonzero_owner_328  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_4    product_lb_116  1
    w_29_4    product_ub_117  1
    w_29_4    normalized_mass_29_131  1
    w_29_4    normalized_ratio_29_132  -0.8
    w_29_4    full_original_Gini_280  -4.5285714285714285e+00
    MARKER    'MARKER'                 'INTORG'
    x_29_5    OBJ       -1.1636571534741636e-02
    x_29_5    product_lb_118  -2.5233560635620170e-02
    x_29_5    product_ub_119  -4.1907802833807628e-02
    x_29_5    onehot_29_130  1
    x_29_5    stock_lb_220  5
    x_29_5    stock_ub_221  5
    x_29_5    unique_nonzero_owner_329  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_5    product_lb_118  1
    w_29_5    product_ub_119  1
    w_29_5    normalized_mass_29_131  1
    w_29_5    normalized_ratio_29_132  -1
    w_29_5    full_original_Gini_280  -4.1380952380952385e+00
    MARKER    'MARKER'                 'INTORG'
    x_29_6    OBJ       -6.9819429208449781e-03
    x_29_6    product_lb_120  -2.5233560635620170e-02
    x_29_6    product_ub_121  -4.1907802833807628e-02
    x_29_6    onehot_29_130  1
    x_29_6    stock_lb_220  6
    x_29_6    stock_ub_221  6
    x_29_6    parent_nonstrict_scope_222  4.6546286138966584e-03
    x_29_6    unique_nonzero_owner_330  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_6    product_lb_120  1
    w_29_6    product_ub_121  1
    w_29_6    normalized_mass_29_131  1
    w_29_6    normalized_ratio_29_132  -1.2000000000000002e+00
    w_29_6    full_original_Gini_280  -9.1380952380952429e+00
    MARKER    'MARKER'                 'INTORG'
    x_29_7    OBJ       -2.3273143069483249e-03
    x_29_7    product_lb_122  -2.5233560635620170e-02
    x_29_7    product_ub_123  -4.1907802833807628e-02
    x_29_7    onehot_29_130  1
    x_29_7    stock_lb_220  7
    x_29_7    stock_ub_221  7
    x_29_7    parent_nonstrict_scope_222  9.3092572277933116e-03
    x_29_7    unique_nonzero_owner_331  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_7    product_lb_122  1
    w_29_7    product_ub_123  1
    w_29_7    normalized_mass_29_131  1
    w_29_7    normalized_ratio_29_132  -1.4000000000000001e+00
    w_29_7    full_original_Gini_280  -1.4138095238095245e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_8    OBJ       0.00232731430694833
    x_29_8    product_lb_124  -2.5233560635620170e-02
    x_29_8    product_ub_125  -4.1907802833807628e-02
    x_29_8    onehot_29_130  1
    x_29_8    stock_lb_220  8
    x_29_8    stock_ub_221  8
    x_29_8    parent_nonstrict_scope_222  1.3963885841689967e-02
    x_29_8    unique_nonzero_owner_332  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_8    product_lb_124  1
    w_29_8    product_ub_125  1
    w_29_8    normalized_mass_29_131  1
    w_29_8    normalized_ratio_29_132  -1.6
    w_29_8    full_original_Gini_280  -1.9338095238095242e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_9    OBJ       6.9819429208449833e-03
    x_29_9    product_lb_126  -2.5233560635620170e-02
    x_29_9    product_ub_127  -4.1907802833807628e-02
    x_29_9    onehot_29_130  1
    x_29_9    stock_lb_220  9
    x_29_9    stock_ub_221  9
    x_29_9    parent_nonstrict_scope_222  1.8618514455586620e-02
    x_29_9    unique_nonzero_owner_333  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_9    product_lb_126  1
    w_29_9    product_ub_127  1
    w_29_9    normalized_mass_29_131  1
    w_29_9    normalized_ratio_29_132  -1.8
    w_29_9    full_original_Gini_280  -2.4738095238095248e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_10   OBJ       1.1636571534741636e-02
    x_29_10   product_lb_128  -2.5233560635620170e-02
    x_29_10   product_ub_129  -4.1907802833807628e-02
    x_29_10   onehot_29_130  1
    x_29_10   stock_lb_220  10
    x_29_10   stock_ub_221  10
    x_29_10   parent_nonstrict_scope_222  2.3273143069483273e-02
    x_29_10   unique_nonzero_owner_334  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_10   product_lb_128  1
    w_29_10   product_ub_129  1
    w_29_10   normalized_mass_29_131  1
    w_29_10   normalized_ratio_29_132  -2
    w_29_10   full_original_Gini_280  -3.0138095238095232e+01
    rho_29    normalized_ratio_29_132  1
    rho_29    block_pair_pos_235  1
    rho_29    block_pair_neg_236  -1
    rho_29    block_pair_pos_249  1
    rho_29    block_pair_neg_250  -1
    rho_29    block_pair_pos_251  -1
    rho_29    block_pair_neg_252  1
    rho_29    block_pair_pos_253  -1
    rho_29    block_pair_neg_254  1
    rho_29    block_pair_pos_255  -1
    rho_29    block_pair_neg_256  1
    rho_29    block_pair_pos_265  1
    rho_29    block_pair_neg_266  -1
    rho_29    block_pair_pos_277  1
    rho_29    block_pair_neg_278  -1
    rho_29    normalization_279  1
    MARKER    'MARKER'                 'INTORG'
    x_16_0    OBJ       2.9789603523644435e-02
    x_16_0    product_lb_133  -2.5233560635620170e-02
    x_16_0    product_ub_134  -4.1907802833807628e-02
    x_16_0    onehot_16_165  1
    x_16_0    parent_nonstrict_scope_222  5.9579207047288869e-02
    x_16_0    unique_nonzero_owner_335  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_0    product_lb_133  1
    w_16_0    product_ub_134  1
    w_16_0    normalized_mass_16_166  1
    w_16_0    full_original_Gini_280  -2.3861904761904764e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_1    OBJ       2.2342202642733327e-02
    x_16_1    product_lb_135  -2.5233560635620170e-02
    x_16_1    product_ub_136  -4.1907802833807628e-02
    x_16_1    onehot_16_165  1
    x_16_1    stock_lb_220  1
    x_16_1    stock_ub_221  1
    x_16_1    parent_nonstrict_scope_222  5.2131806166377762e-02
    x_16_1    unique_nonzero_owner_336  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_1    product_lb_135  1
    w_16_1    product_ub_136  1
    w_16_1    normalized_mass_16_166  1
    w_16_1    normalized_ratio_16_167  -0.125
    w_16_1    full_original_Gini_280  -2.0736904761904764e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_2    OBJ       1.4894801761822219e-02
    x_16_2    product_lb_137  -2.5233560635620170e-02
    x_16_2    product_ub_138  -4.1907802833807628e-02
    x_16_2    onehot_16_165  1
    x_16_2    stock_lb_220  2
    x_16_2    stock_ub_221  2
    x_16_2    parent_nonstrict_scope_222  4.4684405285466654e-02
    MARKER    'MARKER'                 'INTEND'
    w_16_2    product_lb_137  1
    w_16_2    product_ub_138  1
    w_16_2    normalized_mass_16_166  1
    w_16_2    normalized_ratio_16_167  -0.25
    w_16_2    full_original_Gini_280  -1.7611904761904764e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_3    OBJ       7.4474008809111113e-03
    x_16_3    product_lb_139  -2.5233560635620170e-02
    x_16_3    product_ub_140  -4.1907802833807628e-02
    x_16_3    onehot_16_165  1
    x_16_3    stock_lb_220  3
    x_16_3    stock_ub_221  3
    x_16_3    parent_nonstrict_scope_222  3.7237004404555546e-02
    x_16_3    unique_nonzero_owner_337  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_3    product_lb_139  1
    w_16_3    product_ub_140  1
    w_16_3    normalized_mass_16_166  1
    w_16_3    normalized_ratio_16_167  -0.375
    w_16_3    full_original_Gini_280  -1.4486904761904762e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_4    product_lb_141  -2.5233560635620170e-02
    x_16_4    product_ub_142  -4.1907802833807628e-02
    x_16_4    onehot_16_165  1
    x_16_4    stock_lb_220  4
    x_16_4    stock_ub_221  4
    x_16_4    parent_nonstrict_scope_222  2.9789603523644435e-02
    x_16_4    unique_nonzero_owner_338  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_4    product_lb_141  1
    w_16_4    product_ub_142  1
    w_16_4    normalized_mass_16_166  1
    w_16_4    normalized_ratio_16_167  -0.5
    w_16_4    full_original_Gini_280  -1.1361904761904762e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_5    OBJ       -7.4474008809111078e-03
    x_16_5    product_lb_143  -2.5233560635620170e-02
    x_16_5    product_ub_144  -4.1907802833807628e-02
    x_16_5    onehot_16_165  1
    x_16_5    stock_lb_220  5
    x_16_5    stock_ub_221  5
    x_16_5    parent_nonstrict_scope_222  2.2342202642733327e-02
    x_16_5    unique_nonzero_owner_339  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_5    product_lb_143  1
    w_16_5    product_ub_144  1
    w_16_5    normalized_mass_16_166  1
    w_16_5    normalized_ratio_16_167  -0.625
    w_16_5    full_original_Gini_280  -8.2369047619047624e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_6    OBJ       -1.4894801761822217e-02
    x_16_6    product_lb_145  -2.5233560635620170e-02
    x_16_6    product_ub_146  -4.1907802833807628e-02
    x_16_6    onehot_16_165  1
    x_16_6    stock_lb_220  6
    x_16_6    stock_ub_221  6
    x_16_6    parent_nonstrict_scope_222  1.4894801761822217e-02
    x_16_6    unique_nonzero_owner_340  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_6    product_lb_145  1
    w_16_6    product_ub_146  1
    w_16_6    normalized_mass_16_166  1
    w_16_6    normalized_ratio_16_167  -0.75
    w_16_6    full_original_Gini_280  -5.2785714285714276e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_7    OBJ       -2.2342202642733327e-02
    x_16_7    product_lb_147  -2.5233560635620170e-02
    x_16_7    product_ub_148  -4.1907802833807628e-02
    x_16_7    onehot_16_165  1
    x_16_7    stock_lb_220  7
    x_16_7    stock_ub_221  7
    x_16_7    parent_nonstrict_scope_222  7.4474008809111087e-03
    x_16_7    unique_nonzero_owner_341  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_7    product_lb_147  1
    w_16_7    product_ub_148  1
    w_16_7    normalized_mass_16_166  1
    w_16_7    normalized_ratio_16_167  -0.875
    w_16_7    full_original_Gini_280  -4.0130952380952385e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_8    OBJ       -2.9789603523644435e-02
    x_16_8    product_lb_149  -2.5233560635620170e-02
    x_16_8    product_ub_150  -4.1907802833807628e-02
    x_16_8    onehot_16_165  1
    x_16_8    stock_lb_220  8
    x_16_8    stock_ub_221  8
    x_16_8    unique_nonzero_owner_342  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_8    product_lb_149  1
    w_16_8    product_ub_150  1
    w_16_8    normalized_mass_16_166  1
    w_16_8    normalized_ratio_16_167  -1
    w_16_8    full_original_Gini_280  -4.1380952380952385e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_9    OBJ       -2.2342202642733327e-02
    x_16_9    product_lb_151  -2.5233560635620170e-02
    x_16_9    product_ub_152  -4.1907802833807628e-02
    x_16_9    onehot_16_165  1
    x_16_9    stock_lb_220  9
    x_16_9    stock_ub_221  9
    x_16_9    parent_nonstrict_scope_222  7.4474008809111087e-03
    x_16_9    unique_nonzero_owner_343  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_9    product_lb_151  1
    w_16_9    product_ub_152  1
    w_16_9    normalized_mass_16_166  1
    w_16_9    normalized_ratio_16_167  -1.125
    w_16_9    full_original_Gini_280  -7.2630952380952385e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_10   OBJ       -1.4894801761822217e-02
    x_16_10   product_lb_153  -2.5233560635620170e-02
    x_16_10   product_ub_154  -4.1907802833807628e-02
    x_16_10   onehot_16_165  1
    x_16_10   stock_lb_220  10
    x_16_10   stock_ub_221  10
    x_16_10   parent_nonstrict_scope_222  1.4894801761822217e-02
    x_16_10   unique_nonzero_owner_344  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_10   product_lb_153  1
    w_16_10   product_ub_154  1
    w_16_10   normalized_mass_16_166  1
    w_16_10   normalized_ratio_16_167  -1.25
    w_16_10   full_original_Gini_280  -1.0388095238095238e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_11   OBJ       -7.4474008809111078e-03
    x_16_11   product_lb_155  -2.5233560635620170e-02
    x_16_11   product_ub_156  -4.1907802833807628e-02
    x_16_11   onehot_16_165  1
    x_16_11   stock_lb_220  11
    x_16_11   stock_ub_221  11
    x_16_11   parent_nonstrict_scope_222  2.2342202642733327e-02
    x_16_11   unique_nonzero_owner_345  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_11   product_lb_155  1
    w_16_11   product_ub_156  1
    w_16_11   normalized_mass_16_166  1
    w_16_11   normalized_ratio_16_167  -1.375
    w_16_11   full_original_Gini_280  -1.3513095238095238e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_12   product_lb_157  -2.5233560635620170e-02
    x_16_12   product_ub_158  -4.1907802833807628e-02
    x_16_12   onehot_16_165  1
    x_16_12   stock_lb_220  12
    x_16_12   stock_ub_221  12
    x_16_12   parent_nonstrict_scope_222  2.9789603523644435e-02
    x_16_12   unique_nonzero_owner_346  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_12   product_lb_157  1
    w_16_12   product_ub_158  1
    w_16_12   normalized_mass_16_166  1
    w_16_12   normalized_ratio_16_167  -1.5
    w_16_12   full_original_Gini_280  -1.6638095238095239e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_13   OBJ       7.4474008809111113e-03
    x_16_13   product_lb_159  -2.5233560635620170e-02
    x_16_13   product_ub_160  -4.1907802833807628e-02
    x_16_13   onehot_16_165  1
    x_16_13   stock_lb_220  13
    x_16_13   stock_ub_221  13
    x_16_13   parent_nonstrict_scope_222  3.7237004404555546e-02
    x_16_13   unique_nonzero_owner_347  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_13   product_lb_159  1
    w_16_13   product_ub_160  1
    w_16_13   normalized_mass_16_166  1
    w_16_13   normalized_ratio_16_167  -1.625
    w_16_13   full_original_Gini_280  -2.0013095238095236e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_14   OBJ       1.4894801761822219e-02
    x_16_14   product_lb_161  -2.5233560635620170e-02
    x_16_14   product_ub_162  -4.1907802833807628e-02
    x_16_14   onehot_16_165  1
    x_16_14   stock_lb_220  14
    x_16_14   stock_ub_221  14
    x_16_14   parent_nonstrict_scope_222  4.4684405285466654e-02
    x_16_14   unique_nonzero_owner_348  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_14   product_lb_161  1
    w_16_14   product_ub_162  1
    w_16_14   normalized_mass_16_166  1
    w_16_14   normalized_ratio_16_167  -1.75
    w_16_14   full_original_Gini_280  -2.3388095238095236e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_15   OBJ       2.2342202642733327e-02
    x_16_15   product_lb_163  -2.5233560635620170e-02
    x_16_15   product_ub_164  -4.1907802833807628e-02
    x_16_15   onehot_16_165  1
    x_16_15   stock_lb_220  15
    x_16_15   stock_ub_221  15
    x_16_15   parent_nonstrict_scope_222  5.2131806166377762e-02
    x_16_15   unique_nonzero_owner_349  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_15   product_lb_163  1
    w_16_15   product_ub_164  1
    w_16_15   normalized_mass_16_166  1
    w_16_15   normalized_ratio_16_167  -1.875
    w_16_15   full_original_Gini_280  -2.6763095238095232e+01
    rho_16    normalized_ratio_16_167  1
    rho_16    block_pair_pos_223  -1
    rho_16    block_pair_neg_224  1
    rho_16    block_pair_pos_225  -1
    rho_16    block_pair_neg_226  1
    rho_16    block_pair_pos_227  1
    rho_16    block_pair_neg_228  -1
    rho_16    block_pair_pos_243  1
    rho_16    block_pair_neg_244  -1
    rho_16    block_pair_pos_251  1
    rho_16    block_pair_neg_252  -1
    rho_16    block_pair_pos_257  1
    rho_16    block_pair_neg_258  -1
    rho_16    block_pair_pos_269  1
    rho_16    block_pair_neg_270  -1
    rho_16    normalization_279  1
    MARKER    'MARKER'                 'INTORG'
    x_27_0    OBJ       4.1891612282083379e-03
    x_27_0    product_lb_168  -2.5233560635620170e-02
    x_27_0    product_ub_169  -4.1907802833807628e-02
    x_27_0    onehot_27_182  1
    x_27_0    parent_nonstrict_scope_222  8.3783224564166758e-03
    MARKER    'MARKER'                 'INTEND'
    w_27_0    product_lb_168  1
    w_27_0    product_ub_169  1
    w_27_0    normalized_mass_27_183  1
    w_27_0    full_original_Gini_280  -2.3861904761904764e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_1    OBJ       1.3963870760694466e-03
    x_27_1    product_lb_170  -2.5233560635620170e-02
    x_27_1    product_ub_171  -4.1907802833807628e-02
    x_27_1    onehot_27_182  1
    x_27_1    stock_lb_220  1
    x_27_1    stock_ub_221  1
    x_27_1    parent_nonstrict_scope_222  5.5855483042777845e-03
    x_27_1    unique_nonzero_owner_350  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_1    product_lb_170  1
    w_27_1    product_ub_171  1
    w_27_1    normalized_mass_27_183  1
    w_27_1    normalized_ratio_27_184  -3.3333333333333331e-01
    w_27_1    full_original_Gini_280  -1.5528571428571425e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_2    OBJ       -1.3963870760694457e-03
    x_27_2    product_lb_172  -2.5233560635620170e-02
    x_27_2    product_ub_173  -4.1907802833807628e-02
    x_27_2    onehot_27_182  1
    x_27_2    stock_lb_220  2
    x_27_2    stock_ub_221  2
    x_27_2    parent_nonstrict_scope_222  2.7927741521388922e-03
    x_27_2    unique_nonzero_owner_351  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_2    product_lb_172  1
    w_27_2    product_ub_173  1
    w_27_2    normalized_mass_27_183  1
    w_27_2    normalized_ratio_27_184  -6.6666666666666663e-01
    w_27_2    full_original_Gini_280  -7.1952380952380937e+00
    MARKER    'MARKER'                 'INTORG'
    x_27_3    OBJ       -4.1891612282083379e-03
    x_27_3    product_lb_174  -2.5233560635620170e-02
    x_27_3    product_ub_175  -4.1907802833807628e-02
    x_27_3    onehot_27_182  1
    x_27_3    stock_lb_220  3
    x_27_3    stock_ub_221  3
    x_27_3    unique_nonzero_owner_352  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_3    product_lb_174  1
    w_27_3    product_ub_175  1
    w_27_3    normalized_mass_27_183  1
    w_27_3    normalized_ratio_27_184  -1
    w_27_3    full_original_Gini_280  -4.1380952380952385e+00
    MARKER    'MARKER'                 'INTORG'
    x_27_4    OBJ       -1.3963870760694466e-03
    x_27_4    product_lb_176  -2.5233560635620170e-02
    x_27_4    product_ub_177  -4.1907802833807628e-02
    x_27_4    onehot_27_182  1
    x_27_4    stock_lb_220  4
    x_27_4    stock_ub_221  4
    x_27_4    parent_nonstrict_scope_222  2.7927741521388914e-03
    x_27_4    unique_nonzero_owner_353  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_4    product_lb_176  1
    w_27_4    product_ub_177  1
    w_27_4    normalized_mass_27_183  1
    w_27_4    normalized_ratio_27_184  -1.3333333333333333e+00
    w_27_4    full_original_Gini_280  -1.2471428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_5    OBJ       1.3963870760694448e-03
    x_27_5    product_lb_178  -2.5233560635620170e-02
    x_27_5    product_ub_179  -4.1907802833807628e-02
    x_27_5    onehot_27_182  1
    x_27_5    stock_lb_220  5
    x_27_5    stock_ub_221  5
    x_27_5    parent_nonstrict_scope_222  5.5855483042777827e-03
    x_27_5    unique_nonzero_owner_354  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_5    product_lb_178  1
    w_27_5    product_ub_179  1
    w_27_5    normalized_mass_27_183  1
    w_27_5    normalized_ratio_27_184  -1.6666666666666665e+00
    w_27_5    full_original_Gini_280  -2.1138095238095236e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_6    OBJ       4.1891612282083379e-03
    x_27_6    product_lb_180  -2.5233560635620170e-02
    x_27_6    product_ub_181  -4.1907802833807628e-02
    x_27_6    onehot_27_182  1
    x_27_6    stock_lb_220  6
    x_27_6    stock_ub_221  6
    x_27_6    parent_nonstrict_scope_222  8.3783224564166758e-03
    x_27_6    unique_nonzero_owner_355  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_6    product_lb_180  1
    w_27_6    product_ub_181  1
    w_27_6    normalized_mass_27_183  1
    w_27_6    normalized_ratio_27_184  -2
    w_27_6    full_original_Gini_280  -3.0138095238095232e+01
    rho_27    normalized_ratio_27_184  1
    rho_27    block_pair_pos_225  1
    rho_27    block_pair_neg_226  -1
    rho_27    block_pair_pos_231  1
    rho_27    block_pair_neg_232  -1
    rho_27    block_pair_pos_241  -1
    rho_27    block_pair_neg_242  1
    rho_27    block_pair_pos_247  1
    rho_27    block_pair_neg_248  -1
    rho_27    block_pair_pos_255  1
    rho_27    block_pair_neg_256  -1
    rho_27    block_pair_pos_261  1
    rho_27    block_pair_neg_262  -1
    rho_27    block_pair_pos_273  1
    rho_27    block_pair_neg_274  -1
    rho_27    normalization_279  1
    MARKER    'MARKER'                 'INTORG'
    x_22_0    OBJ       1.9549429837111887e-02
    x_22_0    product_lb_185  -2.5233560635620170e-02
    x_22_0    product_ub_186  -4.1907802833807628e-02
    x_22_0    onehot_22_217  1
    x_22_0    parent_nonstrict_scope_222  0.0456153362865944
    x_22_0    unique_nonzero_owner_356  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_0    product_lb_185  1
    w_22_0    product_ub_186  1
    w_22_0    normalized_mass_22_218  1
    w_22_0    full_original_Gini_280  -2.3861904761904764e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_1    OBJ       1.3032953224741260e-02
    x_22_1    product_lb_187  -2.5233560635620170e-02
    x_22_1    product_ub_188  -4.1907802833807628e-02
    x_22_1    onehot_22_217  1
    x_22_1    stock_lb_220  1
    x_22_1    stock_ub_221  1
    x_22_1    parent_nonstrict_scope_222  3.9098859674223774e-02
    x_22_1    unique_nonzero_owner_357  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_1    product_lb_187  1
    w_22_1    product_ub_188  1
    w_22_1    normalized_mass_22_218  1
    w_22_1    normalized_ratio_22_219  -1.4285714285714285e-01
    w_22_1    full_original_Gini_280  -2.0290476190476195e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_2    OBJ       6.5164766123706336e-03
    x_22_2    product_lb_189  -2.5233560635620170e-02
    x_22_2    product_ub_190  -4.1907802833807628e-02
    x_22_2    onehot_22_217  1
    x_22_2    stock_lb_220  2
    x_22_2    stock_ub_221  2
    x_22_2    parent_nonstrict_scope_222  3.2582383061853147e-02
    MARKER    'MARKER'                 'INTEND'
    w_22_2    product_lb_189  1
    w_22_2    product_ub_190  1
    w_22_2    normalized_mass_22_218  1
    w_22_2    normalized_ratio_22_219  -2.8571428571428570e-01
    w_22_2    full_original_Gini_280  -1.6719047619047615e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_3    product_lb_191  -2.5233560635620170e-02
    x_22_3    product_ub_192  -4.1907802833807628e-02
    x_22_3    onehot_22_217  1
    x_22_3    stock_lb_220  3
    x_22_3    stock_ub_221  3
    x_22_3    parent_nonstrict_scope_222  2.6065906449482514e-02
    x_22_3    unique_nonzero_owner_358  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_3    product_lb_191  1
    w_22_3    product_ub_192  1
    w_22_3    normalized_mass_22_218  1
    w_22_3    normalized_ratio_22_219  -4.2857142857142855e-01
    w_22_3    full_original_Gini_280  -1.3147619047619045e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_4    OBJ       -6.5164766123706266e-03
    x_22_4    product_lb_193  -2.5233560635620170e-02
    x_22_4    product_ub_194  -4.1907802833807628e-02
    x_22_4    onehot_22_217  1
    x_22_4    stock_lb_220  4
    x_22_4    stock_ub_221  4
    x_22_4    parent_nonstrict_scope_222  1.9549429837111887e-02
    x_22_4    unique_nonzero_owner_359  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_4    product_lb_193  1
    w_22_4    product_ub_194  1
    w_22_4    normalized_mass_22_218  1
    w_22_4    normalized_ratio_22_219  -5.7142857142857140e-01
    w_22_4    full_original_Gini_280  -9.5761904761904812e+00
    MARKER    'MARKER'                 'INTORG'
    x_22_5    OBJ       -1.3032953224741252e-02
    x_22_5    product_lb_195  -2.5233560635620170e-02
    x_22_5    product_ub_196  -4.1907802833807628e-02
    x_22_5    onehot_22_217  1
    x_22_5    stock_lb_220  5
    x_22_5    stock_ub_221  5
    x_22_5    parent_nonstrict_scope_222  1.3032953224741262e-02
    x_22_5    unique_nonzero_owner_360  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_5    product_lb_195  1
    w_22_5    product_ub_196  1
    w_22_5    normalized_mass_22_218  1
    w_22_5    normalized_ratio_22_219  -7.1428571428571419e-01
    w_22_5    full_original_Gini_280  -6.1000000000000005e+00
    MARKER    'MARKER'                 'INTORG'
    x_22_6    OBJ       -1.9549429837111883e-02
    x_22_6    product_lb_197  -2.5233560635620170e-02
    x_22_6    product_ub_198  -4.1907802833807628e-02
    x_22_6    onehot_22_217  1
    x_22_6    stock_lb_220  6
    x_22_6    stock_ub_221  6
    x_22_6    parent_nonstrict_scope_222  6.5164766123706310e-03
    x_22_6    unique_nonzero_owner_361  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_6    product_lb_197  1
    w_22_6    product_ub_198  1
    w_22_6    normalized_mass_22_218  1
    w_22_6    normalized_ratio_22_219  -8.5714285714285710e-01
    w_22_6    full_original_Gini_280  -3.9952380952380948e+00
    MARKER    'MARKER'                 'INTORG'
    x_22_7    OBJ       -2.6065906449482514e-02
    x_22_7    product_lb_199  -2.5233560635620170e-02
    x_22_7    product_ub_200  -4.1907802833807628e-02
    x_22_7    onehot_22_217  1
    x_22_7    stock_lb_220  7
    x_22_7    stock_ub_221  7
    x_22_7    unique_nonzero_owner_362  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_7    product_lb_199  1
    w_22_7    product_ub_200  1
    w_22_7    normalized_mass_22_218  1
    w_22_7    normalized_ratio_22_219  -1
    w_22_7    full_original_Gini_280  -4.1380952380952385e+00
    MARKER    'MARKER'                 'INTORG'
    x_22_8    OBJ       -1.9549429837111887e-02
    x_22_8    product_lb_201  -2.5233560635620170e-02
    x_22_8    product_ub_202  -4.1907802833807628e-02
    x_22_8    onehot_22_217  1
    x_22_8    stock_lb_220  8
    x_22_8    stock_ub_221  8
    x_22_8    parent_nonstrict_scope_222  6.5164766123706258e-03
    x_22_8    unique_nonzero_owner_363  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_8    product_lb_201  1
    w_22_8    product_ub_202  1
    w_22_8    normalized_mass_22_218  1
    w_22_8    normalized_ratio_22_219  -1.1428571428571428e+00
    w_22_8    full_original_Gini_280  -7.7095238095238052e+00
    MARKER    'MARKER'                 'INTORG'
    x_22_9    OBJ       -1.3032953224741262e-02
    x_22_9    product_lb_203  -2.5233560635620170e-02
    x_22_9    product_ub_204  -4.1907802833807628e-02
    x_22_9    onehot_22_217  1
    x_22_9    stock_lb_220  9
    x_22_9    stock_ub_221  9
    x_22_9    parent_nonstrict_scope_222  1.3032953224741252e-02
    x_22_9    unique_nonzero_owner_364  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_9    product_lb_203  1
    w_22_9    product_ub_204  1
    w_22_9    normalized_mass_22_218  1
    w_22_9    normalized_ratio_22_219  -1.2857142857142856e+00
    w_22_9    full_original_Gini_280  -1.1280952380952375e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_10   OBJ       -6.5164766123706371e-03
    x_22_10   product_lb_205  -2.5233560635620170e-02
    x_22_10   product_ub_206  -4.1907802833807628e-02
    x_22_10   onehot_22_217  1
    x_22_10   stock_lb_220  10
    x_22_10   stock_ub_221  10
    x_22_10   parent_nonstrict_scope_222  1.9549429837111876e-02
    x_22_10   unique_nonzero_owner_365  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_10   product_lb_205  1
    w_22_10   product_ub_206  1
    w_22_10   normalized_mass_22_218  1
    w_22_10   normalized_ratio_22_219  -1.4285714285714284e+00
    w_22_10   full_original_Gini_280  -1.4852380952380953e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_11   product_lb_207  -2.5233560635620170e-02
    x_22_11   product_ub_208  -4.1907802833807628e-02
    x_22_11   onehot_22_217  1
    x_22_11   stock_lb_220  11
    x_22_11   stock_ub_221  11
    x_22_11   parent_nonstrict_scope_222  2.6065906449482514e-02
    x_22_11   unique_nonzero_owner_366  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_11   product_lb_207  1
    w_22_11   product_ub_208  1
    w_22_11   normalized_mass_22_218  1
    w_22_11   normalized_ratio_22_219  -1.5714285714285714e+00
    w_22_11   full_original_Gini_280  -1.8566666666666666e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_12   OBJ       6.5164766123706266e-03
    x_22_12   product_lb_209  -2.5233560635620170e-02
    x_22_12   product_ub_210  -4.1907802833807628e-02
    x_22_12   onehot_22_217  1
    x_22_12   stock_lb_220  12
    x_22_12   stock_ub_221  12
    x_22_12   parent_nonstrict_scope_222  3.2582383061853140e-02
    x_22_12   unique_nonzero_owner_367  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_12   product_lb_209  1
    w_22_12   product_ub_210  1
    w_22_12   normalized_mass_22_218  1
    w_22_12   normalized_ratio_22_219  -1.7142857142857142e+00
    w_22_12   full_original_Gini_280  -2.2423809523809521e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_13   OBJ       1.3032953224741253e-02
    x_22_13   product_lb_211  -2.5233560635620170e-02
    x_22_13   product_ub_212  -4.1907802833807628e-02
    x_22_13   onehot_22_217  1
    x_22_13   stock_lb_220  13
    x_22_13   stock_ub_221  13
    x_22_13   parent_nonstrict_scope_222  3.9098859674223767e-02
    x_22_13   unique_nonzero_owner_368  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_13   product_lb_211  1
    w_22_13   product_ub_212  1
    w_22_13   normalized_mass_22_218  1
    w_22_13   normalized_ratio_22_219  -1.8571428571428570e+00
    w_22_13   full_original_Gini_280  -2.6280952380952385e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_14   OBJ       1.9549429837111887e-02
    x_22_14   product_lb_213  -2.5233560635620170e-02
    x_22_14   product_ub_214  -4.1907802833807628e-02
    x_22_14   onehot_22_217  1
    x_22_14   stock_lb_220  14
    x_22_14   stock_ub_221  14
    x_22_14   parent_nonstrict_scope_222  0.0456153362865944
    x_22_14   unique_nonzero_owner_369  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_14   product_lb_213  1
    w_22_14   product_ub_214  1
    w_22_14   normalized_mass_22_218  1
    w_22_14   normalized_ratio_22_219  -2
    w_22_14   full_original_Gini_280  -3.0138095238095232e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_15   OBJ       2.6065906449482514e-02
    x_22_15   product_lb_215  -2.5233560635620170e-02
    x_22_15   product_ub_216  -4.1907802833807628e-02
    x_22_15   onehot_22_217  1
    x_22_15   stock_lb_220  15
    x_22_15   stock_ub_221  15
    x_22_15   parent_nonstrict_scope_222  5.2131812898965027e-02
    x_22_15   unique_nonzero_owner_370  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_15   product_lb_215  1
    w_22_15   product_ub_216  1
    w_22_15   normalized_mass_22_218  1
    w_22_15   normalized_ratio_22_219  -2.1428571428571428e+00
    w_22_15   full_original_Gini_280  -3.3995238095238093e+01
    rho_22    normalized_ratio_22_219  1
    rho_22    block_pair_pos_223  1
    rho_22    block_pair_neg_224  -1
    rho_22    block_pair_pos_229  1
    rho_22    block_pair_neg_230  -1
    rho_22    block_pair_pos_241  1
    rho_22    block_pair_neg_242  -1
    rho_22    block_pair_pos_245  1
    rho_22    block_pair_neg_246  -1
    rho_22    block_pair_pos_253  1
    rho_22    block_pair_neg_254  -1
    rho_22    block_pair_pos_259  1
    rho_22    block_pair_neg_260  -1
    rho_22    block_pair_pos_271  1
    rho_22    block_pair_neg_272  -1
    rho_22    normalization_279  1
    a_24_30   block_pair_pos_237  1
    a_24_30   block_pair_neg_238  1
    a_24_30   full_original_Gini_280  -1
    a_24_34   block_pair_pos_239  1
    a_24_34   block_pair_neg_240  1
    a_24_34   full_original_Gini_280  -1
    a_24_28   block_pair_pos_233  1
    a_24_28   block_pair_neg_234  1
    a_24_28   full_original_Gini_280  -1
    a_24_29   block_pair_pos_235  1
    a_24_29   block_pair_neg_236  1
    a_24_29   full_original_Gini_280  -1
    a_24_16   block_pair_pos_227  1
    a_24_16   block_pair_neg_228  1
    a_24_16   full_original_Gini_280  -1
    a_24_27   block_pair_pos_231  1
    a_24_27   block_pair_neg_232  1
    a_24_27   full_original_Gini_280  -1
    a_24_22   block_pair_pos_229  1
    a_24_22   block_pair_neg_230  1
    a_24_22   full_original_Gini_280  -1
    a_30_34   block_pair_pos_267  1
    a_30_34   block_pair_neg_268  1
    a_30_34   full_original_Gini_280  -1
    a_30_28   block_pair_pos_263  1
    a_30_28   block_pair_neg_264  1
    a_30_28   full_original_Gini_280  -1
    a_30_29   block_pair_pos_265  1
    a_30_29   block_pair_neg_266  1
    a_30_29   full_original_Gini_280  -1
    a_30_16   block_pair_pos_257  1
    a_30_16   block_pair_neg_258  1
    a_30_16   full_original_Gini_280  -1
    a_30_27   block_pair_pos_261  1
    a_30_27   block_pair_neg_262  1
    a_30_27   full_original_Gini_280  -1
    a_30_22   block_pair_pos_259  1
    a_30_22   block_pair_neg_260  1
    a_30_22   full_original_Gini_280  -1
    a_34_28   block_pair_pos_275  1
    a_34_28   block_pair_neg_276  1
    a_34_28   full_original_Gini_280  -1
    a_34_29   block_pair_pos_277  1
    a_34_29   block_pair_neg_278  1
    a_34_29   full_original_Gini_280  -1
    a_34_16   block_pair_pos_269  1
    a_34_16   block_pair_neg_270  1
    a_34_16   full_original_Gini_280  -1
    a_34_27   block_pair_pos_273  1
    a_34_27   block_pair_neg_274  1
    a_34_27   full_original_Gini_280  -1
    a_34_22   block_pair_pos_271  1
    a_34_22   block_pair_neg_272  1
    a_34_22   full_original_Gini_280  -1
    a_28_29   block_pair_pos_249  1
    a_28_29   block_pair_neg_250  1
    a_28_29   full_original_Gini_280  -1
    a_28_16   block_pair_pos_243  1
    a_28_16   block_pair_neg_244  1
    a_28_16   full_original_Gini_280  -1
    a_28_27   block_pair_pos_247  1
    a_28_27   block_pair_neg_248  1
    a_28_27   full_original_Gini_280  -1
    a_28_22   block_pair_pos_245  1
    a_28_22   block_pair_neg_246  1
    a_28_22   full_original_Gini_280  -1
    a_29_16   block_pair_pos_251  1
    a_29_16   block_pair_neg_252  1
    a_29_16   full_original_Gini_280  -1
    a_29_27   block_pair_pos_255  1
    a_29_27   block_pair_neg_256  1
    a_29_27   full_original_Gini_280  -1
    a_29_22   block_pair_pos_253  1
    a_29_22   block_pair_neg_254  1
    a_29_22   full_original_Gini_280  -1
    a_16_27   block_pair_pos_225  1
    a_16_27   block_pair_neg_226  1
    a_16_27   full_original_Gini_280  -1
    a_16_22   block_pair_pos_223  1
    a_16_22   block_pair_neg_224  1
    a_16_22   full_original_Gini_280  -1
    a_27_22   block_pair_pos_241  1
    a_27_22   block_pair_neg_242  1
    a_27_22   full_original_Gini_280  -1
    MARKER    'MARKER'                 'INTORG'
    service_0_24_0  unique_nonzero_owner_281  1
    service_0_24_0  service_visit_def_694  1
    service_0_24_0  free_load_conservation_695  -13
    service_0_24_0  original_T_including_depot_unload_741  1560
    service_0_24_1  unique_nonzero_owner_282  1
    service_0_24_1  service_visit_def_694  1
    service_0_24_1  free_load_conservation_695  -12
    service_0_24_1  original_T_including_depot_unload_741  1440
    service_0_24_2  unique_nonzero_owner_283  1
    service_0_24_2  service_visit_def_694  1
    service_0_24_2  free_load_conservation_695  -11
    service_0_24_2  original_T_including_depot_unload_741  1320
    service_0_24_3  unique_nonzero_owner_284  1
    service_0_24_3  service_visit_def_694  1
    service_0_24_3  free_load_conservation_695  -10
    service_0_24_3  original_T_including_depot_unload_741  1200
    service_0_24_4  unique_nonzero_owner_285  1
    service_0_24_4  service_visit_def_694  1
    service_0_24_4  free_load_conservation_695  -9
    service_0_24_4  original_T_including_depot_unload_741  1080
    service_0_24_5  unique_nonzero_owner_286  1
    service_0_24_5  service_visit_def_694  1
    service_0_24_5  free_load_conservation_695  -8
    service_0_24_5  original_T_including_depot_unload_741  960
    service_0_24_6  unique_nonzero_owner_287  1
    service_0_24_6  service_visit_def_694  1
    service_0_24_6  free_load_conservation_695  -7
    service_0_24_6  original_T_including_depot_unload_741  840
    service_0_24_7  unique_nonzero_owner_288  1
    service_0_24_7  service_visit_def_694  1
    service_0_24_7  free_load_conservation_695  -6
    service_0_24_7  original_T_including_depot_unload_741  720
    service_0_24_8  unique_nonzero_owner_289  1
    service_0_24_8  service_visit_def_694  1
    service_0_24_8  free_load_conservation_695  -5
    service_0_24_8  original_T_including_depot_unload_741  600
    service_0_24_9  unique_nonzero_owner_290  1
    service_0_24_9  service_visit_def_694  1
    service_0_24_9  free_load_conservation_695  -4
    service_0_24_9  original_T_including_depot_unload_741  480
    service_0_24_10  unique_nonzero_owner_291  1
    service_0_24_10  service_visit_def_694  1
    service_0_24_10  free_load_conservation_695  -3
    service_0_24_10  original_T_including_depot_unload_741  360
    service_0_24_11  unique_nonzero_owner_292  1
    service_0_24_11  service_visit_def_694  1
    service_0_24_11  free_load_conservation_695  -2
    service_0_24_11  original_T_including_depot_unload_741  240
    service_0_24_12  unique_nonzero_owner_293  1
    service_0_24_12  service_visit_def_694  1
    service_0_24_12  free_load_conservation_695  -1
    service_0_24_12  original_T_including_depot_unload_741  120
    service_0_24_14  unique_nonzero_owner_294  1
    service_0_24_14  service_visit_def_694  1
    service_0_24_14  free_load_conservation_695  1
    service_0_24_15  unique_nonzero_owner_295  1
    service_0_24_15  service_visit_def_694  1
    service_0_24_15  free_load_conservation_695  2
    service_1_24_0  unique_nonzero_owner_281  1
    service_1_24_0  service_visit_def_1012  1
    service_1_24_0  free_load_conservation_1013  -13
    service_1_24_0  original_T_including_depot_unload_1058  1560
    service_1_24_1  unique_nonzero_owner_282  1
    service_1_24_1  service_visit_def_1012  1
    service_1_24_1  free_load_conservation_1013  -12
    service_1_24_1  original_T_including_depot_unload_1058  1440
    service_1_24_2  unique_nonzero_owner_283  1
    service_1_24_2  service_visit_def_1012  1
    service_1_24_2  free_load_conservation_1013  -11
    service_1_24_2  original_T_including_depot_unload_1058  1320
    service_1_24_3  unique_nonzero_owner_284  1
    service_1_24_3  service_visit_def_1012  1
    service_1_24_3  free_load_conservation_1013  -10
    service_1_24_3  original_T_including_depot_unload_1058  1200
    service_1_24_4  unique_nonzero_owner_285  1
    service_1_24_4  service_visit_def_1012  1
    service_1_24_4  free_load_conservation_1013  -9
    service_1_24_4  original_T_including_depot_unload_1058  1080
    service_1_24_5  unique_nonzero_owner_286  1
    service_1_24_5  service_visit_def_1012  1
    service_1_24_5  free_load_conservation_1013  -8
    service_1_24_5  original_T_including_depot_unload_1058  960
    service_1_24_6  unique_nonzero_owner_287  1
    service_1_24_6  service_visit_def_1012  1
    service_1_24_6  free_load_conservation_1013  -7
    service_1_24_6  original_T_including_depot_unload_1058  840
    service_1_24_7  unique_nonzero_owner_288  1
    service_1_24_7  service_visit_def_1012  1
    service_1_24_7  free_load_conservation_1013  -6
    service_1_24_7  original_T_including_depot_unload_1058  720
    service_1_24_8  unique_nonzero_owner_289  1
    service_1_24_8  service_visit_def_1012  1
    service_1_24_8  free_load_conservation_1013  -5
    service_1_24_8  original_T_including_depot_unload_1058  600
    service_1_24_9  unique_nonzero_owner_290  1
    service_1_24_9  service_visit_def_1012  1
    service_1_24_9  free_load_conservation_1013  -4
    service_1_24_9  original_T_including_depot_unload_1058  480
    service_1_24_10  unique_nonzero_owner_291  1
    service_1_24_10  service_visit_def_1012  1
    service_1_24_10  free_load_conservation_1013  -3
    service_1_24_10  original_T_including_depot_unload_1058  360
    service_1_24_11  unique_nonzero_owner_292  1
    service_1_24_11  service_visit_def_1012  1
    service_1_24_11  free_load_conservation_1013  -2
    service_1_24_11  original_T_including_depot_unload_1058  240
    service_1_24_12  unique_nonzero_owner_293  1
    service_1_24_12  service_visit_def_1012  1
    service_1_24_12  free_load_conservation_1013  -1
    service_1_24_12  original_T_including_depot_unload_1058  120
    service_1_24_14  unique_nonzero_owner_294  1
    service_1_24_14  service_visit_def_1012  1
    service_1_24_14  free_load_conservation_1013  1
    service_1_24_15  unique_nonzero_owner_295  1
    service_1_24_15  service_visit_def_1012  1
    service_1_24_15  free_load_conservation_1013  2
    service_2_24_0  unique_nonzero_owner_281  1
    service_2_24_0  service_visit_def_1382  1
    service_2_24_0  free_load_conservation_1383  -13
    service_2_24_0  original_T_including_depot_unload_1429  1560
    service_2_24_1  unique_nonzero_owner_282  1
    service_2_24_1  service_visit_def_1382  1
    service_2_24_1  free_load_conservation_1383  -12
    service_2_24_1  original_T_including_depot_unload_1429  1440
    service_2_24_2  unique_nonzero_owner_283  1
    service_2_24_2  service_visit_def_1382  1
    service_2_24_2  free_load_conservation_1383  -11
    service_2_24_2  original_T_including_depot_unload_1429  1320
    service_2_24_3  unique_nonzero_owner_284  1
    service_2_24_3  service_visit_def_1382  1
    service_2_24_3  free_load_conservation_1383  -10
    service_2_24_3  original_T_including_depot_unload_1429  1200
    service_2_24_4  unique_nonzero_owner_285  1
    service_2_24_4  service_visit_def_1382  1
    service_2_24_4  free_load_conservation_1383  -9
    service_2_24_4  original_T_including_depot_unload_1429  1080
    service_2_24_5  unique_nonzero_owner_286  1
    service_2_24_5  service_visit_def_1382  1
    service_2_24_5  free_load_conservation_1383  -8
    service_2_24_5  original_T_including_depot_unload_1429  960
    service_2_24_6  unique_nonzero_owner_287  1
    service_2_24_6  service_visit_def_1382  1
    service_2_24_6  free_load_conservation_1383  -7
    service_2_24_6  original_T_including_depot_unload_1429  840
    service_2_24_7  unique_nonzero_owner_288  1
    service_2_24_7  service_visit_def_1382  1
    service_2_24_7  free_load_conservation_1383  -6
    service_2_24_7  original_T_including_depot_unload_1429  720
    service_2_24_8  unique_nonzero_owner_289  1
    service_2_24_8  service_visit_def_1382  1
    service_2_24_8  free_load_conservation_1383  -5
    service_2_24_8  original_T_including_depot_unload_1429  600
    service_2_24_9  unique_nonzero_owner_290  1
    service_2_24_9  service_visit_def_1382  1
    service_2_24_9  free_load_conservation_1383  -4
    service_2_24_9  original_T_including_depot_unload_1429  480
    service_2_24_10  unique_nonzero_owner_291  1
    service_2_24_10  service_visit_def_1382  1
    service_2_24_10  free_load_conservation_1383  -3
    service_2_24_10  original_T_including_depot_unload_1429  360
    service_2_24_11  unique_nonzero_owner_292  1
    service_2_24_11  service_visit_def_1382  1
    service_2_24_11  free_load_conservation_1383  -2
    service_2_24_11  original_T_including_depot_unload_1429  240
    service_2_24_12  unique_nonzero_owner_293  1
    service_2_24_12  service_visit_def_1382  1
    service_2_24_12  free_load_conservation_1383  -1
    service_2_24_12  original_T_including_depot_unload_1429  120
    service_2_24_14  unique_nonzero_owner_294  1
    service_2_24_14  service_visit_def_1382  1
    service_2_24_14  free_load_conservation_1383  1
    service_2_24_15  unique_nonzero_owner_295  1
    service_2_24_15  service_visit_def_1382  1
    service_2_24_15  free_load_conservation_1383  2
    service_0_30_0  unique_nonzero_owner_296  1
    service_0_30_0  service_visit_def_700  1
    service_0_30_0  free_load_conservation_701  -5
    service_0_30_0  original_T_including_depot_unload_741  600
    service_0_30_1  unique_nonzero_owner_297  1
    service_0_30_1  service_visit_def_700  1
    service_0_30_1  free_load_conservation_701  -4
    service_0_30_1  original_T_including_depot_unload_741  480
    service_0_30_2  unique_nonzero_owner_298  1
    service_0_30_2  service_visit_def_700  1
    service_0_30_2  free_load_conservation_701  -3
    service_0_30_2  original_T_including_depot_unload_741  360
    service_0_30_3  unique_nonzero_owner_299  1
    service_0_30_3  service_visit_def_700  1
    service_0_30_3  free_load_conservation_701  -2
    service_0_30_3  original_T_including_depot_unload_741  240
    service_0_30_4  unique_nonzero_owner_300  1
    service_0_30_4  service_visit_def_700  1
    service_0_30_4  free_load_conservation_701  -1
    service_0_30_4  original_T_including_depot_unload_741  120
    service_0_30_6  unique_nonzero_owner_301  1
    service_0_30_6  service_visit_def_700  1
    service_0_30_6  free_load_conservation_701  1
    service_0_30_7  unique_nonzero_owner_302  1
    service_0_30_7  service_visit_def_700  1
    service_0_30_7  free_load_conservation_701  2
    service_0_30_8  unique_nonzero_owner_303  1
    service_0_30_8  service_visit_def_700  1
    service_0_30_8  free_load_conservation_701  3
    service_1_30_0  unique_nonzero_owner_296  1
    service_1_30_0  service_visit_def_1018  1
    service_1_30_0  free_load_conservation_1019  -5
    service_1_30_0  original_T_including_depot_unload_1058  600
    service_1_30_1  unique_nonzero_owner_297  1
    service_1_30_1  service_visit_def_1018  1
    service_1_30_1  free_load_conservation_1019  -4
    service_1_30_1  original_T_including_depot_unload_1058  480
    service_1_30_2  unique_nonzero_owner_298  1
    service_1_30_2  service_visit_def_1018  1
    service_1_30_2  free_load_conservation_1019  -3
    service_1_30_2  original_T_including_depot_unload_1058  360
    service_1_30_3  unique_nonzero_owner_299  1
    service_1_30_3  service_visit_def_1018  1
    service_1_30_3  free_load_conservation_1019  -2
    service_1_30_3  original_T_including_depot_unload_1058  240
    service_1_30_4  unique_nonzero_owner_300  1
    service_1_30_4  service_visit_def_1018  1
    service_1_30_4  free_load_conservation_1019  -1
    service_1_30_4  original_T_including_depot_unload_1058  120
    service_1_30_6  unique_nonzero_owner_301  1
    service_1_30_6  service_visit_def_1018  1
    service_1_30_6  free_load_conservation_1019  1
    service_1_30_7  unique_nonzero_owner_302  1
    service_1_30_7  service_visit_def_1018  1
    service_1_30_7  free_load_conservation_1019  2
    service_1_30_8  unique_nonzero_owner_303  1
    service_1_30_8  service_visit_def_1018  1
    service_1_30_8  free_load_conservation_1019  3
    service_2_30_0  unique_nonzero_owner_296  1
    service_2_30_0  service_visit_def_1388  1
    service_2_30_0  free_load_conservation_1389  -5
    service_2_30_0  original_T_including_depot_unload_1429  600
    service_2_30_1  unique_nonzero_owner_297  1
    service_2_30_1  service_visit_def_1388  1
    service_2_30_1  free_load_conservation_1389  -4
    service_2_30_1  original_T_including_depot_unload_1429  480
    service_2_30_2  unique_nonzero_owner_298  1
    service_2_30_2  service_visit_def_1388  1
    service_2_30_2  free_load_conservation_1389  -3
    service_2_30_2  original_T_including_depot_unload_1429  360
    service_2_30_3  unique_nonzero_owner_299  1
    service_2_30_3  service_visit_def_1388  1
    service_2_30_3  free_load_conservation_1389  -2
    service_2_30_3  original_T_including_depot_unload_1429  240
    service_2_30_4  unique_nonzero_owner_300  1
    service_2_30_4  service_visit_def_1388  1
    service_2_30_4  free_load_conservation_1389  -1
    service_2_30_4  original_T_including_depot_unload_1429  120
    service_2_30_6  unique_nonzero_owner_301  1
    service_2_30_6  service_visit_def_1388  1
    service_2_30_6  free_load_conservation_1389  1
    service_2_30_7  unique_nonzero_owner_302  1
    service_2_30_7  service_visit_def_1388  1
    service_2_30_7  free_load_conservation_1389  2
    service_2_30_8  unique_nonzero_owner_303  1
    service_2_30_8  service_visit_def_1388  1
    service_2_30_8  free_load_conservation_1389  3
    service_0_34_0  unique_nonzero_owner_304  1
    service_0_34_0  service_visit_def_706  1
    service_0_34_0  free_load_conservation_707  -2
    service_0_34_0  original_T_including_depot_unload_741  240
    service_0_34_1  unique_nonzero_owner_305  1
    service_0_34_1  service_visit_def_706  1
    service_0_34_1  free_load_conservation_707  -1
    service_0_34_1  original_T_including_depot_unload_741  120
    service_0_34_3  unique_nonzero_owner_306  1
    service_0_34_3  service_visit_def_706  1
    service_0_34_3  free_load_conservation_707  1
    service_0_34_4  unique_nonzero_owner_307  1
    service_0_34_4  service_visit_def_706  1
    service_0_34_4  free_load_conservation_707  2
    service_0_34_5  unique_nonzero_owner_308  1
    service_0_34_5  service_visit_def_706  1
    service_0_34_5  free_load_conservation_707  3
    service_0_34_6  unique_nonzero_owner_309  1
    service_0_34_6  service_visit_def_706  1
    service_0_34_6  free_load_conservation_707  4
    service_0_34_7  unique_nonzero_owner_310  1
    service_0_34_7  service_visit_def_706  1
    service_0_34_7  free_load_conservation_707  5
    service_0_34_8  unique_nonzero_owner_311  1
    service_0_34_8  service_visit_def_706  1
    service_0_34_8  free_load_conservation_707  6
    service_0_34_9  unique_nonzero_owner_312  1
    service_0_34_9  service_visit_def_706  1
    service_0_34_9  free_load_conservation_707  7
    service_0_34_10  unique_nonzero_owner_313  1
    service_0_34_10  service_visit_def_706  1
    service_0_34_10  free_load_conservation_707  8
    service_0_34_11  unique_nonzero_owner_314  1
    service_0_34_11  service_visit_def_706  1
    service_0_34_11  free_load_conservation_707  9
    service_0_34_12  unique_nonzero_owner_315  1
    service_0_34_12  service_visit_def_706  1
    service_0_34_12  free_load_conservation_707  10
    service_0_34_13  unique_nonzero_owner_316  1
    service_0_34_13  service_visit_def_706  1
    service_0_34_13  free_load_conservation_707  11
    service_0_34_14  unique_nonzero_owner_317  1
    service_0_34_14  service_visit_def_706  1
    service_0_34_14  free_load_conservation_707  12
    service_0_34_15  unique_nonzero_owner_318  1
    service_0_34_15  service_visit_def_706  1
    service_0_34_15  free_load_conservation_707  13
    service_1_34_0  unique_nonzero_owner_304  1
    service_1_34_0  service_visit_def_1024  1
    service_1_34_0  free_load_conservation_1025  -2
    service_1_34_0  original_T_including_depot_unload_1058  240
    service_1_34_1  unique_nonzero_owner_305  1
    service_1_34_1  service_visit_def_1024  1
    service_1_34_1  free_load_conservation_1025  -1
    service_1_34_1  original_T_including_depot_unload_1058  120
    service_1_34_3  unique_nonzero_owner_306  1
    service_1_34_3  service_visit_def_1024  1
    service_1_34_3  free_load_conservation_1025  1
    service_1_34_4  unique_nonzero_owner_307  1
    service_1_34_4  service_visit_def_1024  1
    service_1_34_4  free_load_conservation_1025  2
    service_1_34_5  unique_nonzero_owner_308  1
    service_1_34_5  service_visit_def_1024  1
    service_1_34_5  free_load_conservation_1025  3
    service_1_34_6  unique_nonzero_owner_309  1
    service_1_34_6  service_visit_def_1024  1
    service_1_34_6  free_load_conservation_1025  4
    service_1_34_7  unique_nonzero_owner_310  1
    service_1_34_7  service_visit_def_1024  1
    service_1_34_7  free_load_conservation_1025  5
    service_1_34_8  unique_nonzero_owner_311  1
    service_1_34_8  service_visit_def_1024  1
    service_1_34_8  free_load_conservation_1025  6
    service_1_34_9  unique_nonzero_owner_312  1
    service_1_34_9  service_visit_def_1024  1
    service_1_34_9  free_load_conservation_1025  7
    service_1_34_10  unique_nonzero_owner_313  1
    service_1_34_10  service_visit_def_1024  1
    service_1_34_10  free_load_conservation_1025  8
    service_1_34_11  unique_nonzero_owner_314  1
    service_1_34_11  service_visit_def_1024  1
    service_1_34_11  free_load_conservation_1025  9
    service_1_34_12  unique_nonzero_owner_315  1
    service_1_34_12  service_visit_def_1024  1
    service_1_34_12  free_load_conservation_1025  10
    service_1_34_13  unique_nonzero_owner_316  1
    service_1_34_13  service_visit_def_1024  1
    service_1_34_13  free_load_conservation_1025  11
    service_1_34_14  unique_nonzero_owner_317  1
    service_1_34_14  service_visit_def_1024  1
    service_1_34_14  free_load_conservation_1025  12
    service_1_34_15  unique_nonzero_owner_318  1
    service_1_34_15  service_visit_def_1024  1
    service_1_34_15  free_load_conservation_1025  13
    service_2_34_0  unique_nonzero_owner_304  1
    service_2_34_0  service_visit_def_1394  1
    service_2_34_0  free_load_conservation_1395  -2
    service_2_34_0  original_T_including_depot_unload_1429  240
    service_2_34_1  unique_nonzero_owner_305  1
    service_2_34_1  service_visit_def_1394  1
    service_2_34_1  free_load_conservation_1395  -1
    service_2_34_1  original_T_including_depot_unload_1429  120
    service_2_34_3  unique_nonzero_owner_306  1
    service_2_34_3  service_visit_def_1394  1
    service_2_34_3  free_load_conservation_1395  1
    service_2_34_4  unique_nonzero_owner_307  1
    service_2_34_4  service_visit_def_1394  1
    service_2_34_4  free_load_conservation_1395  2
    service_2_34_5  unique_nonzero_owner_308  1
    service_2_34_5  service_visit_def_1394  1
    service_2_34_5  free_load_conservation_1395  3
    service_2_34_6  unique_nonzero_owner_309  1
    service_2_34_6  service_visit_def_1394  1
    service_2_34_6  free_load_conservation_1395  4
    service_2_34_7  unique_nonzero_owner_310  1
    service_2_34_7  service_visit_def_1394  1
    service_2_34_7  free_load_conservation_1395  5
    service_2_34_8  unique_nonzero_owner_311  1
    service_2_34_8  service_visit_def_1394  1
    service_2_34_8  free_load_conservation_1395  6
    service_2_34_9  unique_nonzero_owner_312  1
    service_2_34_9  service_visit_def_1394  1
    service_2_34_9  free_load_conservation_1395  7
    service_2_34_10  unique_nonzero_owner_313  1
    service_2_34_10  service_visit_def_1394  1
    service_2_34_10  free_load_conservation_1395  8
    service_2_34_11  unique_nonzero_owner_314  1
    service_2_34_11  service_visit_def_1394  1
    service_2_34_11  free_load_conservation_1395  9
    service_2_34_12  unique_nonzero_owner_315  1
    service_2_34_12  service_visit_def_1394  1
    service_2_34_12  free_load_conservation_1395  10
    service_2_34_13  unique_nonzero_owner_316  1
    service_2_34_13  service_visit_def_1394  1
    service_2_34_13  free_load_conservation_1395  11
    service_2_34_14  unique_nonzero_owner_317  1
    service_2_34_14  service_visit_def_1394  1
    service_2_34_14  free_load_conservation_1395  12
    service_2_34_15  unique_nonzero_owner_318  1
    service_2_34_15  service_visit_def_1394  1
    service_2_34_15  free_load_conservation_1395  13
    service_0_28_0  unique_nonzero_owner_319  1
    service_0_28_0  service_visit_def_712  1
    service_0_28_0  free_load_conservation_713  -1
    service_0_28_0  original_T_including_depot_unload_741  120
    service_0_28_2  unique_nonzero_owner_320  1
    service_0_28_2  service_visit_def_712  1
    service_0_28_2  free_load_conservation_713  1
    service_0_28_3  unique_nonzero_owner_321  1
    service_0_28_3  service_visit_def_712  1
    service_0_28_3  free_load_conservation_713  2
    service_0_28_4  unique_nonzero_owner_322  1
    service_0_28_4  service_visit_def_712  1
    service_0_28_4  free_load_conservation_713  3
    service_0_28_5  unique_nonzero_owner_323  1
    service_0_28_5  service_visit_def_712  1
    service_0_28_5  free_load_conservation_713  4
    service_0_28_6  unique_nonzero_owner_324  1
    service_0_28_6  service_visit_def_712  1
    service_0_28_6  free_load_conservation_713  5
    service_1_28_0  unique_nonzero_owner_319  1
    service_1_28_0  service_visit_def_1030  1
    service_1_28_0  free_load_conservation_1031  -1
    service_1_28_0  original_T_including_depot_unload_1058  120
    service_1_28_2  unique_nonzero_owner_320  1
    service_1_28_2  service_visit_def_1030  1
    service_1_28_2  free_load_conservation_1031  1
    service_1_28_3  unique_nonzero_owner_321  1
    service_1_28_3  service_visit_def_1030  1
    service_1_28_3  free_load_conservation_1031  2
    service_1_28_4  unique_nonzero_owner_322  1
    service_1_28_4  service_visit_def_1030  1
    service_1_28_4  free_load_conservation_1031  3
    service_1_28_5  unique_nonzero_owner_323  1
    service_1_28_5  service_visit_def_1030  1
    service_1_28_5  free_load_conservation_1031  4
    service_1_28_6  unique_nonzero_owner_324  1
    service_1_28_6  service_visit_def_1030  1
    service_1_28_6  free_load_conservation_1031  5
    service_2_28_0  unique_nonzero_owner_319  1
    service_2_28_0  service_visit_def_1400  1
    service_2_28_0  free_load_conservation_1401  -1
    service_2_28_0  original_T_including_depot_unload_1429  120
    service_2_28_2  unique_nonzero_owner_320  1
    service_2_28_2  service_visit_def_1400  1
    service_2_28_2  free_load_conservation_1401  1
    service_2_28_3  unique_nonzero_owner_321  1
    service_2_28_3  service_visit_def_1400  1
    service_2_28_3  free_load_conservation_1401  2
    service_2_28_4  unique_nonzero_owner_322  1
    service_2_28_4  service_visit_def_1400  1
    service_2_28_4  free_load_conservation_1401  3
    service_2_28_5  unique_nonzero_owner_323  1
    service_2_28_5  service_visit_def_1400  1
    service_2_28_5  free_load_conservation_1401  4
    service_2_28_6  unique_nonzero_owner_324  1
    service_2_28_6  service_visit_def_1400  1
    service_2_28_6  free_load_conservation_1401  5
    service_0_29_0  unique_nonzero_owner_325  1
    service_0_29_0  service_visit_def_718  1
    service_0_29_0  free_load_conservation_719  -1
    service_0_29_0  original_T_including_depot_unload_741  120
    service_0_29_2  unique_nonzero_owner_326  1
    service_0_29_2  service_visit_def_718  1
    service_0_29_2  free_load_conservation_719  1
    service_0_29_3  unique_nonzero_owner_327  1
    service_0_29_3  service_visit_def_718  1
    service_0_29_3  free_load_conservation_719  2
    service_0_29_4  unique_nonzero_owner_328  1
    service_0_29_4  service_visit_def_718  1
    service_0_29_4  free_load_conservation_719  3
    service_0_29_5  unique_nonzero_owner_329  1
    service_0_29_5  service_visit_def_718  1
    service_0_29_5  free_load_conservation_719  4
    service_0_29_6  unique_nonzero_owner_330  1
    service_0_29_6  service_visit_def_718  1
    service_0_29_6  free_load_conservation_719  5
    service_0_29_7  unique_nonzero_owner_331  1
    service_0_29_7  service_visit_def_718  1
    service_0_29_7  free_load_conservation_719  6
    service_0_29_8  unique_nonzero_owner_332  1
    service_0_29_8  service_visit_def_718  1
    service_0_29_8  free_load_conservation_719  7
    service_0_29_9  unique_nonzero_owner_333  1
    service_0_29_9  service_visit_def_718  1
    service_0_29_9  free_load_conservation_719  8
    service_0_29_10  unique_nonzero_owner_334  1
    service_0_29_10  service_visit_def_718  1
    service_0_29_10  free_load_conservation_719  9
    service_1_29_0  unique_nonzero_owner_325  1
    service_1_29_0  service_visit_def_1036  1
    service_1_29_0  free_load_conservation_1037  -1
    service_1_29_0  original_T_including_depot_unload_1058  120
    service_1_29_2  unique_nonzero_owner_326  1
    service_1_29_2  service_visit_def_1036  1
    service_1_29_2  free_load_conservation_1037  1
    service_1_29_3  unique_nonzero_owner_327  1
    service_1_29_3  service_visit_def_1036  1
    service_1_29_3  free_load_conservation_1037  2
    service_1_29_4  unique_nonzero_owner_328  1
    service_1_29_4  service_visit_def_1036  1
    service_1_29_4  free_load_conservation_1037  3
    service_1_29_5  unique_nonzero_owner_329  1
    service_1_29_5  service_visit_def_1036  1
    service_1_29_5  free_load_conservation_1037  4
    service_1_29_6  unique_nonzero_owner_330  1
    service_1_29_6  service_visit_def_1036  1
    service_1_29_6  free_load_conservation_1037  5
    service_1_29_7  unique_nonzero_owner_331  1
    service_1_29_7  service_visit_def_1036  1
    service_1_29_7  free_load_conservation_1037  6
    service_1_29_8  unique_nonzero_owner_332  1
    service_1_29_8  service_visit_def_1036  1
    service_1_29_8  free_load_conservation_1037  7
    service_1_29_9  unique_nonzero_owner_333  1
    service_1_29_9  service_visit_def_1036  1
    service_1_29_9  free_load_conservation_1037  8
    service_1_29_10  unique_nonzero_owner_334  1
    service_1_29_10  service_visit_def_1036  1
    service_1_29_10  free_load_conservation_1037  9
    service_2_29_0  unique_nonzero_owner_325  1
    service_2_29_0  service_visit_def_1406  1
    service_2_29_0  free_load_conservation_1407  -1
    service_2_29_0  original_T_including_depot_unload_1429  120
    service_2_29_2  unique_nonzero_owner_326  1
    service_2_29_2  service_visit_def_1406  1
    service_2_29_2  free_load_conservation_1407  1
    service_2_29_3  unique_nonzero_owner_327  1
    service_2_29_3  service_visit_def_1406  1
    service_2_29_3  free_load_conservation_1407  2
    service_2_29_4  unique_nonzero_owner_328  1
    service_2_29_4  service_visit_def_1406  1
    service_2_29_4  free_load_conservation_1407  3
    service_2_29_5  unique_nonzero_owner_329  1
    service_2_29_5  service_visit_def_1406  1
    service_2_29_5  free_load_conservation_1407  4
    service_2_29_6  unique_nonzero_owner_330  1
    service_2_29_6  service_visit_def_1406  1
    service_2_29_6  free_load_conservation_1407  5
    service_2_29_7  unique_nonzero_owner_331  1
    service_2_29_7  service_visit_def_1406  1
    service_2_29_7  free_load_conservation_1407  6
    service_2_29_8  unique_nonzero_owner_332  1
    service_2_29_8  service_visit_def_1406  1
    service_2_29_8  free_load_conservation_1407  7
    service_2_29_9  unique_nonzero_owner_333  1
    service_2_29_9  service_visit_def_1406  1
    service_2_29_9  free_load_conservation_1407  8
    service_2_29_10  unique_nonzero_owner_334  1
    service_2_29_10  service_visit_def_1406  1
    service_2_29_10  free_load_conservation_1407  9
    service_0_16_0  unique_nonzero_owner_335  1
    service_0_16_0  service_visit_def_724  1
    service_0_16_0  free_load_conservation_725  -2
    service_0_16_0  original_T_including_depot_unload_741  240
    service_0_16_1  unique_nonzero_owner_336  1
    service_0_16_1  service_visit_def_724  1
    service_0_16_1  free_load_conservation_725  -1
    service_0_16_1  original_T_including_depot_unload_741  120
    service_0_16_3  unique_nonzero_owner_337  1
    service_0_16_3  service_visit_def_724  1
    service_0_16_3  free_load_conservation_725  1
    service_0_16_4  unique_nonzero_owner_338  1
    service_0_16_4  service_visit_def_724  1
    service_0_16_4  free_load_conservation_725  2
    service_0_16_5  unique_nonzero_owner_339  1
    service_0_16_5  service_visit_def_724  1
    service_0_16_5  free_load_conservation_725  3
    service_0_16_6  unique_nonzero_owner_340  1
    service_0_16_6  service_visit_def_724  1
    service_0_16_6  free_load_conservation_725  4
    service_0_16_7  unique_nonzero_owner_341  1
    service_0_16_7  service_visit_def_724  1
    service_0_16_7  free_load_conservation_725  5
    service_0_16_8  unique_nonzero_owner_342  1
    service_0_16_8  service_visit_def_724  1
    service_0_16_8  free_load_conservation_725  6
    service_0_16_9  unique_nonzero_owner_343  1
    service_0_16_9  service_visit_def_724  1
    service_0_16_9  free_load_conservation_725  7
    service_0_16_10  unique_nonzero_owner_344  1
    service_0_16_10  service_visit_def_724  1
    service_0_16_10  free_load_conservation_725  8
    service_0_16_11  unique_nonzero_owner_345  1
    service_0_16_11  service_visit_def_724  1
    service_0_16_11  free_load_conservation_725  9
    service_0_16_12  unique_nonzero_owner_346  1
    service_0_16_12  service_visit_def_724  1
    service_0_16_12  free_load_conservation_725  10
    service_0_16_13  unique_nonzero_owner_347  1
    service_0_16_13  service_visit_def_724  1
    service_0_16_13  free_load_conservation_725  11
    service_0_16_14  unique_nonzero_owner_348  1
    service_0_16_14  service_visit_def_724  1
    service_0_16_14  free_load_conservation_725  12
    service_0_16_15  unique_nonzero_owner_349  1
    service_0_16_15  service_visit_def_724  1
    service_0_16_15  free_load_conservation_725  13
    service_1_16_0  unique_nonzero_owner_335  1
    service_1_16_0  service_visit_def_1042  1
    service_1_16_0  free_load_conservation_1043  -2
    service_1_16_0  original_T_including_depot_unload_1058  240
    service_1_16_1  unique_nonzero_owner_336  1
    service_1_16_1  service_visit_def_1042  1
    service_1_16_1  free_load_conservation_1043  -1
    service_1_16_1  original_T_including_depot_unload_1058  120
    service_1_16_3  unique_nonzero_owner_337  1
    service_1_16_3  service_visit_def_1042  1
    service_1_16_3  free_load_conservation_1043  1
    service_1_16_4  unique_nonzero_owner_338  1
    service_1_16_4  service_visit_def_1042  1
    service_1_16_4  free_load_conservation_1043  2
    service_1_16_5  unique_nonzero_owner_339  1
    service_1_16_5  service_visit_def_1042  1
    service_1_16_5  free_load_conservation_1043  3
    service_1_16_6  unique_nonzero_owner_340  1
    service_1_16_6  service_visit_def_1042  1
    service_1_16_6  free_load_conservation_1043  4
    service_1_16_7  unique_nonzero_owner_341  1
    service_1_16_7  service_visit_def_1042  1
    service_1_16_7  free_load_conservation_1043  5
    service_1_16_8  unique_nonzero_owner_342  1
    service_1_16_8  service_visit_def_1042  1
    service_1_16_8  free_load_conservation_1043  6
    service_1_16_9  unique_nonzero_owner_343  1
    service_1_16_9  service_visit_def_1042  1
    service_1_16_9  free_load_conservation_1043  7
    service_1_16_10  unique_nonzero_owner_344  1
    service_1_16_10  service_visit_def_1042  1
    service_1_16_10  free_load_conservation_1043  8
    service_1_16_11  unique_nonzero_owner_345  1
    service_1_16_11  service_visit_def_1042  1
    service_1_16_11  free_load_conservation_1043  9
    service_1_16_12  unique_nonzero_owner_346  1
    service_1_16_12  service_visit_def_1042  1
    service_1_16_12  free_load_conservation_1043  10
    service_1_16_13  unique_nonzero_owner_347  1
    service_1_16_13  service_visit_def_1042  1
    service_1_16_13  free_load_conservation_1043  11
    service_1_16_14  unique_nonzero_owner_348  1
    service_1_16_14  service_visit_def_1042  1
    service_1_16_14  free_load_conservation_1043  12
    service_1_16_15  unique_nonzero_owner_349  1
    service_1_16_15  service_visit_def_1042  1
    service_1_16_15  free_load_conservation_1043  13
    service_2_16_0  unique_nonzero_owner_335  1
    service_2_16_0  service_visit_def_1412  1
    service_2_16_0  free_load_conservation_1413  -2
    service_2_16_0  original_T_including_depot_unload_1429  240
    service_2_16_1  unique_nonzero_owner_336  1
    service_2_16_1  service_visit_def_1412  1
    service_2_16_1  free_load_conservation_1413  -1
    service_2_16_1  original_T_including_depot_unload_1429  120
    service_2_16_3  unique_nonzero_owner_337  1
    service_2_16_3  service_visit_def_1412  1
    service_2_16_3  free_load_conservation_1413  1
    service_2_16_4  unique_nonzero_owner_338  1
    service_2_16_4  service_visit_def_1412  1
    service_2_16_4  free_load_conservation_1413  2
    service_2_16_5  unique_nonzero_owner_339  1
    service_2_16_5  service_visit_def_1412  1
    service_2_16_5  free_load_conservation_1413  3
    service_2_16_6  unique_nonzero_owner_340  1
    service_2_16_6  service_visit_def_1412  1
    service_2_16_6  free_load_conservation_1413  4
    service_2_16_7  unique_nonzero_owner_341  1
    service_2_16_7  service_visit_def_1412  1
    service_2_16_7  free_load_conservation_1413  5
    service_2_16_8  unique_nonzero_owner_342  1
    service_2_16_8  service_visit_def_1412  1
    service_2_16_8  free_load_conservation_1413  6
    service_2_16_9  unique_nonzero_owner_343  1
    service_2_16_9  service_visit_def_1412  1
    service_2_16_9  free_load_conservation_1413  7
    service_2_16_10  unique_nonzero_owner_344  1
    service_2_16_10  service_visit_def_1412  1
    service_2_16_10  free_load_conservation_1413  8
    service_2_16_11  unique_nonzero_owner_345  1
    service_2_16_11  service_visit_def_1412  1
    service_2_16_11  free_load_conservation_1413  9
    service_2_16_12  unique_nonzero_owner_346  1
    service_2_16_12  service_visit_def_1412  1
    service_2_16_12  free_load_conservation_1413  10
    service_2_16_13  unique_nonzero_owner_347  1
    service_2_16_13  service_visit_def_1412  1
    service_2_16_13  free_load_conservation_1413  11
    service_2_16_14  unique_nonzero_owner_348  1
    service_2_16_14  service_visit_def_1412  1
    service_2_16_14  free_load_conservation_1413  12
    service_2_16_15  unique_nonzero_owner_349  1
    service_2_16_15  service_visit_def_1412  1
    service_2_16_15  free_load_conservation_1413  13
    service_0_27_1  unique_nonzero_owner_350  1
    service_0_27_1  service_visit_def_730  1
    service_0_27_1  free_load_conservation_731  1
    service_0_27_2  unique_nonzero_owner_351  1
    service_0_27_2  service_visit_def_730  1
    service_0_27_2  free_load_conservation_731  2
    service_0_27_3  unique_nonzero_owner_352  1
    service_0_27_3  service_visit_def_730  1
    service_0_27_3  free_load_conservation_731  3
    service_0_27_4  unique_nonzero_owner_353  1
    service_0_27_4  service_visit_def_730  1
    service_0_27_4  free_load_conservation_731  4
    service_0_27_5  unique_nonzero_owner_354  1
    service_0_27_5  service_visit_def_730  1
    service_0_27_5  free_load_conservation_731  5
    service_0_27_6  unique_nonzero_owner_355  1
    service_0_27_6  service_visit_def_730  1
    service_0_27_6  free_load_conservation_731  6
    service_1_27_1  unique_nonzero_owner_350  1
    service_1_27_1  service_visit_def_1048  1
    service_1_27_1  free_load_conservation_1049  1
    service_1_27_2  unique_nonzero_owner_351  1
    service_1_27_2  service_visit_def_1048  1
    service_1_27_2  free_load_conservation_1049  2
    service_1_27_3  unique_nonzero_owner_352  1
    service_1_27_3  service_visit_def_1048  1
    service_1_27_3  free_load_conservation_1049  3
    service_1_27_4  unique_nonzero_owner_353  1
    service_1_27_4  service_visit_def_1048  1
    service_1_27_4  free_load_conservation_1049  4
    service_1_27_5  unique_nonzero_owner_354  1
    service_1_27_5  service_visit_def_1048  1
    service_1_27_5  free_load_conservation_1049  5
    service_1_27_6  unique_nonzero_owner_355  1
    service_1_27_6  service_visit_def_1048  1
    service_1_27_6  free_load_conservation_1049  6
    service_2_27_1  unique_nonzero_owner_350  1
    service_2_27_1  service_visit_def_1418  1
    service_2_27_1  free_load_conservation_1419  1
    service_2_27_2  unique_nonzero_owner_351  1
    service_2_27_2  service_visit_def_1418  1
    service_2_27_2  free_load_conservation_1419  2
    service_2_27_3  unique_nonzero_owner_352  1
    service_2_27_3  service_visit_def_1418  1
    service_2_27_3  free_load_conservation_1419  3
    service_2_27_4  unique_nonzero_owner_353  1
    service_2_27_4  service_visit_def_1418  1
    service_2_27_4  free_load_conservation_1419  4
    service_2_27_5  unique_nonzero_owner_354  1
    service_2_27_5  service_visit_def_1418  1
    service_2_27_5  free_load_conservation_1419  5
    service_2_27_6  unique_nonzero_owner_355  1
    service_2_27_6  service_visit_def_1418  1
    service_2_27_6  free_load_conservation_1419  6
    service_0_22_0  unique_nonzero_owner_356  1
    service_0_22_0  service_visit_def_736  1
    service_0_22_0  free_load_conservation_737  -2
    service_0_22_0  original_T_including_depot_unload_741  240
    service_0_22_1  unique_nonzero_owner_357  1
    service_0_22_1  service_visit_def_736  1
    service_0_22_1  free_load_conservation_737  -1
    service_0_22_1  original_T_including_depot_unload_741  120
    service_0_22_3  unique_nonzero_owner_358  1
    service_0_22_3  service_visit_def_736  1
    service_0_22_3  free_load_conservation_737  1
    service_0_22_4  unique_nonzero_owner_359  1
    service_0_22_4  service_visit_def_736  1
    service_0_22_4  free_load_conservation_737  2
    service_0_22_5  unique_nonzero_owner_360  1
    service_0_22_5  service_visit_def_736  1
    service_0_22_5  free_load_conservation_737  3
    service_0_22_6  unique_nonzero_owner_361  1
    service_0_22_6  service_visit_def_736  1
    service_0_22_6  free_load_conservation_737  4
    service_0_22_7  unique_nonzero_owner_362  1
    service_0_22_7  service_visit_def_736  1
    service_0_22_7  free_load_conservation_737  5
    service_0_22_8  unique_nonzero_owner_363  1
    service_0_22_8  service_visit_def_736  1
    service_0_22_8  free_load_conservation_737  6
    service_0_22_9  unique_nonzero_owner_364  1
    service_0_22_9  service_visit_def_736  1
    service_0_22_9  free_load_conservation_737  7
    service_0_22_10  unique_nonzero_owner_365  1
    service_0_22_10  service_visit_def_736  1
    service_0_22_10  free_load_conservation_737  8
    service_0_22_11  unique_nonzero_owner_366  1
    service_0_22_11  service_visit_def_736  1
    service_0_22_11  free_load_conservation_737  9
    service_0_22_12  unique_nonzero_owner_367  1
    service_0_22_12  service_visit_def_736  1
    service_0_22_12  free_load_conservation_737  10
    service_0_22_13  unique_nonzero_owner_368  1
    service_0_22_13  service_visit_def_736  1
    service_0_22_13  free_load_conservation_737  11
    service_0_22_14  unique_nonzero_owner_369  1
    service_0_22_14  service_visit_def_736  1
    service_0_22_14  free_load_conservation_737  12
    service_0_22_15  unique_nonzero_owner_370  1
    service_0_22_15  service_visit_def_736  1
    service_0_22_15  free_load_conservation_737  13
    service_1_22_0  unique_nonzero_owner_356  1
    service_1_22_0  service_visit_def_1054  1
    service_1_22_0  free_load_conservation_1055  -2
    service_1_22_0  original_T_including_depot_unload_1058  240
    service_1_22_1  unique_nonzero_owner_357  1
    service_1_22_1  service_visit_def_1054  1
    service_1_22_1  free_load_conservation_1055  -1
    service_1_22_1  original_T_including_depot_unload_1058  120
    service_1_22_3  unique_nonzero_owner_358  1
    service_1_22_3  service_visit_def_1054  1
    service_1_22_3  free_load_conservation_1055  1
    service_1_22_4  unique_nonzero_owner_359  1
    service_1_22_4  service_visit_def_1054  1
    service_1_22_4  free_load_conservation_1055  2
    service_1_22_5  unique_nonzero_owner_360  1
    service_1_22_5  service_visit_def_1054  1
    service_1_22_5  free_load_conservation_1055  3
    service_1_22_6  unique_nonzero_owner_361  1
    service_1_22_6  service_visit_def_1054  1
    service_1_22_6  free_load_conservation_1055  4
    service_1_22_7  unique_nonzero_owner_362  1
    service_1_22_7  service_visit_def_1054  1
    service_1_22_7  free_load_conservation_1055  5
    service_1_22_8  unique_nonzero_owner_363  1
    service_1_22_8  service_visit_def_1054  1
    service_1_22_8  free_load_conservation_1055  6
    service_1_22_9  unique_nonzero_owner_364  1
    service_1_22_9  service_visit_def_1054  1
    service_1_22_9  free_load_conservation_1055  7
    service_1_22_10  unique_nonzero_owner_365  1
    service_1_22_10  service_visit_def_1054  1
    service_1_22_10  free_load_conservation_1055  8
    service_1_22_11  unique_nonzero_owner_366  1
    service_1_22_11  service_visit_def_1054  1
    service_1_22_11  free_load_conservation_1055  9
    service_1_22_12  unique_nonzero_owner_367  1
    service_1_22_12  service_visit_def_1054  1
    service_1_22_12  free_load_conservation_1055  10
    service_1_22_13  unique_nonzero_owner_368  1
    service_1_22_13  service_visit_def_1054  1
    service_1_22_13  free_load_conservation_1055  11
    service_1_22_14  unique_nonzero_owner_369  1
    service_1_22_14  service_visit_def_1054  1
    service_1_22_14  free_load_conservation_1055  12
    service_1_22_15  unique_nonzero_owner_370  1
    service_1_22_15  service_visit_def_1054  1
    service_1_22_15  free_load_conservation_1055  13
    service_2_22_0  unique_nonzero_owner_356  1
    service_2_22_0  service_visit_def_1424  1
    service_2_22_0  free_load_conservation_1425  -2
    service_2_22_0  original_T_including_depot_unload_1429  240
    service_2_22_1  unique_nonzero_owner_357  1
    service_2_22_1  service_visit_def_1424  1
    service_2_22_1  free_load_conservation_1425  -1
    service_2_22_1  original_T_including_depot_unload_1429  120
    service_2_22_3  unique_nonzero_owner_358  1
    service_2_22_3  service_visit_def_1424  1
    service_2_22_3  free_load_conservation_1425  1
    service_2_22_4  unique_nonzero_owner_359  1
    service_2_22_4  service_visit_def_1424  1
    service_2_22_4  free_load_conservation_1425  2
    service_2_22_5  unique_nonzero_owner_360  1
    service_2_22_5  service_visit_def_1424  1
    service_2_22_5  free_load_conservation_1425  3
    service_2_22_6  unique_nonzero_owner_361  1
    service_2_22_6  service_visit_def_1424  1
    service_2_22_6  free_load_conservation_1425  4
    service_2_22_7  unique_nonzero_owner_362  1
    service_2_22_7  service_visit_def_1424  1
    service_2_22_7  free_load_conservation_1425  5
    service_2_22_8  unique_nonzero_owner_363  1
    service_2_22_8  service_visit_def_1424  1
    service_2_22_8  free_load_conservation_1425  6
    service_2_22_9  unique_nonzero_owner_364  1
    service_2_22_9  service_visit_def_1424  1
    service_2_22_9  free_load_conservation_1425  7
    service_2_22_10  unique_nonzero_owner_365  1
    service_2_22_10  service_visit_def_1424  1
    service_2_22_10  free_load_conservation_1425  8
    service_2_22_11  unique_nonzero_owner_366  1
    service_2_22_11  service_visit_def_1424  1
    service_2_22_11  free_load_conservation_1425  9
    service_2_22_12  unique_nonzero_owner_367  1
    service_2_22_12  service_visit_def_1424  1
    service_2_22_12  free_load_conservation_1425  10
    service_2_22_13  unique_nonzero_owner_368  1
    service_2_22_13  service_visit_def_1424  1
    service_2_22_13  free_load_conservation_1425  11
    service_2_22_14  unique_nonzero_owner_369  1
    service_2_22_14  service_visit_def_1424  1
    service_2_22_14  free_load_conservation_1425  12
    service_2_22_15  unique_nonzero_owner_370  1
    service_2_22_15  service_visit_def_1424  1
    service_2_22_15  free_load_conservation_1425  13
    MARKER    'MARKER'                 'INTEND'
    visit_0_1  out_degree_662  -1
    visit_0_1  in_degree_663  -1
    visit_0_1  order_active_lb_664  -1
    visit_0_1  order_active_ub_665  -12
    order_0_1  connected_order_arc_386  -1
    order_0_1  connected_order_arc_388  -1
    order_0_1  connected_order_arc_390  -1
    order_0_1  connected_order_arc_392  -1
    order_0_1  connected_order_arc_394  -1
    order_0_1  connected_order_arc_396  -1
    order_0_1  connected_order_arc_398  -1
    order_0_1  connected_order_arc_400  -1
    order_0_1  connected_order_arc_402  -1
    order_0_1  connected_order_arc_404  -1
    order_0_1  connected_order_arc_406  -1
    order_0_1  connected_order_arc_409  1
    order_0_1  connected_order_arc_432  1
    order_0_1  connected_order_arc_455  1
    order_0_1  connected_order_arc_478  1
    order_0_1  connected_order_arc_501  1
    order_0_1  connected_order_arc_524  1
    order_0_1  connected_order_arc_547  1
    order_0_1  connected_order_arc_570  1
    order_0_1  connected_order_arc_593  1
    order_0_1  connected_order_arc_616  1
    order_0_1  connected_order_arc_639  1
    order_0_1  order_active_lb_664  1
    order_0_1  order_active_ub_665  1
    order_0_1  fixed_segment_relative_order_738  -1
    visit_0_2  out_degree_669  -1
    visit_0_2  in_degree_670  -1
    visit_0_2  order_active_lb_671  -1
    visit_0_2  order_active_ub_672  -12
    order_0_2  connected_order_arc_386  1
    order_0_2  connected_order_arc_409  -1
    order_0_2  connected_order_arc_411  -1
    order_0_2  connected_order_arc_413  -1
    order_0_2  connected_order_arc_415  -1
    order_0_2  connected_order_arc_417  -1
    order_0_2  connected_order_arc_419  -1
    order_0_2  connected_order_arc_421  -1
    order_0_2  connected_order_arc_423  -1
    order_0_2  connected_order_arc_425  -1
    order_0_2  connected_order_arc_427  -1
    order_0_2  connected_order_arc_429  -1
    order_0_2  connected_order_arc_434  1
    order_0_2  connected_order_arc_457  1
    order_0_2  connected_order_arc_480  1
    order_0_2  connected_order_arc_503  1
    order_0_2  connected_order_arc_526  1
    order_0_2  connected_order_arc_549  1
    order_0_2  connected_order_arc_572  1
    order_0_2  connected_order_arc_595  1
    order_0_2  connected_order_arc_618  1
    order_0_2  connected_order_arc_641  1
    order_0_2  order_active_lb_671  1
    order_0_2  order_active_ub_672  1
    order_0_2  fixed_segment_relative_order_738  1
    order_0_2  fixed_segment_relative_order_739  -1
    visit_0_3  out_degree_676  -1
    visit_0_3  in_degree_677  -1
    visit_0_3  order_active_lb_678  -1
    visit_0_3  order_active_ub_679  -12
    order_0_3  connected_order_arc_388  1
    order_0_3  connected_order_arc_411  1
    order_0_3  connected_order_arc_432  -1
    order_0_3  connected_order_arc_434  -1
    order_0_3  connected_order_arc_436  -1
    order_0_3  connected_order_arc_438  -1
    order_0_3  connected_order_arc_440  -1
    order_0_3  connected_order_arc_442  -1
    order_0_3  connected_order_arc_444  -1
    order_0_3  connected_order_arc_446  -1
    order_0_3  connected_order_arc_448  -1
    order_0_3  connected_order_arc_450  -1
    order_0_3  connected_order_arc_452  -1
    order_0_3  connected_order_arc_459  1
    order_0_3  connected_order_arc_482  1
    order_0_3  connected_order_arc_505  1
    order_0_3  connected_order_arc_528  1
    order_0_3  connected_order_arc_551  1
    order_0_3  connected_order_arc_574  1
    order_0_3  connected_order_arc_597  1
    order_0_3  connected_order_arc_620  1
    order_0_3  connected_order_arc_643  1
    order_0_3  order_active_lb_678  1
    order_0_3  order_active_ub_679  1
    order_0_3  fixed_segment_relative_order_739  1
    order_0_3  fixed_segment_relative_order_740  -1
    visit_0_4  out_degree_683  -1
    visit_0_4  in_degree_684  -1
    visit_0_4  order_active_lb_685  -1
    visit_0_4  order_active_ub_686  -12
    order_0_4  connected_order_arc_390  1
    order_0_4  connected_order_arc_413  1
    order_0_4  connected_order_arc_436  1
    order_0_4  connected_order_arc_455  -1
    order_0_4  connected_order_arc_457  -1
    order_0_4  connected_order_arc_459  -1
    order_0_4  connected_order_arc_461  -1
    order_0_4  connected_order_arc_463  -1
    order_0_4  connected_order_arc_465  -1
    order_0_4  connected_order_arc_467  -1
    order_0_4  connected_order_arc_469  -1
    order_0_4  connected_order_arc_471  -1
    order_0_4  connected_order_arc_473  -1
    order_0_4  connected_order_arc_475  -1
    order_0_4  connected_order_arc_484  1
    order_0_4  connected_order_arc_507  1
    order_0_4  connected_order_arc_530  1
    order_0_4  connected_order_arc_553  1
    order_0_4  connected_order_arc_576  1
    order_0_4  connected_order_arc_599  1
    order_0_4  connected_order_arc_622  1
    order_0_4  connected_order_arc_645  1
    order_0_4  order_active_lb_685  1
    order_0_4  order_active_ub_686  1
    order_0_4  fixed_segment_relative_order_740  1
    visit_0_12  out_degree_690  -1
    visit_0_12  in_degree_691  -1
    visit_0_12  order_active_lb_692  -1
    visit_0_12  order_active_ub_693  -12
    visit_0_12  service_visit_def_694  -1
    order_0_12  connected_order_arc_392  1
    order_0_12  connected_order_arc_415  1
    order_0_12  connected_order_arc_438  1
    order_0_12  connected_order_arc_461  1
    order_0_12  connected_order_arc_478  -1
    order_0_12  connected_order_arc_480  -1
    order_0_12  connected_order_arc_482  -1
    order_0_12  connected_order_arc_484  -1
    order_0_12  connected_order_arc_486  -1
    order_0_12  connected_order_arc_488  -1
    order_0_12  connected_order_arc_490  -1
    order_0_12  connected_order_arc_492  -1
    order_0_12  connected_order_arc_494  -1
    order_0_12  connected_order_arc_496  -1
    order_0_12  connected_order_arc_498  -1
    order_0_12  connected_order_arc_509  1
    order_0_12  connected_order_arc_532  1
    order_0_12  connected_order_arc_555  1
    order_0_12  connected_order_arc_578  1
    order_0_12  connected_order_arc_601  1
    order_0_12  connected_order_arc_624  1
    order_0_12  connected_order_arc_647  1
    order_0_12  order_active_lb_692  1
    order_0_12  order_active_ub_693  1
    visit_0_13  out_degree_696  -1
    visit_0_13  in_degree_697  -1
    visit_0_13  order_active_lb_698  -1
    visit_0_13  order_active_ub_699  -12
    visit_0_13  service_visit_def_700  -1
    order_0_13  connected_order_arc_394  1
    order_0_13  connected_order_arc_417  1
    order_0_13  connected_order_arc_440  1
    order_0_13  connected_order_arc_463  1
    order_0_13  connected_order_arc_486  1
    order_0_13  connected_order_arc_501  -1
    order_0_13  connected_order_arc_503  -1
    order_0_13  connected_order_arc_505  -1
    order_0_13  connected_order_arc_507  -1
    order_0_13  connected_order_arc_509  -1
    order_0_13  connected_order_arc_511  -1
    order_0_13  connected_order_arc_513  -1
    order_0_13  connected_order_arc_515  -1
    order_0_13  connected_order_arc_517  -1
    order_0_13  connected_order_arc_519  -1
    order_0_13  connected_order_arc_521  -1
    order_0_13  connected_order_arc_534  1
    order_0_13  connected_order_arc_557  1
    order_0_13  connected_order_arc_580  1
    order_0_13  connected_order_arc_603  1
    order_0_13  connected_order_arc_626  1
    order_0_13  connected_order_arc_649  1
    order_0_13  order_active_lb_698  1
    order_0_13  order_active_ub_699  1
    visit_0_14  out_degree_702  -1
    visit_0_14  in_degree_703  -1
    visit_0_14  order_active_lb_704  -1
    visit_0_14  order_active_ub_705  -12
    visit_0_14  service_visit_def_706  -1
    order_0_14  connected_order_arc_396  1
    order_0_14  connected_order_arc_419  1
    order_0_14  connected_order_arc_442  1
    order_0_14  connected_order_arc_465  1
    order_0_14  connected_order_arc_488  1
    order_0_14  connected_order_arc_511  1
    order_0_14  connected_order_arc_524  -1
    order_0_14  connected_order_arc_526  -1
    order_0_14  connected_order_arc_528  -1
    order_0_14  connected_order_arc_530  -1
    order_0_14  connected_order_arc_532  -1
    order_0_14  connected_order_arc_534  -1
    order_0_14  connected_order_arc_536  -1
    order_0_14  connected_order_arc_538  -1
    order_0_14  connected_order_arc_540  -1
    order_0_14  connected_order_arc_542  -1
    order_0_14  connected_order_arc_544  -1
    order_0_14  connected_order_arc_559  1
    order_0_14  connected_order_arc_582  1
    order_0_14  connected_order_arc_605  1
    order_0_14  connected_order_arc_628  1
    order_0_14  connected_order_arc_651  1
    order_0_14  order_active_lb_704  1
    order_0_14  order_active_ub_705  1
    visit_0_15  out_degree_708  -1
    visit_0_15  in_degree_709  -1
    visit_0_15  order_active_lb_710  -1
    visit_0_15  order_active_ub_711  -12
    visit_0_15  service_visit_def_712  -1
    order_0_15  connected_order_arc_398  1
    order_0_15  connected_order_arc_421  1
    order_0_15  connected_order_arc_444  1
    order_0_15  connected_order_arc_467  1
    order_0_15  connected_order_arc_490  1
    order_0_15  connected_order_arc_513  1
    order_0_15  connected_order_arc_536  1
    order_0_15  connected_order_arc_547  -1
    order_0_15  connected_order_arc_549  -1
    order_0_15  connected_order_arc_551  -1
    order_0_15  connected_order_arc_553  -1
    order_0_15  connected_order_arc_555  -1
    order_0_15  connected_order_arc_557  -1
    order_0_15  connected_order_arc_559  -1
    order_0_15  connected_order_arc_561  -1
    order_0_15  connected_order_arc_563  -1
    order_0_15  connected_order_arc_565  -1
    order_0_15  connected_order_arc_567  -1
    order_0_15  connected_order_arc_584  1
    order_0_15  connected_order_arc_607  1
    order_0_15  connected_order_arc_630  1
    order_0_15  connected_order_arc_653  1
    order_0_15  order_active_lb_710  1
    order_0_15  order_active_ub_711  1
    visit_0_16  out_degree_714  -1
    visit_0_16  in_degree_715  -1
    visit_0_16  order_active_lb_716  -1
    visit_0_16  order_active_ub_717  -12
    visit_0_16  service_visit_def_718  -1
    order_0_16  connected_order_arc_400  1
    order_0_16  connected_order_arc_423  1
    order_0_16  connected_order_arc_446  1
    order_0_16  connected_order_arc_469  1
    order_0_16  connected_order_arc_492  1
    order_0_16  connected_order_arc_515  1
    order_0_16  connected_order_arc_538  1
    order_0_16  connected_order_arc_561  1
    order_0_16  connected_order_arc_570  -1
    order_0_16  connected_order_arc_572  -1
    order_0_16  connected_order_arc_574  -1
    order_0_16  connected_order_arc_576  -1
    order_0_16  connected_order_arc_578  -1
    order_0_16  connected_order_arc_580  -1
    order_0_16  connected_order_arc_582  -1
    order_0_16  connected_order_arc_584  -1
    order_0_16  connected_order_arc_586  -1
    order_0_16  connected_order_arc_588  -1
    order_0_16  connected_order_arc_590  -1
    order_0_16  connected_order_arc_609  1
    order_0_16  connected_order_arc_632  1
    order_0_16  connected_order_arc_655  1
    order_0_16  order_active_lb_716  1
    order_0_16  order_active_ub_717  1
    visit_0_17  out_degree_720  -1
    visit_0_17  in_degree_721  -1
    visit_0_17  order_active_lb_722  -1
    visit_0_17  order_active_ub_723  -12
    visit_0_17  service_visit_def_724  -1
    order_0_17  connected_order_arc_402  1
    order_0_17  connected_order_arc_425  1
    order_0_17  connected_order_arc_448  1
    order_0_17  connected_order_arc_471  1
    order_0_17  connected_order_arc_494  1
    order_0_17  connected_order_arc_517  1
    order_0_17  connected_order_arc_540  1
    order_0_17  connected_order_arc_563  1
    order_0_17  connected_order_arc_586  1
    order_0_17  connected_order_arc_593  -1
    order_0_17  connected_order_arc_595  -1
    order_0_17  connected_order_arc_597  -1
    order_0_17  connected_order_arc_599  -1
    order_0_17  connected_order_arc_601  -1
    order_0_17  connected_order_arc_603  -1
    order_0_17  connected_order_arc_605  -1
    order_0_17  connected_order_arc_607  -1
    order_0_17  connected_order_arc_609  -1
    order_0_17  connected_order_arc_611  -1
    order_0_17  connected_order_arc_613  -1
    order_0_17  connected_order_arc_634  1
    order_0_17  connected_order_arc_657  1
    order_0_17  order_active_lb_722  1
    order_0_17  order_active_ub_723  1
    visit_0_18  out_degree_726  -1
    visit_0_18  in_degree_727  -1
    visit_0_18  order_active_lb_728  -1
    visit_0_18  order_active_ub_729  -12
    visit_0_18  service_visit_def_730  -1
    order_0_18  connected_order_arc_404  1
    order_0_18  connected_order_arc_427  1
    order_0_18  connected_order_arc_450  1
    order_0_18  connected_order_arc_473  1
    order_0_18  connected_order_arc_496  1
    order_0_18  connected_order_arc_519  1
    order_0_18  connected_order_arc_542  1
    order_0_18  connected_order_arc_565  1
    order_0_18  connected_order_arc_588  1
    order_0_18  connected_order_arc_611  1
    order_0_18  connected_order_arc_616  -1
    order_0_18  connected_order_arc_618  -1
    order_0_18  connected_order_arc_620  -1
    order_0_18  connected_order_arc_622  -1
    order_0_18  connected_order_arc_624  -1
    order_0_18  connected_order_arc_626  -1
    order_0_18  connected_order_arc_628  -1
    order_0_18  connected_order_arc_630  -1
    order_0_18  connected_order_arc_632  -1
    order_0_18  connected_order_arc_634  -1
    order_0_18  connected_order_arc_636  -1
    order_0_18  connected_order_arc_659  1
    order_0_18  order_active_lb_728  1
    order_0_18  order_active_ub_729  1
    visit_0_19  out_degree_732  -1
    visit_0_19  in_degree_733  -1
    visit_0_19  order_active_lb_734  -1
    visit_0_19  order_active_ub_735  -12
    visit_0_19  service_visit_def_736  -1
    order_0_19  connected_order_arc_406  1
    order_0_19  connected_order_arc_429  1
    order_0_19  connected_order_arc_452  1
    order_0_19  connected_order_arc_475  1
    order_0_19  connected_order_arc_498  1
    order_0_19  connected_order_arc_521  1
    order_0_19  connected_order_arc_544  1
    order_0_19  connected_order_arc_567  1
    order_0_19  connected_order_arc_590  1
    order_0_19  connected_order_arc_613  1
    order_0_19  connected_order_arc_636  1
    order_0_19  connected_order_arc_639  -1
    order_0_19  connected_order_arc_641  -1
    order_0_19  connected_order_arc_643  -1
    order_0_19  connected_order_arc_645  -1
    order_0_19  connected_order_arc_647  -1
    order_0_19  connected_order_arc_649  -1
    order_0_19  connected_order_arc_651  -1
    order_0_19  connected_order_arc_653  -1
    order_0_19  connected_order_arc_655  -1
    order_0_19  connected_order_arc_657  -1
    order_0_19  connected_order_arc_659  -1
    order_0_19  order_active_lb_734  1
    order_0_19  order_active_ub_735  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_0  arc_capacity_371  -20
    arc_0_0_0  depot_departure_or_bypass_660  1
    arc_0_0_0  depot_return_or_bypass_661  1
    MARKER    'MARKER'                 'INTEND'
    load_0_0_0  arc_capacity_371  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_1  arc_capacity_372  -20
    arc_0_0_1  depot_departure_or_bypass_660  1
    arc_0_0_1  in_degree_663  1
    arc_0_0_1  original_T_including_depot_unload_741  4.3364857643570593e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_1  arc_capacity_372  1
    load_0_0_1  segment_load_conservation_666  -1
    load_0_0_1  segment_prefix_lb_667  1
    load_0_0_1  segment_prefix_ub_668  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_2  arc_capacity_373  -20
    arc_0_0_2  depot_departure_or_bypass_660  1
    arc_0_0_2  in_degree_670  1
    arc_0_0_2  original_T_including_depot_unload_741  5.2273830510106120e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_2  arc_capacity_373  1
    load_0_0_2  segment_load_conservation_673  -1
    load_0_0_2  segment_prefix_lb_674  1
    load_0_0_2  segment_prefix_ub_675  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_3  arc_capacity_374  -20
    arc_0_0_3  depot_departure_or_bypass_660  1
    arc_0_0_3  in_degree_677  1
    arc_0_0_3  original_T_including_depot_unload_741  6.4256529461228865e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_3  arc_capacity_374  1
    load_0_0_3  segment_load_conservation_680  -1
    load_0_0_3  segment_prefix_lb_681  1
    load_0_0_3  segment_prefix_ub_682  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_4  arc_capacity_375  -20
    arc_0_0_4  depot_departure_or_bypass_660  1
    arc_0_0_4  in_degree_684  1
    arc_0_0_4  original_T_including_depot_unload_741  3.9307504957585564e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_4  arc_capacity_375  1
    load_0_0_4  segment_load_conservation_687  -1
    load_0_0_4  segment_prefix_lb_688  1
    load_0_0_4  segment_prefix_ub_689  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_12  arc_capacity_376  -20
    arc_0_0_12  depot_departure_or_bypass_660  1
    arc_0_0_12  in_degree_691  1
    arc_0_0_12  original_T_including_depot_unload_741  1.1935953747864173e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_12  arc_capacity_376  1
    load_0_0_12  free_load_conservation_695  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_13  arc_capacity_377  -20
    arc_0_0_13  depot_departure_or_bypass_660  1
    arc_0_0_13  in_degree_697  1
    arc_0_0_13  original_T_including_depot_unload_741  1.6602888921784454e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_13  arc_capacity_377  1
    load_0_0_13  free_load_conservation_701  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_14  arc_capacity_378  -20
    arc_0_0_14  depot_departure_or_bypass_660  1
    arc_0_0_14  in_degree_703  1
    arc_0_0_14  original_T_including_depot_unload_741  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_14  arc_capacity_378  1
    load_0_0_14  free_load_conservation_707  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_15  arc_capacity_379  -20
    arc_0_0_15  depot_departure_or_bypass_660  1
    arc_0_0_15  in_degree_709  1
    arc_0_0_15  original_T_including_depot_unload_741  1.0056399980521732e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_15  arc_capacity_379  1
    load_0_0_15  free_load_conservation_713  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_16  arc_capacity_380  -20
    arc_0_0_16  depot_departure_or_bypass_660  1
    arc_0_0_16  in_degree_715  1
    arc_0_0_16  original_T_including_depot_unload_741  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_16  arc_capacity_380  1
    load_0_0_16  free_load_conservation_719  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_17  arc_capacity_381  -20
    arc_0_0_17  depot_departure_or_bypass_660  1
    arc_0_0_17  in_degree_721  1
    arc_0_0_17  original_T_including_depot_unload_741  3.5061909388980052e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_17  arc_capacity_381  1
    load_0_0_17  free_load_conservation_725  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_18  arc_capacity_382  -20
    arc_0_0_18  depot_departure_or_bypass_660  1
    arc_0_0_18  in_degree_727  1
    arc_0_0_18  original_T_including_depot_unload_741  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_18  arc_capacity_382  1
    load_0_0_18  free_load_conservation_731  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_19  arc_capacity_383  -20
    arc_0_0_19  depot_departure_or_bypass_660  1
    arc_0_0_19  in_degree_733  1
    arc_0_0_19  original_T_including_depot_unload_741  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_19  arc_capacity_383  1
    load_0_0_19  free_load_conservation_737  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_0  arc_capacity_384  -20
    arc_0_1_0  depot_return_or_bypass_661  1
    arc_0_1_0  out_degree_662  1
    arc_0_1_0  original_T_including_depot_unload_741  4.3364857643570593e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_0  arc_capacity_384  1
    load_0_1_0  segment_load_conservation_666  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_2  arc_capacity_385  -20
    arc_0_1_2  connected_order_arc_386  -13
    arc_0_1_2  out_degree_662  1
    arc_0_1_2  in_degree_670  1
    arc_0_1_2  original_T_including_depot_unload_741  1.6552401015053141e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_2  arc_capacity_385  1
    load_0_1_2  segment_load_conservation_666  1
    load_0_1_2  segment_load_conservation_673  -1
    load_0_1_2  segment_prefix_lb_674  1
    load_0_1_2  segment_prefix_ub_675  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_3  arc_capacity_387  -20
    arc_0_1_3  connected_order_arc_388  -13
    arc_0_1_3  out_degree_662  1
    arc_0_1_3  in_degree_677  1
    arc_0_1_3  original_T_including_depot_unload_741  2.8856753867620006e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_3  arc_capacity_387  1
    load_0_1_3  segment_load_conservation_666  1
    load_0_1_3  segment_load_conservation_680  -1
    load_0_1_3  segment_prefix_lb_681  1
    load_0_1_3  segment_prefix_ub_682  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_4  arc_capacity_389  -20
    arc_0_1_4  connected_order_arc_390  -13
    arc_0_1_4  out_degree_662  1
    arc_0_1_4  in_degree_684  1
    arc_0_1_4  original_T_including_depot_unload_741  1.9684882536425036e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_4  arc_capacity_389  1
    load_0_1_4  segment_load_conservation_666  1
    load_0_1_4  segment_load_conservation_687  -1
    load_0_1_4  segment_prefix_lb_688  1
    load_0_1_4  segment_prefix_ub_689  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_12  arc_capacity_391  -20
    arc_0_1_12  connected_order_arc_392  -13
    arc_0_1_12  out_degree_662  1
    arc_0_1_12  in_degree_691  1
    arc_0_1_12  original_T_including_depot_unload_741  1.5639034270630727e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_12  arc_capacity_391  1
    load_0_1_12  segment_load_conservation_666  1
    load_0_1_12  free_load_conservation_695  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_13  arc_capacity_393  -20
    arc_0_1_13  connected_order_arc_394  -13
    arc_0_1_13  out_degree_662  1
    arc_0_1_13  in_degree_697  1
    arc_0_1_13  original_T_including_depot_unload_741  2.0883063288244971e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_13  arc_capacity_393  1
    load_0_1_13  segment_load_conservation_666  1
    load_0_1_13  free_load_conservation_701  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_14  arc_capacity_395  -20
    arc_0_1_14  connected_order_arc_396  -13
    arc_0_1_14  out_degree_662  1
    arc_0_1_14  in_degree_703  1
    arc_0_1_14  original_T_including_depot_unload_741  1.7908610301589636e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_14  arc_capacity_395  1
    load_0_1_14  segment_load_conservation_666  1
    load_0_1_14  free_load_conservation_707  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_15  arc_capacity_397  -20
    arc_0_1_15  connected_order_arc_398  -13
    arc_0_1_15  out_degree_662  1
    arc_0_1_15  in_degree_709  1
    arc_0_1_15  original_T_including_depot_unload_741  1.4285403548915413e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_15  arc_capacity_397  1
    load_0_1_15  segment_load_conservation_666  1
    load_0_1_15  free_load_conservation_713  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_16  arc_capacity_399  -20
    arc_0_1_16  connected_order_arc_400  -13
    arc_0_1_16  out_degree_662  1
    arc_0_1_16  in_degree_715  1
    arc_0_1_16  original_T_including_depot_unload_741  1.4300244315666421e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_16  arc_capacity_399  1
    load_0_1_16  segment_load_conservation_666  1
    load_0_1_16  free_load_conservation_719  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_17  arc_capacity_401  -20
    arc_0_1_17  connected_order_arc_402  -13
    arc_0_1_17  out_degree_662  1
    arc_0_1_17  in_degree_721  1
    arc_0_1_17  original_T_including_depot_unload_741  552.429776828834
    MARKER    'MARKER'                 'INTEND'
    load_0_1_17  arc_capacity_401  1
    load_0_1_17  segment_load_conservation_666  1
    load_0_1_17  free_load_conservation_725  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_18  arc_capacity_403  -20
    arc_0_1_18  connected_order_arc_404  -13
    arc_0_1_18  out_degree_662  1
    arc_0_1_18  in_degree_727  1
    arc_0_1_18  original_T_including_depot_unload_741  1.1588937665971753e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_18  arc_capacity_403  1
    load_0_1_18  segment_load_conservation_666  1
    load_0_1_18  free_load_conservation_731  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_19  arc_capacity_405  -20
    arc_0_1_19  connected_order_arc_406  -13
    arc_0_1_19  out_degree_662  1
    arc_0_1_19  in_degree_733  1
    arc_0_1_19  original_T_including_depot_unload_741  8.5579830526745980e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_19  arc_capacity_405  1
    load_0_1_19  segment_load_conservation_666  1
    load_0_1_19  free_load_conservation_737  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_0  arc_capacity_407  -20
    arc_0_2_0  depot_return_or_bypass_661  1
    arc_0_2_0  out_degree_669  1
    arc_0_2_0  original_T_including_depot_unload_741  5.2273830510106120e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_0  arc_capacity_407  1
    load_0_2_0  segment_load_conservation_673  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_1  arc_capacity_408  -20
    arc_0_2_1  connected_order_arc_409  -13
    arc_0_2_1  in_degree_663  1
    arc_0_2_1  out_degree_669  1
    arc_0_2_1  original_T_including_depot_unload_741  1.6552401015053141e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_1  arc_capacity_408  1
    load_0_2_1  segment_load_conservation_666  -1
    load_0_2_1  segment_prefix_lb_667  1
    load_0_2_1  segment_prefix_ub_668  1
    load_0_2_1  segment_load_conservation_673  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_3  arc_capacity_410  -20
    arc_0_2_3  connected_order_arc_411  -13
    arc_0_2_3  out_degree_669  1
    arc_0_2_3  in_degree_677  1
    arc_0_2_3  original_T_including_depot_unload_741  1.2962070286822930e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_3  arc_capacity_410  1
    load_0_2_3  segment_load_conservation_673  1
    load_0_2_3  segment_load_conservation_680  -1
    load_0_2_3  segment_prefix_lb_681  1
    load_0_2_3  segment_prefix_ub_682  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_4  arc_capacity_412  -20
    arc_0_2_4  connected_order_arc_413  -13
    arc_0_2_4  out_degree_669  1
    arc_0_2_4  in_degree_684  1
    arc_0_2_4  original_T_including_depot_unload_741  362.349437569786
    MARKER    'MARKER'                 'INTEND'
    load_0_2_4  arc_capacity_412  1
    load_0_2_4  segment_load_conservation_673  1
    load_0_2_4  segment_load_conservation_687  -1
    load_0_2_4  segment_prefix_lb_688  1
    load_0_2_4  segment_prefix_ub_689  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_12  arc_capacity_414  -20
    arc_0_2_12  connected_order_arc_415  -13
    arc_0_2_12  out_degree_669  1
    arc_0_2_12  in_degree_691  1
    arc_0_2_12  original_T_including_depot_unload_741  1.5634365646683834e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_12  arc_capacity_414  1
    load_0_2_12  segment_load_conservation_673  1
    load_0_2_12  free_load_conservation_695  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_13  arc_capacity_416  -20
    arc_0_2_13  connected_order_arc_417  -13
    arc_0_2_13  out_degree_669  1
    arc_0_2_13  in_degree_697  1
    arc_0_2_13  original_T_including_depot_unload_741  2.1385293969918903e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_13  arc_capacity_416  1
    load_0_2_13  segment_load_conservation_673  1
    load_0_2_13  free_load_conservation_701  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_14  arc_capacity_418  -20
    arc_0_2_14  connected_order_arc_419  -13
    arc_0_2_14  out_degree_669  1
    arc_0_2_14  in_degree_703  1
    arc_0_2_14  original_T_including_depot_unload_741  1.9520133700471852e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_14  arc_capacity_418  1
    load_0_2_14  segment_load_conservation_673  1
    load_0_2_14  free_load_conservation_707  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_15  arc_capacity_420  -20
    arc_0_2_15  connected_order_arc_421  -13
    arc_0_2_15  out_degree_669  1
    arc_0_2_15  in_degree_709  1
    arc_0_2_15  original_T_including_depot_unload_741  1.5282490775772073e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_15  arc_capacity_420  1
    load_0_2_15  segment_load_conservation_673  1
    load_0_2_15  free_load_conservation_713  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_16  arc_capacity_422  -20
    arc_0_2_16  connected_order_arc_423  -13
    arc_0_2_16  out_degree_669  1
    arc_0_2_16  in_degree_715  1
    arc_0_2_16  original_T_including_depot_unload_741  1.5297878372821015e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_16  arc_capacity_422  1
    load_0_2_16  segment_load_conservation_673  1
    load_0_2_16  free_load_conservation_719  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_17  arc_capacity_424  -20
    arc_0_2_17  connected_order_arc_425  -13
    arc_0_2_17  out_degree_669  1
    arc_0_2_17  in_degree_721  1
    arc_0_2_17  original_T_including_depot_unload_741  5.3222543932043470e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_17  arc_capacity_424  1
    load_0_2_17  segment_load_conservation_673  1
    load_0_2_17  free_load_conservation_725  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_18  arc_capacity_426  -20
    arc_0_2_18  connected_order_arc_427  -13
    arc_0_2_18  out_degree_669  1
    arc_0_2_18  in_degree_727  1
    arc_0_2_18  original_T_including_depot_unload_741  1.3176071585703125e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_18  arc_capacity_426  1
    load_0_2_18  segment_load_conservation_673  1
    load_0_2_18  free_load_conservation_731  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_19  arc_capacity_428  -20
    arc_0_2_19  connected_order_arc_429  -13
    arc_0_2_19  out_degree_669  1
    arc_0_2_19  in_degree_733  1
    arc_0_2_19  original_T_including_depot_unload_741  9.5968099967049886e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_19  arc_capacity_428  1
    load_0_2_19  segment_load_conservation_673  1
    load_0_2_19  free_load_conservation_737  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_0  arc_capacity_430  -20
    arc_0_3_0  depot_return_or_bypass_661  1
    arc_0_3_0  out_degree_676  1
    arc_0_3_0  original_T_including_depot_unload_741  8.9725048283911053e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_0  arc_capacity_430  1
    load_0_3_0  segment_load_conservation_680  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_1  arc_capacity_431  -20
    arc_0_3_1  connected_order_arc_432  -13
    arc_0_3_1  in_degree_663  1
    arc_0_3_1  out_degree_676  1
    arc_0_3_1  original_T_including_depot_unload_741  7.0663858580683063e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_1  arc_capacity_431  1
    load_0_3_1  segment_load_conservation_666  -1
    load_0_3_1  segment_prefix_lb_667  1
    load_0_3_1  segment_prefix_ub_668  1
    load_0_3_1  segment_load_conservation_680  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_2  arc_capacity_433  -20
    arc_0_3_2  connected_order_arc_434  -13
    arc_0_3_2  in_degree_670  1
    arc_0_3_2  out_degree_676  1
    arc_0_3_2  original_T_including_depot_unload_741  5.4635723875297333e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_2  arc_capacity_433  1
    load_0_3_2  segment_load_conservation_673  -1
    load_0_3_2  segment_prefix_lb_674  1
    load_0_3_2  segment_prefix_ub_675  1
    load_0_3_2  segment_load_conservation_680  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_4  arc_capacity_435  -20
    arc_0_3_4  connected_order_arc_436  -13
    arc_0_3_4  out_degree_676  1
    arc_0_3_4  in_degree_684  1
    arc_0_3_4  original_T_including_depot_unload_741  8.9891387855174980e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_4  arc_capacity_435  1
    load_0_3_4  segment_load_conservation_680  1
    load_0_3_4  segment_load_conservation_687  -1
    load_0_3_4  segment_prefix_lb_688  1
    load_0_3_4  segment_prefix_ub_689  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_12  arc_capacity_437  -20
    arc_0_3_12  connected_order_arc_438  -13
    arc_0_3_12  out_degree_676  1
    arc_0_3_12  in_degree_691  1
    arc_0_3_12  original_T_including_depot_unload_741  1.5299353443215734e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_12  arc_capacity_437  1
    load_0_3_12  segment_load_conservation_680  1
    load_0_3_12  free_load_conservation_695  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_13  arc_capacity_439  -20
    arc_0_3_13  connected_order_arc_440  -13
    arc_0_3_13  out_degree_676  1
    arc_0_3_13  in_degree_697  1
    arc_0_3_13  original_T_including_depot_unload_741  2.2374987321387907e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_13  arc_capacity_439  1
    load_0_3_13  segment_load_conservation_680  1
    load_0_3_13  free_load_conservation_701  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_14  arc_capacity_441  -20
    arc_0_3_14  connected_order_arc_442  -13
    arc_0_3_14  out_degree_676  1
    arc_0_3_14  in_degree_703  1
    arc_0_3_14  original_T_including_depot_unload_741  2.4438258071820178e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_14  arc_capacity_441  1
    load_0_3_14  segment_load_conservation_680  1
    load_0_3_14  free_load_conservation_707  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_15  arc_capacity_443  -20
    arc_0_3_15  connected_order_arc_444  -13
    arc_0_3_15  out_degree_676  1
    arc_0_3_15  in_degree_709  1
    arc_0_3_15  original_T_including_depot_unload_741  1.8134227723553629e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_15  arc_capacity_443  1
    load_0_3_15  segment_load_conservation_680  1
    load_0_3_15  free_load_conservation_713  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_16  arc_capacity_445  -20
    arc_0_3_16  connected_order_arc_446  -13
    arc_0_3_16  out_degree_676  1
    arc_0_3_16  in_degree_715  1
    arc_0_3_16  original_T_including_depot_unload_741  1.8150519376858174e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_16  arc_capacity_445  1
    load_0_3_16  segment_load_conservation_680  1
    load_0_3_16  free_load_conservation_719  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_17  arc_capacity_447  -20
    arc_0_3_17  connected_order_arc_448  -13
    arc_0_3_17  out_degree_676  1
    arc_0_3_17  in_degree_721  1
    arc_0_3_17  original_T_including_depot_unload_741  6.5890455469873450e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_17  arc_capacity_447  1
    load_0_3_17  segment_load_conservation_680  1
    load_0_3_17  free_load_conservation_725  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_18  arc_capacity_449  -20
    arc_0_3_18  connected_order_arc_450  -13
    arc_0_3_18  out_degree_676  1
    arc_0_3_18  in_degree_727  1
    arc_0_3_18  original_T_including_depot_unload_741  1804.59863156495
    MARKER    'MARKER'                 'INTEND'
    load_0_3_18  arc_capacity_449  1
    load_0_3_18  segment_load_conservation_680  1
    load_0_3_18  free_load_conservation_731  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_19  arc_capacity_451  -20
    arc_0_3_19  connected_order_arc_452  -13
    arc_0_3_19  out_degree_676  1
    arc_0_3_19  in_degree_733  1
    arc_0_3_19  original_T_including_depot_unload_741  1.2980305053253444e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_19  arc_capacity_451  1
    load_0_3_19  segment_load_conservation_680  1
    load_0_3_19  free_load_conservation_737  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_0  arc_capacity_453  -20
    arc_0_4_0  depot_return_or_bypass_661  1
    arc_0_4_0  out_degree_683  1
    arc_0_4_0  original_T_including_depot_unload_741  3.8060477410436619e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_0  arc_capacity_453  1
    load_0_4_0  segment_load_conservation_687  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_1  arc_capacity_454  -20
    arc_0_4_1  connected_order_arc_455  -13
    arc_0_4_1  in_degree_663  1
    arc_0_4_1  out_degree_683  1
    arc_0_4_1  original_T_including_depot_unload_741  4.8520683722319296e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_1  arc_capacity_454  1
    load_0_4_1  segment_load_conservation_666  -1
    load_0_4_1  segment_prefix_lb_667  1
    load_0_4_1  segment_prefix_ub_668  1
    load_0_4_1  segment_load_conservation_687  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_2  arc_capacity_456  -20
    arc_0_4_2  connected_order_arc_457  -13
    arc_0_4_2  in_degree_670  1
    arc_0_4_2  out_degree_683  1
    arc_0_4_2  original_T_including_depot_unload_741  6.4485258452666415e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_2  arc_capacity_456  1
    load_0_4_2  segment_load_conservation_673  -1
    load_0_4_2  segment_prefix_lb_674  1
    load_0_4_2  segment_prefix_ub_675  1
    load_0_4_2  segment_load_conservation_687  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_3  arc_capacity_458  -20
    arc_0_4_3  connected_order_arc_459  -13
    arc_0_4_3  in_degree_677  1
    arc_0_4_3  out_degree_683  1
    arc_0_4_3  original_T_including_depot_unload_741  7.7242003812192672e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_3  arc_capacity_458  1
    load_0_4_3  segment_load_conservation_680  -1
    load_0_4_3  segment_prefix_lb_681  1
    load_0_4_3  segment_prefix_ub_682  1
    load_0_4_3  segment_load_conservation_687  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_12  arc_capacity_460  -20
    arc_0_4_12  connected_order_arc_461  -13
    arc_0_4_12  out_degree_683  1
    arc_0_4_12  in_degree_691  1
    arc_0_4_12  original_T_including_depot_unload_741  1.5168242190367512e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_12  arc_capacity_460  1
    load_0_4_12  segment_load_conservation_687  1
    load_0_4_12  free_load_conservation_695  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_13  arc_capacity_462  -20
    arc_0_4_13  connected_order_arc_463  -13
    arc_0_4_13  out_degree_683  1
    arc_0_4_13  in_degree_697  1
    arc_0_4_13  original_T_including_depot_unload_741  1.8670935270400330e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_13  arc_capacity_462  1
    load_0_4_13  segment_load_conservation_687  1
    load_0_4_13  free_load_conservation_701  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_14  arc_capacity_464  -20
    arc_0_4_14  connected_order_arc_465  -13
    arc_0_4_14  out_degree_683  1
    arc_0_4_14  in_degree_703  1
    arc_0_4_14  original_T_including_depot_unload_741  1.3072142379397485e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_14  arc_capacity_464  1
    load_0_4_14  segment_load_conservation_687  1
    load_0_4_14  free_load_conservation_707  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_15  arc_capacity_466  -20
    arc_0_4_15  connected_order_arc_467  -13
    arc_0_4_15  out_degree_683  1
    arc_0_4_15  in_degree_709  1
    arc_0_4_15  original_T_including_depot_unload_741  1.0869859877715128e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_15  arc_capacity_466  1
    load_0_4_15  segment_load_conservation_687  1
    load_0_4_15  free_load_conservation_713  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_16  arc_capacity_468  -20
    arc_0_4_16  connected_order_arc_469  -13
    arc_0_4_16  out_degree_683  1
    arc_0_4_16  in_degree_715  1
    arc_0_4_16  original_T_including_depot_unload_741  1.0882276141652012e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_16  arc_capacity_468  1
    load_0_4_16  segment_load_conservation_687  1
    load_0_4_16  free_load_conservation_719  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_17  arc_capacity_470  -20
    arc_0_4_17  connected_order_arc_471  -13
    arc_0_4_17  out_degree_683  1
    arc_0_4_17  in_degree_721  1
    arc_0_4_17  original_T_including_depot_unload_741  7.2196448570394080e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_17  arc_capacity_470  1
    load_0_4_17  segment_load_conservation_687  1
    load_0_4_17  free_load_conservation_725  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_18  arc_capacity_472  -20
    arc_0_4_18  connected_order_arc_473  -13
    arc_0_4_18  out_degree_683  1
    arc_0_4_18  in_degree_727  1
    arc_0_4_18  original_T_including_depot_unload_741  6.7368811350376711e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_18  arc_capacity_472  1
    load_0_4_18  segment_load_conservation_687  1
    load_0_4_18  free_load_conservation_731  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_19  arc_capacity_474  -20
    arc_0_4_19  connected_order_arc_475  -13
    arc_0_4_19  out_degree_683  1
    arc_0_4_19  in_degree_733  1
    arc_0_4_19  original_T_including_depot_unload_741  5.5668303114993182e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_19  arc_capacity_474  1
    load_0_4_19  segment_load_conservation_687  1
    load_0_4_19  free_load_conservation_737  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_0  arc_capacity_476  -20
    arc_0_12_0  depot_return_or_bypass_661  1
    arc_0_12_0  out_degree_690  1
    arc_0_12_0  original_T_including_depot_unload_741  1.1935953747864173e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_0  arc_capacity_476  1
    load_0_12_0  free_load_conservation_695  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_1  arc_capacity_477  -20
    arc_0_12_1  connected_order_arc_478  -13
    arc_0_12_1  in_degree_663  1
    arc_0_12_1  out_degree_690  1
    arc_0_12_1  original_T_including_depot_unload_741  1.5639034270630727e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_1  arc_capacity_477  1
    load_0_12_1  segment_load_conservation_666  -1
    load_0_12_1  segment_prefix_lb_667  1
    load_0_12_1  segment_prefix_ub_668  1
    load_0_12_1  free_load_conservation_695  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_2  arc_capacity_479  -20
    arc_0_12_2  connected_order_arc_480  -13
    arc_0_12_2  in_degree_670  1
    arc_0_12_2  out_degree_690  1
    arc_0_12_2  original_T_including_depot_unload_741  1.5634365646683834e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_2  arc_capacity_479  1
    load_0_12_2  segment_load_conservation_673  -1
    load_0_12_2  segment_prefix_lb_674  1
    load_0_12_2  segment_prefix_ub_675  1
    load_0_12_2  free_load_conservation_695  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_3  arc_capacity_481  -20
    arc_0_12_3  connected_order_arc_482  -13
    arc_0_12_3  in_degree_677  1
    arc_0_12_3  out_degree_690  1
    arc_0_12_3  original_T_including_depot_unload_741  1.6269573599812545e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_3  arc_capacity_481  1
    load_0_12_3  segment_load_conservation_680  -1
    load_0_12_3  segment_prefix_lb_681  1
    load_0_12_3  segment_prefix_ub_682  1
    load_0_12_3  free_load_conservation_695  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_4  arc_capacity_483  -20
    arc_0_12_4  connected_order_arc_484  -13
    arc_0_12_4  in_degree_684  1
    arc_0_12_4  out_degree_690  1
    arc_0_12_4  original_T_including_depot_unload_741  1.5826657352191260e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_4  arc_capacity_483  1
    load_0_12_4  segment_load_conservation_687  -1
    load_0_12_4  segment_prefix_lb_688  1
    load_0_12_4  segment_prefix_ub_689  1
    load_0_12_4  free_load_conservation_695  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_13  arc_capacity_485  -20
    arc_0_12_13  connected_order_arc_486  -13
    arc_0_12_13  out_degree_690  1
    arc_0_12_13  in_degree_697  1
    arc_0_12_13  original_T_including_depot_unload_741  7.8744552571478073e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_13  arc_capacity_485  1
    load_0_12_13  free_load_conservation_695  1
    load_0_12_13  free_load_conservation_701  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_14  arc_capacity_487  -20
    arc_0_12_14  connected_order_arc_488  -13
    arc_0_12_14  out_degree_690  1
    arc_0_12_14  in_degree_703  1
    arc_0_12_14  original_T_including_depot_unload_741  2.1501600514850211e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_14  arc_capacity_487  1
    load_0_12_14  free_load_conservation_695  1
    load_0_12_14  free_load_conservation_707  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_15  arc_capacity_489  -20
    arc_0_12_15  connected_order_arc_490  -13
    arc_0_12_15  out_degree_690  1
    arc_0_12_15  in_degree_709  1
    arc_0_12_15  original_T_including_depot_unload_741  9.7357850164388731e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_15  arc_capacity_489  1
    load_0_12_15  free_load_conservation_695  1
    load_0_12_15  free_load_conservation_713  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_16  arc_capacity_491  -20
    arc_0_12_16  connected_order_arc_492  -13
    arc_0_12_16  out_degree_690  1
    arc_0_12_16  in_degree_715  1
    arc_0_12_16  original_T_including_depot_unload_741  9.7453518552189382e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_16  arc_capacity_491  1
    load_0_12_16  free_load_conservation_695  1
    load_0_12_16  free_load_conservation_719  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_17  arc_capacity_493  -20
    arc_0_12_17  connected_order_arc_494  -13
    arc_0_12_17  out_degree_690  1
    arc_0_12_17  in_degree_721  1
    arc_0_12_17  original_T_including_depot_unload_741  1.0313568965059917e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_17  arc_capacity_493  1
    load_0_12_17  free_load_conservation_695  1
    load_0_12_17  free_load_conservation_725  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_18  arc_capacity_495  -20
    arc_0_12_18  connected_order_arc_496  -13
    arc_0_12_18  out_degree_690  1
    arc_0_12_18  in_degree_727  1
    arc_0_12_18  original_T_including_depot_unload_741  1.6988291947636669e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_18  arc_capacity_495  1
    load_0_12_18  free_load_conservation_695  1
    load_0_12_18  free_load_conservation_731  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_19  arc_capacity_497  -20
    arc_0_12_19  connected_order_arc_498  -13
    arc_0_12_19  out_degree_690  1
    arc_0_12_19  in_degree_733  1
    arc_0_12_19  original_T_including_depot_unload_741  1.0321140782598593e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_19  arc_capacity_497  1
    load_0_12_19  free_load_conservation_695  1
    load_0_12_19  free_load_conservation_737  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_0  arc_capacity_499  -20
    arc_0_13_0  depot_return_or_bypass_661  1
    arc_0_13_0  out_degree_696  1
    arc_0_13_0  original_T_including_depot_unload_741  1.6602888921784454e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_0  arc_capacity_499  1
    load_0_13_0  free_load_conservation_701  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_1  arc_capacity_500  -20
    arc_0_13_1  connected_order_arc_501  -13
    arc_0_13_1  in_degree_663  1
    arc_0_13_1  out_degree_696  1
    arc_0_13_1  original_T_including_depot_unload_741  2.0883063288244971e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_1  arc_capacity_500  1
    load_0_13_1  segment_load_conservation_666  -1
    load_0_13_1  segment_prefix_lb_667  1
    load_0_13_1  segment_prefix_ub_668  1
    load_0_13_1  free_load_conservation_701  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_2  arc_capacity_502  -20
    arc_0_13_2  connected_order_arc_503  -13
    arc_0_13_2  in_degree_670  1
    arc_0_13_2  out_degree_696  1
    arc_0_13_2  original_T_including_depot_unload_741  2.1385293969918903e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_2  arc_capacity_502  1
    load_0_13_2  segment_load_conservation_673  -1
    load_0_13_2  segment_prefix_lb_674  1
    load_0_13_2  segment_prefix_ub_675  1
    load_0_13_2  free_load_conservation_701  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_3  arc_capacity_504  -20
    arc_0_13_3  connected_order_arc_505  -13
    arc_0_13_3  in_degree_677  1
    arc_0_13_3  out_degree_696  1
    arc_0_13_3  original_T_including_depot_unload_741  2.2308484254926752e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_3  arc_capacity_504  1
    load_0_13_3  segment_load_conservation_680  -1
    load_0_13_3  segment_prefix_lb_681  1
    load_0_13_3  segment_prefix_ub_682  1
    load_0_13_3  free_load_conservation_701  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_4  arc_capacity_506  -20
    arc_0_13_4  connected_order_arc_507  -13
    arc_0_13_4  in_degree_684  1
    arc_0_13_4  out_degree_696  1
    arc_0_13_4  original_T_including_depot_unload_741  2.0400693679210435e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_4  arc_capacity_506  1
    load_0_13_4  segment_load_conservation_687  -1
    load_0_13_4  segment_prefix_lb_688  1
    load_0_13_4  segment_prefix_ub_689  1
    load_0_13_4  free_load_conservation_701  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_12  arc_capacity_508  -20
    arc_0_13_12  connected_order_arc_509  -13
    arc_0_13_12  in_degree_691  1
    arc_0_13_12  out_degree_696  1
    arc_0_13_12  original_T_including_depot_unload_741  7.8744552571478073e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_12  arc_capacity_508  1
    load_0_13_12  free_load_conservation_695  -1
    load_0_13_12  free_load_conservation_701  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_14  arc_capacity_510  -20
    arc_0_13_14  connected_order_arc_511  -13
    arc_0_13_14  out_degree_696  1
    arc_0_13_14  in_degree_703  1
    arc_0_13_14  original_T_including_depot_unload_741  1.9767828664634856e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_14  arc_capacity_510  1
    load_0_13_14  free_load_conservation_701  1
    load_0_13_14  free_load_conservation_707  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_15  arc_capacity_512  -20
    arc_0_13_15  connected_order_arc_513  -13
    arc_0_13_15  out_degree_696  1
    arc_0_13_15  in_degree_709  1
    arc_0_13_15  original_T_including_depot_unload_741  8.7049015369085737e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_15  arc_capacity_512  1
    load_0_13_15  free_load_conservation_701  1
    load_0_13_15  free_load_conservation_713  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_16  arc_capacity_514  -20
    arc_0_13_16  connected_order_arc_515  -13
    arc_0_13_16  out_degree_696  1
    arc_0_13_16  in_degree_715  1
    arc_0_13_16  original_T_including_depot_unload_741  8.7008776944597639e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_16  arc_capacity_514  1
    load_0_13_16  free_load_conservation_701  1
    load_0_13_16  free_load_conservation_719  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_17  arc_capacity_516  -20
    arc_0_13_17  connected_order_arc_517  -13
    arc_0_13_17  out_degree_696  1
    arc_0_13_17  in_degree_721  1
    arc_0_13_17  original_T_including_depot_unload_741  1.6406378986588031e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_17  arc_capacity_516  1
    load_0_13_17  free_load_conservation_701  1
    load_0_13_17  free_load_conservation_725  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_18  arc_capacity_518  -20
    arc_0_13_18  connected_order_arc_519  -13
    arc_0_13_18  out_degree_696  1
    arc_0_13_18  in_degree_727  1
    arc_0_13_18  original_T_including_depot_unload_741  1.7489191280566063e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_18  arc_capacity_518  1
    load_0_13_18  free_load_conservation_701  1
    load_0_13_18  free_load_conservation_731  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_19  arc_capacity_520  -20
    arc_0_13_19  connected_order_arc_521  -13
    arc_0_13_19  out_degree_696  1
    arc_0_13_19  in_degree_733  1
    arc_0_13_19  original_T_including_depot_unload_741  1.3104307696104611e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_19  arc_capacity_520  1
    load_0_13_19  free_load_conservation_701  1
    load_0_13_19  free_load_conservation_737  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_0  arc_capacity_522  -20
    arc_0_14_0  depot_return_or_bypass_661  1
    arc_0_14_0  out_degree_702  1
    arc_0_14_0  original_T_including_depot_unload_741  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_0  arc_capacity_522  1
    load_0_14_0  free_load_conservation_707  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_1  arc_capacity_523  -20
    arc_0_14_1  connected_order_arc_524  -13
    arc_0_14_1  in_degree_663  1
    arc_0_14_1  out_degree_702  1
    arc_0_14_1  original_T_including_depot_unload_741  1.7908610301589636e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_1  arc_capacity_523  1
    load_0_14_1  segment_load_conservation_666  -1
    load_0_14_1  segment_prefix_lb_667  1
    load_0_14_1  segment_prefix_ub_668  1
    load_0_14_1  free_load_conservation_707  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_2  arc_capacity_525  -20
    arc_0_14_2  connected_order_arc_526  -13
    arc_0_14_2  in_degree_670  1
    arc_0_14_2  out_degree_702  1
    arc_0_14_2  original_T_including_depot_unload_741  1.9520133700471852e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_2  arc_capacity_525  1
    load_0_14_2  segment_load_conservation_673  -1
    load_0_14_2  segment_prefix_lb_674  1
    load_0_14_2  segment_prefix_ub_675  1
    load_0_14_2  free_load_conservation_707  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_3  arc_capacity_527  -20
    arc_0_14_3  connected_order_arc_528  -13
    arc_0_14_3  in_degree_677  1
    arc_0_14_3  out_degree_702  1
    arc_0_14_3  original_T_including_depot_unload_741  2.0790680627934375e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_3  arc_capacity_527  1
    load_0_14_3  segment_load_conservation_680  -1
    load_0_14_3  segment_prefix_lb_681  1
    load_0_14_3  segment_prefix_ub_682  1
    load_0_14_3  free_load_conservation_707  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_4  arc_capacity_529  -20
    arc_0_14_4  connected_order_arc_530  -13
    arc_0_14_4  in_degree_684  1
    arc_0_14_4  out_degree_702  1
    arc_0_14_4  original_T_including_depot_unload_741  1.5992308845216928e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_4  arc_capacity_529  1
    load_0_14_4  segment_load_conservation_687  -1
    load_0_14_4  segment_prefix_lb_688  1
    load_0_14_4  segment_prefix_ub_689  1
    load_0_14_4  free_load_conservation_707  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_12  arc_capacity_531  -20
    arc_0_14_12  connected_order_arc_532  -13
    arc_0_14_12  in_degree_691  1
    arc_0_14_12  out_degree_702  1
    arc_0_14_12  original_T_including_depot_unload_741  2.1501600514850211e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_12  arc_capacity_531  1
    load_0_14_12  free_load_conservation_695  -1
    load_0_14_12  free_load_conservation_707  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_13  arc_capacity_533  -20
    arc_0_14_13  connected_order_arc_534  -13
    arc_0_14_13  in_degree_697  1
    arc_0_14_13  out_degree_702  1
    arc_0_14_13  original_T_including_depot_unload_741  1.9767828664634856e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_13  arc_capacity_533  1
    load_0_14_13  free_load_conservation_701  -1
    load_0_14_13  free_load_conservation_707  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_15  arc_capacity_535  -20
    arc_0_14_15  connected_order_arc_536  -13
    arc_0_14_15  out_degree_702  1
    arc_0_14_15  in_degree_709  1
    arc_0_14_15  original_T_including_depot_unload_741  1.1967280409234234e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_15  arc_capacity_535  1
    load_0_14_15  free_load_conservation_707  1
    load_0_14_15  free_load_conservation_713  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_16  arc_capacity_537  -20
    arc_0_14_16  connected_order_arc_538  -13
    arc_0_14_16  out_degree_702  1
    arc_0_14_16  in_degree_715  1
    arc_0_14_16  original_T_including_depot_unload_741  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_16  arc_capacity_537  1
    load_0_14_16  free_load_conservation_707  1
    load_0_14_16  free_load_conservation_719  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_17  arc_capacity_539  -20
    arc_0_14_17  connected_order_arc_540  -13
    arc_0_14_17  out_degree_702  1
    arc_0_14_17  in_degree_721  1
    arc_0_14_17  original_T_including_depot_unload_741  1.8911324761641883e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_17  arc_capacity_539  1
    load_0_14_17  free_load_conservation_707  1
    load_0_14_17  free_load_conservation_725  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_18  arc_capacity_541  -20
    arc_0_14_18  connected_order_arc_542  -13
    arc_0_14_18  out_degree_702  1
    arc_0_14_18  in_degree_727  1
    arc_0_14_18  original_T_including_depot_unload_741  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_0_14_18  arc_capacity_541  1
    load_0_14_18  free_load_conservation_707  1
    load_0_14_18  free_load_conservation_731  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_19  arc_capacity_543  -20
    arc_0_14_19  connected_order_arc_544  -13
    arc_0_14_19  out_degree_702  1
    arc_0_14_19  in_degree_733  1
    arc_0_14_19  original_T_including_depot_unload_741  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_19  arc_capacity_543  1
    load_0_14_19  free_load_conservation_707  1
    load_0_14_19  free_load_conservation_737  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_0  arc_capacity_545  -20
    arc_0_15_0  depot_return_or_bypass_661  1
    arc_0_15_0  out_degree_708  1
    arc_0_15_0  original_T_including_depot_unload_741  1.0056399980521732e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_0  arc_capacity_545  1
    load_0_15_0  free_load_conservation_713  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_1  arc_capacity_546  -20
    arc_0_15_1  connected_order_arc_547  -13
    arc_0_15_1  in_degree_663  1
    arc_0_15_1  out_degree_708  1
    arc_0_15_1  original_T_including_depot_unload_741  1.4285403548915413e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_1  arc_capacity_546  1
    load_0_15_1  segment_load_conservation_666  -1
    load_0_15_1  segment_prefix_lb_667  1
    load_0_15_1  segment_prefix_ub_668  1
    load_0_15_1  free_load_conservation_713  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_2  arc_capacity_548  -20
    arc_0_15_2  connected_order_arc_549  -13
    arc_0_15_2  in_degree_670  1
    arc_0_15_2  out_degree_708  1
    arc_0_15_2  original_T_including_depot_unload_741  1.5282490775772073e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_2  arc_capacity_548  1
    load_0_15_2  segment_load_conservation_673  -1
    load_0_15_2  segment_prefix_lb_674  1
    load_0_15_2  segment_prefix_ub_675  1
    load_0_15_2  free_load_conservation_713  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_3  arc_capacity_550  -20
    arc_0_15_3  connected_order_arc_551  -13
    arc_0_15_3  in_degree_677  1
    arc_0_15_3  out_degree_708  1
    arc_0_15_3  original_T_including_depot_unload_741  1.6457152999301718e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_3  arc_capacity_550  1
    load_0_15_3  segment_load_conservation_680  -1
    load_0_15_3  segment_prefix_lb_681  1
    load_0_15_3  segment_prefix_ub_682  1
    load_0_15_3  free_load_conservation_713  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_4  arc_capacity_552  -20
    arc_0_15_4  connected_order_arc_553  -13
    arc_0_15_4  in_degree_684  1
    arc_0_15_4  out_degree_708  1
    arc_0_15_4  original_T_including_depot_unload_741  1.3232349913962587e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_4  arc_capacity_552  1
    load_0_15_4  segment_load_conservation_687  -1
    load_0_15_4  segment_prefix_lb_688  1
    load_0_15_4  segment_prefix_ub_689  1
    load_0_15_4  free_load_conservation_713  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_12  arc_capacity_554  -20
    arc_0_15_12  connected_order_arc_555  -13
    arc_0_15_12  in_degree_691  1
    arc_0_15_12  out_degree_708  1
    arc_0_15_12  original_T_including_depot_unload_741  9.7357850164388731e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_12  arc_capacity_554  1
    load_0_15_12  free_load_conservation_695  -1
    load_0_15_12  free_load_conservation_713  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_13  arc_capacity_556  -20
    arc_0_15_13  connected_order_arc_557  -13
    arc_0_15_13  in_degree_697  1
    arc_0_15_13  out_degree_708  1
    arc_0_15_13  original_T_including_depot_unload_741  8.7049015369085737e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_13  arc_capacity_556  1
    load_0_15_13  free_load_conservation_701  -1
    load_0_15_13  free_load_conservation_713  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_14  arc_capacity_558  -20
    arc_0_15_14  connected_order_arc_559  -13
    arc_0_15_14  in_degree_703  1
    arc_0_15_14  out_degree_708  1
    arc_0_15_14  original_T_including_depot_unload_741  1.1967280409234234e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_14  arc_capacity_558  1
    load_0_15_14  free_load_conservation_707  -1
    load_0_15_14  free_load_conservation_713  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_16  arc_capacity_560  -20
    arc_0_15_16  connected_order_arc_561  -13
    arc_0_15_16  out_degree_708  1
    arc_0_15_16  in_degree_715  1
    arc_0_15_16  original_T_including_depot_unload_741  1.6320002720932780e+00
    MARKER    'MARKER'                 'INTEND'
    load_0_15_16  arc_capacity_560  1
    load_0_15_16  free_load_conservation_713  1
    load_0_15_16  free_load_conservation_719  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_17  arc_capacity_562  -20
    arc_0_15_17  connected_order_arc_563  -13
    arc_0_15_17  out_degree_708  1
    arc_0_15_17  in_degree_721  1
    arc_0_15_17  original_T_including_depot_unload_741  1.1545648513745866e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_17  arc_capacity_562  1
    load_0_15_17  free_load_conservation_713  1
    load_0_15_17  free_load_conservation_725  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_18  arc_capacity_564  -20
    arc_0_15_18  connected_order_arc_565  -13
    arc_0_15_18  out_degree_708  1
    arc_0_15_18  in_degree_727  1
    arc_0_15_18  original_T_including_depot_unload_741  8.7906342149593650e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_18  arc_capacity_564  1
    load_0_15_18  free_load_conservation_713  1
    load_0_15_18  free_load_conservation_731  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_19  arc_capacity_566  -20
    arc_0_15_19  connected_order_arc_567  -13
    arc_0_15_19  out_degree_708  1
    arc_0_15_19  in_degree_733  1
    arc_0_15_19  original_T_including_depot_unload_741  5.7276146581216926e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_19  arc_capacity_566  1
    load_0_15_19  free_load_conservation_713  1
    load_0_15_19  free_load_conservation_737  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_0  arc_capacity_568  -20
    arc_0_16_0  depot_return_or_bypass_661  1
    arc_0_16_0  out_degree_714  1
    arc_0_16_0  original_T_including_depot_unload_741  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_0  arc_capacity_568  1
    load_0_16_0  free_load_conservation_719  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_1  arc_capacity_569  -20
    arc_0_16_1  connected_order_arc_570  -13
    arc_0_16_1  in_degree_663  1
    arc_0_16_1  out_degree_714  1
    arc_0_16_1  original_T_including_depot_unload_741  1.4300244315666421e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_1  arc_capacity_569  1
    load_0_16_1  segment_load_conservation_666  -1
    load_0_16_1  segment_prefix_lb_667  1
    load_0_16_1  segment_prefix_ub_668  1
    load_0_16_1  free_load_conservation_719  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_2  arc_capacity_571  -20
    arc_0_16_2  connected_order_arc_572  -13
    arc_0_16_2  in_degree_670  1
    arc_0_16_2  out_degree_714  1
    arc_0_16_2  original_T_including_depot_unload_741  1.5297878372821015e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_2  arc_capacity_571  1
    load_0_16_2  segment_load_conservation_673  -1
    load_0_16_2  segment_prefix_lb_674  1
    load_0_16_2  segment_prefix_ub_675  1
    load_0_16_2  free_load_conservation_719  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_3  arc_capacity_573  -20
    arc_0_16_3  connected_order_arc_574  -13
    arc_0_16_3  in_degree_677  1
    arc_0_16_3  out_degree_714  1
    arc_0_16_3  original_T_including_depot_unload_741  1.6472719129023171e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_3  arc_capacity_573  1
    load_0_16_3  segment_load_conservation_680  -1
    load_0_16_3  segment_prefix_lb_681  1
    load_0_16_3  segment_prefix_ub_682  1
    load_0_16_3  free_load_conservation_719  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_4  arc_capacity_575  -20
    arc_0_16_4  connected_order_arc_576  -13
    arc_0_16_4  in_degree_684  1
    arc_0_16_4  out_degree_714  1
    arc_0_16_4  original_T_including_depot_unload_741  1.3246263055739521e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_4  arc_capacity_575  1
    load_0_16_4  segment_load_conservation_687  -1
    load_0_16_4  segment_prefix_lb_688  1
    load_0_16_4  segment_prefix_ub_689  1
    load_0_16_4  free_load_conservation_719  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_12  arc_capacity_577  -20
    arc_0_16_12  connected_order_arc_578  -13
    arc_0_16_12  in_degree_691  1
    arc_0_16_12  out_degree_714  1
    arc_0_16_12  original_T_including_depot_unload_741  9.7453518552189382e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_12  arc_capacity_577  1
    load_0_16_12  free_load_conservation_695  -1
    load_0_16_12  free_load_conservation_719  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_13  arc_capacity_579  -20
    arc_0_16_13  connected_order_arc_580  -13
    arc_0_16_13  in_degree_697  1
    arc_0_16_13  out_degree_714  1
    arc_0_16_13  original_T_including_depot_unload_741  8.7008776944597639e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_13  arc_capacity_579  1
    load_0_16_13  free_load_conservation_701  -1
    load_0_16_13  free_load_conservation_719  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_14  arc_capacity_581  -20
    arc_0_16_14  connected_order_arc_582  -13
    arc_0_16_14  in_degree_703  1
    arc_0_16_14  out_degree_714  1
    arc_0_16_14  original_T_including_depot_unload_741  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_14  arc_capacity_581  1
    load_0_16_14  free_load_conservation_707  -1
    load_0_16_14  free_load_conservation_719  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_15  arc_capacity_583  -20
    arc_0_16_15  connected_order_arc_584  -13
    arc_0_16_15  in_degree_709  1
    arc_0_16_15  out_degree_714  1
    arc_0_16_15  original_T_including_depot_unload_741  1.6320002720932780e+00
    MARKER    'MARKER'                 'INTEND'
    load_0_16_15  arc_capacity_583  1
    load_0_16_15  free_load_conservation_713  -1
    load_0_16_15  free_load_conservation_719  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_17  arc_capacity_585  -20
    arc_0_16_17  connected_order_arc_586  -13
    arc_0_16_17  out_degree_714  1
    arc_0_16_17  in_degree_721  1
    arc_0_16_17  original_T_including_depot_unload_741  1.1561945146971345e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_17  arc_capacity_585  1
    load_0_16_17  free_load_conservation_719  1
    load_0_16_17  free_load_conservation_725  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_18  arc_capacity_587  -20
    arc_0_16_18  connected_order_arc_588  -13
    arc_0_16_18  out_degree_714  1
    arc_0_16_18  in_degree_727  1
    arc_0_16_18  original_T_including_depot_unload_741  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_18  arc_capacity_587  1
    load_0_16_18  free_load_conservation_719  1
    load_0_16_18  free_load_conservation_731  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_19  arc_capacity_589  -20
    arc_0_16_19  connected_order_arc_590  -13
    arc_0_16_19  out_degree_714  1
    arc_0_16_19  in_degree_733  1
    arc_0_16_19  original_T_including_depot_unload_741  5.7424143497696048e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_19  arc_capacity_589  1
    load_0_16_19  free_load_conservation_719  1
    load_0_16_19  free_load_conservation_737  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_0  arc_capacity_591  -20
    arc_0_17_0  depot_return_or_bypass_661  1
    arc_0_17_0  out_degree_720  1
    arc_0_17_0  original_T_including_depot_unload_741  3.5061909388980052e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_0  arc_capacity_591  1
    load_0_17_0  free_load_conservation_725  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_1  arc_capacity_592  -20
    arc_0_17_1  connected_order_arc_593  -13
    arc_0_17_1  in_degree_663  1
    arc_0_17_1  out_degree_720  1
    arc_0_17_1  original_T_including_depot_unload_741  552.429776828834
    MARKER    'MARKER'                 'INTEND'
    load_0_17_1  arc_capacity_592  1
    load_0_17_1  segment_load_conservation_666  -1
    load_0_17_1  segment_prefix_lb_667  1
    load_0_17_1  segment_prefix_ub_668  1
    load_0_17_1  free_load_conservation_725  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_2  arc_capacity_594  -20
    arc_0_17_2  connected_order_arc_595  -13
    arc_0_17_2  in_degree_670  1
    arc_0_17_2  out_degree_720  1
    arc_0_17_2  original_T_including_depot_unload_741  5.3222543932043470e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_2  arc_capacity_594  1
    load_0_17_2  segment_load_conservation_673  -1
    load_0_17_2  segment_prefix_lb_674  1
    load_0_17_2  segment_prefix_ub_675  1
    load_0_17_2  free_load_conservation_725  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_3  arc_capacity_596  -20
    arc_0_17_3  connected_order_arc_597  -13
    arc_0_17_3  in_degree_677  1
    arc_0_17_3  out_degree_720  1
    arc_0_17_3  original_T_including_depot_unload_741  6.0082621405522366e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_3  arc_capacity_596  1
    load_0_17_3  segment_load_conservation_680  -1
    load_0_17_3  segment_prefix_lb_681  1
    load_0_17_3  segment_prefix_ub_682  1
    load_0_17_3  free_load_conservation_725  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_4  arc_capacity_598  -20
    arc_0_17_4  connected_order_arc_599  -13
    arc_0_17_4  in_degree_684  1
    arc_0_17_4  out_degree_720  1
    arc_0_17_4  original_T_including_depot_unload_741  6.3069852135268593e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_4  arc_capacity_598  1
    load_0_17_4  segment_load_conservation_687  -1
    load_0_17_4  segment_prefix_lb_688  1
    load_0_17_4  segment_prefix_ub_689  1
    load_0_17_4  free_load_conservation_725  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_12  arc_capacity_600  -20
    arc_0_17_12  connected_order_arc_601  -13
    arc_0_17_12  in_degree_691  1
    arc_0_17_12  out_degree_720  1
    arc_0_17_12  original_T_including_depot_unload_741  1.0313568965059917e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_12  arc_capacity_600  1
    load_0_17_12  free_load_conservation_695  -1
    load_0_17_12  free_load_conservation_725  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_13  arc_capacity_602  -20
    arc_0_17_13  connected_order_arc_603  -13
    arc_0_17_13  in_degree_697  1
    arc_0_17_13  out_degree_720  1
    arc_0_17_13  original_T_including_depot_unload_741  1.6406378986588031e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_13  arc_capacity_602  1
    load_0_17_13  free_load_conservation_701  -1
    load_0_17_13  free_load_conservation_725  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_14  arc_capacity_604  -20
    arc_0_17_14  connected_order_arc_605  -13
    arc_0_17_14  in_degree_703  1
    arc_0_17_14  out_degree_720  1
    arc_0_17_14  original_T_including_depot_unload_741  1.8911324761641883e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_14  arc_capacity_604  1
    load_0_17_14  free_load_conservation_707  -1
    load_0_17_14  free_load_conservation_725  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_15  arc_capacity_606  -20
    arc_0_17_15  connected_order_arc_607  -13
    arc_0_17_15  in_degree_709  1
    arc_0_17_15  out_degree_720  1
    arc_0_17_15  original_T_including_depot_unload_741  1.1545648513745866e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_15  arc_capacity_606  1
    load_0_17_15  free_load_conservation_713  -1
    load_0_17_15  free_load_conservation_725  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_16  arc_capacity_608  -20
    arc_0_17_16  connected_order_arc_609  -13
    arc_0_17_16  in_degree_715  1
    arc_0_17_16  out_degree_720  1
    arc_0_17_16  original_T_including_depot_unload_741  1.1561945146971345e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_16  arc_capacity_608  1
    load_0_17_16  free_load_conservation_719  -1
    load_0_17_16  free_load_conservation_725  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_18  arc_capacity_610  -20
    arc_0_17_18  connected_order_arc_611  -13
    arc_0_17_18  out_degree_720  1
    arc_0_17_18  in_degree_727  1
    arc_0_17_18  original_T_including_depot_unload_741  1.2665309635243570e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_18  arc_capacity_610  1
    load_0_17_18  free_load_conservation_725  1
    load_0_17_18  free_load_conservation_731  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_19  arc_capacity_612  -20
    arc_0_17_19  connected_order_arc_613  -13
    arc_0_17_19  out_degree_720  1
    arc_0_17_19  in_degree_733  1
    arc_0_17_19  original_T_including_depot_unload_741  6.5869285599668615e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_19  arc_capacity_612  1
    load_0_17_19  free_load_conservation_725  1
    load_0_17_19  free_load_conservation_737  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_0  arc_capacity_614  -20
    arc_0_18_0  depot_return_or_bypass_661  1
    arc_0_18_0  out_degree_726  1
    arc_0_18_0  original_T_including_depot_unload_741  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_0  arc_capacity_614  1
    load_0_18_0  free_load_conservation_731  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_1  arc_capacity_615  -20
    arc_0_18_1  connected_order_arc_616  -13
    arc_0_18_1  in_degree_663  1
    arc_0_18_1  out_degree_726  1
    arc_0_18_1  original_T_including_depot_unload_741  1.1588937665971753e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_1  arc_capacity_615  1
    load_0_18_1  segment_load_conservation_666  -1
    load_0_18_1  segment_prefix_lb_667  1
    load_0_18_1  segment_prefix_ub_668  1
    load_0_18_1  free_load_conservation_731  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_2  arc_capacity_617  -20
    arc_0_18_2  connected_order_arc_618  -13
    arc_0_18_2  in_degree_670  1
    arc_0_18_2  out_degree_726  1
    arc_0_18_2  original_T_including_depot_unload_741  1.3176071585703125e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_2  arc_capacity_617  1
    load_0_18_2  segment_load_conservation_673  -1
    load_0_18_2  segment_prefix_lb_674  1
    load_0_18_2  segment_prefix_ub_675  1
    load_0_18_2  free_load_conservation_731  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_3  arc_capacity_619  -20
    arc_0_18_3  connected_order_arc_620  -13
    arc_0_18_3  in_degree_677  1
    arc_0_18_3  out_degree_726  1
    arc_0_18_3  original_T_including_depot_unload_741  1.4457797980495495e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_3  arc_capacity_619  1
    load_0_18_3  segment_load_conservation_680  -1
    load_0_18_3  segment_prefix_lb_681  1
    load_0_18_3  segment_prefix_ub_682  1
    load_0_18_3  free_load_conservation_731  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_4  arc_capacity_621  -20
    arc_0_18_4  connected_order_arc_622  -13
    arc_0_18_4  in_degree_684  1
    arc_0_18_4  out_degree_726  1
    arc_0_18_4  original_T_including_depot_unload_741  9.7154140307447824e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_4  arc_capacity_621  1
    load_0_18_4  segment_load_conservation_687  -1
    load_0_18_4  segment_prefix_lb_688  1
    load_0_18_4  segment_prefix_ub_689  1
    load_0_18_4  free_load_conservation_731  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_12  arc_capacity_623  -20
    arc_0_18_12  connected_order_arc_624  -13
    arc_0_18_12  in_degree_691  1
    arc_0_18_12  out_degree_726  1
    arc_0_18_12  original_T_including_depot_unload_741  1.6988291947636669e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_12  arc_capacity_623  1
    load_0_18_12  free_load_conservation_695  -1
    load_0_18_12  free_load_conservation_731  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_13  arc_capacity_625  -20
    arc_0_18_13  connected_order_arc_626  -13
    arc_0_18_13  in_degree_697  1
    arc_0_18_13  out_degree_726  1
    arc_0_18_13  original_T_including_depot_unload_741  1.7489191280566063e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_13  arc_capacity_625  1
    load_0_18_13  free_load_conservation_701  -1
    load_0_18_13  free_load_conservation_731  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_14  arc_capacity_627  -20
    arc_0_18_14  connected_order_arc_628  -13
    arc_0_18_14  in_degree_703  1
    arc_0_18_14  out_degree_726  1
    arc_0_18_14  original_T_including_depot_unload_741  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_0_18_14  arc_capacity_627  1
    load_0_18_14  free_load_conservation_707  -1
    load_0_18_14  free_load_conservation_731  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_15  arc_capacity_629  -20
    arc_0_18_15  connected_order_arc_630  -13
    arc_0_18_15  in_degree_709  1
    arc_0_18_15  out_degree_726  1
    arc_0_18_15  original_T_including_depot_unload_741  8.7906342149593650e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_15  arc_capacity_629  1
    load_0_18_15  free_load_conservation_713  -1
    load_0_18_15  free_load_conservation_731  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_16  arc_capacity_631  -20
    arc_0_18_16  connected_order_arc_632  -13
    arc_0_18_16  in_degree_715  1
    arc_0_18_16  out_degree_726  1
    arc_0_18_16  original_T_including_depot_unload_741  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_16  arc_capacity_631  1
    load_0_18_16  free_load_conservation_719  -1
    load_0_18_16  free_load_conservation_731  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_17  arc_capacity_633  -20
    arc_0_18_17  connected_order_arc_634  -13
    arc_0_18_17  in_degree_721  1
    arc_0_18_17  out_degree_726  1
    arc_0_18_17  original_T_including_depot_unload_741  1.2665309635243570e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_17  arc_capacity_633  1
    load_0_18_17  free_load_conservation_725  -1
    load_0_18_17  free_load_conservation_731  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_19  arc_capacity_635  -20
    arc_0_18_19  connected_order_arc_636  -13
    arc_0_18_19  out_degree_726  1
    arc_0_18_19  in_degree_733  1
    arc_0_18_19  original_T_including_depot_unload_741  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_0_18_19  arc_capacity_635  1
    load_0_18_19  free_load_conservation_731  1
    load_0_18_19  free_load_conservation_737  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_0  arc_capacity_637  -20
    arc_0_19_0  depot_return_or_bypass_661  1
    arc_0_19_0  out_degree_732  1
    arc_0_19_0  original_T_including_depot_unload_741  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_0  arc_capacity_637  1
    load_0_19_0  free_load_conservation_737  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_1  arc_capacity_638  -20
    arc_0_19_1  connected_order_arc_639  -13
    arc_0_19_1  in_degree_663  1
    arc_0_19_1  out_degree_732  1
    arc_0_19_1  original_T_including_depot_unload_741  8.5579830526745980e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_1  arc_capacity_638  1
    load_0_19_1  segment_load_conservation_666  -1
    load_0_19_1  segment_prefix_lb_667  1
    load_0_19_1  segment_prefix_ub_668  1
    load_0_19_1  free_load_conservation_737  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_2  arc_capacity_640  -20
    arc_0_19_2  connected_order_arc_641  -13
    arc_0_19_2  in_degree_670  1
    arc_0_19_2  out_degree_732  1
    arc_0_19_2  original_T_including_depot_unload_741  9.5968099967049886e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_2  arc_capacity_640  1
    load_0_19_2  segment_load_conservation_673  -1
    load_0_19_2  segment_prefix_lb_674  1
    load_0_19_2  segment_prefix_ub_675  1
    load_0_19_2  free_load_conservation_737  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_3  arc_capacity_642  -20
    arc_0_19_3  connected_order_arc_643  -13
    arc_0_19_3  in_degree_677  1
    arc_0_19_3  out_degree_732  1
    arc_0_19_3  original_T_including_depot_unload_741  1.0803844170008674e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_3  arc_capacity_642  1
    load_0_19_3  segment_load_conservation_680  -1
    load_0_19_3  segment_prefix_lb_681  1
    load_0_19_3  segment_prefix_ub_682  1
    load_0_19_3  free_load_conservation_737  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_4  arc_capacity_644  -20
    arc_0_19_4  connected_order_arc_645  -13
    arc_0_19_4  in_degree_684  1
    arc_0_19_4  out_degree_732  1
    arc_0_19_4  original_T_including_depot_unload_741  7.5707648242091466e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_4  arc_capacity_644  1
    load_0_19_4  segment_load_conservation_687  -1
    load_0_19_4  segment_prefix_lb_688  1
    load_0_19_4  segment_prefix_ub_689  1
    load_0_19_4  free_load_conservation_737  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_12  arc_capacity_646  -20
    arc_0_19_12  connected_order_arc_647  -13
    arc_0_19_12  in_degree_691  1
    arc_0_19_12  out_degree_732  1
    arc_0_19_12  original_T_including_depot_unload_741  1.0321140782598593e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_12  arc_capacity_646  1
    load_0_19_12  free_load_conservation_695  -1
    load_0_19_12  free_load_conservation_737  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_13  arc_capacity_648  -20
    arc_0_19_13  connected_order_arc_649  -13
    arc_0_19_13  in_degree_697  1
    arc_0_19_13  out_degree_732  1
    arc_0_19_13  original_T_including_depot_unload_741  1.3104307696104611e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_13  arc_capacity_648  1
    load_0_19_13  free_load_conservation_701  -1
    load_0_19_13  free_load_conservation_737  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_14  arc_capacity_650  -20
    arc_0_19_14  connected_order_arc_651  -13
    arc_0_19_14  in_degree_703  1
    arc_0_19_14  out_degree_732  1
    arc_0_19_14  original_T_including_depot_unload_741  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_14  arc_capacity_650  1
    load_0_19_14  free_load_conservation_707  -1
    load_0_19_14  free_load_conservation_737  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_15  arc_capacity_652  -20
    arc_0_19_15  connected_order_arc_653  -13
    arc_0_19_15  in_degree_709  1
    arc_0_19_15  out_degree_732  1
    arc_0_19_15  original_T_including_depot_unload_741  5.7276146581216926e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_15  arc_capacity_652  1
    load_0_19_15  free_load_conservation_713  -1
    load_0_19_15  free_load_conservation_737  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_16  arc_capacity_654  -20
    arc_0_19_16  connected_order_arc_655  -13
    arc_0_19_16  in_degree_715  1
    arc_0_19_16  out_degree_732  1
    arc_0_19_16  original_T_including_depot_unload_741  5.7424143497696048e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_16  arc_capacity_654  1
    load_0_19_16  free_load_conservation_719  -1
    load_0_19_16  free_load_conservation_737  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_17  arc_capacity_656  -20
    arc_0_19_17  connected_order_arc_657  -13
    arc_0_19_17  in_degree_721  1
    arc_0_19_17  out_degree_732  1
    arc_0_19_17  original_T_including_depot_unload_741  6.5869285599668615e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_17  arc_capacity_656  1
    load_0_19_17  free_load_conservation_725  -1
    load_0_19_17  free_load_conservation_737  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_18  arc_capacity_658  -20
    arc_0_19_18  connected_order_arc_659  -13
    arc_0_19_18  in_degree_727  1
    arc_0_19_18  out_degree_732  1
    arc_0_19_18  original_T_including_depot_unload_741  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_0_19_18  arc_capacity_658  1
    load_0_19_18  free_load_conservation_731  -1
    load_0_19_18  free_load_conservation_737  1
    visit_1_5  out_degree_987  -1
    visit_1_5  in_degree_988  -1
    visit_1_5  order_active_lb_989  -1
    visit_1_5  order_active_ub_990  -11
    order_1_5  connected_order_arc_756  -1
    order_1_5  connected_order_arc_758  -1
    order_1_5  connected_order_arc_760  -1
    order_1_5  connected_order_arc_762  -1
    order_1_5  connected_order_arc_764  -1
    order_1_5  connected_order_arc_766  -1
    order_1_5  connected_order_arc_768  -1
    order_1_5  connected_order_arc_770  -1
    order_1_5  connected_order_arc_772  -1
    order_1_5  connected_order_arc_774  -1
    order_1_5  connected_order_arc_777  1
    order_1_5  connected_order_arc_798  1
    order_1_5  connected_order_arc_819  1
    order_1_5  connected_order_arc_840  1
    order_1_5  connected_order_arc_861  1
    order_1_5  connected_order_arc_882  1
    order_1_5  connected_order_arc_903  1
    order_1_5  connected_order_arc_924  1
    order_1_5  connected_order_arc_945  1
    order_1_5  connected_order_arc_966  1
    order_1_5  order_active_lb_989  1
    order_1_5  order_active_ub_990  1
    order_1_5  fixed_segment_relative_order_1056  -1
    visit_1_6  out_degree_994  -1
    visit_1_6  in_degree_995  -1
    visit_1_6  order_active_lb_996  -1
    visit_1_6  order_active_ub_997  -11
    order_1_6  connected_order_arc_756  1
    order_1_6  connected_order_arc_777  -1
    order_1_6  connected_order_arc_779  -1
    order_1_6  connected_order_arc_781  -1
    order_1_6  connected_order_arc_783  -1
    order_1_6  connected_order_arc_785  -1
    order_1_6  connected_order_arc_787  -1
    order_1_6  connected_order_arc_789  -1
    order_1_6  connected_order_arc_791  -1
    order_1_6  connected_order_arc_793  -1
    order_1_6  connected_order_arc_795  -1
    order_1_6  connected_order_arc_800  1
    order_1_6  connected_order_arc_821  1
    order_1_6  connected_order_arc_842  1
    order_1_6  connected_order_arc_863  1
    order_1_6  connected_order_arc_884  1
    order_1_6  connected_order_arc_905  1
    order_1_6  connected_order_arc_926  1
    order_1_6  connected_order_arc_947  1
    order_1_6  connected_order_arc_968  1
    order_1_6  order_active_lb_996  1
    order_1_6  order_active_ub_997  1
    order_1_6  fixed_segment_relative_order_1056  1
    order_1_6  fixed_segment_relative_order_1057  -1
    visit_1_7  out_degree_1001  -1
    visit_1_7  in_degree_1002  -1
    visit_1_7  order_active_lb_1003  -1
    visit_1_7  order_active_ub_1004  -11
    order_1_7  connected_order_arc_758  1
    order_1_7  connected_order_arc_779  1
    order_1_7  connected_order_arc_798  -1
    order_1_7  connected_order_arc_800  -1
    order_1_7  connected_order_arc_802  -1
    order_1_7  connected_order_arc_804  -1
    order_1_7  connected_order_arc_806  -1
    order_1_7  connected_order_arc_808  -1
    order_1_7  connected_order_arc_810  -1
    order_1_7  connected_order_arc_812  -1
    order_1_7  connected_order_arc_814  -1
    order_1_7  connected_order_arc_816  -1
    order_1_7  connected_order_arc_823  1
    order_1_7  connected_order_arc_844  1
    order_1_7  connected_order_arc_865  1
    order_1_7  connected_order_arc_886  1
    order_1_7  connected_order_arc_907  1
    order_1_7  connected_order_arc_928  1
    order_1_7  connected_order_arc_949  1
    order_1_7  connected_order_arc_970  1
    order_1_7  order_active_lb_1003  1
    order_1_7  order_active_ub_1004  1
    order_1_7  fixed_segment_relative_order_1057  1
    visit_1_12  out_degree_1008  -1
    visit_1_12  in_degree_1009  -1
    visit_1_12  order_active_lb_1010  -1
    visit_1_12  order_active_ub_1011  -11
    visit_1_12  service_visit_def_1012  -1
    order_1_12  connected_order_arc_760  1
    order_1_12  connected_order_arc_781  1
    order_1_12  connected_order_arc_802  1
    order_1_12  connected_order_arc_819  -1
    order_1_12  connected_order_arc_821  -1
    order_1_12  connected_order_arc_823  -1
    order_1_12  connected_order_arc_825  -1
    order_1_12  connected_order_arc_827  -1
    order_1_12  connected_order_arc_829  -1
    order_1_12  connected_order_arc_831  -1
    order_1_12  connected_order_arc_833  -1
    order_1_12  connected_order_arc_835  -1
    order_1_12  connected_order_arc_837  -1
    order_1_12  connected_order_arc_846  1
    order_1_12  connected_order_arc_867  1
    order_1_12  connected_order_arc_888  1
    order_1_12  connected_order_arc_909  1
    order_1_12  connected_order_arc_930  1
    order_1_12  connected_order_arc_951  1
    order_1_12  connected_order_arc_972  1
    order_1_12  order_active_lb_1010  1
    order_1_12  order_active_ub_1011  1
    visit_1_13  out_degree_1014  -1
    visit_1_13  in_degree_1015  -1
    visit_1_13  order_active_lb_1016  -1
    visit_1_13  order_active_ub_1017  -11
    visit_1_13  service_visit_def_1018  -1
    order_1_13  connected_order_arc_762  1
    order_1_13  connected_order_arc_783  1
    order_1_13  connected_order_arc_804  1
    order_1_13  connected_order_arc_825  1
    order_1_13  connected_order_arc_840  -1
    order_1_13  connected_order_arc_842  -1
    order_1_13  connected_order_arc_844  -1
    order_1_13  connected_order_arc_846  -1
    order_1_13  connected_order_arc_848  -1
    order_1_13  connected_order_arc_850  -1
    order_1_13  connected_order_arc_852  -1
    order_1_13  connected_order_arc_854  -1
    order_1_13  connected_order_arc_856  -1
    order_1_13  connected_order_arc_858  -1
    order_1_13  connected_order_arc_869  1
    order_1_13  connected_order_arc_890  1
    order_1_13  connected_order_arc_911  1
    order_1_13  connected_order_arc_932  1
    order_1_13  connected_order_arc_953  1
    order_1_13  connected_order_arc_974  1
    order_1_13  order_active_lb_1016  1
    order_1_13  order_active_ub_1017  1
    visit_1_14  out_degree_1020  -1
    visit_1_14  in_degree_1021  -1
    visit_1_14  order_active_lb_1022  -1
    visit_1_14  order_active_ub_1023  -11
    visit_1_14  service_visit_def_1024  -1
    order_1_14  connected_order_arc_764  1
    order_1_14  connected_order_arc_785  1
    order_1_14  connected_order_arc_806  1
    order_1_14  connected_order_arc_827  1
    order_1_14  connected_order_arc_848  1
    order_1_14  connected_order_arc_861  -1
    order_1_14  connected_order_arc_863  -1
    order_1_14  connected_order_arc_865  -1
    order_1_14  connected_order_arc_867  -1
    order_1_14  connected_order_arc_869  -1
    order_1_14  connected_order_arc_871  -1
    order_1_14  connected_order_arc_873  -1
    order_1_14  connected_order_arc_875  -1
    order_1_14  connected_order_arc_877  -1
    order_1_14  connected_order_arc_879  -1
    order_1_14  connected_order_arc_892  1
    order_1_14  connected_order_arc_913  1
    order_1_14  connected_order_arc_934  1
    order_1_14  connected_order_arc_955  1
    order_1_14  connected_order_arc_976  1
    order_1_14  order_active_lb_1022  1
    order_1_14  order_active_ub_1023  1
    visit_1_15  out_degree_1026  -1
    visit_1_15  in_degree_1027  -1
    visit_1_15  order_active_lb_1028  -1
    visit_1_15  order_active_ub_1029  -11
    visit_1_15  service_visit_def_1030  -1
    order_1_15  connected_order_arc_766  1
    order_1_15  connected_order_arc_787  1
    order_1_15  connected_order_arc_808  1
    order_1_15  connected_order_arc_829  1
    order_1_15  connected_order_arc_850  1
    order_1_15  connected_order_arc_871  1
    order_1_15  connected_order_arc_882  -1
    order_1_15  connected_order_arc_884  -1
    order_1_15  connected_order_arc_886  -1
    order_1_15  connected_order_arc_888  -1
    order_1_15  connected_order_arc_890  -1
    order_1_15  connected_order_arc_892  -1
    order_1_15  connected_order_arc_894  -1
    order_1_15  connected_order_arc_896  -1
    order_1_15  connected_order_arc_898  -1
    order_1_15  connected_order_arc_900  -1
    order_1_15  connected_order_arc_915  1
    order_1_15  connected_order_arc_936  1
    order_1_15  connected_order_arc_957  1
    order_1_15  connected_order_arc_978  1
    order_1_15  order_active_lb_1028  1
    order_1_15  order_active_ub_1029  1
    visit_1_16  out_degree_1032  -1
    visit_1_16  in_degree_1033  -1
    visit_1_16  order_active_lb_1034  -1
    visit_1_16  order_active_ub_1035  -11
    visit_1_16  service_visit_def_1036  -1
    order_1_16  connected_order_arc_768  1
    order_1_16  connected_order_arc_789  1
    order_1_16  connected_order_arc_810  1
    order_1_16  connected_order_arc_831  1
    order_1_16  connected_order_arc_852  1
    order_1_16  connected_order_arc_873  1
    order_1_16  connected_order_arc_894  1
    order_1_16  connected_order_arc_903  -1
    order_1_16  connected_order_arc_905  -1
    order_1_16  connected_order_arc_907  -1
    order_1_16  connected_order_arc_909  -1
    order_1_16  connected_order_arc_911  -1
    order_1_16  connected_order_arc_913  -1
    order_1_16  connected_order_arc_915  -1
    order_1_16  connected_order_arc_917  -1
    order_1_16  connected_order_arc_919  -1
    order_1_16  connected_order_arc_921  -1
    order_1_16  connected_order_arc_938  1
    order_1_16  connected_order_arc_959  1
    order_1_16  connected_order_arc_980  1
    order_1_16  order_active_lb_1034  1
    order_1_16  order_active_ub_1035  1
    visit_1_17  out_degree_1038  -1
    visit_1_17  in_degree_1039  -1
    visit_1_17  order_active_lb_1040  -1
    visit_1_17  order_active_ub_1041  -11
    visit_1_17  service_visit_def_1042  -1
    order_1_17  connected_order_arc_770  1
    order_1_17  connected_order_arc_791  1
    order_1_17  connected_order_arc_812  1
    order_1_17  connected_order_arc_833  1
    order_1_17  connected_order_arc_854  1
    order_1_17  connected_order_arc_875  1
    order_1_17  connected_order_arc_896  1
    order_1_17  connected_order_arc_917  1
    order_1_17  connected_order_arc_924  -1
    order_1_17  connected_order_arc_926  -1
    order_1_17  connected_order_arc_928  -1
    order_1_17  connected_order_arc_930  -1
    order_1_17  connected_order_arc_932  -1
    order_1_17  connected_order_arc_934  -1
    order_1_17  connected_order_arc_936  -1
    order_1_17  connected_order_arc_938  -1
    order_1_17  connected_order_arc_940  -1
    order_1_17  connected_order_arc_942  -1
    order_1_17  connected_order_arc_961  1
    order_1_17  connected_order_arc_982  1
    order_1_17  order_active_lb_1040  1
    order_1_17  order_active_ub_1041  1
    visit_1_18  out_degree_1044  -1
    visit_1_18  in_degree_1045  -1
    visit_1_18  order_active_lb_1046  -1
    visit_1_18  order_active_ub_1047  -11
    visit_1_18  service_visit_def_1048  -1
    order_1_18  connected_order_arc_772  1
    order_1_18  connected_order_arc_793  1
    order_1_18  connected_order_arc_814  1
    order_1_18  connected_order_arc_835  1
    order_1_18  connected_order_arc_856  1
    order_1_18  connected_order_arc_877  1
    order_1_18  connected_order_arc_898  1
    order_1_18  connected_order_arc_919  1
    order_1_18  connected_order_arc_940  1
    order_1_18  connected_order_arc_945  -1
    order_1_18  connected_order_arc_947  -1
    order_1_18  connected_order_arc_949  -1
    order_1_18  connected_order_arc_951  -1
    order_1_18  connected_order_arc_953  -1
    order_1_18  connected_order_arc_955  -1
    order_1_18  connected_order_arc_957  -1
    order_1_18  connected_order_arc_959  -1
    order_1_18  connected_order_arc_961  -1
    order_1_18  connected_order_arc_963  -1
    order_1_18  connected_order_arc_984  1
    order_1_18  order_active_lb_1046  1
    order_1_18  order_active_ub_1047  1
    visit_1_19  out_degree_1050  -1
    visit_1_19  in_degree_1051  -1
    visit_1_19  order_active_lb_1052  -1
    visit_1_19  order_active_ub_1053  -11
    visit_1_19  service_visit_def_1054  -1
    order_1_19  connected_order_arc_774  1
    order_1_19  connected_order_arc_795  1
    order_1_19  connected_order_arc_816  1
    order_1_19  connected_order_arc_837  1
    order_1_19  connected_order_arc_858  1
    order_1_19  connected_order_arc_879  1
    order_1_19  connected_order_arc_900  1
    order_1_19  connected_order_arc_921  1
    order_1_19  connected_order_arc_942  1
    order_1_19  connected_order_arc_963  1
    order_1_19  connected_order_arc_966  -1
    order_1_19  connected_order_arc_968  -1
    order_1_19  connected_order_arc_970  -1
    order_1_19  connected_order_arc_972  -1
    order_1_19  connected_order_arc_974  -1
    order_1_19  connected_order_arc_976  -1
    order_1_19  connected_order_arc_978  -1
    order_1_19  connected_order_arc_980  -1
    order_1_19  connected_order_arc_982  -1
    order_1_19  connected_order_arc_984  -1
    order_1_19  order_active_lb_1052  1
    order_1_19  order_active_ub_1053  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_0  arc_capacity_742  -25
    arc_1_0_0  depot_departure_or_bypass_985  1
    arc_1_0_0  depot_return_or_bypass_986  1
    MARKER    'MARKER'                 'INTEND'
    load_1_0_0  arc_capacity_742  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_5  arc_capacity_743  -25
    arc_1_0_5  depot_departure_or_bypass_985  1
    arc_1_0_5  in_degree_988  1
    arc_1_0_5  original_T_including_depot_unload_1058  7.2047755761928431e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_5  arc_capacity_743  1
    load_1_0_5  segment_load_conservation_991  -1
    load_1_0_5  segment_prefix_lb_992  1
    load_1_0_5  segment_prefix_ub_993  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_6  arc_capacity_744  -25
    arc_1_0_6  depot_departure_or_bypass_985  1
    arc_1_0_6  in_degree_995  1
    arc_1_0_6  original_T_including_depot_unload_1058  1.4834116102542102e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_6  arc_capacity_744  1
    load_1_0_6  segment_load_conservation_998  -1
    load_1_0_6  segment_prefix_lb_999  1
    load_1_0_6  segment_prefix_ub_1000  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_7  arc_capacity_745  -25
    arc_1_0_7  depot_departure_or_bypass_985  1
    arc_1_0_7  in_degree_1002  1
    arc_1_0_7  original_T_including_depot_unload_1058  5.4911852608328161e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_7  arc_capacity_745  1
    load_1_0_7  segment_load_conservation_1005  -1
    load_1_0_7  segment_prefix_lb_1006  1
    load_1_0_7  segment_prefix_ub_1007  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_12  arc_capacity_746  -25
    arc_1_0_12  depot_departure_or_bypass_985  1
    arc_1_0_12  in_degree_1009  1
    arc_1_0_12  original_T_including_depot_unload_1058  1.1935953747864173e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_12  arc_capacity_746  1
    load_1_0_12  free_load_conservation_1013  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_13  arc_capacity_747  -25
    arc_1_0_13  depot_departure_or_bypass_985  1
    arc_1_0_13  in_degree_1015  1
    arc_1_0_13  original_T_including_depot_unload_1058  1.6602888921784454e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_13  arc_capacity_747  1
    load_1_0_13  free_load_conservation_1019  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_14  arc_capacity_748  -25
    arc_1_0_14  depot_departure_or_bypass_985  1
    arc_1_0_14  in_degree_1021  1
    arc_1_0_14  original_T_including_depot_unload_1058  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_14  arc_capacity_748  1
    load_1_0_14  free_load_conservation_1025  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_15  arc_capacity_749  -25
    arc_1_0_15  depot_departure_or_bypass_985  1
    arc_1_0_15  in_degree_1027  1
    arc_1_0_15  original_T_including_depot_unload_1058  1.0056399980521732e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_15  arc_capacity_749  1
    load_1_0_15  free_load_conservation_1031  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_16  arc_capacity_750  -25
    arc_1_0_16  depot_departure_or_bypass_985  1
    arc_1_0_16  in_degree_1033  1
    arc_1_0_16  original_T_including_depot_unload_1058  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_16  arc_capacity_750  1
    load_1_0_16  free_load_conservation_1037  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_17  arc_capacity_751  -25
    arc_1_0_17  depot_departure_or_bypass_985  1
    arc_1_0_17  in_degree_1039  1
    arc_1_0_17  original_T_including_depot_unload_1058  3.5061909388980052e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_17  arc_capacity_751  1
    load_1_0_17  free_load_conservation_1043  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_18  arc_capacity_752  -25
    arc_1_0_18  depot_departure_or_bypass_985  1
    arc_1_0_18  in_degree_1045  1
    arc_1_0_18  original_T_including_depot_unload_1058  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_18  arc_capacity_752  1
    load_1_0_18  free_load_conservation_1049  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_19  arc_capacity_753  -25
    arc_1_0_19  depot_departure_or_bypass_985  1
    arc_1_0_19  in_degree_1051  1
    arc_1_0_19  original_T_including_depot_unload_1058  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_19  arc_capacity_753  1
    load_1_0_19  free_load_conservation_1055  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_0  arc_capacity_754  -25
    arc_1_5_0  depot_return_or_bypass_986  1
    arc_1_5_0  out_degree_987  1
    arc_1_5_0  original_T_including_depot_unload_1058  7.2047755761928431e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_5_0  arc_capacity_754  1
    load_1_5_0  segment_load_conservation_991  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_6  arc_capacity_755  -25
    arc_1_5_6  connected_order_arc_756  -12
    arc_1_5_6  out_degree_987  1
    arc_1_5_6  in_degree_995  1
    arc_1_5_6  original_T_including_depot_unload_1058  1.0359917537364215e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_6  arc_capacity_755  1
    load_1_5_6  segment_load_conservation_991  1
    load_1_5_6  segment_load_conservation_998  -1
    load_1_5_6  segment_prefix_lb_999  1
    load_1_5_6  segment_prefix_ub_1000  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_7  arc_capacity_757  -25
    arc_1_5_7  connected_order_arc_758  -12
    arc_1_5_7  out_degree_987  1
    arc_1_5_7  in_degree_1002  1
    arc_1_5_7  original_T_including_depot_unload_1058  2.9662284735332634e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_5_7  arc_capacity_757  1
    load_1_5_7  segment_load_conservation_991  1
    load_1_5_7  segment_load_conservation_1005  -1
    load_1_5_7  segment_prefix_lb_1006  1
    load_1_5_7  segment_prefix_ub_1007  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_12  arc_capacity_759  -25
    arc_1_5_12  connected_order_arc_760  -12
    arc_1_5_12  out_degree_987  1
    arc_1_5_12  in_degree_1009  1
    arc_1_5_12  original_T_including_depot_unload_1058  1.0819844298451576e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_12  arc_capacity_759  1
    load_1_5_12  segment_load_conservation_991  1
    load_1_5_12  free_load_conservation_1013  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_13  arc_capacity_761  -25
    arc_1_5_13  connected_order_arc_762  -12
    arc_1_5_13  out_degree_987  1
    arc_1_5_13  in_degree_1015  1
    arc_1_5_13  original_T_including_depot_unload_1058  1.8021002410302701e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_13  arc_capacity_761  1
    load_1_5_13  segment_load_conservation_991  1
    load_1_5_13  free_load_conservation_1019  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_14  arc_capacity_763  -25
    arc_1_5_14  connected_order_arc_764  -12
    arc_1_5_14  out_degree_987  1
    arc_1_5_14  in_degree_1021  1
    arc_1_5_14  original_T_including_depot_unload_1058  2.2682175936128497e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_14  arc_capacity_763  1
    load_1_5_14  segment_load_conservation_991  1
    load_1_5_14  free_load_conservation_1025  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_15  arc_capacity_765  -25
    arc_1_5_15  connected_order_arc_766  -12
    arc_1_5_15  out_degree_987  1
    arc_1_5_15  in_degree_1027  1
    arc_1_5_15  original_T_including_depot_unload_1058  1.4636929855741182e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_15  arc_capacity_765  1
    load_1_5_15  segment_load_conservation_991  1
    load_1_5_15  free_load_conservation_1031  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_16  arc_capacity_767  -25
    arc_1_5_16  connected_order_arc_768  -12
    arc_1_5_16  out_degree_987  1
    arc_1_5_16  in_degree_1033  1
    arc_1_5_16  original_T_including_depot_unload_1058  1.4653145381016172e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_16  arc_capacity_767  1
    load_1_5_16  segment_load_conservation_991  1
    load_1_5_16  free_load_conservation_1037  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_17  arc_capacity_769  -25
    arc_1_5_17  connected_order_arc_770  -12
    arc_1_5_17  out_degree_987  1
    arc_1_5_17  in_degree_1039  1
    arc_1_5_17  original_T_including_depot_unload_1058  3.7747736142736670e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_5_17  arc_capacity_769  1
    load_1_5_17  segment_load_conservation_991  1
    load_1_5_17  free_load_conservation_1043  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_18  arc_capacity_771  -25
    arc_1_5_18  connected_order_arc_772  -12
    arc_1_5_18  out_degree_987  1
    arc_1_5_18  in_degree_1045  1
    arc_1_5_18  original_T_including_depot_unload_1058  1.6437981048195304e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_18  arc_capacity_771  1
    load_1_5_18  segment_load_conservation_991  1
    load_1_5_18  free_load_conservation_1049  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_19  arc_capacity_773  -25
    arc_1_5_19  connected_order_arc_774  -12
    arc_1_5_19  out_degree_987  1
    arc_1_5_19  in_degree_1051  1
    arc_1_5_19  original_T_including_depot_unload_1058  1.0198535056659911e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_19  arc_capacity_773  1
    load_1_5_19  segment_load_conservation_991  1
    load_1_5_19  free_load_conservation_1055  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_0  arc_capacity_775  -25
    arc_1_6_0  depot_return_or_bypass_986  1
    arc_1_6_0  out_degree_994  1
    arc_1_6_0  original_T_including_depot_unload_1058  1.4834116102542102e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_0  arc_capacity_775  1
    load_1_6_0  segment_load_conservation_998  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_5  arc_capacity_776  -25
    arc_1_6_5  connected_order_arc_777  -12
    arc_1_6_5  in_degree_988  1
    arc_1_6_5  out_degree_994  1
    arc_1_6_5  original_T_including_depot_unload_1058  1.0359917537364215e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_5  arc_capacity_776  1
    load_1_6_5  segment_load_conservation_991  -1
    load_1_6_5  segment_prefix_lb_992  1
    load_1_6_5  segment_prefix_ub_993  1
    load_1_6_5  segment_load_conservation_998  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_7  arc_capacity_778  -25
    arc_1_6_7  connected_order_arc_779  -12
    arc_1_6_7  out_degree_994  1
    arc_1_6_7  in_degree_1002  1
    arc_1_6_7  original_T_including_depot_unload_1058  9.7352441264247466e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_7  arc_capacity_778  1
    load_1_6_7  segment_load_conservation_998  1
    load_1_6_7  segment_load_conservation_1005  -1
    load_1_6_7  segment_prefix_lb_1006  1
    load_1_6_7  segment_prefix_ub_1007  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_12  arc_capacity_780  -25
    arc_1_6_12  connected_order_arc_781  -12
    arc_1_6_12  out_degree_994  1
    arc_1_6_12  in_degree_1009  1
    arc_1_6_12  original_T_including_depot_unload_1058  2.1016283653335277e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_12  arc_capacity_780  1
    load_1_6_12  segment_load_conservation_998  1
    load_1_6_12  free_load_conservation_1013  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_13  arc_capacity_782  -25
    arc_1_6_13  connected_order_arc_783  -12
    arc_1_6_13  out_degree_994  1
    arc_1_6_13  in_degree_1015  1
    arc_1_6_13  original_T_including_depot_unload_1058  2.8379597250568327e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_13  arc_capacity_782  1
    load_1_6_13  segment_load_conservation_998  1
    load_1_6_13  free_load_conservation_1019  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_14  arc_capacity_784  -25
    arc_1_6_14  connected_order_arc_785  -12
    arc_1_6_14  out_degree_994  1
    arc_1_6_14  in_degree_1021  1
    arc_1_6_14  original_T_including_depot_unload_1058  2.9790156048453791e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_14  arc_capacity_784  1
    load_1_6_14  segment_load_conservation_998  1
    load_1_6_14  free_load_conservation_1025  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_15  arc_capacity_786  -25
    arc_1_6_15  connected_order_arc_787  -12
    arc_1_6_15  out_degree_994  1
    arc_1_6_15  in_degree_1027  1
    arc_1_6_15  original_T_including_depot_unload_1058  2.4304747035816213e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_15  arc_capacity_786  1
    load_1_6_15  segment_load_conservation_998  1
    load_1_6_15  free_load_conservation_1031  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_16  arc_capacity_788  -25
    arc_1_6_16  connected_order_arc_789  -12
    arc_1_6_16  out_degree_994  1
    arc_1_6_16  in_degree_1033  1
    arc_1_6_16  original_T_including_depot_unload_1058  2.4321008933612479e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_16  arc_capacity_788  1
    load_1_6_16  segment_load_conservation_998  1
    load_1_6_16  free_load_conservation_1037  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_17  arc_capacity_790  -25
    arc_1_6_17  connected_order_arc_791  -12
    arc_1_6_17  out_degree_994  1
    arc_1_6_17  in_degree_1039  1
    arc_1_6_17  original_T_including_depot_unload_1058  1.2769578074048923e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_17  arc_capacity_790  1
    load_1_6_17  segment_load_conservation_998  1
    load_1_6_17  free_load_conservation_1043  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_18  arc_capacity_792  -25
    arc_1_6_18  connected_order_arc_793  -12
    arc_1_6_18  out_degree_994  1
    arc_1_6_18  in_degree_1045  1
    arc_1_6_18  original_T_including_depot_unload_1058  2.3444750474890211e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_18  arc_capacity_792  1
    load_1_6_18  segment_load_conservation_998  1
    load_1_6_18  free_load_conservation_1049  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_19  arc_capacity_794  -25
    arc_1_6_19  connected_order_arc_795  -12
    arc_1_6_19  out_degree_994  1
    arc_1_6_19  in_degree_1051  1
    arc_1_6_19  original_T_including_depot_unload_1058  1.9029099398713563e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_19  arc_capacity_794  1
    load_1_6_19  segment_load_conservation_998  1
    load_1_6_19  free_load_conservation_1055  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_0  arc_capacity_796  -25
    arc_1_7_0  depot_return_or_bypass_986  1
    arc_1_7_0  out_degree_1001  1
    arc_1_7_0  original_T_including_depot_unload_1058  5.4911852608328161e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_0  arc_capacity_796  1
    load_1_7_0  segment_load_conservation_1005  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_5  arc_capacity_797  -25
    arc_1_7_5  connected_order_arc_798  -12
    arc_1_7_5  in_degree_988  1
    arc_1_7_5  out_degree_1001  1
    arc_1_7_5  original_T_including_depot_unload_1058  2.9662284735332634e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_5  arc_capacity_797  1
    load_1_7_5  segment_load_conservation_991  -1
    load_1_7_5  segment_prefix_lb_992  1
    load_1_7_5  segment_prefix_ub_993  1
    load_1_7_5  segment_load_conservation_1005  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_6  arc_capacity_799  -25
    arc_1_7_6  connected_order_arc_800  -12
    arc_1_7_6  in_degree_995  1
    arc_1_7_6  out_degree_1001  1
    arc_1_7_6  original_T_including_depot_unload_1058  9.7352441264247466e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_6  arc_capacity_799  1
    load_1_7_6  segment_load_conservation_998  -1
    load_1_7_6  segment_prefix_lb_999  1
    load_1_7_6  segment_prefix_ub_1000  1
    load_1_7_6  segment_load_conservation_1005  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_12  arc_capacity_801  -25
    arc_1_7_12  connected_order_arc_802  -12
    arc_1_7_12  out_degree_1001  1
    arc_1_7_12  in_degree_1009  1
    arc_1_7_12  original_T_including_depot_unload_1058  1.2739580769060942e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_12  arc_capacity_801  1
    load_1_7_12  segment_load_conservation_1005  1
    load_1_7_12  free_load_conservation_1013  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_13  arc_capacity_803  -25
    arc_1_7_13  connected_order_arc_804  -12
    arc_1_7_13  out_degree_1001  1
    arc_1_7_13  in_degree_1015  1
    arc_1_7_13  original_T_including_depot_unload_1058  1.9305399866194357e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_13  arc_capacity_803  1
    load_1_7_13  segment_load_conservation_1005  1
    load_1_7_13  free_load_conservation_1019  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_14  arc_capacity_805  -25
    arc_1_7_14  connected_order_arc_806  -12
    arc_1_7_14  out_degree_1001  1
    arc_1_7_14  in_degree_1021  1
    arc_1_7_14  original_T_including_depot_unload_1058  2.1109553693139742e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_14  arc_capacity_805  1
    load_1_7_14  segment_load_conservation_1005  1
    load_1_7_14  free_load_conservation_1025  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_15  arc_capacity_807  -25
    arc_1_7_15  connected_order_arc_808  -12
    arc_1_7_15  out_degree_1001  1
    arc_1_7_15  in_degree_1027  1
    arc_1_7_15  original_T_including_depot_unload_1058  1.4570094449922669e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_15  arc_capacity_807  1
    load_1_7_15  segment_load_conservation_1005  1
    load_1_7_15  free_load_conservation_1031  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_16  arc_capacity_809  -25
    arc_1_7_16  connected_order_arc_810  -12
    arc_1_7_16  out_degree_1001  1
    arc_1_7_16  in_degree_1033  1
    arc_1_7_16  original_T_including_depot_unload_1058  1.4586348268927468e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_16  arc_capacity_809  1
    load_1_7_16  segment_load_conservation_1005  1
    load_1_7_16  free_load_conservation_1037  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_17  arc_capacity_811  -25
    arc_1_7_17  connected_order_arc_812  -12
    arc_1_7_17  out_degree_1001  1
    arc_1_7_17  in_degree_1039  1
    arc_1_7_17  original_T_including_depot_unload_1058  3.0614301781508658e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_17  arc_capacity_811  1
    load_1_7_17  segment_load_conservation_1005  1
    load_1_7_17  free_load_conservation_1043  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_18  arc_capacity_813  -25
    arc_1_7_18  connected_order_arc_814  -12
    arc_1_7_18  out_degree_1001  1
    arc_1_7_18  in_degree_1045  1
    arc_1_7_18  original_T_including_depot_unload_1058  1.4738339199468992e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_18  arc_capacity_813  1
    load_1_7_18  segment_load_conservation_1005  1
    load_1_7_18  free_load_conservation_1049  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_19  arc_capacity_815  -25
    arc_1_7_19  connected_order_arc_816  -12
    arc_1_7_19  out_degree_1001  1
    arc_1_7_19  in_degree_1051  1
    arc_1_7_19  original_T_including_depot_unload_1058  9.3836915476275669e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_19  arc_capacity_815  1
    load_1_7_19  segment_load_conservation_1005  1
    load_1_7_19  free_load_conservation_1055  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_0  arc_capacity_817  -25
    arc_1_12_0  depot_return_or_bypass_986  1
    arc_1_12_0  out_degree_1008  1
    arc_1_12_0  original_T_including_depot_unload_1058  1.1935953747864173e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_0  arc_capacity_817  1
    load_1_12_0  free_load_conservation_1013  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_5  arc_capacity_818  -25
    arc_1_12_5  connected_order_arc_819  -12
    arc_1_12_5  in_degree_988  1
    arc_1_12_5  out_degree_1008  1
    arc_1_12_5  original_T_including_depot_unload_1058  1.0819844298451576e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_5  arc_capacity_818  1
    load_1_12_5  segment_load_conservation_991  -1
    load_1_12_5  segment_prefix_lb_992  1
    load_1_12_5  segment_prefix_ub_993  1
    load_1_12_5  free_load_conservation_1013  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_6  arc_capacity_820  -25
    arc_1_12_6  connected_order_arc_821  -12
    arc_1_12_6  in_degree_995  1
    arc_1_12_6  out_degree_1008  1
    arc_1_12_6  original_T_including_depot_unload_1058  2.1016283653335277e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_6  arc_capacity_820  1
    load_1_12_6  segment_load_conservation_998  -1
    load_1_12_6  segment_prefix_lb_999  1
    load_1_12_6  segment_prefix_ub_1000  1
    load_1_12_6  free_load_conservation_1013  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_7  arc_capacity_822  -25
    arc_1_12_7  connected_order_arc_823  -12
    arc_1_12_7  in_degree_1002  1
    arc_1_12_7  out_degree_1008  1
    arc_1_12_7  original_T_including_depot_unload_1058  1.2739580769060942e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_7  arc_capacity_822  1
    load_1_12_7  segment_load_conservation_1005  -1
    load_1_12_7  segment_prefix_lb_1006  1
    load_1_12_7  segment_prefix_ub_1007  1
    load_1_12_7  free_load_conservation_1013  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_13  arc_capacity_824  -25
    arc_1_12_13  connected_order_arc_825  -12
    arc_1_12_13  out_degree_1008  1
    arc_1_12_13  in_degree_1015  1
    arc_1_12_13  original_T_including_depot_unload_1058  7.8744552571478073e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_13  arc_capacity_824  1
    load_1_12_13  free_load_conservation_1013  1
    load_1_12_13  free_load_conservation_1019  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_14  arc_capacity_826  -25
    arc_1_12_14  connected_order_arc_827  -12
    arc_1_12_14  out_degree_1008  1
    arc_1_12_14  in_degree_1021  1
    arc_1_12_14  original_T_including_depot_unload_1058  2.1501600514850211e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_14  arc_capacity_826  1
    load_1_12_14  free_load_conservation_1013  1
    load_1_12_14  free_load_conservation_1025  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_15  arc_capacity_828  -25
    arc_1_12_15  connected_order_arc_829  -12
    arc_1_12_15  out_degree_1008  1
    arc_1_12_15  in_degree_1027  1
    arc_1_12_15  original_T_including_depot_unload_1058  9.7357850164388731e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_15  arc_capacity_828  1
    load_1_12_15  free_load_conservation_1013  1
    load_1_12_15  free_load_conservation_1031  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_16  arc_capacity_830  -25
    arc_1_12_16  connected_order_arc_831  -12
    arc_1_12_16  out_degree_1008  1
    arc_1_12_16  in_degree_1033  1
    arc_1_12_16  original_T_including_depot_unload_1058  9.7453518552189382e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_16  arc_capacity_830  1
    load_1_12_16  free_load_conservation_1013  1
    load_1_12_16  free_load_conservation_1037  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_17  arc_capacity_832  -25
    arc_1_12_17  connected_order_arc_833  -12
    arc_1_12_17  out_degree_1008  1
    arc_1_12_17  in_degree_1039  1
    arc_1_12_17  original_T_including_depot_unload_1058  1.0313568965059917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_17  arc_capacity_832  1
    load_1_12_17  free_load_conservation_1013  1
    load_1_12_17  free_load_conservation_1043  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_18  arc_capacity_834  -25
    arc_1_12_18  connected_order_arc_835  -12
    arc_1_12_18  out_degree_1008  1
    arc_1_12_18  in_degree_1045  1
    arc_1_12_18  original_T_including_depot_unload_1058  1.6988291947636669e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_18  arc_capacity_834  1
    load_1_12_18  free_load_conservation_1013  1
    load_1_12_18  free_load_conservation_1049  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_19  arc_capacity_836  -25
    arc_1_12_19  connected_order_arc_837  -12
    arc_1_12_19  out_degree_1008  1
    arc_1_12_19  in_degree_1051  1
    arc_1_12_19  original_T_including_depot_unload_1058  1.0321140782598593e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_19  arc_capacity_836  1
    load_1_12_19  free_load_conservation_1013  1
    load_1_12_19  free_load_conservation_1055  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_0  arc_capacity_838  -25
    arc_1_13_0  depot_return_or_bypass_986  1
    arc_1_13_0  out_degree_1014  1
    arc_1_13_0  original_T_including_depot_unload_1058  1.6602888921784454e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_0  arc_capacity_838  1
    load_1_13_0  free_load_conservation_1019  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_5  arc_capacity_839  -25
    arc_1_13_5  connected_order_arc_840  -12
    arc_1_13_5  in_degree_988  1
    arc_1_13_5  out_degree_1014  1
    arc_1_13_5  original_T_including_depot_unload_1058  1.8021002410302701e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_5  arc_capacity_839  1
    load_1_13_5  segment_load_conservation_991  -1
    load_1_13_5  segment_prefix_lb_992  1
    load_1_13_5  segment_prefix_ub_993  1
    load_1_13_5  free_load_conservation_1019  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_6  arc_capacity_841  -25
    arc_1_13_6  connected_order_arc_842  -12
    arc_1_13_6  in_degree_995  1
    arc_1_13_6  out_degree_1014  1
    arc_1_13_6  original_T_including_depot_unload_1058  2.8379597250568327e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_6  arc_capacity_841  1
    load_1_13_6  segment_load_conservation_998  -1
    load_1_13_6  segment_prefix_lb_999  1
    load_1_13_6  segment_prefix_ub_1000  1
    load_1_13_6  free_load_conservation_1019  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_7  arc_capacity_843  -25
    arc_1_13_7  connected_order_arc_844  -12
    arc_1_13_7  in_degree_1002  1
    arc_1_13_7  out_degree_1014  1
    arc_1_13_7  original_T_including_depot_unload_1058  1.9305399866194357e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_7  arc_capacity_843  1
    load_1_13_7  segment_load_conservation_1005  -1
    load_1_13_7  segment_prefix_lb_1006  1
    load_1_13_7  segment_prefix_ub_1007  1
    load_1_13_7  free_load_conservation_1019  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_12  arc_capacity_845  -25
    arc_1_13_12  connected_order_arc_846  -12
    arc_1_13_12  in_degree_1009  1
    arc_1_13_12  out_degree_1014  1
    arc_1_13_12  original_T_including_depot_unload_1058  7.8744552571478073e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_12  arc_capacity_845  1
    load_1_13_12  free_load_conservation_1013  -1
    load_1_13_12  free_load_conservation_1019  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_14  arc_capacity_847  -25
    arc_1_13_14  connected_order_arc_848  -12
    arc_1_13_14  out_degree_1014  1
    arc_1_13_14  in_degree_1021  1
    arc_1_13_14  original_T_including_depot_unload_1058  1.9767828664634856e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_14  arc_capacity_847  1
    load_1_13_14  free_load_conservation_1019  1
    load_1_13_14  free_load_conservation_1025  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_15  arc_capacity_849  -25
    arc_1_13_15  connected_order_arc_850  -12
    arc_1_13_15  out_degree_1014  1
    arc_1_13_15  in_degree_1027  1
    arc_1_13_15  original_T_including_depot_unload_1058  8.7049015369085737e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_15  arc_capacity_849  1
    load_1_13_15  free_load_conservation_1019  1
    load_1_13_15  free_load_conservation_1031  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_16  arc_capacity_851  -25
    arc_1_13_16  connected_order_arc_852  -12
    arc_1_13_16  out_degree_1014  1
    arc_1_13_16  in_degree_1033  1
    arc_1_13_16  original_T_including_depot_unload_1058  8.7008776944597639e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_16  arc_capacity_851  1
    load_1_13_16  free_load_conservation_1019  1
    load_1_13_16  free_load_conservation_1037  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_17  arc_capacity_853  -25
    arc_1_13_17  connected_order_arc_854  -12
    arc_1_13_17  out_degree_1014  1
    arc_1_13_17  in_degree_1039  1
    arc_1_13_17  original_T_including_depot_unload_1058  1.6406378986588031e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_17  arc_capacity_853  1
    load_1_13_17  free_load_conservation_1019  1
    load_1_13_17  free_load_conservation_1043  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_18  arc_capacity_855  -25
    arc_1_13_18  connected_order_arc_856  -12
    arc_1_13_18  out_degree_1014  1
    arc_1_13_18  in_degree_1045  1
    arc_1_13_18  original_T_including_depot_unload_1058  1.7489191280566063e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_18  arc_capacity_855  1
    load_1_13_18  free_load_conservation_1019  1
    load_1_13_18  free_load_conservation_1049  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_19  arc_capacity_857  -25
    arc_1_13_19  connected_order_arc_858  -12
    arc_1_13_19  out_degree_1014  1
    arc_1_13_19  in_degree_1051  1
    arc_1_13_19  original_T_including_depot_unload_1058  1.3104307696104611e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_19  arc_capacity_857  1
    load_1_13_19  free_load_conservation_1019  1
    load_1_13_19  free_load_conservation_1055  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_0  arc_capacity_859  -25
    arc_1_14_0  depot_return_or_bypass_986  1
    arc_1_14_0  out_degree_1020  1
    arc_1_14_0  original_T_including_depot_unload_1058  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_0  arc_capacity_859  1
    load_1_14_0  free_load_conservation_1025  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_5  arc_capacity_860  -25
    arc_1_14_5  connected_order_arc_861  -12
    arc_1_14_5  in_degree_988  1
    arc_1_14_5  out_degree_1020  1
    arc_1_14_5  original_T_including_depot_unload_1058  2.2682175936128497e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_5  arc_capacity_860  1
    load_1_14_5  segment_load_conservation_991  -1
    load_1_14_5  segment_prefix_lb_992  1
    load_1_14_5  segment_prefix_ub_993  1
    load_1_14_5  free_load_conservation_1025  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_6  arc_capacity_862  -25
    arc_1_14_6  connected_order_arc_863  -12
    arc_1_14_6  in_degree_995  1
    arc_1_14_6  out_degree_1020  1
    arc_1_14_6  original_T_including_depot_unload_1058  2.9790156048453791e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_6  arc_capacity_862  1
    load_1_14_6  segment_load_conservation_998  -1
    load_1_14_6  segment_prefix_lb_999  1
    load_1_14_6  segment_prefix_ub_1000  1
    load_1_14_6  free_load_conservation_1025  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_7  arc_capacity_864  -25
    arc_1_14_7  connected_order_arc_865  -12
    arc_1_14_7  in_degree_1002  1
    arc_1_14_7  out_degree_1020  1
    arc_1_14_7  original_T_including_depot_unload_1058  2.1109553693139742e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_7  arc_capacity_864  1
    load_1_14_7  segment_load_conservation_1005  -1
    load_1_14_7  segment_prefix_lb_1006  1
    load_1_14_7  segment_prefix_ub_1007  1
    load_1_14_7  free_load_conservation_1025  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_12  arc_capacity_866  -25
    arc_1_14_12  connected_order_arc_867  -12
    arc_1_14_12  in_degree_1009  1
    arc_1_14_12  out_degree_1020  1
    arc_1_14_12  original_T_including_depot_unload_1058  2.1501600514850211e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_12  arc_capacity_866  1
    load_1_14_12  free_load_conservation_1013  -1
    load_1_14_12  free_load_conservation_1025  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_13  arc_capacity_868  -25
    arc_1_14_13  connected_order_arc_869  -12
    arc_1_14_13  in_degree_1015  1
    arc_1_14_13  out_degree_1020  1
    arc_1_14_13  original_T_including_depot_unload_1058  1.9767828664634856e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_13  arc_capacity_868  1
    load_1_14_13  free_load_conservation_1019  -1
    load_1_14_13  free_load_conservation_1025  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_15  arc_capacity_870  -25
    arc_1_14_15  connected_order_arc_871  -12
    arc_1_14_15  out_degree_1020  1
    arc_1_14_15  in_degree_1027  1
    arc_1_14_15  original_T_including_depot_unload_1058  1.1967280409234234e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_15  arc_capacity_870  1
    load_1_14_15  free_load_conservation_1025  1
    load_1_14_15  free_load_conservation_1031  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_16  arc_capacity_872  -25
    arc_1_14_16  connected_order_arc_873  -12
    arc_1_14_16  out_degree_1020  1
    arc_1_14_16  in_degree_1033  1
    arc_1_14_16  original_T_including_depot_unload_1058  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_16  arc_capacity_872  1
    load_1_14_16  free_load_conservation_1025  1
    load_1_14_16  free_load_conservation_1037  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_17  arc_capacity_874  -25
    arc_1_14_17  connected_order_arc_875  -12
    arc_1_14_17  out_degree_1020  1
    arc_1_14_17  in_degree_1039  1
    arc_1_14_17  original_T_including_depot_unload_1058  1.8911324761641883e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_17  arc_capacity_874  1
    load_1_14_17  free_load_conservation_1025  1
    load_1_14_17  free_load_conservation_1043  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_18  arc_capacity_876  -25
    arc_1_14_18  connected_order_arc_877  -12
    arc_1_14_18  out_degree_1020  1
    arc_1_14_18  in_degree_1045  1
    arc_1_14_18  original_T_including_depot_unload_1058  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_1_14_18  arc_capacity_876  1
    load_1_14_18  free_load_conservation_1025  1
    load_1_14_18  free_load_conservation_1049  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_19  arc_capacity_878  -25
    arc_1_14_19  connected_order_arc_879  -12
    arc_1_14_19  out_degree_1020  1
    arc_1_14_19  in_degree_1051  1
    arc_1_14_19  original_T_including_depot_unload_1058  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_19  arc_capacity_878  1
    load_1_14_19  free_load_conservation_1025  1
    load_1_14_19  free_load_conservation_1055  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_0  arc_capacity_880  -25
    arc_1_15_0  depot_return_or_bypass_986  1
    arc_1_15_0  out_degree_1026  1
    arc_1_15_0  original_T_including_depot_unload_1058  1.0056399980521732e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_0  arc_capacity_880  1
    load_1_15_0  free_load_conservation_1031  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_5  arc_capacity_881  -25
    arc_1_15_5  connected_order_arc_882  -12
    arc_1_15_5  in_degree_988  1
    arc_1_15_5  out_degree_1026  1
    arc_1_15_5  original_T_including_depot_unload_1058  1.4636929855741182e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_5  arc_capacity_881  1
    load_1_15_5  segment_load_conservation_991  -1
    load_1_15_5  segment_prefix_lb_992  1
    load_1_15_5  segment_prefix_ub_993  1
    load_1_15_5  free_load_conservation_1031  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_6  arc_capacity_883  -25
    arc_1_15_6  connected_order_arc_884  -12
    arc_1_15_6  in_degree_995  1
    arc_1_15_6  out_degree_1026  1
    arc_1_15_6  original_T_including_depot_unload_1058  2.4304747035816213e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_6  arc_capacity_883  1
    load_1_15_6  segment_load_conservation_998  -1
    load_1_15_6  segment_prefix_lb_999  1
    load_1_15_6  segment_prefix_ub_1000  1
    load_1_15_6  free_load_conservation_1031  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_7  arc_capacity_885  -25
    arc_1_15_7  connected_order_arc_886  -12
    arc_1_15_7  in_degree_1002  1
    arc_1_15_7  out_degree_1026  1
    arc_1_15_7  original_T_including_depot_unload_1058  1.4570094449922669e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_7  arc_capacity_885  1
    load_1_15_7  segment_load_conservation_1005  -1
    load_1_15_7  segment_prefix_lb_1006  1
    load_1_15_7  segment_prefix_ub_1007  1
    load_1_15_7  free_load_conservation_1031  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_12  arc_capacity_887  -25
    arc_1_15_12  connected_order_arc_888  -12
    arc_1_15_12  in_degree_1009  1
    arc_1_15_12  out_degree_1026  1
    arc_1_15_12  original_T_including_depot_unload_1058  9.7357850164388731e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_12  arc_capacity_887  1
    load_1_15_12  free_load_conservation_1013  -1
    load_1_15_12  free_load_conservation_1031  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_13  arc_capacity_889  -25
    arc_1_15_13  connected_order_arc_890  -12
    arc_1_15_13  in_degree_1015  1
    arc_1_15_13  out_degree_1026  1
    arc_1_15_13  original_T_including_depot_unload_1058  8.7049015369085737e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_13  arc_capacity_889  1
    load_1_15_13  free_load_conservation_1019  -1
    load_1_15_13  free_load_conservation_1031  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_14  arc_capacity_891  -25
    arc_1_15_14  connected_order_arc_892  -12
    arc_1_15_14  in_degree_1021  1
    arc_1_15_14  out_degree_1026  1
    arc_1_15_14  original_T_including_depot_unload_1058  1.1967280409234234e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_14  arc_capacity_891  1
    load_1_15_14  free_load_conservation_1025  -1
    load_1_15_14  free_load_conservation_1031  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_16  arc_capacity_893  -25
    arc_1_15_16  connected_order_arc_894  -12
    arc_1_15_16  out_degree_1026  1
    arc_1_15_16  in_degree_1033  1
    arc_1_15_16  original_T_including_depot_unload_1058  1.6320002720932780e+00
    MARKER    'MARKER'                 'INTEND'
    load_1_15_16  arc_capacity_893  1
    load_1_15_16  free_load_conservation_1031  1
    load_1_15_16  free_load_conservation_1037  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_17  arc_capacity_895  -25
    arc_1_15_17  connected_order_arc_896  -12
    arc_1_15_17  out_degree_1026  1
    arc_1_15_17  in_degree_1039  1
    arc_1_15_17  original_T_including_depot_unload_1058  1.1545648513745866e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_17  arc_capacity_895  1
    load_1_15_17  free_load_conservation_1031  1
    load_1_15_17  free_load_conservation_1043  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_18  arc_capacity_897  -25
    arc_1_15_18  connected_order_arc_898  -12
    arc_1_15_18  out_degree_1026  1
    arc_1_15_18  in_degree_1045  1
    arc_1_15_18  original_T_including_depot_unload_1058  8.7906342149593650e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_18  arc_capacity_897  1
    load_1_15_18  free_load_conservation_1031  1
    load_1_15_18  free_load_conservation_1049  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_19  arc_capacity_899  -25
    arc_1_15_19  connected_order_arc_900  -12
    arc_1_15_19  out_degree_1026  1
    arc_1_15_19  in_degree_1051  1
    arc_1_15_19  original_T_including_depot_unload_1058  5.7276146581216926e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_19  arc_capacity_899  1
    load_1_15_19  free_load_conservation_1031  1
    load_1_15_19  free_load_conservation_1055  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_0  arc_capacity_901  -25
    arc_1_16_0  depot_return_or_bypass_986  1
    arc_1_16_0  out_degree_1032  1
    arc_1_16_0  original_T_including_depot_unload_1058  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_0  arc_capacity_901  1
    load_1_16_0  free_load_conservation_1037  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_5  arc_capacity_902  -25
    arc_1_16_5  connected_order_arc_903  -12
    arc_1_16_5  in_degree_988  1
    arc_1_16_5  out_degree_1032  1
    arc_1_16_5  original_T_including_depot_unload_1058  1.4653145381016172e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_5  arc_capacity_902  1
    load_1_16_5  segment_load_conservation_991  -1
    load_1_16_5  segment_prefix_lb_992  1
    load_1_16_5  segment_prefix_ub_993  1
    load_1_16_5  free_load_conservation_1037  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_6  arc_capacity_904  -25
    arc_1_16_6  connected_order_arc_905  -12
    arc_1_16_6  in_degree_995  1
    arc_1_16_6  out_degree_1032  1
    arc_1_16_6  original_T_including_depot_unload_1058  2.4321008933612479e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_6  arc_capacity_904  1
    load_1_16_6  segment_load_conservation_998  -1
    load_1_16_6  segment_prefix_lb_999  1
    load_1_16_6  segment_prefix_ub_1000  1
    load_1_16_6  free_load_conservation_1037  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_7  arc_capacity_906  -25
    arc_1_16_7  connected_order_arc_907  -12
    arc_1_16_7  in_degree_1002  1
    arc_1_16_7  out_degree_1032  1
    arc_1_16_7  original_T_including_depot_unload_1058  1.4586348268927468e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_7  arc_capacity_906  1
    load_1_16_7  segment_load_conservation_1005  -1
    load_1_16_7  segment_prefix_lb_1006  1
    load_1_16_7  segment_prefix_ub_1007  1
    load_1_16_7  free_load_conservation_1037  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_12  arc_capacity_908  -25
    arc_1_16_12  connected_order_arc_909  -12
    arc_1_16_12  in_degree_1009  1
    arc_1_16_12  out_degree_1032  1
    arc_1_16_12  original_T_including_depot_unload_1058  9.7453518552189382e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_12  arc_capacity_908  1
    load_1_16_12  free_load_conservation_1013  -1
    load_1_16_12  free_load_conservation_1037  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_13  arc_capacity_910  -25
    arc_1_16_13  connected_order_arc_911  -12
    arc_1_16_13  in_degree_1015  1
    arc_1_16_13  out_degree_1032  1
    arc_1_16_13  original_T_including_depot_unload_1058  8.7008776944597639e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_13  arc_capacity_910  1
    load_1_16_13  free_load_conservation_1019  -1
    load_1_16_13  free_load_conservation_1037  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_14  arc_capacity_912  -25
    arc_1_16_14  connected_order_arc_913  -12
    arc_1_16_14  in_degree_1021  1
    arc_1_16_14  out_degree_1032  1
    arc_1_16_14  original_T_including_depot_unload_1058  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_14  arc_capacity_912  1
    load_1_16_14  free_load_conservation_1025  -1
    load_1_16_14  free_load_conservation_1037  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_15  arc_capacity_914  -25
    arc_1_16_15  connected_order_arc_915  -12
    arc_1_16_15  in_degree_1027  1
    arc_1_16_15  out_degree_1032  1
    arc_1_16_15  original_T_including_depot_unload_1058  1.6320002720932780e+00
    MARKER    'MARKER'                 'INTEND'
    load_1_16_15  arc_capacity_914  1
    load_1_16_15  free_load_conservation_1031  -1
    load_1_16_15  free_load_conservation_1037  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_17  arc_capacity_916  -25
    arc_1_16_17  connected_order_arc_917  -12
    arc_1_16_17  out_degree_1032  1
    arc_1_16_17  in_degree_1039  1
    arc_1_16_17  original_T_including_depot_unload_1058  1.1561945146971345e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_17  arc_capacity_916  1
    load_1_16_17  free_load_conservation_1037  1
    load_1_16_17  free_load_conservation_1043  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_18  arc_capacity_918  -25
    arc_1_16_18  connected_order_arc_919  -12
    arc_1_16_18  out_degree_1032  1
    arc_1_16_18  in_degree_1045  1
    arc_1_16_18  original_T_including_depot_unload_1058  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_18  arc_capacity_918  1
    load_1_16_18  free_load_conservation_1037  1
    load_1_16_18  free_load_conservation_1049  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_19  arc_capacity_920  -25
    arc_1_16_19  connected_order_arc_921  -12
    arc_1_16_19  out_degree_1032  1
    arc_1_16_19  in_degree_1051  1
    arc_1_16_19  original_T_including_depot_unload_1058  5.7424143497696048e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_19  arc_capacity_920  1
    load_1_16_19  free_load_conservation_1037  1
    load_1_16_19  free_load_conservation_1055  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_0  arc_capacity_922  -25
    arc_1_17_0  depot_return_or_bypass_986  1
    arc_1_17_0  out_degree_1038  1
    arc_1_17_0  original_T_including_depot_unload_1058  3.5061909388980052e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_0  arc_capacity_922  1
    load_1_17_0  free_load_conservation_1043  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_5  arc_capacity_923  -25
    arc_1_17_5  connected_order_arc_924  -12
    arc_1_17_5  in_degree_988  1
    arc_1_17_5  out_degree_1038  1
    arc_1_17_5  original_T_including_depot_unload_1058  3.7747736142736670e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_5  arc_capacity_923  1
    load_1_17_5  segment_load_conservation_991  -1
    load_1_17_5  segment_prefix_lb_992  1
    load_1_17_5  segment_prefix_ub_993  1
    load_1_17_5  free_load_conservation_1043  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_6  arc_capacity_925  -25
    arc_1_17_6  connected_order_arc_926  -12
    arc_1_17_6  in_degree_995  1
    arc_1_17_6  out_degree_1038  1
    arc_1_17_6  original_T_including_depot_unload_1058  1.2769578074048923e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_6  arc_capacity_925  1
    load_1_17_6  segment_load_conservation_998  -1
    load_1_17_6  segment_prefix_lb_999  1
    load_1_17_6  segment_prefix_ub_1000  1
    load_1_17_6  free_load_conservation_1043  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_7  arc_capacity_927  -25
    arc_1_17_7  connected_order_arc_928  -12
    arc_1_17_7  in_degree_1002  1
    arc_1_17_7  out_degree_1038  1
    arc_1_17_7  original_T_including_depot_unload_1058  3.0614301781508658e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_7  arc_capacity_927  1
    load_1_17_7  segment_load_conservation_1005  -1
    load_1_17_7  segment_prefix_lb_1006  1
    load_1_17_7  segment_prefix_ub_1007  1
    load_1_17_7  free_load_conservation_1043  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_12  arc_capacity_929  -25
    arc_1_17_12  connected_order_arc_930  -12
    arc_1_17_12  in_degree_1009  1
    arc_1_17_12  out_degree_1038  1
    arc_1_17_12  original_T_including_depot_unload_1058  1.0313568965059917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_12  arc_capacity_929  1
    load_1_17_12  free_load_conservation_1013  -1
    load_1_17_12  free_load_conservation_1043  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_13  arc_capacity_931  -25
    arc_1_17_13  connected_order_arc_932  -12
    arc_1_17_13  in_degree_1015  1
    arc_1_17_13  out_degree_1038  1
    arc_1_17_13  original_T_including_depot_unload_1058  1.6406378986588031e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_13  arc_capacity_931  1
    load_1_17_13  free_load_conservation_1019  -1
    load_1_17_13  free_load_conservation_1043  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_14  arc_capacity_933  -25
    arc_1_17_14  connected_order_arc_934  -12
    arc_1_17_14  in_degree_1021  1
    arc_1_17_14  out_degree_1038  1
    arc_1_17_14  original_T_including_depot_unload_1058  1.8911324761641883e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_14  arc_capacity_933  1
    load_1_17_14  free_load_conservation_1025  -1
    load_1_17_14  free_load_conservation_1043  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_15  arc_capacity_935  -25
    arc_1_17_15  connected_order_arc_936  -12
    arc_1_17_15  in_degree_1027  1
    arc_1_17_15  out_degree_1038  1
    arc_1_17_15  original_T_including_depot_unload_1058  1.1545648513745866e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_15  arc_capacity_935  1
    load_1_17_15  free_load_conservation_1031  -1
    load_1_17_15  free_load_conservation_1043  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_16  arc_capacity_937  -25
    arc_1_17_16  connected_order_arc_938  -12
    arc_1_17_16  in_degree_1033  1
    arc_1_17_16  out_degree_1038  1
    arc_1_17_16  original_T_including_depot_unload_1058  1.1561945146971345e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_16  arc_capacity_937  1
    load_1_17_16  free_load_conservation_1037  -1
    load_1_17_16  free_load_conservation_1043  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_18  arc_capacity_939  -25
    arc_1_17_18  connected_order_arc_940  -12
    arc_1_17_18  out_degree_1038  1
    arc_1_17_18  in_degree_1045  1
    arc_1_17_18  original_T_including_depot_unload_1058  1.2665309635243570e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_18  arc_capacity_939  1
    load_1_17_18  free_load_conservation_1043  1
    load_1_17_18  free_load_conservation_1049  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_19  arc_capacity_941  -25
    arc_1_17_19  connected_order_arc_942  -12
    arc_1_17_19  out_degree_1038  1
    arc_1_17_19  in_degree_1051  1
    arc_1_17_19  original_T_including_depot_unload_1058  6.5869285599668615e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_19  arc_capacity_941  1
    load_1_17_19  free_load_conservation_1043  1
    load_1_17_19  free_load_conservation_1055  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_0  arc_capacity_943  -25
    arc_1_18_0  depot_return_or_bypass_986  1
    arc_1_18_0  out_degree_1044  1
    arc_1_18_0  original_T_including_depot_unload_1058  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_0  arc_capacity_943  1
    load_1_18_0  free_load_conservation_1049  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_5  arc_capacity_944  -25
    arc_1_18_5  connected_order_arc_945  -12
    arc_1_18_5  in_degree_988  1
    arc_1_18_5  out_degree_1044  1
    arc_1_18_5  original_T_including_depot_unload_1058  1.6437981048195304e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_5  arc_capacity_944  1
    load_1_18_5  segment_load_conservation_991  -1
    load_1_18_5  segment_prefix_lb_992  1
    load_1_18_5  segment_prefix_ub_993  1
    load_1_18_5  free_load_conservation_1049  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_6  arc_capacity_946  -25
    arc_1_18_6  connected_order_arc_947  -12
    arc_1_18_6  in_degree_995  1
    arc_1_18_6  out_degree_1044  1
    arc_1_18_6  original_T_including_depot_unload_1058  2.3444750474890211e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_6  arc_capacity_946  1
    load_1_18_6  segment_load_conservation_998  -1
    load_1_18_6  segment_prefix_lb_999  1
    load_1_18_6  segment_prefix_ub_1000  1
    load_1_18_6  free_load_conservation_1049  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_7  arc_capacity_948  -25
    arc_1_18_7  connected_order_arc_949  -12
    arc_1_18_7  in_degree_1002  1
    arc_1_18_7  out_degree_1044  1
    arc_1_18_7  original_T_including_depot_unload_1058  1.4738339199468992e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_7  arc_capacity_948  1
    load_1_18_7  segment_load_conservation_1005  -1
    load_1_18_7  segment_prefix_lb_1006  1
    load_1_18_7  segment_prefix_ub_1007  1
    load_1_18_7  free_load_conservation_1049  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_12  arc_capacity_950  -25
    arc_1_18_12  connected_order_arc_951  -12
    arc_1_18_12  in_degree_1009  1
    arc_1_18_12  out_degree_1044  1
    arc_1_18_12  original_T_including_depot_unload_1058  1.6988291947636669e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_12  arc_capacity_950  1
    load_1_18_12  free_load_conservation_1013  -1
    load_1_18_12  free_load_conservation_1049  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_13  arc_capacity_952  -25
    arc_1_18_13  connected_order_arc_953  -12
    arc_1_18_13  in_degree_1015  1
    arc_1_18_13  out_degree_1044  1
    arc_1_18_13  original_T_including_depot_unload_1058  1.7489191280566063e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_13  arc_capacity_952  1
    load_1_18_13  free_load_conservation_1019  -1
    load_1_18_13  free_load_conservation_1049  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_14  arc_capacity_954  -25
    arc_1_18_14  connected_order_arc_955  -12
    arc_1_18_14  in_degree_1021  1
    arc_1_18_14  out_degree_1044  1
    arc_1_18_14  original_T_including_depot_unload_1058  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_1_18_14  arc_capacity_954  1
    load_1_18_14  free_load_conservation_1025  -1
    load_1_18_14  free_load_conservation_1049  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_15  arc_capacity_956  -25
    arc_1_18_15  connected_order_arc_957  -12
    arc_1_18_15  in_degree_1027  1
    arc_1_18_15  out_degree_1044  1
    arc_1_18_15  original_T_including_depot_unload_1058  8.7906342149593650e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_15  arc_capacity_956  1
    load_1_18_15  free_load_conservation_1031  -1
    load_1_18_15  free_load_conservation_1049  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_16  arc_capacity_958  -25
    arc_1_18_16  connected_order_arc_959  -12
    arc_1_18_16  in_degree_1033  1
    arc_1_18_16  out_degree_1044  1
    arc_1_18_16  original_T_including_depot_unload_1058  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_16  arc_capacity_958  1
    load_1_18_16  free_load_conservation_1037  -1
    load_1_18_16  free_load_conservation_1049  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_17  arc_capacity_960  -25
    arc_1_18_17  connected_order_arc_961  -12
    arc_1_18_17  in_degree_1039  1
    arc_1_18_17  out_degree_1044  1
    arc_1_18_17  original_T_including_depot_unload_1058  1.2665309635243570e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_17  arc_capacity_960  1
    load_1_18_17  free_load_conservation_1043  -1
    load_1_18_17  free_load_conservation_1049  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_19  arc_capacity_962  -25
    arc_1_18_19  connected_order_arc_963  -12
    arc_1_18_19  out_degree_1044  1
    arc_1_18_19  in_degree_1051  1
    arc_1_18_19  original_T_including_depot_unload_1058  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_1_18_19  arc_capacity_962  1
    load_1_18_19  free_load_conservation_1049  1
    load_1_18_19  free_load_conservation_1055  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_0  arc_capacity_964  -25
    arc_1_19_0  depot_return_or_bypass_986  1
    arc_1_19_0  out_degree_1050  1
    arc_1_19_0  original_T_including_depot_unload_1058  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_0  arc_capacity_964  1
    load_1_19_0  free_load_conservation_1055  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_5  arc_capacity_965  -25
    arc_1_19_5  connected_order_arc_966  -12
    arc_1_19_5  in_degree_988  1
    arc_1_19_5  out_degree_1050  1
    arc_1_19_5  original_T_including_depot_unload_1058  1.0198535056659911e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_5  arc_capacity_965  1
    load_1_19_5  segment_load_conservation_991  -1
    load_1_19_5  segment_prefix_lb_992  1
    load_1_19_5  segment_prefix_ub_993  1
    load_1_19_5  free_load_conservation_1055  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_6  arc_capacity_967  -25
    arc_1_19_6  connected_order_arc_968  -12
    arc_1_19_6  in_degree_995  1
    arc_1_19_6  out_degree_1050  1
    arc_1_19_6  original_T_including_depot_unload_1058  1.9029099398713563e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_6  arc_capacity_967  1
    load_1_19_6  segment_load_conservation_998  -1
    load_1_19_6  segment_prefix_lb_999  1
    load_1_19_6  segment_prefix_ub_1000  1
    load_1_19_6  free_load_conservation_1055  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_7  arc_capacity_969  -25
    arc_1_19_7  connected_order_arc_970  -12
    arc_1_19_7  in_degree_1002  1
    arc_1_19_7  out_degree_1050  1
    arc_1_19_7  original_T_including_depot_unload_1058  9.3836915476275669e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_7  arc_capacity_969  1
    load_1_19_7  segment_load_conservation_1005  -1
    load_1_19_7  segment_prefix_lb_1006  1
    load_1_19_7  segment_prefix_ub_1007  1
    load_1_19_7  free_load_conservation_1055  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_12  arc_capacity_971  -25
    arc_1_19_12  connected_order_arc_972  -12
    arc_1_19_12  in_degree_1009  1
    arc_1_19_12  out_degree_1050  1
    arc_1_19_12  original_T_including_depot_unload_1058  1.0321140782598593e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_12  arc_capacity_971  1
    load_1_19_12  free_load_conservation_1013  -1
    load_1_19_12  free_load_conservation_1055  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_13  arc_capacity_973  -25
    arc_1_19_13  connected_order_arc_974  -12
    arc_1_19_13  in_degree_1015  1
    arc_1_19_13  out_degree_1050  1
    arc_1_19_13  original_T_including_depot_unload_1058  1.3104307696104611e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_13  arc_capacity_973  1
    load_1_19_13  free_load_conservation_1019  -1
    load_1_19_13  free_load_conservation_1055  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_14  arc_capacity_975  -25
    arc_1_19_14  connected_order_arc_976  -12
    arc_1_19_14  in_degree_1021  1
    arc_1_19_14  out_degree_1050  1
    arc_1_19_14  original_T_including_depot_unload_1058  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_14  arc_capacity_975  1
    load_1_19_14  free_load_conservation_1025  -1
    load_1_19_14  free_load_conservation_1055  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_15  arc_capacity_977  -25
    arc_1_19_15  connected_order_arc_978  -12
    arc_1_19_15  in_degree_1027  1
    arc_1_19_15  out_degree_1050  1
    arc_1_19_15  original_T_including_depot_unload_1058  5.7276146581216926e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_15  arc_capacity_977  1
    load_1_19_15  free_load_conservation_1031  -1
    load_1_19_15  free_load_conservation_1055  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_16  arc_capacity_979  -25
    arc_1_19_16  connected_order_arc_980  -12
    arc_1_19_16  in_degree_1033  1
    arc_1_19_16  out_degree_1050  1
    arc_1_19_16  original_T_including_depot_unload_1058  5.7424143497696048e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_16  arc_capacity_979  1
    load_1_19_16  free_load_conservation_1037  -1
    load_1_19_16  free_load_conservation_1055  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_17  arc_capacity_981  -25
    arc_1_19_17  connected_order_arc_982  -12
    arc_1_19_17  in_degree_1039  1
    arc_1_19_17  out_degree_1050  1
    arc_1_19_17  original_T_including_depot_unload_1058  6.5869285599668615e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_17  arc_capacity_981  1
    load_1_19_17  free_load_conservation_1043  -1
    load_1_19_17  free_load_conservation_1055  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_18  arc_capacity_983  -25
    arc_1_19_18  connected_order_arc_984  -12
    arc_1_19_18  in_degree_1045  1
    arc_1_19_18  out_degree_1050  1
    arc_1_19_18  original_T_including_depot_unload_1058  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_1_19_18  arc_capacity_983  1
    load_1_19_18  free_load_conservation_1049  -1
    load_1_19_18  free_load_conservation_1055  1
    visit_2_8  out_degree_1350  -1
    visit_2_8  in_degree_1351  -1
    visit_2_8  order_active_lb_1352  -1
    visit_2_8  order_active_ub_1353  -12
    order_2_8  connected_order_arc_1074  -1
    order_2_8  connected_order_arc_1076  -1
    order_2_8  connected_order_arc_1078  -1
    order_2_8  connected_order_arc_1080  -1
    order_2_8  connected_order_arc_1082  -1
    order_2_8  connected_order_arc_1084  -1
    order_2_8  connected_order_arc_1086  -1
    order_2_8  connected_order_arc_1088  -1
    order_2_8  connected_order_arc_1090  -1
    order_2_8  connected_order_arc_1092  -1
    order_2_8  connected_order_arc_1094  -1
    order_2_8  connected_order_arc_1097  1
    order_2_8  connected_order_arc_1120  1
    order_2_8  connected_order_arc_1143  1
    order_2_8  connected_order_arc_1166  1
    order_2_8  connected_order_arc_1189  1
    order_2_8  connected_order_arc_1212  1
    order_2_8  connected_order_arc_1235  1
    order_2_8  connected_order_arc_1258  1
    order_2_8  connected_order_arc_1281  1
    order_2_8  connected_order_arc_1304  1
    order_2_8  connected_order_arc_1327  1
    order_2_8  order_active_lb_1352  1
    order_2_8  order_active_ub_1353  1
    order_2_8  fixed_segment_relative_order_1426  -1
    visit_2_9  out_degree_1357  -1
    visit_2_9  in_degree_1358  -1
    visit_2_9  order_active_lb_1359  -1
    visit_2_9  order_active_ub_1360  -12
    order_2_9  connected_order_arc_1074  1
    order_2_9  connected_order_arc_1097  -1
    order_2_9  connected_order_arc_1099  -1
    order_2_9  connected_order_arc_1101  -1
    order_2_9  connected_order_arc_1103  -1
    order_2_9  connected_order_arc_1105  -1
    order_2_9  connected_order_arc_1107  -1
    order_2_9  connected_order_arc_1109  -1
    order_2_9  connected_order_arc_1111  -1
    order_2_9  connected_order_arc_1113  -1
    order_2_9  connected_order_arc_1115  -1
    order_2_9  connected_order_arc_1117  -1
    order_2_9  connected_order_arc_1122  1
    order_2_9  connected_order_arc_1145  1
    order_2_9  connected_order_arc_1168  1
    order_2_9  connected_order_arc_1191  1
    order_2_9  connected_order_arc_1214  1
    order_2_9  connected_order_arc_1237  1
    order_2_9  connected_order_arc_1260  1
    order_2_9  connected_order_arc_1283  1
    order_2_9  connected_order_arc_1306  1
    order_2_9  connected_order_arc_1329  1
    order_2_9  order_active_lb_1359  1
    order_2_9  order_active_ub_1360  1
    order_2_9  fixed_segment_relative_order_1426  1
    order_2_9  fixed_segment_relative_order_1427  -1
    visit_2_10  out_degree_1364  -1
    visit_2_10  in_degree_1365  -1
    visit_2_10  order_active_lb_1366  -1
    visit_2_10  order_active_ub_1367  -12
    order_2_10  connected_order_arc_1076  1
    order_2_10  connected_order_arc_1099  1
    order_2_10  connected_order_arc_1120  -1
    order_2_10  connected_order_arc_1122  -1
    order_2_10  connected_order_arc_1124  -1
    order_2_10  connected_order_arc_1126  -1
    order_2_10  connected_order_arc_1128  -1
    order_2_10  connected_order_arc_1130  -1
    order_2_10  connected_order_arc_1132  -1
    order_2_10  connected_order_arc_1134  -1
    order_2_10  connected_order_arc_1136  -1
    order_2_10  connected_order_arc_1138  -1
    order_2_10  connected_order_arc_1140  -1
    order_2_10  connected_order_arc_1147  1
    order_2_10  connected_order_arc_1170  1
    order_2_10  connected_order_arc_1193  1
    order_2_10  connected_order_arc_1216  1
    order_2_10  connected_order_arc_1239  1
    order_2_10  connected_order_arc_1262  1
    order_2_10  connected_order_arc_1285  1
    order_2_10  connected_order_arc_1308  1
    order_2_10  connected_order_arc_1331  1
    order_2_10  order_active_lb_1366  1
    order_2_10  order_active_ub_1367  1
    order_2_10  fixed_segment_relative_order_1427  1
    order_2_10  fixed_segment_relative_order_1428  -1
    visit_2_11  out_degree_1371  -1
    visit_2_11  in_degree_1372  -1
    visit_2_11  order_active_lb_1373  -1
    visit_2_11  order_active_ub_1374  -12
    order_2_11  connected_order_arc_1078  1
    order_2_11  connected_order_arc_1101  1
    order_2_11  connected_order_arc_1124  1
    order_2_11  connected_order_arc_1143  -1
    order_2_11  connected_order_arc_1145  -1
    order_2_11  connected_order_arc_1147  -1
    order_2_11  connected_order_arc_1149  -1
    order_2_11  connected_order_arc_1151  -1
    order_2_11  connected_order_arc_1153  -1
    order_2_11  connected_order_arc_1155  -1
    order_2_11  connected_order_arc_1157  -1
    order_2_11  connected_order_arc_1159  -1
    order_2_11  connected_order_arc_1161  -1
    order_2_11  connected_order_arc_1163  -1
    order_2_11  connected_order_arc_1172  1
    order_2_11  connected_order_arc_1195  1
    order_2_11  connected_order_arc_1218  1
    order_2_11  connected_order_arc_1241  1
    order_2_11  connected_order_arc_1264  1
    order_2_11  connected_order_arc_1287  1
    order_2_11  connected_order_arc_1310  1
    order_2_11  connected_order_arc_1333  1
    order_2_11  order_active_lb_1373  1
    order_2_11  order_active_ub_1374  1
    order_2_11  fixed_segment_relative_order_1428  1
    visit_2_12  out_degree_1378  -1
    visit_2_12  in_degree_1379  -1
    visit_2_12  order_active_lb_1380  -1
    visit_2_12  order_active_ub_1381  -12
    visit_2_12  service_visit_def_1382  -1
    order_2_12  connected_order_arc_1080  1
    order_2_12  connected_order_arc_1103  1
    order_2_12  connected_order_arc_1126  1
    order_2_12  connected_order_arc_1149  1
    order_2_12  connected_order_arc_1166  -1
    order_2_12  connected_order_arc_1168  -1
    order_2_12  connected_order_arc_1170  -1
    order_2_12  connected_order_arc_1172  -1
    order_2_12  connected_order_arc_1174  -1
    order_2_12  connected_order_arc_1176  -1
    order_2_12  connected_order_arc_1178  -1
    order_2_12  connected_order_arc_1180  -1
    order_2_12  connected_order_arc_1182  -1
    order_2_12  connected_order_arc_1184  -1
    order_2_12  connected_order_arc_1186  -1
    order_2_12  connected_order_arc_1197  1
    order_2_12  connected_order_arc_1220  1
    order_2_12  connected_order_arc_1243  1
    order_2_12  connected_order_arc_1266  1
    order_2_12  connected_order_arc_1289  1
    order_2_12  connected_order_arc_1312  1
    order_2_12  connected_order_arc_1335  1
    order_2_12  order_active_lb_1380  1
    order_2_12  order_active_ub_1381  1
    visit_2_13  out_degree_1384  -1
    visit_2_13  in_degree_1385  -1
    visit_2_13  order_active_lb_1386  -1
    visit_2_13  order_active_ub_1387  -12
    visit_2_13  service_visit_def_1388  -1
    order_2_13  connected_order_arc_1082  1
    order_2_13  connected_order_arc_1105  1
    order_2_13  connected_order_arc_1128  1
    order_2_13  connected_order_arc_1151  1
    order_2_13  connected_order_arc_1174  1
    order_2_13  connected_order_arc_1189  -1
    order_2_13  connected_order_arc_1191  -1
    order_2_13  connected_order_arc_1193  -1
    order_2_13  connected_order_arc_1195  -1
    order_2_13  connected_order_arc_1197  -1
    order_2_13  connected_order_arc_1199  -1
    order_2_13  connected_order_arc_1201  -1
    order_2_13  connected_order_arc_1203  -1
    order_2_13  connected_order_arc_1205  -1
    order_2_13  connected_order_arc_1207  -1
    order_2_13  connected_order_arc_1209  -1
    order_2_13  connected_order_arc_1222  1
    order_2_13  connected_order_arc_1245  1
    order_2_13  connected_order_arc_1268  1
    order_2_13  connected_order_arc_1291  1
    order_2_13  connected_order_arc_1314  1
    order_2_13  connected_order_arc_1337  1
    order_2_13  order_active_lb_1386  1
    order_2_13  order_active_ub_1387  1
    visit_2_14  out_degree_1390  -1
    visit_2_14  in_degree_1391  -1
    visit_2_14  order_active_lb_1392  -1
    visit_2_14  order_active_ub_1393  -12
    visit_2_14  service_visit_def_1394  -1
    order_2_14  connected_order_arc_1084  1
    order_2_14  connected_order_arc_1107  1
    order_2_14  connected_order_arc_1130  1
    order_2_14  connected_order_arc_1153  1
    order_2_14  connected_order_arc_1176  1
    order_2_14  connected_order_arc_1199  1
    order_2_14  connected_order_arc_1212  -1
    order_2_14  connected_order_arc_1214  -1
    order_2_14  connected_order_arc_1216  -1
    order_2_14  connected_order_arc_1218  -1
    order_2_14  connected_order_arc_1220  -1
    order_2_14  connected_order_arc_1222  -1
    order_2_14  connected_order_arc_1224  -1
    order_2_14  connected_order_arc_1226  -1
    order_2_14  connected_order_arc_1228  -1
    order_2_14  connected_order_arc_1230  -1
    order_2_14  connected_order_arc_1232  -1
    order_2_14  connected_order_arc_1247  1
    order_2_14  connected_order_arc_1270  1
    order_2_14  connected_order_arc_1293  1
    order_2_14  connected_order_arc_1316  1
    order_2_14  connected_order_arc_1339  1
    order_2_14  order_active_lb_1392  1
    order_2_14  order_active_ub_1393  1
    visit_2_15  out_degree_1396  -1
    visit_2_15  in_degree_1397  -1
    visit_2_15  order_active_lb_1398  -1
    visit_2_15  order_active_ub_1399  -12
    visit_2_15  service_visit_def_1400  -1
    order_2_15  connected_order_arc_1086  1
    order_2_15  connected_order_arc_1109  1
    order_2_15  connected_order_arc_1132  1
    order_2_15  connected_order_arc_1155  1
    order_2_15  connected_order_arc_1178  1
    order_2_15  connected_order_arc_1201  1
    order_2_15  connected_order_arc_1224  1
    order_2_15  connected_order_arc_1235  -1
    order_2_15  connected_order_arc_1237  -1
    order_2_15  connected_order_arc_1239  -1
    order_2_15  connected_order_arc_1241  -1
    order_2_15  connected_order_arc_1243  -1
    order_2_15  connected_order_arc_1245  -1
    order_2_15  connected_order_arc_1247  -1
    order_2_15  connected_order_arc_1249  -1
    order_2_15  connected_order_arc_1251  -1
    order_2_15  connected_order_arc_1253  -1
    order_2_15  connected_order_arc_1255  -1
    order_2_15  connected_order_arc_1272  1
    order_2_15  connected_order_arc_1295  1
    order_2_15  connected_order_arc_1318  1
    order_2_15  connected_order_arc_1341  1
    order_2_15  order_active_lb_1398  1
    order_2_15  order_active_ub_1399  1
    visit_2_16  out_degree_1402  -1
    visit_2_16  in_degree_1403  -1
    visit_2_16  order_active_lb_1404  -1
    visit_2_16  order_active_ub_1405  -12
    visit_2_16  service_visit_def_1406  -1
    order_2_16  connected_order_arc_1088  1
    order_2_16  connected_order_arc_1111  1
    order_2_16  connected_order_arc_1134  1
    order_2_16  connected_order_arc_1157  1
    order_2_16  connected_order_arc_1180  1
    order_2_16  connected_order_arc_1203  1
    order_2_16  connected_order_arc_1226  1
    order_2_16  connected_order_arc_1249  1
    order_2_16  connected_order_arc_1258  -1
    order_2_16  connected_order_arc_1260  -1
    order_2_16  connected_order_arc_1262  -1
    order_2_16  connected_order_arc_1264  -1
    order_2_16  connected_order_arc_1266  -1
    order_2_16  connected_order_arc_1268  -1
    order_2_16  connected_order_arc_1270  -1
    order_2_16  connected_order_arc_1272  -1
    order_2_16  connected_order_arc_1274  -1
    order_2_16  connected_order_arc_1276  -1
    order_2_16  connected_order_arc_1278  -1
    order_2_16  connected_order_arc_1297  1
    order_2_16  connected_order_arc_1320  1
    order_2_16  connected_order_arc_1343  1
    order_2_16  order_active_lb_1404  1
    order_2_16  order_active_ub_1405  1
    visit_2_17  out_degree_1408  -1
    visit_2_17  in_degree_1409  -1
    visit_2_17  order_active_lb_1410  -1
    visit_2_17  order_active_ub_1411  -12
    visit_2_17  service_visit_def_1412  -1
    order_2_17  connected_order_arc_1090  1
    order_2_17  connected_order_arc_1113  1
    order_2_17  connected_order_arc_1136  1
    order_2_17  connected_order_arc_1159  1
    order_2_17  connected_order_arc_1182  1
    order_2_17  connected_order_arc_1205  1
    order_2_17  connected_order_arc_1228  1
    order_2_17  connected_order_arc_1251  1
    order_2_17  connected_order_arc_1274  1
    order_2_17  connected_order_arc_1281  -1
    order_2_17  connected_order_arc_1283  -1
    order_2_17  connected_order_arc_1285  -1
    order_2_17  connected_order_arc_1287  -1
    order_2_17  connected_order_arc_1289  -1
    order_2_17  connected_order_arc_1291  -1
    order_2_17  connected_order_arc_1293  -1
    order_2_17  connected_order_arc_1295  -1
    order_2_17  connected_order_arc_1297  -1
    order_2_17  connected_order_arc_1299  -1
    order_2_17  connected_order_arc_1301  -1
    order_2_17  connected_order_arc_1322  1
    order_2_17  connected_order_arc_1345  1
    order_2_17  order_active_lb_1410  1
    order_2_17  order_active_ub_1411  1
    visit_2_18  out_degree_1414  -1
    visit_2_18  in_degree_1415  -1
    visit_2_18  order_active_lb_1416  -1
    visit_2_18  order_active_ub_1417  -12
    visit_2_18  service_visit_def_1418  -1
    order_2_18  connected_order_arc_1092  1
    order_2_18  connected_order_arc_1115  1
    order_2_18  connected_order_arc_1138  1
    order_2_18  connected_order_arc_1161  1
    order_2_18  connected_order_arc_1184  1
    order_2_18  connected_order_arc_1207  1
    order_2_18  connected_order_arc_1230  1
    order_2_18  connected_order_arc_1253  1
    order_2_18  connected_order_arc_1276  1
    order_2_18  connected_order_arc_1299  1
    order_2_18  connected_order_arc_1304  -1
    order_2_18  connected_order_arc_1306  -1
    order_2_18  connected_order_arc_1308  -1
    order_2_18  connected_order_arc_1310  -1
    order_2_18  connected_order_arc_1312  -1
    order_2_18  connected_order_arc_1314  -1
    order_2_18  connected_order_arc_1316  -1
    order_2_18  connected_order_arc_1318  -1
    order_2_18  connected_order_arc_1320  -1
    order_2_18  connected_order_arc_1322  -1
    order_2_18  connected_order_arc_1324  -1
    order_2_18  connected_order_arc_1347  1
    order_2_18  order_active_lb_1416  1
    order_2_18  order_active_ub_1417  1
    visit_2_19  out_degree_1420  -1
    visit_2_19  in_degree_1421  -1
    visit_2_19  order_active_lb_1422  -1
    visit_2_19  order_active_ub_1423  -12
    visit_2_19  service_visit_def_1424  -1
    order_2_19  connected_order_arc_1094  1
    order_2_19  connected_order_arc_1117  1
    order_2_19  connected_order_arc_1140  1
    order_2_19  connected_order_arc_1163  1
    order_2_19  connected_order_arc_1186  1
    order_2_19  connected_order_arc_1209  1
    order_2_19  connected_order_arc_1232  1
    order_2_19  connected_order_arc_1255  1
    order_2_19  connected_order_arc_1278  1
    order_2_19  connected_order_arc_1301  1
    order_2_19  connected_order_arc_1324  1
    order_2_19  connected_order_arc_1327  -1
    order_2_19  connected_order_arc_1329  -1
    order_2_19  connected_order_arc_1331  -1
    order_2_19  connected_order_arc_1333  -1
    order_2_19  connected_order_arc_1335  -1
    order_2_19  connected_order_arc_1337  -1
    order_2_19  connected_order_arc_1339  -1
    order_2_19  connected_order_arc_1341  -1
    order_2_19  connected_order_arc_1343  -1
    order_2_19  connected_order_arc_1345  -1
    order_2_19  connected_order_arc_1347  -1
    order_2_19  order_active_lb_1422  1
    order_2_19  order_active_ub_1423  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_0  arc_capacity_1059  -30
    arc_2_0_0  depot_departure_or_bypass_1348  1
    arc_2_0_0  depot_return_or_bypass_1349  1
    MARKER    'MARKER'                 'INTEND'
    load_2_0_0  arc_capacity_1059  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_8  arc_capacity_1060  -30
    arc_2_0_8  depot_departure_or_bypass_1348  1
    arc_2_0_8  in_degree_1351  1
    arc_2_0_8  original_T_including_depot_unload_1429  7.9650294035968375e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_8  arc_capacity_1060  1
    load_2_0_8  segment_load_conservation_1354  -1
    load_2_0_8  segment_prefix_lb_1355  1
    load_2_0_8  segment_prefix_ub_1356  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_9  arc_capacity_1061  -30
    arc_2_0_9  depot_departure_or_bypass_1348  1
    arc_2_0_9  in_degree_1358  1
    arc_2_0_9  original_T_including_depot_unload_1429  1.4373810231417410e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_9  arc_capacity_1061  1
    load_2_0_9  segment_load_conservation_1361  -1
    load_2_0_9  segment_prefix_lb_1362  1
    load_2_0_9  segment_prefix_ub_1363  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_10  arc_capacity_1062  -30
    arc_2_0_10  depot_departure_or_bypass_1348  1
    arc_2_0_10  in_degree_1365  1
    arc_2_0_10  original_T_including_depot_unload_1429  1.4206108045382291e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_10  arc_capacity_1062  1
    load_2_0_10  segment_load_conservation_1368  -1
    load_2_0_10  segment_prefix_lb_1369  1
    load_2_0_10  segment_prefix_ub_1370  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_11  arc_capacity_1063  -30
    arc_2_0_11  depot_departure_or_bypass_1348  1
    arc_2_0_11  in_degree_1372  1
    arc_2_0_11  original_T_including_depot_unload_1429  1.4657426641025907e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_11  arc_capacity_1063  1
    load_2_0_11  segment_load_conservation_1375  -1
    load_2_0_11  segment_prefix_lb_1376  1
    load_2_0_11  segment_prefix_ub_1377  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_12  arc_capacity_1064  -30
    arc_2_0_12  depot_departure_or_bypass_1348  1
    arc_2_0_12  in_degree_1379  1
    arc_2_0_12  original_T_including_depot_unload_1429  1.1935953747864173e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_12  arc_capacity_1064  1
    load_2_0_12  free_load_conservation_1383  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_13  arc_capacity_1065  -30
    arc_2_0_13  depot_departure_or_bypass_1348  1
    arc_2_0_13  in_degree_1385  1
    arc_2_0_13  original_T_including_depot_unload_1429  1.6602888921784454e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_13  arc_capacity_1065  1
    load_2_0_13  free_load_conservation_1389  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_14  arc_capacity_1066  -30
    arc_2_0_14  depot_departure_or_bypass_1348  1
    arc_2_0_14  in_degree_1391  1
    arc_2_0_14  original_T_including_depot_unload_1429  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_14  arc_capacity_1066  1
    load_2_0_14  free_load_conservation_1395  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_15  arc_capacity_1067  -30
    arc_2_0_15  depot_departure_or_bypass_1348  1
    arc_2_0_15  in_degree_1397  1
    arc_2_0_15  original_T_including_depot_unload_1429  1.0056399980521732e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_15  arc_capacity_1067  1
    load_2_0_15  free_load_conservation_1401  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_16  arc_capacity_1068  -30
    arc_2_0_16  depot_departure_or_bypass_1348  1
    arc_2_0_16  in_degree_1403  1
    arc_2_0_16  original_T_including_depot_unload_1429  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_16  arc_capacity_1068  1
    load_2_0_16  free_load_conservation_1407  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_17  arc_capacity_1069  -30
    arc_2_0_17  depot_departure_or_bypass_1348  1
    arc_2_0_17  in_degree_1409  1
    arc_2_0_17  original_T_including_depot_unload_1429  3.5061909388980052e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_17  arc_capacity_1069  1
    load_2_0_17  free_load_conservation_1413  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_18  arc_capacity_1070  -30
    arc_2_0_18  depot_departure_or_bypass_1348  1
    arc_2_0_18  in_degree_1415  1
    arc_2_0_18  original_T_including_depot_unload_1429  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_18  arc_capacity_1070  1
    load_2_0_18  free_load_conservation_1419  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_19  arc_capacity_1071  -30
    arc_2_0_19  depot_departure_or_bypass_1348  1
    arc_2_0_19  in_degree_1421  1
    arc_2_0_19  original_T_including_depot_unload_1429  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_19  arc_capacity_1071  1
    load_2_0_19  free_load_conservation_1425  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_8_0  arc_capacity_1072  -30
    arc_2_8_0  depot_return_or_bypass_1349  1
    arc_2_8_0  out_degree_1350  1
    arc_2_8_0  original_T_including_depot_unload_1429  7.9650294035968375e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_8_0  arc_capacity_1072  1
    load_2_8_0  segment_load_conservation_1354  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_8_9  arc_capacity_1073  -30
    arc_2_8_9  connected_order_arc_1074  -13
    arc_2_8_9  out_degree_1350  1
    arc_2_8_9  in_degree_1358  1
    arc_2_8_9  original_T_including_depot_unload_1429  7.5681404708111961e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_8_9  arc_capacity_1073  1
    load_2_8_9  segment_load_conservation_1354  1
    load_2_8_9  segment_load_conservation_1361  -1
    load_2_8_9  segment_prefix_lb_1362  1
    load_2_8_9  segment_prefix_ub_1363  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_8_10  arc_capacity_1075  -30
    arc_2_8_10  connected_order_arc_1076  -13
    arc_2_8_10  out_degree_1350  1
    arc_2_8_10  in_degree_1365  1
    arc_2_8_10  original_T_including_depot_unload_1429  6.6735284319782306e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_8_10  arc_capacity_1075  1
    load_2_8_10  segment_load_conservation_1354  1
    load_2_8_10  segment_load_conservation_1368  -1
    load_2_8_10  segment_prefix_lb_1369  1
    load_2_8_10  segment_prefix_ub_1370  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_8_11  arc_capacity_1077  -30
    arc_2_8_11  connected_order_arc_1078  -13
    arc_2_8_11  out_degree_1350  1
    arc_2_8_11  in_degree_1372  1
    arc_2_8_11  original_T_including_depot_unload_1429  7.0252509787186375e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_8_11  arc_capacity_1077  1
    load_2_8_11  segment_load_conservation_1354  1
    load_2_8_11  segment_load_conservation_1375  -1
    load_2_8_11  segment_prefix_lb_1376  1
    load_2_8_11  segment_prefix_ub_1377  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_8_12  arc_capacity_1079  -30
    arc_2_8_12  connected_order_arc_1080  -13
    arc_2_8_12  out_degree_1350  1
    arc_2_8_12  in_degree_1379  1
    arc_2_8_12  original_T_including_depot_unload_1429  1.1851786693030479e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_8_12  arc_capacity_1079  1
    load_2_8_12  segment_load_conservation_1354  1
    load_2_8_12  free_load_conservation_1383  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_8_13  arc_capacity_1081  -30
    arc_2_8_13  connected_order_arc_1082  -13
    arc_2_8_13  out_degree_1350  1
    arc_2_8_13  in_degree_1385  1
    arc_2_8_13  original_T_including_depot_unload_1429  1.2177809159572148e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_8_13  arc_capacity_1081  1
    load_2_8_13  segment_load_conservation_1354  1
    load_2_8_13  free_load_conservation_1389  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_8_14  arc_capacity_1083  -30
    arc_2_8_14  connected_order_arc_1084  -13
    arc_2_8_14  out_degree_1350  1
    arc_2_8_14  in_degree_1391  1
    arc_2_8_14  original_T_including_depot_unload_1429  9.8108674361469946e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_8_14  arc_capacity_1083  1
    load_2_8_14  segment_load_conservation_1354  1
    load_2_8_14  free_load_conservation_1395  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_8_15  arc_capacity_1085  -30
    arc_2_8_15  connected_order_arc_1086  -13
    arc_2_8_15  out_degree_1350  1
    arc_2_8_15  in_degree_1397  1
    arc_2_8_15  original_T_including_depot_unload_1429  3.5166546157461704e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_8_15  arc_capacity_1085  1
    load_2_8_15  segment_load_conservation_1354  1
    load_2_8_15  free_load_conservation_1401  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_8_16  arc_capacity_1087  -30
    arc_2_8_16  connected_order_arc_1088  -13
    arc_2_8_16  out_degree_1350  1
    arc_2_8_16  in_degree_1403  1
    arc_2_8_16  original_T_including_depot_unload_1429  3.5235932354279930e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_8_16  arc_capacity_1087  1
    load_2_8_16  segment_load_conservation_1354  1
    load_2_8_16  free_load_conservation_1407  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_8_17  arc_capacity_1089  -30
    arc_2_8_17  connected_order_arc_1090  -13
    arc_2_8_17  out_degree_1350  1
    arc_2_8_17  in_degree_1409  1
    arc_2_8_17  original_T_including_depot_unload_1429  1.0363838262442744e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_8_17  arc_capacity_1089  1
    load_2_8_17  segment_load_conservation_1354  1
    load_2_8_17  free_load_conservation_1413  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_8_18  arc_capacity_1091  -30
    arc_2_8_18  connected_order_arc_1092  -13
    arc_2_8_18  out_degree_1350  1
    arc_2_8_18  in_degree_1415  1
    arc_2_8_18  original_T_including_depot_unload_1429  5.4405628017126674e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_8_18  arc_capacity_1091  1
    load_2_8_18  segment_load_conservation_1354  1
    load_2_8_18  free_load_conservation_1419  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_8_19  arc_capacity_1093  -30
    arc_2_8_19  connected_order_arc_1094  -13
    arc_2_8_19  out_degree_1350  1
    arc_2_8_19  in_degree_1421  1
    arc_2_8_19  original_T_including_depot_unload_1429  3.7831268047064754e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_8_19  arc_capacity_1093  1
    load_2_8_19  segment_load_conservation_1354  1
    load_2_8_19  free_load_conservation_1425  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_0  arc_capacity_1095  -30
    arc_2_9_0  depot_return_or_bypass_1349  1
    arc_2_9_0  out_degree_1357  1
    arc_2_9_0  original_T_including_depot_unload_1429  1.4373810231417410e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_9_0  arc_capacity_1095  1
    load_2_9_0  segment_load_conservation_1361  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_8  arc_capacity_1096  -30
    arc_2_9_8  connected_order_arc_1097  -13
    arc_2_9_8  in_degree_1351  1
    arc_2_9_8  out_degree_1357  1
    arc_2_9_8  original_T_including_depot_unload_1429  7.5681404708111961e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_9_8  arc_capacity_1096  1
    load_2_9_8  segment_load_conservation_1354  -1
    load_2_9_8  segment_prefix_lb_1355  1
    load_2_9_8  segment_prefix_ub_1356  1
    load_2_9_8  segment_load_conservation_1361  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_10  arc_capacity_1098  -30
    arc_2_9_10  connected_order_arc_1099  -13
    arc_2_9_10  out_degree_1357  1
    arc_2_9_10  in_degree_1365  1
    arc_2_9_10  original_T_including_depot_unload_1429  2.2310212250199638e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_9_10  arc_capacity_1098  1
    load_2_9_10  segment_load_conservation_1361  1
    load_2_9_10  segment_load_conservation_1368  -1
    load_2_9_10  segment_prefix_lb_1369  1
    load_2_9_10  segment_prefix_ub_1370  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_11  arc_capacity_1100  -30
    arc_2_9_11  connected_order_arc_1101  -13
    arc_2_9_11  out_degree_1357  1
    arc_2_9_11  in_degree_1372  1
    arc_2_9_11  original_T_including_depot_unload_1429  8.2580969662641792e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_9_11  arc_capacity_1100  1
    load_2_9_11  segment_load_conservation_1361  1
    load_2_9_11  segment_load_conservation_1375  -1
    load_2_9_11  segment_prefix_lb_1376  1
    load_2_9_11  segment_prefix_ub_1377  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_12  arc_capacity_1102  -30
    arc_2_9_12  connected_order_arc_1103  -13
    arc_2_9_12  out_degree_1357  1
    arc_2_9_12  in_degree_1379  1
    arc_2_9_12  original_T_including_depot_unload_1429  1.8930659731251087e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_9_12  arc_capacity_1102  1
    load_2_9_12  segment_load_conservation_1361  1
    load_2_9_12  free_load_conservation_1383  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_13  arc_capacity_1104  -30
    arc_2_9_13  connected_order_arc_1105  -13
    arc_2_9_13  out_degree_1357  1
    arc_2_9_13  in_degree_1385  1
    arc_2_9_13  original_T_including_depot_unload_1429  1.6865464326628071e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_9_13  arc_capacity_1104  1
    load_2_9_13  segment_load_conservation_1361  1
    load_2_9_13  free_load_conservation_1389  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_14  arc_capacity_1106  -30
    arc_2_9_14  connected_order_arc_1107  -13
    arc_2_9_14  out_degree_1357  1
    arc_2_9_14  in_degree_1391  1
    arc_2_9_14  original_T_including_depot_unload_1429  2.9139628504456829e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_9_14  arc_capacity_1106  1
    load_2_9_14  segment_load_conservation_1361  1
    load_2_9_14  free_load_conservation_1395  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_15  arc_capacity_1108  -30
    arc_2_9_15  connected_order_arc_1109  -13
    arc_2_9_15  out_degree_1357  1
    arc_2_9_15  in_degree_1397  1
    arc_2_9_15  original_T_including_depot_unload_1429  926.407625506948
    MARKER    'MARKER'                 'INTEND'
    load_2_9_15  arc_capacity_1108  1
    load_2_9_15  segment_load_conservation_1361  1
    load_2_9_15  free_load_conservation_1401  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_16  arc_capacity_1110  -30
    arc_2_9_16  connected_order_arc_1111  -13
    arc_2_9_16  out_degree_1357  1
    arc_2_9_16  in_degree_1403  1
    arc_2_9_16  original_T_including_depot_unload_1429  925.691754925099
    MARKER    'MARKER'                 'INTEND'
    load_2_9_16  arc_capacity_1110  1
    load_2_9_16  segment_load_conservation_1361  1
    load_2_9_16  free_load_conservation_1407  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_17  arc_capacity_1112  -30
    arc_2_9_17  connected_order_arc_1113  -13
    arc_2_9_17  out_degree_1357  1
    arc_2_9_17  in_degree_1409  1
    arc_2_9_17  original_T_including_depot_unload_1429  1.7397988912348303e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_9_17  arc_capacity_1112  1
    load_2_9_17  segment_load_conservation_1361  1
    load_2_9_17  free_load_conservation_1413  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_18  arc_capacity_1114  -30
    arc_2_9_18  connected_order_arc_1115  -13
    arc_2_9_18  out_degree_1357  1
    arc_2_9_18  in_degree_1415  1
    arc_2_9_18  original_T_including_depot_unload_1429  5.7914586906741226e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_9_18  arc_capacity_1114  1
    load_2_9_18  segment_load_conservation_1361  1
    load_2_9_18  free_load_conservation_1419  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_19  arc_capacity_1116  -30
    arc_2_9_19  connected_order_arc_1117  -13
    arc_2_9_19  out_degree_1357  1
    arc_2_9_19  in_degree_1421  1
    arc_2_9_19  original_T_including_depot_unload_1429  1.0984912119828512e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_9_19  arc_capacity_1116  1
    load_2_9_19  segment_load_conservation_1361  1
    load_2_9_19  free_load_conservation_1425  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_0  arc_capacity_1118  -30
    arc_2_10_0  depot_return_or_bypass_1349  1
    arc_2_10_0  out_degree_1364  1
    arc_2_10_0  original_T_including_depot_unload_1429  1.4206108045382291e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_0  arc_capacity_1118  1
    load_2_10_0  segment_load_conservation_1368  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_8  arc_capacity_1119  -30
    arc_2_10_8  connected_order_arc_1120  -13
    arc_2_10_8  in_degree_1351  1
    arc_2_10_8  out_degree_1364  1
    arc_2_10_8  original_T_including_depot_unload_1429  6.6735284319782306e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_8  arc_capacity_1119  1
    load_2_10_8  segment_load_conservation_1354  -1
    load_2_10_8  segment_prefix_lb_1355  1
    load_2_10_8  segment_prefix_ub_1356  1
    load_2_10_8  segment_load_conservation_1368  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_9  arc_capacity_1121  -30
    arc_2_10_9  connected_order_arc_1122  -13
    arc_2_10_9  in_degree_1358  1
    arc_2_10_9  out_degree_1364  1
    arc_2_10_9  original_T_including_depot_unload_1429  2.2310212250199638e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_9  arc_capacity_1121  1
    load_2_10_9  segment_load_conservation_1361  -1
    load_2_10_9  segment_prefix_lb_1362  1
    load_2_10_9  segment_prefix_ub_1363  1
    load_2_10_9  segment_load_conservation_1368  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_11  arc_capacity_1123  -30
    arc_2_10_11  connected_order_arc_1124  -13
    arc_2_10_11  out_degree_1364  1
    arc_2_10_11  in_degree_1372  1
    arc_2_10_11  original_T_including_depot_unload_1429  604.307118555145
    MARKER    'MARKER'                 'INTEND'
    load_2_10_11  arc_capacity_1123  1
    load_2_10_11  segment_load_conservation_1368  1
    load_2_10_11  segment_load_conservation_1375  -1
    load_2_10_11  segment_prefix_lb_1376  1
    load_2_10_11  segment_prefix_ub_1377  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_12  arc_capacity_1125  -30
    arc_2_10_12  connected_order_arc_1126  -13
    arc_2_10_12  out_degree_1364  1
    arc_2_10_12  in_degree_1379  1
    arc_2_10_12  original_T_including_depot_unload_1429  1.7341837931716675e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_12  arc_capacity_1125  1
    load_2_10_12  segment_load_conservation_1368  1
    load_2_10_12  free_load_conservation_1383  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_13  arc_capacity_1127  -30
    arc_2_10_13  connected_order_arc_1128  -13
    arc_2_10_13  out_degree_1364  1
    arc_2_10_13  in_degree_1385  1
    arc_2_10_13  original_T_including_depot_unload_1429  1.4754486297628157e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_13  arc_capacity_1127  1
    load_2_10_13  segment_load_conservation_1368  1
    load_2_10_13  free_load_conservation_1389  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_14  arc_capacity_1129  -30
    arc_2_10_14  connected_order_arc_1130  -13
    arc_2_10_14  out_degree_1364  1
    arc_2_10_14  in_degree_1391  1
    arc_2_10_14  original_T_including_depot_unload_1429  5.1169459347980438e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_14  arc_capacity_1129  1
    load_2_10_14  segment_load_conservation_1368  1
    load_2_10_14  free_load_conservation_1395  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_15  arc_capacity_1131  -30
    arc_2_10_15  connected_order_arc_1132  -13
    arc_2_10_15  out_degree_1364  1
    arc_2_10_15  in_degree_1397  1
    arc_2_10_15  original_T_including_depot_unload_1429  7.6061661180217550e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_15  arc_capacity_1131  1
    load_2_10_15  segment_load_conservation_1368  1
    load_2_10_15  free_load_conservation_1401  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_16  arc_capacity_1133  -30
    arc_2_10_16  connected_order_arc_1134  -13
    arc_2_10_16  out_degree_1364  1
    arc_2_10_16  in_degree_1403  1
    arc_2_10_16  original_T_including_depot_unload_1429  7.5965235847304257e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_16  arc_capacity_1133  1
    load_2_10_16  segment_load_conservation_1368  1
    load_2_10_16  free_load_conservation_1407  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_17  arc_capacity_1135  -30
    arc_2_10_17  connected_order_arc_1136  -13
    arc_2_10_17  out_degree_1364  1
    arc_2_10_17  in_degree_1409  1
    arc_2_10_17  original_T_including_depot_unload_1429  1.6950562242445128e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_17  arc_capacity_1135  1
    load_2_10_17  segment_load_conservation_1368  1
    load_2_10_17  free_load_conservation_1413  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_18  arc_capacity_1137  -30
    arc_2_10_18  connected_order_arc_1138  -13
    arc_2_10_18  out_degree_1364  1
    arc_2_10_18  in_degree_1415  1
    arc_2_10_18  original_T_including_depot_unload_1429  6.6929586395597710e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_18  arc_capacity_1137  1
    load_2_10_18  segment_load_conservation_1368  1
    load_2_10_18  free_load_conservation_1419  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_19  arc_capacity_1139  -30
    arc_2_10_19  connected_order_arc_1140  -13
    arc_2_10_19  out_degree_1364  1
    arc_2_10_19  in_degree_1421  1
    arc_2_10_19  original_T_including_depot_unload_1429  1.0379751075251477e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_19  arc_capacity_1139  1
    load_2_10_19  segment_load_conservation_1368  1
    load_2_10_19  free_load_conservation_1425  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_0  arc_capacity_1141  -30
    arc_2_11_0  depot_return_or_bypass_1349  1
    arc_2_11_0  out_degree_1371  1
    arc_2_11_0  original_T_including_depot_unload_1429  1.6069967237772416e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_0  arc_capacity_1141  1
    load_2_11_0  segment_load_conservation_1375  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_8  arc_capacity_1142  -30
    arc_2_11_8  connected_order_arc_1143  -13
    arc_2_11_8  in_degree_1351  1
    arc_2_11_8  out_degree_1371  1
    arc_2_11_8  original_T_including_depot_unload_1429  9.1391556399578985e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_8  arc_capacity_1142  1
    load_2_11_8  segment_load_conservation_1354  -1
    load_2_11_8  segment_prefix_lb_1355  1
    load_2_11_8  segment_prefix_ub_1356  1
    load_2_11_8  segment_load_conservation_1375  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_9  arc_capacity_1144  -30
    arc_2_11_9  connected_order_arc_1145  -13
    arc_2_11_9  in_degree_1358  1
    arc_2_11_9  out_degree_1371  1
    arc_2_11_9  original_T_including_depot_unload_1429  1.1316960564588237e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_9  arc_capacity_1144  1
    load_2_11_9  segment_load_conservation_1361  -1
    load_2_11_9  segment_prefix_lb_1362  1
    load_2_11_9  segment_prefix_ub_1363  1
    load_2_11_9  segment_load_conservation_1375  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_10  arc_capacity_1146  -30
    arc_2_11_10  connected_order_arc_1147  -13
    arc_2_11_10  in_degree_1365  1
    arc_2_11_10  out_degree_1371  1
    arc_2_11_10  original_T_including_depot_unload_1429  9.0957857101308207e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_10  arc_capacity_1146  1
    load_2_11_10  segment_load_conservation_1368  -1
    load_2_11_10  segment_prefix_lb_1369  1
    load_2_11_10  segment_prefix_ub_1370  1
    load_2_11_10  segment_load_conservation_1375  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_12  arc_capacity_1148  -30
    arc_2_11_12  connected_order_arc_1149  -13
    arc_2_11_12  out_degree_1371  1
    arc_2_11_12  in_degree_1379  1
    arc_2_11_12  original_T_including_depot_unload_1429  1.2074299340828302e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_12  arc_capacity_1148  1
    load_2_11_12  segment_load_conservation_1375  1
    load_2_11_12  free_load_conservation_1383  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_13  arc_capacity_1150  -30
    arc_2_11_13  connected_order_arc_1151  -13
    arc_2_11_13  out_degree_1371  1
    arc_2_11_13  in_degree_1385  1
    arc_2_11_13  original_T_including_depot_unload_1429  6.3445700791412116e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_13  arc_capacity_1150  1
    load_2_11_13  segment_load_conservation_1375  1
    load_2_11_13  free_load_conservation_1389  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_14  arc_capacity_1152  -30
    arc_2_11_14  connected_order_arc_1153  -13
    arc_2_11_14  out_degree_1371  1
    arc_2_11_14  in_degree_1391  1
    arc_2_11_14  original_T_including_depot_unload_1429  1.4212384771615427e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_14  arc_capacity_1152  1
    load_2_11_14  segment_load_conservation_1375  1
    load_2_11_14  free_load_conservation_1395  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_15  arc_capacity_1154  -30
    arc_2_11_15  connected_order_arc_1155  -13
    arc_2_11_15  out_degree_1371  1
    arc_2_11_15  in_degree_1397  1
    arc_2_11_15  original_T_including_depot_unload_1429  6.0589769933602372e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_15  arc_capacity_1154  1
    load_2_11_15  segment_load_conservation_1375  1
    load_2_11_15  free_load_conservation_1401  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_16  arc_capacity_1156  -30
    arc_2_11_16  connected_order_arc_1157  -13
    arc_2_11_16  out_degree_1371  1
    arc_2_11_16  in_degree_1403  1
    arc_2_11_16  original_T_including_depot_unload_1429  6.0446933365872087e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_16  arc_capacity_1156  1
    load_2_11_16  segment_load_conservation_1375  1
    load_2_11_16  free_load_conservation_1407  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_17  arc_capacity_1158  -30
    arc_2_11_17  connected_order_arc_1159  -13
    arc_2_11_17  out_degree_1371  1
    arc_2_11_17  in_degree_1409  1
    arc_2_11_17  original_T_including_depot_unload_1429  1.7203273996041773e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_17  arc_capacity_1158  1
    load_2_11_17  segment_load_conservation_1375  1
    load_2_11_17  free_load_conservation_1413  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_18  arc_capacity_1160  -30
    arc_2_11_18  connected_order_arc_1161  -13
    arc_2_11_18  out_degree_1371  1
    arc_2_11_18  in_degree_1415  1
    arc_2_11_18  original_T_including_depot_unload_1429  1.3514640973487160e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_18  arc_capacity_1160  1
    load_2_11_18  segment_load_conservation_1375  1
    load_2_11_18  free_load_conservation_1419  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_19  arc_capacity_1162  -30
    arc_2_11_19  connected_order_arc_1163  -13
    arc_2_11_19  out_degree_1371  1
    arc_2_11_19  in_degree_1421  1
    arc_2_11_19  original_T_including_depot_unload_1429  1.1779667765163995e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_19  arc_capacity_1162  1
    load_2_11_19  segment_load_conservation_1375  1
    load_2_11_19  free_load_conservation_1425  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_0  arc_capacity_1164  -30
    arc_2_12_0  depot_return_or_bypass_1349  1
    arc_2_12_0  out_degree_1378  1
    arc_2_12_0  original_T_including_depot_unload_1429  1.1935953747864173e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_0  arc_capacity_1164  1
    load_2_12_0  free_load_conservation_1383  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_8  arc_capacity_1165  -30
    arc_2_12_8  connected_order_arc_1166  -13
    arc_2_12_8  in_degree_1351  1
    arc_2_12_8  out_degree_1378  1
    arc_2_12_8  original_T_including_depot_unload_1429  1.1851786693030479e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_8  arc_capacity_1165  1
    load_2_12_8  segment_load_conservation_1354  -1
    load_2_12_8  segment_prefix_lb_1355  1
    load_2_12_8  segment_prefix_ub_1356  1
    load_2_12_8  free_load_conservation_1383  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_9  arc_capacity_1167  -30
    arc_2_12_9  connected_order_arc_1168  -13
    arc_2_12_9  in_degree_1358  1
    arc_2_12_9  out_degree_1378  1
    arc_2_12_9  original_T_including_depot_unload_1429  1.8930659731251087e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_9  arc_capacity_1167  1
    load_2_12_9  segment_load_conservation_1361  -1
    load_2_12_9  segment_prefix_lb_1362  1
    load_2_12_9  segment_prefix_ub_1363  1
    load_2_12_9  free_load_conservation_1383  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_10  arc_capacity_1169  -30
    arc_2_12_10  connected_order_arc_1170  -13
    arc_2_12_10  in_degree_1365  1
    arc_2_12_10  out_degree_1378  1
    arc_2_12_10  original_T_including_depot_unload_1429  1.7341837931716675e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_10  arc_capacity_1169  1
    load_2_12_10  segment_load_conservation_1368  -1
    load_2_12_10  segment_prefix_lb_1369  1
    load_2_12_10  segment_prefix_ub_1370  1
    load_2_12_10  free_load_conservation_1383  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_11  arc_capacity_1171  -30
    arc_2_12_11  connected_order_arc_1172  -13
    arc_2_12_11  in_degree_1372  1
    arc_2_12_11  out_degree_1378  1
    arc_2_12_11  original_T_including_depot_unload_1429  1.3212871536432347e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_11  arc_capacity_1171  1
    load_2_12_11  segment_load_conservation_1375  -1
    load_2_12_11  segment_prefix_lb_1376  1
    load_2_12_11  segment_prefix_ub_1377  1
    load_2_12_11  free_load_conservation_1383  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_13  arc_capacity_1173  -30
    arc_2_12_13  connected_order_arc_1174  -13
    arc_2_12_13  out_degree_1378  1
    arc_2_12_13  in_degree_1385  1
    arc_2_12_13  original_T_including_depot_unload_1429  7.8744552571478073e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_13  arc_capacity_1173  1
    load_2_12_13  free_load_conservation_1383  1
    load_2_12_13  free_load_conservation_1389  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_14  arc_capacity_1175  -30
    arc_2_12_14  connected_order_arc_1176  -13
    arc_2_12_14  out_degree_1378  1
    arc_2_12_14  in_degree_1391  1
    arc_2_12_14  original_T_including_depot_unload_1429  2.1501600514850211e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_14  arc_capacity_1175  1
    load_2_12_14  free_load_conservation_1383  1
    load_2_12_14  free_load_conservation_1395  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_15  arc_capacity_1177  -30
    arc_2_12_15  connected_order_arc_1178  -13
    arc_2_12_15  out_degree_1378  1
    arc_2_12_15  in_degree_1397  1
    arc_2_12_15  original_T_including_depot_unload_1429  9.7357850164388731e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_15  arc_capacity_1177  1
    load_2_12_15  free_load_conservation_1383  1
    load_2_12_15  free_load_conservation_1401  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_16  arc_capacity_1179  -30
    arc_2_12_16  connected_order_arc_1180  -13
    arc_2_12_16  out_degree_1378  1
    arc_2_12_16  in_degree_1403  1
    arc_2_12_16  original_T_including_depot_unload_1429  9.7453518552189382e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_16  arc_capacity_1179  1
    load_2_12_16  free_load_conservation_1383  1
    load_2_12_16  free_load_conservation_1407  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_17  arc_capacity_1181  -30
    arc_2_12_17  connected_order_arc_1182  -13
    arc_2_12_17  out_degree_1378  1
    arc_2_12_17  in_degree_1409  1
    arc_2_12_17  original_T_including_depot_unload_1429  1.0313568965059917e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_17  arc_capacity_1181  1
    load_2_12_17  free_load_conservation_1383  1
    load_2_12_17  free_load_conservation_1413  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_18  arc_capacity_1183  -30
    arc_2_12_18  connected_order_arc_1184  -13
    arc_2_12_18  out_degree_1378  1
    arc_2_12_18  in_degree_1415  1
    arc_2_12_18  original_T_including_depot_unload_1429  1.6988291947636669e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_18  arc_capacity_1183  1
    load_2_12_18  free_load_conservation_1383  1
    load_2_12_18  free_load_conservation_1419  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_19  arc_capacity_1185  -30
    arc_2_12_19  connected_order_arc_1186  -13
    arc_2_12_19  out_degree_1378  1
    arc_2_12_19  in_degree_1421  1
    arc_2_12_19  original_T_including_depot_unload_1429  1.0321140782598593e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_19  arc_capacity_1185  1
    load_2_12_19  free_load_conservation_1383  1
    load_2_12_19  free_load_conservation_1425  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_0  arc_capacity_1187  -30
    arc_2_13_0  depot_return_or_bypass_1349  1
    arc_2_13_0  out_degree_1384  1
    arc_2_13_0  original_T_including_depot_unload_1429  1.6602888921784454e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_0  arc_capacity_1187  1
    load_2_13_0  free_load_conservation_1389  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_8  arc_capacity_1188  -30
    arc_2_13_8  connected_order_arc_1189  -13
    arc_2_13_8  in_degree_1351  1
    arc_2_13_8  out_degree_1384  1
    arc_2_13_8  original_T_including_depot_unload_1429  1.2177809159572148e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_8  arc_capacity_1188  1
    load_2_13_8  segment_load_conservation_1354  -1
    load_2_13_8  segment_prefix_lb_1355  1
    load_2_13_8  segment_prefix_ub_1356  1
    load_2_13_8  free_load_conservation_1389  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_9  arc_capacity_1190  -30
    arc_2_13_9  connected_order_arc_1191  -13
    arc_2_13_9  in_degree_1358  1
    arc_2_13_9  out_degree_1384  1
    arc_2_13_9  original_T_including_depot_unload_1429  1.6865464326628071e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_9  arc_capacity_1190  1
    load_2_13_9  segment_load_conservation_1361  -1
    load_2_13_9  segment_prefix_lb_1362  1
    load_2_13_9  segment_prefix_ub_1363  1
    load_2_13_9  free_load_conservation_1389  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_10  arc_capacity_1192  -30
    arc_2_13_10  connected_order_arc_1193  -13
    arc_2_13_10  in_degree_1365  1
    arc_2_13_10  out_degree_1384  1
    arc_2_13_10  original_T_including_depot_unload_1429  1.4754486297628157e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_10  arc_capacity_1192  1
    load_2_13_10  segment_load_conservation_1368  -1
    load_2_13_10  segment_prefix_lb_1369  1
    load_2_13_10  segment_prefix_ub_1370  1
    load_2_13_10  free_load_conservation_1389  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_11  arc_capacity_1194  -30
    arc_2_13_11  connected_order_arc_1195  -13
    arc_2_13_11  in_degree_1372  1
    arc_2_13_11  out_degree_1384  1
    arc_2_13_11  original_T_including_depot_unload_1429  8.9397647672367691e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_11  arc_capacity_1194  1
    load_2_13_11  segment_load_conservation_1375  -1
    load_2_13_11  segment_prefix_lb_1376  1
    load_2_13_11  segment_prefix_ub_1377  1
    load_2_13_11  free_load_conservation_1389  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_12  arc_capacity_1196  -30
    arc_2_13_12  connected_order_arc_1197  -13
    arc_2_13_12  in_degree_1379  1
    arc_2_13_12  out_degree_1384  1
    arc_2_13_12  original_T_including_depot_unload_1429  7.8744552571478073e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_12  arc_capacity_1196  1
    load_2_13_12  free_load_conservation_1383  -1
    load_2_13_12  free_load_conservation_1389  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_14  arc_capacity_1198  -30
    arc_2_13_14  connected_order_arc_1199  -13
    arc_2_13_14  out_degree_1384  1
    arc_2_13_14  in_degree_1391  1
    arc_2_13_14  original_T_including_depot_unload_1429  1.9767828664634856e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_14  arc_capacity_1198  1
    load_2_13_14  free_load_conservation_1389  1
    load_2_13_14  free_load_conservation_1395  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_15  arc_capacity_1200  -30
    arc_2_13_15  connected_order_arc_1201  -13
    arc_2_13_15  out_degree_1384  1
    arc_2_13_15  in_degree_1397  1
    arc_2_13_15  original_T_including_depot_unload_1429  8.7049015369085737e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_15  arc_capacity_1200  1
    load_2_13_15  free_load_conservation_1389  1
    load_2_13_15  free_load_conservation_1401  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_16  arc_capacity_1202  -30
    arc_2_13_16  connected_order_arc_1203  -13
    arc_2_13_16  out_degree_1384  1
    arc_2_13_16  in_degree_1403  1
    arc_2_13_16  original_T_including_depot_unload_1429  8.7008776944597639e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_16  arc_capacity_1202  1
    load_2_13_16  free_load_conservation_1389  1
    load_2_13_16  free_load_conservation_1407  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_17  arc_capacity_1204  -30
    arc_2_13_17  connected_order_arc_1205  -13
    arc_2_13_17  out_degree_1384  1
    arc_2_13_17  in_degree_1409  1
    arc_2_13_17  original_T_including_depot_unload_1429  1.6406378986588031e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_17  arc_capacity_1204  1
    load_2_13_17  free_load_conservation_1389  1
    load_2_13_17  free_load_conservation_1413  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_18  arc_capacity_1206  -30
    arc_2_13_18  connected_order_arc_1207  -13
    arc_2_13_18  out_degree_1384  1
    arc_2_13_18  in_degree_1415  1
    arc_2_13_18  original_T_including_depot_unload_1429  1.7489191280566063e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_18  arc_capacity_1206  1
    load_2_13_18  free_load_conservation_1389  1
    load_2_13_18  free_load_conservation_1419  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_19  arc_capacity_1208  -30
    arc_2_13_19  connected_order_arc_1209  -13
    arc_2_13_19  out_degree_1384  1
    arc_2_13_19  in_degree_1421  1
    arc_2_13_19  original_T_including_depot_unload_1429  1.3104307696104611e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_19  arc_capacity_1208  1
    load_2_13_19  free_load_conservation_1389  1
    load_2_13_19  free_load_conservation_1425  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_0  arc_capacity_1210  -30
    arc_2_14_0  depot_return_or_bypass_1349  1
    arc_2_14_0  out_degree_1390  1
    arc_2_14_0  original_T_including_depot_unload_1429  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_0  arc_capacity_1210  1
    load_2_14_0  free_load_conservation_1395  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_8  arc_capacity_1211  -30
    arc_2_14_8  connected_order_arc_1212  -13
    arc_2_14_8  in_degree_1351  1
    arc_2_14_8  out_degree_1390  1
    arc_2_14_8  original_T_including_depot_unload_1429  9.8108674361469946e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_8  arc_capacity_1211  1
    load_2_14_8  segment_load_conservation_1354  -1
    load_2_14_8  segment_prefix_lb_1355  1
    load_2_14_8  segment_prefix_ub_1356  1
    load_2_14_8  free_load_conservation_1395  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_9  arc_capacity_1213  -30
    arc_2_14_9  connected_order_arc_1214  -13
    arc_2_14_9  in_degree_1358  1
    arc_2_14_9  out_degree_1390  1
    arc_2_14_9  original_T_including_depot_unload_1429  2.9139628504456829e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_9  arc_capacity_1213  1
    load_2_14_9  segment_load_conservation_1361  -1
    load_2_14_9  segment_prefix_lb_1362  1
    load_2_14_9  segment_prefix_ub_1363  1
    load_2_14_9  free_load_conservation_1395  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_10  arc_capacity_1215  -30
    arc_2_14_10  connected_order_arc_1216  -13
    arc_2_14_10  in_degree_1365  1
    arc_2_14_10  out_degree_1390  1
    arc_2_14_10  original_T_including_depot_unload_1429  5.1169459347980438e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_10  arc_capacity_1215  1
    load_2_14_10  segment_load_conservation_1368  -1
    load_2_14_10  segment_prefix_lb_1369  1
    load_2_14_10  segment_prefix_ub_1370  1
    load_2_14_10  free_load_conservation_1395  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_11  arc_capacity_1217  -30
    arc_2_14_11  connected_order_arc_1218  -13
    arc_2_14_11  in_degree_1372  1
    arc_2_14_11  out_degree_1390  1
    arc_2_14_11  original_T_including_depot_unload_1429  1.1159421068673551e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_11  arc_capacity_1217  1
    load_2_14_11  segment_load_conservation_1375  -1
    load_2_14_11  segment_prefix_lb_1376  1
    load_2_14_11  segment_prefix_ub_1377  1
    load_2_14_11  free_load_conservation_1395  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_12  arc_capacity_1219  -30
    arc_2_14_12  connected_order_arc_1220  -13
    arc_2_14_12  in_degree_1379  1
    arc_2_14_12  out_degree_1390  1
    arc_2_14_12  original_T_including_depot_unload_1429  2.1501600514850211e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_12  arc_capacity_1219  1
    load_2_14_12  free_load_conservation_1383  -1
    load_2_14_12  free_load_conservation_1395  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_13  arc_capacity_1221  -30
    arc_2_14_13  connected_order_arc_1222  -13
    arc_2_14_13  in_degree_1385  1
    arc_2_14_13  out_degree_1390  1
    arc_2_14_13  original_T_including_depot_unload_1429  1.9767828664634856e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_13  arc_capacity_1221  1
    load_2_14_13  free_load_conservation_1389  -1
    load_2_14_13  free_load_conservation_1395  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_15  arc_capacity_1223  -30
    arc_2_14_15  connected_order_arc_1224  -13
    arc_2_14_15  out_degree_1390  1
    arc_2_14_15  in_degree_1397  1
    arc_2_14_15  original_T_including_depot_unload_1429  1.1967280409234234e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_15  arc_capacity_1223  1
    load_2_14_15  free_load_conservation_1395  1
    load_2_14_15  free_load_conservation_1401  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_16  arc_capacity_1225  -30
    arc_2_14_16  connected_order_arc_1226  -13
    arc_2_14_16  out_degree_1390  1
    arc_2_14_16  in_degree_1403  1
    arc_2_14_16  original_T_including_depot_unload_1429  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_16  arc_capacity_1225  1
    load_2_14_16  free_load_conservation_1395  1
    load_2_14_16  free_load_conservation_1407  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_17  arc_capacity_1227  -30
    arc_2_14_17  connected_order_arc_1228  -13
    arc_2_14_17  out_degree_1390  1
    arc_2_14_17  in_degree_1409  1
    arc_2_14_17  original_T_including_depot_unload_1429  1.8911324761641883e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_17  arc_capacity_1227  1
    load_2_14_17  free_load_conservation_1395  1
    load_2_14_17  free_load_conservation_1413  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_18  arc_capacity_1229  -30
    arc_2_14_18  connected_order_arc_1230  -13
    arc_2_14_18  out_degree_1390  1
    arc_2_14_18  in_degree_1415  1
    arc_2_14_18  original_T_including_depot_unload_1429  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_2_14_18  arc_capacity_1229  1
    load_2_14_18  free_load_conservation_1395  1
    load_2_14_18  free_load_conservation_1419  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_19  arc_capacity_1231  -30
    arc_2_14_19  connected_order_arc_1232  -13
    arc_2_14_19  out_degree_1390  1
    arc_2_14_19  in_degree_1421  1
    arc_2_14_19  original_T_including_depot_unload_1429  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_19  arc_capacity_1231  1
    load_2_14_19  free_load_conservation_1395  1
    load_2_14_19  free_load_conservation_1425  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_0  arc_capacity_1233  -30
    arc_2_15_0  depot_return_or_bypass_1349  1
    arc_2_15_0  out_degree_1396  1
    arc_2_15_0  original_T_including_depot_unload_1429  1.0056399980521732e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_0  arc_capacity_1233  1
    load_2_15_0  free_load_conservation_1401  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_8  arc_capacity_1234  -30
    arc_2_15_8  connected_order_arc_1235  -13
    arc_2_15_8  in_degree_1351  1
    arc_2_15_8  out_degree_1396  1
    arc_2_15_8  original_T_including_depot_unload_1429  3.5166546157461704e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_8  arc_capacity_1234  1
    load_2_15_8  segment_load_conservation_1354  -1
    load_2_15_8  segment_prefix_lb_1355  1
    load_2_15_8  segment_prefix_ub_1356  1
    load_2_15_8  free_load_conservation_1401  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_9  arc_capacity_1236  -30
    arc_2_15_9  connected_order_arc_1237  -13
    arc_2_15_9  in_degree_1358  1
    arc_2_15_9  out_degree_1396  1
    arc_2_15_9  original_T_including_depot_unload_1429  926.407625506948
    MARKER    'MARKER'                 'INTEND'
    load_2_15_9  arc_capacity_1236  1
    load_2_15_9  segment_load_conservation_1361  -1
    load_2_15_9  segment_prefix_lb_1362  1
    load_2_15_9  segment_prefix_ub_1363  1
    load_2_15_9  free_load_conservation_1401  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_10  arc_capacity_1238  -30
    arc_2_15_10  connected_order_arc_1239  -13
    arc_2_15_10  in_degree_1365  1
    arc_2_15_10  out_degree_1396  1
    arc_2_15_10  original_T_including_depot_unload_1429  7.6061661180217550e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_10  arc_capacity_1238  1
    load_2_15_10  segment_load_conservation_1368  -1
    load_2_15_10  segment_prefix_lb_1369  1
    load_2_15_10  segment_prefix_ub_1370  1
    load_2_15_10  free_load_conservation_1401  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_11  arc_capacity_1240  -30
    arc_2_15_11  connected_order_arc_1241  -13
    arc_2_15_11  in_degree_1372  1
    arc_2_15_11  out_degree_1396  1
    arc_2_15_11  original_T_including_depot_unload_1429  4.8227670112102692e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_11  arc_capacity_1240  1
    load_2_15_11  segment_load_conservation_1375  -1
    load_2_15_11  segment_prefix_lb_1376  1
    load_2_15_11  segment_prefix_ub_1377  1
    load_2_15_11  free_load_conservation_1401  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_12  arc_capacity_1242  -30
    arc_2_15_12  connected_order_arc_1243  -13
    arc_2_15_12  in_degree_1379  1
    arc_2_15_12  out_degree_1396  1
    arc_2_15_12  original_T_including_depot_unload_1429  9.7357850164388731e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_12  arc_capacity_1242  1
    load_2_15_12  free_load_conservation_1383  -1
    load_2_15_12  free_load_conservation_1401  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_13  arc_capacity_1244  -30
    arc_2_15_13  connected_order_arc_1245  -13
    arc_2_15_13  in_degree_1385  1
    arc_2_15_13  out_degree_1396  1
    arc_2_15_13  original_T_including_depot_unload_1429  8.7049015369085737e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_13  arc_capacity_1244  1
    load_2_15_13  free_load_conservation_1389  -1
    load_2_15_13  free_load_conservation_1401  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_14  arc_capacity_1246  -30
    arc_2_15_14  connected_order_arc_1247  -13
    arc_2_15_14  in_degree_1391  1
    arc_2_15_14  out_degree_1396  1
    arc_2_15_14  original_T_including_depot_unload_1429  1.1967280409234234e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_14  arc_capacity_1246  1
    load_2_15_14  free_load_conservation_1395  -1
    load_2_15_14  free_load_conservation_1401  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_16  arc_capacity_1248  -30
    arc_2_15_16  connected_order_arc_1249  -13
    arc_2_15_16  out_degree_1396  1
    arc_2_15_16  in_degree_1403  1
    arc_2_15_16  original_T_including_depot_unload_1429  1.6320002720932780e+00
    MARKER    'MARKER'                 'INTEND'
    load_2_15_16  arc_capacity_1248  1
    load_2_15_16  free_load_conservation_1401  1
    load_2_15_16  free_load_conservation_1407  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_17  arc_capacity_1250  -30
    arc_2_15_17  connected_order_arc_1251  -13
    arc_2_15_17  out_degree_1396  1
    arc_2_15_17  in_degree_1409  1
    arc_2_15_17  original_T_including_depot_unload_1429  1.1545648513745866e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_17  arc_capacity_1250  1
    load_2_15_17  free_load_conservation_1401  1
    load_2_15_17  free_load_conservation_1413  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_18  arc_capacity_1252  -30
    arc_2_15_18  connected_order_arc_1253  -13
    arc_2_15_18  out_degree_1396  1
    arc_2_15_18  in_degree_1415  1
    arc_2_15_18  original_T_including_depot_unload_1429  8.7906342149593650e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_18  arc_capacity_1252  1
    load_2_15_18  free_load_conservation_1401  1
    load_2_15_18  free_load_conservation_1419  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_19  arc_capacity_1254  -30
    arc_2_15_19  connected_order_arc_1255  -13
    arc_2_15_19  out_degree_1396  1
    arc_2_15_19  in_degree_1421  1
    arc_2_15_19  original_T_including_depot_unload_1429  5.7276146581216926e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_19  arc_capacity_1254  1
    load_2_15_19  free_load_conservation_1401  1
    load_2_15_19  free_load_conservation_1425  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_0  arc_capacity_1256  -30
    arc_2_16_0  depot_return_or_bypass_1349  1
    arc_2_16_0  out_degree_1402  1
    arc_2_16_0  original_T_including_depot_unload_1429  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_0  arc_capacity_1256  1
    load_2_16_0  free_load_conservation_1407  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_8  arc_capacity_1257  -30
    arc_2_16_8  connected_order_arc_1258  -13
    arc_2_16_8  in_degree_1351  1
    arc_2_16_8  out_degree_1402  1
    arc_2_16_8  original_T_including_depot_unload_1429  3.5235932354279930e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_8  arc_capacity_1257  1
    load_2_16_8  segment_load_conservation_1354  -1
    load_2_16_8  segment_prefix_lb_1355  1
    load_2_16_8  segment_prefix_ub_1356  1
    load_2_16_8  free_load_conservation_1407  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_9  arc_capacity_1259  -30
    arc_2_16_9  connected_order_arc_1260  -13
    arc_2_16_9  in_degree_1358  1
    arc_2_16_9  out_degree_1402  1
    arc_2_16_9  original_T_including_depot_unload_1429  925.691754925099
    MARKER    'MARKER'                 'INTEND'
    load_2_16_9  arc_capacity_1259  1
    load_2_16_9  segment_load_conservation_1361  -1
    load_2_16_9  segment_prefix_lb_1362  1
    load_2_16_9  segment_prefix_ub_1363  1
    load_2_16_9  free_load_conservation_1407  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_10  arc_capacity_1261  -30
    arc_2_16_10  connected_order_arc_1262  -13
    arc_2_16_10  in_degree_1365  1
    arc_2_16_10  out_degree_1402  1
    arc_2_16_10  original_T_including_depot_unload_1429  7.5965235847304257e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_10  arc_capacity_1261  1
    load_2_16_10  segment_load_conservation_1368  -1
    load_2_16_10  segment_prefix_lb_1369  1
    load_2_16_10  segment_prefix_ub_1370  1
    load_2_16_10  free_load_conservation_1407  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_11  arc_capacity_1263  -30
    arc_2_16_11  connected_order_arc_1264  -13
    arc_2_16_11  in_degree_1372  1
    arc_2_16_11  out_degree_1402  1
    arc_2_16_11  original_T_including_depot_unload_1429  4.8064504037614694e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_11  arc_capacity_1263  1
    load_2_16_11  segment_load_conservation_1375  -1
    load_2_16_11  segment_prefix_lb_1376  1
    load_2_16_11  segment_prefix_ub_1377  1
    load_2_16_11  free_load_conservation_1407  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_12  arc_capacity_1265  -30
    arc_2_16_12  connected_order_arc_1266  -13
    arc_2_16_12  in_degree_1379  1
    arc_2_16_12  out_degree_1402  1
    arc_2_16_12  original_T_including_depot_unload_1429  9.7453518552189382e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_12  arc_capacity_1265  1
    load_2_16_12  free_load_conservation_1383  -1
    load_2_16_12  free_load_conservation_1407  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_13  arc_capacity_1267  -30
    arc_2_16_13  connected_order_arc_1268  -13
    arc_2_16_13  in_degree_1385  1
    arc_2_16_13  out_degree_1402  1
    arc_2_16_13  original_T_including_depot_unload_1429  8.7008776944597639e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_13  arc_capacity_1267  1
    load_2_16_13  free_load_conservation_1389  -1
    load_2_16_13  free_load_conservation_1407  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_14  arc_capacity_1269  -30
    arc_2_16_14  connected_order_arc_1270  -13
    arc_2_16_14  in_degree_1391  1
    arc_2_16_14  out_degree_1402  1
    arc_2_16_14  original_T_including_depot_unload_1429  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_14  arc_capacity_1269  1
    load_2_16_14  free_load_conservation_1395  -1
    load_2_16_14  free_load_conservation_1407  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_15  arc_capacity_1271  -30
    arc_2_16_15  connected_order_arc_1272  -13
    arc_2_16_15  in_degree_1397  1
    arc_2_16_15  out_degree_1402  1
    arc_2_16_15  original_T_including_depot_unload_1429  1.6320002720932780e+00
    MARKER    'MARKER'                 'INTEND'
    load_2_16_15  arc_capacity_1271  1
    load_2_16_15  free_load_conservation_1401  -1
    load_2_16_15  free_load_conservation_1407  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_17  arc_capacity_1273  -30
    arc_2_16_17  connected_order_arc_1274  -13
    arc_2_16_17  out_degree_1402  1
    arc_2_16_17  in_degree_1409  1
    arc_2_16_17  original_T_including_depot_unload_1429  1.1561945146971345e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_17  arc_capacity_1273  1
    load_2_16_17  free_load_conservation_1407  1
    load_2_16_17  free_load_conservation_1413  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_18  arc_capacity_1275  -30
    arc_2_16_18  connected_order_arc_1276  -13
    arc_2_16_18  out_degree_1402  1
    arc_2_16_18  in_degree_1415  1
    arc_2_16_18  original_T_including_depot_unload_1429  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_18  arc_capacity_1275  1
    load_2_16_18  free_load_conservation_1407  1
    load_2_16_18  free_load_conservation_1419  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_19  arc_capacity_1277  -30
    arc_2_16_19  connected_order_arc_1278  -13
    arc_2_16_19  out_degree_1402  1
    arc_2_16_19  in_degree_1421  1
    arc_2_16_19  original_T_including_depot_unload_1429  5.7424143497696048e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_19  arc_capacity_1277  1
    load_2_16_19  free_load_conservation_1407  1
    load_2_16_19  free_load_conservation_1425  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_0  arc_capacity_1279  -30
    arc_2_17_0  depot_return_or_bypass_1349  1
    arc_2_17_0  out_degree_1408  1
    arc_2_17_0  original_T_including_depot_unload_1429  3.5061909388980052e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_0  arc_capacity_1279  1
    load_2_17_0  free_load_conservation_1413  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_8  arc_capacity_1280  -30
    arc_2_17_8  connected_order_arc_1281  -13
    arc_2_17_8  in_degree_1351  1
    arc_2_17_8  out_degree_1408  1
    arc_2_17_8  original_T_including_depot_unload_1429  1.0363838262442744e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_8  arc_capacity_1280  1
    load_2_17_8  segment_load_conservation_1354  -1
    load_2_17_8  segment_prefix_lb_1355  1
    load_2_17_8  segment_prefix_ub_1356  1
    load_2_17_8  free_load_conservation_1413  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_9  arc_capacity_1282  -30
    arc_2_17_9  connected_order_arc_1283  -13
    arc_2_17_9  in_degree_1358  1
    arc_2_17_9  out_degree_1408  1
    arc_2_17_9  original_T_including_depot_unload_1429  1.7397988912348303e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_9  arc_capacity_1282  1
    load_2_17_9  segment_load_conservation_1361  -1
    load_2_17_9  segment_prefix_lb_1362  1
    load_2_17_9  segment_prefix_ub_1363  1
    load_2_17_9  free_load_conservation_1413  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_10  arc_capacity_1284  -30
    arc_2_17_10  connected_order_arc_1285  -13
    arc_2_17_10  in_degree_1365  1
    arc_2_17_10  out_degree_1408  1
    arc_2_17_10  original_T_including_depot_unload_1429  1.6950562242445128e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_10  arc_capacity_1284  1
    load_2_17_10  segment_load_conservation_1368  -1
    load_2_17_10  segment_prefix_lb_1369  1
    load_2_17_10  segment_prefix_ub_1370  1
    load_2_17_10  free_load_conservation_1413  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_11  arc_capacity_1286  -30
    arc_2_17_11  connected_order_arc_1287  -13
    arc_2_17_11  in_degree_1372  1
    arc_2_17_11  out_degree_1408  1
    arc_2_17_11  original_T_including_depot_unload_1429  1.6359122202972637e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_11  arc_capacity_1286  1
    load_2_17_11  segment_load_conservation_1375  -1
    load_2_17_11  segment_prefix_lb_1376  1
    load_2_17_11  segment_prefix_ub_1377  1
    load_2_17_11  free_load_conservation_1413  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_12  arc_capacity_1288  -30
    arc_2_17_12  connected_order_arc_1289  -13
    arc_2_17_12  in_degree_1379  1
    arc_2_17_12  out_degree_1408  1
    arc_2_17_12  original_T_including_depot_unload_1429  1.0313568965059917e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_12  arc_capacity_1288  1
    load_2_17_12  free_load_conservation_1383  -1
    load_2_17_12  free_load_conservation_1413  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_13  arc_capacity_1290  -30
    arc_2_17_13  connected_order_arc_1291  -13
    arc_2_17_13  in_degree_1385  1
    arc_2_17_13  out_degree_1408  1
    arc_2_17_13  original_T_including_depot_unload_1429  1.6406378986588031e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_13  arc_capacity_1290  1
    load_2_17_13  free_load_conservation_1389  -1
    load_2_17_13  free_load_conservation_1413  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_14  arc_capacity_1292  -30
    arc_2_17_14  connected_order_arc_1293  -13
    arc_2_17_14  in_degree_1391  1
    arc_2_17_14  out_degree_1408  1
    arc_2_17_14  original_T_including_depot_unload_1429  1.8911324761641883e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_14  arc_capacity_1292  1
    load_2_17_14  free_load_conservation_1395  -1
    load_2_17_14  free_load_conservation_1413  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_15  arc_capacity_1294  -30
    arc_2_17_15  connected_order_arc_1295  -13
    arc_2_17_15  in_degree_1397  1
    arc_2_17_15  out_degree_1408  1
    arc_2_17_15  original_T_including_depot_unload_1429  1.1545648513745866e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_15  arc_capacity_1294  1
    load_2_17_15  free_load_conservation_1401  -1
    load_2_17_15  free_load_conservation_1413  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_16  arc_capacity_1296  -30
    arc_2_17_16  connected_order_arc_1297  -13
    arc_2_17_16  in_degree_1403  1
    arc_2_17_16  out_degree_1408  1
    arc_2_17_16  original_T_including_depot_unload_1429  1.1561945146971345e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_16  arc_capacity_1296  1
    load_2_17_16  free_load_conservation_1407  -1
    load_2_17_16  free_load_conservation_1413  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_18  arc_capacity_1298  -30
    arc_2_17_18  connected_order_arc_1299  -13
    arc_2_17_18  out_degree_1408  1
    arc_2_17_18  in_degree_1415  1
    arc_2_17_18  original_T_including_depot_unload_1429  1.2665309635243570e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_18  arc_capacity_1298  1
    load_2_17_18  free_load_conservation_1413  1
    load_2_17_18  free_load_conservation_1419  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_19  arc_capacity_1300  -30
    arc_2_17_19  connected_order_arc_1301  -13
    arc_2_17_19  out_degree_1408  1
    arc_2_17_19  in_degree_1421  1
    arc_2_17_19  original_T_including_depot_unload_1429  6.5869285599668615e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_19  arc_capacity_1300  1
    load_2_17_19  free_load_conservation_1413  1
    load_2_17_19  free_load_conservation_1425  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_0  arc_capacity_1302  -30
    arc_2_18_0  depot_return_or_bypass_1349  1
    arc_2_18_0  out_degree_1414  1
    arc_2_18_0  original_T_including_depot_unload_1429  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_0  arc_capacity_1302  1
    load_2_18_0  free_load_conservation_1419  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_8  arc_capacity_1303  -30
    arc_2_18_8  connected_order_arc_1304  -13
    arc_2_18_8  in_degree_1351  1
    arc_2_18_8  out_degree_1414  1
    arc_2_18_8  original_T_including_depot_unload_1429  5.4405628017126674e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_8  arc_capacity_1303  1
    load_2_18_8  segment_load_conservation_1354  -1
    load_2_18_8  segment_prefix_lb_1355  1
    load_2_18_8  segment_prefix_ub_1356  1
    load_2_18_8  free_load_conservation_1419  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_9  arc_capacity_1305  -30
    arc_2_18_9  connected_order_arc_1306  -13
    arc_2_18_9  in_degree_1358  1
    arc_2_18_9  out_degree_1414  1
    arc_2_18_9  original_T_including_depot_unload_1429  5.7914586906741226e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_9  arc_capacity_1305  1
    load_2_18_9  segment_load_conservation_1361  -1
    load_2_18_9  segment_prefix_lb_1362  1
    load_2_18_9  segment_prefix_ub_1363  1
    load_2_18_9  free_load_conservation_1419  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_10  arc_capacity_1307  -30
    arc_2_18_10  connected_order_arc_1308  -13
    arc_2_18_10  in_degree_1365  1
    arc_2_18_10  out_degree_1414  1
    arc_2_18_10  original_T_including_depot_unload_1429  6.6929586395597710e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_10  arc_capacity_1307  1
    load_2_18_10  segment_load_conservation_1368  -1
    load_2_18_10  segment_prefix_lb_1369  1
    load_2_18_10  segment_prefix_ub_1370  1
    load_2_18_10  free_load_conservation_1419  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_11  arc_capacity_1309  -30
    arc_2_18_11  connected_order_arc_1310  -13
    arc_2_18_11  in_degree_1372  1
    arc_2_18_11  out_degree_1414  1
    arc_2_18_11  original_T_including_depot_unload_1429  1.0740788448852404e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_11  arc_capacity_1309  1
    load_2_18_11  segment_load_conservation_1375  -1
    load_2_18_11  segment_prefix_lb_1376  1
    load_2_18_11  segment_prefix_ub_1377  1
    load_2_18_11  free_load_conservation_1419  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_12  arc_capacity_1311  -30
    arc_2_18_12  connected_order_arc_1312  -13
    arc_2_18_12  in_degree_1379  1
    arc_2_18_12  out_degree_1414  1
    arc_2_18_12  original_T_including_depot_unload_1429  1.6988291947636669e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_12  arc_capacity_1311  1
    load_2_18_12  free_load_conservation_1383  -1
    load_2_18_12  free_load_conservation_1419  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_13  arc_capacity_1313  -30
    arc_2_18_13  connected_order_arc_1314  -13
    arc_2_18_13  in_degree_1385  1
    arc_2_18_13  out_degree_1414  1
    arc_2_18_13  original_T_including_depot_unload_1429  1.7489191280566063e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_13  arc_capacity_1313  1
    load_2_18_13  free_load_conservation_1389  -1
    load_2_18_13  free_load_conservation_1419  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_14  arc_capacity_1315  -30
    arc_2_18_14  connected_order_arc_1316  -13
    arc_2_18_14  in_degree_1391  1
    arc_2_18_14  out_degree_1414  1
    arc_2_18_14  original_T_including_depot_unload_1429  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_2_18_14  arc_capacity_1315  1
    load_2_18_14  free_load_conservation_1395  -1
    load_2_18_14  free_load_conservation_1419  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_15  arc_capacity_1317  -30
    arc_2_18_15  connected_order_arc_1318  -13
    arc_2_18_15  in_degree_1397  1
    arc_2_18_15  out_degree_1414  1
    arc_2_18_15  original_T_including_depot_unload_1429  8.7906342149593650e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_15  arc_capacity_1317  1
    load_2_18_15  free_load_conservation_1401  -1
    load_2_18_15  free_load_conservation_1419  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_16  arc_capacity_1319  -30
    arc_2_18_16  connected_order_arc_1320  -13
    arc_2_18_16  in_degree_1403  1
    arc_2_18_16  out_degree_1414  1
    arc_2_18_16  original_T_including_depot_unload_1429  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_16  arc_capacity_1319  1
    load_2_18_16  free_load_conservation_1407  -1
    load_2_18_16  free_load_conservation_1419  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_17  arc_capacity_1321  -30
    arc_2_18_17  connected_order_arc_1322  -13
    arc_2_18_17  in_degree_1409  1
    arc_2_18_17  out_degree_1414  1
    arc_2_18_17  original_T_including_depot_unload_1429  1.2665309635243570e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_17  arc_capacity_1321  1
    load_2_18_17  free_load_conservation_1413  -1
    load_2_18_17  free_load_conservation_1419  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_19  arc_capacity_1323  -30
    arc_2_18_19  connected_order_arc_1324  -13
    arc_2_18_19  out_degree_1414  1
    arc_2_18_19  in_degree_1421  1
    arc_2_18_19  original_T_including_depot_unload_1429  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_2_18_19  arc_capacity_1323  1
    load_2_18_19  free_load_conservation_1419  1
    load_2_18_19  free_load_conservation_1425  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_0  arc_capacity_1325  -30
    arc_2_19_0  depot_return_or_bypass_1349  1
    arc_2_19_0  out_degree_1420  1
    arc_2_19_0  original_T_including_depot_unload_1429  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_0  arc_capacity_1325  1
    load_2_19_0  free_load_conservation_1425  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_8  arc_capacity_1326  -30
    arc_2_19_8  connected_order_arc_1327  -13
    arc_2_19_8  in_degree_1351  1
    arc_2_19_8  out_degree_1420  1
    arc_2_19_8  original_T_including_depot_unload_1429  3.7831268047064754e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_8  arc_capacity_1326  1
    load_2_19_8  segment_load_conservation_1354  -1
    load_2_19_8  segment_prefix_lb_1355  1
    load_2_19_8  segment_prefix_ub_1356  1
    load_2_19_8  free_load_conservation_1425  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_9  arc_capacity_1328  -30
    arc_2_19_9  connected_order_arc_1329  -13
    arc_2_19_9  in_degree_1358  1
    arc_2_19_9  out_degree_1420  1
    arc_2_19_9  original_T_including_depot_unload_1429  1.0984912119828512e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_9  arc_capacity_1328  1
    load_2_19_9  segment_load_conservation_1361  -1
    load_2_19_9  segment_prefix_lb_1362  1
    load_2_19_9  segment_prefix_ub_1363  1
    load_2_19_9  free_load_conservation_1425  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_10  arc_capacity_1330  -30
    arc_2_19_10  connected_order_arc_1331  -13
    arc_2_19_10  in_degree_1365  1
    arc_2_19_10  out_degree_1420  1
    arc_2_19_10  original_T_including_depot_unload_1429  1.0379751075251477e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_10  arc_capacity_1330  1
    load_2_19_10  segment_load_conservation_1368  -1
    load_2_19_10  segment_prefix_lb_1369  1
    load_2_19_10  segment_prefix_ub_1370  1
    load_2_19_10  free_load_conservation_1425  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_11  arc_capacity_1332  -30
    arc_2_19_11  connected_order_arc_1333  -13
    arc_2_19_11  in_degree_1372  1
    arc_2_19_11  out_degree_1420  1
    arc_2_19_11  original_T_including_depot_unload_1429  1.0279345387929015e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_11  arc_capacity_1332  1
    load_2_19_11  segment_load_conservation_1375  -1
    load_2_19_11  segment_prefix_lb_1376  1
    load_2_19_11  segment_prefix_ub_1377  1
    load_2_19_11  free_load_conservation_1425  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_12  arc_capacity_1334  -30
    arc_2_19_12  connected_order_arc_1335  -13
    arc_2_19_12  in_degree_1379  1
    arc_2_19_12  out_degree_1420  1
    arc_2_19_12  original_T_including_depot_unload_1429  1.0321140782598593e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_12  arc_capacity_1334  1
    load_2_19_12  free_load_conservation_1383  -1
    load_2_19_12  free_load_conservation_1425  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_13  arc_capacity_1336  -30
    arc_2_19_13  connected_order_arc_1337  -13
    arc_2_19_13  in_degree_1385  1
    arc_2_19_13  out_degree_1420  1
    arc_2_19_13  original_T_including_depot_unload_1429  1.3104307696104611e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_13  arc_capacity_1336  1
    load_2_19_13  free_load_conservation_1389  -1
    load_2_19_13  free_load_conservation_1425  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_14  arc_capacity_1338  -30
    arc_2_19_14  connected_order_arc_1339  -13
    arc_2_19_14  in_degree_1391  1
    arc_2_19_14  out_degree_1420  1
    arc_2_19_14  original_T_including_depot_unload_1429  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_14  arc_capacity_1338  1
    load_2_19_14  free_load_conservation_1395  -1
    load_2_19_14  free_load_conservation_1425  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_15  arc_capacity_1340  -30
    arc_2_19_15  connected_order_arc_1341  -13
    arc_2_19_15  in_degree_1397  1
    arc_2_19_15  out_degree_1420  1
    arc_2_19_15  original_T_including_depot_unload_1429  5.7276146581216926e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_15  arc_capacity_1340  1
    load_2_19_15  free_load_conservation_1401  -1
    load_2_19_15  free_load_conservation_1425  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_16  arc_capacity_1342  -30
    arc_2_19_16  connected_order_arc_1343  -13
    arc_2_19_16  in_degree_1403  1
    arc_2_19_16  out_degree_1420  1
    arc_2_19_16  original_T_including_depot_unload_1429  5.7424143497696048e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_16  arc_capacity_1342  1
    load_2_19_16  free_load_conservation_1407  -1
    load_2_19_16  free_load_conservation_1425  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_17  arc_capacity_1344  -30
    arc_2_19_17  connected_order_arc_1345  -13
    arc_2_19_17  in_degree_1409  1
    arc_2_19_17  out_degree_1420  1
    arc_2_19_17  original_T_including_depot_unload_1429  6.5869285599668615e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_17  arc_capacity_1344  1
    load_2_19_17  free_load_conservation_1413  -1
    load_2_19_17  free_load_conservation_1425  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_18  arc_capacity_1346  -30
    arc_2_19_18  connected_order_arc_1347  -13
    arc_2_19_18  in_degree_1415  1
    arc_2_19_18  out_degree_1420  1
    arc_2_19_18  original_T_including_depot_unload_1429  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_2_19_18  arc_capacity_1346  1
    load_2_19_18  free_load_conservation_1419  -1
    load_2_19_18  free_load_conservation_1425  1
RHS
    RHS1      OBJ       -2.5563209938760956e-01
    RHS1      onehot_24_32  1
    RHS1      onehot_30_53  1
    RHS1      onehot_34_88  1
    RHS1      onehot_28_105  1
    RHS1      onehot_29_130  1
    RHS1      onehot_16_165  1
    RHS1      onehot_27_182  1
    RHS1      onehot_22_217  1
    RHS1      stock_ub_221  27
    RHS1      parent_nonstrict_scope_222  2.8888494310362234e-01
    RHS1      normalization_279  1
    RHS1      connected_order_arc_386  -12
    RHS1      connected_order_arc_388  -12
    RHS1      connected_order_arc_390  -12
    RHS1      connected_order_arc_392  -12
    RHS1      connected_order_arc_394  -12
    RHS1      connected_order_arc_396  -12
    RHS1      connected_order_arc_398  -12
    RHS1      connected_order_arc_400  -12
    RHS1      connected_order_arc_402  -12
    RHS1      connected_order_arc_404  -12
    RHS1      connected_order_arc_406  -12
    RHS1      connected_order_arc_409  -12
    RHS1      connected_order_arc_411  -12
    RHS1      connected_order_arc_413  -12
    RHS1      connected_order_arc_415  -12
    RHS1      connected_order_arc_417  -12
    RHS1      connected_order_arc_419  -12
    RHS1      connected_order_arc_421  -12
    RHS1      connected_order_arc_423  -12
    RHS1      connected_order_arc_425  -12
    RHS1      connected_order_arc_427  -12
    RHS1      connected_order_arc_429  -12
    RHS1      connected_order_arc_432  -12
    RHS1      connected_order_arc_434  -12
    RHS1      connected_order_arc_436  -12
    RHS1      connected_order_arc_438  -12
    RHS1      connected_order_arc_440  -12
    RHS1      connected_order_arc_442  -12
    RHS1      connected_order_arc_444  -12
    RHS1      connected_order_arc_446  -12
    RHS1      connected_order_arc_448  -12
    RHS1      connected_order_arc_450  -12
    RHS1      connected_order_arc_452  -12
    RHS1      connected_order_arc_455  -12
    RHS1      connected_order_arc_457  -12
    RHS1      connected_order_arc_459  -12
    RHS1      connected_order_arc_461  -12
    RHS1      connected_order_arc_463  -12
    RHS1      connected_order_arc_465  -12
    RHS1      connected_order_arc_467  -12
    RHS1      connected_order_arc_469  -12
    RHS1      connected_order_arc_471  -12
    RHS1      connected_order_arc_473  -12
    RHS1      connected_order_arc_475  -12
    RHS1      connected_order_arc_478  -12
    RHS1      connected_order_arc_480  -12
    RHS1      connected_order_arc_482  -12
    RHS1      connected_order_arc_484  -12
    RHS1      connected_order_arc_486  -12
    RHS1      connected_order_arc_488  -12
    RHS1      connected_order_arc_490  -12
    RHS1      connected_order_arc_492  -12
    RHS1      connected_order_arc_494  -12
    RHS1      connected_order_arc_496  -12
    RHS1      connected_order_arc_498  -12
    RHS1      connected_order_arc_501  -12
    RHS1      connected_order_arc_503  -12
    RHS1      connected_order_arc_505  -12
    RHS1      connected_order_arc_507  -12
    RHS1      connected_order_arc_509  -12
    RHS1      connected_order_arc_511  -12
    RHS1      connected_order_arc_513  -12
    RHS1      connected_order_arc_515  -12
    RHS1      connected_order_arc_517  -12
    RHS1      connected_order_arc_519  -12
    RHS1      connected_order_arc_521  -12
    RHS1      connected_order_arc_524  -12
    RHS1      connected_order_arc_526  -12
    RHS1      connected_order_arc_528  -12
    RHS1      connected_order_arc_530  -12
    RHS1      connected_order_arc_532  -12
    RHS1      connected_order_arc_534  -12
    RHS1      connected_order_arc_536  -12
    RHS1      connected_order_arc_538  -12
    RHS1      connected_order_arc_540  -12
    RHS1      connected_order_arc_542  -12
    RHS1      connected_order_arc_544  -12
    RHS1      connected_order_arc_547  -12
    RHS1      connected_order_arc_549  -12
    RHS1      connected_order_arc_551  -12
    RHS1      connected_order_arc_553  -12
    RHS1      connected_order_arc_555  -12
    RHS1      connected_order_arc_557  -12
    RHS1      connected_order_arc_559  -12
    RHS1      connected_order_arc_561  -12
    RHS1      connected_order_arc_563  -12
    RHS1      connected_order_arc_565  -12
    RHS1      connected_order_arc_567  -12
    RHS1      connected_order_arc_570  -12
    RHS1      connected_order_arc_572  -12
    RHS1      connected_order_arc_574  -12
    RHS1      connected_order_arc_576  -12
    RHS1      connected_order_arc_578  -12
    RHS1      connected_order_arc_580  -12
    RHS1      connected_order_arc_582  -12
    RHS1      connected_order_arc_584  -12
    RHS1      connected_order_arc_586  -12
    RHS1      connected_order_arc_588  -12
    RHS1      connected_order_arc_590  -12
    RHS1      connected_order_arc_593  -12
    RHS1      connected_order_arc_595  -12
    RHS1      connected_order_arc_597  -12
    RHS1      connected_order_arc_599  -12
    RHS1      connected_order_arc_601  -12
    RHS1      connected_order_arc_603  -12
    RHS1      connected_order_arc_605  -12
    RHS1      connected_order_arc_607  -12
    RHS1      connected_order_arc_609  -12
    RHS1      connected_order_arc_611  -12
    RHS1      connected_order_arc_613  -12
    RHS1      connected_order_arc_616  -12
    RHS1      connected_order_arc_618  -12
    RHS1      connected_order_arc_620  -12
    RHS1      connected_order_arc_622  -12
    RHS1      connected_order_arc_624  -12
    RHS1      connected_order_arc_626  -12
    RHS1      connected_order_arc_628  -12
    RHS1      connected_order_arc_630  -12
    RHS1      connected_order_arc_632  -12
    RHS1      connected_order_arc_634  -12
    RHS1      connected_order_arc_636  -12
    RHS1      connected_order_arc_639  -12
    RHS1      connected_order_arc_641  -12
    RHS1      connected_order_arc_643  -12
    RHS1      connected_order_arc_645  -12
    RHS1      connected_order_arc_647  -12
    RHS1      connected_order_arc_649  -12
    RHS1      connected_order_arc_651  -12
    RHS1      connected_order_arc_653  -12
    RHS1      connected_order_arc_655  -12
    RHS1      connected_order_arc_657  -12
    RHS1      connected_order_arc_659  -12
    RHS1      depot_departure_or_bypass_660  1
    RHS1      depot_return_or_bypass_661  1
    RHS1      segment_load_conservation_666  1
    RHS1      segment_prefix_ub_668  19
    RHS1      segment_load_conservation_673  1
    RHS1      segment_prefix_ub_675  19
    RHS1      segment_load_conservation_680  -2
    RHS1      segment_prefix_lb_681  2
    RHS1      segment_prefix_ub_682  12
    RHS1      segment_prefix_ub_689  15
    RHS1      fixed_segment_relative_order_738  1
    RHS1      fixed_segment_relative_order_739  1
    RHS1      fixed_segment_relative_order_740  1
    RHS1      original_T_including_depot_unload_741  2.0951809667370981e+03
    RHS1      connected_order_arc_756  -11
    RHS1      connected_order_arc_758  -11
    RHS1      connected_order_arc_760  -11
    RHS1      connected_order_arc_762  -11
    RHS1      connected_order_arc_764  -11
    RHS1      connected_order_arc_766  -11
    RHS1      connected_order_arc_768  -11
    RHS1      connected_order_arc_770  -11
    RHS1      connected_order_arc_772  -11
    RHS1      connected_order_arc_774  -11
    RHS1      connected_order_arc_777  -11
    RHS1      connected_order_arc_779  -11
    RHS1      connected_order_arc_781  -11
    RHS1      connected_order_arc_783  -11
    RHS1      connected_order_arc_785  -11
    RHS1      connected_order_arc_787  -11
    RHS1      connected_order_arc_789  -11
    RHS1      connected_order_arc_791  -11
    RHS1      connected_order_arc_793  -11
    RHS1      connected_order_arc_795  -11
    RHS1      connected_order_arc_798  -11
    RHS1      connected_order_arc_800  -11
    RHS1      connected_order_arc_802  -11
    RHS1      connected_order_arc_804  -11
    RHS1      connected_order_arc_806  -11
    RHS1      connected_order_arc_808  -11
    RHS1      connected_order_arc_810  -11
    RHS1      connected_order_arc_812  -11
    RHS1      connected_order_arc_814  -11
    RHS1      connected_order_arc_816  -11
    RHS1      connected_order_arc_819  -11
    RHS1      connected_order_arc_821  -11
    RHS1      connected_order_arc_823  -11
    RHS1      connected_order_arc_825  -11
    RHS1      connected_order_arc_827  -11
    RHS1      connected_order_arc_829  -11
    RHS1      connected_order_arc_831  -11
    RHS1      connected_order_arc_833  -11
    RHS1      connected_order_arc_835  -11
    RHS1      connected_order_arc_837  -11
    RHS1      connected_order_arc_840  -11
    RHS1      connected_order_arc_842  -11
    RHS1      connected_order_arc_844  -11
    RHS1      connected_order_arc_846  -11
    RHS1      connected_order_arc_848  -11
    RHS1      connected_order_arc_850  -11
    RHS1      connected_order_arc_852  -11
    RHS1      connected_order_arc_854  -11
    RHS1      connected_order_arc_856  -11
    RHS1      connected_order_arc_858  -11
    RHS1      connected_order_arc_861  -11
    RHS1      connected_order_arc_863  -11
    RHS1      connected_order_arc_865  -11
    RHS1      connected_order_arc_867  -11
    RHS1      connected_order_arc_869  -11
    RHS1      connected_order_arc_871  -11
    RHS1      connected_order_arc_873  -11
    RHS1      connected_order_arc_875  -11
    RHS1      connected_order_arc_877  -11
    RHS1      connected_order_arc_879  -11
    RHS1      connected_order_arc_882  -11
    RHS1      connected_order_arc_884  -11
    RHS1      connected_order_arc_886  -11
    RHS1      connected_order_arc_888  -11
    RHS1      connected_order_arc_890  -11
    RHS1      connected_order_arc_892  -11
    RHS1      connected_order_arc_894  -11
    RHS1      connected_order_arc_896  -11
    RHS1      connected_order_arc_898  -11
    RHS1      connected_order_arc_900  -11
    RHS1      connected_order_arc_903  -11
    RHS1      connected_order_arc_905  -11
    RHS1      connected_order_arc_907  -11
    RHS1      connected_order_arc_909  -11
    RHS1      connected_order_arc_911  -11
    RHS1      connected_order_arc_913  -11
    RHS1      connected_order_arc_915  -11
    RHS1      connected_order_arc_917  -11
    RHS1      connected_order_arc_919  -11
    RHS1      connected_order_arc_921  -11
    RHS1      connected_order_arc_924  -11
    RHS1      connected_order_arc_926  -11
    RHS1      connected_order_arc_928  -11
    RHS1      connected_order_arc_930  -11
    RHS1      connected_order_arc_932  -11
    RHS1      connected_order_arc_934  -11
    RHS1      connected_order_arc_936  -11
    RHS1      connected_order_arc_938  -11
    RHS1      connected_order_arc_940  -11
    RHS1      connected_order_arc_942  -11
    RHS1      connected_order_arc_945  -11
    RHS1      connected_order_arc_947  -11
    RHS1      connected_order_arc_949  -11
    RHS1      connected_order_arc_951  -11
    RHS1      connected_order_arc_953  -11
    RHS1      connected_order_arc_955  -11
    RHS1      connected_order_arc_957  -11
    RHS1      connected_order_arc_959  -11
    RHS1      connected_order_arc_961  -11
    RHS1      connected_order_arc_963  -11
    RHS1      connected_order_arc_966  -11
    RHS1      connected_order_arc_968  -11
    RHS1      connected_order_arc_970  -11
    RHS1      connected_order_arc_972  -11
    RHS1      connected_order_arc_974  -11
    RHS1      connected_order_arc_976  -11
    RHS1      connected_order_arc_978  -11
    RHS1      connected_order_arc_980  -11
    RHS1      connected_order_arc_982  -11
    RHS1      connected_order_arc_984  -11
    RHS1      depot_departure_or_bypass_985  1
    RHS1      depot_return_or_bypass_986  1
    RHS1      segment_load_conservation_991  -1
    RHS1      segment_prefix_lb_992  1
    RHS1      segment_prefix_ub_993  25
    RHS1      segment_load_conservation_998  5
    RHS1      segment_prefix_ub_1000  20
    RHS1      segment_load_conservation_1005  -4
    RHS1      segment_prefix_lb_1006  4
    RHS1      segment_prefix_ub_1007  25
    RHS1      fixed_segment_relative_order_1056  1
    RHS1      fixed_segment_relative_order_1057  1
    RHS1      original_T_including_depot_unload_1058  5700
    RHS1      connected_order_arc_1074  -12
    RHS1      connected_order_arc_1076  -12
    RHS1      connected_order_arc_1078  -12
    RHS1      connected_order_arc_1080  -12
    RHS1      connected_order_arc_1082  -12
    RHS1      connected_order_arc_1084  -12
    RHS1      connected_order_arc_1086  -12
    RHS1      connected_order_arc_1088  -12
    RHS1      connected_order_arc_1090  -12
    RHS1      connected_order_arc_1092  -12
    RHS1      connected_order_arc_1094  -12
    RHS1      connected_order_arc_1097  -12
    RHS1      connected_order_arc_1099  -12
    RHS1      connected_order_arc_1101  -12
    RHS1      connected_order_arc_1103  -12
    RHS1      connected_order_arc_1105  -12
    RHS1      connected_order_arc_1107  -12
    RHS1      connected_order_arc_1109  -12
    RHS1      connected_order_arc_1111  -12
    RHS1      connected_order_arc_1113  -12
    RHS1      connected_order_arc_1115  -12
    RHS1      connected_order_arc_1117  -12
    RHS1      connected_order_arc_1120  -12
    RHS1      connected_order_arc_1122  -12
    RHS1      connected_order_arc_1124  -12
    RHS1      connected_order_arc_1126  -12
    RHS1      connected_order_arc_1128  -12
    RHS1      connected_order_arc_1130  -12
    RHS1      connected_order_arc_1132  -12
    RHS1      connected_order_arc_1134  -12
    RHS1      connected_order_arc_1136  -12
    RHS1      connected_order_arc_1138  -12
    RHS1      connected_order_arc_1140  -12
    RHS1      connected_order_arc_1143  -12
    RHS1      connected_order_arc_1145  -12
    RHS1      connected_order_arc_1147  -12
    RHS1      connected_order_arc_1149  -12
    RHS1      connected_order_arc_1151  -12
    RHS1      connected_order_arc_1153  -12
    RHS1      connected_order_arc_1155  -12
    RHS1      connected_order_arc_1157  -12
    RHS1      connected_order_arc_1159  -12
    RHS1      connected_order_arc_1161  -12
    RHS1      connected_order_arc_1163  -12
    RHS1      connected_order_arc_1166  -12
    RHS1      connected_order_arc_1168  -12
    RHS1      connected_order_arc_1170  -12
    RHS1      connected_order_arc_1172  -12
    RHS1      connected_order_arc_1174  -12
    RHS1      connected_order_arc_1176  -12
    RHS1      connected_order_arc_1178  -12
    RHS1      connected_order_arc_1180  -12
    RHS1      connected_order_arc_1182  -12
    RHS1      connected_order_arc_1184  -12
    RHS1      connected_order_arc_1186  -12
    RHS1      connected_order_arc_1189  -12
    RHS1      connected_order_arc_1191  -12
    RHS1      connected_order_arc_1193  -12
    RHS1      connected_order_arc_1195  -12
    RHS1      connected_order_arc_1197  -12
    RHS1      connected_order_arc_1199  -12
    RHS1      connected_order_arc_1201  -12
    RHS1      connected_order_arc_1203  -12
    RHS1      connected_order_arc_1205  -12
    RHS1      connected_order_arc_1207  -12
    RHS1      connected_order_arc_1209  -12
    RHS1      connected_order_arc_1212  -12
    RHS1      connected_order_arc_1214  -12
    RHS1      connected_order_arc_1216  -12
    RHS1      connected_order_arc_1218  -12
    RHS1      connected_order_arc_1220  -12
    RHS1      connected_order_arc_1222  -12
    RHS1      connected_order_arc_1224  -12
    RHS1      connected_order_arc_1226  -12
    RHS1      connected_order_arc_1228  -12
    RHS1      connected_order_arc_1230  -12
    RHS1      connected_order_arc_1232  -12
    RHS1      connected_order_arc_1235  -12
    RHS1      connected_order_arc_1237  -12
    RHS1      connected_order_arc_1239  -12
    RHS1      connected_order_arc_1241  -12
    RHS1      connected_order_arc_1243  -12
    RHS1      connected_order_arc_1245  -12
    RHS1      connected_order_arc_1247  -12
    RHS1      connected_order_arc_1249  -12
    RHS1      connected_order_arc_1251  -12
    RHS1      connected_order_arc_1253  -12
    RHS1      connected_order_arc_1255  -12
    RHS1      connected_order_arc_1258  -12
    RHS1      connected_order_arc_1260  -12
    RHS1      connected_order_arc_1262  -12
    RHS1      connected_order_arc_1264  -12
    RHS1      connected_order_arc_1266  -12
    RHS1      connected_order_arc_1268  -12
    RHS1      connected_order_arc_1270  -12
    RHS1      connected_order_arc_1272  -12
    RHS1      connected_order_arc_1274  -12
    RHS1      connected_order_arc_1276  -12
    RHS1      connected_order_arc_1278  -12
    RHS1      connected_order_arc_1281  -12
    RHS1      connected_order_arc_1283  -12
    RHS1      connected_order_arc_1285  -12
    RHS1      connected_order_arc_1287  -12
    RHS1      connected_order_arc_1289  -12
    RHS1      connected_order_arc_1291  -12
    RHS1      connected_order_arc_1293  -12
    RHS1      connected_order_arc_1295  -12
    RHS1      connected_order_arc_1297  -12
    RHS1      connected_order_arc_1299  -12
    RHS1      connected_order_arc_1301  -12
    RHS1      connected_order_arc_1304  -12
    RHS1      connected_order_arc_1306  -12
    RHS1      connected_order_arc_1308  -12
    RHS1      connected_order_arc_1310  -12
    RHS1      connected_order_arc_1312  -12
    RHS1      connected_order_arc_1314  -12
    RHS1      connected_order_arc_1316  -12
    RHS1      connected_order_arc_1318  -12
    RHS1      connected_order_arc_1320  -12
    RHS1      connected_order_arc_1322  -12
    RHS1      connected_order_arc_1324  -12
    RHS1      connected_order_arc_1327  -12
    RHS1      connected_order_arc_1329  -12
    RHS1      connected_order_arc_1331  -12
    RHS1      connected_order_arc_1333  -12
    RHS1      connected_order_arc_1335  -12
    RHS1      connected_order_arc_1337  -12
    RHS1      connected_order_arc_1339  -12
    RHS1      connected_order_arc_1341  -12
    RHS1      connected_order_arc_1343  -12
    RHS1      connected_order_arc_1345  -12
    RHS1      connected_order_arc_1347  -12
    RHS1      depot_departure_or_bypass_1348  1
    RHS1      depot_return_or_bypass_1349  1
    RHS1      segment_load_conservation_1354  2
    RHS1      segment_prefix_ub_1356  28
    RHS1      segment_load_conservation_1361  2
    RHS1      segment_prefix_ub_1363  28
    RHS1      segment_load_conservation_1368  -4
    RHS1      segment_prefix_lb_1369  4
    RHS1      segment_prefix_ub_1370  30
    RHS1      segment_load_conservation_1375  1
    RHS1      segment_prefix_ub_1377  26
    RHS1      fixed_segment_relative_order_1426  1
    RHS1      fixed_segment_relative_order_1427  1
    RHS1      fixed_segment_relative_order_1428  1
    RHS1      original_T_including_depot_unload_1429  5.0336090414903692e+03
BOUNDS
 LO BND1      t         2.5233560635620170e-02
 UP BND1      t         4.1907802833807628e-02
 UP BND1      q         4.0162002117312451e-01
 BV BND1      x_24_0  
 UP BND1      w_24_0    4.1907802833807628e-02
 BV BND1      x_24_1  
 UP BND1      w_24_1    4.1907802833807628e-02
 BV BND1      x_24_2  
 UP BND1      w_24_2    4.1907802833807628e-02
 BV BND1      x_24_3  
 UP BND1      w_24_3    4.1907802833807628e-02
 BV BND1      x_24_4  
 UP BND1      w_24_4    4.1907802833807628e-02
 BV BND1      x_24_5  
 UP BND1      w_24_5    4.1907802833807628e-02
 BV BND1      x_24_6  
 UP BND1      w_24_6    4.1907802833807628e-02
 BV BND1      x_24_7  
 UP BND1      w_24_7    4.1907802833807628e-02
 BV BND1      x_24_8  
 UP BND1      w_24_8    4.1907802833807628e-02
 BV BND1      x_24_9  
 UP BND1      w_24_9    4.1907802833807628e-02
 BV BND1      x_24_10 
 UP BND1      w_24_10   4.1907802833807628e-02
 BV BND1      x_24_11 
 UP BND1      w_24_11   4.1907802833807628e-02
 BV BND1      x_24_12 
 UP BND1      w_24_12   4.1907802833807628e-02
 BV BND1      x_24_13 
 UP BND1      w_24_13   4.1907802833807628e-02
 BV BND1      x_24_14 
 UP BND1      w_24_14   4.1907802833807628e-02
 BV BND1      x_24_15 
 UP BND1      w_24_15   4.1907802833807628e-02
 UP BND1      rho_24    1
 BV BND1      x_30_0  
 UP BND1      w_30_0    4.1907802833807628e-02
 BV BND1      x_30_1  
 UP BND1      w_30_1    4.1907802833807628e-02
 BV BND1      x_30_2  
 UP BND1      w_30_2    4.1907802833807628e-02
 BV BND1      x_30_3  
 UP BND1      w_30_3    4.1907802833807628e-02
 BV BND1      x_30_4  
 UP BND1      w_30_4    4.1907802833807628e-02
 BV BND1      x_30_5  
 UP BND1      w_30_5    4.1907802833807628e-02
 BV BND1      x_30_6  
 UP BND1      w_30_6    4.1907802833807628e-02
 BV BND1      x_30_7  
 UP BND1      w_30_7    4.1907802833807628e-02
 BV BND1      x_30_8  
 UP BND1      w_30_8    4.1907802833807628e-02
 UP BND1      rho_30    1
 BV BND1      x_34_0  
 UP BND1      w_34_0    4.1907802833807628e-02
 BV BND1      x_34_1  
 UP BND1      w_34_1    4.1907802833807628e-02
 BV BND1      x_34_2  
 UP BND1      w_34_2    4.1907802833807628e-02
 BV BND1      x_34_3  
 UP BND1      w_34_3    4.1907802833807628e-02
 BV BND1      x_34_4  
 UP BND1      w_34_4    4.1907802833807628e-02
 BV BND1      x_34_5  
 UP BND1      w_34_5    4.1907802833807628e-02
 BV BND1      x_34_6  
 UP BND1      w_34_6    4.1907802833807628e-02
 BV BND1      x_34_7  
 UP BND1      w_34_7    4.1907802833807628e-02
 BV BND1      x_34_8  
 UP BND1      w_34_8    4.1907802833807628e-02
 BV BND1      x_34_9  
 UP BND1      w_34_9    4.1907802833807628e-02
 BV BND1      x_34_10 
 UP BND1      w_34_10   4.1907802833807628e-02
 BV BND1      x_34_11 
 UP BND1      w_34_11   4.1907802833807628e-02
 BV BND1      x_34_12 
 UP BND1      w_34_12   4.1907802833807628e-02
 BV BND1      x_34_13 
 UP BND1      w_34_13   4.1907802833807628e-02
 BV BND1      x_34_14 
 UP BND1      w_34_14   4.1907802833807628e-02
 BV BND1      x_34_15 
 UP BND1      w_34_15   4.1907802833807628e-02
 UP BND1      rho_34    1
 BV BND1      x_28_0  
 UP BND1      w_28_0    4.1907802833807628e-02
 BV BND1      x_28_1  
 UP BND1      w_28_1    4.1907802833807628e-02
 BV BND1      x_28_2  
 UP BND1      w_28_2    4.1907802833807628e-02
 BV BND1      x_28_3  
 UP BND1      w_28_3    4.1907802833807628e-02
 BV BND1      x_28_4  
 UP BND1      w_28_4    4.1907802833807628e-02
 BV BND1      x_28_5  
 UP BND1      w_28_5    4.1907802833807628e-02
 BV BND1      x_28_6  
 UP BND1      w_28_6    4.1907802833807628e-02
 UP BND1      rho_28    1
 BV BND1      x_29_0  
 UP BND1      w_29_0    4.1907802833807628e-02
 BV BND1      x_29_1  
 UP BND1      w_29_1    4.1907802833807628e-02
 BV BND1      x_29_2  
 UP BND1      w_29_2    4.1907802833807628e-02
 BV BND1      x_29_3  
 UP BND1      w_29_3    4.1907802833807628e-02
 BV BND1      x_29_4  
 UP BND1      w_29_4    4.1907802833807628e-02
 BV BND1      x_29_5  
 UP BND1      w_29_5    4.1907802833807628e-02
 BV BND1      x_29_6  
 UP BND1      w_29_6    4.1907802833807628e-02
 BV BND1      x_29_7  
 UP BND1      w_29_7    4.1907802833807628e-02
 BV BND1      x_29_8  
 UP BND1      w_29_8    4.1907802833807628e-02
 BV BND1      x_29_9  
 UP BND1      w_29_9    4.1907802833807628e-02
 BV BND1      x_29_10 
 UP BND1      w_29_10   4.1907802833807628e-02
 UP BND1      rho_29    1
 BV BND1      x_16_0  
 UP BND1      w_16_0    4.1907802833807628e-02
 BV BND1      x_16_1  
 UP BND1      w_16_1    4.1907802833807628e-02
 BV BND1      x_16_2  
 UP BND1      w_16_2    4.1907802833807628e-02
 BV BND1      x_16_3  
 UP BND1      w_16_3    4.1907802833807628e-02
 BV BND1      x_16_4  
 UP BND1      w_16_4    4.1907802833807628e-02
 BV BND1      x_16_5  
 UP BND1      w_16_5    4.1907802833807628e-02
 BV BND1      x_16_6  
 UP BND1      w_16_6    4.1907802833807628e-02
 BV BND1      x_16_7  
 UP BND1      w_16_7    4.1907802833807628e-02
 BV BND1      x_16_8  
 UP BND1      w_16_8    4.1907802833807628e-02
 BV BND1      x_16_9  
 UP BND1      w_16_9    4.1907802833807628e-02
 BV BND1      x_16_10 
 UP BND1      w_16_10   4.1907802833807628e-02
 BV BND1      x_16_11 
 UP BND1      w_16_11   4.1907802833807628e-02
 BV BND1      x_16_12 
 UP BND1      w_16_12   4.1907802833807628e-02
 BV BND1      x_16_13 
 UP BND1      w_16_13   4.1907802833807628e-02
 BV BND1      x_16_14 
 UP BND1      w_16_14   4.1907802833807628e-02
 BV BND1      x_16_15 
 UP BND1      w_16_15   4.1907802833807628e-02
 UP BND1      rho_16    1
 BV BND1      x_27_0  
 UP BND1      w_27_0    4.1907802833807628e-02
 BV BND1      x_27_1  
 UP BND1      w_27_1    4.1907802833807628e-02
 BV BND1      x_27_2  
 UP BND1      w_27_2    4.1907802833807628e-02
 BV BND1      x_27_3  
 UP BND1      w_27_3    4.1907802833807628e-02
 BV BND1      x_27_4  
 UP BND1      w_27_4    4.1907802833807628e-02
 BV BND1      x_27_5  
 UP BND1      w_27_5    4.1907802833807628e-02
 BV BND1      x_27_6  
 UP BND1      w_27_6    4.1907802833807628e-02
 UP BND1      rho_27    1
 BV BND1      x_22_0  
 UP BND1      w_22_0    4.1907802833807628e-02
 BV BND1      x_22_1  
 UP BND1      w_22_1    4.1907802833807628e-02
 BV BND1      x_22_2  
 UP BND1      w_22_2    4.1907802833807628e-02
 BV BND1      x_22_3  
 UP BND1      w_22_3    4.1907802833807628e-02
 BV BND1      x_22_4  
 UP BND1      w_22_4    4.1907802833807628e-02
 BV BND1      x_22_5  
 UP BND1      w_22_5    4.1907802833807628e-02
 BV BND1      x_22_6  
 UP BND1      w_22_6    4.1907802833807628e-02
 BV BND1      x_22_7  
 UP BND1      w_22_7    4.1907802833807628e-02
 BV BND1      x_22_8  
 UP BND1      w_22_8    4.1907802833807628e-02
 BV BND1      x_22_9  
 UP BND1      w_22_9    4.1907802833807628e-02
 BV BND1      x_22_10 
 UP BND1      w_22_10   4.1907802833807628e-02
 BV BND1      x_22_11 
 UP BND1      w_22_11   4.1907802833807628e-02
 BV BND1      x_22_12 
 UP BND1      w_22_12   4.1907802833807628e-02
 BV BND1      x_22_13 
 UP BND1      w_22_13   4.1907802833807628e-02
 BV BND1      x_22_14 
 UP BND1      w_22_14   4.1907802833807628e-02
 BV BND1      x_22_15 
 UP BND1      w_22_15   4.1907802833807628e-02
 UP BND1      rho_22    1
 UP BND1      a_24_30   1
 UP BND1      a_24_34   1
 UP BND1      a_24_28   1
 UP BND1      a_24_29   1
 UP BND1      a_24_16   1
 UP BND1      a_24_27   1
 UP BND1      a_24_22   1
 UP BND1      a_30_34   1
 UP BND1      a_30_28   1
 UP BND1      a_30_29   1
 UP BND1      a_30_16   1
 UP BND1      a_30_27   1
 UP BND1      a_30_22   1
 UP BND1      a_34_28   1
 UP BND1      a_34_29   1
 UP BND1      a_34_16   1
 UP BND1      a_34_27   1
 UP BND1      a_34_22   1
 UP BND1      a_28_29   1
 UP BND1      a_28_16   1
 UP BND1      a_28_27   1
 UP BND1      a_28_22   1
 UP BND1      a_29_16   1
 UP BND1      a_29_27   1
 UP BND1      a_29_22   1
 UP BND1      a_16_27   1
 UP BND1      a_16_22   1
 UP BND1      a_27_22   1
 BV BND1      service_0_24_0
 BV BND1      service_0_24_1
 BV BND1      service_0_24_2
 BV BND1      service_0_24_3
 BV BND1      service_0_24_4
 BV BND1      service_0_24_5
 BV BND1      service_0_24_6
 BV BND1      service_0_24_7
 BV BND1      service_0_24_8
 BV BND1      service_0_24_9
 BV BND1      service_0_24_10
 BV BND1      service_0_24_11
 BV BND1      service_0_24_12
 BV BND1      service_0_24_14
 BV BND1      service_0_24_15
 BV BND1      service_1_24_0
 BV BND1      service_1_24_1
 BV BND1      service_1_24_2
 BV BND1      service_1_24_3
 BV BND1      service_1_24_4
 BV BND1      service_1_24_5
 BV BND1      service_1_24_6
 BV BND1      service_1_24_7
 BV BND1      service_1_24_8
 BV BND1      service_1_24_9
 BV BND1      service_1_24_10
 BV BND1      service_1_24_11
 BV BND1      service_1_24_12
 BV BND1      service_1_24_14
 BV BND1      service_1_24_15
 BV BND1      service_2_24_0
 BV BND1      service_2_24_1
 BV BND1      service_2_24_2
 BV BND1      service_2_24_3
 BV BND1      service_2_24_4
 BV BND1      service_2_24_5
 BV BND1      service_2_24_6
 BV BND1      service_2_24_7
 BV BND1      service_2_24_8
 BV BND1      service_2_24_9
 BV BND1      service_2_24_10
 BV BND1      service_2_24_11
 BV BND1      service_2_24_12
 BV BND1      service_2_24_14
 BV BND1      service_2_24_15
 BV BND1      service_0_30_0
 BV BND1      service_0_30_1
 BV BND1      service_0_30_2
 BV BND1      service_0_30_3
 BV BND1      service_0_30_4
 BV BND1      service_0_30_6
 BV BND1      service_0_30_7
 BV BND1      service_0_30_8
 BV BND1      service_1_30_0
 BV BND1      service_1_30_1
 BV BND1      service_1_30_2
 BV BND1      service_1_30_3
 BV BND1      service_1_30_4
 BV BND1      service_1_30_6
 BV BND1      service_1_30_7
 BV BND1      service_1_30_8
 BV BND1      service_2_30_0
 BV BND1      service_2_30_1
 BV BND1      service_2_30_2
 BV BND1      service_2_30_3
 BV BND1      service_2_30_4
 BV BND1      service_2_30_6
 BV BND1      service_2_30_7
 BV BND1      service_2_30_8
 BV BND1      service_0_34_0
 BV BND1      service_0_34_1
 BV BND1      service_0_34_3
 BV BND1      service_0_34_4
 BV BND1      service_0_34_5
 BV BND1      service_0_34_6
 BV BND1      service_0_34_7
 BV BND1      service_0_34_8
 BV BND1      service_0_34_9
 BV BND1      service_0_34_10
 BV BND1      service_0_34_11
 BV BND1      service_0_34_12
 BV BND1      service_0_34_13
 BV BND1      service_0_34_14
 BV BND1      service_0_34_15
 BV BND1      service_1_34_0
 BV BND1      service_1_34_1
 BV BND1      service_1_34_3
 BV BND1      service_1_34_4
 BV BND1      service_1_34_5
 BV BND1      service_1_34_6
 BV BND1      service_1_34_7
 BV BND1      service_1_34_8
 BV BND1      service_1_34_9
 BV BND1      service_1_34_10
 BV BND1      service_1_34_11
 BV BND1      service_1_34_12
 BV BND1      service_1_34_13
 BV BND1      service_1_34_14
 BV BND1      service_1_34_15
 BV BND1      service_2_34_0
 BV BND1      service_2_34_1
 BV BND1      service_2_34_3
 BV BND1      service_2_34_4
 BV BND1      service_2_34_5
 BV BND1      service_2_34_6
 BV BND1      service_2_34_7
 BV BND1      service_2_34_8
 BV BND1      service_2_34_9
 BV BND1      service_2_34_10
 BV BND1      service_2_34_11
 BV BND1      service_2_34_12
 BV BND1      service_2_34_13
 BV BND1      service_2_34_14
 BV BND1      service_2_34_15
 BV BND1      service_0_28_0
 BV BND1      service_0_28_2
 BV BND1      service_0_28_3
 BV BND1      service_0_28_4
 BV BND1      service_0_28_5
 BV BND1      service_0_28_6
 BV BND1      service_1_28_0
 BV BND1      service_1_28_2
 BV BND1      service_1_28_3
 BV BND1      service_1_28_4
 BV BND1      service_1_28_5
 BV BND1      service_1_28_6
 BV BND1      service_2_28_0
 BV BND1      service_2_28_2
 BV BND1      service_2_28_3
 BV BND1      service_2_28_4
 BV BND1      service_2_28_5
 BV BND1      service_2_28_6
 BV BND1      service_0_29_0
 BV BND1      service_0_29_2
 BV BND1      service_0_29_3
 BV BND1      service_0_29_4
 BV BND1      service_0_29_5
 BV BND1      service_0_29_6
 BV BND1      service_0_29_7
 BV BND1      service_0_29_8
 BV BND1      service_0_29_9
 BV BND1      service_0_29_10
 BV BND1      service_1_29_0
 BV BND1      service_1_29_2
 BV BND1      service_1_29_3
 BV BND1      service_1_29_4
 BV BND1      service_1_29_5
 BV BND1      service_1_29_6
 BV BND1      service_1_29_7
 BV BND1      service_1_29_8
 BV BND1      service_1_29_9
 BV BND1      service_1_29_10
 BV BND1      service_2_29_0
 BV BND1      service_2_29_2
 BV BND1      service_2_29_3
 BV BND1      service_2_29_4
 BV BND1      service_2_29_5
 BV BND1      service_2_29_6
 BV BND1      service_2_29_7
 BV BND1      service_2_29_8
 BV BND1      service_2_29_9
 BV BND1      service_2_29_10
 BV BND1      service_0_16_0
 BV BND1      service_0_16_1
 BV BND1      service_0_16_3
 BV BND1      service_0_16_4
 BV BND1      service_0_16_5
 BV BND1      service_0_16_6
 BV BND1      service_0_16_7
 BV BND1      service_0_16_8
 BV BND1      service_0_16_9
 BV BND1      service_0_16_10
 BV BND1      service_0_16_11
 BV BND1      service_0_16_12
 BV BND1      service_0_16_13
 BV BND1      service_0_16_14
 BV BND1      service_0_16_15
 BV BND1      service_1_16_0
 BV BND1      service_1_16_1
 BV BND1      service_1_16_3
 BV BND1      service_1_16_4
 BV BND1      service_1_16_5
 BV BND1      service_1_16_6
 BV BND1      service_1_16_7
 BV BND1      service_1_16_8
 BV BND1      service_1_16_9
 BV BND1      service_1_16_10
 BV BND1      service_1_16_11
 BV BND1      service_1_16_12
 BV BND1      service_1_16_13
 BV BND1      service_1_16_14
 BV BND1      service_1_16_15
 BV BND1      service_2_16_0
 BV BND1      service_2_16_1
 BV BND1      service_2_16_3
 BV BND1      service_2_16_4
 BV BND1      service_2_16_5
 BV BND1      service_2_16_6
 BV BND1      service_2_16_7
 BV BND1      service_2_16_8
 BV BND1      service_2_16_9
 BV BND1      service_2_16_10
 BV BND1      service_2_16_11
 BV BND1      service_2_16_12
 BV BND1      service_2_16_13
 BV BND1      service_2_16_14
 BV BND1      service_2_16_15
 BV BND1      service_0_27_1
 BV BND1      service_0_27_2
 BV BND1      service_0_27_3
 BV BND1      service_0_27_4
 BV BND1      service_0_27_5
 BV BND1      service_0_27_6
 BV BND1      service_1_27_1
 BV BND1      service_1_27_2
 BV BND1      service_1_27_3
 BV BND1      service_1_27_4
 BV BND1      service_1_27_5
 BV BND1      service_1_27_6
 BV BND1      service_2_27_1
 BV BND1      service_2_27_2
 BV BND1      service_2_27_3
 BV BND1      service_2_27_4
 BV BND1      service_2_27_5
 BV BND1      service_2_27_6
 BV BND1      service_0_22_0
 BV BND1      service_0_22_1
 BV BND1      service_0_22_3
 BV BND1      service_0_22_4
 BV BND1      service_0_22_5
 BV BND1      service_0_22_6
 BV BND1      service_0_22_7
 BV BND1      service_0_22_8
 BV BND1      service_0_22_9
 BV BND1      service_0_22_10
 BV BND1      service_0_22_11
 BV BND1      service_0_22_12
 BV BND1      service_0_22_13
 BV BND1      service_0_22_14
 BV BND1      service_0_22_15
 BV BND1      service_1_22_0
 BV BND1      service_1_22_1
 BV BND1      service_1_22_3
 BV BND1      service_1_22_4
 BV BND1      service_1_22_5
 BV BND1      service_1_22_6
 BV BND1      service_1_22_7
 BV BND1      service_1_22_8
 BV BND1      service_1_22_9
 BV BND1      service_1_22_10
 BV BND1      service_1_22_11
 BV BND1      service_1_22_12
 BV BND1      service_1_22_13
 BV BND1      service_1_22_14
 BV BND1      service_1_22_15
 BV BND1      service_2_22_0
 BV BND1      service_2_22_1
 BV BND1      service_2_22_3
 BV BND1      service_2_22_4
 BV BND1      service_2_22_5
 BV BND1      service_2_22_6
 BV BND1      service_2_22_7
 BV BND1      service_2_22_8
 BV BND1      service_2_22_9
 BV BND1      service_2_22_10
 BV BND1      service_2_22_11
 BV BND1      service_2_22_12
 BV BND1      service_2_22_13
 BV BND1      service_2_22_14
 BV BND1      service_2_22_15
 FX BND1      visit_0_1  1
 UP BND1      order_0_1  12
 FX BND1      visit_0_2  1
 UP BND1      order_0_2  12
 FX BND1      visit_0_3  1
 UP BND1      order_0_3  12
 FX BND1      visit_0_4  1
 UP BND1      order_0_4  12
 UP BND1      visit_0_12  1
 UP BND1      order_0_12  12
 UP BND1      visit_0_13  1
 UP BND1      order_0_13  12
 UP BND1      visit_0_14  1
 UP BND1      order_0_14  12
 UP BND1      visit_0_15  1
 UP BND1      order_0_15  12
 UP BND1      visit_0_16  1
 UP BND1      order_0_16  12
 UP BND1      visit_0_17  1
 UP BND1      order_0_17  12
 UP BND1      visit_0_18  1
 UP BND1      order_0_18  12
 UP BND1      visit_0_19  1
 UP BND1      order_0_19  12
 BV BND1      arc_0_0_0
 FX BND1      load_0_0_0  0
 BV BND1      arc_0_0_1
 FX BND1      load_0_0_1  0
 BV BND1      arc_0_0_2
 FX BND1      load_0_0_2  0
 BV BND1      arc_0_0_3
 FX BND1      load_0_0_3  0
 BV BND1      arc_0_0_4
 FX BND1      load_0_0_4  0
 BV BND1      arc_0_0_12
 FX BND1      load_0_0_12  0
 BV BND1      arc_0_0_13
 FX BND1      load_0_0_13  0
 BV BND1      arc_0_0_14
 FX BND1      load_0_0_14  0
 BV BND1      arc_0_0_15
 FX BND1      load_0_0_15  0
 BV BND1      arc_0_0_16
 FX BND1      load_0_0_16  0
 BV BND1      arc_0_0_17
 FX BND1      load_0_0_17  0
 BV BND1      arc_0_0_18
 FX BND1      load_0_0_18  0
 BV BND1      arc_0_0_19
 FX BND1      load_0_0_19  0
 BV BND1      arc_0_1_0
 UP BND1      load_0_1_0  20
 BV BND1      arc_0_1_2
 UP BND1      load_0_1_2  20
 BV BND1      arc_0_1_3
 UP BND1      load_0_1_3  20
 BV BND1      arc_0_1_4
 UP BND1      load_0_1_4  20
 BV BND1      arc_0_1_12
 UP BND1      load_0_1_12  20
 BV BND1      arc_0_1_13
 UP BND1      load_0_1_13  20
 BV BND1      arc_0_1_14
 UP BND1      load_0_1_14  20
 BV BND1      arc_0_1_15
 UP BND1      load_0_1_15  20
 BV BND1      arc_0_1_16
 UP BND1      load_0_1_16  20
 BV BND1      arc_0_1_17
 UP BND1      load_0_1_17  20
 BV BND1      arc_0_1_18
 UP BND1      load_0_1_18  20
 BV BND1      arc_0_1_19
 UP BND1      load_0_1_19  20
 BV BND1      arc_0_2_0
 UP BND1      load_0_2_0  20
 BV BND1      arc_0_2_1
 UP BND1      load_0_2_1  20
 BV BND1      arc_0_2_3
 UP BND1      load_0_2_3  20
 BV BND1      arc_0_2_4
 UP BND1      load_0_2_4  20
 BV BND1      arc_0_2_12
 UP BND1      load_0_2_12  20
 BV BND1      arc_0_2_13
 UP BND1      load_0_2_13  20
 BV BND1      arc_0_2_14
 UP BND1      load_0_2_14  20
 BV BND1      arc_0_2_15
 UP BND1      load_0_2_15  20
 BV BND1      arc_0_2_16
 UP BND1      load_0_2_16  20
 BV BND1      arc_0_2_17
 UP BND1      load_0_2_17  20
 BV BND1      arc_0_2_18
 UP BND1      load_0_2_18  20
 BV BND1      arc_0_2_19
 UP BND1      load_0_2_19  20
 BV BND1      arc_0_3_0
 UP BND1      load_0_3_0  20
 BV BND1      arc_0_3_1
 UP BND1      load_0_3_1  20
 BV BND1      arc_0_3_2
 UP BND1      load_0_3_2  20
 BV BND1      arc_0_3_4
 UP BND1      load_0_3_4  20
 BV BND1      arc_0_3_12
 UP BND1      load_0_3_12  20
 BV BND1      arc_0_3_13
 UP BND1      load_0_3_13  20
 BV BND1      arc_0_3_14
 UP BND1      load_0_3_14  20
 BV BND1      arc_0_3_15
 UP BND1      load_0_3_15  20
 BV BND1      arc_0_3_16
 UP BND1      load_0_3_16  20
 BV BND1      arc_0_3_17
 UP BND1      load_0_3_17  20
 BV BND1      arc_0_3_18
 UP BND1      load_0_3_18  20
 BV BND1      arc_0_3_19
 UP BND1      load_0_3_19  20
 BV BND1      arc_0_4_0
 UP BND1      load_0_4_0  20
 BV BND1      arc_0_4_1
 UP BND1      load_0_4_1  20
 BV BND1      arc_0_4_2
 UP BND1      load_0_4_2  20
 BV BND1      arc_0_4_3
 UP BND1      load_0_4_3  20
 BV BND1      arc_0_4_12
 UP BND1      load_0_4_12  20
 BV BND1      arc_0_4_13
 UP BND1      load_0_4_13  20
 BV BND1      arc_0_4_14
 UP BND1      load_0_4_14  20
 BV BND1      arc_0_4_15
 UP BND1      load_0_4_15  20
 BV BND1      arc_0_4_16
 UP BND1      load_0_4_16  20
 BV BND1      arc_0_4_17
 UP BND1      load_0_4_17  20
 BV BND1      arc_0_4_18
 UP BND1      load_0_4_18  20
 BV BND1      arc_0_4_19
 UP BND1      load_0_4_19  20
 BV BND1      arc_0_12_0
 UP BND1      load_0_12_0  20
 BV BND1      arc_0_12_1
 UP BND1      load_0_12_1  20
 BV BND1      arc_0_12_2
 UP BND1      load_0_12_2  20
 BV BND1      arc_0_12_3
 UP BND1      load_0_12_3  20
 BV BND1      arc_0_12_4
 UP BND1      load_0_12_4  20
 BV BND1      arc_0_12_13
 UP BND1      load_0_12_13  20
 BV BND1      arc_0_12_14
 UP BND1      load_0_12_14  20
 BV BND1      arc_0_12_15
 UP BND1      load_0_12_15  20
 BV BND1      arc_0_12_16
 UP BND1      load_0_12_16  20
 BV BND1      arc_0_12_17
 UP BND1      load_0_12_17  20
 BV BND1      arc_0_12_18
 UP BND1      load_0_12_18  20
 BV BND1      arc_0_12_19
 UP BND1      load_0_12_19  20
 BV BND1      arc_0_13_0
 UP BND1      load_0_13_0  20
 BV BND1      arc_0_13_1
 UP BND1      load_0_13_1  20
 BV BND1      arc_0_13_2
 UP BND1      load_0_13_2  20
 BV BND1      arc_0_13_3
 UP BND1      load_0_13_3  20
 BV BND1      arc_0_13_4
 UP BND1      load_0_13_4  20
 BV BND1      arc_0_13_12
 UP BND1      load_0_13_12  20
 BV BND1      arc_0_13_14
 UP BND1      load_0_13_14  20
 BV BND1      arc_0_13_15
 UP BND1      load_0_13_15  20
 BV BND1      arc_0_13_16
 UP BND1      load_0_13_16  20
 BV BND1      arc_0_13_17
 UP BND1      load_0_13_17  20
 BV BND1      arc_0_13_18
 UP BND1      load_0_13_18  20
 BV BND1      arc_0_13_19
 UP BND1      load_0_13_19  20
 BV BND1      arc_0_14_0
 UP BND1      load_0_14_0  20
 BV BND1      arc_0_14_1
 UP BND1      load_0_14_1  20
 BV BND1      arc_0_14_2
 UP BND1      load_0_14_2  20
 BV BND1      arc_0_14_3
 UP BND1      load_0_14_3  20
 BV BND1      arc_0_14_4
 UP BND1      load_0_14_4  20
 BV BND1      arc_0_14_12
 UP BND1      load_0_14_12  20
 BV BND1      arc_0_14_13
 UP BND1      load_0_14_13  20
 BV BND1      arc_0_14_15
 UP BND1      load_0_14_15  20
 BV BND1      arc_0_14_16
 UP BND1      load_0_14_16  20
 BV BND1      arc_0_14_17
 UP BND1      load_0_14_17  20
 BV BND1      arc_0_14_18
 UP BND1      load_0_14_18  20
 BV BND1      arc_0_14_19
 UP BND1      load_0_14_19  20
 BV BND1      arc_0_15_0
 UP BND1      load_0_15_0  20
 BV BND1      arc_0_15_1
 UP BND1      load_0_15_1  20
 BV BND1      arc_0_15_2
 UP BND1      load_0_15_2  20
 BV BND1      arc_0_15_3
 UP BND1      load_0_15_3  20
 BV BND1      arc_0_15_4
 UP BND1      load_0_15_4  20
 BV BND1      arc_0_15_12
 UP BND1      load_0_15_12  20
 BV BND1      arc_0_15_13
 UP BND1      load_0_15_13  20
 BV BND1      arc_0_15_14
 UP BND1      load_0_15_14  20
 BV BND1      arc_0_15_16
 UP BND1      load_0_15_16  20
 BV BND1      arc_0_15_17
 UP BND1      load_0_15_17  20
 BV BND1      arc_0_15_18
 UP BND1      load_0_15_18  20
 BV BND1      arc_0_15_19
 UP BND1      load_0_15_19  20
 BV BND1      arc_0_16_0
 UP BND1      load_0_16_0  20
 BV BND1      arc_0_16_1
 UP BND1      load_0_16_1  20
 BV BND1      arc_0_16_2
 UP BND1      load_0_16_2  20
 BV BND1      arc_0_16_3
 UP BND1      load_0_16_3  20
 BV BND1      arc_0_16_4
 UP BND1      load_0_16_4  20
 BV BND1      arc_0_16_12
 UP BND1      load_0_16_12  20
 BV BND1      arc_0_16_13
 UP BND1      load_0_16_13  20
 BV BND1      arc_0_16_14
 UP BND1      load_0_16_14  20
 BV BND1      arc_0_16_15
 UP BND1      load_0_16_15  20
 BV BND1      arc_0_16_17
 UP BND1      load_0_16_17  20
 BV BND1      arc_0_16_18
 UP BND1      load_0_16_18  20
 BV BND1      arc_0_16_19
 UP BND1      load_0_16_19  20
 BV BND1      arc_0_17_0
 UP BND1      load_0_17_0  20
 BV BND1      arc_0_17_1
 UP BND1      load_0_17_1  20
 BV BND1      arc_0_17_2
 UP BND1      load_0_17_2  20
 BV BND1      arc_0_17_3
 UP BND1      load_0_17_3  20
 BV BND1      arc_0_17_4
 UP BND1      load_0_17_4  20
 BV BND1      arc_0_17_12
 UP BND1      load_0_17_12  20
 BV BND1      arc_0_17_13
 UP BND1      load_0_17_13  20
 BV BND1      arc_0_17_14
 UP BND1      load_0_17_14  20
 BV BND1      arc_0_17_15
 UP BND1      load_0_17_15  20
 BV BND1      arc_0_17_16
 UP BND1      load_0_17_16  20
 BV BND1      arc_0_17_18
 UP BND1      load_0_17_18  20
 BV BND1      arc_0_17_19
 UP BND1      load_0_17_19  20
 BV BND1      arc_0_18_0
 UP BND1      load_0_18_0  20
 BV BND1      arc_0_18_1
 UP BND1      load_0_18_1  20
 BV BND1      arc_0_18_2
 UP BND1      load_0_18_2  20
 BV BND1      arc_0_18_3
 UP BND1      load_0_18_3  20
 BV BND1      arc_0_18_4
 UP BND1      load_0_18_4  20
 BV BND1      arc_0_18_12
 UP BND1      load_0_18_12  20
 BV BND1      arc_0_18_13
 UP BND1      load_0_18_13  20
 BV BND1      arc_0_18_14
 UP BND1      load_0_18_14  20
 BV BND1      arc_0_18_15
 UP BND1      load_0_18_15  20
 BV BND1      arc_0_18_16
 UP BND1      load_0_18_16  20
 BV BND1      arc_0_18_17
 UP BND1      load_0_18_17  20
 BV BND1      arc_0_18_19
 UP BND1      load_0_18_19  20
 BV BND1      arc_0_19_0
 UP BND1      load_0_19_0  20
 BV BND1      arc_0_19_1
 UP BND1      load_0_19_1  20
 BV BND1      arc_0_19_2
 UP BND1      load_0_19_2  20
 BV BND1      arc_0_19_3
 UP BND1      load_0_19_3  20
 BV BND1      arc_0_19_4
 UP BND1      load_0_19_4  20
 BV BND1      arc_0_19_12
 UP BND1      load_0_19_12  20
 BV BND1      arc_0_19_13
 UP BND1      load_0_19_13  20
 BV BND1      arc_0_19_14
 UP BND1      load_0_19_14  20
 BV BND1      arc_0_19_15
 UP BND1      load_0_19_15  20
 BV BND1      arc_0_19_16
 UP BND1      load_0_19_16  20
 BV BND1      arc_0_19_17
 UP BND1      load_0_19_17  20
 BV BND1      arc_0_19_18
 UP BND1      load_0_19_18  20
 FX BND1      visit_1_5  1
 UP BND1      order_1_5  11
 FX BND1      visit_1_6  1
 UP BND1      order_1_6  11
 FX BND1      visit_1_7  1
 UP BND1      order_1_7  11
 UP BND1      visit_1_12  1
 UP BND1      order_1_12  11
 UP BND1      visit_1_13  1
 UP BND1      order_1_13  11
 UP BND1      visit_1_14  1
 UP BND1      order_1_14  11
 UP BND1      visit_1_15  1
 UP BND1      order_1_15  11
 UP BND1      visit_1_16  1
 UP BND1      order_1_16  11
 UP BND1      visit_1_17  1
 UP BND1      order_1_17  11
 UP BND1      visit_1_18  1
 UP BND1      order_1_18  11
 UP BND1      visit_1_19  1
 UP BND1      order_1_19  11
 BV BND1      arc_1_0_0
 FX BND1      load_1_0_0  0
 BV BND1      arc_1_0_5
 FX BND1      load_1_0_5  0
 BV BND1      arc_1_0_6
 FX BND1      load_1_0_6  0
 BV BND1      arc_1_0_7
 FX BND1      load_1_0_7  0
 BV BND1      arc_1_0_12
 FX BND1      load_1_0_12  0
 BV BND1      arc_1_0_13
 FX BND1      load_1_0_13  0
 BV BND1      arc_1_0_14
 FX BND1      load_1_0_14  0
 BV BND1      arc_1_0_15
 FX BND1      load_1_0_15  0
 BV BND1      arc_1_0_16
 FX BND1      load_1_0_16  0
 BV BND1      arc_1_0_17
 FX BND1      load_1_0_17  0
 BV BND1      arc_1_0_18
 FX BND1      load_1_0_18  0
 BV BND1      arc_1_0_19
 FX BND1      load_1_0_19  0
 BV BND1      arc_1_5_0
 UP BND1      load_1_5_0  25
 BV BND1      arc_1_5_6
 UP BND1      load_1_5_6  25
 BV BND1      arc_1_5_7
 UP BND1      load_1_5_7  25
 BV BND1      arc_1_5_12
 UP BND1      load_1_5_12  25
 BV BND1      arc_1_5_13
 UP BND1      load_1_5_13  25
 BV BND1      arc_1_5_14
 UP BND1      load_1_5_14  25
 BV BND1      arc_1_5_15
 UP BND1      load_1_5_15  25
 BV BND1      arc_1_5_16
 UP BND1      load_1_5_16  25
 BV BND1      arc_1_5_17
 UP BND1      load_1_5_17  25
 BV BND1      arc_1_5_18
 UP BND1      load_1_5_18  25
 BV BND1      arc_1_5_19
 UP BND1      load_1_5_19  25
 BV BND1      arc_1_6_0
 UP BND1      load_1_6_0  25
 BV BND1      arc_1_6_5
 UP BND1      load_1_6_5  25
 BV BND1      arc_1_6_7
 UP BND1      load_1_6_7  25
 BV BND1      arc_1_6_12
 UP BND1      load_1_6_12  25
 BV BND1      arc_1_6_13
 UP BND1      load_1_6_13  25
 BV BND1      arc_1_6_14
 UP BND1      load_1_6_14  25
 BV BND1      arc_1_6_15
 UP BND1      load_1_6_15  25
 BV BND1      arc_1_6_16
 UP BND1      load_1_6_16  25
 BV BND1      arc_1_6_17
 UP BND1      load_1_6_17  25
 BV BND1      arc_1_6_18
 UP BND1      load_1_6_18  25
 BV BND1      arc_1_6_19
 UP BND1      load_1_6_19  25
 BV BND1      arc_1_7_0
 UP BND1      load_1_7_0  25
 BV BND1      arc_1_7_5
 UP BND1      load_1_7_5  25
 BV BND1      arc_1_7_6
 UP BND1      load_1_7_6  25
 BV BND1      arc_1_7_12
 UP BND1      load_1_7_12  25
 BV BND1      arc_1_7_13
 UP BND1      load_1_7_13  25
 BV BND1      arc_1_7_14
 UP BND1      load_1_7_14  25
 BV BND1      arc_1_7_15
 UP BND1      load_1_7_15  25
 BV BND1      arc_1_7_16
 UP BND1      load_1_7_16  25
 BV BND1      arc_1_7_17
 UP BND1      load_1_7_17  25
 BV BND1      arc_1_7_18
 UP BND1      load_1_7_18  25
 BV BND1      arc_1_7_19
 UP BND1      load_1_7_19  25
 BV BND1      arc_1_12_0
 UP BND1      load_1_12_0  25
 BV BND1      arc_1_12_5
 UP BND1      load_1_12_5  25
 BV BND1      arc_1_12_6
 UP BND1      load_1_12_6  25
 BV BND1      arc_1_12_7
 UP BND1      load_1_12_7  25
 BV BND1      arc_1_12_13
 UP BND1      load_1_12_13  25
 BV BND1      arc_1_12_14
 UP BND1      load_1_12_14  25
 BV BND1      arc_1_12_15
 UP BND1      load_1_12_15  25
 BV BND1      arc_1_12_16
 UP BND1      load_1_12_16  25
 BV BND1      arc_1_12_17
 UP BND1      load_1_12_17  25
 BV BND1      arc_1_12_18
 UP BND1      load_1_12_18  25
 BV BND1      arc_1_12_19
 UP BND1      load_1_12_19  25
 BV BND1      arc_1_13_0
 UP BND1      load_1_13_0  25
 BV BND1      arc_1_13_5
 UP BND1      load_1_13_5  25
 BV BND1      arc_1_13_6
 UP BND1      load_1_13_6  25
 BV BND1      arc_1_13_7
 UP BND1      load_1_13_7  25
 BV BND1      arc_1_13_12
 UP BND1      load_1_13_12  25
 BV BND1      arc_1_13_14
 UP BND1      load_1_13_14  25
 BV BND1      arc_1_13_15
 UP BND1      load_1_13_15  25
 BV BND1      arc_1_13_16
 UP BND1      load_1_13_16  25
 BV BND1      arc_1_13_17
 UP BND1      load_1_13_17  25
 BV BND1      arc_1_13_18
 UP BND1      load_1_13_18  25
 BV BND1      arc_1_13_19
 UP BND1      load_1_13_19  25
 BV BND1      arc_1_14_0
 UP BND1      load_1_14_0  25
 BV BND1      arc_1_14_5
 UP BND1      load_1_14_5  25
 BV BND1      arc_1_14_6
 UP BND1      load_1_14_6  25
 BV BND1      arc_1_14_7
 UP BND1      load_1_14_7  25
 BV BND1      arc_1_14_12
 UP BND1      load_1_14_12  25
 BV BND1      arc_1_14_13
 UP BND1      load_1_14_13  25
 BV BND1      arc_1_14_15
 UP BND1      load_1_14_15  25
 BV BND1      arc_1_14_16
 UP BND1      load_1_14_16  25
 BV BND1      arc_1_14_17
 UP BND1      load_1_14_17  25
 BV BND1      arc_1_14_18
 UP BND1      load_1_14_18  25
 BV BND1      arc_1_14_19
 UP BND1      load_1_14_19  25
 BV BND1      arc_1_15_0
 UP BND1      load_1_15_0  25
 BV BND1      arc_1_15_5
 UP BND1      load_1_15_5  25
 BV BND1      arc_1_15_6
 UP BND1      load_1_15_6  25
 BV BND1      arc_1_15_7
 UP BND1      load_1_15_7  25
 BV BND1      arc_1_15_12
 UP BND1      load_1_15_12  25
 BV BND1      arc_1_15_13
 UP BND1      load_1_15_13  25
 BV BND1      arc_1_15_14
 UP BND1      load_1_15_14  25
 BV BND1      arc_1_15_16
 UP BND1      load_1_15_16  25
 BV BND1      arc_1_15_17
 UP BND1      load_1_15_17  25
 BV BND1      arc_1_15_18
 UP BND1      load_1_15_18  25
 BV BND1      arc_1_15_19
 UP BND1      load_1_15_19  25
 BV BND1      arc_1_16_0
 UP BND1      load_1_16_0  25
 BV BND1      arc_1_16_5
 UP BND1      load_1_16_5  25
 BV BND1      arc_1_16_6
 UP BND1      load_1_16_6  25
 BV BND1      arc_1_16_7
 UP BND1      load_1_16_7  25
 BV BND1      arc_1_16_12
 UP BND1      load_1_16_12  25
 BV BND1      arc_1_16_13
 UP BND1      load_1_16_13  25
 BV BND1      arc_1_16_14
 UP BND1      load_1_16_14  25
 BV BND1      arc_1_16_15
 UP BND1      load_1_16_15  25
 BV BND1      arc_1_16_17
 UP BND1      load_1_16_17  25
 BV BND1      arc_1_16_18
 UP BND1      load_1_16_18  25
 BV BND1      arc_1_16_19
 UP BND1      load_1_16_19  25
 BV BND1      arc_1_17_0
 UP BND1      load_1_17_0  25
 BV BND1      arc_1_17_5
 UP BND1      load_1_17_5  25
 BV BND1      arc_1_17_6
 UP BND1      load_1_17_6  25
 BV BND1      arc_1_17_7
 UP BND1      load_1_17_7  25
 BV BND1      arc_1_17_12
 UP BND1      load_1_17_12  25
 BV BND1      arc_1_17_13
 UP BND1      load_1_17_13  25
 BV BND1      arc_1_17_14
 UP BND1      load_1_17_14  25
 BV BND1      arc_1_17_15
 UP BND1      load_1_17_15  25
 BV BND1      arc_1_17_16
 UP BND1      load_1_17_16  25
 BV BND1      arc_1_17_18
 UP BND1      load_1_17_18  25
 BV BND1      arc_1_17_19
 UP BND1      load_1_17_19  25
 BV BND1      arc_1_18_0
 UP BND1      load_1_18_0  25
 BV BND1      arc_1_18_5
 UP BND1      load_1_18_5  25
 BV BND1      arc_1_18_6
 UP BND1      load_1_18_6  25
 BV BND1      arc_1_18_7
 UP BND1      load_1_18_7  25
 BV BND1      arc_1_18_12
 UP BND1      load_1_18_12  25
 BV BND1      arc_1_18_13
 UP BND1      load_1_18_13  25
 BV BND1      arc_1_18_14
 UP BND1      load_1_18_14  25
 BV BND1      arc_1_18_15
 UP BND1      load_1_18_15  25
 BV BND1      arc_1_18_16
 UP BND1      load_1_18_16  25
 BV BND1      arc_1_18_17
 UP BND1      load_1_18_17  25
 BV BND1      arc_1_18_19
 UP BND1      load_1_18_19  25
 BV BND1      arc_1_19_0
 UP BND1      load_1_19_0  25
 BV BND1      arc_1_19_5
 UP BND1      load_1_19_5  25
 BV BND1      arc_1_19_6
 UP BND1      load_1_19_6  25
 BV BND1      arc_1_19_7
 UP BND1      load_1_19_7  25
 BV BND1      arc_1_19_12
 UP BND1      load_1_19_12  25
 BV BND1      arc_1_19_13
 UP BND1      load_1_19_13  25
 BV BND1      arc_1_19_14
 UP BND1      load_1_19_14  25
 BV BND1      arc_1_19_15
 UP BND1      load_1_19_15  25
 BV BND1      arc_1_19_16
 UP BND1      load_1_19_16  25
 BV BND1      arc_1_19_17
 UP BND1      load_1_19_17  25
 BV BND1      arc_1_19_18
 UP BND1      load_1_19_18  25
 FX BND1      visit_2_8  1
 UP BND1      order_2_8  12
 FX BND1      visit_2_9  1
 UP BND1      order_2_9  12
 FX BND1      visit_2_10  1
 UP BND1      order_2_10  12
 FX BND1      visit_2_11  1
 UP BND1      order_2_11  12
 UP BND1      visit_2_12  1
 UP BND1      order_2_12  12
 UP BND1      visit_2_13  1
 UP BND1      order_2_13  12
 UP BND1      visit_2_14  1
 UP BND1      order_2_14  12
 UP BND1      visit_2_15  1
 UP BND1      order_2_15  12
 UP BND1      visit_2_16  1
 UP BND1      order_2_16  12
 UP BND1      visit_2_17  1
 UP BND1      order_2_17  12
 UP BND1      visit_2_18  1
 UP BND1      order_2_18  12
 UP BND1      visit_2_19  1
 UP BND1      order_2_19  12
 BV BND1      arc_2_0_0
 FX BND1      load_2_0_0  0
 BV BND1      arc_2_0_8
 FX BND1      load_2_0_8  0
 BV BND1      arc_2_0_9
 FX BND1      load_2_0_9  0
 BV BND1      arc_2_0_10
 FX BND1      load_2_0_10  0
 BV BND1      arc_2_0_11
 FX BND1      load_2_0_11  0
 BV BND1      arc_2_0_12
 FX BND1      load_2_0_12  0
 BV BND1      arc_2_0_13
 FX BND1      load_2_0_13  0
 BV BND1      arc_2_0_14
 FX BND1      load_2_0_14  0
 BV BND1      arc_2_0_15
 FX BND1      load_2_0_15  0
 BV BND1      arc_2_0_16
 FX BND1      load_2_0_16  0
 BV BND1      arc_2_0_17
 FX BND1      load_2_0_17  0
 BV BND1      arc_2_0_18
 FX BND1      load_2_0_18  0
 BV BND1      arc_2_0_19
 FX BND1      load_2_0_19  0
 BV BND1      arc_2_8_0
 UP BND1      load_2_8_0  30
 BV BND1      arc_2_8_9
 UP BND1      load_2_8_9  30
 BV BND1      arc_2_8_10
 UP BND1      load_2_8_10  30
 BV BND1      arc_2_8_11
 UP BND1      load_2_8_11  30
 BV BND1      arc_2_8_12
 UP BND1      load_2_8_12  30
 BV BND1      arc_2_8_13
 UP BND1      load_2_8_13  30
 BV BND1      arc_2_8_14
 UP BND1      load_2_8_14  30
 BV BND1      arc_2_8_15
 UP BND1      load_2_8_15  30
 BV BND1      arc_2_8_16
 UP BND1      load_2_8_16  30
 BV BND1      arc_2_8_17
 UP BND1      load_2_8_17  30
 BV BND1      arc_2_8_18
 UP BND1      load_2_8_18  30
 BV BND1      arc_2_8_19
 UP BND1      load_2_8_19  30
 BV BND1      arc_2_9_0
 UP BND1      load_2_9_0  30
 BV BND1      arc_2_9_8
 UP BND1      load_2_9_8  30
 BV BND1      arc_2_9_10
 UP BND1      load_2_9_10  30
 BV BND1      arc_2_9_11
 UP BND1      load_2_9_11  30
 BV BND1      arc_2_9_12
 UP BND1      load_2_9_12  30
 BV BND1      arc_2_9_13
 UP BND1      load_2_9_13  30
 BV BND1      arc_2_9_14
 UP BND1      load_2_9_14  30
 BV BND1      arc_2_9_15
 UP BND1      load_2_9_15  30
 BV BND1      arc_2_9_16
 UP BND1      load_2_9_16  30
 BV BND1      arc_2_9_17
 UP BND1      load_2_9_17  30
 BV BND1      arc_2_9_18
 UP BND1      load_2_9_18  30
 BV BND1      arc_2_9_19
 UP BND1      load_2_9_19  30
 BV BND1      arc_2_10_0
 UP BND1      load_2_10_0  30
 BV BND1      arc_2_10_8
 UP BND1      load_2_10_8  30
 BV BND1      arc_2_10_9
 UP BND1      load_2_10_9  30
 BV BND1      arc_2_10_11
 UP BND1      load_2_10_11  30
 BV BND1      arc_2_10_12
 UP BND1      load_2_10_12  30
 BV BND1      arc_2_10_13
 UP BND1      load_2_10_13  30
 BV BND1      arc_2_10_14
 UP BND1      load_2_10_14  30
 BV BND1      arc_2_10_15
 UP BND1      load_2_10_15  30
 BV BND1      arc_2_10_16
 UP BND1      load_2_10_16  30
 BV BND1      arc_2_10_17
 UP BND1      load_2_10_17  30
 BV BND1      arc_2_10_18
 UP BND1      load_2_10_18  30
 BV BND1      arc_2_10_19
 UP BND1      load_2_10_19  30
 BV BND1      arc_2_11_0
 UP BND1      load_2_11_0  30
 BV BND1      arc_2_11_8
 UP BND1      load_2_11_8  30
 BV BND1      arc_2_11_9
 UP BND1      load_2_11_9  30
 BV BND1      arc_2_11_10
 UP BND1      load_2_11_10  30
 BV BND1      arc_2_11_12
 UP BND1      load_2_11_12  30
 BV BND1      arc_2_11_13
 UP BND1      load_2_11_13  30
 BV BND1      arc_2_11_14
 UP BND1      load_2_11_14  30
 BV BND1      arc_2_11_15
 UP BND1      load_2_11_15  30
 BV BND1      arc_2_11_16
 UP BND1      load_2_11_16  30
 BV BND1      arc_2_11_17
 UP BND1      load_2_11_17  30
 BV BND1      arc_2_11_18
 UP BND1      load_2_11_18  30
 BV BND1      arc_2_11_19
 UP BND1      load_2_11_19  30
 BV BND1      arc_2_12_0
 UP BND1      load_2_12_0  30
 BV BND1      arc_2_12_8
 UP BND1      load_2_12_8  30
 BV BND1      arc_2_12_9
 UP BND1      load_2_12_9  30
 BV BND1      arc_2_12_10
 UP BND1      load_2_12_10  30
 BV BND1      arc_2_12_11
 UP BND1      load_2_12_11  30
 BV BND1      arc_2_12_13
 UP BND1      load_2_12_13  30
 BV BND1      arc_2_12_14
 UP BND1      load_2_12_14  30
 BV BND1      arc_2_12_15
 UP BND1      load_2_12_15  30
 BV BND1      arc_2_12_16
 UP BND1      load_2_12_16  30
 BV BND1      arc_2_12_17
 UP BND1      load_2_12_17  30
 BV BND1      arc_2_12_18
 UP BND1      load_2_12_18  30
 BV BND1      arc_2_12_19
 UP BND1      load_2_12_19  30
 BV BND1      arc_2_13_0
 UP BND1      load_2_13_0  30
 BV BND1      arc_2_13_8
 UP BND1      load_2_13_8  30
 BV BND1      arc_2_13_9
 UP BND1      load_2_13_9  30
 BV BND1      arc_2_13_10
 UP BND1      load_2_13_10  30
 BV BND1      arc_2_13_11
 UP BND1      load_2_13_11  30
 BV BND1      arc_2_13_12
 UP BND1      load_2_13_12  30
 BV BND1      arc_2_13_14
 UP BND1      load_2_13_14  30
 BV BND1      arc_2_13_15
 UP BND1      load_2_13_15  30
 BV BND1      arc_2_13_16
 UP BND1      load_2_13_16  30
 BV BND1      arc_2_13_17
 UP BND1      load_2_13_17  30
 BV BND1      arc_2_13_18
 UP BND1      load_2_13_18  30
 BV BND1      arc_2_13_19
 UP BND1      load_2_13_19  30
 BV BND1      arc_2_14_0
 UP BND1      load_2_14_0  30
 BV BND1      arc_2_14_8
 UP BND1      load_2_14_8  30
 BV BND1      arc_2_14_9
 UP BND1      load_2_14_9  30
 BV BND1      arc_2_14_10
 UP BND1      load_2_14_10  30
 BV BND1      arc_2_14_11
 UP BND1      load_2_14_11  30
 BV BND1      arc_2_14_12
 UP BND1      load_2_14_12  30
 BV BND1      arc_2_14_13
 UP BND1      load_2_14_13  30
 BV BND1      arc_2_14_15
 UP BND1      load_2_14_15  30
 BV BND1      arc_2_14_16
 UP BND1      load_2_14_16  30
 BV BND1      arc_2_14_17
 UP BND1      load_2_14_17  30
 BV BND1      arc_2_14_18
 UP BND1      load_2_14_18  30
 BV BND1      arc_2_14_19
 UP BND1      load_2_14_19  30
 BV BND1      arc_2_15_0
 UP BND1      load_2_15_0  30
 BV BND1      arc_2_15_8
 UP BND1      load_2_15_8  30
 BV BND1      arc_2_15_9
 UP BND1      load_2_15_9  30
 BV BND1      arc_2_15_10
 UP BND1      load_2_15_10  30
 BV BND1      arc_2_15_11
 UP BND1      load_2_15_11  30
 BV BND1      arc_2_15_12
 UP BND1      load_2_15_12  30
 BV BND1      arc_2_15_13
 UP BND1      load_2_15_13  30
 BV BND1      arc_2_15_14
 UP BND1      load_2_15_14  30
 BV BND1      arc_2_15_16
 UP BND1      load_2_15_16  30
 BV BND1      arc_2_15_17
 UP BND1      load_2_15_17  30
 BV BND1      arc_2_15_18
 UP BND1      load_2_15_18  30
 BV BND1      arc_2_15_19
 UP BND1      load_2_15_19  30
 BV BND1      arc_2_16_0
 UP BND1      load_2_16_0  30
 BV BND1      arc_2_16_8
 UP BND1      load_2_16_8  30
 BV BND1      arc_2_16_9
 UP BND1      load_2_16_9  30
 BV BND1      arc_2_16_10
 UP BND1      load_2_16_10  30
 BV BND1      arc_2_16_11
 UP BND1      load_2_16_11  30
 BV BND1      arc_2_16_12
 UP BND1      load_2_16_12  30
 BV BND1      arc_2_16_13
 UP BND1      load_2_16_13  30
 BV BND1      arc_2_16_14
 UP BND1      load_2_16_14  30
 BV BND1      arc_2_16_15
 UP BND1      load_2_16_15  30
 BV BND1      arc_2_16_17
 UP BND1      load_2_16_17  30
 BV BND1      arc_2_16_18
 UP BND1      load_2_16_18  30
 BV BND1      arc_2_16_19
 UP BND1      load_2_16_19  30
 BV BND1      arc_2_17_0
 UP BND1      load_2_17_0  30
 BV BND1      arc_2_17_8
 UP BND1      load_2_17_8  30
 BV BND1      arc_2_17_9
 UP BND1      load_2_17_9  30
 BV BND1      arc_2_17_10
 UP BND1      load_2_17_10  30
 BV BND1      arc_2_17_11
 UP BND1      load_2_17_11  30
 BV BND1      arc_2_17_12
 UP BND1      load_2_17_12  30
 BV BND1      arc_2_17_13
 UP BND1      load_2_17_13  30
 BV BND1      arc_2_17_14
 UP BND1      load_2_17_14  30
 BV BND1      arc_2_17_15
 UP BND1      load_2_17_15  30
 BV BND1      arc_2_17_16
 UP BND1      load_2_17_16  30
 BV BND1      arc_2_17_18
 UP BND1      load_2_17_18  30
 BV BND1      arc_2_17_19
 UP BND1      load_2_17_19  30
 BV BND1      arc_2_18_0
 UP BND1      load_2_18_0  30
 BV BND1      arc_2_18_8
 UP BND1      load_2_18_8  30
 BV BND1      arc_2_18_9
 UP BND1      load_2_18_9  30
 BV BND1      arc_2_18_10
 UP BND1      load_2_18_10  30
 BV BND1      arc_2_18_11
 UP BND1      load_2_18_11  30
 BV BND1      arc_2_18_12
 UP BND1      load_2_18_12  30
 BV BND1      arc_2_18_13
 UP BND1      load_2_18_13  30
 BV BND1      arc_2_18_14
 UP BND1      load_2_18_14  30
 BV BND1      arc_2_18_15
 UP BND1      load_2_18_15  30
 BV BND1      arc_2_18_16
 UP BND1      load_2_18_16  30
 BV BND1      arc_2_18_17
 UP BND1      load_2_18_17  30
 BV BND1      arc_2_18_19
 UP BND1      load_2_18_19  30
 BV BND1      arc_2_19_0
 UP BND1      load_2_19_0  30
 BV BND1      arc_2_19_8
 UP BND1      load_2_19_8  30
 BV BND1      arc_2_19_9
 UP BND1      load_2_19_9  30
 BV BND1      arc_2_19_10
 UP BND1      load_2_19_10  30
 BV BND1      arc_2_19_11
 UP BND1      load_2_19_11  30
 BV BND1      arc_2_19_12
 UP BND1      load_2_19_12  30
 BV BND1      arc_2_19_13
 UP BND1      load_2_19_13  30
 BV BND1      arc_2_19_14
 UP BND1      load_2_19_14  30
 BV BND1      arc_2_19_15
 UP BND1      load_2_19_15  30
 BV BND1      arc_2_19_16
 UP BND1      load_2_19_16  30
 BV BND1      arc_2_19_17
 UP BND1      load_2_19_17  30
 BV BND1      arc_2_19_18
 UP BND1      load_2_19_18  30
ENDATA
