* Signature: 0x861606b21aadb15
NAME 
ROWS
 N  OBJ
 G  floor   
COLUMNS
    F_linear  OBJ       1
    F_linear  floor     1
    MARKER    'MARKER'                 'INTORG'
    r141_b    OBJ       0
    MARKER    'MARKER'                 'INTEND'
RHS
    RHS1      OBJ       -0.25
    RHS1      floor     -1.5000000000000002e-01
BOUNDS
 BV BND1      r141_b  
ENDATA
