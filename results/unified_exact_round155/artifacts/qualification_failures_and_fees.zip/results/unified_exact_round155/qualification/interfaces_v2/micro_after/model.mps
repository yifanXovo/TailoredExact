* Signature: 0x86ad205b877fe769
NAME 
ROWS
 N  OBJ
 E  onehot_1
 E  onehot_2
 G  total_lower
 E  hull_convexity
 E  hull_link_1_1
 E  hull_link_2_1
 G  hull_gini
COLUMNS
    G         OBJ       1
    G         hull_gini  1
    state_1_0  onehot_1  1
    state_1_1  OBJ       0.2
    state_1_1  onehot_1  1
    state_1_1  total_lower  1
    state_1_1  hull_link_1_1  -1
    state_2_0  onehot_2  1
    state_2_1  OBJ       0.3
    state_2_1  onehot_2  1
    state_2_1  total_lower  1
    state_2_1  hull_link_2_1  -1
    hull_lambda_00000  hull_convexity  1
    hull_lambda_00000  hull_gini  -0.5
    hull_lambda_00000  hull_link_1_1  1
    hull_lambda_00001  hull_convexity  1
    hull_lambda_00001  hull_gini  -0.5
    hull_lambda_00001  hull_link_2_1  1
    hull_lambda_00002  hull_convexity  1
    hull_lambda_00002  hull_link_1_1  1
    hull_lambda_00002  hull_link_2_1  1
RHS
    RHS1      onehot_1  1
    RHS1      onehot_2  1
    RHS1      total_lower  1
    RHS1      hull_convexity  1
    RHS1      hull_gini  1e-08
BOUNDS
 UP BND1      G         1
 UP BND1      state_1_0  1
 UP BND1      state_1_1  1
 UP BND1      state_2_0  1
 UP BND1      state_2_1  1
ENDATA
