* Signature: 0x1e2c8044c59d3280
NAME R157_free_fleet_original_T
ROWS
 N  OBJ
 E  select_one_1
 E  select_one_2
 E  assign_service_2_1
 L  arc_capacity_0_0_2
 L  arc_capacity_0_2_0
 L  depart_once_0
 E  return_once_0
 E  out_degree_0_2
 E  in_degree_0_2
 E  load_conservation_0_2
 G  order_lb_0_2
 L  order_ub_0_2
 L  original_time_0
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    select[1,1]  select_one_1  1
    select[2,1]  select_one_2  1
    select[2,1]  assign_service_2_1  -1
    service[0,2,1]  assign_service_2_1  1
    service[0,2,1]  out_degree_0_2  -1
    service[0,2,1]  in_degree_0_2  -1
    service[0,2,1]  load_conservation_0_2  1
    service[0,2,1]  order_lb_0_2  -1
    service[0,2,1]  order_ub_0_2  -2
    arc[0,0,2]  arc_capacity_0_0_2  -3
    arc[0,0,2]  depart_once_0  1
    arc[0,0,2]  return_once_0  1
    arc[0,0,2]  in_degree_0_2  1
    arc[0,0,2]  original_time_0  2
    arc[0,2,0]  arc_capacity_0_2_0  -3
    arc[0,2,0]  return_once_0  -1
    arc[0,2,0]  out_degree_0_2  1
    arc[0,2,0]  original_time_0  2
    MARKER    'MARKER'                 'INTEND'
    load[0,0,2]  arc_capacity_0_0_2  1
    load[0,0,2]  load_conservation_0_2  -1
    load[0,2,0]  arc_capacity_0_2_0  1
    load[0,2,0]  load_conservation_0_2  1
    order[0,2]  order_lb_0_2  1
    order[0,2]  order_ub_0_2  1
RHS
    RHS1      select_one_1  1
    RHS1      select_one_2  1
    RHS1      depart_once_0  1
    RHS1      original_time_0  100
BOUNDS
 BV BND1      select[1,1]
 BV BND1      select[2,1]
 BV BND1      service[0,2,1]
 BV BND1      arc[0,0,2]
 BV BND1      arc[0,2,0]
 FX BND1      load[0,0,2]  0
 UP BND1      order[0,2]  2
ENDATA
