* Signature: 0xa37f927b641d0750
NAME 
ROWS
 N  OBJ
 E  onehot_1
 E  inventory_1
 E  ratio_1 
 E  onehot_2
 E  inventory_2
 E  ratio_2 
 E  onehot_3
 E  inventory_3
 E  ratio_3 
 E  onehot_4
 E  inventory_4
 E  ratio_4 
 E  onehot_5
 E  inventory_5
 E  ratio_5 
 E  onehot_6
 E  inventory_6
 E  ratio_6 
 E  onehot_7
 E  inventory_7
 E  ratio_7 
 E  onehot_8
 E  inventory_8
 E  ratio_8 
 E  onehot_9
 E  inventory_9
 E  ratio_9 
 E  onehot_10
 E  inventory_10
 E  ratio_10
 E  onehot_11
 E  inventory_11
 E  ratio_11
 E  onehot_12
 E  inventory_12
 E  ratio_12
 E  onehot_13
 E  inventory_13
 E  ratio_13
 E  onehot_14
 E  inventory_14
 E  ratio_14
 E  onehot_15
 E  inventory_15
 E  ratio_15
 E  onehot_16
 E  inventory_16
 E  ratio_16
 E  onehot_17
 E  inventory_17
 E  ratio_17
 E  onehot_18
 E  inventory_18
 E  ratio_18
 E  onehot_19
 E  inventory_19
 E  ratio_19
 E  onehot_20
 E  inventory_20
 E  ratio_20
 G  R60     
 G  R61     
 G  R62     
 G  R63     
 G  R64     
 G  R65     
 G  R66     
 G  R67     
 G  R68     
 G  R69     
 G  R70     
 G  R71     
 G  R72     
 G  R73     
 G  R74     
 G  R75     
 G  R76     
 G  R77     
 G  R78     
 G  R79     
 G  R80     
 G  R81     
 G  R82     
 G  R83     
 G  R84     
 G  R85     
 G  R86     
 G  R87     
 G  R88     
 G  R89     
 G  R90     
 G  R91     
 G  R92     
 G  R93     
 G  R94     
 G  R95     
 G  R96     
 G  R97     
 G  R98     
 G  R99     
 G  R100    
 G  R101    
 G  R102    
 G  R103    
 G  R104    
 G  R105    
 G  R106    
 G  R107    
 G  R108    
 G  R109    
 G  R110    
 G  R111    
 G  R112    
 G  R113    
 G  R114    
 G  R115    
 G  R116    
 G  R117    
 G  R118    
 G  R119    
 G  R120    
 G  R121    
 G  R122    
 G  R123    
 G  R124    
 G  R125    
 G  R126    
 G  R127    
 G  R128    
 G  R129    
 G  R130    
 G  R131    
 G  R132    
 G  R133    
 G  R134    
 G  R135    
 G  R136    
 G  R137    
 G  R138    
 G  R139    
 G  R140    
 G  R141    
 G  R142    
 G  R143    
 G  R144    
 G  R145    
 G  R146    
 G  R147    
 G  R148    
 G  R149    
 G  R150    
 G  R151    
 G  R152    
 G  R153    
 G  R154    
 G  R155    
 G  R156    
 G  R157    
 G  R158    
 G  R159    
 G  R160    
 G  R161    
 G  R162    
 G  R163    
 G  R164    
 G  R165    
 G  R166    
 G  R167    
 G  R168    
 G  R169    
 G  R170    
 G  R171    
 G  R172    
 G  R173    
 G  R174    
 G  R175    
 G  R176    
 G  R177    
 G  R178    
 G  R179    
 G  R180    
 G  R181    
 G  R182    
 G  R183    
 G  R184    
 G  R185    
 G  R186    
 G  R187    
 G  R188    
 G  R189    
 G  R190    
 G  R191    
 G  R192    
 G  R193    
 G  R194    
 G  R195    
 G  R196    
 G  R197    
 G  R198    
 G  R199    
 G  R200    
 G  R201    
 G  R202    
 G  R203    
 G  R204    
 G  R205    
 G  R206    
 G  R207    
 G  R208    
 G  R209    
 G  R210    
 G  R211    
 G  R212    
 G  R213    
 G  R214    
 G  R215    
 G  R216    
 G  R217    
 G  R218    
 G  R219    
 G  R220    
 G  R221    
 G  R222    
 G  R223    
 G  R224    
 G  R225    
 G  R226    
 G  R227    
 G  R228    
 G  R229    
 G  R230    
 G  R231    
 G  R232    
 G  R233    
 G  R234    
 G  R235    
 G  R236    
 G  R237    
 G  R238    
 G  R239    
 G  R240    
 G  R241    
 G  R242    
 G  R243    
 G  R244    
 G  R245    
 G  R246    
 G  R247    
 G  R248    
 G  R249    
 G  R250    
 G  R251    
 G  R252    
 G  R253    
 G  R254    
 G  R255    
 G  R256    
 G  R257    
 G  R258    
 G  R259    
 G  R260    
 G  R261    
 G  R262    
 G  R263    
 G  R264    
 G  R265    
 G  R266    
 G  R267    
 G  R268    
 G  R269    
 G  R270    
 G  R271    
 G  R272    
 G  R273    
 G  R274    
 G  R275    
 G  R276    
 G  R277    
 G  R278    
 G  R279    
 G  R280    
 G  R281    
 G  R282    
 G  R283    
 G  R284    
 G  R285    
 G  R286    
 G  R287    
 G  R288    
 G  R289    
 G  R290    
 G  R291    
 G  R292    
 G  R293    
 G  R294    
 G  R295    
 G  R296    
 G  R297    
 G  R298    
 G  R299    
 G  R300    
 G  R301    
 G  R302    
 G  R303    
 G  R304    
 G  R305    
 G  R306    
 G  R307    
 G  R308    
 G  R309    
 G  R310    
 G  R311    
 G  R312    
 G  R313    
 G  R314    
 G  R315    
 G  R316    
 G  R317    
 G  R318    
 G  R319    
 G  R320    
 G  R321    
 G  R322    
 G  R323    
 G  R324    
 G  R325    
 G  R326    
 G  R327    
 G  R328    
 G  R329    
 G  R330    
 G  R331    
 G  R332    
 G  R333    
 G  R334    
 G  R335    
 G  R336    
 G  R337    
 G  R338    
 G  R339    
 G  R340    
 G  R341    
 G  R342    
 G  R343    
 G  R344    
 G  R345    
 G  R346    
 G  R347    
 G  R348    
 G  R349    
 G  R350    
 G  R351    
 G  R352    
 G  R353    
 G  R354    
 G  R355    
 G  R356    
 G  R357    
 G  R358    
 G  R359    
 G  R360    
 G  R361    
 G  R362    
 G  R363    
 G  R364    
 G  R365    
 G  R366    
 G  R367    
 G  R368    
 G  R369    
 G  R370    
 G  R371    
 G  R372    
 G  R373    
 G  R374    
 G  R375    
 G  R376    
 G  R377    
 G  R378    
 G  R379    
 G  R380    
 G  R381    
 G  R382    
 G  R383    
 G  R384    
 G  R385    
 G  R386    
 G  R387    
 G  R388    
 G  R389    
 G  R390    
 G  R391    
 G  R392    
 G  R393    
 G  R394    
 G  R395    
 G  R396    
 G  R397    
 G  R398    
 G  R399    
 G  R400    
 G  R401    
 G  R402    
 G  R403    
 G  R404    
 G  R405    
 G  R406    
 G  R407    
 G  R408    
 G  R409    
 G  R410    
 G  R411    
 G  R412    
 G  R413    
 G  R414    
 G  R415    
 G  R416    
 G  R417    
 G  R418    
 G  R419    
 G  R420    
 G  R421    
 G  R422    
 G  R423    
 G  R424    
 G  R425    
 G  R426    
 G  R427    
 G  R428    
 G  R429    
 G  R430    
 G  R431    
 G  R432    
 G  R433    
 G  R434    
 G  R435    
 G  R436    
 G  R437    
 G  R438    
 G  R439    
 G  hard_lower
 L  hard_upper
 G  bin_lower
 L  bin_upper
 L  surrogate_G
 L  physical_G_upper
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    x[1,11]   OBJ       1.7431264764944385e-18
    x[1,11]   onehot_1  1
    x[1,11]   inventory_1  -11
    x[2,14]   OBJ       5.6471577414285437e-18
    x[2,14]   onehot_2  1
    x[2,14]   inventory_2  -14
    x[3,15]   OBJ       1.6206765096615783e-18
    x[3,15]   onehot_3  1
    x[3,15]   inventory_3  -15
    x[3,24]   OBJ       -2.0974679444036790e-02
    x[3,24]   onehot_3  1
    x[3,24]   inventory_3  -24
    x[4,11]   OBJ       1.7431264764944385e-18
    x[4,11]   onehot_4  1
    x[4,11]   inventory_4  -11
    x[5,11]   OBJ       1.7431264764944385e-18
    x[5,11]   onehot_5  1
    x[5,11]   inventory_5  -11
    x[5,18]   OBJ       -2.2070298389293381e-02
    x[5,18]   onehot_5  1
    x[5,18]   inventory_5  -18
    x[6,11]   OBJ       1.7431264764944385e-18
    x[6,11]   onehot_6  1
    x[6,11]   inventory_6  -11
    x[6,20]   OBJ       -2.8356709037274455e-02
    x[6,20]   onehot_6  1
    x[6,20]   inventory_6  -20
    x[7,10]   OBJ       2.8812036090286598e-18
    x[7,10]   onehot_7  1
    x[7,10]   inventory_7  -10
    x[8,11]   OBJ       1.7431264764944385e-18
    x[8,11]   onehot_8  1
    x[8,11]   inventory_8  -11
    x[9,9]    OBJ       2.3337748400464873e-18
    x[9,9]    onehot_9  1
    x[9,9]    inventory_9  -9
    x[10,16]  onehot_10  1
    x[10,16]  inventory_10  -16
    x[11,17]  OBJ       2.0816681711721684e-18
    x[11,17]  onehot_11  1
    x[11,17]  inventory_11  -17
    x[12,10]  OBJ       2.8812036090286598e-18
    x[12,10]  onehot_12  1
    x[12,10]  inventory_12  -10
    x[12,18]  OBJ       -2.8752309965489543e-02
    x[12,18]  onehot_12  1
    x[12,18]  inventory_12  -18
    x[13,13]  OBJ       4.86923001918882e-18
    x[13,13]  onehot_13  1
    x[13,13]  inventory_13  -13
    x[14,13]  OBJ       4.86923001918882e-18
    x[14,13]  onehot_14  1
    x[14,13]  inventory_14  -13
    x[15,14]  OBJ       5.6471577414285437e-18
    x[15,14]  onehot_15  1
    x[15,14]  inventory_15  -14
    x[16,12]  OBJ       4.1489311985998257e-18
    x[16,12]  onehot_16  1
    x[16,12]  inventory_16  -12
    x[16,21]  OBJ       -2.6011380957241148e-02
    x[16,21]  onehot_16  1
    x[16,21]  inventory_16  -21
    x[17,8]   onehot_17  1
    x[17,8]   inventory_17  -8
    x[17,16]  OBJ       -3.3869442472836957e-02
    x[17,16]  onehot_17  1
    x[17,16]  inventory_17  -16
    x[18,11]  OBJ       1.7431264764944385e-18
    x[18,11]  onehot_18  1
    x[18,11]  inventory_18  -11
    x[18,20]  OBJ       -2.7883337278719278e-02
    x[18,20]  onehot_18  1
    x[18,20]  inventory_18  -20
    x[19,12]  OBJ       4.1489311985998257e-18
    x[19,12]  onehot_19  1
    x[19,12]  inventory_19  -12
    x[19,20]  OBJ       -2.1873723676178642e-02
    x[19,20]  onehot_19  1
    x[19,20]  inventory_19  -20
    x[20,13]  OBJ       4.86923001918882e-18
    x[20,13]  onehot_20  1
    x[20,13]  inventory_20  -13
    x[20,21]  OBJ       -2.1914977414928340e-02
    x[20,21]  onehot_20  1
    x[20,21]  inventory_20  -21
    MARKER    'MARKER'                 'INTEND'
    Y[1]      inventory_1  1
    Y[1]      ratio_1   -9.0909090909090912e-02
    Y[1]      hard_lower  1
    Y[1]      hard_upper  1
    Y[2]      inventory_2  1
    Y[2]      ratio_2   -7.1428571428571425e-02
    Y[2]      hard_lower  1
    Y[2]      hard_upper  1
    Y[3]      inventory_3  1
    Y[3]      ratio_3   -6.6666666666666666e-02
    Y[3]      hard_lower  1
    Y[3]      hard_upper  1
    Y[4]      inventory_4  1
    Y[4]      ratio_4   -9.0909090909090912e-02
    Y[4]      hard_lower  1
    Y[4]      hard_upper  1
    Y[5]      inventory_5  1
    Y[5]      ratio_5   -9.0909090909090912e-02
    Y[5]      hard_lower  1
    Y[5]      hard_upper  1
    Y[6]      inventory_6  1
    Y[6]      ratio_6   -9.0909090909090912e-02
    Y[6]      hard_lower  1
    Y[6]      hard_upper  1
    Y[7]      inventory_7  1
    Y[7]      ratio_7   -0.1
    Y[7]      hard_lower  1
    Y[7]      hard_upper  1
    Y[8]      inventory_8  1
    Y[8]      ratio_8   -9.0909090909090912e-02
    Y[8]      hard_lower  1
    Y[8]      hard_upper  1
    Y[9]      inventory_9  1
    Y[9]      ratio_9   -1.1111111111111110e-01
    Y[9]      hard_lower  1
    Y[9]      hard_upper  1
    Y[10]     inventory_10  1
    Y[10]     ratio_10  -0.0625
    Y[10]     hard_lower  1
    Y[10]     hard_upper  1
    Y[11]     inventory_11  1
    Y[11]     ratio_11  -5.8823529411764705e-02
    Y[11]     hard_lower  1
    Y[11]     hard_upper  1
    Y[12]     inventory_12  1
    Y[12]     ratio_12  -0.1
    Y[12]     hard_lower  1
    Y[12]     hard_upper  1
    Y[13]     inventory_13  1
    Y[13]     ratio_13  -7.6923076923076927e-02
    Y[13]     hard_lower  1
    Y[13]     hard_upper  1
    Y[14]     inventory_14  1
    Y[14]     ratio_14  -7.6923076923076927e-02
    Y[14]     hard_lower  1
    Y[14]     hard_upper  1
    Y[15]     inventory_15  1
    Y[15]     ratio_15  -7.1428571428571425e-02
    Y[15]     hard_lower  1
    Y[15]     hard_upper  1
    Y[16]     inventory_16  1
    Y[16]     ratio_16  -8.3333333333333329e-02
    Y[16]     hard_lower  1
    Y[16]     hard_upper  1
    Y[17]     inventory_17  1
    Y[17]     ratio_17  -0.125
    Y[17]     hard_lower  1
    Y[17]     hard_upper  1
    Y[18]     inventory_18  1
    Y[18]     ratio_18  -9.0909090909090912e-02
    Y[18]     hard_lower  1
    Y[18]     hard_upper  1
    Y[19]     inventory_19  1
    Y[19]     ratio_19  -8.3333333333333329e-02
    Y[19]     hard_lower  1
    Y[19]     hard_upper  1
    Y[20]     inventory_20  1
    Y[20]     ratio_20  -7.6923076923076927e-02
    Y[20]     hard_lower  1
    Y[20]     hard_upper  1
    r[1]      ratio_1   1
    r[1]      R60       -1
    r[1]      R61       1
    r[1]      R62       -1
    r[1]      R63       1
    r[1]      R64       -1
    r[1]      R65       1
    r[1]      R66       -1
    r[1]      R67       1
    r[1]      R68       -1
    r[1]      R69       1
    r[1]      R70       -1
    r[1]      R71       1
    r[1]      R72       -1
    r[1]      R73       1
    r[1]      R74       -1
    r[1]      R75       1
    r[1]      R76       -1
    r[1]      R77       1
    r[1]      R78       -1
    r[1]      R79       1
    r[1]      R80       -1
    r[1]      R81       1
    r[1]      R82       -1
    r[1]      R83       1
    r[1]      R84       -1
    r[1]      R85       1
    r[1]      R86       -1
    r[1]      R87       1
    r[1]      R88       -1
    r[1]      R89       1
    r[1]      R90       -1
    r[1]      R91       1
    r[1]      R92       -1
    r[1]      R93       1
    r[1]      R94       -1
    r[1]      R95       1
    r[1]      R96       -1
    r[1]      R97       1
    r[1]      bin_lower  1
    r[1]      bin_upper  1
    r[1]      physical_G_upper  -7.5953661356977875e+00
    r[2]      ratio_2   1
    r[2]      R60       1
    r[2]      R61       -1
    r[2]      R98       -1
    r[2]      R99       1
    r[2]      R100      -1
    r[2]      R101      1
    r[2]      R102      -1
    r[2]      R103      1
    r[2]      R104      -1
    r[2]      R105      1
    r[2]      R106      -1
    r[2]      R107      1
    r[2]      R108      -1
    r[2]      R109      1
    r[2]      R110      -1
    r[2]      R111      1
    r[2]      R112      -1
    r[2]      R113      1
    r[2]      R114      -1
    r[2]      R115      1
    r[2]      R116      -1
    r[2]      R117      1
    r[2]      R118      -1
    r[2]      R119      1
    r[2]      R120      -1
    r[2]      R121      1
    r[2]      R122      -1
    r[2]      R123      1
    r[2]      R124      -1
    r[2]      R125      1
    r[2]      R126      -1
    r[2]      R127      1
    r[2]      R128      -1
    r[2]      R129      1
    r[2]      R130      -1
    r[2]      R131      1
    r[2]      R132      -1
    r[2]      R133      1
    r[2]      bin_lower  1
    r[2]      bin_upper  1
    r[2]      physical_G_upper  -7.5953661356977875e+00
    r[3]      ratio_3   1
    r[3]      R62       1
    r[3]      R63       -1
    r[3]      R98       1
    r[3]      R99       -1
    r[3]      R134      -1
    r[3]      R135      1
    r[3]      R136      -1
    r[3]      R137      1
    r[3]      R138      -1
    r[3]      R139      1
    r[3]      R140      -1
    r[3]      R141      1
    r[3]      R142      -1
    r[3]      R143      1
    r[3]      R144      -1
    r[3]      R145      1
    r[3]      R146      -1
    r[3]      R147      1
    r[3]      R148      -1
    r[3]      R149      1
    r[3]      R150      -1
    r[3]      R151      1
    r[3]      R152      -1
    r[3]      R153      1
    r[3]      R154      -1
    r[3]      R155      1
    r[3]      R156      -1
    r[3]      R157      1
    r[3]      R158      -1
    r[3]      R159      1
    r[3]      R160      -1
    r[3]      R161      1
    r[3]      R162      -1
    r[3]      R163      1
    r[3]      R164      -1
    r[3]      R165      1
    r[3]      R166      -1
    r[3]      R167      1
    r[3]      bin_lower  1
    r[3]      bin_upper  1
    r[3]      physical_G_upper  -7.5953661356977875e+00
    r[4]      ratio_4   1
    r[4]      R64       1
    r[4]      R65       -1
    r[4]      R100      1
    r[4]      R101      -1
    r[4]      R134      1
    r[4]      R135      -1
    r[4]      R168      -1
    r[4]      R169      1
    r[4]      R170      -1
    r[4]      R171      1
    r[4]      R172      -1
    r[4]      R173      1
    r[4]      R174      -1
    r[4]      R175      1
    r[4]      R176      -1
    r[4]      R177      1
    r[4]      R178      -1
    r[4]      R179      1
    r[4]      R180      -1
    r[4]      R181      1
    r[4]      R182      -1
    r[4]      R183      1
    r[4]      R184      -1
    r[4]      R185      1
    r[4]      R186      -1
    r[4]      R187      1
    r[4]      R188      -1
    r[4]      R189      1
    r[4]      R190      -1
    r[4]      R191      1
    r[4]      R192      -1
    r[4]      R193      1
    r[4]      R194      -1
    r[4]      R195      1
    r[4]      R196      -1
    r[4]      R197      1
    r[4]      R198      -1
    r[4]      R199      1
    r[4]      bin_lower  1
    r[4]      bin_upper  1
    r[4]      physical_G_upper  -7.5953661356977875e+00
    r[5]      ratio_5   1
    r[5]      R66       1
    r[5]      R67       -1
    r[5]      R102      1
    r[5]      R103      -1
    r[5]      R136      1
    r[5]      R137      -1
    r[5]      R168      1
    r[5]      R169      -1
    r[5]      R200      -1
    r[5]      R201      1
    r[5]      R202      -1
    r[5]      R203      1
    r[5]      R204      -1
    r[5]      R205      1
    r[5]      R206      -1
    r[5]      R207      1
    r[5]      R208      -1
    r[5]      R209      1
    r[5]      R210      -1
    r[5]      R211      1
    r[5]      R212      -1
    r[5]      R213      1
    r[5]      R214      -1
    r[5]      R215      1
    r[5]      R216      -1
    r[5]      R217      1
    r[5]      R218      -1
    r[5]      R219      1
    r[5]      R220      -1
    r[5]      R221      1
    r[5]      R222      -1
    r[5]      R223      1
    r[5]      R224      -1
    r[5]      R225      1
    r[5]      R226      -1
    r[5]      R227      1
    r[5]      R228      -1
    r[5]      R229      1
    r[5]      bin_lower  1
    r[5]      bin_upper  1
    r[5]      physical_G_upper  -7.5953661356977875e+00
    r[6]      ratio_6   1
    r[6]      R68       1
    r[6]      R69       -1
    r[6]      R104      1
    r[6]      R105      -1
    r[6]      R138      1
    r[6]      R139      -1
    r[6]      R170      1
    r[6]      R171      -1
    r[6]      R200      1
    r[6]      R201      -1
    r[6]      R230      -1
    r[6]      R231      1
    r[6]      R232      -1
    r[6]      R233      1
    r[6]      R234      -1
    r[6]      R235      1
    r[6]      R236      -1
    r[6]      R237      1
    r[6]      R238      -1
    r[6]      R239      1
    r[6]      R240      -1
    r[6]      R241      1
    r[6]      R242      -1
    r[6]      R243      1
    r[6]      R244      -1
    r[6]      R245      1
    r[6]      R246      -1
    r[6]      R247      1
    r[6]      R248      -1
    r[6]      R249      1
    r[6]      R250      -1
    r[6]      R251      1
    r[6]      R252      -1
    r[6]      R253      1
    r[6]      R254      -1
    r[6]      R255      1
    r[6]      R256      -1
    r[6]      R257      1
    r[6]      bin_lower  1
    r[6]      bin_upper  1
    r[6]      physical_G_upper  -7.5953661356977875e+00
    r[7]      ratio_7   1
    r[7]      R70       1
    r[7]      R71       -1
    r[7]      R106      1
    r[7]      R107      -1
    r[7]      R140      1
    r[7]      R141      -1
    r[7]      R172      1
    r[7]      R173      -1
    r[7]      R202      1
    r[7]      R203      -1
    r[7]      R230      1
    r[7]      R231      -1
    r[7]      R258      -1
    r[7]      R259      1
    r[7]      R260      -1
    r[7]      R261      1
    r[7]      R262      -1
    r[7]      R263      1
    r[7]      R264      -1
    r[7]      R265      1
    r[7]      R266      -1
    r[7]      R267      1
    r[7]      R268      -1
    r[7]      R269      1
    r[7]      R270      -1
    r[7]      R271      1
    r[7]      R272      -1
    r[7]      R273      1
    r[7]      R274      -1
    r[7]      R275      1
    r[7]      R276      -1
    r[7]      R277      1
    r[7]      R278      -1
    r[7]      R279      1
    r[7]      R280      -1
    r[7]      R281      1
    r[7]      R282      -1
    r[7]      R283      1
    r[7]      bin_lower  1
    r[7]      bin_upper  1
    r[7]      physical_G_upper  -7.5953661356977875e+00
    r[8]      ratio_8   1
    r[8]      R72       1
    r[8]      R73       -1
    r[8]      R108      1
    r[8]      R109      -1
    r[8]      R142      1
    r[8]      R143      -1
    r[8]      R174      1
    r[8]      R175      -1
    r[8]      R204      1
    r[8]      R205      -1
    r[8]      R232      1
    r[8]      R233      -1
    r[8]      R258      1
    r[8]      R259      -1
    r[8]      R284      -1
    r[8]      R285      1
    r[8]      R286      -1
    r[8]      R287      1
    r[8]      R288      -1
    r[8]      R289      1
    r[8]      R290      -1
    r[8]      R291      1
    r[8]      R292      -1
    r[8]      R293      1
    r[8]      R294      -1
    r[8]      R295      1
    r[8]      R296      -1
    r[8]      R297      1
    r[8]      R298      -1
    r[8]      R299      1
    r[8]      R300      -1
    r[8]      R301      1
    r[8]      R302      -1
    r[8]      R303      1
    r[8]      R304      -1
    r[8]      R305      1
    r[8]      R306      -1
    r[8]      R307      1
    r[8]      bin_lower  1
    r[8]      bin_upper  1
    r[8]      physical_G_upper  -7.5953661356977875e+00
    r[9]      ratio_9   1
    r[9]      R74       1
    r[9]      R75       -1
    r[9]      R110      1
    r[9]      R111      -1
    r[9]      R144      1
    r[9]      R145      -1
    r[9]      R176      1
    r[9]      R177      -1
    r[9]      R206      1
    r[9]      R207      -1
    r[9]      R234      1
    r[9]      R235      -1
    r[9]      R260      1
    r[9]      R261      -1
    r[9]      R284      1
    r[9]      R285      -1
    r[9]      R308      -1
    r[9]      R309      1
    r[9]      R310      -1
    r[9]      R311      1
    r[9]      R312      -1
    r[9]      R313      1
    r[9]      R314      -1
    r[9]      R315      1
    r[9]      R316      -1
    r[9]      R317      1
    r[9]      R318      -1
    r[9]      R319      1
    r[9]      R320      -1
    r[9]      R321      1
    r[9]      R322      -1
    r[9]      R323      1
    r[9]      R324      -1
    r[9]      R325      1
    r[9]      R326      -1
    r[9]      R327      1
    r[9]      R328      -1
    r[9]      R329      1
    r[9]      bin_lower  1
    r[9]      bin_upper  1
    r[9]      physical_G_upper  -7.5953661356977875e+00
    r[10]     ratio_10  1
    r[10]     R76       1
    r[10]     R77       -1
    r[10]     R112      1
    r[10]     R113      -1
    r[10]     R146      1
    r[10]     R147      -1
    r[10]     R178      1
    r[10]     R179      -1
    r[10]     R208      1
    r[10]     R209      -1
    r[10]     R236      1
    r[10]     R237      -1
    r[10]     R262      1
    r[10]     R263      -1
    r[10]     R286      1
    r[10]     R287      -1
    r[10]     R308      1
    r[10]     R309      -1
    r[10]     R330      -1
    r[10]     R331      1
    r[10]     R332      -1
    r[10]     R333      1
    r[10]     R334      -1
    r[10]     R335      1
    r[10]     R336      -1
    r[10]     R337      1
    r[10]     R338      -1
    r[10]     R339      1
    r[10]     R340      -1
    r[10]     R341      1
    r[10]     R342      -1
    r[10]     R343      1
    r[10]     R344      -1
    r[10]     R345      1
    r[10]     R346      -1
    r[10]     R347      1
    r[10]     R348      -1
    r[10]     R349      1
    r[10]     bin_lower  1
    r[10]     bin_upper  1
    r[10]     physical_G_upper  -7.5953661356977875e+00
    r[11]     ratio_11  1
    r[11]     R78       1
    r[11]     R79       -1
    r[11]     R114      1
    r[11]     R115      -1
    r[11]     R148      1
    r[11]     R149      -1
    r[11]     R180      1
    r[11]     R181      -1
    r[11]     R210      1
    r[11]     R211      -1
    r[11]     R238      1
    r[11]     R239      -1
    r[11]     R264      1
    r[11]     R265      -1
    r[11]     R288      1
    r[11]     R289      -1
    r[11]     R310      1
    r[11]     R311      -1
    r[11]     R330      1
    r[11]     R331      -1
    r[11]     R350      -1
    r[11]     R351      1
    r[11]     R352      -1
    r[11]     R353      1
    r[11]     R354      -1
    r[11]     R355      1
    r[11]     R356      -1
    r[11]     R357      1
    r[11]     R358      -1
    r[11]     R359      1
    r[11]     R360      -1
    r[11]     R361      1
    r[11]     R362      -1
    r[11]     R363      1
    r[11]     R364      -1
    r[11]     R365      1
    r[11]     R366      -1
    r[11]     R367      1
    r[11]     bin_lower  1
    r[11]     bin_upper  1
    r[11]     physical_G_upper  -7.5953661356977875e+00
    r[12]     ratio_12  1
    r[12]     R80       1
    r[12]     R81       -1
    r[12]     R116      1
    r[12]     R117      -1
    r[12]     R150      1
    r[12]     R151      -1
    r[12]     R182      1
    r[12]     R183      -1
    r[12]     R212      1
    r[12]     R213      -1
    r[12]     R240      1
    r[12]     R241      -1
    r[12]     R266      1
    r[12]     R267      -1
    r[12]     R290      1
    r[12]     R291      -1
    r[12]     R312      1
    r[12]     R313      -1
    r[12]     R332      1
    r[12]     R333      -1
    r[12]     R350      1
    r[12]     R351      -1
    r[12]     R368      -1
    r[12]     R369      1
    r[12]     R370      -1
    r[12]     R371      1
    r[12]     R372      -1
    r[12]     R373      1
    r[12]     R374      -1
    r[12]     R375      1
    r[12]     R376      -1
    r[12]     R377      1
    r[12]     R378      -1
    r[12]     R379      1
    r[12]     R380      -1
    r[12]     R381      1
    r[12]     R382      -1
    r[12]     R383      1
    r[12]     bin_lower  1
    r[12]     bin_upper  1
    r[12]     physical_G_upper  -7.5953661356977875e+00
    r[13]     ratio_13  1
    r[13]     R82       1
    r[13]     R83       -1
    r[13]     R118      1
    r[13]     R119      -1
    r[13]     R152      1
    r[13]     R153      -1
    r[13]     R184      1
    r[13]     R185      -1
    r[13]     R214      1
    r[13]     R215      -1
    r[13]     R242      1
    r[13]     R243      -1
    r[13]     R268      1
    r[13]     R269      -1
    r[13]     R292      1
    r[13]     R293      -1
    r[13]     R314      1
    r[13]     R315      -1
    r[13]     R334      1
    r[13]     R335      -1
    r[13]     R352      1
    r[13]     R353      -1
    r[13]     R368      1
    r[13]     R369      -1
    r[13]     R384      -1
    r[13]     R385      1
    r[13]     R386      -1
    r[13]     R387      1
    r[13]     R388      -1
    r[13]     R389      1
    r[13]     R390      -1
    r[13]     R391      1
    r[13]     R392      -1
    r[13]     R393      1
    r[13]     R394      -1
    r[13]     R395      1
    r[13]     R396      -1
    r[13]     R397      1
    r[13]     bin_lower  1
    r[13]     bin_upper  1
    r[13]     physical_G_upper  -7.5953661356977875e+00
    r[14]     ratio_14  1
    r[14]     R84       1
    r[14]     R85       -1
    r[14]     R120      1
    r[14]     R121      -1
    r[14]     R154      1
    r[14]     R155      -1
    r[14]     R186      1
    r[14]     R187      -1
    r[14]     R216      1
    r[14]     R217      -1
    r[14]     R244      1
    r[14]     R245      -1
    r[14]     R270      1
    r[14]     R271      -1
    r[14]     R294      1
    r[14]     R295      -1
    r[14]     R316      1
    r[14]     R317      -1
    r[14]     R336      1
    r[14]     R337      -1
    r[14]     R354      1
    r[14]     R355      -1
    r[14]     R370      1
    r[14]     R371      -1
    r[14]     R384      1
    r[14]     R385      -1
    r[14]     R398      -1
    r[14]     R399      1
    r[14]     R400      -1
    r[14]     R401      1
    r[14]     R402      -1
    r[14]     R403      1
    r[14]     R404      -1
    r[14]     R405      1
    r[14]     R406      -1
    r[14]     R407      1
    r[14]     R408      -1
    r[14]     R409      1
    r[14]     bin_lower  1
    r[14]     bin_upper  1
    r[14]     physical_G_upper  -7.5953661356977875e+00
    r[15]     ratio_15  1
    r[15]     R86       1
    r[15]     R87       -1
    r[15]     R122      1
    r[15]     R123      -1
    r[15]     R156      1
    r[15]     R157      -1
    r[15]     R188      1
    r[15]     R189      -1
    r[15]     R218      1
    r[15]     R219      -1
    r[15]     R246      1
    r[15]     R247      -1
    r[15]     R272      1
    r[15]     R273      -1
    r[15]     R296      1
    r[15]     R297      -1
    r[15]     R318      1
    r[15]     R319      -1
    r[15]     R338      1
    r[15]     R339      -1
    r[15]     R356      1
    r[15]     R357      -1
    r[15]     R372      1
    r[15]     R373      -1
    r[15]     R386      1
    r[15]     R387      -1
    r[15]     R398      1
    r[15]     R399      -1
    r[15]     R410      -1
    r[15]     R411      1
    r[15]     R412      -1
    r[15]     R413      1
    r[15]     R414      -1
    r[15]     R415      1
    r[15]     R416      -1
    r[15]     R417      1
    r[15]     R418      -1
    r[15]     R419      1
    r[15]     bin_lower  1
    r[15]     bin_upper  1
    r[15]     physical_G_upper  -7.5953661356977875e+00
    r[16]     ratio_16  1
    r[16]     R88       1
    r[16]     R89       -1
    r[16]     R124      1
    r[16]     R125      -1
    r[16]     R158      1
    r[16]     R159      -1
    r[16]     R190      1
    r[16]     R191      -1
    r[16]     R220      1
    r[16]     R221      -1
    r[16]     R248      1
    r[16]     R249      -1
    r[16]     R274      1
    r[16]     R275      -1
    r[16]     R298      1
    r[16]     R299      -1
    r[16]     R320      1
    r[16]     R321      -1
    r[16]     R340      1
    r[16]     R341      -1
    r[16]     R358      1
    r[16]     R359      -1
    r[16]     R374      1
    r[16]     R375      -1
    r[16]     R388      1
    r[16]     R389      -1
    r[16]     R400      1
    r[16]     R401      -1
    r[16]     R410      1
    r[16]     R411      -1
    r[16]     R420      -1
    r[16]     R421      1
    r[16]     R422      -1
    r[16]     R423      1
    r[16]     R424      -1
    r[16]     R425      1
    r[16]     R426      -1
    r[16]     R427      1
    r[16]     bin_lower  1
    r[16]     bin_upper  1
    r[16]     physical_G_upper  -7.5953661356977875e+00
    r[17]     ratio_17  1
    r[17]     R90       1
    r[17]     R91       -1
    r[17]     R126      1
    r[17]     R127      -1
    r[17]     R160      1
    r[17]     R161      -1
    r[17]     R192      1
    r[17]     R193      -1
    r[17]     R222      1
    r[17]     R223      -1
    r[17]     R250      1
    r[17]     R251      -1
    r[17]     R276      1
    r[17]     R277      -1
    r[17]     R300      1
    r[17]     R301      -1
    r[17]     R322      1
    r[17]     R323      -1
    r[17]     R342      1
    r[17]     R343      -1
    r[17]     R360      1
    r[17]     R361      -1
    r[17]     R376      1
    r[17]     R377      -1
    r[17]     R390      1
    r[17]     R391      -1
    r[17]     R402      1
    r[17]     R403      -1
    r[17]     R412      1
    r[17]     R413      -1
    r[17]     R420      1
    r[17]     R421      -1
    r[17]     R428      -1
    r[17]     R429      1
    r[17]     R430      -1
    r[17]     R431      1
    r[17]     R432      -1
    r[17]     R433      1
    r[17]     bin_lower  1
    r[17]     bin_upper  1
    r[17]     physical_G_upper  -7.5953661356977875e+00
    r[18]     ratio_18  1
    r[18]     R92       1
    r[18]     R93       -1
    r[18]     R128      1
    r[18]     R129      -1
    r[18]     R162      1
    r[18]     R163      -1
    r[18]     R194      1
    r[18]     R195      -1
    r[18]     R224      1
    r[18]     R225      -1
    r[18]     R252      1
    r[18]     R253      -1
    r[18]     R278      1
    r[18]     R279      -1
    r[18]     R302      1
    r[18]     R303      -1
    r[18]     R324      1
    r[18]     R325      -1
    r[18]     R344      1
    r[18]     R345      -1
    r[18]     R362      1
    r[18]     R363      -1
    r[18]     R378      1
    r[18]     R379      -1
    r[18]     R392      1
    r[18]     R393      -1
    r[18]     R404      1
    r[18]     R405      -1
    r[18]     R414      1
    r[18]     R415      -1
    r[18]     R422      1
    r[18]     R423      -1
    r[18]     R428      1
    r[18]     R429      -1
    r[18]     R434      -1
    r[18]     R435      1
    r[18]     R436      -1
    r[18]     R437      1
    r[18]     bin_lower  1
    r[18]     bin_upper  1
    r[18]     physical_G_upper  -7.5953661356977875e+00
    r[19]     ratio_19  1
    r[19]     R94       1
    r[19]     R95       -1
    r[19]     R130      1
    r[19]     R131      -1
    r[19]     R164      1
    r[19]     R165      -1
    r[19]     R196      1
    r[19]     R197      -1
    r[19]     R226      1
    r[19]     R227      -1
    r[19]     R254      1
    r[19]     R255      -1
    r[19]     R280      1
    r[19]     R281      -1
    r[19]     R304      1
    r[19]     R305      -1
    r[19]     R326      1
    r[19]     R327      -1
    r[19]     R346      1
    r[19]     R347      -1
    r[19]     R364      1
    r[19]     R365      -1
    r[19]     R380      1
    r[19]     R381      -1
    r[19]     R394      1
    r[19]     R395      -1
    r[19]     R406      1
    r[19]     R407      -1
    r[19]     R416      1
    r[19]     R417      -1
    r[19]     R424      1
    r[19]     R425      -1
    r[19]     R430      1
    r[19]     R431      -1
    r[19]     R434      1
    r[19]     R435      -1
    r[19]     R438      -1
    r[19]     R439      1
    r[19]     bin_lower  1
    r[19]     bin_upper  1
    r[19]     physical_G_upper  -7.5953661356977875e+00
    r[20]     ratio_20  1
    r[20]     R96       1
    r[20]     R97       -1
    r[20]     R132      1
    r[20]     R133      -1
    r[20]     R166      1
    r[20]     R167      -1
    r[20]     R198      1
    r[20]     R199      -1
    r[20]     R228      1
    r[20]     R229      -1
    r[20]     R256      1
    r[20]     R257      -1
    r[20]     R282      1
    r[20]     R283      -1
    r[20]     R306      1
    r[20]     R307      -1
    r[20]     R328      1
    r[20]     R329      -1
    r[20]     R348      1
    r[20]     R349      -1
    r[20]     R366      1
    r[20]     R367      -1
    r[20]     R382      1
    r[20]     R383      -1
    r[20]     R396      1
    r[20]     R397      -1
    r[20]     R408      1
    r[20]     R409      -1
    r[20]     R418      1
    r[20]     R419      -1
    r[20]     R426      1
    r[20]     R427      -1
    r[20]     R432      1
    r[20]     R433      -1
    r[20]     R436      1
    r[20]     R437      -1
    r[20]     R438      1
    r[20]     R439      -1
    r[20]     bin_lower  1
    r[20]     bin_upper  1
    r[20]     physical_G_upper  -7.5953661356977875e+00
    a[1,2]    R60       1
    a[1,2]    R61       1
    a[1,2]    surrogate_G  1
    a[1,2]    physical_G_upper  1
    a[1,3]    R62       1
    a[1,3]    R63       1
    a[1,3]    surrogate_G  1
    a[1,3]    physical_G_upper  1
    a[1,4]    R64       1
    a[1,4]    R65       1
    a[1,4]    surrogate_G  1
    a[1,4]    physical_G_upper  1
    a[1,5]    R66       1
    a[1,5]    R67       1
    a[1,5]    surrogate_G  1
    a[1,5]    physical_G_upper  1
    a[1,6]    R68       1
    a[1,6]    R69       1
    a[1,6]    surrogate_G  1
    a[1,6]    physical_G_upper  1
    a[1,7]    R70       1
    a[1,7]    R71       1
    a[1,7]    surrogate_G  1
    a[1,7]    physical_G_upper  1
    a[1,8]    R72       1
    a[1,8]    R73       1
    a[1,8]    surrogate_G  1
    a[1,8]    physical_G_upper  1
    a[1,9]    R74       1
    a[1,9]    R75       1
    a[1,9]    surrogate_G  1
    a[1,9]    physical_G_upper  1
    a[1,10]   R76       1
    a[1,10]   R77       1
    a[1,10]   surrogate_G  1
    a[1,10]   physical_G_upper  1
    a[1,11]   R78       1
    a[1,11]   R79       1
    a[1,11]   surrogate_G  1
    a[1,11]   physical_G_upper  1
    a[1,12]   R80       1
    a[1,12]   R81       1
    a[1,12]   surrogate_G  1
    a[1,12]   physical_G_upper  1
    a[1,13]   R82       1
    a[1,13]   R83       1
    a[1,13]   surrogate_G  1
    a[1,13]   physical_G_upper  1
    a[1,14]   R84       1
    a[1,14]   R85       1
    a[1,14]   surrogate_G  1
    a[1,14]   physical_G_upper  1
    a[1,15]   R86       1
    a[1,15]   R87       1
    a[1,15]   surrogate_G  1
    a[1,15]   physical_G_upper  1
    a[1,16]   R88       1
    a[1,16]   R89       1
    a[1,16]   surrogate_G  1
    a[1,16]   physical_G_upper  1
    a[1,17]   R90       1
    a[1,17]   R91       1
    a[1,17]   surrogate_G  1
    a[1,17]   physical_G_upper  1
    a[1,18]   R92       1
    a[1,18]   R93       1
    a[1,18]   surrogate_G  1
    a[1,18]   physical_G_upper  1
    a[1,19]   R94       1
    a[1,19]   R95       1
    a[1,19]   surrogate_G  1
    a[1,19]   physical_G_upper  1
    a[1,20]   R96       1
    a[1,20]   R97       1
    a[1,20]   surrogate_G  1
    a[1,20]   physical_G_upper  1
    a[2,3]    R98       1
    a[2,3]    R99       1
    a[2,3]    surrogate_G  1
    a[2,3]    physical_G_upper  1
    a[2,4]    R100      1
    a[2,4]    R101      1
    a[2,4]    surrogate_G  1
    a[2,4]    physical_G_upper  1
    a[2,5]    R102      1
    a[2,5]    R103      1
    a[2,5]    surrogate_G  1
    a[2,5]    physical_G_upper  1
    a[2,6]    R104      1
    a[2,6]    R105      1
    a[2,6]    surrogate_G  1
    a[2,6]    physical_G_upper  1
    a[2,7]    R106      1
    a[2,7]    R107      1
    a[2,7]    surrogate_G  1
    a[2,7]    physical_G_upper  1
    a[2,8]    R108      1
    a[2,8]    R109      1
    a[2,8]    surrogate_G  1
    a[2,8]    physical_G_upper  1
    a[2,9]    R110      1
    a[2,9]    R111      1
    a[2,9]    surrogate_G  1
    a[2,9]    physical_G_upper  1
    a[2,10]   R112      1
    a[2,10]   R113      1
    a[2,10]   surrogate_G  1
    a[2,10]   physical_G_upper  1
    a[2,11]   R114      1
    a[2,11]   R115      1
    a[2,11]   surrogate_G  1
    a[2,11]   physical_G_upper  1
    a[2,12]   R116      1
    a[2,12]   R117      1
    a[2,12]   surrogate_G  1
    a[2,12]   physical_G_upper  1
    a[2,13]   R118      1
    a[2,13]   R119      1
    a[2,13]   surrogate_G  1
    a[2,13]   physical_G_upper  1
    a[2,14]   R120      1
    a[2,14]   R121      1
    a[2,14]   surrogate_G  1
    a[2,14]   physical_G_upper  1
    a[2,15]   R122      1
    a[2,15]   R123      1
    a[2,15]   surrogate_G  1
    a[2,15]   physical_G_upper  1
    a[2,16]   R124      1
    a[2,16]   R125      1
    a[2,16]   surrogate_G  1
    a[2,16]   physical_G_upper  1
    a[2,17]   R126      1
    a[2,17]   R127      1
    a[2,17]   surrogate_G  1
    a[2,17]   physical_G_upper  1
    a[2,18]   R128      1
    a[2,18]   R129      1
    a[2,18]   surrogate_G  1
    a[2,18]   physical_G_upper  1
    a[2,19]   R130      1
    a[2,19]   R131      1
    a[2,19]   surrogate_G  1
    a[2,19]   physical_G_upper  1
    a[2,20]   R132      1
    a[2,20]   R133      1
    a[2,20]   surrogate_G  1
    a[2,20]   physical_G_upper  1
    a[3,4]    R134      1
    a[3,4]    R135      1
    a[3,4]    surrogate_G  1
    a[3,4]    physical_G_upper  1
    a[3,5]    R136      1
    a[3,5]    R137      1
    a[3,5]    surrogate_G  1
    a[3,5]    physical_G_upper  1
    a[3,6]    R138      1
    a[3,6]    R139      1
    a[3,6]    surrogate_G  1
    a[3,6]    physical_G_upper  1
    a[3,7]    R140      1
    a[3,7]    R141      1
    a[3,7]    surrogate_G  1
    a[3,7]    physical_G_upper  1
    a[3,8]    R142      1
    a[3,8]    R143      1
    a[3,8]    surrogate_G  1
    a[3,8]    physical_G_upper  1
    a[3,9]    R144      1
    a[3,9]    R145      1
    a[3,9]    surrogate_G  1
    a[3,9]    physical_G_upper  1
    a[3,10]   R146      1
    a[3,10]   R147      1
    a[3,10]   surrogate_G  1
    a[3,10]   physical_G_upper  1
    a[3,11]   R148      1
    a[3,11]   R149      1
    a[3,11]   surrogate_G  1
    a[3,11]   physical_G_upper  1
    a[3,12]   R150      1
    a[3,12]   R151      1
    a[3,12]   surrogate_G  1
    a[3,12]   physical_G_upper  1
    a[3,13]   R152      1
    a[3,13]   R153      1
    a[3,13]   surrogate_G  1
    a[3,13]   physical_G_upper  1
    a[3,14]   R154      1
    a[3,14]   R155      1
    a[3,14]   surrogate_G  1
    a[3,14]   physical_G_upper  1
    a[3,15]   R156      1
    a[3,15]   R157      1
    a[3,15]   surrogate_G  1
    a[3,15]   physical_G_upper  1
    a[3,16]   R158      1
    a[3,16]   R159      1
    a[3,16]   surrogate_G  1
    a[3,16]   physical_G_upper  1
    a[3,17]   R160      1
    a[3,17]   R161      1
    a[3,17]   surrogate_G  1
    a[3,17]   physical_G_upper  1
    a[3,18]   R162      1
    a[3,18]   R163      1
    a[3,18]   surrogate_G  1
    a[3,18]   physical_G_upper  1
    a[3,19]   R164      1
    a[3,19]   R165      1
    a[3,19]   surrogate_G  1
    a[3,19]   physical_G_upper  1
    a[3,20]   R166      1
    a[3,20]   R167      1
    a[3,20]   surrogate_G  1
    a[3,20]   physical_G_upper  1
    a[4,5]    R168      1
    a[4,5]    R169      1
    a[4,5]    surrogate_G  1
    a[4,5]    physical_G_upper  1
    a[4,6]    R170      1
    a[4,6]    R171      1
    a[4,6]    surrogate_G  1
    a[4,6]    physical_G_upper  1
    a[4,7]    R172      1
    a[4,7]    R173      1
    a[4,7]    surrogate_G  1
    a[4,7]    physical_G_upper  1
    a[4,8]    R174      1
    a[4,8]    R175      1
    a[4,8]    surrogate_G  1
    a[4,8]    physical_G_upper  1
    a[4,9]    R176      1
    a[4,9]    R177      1
    a[4,9]    surrogate_G  1
    a[4,9]    physical_G_upper  1
    a[4,10]   R178      1
    a[4,10]   R179      1
    a[4,10]   surrogate_G  1
    a[4,10]   physical_G_upper  1
    a[4,11]   R180      1
    a[4,11]   R181      1
    a[4,11]   surrogate_G  1
    a[4,11]   physical_G_upper  1
    a[4,12]   R182      1
    a[4,12]   R183      1
    a[4,12]   surrogate_G  1
    a[4,12]   physical_G_upper  1
    a[4,13]   R184      1
    a[4,13]   R185      1
    a[4,13]   surrogate_G  1
    a[4,13]   physical_G_upper  1
    a[4,14]   R186      1
    a[4,14]   R187      1
    a[4,14]   surrogate_G  1
    a[4,14]   physical_G_upper  1
    a[4,15]   R188      1
    a[4,15]   R189      1
    a[4,15]   surrogate_G  1
    a[4,15]   physical_G_upper  1
    a[4,16]   R190      1
    a[4,16]   R191      1
    a[4,16]   surrogate_G  1
    a[4,16]   physical_G_upper  1
    a[4,17]   R192      1
    a[4,17]   R193      1
    a[4,17]   surrogate_G  1
    a[4,17]   physical_G_upper  1
    a[4,18]   R194      1
    a[4,18]   R195      1
    a[4,18]   surrogate_G  1
    a[4,18]   physical_G_upper  1
    a[4,19]   R196      1
    a[4,19]   R197      1
    a[4,19]   surrogate_G  1
    a[4,19]   physical_G_upper  1
    a[4,20]   R198      1
    a[4,20]   R199      1
    a[4,20]   surrogate_G  1
    a[4,20]   physical_G_upper  1
    a[5,6]    R200      1
    a[5,6]    R201      1
    a[5,6]    surrogate_G  1
    a[5,6]    physical_G_upper  1
    a[5,7]    R202      1
    a[5,7]    R203      1
    a[5,7]    surrogate_G  1
    a[5,7]    physical_G_upper  1
    a[5,8]    R204      1
    a[5,8]    R205      1
    a[5,8]    surrogate_G  1
    a[5,8]    physical_G_upper  1
    a[5,9]    R206      1
    a[5,9]    R207      1
    a[5,9]    surrogate_G  1
    a[5,9]    physical_G_upper  1
    a[5,10]   R208      1
    a[5,10]   R209      1
    a[5,10]   surrogate_G  1
    a[5,10]   physical_G_upper  1
    a[5,11]   R210      1
    a[5,11]   R211      1
    a[5,11]   surrogate_G  1
    a[5,11]   physical_G_upper  1
    a[5,12]   R212      1
    a[5,12]   R213      1
    a[5,12]   surrogate_G  1
    a[5,12]   physical_G_upper  1
    a[5,13]   R214      1
    a[5,13]   R215      1
    a[5,13]   surrogate_G  1
    a[5,13]   physical_G_upper  1
    a[5,14]   R216      1
    a[5,14]   R217      1
    a[5,14]   surrogate_G  1
    a[5,14]   physical_G_upper  1
    a[5,15]   R218      1
    a[5,15]   R219      1
    a[5,15]   surrogate_G  1
    a[5,15]   physical_G_upper  1
    a[5,16]   R220      1
    a[5,16]   R221      1
    a[5,16]   surrogate_G  1
    a[5,16]   physical_G_upper  1
    a[5,17]   R222      1
    a[5,17]   R223      1
    a[5,17]   surrogate_G  1
    a[5,17]   physical_G_upper  1
    a[5,18]   R224      1
    a[5,18]   R225      1
    a[5,18]   surrogate_G  1
    a[5,18]   physical_G_upper  1
    a[5,19]   R226      1
    a[5,19]   R227      1
    a[5,19]   surrogate_G  1
    a[5,19]   physical_G_upper  1
    a[5,20]   R228      1
    a[5,20]   R229      1
    a[5,20]   surrogate_G  1
    a[5,20]   physical_G_upper  1
    a[6,7]    R230      1
    a[6,7]    R231      1
    a[6,7]    surrogate_G  1
    a[6,7]    physical_G_upper  1
    a[6,8]    R232      1
    a[6,8]    R233      1
    a[6,8]    surrogate_G  1
    a[6,8]    physical_G_upper  1
    a[6,9]    R234      1
    a[6,9]    R235      1
    a[6,9]    surrogate_G  1
    a[6,9]    physical_G_upper  1
    a[6,10]   R236      1
    a[6,10]   R237      1
    a[6,10]   surrogate_G  1
    a[6,10]   physical_G_upper  1
    a[6,11]   R238      1
    a[6,11]   R239      1
    a[6,11]   surrogate_G  1
    a[6,11]   physical_G_upper  1
    a[6,12]   R240      1
    a[6,12]   R241      1
    a[6,12]   surrogate_G  1
    a[6,12]   physical_G_upper  1
    a[6,13]   R242      1
    a[6,13]   R243      1
    a[6,13]   surrogate_G  1
    a[6,13]   physical_G_upper  1
    a[6,14]   R244      1
    a[6,14]   R245      1
    a[6,14]   surrogate_G  1
    a[6,14]   physical_G_upper  1
    a[6,15]   R246      1
    a[6,15]   R247      1
    a[6,15]   surrogate_G  1
    a[6,15]   physical_G_upper  1
    a[6,16]   R248      1
    a[6,16]   R249      1
    a[6,16]   surrogate_G  1
    a[6,16]   physical_G_upper  1
    a[6,17]   R250      1
    a[6,17]   R251      1
    a[6,17]   surrogate_G  1
    a[6,17]   physical_G_upper  1
    a[6,18]   R252      1
    a[6,18]   R253      1
    a[6,18]   surrogate_G  1
    a[6,18]   physical_G_upper  1
    a[6,19]   R254      1
    a[6,19]   R255      1
    a[6,19]   surrogate_G  1
    a[6,19]   physical_G_upper  1
    a[6,20]   R256      1
    a[6,20]   R257      1
    a[6,20]   surrogate_G  1
    a[6,20]   physical_G_upper  1
    a[7,8]    R258      1
    a[7,8]    R259      1
    a[7,8]    surrogate_G  1
    a[7,8]    physical_G_upper  1
    a[7,9]    R260      1
    a[7,9]    R261      1
    a[7,9]    surrogate_G  1
    a[7,9]    physical_G_upper  1
    a[7,10]   R262      1
    a[7,10]   R263      1
    a[7,10]   surrogate_G  1
    a[7,10]   physical_G_upper  1
    a[7,11]   R264      1
    a[7,11]   R265      1
    a[7,11]   surrogate_G  1
    a[7,11]   physical_G_upper  1
    a[7,12]   R266      1
    a[7,12]   R267      1
    a[7,12]   surrogate_G  1
    a[7,12]   physical_G_upper  1
    a[7,13]   R268      1
    a[7,13]   R269      1
    a[7,13]   surrogate_G  1
    a[7,13]   physical_G_upper  1
    a[7,14]   R270      1
    a[7,14]   R271      1
    a[7,14]   surrogate_G  1
    a[7,14]   physical_G_upper  1
    a[7,15]   R272      1
    a[7,15]   R273      1
    a[7,15]   surrogate_G  1
    a[7,15]   physical_G_upper  1
    a[7,16]   R274      1
    a[7,16]   R275      1
    a[7,16]   surrogate_G  1
    a[7,16]   physical_G_upper  1
    a[7,17]   R276      1
    a[7,17]   R277      1
    a[7,17]   surrogate_G  1
    a[7,17]   physical_G_upper  1
    a[7,18]   R278      1
    a[7,18]   R279      1
    a[7,18]   surrogate_G  1
    a[7,18]   physical_G_upper  1
    a[7,19]   R280      1
    a[7,19]   R281      1
    a[7,19]   surrogate_G  1
    a[7,19]   physical_G_upper  1
    a[7,20]   R282      1
    a[7,20]   R283      1
    a[7,20]   surrogate_G  1
    a[7,20]   physical_G_upper  1
    a[8,9]    R284      1
    a[8,9]    R285      1
    a[8,9]    surrogate_G  1
    a[8,9]    physical_G_upper  1
    a[8,10]   R286      1
    a[8,10]   R287      1
    a[8,10]   surrogate_G  1
    a[8,10]   physical_G_upper  1
    a[8,11]   R288      1
    a[8,11]   R289      1
    a[8,11]   surrogate_G  1
    a[8,11]   physical_G_upper  1
    a[8,12]   R290      1
    a[8,12]   R291      1
    a[8,12]   surrogate_G  1
    a[8,12]   physical_G_upper  1
    a[8,13]   R292      1
    a[8,13]   R293      1
    a[8,13]   surrogate_G  1
    a[8,13]   physical_G_upper  1
    a[8,14]   R294      1
    a[8,14]   R295      1
    a[8,14]   surrogate_G  1
    a[8,14]   physical_G_upper  1
    a[8,15]   R296      1
    a[8,15]   R297      1
    a[8,15]   surrogate_G  1
    a[8,15]   physical_G_upper  1
    a[8,16]   R298      1
    a[8,16]   R299      1
    a[8,16]   surrogate_G  1
    a[8,16]   physical_G_upper  1
    a[8,17]   R300      1
    a[8,17]   R301      1
    a[8,17]   surrogate_G  1
    a[8,17]   physical_G_upper  1
    a[8,18]   R302      1
    a[8,18]   R303      1
    a[8,18]   surrogate_G  1
    a[8,18]   physical_G_upper  1
    a[8,19]   R304      1
    a[8,19]   R305      1
    a[8,19]   surrogate_G  1
    a[8,19]   physical_G_upper  1
    a[8,20]   R306      1
    a[8,20]   R307      1
    a[8,20]   surrogate_G  1
    a[8,20]   physical_G_upper  1
    a[9,10]   R308      1
    a[9,10]   R309      1
    a[9,10]   surrogate_G  1
    a[9,10]   physical_G_upper  1
    a[9,11]   R310      1
    a[9,11]   R311      1
    a[9,11]   surrogate_G  1
    a[9,11]   physical_G_upper  1
    a[9,12]   R312      1
    a[9,12]   R313      1
    a[9,12]   surrogate_G  1
    a[9,12]   physical_G_upper  1
    a[9,13]   R314      1
    a[9,13]   R315      1
    a[9,13]   surrogate_G  1
    a[9,13]   physical_G_upper  1
    a[9,14]   R316      1
    a[9,14]   R317      1
    a[9,14]   surrogate_G  1
    a[9,14]   physical_G_upper  1
    a[9,15]   R318      1
    a[9,15]   R319      1
    a[9,15]   surrogate_G  1
    a[9,15]   physical_G_upper  1
    a[9,16]   R320      1
    a[9,16]   R321      1
    a[9,16]   surrogate_G  1
    a[9,16]   physical_G_upper  1
    a[9,17]   R322      1
    a[9,17]   R323      1
    a[9,17]   surrogate_G  1
    a[9,17]   physical_G_upper  1
    a[9,18]   R324      1
    a[9,18]   R325      1
    a[9,18]   surrogate_G  1
    a[9,18]   physical_G_upper  1
    a[9,19]   R326      1
    a[9,19]   R327      1
    a[9,19]   surrogate_G  1
    a[9,19]   physical_G_upper  1
    a[9,20]   R328      1
    a[9,20]   R329      1
    a[9,20]   surrogate_G  1
    a[9,20]   physical_G_upper  1
    a[10,11]  R330      1
    a[10,11]  R331      1
    a[10,11]  surrogate_G  1
    a[10,11]  physical_G_upper  1
    a[10,12]  R332      1
    a[10,12]  R333      1
    a[10,12]  surrogate_G  1
    a[10,12]  physical_G_upper  1
    a[10,13]  R334      1
    a[10,13]  R335      1
    a[10,13]  surrogate_G  1
    a[10,13]  physical_G_upper  1
    a[10,14]  R336      1
    a[10,14]  R337      1
    a[10,14]  surrogate_G  1
    a[10,14]  physical_G_upper  1
    a[10,15]  R338      1
    a[10,15]  R339      1
    a[10,15]  surrogate_G  1
    a[10,15]  physical_G_upper  1
    a[10,16]  R340      1
    a[10,16]  R341      1
    a[10,16]  surrogate_G  1
    a[10,16]  physical_G_upper  1
    a[10,17]  R342      1
    a[10,17]  R343      1
    a[10,17]  surrogate_G  1
    a[10,17]  physical_G_upper  1
    a[10,18]  R344      1
    a[10,18]  R345      1
    a[10,18]  surrogate_G  1
    a[10,18]  physical_G_upper  1
    a[10,19]  R346      1
    a[10,19]  R347      1
    a[10,19]  surrogate_G  1
    a[10,19]  physical_G_upper  1
    a[10,20]  R348      1
    a[10,20]  R349      1
    a[10,20]  surrogate_G  1
    a[10,20]  physical_G_upper  1
    a[11,12]  R350      1
    a[11,12]  R351      1
    a[11,12]  surrogate_G  1
    a[11,12]  physical_G_upper  1
    a[11,13]  R352      1
    a[11,13]  R353      1
    a[11,13]  surrogate_G  1
    a[11,13]  physical_G_upper  1
    a[11,14]  R354      1
    a[11,14]  R355      1
    a[11,14]  surrogate_G  1
    a[11,14]  physical_G_upper  1
    a[11,15]  R356      1
    a[11,15]  R357      1
    a[11,15]  surrogate_G  1
    a[11,15]  physical_G_upper  1
    a[11,16]  R358      1
    a[11,16]  R359      1
    a[11,16]  surrogate_G  1
    a[11,16]  physical_G_upper  1
    a[11,17]  R360      1
    a[11,17]  R361      1
    a[11,17]  surrogate_G  1
    a[11,17]  physical_G_upper  1
    a[11,18]  R362      1
    a[11,18]  R363      1
    a[11,18]  surrogate_G  1
    a[11,18]  physical_G_upper  1
    a[11,19]  R364      1
    a[11,19]  R365      1
    a[11,19]  surrogate_G  1
    a[11,19]  physical_G_upper  1
    a[11,20]  R366      1
    a[11,20]  R367      1
    a[11,20]  surrogate_G  1
    a[11,20]  physical_G_upper  1
    a[12,13]  R368      1
    a[12,13]  R369      1
    a[12,13]  surrogate_G  1
    a[12,13]  physical_G_upper  1
    a[12,14]  R370      1
    a[12,14]  R371      1
    a[12,14]  surrogate_G  1
    a[12,14]  physical_G_upper  1
    a[12,15]  R372      1
    a[12,15]  R373      1
    a[12,15]  surrogate_G  1
    a[12,15]  physical_G_upper  1
    a[12,16]  R374      1
    a[12,16]  R375      1
    a[12,16]  surrogate_G  1
    a[12,16]  physical_G_upper  1
    a[12,17]  R376      1
    a[12,17]  R377      1
    a[12,17]  surrogate_G  1
    a[12,17]  physical_G_upper  1
    a[12,18]  R378      1
    a[12,18]  R379      1
    a[12,18]  surrogate_G  1
    a[12,18]  physical_G_upper  1
    a[12,19]  R380      1
    a[12,19]  R381      1
    a[12,19]  surrogate_G  1
    a[12,19]  physical_G_upper  1
    a[12,20]  R382      1
    a[12,20]  R383      1
    a[12,20]  surrogate_G  1
    a[12,20]  physical_G_upper  1
    a[13,14]  R384      1
    a[13,14]  R385      1
    a[13,14]  surrogate_G  1
    a[13,14]  physical_G_upper  1
    a[13,15]  R386      1
    a[13,15]  R387      1
    a[13,15]  surrogate_G  1
    a[13,15]  physical_G_upper  1
    a[13,16]  R388      1
    a[13,16]  R389      1
    a[13,16]  surrogate_G  1
    a[13,16]  physical_G_upper  1
    a[13,17]  R390      1
    a[13,17]  R391      1
    a[13,17]  surrogate_G  1
    a[13,17]  physical_G_upper  1
    a[13,18]  R392      1
    a[13,18]  R393      1
    a[13,18]  surrogate_G  1
    a[13,18]  physical_G_upper  1
    a[13,19]  R394      1
    a[13,19]  R395      1
    a[13,19]  surrogate_G  1
    a[13,19]  physical_G_upper  1
    a[13,20]  R396      1
    a[13,20]  R397      1
    a[13,20]  surrogate_G  1
    a[13,20]  physical_G_upper  1
    a[14,15]  R398      1
    a[14,15]  R399      1
    a[14,15]  surrogate_G  1
    a[14,15]  physical_G_upper  1
    a[14,16]  R400      1
    a[14,16]  R401      1
    a[14,16]  surrogate_G  1
    a[14,16]  physical_G_upper  1
    a[14,17]  R402      1
    a[14,17]  R403      1
    a[14,17]  surrogate_G  1
    a[14,17]  physical_G_upper  1
    a[14,18]  R404      1
    a[14,18]  R405      1
    a[14,18]  surrogate_G  1
    a[14,18]  physical_G_upper  1
    a[14,19]  R406      1
    a[14,19]  R407      1
    a[14,19]  surrogate_G  1
    a[14,19]  physical_G_upper  1
    a[14,20]  R408      1
    a[14,20]  R409      1
    a[14,20]  surrogate_G  1
    a[14,20]  physical_G_upper  1
    a[15,16]  R410      1
    a[15,16]  R411      1
    a[15,16]  surrogate_G  1
    a[15,16]  physical_G_upper  1
    a[15,17]  R412      1
    a[15,17]  R413      1
    a[15,17]  surrogate_G  1
    a[15,17]  physical_G_upper  1
    a[15,18]  R414      1
    a[15,18]  R415      1
    a[15,18]  surrogate_G  1
    a[15,18]  physical_G_upper  1
    a[15,19]  R416      1
    a[15,19]  R417      1
    a[15,19]  surrogate_G  1
    a[15,19]  physical_G_upper  1
    a[15,20]  R418      1
    a[15,20]  R419      1
    a[15,20]  surrogate_G  1
    a[15,20]  physical_G_upper  1
    a[16,17]  R420      1
    a[16,17]  R421      1
    a[16,17]  surrogate_G  1
    a[16,17]  physical_G_upper  1
    a[16,18]  R422      1
    a[16,18]  R423      1
    a[16,18]  surrogate_G  1
    a[16,18]  physical_G_upper  1
    a[16,19]  R424      1
    a[16,19]  R425      1
    a[16,19]  surrogate_G  1
    a[16,19]  physical_G_upper  1
    a[16,20]  R426      1
    a[16,20]  R427      1
    a[16,20]  surrogate_G  1
    a[16,20]  physical_G_upper  1
    a[17,18]  R428      1
    a[17,18]  R429      1
    a[17,18]  surrogate_G  1
    a[17,18]  physical_G_upper  1
    a[17,19]  R430      1
    a[17,19]  R431      1
    a[17,19]  surrogate_G  1
    a[17,19]  physical_G_upper  1
    a[17,20]  R432      1
    a[17,20]  R433      1
    a[17,20]  surrogate_G  1
    a[17,20]  physical_G_upper  1
    a[18,19]  R434      1
    a[18,19]  R435      1
    a[18,19]  surrogate_G  1
    a[18,19]  physical_G_upper  1
    a[18,20]  R436      1
    a[18,20]  R437      1
    a[18,20]  surrogate_G  1
    a[18,20]  physical_G_upper  1
    a[19,20]  R438      1
    a[19,20]  R439      1
    a[19,20]  surrogate_G  1
    a[19,20]  physical_G_upper  1
    q         OBJ       1
    q         surrogate_G  -4.4444444444444446e+02
RHS
    RHS1      onehot_1  1
    RHS1      onehot_2  1
    RHS1      onehot_3  1
    RHS1      onehot_4  1
    RHS1      onehot_5  1
    RHS1      onehot_6  1
    RHS1      onehot_7  1
    RHS1      onehot_8  1
    RHS1      onehot_9  1
    RHS1      onehot_10  1
    RHS1      onehot_11  1
    RHS1      onehot_12  1
    RHS1      onehot_13  1
    RHS1      onehot_14  1
    RHS1      onehot_15  1
    RHS1      onehot_16  1
    RHS1      onehot_17  1
    RHS1      onehot_18  1
    RHS1      onehot_19  1
    RHS1      onehot_20  1
    RHS1      hard_lower  211
    RHS1      hard_upper  271
    RHS1      bin_lower  20
    RHS1      bin_upper  2.2222222222222221e+01
BOUNDS
 BV BND1      x[1,11] 
 BV BND1      x[2,14] 
 BV BND1      x[3,15] 
 BV BND1      x[3,24] 
 BV BND1      x[4,11] 
 BV BND1      x[5,11] 
 BV BND1      x[5,18] 
 BV BND1      x[6,11] 
 BV BND1      x[6,20] 
 BV BND1      x[7,10] 
 BV BND1      x[8,11] 
 BV BND1      x[9,9]  
 BV BND1      x[10,16]
 BV BND1      x[11,17]
 BV BND1      x[12,10]
 BV BND1      x[12,18]
 BV BND1      x[13,13]
 BV BND1      x[14,13]
 BV BND1      x[15,14]
 BV BND1      x[16,12]
 BV BND1      x[16,21]
 BV BND1      x[17,8] 
 BV BND1      x[17,16]
 BV BND1      x[18,11]
 BV BND1      x[18,20]
 BV BND1      x[19,12]
 BV BND1      x[19,20]
 BV BND1      x[20,13]
 BV BND1      x[20,21]
ENDATA
