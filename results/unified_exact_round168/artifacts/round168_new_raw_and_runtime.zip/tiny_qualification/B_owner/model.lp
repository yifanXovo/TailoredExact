\ Model Round168_restricted_family
\ LP format - for model browsing. Use MPS format to capture full model detail.
\ Signature: 0x22e36f3a1cf88253
Minimize
  G + 0.06 e_1 + 0.09 e_2 + 0.075 e_3 + 0.075 e_4
Subject To
 q_le_s_1_0: - s_1_0 + q_1_0 <= 0
 q_le_g_1_0: - G + q_1_0 <= 0
 q_ge_gs_1_0: - G - s_1_0 + q_1_0 >= -1
 q_le_s_1_1: - s_1_1 + q_1_1 <= 0
 q_le_g_1_1: - G + q_1_1 <= 0
 q_ge_gs_1_1: - G - s_1_1 + q_1_1 >= -1
 q_le_s_1_2: - s_1_2 + q_1_2 <= 0
 q_le_g_1_2: - G + q_1_2 <= 0
 q_ge_gs_1_2: - G - s_1_2 + q_1_2 >= -1
 q_le_s_1_3: - s_1_3 + q_1_3 <= 0
 q_le_g_1_3: - G + q_1_3 <= 0
 q_ge_gs_1_3: - G - s_1_3 + q_1_3 >= -1
 one_stock_1: s_1_0 + s_1_1 + s_1_2 + s_1_3 = 1
 common_G_1: - G + q_1_0 + q_1_1 + q_1_2 + q_1_3 = 0
 ratio_1: r_1 - s_1_1 - 2 s_1_2 - 3 s_1_3 = 0
 penalty_plus_1: - r_1 + e_1 >= -1
 penalty_minus_1: r_1 + e_1 >= 1
 q_le_s_2_0: - s_2_0 + q_2_0 <= 0
 q_le_g_2_0: - G + q_2_0 <= 0
 q_ge_gs_2_0: - G - s_2_0 + q_2_0 >= -1
 q_le_s_2_1: - s_2_1 + q_2_1 <= 0
 q_le_g_2_1: - G + q_2_1 <= 0
 q_ge_gs_2_1: - G - s_2_1 + q_2_1 >= -1
 q_le_s_2_2: - s_2_2 + q_2_2 <= 0
 q_le_g_2_2: - G + q_2_2 <= 0
 q_ge_gs_2_2: - G - s_2_2 + q_2_2 >= -1
 q_le_s_2_3: - s_2_3 + q_2_3 <= 0
 q_le_g_2_3: - G + q_2_3 <= 0
 q_ge_gs_2_3: - G - s_2_3 + q_2_3 >= -1
 one_stock_2: s_2_0 + s_2_1 + s_2_2 + s_2_3 = 1
 common_G_2: - G + q_2_0 + q_2_1 + q_2_2 + q_2_3 = 0
 ratio_2: r_2 - 0.5 s_2_1 - s_2_2 - 1.5 s_2_3 = 0
 penalty_plus_2: - r_2 + e_2 >= -1
 penalty_minus_2: r_2 + e_2 >= 1
 q_le_s_3_0: - s_3_0 + q_3_0 <= 0
 q_le_g_3_0: - G + q_3_0 <= 0
 q_ge_gs_3_0: - G - s_3_0 + q_3_0 >= -1
 q_le_s_3_1: - s_3_1 + q_3_1 <= 0
 q_le_g_3_1: - G + q_3_1 <= 0
 q_ge_gs_3_1: - G - s_3_1 + q_3_1 >= -1
 q_le_s_3_2: - s_3_2 + q_3_2 <= 0
 q_le_g_3_2: - G + q_3_2 <= 0
 q_ge_gs_3_2: - G - s_3_2 + q_3_2 >= -1
 q_le_s_3_3: - s_3_3 + q_3_3 <= 0
 q_le_g_3_3: - G + q_3_3 <= 0
 q_ge_gs_3_3: - G - s_3_3 + q_3_3 >= -1
 one_stock_3: s_3_0 + s_3_1 + s_3_2 + s_3_3 = 1
 common_G_3: - G + q_3_0 + q_3_1 + q_3_2 + q_3_3 = 0
 ratio_3: r_3 - s_3_1 - 2 s_3_2 - 3 s_3_3 = 0
 penalty_plus_3: - r_3 + e_3 >= -1
 penalty_minus_3: r_3 + e_3 >= 1
 q_le_s_4_0: - s_4_0 + q_4_0 <= 0
 q_le_g_4_0: - G + q_4_0 <= 0
 q_ge_gs_4_0: - G - s_4_0 + q_4_0 >= -1
 q_le_s_4_1: - s_4_1 + q_4_1 <= 0
 q_le_g_4_1: - G + q_4_1 <= 0
 q_ge_gs_4_1: - G - s_4_1 + q_4_1 >= -1
 q_le_s_4_2: - s_4_2 + q_4_2 <= 0
 q_le_g_4_2: - G + q_4_2 <= 0
 q_ge_gs_4_2: - G - s_4_2 + q_4_2 >= -1
 q_le_s_4_3: - s_4_3 + q_4_3 <= 0
 q_le_g_4_3: - G + q_4_3 <= 0
 q_ge_gs_4_3: - G - s_4_3 + q_4_3 >= -1
 one_stock_4: s_4_0 + s_4_1 + s_4_2 + s_4_3 = 1
 common_G_4: - G + q_4_0 + q_4_1 + q_4_2 + q_4_3 = 0
 ratio_4: r_4 - 0.5 s_4_1 - s_4_2 - 1.5 s_4_3 = 0
 penalty_plus_4: - r_4 + e_4 >= -1
 penalty_minus_4: r_4 + e_4 >= 1
 abs_plus_1_2: - r_1 + r_2 + h_1_2 >= 0
 abs_minus_1_2: r_1 - r_2 + h_1_2 >= 0
 abs_plus_1_3: - r_1 + r_3 + h_1_3 >= 0
 abs_minus_1_3: r_1 - r_3 + h_1_3 >= 0
 abs_plus_1_4: - r_1 + r_4 + h_1_4 >= 0
 abs_minus_1_4: r_1 - r_4 + h_1_4 >= 0
 abs_plus_2_3: - r_2 + r_3 + h_2_3 >= 0
 abs_minus_2_3: r_2 - r_3 + h_2_3 >= 0
 abs_plus_2_4: - r_2 + r_4 + h_2_4 >= 0
 abs_minus_2_4: r_2 - r_4 + h_2_4 >= 0
 abs_plus_3_4: - r_3 + r_4 + h_3_4 >= 0
 abs_minus_3_4: r_3 - r_4 + h_3_4 >= 0
 whole_system_true_Gini_epigraph: - 4 q_1_1 - 8 q_1_2 - 12 q_1_3 - 2 q_2_1
   - 4 q_2_2 - 6 q_2_3 - 4 q_3_1 - 8 q_3_2 - 12 q_3_3 - 2 q_4_1 - 4 q_4_2
   - 6 q_4_3 + h_1_2 + h_1_3 + h_1_4 + h_2_3 + h_2_4 + h_3_4 <= 0
 pickup_visit_0_1: - 2 z_0_1 + p_0_1 <= 0
 drop_visit_0_1: - z_0_1 + d_0_1 <= 0
 optional_nonzero_1: s_1_2 + z_0_1 = 1
 stock_pickup_1: - 2 s_1_0 - s_1_1 + p_0_1 = 0
 stock_drop_1: - s_1_3 + d_0_1 = 0
 pickup_visit_0_2: - z_0_2 + p_0_2 <= 0
 drop_visit_0_2: - 2 z_0_2 + d_0_2 <= 0
 optional_nonzero_2: s_2_1 + z_0_2 = 1
 stock_pickup_2: - s_2_0 + p_0_2 = 0
 stock_drop_2: - s_2_2 - 2 s_2_3 + d_0_2 = 0
 pickup_visit_1_3: - 3 z_1_3 + p_1_3 <= 0
 drop_visit_1_3: d_1_3 <= 0
 optional_nonzero_3: s_3_3 + z_1_3 = 1
 stock_pickup_3: - 3 s_3_0 - 2 s_3_1 - s_3_2 + p_1_3 = 0
 stock_drop_3: d_1_3 = 0
 pickup_visit_1_4: p_1_4 <= 0
 drop_visit_1_4: - 3 z_1_4 + d_1_4 <= 0
 optional_nonzero_4: s_4_0 + z_1_4 = 1
 stock_pickup_4: p_1_4 = 0
 stock_drop_4: - s_4_1 - 2 s_4_2 - 3 s_4_3 + d_1_4 = 0
 arc_capacity_0_0_5: - 3 a_0_0_5 + load_0_0_5 <= 0
 arc_capacity_0_0_1: - 3 a_0_0_1 + load_0_0_1 <= 0
 arc_capacity_0_1_5: - 3 a_0_1_5 + load_0_1_5 <= 0
 arc_capacity_0_0_2: - 3 a_0_0_2 + load_0_0_2 <= 0
 arc_capacity_0_2_5: - 3 a_0_2_5 + load_0_2_5 <= 0
 arc_capacity_0_1_2: - 3 a_0_1_2 + load_0_1_2 <= 0
 arc_capacity_0_2_1: - 3 a_0_2_1 + load_0_2_1 <= 0
 source_0: a_0_0_5 + a_0_0_1 + a_0_0_2 = 1
 sink_0: a_0_0_5 + a_0_1_5 + a_0_2_5 = 1
 in_degree_0_1: - z_0_1 + a_0_0_1 + a_0_2_1 = 0
 out_degree_0_1: - z_0_1 + a_0_1_5 + a_0_1_2 = 0
 load_balance_0_1: - p_0_1 + d_0_1 - load_0_0_1 + load_0_1_5 + load_0_1_2
   - load_0_2_1 = 0
 rank_min_0_1: - z_0_1 + rank_0_1 >= 0
 rank_max_0_1: - 2 z_0_1 + rank_0_1 <= 0
 in_degree_0_2: - z_0_2 + a_0_0_2 + a_0_1_2 = 0
 out_degree_0_2: - z_0_2 + a_0_2_5 + a_0_2_1 = 0
 load_balance_0_2: - p_0_2 + d_0_2 - load_0_0_2 + load_0_2_5 - load_0_1_2
   + load_0_2_1 = 0
 rank_min_0_2: - z_0_2 + rank_0_2 >= 0
 rank_max_0_2: - 2 z_0_2 + rank_0_2 <= 0
 acyclic_0_1_2: - 3 a_0_1_2 - rank_0_1 + rank_0_2 >= -2
 acyclic_0_2_1: - 3 a_0_2_1 + rank_0_1 - rank_0_2 >= -2
 full_travel_and_handling_0: 2 p_0_1 + 2 p_0_2 + a_0_0_1 + a_0_1_5
   + 2 a_0_0_2 + 2 a_0_2_5 + a_0_1_2 + a_0_2_1 <= 12
 arc_capacity_1_0_5: - 3 a_1_0_5 + load_1_0_5 <= 0
 arc_capacity_1_0_3: - 3 a_1_0_3 + load_1_0_3 <= 0
 arc_capacity_1_3_5: - 3 a_1_3_5 + load_1_3_5 <= 0
 arc_capacity_1_0_4: - 3 a_1_0_4 + load_1_0_4 <= 0
 arc_capacity_1_4_5: - 3 a_1_4_5 + load_1_4_5 <= 0
 arc_capacity_1_3_4: - 3 a_1_3_4 + load_1_3_4 <= 0
 arc_capacity_1_4_3: - 3 a_1_4_3 + load_1_4_3 <= 0
 source_1: a_1_0_5 + a_1_0_3 + a_1_0_4 = 1
 sink_1: a_1_0_5 + a_1_3_5 + a_1_4_5 = 1
 in_degree_1_3: - z_1_3 + a_1_0_3 + a_1_4_3 = 0
 out_degree_1_3: - z_1_3 + a_1_3_5 + a_1_3_4 = 0
 load_balance_1_3: - p_1_3 + d_1_3 - load_1_0_3 + load_1_3_5 + load_1_3_4
   - load_1_4_3 = 0
 rank_min_1_3: - z_1_3 + rank_1_3 >= 0
 rank_max_1_3: - 2 z_1_3 + rank_1_3 <= 0
 in_degree_1_4: - z_1_4 + a_1_0_4 + a_1_3_4 = 0
 out_degree_1_4: - z_1_4 + a_1_4_5 + a_1_4_3 = 0
 load_balance_1_4: - p_1_4 + d_1_4 - load_1_0_4 + load_1_4_5 - load_1_3_4
   + load_1_4_3 = 0
 rank_min_1_4: - z_1_4 + rank_1_4 >= 0
 rank_max_1_4: - 2 z_1_4 + rank_1_4 <= 0
 acyclic_1_3_4: - 3 a_1_3_4 - rank_1_3 + rank_1_4 >= -2
 acyclic_1_4_3: - 3 a_1_4_3 + rank_1_3 - rank_1_4 >= -2
 full_travel_and_handling_1: 2 p_1_3 + 2 p_1_4 + 3 a_1_0_3 + 3 a_1_3_5
   + 4 a_1_0_4 + 4 a_1_4_5 + a_1_3_4 + a_1_4_3 <= 12
Bounds
 G <= 1
 r_1 <= 3
 q_1_0 <= 1
 q_1_1 <= 1
 q_1_2 <= 1
 q_1_3 <= 1
 r_2 <= 1.5
 q_2_0 <= 1
 q_2_1 <= 1
 q_2_2 <= 1
 q_2_3 <= 1
 r_3 <= 3
 q_3_0 <= 1
 q_3_1 <= 1
 q_3_2 <= 1
 q_3_3 <= 1
 r_4 <= 1.5
 q_4_0 <= 1
 q_4_1 <= 1
 q_4_2 <= 1
 q_4_3 <= 1
 p_0_1 <= 2
 d_0_1 <= 1
 p_0_2 <= 1
 d_0_2 <= 2
 p_1_3 <= 3
 d_1_3 = 0
 p_1_4 = 0
 d_1_4 <= 3
 load_0_0_5 = 0
 load_0_0_1 = 0
 load_0_1_5 <= 3
 load_0_0_2 = 0
 load_0_2_5 <= 3
 load_0_1_2 <= 3
 load_0_2_1 <= 3
 rank_0_1 <= 2
 rank_0_2 <= 2
 load_1_0_5 = 0
 load_1_0_3 = 0
 load_1_3_5 <= 3
 load_1_0_4 = 0
 load_1_4_5 <= 3
 load_1_3_4 <= 3
 load_1_4_3 <= 3
 rank_1_3 <= 2
 rank_1_4 <= 2
Binaries
 s_1_0 s_1_1 s_1_2 s_1_3 s_2_0 s_2_1 s_2_2 s_2_3 s_3_0 s_3_1 s_3_2 s_3_3
 s_4_0 s_4_1 s_4_2 s_4_3 z_0_1 z_0_2 z_1_3 z_1_4 a_0_0_5 a_0_0_1 a_0_1_5
 a_0_0_2 a_0_2_5 a_0_1_2 a_0_2_1 a_1_0_5 a_1_0_3 a_1_3_5 a_1_0_4 a_1_4_5
 a_1_3_4 a_1_4_3
End
