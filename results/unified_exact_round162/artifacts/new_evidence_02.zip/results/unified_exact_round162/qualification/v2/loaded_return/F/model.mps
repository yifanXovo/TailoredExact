* Signature: 0xb4ac02ad169a993a
NAME obj
ROWS
 N  OBJ
 L  c1      
 G  c2      
 L  c3      
 L  c4      
 L  c5      
 L  c6      
 L  c7      
 L  c8      
 L  c9      
 G  c10     
 L  c11     
 L  c12     
 G  c13     
 G  c14     
 L  c15     
 L  c16     
 L  c17     
 E  c18     
 L  c19     
 E  c20     
 E  c21     
 E  c22     
 E  c23     
 L  c24     
 L  c25     
 L  c26     
 L  c27     
 L  c28     
 L  c29     
 E  c30     
 E  c31     
 E  c32     
 L  c33     
 L  c34     
 L  c35     
 G  c36     
 L  c37     
 L  c38     
 G  c39     
 L  c40     
 G  c41     
 L  c42     
 L  c43     
 L  c44     
 L  c45     
 L  c46     
 L  c47     
 L  c48     
 L  c49     
 G  c50     
 L  c51     
 L  c52     
 L  c53     
 L  c54     
 L  c55     
 L  c56     
 G  c57     
 L  c58     
 L  c59     
 G  c60     
 L  c61     
 G  c62     
 L  c63     
 G  c64     
 L  c65     
 G  c66     
 G  c67     
 L  c68     
 L  c69     
 E  c70     
 E  c71     
 G  c72     
 G  c73     
 E  c74     
 E  c75     
 G  c76     
 G  c77     
 L  c78     
 L  c79     
 L  c80     
 L  c81     
 L  c82     
 G  c83     
 G  c84     
 G  c85     
 L  c86     
 G  c87     
 L  c88     
 G  c89     
 L  c90     
 E  c91     
 E  c92     
 E  c93     
 E  c94     
 E  c95     
 E  c96     
 G  c97     
 L  c98     
 G  c99     
 L  c100    
 G  c101    
 L  c102    
 E  c103    
 E  c104    
 E  c105    
 E  c106    
 E  c107    
 E  c108    
 G  c109    
 G  c110    
 L  c111    
 L  c112    
 G  c113    
 E  pc162_lambda_sum
 E  pc162_G_link
 E  pc162_sum_x_0_0_1
 G  pc162_lbL_x_0_0_1
 L  pc162_ubL_x_0_0_1
 G  pc162_lbU_x_0_0_1
 L  pc162_ubU_x_0_0_1
 E  pc162_sum_x_0_0_2
 G  pc162_lbL_x_0_0_2
 L  pc162_ubL_x_0_0_2
 G  pc162_lbU_x_0_0_2
 L  pc162_ubU_x_0_0_2
 E  pc162_sum_x_0_1_0
 G  pc162_lbL_x_0_1_0
 L  pc162_ubL_x_0_1_0
 G  pc162_lbU_x_0_1_0
 L  pc162_ubU_x_0_1_0
 E  pc162_sum_x_0_2_0
 G  pc162_lbL_x_0_2_0
 L  pc162_ubL_x_0_2_0
 G  pc162_lbU_x_0_2_0
 L  pc162_ubU_x_0_2_0
 E  pc162_sum_x_0_2_1
 G  pc162_lbL_x_0_2_1
 L  pc162_ubL_x_0_2_1
 G  pc162_lbU_x_0_2_1
 L  pc162_ubU_x_0_2_1
 E  pc162_sum_z_0_1
 G  pc162_lbL_z_0_1
 L  pc162_ubL_z_0_1
 G  pc162_lbU_z_0_1
 L  pc162_ubU_z_0_1
 E  pc162_sum_x_0_1_2
 G  pc162_lbL_x_0_1_2
 L  pc162_ubL_x_0_1_2
 G  pc162_lbU_x_0_1_2
 L  pc162_ubU_x_0_1_2
 E  pc162_sum_z_0_2
 G  pc162_lbL_z_0_2
 L  pc162_ubL_z_0_2
 G  pc162_lbU_z_0_2
 L  pc162_ubU_z_0_2
 E  pc162_sum_conn_0_0_1
 G  pc162_lbL_conn_0_0_1
 L  pc162_ubL_conn_0_0_1
 G  pc162_lbU_conn_0_0_1
 L  pc162_ubU_conn_0_0_1
 E  pc162_sum_conn_0_0_2
 G  pc162_lbL_conn_0_0_2
 L  pc162_ubL_conn_0_0_2
 G  pc162_lbU_conn_0_0_2
 L  pc162_ubU_conn_0_0_2
 E  pc162_sum_conn_0_1_0
 G  pc162_lbL_conn_0_1_0
 L  pc162_ubL_conn_0_1_0
 G  pc162_lbU_conn_0_1_0
 L  pc162_ubU_conn_0_1_0
 E  pc162_sum_conn_0_1_2
 G  pc162_lbL_conn_0_1_2
 L  pc162_ubL_conn_0_1_2
 G  pc162_lbU_conn_0_1_2
 L  pc162_ubU_conn_0_1_2
 E  pc162_sum_conn_0_2_0
 G  pc162_lbL_conn_0_2_0
 L  pc162_ubL_conn_0_2_0
 G  pc162_lbU_conn_0_2_0
 L  pc162_ubU_conn_0_2_0
 E  pc162_sum_conn_0_2_1
 G  pc162_lbL_conn_0_2_1
 L  pc162_ubL_conn_0_2_1
 G  pc162_lbU_conn_0_2_1
 L  pc162_ubU_conn_0_2_1
 E  pc162_sum_Y_1
 G  pc162_lbL_Y_1
 L  pc162_ubL_Y_1
 G  pc162_lbU_Y_1
 L  pc162_ubU_Y_1
 E  pc162_product_Y_1
 E  pc162_sum_Y_2
 G  pc162_lbL_Y_2
 L  pc162_ubL_Y_2
 G  pc162_lbU_Y_2
 L  pc162_ubU_Y_2
 E  pc162_product_Y_2
 E  pc162_sum_d_0_1
 G  pc162_lbL_d_0_1
 L  pc162_ubL_d_0_1
 G  pc162_lbU_d_0_1
 L  pc162_ubU_d_0_1
 E  pc162_sum_p_0_2
 G  pc162_lbL_p_0_2
 L  pc162_ubL_p_0_2
 G  pc162_lbU_p_0_2
 L  pc162_ubU_p_0_2
 E  pc162_sum_d_0_2
 G  pc162_lbL_d_0_2
 L  pc162_ubL_d_0_2
 G  pc162_lbU_d_0_2
 L  pc162_ubU_d_0_2
 E  pc162_sum_p_0_1
 G  pc162_lbL_p_0_1
 L  pc162_ubL_p_0_1
 G  pc162_lbU_p_0_1
 L  pc162_ubU_p_0_1
 E  pc162_sum_ord_0_1
 G  pc162_lbL_ord_0_1
 L  pc162_ubL_ord_0_1
 G  pc162_lbU_ord_0_1
 L  pc162_ubU_ord_0_1
 E  pc162_sum_ord_0_2
 G  pc162_lbL_ord_0_2
 L  pc162_ubL_ord_0_2
 G  pc162_lbU_ord_0_2
 L  pc162_ubU_ord_0_2
 E  pc162_sum_mode_0_1
 G  pc162_lbL_mode_0_1
 L  pc162_ubL_mode_0_1
 G  pc162_lbU_mode_0_1
 L  pc162_ubU_mode_0_1
 E  pc162_sum_load_0_1
 G  pc162_lbL_load_0_1
 L  pc162_ubL_load_0_1
 G  pc162_lbU_load_0_1
 L  pc162_ubU_load_0_1
 E  pc162_sum_mode_0_2
 G  pc162_lbL_mode_0_2
 L  pc162_ubL_mode_0_2
 G  pc162_lbU_mode_0_2
 L  pc162_ubU_mode_0_2
 E  pc162_sum_load_0_2
 G  pc162_lbL_load_0_2
 L  pc162_ubL_load_0_2
 G  pc162_lbU_load_0_2
 L  pc162_ubU_load_0_2
 E  pc162_sum_state_1_0
 G  pc162_lbL_state_1_0
 L  pc162_ubL_state_1_0
 G  pc162_lbU_state_1_0
 L  pc162_ubU_state_1_0
 E  pc162_product_state_1_0
 E  pc162_sum_state_1_1
 G  pc162_lbL_state_1_1
 L  pc162_ubL_state_1_1
 G  pc162_lbU_state_1_1
 L  pc162_ubU_state_1_1
 E  pc162_product_state_1_1
 E  pc162_sum_state_1_2
 G  pc162_lbL_state_1_2
 L  pc162_ubL_state_1_2
 G  pc162_lbU_state_1_2
 L  pc162_ubU_state_1_2
 E  pc162_product_state_1_2
 E  pc162_sum_state_2_0
 G  pc162_lbL_state_2_0
 L  pc162_ubL_state_2_0
 G  pc162_lbU_state_2_0
 L  pc162_ubU_state_2_0
 E  pc162_product_state_2_0
 E  pc162_sum_state_2_1
 G  pc162_lbL_state_2_1
 L  pc162_ubL_state_2_1
 G  pc162_lbU_state_2_1
 L  pc162_ubU_state_2_1
 E  pc162_product_state_2_1
 E  pc162_sum_state_2_2
 G  pc162_lbL_state_2_2
 L  pc162_ubL_state_2_2
 G  pc162_lbU_state_2_2
 L  pc162_ubU_state_2_2
 E  pc162_product_state_2_2
 E  pc162_qL_c18
 E  pc162_qU_c18
 L  pc162_qL_c19
 L  pc162_qU_c19
 E  pc162_qL_c20
 E  pc162_qU_c20
 E  pc162_qL_c21
 E  pc162_qU_c21
 E  pc162_qL_c22
 E  pc162_qU_c22
 E  pc162_qL_c23
 E  pc162_qU_c23
 L  pc162_qL_c24
 L  pc162_qU_c24
 L  pc162_qL_c25
 L  pc162_qU_c25
 L  pc162_qL_c26
 L  pc162_qU_c26
 L  pc162_qL_c27
 L  pc162_qU_c27
 L  pc162_qL_c28
 L  pc162_qU_c28
 L  pc162_qL_c29
 L  pc162_qU_c29
 E  pc162_qL_c30
 E  pc162_qU_c30
 E  pc162_qL_c31
 E  pc162_qU_c31
 E  pc162_qL_c32
 E  pc162_qU_c32
 L  pc162_qL_c33
 L  pc162_qU_c33
 L  pc162_qL_c34
 L  pc162_qU_c34
 L  pc162_qL_c35
 L  pc162_qU_c35
 G  pc162_qL_c36
 G  pc162_qU_c36
 L  pc162_qL_c37
 L  pc162_qU_c37
 L  pc162_qL_c38
 L  pc162_qU_c38
 G  pc162_qL_c39
 G  pc162_qU_c39
 L  pc162_qL_c40
 L  pc162_qU_c40
 G  pc162_qL_c41
 G  pc162_qU_c41
 L  pc162_qL_c42
 L  pc162_qU_c42
 L  pc162_qL_c43
 L  pc162_qU_c43
 L  pc162_qL_c44
 L  pc162_qU_c44
 L  pc162_qL_c45
 L  pc162_qU_c45
 L  pc162_qL_c46
 L  pc162_qU_c46
 L  pc162_qL_c47
 L  pc162_qU_c47
 L  pc162_qL_c48
 L  pc162_qU_c48
 L  pc162_qL_c49
 L  pc162_qU_c49
 G  pc162_qL_c50
 G  pc162_qU_c50
 L  pc162_qL_c51
 L  pc162_qU_c51
 L  pc162_qL_c52
 L  pc162_qU_c52
 L  pc162_qL_c53
 L  pc162_qU_c53
 L  pc162_qL_c54
 L  pc162_qU_c54
 L  pc162_qL_c55
 L  pc162_qU_c55
 L  pc162_qL_c56
 L  pc162_qU_c56
 G  pc162_qL_c57
 G  pc162_qU_c57
 L  pc162_qL_c58
 L  pc162_qU_c58
 L  pc162_qL_c59
 L  pc162_qU_c59
 G  pc162_qL_c60
 G  pc162_qU_c60
 L  pc162_qL_c61
 L  pc162_qU_c61
 G  pc162_qL_c62
 G  pc162_qU_c62
 L  pc162_qL_c63
 L  pc162_qU_c63
 G  pc162_qL_c64
 G  pc162_qU_c64
 L  pc162_qL_c65
 L  pc162_qU_c65
 G  pc162_qL_c66
 G  pc162_qU_c66
 G  pc162_qL_c67
 G  pc162_qU_c67
 L  pc162_qL_c68
 L  pc162_qU_c68
 L  pc162_qL_c69
 L  pc162_qU_c69
 E  pc162_qL_c70
 E  pc162_qU_c70
 E  pc162_qL_c74
 E  pc162_qU_c74
 L  pc162_qL_c78
 L  pc162_qU_c78
 L  pc162_qL_c79
 L  pc162_qU_c79
 L  pc162_qL_c80
 L  pc162_qU_c80
 L  pc162_qL_c81
 L  pc162_qU_c81
 L  pc162_qL_c82
 L  pc162_qU_c82
 E  pc162_qL_c91
 E  pc162_qU_c91
 E  pc162_qL_c92
 E  pc162_qU_c92
 E  pc162_qL_c93
 E  pc162_qU_c93
 E  pc162_qL_c94
 E  pc162_qU_c94
 E  pc162_qL_c103
 E  pc162_qU_c103
 E  pc162_qL_c104
 E  pc162_qU_c104
 E  pc162_qL_c105
 E  pc162_qU_c105
 E  pc162_qL_c106
 E  pc162_qU_c106
COLUMNS
    G         OBJ       1
    G         c8        1
    G         c95       -1
    G         c107      -1
    G         c110      -2
    G         c112      -2
    G         pc162_G_link  1
    e_1       OBJ       0.1
    e_1       c8        0.1
    e_1       c9        6.0000000000000009e-01
    e_1       c10       1
    e_1       c11       1
    e_1       c14       -3
    e_1       c15       -3
    e_1       c72       1
    e_1       c73       1
    e_2       OBJ       0.1
    e_2       c8        0.1
    e_2       c9        6.0000000000000009e-01
    e_2       c10       1
    e_2       c12       1
    e_2       c14       -3
    e_2       c15       -3
    e_2       c76       1
    e_2       c77       1
    h_1_2     c1        1
    h_1_2     c2        1
    h_1_2     c3        1
    h_1_2     c9        1
    h_1_2     c17       1
    h_1_2     c83       1
    h_1_2     c84       1
    h_1_2     c113      -1
    r_1       c1        -1
    r_1       c3        -1
    r_1       c4        1
    r_1       c5        -1
    r_1       c7        -2
    r_1       c14       -2
    r_1       c16       -2
    r_1       c17       -1.2000000000000002e+00
    r_1       c71       1
    r_1       c72       -1
    r_1       c73       1
    r_1       c83       -1
    r_1       c84       1
    r_2       c1        -1
    r_2       c3        -1
    r_2       c4        -1
    r_2       c5        1
    r_2       c6        -2
    r_2       c14       -2
    r_2       c16       -2
    r_2       c17       -1.2000000000000002e+00
    r_2       c75       1
    r_2       c76       -1
    r_2       c77       1
    r_2       c83       1
    r_2       c84       -1
    W_SP      c13       1
    W_SP      c14       1
    W_SP      c15       1
    W_SP      c16       1
    W_SP      c17       0.2
    MARKER    'MARKER'                 'INTORG'
    x_0_0_1   c18       1
    x_0_0_1   c19       1
    x_0_0_1   c20       1
    x_0_0_1   c24       -2
    x_0_0_1   c59       2
    x_0_0_1   c60       -2
    x_0_0_1   pc162_sum_x_0_0_1  1
    x_0_0_2   c18       1
    x_0_0_2   c19       1
    x_0_0_2   c22       1
    x_0_0_2   c25       -2
    x_0_0_2   c61       2
    x_0_0_2   c62       -2
    x_0_0_2   pc162_sum_x_0_0_2  1
    x_0_1_0   c18       -1
    x_0_1_0   c21       1
    x_0_1_0   c26       -2
    x_0_1_0   pc162_sum_x_0_1_0  1
    x_0_2_0   c18       -1
    x_0_2_0   c23       1
    x_0_2_0   c28       -2
    x_0_2_0   pc162_sum_x_0_2_0  1
    x_0_2_1   c20       1
    x_0_2_1   c23       1
    x_0_2_1   c29       -2
    x_0_2_1   c44       2
    x_0_2_1   c65       2
    x_0_2_1   c66       -2
    x_0_2_1   pc162_sum_x_0_2_1  1
    z_0_1     c20       -1
    z_0_1     c21       -1
    z_0_1     c30       -1
    z_0_1     c32       -1
    z_0_1     c33       1
    z_0_1     c39       -1
    z_0_1     c40       -2
    z_0_1     c45       -2
    z_0_1     c47       -1
    z_0_1     c50       -1
    z_0_1     c51       -2
    z_0_1     c69       110
    z_0_1     c79       -2
    z_0_1     c92       1
    z_0_1     pc162_sum_z_0_1  1
    x_0_1_2   c21       1
    x_0_1_2   c22       1
    x_0_1_2   c27       -2
    x_0_1_2   c43       2
    x_0_1_2   c63       2
    x_0_1_2   c64       -2
    x_0_1_2   pc162_sum_x_0_1_2  1
    z_0_2     c22       -1
    z_0_2     c23       -1
    z_0_2     c31       -1
    z_0_2     c32       -1
    z_0_2     c34       1
    z_0_2     c41       -1
    z_0_2     c42       -2
    z_0_2     c53       -2
    z_0_2     c54       -1
    z_0_2     c56       -2
    z_0_2     c57       -1
    z_0_2     c58       -2
    z_0_2     c69       110
    z_0_2     c80       -2
    z_0_2     c104      1
    z_0_2     pc162_sum_z_0_2  1
    MARKER    'MARKER'                 'INTEND'
    conn_0_0_1  c24       1
    conn_0_0_1  c30       1
    conn_0_0_1  c32       1
    conn_0_0_1  pc162_sum_conn_0_0_1  1
    conn_0_0_2  c25       1
    conn_0_0_2  c31       1
    conn_0_0_2  c32       1
    conn_0_0_2  pc162_sum_conn_0_0_2  1
    conn_0_1_0  c26       1
    conn_0_1_0  c30       -1
    conn_0_1_0  c32       -1
    conn_0_1_0  pc162_sum_conn_0_1_0  1
    conn_0_1_2  c27       1
    conn_0_1_2  c30       -1
    conn_0_1_2  c31       1
    conn_0_1_2  pc162_sum_conn_0_1_2  1
    conn_0_2_0  c28       1
    conn_0_2_0  c31       -1
    conn_0_2_0  c32       -1
    conn_0_2_0  pc162_sum_conn_0_2_0  1
    conn_0_2_1  c29       1
    conn_0_2_1  c30       1
    conn_0_2_1  c31       -1
    conn_0_2_1  pc162_sum_conn_0_2_1  1
    MARKER    'MARKER'                 'INTORG'
    Y_1       c35       1
    Y_1       c36       1
    Y_1       c70       1
    Y_1       c71       -1
    Y_1       c78       1
    Y_1       c79       -1
    Y_1       c94       1
    Y_1       c110      -5.0000000000000011e-01
    Y_1       c111      -5.0000000000000011e-01
    Y_1       pc162_sum_Y_1  1
    Y_2       c35       1
    Y_2       c36       1
    Y_2       c74       1
    Y_2       c75       -0.5
    Y_2       c80       1
    Y_2       c81       -1
    Y_2       c106      1
    Y_2       c110      -5.0000000000000011e-01
    Y_2       c111      -5.0000000000000011e-01
    Y_2       pc162_sum_Y_2  1
    MARKER    'MARKER'                 'INTEND'
    d_0_1     c37       1
    d_0_1     c46       1
    d_0_1     c49       1
    d_0_1     c50       1
    d_0_1     c59       1
    d_0_1     c60       1
    d_0_1     c65       1
    d_0_1     c66       1
    d_0_1     c67       -1
    d_0_1     c70       -1
    d_0_1     c91       1
    d_0_1     pc162_sum_d_0_1  1
    p_0_2     c37       -1
    p_0_2     c52       1
    p_0_2     c55       1
    p_0_2     c57       1
    p_0_2     c61       -1
    p_0_2     c62       -1
    p_0_2     c63       -1
    p_0_2     c64       -1
    p_0_2     c67       1
    p_0_2     c68       5
    p_0_2     c69       5
    p_0_2     c74       1
    p_0_2     c82       5
    p_0_2     c103      1
    p_0_2     pc162_sum_p_0_2  1
    d_0_2     c38       1
    d_0_2     c53       1
    d_0_2     c56       1
    d_0_2     c57       1
    d_0_2     c61       1
    d_0_2     c62       1
    d_0_2     c63       1
    d_0_2     c64       1
    d_0_2     c67       -1
    d_0_2     c74       -1
    d_0_2     c103      1
    d_0_2     pc162_sum_d_0_2  1
    p_0_1     c38       -1
    p_0_1     c45       1
    p_0_1     c48       1
    p_0_1     c50       1
    p_0_1     c59       -1
    p_0_1     c60       -1
    p_0_1     c65       -1
    p_0_1     c66       -1
    p_0_1     c67       1
    p_0_1     c68       5
    p_0_1     c69       5
    p_0_1     c70       1
    p_0_1     c82       5
    p_0_1     c91       1
    p_0_1     pc162_sum_p_0_1  1
    ord_0_1   c39       1
    ord_0_1   c40       1
    ord_0_1   c43       1
    ord_0_1   c44       -1
    ord_0_1   pc162_sum_ord_0_1  1
    ord_0_2   c41       1
    ord_0_2   c42       1
    ord_0_2   c43       -1
    ord_0_2   c44       1
    ord_0_2   pc162_sum_ord_0_2  1
    MARKER    'MARKER'                 'INTORG'
    mode_0_1  c47       1
    mode_0_1  c48       -2
    mode_0_1  pc162_sum_mode_0_1  1
    load_0_1  c51       1
    load_0_1  c59       1
    load_0_1  c60       1
    load_0_1  c63       -1
    load_0_1  c64       -1
    load_0_1  c65       1
    load_0_1  c66       1
    load_0_1  pc162_sum_load_0_1  1
    mode_0_2  c54       1
    mode_0_2  c56       2
    mode_0_2  pc162_sum_mode_0_2  1
    load_0_2  c58       1
    load_0_2  c61       1
    load_0_2  c62       1
    load_0_2  c63       1
    load_0_2  c64       1
    load_0_2  c65       -1
    load_0_2  c66       -1
    load_0_2  pc162_sum_load_0_2  1
    MARKER    'MARKER'                 'INTEND'
    state_g_1_0  c85       1
    state_g_1_0  c86       1
    state_g_1_0  c95       1
    state_g_1_0  pc162_product_state_1_0  1
    MARKER    'MARKER'                 'INTORG'
    state_1_0  c86       -5.0000000000000011e-01
    state_1_0  c91       -2
    state_1_0  c93       1
    state_1_0  pc162_sum_state_1_0  1
    MARKER    'MARKER'                 'INTEND'
    state_g_1_1  c87       1
    state_g_1_1  c88       1
    state_g_1_1  c95       1
    state_g_1_1  c96       -1
    state_g_1_1  pc162_product_state_1_1  1
    MARKER    'MARKER'                 'INTORG'
    state_1_1  c88       -5.0000000000000011e-01
    state_1_1  c91       -1
    state_1_1  c93       1
    state_1_1  c94       -1
    state_1_1  pc162_sum_state_1_1  1
    MARKER    'MARKER'                 'INTEND'
    state_g_1_2  c89       1
    state_g_1_2  c90       1
    state_g_1_2  c95       1
    state_g_1_2  c96       -2
    state_g_1_2  pc162_product_state_1_2  1
    MARKER    'MARKER'                 'INTORG'
    state_1_2  c90       -5.0000000000000011e-01
    state_1_2  c92       1
    state_1_2  c93       1
    state_1_2  c94       -2
    state_1_2  pc162_sum_state_1_2  1
    MARKER    'MARKER'                 'INTEND'
    zprod_1   c96       1
    zprod_1   c109      1
    zprod_1   c110      1
    zprod_1   c111      1
    zprod_1   c112      1
    zprod_1   c113      2
    zprod_1   pc162_product_Y_1  1
    state_g_2_0  c97       1
    state_g_2_0  c98       1
    state_g_2_0  c107      1
    state_g_2_0  pc162_product_state_2_0  1
    MARKER    'MARKER'                 'INTORG'
    state_2_0  c98       -5.0000000000000011e-01
    state_2_0  c104      1
    state_2_0  c105      1
    state_2_0  pc162_sum_state_2_0  1
    MARKER    'MARKER'                 'INTEND'
    state_g_2_1  c99       1
    state_g_2_1  c100      1
    state_g_2_1  c107      1
    state_g_2_1  c108      -1
    state_g_2_1  pc162_product_state_2_1  1
    MARKER    'MARKER'                 'INTORG'
    state_2_1  c100      -5.0000000000000011e-01
    state_2_1  c103      -1
    state_2_1  c105      1
    state_2_1  c106      -1
    state_2_1  pc162_sum_state_2_1  1
    MARKER    'MARKER'                 'INTEND'
    state_g_2_2  c101      1
    state_g_2_2  c102      1
    state_g_2_2  c107      1
    state_g_2_2  c108      -2
    state_g_2_2  pc162_product_state_2_2  1
    MARKER    'MARKER'                 'INTORG'
    state_2_2  c102      -5.0000000000000011e-01
    state_2_2  c103      -2
    state_2_2  c105      1
    state_2_2  c106      -2
    state_2_2  pc162_sum_state_2_2  1
    MARKER    'MARKER'                 'INTEND'
    zprod_2   c108      1
    zprod_2   c109      1
    zprod_2   c110      1
    zprod_2   c111      1
    zprod_2   c112      1
    zprod_2   c113      1
    zprod_2   pc162_product_Y_2  1
    r_max     OBJ       0
    r_min     OBJ       0
    pc162_lambda_L  pc162_lambda_sum  1
    pc162_lambda_L  pc162_ubL_x_0_0_1  -1
    pc162_lambda_L  pc162_ubL_x_0_0_2  -1
    pc162_lambda_L  pc162_ubL_x_0_1_0  -1
    pc162_lambda_L  pc162_ubL_x_0_2_0  -1
    pc162_lambda_L  pc162_ubL_x_0_2_1  -1
    pc162_lambda_L  pc162_ubL_z_0_1  -1
    pc162_lambda_L  pc162_ubL_x_0_1_2  -1
    pc162_lambda_L  pc162_ubL_z_0_2  -1
    pc162_lambda_L  pc162_ubL_conn_0_0_1  -2
    pc162_lambda_L  pc162_ubL_conn_0_0_2  -2
    pc162_lambda_L  pc162_ubL_conn_0_1_0  -2
    pc162_lambda_L  pc162_ubL_conn_0_1_2  -2
    pc162_lambda_L  pc162_ubL_conn_0_2_0  -2
    pc162_lambda_L  pc162_ubL_conn_0_2_1  -2
    pc162_lambda_L  pc162_ubL_Y_1  -2
    pc162_lambda_L  pc162_ubL_Y_2  -2
    pc162_lambda_L  pc162_ubL_d_0_2  -2
    pc162_lambda_L  pc162_ubL_p_0_1  -2
    pc162_lambda_L  pc162_ubL_ord_0_1  -2
    pc162_lambda_L  pc162_ubL_ord_0_2  -2
    pc162_lambda_L  pc162_ubL_mode_0_1  -1
    pc162_lambda_L  pc162_ubL_load_0_1  -2
    pc162_lambda_L  pc162_ubL_mode_0_2  -1
    pc162_lambda_L  pc162_ubL_load_0_2  -2
    pc162_lambda_L  pc162_ubL_state_1_0  -1
    pc162_lambda_L  pc162_ubL_state_1_1  -1
    pc162_lambda_L  pc162_ubL_state_1_2  -1
    pc162_lambda_L  pc162_ubL_state_2_0  -1
    pc162_lambda_L  pc162_ubL_state_2_1  -1
    pc162_lambda_L  pc162_ubL_state_2_2  -1
    pc162_lambda_L  pc162_qL_c19  -1
    pc162_lambda_L  pc162_qL_c33  -1
    pc162_lambda_L  pc162_qL_c34  -1
    pc162_lambda_L  pc162_qL_c35  -2
    pc162_lambda_L  pc162_qL_c43  -1
    pc162_lambda_L  pc162_qL_c44  -1
    pc162_lambda_L  pc162_qL_c59  -2
    pc162_lambda_L  pc162_qL_c60  2
    pc162_lambda_L  pc162_qL_c61  -2
    pc162_lambda_L  pc162_qL_c62  2
    pc162_lambda_L  pc162_qL_c63  -2
    pc162_lambda_L  pc162_qL_c64  2
    pc162_lambda_L  pc162_qL_c65  -2
    pc162_lambda_L  pc162_qL_c66  2
    pc162_lambda_L  pc162_qL_c68  -100
    pc162_lambda_L  pc162_qL_c69  -320
    pc162_lambda_L  pc162_qL_c70  -2
    pc162_lambda_L  pc162_qL_c78  -2
    pc162_lambda_L  pc162_qL_c79  2
    pc162_lambda_L  pc162_qL_c82  -100
    pc162_lambda_L  pc162_qL_c92  -1
    pc162_lambda_L  pc162_qL_c93  -1
    pc162_lambda_L  pc162_qL_c104  -1
    pc162_lambda_L  pc162_qL_c105  -1
    pc162_lambda_U  pc162_lambda_sum  1
    pc162_lambda_U  pc162_G_link  -5.0000000000000011e-01
    pc162_lambda_U  pc162_ubU_x_0_0_1  -1
    pc162_lambda_U  pc162_ubU_x_0_0_2  -1
    pc162_lambda_U  pc162_ubU_x_0_1_0  -1
    pc162_lambda_U  pc162_ubU_x_0_2_0  -1
    pc162_lambda_U  pc162_ubU_x_0_2_1  -1
    pc162_lambda_U  pc162_ubU_z_0_1  -1
    pc162_lambda_U  pc162_ubU_x_0_1_2  -1
    pc162_lambda_U  pc162_ubU_z_0_2  -1
    pc162_lambda_U  pc162_ubU_conn_0_0_1  -2
    pc162_lambda_U  pc162_ubU_conn_0_0_2  -2
    pc162_lambda_U  pc162_ubU_conn_0_1_0  -2
    pc162_lambda_U  pc162_ubU_conn_0_1_2  -2
    pc162_lambda_U  pc162_ubU_conn_0_2_0  -2
    pc162_lambda_U  pc162_ubU_conn_0_2_1  -2
    pc162_lambda_U  pc162_ubU_Y_1  -2
    pc162_lambda_U  pc162_ubU_Y_2  -2
    pc162_lambda_U  pc162_ubU_d_0_2  -2
    pc162_lambda_U  pc162_ubU_p_0_1  -2
    pc162_lambda_U  pc162_ubU_ord_0_1  -2
    pc162_lambda_U  pc162_ubU_ord_0_2  -2
    pc162_lambda_U  pc162_ubU_mode_0_1  -1
    pc162_lambda_U  pc162_ubU_load_0_1  -2
    pc162_lambda_U  pc162_ubU_mode_0_2  -1
    pc162_lambda_U  pc162_ubU_load_0_2  -2
    pc162_lambda_U  pc162_ubU_state_1_0  -1
    pc162_lambda_U  pc162_ubU_state_1_1  -1
    pc162_lambda_U  pc162_ubU_state_1_2  -1
    pc162_lambda_U  pc162_ubU_state_2_0  -1
    pc162_lambda_U  pc162_ubU_state_2_1  -1
    pc162_lambda_U  pc162_ubU_state_2_2  -1
    pc162_lambda_U  pc162_qU_c19  -1
    pc162_lambda_U  pc162_qU_c33  -1
    pc162_lambda_U  pc162_qU_c34  -1
    pc162_lambda_U  pc162_qU_c35  -2
    pc162_lambda_U  pc162_qU_c43  -1
    pc162_lambda_U  pc162_qU_c44  -1
    pc162_lambda_U  pc162_qU_c59  -2
    pc162_lambda_U  pc162_qU_c60  2
    pc162_lambda_U  pc162_qU_c61  -2
    pc162_lambda_U  pc162_qU_c62  2
    pc162_lambda_U  pc162_qU_c63  -2
    pc162_lambda_U  pc162_qU_c64  2
    pc162_lambda_U  pc162_qU_c65  -2
    pc162_lambda_U  pc162_qU_c66  2
    pc162_lambda_U  pc162_qU_c68  -100
    pc162_lambda_U  pc162_qU_c69  -320
    pc162_lambda_U  pc162_qU_c70  -2
    pc162_lambda_U  pc162_qU_c78  -2
    pc162_lambda_U  pc162_qU_c79  2
    pc162_lambda_U  pc162_qU_c82  -100
    pc162_lambda_U  pc162_qU_c92  -1
    pc162_lambda_U  pc162_qU_c93  -1
    pc162_lambda_U  pc162_qU_c104  -1
    pc162_lambda_U  pc162_qU_c105  -1
    pc162_L_x_0_0_1  pc162_sum_x_0_0_1  -1
    pc162_L_x_0_0_1  pc162_lbL_x_0_0_1  1
    pc162_L_x_0_0_1  pc162_ubL_x_0_0_1  1
    pc162_L_x_0_0_1  pc162_qL_c18  1
    pc162_L_x_0_0_1  pc162_qL_c19  1
    pc162_L_x_0_0_1  pc162_qL_c20  1
    pc162_L_x_0_0_1  pc162_qL_c24  -2
    pc162_L_x_0_0_1  pc162_qL_c59  2
    pc162_L_x_0_0_1  pc162_qL_c60  -2
    pc162_U_x_0_0_1  pc162_sum_x_0_0_1  -1
    pc162_U_x_0_0_1  pc162_lbU_x_0_0_1  1
    pc162_U_x_0_0_1  pc162_ubU_x_0_0_1  1
    pc162_U_x_0_0_1  pc162_qU_c18  1
    pc162_U_x_0_0_1  pc162_qU_c19  1
    pc162_U_x_0_0_1  pc162_qU_c20  1
    pc162_U_x_0_0_1  pc162_qU_c24  -2
    pc162_U_x_0_0_1  pc162_qU_c59  2
    pc162_U_x_0_0_1  pc162_qU_c60  -2
    pc162_L_x_0_0_2  pc162_sum_x_0_0_2  -1
    pc162_L_x_0_0_2  pc162_lbL_x_0_0_2  1
    pc162_L_x_0_0_2  pc162_ubL_x_0_0_2  1
    pc162_L_x_0_0_2  pc162_qL_c18  1
    pc162_L_x_0_0_2  pc162_qL_c19  1
    pc162_L_x_0_0_2  pc162_qL_c22  1
    pc162_L_x_0_0_2  pc162_qL_c25  -2
    pc162_L_x_0_0_2  pc162_qL_c61  2
    pc162_L_x_0_0_2  pc162_qL_c62  -2
    pc162_U_x_0_0_2  pc162_sum_x_0_0_2  -1
    pc162_U_x_0_0_2  pc162_lbU_x_0_0_2  1
    pc162_U_x_0_0_2  pc162_ubU_x_0_0_2  1
    pc162_U_x_0_0_2  pc162_qU_c18  1
    pc162_U_x_0_0_2  pc162_qU_c19  1
    pc162_U_x_0_0_2  pc162_qU_c22  1
    pc162_U_x_0_0_2  pc162_qU_c25  -2
    pc162_U_x_0_0_2  pc162_qU_c61  2
    pc162_U_x_0_0_2  pc162_qU_c62  -2
    pc162_L_x_0_1_0  pc162_sum_x_0_1_0  -1
    pc162_L_x_0_1_0  pc162_lbL_x_0_1_0  1
    pc162_L_x_0_1_0  pc162_ubL_x_0_1_0  1
    pc162_L_x_0_1_0  pc162_qL_c18  -1
    pc162_L_x_0_1_0  pc162_qL_c21  1
    pc162_L_x_0_1_0  pc162_qL_c26  -2
    pc162_U_x_0_1_0  pc162_sum_x_0_1_0  -1
    pc162_U_x_0_1_0  pc162_lbU_x_0_1_0  1
    pc162_U_x_0_1_0  pc162_ubU_x_0_1_0  1
    pc162_U_x_0_1_0  pc162_qU_c18  -1
    pc162_U_x_0_1_0  pc162_qU_c21  1
    pc162_U_x_0_1_0  pc162_qU_c26  -2
    pc162_L_x_0_2_0  pc162_sum_x_0_2_0  -1
    pc162_L_x_0_2_0  pc162_lbL_x_0_2_0  1
    pc162_L_x_0_2_0  pc162_ubL_x_0_2_0  1
    pc162_L_x_0_2_0  pc162_qL_c18  -1
    pc162_L_x_0_2_0  pc162_qL_c23  1
    pc162_L_x_0_2_0  pc162_qL_c28  -2
    pc162_U_x_0_2_0  pc162_sum_x_0_2_0  -1
    pc162_U_x_0_2_0  pc162_lbU_x_0_2_0  1
    pc162_U_x_0_2_0  pc162_ubU_x_0_2_0  1
    pc162_U_x_0_2_0  pc162_qU_c18  -1
    pc162_U_x_0_2_0  pc162_qU_c23  1
    pc162_U_x_0_2_0  pc162_qU_c28  -2
    pc162_L_x_0_2_1  pc162_sum_x_0_2_1  -1
    pc162_L_x_0_2_1  pc162_lbL_x_0_2_1  1
    pc162_L_x_0_2_1  pc162_ubL_x_0_2_1  1
    pc162_L_x_0_2_1  pc162_qL_c20  1
    pc162_L_x_0_2_1  pc162_qL_c23  1
    pc162_L_x_0_2_1  pc162_qL_c29  -2
    pc162_L_x_0_2_1  pc162_qL_c44  2
    pc162_L_x_0_2_1  pc162_qL_c65  2
    pc162_L_x_0_2_1  pc162_qL_c66  -2
    pc162_U_x_0_2_1  pc162_sum_x_0_2_1  -1
    pc162_U_x_0_2_1  pc162_lbU_x_0_2_1  1
    pc162_U_x_0_2_1  pc162_ubU_x_0_2_1  1
    pc162_U_x_0_2_1  pc162_qU_c20  1
    pc162_U_x_0_2_1  pc162_qU_c23  1
    pc162_U_x_0_2_1  pc162_qU_c29  -2
    pc162_U_x_0_2_1  pc162_qU_c44  2
    pc162_U_x_0_2_1  pc162_qU_c65  2
    pc162_U_x_0_2_1  pc162_qU_c66  -2
    pc162_L_z_0_1  pc162_sum_z_0_1  -1
    pc162_L_z_0_1  pc162_lbL_z_0_1  1
    pc162_L_z_0_1  pc162_ubL_z_0_1  1
    pc162_L_z_0_1  pc162_qL_c20  -1
    pc162_L_z_0_1  pc162_qL_c21  -1
    pc162_L_z_0_1  pc162_qL_c30  -1
    pc162_L_z_0_1  pc162_qL_c32  -1
    pc162_L_z_0_1  pc162_qL_c33  1
    pc162_L_z_0_1  pc162_qL_c39  -1
    pc162_L_z_0_1  pc162_qL_c40  -2
    pc162_L_z_0_1  pc162_qL_c45  -2
    pc162_L_z_0_1  pc162_qL_c47  -1
    pc162_L_z_0_1  pc162_qL_c50  -1
    pc162_L_z_0_1  pc162_qL_c51  -2
    pc162_L_z_0_1  pc162_qL_c69  110
    pc162_L_z_0_1  pc162_qL_c79  -2
    pc162_L_z_0_1  pc162_qL_c92  1
    pc162_U_z_0_1  pc162_sum_z_0_1  -1
    pc162_U_z_0_1  pc162_lbU_z_0_1  1
    pc162_U_z_0_1  pc162_ubU_z_0_1  1
    pc162_U_z_0_1  pc162_qU_c20  -1
    pc162_U_z_0_1  pc162_qU_c21  -1
    pc162_U_z_0_1  pc162_qU_c30  -1
    pc162_U_z_0_1  pc162_qU_c32  -1
    pc162_U_z_0_1  pc162_qU_c33  1
    pc162_U_z_0_1  pc162_qU_c39  -1
    pc162_U_z_0_1  pc162_qU_c40  -2
    pc162_U_z_0_1  pc162_qU_c45  -2
    pc162_U_z_0_1  pc162_qU_c47  -1
    pc162_U_z_0_1  pc162_qU_c50  -1
    pc162_U_z_0_1  pc162_qU_c51  -2
    pc162_U_z_0_1  pc162_qU_c69  110
    pc162_U_z_0_1  pc162_qU_c79  -2
    pc162_U_z_0_1  pc162_qU_c92  1
    pc162_L_x_0_1_2  pc162_sum_x_0_1_2  -1
    pc162_L_x_0_1_2  pc162_lbL_x_0_1_2  1
    pc162_L_x_0_1_2  pc162_ubL_x_0_1_2  1
    pc162_L_x_0_1_2  pc162_qL_c21  1
    pc162_L_x_0_1_2  pc162_qL_c22  1
    pc162_L_x_0_1_2  pc162_qL_c27  -2
    pc162_L_x_0_1_2  pc162_qL_c43  2
    pc162_L_x_0_1_2  pc162_qL_c63  2
    pc162_L_x_0_1_2  pc162_qL_c64  -2
    pc162_U_x_0_1_2  pc162_sum_x_0_1_2  -1
    pc162_U_x_0_1_2  pc162_lbU_x_0_1_2  1
    pc162_U_x_0_1_2  pc162_ubU_x_0_1_2  1
    pc162_U_x_0_1_2  pc162_qU_c21  1
    pc162_U_x_0_1_2  pc162_qU_c22  1
    pc162_U_x_0_1_2  pc162_qU_c27  -2
    pc162_U_x_0_1_2  pc162_qU_c43  2
    pc162_U_x_0_1_2  pc162_qU_c63  2
    pc162_U_x_0_1_2  pc162_qU_c64  -2
    pc162_L_z_0_2  pc162_sum_z_0_2  -1
    pc162_L_z_0_2  pc162_lbL_z_0_2  1
    pc162_L_z_0_2  pc162_ubL_z_0_2  1
    pc162_L_z_0_2  pc162_qL_c22  -1
    pc162_L_z_0_2  pc162_qL_c23  -1
    pc162_L_z_0_2  pc162_qL_c31  -1
    pc162_L_z_0_2  pc162_qL_c32  -1
    pc162_L_z_0_2  pc162_qL_c34  1
    pc162_L_z_0_2  pc162_qL_c41  -1
    pc162_L_z_0_2  pc162_qL_c42  -2
    pc162_L_z_0_2  pc162_qL_c53  -2
    pc162_L_z_0_2  pc162_qL_c54  -1
    pc162_L_z_0_2  pc162_qL_c56  -2
    pc162_L_z_0_2  pc162_qL_c57  -1
    pc162_L_z_0_2  pc162_qL_c58  -2
    pc162_L_z_0_2  pc162_qL_c69  110
    pc162_L_z_0_2  pc162_qL_c80  -2
    pc162_L_z_0_2  pc162_qL_c104  1
    pc162_U_z_0_2  pc162_sum_z_0_2  -1
    pc162_U_z_0_2  pc162_lbU_z_0_2  1
    pc162_U_z_0_2  pc162_ubU_z_0_2  1
    pc162_U_z_0_2  pc162_qU_c22  -1
    pc162_U_z_0_2  pc162_qU_c23  -1
    pc162_U_z_0_2  pc162_qU_c31  -1
    pc162_U_z_0_2  pc162_qU_c32  -1
    pc162_U_z_0_2  pc162_qU_c34  1
    pc162_U_z_0_2  pc162_qU_c41  -1
    pc162_U_z_0_2  pc162_qU_c42  -2
    pc162_U_z_0_2  pc162_qU_c53  -2
    pc162_U_z_0_2  pc162_qU_c54  -1
    pc162_U_z_0_2  pc162_qU_c56  -2
    pc162_U_z_0_2  pc162_qU_c57  -1
    pc162_U_z_0_2  pc162_qU_c58  -2
    pc162_U_z_0_2  pc162_qU_c69  110
    pc162_U_z_0_2  pc162_qU_c80  -2
    pc162_U_z_0_2  pc162_qU_c104  1
    pc162_L_conn_0_0_1  pc162_sum_conn_0_0_1  -1
    pc162_L_conn_0_0_1  pc162_lbL_conn_0_0_1  1
    pc162_L_conn_0_0_1  pc162_ubL_conn_0_0_1  1
    pc162_L_conn_0_0_1  pc162_qL_c24  1
    pc162_L_conn_0_0_1  pc162_qL_c30  1
    pc162_L_conn_0_0_1  pc162_qL_c32  1
    pc162_U_conn_0_0_1  pc162_sum_conn_0_0_1  -1
    pc162_U_conn_0_0_1  pc162_lbU_conn_0_0_1  1
    pc162_U_conn_0_0_1  pc162_ubU_conn_0_0_1  1
    pc162_U_conn_0_0_1  pc162_qU_c24  1
    pc162_U_conn_0_0_1  pc162_qU_c30  1
    pc162_U_conn_0_0_1  pc162_qU_c32  1
    pc162_L_conn_0_0_2  pc162_sum_conn_0_0_2  -1
    pc162_L_conn_0_0_2  pc162_lbL_conn_0_0_2  1
    pc162_L_conn_0_0_2  pc162_ubL_conn_0_0_2  1
    pc162_L_conn_0_0_2  pc162_qL_c25  1
    pc162_L_conn_0_0_2  pc162_qL_c31  1
    pc162_L_conn_0_0_2  pc162_qL_c32  1
    pc162_U_conn_0_0_2  pc162_sum_conn_0_0_2  -1
    pc162_U_conn_0_0_2  pc162_lbU_conn_0_0_2  1
    pc162_U_conn_0_0_2  pc162_ubU_conn_0_0_2  1
    pc162_U_conn_0_0_2  pc162_qU_c25  1
    pc162_U_conn_0_0_2  pc162_qU_c31  1
    pc162_U_conn_0_0_2  pc162_qU_c32  1
    pc162_L_conn_0_1_0  pc162_sum_conn_0_1_0  -1
    pc162_L_conn_0_1_0  pc162_lbL_conn_0_1_0  1
    pc162_L_conn_0_1_0  pc162_ubL_conn_0_1_0  1
    pc162_L_conn_0_1_0  pc162_qL_c26  1
    pc162_L_conn_0_1_0  pc162_qL_c30  -1
    pc162_L_conn_0_1_0  pc162_qL_c32  -1
    pc162_U_conn_0_1_0  pc162_sum_conn_0_1_0  -1
    pc162_U_conn_0_1_0  pc162_lbU_conn_0_1_0  1
    pc162_U_conn_0_1_0  pc162_ubU_conn_0_1_0  1
    pc162_U_conn_0_1_0  pc162_qU_c26  1
    pc162_U_conn_0_1_0  pc162_qU_c30  -1
    pc162_U_conn_0_1_0  pc162_qU_c32  -1
    pc162_L_conn_0_1_2  pc162_sum_conn_0_1_2  -1
    pc162_L_conn_0_1_2  pc162_lbL_conn_0_1_2  1
    pc162_L_conn_0_1_2  pc162_ubL_conn_0_1_2  1
    pc162_L_conn_0_1_2  pc162_qL_c27  1
    pc162_L_conn_0_1_2  pc162_qL_c30  -1
    pc162_L_conn_0_1_2  pc162_qL_c31  1
    pc162_U_conn_0_1_2  pc162_sum_conn_0_1_2  -1
    pc162_U_conn_0_1_2  pc162_lbU_conn_0_1_2  1
    pc162_U_conn_0_1_2  pc162_ubU_conn_0_1_2  1
    pc162_U_conn_0_1_2  pc162_qU_c27  1
    pc162_U_conn_0_1_2  pc162_qU_c30  -1
    pc162_U_conn_0_1_2  pc162_qU_c31  1
    pc162_L_conn_0_2_0  pc162_sum_conn_0_2_0  -1
    pc162_L_conn_0_2_0  pc162_lbL_conn_0_2_0  1
    pc162_L_conn_0_2_0  pc162_ubL_conn_0_2_0  1
    pc162_L_conn_0_2_0  pc162_qL_c28  1
    pc162_L_conn_0_2_0  pc162_qL_c31  -1
    pc162_L_conn_0_2_0  pc162_qL_c32  -1
    pc162_U_conn_0_2_0  pc162_sum_conn_0_2_0  -1
    pc162_U_conn_0_2_0  pc162_lbU_conn_0_2_0  1
    pc162_U_conn_0_2_0  pc162_ubU_conn_0_2_0  1
    pc162_U_conn_0_2_0  pc162_qU_c28  1
    pc162_U_conn_0_2_0  pc162_qU_c31  -1
    pc162_U_conn_0_2_0  pc162_qU_c32  -1
    pc162_L_conn_0_2_1  pc162_sum_conn_0_2_1  -1
    pc162_L_conn_0_2_1  pc162_lbL_conn_0_2_1  1
    pc162_L_conn_0_2_1  pc162_ubL_conn_0_2_1  1
    pc162_L_conn_0_2_1  pc162_qL_c29  1
    pc162_L_conn_0_2_1  pc162_qL_c30  1
    pc162_L_conn_0_2_1  pc162_qL_c31  -1
    pc162_U_conn_0_2_1  pc162_sum_conn_0_2_1  -1
    pc162_U_conn_0_2_1  pc162_lbU_conn_0_2_1  1
    pc162_U_conn_0_2_1  pc162_ubU_conn_0_2_1  1
    pc162_U_conn_0_2_1  pc162_qU_c29  1
    pc162_U_conn_0_2_1  pc162_qU_c30  1
    pc162_U_conn_0_2_1  pc162_qU_c31  -1
    pc162_L_Y_1  pc162_sum_Y_1  -1
    pc162_L_Y_1  pc162_lbL_Y_1  1
    pc162_L_Y_1  pc162_ubL_Y_1  1
    pc162_L_Y_1  pc162_qL_c35  1
    pc162_L_Y_1  pc162_qL_c36  1
    pc162_L_Y_1  pc162_qL_c70  1
    pc162_L_Y_1  pc162_qL_c78  1
    pc162_L_Y_1  pc162_qL_c79  -1
    pc162_L_Y_1  pc162_qL_c94  1
    pc162_U_Y_1  pc162_sum_Y_1  -1
    pc162_U_Y_1  pc162_lbU_Y_1  1
    pc162_U_Y_1  pc162_ubU_Y_1  1
    pc162_U_Y_1  pc162_product_Y_1  -5.0000000000000011e-01
    pc162_U_Y_1  pc162_qU_c35  1
    pc162_U_Y_1  pc162_qU_c36  1
    pc162_U_Y_1  pc162_qU_c70  1
    pc162_U_Y_1  pc162_qU_c78  1
    pc162_U_Y_1  pc162_qU_c79  -1
    pc162_U_Y_1  pc162_qU_c94  1
    pc162_L_Y_2  pc162_sum_Y_2  -1
    pc162_L_Y_2  pc162_lbL_Y_2  1
    pc162_L_Y_2  pc162_ubL_Y_2  1
    pc162_L_Y_2  pc162_qL_c35  1
    pc162_L_Y_2  pc162_qL_c36  1
    pc162_L_Y_2  pc162_qL_c74  1
    pc162_L_Y_2  pc162_qL_c80  1
    pc162_L_Y_2  pc162_qL_c81  -1
    pc162_L_Y_2  pc162_qL_c106  1
    pc162_U_Y_2  pc162_sum_Y_2  -1
    pc162_U_Y_2  pc162_lbU_Y_2  1
    pc162_U_Y_2  pc162_ubU_Y_2  1
    pc162_U_Y_2  pc162_product_Y_2  -5.0000000000000011e-01
    pc162_U_Y_2  pc162_qU_c35  1
    pc162_U_Y_2  pc162_qU_c36  1
    pc162_U_Y_2  pc162_qU_c74  1
    pc162_U_Y_2  pc162_qU_c80  1
    pc162_U_Y_2  pc162_qU_c81  -1
    pc162_U_Y_2  pc162_qU_c106  1
    pc162_L_d_0_1  pc162_sum_d_0_1  -1
    pc162_L_d_0_1  pc162_lbL_d_0_1  1
    pc162_L_d_0_1  pc162_ubL_d_0_1  1
    pc162_L_d_0_1  pc162_qL_c37  1
    pc162_L_d_0_1  pc162_qL_c46  1
    pc162_L_d_0_1  pc162_qL_c49  1
    pc162_L_d_0_1  pc162_qL_c50  1
    pc162_L_d_0_1  pc162_qL_c59  1
    pc162_L_d_0_1  pc162_qL_c60  1
    pc162_L_d_0_1  pc162_qL_c65  1
    pc162_L_d_0_1  pc162_qL_c66  1
    pc162_L_d_0_1  pc162_qL_c67  -1
    pc162_L_d_0_1  pc162_qL_c70  -1
    pc162_L_d_0_1  pc162_qL_c91  1
    pc162_U_d_0_1  pc162_sum_d_0_1  -1
    pc162_U_d_0_1  pc162_lbU_d_0_1  1
    pc162_U_d_0_1  pc162_ubU_d_0_1  1
    pc162_U_d_0_1  pc162_qU_c37  1
    pc162_U_d_0_1  pc162_qU_c46  1
    pc162_U_d_0_1  pc162_qU_c49  1
    pc162_U_d_0_1  pc162_qU_c50  1
    pc162_U_d_0_1  pc162_qU_c59  1
    pc162_U_d_0_1  pc162_qU_c60  1
    pc162_U_d_0_1  pc162_qU_c65  1
    pc162_U_d_0_1  pc162_qU_c66  1
    pc162_U_d_0_1  pc162_qU_c67  -1
    pc162_U_d_0_1  pc162_qU_c70  -1
    pc162_U_d_0_1  pc162_qU_c91  1
    pc162_L_p_0_2  pc162_sum_p_0_2  -1
    pc162_L_p_0_2  pc162_lbL_p_0_2  1
    pc162_L_p_0_2  pc162_ubL_p_0_2  1
    pc162_L_p_0_2  pc162_qL_c37  -1
    pc162_L_p_0_2  pc162_qL_c52  1
    pc162_L_p_0_2  pc162_qL_c55  1
    pc162_L_p_0_2  pc162_qL_c57  1
    pc162_L_p_0_2  pc162_qL_c61  -1
    pc162_L_p_0_2  pc162_qL_c62  -1
    pc162_L_p_0_2  pc162_qL_c63  -1
    pc162_L_p_0_2  pc162_qL_c64  -1
    pc162_L_p_0_2  pc162_qL_c67  1
    pc162_L_p_0_2  pc162_qL_c68  5
    pc162_L_p_0_2  pc162_qL_c69  5
    pc162_L_p_0_2  pc162_qL_c74  1
    pc162_L_p_0_2  pc162_qL_c82  5
    pc162_L_p_0_2  pc162_qL_c103  1
    pc162_U_p_0_2  pc162_sum_p_0_2  -1
    pc162_U_p_0_2  pc162_lbU_p_0_2  1
    pc162_U_p_0_2  pc162_ubU_p_0_2  1
    pc162_U_p_0_2  pc162_qU_c37  -1
    pc162_U_p_0_2  pc162_qU_c52  1
    pc162_U_p_0_2  pc162_qU_c55  1
    pc162_U_p_0_2  pc162_qU_c57  1
    pc162_U_p_0_2  pc162_qU_c61  -1
    pc162_U_p_0_2  pc162_qU_c62  -1
    pc162_U_p_0_2  pc162_qU_c63  -1
    pc162_U_p_0_2  pc162_qU_c64  -1
    pc162_U_p_0_2  pc162_qU_c67  1
    pc162_U_p_0_2  pc162_qU_c68  5
    pc162_U_p_0_2  pc162_qU_c69  5
    pc162_U_p_0_2  pc162_qU_c74  1
    pc162_U_p_0_2  pc162_qU_c82  5
    pc162_U_p_0_2  pc162_qU_c103  1
    pc162_L_d_0_2  pc162_sum_d_0_2  -1
    pc162_L_d_0_2  pc162_lbL_d_0_2  1
    pc162_L_d_0_2  pc162_ubL_d_0_2  1
    pc162_L_d_0_2  pc162_qL_c38  1
    pc162_L_d_0_2  pc162_qL_c53  1
    pc162_L_d_0_2  pc162_qL_c56  1
    pc162_L_d_0_2  pc162_qL_c57  1
    pc162_L_d_0_2  pc162_qL_c61  1
    pc162_L_d_0_2  pc162_qL_c62  1
    pc162_L_d_0_2  pc162_qL_c63  1
    pc162_L_d_0_2  pc162_qL_c64  1
    pc162_L_d_0_2  pc162_qL_c67  -1
    pc162_L_d_0_2  pc162_qL_c74  -1
    pc162_L_d_0_2  pc162_qL_c103  1
    pc162_U_d_0_2  pc162_sum_d_0_2  -1
    pc162_U_d_0_2  pc162_lbU_d_0_2  1
    pc162_U_d_0_2  pc162_ubU_d_0_2  1
    pc162_U_d_0_2  pc162_qU_c38  1
    pc162_U_d_0_2  pc162_qU_c53  1
    pc162_U_d_0_2  pc162_qU_c56  1
    pc162_U_d_0_2  pc162_qU_c57  1
    pc162_U_d_0_2  pc162_qU_c61  1
    pc162_U_d_0_2  pc162_qU_c62  1
    pc162_U_d_0_2  pc162_qU_c63  1
    pc162_U_d_0_2  pc162_qU_c64  1
    pc162_U_d_0_2  pc162_qU_c67  -1
    pc162_U_d_0_2  pc162_qU_c74  -1
    pc162_U_d_0_2  pc162_qU_c103  1
    pc162_L_p_0_1  pc162_sum_p_0_1  -1
    pc162_L_p_0_1  pc162_lbL_p_0_1  1
    pc162_L_p_0_1  pc162_ubL_p_0_1  1
    pc162_L_p_0_1  pc162_qL_c38  -1
    pc162_L_p_0_1  pc162_qL_c45  1
    pc162_L_p_0_1  pc162_qL_c48  1
    pc162_L_p_0_1  pc162_qL_c50  1
    pc162_L_p_0_1  pc162_qL_c59  -1
    pc162_L_p_0_1  pc162_qL_c60  -1
    pc162_L_p_0_1  pc162_qL_c65  -1
    pc162_L_p_0_1  pc162_qL_c66  -1
    pc162_L_p_0_1  pc162_qL_c67  1
    pc162_L_p_0_1  pc162_qL_c68  5
    pc162_L_p_0_1  pc162_qL_c69  5
    pc162_L_p_0_1  pc162_qL_c70  1
    pc162_L_p_0_1  pc162_qL_c82  5
    pc162_L_p_0_1  pc162_qL_c91  1
    pc162_U_p_0_1  pc162_sum_p_0_1  -1
    pc162_U_p_0_1  pc162_lbU_p_0_1  1
    pc162_U_p_0_1  pc162_ubU_p_0_1  1
    pc162_U_p_0_1  pc162_qU_c38  -1
    pc162_U_p_0_1  pc162_qU_c45  1
    pc162_U_p_0_1  pc162_qU_c48  1
    pc162_U_p_0_1  pc162_qU_c50  1
    pc162_U_p_0_1  pc162_qU_c59  -1
    pc162_U_p_0_1  pc162_qU_c60  -1
    pc162_U_p_0_1  pc162_qU_c65  -1
    pc162_U_p_0_1  pc162_qU_c66  -1
    pc162_U_p_0_1  pc162_qU_c67  1
    pc162_U_p_0_1  pc162_qU_c68  5
    pc162_U_p_0_1  pc162_qU_c69  5
    pc162_U_p_0_1  pc162_qU_c70  1
    pc162_U_p_0_1  pc162_qU_c82  5
    pc162_U_p_0_1  pc162_qU_c91  1
    pc162_L_ord_0_1  pc162_sum_ord_0_1  -1
    pc162_L_ord_0_1  pc162_lbL_ord_0_1  1
    pc162_L_ord_0_1  pc162_ubL_ord_0_1  1
    pc162_L_ord_0_1  pc162_qL_c39  1
    pc162_L_ord_0_1  pc162_qL_c40  1
    pc162_L_ord_0_1  pc162_qL_c43  1
    pc162_L_ord_0_1  pc162_qL_c44  -1
    pc162_U_ord_0_1  pc162_sum_ord_0_1  -1
    pc162_U_ord_0_1  pc162_lbU_ord_0_1  1
    pc162_U_ord_0_1  pc162_ubU_ord_0_1  1
    pc162_U_ord_0_1  pc162_qU_c39  1
    pc162_U_ord_0_1  pc162_qU_c40  1
    pc162_U_ord_0_1  pc162_qU_c43  1
    pc162_U_ord_0_1  pc162_qU_c44  -1
    pc162_L_ord_0_2  pc162_sum_ord_0_2  -1
    pc162_L_ord_0_2  pc162_lbL_ord_0_2  1
    pc162_L_ord_0_2  pc162_ubL_ord_0_2  1
    pc162_L_ord_0_2  pc162_qL_c41  1
    pc162_L_ord_0_2  pc162_qL_c42  1
    pc162_L_ord_0_2  pc162_qL_c43  -1
    pc162_L_ord_0_2  pc162_qL_c44  1
    pc162_U_ord_0_2  pc162_sum_ord_0_2  -1
    pc162_U_ord_0_2  pc162_lbU_ord_0_2  1
    pc162_U_ord_0_2  pc162_ubU_ord_0_2  1
    pc162_U_ord_0_2  pc162_qU_c41  1
    pc162_U_ord_0_2  pc162_qU_c42  1
    pc162_U_ord_0_2  pc162_qU_c43  -1
    pc162_U_ord_0_2  pc162_qU_c44  1
    pc162_L_mode_0_1  pc162_sum_mode_0_1  -1
    pc162_L_mode_0_1  pc162_lbL_mode_0_1  1
    pc162_L_mode_0_1  pc162_ubL_mode_0_1  1
    pc162_L_mode_0_1  pc162_qL_c47  1
    pc162_L_mode_0_1  pc162_qL_c48  -2
    pc162_U_mode_0_1  pc162_sum_mode_0_1  -1
    pc162_U_mode_0_1  pc162_lbU_mode_0_1  1
    pc162_U_mode_0_1  pc162_ubU_mode_0_1  1
    pc162_U_mode_0_1  pc162_qU_c47  1
    pc162_U_mode_0_1  pc162_qU_c48  -2
    pc162_L_load_0_1  pc162_sum_load_0_1  -1
    pc162_L_load_0_1  pc162_lbL_load_0_1  1
    pc162_L_load_0_1  pc162_ubL_load_0_1  1
    pc162_L_load_0_1  pc162_qL_c51  1
    pc162_L_load_0_1  pc162_qL_c59  1
    pc162_L_load_0_1  pc162_qL_c60  1
    pc162_L_load_0_1  pc162_qL_c63  -1
    pc162_L_load_0_1  pc162_qL_c64  -1
    pc162_L_load_0_1  pc162_qL_c65  1
    pc162_L_load_0_1  pc162_qL_c66  1
    pc162_U_load_0_1  pc162_sum_load_0_1  -1
    pc162_U_load_0_1  pc162_lbU_load_0_1  1
    pc162_U_load_0_1  pc162_ubU_load_0_1  1
    pc162_U_load_0_1  pc162_qU_c51  1
    pc162_U_load_0_1  pc162_qU_c59  1
    pc162_U_load_0_1  pc162_qU_c60  1
    pc162_U_load_0_1  pc162_qU_c63  -1
    pc162_U_load_0_1  pc162_qU_c64  -1
    pc162_U_load_0_1  pc162_qU_c65  1
    pc162_U_load_0_1  pc162_qU_c66  1
    pc162_L_mode_0_2  pc162_sum_mode_0_2  -1
    pc162_L_mode_0_2  pc162_lbL_mode_0_2  1
    pc162_L_mode_0_2  pc162_ubL_mode_0_2  1
    pc162_L_mode_0_2  pc162_qL_c54  1
    pc162_L_mode_0_2  pc162_qL_c56  2
    pc162_U_mode_0_2  pc162_sum_mode_0_2  -1
    pc162_U_mode_0_2  pc162_lbU_mode_0_2  1
    pc162_U_mode_0_2  pc162_ubU_mode_0_2  1
    pc162_U_mode_0_2  pc162_qU_c54  1
    pc162_U_mode_0_2  pc162_qU_c56  2
    pc162_L_load_0_2  pc162_sum_load_0_2  -1
    pc162_L_load_0_2  pc162_lbL_load_0_2  1
    pc162_L_load_0_2  pc162_ubL_load_0_2  1
    pc162_L_load_0_2  pc162_qL_c58  1
    pc162_L_load_0_2  pc162_qL_c61  1
    pc162_L_load_0_2  pc162_qL_c62  1
    pc162_L_load_0_2  pc162_qL_c63  1
    pc162_L_load_0_2  pc162_qL_c64  1
    pc162_L_load_0_2  pc162_qL_c65  -1
    pc162_L_load_0_2  pc162_qL_c66  -1
    pc162_U_load_0_2  pc162_sum_load_0_2  -1
    pc162_U_load_0_2  pc162_lbU_load_0_2  1
    pc162_U_load_0_2  pc162_ubU_load_0_2  1
    pc162_U_load_0_2  pc162_qU_c58  1
    pc162_U_load_0_2  pc162_qU_c61  1
    pc162_U_load_0_2  pc162_qU_c62  1
    pc162_U_load_0_2  pc162_qU_c63  1
    pc162_U_load_0_2  pc162_qU_c64  1
    pc162_U_load_0_2  pc162_qU_c65  -1
    pc162_U_load_0_2  pc162_qU_c66  -1
    pc162_L_state_1_0  pc162_sum_state_1_0  -1
    pc162_L_state_1_0  pc162_lbL_state_1_0  1
    pc162_L_state_1_0  pc162_ubL_state_1_0  1
    pc162_L_state_1_0  pc162_qL_c91  -2
    pc162_L_state_1_0  pc162_qL_c93  1
    pc162_U_state_1_0  pc162_sum_state_1_0  -1
    pc162_U_state_1_0  pc162_lbU_state_1_0  1
    pc162_U_state_1_0  pc162_ubU_state_1_0  1
    pc162_U_state_1_0  pc162_product_state_1_0  -5.0000000000000011e-01
    pc162_U_state_1_0  pc162_qU_c91  -2
    pc162_U_state_1_0  pc162_qU_c93  1
    pc162_L_state_1_1  pc162_sum_state_1_1  -1
    pc162_L_state_1_1  pc162_lbL_state_1_1  1
    pc162_L_state_1_1  pc162_ubL_state_1_1  1
    pc162_L_state_1_1  pc162_qL_c91  -1
    pc162_L_state_1_1  pc162_qL_c93  1
    pc162_L_state_1_1  pc162_qL_c94  -1
    pc162_U_state_1_1  pc162_sum_state_1_1  -1
    pc162_U_state_1_1  pc162_lbU_state_1_1  1
    pc162_U_state_1_1  pc162_ubU_state_1_1  1
    pc162_U_state_1_1  pc162_product_state_1_1  -5.0000000000000011e-01
    pc162_U_state_1_1  pc162_qU_c91  -1
    pc162_U_state_1_1  pc162_qU_c93  1
    pc162_U_state_1_1  pc162_qU_c94  -1
    pc162_L_state_1_2  pc162_sum_state_1_2  -1
    pc162_L_state_1_2  pc162_lbL_state_1_2  1
    pc162_L_state_1_2  pc162_ubL_state_1_2  1
    pc162_L_state_1_2  pc162_qL_c92  1
    pc162_L_state_1_2  pc162_qL_c93  1
    pc162_L_state_1_2  pc162_qL_c94  -2
    pc162_U_state_1_2  pc162_sum_state_1_2  -1
    pc162_U_state_1_2  pc162_lbU_state_1_2  1
    pc162_U_state_1_2  pc162_ubU_state_1_2  1
    pc162_U_state_1_2  pc162_product_state_1_2  -5.0000000000000011e-01
    pc162_U_state_1_2  pc162_qU_c92  1
    pc162_U_state_1_2  pc162_qU_c93  1
    pc162_U_state_1_2  pc162_qU_c94  -2
    pc162_L_state_2_0  pc162_sum_state_2_0  -1
    pc162_L_state_2_0  pc162_lbL_state_2_0  1
    pc162_L_state_2_0  pc162_ubL_state_2_0  1
    pc162_L_state_2_0  pc162_qL_c104  1
    pc162_L_state_2_0  pc162_qL_c105  1
    pc162_U_state_2_0  pc162_sum_state_2_0  -1
    pc162_U_state_2_0  pc162_lbU_state_2_0  1
    pc162_U_state_2_0  pc162_ubU_state_2_0  1
    pc162_U_state_2_0  pc162_product_state_2_0  -5.0000000000000011e-01
    pc162_U_state_2_0  pc162_qU_c104  1
    pc162_U_state_2_0  pc162_qU_c105  1
    pc162_L_state_2_1  pc162_sum_state_2_1  -1
    pc162_L_state_2_1  pc162_lbL_state_2_1  1
    pc162_L_state_2_1  pc162_ubL_state_2_1  1
    pc162_L_state_2_1  pc162_qL_c103  -1
    pc162_L_state_2_1  pc162_qL_c105  1
    pc162_L_state_2_1  pc162_qL_c106  -1
    pc162_U_state_2_1  pc162_sum_state_2_1  -1
    pc162_U_state_2_1  pc162_lbU_state_2_1  1
    pc162_U_state_2_1  pc162_ubU_state_2_1  1
    pc162_U_state_2_1  pc162_product_state_2_1  -5.0000000000000011e-01
    pc162_U_state_2_1  pc162_qU_c103  -1
    pc162_U_state_2_1  pc162_qU_c105  1
    pc162_U_state_2_1  pc162_qU_c106  -1
    pc162_L_state_2_2  pc162_sum_state_2_2  -1
    pc162_L_state_2_2  pc162_lbL_state_2_2  1
    pc162_L_state_2_2  pc162_ubL_state_2_2  1
    pc162_L_state_2_2  pc162_qL_c103  -2
    pc162_L_state_2_2  pc162_qL_c105  1
    pc162_L_state_2_2  pc162_qL_c106  -2
    pc162_U_state_2_2  pc162_sum_state_2_2  -1
    pc162_U_state_2_2  pc162_lbU_state_2_2  1
    pc162_U_state_2_2  pc162_ubU_state_2_2  1
    pc162_U_state_2_2  pc162_product_state_2_2  -5.0000000000000011e-01
    pc162_U_state_2_2  pc162_qU_c103  -2
    pc162_U_state_2_2  pc162_qU_c105  1
    pc162_U_state_2_2  pc162_qU_c106  -2
RHS
    RHS1      c4        3.0000000000000009e+00
    RHS1      c5        3.0000000000000009e+00
    RHS1      c8        6.0000000000000009e-01
    RHS1      c9        3.6000000000000005e+00
    RHS1      c11       6.0000000000000009e+00
    RHS1      c12       6.0000000000000009e+00
    RHS1      c14       -6
    RHS1      c19       1
    RHS1      c33       1
    RHS1      c34       1
    RHS1      c35       2
    RHS1      c43       1
    RHS1      c44       1
    RHS1      c59       2
    RHS1      c60       -2
    RHS1      c61       2
    RHS1      c62       -2
    RHS1      c63       2
    RHS1      c64       -2
    RHS1      c65       2
    RHS1      c66       -2
    RHS1      c68       100
    RHS1      c69       320
    RHS1      c70       2
    RHS1      c72       -1
    RHS1      c73       1
    RHS1      c76       -1
    RHS1      c77       1
    RHS1      c78       2
    RHS1      c79       -2
    RHS1      c82       100
    RHS1      c92       1
    RHS1      c93       1
    RHS1      c104      1
    RHS1      c105      1
    RHS1      c110      -1.0000000000000004e+00
    RHS1      pc162_lambda_sum  1
BOUNDS
 UP BND1      G         5.0000000000000011e-01
 UP BND1      e_1       1
 UP BND1      e_2       1
 UP BND1      h_1_2     3
 UP BND1      r_1       2
 UP BND1      r_2       1
 UP BND1      W_SP      6
 BV BND1      x_0_0_1 
 BV BND1      x_0_0_2 
 BV BND1      x_0_1_0 
 BV BND1      x_0_2_0 
 BV BND1      x_0_2_1 
 BV BND1      z_0_1   
 BV BND1      x_0_1_2 
 BV BND1      z_0_2   
 UP BND1      conn_0_0_1  2
 UP BND1      conn_0_0_2  2
 UP BND1      conn_0_1_0  2
 UP BND1      conn_0_1_2  2
 UP BND1      conn_0_2_0  2
 UP BND1      conn_0_2_1  2
 UP BND1      Y_1       2
 UP BND1      Y_2       2
 FX BND1      d_0_1     0
 FX BND1      p_0_2     0
 UP BND1      d_0_2     2
 UP BND1      p_0_1     2
 UP BND1      ord_0_1   2
 UP BND1      ord_0_2   2
 BV BND1      mode_0_1
 UP BND1      load_0_1  2
 BV BND1      mode_0_2
 UP BND1      load_0_2  2
 UP BND1      state_g_1_0  5.0000000000000011e-01
 BV BND1      state_1_0
 UP BND1      state_g_1_1  5.0000000000000011e-01
 BV BND1      state_1_1
 UP BND1      state_g_1_2  5.0000000000000011e-01
 BV BND1      state_1_2
 UP BND1      zprod_1   2
 UP BND1      state_g_2_0  5.0000000000000011e-01
 BV BND1      state_2_0
 UP BND1      state_g_2_1  5.0000000000000011e-01
 BV BND1      state_2_1
 UP BND1      state_g_2_2  5.0000000000000011e-01
 BV BND1      state_2_2
 UP BND1      zprod_2   2
 UP BND1      r_max     2
 UP BND1      r_min     2
 UP BND1      pc162_lambda_L  1
 UP BND1      pc162_lambda_U  1
 UP BND1      pc162_L_x_0_0_1  1
 UP BND1      pc162_U_x_0_0_1  1
 UP BND1      pc162_L_x_0_0_2  1
 UP BND1      pc162_U_x_0_0_2  1
 UP BND1      pc162_L_x_0_1_0  1
 UP BND1      pc162_U_x_0_1_0  1
 UP BND1      pc162_L_x_0_2_0  1
 UP BND1      pc162_U_x_0_2_0  1
 UP BND1      pc162_L_x_0_2_1  1
 UP BND1      pc162_U_x_0_2_1  1
 UP BND1      pc162_L_z_0_1  1
 UP BND1      pc162_U_z_0_1  1
 UP BND1      pc162_L_x_0_1_2  1
 UP BND1      pc162_U_x_0_1_2  1
 UP BND1      pc162_L_z_0_2  1
 UP BND1      pc162_U_z_0_2  1
 UP BND1      pc162_L_conn_0_0_1  2
 UP BND1      pc162_U_conn_0_0_1  2
 UP BND1      pc162_L_conn_0_0_2  2
 UP BND1      pc162_U_conn_0_0_2  2
 UP BND1      pc162_L_conn_0_1_0  2
 UP BND1      pc162_U_conn_0_1_0  2
 UP BND1      pc162_L_conn_0_1_2  2
 UP BND1      pc162_U_conn_0_1_2  2
 UP BND1      pc162_L_conn_0_2_0  2
 UP BND1      pc162_U_conn_0_2_0  2
 UP BND1      pc162_L_conn_0_2_1  2
 UP BND1      pc162_U_conn_0_2_1  2
 UP BND1      pc162_L_Y_1  2
 UP BND1      pc162_U_Y_1  2
 UP BND1      pc162_L_Y_2  2
 UP BND1      pc162_U_Y_2  2
 FX BND1      pc162_L_d_0_1  0
 FX BND1      pc162_U_d_0_1  0
 FX BND1      pc162_L_p_0_2  0
 FX BND1      pc162_U_p_0_2  0
 UP BND1      pc162_L_d_0_2  2
 UP BND1      pc162_U_d_0_2  2
 UP BND1      pc162_L_p_0_1  2
 UP BND1      pc162_U_p_0_1  2
 UP BND1      pc162_L_ord_0_1  2
 UP BND1      pc162_U_ord_0_1  2
 UP BND1      pc162_L_ord_0_2  2
 UP BND1      pc162_U_ord_0_2  2
 UP BND1      pc162_L_mode_0_1  1
 UP BND1      pc162_U_mode_0_1  1
 UP BND1      pc162_L_load_0_1  2
 UP BND1      pc162_U_load_0_1  2
 UP BND1      pc162_L_mode_0_2  1
 UP BND1      pc162_U_mode_0_2  1
 UP BND1      pc162_L_load_0_2  2
 UP BND1      pc162_U_load_0_2  2
 UP BND1      pc162_L_state_1_0  1
 UP BND1      pc162_U_state_1_0  1
 UP BND1      pc162_L_state_1_1  1
 UP BND1      pc162_U_state_1_1  1
 UP BND1      pc162_L_state_1_2  1
 UP BND1      pc162_U_state_1_2  1
 UP BND1      pc162_L_state_2_0  1
 UP BND1      pc162_U_state_2_0  1
 UP BND1      pc162_L_state_2_1  1
 UP BND1      pc162_U_state_2_1  1
 UP BND1      pc162_L_state_2_2  1
 UP BND1      pc162_U_state_2_2  1
ENDATA
