* Signature: 0x7aeb0ae71708d57a
NAME 
ROWS
 N  OBJ
 E  onehot_1
 E  inventory_1
 E  ratio_1 
 E  onehot_2
 E  inventory_2
 E  ratio_2 
 E  onehot_3
 E  inventory_3
 E  ratio_3 
 E  onehot_4
 E  inventory_4
 E  ratio_4 
 G  R12     
 G  R13     
 G  R14     
 G  R15     
 G  R16     
 G  R17     
 G  R18     
 G  R19     
 G  R20     
 G  R21     
 G  R22     
 G  R23     
 G  hard_lower
 L  hard_upper
 G  bin_lower
 L  bin_upper
 L  surrogate_G
 L  physical_G_upper
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    x[1,0]    OBJ       5.2499999999999991e-01
    x[1,0]    onehot_1  1
    x[1,1]    OBJ       -0.625
    x[1,1]    onehot_1  1
    x[1,1]    inventory_1  -1
    x[1,2]    OBJ       5.2499999999999991e-01
    x[1,2]    onehot_1  1
    x[1,2]    inventory_1  -2
    x[2,0]    OBJ       -4.7500000000000003e-01
    x[2,0]    onehot_2  1
    x[2,1]    OBJ       0.375
    x[2,1]    onehot_2  1
    x[2,1]    inventory_2  -1
    x[2,2]    OBJ       -4.7500000000000003e-01
    x[2,2]    onehot_2  1
    x[2,2]    inventory_2  -2
    x[3,0]    OBJ       5.2499999999999991e-01
    x[3,0]    onehot_3  1
    x[3,1]    OBJ       -0.625
    x[3,1]    onehot_3  1
    x[3,1]    inventory_3  -1
    x[3,2]    OBJ       5.2499999999999991e-01
    x[3,2]    onehot_3  1
    x[3,2]    inventory_3  -2
    x[4,0]    OBJ       -4.7500000000000003e-01
    x[4,0]    onehot_4  1
    x[4,1]    OBJ       0.375
    x[4,1]    onehot_4  1
    x[4,1]    inventory_4  -1
    x[4,2]    OBJ       -4.7500000000000003e-01
    x[4,2]    onehot_4  1
    x[4,2]    inventory_4  -2
    MARKER    'MARKER'                 'INTEND'
    Y[1]      inventory_1  1
    Y[1]      ratio_1   -1
    Y[1]      hard_lower  1
    Y[1]      hard_upper  1
    Y[2]      inventory_2  1
    Y[2]      ratio_2   -1
    Y[2]      hard_lower  1
    Y[2]      hard_upper  1
    Y[3]      inventory_3  1
    Y[3]      ratio_3   -1
    Y[3]      hard_lower  1
    Y[3]      hard_upper  1
    Y[4]      inventory_4  1
    Y[4]      ratio_4   -1
    Y[4]      hard_lower  1
    Y[4]      hard_upper  1
    r[1]      ratio_1   1
    r[1]      R12       -1
    r[1]      R13       1
    r[1]      R14       -1
    r[1]      R15       1
    r[1]      R16       -1
    r[1]      R17       1
    r[1]      bin_lower  1
    r[1]      bin_upper  1
    r[1]      physical_G_upper  -3
    r[2]      ratio_2   1
    r[2]      R12       1
    r[2]      R13       -1
    r[2]      R18       -1
    r[2]      R19       1
    r[2]      R20       -1
    r[2]      R21       1
    r[2]      bin_lower  1
    r[2]      bin_upper  1
    r[2]      physical_G_upper  -3
    r[3]      ratio_3   1
    r[3]      R14       1
    r[3]      R15       -1
    r[3]      R18       1
    r[3]      R19       -1
    r[3]      R22       -1
    r[3]      R23       1
    r[3]      bin_lower  1
    r[3]      bin_upper  1
    r[3]      physical_G_upper  -3
    r[4]      ratio_4   1
    r[4]      R16       1
    r[4]      R17       -1
    r[4]      R20       1
    r[4]      R21       -1
    r[4]      R22       1
    r[4]      R23       -1
    r[4]      bin_lower  1
    r[4]      bin_upper  1
    r[4]      physical_G_upper  -3
    a[1,2]    R12       1
    a[1,2]    R13       1
    a[1,2]    surrogate_G  1
    a[1,2]    physical_G_upper  1
    a[1,3]    R14       1
    a[1,3]    R15       1
    a[1,3]    surrogate_G  1
    a[1,3]    physical_G_upper  1
    a[1,4]    R16       1
    a[1,4]    R17       1
    a[1,4]    surrogate_G  1
    a[1,4]    physical_G_upper  1
    a[2,3]    R18       1
    a[2,3]    R19       1
    a[2,3]    surrogate_G  1
    a[2,3]    physical_G_upper  1
    a[2,4]    R20       1
    a[2,4]    R21       1
    a[2,4]    surrogate_G  1
    a[2,4]    physical_G_upper  1
    a[3,4]    R22       1
    a[3,4]    R23       1
    a[3,4]    surrogate_G  1
    a[3,4]    physical_G_upper  1
    q         OBJ       1
    q         surrogate_G  -1.1661807580174928e+01
RHS
    RHS1      onehot_1  1
    RHS1      onehot_2  1
    RHS1      onehot_3  1
    RHS1      onehot_4  1
    RHS1      hard_upper  3
    RHS1      bin_lower  2.0408163265306123e+00
    RHS1      bin_upper  2.9154518950437320e+00
BOUNDS
 BV BND1      x[1,0]  
 BV BND1      x[1,1]  
 BV BND1      x[1,2]  
 BV BND1      x[2,0]  
 BV BND1      x[2,1]  
 BV BND1      x[2,2]  
 BV BND1      x[3,0]  
 BV BND1      x[3,1]  
 BV BND1      x[3,2]  
 BV BND1      x[4,0]  
 BV BND1      x[4,1]  
 BV BND1      x[4,2]  
ENDATA
