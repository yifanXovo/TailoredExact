* Signature: 0x2a4a51c80e0e452c
NAME R160_physical_neighborhood
ROWS
 N  OBJ
 G  product_lb_0
 L  product_ub_1
 G  product_lb_2
 L  product_ub_3
 G  product_lb_4
 L  product_ub_5
 G  product_lb_6
 L  product_ub_7
 G  product_lb_8
 L  product_ub_9
 G  product_lb_10
 L  product_ub_11
 G  product_lb_12
 L  product_ub_13
 G  product_lb_14
 L  product_ub_15
 G  product_lb_16
 L  product_ub_17
 G  product_lb_18
 L  product_ub_19
 G  product_lb_20
 L  product_ub_21
 E  onehot_20_22
 E  normalized_mass_20_23
 E  normalized_ratio_20_24
 G  product_lb_25
 L  product_ub_26
 G  product_lb_27
 L  product_ub_28
 G  product_lb_29
 L  product_ub_30
 G  product_lb_31
 L  product_ub_32
 G  product_lb_33
 L  product_ub_34
 G  product_lb_35
 L  product_ub_36
 G  product_lb_37
 L  product_ub_38
 E  onehot_21_39
 E  normalized_mass_21_40
 E  normalized_ratio_21_41
 G  product_lb_42
 L  product_ub_43
 G  product_lb_44
 L  product_ub_45
 G  product_lb_46
 L  product_ub_47
 G  product_lb_48
 L  product_ub_49
 G  product_lb_50
 L  product_ub_51
 G  product_lb_52
 L  product_ub_53
 G  product_lb_54
 L  product_ub_55
 G  product_lb_56
 L  product_ub_57
 G  product_lb_58
 L  product_ub_59
 G  product_lb_60
 L  product_ub_61
 G  product_lb_62
 L  product_ub_63
 G  product_lb_64
 L  product_ub_65
 G  product_lb_66
 L  product_ub_67
 G  product_lb_68
 L  product_ub_69
 G  product_lb_70
 L  product_ub_71
 G  product_lb_72
 L  product_ub_73
 E  onehot_34_74
 E  normalized_mass_34_75
 E  normalized_ratio_34_76
 G  product_lb_77
 L  product_ub_78
 G  product_lb_79
 L  product_ub_80
 G  product_lb_81
 L  product_ub_82
 G  product_lb_83
 L  product_ub_84
 G  product_lb_85
 L  product_ub_86
 G  product_lb_87
 L  product_ub_88
 G  product_lb_89
 L  product_ub_90
 G  product_lb_91
 L  product_ub_92
 G  product_lb_93
 L  product_ub_94
 G  product_lb_95
 L  product_ub_96
 G  product_lb_97
 L  product_ub_98
 E  onehot_19_99
 E  normalized_mass_19_100
 E  normalized_ratio_19_101
 G  product_lb_102
 L  product_ub_103
 G  product_lb_104
 L  product_ub_105
 G  product_lb_106
 L  product_ub_107
 G  product_lb_108
 L  product_ub_109
 G  product_lb_110
 L  product_ub_111
 G  product_lb_112
 L  product_ub_113
 G  product_lb_114
 L  product_ub_115
 G  product_lb_116
 L  product_ub_117
 G  product_lb_118
 L  product_ub_119
 G  product_lb_120
 L  product_ub_121
 G  product_lb_122
 L  product_ub_123
 E  onehot_29_124
 E  normalized_mass_29_125
 E  normalized_ratio_29_126
 G  product_lb_127
 L  product_ub_128
 G  product_lb_129
 L  product_ub_130
 G  product_lb_131
 L  product_ub_132
 G  product_lb_133
 L  product_ub_134
 G  product_lb_135
 L  product_ub_136
 G  product_lb_137
 L  product_ub_138
 G  product_lb_139
 L  product_ub_140
 G  product_lb_141
 L  product_ub_142
 G  product_lb_143
 L  product_ub_144
 G  product_lb_145
 L  product_ub_146
 G  product_lb_147
 L  product_ub_148
 E  onehot_18_149
 E  normalized_mass_18_150
 E  normalized_ratio_18_151
 G  product_lb_152
 L  product_ub_153
 G  product_lb_154
 L  product_ub_155
 G  product_lb_156
 L  product_ub_157
 G  product_lb_158
 L  product_ub_159
 G  product_lb_160
 L  product_ub_161
 G  product_lb_162
 L  product_ub_163
 G  product_lb_164
 L  product_ub_165
 E  onehot_27_166
 E  normalized_mass_27_167
 E  normalized_ratio_27_168
 G  product_lb_169
 L  product_ub_170
 G  product_lb_171
 L  product_ub_172
 G  product_lb_173
 L  product_ub_174
 G  product_lb_175
 L  product_ub_176
 G  product_lb_177
 L  product_ub_178
 G  product_lb_179
 L  product_ub_180
 G  product_lb_181
 L  product_ub_182
 E  onehot_17_183
 E  normalized_mass_17_184
 E  normalized_ratio_17_185
 G  stock_lb_186
 L  stock_ub_187
 L  parent_nonstrict_scope_188
 G  block_pair_pos_189
 G  block_pair_neg_190
 G  block_pair_pos_191
 G  block_pair_neg_192
 G  block_pair_pos_193
 G  block_pair_neg_194
 G  block_pair_pos_195
 G  block_pair_neg_196
 G  block_pair_pos_197
 G  block_pair_neg_198
 G  block_pair_pos_199
 G  block_pair_neg_200
 G  block_pair_pos_201
 G  block_pair_neg_202
 G  block_pair_pos_203
 G  block_pair_neg_204
 G  block_pair_pos_205
 G  block_pair_neg_206
 G  block_pair_pos_207
 G  block_pair_neg_208
 G  block_pair_pos_209
 G  block_pair_neg_210
 G  block_pair_pos_211
 G  block_pair_neg_212
 G  block_pair_pos_213
 G  block_pair_neg_214
 G  block_pair_pos_215
 G  block_pair_neg_216
 G  block_pair_pos_217
 G  block_pair_neg_218
 G  block_pair_pos_219
 G  block_pair_neg_220
 G  block_pair_pos_221
 G  block_pair_neg_222
 G  block_pair_pos_223
 G  block_pair_neg_224
 G  block_pair_pos_225
 G  block_pair_neg_226
 G  block_pair_pos_227
 G  block_pair_neg_228
 G  block_pair_pos_229
 G  block_pair_neg_230
 G  block_pair_pos_231
 G  block_pair_neg_232
 G  block_pair_pos_233
 G  block_pair_neg_234
 G  block_pair_pos_235
 G  block_pair_neg_236
 G  block_pair_pos_237
 G  block_pair_neg_238
 G  block_pair_pos_239
 G  block_pair_neg_240
 G  block_pair_pos_241
 G  block_pair_neg_242
 G  block_pair_pos_243
 G  block_pair_neg_244
 E  normalization_245
 G  full_original_Gini_246
 E  unique_nonzero_owner_247
 E  unique_nonzero_owner_248
 E  unique_nonzero_owner_249
 E  unique_nonzero_owner_250
 E  unique_nonzero_owner_251
 E  unique_nonzero_owner_252
 E  unique_nonzero_owner_253
 E  unique_nonzero_owner_254
 E  unique_nonzero_owner_255
 E  unique_nonzero_owner_256
 E  unique_nonzero_owner_257
 E  unique_nonzero_owner_258
 E  unique_nonzero_owner_259
 E  unique_nonzero_owner_260
 E  unique_nonzero_owner_261
 E  unique_nonzero_owner_262
 E  unique_nonzero_owner_263
 E  unique_nonzero_owner_264
 E  unique_nonzero_owner_265
 E  unique_nonzero_owner_266
 E  unique_nonzero_owner_267
 E  unique_nonzero_owner_268
 E  unique_nonzero_owner_269
 E  unique_nonzero_owner_270
 E  unique_nonzero_owner_271
 E  unique_nonzero_owner_272
 E  unique_nonzero_owner_273
 E  unique_nonzero_owner_274
 E  unique_nonzero_owner_275
 E  unique_nonzero_owner_276
 E  unique_nonzero_owner_277
 E  unique_nonzero_owner_278
 E  unique_nonzero_owner_279
 E  unique_nonzero_owner_280
 E  unique_nonzero_owner_281
 E  unique_nonzero_owner_282
 E  unique_nonzero_owner_283
 E  unique_nonzero_owner_284
 E  unique_nonzero_owner_285
 E  unique_nonzero_owner_286
 E  unique_nonzero_owner_287
 E  unique_nonzero_owner_288
 E  unique_nonzero_owner_289
 E  unique_nonzero_owner_290
 E  unique_nonzero_owner_291
 E  unique_nonzero_owner_292
 E  unique_nonzero_owner_293
 E  unique_nonzero_owner_294
 E  unique_nonzero_owner_295
 E  unique_nonzero_owner_296
 E  unique_nonzero_owner_297
 E  unique_nonzero_owner_298
 E  unique_nonzero_owner_299
 E  unique_nonzero_owner_300
 E  unique_nonzero_owner_301
 E  unique_nonzero_owner_302
 E  unique_nonzero_owner_303
 E  unique_nonzero_owner_304
 E  unique_nonzero_owner_305
 E  unique_nonzero_owner_306
 E  unique_nonzero_owner_307
 E  unique_nonzero_owner_308
 E  unique_nonzero_owner_309
 E  unique_nonzero_owner_310
 E  unique_nonzero_owner_311
 E  unique_nonzero_owner_312
 E  unique_nonzero_owner_313
 E  unique_nonzero_owner_314
 E  unique_nonzero_owner_315
 E  unique_nonzero_owner_316
 E  unique_nonzero_owner_317
 E  unique_nonzero_owner_318
 E  unique_nonzero_owner_319
 L  arc_capacity_320
 L  arc_capacity_321
 L  arc_capacity_322
 L  arc_capacity_323
 L  arc_capacity_324
 L  arc_capacity_325
 L  arc_capacity_326
 L  arc_capacity_327
 L  arc_capacity_328
 L  arc_capacity_329
 L  arc_capacity_330
 L  arc_capacity_331
 L  arc_capacity_332
 L  arc_capacity_333
 L  arc_capacity_334
 G  connected_order_arc_335
 L  arc_capacity_336
 G  connected_order_arc_337
 L  arc_capacity_338
 G  connected_order_arc_339
 L  arc_capacity_340
 G  connected_order_arc_341
 L  arc_capacity_342
 G  connected_order_arc_343
 L  arc_capacity_344
 G  connected_order_arc_345
 L  arc_capacity_346
 G  connected_order_arc_347
 L  arc_capacity_348
 G  connected_order_arc_349
 L  arc_capacity_350
 G  connected_order_arc_351
 L  arc_capacity_352
 G  connected_order_arc_353
 L  arc_capacity_354
 G  connected_order_arc_355
 L  arc_capacity_356
 L  arc_capacity_357
 G  connected_order_arc_358
 L  arc_capacity_359
 G  connected_order_arc_360
 L  arc_capacity_361
 G  connected_order_arc_362
 L  arc_capacity_363
 G  connected_order_arc_364
 L  arc_capacity_365
 G  connected_order_arc_366
 L  arc_capacity_367
 G  connected_order_arc_368
 L  arc_capacity_369
 G  connected_order_arc_370
 L  arc_capacity_371
 G  connected_order_arc_372
 L  arc_capacity_373
 G  connected_order_arc_374
 L  arc_capacity_375
 G  connected_order_arc_376
 L  arc_capacity_377
 G  connected_order_arc_378
 L  arc_capacity_379
 L  arc_capacity_380
 G  connected_order_arc_381
 L  arc_capacity_382
 G  connected_order_arc_383
 L  arc_capacity_384
 G  connected_order_arc_385
 L  arc_capacity_386
 G  connected_order_arc_387
 L  arc_capacity_388
 G  connected_order_arc_389
 L  arc_capacity_390
 G  connected_order_arc_391
 L  arc_capacity_392
 G  connected_order_arc_393
 L  arc_capacity_394
 G  connected_order_arc_395
 L  arc_capacity_396
 G  connected_order_arc_397
 L  arc_capacity_398
 G  connected_order_arc_399
 L  arc_capacity_400
 G  connected_order_arc_401
 L  arc_capacity_402
 L  arc_capacity_403
 G  connected_order_arc_404
 L  arc_capacity_405
 G  connected_order_arc_406
 L  arc_capacity_407
 G  connected_order_arc_408
 L  arc_capacity_409
 G  connected_order_arc_410
 L  arc_capacity_411
 G  connected_order_arc_412
 L  arc_capacity_413
 G  connected_order_arc_414
 L  arc_capacity_415
 G  connected_order_arc_416
 L  arc_capacity_417
 G  connected_order_arc_418
 L  arc_capacity_419
 G  connected_order_arc_420
 L  arc_capacity_421
 G  connected_order_arc_422
 L  arc_capacity_423
 G  connected_order_arc_424
 L  arc_capacity_425
 L  arc_capacity_426
 G  connected_order_arc_427
 L  arc_capacity_428
 G  connected_order_arc_429
 L  arc_capacity_430
 G  connected_order_arc_431
 L  arc_capacity_432
 G  connected_order_arc_433
 L  arc_capacity_434
 G  connected_order_arc_435
 L  arc_capacity_436
 G  connected_order_arc_437
 L  arc_capacity_438
 G  connected_order_arc_439
 L  arc_capacity_440
 G  connected_order_arc_441
 L  arc_capacity_442
 G  connected_order_arc_443
 L  arc_capacity_444
 G  connected_order_arc_445
 L  arc_capacity_446
 G  connected_order_arc_447
 L  arc_capacity_448
 L  arc_capacity_449
 G  connected_order_arc_450
 L  arc_capacity_451
 G  connected_order_arc_452
 L  arc_capacity_453
 G  connected_order_arc_454
 L  arc_capacity_455
 G  connected_order_arc_456
 L  arc_capacity_457
 G  connected_order_arc_458
 L  arc_capacity_459
 G  connected_order_arc_460
 L  arc_capacity_461
 G  connected_order_arc_462
 L  arc_capacity_463
 G  connected_order_arc_464
 L  arc_capacity_465
 G  connected_order_arc_466
 L  arc_capacity_467
 G  connected_order_arc_468
 L  arc_capacity_469
 G  connected_order_arc_470
 L  arc_capacity_471
 L  arc_capacity_472
 G  connected_order_arc_473
 L  arc_capacity_474
 G  connected_order_arc_475
 L  arc_capacity_476
 G  connected_order_arc_477
 L  arc_capacity_478
 G  connected_order_arc_479
 L  arc_capacity_480
 G  connected_order_arc_481
 L  arc_capacity_482
 G  connected_order_arc_483
 L  arc_capacity_484
 G  connected_order_arc_485
 L  arc_capacity_486
 G  connected_order_arc_487
 L  arc_capacity_488
 G  connected_order_arc_489
 L  arc_capacity_490
 G  connected_order_arc_491
 L  arc_capacity_492
 G  connected_order_arc_493
 L  arc_capacity_494
 L  arc_capacity_495
 G  connected_order_arc_496
 L  arc_capacity_497
 G  connected_order_arc_498
 L  arc_capacity_499
 G  connected_order_arc_500
 L  arc_capacity_501
 G  connected_order_arc_502
 L  arc_capacity_503
 G  connected_order_arc_504
 L  arc_capacity_505
 G  connected_order_arc_506
 L  arc_capacity_507
 G  connected_order_arc_508
 L  arc_capacity_509
 G  connected_order_arc_510
 L  arc_capacity_511
 G  connected_order_arc_512
 L  arc_capacity_513
 G  connected_order_arc_514
 L  arc_capacity_515
 G  connected_order_arc_516
 L  arc_capacity_517
 L  arc_capacity_518
 G  connected_order_arc_519
 L  arc_capacity_520
 G  connected_order_arc_521
 L  arc_capacity_522
 G  connected_order_arc_523
 L  arc_capacity_524
 G  connected_order_arc_525
 L  arc_capacity_526
 G  connected_order_arc_527
 L  arc_capacity_528
 G  connected_order_arc_529
 L  arc_capacity_530
 G  connected_order_arc_531
 L  arc_capacity_532
 G  connected_order_arc_533
 L  arc_capacity_534
 G  connected_order_arc_535
 L  arc_capacity_536
 G  connected_order_arc_537
 L  arc_capacity_538
 G  connected_order_arc_539
 L  arc_capacity_540
 L  arc_capacity_541
 G  connected_order_arc_542
 L  arc_capacity_543
 G  connected_order_arc_544
 L  arc_capacity_545
 G  connected_order_arc_546
 L  arc_capacity_547
 G  connected_order_arc_548
 L  arc_capacity_549
 G  connected_order_arc_550
 L  arc_capacity_551
 G  connected_order_arc_552
 L  arc_capacity_553
 G  connected_order_arc_554
 L  arc_capacity_555
 G  connected_order_arc_556
 L  arc_capacity_557
 G  connected_order_arc_558
 L  arc_capacity_559
 G  connected_order_arc_560
 L  arc_capacity_561
 G  connected_order_arc_562
 L  arc_capacity_563
 L  arc_capacity_564
 G  connected_order_arc_565
 L  arc_capacity_566
 G  connected_order_arc_567
 L  arc_capacity_568
 G  connected_order_arc_569
 L  arc_capacity_570
 G  connected_order_arc_571
 L  arc_capacity_572
 G  connected_order_arc_573
 L  arc_capacity_574
 G  connected_order_arc_575
 L  arc_capacity_576
 G  connected_order_arc_577
 L  arc_capacity_578
 G  connected_order_arc_579
 L  arc_capacity_580
 G  connected_order_arc_581
 L  arc_capacity_582
 G  connected_order_arc_583
 L  arc_capacity_584
 G  connected_order_arc_585
 L  arc_capacity_586
 L  arc_capacity_587
 G  connected_order_arc_588
 L  arc_capacity_589
 G  connected_order_arc_590
 L  arc_capacity_591
 G  connected_order_arc_592
 L  arc_capacity_593
 G  connected_order_arc_594
 L  arc_capacity_595
 G  connected_order_arc_596
 L  arc_capacity_597
 G  connected_order_arc_598
 L  arc_capacity_599
 G  connected_order_arc_600
 L  arc_capacity_601
 G  connected_order_arc_602
 L  arc_capacity_603
 G  connected_order_arc_604
 L  arc_capacity_605
 G  connected_order_arc_606
 L  arc_capacity_607
 G  connected_order_arc_608
 E  depot_departure_or_bypass_609
 E  depot_return_or_bypass_610
 E  out_degree_611
 E  in_degree_612
 G  order_active_lb_613
 L  order_active_ub_614
 E  segment_load_conservation_615
 G  segment_prefix_lb_616
 L  segment_prefix_ub_617
 E  out_degree_618
 E  in_degree_619
 G  order_active_lb_620
 L  order_active_ub_621
 E  segment_load_conservation_622
 G  segment_prefix_lb_623
 L  segment_prefix_ub_624
 E  out_degree_625
 E  in_degree_626
 G  order_active_lb_627
 L  order_active_ub_628
 E  segment_load_conservation_629
 G  segment_prefix_lb_630
 L  segment_prefix_ub_631
 E  out_degree_632
 E  in_degree_633
 G  order_active_lb_634
 L  order_active_ub_635
 E  segment_load_conservation_636
 G  segment_prefix_lb_637
 L  segment_prefix_ub_638
 E  out_degree_639
 E  in_degree_640
 G  order_active_lb_641
 L  order_active_ub_642
 E  service_visit_def_643
 E  free_load_conservation_644
 E  out_degree_645
 E  in_degree_646
 G  order_active_lb_647
 L  order_active_ub_648
 E  service_visit_def_649
 E  free_load_conservation_650
 E  out_degree_651
 E  in_degree_652
 G  order_active_lb_653
 L  order_active_ub_654
 E  service_visit_def_655
 E  free_load_conservation_656
 E  out_degree_657
 E  in_degree_658
 G  order_active_lb_659
 L  order_active_ub_660
 E  service_visit_def_661
 E  free_load_conservation_662
 E  out_degree_663
 E  in_degree_664
 G  order_active_lb_665
 L  order_active_ub_666
 E  service_visit_def_667
 E  free_load_conservation_668
 E  out_degree_669
 E  in_degree_670
 G  order_active_lb_671
 L  order_active_ub_672
 E  service_visit_def_673
 E  free_load_conservation_674
 E  out_degree_675
 E  in_degree_676
 G  order_active_lb_677
 L  order_active_ub_678
 E  service_visit_def_679
 E  free_load_conservation_680
 E  out_degree_681
 E  in_degree_682
 G  order_active_lb_683
 L  order_active_ub_684
 E  service_visit_def_685
 E  free_load_conservation_686
 G  fixed_segment_relative_order_687
 G  fixed_segment_relative_order_688
 G  fixed_segment_relative_order_689
 L  original_T_including_depot_unload_690
 L  arc_capacity_691
 L  arc_capacity_692
 L  arc_capacity_693
 L  arc_capacity_694
 L  arc_capacity_695
 L  arc_capacity_696
 L  arc_capacity_697
 L  arc_capacity_698
 L  arc_capacity_699
 L  arc_capacity_700
 L  arc_capacity_701
 L  arc_capacity_702
 L  arc_capacity_703
 L  arc_capacity_704
 L  arc_capacity_705
 G  connected_order_arc_706
 L  arc_capacity_707
 G  connected_order_arc_708
 L  arc_capacity_709
 G  connected_order_arc_710
 L  arc_capacity_711
 G  connected_order_arc_712
 L  arc_capacity_713
 G  connected_order_arc_714
 L  arc_capacity_715
 G  connected_order_arc_716
 L  arc_capacity_717
 G  connected_order_arc_718
 L  arc_capacity_719
 G  connected_order_arc_720
 L  arc_capacity_721
 G  connected_order_arc_722
 L  arc_capacity_723
 G  connected_order_arc_724
 L  arc_capacity_725
 G  connected_order_arc_726
 L  arc_capacity_727
 L  arc_capacity_728
 G  connected_order_arc_729
 L  arc_capacity_730
 G  connected_order_arc_731
 L  arc_capacity_732
 G  connected_order_arc_733
 L  arc_capacity_734
 G  connected_order_arc_735
 L  arc_capacity_736
 G  connected_order_arc_737
 L  arc_capacity_738
 G  connected_order_arc_739
 L  arc_capacity_740
 G  connected_order_arc_741
 L  arc_capacity_742
 G  connected_order_arc_743
 L  arc_capacity_744
 G  connected_order_arc_745
 L  arc_capacity_746
 G  connected_order_arc_747
 L  arc_capacity_748
 G  connected_order_arc_749
 L  arc_capacity_750
 L  arc_capacity_751
 G  connected_order_arc_752
 L  arc_capacity_753
 G  connected_order_arc_754
 L  arc_capacity_755
 G  connected_order_arc_756
 L  arc_capacity_757
 G  connected_order_arc_758
 L  arc_capacity_759
 G  connected_order_arc_760
 L  arc_capacity_761
 G  connected_order_arc_762
 L  arc_capacity_763
 G  connected_order_arc_764
 L  arc_capacity_765
 G  connected_order_arc_766
 L  arc_capacity_767
 G  connected_order_arc_768
 L  arc_capacity_769
 G  connected_order_arc_770
 L  arc_capacity_771
 G  connected_order_arc_772
 L  arc_capacity_773
 L  arc_capacity_774
 G  connected_order_arc_775
 L  arc_capacity_776
 G  connected_order_arc_777
 L  arc_capacity_778
 G  connected_order_arc_779
 L  arc_capacity_780
 G  connected_order_arc_781
 L  arc_capacity_782
 G  connected_order_arc_783
 L  arc_capacity_784
 G  connected_order_arc_785
 L  arc_capacity_786
 G  connected_order_arc_787
 L  arc_capacity_788
 G  connected_order_arc_789
 L  arc_capacity_790
 G  connected_order_arc_791
 L  arc_capacity_792
 G  connected_order_arc_793
 L  arc_capacity_794
 G  connected_order_arc_795
 L  arc_capacity_796
 L  arc_capacity_797
 G  connected_order_arc_798
 L  arc_capacity_799
 G  connected_order_arc_800
 L  arc_capacity_801
 G  connected_order_arc_802
 L  arc_capacity_803
 G  connected_order_arc_804
 L  arc_capacity_805
 G  connected_order_arc_806
 L  arc_capacity_807
 G  connected_order_arc_808
 L  arc_capacity_809
 G  connected_order_arc_810
 L  arc_capacity_811
 G  connected_order_arc_812
 L  arc_capacity_813
 G  connected_order_arc_814
 L  arc_capacity_815
 G  connected_order_arc_816
 L  arc_capacity_817
 G  connected_order_arc_818
 L  arc_capacity_819
 L  arc_capacity_820
 G  connected_order_arc_821
 L  arc_capacity_822
 G  connected_order_arc_823
 L  arc_capacity_824
 G  connected_order_arc_825
 L  arc_capacity_826
 G  connected_order_arc_827
 L  arc_capacity_828
 G  connected_order_arc_829
 L  arc_capacity_830
 G  connected_order_arc_831
 L  arc_capacity_832
 G  connected_order_arc_833
 L  arc_capacity_834
 G  connected_order_arc_835
 L  arc_capacity_836
 G  connected_order_arc_837
 L  arc_capacity_838
 G  connected_order_arc_839
 L  arc_capacity_840
 G  connected_order_arc_841
 L  arc_capacity_842
 L  arc_capacity_843
 G  connected_order_arc_844
 L  arc_capacity_845
 G  connected_order_arc_846
 L  arc_capacity_847
 G  connected_order_arc_848
 L  arc_capacity_849
 G  connected_order_arc_850
 L  arc_capacity_851
 G  connected_order_arc_852
 L  arc_capacity_853
 G  connected_order_arc_854
 L  arc_capacity_855
 G  connected_order_arc_856
 L  arc_capacity_857
 G  connected_order_arc_858
 L  arc_capacity_859
 G  connected_order_arc_860
 L  arc_capacity_861
 G  connected_order_arc_862
 L  arc_capacity_863
 G  connected_order_arc_864
 L  arc_capacity_865
 L  arc_capacity_866
 G  connected_order_arc_867
 L  arc_capacity_868
 G  connected_order_arc_869
 L  arc_capacity_870
 G  connected_order_arc_871
 L  arc_capacity_872
 G  connected_order_arc_873
 L  arc_capacity_874
 G  connected_order_arc_875
 L  arc_capacity_876
 G  connected_order_arc_877
 L  arc_capacity_878
 G  connected_order_arc_879
 L  arc_capacity_880
 G  connected_order_arc_881
 L  arc_capacity_882
 G  connected_order_arc_883
 L  arc_capacity_884
 G  connected_order_arc_885
 L  arc_capacity_886
 G  connected_order_arc_887
 L  arc_capacity_888
 L  arc_capacity_889
 G  connected_order_arc_890
 L  arc_capacity_891
 G  connected_order_arc_892
 L  arc_capacity_893
 G  connected_order_arc_894
 L  arc_capacity_895
 G  connected_order_arc_896
 L  arc_capacity_897
 G  connected_order_arc_898
 L  arc_capacity_899
 G  connected_order_arc_900
 L  arc_capacity_901
 G  connected_order_arc_902
 L  arc_capacity_903
 G  connected_order_arc_904
 L  arc_capacity_905
 G  connected_order_arc_906
 L  arc_capacity_907
 G  connected_order_arc_908
 L  arc_capacity_909
 G  connected_order_arc_910
 L  arc_capacity_911
 L  arc_capacity_912
 G  connected_order_arc_913
 L  arc_capacity_914
 G  connected_order_arc_915
 L  arc_capacity_916
 G  connected_order_arc_917
 L  arc_capacity_918
 G  connected_order_arc_919
 L  arc_capacity_920
 G  connected_order_arc_921
 L  arc_capacity_922
 G  connected_order_arc_923
 L  arc_capacity_924
 G  connected_order_arc_925
 L  arc_capacity_926
 G  connected_order_arc_927
 L  arc_capacity_928
 G  connected_order_arc_929
 L  arc_capacity_930
 G  connected_order_arc_931
 L  arc_capacity_932
 G  connected_order_arc_933
 L  arc_capacity_934
 L  arc_capacity_935
 G  connected_order_arc_936
 L  arc_capacity_937
 G  connected_order_arc_938
 L  arc_capacity_939
 G  connected_order_arc_940
 L  arc_capacity_941
 G  connected_order_arc_942
 L  arc_capacity_943
 G  connected_order_arc_944
 L  arc_capacity_945
 G  connected_order_arc_946
 L  arc_capacity_947
 G  connected_order_arc_948
 L  arc_capacity_949
 G  connected_order_arc_950
 L  arc_capacity_951
 G  connected_order_arc_952
 L  arc_capacity_953
 G  connected_order_arc_954
 L  arc_capacity_955
 G  connected_order_arc_956
 L  arc_capacity_957
 L  arc_capacity_958
 G  connected_order_arc_959
 L  arc_capacity_960
 G  connected_order_arc_961
 L  arc_capacity_962
 G  connected_order_arc_963
 L  arc_capacity_964
 G  connected_order_arc_965
 L  arc_capacity_966
 G  connected_order_arc_967
 L  arc_capacity_968
 G  connected_order_arc_969
 L  arc_capacity_970
 G  connected_order_arc_971
 L  arc_capacity_972
 G  connected_order_arc_973
 L  arc_capacity_974
 G  connected_order_arc_975
 L  arc_capacity_976
 G  connected_order_arc_977
 L  arc_capacity_978
 G  connected_order_arc_979
 E  depot_departure_or_bypass_980
 E  depot_return_or_bypass_981
 E  out_degree_982
 E  in_degree_983
 G  order_active_lb_984
 L  order_active_ub_985
 E  segment_load_conservation_986
 G  segment_prefix_lb_987
 L  segment_prefix_ub_988
 E  out_degree_989
 E  in_degree_990
 G  order_active_lb_991
 L  order_active_ub_992
 E  segment_load_conservation_993
 G  segment_prefix_lb_994
 L  segment_prefix_ub_995
 E  out_degree_996
 E  in_degree_997
 G  order_active_lb_998
 L  order_active_ub_999
 E  segment_load_conservation_1000
 G  segment_prefix_lb_1001
 L  segment_prefix_ub_1002
 E  out_degree_1003
 E  in_degree_1004
 G  order_active_lb_1005
 L  order_active_ub_1006
 E  segment_load_conservation_1007
 G  segment_prefix_lb_1008
 L  segment_prefix_ub_1009
 E  out_degree_1010
 E  in_degree_1011
 G  order_active_lb_1012
 L  order_active_ub_1013
 E  service_visit_def_1014
 E  free_load_conservation_1015
 E  out_degree_1016
 E  in_degree_1017
 G  order_active_lb_1018
 L  order_active_ub_1019
 E  service_visit_def_1020
 E  free_load_conservation_1021
 E  out_degree_1022
 E  in_degree_1023
 G  order_active_lb_1024
 L  order_active_ub_1025
 E  service_visit_def_1026
 E  free_load_conservation_1027
 E  out_degree_1028
 E  in_degree_1029
 G  order_active_lb_1030
 L  order_active_ub_1031
 E  service_visit_def_1032
 E  free_load_conservation_1033
 E  out_degree_1034
 E  in_degree_1035
 G  order_active_lb_1036
 L  order_active_ub_1037
 E  service_visit_def_1038
 E  free_load_conservation_1039
 E  out_degree_1040
 E  in_degree_1041
 G  order_active_lb_1042
 L  order_active_ub_1043
 E  service_visit_def_1044
 E  free_load_conservation_1045
 E  out_degree_1046
 E  in_degree_1047
 G  order_active_lb_1048
 L  order_active_ub_1049
 E  service_visit_def_1050
 E  free_load_conservation_1051
 E  out_degree_1052
 E  in_degree_1053
 G  order_active_lb_1054
 L  order_active_ub_1055
 E  service_visit_def_1056
 E  free_load_conservation_1057
 G  fixed_segment_relative_order_1058
 G  fixed_segment_relative_order_1059
 G  fixed_segment_relative_order_1060
 L  original_T_including_depot_unload_1061
 L  arc_capacity_1062
 L  arc_capacity_1063
 L  arc_capacity_1064
 L  arc_capacity_1065
 L  arc_capacity_1066
 L  arc_capacity_1067
 L  arc_capacity_1068
 L  arc_capacity_1069
 L  arc_capacity_1070
 L  arc_capacity_1071
 L  arc_capacity_1072
 L  arc_capacity_1073
 L  arc_capacity_1074
 L  arc_capacity_1075
 G  connected_order_arc_1076
 L  arc_capacity_1077
 G  connected_order_arc_1078
 L  arc_capacity_1079
 G  connected_order_arc_1080
 L  arc_capacity_1081
 G  connected_order_arc_1082
 L  arc_capacity_1083
 G  connected_order_arc_1084
 L  arc_capacity_1085
 G  connected_order_arc_1086
 L  arc_capacity_1087
 G  connected_order_arc_1088
 L  arc_capacity_1089
 G  connected_order_arc_1090
 L  arc_capacity_1091
 G  connected_order_arc_1092
 L  arc_capacity_1093
 G  connected_order_arc_1094
 L  arc_capacity_1095
 L  arc_capacity_1096
 G  connected_order_arc_1097
 L  arc_capacity_1098
 G  connected_order_arc_1099
 L  arc_capacity_1100
 G  connected_order_arc_1101
 L  arc_capacity_1102
 G  connected_order_arc_1103
 L  arc_capacity_1104
 G  connected_order_arc_1105
 L  arc_capacity_1106
 G  connected_order_arc_1107
 L  arc_capacity_1108
 G  connected_order_arc_1109
 L  arc_capacity_1110
 G  connected_order_arc_1111
 L  arc_capacity_1112
 G  connected_order_arc_1113
 L  arc_capacity_1114
 G  connected_order_arc_1115
 L  arc_capacity_1116
 L  arc_capacity_1117
 G  connected_order_arc_1118
 L  arc_capacity_1119
 G  connected_order_arc_1120
 L  arc_capacity_1121
 G  connected_order_arc_1122
 L  arc_capacity_1123
 G  connected_order_arc_1124
 L  arc_capacity_1125
 G  connected_order_arc_1126
 L  arc_capacity_1127
 G  connected_order_arc_1128
 L  arc_capacity_1129
 G  connected_order_arc_1130
 L  arc_capacity_1131
 G  connected_order_arc_1132
 L  arc_capacity_1133
 G  connected_order_arc_1134
 L  arc_capacity_1135
 G  connected_order_arc_1136
 L  arc_capacity_1137
 L  arc_capacity_1138
 G  connected_order_arc_1139
 L  arc_capacity_1140
 G  connected_order_arc_1141
 L  arc_capacity_1142
 G  connected_order_arc_1143
 L  arc_capacity_1144
 G  connected_order_arc_1145
 L  arc_capacity_1146
 G  connected_order_arc_1147
 L  arc_capacity_1148
 G  connected_order_arc_1149
 L  arc_capacity_1150
 G  connected_order_arc_1151
 L  arc_capacity_1152
 G  connected_order_arc_1153
 L  arc_capacity_1154
 G  connected_order_arc_1155
 L  arc_capacity_1156
 G  connected_order_arc_1157
 L  arc_capacity_1158
 L  arc_capacity_1159
 G  connected_order_arc_1160
 L  arc_capacity_1161
 G  connected_order_arc_1162
 L  arc_capacity_1163
 G  connected_order_arc_1164
 L  arc_capacity_1165
 G  connected_order_arc_1166
 L  arc_capacity_1167
 G  connected_order_arc_1168
 L  arc_capacity_1169
 G  connected_order_arc_1170
 L  arc_capacity_1171
 G  connected_order_arc_1172
 L  arc_capacity_1173
 G  connected_order_arc_1174
 L  arc_capacity_1175
 G  connected_order_arc_1176
 L  arc_capacity_1177
 G  connected_order_arc_1178
 L  arc_capacity_1179
 L  arc_capacity_1180
 G  connected_order_arc_1181
 L  arc_capacity_1182
 G  connected_order_arc_1183
 L  arc_capacity_1184
 G  connected_order_arc_1185
 L  arc_capacity_1186
 G  connected_order_arc_1187
 L  arc_capacity_1188
 G  connected_order_arc_1189
 L  arc_capacity_1190
 G  connected_order_arc_1191
 L  arc_capacity_1192
 G  connected_order_arc_1193
 L  arc_capacity_1194
 G  connected_order_arc_1195
 L  arc_capacity_1196
 G  connected_order_arc_1197
 L  arc_capacity_1198
 G  connected_order_arc_1199
 L  arc_capacity_1200
 L  arc_capacity_1201
 G  connected_order_arc_1202
 L  arc_capacity_1203
 G  connected_order_arc_1204
 L  arc_capacity_1205
 G  connected_order_arc_1206
 L  arc_capacity_1207
 G  connected_order_arc_1208
 L  arc_capacity_1209
 G  connected_order_arc_1210
 L  arc_capacity_1211
 G  connected_order_arc_1212
 L  arc_capacity_1213
 G  connected_order_arc_1214
 L  arc_capacity_1215
 G  connected_order_arc_1216
 L  arc_capacity_1217
 G  connected_order_arc_1218
 L  arc_capacity_1219
 G  connected_order_arc_1220
 L  arc_capacity_1221
 L  arc_capacity_1222
 G  connected_order_arc_1223
 L  arc_capacity_1224
 G  connected_order_arc_1225
 L  arc_capacity_1226
 G  connected_order_arc_1227
 L  arc_capacity_1228
 G  connected_order_arc_1229
 L  arc_capacity_1230
 G  connected_order_arc_1231
 L  arc_capacity_1232
 G  connected_order_arc_1233
 L  arc_capacity_1234
 G  connected_order_arc_1235
 L  arc_capacity_1236
 G  connected_order_arc_1237
 L  arc_capacity_1238
 G  connected_order_arc_1239
 L  arc_capacity_1240
 G  connected_order_arc_1241
 L  arc_capacity_1242
 L  arc_capacity_1243
 G  connected_order_arc_1244
 L  arc_capacity_1245
 G  connected_order_arc_1246
 L  arc_capacity_1247
 G  connected_order_arc_1248
 L  arc_capacity_1249
 G  connected_order_arc_1250
 L  arc_capacity_1251
 G  connected_order_arc_1252
 L  arc_capacity_1253
 G  connected_order_arc_1254
 L  arc_capacity_1255
 G  connected_order_arc_1256
 L  arc_capacity_1257
 G  connected_order_arc_1258
 L  arc_capacity_1259
 G  connected_order_arc_1260
 L  arc_capacity_1261
 G  connected_order_arc_1262
 L  arc_capacity_1263
 L  arc_capacity_1264
 G  connected_order_arc_1265
 L  arc_capacity_1266
 G  connected_order_arc_1267
 L  arc_capacity_1268
 G  connected_order_arc_1269
 L  arc_capacity_1270
 G  connected_order_arc_1271
 L  arc_capacity_1272
 G  connected_order_arc_1273
 L  arc_capacity_1274
 G  connected_order_arc_1275
 L  arc_capacity_1276
 G  connected_order_arc_1277
 L  arc_capacity_1278
 G  connected_order_arc_1279
 L  arc_capacity_1280
 G  connected_order_arc_1281
 L  arc_capacity_1282
 G  connected_order_arc_1283
 L  arc_capacity_1284
 L  arc_capacity_1285
 G  connected_order_arc_1286
 L  arc_capacity_1287
 G  connected_order_arc_1288
 L  arc_capacity_1289
 G  connected_order_arc_1290
 L  arc_capacity_1291
 G  connected_order_arc_1292
 L  arc_capacity_1293
 G  connected_order_arc_1294
 L  arc_capacity_1295
 G  connected_order_arc_1296
 L  arc_capacity_1297
 G  connected_order_arc_1298
 L  arc_capacity_1299
 G  connected_order_arc_1300
 L  arc_capacity_1301
 G  connected_order_arc_1302
 L  arc_capacity_1303
 G  connected_order_arc_1304
 E  depot_departure_or_bypass_1305
 E  depot_return_or_bypass_1306
 E  out_degree_1307
 E  in_degree_1308
 G  order_active_lb_1309
 L  order_active_ub_1310
 E  segment_load_conservation_1311
 G  segment_prefix_lb_1312
 L  segment_prefix_ub_1313
 E  out_degree_1314
 E  in_degree_1315
 G  order_active_lb_1316
 L  order_active_ub_1317
 E  segment_load_conservation_1318
 G  segment_prefix_lb_1319
 L  segment_prefix_ub_1320
 E  out_degree_1321
 E  in_degree_1322
 G  order_active_lb_1323
 L  order_active_ub_1324
 E  segment_load_conservation_1325
 G  segment_prefix_lb_1326
 L  segment_prefix_ub_1327
 E  out_degree_1328
 E  in_degree_1329
 G  order_active_lb_1330
 L  order_active_ub_1331
 E  service_visit_def_1332
 E  free_load_conservation_1333
 E  out_degree_1334
 E  in_degree_1335
 G  order_active_lb_1336
 L  order_active_ub_1337
 E  service_visit_def_1338
 E  free_load_conservation_1339
 E  out_degree_1340
 E  in_degree_1341
 G  order_active_lb_1342
 L  order_active_ub_1343
 E  service_visit_def_1344
 E  free_load_conservation_1345
 E  out_degree_1346
 E  in_degree_1347
 G  order_active_lb_1348
 L  order_active_ub_1349
 E  service_visit_def_1350
 E  free_load_conservation_1351
 E  out_degree_1352
 E  in_degree_1353
 G  order_active_lb_1354
 L  order_active_ub_1355
 E  service_visit_def_1356
 E  free_load_conservation_1357
 E  out_degree_1358
 E  in_degree_1359
 G  order_active_lb_1360
 L  order_active_ub_1361
 E  service_visit_def_1362
 E  free_load_conservation_1363
 E  out_degree_1364
 E  in_degree_1365
 G  order_active_lb_1366
 L  order_active_ub_1367
 E  service_visit_def_1368
 E  free_load_conservation_1369
 E  out_degree_1370
 E  in_degree_1371
 G  order_active_lb_1372
 L  order_active_ub_1373
 E  service_visit_def_1374
 E  free_load_conservation_1375
 G  fixed_segment_relative_order_1376
 G  fixed_segment_relative_order_1377
 L  original_T_including_depot_unload_1378
COLUMNS
    t         normalized_mass_20_23  -1
    t         normalized_mass_21_40  -1
    t         normalized_mass_34_75  -1
    t         normalized_mass_19_100  -1
    t         normalized_mass_29_125  -1
    t         normalized_mass_18_150  -1
    t         normalized_mass_27_167  -1
    t         normalized_mass_17_184  -1
    t         normalization_245  2.2534523809523808e+01
    t         full_original_Gini_246  -8.6633333333333411e+01
    q         OBJ       1
    q         parent_nonstrict_scope_188  1
    q         full_original_Gini_246  35
    MARKER    'MARKER'                 'INTORG'
    x_20_0    OBJ       1.1636571534741636e-02
    x_20_0    product_lb_0  -2.6035209521422013e-02
    x_20_0    product_ub_1  -4.4376353742978512e-02
    x_20_0    onehot_20_22  1
    x_20_0    parent_nonstrict_scope_188  2.3273143069483273e-02
    x_20_0    unique_nonzero_owner_247  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_0    product_lb_0  1
    w_20_0    product_ub_1  1
    w_20_0    normalized_mass_20_23  1
    w_20_0    full_original_Gini_246  -2.2534523809523808e+01
    MARKER    'MARKER'                 'INTORG'
    x_20_1    OBJ       6.9819429208449833e-03
    x_20_1    product_lb_2  -2.6035209521422013e-02
    x_20_1    product_ub_3  -4.4376353742978512e-02
    x_20_1    onehot_20_22  1
    x_20_1    stock_lb_186  1
    x_20_1    stock_ub_187  1
    x_20_1    parent_nonstrict_scope_188  1.8618514455586620e-02
    x_20_1    unique_nonzero_owner_248  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_1    product_lb_2  1
    w_20_1    product_ub_3  1
    w_20_1    normalized_mass_20_23  1
    w_20_1    normalized_ratio_20_24  -0.2
    w_20_1    full_original_Gini_246  -1.7534523809523815e+01
    MARKER    'MARKER'                 'INTORG'
    x_20_2    OBJ       2.3273143069483266e-03
    x_20_2    product_lb_4  -2.6035209521422013e-02
    x_20_2    product_ub_5  -4.4376353742978512e-02
    x_20_2    onehot_20_22  1
    x_20_2    stock_lb_186  2
    x_20_2    stock_ub_187  2
    x_20_2    parent_nonstrict_scope_188  1.3963885841689963e-02
    x_20_2    unique_nonzero_owner_249  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_2    product_lb_4  1
    w_20_2    product_ub_5  1
    w_20_2    normalized_mass_20_23  1
    w_20_2    normalized_ratio_20_24  -0.4
    w_20_2    full_original_Gini_246  -1.2667857142857141e+01
    MARKER    'MARKER'                 'INTORG'
    x_20_3    OBJ       -0.00232731430694833
    x_20_3    product_lb_6  -2.6035209521422013e-02
    x_20_3    product_ub_7  -4.4376353742978512e-02
    x_20_3    onehot_20_22  1
    x_20_3    stock_lb_186  3
    x_20_3    stock_ub_187  3
    x_20_3    parent_nonstrict_scope_188  9.3092572277933064e-03
    x_20_3    unique_nonzero_owner_250  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_3    product_lb_6  1
    w_20_3    product_ub_7  1
    w_20_3    normalized_mass_20_23  1
    w_20_3    normalized_ratio_20_24  -6.0000000000000009e-01
    w_20_3    full_original_Gini_246  -8.0678571428571431e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_4    OBJ       -6.9819429208449833e-03
    x_20_4    product_lb_8  -2.6035209521422013e-02
    x_20_4    product_ub_9  -4.4376353742978512e-02
    x_20_4    onehot_20_22  1
    x_20_4    stock_lb_186  4
    x_20_4    stock_ub_187  4
    x_20_4    parent_nonstrict_scope_188  4.6546286138966532e-03
    x_20_4    unique_nonzero_owner_251  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_4    product_lb_8  1
    w_20_4    product_ub_9  1
    w_20_4    normalized_mass_20_23  1
    w_20_4    normalized_ratio_20_24  -0.8
    w_20_4    full_original_Gini_246  -4.40595238095238
    MARKER    'MARKER'                 'INTORG'
    x_20_5    OBJ       -1.1636571534741636e-02
    x_20_5    product_lb_10  -2.6035209521422013e-02
    x_20_5    product_ub_11  -4.4376353742978512e-02
    x_20_5    onehot_20_22  1
    x_20_5    stock_lb_186  5
    x_20_5    stock_ub_187  5
    x_20_5    unique_nonzero_owner_252  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_5    product_lb_10  1
    w_20_5    product_ub_11  1
    w_20_5    normalized_mass_20_23  1
    w_20_5    normalized_ratio_20_24  -1
    w_20_5    full_original_Gini_246  -5.4654761904761910e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_6    OBJ       -6.9819429208449781e-03
    x_20_6    product_lb_12  -2.6035209521422013e-02
    x_20_6    product_ub_13  -4.4376353742978512e-02
    x_20_6    onehot_20_22  1
    x_20_6    stock_lb_186  6
    x_20_6    stock_ub_187  6
    x_20_6    parent_nonstrict_scope_188  4.6546286138966584e-03
    x_20_6    unique_nonzero_owner_253  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_6    product_lb_12  1
    w_20_6    product_ub_13  1
    w_20_6    normalized_mass_20_23  1
    w_20_6    normalized_ratio_20_24  -1.2000000000000002e+00
    w_20_6    full_original_Gini_246  -1.0465476190476192e+01
    MARKER    'MARKER'                 'INTORG'
    x_20_7    OBJ       -2.3273143069483249e-03
    x_20_7    product_lb_14  -2.6035209521422013e-02
    x_20_7    product_ub_15  -4.4376353742978512e-02
    x_20_7    onehot_20_22  1
    x_20_7    stock_lb_186  7
    x_20_7    stock_ub_187  7
    x_20_7    parent_nonstrict_scope_188  9.3092572277933116e-03
    MARKER    'MARKER'                 'INTEND'
    w_20_7    product_lb_14  1
    w_20_7    product_ub_15  1
    w_20_7    normalized_mass_20_23  1
    w_20_7    normalized_ratio_20_24  -1.4000000000000001e+00
    w_20_7    full_original_Gini_246  -1.5465476190476195e+01
    MARKER    'MARKER'                 'INTORG'
    x_20_8    OBJ       0.00232731430694833
    x_20_8    product_lb_16  -2.6035209521422013e-02
    x_20_8    product_ub_17  -4.4376353742978512e-02
    x_20_8    onehot_20_22  1
    x_20_8    stock_lb_186  8
    x_20_8    stock_ub_187  8
    x_20_8    parent_nonstrict_scope_188  1.3963885841689967e-02
    x_20_8    unique_nonzero_owner_254  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_8    product_lb_16  1
    w_20_8    product_ub_17  1
    w_20_8    normalized_mass_20_23  1
    w_20_8    normalized_ratio_20_24  -1.6
    w_20_8    full_original_Gini_246  -2.0665476190476195e+01
    MARKER    'MARKER'                 'INTORG'
    x_20_9    OBJ       6.9819429208449833e-03
    x_20_9    product_lb_18  -2.6035209521422013e-02
    x_20_9    product_ub_19  -4.4376353742978512e-02
    x_20_9    onehot_20_22  1
    x_20_9    stock_lb_186  9
    x_20_9    stock_ub_187  9
    x_20_9    parent_nonstrict_scope_188  1.8618514455586620e-02
    x_20_9    unique_nonzero_owner_255  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_9    product_lb_18  1
    w_20_9    product_ub_19  1
    w_20_9    normalized_mass_20_23  1
    w_20_9    normalized_ratio_20_24  -1.8
    w_20_9    full_original_Gini_246  -26.0654761904762
    MARKER    'MARKER'                 'INTORG'
    x_20_10   OBJ       1.1636571534741636e-02
    x_20_10   product_lb_20  -2.6035209521422013e-02
    x_20_10   product_ub_21  -4.4376353742978512e-02
    x_20_10   onehot_20_22  1
    x_20_10   stock_lb_186  10
    x_20_10   stock_ub_187  10
    x_20_10   parent_nonstrict_scope_188  2.3273143069483273e-02
    x_20_10   unique_nonzero_owner_256  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_10   product_lb_20  1
    w_20_10   product_ub_21  1
    w_20_10   normalized_mass_20_23  1
    w_20_10   normalized_ratio_20_24  -2
    w_20_10   full_original_Gini_246  -3.1465476190476185e+01
    rho_20    normalized_ratio_20_24  1
    rho_20    block_pair_pos_201  -1
    rho_20    block_pair_neg_202  1
    rho_20    block_pair_pos_203  -1
    rho_20    block_pair_neg_204  1
    rho_20    block_pair_pos_205  -1
    rho_20    block_pair_neg_206  1
    rho_20    block_pair_pos_207  -1
    rho_20    block_pair_neg_208  1
    rho_20    block_pair_pos_209  -1
    rho_20    block_pair_neg_210  1
    rho_20    block_pair_pos_211  -1
    rho_20    block_pair_neg_212  1
    rho_20    block_pair_pos_213  -1
    rho_20    block_pair_neg_214  1
    rho_20    normalization_245  1
    MARKER    'MARKER'                 'INTORG'
    x_21_0    OBJ       4.1891612282083379e-03
    x_21_0    product_lb_25  -2.6035209521422013e-02
    x_21_0    product_ub_26  -4.4376353742978512e-02
    x_21_0    onehot_21_39  1
    x_21_0    parent_nonstrict_scope_188  8.3783224564166758e-03
    MARKER    'MARKER'                 'INTEND'
    w_21_0    product_lb_25  1
    w_21_0    product_ub_26  1
    w_21_0    normalized_mass_21_40  1
    w_21_0    full_original_Gini_246  -2.2534523809523808e+01
    MARKER    'MARKER'                 'INTORG'
    x_21_1    OBJ       1.3963870760694466e-03
    x_21_1    product_lb_27  -2.6035209521422013e-02
    x_21_1    product_ub_28  -4.4376353742978512e-02
    x_21_1    onehot_21_39  1
    x_21_1    stock_lb_186  1
    x_21_1    stock_ub_187  1
    x_21_1    parent_nonstrict_scope_188  5.5855483042777845e-03
    x_21_1    unique_nonzero_owner_257  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_1    product_lb_27  1
    w_21_1    product_ub_28  1
    w_21_1    normalized_mass_21_40  1
    w_21_1    normalized_ratio_21_41  -3.3333333333333331e-01
    w_21_1    full_original_Gini_246  -1.4201190476190474e+01
    MARKER    'MARKER'                 'INTORG'
    x_21_2    OBJ       -1.3963870760694457e-03
    x_21_2    product_lb_29  -2.6035209521422013e-02
    x_21_2    product_ub_30  -4.4376353742978512e-02
    x_21_2    onehot_21_39  1
    x_21_2    stock_lb_186  2
    x_21_2    stock_ub_187  2
    x_21_2    parent_nonstrict_scope_188  2.7927741521388922e-03
    x_21_2    unique_nonzero_owner_258  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_2    product_lb_29  1
    w_21_2    product_ub_30  1
    w_21_2    normalized_mass_21_40  1
    w_21_2    normalized_ratio_21_41  -6.6666666666666663e-01
    w_21_2    full_original_Gini_246  -6.5345238095238081e+00
    MARKER    'MARKER'                 'INTORG'
    x_21_3    OBJ       -4.1891612282083379e-03
    x_21_3    product_lb_31  -2.6035209521422013e-02
    x_21_3    product_ub_32  -4.4376353742978512e-02
    x_21_3    onehot_21_39  1
    x_21_3    stock_lb_186  3
    x_21_3    stock_ub_187  3
    x_21_3    unique_nonzero_owner_259  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_3    product_lb_31  1
    w_21_3    product_ub_32  1
    w_21_3    normalized_mass_21_40  1
    w_21_3    normalized_ratio_21_41  -1
    w_21_3    full_original_Gini_246  -5.4654761904761910e+00
    MARKER    'MARKER'                 'INTORG'
    x_21_4    OBJ       -1.3963870760694466e-03
    x_21_4    product_lb_33  -2.6035209521422013e-02
    x_21_4    product_ub_34  -4.4376353742978512e-02
    x_21_4    onehot_21_39  1
    x_21_4    stock_lb_186  4
    x_21_4    stock_ub_187  4
    x_21_4    parent_nonstrict_scope_188  2.7927741521388914e-03
    x_21_4    unique_nonzero_owner_260  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_4    product_lb_33  1
    w_21_4    product_ub_34  1
    w_21_4    normalized_mass_21_40  1
    w_21_4    normalized_ratio_21_41  -1.3333333333333333e+00
    w_21_4    full_original_Gini_246  -1.3798809523809524e+01
    MARKER    'MARKER'                 'INTORG'
    x_21_5    OBJ       1.3963870760694448e-03
    x_21_5    product_lb_35  -2.6035209521422013e-02
    x_21_5    product_ub_36  -4.4376353742978512e-02
    x_21_5    onehot_21_39  1
    x_21_5    stock_lb_186  5
    x_21_5    stock_ub_187  5
    x_21_5    parent_nonstrict_scope_188  5.5855483042777827e-03
    x_21_5    unique_nonzero_owner_261  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_5    product_lb_35  1
    w_21_5    product_ub_36  1
    w_21_5    normalized_mass_21_40  1
    w_21_5    normalized_ratio_21_41  -1.6666666666666665e+00
    w_21_5    full_original_Gini_246  -2.2465476190476188e+01
    MARKER    'MARKER'                 'INTORG'
    x_21_6    OBJ       4.1891612282083379e-03
    x_21_6    product_lb_37  -2.6035209521422013e-02
    x_21_6    product_ub_38  -4.4376353742978512e-02
    x_21_6    onehot_21_39  1
    x_21_6    stock_lb_186  6
    x_21_6    stock_ub_187  6
    x_21_6    parent_nonstrict_scope_188  8.3783224564166758e-03
    x_21_6    unique_nonzero_owner_262  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_6    product_lb_37  1
    w_21_6    product_ub_38  1
    w_21_6    normalized_mass_21_40  1
    w_21_6    normalized_ratio_21_41  -2
    w_21_6    full_original_Gini_246  -3.1465476190476185e+01
    rho_21    normalized_ratio_21_41  1
    rho_21    block_pair_pos_207  1
    rho_21    block_pair_neg_208  -1
    rho_21    block_pair_pos_215  -1
    rho_21    block_pair_neg_216  1
    rho_21    block_pair_pos_217  -1
    rho_21    block_pair_neg_218  1
    rho_21    block_pair_pos_219  -1
    rho_21    block_pair_neg_220  1
    rho_21    block_pair_pos_221  -1
    rho_21    block_pair_neg_222  1
    rho_21    block_pair_pos_223  -1
    rho_21    block_pair_neg_224  1
    rho_21    block_pair_pos_225  -1
    rho_21    block_pair_neg_226  1
    rho_21    normalization_245  1
    MARKER    'MARKER'                 'INTORG'
    x_34_0    OBJ       2.9789603523644435e-02
    x_34_0    product_lb_42  -2.6035209521422013e-02
    x_34_0    product_ub_43  -4.4376353742978512e-02
    x_34_0    onehot_34_74  1
    x_34_0    parent_nonstrict_scope_188  5.9579207047288869e-02
    x_34_0    unique_nonzero_owner_263  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_0    product_lb_42  1
    w_34_0    product_ub_43  1
    w_34_0    normalized_mass_34_75  1
    w_34_0    full_original_Gini_246  -2.2534523809523808e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_1    OBJ       2.2342202642733327e-02
    x_34_1    product_lb_44  -2.6035209521422013e-02
    x_34_1    product_ub_45  -4.4376353742978512e-02
    x_34_1    onehot_34_74  1
    x_34_1    stock_lb_186  1
    x_34_1    stock_ub_187  1
    x_34_1    parent_nonstrict_scope_188  5.2131806166377762e-02
    x_34_1    unique_nonzero_owner_264  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_1    product_lb_44  1
    w_34_1    product_ub_45  1
    w_34_1    normalized_mass_34_75  1
    w_34_1    normalized_ratio_34_76  -0.125
    w_34_1    full_original_Gini_246  -1.9409523809523812e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_2    OBJ       1.4894801761822219e-02
    x_34_2    product_lb_46  -2.6035209521422013e-02
    x_34_2    product_ub_47  -4.4376353742978512e-02
    x_34_2    onehot_34_74  1
    x_34_2    stock_lb_186  2
    x_34_2    stock_ub_187  2
    x_34_2    parent_nonstrict_scope_188  4.4684405285466654e-02
    MARKER    'MARKER'                 'INTEND'
    w_34_2    product_lb_46  1
    w_34_2    product_ub_47  1
    w_34_2    normalized_mass_34_75  1
    w_34_2    normalized_ratio_34_76  -0.25
    w_34_2    full_original_Gini_246  -1.6284523809523812e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_3    OBJ       7.4474008809111113e-03
    x_34_3    product_lb_48  -2.6035209521422013e-02
    x_34_3    product_ub_49  -4.4376353742978512e-02
    x_34_3    onehot_34_74  1
    x_34_3    stock_lb_186  3
    x_34_3    stock_ub_187  3
    x_34_3    parent_nonstrict_scope_188  3.7237004404555546e-02
    x_34_3    unique_nonzero_owner_265  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_3    product_lb_48  1
    w_34_3    product_ub_49  1
    w_34_3    normalized_mass_34_75  1
    w_34_3    normalized_ratio_34_76  -0.375
    w_34_3    full_original_Gini_246  -1.3242857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_4    product_lb_50  -2.6035209521422013e-02
    x_34_4    product_ub_51  -4.4376353742978512e-02
    x_34_4    onehot_34_74  1
    x_34_4    stock_lb_186  4
    x_34_4    stock_ub_187  4
    x_34_4    parent_nonstrict_scope_188  2.9789603523644435e-02
    x_34_4    unique_nonzero_owner_266  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_4    product_lb_50  1
    w_34_4    product_ub_51  1
    w_34_4    normalized_mass_34_75  1
    w_34_4    normalized_ratio_34_76  -0.5
    w_34_4    full_original_Gini_246  -1.0367857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_5    OBJ       -7.4474008809111078e-03
    x_34_5    product_lb_52  -2.6035209521422013e-02
    x_34_5    product_ub_53  -4.4376353742978512e-02
    x_34_5    onehot_34_74  1
    x_34_5    stock_lb_186  5
    x_34_5    stock_ub_187  5
    x_34_5    parent_nonstrict_scope_188  2.2342202642733327e-02
    x_34_5    unique_nonzero_owner_267  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_5    product_lb_52  1
    w_34_5    product_ub_53  1
    w_34_5    normalized_mass_34_75  1
    w_34_5    normalized_ratio_34_76  -0.625
    w_34_5    full_original_Gini_246  -7.4928571428571429e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_6    OBJ       -1.4894801761822217e-02
    x_34_6    product_lb_54  -2.6035209521422013e-02
    x_34_6    product_ub_55  -4.4376353742978512e-02
    x_34_6    onehot_34_74  1
    x_34_6    stock_lb_186  6
    x_34_6    stock_ub_187  6
    x_34_6    parent_nonstrict_scope_188  1.4894801761822217e-02
    x_34_6    unique_nonzero_owner_268  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_6    product_lb_54  1
    w_34_6    product_ub_55  1
    w_34_6    normalized_mass_34_75  1
    w_34_6    normalized_ratio_34_76  -0.75
    w_34_6    full_original_Gini_246  -4.85595238095238
    MARKER    'MARKER'                 'INTORG'
    x_34_7    OBJ       -2.2342202642733327e-02
    x_34_7    product_lb_56  -2.6035209521422013e-02
    x_34_7    product_ub_57  -4.4376353742978512e-02
    x_34_7    onehot_34_74  1
    x_34_7    stock_lb_186  7
    x_34_7    stock_ub_187  7
    x_34_7    parent_nonstrict_scope_188  7.4474008809111087e-03
    x_34_7    unique_nonzero_owner_269  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_7    product_lb_56  1
    w_34_7    product_ub_57  1
    w_34_7    normalized_mass_34_75  1
    w_34_7    normalized_ratio_34_76  -0.875
    w_34_7    full_original_Gini_246  -4.3404761904761910e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_8    OBJ       -2.9789603523644435e-02
    x_34_8    product_lb_58  -2.6035209521422013e-02
    x_34_8    product_ub_59  -4.4376353742978512e-02
    x_34_8    onehot_34_74  1
    x_34_8    stock_lb_186  8
    x_34_8    stock_ub_187  8
    x_34_8    unique_nonzero_owner_270  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_8    product_lb_58  1
    w_34_8    product_ub_59  1
    w_34_8    normalized_mass_34_75  1
    w_34_8    normalized_ratio_34_76  -1
    w_34_8    full_original_Gini_246  -5.4654761904761910e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_9    OBJ       -2.2342202642733327e-02
    x_34_9    product_lb_60  -2.6035209521422013e-02
    x_34_9    product_ub_61  -4.4376353742978512e-02
    x_34_9    onehot_34_74  1
    x_34_9    stock_lb_186  9
    x_34_9    stock_ub_187  9
    x_34_9    parent_nonstrict_scope_188  7.4474008809111087e-03
    x_34_9    unique_nonzero_owner_271  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_9    product_lb_60  1
    w_34_9    product_ub_61  1
    w_34_9    normalized_mass_34_75  1
    w_34_9    normalized_ratio_34_76  -1.125
    w_34_9    full_original_Gini_246  -8.59047619047619
    MARKER    'MARKER'                 'INTORG'
    x_34_10   OBJ       -1.4894801761822217e-02
    x_34_10   product_lb_62  -2.6035209521422013e-02
    x_34_10   product_ub_63  -4.4376353742978512e-02
    x_34_10   onehot_34_74  1
    x_34_10   stock_lb_186  10
    x_34_10   stock_ub_187  10
    x_34_10   parent_nonstrict_scope_188  1.4894801761822217e-02
    x_34_10   unique_nonzero_owner_272  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_10   product_lb_62  1
    w_34_10   product_ub_63  1
    w_34_10   normalized_mass_34_75  1
    w_34_10   normalized_ratio_34_76  -1.25
    w_34_10   full_original_Gini_246  -1.1715476190476190e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_11   OBJ       -7.4474008809111078e-03
    x_34_11   product_lb_64  -2.6035209521422013e-02
    x_34_11   product_ub_65  -4.4376353742978512e-02
    x_34_11   onehot_34_74  1
    x_34_11   stock_lb_186  11
    x_34_11   stock_ub_187  11
    x_34_11   parent_nonstrict_scope_188  2.2342202642733327e-02
    x_34_11   unique_nonzero_owner_273  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_11   product_lb_64  1
    w_34_11   product_ub_65  1
    w_34_11   normalized_mass_34_75  1
    w_34_11   normalized_ratio_34_76  -1.375
    w_34_11   full_original_Gini_246  -1.4840476190476190e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_12   product_lb_66  -2.6035209521422013e-02
    x_34_12   product_ub_67  -4.4376353742978512e-02
    x_34_12   onehot_34_74  1
    x_34_12   stock_lb_186  12
    x_34_12   stock_ub_187  12
    x_34_12   parent_nonstrict_scope_188  2.9789603523644435e-02
    x_34_12   unique_nonzero_owner_274  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_12   product_lb_66  1
    w_34_12   product_ub_67  1
    w_34_12   normalized_mass_34_75  1
    w_34_12   normalized_ratio_34_76  -1.5
    w_34_12   full_original_Gini_246  -1.7965476190476188e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_13   OBJ       7.4474008809111113e-03
    x_34_13   product_lb_68  -2.6035209521422013e-02
    x_34_13   product_ub_69  -4.4376353742978512e-02
    x_34_13   onehot_34_74  1
    x_34_13   stock_lb_186  13
    x_34_13   stock_ub_187  13
    x_34_13   parent_nonstrict_scope_188  3.7237004404555546e-02
    x_34_13   unique_nonzero_owner_275  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_13   product_lb_68  1
    w_34_13   product_ub_69  1
    w_34_13   normalized_mass_34_75  1
    w_34_13   normalized_ratio_34_76  -1.625
    w_34_13   full_original_Gini_246  -2.1340476190476188e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_14   OBJ       1.4894801761822219e-02
    x_34_14   product_lb_70  -2.6035209521422013e-02
    x_34_14   product_ub_71  -4.4376353742978512e-02
    x_34_14   onehot_34_74  1
    x_34_14   stock_lb_186  14
    x_34_14   stock_ub_187  14
    x_34_14   parent_nonstrict_scope_188  4.4684405285466654e-02
    x_34_14   unique_nonzero_owner_276  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_14   product_lb_70  1
    w_34_14   product_ub_71  1
    w_34_14   normalized_mass_34_75  1
    w_34_14   normalized_ratio_34_76  -1.75
    w_34_14   full_original_Gini_246  -2.4715476190476192e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_15   OBJ       2.2342202642733327e-02
    x_34_15   product_lb_72  -2.6035209521422013e-02
    x_34_15   product_ub_73  -4.4376353742978512e-02
    x_34_15   onehot_34_74  1
    x_34_15   stock_lb_186  15
    x_34_15   stock_ub_187  15
    x_34_15   parent_nonstrict_scope_188  5.2131806166377762e-02
    x_34_15   unique_nonzero_owner_277  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_15   product_lb_72  1
    w_34_15   product_ub_73  1
    w_34_15   normalized_mass_34_75  1
    w_34_15   normalized_ratio_34_76  -1.875
    w_34_15   full_original_Gini_246  -2.8090476190476188e+01
    rho_34    normalized_ratio_34_76  1
    rho_34    block_pair_pos_213  1
    rho_34    block_pair_neg_214  -1
    rho_34    block_pair_pos_225  1
    rho_34    block_pair_neg_226  -1
    rho_34    block_pair_pos_235  -1
    rho_34    block_pair_neg_236  1
    rho_34    block_pair_pos_237  -1
    rho_34    block_pair_neg_238  1
    rho_34    block_pair_pos_239  -1
    rho_34    block_pair_neg_240  1
    rho_34    block_pair_pos_241  -1
    rho_34    block_pair_neg_242  1
    rho_34    block_pair_pos_243  -1
    rho_34    block_pair_neg_244  1
    rho_34    normalization_245  1
    MARKER    'MARKER'                 'INTORG'
    x_19_0    OBJ       1.1636571534741636e-02
    x_19_0    product_lb_77  -2.6035209521422013e-02
    x_19_0    product_ub_78  -4.4376353742978512e-02
    x_19_0    onehot_19_99  1
    x_19_0    parent_nonstrict_scope_188  2.3273143069483273e-02
    x_19_0    unique_nonzero_owner_278  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_0    product_lb_77  1
    w_19_0    product_ub_78  1
    w_19_0    normalized_mass_19_100  1
    w_19_0    full_original_Gini_246  -2.2534523809523808e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_1    OBJ       6.9819429208449833e-03
    x_19_1    product_lb_79  -2.6035209521422013e-02
    x_19_1    product_ub_80  -4.4376353742978512e-02
    x_19_1    onehot_19_99  1
    x_19_1    stock_lb_186  1
    x_19_1    stock_ub_187  1
    x_19_1    parent_nonstrict_scope_188  1.8618514455586620e-02
    MARKER    'MARKER'                 'INTEND'
    w_19_1    product_lb_79  1
    w_19_1    product_ub_80  1
    w_19_1    normalized_mass_19_100  1
    w_19_1    normalized_ratio_19_101  -0.2
    w_19_1    full_original_Gini_246  -1.7534523809523815e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_2    OBJ       2.3273143069483266e-03
    x_19_2    product_lb_81  -2.6035209521422013e-02
    x_19_2    product_ub_82  -4.4376353742978512e-02
    x_19_2    onehot_19_99  1
    x_19_2    stock_lb_186  2
    x_19_2    stock_ub_187  2
    x_19_2    parent_nonstrict_scope_188  1.3963885841689963e-02
    x_19_2    unique_nonzero_owner_279  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_2    product_lb_81  1
    w_19_2    product_ub_82  1
    w_19_2    normalized_mass_19_100  1
    w_19_2    normalized_ratio_19_101  -0.4
    w_19_2    full_original_Gini_246  -1.2667857142857141e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_3    OBJ       -0.00232731430694833
    x_19_3    product_lb_83  -2.6035209521422013e-02
    x_19_3    product_ub_84  -4.4376353742978512e-02
    x_19_3    onehot_19_99  1
    x_19_3    stock_lb_186  3
    x_19_3    stock_ub_187  3
    x_19_3    parent_nonstrict_scope_188  9.3092572277933064e-03
    x_19_3    unique_nonzero_owner_280  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_3    product_lb_83  1
    w_19_3    product_ub_84  1
    w_19_3    normalized_mass_19_100  1
    w_19_3    normalized_ratio_19_101  -6.0000000000000009e-01
    w_19_3    full_original_Gini_246  -8.0678571428571431e+00
    MARKER    'MARKER'                 'INTORG'
    x_19_4    OBJ       -6.9819429208449833e-03
    x_19_4    product_lb_85  -2.6035209521422013e-02
    x_19_4    product_ub_86  -4.4376353742978512e-02
    x_19_4    onehot_19_99  1
    x_19_4    stock_lb_186  4
    x_19_4    stock_ub_187  4
    x_19_4    parent_nonstrict_scope_188  4.6546286138966532e-03
    x_19_4    unique_nonzero_owner_281  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_4    product_lb_85  1
    w_19_4    product_ub_86  1
    w_19_4    normalized_mass_19_100  1
    w_19_4    normalized_ratio_19_101  -0.8
    w_19_4    full_original_Gini_246  -4.40595238095238
    MARKER    'MARKER'                 'INTORG'
    x_19_5    OBJ       -1.1636571534741636e-02
    x_19_5    product_lb_87  -2.6035209521422013e-02
    x_19_5    product_ub_88  -4.4376353742978512e-02
    x_19_5    onehot_19_99  1
    x_19_5    stock_lb_186  5
    x_19_5    stock_ub_187  5
    x_19_5    unique_nonzero_owner_282  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_5    product_lb_87  1
    w_19_5    product_ub_88  1
    w_19_5    normalized_mass_19_100  1
    w_19_5    normalized_ratio_19_101  -1
    w_19_5    full_original_Gini_246  -5.4654761904761910e+00
    MARKER    'MARKER'                 'INTORG'
    x_19_6    OBJ       -6.9819429208449781e-03
    x_19_6    product_lb_89  -2.6035209521422013e-02
    x_19_6    product_ub_90  -4.4376353742978512e-02
    x_19_6    onehot_19_99  1
    x_19_6    stock_lb_186  6
    x_19_6    stock_ub_187  6
    x_19_6    parent_nonstrict_scope_188  4.6546286138966584e-03
    x_19_6    unique_nonzero_owner_283  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_6    product_lb_89  1
    w_19_6    product_ub_90  1
    w_19_6    normalized_mass_19_100  1
    w_19_6    normalized_ratio_19_101  -1.2000000000000002e+00
    w_19_6    full_original_Gini_246  -1.0465476190476192e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_7    OBJ       -2.3273143069483249e-03
    x_19_7    product_lb_91  -2.6035209521422013e-02
    x_19_7    product_ub_92  -4.4376353742978512e-02
    x_19_7    onehot_19_99  1
    x_19_7    stock_lb_186  7
    x_19_7    stock_ub_187  7
    x_19_7    parent_nonstrict_scope_188  9.3092572277933116e-03
    x_19_7    unique_nonzero_owner_284  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_7    product_lb_91  1
    w_19_7    product_ub_92  1
    w_19_7    normalized_mass_19_100  1
    w_19_7    normalized_ratio_19_101  -1.4000000000000001e+00
    w_19_7    full_original_Gini_246  -1.5465476190476195e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_8    OBJ       0.00232731430694833
    x_19_8    product_lb_93  -2.6035209521422013e-02
    x_19_8    product_ub_94  -4.4376353742978512e-02
    x_19_8    onehot_19_99  1
    x_19_8    stock_lb_186  8
    x_19_8    stock_ub_187  8
    x_19_8    parent_nonstrict_scope_188  1.3963885841689967e-02
    x_19_8    unique_nonzero_owner_285  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_8    product_lb_93  1
    w_19_8    product_ub_94  1
    w_19_8    normalized_mass_19_100  1
    w_19_8    normalized_ratio_19_101  -1.6
    w_19_8    full_original_Gini_246  -2.0665476190476195e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_9    OBJ       6.9819429208449833e-03
    x_19_9    product_lb_95  -2.6035209521422013e-02
    x_19_9    product_ub_96  -4.4376353742978512e-02
    x_19_9    onehot_19_99  1
    x_19_9    stock_lb_186  9
    x_19_9    stock_ub_187  9
    x_19_9    parent_nonstrict_scope_188  1.8618514455586620e-02
    x_19_9    unique_nonzero_owner_286  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_9    product_lb_95  1
    w_19_9    product_ub_96  1
    w_19_9    normalized_mass_19_100  1
    w_19_9    normalized_ratio_19_101  -1.8
    w_19_9    full_original_Gini_246  -26.0654761904762
    MARKER    'MARKER'                 'INTORG'
    x_19_10   OBJ       1.1636571534741636e-02
    x_19_10   product_lb_97  -2.6035209521422013e-02
    x_19_10   product_ub_98  -4.4376353742978512e-02
    x_19_10   onehot_19_99  1
    x_19_10   stock_lb_186  10
    x_19_10   stock_ub_187  10
    x_19_10   parent_nonstrict_scope_188  2.3273143069483273e-02
    x_19_10   unique_nonzero_owner_287  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_10   product_lb_97  1
    w_19_10   product_ub_98  1
    w_19_10   normalized_mass_19_100  1
    w_19_10   normalized_ratio_19_101  -2
    w_19_10   full_original_Gini_246  -3.1465476190476185e+01
    rho_19    normalized_ratio_19_101  1
    rho_19    block_pair_pos_193  -1
    rho_19    block_pair_neg_194  1
    rho_19    block_pair_pos_195  -1
    rho_19    block_pair_neg_196  1
    rho_19    block_pair_pos_197  -1
    rho_19    block_pair_neg_198  1
    rho_19    block_pair_pos_199  -1
    rho_19    block_pair_neg_200  1
    rho_19    block_pair_pos_205  1
    rho_19    block_pair_neg_206  -1
    rho_19    block_pair_pos_219  1
    rho_19    block_pair_neg_220  -1
    rho_19    block_pair_pos_239  1
    rho_19    block_pair_neg_240  -1
    rho_19    normalization_245  1
    MARKER    'MARKER'                 'INTORG'
    x_29_0    OBJ       1.1636571534741636e-02
    x_29_0    product_lb_102  -2.6035209521422013e-02
    x_29_0    product_ub_103  -4.4376353742978512e-02
    x_29_0    onehot_29_124  1
    x_29_0    parent_nonstrict_scope_188  2.3273143069483273e-02
    x_29_0    unique_nonzero_owner_288  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_0    product_lb_102  1
    w_29_0    product_ub_103  1
    w_29_0    normalized_mass_29_125  1
    w_29_0    full_original_Gini_246  -2.2534523809523808e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_1    OBJ       6.9819429208449833e-03
    x_29_1    product_lb_104  -2.6035209521422013e-02
    x_29_1    product_ub_105  -4.4376353742978512e-02
    x_29_1    onehot_29_124  1
    x_29_1    stock_lb_186  1
    x_29_1    stock_ub_187  1
    x_29_1    parent_nonstrict_scope_188  1.8618514455586620e-02
    MARKER    'MARKER'                 'INTEND'
    w_29_1    product_lb_104  1
    w_29_1    product_ub_105  1
    w_29_1    normalized_mass_29_125  1
    w_29_1    normalized_ratio_29_126  -0.2
    w_29_1    full_original_Gini_246  -1.7534523809523815e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_2    OBJ       2.3273143069483266e-03
    x_29_2    product_lb_106  -2.6035209521422013e-02
    x_29_2    product_ub_107  -4.4376353742978512e-02
    x_29_2    onehot_29_124  1
    x_29_2    stock_lb_186  2
    x_29_2    stock_ub_187  2
    x_29_2    parent_nonstrict_scope_188  1.3963885841689963e-02
    x_29_2    unique_nonzero_owner_289  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_2    product_lb_106  1
    w_29_2    product_ub_107  1
    w_29_2    normalized_mass_29_125  1
    w_29_2    normalized_ratio_29_126  -0.4
    w_29_2    full_original_Gini_246  -1.2667857142857141e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_3    OBJ       -0.00232731430694833
    x_29_3    product_lb_108  -2.6035209521422013e-02
    x_29_3    product_ub_109  -4.4376353742978512e-02
    x_29_3    onehot_29_124  1
    x_29_3    stock_lb_186  3
    x_29_3    stock_ub_187  3
    x_29_3    parent_nonstrict_scope_188  9.3092572277933064e-03
    x_29_3    unique_nonzero_owner_290  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_3    product_lb_108  1
    w_29_3    product_ub_109  1
    w_29_3    normalized_mass_29_125  1
    w_29_3    normalized_ratio_29_126  -6.0000000000000009e-01
    w_29_3    full_original_Gini_246  -8.0678571428571431e+00
    MARKER    'MARKER'                 'INTORG'
    x_29_4    OBJ       -6.9819429208449833e-03
    x_29_4    product_lb_110  -2.6035209521422013e-02
    x_29_4    product_ub_111  -4.4376353742978512e-02
    x_29_4    onehot_29_124  1
    x_29_4    stock_lb_186  4
    x_29_4    stock_ub_187  4
    x_29_4    parent_nonstrict_scope_188  4.6546286138966532e-03
    x_29_4    unique_nonzero_owner_291  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_4    product_lb_110  1
    w_29_4    product_ub_111  1
    w_29_4    normalized_mass_29_125  1
    w_29_4    normalized_ratio_29_126  -0.8
    w_29_4    full_original_Gini_246  -4.40595238095238
    MARKER    'MARKER'                 'INTORG'
    x_29_5    OBJ       -1.1636571534741636e-02
    x_29_5    product_lb_112  -2.6035209521422013e-02
    x_29_5    product_ub_113  -4.4376353742978512e-02
    x_29_5    onehot_29_124  1
    x_29_5    stock_lb_186  5
    x_29_5    stock_ub_187  5
    x_29_5    unique_nonzero_owner_292  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_5    product_lb_112  1
    w_29_5    product_ub_113  1
    w_29_5    normalized_mass_29_125  1
    w_29_5    normalized_ratio_29_126  -1
    w_29_5    full_original_Gini_246  -5.4654761904761910e+00
    MARKER    'MARKER'                 'INTORG'
    x_29_6    OBJ       -6.9819429208449781e-03
    x_29_6    product_lb_114  -2.6035209521422013e-02
    x_29_6    product_ub_115  -4.4376353742978512e-02
    x_29_6    onehot_29_124  1
    x_29_6    stock_lb_186  6
    x_29_6    stock_ub_187  6
    x_29_6    parent_nonstrict_scope_188  4.6546286138966584e-03
    x_29_6    unique_nonzero_owner_293  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_6    product_lb_114  1
    w_29_6    product_ub_115  1
    w_29_6    normalized_mass_29_125  1
    w_29_6    normalized_ratio_29_126  -1.2000000000000002e+00
    w_29_6    full_original_Gini_246  -1.0465476190476192e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_7    OBJ       -2.3273143069483249e-03
    x_29_7    product_lb_116  -2.6035209521422013e-02
    x_29_7    product_ub_117  -4.4376353742978512e-02
    x_29_7    onehot_29_124  1
    x_29_7    stock_lb_186  7
    x_29_7    stock_ub_187  7
    x_29_7    parent_nonstrict_scope_188  9.3092572277933116e-03
    x_29_7    unique_nonzero_owner_294  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_7    product_lb_116  1
    w_29_7    product_ub_117  1
    w_29_7    normalized_mass_29_125  1
    w_29_7    normalized_ratio_29_126  -1.4000000000000001e+00
    w_29_7    full_original_Gini_246  -1.5465476190476195e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_8    OBJ       0.00232731430694833
    x_29_8    product_lb_118  -2.6035209521422013e-02
    x_29_8    product_ub_119  -4.4376353742978512e-02
    x_29_8    onehot_29_124  1
    x_29_8    stock_lb_186  8
    x_29_8    stock_ub_187  8
    x_29_8    parent_nonstrict_scope_188  1.3963885841689967e-02
    x_29_8    unique_nonzero_owner_295  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_8    product_lb_118  1
    w_29_8    product_ub_119  1
    w_29_8    normalized_mass_29_125  1
    w_29_8    normalized_ratio_29_126  -1.6
    w_29_8    full_original_Gini_246  -2.0665476190476195e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_9    OBJ       6.9819429208449833e-03
    x_29_9    product_lb_120  -2.6035209521422013e-02
    x_29_9    product_ub_121  -4.4376353742978512e-02
    x_29_9    onehot_29_124  1
    x_29_9    stock_lb_186  9
    x_29_9    stock_ub_187  9
    x_29_9    parent_nonstrict_scope_188  1.8618514455586620e-02
    x_29_9    unique_nonzero_owner_296  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_9    product_lb_120  1
    w_29_9    product_ub_121  1
    w_29_9    normalized_mass_29_125  1
    w_29_9    normalized_ratio_29_126  -1.8
    w_29_9    full_original_Gini_246  -26.0654761904762
    MARKER    'MARKER'                 'INTORG'
    x_29_10   OBJ       1.1636571534741636e-02
    x_29_10   product_lb_122  -2.6035209521422013e-02
    x_29_10   product_ub_123  -4.4376353742978512e-02
    x_29_10   onehot_29_124  1
    x_29_10   stock_lb_186  10
    x_29_10   stock_ub_187  10
    x_29_10   parent_nonstrict_scope_188  2.3273143069483273e-02
    x_29_10   unique_nonzero_owner_297  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_10   product_lb_122  1
    w_29_10   product_ub_123  1
    w_29_10   normalized_mass_29_125  1
    w_29_10   normalized_ratio_29_126  -2
    w_29_10   full_original_Gini_246  -3.1465476190476185e+01
    rho_29    normalized_ratio_29_126  1
    rho_29    block_pair_pos_199  1
    rho_29    block_pair_neg_200  -1
    rho_29    block_pair_pos_211  1
    rho_29    block_pair_neg_212  -1
    rho_29    block_pair_pos_223  1
    rho_29    block_pair_neg_224  -1
    rho_29    block_pair_pos_229  -1
    rho_29    block_pair_neg_230  1
    rho_29    block_pair_pos_231  -1
    rho_29    block_pair_neg_232  1
    rho_29    block_pair_pos_233  -1
    rho_29    block_pair_neg_234  1
    rho_29    block_pair_pos_243  1
    rho_29    block_pair_neg_244  -1
    rho_29    normalization_245  1
    MARKER    'MARKER'                 'INTORG'
    x_18_0    OBJ       1.1636571534741636e-02
    x_18_0    product_lb_127  -2.6035209521422013e-02
    x_18_0    product_ub_128  -4.4376353742978512e-02
    x_18_0    onehot_18_149  1
    x_18_0    parent_nonstrict_scope_188  2.3273143069483273e-02
    x_18_0    unique_nonzero_owner_298  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_0    product_lb_127  1
    w_18_0    product_ub_128  1
    w_18_0    normalized_mass_18_150  1
    w_18_0    full_original_Gini_246  -2.2534523809523808e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_1    OBJ       6.9819429208449833e-03
    x_18_1    product_lb_129  -2.6035209521422013e-02
    x_18_1    product_ub_130  -4.4376353742978512e-02
    x_18_1    onehot_18_149  1
    x_18_1    stock_lb_186  1
    x_18_1    stock_ub_187  1
    x_18_1    parent_nonstrict_scope_188  1.8618514455586620e-02
    x_18_1    unique_nonzero_owner_299  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_1    product_lb_129  1
    w_18_1    product_ub_130  1
    w_18_1    normalized_mass_18_150  1
    w_18_1    normalized_ratio_18_151  -0.2
    w_18_1    full_original_Gini_246  -1.7534523809523815e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_2    OBJ       2.3273143069483266e-03
    x_18_2    product_lb_131  -2.6035209521422013e-02
    x_18_2    product_ub_132  -4.4376353742978512e-02
    x_18_2    onehot_18_149  1
    x_18_2    stock_lb_186  2
    x_18_2    stock_ub_187  2
    x_18_2    parent_nonstrict_scope_188  1.3963885841689963e-02
    x_18_2    unique_nonzero_owner_300  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_2    product_lb_131  1
    w_18_2    product_ub_132  1
    w_18_2    normalized_mass_18_150  1
    w_18_2    normalized_ratio_18_151  -0.4
    w_18_2    full_original_Gini_246  -1.2667857142857141e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_3    OBJ       -0.00232731430694833
    x_18_3    product_lb_133  -2.6035209521422013e-02
    x_18_3    product_ub_134  -4.4376353742978512e-02
    x_18_3    onehot_18_149  1
    x_18_3    stock_lb_186  3
    x_18_3    stock_ub_187  3
    x_18_3    parent_nonstrict_scope_188  9.3092572277933064e-03
    x_18_3    unique_nonzero_owner_301  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_3    product_lb_133  1
    w_18_3    product_ub_134  1
    w_18_3    normalized_mass_18_150  1
    w_18_3    normalized_ratio_18_151  -6.0000000000000009e-01
    w_18_3    full_original_Gini_246  -8.0678571428571431e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_4    OBJ       -6.9819429208449833e-03
    x_18_4    product_lb_135  -2.6035209521422013e-02
    x_18_4    product_ub_136  -4.4376353742978512e-02
    x_18_4    onehot_18_149  1
    x_18_4    stock_lb_186  4
    x_18_4    stock_ub_187  4
    x_18_4    parent_nonstrict_scope_188  4.6546286138966532e-03
    x_18_4    unique_nonzero_owner_302  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_4    product_lb_135  1
    w_18_4    product_ub_136  1
    w_18_4    normalized_mass_18_150  1
    w_18_4    normalized_ratio_18_151  -0.8
    w_18_4    full_original_Gini_246  -4.40595238095238
    MARKER    'MARKER'                 'INTORG'
    x_18_5    OBJ       -1.1636571534741636e-02
    x_18_5    product_lb_137  -2.6035209521422013e-02
    x_18_5    product_ub_138  -4.4376353742978512e-02
    x_18_5    onehot_18_149  1
    x_18_5    stock_lb_186  5
    x_18_5    stock_ub_187  5
    x_18_5    unique_nonzero_owner_303  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_5    product_lb_137  1
    w_18_5    product_ub_138  1
    w_18_5    normalized_mass_18_150  1
    w_18_5    normalized_ratio_18_151  -1
    w_18_5    full_original_Gini_246  -5.4654761904761910e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_6    OBJ       -6.9819429208449781e-03
    x_18_6    product_lb_139  -2.6035209521422013e-02
    x_18_6    product_ub_140  -4.4376353742978512e-02
    x_18_6    onehot_18_149  1
    x_18_6    stock_lb_186  6
    x_18_6    stock_ub_187  6
    x_18_6    parent_nonstrict_scope_188  4.6546286138966584e-03
    x_18_6    unique_nonzero_owner_304  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_6    product_lb_139  1
    w_18_6    product_ub_140  1
    w_18_6    normalized_mass_18_150  1
    w_18_6    normalized_ratio_18_151  -1.2000000000000002e+00
    w_18_6    full_original_Gini_246  -1.0465476190476192e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_7    OBJ       -2.3273143069483249e-03
    x_18_7    product_lb_141  -2.6035209521422013e-02
    x_18_7    product_ub_142  -4.4376353742978512e-02
    x_18_7    onehot_18_149  1
    x_18_7    stock_lb_186  7
    x_18_7    stock_ub_187  7
    x_18_7    parent_nonstrict_scope_188  9.3092572277933116e-03
    x_18_7    unique_nonzero_owner_305  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_7    product_lb_141  1
    w_18_7    product_ub_142  1
    w_18_7    normalized_mass_18_150  1
    w_18_7    normalized_ratio_18_151  -1.4000000000000001e+00
    w_18_7    full_original_Gini_246  -1.5465476190476195e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_8    OBJ       0.00232731430694833
    x_18_8    product_lb_143  -2.6035209521422013e-02
    x_18_8    product_ub_144  -4.4376353742978512e-02
    x_18_8    onehot_18_149  1
    x_18_8    stock_lb_186  8
    x_18_8    stock_ub_187  8
    x_18_8    parent_nonstrict_scope_188  1.3963885841689967e-02
    MARKER    'MARKER'                 'INTEND'
    w_18_8    product_lb_143  1
    w_18_8    product_ub_144  1
    w_18_8    normalized_mass_18_150  1
    w_18_8    normalized_ratio_18_151  -1.6
    w_18_8    full_original_Gini_246  -2.0665476190476195e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_9    OBJ       6.9819429208449833e-03
    x_18_9    product_lb_145  -2.6035209521422013e-02
    x_18_9    product_ub_146  -4.4376353742978512e-02
    x_18_9    onehot_18_149  1
    x_18_9    stock_lb_186  9
    x_18_9    stock_ub_187  9
    x_18_9    parent_nonstrict_scope_188  1.8618514455586620e-02
    x_18_9    unique_nonzero_owner_306  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_9    product_lb_145  1
    w_18_9    product_ub_146  1
    w_18_9    normalized_mass_18_150  1
    w_18_9    normalized_ratio_18_151  -1.8
    w_18_9    full_original_Gini_246  -26.0654761904762
    MARKER    'MARKER'                 'INTORG'
    x_18_10   OBJ       1.1636571534741636e-02
    x_18_10   product_lb_147  -2.6035209521422013e-02
    x_18_10   product_ub_148  -4.4376353742978512e-02
    x_18_10   onehot_18_149  1
    x_18_10   stock_lb_186  10
    x_18_10   stock_ub_187  10
    x_18_10   parent_nonstrict_scope_188  2.3273143069483273e-02
    x_18_10   unique_nonzero_owner_307  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_10   product_lb_147  1
    w_18_10   product_ub_148  1
    w_18_10   normalized_mass_18_150  1
    w_18_10   normalized_ratio_18_151  -2
    w_18_10   full_original_Gini_246  -3.1465476190476185e+01
    rho_18    normalized_ratio_18_151  1
    rho_18    block_pair_pos_189  -1
    rho_18    block_pair_neg_190  1
    rho_18    block_pair_pos_191  -1
    rho_18    block_pair_neg_192  1
    rho_18    block_pair_pos_195  1
    rho_18    block_pair_neg_196  -1
    rho_18    block_pair_pos_203  1
    rho_18    block_pair_neg_204  -1
    rho_18    block_pair_pos_217  1
    rho_18    block_pair_neg_218  -1
    rho_18    block_pair_pos_231  1
    rho_18    block_pair_neg_232  -1
    rho_18    block_pair_pos_237  1
    rho_18    block_pair_neg_238  -1
    rho_18    normalization_245  1
    MARKER    'MARKER'                 'INTORG'
    x_27_0    OBJ       4.1891612282083379e-03
    x_27_0    product_lb_152  -2.6035209521422013e-02
    x_27_0    product_ub_153  -4.4376353742978512e-02
    x_27_0    onehot_27_166  1
    x_27_0    parent_nonstrict_scope_188  8.3783224564166758e-03
    MARKER    'MARKER'                 'INTEND'
    w_27_0    product_lb_152  1
    w_27_0    product_ub_153  1
    w_27_0    normalized_mass_27_167  1
    w_27_0    full_original_Gini_246  -2.2534523809523808e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_1    OBJ       1.3963870760694466e-03
    x_27_1    product_lb_154  -2.6035209521422013e-02
    x_27_1    product_ub_155  -4.4376353742978512e-02
    x_27_1    onehot_27_166  1
    x_27_1    stock_lb_186  1
    x_27_1    stock_ub_187  1
    x_27_1    parent_nonstrict_scope_188  5.5855483042777845e-03
    x_27_1    unique_nonzero_owner_308  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_1    product_lb_154  1
    w_27_1    product_ub_155  1
    w_27_1    normalized_mass_27_167  1
    w_27_1    normalized_ratio_27_168  -3.3333333333333331e-01
    w_27_1    full_original_Gini_246  -1.4201190476190474e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_2    OBJ       -1.3963870760694457e-03
    x_27_2    product_lb_156  -2.6035209521422013e-02
    x_27_2    product_ub_157  -4.4376353742978512e-02
    x_27_2    onehot_27_166  1
    x_27_2    stock_lb_186  2
    x_27_2    stock_ub_187  2
    x_27_2    parent_nonstrict_scope_188  2.7927741521388922e-03
    x_27_2    unique_nonzero_owner_309  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_2    product_lb_156  1
    w_27_2    product_ub_157  1
    w_27_2    normalized_mass_27_167  1
    w_27_2    normalized_ratio_27_168  -6.6666666666666663e-01
    w_27_2    full_original_Gini_246  -6.5345238095238081e+00
    MARKER    'MARKER'                 'INTORG'
    x_27_3    OBJ       -4.1891612282083379e-03
    x_27_3    product_lb_158  -2.6035209521422013e-02
    x_27_3    product_ub_159  -4.4376353742978512e-02
    x_27_3    onehot_27_166  1
    x_27_3    stock_lb_186  3
    x_27_3    stock_ub_187  3
    x_27_3    unique_nonzero_owner_310  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_3    product_lb_158  1
    w_27_3    product_ub_159  1
    w_27_3    normalized_mass_27_167  1
    w_27_3    normalized_ratio_27_168  -1
    w_27_3    full_original_Gini_246  -5.4654761904761910e+00
    MARKER    'MARKER'                 'INTORG'
    x_27_4    OBJ       -1.3963870760694466e-03
    x_27_4    product_lb_160  -2.6035209521422013e-02
    x_27_4    product_ub_161  -4.4376353742978512e-02
    x_27_4    onehot_27_166  1
    x_27_4    stock_lb_186  4
    x_27_4    stock_ub_187  4
    x_27_4    parent_nonstrict_scope_188  2.7927741521388914e-03
    x_27_4    unique_nonzero_owner_311  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_4    product_lb_160  1
    w_27_4    product_ub_161  1
    w_27_4    normalized_mass_27_167  1
    w_27_4    normalized_ratio_27_168  -1.3333333333333333e+00
    w_27_4    full_original_Gini_246  -1.3798809523809524e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_5    OBJ       1.3963870760694448e-03
    x_27_5    product_lb_162  -2.6035209521422013e-02
    x_27_5    product_ub_163  -4.4376353742978512e-02
    x_27_5    onehot_27_166  1
    x_27_5    stock_lb_186  5
    x_27_5    stock_ub_187  5
    x_27_5    parent_nonstrict_scope_188  5.5855483042777827e-03
    x_27_5    unique_nonzero_owner_312  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_5    product_lb_162  1
    w_27_5    product_ub_163  1
    w_27_5    normalized_mass_27_167  1
    w_27_5    normalized_ratio_27_168  -1.6666666666666665e+00
    w_27_5    full_original_Gini_246  -2.2465476190476188e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_6    OBJ       4.1891612282083379e-03
    x_27_6    product_lb_164  -2.6035209521422013e-02
    x_27_6    product_ub_165  -4.4376353742978512e-02
    x_27_6    onehot_27_166  1
    x_27_6    stock_lb_186  6
    x_27_6    stock_ub_187  6
    x_27_6    parent_nonstrict_scope_188  8.3783224564166758e-03
    x_27_6    unique_nonzero_owner_313  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_6    product_lb_164  1
    w_27_6    product_ub_165  1
    w_27_6    normalized_mass_27_167  1
    w_27_6    normalized_ratio_27_168  -2
    w_27_6    full_original_Gini_246  -3.1465476190476185e+01
    rho_27    normalized_ratio_27_168  1
    rho_27    block_pair_pos_191  1
    rho_27    block_pair_neg_192  -1
    rho_27    block_pair_pos_197  1
    rho_27    block_pair_neg_198  -1
    rho_27    block_pair_pos_209  1
    rho_27    block_pair_neg_210  -1
    rho_27    block_pair_pos_221  1
    rho_27    block_pair_neg_222  -1
    rho_27    block_pair_pos_227  -1
    rho_27    block_pair_neg_228  1
    rho_27    block_pair_pos_233  1
    rho_27    block_pair_neg_234  -1
    rho_27    block_pair_pos_241  1
    rho_27    block_pair_neg_242  -1
    rho_27    normalization_245  1
    MARKER    'MARKER'                 'INTORG'
    x_17_0    OBJ       4.1891612282083379e-03
    x_17_0    product_lb_169  -2.6035209521422013e-02
    x_17_0    product_ub_170  -4.4376353742978512e-02
    x_17_0    onehot_17_183  1
    x_17_0    parent_nonstrict_scope_188  8.3783224564166758e-03
    x_17_0    unique_nonzero_owner_314  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_0    product_lb_169  1
    w_17_0    product_ub_170  1
    w_17_0    normalized_mass_17_184  1
    w_17_0    full_original_Gini_246  -2.2534523809523808e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_1    OBJ       1.3963870760694466e-03
    x_17_1    product_lb_171  -2.6035209521422013e-02
    x_17_1    product_ub_172  -4.4376353742978512e-02
    x_17_1    onehot_17_183  1
    x_17_1    stock_lb_186  1
    x_17_1    stock_ub_187  1
    x_17_1    parent_nonstrict_scope_188  5.5855483042777845e-03
    x_17_1    unique_nonzero_owner_315  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_1    product_lb_171  1
    w_17_1    product_ub_172  1
    w_17_1    normalized_mass_17_184  1
    w_17_1    normalized_ratio_17_185  -3.3333333333333331e-01
    w_17_1    full_original_Gini_246  -1.4201190476190474e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_2    OBJ       -1.3963870760694457e-03
    x_17_2    product_lb_173  -2.6035209521422013e-02
    x_17_2    product_ub_174  -4.4376353742978512e-02
    x_17_2    onehot_17_183  1
    x_17_2    stock_lb_186  2
    x_17_2    stock_ub_187  2
    x_17_2    parent_nonstrict_scope_188  2.7927741521388922e-03
    x_17_2    unique_nonzero_owner_316  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_2    product_lb_173  1
    w_17_2    product_ub_174  1
    w_17_2    normalized_mass_17_184  1
    w_17_2    normalized_ratio_17_185  -6.6666666666666663e-01
    w_17_2    full_original_Gini_246  -6.5345238095238081e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_3    OBJ       -4.1891612282083379e-03
    x_17_3    product_lb_175  -2.6035209521422013e-02
    x_17_3    product_ub_176  -4.4376353742978512e-02
    x_17_3    onehot_17_183  1
    x_17_3    stock_lb_186  3
    x_17_3    stock_ub_187  3
    x_17_3    unique_nonzero_owner_317  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_3    product_lb_175  1
    w_17_3    product_ub_176  1
    w_17_3    normalized_mass_17_184  1
    w_17_3    normalized_ratio_17_185  -1
    w_17_3    full_original_Gini_246  -5.4654761904761910e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_4    OBJ       -1.3963870760694466e-03
    x_17_4    product_lb_177  -2.6035209521422013e-02
    x_17_4    product_ub_178  -4.4376353742978512e-02
    x_17_4    onehot_17_183  1
    x_17_4    stock_lb_186  4
    x_17_4    stock_ub_187  4
    x_17_4    parent_nonstrict_scope_188  2.7927741521388914e-03
    x_17_4    unique_nonzero_owner_318  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_4    product_lb_177  1
    w_17_4    product_ub_178  1
    w_17_4    normalized_mass_17_184  1
    w_17_4    normalized_ratio_17_185  -1.3333333333333333e+00
    w_17_4    full_original_Gini_246  -1.3798809523809524e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_5    OBJ       1.3963870760694448e-03
    x_17_5    product_lb_179  -2.6035209521422013e-02
    x_17_5    product_ub_180  -4.4376353742978512e-02
    x_17_5    onehot_17_183  1
    x_17_5    stock_lb_186  5
    x_17_5    stock_ub_187  5
    x_17_5    parent_nonstrict_scope_188  5.5855483042777827e-03
    MARKER    'MARKER'                 'INTEND'
    w_17_5    product_lb_179  1
    w_17_5    product_ub_180  1
    w_17_5    normalized_mass_17_184  1
    w_17_5    normalized_ratio_17_185  -1.6666666666666665e+00
    w_17_5    full_original_Gini_246  -2.2465476190476188e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_6    OBJ       4.1891612282083379e-03
    x_17_6    product_lb_181  -2.6035209521422013e-02
    x_17_6    product_ub_182  -4.4376353742978512e-02
    x_17_6    onehot_17_183  1
    x_17_6    stock_lb_186  6
    x_17_6    stock_ub_187  6
    x_17_6    parent_nonstrict_scope_188  8.3783224564166758e-03
    x_17_6    unique_nonzero_owner_319  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_6    product_lb_181  1
    w_17_6    product_ub_182  1
    w_17_6    normalized_mass_17_184  1
    w_17_6    normalized_ratio_17_185  -2
    w_17_6    full_original_Gini_246  -3.1465476190476185e+01
    rho_17    normalized_ratio_17_185  1
    rho_17    block_pair_pos_189  1
    rho_17    block_pair_neg_190  -1
    rho_17    block_pair_pos_193  1
    rho_17    block_pair_neg_194  -1
    rho_17    block_pair_pos_201  1
    rho_17    block_pair_neg_202  -1
    rho_17    block_pair_pos_215  1
    rho_17    block_pair_neg_216  -1
    rho_17    block_pair_pos_227  1
    rho_17    block_pair_neg_228  -1
    rho_17    block_pair_pos_229  1
    rho_17    block_pair_neg_230  -1
    rho_17    block_pair_pos_235  1
    rho_17    block_pair_neg_236  -1
    rho_17    normalization_245  1
    a_20_21   block_pair_pos_207  1
    a_20_21   block_pair_neg_208  1
    a_20_21   full_original_Gini_246  -1
    a_20_34   block_pair_pos_213  1
    a_20_34   block_pair_neg_214  1
    a_20_34   full_original_Gini_246  -1
    a_20_19   block_pair_pos_205  1
    a_20_19   block_pair_neg_206  1
    a_20_19   full_original_Gini_246  -1
    a_20_29   block_pair_pos_211  1
    a_20_29   block_pair_neg_212  1
    a_20_29   full_original_Gini_246  -1
    a_20_18   block_pair_pos_203  1
    a_20_18   block_pair_neg_204  1
    a_20_18   full_original_Gini_246  -1
    a_20_27   block_pair_pos_209  1
    a_20_27   block_pair_neg_210  1
    a_20_27   full_original_Gini_246  -1
    a_20_17   block_pair_pos_201  1
    a_20_17   block_pair_neg_202  1
    a_20_17   full_original_Gini_246  -1
    a_21_34   block_pair_pos_225  1
    a_21_34   block_pair_neg_226  1
    a_21_34   full_original_Gini_246  -1
    a_21_19   block_pair_pos_219  1
    a_21_19   block_pair_neg_220  1
    a_21_19   full_original_Gini_246  -1
    a_21_29   block_pair_pos_223  1
    a_21_29   block_pair_neg_224  1
    a_21_29   full_original_Gini_246  -1
    a_21_18   block_pair_pos_217  1
    a_21_18   block_pair_neg_218  1
    a_21_18   full_original_Gini_246  -1
    a_21_27   block_pair_pos_221  1
    a_21_27   block_pair_neg_222  1
    a_21_27   full_original_Gini_246  -1
    a_21_17   block_pair_pos_215  1
    a_21_17   block_pair_neg_216  1
    a_21_17   full_original_Gini_246  -1
    a_34_19   block_pair_pos_239  1
    a_34_19   block_pair_neg_240  1
    a_34_19   full_original_Gini_246  -1
    a_34_29   block_pair_pos_243  1
    a_34_29   block_pair_neg_244  1
    a_34_29   full_original_Gini_246  -1
    a_34_18   block_pair_pos_237  1
    a_34_18   block_pair_neg_238  1
    a_34_18   full_original_Gini_246  -1
    a_34_27   block_pair_pos_241  1
    a_34_27   block_pair_neg_242  1
    a_34_27   full_original_Gini_246  -1
    a_34_17   block_pair_pos_235  1
    a_34_17   block_pair_neg_236  1
    a_34_17   full_original_Gini_246  -1
    a_19_29   block_pair_pos_199  1
    a_19_29   block_pair_neg_200  1
    a_19_29   full_original_Gini_246  -1
    a_19_18   block_pair_pos_195  1
    a_19_18   block_pair_neg_196  1
    a_19_18   full_original_Gini_246  -1
    a_19_27   block_pair_pos_197  1
    a_19_27   block_pair_neg_198  1
    a_19_27   full_original_Gini_246  -1
    a_19_17   block_pair_pos_193  1
    a_19_17   block_pair_neg_194  1
    a_19_17   full_original_Gini_246  -1
    a_29_18   block_pair_pos_231  1
    a_29_18   block_pair_neg_232  1
    a_29_18   full_original_Gini_246  -1
    a_29_27   block_pair_pos_233  1
    a_29_27   block_pair_neg_234  1
    a_29_27   full_original_Gini_246  -1
    a_29_17   block_pair_pos_229  1
    a_29_17   block_pair_neg_230  1
    a_29_17   full_original_Gini_246  -1
    a_18_27   block_pair_pos_191  1
    a_18_27   block_pair_neg_192  1
    a_18_27   full_original_Gini_246  -1
    a_18_17   block_pair_pos_189  1
    a_18_17   block_pair_neg_190  1
    a_18_17   full_original_Gini_246  -1
    a_27_17   block_pair_pos_227  1
    a_27_17   block_pair_neg_228  1
    a_27_17   full_original_Gini_246  -1
    MARKER    'MARKER'                 'INTORG'
    service_0_20_0  unique_nonzero_owner_247  1
    service_0_20_0  service_visit_def_643  1
    service_0_20_0  free_load_conservation_644  -7
    service_0_20_0  original_T_including_depot_unload_690  840
    service_0_20_1  unique_nonzero_owner_248  1
    service_0_20_1  service_visit_def_643  1
    service_0_20_1  free_load_conservation_644  -6
    service_0_20_1  original_T_including_depot_unload_690  720
    service_0_20_2  unique_nonzero_owner_249  1
    service_0_20_2  service_visit_def_643  1
    service_0_20_2  free_load_conservation_644  -5
    service_0_20_2  original_T_including_depot_unload_690  600
    service_0_20_3  unique_nonzero_owner_250  1
    service_0_20_3  service_visit_def_643  1
    service_0_20_3  free_load_conservation_644  -4
    service_0_20_3  original_T_including_depot_unload_690  480
    service_0_20_4  unique_nonzero_owner_251  1
    service_0_20_4  service_visit_def_643  1
    service_0_20_4  free_load_conservation_644  -3
    service_0_20_4  original_T_including_depot_unload_690  360
    service_0_20_5  unique_nonzero_owner_252  1
    service_0_20_5  service_visit_def_643  1
    service_0_20_5  free_load_conservation_644  -2
    service_0_20_5  original_T_including_depot_unload_690  240
    service_0_20_6  unique_nonzero_owner_253  1
    service_0_20_6  service_visit_def_643  1
    service_0_20_6  free_load_conservation_644  -1
    service_0_20_6  original_T_including_depot_unload_690  120
    service_0_20_8  unique_nonzero_owner_254  1
    service_0_20_8  service_visit_def_643  1
    service_0_20_8  free_load_conservation_644  1
    service_0_20_9  unique_nonzero_owner_255  1
    service_0_20_9  service_visit_def_643  1
    service_0_20_9  free_load_conservation_644  2
    service_0_20_10  unique_nonzero_owner_256  1
    service_0_20_10  service_visit_def_643  1
    service_0_20_10  free_load_conservation_644  3
    service_1_20_0  unique_nonzero_owner_247  1
    service_1_20_0  service_visit_def_1014  1
    service_1_20_0  free_load_conservation_1015  -7
    service_1_20_0  original_T_including_depot_unload_1061  840
    service_1_20_1  unique_nonzero_owner_248  1
    service_1_20_1  service_visit_def_1014  1
    service_1_20_1  free_load_conservation_1015  -6
    service_1_20_1  original_T_including_depot_unload_1061  720
    service_1_20_2  unique_nonzero_owner_249  1
    service_1_20_2  service_visit_def_1014  1
    service_1_20_2  free_load_conservation_1015  -5
    service_1_20_2  original_T_including_depot_unload_1061  600
    service_1_20_3  unique_nonzero_owner_250  1
    service_1_20_3  service_visit_def_1014  1
    service_1_20_3  free_load_conservation_1015  -4
    service_1_20_3  original_T_including_depot_unload_1061  480
    service_1_20_4  unique_nonzero_owner_251  1
    service_1_20_4  service_visit_def_1014  1
    service_1_20_4  free_load_conservation_1015  -3
    service_1_20_4  original_T_including_depot_unload_1061  360
    service_1_20_5  unique_nonzero_owner_252  1
    service_1_20_5  service_visit_def_1014  1
    service_1_20_5  free_load_conservation_1015  -2
    service_1_20_5  original_T_including_depot_unload_1061  240
    service_1_20_6  unique_nonzero_owner_253  1
    service_1_20_6  service_visit_def_1014  1
    service_1_20_6  free_load_conservation_1015  -1
    service_1_20_6  original_T_including_depot_unload_1061  120
    service_1_20_8  unique_nonzero_owner_254  1
    service_1_20_8  service_visit_def_1014  1
    service_1_20_8  free_load_conservation_1015  1
    service_1_20_9  unique_nonzero_owner_255  1
    service_1_20_9  service_visit_def_1014  1
    service_1_20_9  free_load_conservation_1015  2
    service_1_20_10  unique_nonzero_owner_256  1
    service_1_20_10  service_visit_def_1014  1
    service_1_20_10  free_load_conservation_1015  3
    service_2_20_0  unique_nonzero_owner_247  1
    service_2_20_0  service_visit_def_1332  1
    service_2_20_0  free_load_conservation_1333  -7
    service_2_20_0  original_T_including_depot_unload_1378  840
    service_2_20_1  unique_nonzero_owner_248  1
    service_2_20_1  service_visit_def_1332  1
    service_2_20_1  free_load_conservation_1333  -6
    service_2_20_1  original_T_including_depot_unload_1378  720
    service_2_20_2  unique_nonzero_owner_249  1
    service_2_20_2  service_visit_def_1332  1
    service_2_20_2  free_load_conservation_1333  -5
    service_2_20_2  original_T_including_depot_unload_1378  600
    service_2_20_3  unique_nonzero_owner_250  1
    service_2_20_3  service_visit_def_1332  1
    service_2_20_3  free_load_conservation_1333  -4
    service_2_20_3  original_T_including_depot_unload_1378  480
    service_2_20_4  unique_nonzero_owner_251  1
    service_2_20_4  service_visit_def_1332  1
    service_2_20_4  free_load_conservation_1333  -3
    service_2_20_4  original_T_including_depot_unload_1378  360
    service_2_20_5  unique_nonzero_owner_252  1
    service_2_20_5  service_visit_def_1332  1
    service_2_20_5  free_load_conservation_1333  -2
    service_2_20_5  original_T_including_depot_unload_1378  240
    service_2_20_6  unique_nonzero_owner_253  1
    service_2_20_6  service_visit_def_1332  1
    service_2_20_6  free_load_conservation_1333  -1
    service_2_20_6  original_T_including_depot_unload_1378  120
    service_2_20_8  unique_nonzero_owner_254  1
    service_2_20_8  service_visit_def_1332  1
    service_2_20_8  free_load_conservation_1333  1
    service_2_20_9  unique_nonzero_owner_255  1
    service_2_20_9  service_visit_def_1332  1
    service_2_20_9  free_load_conservation_1333  2
    service_2_20_10  unique_nonzero_owner_256  1
    service_2_20_10  service_visit_def_1332  1
    service_2_20_10  free_load_conservation_1333  3
    service_0_21_1  unique_nonzero_owner_257  1
    service_0_21_1  service_visit_def_649  1
    service_0_21_1  free_load_conservation_650  1
    service_0_21_2  unique_nonzero_owner_258  1
    service_0_21_2  service_visit_def_649  1
    service_0_21_2  free_load_conservation_650  2
    service_0_21_3  unique_nonzero_owner_259  1
    service_0_21_3  service_visit_def_649  1
    service_0_21_3  free_load_conservation_650  3
    service_0_21_4  unique_nonzero_owner_260  1
    service_0_21_4  service_visit_def_649  1
    service_0_21_4  free_load_conservation_650  4
    service_0_21_5  unique_nonzero_owner_261  1
    service_0_21_5  service_visit_def_649  1
    service_0_21_5  free_load_conservation_650  5
    service_0_21_6  unique_nonzero_owner_262  1
    service_0_21_6  service_visit_def_649  1
    service_0_21_6  free_load_conservation_650  6
    service_1_21_1  unique_nonzero_owner_257  1
    service_1_21_1  service_visit_def_1020  1
    service_1_21_1  free_load_conservation_1021  1
    service_1_21_2  unique_nonzero_owner_258  1
    service_1_21_2  service_visit_def_1020  1
    service_1_21_2  free_load_conservation_1021  2
    service_1_21_3  unique_nonzero_owner_259  1
    service_1_21_3  service_visit_def_1020  1
    service_1_21_3  free_load_conservation_1021  3
    service_1_21_4  unique_nonzero_owner_260  1
    service_1_21_4  service_visit_def_1020  1
    service_1_21_4  free_load_conservation_1021  4
    service_1_21_5  unique_nonzero_owner_261  1
    service_1_21_5  service_visit_def_1020  1
    service_1_21_5  free_load_conservation_1021  5
    service_1_21_6  unique_nonzero_owner_262  1
    service_1_21_6  service_visit_def_1020  1
    service_1_21_6  free_load_conservation_1021  6
    service_2_21_1  unique_nonzero_owner_257  1
    service_2_21_1  service_visit_def_1338  1
    service_2_21_1  free_load_conservation_1339  1
    service_2_21_2  unique_nonzero_owner_258  1
    service_2_21_2  service_visit_def_1338  1
    service_2_21_2  free_load_conservation_1339  2
    service_2_21_3  unique_nonzero_owner_259  1
    service_2_21_3  service_visit_def_1338  1
    service_2_21_3  free_load_conservation_1339  3
    service_2_21_4  unique_nonzero_owner_260  1
    service_2_21_4  service_visit_def_1338  1
    service_2_21_4  free_load_conservation_1339  4
    service_2_21_5  unique_nonzero_owner_261  1
    service_2_21_5  service_visit_def_1338  1
    service_2_21_5  free_load_conservation_1339  5
    service_2_21_6  unique_nonzero_owner_262  1
    service_2_21_6  service_visit_def_1338  1
    service_2_21_6  free_load_conservation_1339  6
    service_0_34_0  unique_nonzero_owner_263  1
    service_0_34_0  service_visit_def_655  1
    service_0_34_0  free_load_conservation_656  -2
    service_0_34_0  original_T_including_depot_unload_690  240
    service_0_34_1  unique_nonzero_owner_264  1
    service_0_34_1  service_visit_def_655  1
    service_0_34_1  free_load_conservation_656  -1
    service_0_34_1  original_T_including_depot_unload_690  120
    service_0_34_3  unique_nonzero_owner_265  1
    service_0_34_3  service_visit_def_655  1
    service_0_34_3  free_load_conservation_656  1
    service_0_34_4  unique_nonzero_owner_266  1
    service_0_34_4  service_visit_def_655  1
    service_0_34_4  free_load_conservation_656  2
    service_0_34_5  unique_nonzero_owner_267  1
    service_0_34_5  service_visit_def_655  1
    service_0_34_5  free_load_conservation_656  3
    service_0_34_6  unique_nonzero_owner_268  1
    service_0_34_6  service_visit_def_655  1
    service_0_34_6  free_load_conservation_656  4
    service_0_34_7  unique_nonzero_owner_269  1
    service_0_34_7  service_visit_def_655  1
    service_0_34_7  free_load_conservation_656  5
    service_0_34_8  unique_nonzero_owner_270  1
    service_0_34_8  service_visit_def_655  1
    service_0_34_8  free_load_conservation_656  6
    service_0_34_9  unique_nonzero_owner_271  1
    service_0_34_9  service_visit_def_655  1
    service_0_34_9  free_load_conservation_656  7
    service_0_34_10  unique_nonzero_owner_272  1
    service_0_34_10  service_visit_def_655  1
    service_0_34_10  free_load_conservation_656  8
    service_0_34_11  unique_nonzero_owner_273  1
    service_0_34_11  service_visit_def_655  1
    service_0_34_11  free_load_conservation_656  9
    service_0_34_12  unique_nonzero_owner_274  1
    service_0_34_12  service_visit_def_655  1
    service_0_34_12  free_load_conservation_656  10
    service_0_34_13  unique_nonzero_owner_275  1
    service_0_34_13  service_visit_def_655  1
    service_0_34_13  free_load_conservation_656  11
    service_0_34_14  unique_nonzero_owner_276  1
    service_0_34_14  service_visit_def_655  1
    service_0_34_14  free_load_conservation_656  12
    service_0_34_15  unique_nonzero_owner_277  1
    service_0_34_15  service_visit_def_655  1
    service_0_34_15  free_load_conservation_656  13
    service_1_34_0  unique_nonzero_owner_263  1
    service_1_34_0  service_visit_def_1026  1
    service_1_34_0  free_load_conservation_1027  -2
    service_1_34_0  original_T_including_depot_unload_1061  240
    service_1_34_1  unique_nonzero_owner_264  1
    service_1_34_1  service_visit_def_1026  1
    service_1_34_1  free_load_conservation_1027  -1
    service_1_34_1  original_T_including_depot_unload_1061  120
    service_1_34_3  unique_nonzero_owner_265  1
    service_1_34_3  service_visit_def_1026  1
    service_1_34_3  free_load_conservation_1027  1
    service_1_34_4  unique_nonzero_owner_266  1
    service_1_34_4  service_visit_def_1026  1
    service_1_34_4  free_load_conservation_1027  2
    service_1_34_5  unique_nonzero_owner_267  1
    service_1_34_5  service_visit_def_1026  1
    service_1_34_5  free_load_conservation_1027  3
    service_1_34_6  unique_nonzero_owner_268  1
    service_1_34_6  service_visit_def_1026  1
    service_1_34_6  free_load_conservation_1027  4
    service_1_34_7  unique_nonzero_owner_269  1
    service_1_34_7  service_visit_def_1026  1
    service_1_34_7  free_load_conservation_1027  5
    service_1_34_8  unique_nonzero_owner_270  1
    service_1_34_8  service_visit_def_1026  1
    service_1_34_8  free_load_conservation_1027  6
    service_1_34_9  unique_nonzero_owner_271  1
    service_1_34_9  service_visit_def_1026  1
    service_1_34_9  free_load_conservation_1027  7
    service_1_34_10  unique_nonzero_owner_272  1
    service_1_34_10  service_visit_def_1026  1
    service_1_34_10  free_load_conservation_1027  8
    service_1_34_11  unique_nonzero_owner_273  1
    service_1_34_11  service_visit_def_1026  1
    service_1_34_11  free_load_conservation_1027  9
    service_1_34_12  unique_nonzero_owner_274  1
    service_1_34_12  service_visit_def_1026  1
    service_1_34_12  free_load_conservation_1027  10
    service_1_34_13  unique_nonzero_owner_275  1
    service_1_34_13  service_visit_def_1026  1
    service_1_34_13  free_load_conservation_1027  11
    service_1_34_14  unique_nonzero_owner_276  1
    service_1_34_14  service_visit_def_1026  1
    service_1_34_14  free_load_conservation_1027  12
    service_1_34_15  unique_nonzero_owner_277  1
    service_1_34_15  service_visit_def_1026  1
    service_1_34_15  free_load_conservation_1027  13
    service_2_34_0  unique_nonzero_owner_263  1
    service_2_34_0  service_visit_def_1344  1
    service_2_34_0  free_load_conservation_1345  -2
    service_2_34_0  original_T_including_depot_unload_1378  240
    service_2_34_1  unique_nonzero_owner_264  1
    service_2_34_1  service_visit_def_1344  1
    service_2_34_1  free_load_conservation_1345  -1
    service_2_34_1  original_T_including_depot_unload_1378  120
    service_2_34_3  unique_nonzero_owner_265  1
    service_2_34_3  service_visit_def_1344  1
    service_2_34_3  free_load_conservation_1345  1
    service_2_34_4  unique_nonzero_owner_266  1
    service_2_34_4  service_visit_def_1344  1
    service_2_34_4  free_load_conservation_1345  2
    service_2_34_5  unique_nonzero_owner_267  1
    service_2_34_5  service_visit_def_1344  1
    service_2_34_5  free_load_conservation_1345  3
    service_2_34_6  unique_nonzero_owner_268  1
    service_2_34_6  service_visit_def_1344  1
    service_2_34_6  free_load_conservation_1345  4
    service_2_34_7  unique_nonzero_owner_269  1
    service_2_34_7  service_visit_def_1344  1
    service_2_34_7  free_load_conservation_1345  5
    service_2_34_8  unique_nonzero_owner_270  1
    service_2_34_8  service_visit_def_1344  1
    service_2_34_8  free_load_conservation_1345  6
    service_2_34_9  unique_nonzero_owner_271  1
    service_2_34_9  service_visit_def_1344  1
    service_2_34_9  free_load_conservation_1345  7
    service_2_34_10  unique_nonzero_owner_272  1
    service_2_34_10  service_visit_def_1344  1
    service_2_34_10  free_load_conservation_1345  8
    service_2_34_11  unique_nonzero_owner_273  1
    service_2_34_11  service_visit_def_1344  1
    service_2_34_11  free_load_conservation_1345  9
    service_2_34_12  unique_nonzero_owner_274  1
    service_2_34_12  service_visit_def_1344  1
    service_2_34_12  free_load_conservation_1345  10
    service_2_34_13  unique_nonzero_owner_275  1
    service_2_34_13  service_visit_def_1344  1
    service_2_34_13  free_load_conservation_1345  11
    service_2_34_14  unique_nonzero_owner_276  1
    service_2_34_14  service_visit_def_1344  1
    service_2_34_14  free_load_conservation_1345  12
    service_2_34_15  unique_nonzero_owner_277  1
    service_2_34_15  service_visit_def_1344  1
    service_2_34_15  free_load_conservation_1345  13
    service_0_19_0  unique_nonzero_owner_278  1
    service_0_19_0  service_visit_def_661  1
    service_0_19_0  free_load_conservation_662  -1
    service_0_19_0  original_T_including_depot_unload_690  120
    service_0_19_2  unique_nonzero_owner_279  1
    service_0_19_2  service_visit_def_661  1
    service_0_19_2  free_load_conservation_662  1
    service_0_19_3  unique_nonzero_owner_280  1
    service_0_19_3  service_visit_def_661  1
    service_0_19_3  free_load_conservation_662  2
    service_0_19_4  unique_nonzero_owner_281  1
    service_0_19_4  service_visit_def_661  1
    service_0_19_4  free_load_conservation_662  3
    service_0_19_5  unique_nonzero_owner_282  1
    service_0_19_5  service_visit_def_661  1
    service_0_19_5  free_load_conservation_662  4
    service_0_19_6  unique_nonzero_owner_283  1
    service_0_19_6  service_visit_def_661  1
    service_0_19_6  free_load_conservation_662  5
    service_0_19_7  unique_nonzero_owner_284  1
    service_0_19_7  service_visit_def_661  1
    service_0_19_7  free_load_conservation_662  6
    service_0_19_8  unique_nonzero_owner_285  1
    service_0_19_8  service_visit_def_661  1
    service_0_19_8  free_load_conservation_662  7
    service_0_19_9  unique_nonzero_owner_286  1
    service_0_19_9  service_visit_def_661  1
    service_0_19_9  free_load_conservation_662  8
    service_0_19_10  unique_nonzero_owner_287  1
    service_0_19_10  service_visit_def_661  1
    service_0_19_10  free_load_conservation_662  9
    service_1_19_0  unique_nonzero_owner_278  1
    service_1_19_0  service_visit_def_1032  1
    service_1_19_0  free_load_conservation_1033  -1
    service_1_19_0  original_T_including_depot_unload_1061  120
    service_1_19_2  unique_nonzero_owner_279  1
    service_1_19_2  service_visit_def_1032  1
    service_1_19_2  free_load_conservation_1033  1
    service_1_19_3  unique_nonzero_owner_280  1
    service_1_19_3  service_visit_def_1032  1
    service_1_19_3  free_load_conservation_1033  2
    service_1_19_4  unique_nonzero_owner_281  1
    service_1_19_4  service_visit_def_1032  1
    service_1_19_4  free_load_conservation_1033  3
    service_1_19_5  unique_nonzero_owner_282  1
    service_1_19_5  service_visit_def_1032  1
    service_1_19_5  free_load_conservation_1033  4
    service_1_19_6  unique_nonzero_owner_283  1
    service_1_19_6  service_visit_def_1032  1
    service_1_19_6  free_load_conservation_1033  5
    service_1_19_7  unique_nonzero_owner_284  1
    service_1_19_7  service_visit_def_1032  1
    service_1_19_7  free_load_conservation_1033  6
    service_1_19_8  unique_nonzero_owner_285  1
    service_1_19_8  service_visit_def_1032  1
    service_1_19_8  free_load_conservation_1033  7
    service_1_19_9  unique_nonzero_owner_286  1
    service_1_19_9  service_visit_def_1032  1
    service_1_19_9  free_load_conservation_1033  8
    service_1_19_10  unique_nonzero_owner_287  1
    service_1_19_10  service_visit_def_1032  1
    service_1_19_10  free_load_conservation_1033  9
    service_2_19_0  unique_nonzero_owner_278  1
    service_2_19_0  service_visit_def_1350  1
    service_2_19_0  free_load_conservation_1351  -1
    service_2_19_0  original_T_including_depot_unload_1378  120
    service_2_19_2  unique_nonzero_owner_279  1
    service_2_19_2  service_visit_def_1350  1
    service_2_19_2  free_load_conservation_1351  1
    service_2_19_3  unique_nonzero_owner_280  1
    service_2_19_3  service_visit_def_1350  1
    service_2_19_3  free_load_conservation_1351  2
    service_2_19_4  unique_nonzero_owner_281  1
    service_2_19_4  service_visit_def_1350  1
    service_2_19_4  free_load_conservation_1351  3
    service_2_19_5  unique_nonzero_owner_282  1
    service_2_19_5  service_visit_def_1350  1
    service_2_19_5  free_load_conservation_1351  4
    service_2_19_6  unique_nonzero_owner_283  1
    service_2_19_6  service_visit_def_1350  1
    service_2_19_6  free_load_conservation_1351  5
    service_2_19_7  unique_nonzero_owner_284  1
    service_2_19_7  service_visit_def_1350  1
    service_2_19_7  free_load_conservation_1351  6
    service_2_19_8  unique_nonzero_owner_285  1
    service_2_19_8  service_visit_def_1350  1
    service_2_19_8  free_load_conservation_1351  7
    service_2_19_9  unique_nonzero_owner_286  1
    service_2_19_9  service_visit_def_1350  1
    service_2_19_9  free_load_conservation_1351  8
    service_2_19_10  unique_nonzero_owner_287  1
    service_2_19_10  service_visit_def_1350  1
    service_2_19_10  free_load_conservation_1351  9
    service_0_29_0  unique_nonzero_owner_288  1
    service_0_29_0  service_visit_def_667  1
    service_0_29_0  free_load_conservation_668  -1
    service_0_29_0  original_T_including_depot_unload_690  120
    service_0_29_2  unique_nonzero_owner_289  1
    service_0_29_2  service_visit_def_667  1
    service_0_29_2  free_load_conservation_668  1
    service_0_29_3  unique_nonzero_owner_290  1
    service_0_29_3  service_visit_def_667  1
    service_0_29_3  free_load_conservation_668  2
    service_0_29_4  unique_nonzero_owner_291  1
    service_0_29_4  service_visit_def_667  1
    service_0_29_4  free_load_conservation_668  3
    service_0_29_5  unique_nonzero_owner_292  1
    service_0_29_5  service_visit_def_667  1
    service_0_29_5  free_load_conservation_668  4
    service_0_29_6  unique_nonzero_owner_293  1
    service_0_29_6  service_visit_def_667  1
    service_0_29_6  free_load_conservation_668  5
    service_0_29_7  unique_nonzero_owner_294  1
    service_0_29_7  service_visit_def_667  1
    service_0_29_7  free_load_conservation_668  6
    service_0_29_8  unique_nonzero_owner_295  1
    service_0_29_8  service_visit_def_667  1
    service_0_29_8  free_load_conservation_668  7
    service_0_29_9  unique_nonzero_owner_296  1
    service_0_29_9  service_visit_def_667  1
    service_0_29_9  free_load_conservation_668  8
    service_0_29_10  unique_nonzero_owner_297  1
    service_0_29_10  service_visit_def_667  1
    service_0_29_10  free_load_conservation_668  9
    service_1_29_0  unique_nonzero_owner_288  1
    service_1_29_0  service_visit_def_1038  1
    service_1_29_0  free_load_conservation_1039  -1
    service_1_29_0  original_T_including_depot_unload_1061  120
    service_1_29_2  unique_nonzero_owner_289  1
    service_1_29_2  service_visit_def_1038  1
    service_1_29_2  free_load_conservation_1039  1
    service_1_29_3  unique_nonzero_owner_290  1
    service_1_29_3  service_visit_def_1038  1
    service_1_29_3  free_load_conservation_1039  2
    service_1_29_4  unique_nonzero_owner_291  1
    service_1_29_4  service_visit_def_1038  1
    service_1_29_4  free_load_conservation_1039  3
    service_1_29_5  unique_nonzero_owner_292  1
    service_1_29_5  service_visit_def_1038  1
    service_1_29_5  free_load_conservation_1039  4
    service_1_29_6  unique_nonzero_owner_293  1
    service_1_29_6  service_visit_def_1038  1
    service_1_29_6  free_load_conservation_1039  5
    service_1_29_7  unique_nonzero_owner_294  1
    service_1_29_7  service_visit_def_1038  1
    service_1_29_7  free_load_conservation_1039  6
    service_1_29_8  unique_nonzero_owner_295  1
    service_1_29_8  service_visit_def_1038  1
    service_1_29_8  free_load_conservation_1039  7
    service_1_29_9  unique_nonzero_owner_296  1
    service_1_29_9  service_visit_def_1038  1
    service_1_29_9  free_load_conservation_1039  8
    service_1_29_10  unique_nonzero_owner_297  1
    service_1_29_10  service_visit_def_1038  1
    service_1_29_10  free_load_conservation_1039  9
    service_2_29_0  unique_nonzero_owner_288  1
    service_2_29_0  service_visit_def_1356  1
    service_2_29_0  free_load_conservation_1357  -1
    service_2_29_0  original_T_including_depot_unload_1378  120
    service_2_29_2  unique_nonzero_owner_289  1
    service_2_29_2  service_visit_def_1356  1
    service_2_29_2  free_load_conservation_1357  1
    service_2_29_3  unique_nonzero_owner_290  1
    service_2_29_3  service_visit_def_1356  1
    service_2_29_3  free_load_conservation_1357  2
    service_2_29_4  unique_nonzero_owner_291  1
    service_2_29_4  service_visit_def_1356  1
    service_2_29_4  free_load_conservation_1357  3
    service_2_29_5  unique_nonzero_owner_292  1
    service_2_29_5  service_visit_def_1356  1
    service_2_29_5  free_load_conservation_1357  4
    service_2_29_6  unique_nonzero_owner_293  1
    service_2_29_6  service_visit_def_1356  1
    service_2_29_6  free_load_conservation_1357  5
    service_2_29_7  unique_nonzero_owner_294  1
    service_2_29_7  service_visit_def_1356  1
    service_2_29_7  free_load_conservation_1357  6
    service_2_29_8  unique_nonzero_owner_295  1
    service_2_29_8  service_visit_def_1356  1
    service_2_29_8  free_load_conservation_1357  7
    service_2_29_9  unique_nonzero_owner_296  1
    service_2_29_9  service_visit_def_1356  1
    service_2_29_9  free_load_conservation_1357  8
    service_2_29_10  unique_nonzero_owner_297  1
    service_2_29_10  service_visit_def_1356  1
    service_2_29_10  free_load_conservation_1357  9
    service_0_18_0  unique_nonzero_owner_298  1
    service_0_18_0  service_visit_def_673  1
    service_0_18_0  free_load_conservation_674  -8
    service_0_18_0  original_T_including_depot_unload_690  960
    service_0_18_1  unique_nonzero_owner_299  1
    service_0_18_1  service_visit_def_673  1
    service_0_18_1  free_load_conservation_674  -7
    service_0_18_1  original_T_including_depot_unload_690  840
    service_0_18_2  unique_nonzero_owner_300  1
    service_0_18_2  service_visit_def_673  1
    service_0_18_2  free_load_conservation_674  -6
    service_0_18_2  original_T_including_depot_unload_690  720
    service_0_18_3  unique_nonzero_owner_301  1
    service_0_18_3  service_visit_def_673  1
    service_0_18_3  free_load_conservation_674  -5
    service_0_18_3  original_T_including_depot_unload_690  600
    service_0_18_4  unique_nonzero_owner_302  1
    service_0_18_4  service_visit_def_673  1
    service_0_18_4  free_load_conservation_674  -4
    service_0_18_4  original_T_including_depot_unload_690  480
    service_0_18_5  unique_nonzero_owner_303  1
    service_0_18_5  service_visit_def_673  1
    service_0_18_5  free_load_conservation_674  -3
    service_0_18_5  original_T_including_depot_unload_690  360
    service_0_18_6  unique_nonzero_owner_304  1
    service_0_18_6  service_visit_def_673  1
    service_0_18_6  free_load_conservation_674  -2
    service_0_18_6  original_T_including_depot_unload_690  240
    service_0_18_7  unique_nonzero_owner_305  1
    service_0_18_7  service_visit_def_673  1
    service_0_18_7  free_load_conservation_674  -1
    service_0_18_7  original_T_including_depot_unload_690  120
    service_0_18_9  unique_nonzero_owner_306  1
    service_0_18_9  service_visit_def_673  1
    service_0_18_9  free_load_conservation_674  1
    service_0_18_10  unique_nonzero_owner_307  1
    service_0_18_10  service_visit_def_673  1
    service_0_18_10  free_load_conservation_674  2
    service_1_18_0  unique_nonzero_owner_298  1
    service_1_18_0  service_visit_def_1044  1
    service_1_18_0  free_load_conservation_1045  -8
    service_1_18_0  original_T_including_depot_unload_1061  960
    service_1_18_1  unique_nonzero_owner_299  1
    service_1_18_1  service_visit_def_1044  1
    service_1_18_1  free_load_conservation_1045  -7
    service_1_18_1  original_T_including_depot_unload_1061  840
    service_1_18_2  unique_nonzero_owner_300  1
    service_1_18_2  service_visit_def_1044  1
    service_1_18_2  free_load_conservation_1045  -6
    service_1_18_2  original_T_including_depot_unload_1061  720
    service_1_18_3  unique_nonzero_owner_301  1
    service_1_18_3  service_visit_def_1044  1
    service_1_18_3  free_load_conservation_1045  -5
    service_1_18_3  original_T_including_depot_unload_1061  600
    service_1_18_4  unique_nonzero_owner_302  1
    service_1_18_4  service_visit_def_1044  1
    service_1_18_4  free_load_conservation_1045  -4
    service_1_18_4  original_T_including_depot_unload_1061  480
    service_1_18_5  unique_nonzero_owner_303  1
    service_1_18_5  service_visit_def_1044  1
    service_1_18_5  free_load_conservation_1045  -3
    service_1_18_5  original_T_including_depot_unload_1061  360
    service_1_18_6  unique_nonzero_owner_304  1
    service_1_18_6  service_visit_def_1044  1
    service_1_18_6  free_load_conservation_1045  -2
    service_1_18_6  original_T_including_depot_unload_1061  240
    service_1_18_7  unique_nonzero_owner_305  1
    service_1_18_7  service_visit_def_1044  1
    service_1_18_7  free_load_conservation_1045  -1
    service_1_18_7  original_T_including_depot_unload_1061  120
    service_1_18_9  unique_nonzero_owner_306  1
    service_1_18_9  service_visit_def_1044  1
    service_1_18_9  free_load_conservation_1045  1
    service_1_18_10  unique_nonzero_owner_307  1
    service_1_18_10  service_visit_def_1044  1
    service_1_18_10  free_load_conservation_1045  2
    service_2_18_0  unique_nonzero_owner_298  1
    service_2_18_0  service_visit_def_1362  1
    service_2_18_0  free_load_conservation_1363  -8
    service_2_18_0  original_T_including_depot_unload_1378  960
    service_2_18_1  unique_nonzero_owner_299  1
    service_2_18_1  service_visit_def_1362  1
    service_2_18_1  free_load_conservation_1363  -7
    service_2_18_1  original_T_including_depot_unload_1378  840
    service_2_18_2  unique_nonzero_owner_300  1
    service_2_18_2  service_visit_def_1362  1
    service_2_18_2  free_load_conservation_1363  -6
    service_2_18_2  original_T_including_depot_unload_1378  720
    service_2_18_3  unique_nonzero_owner_301  1
    service_2_18_3  service_visit_def_1362  1
    service_2_18_3  free_load_conservation_1363  -5
    service_2_18_3  original_T_including_depot_unload_1378  600
    service_2_18_4  unique_nonzero_owner_302  1
    service_2_18_4  service_visit_def_1362  1
    service_2_18_4  free_load_conservation_1363  -4
    service_2_18_4  original_T_including_depot_unload_1378  480
    service_2_18_5  unique_nonzero_owner_303  1
    service_2_18_5  service_visit_def_1362  1
    service_2_18_5  free_load_conservation_1363  -3
    service_2_18_5  original_T_including_depot_unload_1378  360
    service_2_18_6  unique_nonzero_owner_304  1
    service_2_18_6  service_visit_def_1362  1
    service_2_18_6  free_load_conservation_1363  -2
    service_2_18_6  original_T_including_depot_unload_1378  240
    service_2_18_7  unique_nonzero_owner_305  1
    service_2_18_7  service_visit_def_1362  1
    service_2_18_7  free_load_conservation_1363  -1
    service_2_18_7  original_T_including_depot_unload_1378  120
    service_2_18_9  unique_nonzero_owner_306  1
    service_2_18_9  service_visit_def_1362  1
    service_2_18_9  free_load_conservation_1363  1
    service_2_18_10  unique_nonzero_owner_307  1
    service_2_18_10  service_visit_def_1362  1
    service_2_18_10  free_load_conservation_1363  2
    service_0_27_1  unique_nonzero_owner_308  1
    service_0_27_1  service_visit_def_679  1
    service_0_27_1  free_load_conservation_680  1
    service_0_27_2  unique_nonzero_owner_309  1
    service_0_27_2  service_visit_def_679  1
    service_0_27_2  free_load_conservation_680  2
    service_0_27_3  unique_nonzero_owner_310  1
    service_0_27_3  service_visit_def_679  1
    service_0_27_3  free_load_conservation_680  3
    service_0_27_4  unique_nonzero_owner_311  1
    service_0_27_4  service_visit_def_679  1
    service_0_27_4  free_load_conservation_680  4
    service_0_27_5  unique_nonzero_owner_312  1
    service_0_27_5  service_visit_def_679  1
    service_0_27_5  free_load_conservation_680  5
    service_0_27_6  unique_nonzero_owner_313  1
    service_0_27_6  service_visit_def_679  1
    service_0_27_6  free_load_conservation_680  6
    service_1_27_1  unique_nonzero_owner_308  1
    service_1_27_1  service_visit_def_1050  1
    service_1_27_1  free_load_conservation_1051  1
    service_1_27_2  unique_nonzero_owner_309  1
    service_1_27_2  service_visit_def_1050  1
    service_1_27_2  free_load_conservation_1051  2
    service_1_27_3  unique_nonzero_owner_310  1
    service_1_27_3  service_visit_def_1050  1
    service_1_27_3  free_load_conservation_1051  3
    service_1_27_4  unique_nonzero_owner_311  1
    service_1_27_4  service_visit_def_1050  1
    service_1_27_4  free_load_conservation_1051  4
    service_1_27_5  unique_nonzero_owner_312  1
    service_1_27_5  service_visit_def_1050  1
    service_1_27_5  free_load_conservation_1051  5
    service_1_27_6  unique_nonzero_owner_313  1
    service_1_27_6  service_visit_def_1050  1
    service_1_27_6  free_load_conservation_1051  6
    service_2_27_1  unique_nonzero_owner_308  1
    service_2_27_1  service_visit_def_1368  1
    service_2_27_1  free_load_conservation_1369  1
    service_2_27_2  unique_nonzero_owner_309  1
    service_2_27_2  service_visit_def_1368  1
    service_2_27_2  free_load_conservation_1369  2
    service_2_27_3  unique_nonzero_owner_310  1
    service_2_27_3  service_visit_def_1368  1
    service_2_27_3  free_load_conservation_1369  3
    service_2_27_4  unique_nonzero_owner_311  1
    service_2_27_4  service_visit_def_1368  1
    service_2_27_4  free_load_conservation_1369  4
    service_2_27_5  unique_nonzero_owner_312  1
    service_2_27_5  service_visit_def_1368  1
    service_2_27_5  free_load_conservation_1369  5
    service_2_27_6  unique_nonzero_owner_313  1
    service_2_27_6  service_visit_def_1368  1
    service_2_27_6  free_load_conservation_1369  6
    service_0_17_0  unique_nonzero_owner_314  1
    service_0_17_0  service_visit_def_685  1
    service_0_17_0  free_load_conservation_686  -5
    service_0_17_0  original_T_including_depot_unload_690  600
    service_0_17_1  unique_nonzero_owner_315  1
    service_0_17_1  service_visit_def_685  1
    service_0_17_1  free_load_conservation_686  -4
    service_0_17_1  original_T_including_depot_unload_690  480
    service_0_17_2  unique_nonzero_owner_316  1
    service_0_17_2  service_visit_def_685  1
    service_0_17_2  free_load_conservation_686  -3
    service_0_17_2  original_T_including_depot_unload_690  360
    service_0_17_3  unique_nonzero_owner_317  1
    service_0_17_3  service_visit_def_685  1
    service_0_17_3  free_load_conservation_686  -2
    service_0_17_3  original_T_including_depot_unload_690  240
    service_0_17_4  unique_nonzero_owner_318  1
    service_0_17_4  service_visit_def_685  1
    service_0_17_4  free_load_conservation_686  -1
    service_0_17_4  original_T_including_depot_unload_690  120
    service_0_17_6  unique_nonzero_owner_319  1
    service_0_17_6  service_visit_def_685  1
    service_0_17_6  free_load_conservation_686  1
    service_1_17_0  unique_nonzero_owner_314  1
    service_1_17_0  service_visit_def_1056  1
    service_1_17_0  free_load_conservation_1057  -5
    service_1_17_0  original_T_including_depot_unload_1061  600
    service_1_17_1  unique_nonzero_owner_315  1
    service_1_17_1  service_visit_def_1056  1
    service_1_17_1  free_load_conservation_1057  -4
    service_1_17_1  original_T_including_depot_unload_1061  480
    service_1_17_2  unique_nonzero_owner_316  1
    service_1_17_2  service_visit_def_1056  1
    service_1_17_2  free_load_conservation_1057  -3
    service_1_17_2  original_T_including_depot_unload_1061  360
    service_1_17_3  unique_nonzero_owner_317  1
    service_1_17_3  service_visit_def_1056  1
    service_1_17_3  free_load_conservation_1057  -2
    service_1_17_3  original_T_including_depot_unload_1061  240
    service_1_17_4  unique_nonzero_owner_318  1
    service_1_17_4  service_visit_def_1056  1
    service_1_17_4  free_load_conservation_1057  -1
    service_1_17_4  original_T_including_depot_unload_1061  120
    service_1_17_6  unique_nonzero_owner_319  1
    service_1_17_6  service_visit_def_1056  1
    service_1_17_6  free_load_conservation_1057  1
    service_2_17_0  unique_nonzero_owner_314  1
    service_2_17_0  service_visit_def_1374  1
    service_2_17_0  free_load_conservation_1375  -5
    service_2_17_0  original_T_including_depot_unload_1378  600
    service_2_17_1  unique_nonzero_owner_315  1
    service_2_17_1  service_visit_def_1374  1
    service_2_17_1  free_load_conservation_1375  -4
    service_2_17_1  original_T_including_depot_unload_1378  480
    service_2_17_2  unique_nonzero_owner_316  1
    service_2_17_2  service_visit_def_1374  1
    service_2_17_2  free_load_conservation_1375  -3
    service_2_17_2  original_T_including_depot_unload_1378  360
    service_2_17_3  unique_nonzero_owner_317  1
    service_2_17_3  service_visit_def_1374  1
    service_2_17_3  free_load_conservation_1375  -2
    service_2_17_3  original_T_including_depot_unload_1378  240
    service_2_17_4  unique_nonzero_owner_318  1
    service_2_17_4  service_visit_def_1374  1
    service_2_17_4  free_load_conservation_1375  -1
    service_2_17_4  original_T_including_depot_unload_1378  120
    service_2_17_6  unique_nonzero_owner_319  1
    service_2_17_6  service_visit_def_1374  1
    service_2_17_6  free_load_conservation_1375  1
    MARKER    'MARKER'                 'INTEND'
    visit_0_1  out_degree_611  -1
    visit_0_1  in_degree_612  -1
    visit_0_1  order_active_lb_613  -1
    visit_0_1  order_active_ub_614  -12
    order_0_1  connected_order_arc_335  -1
    order_0_1  connected_order_arc_337  -1
    order_0_1  connected_order_arc_339  -1
    order_0_1  connected_order_arc_341  -1
    order_0_1  connected_order_arc_343  -1
    order_0_1  connected_order_arc_345  -1
    order_0_1  connected_order_arc_347  -1
    order_0_1  connected_order_arc_349  -1
    order_0_1  connected_order_arc_351  -1
    order_0_1  connected_order_arc_353  -1
    order_0_1  connected_order_arc_355  -1
    order_0_1  connected_order_arc_358  1
    order_0_1  connected_order_arc_381  1
    order_0_1  connected_order_arc_404  1
    order_0_1  connected_order_arc_427  1
    order_0_1  connected_order_arc_450  1
    order_0_1  connected_order_arc_473  1
    order_0_1  connected_order_arc_496  1
    order_0_1  connected_order_arc_519  1
    order_0_1  connected_order_arc_542  1
    order_0_1  connected_order_arc_565  1
    order_0_1  connected_order_arc_588  1
    order_0_1  order_active_lb_613  1
    order_0_1  order_active_ub_614  1
    order_0_1  fixed_segment_relative_order_687  -1
    visit_0_2  out_degree_618  -1
    visit_0_2  in_degree_619  -1
    visit_0_2  order_active_lb_620  -1
    visit_0_2  order_active_ub_621  -12
    order_0_2  connected_order_arc_335  1
    order_0_2  connected_order_arc_358  -1
    order_0_2  connected_order_arc_360  -1
    order_0_2  connected_order_arc_362  -1
    order_0_2  connected_order_arc_364  -1
    order_0_2  connected_order_arc_366  -1
    order_0_2  connected_order_arc_368  -1
    order_0_2  connected_order_arc_370  -1
    order_0_2  connected_order_arc_372  -1
    order_0_2  connected_order_arc_374  -1
    order_0_2  connected_order_arc_376  -1
    order_0_2  connected_order_arc_378  -1
    order_0_2  connected_order_arc_383  1
    order_0_2  connected_order_arc_406  1
    order_0_2  connected_order_arc_429  1
    order_0_2  connected_order_arc_452  1
    order_0_2  connected_order_arc_475  1
    order_0_2  connected_order_arc_498  1
    order_0_2  connected_order_arc_521  1
    order_0_2  connected_order_arc_544  1
    order_0_2  connected_order_arc_567  1
    order_0_2  connected_order_arc_590  1
    order_0_2  order_active_lb_620  1
    order_0_2  order_active_ub_621  1
    order_0_2  fixed_segment_relative_order_687  1
    order_0_2  fixed_segment_relative_order_688  -1
    visit_0_3  out_degree_625  -1
    visit_0_3  in_degree_626  -1
    visit_0_3  order_active_lb_627  -1
    visit_0_3  order_active_ub_628  -12
    order_0_3  connected_order_arc_337  1
    order_0_3  connected_order_arc_360  1
    order_0_3  connected_order_arc_381  -1
    order_0_3  connected_order_arc_383  -1
    order_0_3  connected_order_arc_385  -1
    order_0_3  connected_order_arc_387  -1
    order_0_3  connected_order_arc_389  -1
    order_0_3  connected_order_arc_391  -1
    order_0_3  connected_order_arc_393  -1
    order_0_3  connected_order_arc_395  -1
    order_0_3  connected_order_arc_397  -1
    order_0_3  connected_order_arc_399  -1
    order_0_3  connected_order_arc_401  -1
    order_0_3  connected_order_arc_408  1
    order_0_3  connected_order_arc_431  1
    order_0_3  connected_order_arc_454  1
    order_0_3  connected_order_arc_477  1
    order_0_3  connected_order_arc_500  1
    order_0_3  connected_order_arc_523  1
    order_0_3  connected_order_arc_546  1
    order_0_3  connected_order_arc_569  1
    order_0_3  connected_order_arc_592  1
    order_0_3  order_active_lb_627  1
    order_0_3  order_active_ub_628  1
    order_0_3  fixed_segment_relative_order_688  1
    order_0_3  fixed_segment_relative_order_689  -1
    visit_0_4  out_degree_632  -1
    visit_0_4  in_degree_633  -1
    visit_0_4  order_active_lb_634  -1
    visit_0_4  order_active_ub_635  -12
    order_0_4  connected_order_arc_339  1
    order_0_4  connected_order_arc_362  1
    order_0_4  connected_order_arc_385  1
    order_0_4  connected_order_arc_404  -1
    order_0_4  connected_order_arc_406  -1
    order_0_4  connected_order_arc_408  -1
    order_0_4  connected_order_arc_410  -1
    order_0_4  connected_order_arc_412  -1
    order_0_4  connected_order_arc_414  -1
    order_0_4  connected_order_arc_416  -1
    order_0_4  connected_order_arc_418  -1
    order_0_4  connected_order_arc_420  -1
    order_0_4  connected_order_arc_422  -1
    order_0_4  connected_order_arc_424  -1
    order_0_4  connected_order_arc_433  1
    order_0_4  connected_order_arc_456  1
    order_0_4  connected_order_arc_479  1
    order_0_4  connected_order_arc_502  1
    order_0_4  connected_order_arc_525  1
    order_0_4  connected_order_arc_548  1
    order_0_4  connected_order_arc_571  1
    order_0_4  connected_order_arc_594  1
    order_0_4  order_active_lb_634  1
    order_0_4  order_active_ub_635  1
    order_0_4  fixed_segment_relative_order_689  1
    visit_0_12  out_degree_639  -1
    visit_0_12  in_degree_640  -1
    visit_0_12  order_active_lb_641  -1
    visit_0_12  order_active_ub_642  -12
    visit_0_12  service_visit_def_643  -1
    order_0_12  connected_order_arc_341  1
    order_0_12  connected_order_arc_364  1
    order_0_12  connected_order_arc_387  1
    order_0_12  connected_order_arc_410  1
    order_0_12  connected_order_arc_427  -1
    order_0_12  connected_order_arc_429  -1
    order_0_12  connected_order_arc_431  -1
    order_0_12  connected_order_arc_433  -1
    order_0_12  connected_order_arc_435  -1
    order_0_12  connected_order_arc_437  -1
    order_0_12  connected_order_arc_439  -1
    order_0_12  connected_order_arc_441  -1
    order_0_12  connected_order_arc_443  -1
    order_0_12  connected_order_arc_445  -1
    order_0_12  connected_order_arc_447  -1
    order_0_12  connected_order_arc_458  1
    order_0_12  connected_order_arc_481  1
    order_0_12  connected_order_arc_504  1
    order_0_12  connected_order_arc_527  1
    order_0_12  connected_order_arc_550  1
    order_0_12  connected_order_arc_573  1
    order_0_12  connected_order_arc_596  1
    order_0_12  order_active_lb_641  1
    order_0_12  order_active_ub_642  1
    visit_0_13  out_degree_645  -1
    visit_0_13  in_degree_646  -1
    visit_0_13  order_active_lb_647  -1
    visit_0_13  order_active_ub_648  -12
    visit_0_13  service_visit_def_649  -1
    order_0_13  connected_order_arc_343  1
    order_0_13  connected_order_arc_366  1
    order_0_13  connected_order_arc_389  1
    order_0_13  connected_order_arc_412  1
    order_0_13  connected_order_arc_435  1
    order_0_13  connected_order_arc_450  -1
    order_0_13  connected_order_arc_452  -1
    order_0_13  connected_order_arc_454  -1
    order_0_13  connected_order_arc_456  -1
    order_0_13  connected_order_arc_458  -1
    order_0_13  connected_order_arc_460  -1
    order_0_13  connected_order_arc_462  -1
    order_0_13  connected_order_arc_464  -1
    order_0_13  connected_order_arc_466  -1
    order_0_13  connected_order_arc_468  -1
    order_0_13  connected_order_arc_470  -1
    order_0_13  connected_order_arc_483  1
    order_0_13  connected_order_arc_506  1
    order_0_13  connected_order_arc_529  1
    order_0_13  connected_order_arc_552  1
    order_0_13  connected_order_arc_575  1
    order_0_13  connected_order_arc_598  1
    order_0_13  order_active_lb_647  1
    order_0_13  order_active_ub_648  1
    visit_0_14  out_degree_651  -1
    visit_0_14  in_degree_652  -1
    visit_0_14  order_active_lb_653  -1
    visit_0_14  order_active_ub_654  -12
    visit_0_14  service_visit_def_655  -1
    order_0_14  connected_order_arc_345  1
    order_0_14  connected_order_arc_368  1
    order_0_14  connected_order_arc_391  1
    order_0_14  connected_order_arc_414  1
    order_0_14  connected_order_arc_437  1
    order_0_14  connected_order_arc_460  1
    order_0_14  connected_order_arc_473  -1
    order_0_14  connected_order_arc_475  -1
    order_0_14  connected_order_arc_477  -1
    order_0_14  connected_order_arc_479  -1
    order_0_14  connected_order_arc_481  -1
    order_0_14  connected_order_arc_483  -1
    order_0_14  connected_order_arc_485  -1
    order_0_14  connected_order_arc_487  -1
    order_0_14  connected_order_arc_489  -1
    order_0_14  connected_order_arc_491  -1
    order_0_14  connected_order_arc_493  -1
    order_0_14  connected_order_arc_508  1
    order_0_14  connected_order_arc_531  1
    order_0_14  connected_order_arc_554  1
    order_0_14  connected_order_arc_577  1
    order_0_14  connected_order_arc_600  1
    order_0_14  order_active_lb_653  1
    order_0_14  order_active_ub_654  1
    visit_0_15  out_degree_657  -1
    visit_0_15  in_degree_658  -1
    visit_0_15  order_active_lb_659  -1
    visit_0_15  order_active_ub_660  -12
    visit_0_15  service_visit_def_661  -1
    order_0_15  connected_order_arc_347  1
    order_0_15  connected_order_arc_370  1
    order_0_15  connected_order_arc_393  1
    order_0_15  connected_order_arc_416  1
    order_0_15  connected_order_arc_439  1
    order_0_15  connected_order_arc_462  1
    order_0_15  connected_order_arc_485  1
    order_0_15  connected_order_arc_496  -1
    order_0_15  connected_order_arc_498  -1
    order_0_15  connected_order_arc_500  -1
    order_0_15  connected_order_arc_502  -1
    order_0_15  connected_order_arc_504  -1
    order_0_15  connected_order_arc_506  -1
    order_0_15  connected_order_arc_508  -1
    order_0_15  connected_order_arc_510  -1
    order_0_15  connected_order_arc_512  -1
    order_0_15  connected_order_arc_514  -1
    order_0_15  connected_order_arc_516  -1
    order_0_15  connected_order_arc_533  1
    order_0_15  connected_order_arc_556  1
    order_0_15  connected_order_arc_579  1
    order_0_15  connected_order_arc_602  1
    order_0_15  order_active_lb_659  1
    order_0_15  order_active_ub_660  1
    visit_0_16  out_degree_663  -1
    visit_0_16  in_degree_664  -1
    visit_0_16  order_active_lb_665  -1
    visit_0_16  order_active_ub_666  -12
    visit_0_16  service_visit_def_667  -1
    order_0_16  connected_order_arc_349  1
    order_0_16  connected_order_arc_372  1
    order_0_16  connected_order_arc_395  1
    order_0_16  connected_order_arc_418  1
    order_0_16  connected_order_arc_441  1
    order_0_16  connected_order_arc_464  1
    order_0_16  connected_order_arc_487  1
    order_0_16  connected_order_arc_510  1
    order_0_16  connected_order_arc_519  -1
    order_0_16  connected_order_arc_521  -1
    order_0_16  connected_order_arc_523  -1
    order_0_16  connected_order_arc_525  -1
    order_0_16  connected_order_arc_527  -1
    order_0_16  connected_order_arc_529  -1
    order_0_16  connected_order_arc_531  -1
    order_0_16  connected_order_arc_533  -1
    order_0_16  connected_order_arc_535  -1
    order_0_16  connected_order_arc_537  -1
    order_0_16  connected_order_arc_539  -1
    order_0_16  connected_order_arc_558  1
    order_0_16  connected_order_arc_581  1
    order_0_16  connected_order_arc_604  1
    order_0_16  order_active_lb_665  1
    order_0_16  order_active_ub_666  1
    visit_0_17  out_degree_669  -1
    visit_0_17  in_degree_670  -1
    visit_0_17  order_active_lb_671  -1
    visit_0_17  order_active_ub_672  -12
    visit_0_17  service_visit_def_673  -1
    order_0_17  connected_order_arc_351  1
    order_0_17  connected_order_arc_374  1
    order_0_17  connected_order_arc_397  1
    order_0_17  connected_order_arc_420  1
    order_0_17  connected_order_arc_443  1
    order_0_17  connected_order_arc_466  1
    order_0_17  connected_order_arc_489  1
    order_0_17  connected_order_arc_512  1
    order_0_17  connected_order_arc_535  1
    order_0_17  connected_order_arc_542  -1
    order_0_17  connected_order_arc_544  -1
    order_0_17  connected_order_arc_546  -1
    order_0_17  connected_order_arc_548  -1
    order_0_17  connected_order_arc_550  -1
    order_0_17  connected_order_arc_552  -1
    order_0_17  connected_order_arc_554  -1
    order_0_17  connected_order_arc_556  -1
    order_0_17  connected_order_arc_558  -1
    order_0_17  connected_order_arc_560  -1
    order_0_17  connected_order_arc_562  -1
    order_0_17  connected_order_arc_583  1
    order_0_17  connected_order_arc_606  1
    order_0_17  order_active_lb_671  1
    order_0_17  order_active_ub_672  1
    visit_0_18  out_degree_675  -1
    visit_0_18  in_degree_676  -1
    visit_0_18  order_active_lb_677  -1
    visit_0_18  order_active_ub_678  -12
    visit_0_18  service_visit_def_679  -1
    order_0_18  connected_order_arc_353  1
    order_0_18  connected_order_arc_376  1
    order_0_18  connected_order_arc_399  1
    order_0_18  connected_order_arc_422  1
    order_0_18  connected_order_arc_445  1
    order_0_18  connected_order_arc_468  1
    order_0_18  connected_order_arc_491  1
    order_0_18  connected_order_arc_514  1
    order_0_18  connected_order_arc_537  1
    order_0_18  connected_order_arc_560  1
    order_0_18  connected_order_arc_565  -1
    order_0_18  connected_order_arc_567  -1
    order_0_18  connected_order_arc_569  -1
    order_0_18  connected_order_arc_571  -1
    order_0_18  connected_order_arc_573  -1
    order_0_18  connected_order_arc_575  -1
    order_0_18  connected_order_arc_577  -1
    order_0_18  connected_order_arc_579  -1
    order_0_18  connected_order_arc_581  -1
    order_0_18  connected_order_arc_583  -1
    order_0_18  connected_order_arc_585  -1
    order_0_18  connected_order_arc_608  1
    order_0_18  order_active_lb_677  1
    order_0_18  order_active_ub_678  1
    visit_0_19  out_degree_681  -1
    visit_0_19  in_degree_682  -1
    visit_0_19  order_active_lb_683  -1
    visit_0_19  order_active_ub_684  -12
    visit_0_19  service_visit_def_685  -1
    order_0_19  connected_order_arc_355  1
    order_0_19  connected_order_arc_378  1
    order_0_19  connected_order_arc_401  1
    order_0_19  connected_order_arc_424  1
    order_0_19  connected_order_arc_447  1
    order_0_19  connected_order_arc_470  1
    order_0_19  connected_order_arc_493  1
    order_0_19  connected_order_arc_516  1
    order_0_19  connected_order_arc_539  1
    order_0_19  connected_order_arc_562  1
    order_0_19  connected_order_arc_585  1
    order_0_19  connected_order_arc_588  -1
    order_0_19  connected_order_arc_590  -1
    order_0_19  connected_order_arc_592  -1
    order_0_19  connected_order_arc_594  -1
    order_0_19  connected_order_arc_596  -1
    order_0_19  connected_order_arc_598  -1
    order_0_19  connected_order_arc_600  -1
    order_0_19  connected_order_arc_602  -1
    order_0_19  connected_order_arc_604  -1
    order_0_19  connected_order_arc_606  -1
    order_0_19  connected_order_arc_608  -1
    order_0_19  order_active_lb_683  1
    order_0_19  order_active_ub_684  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_0  arc_capacity_320  -20
    arc_0_0_0  depot_departure_or_bypass_609  1
    arc_0_0_0  depot_return_or_bypass_610  1
    MARKER    'MARKER'                 'INTEND'
    load_0_0_0  arc_capacity_320  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_1  arc_capacity_321  -20
    arc_0_0_1  depot_departure_or_bypass_609  1
    arc_0_0_1  in_degree_612  1
    arc_0_0_1  original_T_including_depot_unload_690  4.3364857643570593e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_1  arc_capacity_321  1
    load_0_0_1  segment_load_conservation_615  -1
    load_0_0_1  segment_prefix_lb_616  1
    load_0_0_1  segment_prefix_ub_617  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_2  arc_capacity_322  -20
    arc_0_0_2  depot_departure_or_bypass_609  1
    arc_0_0_2  in_degree_619  1
    arc_0_0_2  original_T_including_depot_unload_690  5.2273830510106120e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_2  arc_capacity_322  1
    load_0_0_2  segment_load_conservation_622  -1
    load_0_0_2  segment_prefix_lb_623  1
    load_0_0_2  segment_prefix_ub_624  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_3  arc_capacity_323  -20
    arc_0_0_3  depot_departure_or_bypass_609  1
    arc_0_0_3  in_degree_626  1
    arc_0_0_3  original_T_including_depot_unload_690  6.4256529461228865e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_3  arc_capacity_323  1
    load_0_0_3  segment_load_conservation_629  -1
    load_0_0_3  segment_prefix_lb_630  1
    load_0_0_3  segment_prefix_ub_631  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_4  arc_capacity_324  -20
    arc_0_0_4  depot_departure_or_bypass_609  1
    arc_0_0_4  in_degree_633  1
    arc_0_0_4  original_T_including_depot_unload_690  6.2904707403788154e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_4  arc_capacity_324  1
    load_0_0_4  segment_load_conservation_636  -1
    load_0_0_4  segment_prefix_lb_637  1
    load_0_0_4  segment_prefix_ub_638  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_12  arc_capacity_325  -20
    arc_0_0_12  depot_departure_or_bypass_609  1
    arc_0_0_12  in_degree_640  1
    arc_0_0_12  original_T_including_depot_unload_690  3.6666597054112611e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_12  arc_capacity_325  1
    load_0_0_12  free_load_conservation_644  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_13  arc_capacity_326  -20
    arc_0_0_13  depot_departure_or_bypass_609  1
    arc_0_0_13  in_degree_646  1
    arc_0_0_13  original_T_including_depot_unload_690  3.8060477410436619e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_13  arc_capacity_326  1
    load_0_0_13  free_load_conservation_650  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_14  arc_capacity_327  -20
    arc_0_0_14  depot_departure_or_bypass_609  1
    arc_0_0_14  in_degree_652  1
    arc_0_0_14  original_T_including_depot_unload_690  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_14  arc_capacity_327  1
    load_0_0_14  free_load_conservation_656  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_15  arc_capacity_328  -20
    arc_0_0_15  depot_departure_or_bypass_609  1
    arc_0_0_15  in_degree_658  1
    arc_0_0_15  original_T_including_depot_unload_690  391.582148421393
    MARKER    'MARKER'                 'INTEND'
    load_0_0_15  arc_capacity_328  1
    load_0_0_15  free_load_conservation_662  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_16  arc_capacity_329  -20
    arc_0_0_16  depot_departure_or_bypass_609  1
    arc_0_0_16  in_degree_664  1
    arc_0_0_16  original_T_including_depot_unload_690  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_16  arc_capacity_329  1
    load_0_0_16  free_load_conservation_668  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_17  arc_capacity_330  -20
    arc_0_0_17  depot_departure_or_bypass_609  1
    arc_0_0_17  in_degree_670  1
    arc_0_0_17  original_T_including_depot_unload_690  3.9270969537253126e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_17  arc_capacity_330  1
    load_0_0_17  free_load_conservation_674  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_18  arc_capacity_331  -20
    arc_0_0_18  depot_departure_or_bypass_609  1
    arc_0_0_18  in_degree_676  1
    arc_0_0_18  original_T_including_depot_unload_690  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_18  arc_capacity_331  1
    load_0_0_18  free_load_conservation_680  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_19  arc_capacity_332  -20
    arc_0_0_19  depot_departure_or_bypass_609  1
    arc_0_0_19  in_degree_682  1
    arc_0_0_19  original_T_including_depot_unload_690  3.9307504957585564e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_19  arc_capacity_332  1
    load_0_0_19  free_load_conservation_686  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_0  arc_capacity_333  -20
    arc_0_1_0  depot_return_or_bypass_610  1
    arc_0_1_0  out_degree_611  1
    arc_0_1_0  original_T_including_depot_unload_690  4.3364857643570593e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_0  arc_capacity_333  1
    load_0_1_0  segment_load_conservation_615  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_2  arc_capacity_334  -20
    arc_0_1_2  connected_order_arc_335  -13
    arc_0_1_2  out_degree_611  1
    arc_0_1_2  in_degree_619  1
    arc_0_1_2  original_T_including_depot_unload_690  1.6552401015053141e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_2  arc_capacity_334  1
    load_0_1_2  segment_load_conservation_615  1
    load_0_1_2  segment_load_conservation_622  -1
    load_0_1_2  segment_prefix_lb_623  1
    load_0_1_2  segment_prefix_ub_624  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_3  arc_capacity_336  -20
    arc_0_1_3  connected_order_arc_337  -13
    arc_0_1_3  out_degree_611  1
    arc_0_1_3  in_degree_626  1
    arc_0_1_3  original_T_including_depot_unload_690  2.8856753867620006e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_3  arc_capacity_336  1
    load_0_1_3  segment_load_conservation_615  1
    load_0_1_3  segment_load_conservation_629  -1
    load_0_1_3  segment_prefix_lb_630  1
    load_0_1_3  segment_prefix_ub_631  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_4  arc_capacity_338  -20
    arc_0_1_4  connected_order_arc_339  -13
    arc_0_1_4  out_degree_611  1
    arc_0_1_4  in_degree_633  1
    arc_0_1_4  original_T_including_depot_unload_690  2.9672747884555446e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_4  arc_capacity_338  1
    load_0_1_4  segment_load_conservation_615  1
    load_0_1_4  segment_load_conservation_636  -1
    load_0_1_4  segment_prefix_lb_637  1
    load_0_1_4  segment_prefix_ub_638  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_12  arc_capacity_340  -20
    arc_0_1_12  connected_order_arc_341  -13
    arc_0_1_12  out_degree_611  1
    arc_0_1_12  in_degree_640  1
    arc_0_1_12  original_T_including_depot_unload_690  3.8423967538093660e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_12  arc_capacity_340  1
    load_0_1_12  segment_load_conservation_615  1
    load_0_1_12  free_load_conservation_644  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_13  arc_capacity_342  -20
    arc_0_1_13  connected_order_arc_343  -13
    arc_0_1_13  out_degree_611  1
    arc_0_1_13  in_degree_646  1
    arc_0_1_13  original_T_including_depot_unload_690  4.8520683722319296e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_13  arc_capacity_342  1
    load_0_1_13  segment_load_conservation_615  1
    load_0_1_13  free_load_conservation_650  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_14  arc_capacity_344  -20
    arc_0_1_14  connected_order_arc_345  -13
    arc_0_1_14  out_degree_611  1
    arc_0_1_14  in_degree_652  1
    arc_0_1_14  original_T_including_depot_unload_690  1.7908610301589636e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_14  arc_capacity_344  1
    load_0_1_14  segment_load_conservation_615  1
    load_0_1_14  free_load_conservation_656  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_15  arc_capacity_346  -20
    arc_0_1_15  connected_order_arc_347  -13
    arc_0_1_15  out_degree_611  1
    arc_0_1_15  in_degree_658  1
    arc_0_1_15  original_T_including_depot_unload_690  1.9892540565194176e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_15  arc_capacity_346  1
    load_0_1_15  segment_load_conservation_615  1
    load_0_1_15  free_load_conservation_662  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_16  arc_capacity_348  -20
    arc_0_1_16  connected_order_arc_349  -13
    arc_0_1_16  out_degree_611  1
    arc_0_1_16  in_degree_664  1
    arc_0_1_16  original_T_including_depot_unload_690  1.4300244315666421e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_16  arc_capacity_348  1
    load_0_1_16  segment_load_conservation_615  1
    load_0_1_16  free_load_conservation_668  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_17  arc_capacity_350  -20
    arc_0_1_17  connected_order_arc_351  -13
    arc_0_1_17  out_degree_611  1
    arc_0_1_17  in_degree_670  1
    arc_0_1_17  original_T_including_depot_unload_690  1.9846190563900964e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_17  arc_capacity_350  1
    load_0_1_17  segment_load_conservation_615  1
    load_0_1_17  free_load_conservation_674  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_18  arc_capacity_352  -20
    arc_0_1_18  connected_order_arc_353  -13
    arc_0_1_18  out_degree_611  1
    arc_0_1_18  in_degree_676  1
    arc_0_1_18  original_T_including_depot_unload_690  1.1588937665971753e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_18  arc_capacity_352  1
    load_0_1_18  segment_load_conservation_615  1
    load_0_1_18  free_load_conservation_680  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_19  arc_capacity_354  -20
    arc_0_1_19  connected_order_arc_355  -13
    arc_0_1_19  out_degree_611  1
    arc_0_1_19  in_degree_682  1
    arc_0_1_19  original_T_including_depot_unload_690  1.9684882536425036e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_19  arc_capacity_354  1
    load_0_1_19  segment_load_conservation_615  1
    load_0_1_19  free_load_conservation_686  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_0  arc_capacity_356  -20
    arc_0_2_0  depot_return_or_bypass_610  1
    arc_0_2_0  out_degree_618  1
    arc_0_2_0  original_T_including_depot_unload_690  5.2273830510106120e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_0  arc_capacity_356  1
    load_0_2_0  segment_load_conservation_622  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_1  arc_capacity_357  -20
    arc_0_2_1  connected_order_arc_358  -13
    arc_0_2_1  in_degree_612  1
    arc_0_2_1  out_degree_618  1
    arc_0_2_1  original_T_including_depot_unload_690  1.6552401015053141e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_1  arc_capacity_357  1
    load_0_2_1  segment_load_conservation_615  -1
    load_0_2_1  segment_prefix_lb_616  1
    load_0_2_1  segment_prefix_ub_617  1
    load_0_2_1  segment_load_conservation_622  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_3  arc_capacity_359  -20
    arc_0_2_3  connected_order_arc_360  -13
    arc_0_2_3  out_degree_618  1
    arc_0_2_3  in_degree_626  1
    arc_0_2_3  original_T_including_depot_unload_690  1.2962070286822930e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_3  arc_capacity_359  1
    load_0_2_3  segment_load_conservation_622  1
    load_0_2_3  segment_load_conservation_629  -1
    load_0_2_3  segment_prefix_lb_630  1
    load_0_2_3  segment_prefix_ub_631  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_4  arc_capacity_361  -20
    arc_0_2_4  connected_order_arc_362  -13
    arc_0_2_4  out_degree_618  1
    arc_0_2_4  in_degree_633  1
    arc_0_2_4  original_T_including_depot_unload_690  1.3208911608803092e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_4  arc_capacity_361  1
    load_0_2_4  segment_load_conservation_622  1
    load_0_2_4  segment_load_conservation_636  -1
    load_0_2_4  segment_prefix_lb_637  1
    load_0_2_4  segment_prefix_ub_638  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_12  arc_capacity_363  -20
    arc_0_2_12  connected_order_arc_364  -13
    arc_0_2_12  out_degree_618  1
    arc_0_2_12  in_degree_640  1
    arc_0_2_12  original_T_including_depot_unload_690  5.4660309215526388e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_12  arc_capacity_363  1
    load_0_2_12  segment_load_conservation_622  1
    load_0_2_12  free_load_conservation_644  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_13  arc_capacity_365  -20
    arc_0_2_13  connected_order_arc_366  -13
    arc_0_2_13  out_degree_618  1
    arc_0_2_13  in_degree_646  1
    arc_0_2_13  original_T_including_depot_unload_690  6.4485258452666415e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_13  arc_capacity_365  1
    load_0_2_13  segment_load_conservation_622  1
    load_0_2_13  free_load_conservation_650  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_14  arc_capacity_367  -20
    arc_0_2_14  connected_order_arc_368  -13
    arc_0_2_14  out_degree_618  1
    arc_0_2_14  in_degree_652  1
    arc_0_2_14  original_T_including_depot_unload_690  1.9520133700471852e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_14  arc_capacity_367  1
    load_0_2_14  segment_load_conservation_622  1
    load_0_2_14  free_load_conservation_656  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_15  arc_capacity_369  -20
    arc_0_2_15  connected_order_arc_370  -13
    arc_0_2_15  out_degree_618  1
    arc_0_2_15  in_degree_658  1
    arc_0_2_15  original_T_including_depot_unload_690  3.6440683639116645e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_15  arc_capacity_369  1
    load_0_2_15  segment_load_conservation_622  1
    load_0_2_15  free_load_conservation_662  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_16  arc_capacity_371  -20
    arc_0_2_16  connected_order_arc_372  -13
    arc_0_2_16  out_degree_618  1
    arc_0_2_16  in_degree_664  1
    arc_0_2_16  original_T_including_depot_unload_690  1.5297878372821015e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_16  arc_capacity_371  1
    load_0_2_16  segment_load_conservation_622  1
    load_0_2_16  free_load_conservation_668  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_17  arc_capacity_373  -20
    arc_0_2_17  connected_order_arc_374  -13
    arc_0_2_17  out_degree_618  1
    arc_0_2_17  in_degree_670  1
    arc_0_2_17  original_T_including_depot_unload_690  3.6395783496181843e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_17  arc_capacity_373  1
    load_0_2_17  segment_load_conservation_622  1
    load_0_2_17  free_load_conservation_674  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_18  arc_capacity_375  -20
    arc_0_2_18  connected_order_arc_376  -13
    arc_0_2_18  out_degree_618  1
    arc_0_2_18  in_degree_676  1
    arc_0_2_18  original_T_including_depot_unload_690  1.3176071585703125e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_18  arc_capacity_375  1
    load_0_2_18  segment_load_conservation_622  1
    load_0_2_18  free_load_conservation_680  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_19  arc_capacity_377  -20
    arc_0_2_19  connected_order_arc_378  -13
    arc_0_2_19  out_degree_618  1
    arc_0_2_19  in_degree_682  1
    arc_0_2_19  original_T_including_depot_unload_690  362.349437569786
    MARKER    'MARKER'                 'INTEND'
    load_0_2_19  arc_capacity_377  1
    load_0_2_19  segment_load_conservation_622  1
    load_0_2_19  free_load_conservation_686  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_0  arc_capacity_379  -20
    arc_0_3_0  depot_return_or_bypass_610  1
    arc_0_3_0  out_degree_625  1
    arc_0_3_0  original_T_including_depot_unload_690  6.4256529461228865e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_0  arc_capacity_379  1
    load_0_3_0  segment_load_conservation_629  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_1  arc_capacity_380  -20
    arc_0_3_1  connected_order_arc_381  -13
    arc_0_3_1  in_degree_612  1
    arc_0_3_1  out_degree_625  1
    arc_0_3_1  original_T_including_depot_unload_690  2.8856753867620006e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_1  arc_capacity_380  1
    load_0_3_1  segment_load_conservation_615  -1
    load_0_3_1  segment_prefix_lb_616  1
    load_0_3_1  segment_prefix_ub_617  1
    load_0_3_1  segment_load_conservation_629  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_2  arc_capacity_382  -20
    arc_0_3_2  connected_order_arc_383  -13
    arc_0_3_2  in_degree_619  1
    arc_0_3_2  out_degree_625  1
    arc_0_3_2  original_T_including_depot_unload_690  1.2962070286822930e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_2  arc_capacity_382  1
    load_0_3_2  segment_load_conservation_622  -1
    load_0_3_2  segment_prefix_lb_623  1
    load_0_3_2  segment_prefix_ub_624  1
    load_0_3_2  segment_load_conservation_629  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_4  arc_capacity_384  -20
    arc_0_3_4  connected_order_arc_385  -13
    arc_0_3_4  out_degree_625  1
    arc_0_3_4  in_degree_633  1
    arc_0_3_4  original_T_including_depot_unload_690  3.5426413058949414e+01
    MARKER    'MARKER'                 'INTEND'
    load_0_3_4  arc_capacity_384  1
    load_0_3_4  segment_load_conservation_629  1
    load_0_3_4  segment_load_conservation_636  -1
    load_0_3_4  segment_prefix_lb_637  1
    load_0_3_4  segment_prefix_ub_638  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_12  arc_capacity_386  -20
    arc_0_3_12  connected_order_arc_387  -13
    arc_0_3_12  out_degree_625  1
    arc_0_3_12  in_degree_640  1
    arc_0_3_12  original_T_including_depot_unload_690  6.7262401684980023e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_12  arc_capacity_386  1
    load_0_3_12  segment_load_conservation_629  1
    load_0_3_12  free_load_conservation_644  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_13  arc_capacity_388  -20
    arc_0_3_13  connected_order_arc_389  -13
    arc_0_3_13  out_degree_625  1
    arc_0_3_13  in_degree_646  1
    arc_0_3_13  original_T_including_depot_unload_690  7.7242003812192672e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_13  arc_capacity_388  1
    load_0_3_13  segment_load_conservation_629  1
    load_0_3_13  free_load_conservation_650  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_14  arc_capacity_390  -20
    arc_0_3_14  connected_order_arc_391  -13
    arc_0_3_14  out_degree_625  1
    arc_0_3_14  in_degree_652  1
    arc_0_3_14  original_T_including_depot_unload_690  2.0790680627934375e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_14  arc_capacity_390  1
    load_0_3_14  segment_load_conservation_629  1
    load_0_3_14  free_load_conservation_656  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_15  arc_capacity_392  -20
    arc_0_3_15  connected_order_arc_393  -13
    arc_0_3_15  out_degree_625  1
    arc_0_3_15  in_degree_658  1
    arc_0_3_15  original_T_including_depot_unload_690  4.8605919276499873e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_15  arc_capacity_392  1
    load_0_3_15  segment_load_conservation_629  1
    load_0_3_15  free_load_conservation_662  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_16  arc_capacity_394  -20
    arc_0_3_16  connected_order_arc_395  -13
    arc_0_3_16  out_degree_625  1
    arc_0_3_16  in_degree_664  1
    arc_0_3_16  original_T_including_depot_unload_690  1.6472719129023171e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_16  arc_capacity_394  1
    load_0_3_16  segment_load_conservation_629  1
    load_0_3_16  free_load_conservation_668  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_17  arc_capacity_396  -20
    arc_0_3_17  connected_order_arc_397  -13
    arc_0_3_17  out_degree_625  1
    arc_0_3_17  in_degree_670  1
    arc_0_3_17  original_T_including_depot_unload_690  4.8549019843957007e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_17  arc_capacity_396  1
    load_0_3_17  segment_load_conservation_629  1
    load_0_3_17  free_load_conservation_674  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_18  arc_capacity_398  -20
    arc_0_3_18  connected_order_arc_399  -13
    arc_0_3_18  out_degree_625  1
    arc_0_3_18  in_degree_676  1
    arc_0_3_18  original_T_including_depot_unload_690  1.4457797980495495e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_18  arc_capacity_398  1
    load_0_3_18  segment_load_conservation_629  1
    load_0_3_18  free_load_conservation_680  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_19  arc_capacity_400  -20
    arc_0_3_19  connected_order_arc_401  -13
    arc_0_3_19  out_degree_625  1
    arc_0_3_19  in_degree_682  1
    arc_0_3_19  original_T_including_depot_unload_690  4.8384395388802926e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_19  arc_capacity_400  1
    load_0_3_19  segment_load_conservation_629  1
    load_0_3_19  free_load_conservation_686  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_0  arc_capacity_402  -20
    arc_0_4_0  depot_return_or_bypass_610  1
    arc_0_4_0  out_degree_632  1
    arc_0_4_0  original_T_including_depot_unload_690  8.9725048283911053e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_0  arc_capacity_402  1
    load_0_4_0  segment_load_conservation_636  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_1  arc_capacity_403  -20
    arc_0_4_1  connected_order_arc_404  -13
    arc_0_4_1  in_degree_612  1
    arc_0_4_1  out_degree_632  1
    arc_0_4_1  original_T_including_depot_unload_690  7.0663858580683063e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_1  arc_capacity_403  1
    load_0_4_1  segment_load_conservation_615  -1
    load_0_4_1  segment_prefix_lb_616  1
    load_0_4_1  segment_prefix_ub_617  1
    load_0_4_1  segment_load_conservation_636  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_2  arc_capacity_405  -20
    arc_0_4_2  connected_order_arc_406  -13
    arc_0_4_2  in_degree_619  1
    arc_0_4_2  out_degree_632  1
    arc_0_4_2  original_T_including_depot_unload_690  5.4635723875297333e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_2  arc_capacity_405  1
    load_0_4_2  segment_load_conservation_622  -1
    load_0_4_2  segment_prefix_lb_623  1
    load_0_4_2  segment_prefix_ub_624  1
    load_0_4_2  segment_load_conservation_636  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_3  arc_capacity_407  -20
    arc_0_4_3  connected_order_arc_408  -13
    arc_0_4_3  in_degree_626  1
    arc_0_4_3  out_degree_632  1
    arc_0_4_3  original_T_including_depot_unload_690  4.5635886855303721e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_3  arc_capacity_407  1
    load_0_4_3  segment_load_conservation_629  -1
    load_0_4_3  segment_prefix_lb_630  1
    load_0_4_3  segment_prefix_ub_631  1
    load_0_4_3  segment_load_conservation_636  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_12  arc_capacity_409  -20
    arc_0_4_12  connected_order_arc_410  -13
    arc_0_4_12  out_degree_632  1
    arc_0_4_12  in_degree_640  1
    arc_0_4_12  original_T_including_depot_unload_690  1.0652346416428543e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_12  arc_capacity_409  1
    load_0_4_12  segment_load_conservation_636  1
    load_0_4_12  free_load_conservation_644  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_13  arc_capacity_411  -20
    arc_0_4_13  connected_order_arc_412  -13
    arc_0_4_13  out_degree_632  1
    arc_0_4_13  in_degree_646  1
    arc_0_4_13  original_T_including_depot_unload_690  1.1516424799836650e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_13  arc_capacity_411  1
    load_0_4_13  segment_load_conservation_636  1
    load_0_4_13  free_load_conservation_650  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_14  arc_capacity_413  -20
    arc_0_4_14  connected_order_arc_414  -13
    arc_0_4_14  out_degree_632  1
    arc_0_4_14  in_degree_652  1
    arc_0_4_14  original_T_including_depot_unload_690  2.4438258071820178e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_14  arc_capacity_413  1
    load_0_4_14  segment_load_conservation_636  1
    load_0_4_14  free_load_conservation_656  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_15  arc_capacity_415  -20
    arc_0_4_15  connected_order_arc_416  -13
    arc_0_4_15  out_degree_632  1
    arc_0_4_15  in_degree_658  1
    arc_0_4_15  original_T_including_depot_unload_690  900.650596089206
    MARKER    'MARKER'                 'INTEND'
    load_0_4_15  arc_capacity_415  1
    load_0_4_15  segment_load_conservation_636  1
    load_0_4_15  free_load_conservation_662  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_16  arc_capacity_417  -20
    arc_0_4_16  connected_order_arc_418  -13
    arc_0_4_16  out_degree_632  1
    arc_0_4_16  in_degree_664  1
    arc_0_4_16  original_T_including_depot_unload_690  1.8150519376858174e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_16  arc_capacity_417  1
    load_0_4_16  segment_load_conservation_636  1
    load_0_4_16  free_load_conservation_668  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_17  arc_capacity_419  -20
    arc_0_4_17  connected_order_arc_420  -13
    arc_0_4_17  out_degree_632  1
    arc_0_4_17  in_degree_670  1
    arc_0_4_17  original_T_including_depot_unload_690  9.0041705227827231e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_17  arc_capacity_419  1
    load_0_4_17  segment_load_conservation_636  1
    load_0_4_17  free_load_conservation_674  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_18  arc_capacity_421  -20
    arc_0_4_18  connected_order_arc_422  -13
    arc_0_4_18  out_degree_632  1
    arc_0_4_18  in_degree_676  1
    arc_0_4_18  original_T_including_depot_unload_690  1804.59863156495
    MARKER    'MARKER'                 'INTEND'
    load_0_4_18  arc_capacity_421  1
    load_0_4_18  segment_load_conservation_636  1
    load_0_4_18  free_load_conservation_680  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_19  arc_capacity_423  -20
    arc_0_4_19  connected_order_arc_424  -13
    arc_0_4_19  out_degree_632  1
    arc_0_4_19  in_degree_682  1
    arc_0_4_19  original_T_including_depot_unload_690  8.9891387855174980e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_19  arc_capacity_423  1
    load_0_4_19  segment_load_conservation_636  1
    load_0_4_19  free_load_conservation_686  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_0  arc_capacity_425  -20
    arc_0_12_0  depot_return_or_bypass_610  1
    arc_0_12_0  out_degree_639  1
    arc_0_12_0  original_T_including_depot_unload_690  3.6666597054112611e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_0  arc_capacity_425  1
    load_0_12_0  free_load_conservation_644  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_1  arc_capacity_426  -20
    arc_0_12_1  connected_order_arc_427  -13
    arc_0_12_1  in_degree_612  1
    arc_0_12_1  out_degree_639  1
    arc_0_12_1  original_T_including_depot_unload_690  3.8423967538093660e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_1  arc_capacity_426  1
    load_0_12_1  segment_load_conservation_615  -1
    load_0_12_1  segment_prefix_lb_616  1
    load_0_12_1  segment_prefix_ub_617  1
    load_0_12_1  free_load_conservation_644  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_2  arc_capacity_428  -20
    arc_0_12_2  connected_order_arc_429  -13
    arc_0_12_2  in_degree_619  1
    arc_0_12_2  out_degree_639  1
    arc_0_12_2  original_T_including_depot_unload_690  5.4660309215526388e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_2  arc_capacity_428  1
    load_0_12_2  segment_load_conservation_622  -1
    load_0_12_2  segment_prefix_lb_623  1
    load_0_12_2  segment_prefix_ub_624  1
    load_0_12_2  free_load_conservation_644  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_3  arc_capacity_430  -20
    arc_0_12_3  connected_order_arc_431  -13
    arc_0_12_3  in_degree_626  1
    arc_0_12_3  out_degree_639  1
    arc_0_12_3  original_T_including_depot_unload_690  6.7262401684980023e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_3  arc_capacity_430  1
    load_0_12_3  segment_load_conservation_629  -1
    load_0_12_3  segment_prefix_lb_630  1
    load_0_12_3  segment_prefix_ub_631  1
    load_0_12_3  free_load_conservation_644  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_4  arc_capacity_432  -20
    arc_0_12_4  connected_order_arc_433  -13
    arc_0_12_4  in_degree_633  1
    arc_0_12_4  out_degree_639  1
    arc_0_12_4  original_T_including_depot_unload_690  6.7868847915924835e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_4  arc_capacity_432  1
    load_0_12_4  segment_load_conservation_636  -1
    load_0_12_4  segment_prefix_lb_637  1
    load_0_12_4  segment_prefix_ub_638  1
    load_0_12_4  free_load_conservation_644  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_13  arc_capacity_434  -20
    arc_0_12_13  connected_order_arc_435  -13
    arc_0_12_13  out_degree_639  1
    arc_0_12_13  in_degree_646  1
    arc_0_12_13  original_T_including_depot_unload_690  1.0605986491096120e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_13  arc_capacity_434  1
    load_0_12_13  free_load_conservation_644  1
    load_0_12_13  free_load_conservation_650  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_14  arc_capacity_436  -20
    arc_0_12_14  connected_order_arc_437  -13
    arc_0_12_14  out_degree_639  1
    arc_0_12_14  in_degree_652  1
    arc_0_12_14  original_T_including_depot_unload_690  1.4066323818659139e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_14  arc_capacity_436  1
    load_0_12_14  free_load_conservation_644  1
    load_0_12_14  free_load_conservation_656  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_15  arc_capacity_438  -20
    arc_0_12_15  connected_order_arc_439  -13
    arc_0_12_15  out_degree_639  1
    arc_0_12_15  in_degree_658  1
    arc_0_12_15  original_T_including_depot_unload_690  193.618232742121
    MARKER    'MARKER'                 'INTEND'
    load_0_12_15  arc_capacity_438  1
    load_0_12_15  free_load_conservation_644  1
    load_0_12_15  free_load_conservation_662  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_16  arc_capacity_440  -20
    arc_0_12_16  connected_order_arc_441  -13
    arc_0_12_16  out_degree_639  1
    arc_0_12_16  in_degree_664  1
    arc_0_12_16  original_T_including_depot_unload_690  1.1737339836679257e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_16  arc_capacity_440  1
    load_0_12_16  free_load_conservation_644  1
    load_0_12_16  free_load_conservation_668  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_17  arc_capacity_442  -20
    arc_0_12_17  connected_order_arc_443  -13
    arc_0_12_17  out_degree_639  1
    arc_0_12_17  in_degree_670  1
    arc_0_12_17  original_T_including_depot_unload_690  1.9450542613707577e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_17  arc_capacity_442  1
    load_0_12_17  free_load_conservation_644  1
    load_0_12_17  free_load_conservation_674  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_18  arc_capacity_444  -20
    arc_0_12_18  connected_order_arc_445  -13
    arc_0_12_18  out_degree_639  1
    arc_0_12_18  in_degree_676  1
    arc_0_12_18  original_T_including_depot_unload_690  7.7620596437921665e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_18  arc_capacity_444  1
    load_0_12_18  free_load_conservation_644  1
    load_0_12_18  free_load_conservation_680  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_19  arc_capacity_446  -20
    arc_0_12_19  connected_order_arc_447  -13
    arc_0_12_19  out_degree_639  1
    arc_0_12_19  in_degree_682  1
    arc_0_12_19  original_T_including_depot_unload_690  1.9614944290232185e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_19  arc_capacity_446  1
    load_0_12_19  free_load_conservation_644  1
    load_0_12_19  free_load_conservation_686  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_0  arc_capacity_448  -20
    arc_0_13_0  depot_return_or_bypass_610  1
    arc_0_13_0  out_degree_645  1
    arc_0_13_0  original_T_including_depot_unload_690  3.8060477410436619e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_0  arc_capacity_448  1
    load_0_13_0  free_load_conservation_650  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_1  arc_capacity_449  -20
    arc_0_13_1  connected_order_arc_450  -13
    arc_0_13_1  in_degree_612  1
    arc_0_13_1  out_degree_645  1
    arc_0_13_1  original_T_including_depot_unload_690  4.8520683722319296e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_1  arc_capacity_449  1
    load_0_13_1  segment_load_conservation_615  -1
    load_0_13_1  segment_prefix_lb_616  1
    load_0_13_1  segment_prefix_ub_617  1
    load_0_13_1  free_load_conservation_650  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_2  arc_capacity_451  -20
    arc_0_13_2  connected_order_arc_452  -13
    arc_0_13_2  in_degree_619  1
    arc_0_13_2  out_degree_645  1
    arc_0_13_2  original_T_including_depot_unload_690  6.4485258452666415e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_2  arc_capacity_451  1
    load_0_13_2  segment_load_conservation_622  -1
    load_0_13_2  segment_prefix_lb_623  1
    load_0_13_2  segment_prefix_ub_624  1
    load_0_13_2  free_load_conservation_650  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_3  arc_capacity_453  -20
    arc_0_13_3  connected_order_arc_454  -13
    arc_0_13_3  in_degree_626  1
    arc_0_13_3  out_degree_645  1
    arc_0_13_3  original_T_including_depot_unload_690  7.7242003812192672e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_3  arc_capacity_453  1
    load_0_13_3  segment_load_conservation_629  -1
    load_0_13_3  segment_prefix_lb_630  1
    load_0_13_3  segment_prefix_ub_631  1
    load_0_13_3  free_load_conservation_650  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_4  arc_capacity_455  -20
    arc_0_13_4  connected_order_arc_456  -13
    arc_0_13_4  in_degree_633  1
    arc_0_13_4  out_degree_645  1
    arc_0_13_4  original_T_including_depot_unload_690  7.7662791174533720e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_4  arc_capacity_455  1
    load_0_13_4  segment_load_conservation_636  -1
    load_0_13_4  segment_prefix_lb_637  1
    load_0_13_4  segment_prefix_ub_638  1
    load_0_13_4  free_load_conservation_650  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_12  arc_capacity_457  -20
    arc_0_13_12  connected_order_arc_458  -13
    arc_0_13_12  in_degree_640  1
    arc_0_13_12  out_degree_645  1
    arc_0_13_12  original_T_including_depot_unload_690  1.0605986491096120e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_12  arc_capacity_457  1
    load_0_13_12  free_load_conservation_644  -1
    load_0_13_12  free_load_conservation_650  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_14  arc_capacity_459  -20
    arc_0_13_14  connected_order_arc_460  -13
    arc_0_13_14  out_degree_645  1
    arc_0_13_14  in_degree_652  1
    arc_0_13_14  original_T_including_depot_unload_690  1.3072142379397485e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_14  arc_capacity_459  1
    load_0_13_14  free_load_conservation_650  1
    load_0_13_14  free_load_conservation_656  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_15  arc_capacity_461  -20
    arc_0_13_15  connected_order_arc_462  -13
    arc_0_13_15  out_degree_645  1
    arc_0_13_15  in_degree_658  1
    arc_0_13_15  original_T_including_depot_unload_690  2.9898712977512486e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_15  arc_capacity_461  1
    load_0_13_15  free_load_conservation_650  1
    load_0_13_15  free_load_conservation_662  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_16  arc_capacity_463  -20
    arc_0_13_16  connected_order_arc_464  -13
    arc_0_13_16  out_degree_645  1
    arc_0_13_16  in_degree_664  1
    arc_0_13_16  original_T_including_depot_unload_690  1.0882276141652012e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_16  arc_capacity_463  1
    load_0_13_16  free_load_conservation_650  1
    load_0_13_16  free_load_conservation_668  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_17  arc_capacity_465  -20
    arc_0_13_17  connected_order_arc_466  -13
    arc_0_13_17  out_degree_645  1
    arc_0_13_17  in_degree_670  1
    arc_0_13_17  original_T_including_depot_unload_690  299.915584808525
    MARKER    'MARKER'                 'INTEND'
    load_0_13_17  arc_capacity_465  1
    load_0_13_17  free_load_conservation_650  1
    load_0_13_17  free_load_conservation_674  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_18  arc_capacity_467  -20
    arc_0_13_18  connected_order_arc_468  -13
    arc_0_13_18  out_degree_645  1
    arc_0_13_18  in_degree_676  1
    arc_0_13_18  original_T_including_depot_unload_690  6.7368811350376711e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_18  arc_capacity_467  1
    load_0_13_18  free_load_conservation_650  1
    load_0_13_18  free_load_conservation_680  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_19  arc_capacity_469  -20
    arc_0_13_19  connected_order_arc_470  -13
    arc_0_13_19  out_degree_645  1
    arc_0_13_19  in_degree_682  1
    arc_0_13_19  original_T_including_depot_unload_690  3.0154417050280659e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_19  arc_capacity_469  1
    load_0_13_19  free_load_conservation_650  1
    load_0_13_19  free_load_conservation_686  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_0  arc_capacity_471  -20
    arc_0_14_0  depot_return_or_bypass_610  1
    arc_0_14_0  out_degree_651  1
    arc_0_14_0  original_T_including_depot_unload_690  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_0  arc_capacity_471  1
    load_0_14_0  free_load_conservation_656  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_1  arc_capacity_472  -20
    arc_0_14_1  connected_order_arc_473  -13
    arc_0_14_1  in_degree_612  1
    arc_0_14_1  out_degree_651  1
    arc_0_14_1  original_T_including_depot_unload_690  1.7908610301589636e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_1  arc_capacity_472  1
    load_0_14_1  segment_load_conservation_615  -1
    load_0_14_1  segment_prefix_lb_616  1
    load_0_14_1  segment_prefix_ub_617  1
    load_0_14_1  free_load_conservation_656  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_2  arc_capacity_474  -20
    arc_0_14_2  connected_order_arc_475  -13
    arc_0_14_2  in_degree_619  1
    arc_0_14_2  out_degree_651  1
    arc_0_14_2  original_T_including_depot_unload_690  1.9520133700471852e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_2  arc_capacity_474  1
    load_0_14_2  segment_load_conservation_622  -1
    load_0_14_2  segment_prefix_lb_623  1
    load_0_14_2  segment_prefix_ub_624  1
    load_0_14_2  free_load_conservation_656  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_3  arc_capacity_476  -20
    arc_0_14_3  connected_order_arc_477  -13
    arc_0_14_3  in_degree_626  1
    arc_0_14_3  out_degree_651  1
    arc_0_14_3  original_T_including_depot_unload_690  2.0790680627934375e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_3  arc_capacity_476  1
    load_0_14_3  segment_load_conservation_629  -1
    load_0_14_3  segment_prefix_lb_630  1
    load_0_14_3  segment_prefix_ub_631  1
    load_0_14_3  free_load_conservation_656  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_4  arc_capacity_478  -20
    arc_0_14_4  connected_order_arc_479  -13
    arc_0_14_4  in_degree_633  1
    arc_0_14_4  out_degree_651  1
    arc_0_14_4  original_T_including_depot_unload_690  2.0838401346783280e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_4  arc_capacity_478  1
    load_0_14_4  segment_load_conservation_636  -1
    load_0_14_4  segment_prefix_lb_637  1
    load_0_14_4  segment_prefix_ub_638  1
    load_0_14_4  free_load_conservation_656  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_12  arc_capacity_480  -20
    arc_0_14_12  connected_order_arc_481  -13
    arc_0_14_12  in_degree_640  1
    arc_0_14_12  out_degree_651  1
    arc_0_14_12  original_T_including_depot_unload_690  1.4066323818659139e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_12  arc_capacity_480  1
    load_0_14_12  free_load_conservation_644  -1
    load_0_14_12  free_load_conservation_656  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_13  arc_capacity_482  -20
    arc_0_14_13  connected_order_arc_483  -13
    arc_0_14_13  in_degree_646  1
    arc_0_14_13  out_degree_651  1
    arc_0_14_13  original_T_including_depot_unload_690  1.3072142379397485e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_13  arc_capacity_482  1
    load_0_14_13  free_load_conservation_650  -1
    load_0_14_13  free_load_conservation_656  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_15  arc_capacity_484  -20
    arc_0_14_15  connected_order_arc_485  -13
    arc_0_14_15  out_degree_651  1
    arc_0_14_15  in_degree_658  1
    arc_0_14_15  original_T_including_depot_unload_690  1.5968425841449753e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_15  arc_capacity_484  1
    load_0_14_15  free_load_conservation_656  1
    load_0_14_15  free_load_conservation_662  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_16  arc_capacity_486  -20
    arc_0_14_16  connected_order_arc_487  -13
    arc_0_14_16  out_degree_651  1
    arc_0_14_16  in_degree_664  1
    arc_0_14_16  original_T_including_depot_unload_690  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_16  arc_capacity_486  1
    load_0_14_16  free_load_conservation_656  1
    load_0_14_16  free_load_conservation_668  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_17  arc_capacity_488  -20
    arc_0_14_17  connected_order_arc_489  -13
    arc_0_14_17  out_degree_651  1
    arc_0_14_17  in_degree_670  1
    arc_0_14_17  original_T_including_depot_unload_690  1.5975637706723310e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_17  arc_capacity_488  1
    load_0_14_17  free_load_conservation_656  1
    load_0_14_17  free_load_conservation_674  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_18  arc_capacity_490  -20
    arc_0_14_18  connected_order_arc_491  -13
    arc_0_14_18  out_degree_651  1
    arc_0_14_18  in_degree_676  1
    arc_0_14_18  original_T_including_depot_unload_690  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_0_14_18  arc_capacity_490  1
    load_0_14_18  free_load_conservation_656  1
    load_0_14_18  free_load_conservation_680  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_19  arc_capacity_492  -20
    arc_0_14_19  connected_order_arc_493  -13
    arc_0_14_19  out_degree_651  1
    arc_0_14_19  in_degree_682  1
    arc_0_14_19  original_T_including_depot_unload_690  1.5992308845216928e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_19  arc_capacity_492  1
    load_0_14_19  free_load_conservation_656  1
    load_0_14_19  free_load_conservation_686  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_0  arc_capacity_494  -20
    arc_0_15_0  depot_return_or_bypass_610  1
    arc_0_15_0  out_degree_657  1
    arc_0_15_0  original_T_including_depot_unload_690  391.582148421393
    MARKER    'MARKER'                 'INTEND'
    load_0_15_0  arc_capacity_494  1
    load_0_15_0  free_load_conservation_662  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_1  arc_capacity_495  -20
    arc_0_15_1  connected_order_arc_496  -13
    arc_0_15_1  in_degree_612  1
    arc_0_15_1  out_degree_657  1
    arc_0_15_1  original_T_including_depot_unload_690  1.9892540565194176e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_1  arc_capacity_495  1
    load_0_15_1  segment_load_conservation_615  -1
    load_0_15_1  segment_prefix_lb_616  1
    load_0_15_1  segment_prefix_ub_617  1
    load_0_15_1  free_load_conservation_662  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_2  arc_capacity_497  -20
    arc_0_15_2  connected_order_arc_498  -13
    arc_0_15_2  in_degree_619  1
    arc_0_15_2  out_degree_657  1
    arc_0_15_2  original_T_including_depot_unload_690  3.6440683639116645e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_2  arc_capacity_497  1
    load_0_15_2  segment_load_conservation_622  -1
    load_0_15_2  segment_prefix_lb_623  1
    load_0_15_2  segment_prefix_ub_624  1
    load_0_15_2  free_load_conservation_662  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_3  arc_capacity_499  -20
    arc_0_15_3  connected_order_arc_500  -13
    arc_0_15_3  in_degree_626  1
    arc_0_15_3  out_degree_657  1
    arc_0_15_3  original_T_including_depot_unload_690  4.8605919276499873e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_3  arc_capacity_499  1
    load_0_15_3  segment_load_conservation_629  -1
    load_0_15_3  segment_prefix_lb_630  1
    load_0_15_3  segment_prefix_ub_631  1
    load_0_15_3  free_load_conservation_662  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_4  arc_capacity_501  -20
    arc_0_15_4  connected_order_arc_502  -13
    arc_0_15_4  in_degree_633  1
    arc_0_15_4  out_degree_657  1
    arc_0_15_4  original_T_including_depot_unload_690  4.9556592834383019e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_4  arc_capacity_501  1
    load_0_15_4  segment_load_conservation_636  -1
    load_0_15_4  segment_prefix_lb_637  1
    load_0_15_4  segment_prefix_ub_638  1
    load_0_15_4  free_load_conservation_662  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_12  arc_capacity_503  -20
    arc_0_15_12  connected_order_arc_504  -13
    arc_0_15_12  in_degree_640  1
    arc_0_15_12  out_degree_657  1
    arc_0_15_12  original_T_including_depot_unload_690  193.618232742121
    MARKER    'MARKER'                 'INTEND'
    load_0_15_12  arc_capacity_503  1
    load_0_15_12  free_load_conservation_644  -1
    load_0_15_12  free_load_conservation_662  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_13  arc_capacity_505  -20
    arc_0_15_13  connected_order_arc_506  -13
    arc_0_15_13  in_degree_646  1
    arc_0_15_13  out_degree_657  1
    arc_0_15_13  original_T_including_depot_unload_690  2.9898712977512486e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_13  arc_capacity_505  1
    load_0_15_13  free_load_conservation_650  -1
    load_0_15_13  free_load_conservation_662  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_14  arc_capacity_507  -20
    arc_0_15_14  connected_order_arc_508  -13
    arc_0_15_14  in_degree_652  1
    arc_0_15_14  out_degree_657  1
    arc_0_15_14  original_T_including_depot_unload_690  1.5968425841449753e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_14  arc_capacity_507  1
    load_0_15_14  free_load_conservation_656  -1
    load_0_15_14  free_load_conservation_662  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_16  arc_capacity_509  -20
    arc_0_15_16  connected_order_arc_510  -13
    arc_0_15_16  out_degree_657  1
    arc_0_15_16  in_degree_664  1
    arc_0_15_16  original_T_including_depot_unload_690  1.3222534044746537e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_16  arc_capacity_509  1
    load_0_15_16  free_load_conservation_662  1
    load_0_15_16  free_load_conservation_668  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_17  arc_capacity_511  -20
    arc_0_15_17  connected_order_arc_512  -13
    arc_0_15_17  out_degree_657  1
    arc_0_15_17  in_degree_670  1
    arc_0_15_17  original_T_including_depot_unload_690  1.2340243107914335e+00
    MARKER    'MARKER'                 'INTEND'
    load_0_15_17  arc_capacity_511  1
    load_0_15_17  free_load_conservation_662  1
    load_0_15_17  free_load_conservation_674  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_18  arc_capacity_513  -20
    arc_0_15_18  connected_order_arc_514  -13
    arc_0_15_18  out_degree_657  1
    arc_0_15_18  in_degree_676  1
    arc_0_15_18  original_T_including_depot_unload_690  9.6906528258679839e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_18  arc_capacity_513  1
    load_0_15_18  free_load_conservation_662  1
    load_0_15_18  free_load_conservation_680  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_19  arc_capacity_515  -20
    arc_0_15_19  connected_order_arc_516  -13
    arc_0_15_19  out_degree_657  1
    arc_0_15_19  in_degree_682  1
    arc_0_15_19  original_T_including_depot_unload_690  2.5978621120511871e+00
    MARKER    'MARKER'                 'INTEND'
    load_0_15_19  arc_capacity_515  1
    load_0_15_19  free_load_conservation_662  1
    load_0_15_19  free_load_conservation_686  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_0  arc_capacity_517  -20
    arc_0_16_0  depot_return_or_bypass_610  1
    arc_0_16_0  out_degree_663  1
    arc_0_16_0  original_T_including_depot_unload_690  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_0  arc_capacity_517  1
    load_0_16_0  free_load_conservation_668  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_1  arc_capacity_518  -20
    arc_0_16_1  connected_order_arc_519  -13
    arc_0_16_1  in_degree_612  1
    arc_0_16_1  out_degree_663  1
    arc_0_16_1  original_T_including_depot_unload_690  1.4300244315666421e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_1  arc_capacity_518  1
    load_0_16_1  segment_load_conservation_615  -1
    load_0_16_1  segment_prefix_lb_616  1
    load_0_16_1  segment_prefix_ub_617  1
    load_0_16_1  free_load_conservation_668  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_2  arc_capacity_520  -20
    arc_0_16_2  connected_order_arc_521  -13
    arc_0_16_2  in_degree_619  1
    arc_0_16_2  out_degree_663  1
    arc_0_16_2  original_T_including_depot_unload_690  1.5297878372821015e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_2  arc_capacity_520  1
    load_0_16_2  segment_load_conservation_622  -1
    load_0_16_2  segment_prefix_lb_623  1
    load_0_16_2  segment_prefix_ub_624  1
    load_0_16_2  free_load_conservation_668  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_3  arc_capacity_522  -20
    arc_0_16_3  connected_order_arc_523  -13
    arc_0_16_3  in_degree_626  1
    arc_0_16_3  out_degree_663  1
    arc_0_16_3  original_T_including_depot_unload_690  1.6472719129023171e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_3  arc_capacity_522  1
    load_0_16_3  segment_load_conservation_629  -1
    load_0_16_3  segment_prefix_lb_630  1
    load_0_16_3  segment_prefix_ub_631  1
    load_0_16_3  free_load_conservation_668  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_4  arc_capacity_524  -20
    arc_0_16_4  connected_order_arc_525  -13
    arc_0_16_4  in_degree_633  1
    arc_0_16_4  out_degree_663  1
    arc_0_16_4  original_T_including_depot_unload_690  1.6310373065065476e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_4  arc_capacity_524  1
    load_0_16_4  segment_load_conservation_636  -1
    load_0_16_4  segment_prefix_lb_637  1
    load_0_16_4  segment_prefix_ub_638  1
    load_0_16_4  free_load_conservation_668  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_12  arc_capacity_526  -20
    arc_0_16_12  connected_order_arc_527  -13
    arc_0_16_12  in_degree_640  1
    arc_0_16_12  out_degree_663  1
    arc_0_16_12  original_T_including_depot_unload_690  1.1737339836679257e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_12  arc_capacity_526  1
    load_0_16_12  free_load_conservation_644  -1
    load_0_16_12  free_load_conservation_668  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_13  arc_capacity_528  -20
    arc_0_16_13  connected_order_arc_529  -13
    arc_0_16_13  in_degree_646  1
    arc_0_16_13  out_degree_663  1
    arc_0_16_13  original_T_including_depot_unload_690  1.0882276141652012e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_13  arc_capacity_528  1
    load_0_16_13  free_load_conservation_650  -1
    load_0_16_13  free_load_conservation_668  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_14  arc_capacity_530  -20
    arc_0_16_14  connected_order_arc_531  -13
    arc_0_16_14  in_degree_652  1
    arc_0_16_14  out_degree_663  1
    arc_0_16_14  original_T_including_depot_unload_690  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_14  arc_capacity_530  1
    load_0_16_14  free_load_conservation_656  -1
    load_0_16_14  free_load_conservation_668  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_15  arc_capacity_532  -20
    arc_0_16_15  connected_order_arc_533  -13
    arc_0_16_15  in_degree_658  1
    arc_0_16_15  out_degree_663  1
    arc_0_16_15  original_T_including_depot_unload_690  1.3222534044746537e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_15  arc_capacity_532  1
    load_0_16_15  free_load_conservation_662  -1
    load_0_16_15  free_load_conservation_668  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_17  arc_capacity_534  -20
    arc_0_16_17  connected_order_arc_535  -13
    arc_0_16_17  out_degree_663  1
    arc_0_16_17  in_degree_670  1
    arc_0_16_17  original_T_including_depot_unload_690  1.3234781764513652e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_17  arc_capacity_534  1
    load_0_16_17  free_load_conservation_668  1
    load_0_16_17  free_load_conservation_674  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_18  arc_capacity_536  -20
    arc_0_16_18  connected_order_arc_537  -13
    arc_0_16_18  out_degree_663  1
    arc_0_16_18  in_degree_676  1
    arc_0_16_18  original_T_including_depot_unload_690  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_18  arc_capacity_536  1
    load_0_16_18  free_load_conservation_668  1
    load_0_16_18  free_load_conservation_680  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_19  arc_capacity_538  -20
    arc_0_16_19  connected_order_arc_539  -13
    arc_0_16_19  out_degree_663  1
    arc_0_16_19  in_degree_682  1
    arc_0_16_19  original_T_including_depot_unload_690  1.3246263055739521e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_19  arc_capacity_538  1
    load_0_16_19  free_load_conservation_668  1
    load_0_16_19  free_load_conservation_686  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_0  arc_capacity_540  -20
    arc_0_17_0  depot_return_or_bypass_610  1
    arc_0_17_0  out_degree_669  1
    arc_0_17_0  original_T_including_depot_unload_690  3.9270969537253126e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_0  arc_capacity_540  1
    load_0_17_0  free_load_conservation_674  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_1  arc_capacity_541  -20
    arc_0_17_1  connected_order_arc_542  -13
    arc_0_17_1  in_degree_612  1
    arc_0_17_1  out_degree_669  1
    arc_0_17_1  original_T_including_depot_unload_690  1.9846190563900964e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_1  arc_capacity_541  1
    load_0_17_1  segment_load_conservation_615  -1
    load_0_17_1  segment_prefix_lb_616  1
    load_0_17_1  segment_prefix_ub_617  1
    load_0_17_1  free_load_conservation_674  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_2  arc_capacity_543  -20
    arc_0_17_2  connected_order_arc_544  -13
    arc_0_17_2  in_degree_619  1
    arc_0_17_2  out_degree_669  1
    arc_0_17_2  original_T_including_depot_unload_690  3.6395783496181843e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_2  arc_capacity_543  1
    load_0_17_2  segment_load_conservation_622  -1
    load_0_17_2  segment_prefix_lb_623  1
    load_0_17_2  segment_prefix_ub_624  1
    load_0_17_2  free_load_conservation_674  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_3  arc_capacity_545  -20
    arc_0_17_3  connected_order_arc_546  -13
    arc_0_17_3  in_degree_626  1
    arc_0_17_3  out_degree_669  1
    arc_0_17_3  original_T_including_depot_unload_690  4.8549019843957007e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_3  arc_capacity_545  1
    load_0_17_3  segment_load_conservation_629  -1
    load_0_17_3  segment_prefix_lb_630  1
    load_0_17_3  segment_prefix_ub_631  1
    load_0_17_3  free_load_conservation_674  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_4  arc_capacity_547  -20
    arc_0_17_4  connected_order_arc_548  -13
    arc_0_17_4  in_degree_633  1
    arc_0_17_4  out_degree_669  1
    arc_0_17_4  original_T_including_depot_unload_690  4.9507442307813227e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_4  arc_capacity_547  1
    load_0_17_4  segment_load_conservation_636  -1
    load_0_17_4  segment_prefix_lb_637  1
    load_0_17_4  segment_prefix_ub_638  1
    load_0_17_4  free_load_conservation_674  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_12  arc_capacity_549  -20
    arc_0_17_12  connected_order_arc_550  -13
    arc_0_17_12  in_degree_640  1
    arc_0_17_12  out_degree_669  1
    arc_0_17_12  original_T_including_depot_unload_690  1.9450542613707577e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_12  arc_capacity_549  1
    load_0_17_12  free_load_conservation_644  -1
    load_0_17_12  free_load_conservation_674  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_13  arc_capacity_551  -20
    arc_0_17_13  connected_order_arc_552  -13
    arc_0_17_13  in_degree_646  1
    arc_0_17_13  out_degree_669  1
    arc_0_17_13  original_T_including_depot_unload_690  299.915584808525
    MARKER    'MARKER'                 'INTEND'
    load_0_17_13  arc_capacity_551  1
    load_0_17_13  free_load_conservation_650  -1
    load_0_17_13  free_load_conservation_674  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_14  arc_capacity_553  -20
    arc_0_17_14  connected_order_arc_554  -13
    arc_0_17_14  in_degree_652  1
    arc_0_17_14  out_degree_669  1
    arc_0_17_14  original_T_including_depot_unload_690  1.5975637706723310e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_14  arc_capacity_553  1
    load_0_17_14  free_load_conservation_656  -1
    load_0_17_14  free_load_conservation_674  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_15  arc_capacity_555  -20
    arc_0_17_15  connected_order_arc_556  -13
    arc_0_17_15  in_degree_658  1
    arc_0_17_15  out_degree_669  1
    arc_0_17_15  original_T_including_depot_unload_690  1.2340243107914335e+00
    MARKER    'MARKER'                 'INTEND'
    load_0_17_15  arc_capacity_555  1
    load_0_17_15  free_load_conservation_662  -1
    load_0_17_15  free_load_conservation_674  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_16  arc_capacity_557  -20
    arc_0_17_16  connected_order_arc_558  -13
    arc_0_17_16  in_degree_664  1
    arc_0_17_16  out_degree_669  1
    arc_0_17_16  original_T_including_depot_unload_690  1.3234781764513652e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_16  arc_capacity_557  1
    load_0_17_16  free_load_conservation_668  -1
    load_0_17_16  free_load_conservation_674  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_18  arc_capacity_559  -20
    arc_0_17_18  connected_order_arc_560  -13
    arc_0_17_18  out_degree_669  1
    arc_0_17_18  in_degree_676  1
    arc_0_17_18  original_T_including_depot_unload_690  9.6988018824317578e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_18  arc_capacity_559  1
    load_0_17_18  free_load_conservation_674  1
    load_0_17_18  free_load_conservation_680  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_19  arc_capacity_561  -20
    arc_0_17_19  connected_order_arc_562  -13
    arc_0_17_19  out_degree_669  1
    arc_0_17_19  in_degree_682  1
    arc_0_17_19  original_T_including_depot_unload_690  1.6672379018690657e+00
    MARKER    'MARKER'                 'INTEND'
    load_0_17_19  arc_capacity_561  1
    load_0_17_19  free_load_conservation_674  1
    load_0_17_19  free_load_conservation_686  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_0  arc_capacity_563  -20
    arc_0_18_0  depot_return_or_bypass_610  1
    arc_0_18_0  out_degree_675  1
    arc_0_18_0  original_T_including_depot_unload_690  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_0  arc_capacity_563  1
    load_0_18_0  free_load_conservation_680  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_1  arc_capacity_564  -20
    arc_0_18_1  connected_order_arc_565  -13
    arc_0_18_1  in_degree_612  1
    arc_0_18_1  out_degree_675  1
    arc_0_18_1  original_T_including_depot_unload_690  1.1588937665971753e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_1  arc_capacity_564  1
    load_0_18_1  segment_load_conservation_615  -1
    load_0_18_1  segment_prefix_lb_616  1
    load_0_18_1  segment_prefix_ub_617  1
    load_0_18_1  free_load_conservation_680  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_2  arc_capacity_566  -20
    arc_0_18_2  connected_order_arc_567  -13
    arc_0_18_2  in_degree_619  1
    arc_0_18_2  out_degree_675  1
    arc_0_18_2  original_T_including_depot_unload_690  1.3176071585703125e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_2  arc_capacity_566  1
    load_0_18_2  segment_load_conservation_622  -1
    load_0_18_2  segment_prefix_lb_623  1
    load_0_18_2  segment_prefix_ub_624  1
    load_0_18_2  free_load_conservation_680  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_3  arc_capacity_568  -20
    arc_0_18_3  connected_order_arc_569  -13
    arc_0_18_3  in_degree_626  1
    arc_0_18_3  out_degree_675  1
    arc_0_18_3  original_T_including_depot_unload_690  1.4457797980495495e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_3  arc_capacity_568  1
    load_0_18_3  segment_load_conservation_629  -1
    load_0_18_3  segment_prefix_lb_630  1
    load_0_18_3  segment_prefix_ub_631  1
    load_0_18_3  free_load_conservation_680  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_4  arc_capacity_570  -20
    arc_0_18_4  connected_order_arc_571  -13
    arc_0_18_4  in_degree_633  1
    arc_0_18_4  out_degree_675  1
    arc_0_18_4  original_T_including_depot_unload_690  1.4489149558446036e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_4  arc_capacity_570  1
    load_0_18_4  segment_load_conservation_636  -1
    load_0_18_4  segment_prefix_lb_637  1
    load_0_18_4  segment_prefix_ub_638  1
    load_0_18_4  free_load_conservation_680  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_12  arc_capacity_572  -20
    arc_0_18_12  connected_order_arc_573  -13
    arc_0_18_12  in_degree_640  1
    arc_0_18_12  out_degree_675  1
    arc_0_18_12  original_T_including_depot_unload_690  7.7620596437921665e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_12  arc_capacity_572  1
    load_0_18_12  free_load_conservation_644  -1
    load_0_18_12  free_load_conservation_680  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_13  arc_capacity_574  -20
    arc_0_18_13  connected_order_arc_575  -13
    arc_0_18_13  in_degree_646  1
    arc_0_18_13  out_degree_675  1
    arc_0_18_13  original_T_including_depot_unload_690  6.7368811350376711e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_13  arc_capacity_574  1
    load_0_18_13  free_load_conservation_650  -1
    load_0_18_13  free_load_conservation_680  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_14  arc_capacity_576  -20
    arc_0_18_14  connected_order_arc_577  -13
    arc_0_18_14  in_degree_652  1
    arc_0_18_14  out_degree_675  1
    arc_0_18_14  original_T_including_depot_unload_690  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_0_18_14  arc_capacity_576  1
    load_0_18_14  free_load_conservation_656  -1
    load_0_18_14  free_load_conservation_680  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_15  arc_capacity_578  -20
    arc_0_18_15  connected_order_arc_579  -13
    arc_0_18_15  in_degree_658  1
    arc_0_18_15  out_degree_675  1
    arc_0_18_15  original_T_including_depot_unload_690  9.6906528258679839e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_15  arc_capacity_578  1
    load_0_18_15  free_load_conservation_662  -1
    load_0_18_15  free_load_conservation_680  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_16  arc_capacity_580  -20
    arc_0_18_16  connected_order_arc_581  -13
    arc_0_18_16  in_degree_664  1
    arc_0_18_16  out_degree_675  1
    arc_0_18_16  original_T_including_depot_unload_690  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_16  arc_capacity_580  1
    load_0_18_16  free_load_conservation_668  -1
    load_0_18_16  free_load_conservation_680  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_17  arc_capacity_582  -20
    arc_0_18_17  connected_order_arc_583  -13
    arc_0_18_17  in_degree_670  1
    arc_0_18_17  out_degree_675  1
    arc_0_18_17  original_T_including_depot_unload_690  9.6988018824317578e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_17  arc_capacity_582  1
    load_0_18_17  free_load_conservation_674  -1
    load_0_18_17  free_load_conservation_680  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_19  arc_capacity_584  -20
    arc_0_18_19  connected_order_arc_585  -13
    arc_0_18_19  out_degree_675  1
    arc_0_18_19  in_degree_682  1
    arc_0_18_19  original_T_including_depot_unload_690  9.7154140307447824e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_19  arc_capacity_584  1
    load_0_18_19  free_load_conservation_680  1
    load_0_18_19  free_load_conservation_686  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_0  arc_capacity_586  -20
    arc_0_19_0  depot_return_or_bypass_610  1
    arc_0_19_0  out_degree_681  1
    arc_0_19_0  original_T_including_depot_unload_690  3.9307504957585564e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_0  arc_capacity_586  1
    load_0_19_0  free_load_conservation_686  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_1  arc_capacity_587  -20
    arc_0_19_1  connected_order_arc_588  -13
    arc_0_19_1  in_degree_612  1
    arc_0_19_1  out_degree_681  1
    arc_0_19_1  original_T_including_depot_unload_690  1.9684882536425036e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_1  arc_capacity_587  1
    load_0_19_1  segment_load_conservation_615  -1
    load_0_19_1  segment_prefix_lb_616  1
    load_0_19_1  segment_prefix_ub_617  1
    load_0_19_1  free_load_conservation_686  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_2  arc_capacity_589  -20
    arc_0_19_2  connected_order_arc_590  -13
    arc_0_19_2  in_degree_619  1
    arc_0_19_2  out_degree_681  1
    arc_0_19_2  original_T_including_depot_unload_690  362.349437569786
    MARKER    'MARKER'                 'INTEND'
    load_0_19_2  arc_capacity_589  1
    load_0_19_2  segment_load_conservation_622  -1
    load_0_19_2  segment_prefix_lb_623  1
    load_0_19_2  segment_prefix_ub_624  1
    load_0_19_2  free_load_conservation_686  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_3  arc_capacity_591  -20
    arc_0_19_3  connected_order_arc_592  -13
    arc_0_19_3  in_degree_626  1
    arc_0_19_3  out_degree_681  1
    arc_0_19_3  original_T_including_depot_unload_690  4.8384395388802926e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_3  arc_capacity_591  1
    load_0_19_3  segment_load_conservation_629  -1
    load_0_19_3  segment_prefix_lb_630  1
    load_0_19_3  segment_prefix_ub_631  1
    load_0_19_3  free_load_conservation_686  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_4  arc_capacity_593  -20
    arc_0_19_4  connected_order_arc_594  -13
    arc_0_19_4  in_degree_633  1
    arc_0_19_4  out_degree_681  1
    arc_0_19_4  original_T_including_depot_unload_690  4.9345054001313224e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_4  arc_capacity_593  1
    load_0_19_4  segment_load_conservation_636  -1
    load_0_19_4  segment_prefix_lb_637  1
    load_0_19_4  segment_prefix_ub_638  1
    load_0_19_4  free_load_conservation_686  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_12  arc_capacity_595  -20
    arc_0_19_12  connected_order_arc_596  -13
    arc_0_19_12  in_degree_640  1
    arc_0_19_12  out_degree_681  1
    arc_0_19_12  original_T_including_depot_unload_690  1.9614944290232185e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_12  arc_capacity_595  1
    load_0_19_12  free_load_conservation_644  -1
    load_0_19_12  free_load_conservation_686  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_13  arc_capacity_597  -20
    arc_0_19_13  connected_order_arc_598  -13
    arc_0_19_13  in_degree_646  1
    arc_0_19_13  out_degree_681  1
    arc_0_19_13  original_T_including_depot_unload_690  3.0154417050280659e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_13  arc_capacity_597  1
    load_0_19_13  free_load_conservation_650  -1
    load_0_19_13  free_load_conservation_686  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_14  arc_capacity_599  -20
    arc_0_19_14  connected_order_arc_600  -13
    arc_0_19_14  in_degree_652  1
    arc_0_19_14  out_degree_681  1
    arc_0_19_14  original_T_including_depot_unload_690  1.5992308845216928e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_14  arc_capacity_599  1
    load_0_19_14  free_load_conservation_656  -1
    load_0_19_14  free_load_conservation_686  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_15  arc_capacity_601  -20
    arc_0_19_15  connected_order_arc_602  -13
    arc_0_19_15  in_degree_658  1
    arc_0_19_15  out_degree_681  1
    arc_0_19_15  original_T_including_depot_unload_690  2.5978621120511871e+00
    MARKER    'MARKER'                 'INTEND'
    load_0_19_15  arc_capacity_601  1
    load_0_19_15  free_load_conservation_662  -1
    load_0_19_15  free_load_conservation_686  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_16  arc_capacity_603  -20
    arc_0_19_16  connected_order_arc_604  -13
    arc_0_19_16  in_degree_664  1
    arc_0_19_16  out_degree_681  1
    arc_0_19_16  original_T_including_depot_unload_690  1.3246263055739521e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_16  arc_capacity_603  1
    load_0_19_16  free_load_conservation_668  -1
    load_0_19_16  free_load_conservation_686  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_17  arc_capacity_605  -20
    arc_0_19_17  connected_order_arc_606  -13
    arc_0_19_17  in_degree_670  1
    arc_0_19_17  out_degree_681  1
    arc_0_19_17  original_T_including_depot_unload_690  1.6672379018690657e+00
    MARKER    'MARKER'                 'INTEND'
    load_0_19_17  arc_capacity_605  1
    load_0_19_17  free_load_conservation_674  -1
    load_0_19_17  free_load_conservation_686  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_18  arc_capacity_607  -20
    arc_0_19_18  connected_order_arc_608  -13
    arc_0_19_18  in_degree_676  1
    arc_0_19_18  out_degree_681  1
    arc_0_19_18  original_T_including_depot_unload_690  9.7154140307447824e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_18  arc_capacity_607  1
    load_0_19_18  free_load_conservation_680  -1
    load_0_19_18  free_load_conservation_686  1
    visit_1_5  out_degree_982  -1
    visit_1_5  in_degree_983  -1
    visit_1_5  order_active_lb_984  -1
    visit_1_5  order_active_ub_985  -12
    order_1_5  connected_order_arc_706  -1
    order_1_5  connected_order_arc_708  -1
    order_1_5  connected_order_arc_710  -1
    order_1_5  connected_order_arc_712  -1
    order_1_5  connected_order_arc_714  -1
    order_1_5  connected_order_arc_716  -1
    order_1_5  connected_order_arc_718  -1
    order_1_5  connected_order_arc_720  -1
    order_1_5  connected_order_arc_722  -1
    order_1_5  connected_order_arc_724  -1
    order_1_5  connected_order_arc_726  -1
    order_1_5  connected_order_arc_729  1
    order_1_5  connected_order_arc_752  1
    order_1_5  connected_order_arc_775  1
    order_1_5  connected_order_arc_798  1
    order_1_5  connected_order_arc_821  1
    order_1_5  connected_order_arc_844  1
    order_1_5  connected_order_arc_867  1
    order_1_5  connected_order_arc_890  1
    order_1_5  connected_order_arc_913  1
    order_1_5  connected_order_arc_936  1
    order_1_5  connected_order_arc_959  1
    order_1_5  order_active_lb_984  1
    order_1_5  order_active_ub_985  1
    order_1_5  fixed_segment_relative_order_1058  -1
    visit_1_6  out_degree_989  -1
    visit_1_6  in_degree_990  -1
    visit_1_6  order_active_lb_991  -1
    visit_1_6  order_active_ub_992  -12
    order_1_6  connected_order_arc_706  1
    order_1_6  connected_order_arc_729  -1
    order_1_6  connected_order_arc_731  -1
    order_1_6  connected_order_arc_733  -1
    order_1_6  connected_order_arc_735  -1
    order_1_6  connected_order_arc_737  -1
    order_1_6  connected_order_arc_739  -1
    order_1_6  connected_order_arc_741  -1
    order_1_6  connected_order_arc_743  -1
    order_1_6  connected_order_arc_745  -1
    order_1_6  connected_order_arc_747  -1
    order_1_6  connected_order_arc_749  -1
    order_1_6  connected_order_arc_754  1
    order_1_6  connected_order_arc_777  1
    order_1_6  connected_order_arc_800  1
    order_1_6  connected_order_arc_823  1
    order_1_6  connected_order_arc_846  1
    order_1_6  connected_order_arc_869  1
    order_1_6  connected_order_arc_892  1
    order_1_6  connected_order_arc_915  1
    order_1_6  connected_order_arc_938  1
    order_1_6  connected_order_arc_961  1
    order_1_6  order_active_lb_991  1
    order_1_6  order_active_ub_992  1
    order_1_6  fixed_segment_relative_order_1058  1
    order_1_6  fixed_segment_relative_order_1059  -1
    visit_1_7  out_degree_996  -1
    visit_1_7  in_degree_997  -1
    visit_1_7  order_active_lb_998  -1
    visit_1_7  order_active_ub_999  -12
    order_1_7  connected_order_arc_708  1
    order_1_7  connected_order_arc_731  1
    order_1_7  connected_order_arc_752  -1
    order_1_7  connected_order_arc_754  -1
    order_1_7  connected_order_arc_756  -1
    order_1_7  connected_order_arc_758  -1
    order_1_7  connected_order_arc_760  -1
    order_1_7  connected_order_arc_762  -1
    order_1_7  connected_order_arc_764  -1
    order_1_7  connected_order_arc_766  -1
    order_1_7  connected_order_arc_768  -1
    order_1_7  connected_order_arc_770  -1
    order_1_7  connected_order_arc_772  -1
    order_1_7  connected_order_arc_779  1
    order_1_7  connected_order_arc_802  1
    order_1_7  connected_order_arc_825  1
    order_1_7  connected_order_arc_848  1
    order_1_7  connected_order_arc_871  1
    order_1_7  connected_order_arc_894  1
    order_1_7  connected_order_arc_917  1
    order_1_7  connected_order_arc_940  1
    order_1_7  connected_order_arc_963  1
    order_1_7  order_active_lb_998  1
    order_1_7  order_active_ub_999  1
    order_1_7  fixed_segment_relative_order_1059  1
    order_1_7  fixed_segment_relative_order_1060  -1
    visit_1_8  out_degree_1003  -1
    visit_1_8  in_degree_1004  -1
    visit_1_8  order_active_lb_1005  -1
    visit_1_8  order_active_ub_1006  -12
    order_1_8  connected_order_arc_710  1
    order_1_8  connected_order_arc_733  1
    order_1_8  connected_order_arc_756  1
    order_1_8  connected_order_arc_775  -1
    order_1_8  connected_order_arc_777  -1
    order_1_8  connected_order_arc_779  -1
    order_1_8  connected_order_arc_781  -1
    order_1_8  connected_order_arc_783  -1
    order_1_8  connected_order_arc_785  -1
    order_1_8  connected_order_arc_787  -1
    order_1_8  connected_order_arc_789  -1
    order_1_8  connected_order_arc_791  -1
    order_1_8  connected_order_arc_793  -1
    order_1_8  connected_order_arc_795  -1
    order_1_8  connected_order_arc_804  1
    order_1_8  connected_order_arc_827  1
    order_1_8  connected_order_arc_850  1
    order_1_8  connected_order_arc_873  1
    order_1_8  connected_order_arc_896  1
    order_1_8  connected_order_arc_919  1
    order_1_8  connected_order_arc_942  1
    order_1_8  connected_order_arc_965  1
    order_1_8  order_active_lb_1005  1
    order_1_8  order_active_ub_1006  1
    order_1_8  fixed_segment_relative_order_1060  1
    visit_1_12  out_degree_1010  -1
    visit_1_12  in_degree_1011  -1
    visit_1_12  order_active_lb_1012  -1
    visit_1_12  order_active_ub_1013  -12
    visit_1_12  service_visit_def_1014  -1
    order_1_12  connected_order_arc_712  1
    order_1_12  connected_order_arc_735  1
    order_1_12  connected_order_arc_758  1
    order_1_12  connected_order_arc_781  1
    order_1_12  connected_order_arc_798  -1
    order_1_12  connected_order_arc_800  -1
    order_1_12  connected_order_arc_802  -1
    order_1_12  connected_order_arc_804  -1
    order_1_12  connected_order_arc_806  -1
    order_1_12  connected_order_arc_808  -1
    order_1_12  connected_order_arc_810  -1
    order_1_12  connected_order_arc_812  -1
    order_1_12  connected_order_arc_814  -1
    order_1_12  connected_order_arc_816  -1
    order_1_12  connected_order_arc_818  -1
    order_1_12  connected_order_arc_829  1
    order_1_12  connected_order_arc_852  1
    order_1_12  connected_order_arc_875  1
    order_1_12  connected_order_arc_898  1
    order_1_12  connected_order_arc_921  1
    order_1_12  connected_order_arc_944  1
    order_1_12  connected_order_arc_967  1
    order_1_12  order_active_lb_1012  1
    order_1_12  order_active_ub_1013  1
    visit_1_13  out_degree_1016  -1
    visit_1_13  in_degree_1017  -1
    visit_1_13  order_active_lb_1018  -1
    visit_1_13  order_active_ub_1019  -12
    visit_1_13  service_visit_def_1020  -1
    order_1_13  connected_order_arc_714  1
    order_1_13  connected_order_arc_737  1
    order_1_13  connected_order_arc_760  1
    order_1_13  connected_order_arc_783  1
    order_1_13  connected_order_arc_806  1
    order_1_13  connected_order_arc_821  -1
    order_1_13  connected_order_arc_823  -1
    order_1_13  connected_order_arc_825  -1
    order_1_13  connected_order_arc_827  -1
    order_1_13  connected_order_arc_829  -1
    order_1_13  connected_order_arc_831  -1
    order_1_13  connected_order_arc_833  -1
    order_1_13  connected_order_arc_835  -1
    order_1_13  connected_order_arc_837  -1
    order_1_13  connected_order_arc_839  -1
    order_1_13  connected_order_arc_841  -1
    order_1_13  connected_order_arc_854  1
    order_1_13  connected_order_arc_877  1
    order_1_13  connected_order_arc_900  1
    order_1_13  connected_order_arc_923  1
    order_1_13  connected_order_arc_946  1
    order_1_13  connected_order_arc_969  1
    order_1_13  order_active_lb_1018  1
    order_1_13  order_active_ub_1019  1
    visit_1_14  out_degree_1022  -1
    visit_1_14  in_degree_1023  -1
    visit_1_14  order_active_lb_1024  -1
    visit_1_14  order_active_ub_1025  -12
    visit_1_14  service_visit_def_1026  -1
    order_1_14  connected_order_arc_716  1
    order_1_14  connected_order_arc_739  1
    order_1_14  connected_order_arc_762  1
    order_1_14  connected_order_arc_785  1
    order_1_14  connected_order_arc_808  1
    order_1_14  connected_order_arc_831  1
    order_1_14  connected_order_arc_844  -1
    order_1_14  connected_order_arc_846  -1
    order_1_14  connected_order_arc_848  -1
    order_1_14  connected_order_arc_850  -1
    order_1_14  connected_order_arc_852  -1
    order_1_14  connected_order_arc_854  -1
    order_1_14  connected_order_arc_856  -1
    order_1_14  connected_order_arc_858  -1
    order_1_14  connected_order_arc_860  -1
    order_1_14  connected_order_arc_862  -1
    order_1_14  connected_order_arc_864  -1
    order_1_14  connected_order_arc_879  1
    order_1_14  connected_order_arc_902  1
    order_1_14  connected_order_arc_925  1
    order_1_14  connected_order_arc_948  1
    order_1_14  connected_order_arc_971  1
    order_1_14  order_active_lb_1024  1
    order_1_14  order_active_ub_1025  1
    visit_1_15  out_degree_1028  -1
    visit_1_15  in_degree_1029  -1
    visit_1_15  order_active_lb_1030  -1
    visit_1_15  order_active_ub_1031  -12
    visit_1_15  service_visit_def_1032  -1
    order_1_15  connected_order_arc_718  1
    order_1_15  connected_order_arc_741  1
    order_1_15  connected_order_arc_764  1
    order_1_15  connected_order_arc_787  1
    order_1_15  connected_order_arc_810  1
    order_1_15  connected_order_arc_833  1
    order_1_15  connected_order_arc_856  1
    order_1_15  connected_order_arc_867  -1
    order_1_15  connected_order_arc_869  -1
    order_1_15  connected_order_arc_871  -1
    order_1_15  connected_order_arc_873  -1
    order_1_15  connected_order_arc_875  -1
    order_1_15  connected_order_arc_877  -1
    order_1_15  connected_order_arc_879  -1
    order_1_15  connected_order_arc_881  -1
    order_1_15  connected_order_arc_883  -1
    order_1_15  connected_order_arc_885  -1
    order_1_15  connected_order_arc_887  -1
    order_1_15  connected_order_arc_904  1
    order_1_15  connected_order_arc_927  1
    order_1_15  connected_order_arc_950  1
    order_1_15  connected_order_arc_973  1
    order_1_15  order_active_lb_1030  1
    order_1_15  order_active_ub_1031  1
    visit_1_16  out_degree_1034  -1
    visit_1_16  in_degree_1035  -1
    visit_1_16  order_active_lb_1036  -1
    visit_1_16  order_active_ub_1037  -12
    visit_1_16  service_visit_def_1038  -1
    order_1_16  connected_order_arc_720  1
    order_1_16  connected_order_arc_743  1
    order_1_16  connected_order_arc_766  1
    order_1_16  connected_order_arc_789  1
    order_1_16  connected_order_arc_812  1
    order_1_16  connected_order_arc_835  1
    order_1_16  connected_order_arc_858  1
    order_1_16  connected_order_arc_881  1
    order_1_16  connected_order_arc_890  -1
    order_1_16  connected_order_arc_892  -1
    order_1_16  connected_order_arc_894  -1
    order_1_16  connected_order_arc_896  -1
    order_1_16  connected_order_arc_898  -1
    order_1_16  connected_order_arc_900  -1
    order_1_16  connected_order_arc_902  -1
    order_1_16  connected_order_arc_904  -1
    order_1_16  connected_order_arc_906  -1
    order_1_16  connected_order_arc_908  -1
    order_1_16  connected_order_arc_910  -1
    order_1_16  connected_order_arc_929  1
    order_1_16  connected_order_arc_952  1
    order_1_16  connected_order_arc_975  1
    order_1_16  order_active_lb_1036  1
    order_1_16  order_active_ub_1037  1
    visit_1_17  out_degree_1040  -1
    visit_1_17  in_degree_1041  -1
    visit_1_17  order_active_lb_1042  -1
    visit_1_17  order_active_ub_1043  -12
    visit_1_17  service_visit_def_1044  -1
    order_1_17  connected_order_arc_722  1
    order_1_17  connected_order_arc_745  1
    order_1_17  connected_order_arc_768  1
    order_1_17  connected_order_arc_791  1
    order_1_17  connected_order_arc_814  1
    order_1_17  connected_order_arc_837  1
    order_1_17  connected_order_arc_860  1
    order_1_17  connected_order_arc_883  1
    order_1_17  connected_order_arc_906  1
    order_1_17  connected_order_arc_913  -1
    order_1_17  connected_order_arc_915  -1
    order_1_17  connected_order_arc_917  -1
    order_1_17  connected_order_arc_919  -1
    order_1_17  connected_order_arc_921  -1
    order_1_17  connected_order_arc_923  -1
    order_1_17  connected_order_arc_925  -1
    order_1_17  connected_order_arc_927  -1
    order_1_17  connected_order_arc_929  -1
    order_1_17  connected_order_arc_931  -1
    order_1_17  connected_order_arc_933  -1
    order_1_17  connected_order_arc_954  1
    order_1_17  connected_order_arc_977  1
    order_1_17  order_active_lb_1042  1
    order_1_17  order_active_ub_1043  1
    visit_1_18  out_degree_1046  -1
    visit_1_18  in_degree_1047  -1
    visit_1_18  order_active_lb_1048  -1
    visit_1_18  order_active_ub_1049  -12
    visit_1_18  service_visit_def_1050  -1
    order_1_18  connected_order_arc_724  1
    order_1_18  connected_order_arc_747  1
    order_1_18  connected_order_arc_770  1
    order_1_18  connected_order_arc_793  1
    order_1_18  connected_order_arc_816  1
    order_1_18  connected_order_arc_839  1
    order_1_18  connected_order_arc_862  1
    order_1_18  connected_order_arc_885  1
    order_1_18  connected_order_arc_908  1
    order_1_18  connected_order_arc_931  1
    order_1_18  connected_order_arc_936  -1
    order_1_18  connected_order_arc_938  -1
    order_1_18  connected_order_arc_940  -1
    order_1_18  connected_order_arc_942  -1
    order_1_18  connected_order_arc_944  -1
    order_1_18  connected_order_arc_946  -1
    order_1_18  connected_order_arc_948  -1
    order_1_18  connected_order_arc_950  -1
    order_1_18  connected_order_arc_952  -1
    order_1_18  connected_order_arc_954  -1
    order_1_18  connected_order_arc_956  -1
    order_1_18  connected_order_arc_979  1
    order_1_18  order_active_lb_1048  1
    order_1_18  order_active_ub_1049  1
    visit_1_19  out_degree_1052  -1
    visit_1_19  in_degree_1053  -1
    visit_1_19  order_active_lb_1054  -1
    visit_1_19  order_active_ub_1055  -12
    visit_1_19  service_visit_def_1056  -1
    order_1_19  connected_order_arc_726  1
    order_1_19  connected_order_arc_749  1
    order_1_19  connected_order_arc_772  1
    order_1_19  connected_order_arc_795  1
    order_1_19  connected_order_arc_818  1
    order_1_19  connected_order_arc_841  1
    order_1_19  connected_order_arc_864  1
    order_1_19  connected_order_arc_887  1
    order_1_19  connected_order_arc_910  1
    order_1_19  connected_order_arc_933  1
    order_1_19  connected_order_arc_956  1
    order_1_19  connected_order_arc_959  -1
    order_1_19  connected_order_arc_961  -1
    order_1_19  connected_order_arc_963  -1
    order_1_19  connected_order_arc_965  -1
    order_1_19  connected_order_arc_967  -1
    order_1_19  connected_order_arc_969  -1
    order_1_19  connected_order_arc_971  -1
    order_1_19  connected_order_arc_973  -1
    order_1_19  connected_order_arc_975  -1
    order_1_19  connected_order_arc_977  -1
    order_1_19  connected_order_arc_979  -1
    order_1_19  order_active_lb_1054  1
    order_1_19  order_active_ub_1055  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_0  arc_capacity_691  -25
    arc_1_0_0  depot_departure_or_bypass_980  1
    arc_1_0_0  depot_return_or_bypass_981  1
    MARKER    'MARKER'                 'INTEND'
    load_1_0_0  arc_capacity_691  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_5  arc_capacity_692  -25
    arc_1_0_5  depot_departure_or_bypass_980  1
    arc_1_0_5  in_degree_983  1
    arc_1_0_5  original_T_including_depot_unload_1061  1.1935953747864173e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_5  arc_capacity_692  1
    load_1_0_5  segment_load_conservation_986  -1
    load_1_0_5  segment_prefix_lb_987  1
    load_1_0_5  segment_prefix_ub_988  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_6  arc_capacity_693  -25
    arc_1_0_6  depot_departure_or_bypass_980  1
    arc_1_0_6  in_degree_990  1
    arc_1_0_6  original_T_including_depot_unload_1061  1.4834116102542102e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_6  arc_capacity_693  1
    load_1_0_6  segment_load_conservation_993  -1
    load_1_0_6  segment_prefix_lb_994  1
    load_1_0_6  segment_prefix_ub_995  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_7  arc_capacity_694  -25
    arc_1_0_7  depot_departure_or_bypass_980  1
    arc_1_0_7  in_degree_997  1
    arc_1_0_7  original_T_including_depot_unload_1061  5.4911852608328161e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_7  arc_capacity_694  1
    load_1_0_7  segment_load_conservation_1000  -1
    load_1_0_7  segment_prefix_lb_1001  1
    load_1_0_7  segment_prefix_ub_1002  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_8  arc_capacity_695  -25
    arc_1_0_8  depot_departure_or_bypass_980  1
    arc_1_0_8  in_degree_1004  1
    arc_1_0_8  original_T_including_depot_unload_1061  3.5061909388980052e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_8  arc_capacity_695  1
    load_1_0_8  segment_load_conservation_1007  -1
    load_1_0_8  segment_prefix_lb_1008  1
    load_1_0_8  segment_prefix_ub_1009  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_12  arc_capacity_696  -25
    arc_1_0_12  depot_departure_or_bypass_980  1
    arc_1_0_12  in_degree_1011  1
    arc_1_0_12  original_T_including_depot_unload_1061  3.6666597054112611e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_12  arc_capacity_696  1
    load_1_0_12  free_load_conservation_1015  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_13  arc_capacity_697  -25
    arc_1_0_13  depot_departure_or_bypass_980  1
    arc_1_0_13  in_degree_1017  1
    arc_1_0_13  original_T_including_depot_unload_1061  3.8060477410436619e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_13  arc_capacity_697  1
    load_1_0_13  free_load_conservation_1021  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_14  arc_capacity_698  -25
    arc_1_0_14  depot_departure_or_bypass_980  1
    arc_1_0_14  in_degree_1023  1
    arc_1_0_14  original_T_including_depot_unload_1061  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_14  arc_capacity_698  1
    load_1_0_14  free_load_conservation_1027  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_15  arc_capacity_699  -25
    arc_1_0_15  depot_departure_or_bypass_980  1
    arc_1_0_15  in_degree_1029  1
    arc_1_0_15  original_T_including_depot_unload_1061  391.582148421393
    MARKER    'MARKER'                 'INTEND'
    load_1_0_15  arc_capacity_699  1
    load_1_0_15  free_load_conservation_1033  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_16  arc_capacity_700  -25
    arc_1_0_16  depot_departure_or_bypass_980  1
    arc_1_0_16  in_degree_1035  1
    arc_1_0_16  original_T_including_depot_unload_1061  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_16  arc_capacity_700  1
    load_1_0_16  free_load_conservation_1039  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_17  arc_capacity_701  -25
    arc_1_0_17  depot_departure_or_bypass_980  1
    arc_1_0_17  in_degree_1041  1
    arc_1_0_17  original_T_including_depot_unload_1061  3.9270969537253126e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_17  arc_capacity_701  1
    load_1_0_17  free_load_conservation_1045  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_18  arc_capacity_702  -25
    arc_1_0_18  depot_departure_or_bypass_980  1
    arc_1_0_18  in_degree_1047  1
    arc_1_0_18  original_T_including_depot_unload_1061  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_18  arc_capacity_702  1
    load_1_0_18  free_load_conservation_1051  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_19  arc_capacity_703  -25
    arc_1_0_19  depot_departure_or_bypass_980  1
    arc_1_0_19  in_degree_1053  1
    arc_1_0_19  original_T_including_depot_unload_1061  3.9307504957585564e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_19  arc_capacity_703  1
    load_1_0_19  free_load_conservation_1057  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_0  arc_capacity_704  -25
    arc_1_5_0  depot_return_or_bypass_981  1
    arc_1_5_0  out_degree_982  1
    arc_1_5_0  original_T_including_depot_unload_1061  7.2047755761928431e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_5_0  arc_capacity_704  1
    load_1_5_0  segment_load_conservation_986  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_6  arc_capacity_705  -25
    arc_1_5_6  connected_order_arc_706  -13
    arc_1_5_6  out_degree_982  1
    arc_1_5_6  in_degree_990  1
    arc_1_5_6  original_T_including_depot_unload_1061  1.0359917537364215e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_6  arc_capacity_705  1
    load_1_5_6  segment_load_conservation_986  1
    load_1_5_6  segment_load_conservation_993  -1
    load_1_5_6  segment_prefix_lb_994  1
    load_1_5_6  segment_prefix_ub_995  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_7  arc_capacity_707  -25
    arc_1_5_7  connected_order_arc_708  -13
    arc_1_5_7  out_degree_982  1
    arc_1_5_7  in_degree_997  1
    arc_1_5_7  original_T_including_depot_unload_1061  2.9662284735332634e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_5_7  arc_capacity_707  1
    load_1_5_7  segment_load_conservation_986  1
    load_1_5_7  segment_load_conservation_1000  -1
    load_1_5_7  segment_prefix_lb_1001  1
    load_1_5_7  segment_prefix_ub_1002  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_8  arc_capacity_709  -25
    arc_1_5_8  connected_order_arc_710  -13
    arc_1_5_8  out_degree_982  1
    arc_1_5_8  in_degree_1004  1
    arc_1_5_8  original_T_including_depot_unload_1061  3.7747736142736670e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_5_8  arc_capacity_709  1
    load_1_5_8  segment_load_conservation_986  1
    load_1_5_8  segment_load_conservation_1007  -1
    load_1_5_8  segment_prefix_lb_1008  1
    load_1_5_8  segment_prefix_ub_1009  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_12  arc_capacity_711  -25
    arc_1_5_12  connected_order_arc_712  -13
    arc_1_5_12  out_degree_982  1
    arc_1_5_12  in_degree_1011  1
    arc_1_5_12  original_T_including_depot_unload_1061  1.0195890294186160e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_12  arc_capacity_711  1
    load_1_5_12  segment_load_conservation_986  1
    load_1_5_12  free_load_conservation_1015  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_13  arc_capacity_713  -25
    arc_1_5_13  connected_order_arc_714  -13
    arc_1_5_13  out_degree_982  1
    arc_1_5_13  in_degree_1017  1
    arc_1_5_13  original_T_including_depot_unload_1061  1.0738353745204206e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_13  arc_capacity_713  1
    load_1_5_13  segment_load_conservation_986  1
    load_1_5_13  free_load_conservation_1021  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_14  arc_capacity_715  -25
    arc_1_5_14  connected_order_arc_716  -13
    arc_1_5_14  out_degree_982  1
    arc_1_5_14  in_degree_1023  1
    arc_1_5_14  original_T_including_depot_unload_1061  2.2682175936128497e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_14  arc_capacity_715  1
    load_1_5_14  segment_load_conservation_986  1
    load_1_5_14  free_load_conservation_1027  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_15  arc_capacity_717  -25
    arc_1_5_15  connected_order_arc_718  -13
    arc_1_5_15  out_degree_982  1
    arc_1_5_15  in_degree_1029  1
    arc_1_5_15  original_T_including_depot_unload_1061  9.1810091557460953e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_5_15  arc_capacity_717  1
    load_1_5_15  segment_load_conservation_986  1
    load_1_5_15  free_load_conservation_1033  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_16  arc_capacity_719  -25
    arc_1_5_16  connected_order_arc_720  -13
    arc_1_5_16  out_degree_982  1
    arc_1_5_16  in_degree_1035  1
    arc_1_5_16  original_T_including_depot_unload_1061  1.4653145381016172e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_16  arc_capacity_719  1
    load_1_5_16  segment_load_conservation_986  1
    load_1_5_16  free_load_conservation_1039  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_17  arc_capacity_721  -25
    arc_1_5_17  connected_order_arc_722  -13
    arc_1_5_17  out_degree_982  1
    arc_1_5_17  in_degree_1041  1
    arc_1_5_17  original_T_including_depot_unload_1061  9.1847405672984632e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_5_17  arc_capacity_721  1
    load_1_5_17  segment_load_conservation_986  1
    load_1_5_17  free_load_conservation_1045  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_18  arc_capacity_723  -25
    arc_1_5_18  connected_order_arc_724  -13
    arc_1_5_18  out_degree_982  1
    arc_1_5_18  in_degree_1047  1
    arc_1_5_18  original_T_including_depot_unload_1061  1.6437981048195304e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_18  arc_capacity_723  1
    load_1_5_18  segment_load_conservation_986  1
    load_1_5_18  free_load_conservation_1051  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_19  arc_capacity_725  -25
    arc_1_5_19  connected_order_arc_726  -13
    arc_1_5_19  out_degree_982  1
    arc_1_5_19  in_degree_1053  1
    arc_1_5_19  original_T_including_depot_unload_1061  9.1749781390727367e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_5_19  arc_capacity_725  1
    load_1_5_19  segment_load_conservation_986  1
    load_1_5_19  free_load_conservation_1057  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_0  arc_capacity_727  -25
    arc_1_6_0  depot_return_or_bypass_981  1
    arc_1_6_0  out_degree_989  1
    arc_1_6_0  original_T_including_depot_unload_1061  1.4834116102542102e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_0  arc_capacity_727  1
    load_1_6_0  segment_load_conservation_993  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_5  arc_capacity_728  -25
    arc_1_6_5  connected_order_arc_729  -13
    arc_1_6_5  in_degree_983  1
    arc_1_6_5  out_degree_989  1
    arc_1_6_5  original_T_including_depot_unload_1061  2.1016283653335277e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_5  arc_capacity_728  1
    load_1_6_5  segment_load_conservation_986  -1
    load_1_6_5  segment_prefix_lb_987  1
    load_1_6_5  segment_prefix_ub_988  1
    load_1_6_5  segment_load_conservation_993  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_7  arc_capacity_730  -25
    arc_1_6_7  connected_order_arc_731  -13
    arc_1_6_7  out_degree_989  1
    arc_1_6_7  in_degree_997  1
    arc_1_6_7  original_T_including_depot_unload_1061  9.7352441264247466e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_7  arc_capacity_730  1
    load_1_6_7  segment_load_conservation_993  1
    load_1_6_7  segment_load_conservation_1000  -1
    load_1_6_7  segment_prefix_lb_1001  1
    load_1_6_7  segment_prefix_ub_1002  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_8  arc_capacity_732  -25
    arc_1_6_8  connected_order_arc_733  -13
    arc_1_6_8  out_degree_989  1
    arc_1_6_8  in_degree_1004  1
    arc_1_6_8  original_T_including_depot_unload_1061  1.2769578074048923e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_8  arc_capacity_732  1
    load_1_6_8  segment_load_conservation_993  1
    load_1_6_8  segment_load_conservation_1007  -1
    load_1_6_8  segment_prefix_lb_1008  1
    load_1_6_8  segment_prefix_ub_1009  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_12  arc_capacity_734  -25
    arc_1_6_12  connected_order_arc_735  -13
    arc_1_6_12  out_degree_989  1
    arc_1_6_12  in_degree_1011  1
    arc_1_6_12  original_T_including_depot_unload_1061  1.5727012897474963e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_12  arc_capacity_734  1
    load_1_6_12  segment_load_conservation_993  1
    load_1_6_12  free_load_conservation_1015  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_13  arc_capacity_736  -25
    arc_1_6_13  connected_order_arc_737  -13
    arc_1_6_13  out_degree_989  1
    arc_1_6_13  in_degree_1017  1
    arc_1_6_13  original_T_including_depot_unload_1061  1.6719633410042259e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_13  arc_capacity_736  1
    load_1_6_13  segment_load_conservation_993  1
    load_1_6_13  free_load_conservation_1021  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_14  arc_capacity_738  -25
    arc_1_6_14  connected_order_arc_739  -13
    arc_1_6_14  out_degree_989  1
    arc_1_6_14  in_degree_1023  1
    arc_1_6_14  original_T_including_depot_unload_1061  2.9790156048453791e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_14  arc_capacity_738  1
    load_1_6_14  segment_load_conservation_993  1
    load_1_6_14  free_load_conservation_1027  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_15  arc_capacity_740  -25
    arc_1_6_15  connected_order_arc_741  -13
    arc_1_6_15  out_degree_989  1
    arc_1_6_15  in_degree_1029  1
    arc_1_6_15  original_T_including_depot_unload_1061  1.3848663974280498e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_15  arc_capacity_740  1
    load_1_6_15  segment_load_conservation_993  1
    load_1_6_15  free_load_conservation_1033  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_16  arc_capacity_742  -25
    arc_1_6_16  connected_order_arc_743  -13
    arc_1_6_16  out_degree_989  1
    arc_1_6_16  in_degree_1035  1
    arc_1_6_16  original_T_including_depot_unload_1061  2.4321008933612479e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_16  arc_capacity_742  1
    load_1_6_16  segment_load_conservation_993  1
    load_1_6_16  free_load_conservation_1039  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_17  arc_capacity_744  -25
    arc_1_6_17  connected_order_arc_745  -13
    arc_1_6_17  out_degree_989  1
    arc_1_6_17  in_degree_1041  1
    arc_1_6_17  original_T_including_depot_unload_1061  1.3842338084916330e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_17  arc_capacity_744  1
    load_1_6_17  segment_load_conservation_993  1
    load_1_6_17  free_load_conservation_1045  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_18  arc_capacity_746  -25
    arc_1_6_18  connected_order_arc_747  -13
    arc_1_6_18  out_degree_989  1
    arc_1_6_18  in_degree_1047  1
    arc_1_6_18  original_T_including_depot_unload_1061  2.3444750474890211e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_18  arc_capacity_746  1
    load_1_6_18  segment_load_conservation_993  1
    load_1_6_18  free_load_conservation_1051  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_19  arc_capacity_748  -25
    arc_1_6_19  connected_order_arc_749  -13
    arc_1_6_19  out_degree_989  1
    arc_1_6_19  in_degree_1053  1
    arc_1_6_19  original_T_including_depot_unload_1061  1.3825747156698872e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_19  arc_capacity_748  1
    load_1_6_19  segment_load_conservation_993  1
    load_1_6_19  free_load_conservation_1057  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_0  arc_capacity_750  -25
    arc_1_7_0  depot_return_or_bypass_981  1
    arc_1_7_0  out_degree_996  1
    arc_1_7_0  original_T_including_depot_unload_1061  5.4911852608328161e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_0  arc_capacity_750  1
    load_1_7_0  segment_load_conservation_1000  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_5  arc_capacity_751  -25
    arc_1_7_5  connected_order_arc_752  -13
    arc_1_7_5  in_degree_983  1
    arc_1_7_5  out_degree_996  1
    arc_1_7_5  original_T_including_depot_unload_1061  1.2739580769060942e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_5  arc_capacity_751  1
    load_1_7_5  segment_load_conservation_986  -1
    load_1_7_5  segment_prefix_lb_987  1
    load_1_7_5  segment_prefix_ub_988  1
    load_1_7_5  segment_load_conservation_1000  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_6  arc_capacity_753  -25
    arc_1_7_6  connected_order_arc_754  -13
    arc_1_7_6  in_degree_990  1
    arc_1_7_6  out_degree_996  1
    arc_1_7_6  original_T_including_depot_unload_1061  9.7352441264247466e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_6  arc_capacity_753  1
    load_1_7_6  segment_load_conservation_993  -1
    load_1_7_6  segment_prefix_lb_994  1
    load_1_7_6  segment_prefix_ub_995  1
    load_1_7_6  segment_load_conservation_1000  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_8  arc_capacity_755  -25
    arc_1_7_8  connected_order_arc_756  -13
    arc_1_7_8  out_degree_996  1
    arc_1_7_8  in_degree_1004  1
    arc_1_7_8  original_T_including_depot_unload_1061  3.0614301781508658e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_8  arc_capacity_755  1
    load_1_7_8  segment_load_conservation_1000  1
    load_1_7_8  segment_load_conservation_1007  -1
    load_1_7_8  segment_prefix_lb_1008  1
    load_1_7_8  segment_prefix_ub_1009  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_12  arc_capacity_757  -25
    arc_1_7_12  connected_order_arc_758  -13
    arc_1_7_12  out_degree_996  1
    arc_1_7_12  in_degree_1011  1
    arc_1_7_12  original_T_including_depot_unload_1061  7.7752090265769914e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_12  arc_capacity_757  1
    load_1_7_12  segment_load_conservation_1000  1
    load_1_7_12  free_load_conservation_1015  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_13  arc_capacity_759  -25
    arc_1_7_13  connected_order_arc_760  -13
    arc_1_7_13  out_degree_996  1
    arc_1_7_13  in_degree_1017  1
    arc_1_7_13  original_T_including_depot_unload_1061  8.4865162627289658e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_13  arc_capacity_759  1
    load_1_7_13  segment_load_conservation_1000  1
    load_1_7_13  free_load_conservation_1021  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_14  arc_capacity_761  -25
    arc_1_7_14  connected_order_arc_762  -13
    arc_1_7_14  out_degree_996  1
    arc_1_7_14  in_degree_1023  1
    arc_1_7_14  original_T_including_depot_unload_1061  2.1109553693139742e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_14  arc_capacity_761  1
    load_1_7_14  segment_load_conservation_1000  1
    load_1_7_14  free_load_conservation_1027  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_15  arc_capacity_763  -25
    arc_1_7_15  connected_order_arc_764  -13
    arc_1_7_15  out_degree_996  1
    arc_1_7_15  in_degree_1029  1
    arc_1_7_15  original_T_including_depot_unload_1061  6.4832473911284285e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_15  arc_capacity_763  1
    load_1_7_15  segment_load_conservation_1000  1
    load_1_7_15  free_load_conservation_1033  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_16  arc_capacity_765  -25
    arc_1_7_16  connected_order_arc_766  -13
    arc_1_7_16  out_degree_996  1
    arc_1_7_16  in_degree_1035  1
    arc_1_7_16  original_T_including_depot_unload_1061  1.4586348268927468e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_16  arc_capacity_765  1
    load_1_7_16  segment_load_conservation_1000  1
    load_1_7_16  free_load_conservation_1039  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_17  arc_capacity_767  -25
    arc_1_7_17  connected_order_arc_768  -13
    arc_1_7_17  out_degree_996  1
    arc_1_7_17  in_degree_1041  1
    arc_1_7_17  original_T_including_depot_unload_1061  6.4850607840217310e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_17  arc_capacity_767  1
    load_1_7_17  segment_load_conservation_1000  1
    load_1_7_17  free_load_conservation_1045  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_18  arc_capacity_769  -25
    arc_1_7_18  connected_order_arc_770  -13
    arc_1_7_18  out_degree_996  1
    arc_1_7_18  in_degree_1047  1
    arc_1_7_18  original_T_including_depot_unload_1061  1.4738339199468992e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_18  arc_capacity_769  1
    load_1_7_18  segment_load_conservation_1000  1
    load_1_7_18  free_load_conservation_1051  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_19  arc_capacity_771  -25
    arc_1_7_19  connected_order_arc_772  -13
    arc_1_7_19  out_degree_996  1
    arc_1_7_19  in_degree_1053  1
    arc_1_7_19  original_T_including_depot_unload_1061  6.4732789246105290e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_19  arc_capacity_771  1
    load_1_7_19  segment_load_conservation_1000  1
    load_1_7_19  free_load_conservation_1057  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_0  arc_capacity_773  -25
    arc_1_8_0  depot_return_or_bypass_981  1
    arc_1_8_0  out_degree_1003  1
    arc_1_8_0  original_T_including_depot_unload_1061  3.5061909388980052e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_0  arc_capacity_773  1
    load_1_8_0  segment_load_conservation_1007  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_5  arc_capacity_774  -25
    arc_1_8_5  connected_order_arc_775  -13
    arc_1_8_5  in_degree_983  1
    arc_1_8_5  out_degree_1003  1
    arc_1_8_5  original_T_including_depot_unload_1061  1.0313568965059917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_5  arc_capacity_774  1
    load_1_8_5  segment_load_conservation_986  -1
    load_1_8_5  segment_prefix_lb_987  1
    load_1_8_5  segment_prefix_ub_988  1
    load_1_8_5  segment_load_conservation_1007  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_6  arc_capacity_776  -25
    arc_1_8_6  connected_order_arc_777  -13
    arc_1_8_6  in_degree_990  1
    arc_1_8_6  out_degree_1003  1
    arc_1_8_6  original_T_including_depot_unload_1061  1.2769578074048923e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_6  arc_capacity_776  1
    load_1_8_6  segment_load_conservation_993  -1
    load_1_8_6  segment_prefix_lb_994  1
    load_1_8_6  segment_prefix_ub_995  1
    load_1_8_6  segment_load_conservation_1007  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_7  arc_capacity_778  -25
    arc_1_8_7  connected_order_arc_779  -13
    arc_1_8_7  in_degree_997  1
    arc_1_8_7  out_degree_1003  1
    arc_1_8_7  original_T_including_depot_unload_1061  3.0614301781508658e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_7  arc_capacity_778  1
    load_1_8_7  segment_load_conservation_1000  -1
    load_1_8_7  segment_prefix_lb_1001  1
    load_1_8_7  segment_prefix_ub_1002  1
    load_1_8_7  segment_load_conservation_1007  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_12  arc_capacity_780  -25
    arc_1_8_12  connected_order_arc_781  -13
    arc_1_8_12  out_degree_1003  1
    arc_1_8_12  in_degree_1011  1
    arc_1_8_12  original_T_including_depot_unload_1061  685.13013884234
    MARKER    'MARKER'                 'INTEND'
    load_1_8_12  arc_capacity_780  1
    load_1_8_12  segment_load_conservation_1007  1
    load_1_8_12  free_load_conservation_1015  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_13  arc_capacity_782  -25
    arc_1_8_13  connected_order_arc_783  -13
    arc_1_8_13  out_degree_1003  1
    arc_1_8_13  in_degree_1017  1
    arc_1_8_13  original_T_including_depot_unload_1061  7.2196448570394080e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_13  arc_capacity_782  1
    load_1_8_13  segment_load_conservation_1007  1
    load_1_8_13  free_load_conservation_1021  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_14  arc_capacity_784  -25
    arc_1_8_14  connected_order_arc_785  -13
    arc_1_8_14  out_degree_1003  1
    arc_1_8_14  in_degree_1023  1
    arc_1_8_14  original_T_including_depot_unload_1061  1.8911324761641883e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_14  arc_capacity_784  1
    load_1_8_14  segment_load_conservation_1007  1
    load_1_8_14  free_load_conservation_1027  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_15  arc_capacity_786  -25
    arc_1_8_15  connected_order_arc_787  -13
    arc_1_8_15  out_degree_1003  1
    arc_1_8_15  in_degree_1029  1
    arc_1_8_15  original_T_including_depot_unload_1061  6.3046739375549225e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_15  arc_capacity_786  1
    load_1_8_15  segment_load_conservation_1007  1
    load_1_8_15  free_load_conservation_1033  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_16  arc_capacity_788  -25
    arc_1_8_16  connected_order_arc_789  -13
    arc_1_8_16  out_degree_1003  1
    arc_1_8_16  in_degree_1035  1
    arc_1_8_16  original_T_including_depot_unload_1061  1.1561945146971345e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_16  arc_capacity_788  1
    load_1_8_16  segment_load_conservation_1007  1
    load_1_8_16  free_load_conservation_1039  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_17  arc_capacity_790  -25
    arc_1_8_17  connected_order_arc_791  -13
    arc_1_8_17  out_degree_1003  1
    arc_1_8_17  in_degree_1041  1
    arc_1_8_17  original_T_including_depot_unload_1061  6.3119444979991374e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_17  arc_capacity_790  1
    load_1_8_17  segment_load_conservation_1007  1
    load_1_8_17  free_load_conservation_1045  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_18  arc_capacity_792  -25
    arc_1_8_18  connected_order_arc_793  -13
    arc_1_8_18  out_degree_1003  1
    arc_1_8_18  in_degree_1047  1
    arc_1_8_18  original_T_including_depot_unload_1061  1.2665309635243570e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_18  arc_capacity_792  1
    load_1_8_18  segment_load_conservation_1007  1
    load_1_8_18  free_load_conservation_1051  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_19  arc_capacity_794  -25
    arc_1_8_19  connected_order_arc_795  -13
    arc_1_8_19  out_degree_1003  1
    arc_1_8_19  in_degree_1053  1
    arc_1_8_19  original_T_including_depot_unload_1061  6.3069852135268593e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_19  arc_capacity_794  1
    load_1_8_19  segment_load_conservation_1007  1
    load_1_8_19  free_load_conservation_1057  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_0  arc_capacity_796  -25
    arc_1_12_0  depot_return_or_bypass_981  1
    arc_1_12_0  out_degree_1010  1
    arc_1_12_0  original_T_including_depot_unload_1061  3.6666597054112611e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_0  arc_capacity_796  1
    load_1_12_0  free_load_conservation_1015  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_5  arc_capacity_797  -25
    arc_1_12_5  connected_order_arc_798  -13
    arc_1_12_5  in_degree_983  1
    arc_1_12_5  out_degree_1010  1
    arc_1_12_5  original_T_including_depot_unload_1061  1.5428621806127467e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_5  arc_capacity_797  1
    load_1_12_5  segment_load_conservation_986  -1
    load_1_12_5  segment_prefix_lb_987  1
    load_1_12_5  segment_prefix_ub_988  1
    load_1_12_5  free_load_conservation_1015  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_6  arc_capacity_799  -25
    arc_1_12_6  connected_order_arc_800  -13
    arc_1_12_6  in_degree_990  1
    arc_1_12_6  out_degree_1010  1
    arc_1_12_6  original_T_including_depot_unload_1061  1.5727012897474963e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_6  arc_capacity_799  1
    load_1_12_6  segment_load_conservation_993  -1
    load_1_12_6  segment_prefix_lb_994  1
    load_1_12_6  segment_prefix_ub_995  1
    load_1_12_6  free_load_conservation_1015  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_7  arc_capacity_801  -25
    arc_1_12_7  connected_order_arc_802  -13
    arc_1_12_7  in_degree_997  1
    arc_1_12_7  out_degree_1010  1
    arc_1_12_7  original_T_including_depot_unload_1061  7.7752090265769914e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_7  arc_capacity_801  1
    load_1_12_7  segment_load_conservation_1000  -1
    load_1_12_7  segment_prefix_lb_1001  1
    load_1_12_7  segment_prefix_ub_1002  1
    load_1_12_7  free_load_conservation_1015  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_8  arc_capacity_803  -25
    arc_1_12_8  connected_order_arc_804  -13
    arc_1_12_8  in_degree_1004  1
    arc_1_12_8  out_degree_1010  1
    arc_1_12_8  original_T_including_depot_unload_1061  685.13013884234
    MARKER    'MARKER'                 'INTEND'
    load_1_12_8  arc_capacity_803  1
    load_1_12_8  segment_load_conservation_1007  -1
    load_1_12_8  segment_prefix_lb_1008  1
    load_1_12_8  segment_prefix_ub_1009  1
    load_1_12_8  free_load_conservation_1015  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_13  arc_capacity_805  -25
    arc_1_12_13  connected_order_arc_806  -13
    arc_1_12_13  out_degree_1010  1
    arc_1_12_13  in_degree_1017  1
    arc_1_12_13  original_T_including_depot_unload_1061  1.0605986491096120e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_13  arc_capacity_805  1
    load_1_12_13  free_load_conservation_1015  1
    load_1_12_13  free_load_conservation_1021  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_14  arc_capacity_807  -25
    arc_1_12_14  connected_order_arc_808  -13
    arc_1_12_14  out_degree_1010  1
    arc_1_12_14  in_degree_1023  1
    arc_1_12_14  original_T_including_depot_unload_1061  1.4066323818659139e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_14  arc_capacity_807  1
    load_1_12_14  free_load_conservation_1015  1
    load_1_12_14  free_load_conservation_1027  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_15  arc_capacity_809  -25
    arc_1_12_15  connected_order_arc_810  -13
    arc_1_12_15  out_degree_1010  1
    arc_1_12_15  in_degree_1029  1
    arc_1_12_15  original_T_including_depot_unload_1061  193.618232742121
    MARKER    'MARKER'                 'INTEND'
    load_1_12_15  arc_capacity_809  1
    load_1_12_15  free_load_conservation_1015  1
    load_1_12_15  free_load_conservation_1033  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_16  arc_capacity_811  -25
    arc_1_12_16  connected_order_arc_812  -13
    arc_1_12_16  out_degree_1010  1
    arc_1_12_16  in_degree_1035  1
    arc_1_12_16  original_T_including_depot_unload_1061  1.1737339836679257e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_16  arc_capacity_811  1
    load_1_12_16  free_load_conservation_1015  1
    load_1_12_16  free_load_conservation_1039  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_17  arc_capacity_813  -25
    arc_1_12_17  connected_order_arc_814  -13
    arc_1_12_17  out_degree_1010  1
    arc_1_12_17  in_degree_1041  1
    arc_1_12_17  original_T_including_depot_unload_1061  1.9450542613707577e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_17  arc_capacity_813  1
    load_1_12_17  free_load_conservation_1015  1
    load_1_12_17  free_load_conservation_1045  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_18  arc_capacity_815  -25
    arc_1_12_18  connected_order_arc_816  -13
    arc_1_12_18  out_degree_1010  1
    arc_1_12_18  in_degree_1047  1
    arc_1_12_18  original_T_including_depot_unload_1061  7.7620596437921665e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_18  arc_capacity_815  1
    load_1_12_18  free_load_conservation_1015  1
    load_1_12_18  free_load_conservation_1051  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_19  arc_capacity_817  -25
    arc_1_12_19  connected_order_arc_818  -13
    arc_1_12_19  out_degree_1010  1
    arc_1_12_19  in_degree_1053  1
    arc_1_12_19  original_T_including_depot_unload_1061  1.9614944290232185e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_19  arc_capacity_817  1
    load_1_12_19  free_load_conservation_1015  1
    load_1_12_19  free_load_conservation_1057  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_0  arc_capacity_819  -25
    arc_1_13_0  depot_return_or_bypass_981  1
    arc_1_13_0  out_degree_1016  1
    arc_1_13_0  original_T_including_depot_unload_1061  3.8060477410436619e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_0  arc_capacity_819  1
    load_1_13_0  free_load_conservation_1021  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_5  arc_capacity_820  -25
    arc_1_13_5  connected_order_arc_821  -13
    arc_1_13_5  in_degree_983  1
    arc_1_13_5  out_degree_1016  1
    arc_1_13_5  original_T_including_depot_unload_1061  1.5168242190367512e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_5  arc_capacity_820  1
    load_1_13_5  segment_load_conservation_986  -1
    load_1_13_5  segment_prefix_lb_987  1
    load_1_13_5  segment_prefix_ub_988  1
    load_1_13_5  free_load_conservation_1021  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_6  arc_capacity_822  -25
    arc_1_13_6  connected_order_arc_823  -13
    arc_1_13_6  in_degree_990  1
    arc_1_13_6  out_degree_1016  1
    arc_1_13_6  original_T_including_depot_unload_1061  1.6719633410042259e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_6  arc_capacity_822  1
    load_1_13_6  segment_load_conservation_993  -1
    load_1_13_6  segment_prefix_lb_994  1
    load_1_13_6  segment_prefix_ub_995  1
    load_1_13_6  free_load_conservation_1021  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_7  arc_capacity_824  -25
    arc_1_13_7  connected_order_arc_825  -13
    arc_1_13_7  in_degree_997  1
    arc_1_13_7  out_degree_1016  1
    arc_1_13_7  original_T_including_depot_unload_1061  8.4865162627289658e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_7  arc_capacity_824  1
    load_1_13_7  segment_load_conservation_1000  -1
    load_1_13_7  segment_prefix_lb_1001  1
    load_1_13_7  segment_prefix_ub_1002  1
    load_1_13_7  free_load_conservation_1021  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_8  arc_capacity_826  -25
    arc_1_13_8  connected_order_arc_827  -13
    arc_1_13_8  in_degree_1004  1
    arc_1_13_8  out_degree_1016  1
    arc_1_13_8  original_T_including_depot_unload_1061  7.2196448570394080e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_8  arc_capacity_826  1
    load_1_13_8  segment_load_conservation_1007  -1
    load_1_13_8  segment_prefix_lb_1008  1
    load_1_13_8  segment_prefix_ub_1009  1
    load_1_13_8  free_load_conservation_1021  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_12  arc_capacity_828  -25
    arc_1_13_12  connected_order_arc_829  -13
    arc_1_13_12  in_degree_1011  1
    arc_1_13_12  out_degree_1016  1
    arc_1_13_12  original_T_including_depot_unload_1061  1.0605986491096120e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_12  arc_capacity_828  1
    load_1_13_12  free_load_conservation_1015  -1
    load_1_13_12  free_load_conservation_1021  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_14  arc_capacity_830  -25
    arc_1_13_14  connected_order_arc_831  -13
    arc_1_13_14  out_degree_1016  1
    arc_1_13_14  in_degree_1023  1
    arc_1_13_14  original_T_including_depot_unload_1061  1.3072142379397485e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_14  arc_capacity_830  1
    load_1_13_14  free_load_conservation_1021  1
    load_1_13_14  free_load_conservation_1027  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_15  arc_capacity_832  -25
    arc_1_13_15  connected_order_arc_833  -13
    arc_1_13_15  out_degree_1016  1
    arc_1_13_15  in_degree_1029  1
    arc_1_13_15  original_T_including_depot_unload_1061  2.9898712977512486e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_15  arc_capacity_832  1
    load_1_13_15  free_load_conservation_1021  1
    load_1_13_15  free_load_conservation_1033  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_16  arc_capacity_834  -25
    arc_1_13_16  connected_order_arc_835  -13
    arc_1_13_16  out_degree_1016  1
    arc_1_13_16  in_degree_1035  1
    arc_1_13_16  original_T_including_depot_unload_1061  1.0882276141652012e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_16  arc_capacity_834  1
    load_1_13_16  free_load_conservation_1021  1
    load_1_13_16  free_load_conservation_1039  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_17  arc_capacity_836  -25
    arc_1_13_17  connected_order_arc_837  -13
    arc_1_13_17  out_degree_1016  1
    arc_1_13_17  in_degree_1041  1
    arc_1_13_17  original_T_including_depot_unload_1061  299.915584808525
    MARKER    'MARKER'                 'INTEND'
    load_1_13_17  arc_capacity_836  1
    load_1_13_17  free_load_conservation_1021  1
    load_1_13_17  free_load_conservation_1045  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_18  arc_capacity_838  -25
    arc_1_13_18  connected_order_arc_839  -13
    arc_1_13_18  out_degree_1016  1
    arc_1_13_18  in_degree_1047  1
    arc_1_13_18  original_T_including_depot_unload_1061  6.7368811350376711e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_18  arc_capacity_838  1
    load_1_13_18  free_load_conservation_1021  1
    load_1_13_18  free_load_conservation_1051  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_19  arc_capacity_840  -25
    arc_1_13_19  connected_order_arc_841  -13
    arc_1_13_19  out_degree_1016  1
    arc_1_13_19  in_degree_1053  1
    arc_1_13_19  original_T_including_depot_unload_1061  3.0154417050280659e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_19  arc_capacity_840  1
    load_1_13_19  free_load_conservation_1021  1
    load_1_13_19  free_load_conservation_1057  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_0  arc_capacity_842  -25
    arc_1_14_0  depot_return_or_bypass_981  1
    arc_1_14_0  out_degree_1022  1
    arc_1_14_0  original_T_including_depot_unload_1061  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_0  arc_capacity_842  1
    load_1_14_0  free_load_conservation_1027  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_5  arc_capacity_843  -25
    arc_1_14_5  connected_order_arc_844  -13
    arc_1_14_5  in_degree_983  1
    arc_1_14_5  out_degree_1022  1
    arc_1_14_5  original_T_including_depot_unload_1061  2.1501600514850211e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_5  arc_capacity_843  1
    load_1_14_5  segment_load_conservation_986  -1
    load_1_14_5  segment_prefix_lb_987  1
    load_1_14_5  segment_prefix_ub_988  1
    load_1_14_5  free_load_conservation_1027  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_6  arc_capacity_845  -25
    arc_1_14_6  connected_order_arc_846  -13
    arc_1_14_6  in_degree_990  1
    arc_1_14_6  out_degree_1022  1
    arc_1_14_6  original_T_including_depot_unload_1061  2.9790156048453791e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_6  arc_capacity_845  1
    load_1_14_6  segment_load_conservation_993  -1
    load_1_14_6  segment_prefix_lb_994  1
    load_1_14_6  segment_prefix_ub_995  1
    load_1_14_6  free_load_conservation_1027  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_7  arc_capacity_847  -25
    arc_1_14_7  connected_order_arc_848  -13
    arc_1_14_7  in_degree_997  1
    arc_1_14_7  out_degree_1022  1
    arc_1_14_7  original_T_including_depot_unload_1061  2.1109553693139742e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_7  arc_capacity_847  1
    load_1_14_7  segment_load_conservation_1000  -1
    load_1_14_7  segment_prefix_lb_1001  1
    load_1_14_7  segment_prefix_ub_1002  1
    load_1_14_7  free_load_conservation_1027  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_8  arc_capacity_849  -25
    arc_1_14_8  connected_order_arc_850  -13
    arc_1_14_8  in_degree_1004  1
    arc_1_14_8  out_degree_1022  1
    arc_1_14_8  original_T_including_depot_unload_1061  1.8911324761641883e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_8  arc_capacity_849  1
    load_1_14_8  segment_load_conservation_1007  -1
    load_1_14_8  segment_prefix_lb_1008  1
    load_1_14_8  segment_prefix_ub_1009  1
    load_1_14_8  free_load_conservation_1027  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_12  arc_capacity_851  -25
    arc_1_14_12  connected_order_arc_852  -13
    arc_1_14_12  in_degree_1011  1
    arc_1_14_12  out_degree_1022  1
    arc_1_14_12  original_T_including_depot_unload_1061  1.4066323818659139e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_12  arc_capacity_851  1
    load_1_14_12  free_load_conservation_1015  -1
    load_1_14_12  free_load_conservation_1027  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_13  arc_capacity_853  -25
    arc_1_14_13  connected_order_arc_854  -13
    arc_1_14_13  in_degree_1017  1
    arc_1_14_13  out_degree_1022  1
    arc_1_14_13  original_T_including_depot_unload_1061  1.3072142379397485e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_13  arc_capacity_853  1
    load_1_14_13  free_load_conservation_1021  -1
    load_1_14_13  free_load_conservation_1027  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_15  arc_capacity_855  -25
    arc_1_14_15  connected_order_arc_856  -13
    arc_1_14_15  out_degree_1022  1
    arc_1_14_15  in_degree_1029  1
    arc_1_14_15  original_T_including_depot_unload_1061  1.5968425841449753e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_15  arc_capacity_855  1
    load_1_14_15  free_load_conservation_1027  1
    load_1_14_15  free_load_conservation_1033  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_16  arc_capacity_857  -25
    arc_1_14_16  connected_order_arc_858  -13
    arc_1_14_16  out_degree_1022  1
    arc_1_14_16  in_degree_1035  1
    arc_1_14_16  original_T_including_depot_unload_1061  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_16  arc_capacity_857  1
    load_1_14_16  free_load_conservation_1027  1
    load_1_14_16  free_load_conservation_1039  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_17  arc_capacity_859  -25
    arc_1_14_17  connected_order_arc_860  -13
    arc_1_14_17  out_degree_1022  1
    arc_1_14_17  in_degree_1041  1
    arc_1_14_17  original_T_including_depot_unload_1061  1.5975637706723310e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_17  arc_capacity_859  1
    load_1_14_17  free_load_conservation_1027  1
    load_1_14_17  free_load_conservation_1045  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_18  arc_capacity_861  -25
    arc_1_14_18  connected_order_arc_862  -13
    arc_1_14_18  out_degree_1022  1
    arc_1_14_18  in_degree_1047  1
    arc_1_14_18  original_T_including_depot_unload_1061  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_1_14_18  arc_capacity_861  1
    load_1_14_18  free_load_conservation_1027  1
    load_1_14_18  free_load_conservation_1051  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_19  arc_capacity_863  -25
    arc_1_14_19  connected_order_arc_864  -13
    arc_1_14_19  out_degree_1022  1
    arc_1_14_19  in_degree_1053  1
    arc_1_14_19  original_T_including_depot_unload_1061  1.5992308845216928e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_19  arc_capacity_863  1
    load_1_14_19  free_load_conservation_1027  1
    load_1_14_19  free_load_conservation_1057  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_0  arc_capacity_865  -25
    arc_1_15_0  depot_return_or_bypass_981  1
    arc_1_15_0  out_degree_1028  1
    arc_1_15_0  original_T_including_depot_unload_1061  391.582148421393
    MARKER    'MARKER'                 'INTEND'
    load_1_15_0  arc_capacity_865  1
    load_1_15_0  free_load_conservation_1033  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_5  arc_capacity_866  -25
    arc_1_15_5  connected_order_arc_867  -13
    arc_1_15_5  in_degree_983  1
    arc_1_15_5  out_degree_1028  1
    arc_1_15_5  original_T_including_depot_unload_1061  1.5814425672683194e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_5  arc_capacity_866  1
    load_1_15_5  segment_load_conservation_986  -1
    load_1_15_5  segment_prefix_lb_987  1
    load_1_15_5  segment_prefix_ub_988  1
    load_1_15_5  free_load_conservation_1033  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_6  arc_capacity_868  -25
    arc_1_15_6  connected_order_arc_869  -13
    arc_1_15_6  in_degree_990  1
    arc_1_15_6  out_degree_1028  1
    arc_1_15_6  original_T_including_depot_unload_1061  1.3848663974280498e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_6  arc_capacity_868  1
    load_1_15_6  segment_load_conservation_993  -1
    load_1_15_6  segment_prefix_lb_994  1
    load_1_15_6  segment_prefix_ub_995  1
    load_1_15_6  free_load_conservation_1033  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_7  arc_capacity_870  -25
    arc_1_15_7  connected_order_arc_871  -13
    arc_1_15_7  in_degree_997  1
    arc_1_15_7  out_degree_1028  1
    arc_1_15_7  original_T_including_depot_unload_1061  6.4832473911284285e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_7  arc_capacity_870  1
    load_1_15_7  segment_load_conservation_1000  -1
    load_1_15_7  segment_prefix_lb_1001  1
    load_1_15_7  segment_prefix_ub_1002  1
    load_1_15_7  free_load_conservation_1033  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_8  arc_capacity_872  -25
    arc_1_15_8  connected_order_arc_873  -13
    arc_1_15_8  in_degree_1004  1
    arc_1_15_8  out_degree_1028  1
    arc_1_15_8  original_T_including_depot_unload_1061  6.3046739375549225e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_8  arc_capacity_872  1
    load_1_15_8  segment_load_conservation_1007  -1
    load_1_15_8  segment_prefix_lb_1008  1
    load_1_15_8  segment_prefix_ub_1009  1
    load_1_15_8  free_load_conservation_1033  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_12  arc_capacity_874  -25
    arc_1_15_12  connected_order_arc_875  -13
    arc_1_15_12  in_degree_1011  1
    arc_1_15_12  out_degree_1028  1
    arc_1_15_12  original_T_including_depot_unload_1061  193.618232742121
    MARKER    'MARKER'                 'INTEND'
    load_1_15_12  arc_capacity_874  1
    load_1_15_12  free_load_conservation_1015  -1
    load_1_15_12  free_load_conservation_1033  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_13  arc_capacity_876  -25
    arc_1_15_13  connected_order_arc_877  -13
    arc_1_15_13  in_degree_1017  1
    arc_1_15_13  out_degree_1028  1
    arc_1_15_13  original_T_including_depot_unload_1061  2.9898712977512486e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_13  arc_capacity_876  1
    load_1_15_13  free_load_conservation_1021  -1
    load_1_15_13  free_load_conservation_1033  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_14  arc_capacity_878  -25
    arc_1_15_14  connected_order_arc_879  -13
    arc_1_15_14  in_degree_1023  1
    arc_1_15_14  out_degree_1028  1
    arc_1_15_14  original_T_including_depot_unload_1061  1.5968425841449753e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_14  arc_capacity_878  1
    load_1_15_14  free_load_conservation_1027  -1
    load_1_15_14  free_load_conservation_1033  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_16  arc_capacity_880  -25
    arc_1_15_16  connected_order_arc_881  -13
    arc_1_15_16  out_degree_1028  1
    arc_1_15_16  in_degree_1035  1
    arc_1_15_16  original_T_including_depot_unload_1061  1.3222534044746537e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_16  arc_capacity_880  1
    load_1_15_16  free_load_conservation_1033  1
    load_1_15_16  free_load_conservation_1039  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_17  arc_capacity_882  -25
    arc_1_15_17  connected_order_arc_883  -13
    arc_1_15_17  out_degree_1028  1
    arc_1_15_17  in_degree_1041  1
    arc_1_15_17  original_T_including_depot_unload_1061  1.2340243107914335e+00
    MARKER    'MARKER'                 'INTEND'
    load_1_15_17  arc_capacity_882  1
    load_1_15_17  free_load_conservation_1033  1
    load_1_15_17  free_load_conservation_1045  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_18  arc_capacity_884  -25
    arc_1_15_18  connected_order_arc_885  -13
    arc_1_15_18  out_degree_1028  1
    arc_1_15_18  in_degree_1047  1
    arc_1_15_18  original_T_including_depot_unload_1061  9.6906528258679839e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_18  arc_capacity_884  1
    load_1_15_18  free_load_conservation_1033  1
    load_1_15_18  free_load_conservation_1051  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_19  arc_capacity_886  -25
    arc_1_15_19  connected_order_arc_887  -13
    arc_1_15_19  out_degree_1028  1
    arc_1_15_19  in_degree_1053  1
    arc_1_15_19  original_T_including_depot_unload_1061  2.5978621120511871e+00
    MARKER    'MARKER'                 'INTEND'
    load_1_15_19  arc_capacity_886  1
    load_1_15_19  free_load_conservation_1033  1
    load_1_15_19  free_load_conservation_1057  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_0  arc_capacity_888  -25
    arc_1_16_0  depot_return_or_bypass_981  1
    arc_1_16_0  out_degree_1034  1
    arc_1_16_0  original_T_including_depot_unload_1061  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_0  arc_capacity_888  1
    load_1_16_0  free_load_conservation_1039  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_5  arc_capacity_889  -25
    arc_1_16_5  connected_order_arc_890  -13
    arc_1_16_5  in_degree_983  1
    arc_1_16_5  out_degree_1034  1
    arc_1_16_5  original_T_including_depot_unload_1061  9.7453518552189382e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_5  arc_capacity_889  1
    load_1_16_5  segment_load_conservation_986  -1
    load_1_16_5  segment_prefix_lb_987  1
    load_1_16_5  segment_prefix_ub_988  1
    load_1_16_5  free_load_conservation_1039  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_6  arc_capacity_891  -25
    arc_1_16_6  connected_order_arc_892  -13
    arc_1_16_6  in_degree_990  1
    arc_1_16_6  out_degree_1034  1
    arc_1_16_6  original_T_including_depot_unload_1061  2.4321008933612479e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_6  arc_capacity_891  1
    load_1_16_6  segment_load_conservation_993  -1
    load_1_16_6  segment_prefix_lb_994  1
    load_1_16_6  segment_prefix_ub_995  1
    load_1_16_6  free_load_conservation_1039  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_7  arc_capacity_893  -25
    arc_1_16_7  connected_order_arc_894  -13
    arc_1_16_7  in_degree_997  1
    arc_1_16_7  out_degree_1034  1
    arc_1_16_7  original_T_including_depot_unload_1061  1.4586348268927468e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_7  arc_capacity_893  1
    load_1_16_7  segment_load_conservation_1000  -1
    load_1_16_7  segment_prefix_lb_1001  1
    load_1_16_7  segment_prefix_ub_1002  1
    load_1_16_7  free_load_conservation_1039  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_8  arc_capacity_895  -25
    arc_1_16_8  connected_order_arc_896  -13
    arc_1_16_8  in_degree_1004  1
    arc_1_16_8  out_degree_1034  1
    arc_1_16_8  original_T_including_depot_unload_1061  1.1561945146971345e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_8  arc_capacity_895  1
    load_1_16_8  segment_load_conservation_1007  -1
    load_1_16_8  segment_prefix_lb_1008  1
    load_1_16_8  segment_prefix_ub_1009  1
    load_1_16_8  free_load_conservation_1039  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_12  arc_capacity_897  -25
    arc_1_16_12  connected_order_arc_898  -13
    arc_1_16_12  in_degree_1011  1
    arc_1_16_12  out_degree_1034  1
    arc_1_16_12  original_T_including_depot_unload_1061  1.1737339836679257e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_12  arc_capacity_897  1
    load_1_16_12  free_load_conservation_1015  -1
    load_1_16_12  free_load_conservation_1039  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_13  arc_capacity_899  -25
    arc_1_16_13  connected_order_arc_900  -13
    arc_1_16_13  in_degree_1017  1
    arc_1_16_13  out_degree_1034  1
    arc_1_16_13  original_T_including_depot_unload_1061  1.0882276141652012e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_13  arc_capacity_899  1
    load_1_16_13  free_load_conservation_1021  -1
    load_1_16_13  free_load_conservation_1039  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_14  arc_capacity_901  -25
    arc_1_16_14  connected_order_arc_902  -13
    arc_1_16_14  in_degree_1023  1
    arc_1_16_14  out_degree_1034  1
    arc_1_16_14  original_T_including_depot_unload_1061  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_14  arc_capacity_901  1
    load_1_16_14  free_load_conservation_1027  -1
    load_1_16_14  free_load_conservation_1039  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_15  arc_capacity_903  -25
    arc_1_16_15  connected_order_arc_904  -13
    arc_1_16_15  in_degree_1029  1
    arc_1_16_15  out_degree_1034  1
    arc_1_16_15  original_T_including_depot_unload_1061  1.3222534044746537e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_15  arc_capacity_903  1
    load_1_16_15  free_load_conservation_1033  -1
    load_1_16_15  free_load_conservation_1039  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_17  arc_capacity_905  -25
    arc_1_16_17  connected_order_arc_906  -13
    arc_1_16_17  out_degree_1034  1
    arc_1_16_17  in_degree_1041  1
    arc_1_16_17  original_T_including_depot_unload_1061  1.3234781764513652e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_17  arc_capacity_905  1
    load_1_16_17  free_load_conservation_1039  1
    load_1_16_17  free_load_conservation_1045  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_18  arc_capacity_907  -25
    arc_1_16_18  connected_order_arc_908  -13
    arc_1_16_18  out_degree_1034  1
    arc_1_16_18  in_degree_1047  1
    arc_1_16_18  original_T_including_depot_unload_1061  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_18  arc_capacity_907  1
    load_1_16_18  free_load_conservation_1039  1
    load_1_16_18  free_load_conservation_1051  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_19  arc_capacity_909  -25
    arc_1_16_19  connected_order_arc_910  -13
    arc_1_16_19  out_degree_1034  1
    arc_1_16_19  in_degree_1053  1
    arc_1_16_19  original_T_including_depot_unload_1061  1.3246263055739521e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_19  arc_capacity_909  1
    load_1_16_19  free_load_conservation_1039  1
    load_1_16_19  free_load_conservation_1057  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_0  arc_capacity_911  -25
    arc_1_17_0  depot_return_or_bypass_981  1
    arc_1_17_0  out_degree_1040  1
    arc_1_17_0  original_T_including_depot_unload_1061  3.9270969537253126e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_0  arc_capacity_911  1
    load_1_17_0  free_load_conservation_1045  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_5  arc_capacity_912  -25
    arc_1_17_5  connected_order_arc_913  -13
    arc_1_17_5  in_degree_983  1
    arc_1_17_5  out_degree_1040  1
    arc_1_17_5  original_T_including_depot_unload_1061  1.5825017171049274e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_5  arc_capacity_912  1
    load_1_17_5  segment_load_conservation_986  -1
    load_1_17_5  segment_prefix_lb_987  1
    load_1_17_5  segment_prefix_ub_988  1
    load_1_17_5  free_load_conservation_1045  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_6  arc_capacity_914  -25
    arc_1_17_6  connected_order_arc_915  -13
    arc_1_17_6  in_degree_990  1
    arc_1_17_6  out_degree_1040  1
    arc_1_17_6  original_T_including_depot_unload_1061  1.3842338084916330e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_6  arc_capacity_914  1
    load_1_17_6  segment_load_conservation_993  -1
    load_1_17_6  segment_prefix_lb_994  1
    load_1_17_6  segment_prefix_ub_995  1
    load_1_17_6  free_load_conservation_1045  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_7  arc_capacity_916  -25
    arc_1_17_7  connected_order_arc_917  -13
    arc_1_17_7  in_degree_997  1
    arc_1_17_7  out_degree_1040  1
    arc_1_17_7  original_T_including_depot_unload_1061  6.4850607840217310e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_7  arc_capacity_916  1
    load_1_17_7  segment_load_conservation_1000  -1
    load_1_17_7  segment_prefix_lb_1001  1
    load_1_17_7  segment_prefix_ub_1002  1
    load_1_17_7  free_load_conservation_1045  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_8  arc_capacity_918  -25
    arc_1_17_8  connected_order_arc_919  -13
    arc_1_17_8  in_degree_1004  1
    arc_1_17_8  out_degree_1040  1
    arc_1_17_8  original_T_including_depot_unload_1061  6.3119444979991374e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_8  arc_capacity_918  1
    load_1_17_8  segment_load_conservation_1007  -1
    load_1_17_8  segment_prefix_lb_1008  1
    load_1_17_8  segment_prefix_ub_1009  1
    load_1_17_8  free_load_conservation_1045  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_12  arc_capacity_920  -25
    arc_1_17_12  connected_order_arc_921  -13
    arc_1_17_12  in_degree_1011  1
    arc_1_17_12  out_degree_1040  1
    arc_1_17_12  original_T_including_depot_unload_1061  1.9450542613707577e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_12  arc_capacity_920  1
    load_1_17_12  free_load_conservation_1015  -1
    load_1_17_12  free_load_conservation_1045  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_13  arc_capacity_922  -25
    arc_1_17_13  connected_order_arc_923  -13
    arc_1_17_13  in_degree_1017  1
    arc_1_17_13  out_degree_1040  1
    arc_1_17_13  original_T_including_depot_unload_1061  299.915584808525
    MARKER    'MARKER'                 'INTEND'
    load_1_17_13  arc_capacity_922  1
    load_1_17_13  free_load_conservation_1021  -1
    load_1_17_13  free_load_conservation_1045  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_14  arc_capacity_924  -25
    arc_1_17_14  connected_order_arc_925  -13
    arc_1_17_14  in_degree_1023  1
    arc_1_17_14  out_degree_1040  1
    arc_1_17_14  original_T_including_depot_unload_1061  1.5975637706723310e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_14  arc_capacity_924  1
    load_1_17_14  free_load_conservation_1027  -1
    load_1_17_14  free_load_conservation_1045  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_15  arc_capacity_926  -25
    arc_1_17_15  connected_order_arc_927  -13
    arc_1_17_15  in_degree_1029  1
    arc_1_17_15  out_degree_1040  1
    arc_1_17_15  original_T_including_depot_unload_1061  1.2340243107914335e+00
    MARKER    'MARKER'                 'INTEND'
    load_1_17_15  arc_capacity_926  1
    load_1_17_15  free_load_conservation_1033  -1
    load_1_17_15  free_load_conservation_1045  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_16  arc_capacity_928  -25
    arc_1_17_16  connected_order_arc_929  -13
    arc_1_17_16  in_degree_1035  1
    arc_1_17_16  out_degree_1040  1
    arc_1_17_16  original_T_including_depot_unload_1061  1.3234781764513652e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_16  arc_capacity_928  1
    load_1_17_16  free_load_conservation_1039  -1
    load_1_17_16  free_load_conservation_1045  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_18  arc_capacity_930  -25
    arc_1_17_18  connected_order_arc_931  -13
    arc_1_17_18  out_degree_1040  1
    arc_1_17_18  in_degree_1047  1
    arc_1_17_18  original_T_including_depot_unload_1061  9.6988018824317578e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_18  arc_capacity_930  1
    load_1_17_18  free_load_conservation_1045  1
    load_1_17_18  free_load_conservation_1051  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_19  arc_capacity_932  -25
    arc_1_17_19  connected_order_arc_933  -13
    arc_1_17_19  out_degree_1040  1
    arc_1_17_19  in_degree_1053  1
    arc_1_17_19  original_T_including_depot_unload_1061  1.6672379018690657e+00
    MARKER    'MARKER'                 'INTEND'
    load_1_17_19  arc_capacity_932  1
    load_1_17_19  free_load_conservation_1045  1
    load_1_17_19  free_load_conservation_1057  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_0  arc_capacity_934  -25
    arc_1_18_0  depot_return_or_bypass_981  1
    arc_1_18_0  out_degree_1046  1
    arc_1_18_0  original_T_including_depot_unload_1061  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_0  arc_capacity_934  1
    load_1_18_0  free_load_conservation_1051  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_5  arc_capacity_935  -25
    arc_1_18_5  connected_order_arc_936  -13
    arc_1_18_5  in_degree_983  1
    arc_1_18_5  out_degree_1046  1
    arc_1_18_5  original_T_including_depot_unload_1061  1.6988291947636669e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_5  arc_capacity_935  1
    load_1_18_5  segment_load_conservation_986  -1
    load_1_18_5  segment_prefix_lb_987  1
    load_1_18_5  segment_prefix_ub_988  1
    load_1_18_5  free_load_conservation_1051  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_6  arc_capacity_937  -25
    arc_1_18_6  connected_order_arc_938  -13
    arc_1_18_6  in_degree_990  1
    arc_1_18_6  out_degree_1046  1
    arc_1_18_6  original_T_including_depot_unload_1061  2.3444750474890211e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_6  arc_capacity_937  1
    load_1_18_6  segment_load_conservation_993  -1
    load_1_18_6  segment_prefix_lb_994  1
    load_1_18_6  segment_prefix_ub_995  1
    load_1_18_6  free_load_conservation_1051  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_7  arc_capacity_939  -25
    arc_1_18_7  connected_order_arc_940  -13
    arc_1_18_7  in_degree_997  1
    arc_1_18_7  out_degree_1046  1
    arc_1_18_7  original_T_including_depot_unload_1061  1.4738339199468992e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_7  arc_capacity_939  1
    load_1_18_7  segment_load_conservation_1000  -1
    load_1_18_7  segment_prefix_lb_1001  1
    load_1_18_7  segment_prefix_ub_1002  1
    load_1_18_7  free_load_conservation_1051  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_8  arc_capacity_941  -25
    arc_1_18_8  connected_order_arc_942  -13
    arc_1_18_8  in_degree_1004  1
    arc_1_18_8  out_degree_1046  1
    arc_1_18_8  original_T_including_depot_unload_1061  1.2665309635243570e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_8  arc_capacity_941  1
    load_1_18_8  segment_load_conservation_1007  -1
    load_1_18_8  segment_prefix_lb_1008  1
    load_1_18_8  segment_prefix_ub_1009  1
    load_1_18_8  free_load_conservation_1051  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_12  arc_capacity_943  -25
    arc_1_18_12  connected_order_arc_944  -13
    arc_1_18_12  in_degree_1011  1
    arc_1_18_12  out_degree_1046  1
    arc_1_18_12  original_T_including_depot_unload_1061  7.7620596437921665e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_12  arc_capacity_943  1
    load_1_18_12  free_load_conservation_1015  -1
    load_1_18_12  free_load_conservation_1051  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_13  arc_capacity_945  -25
    arc_1_18_13  connected_order_arc_946  -13
    arc_1_18_13  in_degree_1017  1
    arc_1_18_13  out_degree_1046  1
    arc_1_18_13  original_T_including_depot_unload_1061  6.7368811350376711e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_13  arc_capacity_945  1
    load_1_18_13  free_load_conservation_1021  -1
    load_1_18_13  free_load_conservation_1051  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_14  arc_capacity_947  -25
    arc_1_18_14  connected_order_arc_948  -13
    arc_1_18_14  in_degree_1023  1
    arc_1_18_14  out_degree_1046  1
    arc_1_18_14  original_T_including_depot_unload_1061  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_1_18_14  arc_capacity_947  1
    load_1_18_14  free_load_conservation_1027  -1
    load_1_18_14  free_load_conservation_1051  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_15  arc_capacity_949  -25
    arc_1_18_15  connected_order_arc_950  -13
    arc_1_18_15  in_degree_1029  1
    arc_1_18_15  out_degree_1046  1
    arc_1_18_15  original_T_including_depot_unload_1061  9.6906528258679839e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_15  arc_capacity_949  1
    load_1_18_15  free_load_conservation_1033  -1
    load_1_18_15  free_load_conservation_1051  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_16  arc_capacity_951  -25
    arc_1_18_16  connected_order_arc_952  -13
    arc_1_18_16  in_degree_1035  1
    arc_1_18_16  out_degree_1046  1
    arc_1_18_16  original_T_including_depot_unload_1061  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_16  arc_capacity_951  1
    load_1_18_16  free_load_conservation_1039  -1
    load_1_18_16  free_load_conservation_1051  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_17  arc_capacity_953  -25
    arc_1_18_17  connected_order_arc_954  -13
    arc_1_18_17  in_degree_1041  1
    arc_1_18_17  out_degree_1046  1
    arc_1_18_17  original_T_including_depot_unload_1061  9.6988018824317578e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_17  arc_capacity_953  1
    load_1_18_17  free_load_conservation_1045  -1
    load_1_18_17  free_load_conservation_1051  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_19  arc_capacity_955  -25
    arc_1_18_19  connected_order_arc_956  -13
    arc_1_18_19  out_degree_1046  1
    arc_1_18_19  in_degree_1053  1
    arc_1_18_19  original_T_including_depot_unload_1061  9.7154140307447824e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_19  arc_capacity_955  1
    load_1_18_19  free_load_conservation_1051  1
    load_1_18_19  free_load_conservation_1057  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_0  arc_capacity_957  -25
    arc_1_19_0  depot_return_or_bypass_981  1
    arc_1_19_0  out_degree_1052  1
    arc_1_19_0  original_T_including_depot_unload_1061  3.9307504957585564e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_0  arc_capacity_957  1
    load_1_19_0  free_load_conservation_1057  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_5  arc_capacity_958  -25
    arc_1_19_5  connected_order_arc_959  -13
    arc_1_19_5  in_degree_983  1
    arc_1_19_5  out_degree_1052  1
    arc_1_19_5  original_T_including_depot_unload_1061  1.5826657352191260e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_5  arc_capacity_958  1
    load_1_19_5  segment_load_conservation_986  -1
    load_1_19_5  segment_prefix_lb_987  1
    load_1_19_5  segment_prefix_ub_988  1
    load_1_19_5  free_load_conservation_1057  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_6  arc_capacity_960  -25
    arc_1_19_6  connected_order_arc_961  -13
    arc_1_19_6  in_degree_990  1
    arc_1_19_6  out_degree_1052  1
    arc_1_19_6  original_T_including_depot_unload_1061  1.3825747156698872e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_6  arc_capacity_960  1
    load_1_19_6  segment_load_conservation_993  -1
    load_1_19_6  segment_prefix_lb_994  1
    load_1_19_6  segment_prefix_ub_995  1
    load_1_19_6  free_load_conservation_1057  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_7  arc_capacity_962  -25
    arc_1_19_7  connected_order_arc_963  -13
    arc_1_19_7  in_degree_997  1
    arc_1_19_7  out_degree_1052  1
    arc_1_19_7  original_T_including_depot_unload_1061  6.4732789246105290e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_7  arc_capacity_962  1
    load_1_19_7  segment_load_conservation_1000  -1
    load_1_19_7  segment_prefix_lb_1001  1
    load_1_19_7  segment_prefix_ub_1002  1
    load_1_19_7  free_load_conservation_1057  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_8  arc_capacity_964  -25
    arc_1_19_8  connected_order_arc_965  -13
    arc_1_19_8  in_degree_1004  1
    arc_1_19_8  out_degree_1052  1
    arc_1_19_8  original_T_including_depot_unload_1061  6.3069852135268593e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_8  arc_capacity_964  1
    load_1_19_8  segment_load_conservation_1007  -1
    load_1_19_8  segment_prefix_lb_1008  1
    load_1_19_8  segment_prefix_ub_1009  1
    load_1_19_8  free_load_conservation_1057  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_12  arc_capacity_966  -25
    arc_1_19_12  connected_order_arc_967  -13
    arc_1_19_12  in_degree_1011  1
    arc_1_19_12  out_degree_1052  1
    arc_1_19_12  original_T_including_depot_unload_1061  1.9614944290232185e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_12  arc_capacity_966  1
    load_1_19_12  free_load_conservation_1015  -1
    load_1_19_12  free_load_conservation_1057  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_13  arc_capacity_968  -25
    arc_1_19_13  connected_order_arc_969  -13
    arc_1_19_13  in_degree_1017  1
    arc_1_19_13  out_degree_1052  1
    arc_1_19_13  original_T_including_depot_unload_1061  3.0154417050280659e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_13  arc_capacity_968  1
    load_1_19_13  free_load_conservation_1021  -1
    load_1_19_13  free_load_conservation_1057  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_14  arc_capacity_970  -25
    arc_1_19_14  connected_order_arc_971  -13
    arc_1_19_14  in_degree_1023  1
    arc_1_19_14  out_degree_1052  1
    arc_1_19_14  original_T_including_depot_unload_1061  1.5992308845216928e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_14  arc_capacity_970  1
    load_1_19_14  free_load_conservation_1027  -1
    load_1_19_14  free_load_conservation_1057  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_15  arc_capacity_972  -25
    arc_1_19_15  connected_order_arc_973  -13
    arc_1_19_15  in_degree_1029  1
    arc_1_19_15  out_degree_1052  1
    arc_1_19_15  original_T_including_depot_unload_1061  2.5978621120511871e+00
    MARKER    'MARKER'                 'INTEND'
    load_1_19_15  arc_capacity_972  1
    load_1_19_15  free_load_conservation_1033  -1
    load_1_19_15  free_load_conservation_1057  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_16  arc_capacity_974  -25
    arc_1_19_16  connected_order_arc_975  -13
    arc_1_19_16  in_degree_1035  1
    arc_1_19_16  out_degree_1052  1
    arc_1_19_16  original_T_including_depot_unload_1061  1.3246263055739521e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_16  arc_capacity_974  1
    load_1_19_16  free_load_conservation_1039  -1
    load_1_19_16  free_load_conservation_1057  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_17  arc_capacity_976  -25
    arc_1_19_17  connected_order_arc_977  -13
    arc_1_19_17  in_degree_1041  1
    arc_1_19_17  out_degree_1052  1
    arc_1_19_17  original_T_including_depot_unload_1061  1.6672379018690657e+00
    MARKER    'MARKER'                 'INTEND'
    load_1_19_17  arc_capacity_976  1
    load_1_19_17  free_load_conservation_1045  -1
    load_1_19_17  free_load_conservation_1057  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_18  arc_capacity_978  -25
    arc_1_19_18  connected_order_arc_979  -13
    arc_1_19_18  in_degree_1047  1
    arc_1_19_18  out_degree_1052  1
    arc_1_19_18  original_T_including_depot_unload_1061  9.7154140307447824e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_18  arc_capacity_978  1
    load_1_19_18  free_load_conservation_1051  -1
    load_1_19_18  free_load_conservation_1057  1
    visit_2_9  out_degree_1307  -1
    visit_2_9  in_degree_1308  -1
    visit_2_9  order_active_lb_1309  -1
    visit_2_9  order_active_ub_1310  -11
    order_2_9  connected_order_arc_1076  -1
    order_2_9  connected_order_arc_1078  -1
    order_2_9  connected_order_arc_1080  -1
    order_2_9  connected_order_arc_1082  -1
    order_2_9  connected_order_arc_1084  -1
    order_2_9  connected_order_arc_1086  -1
    order_2_9  connected_order_arc_1088  -1
    order_2_9  connected_order_arc_1090  -1
    order_2_9  connected_order_arc_1092  -1
    order_2_9  connected_order_arc_1094  -1
    order_2_9  connected_order_arc_1097  1
    order_2_9  connected_order_arc_1118  1
    order_2_9  connected_order_arc_1139  1
    order_2_9  connected_order_arc_1160  1
    order_2_9  connected_order_arc_1181  1
    order_2_9  connected_order_arc_1202  1
    order_2_9  connected_order_arc_1223  1
    order_2_9  connected_order_arc_1244  1
    order_2_9  connected_order_arc_1265  1
    order_2_9  connected_order_arc_1286  1
    order_2_9  order_active_lb_1309  1
    order_2_9  order_active_ub_1310  1
    order_2_9  fixed_segment_relative_order_1376  -1
    visit_2_10  out_degree_1314  -1
    visit_2_10  in_degree_1315  -1
    visit_2_10  order_active_lb_1316  -1
    visit_2_10  order_active_ub_1317  -11
    order_2_10  connected_order_arc_1076  1
    order_2_10  connected_order_arc_1097  -1
    order_2_10  connected_order_arc_1099  -1
    order_2_10  connected_order_arc_1101  -1
    order_2_10  connected_order_arc_1103  -1
    order_2_10  connected_order_arc_1105  -1
    order_2_10  connected_order_arc_1107  -1
    order_2_10  connected_order_arc_1109  -1
    order_2_10  connected_order_arc_1111  -1
    order_2_10  connected_order_arc_1113  -1
    order_2_10  connected_order_arc_1115  -1
    order_2_10  connected_order_arc_1120  1
    order_2_10  connected_order_arc_1141  1
    order_2_10  connected_order_arc_1162  1
    order_2_10  connected_order_arc_1183  1
    order_2_10  connected_order_arc_1204  1
    order_2_10  connected_order_arc_1225  1
    order_2_10  connected_order_arc_1246  1
    order_2_10  connected_order_arc_1267  1
    order_2_10  connected_order_arc_1288  1
    order_2_10  order_active_lb_1316  1
    order_2_10  order_active_ub_1317  1
    order_2_10  fixed_segment_relative_order_1376  1
    order_2_10  fixed_segment_relative_order_1377  -1
    visit_2_11  out_degree_1321  -1
    visit_2_11  in_degree_1322  -1
    visit_2_11  order_active_lb_1323  -1
    visit_2_11  order_active_ub_1324  -11
    order_2_11  connected_order_arc_1078  1
    order_2_11  connected_order_arc_1099  1
    order_2_11  connected_order_arc_1118  -1
    order_2_11  connected_order_arc_1120  -1
    order_2_11  connected_order_arc_1122  -1
    order_2_11  connected_order_arc_1124  -1
    order_2_11  connected_order_arc_1126  -1
    order_2_11  connected_order_arc_1128  -1
    order_2_11  connected_order_arc_1130  -1
    order_2_11  connected_order_arc_1132  -1
    order_2_11  connected_order_arc_1134  -1
    order_2_11  connected_order_arc_1136  -1
    order_2_11  connected_order_arc_1143  1
    order_2_11  connected_order_arc_1164  1
    order_2_11  connected_order_arc_1185  1
    order_2_11  connected_order_arc_1206  1
    order_2_11  connected_order_arc_1227  1
    order_2_11  connected_order_arc_1248  1
    order_2_11  connected_order_arc_1269  1
    order_2_11  connected_order_arc_1290  1
    order_2_11  order_active_lb_1323  1
    order_2_11  order_active_ub_1324  1
    order_2_11  fixed_segment_relative_order_1377  1
    visit_2_12  out_degree_1328  -1
    visit_2_12  in_degree_1329  -1
    visit_2_12  order_active_lb_1330  -1
    visit_2_12  order_active_ub_1331  -11
    visit_2_12  service_visit_def_1332  -1
    order_2_12  connected_order_arc_1080  1
    order_2_12  connected_order_arc_1101  1
    order_2_12  connected_order_arc_1122  1
    order_2_12  connected_order_arc_1139  -1
    order_2_12  connected_order_arc_1141  -1
    order_2_12  connected_order_arc_1143  -1
    order_2_12  connected_order_arc_1145  -1
    order_2_12  connected_order_arc_1147  -1
    order_2_12  connected_order_arc_1149  -1
    order_2_12  connected_order_arc_1151  -1
    order_2_12  connected_order_arc_1153  -1
    order_2_12  connected_order_arc_1155  -1
    order_2_12  connected_order_arc_1157  -1
    order_2_12  connected_order_arc_1166  1
    order_2_12  connected_order_arc_1187  1
    order_2_12  connected_order_arc_1208  1
    order_2_12  connected_order_arc_1229  1
    order_2_12  connected_order_arc_1250  1
    order_2_12  connected_order_arc_1271  1
    order_2_12  connected_order_arc_1292  1
    order_2_12  order_active_lb_1330  1
    order_2_12  order_active_ub_1331  1
    visit_2_13  out_degree_1334  -1
    visit_2_13  in_degree_1335  -1
    visit_2_13  order_active_lb_1336  -1
    visit_2_13  order_active_ub_1337  -11
    visit_2_13  service_visit_def_1338  -1
    order_2_13  connected_order_arc_1082  1
    order_2_13  connected_order_arc_1103  1
    order_2_13  connected_order_arc_1124  1
    order_2_13  connected_order_arc_1145  1
    order_2_13  connected_order_arc_1160  -1
    order_2_13  connected_order_arc_1162  -1
    order_2_13  connected_order_arc_1164  -1
    order_2_13  connected_order_arc_1166  -1
    order_2_13  connected_order_arc_1168  -1
    order_2_13  connected_order_arc_1170  -1
    order_2_13  connected_order_arc_1172  -1
    order_2_13  connected_order_arc_1174  -1
    order_2_13  connected_order_arc_1176  -1
    order_2_13  connected_order_arc_1178  -1
    order_2_13  connected_order_arc_1189  1
    order_2_13  connected_order_arc_1210  1
    order_2_13  connected_order_arc_1231  1
    order_2_13  connected_order_arc_1252  1
    order_2_13  connected_order_arc_1273  1
    order_2_13  connected_order_arc_1294  1
    order_2_13  order_active_lb_1336  1
    order_2_13  order_active_ub_1337  1
    visit_2_14  out_degree_1340  -1
    visit_2_14  in_degree_1341  -1
    visit_2_14  order_active_lb_1342  -1
    visit_2_14  order_active_ub_1343  -11
    visit_2_14  service_visit_def_1344  -1
    order_2_14  connected_order_arc_1084  1
    order_2_14  connected_order_arc_1105  1
    order_2_14  connected_order_arc_1126  1
    order_2_14  connected_order_arc_1147  1
    order_2_14  connected_order_arc_1168  1
    order_2_14  connected_order_arc_1181  -1
    order_2_14  connected_order_arc_1183  -1
    order_2_14  connected_order_arc_1185  -1
    order_2_14  connected_order_arc_1187  -1
    order_2_14  connected_order_arc_1189  -1
    order_2_14  connected_order_arc_1191  -1
    order_2_14  connected_order_arc_1193  -1
    order_2_14  connected_order_arc_1195  -1
    order_2_14  connected_order_arc_1197  -1
    order_2_14  connected_order_arc_1199  -1
    order_2_14  connected_order_arc_1212  1
    order_2_14  connected_order_arc_1233  1
    order_2_14  connected_order_arc_1254  1
    order_2_14  connected_order_arc_1275  1
    order_2_14  connected_order_arc_1296  1
    order_2_14  order_active_lb_1342  1
    order_2_14  order_active_ub_1343  1
    visit_2_15  out_degree_1346  -1
    visit_2_15  in_degree_1347  -1
    visit_2_15  order_active_lb_1348  -1
    visit_2_15  order_active_ub_1349  -11
    visit_2_15  service_visit_def_1350  -1
    order_2_15  connected_order_arc_1086  1
    order_2_15  connected_order_arc_1107  1
    order_2_15  connected_order_arc_1128  1
    order_2_15  connected_order_arc_1149  1
    order_2_15  connected_order_arc_1170  1
    order_2_15  connected_order_arc_1191  1
    order_2_15  connected_order_arc_1202  -1
    order_2_15  connected_order_arc_1204  -1
    order_2_15  connected_order_arc_1206  -1
    order_2_15  connected_order_arc_1208  -1
    order_2_15  connected_order_arc_1210  -1
    order_2_15  connected_order_arc_1212  -1
    order_2_15  connected_order_arc_1214  -1
    order_2_15  connected_order_arc_1216  -1
    order_2_15  connected_order_arc_1218  -1
    order_2_15  connected_order_arc_1220  -1
    order_2_15  connected_order_arc_1235  1
    order_2_15  connected_order_arc_1256  1
    order_2_15  connected_order_arc_1277  1
    order_2_15  connected_order_arc_1298  1
    order_2_15  order_active_lb_1348  1
    order_2_15  order_active_ub_1349  1
    visit_2_16  out_degree_1352  -1
    visit_2_16  in_degree_1353  -1
    visit_2_16  order_active_lb_1354  -1
    visit_2_16  order_active_ub_1355  -11
    visit_2_16  service_visit_def_1356  -1
    order_2_16  connected_order_arc_1088  1
    order_2_16  connected_order_arc_1109  1
    order_2_16  connected_order_arc_1130  1
    order_2_16  connected_order_arc_1151  1
    order_2_16  connected_order_arc_1172  1
    order_2_16  connected_order_arc_1193  1
    order_2_16  connected_order_arc_1214  1
    order_2_16  connected_order_arc_1223  -1
    order_2_16  connected_order_arc_1225  -1
    order_2_16  connected_order_arc_1227  -1
    order_2_16  connected_order_arc_1229  -1
    order_2_16  connected_order_arc_1231  -1
    order_2_16  connected_order_arc_1233  -1
    order_2_16  connected_order_arc_1235  -1
    order_2_16  connected_order_arc_1237  -1
    order_2_16  connected_order_arc_1239  -1
    order_2_16  connected_order_arc_1241  -1
    order_2_16  connected_order_arc_1258  1
    order_2_16  connected_order_arc_1279  1
    order_2_16  connected_order_arc_1300  1
    order_2_16  order_active_lb_1354  1
    order_2_16  order_active_ub_1355  1
    visit_2_17  out_degree_1358  -1
    visit_2_17  in_degree_1359  -1
    visit_2_17  order_active_lb_1360  -1
    visit_2_17  order_active_ub_1361  -11
    visit_2_17  service_visit_def_1362  -1
    order_2_17  connected_order_arc_1090  1
    order_2_17  connected_order_arc_1111  1
    order_2_17  connected_order_arc_1132  1
    order_2_17  connected_order_arc_1153  1
    order_2_17  connected_order_arc_1174  1
    order_2_17  connected_order_arc_1195  1
    order_2_17  connected_order_arc_1216  1
    order_2_17  connected_order_arc_1237  1
    order_2_17  connected_order_arc_1244  -1
    order_2_17  connected_order_arc_1246  -1
    order_2_17  connected_order_arc_1248  -1
    order_2_17  connected_order_arc_1250  -1
    order_2_17  connected_order_arc_1252  -1
    order_2_17  connected_order_arc_1254  -1
    order_2_17  connected_order_arc_1256  -1
    order_2_17  connected_order_arc_1258  -1
    order_2_17  connected_order_arc_1260  -1
    order_2_17  connected_order_arc_1262  -1
    order_2_17  connected_order_arc_1281  1
    order_2_17  connected_order_arc_1302  1
    order_2_17  order_active_lb_1360  1
    order_2_17  order_active_ub_1361  1
    visit_2_18  out_degree_1364  -1
    visit_2_18  in_degree_1365  -1
    visit_2_18  order_active_lb_1366  -1
    visit_2_18  order_active_ub_1367  -11
    visit_2_18  service_visit_def_1368  -1
    order_2_18  connected_order_arc_1092  1
    order_2_18  connected_order_arc_1113  1
    order_2_18  connected_order_arc_1134  1
    order_2_18  connected_order_arc_1155  1
    order_2_18  connected_order_arc_1176  1
    order_2_18  connected_order_arc_1197  1
    order_2_18  connected_order_arc_1218  1
    order_2_18  connected_order_arc_1239  1
    order_2_18  connected_order_arc_1260  1
    order_2_18  connected_order_arc_1265  -1
    order_2_18  connected_order_arc_1267  -1
    order_2_18  connected_order_arc_1269  -1
    order_2_18  connected_order_arc_1271  -1
    order_2_18  connected_order_arc_1273  -1
    order_2_18  connected_order_arc_1275  -1
    order_2_18  connected_order_arc_1277  -1
    order_2_18  connected_order_arc_1279  -1
    order_2_18  connected_order_arc_1281  -1
    order_2_18  connected_order_arc_1283  -1
    order_2_18  connected_order_arc_1304  1
    order_2_18  order_active_lb_1366  1
    order_2_18  order_active_ub_1367  1
    visit_2_19  out_degree_1370  -1
    visit_2_19  in_degree_1371  -1
    visit_2_19  order_active_lb_1372  -1
    visit_2_19  order_active_ub_1373  -11
    visit_2_19  service_visit_def_1374  -1
    order_2_19  connected_order_arc_1094  1
    order_2_19  connected_order_arc_1115  1
    order_2_19  connected_order_arc_1136  1
    order_2_19  connected_order_arc_1157  1
    order_2_19  connected_order_arc_1178  1
    order_2_19  connected_order_arc_1199  1
    order_2_19  connected_order_arc_1220  1
    order_2_19  connected_order_arc_1241  1
    order_2_19  connected_order_arc_1262  1
    order_2_19  connected_order_arc_1283  1
    order_2_19  connected_order_arc_1286  -1
    order_2_19  connected_order_arc_1288  -1
    order_2_19  connected_order_arc_1290  -1
    order_2_19  connected_order_arc_1292  -1
    order_2_19  connected_order_arc_1294  -1
    order_2_19  connected_order_arc_1296  -1
    order_2_19  connected_order_arc_1298  -1
    order_2_19  connected_order_arc_1300  -1
    order_2_19  connected_order_arc_1302  -1
    order_2_19  connected_order_arc_1304  -1
    order_2_19  order_active_lb_1372  1
    order_2_19  order_active_ub_1373  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_0  arc_capacity_1062  -30
    arc_2_0_0  depot_departure_or_bypass_1305  1
    arc_2_0_0  depot_return_or_bypass_1306  1
    MARKER    'MARKER'                 'INTEND'
    load_2_0_0  arc_capacity_1062  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_9  arc_capacity_1063  -30
    arc_2_0_9  depot_departure_or_bypass_1305  1
    arc_2_0_9  in_degree_1308  1
    arc_2_0_9  original_T_including_depot_unload_1378  7.9650294035968375e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_9  arc_capacity_1063  1
    load_2_0_9  segment_load_conservation_1311  -1
    load_2_0_9  segment_prefix_lb_1312  1
    load_2_0_9  segment_prefix_ub_1313  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_10  arc_capacity_1064  -30
    arc_2_0_10  depot_departure_or_bypass_1305  1
    arc_2_0_10  in_degree_1315  1
    arc_2_0_10  original_T_including_depot_unload_1378  1.4373810231417410e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_10  arc_capacity_1064  1
    load_2_0_10  segment_load_conservation_1318  -1
    load_2_0_10  segment_prefix_lb_1319  1
    load_2_0_10  segment_prefix_ub_1320  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_11  arc_capacity_1065  -30
    arc_2_0_11  depot_departure_or_bypass_1305  1
    arc_2_0_11  in_degree_1322  1
    arc_2_0_11  original_T_including_depot_unload_1378  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_11  arc_capacity_1065  1
    load_2_0_11  segment_load_conservation_1325  -1
    load_2_0_11  segment_prefix_lb_1326  1
    load_2_0_11  segment_prefix_ub_1327  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_12  arc_capacity_1066  -30
    arc_2_0_12  depot_departure_or_bypass_1305  1
    arc_2_0_12  in_degree_1329  1
    arc_2_0_12  original_T_including_depot_unload_1378  3.6666597054112611e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_12  arc_capacity_1066  1
    load_2_0_12  free_load_conservation_1333  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_13  arc_capacity_1067  -30
    arc_2_0_13  depot_departure_or_bypass_1305  1
    arc_2_0_13  in_degree_1335  1
    arc_2_0_13  original_T_including_depot_unload_1378  3.8060477410436619e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_13  arc_capacity_1067  1
    load_2_0_13  free_load_conservation_1339  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_14  arc_capacity_1068  -30
    arc_2_0_14  depot_departure_or_bypass_1305  1
    arc_2_0_14  in_degree_1341  1
    arc_2_0_14  original_T_including_depot_unload_1378  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_14  arc_capacity_1068  1
    load_2_0_14  free_load_conservation_1345  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_15  arc_capacity_1069  -30
    arc_2_0_15  depot_departure_or_bypass_1305  1
    arc_2_0_15  in_degree_1347  1
    arc_2_0_15  original_T_including_depot_unload_1378  391.582148421393
    MARKER    'MARKER'                 'INTEND'
    load_2_0_15  arc_capacity_1069  1
    load_2_0_15  free_load_conservation_1351  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_16  arc_capacity_1070  -30
    arc_2_0_16  depot_departure_or_bypass_1305  1
    arc_2_0_16  in_degree_1353  1
    arc_2_0_16  original_T_including_depot_unload_1378  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_16  arc_capacity_1070  1
    load_2_0_16  free_load_conservation_1357  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_17  arc_capacity_1071  -30
    arc_2_0_17  depot_departure_or_bypass_1305  1
    arc_2_0_17  in_degree_1359  1
    arc_2_0_17  original_T_including_depot_unload_1378  3.9270969537253126e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_17  arc_capacity_1071  1
    load_2_0_17  free_load_conservation_1363  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_18  arc_capacity_1072  -30
    arc_2_0_18  depot_departure_or_bypass_1305  1
    arc_2_0_18  in_degree_1365  1
    arc_2_0_18  original_T_including_depot_unload_1378  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_18  arc_capacity_1072  1
    load_2_0_18  free_load_conservation_1369  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_19  arc_capacity_1073  -30
    arc_2_0_19  depot_departure_or_bypass_1305  1
    arc_2_0_19  in_degree_1371  1
    arc_2_0_19  original_T_including_depot_unload_1378  3.9307504957585564e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_19  arc_capacity_1073  1
    load_2_0_19  free_load_conservation_1375  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_0  arc_capacity_1074  -30
    arc_2_9_0  depot_return_or_bypass_1306  1
    arc_2_9_0  out_degree_1307  1
    arc_2_9_0  original_T_including_depot_unload_1378  7.9650294035968375e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_9_0  arc_capacity_1074  1
    load_2_9_0  segment_load_conservation_1311  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_10  arc_capacity_1075  -30
    arc_2_9_10  connected_order_arc_1076  -12
    arc_2_9_10  out_degree_1307  1
    arc_2_9_10  in_degree_1315  1
    arc_2_9_10  original_T_including_depot_unload_1378  7.5681404708111961e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_9_10  arc_capacity_1075  1
    load_2_9_10  segment_load_conservation_1311  1
    load_2_9_10  segment_load_conservation_1318  -1
    load_2_9_10  segment_prefix_lb_1319  1
    load_2_9_10  segment_prefix_ub_1320  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_11  arc_capacity_1077  -30
    arc_2_9_11  connected_order_arc_1078  -12
    arc_2_9_11  out_degree_1307  1
    arc_2_9_11  in_degree_1322  1
    arc_2_9_11  original_T_including_depot_unload_1378  3.7831268047064754e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_9_11  arc_capacity_1077  1
    load_2_9_11  segment_load_conservation_1311  1
    load_2_9_11  segment_load_conservation_1325  -1
    load_2_9_11  segment_prefix_lb_1326  1
    load_2_9_11  segment_prefix_ub_1327  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_12  arc_capacity_1079  -30
    arc_2_9_12  connected_order_arc_1080  -12
    arc_2_9_12  out_degree_1307  1
    arc_2_9_12  in_degree_1329  1
    arc_2_9_12  original_T_including_depot_unload_1378  876.282348312514
    MARKER    'MARKER'                 'INTEND'
    load_2_9_12  arc_capacity_1079  1
    load_2_9_12  segment_load_conservation_1311  1
    load_2_9_12  free_load_conservation_1333  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_13  arc_capacity_1081  -30
    arc_2_9_13  connected_order_arc_1082  -12
    arc_2_9_13  out_degree_1307  1
    arc_2_9_13  in_degree_1335  1
    arc_2_9_13  original_T_including_depot_unload_1378  7.8060605690718819e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_9_13  arc_capacity_1081  1
    load_2_9_13  segment_load_conservation_1311  1
    load_2_9_13  free_load_conservation_1339  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_14  arc_capacity_1083  -30
    arc_2_9_14  connected_order_arc_1084  -12
    arc_2_9_14  out_degree_1307  1
    arc_2_9_14  in_degree_1341  1
    arc_2_9_14  original_T_including_depot_unload_1378  9.8108674361469946e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_9_14  arc_capacity_1083  1
    load_2_9_14  segment_load_conservation_1311  1
    load_2_9_14  free_load_conservation_1345  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_15  arc_capacity_1085  -30
    arc_2_9_15  connected_order_arc_1086  -12
    arc_2_9_15  out_degree_1307  1
    arc_2_9_15  in_degree_1347  1
    arc_2_9_15  original_T_including_depot_unload_1378  1.0452797846577832e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_9_15  arc_capacity_1085  1
    load_2_9_15  segment_load_conservation_1311  1
    load_2_9_15  free_load_conservation_1351  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_16  arc_capacity_1087  -30
    arc_2_9_16  connected_order_arc_1088  -12
    arc_2_9_16  out_degree_1307  1
    arc_2_9_16  in_degree_1353  1
    arc_2_9_16  original_T_including_depot_unload_1378  3.5235932354279930e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_9_16  arc_capacity_1087  1
    load_2_9_16  segment_load_conservation_1311  1
    load_2_9_16  free_load_conservation_1357  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_17  arc_capacity_1089  -30
    arc_2_9_17  connected_order_arc_1090  -12
    arc_2_9_17  out_degree_1307  1
    arc_2_9_17  in_degree_1359  1
    arc_2_9_17  original_T_including_depot_unload_1378  1.0464557570570403e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_9_17  arc_capacity_1089  1
    load_2_9_17  segment_load_conservation_1311  1
    load_2_9_17  free_load_conservation_1363  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_18  arc_capacity_1091  -30
    arc_2_9_18  connected_order_arc_1092  -12
    arc_2_9_18  out_degree_1307  1
    arc_2_9_18  in_degree_1365  1
    arc_2_9_18  original_T_including_depot_unload_1378  5.4405628017126674e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_9_18  arc_capacity_1091  1
    load_2_9_18  segment_load_conservation_1311  1
    load_2_9_18  free_load_conservation_1369  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_19  arc_capacity_1093  -30
    arc_2_9_19  connected_order_arc_1094  -12
    arc_2_9_19  out_degree_1307  1
    arc_2_9_19  in_degree_1371  1
    arc_2_9_19  original_T_including_depot_unload_1378  1.0478069687959494e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_9_19  arc_capacity_1093  1
    load_2_9_19  segment_load_conservation_1311  1
    load_2_9_19  free_load_conservation_1375  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_0  arc_capacity_1095  -30
    arc_2_10_0  depot_return_or_bypass_1306  1
    arc_2_10_0  out_degree_1314  1
    arc_2_10_0  original_T_including_depot_unload_1378  1.6602888921784454e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_0  arc_capacity_1095  1
    load_2_10_0  segment_load_conservation_1318  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_9  arc_capacity_1096  -30
    arc_2_10_9  connected_order_arc_1097  -12
    arc_2_10_9  in_degree_1308  1
    arc_2_10_9  out_degree_1314  1
    arc_2_10_9  original_T_including_depot_unload_1378  1.2177809159572148e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_9  arc_capacity_1096  1
    load_2_10_9  segment_load_conservation_1311  -1
    load_2_10_9  segment_prefix_lb_1312  1
    load_2_10_9  segment_prefix_ub_1313  1
    load_2_10_9  segment_load_conservation_1318  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_11  arc_capacity_1098  -30
    arc_2_10_11  connected_order_arc_1099  -12
    arc_2_10_11  out_degree_1314  1
    arc_2_10_11  in_degree_1322  1
    arc_2_10_11  original_T_including_depot_unload_1378  1.3104307696104611e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_11  arc_capacity_1098  1
    load_2_10_11  segment_load_conservation_1318  1
    load_2_10_11  segment_load_conservation_1325  -1
    load_2_10_11  segment_prefix_lb_1326  1
    load_2_10_11  segment_prefix_ub_1327  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_12  arc_capacity_1100  -30
    arc_2_10_12  connected_order_arc_1101  -12
    arc_2_10_12  out_degree_1314  1
    arc_2_10_12  in_degree_1329  1
    arc_2_10_12  original_T_including_depot_unload_1378  1.9320166886379850e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_12  arc_capacity_1100  1
    load_2_10_12  segment_load_conservation_1318  1
    load_2_10_12  free_load_conservation_1333  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_13  arc_capacity_1102  -30
    arc_2_10_13  connected_order_arc_1103  -12
    arc_2_10_13  out_degree_1314  1
    arc_2_10_13  in_degree_1335  1
    arc_2_10_13  original_T_including_depot_unload_1378  1.8670935270400330e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_13  arc_capacity_1102  1
    load_2_10_13  segment_load_conservation_1318  1
    load_2_10_13  free_load_conservation_1339  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_14  arc_capacity_1104  -30
    arc_2_10_14  connected_order_arc_1105  -12
    arc_2_10_14  out_degree_1314  1
    arc_2_10_14  in_degree_1341  1
    arc_2_10_14  original_T_including_depot_unload_1378  1.9767828664634856e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_14  arc_capacity_1104  1
    load_2_10_14  segment_load_conservation_1318  1
    load_2_10_14  free_load_conservation_1345  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_15  arc_capacity_1106  -30
    arc_2_10_15  connected_order_arc_1107  -12
    arc_2_10_15  out_degree_1314  1
    arc_2_10_15  in_degree_1347  1
    arc_2_10_15  original_T_including_depot_unload_1378  2.0381190522271584e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_15  arc_capacity_1106  1
    load_2_10_15  segment_load_conservation_1318  1
    load_2_10_15  free_load_conservation_1351  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_16  arc_capacity_1108  -30
    arc_2_10_16  connected_order_arc_1109  -12
    arc_2_10_16  out_degree_1314  1
    arc_2_10_16  in_degree_1353  1
    arc_2_10_16  original_T_including_depot_unload_1378  8.7008776944597639e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_16  arc_capacity_1108  1
    load_2_10_16  segment_load_conservation_1318  1
    load_2_10_16  free_load_conservation_1357  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_17  arc_capacity_1110  -30
    arc_2_10_17  connected_order_arc_1111  -12
    arc_2_10_17  out_degree_1314  1
    arc_2_10_17  in_degree_1359  1
    arc_2_10_17  original_T_including_depot_unload_1378  2.0393331898049819e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_17  arc_capacity_1110  1
    load_2_10_17  segment_load_conservation_1318  1
    load_2_10_17  free_load_conservation_1363  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_18  arc_capacity_1112  -30
    arc_2_10_18  connected_order_arc_1113  -12
    arc_2_10_18  out_degree_1314  1
    arc_2_10_18  in_degree_1365  1
    arc_2_10_18  original_T_including_depot_unload_1378  1.7489191280566063e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_18  arc_capacity_1112  1
    load_2_10_18  segment_load_conservation_1318  1
    load_2_10_18  free_load_conservation_1369  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_19  arc_capacity_1114  -30
    arc_2_10_19  connected_order_arc_1115  -12
    arc_2_10_19  out_degree_1314  1
    arc_2_10_19  in_degree_1371  1
    arc_2_10_19  original_T_including_depot_unload_1378  2.0400693679210435e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_19  arc_capacity_1114  1
    load_2_10_19  segment_load_conservation_1318  1
    load_2_10_19  free_load_conservation_1375  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_0  arc_capacity_1116  -30
    arc_2_11_0  depot_return_or_bypass_1306  1
    arc_2_11_0  out_degree_1321  1
    arc_2_11_0  original_T_including_depot_unload_1378  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_0  arc_capacity_1116  1
    load_2_11_0  segment_load_conservation_1325  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_9  arc_capacity_1117  -30
    arc_2_11_9  connected_order_arc_1118  -12
    arc_2_11_9  in_degree_1308  1
    arc_2_11_9  out_degree_1321  1
    arc_2_11_9  original_T_including_depot_unload_1378  3.7831268047064754e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_9  arc_capacity_1117  1
    load_2_11_9  segment_load_conservation_1311  -1
    load_2_11_9  segment_prefix_lb_1312  1
    load_2_11_9  segment_prefix_ub_1313  1
    load_2_11_9  segment_load_conservation_1325  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_10  arc_capacity_1119  -30
    arc_2_11_10  connected_order_arc_1120  -12
    arc_2_11_10  in_degree_1315  1
    arc_2_11_10  out_degree_1321  1
    arc_2_11_10  original_T_including_depot_unload_1378  1.0984912119828512e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_10  arc_capacity_1119  1
    load_2_11_10  segment_load_conservation_1318  -1
    load_2_11_10  segment_prefix_lb_1319  1
    load_2_11_10  segment_prefix_ub_1320  1
    load_2_11_10  segment_load_conservation_1325  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_12  arc_capacity_1121  -30
    arc_2_11_12  connected_order_arc_1122  -12
    arc_2_11_12  out_degree_1321  1
    arc_2_11_12  in_degree_1329  1
    arc_2_11_12  original_T_including_depot_unload_1378  6.2502004715709484e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_12  arc_capacity_1121  1
    load_2_11_12  segment_load_conservation_1325  1
    load_2_11_12  free_load_conservation_1333  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_13  arc_capacity_1123  -30
    arc_2_11_13  connected_order_arc_1124  -12
    arc_2_11_13  out_degree_1321  1
    arc_2_11_13  in_degree_1335  1
    arc_2_11_13  original_T_including_depot_unload_1378  5.5668303114993182e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_13  arc_capacity_1123  1
    load_2_11_13  segment_load_conservation_1325  1
    load_2_11_13  free_load_conservation_1339  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_14  arc_capacity_1125  -30
    arc_2_11_14  connected_order_arc_1126  -12
    arc_2_11_14  out_degree_1321  1
    arc_2_11_14  in_degree_1341  1
    arc_2_11_14  original_T_including_depot_unload_1378  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_14  arc_capacity_1125  1
    load_2_11_14  segment_load_conservation_1325  1
    load_2_11_14  free_load_conservation_1345  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_15  arc_capacity_1127  -30
    arc_2_11_15  connected_order_arc_1128  -12
    arc_2_11_15  out_degree_1321  1
    arc_2_11_15  in_degree_1347  1
    arc_2_11_15  original_T_including_depot_unload_1378  7.5480538147776406e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_15  arc_capacity_1127  1
    load_2_11_15  segment_load_conservation_1325  1
    load_2_11_15  free_load_conservation_1351  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_16  arc_capacity_1129  -30
    arc_2_11_16  connected_order_arc_1130  -12
    arc_2_11_16  out_degree_1321  1
    arc_2_11_16  in_degree_1353  1
    arc_2_11_16  original_T_including_depot_unload_1378  5.7424143497696048e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_16  arc_capacity_1129  1
    load_2_11_16  segment_load_conservation_1325  1
    load_2_11_16  free_load_conservation_1357  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_17  arc_capacity_1131  -30
    arc_2_11_17  connected_order_arc_1132  -12
    arc_2_11_17  out_degree_1321  1
    arc_2_11_17  in_degree_1359  1
    arc_2_11_17  original_T_including_depot_unload_1378  756.038676628532
    MARKER    'MARKER'                 'INTEND'
    load_2_11_17  arc_capacity_1131  1
    load_2_11_17  segment_load_conservation_1325  1
    load_2_11_17  free_load_conservation_1363  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_18  arc_capacity_1133  -30
    arc_2_11_18  connected_order_arc_1134  -12
    arc_2_11_18  out_degree_1321  1
    arc_2_11_18  in_degree_1365  1
    arc_2_11_18  original_T_including_depot_unload_1378  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_2_11_18  arc_capacity_1133  1
    load_2_11_18  segment_load_conservation_1325  1
    load_2_11_18  free_load_conservation_1369  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_19  arc_capacity_1135  -30
    arc_2_11_19  connected_order_arc_1136  -12
    arc_2_11_19  out_degree_1321  1
    arc_2_11_19  in_degree_1371  1
    arc_2_11_19  original_T_including_depot_unload_1378  7.5707648242091466e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_19  arc_capacity_1135  1
    load_2_11_19  segment_load_conservation_1325  1
    load_2_11_19  free_load_conservation_1375  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_0  arc_capacity_1137  -30
    arc_2_12_0  depot_return_or_bypass_1306  1
    arc_2_12_0  out_degree_1328  1
    arc_2_12_0  original_T_including_depot_unload_1378  3.6666597054112611e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_0  arc_capacity_1137  1
    load_2_12_0  free_load_conservation_1333  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_9  arc_capacity_1138  -30
    arc_2_12_9  connected_order_arc_1139  -12
    arc_2_12_9  in_degree_1308  1
    arc_2_12_9  out_degree_1328  1
    arc_2_12_9  original_T_including_depot_unload_1378  876.282348312514
    MARKER    'MARKER'                 'INTEND'
    load_2_12_9  arc_capacity_1138  1
    load_2_12_9  segment_load_conservation_1311  -1
    load_2_12_9  segment_prefix_lb_1312  1
    load_2_12_9  segment_prefix_ub_1313  1
    load_2_12_9  free_load_conservation_1333  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_10  arc_capacity_1140  -30
    arc_2_12_10  connected_order_arc_1141  -12
    arc_2_12_10  in_degree_1315  1
    arc_2_12_10  out_degree_1328  1
    arc_2_12_10  original_T_including_depot_unload_1378  1.3451277357129768e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_10  arc_capacity_1140  1
    load_2_12_10  segment_load_conservation_1318  -1
    load_2_12_10  segment_prefix_lb_1319  1
    load_2_12_10  segment_prefix_ub_1320  1
    load_2_12_10  free_load_conservation_1333  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_11  arc_capacity_1142  -30
    arc_2_12_11  connected_order_arc_1143  -12
    arc_2_12_11  in_degree_1322  1
    arc_2_12_11  out_degree_1328  1
    arc_2_12_11  original_T_including_depot_unload_1378  6.2502004715709484e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_11  arc_capacity_1142  1
    load_2_12_11  segment_load_conservation_1325  -1
    load_2_12_11  segment_prefix_lb_1326  1
    load_2_12_11  segment_prefix_ub_1327  1
    load_2_12_11  free_load_conservation_1333  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_13  arc_capacity_1144  -30
    arc_2_12_13  connected_order_arc_1145  -12
    arc_2_12_13  out_degree_1328  1
    arc_2_12_13  in_degree_1335  1
    arc_2_12_13  original_T_including_depot_unload_1378  1.0605986491096120e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_13  arc_capacity_1144  1
    load_2_12_13  free_load_conservation_1333  1
    load_2_12_13  free_load_conservation_1339  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_14  arc_capacity_1146  -30
    arc_2_12_14  connected_order_arc_1147  -12
    arc_2_12_14  out_degree_1328  1
    arc_2_12_14  in_degree_1341  1
    arc_2_12_14  original_T_including_depot_unload_1378  1.4066323818659139e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_14  arc_capacity_1146  1
    load_2_12_14  free_load_conservation_1333  1
    load_2_12_14  free_load_conservation_1345  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_15  arc_capacity_1148  -30
    arc_2_12_15  connected_order_arc_1149  -12
    arc_2_12_15  out_degree_1328  1
    arc_2_12_15  in_degree_1347  1
    arc_2_12_15  original_T_including_depot_unload_1378  193.618232742121
    MARKER    'MARKER'                 'INTEND'
    load_2_12_15  arc_capacity_1148  1
    load_2_12_15  free_load_conservation_1333  1
    load_2_12_15  free_load_conservation_1351  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_16  arc_capacity_1150  -30
    arc_2_12_16  connected_order_arc_1151  -12
    arc_2_12_16  out_degree_1328  1
    arc_2_12_16  in_degree_1353  1
    arc_2_12_16  original_T_including_depot_unload_1378  1.1737339836679257e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_16  arc_capacity_1150  1
    load_2_12_16  free_load_conservation_1333  1
    load_2_12_16  free_load_conservation_1357  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_17  arc_capacity_1152  -30
    arc_2_12_17  connected_order_arc_1153  -12
    arc_2_12_17  out_degree_1328  1
    arc_2_12_17  in_degree_1359  1
    arc_2_12_17  original_T_including_depot_unload_1378  1.9450542613707577e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_17  arc_capacity_1152  1
    load_2_12_17  free_load_conservation_1333  1
    load_2_12_17  free_load_conservation_1363  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_18  arc_capacity_1154  -30
    arc_2_12_18  connected_order_arc_1155  -12
    arc_2_12_18  out_degree_1328  1
    arc_2_12_18  in_degree_1365  1
    arc_2_12_18  original_T_including_depot_unload_1378  7.7620596437921665e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_18  arc_capacity_1154  1
    load_2_12_18  free_load_conservation_1333  1
    load_2_12_18  free_load_conservation_1369  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_19  arc_capacity_1156  -30
    arc_2_12_19  connected_order_arc_1157  -12
    arc_2_12_19  out_degree_1328  1
    arc_2_12_19  in_degree_1371  1
    arc_2_12_19  original_T_including_depot_unload_1378  1.9614944290232185e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_19  arc_capacity_1156  1
    load_2_12_19  free_load_conservation_1333  1
    load_2_12_19  free_load_conservation_1375  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_0  arc_capacity_1158  -30
    arc_2_13_0  depot_return_or_bypass_1306  1
    arc_2_13_0  out_degree_1334  1
    arc_2_13_0  original_T_including_depot_unload_1378  3.8060477410436619e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_0  arc_capacity_1158  1
    load_2_13_0  free_load_conservation_1339  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_9  arc_capacity_1159  -30
    arc_2_13_9  connected_order_arc_1160  -12
    arc_2_13_9  in_degree_1308  1
    arc_2_13_9  out_degree_1334  1
    arc_2_13_9  original_T_including_depot_unload_1378  7.8060605690718819e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_9  arc_capacity_1159  1
    load_2_13_9  segment_load_conservation_1311  -1
    load_2_13_9  segment_prefix_lb_1312  1
    load_2_13_9  segment_prefix_ub_1313  1
    load_2_13_9  free_load_conservation_1339  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_10  arc_capacity_1161  -30
    arc_2_13_10  connected_order_arc_1162  -12
    arc_2_13_10  in_degree_1315  1
    arc_2_13_10  out_degree_1334  1
    arc_2_13_10  original_T_including_depot_unload_1378  1.2401143998876444e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_10  arc_capacity_1161  1
    load_2_13_10  segment_load_conservation_1318  -1
    load_2_13_10  segment_prefix_lb_1319  1
    load_2_13_10  segment_prefix_ub_1320  1
    load_2_13_10  free_load_conservation_1339  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_11  arc_capacity_1163  -30
    arc_2_13_11  connected_order_arc_1164  -12
    arc_2_13_11  in_degree_1322  1
    arc_2_13_11  out_degree_1334  1
    arc_2_13_11  original_T_including_depot_unload_1378  5.5668303114993182e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_11  arc_capacity_1163  1
    load_2_13_11  segment_load_conservation_1325  -1
    load_2_13_11  segment_prefix_lb_1326  1
    load_2_13_11  segment_prefix_ub_1327  1
    load_2_13_11  free_load_conservation_1339  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_12  arc_capacity_1165  -30
    arc_2_13_12  connected_order_arc_1166  -12
    arc_2_13_12  in_degree_1329  1
    arc_2_13_12  out_degree_1334  1
    arc_2_13_12  original_T_including_depot_unload_1378  1.0605986491096120e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_12  arc_capacity_1165  1
    load_2_13_12  free_load_conservation_1333  -1
    load_2_13_12  free_load_conservation_1339  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_14  arc_capacity_1167  -30
    arc_2_13_14  connected_order_arc_1168  -12
    arc_2_13_14  out_degree_1334  1
    arc_2_13_14  in_degree_1341  1
    arc_2_13_14  original_T_including_depot_unload_1378  1.3072142379397485e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_14  arc_capacity_1167  1
    load_2_13_14  free_load_conservation_1339  1
    load_2_13_14  free_load_conservation_1345  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_15  arc_capacity_1169  -30
    arc_2_13_15  connected_order_arc_1170  -12
    arc_2_13_15  out_degree_1334  1
    arc_2_13_15  in_degree_1347  1
    arc_2_13_15  original_T_including_depot_unload_1378  2.9898712977512486e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_15  arc_capacity_1169  1
    load_2_13_15  free_load_conservation_1339  1
    load_2_13_15  free_load_conservation_1351  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_16  arc_capacity_1171  -30
    arc_2_13_16  connected_order_arc_1172  -12
    arc_2_13_16  out_degree_1334  1
    arc_2_13_16  in_degree_1353  1
    arc_2_13_16  original_T_including_depot_unload_1378  1.0882276141652012e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_16  arc_capacity_1171  1
    load_2_13_16  free_load_conservation_1339  1
    load_2_13_16  free_load_conservation_1357  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_17  arc_capacity_1173  -30
    arc_2_13_17  connected_order_arc_1174  -12
    arc_2_13_17  out_degree_1334  1
    arc_2_13_17  in_degree_1359  1
    arc_2_13_17  original_T_including_depot_unload_1378  299.915584808525
    MARKER    'MARKER'                 'INTEND'
    load_2_13_17  arc_capacity_1173  1
    load_2_13_17  free_load_conservation_1339  1
    load_2_13_17  free_load_conservation_1363  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_18  arc_capacity_1175  -30
    arc_2_13_18  connected_order_arc_1176  -12
    arc_2_13_18  out_degree_1334  1
    arc_2_13_18  in_degree_1365  1
    arc_2_13_18  original_T_including_depot_unload_1378  6.7368811350376711e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_18  arc_capacity_1175  1
    load_2_13_18  free_load_conservation_1339  1
    load_2_13_18  free_load_conservation_1369  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_19  arc_capacity_1177  -30
    arc_2_13_19  connected_order_arc_1178  -12
    arc_2_13_19  out_degree_1334  1
    arc_2_13_19  in_degree_1371  1
    arc_2_13_19  original_T_including_depot_unload_1378  3.0154417050280659e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_19  arc_capacity_1177  1
    load_2_13_19  free_load_conservation_1339  1
    load_2_13_19  free_load_conservation_1375  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_0  arc_capacity_1179  -30
    arc_2_14_0  depot_return_or_bypass_1306  1
    arc_2_14_0  out_degree_1340  1
    arc_2_14_0  original_T_including_depot_unload_1378  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_0  arc_capacity_1179  1
    load_2_14_0  free_load_conservation_1345  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_9  arc_capacity_1180  -30
    arc_2_14_9  connected_order_arc_1181  -12
    arc_2_14_9  in_degree_1308  1
    arc_2_14_9  out_degree_1340  1
    arc_2_14_9  original_T_including_depot_unload_1378  9.8108674361469946e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_9  arc_capacity_1180  1
    load_2_14_9  segment_load_conservation_1311  -1
    load_2_14_9  segment_prefix_lb_1312  1
    load_2_14_9  segment_prefix_ub_1313  1
    load_2_14_9  free_load_conservation_1345  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_10  arc_capacity_1182  -30
    arc_2_14_10  connected_order_arc_1183  -12
    arc_2_14_10  in_degree_1315  1
    arc_2_14_10  out_degree_1340  1
    arc_2_14_10  original_T_including_depot_unload_1378  2.9139628504456829e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_10  arc_capacity_1182  1
    load_2_14_10  segment_load_conservation_1318  -1
    load_2_14_10  segment_prefix_lb_1319  1
    load_2_14_10  segment_prefix_ub_1320  1
    load_2_14_10  free_load_conservation_1345  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_11  arc_capacity_1184  -30
    arc_2_14_11  connected_order_arc_1185  -12
    arc_2_14_11  in_degree_1322  1
    arc_2_14_11  out_degree_1340  1
    arc_2_14_11  original_T_including_depot_unload_1378  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_11  arc_capacity_1184  1
    load_2_14_11  segment_load_conservation_1325  -1
    load_2_14_11  segment_prefix_lb_1326  1
    load_2_14_11  segment_prefix_ub_1327  1
    load_2_14_11  free_load_conservation_1345  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_12  arc_capacity_1186  -30
    arc_2_14_12  connected_order_arc_1187  -12
    arc_2_14_12  in_degree_1329  1
    arc_2_14_12  out_degree_1340  1
    arc_2_14_12  original_T_including_depot_unload_1378  1.4066323818659139e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_12  arc_capacity_1186  1
    load_2_14_12  free_load_conservation_1333  -1
    load_2_14_12  free_load_conservation_1345  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_13  arc_capacity_1188  -30
    arc_2_14_13  connected_order_arc_1189  -12
    arc_2_14_13  in_degree_1335  1
    arc_2_14_13  out_degree_1340  1
    arc_2_14_13  original_T_including_depot_unload_1378  1.3072142379397485e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_13  arc_capacity_1188  1
    load_2_14_13  free_load_conservation_1339  -1
    load_2_14_13  free_load_conservation_1345  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_15  arc_capacity_1190  -30
    arc_2_14_15  connected_order_arc_1191  -12
    arc_2_14_15  out_degree_1340  1
    arc_2_14_15  in_degree_1347  1
    arc_2_14_15  original_T_including_depot_unload_1378  1.5968425841449753e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_15  arc_capacity_1190  1
    load_2_14_15  free_load_conservation_1345  1
    load_2_14_15  free_load_conservation_1351  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_16  arc_capacity_1192  -30
    arc_2_14_16  connected_order_arc_1193  -12
    arc_2_14_16  out_degree_1340  1
    arc_2_14_16  in_degree_1353  1
    arc_2_14_16  original_T_including_depot_unload_1378  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_16  arc_capacity_1192  1
    load_2_14_16  free_load_conservation_1345  1
    load_2_14_16  free_load_conservation_1357  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_17  arc_capacity_1194  -30
    arc_2_14_17  connected_order_arc_1195  -12
    arc_2_14_17  out_degree_1340  1
    arc_2_14_17  in_degree_1359  1
    arc_2_14_17  original_T_including_depot_unload_1378  1.5975637706723310e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_17  arc_capacity_1194  1
    load_2_14_17  free_load_conservation_1345  1
    load_2_14_17  free_load_conservation_1363  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_18  arc_capacity_1196  -30
    arc_2_14_18  connected_order_arc_1197  -12
    arc_2_14_18  out_degree_1340  1
    arc_2_14_18  in_degree_1365  1
    arc_2_14_18  original_T_including_depot_unload_1378  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_2_14_18  arc_capacity_1196  1
    load_2_14_18  free_load_conservation_1345  1
    load_2_14_18  free_load_conservation_1369  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_19  arc_capacity_1198  -30
    arc_2_14_19  connected_order_arc_1199  -12
    arc_2_14_19  out_degree_1340  1
    arc_2_14_19  in_degree_1371  1
    arc_2_14_19  original_T_including_depot_unload_1378  1.5992308845216928e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_19  arc_capacity_1198  1
    load_2_14_19  free_load_conservation_1345  1
    load_2_14_19  free_load_conservation_1375  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_0  arc_capacity_1200  -30
    arc_2_15_0  depot_return_or_bypass_1306  1
    arc_2_15_0  out_degree_1346  1
    arc_2_15_0  original_T_including_depot_unload_1378  391.582148421393
    MARKER    'MARKER'                 'INTEND'
    load_2_15_0  arc_capacity_1200  1
    load_2_15_0  free_load_conservation_1351  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_9  arc_capacity_1201  -30
    arc_2_15_9  connected_order_arc_1202  -12
    arc_2_15_9  in_degree_1308  1
    arc_2_15_9  out_degree_1346  1
    arc_2_15_9  original_T_including_depot_unload_1378  1.0452797846577832e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_9  arc_capacity_1201  1
    load_2_15_9  segment_load_conservation_1311  -1
    load_2_15_9  segment_prefix_lb_1312  1
    load_2_15_9  segment_prefix_ub_1313  1
    load_2_15_9  free_load_conservation_1351  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_10  arc_capacity_1203  -30
    arc_2_15_10  connected_order_arc_1204  -12
    arc_2_15_10  in_degree_1315  1
    arc_2_15_10  out_degree_1346  1
    arc_2_15_10  original_T_including_depot_unload_1378  1.5387417148054021e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_10  arc_capacity_1203  1
    load_2_15_10  segment_load_conservation_1318  -1
    load_2_15_10  segment_prefix_lb_1319  1
    load_2_15_10  segment_prefix_ub_1320  1
    load_2_15_10  free_load_conservation_1351  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_11  arc_capacity_1205  -30
    arc_2_15_11  connected_order_arc_1206  -12
    arc_2_15_11  in_degree_1322  1
    arc_2_15_11  out_degree_1346  1
    arc_2_15_11  original_T_including_depot_unload_1378  7.5480538147776406e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_11  arc_capacity_1205  1
    load_2_15_11  segment_load_conservation_1325  -1
    load_2_15_11  segment_prefix_lb_1326  1
    load_2_15_11  segment_prefix_ub_1327  1
    load_2_15_11  free_load_conservation_1351  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_12  arc_capacity_1207  -30
    arc_2_15_12  connected_order_arc_1208  -12
    arc_2_15_12  in_degree_1329  1
    arc_2_15_12  out_degree_1346  1
    arc_2_15_12  original_T_including_depot_unload_1378  193.618232742121
    MARKER    'MARKER'                 'INTEND'
    load_2_15_12  arc_capacity_1207  1
    load_2_15_12  free_load_conservation_1333  -1
    load_2_15_12  free_load_conservation_1351  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_13  arc_capacity_1209  -30
    arc_2_15_13  connected_order_arc_1210  -12
    arc_2_15_13  in_degree_1335  1
    arc_2_15_13  out_degree_1346  1
    arc_2_15_13  original_T_including_depot_unload_1378  2.9898712977512486e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_13  arc_capacity_1209  1
    load_2_15_13  free_load_conservation_1339  -1
    load_2_15_13  free_load_conservation_1351  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_14  arc_capacity_1211  -30
    arc_2_15_14  connected_order_arc_1212  -12
    arc_2_15_14  in_degree_1341  1
    arc_2_15_14  out_degree_1346  1
    arc_2_15_14  original_T_including_depot_unload_1378  1.5968425841449753e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_14  arc_capacity_1211  1
    load_2_15_14  free_load_conservation_1345  -1
    load_2_15_14  free_load_conservation_1351  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_16  arc_capacity_1213  -30
    arc_2_15_16  connected_order_arc_1214  -12
    arc_2_15_16  out_degree_1346  1
    arc_2_15_16  in_degree_1353  1
    arc_2_15_16  original_T_including_depot_unload_1378  1.3222534044746537e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_16  arc_capacity_1213  1
    load_2_15_16  free_load_conservation_1351  1
    load_2_15_16  free_load_conservation_1357  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_17  arc_capacity_1215  -30
    arc_2_15_17  connected_order_arc_1216  -12
    arc_2_15_17  out_degree_1346  1
    arc_2_15_17  in_degree_1359  1
    arc_2_15_17  original_T_including_depot_unload_1378  1.2340243107914335e+00
    MARKER    'MARKER'                 'INTEND'
    load_2_15_17  arc_capacity_1215  1
    load_2_15_17  free_load_conservation_1351  1
    load_2_15_17  free_load_conservation_1363  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_18  arc_capacity_1217  -30
    arc_2_15_18  connected_order_arc_1218  -12
    arc_2_15_18  out_degree_1346  1
    arc_2_15_18  in_degree_1365  1
    arc_2_15_18  original_T_including_depot_unload_1378  9.6906528258679839e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_18  arc_capacity_1217  1
    load_2_15_18  free_load_conservation_1351  1
    load_2_15_18  free_load_conservation_1369  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_19  arc_capacity_1219  -30
    arc_2_15_19  connected_order_arc_1220  -12
    arc_2_15_19  out_degree_1346  1
    arc_2_15_19  in_degree_1371  1
    arc_2_15_19  original_T_including_depot_unload_1378  2.5978621120511871e+00
    MARKER    'MARKER'                 'INTEND'
    load_2_15_19  arc_capacity_1219  1
    load_2_15_19  free_load_conservation_1351  1
    load_2_15_19  free_load_conservation_1375  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_0  arc_capacity_1221  -30
    arc_2_16_0  depot_return_or_bypass_1306  1
    arc_2_16_0  out_degree_1352  1
    arc_2_16_0  original_T_including_depot_unload_1378  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_0  arc_capacity_1221  1
    load_2_16_0  free_load_conservation_1357  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_9  arc_capacity_1222  -30
    arc_2_16_9  connected_order_arc_1223  -12
    arc_2_16_9  in_degree_1308  1
    arc_2_16_9  out_degree_1352  1
    arc_2_16_9  original_T_including_depot_unload_1378  3.5235932354279930e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_9  arc_capacity_1222  1
    load_2_16_9  segment_load_conservation_1311  -1
    load_2_16_9  segment_prefix_lb_1312  1
    load_2_16_9  segment_prefix_ub_1313  1
    load_2_16_9  free_load_conservation_1357  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_10  arc_capacity_1224  -30
    arc_2_16_10  connected_order_arc_1225  -12
    arc_2_16_10  in_degree_1315  1
    arc_2_16_10  out_degree_1352  1
    arc_2_16_10  original_T_including_depot_unload_1378  925.691754925099
    MARKER    'MARKER'                 'INTEND'
    load_2_16_10  arc_capacity_1224  1
    load_2_16_10  segment_load_conservation_1318  -1
    load_2_16_10  segment_prefix_lb_1319  1
    load_2_16_10  segment_prefix_ub_1320  1
    load_2_16_10  free_load_conservation_1357  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_11  arc_capacity_1226  -30
    arc_2_16_11  connected_order_arc_1227  -12
    arc_2_16_11  in_degree_1322  1
    arc_2_16_11  out_degree_1352  1
    arc_2_16_11  original_T_including_depot_unload_1378  5.7424143497696048e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_11  arc_capacity_1226  1
    load_2_16_11  segment_load_conservation_1325  -1
    load_2_16_11  segment_prefix_lb_1326  1
    load_2_16_11  segment_prefix_ub_1327  1
    load_2_16_11  free_load_conservation_1357  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_12  arc_capacity_1228  -30
    arc_2_16_12  connected_order_arc_1229  -12
    arc_2_16_12  in_degree_1329  1
    arc_2_16_12  out_degree_1352  1
    arc_2_16_12  original_T_including_depot_unload_1378  1.1737339836679257e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_12  arc_capacity_1228  1
    load_2_16_12  free_load_conservation_1333  -1
    load_2_16_12  free_load_conservation_1357  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_13  arc_capacity_1230  -30
    arc_2_16_13  connected_order_arc_1231  -12
    arc_2_16_13  in_degree_1335  1
    arc_2_16_13  out_degree_1352  1
    arc_2_16_13  original_T_including_depot_unload_1378  1.0882276141652012e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_13  arc_capacity_1230  1
    load_2_16_13  free_load_conservation_1339  -1
    load_2_16_13  free_load_conservation_1357  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_14  arc_capacity_1232  -30
    arc_2_16_14  connected_order_arc_1233  -12
    arc_2_16_14  in_degree_1341  1
    arc_2_16_14  out_degree_1352  1
    arc_2_16_14  original_T_including_depot_unload_1378  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_14  arc_capacity_1232  1
    load_2_16_14  free_load_conservation_1345  -1
    load_2_16_14  free_load_conservation_1357  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_15  arc_capacity_1234  -30
    arc_2_16_15  connected_order_arc_1235  -12
    arc_2_16_15  in_degree_1347  1
    arc_2_16_15  out_degree_1352  1
    arc_2_16_15  original_T_including_depot_unload_1378  1.3222534044746537e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_15  arc_capacity_1234  1
    load_2_16_15  free_load_conservation_1351  -1
    load_2_16_15  free_load_conservation_1357  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_17  arc_capacity_1236  -30
    arc_2_16_17  connected_order_arc_1237  -12
    arc_2_16_17  out_degree_1352  1
    arc_2_16_17  in_degree_1359  1
    arc_2_16_17  original_T_including_depot_unload_1378  1.3234781764513652e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_17  arc_capacity_1236  1
    load_2_16_17  free_load_conservation_1357  1
    load_2_16_17  free_load_conservation_1363  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_18  arc_capacity_1238  -30
    arc_2_16_18  connected_order_arc_1239  -12
    arc_2_16_18  out_degree_1352  1
    arc_2_16_18  in_degree_1365  1
    arc_2_16_18  original_T_including_depot_unload_1378  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_18  arc_capacity_1238  1
    load_2_16_18  free_load_conservation_1357  1
    load_2_16_18  free_load_conservation_1369  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_19  arc_capacity_1240  -30
    arc_2_16_19  connected_order_arc_1241  -12
    arc_2_16_19  out_degree_1352  1
    arc_2_16_19  in_degree_1371  1
    arc_2_16_19  original_T_including_depot_unload_1378  1.3246263055739521e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_19  arc_capacity_1240  1
    load_2_16_19  free_load_conservation_1357  1
    load_2_16_19  free_load_conservation_1375  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_0  arc_capacity_1242  -30
    arc_2_17_0  depot_return_or_bypass_1306  1
    arc_2_17_0  out_degree_1358  1
    arc_2_17_0  original_T_including_depot_unload_1378  3.9270969537253126e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_0  arc_capacity_1242  1
    load_2_17_0  free_load_conservation_1363  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_9  arc_capacity_1243  -30
    arc_2_17_9  connected_order_arc_1244  -12
    arc_2_17_9  in_degree_1308  1
    arc_2_17_9  out_degree_1358  1
    arc_2_17_9  original_T_including_depot_unload_1378  1.0464557570570403e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_9  arc_capacity_1243  1
    load_2_17_9  segment_load_conservation_1311  -1
    load_2_17_9  segment_prefix_lb_1312  1
    load_2_17_9  segment_prefix_ub_1313  1
    load_2_17_9  free_load_conservation_1363  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_10  arc_capacity_1245  -30
    arc_2_17_10  connected_order_arc_1246  -12
    arc_2_17_10  in_degree_1315  1
    arc_2_17_10  out_degree_1358  1
    arc_2_17_10  original_T_including_depot_unload_1378  1.5396325562458978e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_10  arc_capacity_1245  1
    load_2_17_10  segment_load_conservation_1318  -1
    load_2_17_10  segment_prefix_lb_1319  1
    load_2_17_10  segment_prefix_ub_1320  1
    load_2_17_10  free_load_conservation_1363  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_11  arc_capacity_1247  -30
    arc_2_17_11  connected_order_arc_1248  -12
    arc_2_17_11  in_degree_1322  1
    arc_2_17_11  out_degree_1358  1
    arc_2_17_11  original_T_including_depot_unload_1378  756.038676628532
    MARKER    'MARKER'                 'INTEND'
    load_2_17_11  arc_capacity_1247  1
    load_2_17_11  segment_load_conservation_1325  -1
    load_2_17_11  segment_prefix_lb_1326  1
    load_2_17_11  segment_prefix_ub_1327  1
    load_2_17_11  free_load_conservation_1363  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_12  arc_capacity_1249  -30
    arc_2_17_12  connected_order_arc_1250  -12
    arc_2_17_12  in_degree_1329  1
    arc_2_17_12  out_degree_1358  1
    arc_2_17_12  original_T_including_depot_unload_1378  1.9450542613707577e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_12  arc_capacity_1249  1
    load_2_17_12  free_load_conservation_1333  -1
    load_2_17_12  free_load_conservation_1363  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_13  arc_capacity_1251  -30
    arc_2_17_13  connected_order_arc_1252  -12
    arc_2_17_13  in_degree_1335  1
    arc_2_17_13  out_degree_1358  1
    arc_2_17_13  original_T_including_depot_unload_1378  299.915584808525
    MARKER    'MARKER'                 'INTEND'
    load_2_17_13  arc_capacity_1251  1
    load_2_17_13  free_load_conservation_1339  -1
    load_2_17_13  free_load_conservation_1363  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_14  arc_capacity_1253  -30
    arc_2_17_14  connected_order_arc_1254  -12
    arc_2_17_14  in_degree_1341  1
    arc_2_17_14  out_degree_1358  1
    arc_2_17_14  original_T_including_depot_unload_1378  1.5975637706723310e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_14  arc_capacity_1253  1
    load_2_17_14  free_load_conservation_1345  -1
    load_2_17_14  free_load_conservation_1363  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_15  arc_capacity_1255  -30
    arc_2_17_15  connected_order_arc_1256  -12
    arc_2_17_15  in_degree_1347  1
    arc_2_17_15  out_degree_1358  1
    arc_2_17_15  original_T_including_depot_unload_1378  1.2340243107914335e+00
    MARKER    'MARKER'                 'INTEND'
    load_2_17_15  arc_capacity_1255  1
    load_2_17_15  free_load_conservation_1351  -1
    load_2_17_15  free_load_conservation_1363  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_16  arc_capacity_1257  -30
    arc_2_17_16  connected_order_arc_1258  -12
    arc_2_17_16  in_degree_1353  1
    arc_2_17_16  out_degree_1358  1
    arc_2_17_16  original_T_including_depot_unload_1378  1.3234781764513652e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_16  arc_capacity_1257  1
    load_2_17_16  free_load_conservation_1357  -1
    load_2_17_16  free_load_conservation_1363  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_18  arc_capacity_1259  -30
    arc_2_17_18  connected_order_arc_1260  -12
    arc_2_17_18  out_degree_1358  1
    arc_2_17_18  in_degree_1365  1
    arc_2_17_18  original_T_including_depot_unload_1378  9.6988018824317578e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_18  arc_capacity_1259  1
    load_2_17_18  free_load_conservation_1363  1
    load_2_17_18  free_load_conservation_1369  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_19  arc_capacity_1261  -30
    arc_2_17_19  connected_order_arc_1262  -12
    arc_2_17_19  out_degree_1358  1
    arc_2_17_19  in_degree_1371  1
    arc_2_17_19  original_T_including_depot_unload_1378  1.6672379018690657e+00
    MARKER    'MARKER'                 'INTEND'
    load_2_17_19  arc_capacity_1261  1
    load_2_17_19  free_load_conservation_1363  1
    load_2_17_19  free_load_conservation_1375  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_0  arc_capacity_1263  -30
    arc_2_18_0  depot_return_or_bypass_1306  1
    arc_2_18_0  out_degree_1364  1
    arc_2_18_0  original_T_including_depot_unload_1378  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_0  arc_capacity_1263  1
    load_2_18_0  free_load_conservation_1369  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_9  arc_capacity_1264  -30
    arc_2_18_9  connected_order_arc_1265  -12
    arc_2_18_9  in_degree_1308  1
    arc_2_18_9  out_degree_1364  1
    arc_2_18_9  original_T_including_depot_unload_1378  5.4405628017126674e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_9  arc_capacity_1264  1
    load_2_18_9  segment_load_conservation_1311  -1
    load_2_18_9  segment_prefix_lb_1312  1
    load_2_18_9  segment_prefix_ub_1313  1
    load_2_18_9  free_load_conservation_1369  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_10  arc_capacity_1266  -30
    arc_2_18_10  connected_order_arc_1267  -12
    arc_2_18_10  in_degree_1315  1
    arc_2_18_10  out_degree_1364  1
    arc_2_18_10  original_T_including_depot_unload_1378  5.7914586906741226e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_10  arc_capacity_1266  1
    load_2_18_10  segment_load_conservation_1318  -1
    load_2_18_10  segment_prefix_lb_1319  1
    load_2_18_10  segment_prefix_ub_1320  1
    load_2_18_10  free_load_conservation_1369  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_11  arc_capacity_1268  -30
    arc_2_18_11  connected_order_arc_1269  -12
    arc_2_18_11  in_degree_1322  1
    arc_2_18_11  out_degree_1364  1
    arc_2_18_11  original_T_including_depot_unload_1378  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_2_18_11  arc_capacity_1268  1
    load_2_18_11  segment_load_conservation_1325  -1
    load_2_18_11  segment_prefix_lb_1326  1
    load_2_18_11  segment_prefix_ub_1327  1
    load_2_18_11  free_load_conservation_1369  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_12  arc_capacity_1270  -30
    arc_2_18_12  connected_order_arc_1271  -12
    arc_2_18_12  in_degree_1329  1
    arc_2_18_12  out_degree_1364  1
    arc_2_18_12  original_T_including_depot_unload_1378  7.7620596437921665e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_12  arc_capacity_1270  1
    load_2_18_12  free_load_conservation_1333  -1
    load_2_18_12  free_load_conservation_1369  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_13  arc_capacity_1272  -30
    arc_2_18_13  connected_order_arc_1273  -12
    arc_2_18_13  in_degree_1335  1
    arc_2_18_13  out_degree_1364  1
    arc_2_18_13  original_T_including_depot_unload_1378  6.7368811350376711e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_13  arc_capacity_1272  1
    load_2_18_13  free_load_conservation_1339  -1
    load_2_18_13  free_load_conservation_1369  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_14  arc_capacity_1274  -30
    arc_2_18_14  connected_order_arc_1275  -12
    arc_2_18_14  in_degree_1341  1
    arc_2_18_14  out_degree_1364  1
    arc_2_18_14  original_T_including_depot_unload_1378  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_2_18_14  arc_capacity_1274  1
    load_2_18_14  free_load_conservation_1345  -1
    load_2_18_14  free_load_conservation_1369  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_15  arc_capacity_1276  -30
    arc_2_18_15  connected_order_arc_1277  -12
    arc_2_18_15  in_degree_1347  1
    arc_2_18_15  out_degree_1364  1
    arc_2_18_15  original_T_including_depot_unload_1378  9.6906528258679839e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_15  arc_capacity_1276  1
    load_2_18_15  free_load_conservation_1351  -1
    load_2_18_15  free_load_conservation_1369  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_16  arc_capacity_1278  -30
    arc_2_18_16  connected_order_arc_1279  -12
    arc_2_18_16  in_degree_1353  1
    arc_2_18_16  out_degree_1364  1
    arc_2_18_16  original_T_including_depot_unload_1378  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_16  arc_capacity_1278  1
    load_2_18_16  free_load_conservation_1357  -1
    load_2_18_16  free_load_conservation_1369  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_17  arc_capacity_1280  -30
    arc_2_18_17  connected_order_arc_1281  -12
    arc_2_18_17  in_degree_1359  1
    arc_2_18_17  out_degree_1364  1
    arc_2_18_17  original_T_including_depot_unload_1378  9.6988018824317578e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_17  arc_capacity_1280  1
    load_2_18_17  free_load_conservation_1363  -1
    load_2_18_17  free_load_conservation_1369  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_19  arc_capacity_1282  -30
    arc_2_18_19  connected_order_arc_1283  -12
    arc_2_18_19  out_degree_1364  1
    arc_2_18_19  in_degree_1371  1
    arc_2_18_19  original_T_including_depot_unload_1378  9.7154140307447824e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_19  arc_capacity_1282  1
    load_2_18_19  free_load_conservation_1369  1
    load_2_18_19  free_load_conservation_1375  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_0  arc_capacity_1284  -30
    arc_2_19_0  depot_return_or_bypass_1306  1
    arc_2_19_0  out_degree_1370  1
    arc_2_19_0  original_T_including_depot_unload_1378  3.9307504957585564e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_0  arc_capacity_1284  1
    load_2_19_0  free_load_conservation_1375  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_9  arc_capacity_1285  -30
    arc_2_19_9  connected_order_arc_1286  -12
    arc_2_19_9  in_degree_1308  1
    arc_2_19_9  out_degree_1370  1
    arc_2_19_9  original_T_including_depot_unload_1378  1.0478069687959494e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_9  arc_capacity_1285  1
    load_2_19_9  segment_load_conservation_1311  -1
    load_2_19_9  segment_prefix_lb_1312  1
    load_2_19_9  segment_prefix_ub_1313  1
    load_2_19_9  free_load_conservation_1375  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_10  arc_capacity_1287  -30
    arc_2_19_10  connected_order_arc_1288  -12
    arc_2_19_10  in_degree_1315  1
    arc_2_19_10  out_degree_1370  1
    arc_2_19_10  original_T_including_depot_unload_1378  1.5412757472294663e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_10  arc_capacity_1287  1
    load_2_19_10  segment_load_conservation_1318  -1
    load_2_19_10  segment_prefix_lb_1319  1
    load_2_19_10  segment_prefix_ub_1320  1
    load_2_19_10  free_load_conservation_1375  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_11  arc_capacity_1289  -30
    arc_2_19_11  connected_order_arc_1290  -12
    arc_2_19_11  in_degree_1322  1
    arc_2_19_11  out_degree_1370  1
    arc_2_19_11  original_T_including_depot_unload_1378  7.5707648242091466e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_11  arc_capacity_1289  1
    load_2_19_11  segment_load_conservation_1325  -1
    load_2_19_11  segment_prefix_lb_1326  1
    load_2_19_11  segment_prefix_ub_1327  1
    load_2_19_11  free_load_conservation_1375  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_12  arc_capacity_1291  -30
    arc_2_19_12  connected_order_arc_1292  -12
    arc_2_19_12  in_degree_1329  1
    arc_2_19_12  out_degree_1370  1
    arc_2_19_12  original_T_including_depot_unload_1378  1.9614944290232185e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_12  arc_capacity_1291  1
    load_2_19_12  free_load_conservation_1333  -1
    load_2_19_12  free_load_conservation_1375  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_13  arc_capacity_1293  -30
    arc_2_19_13  connected_order_arc_1294  -12
    arc_2_19_13  in_degree_1335  1
    arc_2_19_13  out_degree_1370  1
    arc_2_19_13  original_T_including_depot_unload_1378  3.0154417050280659e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_13  arc_capacity_1293  1
    load_2_19_13  free_load_conservation_1339  -1
    load_2_19_13  free_load_conservation_1375  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_14  arc_capacity_1295  -30
    arc_2_19_14  connected_order_arc_1296  -12
    arc_2_19_14  in_degree_1341  1
    arc_2_19_14  out_degree_1370  1
    arc_2_19_14  original_T_including_depot_unload_1378  1.5992308845216928e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_14  arc_capacity_1295  1
    load_2_19_14  free_load_conservation_1345  -1
    load_2_19_14  free_load_conservation_1375  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_15  arc_capacity_1297  -30
    arc_2_19_15  connected_order_arc_1298  -12
    arc_2_19_15  in_degree_1347  1
    arc_2_19_15  out_degree_1370  1
    arc_2_19_15  original_T_including_depot_unload_1378  2.5978621120511871e+00
    MARKER    'MARKER'                 'INTEND'
    load_2_19_15  arc_capacity_1297  1
    load_2_19_15  free_load_conservation_1351  -1
    load_2_19_15  free_load_conservation_1375  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_16  arc_capacity_1299  -30
    arc_2_19_16  connected_order_arc_1300  -12
    arc_2_19_16  in_degree_1353  1
    arc_2_19_16  out_degree_1370  1
    arc_2_19_16  original_T_including_depot_unload_1378  1.3246263055739521e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_16  arc_capacity_1299  1
    load_2_19_16  free_load_conservation_1357  -1
    load_2_19_16  free_load_conservation_1375  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_17  arc_capacity_1301  -30
    arc_2_19_17  connected_order_arc_1302  -12
    arc_2_19_17  in_degree_1359  1
    arc_2_19_17  out_degree_1370  1
    arc_2_19_17  original_T_including_depot_unload_1378  1.6672379018690657e+00
    MARKER    'MARKER'                 'INTEND'
    load_2_19_17  arc_capacity_1301  1
    load_2_19_17  free_load_conservation_1363  -1
    load_2_19_17  free_load_conservation_1375  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_18  arc_capacity_1303  -30
    arc_2_19_18  connected_order_arc_1304  -12
    arc_2_19_18  in_degree_1365  1
    arc_2_19_18  out_degree_1370  1
    arc_2_19_18  original_T_including_depot_unload_1378  9.7154140307447824e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_18  arc_capacity_1303  1
    load_2_19_18  free_load_conservation_1369  -1
    load_2_19_18  free_load_conservation_1375  1
RHS
    RHS1      OBJ       -2.3142805897993490e-01
    RHS1      onehot_20_22  1
    RHS1      onehot_21_39  1
    RHS1      onehot_34_74  1
    RHS1      onehot_19_99  1
    RHS1      onehot_29_124  1
    RHS1      onehot_18_149  1
    RHS1      onehot_27_166  1
    RHS1      onehot_17_183  1
    RHS1      stock_ub_187  24
    RHS1      parent_nonstrict_scope_188  2.5909533554042552e-01
    RHS1      normalization_245  1
    RHS1      connected_order_arc_335  -12
    RHS1      connected_order_arc_337  -12
    RHS1      connected_order_arc_339  -12
    RHS1      connected_order_arc_341  -12
    RHS1      connected_order_arc_343  -12
    RHS1      connected_order_arc_345  -12
    RHS1      connected_order_arc_347  -12
    RHS1      connected_order_arc_349  -12
    RHS1      connected_order_arc_351  -12
    RHS1      connected_order_arc_353  -12
    RHS1      connected_order_arc_355  -12
    RHS1      connected_order_arc_358  -12
    RHS1      connected_order_arc_360  -12
    RHS1      connected_order_arc_362  -12
    RHS1      connected_order_arc_364  -12
    RHS1      connected_order_arc_366  -12
    RHS1      connected_order_arc_368  -12
    RHS1      connected_order_arc_370  -12
    RHS1      connected_order_arc_372  -12
    RHS1      connected_order_arc_374  -12
    RHS1      connected_order_arc_376  -12
    RHS1      connected_order_arc_378  -12
    RHS1      connected_order_arc_381  -12
    RHS1      connected_order_arc_383  -12
    RHS1      connected_order_arc_385  -12
    RHS1      connected_order_arc_387  -12
    RHS1      connected_order_arc_389  -12
    RHS1      connected_order_arc_391  -12
    RHS1      connected_order_arc_393  -12
    RHS1      connected_order_arc_395  -12
    RHS1      connected_order_arc_397  -12
    RHS1      connected_order_arc_399  -12
    RHS1      connected_order_arc_401  -12
    RHS1      connected_order_arc_404  -12
    RHS1      connected_order_arc_406  -12
    RHS1      connected_order_arc_408  -12
    RHS1      connected_order_arc_410  -12
    RHS1      connected_order_arc_412  -12
    RHS1      connected_order_arc_414  -12
    RHS1      connected_order_arc_416  -12
    RHS1      connected_order_arc_418  -12
    RHS1      connected_order_arc_420  -12
    RHS1      connected_order_arc_422  -12
    RHS1      connected_order_arc_424  -12
    RHS1      connected_order_arc_427  -12
    RHS1      connected_order_arc_429  -12
    RHS1      connected_order_arc_431  -12
    RHS1      connected_order_arc_433  -12
    RHS1      connected_order_arc_435  -12
    RHS1      connected_order_arc_437  -12
    RHS1      connected_order_arc_439  -12
    RHS1      connected_order_arc_441  -12
    RHS1      connected_order_arc_443  -12
    RHS1      connected_order_arc_445  -12
    RHS1      connected_order_arc_447  -12
    RHS1      connected_order_arc_450  -12
    RHS1      connected_order_arc_452  -12
    RHS1      connected_order_arc_454  -12
    RHS1      connected_order_arc_456  -12
    RHS1      connected_order_arc_458  -12
    RHS1      connected_order_arc_460  -12
    RHS1      connected_order_arc_462  -12
    RHS1      connected_order_arc_464  -12
    RHS1      connected_order_arc_466  -12
    RHS1      connected_order_arc_468  -12
    RHS1      connected_order_arc_470  -12
    RHS1      connected_order_arc_473  -12
    RHS1      connected_order_arc_475  -12
    RHS1      connected_order_arc_477  -12
    RHS1      connected_order_arc_479  -12
    RHS1      connected_order_arc_481  -12
    RHS1      connected_order_arc_483  -12
    RHS1      connected_order_arc_485  -12
    RHS1      connected_order_arc_487  -12
    RHS1      connected_order_arc_489  -12
    RHS1      connected_order_arc_491  -12
    RHS1      connected_order_arc_493  -12
    RHS1      connected_order_arc_496  -12
    RHS1      connected_order_arc_498  -12
    RHS1      connected_order_arc_500  -12
    RHS1      connected_order_arc_502  -12
    RHS1      connected_order_arc_504  -12
    RHS1      connected_order_arc_506  -12
    RHS1      connected_order_arc_508  -12
    RHS1      connected_order_arc_510  -12
    RHS1      connected_order_arc_512  -12
    RHS1      connected_order_arc_514  -12
    RHS1      connected_order_arc_516  -12
    RHS1      connected_order_arc_519  -12
    RHS1      connected_order_arc_521  -12
    RHS1      connected_order_arc_523  -12
    RHS1      connected_order_arc_525  -12
    RHS1      connected_order_arc_527  -12
    RHS1      connected_order_arc_529  -12
    RHS1      connected_order_arc_531  -12
    RHS1      connected_order_arc_533  -12
    RHS1      connected_order_arc_535  -12
    RHS1      connected_order_arc_537  -12
    RHS1      connected_order_arc_539  -12
    RHS1      connected_order_arc_542  -12
    RHS1      connected_order_arc_544  -12
    RHS1      connected_order_arc_546  -12
    RHS1      connected_order_arc_548  -12
    RHS1      connected_order_arc_550  -12
    RHS1      connected_order_arc_552  -12
    RHS1      connected_order_arc_554  -12
    RHS1      connected_order_arc_556  -12
    RHS1      connected_order_arc_558  -12
    RHS1      connected_order_arc_560  -12
    RHS1      connected_order_arc_562  -12
    RHS1      connected_order_arc_565  -12
    RHS1      connected_order_arc_567  -12
    RHS1      connected_order_arc_569  -12
    RHS1      connected_order_arc_571  -12
    RHS1      connected_order_arc_573  -12
    RHS1      connected_order_arc_575  -12
    RHS1      connected_order_arc_577  -12
    RHS1      connected_order_arc_579  -12
    RHS1      connected_order_arc_581  -12
    RHS1      connected_order_arc_583  -12
    RHS1      connected_order_arc_585  -12
    RHS1      connected_order_arc_588  -12
    RHS1      connected_order_arc_590  -12
    RHS1      connected_order_arc_592  -12
    RHS1      connected_order_arc_594  -12
    RHS1      connected_order_arc_596  -12
    RHS1      connected_order_arc_598  -12
    RHS1      connected_order_arc_600  -12
    RHS1      connected_order_arc_602  -12
    RHS1      connected_order_arc_604  -12
    RHS1      connected_order_arc_606  -12
    RHS1      connected_order_arc_608  -12
    RHS1      depot_departure_or_bypass_609  1
    RHS1      depot_return_or_bypass_610  1
    RHS1      segment_load_conservation_615  1
    RHS1      segment_prefix_ub_617  19
    RHS1      segment_load_conservation_622  1
    RHS1      segment_prefix_ub_624  19
    RHS1      segment_load_conservation_629  -2
    RHS1      segment_prefix_lb_630  2
    RHS1      segment_prefix_ub_631  20
    RHS1      segment_prefix_ub_638  10
    RHS1      fixed_segment_relative_order_687  1
    RHS1      fixed_segment_relative_order_688  1
    RHS1      fixed_segment_relative_order_689  1
    RHS1      original_T_including_depot_unload_690  3273.18673966179
    RHS1      connected_order_arc_706  -12
    RHS1      connected_order_arc_708  -12
    RHS1      connected_order_arc_710  -12
    RHS1      connected_order_arc_712  -12
    RHS1      connected_order_arc_714  -12
    RHS1      connected_order_arc_716  -12
    RHS1      connected_order_arc_718  -12
    RHS1      connected_order_arc_720  -12
    RHS1      connected_order_arc_722  -12
    RHS1      connected_order_arc_724  -12
    RHS1      connected_order_arc_726  -12
    RHS1      connected_order_arc_729  -12
    RHS1      connected_order_arc_731  -12
    RHS1      connected_order_arc_733  -12
    RHS1      connected_order_arc_735  -12
    RHS1      connected_order_arc_737  -12
    RHS1      connected_order_arc_739  -12
    RHS1      connected_order_arc_741  -12
    RHS1      connected_order_arc_743  -12
    RHS1      connected_order_arc_745  -12
    RHS1      connected_order_arc_747  -12
    RHS1      connected_order_arc_749  -12
    RHS1      connected_order_arc_752  -12
    RHS1      connected_order_arc_754  -12
    RHS1      connected_order_arc_756  -12
    RHS1      connected_order_arc_758  -12
    RHS1      connected_order_arc_760  -12
    RHS1      connected_order_arc_762  -12
    RHS1      connected_order_arc_764  -12
    RHS1      connected_order_arc_766  -12
    RHS1      connected_order_arc_768  -12
    RHS1      connected_order_arc_770  -12
    RHS1      connected_order_arc_772  -12
    RHS1      connected_order_arc_775  -12
    RHS1      connected_order_arc_777  -12
    RHS1      connected_order_arc_779  -12
    RHS1      connected_order_arc_781  -12
    RHS1      connected_order_arc_783  -12
    RHS1      connected_order_arc_785  -12
    RHS1      connected_order_arc_787  -12
    RHS1      connected_order_arc_789  -12
    RHS1      connected_order_arc_791  -12
    RHS1      connected_order_arc_793  -12
    RHS1      connected_order_arc_795  -12
    RHS1      connected_order_arc_798  -12
    RHS1      connected_order_arc_800  -12
    RHS1      connected_order_arc_802  -12
    RHS1      connected_order_arc_804  -12
    RHS1      connected_order_arc_806  -12
    RHS1      connected_order_arc_808  -12
    RHS1      connected_order_arc_810  -12
    RHS1      connected_order_arc_812  -12
    RHS1      connected_order_arc_814  -12
    RHS1      connected_order_arc_816  -12
    RHS1      connected_order_arc_818  -12
    RHS1      connected_order_arc_821  -12
    RHS1      connected_order_arc_823  -12
    RHS1      connected_order_arc_825  -12
    RHS1      connected_order_arc_827  -12
    RHS1      connected_order_arc_829  -12
    RHS1      connected_order_arc_831  -12
    RHS1      connected_order_arc_833  -12
    RHS1      connected_order_arc_835  -12
    RHS1      connected_order_arc_837  -12
    RHS1      connected_order_arc_839  -12
    RHS1      connected_order_arc_841  -12
    RHS1      connected_order_arc_844  -12
    RHS1      connected_order_arc_846  -12
    RHS1      connected_order_arc_848  -12
    RHS1      connected_order_arc_850  -12
    RHS1      connected_order_arc_852  -12
    RHS1      connected_order_arc_854  -12
    RHS1      connected_order_arc_856  -12
    RHS1      connected_order_arc_858  -12
    RHS1      connected_order_arc_860  -12
    RHS1      connected_order_arc_862  -12
    RHS1      connected_order_arc_864  -12
    RHS1      connected_order_arc_867  -12
    RHS1      connected_order_arc_869  -12
    RHS1      connected_order_arc_871  -12
    RHS1      connected_order_arc_873  -12
    RHS1      connected_order_arc_875  -12
    RHS1      connected_order_arc_877  -12
    RHS1      connected_order_arc_879  -12
    RHS1      connected_order_arc_881  -12
    RHS1      connected_order_arc_883  -12
    RHS1      connected_order_arc_885  -12
    RHS1      connected_order_arc_887  -12
    RHS1      connected_order_arc_890  -12
    RHS1      connected_order_arc_892  -12
    RHS1      connected_order_arc_894  -12
    RHS1      connected_order_arc_896  -12
    RHS1      connected_order_arc_898  -12
    RHS1      connected_order_arc_900  -12
    RHS1      connected_order_arc_902  -12
    RHS1      connected_order_arc_904  -12
    RHS1      connected_order_arc_906  -12
    RHS1      connected_order_arc_908  -12
    RHS1      connected_order_arc_910  -12
    RHS1      connected_order_arc_913  -12
    RHS1      connected_order_arc_915  -12
    RHS1      connected_order_arc_917  -12
    RHS1      connected_order_arc_919  -12
    RHS1      connected_order_arc_921  -12
    RHS1      connected_order_arc_923  -12
    RHS1      connected_order_arc_925  -12
    RHS1      connected_order_arc_927  -12
    RHS1      connected_order_arc_929  -12
    RHS1      connected_order_arc_931  -12
    RHS1      connected_order_arc_933  -12
    RHS1      connected_order_arc_936  -12
    RHS1      connected_order_arc_938  -12
    RHS1      connected_order_arc_940  -12
    RHS1      connected_order_arc_942  -12
    RHS1      connected_order_arc_944  -12
    RHS1      connected_order_arc_946  -12
    RHS1      connected_order_arc_948  -12
    RHS1      connected_order_arc_950  -12
    RHS1      connected_order_arc_952  -12
    RHS1      connected_order_arc_954  -12
    RHS1      connected_order_arc_956  -12
    RHS1      connected_order_arc_959  -12
    RHS1      connected_order_arc_961  -12
    RHS1      connected_order_arc_963  -12
    RHS1      connected_order_arc_965  -12
    RHS1      connected_order_arc_967  -12
    RHS1      connected_order_arc_969  -12
    RHS1      connected_order_arc_971  -12
    RHS1      connected_order_arc_973  -12
    RHS1      connected_order_arc_975  -12
    RHS1      connected_order_arc_977  -12
    RHS1      connected_order_arc_979  -12
    RHS1      depot_departure_or_bypass_980  1
    RHS1      depot_return_or_bypass_981  1
    RHS1      segment_load_conservation_986  4
    RHS1      segment_prefix_ub_988  20
    RHS1      segment_load_conservation_993  5
    RHS1      segment_prefix_ub_995  20
    RHS1      segment_load_conservation_1000  -4
    RHS1      segment_prefix_lb_1001  4
    RHS1      segment_prefix_ub_1002  25
    RHS1      segment_load_conservation_1007  -5
    RHS1      segment_prefix_lb_1008  5
    RHS1      segment_prefix_ub_1009  25
    RHS1      fixed_segment_relative_order_1058  1
    RHS1      fixed_segment_relative_order_1059  1
    RHS1      fixed_segment_relative_order_1060  1
    RHS1      original_T_including_depot_unload_1061  4.0180155701548429e+03
    RHS1      connected_order_arc_1076  -11
    RHS1      connected_order_arc_1078  -11
    RHS1      connected_order_arc_1080  -11
    RHS1      connected_order_arc_1082  -11
    RHS1      connected_order_arc_1084  -11
    RHS1      connected_order_arc_1086  -11
    RHS1      connected_order_arc_1088  -11
    RHS1      connected_order_arc_1090  -11
    RHS1      connected_order_arc_1092  -11
    RHS1      connected_order_arc_1094  -11
    RHS1      connected_order_arc_1097  -11
    RHS1      connected_order_arc_1099  -11
    RHS1      connected_order_arc_1101  -11
    RHS1      connected_order_arc_1103  -11
    RHS1      connected_order_arc_1105  -11
    RHS1      connected_order_arc_1107  -11
    RHS1      connected_order_arc_1109  -11
    RHS1      connected_order_arc_1111  -11
    RHS1      connected_order_arc_1113  -11
    RHS1      connected_order_arc_1115  -11
    RHS1      connected_order_arc_1118  -11
    RHS1      connected_order_arc_1120  -11
    RHS1      connected_order_arc_1122  -11
    RHS1      connected_order_arc_1124  -11
    RHS1      connected_order_arc_1126  -11
    RHS1      connected_order_arc_1128  -11
    RHS1      connected_order_arc_1130  -11
    RHS1      connected_order_arc_1132  -11
    RHS1      connected_order_arc_1134  -11
    RHS1      connected_order_arc_1136  -11
    RHS1      connected_order_arc_1139  -11
    RHS1      connected_order_arc_1141  -11
    RHS1      connected_order_arc_1143  -11
    RHS1      connected_order_arc_1145  -11
    RHS1      connected_order_arc_1147  -11
    RHS1      connected_order_arc_1149  -11
    RHS1      connected_order_arc_1151  -11
    RHS1      connected_order_arc_1153  -11
    RHS1      connected_order_arc_1155  -11
    RHS1      connected_order_arc_1157  -11
    RHS1      connected_order_arc_1160  -11
    RHS1      connected_order_arc_1162  -11
    RHS1      connected_order_arc_1164  -11
    RHS1      connected_order_arc_1166  -11
    RHS1      connected_order_arc_1168  -11
    RHS1      connected_order_arc_1170  -11
    RHS1      connected_order_arc_1172  -11
    RHS1      connected_order_arc_1174  -11
    RHS1      connected_order_arc_1176  -11
    RHS1      connected_order_arc_1178  -11
    RHS1      connected_order_arc_1181  -11
    RHS1      connected_order_arc_1183  -11
    RHS1      connected_order_arc_1185  -11
    RHS1      connected_order_arc_1187  -11
    RHS1      connected_order_arc_1189  -11
    RHS1      connected_order_arc_1191  -11
    RHS1      connected_order_arc_1193  -11
    RHS1      connected_order_arc_1195  -11
    RHS1      connected_order_arc_1197  -11
    RHS1      connected_order_arc_1199  -11
    RHS1      connected_order_arc_1202  -11
    RHS1      connected_order_arc_1204  -11
    RHS1      connected_order_arc_1206  -11
    RHS1      connected_order_arc_1208  -11
    RHS1      connected_order_arc_1210  -11
    RHS1      connected_order_arc_1212  -11
    RHS1      connected_order_arc_1214  -11
    RHS1      connected_order_arc_1216  -11
    RHS1      connected_order_arc_1218  -11
    RHS1      connected_order_arc_1220  -11
    RHS1      connected_order_arc_1223  -11
    RHS1      connected_order_arc_1225  -11
    RHS1      connected_order_arc_1227  -11
    RHS1      connected_order_arc_1229  -11
    RHS1      connected_order_arc_1231  -11
    RHS1      connected_order_arc_1233  -11
    RHS1      connected_order_arc_1235  -11
    RHS1      connected_order_arc_1237  -11
    RHS1      connected_order_arc_1239  -11
    RHS1      connected_order_arc_1241  -11
    RHS1      connected_order_arc_1244  -11
    RHS1      connected_order_arc_1246  -11
    RHS1      connected_order_arc_1248  -11
    RHS1      connected_order_arc_1250  -11
    RHS1      connected_order_arc_1252  -11
    RHS1      connected_order_arc_1254  -11
    RHS1      connected_order_arc_1256  -11
    RHS1      connected_order_arc_1258  -11
    RHS1      connected_order_arc_1260  -11
    RHS1      connected_order_arc_1262  -11
    RHS1      connected_order_arc_1265  -11
    RHS1      connected_order_arc_1267  -11
    RHS1      connected_order_arc_1269  -11
    RHS1      connected_order_arc_1271  -11
    RHS1      connected_order_arc_1273  -11
    RHS1      connected_order_arc_1275  -11
    RHS1      connected_order_arc_1277  -11
    RHS1      connected_order_arc_1279  -11
    RHS1      connected_order_arc_1281  -11
    RHS1      connected_order_arc_1283  -11
    RHS1      connected_order_arc_1286  -11
    RHS1      connected_order_arc_1288  -11
    RHS1      connected_order_arc_1290  -11
    RHS1      connected_order_arc_1292  -11
    RHS1      connected_order_arc_1294  -11
    RHS1      connected_order_arc_1296  -11
    RHS1      connected_order_arc_1298  -11
    RHS1      connected_order_arc_1300  -11
    RHS1      connected_order_arc_1302  -11
    RHS1      connected_order_arc_1304  -11
    RHS1      depot_departure_or_bypass_1305  1
    RHS1      depot_return_or_bypass_1306  1
    RHS1      segment_load_conservation_1311  2
    RHS1      segment_prefix_ub_1313  28
    RHS1      segment_load_conservation_1318  1
    RHS1      segment_prefix_lb_1319  2
    RHS1      segment_prefix_ub_1320  28
    RHS1      segment_load_conservation_1325  -3
    RHS1      segment_prefix_lb_1326  3
    RHS1      segment_prefix_ub_1327  30
    RHS1      fixed_segment_relative_order_1376  1
    RHS1      fixed_segment_relative_order_1377  1
    RHS1      original_T_including_depot_unload_1378  3.3317427925191068e+03
BOUNDS
 LO BND1      t         2.6035209521422013e-02
 UP BND1      t         4.4376353742978512e-02
 UP BND1      q         4.0162002117312451e-01
 BV BND1      x_20_0  
 UP BND1      w_20_0    4.4376353742978512e-02
 BV BND1      x_20_1  
 UP BND1      w_20_1    4.4376353742978512e-02
 BV BND1      x_20_2  
 UP BND1      w_20_2    4.4376353742978512e-02
 BV BND1      x_20_3  
 UP BND1      w_20_3    4.4376353742978512e-02
 BV BND1      x_20_4  
 UP BND1      w_20_4    4.4376353742978512e-02
 BV BND1      x_20_5  
 UP BND1      w_20_5    4.4376353742978512e-02
 BV BND1      x_20_6  
 UP BND1      w_20_6    4.4376353742978512e-02
 BV BND1      x_20_7  
 UP BND1      w_20_7    4.4376353742978512e-02
 BV BND1      x_20_8  
 UP BND1      w_20_8    4.4376353742978512e-02
 BV BND1      x_20_9  
 UP BND1      w_20_9    4.4376353742978512e-02
 BV BND1      x_20_10 
 UP BND1      w_20_10   4.4376353742978512e-02
 UP BND1      rho_20    1
 BV BND1      x_21_0  
 UP BND1      w_21_0    4.4376353742978512e-02
 BV BND1      x_21_1  
 UP BND1      w_21_1    4.4376353742978512e-02
 BV BND1      x_21_2  
 UP BND1      w_21_2    4.4376353742978512e-02
 BV BND1      x_21_3  
 UP BND1      w_21_3    4.4376353742978512e-02
 BV BND1      x_21_4  
 UP BND1      w_21_4    4.4376353742978512e-02
 BV BND1      x_21_5  
 UP BND1      w_21_5    4.4376353742978512e-02
 BV BND1      x_21_6  
 UP BND1      w_21_6    4.4376353742978512e-02
 UP BND1      rho_21    1
 BV BND1      x_34_0  
 UP BND1      w_34_0    4.4376353742978512e-02
 BV BND1      x_34_1  
 UP BND1      w_34_1    4.4376353742978512e-02
 BV BND1      x_34_2  
 UP BND1      w_34_2    4.4376353742978512e-02
 BV BND1      x_34_3  
 UP BND1      w_34_3    4.4376353742978512e-02
 BV BND1      x_34_4  
 UP BND1      w_34_4    4.4376353742978512e-02
 BV BND1      x_34_5  
 UP BND1      w_34_5    4.4376353742978512e-02
 BV BND1      x_34_6  
 UP BND1      w_34_6    4.4376353742978512e-02
 BV BND1      x_34_7  
 UP BND1      w_34_7    4.4376353742978512e-02
 BV BND1      x_34_8  
 UP BND1      w_34_8    4.4376353742978512e-02
 BV BND1      x_34_9  
 UP BND1      w_34_9    4.4376353742978512e-02
 BV BND1      x_34_10 
 UP BND1      w_34_10   4.4376353742978512e-02
 BV BND1      x_34_11 
 UP BND1      w_34_11   4.4376353742978512e-02
 BV BND1      x_34_12 
 UP BND1      w_34_12   4.4376353742978512e-02
 BV BND1      x_34_13 
 UP BND1      w_34_13   4.4376353742978512e-02
 BV BND1      x_34_14 
 UP BND1      w_34_14   4.4376353742978512e-02
 BV BND1      x_34_15 
 UP BND1      w_34_15   4.4376353742978512e-02
 UP BND1      rho_34    1
 BV BND1      x_19_0  
 UP BND1      w_19_0    4.4376353742978512e-02
 BV BND1      x_19_1  
 UP BND1      w_19_1    4.4376353742978512e-02
 BV BND1      x_19_2  
 UP BND1      w_19_2    4.4376353742978512e-02
 BV BND1      x_19_3  
 UP BND1      w_19_3    4.4376353742978512e-02
 BV BND1      x_19_4  
 UP BND1      w_19_4    4.4376353742978512e-02
 BV BND1      x_19_5  
 UP BND1      w_19_5    4.4376353742978512e-02
 BV BND1      x_19_6  
 UP BND1      w_19_6    4.4376353742978512e-02
 BV BND1      x_19_7  
 UP BND1      w_19_7    4.4376353742978512e-02
 BV BND1      x_19_8  
 UP BND1      w_19_8    4.4376353742978512e-02
 BV BND1      x_19_9  
 UP BND1      w_19_9    4.4376353742978512e-02
 BV BND1      x_19_10 
 UP BND1      w_19_10   4.4376353742978512e-02
 UP BND1      rho_19    1
 BV BND1      x_29_0  
 UP BND1      w_29_0    4.4376353742978512e-02
 BV BND1      x_29_1  
 UP BND1      w_29_1    4.4376353742978512e-02
 BV BND1      x_29_2  
 UP BND1      w_29_2    4.4376353742978512e-02
 BV BND1      x_29_3  
 UP BND1      w_29_3    4.4376353742978512e-02
 BV BND1      x_29_4  
 UP BND1      w_29_4    4.4376353742978512e-02
 BV BND1      x_29_5  
 UP BND1      w_29_5    4.4376353742978512e-02
 BV BND1      x_29_6  
 UP BND1      w_29_6    4.4376353742978512e-02
 BV BND1      x_29_7  
 UP BND1      w_29_7    4.4376353742978512e-02
 BV BND1      x_29_8  
 UP BND1      w_29_8    4.4376353742978512e-02
 BV BND1      x_29_9  
 UP BND1      w_29_9    4.4376353742978512e-02
 BV BND1      x_29_10 
 UP BND1      w_29_10   4.4376353742978512e-02
 UP BND1      rho_29    1
 BV BND1      x_18_0  
 UP BND1      w_18_0    4.4376353742978512e-02
 BV BND1      x_18_1  
 UP BND1      w_18_1    4.4376353742978512e-02
 BV BND1      x_18_2  
 UP BND1      w_18_2    4.4376353742978512e-02
 BV BND1      x_18_3  
 UP BND1      w_18_3    4.4376353742978512e-02
 BV BND1      x_18_4  
 UP BND1      w_18_4    4.4376353742978512e-02
 BV BND1      x_18_5  
 UP BND1      w_18_5    4.4376353742978512e-02
 BV BND1      x_18_6  
 UP BND1      w_18_6    4.4376353742978512e-02
 BV BND1      x_18_7  
 UP BND1      w_18_7    4.4376353742978512e-02
 BV BND1      x_18_8  
 UP BND1      w_18_8    4.4376353742978512e-02
 BV BND1      x_18_9  
 UP BND1      w_18_9    4.4376353742978512e-02
 BV BND1      x_18_10 
 UP BND1      w_18_10   4.4376353742978512e-02
 UP BND1      rho_18    1
 BV BND1      x_27_0  
 UP BND1      w_27_0    4.4376353742978512e-02
 BV BND1      x_27_1  
 UP BND1      w_27_1    4.4376353742978512e-02
 BV BND1      x_27_2  
 UP BND1      w_27_2    4.4376353742978512e-02
 BV BND1      x_27_3  
 UP BND1      w_27_3    4.4376353742978512e-02
 BV BND1      x_27_4  
 UP BND1      w_27_4    4.4376353742978512e-02
 BV BND1      x_27_5  
 UP BND1      w_27_5    4.4376353742978512e-02
 BV BND1      x_27_6  
 UP BND1      w_27_6    4.4376353742978512e-02
 UP BND1      rho_27    1
 BV BND1      x_17_0  
 UP BND1      w_17_0    4.4376353742978512e-02
 BV BND1      x_17_1  
 UP BND1      w_17_1    4.4376353742978512e-02
 BV BND1      x_17_2  
 UP BND1      w_17_2    4.4376353742978512e-02
 BV BND1      x_17_3  
 UP BND1      w_17_3    4.4376353742978512e-02
 BV BND1      x_17_4  
 UP BND1      w_17_4    4.4376353742978512e-02
 BV BND1      x_17_5  
 UP BND1      w_17_5    4.4376353742978512e-02
 BV BND1      x_17_6  
 UP BND1      w_17_6    4.4376353742978512e-02
 UP BND1      rho_17    1
 UP BND1      a_20_21   1
 UP BND1      a_20_34   1
 UP BND1      a_20_19   1
 UP BND1      a_20_29   1
 UP BND1      a_20_18   1
 UP BND1      a_20_27   1
 UP BND1      a_20_17   1
 UP BND1      a_21_34   1
 UP BND1      a_21_19   1
 UP BND1      a_21_29   1
 UP BND1      a_21_18   1
 UP BND1      a_21_27   1
 UP BND1      a_21_17   1
 UP BND1      a_34_19   1
 UP BND1      a_34_29   1
 UP BND1      a_34_18   1
 UP BND1      a_34_27   1
 UP BND1      a_34_17   1
 UP BND1      a_19_29   1
 UP BND1      a_19_18   1
 UP BND1      a_19_27   1
 UP BND1      a_19_17   1
 UP BND1      a_29_18   1
 UP BND1      a_29_27   1
 UP BND1      a_29_17   1
 UP BND1      a_18_27   1
 UP BND1      a_18_17   1
 UP BND1      a_27_17   1
 BV BND1      service_0_20_0
 BV BND1      service_0_20_1
 BV BND1      service_0_20_2
 BV BND1      service_0_20_3
 BV BND1      service_0_20_4
 BV BND1      service_0_20_5
 BV BND1      service_0_20_6
 BV BND1      service_0_20_8
 BV BND1      service_0_20_9
 BV BND1      service_0_20_10
 BV BND1      service_1_20_0
 BV BND1      service_1_20_1
 BV BND1      service_1_20_2
 BV BND1      service_1_20_3
 BV BND1      service_1_20_4
 BV BND1      service_1_20_5
 BV BND1      service_1_20_6
 BV BND1      service_1_20_8
 BV BND1      service_1_20_9
 BV BND1      service_1_20_10
 BV BND1      service_2_20_0
 BV BND1      service_2_20_1
 BV BND1      service_2_20_2
 BV BND1      service_2_20_3
 BV BND1      service_2_20_4
 BV BND1      service_2_20_5
 BV BND1      service_2_20_6
 BV BND1      service_2_20_8
 BV BND1      service_2_20_9
 BV BND1      service_2_20_10
 BV BND1      service_0_21_1
 BV BND1      service_0_21_2
 BV BND1      service_0_21_3
 BV BND1      service_0_21_4
 BV BND1      service_0_21_5
 BV BND1      service_0_21_6
 BV BND1      service_1_21_1
 BV BND1      service_1_21_2
 BV BND1      service_1_21_3
 BV BND1      service_1_21_4
 BV BND1      service_1_21_5
 BV BND1      service_1_21_6
 BV BND1      service_2_21_1
 BV BND1      service_2_21_2
 BV BND1      service_2_21_3
 BV BND1      service_2_21_4
 BV BND1      service_2_21_5
 BV BND1      service_2_21_6
 BV BND1      service_0_34_0
 BV BND1      service_0_34_1
 BV BND1      service_0_34_3
 BV BND1      service_0_34_4
 BV BND1      service_0_34_5
 BV BND1      service_0_34_6
 BV BND1      service_0_34_7
 BV BND1      service_0_34_8
 BV BND1      service_0_34_9
 BV BND1      service_0_34_10
 BV BND1      service_0_34_11
 BV BND1      service_0_34_12
 BV BND1      service_0_34_13
 BV BND1      service_0_34_14
 BV BND1      service_0_34_15
 BV BND1      service_1_34_0
 BV BND1      service_1_34_1
 BV BND1      service_1_34_3
 BV BND1      service_1_34_4
 BV BND1      service_1_34_5
 BV BND1      service_1_34_6
 BV BND1      service_1_34_7
 BV BND1      service_1_34_8
 BV BND1      service_1_34_9
 BV BND1      service_1_34_10
 BV BND1      service_1_34_11
 BV BND1      service_1_34_12
 BV BND1      service_1_34_13
 BV BND1      service_1_34_14
 BV BND1      service_1_34_15
 BV BND1      service_2_34_0
 BV BND1      service_2_34_1
 BV BND1      service_2_34_3
 BV BND1      service_2_34_4
 BV BND1      service_2_34_5
 BV BND1      service_2_34_6
 BV BND1      service_2_34_7
 BV BND1      service_2_34_8
 BV BND1      service_2_34_9
 BV BND1      service_2_34_10
 BV BND1      service_2_34_11
 BV BND1      service_2_34_12
 BV BND1      service_2_34_13
 BV BND1      service_2_34_14
 BV BND1      service_2_34_15
 BV BND1      service_0_19_0
 BV BND1      service_0_19_2
 BV BND1      service_0_19_3
 BV BND1      service_0_19_4
 BV BND1      service_0_19_5
 BV BND1      service_0_19_6
 BV BND1      service_0_19_7
 BV BND1      service_0_19_8
 BV BND1      service_0_19_9
 BV BND1      service_0_19_10
 BV BND1      service_1_19_0
 BV BND1      service_1_19_2
 BV BND1      service_1_19_3
 BV BND1      service_1_19_4
 BV BND1      service_1_19_5
 BV BND1      service_1_19_6
 BV BND1      service_1_19_7
 BV BND1      service_1_19_8
 BV BND1      service_1_19_9
 BV BND1      service_1_19_10
 BV BND1      service_2_19_0
 BV BND1      service_2_19_2
 BV BND1      service_2_19_3
 BV BND1      service_2_19_4
 BV BND1      service_2_19_5
 BV BND1      service_2_19_6
 BV BND1      service_2_19_7
 BV BND1      service_2_19_8
 BV BND1      service_2_19_9
 BV BND1      service_2_19_10
 BV BND1      service_0_29_0
 BV BND1      service_0_29_2
 BV BND1      service_0_29_3
 BV BND1      service_0_29_4
 BV BND1      service_0_29_5
 BV BND1      service_0_29_6
 BV BND1      service_0_29_7
 BV BND1      service_0_29_8
 BV BND1      service_0_29_9
 BV BND1      service_0_29_10
 BV BND1      service_1_29_0
 BV BND1      service_1_29_2
 BV BND1      service_1_29_3
 BV BND1      service_1_29_4
 BV BND1      service_1_29_5
 BV BND1      service_1_29_6
 BV BND1      service_1_29_7
 BV BND1      service_1_29_8
 BV BND1      service_1_29_9
 BV BND1      service_1_29_10
 BV BND1      service_2_29_0
 BV BND1      service_2_29_2
 BV BND1      service_2_29_3
 BV BND1      service_2_29_4
 BV BND1      service_2_29_5
 BV BND1      service_2_29_6
 BV BND1      service_2_29_7
 BV BND1      service_2_29_8
 BV BND1      service_2_29_9
 BV BND1      service_2_29_10
 BV BND1      service_0_18_0
 BV BND1      service_0_18_1
 BV BND1      service_0_18_2
 BV BND1      service_0_18_3
 BV BND1      service_0_18_4
 BV BND1      service_0_18_5
 BV BND1      service_0_18_6
 BV BND1      service_0_18_7
 BV BND1      service_0_18_9
 BV BND1      service_0_18_10
 BV BND1      service_1_18_0
 BV BND1      service_1_18_1
 BV BND1      service_1_18_2
 BV BND1      service_1_18_3
 BV BND1      service_1_18_4
 BV BND1      service_1_18_5
 BV BND1      service_1_18_6
 BV BND1      service_1_18_7
 BV BND1      service_1_18_9
 BV BND1      service_1_18_10
 BV BND1      service_2_18_0
 BV BND1      service_2_18_1
 BV BND1      service_2_18_2
 BV BND1      service_2_18_3
 BV BND1      service_2_18_4
 BV BND1      service_2_18_5
 BV BND1      service_2_18_6
 BV BND1      service_2_18_7
 BV BND1      service_2_18_9
 BV BND1      service_2_18_10
 BV BND1      service_0_27_1
 BV BND1      service_0_27_2
 BV BND1      service_0_27_3
 BV BND1      service_0_27_4
 BV BND1      service_0_27_5
 BV BND1      service_0_27_6
 BV BND1      service_1_27_1
 BV BND1      service_1_27_2
 BV BND1      service_1_27_3
 BV BND1      service_1_27_4
 BV BND1      service_1_27_5
 BV BND1      service_1_27_6
 BV BND1      service_2_27_1
 BV BND1      service_2_27_2
 BV BND1      service_2_27_3
 BV BND1      service_2_27_4
 BV BND1      service_2_27_5
 BV BND1      service_2_27_6
 BV BND1      service_0_17_0
 BV BND1      service_0_17_1
 BV BND1      service_0_17_2
 BV BND1      service_0_17_3
 BV BND1      service_0_17_4
 BV BND1      service_0_17_6
 BV BND1      service_1_17_0
 BV BND1      service_1_17_1
 BV BND1      service_1_17_2
 BV BND1      service_1_17_3
 BV BND1      service_1_17_4
 BV BND1      service_1_17_6
 BV BND1      service_2_17_0
 BV BND1      service_2_17_1
 BV BND1      service_2_17_2
 BV BND1      service_2_17_3
 BV BND1      service_2_17_4
 BV BND1      service_2_17_6
 FX BND1      visit_0_1  1
 UP BND1      order_0_1  12
 FX BND1      visit_0_2  1
 UP BND1      order_0_2  12
 FX BND1      visit_0_3  1
 UP BND1      order_0_3  12
 FX BND1      visit_0_4  1
 UP BND1      order_0_4  12
 UP BND1      visit_0_12  1
 UP BND1      order_0_12  12
 UP BND1      visit_0_13  1
 UP BND1      order_0_13  12
 UP BND1      visit_0_14  1
 UP BND1      order_0_14  12
 UP BND1      visit_0_15  1
 UP BND1      order_0_15  12
 UP BND1      visit_0_16  1
 UP BND1      order_0_16  12
 UP BND1      visit_0_17  1
 UP BND1      order_0_17  12
 UP BND1      visit_0_18  1
 UP BND1      order_0_18  12
 UP BND1      visit_0_19  1
 UP BND1      order_0_19  12
 BV BND1      arc_0_0_0
 FX BND1      load_0_0_0  0
 BV BND1      arc_0_0_1
 FX BND1      load_0_0_1  0
 BV BND1      arc_0_0_2
 FX BND1      load_0_0_2  0
 BV BND1      arc_0_0_3
 FX BND1      load_0_0_3  0
 BV BND1      arc_0_0_4
 FX BND1      load_0_0_4  0
 BV BND1      arc_0_0_12
 FX BND1      load_0_0_12  0
 BV BND1      arc_0_0_13
 FX BND1      load_0_0_13  0
 BV BND1      arc_0_0_14
 FX BND1      load_0_0_14  0
 BV BND1      arc_0_0_15
 FX BND1      load_0_0_15  0
 BV BND1      arc_0_0_16
 FX BND1      load_0_0_16  0
 BV BND1      arc_0_0_17
 FX BND1      load_0_0_17  0
 BV BND1      arc_0_0_18
 FX BND1      load_0_0_18  0
 BV BND1      arc_0_0_19
 FX BND1      load_0_0_19  0
 BV BND1      arc_0_1_0
 UP BND1      load_0_1_0  20
 BV BND1      arc_0_1_2
 UP BND1      load_0_1_2  20
 BV BND1      arc_0_1_3
 UP BND1      load_0_1_3  20
 BV BND1      arc_0_1_4
 UP BND1      load_0_1_4  20
 BV BND1      arc_0_1_12
 UP BND1      load_0_1_12  20
 BV BND1      arc_0_1_13
 UP BND1      load_0_1_13  20
 BV BND1      arc_0_1_14
 UP BND1      load_0_1_14  20
 BV BND1      arc_0_1_15
 UP BND1      load_0_1_15  20
 BV BND1      arc_0_1_16
 UP BND1      load_0_1_16  20
 BV BND1      arc_0_1_17
 UP BND1      load_0_1_17  20
 BV BND1      arc_0_1_18
 UP BND1      load_0_1_18  20
 BV BND1      arc_0_1_19
 UP BND1      load_0_1_19  20
 BV BND1      arc_0_2_0
 UP BND1      load_0_2_0  20
 BV BND1      arc_0_2_1
 UP BND1      load_0_2_1  20
 BV BND1      arc_0_2_3
 UP BND1      load_0_2_3  20
 BV BND1      arc_0_2_4
 UP BND1      load_0_2_4  20
 BV BND1      arc_0_2_12
 UP BND1      load_0_2_12  20
 BV BND1      arc_0_2_13
 UP BND1      load_0_2_13  20
 BV BND1      arc_0_2_14
 UP BND1      load_0_2_14  20
 BV BND1      arc_0_2_15
 UP BND1      load_0_2_15  20
 BV BND1      arc_0_2_16
 UP BND1      load_0_2_16  20
 BV BND1      arc_0_2_17
 UP BND1      load_0_2_17  20
 BV BND1      arc_0_2_18
 UP BND1      load_0_2_18  20
 BV BND1      arc_0_2_19
 UP BND1      load_0_2_19  20
 BV BND1      arc_0_3_0
 UP BND1      load_0_3_0  20
 BV BND1      arc_0_3_1
 UP BND1      load_0_3_1  20
 BV BND1      arc_0_3_2
 UP BND1      load_0_3_2  20
 BV BND1      arc_0_3_4
 UP BND1      load_0_3_4  20
 BV BND1      arc_0_3_12
 UP BND1      load_0_3_12  20
 BV BND1      arc_0_3_13
 UP BND1      load_0_3_13  20
 BV BND1      arc_0_3_14
 UP BND1      load_0_3_14  20
 BV BND1      arc_0_3_15
 UP BND1      load_0_3_15  20
 BV BND1      arc_0_3_16
 UP BND1      load_0_3_16  20
 BV BND1      arc_0_3_17
 UP BND1      load_0_3_17  20
 BV BND1      arc_0_3_18
 UP BND1      load_0_3_18  20
 BV BND1      arc_0_3_19
 UP BND1      load_0_3_19  20
 BV BND1      arc_0_4_0
 UP BND1      load_0_4_0  20
 BV BND1      arc_0_4_1
 UP BND1      load_0_4_1  20
 BV BND1      arc_0_4_2
 UP BND1      load_0_4_2  20
 BV BND1      arc_0_4_3
 UP BND1      load_0_4_3  20
 BV BND1      arc_0_4_12
 UP BND1      load_0_4_12  20
 BV BND1      arc_0_4_13
 UP BND1      load_0_4_13  20
 BV BND1      arc_0_4_14
 UP BND1      load_0_4_14  20
 BV BND1      arc_0_4_15
 UP BND1      load_0_4_15  20
 BV BND1      arc_0_4_16
 UP BND1      load_0_4_16  20
 BV BND1      arc_0_4_17
 UP BND1      load_0_4_17  20
 BV BND1      arc_0_4_18
 UP BND1      load_0_4_18  20
 BV BND1      arc_0_4_19
 UP BND1      load_0_4_19  20
 BV BND1      arc_0_12_0
 UP BND1      load_0_12_0  20
 BV BND1      arc_0_12_1
 UP BND1      load_0_12_1  20
 BV BND1      arc_0_12_2
 UP BND1      load_0_12_2  20
 BV BND1      arc_0_12_3
 UP BND1      load_0_12_3  20
 BV BND1      arc_0_12_4
 UP BND1      load_0_12_4  20
 BV BND1      arc_0_12_13
 UP BND1      load_0_12_13  20
 BV BND1      arc_0_12_14
 UP BND1      load_0_12_14  20
 BV BND1      arc_0_12_15
 UP BND1      load_0_12_15  20
 BV BND1      arc_0_12_16
 UP BND1      load_0_12_16  20
 BV BND1      arc_0_12_17
 UP BND1      load_0_12_17  20
 BV BND1      arc_0_12_18
 UP BND1      load_0_12_18  20
 BV BND1      arc_0_12_19
 UP BND1      load_0_12_19  20
 BV BND1      arc_0_13_0
 UP BND1      load_0_13_0  20
 BV BND1      arc_0_13_1
 UP BND1      load_0_13_1  20
 BV BND1      arc_0_13_2
 UP BND1      load_0_13_2  20
 BV BND1      arc_0_13_3
 UP BND1      load_0_13_3  20
 BV BND1      arc_0_13_4
 UP BND1      load_0_13_4  20
 BV BND1      arc_0_13_12
 UP BND1      load_0_13_12  20
 BV BND1      arc_0_13_14
 UP BND1      load_0_13_14  20
 BV BND1      arc_0_13_15
 UP BND1      load_0_13_15  20
 BV BND1      arc_0_13_16
 UP BND1      load_0_13_16  20
 BV BND1      arc_0_13_17
 UP BND1      load_0_13_17  20
 BV BND1      arc_0_13_18
 UP BND1      load_0_13_18  20
 BV BND1      arc_0_13_19
 UP BND1      load_0_13_19  20
 BV BND1      arc_0_14_0
 UP BND1      load_0_14_0  20
 BV BND1      arc_0_14_1
 UP BND1      load_0_14_1  20
 BV BND1      arc_0_14_2
 UP BND1      load_0_14_2  20
 BV BND1      arc_0_14_3
 UP BND1      load_0_14_3  20
 BV BND1      arc_0_14_4
 UP BND1      load_0_14_4  20
 BV BND1      arc_0_14_12
 UP BND1      load_0_14_12  20
 BV BND1      arc_0_14_13
 UP BND1      load_0_14_13  20
 BV BND1      arc_0_14_15
 UP BND1      load_0_14_15  20
 BV BND1      arc_0_14_16
 UP BND1      load_0_14_16  20
 BV BND1      arc_0_14_17
 UP BND1      load_0_14_17  20
 BV BND1      arc_0_14_18
 UP BND1      load_0_14_18  20
 BV BND1      arc_0_14_19
 UP BND1      load_0_14_19  20
 BV BND1      arc_0_15_0
 UP BND1      load_0_15_0  20
 BV BND1      arc_0_15_1
 UP BND1      load_0_15_1  20
 BV BND1      arc_0_15_2
 UP BND1      load_0_15_2  20
 BV BND1      arc_0_15_3
 UP BND1      load_0_15_3  20
 BV BND1      arc_0_15_4
 UP BND1      load_0_15_4  20
 BV BND1      arc_0_15_12
 UP BND1      load_0_15_12  20
 BV BND1      arc_0_15_13
 UP BND1      load_0_15_13  20
 BV BND1      arc_0_15_14
 UP BND1      load_0_15_14  20
 BV BND1      arc_0_15_16
 UP BND1      load_0_15_16  20
 BV BND1      arc_0_15_17
 UP BND1      load_0_15_17  20
 BV BND1      arc_0_15_18
 UP BND1      load_0_15_18  20
 BV BND1      arc_0_15_19
 UP BND1      load_0_15_19  20
 BV BND1      arc_0_16_0
 UP BND1      load_0_16_0  20
 BV BND1      arc_0_16_1
 UP BND1      load_0_16_1  20
 BV BND1      arc_0_16_2
 UP BND1      load_0_16_2  20
 BV BND1      arc_0_16_3
 UP BND1      load_0_16_3  20
 BV BND1      arc_0_16_4
 UP BND1      load_0_16_4  20
 BV BND1      arc_0_16_12
 UP BND1      load_0_16_12  20
 BV BND1      arc_0_16_13
 UP BND1      load_0_16_13  20
 BV BND1      arc_0_16_14
 UP BND1      load_0_16_14  20
 BV BND1      arc_0_16_15
 UP BND1      load_0_16_15  20
 BV BND1      arc_0_16_17
 UP BND1      load_0_16_17  20
 BV BND1      arc_0_16_18
 UP BND1      load_0_16_18  20
 BV BND1      arc_0_16_19
 UP BND1      load_0_16_19  20
 BV BND1      arc_0_17_0
 UP BND1      load_0_17_0  20
 BV BND1      arc_0_17_1
 UP BND1      load_0_17_1  20
 BV BND1      arc_0_17_2
 UP BND1      load_0_17_2  20
 BV BND1      arc_0_17_3
 UP BND1      load_0_17_3  20
 BV BND1      arc_0_17_4
 UP BND1      load_0_17_4  20
 BV BND1      arc_0_17_12
 UP BND1      load_0_17_12  20
 BV BND1      arc_0_17_13
 UP BND1      load_0_17_13  20
 BV BND1      arc_0_17_14
 UP BND1      load_0_17_14  20
 BV BND1      arc_0_17_15
 UP BND1      load_0_17_15  20
 BV BND1      arc_0_17_16
 UP BND1      load_0_17_16  20
 BV BND1      arc_0_17_18
 UP BND1      load_0_17_18  20
 BV BND1      arc_0_17_19
 UP BND1      load_0_17_19  20
 BV BND1      arc_0_18_0
 UP BND1      load_0_18_0  20
 BV BND1      arc_0_18_1
 UP BND1      load_0_18_1  20
 BV BND1      arc_0_18_2
 UP BND1      load_0_18_2  20
 BV BND1      arc_0_18_3
 UP BND1      load_0_18_3  20
 BV BND1      arc_0_18_4
 UP BND1      load_0_18_4  20
 BV BND1      arc_0_18_12
 UP BND1      load_0_18_12  20
 BV BND1      arc_0_18_13
 UP BND1      load_0_18_13  20
 BV BND1      arc_0_18_14
 UP BND1      load_0_18_14  20
 BV BND1      arc_0_18_15
 UP BND1      load_0_18_15  20
 BV BND1      arc_0_18_16
 UP BND1      load_0_18_16  20
 BV BND1      arc_0_18_17
 UP BND1      load_0_18_17  20
 BV BND1      arc_0_18_19
 UP BND1      load_0_18_19  20
 BV BND1      arc_0_19_0
 UP BND1      load_0_19_0  20
 BV BND1      arc_0_19_1
 UP BND1      load_0_19_1  20
 BV BND1      arc_0_19_2
 UP BND1      load_0_19_2  20
 BV BND1      arc_0_19_3
 UP BND1      load_0_19_3  20
 BV BND1      arc_0_19_4
 UP BND1      load_0_19_4  20
 BV BND1      arc_0_19_12
 UP BND1      load_0_19_12  20
 BV BND1      arc_0_19_13
 UP BND1      load_0_19_13  20
 BV BND1      arc_0_19_14
 UP BND1      load_0_19_14  20
 BV BND1      arc_0_19_15
 UP BND1      load_0_19_15  20
 BV BND1      arc_0_19_16
 UP BND1      load_0_19_16  20
 BV BND1      arc_0_19_17
 UP BND1      load_0_19_17  20
 BV BND1      arc_0_19_18
 UP BND1      load_0_19_18  20
 FX BND1      visit_1_5  1
 UP BND1      order_1_5  12
 FX BND1      visit_1_6  1
 UP BND1      order_1_6  12
 FX BND1      visit_1_7  1
 UP BND1      order_1_7  12
 FX BND1      visit_1_8  1
 UP BND1      order_1_8  12
 UP BND1      visit_1_12  1
 UP BND1      order_1_12  12
 UP BND1      visit_1_13  1
 UP BND1      order_1_13  12
 UP BND1      visit_1_14  1
 UP BND1      order_1_14  12
 UP BND1      visit_1_15  1
 UP BND1      order_1_15  12
 UP BND1      visit_1_16  1
 UP BND1      order_1_16  12
 UP BND1      visit_1_17  1
 UP BND1      order_1_17  12
 UP BND1      visit_1_18  1
 UP BND1      order_1_18  12
 UP BND1      visit_1_19  1
 UP BND1      order_1_19  12
 BV BND1      arc_1_0_0
 FX BND1      load_1_0_0  0
 BV BND1      arc_1_0_5
 FX BND1      load_1_0_5  0
 BV BND1      arc_1_0_6
 FX BND1      load_1_0_6  0
 BV BND1      arc_1_0_7
 FX BND1      load_1_0_7  0
 BV BND1      arc_1_0_8
 FX BND1      load_1_0_8  0
 BV BND1      arc_1_0_12
 FX BND1      load_1_0_12  0
 BV BND1      arc_1_0_13
 FX BND1      load_1_0_13  0
 BV BND1      arc_1_0_14
 FX BND1      load_1_0_14  0
 BV BND1      arc_1_0_15
 FX BND1      load_1_0_15  0
 BV BND1      arc_1_0_16
 FX BND1      load_1_0_16  0
 BV BND1      arc_1_0_17
 FX BND1      load_1_0_17  0
 BV BND1      arc_1_0_18
 FX BND1      load_1_0_18  0
 BV BND1      arc_1_0_19
 FX BND1      load_1_0_19  0
 BV BND1      arc_1_5_0
 UP BND1      load_1_5_0  25
 BV BND1      arc_1_5_6
 UP BND1      load_1_5_6  25
 BV BND1      arc_1_5_7
 UP BND1      load_1_5_7  25
 BV BND1      arc_1_5_8
 UP BND1      load_1_5_8  25
 BV BND1      arc_1_5_12
 UP BND1      load_1_5_12  25
 BV BND1      arc_1_5_13
 UP BND1      load_1_5_13  25
 BV BND1      arc_1_5_14
 UP BND1      load_1_5_14  25
 BV BND1      arc_1_5_15
 UP BND1      load_1_5_15  25
 BV BND1      arc_1_5_16
 UP BND1      load_1_5_16  25
 BV BND1      arc_1_5_17
 UP BND1      load_1_5_17  25
 BV BND1      arc_1_5_18
 UP BND1      load_1_5_18  25
 BV BND1      arc_1_5_19
 UP BND1      load_1_5_19  25
 BV BND1      arc_1_6_0
 UP BND1      load_1_6_0  25
 BV BND1      arc_1_6_5
 UP BND1      load_1_6_5  25
 BV BND1      arc_1_6_7
 UP BND1      load_1_6_7  25
 BV BND1      arc_1_6_8
 UP BND1      load_1_6_8  25
 BV BND1      arc_1_6_12
 UP BND1      load_1_6_12  25
 BV BND1      arc_1_6_13
 UP BND1      load_1_6_13  25
 BV BND1      arc_1_6_14
 UP BND1      load_1_6_14  25
 BV BND1      arc_1_6_15
 UP BND1      load_1_6_15  25
 BV BND1      arc_1_6_16
 UP BND1      load_1_6_16  25
 BV BND1      arc_1_6_17
 UP BND1      load_1_6_17  25
 BV BND1      arc_1_6_18
 UP BND1      load_1_6_18  25
 BV BND1      arc_1_6_19
 UP BND1      load_1_6_19  25
 BV BND1      arc_1_7_0
 UP BND1      load_1_7_0  25
 BV BND1      arc_1_7_5
 UP BND1      load_1_7_5  25
 BV BND1      arc_1_7_6
 UP BND1      load_1_7_6  25
 BV BND1      arc_1_7_8
 UP BND1      load_1_7_8  25
 BV BND1      arc_1_7_12
 UP BND1      load_1_7_12  25
 BV BND1      arc_1_7_13
 UP BND1      load_1_7_13  25
 BV BND1      arc_1_7_14
 UP BND1      load_1_7_14  25
 BV BND1      arc_1_7_15
 UP BND1      load_1_7_15  25
 BV BND1      arc_1_7_16
 UP BND1      load_1_7_16  25
 BV BND1      arc_1_7_17
 UP BND1      load_1_7_17  25
 BV BND1      arc_1_7_18
 UP BND1      load_1_7_18  25
 BV BND1      arc_1_7_19
 UP BND1      load_1_7_19  25
 BV BND1      arc_1_8_0
 UP BND1      load_1_8_0  25
 BV BND1      arc_1_8_5
 UP BND1      load_1_8_5  25
 BV BND1      arc_1_8_6
 UP BND1      load_1_8_6  25
 BV BND1      arc_1_8_7
 UP BND1      load_1_8_7  25
 BV BND1      arc_1_8_12
 UP BND1      load_1_8_12  25
 BV BND1      arc_1_8_13
 UP BND1      load_1_8_13  25
 BV BND1      arc_1_8_14
 UP BND1      load_1_8_14  25
 BV BND1      arc_1_8_15
 UP BND1      load_1_8_15  25
 BV BND1      arc_1_8_16
 UP BND1      load_1_8_16  25
 BV BND1      arc_1_8_17
 UP BND1      load_1_8_17  25
 BV BND1      arc_1_8_18
 UP BND1      load_1_8_18  25
 BV BND1      arc_1_8_19
 UP BND1      load_1_8_19  25
 BV BND1      arc_1_12_0
 UP BND1      load_1_12_0  25
 BV BND1      arc_1_12_5
 UP BND1      load_1_12_5  25
 BV BND1      arc_1_12_6
 UP BND1      load_1_12_6  25
 BV BND1      arc_1_12_7
 UP BND1      load_1_12_7  25
 BV BND1      arc_1_12_8
 UP BND1      load_1_12_8  25
 BV BND1      arc_1_12_13
 UP BND1      load_1_12_13  25
 BV BND1      arc_1_12_14
 UP BND1      load_1_12_14  25
 BV BND1      arc_1_12_15
 UP BND1      load_1_12_15  25
 BV BND1      arc_1_12_16
 UP BND1      load_1_12_16  25
 BV BND1      arc_1_12_17
 UP BND1      load_1_12_17  25
 BV BND1      arc_1_12_18
 UP BND1      load_1_12_18  25
 BV BND1      arc_1_12_19
 UP BND1      load_1_12_19  25
 BV BND1      arc_1_13_0
 UP BND1      load_1_13_0  25
 BV BND1      arc_1_13_5
 UP BND1      load_1_13_5  25
 BV BND1      arc_1_13_6
 UP BND1      load_1_13_6  25
 BV BND1      arc_1_13_7
 UP BND1      load_1_13_7  25
 BV BND1      arc_1_13_8
 UP BND1      load_1_13_8  25
 BV BND1      arc_1_13_12
 UP BND1      load_1_13_12  25
 BV BND1      arc_1_13_14
 UP BND1      load_1_13_14  25
 BV BND1      arc_1_13_15
 UP BND1      load_1_13_15  25
 BV BND1      arc_1_13_16
 UP BND1      load_1_13_16  25
 BV BND1      arc_1_13_17
 UP BND1      load_1_13_17  25
 BV BND1      arc_1_13_18
 UP BND1      load_1_13_18  25
 BV BND1      arc_1_13_19
 UP BND1      load_1_13_19  25
 BV BND1      arc_1_14_0
 UP BND1      load_1_14_0  25
 BV BND1      arc_1_14_5
 UP BND1      load_1_14_5  25
 BV BND1      arc_1_14_6
 UP BND1      load_1_14_6  25
 BV BND1      arc_1_14_7
 UP BND1      load_1_14_7  25
 BV BND1      arc_1_14_8
 UP BND1      load_1_14_8  25
 BV BND1      arc_1_14_12
 UP BND1      load_1_14_12  25
 BV BND1      arc_1_14_13
 UP BND1      load_1_14_13  25
 BV BND1      arc_1_14_15
 UP BND1      load_1_14_15  25
 BV BND1      arc_1_14_16
 UP BND1      load_1_14_16  25
 BV BND1      arc_1_14_17
 UP BND1      load_1_14_17  25
 BV BND1      arc_1_14_18
 UP BND1      load_1_14_18  25
 BV BND1      arc_1_14_19
 UP BND1      load_1_14_19  25
 BV BND1      arc_1_15_0
 UP BND1      load_1_15_0  25
 BV BND1      arc_1_15_5
 UP BND1      load_1_15_5  25
 BV BND1      arc_1_15_6
 UP BND1      load_1_15_6  25
 BV BND1      arc_1_15_7
 UP BND1      load_1_15_7  25
 BV BND1      arc_1_15_8
 UP BND1      load_1_15_8  25
 BV BND1      arc_1_15_12
 UP BND1      load_1_15_12  25
 BV BND1      arc_1_15_13
 UP BND1      load_1_15_13  25
 BV BND1      arc_1_15_14
 UP BND1      load_1_15_14  25
 BV BND1      arc_1_15_16
 UP BND1      load_1_15_16  25
 BV BND1      arc_1_15_17
 UP BND1      load_1_15_17  25
 BV BND1      arc_1_15_18
 UP BND1      load_1_15_18  25
 BV BND1      arc_1_15_19
 UP BND1      load_1_15_19  25
 BV BND1      arc_1_16_0
 UP BND1      load_1_16_0  25
 BV BND1      arc_1_16_5
 UP BND1      load_1_16_5  25
 BV BND1      arc_1_16_6
 UP BND1      load_1_16_6  25
 BV BND1      arc_1_16_7
 UP BND1      load_1_16_7  25
 BV BND1      arc_1_16_8
 UP BND1      load_1_16_8  25
 BV BND1      arc_1_16_12
 UP BND1      load_1_16_12  25
 BV BND1      arc_1_16_13
 UP BND1      load_1_16_13  25
 BV BND1      arc_1_16_14
 UP BND1      load_1_16_14  25
 BV BND1      arc_1_16_15
 UP BND1      load_1_16_15  25
 BV BND1      arc_1_16_17
 UP BND1      load_1_16_17  25
 BV BND1      arc_1_16_18
 UP BND1      load_1_16_18  25
 BV BND1      arc_1_16_19
 UP BND1      load_1_16_19  25
 BV BND1      arc_1_17_0
 UP BND1      load_1_17_0  25
 BV BND1      arc_1_17_5
 UP BND1      load_1_17_5  25
 BV BND1      arc_1_17_6
 UP BND1      load_1_17_6  25
 BV BND1      arc_1_17_7
 UP BND1      load_1_17_7  25
 BV BND1      arc_1_17_8
 UP BND1      load_1_17_8  25
 BV BND1      arc_1_17_12
 UP BND1      load_1_17_12  25
 BV BND1      arc_1_17_13
 UP BND1      load_1_17_13  25
 BV BND1      arc_1_17_14
 UP BND1      load_1_17_14  25
 BV BND1      arc_1_17_15
 UP BND1      load_1_17_15  25
 BV BND1      arc_1_17_16
 UP BND1      load_1_17_16  25
 BV BND1      arc_1_17_18
 UP BND1      load_1_17_18  25
 BV BND1      arc_1_17_19
 UP BND1      load_1_17_19  25
 BV BND1      arc_1_18_0
 UP BND1      load_1_18_0  25
 BV BND1      arc_1_18_5
 UP BND1      load_1_18_5  25
 BV BND1      arc_1_18_6
 UP BND1      load_1_18_6  25
 BV BND1      arc_1_18_7
 UP BND1      load_1_18_7  25
 BV BND1      arc_1_18_8
 UP BND1      load_1_18_8  25
 BV BND1      arc_1_18_12
 UP BND1      load_1_18_12  25
 BV BND1      arc_1_18_13
 UP BND1      load_1_18_13  25
 BV BND1      arc_1_18_14
 UP BND1      load_1_18_14  25
 BV BND1      arc_1_18_15
 UP BND1      load_1_18_15  25
 BV BND1      arc_1_18_16
 UP BND1      load_1_18_16  25
 BV BND1      arc_1_18_17
 UP BND1      load_1_18_17  25
 BV BND1      arc_1_18_19
 UP BND1      load_1_18_19  25
 BV BND1      arc_1_19_0
 UP BND1      load_1_19_0  25
 BV BND1      arc_1_19_5
 UP BND1      load_1_19_5  25
 BV BND1      arc_1_19_6
 UP BND1      load_1_19_6  25
 BV BND1      arc_1_19_7
 UP BND1      load_1_19_7  25
 BV BND1      arc_1_19_8
 UP BND1      load_1_19_8  25
 BV BND1      arc_1_19_12
 UP BND1      load_1_19_12  25
 BV BND1      arc_1_19_13
 UP BND1      load_1_19_13  25
 BV BND1      arc_1_19_14
 UP BND1      load_1_19_14  25
 BV BND1      arc_1_19_15
 UP BND1      load_1_19_15  25
 BV BND1      arc_1_19_16
 UP BND1      load_1_19_16  25
 BV BND1      arc_1_19_17
 UP BND1      load_1_19_17  25
 BV BND1      arc_1_19_18
 UP BND1      load_1_19_18  25
 FX BND1      visit_2_9  1
 UP BND1      order_2_9  11
 FX BND1      visit_2_10  1
 UP BND1      order_2_10  11
 FX BND1      visit_2_11  1
 UP BND1      order_2_11  11
 UP BND1      visit_2_12  1
 UP BND1      order_2_12  11
 UP BND1      visit_2_13  1
 UP BND1      order_2_13  11
 UP BND1      visit_2_14  1
 UP BND1      order_2_14  11
 UP BND1      visit_2_15  1
 UP BND1      order_2_15  11
 UP BND1      visit_2_16  1
 UP BND1      order_2_16  11
 UP BND1      visit_2_17  1
 UP BND1      order_2_17  11
 UP BND1      visit_2_18  1
 UP BND1      order_2_18  11
 UP BND1      visit_2_19  1
 UP BND1      order_2_19  11
 BV BND1      arc_2_0_0
 FX BND1      load_2_0_0  0
 BV BND1      arc_2_0_9
 FX BND1      load_2_0_9  0
 BV BND1      arc_2_0_10
 FX BND1      load_2_0_10  0
 BV BND1      arc_2_0_11
 FX BND1      load_2_0_11  0
 BV BND1      arc_2_0_12
 FX BND1      load_2_0_12  0
 BV BND1      arc_2_0_13
 FX BND1      load_2_0_13  0
 BV BND1      arc_2_0_14
 FX BND1      load_2_0_14  0
 BV BND1      arc_2_0_15
 FX BND1      load_2_0_15  0
 BV BND1      arc_2_0_16
 FX BND1      load_2_0_16  0
 BV BND1      arc_2_0_17
 FX BND1      load_2_0_17  0
 BV BND1      arc_2_0_18
 FX BND1      load_2_0_18  0
 BV BND1      arc_2_0_19
 FX BND1      load_2_0_19  0
 BV BND1      arc_2_9_0
 UP BND1      load_2_9_0  30
 BV BND1      arc_2_9_10
 UP BND1      load_2_9_10  30
 BV BND1      arc_2_9_11
 UP BND1      load_2_9_11  30
 BV BND1      arc_2_9_12
 UP BND1      load_2_9_12  30
 BV BND1      arc_2_9_13
 UP BND1      load_2_9_13  30
 BV BND1      arc_2_9_14
 UP BND1      load_2_9_14  30
 BV BND1      arc_2_9_15
 UP BND1      load_2_9_15  30
 BV BND1      arc_2_9_16
 UP BND1      load_2_9_16  30
 BV BND1      arc_2_9_17
 UP BND1      load_2_9_17  30
 BV BND1      arc_2_9_18
 UP BND1      load_2_9_18  30
 BV BND1      arc_2_9_19
 UP BND1      load_2_9_19  30
 BV BND1      arc_2_10_0
 UP BND1      load_2_10_0  30
 BV BND1      arc_2_10_9
 UP BND1      load_2_10_9  30
 BV BND1      arc_2_10_11
 UP BND1      load_2_10_11  30
 BV BND1      arc_2_10_12
 UP BND1      load_2_10_12  30
 BV BND1      arc_2_10_13
 UP BND1      load_2_10_13  30
 BV BND1      arc_2_10_14
 UP BND1      load_2_10_14  30
 BV BND1      arc_2_10_15
 UP BND1      load_2_10_15  30
 BV BND1      arc_2_10_16
 UP BND1      load_2_10_16  30
 BV BND1      arc_2_10_17
 UP BND1      load_2_10_17  30
 BV BND1      arc_2_10_18
 UP BND1      load_2_10_18  30
 BV BND1      arc_2_10_19
 UP BND1      load_2_10_19  30
 BV BND1      arc_2_11_0
 UP BND1      load_2_11_0  30
 BV BND1      arc_2_11_9
 UP BND1      load_2_11_9  30
 BV BND1      arc_2_11_10
 UP BND1      load_2_11_10  30
 BV BND1      arc_2_11_12
 UP BND1      load_2_11_12  30
 BV BND1      arc_2_11_13
 UP BND1      load_2_11_13  30
 BV BND1      arc_2_11_14
 UP BND1      load_2_11_14  30
 BV BND1      arc_2_11_15
 UP BND1      load_2_11_15  30
 BV BND1      arc_2_11_16
 UP BND1      load_2_11_16  30
 BV BND1      arc_2_11_17
 UP BND1      load_2_11_17  30
 BV BND1      arc_2_11_18
 UP BND1      load_2_11_18  30
 BV BND1      arc_2_11_19
 UP BND1      load_2_11_19  30
 BV BND1      arc_2_12_0
 UP BND1      load_2_12_0  30
 BV BND1      arc_2_12_9
 UP BND1      load_2_12_9  30
 BV BND1      arc_2_12_10
 UP BND1      load_2_12_10  30
 BV BND1      arc_2_12_11
 UP BND1      load_2_12_11  30
 BV BND1      arc_2_12_13
 UP BND1      load_2_12_13  30
 BV BND1      arc_2_12_14
 UP BND1      load_2_12_14  30
 BV BND1      arc_2_12_15
 UP BND1      load_2_12_15  30
 BV BND1      arc_2_12_16
 UP BND1      load_2_12_16  30
 BV BND1      arc_2_12_17
 UP BND1      load_2_12_17  30
 BV BND1      arc_2_12_18
 UP BND1      load_2_12_18  30
 BV BND1      arc_2_12_19
 UP BND1      load_2_12_19  30
 BV BND1      arc_2_13_0
 UP BND1      load_2_13_0  30
 BV BND1      arc_2_13_9
 UP BND1      load_2_13_9  30
 BV BND1      arc_2_13_10
 UP BND1      load_2_13_10  30
 BV BND1      arc_2_13_11
 UP BND1      load_2_13_11  30
 BV BND1      arc_2_13_12
 UP BND1      load_2_13_12  30
 BV BND1      arc_2_13_14
 UP BND1      load_2_13_14  30
 BV BND1      arc_2_13_15
 UP BND1      load_2_13_15  30
 BV BND1      arc_2_13_16
 UP BND1      load_2_13_16  30
 BV BND1      arc_2_13_17
 UP BND1      load_2_13_17  30
 BV BND1      arc_2_13_18
 UP BND1      load_2_13_18  30
 BV BND1      arc_2_13_19
 UP BND1      load_2_13_19  30
 BV BND1      arc_2_14_0
 UP BND1      load_2_14_0  30
 BV BND1      arc_2_14_9
 UP BND1      load_2_14_9  30
 BV BND1      arc_2_14_10
 UP BND1      load_2_14_10  30
 BV BND1      arc_2_14_11
 UP BND1      load_2_14_11  30
 BV BND1      arc_2_14_12
 UP BND1      load_2_14_12  30
 BV BND1      arc_2_14_13
 UP BND1      load_2_14_13  30
 BV BND1      arc_2_14_15
 UP BND1      load_2_14_15  30
 BV BND1      arc_2_14_16
 UP BND1      load_2_14_16  30
 BV BND1      arc_2_14_17
 UP BND1      load_2_14_17  30
 BV BND1      arc_2_14_18
 UP BND1      load_2_14_18  30
 BV BND1      arc_2_14_19
 UP BND1      load_2_14_19  30
 BV BND1      arc_2_15_0
 UP BND1      load_2_15_0  30
 BV BND1      arc_2_15_9
 UP BND1      load_2_15_9  30
 BV BND1      arc_2_15_10
 UP BND1      load_2_15_10  30
 BV BND1      arc_2_15_11
 UP BND1      load_2_15_11  30
 BV BND1      arc_2_15_12
 UP BND1      load_2_15_12  30
 BV BND1      arc_2_15_13
 UP BND1      load_2_15_13  30
 BV BND1      arc_2_15_14
 UP BND1      load_2_15_14  30
 BV BND1      arc_2_15_16
 UP BND1      load_2_15_16  30
 BV BND1      arc_2_15_17
 UP BND1      load_2_15_17  30
 BV BND1      arc_2_15_18
 UP BND1      load_2_15_18  30
 BV BND1      arc_2_15_19
 UP BND1      load_2_15_19  30
 BV BND1      arc_2_16_0
 UP BND1      load_2_16_0  30
 BV BND1      arc_2_16_9
 UP BND1      load_2_16_9  30
 BV BND1      arc_2_16_10
 UP BND1      load_2_16_10  30
 BV BND1      arc_2_16_11
 UP BND1      load_2_16_11  30
 BV BND1      arc_2_16_12
 UP BND1      load_2_16_12  30
 BV BND1      arc_2_16_13
 UP BND1      load_2_16_13  30
 BV BND1      arc_2_16_14
 UP BND1      load_2_16_14  30
 BV BND1      arc_2_16_15
 UP BND1      load_2_16_15  30
 BV BND1      arc_2_16_17
 UP BND1      load_2_16_17  30
 BV BND1      arc_2_16_18
 UP BND1      load_2_16_18  30
 BV BND1      arc_2_16_19
 UP BND1      load_2_16_19  30
 BV BND1      arc_2_17_0
 UP BND1      load_2_17_0  30
 BV BND1      arc_2_17_9
 UP BND1      load_2_17_9  30
 BV BND1      arc_2_17_10
 UP BND1      load_2_17_10  30
 BV BND1      arc_2_17_11
 UP BND1      load_2_17_11  30
 BV BND1      arc_2_17_12
 UP BND1      load_2_17_12  30
 BV BND1      arc_2_17_13
 UP BND1      load_2_17_13  30
 BV BND1      arc_2_17_14
 UP BND1      load_2_17_14  30
 BV BND1      arc_2_17_15
 UP BND1      load_2_17_15  30
 BV BND1      arc_2_17_16
 UP BND1      load_2_17_16  30
 BV BND1      arc_2_17_18
 UP BND1      load_2_17_18  30
 BV BND1      arc_2_17_19
 UP BND1      load_2_17_19  30
 BV BND1      arc_2_18_0
 UP BND1      load_2_18_0  30
 BV BND1      arc_2_18_9
 UP BND1      load_2_18_9  30
 BV BND1      arc_2_18_10
 UP BND1      load_2_18_10  30
 BV BND1      arc_2_18_11
 UP BND1      load_2_18_11  30
 BV BND1      arc_2_18_12
 UP BND1      load_2_18_12  30
 BV BND1      arc_2_18_13
 UP BND1      load_2_18_13  30
 BV BND1      arc_2_18_14
 UP BND1      load_2_18_14  30
 BV BND1      arc_2_18_15
 UP BND1      load_2_18_15  30
 BV BND1      arc_2_18_16
 UP BND1      load_2_18_16  30
 BV BND1      arc_2_18_17
 UP BND1      load_2_18_17  30
 BV BND1      arc_2_18_19
 UP BND1      load_2_18_19  30
 BV BND1      arc_2_19_0
 UP BND1      load_2_19_0  30
 BV BND1      arc_2_19_9
 UP BND1      load_2_19_9  30
 BV BND1      arc_2_19_10
 UP BND1      load_2_19_10  30
 BV BND1      arc_2_19_11
 UP BND1      load_2_19_11  30
 BV BND1      arc_2_19_12
 UP BND1      load_2_19_12  30
 BV BND1      arc_2_19_13
 UP BND1      load_2_19_13  30
 BV BND1      arc_2_19_14
 UP BND1      load_2_19_14  30
 BV BND1      arc_2_19_15
 UP BND1      load_2_19_15  30
 BV BND1      arc_2_19_16
 UP BND1      load_2_19_16  30
 BV BND1      arc_2_19_17
 UP BND1      load_2_19_17  30
 BV BND1      arc_2_19_18
 UP BND1      load_2_19_18  30
ENDATA
