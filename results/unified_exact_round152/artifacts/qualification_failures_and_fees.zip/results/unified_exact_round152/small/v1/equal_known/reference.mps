* Signature: 0x4872d4b05ee8fd11
NAME 
ROWS
 N  OBJ
 G  R0      
 L  R1      
 G  R2      
 L  R3      
 G  R4      
 L  R5      
 E  R6      
 E  R7      
 E  R8      
 G  R9      
 G  R10     
 E  R11     
 E  R12     
 G  R13     
 L  R14     
 G  R15     
 L  R16     
 G  R17     
 L  R18     
 E  R19     
 E  R20     
 E  R21     
 G  R22     
 G  R23     
 E  R24     
 E  R25     
 G  R26     
 L  R27     
 G  R28     
 L  R29     
 G  R30     
 L  R31     
 E  R32     
 E  R33     
 E  R34     
 G  R35     
 G  R36     
 E  R37     
 E  R38     
 G  R39     
 L  R40     
 G  R41     
 L  R42     
 G  R43     
 L  R44     
 E  R45     
 E  R46     
 E  R47     
 G  R48     
 G  R49     
 E  R50     
 E  R51     
 G  R52     
 G  R53     
 G  R54     
 G  R55     
 G  R56     
 G  R57     
 G  R58     
 G  R59     
 G  R60     
 G  R61     
 G  R62     
 G  R63     
 L  R64     
 G  R65     
 L  R66     
 G  r152_known_AP
 G  r152_known_stock_loL
 G  r152_known_stock_loU
 L  r152_known_stock_hiL
 L  r152_known_stock_hiU
 G  r152_known_TC
 G  r152_known_TC2
 G  r152_known_count_0_low
 L  r152_known_count_0_high
 G  r152_known_count_1_low
 L  r152_known_count_1_high
 G  r152_known_CP_0_loL
 G  r152_known_CP_0_loU
 L  r152_known_CP_0_hiL
 L  r152_known_CP_0_hiU
 G  r152_known_CP_1_loL
 G  r152_known_CP_1_loU
 L  r152_known_CP_1_hiL
 L  r152_known_CP_1_hiU
COLUMNS
    state_1_0  R1        -0.75
    state_1_0  R6        1
    state_1_0  r152_known_AP  -0.15
    state_1_1  R3        -0.75
    state_1_1  R6        1
    state_1_1  R7        -1
    state_1_1  r152_known_TC  -1
    state_1_1  r152_known_TC2  -1
    state_1_1  r152_known_count_0_low  1
    state_1_1  r152_known_count_0_high  1
    state_1_1  r152_known_CP_0_loU  -0.75
    state_1_1  r152_known_CP_0_hiL  -0.75
    state_1_2  R5        -0.75
    state_1_2  R6        1
    state_1_2  R7        -2
    state_1_2  r152_known_AP  -0.15
    state_1_2  r152_known_TC  -4
    state_1_2  r152_known_TC2  -4
    state_1_2  r152_known_count_0_low  1
    state_1_2  r152_known_count_0_high  1
    state_1_2  r152_known_count_1_low  1
    state_1_2  r152_known_count_1_high  1
    state_1_2  r152_known_CP_0_loU  -0.75
    state_1_2  r152_known_CP_0_hiL  -0.75
    state_1_2  r152_known_CP_1_loU  -0.75
    state_1_2  r152_known_CP_1_hiL  -0.75
    state_2_0  R14       -0.75
    state_2_0  R19       1
    state_2_0  r152_known_AP  -0.15
    state_2_1  R16       -0.75
    state_2_1  R19       1
    state_2_1  R20       -1
    state_2_1  r152_known_TC  -1
    state_2_1  r152_known_TC2  -1
    state_2_1  r152_known_count_0_low  1
    state_2_1  r152_known_count_0_high  1
    state_2_1  r152_known_CP_0_loU  -0.75
    state_2_1  r152_known_CP_0_hiL  -0.75
    state_2_2  R18       -0.75
    state_2_2  R19       1
    state_2_2  R20       -2
    state_2_2  r152_known_AP  -0.15
    state_2_2  r152_known_TC  -4
    state_2_2  r152_known_TC2  -4
    state_2_2  r152_known_count_0_low  1
    state_2_2  r152_known_count_0_high  1
    state_2_2  r152_known_count_1_low  1
    state_2_2  r152_known_count_1_high  1
    state_2_2  r152_known_CP_0_loU  -0.75
    state_2_2  r152_known_CP_0_hiL  -0.75
    state_2_2  r152_known_CP_1_loU  -0.75
    state_2_2  r152_known_CP_1_hiL  -0.75
    state_3_0  R27       -0.75
    state_3_0  R32       1
    state_3_0  r152_known_AP  -0.15
    state_3_1  R29       -0.75
    state_3_1  R32       1
    state_3_1  R33       -1
    state_3_1  r152_known_TC  -1
    state_3_1  r152_known_TC2  -1
    state_3_1  r152_known_count_0_low  1
    state_3_1  r152_known_count_0_high  1
    state_3_1  r152_known_CP_0_loU  -0.75
    state_3_1  r152_known_CP_0_hiL  -0.75
    state_3_2  R31       -0.75
    state_3_2  R32       1
    state_3_2  R33       -2
    state_3_2  r152_known_AP  -0.15
    state_3_2  r152_known_TC  -4
    state_3_2  r152_known_TC2  -4
    state_3_2  r152_known_count_0_low  1
    state_3_2  r152_known_count_0_high  1
    state_3_2  r152_known_count_1_low  1
    state_3_2  r152_known_count_1_high  1
    state_3_2  r152_known_CP_0_loU  -0.75
    state_3_2  r152_known_CP_0_hiL  -0.75
    state_3_2  r152_known_CP_1_loU  -0.75
    state_3_2  r152_known_CP_1_hiL  -0.75
    state_4_0  R40       -0.75
    state_4_0  R45       1
    state_4_0  r152_known_AP  -0.15
    state_4_1  R42       -0.75
    state_4_1  R45       1
    state_4_1  R46       -1
    state_4_1  r152_known_TC  -1
    state_4_1  r152_known_TC2  -1
    state_4_1  r152_known_count_0_low  1
    state_4_1  r152_known_count_0_high  1
    state_4_1  r152_known_CP_0_loU  -0.75
    state_4_1  r152_known_CP_0_hiL  -0.75
    state_4_2  R44       -0.75
    state_4_2  R45       1
    state_4_2  R46       -2
    state_4_2  r152_known_AP  -0.15
    state_4_2  r152_known_TC  -4
    state_4_2  r152_known_TC2  -4
    state_4_2  r152_known_count_0_low  1
    state_4_2  r152_known_count_0_high  1
    state_4_2  r152_known_count_1_low  1
    state_4_2  r152_known_count_1_high  1
    state_4_2  r152_known_CP_0_loU  -0.75
    state_4_2  r152_known_CP_0_hiL  -0.75
    state_4_2  r152_known_CP_1_loU  -0.75
    state_4_2  r152_known_CP_1_hiL  -0.75
    G         OBJ       1
    G         R11       -1
    G         R24       -1
    G         R37       -1
    G         R50       -1
    G         r152_known_stock_loU  -3
    G         r152_known_stock_hiU  -3
    G         r152_known_CP_0_loU  -3
    G         r152_known_CP_0_hiU  -3
    G         r152_known_CP_1_loU  -1
    G         r152_known_CP_1_hiU  -1
    Y_1       R7        1
    Y_1       R8        -1
    Y_1       R65       1
    Y_1       R66       1
    Y_1       r152_known_stock_loU  -0.75
    Y_1       r152_known_stock_hiL  -0.75
    r_1       R8        1
    r_1       R9        -1
    r_1       R10       1
    r_1       R52       -1
    r_1       R53       1
    r_1       R54       -1
    r_1       R55       1
    r_1       R56       -1
    r_1       R57       1
    e_1       OBJ       0.15
    e_1       R9        1
    e_1       R10       1
    e_1       r152_known_AP  0.15
    zprod_1   R12       1
    zprod_1   R64       -4
    zprod_1   r152_known_stock_loL  1
    zprod_1   r152_known_stock_loU  1
    zprod_1   r152_known_stock_hiL  1
    zprod_1   r152_known_stock_hiU  1
    state_g_1_0  R0        1
    state_g_1_0  R1        1
    state_g_1_0  R11       1
    state_g_1_1  R2        1
    state_g_1_1  R3        1
    state_g_1_1  R11       1
    state_g_1_1  R12       -1
    state_g_1_1  r152_known_CP_0_loL  1
    state_g_1_1  r152_known_CP_0_loU  1
    state_g_1_1  r152_known_CP_0_hiL  1
    state_g_1_1  r152_known_CP_0_hiU  1
    state_g_1_2  R4        1
    state_g_1_2  R5        1
    state_g_1_2  R11       1
    state_g_1_2  R12       -2
    state_g_1_2  r152_known_CP_0_loL  1
    state_g_1_2  r152_known_CP_0_loU  1
    state_g_1_2  r152_known_CP_0_hiL  1
    state_g_1_2  r152_known_CP_0_hiU  1
    state_g_1_2  r152_known_CP_1_loL  1
    state_g_1_2  r152_known_CP_1_loU  1
    state_g_1_2  r152_known_CP_1_hiL  1
    state_g_1_2  r152_known_CP_1_hiU  1
    Y_2       R20       1
    Y_2       R21       -1
    Y_2       R65       1
    Y_2       R66       1
    Y_2       r152_known_stock_loU  -0.75
    Y_2       r152_known_stock_hiL  -0.75
    r_2       R21       1
    r_2       R22       -1
    r_2       R23       1
    r_2       R52       1
    r_2       R53       -1
    r_2       R58       -1
    r_2       R59       1
    r_2       R60       -1
    r_2       R61       1
    e_2       OBJ       0.15
    e_2       R22       1
    e_2       R23       1
    e_2       r152_known_AP  0.15
    zprod_2   R25       1
    zprod_2   R64       -4
    zprod_2   r152_known_stock_loL  1
    zprod_2   r152_known_stock_loU  1
    zprod_2   r152_known_stock_hiL  1
    zprod_2   r152_known_stock_hiU  1
    state_g_2_0  R13       1
    state_g_2_0  R14       1
    state_g_2_0  R24       1
    state_g_2_1  R15       1
    state_g_2_1  R16       1
    state_g_2_1  R24       1
    state_g_2_1  R25       -1
    state_g_2_1  r152_known_CP_0_loL  1
    state_g_2_1  r152_known_CP_0_loU  1
    state_g_2_1  r152_known_CP_0_hiL  1
    state_g_2_1  r152_known_CP_0_hiU  1
    state_g_2_2  R17       1
    state_g_2_2  R18       1
    state_g_2_2  R24       1
    state_g_2_2  R25       -2
    state_g_2_2  r152_known_CP_0_loL  1
    state_g_2_2  r152_known_CP_0_loU  1
    state_g_2_2  r152_known_CP_0_hiL  1
    state_g_2_2  r152_known_CP_0_hiU  1
    state_g_2_2  r152_known_CP_1_loL  1
    state_g_2_2  r152_known_CP_1_loU  1
    state_g_2_2  r152_known_CP_1_hiL  1
    state_g_2_2  r152_known_CP_1_hiU  1
    Y_3       R33       1
    Y_3       R34       -1
    Y_3       R65       1
    Y_3       R66       1
    Y_3       r152_known_stock_loU  -0.75
    Y_3       r152_known_stock_hiL  -0.75
    r_3       R34       1
    r_3       R35       -1
    r_3       R36       1
    r_3       R54       1
    r_3       R55       -1
    r_3       R58       1
    r_3       R59       -1
    r_3       R62       -1
    r_3       R63       1
    e_3       OBJ       0.15
    e_3       R35       1
    e_3       R36       1
    e_3       r152_known_AP  0.15
    zprod_3   R38       1
    zprod_3   R64       -4
    zprod_3   r152_known_stock_loL  1
    zprod_3   r152_known_stock_loU  1
    zprod_3   r152_known_stock_hiL  1
    zprod_3   r152_known_stock_hiU  1
    state_g_3_0  R26       1
    state_g_3_0  R27       1
    state_g_3_0  R37       1
    state_g_3_1  R28       1
    state_g_3_1  R29       1
    state_g_3_1  R37       1
    state_g_3_1  R38       -1
    state_g_3_1  r152_known_CP_0_loL  1
    state_g_3_1  r152_known_CP_0_loU  1
    state_g_3_1  r152_known_CP_0_hiL  1
    state_g_3_1  r152_known_CP_0_hiU  1
    state_g_3_2  R30       1
    state_g_3_2  R31       1
    state_g_3_2  R37       1
    state_g_3_2  R38       -2
    state_g_3_2  r152_known_CP_0_loL  1
    state_g_3_2  r152_known_CP_0_loU  1
    state_g_3_2  r152_known_CP_0_hiL  1
    state_g_3_2  r152_known_CP_0_hiU  1
    state_g_3_2  r152_known_CP_1_loL  1
    state_g_3_2  r152_known_CP_1_loU  1
    state_g_3_2  r152_known_CP_1_hiL  1
    state_g_3_2  r152_known_CP_1_hiU  1
    Y_4       R46       1
    Y_4       R47       -1
    Y_4       R65       1
    Y_4       R66       1
    Y_4       r152_known_stock_loU  -0.75
    Y_4       r152_known_stock_hiL  -0.75
    r_4       R47       1
    r_4       R48       -1
    r_4       R49       1
    r_4       R56       1
    r_4       R57       -1
    r_4       R60       1
    r_4       R61       -1
    r_4       R62       1
    r_4       R63       -1
    e_4       OBJ       0.15
    e_4       R48       1
    e_4       R49       1
    e_4       r152_known_AP  0.15
    zprod_4   R51       1
    zprod_4   R64       -4
    zprod_4   r152_known_stock_loL  1
    zprod_4   r152_known_stock_loU  1
    zprod_4   r152_known_stock_hiL  1
    zprod_4   r152_known_stock_hiU  1
    state_g_4_0  R39       1
    state_g_4_0  R40       1
    state_g_4_0  R50       1
    state_g_4_1  R41       1
    state_g_4_1  R42       1
    state_g_4_1  R50       1
    state_g_4_1  R51       -1
    state_g_4_1  r152_known_CP_0_loL  1
    state_g_4_1  r152_known_CP_0_loU  1
    state_g_4_1  r152_known_CP_0_hiL  1
    state_g_4_1  r152_known_CP_0_hiU  1
    state_g_4_2  R43       1
    state_g_4_2  R44       1
    state_g_4_2  R50       1
    state_g_4_2  R51       -2
    state_g_4_2  r152_known_CP_0_loL  1
    state_g_4_2  r152_known_CP_0_loU  1
    state_g_4_2  r152_known_CP_0_hiL  1
    state_g_4_2  r152_known_CP_0_hiU  1
    state_g_4_2  r152_known_CP_1_loL  1
    state_g_4_2  r152_known_CP_1_loU  1
    state_g_4_2  r152_known_CP_1_hiL  1
    state_g_4_2  r152_known_CP_1_hiU  1
    h_1_2     R52       1
    h_1_2     R53       1
    h_1_2     R64       1
    h_1_2     r152_known_TC  1
    h_1_2     r152_known_TC2  1
    h_1_3     R54       1
    h_1_3     R55       1
    h_1_3     R64       1
    h_1_3     r152_known_TC  1
    h_1_3     r152_known_TC2  1
    h_1_4     R56       1
    h_1_4     R57       1
    h_1_4     R64       1
    h_1_4     r152_known_TC  1
    h_1_4     r152_known_TC2  1
    h_2_3     R58       1
    h_2_3     R59       1
    h_2_3     R64       1
    h_2_3     r152_known_TC  1
    h_2_3     r152_known_TC2  1
    h_2_4     R60       1
    h_2_4     R61       1
    h_2_4     R64       1
    h_2_4     r152_known_TC  1
    h_2_4     r152_known_TC2  1
    h_3_4     R62       1
    h_3_4     R63       1
    h_3_4     R64       1
    h_3_4     r152_known_TC  1
    h_3_4     r152_known_TC2  1
RHS
    RHS1      R6        1
    RHS1      R9        -1
    RHS1      R10       1
    RHS1      R19       1
    RHS1      R22       -1
    RHS1      R23       1
    RHS1      R32       1
    RHS1      R35       -1
    RHS1      R36       1
    RHS1      R45       1
    RHS1      R48       -1
    RHS1      R49       1
    RHS1      R66       3
    RHS1      r152_known_stock_loU  -2.25
    RHS1      r152_known_count_0_high  3
    RHS1      r152_known_count_1_high  1
    RHS1      r152_known_CP_0_loU  -2.25
    RHS1      r152_known_CP_1_loU  -0.75
BOUNDS
 UP BND1      state_1_0  1
 UP BND1      state_1_1  1
 UP BND1      state_1_2  1
 UP BND1      state_2_0  1
 UP BND1      state_2_1  1
 UP BND1      state_2_2  1
 UP BND1      state_3_0  1
 UP BND1      state_3_1  1
 UP BND1      state_3_2  1
 UP BND1      state_4_0  1
 UP BND1      state_4_1  1
 UP BND1      state_4_2  1
 UP BND1      G         0.75
 UP BND1      Y_1       2
 UP BND1      Y_2       2
 UP BND1      Y_3       2
 UP BND1      Y_4       2
ENDATA
