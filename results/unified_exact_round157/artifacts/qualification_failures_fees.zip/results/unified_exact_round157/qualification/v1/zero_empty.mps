* Signature: 0xfeb1026282ce77a1
NAME R157_free_fleet_original_T
ROWS
 N  OBJ
 E  select_one_1
 E  select_one_2
 L  depart_once_0
 E  return_once_0
 L  original_time_0
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    select[1,0]  select_one_1  1
    select[2,0]  select_one_2  1
    MARKER    'MARKER'                 'INTEND'
RHS
    RHS1      select_one_1  1
    RHS1      select_one_2  1
    RHS1      depart_once_0  1
    RHS1      original_time_0  1
BOUNDS
 BV BND1      select[1,0]
 BV BND1      select[2,0]
ENDATA
