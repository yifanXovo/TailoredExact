* Signature: 0x58ecc71fa53890c1
NAME 
ROWS
 N  OBJ
 E  onehot_1
 E  mass_1  
 G  w_lb_1_0
 L  w_ub_1_0
 G  w_lb_1_1
 L  w_ub_1_1
 G  w_lb_1_2
 L  w_ub_1_2
 E  normalized_inventory_1
 E  normalized_ratio_1
 E  onehot_2
 E  mass_2  
 G  w_lb_2_0
 L  w_ub_2_0
 G  w_lb_2_1
 L  w_ub_2_1
 G  w_lb_2_2
 L  w_ub_2_2
 E  normalized_inventory_2
 E  normalized_ratio_2
 G  hard_lower
 L  hard_upper
 E  normalization
 G  scaled_stock_lower
 L  scaled_stock_upper
 G  abs_p_1_2
 G  abs_m_1_2
 L  true_G_epigraph
 L  physical_G_upper
 G  old_normalized_TC
 G  old_normalized_TC2
 G  old_TS1 
 G  old_TS2 
 L  old_TS3 
 L  old_TS4 
 E  resource_assign_1_0
 E  resource_assign_1_1
 E  resource_assign_2_1
 E  resource_assign_2_2
 E  resource_visit_def_0_1
 E  resource_visit_def_0_2
 E  resource_pickup_def_0
 E  resource_drop_def_0
 G  resource_return_lb_0
 L  resource_return_ub_0
 L  resource_handling_0
 L  resource_subset_0_0
 L  resource_subset_0_1
 L  resource_subset_0_2
 G  known_original_inventory_lower
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    x[1,0]    OBJ       0.075
    x[1,0]    onehot_1  1
    x[1,0]    w_lb_1_0  -1
    x[1,0]    w_ub_1_0  -2
    x[1,0]    resource_assign_1_0  -1
    x[1,0]    known_original_inventory_lower  0.15
    x[1,1]    onehot_1  1
    x[1,1]    w_lb_1_1  -1
    x[1,1]    w_ub_1_1  -2
    x[1,1]    hard_lower  1
    x[1,1]    hard_upper  1
    x[1,1]    old_TS1   -1
    x[1,1]    old_TS2   -2
    x[1,1]    old_TS3   -2
    x[1,1]    old_TS4   -1
    x[1,1]    resource_assign_1_1  -1
    x[1,1]    known_original_inventory_lower  0.075
    x[1,2]    OBJ       -0.075
    x[1,2]    onehot_1  1
    x[1,2]    w_lb_1_2  -1
    x[1,2]    w_ub_1_2  -2
    x[1,2]    hard_lower  2
    x[1,2]    hard_upper  2
    x[1,2]    old_TS1   -2
    x[1,2]    old_TS2   -4
    x[1,2]    old_TS3   -4
    x[1,2]    old_TS4   -2
    x[2,0]    OBJ       0.075
    x[2,0]    onehot_2  1
    x[2,0]    w_lb_2_0  -1
    x[2,0]    w_ub_2_0  -2
    x[2,0]    known_original_inventory_lower  0.15
    x[2,1]    onehot_2  1
    x[2,1]    w_lb_2_1  -1
    x[2,1]    w_ub_2_1  -2
    x[2,1]    hard_lower  1
    x[2,1]    hard_upper  1
    x[2,1]    old_TS1   -1
    x[2,1]    old_TS2   -2
    x[2,1]    old_TS3   -2
    x[2,1]    old_TS4   -1
    x[2,1]    resource_assign_2_1  -1
    x[2,1]    known_original_inventory_lower  0.075
    x[2,2]    OBJ       -0.075
    x[2,2]    onehot_2  1
    x[2,2]    w_lb_2_2  -1
    x[2,2]    w_ub_2_2  -2
    x[2,2]    hard_lower  2
    x[2,2]    hard_upper  2
    x[2,2]    old_TS1   -2
    x[2,2]    old_TS2   -4
    x[2,2]    old_TS3   -4
    x[2,2]    old_TS4   -2
    x[2,2]    resource_assign_2_2  -1
    MARKER    'MARKER'                 'INTEND'
    w[1,0]    mass_1    1
    w[1,0]    w_lb_1_0  1
    w[1,0]    w_ub_1_0  1
    w[1,1]    mass_1    1
    w[1,1]    w_lb_1_1  1
    w[1,1]    w_ub_1_1  1
    w[1,1]    normalized_inventory_1  -1
    w[1,1]    old_normalized_TC2  0.5
    w[1,2]    mass_1    1
    w[1,2]    w_lb_1_2  1
    w[1,2]    w_ub_1_2  1
    w[1,2]    normalized_inventory_1  -2
    w[1,2]    old_normalized_TC  -0.5
    w[2,0]    mass_2    1
    w[2,0]    w_lb_2_0  1
    w[2,0]    w_ub_2_0  1
    w[2,1]    mass_2    1
    w[2,1]    w_lb_2_1  1
    w[2,1]    w_ub_2_1  1
    w[2,1]    normalized_inventory_2  -1
    w[2,1]    old_normalized_TC2  0.5
    w[2,2]    mass_2    1
    w[2,2]    w_lb_2_2  1
    w[2,2]    w_ub_2_2  1
    w[2,2]    normalized_inventory_2  -2
    w[2,2]    old_normalized_TC  -0.5
    t         mass_1    -1
    t         mass_2    -1
    t         scaled_stock_lower  -1
    t         scaled_stock_upper  -2
    t         old_normalized_TC2  -1
    t         old_TS1   -1
    t         old_TS2   -2
    t         old_TS3   -1
    t         old_TS4   -2
    z[1]      normalized_inventory_1  1
    z[1]      normalized_ratio_1  -0.5
    z[1]      scaled_stock_lower  1
    z[1]      scaled_stock_upper  1
    z[1]      old_TS1   1
    z[1]      old_TS2   1
    z[1]      old_TS3   1
    z[1]      old_TS4   1
    z[2]      normalized_inventory_2  1
    z[2]      normalized_ratio_2  -0.5
    z[2]      scaled_stock_lower  1
    z[2]      scaled_stock_upper  1
    z[2]      old_TS1   1
    z[2]      old_TS2   1
    z[2]      old_TS3   1
    z[2]      old_TS4   1
    r[1]      normalized_ratio_1  1
    r[1]      normalization  1
    r[1]      abs_p_1_2  -1
    r[1]      abs_m_1_2  1
    r[2]      normalized_ratio_2  1
    r[2]      normalization  1
    r[2]      abs_p_1_2  1
    r[2]      abs_m_1_2  -1
    a[1,2]    abs_p_1_2  1
    a[1,2]    abs_m_1_2  1
    a[1,2]    true_G_epigraph  1
    a[1,2]    physical_G_upper  1
    a[1,2]    old_normalized_TC  1
    a[1,2]    old_normalized_TC2  1
    q         OBJ       1
    q         true_G_epigraph  -2
    q         known_original_inventory_lower  1
    MARKER    'MARKER'                 'INTORG'
    resource_service[0,1,1]  resource_assign_1_1  1
    resource_service[0,1,1]  resource_visit_def_0_1  -1
    resource_service[0,1,1]  resource_pickup_def_0  -1
    resource_service[0,2,1]  resource_assign_2_1  1
    resource_service[0,2,1]  resource_visit_def_0_2  -1
    resource_service[0,2,1]  resource_drop_def_0  -1
    MARKER    'MARKER'                 'INTEND'
    resource_visit[0,1]  resource_visit_def_0_1  1
    resource_visit[0,1]  resource_subset_0_0  2
    resource_visit[0,1]  resource_subset_0_2  200
    resource_visit[0,2]  resource_visit_def_0_2  1
    resource_visit[0,2]  resource_subset_0_1  200
    resource_visit[0,2]  resource_subset_0_2  200
    resource_pickup[0]  resource_pickup_def_0  1
    resource_pickup[0]  resource_return_lb_0  1
    resource_pickup[0]  resource_return_ub_0  1
    resource_pickup[0]  resource_handling_0  1
    resource_pickup[0]  resource_subset_0_0  1
    resource_pickup[0]  resource_subset_0_1  1
    resource_pickup[0]  resource_subset_0_2  1
    resource_drop[0]  resource_drop_def_0  1
    resource_drop[0]  resource_return_lb_0  -1
    resource_drop[0]  resource_return_ub_0  -1
RHS
    RHS1      onehot_1  1
    RHS1      onehot_2  1
    RHS1      hard_lower  1
    RHS1      hard_upper  2
    RHS1      normalization  1
    RHS1      physical_G_upper  2
    RHS1      old_TS1   -1
    RHS1      old_TS2   -4
    RHS1      old_TS3   -2
    RHS1      old_TS4   -2
    RHS1      resource_return_ub_0  1
    RHS1      resource_handling_0  10
    RHS1      resource_subset_0_0  10
    RHS1      resource_subset_0_1  10
    RHS1      resource_subset_0_2  210
    RHS1      known_original_inventory_lower  0.15
BOUNDS
 BV BND1      x[1,0]  
 BV BND1      x[1,1]  
 BV BND1      x[1,2]  
 BV BND1      x[2,0]  
 BV BND1      x[2,1]  
 BV BND1      x[2,2]  
 UP BND1      w[1,0]    2
 UP BND1      w[1,1]    2
 UP BND1      w[1,2]    2
 UP BND1      w[2,0]    2
 UP BND1      w[2,1]    2
 UP BND1      w[2,2]    2
 LO BND1      t         1
 UP BND1      t         2
 UP BND1      q         1
 BV BND1      resource_service[0,1,1]
 BV BND1      resource_service[0,2,1]
 UP BND1      resource_visit[0,1]  1
 UP BND1      resource_visit[0,2]  1
 UP BND1      resource_pickup[0]  2
 UP BND1      resource_drop[0]  4
ENDATA
