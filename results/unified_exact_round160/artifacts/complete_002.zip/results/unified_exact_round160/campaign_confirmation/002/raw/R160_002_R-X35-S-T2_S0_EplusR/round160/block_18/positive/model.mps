* Signature: 0x15f29976a99cc1bd
NAME R160_physical_neighborhood
ROWS
 N  OBJ
 G  product_lb_0
 L  product_ub_1
 G  product_lb_2
 L  product_ub_3
 G  product_lb_4
 L  product_ub_5
 G  product_lb_6
 L  product_ub_7
 G  product_lb_8
 L  product_ub_9
 G  product_lb_10
 L  product_ub_11
 G  product_lb_12
 L  product_ub_13
 G  product_lb_14
 L  product_ub_15
 G  product_lb_16
 L  product_ub_17
 E  onehot_26_18
 E  normalized_mass_26_19
 E  normalized_ratio_26_20
 G  product_lb_21
 L  product_ub_22
 G  product_lb_23
 L  product_ub_24
 G  product_lb_25
 L  product_ub_26
 G  product_lb_27
 L  product_ub_28
 G  product_lb_29
 L  product_ub_30
 G  product_lb_31
 L  product_ub_32
 G  product_lb_33
 L  product_ub_34
 E  onehot_28_35
 E  normalized_mass_28_36
 E  normalized_ratio_28_37
 G  product_lb_38
 L  product_ub_39
 G  product_lb_40
 L  product_ub_41
 G  product_lb_42
 L  product_ub_43
 G  product_lb_44
 L  product_ub_45
 G  product_lb_46
 L  product_ub_47
 G  product_lb_48
 L  product_ub_49
 G  product_lb_50
 L  product_ub_51
 G  product_lb_52
 L  product_ub_53
 G  product_lb_54
 L  product_ub_55
 G  product_lb_56
 L  product_ub_57
 G  product_lb_58
 L  product_ub_59
 G  product_lb_60
 L  product_ub_61
 G  product_lb_62
 L  product_ub_63
 G  product_lb_64
 L  product_ub_65
 G  product_lb_66
 L  product_ub_67
 G  product_lb_68
 L  product_ub_69
 E  onehot_34_70
 E  normalized_mass_34_71
 E  normalized_ratio_34_72
 G  product_lb_73
 L  product_ub_74
 G  product_lb_75
 L  product_ub_76
 G  product_lb_77
 L  product_ub_78
 G  product_lb_79
 L  product_ub_80
 G  product_lb_81
 L  product_ub_82
 G  product_lb_83
 L  product_ub_84
 G  product_lb_85
 L  product_ub_86
 G  product_lb_87
 L  product_ub_88
 G  product_lb_89
 L  product_ub_90
 G  product_lb_91
 L  product_ub_92
 G  product_lb_93
 L  product_ub_94
 E  onehot_29_95
 E  normalized_mass_29_96
 E  normalized_ratio_29_97
 G  product_lb_98
 L  product_ub_99
 G  product_lb_100
 L  product_ub_101
 G  product_lb_102
 L  product_ub_103
 G  product_lb_104
 L  product_ub_105
 G  product_lb_106
 L  product_ub_107
 G  product_lb_108
 L  product_ub_109
 G  product_lb_110
 L  product_ub_111
 E  onehot_27_112
 E  normalized_mass_27_113
 E  normalized_ratio_27_114
 G  product_lb_115
 L  product_ub_116
 G  product_lb_117
 L  product_ub_118
 G  product_lb_119
 L  product_ub_120
 G  product_lb_121
 L  product_ub_122
 G  product_lb_123
 L  product_ub_124
 G  product_lb_125
 L  product_ub_126
 G  product_lb_127
 L  product_ub_128
 G  product_lb_129
 L  product_ub_130
 G  product_lb_131
 L  product_ub_132
 G  product_lb_133
 L  product_ub_134
 G  product_lb_135
 L  product_ub_136
 G  product_lb_137
 L  product_ub_138
 G  product_lb_139
 L  product_ub_140
 G  product_lb_141
 L  product_ub_142
 G  product_lb_143
 L  product_ub_144
 G  product_lb_145
 L  product_ub_146
 E  onehot_22_147
 E  normalized_mass_22_148
 E  normalized_ratio_22_149
 G  product_lb_150
 L  product_ub_151
 G  product_lb_152
 L  product_ub_153
 G  product_lb_154
 L  product_ub_155
 G  product_lb_156
 L  product_ub_157
 G  product_lb_158
 L  product_ub_159
 E  onehot_25_160
 E  normalized_mass_25_161
 E  normalized_ratio_25_162
 G  product_lb_163
 L  product_ub_164
 G  product_lb_165
 L  product_ub_166
 G  product_lb_167
 L  product_ub_168
 G  product_lb_169
 L  product_ub_170
 E  onehot_23_171
 E  normalized_mass_23_172
 E  normalized_ratio_23_173
 G  stock_lb_174
 L  stock_ub_175
 L  parent_nonstrict_scope_176
 G  block_pair_pos_177
 G  block_pair_neg_178
 G  block_pair_pos_179
 G  block_pair_neg_180
 G  block_pair_pos_181
 G  block_pair_neg_182
 G  block_pair_pos_183
 G  block_pair_neg_184
 G  block_pair_pos_185
 G  block_pair_neg_186
 G  block_pair_pos_187
 G  block_pair_neg_188
 G  block_pair_pos_189
 G  block_pair_neg_190
 G  block_pair_pos_191
 G  block_pair_neg_192
 G  block_pair_pos_193
 G  block_pair_neg_194
 G  block_pair_pos_195
 G  block_pair_neg_196
 G  block_pair_pos_197
 G  block_pair_neg_198
 G  block_pair_pos_199
 G  block_pair_neg_200
 G  block_pair_pos_201
 G  block_pair_neg_202
 G  block_pair_pos_203
 G  block_pair_neg_204
 G  block_pair_pos_205
 G  block_pair_neg_206
 G  block_pair_pos_207
 G  block_pair_neg_208
 G  block_pair_pos_209
 G  block_pair_neg_210
 G  block_pair_pos_211
 G  block_pair_neg_212
 G  block_pair_pos_213
 G  block_pair_neg_214
 G  block_pair_pos_215
 G  block_pair_neg_216
 G  block_pair_pos_217
 G  block_pair_neg_218
 G  block_pair_pos_219
 G  block_pair_neg_220
 G  block_pair_pos_221
 G  block_pair_neg_222
 G  block_pair_pos_223
 G  block_pair_neg_224
 G  block_pair_pos_225
 G  block_pair_neg_226
 G  block_pair_pos_227
 G  block_pair_neg_228
 G  block_pair_pos_229
 G  block_pair_neg_230
 G  block_pair_pos_231
 G  block_pair_neg_232
 E  normalization_233
 G  full_original_Gini_234
 E  unique_nonzero_owner_235
 E  unique_nonzero_owner_236
 E  unique_nonzero_owner_237
 E  unique_nonzero_owner_238
 E  unique_nonzero_owner_239
 E  unique_nonzero_owner_240
 E  unique_nonzero_owner_241
 E  unique_nonzero_owner_242
 E  unique_nonzero_owner_243
 E  unique_nonzero_owner_244
 E  unique_nonzero_owner_245
 E  unique_nonzero_owner_246
 E  unique_nonzero_owner_247
 E  unique_nonzero_owner_248
 E  unique_nonzero_owner_249
 E  unique_nonzero_owner_250
 E  unique_nonzero_owner_251
 E  unique_nonzero_owner_252
 E  unique_nonzero_owner_253
 E  unique_nonzero_owner_254
 E  unique_nonzero_owner_255
 E  unique_nonzero_owner_256
 E  unique_nonzero_owner_257
 E  unique_nonzero_owner_258
 E  unique_nonzero_owner_259
 E  unique_nonzero_owner_260
 E  unique_nonzero_owner_261
 E  unique_nonzero_owner_262
 E  unique_nonzero_owner_263
 E  unique_nonzero_owner_264
 E  unique_nonzero_owner_265
 E  unique_nonzero_owner_266
 E  unique_nonzero_owner_267
 E  unique_nonzero_owner_268
 E  unique_nonzero_owner_269
 E  unique_nonzero_owner_270
 E  unique_nonzero_owner_271
 E  unique_nonzero_owner_272
 E  unique_nonzero_owner_273
 E  unique_nonzero_owner_274
 E  unique_nonzero_owner_275
 E  unique_nonzero_owner_276
 E  unique_nonzero_owner_277
 E  unique_nonzero_owner_278
 E  unique_nonzero_owner_279
 E  unique_nonzero_owner_280
 E  unique_nonzero_owner_281
 E  unique_nonzero_owner_282
 E  unique_nonzero_owner_283
 E  unique_nonzero_owner_284
 E  unique_nonzero_owner_285
 E  unique_nonzero_owner_286
 E  unique_nonzero_owner_287
 E  unique_nonzero_owner_288
 E  unique_nonzero_owner_289
 E  unique_nonzero_owner_290
 E  unique_nonzero_owner_291
 E  unique_nonzero_owner_292
 E  unique_nonzero_owner_293
 E  unique_nonzero_owner_294
 E  unique_nonzero_owner_295
 E  unique_nonzero_owner_296
 E  unique_nonzero_owner_297
 E  unique_nonzero_owner_298
 E  unique_nonzero_owner_299
 E  unique_nonzero_owner_300
 E  unique_nonzero_owner_301
 L  arc_capacity_302
 L  arc_capacity_303
 L  arc_capacity_304
 L  arc_capacity_305
 L  arc_capacity_306
 L  arc_capacity_307
 L  arc_capacity_308
 L  arc_capacity_309
 L  arc_capacity_310
 L  arc_capacity_311
 L  arc_capacity_312
 L  arc_capacity_313
 L  arc_capacity_314
 L  arc_capacity_315
 L  arc_capacity_316
 G  connected_order_arc_317
 L  arc_capacity_318
 G  connected_order_arc_319
 L  arc_capacity_320
 G  connected_order_arc_321
 L  arc_capacity_322
 G  connected_order_arc_323
 L  arc_capacity_324
 G  connected_order_arc_325
 L  arc_capacity_326
 G  connected_order_arc_327
 L  arc_capacity_328
 G  connected_order_arc_329
 L  arc_capacity_330
 G  connected_order_arc_331
 L  arc_capacity_332
 G  connected_order_arc_333
 L  arc_capacity_334
 G  connected_order_arc_335
 L  arc_capacity_336
 G  connected_order_arc_337
 L  arc_capacity_338
 L  arc_capacity_339
 G  connected_order_arc_340
 L  arc_capacity_341
 G  connected_order_arc_342
 L  arc_capacity_343
 G  connected_order_arc_344
 L  arc_capacity_345
 G  connected_order_arc_346
 L  arc_capacity_347
 G  connected_order_arc_348
 L  arc_capacity_349
 G  connected_order_arc_350
 L  arc_capacity_351
 G  connected_order_arc_352
 L  arc_capacity_353
 G  connected_order_arc_354
 L  arc_capacity_355
 G  connected_order_arc_356
 L  arc_capacity_357
 G  connected_order_arc_358
 L  arc_capacity_359
 G  connected_order_arc_360
 L  arc_capacity_361
 L  arc_capacity_362
 G  connected_order_arc_363
 L  arc_capacity_364
 G  connected_order_arc_365
 L  arc_capacity_366
 G  connected_order_arc_367
 L  arc_capacity_368
 G  connected_order_arc_369
 L  arc_capacity_370
 G  connected_order_arc_371
 L  arc_capacity_372
 G  connected_order_arc_373
 L  arc_capacity_374
 G  connected_order_arc_375
 L  arc_capacity_376
 G  connected_order_arc_377
 L  arc_capacity_378
 G  connected_order_arc_379
 L  arc_capacity_380
 G  connected_order_arc_381
 L  arc_capacity_382
 G  connected_order_arc_383
 L  arc_capacity_384
 L  arc_capacity_385
 G  connected_order_arc_386
 L  arc_capacity_387
 G  connected_order_arc_388
 L  arc_capacity_389
 G  connected_order_arc_390
 L  arc_capacity_391
 G  connected_order_arc_392
 L  arc_capacity_393
 G  connected_order_arc_394
 L  arc_capacity_395
 G  connected_order_arc_396
 L  arc_capacity_397
 G  connected_order_arc_398
 L  arc_capacity_399
 G  connected_order_arc_400
 L  arc_capacity_401
 G  connected_order_arc_402
 L  arc_capacity_403
 G  connected_order_arc_404
 L  arc_capacity_405
 G  connected_order_arc_406
 L  arc_capacity_407
 L  arc_capacity_408
 G  connected_order_arc_409
 L  arc_capacity_410
 G  connected_order_arc_411
 L  arc_capacity_412
 G  connected_order_arc_413
 L  arc_capacity_414
 G  connected_order_arc_415
 L  arc_capacity_416
 G  connected_order_arc_417
 L  arc_capacity_418
 G  connected_order_arc_419
 L  arc_capacity_420
 G  connected_order_arc_421
 L  arc_capacity_422
 G  connected_order_arc_423
 L  arc_capacity_424
 G  connected_order_arc_425
 L  arc_capacity_426
 G  connected_order_arc_427
 L  arc_capacity_428
 G  connected_order_arc_429
 L  arc_capacity_430
 L  arc_capacity_431
 G  connected_order_arc_432
 L  arc_capacity_433
 G  connected_order_arc_434
 L  arc_capacity_435
 G  connected_order_arc_436
 L  arc_capacity_437
 G  connected_order_arc_438
 L  arc_capacity_439
 G  connected_order_arc_440
 L  arc_capacity_441
 G  connected_order_arc_442
 L  arc_capacity_443
 G  connected_order_arc_444
 L  arc_capacity_445
 G  connected_order_arc_446
 L  arc_capacity_447
 G  connected_order_arc_448
 L  arc_capacity_449
 G  connected_order_arc_450
 L  arc_capacity_451
 G  connected_order_arc_452
 L  arc_capacity_453
 L  arc_capacity_454
 G  connected_order_arc_455
 L  arc_capacity_456
 G  connected_order_arc_457
 L  arc_capacity_458
 G  connected_order_arc_459
 L  arc_capacity_460
 G  connected_order_arc_461
 L  arc_capacity_462
 G  connected_order_arc_463
 L  arc_capacity_464
 G  connected_order_arc_465
 L  arc_capacity_466
 G  connected_order_arc_467
 L  arc_capacity_468
 G  connected_order_arc_469
 L  arc_capacity_470
 G  connected_order_arc_471
 L  arc_capacity_472
 G  connected_order_arc_473
 L  arc_capacity_474
 G  connected_order_arc_475
 L  arc_capacity_476
 L  arc_capacity_477
 G  connected_order_arc_478
 L  arc_capacity_479
 G  connected_order_arc_480
 L  arc_capacity_481
 G  connected_order_arc_482
 L  arc_capacity_483
 G  connected_order_arc_484
 L  arc_capacity_485
 G  connected_order_arc_486
 L  arc_capacity_487
 G  connected_order_arc_488
 L  arc_capacity_489
 G  connected_order_arc_490
 L  arc_capacity_491
 G  connected_order_arc_492
 L  arc_capacity_493
 G  connected_order_arc_494
 L  arc_capacity_495
 G  connected_order_arc_496
 L  arc_capacity_497
 G  connected_order_arc_498
 L  arc_capacity_499
 L  arc_capacity_500
 G  connected_order_arc_501
 L  arc_capacity_502
 G  connected_order_arc_503
 L  arc_capacity_504
 G  connected_order_arc_505
 L  arc_capacity_506
 G  connected_order_arc_507
 L  arc_capacity_508
 G  connected_order_arc_509
 L  arc_capacity_510
 G  connected_order_arc_511
 L  arc_capacity_512
 G  connected_order_arc_513
 L  arc_capacity_514
 G  connected_order_arc_515
 L  arc_capacity_516
 G  connected_order_arc_517
 L  arc_capacity_518
 G  connected_order_arc_519
 L  arc_capacity_520
 G  connected_order_arc_521
 L  arc_capacity_522
 L  arc_capacity_523
 G  connected_order_arc_524
 L  arc_capacity_525
 G  connected_order_arc_526
 L  arc_capacity_527
 G  connected_order_arc_528
 L  arc_capacity_529
 G  connected_order_arc_530
 L  arc_capacity_531
 G  connected_order_arc_532
 L  arc_capacity_533
 G  connected_order_arc_534
 L  arc_capacity_535
 G  connected_order_arc_536
 L  arc_capacity_537
 G  connected_order_arc_538
 L  arc_capacity_539
 G  connected_order_arc_540
 L  arc_capacity_541
 G  connected_order_arc_542
 L  arc_capacity_543
 G  connected_order_arc_544
 L  arc_capacity_545
 L  arc_capacity_546
 G  connected_order_arc_547
 L  arc_capacity_548
 G  connected_order_arc_549
 L  arc_capacity_550
 G  connected_order_arc_551
 L  arc_capacity_552
 G  connected_order_arc_553
 L  arc_capacity_554
 G  connected_order_arc_555
 L  arc_capacity_556
 G  connected_order_arc_557
 L  arc_capacity_558
 G  connected_order_arc_559
 L  arc_capacity_560
 G  connected_order_arc_561
 L  arc_capacity_562
 G  connected_order_arc_563
 L  arc_capacity_564
 G  connected_order_arc_565
 L  arc_capacity_566
 G  connected_order_arc_567
 L  arc_capacity_568
 L  arc_capacity_569
 G  connected_order_arc_570
 L  arc_capacity_571
 G  connected_order_arc_572
 L  arc_capacity_573
 G  connected_order_arc_574
 L  arc_capacity_575
 G  connected_order_arc_576
 L  arc_capacity_577
 G  connected_order_arc_578
 L  arc_capacity_579
 G  connected_order_arc_580
 L  arc_capacity_581
 G  connected_order_arc_582
 L  arc_capacity_583
 G  connected_order_arc_584
 L  arc_capacity_585
 G  connected_order_arc_586
 L  arc_capacity_587
 G  connected_order_arc_588
 L  arc_capacity_589
 G  connected_order_arc_590
 E  depot_departure_or_bypass_591
 E  depot_return_or_bypass_592
 E  out_degree_593
 E  in_degree_594
 G  order_active_lb_595
 L  order_active_ub_596
 E  segment_load_conservation_597
 G  segment_prefix_lb_598
 L  segment_prefix_ub_599
 E  out_degree_600
 E  in_degree_601
 G  order_active_lb_602
 L  order_active_ub_603
 E  segment_load_conservation_604
 G  segment_prefix_lb_605
 L  segment_prefix_ub_606
 E  out_degree_607
 E  in_degree_608
 G  order_active_lb_609
 L  order_active_ub_610
 E  segment_load_conservation_611
 G  segment_prefix_lb_612
 L  segment_prefix_ub_613
 E  out_degree_614
 E  in_degree_615
 G  order_active_lb_616
 L  order_active_ub_617
 E  segment_load_conservation_618
 G  segment_prefix_lb_619
 L  segment_prefix_ub_620
 E  out_degree_621
 E  in_degree_622
 G  order_active_lb_623
 L  order_active_ub_624
 E  service_visit_def_625
 E  free_load_conservation_626
 E  out_degree_627
 E  in_degree_628
 G  order_active_lb_629
 L  order_active_ub_630
 E  service_visit_def_631
 E  free_load_conservation_632
 E  out_degree_633
 E  in_degree_634
 G  order_active_lb_635
 L  order_active_ub_636
 E  service_visit_def_637
 E  free_load_conservation_638
 E  out_degree_639
 E  in_degree_640
 G  order_active_lb_641
 L  order_active_ub_642
 E  service_visit_def_643
 E  free_load_conservation_644
 E  out_degree_645
 E  in_degree_646
 G  order_active_lb_647
 L  order_active_ub_648
 E  service_visit_def_649
 E  free_load_conservation_650
 E  out_degree_651
 E  in_degree_652
 G  order_active_lb_653
 L  order_active_ub_654
 E  service_visit_def_655
 E  free_load_conservation_656
 E  out_degree_657
 E  in_degree_658
 G  order_active_lb_659
 L  order_active_ub_660
 E  service_visit_def_661
 E  free_load_conservation_662
 E  out_degree_663
 E  in_degree_664
 G  order_active_lb_665
 L  order_active_ub_666
 E  service_visit_def_667
 E  free_load_conservation_668
 G  fixed_segment_relative_order_669
 G  fixed_segment_relative_order_670
 G  fixed_segment_relative_order_671
 L  original_T_including_depot_unload_672
 L  arc_capacity_673
 L  arc_capacity_674
 L  arc_capacity_675
 L  arc_capacity_676
 L  arc_capacity_677
 L  arc_capacity_678
 L  arc_capacity_679
 L  arc_capacity_680
 L  arc_capacity_681
 L  arc_capacity_682
 L  arc_capacity_683
 L  arc_capacity_684
 L  arc_capacity_685
 L  arc_capacity_686
 L  arc_capacity_687
 G  connected_order_arc_688
 L  arc_capacity_689
 G  connected_order_arc_690
 L  arc_capacity_691
 G  connected_order_arc_692
 L  arc_capacity_693
 G  connected_order_arc_694
 L  arc_capacity_695
 G  connected_order_arc_696
 L  arc_capacity_697
 G  connected_order_arc_698
 L  arc_capacity_699
 G  connected_order_arc_700
 L  arc_capacity_701
 G  connected_order_arc_702
 L  arc_capacity_703
 G  connected_order_arc_704
 L  arc_capacity_705
 G  connected_order_arc_706
 L  arc_capacity_707
 G  connected_order_arc_708
 L  arc_capacity_709
 L  arc_capacity_710
 G  connected_order_arc_711
 L  arc_capacity_712
 G  connected_order_arc_713
 L  arc_capacity_714
 G  connected_order_arc_715
 L  arc_capacity_716
 G  connected_order_arc_717
 L  arc_capacity_718
 G  connected_order_arc_719
 L  arc_capacity_720
 G  connected_order_arc_721
 L  arc_capacity_722
 G  connected_order_arc_723
 L  arc_capacity_724
 G  connected_order_arc_725
 L  arc_capacity_726
 G  connected_order_arc_727
 L  arc_capacity_728
 G  connected_order_arc_729
 L  arc_capacity_730
 G  connected_order_arc_731
 L  arc_capacity_732
 L  arc_capacity_733
 G  connected_order_arc_734
 L  arc_capacity_735
 G  connected_order_arc_736
 L  arc_capacity_737
 G  connected_order_arc_738
 L  arc_capacity_739
 G  connected_order_arc_740
 L  arc_capacity_741
 G  connected_order_arc_742
 L  arc_capacity_743
 G  connected_order_arc_744
 L  arc_capacity_745
 G  connected_order_arc_746
 L  arc_capacity_747
 G  connected_order_arc_748
 L  arc_capacity_749
 G  connected_order_arc_750
 L  arc_capacity_751
 G  connected_order_arc_752
 L  arc_capacity_753
 G  connected_order_arc_754
 L  arc_capacity_755
 L  arc_capacity_756
 G  connected_order_arc_757
 L  arc_capacity_758
 G  connected_order_arc_759
 L  arc_capacity_760
 G  connected_order_arc_761
 L  arc_capacity_762
 G  connected_order_arc_763
 L  arc_capacity_764
 G  connected_order_arc_765
 L  arc_capacity_766
 G  connected_order_arc_767
 L  arc_capacity_768
 G  connected_order_arc_769
 L  arc_capacity_770
 G  connected_order_arc_771
 L  arc_capacity_772
 G  connected_order_arc_773
 L  arc_capacity_774
 G  connected_order_arc_775
 L  arc_capacity_776
 G  connected_order_arc_777
 L  arc_capacity_778
 L  arc_capacity_779
 G  connected_order_arc_780
 L  arc_capacity_781
 G  connected_order_arc_782
 L  arc_capacity_783
 G  connected_order_arc_784
 L  arc_capacity_785
 G  connected_order_arc_786
 L  arc_capacity_787
 G  connected_order_arc_788
 L  arc_capacity_789
 G  connected_order_arc_790
 L  arc_capacity_791
 G  connected_order_arc_792
 L  arc_capacity_793
 G  connected_order_arc_794
 L  arc_capacity_795
 G  connected_order_arc_796
 L  arc_capacity_797
 G  connected_order_arc_798
 L  arc_capacity_799
 G  connected_order_arc_800
 L  arc_capacity_801
 L  arc_capacity_802
 G  connected_order_arc_803
 L  arc_capacity_804
 G  connected_order_arc_805
 L  arc_capacity_806
 G  connected_order_arc_807
 L  arc_capacity_808
 G  connected_order_arc_809
 L  arc_capacity_810
 G  connected_order_arc_811
 L  arc_capacity_812
 G  connected_order_arc_813
 L  arc_capacity_814
 G  connected_order_arc_815
 L  arc_capacity_816
 G  connected_order_arc_817
 L  arc_capacity_818
 G  connected_order_arc_819
 L  arc_capacity_820
 G  connected_order_arc_821
 L  arc_capacity_822
 G  connected_order_arc_823
 L  arc_capacity_824
 L  arc_capacity_825
 G  connected_order_arc_826
 L  arc_capacity_827
 G  connected_order_arc_828
 L  arc_capacity_829
 G  connected_order_arc_830
 L  arc_capacity_831
 G  connected_order_arc_832
 L  arc_capacity_833
 G  connected_order_arc_834
 L  arc_capacity_835
 G  connected_order_arc_836
 L  arc_capacity_837
 G  connected_order_arc_838
 L  arc_capacity_839
 G  connected_order_arc_840
 L  arc_capacity_841
 G  connected_order_arc_842
 L  arc_capacity_843
 G  connected_order_arc_844
 L  arc_capacity_845
 G  connected_order_arc_846
 L  arc_capacity_847
 L  arc_capacity_848
 G  connected_order_arc_849
 L  arc_capacity_850
 G  connected_order_arc_851
 L  arc_capacity_852
 G  connected_order_arc_853
 L  arc_capacity_854
 G  connected_order_arc_855
 L  arc_capacity_856
 G  connected_order_arc_857
 L  arc_capacity_858
 G  connected_order_arc_859
 L  arc_capacity_860
 G  connected_order_arc_861
 L  arc_capacity_862
 G  connected_order_arc_863
 L  arc_capacity_864
 G  connected_order_arc_865
 L  arc_capacity_866
 G  connected_order_arc_867
 L  arc_capacity_868
 G  connected_order_arc_869
 L  arc_capacity_870
 L  arc_capacity_871
 G  connected_order_arc_872
 L  arc_capacity_873
 G  connected_order_arc_874
 L  arc_capacity_875
 G  connected_order_arc_876
 L  arc_capacity_877
 G  connected_order_arc_878
 L  arc_capacity_879
 G  connected_order_arc_880
 L  arc_capacity_881
 G  connected_order_arc_882
 L  arc_capacity_883
 G  connected_order_arc_884
 L  arc_capacity_885
 G  connected_order_arc_886
 L  arc_capacity_887
 G  connected_order_arc_888
 L  arc_capacity_889
 G  connected_order_arc_890
 L  arc_capacity_891
 G  connected_order_arc_892
 L  arc_capacity_893
 L  arc_capacity_894
 G  connected_order_arc_895
 L  arc_capacity_896
 G  connected_order_arc_897
 L  arc_capacity_898
 G  connected_order_arc_899
 L  arc_capacity_900
 G  connected_order_arc_901
 L  arc_capacity_902
 G  connected_order_arc_903
 L  arc_capacity_904
 G  connected_order_arc_905
 L  arc_capacity_906
 G  connected_order_arc_907
 L  arc_capacity_908
 G  connected_order_arc_909
 L  arc_capacity_910
 G  connected_order_arc_911
 L  arc_capacity_912
 G  connected_order_arc_913
 L  arc_capacity_914
 G  connected_order_arc_915
 L  arc_capacity_916
 L  arc_capacity_917
 G  connected_order_arc_918
 L  arc_capacity_919
 G  connected_order_arc_920
 L  arc_capacity_921
 G  connected_order_arc_922
 L  arc_capacity_923
 G  connected_order_arc_924
 L  arc_capacity_925
 G  connected_order_arc_926
 L  arc_capacity_927
 G  connected_order_arc_928
 L  arc_capacity_929
 G  connected_order_arc_930
 L  arc_capacity_931
 G  connected_order_arc_932
 L  arc_capacity_933
 G  connected_order_arc_934
 L  arc_capacity_935
 G  connected_order_arc_936
 L  arc_capacity_937
 G  connected_order_arc_938
 L  arc_capacity_939
 L  arc_capacity_940
 G  connected_order_arc_941
 L  arc_capacity_942
 G  connected_order_arc_943
 L  arc_capacity_944
 G  connected_order_arc_945
 L  arc_capacity_946
 G  connected_order_arc_947
 L  arc_capacity_948
 G  connected_order_arc_949
 L  arc_capacity_950
 G  connected_order_arc_951
 L  arc_capacity_952
 G  connected_order_arc_953
 L  arc_capacity_954
 G  connected_order_arc_955
 L  arc_capacity_956
 G  connected_order_arc_957
 L  arc_capacity_958
 G  connected_order_arc_959
 L  arc_capacity_960
 G  connected_order_arc_961
 E  depot_departure_or_bypass_962
 E  depot_return_or_bypass_963
 E  out_degree_964
 E  in_degree_965
 G  order_active_lb_966
 L  order_active_ub_967
 E  segment_load_conservation_968
 G  segment_prefix_lb_969
 L  segment_prefix_ub_970
 E  out_degree_971
 E  in_degree_972
 G  order_active_lb_973
 L  order_active_ub_974
 E  segment_load_conservation_975
 G  segment_prefix_lb_976
 L  segment_prefix_ub_977
 E  out_degree_978
 E  in_degree_979
 G  order_active_lb_980
 L  order_active_ub_981
 E  segment_load_conservation_982
 G  segment_prefix_lb_983
 L  segment_prefix_ub_984
 E  out_degree_985
 E  in_degree_986
 G  order_active_lb_987
 L  order_active_ub_988
 E  segment_load_conservation_989
 G  segment_prefix_lb_990
 L  segment_prefix_ub_991
 E  out_degree_992
 E  in_degree_993
 G  order_active_lb_994
 L  order_active_ub_995
 E  service_visit_def_996
 E  free_load_conservation_997
 E  out_degree_998
 E  in_degree_999
 G  order_active_lb_1000
 L  order_active_ub_1001
 E  service_visit_def_1002
 E  free_load_conservation_1003
 E  out_degree_1004
 E  in_degree_1005
 G  order_active_lb_1006
 L  order_active_ub_1007
 E  service_visit_def_1008
 E  free_load_conservation_1009
 E  out_degree_1010
 E  in_degree_1011
 G  order_active_lb_1012
 L  order_active_ub_1013
 E  service_visit_def_1014
 E  free_load_conservation_1015
 E  out_degree_1016
 E  in_degree_1017
 G  order_active_lb_1018
 L  order_active_ub_1019
 E  service_visit_def_1020
 E  free_load_conservation_1021
 E  out_degree_1022
 E  in_degree_1023
 G  order_active_lb_1024
 L  order_active_ub_1025
 E  service_visit_def_1026
 E  free_load_conservation_1027
 E  out_degree_1028
 E  in_degree_1029
 G  order_active_lb_1030
 L  order_active_ub_1031
 E  service_visit_def_1032
 E  free_load_conservation_1033
 E  out_degree_1034
 E  in_degree_1035
 G  order_active_lb_1036
 L  order_active_ub_1037
 E  service_visit_def_1038
 E  free_load_conservation_1039
 G  fixed_segment_relative_order_1040
 G  fixed_segment_relative_order_1041
 G  fixed_segment_relative_order_1042
 L  original_T_including_depot_unload_1043
 L  arc_capacity_1044
 L  arc_capacity_1045
 L  arc_capacity_1046
 L  arc_capacity_1047
 L  arc_capacity_1048
 L  arc_capacity_1049
 L  arc_capacity_1050
 L  arc_capacity_1051
 L  arc_capacity_1052
 L  arc_capacity_1053
 L  arc_capacity_1054
 L  arc_capacity_1055
 L  arc_capacity_1056
 L  arc_capacity_1057
 G  connected_order_arc_1058
 L  arc_capacity_1059
 G  connected_order_arc_1060
 L  arc_capacity_1061
 G  connected_order_arc_1062
 L  arc_capacity_1063
 G  connected_order_arc_1064
 L  arc_capacity_1065
 G  connected_order_arc_1066
 L  arc_capacity_1067
 G  connected_order_arc_1068
 L  arc_capacity_1069
 G  connected_order_arc_1070
 L  arc_capacity_1071
 G  connected_order_arc_1072
 L  arc_capacity_1073
 G  connected_order_arc_1074
 L  arc_capacity_1075
 G  connected_order_arc_1076
 L  arc_capacity_1077
 L  arc_capacity_1078
 G  connected_order_arc_1079
 L  arc_capacity_1080
 G  connected_order_arc_1081
 L  arc_capacity_1082
 G  connected_order_arc_1083
 L  arc_capacity_1084
 G  connected_order_arc_1085
 L  arc_capacity_1086
 G  connected_order_arc_1087
 L  arc_capacity_1088
 G  connected_order_arc_1089
 L  arc_capacity_1090
 G  connected_order_arc_1091
 L  arc_capacity_1092
 G  connected_order_arc_1093
 L  arc_capacity_1094
 G  connected_order_arc_1095
 L  arc_capacity_1096
 G  connected_order_arc_1097
 L  arc_capacity_1098
 L  arc_capacity_1099
 G  connected_order_arc_1100
 L  arc_capacity_1101
 G  connected_order_arc_1102
 L  arc_capacity_1103
 G  connected_order_arc_1104
 L  arc_capacity_1105
 G  connected_order_arc_1106
 L  arc_capacity_1107
 G  connected_order_arc_1108
 L  arc_capacity_1109
 G  connected_order_arc_1110
 L  arc_capacity_1111
 G  connected_order_arc_1112
 L  arc_capacity_1113
 G  connected_order_arc_1114
 L  arc_capacity_1115
 G  connected_order_arc_1116
 L  arc_capacity_1117
 G  connected_order_arc_1118
 L  arc_capacity_1119
 L  arc_capacity_1120
 G  connected_order_arc_1121
 L  arc_capacity_1122
 G  connected_order_arc_1123
 L  arc_capacity_1124
 G  connected_order_arc_1125
 L  arc_capacity_1126
 G  connected_order_arc_1127
 L  arc_capacity_1128
 G  connected_order_arc_1129
 L  arc_capacity_1130
 G  connected_order_arc_1131
 L  arc_capacity_1132
 G  connected_order_arc_1133
 L  arc_capacity_1134
 G  connected_order_arc_1135
 L  arc_capacity_1136
 G  connected_order_arc_1137
 L  arc_capacity_1138
 G  connected_order_arc_1139
 L  arc_capacity_1140
 L  arc_capacity_1141
 G  connected_order_arc_1142
 L  arc_capacity_1143
 G  connected_order_arc_1144
 L  arc_capacity_1145
 G  connected_order_arc_1146
 L  arc_capacity_1147
 G  connected_order_arc_1148
 L  arc_capacity_1149
 G  connected_order_arc_1150
 L  arc_capacity_1151
 G  connected_order_arc_1152
 L  arc_capacity_1153
 G  connected_order_arc_1154
 L  arc_capacity_1155
 G  connected_order_arc_1156
 L  arc_capacity_1157
 G  connected_order_arc_1158
 L  arc_capacity_1159
 G  connected_order_arc_1160
 L  arc_capacity_1161
 L  arc_capacity_1162
 G  connected_order_arc_1163
 L  arc_capacity_1164
 G  connected_order_arc_1165
 L  arc_capacity_1166
 G  connected_order_arc_1167
 L  arc_capacity_1168
 G  connected_order_arc_1169
 L  arc_capacity_1170
 G  connected_order_arc_1171
 L  arc_capacity_1172
 G  connected_order_arc_1173
 L  arc_capacity_1174
 G  connected_order_arc_1175
 L  arc_capacity_1176
 G  connected_order_arc_1177
 L  arc_capacity_1178
 G  connected_order_arc_1179
 L  arc_capacity_1180
 G  connected_order_arc_1181
 L  arc_capacity_1182
 L  arc_capacity_1183
 G  connected_order_arc_1184
 L  arc_capacity_1185
 G  connected_order_arc_1186
 L  arc_capacity_1187
 G  connected_order_arc_1188
 L  arc_capacity_1189
 G  connected_order_arc_1190
 L  arc_capacity_1191
 G  connected_order_arc_1192
 L  arc_capacity_1193
 G  connected_order_arc_1194
 L  arc_capacity_1195
 G  connected_order_arc_1196
 L  arc_capacity_1197
 G  connected_order_arc_1198
 L  arc_capacity_1199
 G  connected_order_arc_1200
 L  arc_capacity_1201
 G  connected_order_arc_1202
 L  arc_capacity_1203
 L  arc_capacity_1204
 G  connected_order_arc_1205
 L  arc_capacity_1206
 G  connected_order_arc_1207
 L  arc_capacity_1208
 G  connected_order_arc_1209
 L  arc_capacity_1210
 G  connected_order_arc_1211
 L  arc_capacity_1212
 G  connected_order_arc_1213
 L  arc_capacity_1214
 G  connected_order_arc_1215
 L  arc_capacity_1216
 G  connected_order_arc_1217
 L  arc_capacity_1218
 G  connected_order_arc_1219
 L  arc_capacity_1220
 G  connected_order_arc_1221
 L  arc_capacity_1222
 G  connected_order_arc_1223
 L  arc_capacity_1224
 L  arc_capacity_1225
 G  connected_order_arc_1226
 L  arc_capacity_1227
 G  connected_order_arc_1228
 L  arc_capacity_1229
 G  connected_order_arc_1230
 L  arc_capacity_1231
 G  connected_order_arc_1232
 L  arc_capacity_1233
 G  connected_order_arc_1234
 L  arc_capacity_1235
 G  connected_order_arc_1236
 L  arc_capacity_1237
 G  connected_order_arc_1238
 L  arc_capacity_1239
 G  connected_order_arc_1240
 L  arc_capacity_1241
 G  connected_order_arc_1242
 L  arc_capacity_1243
 G  connected_order_arc_1244
 L  arc_capacity_1245
 L  arc_capacity_1246
 G  connected_order_arc_1247
 L  arc_capacity_1248
 G  connected_order_arc_1249
 L  arc_capacity_1250
 G  connected_order_arc_1251
 L  arc_capacity_1252
 G  connected_order_arc_1253
 L  arc_capacity_1254
 G  connected_order_arc_1255
 L  arc_capacity_1256
 G  connected_order_arc_1257
 L  arc_capacity_1258
 G  connected_order_arc_1259
 L  arc_capacity_1260
 G  connected_order_arc_1261
 L  arc_capacity_1262
 G  connected_order_arc_1263
 L  arc_capacity_1264
 G  connected_order_arc_1265
 L  arc_capacity_1266
 L  arc_capacity_1267
 G  connected_order_arc_1268
 L  arc_capacity_1269
 G  connected_order_arc_1270
 L  arc_capacity_1271
 G  connected_order_arc_1272
 L  arc_capacity_1273
 G  connected_order_arc_1274
 L  arc_capacity_1275
 G  connected_order_arc_1276
 L  arc_capacity_1277
 G  connected_order_arc_1278
 L  arc_capacity_1279
 G  connected_order_arc_1280
 L  arc_capacity_1281
 G  connected_order_arc_1282
 L  arc_capacity_1283
 G  connected_order_arc_1284
 L  arc_capacity_1285
 G  connected_order_arc_1286
 E  depot_departure_or_bypass_1287
 E  depot_return_or_bypass_1288
 E  out_degree_1289
 E  in_degree_1290
 G  order_active_lb_1291
 L  order_active_ub_1292
 E  segment_load_conservation_1293
 G  segment_prefix_lb_1294
 L  segment_prefix_ub_1295
 E  out_degree_1296
 E  in_degree_1297
 G  order_active_lb_1298
 L  order_active_ub_1299
 E  segment_load_conservation_1300
 G  segment_prefix_lb_1301
 L  segment_prefix_ub_1302
 E  out_degree_1303
 E  in_degree_1304
 G  order_active_lb_1305
 L  order_active_ub_1306
 E  segment_load_conservation_1307
 G  segment_prefix_lb_1308
 L  segment_prefix_ub_1309
 E  out_degree_1310
 E  in_degree_1311
 G  order_active_lb_1312
 L  order_active_ub_1313
 E  service_visit_def_1314
 E  free_load_conservation_1315
 E  out_degree_1316
 E  in_degree_1317
 G  order_active_lb_1318
 L  order_active_ub_1319
 E  service_visit_def_1320
 E  free_load_conservation_1321
 E  out_degree_1322
 E  in_degree_1323
 G  order_active_lb_1324
 L  order_active_ub_1325
 E  service_visit_def_1326
 E  free_load_conservation_1327
 E  out_degree_1328
 E  in_degree_1329
 G  order_active_lb_1330
 L  order_active_ub_1331
 E  service_visit_def_1332
 E  free_load_conservation_1333
 E  out_degree_1334
 E  in_degree_1335
 G  order_active_lb_1336
 L  order_active_ub_1337
 E  service_visit_def_1338
 E  free_load_conservation_1339
 E  out_degree_1340
 E  in_degree_1341
 G  order_active_lb_1342
 L  order_active_ub_1343
 E  service_visit_def_1344
 E  free_load_conservation_1345
 E  out_degree_1346
 E  in_degree_1347
 G  order_active_lb_1348
 L  order_active_ub_1349
 E  service_visit_def_1350
 E  free_load_conservation_1351
 E  out_degree_1352
 E  in_degree_1353
 G  order_active_lb_1354
 L  order_active_ub_1355
 E  service_visit_def_1356
 E  free_load_conservation_1357
 G  fixed_segment_relative_order_1358
 G  fixed_segment_relative_order_1359
 L  original_T_including_depot_unload_1360
COLUMNS
    t         normalized_mass_26_19  -1
    t         normalized_mass_28_36  -1
    t         normalized_mass_34_71  -1
    t         normalized_mass_29_96  -1
    t         normalized_mass_27_113  -1
    t         normalized_mass_22_148  -1
    t         normalized_mass_25_161  -1
    t         normalized_mass_23_172  -1
    t         normalization_233  2.4486904761904764e+01
    t         full_original_Gini_234  -5.6330952380952446e+01
    q         OBJ       1
    q         parent_nonstrict_scope_176  1
    q         full_original_Gini_234  35
    MARKER    'MARKER'                 'INTORG'
    x_26_0    OBJ       7.4474103065332977e-03
    x_26_0    product_lb_0  -2.4093620927006652e-02
    x_26_0    product_ub_1  -4.0838154504392050e-02
    x_26_0    onehot_26_18  1
    x_26_0    parent_nonstrict_scope_176  1.4894820613066595e-02
    x_26_0    unique_nonzero_owner_235  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_0    product_lb_0  1
    w_26_0    product_ub_1  1
    w_26_0    normalized_mass_26_19  1
    w_26_0    full_original_Gini_234  -2.4486904761904764e+01
    MARKER    'MARKER'                 'INTORG'
    x_26_1    OBJ       3.7237051532666493e-03
    x_26_1    product_lb_2  -2.4093620927006652e-02
    x_26_1    product_ub_3  -4.0838154504392050e-02
    x_26_1    onehot_26_18  1
    x_26_1    stock_lb_174  1
    x_26_1    stock_ub_175  1
    x_26_1    parent_nonstrict_scope_176  1.1171115459799947e-02
    x_26_1    unique_nonzero_owner_236  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_1    product_lb_2  1
    w_26_1    product_ub_3  1
    w_26_1    normalized_mass_26_19  1
    w_26_1    normalized_ratio_26_20  -0.25
    w_26_1    full_original_Gini_234  -1.7736904761904764e+01
    MARKER    'MARKER'                 'INTORG'
    x_26_2    product_lb_4  -2.4093620927006652e-02
    x_26_2    product_ub_5  -4.0838154504392050e-02
    x_26_2    onehot_26_18  1
    x_26_2    stock_lb_174  2
    x_26_2    stock_ub_175  2
    x_26_2    parent_nonstrict_scope_176  7.4474103065332977e-03
    x_26_2    unique_nonzero_owner_237  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_2    product_lb_4  1
    w_26_2    product_ub_5  1
    w_26_2    normalized_mass_26_19  1
    w_26_2    normalized_ratio_26_20  -0.5
    w_26_2    full_original_Gini_234  -1.0986904761904762e+01
    MARKER    'MARKER'                 'INTORG'
    x_26_3    OBJ       -3.7237051532666488e-03
    x_26_3    product_lb_6  -2.4093620927006652e-02
    x_26_3    product_ub_7  -4.0838154504392050e-02
    x_26_3    onehot_26_18  1
    x_26_3    stock_lb_174  3
    x_26_3    stock_ub_175  3
    x_26_3    parent_nonstrict_scope_176  3.7237051532666488e-03
    x_26_3    unique_nonzero_owner_238  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_3    product_lb_6  1
    w_26_3    product_ub_7  1
    w_26_3    normalized_mass_26_19  1
    w_26_3    normalized_ratio_26_20  -0.75
    w_26_3    full_original_Gini_234  -4.4035714285714276e+00
    MARKER    'MARKER'                 'INTORG'
    x_26_4    OBJ       -7.4474103065332977e-03
    x_26_4    product_lb_8  -2.4093620927006652e-02
    x_26_4    product_ub_9  -4.0838154504392050e-02
    x_26_4    onehot_26_18  1
    x_26_4    stock_lb_174  4
    x_26_4    stock_ub_175  4
    x_26_4    unique_nonzero_owner_239  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_4    product_lb_8  1
    w_26_4    product_ub_9  1
    w_26_4    normalized_mass_26_19  1
    w_26_4    normalized_ratio_26_20  -1
    w_26_4    full_original_Gini_234  -3.5130952380952385e+00
    MARKER    'MARKER'                 'INTORG'
    x_26_5    OBJ       -3.7237051532666488e-03
    x_26_5    product_lb_10  -2.4093620927006652e-02
    x_26_5    product_ub_11  -4.0838154504392050e-02
    x_26_5    onehot_26_18  1
    x_26_5    stock_lb_174  5
    x_26_5    stock_ub_175  5
    x_26_5    parent_nonstrict_scope_176  3.7237051532666488e-03
    MARKER    'MARKER'                 'INTEND'
    w_26_5    product_lb_10  1
    w_26_5    product_ub_11  1
    w_26_5    normalized_mass_26_19  1
    w_26_5    normalized_ratio_26_20  -1.25
    w_26_5    full_original_Gini_234  -9.7630952380952376e+00
    MARKER    'MARKER'                 'INTORG'
    x_26_6    product_lb_12  -2.4093620927006652e-02
    x_26_6    product_ub_13  -4.0838154504392050e-02
    x_26_6    onehot_26_18  1
    x_26_6    stock_lb_174  6
    x_26_6    stock_ub_175  6
    x_26_6    parent_nonstrict_scope_176  7.4474103065332977e-03
    x_26_6    unique_nonzero_owner_240  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_6    product_lb_12  1
    w_26_6    product_ub_13  1
    w_26_6    normalized_mass_26_19  1
    w_26_6    normalized_ratio_26_20  -1.5
    w_26_6    full_original_Gini_234  -1.6013095238095239e+01
    MARKER    'MARKER'                 'INTORG'
    x_26_7    OBJ       3.7237051532666493e-03
    x_26_7    product_lb_14  -2.4093620927006652e-02
    x_26_7    product_ub_15  -4.0838154504392050e-02
    x_26_7    onehot_26_18  1
    x_26_7    stock_lb_174  7
    x_26_7    stock_ub_175  7
    x_26_7    parent_nonstrict_scope_176  1.1171115459799947e-02
    x_26_7    unique_nonzero_owner_241  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_7    product_lb_14  1
    w_26_7    product_ub_15  1
    w_26_7    normalized_mass_26_19  1
    w_26_7    normalized_ratio_26_20  -1.75
    w_26_7    full_original_Gini_234  -2.2763095238095236e+01
    MARKER    'MARKER'                 'INTORG'
    x_26_8    OBJ       7.4474103065332977e-03
    x_26_8    product_lb_16  -2.4093620927006652e-02
    x_26_8    product_ub_17  -4.0838154504392050e-02
    x_26_8    onehot_26_18  1
    x_26_8    stock_lb_174  8
    x_26_8    stock_ub_175  8
    x_26_8    parent_nonstrict_scope_176  1.4894820613066595e-02
    x_26_8    unique_nonzero_owner_242  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_8    product_lb_16  1
    w_26_8    product_ub_17  1
    w_26_8    normalized_mass_26_19  1
    w_26_8    normalized_ratio_26_20  -2
    w_26_8    full_original_Gini_234  -2.9513095238095232e+01
    rho_26    normalized_ratio_26_20  1
    rho_26    block_pair_pos_183  -1
    rho_26    block_pair_neg_184  1
    rho_26    block_pair_pos_185  -1
    rho_26    block_pair_neg_186  1
    rho_26    block_pair_pos_187  -1
    rho_26    block_pair_neg_188  1
    rho_26    block_pair_pos_189  -1
    rho_26    block_pair_neg_190  1
    rho_26    block_pair_pos_191  -1
    rho_26    block_pair_neg_192  1
    rho_26    block_pair_pos_193  -1
    rho_26    block_pair_neg_194  1
    rho_26    block_pair_pos_195  -1
    rho_26    block_pair_neg_196  1
    rho_26    normalization_233  1
    MARKER    'MARKER'                 'INTORG'
    x_28_0    OBJ       4.1891612282083379e-03
    x_28_0    product_lb_21  -2.4093620927006652e-02
    x_28_0    product_ub_22  -4.0838154504392050e-02
    x_28_0    onehot_28_35  1
    x_28_0    parent_nonstrict_scope_176  8.3783224564166758e-03
    x_28_0    unique_nonzero_owner_243  -1
    MARKER    'MARKER'                 'INTEND'
    w_28_0    product_lb_21  1
    w_28_0    product_ub_22  1
    w_28_0    normalized_mass_28_36  1
    w_28_0    full_original_Gini_234  -2.4486904761904764e+01
    MARKER    'MARKER'                 'INTORG'
    x_28_1    OBJ       1.3963870760694466e-03
    x_28_1    product_lb_23  -2.4093620927006652e-02
    x_28_1    product_ub_24  -4.0838154504392050e-02
    x_28_1    onehot_28_35  1
    x_28_1    stock_lb_174  1
    x_28_1    stock_ub_175  1
    x_28_1    parent_nonstrict_scope_176  5.5855483042777845e-03
    MARKER    'MARKER'                 'INTEND'
    w_28_1    product_lb_23  1
    w_28_1    product_ub_24  1
    w_28_1    normalized_mass_28_36  1
    w_28_1    normalized_ratio_28_37  -3.3333333333333331e-01
    w_28_1    full_original_Gini_234  -1.5486904761904757e+01
    MARKER    'MARKER'                 'INTORG'
    x_28_2    OBJ       -1.3963870760694457e-03
    x_28_2    product_lb_25  -2.4093620927006652e-02
    x_28_2    product_ub_26  -4.0838154504392050e-02
    x_28_2    onehot_28_35  1
    x_28_2    stock_lb_174  2
    x_28_2    stock_ub_175  2
    x_28_2    parent_nonstrict_scope_176  2.7927741521388922e-03
    x_28_2    unique_nonzero_owner_244  -1
    MARKER    'MARKER'                 'INTEND'
    w_28_2    product_lb_25  1
    w_28_2    product_ub_26  1
    w_28_2    normalized_mass_28_36  1
    w_28_2    normalized_ratio_28_37  -6.6666666666666663e-01
    w_28_2    full_original_Gini_234  -6.4869047619047606e+00
    MARKER    'MARKER'                 'INTORG'
    x_28_3    OBJ       -4.1891612282083379e-03
    x_28_3    product_lb_27  -2.4093620927006652e-02
    x_28_3    product_ub_28  -4.0838154504392050e-02
    x_28_3    onehot_28_35  1
    x_28_3    stock_lb_174  3
    x_28_3    stock_ub_175  3
    x_28_3    unique_nonzero_owner_245  -1
    MARKER    'MARKER'                 'INTEND'
    w_28_3    product_lb_27  1
    w_28_3    product_ub_28  1
    w_28_3    normalized_mass_28_36  1
    w_28_3    normalized_ratio_28_37  -1
    w_28_3    full_original_Gini_234  -3.5130952380952385e+00
    MARKER    'MARKER'                 'INTORG'
    x_28_4    OBJ       -1.3963870760694466e-03
    x_28_4    product_lb_29  -2.4093620927006652e-02
    x_28_4    product_ub_30  -4.0838154504392050e-02
    x_28_4    onehot_28_35  1
    x_28_4    stock_lb_174  4
    x_28_4    stock_ub_175  4
    x_28_4    parent_nonstrict_scope_176  2.7927741521388914e-03
    x_28_4    unique_nonzero_owner_246  -1
    MARKER    'MARKER'                 'INTEND'
    w_28_4    product_lb_29  1
    w_28_4    product_ub_30  1
    w_28_4    normalized_mass_28_36  1
    w_28_4    normalized_ratio_28_37  -1.3333333333333333e+00
    w_28_4    full_original_Gini_234  -1.1846428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_28_5    OBJ       1.3963870760694448e-03
    x_28_5    product_lb_31  -2.4093620927006652e-02
    x_28_5    product_ub_32  -4.0838154504392050e-02
    x_28_5    onehot_28_35  1
    x_28_5    stock_lb_174  5
    x_28_5    stock_ub_175  5
    x_28_5    parent_nonstrict_scope_176  5.5855483042777827e-03
    x_28_5    unique_nonzero_owner_247  -1
    MARKER    'MARKER'                 'INTEND'
    w_28_5    product_lb_31  1
    w_28_5    product_ub_32  1
    w_28_5    normalized_mass_28_36  1
    w_28_5    normalized_ratio_28_37  -1.6666666666666665e+00
    w_28_5    full_original_Gini_234  -2.0513095238095236e+01
    MARKER    'MARKER'                 'INTORG'
    x_28_6    OBJ       4.1891612282083379e-03
    x_28_6    product_lb_33  -2.4093620927006652e-02
    x_28_6    product_ub_34  -4.0838154504392050e-02
    x_28_6    onehot_28_35  1
    x_28_6    stock_lb_174  6
    x_28_6    stock_ub_175  6
    x_28_6    parent_nonstrict_scope_176  8.3783224564166758e-03
    x_28_6    unique_nonzero_owner_248  -1
    MARKER    'MARKER'                 'INTEND'
    w_28_6    product_lb_33  1
    w_28_6    product_ub_34  1
    w_28_6    normalized_mass_28_36  1
    w_28_6    normalized_ratio_28_37  -2
    w_28_6    full_original_Gini_234  -2.9513095238095232e+01
    rho_28    normalized_ratio_28_37  1
    rho_28    block_pair_pos_191  1
    rho_28    block_pair_neg_192  -1
    rho_28    block_pair_pos_203  -1
    rho_28    block_pair_neg_204  1
    rho_28    block_pair_pos_205  -1
    rho_28    block_pair_neg_206  1
    rho_28    block_pair_pos_207  -1
    rho_28    block_pair_neg_208  1
    rho_28    block_pair_pos_209  -1
    rho_28    block_pair_neg_210  1
    rho_28    block_pair_pos_211  -1
    rho_28    block_pair_neg_212  1
    rho_28    block_pair_pos_213  -1
    rho_28    block_pair_neg_214  1
    rho_28    normalization_233  1
    MARKER    'MARKER'                 'INTORG'
    x_34_0    OBJ       2.9789603523644435e-02
    x_34_0    product_lb_38  -2.4093620927006652e-02
    x_34_0    product_ub_39  -4.0838154504392050e-02
    x_34_0    onehot_34_70  1
    x_34_0    parent_nonstrict_scope_176  5.9579207047288869e-02
    x_34_0    unique_nonzero_owner_249  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_0    product_lb_38  1
    w_34_0    product_ub_39  1
    w_34_0    normalized_mass_34_71  1
    w_34_0    full_original_Gini_234  -2.4486904761904764e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_1    OBJ       2.2342202642733327e-02
    x_34_1    product_lb_40  -2.4093620927006652e-02
    x_34_1    product_ub_41  -4.0838154504392050e-02
    x_34_1    onehot_34_70  1
    x_34_1    stock_lb_174  1
    x_34_1    stock_ub_175  1
    x_34_1    parent_nonstrict_scope_176  5.2131806166377762e-02
    x_34_1    unique_nonzero_owner_250  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_1    product_lb_40  1
    w_34_1    product_ub_41  1
    w_34_1    normalized_mass_34_71  1
    w_34_1    normalized_ratio_34_72  -0.125
    w_34_1    full_original_Gini_234  -2.1111904761904764e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_2    OBJ       1.4894801761822219e-02
    x_34_2    product_lb_42  -2.4093620927006652e-02
    x_34_2    product_ub_43  -4.0838154504392050e-02
    x_34_2    onehot_34_70  1
    x_34_2    stock_lb_174  2
    x_34_2    stock_ub_175  2
    x_34_2    parent_nonstrict_scope_176  4.4684405285466654e-02
    MARKER    'MARKER'                 'INTEND'
    w_34_2    product_lb_42  1
    w_34_2    product_ub_43  1
    w_34_2    normalized_mass_34_71  1
    w_34_2    normalized_ratio_34_72  -0.25
    w_34_2    full_original_Gini_234  -1.7736904761904764e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_3    OBJ       7.4474008809111113e-03
    x_34_3    product_lb_44  -2.4093620927006652e-02
    x_34_3    product_ub_45  -4.0838154504392050e-02
    x_34_3    onehot_34_70  1
    x_34_3    stock_lb_174  3
    x_34_3    stock_ub_175  3
    x_34_3    parent_nonstrict_scope_176  3.7237004404555546e-02
    x_34_3    unique_nonzero_owner_251  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_3    product_lb_44  1
    w_34_3    product_ub_45  1
    w_34_3    normalized_mass_34_71  1
    w_34_3    normalized_ratio_34_72  -0.375
    w_34_3    full_original_Gini_234  -1.4361904761904762e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_4    product_lb_46  -2.4093620927006652e-02
    x_34_4    product_ub_47  -4.0838154504392050e-02
    x_34_4    onehot_34_70  1
    x_34_4    stock_lb_174  4
    x_34_4    stock_ub_175  4
    x_34_4    parent_nonstrict_scope_176  2.9789603523644435e-02
    x_34_4    unique_nonzero_owner_252  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_4    product_lb_46  1
    w_34_4    product_ub_47  1
    w_34_4    normalized_mass_34_71  1
    w_34_4    normalized_ratio_34_72  -0.5
    w_34_4    full_original_Gini_234  -1.0986904761904762e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_5    OBJ       -7.4474008809111078e-03
    x_34_5    product_lb_48  -2.4093620927006652e-02
    x_34_5    product_ub_49  -4.0838154504392050e-02
    x_34_5    onehot_34_70  1
    x_34_5    stock_lb_174  5
    x_34_5    stock_ub_175  5
    x_34_5    parent_nonstrict_scope_176  2.2342202642733327e-02
    x_34_5    unique_nonzero_owner_253  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_5    product_lb_48  1
    w_34_5    product_ub_49  1
    w_34_5    normalized_mass_34_71  1
    w_34_5    normalized_ratio_34_72  -0.625
    w_34_5    full_original_Gini_234  -7.6119047619047615e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_6    OBJ       -1.4894801761822217e-02
    x_34_6    product_lb_50  -2.4093620927006652e-02
    x_34_6    product_ub_51  -4.0838154504392050e-02
    x_34_6    onehot_34_70  1
    x_34_6    stock_lb_174  6
    x_34_6    stock_ub_175  6
    x_34_6    parent_nonstrict_scope_176  1.4894801761822217e-02
    x_34_6    unique_nonzero_owner_254  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_6    product_lb_50  1
    w_34_6    product_ub_51  1
    w_34_6    normalized_mass_34_71  1
    w_34_6    normalized_ratio_34_72  -0.75
    w_34_6    full_original_Gini_234  -4.4035714285714276e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_7    OBJ       -2.2342202642733327e-02
    x_34_7    product_lb_52  -2.4093620927006652e-02
    x_34_7    product_ub_53  -4.0838154504392050e-02
    x_34_7    onehot_34_70  1
    x_34_7    stock_lb_174  7
    x_34_7    stock_ub_175  7
    x_34_7    parent_nonstrict_scope_176  7.4474008809111087e-03
    x_34_7    unique_nonzero_owner_255  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_7    product_lb_52  1
    w_34_7    product_ub_53  1
    w_34_7    normalized_mass_34_71  1
    w_34_7    normalized_ratio_34_72  -0.875
    w_34_7    full_original_Gini_234  -3.1380952380952385e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_8    OBJ       -2.9789603523644435e-02
    x_34_8    product_lb_54  -2.4093620927006652e-02
    x_34_8    product_ub_55  -4.0838154504392050e-02
    x_34_8    onehot_34_70  1
    x_34_8    stock_lb_174  8
    x_34_8    stock_ub_175  8
    x_34_8    unique_nonzero_owner_256  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_8    product_lb_54  1
    w_34_8    product_ub_55  1
    w_34_8    normalized_mass_34_71  1
    w_34_8    normalized_ratio_34_72  -1
    w_34_8    full_original_Gini_234  -3.5130952380952385e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_9    OBJ       -2.2342202642733327e-02
    x_34_9    product_lb_56  -2.4093620927006652e-02
    x_34_9    product_ub_57  -4.0838154504392050e-02
    x_34_9    onehot_34_70  1
    x_34_9    stock_lb_174  9
    x_34_9    stock_ub_175  9
    x_34_9    parent_nonstrict_scope_176  7.4474008809111087e-03
    x_34_9    unique_nonzero_owner_257  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_9    product_lb_56  1
    w_34_9    product_ub_57  1
    w_34_9    normalized_mass_34_71  1
    w_34_9    normalized_ratio_34_72  -1.125
    w_34_9    full_original_Gini_234  -6.6380952380952385e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_10   OBJ       -1.4894801761822217e-02
    x_34_10   product_lb_58  -2.4093620927006652e-02
    x_34_10   product_ub_59  -4.0838154504392050e-02
    x_34_10   onehot_34_70  1
    x_34_10   stock_lb_174  10
    x_34_10   stock_ub_175  10
    x_34_10   parent_nonstrict_scope_176  1.4894801761822217e-02
    x_34_10   unique_nonzero_owner_258  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_10   product_lb_58  1
    w_34_10   product_ub_59  1
    w_34_10   normalized_mass_34_71  1
    w_34_10   normalized_ratio_34_72  -1.25
    w_34_10   full_original_Gini_234  -9.7630952380952376e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_11   OBJ       -7.4474008809111078e-03
    x_34_11   product_lb_60  -2.4093620927006652e-02
    x_34_11   product_ub_61  -4.0838154504392050e-02
    x_34_11   onehot_34_70  1
    x_34_11   stock_lb_174  11
    x_34_11   stock_ub_175  11
    x_34_11   parent_nonstrict_scope_176  2.2342202642733327e-02
    x_34_11   unique_nonzero_owner_259  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_11   product_lb_60  1
    w_34_11   product_ub_61  1
    w_34_11   normalized_mass_34_71  1
    w_34_11   normalized_ratio_34_72  -1.375
    w_34_11   full_original_Gini_234  -1.2888095238095238e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_12   product_lb_62  -2.4093620927006652e-02
    x_34_12   product_ub_63  -4.0838154504392050e-02
    x_34_12   onehot_34_70  1
    x_34_12   stock_lb_174  12
    x_34_12   stock_ub_175  12
    x_34_12   parent_nonstrict_scope_176  2.9789603523644435e-02
    x_34_12   unique_nonzero_owner_260  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_12   product_lb_62  1
    w_34_12   product_ub_63  1
    w_34_12   normalized_mass_34_71  1
    w_34_12   normalized_ratio_34_72  -1.5
    w_34_12   full_original_Gini_234  -1.6013095238095239e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_13   OBJ       7.4474008809111113e-03
    x_34_13   product_lb_64  -2.4093620927006652e-02
    x_34_13   product_ub_65  -4.0838154504392050e-02
    x_34_13   onehot_34_70  1
    x_34_13   stock_lb_174  13
    x_34_13   stock_ub_175  13
    x_34_13   parent_nonstrict_scope_176  3.7237004404555546e-02
    x_34_13   unique_nonzero_owner_261  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_13   product_lb_64  1
    w_34_13   product_ub_65  1
    w_34_13   normalized_mass_34_71  1
    w_34_13   normalized_ratio_34_72  -1.625
    w_34_13   full_original_Gini_234  -1.9388095238095236e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_14   OBJ       1.4894801761822219e-02
    x_34_14   product_lb_66  -2.4093620927006652e-02
    x_34_14   product_ub_67  -4.0838154504392050e-02
    x_34_14   onehot_34_70  1
    x_34_14   stock_lb_174  14
    x_34_14   stock_ub_175  14
    x_34_14   parent_nonstrict_scope_176  4.4684405285466654e-02
    x_34_14   unique_nonzero_owner_262  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_14   product_lb_66  1
    w_34_14   product_ub_67  1
    w_34_14   normalized_mass_34_71  1
    w_34_14   normalized_ratio_34_72  -1.75
    w_34_14   full_original_Gini_234  -2.2763095238095236e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_15   OBJ       2.2342202642733327e-02
    x_34_15   product_lb_68  -2.4093620927006652e-02
    x_34_15   product_ub_69  -4.0838154504392050e-02
    x_34_15   onehot_34_70  1
    x_34_15   stock_lb_174  15
    x_34_15   stock_ub_175  15
    x_34_15   parent_nonstrict_scope_176  5.2131806166377762e-02
    x_34_15   unique_nonzero_owner_263  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_15   product_lb_68  1
    w_34_15   product_ub_69  1
    w_34_15   normalized_mass_34_71  1
    w_34_15   normalized_ratio_34_72  -1.875
    w_34_15   full_original_Gini_234  -2.6138095238095232e+01
    rho_34    normalized_ratio_34_72  1
    rho_34    block_pair_pos_195  1
    rho_34    block_pair_neg_196  -1
    rho_34    block_pair_pos_213  1
    rho_34    block_pair_neg_214  -1
    rho_34    block_pair_pos_223  -1
    rho_34    block_pair_neg_224  1
    rho_34    block_pair_pos_225  -1
    rho_34    block_pair_neg_226  1
    rho_34    block_pair_pos_227  -1
    rho_34    block_pair_neg_228  1
    rho_34    block_pair_pos_229  -1
    rho_34    block_pair_neg_230  1
    rho_34    block_pair_pos_231  -1
    rho_34    block_pair_neg_232  1
    rho_34    normalization_233  1
    MARKER    'MARKER'                 'INTORG'
    x_29_0    OBJ       1.1636571534741636e-02
    x_29_0    product_lb_73  -2.4093620927006652e-02
    x_29_0    product_ub_74  -4.0838154504392050e-02
    x_29_0    onehot_29_95  1
    x_29_0    parent_nonstrict_scope_176  2.3273143069483273e-02
    x_29_0    unique_nonzero_owner_264  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_0    product_lb_73  1
    w_29_0    product_ub_74  1
    w_29_0    normalized_mass_29_96  1
    w_29_0    full_original_Gini_234  -2.4486904761904764e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_1    OBJ       6.9819429208449833e-03
    x_29_1    product_lb_75  -2.4093620927006652e-02
    x_29_1    product_ub_76  -4.0838154504392050e-02
    x_29_1    onehot_29_95  1
    x_29_1    stock_lb_174  1
    x_29_1    stock_ub_175  1
    x_29_1    parent_nonstrict_scope_176  1.8618514455586620e-02
    MARKER    'MARKER'                 'INTEND'
    w_29_1    product_lb_75  1
    w_29_1    product_ub_76  1
    w_29_1    normalized_mass_29_96  1
    w_29_1    normalized_ratio_29_97  -0.2
    w_29_1    full_original_Gini_234  -1.9086904761904769e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_2    OBJ       2.3273143069483266e-03
    x_29_2    product_lb_77  -2.4093620927006652e-02
    x_29_2    product_ub_78  -4.0838154504392050e-02
    x_29_2    onehot_29_95  1
    x_29_2    stock_lb_174  2
    x_29_2    stock_ub_175  2
    x_29_2    parent_nonstrict_scope_176  1.3963885841689963e-02
    x_29_2    unique_nonzero_owner_265  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_2    product_lb_77  1
    w_29_2    product_ub_78  1
    w_29_2    normalized_mass_29_96  1
    w_29_2    normalized_ratio_29_97  -0.4
    w_29_2    full_original_Gini_234  -1.3686904761904756e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_3    OBJ       -0.00232731430694833
    x_29_3    product_lb_79  -2.4093620927006652e-02
    x_29_3    product_ub_80  -4.0838154504392050e-02
    x_29_3    onehot_29_95  1
    x_29_3    stock_lb_174  3
    x_29_3    stock_ub_175  3
    x_29_3    parent_nonstrict_scope_176  9.3092572277933064e-03
    x_29_3    unique_nonzero_owner_266  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_3    product_lb_79  1
    w_29_3    product_ub_80  1
    w_29_3    normalized_mass_29_96  1
    w_29_3    normalized_ratio_29_97  -6.0000000000000009e-01
    w_29_3    full_original_Gini_234  -8.2869047619047649e+00
    MARKER    'MARKER'                 'INTORG'
    x_29_4    OBJ       -6.9819429208449833e-03
    x_29_4    product_lb_81  -2.4093620927006652e-02
    x_29_4    product_ub_82  -4.0838154504392050e-02
    x_29_4    onehot_29_95  1
    x_29_4    stock_lb_174  4
    x_29_4    stock_ub_175  4
    x_29_4    parent_nonstrict_scope_176  4.6546286138966532e-03
    x_29_4    unique_nonzero_owner_267  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_4    product_lb_81  1
    w_29_4    product_ub_82  1
    w_29_4    normalized_mass_29_96  1
    w_29_4    normalized_ratio_29_97  -0.8
    w_29_4    full_original_Gini_234  -3.6535714285714294e+00
    MARKER    'MARKER'                 'INTORG'
    x_29_5    OBJ       -1.1636571534741636e-02
    x_29_5    product_lb_83  -2.4093620927006652e-02
    x_29_5    product_ub_84  -4.0838154504392050e-02
    x_29_5    onehot_29_95  1
    x_29_5    stock_lb_174  5
    x_29_5    stock_ub_175  5
    x_29_5    unique_nonzero_owner_268  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_5    product_lb_83  1
    w_29_5    product_ub_84  1
    w_29_5    normalized_mass_29_96  1
    w_29_5    normalized_ratio_29_97  -1
    w_29_5    full_original_Gini_234  -3.5130952380952385e+00
    MARKER    'MARKER'                 'INTORG'
    x_29_6    OBJ       -6.9819429208449781e-03
    x_29_6    product_lb_85  -2.4093620927006652e-02
    x_29_6    product_ub_86  -4.0838154504392050e-02
    x_29_6    onehot_29_95  1
    x_29_6    stock_lb_174  6
    x_29_6    stock_ub_175  6
    x_29_6    parent_nonstrict_scope_176  4.6546286138966584e-03
    x_29_6    unique_nonzero_owner_269  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_6    product_lb_85  1
    w_29_6    product_ub_86  1
    w_29_6    normalized_mass_29_96  1
    w_29_6    normalized_ratio_29_97  -1.2000000000000002e+00
    w_29_6    full_original_Gini_234  -8.5130952380952429e+00
    MARKER    'MARKER'                 'INTORG'
    x_29_7    OBJ       -2.3273143069483249e-03
    x_29_7    product_lb_87  -2.4093620927006652e-02
    x_29_7    product_ub_88  -4.0838154504392050e-02
    x_29_7    onehot_29_95  1
    x_29_7    stock_lb_174  7
    x_29_7    stock_ub_175  7
    x_29_7    parent_nonstrict_scope_176  9.3092572277933116e-03
    x_29_7    unique_nonzero_owner_270  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_7    product_lb_87  1
    w_29_7    product_ub_88  1
    w_29_7    normalized_mass_29_96  1
    w_29_7    normalized_ratio_29_97  -1.4000000000000001e+00
    w_29_7    full_original_Gini_234  -1.3513095238095245e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_8    OBJ       0.00232731430694833
    x_29_8    product_lb_89  -2.4093620927006652e-02
    x_29_8    product_ub_90  -4.0838154504392050e-02
    x_29_8    onehot_29_95  1
    x_29_8    stock_lb_174  8
    x_29_8    stock_ub_175  8
    x_29_8    parent_nonstrict_scope_176  1.3963885841689967e-02
    x_29_8    unique_nonzero_owner_271  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_8    product_lb_89  1
    w_29_8    product_ub_90  1
    w_29_8    normalized_mass_29_96  1
    w_29_8    normalized_ratio_29_97  -1.6
    w_29_8    full_original_Gini_234  -1.8713095238095239e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_9    OBJ       6.9819429208449833e-03
    x_29_9    product_lb_91  -2.4093620927006652e-02
    x_29_9    product_ub_92  -4.0838154504392050e-02
    x_29_9    onehot_29_95  1
    x_29_9    stock_lb_174  9
    x_29_9    stock_ub_175  9
    x_29_9    parent_nonstrict_scope_176  1.8618514455586620e-02
    x_29_9    unique_nonzero_owner_272  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_9    product_lb_91  1
    w_29_9    product_ub_92  1
    w_29_9    normalized_mass_29_96  1
    w_29_9    normalized_ratio_29_97  -1.8
    w_29_9    full_original_Gini_234  -2.4113095238095248e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_10   OBJ       1.1636571534741636e-02
    x_29_10   product_lb_93  -2.4093620927006652e-02
    x_29_10   product_ub_94  -4.0838154504392050e-02
    x_29_10   onehot_29_95  1
    x_29_10   stock_lb_174  10
    x_29_10   stock_ub_175  10
    x_29_10   parent_nonstrict_scope_176  2.3273143069483273e-02
    x_29_10   unique_nonzero_owner_273  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_10   product_lb_93  1
    w_29_10   product_ub_94  1
    w_29_10   normalized_mass_29_96  1
    w_29_10   normalized_ratio_29_97  -2
    w_29_10   full_original_Gini_234  -2.9513095238095232e+01
    rho_29    normalized_ratio_29_97  1
    rho_29    block_pair_pos_193  1
    rho_29    block_pair_neg_194  -1
    rho_29    block_pair_pos_211  1
    rho_29    block_pair_neg_212  -1
    rho_29    block_pair_pos_215  -1
    rho_29    block_pair_neg_216  1
    rho_29    block_pair_pos_217  -1
    rho_29    block_pair_neg_218  1
    rho_29    block_pair_pos_219  -1
    rho_29    block_pair_neg_220  1
    rho_29    block_pair_pos_221  -1
    rho_29    block_pair_neg_222  1
    rho_29    block_pair_pos_231  1
    rho_29    block_pair_neg_232  -1
    rho_29    normalization_233  1
    MARKER    'MARKER'                 'INTORG'
    x_27_0    OBJ       4.1891612282083379e-03
    x_27_0    product_lb_98  -2.4093620927006652e-02
    x_27_0    product_ub_99  -4.0838154504392050e-02
    x_27_0    onehot_27_112  1
    x_27_0    parent_nonstrict_scope_176  8.3783224564166758e-03
    MARKER    'MARKER'                 'INTEND'
    w_27_0    product_lb_98  1
    w_27_0    product_ub_99  1
    w_27_0    normalized_mass_27_113  1
    w_27_0    full_original_Gini_234  -2.4486904761904764e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_1    OBJ       1.3963870760694466e-03
    x_27_1    product_lb_100  -2.4093620927006652e-02
    x_27_1    product_ub_101  -4.0838154504392050e-02
    x_27_1    onehot_27_112  1
    x_27_1    stock_lb_174  1
    x_27_1    stock_ub_175  1
    x_27_1    parent_nonstrict_scope_176  5.5855483042777845e-03
    x_27_1    unique_nonzero_owner_274  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_1    product_lb_100  1
    w_27_1    product_ub_101  1
    w_27_1    normalized_mass_27_113  1
    w_27_1    normalized_ratio_27_114  -3.3333333333333331e-01
    w_27_1    full_original_Gini_234  -1.5486904761904757e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_2    OBJ       -1.3963870760694457e-03
    x_27_2    product_lb_102  -2.4093620927006652e-02
    x_27_2    product_ub_103  -4.0838154504392050e-02
    x_27_2    onehot_27_112  1
    x_27_2    stock_lb_174  2
    x_27_2    stock_ub_175  2
    x_27_2    parent_nonstrict_scope_176  2.7927741521388922e-03
    x_27_2    unique_nonzero_owner_275  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_2    product_lb_102  1
    w_27_2    product_ub_103  1
    w_27_2    normalized_mass_27_113  1
    w_27_2    normalized_ratio_27_114  -6.6666666666666663e-01
    w_27_2    full_original_Gini_234  -6.4869047619047606e+00
    MARKER    'MARKER'                 'INTORG'
    x_27_3    OBJ       -4.1891612282083379e-03
    x_27_3    product_lb_104  -2.4093620927006652e-02
    x_27_3    product_ub_105  -4.0838154504392050e-02
    x_27_3    onehot_27_112  1
    x_27_3    stock_lb_174  3
    x_27_3    stock_ub_175  3
    x_27_3    unique_nonzero_owner_276  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_3    product_lb_104  1
    w_27_3    product_ub_105  1
    w_27_3    normalized_mass_27_113  1
    w_27_3    normalized_ratio_27_114  -1
    w_27_3    full_original_Gini_234  -3.5130952380952385e+00
    MARKER    'MARKER'                 'INTORG'
    x_27_4    OBJ       -1.3963870760694466e-03
    x_27_4    product_lb_106  -2.4093620927006652e-02
    x_27_4    product_ub_107  -4.0838154504392050e-02
    x_27_4    onehot_27_112  1
    x_27_4    stock_lb_174  4
    x_27_4    stock_ub_175  4
    x_27_4    parent_nonstrict_scope_176  2.7927741521388914e-03
    x_27_4    unique_nonzero_owner_277  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_4    product_lb_106  1
    w_27_4    product_ub_107  1
    w_27_4    normalized_mass_27_113  1
    w_27_4    normalized_ratio_27_114  -1.3333333333333333e+00
    w_27_4    full_original_Gini_234  -1.1846428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_5    OBJ       1.3963870760694448e-03
    x_27_5    product_lb_108  -2.4093620927006652e-02
    x_27_5    product_ub_109  -4.0838154504392050e-02
    x_27_5    onehot_27_112  1
    x_27_5    stock_lb_174  5
    x_27_5    stock_ub_175  5
    x_27_5    parent_nonstrict_scope_176  5.5855483042777827e-03
    x_27_5    unique_nonzero_owner_278  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_5    product_lb_108  1
    w_27_5    product_ub_109  1
    w_27_5    normalized_mass_27_113  1
    w_27_5    normalized_ratio_27_114  -1.6666666666666665e+00
    w_27_5    full_original_Gini_234  -2.0513095238095236e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_6    OBJ       4.1891612282083379e-03
    x_27_6    product_lb_110  -2.4093620927006652e-02
    x_27_6    product_ub_111  -4.0838154504392050e-02
    x_27_6    onehot_27_112  1
    x_27_6    stock_lb_174  6
    x_27_6    stock_ub_175  6
    x_27_6    parent_nonstrict_scope_176  8.3783224564166758e-03
    x_27_6    unique_nonzero_owner_279  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_6    product_lb_110  1
    w_27_6    product_ub_111  1
    w_27_6    normalized_mass_27_113  1
    w_27_6    normalized_ratio_27_114  -2
    w_27_6    full_original_Gini_234  -2.9513095238095232e+01
    rho_27    normalized_ratio_27_114  1
    rho_27    block_pair_pos_189  1
    rho_27    block_pair_neg_190  -1
    rho_27    block_pair_pos_197  -1
    rho_27    block_pair_neg_198  1
    rho_27    block_pair_pos_199  -1
    rho_27    block_pair_neg_200  1
    rho_27    block_pair_pos_201  -1
    rho_27    block_pair_neg_202  1
    rho_27    block_pair_pos_209  1
    rho_27    block_pair_neg_210  -1
    rho_27    block_pair_pos_221  1
    rho_27    block_pair_neg_222  -1
    rho_27    block_pair_pos_229  1
    rho_27    block_pair_neg_230  -1
    rho_27    normalization_233  1
    MARKER    'MARKER'                 'INTORG'
    x_22_0    OBJ       1.9549429837111887e-02
    x_22_0    product_lb_115  -2.4093620927006652e-02
    x_22_0    product_ub_116  -4.0838154504392050e-02
    x_22_0    onehot_22_147  1
    x_22_0    parent_nonstrict_scope_176  0.0456153362865944
    x_22_0    unique_nonzero_owner_280  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_0    product_lb_115  1
    w_22_0    product_ub_116  1
    w_22_0    normalized_mass_22_148  1
    w_22_0    full_original_Gini_234  -2.4486904761904764e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_1    OBJ       1.3032953224741260e-02
    x_22_1    product_lb_117  -2.4093620927006652e-02
    x_22_1    product_ub_118  -4.0838154504392050e-02
    x_22_1    onehot_22_147  1
    x_22_1    stock_lb_174  1
    x_22_1    stock_ub_175  1
    x_22_1    parent_nonstrict_scope_176  3.9098859674223774e-02
    x_22_1    unique_nonzero_owner_281  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_1    product_lb_117  1
    w_22_1    product_ub_118  1
    w_22_1    normalized_mass_22_148  1
    w_22_1    normalized_ratio_22_149  -1.4285714285714285e-01
    w_22_1    full_original_Gini_234  -2.0629761904761910e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_2    OBJ       6.5164766123706336e-03
    x_22_2    product_lb_119  -2.4093620927006652e-02
    x_22_2    product_ub_120  -4.0838154504392050e-02
    x_22_2    onehot_22_147  1
    x_22_2    stock_lb_174  2
    x_22_2    stock_ub_175  2
    x_22_2    parent_nonstrict_scope_176  3.2582383061853147e-02
    MARKER    'MARKER'                 'INTEND'
    w_22_2    product_lb_119  1
    w_22_2    product_ub_120  1
    w_22_2    normalized_mass_22_148  1
    w_22_2    normalized_ratio_22_149  -2.8571428571428570e-01
    w_22_2    full_original_Gini_234  -1.6772619047619042e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_3    product_lb_121  -2.4093620927006652e-02
    x_22_3    product_ub_122  -4.0838154504392050e-02
    x_22_3    onehot_22_147  1
    x_22_3    stock_lb_174  3
    x_22_3    stock_ub_175  3
    x_22_3    parent_nonstrict_scope_176  2.6065906449482514e-02
    x_22_3    unique_nonzero_owner_282  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_3    product_lb_121  1
    w_22_3    product_ub_122  1
    w_22_3    normalized_mass_22_148  1
    w_22_3    normalized_ratio_22_149  -4.2857142857142855e-01
    w_22_3    full_original_Gini_234  -1.2915476190476188e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_4    OBJ       -6.5164766123706266e-03
    x_22_4    product_lb_123  -2.4093620927006652e-02
    x_22_4    product_ub_124  -4.0838154504392050e-02
    x_22_4    onehot_22_147  1
    x_22_4    stock_lb_174  4
    x_22_4    stock_ub_175  4
    x_22_4    parent_nonstrict_scope_176  1.9549429837111887e-02
    x_22_4    unique_nonzero_owner_283  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_4    product_lb_123  1
    w_22_4    product_ub_124  1
    w_22_4    normalized_mass_22_148  1
    w_22_4    normalized_ratio_22_149  -5.7142857142857140e-01
    w_22_4    full_original_Gini_234  -9.0583333333333353e+00
    MARKER    'MARKER'                 'INTORG'
    x_22_5    OBJ       -1.3032953224741252e-02
    x_22_5    product_lb_125  -2.4093620927006652e-02
    x_22_5    product_ub_126  -4.0838154504392050e-02
    x_22_5    onehot_22_147  1
    x_22_5    stock_lb_174  5
    x_22_5    stock_ub_175  5
    x_22_5    parent_nonstrict_scope_176  1.3032953224741262e-02
    x_22_5    unique_nonzero_owner_284  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_5    product_lb_125  1
    w_22_5    product_ub_126  1
    w_22_5    normalized_mass_22_148  1
    w_22_5    normalized_ratio_22_149  -7.1428571428571419e-01
    w_22_5    full_original_Gini_234  -5.2964285714285717e+00
    MARKER    'MARKER'                 'INTORG'
    x_22_6    OBJ       -1.9549429837111883e-02
    x_22_6    product_lb_127  -2.4093620927006652e-02
    x_22_6    product_ub_128  -4.0838154504392050e-02
    x_22_6    onehot_22_147  1
    x_22_6    stock_lb_174  6
    x_22_6    stock_ub_175  6
    x_22_6    parent_nonstrict_scope_176  6.5164766123706310e-03
    x_22_6    unique_nonzero_owner_285  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_6    product_lb_127  1
    w_22_6    product_ub_128  1
    w_22_6    normalized_mass_22_148  1
    w_22_6    normalized_ratio_22_149  -8.5714285714285710e-01
    w_22_6    full_original_Gini_234  -3.1202380952380948e+00
    MARKER    'MARKER'                 'INTORG'
    x_22_7    OBJ       -2.6065906449482514e-02
    x_22_7    product_lb_129  -2.4093620927006652e-02
    x_22_7    product_ub_130  -4.0838154504392050e-02
    x_22_7    onehot_22_147  1
    x_22_7    stock_lb_174  7
    x_22_7    stock_ub_175  7
    x_22_7    unique_nonzero_owner_286  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_7    product_lb_129  1
    w_22_7    product_ub_130  1
    w_22_7    normalized_mass_22_148  1
    w_22_7    normalized_ratio_22_149  -1
    w_22_7    full_original_Gini_234  -3.5130952380952385e+00
    MARKER    'MARKER'                 'INTORG'
    x_22_8    OBJ       -1.9549429837111887e-02
    x_22_8    product_lb_131  -2.4093620927006652e-02
    x_22_8    product_ub_132  -4.0838154504392050e-02
    x_22_8    onehot_22_147  1
    x_22_8    stock_lb_174  8
    x_22_8    stock_ub_175  8
    x_22_8    parent_nonstrict_scope_176  6.5164766123706258e-03
    x_22_8    unique_nonzero_owner_287  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_8    product_lb_131  1
    w_22_8    product_ub_132  1
    w_22_8    normalized_mass_22_148  1
    w_22_8    normalized_ratio_22_149  -1.1428571428571428e+00
    w_22_8    full_original_Gini_234  -7.0845238095238035e+00
    MARKER    'MARKER'                 'INTORG'
    x_22_9    OBJ       -1.3032953224741262e-02
    x_22_9    product_lb_133  -2.4093620927006652e-02
    x_22_9    product_ub_134  -4.0838154504392050e-02
    x_22_9    onehot_22_147  1
    x_22_9    stock_lb_174  9
    x_22_9    stock_ub_175  9
    x_22_9    parent_nonstrict_scope_176  1.3032953224741252e-02
    x_22_9    unique_nonzero_owner_288  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_9    product_lb_133  1
    w_22_9    product_ub_134  1
    w_22_9    normalized_mass_22_148  1
    w_22_9    normalized_ratio_22_149  -1.2857142857142856e+00
    w_22_9    full_original_Gini_234  -1.0655952380952375e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_10   OBJ       -6.5164766123706371e-03
    x_22_10   product_lb_135  -2.4093620927006652e-02
    x_22_10   product_ub_136  -4.0838154504392050e-02
    x_22_10   onehot_22_147  1
    x_22_10   stock_lb_174  10
    x_22_10   stock_ub_175  10
    x_22_10   parent_nonstrict_scope_176  1.9549429837111876e-02
    x_22_10   unique_nonzero_owner_289  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_10   product_lb_135  1
    w_22_10   product_ub_136  1
    w_22_10   normalized_mass_22_148  1
    w_22_10   normalized_ratio_22_149  -1.4285714285714284e+00
    w_22_10   full_original_Gini_234  -1.4227380952380953e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_11   product_lb_137  -2.4093620927006652e-02
    x_22_11   product_ub_138  -4.0838154504392050e-02
    x_22_11   onehot_22_147  1
    x_22_11   stock_lb_174  11
    x_22_11   stock_ub_175  11
    x_22_11   parent_nonstrict_scope_176  2.6065906449482514e-02
    x_22_11   unique_nonzero_owner_290  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_11   product_lb_137  1
    w_22_11   product_ub_138  1
    w_22_11   normalized_mass_22_148  1
    w_22_11   normalized_ratio_22_149  -1.5714285714285714e+00
    w_22_11   full_original_Gini_234  -1.7941666666666666e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_12   OBJ       6.5164766123706266e-03
    x_22_12   product_lb_139  -2.4093620927006652e-02
    x_22_12   product_ub_140  -4.0838154504392050e-02
    x_22_12   onehot_22_147  1
    x_22_12   stock_lb_174  12
    x_22_12   stock_ub_175  12
    x_22_12   parent_nonstrict_scope_176  3.2582383061853140e-02
    x_22_12   unique_nonzero_owner_291  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_12   product_lb_139  1
    w_22_12   product_ub_140  1
    w_22_12   normalized_mass_22_148  1
    w_22_12   normalized_ratio_22_149  -1.7142857142857142e+00
    w_22_12   full_original_Gini_234  -2.1798809523809521e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_13   OBJ       1.3032953224741253e-02
    x_22_13   product_lb_141  -2.4093620927006652e-02
    x_22_13   product_ub_142  -4.0838154504392050e-02
    x_22_13   onehot_22_147  1
    x_22_13   stock_lb_174  13
    x_22_13   stock_ub_175  13
    x_22_13   parent_nonstrict_scope_176  3.9098859674223767e-02
    x_22_13   unique_nonzero_owner_292  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_13   product_lb_141  1
    w_22_13   product_ub_142  1
    w_22_13   normalized_mass_22_148  1
    w_22_13   normalized_ratio_22_149  -1.8571428571428570e+00
    w_22_13   full_original_Gini_234  -2.5655952380952385e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_14   OBJ       1.9549429837111887e-02
    x_22_14   product_lb_143  -2.4093620927006652e-02
    x_22_14   product_ub_144  -4.0838154504392050e-02
    x_22_14   onehot_22_147  1
    x_22_14   stock_lb_174  14
    x_22_14   stock_ub_175  14
    x_22_14   parent_nonstrict_scope_176  0.0456153362865944
    x_22_14   unique_nonzero_owner_293  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_14   product_lb_143  1
    w_22_14   product_ub_144  1
    w_22_14   normalized_mass_22_148  1
    w_22_14   normalized_ratio_22_149  -2
    w_22_14   full_original_Gini_234  -2.9513095238095232e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_15   OBJ       2.6065906449482514e-02
    x_22_15   product_lb_145  -2.4093620927006652e-02
    x_22_15   product_ub_146  -4.0838154504392050e-02
    x_22_15   onehot_22_147  1
    x_22_15   stock_lb_174  15
    x_22_15   stock_ub_175  15
    x_22_15   parent_nonstrict_scope_176  5.2131812898965027e-02
    x_22_15   unique_nonzero_owner_294  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_15   product_lb_145  1
    w_22_15   product_ub_146  1
    w_22_15   normalized_mass_22_148  1
    w_22_15   normalized_ratio_22_149  -2.1428571428571428e+00
    w_22_15   full_original_Gini_234  -3.3370238095238093e+01
    rho_22    normalized_ratio_22_149  1
    rho_22    block_pair_pos_177  -1
    rho_22    block_pair_neg_178  1
    rho_22    block_pair_pos_179  -1
    rho_22    block_pair_neg_180  1
    rho_22    block_pair_pos_183  1
    rho_22    block_pair_neg_184  -1
    rho_22    block_pair_pos_197  1
    rho_22    block_pair_neg_198  -1
    rho_22    block_pair_pos_203  1
    rho_22    block_pair_neg_204  -1
    rho_22    block_pair_pos_215  1
    rho_22    block_pair_neg_216  -1
    rho_22    block_pair_pos_223  1
    rho_22    block_pair_neg_224  -1
    rho_22    normalization_233  1
    MARKER    'MARKER'                 'INTORG'
    x_25_0    OBJ       3.7702488756363797e-03
    x_25_0    product_lb_150  -2.4093620927006652e-02
    x_25_0    product_ub_151  -4.0838154504392050e-02
    x_25_0    onehot_25_160  1
    x_25_0    parent_nonstrict_scope_176  7.5404977512727595e-03
    MARKER    'MARKER'                 'INTEND'
    w_25_0    product_lb_150  1
    w_25_0    product_ub_151  1
    w_25_0    normalized_mass_25_161  1
    w_25_0    full_original_Gini_234  -2.4486904761904764e+01
    MARKER    'MARKER'                 'INTORG'
    x_25_1    product_lb_152  -2.4093620927006652e-02
    x_25_1    product_ub_153  -4.0838154504392050e-02
    x_25_1    onehot_25_160  1
    x_25_1    stock_lb_174  1
    x_25_1    stock_ub_175  1
    x_25_1    parent_nonstrict_scope_176  3.7702488756363797e-03
    x_25_1    unique_nonzero_owner_295  -1
    MARKER    'MARKER'                 'INTEND'
    w_25_1    product_lb_152  1
    w_25_1    product_ub_153  1
    w_25_1    normalized_mass_25_161  1
    w_25_1    normalized_ratio_25_162  -0.5
    w_25_1    full_original_Gini_234  -1.0986904761904762e+01
    MARKER    'MARKER'                 'INTORG'
    x_25_2    OBJ       -3.7702488756363797e-03
    x_25_2    product_lb_154  -2.4093620927006652e-02
    x_25_2    product_ub_155  -4.0838154504392050e-02
    x_25_2    onehot_25_160  1
    x_25_2    stock_lb_174  2
    x_25_2    stock_ub_175  2
    x_25_2    unique_nonzero_owner_296  -1
    MARKER    'MARKER'                 'INTEND'
    w_25_2    product_lb_154  1
    w_25_2    product_ub_155  1
    w_25_2    normalized_mass_25_161  1
    w_25_2    normalized_ratio_25_162  -1
    w_25_2    full_original_Gini_234  -3.5130952380952385e+00
    MARKER    'MARKER'                 'INTORG'
    x_25_3    product_lb_156  -2.4093620927006652e-02
    x_25_3    product_ub_157  -4.0838154504392050e-02
    x_25_3    onehot_25_160  1
    x_25_3    stock_lb_174  3
    x_25_3    stock_ub_175  3
    x_25_3    parent_nonstrict_scope_176  3.7702488756363797e-03
    x_25_3    unique_nonzero_owner_297  -1
    MARKER    'MARKER'                 'INTEND'
    w_25_3    product_lb_156  1
    w_25_3    product_ub_157  1
    w_25_3    normalized_mass_25_161  1
    w_25_3    normalized_ratio_25_162  -1.5
    w_25_3    full_original_Gini_234  -1.6013095238095239e+01
    MARKER    'MARKER'                 'INTORG'
    x_25_4    OBJ       3.7702488756363797e-03
    x_25_4    product_lb_158  -2.4093620927006652e-02
    x_25_4    product_ub_159  -4.0838154504392050e-02
    x_25_4    onehot_25_160  1
    x_25_4    stock_lb_174  4
    x_25_4    stock_ub_175  4
    x_25_4    parent_nonstrict_scope_176  7.5404977512727595e-03
    x_25_4    unique_nonzero_owner_298  -1
    MARKER    'MARKER'                 'INTEND'
    w_25_4    product_lb_158  1
    w_25_4    product_ub_159  1
    w_25_4    normalized_mass_25_161  1
    w_25_4    normalized_ratio_25_162  -2
    w_25_4    full_original_Gini_234  -2.9513095238095232e+01
    rho_25    normalized_ratio_25_162  1
    rho_25    block_pair_pos_179  1
    rho_25    block_pair_neg_180  -1
    rho_25    block_pair_pos_181  -1
    rho_25    block_pair_neg_182  1
    rho_25    block_pair_pos_187  1
    rho_25    block_pair_neg_188  -1
    rho_25    block_pair_pos_201  1
    rho_25    block_pair_neg_202  -1
    rho_25    block_pair_pos_207  1
    rho_25    block_pair_neg_208  -1
    rho_25    block_pair_pos_219  1
    rho_25    block_pair_neg_220  -1
    rho_25    block_pair_pos_227  1
    rho_25    block_pair_neg_228  -1
    rho_25    normalization_233  1
    MARKER    'MARKER'                 'INTORG'
    x_23_0    product_lb_163  -2.4093620927006652e-02
    x_23_0    product_ub_164  -4.0838154504392050e-02
    x_23_0    onehot_23_171  1
    x_23_0    parent_nonstrict_scope_176  7.5404977512727595e-03
    x_23_0    unique_nonzero_owner_299  -1
    MARKER    'MARKER'                 'INTEND'
    w_23_0    product_lb_163  1
    w_23_0    product_ub_164  1
    w_23_0    normalized_mass_23_172  1
    w_23_0    full_original_Gini_234  -2.4486904761904764e+01
    MARKER    'MARKER'                 'INTORG'
    x_23_1    OBJ       -7.5404977512727595e-03
    x_23_1    product_lb_165  -2.4093620927006652e-02
    x_23_1    product_ub_166  -4.0838154504392050e-02
    x_23_1    onehot_23_171  1
    x_23_1    stock_lb_174  1
    x_23_1    stock_ub_175  1
    MARKER    'MARKER'                 'INTEND'
    w_23_1    product_lb_165  1
    w_23_1    product_ub_166  1
    w_23_1    normalized_mass_23_172  1
    w_23_1    normalized_ratio_23_173  -1
    w_23_1    full_original_Gini_234  -3.5130952380952385e+00
    MARKER    'MARKER'                 'INTORG'
    x_23_2    product_lb_167  -2.4093620927006652e-02
    x_23_2    product_ub_168  -4.0838154504392050e-02
    x_23_2    onehot_23_171  1
    x_23_2    stock_lb_174  2
    x_23_2    stock_ub_175  2
    x_23_2    parent_nonstrict_scope_176  7.5404977512727595e-03
    x_23_2    unique_nonzero_owner_300  -1
    MARKER    'MARKER'                 'INTEND'
    w_23_2    product_lb_167  1
    w_23_2    product_ub_168  1
    w_23_2    normalized_mass_23_172  1
    w_23_2    normalized_ratio_23_173  -2
    w_23_2    full_original_Gini_234  -2.9513095238095232e+01
    MARKER    'MARKER'                 'INTORG'
    x_23_3    OBJ       7.5404977512727595e-03
    x_23_3    product_lb_169  -2.4093620927006652e-02
    x_23_3    product_ub_170  -4.0838154504392050e-02
    x_23_3    onehot_23_171  1
    x_23_3    stock_lb_174  3
    x_23_3    stock_ub_175  3
    x_23_3    parent_nonstrict_scope_176  1.5080995502545519e-02
    x_23_3    unique_nonzero_owner_301  -1
    MARKER    'MARKER'                 'INTEND'
    w_23_3    product_lb_169  1
    w_23_3    product_ub_170  1
    w_23_3    normalized_mass_23_172  1
    w_23_3    normalized_ratio_23_173  -3
    w_23_3    full_original_Gini_234  -5.6513095238095239e+01
    rho_23    normalized_ratio_23_173  1
    rho_23    block_pair_pos_177  1
    rho_23    block_pair_neg_178  -1
    rho_23    block_pair_pos_181  1
    rho_23    block_pair_neg_182  -1
    rho_23    block_pair_pos_185  1
    rho_23    block_pair_neg_186  -1
    rho_23    block_pair_pos_199  1
    rho_23    block_pair_neg_200  -1
    rho_23    block_pair_pos_205  1
    rho_23    block_pair_neg_206  -1
    rho_23    block_pair_pos_217  1
    rho_23    block_pair_neg_218  -1
    rho_23    block_pair_pos_225  1
    rho_23    block_pair_neg_226  -1
    rho_23    normalization_233  1
    a_26_28   block_pair_pos_191  1
    a_26_28   block_pair_neg_192  1
    a_26_28   full_original_Gini_234  -1
    a_26_34   block_pair_pos_195  1
    a_26_34   block_pair_neg_196  1
    a_26_34   full_original_Gini_234  -1
    a_26_29   block_pair_pos_193  1
    a_26_29   block_pair_neg_194  1
    a_26_29   full_original_Gini_234  -1
    a_26_27   block_pair_pos_189  1
    a_26_27   block_pair_neg_190  1
    a_26_27   full_original_Gini_234  -1
    a_26_22   block_pair_pos_183  1
    a_26_22   block_pair_neg_184  1
    a_26_22   full_original_Gini_234  -1
    a_26_25   block_pair_pos_187  1
    a_26_25   block_pair_neg_188  1
    a_26_25   full_original_Gini_234  -1
    a_26_23   block_pair_pos_185  1
    a_26_23   block_pair_neg_186  1
    a_26_23   full_original_Gini_234  -1
    a_28_34   block_pair_pos_213  1
    a_28_34   block_pair_neg_214  1
    a_28_34   full_original_Gini_234  -1
    a_28_29   block_pair_pos_211  1
    a_28_29   block_pair_neg_212  1
    a_28_29   full_original_Gini_234  -1
    a_28_27   block_pair_pos_209  1
    a_28_27   block_pair_neg_210  1
    a_28_27   full_original_Gini_234  -1
    a_28_22   block_pair_pos_203  1
    a_28_22   block_pair_neg_204  1
    a_28_22   full_original_Gini_234  -1
    a_28_25   block_pair_pos_207  1
    a_28_25   block_pair_neg_208  1
    a_28_25   full_original_Gini_234  -1
    a_28_23   block_pair_pos_205  1
    a_28_23   block_pair_neg_206  1
    a_28_23   full_original_Gini_234  -1
    a_34_29   block_pair_pos_231  1
    a_34_29   block_pair_neg_232  1
    a_34_29   full_original_Gini_234  -1
    a_34_27   block_pair_pos_229  1
    a_34_27   block_pair_neg_230  1
    a_34_27   full_original_Gini_234  -1
    a_34_22   block_pair_pos_223  1
    a_34_22   block_pair_neg_224  1
    a_34_22   full_original_Gini_234  -1
    a_34_25   block_pair_pos_227  1
    a_34_25   block_pair_neg_228  1
    a_34_25   full_original_Gini_234  -1
    a_34_23   block_pair_pos_225  1
    a_34_23   block_pair_neg_226  1
    a_34_23   full_original_Gini_234  -1
    a_29_27   block_pair_pos_221  1
    a_29_27   block_pair_neg_222  1
    a_29_27   full_original_Gini_234  -1
    a_29_22   block_pair_pos_215  1
    a_29_22   block_pair_neg_216  1
    a_29_22   full_original_Gini_234  -1
    a_29_25   block_pair_pos_219  1
    a_29_25   block_pair_neg_220  1
    a_29_25   full_original_Gini_234  -1
    a_29_23   block_pair_pos_217  1
    a_29_23   block_pair_neg_218  1
    a_29_23   full_original_Gini_234  -1
    a_27_22   block_pair_pos_197  1
    a_27_22   block_pair_neg_198  1
    a_27_22   full_original_Gini_234  -1
    a_27_25   block_pair_pos_201  1
    a_27_25   block_pair_neg_202  1
    a_27_25   full_original_Gini_234  -1
    a_27_23   block_pair_pos_199  1
    a_27_23   block_pair_neg_200  1
    a_27_23   full_original_Gini_234  -1
    a_22_25   block_pair_pos_179  1
    a_22_25   block_pair_neg_180  1
    a_22_25   full_original_Gini_234  -1
    a_22_23   block_pair_pos_177  1
    a_22_23   block_pair_neg_178  1
    a_22_23   full_original_Gini_234  -1
    a_25_23   block_pair_pos_181  1
    a_25_23   block_pair_neg_182  1
    a_25_23   full_original_Gini_234  -1
    MARKER    'MARKER'                 'INTORG'
    service_0_26_0  unique_nonzero_owner_235  1
    service_0_26_0  service_visit_def_625  1
    service_0_26_0  free_load_conservation_626  -5
    service_0_26_0  original_T_including_depot_unload_672  600
    service_0_26_1  unique_nonzero_owner_236  1
    service_0_26_1  service_visit_def_625  1
    service_0_26_1  free_load_conservation_626  -4
    service_0_26_1  original_T_including_depot_unload_672  480
    service_0_26_2  unique_nonzero_owner_237  1
    service_0_26_2  service_visit_def_625  1
    service_0_26_2  free_load_conservation_626  -3
    service_0_26_2  original_T_including_depot_unload_672  360
    service_0_26_3  unique_nonzero_owner_238  1
    service_0_26_3  service_visit_def_625  1
    service_0_26_3  free_load_conservation_626  -2
    service_0_26_3  original_T_including_depot_unload_672  240
    service_0_26_4  unique_nonzero_owner_239  1
    service_0_26_4  service_visit_def_625  1
    service_0_26_4  free_load_conservation_626  -1
    service_0_26_4  original_T_including_depot_unload_672  120
    service_0_26_6  unique_nonzero_owner_240  1
    service_0_26_6  service_visit_def_625  1
    service_0_26_6  free_load_conservation_626  1
    service_0_26_7  unique_nonzero_owner_241  1
    service_0_26_7  service_visit_def_625  1
    service_0_26_7  free_load_conservation_626  2
    service_0_26_8  unique_nonzero_owner_242  1
    service_0_26_8  service_visit_def_625  1
    service_0_26_8  free_load_conservation_626  3
    service_1_26_0  unique_nonzero_owner_235  1
    service_1_26_0  service_visit_def_996  1
    service_1_26_0  free_load_conservation_997  -5
    service_1_26_0  original_T_including_depot_unload_1043  600
    service_1_26_1  unique_nonzero_owner_236  1
    service_1_26_1  service_visit_def_996  1
    service_1_26_1  free_load_conservation_997  -4
    service_1_26_1  original_T_including_depot_unload_1043  480
    service_1_26_2  unique_nonzero_owner_237  1
    service_1_26_2  service_visit_def_996  1
    service_1_26_2  free_load_conservation_997  -3
    service_1_26_2  original_T_including_depot_unload_1043  360
    service_1_26_3  unique_nonzero_owner_238  1
    service_1_26_3  service_visit_def_996  1
    service_1_26_3  free_load_conservation_997  -2
    service_1_26_3  original_T_including_depot_unload_1043  240
    service_1_26_4  unique_nonzero_owner_239  1
    service_1_26_4  service_visit_def_996  1
    service_1_26_4  free_load_conservation_997  -1
    service_1_26_4  original_T_including_depot_unload_1043  120
    service_1_26_6  unique_nonzero_owner_240  1
    service_1_26_6  service_visit_def_996  1
    service_1_26_6  free_load_conservation_997  1
    service_1_26_7  unique_nonzero_owner_241  1
    service_1_26_7  service_visit_def_996  1
    service_1_26_7  free_load_conservation_997  2
    service_1_26_8  unique_nonzero_owner_242  1
    service_1_26_8  service_visit_def_996  1
    service_1_26_8  free_load_conservation_997  3
    service_2_26_0  unique_nonzero_owner_235  1
    service_2_26_0  service_visit_def_1314  1
    service_2_26_0  free_load_conservation_1315  -5
    service_2_26_0  original_T_including_depot_unload_1360  600
    service_2_26_1  unique_nonzero_owner_236  1
    service_2_26_1  service_visit_def_1314  1
    service_2_26_1  free_load_conservation_1315  -4
    service_2_26_1  original_T_including_depot_unload_1360  480
    service_2_26_2  unique_nonzero_owner_237  1
    service_2_26_2  service_visit_def_1314  1
    service_2_26_2  free_load_conservation_1315  -3
    service_2_26_2  original_T_including_depot_unload_1360  360
    service_2_26_3  unique_nonzero_owner_238  1
    service_2_26_3  service_visit_def_1314  1
    service_2_26_3  free_load_conservation_1315  -2
    service_2_26_3  original_T_including_depot_unload_1360  240
    service_2_26_4  unique_nonzero_owner_239  1
    service_2_26_4  service_visit_def_1314  1
    service_2_26_4  free_load_conservation_1315  -1
    service_2_26_4  original_T_including_depot_unload_1360  120
    service_2_26_6  unique_nonzero_owner_240  1
    service_2_26_6  service_visit_def_1314  1
    service_2_26_6  free_load_conservation_1315  1
    service_2_26_7  unique_nonzero_owner_241  1
    service_2_26_7  service_visit_def_1314  1
    service_2_26_7  free_load_conservation_1315  2
    service_2_26_8  unique_nonzero_owner_242  1
    service_2_26_8  service_visit_def_1314  1
    service_2_26_8  free_load_conservation_1315  3
    service_0_28_0  unique_nonzero_owner_243  1
    service_0_28_0  service_visit_def_631  1
    service_0_28_0  free_load_conservation_632  -1
    service_0_28_0  original_T_including_depot_unload_672  120
    service_0_28_2  unique_nonzero_owner_244  1
    service_0_28_2  service_visit_def_631  1
    service_0_28_2  free_load_conservation_632  1
    service_0_28_3  unique_nonzero_owner_245  1
    service_0_28_3  service_visit_def_631  1
    service_0_28_3  free_load_conservation_632  2
    service_0_28_4  unique_nonzero_owner_246  1
    service_0_28_4  service_visit_def_631  1
    service_0_28_4  free_load_conservation_632  3
    service_0_28_5  unique_nonzero_owner_247  1
    service_0_28_5  service_visit_def_631  1
    service_0_28_5  free_load_conservation_632  4
    service_0_28_6  unique_nonzero_owner_248  1
    service_0_28_6  service_visit_def_631  1
    service_0_28_6  free_load_conservation_632  5
    service_1_28_0  unique_nonzero_owner_243  1
    service_1_28_0  service_visit_def_1002  1
    service_1_28_0  free_load_conservation_1003  -1
    service_1_28_0  original_T_including_depot_unload_1043  120
    service_1_28_2  unique_nonzero_owner_244  1
    service_1_28_2  service_visit_def_1002  1
    service_1_28_2  free_load_conservation_1003  1
    service_1_28_3  unique_nonzero_owner_245  1
    service_1_28_3  service_visit_def_1002  1
    service_1_28_3  free_load_conservation_1003  2
    service_1_28_4  unique_nonzero_owner_246  1
    service_1_28_4  service_visit_def_1002  1
    service_1_28_4  free_load_conservation_1003  3
    service_1_28_5  unique_nonzero_owner_247  1
    service_1_28_5  service_visit_def_1002  1
    service_1_28_5  free_load_conservation_1003  4
    service_1_28_6  unique_nonzero_owner_248  1
    service_1_28_6  service_visit_def_1002  1
    service_1_28_6  free_load_conservation_1003  5
    service_2_28_0  unique_nonzero_owner_243  1
    service_2_28_0  service_visit_def_1320  1
    service_2_28_0  free_load_conservation_1321  -1
    service_2_28_0  original_T_including_depot_unload_1360  120
    service_2_28_2  unique_nonzero_owner_244  1
    service_2_28_2  service_visit_def_1320  1
    service_2_28_2  free_load_conservation_1321  1
    service_2_28_3  unique_nonzero_owner_245  1
    service_2_28_3  service_visit_def_1320  1
    service_2_28_3  free_load_conservation_1321  2
    service_2_28_4  unique_nonzero_owner_246  1
    service_2_28_4  service_visit_def_1320  1
    service_2_28_4  free_load_conservation_1321  3
    service_2_28_5  unique_nonzero_owner_247  1
    service_2_28_5  service_visit_def_1320  1
    service_2_28_5  free_load_conservation_1321  4
    service_2_28_6  unique_nonzero_owner_248  1
    service_2_28_6  service_visit_def_1320  1
    service_2_28_6  free_load_conservation_1321  5
    service_0_34_0  unique_nonzero_owner_249  1
    service_0_34_0  service_visit_def_637  1
    service_0_34_0  free_load_conservation_638  -2
    service_0_34_0  original_T_including_depot_unload_672  240
    service_0_34_1  unique_nonzero_owner_250  1
    service_0_34_1  service_visit_def_637  1
    service_0_34_1  free_load_conservation_638  -1
    service_0_34_1  original_T_including_depot_unload_672  120
    service_0_34_3  unique_nonzero_owner_251  1
    service_0_34_3  service_visit_def_637  1
    service_0_34_3  free_load_conservation_638  1
    service_0_34_4  unique_nonzero_owner_252  1
    service_0_34_4  service_visit_def_637  1
    service_0_34_4  free_load_conservation_638  2
    service_0_34_5  unique_nonzero_owner_253  1
    service_0_34_5  service_visit_def_637  1
    service_0_34_5  free_load_conservation_638  3
    service_0_34_6  unique_nonzero_owner_254  1
    service_0_34_6  service_visit_def_637  1
    service_0_34_6  free_load_conservation_638  4
    service_0_34_7  unique_nonzero_owner_255  1
    service_0_34_7  service_visit_def_637  1
    service_0_34_7  free_load_conservation_638  5
    service_0_34_8  unique_nonzero_owner_256  1
    service_0_34_8  service_visit_def_637  1
    service_0_34_8  free_load_conservation_638  6
    service_0_34_9  unique_nonzero_owner_257  1
    service_0_34_9  service_visit_def_637  1
    service_0_34_9  free_load_conservation_638  7
    service_0_34_10  unique_nonzero_owner_258  1
    service_0_34_10  service_visit_def_637  1
    service_0_34_10  free_load_conservation_638  8
    service_0_34_11  unique_nonzero_owner_259  1
    service_0_34_11  service_visit_def_637  1
    service_0_34_11  free_load_conservation_638  9
    service_0_34_12  unique_nonzero_owner_260  1
    service_0_34_12  service_visit_def_637  1
    service_0_34_12  free_load_conservation_638  10
    service_0_34_13  unique_nonzero_owner_261  1
    service_0_34_13  service_visit_def_637  1
    service_0_34_13  free_load_conservation_638  11
    service_0_34_14  unique_nonzero_owner_262  1
    service_0_34_14  service_visit_def_637  1
    service_0_34_14  free_load_conservation_638  12
    service_0_34_15  unique_nonzero_owner_263  1
    service_0_34_15  service_visit_def_637  1
    service_0_34_15  free_load_conservation_638  13
    service_1_34_0  unique_nonzero_owner_249  1
    service_1_34_0  service_visit_def_1008  1
    service_1_34_0  free_load_conservation_1009  -2
    service_1_34_0  original_T_including_depot_unload_1043  240
    service_1_34_1  unique_nonzero_owner_250  1
    service_1_34_1  service_visit_def_1008  1
    service_1_34_1  free_load_conservation_1009  -1
    service_1_34_1  original_T_including_depot_unload_1043  120
    service_1_34_3  unique_nonzero_owner_251  1
    service_1_34_3  service_visit_def_1008  1
    service_1_34_3  free_load_conservation_1009  1
    service_1_34_4  unique_nonzero_owner_252  1
    service_1_34_4  service_visit_def_1008  1
    service_1_34_4  free_load_conservation_1009  2
    service_1_34_5  unique_nonzero_owner_253  1
    service_1_34_5  service_visit_def_1008  1
    service_1_34_5  free_load_conservation_1009  3
    service_1_34_6  unique_nonzero_owner_254  1
    service_1_34_6  service_visit_def_1008  1
    service_1_34_6  free_load_conservation_1009  4
    service_1_34_7  unique_nonzero_owner_255  1
    service_1_34_7  service_visit_def_1008  1
    service_1_34_7  free_load_conservation_1009  5
    service_1_34_8  unique_nonzero_owner_256  1
    service_1_34_8  service_visit_def_1008  1
    service_1_34_8  free_load_conservation_1009  6
    service_1_34_9  unique_nonzero_owner_257  1
    service_1_34_9  service_visit_def_1008  1
    service_1_34_9  free_load_conservation_1009  7
    service_1_34_10  unique_nonzero_owner_258  1
    service_1_34_10  service_visit_def_1008  1
    service_1_34_10  free_load_conservation_1009  8
    service_1_34_11  unique_nonzero_owner_259  1
    service_1_34_11  service_visit_def_1008  1
    service_1_34_11  free_load_conservation_1009  9
    service_1_34_12  unique_nonzero_owner_260  1
    service_1_34_12  service_visit_def_1008  1
    service_1_34_12  free_load_conservation_1009  10
    service_1_34_13  unique_nonzero_owner_261  1
    service_1_34_13  service_visit_def_1008  1
    service_1_34_13  free_load_conservation_1009  11
    service_1_34_14  unique_nonzero_owner_262  1
    service_1_34_14  service_visit_def_1008  1
    service_1_34_14  free_load_conservation_1009  12
    service_1_34_15  unique_nonzero_owner_263  1
    service_1_34_15  service_visit_def_1008  1
    service_1_34_15  free_load_conservation_1009  13
    service_2_34_0  unique_nonzero_owner_249  1
    service_2_34_0  service_visit_def_1326  1
    service_2_34_0  free_load_conservation_1327  -2
    service_2_34_0  original_T_including_depot_unload_1360  240
    service_2_34_1  unique_nonzero_owner_250  1
    service_2_34_1  service_visit_def_1326  1
    service_2_34_1  free_load_conservation_1327  -1
    service_2_34_1  original_T_including_depot_unload_1360  120
    service_2_34_3  unique_nonzero_owner_251  1
    service_2_34_3  service_visit_def_1326  1
    service_2_34_3  free_load_conservation_1327  1
    service_2_34_4  unique_nonzero_owner_252  1
    service_2_34_4  service_visit_def_1326  1
    service_2_34_4  free_load_conservation_1327  2
    service_2_34_5  unique_nonzero_owner_253  1
    service_2_34_5  service_visit_def_1326  1
    service_2_34_5  free_load_conservation_1327  3
    service_2_34_6  unique_nonzero_owner_254  1
    service_2_34_6  service_visit_def_1326  1
    service_2_34_6  free_load_conservation_1327  4
    service_2_34_7  unique_nonzero_owner_255  1
    service_2_34_7  service_visit_def_1326  1
    service_2_34_7  free_load_conservation_1327  5
    service_2_34_8  unique_nonzero_owner_256  1
    service_2_34_8  service_visit_def_1326  1
    service_2_34_8  free_load_conservation_1327  6
    service_2_34_9  unique_nonzero_owner_257  1
    service_2_34_9  service_visit_def_1326  1
    service_2_34_9  free_load_conservation_1327  7
    service_2_34_10  unique_nonzero_owner_258  1
    service_2_34_10  service_visit_def_1326  1
    service_2_34_10  free_load_conservation_1327  8
    service_2_34_11  unique_nonzero_owner_259  1
    service_2_34_11  service_visit_def_1326  1
    service_2_34_11  free_load_conservation_1327  9
    service_2_34_12  unique_nonzero_owner_260  1
    service_2_34_12  service_visit_def_1326  1
    service_2_34_12  free_load_conservation_1327  10
    service_2_34_13  unique_nonzero_owner_261  1
    service_2_34_13  service_visit_def_1326  1
    service_2_34_13  free_load_conservation_1327  11
    service_2_34_14  unique_nonzero_owner_262  1
    service_2_34_14  service_visit_def_1326  1
    service_2_34_14  free_load_conservation_1327  12
    service_2_34_15  unique_nonzero_owner_263  1
    service_2_34_15  service_visit_def_1326  1
    service_2_34_15  free_load_conservation_1327  13
    service_0_29_0  unique_nonzero_owner_264  1
    service_0_29_0  service_visit_def_643  1
    service_0_29_0  free_load_conservation_644  -1
    service_0_29_0  original_T_including_depot_unload_672  120
    service_0_29_2  unique_nonzero_owner_265  1
    service_0_29_2  service_visit_def_643  1
    service_0_29_2  free_load_conservation_644  1
    service_0_29_3  unique_nonzero_owner_266  1
    service_0_29_3  service_visit_def_643  1
    service_0_29_3  free_load_conservation_644  2
    service_0_29_4  unique_nonzero_owner_267  1
    service_0_29_4  service_visit_def_643  1
    service_0_29_4  free_load_conservation_644  3
    service_0_29_5  unique_nonzero_owner_268  1
    service_0_29_5  service_visit_def_643  1
    service_0_29_5  free_load_conservation_644  4
    service_0_29_6  unique_nonzero_owner_269  1
    service_0_29_6  service_visit_def_643  1
    service_0_29_6  free_load_conservation_644  5
    service_0_29_7  unique_nonzero_owner_270  1
    service_0_29_7  service_visit_def_643  1
    service_0_29_7  free_load_conservation_644  6
    service_0_29_8  unique_nonzero_owner_271  1
    service_0_29_8  service_visit_def_643  1
    service_0_29_8  free_load_conservation_644  7
    service_0_29_9  unique_nonzero_owner_272  1
    service_0_29_9  service_visit_def_643  1
    service_0_29_9  free_load_conservation_644  8
    service_0_29_10  unique_nonzero_owner_273  1
    service_0_29_10  service_visit_def_643  1
    service_0_29_10  free_load_conservation_644  9
    service_1_29_0  unique_nonzero_owner_264  1
    service_1_29_0  service_visit_def_1014  1
    service_1_29_0  free_load_conservation_1015  -1
    service_1_29_0  original_T_including_depot_unload_1043  120
    service_1_29_2  unique_nonzero_owner_265  1
    service_1_29_2  service_visit_def_1014  1
    service_1_29_2  free_load_conservation_1015  1
    service_1_29_3  unique_nonzero_owner_266  1
    service_1_29_3  service_visit_def_1014  1
    service_1_29_3  free_load_conservation_1015  2
    service_1_29_4  unique_nonzero_owner_267  1
    service_1_29_4  service_visit_def_1014  1
    service_1_29_4  free_load_conservation_1015  3
    service_1_29_5  unique_nonzero_owner_268  1
    service_1_29_5  service_visit_def_1014  1
    service_1_29_5  free_load_conservation_1015  4
    service_1_29_6  unique_nonzero_owner_269  1
    service_1_29_6  service_visit_def_1014  1
    service_1_29_6  free_load_conservation_1015  5
    service_1_29_7  unique_nonzero_owner_270  1
    service_1_29_7  service_visit_def_1014  1
    service_1_29_7  free_load_conservation_1015  6
    service_1_29_8  unique_nonzero_owner_271  1
    service_1_29_8  service_visit_def_1014  1
    service_1_29_8  free_load_conservation_1015  7
    service_1_29_9  unique_nonzero_owner_272  1
    service_1_29_9  service_visit_def_1014  1
    service_1_29_9  free_load_conservation_1015  8
    service_1_29_10  unique_nonzero_owner_273  1
    service_1_29_10  service_visit_def_1014  1
    service_1_29_10  free_load_conservation_1015  9
    service_2_29_0  unique_nonzero_owner_264  1
    service_2_29_0  service_visit_def_1332  1
    service_2_29_0  free_load_conservation_1333  -1
    service_2_29_0  original_T_including_depot_unload_1360  120
    service_2_29_2  unique_nonzero_owner_265  1
    service_2_29_2  service_visit_def_1332  1
    service_2_29_2  free_load_conservation_1333  1
    service_2_29_3  unique_nonzero_owner_266  1
    service_2_29_3  service_visit_def_1332  1
    service_2_29_3  free_load_conservation_1333  2
    service_2_29_4  unique_nonzero_owner_267  1
    service_2_29_4  service_visit_def_1332  1
    service_2_29_4  free_load_conservation_1333  3
    service_2_29_5  unique_nonzero_owner_268  1
    service_2_29_5  service_visit_def_1332  1
    service_2_29_5  free_load_conservation_1333  4
    service_2_29_6  unique_nonzero_owner_269  1
    service_2_29_6  service_visit_def_1332  1
    service_2_29_6  free_load_conservation_1333  5
    service_2_29_7  unique_nonzero_owner_270  1
    service_2_29_7  service_visit_def_1332  1
    service_2_29_7  free_load_conservation_1333  6
    service_2_29_8  unique_nonzero_owner_271  1
    service_2_29_8  service_visit_def_1332  1
    service_2_29_8  free_load_conservation_1333  7
    service_2_29_9  unique_nonzero_owner_272  1
    service_2_29_9  service_visit_def_1332  1
    service_2_29_9  free_load_conservation_1333  8
    service_2_29_10  unique_nonzero_owner_273  1
    service_2_29_10  service_visit_def_1332  1
    service_2_29_10  free_load_conservation_1333  9
    service_0_27_1  unique_nonzero_owner_274  1
    service_0_27_1  service_visit_def_649  1
    service_0_27_1  free_load_conservation_650  1
    service_0_27_2  unique_nonzero_owner_275  1
    service_0_27_2  service_visit_def_649  1
    service_0_27_2  free_load_conservation_650  2
    service_0_27_3  unique_nonzero_owner_276  1
    service_0_27_3  service_visit_def_649  1
    service_0_27_3  free_load_conservation_650  3
    service_0_27_4  unique_nonzero_owner_277  1
    service_0_27_4  service_visit_def_649  1
    service_0_27_4  free_load_conservation_650  4
    service_0_27_5  unique_nonzero_owner_278  1
    service_0_27_5  service_visit_def_649  1
    service_0_27_5  free_load_conservation_650  5
    service_0_27_6  unique_nonzero_owner_279  1
    service_0_27_6  service_visit_def_649  1
    service_0_27_6  free_load_conservation_650  6
    service_1_27_1  unique_nonzero_owner_274  1
    service_1_27_1  service_visit_def_1020  1
    service_1_27_1  free_load_conservation_1021  1
    service_1_27_2  unique_nonzero_owner_275  1
    service_1_27_2  service_visit_def_1020  1
    service_1_27_2  free_load_conservation_1021  2
    service_1_27_3  unique_nonzero_owner_276  1
    service_1_27_3  service_visit_def_1020  1
    service_1_27_3  free_load_conservation_1021  3
    service_1_27_4  unique_nonzero_owner_277  1
    service_1_27_4  service_visit_def_1020  1
    service_1_27_4  free_load_conservation_1021  4
    service_1_27_5  unique_nonzero_owner_278  1
    service_1_27_5  service_visit_def_1020  1
    service_1_27_5  free_load_conservation_1021  5
    service_1_27_6  unique_nonzero_owner_279  1
    service_1_27_6  service_visit_def_1020  1
    service_1_27_6  free_load_conservation_1021  6
    service_2_27_1  unique_nonzero_owner_274  1
    service_2_27_1  service_visit_def_1338  1
    service_2_27_1  free_load_conservation_1339  1
    service_2_27_2  unique_nonzero_owner_275  1
    service_2_27_2  service_visit_def_1338  1
    service_2_27_2  free_load_conservation_1339  2
    service_2_27_3  unique_nonzero_owner_276  1
    service_2_27_3  service_visit_def_1338  1
    service_2_27_3  free_load_conservation_1339  3
    service_2_27_4  unique_nonzero_owner_277  1
    service_2_27_4  service_visit_def_1338  1
    service_2_27_4  free_load_conservation_1339  4
    service_2_27_5  unique_nonzero_owner_278  1
    service_2_27_5  service_visit_def_1338  1
    service_2_27_5  free_load_conservation_1339  5
    service_2_27_6  unique_nonzero_owner_279  1
    service_2_27_6  service_visit_def_1338  1
    service_2_27_6  free_load_conservation_1339  6
    service_0_22_0  unique_nonzero_owner_280  1
    service_0_22_0  service_visit_def_655  1
    service_0_22_0  free_load_conservation_656  -2
    service_0_22_0  original_T_including_depot_unload_672  240
    service_0_22_1  unique_nonzero_owner_281  1
    service_0_22_1  service_visit_def_655  1
    service_0_22_1  free_load_conservation_656  -1
    service_0_22_1  original_T_including_depot_unload_672  120
    service_0_22_3  unique_nonzero_owner_282  1
    service_0_22_3  service_visit_def_655  1
    service_0_22_3  free_load_conservation_656  1
    service_0_22_4  unique_nonzero_owner_283  1
    service_0_22_4  service_visit_def_655  1
    service_0_22_4  free_load_conservation_656  2
    service_0_22_5  unique_nonzero_owner_284  1
    service_0_22_5  service_visit_def_655  1
    service_0_22_5  free_load_conservation_656  3
    service_0_22_6  unique_nonzero_owner_285  1
    service_0_22_6  service_visit_def_655  1
    service_0_22_6  free_load_conservation_656  4
    service_0_22_7  unique_nonzero_owner_286  1
    service_0_22_7  service_visit_def_655  1
    service_0_22_7  free_load_conservation_656  5
    service_0_22_8  unique_nonzero_owner_287  1
    service_0_22_8  service_visit_def_655  1
    service_0_22_8  free_load_conservation_656  6
    service_0_22_9  unique_nonzero_owner_288  1
    service_0_22_9  service_visit_def_655  1
    service_0_22_9  free_load_conservation_656  7
    service_0_22_10  unique_nonzero_owner_289  1
    service_0_22_10  service_visit_def_655  1
    service_0_22_10  free_load_conservation_656  8
    service_0_22_11  unique_nonzero_owner_290  1
    service_0_22_11  service_visit_def_655  1
    service_0_22_11  free_load_conservation_656  9
    service_0_22_12  unique_nonzero_owner_291  1
    service_0_22_12  service_visit_def_655  1
    service_0_22_12  free_load_conservation_656  10
    service_0_22_13  unique_nonzero_owner_292  1
    service_0_22_13  service_visit_def_655  1
    service_0_22_13  free_load_conservation_656  11
    service_0_22_14  unique_nonzero_owner_293  1
    service_0_22_14  service_visit_def_655  1
    service_0_22_14  free_load_conservation_656  12
    service_0_22_15  unique_nonzero_owner_294  1
    service_0_22_15  service_visit_def_655  1
    service_0_22_15  free_load_conservation_656  13
    service_1_22_0  unique_nonzero_owner_280  1
    service_1_22_0  service_visit_def_1026  1
    service_1_22_0  free_load_conservation_1027  -2
    service_1_22_0  original_T_including_depot_unload_1043  240
    service_1_22_1  unique_nonzero_owner_281  1
    service_1_22_1  service_visit_def_1026  1
    service_1_22_1  free_load_conservation_1027  -1
    service_1_22_1  original_T_including_depot_unload_1043  120
    service_1_22_3  unique_nonzero_owner_282  1
    service_1_22_3  service_visit_def_1026  1
    service_1_22_3  free_load_conservation_1027  1
    service_1_22_4  unique_nonzero_owner_283  1
    service_1_22_4  service_visit_def_1026  1
    service_1_22_4  free_load_conservation_1027  2
    service_1_22_5  unique_nonzero_owner_284  1
    service_1_22_5  service_visit_def_1026  1
    service_1_22_5  free_load_conservation_1027  3
    service_1_22_6  unique_nonzero_owner_285  1
    service_1_22_6  service_visit_def_1026  1
    service_1_22_6  free_load_conservation_1027  4
    service_1_22_7  unique_nonzero_owner_286  1
    service_1_22_7  service_visit_def_1026  1
    service_1_22_7  free_load_conservation_1027  5
    service_1_22_8  unique_nonzero_owner_287  1
    service_1_22_8  service_visit_def_1026  1
    service_1_22_8  free_load_conservation_1027  6
    service_1_22_9  unique_nonzero_owner_288  1
    service_1_22_9  service_visit_def_1026  1
    service_1_22_9  free_load_conservation_1027  7
    service_1_22_10  unique_nonzero_owner_289  1
    service_1_22_10  service_visit_def_1026  1
    service_1_22_10  free_load_conservation_1027  8
    service_1_22_11  unique_nonzero_owner_290  1
    service_1_22_11  service_visit_def_1026  1
    service_1_22_11  free_load_conservation_1027  9
    service_1_22_12  unique_nonzero_owner_291  1
    service_1_22_12  service_visit_def_1026  1
    service_1_22_12  free_load_conservation_1027  10
    service_1_22_13  unique_nonzero_owner_292  1
    service_1_22_13  service_visit_def_1026  1
    service_1_22_13  free_load_conservation_1027  11
    service_1_22_14  unique_nonzero_owner_293  1
    service_1_22_14  service_visit_def_1026  1
    service_1_22_14  free_load_conservation_1027  12
    service_1_22_15  unique_nonzero_owner_294  1
    service_1_22_15  service_visit_def_1026  1
    service_1_22_15  free_load_conservation_1027  13
    service_2_22_0  unique_nonzero_owner_280  1
    service_2_22_0  service_visit_def_1344  1
    service_2_22_0  free_load_conservation_1345  -2
    service_2_22_0  original_T_including_depot_unload_1360  240
    service_2_22_1  unique_nonzero_owner_281  1
    service_2_22_1  service_visit_def_1344  1
    service_2_22_1  free_load_conservation_1345  -1
    service_2_22_1  original_T_including_depot_unload_1360  120
    service_2_22_3  unique_nonzero_owner_282  1
    service_2_22_3  service_visit_def_1344  1
    service_2_22_3  free_load_conservation_1345  1
    service_2_22_4  unique_nonzero_owner_283  1
    service_2_22_4  service_visit_def_1344  1
    service_2_22_4  free_load_conservation_1345  2
    service_2_22_5  unique_nonzero_owner_284  1
    service_2_22_5  service_visit_def_1344  1
    service_2_22_5  free_load_conservation_1345  3
    service_2_22_6  unique_nonzero_owner_285  1
    service_2_22_6  service_visit_def_1344  1
    service_2_22_6  free_load_conservation_1345  4
    service_2_22_7  unique_nonzero_owner_286  1
    service_2_22_7  service_visit_def_1344  1
    service_2_22_7  free_load_conservation_1345  5
    service_2_22_8  unique_nonzero_owner_287  1
    service_2_22_8  service_visit_def_1344  1
    service_2_22_8  free_load_conservation_1345  6
    service_2_22_9  unique_nonzero_owner_288  1
    service_2_22_9  service_visit_def_1344  1
    service_2_22_9  free_load_conservation_1345  7
    service_2_22_10  unique_nonzero_owner_289  1
    service_2_22_10  service_visit_def_1344  1
    service_2_22_10  free_load_conservation_1345  8
    service_2_22_11  unique_nonzero_owner_290  1
    service_2_22_11  service_visit_def_1344  1
    service_2_22_11  free_load_conservation_1345  9
    service_2_22_12  unique_nonzero_owner_291  1
    service_2_22_12  service_visit_def_1344  1
    service_2_22_12  free_load_conservation_1345  10
    service_2_22_13  unique_nonzero_owner_292  1
    service_2_22_13  service_visit_def_1344  1
    service_2_22_13  free_load_conservation_1345  11
    service_2_22_14  unique_nonzero_owner_293  1
    service_2_22_14  service_visit_def_1344  1
    service_2_22_14  free_load_conservation_1345  12
    service_2_22_15  unique_nonzero_owner_294  1
    service_2_22_15  service_visit_def_1344  1
    service_2_22_15  free_load_conservation_1345  13
    service_0_25_1  unique_nonzero_owner_295  1
    service_0_25_1  service_visit_def_661  1
    service_0_25_1  free_load_conservation_662  1
    service_0_25_2  unique_nonzero_owner_296  1
    service_0_25_2  service_visit_def_661  1
    service_0_25_2  free_load_conservation_662  2
    service_0_25_3  unique_nonzero_owner_297  1
    service_0_25_3  service_visit_def_661  1
    service_0_25_3  free_load_conservation_662  3
    service_0_25_4  unique_nonzero_owner_298  1
    service_0_25_4  service_visit_def_661  1
    service_0_25_4  free_load_conservation_662  4
    service_1_25_1  unique_nonzero_owner_295  1
    service_1_25_1  service_visit_def_1032  1
    service_1_25_1  free_load_conservation_1033  1
    service_1_25_2  unique_nonzero_owner_296  1
    service_1_25_2  service_visit_def_1032  1
    service_1_25_2  free_load_conservation_1033  2
    service_1_25_3  unique_nonzero_owner_297  1
    service_1_25_3  service_visit_def_1032  1
    service_1_25_3  free_load_conservation_1033  3
    service_1_25_4  unique_nonzero_owner_298  1
    service_1_25_4  service_visit_def_1032  1
    service_1_25_4  free_load_conservation_1033  4
    service_2_25_1  unique_nonzero_owner_295  1
    service_2_25_1  service_visit_def_1350  1
    service_2_25_1  free_load_conservation_1351  1
    service_2_25_2  unique_nonzero_owner_296  1
    service_2_25_2  service_visit_def_1350  1
    service_2_25_2  free_load_conservation_1351  2
    service_2_25_3  unique_nonzero_owner_297  1
    service_2_25_3  service_visit_def_1350  1
    service_2_25_3  free_load_conservation_1351  3
    service_2_25_4  unique_nonzero_owner_298  1
    service_2_25_4  service_visit_def_1350  1
    service_2_25_4  free_load_conservation_1351  4
    service_0_23_0  unique_nonzero_owner_299  1
    service_0_23_0  service_visit_def_667  1
    service_0_23_0  free_load_conservation_668  -1
    service_0_23_0  original_T_including_depot_unload_672  120
    service_0_23_2  unique_nonzero_owner_300  1
    service_0_23_2  service_visit_def_667  1
    service_0_23_2  free_load_conservation_668  1
    service_0_23_3  unique_nonzero_owner_301  1
    service_0_23_3  service_visit_def_667  1
    service_0_23_3  free_load_conservation_668  2
    service_1_23_0  unique_nonzero_owner_299  1
    service_1_23_0  service_visit_def_1038  1
    service_1_23_0  free_load_conservation_1039  -1
    service_1_23_0  original_T_including_depot_unload_1043  120
    service_1_23_2  unique_nonzero_owner_300  1
    service_1_23_2  service_visit_def_1038  1
    service_1_23_2  free_load_conservation_1039  1
    service_1_23_3  unique_nonzero_owner_301  1
    service_1_23_3  service_visit_def_1038  1
    service_1_23_3  free_load_conservation_1039  2
    service_2_23_0  unique_nonzero_owner_299  1
    service_2_23_0  service_visit_def_1356  1
    service_2_23_0  free_load_conservation_1357  -1
    service_2_23_0  original_T_including_depot_unload_1360  120
    service_2_23_2  unique_nonzero_owner_300  1
    service_2_23_2  service_visit_def_1356  1
    service_2_23_2  free_load_conservation_1357  1
    service_2_23_3  unique_nonzero_owner_301  1
    service_2_23_3  service_visit_def_1356  1
    service_2_23_3  free_load_conservation_1357  2
    MARKER    'MARKER'                 'INTEND'
    visit_0_1  out_degree_593  -1
    visit_0_1  in_degree_594  -1
    visit_0_1  order_active_lb_595  -1
    visit_0_1  order_active_ub_596  -12
    order_0_1  connected_order_arc_317  -1
    order_0_1  connected_order_arc_319  -1
    order_0_1  connected_order_arc_321  -1
    order_0_1  connected_order_arc_323  -1
    order_0_1  connected_order_arc_325  -1
    order_0_1  connected_order_arc_327  -1
    order_0_1  connected_order_arc_329  -1
    order_0_1  connected_order_arc_331  -1
    order_0_1  connected_order_arc_333  -1
    order_0_1  connected_order_arc_335  -1
    order_0_1  connected_order_arc_337  -1
    order_0_1  connected_order_arc_340  1
    order_0_1  connected_order_arc_363  1
    order_0_1  connected_order_arc_386  1
    order_0_1  connected_order_arc_409  1
    order_0_1  connected_order_arc_432  1
    order_0_1  connected_order_arc_455  1
    order_0_1  connected_order_arc_478  1
    order_0_1  connected_order_arc_501  1
    order_0_1  connected_order_arc_524  1
    order_0_1  connected_order_arc_547  1
    order_0_1  connected_order_arc_570  1
    order_0_1  order_active_lb_595  1
    order_0_1  order_active_ub_596  1
    order_0_1  fixed_segment_relative_order_669  -1
    visit_0_2  out_degree_600  -1
    visit_0_2  in_degree_601  -1
    visit_0_2  order_active_lb_602  -1
    visit_0_2  order_active_ub_603  -12
    order_0_2  connected_order_arc_317  1
    order_0_2  connected_order_arc_340  -1
    order_0_2  connected_order_arc_342  -1
    order_0_2  connected_order_arc_344  -1
    order_0_2  connected_order_arc_346  -1
    order_0_2  connected_order_arc_348  -1
    order_0_2  connected_order_arc_350  -1
    order_0_2  connected_order_arc_352  -1
    order_0_2  connected_order_arc_354  -1
    order_0_2  connected_order_arc_356  -1
    order_0_2  connected_order_arc_358  -1
    order_0_2  connected_order_arc_360  -1
    order_0_2  connected_order_arc_365  1
    order_0_2  connected_order_arc_388  1
    order_0_2  connected_order_arc_411  1
    order_0_2  connected_order_arc_434  1
    order_0_2  connected_order_arc_457  1
    order_0_2  connected_order_arc_480  1
    order_0_2  connected_order_arc_503  1
    order_0_2  connected_order_arc_526  1
    order_0_2  connected_order_arc_549  1
    order_0_2  connected_order_arc_572  1
    order_0_2  order_active_lb_602  1
    order_0_2  order_active_ub_603  1
    order_0_2  fixed_segment_relative_order_669  1
    order_0_2  fixed_segment_relative_order_670  -1
    visit_0_3  out_degree_607  -1
    visit_0_3  in_degree_608  -1
    visit_0_3  order_active_lb_609  -1
    visit_0_3  order_active_ub_610  -12
    order_0_3  connected_order_arc_319  1
    order_0_3  connected_order_arc_342  1
    order_0_3  connected_order_arc_363  -1
    order_0_3  connected_order_arc_365  -1
    order_0_3  connected_order_arc_367  -1
    order_0_3  connected_order_arc_369  -1
    order_0_3  connected_order_arc_371  -1
    order_0_3  connected_order_arc_373  -1
    order_0_3  connected_order_arc_375  -1
    order_0_3  connected_order_arc_377  -1
    order_0_3  connected_order_arc_379  -1
    order_0_3  connected_order_arc_381  -1
    order_0_3  connected_order_arc_383  -1
    order_0_3  connected_order_arc_390  1
    order_0_3  connected_order_arc_413  1
    order_0_3  connected_order_arc_436  1
    order_0_3  connected_order_arc_459  1
    order_0_3  connected_order_arc_482  1
    order_0_3  connected_order_arc_505  1
    order_0_3  connected_order_arc_528  1
    order_0_3  connected_order_arc_551  1
    order_0_3  connected_order_arc_574  1
    order_0_3  order_active_lb_609  1
    order_0_3  order_active_ub_610  1
    order_0_3  fixed_segment_relative_order_670  1
    order_0_3  fixed_segment_relative_order_671  -1
    visit_0_4  out_degree_614  -1
    visit_0_4  in_degree_615  -1
    visit_0_4  order_active_lb_616  -1
    visit_0_4  order_active_ub_617  -12
    order_0_4  connected_order_arc_321  1
    order_0_4  connected_order_arc_344  1
    order_0_4  connected_order_arc_367  1
    order_0_4  connected_order_arc_386  -1
    order_0_4  connected_order_arc_388  -1
    order_0_4  connected_order_arc_390  -1
    order_0_4  connected_order_arc_392  -1
    order_0_4  connected_order_arc_394  -1
    order_0_4  connected_order_arc_396  -1
    order_0_4  connected_order_arc_398  -1
    order_0_4  connected_order_arc_400  -1
    order_0_4  connected_order_arc_402  -1
    order_0_4  connected_order_arc_404  -1
    order_0_4  connected_order_arc_406  -1
    order_0_4  connected_order_arc_415  1
    order_0_4  connected_order_arc_438  1
    order_0_4  connected_order_arc_461  1
    order_0_4  connected_order_arc_484  1
    order_0_4  connected_order_arc_507  1
    order_0_4  connected_order_arc_530  1
    order_0_4  connected_order_arc_553  1
    order_0_4  connected_order_arc_576  1
    order_0_4  order_active_lb_616  1
    order_0_4  order_active_ub_617  1
    order_0_4  fixed_segment_relative_order_671  1
    visit_0_12  out_degree_621  -1
    visit_0_12  in_degree_622  -1
    visit_0_12  order_active_lb_623  -1
    visit_0_12  order_active_ub_624  -12
    visit_0_12  service_visit_def_625  -1
    order_0_12  connected_order_arc_323  1
    order_0_12  connected_order_arc_346  1
    order_0_12  connected_order_arc_369  1
    order_0_12  connected_order_arc_392  1
    order_0_12  connected_order_arc_409  -1
    order_0_12  connected_order_arc_411  -1
    order_0_12  connected_order_arc_413  -1
    order_0_12  connected_order_arc_415  -1
    order_0_12  connected_order_arc_417  -1
    order_0_12  connected_order_arc_419  -1
    order_0_12  connected_order_arc_421  -1
    order_0_12  connected_order_arc_423  -1
    order_0_12  connected_order_arc_425  -1
    order_0_12  connected_order_arc_427  -1
    order_0_12  connected_order_arc_429  -1
    order_0_12  connected_order_arc_440  1
    order_0_12  connected_order_arc_463  1
    order_0_12  connected_order_arc_486  1
    order_0_12  connected_order_arc_509  1
    order_0_12  connected_order_arc_532  1
    order_0_12  connected_order_arc_555  1
    order_0_12  connected_order_arc_578  1
    order_0_12  order_active_lb_623  1
    order_0_12  order_active_ub_624  1
    visit_0_13  out_degree_627  -1
    visit_0_13  in_degree_628  -1
    visit_0_13  order_active_lb_629  -1
    visit_0_13  order_active_ub_630  -12
    visit_0_13  service_visit_def_631  -1
    order_0_13  connected_order_arc_325  1
    order_0_13  connected_order_arc_348  1
    order_0_13  connected_order_arc_371  1
    order_0_13  connected_order_arc_394  1
    order_0_13  connected_order_arc_417  1
    order_0_13  connected_order_arc_432  -1
    order_0_13  connected_order_arc_434  -1
    order_0_13  connected_order_arc_436  -1
    order_0_13  connected_order_arc_438  -1
    order_0_13  connected_order_arc_440  -1
    order_0_13  connected_order_arc_442  -1
    order_0_13  connected_order_arc_444  -1
    order_0_13  connected_order_arc_446  -1
    order_0_13  connected_order_arc_448  -1
    order_0_13  connected_order_arc_450  -1
    order_0_13  connected_order_arc_452  -1
    order_0_13  connected_order_arc_465  1
    order_0_13  connected_order_arc_488  1
    order_0_13  connected_order_arc_511  1
    order_0_13  connected_order_arc_534  1
    order_0_13  connected_order_arc_557  1
    order_0_13  connected_order_arc_580  1
    order_0_13  order_active_lb_629  1
    order_0_13  order_active_ub_630  1
    visit_0_14  out_degree_633  -1
    visit_0_14  in_degree_634  -1
    visit_0_14  order_active_lb_635  -1
    visit_0_14  order_active_ub_636  -12
    visit_0_14  service_visit_def_637  -1
    order_0_14  connected_order_arc_327  1
    order_0_14  connected_order_arc_350  1
    order_0_14  connected_order_arc_373  1
    order_0_14  connected_order_arc_396  1
    order_0_14  connected_order_arc_419  1
    order_0_14  connected_order_arc_442  1
    order_0_14  connected_order_arc_455  -1
    order_0_14  connected_order_arc_457  -1
    order_0_14  connected_order_arc_459  -1
    order_0_14  connected_order_arc_461  -1
    order_0_14  connected_order_arc_463  -1
    order_0_14  connected_order_arc_465  -1
    order_0_14  connected_order_arc_467  -1
    order_0_14  connected_order_arc_469  -1
    order_0_14  connected_order_arc_471  -1
    order_0_14  connected_order_arc_473  -1
    order_0_14  connected_order_arc_475  -1
    order_0_14  connected_order_arc_490  1
    order_0_14  connected_order_arc_513  1
    order_0_14  connected_order_arc_536  1
    order_0_14  connected_order_arc_559  1
    order_0_14  connected_order_arc_582  1
    order_0_14  order_active_lb_635  1
    order_0_14  order_active_ub_636  1
    visit_0_15  out_degree_639  -1
    visit_0_15  in_degree_640  -1
    visit_0_15  order_active_lb_641  -1
    visit_0_15  order_active_ub_642  -12
    visit_0_15  service_visit_def_643  -1
    order_0_15  connected_order_arc_329  1
    order_0_15  connected_order_arc_352  1
    order_0_15  connected_order_arc_375  1
    order_0_15  connected_order_arc_398  1
    order_0_15  connected_order_arc_421  1
    order_0_15  connected_order_arc_444  1
    order_0_15  connected_order_arc_467  1
    order_0_15  connected_order_arc_478  -1
    order_0_15  connected_order_arc_480  -1
    order_0_15  connected_order_arc_482  -1
    order_0_15  connected_order_arc_484  -1
    order_0_15  connected_order_arc_486  -1
    order_0_15  connected_order_arc_488  -1
    order_0_15  connected_order_arc_490  -1
    order_0_15  connected_order_arc_492  -1
    order_0_15  connected_order_arc_494  -1
    order_0_15  connected_order_arc_496  -1
    order_0_15  connected_order_arc_498  -1
    order_0_15  connected_order_arc_515  1
    order_0_15  connected_order_arc_538  1
    order_0_15  connected_order_arc_561  1
    order_0_15  connected_order_arc_584  1
    order_0_15  order_active_lb_641  1
    order_0_15  order_active_ub_642  1
    visit_0_16  out_degree_645  -1
    visit_0_16  in_degree_646  -1
    visit_0_16  order_active_lb_647  -1
    visit_0_16  order_active_ub_648  -12
    visit_0_16  service_visit_def_649  -1
    order_0_16  connected_order_arc_331  1
    order_0_16  connected_order_arc_354  1
    order_0_16  connected_order_arc_377  1
    order_0_16  connected_order_arc_400  1
    order_0_16  connected_order_arc_423  1
    order_0_16  connected_order_arc_446  1
    order_0_16  connected_order_arc_469  1
    order_0_16  connected_order_arc_492  1
    order_0_16  connected_order_arc_501  -1
    order_0_16  connected_order_arc_503  -1
    order_0_16  connected_order_arc_505  -1
    order_0_16  connected_order_arc_507  -1
    order_0_16  connected_order_arc_509  -1
    order_0_16  connected_order_arc_511  -1
    order_0_16  connected_order_arc_513  -1
    order_0_16  connected_order_arc_515  -1
    order_0_16  connected_order_arc_517  -1
    order_0_16  connected_order_arc_519  -1
    order_0_16  connected_order_arc_521  -1
    order_0_16  connected_order_arc_540  1
    order_0_16  connected_order_arc_563  1
    order_0_16  connected_order_arc_586  1
    order_0_16  order_active_lb_647  1
    order_0_16  order_active_ub_648  1
    visit_0_17  out_degree_651  -1
    visit_0_17  in_degree_652  -1
    visit_0_17  order_active_lb_653  -1
    visit_0_17  order_active_ub_654  -12
    visit_0_17  service_visit_def_655  -1
    order_0_17  connected_order_arc_333  1
    order_0_17  connected_order_arc_356  1
    order_0_17  connected_order_arc_379  1
    order_0_17  connected_order_arc_402  1
    order_0_17  connected_order_arc_425  1
    order_0_17  connected_order_arc_448  1
    order_0_17  connected_order_arc_471  1
    order_0_17  connected_order_arc_494  1
    order_0_17  connected_order_arc_517  1
    order_0_17  connected_order_arc_524  -1
    order_0_17  connected_order_arc_526  -1
    order_0_17  connected_order_arc_528  -1
    order_0_17  connected_order_arc_530  -1
    order_0_17  connected_order_arc_532  -1
    order_0_17  connected_order_arc_534  -1
    order_0_17  connected_order_arc_536  -1
    order_0_17  connected_order_arc_538  -1
    order_0_17  connected_order_arc_540  -1
    order_0_17  connected_order_arc_542  -1
    order_0_17  connected_order_arc_544  -1
    order_0_17  connected_order_arc_565  1
    order_0_17  connected_order_arc_588  1
    order_0_17  order_active_lb_653  1
    order_0_17  order_active_ub_654  1
    visit_0_18  out_degree_657  -1
    visit_0_18  in_degree_658  -1
    visit_0_18  order_active_lb_659  -1
    visit_0_18  order_active_ub_660  -12
    visit_0_18  service_visit_def_661  -1
    order_0_18  connected_order_arc_335  1
    order_0_18  connected_order_arc_358  1
    order_0_18  connected_order_arc_381  1
    order_0_18  connected_order_arc_404  1
    order_0_18  connected_order_arc_427  1
    order_0_18  connected_order_arc_450  1
    order_0_18  connected_order_arc_473  1
    order_0_18  connected_order_arc_496  1
    order_0_18  connected_order_arc_519  1
    order_0_18  connected_order_arc_542  1
    order_0_18  connected_order_arc_547  -1
    order_0_18  connected_order_arc_549  -1
    order_0_18  connected_order_arc_551  -1
    order_0_18  connected_order_arc_553  -1
    order_0_18  connected_order_arc_555  -1
    order_0_18  connected_order_arc_557  -1
    order_0_18  connected_order_arc_559  -1
    order_0_18  connected_order_arc_561  -1
    order_0_18  connected_order_arc_563  -1
    order_0_18  connected_order_arc_565  -1
    order_0_18  connected_order_arc_567  -1
    order_0_18  connected_order_arc_590  1
    order_0_18  order_active_lb_659  1
    order_0_18  order_active_ub_660  1
    visit_0_19  out_degree_663  -1
    visit_0_19  in_degree_664  -1
    visit_0_19  order_active_lb_665  -1
    visit_0_19  order_active_ub_666  -12
    visit_0_19  service_visit_def_667  -1
    order_0_19  connected_order_arc_337  1
    order_0_19  connected_order_arc_360  1
    order_0_19  connected_order_arc_383  1
    order_0_19  connected_order_arc_406  1
    order_0_19  connected_order_arc_429  1
    order_0_19  connected_order_arc_452  1
    order_0_19  connected_order_arc_475  1
    order_0_19  connected_order_arc_498  1
    order_0_19  connected_order_arc_521  1
    order_0_19  connected_order_arc_544  1
    order_0_19  connected_order_arc_567  1
    order_0_19  connected_order_arc_570  -1
    order_0_19  connected_order_arc_572  -1
    order_0_19  connected_order_arc_574  -1
    order_0_19  connected_order_arc_576  -1
    order_0_19  connected_order_arc_578  -1
    order_0_19  connected_order_arc_580  -1
    order_0_19  connected_order_arc_582  -1
    order_0_19  connected_order_arc_584  -1
    order_0_19  connected_order_arc_586  -1
    order_0_19  connected_order_arc_588  -1
    order_0_19  connected_order_arc_590  -1
    order_0_19  order_active_lb_665  1
    order_0_19  order_active_ub_666  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_0  arc_capacity_302  -20
    arc_0_0_0  depot_departure_or_bypass_591  1
    arc_0_0_0  depot_return_or_bypass_592  1
    MARKER    'MARKER'                 'INTEND'
    load_0_0_0  arc_capacity_302  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_1  arc_capacity_303  -20
    arc_0_0_1  depot_departure_or_bypass_591  1
    arc_0_0_1  in_degree_594  1
    arc_0_0_1  original_T_including_depot_unload_672  5.2273830510106120e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_1  arc_capacity_303  1
    load_0_0_1  segment_load_conservation_597  -1
    load_0_0_1  segment_prefix_lb_598  1
    load_0_0_1  segment_prefix_ub_599  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_2  arc_capacity_304  -20
    arc_0_0_2  depot_departure_or_bypass_591  1
    arc_0_0_2  in_degree_601  1
    arc_0_0_2  original_T_including_depot_unload_672  3.9307504957585564e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_2  arc_capacity_304  1
    load_0_0_2  segment_load_conservation_604  -1
    load_0_0_2  segment_prefix_lb_605  1
    load_0_0_2  segment_prefix_ub_606  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_3  arc_capacity_305  -20
    arc_0_0_3  depot_departure_or_bypass_591  1
    arc_0_0_3  in_degree_608  1
    arc_0_0_3  original_T_including_depot_unload_672  3.6666597054112611e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_3  arc_capacity_305  1
    load_0_0_3  segment_load_conservation_611  -1
    load_0_0_3  segment_prefix_lb_612  1
    load_0_0_3  segment_prefix_ub_613  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_4  arc_capacity_306  -20
    arc_0_0_4  depot_departure_or_bypass_591  1
    arc_0_0_4  in_degree_615  1
    arc_0_0_4  original_T_including_depot_unload_672  3.8060477410436619e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_4  arc_capacity_306  1
    load_0_0_4  segment_load_conservation_618  -1
    load_0_0_4  segment_prefix_lb_619  1
    load_0_0_4  segment_prefix_ub_620  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_12  arc_capacity_307  -20
    arc_0_0_12  depot_departure_or_bypass_591  1
    arc_0_0_12  in_degree_622  1
    arc_0_0_12  original_T_including_depot_unload_672  7.9650294035968375e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_12  arc_capacity_307  1
    load_0_0_12  free_load_conservation_626  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_13  arc_capacity_308  -20
    arc_0_0_13  depot_departure_or_bypass_591  1
    arc_0_0_13  in_degree_628  1
    arc_0_0_13  original_T_including_depot_unload_672  1.0056399980521732e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_13  arc_capacity_308  1
    load_0_0_13  free_load_conservation_632  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_14  arc_capacity_309  -20
    arc_0_0_14  depot_departure_or_bypass_591  1
    arc_0_0_14  in_degree_634  1
    arc_0_0_14  original_T_including_depot_unload_672  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_14  arc_capacity_309  1
    load_0_0_14  free_load_conservation_638  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_15  arc_capacity_310  -20
    arc_0_0_15  depot_departure_or_bypass_591  1
    arc_0_0_15  in_degree_640  1
    arc_0_0_15  original_T_including_depot_unload_672  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_15  arc_capacity_310  1
    load_0_0_15  free_load_conservation_644  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_16  arc_capacity_311  -20
    arc_0_0_16  depot_departure_or_bypass_591  1
    arc_0_0_16  in_degree_646  1
    arc_0_0_16  original_T_including_depot_unload_672  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_16  arc_capacity_311  1
    load_0_0_16  free_load_conservation_650  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_17  arc_capacity_312  -20
    arc_0_0_17  depot_departure_or_bypass_591  1
    arc_0_0_17  in_degree_652  1
    arc_0_0_17  original_T_including_depot_unload_672  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_17  arc_capacity_312  1
    load_0_0_17  free_load_conservation_656  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_18  arc_capacity_313  -20
    arc_0_0_18  depot_departure_or_bypass_591  1
    arc_0_0_18  in_degree_658  1
    arc_0_0_18  original_T_including_depot_unload_672  778.011461754062
    MARKER    'MARKER'                 'INTEND'
    load_0_0_18  arc_capacity_313  1
    load_0_0_18  free_load_conservation_662  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_19  arc_capacity_314  -20
    arc_0_0_19  depot_departure_or_bypass_591  1
    arc_0_0_19  in_degree_664  1
    arc_0_0_19  original_T_including_depot_unload_672  5.8421641813809208e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_19  arc_capacity_314  1
    load_0_0_19  free_load_conservation_668  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_0  arc_capacity_315  -20
    arc_0_1_0  depot_return_or_bypass_592  1
    arc_0_1_0  out_degree_593  1
    arc_0_1_0  original_T_including_depot_unload_672  4.3364857643570593e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_0  arc_capacity_315  1
    load_0_1_0  segment_load_conservation_597  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_2  arc_capacity_316  -20
    arc_0_1_2  connected_order_arc_317  -13
    arc_0_1_2  out_degree_593  1
    arc_0_1_2  in_degree_601  1
    arc_0_1_2  original_T_including_depot_unload_672  1.9684882536425036e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_2  arc_capacity_316  1
    load_0_1_2  segment_load_conservation_597  1
    load_0_1_2  segment_load_conservation_604  -1
    load_0_1_2  segment_prefix_lb_605  1
    load_0_1_2  segment_prefix_ub_606  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_3  arc_capacity_318  -20
    arc_0_1_3  connected_order_arc_319  -13
    arc_0_1_3  out_degree_593  1
    arc_0_1_3  in_degree_608  1
    arc_0_1_3  original_T_including_depot_unload_672  3.8423967538093660e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_3  arc_capacity_318  1
    load_0_1_3  segment_load_conservation_597  1
    load_0_1_3  segment_load_conservation_611  -1
    load_0_1_3  segment_prefix_lb_612  1
    load_0_1_3  segment_prefix_ub_613  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_4  arc_capacity_320  -20
    arc_0_1_4  connected_order_arc_321  -13
    arc_0_1_4  out_degree_593  1
    arc_0_1_4  in_degree_615  1
    arc_0_1_4  original_T_including_depot_unload_672  4.8520683722319296e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_4  arc_capacity_320  1
    load_0_1_4  segment_load_conservation_597  1
    load_0_1_4  segment_load_conservation_618  -1
    load_0_1_4  segment_prefix_lb_619  1
    load_0_1_4  segment_prefix_ub_620  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_12  arc_capacity_322  -20
    arc_0_1_12  connected_order_arc_323  -13
    arc_0_1_12  out_degree_593  1
    arc_0_1_12  in_degree_622  1
    arc_0_1_12  original_T_including_depot_unload_672  1.1827214856899616e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_12  arc_capacity_322  1
    load_0_1_12  segment_load_conservation_597  1
    load_0_1_12  free_load_conservation_626  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_13  arc_capacity_324  -20
    arc_0_1_13  connected_order_arc_325  -13
    arc_0_1_13  out_degree_593  1
    arc_0_1_13  in_degree_628  1
    arc_0_1_13  original_T_including_depot_unload_672  1.4285403548915413e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_13  arc_capacity_324  1
    load_0_1_13  segment_load_conservation_597  1
    load_0_1_13  free_load_conservation_632  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_14  arc_capacity_326  -20
    arc_0_1_14  connected_order_arc_327  -13
    arc_0_1_14  out_degree_593  1
    arc_0_1_14  in_degree_634  1
    arc_0_1_14  original_T_including_depot_unload_672  1.7908610301589636e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_14  arc_capacity_326  1
    load_0_1_14  segment_load_conservation_597  1
    load_0_1_14  free_load_conservation_638  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_15  arc_capacity_328  -20
    arc_0_1_15  connected_order_arc_329  -13
    arc_0_1_15  out_degree_593  1
    arc_0_1_15  in_degree_640  1
    arc_0_1_15  original_T_including_depot_unload_672  1.4300244315666421e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_15  arc_capacity_328  1
    load_0_1_15  segment_load_conservation_597  1
    load_0_1_15  free_load_conservation_644  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_16  arc_capacity_330  -20
    arc_0_1_16  connected_order_arc_331  -13
    arc_0_1_16  out_degree_593  1
    arc_0_1_16  in_degree_646  1
    arc_0_1_16  original_T_including_depot_unload_672  1.1588937665971753e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_16  arc_capacity_330  1
    load_0_1_16  segment_load_conservation_597  1
    load_0_1_16  free_load_conservation_650  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_17  arc_capacity_332  -20
    arc_0_1_17  connected_order_arc_333  -13
    arc_0_1_17  out_degree_593  1
    arc_0_1_17  in_degree_652  1
    arc_0_1_17  original_T_including_depot_unload_672  8.5579830526745980e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_17  arc_capacity_332  1
    load_0_1_17  segment_load_conservation_597  1
    load_0_1_17  free_load_conservation_656  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_18  arc_capacity_334  -20
    arc_0_1_18  connected_order_arc_335  -13
    arc_0_1_18  out_degree_593  1
    arc_0_1_18  in_degree_658  1
    arc_0_1_18  original_T_including_depot_unload_672  9.9507040584540334e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_18  arc_capacity_334  1
    load_0_1_18  segment_load_conservation_597  1
    load_0_1_18  free_load_conservation_662  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_19  arc_capacity_336  -20
    arc_0_1_19  connected_order_arc_337  -13
    arc_0_1_19  out_degree_593  1
    arc_0_1_19  in_degree_664  1
    arc_0_1_19  original_T_including_depot_unload_672  7.9279566508536948e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_19  arc_capacity_336  1
    load_0_1_19  segment_load_conservation_597  1
    load_0_1_19  free_load_conservation_668  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_0  arc_capacity_338  -20
    arc_0_2_0  depot_return_or_bypass_592  1
    arc_0_2_0  out_degree_600  1
    arc_0_2_0  original_T_including_depot_unload_672  391.582148421393
    MARKER    'MARKER'                 'INTEND'
    load_0_2_0  arc_capacity_338  1
    load_0_2_0  segment_load_conservation_604  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_1  arc_capacity_339  -20
    arc_0_2_1  connected_order_arc_340  -13
    arc_0_2_1  in_degree_594  1
    arc_0_2_1  out_degree_600  1
    arc_0_2_1  original_T_including_depot_unload_672  3.6440683639116645e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_1  arc_capacity_339  1
    load_0_2_1  segment_load_conservation_597  -1
    load_0_2_1  segment_prefix_lb_598  1
    load_0_2_1  segment_prefix_ub_599  1
    load_0_2_1  segment_load_conservation_604  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_3  arc_capacity_341  -20
    arc_0_2_3  connected_order_arc_342  -13
    arc_0_2_3  out_degree_600  1
    arc_0_2_3  in_degree_608  1
    arc_0_2_3  original_T_including_depot_unload_672  193.618232742121
    MARKER    'MARKER'                 'INTEND'
    load_0_2_3  arc_capacity_341  1
    load_0_2_3  segment_load_conservation_604  1
    load_0_2_3  segment_load_conservation_611  -1
    load_0_2_3  segment_prefix_lb_612  1
    load_0_2_3  segment_prefix_ub_613  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_4  arc_capacity_343  -20
    arc_0_2_4  connected_order_arc_344  -13
    arc_0_2_4  out_degree_600  1
    arc_0_2_4  in_degree_615  1
    arc_0_2_4  original_T_including_depot_unload_672  2.9898712977512486e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_4  arc_capacity_343  1
    load_0_2_4  segment_load_conservation_604  1
    load_0_2_4  segment_load_conservation_618  -1
    load_0_2_4  segment_prefix_lb_619  1
    load_0_2_4  segment_prefix_ub_620  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_12  arc_capacity_345  -20
    arc_0_2_12  connected_order_arc_346  -13
    arc_0_2_12  out_degree_600  1
    arc_0_2_12  in_degree_622  1
    arc_0_2_12  original_T_including_depot_unload_672  1.0452797846577832e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_12  arc_capacity_345  1
    load_0_2_12  segment_load_conservation_604  1
    load_0_2_12  free_load_conservation_626  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_13  arc_capacity_347  -20
    arc_0_2_13  connected_order_arc_348  -13
    arc_0_2_13  out_degree_600  1
    arc_0_2_13  in_degree_628  1
    arc_0_2_13  original_T_including_depot_unload_672  1.3208627731923268e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_13  arc_capacity_347  1
    load_0_2_13  segment_load_conservation_604  1
    load_0_2_13  free_load_conservation_632  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_14  arc_capacity_349  -20
    arc_0_2_14  connected_order_arc_350  -13
    arc_0_2_14  out_degree_600  1
    arc_0_2_14  in_degree_634  1
    arc_0_2_14  original_T_including_depot_unload_672  1.5968425841449753e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_14  arc_capacity_349  1
    load_0_2_14  segment_load_conservation_604  1
    load_0_2_14  free_load_conservation_638  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_15  arc_capacity_351  -20
    arc_0_2_15  connected_order_arc_352  -13
    arc_0_2_15  out_degree_600  1
    arc_0_2_15  in_degree_640  1
    arc_0_2_15  original_T_including_depot_unload_672  1.3222534044746537e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_15  arc_capacity_351  1
    load_0_2_15  segment_load_conservation_604  1
    load_0_2_15  free_load_conservation_644  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_16  arc_capacity_353  -20
    arc_0_2_16  connected_order_arc_354  -13
    arc_0_2_16  out_degree_600  1
    arc_0_2_16  in_degree_646  1
    arc_0_2_16  original_T_including_depot_unload_672  9.6906528258679839e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_16  arc_capacity_353  1
    load_0_2_16  segment_load_conservation_604  1
    load_0_2_16  free_load_conservation_650  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_17  arc_capacity_355  -20
    arc_0_2_17  connected_order_arc_356  -13
    arc_0_2_17  out_degree_600  1
    arc_0_2_17  in_degree_652  1
    arc_0_2_17  original_T_including_depot_unload_672  7.5480538147776406e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_17  arc_capacity_355  1
    load_0_2_17  segment_load_conservation_604  1
    load_0_2_17  free_load_conservation_656  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_18  arc_capacity_357  -20
    arc_0_2_18  connected_order_arc_358  -13
    arc_0_2_18  out_degree_600  1
    arc_0_2_18  in_degree_658  1
    arc_0_2_18  original_T_including_depot_unload_672  8.0582548325956611e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_18  arc_capacity_357  1
    load_0_2_18  segment_load_conservation_604  1
    load_0_2_18  free_load_conservation_662  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_19  arc_capacity_359  -20
    arc_0_2_19  connected_order_arc_360  -13
    arc_0_2_19  out_degree_600  1
    arc_0_2_19  in_degree_664  1
    arc_0_2_19  original_T_including_depot_unload_672  6.0704113403569352e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_19  arc_capacity_359  1
    load_0_2_19  segment_load_conservation_604  1
    load_0_2_19  free_load_conservation_668  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_0  arc_capacity_361  -20
    arc_0_3_0  depot_return_or_bypass_592  1
    arc_0_3_0  out_degree_607  1
    arc_0_3_0  original_T_including_depot_unload_672  3.6666597054112611e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_0  arc_capacity_361  1
    load_0_3_0  segment_load_conservation_611  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_1  arc_capacity_362  -20
    arc_0_3_1  connected_order_arc_363  -13
    arc_0_3_1  in_degree_594  1
    arc_0_3_1  out_degree_607  1
    arc_0_3_1  original_T_including_depot_unload_672  5.4660309215526388e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_1  arc_capacity_362  1
    load_0_3_1  segment_load_conservation_597  -1
    load_0_3_1  segment_prefix_lb_598  1
    load_0_3_1  segment_prefix_ub_599  1
    load_0_3_1  segment_load_conservation_611  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_2  arc_capacity_364  -20
    arc_0_3_2  connected_order_arc_365  -13
    arc_0_3_2  in_degree_601  1
    arc_0_3_2  out_degree_607  1
    arc_0_3_2  original_T_including_depot_unload_672  1.9614944290232185e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_2  arc_capacity_364  1
    load_0_3_2  segment_load_conservation_604  -1
    load_0_3_2  segment_prefix_lb_605  1
    load_0_3_2  segment_prefix_ub_606  1
    load_0_3_2  segment_load_conservation_611  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_4  arc_capacity_366  -20
    arc_0_3_4  connected_order_arc_367  -13
    arc_0_3_4  out_degree_607  1
    arc_0_3_4  in_degree_615  1
    arc_0_3_4  original_T_including_depot_unload_672  1.0605986491096120e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_4  arc_capacity_366  1
    load_0_3_4  segment_load_conservation_611  1
    load_0_3_4  segment_load_conservation_618  -1
    load_0_3_4  segment_prefix_lb_619  1
    load_0_3_4  segment_prefix_ub_620  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_12  arc_capacity_368  -20
    arc_0_3_12  connected_order_arc_369  -13
    arc_0_3_12  out_degree_607  1
    arc_0_3_12  in_degree_622  1
    arc_0_3_12  original_T_including_depot_unload_672  876.282348312514
    MARKER    'MARKER'                 'INTEND'
    load_0_3_12  arc_capacity_368  1
    load_0_3_12  segment_load_conservation_611  1
    load_0_3_12  free_load_conservation_626  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_13  arc_capacity_370  -20
    arc_0_3_13  connected_order_arc_371  -13
    arc_0_3_13  out_degree_607  1
    arc_0_3_13  in_degree_628  1
    arc_0_3_13  original_T_including_depot_unload_672  1.1724354239849338e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_13  arc_capacity_370  1
    load_0_3_13  segment_load_conservation_611  1
    load_0_3_13  free_load_conservation_632  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_14  arc_capacity_372  -20
    arc_0_3_14  connected_order_arc_373  -13
    arc_0_3_14  out_degree_607  1
    arc_0_3_14  in_degree_634  1
    arc_0_3_14  original_T_including_depot_unload_672  1.4066323818659139e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_14  arc_capacity_372  1
    load_0_3_14  segment_load_conservation_611  1
    load_0_3_14  free_load_conservation_638  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_15  arc_capacity_374  -20
    arc_0_3_15  connected_order_arc_375  -13
    arc_0_3_15  out_degree_607  1
    arc_0_3_15  in_degree_640  1
    arc_0_3_15  original_T_including_depot_unload_672  1.1737339836679257e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_15  arc_capacity_374  1
    load_0_3_15  segment_load_conservation_611  1
    load_0_3_15  free_load_conservation_644  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_16  arc_capacity_376  -20
    arc_0_3_16  connected_order_arc_377  -13
    arc_0_3_16  out_degree_607  1
    arc_0_3_16  in_degree_646  1
    arc_0_3_16  original_T_including_depot_unload_672  7.7620596437921665e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_16  arc_capacity_376  1
    load_0_3_16  segment_load_conservation_611  1
    load_0_3_16  free_load_conservation_650  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_17  arc_capacity_378  -20
    arc_0_3_17  connected_order_arc_379  -13
    arc_0_3_17  out_degree_607  1
    arc_0_3_17  in_degree_652  1
    arc_0_3_17  original_T_including_depot_unload_672  6.2502004715709484e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_17  arc_capacity_378  1
    load_0_3_17  segment_load_conservation_611  1
    load_0_3_17  free_load_conservation_656  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_18  arc_capacity_380  -20
    arc_0_3_18  connected_order_arc_381  -13
    arc_0_3_18  out_degree_607  1
    arc_0_3_18  in_degree_658  1
    arc_0_3_18  original_T_including_depot_unload_672  6.1271031593432815e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_18  arc_capacity_380  1
    load_0_3_18  segment_load_conservation_611  1
    load_0_3_18  free_load_conservation_662  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_19  arc_capacity_382  -20
    arc_0_3_19  connected_order_arc_383  -13
    arc_0_3_19  out_degree_607  1
    arc_0_3_19  in_degree_664  1
    arc_0_3_19  original_T_including_depot_unload_672  4.1343325097934911e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_19  arc_capacity_382  1
    load_0_3_19  segment_load_conservation_611  1
    load_0_3_19  free_load_conservation_668  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_0  arc_capacity_384  -20
    arc_0_4_0  depot_return_or_bypass_592  1
    arc_0_4_0  out_degree_614  1
    arc_0_4_0  original_T_including_depot_unload_672  3.8060477410436619e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_0  arc_capacity_384  1
    load_0_4_0  segment_load_conservation_618  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_1  arc_capacity_385  -20
    arc_0_4_1  connected_order_arc_386  -13
    arc_0_4_1  in_degree_594  1
    arc_0_4_1  out_degree_614  1
    arc_0_4_1  original_T_including_depot_unload_672  6.4485258452666415e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_1  arc_capacity_385  1
    load_0_4_1  segment_load_conservation_597  -1
    load_0_4_1  segment_prefix_lb_598  1
    load_0_4_1  segment_prefix_ub_599  1
    load_0_4_1  segment_load_conservation_618  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_2  arc_capacity_387  -20
    arc_0_4_2  connected_order_arc_388  -13
    arc_0_4_2  in_degree_601  1
    arc_0_4_2  out_degree_614  1
    arc_0_4_2  original_T_including_depot_unload_672  3.0154417050280659e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_2  arc_capacity_387  1
    load_0_4_2  segment_load_conservation_604  -1
    load_0_4_2  segment_prefix_lb_605  1
    load_0_4_2  segment_prefix_ub_606  1
    load_0_4_2  segment_load_conservation_618  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_3  arc_capacity_389  -20
    arc_0_4_3  connected_order_arc_390  -13
    arc_0_4_3  in_degree_608  1
    arc_0_4_3  out_degree_614  1
    arc_0_4_3  original_T_including_depot_unload_672  1.0605986491096120e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_3  arc_capacity_389  1
    load_0_4_3  segment_load_conservation_611  -1
    load_0_4_3  segment_prefix_lb_612  1
    load_0_4_3  segment_prefix_ub_613  1
    load_0_4_3  segment_load_conservation_618  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_12  arc_capacity_391  -20
    arc_0_4_12  connected_order_arc_392  -13
    arc_0_4_12  out_degree_614  1
    arc_0_4_12  in_degree_622  1
    arc_0_4_12  original_T_including_depot_unload_672  7.8060605690718819e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_12  arc_capacity_391  1
    load_0_4_12  segment_load_conservation_618  1
    load_0_4_12  free_load_conservation_626  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_13  arc_capacity_393  -20
    arc_0_4_13  connected_order_arc_394  -13
    arc_0_4_13  out_degree_614  1
    arc_0_4_13  in_degree_628  1
    arc_0_4_13  original_T_including_depot_unload_672  1.0869859877715128e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_13  arc_capacity_393  1
    load_0_4_13  segment_load_conservation_618  1
    load_0_4_13  free_load_conservation_632  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_14  arc_capacity_395  -20
    arc_0_4_14  connected_order_arc_396  -13
    arc_0_4_14  out_degree_614  1
    arc_0_4_14  in_degree_634  1
    arc_0_4_14  original_T_including_depot_unload_672  1.3072142379397485e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_14  arc_capacity_395  1
    load_0_4_14  segment_load_conservation_618  1
    load_0_4_14  free_load_conservation_638  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_15  arc_capacity_397  -20
    arc_0_4_15  connected_order_arc_398  -13
    arc_0_4_15  out_degree_614  1
    arc_0_4_15  in_degree_640  1
    arc_0_4_15  original_T_including_depot_unload_672  1.0882276141652012e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_15  arc_capacity_397  1
    load_0_4_15  segment_load_conservation_618  1
    load_0_4_15  free_load_conservation_644  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_16  arc_capacity_399  -20
    arc_0_4_16  connected_order_arc_400  -13
    arc_0_4_16  out_degree_614  1
    arc_0_4_16  in_degree_646  1
    arc_0_4_16  original_T_including_depot_unload_672  6.7368811350376711e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_16  arc_capacity_399  1
    load_0_4_16  segment_load_conservation_618  1
    load_0_4_16  free_load_conservation_650  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_17  arc_capacity_401  -20
    arc_0_4_17  connected_order_arc_402  -13
    arc_0_4_17  out_degree_614  1
    arc_0_4_17  in_degree_652  1
    arc_0_4_17  original_T_including_depot_unload_672  5.5668303114993182e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_17  arc_capacity_401  1
    load_0_4_17  segment_load_conservation_618  1
    load_0_4_17  free_load_conservation_656  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_18  arc_capacity_403  -20
    arc_0_4_18  connected_order_arc_404  -13
    arc_0_4_18  out_degree_614  1
    arc_0_4_18  in_degree_658  1
    arc_0_4_18  original_T_including_depot_unload_672  5.0986619729981788e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_18  arc_capacity_403  1
    load_0_4_18  segment_load_conservation_618  1
    load_0_4_18  free_load_conservation_662  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_19  arc_capacity_405  -20
    arc_0_4_19  connected_order_arc_406  -13
    arc_0_4_19  out_degree_614  1
    arc_0_4_19  in_degree_664  1
    arc_0_4_19  original_T_including_depot_unload_672  308.565954837055
    MARKER    'MARKER'                 'INTEND'
    load_0_4_19  arc_capacity_405  1
    load_0_4_19  segment_load_conservation_618  1
    load_0_4_19  free_load_conservation_668  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_0  arc_capacity_407  -20
    arc_0_12_0  depot_return_or_bypass_592  1
    arc_0_12_0  out_degree_621  1
    arc_0_12_0  original_T_including_depot_unload_672  7.9650294035968375e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_0  arc_capacity_407  1
    load_0_12_0  free_load_conservation_626  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_1  arc_capacity_408  -20
    arc_0_12_1  connected_order_arc_409  -13
    arc_0_12_1  in_degree_594  1
    arc_0_12_1  out_degree_621  1
    arc_0_12_1  original_T_including_depot_unload_672  1.3060135543268104e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_1  arc_capacity_408  1
    load_0_12_1  segment_load_conservation_597  -1
    load_0_12_1  segment_prefix_lb_598  1
    load_0_12_1  segment_prefix_ub_599  1
    load_0_12_1  free_load_conservation_626  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_2  arc_capacity_410  -20
    arc_0_12_2  connected_order_arc_411  -13
    arc_0_12_2  in_degree_601  1
    arc_0_12_2  out_degree_621  1
    arc_0_12_2  original_T_including_depot_unload_672  1.0478069687959494e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_2  arc_capacity_410  1
    load_0_12_2  segment_load_conservation_604  -1
    load_0_12_2  segment_prefix_lb_605  1
    load_0_12_2  segment_prefix_ub_606  1
    load_0_12_2  free_load_conservation_626  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_3  arc_capacity_412  -20
    arc_0_12_3  connected_order_arc_413  -13
    arc_0_12_3  in_degree_608  1
    arc_0_12_3  out_degree_621  1
    arc_0_12_3  original_T_including_depot_unload_672  876.282348312514
    MARKER    'MARKER'                 'INTEND'
    load_0_12_3  arc_capacity_412  1
    load_0_12_3  segment_load_conservation_611  -1
    load_0_12_3  segment_prefix_lb_612  1
    load_0_12_3  segment_prefix_ub_613  1
    load_0_12_3  free_load_conservation_626  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_4  arc_capacity_414  -20
    arc_0_12_4  connected_order_arc_415  -13
    arc_0_12_4  in_degree_615  1
    arc_0_12_4  out_degree_621  1
    arc_0_12_4  original_T_including_depot_unload_672  7.8060605690718819e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_4  arc_capacity_414  1
    load_0_12_4  segment_load_conservation_618  -1
    load_0_12_4  segment_prefix_lb_619  1
    load_0_12_4  segment_prefix_ub_620  1
    load_0_12_4  free_load_conservation_626  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_13  arc_capacity_416  -20
    arc_0_12_13  connected_order_arc_417  -13
    arc_0_12_13  out_degree_621  1
    arc_0_12_13  in_degree_628  1
    arc_0_12_13  original_T_including_depot_unload_672  3.5166546157461704e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_13  arc_capacity_416  1
    load_0_12_13  free_load_conservation_626  1
    load_0_12_13  free_load_conservation_632  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_14  arc_capacity_418  -20
    arc_0_12_14  connected_order_arc_419  -13
    arc_0_12_14  out_degree_621  1
    arc_0_12_14  in_degree_634  1
    arc_0_12_14  original_T_including_depot_unload_672  9.8108674361469946e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_14  arc_capacity_418  1
    load_0_12_14  free_load_conservation_626  1
    load_0_12_14  free_load_conservation_638  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_15  arc_capacity_420  -20
    arc_0_12_15  connected_order_arc_421  -13
    arc_0_12_15  out_degree_621  1
    arc_0_12_15  in_degree_640  1
    arc_0_12_15  original_T_including_depot_unload_672  3.5235932354279930e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_15  arc_capacity_420  1
    load_0_12_15  free_load_conservation_626  1
    load_0_12_15  free_load_conservation_644  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_16  arc_capacity_422  -20
    arc_0_12_16  connected_order_arc_423  -13
    arc_0_12_16  out_degree_621  1
    arc_0_12_16  in_degree_646  1
    arc_0_12_16  original_T_including_depot_unload_672  5.4405628017126674e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_16  arc_capacity_422  1
    load_0_12_16  free_load_conservation_626  1
    load_0_12_16  free_load_conservation_650  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_17  arc_capacity_424  -20
    arc_0_12_17  connected_order_arc_425  -13
    arc_0_12_17  out_degree_621  1
    arc_0_12_17  in_degree_652  1
    arc_0_12_17  original_T_including_depot_unload_672  3.7831268047064754e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_17  arc_capacity_424  1
    load_0_12_17  free_load_conservation_626  1
    load_0_12_17  free_load_conservation_656  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_18  arc_capacity_426  -20
    arc_0_12_18  connected_order_arc_427  -13
    arc_0_12_18  out_degree_621  1
    arc_0_12_18  in_degree_658  1
    arc_0_12_18  original_T_including_depot_unload_672  5.3348116005684176e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_18  arc_capacity_426  1
    load_0_12_18  free_load_conservation_626  1
    load_0_12_18  free_load_conservation_662  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_19  arc_capacity_428  -20
    arc_0_12_19  connected_order_arc_429  -13
    arc_0_12_19  out_degree_621  1
    arc_0_12_19  in_degree_664  1
    arc_0_12_19  original_T_including_depot_unload_672  566.256001718161
    MARKER    'MARKER'                 'INTEND'
    load_0_12_19  arc_capacity_428  1
    load_0_12_19  free_load_conservation_626  1
    load_0_12_19  free_load_conservation_668  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_0  arc_capacity_430  -20
    arc_0_13_0  depot_return_or_bypass_592  1
    arc_0_13_0  out_degree_627  1
    arc_0_13_0  original_T_including_depot_unload_672  1.0056399980521732e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_0  arc_capacity_430  1
    load_0_13_0  free_load_conservation_632  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_1  arc_capacity_431  -20
    arc_0_13_1  connected_order_arc_432  -13
    arc_0_13_1  in_degree_594  1
    arc_0_13_1  out_degree_627  1
    arc_0_13_1  original_T_including_depot_unload_672  1.5282490775772073e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_1  arc_capacity_431  1
    load_0_13_1  segment_load_conservation_597  -1
    load_0_13_1  segment_prefix_lb_598  1
    load_0_13_1  segment_prefix_ub_599  1
    load_0_13_1  free_load_conservation_632  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_2  arc_capacity_433  -20
    arc_0_13_2  connected_order_arc_434  -13
    arc_0_13_2  in_degree_601  1
    arc_0_13_2  out_degree_627  1
    arc_0_13_2  original_T_including_depot_unload_672  1.3232349913962587e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_2  arc_capacity_433  1
    load_0_13_2  segment_load_conservation_604  -1
    load_0_13_2  segment_prefix_lb_605  1
    load_0_13_2  segment_prefix_ub_606  1
    load_0_13_2  free_load_conservation_632  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_3  arc_capacity_435  -20
    arc_0_13_3  connected_order_arc_436  -13
    arc_0_13_3  in_degree_608  1
    arc_0_13_3  out_degree_627  1
    arc_0_13_3  original_T_including_depot_unload_672  1.1724354239849338e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_3  arc_capacity_435  1
    load_0_13_3  segment_load_conservation_611  -1
    load_0_13_3  segment_prefix_lb_612  1
    load_0_13_3  segment_prefix_ub_613  1
    load_0_13_3  free_load_conservation_632  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_4  arc_capacity_437  -20
    arc_0_13_4  connected_order_arc_438  -13
    arc_0_13_4  in_degree_615  1
    arc_0_13_4  out_degree_627  1
    arc_0_13_4  original_T_including_depot_unload_672  1.0869859877715128e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_4  arc_capacity_437  1
    load_0_13_4  segment_load_conservation_618  -1
    load_0_13_4  segment_prefix_lb_619  1
    load_0_13_4  segment_prefix_ub_620  1
    load_0_13_4  free_load_conservation_632  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_12  arc_capacity_439  -20
    arc_0_13_12  connected_order_arc_440  -13
    arc_0_13_12  in_degree_622  1
    arc_0_13_12  out_degree_627  1
    arc_0_13_12  original_T_including_depot_unload_672  3.5166546157461704e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_12  arc_capacity_439  1
    load_0_13_12  free_load_conservation_626  -1
    load_0_13_12  free_load_conservation_632  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_14  arc_capacity_441  -20
    arc_0_13_14  connected_order_arc_442  -13
    arc_0_13_14  out_degree_627  1
    arc_0_13_14  in_degree_634  1
    arc_0_13_14  original_T_including_depot_unload_672  1.1967280409234234e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_14  arc_capacity_441  1
    load_0_13_14  free_load_conservation_632  1
    load_0_13_14  free_load_conservation_638  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_15  arc_capacity_443  -20
    arc_0_13_15  connected_order_arc_444  -13
    arc_0_13_15  out_degree_627  1
    arc_0_13_15  in_degree_640  1
    arc_0_13_15  original_T_including_depot_unload_672  1.6320002720932780e+00
    MARKER    'MARKER'                 'INTEND'
    load_0_13_15  arc_capacity_443  1
    load_0_13_15  free_load_conservation_632  1
    load_0_13_15  free_load_conservation_644  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_16  arc_capacity_445  -20
    arc_0_13_16  connected_order_arc_446  -13
    arc_0_13_16  out_degree_627  1
    arc_0_13_16  in_degree_646  1
    arc_0_13_16  original_T_including_depot_unload_672  8.7906342149593650e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_16  arc_capacity_445  1
    load_0_13_16  free_load_conservation_632  1
    load_0_13_16  free_load_conservation_650  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_17  arc_capacity_447  -20
    arc_0_13_17  connected_order_arc_448  -13
    arc_0_13_17  out_degree_627  1
    arc_0_13_17  in_degree_652  1
    arc_0_13_17  original_T_including_depot_unload_672  5.7276146581216926e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_17  arc_capacity_447  1
    load_0_13_17  free_load_conservation_632  1
    load_0_13_17  free_load_conservation_656  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_18  arc_capacity_449  -20
    arc_0_13_18  connected_order_arc_450  -13
    arc_0_13_18  out_degree_627  1
    arc_0_13_18  in_degree_658  1
    arc_0_13_18  original_T_including_depot_unload_672  8.8427037135592116e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_18  arc_capacity_449  1
    load_0_13_18  free_load_conservation_632  1
    load_0_13_18  free_load_conservation_662  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_19  arc_capacity_451  -20
    arc_0_13_19  connected_order_arc_452  -13
    arc_0_13_19  out_degree_627  1
    arc_0_13_19  in_degree_664  1
    arc_0_13_19  original_T_including_depot_unload_672  9.0947747566405189e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_19  arc_capacity_451  1
    load_0_13_19  free_load_conservation_632  1
    load_0_13_19  free_load_conservation_668  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_0  arc_capacity_453  -20
    arc_0_14_0  depot_return_or_bypass_592  1
    arc_0_14_0  out_degree_633  1
    arc_0_14_0  original_T_including_depot_unload_672  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_0  arc_capacity_453  1
    load_0_14_0  free_load_conservation_638  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_1  arc_capacity_454  -20
    arc_0_14_1  connected_order_arc_455  -13
    arc_0_14_1  in_degree_594  1
    arc_0_14_1  out_degree_633  1
    arc_0_14_1  original_T_including_depot_unload_672  1.9520133700471852e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_1  arc_capacity_454  1
    load_0_14_1  segment_load_conservation_597  -1
    load_0_14_1  segment_prefix_lb_598  1
    load_0_14_1  segment_prefix_ub_599  1
    load_0_14_1  free_load_conservation_638  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_2  arc_capacity_456  -20
    arc_0_14_2  connected_order_arc_457  -13
    arc_0_14_2  in_degree_601  1
    arc_0_14_2  out_degree_633  1
    arc_0_14_2  original_T_including_depot_unload_672  1.5992308845216928e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_2  arc_capacity_456  1
    load_0_14_2  segment_load_conservation_604  -1
    load_0_14_2  segment_prefix_lb_605  1
    load_0_14_2  segment_prefix_ub_606  1
    load_0_14_2  free_load_conservation_638  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_3  arc_capacity_458  -20
    arc_0_14_3  connected_order_arc_459  -13
    arc_0_14_3  in_degree_608  1
    arc_0_14_3  out_degree_633  1
    arc_0_14_3  original_T_including_depot_unload_672  1.4066323818659139e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_3  arc_capacity_458  1
    load_0_14_3  segment_load_conservation_611  -1
    load_0_14_3  segment_prefix_lb_612  1
    load_0_14_3  segment_prefix_ub_613  1
    load_0_14_3  free_load_conservation_638  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_4  arc_capacity_460  -20
    arc_0_14_4  connected_order_arc_461  -13
    arc_0_14_4  in_degree_615  1
    arc_0_14_4  out_degree_633  1
    arc_0_14_4  original_T_including_depot_unload_672  1.3072142379397485e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_4  arc_capacity_460  1
    load_0_14_4  segment_load_conservation_618  -1
    load_0_14_4  segment_prefix_lb_619  1
    load_0_14_4  segment_prefix_ub_620  1
    load_0_14_4  free_load_conservation_638  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_12  arc_capacity_462  -20
    arc_0_14_12  connected_order_arc_463  -13
    arc_0_14_12  in_degree_622  1
    arc_0_14_12  out_degree_633  1
    arc_0_14_12  original_T_including_depot_unload_672  9.8108674361469946e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_12  arc_capacity_462  1
    load_0_14_12  free_load_conservation_626  -1
    load_0_14_12  free_load_conservation_638  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_13  arc_capacity_464  -20
    arc_0_14_13  connected_order_arc_465  -13
    arc_0_14_13  in_degree_628  1
    arc_0_14_13  out_degree_633  1
    arc_0_14_13  original_T_including_depot_unload_672  1.1967280409234234e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_13  arc_capacity_464  1
    load_0_14_13  free_load_conservation_632  -1
    load_0_14_13  free_load_conservation_638  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_15  arc_capacity_466  -20
    arc_0_14_15  connected_order_arc_467  -13
    arc_0_14_15  out_degree_633  1
    arc_0_14_15  in_degree_640  1
    arc_0_14_15  original_T_including_depot_unload_672  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_15  arc_capacity_466  1
    load_0_14_15  free_load_conservation_638  1
    load_0_14_15  free_load_conservation_644  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_16  arc_capacity_468  -20
    arc_0_14_16  connected_order_arc_469  -13
    arc_0_14_16  out_degree_633  1
    arc_0_14_16  in_degree_646  1
    arc_0_14_16  original_T_including_depot_unload_672  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_0_14_16  arc_capacity_468  1
    load_0_14_16  free_load_conservation_638  1
    load_0_14_16  free_load_conservation_650  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_17  arc_capacity_470  -20
    arc_0_14_17  connected_order_arc_471  -13
    arc_0_14_17  out_degree_633  1
    arc_0_14_17  in_degree_652  1
    arc_0_14_17  original_T_including_depot_unload_672  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_17  arc_capacity_470  1
    load_0_14_17  free_load_conservation_638  1
    load_0_14_17  free_load_conservation_656  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_18  arc_capacity_472  -20
    arc_0_14_18  connected_order_arc_473  -13
    arc_0_14_18  out_degree_633  1
    arc_0_14_18  in_degree_658  1
    arc_0_14_18  original_T_including_depot_unload_672  8.0139063451811444e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_18  arc_capacity_472  1
    load_0_14_18  free_load_conservation_638  1
    load_0_14_18  free_load_conservation_662  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_19  arc_capacity_474  -20
    arc_0_14_19  connected_order_arc_475  -13
    arc_0_14_19  out_degree_633  1
    arc_0_14_19  in_degree_664  1
    arc_0_14_19  original_T_including_depot_unload_672  1.0063298732365655e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_19  arc_capacity_474  1
    load_0_14_19  free_load_conservation_638  1
    load_0_14_19  free_load_conservation_668  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_0  arc_capacity_476  -20
    arc_0_15_0  depot_return_or_bypass_592  1
    arc_0_15_0  out_degree_639  1
    arc_0_15_0  original_T_including_depot_unload_672  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_0  arc_capacity_476  1
    load_0_15_0  free_load_conservation_644  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_1  arc_capacity_477  -20
    arc_0_15_1  connected_order_arc_478  -13
    arc_0_15_1  in_degree_594  1
    arc_0_15_1  out_degree_639  1
    arc_0_15_1  original_T_including_depot_unload_672  1.5297878372821015e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_1  arc_capacity_477  1
    load_0_15_1  segment_load_conservation_597  -1
    load_0_15_1  segment_prefix_lb_598  1
    load_0_15_1  segment_prefix_ub_599  1
    load_0_15_1  free_load_conservation_644  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_2  arc_capacity_479  -20
    arc_0_15_2  connected_order_arc_480  -13
    arc_0_15_2  in_degree_601  1
    arc_0_15_2  out_degree_639  1
    arc_0_15_2  original_T_including_depot_unload_672  1.3246263055739521e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_2  arc_capacity_479  1
    load_0_15_2  segment_load_conservation_604  -1
    load_0_15_2  segment_prefix_lb_605  1
    load_0_15_2  segment_prefix_ub_606  1
    load_0_15_2  free_load_conservation_644  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_3  arc_capacity_481  -20
    arc_0_15_3  connected_order_arc_482  -13
    arc_0_15_3  in_degree_608  1
    arc_0_15_3  out_degree_639  1
    arc_0_15_3  original_T_including_depot_unload_672  1.1737339836679257e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_3  arc_capacity_481  1
    load_0_15_3  segment_load_conservation_611  -1
    load_0_15_3  segment_prefix_lb_612  1
    load_0_15_3  segment_prefix_ub_613  1
    load_0_15_3  free_load_conservation_644  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_4  arc_capacity_483  -20
    arc_0_15_4  connected_order_arc_484  -13
    arc_0_15_4  in_degree_615  1
    arc_0_15_4  out_degree_639  1
    arc_0_15_4  original_T_including_depot_unload_672  1.0882276141652012e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_4  arc_capacity_483  1
    load_0_15_4  segment_load_conservation_618  -1
    load_0_15_4  segment_prefix_lb_619  1
    load_0_15_4  segment_prefix_ub_620  1
    load_0_15_4  free_load_conservation_644  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_12  arc_capacity_485  -20
    arc_0_15_12  connected_order_arc_486  -13
    arc_0_15_12  in_degree_622  1
    arc_0_15_12  out_degree_639  1
    arc_0_15_12  original_T_including_depot_unload_672  3.5235932354279930e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_12  arc_capacity_485  1
    load_0_15_12  free_load_conservation_626  -1
    load_0_15_12  free_load_conservation_644  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_13  arc_capacity_487  -20
    arc_0_15_13  connected_order_arc_488  -13
    arc_0_15_13  in_degree_628  1
    arc_0_15_13  out_degree_639  1
    arc_0_15_13  original_T_including_depot_unload_672  1.6320002720932780e+00
    MARKER    'MARKER'                 'INTEND'
    load_0_15_13  arc_capacity_487  1
    load_0_15_13  free_load_conservation_632  -1
    load_0_15_13  free_load_conservation_644  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_14  arc_capacity_489  -20
    arc_0_15_14  connected_order_arc_490  -13
    arc_0_15_14  in_degree_634  1
    arc_0_15_14  out_degree_639  1
    arc_0_15_14  original_T_including_depot_unload_672  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_14  arc_capacity_489  1
    load_0_15_14  free_load_conservation_638  -1
    load_0_15_14  free_load_conservation_644  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_16  arc_capacity_491  -20
    arc_0_15_16  connected_order_arc_492  -13
    arc_0_15_16  out_degree_639  1
    arc_0_15_16  in_degree_646  1
    arc_0_15_16  original_T_including_depot_unload_672  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_16  arc_capacity_491  1
    load_0_15_16  free_load_conservation_644  1
    load_0_15_16  free_load_conservation_650  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_17  arc_capacity_493  -20
    arc_0_15_17  connected_order_arc_494  -13
    arc_0_15_17  out_degree_639  1
    arc_0_15_17  in_degree_652  1
    arc_0_15_17  original_T_including_depot_unload_672  5.7424143497696048e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_17  arc_capacity_493  1
    load_0_15_17  free_load_conservation_644  1
    load_0_15_17  free_load_conservation_656  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_18  arc_capacity_495  -20
    arc_0_15_18  connected_order_arc_496  -13
    arc_0_15_18  out_degree_639  1
    arc_0_15_18  in_degree_658  1
    arc_0_15_18  original_T_including_depot_unload_672  8.8488037837239642e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_18  arc_capacity_495  1
    load_0_15_18  free_load_conservation_644  1
    load_0_15_18  free_load_conservation_662  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_19  arc_capacity_497  -20
    arc_0_15_19  connected_order_arc_498  -13
    arc_0_15_19  out_degree_639  1
    arc_0_15_19  in_degree_664  1
    arc_0_15_19  original_T_including_depot_unload_672  9.1041274142057227e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_19  arc_capacity_497  1
    load_0_15_19  free_load_conservation_644  1
    load_0_15_19  free_load_conservation_668  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_0  arc_capacity_499  -20
    arc_0_16_0  depot_return_or_bypass_592  1
    arc_0_16_0  out_degree_645  1
    arc_0_16_0  original_T_including_depot_unload_672  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_0  arc_capacity_499  1
    load_0_16_0  free_load_conservation_650  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_1  arc_capacity_500  -20
    arc_0_16_1  connected_order_arc_501  -13
    arc_0_16_1  in_degree_594  1
    arc_0_16_1  out_degree_645  1
    arc_0_16_1  original_T_including_depot_unload_672  1.3176071585703125e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_1  arc_capacity_500  1
    load_0_16_1  segment_load_conservation_597  -1
    load_0_16_1  segment_prefix_lb_598  1
    load_0_16_1  segment_prefix_ub_599  1
    load_0_16_1  free_load_conservation_650  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_2  arc_capacity_502  -20
    arc_0_16_2  connected_order_arc_503  -13
    arc_0_16_2  in_degree_601  1
    arc_0_16_2  out_degree_645  1
    arc_0_16_2  original_T_including_depot_unload_672  9.7154140307447824e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_2  arc_capacity_502  1
    load_0_16_2  segment_load_conservation_604  -1
    load_0_16_2  segment_prefix_lb_605  1
    load_0_16_2  segment_prefix_ub_606  1
    load_0_16_2  free_load_conservation_650  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_3  arc_capacity_504  -20
    arc_0_16_3  connected_order_arc_505  -13
    arc_0_16_3  in_degree_608  1
    arc_0_16_3  out_degree_645  1
    arc_0_16_3  original_T_including_depot_unload_672  7.7620596437921665e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_3  arc_capacity_504  1
    load_0_16_3  segment_load_conservation_611  -1
    load_0_16_3  segment_prefix_lb_612  1
    load_0_16_3  segment_prefix_ub_613  1
    load_0_16_3  free_load_conservation_650  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_4  arc_capacity_506  -20
    arc_0_16_4  connected_order_arc_507  -13
    arc_0_16_4  in_degree_615  1
    arc_0_16_4  out_degree_645  1
    arc_0_16_4  original_T_including_depot_unload_672  6.7368811350376711e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_4  arc_capacity_506  1
    load_0_16_4  segment_load_conservation_618  -1
    load_0_16_4  segment_prefix_lb_619  1
    load_0_16_4  segment_prefix_ub_620  1
    load_0_16_4  free_load_conservation_650  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_12  arc_capacity_508  -20
    arc_0_16_12  connected_order_arc_509  -13
    arc_0_16_12  in_degree_622  1
    arc_0_16_12  out_degree_645  1
    arc_0_16_12  original_T_including_depot_unload_672  5.4405628017126674e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_12  arc_capacity_508  1
    load_0_16_12  free_load_conservation_626  -1
    load_0_16_12  free_load_conservation_650  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_13  arc_capacity_510  -20
    arc_0_16_13  connected_order_arc_511  -13
    arc_0_16_13  in_degree_628  1
    arc_0_16_13  out_degree_645  1
    arc_0_16_13  original_T_including_depot_unload_672  8.7906342149593650e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_13  arc_capacity_510  1
    load_0_16_13  free_load_conservation_632  -1
    load_0_16_13  free_load_conservation_650  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_14  arc_capacity_512  -20
    arc_0_16_14  connected_order_arc_513  -13
    arc_0_16_14  in_degree_634  1
    arc_0_16_14  out_degree_645  1
    arc_0_16_14  original_T_including_depot_unload_672  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_0_16_14  arc_capacity_512  1
    load_0_16_14  free_load_conservation_638  -1
    load_0_16_14  free_load_conservation_650  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_15  arc_capacity_514  -20
    arc_0_16_15  connected_order_arc_515  -13
    arc_0_16_15  in_degree_640  1
    arc_0_16_15  out_degree_645  1
    arc_0_16_15  original_T_including_depot_unload_672  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_15  arc_capacity_514  1
    load_0_16_15  free_load_conservation_644  -1
    load_0_16_15  free_load_conservation_650  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_17  arc_capacity_516  -20
    arc_0_16_17  connected_order_arc_517  -13
    arc_0_16_17  out_degree_645  1
    arc_0_16_17  in_degree_652  1
    arc_0_16_17  original_T_including_depot_unload_672  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_0_16_17  arc_capacity_516  1
    load_0_16_17  free_load_conservation_650  1
    load_0_16_17  free_load_conservation_656  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_18  arc_capacity_518  -20
    arc_0_16_18  connected_order_arc_519  -13
    arc_0_16_18  out_degree_645  1
    arc_0_16_18  in_degree_658  1
    arc_0_16_18  original_T_including_depot_unload_672  1.6388081578301370e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_18  arc_capacity_518  1
    load_0_16_18  free_load_conservation_650  1
    load_0_16_18  free_load_conservation_662  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_19  arc_capacity_520  -20
    arc_0_16_19  connected_order_arc_521  -13
    arc_0_16_19  out_degree_645  1
    arc_0_16_19  in_degree_664  1
    arc_0_16_19  original_T_including_depot_unload_672  3.6822662782562685e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_19  arc_capacity_520  1
    load_0_16_19  free_load_conservation_650  1
    load_0_16_19  free_load_conservation_668  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_0  arc_capacity_522  -20
    arc_0_17_0  depot_return_or_bypass_592  1
    arc_0_17_0  out_degree_651  1
    arc_0_17_0  original_T_including_depot_unload_672  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_0  arc_capacity_522  1
    load_0_17_0  free_load_conservation_656  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_1  arc_capacity_523  -20
    arc_0_17_1  connected_order_arc_524  -13
    arc_0_17_1  in_degree_594  1
    arc_0_17_1  out_degree_651  1
    arc_0_17_1  original_T_including_depot_unload_672  9.5968099967049886e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_1  arc_capacity_523  1
    load_0_17_1  segment_load_conservation_597  -1
    load_0_17_1  segment_prefix_lb_598  1
    load_0_17_1  segment_prefix_ub_599  1
    load_0_17_1  free_load_conservation_656  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_2  arc_capacity_525  -20
    arc_0_17_2  connected_order_arc_526  -13
    arc_0_17_2  in_degree_601  1
    arc_0_17_2  out_degree_651  1
    arc_0_17_2  original_T_including_depot_unload_672  7.5707648242091466e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_2  arc_capacity_525  1
    load_0_17_2  segment_load_conservation_604  -1
    load_0_17_2  segment_prefix_lb_605  1
    load_0_17_2  segment_prefix_ub_606  1
    load_0_17_2  free_load_conservation_656  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_3  arc_capacity_527  -20
    arc_0_17_3  connected_order_arc_528  -13
    arc_0_17_3  in_degree_608  1
    arc_0_17_3  out_degree_651  1
    arc_0_17_3  original_T_including_depot_unload_672  6.2502004715709484e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_3  arc_capacity_527  1
    load_0_17_3  segment_load_conservation_611  -1
    load_0_17_3  segment_prefix_lb_612  1
    load_0_17_3  segment_prefix_ub_613  1
    load_0_17_3  free_load_conservation_656  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_4  arc_capacity_529  -20
    arc_0_17_4  connected_order_arc_530  -13
    arc_0_17_4  in_degree_615  1
    arc_0_17_4  out_degree_651  1
    arc_0_17_4  original_T_including_depot_unload_672  5.5668303114993182e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_4  arc_capacity_529  1
    load_0_17_4  segment_load_conservation_618  -1
    load_0_17_4  segment_prefix_lb_619  1
    load_0_17_4  segment_prefix_ub_620  1
    load_0_17_4  free_load_conservation_656  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_12  arc_capacity_531  -20
    arc_0_17_12  connected_order_arc_532  -13
    arc_0_17_12  in_degree_622  1
    arc_0_17_12  out_degree_651  1
    arc_0_17_12  original_T_including_depot_unload_672  3.7831268047064754e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_12  arc_capacity_531  1
    load_0_17_12  free_load_conservation_626  -1
    load_0_17_12  free_load_conservation_656  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_13  arc_capacity_533  -20
    arc_0_17_13  connected_order_arc_534  -13
    arc_0_17_13  in_degree_628  1
    arc_0_17_13  out_degree_651  1
    arc_0_17_13  original_T_including_depot_unload_672  5.7276146581216926e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_13  arc_capacity_533  1
    load_0_17_13  free_load_conservation_632  -1
    load_0_17_13  free_load_conservation_656  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_14  arc_capacity_535  -20
    arc_0_17_14  connected_order_arc_536  -13
    arc_0_17_14  in_degree_634  1
    arc_0_17_14  out_degree_651  1
    arc_0_17_14  original_T_including_depot_unload_672  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_14  arc_capacity_535  1
    load_0_17_14  free_load_conservation_638  -1
    load_0_17_14  free_load_conservation_656  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_15  arc_capacity_537  -20
    arc_0_17_15  connected_order_arc_538  -13
    arc_0_17_15  in_degree_640  1
    arc_0_17_15  out_degree_651  1
    arc_0_17_15  original_T_including_depot_unload_672  5.7424143497696048e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_15  arc_capacity_537  1
    load_0_17_15  free_load_conservation_644  -1
    load_0_17_15  free_load_conservation_656  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_16  arc_capacity_539  -20
    arc_0_17_16  connected_order_arc_540  -13
    arc_0_17_16  in_degree_646  1
    arc_0_17_16  out_degree_651  1
    arc_0_17_16  original_T_including_depot_unload_672  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_0_17_16  arc_capacity_539  1
    load_0_17_16  free_load_conservation_650  -1
    load_0_17_16  free_load_conservation_656  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_18  arc_capacity_541  -20
    arc_0_17_18  connected_order_arc_542  -13
    arc_0_17_18  out_degree_651  1
    arc_0_17_18  in_degree_658  1
    arc_0_17_18  original_T_including_depot_unload_672  608.963327854777
    MARKER    'MARKER'                 'INTEND'
    load_0_17_18  arc_capacity_541  1
    load_0_17_18  free_load_conservation_656  1
    load_0_17_18  free_load_conservation_662  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_19  arc_capacity_543  -20
    arc_0_17_19  connected_order_arc_544  -13
    arc_0_17_19  out_degree_651  1
    arc_0_17_19  in_degree_664  1
    arc_0_17_19  original_T_including_depot_unload_672  5.0398976026149836e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_19  arc_capacity_543  1
    load_0_17_19  free_load_conservation_656  1
    load_0_17_19  free_load_conservation_668  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_0  arc_capacity_545  -20
    arc_0_18_0  depot_return_or_bypass_592  1
    arc_0_18_0  out_degree_657  1
    arc_0_18_0  original_T_including_depot_unload_672  778.011461754062
    MARKER    'MARKER'                 'INTEND'
    load_0_18_0  arc_capacity_545  1
    load_0_18_0  free_load_conservation_662  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_1  arc_capacity_546  -20
    arc_0_18_1  connected_order_arc_547  -13
    arc_0_18_1  in_degree_594  1
    arc_0_18_1  out_degree_657  1
    arc_0_18_1  original_T_including_depot_unload_672  1.1537433813312707e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_1  arc_capacity_546  1
    load_0_18_1  segment_load_conservation_597  -1
    load_0_18_1  segment_prefix_lb_598  1
    load_0_18_1  segment_prefix_ub_599  1
    load_0_18_1  free_load_conservation_662  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_2  arc_capacity_548  -20
    arc_0_18_2  connected_order_arc_549  -13
    arc_0_18_2  in_degree_601  1
    arc_0_18_2  out_degree_657  1
    arc_0_18_2  original_T_including_depot_unload_672  8.0831419223632781e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_2  arc_capacity_548  1
    load_0_18_2  segment_load_conservation_604  -1
    load_0_18_2  segment_prefix_lb_605  1
    load_0_18_2  segment_prefix_ub_606  1
    load_0_18_2  free_load_conservation_662  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_3  arc_capacity_550  -20
    arc_0_18_3  connected_order_arc_551  -13
    arc_0_18_3  in_degree_608  1
    arc_0_18_3  out_degree_657  1
    arc_0_18_3  original_T_including_depot_unload_672  6.1271031593432815e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_3  arc_capacity_550  1
    load_0_18_3  segment_load_conservation_611  -1
    load_0_18_3  segment_prefix_lb_612  1
    load_0_18_3  segment_prefix_ub_613  1
    load_0_18_3  free_load_conservation_662  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_4  arc_capacity_552  -20
    arc_0_18_4  connected_order_arc_553  -13
    arc_0_18_4  in_degree_615  1
    arc_0_18_4  out_degree_657  1
    arc_0_18_4  original_T_including_depot_unload_672  5.0986619729981788e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_4  arc_capacity_552  1
    load_0_18_4  segment_load_conservation_618  -1
    load_0_18_4  segment_prefix_lb_619  1
    load_0_18_4  segment_prefix_ub_620  1
    load_0_18_4  free_load_conservation_662  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_12  arc_capacity_554  -20
    arc_0_18_12  connected_order_arc_555  -13
    arc_0_18_12  in_degree_622  1
    arc_0_18_12  out_degree_657  1
    arc_0_18_12  original_T_including_depot_unload_672  5.3348116005684176e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_12  arc_capacity_554  1
    load_0_18_12  free_load_conservation_626  -1
    load_0_18_12  free_load_conservation_662  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_13  arc_capacity_556  -20
    arc_0_18_13  connected_order_arc_557  -13
    arc_0_18_13  in_degree_628  1
    arc_0_18_13  out_degree_657  1
    arc_0_18_13  original_T_including_depot_unload_672  8.8427037135592116e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_13  arc_capacity_556  1
    load_0_18_13  free_load_conservation_632  -1
    load_0_18_13  free_load_conservation_662  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_14  arc_capacity_558  -20
    arc_0_18_14  connected_order_arc_559  -13
    arc_0_18_14  in_degree_634  1
    arc_0_18_14  out_degree_657  1
    arc_0_18_14  original_T_including_depot_unload_672  8.0139063451811444e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_14  arc_capacity_558  1
    load_0_18_14  free_load_conservation_638  -1
    load_0_18_14  free_load_conservation_662  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_15  arc_capacity_560  -20
    arc_0_18_15  connected_order_arc_561  -13
    arc_0_18_15  in_degree_640  1
    arc_0_18_15  out_degree_657  1
    arc_0_18_15  original_T_including_depot_unload_672  8.8488037837239642e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_15  arc_capacity_560  1
    load_0_18_15  free_load_conservation_644  -1
    load_0_18_15  free_load_conservation_662  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_16  arc_capacity_562  -20
    arc_0_18_16  connected_order_arc_563  -13
    arc_0_18_16  in_degree_646  1
    arc_0_18_16  out_degree_657  1
    arc_0_18_16  original_T_including_depot_unload_672  1.6388081578301370e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_16  arc_capacity_562  1
    load_0_18_16  free_load_conservation_650  -1
    load_0_18_16  free_load_conservation_662  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_17  arc_capacity_564  -20
    arc_0_18_17  connected_order_arc_565  -13
    arc_0_18_17  in_degree_652  1
    arc_0_18_17  out_degree_657  1
    arc_0_18_17  original_T_including_depot_unload_672  608.963327854777
    MARKER    'MARKER'                 'INTEND'
    load_0_18_17  arc_capacity_564  1
    load_0_18_17  free_load_conservation_656  -1
    load_0_18_17  free_load_conservation_662  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_19  arc_capacity_566  -20
    arc_0_18_19  connected_order_arc_567  -13
    arc_0_18_19  out_degree_657  1
    arc_0_18_19  in_degree_664  1
    arc_0_18_19  original_T_including_depot_unload_672  204.956380049771
    MARKER    'MARKER'                 'INTEND'
    load_0_18_19  arc_capacity_566  1
    load_0_18_19  free_load_conservation_662  1
    load_0_18_19  free_load_conservation_668  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_0  arc_capacity_568  -20
    arc_0_19_0  depot_return_or_bypass_592  1
    arc_0_19_0  out_degree_663  1
    arc_0_19_0  original_T_including_depot_unload_672  5.8421641813809208e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_0  arc_capacity_568  1
    load_0_19_0  free_load_conservation_668  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_1  arc_capacity_569  -20
    arc_0_19_1  connected_order_arc_570  -13
    arc_0_19_1  in_degree_594  1
    arc_0_19_1  out_degree_663  1
    arc_0_19_1  original_T_including_depot_unload_672  9.5004139651657067e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_1  arc_capacity_569  1
    load_0_19_1  segment_load_conservation_597  -1
    load_0_19_1  segment_prefix_lb_598  1
    load_0_19_1  segment_prefix_ub_599  1
    load_0_19_1  free_load_conservation_668  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_2  arc_capacity_571  -20
    arc_0_19_2  connected_order_arc_572  -13
    arc_0_19_2  in_degree_601  1
    arc_0_19_2  out_degree_663  1
    arc_0_19_2  original_T_including_depot_unload_672  6.0957665440032713e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_2  arc_capacity_571  1
    load_0_19_2  segment_load_conservation_604  -1
    load_0_19_2  segment_prefix_lb_605  1
    load_0_19_2  segment_prefix_ub_606  1
    load_0_19_2  free_load_conservation_668  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_3  arc_capacity_573  -20
    arc_0_19_3  connected_order_arc_574  -13
    arc_0_19_3  in_degree_608  1
    arc_0_19_3  out_degree_663  1
    arc_0_19_3  original_T_including_depot_unload_672  4.1343325097934911e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_3  arc_capacity_573  1
    load_0_19_3  segment_load_conservation_611  -1
    load_0_19_3  segment_prefix_lb_612  1
    load_0_19_3  segment_prefix_ub_613  1
    load_0_19_3  free_load_conservation_668  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_4  arc_capacity_575  -20
    arc_0_19_4  connected_order_arc_576  -13
    arc_0_19_4  in_degree_615  1
    arc_0_19_4  out_degree_663  1
    arc_0_19_4  original_T_including_depot_unload_672  308.565954837055
    MARKER    'MARKER'                 'INTEND'
    load_0_19_4  arc_capacity_575  1
    load_0_19_4  segment_load_conservation_618  -1
    load_0_19_4  segment_prefix_lb_619  1
    load_0_19_4  segment_prefix_ub_620  1
    load_0_19_4  free_load_conservation_668  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_12  arc_capacity_577  -20
    arc_0_19_12  connected_order_arc_578  -13
    arc_0_19_12  in_degree_622  1
    arc_0_19_12  out_degree_663  1
    arc_0_19_12  original_T_including_depot_unload_672  566.256001718161
    MARKER    'MARKER'                 'INTEND'
    load_0_19_12  arc_capacity_577  1
    load_0_19_12  free_load_conservation_626  -1
    load_0_19_12  free_load_conservation_668  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_13  arc_capacity_579  -20
    arc_0_19_13  connected_order_arc_580  -13
    arc_0_19_13  in_degree_628  1
    arc_0_19_13  out_degree_663  1
    arc_0_19_13  original_T_including_depot_unload_672  9.0947747566405189e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_13  arc_capacity_579  1
    load_0_19_13  free_load_conservation_632  -1
    load_0_19_13  free_load_conservation_668  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_14  arc_capacity_581  -20
    arc_0_19_14  connected_order_arc_582  -13
    arc_0_19_14  in_degree_634  1
    arc_0_19_14  out_degree_663  1
    arc_0_19_14  original_T_including_depot_unload_672  1.0063298732365655e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_14  arc_capacity_581  1
    load_0_19_14  free_load_conservation_638  -1
    load_0_19_14  free_load_conservation_668  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_15  arc_capacity_583  -20
    arc_0_19_15  connected_order_arc_584  -13
    arc_0_19_15  in_degree_640  1
    arc_0_19_15  out_degree_663  1
    arc_0_19_15  original_T_including_depot_unload_672  9.1041274142057227e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_15  arc_capacity_583  1
    load_0_19_15  free_load_conservation_644  -1
    load_0_19_15  free_load_conservation_668  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_16  arc_capacity_585  -20
    arc_0_19_16  connected_order_arc_586  -13
    arc_0_19_16  in_degree_646  1
    arc_0_19_16  out_degree_663  1
    arc_0_19_16  original_T_including_depot_unload_672  3.6822662782562685e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_16  arc_capacity_585  1
    load_0_19_16  free_load_conservation_650  -1
    load_0_19_16  free_load_conservation_668  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_17  arc_capacity_587  -20
    arc_0_19_17  connected_order_arc_588  -13
    arc_0_19_17  in_degree_652  1
    arc_0_19_17  out_degree_663  1
    arc_0_19_17  original_T_including_depot_unload_672  5.0398976026149836e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_17  arc_capacity_587  1
    load_0_19_17  free_load_conservation_656  -1
    load_0_19_17  free_load_conservation_668  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_18  arc_capacity_589  -20
    arc_0_19_18  connected_order_arc_590  -13
    arc_0_19_18  in_degree_658  1
    arc_0_19_18  out_degree_663  1
    arc_0_19_18  original_T_including_depot_unload_672  204.956380049771
    MARKER    'MARKER'                 'INTEND'
    load_0_19_18  arc_capacity_589  1
    load_0_19_18  free_load_conservation_662  -1
    load_0_19_18  free_load_conservation_668  1
    visit_1_5  out_degree_964  -1
    visit_1_5  in_degree_965  -1
    visit_1_5  order_active_lb_966  -1
    visit_1_5  order_active_ub_967  -12
    order_1_5  connected_order_arc_688  -1
    order_1_5  connected_order_arc_690  -1
    order_1_5  connected_order_arc_692  -1
    order_1_5  connected_order_arc_694  -1
    order_1_5  connected_order_arc_696  -1
    order_1_5  connected_order_arc_698  -1
    order_1_5  connected_order_arc_700  -1
    order_1_5  connected_order_arc_702  -1
    order_1_5  connected_order_arc_704  -1
    order_1_5  connected_order_arc_706  -1
    order_1_5  connected_order_arc_708  -1
    order_1_5  connected_order_arc_711  1
    order_1_5  connected_order_arc_734  1
    order_1_5  connected_order_arc_757  1
    order_1_5  connected_order_arc_780  1
    order_1_5  connected_order_arc_803  1
    order_1_5  connected_order_arc_826  1
    order_1_5  connected_order_arc_849  1
    order_1_5  connected_order_arc_872  1
    order_1_5  connected_order_arc_895  1
    order_1_5  connected_order_arc_918  1
    order_1_5  connected_order_arc_941  1
    order_1_5  order_active_lb_966  1
    order_1_5  order_active_ub_967  1
    order_1_5  fixed_segment_relative_order_1040  -1
    visit_1_6  out_degree_971  -1
    visit_1_6  in_degree_972  -1
    visit_1_6  order_active_lb_973  -1
    visit_1_6  order_active_ub_974  -12
    order_1_6  connected_order_arc_688  1
    order_1_6  connected_order_arc_711  -1
    order_1_6  connected_order_arc_713  -1
    order_1_6  connected_order_arc_715  -1
    order_1_6  connected_order_arc_717  -1
    order_1_6  connected_order_arc_719  -1
    order_1_6  connected_order_arc_721  -1
    order_1_6  connected_order_arc_723  -1
    order_1_6  connected_order_arc_725  -1
    order_1_6  connected_order_arc_727  -1
    order_1_6  connected_order_arc_729  -1
    order_1_6  connected_order_arc_731  -1
    order_1_6  connected_order_arc_736  1
    order_1_6  connected_order_arc_759  1
    order_1_6  connected_order_arc_782  1
    order_1_6  connected_order_arc_805  1
    order_1_6  connected_order_arc_828  1
    order_1_6  connected_order_arc_851  1
    order_1_6  connected_order_arc_874  1
    order_1_6  connected_order_arc_897  1
    order_1_6  connected_order_arc_920  1
    order_1_6  connected_order_arc_943  1
    order_1_6  order_active_lb_973  1
    order_1_6  order_active_ub_974  1
    order_1_6  fixed_segment_relative_order_1040  1
    order_1_6  fixed_segment_relative_order_1041  -1
    visit_1_7  out_degree_978  -1
    visit_1_7  in_degree_979  -1
    visit_1_7  order_active_lb_980  -1
    visit_1_7  order_active_ub_981  -12
    order_1_7  connected_order_arc_690  1
    order_1_7  connected_order_arc_713  1
    order_1_7  connected_order_arc_734  -1
    order_1_7  connected_order_arc_736  -1
    order_1_7  connected_order_arc_738  -1
    order_1_7  connected_order_arc_740  -1
    order_1_7  connected_order_arc_742  -1
    order_1_7  connected_order_arc_744  -1
    order_1_7  connected_order_arc_746  -1
    order_1_7  connected_order_arc_748  -1
    order_1_7  connected_order_arc_750  -1
    order_1_7  connected_order_arc_752  -1
    order_1_7  connected_order_arc_754  -1
    order_1_7  connected_order_arc_761  1
    order_1_7  connected_order_arc_784  1
    order_1_7  connected_order_arc_807  1
    order_1_7  connected_order_arc_830  1
    order_1_7  connected_order_arc_853  1
    order_1_7  connected_order_arc_876  1
    order_1_7  connected_order_arc_899  1
    order_1_7  connected_order_arc_922  1
    order_1_7  connected_order_arc_945  1
    order_1_7  order_active_lb_980  1
    order_1_7  order_active_ub_981  1
    order_1_7  fixed_segment_relative_order_1041  1
    order_1_7  fixed_segment_relative_order_1042  -1
    visit_1_8  out_degree_985  -1
    visit_1_8  in_degree_986  -1
    visit_1_8  order_active_lb_987  -1
    visit_1_8  order_active_ub_988  -12
    order_1_8  connected_order_arc_692  1
    order_1_8  connected_order_arc_715  1
    order_1_8  connected_order_arc_738  1
    order_1_8  connected_order_arc_757  -1
    order_1_8  connected_order_arc_759  -1
    order_1_8  connected_order_arc_761  -1
    order_1_8  connected_order_arc_763  -1
    order_1_8  connected_order_arc_765  -1
    order_1_8  connected_order_arc_767  -1
    order_1_8  connected_order_arc_769  -1
    order_1_8  connected_order_arc_771  -1
    order_1_8  connected_order_arc_773  -1
    order_1_8  connected_order_arc_775  -1
    order_1_8  connected_order_arc_777  -1
    order_1_8  connected_order_arc_786  1
    order_1_8  connected_order_arc_809  1
    order_1_8  connected_order_arc_832  1
    order_1_8  connected_order_arc_855  1
    order_1_8  connected_order_arc_878  1
    order_1_8  connected_order_arc_901  1
    order_1_8  connected_order_arc_924  1
    order_1_8  connected_order_arc_947  1
    order_1_8  order_active_lb_987  1
    order_1_8  order_active_ub_988  1
    order_1_8  fixed_segment_relative_order_1042  1
    visit_1_12  out_degree_992  -1
    visit_1_12  in_degree_993  -1
    visit_1_12  order_active_lb_994  -1
    visit_1_12  order_active_ub_995  -12
    visit_1_12  service_visit_def_996  -1
    order_1_12  connected_order_arc_694  1
    order_1_12  connected_order_arc_717  1
    order_1_12  connected_order_arc_740  1
    order_1_12  connected_order_arc_763  1
    order_1_12  connected_order_arc_780  -1
    order_1_12  connected_order_arc_782  -1
    order_1_12  connected_order_arc_784  -1
    order_1_12  connected_order_arc_786  -1
    order_1_12  connected_order_arc_788  -1
    order_1_12  connected_order_arc_790  -1
    order_1_12  connected_order_arc_792  -1
    order_1_12  connected_order_arc_794  -1
    order_1_12  connected_order_arc_796  -1
    order_1_12  connected_order_arc_798  -1
    order_1_12  connected_order_arc_800  -1
    order_1_12  connected_order_arc_811  1
    order_1_12  connected_order_arc_834  1
    order_1_12  connected_order_arc_857  1
    order_1_12  connected_order_arc_880  1
    order_1_12  connected_order_arc_903  1
    order_1_12  connected_order_arc_926  1
    order_1_12  connected_order_arc_949  1
    order_1_12  order_active_lb_994  1
    order_1_12  order_active_ub_995  1
    visit_1_13  out_degree_998  -1
    visit_1_13  in_degree_999  -1
    visit_1_13  order_active_lb_1000  -1
    visit_1_13  order_active_ub_1001  -12
    visit_1_13  service_visit_def_1002  -1
    order_1_13  connected_order_arc_696  1
    order_1_13  connected_order_arc_719  1
    order_1_13  connected_order_arc_742  1
    order_1_13  connected_order_arc_765  1
    order_1_13  connected_order_arc_788  1
    order_1_13  connected_order_arc_803  -1
    order_1_13  connected_order_arc_805  -1
    order_1_13  connected_order_arc_807  -1
    order_1_13  connected_order_arc_809  -1
    order_1_13  connected_order_arc_811  -1
    order_1_13  connected_order_arc_813  -1
    order_1_13  connected_order_arc_815  -1
    order_1_13  connected_order_arc_817  -1
    order_1_13  connected_order_arc_819  -1
    order_1_13  connected_order_arc_821  -1
    order_1_13  connected_order_arc_823  -1
    order_1_13  connected_order_arc_836  1
    order_1_13  connected_order_arc_859  1
    order_1_13  connected_order_arc_882  1
    order_1_13  connected_order_arc_905  1
    order_1_13  connected_order_arc_928  1
    order_1_13  connected_order_arc_951  1
    order_1_13  order_active_lb_1000  1
    order_1_13  order_active_ub_1001  1
    visit_1_14  out_degree_1004  -1
    visit_1_14  in_degree_1005  -1
    visit_1_14  order_active_lb_1006  -1
    visit_1_14  order_active_ub_1007  -12
    visit_1_14  service_visit_def_1008  -1
    order_1_14  connected_order_arc_698  1
    order_1_14  connected_order_arc_721  1
    order_1_14  connected_order_arc_744  1
    order_1_14  connected_order_arc_767  1
    order_1_14  connected_order_arc_790  1
    order_1_14  connected_order_arc_813  1
    order_1_14  connected_order_arc_826  -1
    order_1_14  connected_order_arc_828  -1
    order_1_14  connected_order_arc_830  -1
    order_1_14  connected_order_arc_832  -1
    order_1_14  connected_order_arc_834  -1
    order_1_14  connected_order_arc_836  -1
    order_1_14  connected_order_arc_838  -1
    order_1_14  connected_order_arc_840  -1
    order_1_14  connected_order_arc_842  -1
    order_1_14  connected_order_arc_844  -1
    order_1_14  connected_order_arc_846  -1
    order_1_14  connected_order_arc_861  1
    order_1_14  connected_order_arc_884  1
    order_1_14  connected_order_arc_907  1
    order_1_14  connected_order_arc_930  1
    order_1_14  connected_order_arc_953  1
    order_1_14  order_active_lb_1006  1
    order_1_14  order_active_ub_1007  1
    visit_1_15  out_degree_1010  -1
    visit_1_15  in_degree_1011  -1
    visit_1_15  order_active_lb_1012  -1
    visit_1_15  order_active_ub_1013  -12
    visit_1_15  service_visit_def_1014  -1
    order_1_15  connected_order_arc_700  1
    order_1_15  connected_order_arc_723  1
    order_1_15  connected_order_arc_746  1
    order_1_15  connected_order_arc_769  1
    order_1_15  connected_order_arc_792  1
    order_1_15  connected_order_arc_815  1
    order_1_15  connected_order_arc_838  1
    order_1_15  connected_order_arc_849  -1
    order_1_15  connected_order_arc_851  -1
    order_1_15  connected_order_arc_853  -1
    order_1_15  connected_order_arc_855  -1
    order_1_15  connected_order_arc_857  -1
    order_1_15  connected_order_arc_859  -1
    order_1_15  connected_order_arc_861  -1
    order_1_15  connected_order_arc_863  -1
    order_1_15  connected_order_arc_865  -1
    order_1_15  connected_order_arc_867  -1
    order_1_15  connected_order_arc_869  -1
    order_1_15  connected_order_arc_886  1
    order_1_15  connected_order_arc_909  1
    order_1_15  connected_order_arc_932  1
    order_1_15  connected_order_arc_955  1
    order_1_15  order_active_lb_1012  1
    order_1_15  order_active_ub_1013  1
    visit_1_16  out_degree_1016  -1
    visit_1_16  in_degree_1017  -1
    visit_1_16  order_active_lb_1018  -1
    visit_1_16  order_active_ub_1019  -12
    visit_1_16  service_visit_def_1020  -1
    order_1_16  connected_order_arc_702  1
    order_1_16  connected_order_arc_725  1
    order_1_16  connected_order_arc_748  1
    order_1_16  connected_order_arc_771  1
    order_1_16  connected_order_arc_794  1
    order_1_16  connected_order_arc_817  1
    order_1_16  connected_order_arc_840  1
    order_1_16  connected_order_arc_863  1
    order_1_16  connected_order_arc_872  -1
    order_1_16  connected_order_arc_874  -1
    order_1_16  connected_order_arc_876  -1
    order_1_16  connected_order_arc_878  -1
    order_1_16  connected_order_arc_880  -1
    order_1_16  connected_order_arc_882  -1
    order_1_16  connected_order_arc_884  -1
    order_1_16  connected_order_arc_886  -1
    order_1_16  connected_order_arc_888  -1
    order_1_16  connected_order_arc_890  -1
    order_1_16  connected_order_arc_892  -1
    order_1_16  connected_order_arc_911  1
    order_1_16  connected_order_arc_934  1
    order_1_16  connected_order_arc_957  1
    order_1_16  order_active_lb_1018  1
    order_1_16  order_active_ub_1019  1
    visit_1_17  out_degree_1022  -1
    visit_1_17  in_degree_1023  -1
    visit_1_17  order_active_lb_1024  -1
    visit_1_17  order_active_ub_1025  -12
    visit_1_17  service_visit_def_1026  -1
    order_1_17  connected_order_arc_704  1
    order_1_17  connected_order_arc_727  1
    order_1_17  connected_order_arc_750  1
    order_1_17  connected_order_arc_773  1
    order_1_17  connected_order_arc_796  1
    order_1_17  connected_order_arc_819  1
    order_1_17  connected_order_arc_842  1
    order_1_17  connected_order_arc_865  1
    order_1_17  connected_order_arc_888  1
    order_1_17  connected_order_arc_895  -1
    order_1_17  connected_order_arc_897  -1
    order_1_17  connected_order_arc_899  -1
    order_1_17  connected_order_arc_901  -1
    order_1_17  connected_order_arc_903  -1
    order_1_17  connected_order_arc_905  -1
    order_1_17  connected_order_arc_907  -1
    order_1_17  connected_order_arc_909  -1
    order_1_17  connected_order_arc_911  -1
    order_1_17  connected_order_arc_913  -1
    order_1_17  connected_order_arc_915  -1
    order_1_17  connected_order_arc_936  1
    order_1_17  connected_order_arc_959  1
    order_1_17  order_active_lb_1024  1
    order_1_17  order_active_ub_1025  1
    visit_1_18  out_degree_1028  -1
    visit_1_18  in_degree_1029  -1
    visit_1_18  order_active_lb_1030  -1
    visit_1_18  order_active_ub_1031  -12
    visit_1_18  service_visit_def_1032  -1
    order_1_18  connected_order_arc_706  1
    order_1_18  connected_order_arc_729  1
    order_1_18  connected_order_arc_752  1
    order_1_18  connected_order_arc_775  1
    order_1_18  connected_order_arc_798  1
    order_1_18  connected_order_arc_821  1
    order_1_18  connected_order_arc_844  1
    order_1_18  connected_order_arc_867  1
    order_1_18  connected_order_arc_890  1
    order_1_18  connected_order_arc_913  1
    order_1_18  connected_order_arc_918  -1
    order_1_18  connected_order_arc_920  -1
    order_1_18  connected_order_arc_922  -1
    order_1_18  connected_order_arc_924  -1
    order_1_18  connected_order_arc_926  -1
    order_1_18  connected_order_arc_928  -1
    order_1_18  connected_order_arc_930  -1
    order_1_18  connected_order_arc_932  -1
    order_1_18  connected_order_arc_934  -1
    order_1_18  connected_order_arc_936  -1
    order_1_18  connected_order_arc_938  -1
    order_1_18  connected_order_arc_961  1
    order_1_18  order_active_lb_1030  1
    order_1_18  order_active_ub_1031  1
    visit_1_19  out_degree_1034  -1
    visit_1_19  in_degree_1035  -1
    visit_1_19  order_active_lb_1036  -1
    visit_1_19  order_active_ub_1037  -12
    visit_1_19  service_visit_def_1038  -1
    order_1_19  connected_order_arc_708  1
    order_1_19  connected_order_arc_731  1
    order_1_19  connected_order_arc_754  1
    order_1_19  connected_order_arc_777  1
    order_1_19  connected_order_arc_800  1
    order_1_19  connected_order_arc_823  1
    order_1_19  connected_order_arc_846  1
    order_1_19  connected_order_arc_869  1
    order_1_19  connected_order_arc_892  1
    order_1_19  connected_order_arc_915  1
    order_1_19  connected_order_arc_938  1
    order_1_19  connected_order_arc_941  -1
    order_1_19  connected_order_arc_943  -1
    order_1_19  connected_order_arc_945  -1
    order_1_19  connected_order_arc_947  -1
    order_1_19  connected_order_arc_949  -1
    order_1_19  connected_order_arc_951  -1
    order_1_19  connected_order_arc_953  -1
    order_1_19  connected_order_arc_955  -1
    order_1_19  connected_order_arc_957  -1
    order_1_19  connected_order_arc_959  -1
    order_1_19  connected_order_arc_961  -1
    order_1_19  order_active_lb_1036  1
    order_1_19  order_active_ub_1037  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_0  arc_capacity_673  -25
    arc_1_0_0  depot_departure_or_bypass_962  1
    arc_1_0_0  depot_return_or_bypass_963  1
    MARKER    'MARKER'                 'INTEND'
    load_1_0_0  arc_capacity_673  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_5  arc_capacity_674  -25
    arc_1_0_5  depot_departure_or_bypass_962  1
    arc_1_0_5  in_degree_965  1
    arc_1_0_5  original_T_including_depot_unload_1043  1.1935953747864173e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_5  arc_capacity_674  1
    load_1_0_5  segment_load_conservation_968  -1
    load_1_0_5  segment_prefix_lb_969  1
    load_1_0_5  segment_prefix_ub_970  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_6  arc_capacity_675  -25
    arc_1_0_6  depot_departure_or_bypass_962  1
    arc_1_0_6  in_degree_972  1
    arc_1_0_6  original_T_including_depot_unload_1043  7.2047755761928431e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_6  arc_capacity_675  1
    load_1_0_6  segment_load_conservation_975  -1
    load_1_0_6  segment_prefix_lb_976  1
    load_1_0_6  segment_prefix_ub_977  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_7  arc_capacity_676  -25
    arc_1_0_7  depot_departure_or_bypass_962  1
    arc_1_0_7  in_degree_979  1
    arc_1_0_7  original_T_including_depot_unload_1043  5.4911852608328161e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_7  arc_capacity_676  1
    load_1_0_7  segment_load_conservation_982  -1
    load_1_0_7  segment_prefix_lb_983  1
    load_1_0_7  segment_prefix_ub_984  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_8  arc_capacity_677  -25
    arc_1_0_8  depot_departure_or_bypass_962  1
    arc_1_0_8  in_degree_986  1
    arc_1_0_8  original_T_including_depot_unload_1043  3.5061909388980052e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_8  arc_capacity_677  1
    load_1_0_8  segment_load_conservation_989  -1
    load_1_0_8  segment_prefix_lb_990  1
    load_1_0_8  segment_prefix_ub_991  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_12  arc_capacity_678  -25
    arc_1_0_12  depot_departure_or_bypass_962  1
    arc_1_0_12  in_degree_993  1
    arc_1_0_12  original_T_including_depot_unload_1043  7.9650294035968375e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_12  arc_capacity_678  1
    load_1_0_12  free_load_conservation_997  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_13  arc_capacity_679  -25
    arc_1_0_13  depot_departure_or_bypass_962  1
    arc_1_0_13  in_degree_999  1
    arc_1_0_13  original_T_including_depot_unload_1043  1.0056399980521732e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_13  arc_capacity_679  1
    load_1_0_13  free_load_conservation_1003  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_14  arc_capacity_680  -25
    arc_1_0_14  depot_departure_or_bypass_962  1
    arc_1_0_14  in_degree_1005  1
    arc_1_0_14  original_T_including_depot_unload_1043  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_14  arc_capacity_680  1
    load_1_0_14  free_load_conservation_1009  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_15  arc_capacity_681  -25
    arc_1_0_15  depot_departure_or_bypass_962  1
    arc_1_0_15  in_degree_1011  1
    arc_1_0_15  original_T_including_depot_unload_1043  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_15  arc_capacity_681  1
    load_1_0_15  free_load_conservation_1015  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_16  arc_capacity_682  -25
    arc_1_0_16  depot_departure_or_bypass_962  1
    arc_1_0_16  in_degree_1017  1
    arc_1_0_16  original_T_including_depot_unload_1043  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_16  arc_capacity_682  1
    load_1_0_16  free_load_conservation_1021  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_17  arc_capacity_683  -25
    arc_1_0_17  depot_departure_or_bypass_962  1
    arc_1_0_17  in_degree_1023  1
    arc_1_0_17  original_T_including_depot_unload_1043  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_17  arc_capacity_683  1
    load_1_0_17  free_load_conservation_1027  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_18  arc_capacity_684  -25
    arc_1_0_18  depot_departure_or_bypass_962  1
    arc_1_0_18  in_degree_1029  1
    arc_1_0_18  original_T_including_depot_unload_1043  778.011461754062
    MARKER    'MARKER'                 'INTEND'
    load_1_0_18  arc_capacity_684  1
    load_1_0_18  free_load_conservation_1033  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_19  arc_capacity_685  -25
    arc_1_0_19  depot_departure_or_bypass_962  1
    arc_1_0_19  in_degree_1035  1
    arc_1_0_19  original_T_including_depot_unload_1043  5.8421641813809208e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_19  arc_capacity_685  1
    load_1_0_19  free_load_conservation_1039  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_0  arc_capacity_686  -25
    arc_1_5_0  depot_return_or_bypass_963  1
    arc_1_5_0  out_degree_964  1
    arc_1_5_0  original_T_including_depot_unload_1043  1.1935953747864173e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_0  arc_capacity_686  1
    load_1_5_0  segment_load_conservation_968  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_6  arc_capacity_687  -25
    arc_1_5_6  connected_order_arc_688  -13
    arc_1_5_6  out_degree_964  1
    arc_1_5_6  in_degree_972  1
    arc_1_5_6  original_T_including_depot_unload_1043  1.0819844298451576e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_6  arc_capacity_687  1
    load_1_5_6  segment_load_conservation_968  1
    load_1_5_6  segment_load_conservation_975  -1
    load_1_5_6  segment_prefix_lb_976  1
    load_1_5_6  segment_prefix_ub_977  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_7  arc_capacity_689  -25
    arc_1_5_7  connected_order_arc_690  -13
    arc_1_5_7  out_degree_964  1
    arc_1_5_7  in_degree_979  1
    arc_1_5_7  original_T_including_depot_unload_1043  1.2739580769060942e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_7  arc_capacity_689  1
    load_1_5_7  segment_load_conservation_968  1
    load_1_5_7  segment_load_conservation_982  -1
    load_1_5_7  segment_prefix_lb_983  1
    load_1_5_7  segment_prefix_ub_984  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_8  arc_capacity_691  -25
    arc_1_5_8  connected_order_arc_692  -13
    arc_1_5_8  out_degree_964  1
    arc_1_5_8  in_degree_986  1
    arc_1_5_8  original_T_including_depot_unload_1043  1.0313568965059917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_8  arc_capacity_691  1
    load_1_5_8  segment_load_conservation_968  1
    load_1_5_8  segment_load_conservation_989  -1
    load_1_5_8  segment_prefix_lb_990  1
    load_1_5_8  segment_prefix_ub_991  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_12  arc_capacity_693  -25
    arc_1_5_12  connected_order_arc_694  -13
    arc_1_5_12  out_degree_964  1
    arc_1_5_12  in_degree_993  1
    arc_1_5_12  original_T_including_depot_unload_1043  1.1851786693030479e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_12  arc_capacity_693  1
    load_1_5_12  segment_load_conservation_968  1
    load_1_5_12  free_load_conservation_997  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_13  arc_capacity_695  -25
    arc_1_5_13  connected_order_arc_696  -13
    arc_1_5_13  out_degree_964  1
    arc_1_5_13  in_degree_999  1
    arc_1_5_13  original_T_including_depot_unload_1043  9.7357850164388731e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_5_13  arc_capacity_695  1
    load_1_5_13  segment_load_conservation_968  1
    load_1_5_13  free_load_conservation_1003  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_14  arc_capacity_697  -25
    arc_1_5_14  connected_order_arc_698  -13
    arc_1_5_14  out_degree_964  1
    arc_1_5_14  in_degree_1005  1
    arc_1_5_14  original_T_including_depot_unload_1043  2.1501600514850211e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_14  arc_capacity_697  1
    load_1_5_14  segment_load_conservation_968  1
    load_1_5_14  free_load_conservation_1009  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_15  arc_capacity_699  -25
    arc_1_5_15  connected_order_arc_700  -13
    arc_1_5_15  out_degree_964  1
    arc_1_5_15  in_degree_1011  1
    arc_1_5_15  original_T_including_depot_unload_1043  9.7453518552189382e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_5_15  arc_capacity_699  1
    load_1_5_15  segment_load_conservation_968  1
    load_1_5_15  free_load_conservation_1015  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_16  arc_capacity_701  -25
    arc_1_5_16  connected_order_arc_702  -13
    arc_1_5_16  out_degree_964  1
    arc_1_5_16  in_degree_1017  1
    arc_1_5_16  original_T_including_depot_unload_1043  1.6988291947636669e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_16  arc_capacity_701  1
    load_1_5_16  segment_load_conservation_968  1
    load_1_5_16  free_load_conservation_1021  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_17  arc_capacity_703  -25
    arc_1_5_17  connected_order_arc_704  -13
    arc_1_5_17  out_degree_964  1
    arc_1_5_17  in_degree_1023  1
    arc_1_5_17  original_T_including_depot_unload_1043  1.0321140782598593e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_17  arc_capacity_703  1
    load_1_5_17  segment_load_conservation_968  1
    load_1_5_17  free_load_conservation_1027  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_18  arc_capacity_705  -25
    arc_1_5_18  connected_order_arc_706  -13
    arc_1_5_18  out_degree_964  1
    arc_1_5_18  in_degree_1029  1
    arc_1_5_18  original_T_including_depot_unload_1043  1.6274520107532360e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_18  arc_capacity_705  1
    load_1_5_18  segment_load_conservation_968  1
    load_1_5_18  free_load_conservation_1033  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_19  arc_capacity_707  -25
    arc_1_5_19  connected_order_arc_708  -13
    arc_1_5_19  out_degree_964  1
    arc_1_5_19  in_degree_1035  1
    arc_1_5_19  original_T_including_depot_unload_1043  1.5356438916798834e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_19  arc_capacity_707  1
    load_1_5_19  segment_load_conservation_968  1
    load_1_5_19  free_load_conservation_1039  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_0  arc_capacity_709  -25
    arc_1_6_0  depot_return_or_bypass_963  1
    arc_1_6_0  out_degree_971  1
    arc_1_6_0  original_T_including_depot_unload_1043  1.4834116102542102e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_0  arc_capacity_709  1
    load_1_6_0  segment_load_conservation_975  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_5  arc_capacity_710  -25
    arc_1_6_5  connected_order_arc_711  -13
    arc_1_6_5  in_degree_965  1
    arc_1_6_5  out_degree_971  1
    arc_1_6_5  original_T_including_depot_unload_1043  2.1016283653335277e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_5  arc_capacity_710  1
    load_1_6_5  segment_load_conservation_968  -1
    load_1_6_5  segment_prefix_lb_969  1
    load_1_6_5  segment_prefix_ub_970  1
    load_1_6_5  segment_load_conservation_975  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_7  arc_capacity_712  -25
    arc_1_6_7  connected_order_arc_713  -13
    arc_1_6_7  out_degree_971  1
    arc_1_6_7  in_degree_979  1
    arc_1_6_7  original_T_including_depot_unload_1043  9.7352441264247466e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_7  arc_capacity_712  1
    load_1_6_7  segment_load_conservation_975  1
    load_1_6_7  segment_load_conservation_982  -1
    load_1_6_7  segment_prefix_lb_983  1
    load_1_6_7  segment_prefix_ub_984  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_8  arc_capacity_714  -25
    arc_1_6_8  connected_order_arc_715  -13
    arc_1_6_8  out_degree_971  1
    arc_1_6_8  in_degree_986  1
    arc_1_6_8  original_T_including_depot_unload_1043  1.2769578074048923e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_8  arc_capacity_714  1
    load_1_6_8  segment_load_conservation_975  1
    load_1_6_8  segment_load_conservation_989  -1
    load_1_6_8  segment_prefix_lb_990  1
    load_1_6_8  segment_prefix_ub_991  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_12  arc_capacity_716  -25
    arc_1_6_12  connected_order_arc_717  -13
    arc_1_6_12  out_degree_971  1
    arc_1_6_12  in_degree_993  1
    arc_1_6_12  original_T_including_depot_unload_1043  2.2758084421049020e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_12  arc_capacity_716  1
    load_1_6_12  segment_load_conservation_975  1
    load_1_6_12  free_load_conservation_997  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_13  arc_capacity_718  -25
    arc_1_6_13  connected_order_arc_719  -13
    arc_1_6_13  out_degree_971  1
    arc_1_6_13  in_degree_999  1
    arc_1_6_13  original_T_including_depot_unload_1043  2.4304747035816213e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_13  arc_capacity_718  1
    load_1_6_13  segment_load_conservation_975  1
    load_1_6_13  free_load_conservation_1003  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_14  arc_capacity_720  -25
    arc_1_6_14  connected_order_arc_721  -13
    arc_1_6_14  out_degree_971  1
    arc_1_6_14  in_degree_1005  1
    arc_1_6_14  original_T_including_depot_unload_1043  2.9790156048453791e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_14  arc_capacity_720  1
    load_1_6_14  segment_load_conservation_975  1
    load_1_6_14  free_load_conservation_1009  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_15  arc_capacity_722  -25
    arc_1_6_15  connected_order_arc_723  -13
    arc_1_6_15  out_degree_971  1
    arc_1_6_15  in_degree_1011  1
    arc_1_6_15  original_T_including_depot_unload_1043  2.4321008933612479e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_15  arc_capacity_722  1
    load_1_6_15  segment_load_conservation_975  1
    load_1_6_15  free_load_conservation_1015  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_16  arc_capacity_724  -25
    arc_1_6_16  connected_order_arc_725  -13
    arc_1_6_16  out_degree_971  1
    arc_1_6_16  in_degree_1017  1
    arc_1_6_16  original_T_including_depot_unload_1043  2.3444750474890211e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_16  arc_capacity_724  1
    load_1_6_16  segment_load_conservation_975  1
    load_1_6_16  free_load_conservation_1021  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_17  arc_capacity_726  -25
    arc_1_6_17  connected_order_arc_727  -13
    arc_1_6_17  out_degree_971  1
    arc_1_6_17  in_degree_1023  1
    arc_1_6_17  original_T_including_depot_unload_1043  1.9029099398713563e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_17  arc_capacity_726  1
    load_1_6_17  segment_load_conservation_975  1
    load_1_6_17  free_load_conservation_1027  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_18  arc_capacity_728  -25
    arc_1_6_18  connected_order_arc_729  -13
    arc_1_6_18  out_degree_971  1
    arc_1_6_18  in_degree_1029  1
    arc_1_6_18  original_T_including_depot_unload_1043  2.1806564621513235e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_18  arc_capacity_728  1
    load_1_6_18  segment_load_conservation_975  1
    load_1_6_18  free_load_conservation_1033  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_19  arc_capacity_730  -25
    arc_1_6_19  connected_order_arc_731  -13
    arc_1_6_19  out_degree_971  1
    arc_1_6_19  in_degree_1035  1
    arc_1_6_19  original_T_including_depot_unload_1043  1.9765601995118598e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_19  arc_capacity_730  1
    load_1_6_19  segment_load_conservation_975  1
    load_1_6_19  free_load_conservation_1039  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_0  arc_capacity_732  -25
    arc_1_7_0  depot_return_or_bypass_963  1
    arc_1_7_0  out_degree_978  1
    arc_1_7_0  original_T_including_depot_unload_1043  5.4911852608328161e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_0  arc_capacity_732  1
    load_1_7_0  segment_load_conservation_982  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_5  arc_capacity_733  -25
    arc_1_7_5  connected_order_arc_734  -13
    arc_1_7_5  in_degree_965  1
    arc_1_7_5  out_degree_978  1
    arc_1_7_5  original_T_including_depot_unload_1043  1.2739580769060942e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_5  arc_capacity_733  1
    load_1_7_5  segment_load_conservation_968  -1
    load_1_7_5  segment_prefix_lb_969  1
    load_1_7_5  segment_prefix_ub_970  1
    load_1_7_5  segment_load_conservation_982  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_6  arc_capacity_735  -25
    arc_1_7_6  connected_order_arc_736  -13
    arc_1_7_6  in_degree_972  1
    arc_1_7_6  out_degree_978  1
    arc_1_7_6  original_T_including_depot_unload_1043  2.9662284735332634e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_6  arc_capacity_735  1
    load_1_7_6  segment_load_conservation_975  -1
    load_1_7_6  segment_prefix_lb_976  1
    load_1_7_6  segment_prefix_ub_977  1
    load_1_7_6  segment_load_conservation_982  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_8  arc_capacity_737  -25
    arc_1_7_8  connected_order_arc_738  -13
    arc_1_7_8  out_degree_978  1
    arc_1_7_8  in_degree_986  1
    arc_1_7_8  original_T_including_depot_unload_1043  3.0614301781508658e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_8  arc_capacity_737  1
    load_1_7_8  segment_load_conservation_982  1
    load_1_7_8  segment_load_conservation_989  -1
    load_1_7_8  segment_prefix_lb_990  1
    load_1_7_8  segment_prefix_ub_991  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_12  arc_capacity_739  -25
    arc_1_7_12  connected_order_arc_740  -13
    arc_1_7_12  out_degree_978  1
    arc_1_7_12  in_degree_993  1
    arc_1_7_12  original_T_including_depot_unload_1043  1.3156708792004563e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_12  arc_capacity_739  1
    load_1_7_12  segment_load_conservation_982  1
    load_1_7_12  free_load_conservation_997  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_13  arc_capacity_741  -25
    arc_1_7_13  connected_order_arc_742  -13
    arc_1_7_13  out_degree_978  1
    arc_1_7_13  in_degree_999  1
    arc_1_7_13  original_T_including_depot_unload_1043  1.4570094449922669e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_13  arc_capacity_741  1
    load_1_7_13  segment_load_conservation_982  1
    load_1_7_13  free_load_conservation_1003  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_14  arc_capacity_743  -25
    arc_1_7_14  connected_order_arc_744  -13
    arc_1_7_14  out_degree_978  1
    arc_1_7_14  in_degree_1005  1
    arc_1_7_14  original_T_including_depot_unload_1043  2.1109553693139742e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_14  arc_capacity_743  1
    load_1_7_14  segment_load_conservation_982  1
    load_1_7_14  free_load_conservation_1009  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_15  arc_capacity_745  -25
    arc_1_7_15  connected_order_arc_746  -13
    arc_1_7_15  out_degree_978  1
    arc_1_7_15  in_degree_1011  1
    arc_1_7_15  original_T_including_depot_unload_1043  1.4586348268927468e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_15  arc_capacity_745  1
    load_1_7_15  segment_load_conservation_982  1
    load_1_7_15  free_load_conservation_1015  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_16  arc_capacity_747  -25
    arc_1_7_16  connected_order_arc_748  -13
    arc_1_7_16  out_degree_978  1
    arc_1_7_16  in_degree_1017  1
    arc_1_7_16  original_T_including_depot_unload_1043  1.4738339199468992e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_16  arc_capacity_747  1
    load_1_7_16  segment_load_conservation_982  1
    load_1_7_16  free_load_conservation_1021  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_17  arc_capacity_749  -25
    arc_1_7_17  connected_order_arc_750  -13
    arc_1_7_17  out_degree_978  1
    arc_1_7_17  in_degree_1023  1
    arc_1_7_17  original_T_including_depot_unload_1043  9.3836915476275669e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_17  arc_capacity_749  1
    load_1_7_17  segment_load_conservation_982  1
    load_1_7_17  free_load_conservation_1027  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_18  arc_capacity_751  -25
    arc_1_7_18  connected_order_arc_752  -13
    arc_1_7_18  out_degree_978  1
    arc_1_7_18  in_degree_1029  1
    arc_1_7_18  original_T_including_depot_unload_1043  1.3162040688959055e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_18  arc_capacity_751  1
    load_1_7_18  segment_load_conservation_982  1
    load_1_7_18  free_load_conservation_1033  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_19  arc_capacity_753  -25
    arc_1_7_19  connected_order_arc_754  -13
    arc_1_7_19  out_degree_978  1
    arc_1_7_19  in_degree_1035  1
    arc_1_7_19  original_T_including_depot_unload_1043  1.1150690045767951e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_19  arc_capacity_753  1
    load_1_7_19  segment_load_conservation_982  1
    load_1_7_19  free_load_conservation_1039  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_0  arc_capacity_755  -25
    arc_1_8_0  depot_return_or_bypass_963  1
    arc_1_8_0  out_degree_985  1
    arc_1_8_0  original_T_including_depot_unload_1043  3.5061909388980052e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_0  arc_capacity_755  1
    load_1_8_0  segment_load_conservation_989  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_5  arc_capacity_756  -25
    arc_1_8_5  connected_order_arc_757  -13
    arc_1_8_5  in_degree_965  1
    arc_1_8_5  out_degree_985  1
    arc_1_8_5  original_T_including_depot_unload_1043  1.0313568965059917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_5  arc_capacity_756  1
    load_1_8_5  segment_load_conservation_968  -1
    load_1_8_5  segment_prefix_lb_969  1
    load_1_8_5  segment_prefix_ub_970  1
    load_1_8_5  segment_load_conservation_989  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_6  arc_capacity_758  -25
    arc_1_8_6  connected_order_arc_759  -13
    arc_1_8_6  in_degree_972  1
    arc_1_8_6  out_degree_985  1
    arc_1_8_6  original_T_including_depot_unload_1043  3.7747736142736670e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_6  arc_capacity_758  1
    load_1_8_6  segment_load_conservation_975  -1
    load_1_8_6  segment_prefix_lb_976  1
    load_1_8_6  segment_prefix_ub_977  1
    load_1_8_6  segment_load_conservation_989  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_7  arc_capacity_760  -25
    arc_1_8_7  connected_order_arc_761  -13
    arc_1_8_7  in_degree_979  1
    arc_1_8_7  out_degree_985  1
    arc_1_8_7  original_T_including_depot_unload_1043  3.0614301781508658e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_7  arc_capacity_760  1
    load_1_8_7  segment_load_conservation_982  -1
    load_1_8_7  segment_prefix_lb_983  1
    load_1_8_7  segment_prefix_ub_984  1
    load_1_8_7  segment_load_conservation_989  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_12  arc_capacity_762  -25
    arc_1_8_12  connected_order_arc_763  -13
    arc_1_8_12  out_degree_985  1
    arc_1_8_12  in_degree_993  1
    arc_1_8_12  original_T_including_depot_unload_1043  1.0363838262442744e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_12  arc_capacity_762  1
    load_1_8_12  segment_load_conservation_989  1
    load_1_8_12  free_load_conservation_997  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_13  arc_capacity_764  -25
    arc_1_8_13  connected_order_arc_765  -13
    arc_1_8_13  out_degree_985  1
    arc_1_8_13  in_degree_999  1
    arc_1_8_13  original_T_including_depot_unload_1043  1.1545648513745866e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_13  arc_capacity_764  1
    load_1_8_13  segment_load_conservation_989  1
    load_1_8_13  free_load_conservation_1003  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_14  arc_capacity_766  -25
    arc_1_8_14  connected_order_arc_767  -13
    arc_1_8_14  out_degree_985  1
    arc_1_8_14  in_degree_1005  1
    arc_1_8_14  original_T_including_depot_unload_1043  1.8911324761641883e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_14  arc_capacity_766  1
    load_1_8_14  segment_load_conservation_989  1
    load_1_8_14  free_load_conservation_1009  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_15  arc_capacity_768  -25
    arc_1_8_15  connected_order_arc_769  -13
    arc_1_8_15  out_degree_985  1
    arc_1_8_15  in_degree_1011  1
    arc_1_8_15  original_T_including_depot_unload_1043  1.1561945146971345e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_15  arc_capacity_768  1
    load_1_8_15  segment_load_conservation_989  1
    load_1_8_15  free_load_conservation_1015  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_16  arc_capacity_770  -25
    arc_1_8_16  connected_order_arc_771  -13
    arc_1_8_16  out_degree_985  1
    arc_1_8_16  in_degree_1017  1
    arc_1_8_16  original_T_including_depot_unload_1043  1.2665309635243570e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_16  arc_capacity_770  1
    load_1_8_16  segment_load_conservation_989  1
    load_1_8_16  free_load_conservation_1021  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_17  arc_capacity_772  -25
    arc_1_8_17  connected_order_arc_773  -13
    arc_1_8_17  out_degree_985  1
    arc_1_8_17  in_degree_1023  1
    arc_1_8_17  original_T_including_depot_unload_1043  6.5869285599668615e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_17  arc_capacity_772  1
    load_1_8_17  segment_load_conservation_989  1
    load_1_8_17  free_load_conservation_1027  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_18  arc_capacity_774  -25
    arc_1_8_18  connected_order_arc_775  -13
    arc_1_8_18  out_degree_985  1
    arc_1_8_18  in_degree_1029  1
    arc_1_8_18  original_T_including_depot_unload_1043  1.1193870869231816e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_18  arc_capacity_774  1
    load_1_8_18  segment_load_conservation_989  1
    load_1_8_18  free_load_conservation_1033  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_19  arc_capacity_776  -25
    arc_1_8_19  connected_order_arc_777  -13
    arc_1_8_19  out_degree_985  1
    arc_1_8_19  in_degree_1035  1
    arc_1_8_19  original_T_including_depot_unload_1043  9.3137133767849343e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_19  arc_capacity_776  1
    load_1_8_19  segment_load_conservation_989  1
    load_1_8_19  free_load_conservation_1039  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_0  arc_capacity_778  -25
    arc_1_12_0  depot_return_or_bypass_963  1
    arc_1_12_0  out_degree_992  1
    arc_1_12_0  original_T_including_depot_unload_1043  7.9650294035968375e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_0  arc_capacity_778  1
    load_1_12_0  free_load_conservation_997  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_5  arc_capacity_779  -25
    arc_1_12_5  connected_order_arc_780  -13
    arc_1_12_5  in_degree_965  1
    arc_1_12_5  out_degree_992  1
    arc_1_12_5  original_T_including_depot_unload_1043  1.1851786693030479e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_5  arc_capacity_779  1
    load_1_12_5  segment_load_conservation_968  -1
    load_1_12_5  segment_prefix_lb_969  1
    load_1_12_5  segment_prefix_ub_970  1
    load_1_12_5  free_load_conservation_997  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_6  arc_capacity_781  -25
    arc_1_12_6  connected_order_arc_782  -13
    arc_1_12_6  in_degree_972  1
    arc_1_12_6  out_degree_992  1
    arc_1_12_6  original_T_including_depot_unload_1043  1.3923205390152336e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_6  arc_capacity_781  1
    load_1_12_6  segment_load_conservation_975  -1
    load_1_12_6  segment_prefix_lb_976  1
    load_1_12_6  segment_prefix_ub_977  1
    load_1_12_6  free_load_conservation_997  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_7  arc_capacity_783  -25
    arc_1_12_7  connected_order_arc_784  -13
    arc_1_12_7  in_degree_979  1
    arc_1_12_7  out_degree_992  1
    arc_1_12_7  original_T_including_depot_unload_1043  1.3156708792004563e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_7  arc_capacity_783  1
    load_1_12_7  segment_load_conservation_982  -1
    load_1_12_7  segment_prefix_lb_983  1
    load_1_12_7  segment_prefix_ub_984  1
    load_1_12_7  free_load_conservation_997  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_8  arc_capacity_785  -25
    arc_1_12_8  connected_order_arc_786  -13
    arc_1_12_8  in_degree_986  1
    arc_1_12_8  out_degree_992  1
    arc_1_12_8  original_T_including_depot_unload_1043  1.0363838262442744e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_8  arc_capacity_785  1
    load_1_12_8  segment_load_conservation_989  -1
    load_1_12_8  segment_prefix_lb_990  1
    load_1_12_8  segment_prefix_ub_991  1
    load_1_12_8  free_load_conservation_997  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_13  arc_capacity_787  -25
    arc_1_12_13  connected_order_arc_788  -13
    arc_1_12_13  out_degree_992  1
    arc_1_12_13  in_degree_999  1
    arc_1_12_13  original_T_including_depot_unload_1043  3.5166546157461704e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_13  arc_capacity_787  1
    load_1_12_13  free_load_conservation_997  1
    load_1_12_13  free_load_conservation_1003  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_14  arc_capacity_789  -25
    arc_1_12_14  connected_order_arc_790  -13
    arc_1_12_14  out_degree_992  1
    arc_1_12_14  in_degree_1005  1
    arc_1_12_14  original_T_including_depot_unload_1043  9.8108674361469946e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_14  arc_capacity_789  1
    load_1_12_14  free_load_conservation_997  1
    load_1_12_14  free_load_conservation_1009  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_15  arc_capacity_791  -25
    arc_1_12_15  connected_order_arc_792  -13
    arc_1_12_15  out_degree_992  1
    arc_1_12_15  in_degree_1011  1
    arc_1_12_15  original_T_including_depot_unload_1043  3.5235932354279930e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_15  arc_capacity_791  1
    load_1_12_15  free_load_conservation_997  1
    load_1_12_15  free_load_conservation_1015  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_16  arc_capacity_793  -25
    arc_1_12_16  connected_order_arc_794  -13
    arc_1_12_16  out_degree_992  1
    arc_1_12_16  in_degree_1017  1
    arc_1_12_16  original_T_including_depot_unload_1043  5.4405628017126674e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_16  arc_capacity_793  1
    load_1_12_16  free_load_conservation_997  1
    load_1_12_16  free_load_conservation_1021  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_17  arc_capacity_795  -25
    arc_1_12_17  connected_order_arc_796  -13
    arc_1_12_17  out_degree_992  1
    arc_1_12_17  in_degree_1023  1
    arc_1_12_17  original_T_including_depot_unload_1043  3.7831268047064754e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_17  arc_capacity_795  1
    load_1_12_17  free_load_conservation_997  1
    load_1_12_17  free_load_conservation_1027  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_18  arc_capacity_797  -25
    arc_1_12_18  connected_order_arc_798  -13
    arc_1_12_18  out_degree_992  1
    arc_1_12_18  in_degree_1029  1
    arc_1_12_18  original_T_including_depot_unload_1043  5.3348116005684176e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_18  arc_capacity_797  1
    load_1_12_18  free_load_conservation_997  1
    load_1_12_18  free_load_conservation_1033  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_19  arc_capacity_799  -25
    arc_1_12_19  connected_order_arc_800  -13
    arc_1_12_19  out_degree_992  1
    arc_1_12_19  in_degree_1035  1
    arc_1_12_19  original_T_including_depot_unload_1043  566.256001718161
    MARKER    'MARKER'                 'INTEND'
    load_1_12_19  arc_capacity_799  1
    load_1_12_19  free_load_conservation_997  1
    load_1_12_19  free_load_conservation_1039  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_0  arc_capacity_801  -25
    arc_1_13_0  depot_return_or_bypass_963  1
    arc_1_13_0  out_degree_998  1
    arc_1_13_0  original_T_including_depot_unload_1043  1.0056399980521732e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_0  arc_capacity_801  1
    load_1_13_0  free_load_conservation_1003  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_5  arc_capacity_802  -25
    arc_1_13_5  connected_order_arc_803  -13
    arc_1_13_5  in_degree_965  1
    arc_1_13_5  out_degree_998  1
    arc_1_13_5  original_T_including_depot_unload_1043  9.7357850164388731e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_5  arc_capacity_802  1
    load_1_13_5  segment_load_conservation_968  -1
    load_1_13_5  segment_prefix_lb_969  1
    load_1_13_5  segment_prefix_ub_970  1
    load_1_13_5  free_load_conservation_1003  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_6  arc_capacity_804  -25
    arc_1_13_6  connected_order_arc_805  -13
    arc_1_13_6  in_degree_972  1
    arc_1_13_6  out_degree_998  1
    arc_1_13_6  original_T_including_depot_unload_1043  1.4636929855741182e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_6  arc_capacity_804  1
    load_1_13_6  segment_load_conservation_975  -1
    load_1_13_6  segment_prefix_lb_976  1
    load_1_13_6  segment_prefix_ub_977  1
    load_1_13_6  free_load_conservation_1003  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_7  arc_capacity_806  -25
    arc_1_13_7  connected_order_arc_807  -13
    arc_1_13_7  in_degree_979  1
    arc_1_13_7  out_degree_998  1
    arc_1_13_7  original_T_including_depot_unload_1043  1.4570094449922669e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_7  arc_capacity_806  1
    load_1_13_7  segment_load_conservation_982  -1
    load_1_13_7  segment_prefix_lb_983  1
    load_1_13_7  segment_prefix_ub_984  1
    load_1_13_7  free_load_conservation_1003  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_8  arc_capacity_808  -25
    arc_1_13_8  connected_order_arc_809  -13
    arc_1_13_8  in_degree_986  1
    arc_1_13_8  out_degree_998  1
    arc_1_13_8  original_T_including_depot_unload_1043  1.1545648513745866e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_8  arc_capacity_808  1
    load_1_13_8  segment_load_conservation_989  -1
    load_1_13_8  segment_prefix_lb_990  1
    load_1_13_8  segment_prefix_ub_991  1
    load_1_13_8  free_load_conservation_1003  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_12  arc_capacity_810  -25
    arc_1_13_12  connected_order_arc_811  -13
    arc_1_13_12  in_degree_993  1
    arc_1_13_12  out_degree_998  1
    arc_1_13_12  original_T_including_depot_unload_1043  3.5166546157461704e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_12  arc_capacity_810  1
    load_1_13_12  free_load_conservation_997  -1
    load_1_13_12  free_load_conservation_1003  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_14  arc_capacity_812  -25
    arc_1_13_14  connected_order_arc_813  -13
    arc_1_13_14  out_degree_998  1
    arc_1_13_14  in_degree_1005  1
    arc_1_13_14  original_T_including_depot_unload_1043  1.1967280409234234e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_14  arc_capacity_812  1
    load_1_13_14  free_load_conservation_1003  1
    load_1_13_14  free_load_conservation_1009  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_15  arc_capacity_814  -25
    arc_1_13_15  connected_order_arc_815  -13
    arc_1_13_15  out_degree_998  1
    arc_1_13_15  in_degree_1011  1
    arc_1_13_15  original_T_including_depot_unload_1043  1.6320002720932780e+00
    MARKER    'MARKER'                 'INTEND'
    load_1_13_15  arc_capacity_814  1
    load_1_13_15  free_load_conservation_1003  1
    load_1_13_15  free_load_conservation_1015  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_16  arc_capacity_816  -25
    arc_1_13_16  connected_order_arc_817  -13
    arc_1_13_16  out_degree_998  1
    arc_1_13_16  in_degree_1017  1
    arc_1_13_16  original_T_including_depot_unload_1043  8.7906342149593650e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_16  arc_capacity_816  1
    load_1_13_16  free_load_conservation_1003  1
    load_1_13_16  free_load_conservation_1021  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_17  arc_capacity_818  -25
    arc_1_13_17  connected_order_arc_819  -13
    arc_1_13_17  out_degree_998  1
    arc_1_13_17  in_degree_1023  1
    arc_1_13_17  original_T_including_depot_unload_1043  5.7276146581216926e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_17  arc_capacity_818  1
    load_1_13_17  free_load_conservation_1003  1
    load_1_13_17  free_load_conservation_1027  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_18  arc_capacity_820  -25
    arc_1_13_18  connected_order_arc_821  -13
    arc_1_13_18  out_degree_998  1
    arc_1_13_18  in_degree_1029  1
    arc_1_13_18  original_T_including_depot_unload_1043  8.8427037135592116e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_18  arc_capacity_820  1
    load_1_13_18  free_load_conservation_1003  1
    load_1_13_18  free_load_conservation_1033  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_19  arc_capacity_822  -25
    arc_1_13_19  connected_order_arc_823  -13
    arc_1_13_19  out_degree_998  1
    arc_1_13_19  in_degree_1035  1
    arc_1_13_19  original_T_including_depot_unload_1043  9.0947747566405189e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_19  arc_capacity_822  1
    load_1_13_19  free_load_conservation_1003  1
    load_1_13_19  free_load_conservation_1039  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_0  arc_capacity_824  -25
    arc_1_14_0  depot_return_or_bypass_963  1
    arc_1_14_0  out_degree_1004  1
    arc_1_14_0  original_T_including_depot_unload_1043  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_0  arc_capacity_824  1
    load_1_14_0  free_load_conservation_1009  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_5  arc_capacity_825  -25
    arc_1_14_5  connected_order_arc_826  -13
    arc_1_14_5  in_degree_965  1
    arc_1_14_5  out_degree_1004  1
    arc_1_14_5  original_T_including_depot_unload_1043  2.1501600514850211e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_5  arc_capacity_825  1
    load_1_14_5  segment_load_conservation_968  -1
    load_1_14_5  segment_prefix_lb_969  1
    load_1_14_5  segment_prefix_ub_970  1
    load_1_14_5  free_load_conservation_1009  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_6  arc_capacity_827  -25
    arc_1_14_6  connected_order_arc_828  -13
    arc_1_14_6  in_degree_972  1
    arc_1_14_6  out_degree_1004  1
    arc_1_14_6  original_T_including_depot_unload_1043  2.2682175936128497e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_6  arc_capacity_827  1
    load_1_14_6  segment_load_conservation_975  -1
    load_1_14_6  segment_prefix_lb_976  1
    load_1_14_6  segment_prefix_ub_977  1
    load_1_14_6  free_load_conservation_1009  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_7  arc_capacity_829  -25
    arc_1_14_7  connected_order_arc_830  -13
    arc_1_14_7  in_degree_979  1
    arc_1_14_7  out_degree_1004  1
    arc_1_14_7  original_T_including_depot_unload_1043  2.1109553693139742e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_7  arc_capacity_829  1
    load_1_14_7  segment_load_conservation_982  -1
    load_1_14_7  segment_prefix_lb_983  1
    load_1_14_7  segment_prefix_ub_984  1
    load_1_14_7  free_load_conservation_1009  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_8  arc_capacity_831  -25
    arc_1_14_8  connected_order_arc_832  -13
    arc_1_14_8  in_degree_986  1
    arc_1_14_8  out_degree_1004  1
    arc_1_14_8  original_T_including_depot_unload_1043  1.8911324761641883e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_8  arc_capacity_831  1
    load_1_14_8  segment_load_conservation_989  -1
    load_1_14_8  segment_prefix_lb_990  1
    load_1_14_8  segment_prefix_ub_991  1
    load_1_14_8  free_load_conservation_1009  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_12  arc_capacity_833  -25
    arc_1_14_12  connected_order_arc_834  -13
    arc_1_14_12  in_degree_993  1
    arc_1_14_12  out_degree_1004  1
    arc_1_14_12  original_T_including_depot_unload_1043  9.8108674361469946e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_12  arc_capacity_833  1
    load_1_14_12  free_load_conservation_997  -1
    load_1_14_12  free_load_conservation_1009  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_13  arc_capacity_835  -25
    arc_1_14_13  connected_order_arc_836  -13
    arc_1_14_13  in_degree_999  1
    arc_1_14_13  out_degree_1004  1
    arc_1_14_13  original_T_including_depot_unload_1043  1.1967280409234234e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_13  arc_capacity_835  1
    load_1_14_13  free_load_conservation_1003  -1
    load_1_14_13  free_load_conservation_1009  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_15  arc_capacity_837  -25
    arc_1_14_15  connected_order_arc_838  -13
    arc_1_14_15  out_degree_1004  1
    arc_1_14_15  in_degree_1011  1
    arc_1_14_15  original_T_including_depot_unload_1043  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_15  arc_capacity_837  1
    load_1_14_15  free_load_conservation_1009  1
    load_1_14_15  free_load_conservation_1015  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_16  arc_capacity_839  -25
    arc_1_14_16  connected_order_arc_840  -13
    arc_1_14_16  out_degree_1004  1
    arc_1_14_16  in_degree_1017  1
    arc_1_14_16  original_T_including_depot_unload_1043  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_1_14_16  arc_capacity_839  1
    load_1_14_16  free_load_conservation_1009  1
    load_1_14_16  free_load_conservation_1021  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_17  arc_capacity_841  -25
    arc_1_14_17  connected_order_arc_842  -13
    arc_1_14_17  out_degree_1004  1
    arc_1_14_17  in_degree_1023  1
    arc_1_14_17  original_T_including_depot_unload_1043  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_17  arc_capacity_841  1
    load_1_14_17  free_load_conservation_1009  1
    load_1_14_17  free_load_conservation_1027  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_18  arc_capacity_843  -25
    arc_1_14_18  connected_order_arc_844  -13
    arc_1_14_18  out_degree_1004  1
    arc_1_14_18  in_degree_1029  1
    arc_1_14_18  original_T_including_depot_unload_1043  8.0139063451811444e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_18  arc_capacity_843  1
    load_1_14_18  free_load_conservation_1009  1
    load_1_14_18  free_load_conservation_1033  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_19  arc_capacity_845  -25
    arc_1_14_19  connected_order_arc_846  -13
    arc_1_14_19  out_degree_1004  1
    arc_1_14_19  in_degree_1035  1
    arc_1_14_19  original_T_including_depot_unload_1043  1.0063298732365655e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_19  arc_capacity_845  1
    load_1_14_19  free_load_conservation_1009  1
    load_1_14_19  free_load_conservation_1039  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_0  arc_capacity_847  -25
    arc_1_15_0  depot_return_or_bypass_963  1
    arc_1_15_0  out_degree_1010  1
    arc_1_15_0  original_T_including_depot_unload_1043  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_0  arc_capacity_847  1
    load_1_15_0  free_load_conservation_1015  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_5  arc_capacity_848  -25
    arc_1_15_5  connected_order_arc_849  -13
    arc_1_15_5  in_degree_965  1
    arc_1_15_5  out_degree_1010  1
    arc_1_15_5  original_T_including_depot_unload_1043  9.7453518552189382e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_5  arc_capacity_848  1
    load_1_15_5  segment_load_conservation_968  -1
    load_1_15_5  segment_prefix_lb_969  1
    load_1_15_5  segment_prefix_ub_970  1
    load_1_15_5  free_load_conservation_1015  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_6  arc_capacity_850  -25
    arc_1_15_6  connected_order_arc_851  -13
    arc_1_15_6  in_degree_972  1
    arc_1_15_6  out_degree_1010  1
    arc_1_15_6  original_T_including_depot_unload_1043  1.4653145381016172e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_6  arc_capacity_850  1
    load_1_15_6  segment_load_conservation_975  -1
    load_1_15_6  segment_prefix_lb_976  1
    load_1_15_6  segment_prefix_ub_977  1
    load_1_15_6  free_load_conservation_1015  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_7  arc_capacity_852  -25
    arc_1_15_7  connected_order_arc_853  -13
    arc_1_15_7  in_degree_979  1
    arc_1_15_7  out_degree_1010  1
    arc_1_15_7  original_T_including_depot_unload_1043  1.4586348268927468e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_7  arc_capacity_852  1
    load_1_15_7  segment_load_conservation_982  -1
    load_1_15_7  segment_prefix_lb_983  1
    load_1_15_7  segment_prefix_ub_984  1
    load_1_15_7  free_load_conservation_1015  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_8  arc_capacity_854  -25
    arc_1_15_8  connected_order_arc_855  -13
    arc_1_15_8  in_degree_986  1
    arc_1_15_8  out_degree_1010  1
    arc_1_15_8  original_T_including_depot_unload_1043  1.1561945146971345e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_8  arc_capacity_854  1
    load_1_15_8  segment_load_conservation_989  -1
    load_1_15_8  segment_prefix_lb_990  1
    load_1_15_8  segment_prefix_ub_991  1
    load_1_15_8  free_load_conservation_1015  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_12  arc_capacity_856  -25
    arc_1_15_12  connected_order_arc_857  -13
    arc_1_15_12  in_degree_993  1
    arc_1_15_12  out_degree_1010  1
    arc_1_15_12  original_T_including_depot_unload_1043  3.5235932354279930e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_12  arc_capacity_856  1
    load_1_15_12  free_load_conservation_997  -1
    load_1_15_12  free_load_conservation_1015  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_13  arc_capacity_858  -25
    arc_1_15_13  connected_order_arc_859  -13
    arc_1_15_13  in_degree_999  1
    arc_1_15_13  out_degree_1010  1
    arc_1_15_13  original_T_including_depot_unload_1043  1.6320002720932780e+00
    MARKER    'MARKER'                 'INTEND'
    load_1_15_13  arc_capacity_858  1
    load_1_15_13  free_load_conservation_1003  -1
    load_1_15_13  free_load_conservation_1015  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_14  arc_capacity_860  -25
    arc_1_15_14  connected_order_arc_861  -13
    arc_1_15_14  in_degree_1005  1
    arc_1_15_14  out_degree_1010  1
    arc_1_15_14  original_T_including_depot_unload_1043  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_14  arc_capacity_860  1
    load_1_15_14  free_load_conservation_1009  -1
    load_1_15_14  free_load_conservation_1015  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_16  arc_capacity_862  -25
    arc_1_15_16  connected_order_arc_863  -13
    arc_1_15_16  out_degree_1010  1
    arc_1_15_16  in_degree_1017  1
    arc_1_15_16  original_T_including_depot_unload_1043  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_16  arc_capacity_862  1
    load_1_15_16  free_load_conservation_1015  1
    load_1_15_16  free_load_conservation_1021  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_17  arc_capacity_864  -25
    arc_1_15_17  connected_order_arc_865  -13
    arc_1_15_17  out_degree_1010  1
    arc_1_15_17  in_degree_1023  1
    arc_1_15_17  original_T_including_depot_unload_1043  5.7424143497696048e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_17  arc_capacity_864  1
    load_1_15_17  free_load_conservation_1015  1
    load_1_15_17  free_load_conservation_1027  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_18  arc_capacity_866  -25
    arc_1_15_18  connected_order_arc_867  -13
    arc_1_15_18  out_degree_1010  1
    arc_1_15_18  in_degree_1029  1
    arc_1_15_18  original_T_including_depot_unload_1043  8.8488037837239642e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_18  arc_capacity_866  1
    load_1_15_18  free_load_conservation_1015  1
    load_1_15_18  free_load_conservation_1033  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_19  arc_capacity_868  -25
    arc_1_15_19  connected_order_arc_869  -13
    arc_1_15_19  out_degree_1010  1
    arc_1_15_19  in_degree_1035  1
    arc_1_15_19  original_T_including_depot_unload_1043  9.1041274142057227e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_19  arc_capacity_868  1
    load_1_15_19  free_load_conservation_1015  1
    load_1_15_19  free_load_conservation_1039  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_0  arc_capacity_870  -25
    arc_1_16_0  depot_return_or_bypass_963  1
    arc_1_16_0  out_degree_1016  1
    arc_1_16_0  original_T_including_depot_unload_1043  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_0  arc_capacity_870  1
    load_1_16_0  free_load_conservation_1021  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_5  arc_capacity_871  -25
    arc_1_16_5  connected_order_arc_872  -13
    arc_1_16_5  in_degree_965  1
    arc_1_16_5  out_degree_1016  1
    arc_1_16_5  original_T_including_depot_unload_1043  1.6988291947636669e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_5  arc_capacity_871  1
    load_1_16_5  segment_load_conservation_968  -1
    load_1_16_5  segment_prefix_lb_969  1
    load_1_16_5  segment_prefix_ub_970  1
    load_1_16_5  free_load_conservation_1021  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_6  arc_capacity_873  -25
    arc_1_16_6  connected_order_arc_874  -13
    arc_1_16_6  in_degree_972  1
    arc_1_16_6  out_degree_1016  1
    arc_1_16_6  original_T_including_depot_unload_1043  1.6437981048195304e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_6  arc_capacity_873  1
    load_1_16_6  segment_load_conservation_975  -1
    load_1_16_6  segment_prefix_lb_976  1
    load_1_16_6  segment_prefix_ub_977  1
    load_1_16_6  free_load_conservation_1021  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_7  arc_capacity_875  -25
    arc_1_16_7  connected_order_arc_876  -13
    arc_1_16_7  in_degree_979  1
    arc_1_16_7  out_degree_1016  1
    arc_1_16_7  original_T_including_depot_unload_1043  1.4738339199468992e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_7  arc_capacity_875  1
    load_1_16_7  segment_load_conservation_982  -1
    load_1_16_7  segment_prefix_lb_983  1
    load_1_16_7  segment_prefix_ub_984  1
    load_1_16_7  free_load_conservation_1021  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_8  arc_capacity_877  -25
    arc_1_16_8  connected_order_arc_878  -13
    arc_1_16_8  in_degree_986  1
    arc_1_16_8  out_degree_1016  1
    arc_1_16_8  original_T_including_depot_unload_1043  1.2665309635243570e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_8  arc_capacity_877  1
    load_1_16_8  segment_load_conservation_989  -1
    load_1_16_8  segment_prefix_lb_990  1
    load_1_16_8  segment_prefix_ub_991  1
    load_1_16_8  free_load_conservation_1021  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_12  arc_capacity_879  -25
    arc_1_16_12  connected_order_arc_880  -13
    arc_1_16_12  in_degree_993  1
    arc_1_16_12  out_degree_1016  1
    arc_1_16_12  original_T_including_depot_unload_1043  5.4405628017126674e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_12  arc_capacity_879  1
    load_1_16_12  free_load_conservation_997  -1
    load_1_16_12  free_load_conservation_1021  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_13  arc_capacity_881  -25
    arc_1_16_13  connected_order_arc_882  -13
    arc_1_16_13  in_degree_999  1
    arc_1_16_13  out_degree_1016  1
    arc_1_16_13  original_T_including_depot_unload_1043  8.7906342149593650e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_13  arc_capacity_881  1
    load_1_16_13  free_load_conservation_1003  -1
    load_1_16_13  free_load_conservation_1021  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_14  arc_capacity_883  -25
    arc_1_16_14  connected_order_arc_884  -13
    arc_1_16_14  in_degree_1005  1
    arc_1_16_14  out_degree_1016  1
    arc_1_16_14  original_T_including_depot_unload_1043  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_1_16_14  arc_capacity_883  1
    load_1_16_14  free_load_conservation_1009  -1
    load_1_16_14  free_load_conservation_1021  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_15  arc_capacity_885  -25
    arc_1_16_15  connected_order_arc_886  -13
    arc_1_16_15  in_degree_1011  1
    arc_1_16_15  out_degree_1016  1
    arc_1_16_15  original_T_including_depot_unload_1043  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_15  arc_capacity_885  1
    load_1_16_15  free_load_conservation_1015  -1
    load_1_16_15  free_load_conservation_1021  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_17  arc_capacity_887  -25
    arc_1_16_17  connected_order_arc_888  -13
    arc_1_16_17  out_degree_1016  1
    arc_1_16_17  in_degree_1023  1
    arc_1_16_17  original_T_including_depot_unload_1043  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_1_16_17  arc_capacity_887  1
    load_1_16_17  free_load_conservation_1021  1
    load_1_16_17  free_load_conservation_1027  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_18  arc_capacity_889  -25
    arc_1_16_18  connected_order_arc_890  -13
    arc_1_16_18  out_degree_1016  1
    arc_1_16_18  in_degree_1029  1
    arc_1_16_18  original_T_including_depot_unload_1043  1.6388081578301370e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_18  arc_capacity_889  1
    load_1_16_18  free_load_conservation_1021  1
    load_1_16_18  free_load_conservation_1033  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_19  arc_capacity_891  -25
    arc_1_16_19  connected_order_arc_892  -13
    arc_1_16_19  out_degree_1016  1
    arc_1_16_19  in_degree_1035  1
    arc_1_16_19  original_T_including_depot_unload_1043  3.6822662782562685e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_19  arc_capacity_891  1
    load_1_16_19  free_load_conservation_1021  1
    load_1_16_19  free_load_conservation_1039  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_0  arc_capacity_893  -25
    arc_1_17_0  depot_return_or_bypass_963  1
    arc_1_17_0  out_degree_1022  1
    arc_1_17_0  original_T_including_depot_unload_1043  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_0  arc_capacity_893  1
    load_1_17_0  free_load_conservation_1027  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_5  arc_capacity_894  -25
    arc_1_17_5  connected_order_arc_895  -13
    arc_1_17_5  in_degree_965  1
    arc_1_17_5  out_degree_1022  1
    arc_1_17_5  original_T_including_depot_unload_1043  1.0321140782598593e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_5  arc_capacity_894  1
    load_1_17_5  segment_load_conservation_968  -1
    load_1_17_5  segment_prefix_lb_969  1
    load_1_17_5  segment_prefix_ub_970  1
    load_1_17_5  free_load_conservation_1027  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_6  arc_capacity_896  -25
    arc_1_17_6  connected_order_arc_897  -13
    arc_1_17_6  in_degree_972  1
    arc_1_17_6  out_degree_1022  1
    arc_1_17_6  original_T_including_depot_unload_1043  1.0198535056659911e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_6  arc_capacity_896  1
    load_1_17_6  segment_load_conservation_975  -1
    load_1_17_6  segment_prefix_lb_976  1
    load_1_17_6  segment_prefix_ub_977  1
    load_1_17_6  free_load_conservation_1027  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_7  arc_capacity_898  -25
    arc_1_17_7  connected_order_arc_899  -13
    arc_1_17_7  in_degree_979  1
    arc_1_17_7  out_degree_1022  1
    arc_1_17_7  original_T_including_depot_unload_1043  9.3836915476275669e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_7  arc_capacity_898  1
    load_1_17_7  segment_load_conservation_982  -1
    load_1_17_7  segment_prefix_lb_983  1
    load_1_17_7  segment_prefix_ub_984  1
    load_1_17_7  free_load_conservation_1027  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_8  arc_capacity_900  -25
    arc_1_17_8  connected_order_arc_901  -13
    arc_1_17_8  in_degree_986  1
    arc_1_17_8  out_degree_1022  1
    arc_1_17_8  original_T_including_depot_unload_1043  6.5869285599668615e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_8  arc_capacity_900  1
    load_1_17_8  segment_load_conservation_989  -1
    load_1_17_8  segment_prefix_lb_990  1
    load_1_17_8  segment_prefix_ub_991  1
    load_1_17_8  free_load_conservation_1027  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_12  arc_capacity_902  -25
    arc_1_17_12  connected_order_arc_903  -13
    arc_1_17_12  in_degree_993  1
    arc_1_17_12  out_degree_1022  1
    arc_1_17_12  original_T_including_depot_unload_1043  3.7831268047064754e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_12  arc_capacity_902  1
    load_1_17_12  free_load_conservation_997  -1
    load_1_17_12  free_load_conservation_1027  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_13  arc_capacity_904  -25
    arc_1_17_13  connected_order_arc_905  -13
    arc_1_17_13  in_degree_999  1
    arc_1_17_13  out_degree_1022  1
    arc_1_17_13  original_T_including_depot_unload_1043  5.7276146581216926e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_13  arc_capacity_904  1
    load_1_17_13  free_load_conservation_1003  -1
    load_1_17_13  free_load_conservation_1027  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_14  arc_capacity_906  -25
    arc_1_17_14  connected_order_arc_907  -13
    arc_1_17_14  in_degree_1005  1
    arc_1_17_14  out_degree_1022  1
    arc_1_17_14  original_T_including_depot_unload_1043  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_14  arc_capacity_906  1
    load_1_17_14  free_load_conservation_1009  -1
    load_1_17_14  free_load_conservation_1027  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_15  arc_capacity_908  -25
    arc_1_17_15  connected_order_arc_909  -13
    arc_1_17_15  in_degree_1011  1
    arc_1_17_15  out_degree_1022  1
    arc_1_17_15  original_T_including_depot_unload_1043  5.7424143497696048e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_15  arc_capacity_908  1
    load_1_17_15  free_load_conservation_1015  -1
    load_1_17_15  free_load_conservation_1027  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_16  arc_capacity_910  -25
    arc_1_17_16  connected_order_arc_911  -13
    arc_1_17_16  in_degree_1017  1
    arc_1_17_16  out_degree_1022  1
    arc_1_17_16  original_T_including_depot_unload_1043  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_1_17_16  arc_capacity_910  1
    load_1_17_16  free_load_conservation_1021  -1
    load_1_17_16  free_load_conservation_1027  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_18  arc_capacity_912  -25
    arc_1_17_18  connected_order_arc_913  -13
    arc_1_17_18  out_degree_1022  1
    arc_1_17_18  in_degree_1029  1
    arc_1_17_18  original_T_including_depot_unload_1043  608.963327854777
    MARKER    'MARKER'                 'INTEND'
    load_1_17_18  arc_capacity_912  1
    load_1_17_18  free_load_conservation_1027  1
    load_1_17_18  free_load_conservation_1033  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_19  arc_capacity_914  -25
    arc_1_17_19  connected_order_arc_915  -13
    arc_1_17_19  out_degree_1022  1
    arc_1_17_19  in_degree_1035  1
    arc_1_17_19  original_T_including_depot_unload_1043  5.0398976026149836e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_19  arc_capacity_914  1
    load_1_17_19  free_load_conservation_1027  1
    load_1_17_19  free_load_conservation_1039  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_0  arc_capacity_916  -25
    arc_1_18_0  depot_return_or_bypass_963  1
    arc_1_18_0  out_degree_1028  1
    arc_1_18_0  original_T_including_depot_unload_1043  778.011461754062
    MARKER    'MARKER'                 'INTEND'
    load_1_18_0  arc_capacity_916  1
    load_1_18_0  free_load_conservation_1033  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_5  arc_capacity_917  -25
    arc_1_18_5  connected_order_arc_918  -13
    arc_1_18_5  in_degree_965  1
    arc_1_18_5  out_degree_1028  1
    arc_1_18_5  original_T_including_depot_unload_1043  1.6274520107532360e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_5  arc_capacity_917  1
    load_1_18_5  segment_load_conservation_968  -1
    load_1_18_5  segment_prefix_lb_969  1
    load_1_18_5  segment_prefix_ub_970  1
    load_1_18_5  free_load_conservation_1033  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_6  arc_capacity_919  -25
    arc_1_18_6  connected_order_arc_920  -13
    arc_1_18_6  in_degree_972  1
    arc_1_18_6  out_degree_1028  1
    arc_1_18_6  original_T_including_depot_unload_1043  1.4954919447603527e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_6  arc_capacity_919  1
    load_1_18_6  segment_load_conservation_975  -1
    load_1_18_6  segment_prefix_lb_976  1
    load_1_18_6  segment_prefix_ub_977  1
    load_1_18_6  free_load_conservation_1033  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_7  arc_capacity_921  -25
    arc_1_18_7  connected_order_arc_922  -13
    arc_1_18_7  in_degree_979  1
    arc_1_18_7  out_degree_1028  1
    arc_1_18_7  original_T_including_depot_unload_1043  1.3162040688959055e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_7  arc_capacity_921  1
    load_1_18_7  segment_load_conservation_982  -1
    load_1_18_7  segment_prefix_lb_983  1
    load_1_18_7  segment_prefix_ub_984  1
    load_1_18_7  free_load_conservation_1033  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_8  arc_capacity_923  -25
    arc_1_18_8  connected_order_arc_924  -13
    arc_1_18_8  in_degree_986  1
    arc_1_18_8  out_degree_1028  1
    arc_1_18_8  original_T_including_depot_unload_1043  1.1193870869231816e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_8  arc_capacity_923  1
    load_1_18_8  segment_load_conservation_989  -1
    load_1_18_8  segment_prefix_lb_990  1
    load_1_18_8  segment_prefix_ub_991  1
    load_1_18_8  free_load_conservation_1033  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_12  arc_capacity_925  -25
    arc_1_18_12  connected_order_arc_926  -13
    arc_1_18_12  in_degree_993  1
    arc_1_18_12  out_degree_1028  1
    arc_1_18_12  original_T_including_depot_unload_1043  5.3348116005684176e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_12  arc_capacity_925  1
    load_1_18_12  free_load_conservation_997  -1
    load_1_18_12  free_load_conservation_1033  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_13  arc_capacity_927  -25
    arc_1_18_13  connected_order_arc_928  -13
    arc_1_18_13  in_degree_999  1
    arc_1_18_13  out_degree_1028  1
    arc_1_18_13  original_T_including_depot_unload_1043  8.8427037135592116e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_13  arc_capacity_927  1
    load_1_18_13  free_load_conservation_1003  -1
    load_1_18_13  free_load_conservation_1033  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_14  arc_capacity_929  -25
    arc_1_18_14  connected_order_arc_930  -13
    arc_1_18_14  in_degree_1005  1
    arc_1_18_14  out_degree_1028  1
    arc_1_18_14  original_T_including_depot_unload_1043  8.0139063451811444e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_14  arc_capacity_929  1
    load_1_18_14  free_load_conservation_1009  -1
    load_1_18_14  free_load_conservation_1033  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_15  arc_capacity_931  -25
    arc_1_18_15  connected_order_arc_932  -13
    arc_1_18_15  in_degree_1011  1
    arc_1_18_15  out_degree_1028  1
    arc_1_18_15  original_T_including_depot_unload_1043  8.8488037837239642e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_15  arc_capacity_931  1
    load_1_18_15  free_load_conservation_1015  -1
    load_1_18_15  free_load_conservation_1033  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_16  arc_capacity_933  -25
    arc_1_18_16  connected_order_arc_934  -13
    arc_1_18_16  in_degree_1017  1
    arc_1_18_16  out_degree_1028  1
    arc_1_18_16  original_T_including_depot_unload_1043  1.6388081578301370e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_16  arc_capacity_933  1
    load_1_18_16  free_load_conservation_1021  -1
    load_1_18_16  free_load_conservation_1033  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_17  arc_capacity_935  -25
    arc_1_18_17  connected_order_arc_936  -13
    arc_1_18_17  in_degree_1023  1
    arc_1_18_17  out_degree_1028  1
    arc_1_18_17  original_T_including_depot_unload_1043  608.963327854777
    MARKER    'MARKER'                 'INTEND'
    load_1_18_17  arc_capacity_935  1
    load_1_18_17  free_load_conservation_1027  -1
    load_1_18_17  free_load_conservation_1033  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_19  arc_capacity_937  -25
    arc_1_18_19  connected_order_arc_938  -13
    arc_1_18_19  out_degree_1028  1
    arc_1_18_19  in_degree_1035  1
    arc_1_18_19  original_T_including_depot_unload_1043  204.956380049771
    MARKER    'MARKER'                 'INTEND'
    load_1_18_19  arc_capacity_937  1
    load_1_18_19  free_load_conservation_1033  1
    load_1_18_19  free_load_conservation_1039  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_0  arc_capacity_939  -25
    arc_1_19_0  depot_return_or_bypass_963  1
    arc_1_19_0  out_degree_1034  1
    arc_1_19_0  original_T_including_depot_unload_1043  5.8421641813809208e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_0  arc_capacity_939  1
    load_1_19_0  free_load_conservation_1039  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_5  arc_capacity_940  -25
    arc_1_19_5  connected_order_arc_941  -13
    arc_1_19_5  in_degree_965  1
    arc_1_19_5  out_degree_1034  1
    arc_1_19_5  original_T_including_depot_unload_1043  1.5356438916798834e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_5  arc_capacity_940  1
    load_1_19_5  segment_load_conservation_968  -1
    load_1_19_5  segment_prefix_lb_969  1
    load_1_19_5  segment_prefix_ub_970  1
    load_1_19_5  free_load_conservation_1039  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_6  arc_capacity_942  -25
    arc_1_19_6  connected_order_arc_943  -13
    arc_1_19_6  in_degree_972  1
    arc_1_19_6  out_degree_1034  1
    arc_1_19_6  original_T_including_depot_unload_1043  1.3045709733112460e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_6  arc_capacity_942  1
    load_1_19_6  segment_load_conservation_975  -1
    load_1_19_6  segment_prefix_lb_976  1
    load_1_19_6  segment_prefix_ub_977  1
    load_1_19_6  free_load_conservation_1039  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_7  arc_capacity_944  -25
    arc_1_19_7  connected_order_arc_945  -13
    arc_1_19_7  in_degree_979  1
    arc_1_19_7  out_degree_1034  1
    arc_1_19_7  original_T_including_depot_unload_1043  1.1150690045767951e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_7  arc_capacity_944  1
    load_1_19_7  segment_load_conservation_982  -1
    load_1_19_7  segment_prefix_lb_983  1
    load_1_19_7  segment_prefix_ub_984  1
    load_1_19_7  free_load_conservation_1039  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_8  arc_capacity_946  -25
    arc_1_19_8  connected_order_arc_947  -13
    arc_1_19_8  in_degree_986  1
    arc_1_19_8  out_degree_1034  1
    arc_1_19_8  original_T_including_depot_unload_1043  9.3137133767849343e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_8  arc_capacity_946  1
    load_1_19_8  segment_load_conservation_989  -1
    load_1_19_8  segment_prefix_lb_990  1
    load_1_19_8  segment_prefix_ub_991  1
    load_1_19_8  free_load_conservation_1039  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_12  arc_capacity_948  -25
    arc_1_19_12  connected_order_arc_949  -13
    arc_1_19_12  in_degree_993  1
    arc_1_19_12  out_degree_1034  1
    arc_1_19_12  original_T_including_depot_unload_1043  566.256001718161
    MARKER    'MARKER'                 'INTEND'
    load_1_19_12  arc_capacity_948  1
    load_1_19_12  free_load_conservation_997  -1
    load_1_19_12  free_load_conservation_1039  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_13  arc_capacity_950  -25
    arc_1_19_13  connected_order_arc_951  -13
    arc_1_19_13  in_degree_999  1
    arc_1_19_13  out_degree_1034  1
    arc_1_19_13  original_T_including_depot_unload_1043  9.0947747566405189e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_13  arc_capacity_950  1
    load_1_19_13  free_load_conservation_1003  -1
    load_1_19_13  free_load_conservation_1039  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_14  arc_capacity_952  -25
    arc_1_19_14  connected_order_arc_953  -13
    arc_1_19_14  in_degree_1005  1
    arc_1_19_14  out_degree_1034  1
    arc_1_19_14  original_T_including_depot_unload_1043  1.0063298732365655e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_14  arc_capacity_952  1
    load_1_19_14  free_load_conservation_1009  -1
    load_1_19_14  free_load_conservation_1039  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_15  arc_capacity_954  -25
    arc_1_19_15  connected_order_arc_955  -13
    arc_1_19_15  in_degree_1011  1
    arc_1_19_15  out_degree_1034  1
    arc_1_19_15  original_T_including_depot_unload_1043  9.1041274142057227e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_15  arc_capacity_954  1
    load_1_19_15  free_load_conservation_1015  -1
    load_1_19_15  free_load_conservation_1039  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_16  arc_capacity_956  -25
    arc_1_19_16  connected_order_arc_957  -13
    arc_1_19_16  in_degree_1017  1
    arc_1_19_16  out_degree_1034  1
    arc_1_19_16  original_T_including_depot_unload_1043  3.6822662782562685e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_16  arc_capacity_956  1
    load_1_19_16  free_load_conservation_1021  -1
    load_1_19_16  free_load_conservation_1039  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_17  arc_capacity_958  -25
    arc_1_19_17  connected_order_arc_959  -13
    arc_1_19_17  in_degree_1023  1
    arc_1_19_17  out_degree_1034  1
    arc_1_19_17  original_T_including_depot_unload_1043  5.0398976026149836e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_17  arc_capacity_958  1
    load_1_19_17  free_load_conservation_1027  -1
    load_1_19_17  free_load_conservation_1039  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_18  arc_capacity_960  -25
    arc_1_19_18  connected_order_arc_961  -13
    arc_1_19_18  in_degree_1029  1
    arc_1_19_18  out_degree_1034  1
    arc_1_19_18  original_T_including_depot_unload_1043  204.956380049771
    MARKER    'MARKER'                 'INTEND'
    load_1_19_18  arc_capacity_960  1
    load_1_19_18  free_load_conservation_1033  -1
    load_1_19_18  free_load_conservation_1039  1
    visit_2_9  out_degree_1289  -1
    visit_2_9  in_degree_1290  -1
    visit_2_9  order_active_lb_1291  -1
    visit_2_9  order_active_ub_1292  -11
    order_2_9  connected_order_arc_1058  -1
    order_2_9  connected_order_arc_1060  -1
    order_2_9  connected_order_arc_1062  -1
    order_2_9  connected_order_arc_1064  -1
    order_2_9  connected_order_arc_1066  -1
    order_2_9  connected_order_arc_1068  -1
    order_2_9  connected_order_arc_1070  -1
    order_2_9  connected_order_arc_1072  -1
    order_2_9  connected_order_arc_1074  -1
    order_2_9  connected_order_arc_1076  -1
    order_2_9  connected_order_arc_1079  1
    order_2_9  connected_order_arc_1100  1
    order_2_9  connected_order_arc_1121  1
    order_2_9  connected_order_arc_1142  1
    order_2_9  connected_order_arc_1163  1
    order_2_9  connected_order_arc_1184  1
    order_2_9  connected_order_arc_1205  1
    order_2_9  connected_order_arc_1226  1
    order_2_9  connected_order_arc_1247  1
    order_2_9  connected_order_arc_1268  1
    order_2_9  order_active_lb_1291  1
    order_2_9  order_active_ub_1292  1
    order_2_9  fixed_segment_relative_order_1358  -1
    visit_2_10  out_degree_1296  -1
    visit_2_10  in_degree_1297  -1
    visit_2_10  order_active_lb_1298  -1
    visit_2_10  order_active_ub_1299  -11
    order_2_10  connected_order_arc_1058  1
    order_2_10  connected_order_arc_1079  -1
    order_2_10  connected_order_arc_1081  -1
    order_2_10  connected_order_arc_1083  -1
    order_2_10  connected_order_arc_1085  -1
    order_2_10  connected_order_arc_1087  -1
    order_2_10  connected_order_arc_1089  -1
    order_2_10  connected_order_arc_1091  -1
    order_2_10  connected_order_arc_1093  -1
    order_2_10  connected_order_arc_1095  -1
    order_2_10  connected_order_arc_1097  -1
    order_2_10  connected_order_arc_1102  1
    order_2_10  connected_order_arc_1123  1
    order_2_10  connected_order_arc_1144  1
    order_2_10  connected_order_arc_1165  1
    order_2_10  connected_order_arc_1186  1
    order_2_10  connected_order_arc_1207  1
    order_2_10  connected_order_arc_1228  1
    order_2_10  connected_order_arc_1249  1
    order_2_10  connected_order_arc_1270  1
    order_2_10  order_active_lb_1298  1
    order_2_10  order_active_ub_1299  1
    order_2_10  fixed_segment_relative_order_1358  1
    order_2_10  fixed_segment_relative_order_1359  -1
    visit_2_11  out_degree_1303  -1
    visit_2_11  in_degree_1304  -1
    visit_2_11  order_active_lb_1305  -1
    visit_2_11  order_active_ub_1306  -11
    order_2_11  connected_order_arc_1060  1
    order_2_11  connected_order_arc_1081  1
    order_2_11  connected_order_arc_1100  -1
    order_2_11  connected_order_arc_1102  -1
    order_2_11  connected_order_arc_1104  -1
    order_2_11  connected_order_arc_1106  -1
    order_2_11  connected_order_arc_1108  -1
    order_2_11  connected_order_arc_1110  -1
    order_2_11  connected_order_arc_1112  -1
    order_2_11  connected_order_arc_1114  -1
    order_2_11  connected_order_arc_1116  -1
    order_2_11  connected_order_arc_1118  -1
    order_2_11  connected_order_arc_1125  1
    order_2_11  connected_order_arc_1146  1
    order_2_11  connected_order_arc_1167  1
    order_2_11  connected_order_arc_1188  1
    order_2_11  connected_order_arc_1209  1
    order_2_11  connected_order_arc_1230  1
    order_2_11  connected_order_arc_1251  1
    order_2_11  connected_order_arc_1272  1
    order_2_11  order_active_lb_1305  1
    order_2_11  order_active_ub_1306  1
    order_2_11  fixed_segment_relative_order_1359  1
    visit_2_12  out_degree_1310  -1
    visit_2_12  in_degree_1311  -1
    visit_2_12  order_active_lb_1312  -1
    visit_2_12  order_active_ub_1313  -11
    visit_2_12  service_visit_def_1314  -1
    order_2_12  connected_order_arc_1062  1
    order_2_12  connected_order_arc_1083  1
    order_2_12  connected_order_arc_1104  1
    order_2_12  connected_order_arc_1121  -1
    order_2_12  connected_order_arc_1123  -1
    order_2_12  connected_order_arc_1125  -1
    order_2_12  connected_order_arc_1127  -1
    order_2_12  connected_order_arc_1129  -1
    order_2_12  connected_order_arc_1131  -1
    order_2_12  connected_order_arc_1133  -1
    order_2_12  connected_order_arc_1135  -1
    order_2_12  connected_order_arc_1137  -1
    order_2_12  connected_order_arc_1139  -1
    order_2_12  connected_order_arc_1148  1
    order_2_12  connected_order_arc_1169  1
    order_2_12  connected_order_arc_1190  1
    order_2_12  connected_order_arc_1211  1
    order_2_12  connected_order_arc_1232  1
    order_2_12  connected_order_arc_1253  1
    order_2_12  connected_order_arc_1274  1
    order_2_12  order_active_lb_1312  1
    order_2_12  order_active_ub_1313  1
    visit_2_13  out_degree_1316  -1
    visit_2_13  in_degree_1317  -1
    visit_2_13  order_active_lb_1318  -1
    visit_2_13  order_active_ub_1319  -11
    visit_2_13  service_visit_def_1320  -1
    order_2_13  connected_order_arc_1064  1
    order_2_13  connected_order_arc_1085  1
    order_2_13  connected_order_arc_1106  1
    order_2_13  connected_order_arc_1127  1
    order_2_13  connected_order_arc_1142  -1
    order_2_13  connected_order_arc_1144  -1
    order_2_13  connected_order_arc_1146  -1
    order_2_13  connected_order_arc_1148  -1
    order_2_13  connected_order_arc_1150  -1
    order_2_13  connected_order_arc_1152  -1
    order_2_13  connected_order_arc_1154  -1
    order_2_13  connected_order_arc_1156  -1
    order_2_13  connected_order_arc_1158  -1
    order_2_13  connected_order_arc_1160  -1
    order_2_13  connected_order_arc_1171  1
    order_2_13  connected_order_arc_1192  1
    order_2_13  connected_order_arc_1213  1
    order_2_13  connected_order_arc_1234  1
    order_2_13  connected_order_arc_1255  1
    order_2_13  connected_order_arc_1276  1
    order_2_13  order_active_lb_1318  1
    order_2_13  order_active_ub_1319  1
    visit_2_14  out_degree_1322  -1
    visit_2_14  in_degree_1323  -1
    visit_2_14  order_active_lb_1324  -1
    visit_2_14  order_active_ub_1325  -11
    visit_2_14  service_visit_def_1326  -1
    order_2_14  connected_order_arc_1066  1
    order_2_14  connected_order_arc_1087  1
    order_2_14  connected_order_arc_1108  1
    order_2_14  connected_order_arc_1129  1
    order_2_14  connected_order_arc_1150  1
    order_2_14  connected_order_arc_1163  -1
    order_2_14  connected_order_arc_1165  -1
    order_2_14  connected_order_arc_1167  -1
    order_2_14  connected_order_arc_1169  -1
    order_2_14  connected_order_arc_1171  -1
    order_2_14  connected_order_arc_1173  -1
    order_2_14  connected_order_arc_1175  -1
    order_2_14  connected_order_arc_1177  -1
    order_2_14  connected_order_arc_1179  -1
    order_2_14  connected_order_arc_1181  -1
    order_2_14  connected_order_arc_1194  1
    order_2_14  connected_order_arc_1215  1
    order_2_14  connected_order_arc_1236  1
    order_2_14  connected_order_arc_1257  1
    order_2_14  connected_order_arc_1278  1
    order_2_14  order_active_lb_1324  1
    order_2_14  order_active_ub_1325  1
    visit_2_15  out_degree_1328  -1
    visit_2_15  in_degree_1329  -1
    visit_2_15  order_active_lb_1330  -1
    visit_2_15  order_active_ub_1331  -11
    visit_2_15  service_visit_def_1332  -1
    order_2_15  connected_order_arc_1068  1
    order_2_15  connected_order_arc_1089  1
    order_2_15  connected_order_arc_1110  1
    order_2_15  connected_order_arc_1131  1
    order_2_15  connected_order_arc_1152  1
    order_2_15  connected_order_arc_1173  1
    order_2_15  connected_order_arc_1184  -1
    order_2_15  connected_order_arc_1186  -1
    order_2_15  connected_order_arc_1188  -1
    order_2_15  connected_order_arc_1190  -1
    order_2_15  connected_order_arc_1192  -1
    order_2_15  connected_order_arc_1194  -1
    order_2_15  connected_order_arc_1196  -1
    order_2_15  connected_order_arc_1198  -1
    order_2_15  connected_order_arc_1200  -1
    order_2_15  connected_order_arc_1202  -1
    order_2_15  connected_order_arc_1217  1
    order_2_15  connected_order_arc_1238  1
    order_2_15  connected_order_arc_1259  1
    order_2_15  connected_order_arc_1280  1
    order_2_15  order_active_lb_1330  1
    order_2_15  order_active_ub_1331  1
    visit_2_16  out_degree_1334  -1
    visit_2_16  in_degree_1335  -1
    visit_2_16  order_active_lb_1336  -1
    visit_2_16  order_active_ub_1337  -11
    visit_2_16  service_visit_def_1338  -1
    order_2_16  connected_order_arc_1070  1
    order_2_16  connected_order_arc_1091  1
    order_2_16  connected_order_arc_1112  1
    order_2_16  connected_order_arc_1133  1
    order_2_16  connected_order_arc_1154  1
    order_2_16  connected_order_arc_1175  1
    order_2_16  connected_order_arc_1196  1
    order_2_16  connected_order_arc_1205  -1
    order_2_16  connected_order_arc_1207  -1
    order_2_16  connected_order_arc_1209  -1
    order_2_16  connected_order_arc_1211  -1
    order_2_16  connected_order_arc_1213  -1
    order_2_16  connected_order_arc_1215  -1
    order_2_16  connected_order_arc_1217  -1
    order_2_16  connected_order_arc_1219  -1
    order_2_16  connected_order_arc_1221  -1
    order_2_16  connected_order_arc_1223  -1
    order_2_16  connected_order_arc_1240  1
    order_2_16  connected_order_arc_1261  1
    order_2_16  connected_order_arc_1282  1
    order_2_16  order_active_lb_1336  1
    order_2_16  order_active_ub_1337  1
    visit_2_17  out_degree_1340  -1
    visit_2_17  in_degree_1341  -1
    visit_2_17  order_active_lb_1342  -1
    visit_2_17  order_active_ub_1343  -11
    visit_2_17  service_visit_def_1344  -1
    order_2_17  connected_order_arc_1072  1
    order_2_17  connected_order_arc_1093  1
    order_2_17  connected_order_arc_1114  1
    order_2_17  connected_order_arc_1135  1
    order_2_17  connected_order_arc_1156  1
    order_2_17  connected_order_arc_1177  1
    order_2_17  connected_order_arc_1198  1
    order_2_17  connected_order_arc_1219  1
    order_2_17  connected_order_arc_1226  -1
    order_2_17  connected_order_arc_1228  -1
    order_2_17  connected_order_arc_1230  -1
    order_2_17  connected_order_arc_1232  -1
    order_2_17  connected_order_arc_1234  -1
    order_2_17  connected_order_arc_1236  -1
    order_2_17  connected_order_arc_1238  -1
    order_2_17  connected_order_arc_1240  -1
    order_2_17  connected_order_arc_1242  -1
    order_2_17  connected_order_arc_1244  -1
    order_2_17  connected_order_arc_1263  1
    order_2_17  connected_order_arc_1284  1
    order_2_17  order_active_lb_1342  1
    order_2_17  order_active_ub_1343  1
    visit_2_18  out_degree_1346  -1
    visit_2_18  in_degree_1347  -1
    visit_2_18  order_active_lb_1348  -1
    visit_2_18  order_active_ub_1349  -11
    visit_2_18  service_visit_def_1350  -1
    order_2_18  connected_order_arc_1074  1
    order_2_18  connected_order_arc_1095  1
    order_2_18  connected_order_arc_1116  1
    order_2_18  connected_order_arc_1137  1
    order_2_18  connected_order_arc_1158  1
    order_2_18  connected_order_arc_1179  1
    order_2_18  connected_order_arc_1200  1
    order_2_18  connected_order_arc_1221  1
    order_2_18  connected_order_arc_1242  1
    order_2_18  connected_order_arc_1247  -1
    order_2_18  connected_order_arc_1249  -1
    order_2_18  connected_order_arc_1251  -1
    order_2_18  connected_order_arc_1253  -1
    order_2_18  connected_order_arc_1255  -1
    order_2_18  connected_order_arc_1257  -1
    order_2_18  connected_order_arc_1259  -1
    order_2_18  connected_order_arc_1261  -1
    order_2_18  connected_order_arc_1263  -1
    order_2_18  connected_order_arc_1265  -1
    order_2_18  connected_order_arc_1286  1
    order_2_18  order_active_lb_1348  1
    order_2_18  order_active_ub_1349  1
    visit_2_19  out_degree_1352  -1
    visit_2_19  in_degree_1353  -1
    visit_2_19  order_active_lb_1354  -1
    visit_2_19  order_active_ub_1355  -11
    visit_2_19  service_visit_def_1356  -1
    order_2_19  connected_order_arc_1076  1
    order_2_19  connected_order_arc_1097  1
    order_2_19  connected_order_arc_1118  1
    order_2_19  connected_order_arc_1139  1
    order_2_19  connected_order_arc_1160  1
    order_2_19  connected_order_arc_1181  1
    order_2_19  connected_order_arc_1202  1
    order_2_19  connected_order_arc_1223  1
    order_2_19  connected_order_arc_1244  1
    order_2_19  connected_order_arc_1265  1
    order_2_19  connected_order_arc_1268  -1
    order_2_19  connected_order_arc_1270  -1
    order_2_19  connected_order_arc_1272  -1
    order_2_19  connected_order_arc_1274  -1
    order_2_19  connected_order_arc_1276  -1
    order_2_19  connected_order_arc_1278  -1
    order_2_19  connected_order_arc_1280  -1
    order_2_19  connected_order_arc_1282  -1
    order_2_19  connected_order_arc_1284  -1
    order_2_19  connected_order_arc_1286  -1
    order_2_19  order_active_lb_1354  1
    order_2_19  order_active_ub_1355  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_0  arc_capacity_1044  -30
    arc_2_0_0  depot_departure_or_bypass_1287  1
    arc_2_0_0  depot_return_or_bypass_1288  1
    MARKER    'MARKER'                 'INTEND'
    load_2_0_0  arc_capacity_1044  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_9  arc_capacity_1045  -30
    arc_2_0_9  depot_departure_or_bypass_1287  1
    arc_2_0_9  in_degree_1290  1
    arc_2_0_9  original_T_including_depot_unload_1360  1.4373810231417410e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_9  arc_capacity_1045  1
    load_2_0_9  segment_load_conservation_1293  -1
    load_2_0_9  segment_prefix_lb_1294  1
    load_2_0_9  segment_prefix_ub_1295  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_10  arc_capacity_1046  -30
    arc_2_0_10  depot_departure_or_bypass_1287  1
    arc_2_0_10  in_degree_1297  1
    arc_2_0_10  original_T_including_depot_unload_1360  1.4206108045382291e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_10  arc_capacity_1046  1
    load_2_0_10  segment_load_conservation_1300  -1
    load_2_0_10  segment_prefix_lb_1301  1
    load_2_0_10  segment_prefix_ub_1302  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_11  arc_capacity_1047  -30
    arc_2_0_11  depot_departure_or_bypass_1287  1
    arc_2_0_11  in_degree_1304  1
    arc_2_0_11  original_T_including_depot_unload_1360  1.4657426641025907e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_11  arc_capacity_1047  1
    load_2_0_11  segment_load_conservation_1307  -1
    load_2_0_11  segment_prefix_lb_1308  1
    load_2_0_11  segment_prefix_ub_1309  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_12  arc_capacity_1048  -30
    arc_2_0_12  depot_departure_or_bypass_1287  1
    arc_2_0_12  in_degree_1311  1
    arc_2_0_12  original_T_including_depot_unload_1360  7.9650294035968375e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_12  arc_capacity_1048  1
    load_2_0_12  free_load_conservation_1315  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_13  arc_capacity_1049  -30
    arc_2_0_13  depot_departure_or_bypass_1287  1
    arc_2_0_13  in_degree_1317  1
    arc_2_0_13  original_T_including_depot_unload_1360  1.0056399980521732e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_13  arc_capacity_1049  1
    load_2_0_13  free_load_conservation_1321  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_14  arc_capacity_1050  -30
    arc_2_0_14  depot_departure_or_bypass_1287  1
    arc_2_0_14  in_degree_1323  1
    arc_2_0_14  original_T_including_depot_unload_1360  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_14  arc_capacity_1050  1
    load_2_0_14  free_load_conservation_1327  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_15  arc_capacity_1051  -30
    arc_2_0_15  depot_departure_or_bypass_1287  1
    arc_2_0_15  in_degree_1329  1
    arc_2_0_15  original_T_including_depot_unload_1360  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_15  arc_capacity_1051  1
    load_2_0_15  free_load_conservation_1333  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_16  arc_capacity_1052  -30
    arc_2_0_16  depot_departure_or_bypass_1287  1
    arc_2_0_16  in_degree_1335  1
    arc_2_0_16  original_T_including_depot_unload_1360  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_16  arc_capacity_1052  1
    load_2_0_16  free_load_conservation_1339  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_17  arc_capacity_1053  -30
    arc_2_0_17  depot_departure_or_bypass_1287  1
    arc_2_0_17  in_degree_1341  1
    arc_2_0_17  original_T_including_depot_unload_1360  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_17  arc_capacity_1053  1
    load_2_0_17  free_load_conservation_1345  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_18  arc_capacity_1054  -30
    arc_2_0_18  depot_departure_or_bypass_1287  1
    arc_2_0_18  in_degree_1347  1
    arc_2_0_18  original_T_including_depot_unload_1360  778.011461754062
    MARKER    'MARKER'                 'INTEND'
    load_2_0_18  arc_capacity_1054  1
    load_2_0_18  free_load_conservation_1351  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_19  arc_capacity_1055  -30
    arc_2_0_19  depot_departure_or_bypass_1287  1
    arc_2_0_19  in_degree_1353  1
    arc_2_0_19  original_T_including_depot_unload_1360  5.8421641813809208e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_19  arc_capacity_1055  1
    load_2_0_19  free_load_conservation_1357  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_0  arc_capacity_1056  -30
    arc_2_9_0  depot_return_or_bypass_1288  1
    arc_2_9_0  out_degree_1289  1
    arc_2_9_0  original_T_including_depot_unload_1360  1.4373810231417410e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_9_0  arc_capacity_1056  1
    load_2_9_0  segment_load_conservation_1293  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_10  arc_capacity_1057  -30
    arc_2_9_10  connected_order_arc_1058  -12
    arc_2_9_10  out_degree_1289  1
    arc_2_9_10  in_degree_1297  1
    arc_2_9_10  original_T_including_depot_unload_1360  2.2310212250199638e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_9_10  arc_capacity_1057  1
    load_2_9_10  segment_load_conservation_1293  1
    load_2_9_10  segment_load_conservation_1300  -1
    load_2_9_10  segment_prefix_lb_1301  1
    load_2_9_10  segment_prefix_ub_1302  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_11  arc_capacity_1059  -30
    arc_2_9_11  connected_order_arc_1060  -12
    arc_2_9_11  out_degree_1289  1
    arc_2_9_11  in_degree_1304  1
    arc_2_9_11  original_T_including_depot_unload_1360  8.2580969662641792e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_9_11  arc_capacity_1059  1
    load_2_9_11  segment_load_conservation_1293  1
    load_2_9_11  segment_load_conservation_1307  -1
    load_2_9_11  segment_prefix_lb_1308  1
    load_2_9_11  segment_prefix_ub_1309  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_12  arc_capacity_1061  -30
    arc_2_9_12  connected_order_arc_1062  -12
    arc_2_9_12  out_degree_1289  1
    arc_2_9_12  in_degree_1311  1
    arc_2_9_12  original_T_including_depot_unload_1360  7.5681404708111961e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_9_12  arc_capacity_1061  1
    load_2_9_12  segment_load_conservation_1293  1
    load_2_9_12  free_load_conservation_1315  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_13  arc_capacity_1063  -30
    arc_2_9_13  connected_order_arc_1064  -12
    arc_2_9_13  out_degree_1289  1
    arc_2_9_13  in_degree_1317  1
    arc_2_9_13  original_T_including_depot_unload_1360  926.407625506948
    MARKER    'MARKER'                 'INTEND'
    load_2_9_13  arc_capacity_1063  1
    load_2_9_13  segment_load_conservation_1293  1
    load_2_9_13  free_load_conservation_1321  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_14  arc_capacity_1065  -30
    arc_2_9_14  connected_order_arc_1066  -12
    arc_2_9_14  out_degree_1289  1
    arc_2_9_14  in_degree_1323  1
    arc_2_9_14  original_T_including_depot_unload_1360  2.9139628504456829e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_9_14  arc_capacity_1065  1
    load_2_9_14  segment_load_conservation_1293  1
    load_2_9_14  free_load_conservation_1327  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_15  arc_capacity_1067  -30
    arc_2_9_15  connected_order_arc_1068  -12
    arc_2_9_15  out_degree_1289  1
    arc_2_9_15  in_degree_1329  1
    arc_2_9_15  original_T_including_depot_unload_1360  925.691754925099
    MARKER    'MARKER'                 'INTEND'
    load_2_9_15  arc_capacity_1067  1
    load_2_9_15  segment_load_conservation_1293  1
    load_2_9_15  free_load_conservation_1333  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_16  arc_capacity_1069  -30
    arc_2_9_16  connected_order_arc_1070  -12
    arc_2_9_16  out_degree_1289  1
    arc_2_9_16  in_degree_1335  1
    arc_2_9_16  original_T_including_depot_unload_1360  5.7914586906741226e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_9_16  arc_capacity_1069  1
    load_2_9_16  segment_load_conservation_1293  1
    load_2_9_16  free_load_conservation_1339  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_17  arc_capacity_1071  -30
    arc_2_9_17  connected_order_arc_1072  -12
    arc_2_9_17  out_degree_1289  1
    arc_2_9_17  in_degree_1341  1
    arc_2_9_17  original_T_including_depot_unload_1360  1.0984912119828512e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_9_17  arc_capacity_1071  1
    load_2_9_17  segment_load_conservation_1293  1
    load_2_9_17  free_load_conservation_1345  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_18  arc_capacity_1073  -30
    arc_2_9_18  connected_order_arc_1074  -12
    arc_2_9_18  out_degree_1289  1
    arc_2_9_18  in_degree_1347  1
    arc_2_9_18  original_T_including_depot_unload_1360  7.3693716289230485e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_9_18  arc_capacity_1073  1
    load_2_9_18  segment_load_conservation_1293  1
    load_2_9_18  free_load_conservation_1351  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_19  arc_capacity_1075  -30
    arc_2_9_19  connected_order_arc_1076  -12
    arc_2_9_19  out_degree_1289  1
    arc_2_9_19  in_degree_1353  1
    arc_2_9_19  original_T_including_depot_unload_1360  9.3170331463979812e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_9_19  arc_capacity_1075  1
    load_2_9_19  segment_load_conservation_1293  1
    load_2_9_19  free_load_conservation_1357  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_0  arc_capacity_1077  -30
    arc_2_10_0  depot_return_or_bypass_1288  1
    arc_2_10_0  out_degree_1296  1
    arc_2_10_0  original_T_including_depot_unload_1360  1.4206108045382291e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_0  arc_capacity_1077  1
    load_2_10_0  segment_load_conservation_1300  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_9  arc_capacity_1078  -30
    arc_2_10_9  connected_order_arc_1079  -12
    arc_2_10_9  in_degree_1290  1
    arc_2_10_9  out_degree_1296  1
    arc_2_10_9  original_T_including_depot_unload_1360  2.2310212250199638e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_9  arc_capacity_1078  1
    load_2_10_9  segment_load_conservation_1293  -1
    load_2_10_9  segment_prefix_lb_1294  1
    load_2_10_9  segment_prefix_ub_1295  1
    load_2_10_9  segment_load_conservation_1300  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_11  arc_capacity_1080  -30
    arc_2_10_11  connected_order_arc_1081  -12
    arc_2_10_11  out_degree_1296  1
    arc_2_10_11  in_degree_1304  1
    arc_2_10_11  original_T_including_depot_unload_1360  604.307118555145
    MARKER    'MARKER'                 'INTEND'
    load_2_10_11  arc_capacity_1080  1
    load_2_10_11  segment_load_conservation_1300  1
    load_2_10_11  segment_load_conservation_1307  -1
    load_2_10_11  segment_prefix_lb_1308  1
    load_2_10_11  segment_prefix_ub_1309  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_12  arc_capacity_1082  -30
    arc_2_10_12  connected_order_arc_1083  -12
    arc_2_10_12  out_degree_1296  1
    arc_2_10_12  in_degree_1311  1
    arc_2_10_12  original_T_including_depot_unload_1360  6.6735284319782306e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_12  arc_capacity_1082  1
    load_2_10_12  segment_load_conservation_1300  1
    load_2_10_12  free_load_conservation_1315  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_13  arc_capacity_1084  -30
    arc_2_10_13  connected_order_arc_1085  -12
    arc_2_10_13  out_degree_1296  1
    arc_2_10_13  in_degree_1317  1
    arc_2_10_13  original_T_including_depot_unload_1360  7.6061661180217550e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_13  arc_capacity_1084  1
    load_2_10_13  segment_load_conservation_1300  1
    load_2_10_13  free_load_conservation_1321  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_14  arc_capacity_1086  -30
    arc_2_10_14  connected_order_arc_1087  -12
    arc_2_10_14  out_degree_1296  1
    arc_2_10_14  in_degree_1323  1
    arc_2_10_14  original_T_including_depot_unload_1360  5.1169459347980438e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_14  arc_capacity_1086  1
    load_2_10_14  segment_load_conservation_1300  1
    load_2_10_14  free_load_conservation_1327  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_15  arc_capacity_1088  -30
    arc_2_10_15  connected_order_arc_1089  -12
    arc_2_10_15  out_degree_1296  1
    arc_2_10_15  in_degree_1329  1
    arc_2_10_15  original_T_including_depot_unload_1360  7.5965235847304257e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_15  arc_capacity_1088  1
    load_2_10_15  segment_load_conservation_1300  1
    load_2_10_15  free_load_conservation_1333  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_16  arc_capacity_1090  -30
    arc_2_10_16  connected_order_arc_1091  -12
    arc_2_10_16  out_degree_1296  1
    arc_2_10_16  in_degree_1335  1
    arc_2_10_16  original_T_including_depot_unload_1360  6.6929586395597710e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_16  arc_capacity_1090  1
    load_2_10_16  segment_load_conservation_1300  1
    load_2_10_16  free_load_conservation_1339  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_17  arc_capacity_1092  -30
    arc_2_10_17  connected_order_arc_1093  -12
    arc_2_10_17  out_degree_1296  1
    arc_2_10_17  in_degree_1341  1
    arc_2_10_17  original_T_including_depot_unload_1360  1.0379751075251477e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_17  arc_capacity_1092  1
    load_2_10_17  segment_load_conservation_1300  1
    load_2_10_17  free_load_conservation_1345  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_18  arc_capacity_1094  -30
    arc_2_10_18  connected_order_arc_1095  -12
    arc_2_10_18  out_degree_1296  1
    arc_2_10_18  in_degree_1347  1
    arc_2_10_18  original_T_including_depot_unload_1360  8.0681198709780529e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_18  arc_capacity_1094  1
    load_2_10_18  segment_load_conservation_1300  1
    load_2_10_18  free_load_conservation_1351  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_19  arc_capacity_1096  -30
    arc_2_10_19  connected_order_arc_1097  -12
    arc_2_10_19  out_degree_1296  1
    arc_2_10_19  in_degree_1353  1
    arc_2_10_19  original_T_including_depot_unload_1360  9.7958300464034107e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_19  arc_capacity_1096  1
    load_2_10_19  segment_load_conservation_1300  1
    load_2_10_19  free_load_conservation_1357  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_0  arc_capacity_1098  -30
    arc_2_11_0  depot_return_or_bypass_1288  1
    arc_2_11_0  out_degree_1303  1
    arc_2_11_0  original_T_including_depot_unload_1360  1.6602888921784454e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_0  arc_capacity_1098  1
    load_2_11_0  segment_load_conservation_1307  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_9  arc_capacity_1099  -30
    arc_2_11_9  connected_order_arc_1100  -12
    arc_2_11_9  in_degree_1290  1
    arc_2_11_9  out_degree_1303  1
    arc_2_11_9  original_T_including_depot_unload_1360  1.6865464326628071e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_9  arc_capacity_1099  1
    load_2_11_9  segment_load_conservation_1293  -1
    load_2_11_9  segment_prefix_lb_1294  1
    load_2_11_9  segment_prefix_ub_1295  1
    load_2_11_9  segment_load_conservation_1307  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_10  arc_capacity_1101  -30
    arc_2_11_10  connected_order_arc_1102  -12
    arc_2_11_10  in_degree_1297  1
    arc_2_11_10  out_degree_1303  1
    arc_2_11_10  original_T_including_depot_unload_1360  1.4754486297628157e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_10  arc_capacity_1101  1
    load_2_11_10  segment_load_conservation_1300  -1
    load_2_11_10  segment_prefix_lb_1301  1
    load_2_11_10  segment_prefix_ub_1302  1
    load_2_11_10  segment_load_conservation_1307  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_12  arc_capacity_1103  -30
    arc_2_11_12  connected_order_arc_1104  -12
    arc_2_11_12  out_degree_1303  1
    arc_2_11_12  in_degree_1311  1
    arc_2_11_12  original_T_including_depot_unload_1360  1.2177809159572148e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_12  arc_capacity_1103  1
    load_2_11_12  segment_load_conservation_1307  1
    load_2_11_12  free_load_conservation_1315  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_13  arc_capacity_1105  -30
    arc_2_11_13  connected_order_arc_1106  -12
    arc_2_11_13  out_degree_1303  1
    arc_2_11_13  in_degree_1317  1
    arc_2_11_13  original_T_including_depot_unload_1360  8.7049015369085737e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_13  arc_capacity_1105  1
    load_2_11_13  segment_load_conservation_1307  1
    load_2_11_13  free_load_conservation_1321  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_14  arc_capacity_1107  -30
    arc_2_11_14  connected_order_arc_1108  -12
    arc_2_11_14  out_degree_1303  1
    arc_2_11_14  in_degree_1323  1
    arc_2_11_14  original_T_including_depot_unload_1360  1.9767828664634856e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_14  arc_capacity_1107  1
    load_2_11_14  segment_load_conservation_1307  1
    load_2_11_14  free_load_conservation_1327  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_15  arc_capacity_1109  -30
    arc_2_11_15  connected_order_arc_1110  -12
    arc_2_11_15  out_degree_1303  1
    arc_2_11_15  in_degree_1329  1
    arc_2_11_15  original_T_including_depot_unload_1360  8.7008776944597639e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_15  arc_capacity_1109  1
    load_2_11_15  segment_load_conservation_1307  1
    load_2_11_15  free_load_conservation_1333  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_16  arc_capacity_1111  -30
    arc_2_11_16  connected_order_arc_1112  -12
    arc_2_11_16  out_degree_1303  1
    arc_2_11_16  in_degree_1335  1
    arc_2_11_16  original_T_including_depot_unload_1360  1.7489191280566063e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_16  arc_capacity_1111  1
    load_2_11_16  segment_load_conservation_1307  1
    load_2_11_16  free_load_conservation_1339  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_17  arc_capacity_1113  -30
    arc_2_11_17  connected_order_arc_1114  -12
    arc_2_11_17  out_degree_1303  1
    arc_2_11_17  in_degree_1341  1
    arc_2_11_17  original_T_including_depot_unload_1360  1.3104307696104611e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_17  arc_capacity_1113  1
    load_2_11_17  segment_load_conservation_1307  1
    load_2_11_17  free_load_conservation_1345  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_18  arc_capacity_1115  -30
    arc_2_11_18  connected_order_arc_1116  -12
    arc_2_11_18  out_degree_1303  1
    arc_2_11_18  in_degree_1347  1
    arc_2_11_18  original_T_including_depot_unload_1360  1.7509294259345222e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_18  arc_capacity_1115  1
    load_2_11_18  segment_load_conservation_1307  1
    load_2_11_18  free_load_conservation_1351  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_19  arc_capacity_1117  -30
    arc_2_11_19  connected_order_arc_1118  -12
    arc_2_11_19  out_degree_1303  1
    arc_2_11_19  in_degree_1353  1
    arc_2_11_19  original_T_including_depot_unload_1360  1.7513054753242350e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_19  arc_capacity_1117  1
    load_2_11_19  segment_load_conservation_1307  1
    load_2_11_19  free_load_conservation_1357  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_0  arc_capacity_1119  -30
    arc_2_12_0  depot_return_or_bypass_1288  1
    arc_2_12_0  out_degree_1310  1
    arc_2_12_0  original_T_including_depot_unload_1360  7.9650294035968375e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_0  arc_capacity_1119  1
    load_2_12_0  free_load_conservation_1315  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_9  arc_capacity_1120  -30
    arc_2_12_9  connected_order_arc_1121  -12
    arc_2_12_9  in_degree_1290  1
    arc_2_12_9  out_degree_1310  1
    arc_2_12_9  original_T_including_depot_unload_1360  7.5681404708111961e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_9  arc_capacity_1120  1
    load_2_12_9  segment_load_conservation_1293  -1
    load_2_12_9  segment_prefix_lb_1294  1
    load_2_12_9  segment_prefix_ub_1295  1
    load_2_12_9  free_load_conservation_1315  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_10  arc_capacity_1122  -30
    arc_2_12_10  connected_order_arc_1123  -12
    arc_2_12_10  in_degree_1297  1
    arc_2_12_10  out_degree_1310  1
    arc_2_12_10  original_T_including_depot_unload_1360  6.6735284319782306e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_10  arc_capacity_1122  1
    load_2_12_10  segment_load_conservation_1300  -1
    load_2_12_10  segment_prefix_lb_1301  1
    load_2_12_10  segment_prefix_ub_1302  1
    load_2_12_10  free_load_conservation_1315  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_11  arc_capacity_1124  -30
    arc_2_12_11  connected_order_arc_1125  -12
    arc_2_12_11  in_degree_1304  1
    arc_2_12_11  out_degree_1310  1
    arc_2_12_11  original_T_including_depot_unload_1360  7.0252509787186375e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_11  arc_capacity_1124  1
    load_2_12_11  segment_load_conservation_1307  -1
    load_2_12_11  segment_prefix_lb_1308  1
    load_2_12_11  segment_prefix_ub_1309  1
    load_2_12_11  free_load_conservation_1315  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_13  arc_capacity_1126  -30
    arc_2_12_13  connected_order_arc_1127  -12
    arc_2_12_13  out_degree_1310  1
    arc_2_12_13  in_degree_1317  1
    arc_2_12_13  original_T_including_depot_unload_1360  3.5166546157461704e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_13  arc_capacity_1126  1
    load_2_12_13  free_load_conservation_1315  1
    load_2_12_13  free_load_conservation_1321  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_14  arc_capacity_1128  -30
    arc_2_12_14  connected_order_arc_1129  -12
    arc_2_12_14  out_degree_1310  1
    arc_2_12_14  in_degree_1323  1
    arc_2_12_14  original_T_including_depot_unload_1360  9.8108674361469946e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_14  arc_capacity_1128  1
    load_2_12_14  free_load_conservation_1315  1
    load_2_12_14  free_load_conservation_1327  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_15  arc_capacity_1130  -30
    arc_2_12_15  connected_order_arc_1131  -12
    arc_2_12_15  out_degree_1310  1
    arc_2_12_15  in_degree_1329  1
    arc_2_12_15  original_T_including_depot_unload_1360  3.5235932354279930e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_15  arc_capacity_1130  1
    load_2_12_15  free_load_conservation_1315  1
    load_2_12_15  free_load_conservation_1333  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_16  arc_capacity_1132  -30
    arc_2_12_16  connected_order_arc_1133  -12
    arc_2_12_16  out_degree_1310  1
    arc_2_12_16  in_degree_1335  1
    arc_2_12_16  original_T_including_depot_unload_1360  5.4405628017126674e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_16  arc_capacity_1132  1
    load_2_12_16  free_load_conservation_1315  1
    load_2_12_16  free_load_conservation_1339  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_17  arc_capacity_1134  -30
    arc_2_12_17  connected_order_arc_1135  -12
    arc_2_12_17  out_degree_1310  1
    arc_2_12_17  in_degree_1341  1
    arc_2_12_17  original_T_including_depot_unload_1360  3.7831268047064754e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_17  arc_capacity_1134  1
    load_2_12_17  free_load_conservation_1315  1
    load_2_12_17  free_load_conservation_1345  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_18  arc_capacity_1136  -30
    arc_2_12_18  connected_order_arc_1137  -12
    arc_2_12_18  out_degree_1310  1
    arc_2_12_18  in_degree_1347  1
    arc_2_12_18  original_T_including_depot_unload_1360  5.3348116005684176e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_18  arc_capacity_1136  1
    load_2_12_18  free_load_conservation_1315  1
    load_2_12_18  free_load_conservation_1351  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_19  arc_capacity_1138  -30
    arc_2_12_19  connected_order_arc_1139  -12
    arc_2_12_19  out_degree_1310  1
    arc_2_12_19  in_degree_1353  1
    arc_2_12_19  original_T_including_depot_unload_1360  566.256001718161
    MARKER    'MARKER'                 'INTEND'
    load_2_12_19  arc_capacity_1138  1
    load_2_12_19  free_load_conservation_1315  1
    load_2_12_19  free_load_conservation_1357  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_0  arc_capacity_1140  -30
    arc_2_13_0  depot_return_or_bypass_1288  1
    arc_2_13_0  out_degree_1316  1
    arc_2_13_0  original_T_including_depot_unload_1360  1.0056399980521732e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_0  arc_capacity_1140  1
    load_2_13_0  free_load_conservation_1321  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_9  arc_capacity_1141  -30
    arc_2_13_9  connected_order_arc_1142  -12
    arc_2_13_9  in_degree_1290  1
    arc_2_13_9  out_degree_1316  1
    arc_2_13_9  original_T_including_depot_unload_1360  926.407625506948
    MARKER    'MARKER'                 'INTEND'
    load_2_13_9  arc_capacity_1141  1
    load_2_13_9  segment_load_conservation_1293  -1
    load_2_13_9  segment_prefix_lb_1294  1
    load_2_13_9  segment_prefix_ub_1295  1
    load_2_13_9  free_load_conservation_1321  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_10  arc_capacity_1143  -30
    arc_2_13_10  connected_order_arc_1144  -12
    arc_2_13_10  in_degree_1297  1
    arc_2_13_10  out_degree_1316  1
    arc_2_13_10  original_T_including_depot_unload_1360  7.6061661180217550e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_10  arc_capacity_1143  1
    load_2_13_10  segment_load_conservation_1300  -1
    load_2_13_10  segment_prefix_lb_1301  1
    load_2_13_10  segment_prefix_ub_1302  1
    load_2_13_10  free_load_conservation_1321  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_11  arc_capacity_1145  -30
    arc_2_13_11  connected_order_arc_1146  -12
    arc_2_13_11  in_degree_1304  1
    arc_2_13_11  out_degree_1316  1
    arc_2_13_11  original_T_including_depot_unload_1360  4.8227670112102692e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_11  arc_capacity_1145  1
    load_2_13_11  segment_load_conservation_1307  -1
    load_2_13_11  segment_prefix_lb_1308  1
    load_2_13_11  segment_prefix_ub_1309  1
    load_2_13_11  free_load_conservation_1321  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_12  arc_capacity_1147  -30
    arc_2_13_12  connected_order_arc_1148  -12
    arc_2_13_12  in_degree_1311  1
    arc_2_13_12  out_degree_1316  1
    arc_2_13_12  original_T_including_depot_unload_1360  3.5166546157461704e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_12  arc_capacity_1147  1
    load_2_13_12  free_load_conservation_1315  -1
    load_2_13_12  free_load_conservation_1321  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_14  arc_capacity_1149  -30
    arc_2_13_14  connected_order_arc_1150  -12
    arc_2_13_14  out_degree_1316  1
    arc_2_13_14  in_degree_1323  1
    arc_2_13_14  original_T_including_depot_unload_1360  1.1967280409234234e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_14  arc_capacity_1149  1
    load_2_13_14  free_load_conservation_1321  1
    load_2_13_14  free_load_conservation_1327  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_15  arc_capacity_1151  -30
    arc_2_13_15  connected_order_arc_1152  -12
    arc_2_13_15  out_degree_1316  1
    arc_2_13_15  in_degree_1329  1
    arc_2_13_15  original_T_including_depot_unload_1360  1.6320002720932780e+00
    MARKER    'MARKER'                 'INTEND'
    load_2_13_15  arc_capacity_1151  1
    load_2_13_15  free_load_conservation_1321  1
    load_2_13_15  free_load_conservation_1333  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_16  arc_capacity_1153  -30
    arc_2_13_16  connected_order_arc_1154  -12
    arc_2_13_16  out_degree_1316  1
    arc_2_13_16  in_degree_1335  1
    arc_2_13_16  original_T_including_depot_unload_1360  8.7906342149593650e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_16  arc_capacity_1153  1
    load_2_13_16  free_load_conservation_1321  1
    load_2_13_16  free_load_conservation_1339  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_17  arc_capacity_1155  -30
    arc_2_13_17  connected_order_arc_1156  -12
    arc_2_13_17  out_degree_1316  1
    arc_2_13_17  in_degree_1341  1
    arc_2_13_17  original_T_including_depot_unload_1360  5.7276146581216926e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_17  arc_capacity_1155  1
    load_2_13_17  free_load_conservation_1321  1
    load_2_13_17  free_load_conservation_1345  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_18  arc_capacity_1157  -30
    arc_2_13_18  connected_order_arc_1158  -12
    arc_2_13_18  out_degree_1316  1
    arc_2_13_18  in_degree_1347  1
    arc_2_13_18  original_T_including_depot_unload_1360  8.8427037135592116e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_18  arc_capacity_1157  1
    load_2_13_18  free_load_conservation_1321  1
    load_2_13_18  free_load_conservation_1351  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_19  arc_capacity_1159  -30
    arc_2_13_19  connected_order_arc_1160  -12
    arc_2_13_19  out_degree_1316  1
    arc_2_13_19  in_degree_1353  1
    arc_2_13_19  original_T_including_depot_unload_1360  9.0947747566405189e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_19  arc_capacity_1159  1
    load_2_13_19  free_load_conservation_1321  1
    load_2_13_19  free_load_conservation_1357  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_0  arc_capacity_1161  -30
    arc_2_14_0  depot_return_or_bypass_1288  1
    arc_2_14_0  out_degree_1322  1
    arc_2_14_0  original_T_including_depot_unload_1360  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_0  arc_capacity_1161  1
    load_2_14_0  free_load_conservation_1327  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_9  arc_capacity_1162  -30
    arc_2_14_9  connected_order_arc_1163  -12
    arc_2_14_9  in_degree_1290  1
    arc_2_14_9  out_degree_1322  1
    arc_2_14_9  original_T_including_depot_unload_1360  2.9139628504456829e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_9  arc_capacity_1162  1
    load_2_14_9  segment_load_conservation_1293  -1
    load_2_14_9  segment_prefix_lb_1294  1
    load_2_14_9  segment_prefix_ub_1295  1
    load_2_14_9  free_load_conservation_1327  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_10  arc_capacity_1164  -30
    arc_2_14_10  connected_order_arc_1165  -12
    arc_2_14_10  in_degree_1297  1
    arc_2_14_10  out_degree_1322  1
    arc_2_14_10  original_T_including_depot_unload_1360  5.1169459347980438e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_10  arc_capacity_1164  1
    load_2_14_10  segment_load_conservation_1300  -1
    load_2_14_10  segment_prefix_lb_1301  1
    load_2_14_10  segment_prefix_ub_1302  1
    load_2_14_10  free_load_conservation_1327  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_11  arc_capacity_1166  -30
    arc_2_14_11  connected_order_arc_1167  -12
    arc_2_14_11  in_degree_1304  1
    arc_2_14_11  out_degree_1322  1
    arc_2_14_11  original_T_including_depot_unload_1360  1.1159421068673551e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_11  arc_capacity_1166  1
    load_2_14_11  segment_load_conservation_1307  -1
    load_2_14_11  segment_prefix_lb_1308  1
    load_2_14_11  segment_prefix_ub_1309  1
    load_2_14_11  free_load_conservation_1327  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_12  arc_capacity_1168  -30
    arc_2_14_12  connected_order_arc_1169  -12
    arc_2_14_12  in_degree_1311  1
    arc_2_14_12  out_degree_1322  1
    arc_2_14_12  original_T_including_depot_unload_1360  9.8108674361469946e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_12  arc_capacity_1168  1
    load_2_14_12  free_load_conservation_1315  -1
    load_2_14_12  free_load_conservation_1327  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_13  arc_capacity_1170  -30
    arc_2_14_13  connected_order_arc_1171  -12
    arc_2_14_13  in_degree_1317  1
    arc_2_14_13  out_degree_1322  1
    arc_2_14_13  original_T_including_depot_unload_1360  1.1967280409234234e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_13  arc_capacity_1170  1
    load_2_14_13  free_load_conservation_1321  -1
    load_2_14_13  free_load_conservation_1327  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_15  arc_capacity_1172  -30
    arc_2_14_15  connected_order_arc_1173  -12
    arc_2_14_15  out_degree_1322  1
    arc_2_14_15  in_degree_1329  1
    arc_2_14_15  original_T_including_depot_unload_1360  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_15  arc_capacity_1172  1
    load_2_14_15  free_load_conservation_1327  1
    load_2_14_15  free_load_conservation_1333  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_16  arc_capacity_1174  -30
    arc_2_14_16  connected_order_arc_1175  -12
    arc_2_14_16  out_degree_1322  1
    arc_2_14_16  in_degree_1335  1
    arc_2_14_16  original_T_including_depot_unload_1360  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_2_14_16  arc_capacity_1174  1
    load_2_14_16  free_load_conservation_1327  1
    load_2_14_16  free_load_conservation_1339  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_17  arc_capacity_1176  -30
    arc_2_14_17  connected_order_arc_1177  -12
    arc_2_14_17  out_degree_1322  1
    arc_2_14_17  in_degree_1341  1
    arc_2_14_17  original_T_including_depot_unload_1360  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_17  arc_capacity_1176  1
    load_2_14_17  free_load_conservation_1327  1
    load_2_14_17  free_load_conservation_1345  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_18  arc_capacity_1178  -30
    arc_2_14_18  connected_order_arc_1179  -12
    arc_2_14_18  out_degree_1322  1
    arc_2_14_18  in_degree_1347  1
    arc_2_14_18  original_T_including_depot_unload_1360  8.0139063451811444e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_18  arc_capacity_1178  1
    load_2_14_18  free_load_conservation_1327  1
    load_2_14_18  free_load_conservation_1351  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_19  arc_capacity_1180  -30
    arc_2_14_19  connected_order_arc_1181  -12
    arc_2_14_19  out_degree_1322  1
    arc_2_14_19  in_degree_1353  1
    arc_2_14_19  original_T_including_depot_unload_1360  1.0063298732365655e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_19  arc_capacity_1180  1
    load_2_14_19  free_load_conservation_1327  1
    load_2_14_19  free_load_conservation_1357  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_0  arc_capacity_1182  -30
    arc_2_15_0  depot_return_or_bypass_1288  1
    arc_2_15_0  out_degree_1328  1
    arc_2_15_0  original_T_including_depot_unload_1360  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_0  arc_capacity_1182  1
    load_2_15_0  free_load_conservation_1333  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_9  arc_capacity_1183  -30
    arc_2_15_9  connected_order_arc_1184  -12
    arc_2_15_9  in_degree_1290  1
    arc_2_15_9  out_degree_1328  1
    arc_2_15_9  original_T_including_depot_unload_1360  925.691754925099
    MARKER    'MARKER'                 'INTEND'
    load_2_15_9  arc_capacity_1183  1
    load_2_15_9  segment_load_conservation_1293  -1
    load_2_15_9  segment_prefix_lb_1294  1
    load_2_15_9  segment_prefix_ub_1295  1
    load_2_15_9  free_load_conservation_1333  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_10  arc_capacity_1185  -30
    arc_2_15_10  connected_order_arc_1186  -12
    arc_2_15_10  in_degree_1297  1
    arc_2_15_10  out_degree_1328  1
    arc_2_15_10  original_T_including_depot_unload_1360  7.5965235847304257e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_10  arc_capacity_1185  1
    load_2_15_10  segment_load_conservation_1300  -1
    load_2_15_10  segment_prefix_lb_1301  1
    load_2_15_10  segment_prefix_ub_1302  1
    load_2_15_10  free_load_conservation_1333  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_11  arc_capacity_1187  -30
    arc_2_15_11  connected_order_arc_1188  -12
    arc_2_15_11  in_degree_1304  1
    arc_2_15_11  out_degree_1328  1
    arc_2_15_11  original_T_including_depot_unload_1360  4.8064504037614694e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_11  arc_capacity_1187  1
    load_2_15_11  segment_load_conservation_1307  -1
    load_2_15_11  segment_prefix_lb_1308  1
    load_2_15_11  segment_prefix_ub_1309  1
    load_2_15_11  free_load_conservation_1333  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_12  arc_capacity_1189  -30
    arc_2_15_12  connected_order_arc_1190  -12
    arc_2_15_12  in_degree_1311  1
    arc_2_15_12  out_degree_1328  1
    arc_2_15_12  original_T_including_depot_unload_1360  3.5235932354279930e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_12  arc_capacity_1189  1
    load_2_15_12  free_load_conservation_1315  -1
    load_2_15_12  free_load_conservation_1333  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_13  arc_capacity_1191  -30
    arc_2_15_13  connected_order_arc_1192  -12
    arc_2_15_13  in_degree_1317  1
    arc_2_15_13  out_degree_1328  1
    arc_2_15_13  original_T_including_depot_unload_1360  1.6320002720932780e+00
    MARKER    'MARKER'                 'INTEND'
    load_2_15_13  arc_capacity_1191  1
    load_2_15_13  free_load_conservation_1321  -1
    load_2_15_13  free_load_conservation_1333  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_14  arc_capacity_1193  -30
    arc_2_15_14  connected_order_arc_1194  -12
    arc_2_15_14  in_degree_1323  1
    arc_2_15_14  out_degree_1328  1
    arc_2_15_14  original_T_including_depot_unload_1360  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_14  arc_capacity_1193  1
    load_2_15_14  free_load_conservation_1327  -1
    load_2_15_14  free_load_conservation_1333  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_16  arc_capacity_1195  -30
    arc_2_15_16  connected_order_arc_1196  -12
    arc_2_15_16  out_degree_1328  1
    arc_2_15_16  in_degree_1335  1
    arc_2_15_16  original_T_including_depot_unload_1360  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_16  arc_capacity_1195  1
    load_2_15_16  free_load_conservation_1333  1
    load_2_15_16  free_load_conservation_1339  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_17  arc_capacity_1197  -30
    arc_2_15_17  connected_order_arc_1198  -12
    arc_2_15_17  out_degree_1328  1
    arc_2_15_17  in_degree_1341  1
    arc_2_15_17  original_T_including_depot_unload_1360  5.7424143497696048e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_17  arc_capacity_1197  1
    load_2_15_17  free_load_conservation_1333  1
    load_2_15_17  free_load_conservation_1345  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_18  arc_capacity_1199  -30
    arc_2_15_18  connected_order_arc_1200  -12
    arc_2_15_18  out_degree_1328  1
    arc_2_15_18  in_degree_1347  1
    arc_2_15_18  original_T_including_depot_unload_1360  8.8488037837239642e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_18  arc_capacity_1199  1
    load_2_15_18  free_load_conservation_1333  1
    load_2_15_18  free_load_conservation_1351  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_19  arc_capacity_1201  -30
    arc_2_15_19  connected_order_arc_1202  -12
    arc_2_15_19  out_degree_1328  1
    arc_2_15_19  in_degree_1353  1
    arc_2_15_19  original_T_including_depot_unload_1360  9.1041274142057227e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_19  arc_capacity_1201  1
    load_2_15_19  free_load_conservation_1333  1
    load_2_15_19  free_load_conservation_1357  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_0  arc_capacity_1203  -30
    arc_2_16_0  depot_return_or_bypass_1288  1
    arc_2_16_0  out_degree_1334  1
    arc_2_16_0  original_T_including_depot_unload_1360  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_0  arc_capacity_1203  1
    load_2_16_0  free_load_conservation_1339  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_9  arc_capacity_1204  -30
    arc_2_16_9  connected_order_arc_1205  -12
    arc_2_16_9  in_degree_1290  1
    arc_2_16_9  out_degree_1334  1
    arc_2_16_9  original_T_including_depot_unload_1360  5.7914586906741226e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_9  arc_capacity_1204  1
    load_2_16_9  segment_load_conservation_1293  -1
    load_2_16_9  segment_prefix_lb_1294  1
    load_2_16_9  segment_prefix_ub_1295  1
    load_2_16_9  free_load_conservation_1339  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_10  arc_capacity_1206  -30
    arc_2_16_10  connected_order_arc_1207  -12
    arc_2_16_10  in_degree_1297  1
    arc_2_16_10  out_degree_1334  1
    arc_2_16_10  original_T_including_depot_unload_1360  6.6929586395597710e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_10  arc_capacity_1206  1
    load_2_16_10  segment_load_conservation_1300  -1
    load_2_16_10  segment_prefix_lb_1301  1
    load_2_16_10  segment_prefix_ub_1302  1
    load_2_16_10  free_load_conservation_1339  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_11  arc_capacity_1208  -30
    arc_2_16_11  connected_order_arc_1209  -12
    arc_2_16_11  in_degree_1304  1
    arc_2_16_11  out_degree_1334  1
    arc_2_16_11  original_T_including_depot_unload_1360  1.0740788448852404e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_11  arc_capacity_1208  1
    load_2_16_11  segment_load_conservation_1307  -1
    load_2_16_11  segment_prefix_lb_1308  1
    load_2_16_11  segment_prefix_ub_1309  1
    load_2_16_11  free_load_conservation_1339  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_12  arc_capacity_1210  -30
    arc_2_16_12  connected_order_arc_1211  -12
    arc_2_16_12  in_degree_1311  1
    arc_2_16_12  out_degree_1334  1
    arc_2_16_12  original_T_including_depot_unload_1360  5.4405628017126674e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_12  arc_capacity_1210  1
    load_2_16_12  free_load_conservation_1315  -1
    load_2_16_12  free_load_conservation_1339  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_13  arc_capacity_1212  -30
    arc_2_16_13  connected_order_arc_1213  -12
    arc_2_16_13  in_degree_1317  1
    arc_2_16_13  out_degree_1334  1
    arc_2_16_13  original_T_including_depot_unload_1360  8.7906342149593650e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_13  arc_capacity_1212  1
    load_2_16_13  free_load_conservation_1321  -1
    load_2_16_13  free_load_conservation_1339  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_14  arc_capacity_1214  -30
    arc_2_16_14  connected_order_arc_1215  -12
    arc_2_16_14  in_degree_1323  1
    arc_2_16_14  out_degree_1334  1
    arc_2_16_14  original_T_including_depot_unload_1360  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_2_16_14  arc_capacity_1214  1
    load_2_16_14  free_load_conservation_1327  -1
    load_2_16_14  free_load_conservation_1339  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_15  arc_capacity_1216  -30
    arc_2_16_15  connected_order_arc_1217  -12
    arc_2_16_15  in_degree_1329  1
    arc_2_16_15  out_degree_1334  1
    arc_2_16_15  original_T_including_depot_unload_1360  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_15  arc_capacity_1216  1
    load_2_16_15  free_load_conservation_1333  -1
    load_2_16_15  free_load_conservation_1339  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_17  arc_capacity_1218  -30
    arc_2_16_17  connected_order_arc_1219  -12
    arc_2_16_17  out_degree_1334  1
    arc_2_16_17  in_degree_1341  1
    arc_2_16_17  original_T_including_depot_unload_1360  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_2_16_17  arc_capacity_1218  1
    load_2_16_17  free_load_conservation_1339  1
    load_2_16_17  free_load_conservation_1345  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_18  arc_capacity_1220  -30
    arc_2_16_18  connected_order_arc_1221  -12
    arc_2_16_18  out_degree_1334  1
    arc_2_16_18  in_degree_1347  1
    arc_2_16_18  original_T_including_depot_unload_1360  1.6388081578301370e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_18  arc_capacity_1220  1
    load_2_16_18  free_load_conservation_1339  1
    load_2_16_18  free_load_conservation_1351  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_19  arc_capacity_1222  -30
    arc_2_16_19  connected_order_arc_1223  -12
    arc_2_16_19  out_degree_1334  1
    arc_2_16_19  in_degree_1353  1
    arc_2_16_19  original_T_including_depot_unload_1360  3.6822662782562685e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_19  arc_capacity_1222  1
    load_2_16_19  free_load_conservation_1339  1
    load_2_16_19  free_load_conservation_1357  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_0  arc_capacity_1224  -30
    arc_2_17_0  depot_return_or_bypass_1288  1
    arc_2_17_0  out_degree_1340  1
    arc_2_17_0  original_T_including_depot_unload_1360  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_0  arc_capacity_1224  1
    load_2_17_0  free_load_conservation_1345  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_9  arc_capacity_1225  -30
    arc_2_17_9  connected_order_arc_1226  -12
    arc_2_17_9  in_degree_1290  1
    arc_2_17_9  out_degree_1340  1
    arc_2_17_9  original_T_including_depot_unload_1360  1.0984912119828512e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_9  arc_capacity_1225  1
    load_2_17_9  segment_load_conservation_1293  -1
    load_2_17_9  segment_prefix_lb_1294  1
    load_2_17_9  segment_prefix_ub_1295  1
    load_2_17_9  free_load_conservation_1345  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_10  arc_capacity_1227  -30
    arc_2_17_10  connected_order_arc_1228  -12
    arc_2_17_10  in_degree_1297  1
    arc_2_17_10  out_degree_1340  1
    arc_2_17_10  original_T_including_depot_unload_1360  1.0379751075251477e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_10  arc_capacity_1227  1
    load_2_17_10  segment_load_conservation_1300  -1
    load_2_17_10  segment_prefix_lb_1301  1
    load_2_17_10  segment_prefix_ub_1302  1
    load_2_17_10  free_load_conservation_1345  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_11  arc_capacity_1229  -30
    arc_2_17_11  connected_order_arc_1230  -12
    arc_2_17_11  in_degree_1304  1
    arc_2_17_11  out_degree_1340  1
    arc_2_17_11  original_T_including_depot_unload_1360  1.0279345387929015e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_11  arc_capacity_1229  1
    load_2_17_11  segment_load_conservation_1307  -1
    load_2_17_11  segment_prefix_lb_1308  1
    load_2_17_11  segment_prefix_ub_1309  1
    load_2_17_11  free_load_conservation_1345  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_12  arc_capacity_1231  -30
    arc_2_17_12  connected_order_arc_1232  -12
    arc_2_17_12  in_degree_1311  1
    arc_2_17_12  out_degree_1340  1
    arc_2_17_12  original_T_including_depot_unload_1360  3.7831268047064754e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_12  arc_capacity_1231  1
    load_2_17_12  free_load_conservation_1315  -1
    load_2_17_12  free_load_conservation_1345  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_13  arc_capacity_1233  -30
    arc_2_17_13  connected_order_arc_1234  -12
    arc_2_17_13  in_degree_1317  1
    arc_2_17_13  out_degree_1340  1
    arc_2_17_13  original_T_including_depot_unload_1360  5.7276146581216926e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_13  arc_capacity_1233  1
    load_2_17_13  free_load_conservation_1321  -1
    load_2_17_13  free_load_conservation_1345  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_14  arc_capacity_1235  -30
    arc_2_17_14  connected_order_arc_1236  -12
    arc_2_17_14  in_degree_1323  1
    arc_2_17_14  out_degree_1340  1
    arc_2_17_14  original_T_including_depot_unload_1360  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_14  arc_capacity_1235  1
    load_2_17_14  free_load_conservation_1327  -1
    load_2_17_14  free_load_conservation_1345  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_15  arc_capacity_1237  -30
    arc_2_17_15  connected_order_arc_1238  -12
    arc_2_17_15  in_degree_1329  1
    arc_2_17_15  out_degree_1340  1
    arc_2_17_15  original_T_including_depot_unload_1360  5.7424143497696048e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_15  arc_capacity_1237  1
    load_2_17_15  free_load_conservation_1333  -1
    load_2_17_15  free_load_conservation_1345  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_16  arc_capacity_1239  -30
    arc_2_17_16  connected_order_arc_1240  -12
    arc_2_17_16  in_degree_1335  1
    arc_2_17_16  out_degree_1340  1
    arc_2_17_16  original_T_including_depot_unload_1360  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_2_17_16  arc_capacity_1239  1
    load_2_17_16  free_load_conservation_1339  -1
    load_2_17_16  free_load_conservation_1345  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_18  arc_capacity_1241  -30
    arc_2_17_18  connected_order_arc_1242  -12
    arc_2_17_18  out_degree_1340  1
    arc_2_17_18  in_degree_1347  1
    arc_2_17_18  original_T_including_depot_unload_1360  608.963327854777
    MARKER    'MARKER'                 'INTEND'
    load_2_17_18  arc_capacity_1241  1
    load_2_17_18  free_load_conservation_1345  1
    load_2_17_18  free_load_conservation_1351  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_19  arc_capacity_1243  -30
    arc_2_17_19  connected_order_arc_1244  -12
    arc_2_17_19  out_degree_1340  1
    arc_2_17_19  in_degree_1353  1
    arc_2_17_19  original_T_including_depot_unload_1360  5.0398976026149836e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_19  arc_capacity_1243  1
    load_2_17_19  free_load_conservation_1345  1
    load_2_17_19  free_load_conservation_1357  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_0  arc_capacity_1245  -30
    arc_2_18_0  depot_return_or_bypass_1288  1
    arc_2_18_0  out_degree_1346  1
    arc_2_18_0  original_T_including_depot_unload_1360  778.011461754062
    MARKER    'MARKER'                 'INTEND'
    load_2_18_0  arc_capacity_1245  1
    load_2_18_0  free_load_conservation_1351  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_9  arc_capacity_1246  -30
    arc_2_18_9  connected_order_arc_1247  -12
    arc_2_18_9  in_degree_1290  1
    arc_2_18_9  out_degree_1346  1
    arc_2_18_9  original_T_including_depot_unload_1360  7.3693716289230485e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_9  arc_capacity_1246  1
    load_2_18_9  segment_load_conservation_1293  -1
    load_2_18_9  segment_prefix_lb_1294  1
    load_2_18_9  segment_prefix_ub_1295  1
    load_2_18_9  free_load_conservation_1351  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_10  arc_capacity_1248  -30
    arc_2_18_10  connected_order_arc_1249  -12
    arc_2_18_10  in_degree_1297  1
    arc_2_18_10  out_degree_1346  1
    arc_2_18_10  original_T_including_depot_unload_1360  8.0681198709780529e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_10  arc_capacity_1248  1
    load_2_18_10  segment_load_conservation_1300  -1
    load_2_18_10  segment_prefix_lb_1301  1
    load_2_18_10  segment_prefix_ub_1302  1
    load_2_18_10  free_load_conservation_1351  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_11  arc_capacity_1250  -30
    arc_2_18_11  connected_order_arc_1251  -12
    arc_2_18_11  in_degree_1304  1
    arc_2_18_11  out_degree_1346  1
    arc_2_18_11  original_T_including_depot_unload_1360  1.1473765463273915e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_11  arc_capacity_1250  1
    load_2_18_11  segment_load_conservation_1307  -1
    load_2_18_11  segment_prefix_lb_1308  1
    load_2_18_11  segment_prefix_ub_1309  1
    load_2_18_11  free_load_conservation_1351  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_12  arc_capacity_1252  -30
    arc_2_18_12  connected_order_arc_1253  -12
    arc_2_18_12  in_degree_1311  1
    arc_2_18_12  out_degree_1346  1
    arc_2_18_12  original_T_including_depot_unload_1360  5.3348116005684176e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_12  arc_capacity_1252  1
    load_2_18_12  free_load_conservation_1315  -1
    load_2_18_12  free_load_conservation_1351  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_13  arc_capacity_1254  -30
    arc_2_18_13  connected_order_arc_1255  -12
    arc_2_18_13  in_degree_1317  1
    arc_2_18_13  out_degree_1346  1
    arc_2_18_13  original_T_including_depot_unload_1360  8.8427037135592116e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_13  arc_capacity_1254  1
    load_2_18_13  free_load_conservation_1321  -1
    load_2_18_13  free_load_conservation_1351  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_14  arc_capacity_1256  -30
    arc_2_18_14  connected_order_arc_1257  -12
    arc_2_18_14  in_degree_1323  1
    arc_2_18_14  out_degree_1346  1
    arc_2_18_14  original_T_including_depot_unload_1360  8.0139063451811444e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_14  arc_capacity_1256  1
    load_2_18_14  free_load_conservation_1327  -1
    load_2_18_14  free_load_conservation_1351  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_15  arc_capacity_1258  -30
    arc_2_18_15  connected_order_arc_1259  -12
    arc_2_18_15  in_degree_1329  1
    arc_2_18_15  out_degree_1346  1
    arc_2_18_15  original_T_including_depot_unload_1360  8.8488037837239642e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_15  arc_capacity_1258  1
    load_2_18_15  free_load_conservation_1333  -1
    load_2_18_15  free_load_conservation_1351  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_16  arc_capacity_1260  -30
    arc_2_18_16  connected_order_arc_1261  -12
    arc_2_18_16  in_degree_1335  1
    arc_2_18_16  out_degree_1346  1
    arc_2_18_16  original_T_including_depot_unload_1360  1.6388081578301370e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_16  arc_capacity_1260  1
    load_2_18_16  free_load_conservation_1339  -1
    load_2_18_16  free_load_conservation_1351  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_17  arc_capacity_1262  -30
    arc_2_18_17  connected_order_arc_1263  -12
    arc_2_18_17  in_degree_1341  1
    arc_2_18_17  out_degree_1346  1
    arc_2_18_17  original_T_including_depot_unload_1360  608.963327854777
    MARKER    'MARKER'                 'INTEND'
    load_2_18_17  arc_capacity_1262  1
    load_2_18_17  free_load_conservation_1345  -1
    load_2_18_17  free_load_conservation_1351  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_19  arc_capacity_1264  -30
    arc_2_18_19  connected_order_arc_1265  -12
    arc_2_18_19  out_degree_1346  1
    arc_2_18_19  in_degree_1353  1
    arc_2_18_19  original_T_including_depot_unload_1360  204.956380049771
    MARKER    'MARKER'                 'INTEND'
    load_2_18_19  arc_capacity_1264  1
    load_2_18_19  free_load_conservation_1351  1
    load_2_18_19  free_load_conservation_1357  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_0  arc_capacity_1266  -30
    arc_2_19_0  depot_return_or_bypass_1288  1
    arc_2_19_0  out_degree_1352  1
    arc_2_19_0  original_T_including_depot_unload_1360  5.8421641813809208e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_0  arc_capacity_1266  1
    load_2_19_0  free_load_conservation_1357  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_9  arc_capacity_1267  -30
    arc_2_19_9  connected_order_arc_1268  -12
    arc_2_19_9  in_degree_1290  1
    arc_2_19_9  out_degree_1352  1
    arc_2_19_9  original_T_including_depot_unload_1360  9.3170331463979812e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_9  arc_capacity_1267  1
    load_2_19_9  segment_load_conservation_1293  -1
    load_2_19_9  segment_prefix_lb_1294  1
    load_2_19_9  segment_prefix_ub_1295  1
    load_2_19_9  free_load_conservation_1357  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_10  arc_capacity_1269  -30
    arc_2_19_10  connected_order_arc_1270  -12
    arc_2_19_10  in_degree_1297  1
    arc_2_19_10  out_degree_1352  1
    arc_2_19_10  original_T_including_depot_unload_1360  9.7958300464034107e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_10  arc_capacity_1269  1
    load_2_19_10  segment_load_conservation_1300  -1
    load_2_19_10  segment_prefix_lb_1301  1
    load_2_19_10  segment_prefix_ub_1302  1
    load_2_19_10  free_load_conservation_1357  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_11  arc_capacity_1271  -30
    arc_2_19_11  connected_order_arc_1272  -12
    arc_2_19_11  in_degree_1304  1
    arc_2_19_11  out_degree_1352  1
    arc_2_19_11  original_T_including_depot_unload_1360  1.2438605922360068e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_11  arc_capacity_1271  1
    load_2_19_11  segment_load_conservation_1307  -1
    load_2_19_11  segment_prefix_lb_1308  1
    load_2_19_11  segment_prefix_ub_1309  1
    load_2_19_11  free_load_conservation_1357  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_12  arc_capacity_1273  -30
    arc_2_19_12  connected_order_arc_1274  -12
    arc_2_19_12  in_degree_1311  1
    arc_2_19_12  out_degree_1352  1
    arc_2_19_12  original_T_including_depot_unload_1360  566.256001718161
    MARKER    'MARKER'                 'INTEND'
    load_2_19_12  arc_capacity_1273  1
    load_2_19_12  free_load_conservation_1315  -1
    load_2_19_12  free_load_conservation_1357  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_13  arc_capacity_1275  -30
    arc_2_19_13  connected_order_arc_1276  -12
    arc_2_19_13  in_degree_1317  1
    arc_2_19_13  out_degree_1352  1
    arc_2_19_13  original_T_including_depot_unload_1360  9.0947747566405189e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_13  arc_capacity_1275  1
    load_2_19_13  free_load_conservation_1321  -1
    load_2_19_13  free_load_conservation_1357  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_14  arc_capacity_1277  -30
    arc_2_19_14  connected_order_arc_1278  -12
    arc_2_19_14  in_degree_1323  1
    arc_2_19_14  out_degree_1352  1
    arc_2_19_14  original_T_including_depot_unload_1360  1.0063298732365655e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_14  arc_capacity_1277  1
    load_2_19_14  free_load_conservation_1327  -1
    load_2_19_14  free_load_conservation_1357  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_15  arc_capacity_1279  -30
    arc_2_19_15  connected_order_arc_1280  -12
    arc_2_19_15  in_degree_1329  1
    arc_2_19_15  out_degree_1352  1
    arc_2_19_15  original_T_including_depot_unload_1360  9.1041274142057227e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_15  arc_capacity_1279  1
    load_2_19_15  free_load_conservation_1333  -1
    load_2_19_15  free_load_conservation_1357  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_16  arc_capacity_1281  -30
    arc_2_19_16  connected_order_arc_1282  -12
    arc_2_19_16  in_degree_1335  1
    arc_2_19_16  out_degree_1352  1
    arc_2_19_16  original_T_including_depot_unload_1360  3.6822662782562685e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_16  arc_capacity_1281  1
    load_2_19_16  free_load_conservation_1339  -1
    load_2_19_16  free_load_conservation_1357  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_17  arc_capacity_1283  -30
    arc_2_19_17  connected_order_arc_1284  -12
    arc_2_19_17  in_degree_1341  1
    arc_2_19_17  out_degree_1352  1
    arc_2_19_17  original_T_including_depot_unload_1360  5.0398976026149836e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_17  arc_capacity_1283  1
    load_2_19_17  free_load_conservation_1345  -1
    load_2_19_17  free_load_conservation_1357  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_18  arc_capacity_1285  -30
    arc_2_19_18  connected_order_arc_1286  -12
    arc_2_19_18  in_degree_1347  1
    arc_2_19_18  out_degree_1352  1
    arc_2_19_18  original_T_including_depot_unload_1360  204.956380049771
    MARKER    'MARKER'                 'INTEND'
    load_2_19_18  arc_capacity_1285  1
    load_2_19_18  free_load_conservation_1351  -1
    load_2_19_18  free_load_conservation_1357  1
RHS
    RHS1      OBJ       -2.1099424725013483e-01
    RHS1      onehot_26_18  1
    RHS1      onehot_28_35  1
    RHS1      onehot_34_70  1
    RHS1      onehot_29_95  1
    RHS1      onehot_27_112  1
    RHS1      onehot_22_147  1
    RHS1      onehot_25_160  1
    RHS1      onehot_23_171  1
    RHS1      stock_ub_175  14
    RHS1      parent_nonstrict_scope_176  2.9029702465327534e-01
    RHS1      normalization_233  1
    RHS1      connected_order_arc_317  -12
    RHS1      connected_order_arc_319  -12
    RHS1      connected_order_arc_321  -12
    RHS1      connected_order_arc_323  -12
    RHS1      connected_order_arc_325  -12
    RHS1      connected_order_arc_327  -12
    RHS1      connected_order_arc_329  -12
    RHS1      connected_order_arc_331  -12
    RHS1      connected_order_arc_333  -12
    RHS1      connected_order_arc_335  -12
    RHS1      connected_order_arc_337  -12
    RHS1      connected_order_arc_340  -12
    RHS1      connected_order_arc_342  -12
    RHS1      connected_order_arc_344  -12
    RHS1      connected_order_arc_346  -12
    RHS1      connected_order_arc_348  -12
    RHS1      connected_order_arc_350  -12
    RHS1      connected_order_arc_352  -12
    RHS1      connected_order_arc_354  -12
    RHS1      connected_order_arc_356  -12
    RHS1      connected_order_arc_358  -12
    RHS1      connected_order_arc_360  -12
    RHS1      connected_order_arc_363  -12
    RHS1      connected_order_arc_365  -12
    RHS1      connected_order_arc_367  -12
    RHS1      connected_order_arc_369  -12
    RHS1      connected_order_arc_371  -12
    RHS1      connected_order_arc_373  -12
    RHS1      connected_order_arc_375  -12
    RHS1      connected_order_arc_377  -12
    RHS1      connected_order_arc_379  -12
    RHS1      connected_order_arc_381  -12
    RHS1      connected_order_arc_383  -12
    RHS1      connected_order_arc_386  -12
    RHS1      connected_order_arc_388  -12
    RHS1      connected_order_arc_390  -12
    RHS1      connected_order_arc_392  -12
    RHS1      connected_order_arc_394  -12
    RHS1      connected_order_arc_396  -12
    RHS1      connected_order_arc_398  -12
    RHS1      connected_order_arc_400  -12
    RHS1      connected_order_arc_402  -12
    RHS1      connected_order_arc_404  -12
    RHS1      connected_order_arc_406  -12
    RHS1      connected_order_arc_409  -12
    RHS1      connected_order_arc_411  -12
    RHS1      connected_order_arc_413  -12
    RHS1      connected_order_arc_415  -12
    RHS1      connected_order_arc_417  -12
    RHS1      connected_order_arc_419  -12
    RHS1      connected_order_arc_421  -12
    RHS1      connected_order_arc_423  -12
    RHS1      connected_order_arc_425  -12
    RHS1      connected_order_arc_427  -12
    RHS1      connected_order_arc_429  -12
    RHS1      connected_order_arc_432  -12
    RHS1      connected_order_arc_434  -12
    RHS1      connected_order_arc_436  -12
    RHS1      connected_order_arc_438  -12
    RHS1      connected_order_arc_440  -12
    RHS1      connected_order_arc_442  -12
    RHS1      connected_order_arc_444  -12
    RHS1      connected_order_arc_446  -12
    RHS1      connected_order_arc_448  -12
    RHS1      connected_order_arc_450  -12
    RHS1      connected_order_arc_452  -12
    RHS1      connected_order_arc_455  -12
    RHS1      connected_order_arc_457  -12
    RHS1      connected_order_arc_459  -12
    RHS1      connected_order_arc_461  -12
    RHS1      connected_order_arc_463  -12
    RHS1      connected_order_arc_465  -12
    RHS1      connected_order_arc_467  -12
    RHS1      connected_order_arc_469  -12
    RHS1      connected_order_arc_471  -12
    RHS1      connected_order_arc_473  -12
    RHS1      connected_order_arc_475  -12
    RHS1      connected_order_arc_478  -12
    RHS1      connected_order_arc_480  -12
    RHS1      connected_order_arc_482  -12
    RHS1      connected_order_arc_484  -12
    RHS1      connected_order_arc_486  -12
    RHS1      connected_order_arc_488  -12
    RHS1      connected_order_arc_490  -12
    RHS1      connected_order_arc_492  -12
    RHS1      connected_order_arc_494  -12
    RHS1      connected_order_arc_496  -12
    RHS1      connected_order_arc_498  -12
    RHS1      connected_order_arc_501  -12
    RHS1      connected_order_arc_503  -12
    RHS1      connected_order_arc_505  -12
    RHS1      connected_order_arc_507  -12
    RHS1      connected_order_arc_509  -12
    RHS1      connected_order_arc_511  -12
    RHS1      connected_order_arc_513  -12
    RHS1      connected_order_arc_515  -12
    RHS1      connected_order_arc_517  -12
    RHS1      connected_order_arc_519  -12
    RHS1      connected_order_arc_521  -12
    RHS1      connected_order_arc_524  -12
    RHS1      connected_order_arc_526  -12
    RHS1      connected_order_arc_528  -12
    RHS1      connected_order_arc_530  -12
    RHS1      connected_order_arc_532  -12
    RHS1      connected_order_arc_534  -12
    RHS1      connected_order_arc_536  -12
    RHS1      connected_order_arc_538  -12
    RHS1      connected_order_arc_540  -12
    RHS1      connected_order_arc_542  -12
    RHS1      connected_order_arc_544  -12
    RHS1      connected_order_arc_547  -12
    RHS1      connected_order_arc_549  -12
    RHS1      connected_order_arc_551  -12
    RHS1      connected_order_arc_553  -12
    RHS1      connected_order_arc_555  -12
    RHS1      connected_order_arc_557  -12
    RHS1      connected_order_arc_559  -12
    RHS1      connected_order_arc_561  -12
    RHS1      connected_order_arc_563  -12
    RHS1      connected_order_arc_565  -12
    RHS1      connected_order_arc_567  -12
    RHS1      connected_order_arc_570  -12
    RHS1      connected_order_arc_572  -12
    RHS1      connected_order_arc_574  -12
    RHS1      connected_order_arc_576  -12
    RHS1      connected_order_arc_578  -12
    RHS1      connected_order_arc_580  -12
    RHS1      connected_order_arc_582  -12
    RHS1      connected_order_arc_584  -12
    RHS1      connected_order_arc_586  -12
    RHS1      connected_order_arc_588  -12
    RHS1      connected_order_arc_590  -12
    RHS1      depot_departure_or_bypass_591  1
    RHS1      depot_return_or_bypass_592  1
    RHS1      segment_load_conservation_597  1
    RHS1      segment_prefix_ub_599  8
    RHS1      segment_load_conservation_604  1
    RHS1      segment_prefix_ub_606  15
    RHS1      segment_load_conservation_611  2
    RHS1      segment_prefix_ub_613  18
    RHS1      segment_load_conservation_618  -3
    RHS1      segment_prefix_lb_619  3
    RHS1      segment_prefix_ub_620  20
    RHS1      fixed_segment_relative_order_669  1
    RHS1      fixed_segment_relative_order_670  1
    RHS1      fixed_segment_relative_order_671  1
    RHS1      original_T_including_depot_unload_672  1.4344626971989874e+03
    RHS1      connected_order_arc_688  -12
    RHS1      connected_order_arc_690  -12
    RHS1      connected_order_arc_692  -12
    RHS1      connected_order_arc_694  -12
    RHS1      connected_order_arc_696  -12
    RHS1      connected_order_arc_698  -12
    RHS1      connected_order_arc_700  -12
    RHS1      connected_order_arc_702  -12
    RHS1      connected_order_arc_704  -12
    RHS1      connected_order_arc_706  -12
    RHS1      connected_order_arc_708  -12
    RHS1      connected_order_arc_711  -12
    RHS1      connected_order_arc_713  -12
    RHS1      connected_order_arc_715  -12
    RHS1      connected_order_arc_717  -12
    RHS1      connected_order_arc_719  -12
    RHS1      connected_order_arc_721  -12
    RHS1      connected_order_arc_723  -12
    RHS1      connected_order_arc_725  -12
    RHS1      connected_order_arc_727  -12
    RHS1      connected_order_arc_729  -12
    RHS1      connected_order_arc_731  -12
    RHS1      connected_order_arc_734  -12
    RHS1      connected_order_arc_736  -12
    RHS1      connected_order_arc_738  -12
    RHS1      connected_order_arc_740  -12
    RHS1      connected_order_arc_742  -12
    RHS1      connected_order_arc_744  -12
    RHS1      connected_order_arc_746  -12
    RHS1      connected_order_arc_748  -12
    RHS1      connected_order_arc_750  -12
    RHS1      connected_order_arc_752  -12
    RHS1      connected_order_arc_754  -12
    RHS1      connected_order_arc_757  -12
    RHS1      connected_order_arc_759  -12
    RHS1      connected_order_arc_761  -12
    RHS1      connected_order_arc_763  -12
    RHS1      connected_order_arc_765  -12
    RHS1      connected_order_arc_767  -12
    RHS1      connected_order_arc_769  -12
    RHS1      connected_order_arc_771  -12
    RHS1      connected_order_arc_773  -12
    RHS1      connected_order_arc_775  -12
    RHS1      connected_order_arc_777  -12
    RHS1      connected_order_arc_780  -12
    RHS1      connected_order_arc_782  -12
    RHS1      connected_order_arc_784  -12
    RHS1      connected_order_arc_786  -12
    RHS1      connected_order_arc_788  -12
    RHS1      connected_order_arc_790  -12
    RHS1      connected_order_arc_792  -12
    RHS1      connected_order_arc_794  -12
    RHS1      connected_order_arc_796  -12
    RHS1      connected_order_arc_798  -12
    RHS1      connected_order_arc_800  -12
    RHS1      connected_order_arc_803  -12
    RHS1      connected_order_arc_805  -12
    RHS1      connected_order_arc_807  -12
    RHS1      connected_order_arc_809  -12
    RHS1      connected_order_arc_811  -12
    RHS1      connected_order_arc_813  -12
    RHS1      connected_order_arc_815  -12
    RHS1      connected_order_arc_817  -12
    RHS1      connected_order_arc_819  -12
    RHS1      connected_order_arc_821  -12
    RHS1      connected_order_arc_823  -12
    RHS1      connected_order_arc_826  -12
    RHS1      connected_order_arc_828  -12
    RHS1      connected_order_arc_830  -12
    RHS1      connected_order_arc_832  -12
    RHS1      connected_order_arc_834  -12
    RHS1      connected_order_arc_836  -12
    RHS1      connected_order_arc_838  -12
    RHS1      connected_order_arc_840  -12
    RHS1      connected_order_arc_842  -12
    RHS1      connected_order_arc_844  -12
    RHS1      connected_order_arc_846  -12
    RHS1      connected_order_arc_849  -12
    RHS1      connected_order_arc_851  -12
    RHS1      connected_order_arc_853  -12
    RHS1      connected_order_arc_855  -12
    RHS1      connected_order_arc_857  -12
    RHS1      connected_order_arc_859  -12
    RHS1      connected_order_arc_861  -12
    RHS1      connected_order_arc_863  -12
    RHS1      connected_order_arc_865  -12
    RHS1      connected_order_arc_867  -12
    RHS1      connected_order_arc_869  -12
    RHS1      connected_order_arc_872  -12
    RHS1      connected_order_arc_874  -12
    RHS1      connected_order_arc_876  -12
    RHS1      connected_order_arc_878  -12
    RHS1      connected_order_arc_880  -12
    RHS1      connected_order_arc_882  -12
    RHS1      connected_order_arc_884  -12
    RHS1      connected_order_arc_886  -12
    RHS1      connected_order_arc_888  -12
    RHS1      connected_order_arc_890  -12
    RHS1      connected_order_arc_892  -12
    RHS1      connected_order_arc_895  -12
    RHS1      connected_order_arc_897  -12
    RHS1      connected_order_arc_899  -12
    RHS1      connected_order_arc_901  -12
    RHS1      connected_order_arc_903  -12
    RHS1      connected_order_arc_905  -12
    RHS1      connected_order_arc_907  -12
    RHS1      connected_order_arc_909  -12
    RHS1      connected_order_arc_911  -12
    RHS1      connected_order_arc_913  -12
    RHS1      connected_order_arc_915  -12
    RHS1      connected_order_arc_918  -12
    RHS1      connected_order_arc_920  -12
    RHS1      connected_order_arc_922  -12
    RHS1      connected_order_arc_924  -12
    RHS1      connected_order_arc_926  -12
    RHS1      connected_order_arc_928  -12
    RHS1      connected_order_arc_930  -12
    RHS1      connected_order_arc_932  -12
    RHS1      connected_order_arc_934  -12
    RHS1      connected_order_arc_936  -12
    RHS1      connected_order_arc_938  -12
    RHS1      connected_order_arc_941  -12
    RHS1      connected_order_arc_943  -12
    RHS1      connected_order_arc_945  -12
    RHS1      connected_order_arc_947  -12
    RHS1      connected_order_arc_949  -12
    RHS1      connected_order_arc_951  -12
    RHS1      connected_order_arc_953  -12
    RHS1      connected_order_arc_955  -12
    RHS1      connected_order_arc_957  -12
    RHS1      connected_order_arc_959  -12
    RHS1      connected_order_arc_961  -12
    RHS1      depot_departure_or_bypass_962  1
    RHS1      depot_return_or_bypass_963  1
    RHS1      segment_load_conservation_968  5
    RHS1      segment_prefix_ub_970  20
    RHS1      segment_load_conservation_975  4
    RHS1      segment_prefix_lb_976  1
    RHS1      segment_prefix_ub_977  21
    RHS1      segment_load_conservation_982  -4
    RHS1      segment_prefix_lb_983  4
    RHS1      segment_prefix_ub_984  25
    RHS1      segment_load_conservation_989  -5
    RHS1      segment_prefix_lb_990  5
    RHS1      segment_prefix_ub_991  25
    RHS1      fixed_segment_relative_order_1040  1
    RHS1      fixed_segment_relative_order_1041  1
    RHS1      fixed_segment_relative_order_1042  1
    RHS1      original_T_including_depot_unload_1043  4.0640082462635783e+03
    RHS1      connected_order_arc_1058  -11
    RHS1      connected_order_arc_1060  -11
    RHS1      connected_order_arc_1062  -11
    RHS1      connected_order_arc_1064  -11
    RHS1      connected_order_arc_1066  -11
    RHS1      connected_order_arc_1068  -11
    RHS1      connected_order_arc_1070  -11
    RHS1      connected_order_arc_1072  -11
    RHS1      connected_order_arc_1074  -11
    RHS1      connected_order_arc_1076  -11
    RHS1      connected_order_arc_1079  -11
    RHS1      connected_order_arc_1081  -11
    RHS1      connected_order_arc_1083  -11
    RHS1      connected_order_arc_1085  -11
    RHS1      connected_order_arc_1087  -11
    RHS1      connected_order_arc_1089  -11
    RHS1      connected_order_arc_1091  -11
    RHS1      connected_order_arc_1093  -11
    RHS1      connected_order_arc_1095  -11
    RHS1      connected_order_arc_1097  -11
    RHS1      connected_order_arc_1100  -11
    RHS1      connected_order_arc_1102  -11
    RHS1      connected_order_arc_1104  -11
    RHS1      connected_order_arc_1106  -11
    RHS1      connected_order_arc_1108  -11
    RHS1      connected_order_arc_1110  -11
    RHS1      connected_order_arc_1112  -11
    RHS1      connected_order_arc_1114  -11
    RHS1      connected_order_arc_1116  -11
    RHS1      connected_order_arc_1118  -11
    RHS1      connected_order_arc_1121  -11
    RHS1      connected_order_arc_1123  -11
    RHS1      connected_order_arc_1125  -11
    RHS1      connected_order_arc_1127  -11
    RHS1      connected_order_arc_1129  -11
    RHS1      connected_order_arc_1131  -11
    RHS1      connected_order_arc_1133  -11
    RHS1      connected_order_arc_1135  -11
    RHS1      connected_order_arc_1137  -11
    RHS1      connected_order_arc_1139  -11
    RHS1      connected_order_arc_1142  -11
    RHS1      connected_order_arc_1144  -11
    RHS1      connected_order_arc_1146  -11
    RHS1      connected_order_arc_1148  -11
    RHS1      connected_order_arc_1150  -11
    RHS1      connected_order_arc_1152  -11
    RHS1      connected_order_arc_1154  -11
    RHS1      connected_order_arc_1156  -11
    RHS1      connected_order_arc_1158  -11
    RHS1      connected_order_arc_1160  -11
    RHS1      connected_order_arc_1163  -11
    RHS1      connected_order_arc_1165  -11
    RHS1      connected_order_arc_1167  -11
    RHS1      connected_order_arc_1169  -11
    RHS1      connected_order_arc_1171  -11
    RHS1      connected_order_arc_1173  -11
    RHS1      connected_order_arc_1175  -11
    RHS1      connected_order_arc_1177  -11
    RHS1      connected_order_arc_1179  -11
    RHS1      connected_order_arc_1181  -11
    RHS1      connected_order_arc_1184  -11
    RHS1      connected_order_arc_1186  -11
    RHS1      connected_order_arc_1188  -11
    RHS1      connected_order_arc_1190  -11
    RHS1      connected_order_arc_1192  -11
    RHS1      connected_order_arc_1194  -11
    RHS1      connected_order_arc_1196  -11
    RHS1      connected_order_arc_1198  -11
    RHS1      connected_order_arc_1200  -11
    RHS1      connected_order_arc_1202  -11
    RHS1      connected_order_arc_1205  -11
    RHS1      connected_order_arc_1207  -11
    RHS1      connected_order_arc_1209  -11
    RHS1      connected_order_arc_1211  -11
    RHS1      connected_order_arc_1213  -11
    RHS1      connected_order_arc_1215  -11
    RHS1      connected_order_arc_1217  -11
    RHS1      connected_order_arc_1219  -11
    RHS1      connected_order_arc_1221  -11
    RHS1      connected_order_arc_1223  -11
    RHS1      connected_order_arc_1226  -11
    RHS1      connected_order_arc_1228  -11
    RHS1      connected_order_arc_1230  -11
    RHS1      connected_order_arc_1232  -11
    RHS1      connected_order_arc_1234  -11
    RHS1      connected_order_arc_1236  -11
    RHS1      connected_order_arc_1238  -11
    RHS1      connected_order_arc_1240  -11
    RHS1      connected_order_arc_1242  -11
    RHS1      connected_order_arc_1244  -11
    RHS1      connected_order_arc_1247  -11
    RHS1      connected_order_arc_1249  -11
    RHS1      connected_order_arc_1251  -11
    RHS1      connected_order_arc_1253  -11
    RHS1      connected_order_arc_1255  -11
    RHS1      connected_order_arc_1257  -11
    RHS1      connected_order_arc_1259  -11
    RHS1      connected_order_arc_1261  -11
    RHS1      connected_order_arc_1263  -11
    RHS1      connected_order_arc_1265  -11
    RHS1      connected_order_arc_1268  -11
    RHS1      connected_order_arc_1270  -11
    RHS1      connected_order_arc_1272  -11
    RHS1      connected_order_arc_1274  -11
    RHS1      connected_order_arc_1276  -11
    RHS1      connected_order_arc_1278  -11
    RHS1      connected_order_arc_1280  -11
    RHS1      connected_order_arc_1282  -11
    RHS1      connected_order_arc_1284  -11
    RHS1      connected_order_arc_1286  -11
    RHS1      depot_departure_or_bypass_1287  1
    RHS1      depot_return_or_bypass_1288  1
    RHS1      segment_load_conservation_1293  2
    RHS1      segment_prefix_ub_1295  28
    RHS1      segment_load_conservation_1300  -4
    RHS1      segment_prefix_lb_1301  4
    RHS1      segment_prefix_ub_1302  30
    RHS1      segment_load_conservation_1307  3
    RHS1      segment_prefix_ub_1309  26
    RHS1      fixed_segment_relative_order_1358  1
    RHS1      fixed_segment_relative_order_1359  1
    RHS1      original_T_including_depot_unload_1360  4.3991520335762489e+03
BOUNDS
 LO BND1      t         2.4093620927006652e-02
 UP BND1      t         4.0838154504392050e-02
 UP BND1      q         4.0666271100568246e-01
 BV BND1      x_26_0  
 UP BND1      w_26_0    4.0838154504392050e-02
 BV BND1      x_26_1  
 UP BND1      w_26_1    4.0838154504392050e-02
 BV BND1      x_26_2  
 UP BND1      w_26_2    4.0838154504392050e-02
 BV BND1      x_26_3  
 UP BND1      w_26_3    4.0838154504392050e-02
 BV BND1      x_26_4  
 UP BND1      w_26_4    4.0838154504392050e-02
 BV BND1      x_26_5  
 UP BND1      w_26_5    4.0838154504392050e-02
 BV BND1      x_26_6  
 UP BND1      w_26_6    4.0838154504392050e-02
 BV BND1      x_26_7  
 UP BND1      w_26_7    4.0838154504392050e-02
 BV BND1      x_26_8  
 UP BND1      w_26_8    4.0838154504392050e-02
 UP BND1      rho_26    1
 BV BND1      x_28_0  
 UP BND1      w_28_0    4.0838154504392050e-02
 BV BND1      x_28_1  
 UP BND1      w_28_1    4.0838154504392050e-02
 BV BND1      x_28_2  
 UP BND1      w_28_2    4.0838154504392050e-02
 BV BND1      x_28_3  
 UP BND1      w_28_3    4.0838154504392050e-02
 BV BND1      x_28_4  
 UP BND1      w_28_4    4.0838154504392050e-02
 BV BND1      x_28_5  
 UP BND1      w_28_5    4.0838154504392050e-02
 BV BND1      x_28_6  
 UP BND1      w_28_6    4.0838154504392050e-02
 UP BND1      rho_28    1
 BV BND1      x_34_0  
 UP BND1      w_34_0    4.0838154504392050e-02
 BV BND1      x_34_1  
 UP BND1      w_34_1    4.0838154504392050e-02
 BV BND1      x_34_2  
 UP BND1      w_34_2    4.0838154504392050e-02
 BV BND1      x_34_3  
 UP BND1      w_34_3    4.0838154504392050e-02
 BV BND1      x_34_4  
 UP BND1      w_34_4    4.0838154504392050e-02
 BV BND1      x_34_5  
 UP BND1      w_34_5    4.0838154504392050e-02
 BV BND1      x_34_6  
 UP BND1      w_34_6    4.0838154504392050e-02
 BV BND1      x_34_7  
 UP BND1      w_34_7    4.0838154504392050e-02
 BV BND1      x_34_8  
 UP BND1      w_34_8    4.0838154504392050e-02
 BV BND1      x_34_9  
 UP BND1      w_34_9    4.0838154504392050e-02
 BV BND1      x_34_10 
 UP BND1      w_34_10   4.0838154504392050e-02
 BV BND1      x_34_11 
 UP BND1      w_34_11   4.0838154504392050e-02
 BV BND1      x_34_12 
 UP BND1      w_34_12   4.0838154504392050e-02
 BV BND1      x_34_13 
 UP BND1      w_34_13   4.0838154504392050e-02
 BV BND1      x_34_14 
 UP BND1      w_34_14   4.0838154504392050e-02
 BV BND1      x_34_15 
 UP BND1      w_34_15   4.0838154504392050e-02
 UP BND1      rho_34    1
 BV BND1      x_29_0  
 UP BND1      w_29_0    4.0838154504392050e-02
 BV BND1      x_29_1  
 UP BND1      w_29_1    4.0838154504392050e-02
 BV BND1      x_29_2  
 UP BND1      w_29_2    4.0838154504392050e-02
 BV BND1      x_29_3  
 UP BND1      w_29_3    4.0838154504392050e-02
 BV BND1      x_29_4  
 UP BND1      w_29_4    4.0838154504392050e-02
 BV BND1      x_29_5  
 UP BND1      w_29_5    4.0838154504392050e-02
 BV BND1      x_29_6  
 UP BND1      w_29_6    4.0838154504392050e-02
 BV BND1      x_29_7  
 UP BND1      w_29_7    4.0838154504392050e-02
 BV BND1      x_29_8  
 UP BND1      w_29_8    4.0838154504392050e-02
 BV BND1      x_29_9  
 UP BND1      w_29_9    4.0838154504392050e-02
 BV BND1      x_29_10 
 UP BND1      w_29_10   4.0838154504392050e-02
 UP BND1      rho_29    1
 BV BND1      x_27_0  
 UP BND1      w_27_0    4.0838154504392050e-02
 BV BND1      x_27_1  
 UP BND1      w_27_1    4.0838154504392050e-02
 BV BND1      x_27_2  
 UP BND1      w_27_2    4.0838154504392050e-02
 BV BND1      x_27_3  
 UP BND1      w_27_3    4.0838154504392050e-02
 BV BND1      x_27_4  
 UP BND1      w_27_4    4.0838154504392050e-02
 BV BND1      x_27_5  
 UP BND1      w_27_5    4.0838154504392050e-02
 BV BND1      x_27_6  
 UP BND1      w_27_6    4.0838154504392050e-02
 UP BND1      rho_27    1
 BV BND1      x_22_0  
 UP BND1      w_22_0    4.0838154504392050e-02
 BV BND1      x_22_1  
 UP BND1      w_22_1    4.0838154504392050e-02
 BV BND1      x_22_2  
 UP BND1      w_22_2    4.0838154504392050e-02
 BV BND1      x_22_3  
 UP BND1      w_22_3    4.0838154504392050e-02
 BV BND1      x_22_4  
 UP BND1      w_22_4    4.0838154504392050e-02
 BV BND1      x_22_5  
 UP BND1      w_22_5    4.0838154504392050e-02
 BV BND1      x_22_6  
 UP BND1      w_22_6    4.0838154504392050e-02
 BV BND1      x_22_7  
 UP BND1      w_22_7    4.0838154504392050e-02
 BV BND1      x_22_8  
 UP BND1      w_22_8    4.0838154504392050e-02
 BV BND1      x_22_9  
 UP BND1      w_22_9    4.0838154504392050e-02
 BV BND1      x_22_10 
 UP BND1      w_22_10   4.0838154504392050e-02
 BV BND1      x_22_11 
 UP BND1      w_22_11   4.0838154504392050e-02
 BV BND1      x_22_12 
 UP BND1      w_22_12   4.0838154504392050e-02
 BV BND1      x_22_13 
 UP BND1      w_22_13   4.0838154504392050e-02
 BV BND1      x_22_14 
 UP BND1      w_22_14   4.0838154504392050e-02
 BV BND1      x_22_15 
 UP BND1      w_22_15   4.0838154504392050e-02
 UP BND1      rho_22    1
 BV BND1      x_25_0  
 UP BND1      w_25_0    4.0838154504392050e-02
 BV BND1      x_25_1  
 UP BND1      w_25_1    4.0838154504392050e-02
 BV BND1      x_25_2  
 UP BND1      w_25_2    4.0838154504392050e-02
 BV BND1      x_25_3  
 UP BND1      w_25_3    4.0838154504392050e-02
 BV BND1      x_25_4  
 UP BND1      w_25_4    4.0838154504392050e-02
 UP BND1      rho_25    1
 BV BND1      x_23_0  
 UP BND1      w_23_0    4.0838154504392050e-02
 BV BND1      x_23_1  
 UP BND1      w_23_1    4.0838154504392050e-02
 BV BND1      x_23_2  
 UP BND1      w_23_2    4.0838154504392050e-02
 BV BND1      x_23_3  
 UP BND1      w_23_3    4.0838154504392050e-02
 UP BND1      rho_23    1
 UP BND1      a_26_28   1
 UP BND1      a_26_34   1
 UP BND1      a_26_29   1
 UP BND1      a_26_27   1
 UP BND1      a_26_22   1
 UP BND1      a_26_25   1
 UP BND1      a_26_23   1
 UP BND1      a_28_34   1
 UP BND1      a_28_29   1
 UP BND1      a_28_27   1
 UP BND1      a_28_22   1
 UP BND1      a_28_25   1
 UP BND1      a_28_23   1
 UP BND1      a_34_29   1
 UP BND1      a_34_27   1
 UP BND1      a_34_22   1
 UP BND1      a_34_25   1
 UP BND1      a_34_23   1
 UP BND1      a_29_27   1
 UP BND1      a_29_22   1
 UP BND1      a_29_25   1
 UP BND1      a_29_23   1
 UP BND1      a_27_22   1
 UP BND1      a_27_25   1
 UP BND1      a_27_23   1
 UP BND1      a_22_25   1
 UP BND1      a_22_23   1
 UP BND1      a_25_23   1
 BV BND1      service_0_26_0
 BV BND1      service_0_26_1
 BV BND1      service_0_26_2
 BV BND1      service_0_26_3
 BV BND1      service_0_26_4
 BV BND1      service_0_26_6
 BV BND1      service_0_26_7
 BV BND1      service_0_26_8
 BV BND1      service_1_26_0
 BV BND1      service_1_26_1
 BV BND1      service_1_26_2
 BV BND1      service_1_26_3
 BV BND1      service_1_26_4
 BV BND1      service_1_26_6
 BV BND1      service_1_26_7
 BV BND1      service_1_26_8
 BV BND1      service_2_26_0
 BV BND1      service_2_26_1
 BV BND1      service_2_26_2
 BV BND1      service_2_26_3
 BV BND1      service_2_26_4
 BV BND1      service_2_26_6
 BV BND1      service_2_26_7
 BV BND1      service_2_26_8
 BV BND1      service_0_28_0
 BV BND1      service_0_28_2
 BV BND1      service_0_28_3
 BV BND1      service_0_28_4
 BV BND1      service_0_28_5
 BV BND1      service_0_28_6
 BV BND1      service_1_28_0
 BV BND1      service_1_28_2
 BV BND1      service_1_28_3
 BV BND1      service_1_28_4
 BV BND1      service_1_28_5
 BV BND1      service_1_28_6
 BV BND1      service_2_28_0
 BV BND1      service_2_28_2
 BV BND1      service_2_28_3
 BV BND1      service_2_28_4
 BV BND1      service_2_28_5
 BV BND1      service_2_28_6
 BV BND1      service_0_34_0
 BV BND1      service_0_34_1
 BV BND1      service_0_34_3
 BV BND1      service_0_34_4
 BV BND1      service_0_34_5
 BV BND1      service_0_34_6
 BV BND1      service_0_34_7
 BV BND1      service_0_34_8
 BV BND1      service_0_34_9
 BV BND1      service_0_34_10
 BV BND1      service_0_34_11
 BV BND1      service_0_34_12
 BV BND1      service_0_34_13
 BV BND1      service_0_34_14
 BV BND1      service_0_34_15
 BV BND1      service_1_34_0
 BV BND1      service_1_34_1
 BV BND1      service_1_34_3
 BV BND1      service_1_34_4
 BV BND1      service_1_34_5
 BV BND1      service_1_34_6
 BV BND1      service_1_34_7
 BV BND1      service_1_34_8
 BV BND1      service_1_34_9
 BV BND1      service_1_34_10
 BV BND1      service_1_34_11
 BV BND1      service_1_34_12
 BV BND1      service_1_34_13
 BV BND1      service_1_34_14
 BV BND1      service_1_34_15
 BV BND1      service_2_34_0
 BV BND1      service_2_34_1
 BV BND1      service_2_34_3
 BV BND1      service_2_34_4
 BV BND1      service_2_34_5
 BV BND1      service_2_34_6
 BV BND1      service_2_34_7
 BV BND1      service_2_34_8
 BV BND1      service_2_34_9
 BV BND1      service_2_34_10
 BV BND1      service_2_34_11
 BV BND1      service_2_34_12
 BV BND1      service_2_34_13
 BV BND1      service_2_34_14
 BV BND1      service_2_34_15
 BV BND1      service_0_29_0
 BV BND1      service_0_29_2
 BV BND1      service_0_29_3
 BV BND1      service_0_29_4
 BV BND1      service_0_29_5
 BV BND1      service_0_29_6
 BV BND1      service_0_29_7
 BV BND1      service_0_29_8
 BV BND1      service_0_29_9
 BV BND1      service_0_29_10
 BV BND1      service_1_29_0
 BV BND1      service_1_29_2
 BV BND1      service_1_29_3
 BV BND1      service_1_29_4
 BV BND1      service_1_29_5
 BV BND1      service_1_29_6
 BV BND1      service_1_29_7
 BV BND1      service_1_29_8
 BV BND1      service_1_29_9
 BV BND1      service_1_29_10
 BV BND1      service_2_29_0
 BV BND1      service_2_29_2
 BV BND1      service_2_29_3
 BV BND1      service_2_29_4
 BV BND1      service_2_29_5
 BV BND1      service_2_29_6
 BV BND1      service_2_29_7
 BV BND1      service_2_29_8
 BV BND1      service_2_29_9
 BV BND1      service_2_29_10
 BV BND1      service_0_27_1
 BV BND1      service_0_27_2
 BV BND1      service_0_27_3
 BV BND1      service_0_27_4
 BV BND1      service_0_27_5
 BV BND1      service_0_27_6
 BV BND1      service_1_27_1
 BV BND1      service_1_27_2
 BV BND1      service_1_27_3
 BV BND1      service_1_27_4
 BV BND1      service_1_27_5
 BV BND1      service_1_27_6
 BV BND1      service_2_27_1
 BV BND1      service_2_27_2
 BV BND1      service_2_27_3
 BV BND1      service_2_27_4
 BV BND1      service_2_27_5
 BV BND1      service_2_27_6
 BV BND1      service_0_22_0
 BV BND1      service_0_22_1
 BV BND1      service_0_22_3
 BV BND1      service_0_22_4
 BV BND1      service_0_22_5
 BV BND1      service_0_22_6
 BV BND1      service_0_22_7
 BV BND1      service_0_22_8
 BV BND1      service_0_22_9
 BV BND1      service_0_22_10
 BV BND1      service_0_22_11
 BV BND1      service_0_22_12
 BV BND1      service_0_22_13
 BV BND1      service_0_22_14
 BV BND1      service_0_22_15
 BV BND1      service_1_22_0
 BV BND1      service_1_22_1
 BV BND1      service_1_22_3
 BV BND1      service_1_22_4
 BV BND1      service_1_22_5
 BV BND1      service_1_22_6
 BV BND1      service_1_22_7
 BV BND1      service_1_22_8
 BV BND1      service_1_22_9
 BV BND1      service_1_22_10
 BV BND1      service_1_22_11
 BV BND1      service_1_22_12
 BV BND1      service_1_22_13
 BV BND1      service_1_22_14
 BV BND1      service_1_22_15
 BV BND1      service_2_22_0
 BV BND1      service_2_22_1
 BV BND1      service_2_22_3
 BV BND1      service_2_22_4
 BV BND1      service_2_22_5
 BV BND1      service_2_22_6
 BV BND1      service_2_22_7
 BV BND1      service_2_22_8
 BV BND1      service_2_22_9
 BV BND1      service_2_22_10
 BV BND1      service_2_22_11
 BV BND1      service_2_22_12
 BV BND1      service_2_22_13
 BV BND1      service_2_22_14
 BV BND1      service_2_22_15
 BV BND1      service_0_25_1
 BV BND1      service_0_25_2
 BV BND1      service_0_25_3
 BV BND1      service_0_25_4
 BV BND1      service_1_25_1
 BV BND1      service_1_25_2
 BV BND1      service_1_25_3
 BV BND1      service_1_25_4
 BV BND1      service_2_25_1
 BV BND1      service_2_25_2
 BV BND1      service_2_25_3
 BV BND1      service_2_25_4
 BV BND1      service_0_23_0
 BV BND1      service_0_23_2
 BV BND1      service_0_23_3
 BV BND1      service_1_23_0
 BV BND1      service_1_23_2
 BV BND1      service_1_23_3
 BV BND1      service_2_23_0
 BV BND1      service_2_23_2
 BV BND1      service_2_23_3
 FX BND1      visit_0_1  1
 UP BND1      order_0_1  12
 FX BND1      visit_0_2  1
 UP BND1      order_0_2  12
 FX BND1      visit_0_3  1
 UP BND1      order_0_3  12
 FX BND1      visit_0_4  1
 UP BND1      order_0_4  12
 UP BND1      visit_0_12  1
 UP BND1      order_0_12  12
 UP BND1      visit_0_13  1
 UP BND1      order_0_13  12
 UP BND1      visit_0_14  1
 UP BND1      order_0_14  12
 UP BND1      visit_0_15  1
 UP BND1      order_0_15  12
 UP BND1      visit_0_16  1
 UP BND1      order_0_16  12
 UP BND1      visit_0_17  1
 UP BND1      order_0_17  12
 UP BND1      visit_0_18  1
 UP BND1      order_0_18  12
 UP BND1      visit_0_19  1
 UP BND1      order_0_19  12
 BV BND1      arc_0_0_0
 FX BND1      load_0_0_0  0
 BV BND1      arc_0_0_1
 FX BND1      load_0_0_1  0
 BV BND1      arc_0_0_2
 FX BND1      load_0_0_2  0
 BV BND1      arc_0_0_3
 FX BND1      load_0_0_3  0
 BV BND1      arc_0_0_4
 FX BND1      load_0_0_4  0
 BV BND1      arc_0_0_12
 FX BND1      load_0_0_12  0
 BV BND1      arc_0_0_13
 FX BND1      load_0_0_13  0
 BV BND1      arc_0_0_14
 FX BND1      load_0_0_14  0
 BV BND1      arc_0_0_15
 FX BND1      load_0_0_15  0
 BV BND1      arc_0_0_16
 FX BND1      load_0_0_16  0
 BV BND1      arc_0_0_17
 FX BND1      load_0_0_17  0
 BV BND1      arc_0_0_18
 FX BND1      load_0_0_18  0
 BV BND1      arc_0_0_19
 FX BND1      load_0_0_19  0
 BV BND1      arc_0_1_0
 UP BND1      load_0_1_0  20
 BV BND1      arc_0_1_2
 UP BND1      load_0_1_2  20
 BV BND1      arc_0_1_3
 UP BND1      load_0_1_3  20
 BV BND1      arc_0_1_4
 UP BND1      load_0_1_4  20
 BV BND1      arc_0_1_12
 UP BND1      load_0_1_12  20
 BV BND1      arc_0_1_13
 UP BND1      load_0_1_13  20
 BV BND1      arc_0_1_14
 UP BND1      load_0_1_14  20
 BV BND1      arc_0_1_15
 UP BND1      load_0_1_15  20
 BV BND1      arc_0_1_16
 UP BND1      load_0_1_16  20
 BV BND1      arc_0_1_17
 UP BND1      load_0_1_17  20
 BV BND1      arc_0_1_18
 UP BND1      load_0_1_18  20
 BV BND1      arc_0_1_19
 UP BND1      load_0_1_19  20
 BV BND1      arc_0_2_0
 UP BND1      load_0_2_0  20
 BV BND1      arc_0_2_1
 UP BND1      load_0_2_1  20
 BV BND1      arc_0_2_3
 UP BND1      load_0_2_3  20
 BV BND1      arc_0_2_4
 UP BND1      load_0_2_4  20
 BV BND1      arc_0_2_12
 UP BND1      load_0_2_12  20
 BV BND1      arc_0_2_13
 UP BND1      load_0_2_13  20
 BV BND1      arc_0_2_14
 UP BND1      load_0_2_14  20
 BV BND1      arc_0_2_15
 UP BND1      load_0_2_15  20
 BV BND1      arc_0_2_16
 UP BND1      load_0_2_16  20
 BV BND1      arc_0_2_17
 UP BND1      load_0_2_17  20
 BV BND1      arc_0_2_18
 UP BND1      load_0_2_18  20
 BV BND1      arc_0_2_19
 UP BND1      load_0_2_19  20
 BV BND1      arc_0_3_0
 UP BND1      load_0_3_0  20
 BV BND1      arc_0_3_1
 UP BND1      load_0_3_1  20
 BV BND1      arc_0_3_2
 UP BND1      load_0_3_2  20
 BV BND1      arc_0_3_4
 UP BND1      load_0_3_4  20
 BV BND1      arc_0_3_12
 UP BND1      load_0_3_12  20
 BV BND1      arc_0_3_13
 UP BND1      load_0_3_13  20
 BV BND1      arc_0_3_14
 UP BND1      load_0_3_14  20
 BV BND1      arc_0_3_15
 UP BND1      load_0_3_15  20
 BV BND1      arc_0_3_16
 UP BND1      load_0_3_16  20
 BV BND1      arc_0_3_17
 UP BND1      load_0_3_17  20
 BV BND1      arc_0_3_18
 UP BND1      load_0_3_18  20
 BV BND1      arc_0_3_19
 UP BND1      load_0_3_19  20
 BV BND1      arc_0_4_0
 UP BND1      load_0_4_0  20
 BV BND1      arc_0_4_1
 UP BND1      load_0_4_1  20
 BV BND1      arc_0_4_2
 UP BND1      load_0_4_2  20
 BV BND1      arc_0_4_3
 UP BND1      load_0_4_3  20
 BV BND1      arc_0_4_12
 UP BND1      load_0_4_12  20
 BV BND1      arc_0_4_13
 UP BND1      load_0_4_13  20
 BV BND1      arc_0_4_14
 UP BND1      load_0_4_14  20
 BV BND1      arc_0_4_15
 UP BND1      load_0_4_15  20
 BV BND1      arc_0_4_16
 UP BND1      load_0_4_16  20
 BV BND1      arc_0_4_17
 UP BND1      load_0_4_17  20
 BV BND1      arc_0_4_18
 UP BND1      load_0_4_18  20
 BV BND1      arc_0_4_19
 UP BND1      load_0_4_19  20
 BV BND1      arc_0_12_0
 UP BND1      load_0_12_0  20
 BV BND1      arc_0_12_1
 UP BND1      load_0_12_1  20
 BV BND1      arc_0_12_2
 UP BND1      load_0_12_2  20
 BV BND1      arc_0_12_3
 UP BND1      load_0_12_3  20
 BV BND1      arc_0_12_4
 UP BND1      load_0_12_4  20
 BV BND1      arc_0_12_13
 UP BND1      load_0_12_13  20
 BV BND1      arc_0_12_14
 UP BND1      load_0_12_14  20
 BV BND1      arc_0_12_15
 UP BND1      load_0_12_15  20
 BV BND1      arc_0_12_16
 UP BND1      load_0_12_16  20
 BV BND1      arc_0_12_17
 UP BND1      load_0_12_17  20
 BV BND1      arc_0_12_18
 UP BND1      load_0_12_18  20
 BV BND1      arc_0_12_19
 UP BND1      load_0_12_19  20
 BV BND1      arc_0_13_0
 UP BND1      load_0_13_0  20
 BV BND1      arc_0_13_1
 UP BND1      load_0_13_1  20
 BV BND1      arc_0_13_2
 UP BND1      load_0_13_2  20
 BV BND1      arc_0_13_3
 UP BND1      load_0_13_3  20
 BV BND1      arc_0_13_4
 UP BND1      load_0_13_4  20
 BV BND1      arc_0_13_12
 UP BND1      load_0_13_12  20
 BV BND1      arc_0_13_14
 UP BND1      load_0_13_14  20
 BV BND1      arc_0_13_15
 UP BND1      load_0_13_15  20
 BV BND1      arc_0_13_16
 UP BND1      load_0_13_16  20
 BV BND1      arc_0_13_17
 UP BND1      load_0_13_17  20
 BV BND1      arc_0_13_18
 UP BND1      load_0_13_18  20
 BV BND1      arc_0_13_19
 UP BND1      load_0_13_19  20
 BV BND1      arc_0_14_0
 UP BND1      load_0_14_0  20
 BV BND1      arc_0_14_1
 UP BND1      load_0_14_1  20
 BV BND1      arc_0_14_2
 UP BND1      load_0_14_2  20
 BV BND1      arc_0_14_3
 UP BND1      load_0_14_3  20
 BV BND1      arc_0_14_4
 UP BND1      load_0_14_4  20
 BV BND1      arc_0_14_12
 UP BND1      load_0_14_12  20
 BV BND1      arc_0_14_13
 UP BND1      load_0_14_13  20
 BV BND1      arc_0_14_15
 UP BND1      load_0_14_15  20
 BV BND1      arc_0_14_16
 UP BND1      load_0_14_16  20
 BV BND1      arc_0_14_17
 UP BND1      load_0_14_17  20
 BV BND1      arc_0_14_18
 UP BND1      load_0_14_18  20
 BV BND1      arc_0_14_19
 UP BND1      load_0_14_19  20
 BV BND1      arc_0_15_0
 UP BND1      load_0_15_0  20
 BV BND1      arc_0_15_1
 UP BND1      load_0_15_1  20
 BV BND1      arc_0_15_2
 UP BND1      load_0_15_2  20
 BV BND1      arc_0_15_3
 UP BND1      load_0_15_3  20
 BV BND1      arc_0_15_4
 UP BND1      load_0_15_4  20
 BV BND1      arc_0_15_12
 UP BND1      load_0_15_12  20
 BV BND1      arc_0_15_13
 UP BND1      load_0_15_13  20
 BV BND1      arc_0_15_14
 UP BND1      load_0_15_14  20
 BV BND1      arc_0_15_16
 UP BND1      load_0_15_16  20
 BV BND1      arc_0_15_17
 UP BND1      load_0_15_17  20
 BV BND1      arc_0_15_18
 UP BND1      load_0_15_18  20
 BV BND1      arc_0_15_19
 UP BND1      load_0_15_19  20
 BV BND1      arc_0_16_0
 UP BND1      load_0_16_0  20
 BV BND1      arc_0_16_1
 UP BND1      load_0_16_1  20
 BV BND1      arc_0_16_2
 UP BND1      load_0_16_2  20
 BV BND1      arc_0_16_3
 UP BND1      load_0_16_3  20
 BV BND1      arc_0_16_4
 UP BND1      load_0_16_4  20
 BV BND1      arc_0_16_12
 UP BND1      load_0_16_12  20
 BV BND1      arc_0_16_13
 UP BND1      load_0_16_13  20
 BV BND1      arc_0_16_14
 UP BND1      load_0_16_14  20
 BV BND1      arc_0_16_15
 UP BND1      load_0_16_15  20
 BV BND1      arc_0_16_17
 UP BND1      load_0_16_17  20
 BV BND1      arc_0_16_18
 UP BND1      load_0_16_18  20
 BV BND1      arc_0_16_19
 UP BND1      load_0_16_19  20
 BV BND1      arc_0_17_0
 UP BND1      load_0_17_0  20
 BV BND1      arc_0_17_1
 UP BND1      load_0_17_1  20
 BV BND1      arc_0_17_2
 UP BND1      load_0_17_2  20
 BV BND1      arc_0_17_3
 UP BND1      load_0_17_3  20
 BV BND1      arc_0_17_4
 UP BND1      load_0_17_4  20
 BV BND1      arc_0_17_12
 UP BND1      load_0_17_12  20
 BV BND1      arc_0_17_13
 UP BND1      load_0_17_13  20
 BV BND1      arc_0_17_14
 UP BND1      load_0_17_14  20
 BV BND1      arc_0_17_15
 UP BND1      load_0_17_15  20
 BV BND1      arc_0_17_16
 UP BND1      load_0_17_16  20
 BV BND1      arc_0_17_18
 UP BND1      load_0_17_18  20
 BV BND1      arc_0_17_19
 UP BND1      load_0_17_19  20
 BV BND1      arc_0_18_0
 UP BND1      load_0_18_0  20
 BV BND1      arc_0_18_1
 UP BND1      load_0_18_1  20
 BV BND1      arc_0_18_2
 UP BND1      load_0_18_2  20
 BV BND1      arc_0_18_3
 UP BND1      load_0_18_3  20
 BV BND1      arc_0_18_4
 UP BND1      load_0_18_4  20
 BV BND1      arc_0_18_12
 UP BND1      load_0_18_12  20
 BV BND1      arc_0_18_13
 UP BND1      load_0_18_13  20
 BV BND1      arc_0_18_14
 UP BND1      load_0_18_14  20
 BV BND1      arc_0_18_15
 UP BND1      load_0_18_15  20
 BV BND1      arc_0_18_16
 UP BND1      load_0_18_16  20
 BV BND1      arc_0_18_17
 UP BND1      load_0_18_17  20
 BV BND1      arc_0_18_19
 UP BND1      load_0_18_19  20
 BV BND1      arc_0_19_0
 UP BND1      load_0_19_0  20
 BV BND1      arc_0_19_1
 UP BND1      load_0_19_1  20
 BV BND1      arc_0_19_2
 UP BND1      load_0_19_2  20
 BV BND1      arc_0_19_3
 UP BND1      load_0_19_3  20
 BV BND1      arc_0_19_4
 UP BND1      load_0_19_4  20
 BV BND1      arc_0_19_12
 UP BND1      load_0_19_12  20
 BV BND1      arc_0_19_13
 UP BND1      load_0_19_13  20
 BV BND1      arc_0_19_14
 UP BND1      load_0_19_14  20
 BV BND1      arc_0_19_15
 UP BND1      load_0_19_15  20
 BV BND1      arc_0_19_16
 UP BND1      load_0_19_16  20
 BV BND1      arc_0_19_17
 UP BND1      load_0_19_17  20
 BV BND1      arc_0_19_18
 UP BND1      load_0_19_18  20
 FX BND1      visit_1_5  1
 UP BND1      order_1_5  12
 FX BND1      visit_1_6  1
 UP BND1      order_1_6  12
 FX BND1      visit_1_7  1
 UP BND1      order_1_7  12
 FX BND1      visit_1_8  1
 UP BND1      order_1_8  12
 UP BND1      visit_1_12  1
 UP BND1      order_1_12  12
 UP BND1      visit_1_13  1
 UP BND1      order_1_13  12
 UP BND1      visit_1_14  1
 UP BND1      order_1_14  12
 UP BND1      visit_1_15  1
 UP BND1      order_1_15  12
 UP BND1      visit_1_16  1
 UP BND1      order_1_16  12
 UP BND1      visit_1_17  1
 UP BND1      order_1_17  12
 UP BND1      visit_1_18  1
 UP BND1      order_1_18  12
 UP BND1      visit_1_19  1
 UP BND1      order_1_19  12
 BV BND1      arc_1_0_0
 FX BND1      load_1_0_0  0
 BV BND1      arc_1_0_5
 FX BND1      load_1_0_5  0
 BV BND1      arc_1_0_6
 FX BND1      load_1_0_6  0
 BV BND1      arc_1_0_7
 FX BND1      load_1_0_7  0
 BV BND1      arc_1_0_8
 FX BND1      load_1_0_8  0
 BV BND1      arc_1_0_12
 FX BND1      load_1_0_12  0
 BV BND1      arc_1_0_13
 FX BND1      load_1_0_13  0
 BV BND1      arc_1_0_14
 FX BND1      load_1_0_14  0
 BV BND1      arc_1_0_15
 FX BND1      load_1_0_15  0
 BV BND1      arc_1_0_16
 FX BND1      load_1_0_16  0
 BV BND1      arc_1_0_17
 FX BND1      load_1_0_17  0
 BV BND1      arc_1_0_18
 FX BND1      load_1_0_18  0
 BV BND1      arc_1_0_19
 FX BND1      load_1_0_19  0
 BV BND1      arc_1_5_0
 UP BND1      load_1_5_0  25
 BV BND1      arc_1_5_6
 UP BND1      load_1_5_6  25
 BV BND1      arc_1_5_7
 UP BND1      load_1_5_7  25
 BV BND1      arc_1_5_8
 UP BND1      load_1_5_8  25
 BV BND1      arc_1_5_12
 UP BND1      load_1_5_12  25
 BV BND1      arc_1_5_13
 UP BND1      load_1_5_13  25
 BV BND1      arc_1_5_14
 UP BND1      load_1_5_14  25
 BV BND1      arc_1_5_15
 UP BND1      load_1_5_15  25
 BV BND1      arc_1_5_16
 UP BND1      load_1_5_16  25
 BV BND1      arc_1_5_17
 UP BND1      load_1_5_17  25
 BV BND1      arc_1_5_18
 UP BND1      load_1_5_18  25
 BV BND1      arc_1_5_19
 UP BND1      load_1_5_19  25
 BV BND1      arc_1_6_0
 UP BND1      load_1_6_0  25
 BV BND1      arc_1_6_5
 UP BND1      load_1_6_5  25
 BV BND1      arc_1_6_7
 UP BND1      load_1_6_7  25
 BV BND1      arc_1_6_8
 UP BND1      load_1_6_8  25
 BV BND1      arc_1_6_12
 UP BND1      load_1_6_12  25
 BV BND1      arc_1_6_13
 UP BND1      load_1_6_13  25
 BV BND1      arc_1_6_14
 UP BND1      load_1_6_14  25
 BV BND1      arc_1_6_15
 UP BND1      load_1_6_15  25
 BV BND1      arc_1_6_16
 UP BND1      load_1_6_16  25
 BV BND1      arc_1_6_17
 UP BND1      load_1_6_17  25
 BV BND1      arc_1_6_18
 UP BND1      load_1_6_18  25
 BV BND1      arc_1_6_19
 UP BND1      load_1_6_19  25
 BV BND1      arc_1_7_0
 UP BND1      load_1_7_0  25
 BV BND1      arc_1_7_5
 UP BND1      load_1_7_5  25
 BV BND1      arc_1_7_6
 UP BND1      load_1_7_6  25
 BV BND1      arc_1_7_8
 UP BND1      load_1_7_8  25
 BV BND1      arc_1_7_12
 UP BND1      load_1_7_12  25
 BV BND1      arc_1_7_13
 UP BND1      load_1_7_13  25
 BV BND1      arc_1_7_14
 UP BND1      load_1_7_14  25
 BV BND1      arc_1_7_15
 UP BND1      load_1_7_15  25
 BV BND1      arc_1_7_16
 UP BND1      load_1_7_16  25
 BV BND1      arc_1_7_17
 UP BND1      load_1_7_17  25
 BV BND1      arc_1_7_18
 UP BND1      load_1_7_18  25
 BV BND1      arc_1_7_19
 UP BND1      load_1_7_19  25
 BV BND1      arc_1_8_0
 UP BND1      load_1_8_0  25
 BV BND1      arc_1_8_5
 UP BND1      load_1_8_5  25
 BV BND1      arc_1_8_6
 UP BND1      load_1_8_6  25
 BV BND1      arc_1_8_7
 UP BND1      load_1_8_7  25
 BV BND1      arc_1_8_12
 UP BND1      load_1_8_12  25
 BV BND1      arc_1_8_13
 UP BND1      load_1_8_13  25
 BV BND1      arc_1_8_14
 UP BND1      load_1_8_14  25
 BV BND1      arc_1_8_15
 UP BND1      load_1_8_15  25
 BV BND1      arc_1_8_16
 UP BND1      load_1_8_16  25
 BV BND1      arc_1_8_17
 UP BND1      load_1_8_17  25
 BV BND1      arc_1_8_18
 UP BND1      load_1_8_18  25
 BV BND1      arc_1_8_19
 UP BND1      load_1_8_19  25
 BV BND1      arc_1_12_0
 UP BND1      load_1_12_0  25
 BV BND1      arc_1_12_5
 UP BND1      load_1_12_5  25
 BV BND1      arc_1_12_6
 UP BND1      load_1_12_6  25
 BV BND1      arc_1_12_7
 UP BND1      load_1_12_7  25
 BV BND1      arc_1_12_8
 UP BND1      load_1_12_8  25
 BV BND1      arc_1_12_13
 UP BND1      load_1_12_13  25
 BV BND1      arc_1_12_14
 UP BND1      load_1_12_14  25
 BV BND1      arc_1_12_15
 UP BND1      load_1_12_15  25
 BV BND1      arc_1_12_16
 UP BND1      load_1_12_16  25
 BV BND1      arc_1_12_17
 UP BND1      load_1_12_17  25
 BV BND1      arc_1_12_18
 UP BND1      load_1_12_18  25
 BV BND1      arc_1_12_19
 UP BND1      load_1_12_19  25
 BV BND1      arc_1_13_0
 UP BND1      load_1_13_0  25
 BV BND1      arc_1_13_5
 UP BND1      load_1_13_5  25
 BV BND1      arc_1_13_6
 UP BND1      load_1_13_6  25
 BV BND1      arc_1_13_7
 UP BND1      load_1_13_7  25
 BV BND1      arc_1_13_8
 UP BND1      load_1_13_8  25
 BV BND1      arc_1_13_12
 UP BND1      load_1_13_12  25
 BV BND1      arc_1_13_14
 UP BND1      load_1_13_14  25
 BV BND1      arc_1_13_15
 UP BND1      load_1_13_15  25
 BV BND1      arc_1_13_16
 UP BND1      load_1_13_16  25
 BV BND1      arc_1_13_17
 UP BND1      load_1_13_17  25
 BV BND1      arc_1_13_18
 UP BND1      load_1_13_18  25
 BV BND1      arc_1_13_19
 UP BND1      load_1_13_19  25
 BV BND1      arc_1_14_0
 UP BND1      load_1_14_0  25
 BV BND1      arc_1_14_5
 UP BND1      load_1_14_5  25
 BV BND1      arc_1_14_6
 UP BND1      load_1_14_6  25
 BV BND1      arc_1_14_7
 UP BND1      load_1_14_7  25
 BV BND1      arc_1_14_8
 UP BND1      load_1_14_8  25
 BV BND1      arc_1_14_12
 UP BND1      load_1_14_12  25
 BV BND1      arc_1_14_13
 UP BND1      load_1_14_13  25
 BV BND1      arc_1_14_15
 UP BND1      load_1_14_15  25
 BV BND1      arc_1_14_16
 UP BND1      load_1_14_16  25
 BV BND1      arc_1_14_17
 UP BND1      load_1_14_17  25
 BV BND1      arc_1_14_18
 UP BND1      load_1_14_18  25
 BV BND1      arc_1_14_19
 UP BND1      load_1_14_19  25
 BV BND1      arc_1_15_0
 UP BND1      load_1_15_0  25
 BV BND1      arc_1_15_5
 UP BND1      load_1_15_5  25
 BV BND1      arc_1_15_6
 UP BND1      load_1_15_6  25
 BV BND1      arc_1_15_7
 UP BND1      load_1_15_7  25
 BV BND1      arc_1_15_8
 UP BND1      load_1_15_8  25
 BV BND1      arc_1_15_12
 UP BND1      load_1_15_12  25
 BV BND1      arc_1_15_13
 UP BND1      load_1_15_13  25
 BV BND1      arc_1_15_14
 UP BND1      load_1_15_14  25
 BV BND1      arc_1_15_16
 UP BND1      load_1_15_16  25
 BV BND1      arc_1_15_17
 UP BND1      load_1_15_17  25
 BV BND1      arc_1_15_18
 UP BND1      load_1_15_18  25
 BV BND1      arc_1_15_19
 UP BND1      load_1_15_19  25
 BV BND1      arc_1_16_0
 UP BND1      load_1_16_0  25
 BV BND1      arc_1_16_5
 UP BND1      load_1_16_5  25
 BV BND1      arc_1_16_6
 UP BND1      load_1_16_6  25
 BV BND1      arc_1_16_7
 UP BND1      load_1_16_7  25
 BV BND1      arc_1_16_8
 UP BND1      load_1_16_8  25
 BV BND1      arc_1_16_12
 UP BND1      load_1_16_12  25
 BV BND1      arc_1_16_13
 UP BND1      load_1_16_13  25
 BV BND1      arc_1_16_14
 UP BND1      load_1_16_14  25
 BV BND1      arc_1_16_15
 UP BND1      load_1_16_15  25
 BV BND1      arc_1_16_17
 UP BND1      load_1_16_17  25
 BV BND1      arc_1_16_18
 UP BND1      load_1_16_18  25
 BV BND1      arc_1_16_19
 UP BND1      load_1_16_19  25
 BV BND1      arc_1_17_0
 UP BND1      load_1_17_0  25
 BV BND1      arc_1_17_5
 UP BND1      load_1_17_5  25
 BV BND1      arc_1_17_6
 UP BND1      load_1_17_6  25
 BV BND1      arc_1_17_7
 UP BND1      load_1_17_7  25
 BV BND1      arc_1_17_8
 UP BND1      load_1_17_8  25
 BV BND1      arc_1_17_12
 UP BND1      load_1_17_12  25
 BV BND1      arc_1_17_13
 UP BND1      load_1_17_13  25
 BV BND1      arc_1_17_14
 UP BND1      load_1_17_14  25
 BV BND1      arc_1_17_15
 UP BND1      load_1_17_15  25
 BV BND1      arc_1_17_16
 UP BND1      load_1_17_16  25
 BV BND1      arc_1_17_18
 UP BND1      load_1_17_18  25
 BV BND1      arc_1_17_19
 UP BND1      load_1_17_19  25
 BV BND1      arc_1_18_0
 UP BND1      load_1_18_0  25
 BV BND1      arc_1_18_5
 UP BND1      load_1_18_5  25
 BV BND1      arc_1_18_6
 UP BND1      load_1_18_6  25
 BV BND1      arc_1_18_7
 UP BND1      load_1_18_7  25
 BV BND1      arc_1_18_8
 UP BND1      load_1_18_8  25
 BV BND1      arc_1_18_12
 UP BND1      load_1_18_12  25
 BV BND1      arc_1_18_13
 UP BND1      load_1_18_13  25
 BV BND1      arc_1_18_14
 UP BND1      load_1_18_14  25
 BV BND1      arc_1_18_15
 UP BND1      load_1_18_15  25
 BV BND1      arc_1_18_16
 UP BND1      load_1_18_16  25
 BV BND1      arc_1_18_17
 UP BND1      load_1_18_17  25
 BV BND1      arc_1_18_19
 UP BND1      load_1_18_19  25
 BV BND1      arc_1_19_0
 UP BND1      load_1_19_0  25
 BV BND1      arc_1_19_5
 UP BND1      load_1_19_5  25
 BV BND1      arc_1_19_6
 UP BND1      load_1_19_6  25
 BV BND1      arc_1_19_7
 UP BND1      load_1_19_7  25
 BV BND1      arc_1_19_8
 UP BND1      load_1_19_8  25
 BV BND1      arc_1_19_12
 UP BND1      load_1_19_12  25
 BV BND1      arc_1_19_13
 UP BND1      load_1_19_13  25
 BV BND1      arc_1_19_14
 UP BND1      load_1_19_14  25
 BV BND1      arc_1_19_15
 UP BND1      load_1_19_15  25
 BV BND1      arc_1_19_16
 UP BND1      load_1_19_16  25
 BV BND1      arc_1_19_17
 UP BND1      load_1_19_17  25
 BV BND1      arc_1_19_18
 UP BND1      load_1_19_18  25
 FX BND1      visit_2_9  1
 UP BND1      order_2_9  11
 FX BND1      visit_2_10  1
 UP BND1      order_2_10  11
 FX BND1      visit_2_11  1
 UP BND1      order_2_11  11
 UP BND1      visit_2_12  1
 UP BND1      order_2_12  11
 UP BND1      visit_2_13  1
 UP BND1      order_2_13  11
 UP BND1      visit_2_14  1
 UP BND1      order_2_14  11
 UP BND1      visit_2_15  1
 UP BND1      order_2_15  11
 UP BND1      visit_2_16  1
 UP BND1      order_2_16  11
 UP BND1      visit_2_17  1
 UP BND1      order_2_17  11
 UP BND1      visit_2_18  1
 UP BND1      order_2_18  11
 UP BND1      visit_2_19  1
 UP BND1      order_2_19  11
 BV BND1      arc_2_0_0
 FX BND1      load_2_0_0  0
 BV BND1      arc_2_0_9
 FX BND1      load_2_0_9  0
 BV BND1      arc_2_0_10
 FX BND1      load_2_0_10  0
 BV BND1      arc_2_0_11
 FX BND1      load_2_0_11  0
 BV BND1      arc_2_0_12
 FX BND1      load_2_0_12  0
 BV BND1      arc_2_0_13
 FX BND1      load_2_0_13  0
 BV BND1      arc_2_0_14
 FX BND1      load_2_0_14  0
 BV BND1      arc_2_0_15
 FX BND1      load_2_0_15  0
 BV BND1      arc_2_0_16
 FX BND1      load_2_0_16  0
 BV BND1      arc_2_0_17
 FX BND1      load_2_0_17  0
 BV BND1      arc_2_0_18
 FX BND1      load_2_0_18  0
 BV BND1      arc_2_0_19
 FX BND1      load_2_0_19  0
 BV BND1      arc_2_9_0
 UP BND1      load_2_9_0  30
 BV BND1      arc_2_9_10
 UP BND1      load_2_9_10  30
 BV BND1      arc_2_9_11
 UP BND1      load_2_9_11  30
 BV BND1      arc_2_9_12
 UP BND1      load_2_9_12  30
 BV BND1      arc_2_9_13
 UP BND1      load_2_9_13  30
 BV BND1      arc_2_9_14
 UP BND1      load_2_9_14  30
 BV BND1      arc_2_9_15
 UP BND1      load_2_9_15  30
 BV BND1      arc_2_9_16
 UP BND1      load_2_9_16  30
 BV BND1      arc_2_9_17
 UP BND1      load_2_9_17  30
 BV BND1      arc_2_9_18
 UP BND1      load_2_9_18  30
 BV BND1      arc_2_9_19
 UP BND1      load_2_9_19  30
 BV BND1      arc_2_10_0
 UP BND1      load_2_10_0  30
 BV BND1      arc_2_10_9
 UP BND1      load_2_10_9  30
 BV BND1      arc_2_10_11
 UP BND1      load_2_10_11  30
 BV BND1      arc_2_10_12
 UP BND1      load_2_10_12  30
 BV BND1      arc_2_10_13
 UP BND1      load_2_10_13  30
 BV BND1      arc_2_10_14
 UP BND1      load_2_10_14  30
 BV BND1      arc_2_10_15
 UP BND1      load_2_10_15  30
 BV BND1      arc_2_10_16
 UP BND1      load_2_10_16  30
 BV BND1      arc_2_10_17
 UP BND1      load_2_10_17  30
 BV BND1      arc_2_10_18
 UP BND1      load_2_10_18  30
 BV BND1      arc_2_10_19
 UP BND1      load_2_10_19  30
 BV BND1      arc_2_11_0
 UP BND1      load_2_11_0  30
 BV BND1      arc_2_11_9
 UP BND1      load_2_11_9  30
 BV BND1      arc_2_11_10
 UP BND1      load_2_11_10  30
 BV BND1      arc_2_11_12
 UP BND1      load_2_11_12  30
 BV BND1      arc_2_11_13
 UP BND1      load_2_11_13  30
 BV BND1      arc_2_11_14
 UP BND1      load_2_11_14  30
 BV BND1      arc_2_11_15
 UP BND1      load_2_11_15  30
 BV BND1      arc_2_11_16
 UP BND1      load_2_11_16  30
 BV BND1      arc_2_11_17
 UP BND1      load_2_11_17  30
 BV BND1      arc_2_11_18
 UP BND1      load_2_11_18  30
 BV BND1      arc_2_11_19
 UP BND1      load_2_11_19  30
 BV BND1      arc_2_12_0
 UP BND1      load_2_12_0  30
 BV BND1      arc_2_12_9
 UP BND1      load_2_12_9  30
 BV BND1      arc_2_12_10
 UP BND1      load_2_12_10  30
 BV BND1      arc_2_12_11
 UP BND1      load_2_12_11  30
 BV BND1      arc_2_12_13
 UP BND1      load_2_12_13  30
 BV BND1      arc_2_12_14
 UP BND1      load_2_12_14  30
 BV BND1      arc_2_12_15
 UP BND1      load_2_12_15  30
 BV BND1      arc_2_12_16
 UP BND1      load_2_12_16  30
 BV BND1      arc_2_12_17
 UP BND1      load_2_12_17  30
 BV BND1      arc_2_12_18
 UP BND1      load_2_12_18  30
 BV BND1      arc_2_12_19
 UP BND1      load_2_12_19  30
 BV BND1      arc_2_13_0
 UP BND1      load_2_13_0  30
 BV BND1      arc_2_13_9
 UP BND1      load_2_13_9  30
 BV BND1      arc_2_13_10
 UP BND1      load_2_13_10  30
 BV BND1      arc_2_13_11
 UP BND1      load_2_13_11  30
 BV BND1      arc_2_13_12
 UP BND1      load_2_13_12  30
 BV BND1      arc_2_13_14
 UP BND1      load_2_13_14  30
 BV BND1      arc_2_13_15
 UP BND1      load_2_13_15  30
 BV BND1      arc_2_13_16
 UP BND1      load_2_13_16  30
 BV BND1      arc_2_13_17
 UP BND1      load_2_13_17  30
 BV BND1      arc_2_13_18
 UP BND1      load_2_13_18  30
 BV BND1      arc_2_13_19
 UP BND1      load_2_13_19  30
 BV BND1      arc_2_14_0
 UP BND1      load_2_14_0  30
 BV BND1      arc_2_14_9
 UP BND1      load_2_14_9  30
 BV BND1      arc_2_14_10
 UP BND1      load_2_14_10  30
 BV BND1      arc_2_14_11
 UP BND1      load_2_14_11  30
 BV BND1      arc_2_14_12
 UP BND1      load_2_14_12  30
 BV BND1      arc_2_14_13
 UP BND1      load_2_14_13  30
 BV BND1      arc_2_14_15
 UP BND1      load_2_14_15  30
 BV BND1      arc_2_14_16
 UP BND1      load_2_14_16  30
 BV BND1      arc_2_14_17
 UP BND1      load_2_14_17  30
 BV BND1      arc_2_14_18
 UP BND1      load_2_14_18  30
 BV BND1      arc_2_14_19
 UP BND1      load_2_14_19  30
 BV BND1      arc_2_15_0
 UP BND1      load_2_15_0  30
 BV BND1      arc_2_15_9
 UP BND1      load_2_15_9  30
 BV BND1      arc_2_15_10
 UP BND1      load_2_15_10  30
 BV BND1      arc_2_15_11
 UP BND1      load_2_15_11  30
 BV BND1      arc_2_15_12
 UP BND1      load_2_15_12  30
 BV BND1      arc_2_15_13
 UP BND1      load_2_15_13  30
 BV BND1      arc_2_15_14
 UP BND1      load_2_15_14  30
 BV BND1      arc_2_15_16
 UP BND1      load_2_15_16  30
 BV BND1      arc_2_15_17
 UP BND1      load_2_15_17  30
 BV BND1      arc_2_15_18
 UP BND1      load_2_15_18  30
 BV BND1      arc_2_15_19
 UP BND1      load_2_15_19  30
 BV BND1      arc_2_16_0
 UP BND1      load_2_16_0  30
 BV BND1      arc_2_16_9
 UP BND1      load_2_16_9  30
 BV BND1      arc_2_16_10
 UP BND1      load_2_16_10  30
 BV BND1      arc_2_16_11
 UP BND1      load_2_16_11  30
 BV BND1      arc_2_16_12
 UP BND1      load_2_16_12  30
 BV BND1      arc_2_16_13
 UP BND1      load_2_16_13  30
 BV BND1      arc_2_16_14
 UP BND1      load_2_16_14  30
 BV BND1      arc_2_16_15
 UP BND1      load_2_16_15  30
 BV BND1      arc_2_16_17
 UP BND1      load_2_16_17  30
 BV BND1      arc_2_16_18
 UP BND1      load_2_16_18  30
 BV BND1      arc_2_16_19
 UP BND1      load_2_16_19  30
 BV BND1      arc_2_17_0
 UP BND1      load_2_17_0  30
 BV BND1      arc_2_17_9
 UP BND1      load_2_17_9  30
 BV BND1      arc_2_17_10
 UP BND1      load_2_17_10  30
 BV BND1      arc_2_17_11
 UP BND1      load_2_17_11  30
 BV BND1      arc_2_17_12
 UP BND1      load_2_17_12  30
 BV BND1      arc_2_17_13
 UP BND1      load_2_17_13  30
 BV BND1      arc_2_17_14
 UP BND1      load_2_17_14  30
 BV BND1      arc_2_17_15
 UP BND1      load_2_17_15  30
 BV BND1      arc_2_17_16
 UP BND1      load_2_17_16  30
 BV BND1      arc_2_17_18
 UP BND1      load_2_17_18  30
 BV BND1      arc_2_17_19
 UP BND1      load_2_17_19  30
 BV BND1      arc_2_18_0
 UP BND1      load_2_18_0  30
 BV BND1      arc_2_18_9
 UP BND1      load_2_18_9  30
 BV BND1      arc_2_18_10
 UP BND1      load_2_18_10  30
 BV BND1      arc_2_18_11
 UP BND1      load_2_18_11  30
 BV BND1      arc_2_18_12
 UP BND1      load_2_18_12  30
 BV BND1      arc_2_18_13
 UP BND1      load_2_18_13  30
 BV BND1      arc_2_18_14
 UP BND1      load_2_18_14  30
 BV BND1      arc_2_18_15
 UP BND1      load_2_18_15  30
 BV BND1      arc_2_18_16
 UP BND1      load_2_18_16  30
 BV BND1      arc_2_18_17
 UP BND1      load_2_18_17  30
 BV BND1      arc_2_18_19
 UP BND1      load_2_18_19  30
 BV BND1      arc_2_19_0
 UP BND1      load_2_19_0  30
 BV BND1      arc_2_19_9
 UP BND1      load_2_19_9  30
 BV BND1      arc_2_19_10
 UP BND1      load_2_19_10  30
 BV BND1      arc_2_19_11
 UP BND1      load_2_19_11  30
 BV BND1      arc_2_19_12
 UP BND1      load_2_19_12  30
 BV BND1      arc_2_19_13
 UP BND1      load_2_19_13  30
 BV BND1      arc_2_19_14
 UP BND1      load_2_19_14  30
 BV BND1      arc_2_19_15
 UP BND1      load_2_19_15  30
 BV BND1      arc_2_19_16
 UP BND1      load_2_19_16  30
 BV BND1      arc_2_19_17
 UP BND1      load_2_19_17  30
 BV BND1      arc_2_19_18
 UP BND1      load_2_19_18  30
ENDATA
