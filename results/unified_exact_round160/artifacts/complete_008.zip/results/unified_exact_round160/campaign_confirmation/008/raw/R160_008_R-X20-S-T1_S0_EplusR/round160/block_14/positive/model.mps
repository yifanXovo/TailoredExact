* Signature: 0x5b7ebe79741206aa
NAME R160_physical_neighborhood
ROWS
 N  OBJ
 G  product_lb_0
 L  product_ub_1
 G  product_lb_2
 L  product_ub_3
 E  onehot_6_4
 E  normalized_mass_6_5
 E  normalized_ratio_6_6
 G  product_lb_7
 L  product_ub_8
 G  product_lb_9
 L  product_ub_10
 G  product_lb_11
 L  product_ub_12
 G  product_lb_13
 L  product_ub_14
 G  product_lb_15
 L  product_ub_16
 G  product_lb_17
 L  product_ub_18
 G  product_lb_19
 L  product_ub_20
 G  product_lb_21
 L  product_ub_22
 G  product_lb_23
 L  product_ub_24
 G  product_lb_25
 L  product_ub_26
 G  product_lb_27
 L  product_ub_28
 G  product_lb_29
 L  product_ub_30
 G  product_lb_31
 L  product_ub_32
 G  product_lb_33
 L  product_ub_34
 G  product_lb_35
 L  product_ub_36
 G  product_lb_37
 L  product_ub_38
 G  product_lb_39
 L  product_ub_40
 E  onehot_3_41
 E  normalized_mass_3_42
 E  normalized_ratio_3_43
 G  product_lb_44
 L  product_ub_45
 G  product_lb_46
 L  product_ub_47
 G  product_lb_48
 L  product_ub_49
 G  product_lb_50
 L  product_ub_51
 G  product_lb_52
 L  product_ub_53
 G  product_lb_54
 L  product_ub_55
 G  product_lb_56
 L  product_ub_57
 G  product_lb_58
 L  product_ub_59
 G  product_lb_60
 L  product_ub_61
 G  product_lb_62
 L  product_ub_63
 G  product_lb_64
 L  product_ub_65
 G  product_lb_66
 L  product_ub_67
 G  product_lb_68
 L  product_ub_69
 G  product_lb_70
 L  product_ub_71
 G  product_lb_72
 L  product_ub_73
 G  product_lb_74
 L  product_ub_75
 E  onehot_18_76
 E  normalized_mass_18_77
 E  normalized_ratio_18_78
 G  product_lb_79
 L  product_ub_80
 G  product_lb_81
 L  product_ub_82
 G  product_lb_83
 L  product_ub_84
 G  product_lb_85
 L  product_ub_86
 G  product_lb_87
 L  product_ub_88
 G  product_lb_89
 L  product_ub_90
 G  product_lb_91
 L  product_ub_92
 G  product_lb_93
 L  product_ub_94
 G  product_lb_95
 L  product_ub_96
 G  product_lb_97
 L  product_ub_98
 G  product_lb_99
 L  product_ub_100
 E  onehot_7_101
 E  normalized_mass_7_102
 E  normalized_ratio_7_103
 G  product_lb_104
 L  product_ub_105
 G  product_lb_106
 L  product_ub_107
 G  product_lb_108
 L  product_ub_109
 G  product_lb_110
 L  product_ub_111
 G  product_lb_112
 L  product_ub_113
 G  product_lb_114
 L  product_ub_115
 G  product_lb_116
 L  product_ub_117
 G  product_lb_118
 L  product_ub_119
 G  product_lb_120
 L  product_ub_121
 G  product_lb_122
 L  product_ub_123
 G  product_lb_124
 L  product_ub_125
 G  product_lb_126
 L  product_ub_127
 G  product_lb_128
 L  product_ub_129
 G  product_lb_130
 L  product_ub_131
 G  product_lb_132
 L  product_ub_133
 G  product_lb_134
 L  product_ub_135
 G  product_lb_136
 L  product_ub_137
 E  onehot_17_138
 E  normalized_mass_17_139
 E  normalized_ratio_17_140
 G  product_lb_141
 L  product_ub_142
 G  product_lb_143
 L  product_ub_144
 G  product_lb_145
 L  product_ub_146
 E  onehot_5_147
 E  normalized_mass_5_148
 E  normalized_ratio_5_149
 G  product_lb_150
 L  product_ub_151
 G  product_lb_152
 L  product_ub_153
 G  product_lb_154
 L  product_ub_155
 G  product_lb_156
 L  product_ub_157
 G  product_lb_158
 L  product_ub_159
 G  product_lb_160
 L  product_ub_161
 G  product_lb_162
 L  product_ub_163
 G  product_lb_164
 L  product_ub_165
 G  product_lb_166
 L  product_ub_167
 G  product_lb_168
 L  product_ub_169
 G  product_lb_170
 L  product_ub_171
 G  product_lb_172
 L  product_ub_173
 G  product_lb_174
 L  product_ub_175
 G  product_lb_176
 L  product_ub_177
 G  product_lb_178
 L  product_ub_179
 G  product_lb_180
 L  product_ub_181
 E  onehot_11_182
 E  normalized_mass_11_183
 E  normalized_ratio_11_184
 G  product_lb_185
 L  product_ub_186
 G  product_lb_187
 L  product_ub_188
 E  onehot_2_189
 E  normalized_mass_2_190
 E  normalized_ratio_2_191
 G  stock_lb_192
 L  stock_ub_193
 L  parent_nonstrict_scope_194
 G  block_pair_pos_195
 G  block_pair_neg_196
 G  block_pair_pos_197
 G  block_pair_neg_198
 G  block_pair_pos_199
 G  block_pair_neg_200
 G  block_pair_pos_201
 G  block_pair_neg_202
 G  block_pair_pos_203
 G  block_pair_neg_204
 G  block_pair_pos_205
 G  block_pair_neg_206
 G  block_pair_pos_207
 G  block_pair_neg_208
 G  block_pair_pos_209
 G  block_pair_neg_210
 G  block_pair_pos_211
 G  block_pair_neg_212
 G  block_pair_pos_213
 G  block_pair_neg_214
 G  block_pair_pos_215
 G  block_pair_neg_216
 G  block_pair_pos_217
 G  block_pair_neg_218
 G  block_pair_pos_219
 G  block_pair_neg_220
 G  block_pair_pos_221
 G  block_pair_neg_222
 G  block_pair_pos_223
 G  block_pair_neg_224
 G  block_pair_pos_225
 G  block_pair_neg_226
 G  block_pair_pos_227
 G  block_pair_neg_228
 G  block_pair_pos_229
 G  block_pair_neg_230
 G  block_pair_pos_231
 G  block_pair_neg_232
 G  block_pair_pos_233
 G  block_pair_neg_234
 G  block_pair_pos_235
 G  block_pair_neg_236
 G  block_pair_pos_237
 G  block_pair_neg_238
 G  block_pair_pos_239
 G  block_pair_neg_240
 G  block_pair_pos_241
 G  block_pair_neg_242
 G  block_pair_pos_243
 G  block_pair_neg_244
 G  block_pair_pos_245
 G  block_pair_neg_246
 G  block_pair_pos_247
 G  block_pair_neg_248
 G  block_pair_pos_249
 G  block_pair_neg_250
 E  normalization_251
 G  full_original_Gini_252
 E  unique_nonzero_owner_253
 E  unique_nonzero_owner_254
 E  unique_nonzero_owner_255
 E  unique_nonzero_owner_256
 E  unique_nonzero_owner_257
 E  unique_nonzero_owner_258
 E  unique_nonzero_owner_259
 E  unique_nonzero_owner_260
 E  unique_nonzero_owner_261
 E  unique_nonzero_owner_262
 E  unique_nonzero_owner_263
 E  unique_nonzero_owner_264
 E  unique_nonzero_owner_265
 E  unique_nonzero_owner_266
 E  unique_nonzero_owner_267
 E  unique_nonzero_owner_268
 E  unique_nonzero_owner_269
 E  unique_nonzero_owner_270
 E  unique_nonzero_owner_271
 E  unique_nonzero_owner_272
 E  unique_nonzero_owner_273
 E  unique_nonzero_owner_274
 E  unique_nonzero_owner_275
 E  unique_nonzero_owner_276
 E  unique_nonzero_owner_277
 E  unique_nonzero_owner_278
 E  unique_nonzero_owner_279
 E  unique_nonzero_owner_280
 E  unique_nonzero_owner_281
 E  unique_nonzero_owner_282
 E  unique_nonzero_owner_283
 E  unique_nonzero_owner_284
 E  unique_nonzero_owner_285
 E  unique_nonzero_owner_286
 E  unique_nonzero_owner_287
 E  unique_nonzero_owner_288
 E  unique_nonzero_owner_289
 E  unique_nonzero_owner_290
 E  unique_nonzero_owner_291
 E  unique_nonzero_owner_292
 E  unique_nonzero_owner_293
 E  unique_nonzero_owner_294
 E  unique_nonzero_owner_295
 E  unique_nonzero_owner_296
 E  unique_nonzero_owner_297
 E  unique_nonzero_owner_298
 E  unique_nonzero_owner_299
 E  unique_nonzero_owner_300
 E  unique_nonzero_owner_301
 E  unique_nonzero_owner_302
 E  unique_nonzero_owner_303
 E  unique_nonzero_owner_304
 E  unique_nonzero_owner_305
 E  unique_nonzero_owner_306
 E  unique_nonzero_owner_307
 E  unique_nonzero_owner_308
 E  unique_nonzero_owner_309
 E  unique_nonzero_owner_310
 E  unique_nonzero_owner_311
 E  unique_nonzero_owner_312
 E  unique_nonzero_owner_313
 E  unique_nonzero_owner_314
 E  unique_nonzero_owner_315
 E  unique_nonzero_owner_316
 E  unique_nonzero_owner_317
 E  unique_nonzero_owner_318
 E  unique_nonzero_owner_319
 E  unique_nonzero_owner_320
 E  unique_nonzero_owner_321
 E  unique_nonzero_owner_322
 E  unique_nonzero_owner_323
 E  unique_nonzero_owner_324
 E  unique_nonzero_owner_325
 E  unique_nonzero_owner_326
 E  unique_nonzero_owner_327
 E  unique_nonzero_owner_328
 L  arc_capacity_329
 L  arc_capacity_330
 L  arc_capacity_331
 L  arc_capacity_332
 L  arc_capacity_333
 L  arc_capacity_334
 L  arc_capacity_335
 L  arc_capacity_336
 L  arc_capacity_337
 L  arc_capacity_338
 L  arc_capacity_339
 L  arc_capacity_340
 L  arc_capacity_341
 L  arc_capacity_342
 L  arc_capacity_343
 L  arc_capacity_344
 G  connected_order_arc_345
 L  arc_capacity_346
 G  connected_order_arc_347
 L  arc_capacity_348
 G  connected_order_arc_349
 L  arc_capacity_350
 G  connected_order_arc_351
 L  arc_capacity_352
 G  connected_order_arc_353
 L  arc_capacity_354
 G  connected_order_arc_355
 L  arc_capacity_356
 G  connected_order_arc_357
 L  arc_capacity_358
 G  connected_order_arc_359
 L  arc_capacity_360
 G  connected_order_arc_361
 L  arc_capacity_362
 G  connected_order_arc_363
 L  arc_capacity_364
 G  connected_order_arc_365
 L  arc_capacity_366
 G  connected_order_arc_367
 L  arc_capacity_368
 L  arc_capacity_369
 G  connected_order_arc_370
 L  arc_capacity_371
 G  connected_order_arc_372
 L  arc_capacity_373
 G  connected_order_arc_374
 L  arc_capacity_375
 G  connected_order_arc_376
 L  arc_capacity_377
 G  connected_order_arc_378
 L  arc_capacity_379
 G  connected_order_arc_380
 L  arc_capacity_381
 G  connected_order_arc_382
 L  arc_capacity_383
 G  connected_order_arc_384
 L  arc_capacity_385
 G  connected_order_arc_386
 L  arc_capacity_387
 G  connected_order_arc_388
 L  arc_capacity_389
 G  connected_order_arc_390
 L  arc_capacity_391
 G  connected_order_arc_392
 L  arc_capacity_393
 L  arc_capacity_394
 G  connected_order_arc_395
 L  arc_capacity_396
 G  connected_order_arc_397
 L  arc_capacity_398
 G  connected_order_arc_399
 L  arc_capacity_400
 G  connected_order_arc_401
 L  arc_capacity_402
 G  connected_order_arc_403
 L  arc_capacity_404
 G  connected_order_arc_405
 L  arc_capacity_406
 G  connected_order_arc_407
 L  arc_capacity_408
 G  connected_order_arc_409
 L  arc_capacity_410
 G  connected_order_arc_411
 L  arc_capacity_412
 G  connected_order_arc_413
 L  arc_capacity_414
 G  connected_order_arc_415
 L  arc_capacity_416
 G  connected_order_arc_417
 L  arc_capacity_418
 L  arc_capacity_419
 G  connected_order_arc_420
 L  arc_capacity_421
 G  connected_order_arc_422
 L  arc_capacity_423
 G  connected_order_arc_424
 L  arc_capacity_425
 G  connected_order_arc_426
 L  arc_capacity_427
 G  connected_order_arc_428
 L  arc_capacity_429
 G  connected_order_arc_430
 L  arc_capacity_431
 G  connected_order_arc_432
 L  arc_capacity_433
 G  connected_order_arc_434
 L  arc_capacity_435
 G  connected_order_arc_436
 L  arc_capacity_437
 G  connected_order_arc_438
 L  arc_capacity_439
 G  connected_order_arc_440
 L  arc_capacity_441
 G  connected_order_arc_442
 L  arc_capacity_443
 L  arc_capacity_444
 G  connected_order_arc_445
 L  arc_capacity_446
 G  connected_order_arc_447
 L  arc_capacity_448
 G  connected_order_arc_449
 L  arc_capacity_450
 G  connected_order_arc_451
 L  arc_capacity_452
 G  connected_order_arc_453
 L  arc_capacity_454
 G  connected_order_arc_455
 L  arc_capacity_456
 G  connected_order_arc_457
 L  arc_capacity_458
 G  connected_order_arc_459
 L  arc_capacity_460
 G  connected_order_arc_461
 L  arc_capacity_462
 G  connected_order_arc_463
 L  arc_capacity_464
 G  connected_order_arc_465
 L  arc_capacity_466
 G  connected_order_arc_467
 L  arc_capacity_468
 L  arc_capacity_469
 G  connected_order_arc_470
 L  arc_capacity_471
 G  connected_order_arc_472
 L  arc_capacity_473
 G  connected_order_arc_474
 L  arc_capacity_475
 G  connected_order_arc_476
 L  arc_capacity_477
 G  connected_order_arc_478
 L  arc_capacity_479
 G  connected_order_arc_480
 L  arc_capacity_481
 G  connected_order_arc_482
 L  arc_capacity_483
 G  connected_order_arc_484
 L  arc_capacity_485
 G  connected_order_arc_486
 L  arc_capacity_487
 G  connected_order_arc_488
 L  arc_capacity_489
 G  connected_order_arc_490
 L  arc_capacity_491
 G  connected_order_arc_492
 L  arc_capacity_493
 L  arc_capacity_494
 G  connected_order_arc_495
 L  arc_capacity_496
 G  connected_order_arc_497
 L  arc_capacity_498
 G  connected_order_arc_499
 L  arc_capacity_500
 G  connected_order_arc_501
 L  arc_capacity_502
 G  connected_order_arc_503
 L  arc_capacity_504
 G  connected_order_arc_505
 L  arc_capacity_506
 G  connected_order_arc_507
 L  arc_capacity_508
 G  connected_order_arc_509
 L  arc_capacity_510
 G  connected_order_arc_511
 L  arc_capacity_512
 G  connected_order_arc_513
 L  arc_capacity_514
 G  connected_order_arc_515
 L  arc_capacity_516
 G  connected_order_arc_517
 L  arc_capacity_518
 L  arc_capacity_519
 G  connected_order_arc_520
 L  arc_capacity_521
 G  connected_order_arc_522
 L  arc_capacity_523
 G  connected_order_arc_524
 L  arc_capacity_525
 G  connected_order_arc_526
 L  arc_capacity_527
 G  connected_order_arc_528
 L  arc_capacity_529
 G  connected_order_arc_530
 L  arc_capacity_531
 G  connected_order_arc_532
 L  arc_capacity_533
 G  connected_order_arc_534
 L  arc_capacity_535
 G  connected_order_arc_536
 L  arc_capacity_537
 G  connected_order_arc_538
 L  arc_capacity_539
 G  connected_order_arc_540
 L  arc_capacity_541
 G  connected_order_arc_542
 L  arc_capacity_543
 L  arc_capacity_544
 G  connected_order_arc_545
 L  arc_capacity_546
 G  connected_order_arc_547
 L  arc_capacity_548
 G  connected_order_arc_549
 L  arc_capacity_550
 G  connected_order_arc_551
 L  arc_capacity_552
 G  connected_order_arc_553
 L  arc_capacity_554
 G  connected_order_arc_555
 L  arc_capacity_556
 G  connected_order_arc_557
 L  arc_capacity_558
 G  connected_order_arc_559
 L  arc_capacity_560
 G  connected_order_arc_561
 L  arc_capacity_562
 G  connected_order_arc_563
 L  arc_capacity_564
 G  connected_order_arc_565
 L  arc_capacity_566
 G  connected_order_arc_567
 L  arc_capacity_568
 L  arc_capacity_569
 G  connected_order_arc_570
 L  arc_capacity_571
 G  connected_order_arc_572
 L  arc_capacity_573
 G  connected_order_arc_574
 L  arc_capacity_575
 G  connected_order_arc_576
 L  arc_capacity_577
 G  connected_order_arc_578
 L  arc_capacity_579
 G  connected_order_arc_580
 L  arc_capacity_581
 G  connected_order_arc_582
 L  arc_capacity_583
 G  connected_order_arc_584
 L  arc_capacity_585
 G  connected_order_arc_586
 L  arc_capacity_587
 G  connected_order_arc_588
 L  arc_capacity_589
 G  connected_order_arc_590
 L  arc_capacity_591
 G  connected_order_arc_592
 L  arc_capacity_593
 L  arc_capacity_594
 G  connected_order_arc_595
 L  arc_capacity_596
 G  connected_order_arc_597
 L  arc_capacity_598
 G  connected_order_arc_599
 L  arc_capacity_600
 G  connected_order_arc_601
 L  arc_capacity_602
 G  connected_order_arc_603
 L  arc_capacity_604
 G  connected_order_arc_605
 L  arc_capacity_606
 G  connected_order_arc_607
 L  arc_capacity_608
 G  connected_order_arc_609
 L  arc_capacity_610
 G  connected_order_arc_611
 L  arc_capacity_612
 G  connected_order_arc_613
 L  arc_capacity_614
 G  connected_order_arc_615
 L  arc_capacity_616
 G  connected_order_arc_617
 L  arc_capacity_618
 L  arc_capacity_619
 G  connected_order_arc_620
 L  arc_capacity_621
 G  connected_order_arc_622
 L  arc_capacity_623
 G  connected_order_arc_624
 L  arc_capacity_625
 G  connected_order_arc_626
 L  arc_capacity_627
 G  connected_order_arc_628
 L  arc_capacity_629
 G  connected_order_arc_630
 L  arc_capacity_631
 G  connected_order_arc_632
 L  arc_capacity_633
 G  connected_order_arc_634
 L  arc_capacity_635
 G  connected_order_arc_636
 L  arc_capacity_637
 G  connected_order_arc_638
 L  arc_capacity_639
 G  connected_order_arc_640
 L  arc_capacity_641
 G  connected_order_arc_642
 L  arc_capacity_643
 L  arc_capacity_644
 G  connected_order_arc_645
 L  arc_capacity_646
 G  connected_order_arc_647
 L  arc_capacity_648
 G  connected_order_arc_649
 L  arc_capacity_650
 G  connected_order_arc_651
 L  arc_capacity_652
 G  connected_order_arc_653
 L  arc_capacity_654
 G  connected_order_arc_655
 L  arc_capacity_656
 G  connected_order_arc_657
 L  arc_capacity_658
 G  connected_order_arc_659
 L  arc_capacity_660
 G  connected_order_arc_661
 L  arc_capacity_662
 G  connected_order_arc_663
 L  arc_capacity_664
 G  connected_order_arc_665
 L  arc_capacity_666
 G  connected_order_arc_667
 E  depot_departure_or_bypass_668
 E  depot_return_or_bypass_669
 E  out_degree_670
 E  in_degree_671
 G  order_active_lb_672
 L  order_active_ub_673
 E  segment_load_conservation_674
 G  segment_prefix_lb_675
 L  segment_prefix_ub_676
 E  out_degree_677
 E  in_degree_678
 G  order_active_lb_679
 L  order_active_ub_680
 E  segment_load_conservation_681
 G  segment_prefix_lb_682
 L  segment_prefix_ub_683
 E  out_degree_684
 E  in_degree_685
 G  order_active_lb_686
 L  order_active_ub_687
 E  segment_load_conservation_688
 G  segment_prefix_lb_689
 L  segment_prefix_ub_690
 E  out_degree_691
 E  in_degree_692
 G  order_active_lb_693
 L  order_active_ub_694
 E  segment_load_conservation_695
 G  segment_prefix_lb_696
 L  segment_prefix_ub_697
 E  out_degree_698
 E  in_degree_699
 G  order_active_lb_700
 L  order_active_ub_701
 E  segment_load_conservation_702
 G  segment_prefix_lb_703
 L  segment_prefix_ub_704
 E  out_degree_705
 E  in_degree_706
 G  order_active_lb_707
 L  order_active_ub_708
 E  service_visit_def_709
 E  free_load_conservation_710
 E  out_degree_711
 E  in_degree_712
 G  order_active_lb_713
 L  order_active_ub_714
 E  service_visit_def_715
 E  free_load_conservation_716
 E  out_degree_717
 E  in_degree_718
 G  order_active_lb_719
 L  order_active_ub_720
 E  service_visit_def_721
 E  free_load_conservation_722
 E  out_degree_723
 E  in_degree_724
 G  order_active_lb_725
 L  order_active_ub_726
 E  service_visit_def_727
 E  free_load_conservation_728
 E  out_degree_729
 E  in_degree_730
 G  order_active_lb_731
 L  order_active_ub_732
 E  service_visit_def_733
 E  free_load_conservation_734
 E  out_degree_735
 E  in_degree_736
 G  order_active_lb_737
 L  order_active_ub_738
 E  service_visit_def_739
 E  free_load_conservation_740
 E  out_degree_741
 E  in_degree_742
 G  order_active_lb_743
 L  order_active_ub_744
 E  service_visit_def_745
 E  free_load_conservation_746
 E  out_degree_747
 E  in_degree_748
 G  order_active_lb_749
 L  order_active_ub_750
 E  service_visit_def_751
 E  free_load_conservation_752
 G  fixed_segment_relative_order_753
 G  fixed_segment_relative_order_754
 G  fixed_segment_relative_order_755
 G  fixed_segment_relative_order_756
 L  original_T_including_depot_unload_757
 L  arc_capacity_758
 L  arc_capacity_759
 L  arc_capacity_760
 L  arc_capacity_761
 L  arc_capacity_762
 L  arc_capacity_763
 L  arc_capacity_764
 L  arc_capacity_765
 L  arc_capacity_766
 L  arc_capacity_767
 L  arc_capacity_768
 L  arc_capacity_769
 L  arc_capacity_770
 G  connected_order_arc_771
 L  arc_capacity_772
 G  connected_order_arc_773
 L  arc_capacity_774
 G  connected_order_arc_775
 L  arc_capacity_776
 G  connected_order_arc_777
 L  arc_capacity_778
 G  connected_order_arc_779
 L  arc_capacity_780
 G  connected_order_arc_781
 L  arc_capacity_782
 G  connected_order_arc_783
 L  arc_capacity_784
 G  connected_order_arc_785
 L  arc_capacity_786
 G  connected_order_arc_787
 L  arc_capacity_788
 L  arc_capacity_789
 G  connected_order_arc_790
 L  arc_capacity_791
 G  connected_order_arc_792
 L  arc_capacity_793
 G  connected_order_arc_794
 L  arc_capacity_795
 G  connected_order_arc_796
 L  arc_capacity_797
 G  connected_order_arc_798
 L  arc_capacity_799
 G  connected_order_arc_800
 L  arc_capacity_801
 G  connected_order_arc_802
 L  arc_capacity_803
 G  connected_order_arc_804
 L  arc_capacity_805
 G  connected_order_arc_806
 L  arc_capacity_807
 L  arc_capacity_808
 G  connected_order_arc_809
 L  arc_capacity_810
 G  connected_order_arc_811
 L  arc_capacity_812
 G  connected_order_arc_813
 L  arc_capacity_814
 G  connected_order_arc_815
 L  arc_capacity_816
 G  connected_order_arc_817
 L  arc_capacity_818
 G  connected_order_arc_819
 L  arc_capacity_820
 G  connected_order_arc_821
 L  arc_capacity_822
 G  connected_order_arc_823
 L  arc_capacity_824
 G  connected_order_arc_825
 L  arc_capacity_826
 L  arc_capacity_827
 G  connected_order_arc_828
 L  arc_capacity_829
 G  connected_order_arc_830
 L  arc_capacity_831
 G  connected_order_arc_832
 L  arc_capacity_833
 G  connected_order_arc_834
 L  arc_capacity_835
 G  connected_order_arc_836
 L  arc_capacity_837
 G  connected_order_arc_838
 L  arc_capacity_839
 G  connected_order_arc_840
 L  arc_capacity_841
 G  connected_order_arc_842
 L  arc_capacity_843
 G  connected_order_arc_844
 L  arc_capacity_845
 L  arc_capacity_846
 G  connected_order_arc_847
 L  arc_capacity_848
 G  connected_order_arc_849
 L  arc_capacity_850
 G  connected_order_arc_851
 L  arc_capacity_852
 G  connected_order_arc_853
 L  arc_capacity_854
 G  connected_order_arc_855
 L  arc_capacity_856
 G  connected_order_arc_857
 L  arc_capacity_858
 G  connected_order_arc_859
 L  arc_capacity_860
 G  connected_order_arc_861
 L  arc_capacity_862
 G  connected_order_arc_863
 L  arc_capacity_864
 L  arc_capacity_865
 G  connected_order_arc_866
 L  arc_capacity_867
 G  connected_order_arc_868
 L  arc_capacity_869
 G  connected_order_arc_870
 L  arc_capacity_871
 G  connected_order_arc_872
 L  arc_capacity_873
 G  connected_order_arc_874
 L  arc_capacity_875
 G  connected_order_arc_876
 L  arc_capacity_877
 G  connected_order_arc_878
 L  arc_capacity_879
 G  connected_order_arc_880
 L  arc_capacity_881
 G  connected_order_arc_882
 L  arc_capacity_883
 L  arc_capacity_884
 G  connected_order_arc_885
 L  arc_capacity_886
 G  connected_order_arc_887
 L  arc_capacity_888
 G  connected_order_arc_889
 L  arc_capacity_890
 G  connected_order_arc_891
 L  arc_capacity_892
 G  connected_order_arc_893
 L  arc_capacity_894
 G  connected_order_arc_895
 L  arc_capacity_896
 G  connected_order_arc_897
 L  arc_capacity_898
 G  connected_order_arc_899
 L  arc_capacity_900
 G  connected_order_arc_901
 L  arc_capacity_902
 L  arc_capacity_903
 G  connected_order_arc_904
 L  arc_capacity_905
 G  connected_order_arc_906
 L  arc_capacity_907
 G  connected_order_arc_908
 L  arc_capacity_909
 G  connected_order_arc_910
 L  arc_capacity_911
 G  connected_order_arc_912
 L  arc_capacity_913
 G  connected_order_arc_914
 L  arc_capacity_915
 G  connected_order_arc_916
 L  arc_capacity_917
 G  connected_order_arc_918
 L  arc_capacity_919
 G  connected_order_arc_920
 L  arc_capacity_921
 L  arc_capacity_922
 G  connected_order_arc_923
 L  arc_capacity_924
 G  connected_order_arc_925
 L  arc_capacity_926
 G  connected_order_arc_927
 L  arc_capacity_928
 G  connected_order_arc_929
 L  arc_capacity_930
 G  connected_order_arc_931
 L  arc_capacity_932
 G  connected_order_arc_933
 L  arc_capacity_934
 G  connected_order_arc_935
 L  arc_capacity_936
 G  connected_order_arc_937
 L  arc_capacity_938
 G  connected_order_arc_939
 L  arc_capacity_940
 L  arc_capacity_941
 G  connected_order_arc_942
 L  arc_capacity_943
 G  connected_order_arc_944
 L  arc_capacity_945
 G  connected_order_arc_946
 L  arc_capacity_947
 G  connected_order_arc_948
 L  arc_capacity_949
 G  connected_order_arc_950
 L  arc_capacity_951
 G  connected_order_arc_952
 L  arc_capacity_953
 G  connected_order_arc_954
 L  arc_capacity_955
 G  connected_order_arc_956
 L  arc_capacity_957
 G  connected_order_arc_958
 E  depot_departure_or_bypass_959
 E  depot_return_or_bypass_960
 E  out_degree_961
 E  in_degree_962
 G  order_active_lb_963
 L  order_active_ub_964
 E  segment_load_conservation_965
 G  segment_prefix_lb_966
 L  segment_prefix_ub_967
 E  out_degree_968
 E  in_degree_969
 G  order_active_lb_970
 L  order_active_ub_971
 E  segment_load_conservation_972
 G  segment_prefix_lb_973
 L  segment_prefix_ub_974
 E  out_degree_975
 E  in_degree_976
 G  order_active_lb_977
 L  order_active_ub_978
 E  service_visit_def_979
 E  free_load_conservation_980
 E  out_degree_981
 E  in_degree_982
 G  order_active_lb_983
 L  order_active_ub_984
 E  service_visit_def_985
 E  free_load_conservation_986
 E  out_degree_987
 E  in_degree_988
 G  order_active_lb_989
 L  order_active_ub_990
 E  service_visit_def_991
 E  free_load_conservation_992
 E  out_degree_993
 E  in_degree_994
 G  order_active_lb_995
 L  order_active_ub_996
 E  service_visit_def_997
 E  free_load_conservation_998
 E  out_degree_999
 E  in_degree_1000
 G  order_active_lb_1001
 L  order_active_ub_1002
 E  service_visit_def_1003
 E  free_load_conservation_1004
 E  out_degree_1005
 E  in_degree_1006
 G  order_active_lb_1007
 L  order_active_ub_1008
 E  service_visit_def_1009
 E  free_load_conservation_1010
 E  out_degree_1011
 E  in_degree_1012
 G  order_active_lb_1013
 L  order_active_ub_1014
 E  service_visit_def_1015
 E  free_load_conservation_1016
 E  out_degree_1017
 E  in_degree_1018
 G  order_active_lb_1019
 L  order_active_ub_1020
 E  service_visit_def_1021
 E  free_load_conservation_1022
 G  fixed_segment_relative_order_1023
 L  original_T_including_depot_unload_1024
COLUMNS
    t         normalized_mass_6_5  -1
    t         normalized_mass_3_42  -1
    t         normalized_mass_18_77  -1
    t         normalized_mass_7_102  -1
    t         normalized_mass_17_139  -1
    t         normalized_mass_5_148  -1
    t         normalized_mass_11_183  -1
    t         normalized_mass_2_190  -1
    t         normalization_251  9.0714285714285712e+00
    t         full_original_Gini_252  -3.6642857142857139e+01
    q         OBJ       1
    q         parent_nonstrict_scope_194  1
    q         full_original_Gini_252  20
    MARKER    'MARKER'                 'INTORG'
    x_6_0     OBJ       6.3380304899829966e-03
    x_6_0     product_lb_0  -4.3731019522732839e-02
    x_6_0     product_ub_1  -1.1023622047255120e-01
    x_6_0     onehot_6_4  1
    x_6_0     parent_nonstrict_scope_194  1.2676060979965993e-02
    MARKER    'MARKER'                 'INTEND'
    w_6_0     product_lb_0  1
    w_6_0     product_ub_1  1
    w_6_0     normalized_mass_6_5  1
    w_6_0     full_original_Gini_252  -9.0714285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_6_1     OBJ       -6.3380304899829966e-03
    x_6_1     product_lb_2  -4.3731019522732839e-02
    x_6_1     product_ub_3  -1.1023622047255120e-01
    x_6_1     onehot_6_4  1
    x_6_1     stock_lb_192  1
    x_6_1     stock_ub_193  1
    x_6_1     unique_nonzero_owner_253  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_1     product_lb_2  1
    w_6_1     product_ub_3  1
    w_6_1     normalized_mass_6_5  1
    w_6_1     normalized_ratio_6_6  -1
    w_6_1     full_original_Gini_252  -4.2142857142857144e+00
    rho_6     normalized_ratio_6_6  1
    rho_6     block_pair_pos_211  -1
    rho_6     block_pair_neg_212  1
    rho_6     block_pair_pos_213  -1
    rho_6     block_pair_neg_214  1
    rho_6     block_pair_pos_215  -1
    rho_6     block_pair_neg_216  1
    rho_6     block_pair_pos_217  -1
    rho_6     block_pair_neg_218  1
    rho_6     block_pair_pos_219  -1
    rho_6     block_pair_neg_220  1
    rho_6     block_pair_pos_221  -1
    rho_6     block_pair_neg_222  1
    rho_6     block_pair_pos_223  -1
    rho_6     block_pair_neg_224  1
    rho_6     normalization_251  1
    MARKER    'MARKER'                 'INTORG'
    x_3_0     OBJ       5.0078236648368350e-02
    x_3_0     product_lb_7  -4.3731019522732839e-02
    x_3_0     product_ub_8  -1.1023622047255120e-01
    x_3_0     onehot_3_41  1
    x_3_0     parent_nonstrict_scope_194  1.0015647329673670e-01
    x_3_0     unique_nonzero_owner_254  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_0     product_lb_7  1
    w_3_0     product_ub_8  1
    w_3_0     normalized_mass_3_42  1
    w_3_0     full_original_Gini_252  -9.0714285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_1     OBJ       3.7558677486276261e-02
    x_3_1     product_lb_9  -4.3731019522732839e-02
    x_3_1     product_ub_10  -1.1023622047255120e-01
    x_3_1     onehot_3_41  1
    x_3_1     stock_lb_192  1
    x_3_1     stock_ub_193  1
    x_3_1     parent_nonstrict_scope_194  8.7636914134644611e-02
    x_3_1     unique_nonzero_owner_255  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_1     product_lb_9  1
    w_3_1     product_ub_10  1
    w_3_1     normalized_mass_3_42  1
    w_3_1     normalized_ratio_3_43  -0.125
    w_3_1     full_original_Gini_252  -8.3214285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_2     OBJ       2.5039118324184172e-02
    x_3_2     product_lb_11  -4.3731019522732839e-02
    x_3_2     product_ub_12  -1.1023622047255120e-01
    x_3_2     onehot_3_41  1
    x_3_2     stock_lb_192  2
    x_3_2     stock_ub_193  2
    x_3_2     parent_nonstrict_scope_194  7.5117354972552522e-02
    x_3_2     unique_nonzero_owner_256  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_2     product_lb_11  1
    w_3_2     product_ub_12  1
    w_3_2     normalized_mass_3_42  1
    w_3_2     normalized_ratio_3_43  -0.25
    w_3_2     full_original_Gini_252  -7.5714285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_3     OBJ       1.2519559162092082e-02
    x_3_3     product_lb_13  -4.3731019522732839e-02
    x_3_3     product_ub_14  -1.1023622047255120e-01
    x_3_3     onehot_3_41  1
    x_3_3     stock_lb_192  3
    x_3_3     stock_ub_193  3
    x_3_3     parent_nonstrict_scope_194  6.2597795810460433e-02
    x_3_3     unique_nonzero_owner_257  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_3     product_lb_13  1
    w_3_3     product_ub_14  1
    w_3_3     normalized_mass_3_42  1
    w_3_3     normalized_ratio_3_43  -0.375
    w_3_3     full_original_Gini_252  -6.8214285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_4     product_lb_15  -4.3731019522732839e-02
    x_3_4     product_ub_16  -1.1023622047255120e-01
    x_3_4     onehot_3_41  1
    x_3_4     stock_lb_192  4
    x_3_4     stock_ub_193  4
    x_3_4     parent_nonstrict_scope_194  5.0078236648368350e-02
    x_3_4     unique_nonzero_owner_258  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_4     product_lb_15  1
    w_3_4     product_ub_16  1
    w_3_4     normalized_mass_3_42  1
    w_3_4     normalized_ratio_3_43  -0.5
    w_3_4     full_original_Gini_252  -6.2142857142857135e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_5     OBJ       -1.2519559162092089e-02
    x_3_5     product_lb_17  -4.3731019522732839e-02
    x_3_5     product_ub_18  -1.1023622047255120e-01
    x_3_5     onehot_3_41  1
    x_3_5     stock_lb_192  5
    x_3_5     stock_ub_193  5
    x_3_5     parent_nonstrict_scope_194  3.7558677486276261e-02
    x_3_5     unique_nonzero_owner_259  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_5     product_lb_17  1
    w_3_5     product_ub_18  1
    w_3_5     normalized_mass_3_42  1
    w_3_5     normalized_ratio_3_43  -0.625
    w_3_5     full_original_Gini_252  -5.7142857142857144e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_6     OBJ       -2.5039118324184175e-02
    x_3_6     product_lb_19  -4.3731019522732839e-02
    x_3_6     product_ub_20  -1.1023622047255120e-01
    x_3_6     onehot_3_41  1
    x_3_6     stock_lb_192  6
    x_3_6     stock_ub_193  6
    x_3_6     parent_nonstrict_scope_194  2.5039118324184175e-02
    x_3_6     unique_nonzero_owner_260  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_6     product_lb_19  1
    w_3_6     product_ub_20  1
    w_3_6     normalized_mass_3_42  1
    w_3_6     normalized_ratio_3_43  -0.75
    w_3_6     full_original_Gini_252  -5.2142857142857144e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_7     OBJ       -3.7558677486276261e-02
    x_3_7     product_lb_21  -4.3731019522732839e-02
    x_3_7     product_ub_22  -1.1023622047255120e-01
    x_3_7     onehot_3_41  1
    x_3_7     stock_lb_192  7
    x_3_7     stock_ub_193  7
    x_3_7     parent_nonstrict_scope_194  1.2519559162092088e-02
    x_3_7     unique_nonzero_owner_261  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_7     product_lb_21  1
    w_3_7     product_ub_22  1
    w_3_7     normalized_mass_3_42  1
    w_3_7     normalized_ratio_3_43  -0.875
    w_3_7     full_original_Gini_252  -4.7142857142857144e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_8     OBJ       -5.0078236648368350e-02
    x_3_8     product_lb_23  -4.3731019522732839e-02
    x_3_8     product_ub_24  -1.1023622047255120e-01
    x_3_8     onehot_3_41  1
    x_3_8     stock_lb_192  8
    x_3_8     stock_ub_193  8
    x_3_8     unique_nonzero_owner_262  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_8     product_lb_23  1
    w_3_8     product_ub_24  1
    w_3_8     normalized_mass_3_42  1
    w_3_8     normalized_ratio_3_43  -1
    w_3_8     full_original_Gini_252  -4.2142857142857144e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_9     OBJ       -3.7558677486276261e-02
    x_3_9     product_lb_25  -4.3731019522732839e-02
    x_3_9     product_ub_26  -1.1023622047255120e-01
    x_3_9     onehot_3_41  1
    x_3_9     stock_lb_192  9
    x_3_9     stock_ub_193  9
    x_3_9     parent_nonstrict_scope_194  1.2519559162092088e-02
    x_3_9     unique_nonzero_owner_263  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_9     product_lb_25  1
    w_3_9     product_ub_26  1
    w_3_9     normalized_mass_3_42  1
    w_3_9     normalized_ratio_3_43  -1.125
    w_3_9     full_original_Gini_252  -5.2142857142857135e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_10    OBJ       -2.5039118324184175e-02
    x_3_10    product_lb_27  -4.3731019522732839e-02
    x_3_10    product_ub_28  -1.1023622047255120e-01
    x_3_10    onehot_3_41  1
    x_3_10    stock_lb_192  10
    x_3_10    stock_ub_193  10
    x_3_10    parent_nonstrict_scope_194  2.5039118324184175e-02
    x_3_10    unique_nonzero_owner_264  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_10    product_lb_27  1
    w_3_10    product_ub_28  1
    w_3_10    normalized_mass_3_42  1
    w_3_10    normalized_ratio_3_43  -1.25
    w_3_10    full_original_Gini_252  -6.4285714285714288e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_11    OBJ       -1.2519559162092089e-02
    x_3_11    product_lb_29  -4.3731019522732839e-02
    x_3_11    product_ub_30  -1.1023622047255120e-01
    x_3_11    onehot_3_41  1
    x_3_11    stock_lb_192  11
    x_3_11    stock_ub_193  11
    x_3_11    parent_nonstrict_scope_194  3.7558677486276261e-02
    x_3_11    unique_nonzero_owner_265  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_11    product_lb_29  1
    w_3_11    product_ub_30  1
    w_3_11    normalized_mass_3_42  1
    w_3_11    normalized_ratio_3_43  -1.375
    w_3_11    full_original_Gini_252  -7.6785714285714288e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_12    product_lb_31  -4.3731019522732839e-02
    x_3_12    product_ub_32  -1.1023622047255120e-01
    x_3_12    onehot_3_41  1
    x_3_12    stock_lb_192  12
    x_3_12    stock_ub_193  12
    x_3_12    parent_nonstrict_scope_194  5.0078236648368350e-02
    MARKER    'MARKER'                 'INTEND'
    w_3_12    product_lb_31  1
    w_3_12    product_ub_32  1
    w_3_12    normalized_mass_3_42  1
    w_3_12    normalized_ratio_3_43  -1.5
    w_3_12    full_original_Gini_252  -8.9285714285714288e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_13    OBJ       1.2519559162092082e-02
    x_3_13    product_lb_33  -4.3731019522732839e-02
    x_3_13    product_ub_34  -1.1023622047255120e-01
    x_3_13    onehot_3_41  1
    x_3_13    stock_lb_192  13
    x_3_13    stock_ub_193  13
    x_3_13    parent_nonstrict_scope_194  6.2597795810460433e-02
    x_3_13    unique_nonzero_owner_266  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_13    product_lb_33  1
    w_3_13    product_ub_34  1
    w_3_13    normalized_mass_3_42  1
    w_3_13    normalized_ratio_3_43  -1.625
    w_3_13    full_original_Gini_252  -1.0428571428571429e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_14    OBJ       2.5039118324184172e-02
    x_3_14    product_lb_35  -4.3731019522732839e-02
    x_3_14    product_ub_36  -1.1023622047255120e-01
    x_3_14    onehot_3_41  1
    x_3_14    stock_lb_192  14
    x_3_14    stock_ub_193  14
    x_3_14    parent_nonstrict_scope_194  7.5117354972552522e-02
    x_3_14    unique_nonzero_owner_267  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_14    product_lb_35  1
    w_3_14    product_ub_36  1
    w_3_14    normalized_mass_3_42  1
    w_3_14    normalized_ratio_3_43  -1.75
    w_3_14    full_original_Gini_252  -1.1928571428571429e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_15    OBJ       3.7558677486276261e-02
    x_3_15    product_lb_37  -4.3731019522732839e-02
    x_3_15    product_ub_38  -1.1023622047255120e-01
    x_3_15    onehot_3_41  1
    x_3_15    stock_lb_192  15
    x_3_15    stock_ub_193  15
    x_3_15    parent_nonstrict_scope_194  8.7636914134644611e-02
    x_3_15    unique_nonzero_owner_268  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_15    product_lb_37  1
    w_3_15    product_ub_38  1
    w_3_15    normalized_mass_3_42  1
    w_3_15    normalized_ratio_3_43  -1.875
    w_3_15    full_original_Gini_252  -1.3428571428571429e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_16    OBJ       5.0078236648368350e-02
    x_3_16    product_lb_39  -4.3731019522732839e-02
    x_3_16    product_ub_40  -1.1023622047255120e-01
    x_3_16    onehot_3_41  1
    x_3_16    stock_lb_192  16
    x_3_16    stock_ub_193  16
    x_3_16    parent_nonstrict_scope_194  1.0015647329673670e-01
    x_3_16    unique_nonzero_owner_269  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_16    product_lb_39  1
    w_3_16    product_ub_40  1
    w_3_16    normalized_mass_3_42  1
    w_3_16    normalized_ratio_3_43  -2
    w_3_16    full_original_Gini_252  -1.4928571428571429e+01
    rho_3     normalized_ratio_3_43  1
    rho_3     block_pair_pos_195  -1
    rho_3     block_pair_neg_196  1
    rho_3     block_pair_pos_197  -1
    rho_3     block_pair_neg_198  1
    rho_3     block_pair_pos_199  -1
    rho_3     block_pair_neg_200  1
    rho_3     block_pair_pos_201  -1
    rho_3     block_pair_neg_202  1
    rho_3     block_pair_pos_203  -1
    rho_3     block_pair_neg_204  1
    rho_3     block_pair_pos_205  -1
    rho_3     block_pair_neg_206  1
    rho_3     block_pair_pos_213  1
    rho_3     block_pair_neg_214  -1
    rho_3     normalization_251  1
    MARKER    'MARKER'                 'INTORG'
    x_18_0    OBJ       3.2863847044708572e-02
    x_18_0    product_lb_44  -4.3731019522732839e-02
    x_18_0    product_ub_45  -1.1023622047255120e-01
    x_18_0    onehot_18_76  1
    x_18_0    parent_nonstrict_scope_194  7.6682309770986667e-02
    MARKER    'MARKER'                 'INTEND'
    w_18_0    product_lb_44  1
    w_18_0    product_ub_45  1
    w_18_0    normalized_mass_18_77  1
    w_18_0    full_original_Gini_252  -9.0714285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_1    OBJ       2.1909231363139048e-02
    x_18_1    product_lb_46  -4.3731019522732839e-02
    x_18_1    product_ub_47  -1.1023622047255120e-01
    x_18_1    onehot_18_76  1
    x_18_1    stock_lb_192  1
    x_18_1    stock_ub_193  1
    x_18_1    parent_nonstrict_scope_194  6.5727694089417144e-02
    x_18_1    unique_nonzero_owner_270  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_1    product_lb_46  1
    w_18_1    product_ub_47  1
    w_18_1    normalized_mass_18_77  1
    w_18_1    normalized_ratio_18_78  -1.4285714285714285e-01
    w_18_1    full_original_Gini_252  -8.2142857142857153e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_2    OBJ       1.0954615681569524e-02
    x_18_2    product_lb_48  -4.3731019522732839e-02
    x_18_2    product_ub_49  -1.1023622047255120e-01
    x_18_2    onehot_18_76  1
    x_18_2    stock_lb_192  2
    x_18_2    stock_ub_193  2
    x_18_2    parent_nonstrict_scope_194  5.4773078407847620e-02
    x_18_2    unique_nonzero_owner_271  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_2    product_lb_48  1
    w_18_2    product_ub_49  1
    w_18_2    normalized_mass_18_77  1
    w_18_2    normalized_ratio_18_78  -2.8571428571428570e-01
    w_18_2    full_original_Gini_252  -7.3571428571428577e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_3    product_lb_50  -4.3731019522732839e-02
    x_18_3    product_ub_51  -1.1023622047255120e-01
    x_18_3    onehot_18_76  1
    x_18_3    stock_lb_192  3
    x_18_3    stock_ub_193  3
    x_18_3    parent_nonstrict_scope_194  4.3818462726278096e-02
    x_18_3    unique_nonzero_owner_272  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_3    product_lb_50  1
    w_18_3    product_ub_51  1
    w_18_3    normalized_mass_18_77  1
    w_18_3    normalized_ratio_18_78  -4.2857142857142855e-01
    w_18_3    full_original_Gini_252  -6.4999999999999991e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_4    OBJ       -1.0954615681569524e-02
    x_18_4    product_lb_52  -4.3731019522732839e-02
    x_18_4    product_ub_53  -1.1023622047255120e-01
    x_18_4    onehot_18_76  1
    x_18_4    stock_lb_192  4
    x_18_4    stock_ub_193  4
    x_18_4    parent_nonstrict_scope_194  3.2863847044708572e-02
    x_18_4    unique_nonzero_owner_273  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_4    product_lb_52  1
    w_18_4    product_ub_53  1
    w_18_4    normalized_mass_18_77  1
    w_18_4    normalized_ratio_18_78  -5.7142857142857140e-01
    w_18_4    full_original_Gini_252  -5.9285714285714288e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_5    OBJ       -2.1909231363139041e-02
    x_18_5    product_lb_54  -4.3731019522732839e-02
    x_18_5    product_ub_55  -1.1023622047255120e-01
    x_18_5    onehot_18_76  1
    x_18_5    stock_lb_192  5
    x_18_5    stock_ub_193  5
    x_18_5    parent_nonstrict_scope_194  2.1909231363139055e-02
    x_18_5    unique_nonzero_owner_274  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_5    product_lb_54  1
    w_18_5    product_ub_55  1
    w_18_5    normalized_mass_18_77  1
    w_18_5    normalized_ratio_18_78  -7.1428571428571419e-01
    w_18_5    full_original_Gini_252  -5.3571428571428568e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_6    OBJ       -3.2863847044708572e-02
    x_18_6    product_lb_56  -4.3731019522732839e-02
    x_18_6    product_ub_57  -1.1023622047255120e-01
    x_18_6    onehot_18_76  1
    x_18_6    stock_lb_192  6
    x_18_6    stock_ub_193  6
    x_18_6    parent_nonstrict_scope_194  1.0954615681569527e-02
    x_18_6    unique_nonzero_owner_275  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_6    product_lb_56  1
    w_18_6    product_ub_57  1
    w_18_6    normalized_mass_18_77  1
    w_18_6    normalized_ratio_18_78  -8.5714285714285710e-01
    w_18_6    full_original_Gini_252  -4.7857142857142856e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_7    OBJ       -4.3818462726278096e-02
    x_18_7    product_lb_58  -4.3731019522732839e-02
    x_18_7    product_ub_59  -1.1023622047255120e-01
    x_18_7    onehot_18_76  1
    x_18_7    stock_lb_192  7
    x_18_7    stock_ub_193  7
    x_18_7    unique_nonzero_owner_276  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_7    product_lb_58  1
    w_18_7    product_ub_59  1
    w_18_7    normalized_mass_18_77  1
    w_18_7    normalized_ratio_18_78  -1
    w_18_7    full_original_Gini_252  -4.2142857142857144e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_8    OBJ       -3.2863847044708579e-02
    x_18_8    product_lb_60  -4.3731019522732839e-02
    x_18_8    product_ub_61  -1.1023622047255120e-01
    x_18_8    onehot_18_76  1
    x_18_8    stock_lb_192  8
    x_18_8    stock_ub_193  8
    x_18_8    parent_nonstrict_scope_194  1.0954615681569519e-02
    x_18_8    unique_nonzero_owner_277  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_8    product_lb_60  1
    w_18_8    product_ub_61  1
    w_18_8    normalized_mass_18_77  1
    w_18_8    normalized_ratio_18_78  -1.1428571428571428e+00
    w_18_8    full_original_Gini_252  -5.3571428571428559e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_9    OBJ       -2.1909231363139058e-02
    x_18_9    product_lb_62  -4.3731019522732839e-02
    x_18_9    product_ub_63  -1.1023622047255120e-01
    x_18_9    onehot_18_76  1
    x_18_9    stock_lb_192  9
    x_18_9    stock_ub_193  9
    x_18_9    parent_nonstrict_scope_194  2.1909231363139037e-02
    x_18_9    unique_nonzero_owner_278  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_9    product_lb_62  1
    w_18_9    product_ub_63  1
    w_18_9    normalized_mass_18_77  1
    w_18_9    normalized_ratio_18_78  -1.2857142857142856e+00
    w_18_9    full_original_Gini_252  -6.7857142857142838e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_10   OBJ       -1.0954615681569538e-02
    x_18_10   product_lb_64  -4.3731019522732839e-02
    x_18_10   product_ub_65  -1.1023622047255120e-01
    x_18_10   onehot_18_76  1
    x_18_10   stock_lb_192  10
    x_18_10   stock_ub_193  10
    x_18_10   parent_nonstrict_scope_194  3.2863847044708558e-02
    x_18_10   unique_nonzero_owner_279  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_10   product_lb_64  1
    w_18_10   product_ub_65  1
    w_18_10   normalized_mass_18_77  1
    w_18_10   normalized_ratio_18_78  -1.4285714285714284e+00
    w_18_10   full_original_Gini_252  -8.2142857142857135e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_11   product_lb_66  -4.3731019522732839e-02
    x_18_11   product_ub_67  -1.1023622047255120e-01
    x_18_11   onehot_18_76  1
    x_18_11   stock_lb_192  11
    x_18_11   stock_ub_193  11
    x_18_11   parent_nonstrict_scope_194  4.3818462726278096e-02
    x_18_11   unique_nonzero_owner_280  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_11   product_lb_66  1
    w_18_11   product_ub_67  1
    w_18_11   normalized_mass_18_77  1
    w_18_11   normalized_ratio_18_78  -1.5714285714285714e+00
    w_18_11   full_original_Gini_252  -9.7857142857142847e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_12   OBJ       1.0954615681569517e-02
    x_18_12   product_lb_68  -4.3731019522732839e-02
    x_18_12   product_ub_69  -1.1023622047255120e-01
    x_18_12   onehot_18_76  1
    x_18_12   stock_lb_192  12
    x_18_12   stock_ub_193  12
    x_18_12   parent_nonstrict_scope_194  5.4773078407847613e-02
    x_18_12   unique_nonzero_owner_281  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_12   product_lb_68  1
    w_18_12   product_ub_69  1
    w_18_12   normalized_mass_18_77  1
    w_18_12   normalized_ratio_18_78  -1.7142857142857142e+00
    w_18_12   full_original_Gini_252  -1.1499999999999996e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_13   OBJ       2.1909231363139034e-02
    x_18_13   product_lb_70  -4.3731019522732839e-02
    x_18_13   product_ub_71  -1.1023622047255120e-01
    x_18_13   onehot_18_76  1
    x_18_13   stock_lb_192  13
    x_18_13   stock_ub_193  13
    x_18_13   parent_nonstrict_scope_194  6.5727694089417130e-02
    x_18_13   unique_nonzero_owner_282  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_13   product_lb_70  1
    w_18_13   product_ub_71  1
    w_18_13   normalized_mass_18_77  1
    w_18_13   normalized_ratio_18_78  -1.8571428571428570e+00
    w_18_13   full_original_Gini_252  -1.3214285714285715e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_14   OBJ       3.2863847044708572e-02
    x_18_14   product_lb_72  -4.3731019522732839e-02
    x_18_14   product_ub_73  -1.1023622047255120e-01
    x_18_14   onehot_18_76  1
    x_18_14   stock_lb_192  14
    x_18_14   stock_ub_193  14
    x_18_14   parent_nonstrict_scope_194  7.6682309770986667e-02
    x_18_14   unique_nonzero_owner_283  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_14   product_lb_72  1
    w_18_14   product_ub_73  1
    w_18_14   normalized_mass_18_77  1
    w_18_14   normalized_ratio_18_78  -2
    w_18_14   full_original_Gini_252  -1.4928571428571429e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_15   OBJ       4.3818462726278096e-02
    x_18_15   product_lb_74  -4.3731019522732839e-02
    x_18_15   product_ub_75  -1.1023622047255120e-01
    x_18_15   onehot_18_76  1
    x_18_15   stock_lb_192  15
    x_18_15   stock_ub_193  15
    x_18_15   parent_nonstrict_scope_194  8.7636925452556191e-02
    x_18_15   unique_nonzero_owner_284  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_15   product_lb_74  1
    w_18_15   product_ub_75  1
    w_18_15   normalized_mass_18_77  1
    w_18_15   normalized_ratio_18_78  -2.1428571428571428e+00
    w_18_15   full_original_Gini_252  -1.6642857142857139e+01
    rho_18    normalized_ratio_18_78  1
    rho_18    block_pair_pos_205  1
    rho_18    block_pair_neg_206  -1
    rho_18    block_pair_pos_223  1
    rho_18    block_pair_neg_224  -1
    rho_18    block_pair_pos_241  -1
    rho_18    block_pair_neg_242  1
    rho_18    block_pair_pos_243  -1
    rho_18    block_pair_neg_244  1
    rho_18    block_pair_pos_245  -1
    rho_18    block_pair_neg_246  1
    rho_18    block_pair_pos_247  -1
    rho_18    block_pair_neg_248  1
    rho_18    block_pair_pos_249  -1
    rho_18    block_pair_neg_250  1
    rho_18    normalization_251  1
    MARKER    'MARKER'                 'INTORG'
    x_7_0     OBJ       1.9561824064893318e-02
    x_7_0     product_lb_79  -4.3731019522732839e-02
    x_7_0     product_ub_80  -1.1023622047255120e-01
    x_7_0     onehot_7_101  1
    x_7_0     parent_nonstrict_scope_194  3.9123648129786637e-02
    x_7_0     unique_nonzero_owner_285  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_0     product_lb_79  1
    w_7_0     product_ub_80  1
    w_7_0     normalized_mass_7_102  1
    w_7_0     full_original_Gini_252  -9.0714285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_1     OBJ       1.1737094438935995e-02
    x_7_1     product_lb_81  -4.3731019522732839e-02
    x_7_1     product_ub_82  -1.1023622047255120e-01
    x_7_1     onehot_7_101  1
    x_7_1     stock_lb_192  1
    x_7_1     stock_ub_193  1
    x_7_1     parent_nonstrict_scope_194  3.1298918503829314e-02
    MARKER    'MARKER'                 'INTEND'
    w_7_1     product_lb_81  1
    w_7_1     product_ub_82  1
    w_7_1     normalized_mass_7_102  1
    w_7_1     normalized_ratio_7_103  -0.2
    w_7_1     full_original_Gini_252  -7.8714285714285710e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_2     OBJ       3.9123648129786616e-03
    x_7_2     product_lb_83  -4.3731019522732839e-02
    x_7_2     product_ub_84  -1.1023622047255120e-01
    x_7_2     onehot_7_101  1
    x_7_2     stock_lb_192  2
    x_7_2     stock_ub_193  2
    x_7_2     parent_nonstrict_scope_194  2.3474188877871980e-02
    x_7_2     unique_nonzero_owner_286  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_2     product_lb_83  1
    w_7_2     product_ub_84  1
    w_7_2     normalized_mass_7_102  1
    w_7_2     normalized_ratio_7_103  -0.4
    w_7_2     full_original_Gini_252  -6.6714285714285726e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_3     OBJ       -3.9123648129786685e-03
    x_7_3     product_lb_85  -4.3731019522732839e-02
    x_7_3     product_ub_86  -1.1023622047255120e-01
    x_7_3     onehot_7_101  1
    x_7_3     stock_lb_192  3
    x_7_3     stock_ub_193  3
    x_7_3     parent_nonstrict_scope_194  1.5649459251914650e-02
    x_7_3     unique_nonzero_owner_287  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_3     product_lb_85  1
    w_7_3     product_ub_86  1
    w_7_3     normalized_mass_7_102  1
    w_7_3     normalized_ratio_7_103  -6.0000000000000009e-01
    w_7_3     full_original_Gini_252  -5.8142857142857149e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_4     OBJ       -1.1737094438935993e-02
    x_7_4     product_lb_87  -4.3731019522732839e-02
    x_7_4     product_ub_88  -1.1023622047255120e-01
    x_7_4     onehot_7_101  1
    x_7_4     stock_lb_192  4
    x_7_4     stock_ub_193  4
    x_7_4     parent_nonstrict_scope_194  7.8247296259573249e-03
    x_7_4     unique_nonzero_owner_288  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_4     product_lb_87  1
    w_7_4     product_ub_88  1
    w_7_4     normalized_mass_7_102  1
    w_7_4     normalized_ratio_7_103  -0.8
    w_7_4     full_original_Gini_252  -5.0142857142857142e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_5     OBJ       -1.9561824064893318e-02
    x_7_5     product_lb_89  -4.3731019522732839e-02
    x_7_5     product_ub_90  -1.1023622047255120e-01
    x_7_5     onehot_7_101  1
    x_7_5     stock_lb_192  5
    x_7_5     stock_ub_193  5
    x_7_5     unique_nonzero_owner_289  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_5     product_lb_89  1
    w_7_5     product_ub_90  1
    w_7_5     normalized_mass_7_102  1
    w_7_5     normalized_ratio_7_103  -1
    w_7_5     full_original_Gini_252  -4.2142857142857144e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_6     OBJ       -1.1737094438935985e-02
    x_7_6     product_lb_91  -4.3731019522732839e-02
    x_7_6     product_ub_92  -1.1023622047255120e-01
    x_7_6     onehot_7_101  1
    x_7_6     stock_lb_192  6
    x_7_6     stock_ub_193  6
    x_7_6     parent_nonstrict_scope_194  7.8247296259573336e-03
    x_7_6     unique_nonzero_owner_290  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_6     product_lb_91  1
    w_7_6     product_ub_92  1
    w_7_6     normalized_mass_7_102  1
    w_7_6     normalized_ratio_7_103  -1.2000000000000002e+00
    w_7_6     full_original_Gini_252  -5.92857142857143
    MARKER    'MARKER'                 'INTORG'
    x_7_7     OBJ       -3.9123648129786581e-03
    x_7_7     product_lb_93  -4.3731019522732839e-02
    x_7_7     product_ub_94  -1.1023622047255120e-01
    x_7_7     onehot_7_101  1
    x_7_7     stock_lb_192  7
    x_7_7     stock_ub_193  7
    x_7_7     parent_nonstrict_scope_194  1.5649459251914660e-02
    x_7_7     unique_nonzero_owner_291  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_7     product_lb_93  1
    w_7_7     product_ub_94  1
    w_7_7     normalized_mass_7_102  1
    w_7_7     normalized_ratio_7_103  -1.4000000000000001e+00
    w_7_7     full_original_Gini_252  -7.9285714285714306e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_8     OBJ       3.9123648129786685e-03
    x_7_8     product_lb_95  -4.3731019522732839e-02
    x_7_8     product_ub_96  -1.1023622047255120e-01
    x_7_8     onehot_7_101  1
    x_7_8     stock_lb_192  8
    x_7_8     stock_ub_193  8
    x_7_8     parent_nonstrict_scope_194  2.3474188877871987e-02
    x_7_8     unique_nonzero_owner_292  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_8     product_lb_95  1
    w_7_8     product_ub_96  1
    w_7_8     normalized_mass_7_102  1
    w_7_8     normalized_ratio_7_103  -1.6
    w_7_8     full_original_Gini_252  -1.0128571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_9     OBJ       1.1737094438935995e-02
    x_7_9     product_lb_97  -4.3731019522732839e-02
    x_7_9     product_ub_98  -1.1023622047255120e-01
    x_7_9     onehot_7_101  1
    x_7_9     stock_lb_192  9
    x_7_9     stock_ub_193  9
    x_7_9     parent_nonstrict_scope_194  3.1298918503829314e-02
    x_7_9     unique_nonzero_owner_293  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_9     product_lb_97  1
    w_7_9     product_ub_98  1
    w_7_9     normalized_mass_7_102  1
    w_7_9     normalized_ratio_7_103  -1.8
    w_7_9     full_original_Gini_252  -1.2528571428571430e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_10    OBJ       1.9561824064893318e-02
    x_7_10    product_lb_99  -4.3731019522732839e-02
    x_7_10    product_ub_100  -1.1023622047255120e-01
    x_7_10    onehot_7_101  1
    x_7_10    stock_lb_192  10
    x_7_10    stock_ub_193  10
    x_7_10    parent_nonstrict_scope_194  3.9123648129786637e-02
    x_7_10    unique_nonzero_owner_294  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_10    product_lb_99  1
    w_7_10    product_ub_100  1
    w_7_10    normalized_mass_7_102  1
    w_7_10    normalized_ratio_7_103  -2
    w_7_10    full_original_Gini_252  -1.4928571428571429e+01
    rho_7     normalized_ratio_7_103  1
    rho_7     block_pair_pos_199  1
    rho_7     block_pair_neg_200  -1
    rho_7     block_pair_pos_217  1
    rho_7     block_pair_neg_218  -1
    rho_7     block_pair_pos_225  -1
    rho_7     block_pair_neg_226  1
    rho_7     block_pair_pos_227  -1
    rho_7     block_pair_neg_228  1
    rho_7     block_pair_pos_229  -1
    rho_7     block_pair_neg_230  1
    rho_7     block_pair_pos_231  -1
    rho_7     block_pair_neg_232  1
    rho_7     block_pair_pos_245  1
    rho_7     block_pair_neg_246  -1
    rho_7     normalization_251  1
    MARKER    'MARKER'                 'INTORG'
    x_17_0    OBJ       6.3380304899829959e-02
    x_17_0    product_lb_104  -4.3731019522732839e-02
    x_17_0    product_ub_105  -1.1023622047255120e-01
    x_17_0    onehot_17_138  1
    x_17_0    parent_nonstrict_scope_194  1.2676060979965992e-01
    x_17_0    unique_nonzero_owner_295  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_0    product_lb_104  1
    w_17_0    product_ub_105  1
    w_17_0    normalized_mass_17_139  1
    w_17_0    full_original_Gini_252  -9.0714285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_1    OBJ       4.9295792699867738e-02
    x_17_1    product_lb_106  -4.3731019522732839e-02
    x_17_1    product_ub_107  -1.1023622047255120e-01
    x_17_1    onehot_17_138  1
    x_17_1    stock_lb_192  1
    x_17_1    stock_ub_193  1
    x_17_1    parent_nonstrict_scope_194  1.1267609759969770e-01
    x_17_1    unique_nonzero_owner_296  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_1    product_lb_106  1
    w_17_1    product_ub_107  1
    w_17_1    normalized_mass_17_139  1
    w_17_1    normalized_ratio_17_140  -1.1111111111111110e-01
    w_17_1    full_original_Gini_252  -8.4047619047619051e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_2    OBJ       3.5211280499905531e-02
    x_17_2    product_lb_108  -4.3731019522732839e-02
    x_17_2    product_ub_109  -1.1023622047255120e-01
    x_17_2    onehot_17_138  1
    x_17_2    stock_lb_192  2
    x_17_2    stock_ub_193  2
    x_17_2    parent_nonstrict_scope_194  9.8591585399735490e-02
    x_17_2    unique_nonzero_owner_297  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_2    product_lb_108  1
    w_17_2    product_ub_109  1
    w_17_2    normalized_mass_17_139  1
    w_17_2    normalized_ratio_17_140  -2.2222222222222221e-01
    w_17_2    full_original_Gini_252  -7.7380952380952381e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_3    OBJ       2.1126768299943324e-02
    x_17_3    product_lb_110  -4.3731019522732839e-02
    x_17_3    product_ub_111  -1.1023622047255120e-01
    x_17_3    onehot_17_138  1
    x_17_3    stock_lb_192  3
    x_17_3    stock_ub_193  3
    x_17_3    parent_nonstrict_scope_194  8.4507073199773283e-02
    MARKER    'MARKER'                 'INTEND'
    w_17_3    product_lb_110  1
    w_17_3    product_ub_111  1
    w_17_3    normalized_mass_17_139  1
    w_17_3    normalized_ratio_17_140  -3.3333333333333331e-01
    w_17_3    full_original_Gini_252  -7.0714285714285721e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_4    OBJ       7.0422560999811035e-03
    x_17_4    product_lb_112  -4.3731019522732839e-02
    x_17_4    product_ub_113  -1.1023622047255120e-01
    x_17_4    onehot_17_138  1
    x_17_4    stock_lb_192  4
    x_17_4    stock_ub_193  4
    x_17_4    parent_nonstrict_scope_194  7.0422560999811062e-02
    x_17_4    unique_nonzero_owner_298  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_4    product_lb_112  1
    w_17_4    product_ub_113  1
    w_17_4    normalized_mass_17_139  1
    w_17_4    normalized_ratio_17_140  -4.4444444444444442e-01
    w_17_4    full_original_Gini_252  -6.4365079365079358e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_5    OBJ       -0.00704225609998111
    x_17_5    product_lb_114  -4.3731019522732839e-02
    x_17_5    product_ub_115  -1.1023622047255120e-01
    x_17_5    onehot_17_138  1
    x_17_5    stock_lb_192  5
    x_17_5    stock_ub_193  5
    x_17_5    parent_nonstrict_scope_194  5.6338048799848849e-02
    x_17_5    unique_nonzero_owner_299  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_5    product_lb_114  1
    w_17_5    product_ub_115  1
    w_17_5    normalized_mass_17_139  1
    w_17_5    normalized_ratio_17_140  -5.5555555555555558e-01
    w_17_5    full_original_Gini_252  -5.9920634920634921e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_6    OBJ       -2.1126768299943317e-02
    x_17_6    product_lb_116  -4.3731019522732839e-02
    x_17_6    product_ub_117  -1.1023622047255120e-01
    x_17_6    onehot_17_138  1
    x_17_6    stock_lb_192  6
    x_17_6    stock_ub_193  6
    x_17_6    parent_nonstrict_scope_194  4.2253536599886642e-02
    x_17_6    unique_nonzero_owner_300  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_6    product_lb_116  1
    w_17_6    product_ub_117  1
    w_17_6    normalized_mass_17_139  1
    w_17_6    normalized_ratio_17_140  -6.6666666666666663e-01
    w_17_6    full_original_Gini_252  -5.5476190476190483e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_7    OBJ       -3.5211280499905517e-02
    x_17_7    product_lb_118  -4.3731019522732839e-02
    x_17_7    product_ub_119  -1.1023622047255120e-01
    x_17_7    onehot_17_138  1
    x_17_7    stock_lb_192  7
    x_17_7    stock_ub_193  7
    x_17_7    parent_nonstrict_scope_194  2.8169024399924438e-02
    x_17_7    unique_nonzero_owner_301  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_7    product_lb_118  1
    w_17_7    product_ub_119  1
    w_17_7    normalized_mass_17_139  1
    w_17_7    normalized_ratio_17_140  -7.7777777777777768e-01
    w_17_7    full_original_Gini_252  -5.1031746031746037e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_8    OBJ       -4.9295792699867738e-02
    x_17_8    product_lb_120  -4.3731019522732839e-02
    x_17_8    product_ub_121  -1.1023622047255120e-01
    x_17_8    onehot_17_138  1
    x_17_8    stock_lb_192  8
    x_17_8    stock_ub_193  8
    x_17_8    parent_nonstrict_scope_194  1.4084512199962219e-02
    x_17_8    unique_nonzero_owner_302  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_8    product_lb_120  1
    w_17_8    product_ub_121  1
    w_17_8    normalized_mass_17_139  1
    w_17_8    normalized_ratio_17_140  -8.8888888888888884e-01
    w_17_8    full_original_Gini_252  -4.6587301587301582e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_9    OBJ       -6.3380304899829959e-02
    x_17_9    product_lb_122  -4.3731019522732839e-02
    x_17_9    product_ub_123  -1.1023622047255120e-01
    x_17_9    onehot_17_138  1
    x_17_9    stock_lb_192  9
    x_17_9    stock_ub_193  9
    x_17_9    unique_nonzero_owner_303  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_9    product_lb_122  1
    w_17_9    product_ub_123  1
    w_17_9    normalized_mass_17_139  1
    w_17_9    normalized_ratio_17_140  -1
    w_17_9    full_original_Gini_252  -4.2142857142857144e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_10   OBJ       -4.9295792699867738e-02
    x_17_10   product_lb_124  -4.3731019522732839e-02
    x_17_10   product_ub_125  -1.1023622047255120e-01
    x_17_10   onehot_17_138  1
    x_17_10   stock_lb_192  10
    x_17_10   stock_ub_193  10
    x_17_10   parent_nonstrict_scope_194  1.4084512199962219e-02
    x_17_10   unique_nonzero_owner_304  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_10   product_lb_124  1
    w_17_10   product_ub_125  1
    w_17_10   normalized_mass_17_139  1
    w_17_10   normalized_ratio_17_140  -1.1111111111111112e+00
    w_17_10   full_original_Gini_252  -5.1031746031746028e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_11   OBJ       -3.5211280499905545e-02
    x_17_11   product_lb_126  -4.3731019522732839e-02
    x_17_11   product_ub_127  -1.1023622047255120e-01
    x_17_11   onehot_17_138  1
    x_17_11   stock_lb_192  11
    x_17_11   stock_ub_193  11
    x_17_11   parent_nonstrict_scope_194  2.8169024399924410e-02
    x_17_11   unique_nonzero_owner_305  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_11   product_lb_126  1
    w_17_11   product_ub_127  1
    w_17_11   normalized_mass_17_139  1
    w_17_11   normalized_ratio_17_140  -1.2222222222222221e+00
    w_17_11   full_original_Gini_252  -6.15079365079365
    MARKER    'MARKER'                 'INTORG'
    x_17_12   OBJ       -2.1126768299943331e-02
    x_17_12   product_lb_128  -4.3731019522732839e-02
    x_17_12   product_ub_129  -1.1023622047255120e-01
    x_17_12   onehot_17_138  1
    x_17_12   stock_lb_192  12
    x_17_12   stock_ub_193  12
    x_17_12   parent_nonstrict_scope_194  4.2253536599886628e-02
    x_17_12   unique_nonzero_owner_306  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_12   product_lb_128  1
    w_17_12   product_ub_129  1
    w_17_12   normalized_mass_17_139  1
    w_17_12   normalized_ratio_17_140  -1.3333333333333333e+00
    w_17_12   full_original_Gini_252  -7.26190476190476
    MARKER    'MARKER'                 'INTORG'
    x_17_13   OBJ       -0.00704225609998111
    x_17_13   product_lb_130  -4.3731019522732839e-02
    x_17_13   product_ub_131  -1.1023622047255120e-01
    x_17_13   onehot_17_138  1
    x_17_13   stock_lb_192  13
    x_17_13   stock_ub_193  13
    x_17_13   parent_nonstrict_scope_194  5.6338048799848849e-02
    x_17_13   unique_nonzero_owner_307  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_13   product_lb_130  1
    w_17_13   product_ub_131  1
    w_17_13   normalized_mass_17_139  1
    w_17_13   normalized_ratio_17_140  -1.4444444444444444e+00
    w_17_13   full_original_Gini_252  -8.3730158730158735e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_14   OBJ       7.0422560999810757e-03
    x_17_14   product_lb_132  -4.3731019522732839e-02
    x_17_14   product_ub_133  -1.1023622047255120e-01
    x_17_14   onehot_17_138  1
    x_17_14   stock_lb_192  14
    x_17_14   stock_ub_193  14
    x_17_14   parent_nonstrict_scope_194  7.0422560999811035e-02
    x_17_14   unique_nonzero_owner_308  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_14   product_lb_132  1
    w_17_14   product_ub_133  1
    w_17_14   normalized_mass_17_139  1
    w_17_14   normalized_ratio_17_140  -1.5555555555555554e+00
    w_17_14   full_original_Gini_252  -9.5952380952380931e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_15   OBJ       2.1126768299943297e-02
    x_17_15   product_lb_134  -4.3731019522732839e-02
    x_17_15   product_ub_135  -1.1023622047255120e-01
    x_17_15   onehot_17_138  1
    x_17_15   stock_lb_192  15
    x_17_15   stock_ub_193  15
    x_17_15   parent_nonstrict_scope_194  8.4507073199773255e-02
    x_17_15   unique_nonzero_owner_309  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_15   product_lb_134  1
    w_17_15   product_ub_135  1
    w_17_15   normalized_mass_17_139  1
    w_17_15   normalized_ratio_17_140  -1.6666666666666665e+00
    w_17_15   full_original_Gini_252  -1.0928571428571423e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_16   OBJ       3.5211280499905517e-02
    x_17_16   product_lb_136  -4.3731019522732839e-02
    x_17_16   product_ub_137  -1.1023622047255120e-01
    x_17_16   onehot_17_138  1
    x_17_16   stock_lb_192  16
    x_17_16   stock_ub_193  16
    x_17_16   parent_nonstrict_scope_194  9.8591585399735476e-02
    x_17_16   unique_nonzero_owner_310  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_16   product_lb_136  1
    w_17_16   product_ub_137  1
    w_17_16   normalized_mass_17_139  1
    w_17_16   normalized_ratio_17_140  -1.7777777777777777e+00
    w_17_16   full_original_Gini_252  -1.2261904761904763e+01
    rho_17    normalized_ratio_17_140  1
    rho_17    block_pair_pos_203  1
    rho_17    block_pair_neg_204  -1
    rho_17    block_pair_pos_221  1
    rho_17    block_pair_neg_222  -1
    rho_17    block_pair_pos_231  1
    rho_17    block_pair_neg_232  -1
    rho_17    block_pair_pos_235  -1
    rho_17    block_pair_neg_236  1
    rho_17    block_pair_pos_237  -1
    rho_17    block_pair_neg_238  1
    rho_17    block_pair_pos_239  -1
    rho_17    block_pair_neg_240  1
    rho_17    block_pair_pos_249  1
    rho_17    block_pair_neg_250  -1
    rho_17    normalization_251  1
    MARKER    'MARKER'                 'INTORG'
    x_5_0     OBJ       6.3380304899829966e-03
    x_5_0     product_lb_141  -4.3731019522732839e-02
    x_5_0     product_ub_142  -1.1023622047255120e-01
    x_5_0     onehot_5_147  1
    x_5_0     parent_nonstrict_scope_194  1.2676060979965993e-02
    MARKER    'MARKER'                 'INTEND'
    w_5_0     product_lb_141  1
    w_5_0     product_ub_142  1
    w_5_0     normalized_mass_5_148  1
    w_5_0     full_original_Gini_252  -9.0714285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_5_1     OBJ       -6.3380304899829966e-03
    x_5_1     product_lb_143  -4.3731019522732839e-02
    x_5_1     product_ub_144  -1.1023622047255120e-01
    x_5_1     onehot_5_147  1
    x_5_1     stock_lb_192  1
    x_5_1     stock_ub_193  1
    x_5_1     unique_nonzero_owner_311  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_1     product_lb_143  1
    w_5_1     product_ub_144  1
    w_5_1     normalized_mass_5_148  1
    w_5_1     normalized_ratio_5_149  -1
    w_5_1     full_original_Gini_252  -4.2142857142857144e+00
    MARKER    'MARKER'                 'INTORG'
    x_5_2     OBJ       6.3380304899829966e-03
    x_5_2     product_lb_145  -4.3731019522732839e-02
    x_5_2     product_ub_146  -1.1023622047255120e-01
    x_5_2     onehot_5_147  1
    x_5_2     stock_lb_192  2
    x_5_2     stock_ub_193  2
    x_5_2     parent_nonstrict_scope_194  1.2676060979965993e-02
    x_5_2     unique_nonzero_owner_312  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_2     product_lb_145  1
    w_5_2     product_ub_146  1
    w_5_2     normalized_mass_5_148  1
    w_5_2     normalized_ratio_5_149  -2
    w_5_2     full_original_Gini_252  -1.4928571428571429e+01
    rho_5     normalized_ratio_5_149  1
    rho_5     block_pair_pos_197  1
    rho_5     block_pair_neg_198  -1
    rho_5     block_pair_pos_207  -1
    rho_5     block_pair_neg_208  1
    rho_5     block_pair_pos_209  -1
    rho_5     block_pair_neg_210  1
    rho_5     block_pair_pos_215  1
    rho_5     block_pair_neg_216  -1
    rho_5     block_pair_pos_227  1
    rho_5     block_pair_neg_228  -1
    rho_5     block_pair_pos_237  1
    rho_5     block_pair_neg_238  -1
    rho_5     block_pair_pos_243  1
    rho_5     block_pair_neg_244  -1
    rho_5     normalization_251  1
    MARKER    'MARKER'                 'INTORG'
    x_11_0    OBJ       5.0078236648368350e-02
    x_11_0    product_lb_150  -4.3731019522732839e-02
    x_11_0    product_ub_151  -1.1023622047255120e-01
    x_11_0    onehot_11_182  1
    x_11_0    parent_nonstrict_scope_194  1.0015647329673670e-01
    x_11_0    unique_nonzero_owner_313  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_0    product_lb_150  1
    w_11_0    product_ub_151  1
    w_11_0    normalized_mass_11_183  1
    w_11_0    full_original_Gini_252  -9.0714285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_1    OBJ       3.7558677486276261e-02
    x_11_1    product_lb_152  -4.3731019522732839e-02
    x_11_1    product_ub_153  -1.1023622047255120e-01
    x_11_1    onehot_11_182  1
    x_11_1    stock_lb_192  1
    x_11_1    stock_ub_193  1
    x_11_1    parent_nonstrict_scope_194  8.7636914134644611e-02
    MARKER    'MARKER'                 'INTEND'
    w_11_1    product_lb_152  1
    w_11_1    product_ub_153  1
    w_11_1    normalized_mass_11_183  1
    w_11_1    normalized_ratio_11_184  -0.125
    w_11_1    full_original_Gini_252  -8.3214285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_2    OBJ       2.5039118324184172e-02
    x_11_2    product_lb_154  -4.3731019522732839e-02
    x_11_2    product_ub_155  -1.1023622047255120e-01
    x_11_2    onehot_11_182  1
    x_11_2    stock_lb_192  2
    x_11_2    stock_ub_193  2
    x_11_2    parent_nonstrict_scope_194  7.5117354972552522e-02
    x_11_2    unique_nonzero_owner_314  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_2    product_lb_154  1
    w_11_2    product_ub_155  1
    w_11_2    normalized_mass_11_183  1
    w_11_2    normalized_ratio_11_184  -0.25
    w_11_2    full_original_Gini_252  -7.5714285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_3    OBJ       1.2519559162092082e-02
    x_11_3    product_lb_156  -4.3731019522732839e-02
    x_11_3    product_ub_157  -1.1023622047255120e-01
    x_11_3    onehot_11_182  1
    x_11_3    stock_lb_192  3
    x_11_3    stock_ub_193  3
    x_11_3    parent_nonstrict_scope_194  6.2597795810460433e-02
    x_11_3    unique_nonzero_owner_315  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_3    product_lb_156  1
    w_11_3    product_ub_157  1
    w_11_3    normalized_mass_11_183  1
    w_11_3    normalized_ratio_11_184  -0.375
    w_11_3    full_original_Gini_252  -6.8214285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_4    product_lb_158  -4.3731019522732839e-02
    x_11_4    product_ub_159  -1.1023622047255120e-01
    x_11_4    onehot_11_182  1
    x_11_4    stock_lb_192  4
    x_11_4    stock_ub_193  4
    x_11_4    parent_nonstrict_scope_194  5.0078236648368350e-02
    x_11_4    unique_nonzero_owner_316  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_4    product_lb_158  1
    w_11_4    product_ub_159  1
    w_11_4    normalized_mass_11_183  1
    w_11_4    normalized_ratio_11_184  -0.5
    w_11_4    full_original_Gini_252  -6.2142857142857135e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_5    OBJ       -1.2519559162092089e-02
    x_11_5    product_lb_160  -4.3731019522732839e-02
    x_11_5    product_ub_161  -1.1023622047255120e-01
    x_11_5    onehot_11_182  1
    x_11_5    stock_lb_192  5
    x_11_5    stock_ub_193  5
    x_11_5    parent_nonstrict_scope_194  3.7558677486276261e-02
    x_11_5    unique_nonzero_owner_317  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_5    product_lb_160  1
    w_11_5    product_ub_161  1
    w_11_5    normalized_mass_11_183  1
    w_11_5    normalized_ratio_11_184  -0.625
    w_11_5    full_original_Gini_252  -5.7142857142857144e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_6    OBJ       -2.5039118324184175e-02
    x_11_6    product_lb_162  -4.3731019522732839e-02
    x_11_6    product_ub_163  -1.1023622047255120e-01
    x_11_6    onehot_11_182  1
    x_11_6    stock_lb_192  6
    x_11_6    stock_ub_193  6
    x_11_6    parent_nonstrict_scope_194  2.5039118324184175e-02
    x_11_6    unique_nonzero_owner_318  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_6    product_lb_162  1
    w_11_6    product_ub_163  1
    w_11_6    normalized_mass_11_183  1
    w_11_6    normalized_ratio_11_184  -0.75
    w_11_6    full_original_Gini_252  -5.2142857142857144e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_7    OBJ       -3.7558677486276261e-02
    x_11_7    product_lb_164  -4.3731019522732839e-02
    x_11_7    product_ub_165  -1.1023622047255120e-01
    x_11_7    onehot_11_182  1
    x_11_7    stock_lb_192  7
    x_11_7    stock_ub_193  7
    x_11_7    parent_nonstrict_scope_194  1.2519559162092088e-02
    x_11_7    unique_nonzero_owner_319  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_7    product_lb_164  1
    w_11_7    product_ub_165  1
    w_11_7    normalized_mass_11_183  1
    w_11_7    normalized_ratio_11_184  -0.875
    w_11_7    full_original_Gini_252  -4.7142857142857144e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_8    OBJ       -5.0078236648368350e-02
    x_11_8    product_lb_166  -4.3731019522732839e-02
    x_11_8    product_ub_167  -1.1023622047255120e-01
    x_11_8    onehot_11_182  1
    x_11_8    stock_lb_192  8
    x_11_8    stock_ub_193  8
    x_11_8    unique_nonzero_owner_320  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_8    product_lb_166  1
    w_11_8    product_ub_167  1
    w_11_8    normalized_mass_11_183  1
    w_11_8    normalized_ratio_11_184  -1
    w_11_8    full_original_Gini_252  -4.2142857142857144e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_9    OBJ       -3.7558677486276261e-02
    x_11_9    product_lb_168  -4.3731019522732839e-02
    x_11_9    product_ub_169  -1.1023622047255120e-01
    x_11_9    onehot_11_182  1
    x_11_9    stock_lb_192  9
    x_11_9    stock_ub_193  9
    x_11_9    parent_nonstrict_scope_194  1.2519559162092088e-02
    x_11_9    unique_nonzero_owner_321  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_9    product_lb_168  1
    w_11_9    product_ub_169  1
    w_11_9    normalized_mass_11_183  1
    w_11_9    normalized_ratio_11_184  -1.125
    w_11_9    full_original_Gini_252  -5.2142857142857135e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_10   OBJ       -2.5039118324184175e-02
    x_11_10   product_lb_170  -4.3731019522732839e-02
    x_11_10   product_ub_171  -1.1023622047255120e-01
    x_11_10   onehot_11_182  1
    x_11_10   stock_lb_192  10
    x_11_10   stock_ub_193  10
    x_11_10   parent_nonstrict_scope_194  2.5039118324184175e-02
    x_11_10   unique_nonzero_owner_322  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_10   product_lb_170  1
    w_11_10   product_ub_171  1
    w_11_10   normalized_mass_11_183  1
    w_11_10   normalized_ratio_11_184  -1.25
    w_11_10   full_original_Gini_252  -6.4285714285714288e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_11   OBJ       -1.2519559162092089e-02
    x_11_11   product_lb_172  -4.3731019522732839e-02
    x_11_11   product_ub_173  -1.1023622047255120e-01
    x_11_11   onehot_11_182  1
    x_11_11   stock_lb_192  11
    x_11_11   stock_ub_193  11
    x_11_11   parent_nonstrict_scope_194  3.7558677486276261e-02
    x_11_11   unique_nonzero_owner_323  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_11   product_lb_172  1
    w_11_11   product_ub_173  1
    w_11_11   normalized_mass_11_183  1
    w_11_11   normalized_ratio_11_184  -1.375
    w_11_11   full_original_Gini_252  -7.6785714285714288e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_12   product_lb_174  -4.3731019522732839e-02
    x_11_12   product_ub_175  -1.1023622047255120e-01
    x_11_12   onehot_11_182  1
    x_11_12   stock_lb_192  12
    x_11_12   stock_ub_193  12
    x_11_12   parent_nonstrict_scope_194  5.0078236648368350e-02
    x_11_12   unique_nonzero_owner_324  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_12   product_lb_174  1
    w_11_12   product_ub_175  1
    w_11_12   normalized_mass_11_183  1
    w_11_12   normalized_ratio_11_184  -1.5
    w_11_12   full_original_Gini_252  -8.9285714285714288e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_13   OBJ       1.2519559162092082e-02
    x_11_13   product_lb_176  -4.3731019522732839e-02
    x_11_13   product_ub_177  -1.1023622047255120e-01
    x_11_13   onehot_11_182  1
    x_11_13   stock_lb_192  13
    x_11_13   stock_ub_193  13
    x_11_13   parent_nonstrict_scope_194  6.2597795810460433e-02
    x_11_13   unique_nonzero_owner_325  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_13   product_lb_176  1
    w_11_13   product_ub_177  1
    w_11_13   normalized_mass_11_183  1
    w_11_13   normalized_ratio_11_184  -1.625
    w_11_13   full_original_Gini_252  -1.0428571428571429e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_14   OBJ       2.5039118324184172e-02
    x_11_14   product_lb_178  -4.3731019522732839e-02
    x_11_14   product_ub_179  -1.1023622047255120e-01
    x_11_14   onehot_11_182  1
    x_11_14   stock_lb_192  14
    x_11_14   stock_ub_193  14
    x_11_14   parent_nonstrict_scope_194  7.5117354972552522e-02
    x_11_14   unique_nonzero_owner_326  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_14   product_lb_178  1
    w_11_14   product_ub_179  1
    w_11_14   normalized_mass_11_183  1
    w_11_14   normalized_ratio_11_184  -1.75
    w_11_14   full_original_Gini_252  -1.1928571428571429e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_15   OBJ       3.7558677486276261e-02
    x_11_15   product_lb_180  -4.3731019522732839e-02
    x_11_15   product_ub_181  -1.1023622047255120e-01
    x_11_15   onehot_11_182  1
    x_11_15   stock_lb_192  15
    x_11_15   stock_ub_193  15
    x_11_15   parent_nonstrict_scope_194  8.7636914134644611e-02
    x_11_15   unique_nonzero_owner_327  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_15   product_lb_180  1
    w_11_15   product_ub_181  1
    w_11_15   normalized_mass_11_183  1
    w_11_15   normalized_ratio_11_184  -1.875
    w_11_15   full_original_Gini_252  -1.3428571428571429e+01
    rho_11    normalized_ratio_11_184  1
    rho_11    block_pair_pos_201  1
    rho_11    block_pair_neg_202  -1
    rho_11    block_pair_pos_209  1
    rho_11    block_pair_neg_210  -1
    rho_11    block_pair_pos_219  1
    rho_11    block_pair_neg_220  -1
    rho_11    block_pair_pos_229  1
    rho_11    block_pair_neg_230  -1
    rho_11    block_pair_pos_233  -1
    rho_11    block_pair_neg_234  1
    rho_11    block_pair_pos_239  1
    rho_11    block_pair_neg_240  -1
    rho_11    block_pair_pos_247  1
    rho_11    block_pair_neg_248  -1
    rho_11    normalization_251  1
    MARKER    'MARKER'                 'INTORG'
    x_2_0     OBJ       6.3380304899829966e-03
    x_2_0     product_lb_185  -4.3731019522732839e-02
    x_2_0     product_ub_186  -1.1023622047255120e-01
    x_2_0     onehot_2_189  1
    x_2_0     parent_nonstrict_scope_194  1.2676060979965993e-02
    MARKER    'MARKER'                 'INTEND'
    w_2_0     product_lb_185  1
    w_2_0     product_ub_186  1
    w_2_0     normalized_mass_2_190  1
    w_2_0     full_original_Gini_252  -9.0714285714285712e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_1     OBJ       -6.3380304899829966e-03
    x_2_1     product_lb_187  -4.3731019522732839e-02
    x_2_1     product_ub_188  -1.1023622047255120e-01
    x_2_1     onehot_2_189  1
    x_2_1     stock_lb_192  1
    x_2_1     stock_ub_193  1
    x_2_1     unique_nonzero_owner_328  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_1     product_lb_187  1
    w_2_1     product_ub_188  1
    w_2_1     normalized_mass_2_190  1
    w_2_1     normalized_ratio_2_191  -1
    w_2_1     full_original_Gini_252  -4.2142857142857144e+00
    rho_2     normalized_ratio_2_191  1
    rho_2     block_pair_pos_195  1
    rho_2     block_pair_neg_196  -1
    rho_2     block_pair_pos_207  1
    rho_2     block_pair_neg_208  -1
    rho_2     block_pair_pos_211  1
    rho_2     block_pair_neg_212  -1
    rho_2     block_pair_pos_225  1
    rho_2     block_pair_neg_226  -1
    rho_2     block_pair_pos_233  1
    rho_2     block_pair_neg_234  -1
    rho_2     block_pair_pos_235  1
    rho_2     block_pair_neg_236  -1
    rho_2     block_pair_pos_241  1
    rho_2     block_pair_neg_242  -1
    rho_2     normalization_251  1
    a_6_3     block_pair_pos_213  1
    a_6_3     block_pair_neg_214  1
    a_6_3     full_original_Gini_252  -1
    a_6_18    block_pair_pos_223  1
    a_6_18    block_pair_neg_224  1
    a_6_18    full_original_Gini_252  -1
    a_6_7     block_pair_pos_217  1
    a_6_7     block_pair_neg_218  1
    a_6_7     full_original_Gini_252  -1
    a_6_17    block_pair_pos_221  1
    a_6_17    block_pair_neg_222  1
    a_6_17    full_original_Gini_252  -1
    a_6_5     block_pair_pos_215  1
    a_6_5     block_pair_neg_216  1
    a_6_5     full_original_Gini_252  -1
    a_6_11    block_pair_pos_219  1
    a_6_11    block_pair_neg_220  1
    a_6_11    full_original_Gini_252  -1
    a_6_2     block_pair_pos_211  1
    a_6_2     block_pair_neg_212  1
    a_6_2     full_original_Gini_252  -1
    a_3_18    block_pair_pos_205  1
    a_3_18    block_pair_neg_206  1
    a_3_18    full_original_Gini_252  -1
    a_3_7     block_pair_pos_199  1
    a_3_7     block_pair_neg_200  1
    a_3_7     full_original_Gini_252  -1
    a_3_17    block_pair_pos_203  1
    a_3_17    block_pair_neg_204  1
    a_3_17    full_original_Gini_252  -1
    a_3_5     block_pair_pos_197  1
    a_3_5     block_pair_neg_198  1
    a_3_5     full_original_Gini_252  -1
    a_3_11    block_pair_pos_201  1
    a_3_11    block_pair_neg_202  1
    a_3_11    full_original_Gini_252  -1
    a_3_2     block_pair_pos_195  1
    a_3_2     block_pair_neg_196  1
    a_3_2     full_original_Gini_252  -1
    a_18_7    block_pair_pos_245  1
    a_18_7    block_pair_neg_246  1
    a_18_7    full_original_Gini_252  -1
    a_18_17   block_pair_pos_249  1
    a_18_17   block_pair_neg_250  1
    a_18_17   full_original_Gini_252  -1
    a_18_5    block_pair_pos_243  1
    a_18_5    block_pair_neg_244  1
    a_18_5    full_original_Gini_252  -1
    a_18_11   block_pair_pos_247  1
    a_18_11   block_pair_neg_248  1
    a_18_11   full_original_Gini_252  -1
    a_18_2    block_pair_pos_241  1
    a_18_2    block_pair_neg_242  1
    a_18_2    full_original_Gini_252  -1
    a_7_17    block_pair_pos_231  1
    a_7_17    block_pair_neg_232  1
    a_7_17    full_original_Gini_252  -1
    a_7_5     block_pair_pos_227  1
    a_7_5     block_pair_neg_228  1
    a_7_5     full_original_Gini_252  -1
    a_7_11    block_pair_pos_229  1
    a_7_11    block_pair_neg_230  1
    a_7_11    full_original_Gini_252  -1
    a_7_2     block_pair_pos_225  1
    a_7_2     block_pair_neg_226  1
    a_7_2     full_original_Gini_252  -1
    a_17_5    block_pair_pos_237  1
    a_17_5    block_pair_neg_238  1
    a_17_5    full_original_Gini_252  -1
    a_17_11   block_pair_pos_239  1
    a_17_11   block_pair_neg_240  1
    a_17_11   full_original_Gini_252  -1
    a_17_2    block_pair_pos_235  1
    a_17_2    block_pair_neg_236  1
    a_17_2    full_original_Gini_252  -1
    a_5_11    block_pair_pos_209  1
    a_5_11    block_pair_neg_210  1
    a_5_11    full_original_Gini_252  -1
    a_5_2     block_pair_pos_207  1
    a_5_2     block_pair_neg_208  1
    a_5_2     full_original_Gini_252  -1
    a_11_2    block_pair_pos_233  1
    a_11_2    block_pair_neg_234  1
    a_11_2    full_original_Gini_252  -1
    MARKER    'MARKER'                 'INTORG'
    service_0_6_1  unique_nonzero_owner_253  1
    service_0_6_1  service_visit_def_709  1
    service_0_6_1  free_load_conservation_710  1
    service_1_6_1  unique_nonzero_owner_253  1
    service_1_6_1  service_visit_def_979  1
    service_1_6_1  free_load_conservation_980  1
    service_0_3_0  unique_nonzero_owner_254  1
    service_0_3_0  service_visit_def_715  1
    service_0_3_0  free_load_conservation_716  -12
    service_0_3_0  original_T_including_depot_unload_757  1440
    service_0_3_1  unique_nonzero_owner_255  1
    service_0_3_1  service_visit_def_715  1
    service_0_3_1  free_load_conservation_716  -11
    service_0_3_1  original_T_including_depot_unload_757  1320
    service_0_3_2  unique_nonzero_owner_256  1
    service_0_3_2  service_visit_def_715  1
    service_0_3_2  free_load_conservation_716  -10
    service_0_3_2  original_T_including_depot_unload_757  1200
    service_0_3_3  unique_nonzero_owner_257  1
    service_0_3_3  service_visit_def_715  1
    service_0_3_3  free_load_conservation_716  -9
    service_0_3_3  original_T_including_depot_unload_757  1080
    service_0_3_4  unique_nonzero_owner_258  1
    service_0_3_4  service_visit_def_715  1
    service_0_3_4  free_load_conservation_716  -8
    service_0_3_4  original_T_including_depot_unload_757  960
    service_0_3_5  unique_nonzero_owner_259  1
    service_0_3_5  service_visit_def_715  1
    service_0_3_5  free_load_conservation_716  -7
    service_0_3_5  original_T_including_depot_unload_757  840
    service_0_3_6  unique_nonzero_owner_260  1
    service_0_3_6  service_visit_def_715  1
    service_0_3_6  free_load_conservation_716  -6
    service_0_3_6  original_T_including_depot_unload_757  720
    service_0_3_7  unique_nonzero_owner_261  1
    service_0_3_7  service_visit_def_715  1
    service_0_3_7  free_load_conservation_716  -5
    service_0_3_7  original_T_including_depot_unload_757  600
    service_0_3_8  unique_nonzero_owner_262  1
    service_0_3_8  service_visit_def_715  1
    service_0_3_8  free_load_conservation_716  -4
    service_0_3_8  original_T_including_depot_unload_757  480
    service_0_3_9  unique_nonzero_owner_263  1
    service_0_3_9  service_visit_def_715  1
    service_0_3_9  free_load_conservation_716  -3
    service_0_3_9  original_T_including_depot_unload_757  360
    service_0_3_10  unique_nonzero_owner_264  1
    service_0_3_10  service_visit_def_715  1
    service_0_3_10  free_load_conservation_716  -2
    service_0_3_10  original_T_including_depot_unload_757  240
    service_0_3_11  unique_nonzero_owner_265  1
    service_0_3_11  service_visit_def_715  1
    service_0_3_11  free_load_conservation_716  -1
    service_0_3_11  original_T_including_depot_unload_757  120
    service_0_3_13  unique_nonzero_owner_266  1
    service_0_3_13  service_visit_def_715  1
    service_0_3_13  free_load_conservation_716  1
    service_0_3_14  unique_nonzero_owner_267  1
    service_0_3_14  service_visit_def_715  1
    service_0_3_14  free_load_conservation_716  2
    service_0_3_15  unique_nonzero_owner_268  1
    service_0_3_15  service_visit_def_715  1
    service_0_3_15  free_load_conservation_716  3
    service_0_3_16  unique_nonzero_owner_269  1
    service_0_3_16  service_visit_def_715  1
    service_0_3_16  free_load_conservation_716  4
    service_1_3_0  unique_nonzero_owner_254  1
    service_1_3_0  service_visit_def_985  1
    service_1_3_0  free_load_conservation_986  -12
    service_1_3_0  original_T_including_depot_unload_1024  1440
    service_1_3_1  unique_nonzero_owner_255  1
    service_1_3_1  service_visit_def_985  1
    service_1_3_1  free_load_conservation_986  -11
    service_1_3_1  original_T_including_depot_unload_1024  1320
    service_1_3_2  unique_nonzero_owner_256  1
    service_1_3_2  service_visit_def_985  1
    service_1_3_2  free_load_conservation_986  -10
    service_1_3_2  original_T_including_depot_unload_1024  1200
    service_1_3_3  unique_nonzero_owner_257  1
    service_1_3_3  service_visit_def_985  1
    service_1_3_3  free_load_conservation_986  -9
    service_1_3_3  original_T_including_depot_unload_1024  1080
    service_1_3_4  unique_nonzero_owner_258  1
    service_1_3_4  service_visit_def_985  1
    service_1_3_4  free_load_conservation_986  -8
    service_1_3_4  original_T_including_depot_unload_1024  960
    service_1_3_5  unique_nonzero_owner_259  1
    service_1_3_5  service_visit_def_985  1
    service_1_3_5  free_load_conservation_986  -7
    service_1_3_5  original_T_including_depot_unload_1024  840
    service_1_3_6  unique_nonzero_owner_260  1
    service_1_3_6  service_visit_def_985  1
    service_1_3_6  free_load_conservation_986  -6
    service_1_3_6  original_T_including_depot_unload_1024  720
    service_1_3_7  unique_nonzero_owner_261  1
    service_1_3_7  service_visit_def_985  1
    service_1_3_7  free_load_conservation_986  -5
    service_1_3_7  original_T_including_depot_unload_1024  600
    service_1_3_8  unique_nonzero_owner_262  1
    service_1_3_8  service_visit_def_985  1
    service_1_3_8  free_load_conservation_986  -4
    service_1_3_8  original_T_including_depot_unload_1024  480
    service_1_3_9  unique_nonzero_owner_263  1
    service_1_3_9  service_visit_def_985  1
    service_1_3_9  free_load_conservation_986  -3
    service_1_3_9  original_T_including_depot_unload_1024  360
    service_1_3_10  unique_nonzero_owner_264  1
    service_1_3_10  service_visit_def_985  1
    service_1_3_10  free_load_conservation_986  -2
    service_1_3_10  original_T_including_depot_unload_1024  240
    service_1_3_11  unique_nonzero_owner_265  1
    service_1_3_11  service_visit_def_985  1
    service_1_3_11  free_load_conservation_986  -1
    service_1_3_11  original_T_including_depot_unload_1024  120
    service_1_3_13  unique_nonzero_owner_266  1
    service_1_3_13  service_visit_def_985  1
    service_1_3_13  free_load_conservation_986  1
    service_1_3_14  unique_nonzero_owner_267  1
    service_1_3_14  service_visit_def_985  1
    service_1_3_14  free_load_conservation_986  2
    service_1_3_15  unique_nonzero_owner_268  1
    service_1_3_15  service_visit_def_985  1
    service_1_3_15  free_load_conservation_986  3
    service_1_3_16  unique_nonzero_owner_269  1
    service_1_3_16  service_visit_def_985  1
    service_1_3_16  free_load_conservation_986  4
    service_0_18_1  unique_nonzero_owner_270  1
    service_0_18_1  service_visit_def_721  1
    service_0_18_1  free_load_conservation_722  1
    service_0_18_2  unique_nonzero_owner_271  1
    service_0_18_2  service_visit_def_721  1
    service_0_18_2  free_load_conservation_722  2
    service_0_18_3  unique_nonzero_owner_272  1
    service_0_18_3  service_visit_def_721  1
    service_0_18_3  free_load_conservation_722  3
    service_0_18_4  unique_nonzero_owner_273  1
    service_0_18_4  service_visit_def_721  1
    service_0_18_4  free_load_conservation_722  4
    service_0_18_5  unique_nonzero_owner_274  1
    service_0_18_5  service_visit_def_721  1
    service_0_18_5  free_load_conservation_722  5
    service_0_18_6  unique_nonzero_owner_275  1
    service_0_18_6  service_visit_def_721  1
    service_0_18_6  free_load_conservation_722  6
    service_0_18_7  unique_nonzero_owner_276  1
    service_0_18_7  service_visit_def_721  1
    service_0_18_7  free_load_conservation_722  7
    service_0_18_8  unique_nonzero_owner_277  1
    service_0_18_8  service_visit_def_721  1
    service_0_18_8  free_load_conservation_722  8
    service_0_18_9  unique_nonzero_owner_278  1
    service_0_18_9  service_visit_def_721  1
    service_0_18_9  free_load_conservation_722  9
    service_0_18_10  unique_nonzero_owner_279  1
    service_0_18_10  service_visit_def_721  1
    service_0_18_10  free_load_conservation_722  10
    service_0_18_11  unique_nonzero_owner_280  1
    service_0_18_11  service_visit_def_721  1
    service_0_18_11  free_load_conservation_722  11
    service_0_18_12  unique_nonzero_owner_281  1
    service_0_18_12  service_visit_def_721  1
    service_0_18_12  free_load_conservation_722  12
    service_0_18_13  unique_nonzero_owner_282  1
    service_0_18_13  service_visit_def_721  1
    service_0_18_13  free_load_conservation_722  13
    service_0_18_14  unique_nonzero_owner_283  1
    service_0_18_14  service_visit_def_721  1
    service_0_18_14  free_load_conservation_722  14
    service_0_18_15  unique_nonzero_owner_284  1
    service_0_18_15  service_visit_def_721  1
    service_0_18_15  free_load_conservation_722  15
    service_1_18_1  unique_nonzero_owner_270  1
    service_1_18_1  service_visit_def_991  1
    service_1_18_1  free_load_conservation_992  1
    service_1_18_2  unique_nonzero_owner_271  1
    service_1_18_2  service_visit_def_991  1
    service_1_18_2  free_load_conservation_992  2
    service_1_18_3  unique_nonzero_owner_272  1
    service_1_18_3  service_visit_def_991  1
    service_1_18_3  free_load_conservation_992  3
    service_1_18_4  unique_nonzero_owner_273  1
    service_1_18_4  service_visit_def_991  1
    service_1_18_4  free_load_conservation_992  4
    service_1_18_5  unique_nonzero_owner_274  1
    service_1_18_5  service_visit_def_991  1
    service_1_18_5  free_load_conservation_992  5
    service_1_18_6  unique_nonzero_owner_275  1
    service_1_18_6  service_visit_def_991  1
    service_1_18_6  free_load_conservation_992  6
    service_1_18_7  unique_nonzero_owner_276  1
    service_1_18_7  service_visit_def_991  1
    service_1_18_7  free_load_conservation_992  7
    service_1_18_8  unique_nonzero_owner_277  1
    service_1_18_8  service_visit_def_991  1
    service_1_18_8  free_load_conservation_992  8
    service_1_18_9  unique_nonzero_owner_278  1
    service_1_18_9  service_visit_def_991  1
    service_1_18_9  free_load_conservation_992  9
    service_1_18_10  unique_nonzero_owner_279  1
    service_1_18_10  service_visit_def_991  1
    service_1_18_10  free_load_conservation_992  10
    service_1_18_11  unique_nonzero_owner_280  1
    service_1_18_11  service_visit_def_991  1
    service_1_18_11  free_load_conservation_992  11
    service_1_18_12  unique_nonzero_owner_281  1
    service_1_18_12  service_visit_def_991  1
    service_1_18_12  free_load_conservation_992  12
    service_1_18_13  unique_nonzero_owner_282  1
    service_1_18_13  service_visit_def_991  1
    service_1_18_13  free_load_conservation_992  13
    service_1_18_14  unique_nonzero_owner_283  1
    service_1_18_14  service_visit_def_991  1
    service_1_18_14  free_load_conservation_992  14
    service_1_18_15  unique_nonzero_owner_284  1
    service_1_18_15  service_visit_def_991  1
    service_1_18_15  free_load_conservation_992  15
    service_0_7_0  unique_nonzero_owner_285  1
    service_0_7_0  service_visit_def_727  1
    service_0_7_0  free_load_conservation_728  -1
    service_0_7_0  original_T_including_depot_unload_757  120
    service_0_7_2  unique_nonzero_owner_286  1
    service_0_7_2  service_visit_def_727  1
    service_0_7_2  free_load_conservation_728  1
    service_0_7_3  unique_nonzero_owner_287  1
    service_0_7_3  service_visit_def_727  1
    service_0_7_3  free_load_conservation_728  2
    service_0_7_4  unique_nonzero_owner_288  1
    service_0_7_4  service_visit_def_727  1
    service_0_7_4  free_load_conservation_728  3
    service_0_7_5  unique_nonzero_owner_289  1
    service_0_7_5  service_visit_def_727  1
    service_0_7_5  free_load_conservation_728  4
    service_0_7_6  unique_nonzero_owner_290  1
    service_0_7_6  service_visit_def_727  1
    service_0_7_6  free_load_conservation_728  5
    service_0_7_7  unique_nonzero_owner_291  1
    service_0_7_7  service_visit_def_727  1
    service_0_7_7  free_load_conservation_728  6
    service_0_7_8  unique_nonzero_owner_292  1
    service_0_7_8  service_visit_def_727  1
    service_0_7_8  free_load_conservation_728  7
    service_0_7_9  unique_nonzero_owner_293  1
    service_0_7_9  service_visit_def_727  1
    service_0_7_9  free_load_conservation_728  8
    service_0_7_10  unique_nonzero_owner_294  1
    service_0_7_10  service_visit_def_727  1
    service_0_7_10  free_load_conservation_728  9
    service_1_7_0  unique_nonzero_owner_285  1
    service_1_7_0  service_visit_def_997  1
    service_1_7_0  free_load_conservation_998  -1
    service_1_7_0  original_T_including_depot_unload_1024  120
    service_1_7_2  unique_nonzero_owner_286  1
    service_1_7_2  service_visit_def_997  1
    service_1_7_2  free_load_conservation_998  1
    service_1_7_3  unique_nonzero_owner_287  1
    service_1_7_3  service_visit_def_997  1
    service_1_7_3  free_load_conservation_998  2
    service_1_7_4  unique_nonzero_owner_288  1
    service_1_7_4  service_visit_def_997  1
    service_1_7_4  free_load_conservation_998  3
    service_1_7_5  unique_nonzero_owner_289  1
    service_1_7_5  service_visit_def_997  1
    service_1_7_5  free_load_conservation_998  4
    service_1_7_6  unique_nonzero_owner_290  1
    service_1_7_6  service_visit_def_997  1
    service_1_7_6  free_load_conservation_998  5
    service_1_7_7  unique_nonzero_owner_291  1
    service_1_7_7  service_visit_def_997  1
    service_1_7_7  free_load_conservation_998  6
    service_1_7_8  unique_nonzero_owner_292  1
    service_1_7_8  service_visit_def_997  1
    service_1_7_8  free_load_conservation_998  7
    service_1_7_9  unique_nonzero_owner_293  1
    service_1_7_9  service_visit_def_997  1
    service_1_7_9  free_load_conservation_998  8
    service_1_7_10  unique_nonzero_owner_294  1
    service_1_7_10  service_visit_def_997  1
    service_1_7_10  free_load_conservation_998  9
    service_0_17_0  unique_nonzero_owner_295  1
    service_0_17_0  service_visit_def_733  1
    service_0_17_0  free_load_conservation_734  -3
    service_0_17_0  original_T_including_depot_unload_757  360
    service_0_17_1  unique_nonzero_owner_296  1
    service_0_17_1  service_visit_def_733  1
    service_0_17_1  free_load_conservation_734  -2
    service_0_17_1  original_T_including_depot_unload_757  240
    service_0_17_2  unique_nonzero_owner_297  1
    service_0_17_2  service_visit_def_733  1
    service_0_17_2  free_load_conservation_734  -1
    service_0_17_2  original_T_including_depot_unload_757  120
    service_0_17_4  unique_nonzero_owner_298  1
    service_0_17_4  service_visit_def_733  1
    service_0_17_4  free_load_conservation_734  1
    service_0_17_5  unique_nonzero_owner_299  1
    service_0_17_5  service_visit_def_733  1
    service_0_17_5  free_load_conservation_734  2
    service_0_17_6  unique_nonzero_owner_300  1
    service_0_17_6  service_visit_def_733  1
    service_0_17_6  free_load_conservation_734  3
    service_0_17_7  unique_nonzero_owner_301  1
    service_0_17_7  service_visit_def_733  1
    service_0_17_7  free_load_conservation_734  4
    service_0_17_8  unique_nonzero_owner_302  1
    service_0_17_8  service_visit_def_733  1
    service_0_17_8  free_load_conservation_734  5
    service_0_17_9  unique_nonzero_owner_303  1
    service_0_17_9  service_visit_def_733  1
    service_0_17_9  free_load_conservation_734  6
    service_0_17_10  unique_nonzero_owner_304  1
    service_0_17_10  service_visit_def_733  1
    service_0_17_10  free_load_conservation_734  7
    service_0_17_11  unique_nonzero_owner_305  1
    service_0_17_11  service_visit_def_733  1
    service_0_17_11  free_load_conservation_734  8
    service_0_17_12  unique_nonzero_owner_306  1
    service_0_17_12  service_visit_def_733  1
    service_0_17_12  free_load_conservation_734  9
    service_0_17_13  unique_nonzero_owner_307  1
    service_0_17_13  service_visit_def_733  1
    service_0_17_13  free_load_conservation_734  10
    service_0_17_14  unique_nonzero_owner_308  1
    service_0_17_14  service_visit_def_733  1
    service_0_17_14  free_load_conservation_734  11
    service_0_17_15  unique_nonzero_owner_309  1
    service_0_17_15  service_visit_def_733  1
    service_0_17_15  free_load_conservation_734  12
    service_0_17_16  unique_nonzero_owner_310  1
    service_0_17_16  service_visit_def_733  1
    service_0_17_16  free_load_conservation_734  13
    service_1_17_0  unique_nonzero_owner_295  1
    service_1_17_0  service_visit_def_1003  1
    service_1_17_0  free_load_conservation_1004  -3
    service_1_17_0  original_T_including_depot_unload_1024  360
    service_1_17_1  unique_nonzero_owner_296  1
    service_1_17_1  service_visit_def_1003  1
    service_1_17_1  free_load_conservation_1004  -2
    service_1_17_1  original_T_including_depot_unload_1024  240
    service_1_17_2  unique_nonzero_owner_297  1
    service_1_17_2  service_visit_def_1003  1
    service_1_17_2  free_load_conservation_1004  -1
    service_1_17_2  original_T_including_depot_unload_1024  120
    service_1_17_4  unique_nonzero_owner_298  1
    service_1_17_4  service_visit_def_1003  1
    service_1_17_4  free_load_conservation_1004  1
    service_1_17_5  unique_nonzero_owner_299  1
    service_1_17_5  service_visit_def_1003  1
    service_1_17_5  free_load_conservation_1004  2
    service_1_17_6  unique_nonzero_owner_300  1
    service_1_17_6  service_visit_def_1003  1
    service_1_17_6  free_load_conservation_1004  3
    service_1_17_7  unique_nonzero_owner_301  1
    service_1_17_7  service_visit_def_1003  1
    service_1_17_7  free_load_conservation_1004  4
    service_1_17_8  unique_nonzero_owner_302  1
    service_1_17_8  service_visit_def_1003  1
    service_1_17_8  free_load_conservation_1004  5
    service_1_17_9  unique_nonzero_owner_303  1
    service_1_17_9  service_visit_def_1003  1
    service_1_17_9  free_load_conservation_1004  6
    service_1_17_10  unique_nonzero_owner_304  1
    service_1_17_10  service_visit_def_1003  1
    service_1_17_10  free_load_conservation_1004  7
    service_1_17_11  unique_nonzero_owner_305  1
    service_1_17_11  service_visit_def_1003  1
    service_1_17_11  free_load_conservation_1004  8
    service_1_17_12  unique_nonzero_owner_306  1
    service_1_17_12  service_visit_def_1003  1
    service_1_17_12  free_load_conservation_1004  9
    service_1_17_13  unique_nonzero_owner_307  1
    service_1_17_13  service_visit_def_1003  1
    service_1_17_13  free_load_conservation_1004  10
    service_1_17_14  unique_nonzero_owner_308  1
    service_1_17_14  service_visit_def_1003  1
    service_1_17_14  free_load_conservation_1004  11
    service_1_17_15  unique_nonzero_owner_309  1
    service_1_17_15  service_visit_def_1003  1
    service_1_17_15  free_load_conservation_1004  12
    service_1_17_16  unique_nonzero_owner_310  1
    service_1_17_16  service_visit_def_1003  1
    service_1_17_16  free_load_conservation_1004  13
    service_0_5_1  unique_nonzero_owner_311  1
    service_0_5_1  service_visit_def_739  1
    service_0_5_1  free_load_conservation_740  1
    service_0_5_2  unique_nonzero_owner_312  1
    service_0_5_2  service_visit_def_739  1
    service_0_5_2  free_load_conservation_740  2
    service_1_5_1  unique_nonzero_owner_311  1
    service_1_5_1  service_visit_def_1009  1
    service_1_5_1  free_load_conservation_1010  1
    service_1_5_2  unique_nonzero_owner_312  1
    service_1_5_2  service_visit_def_1009  1
    service_1_5_2  free_load_conservation_1010  2
    service_0_11_0  unique_nonzero_owner_313  1
    service_0_11_0  service_visit_def_745  1
    service_0_11_0  free_load_conservation_746  -1
    service_0_11_0  original_T_including_depot_unload_757  120
    service_0_11_2  unique_nonzero_owner_314  1
    service_0_11_2  service_visit_def_745  1
    service_0_11_2  free_load_conservation_746  1
    service_0_11_3  unique_nonzero_owner_315  1
    service_0_11_3  service_visit_def_745  1
    service_0_11_3  free_load_conservation_746  2
    service_0_11_4  unique_nonzero_owner_316  1
    service_0_11_4  service_visit_def_745  1
    service_0_11_4  free_load_conservation_746  3
    service_0_11_5  unique_nonzero_owner_317  1
    service_0_11_5  service_visit_def_745  1
    service_0_11_5  free_load_conservation_746  4
    service_0_11_6  unique_nonzero_owner_318  1
    service_0_11_6  service_visit_def_745  1
    service_0_11_6  free_load_conservation_746  5
    service_0_11_7  unique_nonzero_owner_319  1
    service_0_11_7  service_visit_def_745  1
    service_0_11_7  free_load_conservation_746  6
    service_0_11_8  unique_nonzero_owner_320  1
    service_0_11_8  service_visit_def_745  1
    service_0_11_8  free_load_conservation_746  7
    service_0_11_9  unique_nonzero_owner_321  1
    service_0_11_9  service_visit_def_745  1
    service_0_11_9  free_load_conservation_746  8
    service_0_11_10  unique_nonzero_owner_322  1
    service_0_11_10  service_visit_def_745  1
    service_0_11_10  free_load_conservation_746  9
    service_0_11_11  unique_nonzero_owner_323  1
    service_0_11_11  service_visit_def_745  1
    service_0_11_11  free_load_conservation_746  10
    service_0_11_12  unique_nonzero_owner_324  1
    service_0_11_12  service_visit_def_745  1
    service_0_11_12  free_load_conservation_746  11
    service_0_11_13  unique_nonzero_owner_325  1
    service_0_11_13  service_visit_def_745  1
    service_0_11_13  free_load_conservation_746  12
    service_0_11_14  unique_nonzero_owner_326  1
    service_0_11_14  service_visit_def_745  1
    service_0_11_14  free_load_conservation_746  13
    service_0_11_15  unique_nonzero_owner_327  1
    service_0_11_15  service_visit_def_745  1
    service_0_11_15  free_load_conservation_746  14
    service_1_11_0  unique_nonzero_owner_313  1
    service_1_11_0  service_visit_def_1015  1
    service_1_11_0  free_load_conservation_1016  -1
    service_1_11_0  original_T_including_depot_unload_1024  120
    service_1_11_2  unique_nonzero_owner_314  1
    service_1_11_2  service_visit_def_1015  1
    service_1_11_2  free_load_conservation_1016  1
    service_1_11_3  unique_nonzero_owner_315  1
    service_1_11_3  service_visit_def_1015  1
    service_1_11_3  free_load_conservation_1016  2
    service_1_11_4  unique_nonzero_owner_316  1
    service_1_11_4  service_visit_def_1015  1
    service_1_11_4  free_load_conservation_1016  3
    service_1_11_5  unique_nonzero_owner_317  1
    service_1_11_5  service_visit_def_1015  1
    service_1_11_5  free_load_conservation_1016  4
    service_1_11_6  unique_nonzero_owner_318  1
    service_1_11_6  service_visit_def_1015  1
    service_1_11_6  free_load_conservation_1016  5
    service_1_11_7  unique_nonzero_owner_319  1
    service_1_11_7  service_visit_def_1015  1
    service_1_11_7  free_load_conservation_1016  6
    service_1_11_8  unique_nonzero_owner_320  1
    service_1_11_8  service_visit_def_1015  1
    service_1_11_8  free_load_conservation_1016  7
    service_1_11_9  unique_nonzero_owner_321  1
    service_1_11_9  service_visit_def_1015  1
    service_1_11_9  free_load_conservation_1016  8
    service_1_11_10  unique_nonzero_owner_322  1
    service_1_11_10  service_visit_def_1015  1
    service_1_11_10  free_load_conservation_1016  9
    service_1_11_11  unique_nonzero_owner_323  1
    service_1_11_11  service_visit_def_1015  1
    service_1_11_11  free_load_conservation_1016  10
    service_1_11_12  unique_nonzero_owner_324  1
    service_1_11_12  service_visit_def_1015  1
    service_1_11_12  free_load_conservation_1016  11
    service_1_11_13  unique_nonzero_owner_325  1
    service_1_11_13  service_visit_def_1015  1
    service_1_11_13  free_load_conservation_1016  12
    service_1_11_14  unique_nonzero_owner_326  1
    service_1_11_14  service_visit_def_1015  1
    service_1_11_14  free_load_conservation_1016  13
    service_1_11_15  unique_nonzero_owner_327  1
    service_1_11_15  service_visit_def_1015  1
    service_1_11_15  free_load_conservation_1016  14
    service_0_2_1  unique_nonzero_owner_328  1
    service_0_2_1  service_visit_def_751  1
    service_0_2_1  free_load_conservation_752  1
    service_1_2_1  unique_nonzero_owner_328  1
    service_1_2_1  service_visit_def_1021  1
    service_1_2_1  free_load_conservation_1022  1
    MARKER    'MARKER'                 'INTEND'
    visit_0_1  out_degree_670  -1
    visit_0_1  in_degree_671  -1
    visit_0_1  order_active_lb_672  -1
    visit_0_1  order_active_ub_673  -13
    order_0_1  connected_order_arc_345  -1
    order_0_1  connected_order_arc_347  -1
    order_0_1  connected_order_arc_349  -1
    order_0_1  connected_order_arc_351  -1
    order_0_1  connected_order_arc_353  -1
    order_0_1  connected_order_arc_355  -1
    order_0_1  connected_order_arc_357  -1
    order_0_1  connected_order_arc_359  -1
    order_0_1  connected_order_arc_361  -1
    order_0_1  connected_order_arc_363  -1
    order_0_1  connected_order_arc_365  -1
    order_0_1  connected_order_arc_367  -1
    order_0_1  connected_order_arc_370  1
    order_0_1  connected_order_arc_395  1
    order_0_1  connected_order_arc_420  1
    order_0_1  connected_order_arc_445  1
    order_0_1  connected_order_arc_470  1
    order_0_1  connected_order_arc_495  1
    order_0_1  connected_order_arc_520  1
    order_0_1  connected_order_arc_545  1
    order_0_1  connected_order_arc_570  1
    order_0_1  connected_order_arc_595  1
    order_0_1  connected_order_arc_620  1
    order_0_1  connected_order_arc_645  1
    order_0_1  order_active_lb_672  1
    order_0_1  order_active_ub_673  1
    order_0_1  fixed_segment_relative_order_753  -1
    visit_0_2  out_degree_677  -1
    visit_0_2  in_degree_678  -1
    visit_0_2  order_active_lb_679  -1
    visit_0_2  order_active_ub_680  -13
    order_0_2  connected_order_arc_345  1
    order_0_2  connected_order_arc_370  -1
    order_0_2  connected_order_arc_372  -1
    order_0_2  connected_order_arc_374  -1
    order_0_2  connected_order_arc_376  -1
    order_0_2  connected_order_arc_378  -1
    order_0_2  connected_order_arc_380  -1
    order_0_2  connected_order_arc_382  -1
    order_0_2  connected_order_arc_384  -1
    order_0_2  connected_order_arc_386  -1
    order_0_2  connected_order_arc_388  -1
    order_0_2  connected_order_arc_390  -1
    order_0_2  connected_order_arc_392  -1
    order_0_2  connected_order_arc_397  1
    order_0_2  connected_order_arc_422  1
    order_0_2  connected_order_arc_447  1
    order_0_2  connected_order_arc_472  1
    order_0_2  connected_order_arc_497  1
    order_0_2  connected_order_arc_522  1
    order_0_2  connected_order_arc_547  1
    order_0_2  connected_order_arc_572  1
    order_0_2  connected_order_arc_597  1
    order_0_2  connected_order_arc_622  1
    order_0_2  connected_order_arc_647  1
    order_0_2  order_active_lb_679  1
    order_0_2  order_active_ub_680  1
    order_0_2  fixed_segment_relative_order_753  1
    order_0_2  fixed_segment_relative_order_754  -1
    visit_0_3  out_degree_684  -1
    visit_0_3  in_degree_685  -1
    visit_0_3  order_active_lb_686  -1
    visit_0_3  order_active_ub_687  -13
    order_0_3  connected_order_arc_347  1
    order_0_3  connected_order_arc_372  1
    order_0_3  connected_order_arc_395  -1
    order_0_3  connected_order_arc_397  -1
    order_0_3  connected_order_arc_399  -1
    order_0_3  connected_order_arc_401  -1
    order_0_3  connected_order_arc_403  -1
    order_0_3  connected_order_arc_405  -1
    order_0_3  connected_order_arc_407  -1
    order_0_3  connected_order_arc_409  -1
    order_0_3  connected_order_arc_411  -1
    order_0_3  connected_order_arc_413  -1
    order_0_3  connected_order_arc_415  -1
    order_0_3  connected_order_arc_417  -1
    order_0_3  connected_order_arc_424  1
    order_0_3  connected_order_arc_449  1
    order_0_3  connected_order_arc_474  1
    order_0_3  connected_order_arc_499  1
    order_0_3  connected_order_arc_524  1
    order_0_3  connected_order_arc_549  1
    order_0_3  connected_order_arc_574  1
    order_0_3  connected_order_arc_599  1
    order_0_3  connected_order_arc_624  1
    order_0_3  connected_order_arc_649  1
    order_0_3  order_active_lb_686  1
    order_0_3  order_active_ub_687  1
    order_0_3  fixed_segment_relative_order_754  1
    order_0_3  fixed_segment_relative_order_755  -1
    visit_0_4  out_degree_691  -1
    visit_0_4  in_degree_692  -1
    visit_0_4  order_active_lb_693  -1
    visit_0_4  order_active_ub_694  -13
    order_0_4  connected_order_arc_349  1
    order_0_4  connected_order_arc_374  1
    order_0_4  connected_order_arc_399  1
    order_0_4  connected_order_arc_420  -1
    order_0_4  connected_order_arc_422  -1
    order_0_4  connected_order_arc_424  -1
    order_0_4  connected_order_arc_426  -1
    order_0_4  connected_order_arc_428  -1
    order_0_4  connected_order_arc_430  -1
    order_0_4  connected_order_arc_432  -1
    order_0_4  connected_order_arc_434  -1
    order_0_4  connected_order_arc_436  -1
    order_0_4  connected_order_arc_438  -1
    order_0_4  connected_order_arc_440  -1
    order_0_4  connected_order_arc_442  -1
    order_0_4  connected_order_arc_451  1
    order_0_4  connected_order_arc_476  1
    order_0_4  connected_order_arc_501  1
    order_0_4  connected_order_arc_526  1
    order_0_4  connected_order_arc_551  1
    order_0_4  connected_order_arc_576  1
    order_0_4  connected_order_arc_601  1
    order_0_4  connected_order_arc_626  1
    order_0_4  connected_order_arc_651  1
    order_0_4  order_active_lb_693  1
    order_0_4  order_active_ub_694  1
    order_0_4  fixed_segment_relative_order_755  1
    order_0_4  fixed_segment_relative_order_756  -1
    visit_0_5  out_degree_698  -1
    visit_0_5  in_degree_699  -1
    visit_0_5  order_active_lb_700  -1
    visit_0_5  order_active_ub_701  -13
    order_0_5  connected_order_arc_351  1
    order_0_5  connected_order_arc_376  1
    order_0_5  connected_order_arc_401  1
    order_0_5  connected_order_arc_426  1
    order_0_5  connected_order_arc_445  -1
    order_0_5  connected_order_arc_447  -1
    order_0_5  connected_order_arc_449  -1
    order_0_5  connected_order_arc_451  -1
    order_0_5  connected_order_arc_453  -1
    order_0_5  connected_order_arc_455  -1
    order_0_5  connected_order_arc_457  -1
    order_0_5  connected_order_arc_459  -1
    order_0_5  connected_order_arc_461  -1
    order_0_5  connected_order_arc_463  -1
    order_0_5  connected_order_arc_465  -1
    order_0_5  connected_order_arc_467  -1
    order_0_5  connected_order_arc_478  1
    order_0_5  connected_order_arc_503  1
    order_0_5  connected_order_arc_528  1
    order_0_5  connected_order_arc_553  1
    order_0_5  connected_order_arc_578  1
    order_0_5  connected_order_arc_603  1
    order_0_5  connected_order_arc_628  1
    order_0_5  connected_order_arc_653  1
    order_0_5  order_active_lb_700  1
    order_0_5  order_active_ub_701  1
    order_0_5  fixed_segment_relative_order_756  1
    visit_0_8  out_degree_705  -1
    visit_0_8  in_degree_706  -1
    visit_0_8  order_active_lb_707  -1
    visit_0_8  order_active_ub_708  -13
    visit_0_8  service_visit_def_709  -1
    order_0_8  connected_order_arc_353  1
    order_0_8  connected_order_arc_378  1
    order_0_8  connected_order_arc_403  1
    order_0_8  connected_order_arc_428  1
    order_0_8  connected_order_arc_453  1
    order_0_8  connected_order_arc_470  -1
    order_0_8  connected_order_arc_472  -1
    order_0_8  connected_order_arc_474  -1
    order_0_8  connected_order_arc_476  -1
    order_0_8  connected_order_arc_478  -1
    order_0_8  connected_order_arc_480  -1
    order_0_8  connected_order_arc_482  -1
    order_0_8  connected_order_arc_484  -1
    order_0_8  connected_order_arc_486  -1
    order_0_8  connected_order_arc_488  -1
    order_0_8  connected_order_arc_490  -1
    order_0_8  connected_order_arc_492  -1
    order_0_8  connected_order_arc_505  1
    order_0_8  connected_order_arc_530  1
    order_0_8  connected_order_arc_555  1
    order_0_8  connected_order_arc_580  1
    order_0_8  connected_order_arc_605  1
    order_0_8  connected_order_arc_630  1
    order_0_8  connected_order_arc_655  1
    order_0_8  order_active_lb_707  1
    order_0_8  order_active_ub_708  1
    visit_0_9  out_degree_711  -1
    visit_0_9  in_degree_712  -1
    visit_0_9  order_active_lb_713  -1
    visit_0_9  order_active_ub_714  -13
    visit_0_9  service_visit_def_715  -1
    order_0_9  connected_order_arc_355  1
    order_0_9  connected_order_arc_380  1
    order_0_9  connected_order_arc_405  1
    order_0_9  connected_order_arc_430  1
    order_0_9  connected_order_arc_455  1
    order_0_9  connected_order_arc_480  1
    order_0_9  connected_order_arc_495  -1
    order_0_9  connected_order_arc_497  -1
    order_0_9  connected_order_arc_499  -1
    order_0_9  connected_order_arc_501  -1
    order_0_9  connected_order_arc_503  -1
    order_0_9  connected_order_arc_505  -1
    order_0_9  connected_order_arc_507  -1
    order_0_9  connected_order_arc_509  -1
    order_0_9  connected_order_arc_511  -1
    order_0_9  connected_order_arc_513  -1
    order_0_9  connected_order_arc_515  -1
    order_0_9  connected_order_arc_517  -1
    order_0_9  connected_order_arc_532  1
    order_0_9  connected_order_arc_557  1
    order_0_9  connected_order_arc_582  1
    order_0_9  connected_order_arc_607  1
    order_0_9  connected_order_arc_632  1
    order_0_9  connected_order_arc_657  1
    order_0_9  order_active_lb_713  1
    order_0_9  order_active_ub_714  1
    visit_0_10  out_degree_717  -1
    visit_0_10  in_degree_718  -1
    visit_0_10  order_active_lb_719  -1
    visit_0_10  order_active_ub_720  -13
    visit_0_10  service_visit_def_721  -1
    order_0_10  connected_order_arc_357  1
    order_0_10  connected_order_arc_382  1
    order_0_10  connected_order_arc_407  1
    order_0_10  connected_order_arc_432  1
    order_0_10  connected_order_arc_457  1
    order_0_10  connected_order_arc_482  1
    order_0_10  connected_order_arc_507  1
    order_0_10  connected_order_arc_520  -1
    order_0_10  connected_order_arc_522  -1
    order_0_10  connected_order_arc_524  -1
    order_0_10  connected_order_arc_526  -1
    order_0_10  connected_order_arc_528  -1
    order_0_10  connected_order_arc_530  -1
    order_0_10  connected_order_arc_532  -1
    order_0_10  connected_order_arc_534  -1
    order_0_10  connected_order_arc_536  -1
    order_0_10  connected_order_arc_538  -1
    order_0_10  connected_order_arc_540  -1
    order_0_10  connected_order_arc_542  -1
    order_0_10  connected_order_arc_559  1
    order_0_10  connected_order_arc_584  1
    order_0_10  connected_order_arc_609  1
    order_0_10  connected_order_arc_634  1
    order_0_10  connected_order_arc_659  1
    order_0_10  order_active_lb_719  1
    order_0_10  order_active_ub_720  1
    visit_0_11  out_degree_723  -1
    visit_0_11  in_degree_724  -1
    visit_0_11  order_active_lb_725  -1
    visit_0_11  order_active_ub_726  -13
    visit_0_11  service_visit_def_727  -1
    order_0_11  connected_order_arc_359  1
    order_0_11  connected_order_arc_384  1
    order_0_11  connected_order_arc_409  1
    order_0_11  connected_order_arc_434  1
    order_0_11  connected_order_arc_459  1
    order_0_11  connected_order_arc_484  1
    order_0_11  connected_order_arc_509  1
    order_0_11  connected_order_arc_534  1
    order_0_11  connected_order_arc_545  -1
    order_0_11  connected_order_arc_547  -1
    order_0_11  connected_order_arc_549  -1
    order_0_11  connected_order_arc_551  -1
    order_0_11  connected_order_arc_553  -1
    order_0_11  connected_order_arc_555  -1
    order_0_11  connected_order_arc_557  -1
    order_0_11  connected_order_arc_559  -1
    order_0_11  connected_order_arc_561  -1
    order_0_11  connected_order_arc_563  -1
    order_0_11  connected_order_arc_565  -1
    order_0_11  connected_order_arc_567  -1
    order_0_11  connected_order_arc_586  1
    order_0_11  connected_order_arc_611  1
    order_0_11  connected_order_arc_636  1
    order_0_11  connected_order_arc_661  1
    order_0_11  order_active_lb_725  1
    order_0_11  order_active_ub_726  1
    visit_0_12  out_degree_729  -1
    visit_0_12  in_degree_730  -1
    visit_0_12  order_active_lb_731  -1
    visit_0_12  order_active_ub_732  -13
    visit_0_12  service_visit_def_733  -1
    order_0_12  connected_order_arc_361  1
    order_0_12  connected_order_arc_386  1
    order_0_12  connected_order_arc_411  1
    order_0_12  connected_order_arc_436  1
    order_0_12  connected_order_arc_461  1
    order_0_12  connected_order_arc_486  1
    order_0_12  connected_order_arc_511  1
    order_0_12  connected_order_arc_536  1
    order_0_12  connected_order_arc_561  1
    order_0_12  connected_order_arc_570  -1
    order_0_12  connected_order_arc_572  -1
    order_0_12  connected_order_arc_574  -1
    order_0_12  connected_order_arc_576  -1
    order_0_12  connected_order_arc_578  -1
    order_0_12  connected_order_arc_580  -1
    order_0_12  connected_order_arc_582  -1
    order_0_12  connected_order_arc_584  -1
    order_0_12  connected_order_arc_586  -1
    order_0_12  connected_order_arc_588  -1
    order_0_12  connected_order_arc_590  -1
    order_0_12  connected_order_arc_592  -1
    order_0_12  connected_order_arc_613  1
    order_0_12  connected_order_arc_638  1
    order_0_12  connected_order_arc_663  1
    order_0_12  order_active_lb_731  1
    order_0_12  order_active_ub_732  1
    visit_0_13  out_degree_735  -1
    visit_0_13  in_degree_736  -1
    visit_0_13  order_active_lb_737  -1
    visit_0_13  order_active_ub_738  -13
    visit_0_13  service_visit_def_739  -1
    order_0_13  connected_order_arc_363  1
    order_0_13  connected_order_arc_388  1
    order_0_13  connected_order_arc_413  1
    order_0_13  connected_order_arc_438  1
    order_0_13  connected_order_arc_463  1
    order_0_13  connected_order_arc_488  1
    order_0_13  connected_order_arc_513  1
    order_0_13  connected_order_arc_538  1
    order_0_13  connected_order_arc_563  1
    order_0_13  connected_order_arc_588  1
    order_0_13  connected_order_arc_595  -1
    order_0_13  connected_order_arc_597  -1
    order_0_13  connected_order_arc_599  -1
    order_0_13  connected_order_arc_601  -1
    order_0_13  connected_order_arc_603  -1
    order_0_13  connected_order_arc_605  -1
    order_0_13  connected_order_arc_607  -1
    order_0_13  connected_order_arc_609  -1
    order_0_13  connected_order_arc_611  -1
    order_0_13  connected_order_arc_613  -1
    order_0_13  connected_order_arc_615  -1
    order_0_13  connected_order_arc_617  -1
    order_0_13  connected_order_arc_640  1
    order_0_13  connected_order_arc_665  1
    order_0_13  order_active_lb_737  1
    order_0_13  order_active_ub_738  1
    visit_0_14  out_degree_741  -1
    visit_0_14  in_degree_742  -1
    visit_0_14  order_active_lb_743  -1
    visit_0_14  order_active_ub_744  -13
    visit_0_14  service_visit_def_745  -1
    order_0_14  connected_order_arc_365  1
    order_0_14  connected_order_arc_390  1
    order_0_14  connected_order_arc_415  1
    order_0_14  connected_order_arc_440  1
    order_0_14  connected_order_arc_465  1
    order_0_14  connected_order_arc_490  1
    order_0_14  connected_order_arc_515  1
    order_0_14  connected_order_arc_540  1
    order_0_14  connected_order_arc_565  1
    order_0_14  connected_order_arc_590  1
    order_0_14  connected_order_arc_615  1
    order_0_14  connected_order_arc_620  -1
    order_0_14  connected_order_arc_622  -1
    order_0_14  connected_order_arc_624  -1
    order_0_14  connected_order_arc_626  -1
    order_0_14  connected_order_arc_628  -1
    order_0_14  connected_order_arc_630  -1
    order_0_14  connected_order_arc_632  -1
    order_0_14  connected_order_arc_634  -1
    order_0_14  connected_order_arc_636  -1
    order_0_14  connected_order_arc_638  -1
    order_0_14  connected_order_arc_640  -1
    order_0_14  connected_order_arc_642  -1
    order_0_14  connected_order_arc_667  1
    order_0_14  order_active_lb_743  1
    order_0_14  order_active_ub_744  1
    visit_0_15  out_degree_747  -1
    visit_0_15  in_degree_748  -1
    visit_0_15  order_active_lb_749  -1
    visit_0_15  order_active_ub_750  -13
    visit_0_15  service_visit_def_751  -1
    order_0_15  connected_order_arc_367  1
    order_0_15  connected_order_arc_392  1
    order_0_15  connected_order_arc_417  1
    order_0_15  connected_order_arc_442  1
    order_0_15  connected_order_arc_467  1
    order_0_15  connected_order_arc_492  1
    order_0_15  connected_order_arc_517  1
    order_0_15  connected_order_arc_542  1
    order_0_15  connected_order_arc_567  1
    order_0_15  connected_order_arc_592  1
    order_0_15  connected_order_arc_617  1
    order_0_15  connected_order_arc_642  1
    order_0_15  connected_order_arc_645  -1
    order_0_15  connected_order_arc_647  -1
    order_0_15  connected_order_arc_649  -1
    order_0_15  connected_order_arc_651  -1
    order_0_15  connected_order_arc_653  -1
    order_0_15  connected_order_arc_655  -1
    order_0_15  connected_order_arc_657  -1
    order_0_15  connected_order_arc_659  -1
    order_0_15  connected_order_arc_661  -1
    order_0_15  connected_order_arc_663  -1
    order_0_15  connected_order_arc_665  -1
    order_0_15  connected_order_arc_667  -1
    order_0_15  order_active_lb_749  1
    order_0_15  order_active_ub_750  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_0  arc_capacity_329  -30
    arc_0_0_0  depot_departure_or_bypass_668  1
    arc_0_0_0  depot_return_or_bypass_669  1
    MARKER    'MARKER'                 'INTEND'
    load_0_0_0  arc_capacity_329  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_1  arc_capacity_330  -30
    arc_0_0_1  depot_departure_or_bypass_668  1
    arc_0_0_1  in_degree_671  1
    arc_0_0_1  original_T_including_depot_unload_757  3.5937232665424995e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_1  arc_capacity_330  1
    load_0_0_1  segment_load_conservation_674  -1
    load_0_0_1  segment_prefix_lb_675  1
    load_0_0_1  segment_prefix_ub_676  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_2  arc_capacity_331  -30
    arc_0_0_2  depot_departure_or_bypass_668  1
    arc_0_0_2  in_degree_678  1
    arc_0_0_2  original_T_including_depot_unload_757  5.2774046204590661e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_2  arc_capacity_331  1
    load_0_0_2  segment_load_conservation_681  -1
    load_0_0_2  segment_prefix_lb_682  1
    load_0_0_2  segment_prefix_ub_683  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_3  arc_capacity_332  -30
    arc_0_0_3  depot_departure_or_bypass_668  1
    arc_0_0_3  in_degree_685  1
    arc_0_0_3  original_T_including_depot_unload_757  1.2186896810212775e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_3  arc_capacity_332  1
    load_0_0_3  segment_load_conservation_688  -1
    load_0_0_3  segment_prefix_lb_689  1
    load_0_0_3  segment_prefix_ub_690  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_4  arc_capacity_333  -30
    arc_0_0_4  depot_departure_or_bypass_668  1
    arc_0_0_4  in_degree_692  1
    arc_0_0_4  original_T_including_depot_unload_757  1.1473865007565566e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_4  arc_capacity_333  1
    load_0_0_4  segment_load_conservation_695  -1
    load_0_0_4  segment_prefix_lb_696  1
    load_0_0_4  segment_prefix_ub_697  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_5  arc_capacity_334  -30
    arc_0_0_5  depot_departure_or_bypass_668  1
    arc_0_0_5  in_degree_699  1
    arc_0_0_5  original_T_including_depot_unload_757  4.1588440854375170e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_5  arc_capacity_334  1
    load_0_0_5  segment_load_conservation_702  -1
    load_0_0_5  segment_prefix_lb_703  1
    load_0_0_5  segment_prefix_ub_704  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_8  arc_capacity_335  -30
    arc_0_0_8  depot_departure_or_bypass_668  1
    arc_0_0_8  in_degree_706  1
    arc_0_0_8  original_T_including_depot_unload_757  7.4412496590753551e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_8  arc_capacity_335  1
    load_0_0_8  free_load_conservation_710  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_9  arc_capacity_336  -30
    arc_0_0_9  depot_departure_or_bypass_668  1
    arc_0_0_9  in_degree_712  1
    arc_0_0_9  original_T_including_depot_unload_757  8.2548955430739034e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_9  arc_capacity_336  1
    load_0_0_9  free_load_conservation_716  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_10  arc_capacity_337  -30
    arc_0_0_10  depot_departure_or_bypass_668  1
    arc_0_0_10  in_degree_718  1
    arc_0_0_10  original_T_including_depot_unload_757  2.3234267380118886e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_10  arc_capacity_337  1
    load_0_0_10  free_load_conservation_722  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_11  arc_capacity_338  -30
    arc_0_0_11  depot_departure_or_bypass_668  1
    arc_0_0_11  in_degree_724  1
    arc_0_0_11  original_T_including_depot_unload_757  5.9631731642067359e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_11  arc_capacity_338  1
    load_0_0_11  free_load_conservation_728  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_12  arc_capacity_339  -30
    arc_0_0_12  depot_departure_or_bypass_668  1
    arc_0_0_12  in_degree_730  1
    arc_0_0_12  original_T_including_depot_unload_757  2.2866763971369810e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_12  arc_capacity_339  1
    load_0_0_12  free_load_conservation_734  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_13  arc_capacity_340  -30
    arc_0_0_13  depot_departure_or_bypass_668  1
    arc_0_0_13  in_degree_736  1
    arc_0_0_13  original_T_including_depot_unload_757  9.3659929340140741e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_13  arc_capacity_340  1
    load_0_0_13  free_load_conservation_740  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_14  arc_capacity_341  -30
    arc_0_0_14  depot_departure_or_bypass_668  1
    arc_0_0_14  in_degree_742  1
    arc_0_0_14  original_T_including_depot_unload_757  4.0782796387128610e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_14  arc_capacity_341  1
    load_0_0_14  free_load_conservation_746  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_15  arc_capacity_342  -30
    arc_0_0_15  depot_departure_or_bypass_668  1
    arc_0_0_15  in_degree_748  1
    arc_0_0_15  original_T_including_depot_unload_757  9.3133633713881534e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_15  arc_capacity_342  1
    load_0_0_15  free_load_conservation_752  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_0  arc_capacity_343  -30
    arc_0_1_0  depot_return_or_bypass_669  1
    arc_0_1_0  out_degree_670  1
    arc_0_1_0  original_T_including_depot_unload_757  3.5937232665424995e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_0  arc_capacity_343  1
    load_0_1_0  segment_load_conservation_674  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_2  arc_capacity_344  -30
    arc_0_1_2  connected_order_arc_345  -14
    arc_0_1_2  out_degree_670  1
    arc_0_1_2  in_degree_678  1
    arc_0_1_2  original_T_including_depot_unload_757  7.2696582003770027e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_2  arc_capacity_344  1
    load_0_1_2  segment_load_conservation_674  1
    load_0_1_2  segment_load_conservation_681  -1
    load_0_1_2  segment_prefix_lb_682  1
    load_0_1_2  segment_prefix_ub_683  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_3  arc_capacity_346  -30
    arc_0_1_3  connected_order_arc_347  -14
    arc_0_1_3  out_degree_670  1
    arc_0_1_3  in_degree_685  1
    arc_0_1_3  original_T_including_depot_unload_757  1.4485896981484648e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_3  arc_capacity_346  1
    load_0_1_3  segment_load_conservation_674  1
    load_0_1_3  segment_load_conservation_688  -1
    load_0_1_3  segment_prefix_lb_689  1
    load_0_1_3  segment_prefix_ub_690  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_4  arc_capacity_348  -30
    arc_0_1_4  connected_order_arc_349  -14
    arc_0_1_4  out_degree_670  1
    arc_0_1_4  in_degree_692  1
    arc_0_1_4  original_T_including_depot_unload_757  1.4558134627196880e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_4  arc_capacity_348  1
    load_0_1_4  segment_load_conservation_674  1
    load_0_1_4  segment_load_conservation_695  -1
    load_0_1_4  segment_prefix_lb_696  1
    load_0_1_4  segment_prefix_ub_697  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_5  arc_capacity_350  -30
    arc_0_1_5  connected_order_arc_351  -14
    arc_0_1_5  out_degree_670  1
    arc_0_1_5  in_degree_699  1
    arc_0_1_5  original_T_including_depot_unload_757  7.2365484333226220e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_5  arc_capacity_350  1
    load_0_1_5  segment_load_conservation_674  1
    load_0_1_5  segment_load_conservation_702  -1
    load_0_1_5  segment_prefix_lb_703  1
    load_0_1_5  segment_prefix_ub_704  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_8  arc_capacity_352  -30
    arc_0_1_8  connected_order_arc_353  -14
    arc_0_1_8  out_degree_670  1
    arc_0_1_8  in_degree_706  1
    arc_0_1_8  original_T_including_depot_unload_757  1.0007616644945284e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_8  arc_capacity_352  1
    load_0_1_8  segment_load_conservation_674  1
    load_0_1_8  free_load_conservation_710  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_9  arc_capacity_354  -30
    arc_0_1_9  connected_order_arc_355  -14
    arc_0_1_9  out_degree_670  1
    arc_0_1_9  in_degree_712  1
    arc_0_1_9  original_T_including_depot_unload_757  1.1046832181240914e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_9  arc_capacity_354  1
    load_0_1_9  segment_load_conservation_674  1
    load_0_1_9  free_load_conservation_716  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_10  arc_capacity_356  -30
    arc_0_1_10  connected_order_arc_357  -14
    arc_0_1_10  out_degree_670  1
    arc_0_1_10  in_degree_718  1
    arc_0_1_10  original_T_including_depot_unload_757  2.4160844235310037e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_10  arc_capacity_356  1
    load_0_1_10  segment_load_conservation_674  1
    load_0_1_10  free_load_conservation_722  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_11  arc_capacity_358  -30
    arc_0_1_11  connected_order_arc_359  -14
    arc_0_1_11  out_degree_670  1
    arc_0_1_11  in_degree_724  1
    arc_0_1_11  original_T_including_depot_unload_757  8.4376826601758887e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_11  arc_capacity_358  1
    load_0_1_11  segment_load_conservation_674  1
    load_0_1_11  free_load_conservation_728  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_12  arc_capacity_360  -30
    arc_0_1_12  connected_order_arc_361  -14
    arc_0_1_12  out_degree_670  1
    arc_0_1_12  in_degree_730  1
    arc_0_1_12  original_T_including_depot_unload_757  1.9791430726365086e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_12  arc_capacity_360  1
    load_0_1_12  segment_load_conservation_674  1
    load_0_1_12  free_load_conservation_734  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_13  arc_capacity_362  -30
    arc_0_1_13  connected_order_arc_363  -14
    arc_0_1_13  out_degree_670  1
    arc_0_1_13  in_degree_736  1
    arc_0_1_13  original_T_including_depot_unload_757  1.1702148343313254e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_13  arc_capacity_362  1
    load_0_1_13  segment_load_conservation_674  1
    load_0_1_13  free_load_conservation_740  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_14  arc_capacity_364  -30
    arc_0_1_14  connected_order_arc_365  -14
    arc_0_1_14  out_degree_670  1
    arc_0_1_14  in_degree_742  1
    arc_0_1_14  original_T_including_depot_unload_757  6.3975035388222534e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_14  arc_capacity_364  1
    load_0_1_14  segment_load_conservation_674  1
    load_0_1_14  free_load_conservation_746  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_15  arc_capacity_366  -30
    arc_0_1_15  connected_order_arc_367  -14
    arc_0_1_15  out_degree_670  1
    arc_0_1_15  in_degree_748  1
    arc_0_1_15  original_T_including_depot_unload_757  1.2315777010885340e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_15  arc_capacity_366  1
    load_0_1_15  segment_load_conservation_674  1
    load_0_1_15  free_load_conservation_752  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_0  arc_capacity_368  -30
    arc_0_2_0  depot_return_or_bypass_669  1
    arc_0_2_0  out_degree_677  1
    arc_0_2_0  original_T_including_depot_unload_757  5.2774046204590661e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_0  arc_capacity_368  1
    load_0_2_0  segment_load_conservation_681  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_1  arc_capacity_369  -30
    arc_0_2_1  connected_order_arc_370  -14
    arc_0_2_1  in_degree_671  1
    arc_0_2_1  out_degree_677  1
    arc_0_2_1  original_T_including_depot_unload_757  7.2696582003770027e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_1  arc_capacity_369  1
    load_0_2_1  segment_load_conservation_674  -1
    load_0_2_1  segment_prefix_lb_675  1
    load_0_2_1  segment_prefix_ub_676  1
    load_0_2_1  segment_load_conservation_681  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_3  arc_capacity_371  -30
    arc_0_2_3  connected_order_arc_372  -14
    arc_0_2_3  out_degree_677  1
    arc_0_2_3  in_degree_685  1
    arc_0_2_3  original_T_including_depot_unload_757  7.2186296856879846e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_3  arc_capacity_371  1
    load_0_2_3  segment_load_conservation_681  1
    load_0_2_3  segment_load_conservation_688  -1
    load_0_2_3  segment_prefix_lb_689  1
    load_0_2_3  segment_prefix_ub_690  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_4  arc_capacity_373  -30
    arc_0_2_4  connected_order_arc_374  -14
    arc_0_2_4  out_degree_677  1
    arc_0_2_4  in_degree_692  1
    arc_0_2_4  original_T_including_depot_unload_757  7.8604521666483390e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_4  arc_capacity_373  1
    load_0_2_4  segment_load_conservation_681  1
    load_0_2_4  segment_load_conservation_695  -1
    load_0_2_4  segment_prefix_lb_696  1
    load_0_2_4  segment_prefix_ub_697  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_5  arc_capacity_375  -30
    arc_0_2_5  connected_order_arc_376  -14
    arc_0_2_5  out_degree_677  1
    arc_0_2_5  in_degree_699  1
    arc_0_2_5  original_T_including_depot_unload_757  2.6178398366762252e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_5  arc_capacity_375  1
    load_0_2_5  segment_load_conservation_681  1
    load_0_2_5  segment_load_conservation_702  -1
    load_0_2_5  segment_prefix_lb_703  1
    load_0_2_5  segment_prefix_ub_704  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_8  arc_capacity_377  -30
    arc_0_2_8  connected_order_arc_378  -14
    arc_0_2_8  out_degree_677  1
    arc_0_2_8  in_degree_706  1
    arc_0_2_8  original_T_including_depot_unload_757  291.965990421835
    MARKER    'MARKER'                 'INTEND'
    load_0_2_8  arc_capacity_377  1
    load_0_2_8  segment_load_conservation_681  1
    load_0_2_8  free_load_conservation_710  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_9  arc_capacity_379  -30
    arc_0_2_9  connected_order_arc_380  -14
    arc_0_2_9  out_degree_677  1
    arc_0_2_9  in_degree_712  1
    arc_0_2_9  original_T_including_depot_unload_757  4.1346687597344868e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_9  arc_capacity_379  1
    load_0_2_9  segment_load_conservation_681  1
    load_0_2_9  free_load_conservation_716  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_10  arc_capacity_381  -30
    arc_0_2_10  connected_order_arc_382  -14
    arc_0_2_10  out_degree_677  1
    arc_0_2_10  in_degree_718  1
    arc_0_2_10  original_T_including_depot_unload_757  2.7957126389480295e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_10  arc_capacity_381  1
    load_0_2_10  segment_load_conservation_681  1
    load_0_2_10  free_load_conservation_722  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_11  arc_capacity_383  -30
    arc_0_2_11  connected_order_arc_384  -14
    arc_0_2_11  out_degree_677  1
    arc_0_2_11  in_degree_724  1
    arc_0_2_11  original_T_including_depot_unload_757  1.4810770279475858e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_11  arc_capacity_383  1
    load_0_2_11  segment_load_conservation_681  1
    load_0_2_11  free_load_conservation_728  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_12  arc_capacity_385  -30
    arc_0_2_12  connected_order_arc_386  -14
    arc_0_2_12  out_degree_677  1
    arc_0_2_12  in_degree_730  1
    arc_0_2_12  original_T_including_depot_unload_757  2.2541698308553673e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_12  arc_capacity_385  1
    load_0_2_12  segment_load_conservation_681  1
    load_0_2_12  free_load_conservation_734  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_13  arc_capacity_387  -30
    arc_0_2_13  connected_order_arc_388  -14
    arc_0_2_13  out_degree_677  1
    arc_0_2_13  in_degree_736  1
    arc_0_2_13  original_T_including_depot_unload_757  4.4360641393992279e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_13  arc_capacity_387  1
    load_0_2_13  segment_load_conservation_681  1
    load_0_2_13  free_load_conservation_740  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_14  arc_capacity_389  -30
    arc_0_2_14  connected_order_arc_390  -14
    arc_0_2_14  out_degree_677  1
    arc_0_2_14  in_degree_742  1
    arc_0_2_14  original_T_including_depot_unload_757  1.2480053261465446e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_14  arc_capacity_389  1
    load_0_2_14  segment_load_conservation_681  1
    load_0_2_14  free_load_conservation_746  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_15  arc_capacity_391  -30
    arc_0_2_15  connected_order_arc_392  -14
    arc_0_2_15  out_degree_677  1
    arc_0_2_15  in_degree_748  1
    arc_0_2_15  original_T_including_depot_unload_757  5.6231331158364958e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_15  arc_capacity_391  1
    load_0_2_15  segment_load_conservation_681  1
    load_0_2_15  free_load_conservation_752  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_0  arc_capacity_393  -30
    arc_0_3_0  depot_return_or_bypass_669  1
    arc_0_3_0  out_degree_684  1
    arc_0_3_0  original_T_including_depot_unload_757  1.2186896810212775e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_0  arc_capacity_393  1
    load_0_3_0  segment_load_conservation_688  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_1  arc_capacity_394  -30
    arc_0_3_1  connected_order_arc_395  -14
    arc_0_3_1  in_degree_671  1
    arc_0_3_1  out_degree_684  1
    arc_0_3_1  original_T_including_depot_unload_757  1.4485896981484648e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_1  arc_capacity_394  1
    load_0_3_1  segment_load_conservation_674  -1
    load_0_3_1  segment_prefix_lb_675  1
    load_0_3_1  segment_prefix_ub_676  1
    load_0_3_1  segment_load_conservation_688  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_2  arc_capacity_396  -30
    arc_0_3_2  connected_order_arc_397  -14
    arc_0_3_2  in_degree_678  1
    arc_0_3_2  out_degree_684  1
    arc_0_3_2  original_T_including_depot_unload_757  7.2186296856879846e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_2  arc_capacity_396  1
    load_0_3_2  segment_load_conservation_681  -1
    load_0_3_2  segment_prefix_lb_682  1
    load_0_3_2  segment_prefix_ub_683  1
    load_0_3_2  segment_load_conservation_688  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_4  arc_capacity_398  -30
    arc_0_3_4  connected_order_arc_399  -14
    arc_0_3_4  out_degree_684  1
    arc_0_3_4  in_degree_692  1
    arc_0_3_4  original_T_including_depot_unload_757  4.4158457011124148e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_4  arc_capacity_398  1
    load_0_3_4  segment_load_conservation_688  1
    load_0_3_4  segment_load_conservation_695  -1
    load_0_3_4  segment_prefix_lb_696  1
    load_0_3_4  segment_prefix_ub_697  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_5  arc_capacity_400  -30
    arc_0_3_5  connected_order_arc_401  -14
    arc_0_3_5  out_degree_684  1
    arc_0_3_5  in_degree_699  1
    arc_0_3_5  original_T_including_depot_unload_757  8.2210727717430609e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_5  arc_capacity_400  1
    load_0_3_5  segment_load_conservation_688  1
    load_0_3_5  segment_load_conservation_702  -1
    load_0_3_5  segment_prefix_lb_703  1
    load_0_3_5  segment_prefix_ub_704  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_8  arc_capacity_402  -30
    arc_0_3_8  connected_order_arc_403  -14
    arc_0_3_8  out_degree_684  1
    arc_0_3_8  in_degree_706  1
    arc_0_3_8  original_T_including_depot_unload_757  4.7721499161748335e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_8  arc_capacity_402  1
    load_0_3_8  segment_load_conservation_688  1
    load_0_3_8  free_load_conservation_710  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_9  arc_capacity_404  -30
    arc_0_3_9  connected_order_arc_405  -14
    arc_0_3_9  out_degree_684  1
    arc_0_3_9  in_degree_712  1
    arc_0_3_9  original_T_including_depot_unload_757  4.3124580937307496e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_9  arc_capacity_404  1
    load_0_3_9  segment_load_conservation_688  1
    load_0_3_9  free_load_conservation_716  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_10  arc_capacity_406  -30
    arc_0_3_10  connected_order_arc_407  -14
    arc_0_3_10  out_degree_684  1
    arc_0_3_10  in_degree_718  1
    arc_0_3_10  original_T_including_depot_unload_757  3.3076115257178203e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_10  arc_capacity_406  1
    load_0_3_10  segment_load_conservation_688  1
    load_0_3_10  free_load_conservation_722  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_11  arc_capacity_408  -30
    arc_0_3_11  connected_order_arc_409  -14
    arc_0_3_11  out_degree_684  1
    arc_0_3_11  in_degree_724  1
    arc_0_3_11  original_T_including_depot_unload_757  6.2279118029742506e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_11  arc_capacity_408  1
    load_0_3_11  segment_load_conservation_688  1
    load_0_3_11  free_load_conservation_728  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_12  arc_capacity_410  -30
    arc_0_3_12  connected_order_arc_411  -14
    arc_0_3_12  out_degree_684  1
    arc_0_3_12  in_degree_730  1
    arc_0_3_12  original_T_including_depot_unload_757  2.6797194604092651e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_12  arc_capacity_410  1
    load_0_3_12  segment_load_conservation_688  1
    load_0_3_12  free_load_conservation_734  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_13  arc_capacity_412  -30
    arc_0_3_13  connected_order_arc_413  -14
    arc_0_3_13  out_degree_684  1
    arc_0_3_13  in_degree_736  1
    arc_0_3_13  original_T_including_depot_unload_757  2.8260257937815851e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_13  arc_capacity_412  1
    load_0_3_13  segment_load_conservation_688  1
    load_0_3_13  free_load_conservation_740  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_14  arc_capacity_414  -30
    arc_0_3_14  connected_order_arc_415  -14
    arc_0_3_14  out_degree_684  1
    arc_0_3_14  in_degree_742  1
    arc_0_3_14  original_T_including_depot_unload_757  8.2145202724109538e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_14  arc_capacity_414  1
    load_0_3_14  segment_load_conservation_688  1
    load_0_3_14  free_load_conservation_746  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_15  arc_capacity_416  -30
    arc_0_3_15  connected_order_arc_417  -14
    arc_0_3_15  out_degree_684  1
    arc_0_3_15  in_degree_748  1
    arc_0_3_15  original_T_including_depot_unload_757  4.3257823465305182e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_15  arc_capacity_416  1
    load_0_3_15  segment_load_conservation_688  1
    load_0_3_15  free_load_conservation_752  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_0  arc_capacity_418  -30
    arc_0_4_0  depot_return_or_bypass_669  1
    arc_0_4_0  out_degree_691  1
    arc_0_4_0  original_T_including_depot_unload_757  1.1473865007565566e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_0  arc_capacity_418  1
    load_0_4_0  segment_load_conservation_695  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_1  arc_capacity_419  -30
    arc_0_4_1  connected_order_arc_420  -14
    arc_0_4_1  in_degree_671  1
    arc_0_4_1  out_degree_691  1
    arc_0_4_1  original_T_including_depot_unload_757  1.4558134627196880e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_1  arc_capacity_419  1
    load_0_4_1  segment_load_conservation_674  -1
    load_0_4_1  segment_prefix_lb_675  1
    load_0_4_1  segment_prefix_ub_676  1
    load_0_4_1  segment_load_conservation_695  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_2  arc_capacity_421  -30
    arc_0_4_2  connected_order_arc_422  -14
    arc_0_4_2  in_degree_678  1
    arc_0_4_2  out_degree_691  1
    arc_0_4_2  original_T_including_depot_unload_757  7.8604521666483390e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_2  arc_capacity_421  1
    load_0_4_2  segment_load_conservation_681  -1
    load_0_4_2  segment_prefix_lb_682  1
    load_0_4_2  segment_prefix_ub_683  1
    load_0_4_2  segment_load_conservation_695  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_3  arc_capacity_423  -30
    arc_0_4_3  connected_order_arc_424  -14
    arc_0_4_3  in_degree_685  1
    arc_0_4_3  out_degree_691  1
    arc_0_4_3  original_T_including_depot_unload_757  4.4158457011124148e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_3  arc_capacity_423  1
    load_0_4_3  segment_load_conservation_688  -1
    load_0_4_3  segment_prefix_lb_689  1
    load_0_4_3  segment_prefix_ub_690  1
    load_0_4_3  segment_load_conservation_695  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_5  arc_capacity_425  -30
    arc_0_4_5  connected_order_arc_426  -14
    arc_0_4_5  out_degree_691  1
    arc_0_4_5  in_degree_699  1
    arc_0_4_5  original_T_including_depot_unload_757  7.3627521985972965e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_5  arc_capacity_425  1
    load_0_4_5  segment_load_conservation_695  1
    load_0_4_5  segment_load_conservation_702  -1
    load_0_4_5  segment_prefix_lb_703  1
    load_0_4_5  segment_prefix_ub_704  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_8  arc_capacity_427  -30
    arc_0_4_8  connected_order_arc_428  -14
    arc_0_4_8  out_degree_691  1
    arc_0_4_8  in_degree_706  1
    arc_0_4_8  original_T_including_depot_unload_757  4.9817963927689311e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_8  arc_capacity_427  1
    load_0_4_8  segment_load_conservation_695  1
    load_0_4_8  free_load_conservation_710  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_9  arc_capacity_429  -30
    arc_0_4_9  connected_order_arc_430  -14
    arc_0_4_9  out_degree_691  1
    arc_0_4_9  in_degree_712  1
    arc_0_4_9  original_T_including_depot_unload_757  3.7295617536174859e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_9  arc_capacity_429  1
    load_0_4_9  segment_load_conservation_695  1
    load_0_4_9  free_load_conservation_716  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_10  arc_capacity_431  -30
    arc_0_4_10  connected_order_arc_432  -14
    arc_0_4_10  out_degree_691  1
    arc_0_4_10  in_degree_718  1
    arc_0_4_10  original_T_including_depot_unload_757  2.9878665461125843e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_10  arc_capacity_431  1
    load_0_4_10  segment_load_conservation_695  1
    load_0_4_10  free_load_conservation_722  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_11  arc_capacity_433  -30
    arc_0_4_11  connected_order_arc_434  -14
    arc_0_4_11  out_degree_691  1
    arc_0_4_11  in_degree_724  1
    arc_0_4_11  original_T_including_depot_unload_757  6.4057623819624155e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_11  arc_capacity_433  1
    load_0_4_11  segment_load_conservation_695  1
    load_0_4_11  free_load_conservation_728  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_12  arc_capacity_435  -30
    arc_0_4_12  connected_order_arc_436  -14
    arc_0_4_12  out_degree_691  1
    arc_0_4_12  in_degree_730  1
    arc_0_4_12  original_T_including_depot_unload_757  2.9747397208089205e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_12  arc_capacity_435  1
    load_0_4_12  segment_load_conservation_695  1
    load_0_4_12  free_load_conservation_734  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_13  arc_capacity_437  -30
    arc_0_4_13  connected_order_arc_438  -14
    arc_0_4_13  out_degree_691  1
    arc_0_4_13  in_degree_736  1
    arc_0_4_13  original_T_including_depot_unload_757  4.5058965368847572e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_13  arc_capacity_437  1
    load_0_4_13  segment_load_conservation_695  1
    load_0_4_13  free_load_conservation_740  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_14  arc_capacity_439  -30
    arc_0_4_14  connected_order_arc_440  -14
    arc_0_4_14  out_degree_691  1
    arc_0_4_14  in_degree_742  1
    arc_0_4_14  original_T_including_depot_unload_757  8.2982882938703278e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_14  arc_capacity_439  1
    load_0_4_14  segment_load_conservation_695  1
    load_0_4_14  free_load_conservation_746  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_15  arc_capacity_441  -30
    arc_0_4_15  connected_order_arc_442  -14
    arc_0_4_15  out_degree_691  1
    arc_0_4_15  in_degree_748  1
    arc_0_4_15  original_T_including_depot_unload_757  2.2655310037545112e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_15  arc_capacity_441  1
    load_0_4_15  segment_load_conservation_695  1
    load_0_4_15  free_load_conservation_752  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_0  arc_capacity_443  -30
    arc_0_5_0  depot_return_or_bypass_669  1
    arc_0_5_0  out_degree_698  1
    arc_0_5_0  original_T_including_depot_unload_757  4.1588440854375170e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_0  arc_capacity_443  1
    load_0_5_0  segment_load_conservation_702  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_1  arc_capacity_444  -30
    arc_0_5_1  connected_order_arc_445  -14
    arc_0_5_1  in_degree_671  1
    arc_0_5_1  out_degree_698  1
    arc_0_5_1  original_T_including_depot_unload_757  7.2365484333226220e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_1  arc_capacity_444  1
    load_0_5_1  segment_load_conservation_674  -1
    load_0_5_1  segment_prefix_lb_675  1
    load_0_5_1  segment_prefix_ub_676  1
    load_0_5_1  segment_load_conservation_702  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_2  arc_capacity_446  -30
    arc_0_5_2  connected_order_arc_447  -14
    arc_0_5_2  in_degree_678  1
    arc_0_5_2  out_degree_698  1
    arc_0_5_2  original_T_including_depot_unload_757  2.6178398366762252e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_2  arc_capacity_446  1
    load_0_5_2  segment_load_conservation_681  -1
    load_0_5_2  segment_prefix_lb_682  1
    load_0_5_2  segment_prefix_ub_683  1
    load_0_5_2  segment_load_conservation_702  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_3  arc_capacity_448  -30
    arc_0_5_3  connected_order_arc_449  -14
    arc_0_5_3  in_degree_685  1
    arc_0_5_3  out_degree_698  1
    arc_0_5_3  original_T_including_depot_unload_757  8.2210727717430609e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_3  arc_capacity_448  1
    load_0_5_3  segment_load_conservation_688  -1
    load_0_5_3  segment_prefix_lb_689  1
    load_0_5_3  segment_prefix_ub_690  1
    load_0_5_3  segment_load_conservation_702  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_4  arc_capacity_450  -30
    arc_0_5_4  connected_order_arc_451  -14
    arc_0_5_4  in_degree_692  1
    arc_0_5_4  out_degree_698  1
    arc_0_5_4  original_T_including_depot_unload_757  7.3627521985972965e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_4  arc_capacity_450  1
    load_0_5_4  segment_load_conservation_695  -1
    load_0_5_4  segment_prefix_lb_696  1
    load_0_5_4  segment_prefix_ub_697  1
    load_0_5_4  segment_load_conservation_702  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_8  arc_capacity_452  -30
    arc_0_5_8  connected_order_arc_453  -14
    arc_0_5_8  out_degree_698  1
    arc_0_5_8  in_degree_706  1
    arc_0_5_8  original_T_including_depot_unload_757  3.4593676445964553e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_8  arc_capacity_452  1
    load_0_5_8  segment_load_conservation_702  1
    load_0_5_8  free_load_conservation_710  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_9  arc_capacity_454  -30
    arc_0_5_9  connected_order_arc_455  -14
    arc_0_5_9  out_degree_698  1
    arc_0_5_9  in_degree_712  1
    arc_0_5_9  original_T_including_depot_unload_757  4.1180717113418365e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_9  arc_capacity_454  1
    load_0_5_9  segment_load_conservation_702  1
    load_0_5_9  free_load_conservation_716  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_10  arc_capacity_456  -30
    arc_0_5_10  connected_order_arc_457  -14
    arc_0_5_10  out_degree_698  1
    arc_0_5_10  in_degree_718  1
    arc_0_5_10  original_T_including_depot_unload_757  2.5651522766561479e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_10  arc_capacity_456  1
    load_0_5_10  segment_load_conservation_702  1
    load_0_5_10  free_load_conservation_722  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_11  arc_capacity_458  -30
    arc_0_5_11  connected_order_arc_459  -14
    arc_0_5_11  out_degree_698  1
    arc_0_5_11  in_degree_724  1
    arc_0_5_11  original_T_including_depot_unload_757  2.2661537412294956e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_11  arc_capacity_458  1
    load_0_5_11  segment_load_conservation_702  1
    load_0_5_11  free_load_conservation_728  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_12  arc_capacity_460  -30
    arc_0_5_12  connected_order_arc_461  -14
    arc_0_5_12  out_degree_698  1
    arc_0_5_12  in_degree_730  1
    arc_0_5_12  original_T_including_depot_unload_757  2.4543912353372671e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_12  arc_capacity_460  1
    load_0_5_12  segment_load_conservation_702  1
    load_0_5_12  free_load_conservation_734  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_13  arc_capacity_462  -30
    arc_0_5_13  connected_order_arc_463  -14
    arc_0_5_13  out_degree_698  1
    arc_0_5_13  in_degree_736  1
    arc_0_5_13  original_T_including_depot_unload_757  5.4626430531406254e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_13  arc_capacity_462  1
    load_0_5_13  segment_load_conservation_702  1
    load_0_5_13  free_load_conservation_740  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_14  arc_capacity_464  -30
    arc_0_5_14  connected_order_arc_465  -14
    arc_0_5_14  out_degree_698  1
    arc_0_5_14  in_degree_742  1
    arc_0_5_14  original_T_including_depot_unload_757  1.7839442696984972e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_14  arc_capacity_464  1
    load_0_5_14  segment_load_conservation_702  1
    load_0_5_14  free_load_conservation_746  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_15  arc_capacity_466  -30
    arc_0_5_15  connected_order_arc_467  -14
    arc_0_5_15  out_degree_698  1
    arc_0_5_15  in_degree_748  1
    arc_0_5_15  original_T_including_depot_unload_757  516.598297486096
    MARKER    'MARKER'                 'INTEND'
    load_0_5_15  arc_capacity_466  1
    load_0_5_15  segment_load_conservation_702  1
    load_0_5_15  free_load_conservation_752  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_0  arc_capacity_468  -30
    arc_0_8_0  depot_return_or_bypass_669  1
    arc_0_8_0  out_degree_705  1
    arc_0_8_0  original_T_including_depot_unload_757  7.4412496590753551e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_0  arc_capacity_468  1
    load_0_8_0  free_load_conservation_710  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_1  arc_capacity_469  -30
    arc_0_8_1  connected_order_arc_470  -14
    arc_0_8_1  in_degree_671  1
    arc_0_8_1  out_degree_705  1
    arc_0_8_1  original_T_including_depot_unload_757  1.0007616644945284e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_8_1  arc_capacity_469  1
    load_0_8_1  segment_load_conservation_674  -1
    load_0_8_1  segment_prefix_lb_675  1
    load_0_8_1  segment_prefix_ub_676  1
    load_0_8_1  free_load_conservation_710  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_2  arc_capacity_471  -30
    arc_0_8_2  connected_order_arc_472  -14
    arc_0_8_2  in_degree_678  1
    arc_0_8_2  out_degree_705  1
    arc_0_8_2  original_T_including_depot_unload_757  291.965990421835
    MARKER    'MARKER'                 'INTEND'
    load_0_8_2  arc_capacity_471  1
    load_0_8_2  segment_load_conservation_681  -1
    load_0_8_2  segment_prefix_lb_682  1
    load_0_8_2  segment_prefix_ub_683  1
    load_0_8_2  free_load_conservation_710  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_3  arc_capacity_473  -30
    arc_0_8_3  connected_order_arc_474  -14
    arc_0_8_3  in_degree_685  1
    arc_0_8_3  out_degree_705  1
    arc_0_8_3  original_T_including_depot_unload_757  4.7721499161748335e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_3  arc_capacity_473  1
    load_0_8_3  segment_load_conservation_688  -1
    load_0_8_3  segment_prefix_lb_689  1
    load_0_8_3  segment_prefix_ub_690  1
    load_0_8_3  free_load_conservation_710  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_4  arc_capacity_475  -30
    arc_0_8_4  connected_order_arc_476  -14
    arc_0_8_4  in_degree_692  1
    arc_0_8_4  out_degree_705  1
    arc_0_8_4  original_T_including_depot_unload_757  4.9817963927689311e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_4  arc_capacity_475  1
    load_0_8_4  segment_load_conservation_695  -1
    load_0_8_4  segment_prefix_lb_696  1
    load_0_8_4  segment_prefix_ub_697  1
    load_0_8_4  free_load_conservation_710  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_5  arc_capacity_477  -30
    arc_0_8_5  connected_order_arc_478  -14
    arc_0_8_5  in_degree_699  1
    arc_0_8_5  out_degree_705  1
    arc_0_8_5  original_T_including_depot_unload_757  3.4593676445964553e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_5  arc_capacity_477  1
    load_0_8_5  segment_load_conservation_702  -1
    load_0_8_5  segment_prefix_lb_703  1
    load_0_8_5  segment_prefix_ub_704  1
    load_0_8_5  free_load_conservation_710  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_9  arc_capacity_479  -30
    arc_0_8_9  connected_order_arc_480  -14
    arc_0_8_9  out_degree_705  1
    arc_0_8_9  in_degree_712  1
    arc_0_8_9  original_T_including_depot_unload_757  1.2673640125672841e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_9  arc_capacity_479  1
    load_0_8_9  free_load_conservation_710  1
    load_0_8_9  free_load_conservation_716  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_10  arc_capacity_481  -30
    arc_0_8_10  connected_order_arc_482  -14
    arc_0_8_10  out_degree_705  1
    arc_0_8_10  in_degree_718  1
    arc_0_8_10  original_T_including_depot_unload_757  2.8807002034504962e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_8_10  arc_capacity_481  1
    load_0_8_10  free_load_conservation_710  1
    load_0_8_10  free_load_conservation_722  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_11  arc_capacity_483  -30
    arc_0_8_11  connected_order_arc_484  -14
    arc_0_8_11  out_degree_705  1
    arc_0_8_11  in_degree_724  1
    arc_0_8_11  original_T_including_depot_unload_757  1.5701156446555925e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_11  arc_capacity_483  1
    load_0_8_11  free_load_conservation_710  1
    load_0_8_11  free_load_conservation_728  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_12  arc_capacity_485  -30
    arc_0_8_12  connected_order_arc_486  -14
    arc_0_8_12  out_degree_705  1
    arc_0_8_12  in_degree_730  1
    arc_0_8_12  original_T_including_depot_unload_757  2.4992063774241742e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_8_12  arc_capacity_485  1
    load_0_8_12  free_load_conservation_710  1
    load_0_8_12  free_load_conservation_734  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_13  arc_capacity_487  -30
    arc_0_8_13  connected_order_arc_488  -14
    arc_0_8_13  out_degree_705  1
    arc_0_8_13  in_degree_736  1
    arc_0_8_13  original_T_including_depot_unload_757  2.0082608212298291e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_13  arc_capacity_487  1
    load_0_8_13  free_load_conservation_710  1
    load_0_8_13  free_load_conservation_740  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_14  arc_capacity_489  -30
    arc_0_8_14  connected_order_arc_490  -14
    arc_0_8_14  out_degree_705  1
    arc_0_8_14  in_degree_742  1
    arc_0_8_14  original_T_including_depot_unload_757  3.6114004430677619e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_14  arc_capacity_489  1
    load_0_8_14  free_load_conservation_710  1
    load_0_8_14  free_load_conservation_746  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_15  arc_capacity_491  -30
    arc_0_8_15  connected_order_arc_492  -14
    arc_0_8_15  out_degree_705  1
    arc_0_8_15  in_degree_748  1
    arc_0_8_15  original_T_including_depot_unload_757  2.8072002002622634e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_15  arc_capacity_491  1
    load_0_8_15  free_load_conservation_710  1
    load_0_8_15  free_load_conservation_752  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_0  arc_capacity_493  -30
    arc_0_9_0  depot_return_or_bypass_669  1
    arc_0_9_0  out_degree_711  1
    arc_0_9_0  original_T_including_depot_unload_757  8.2548955430739034e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_0  arc_capacity_493  1
    load_0_9_0  free_load_conservation_716  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_1  arc_capacity_494  -30
    arc_0_9_1  connected_order_arc_495  -14
    arc_0_9_1  in_degree_671  1
    arc_0_9_1  out_degree_711  1
    arc_0_9_1  original_T_including_depot_unload_757  1.1046832181240914e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_1  arc_capacity_494  1
    load_0_9_1  segment_load_conservation_674  -1
    load_0_9_1  segment_prefix_lb_675  1
    load_0_9_1  segment_prefix_ub_676  1
    load_0_9_1  free_load_conservation_716  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_2  arc_capacity_496  -30
    arc_0_9_2  connected_order_arc_497  -14
    arc_0_9_2  in_degree_678  1
    arc_0_9_2  out_degree_711  1
    arc_0_9_2  original_T_including_depot_unload_757  4.1346687597344868e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_2  arc_capacity_496  1
    load_0_9_2  segment_load_conservation_681  -1
    load_0_9_2  segment_prefix_lb_682  1
    load_0_9_2  segment_prefix_ub_683  1
    load_0_9_2  free_load_conservation_716  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_3  arc_capacity_498  -30
    arc_0_9_3  connected_order_arc_499  -14
    arc_0_9_3  in_degree_685  1
    arc_0_9_3  out_degree_711  1
    arc_0_9_3  original_T_including_depot_unload_757  4.3124580937307496e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_3  arc_capacity_498  1
    load_0_9_3  segment_load_conservation_688  -1
    load_0_9_3  segment_prefix_lb_689  1
    load_0_9_3  segment_prefix_ub_690  1
    load_0_9_3  free_load_conservation_716  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_4  arc_capacity_500  -30
    arc_0_9_4  connected_order_arc_501  -14
    arc_0_9_4  in_degree_692  1
    arc_0_9_4  out_degree_711  1
    arc_0_9_4  original_T_including_depot_unload_757  3.7295617536174859e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_4  arc_capacity_500  1
    load_0_9_4  segment_load_conservation_695  -1
    load_0_9_4  segment_prefix_lb_696  1
    load_0_9_4  segment_prefix_ub_697  1
    load_0_9_4  free_load_conservation_716  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_5  arc_capacity_502  -30
    arc_0_9_5  connected_order_arc_503  -14
    arc_0_9_5  in_degree_699  1
    arc_0_9_5  out_degree_711  1
    arc_0_9_5  original_T_including_depot_unload_757  4.1180717113418365e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_5  arc_capacity_502  1
    load_0_9_5  segment_load_conservation_702  -1
    load_0_9_5  segment_prefix_lb_703  1
    load_0_9_5  segment_prefix_ub_704  1
    load_0_9_5  free_load_conservation_716  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_8  arc_capacity_504  -30
    arc_0_9_8  connected_order_arc_505  -14
    arc_0_9_8  in_degree_706  1
    arc_0_9_8  out_degree_711  1
    arc_0_9_8  original_T_including_depot_unload_757  1.2673640125672841e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_8  arc_capacity_504  1
    load_0_9_8  free_load_conservation_710  -1
    load_0_9_8  free_load_conservation_716  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_10  arc_capacity_506  -30
    arc_0_9_10  connected_order_arc_507  -14
    arc_0_9_10  out_degree_711  1
    arc_0_9_10  in_degree_718  1
    arc_0_9_10  original_T_including_depot_unload_757  2.8834086639088187e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_10  arc_capacity_506  1
    load_0_9_10  free_load_conservation_716  1
    load_0_9_10  free_load_conservation_722  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_11  arc_capacity_508  -30
    arc_0_9_11  connected_order_arc_509  -14
    arc_0_9_11  out_degree_711  1
    arc_0_9_11  in_degree_724  1
    arc_0_9_11  original_T_including_depot_unload_757  2.6991456262177837e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_11  arc_capacity_508  1
    load_0_9_11  free_load_conservation_716  1
    load_0_9_11  free_load_conservation_728  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_12  arc_capacity_510  -30
    arc_0_9_12  connected_order_arc_511  -14
    arc_0_9_12  out_degree_711  1
    arc_0_9_12  in_degree_730  1
    arc_0_9_12  original_T_including_depot_unload_757  2.6235983504802839e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_12  arc_capacity_510  1
    load_0_9_12  free_load_conservation_716  1
    load_0_9_12  free_load_conservation_734  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_13  arc_capacity_512  -30
    arc_0_9_13  connected_order_arc_513  -14
    arc_0_9_13  out_degree_711  1
    arc_0_9_13  in_degree_736  1
    arc_0_9_13  original_T_including_depot_unload_757  2.0241950709354862e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_13  arc_capacity_512  1
    load_0_9_13  free_load_conservation_716  1
    load_0_9_13  free_load_conservation_740  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_14  arc_capacity_514  -30
    arc_0_9_14  connected_order_arc_515  -14
    arc_0_9_14  out_degree_711  1
    arc_0_9_14  in_degree_742  1
    arc_0_9_14  original_T_including_depot_unload_757  4.6739130846957909e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_14  arc_capacity_514  1
    load_0_9_14  free_load_conservation_716  1
    load_0_9_14  free_load_conservation_746  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_15  arc_capacity_516  -30
    arc_0_9_15  connected_order_arc_517  -14
    arc_0_9_15  out_degree_711  1
    arc_0_9_15  in_degree_748  1
    arc_0_9_15  original_T_including_depot_unload_757  1.5413712102626312e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_15  arc_capacity_516  1
    load_0_9_15  free_load_conservation_716  1
    load_0_9_15  free_load_conservation_752  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_0  arc_capacity_518  -30
    arc_0_10_0  depot_return_or_bypass_669  1
    arc_0_10_0  out_degree_717  1
    arc_0_10_0  original_T_including_depot_unload_757  2.3234267380118886e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_0  arc_capacity_518  1
    load_0_10_0  free_load_conservation_722  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_1  arc_capacity_519  -30
    arc_0_10_1  connected_order_arc_520  -14
    arc_0_10_1  in_degree_671  1
    arc_0_10_1  out_degree_717  1
    arc_0_10_1  original_T_including_depot_unload_757  2.4160844235310037e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_1  arc_capacity_519  1
    load_0_10_1  segment_load_conservation_674  -1
    load_0_10_1  segment_prefix_lb_675  1
    load_0_10_1  segment_prefix_ub_676  1
    load_0_10_1  free_load_conservation_722  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_2  arc_capacity_521  -30
    arc_0_10_2  connected_order_arc_522  -14
    arc_0_10_2  in_degree_678  1
    arc_0_10_2  out_degree_717  1
    arc_0_10_2  original_T_including_depot_unload_757  2.7957126389480295e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_2  arc_capacity_521  1
    load_0_10_2  segment_load_conservation_681  -1
    load_0_10_2  segment_prefix_lb_682  1
    load_0_10_2  segment_prefix_ub_683  1
    load_0_10_2  free_load_conservation_722  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_3  arc_capacity_523  -30
    arc_0_10_3  connected_order_arc_524  -14
    arc_0_10_3  in_degree_685  1
    arc_0_10_3  out_degree_717  1
    arc_0_10_3  original_T_including_depot_unload_757  3.3076115257178203e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_3  arc_capacity_523  1
    load_0_10_3  segment_load_conservation_688  -1
    load_0_10_3  segment_prefix_lb_689  1
    load_0_10_3  segment_prefix_ub_690  1
    load_0_10_3  free_load_conservation_722  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_4  arc_capacity_525  -30
    arc_0_10_4  connected_order_arc_526  -14
    arc_0_10_4  in_degree_692  1
    arc_0_10_4  out_degree_717  1
    arc_0_10_4  original_T_including_depot_unload_757  2.9878665461125843e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_4  arc_capacity_525  1
    load_0_10_4  segment_load_conservation_695  -1
    load_0_10_4  segment_prefix_lb_696  1
    load_0_10_4  segment_prefix_ub_697  1
    load_0_10_4  free_load_conservation_722  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_5  arc_capacity_527  -30
    arc_0_10_5  connected_order_arc_528  -14
    arc_0_10_5  in_degree_699  1
    arc_0_10_5  out_degree_717  1
    arc_0_10_5  original_T_including_depot_unload_757  2.5651522766561479e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_5  arc_capacity_527  1
    load_0_10_5  segment_load_conservation_702  -1
    load_0_10_5  segment_prefix_lb_703  1
    load_0_10_5  segment_prefix_ub_704  1
    load_0_10_5  free_load_conservation_722  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_8  arc_capacity_529  -30
    arc_0_10_8  connected_order_arc_530  -14
    arc_0_10_8  in_degree_706  1
    arc_0_10_8  out_degree_717  1
    arc_0_10_8  original_T_including_depot_unload_757  2.8807002034504962e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_8  arc_capacity_529  1
    load_0_10_8  free_load_conservation_710  -1
    load_0_10_8  free_load_conservation_722  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_9  arc_capacity_531  -30
    arc_0_10_9  connected_order_arc_532  -14
    arc_0_10_9  in_degree_712  1
    arc_0_10_9  out_degree_717  1
    arc_0_10_9  original_T_including_depot_unload_757  2.8834086639088187e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_9  arc_capacity_531  1
    load_0_10_9  free_load_conservation_716  -1
    load_0_10_9  free_load_conservation_722  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_11  arc_capacity_533  -30
    arc_0_10_11  connected_order_arc_534  -14
    arc_0_10_11  out_degree_717  1
    arc_0_10_11  in_degree_724  1
    arc_0_10_11  original_T_including_depot_unload_757  2.7910579461472848e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_11  arc_capacity_533  1
    load_0_10_11  free_load_conservation_722  1
    load_0_10_11  free_load_conservation_728  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_12  arc_capacity_535  -30
    arc_0_10_12  connected_order_arc_536  -14
    arc_0_10_12  out_degree_717  1
    arc_0_10_12  in_degree_730  1
    arc_0_10_12  original_T_including_depot_unload_757  4.1686506413165080e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_12  arc_capacity_535  1
    load_0_10_12  free_load_conservation_722  1
    load_0_10_12  free_load_conservation_734  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_13  arc_capacity_537  -30
    arc_0_10_13  connected_order_arc_538  -14
    arc_0_10_13  out_degree_717  1
    arc_0_10_13  in_degree_736  1
    arc_0_10_13  original_T_including_depot_unload_757  3.0726580305165480e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_13  arc_capacity_537  1
    load_0_10_13  free_load_conservation_722  1
    load_0_10_13  free_load_conservation_740  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_14  arc_capacity_539  -30
    arc_0_10_14  connected_order_arc_540  -14
    arc_0_10_14  out_degree_717  1
    arc_0_10_14  in_degree_742  1
    arc_0_10_14  original_T_including_depot_unload_757  2.6728511574036233e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_14  arc_capacity_539  1
    load_0_10_14  free_load_conservation_722  1
    load_0_10_14  free_load_conservation_746  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_15  arc_capacity_541  -30
    arc_0_10_15  connected_order_arc_542  -14
    arc_0_10_15  out_degree_717  1
    arc_0_10_15  in_degree_748  1
    arc_0_10_15  original_T_including_depot_unload_757  2.8839695646198670e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_15  arc_capacity_541  1
    load_0_10_15  free_load_conservation_722  1
    load_0_10_15  free_load_conservation_752  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_0  arc_capacity_543  -30
    arc_0_11_0  depot_return_or_bypass_669  1
    arc_0_11_0  out_degree_723  1
    arc_0_11_0  original_T_including_depot_unload_757  5.9631731642067359e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_11_0  arc_capacity_543  1
    load_0_11_0  free_load_conservation_728  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_1  arc_capacity_544  -30
    arc_0_11_1  connected_order_arc_545  -14
    arc_0_11_1  in_degree_671  1
    arc_0_11_1  out_degree_723  1
    arc_0_11_1  original_T_including_depot_unload_757  8.4376826601758887e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_11_1  arc_capacity_544  1
    load_0_11_1  segment_load_conservation_674  -1
    load_0_11_1  segment_prefix_lb_675  1
    load_0_11_1  segment_prefix_ub_676  1
    load_0_11_1  free_load_conservation_728  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_2  arc_capacity_546  -30
    arc_0_11_2  connected_order_arc_547  -14
    arc_0_11_2  in_degree_678  1
    arc_0_11_2  out_degree_723  1
    arc_0_11_2  original_T_including_depot_unload_757  1.4810770279475858e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_11_2  arc_capacity_546  1
    load_0_11_2  segment_load_conservation_681  -1
    load_0_11_2  segment_prefix_lb_682  1
    load_0_11_2  segment_prefix_ub_683  1
    load_0_11_2  free_load_conservation_728  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_3  arc_capacity_548  -30
    arc_0_11_3  connected_order_arc_549  -14
    arc_0_11_3  in_degree_685  1
    arc_0_11_3  out_degree_723  1
    arc_0_11_3  original_T_including_depot_unload_757  6.2279118029742506e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_11_3  arc_capacity_548  1
    load_0_11_3  segment_load_conservation_688  -1
    load_0_11_3  segment_prefix_lb_689  1
    load_0_11_3  segment_prefix_ub_690  1
    load_0_11_3  free_load_conservation_728  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_4  arc_capacity_550  -30
    arc_0_11_4  connected_order_arc_551  -14
    arc_0_11_4  in_degree_692  1
    arc_0_11_4  out_degree_723  1
    arc_0_11_4  original_T_including_depot_unload_757  6.4057623819624155e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_11_4  arc_capacity_550  1
    load_0_11_4  segment_load_conservation_695  -1
    load_0_11_4  segment_prefix_lb_696  1
    load_0_11_4  segment_prefix_ub_697  1
    load_0_11_4  free_load_conservation_728  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_5  arc_capacity_552  -30
    arc_0_11_5  connected_order_arc_553  -14
    arc_0_11_5  in_degree_699  1
    arc_0_11_5  out_degree_723  1
    arc_0_11_5  original_T_including_depot_unload_757  2.2661537412294956e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_11_5  arc_capacity_552  1
    load_0_11_5  segment_load_conservation_702  -1
    load_0_11_5  segment_prefix_lb_703  1
    load_0_11_5  segment_prefix_ub_704  1
    load_0_11_5  free_load_conservation_728  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_8  arc_capacity_554  -30
    arc_0_11_8  connected_order_arc_555  -14
    arc_0_11_8  in_degree_706  1
    arc_0_11_8  out_degree_723  1
    arc_0_11_8  original_T_including_depot_unload_757  1.5701156446555925e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_11_8  arc_capacity_554  1
    load_0_11_8  free_load_conservation_710  -1
    load_0_11_8  free_load_conservation_728  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_9  arc_capacity_556  -30
    arc_0_11_9  connected_order_arc_557  -14
    arc_0_11_9  in_degree_712  1
    arc_0_11_9  out_degree_723  1
    arc_0_11_9  original_T_including_depot_unload_757  2.6991456262177837e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_11_9  arc_capacity_556  1
    load_0_11_9  free_load_conservation_716  -1
    load_0_11_9  free_load_conservation_728  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_10  arc_capacity_558  -30
    arc_0_11_10  connected_order_arc_559  -14
    arc_0_11_10  in_degree_718  1
    arc_0_11_10  out_degree_723  1
    arc_0_11_10  original_T_including_depot_unload_757  2.7910579461472848e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_10  arc_capacity_558  1
    load_0_11_10  free_load_conservation_722  -1
    load_0_11_10  free_load_conservation_728  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_12  arc_capacity_560  -30
    arc_0_11_12  connected_order_arc_561  -14
    arc_0_11_12  out_degree_723  1
    arc_0_11_12  in_degree_730  1
    arc_0_11_12  original_T_including_depot_unload_757  2.3958340327791907e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_12  arc_capacity_560  1
    load_0_11_12  free_load_conservation_728  1
    load_0_11_12  free_load_conservation_734  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_13  arc_capacity_562  -30
    arc_0_11_13  connected_order_arc_563  -14
    arc_0_11_13  out_degree_723  1
    arc_0_11_13  in_degree_736  1
    arc_0_11_13  original_T_including_depot_unload_757  3.4037893208114895e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_11_13  arc_capacity_562  1
    load_0_11_13  free_load_conservation_728  1
    load_0_11_13  free_load_conservation_740  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_14  arc_capacity_564  -30
    arc_0_11_14  connected_order_arc_565  -14
    arc_0_11_14  out_degree_723  1
    arc_0_11_14  in_degree_742  1
    arc_0_11_14  original_T_including_depot_unload_757  2.0430160967046345e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_11_14  arc_capacity_564  1
    load_0_11_14  free_load_conservation_728  1
    load_0_11_14  free_load_conservation_746  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_15  arc_capacity_566  -30
    arc_0_11_15  connected_order_arc_567  -14
    arc_0_11_15  out_degree_723  1
    arc_0_11_15  in_degree_748  1
    arc_0_11_15  original_T_including_depot_unload_757  4.1557375918514475e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_11_15  arc_capacity_566  1
    load_0_11_15  free_load_conservation_728  1
    load_0_11_15  free_load_conservation_752  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_0  arc_capacity_568  -30
    arc_0_12_0  depot_return_or_bypass_669  1
    arc_0_12_0  out_degree_729  1
    arc_0_12_0  original_T_including_depot_unload_757  2.2866763971369810e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_0  arc_capacity_568  1
    load_0_12_0  free_load_conservation_734  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_1  arc_capacity_569  -30
    arc_0_12_1  connected_order_arc_570  -14
    arc_0_12_1  in_degree_671  1
    arc_0_12_1  out_degree_729  1
    arc_0_12_1  original_T_including_depot_unload_757  1.9791430726365086e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_1  arc_capacity_569  1
    load_0_12_1  segment_load_conservation_674  -1
    load_0_12_1  segment_prefix_lb_675  1
    load_0_12_1  segment_prefix_ub_676  1
    load_0_12_1  free_load_conservation_734  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_2  arc_capacity_571  -30
    arc_0_12_2  connected_order_arc_572  -14
    arc_0_12_2  in_degree_678  1
    arc_0_12_2  out_degree_729  1
    arc_0_12_2  original_T_including_depot_unload_757  2.2541698308553673e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_2  arc_capacity_571  1
    load_0_12_2  segment_load_conservation_681  -1
    load_0_12_2  segment_prefix_lb_682  1
    load_0_12_2  segment_prefix_ub_683  1
    load_0_12_2  free_load_conservation_734  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_3  arc_capacity_573  -30
    arc_0_12_3  connected_order_arc_574  -14
    arc_0_12_3  in_degree_685  1
    arc_0_12_3  out_degree_729  1
    arc_0_12_3  original_T_including_depot_unload_757  2.6797194604092651e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_3  arc_capacity_573  1
    load_0_12_3  segment_load_conservation_688  -1
    load_0_12_3  segment_prefix_lb_689  1
    load_0_12_3  segment_prefix_ub_690  1
    load_0_12_3  free_load_conservation_734  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_4  arc_capacity_575  -30
    arc_0_12_4  connected_order_arc_576  -14
    arc_0_12_4  in_degree_692  1
    arc_0_12_4  out_degree_729  1
    arc_0_12_4  original_T_including_depot_unload_757  2.9747397208089205e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_4  arc_capacity_575  1
    load_0_12_4  segment_load_conservation_695  -1
    load_0_12_4  segment_prefix_lb_696  1
    load_0_12_4  segment_prefix_ub_697  1
    load_0_12_4  free_load_conservation_734  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_5  arc_capacity_577  -30
    arc_0_12_5  connected_order_arc_578  -14
    arc_0_12_5  in_degree_699  1
    arc_0_12_5  out_degree_729  1
    arc_0_12_5  original_T_including_depot_unload_757  2.4543912353372671e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_5  arc_capacity_577  1
    load_0_12_5  segment_load_conservation_702  -1
    load_0_12_5  segment_prefix_lb_703  1
    load_0_12_5  segment_prefix_ub_704  1
    load_0_12_5  free_load_conservation_734  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_8  arc_capacity_579  -30
    arc_0_12_8  connected_order_arc_580  -14
    arc_0_12_8  in_degree_706  1
    arc_0_12_8  out_degree_729  1
    arc_0_12_8  original_T_including_depot_unload_757  2.4992063774241742e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_8  arc_capacity_579  1
    load_0_12_8  free_load_conservation_710  -1
    load_0_12_8  free_load_conservation_734  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_9  arc_capacity_581  -30
    arc_0_12_9  connected_order_arc_582  -14
    arc_0_12_9  in_degree_712  1
    arc_0_12_9  out_degree_729  1
    arc_0_12_9  original_T_including_depot_unload_757  2.6235983504802839e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_9  arc_capacity_581  1
    load_0_12_9  free_load_conservation_716  -1
    load_0_12_9  free_load_conservation_734  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_10  arc_capacity_583  -30
    arc_0_12_10  connected_order_arc_584  -14
    arc_0_12_10  in_degree_718  1
    arc_0_12_10  out_degree_729  1
    arc_0_12_10  original_T_including_depot_unload_757  4.1686506413165080e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_10  arc_capacity_583  1
    load_0_12_10  free_load_conservation_722  -1
    load_0_12_10  free_load_conservation_734  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_11  arc_capacity_585  -30
    arc_0_12_11  connected_order_arc_586  -14
    arc_0_12_11  in_degree_724  1
    arc_0_12_11  out_degree_729  1
    arc_0_12_11  original_T_including_depot_unload_757  2.3958340327791907e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_11  arc_capacity_585  1
    load_0_12_11  free_load_conservation_728  -1
    load_0_12_11  free_load_conservation_734  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_13  arc_capacity_587  -30
    arc_0_12_13  connected_order_arc_588  -14
    arc_0_12_13  out_degree_729  1
    arc_0_12_13  in_degree_736  1
    arc_0_12_13  original_T_including_depot_unload_757  2.5292035468949002e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_13  arc_capacity_587  1
    load_0_12_13  free_load_conservation_734  1
    load_0_12_13  free_load_conservation_740  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_14  arc_capacity_589  -30
    arc_0_12_14  connected_order_arc_590  -14
    arc_0_12_14  out_degree_729  1
    arc_0_12_14  in_degree_742  1
    arc_0_12_14  original_T_including_depot_unload_757  2.2811398160464278e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_14  arc_capacity_589  1
    load_0_12_14  free_load_conservation_734  1
    load_0_12_14  free_load_conservation_746  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_15  arc_capacity_591  -30
    arc_0_12_15  connected_order_arc_592  -14
    arc_0_12_15  out_degree_729  1
    arc_0_12_15  in_degree_748  1
    arc_0_12_15  original_T_including_depot_unload_757  2.7766616410403444e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_15  arc_capacity_591  1
    load_0_12_15  free_load_conservation_734  1
    load_0_12_15  free_load_conservation_752  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_0  arc_capacity_593  -30
    arc_0_13_0  depot_return_or_bypass_669  1
    arc_0_13_0  out_degree_735  1
    arc_0_13_0  original_T_including_depot_unload_757  9.3659929340140741e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_0  arc_capacity_593  1
    load_0_13_0  free_load_conservation_740  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_1  arc_capacity_594  -30
    arc_0_13_1  connected_order_arc_595  -14
    arc_0_13_1  in_degree_671  1
    arc_0_13_1  out_degree_735  1
    arc_0_13_1  original_T_including_depot_unload_757  1.1702148343313254e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_1  arc_capacity_594  1
    load_0_13_1  segment_load_conservation_674  -1
    load_0_13_1  segment_prefix_lb_675  1
    load_0_13_1  segment_prefix_ub_676  1
    load_0_13_1  free_load_conservation_740  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_2  arc_capacity_596  -30
    arc_0_13_2  connected_order_arc_597  -14
    arc_0_13_2  in_degree_678  1
    arc_0_13_2  out_degree_735  1
    arc_0_13_2  original_T_including_depot_unload_757  4.4360641393992279e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_2  arc_capacity_596  1
    load_0_13_2  segment_load_conservation_681  -1
    load_0_13_2  segment_prefix_lb_682  1
    load_0_13_2  segment_prefix_ub_683  1
    load_0_13_2  free_load_conservation_740  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_3  arc_capacity_598  -30
    arc_0_13_3  connected_order_arc_599  -14
    arc_0_13_3  in_degree_685  1
    arc_0_13_3  out_degree_735  1
    arc_0_13_3  original_T_including_depot_unload_757  2.8260257937815851e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_3  arc_capacity_598  1
    load_0_13_3  segment_load_conservation_688  -1
    load_0_13_3  segment_prefix_lb_689  1
    load_0_13_3  segment_prefix_ub_690  1
    load_0_13_3  free_load_conservation_740  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_4  arc_capacity_600  -30
    arc_0_13_4  connected_order_arc_601  -14
    arc_0_13_4  in_degree_692  1
    arc_0_13_4  out_degree_735  1
    arc_0_13_4  original_T_including_depot_unload_757  4.5058965368847572e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_4  arc_capacity_600  1
    load_0_13_4  segment_load_conservation_695  -1
    load_0_13_4  segment_prefix_lb_696  1
    load_0_13_4  segment_prefix_ub_697  1
    load_0_13_4  free_load_conservation_740  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_5  arc_capacity_602  -30
    arc_0_13_5  connected_order_arc_603  -14
    arc_0_13_5  in_degree_699  1
    arc_0_13_5  out_degree_735  1
    arc_0_13_5  original_T_including_depot_unload_757  5.4626430531406254e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_5  arc_capacity_602  1
    load_0_13_5  segment_load_conservation_702  -1
    load_0_13_5  segment_prefix_lb_703  1
    load_0_13_5  segment_prefix_ub_704  1
    load_0_13_5  free_load_conservation_740  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_8  arc_capacity_604  -30
    arc_0_13_8  connected_order_arc_605  -14
    arc_0_13_8  in_degree_706  1
    arc_0_13_8  out_degree_735  1
    arc_0_13_8  original_T_including_depot_unload_757  2.0082608212298291e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_8  arc_capacity_604  1
    load_0_13_8  free_load_conservation_710  -1
    load_0_13_8  free_load_conservation_740  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_9  arc_capacity_606  -30
    arc_0_13_9  connected_order_arc_607  -14
    arc_0_13_9  in_degree_712  1
    arc_0_13_9  out_degree_735  1
    arc_0_13_9  original_T_including_depot_unload_757  2.0241950709354862e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_9  arc_capacity_606  1
    load_0_13_9  free_load_conservation_716  -1
    load_0_13_9  free_load_conservation_740  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_10  arc_capacity_608  -30
    arc_0_13_10  connected_order_arc_609  -14
    arc_0_13_10  in_degree_718  1
    arc_0_13_10  out_degree_735  1
    arc_0_13_10  original_T_including_depot_unload_757  3.0726580305165480e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_10  arc_capacity_608  1
    load_0_13_10  free_load_conservation_722  -1
    load_0_13_10  free_load_conservation_740  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_11  arc_capacity_610  -30
    arc_0_13_11  connected_order_arc_611  -14
    arc_0_13_11  in_degree_724  1
    arc_0_13_11  out_degree_735  1
    arc_0_13_11  original_T_including_depot_unload_757  3.4037893208114895e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_11  arc_capacity_610  1
    load_0_13_11  free_load_conservation_728  -1
    load_0_13_11  free_load_conservation_740  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_12  arc_capacity_612  -30
    arc_0_13_12  connected_order_arc_613  -14
    arc_0_13_12  in_degree_730  1
    arc_0_13_12  out_degree_735  1
    arc_0_13_12  original_T_including_depot_unload_757  2.5292035468949002e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_12  arc_capacity_612  1
    load_0_13_12  free_load_conservation_734  -1
    load_0_13_12  free_load_conservation_740  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_14  arc_capacity_614  -30
    arc_0_13_14  connected_order_arc_615  -14
    arc_0_13_14  out_degree_735  1
    arc_0_13_14  in_degree_742  1
    arc_0_13_14  original_T_including_depot_unload_757  5.3918604589472477e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_14  arc_capacity_614  1
    load_0_13_14  free_load_conservation_740  1
    load_0_13_14  free_load_conservation_746  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_15  arc_capacity_616  -30
    arc_0_13_15  connected_order_arc_617  -14
    arc_0_13_15  out_degree_735  1
    arc_0_13_15  in_degree_748  1
    arc_0_13_15  original_T_including_depot_unload_757  2.9819555494495978e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_15  arc_capacity_616  1
    load_0_13_15  free_load_conservation_740  1
    load_0_13_15  free_load_conservation_752  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_0  arc_capacity_618  -30
    arc_0_14_0  depot_return_or_bypass_669  1
    arc_0_14_0  out_degree_741  1
    arc_0_14_0  original_T_including_depot_unload_757  4.0782796387128610e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_0  arc_capacity_618  1
    load_0_14_0  free_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_1  arc_capacity_619  -30
    arc_0_14_1  connected_order_arc_620  -14
    arc_0_14_1  in_degree_671  1
    arc_0_14_1  out_degree_741  1
    arc_0_14_1  original_T_including_depot_unload_757  6.3975035388222534e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_1  arc_capacity_619  1
    load_0_14_1  segment_load_conservation_674  -1
    load_0_14_1  segment_prefix_lb_675  1
    load_0_14_1  segment_prefix_ub_676  1
    load_0_14_1  free_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_2  arc_capacity_621  -30
    arc_0_14_2  connected_order_arc_622  -14
    arc_0_14_2  in_degree_678  1
    arc_0_14_2  out_degree_741  1
    arc_0_14_2  original_T_including_depot_unload_757  1.2480053261465446e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_2  arc_capacity_621  1
    load_0_14_2  segment_load_conservation_681  -1
    load_0_14_2  segment_prefix_lb_682  1
    load_0_14_2  segment_prefix_ub_683  1
    load_0_14_2  free_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_3  arc_capacity_623  -30
    arc_0_14_3  connected_order_arc_624  -14
    arc_0_14_3  in_degree_685  1
    arc_0_14_3  out_degree_741  1
    arc_0_14_3  original_T_including_depot_unload_757  8.2145202724109538e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_3  arc_capacity_623  1
    load_0_14_3  segment_load_conservation_688  -1
    load_0_14_3  segment_prefix_lb_689  1
    load_0_14_3  segment_prefix_ub_690  1
    load_0_14_3  free_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_4  arc_capacity_625  -30
    arc_0_14_4  connected_order_arc_626  -14
    arc_0_14_4  in_degree_692  1
    arc_0_14_4  out_degree_741  1
    arc_0_14_4  original_T_including_depot_unload_757  8.2982882938703278e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_4  arc_capacity_625  1
    load_0_14_4  segment_load_conservation_695  -1
    load_0_14_4  segment_prefix_lb_696  1
    load_0_14_4  segment_prefix_ub_697  1
    load_0_14_4  free_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_5  arc_capacity_627  -30
    arc_0_14_5  connected_order_arc_628  -14
    arc_0_14_5  in_degree_699  1
    arc_0_14_5  out_degree_741  1
    arc_0_14_5  original_T_including_depot_unload_757  1.7839442696984972e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_5  arc_capacity_627  1
    load_0_14_5  segment_load_conservation_702  -1
    load_0_14_5  segment_prefix_lb_703  1
    load_0_14_5  segment_prefix_ub_704  1
    load_0_14_5  free_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_8  arc_capacity_629  -30
    arc_0_14_8  connected_order_arc_630  -14
    arc_0_14_8  in_degree_706  1
    arc_0_14_8  out_degree_741  1
    arc_0_14_8  original_T_including_depot_unload_757  3.6114004430677619e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_8  arc_capacity_629  1
    load_0_14_8  free_load_conservation_710  -1
    load_0_14_8  free_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_9  arc_capacity_631  -30
    arc_0_14_9  connected_order_arc_632  -14
    arc_0_14_9  in_degree_712  1
    arc_0_14_9  out_degree_741  1
    arc_0_14_9  original_T_including_depot_unload_757  4.6739130846957909e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_9  arc_capacity_631  1
    load_0_14_9  free_load_conservation_716  -1
    load_0_14_9  free_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_10  arc_capacity_633  -30
    arc_0_14_10  connected_order_arc_634  -14
    arc_0_14_10  in_degree_718  1
    arc_0_14_10  out_degree_741  1
    arc_0_14_10  original_T_including_depot_unload_757  2.6728511574036233e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_10  arc_capacity_633  1
    load_0_14_10  free_load_conservation_722  -1
    load_0_14_10  free_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_11  arc_capacity_635  -30
    arc_0_14_11  connected_order_arc_636  -14
    arc_0_14_11  in_degree_724  1
    arc_0_14_11  out_degree_741  1
    arc_0_14_11  original_T_including_depot_unload_757  2.0430160967046345e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_11  arc_capacity_635  1
    load_0_14_11  free_load_conservation_728  -1
    load_0_14_11  free_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_12  arc_capacity_637  -30
    arc_0_14_12  connected_order_arc_638  -14
    arc_0_14_12  in_degree_730  1
    arc_0_14_12  out_degree_741  1
    arc_0_14_12  original_T_including_depot_unload_757  2.2811398160464278e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_12  arc_capacity_637  1
    load_0_14_12  free_load_conservation_734  -1
    load_0_14_12  free_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_13  arc_capacity_639  -30
    arc_0_14_13  connected_order_arc_640  -14
    arc_0_14_13  in_degree_736  1
    arc_0_14_13  out_degree_741  1
    arc_0_14_13  original_T_including_depot_unload_757  5.3918604589472477e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_13  arc_capacity_639  1
    load_0_14_13  free_load_conservation_740  -1
    load_0_14_13  free_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_15  arc_capacity_641  -30
    arc_0_14_15  connected_order_arc_642  -14
    arc_0_14_15  out_degree_741  1
    arc_0_14_15  in_degree_748  1
    arc_0_14_15  original_T_including_depot_unload_757  6.0329604828085382e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_15  arc_capacity_641  1
    load_0_14_15  free_load_conservation_746  1
    load_0_14_15  free_load_conservation_752  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_0  arc_capacity_643  -30
    arc_0_15_0  depot_return_or_bypass_669  1
    arc_0_15_0  out_degree_747  1
    arc_0_15_0  original_T_including_depot_unload_757  9.3133633713881534e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_0  arc_capacity_643  1
    load_0_15_0  free_load_conservation_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_1  arc_capacity_644  -30
    arc_0_15_1  connected_order_arc_645  -14
    arc_0_15_1  in_degree_671  1
    arc_0_15_1  out_degree_747  1
    arc_0_15_1  original_T_including_depot_unload_757  1.2315777010885340e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_1  arc_capacity_644  1
    load_0_15_1  segment_load_conservation_674  -1
    load_0_15_1  segment_prefix_lb_675  1
    load_0_15_1  segment_prefix_ub_676  1
    load_0_15_1  free_load_conservation_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_2  arc_capacity_646  -30
    arc_0_15_2  connected_order_arc_647  -14
    arc_0_15_2  in_degree_678  1
    arc_0_15_2  out_degree_747  1
    arc_0_15_2  original_T_including_depot_unload_757  5.6231331158364958e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_2  arc_capacity_646  1
    load_0_15_2  segment_load_conservation_681  -1
    load_0_15_2  segment_prefix_lb_682  1
    load_0_15_2  segment_prefix_ub_683  1
    load_0_15_2  free_load_conservation_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_3  arc_capacity_648  -30
    arc_0_15_3  connected_order_arc_649  -14
    arc_0_15_3  in_degree_685  1
    arc_0_15_3  out_degree_747  1
    arc_0_15_3  original_T_including_depot_unload_757  4.3257823465305182e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_3  arc_capacity_648  1
    load_0_15_3  segment_load_conservation_688  -1
    load_0_15_3  segment_prefix_lb_689  1
    load_0_15_3  segment_prefix_ub_690  1
    load_0_15_3  free_load_conservation_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_4  arc_capacity_650  -30
    arc_0_15_4  connected_order_arc_651  -14
    arc_0_15_4  in_degree_692  1
    arc_0_15_4  out_degree_747  1
    arc_0_15_4  original_T_including_depot_unload_757  2.2655310037545112e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_4  arc_capacity_650  1
    load_0_15_4  segment_load_conservation_695  -1
    load_0_15_4  segment_prefix_lb_696  1
    load_0_15_4  segment_prefix_ub_697  1
    load_0_15_4  free_load_conservation_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_5  arc_capacity_652  -30
    arc_0_15_5  connected_order_arc_653  -14
    arc_0_15_5  in_degree_699  1
    arc_0_15_5  out_degree_747  1
    arc_0_15_5  original_T_including_depot_unload_757  516.598297486096
    MARKER    'MARKER'                 'INTEND'
    load_0_15_5  arc_capacity_652  1
    load_0_15_5  segment_load_conservation_702  -1
    load_0_15_5  segment_prefix_lb_703  1
    load_0_15_5  segment_prefix_ub_704  1
    load_0_15_5  free_load_conservation_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_8  arc_capacity_654  -30
    arc_0_15_8  connected_order_arc_655  -14
    arc_0_15_8  in_degree_706  1
    arc_0_15_8  out_degree_747  1
    arc_0_15_8  original_T_including_depot_unload_757  2.8072002002622634e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_8  arc_capacity_654  1
    load_0_15_8  free_load_conservation_710  -1
    load_0_15_8  free_load_conservation_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_9  arc_capacity_656  -30
    arc_0_15_9  connected_order_arc_657  -14
    arc_0_15_9  in_degree_712  1
    arc_0_15_9  out_degree_747  1
    arc_0_15_9  original_T_including_depot_unload_757  1.5413712102626312e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_9  arc_capacity_656  1
    load_0_15_9  free_load_conservation_716  -1
    load_0_15_9  free_load_conservation_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_10  arc_capacity_658  -30
    arc_0_15_10  connected_order_arc_659  -14
    arc_0_15_10  in_degree_718  1
    arc_0_15_10  out_degree_747  1
    arc_0_15_10  original_T_including_depot_unload_757  2.8839695646198670e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_10  arc_capacity_658  1
    load_0_15_10  free_load_conservation_722  -1
    load_0_15_10  free_load_conservation_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_11  arc_capacity_660  -30
    arc_0_15_11  connected_order_arc_661  -14
    arc_0_15_11  in_degree_724  1
    arc_0_15_11  out_degree_747  1
    arc_0_15_11  original_T_including_depot_unload_757  4.1557375918514475e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_11  arc_capacity_660  1
    load_0_15_11  free_load_conservation_728  -1
    load_0_15_11  free_load_conservation_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_12  arc_capacity_662  -30
    arc_0_15_12  connected_order_arc_663  -14
    arc_0_15_12  in_degree_730  1
    arc_0_15_12  out_degree_747  1
    arc_0_15_12  original_T_including_depot_unload_757  2.7766616410403444e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_12  arc_capacity_662  1
    load_0_15_12  free_load_conservation_734  -1
    load_0_15_12  free_load_conservation_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_13  arc_capacity_664  -30
    arc_0_15_13  connected_order_arc_665  -14
    arc_0_15_13  in_degree_736  1
    arc_0_15_13  out_degree_747  1
    arc_0_15_13  original_T_including_depot_unload_757  2.9819555494495978e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_13  arc_capacity_664  1
    load_0_15_13  free_load_conservation_740  -1
    load_0_15_13  free_load_conservation_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_14  arc_capacity_666  -30
    arc_0_15_14  connected_order_arc_667  -14
    arc_0_15_14  in_degree_742  1
    arc_0_15_14  out_degree_747  1
    arc_0_15_14  original_T_including_depot_unload_757  6.0329604828085382e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_14  arc_capacity_666  1
    load_0_15_14  free_load_conservation_746  -1
    load_0_15_14  free_load_conservation_752  1
    visit_1_6  out_degree_961  -1
    visit_1_6  in_degree_962  -1
    visit_1_6  order_active_lb_963  -1
    visit_1_6  order_active_ub_964  -10
    order_1_6  connected_order_arc_771  -1
    order_1_6  connected_order_arc_773  -1
    order_1_6  connected_order_arc_775  -1
    order_1_6  connected_order_arc_777  -1
    order_1_6  connected_order_arc_779  -1
    order_1_6  connected_order_arc_781  -1
    order_1_6  connected_order_arc_783  -1
    order_1_6  connected_order_arc_785  -1
    order_1_6  connected_order_arc_787  -1
    order_1_6  connected_order_arc_790  1
    order_1_6  connected_order_arc_809  1
    order_1_6  connected_order_arc_828  1
    order_1_6  connected_order_arc_847  1
    order_1_6  connected_order_arc_866  1
    order_1_6  connected_order_arc_885  1
    order_1_6  connected_order_arc_904  1
    order_1_6  connected_order_arc_923  1
    order_1_6  connected_order_arc_942  1
    order_1_6  order_active_lb_963  1
    order_1_6  order_active_ub_964  1
    order_1_6  fixed_segment_relative_order_1023  -1
    visit_1_7  out_degree_968  -1
    visit_1_7  in_degree_969  -1
    visit_1_7  order_active_lb_970  -1
    visit_1_7  order_active_ub_971  -10
    order_1_7  connected_order_arc_771  1
    order_1_7  connected_order_arc_790  -1
    order_1_7  connected_order_arc_792  -1
    order_1_7  connected_order_arc_794  -1
    order_1_7  connected_order_arc_796  -1
    order_1_7  connected_order_arc_798  -1
    order_1_7  connected_order_arc_800  -1
    order_1_7  connected_order_arc_802  -1
    order_1_7  connected_order_arc_804  -1
    order_1_7  connected_order_arc_806  -1
    order_1_7  connected_order_arc_811  1
    order_1_7  connected_order_arc_830  1
    order_1_7  connected_order_arc_849  1
    order_1_7  connected_order_arc_868  1
    order_1_7  connected_order_arc_887  1
    order_1_7  connected_order_arc_906  1
    order_1_7  connected_order_arc_925  1
    order_1_7  connected_order_arc_944  1
    order_1_7  order_active_lb_970  1
    order_1_7  order_active_ub_971  1
    order_1_7  fixed_segment_relative_order_1023  1
    visit_1_8  out_degree_975  -1
    visit_1_8  in_degree_976  -1
    visit_1_8  order_active_lb_977  -1
    visit_1_8  order_active_ub_978  -10
    visit_1_8  service_visit_def_979  -1
    order_1_8  connected_order_arc_773  1
    order_1_8  connected_order_arc_792  1
    order_1_8  connected_order_arc_809  -1
    order_1_8  connected_order_arc_811  -1
    order_1_8  connected_order_arc_813  -1
    order_1_8  connected_order_arc_815  -1
    order_1_8  connected_order_arc_817  -1
    order_1_8  connected_order_arc_819  -1
    order_1_8  connected_order_arc_821  -1
    order_1_8  connected_order_arc_823  -1
    order_1_8  connected_order_arc_825  -1
    order_1_8  connected_order_arc_832  1
    order_1_8  connected_order_arc_851  1
    order_1_8  connected_order_arc_870  1
    order_1_8  connected_order_arc_889  1
    order_1_8  connected_order_arc_908  1
    order_1_8  connected_order_arc_927  1
    order_1_8  connected_order_arc_946  1
    order_1_8  order_active_lb_977  1
    order_1_8  order_active_ub_978  1
    visit_1_9  out_degree_981  -1
    visit_1_9  in_degree_982  -1
    visit_1_9  order_active_lb_983  -1
    visit_1_9  order_active_ub_984  -10
    visit_1_9  service_visit_def_985  -1
    order_1_9  connected_order_arc_775  1
    order_1_9  connected_order_arc_794  1
    order_1_9  connected_order_arc_813  1
    order_1_9  connected_order_arc_828  -1
    order_1_9  connected_order_arc_830  -1
    order_1_9  connected_order_arc_832  -1
    order_1_9  connected_order_arc_834  -1
    order_1_9  connected_order_arc_836  -1
    order_1_9  connected_order_arc_838  -1
    order_1_9  connected_order_arc_840  -1
    order_1_9  connected_order_arc_842  -1
    order_1_9  connected_order_arc_844  -1
    order_1_9  connected_order_arc_853  1
    order_1_9  connected_order_arc_872  1
    order_1_9  connected_order_arc_891  1
    order_1_9  connected_order_arc_910  1
    order_1_9  connected_order_arc_929  1
    order_1_9  connected_order_arc_948  1
    order_1_9  order_active_lb_983  1
    order_1_9  order_active_ub_984  1
    visit_1_10  out_degree_987  -1
    visit_1_10  in_degree_988  -1
    visit_1_10  order_active_lb_989  -1
    visit_1_10  order_active_ub_990  -10
    visit_1_10  service_visit_def_991  -1
    order_1_10  connected_order_arc_777  1
    order_1_10  connected_order_arc_796  1
    order_1_10  connected_order_arc_815  1
    order_1_10  connected_order_arc_834  1
    order_1_10  connected_order_arc_847  -1
    order_1_10  connected_order_arc_849  -1
    order_1_10  connected_order_arc_851  -1
    order_1_10  connected_order_arc_853  -1
    order_1_10  connected_order_arc_855  -1
    order_1_10  connected_order_arc_857  -1
    order_1_10  connected_order_arc_859  -1
    order_1_10  connected_order_arc_861  -1
    order_1_10  connected_order_arc_863  -1
    order_1_10  connected_order_arc_874  1
    order_1_10  connected_order_arc_893  1
    order_1_10  connected_order_arc_912  1
    order_1_10  connected_order_arc_931  1
    order_1_10  connected_order_arc_950  1
    order_1_10  order_active_lb_989  1
    order_1_10  order_active_ub_990  1
    visit_1_11  out_degree_993  -1
    visit_1_11  in_degree_994  -1
    visit_1_11  order_active_lb_995  -1
    visit_1_11  order_active_ub_996  -10
    visit_1_11  service_visit_def_997  -1
    order_1_11  connected_order_arc_779  1
    order_1_11  connected_order_arc_798  1
    order_1_11  connected_order_arc_817  1
    order_1_11  connected_order_arc_836  1
    order_1_11  connected_order_arc_855  1
    order_1_11  connected_order_arc_866  -1
    order_1_11  connected_order_arc_868  -1
    order_1_11  connected_order_arc_870  -1
    order_1_11  connected_order_arc_872  -1
    order_1_11  connected_order_arc_874  -1
    order_1_11  connected_order_arc_876  -1
    order_1_11  connected_order_arc_878  -1
    order_1_11  connected_order_arc_880  -1
    order_1_11  connected_order_arc_882  -1
    order_1_11  connected_order_arc_895  1
    order_1_11  connected_order_arc_914  1
    order_1_11  connected_order_arc_933  1
    order_1_11  connected_order_arc_952  1
    order_1_11  order_active_lb_995  1
    order_1_11  order_active_ub_996  1
    visit_1_12  out_degree_999  -1
    visit_1_12  in_degree_1000  -1
    visit_1_12  order_active_lb_1001  -1
    visit_1_12  order_active_ub_1002  -10
    visit_1_12  service_visit_def_1003  -1
    order_1_12  connected_order_arc_781  1
    order_1_12  connected_order_arc_800  1
    order_1_12  connected_order_arc_819  1
    order_1_12  connected_order_arc_838  1
    order_1_12  connected_order_arc_857  1
    order_1_12  connected_order_arc_876  1
    order_1_12  connected_order_arc_885  -1
    order_1_12  connected_order_arc_887  -1
    order_1_12  connected_order_arc_889  -1
    order_1_12  connected_order_arc_891  -1
    order_1_12  connected_order_arc_893  -1
    order_1_12  connected_order_arc_895  -1
    order_1_12  connected_order_arc_897  -1
    order_1_12  connected_order_arc_899  -1
    order_1_12  connected_order_arc_901  -1
    order_1_12  connected_order_arc_916  1
    order_1_12  connected_order_arc_935  1
    order_1_12  connected_order_arc_954  1
    order_1_12  order_active_lb_1001  1
    order_1_12  order_active_ub_1002  1
    visit_1_13  out_degree_1005  -1
    visit_1_13  in_degree_1006  -1
    visit_1_13  order_active_lb_1007  -1
    visit_1_13  order_active_ub_1008  -10
    visit_1_13  service_visit_def_1009  -1
    order_1_13  connected_order_arc_783  1
    order_1_13  connected_order_arc_802  1
    order_1_13  connected_order_arc_821  1
    order_1_13  connected_order_arc_840  1
    order_1_13  connected_order_arc_859  1
    order_1_13  connected_order_arc_878  1
    order_1_13  connected_order_arc_897  1
    order_1_13  connected_order_arc_904  -1
    order_1_13  connected_order_arc_906  -1
    order_1_13  connected_order_arc_908  -1
    order_1_13  connected_order_arc_910  -1
    order_1_13  connected_order_arc_912  -1
    order_1_13  connected_order_arc_914  -1
    order_1_13  connected_order_arc_916  -1
    order_1_13  connected_order_arc_918  -1
    order_1_13  connected_order_arc_920  -1
    order_1_13  connected_order_arc_937  1
    order_1_13  connected_order_arc_956  1
    order_1_13  order_active_lb_1007  1
    order_1_13  order_active_ub_1008  1
    visit_1_14  out_degree_1011  -1
    visit_1_14  in_degree_1012  -1
    visit_1_14  order_active_lb_1013  -1
    visit_1_14  order_active_ub_1014  -10
    visit_1_14  service_visit_def_1015  -1
    order_1_14  connected_order_arc_785  1
    order_1_14  connected_order_arc_804  1
    order_1_14  connected_order_arc_823  1
    order_1_14  connected_order_arc_842  1
    order_1_14  connected_order_arc_861  1
    order_1_14  connected_order_arc_880  1
    order_1_14  connected_order_arc_899  1
    order_1_14  connected_order_arc_918  1
    order_1_14  connected_order_arc_923  -1
    order_1_14  connected_order_arc_925  -1
    order_1_14  connected_order_arc_927  -1
    order_1_14  connected_order_arc_929  -1
    order_1_14  connected_order_arc_931  -1
    order_1_14  connected_order_arc_933  -1
    order_1_14  connected_order_arc_935  -1
    order_1_14  connected_order_arc_937  -1
    order_1_14  connected_order_arc_939  -1
    order_1_14  connected_order_arc_958  1
    order_1_14  order_active_lb_1013  1
    order_1_14  order_active_ub_1014  1
    visit_1_15  out_degree_1017  -1
    visit_1_15  in_degree_1018  -1
    visit_1_15  order_active_lb_1019  -1
    visit_1_15  order_active_ub_1020  -10
    visit_1_15  service_visit_def_1021  -1
    order_1_15  connected_order_arc_787  1
    order_1_15  connected_order_arc_806  1
    order_1_15  connected_order_arc_825  1
    order_1_15  connected_order_arc_844  1
    order_1_15  connected_order_arc_863  1
    order_1_15  connected_order_arc_882  1
    order_1_15  connected_order_arc_901  1
    order_1_15  connected_order_arc_920  1
    order_1_15  connected_order_arc_939  1
    order_1_15  connected_order_arc_942  -1
    order_1_15  connected_order_arc_944  -1
    order_1_15  connected_order_arc_946  -1
    order_1_15  connected_order_arc_948  -1
    order_1_15  connected_order_arc_950  -1
    order_1_15  connected_order_arc_952  -1
    order_1_15  connected_order_arc_954  -1
    order_1_15  connected_order_arc_956  -1
    order_1_15  connected_order_arc_958  -1
    order_1_15  order_active_lb_1019  1
    order_1_15  order_active_ub_1020  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_0  arc_capacity_758  -30
    arc_1_0_0  depot_departure_or_bypass_959  1
    arc_1_0_0  depot_return_or_bypass_960  1
    MARKER    'MARKER'                 'INTEND'
    load_1_0_0  arc_capacity_758  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_6  arc_capacity_759  -30
    arc_1_0_6  depot_departure_or_bypass_959  1
    arc_1_0_6  in_degree_962  1
    arc_1_0_6  original_T_including_depot_unload_1024  1.8065333212349267e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_6  arc_capacity_759  1
    load_1_0_6  segment_load_conservation_965  -1
    load_1_0_6  segment_prefix_lb_966  1
    load_1_0_6  segment_prefix_ub_967  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_7  arc_capacity_760  -30
    arc_1_0_7  depot_departure_or_bypass_959  1
    arc_1_0_7  in_degree_969  1
    arc_1_0_7  original_T_including_depot_unload_1024  1739.61165920636
    MARKER    'MARKER'                 'INTEND'
    load_1_0_7  arc_capacity_760  1
    load_1_0_7  segment_load_conservation_972  -1
    load_1_0_7  segment_prefix_lb_973  1
    load_1_0_7  segment_prefix_ub_974  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_8  arc_capacity_761  -30
    arc_1_0_8  depot_departure_or_bypass_959  1
    arc_1_0_8  in_degree_976  1
    arc_1_0_8  original_T_including_depot_unload_1024  7.4412496590753551e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_8  arc_capacity_761  1
    load_1_0_8  free_load_conservation_980  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_9  arc_capacity_762  -30
    arc_1_0_9  depot_departure_or_bypass_959  1
    arc_1_0_9  in_degree_982  1
    arc_1_0_9  original_T_including_depot_unload_1024  8.2548955430739034e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_9  arc_capacity_762  1
    load_1_0_9  free_load_conservation_986  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_10  arc_capacity_763  -30
    arc_1_0_10  depot_departure_or_bypass_959  1
    arc_1_0_10  in_degree_988  1
    arc_1_0_10  original_T_including_depot_unload_1024  2.3234267380118886e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_10  arc_capacity_763  1
    load_1_0_10  free_load_conservation_992  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_11  arc_capacity_764  -30
    arc_1_0_11  depot_departure_or_bypass_959  1
    arc_1_0_11  in_degree_994  1
    arc_1_0_11  original_T_including_depot_unload_1024  5.9631731642067359e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_11  arc_capacity_764  1
    load_1_0_11  free_load_conservation_998  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_12  arc_capacity_765  -30
    arc_1_0_12  depot_departure_or_bypass_959  1
    arc_1_0_12  in_degree_1000  1
    arc_1_0_12  original_T_including_depot_unload_1024  2.2866763971369810e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_12  arc_capacity_765  1
    load_1_0_12  free_load_conservation_1004  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_13  arc_capacity_766  -30
    arc_1_0_13  depot_departure_or_bypass_959  1
    arc_1_0_13  in_degree_1006  1
    arc_1_0_13  original_T_including_depot_unload_1024  9.3659929340140741e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_13  arc_capacity_766  1
    load_1_0_13  free_load_conservation_1010  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_14  arc_capacity_767  -30
    arc_1_0_14  depot_departure_or_bypass_959  1
    arc_1_0_14  in_degree_1012  1
    arc_1_0_14  original_T_including_depot_unload_1024  4.0782796387128610e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_14  arc_capacity_767  1
    load_1_0_14  free_load_conservation_1016  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_15  arc_capacity_768  -30
    arc_1_0_15  depot_departure_or_bypass_959  1
    arc_1_0_15  in_degree_1018  1
    arc_1_0_15  original_T_including_depot_unload_1024  9.3133633713881534e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_15  arc_capacity_768  1
    load_1_0_15  free_load_conservation_1022  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_0  arc_capacity_769  -30
    arc_1_6_0  depot_return_or_bypass_960  1
    arc_1_6_0  out_degree_961  1
    arc_1_6_0  original_T_including_depot_unload_1024  1.8065333212349267e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_0  arc_capacity_769  1
    load_1_6_0  segment_load_conservation_965  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_7  arc_capacity_770  -30
    arc_1_6_7  connected_order_arc_771  -11
    arc_1_6_7  out_degree_961  1
    arc_1_6_7  in_degree_969  1
    arc_1_6_7  original_T_including_depot_unload_1024  1.3126251897454844e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_7  arc_capacity_770  1
    load_1_6_7  segment_load_conservation_965  1
    load_1_6_7  segment_load_conservation_972  -1
    load_1_6_7  segment_prefix_lb_973  1
    load_1_6_7  segment_prefix_ub_974  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_8  arc_capacity_772  -30
    arc_1_6_8  connected_order_arc_773  -11
    arc_1_6_8  out_degree_961  1
    arc_1_6_8  in_degree_976  1
    arc_1_6_8  original_T_including_depot_unload_1024  1.9740618091449423e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_8  arc_capacity_772  1
    load_1_6_8  segment_load_conservation_965  1
    load_1_6_8  free_load_conservation_980  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_9  arc_capacity_774  -30
    arc_1_6_9  connected_order_arc_775  -11
    arc_1_6_9  out_degree_961  1
    arc_1_6_9  in_degree_982  1
    arc_1_6_9  original_T_including_depot_unload_1024  2.0979901720969542e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_9  arc_capacity_774  1
    load_1_6_9  segment_load_conservation_965  1
    load_1_6_9  free_load_conservation_986  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_10  arc_capacity_776  -30
    arc_1_6_10  connected_order_arc_777  -11
    arc_1_6_10  out_degree_961  1
    arc_1_6_10  in_degree_988  1
    arc_1_6_10  original_T_including_depot_unload_1024  3.8283958278492823e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_10  arc_capacity_776  1
    load_1_6_10  segment_load_conservation_965  1
    load_1_6_10  free_load_conservation_992  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_11  arc_capacity_778  -30
    arc_1_6_11  connected_order_arc_779  -11
    arc_1_6_11  out_degree_961  1
    arc_1_6_11  in_degree_994  1
    arc_1_6_11  original_T_including_depot_unload_1024  1.8739441025189553e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_11  arc_capacity_778  1
    load_1_6_11  segment_load_conservation_965  1
    load_1_6_11  free_load_conservation_998  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_12  arc_capacity_780  -30
    arc_1_6_12  connected_order_arc_781  -11
    arc_1_6_12  out_degree_961  1
    arc_1_6_12  in_degree_1000  1
    arc_1_6_12  original_T_including_depot_unload_1024  5.2703432304351884e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_12  arc_capacity_780  1
    load_1_6_12  segment_load_conservation_965  1
    load_1_6_12  free_load_conservation_1004  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_13  arc_capacity_782  -30
    arc_1_6_13  connected_order_arc_783  -11
    arc_1_6_13  out_degree_961  1
    arc_1_6_13  in_degree_1006  1
    arc_1_6_13  original_T_including_depot_unload_1024  2.0021738809925773e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_13  arc_capacity_782  1
    load_1_6_13  segment_load_conservation_965  1
    load_1_6_13  free_load_conservation_1010  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_14  arc_capacity_784  -30
    arc_1_6_14  connected_order_arc_785  -11
    arc_1_6_14  out_degree_961  1
    arc_1_6_14  in_degree_1012  1
    arc_1_6_14  original_T_including_depot_unload_1024  1.7671662790958783e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_14  arc_capacity_784  1
    load_1_6_14  segment_load_conservation_965  1
    load_1_6_14  free_load_conservation_1016  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_15  arc_capacity_786  -30
    arc_1_6_15  connected_order_arc_787  -11
    arc_1_6_15  out_degree_961  1
    arc_1_6_15  in_degree_1018  1
    arc_1_6_15  original_T_including_depot_unload_1024  2.2507610939146793e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_15  arc_capacity_786  1
    load_1_6_15  segment_load_conservation_965  1
    load_1_6_15  free_load_conservation_1022  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_0  arc_capacity_788  -30
    arc_1_7_0  depot_return_or_bypass_960  1
    arc_1_7_0  out_degree_968  1
    arc_1_7_0  original_T_including_depot_unload_1024  1739.61165920636
    MARKER    'MARKER'                 'INTEND'
    load_1_7_0  arc_capacity_788  1
    load_1_7_0  segment_load_conservation_972  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_6  arc_capacity_789  -30
    arc_1_7_6  connected_order_arc_790  -11
    arc_1_7_6  in_degree_962  1
    arc_1_7_6  out_degree_968  1
    arc_1_7_6  original_T_including_depot_unload_1024  1.3126251897454844e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_6  arc_capacity_789  1
    load_1_7_6  segment_load_conservation_965  -1
    load_1_7_6  segment_prefix_lb_966  1
    load_1_7_6  segment_prefix_ub_967  1
    load_1_7_6  segment_load_conservation_972  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_8  arc_capacity_791  -30
    arc_1_7_8  connected_order_arc_792  -11
    arc_1_7_8  out_degree_968  1
    arc_1_7_8  in_degree_976  1
    arc_1_7_8  original_T_including_depot_unload_1024  1.9548039027038737e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_8  arc_capacity_791  1
    load_1_7_8  segment_load_conservation_972  1
    load_1_7_8  free_load_conservation_980  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_9  arc_capacity_793  -30
    arc_1_7_9  connected_order_arc_794  -11
    arc_1_7_9  out_degree_968  1
    arc_1_7_9  in_degree_982  1
    arc_1_7_9  original_T_including_depot_unload_1024  2.0801782775431307e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_9  arc_capacity_793  1
    load_1_7_9  segment_load_conservation_972  1
    load_1_7_9  free_load_conservation_986  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_10  arc_capacity_795  -30
    arc_1_7_10  connected_order_arc_796  -11
    arc_1_7_10  out_degree_968  1
    arc_1_7_10  in_degree_988  1
    arc_1_7_10  original_T_including_depot_unload_1024  3.7182308190042463e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_10  arc_capacity_795  1
    load_1_7_10  segment_load_conservation_972  1
    load_1_7_10  free_load_conservation_992  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_11  arc_capacity_797  -30
    arc_1_7_11  connected_order_arc_798  -11
    arc_1_7_11  out_degree_968  1
    arc_1_7_11  in_degree_994  1
    arc_1_7_11  original_T_including_depot_unload_1024  1.8467456333549035e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_11  arc_capacity_797  1
    load_1_7_11  segment_load_conservation_972  1
    load_1_7_11  free_load_conservation_998  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_12  arc_capacity_799  -30
    arc_1_7_12  connected_order_arc_800  -11
    arc_1_7_12  out_degree_968  1
    arc_1_7_12  in_degree_1000  1
    arc_1_7_12  original_T_including_depot_unload_1024  5.5382752177930990e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_12  arc_capacity_799  1
    load_1_7_12  segment_load_conservation_972  1
    load_1_7_12  free_load_conservation_1004  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_13  arc_capacity_801  -30
    arc_1_7_13  connected_order_arc_802  -11
    arc_1_7_13  out_degree_968  1
    arc_1_7_13  in_degree_1006  1
    arc_1_7_13  original_T_including_depot_unload_1024  1.9959569014367933e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_13  arc_capacity_801  1
    load_1_7_13  segment_load_conservation_972  1
    load_1_7_13  free_load_conservation_1010  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_14  arc_capacity_803  -30
    arc_1_7_14  connected_order_arc_804  -11
    arc_1_7_14  out_degree_968  1
    arc_1_7_14  in_degree_1012  1
    arc_1_7_14  original_T_including_depot_unload_1024  1.7279728905134273e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_14  arc_capacity_803  1
    load_1_7_14  segment_load_conservation_972  1
    load_1_7_14  free_load_conservation_1016  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_15  arc_capacity_805  -30
    arc_1_7_15  connected_order_arc_806  -11
    arc_1_7_15  out_degree_968  1
    arc_1_7_15  in_degree_1018  1
    arc_1_7_15  original_T_including_depot_unload_1024  2.2339035809798856e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_15  arc_capacity_805  1
    load_1_7_15  segment_load_conservation_972  1
    load_1_7_15  free_load_conservation_1022  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_0  arc_capacity_807  -30
    arc_1_8_0  depot_return_or_bypass_960  1
    arc_1_8_0  out_degree_975  1
    arc_1_8_0  original_T_including_depot_unload_1024  7.4412496590753551e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_0  arc_capacity_807  1
    load_1_8_0  free_load_conservation_980  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_6  arc_capacity_808  -30
    arc_1_8_6  connected_order_arc_809  -11
    arc_1_8_6  in_degree_962  1
    arc_1_8_6  out_degree_975  1
    arc_1_8_6  original_T_including_depot_unload_1024  1.9740618091449423e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_6  arc_capacity_808  1
    load_1_8_6  segment_load_conservation_965  -1
    load_1_8_6  segment_prefix_lb_966  1
    load_1_8_6  segment_prefix_ub_967  1
    load_1_8_6  free_load_conservation_980  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_7  arc_capacity_810  -30
    arc_1_8_7  connected_order_arc_811  -11
    arc_1_8_7  in_degree_969  1
    arc_1_8_7  out_degree_975  1
    arc_1_8_7  original_T_including_depot_unload_1024  1.9548039027038737e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_7  arc_capacity_810  1
    load_1_8_7  segment_load_conservation_972  -1
    load_1_8_7  segment_prefix_lb_973  1
    load_1_8_7  segment_prefix_ub_974  1
    load_1_8_7  free_load_conservation_980  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_9  arc_capacity_812  -30
    arc_1_8_9  connected_order_arc_813  -11
    arc_1_8_9  out_degree_975  1
    arc_1_8_9  in_degree_982  1
    arc_1_8_9  original_T_including_depot_unload_1024  1.2673640125672841e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_9  arc_capacity_812  1
    load_1_8_9  free_load_conservation_980  1
    load_1_8_9  free_load_conservation_986  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_10  arc_capacity_814  -30
    arc_1_8_10  connected_order_arc_815  -11
    arc_1_8_10  out_degree_975  1
    arc_1_8_10  in_degree_988  1
    arc_1_8_10  original_T_including_depot_unload_1024  2.8807002034504962e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_10  arc_capacity_814  1
    load_1_8_10  free_load_conservation_980  1
    load_1_8_10  free_load_conservation_992  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_11  arc_capacity_816  -30
    arc_1_8_11  connected_order_arc_817  -11
    arc_1_8_11  out_degree_975  1
    arc_1_8_11  in_degree_994  1
    arc_1_8_11  original_T_including_depot_unload_1024  1.5701156446555925e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_11  arc_capacity_816  1
    load_1_8_11  free_load_conservation_980  1
    load_1_8_11  free_load_conservation_998  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_12  arc_capacity_818  -30
    arc_1_8_12  connected_order_arc_819  -11
    arc_1_8_12  out_degree_975  1
    arc_1_8_12  in_degree_1000  1
    arc_1_8_12  original_T_including_depot_unload_1024  2.4992063774241742e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_12  arc_capacity_818  1
    load_1_8_12  free_load_conservation_980  1
    load_1_8_12  free_load_conservation_1004  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_13  arc_capacity_820  -30
    arc_1_8_13  connected_order_arc_821  -11
    arc_1_8_13  out_degree_975  1
    arc_1_8_13  in_degree_1006  1
    arc_1_8_13  original_T_including_depot_unload_1024  2.0082608212298291e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_13  arc_capacity_820  1
    load_1_8_13  free_load_conservation_980  1
    load_1_8_13  free_load_conservation_1010  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_14  arc_capacity_822  -30
    arc_1_8_14  connected_order_arc_823  -11
    arc_1_8_14  out_degree_975  1
    arc_1_8_14  in_degree_1012  1
    arc_1_8_14  original_T_including_depot_unload_1024  3.6114004430677619e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_14  arc_capacity_822  1
    load_1_8_14  free_load_conservation_980  1
    load_1_8_14  free_load_conservation_1016  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_15  arc_capacity_824  -30
    arc_1_8_15  connected_order_arc_825  -11
    arc_1_8_15  out_degree_975  1
    arc_1_8_15  in_degree_1018  1
    arc_1_8_15  original_T_including_depot_unload_1024  2.8072002002622634e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_15  arc_capacity_824  1
    load_1_8_15  free_load_conservation_980  1
    load_1_8_15  free_load_conservation_1022  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_0  arc_capacity_826  -30
    arc_1_9_0  depot_return_or_bypass_960  1
    arc_1_9_0  out_degree_981  1
    arc_1_9_0  original_T_including_depot_unload_1024  8.2548955430739034e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_0  arc_capacity_826  1
    load_1_9_0  free_load_conservation_986  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_6  arc_capacity_827  -30
    arc_1_9_6  connected_order_arc_828  -11
    arc_1_9_6  in_degree_962  1
    arc_1_9_6  out_degree_981  1
    arc_1_9_6  original_T_including_depot_unload_1024  2.0979901720969542e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_6  arc_capacity_827  1
    load_1_9_6  segment_load_conservation_965  -1
    load_1_9_6  segment_prefix_lb_966  1
    load_1_9_6  segment_prefix_ub_967  1
    load_1_9_6  free_load_conservation_986  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_7  arc_capacity_829  -30
    arc_1_9_7  connected_order_arc_830  -11
    arc_1_9_7  in_degree_969  1
    arc_1_9_7  out_degree_981  1
    arc_1_9_7  original_T_including_depot_unload_1024  2.0801782775431307e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_7  arc_capacity_829  1
    load_1_9_7  segment_load_conservation_972  -1
    load_1_9_7  segment_prefix_lb_973  1
    load_1_9_7  segment_prefix_ub_974  1
    load_1_9_7  free_load_conservation_986  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_8  arc_capacity_831  -30
    arc_1_9_8  connected_order_arc_832  -11
    arc_1_9_8  in_degree_976  1
    arc_1_9_8  out_degree_981  1
    arc_1_9_8  original_T_including_depot_unload_1024  1.2673640125672841e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_8  arc_capacity_831  1
    load_1_9_8  free_load_conservation_980  -1
    load_1_9_8  free_load_conservation_986  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_10  arc_capacity_833  -30
    arc_1_9_10  connected_order_arc_834  -11
    arc_1_9_10  out_degree_981  1
    arc_1_9_10  in_degree_988  1
    arc_1_9_10  original_T_including_depot_unload_1024  2.8834086639088187e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_10  arc_capacity_833  1
    load_1_9_10  free_load_conservation_986  1
    load_1_9_10  free_load_conservation_992  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_11  arc_capacity_835  -30
    arc_1_9_11  connected_order_arc_836  -11
    arc_1_9_11  out_degree_981  1
    arc_1_9_11  in_degree_994  1
    arc_1_9_11  original_T_including_depot_unload_1024  2.6991456262177837e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_11  arc_capacity_835  1
    load_1_9_11  free_load_conservation_986  1
    load_1_9_11  free_load_conservation_998  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_12  arc_capacity_837  -30
    arc_1_9_12  connected_order_arc_838  -11
    arc_1_9_12  out_degree_981  1
    arc_1_9_12  in_degree_1000  1
    arc_1_9_12  original_T_including_depot_unload_1024  2.6235983504802839e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_12  arc_capacity_837  1
    load_1_9_12  free_load_conservation_986  1
    load_1_9_12  free_load_conservation_1004  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_13  arc_capacity_839  -30
    arc_1_9_13  connected_order_arc_840  -11
    arc_1_9_13  out_degree_981  1
    arc_1_9_13  in_degree_1006  1
    arc_1_9_13  original_T_including_depot_unload_1024  2.0241950709354862e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_13  arc_capacity_839  1
    load_1_9_13  free_load_conservation_986  1
    load_1_9_13  free_load_conservation_1010  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_14  arc_capacity_841  -30
    arc_1_9_14  connected_order_arc_842  -11
    arc_1_9_14  out_degree_981  1
    arc_1_9_14  in_degree_1012  1
    arc_1_9_14  original_T_including_depot_unload_1024  4.6739130846957909e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_14  arc_capacity_841  1
    load_1_9_14  free_load_conservation_986  1
    load_1_9_14  free_load_conservation_1016  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_15  arc_capacity_843  -30
    arc_1_9_15  connected_order_arc_844  -11
    arc_1_9_15  out_degree_981  1
    arc_1_9_15  in_degree_1018  1
    arc_1_9_15  original_T_including_depot_unload_1024  1.5413712102626312e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_15  arc_capacity_843  1
    load_1_9_15  free_load_conservation_986  1
    load_1_9_15  free_load_conservation_1022  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_0  arc_capacity_845  -30
    arc_1_10_0  depot_return_or_bypass_960  1
    arc_1_10_0  out_degree_987  1
    arc_1_10_0  original_T_including_depot_unload_1024  2.3234267380118886e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_0  arc_capacity_845  1
    load_1_10_0  free_load_conservation_992  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_6  arc_capacity_846  -30
    arc_1_10_6  connected_order_arc_847  -11
    arc_1_10_6  in_degree_962  1
    arc_1_10_6  out_degree_987  1
    arc_1_10_6  original_T_including_depot_unload_1024  3.8283958278492823e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_6  arc_capacity_846  1
    load_1_10_6  segment_load_conservation_965  -1
    load_1_10_6  segment_prefix_lb_966  1
    load_1_10_6  segment_prefix_ub_967  1
    load_1_10_6  free_load_conservation_992  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_7  arc_capacity_848  -30
    arc_1_10_7  connected_order_arc_849  -11
    arc_1_10_7  in_degree_969  1
    arc_1_10_7  out_degree_987  1
    arc_1_10_7  original_T_including_depot_unload_1024  3.7182308190042463e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_7  arc_capacity_848  1
    load_1_10_7  segment_load_conservation_972  -1
    load_1_10_7  segment_prefix_lb_973  1
    load_1_10_7  segment_prefix_ub_974  1
    load_1_10_7  free_load_conservation_992  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_8  arc_capacity_850  -30
    arc_1_10_8  connected_order_arc_851  -11
    arc_1_10_8  in_degree_976  1
    arc_1_10_8  out_degree_987  1
    arc_1_10_8  original_T_including_depot_unload_1024  2.8807002034504962e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_8  arc_capacity_850  1
    load_1_10_8  free_load_conservation_980  -1
    load_1_10_8  free_load_conservation_992  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_9  arc_capacity_852  -30
    arc_1_10_9  connected_order_arc_853  -11
    arc_1_10_9  in_degree_982  1
    arc_1_10_9  out_degree_987  1
    arc_1_10_9  original_T_including_depot_unload_1024  2.8834086639088187e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_9  arc_capacity_852  1
    load_1_10_9  free_load_conservation_986  -1
    load_1_10_9  free_load_conservation_992  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_11  arc_capacity_854  -30
    arc_1_10_11  connected_order_arc_855  -11
    arc_1_10_11  out_degree_987  1
    arc_1_10_11  in_degree_994  1
    arc_1_10_11  original_T_including_depot_unload_1024  2.7910579461472848e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_11  arc_capacity_854  1
    load_1_10_11  free_load_conservation_992  1
    load_1_10_11  free_load_conservation_998  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_12  arc_capacity_856  -30
    arc_1_10_12  connected_order_arc_857  -11
    arc_1_10_12  out_degree_987  1
    arc_1_10_12  in_degree_1000  1
    arc_1_10_12  original_T_including_depot_unload_1024  4.1686506413165080e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_12  arc_capacity_856  1
    load_1_10_12  free_load_conservation_992  1
    load_1_10_12  free_load_conservation_1004  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_13  arc_capacity_858  -30
    arc_1_10_13  connected_order_arc_859  -11
    arc_1_10_13  out_degree_987  1
    arc_1_10_13  in_degree_1006  1
    arc_1_10_13  original_T_including_depot_unload_1024  3.0726580305165480e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_13  arc_capacity_858  1
    load_1_10_13  free_load_conservation_992  1
    load_1_10_13  free_load_conservation_1010  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_14  arc_capacity_860  -30
    arc_1_10_14  connected_order_arc_861  -11
    arc_1_10_14  out_degree_987  1
    arc_1_10_14  in_degree_1012  1
    arc_1_10_14  original_T_including_depot_unload_1024  2.6728511574036233e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_14  arc_capacity_860  1
    load_1_10_14  free_load_conservation_992  1
    load_1_10_14  free_load_conservation_1016  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_15  arc_capacity_862  -30
    arc_1_10_15  connected_order_arc_863  -11
    arc_1_10_15  out_degree_987  1
    arc_1_10_15  in_degree_1018  1
    arc_1_10_15  original_T_including_depot_unload_1024  2.8839695646198670e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_15  arc_capacity_862  1
    load_1_10_15  free_load_conservation_992  1
    load_1_10_15  free_load_conservation_1022  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_0  arc_capacity_864  -30
    arc_1_11_0  depot_return_or_bypass_960  1
    arc_1_11_0  out_degree_993  1
    arc_1_11_0  original_T_including_depot_unload_1024  5.9631731642067359e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_0  arc_capacity_864  1
    load_1_11_0  free_load_conservation_998  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_6  arc_capacity_865  -30
    arc_1_11_6  connected_order_arc_866  -11
    arc_1_11_6  in_degree_962  1
    arc_1_11_6  out_degree_993  1
    arc_1_11_6  original_T_including_depot_unload_1024  1.8739441025189553e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_6  arc_capacity_865  1
    load_1_11_6  segment_load_conservation_965  -1
    load_1_11_6  segment_prefix_lb_966  1
    load_1_11_6  segment_prefix_ub_967  1
    load_1_11_6  free_load_conservation_998  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_7  arc_capacity_867  -30
    arc_1_11_7  connected_order_arc_868  -11
    arc_1_11_7  in_degree_969  1
    arc_1_11_7  out_degree_993  1
    arc_1_11_7  original_T_including_depot_unload_1024  1.8467456333549035e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_7  arc_capacity_867  1
    load_1_11_7  segment_load_conservation_972  -1
    load_1_11_7  segment_prefix_lb_973  1
    load_1_11_7  segment_prefix_ub_974  1
    load_1_11_7  free_load_conservation_998  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_8  arc_capacity_869  -30
    arc_1_11_8  connected_order_arc_870  -11
    arc_1_11_8  in_degree_976  1
    arc_1_11_8  out_degree_993  1
    arc_1_11_8  original_T_including_depot_unload_1024  1.5701156446555925e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_8  arc_capacity_869  1
    load_1_11_8  free_load_conservation_980  -1
    load_1_11_8  free_load_conservation_998  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_9  arc_capacity_871  -30
    arc_1_11_9  connected_order_arc_872  -11
    arc_1_11_9  in_degree_982  1
    arc_1_11_9  out_degree_993  1
    arc_1_11_9  original_T_including_depot_unload_1024  2.6991456262177837e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_9  arc_capacity_871  1
    load_1_11_9  free_load_conservation_986  -1
    load_1_11_9  free_load_conservation_998  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_10  arc_capacity_873  -30
    arc_1_11_10  connected_order_arc_874  -11
    arc_1_11_10  in_degree_988  1
    arc_1_11_10  out_degree_993  1
    arc_1_11_10  original_T_including_depot_unload_1024  2.7910579461472848e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_10  arc_capacity_873  1
    load_1_11_10  free_load_conservation_992  -1
    load_1_11_10  free_load_conservation_998  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_12  arc_capacity_875  -30
    arc_1_11_12  connected_order_arc_876  -11
    arc_1_11_12  out_degree_993  1
    arc_1_11_12  in_degree_1000  1
    arc_1_11_12  original_T_including_depot_unload_1024  2.3958340327791907e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_12  arc_capacity_875  1
    load_1_11_12  free_load_conservation_998  1
    load_1_11_12  free_load_conservation_1004  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_13  arc_capacity_877  -30
    arc_1_11_13  connected_order_arc_878  -11
    arc_1_11_13  out_degree_993  1
    arc_1_11_13  in_degree_1006  1
    arc_1_11_13  original_T_including_depot_unload_1024  3.4037893208114895e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_13  arc_capacity_877  1
    load_1_11_13  free_load_conservation_998  1
    load_1_11_13  free_load_conservation_1010  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_14  arc_capacity_879  -30
    arc_1_11_14  connected_order_arc_880  -11
    arc_1_11_14  out_degree_993  1
    arc_1_11_14  in_degree_1012  1
    arc_1_11_14  original_T_including_depot_unload_1024  2.0430160967046345e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_14  arc_capacity_879  1
    load_1_11_14  free_load_conservation_998  1
    load_1_11_14  free_load_conservation_1016  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_15  arc_capacity_881  -30
    arc_1_11_15  connected_order_arc_882  -11
    arc_1_11_15  out_degree_993  1
    arc_1_11_15  in_degree_1018  1
    arc_1_11_15  original_T_including_depot_unload_1024  4.1557375918514475e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_15  arc_capacity_881  1
    load_1_11_15  free_load_conservation_998  1
    load_1_11_15  free_load_conservation_1022  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_0  arc_capacity_883  -30
    arc_1_12_0  depot_return_or_bypass_960  1
    arc_1_12_0  out_degree_999  1
    arc_1_12_0  original_T_including_depot_unload_1024  2.2866763971369810e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_0  arc_capacity_883  1
    load_1_12_0  free_load_conservation_1004  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_6  arc_capacity_884  -30
    arc_1_12_6  connected_order_arc_885  -11
    arc_1_12_6  in_degree_962  1
    arc_1_12_6  out_degree_999  1
    arc_1_12_6  original_T_including_depot_unload_1024  5.2703432304351884e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_6  arc_capacity_884  1
    load_1_12_6  segment_load_conservation_965  -1
    load_1_12_6  segment_prefix_lb_966  1
    load_1_12_6  segment_prefix_ub_967  1
    load_1_12_6  free_load_conservation_1004  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_7  arc_capacity_886  -30
    arc_1_12_7  connected_order_arc_887  -11
    arc_1_12_7  in_degree_969  1
    arc_1_12_7  out_degree_999  1
    arc_1_12_7  original_T_including_depot_unload_1024  5.5382752177930990e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_7  arc_capacity_886  1
    load_1_12_7  segment_load_conservation_972  -1
    load_1_12_7  segment_prefix_lb_973  1
    load_1_12_7  segment_prefix_ub_974  1
    load_1_12_7  free_load_conservation_1004  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_8  arc_capacity_888  -30
    arc_1_12_8  connected_order_arc_889  -11
    arc_1_12_8  in_degree_976  1
    arc_1_12_8  out_degree_999  1
    arc_1_12_8  original_T_including_depot_unload_1024  2.4992063774241742e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_8  arc_capacity_888  1
    load_1_12_8  free_load_conservation_980  -1
    load_1_12_8  free_load_conservation_1004  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_9  arc_capacity_890  -30
    arc_1_12_9  connected_order_arc_891  -11
    arc_1_12_9  in_degree_982  1
    arc_1_12_9  out_degree_999  1
    arc_1_12_9  original_T_including_depot_unload_1024  2.6235983504802839e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_9  arc_capacity_890  1
    load_1_12_9  free_load_conservation_986  -1
    load_1_12_9  free_load_conservation_1004  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_10  arc_capacity_892  -30
    arc_1_12_10  connected_order_arc_893  -11
    arc_1_12_10  in_degree_988  1
    arc_1_12_10  out_degree_999  1
    arc_1_12_10  original_T_including_depot_unload_1024  4.1686506413165080e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_10  arc_capacity_892  1
    load_1_12_10  free_load_conservation_992  -1
    load_1_12_10  free_load_conservation_1004  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_11  arc_capacity_894  -30
    arc_1_12_11  connected_order_arc_895  -11
    arc_1_12_11  in_degree_994  1
    arc_1_12_11  out_degree_999  1
    arc_1_12_11  original_T_including_depot_unload_1024  2.3958340327791907e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_11  arc_capacity_894  1
    load_1_12_11  free_load_conservation_998  -1
    load_1_12_11  free_load_conservation_1004  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_13  arc_capacity_896  -30
    arc_1_12_13  connected_order_arc_897  -11
    arc_1_12_13  out_degree_999  1
    arc_1_12_13  in_degree_1006  1
    arc_1_12_13  original_T_including_depot_unload_1024  2.5292035468949002e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_13  arc_capacity_896  1
    load_1_12_13  free_load_conservation_1004  1
    load_1_12_13  free_load_conservation_1010  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_14  arc_capacity_898  -30
    arc_1_12_14  connected_order_arc_899  -11
    arc_1_12_14  out_degree_999  1
    arc_1_12_14  in_degree_1012  1
    arc_1_12_14  original_T_including_depot_unload_1024  2.2811398160464278e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_14  arc_capacity_898  1
    load_1_12_14  free_load_conservation_1004  1
    load_1_12_14  free_load_conservation_1016  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_15  arc_capacity_900  -30
    arc_1_12_15  connected_order_arc_901  -11
    arc_1_12_15  out_degree_999  1
    arc_1_12_15  in_degree_1018  1
    arc_1_12_15  original_T_including_depot_unload_1024  2.7766616410403444e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_15  arc_capacity_900  1
    load_1_12_15  free_load_conservation_1004  1
    load_1_12_15  free_load_conservation_1022  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_0  arc_capacity_902  -30
    arc_1_13_0  depot_return_or_bypass_960  1
    arc_1_13_0  out_degree_1005  1
    arc_1_13_0  original_T_including_depot_unload_1024  9.3659929340140741e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_0  arc_capacity_902  1
    load_1_13_0  free_load_conservation_1010  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_6  arc_capacity_903  -30
    arc_1_13_6  connected_order_arc_904  -11
    arc_1_13_6  in_degree_962  1
    arc_1_13_6  out_degree_1005  1
    arc_1_13_6  original_T_including_depot_unload_1024  2.0021738809925773e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_6  arc_capacity_903  1
    load_1_13_6  segment_load_conservation_965  -1
    load_1_13_6  segment_prefix_lb_966  1
    load_1_13_6  segment_prefix_ub_967  1
    load_1_13_6  free_load_conservation_1010  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_7  arc_capacity_905  -30
    arc_1_13_7  connected_order_arc_906  -11
    arc_1_13_7  in_degree_969  1
    arc_1_13_7  out_degree_1005  1
    arc_1_13_7  original_T_including_depot_unload_1024  1.9959569014367933e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_7  arc_capacity_905  1
    load_1_13_7  segment_load_conservation_972  -1
    load_1_13_7  segment_prefix_lb_973  1
    load_1_13_7  segment_prefix_ub_974  1
    load_1_13_7  free_load_conservation_1010  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_8  arc_capacity_907  -30
    arc_1_13_8  connected_order_arc_908  -11
    arc_1_13_8  in_degree_976  1
    arc_1_13_8  out_degree_1005  1
    arc_1_13_8  original_T_including_depot_unload_1024  2.0082608212298291e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_8  arc_capacity_907  1
    load_1_13_8  free_load_conservation_980  -1
    load_1_13_8  free_load_conservation_1010  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_9  arc_capacity_909  -30
    arc_1_13_9  connected_order_arc_910  -11
    arc_1_13_9  in_degree_982  1
    arc_1_13_9  out_degree_1005  1
    arc_1_13_9  original_T_including_depot_unload_1024  2.0241950709354862e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_9  arc_capacity_909  1
    load_1_13_9  free_load_conservation_986  -1
    load_1_13_9  free_load_conservation_1010  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_10  arc_capacity_911  -30
    arc_1_13_10  connected_order_arc_912  -11
    arc_1_13_10  in_degree_988  1
    arc_1_13_10  out_degree_1005  1
    arc_1_13_10  original_T_including_depot_unload_1024  3.0726580305165480e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_10  arc_capacity_911  1
    load_1_13_10  free_load_conservation_992  -1
    load_1_13_10  free_load_conservation_1010  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_11  arc_capacity_913  -30
    arc_1_13_11  connected_order_arc_914  -11
    arc_1_13_11  in_degree_994  1
    arc_1_13_11  out_degree_1005  1
    arc_1_13_11  original_T_including_depot_unload_1024  3.4037893208114895e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_11  arc_capacity_913  1
    load_1_13_11  free_load_conservation_998  -1
    load_1_13_11  free_load_conservation_1010  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_12  arc_capacity_915  -30
    arc_1_13_12  connected_order_arc_916  -11
    arc_1_13_12  in_degree_1000  1
    arc_1_13_12  out_degree_1005  1
    arc_1_13_12  original_T_including_depot_unload_1024  2.5292035468949002e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_12  arc_capacity_915  1
    load_1_13_12  free_load_conservation_1004  -1
    load_1_13_12  free_load_conservation_1010  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_14  arc_capacity_917  -30
    arc_1_13_14  connected_order_arc_918  -11
    arc_1_13_14  out_degree_1005  1
    arc_1_13_14  in_degree_1012  1
    arc_1_13_14  original_T_including_depot_unload_1024  5.3918604589472477e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_14  arc_capacity_917  1
    load_1_13_14  free_load_conservation_1010  1
    load_1_13_14  free_load_conservation_1016  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_15  arc_capacity_919  -30
    arc_1_13_15  connected_order_arc_920  -11
    arc_1_13_15  out_degree_1005  1
    arc_1_13_15  in_degree_1018  1
    arc_1_13_15  original_T_including_depot_unload_1024  2.9819555494495978e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_15  arc_capacity_919  1
    load_1_13_15  free_load_conservation_1010  1
    load_1_13_15  free_load_conservation_1022  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_0  arc_capacity_921  -30
    arc_1_14_0  depot_return_or_bypass_960  1
    arc_1_14_0  out_degree_1011  1
    arc_1_14_0  original_T_including_depot_unload_1024  4.0782796387128610e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_0  arc_capacity_921  1
    load_1_14_0  free_load_conservation_1016  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_6  arc_capacity_922  -30
    arc_1_14_6  connected_order_arc_923  -11
    arc_1_14_6  in_degree_962  1
    arc_1_14_6  out_degree_1011  1
    arc_1_14_6  original_T_including_depot_unload_1024  1.7671662790958783e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_6  arc_capacity_922  1
    load_1_14_6  segment_load_conservation_965  -1
    load_1_14_6  segment_prefix_lb_966  1
    load_1_14_6  segment_prefix_ub_967  1
    load_1_14_6  free_load_conservation_1016  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_7  arc_capacity_924  -30
    arc_1_14_7  connected_order_arc_925  -11
    arc_1_14_7  in_degree_969  1
    arc_1_14_7  out_degree_1011  1
    arc_1_14_7  original_T_including_depot_unload_1024  1.7279728905134273e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_7  arc_capacity_924  1
    load_1_14_7  segment_load_conservation_972  -1
    load_1_14_7  segment_prefix_lb_973  1
    load_1_14_7  segment_prefix_ub_974  1
    load_1_14_7  free_load_conservation_1016  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_8  arc_capacity_926  -30
    arc_1_14_8  connected_order_arc_927  -11
    arc_1_14_8  in_degree_976  1
    arc_1_14_8  out_degree_1011  1
    arc_1_14_8  original_T_including_depot_unload_1024  3.6114004430677619e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_8  arc_capacity_926  1
    load_1_14_8  free_load_conservation_980  -1
    load_1_14_8  free_load_conservation_1016  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_9  arc_capacity_928  -30
    arc_1_14_9  connected_order_arc_929  -11
    arc_1_14_9  in_degree_982  1
    arc_1_14_9  out_degree_1011  1
    arc_1_14_9  original_T_including_depot_unload_1024  4.6739130846957909e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_9  arc_capacity_928  1
    load_1_14_9  free_load_conservation_986  -1
    load_1_14_9  free_load_conservation_1016  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_10  arc_capacity_930  -30
    arc_1_14_10  connected_order_arc_931  -11
    arc_1_14_10  in_degree_988  1
    arc_1_14_10  out_degree_1011  1
    arc_1_14_10  original_T_including_depot_unload_1024  2.6728511574036233e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_10  arc_capacity_930  1
    load_1_14_10  free_load_conservation_992  -1
    load_1_14_10  free_load_conservation_1016  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_11  arc_capacity_932  -30
    arc_1_14_11  connected_order_arc_933  -11
    arc_1_14_11  in_degree_994  1
    arc_1_14_11  out_degree_1011  1
    arc_1_14_11  original_T_including_depot_unload_1024  2.0430160967046345e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_11  arc_capacity_932  1
    load_1_14_11  free_load_conservation_998  -1
    load_1_14_11  free_load_conservation_1016  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_12  arc_capacity_934  -30
    arc_1_14_12  connected_order_arc_935  -11
    arc_1_14_12  in_degree_1000  1
    arc_1_14_12  out_degree_1011  1
    arc_1_14_12  original_T_including_depot_unload_1024  2.2811398160464278e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_12  arc_capacity_934  1
    load_1_14_12  free_load_conservation_1004  -1
    load_1_14_12  free_load_conservation_1016  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_13  arc_capacity_936  -30
    arc_1_14_13  connected_order_arc_937  -11
    arc_1_14_13  in_degree_1006  1
    arc_1_14_13  out_degree_1011  1
    arc_1_14_13  original_T_including_depot_unload_1024  5.3918604589472477e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_13  arc_capacity_936  1
    load_1_14_13  free_load_conservation_1010  -1
    load_1_14_13  free_load_conservation_1016  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_15  arc_capacity_938  -30
    arc_1_14_15  connected_order_arc_939  -11
    arc_1_14_15  out_degree_1011  1
    arc_1_14_15  in_degree_1018  1
    arc_1_14_15  original_T_including_depot_unload_1024  6.0329604828085382e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_15  arc_capacity_938  1
    load_1_14_15  free_load_conservation_1016  1
    load_1_14_15  free_load_conservation_1022  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_0  arc_capacity_940  -30
    arc_1_15_0  depot_return_or_bypass_960  1
    arc_1_15_0  out_degree_1017  1
    arc_1_15_0  original_T_including_depot_unload_1024  9.3133633713881534e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_0  arc_capacity_940  1
    load_1_15_0  free_load_conservation_1022  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_6  arc_capacity_941  -30
    arc_1_15_6  connected_order_arc_942  -11
    arc_1_15_6  in_degree_962  1
    arc_1_15_6  out_degree_1017  1
    arc_1_15_6  original_T_including_depot_unload_1024  2.2507610939146793e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_6  arc_capacity_941  1
    load_1_15_6  segment_load_conservation_965  -1
    load_1_15_6  segment_prefix_lb_966  1
    load_1_15_6  segment_prefix_ub_967  1
    load_1_15_6  free_load_conservation_1022  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_7  arc_capacity_943  -30
    arc_1_15_7  connected_order_arc_944  -11
    arc_1_15_7  in_degree_969  1
    arc_1_15_7  out_degree_1017  1
    arc_1_15_7  original_T_including_depot_unload_1024  2.2339035809798856e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_7  arc_capacity_943  1
    load_1_15_7  segment_load_conservation_972  -1
    load_1_15_7  segment_prefix_lb_973  1
    load_1_15_7  segment_prefix_ub_974  1
    load_1_15_7  free_load_conservation_1022  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_8  arc_capacity_945  -30
    arc_1_15_8  connected_order_arc_946  -11
    arc_1_15_8  in_degree_976  1
    arc_1_15_8  out_degree_1017  1
    arc_1_15_8  original_T_including_depot_unload_1024  2.8072002002622634e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_8  arc_capacity_945  1
    load_1_15_8  free_load_conservation_980  -1
    load_1_15_8  free_load_conservation_1022  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_9  arc_capacity_947  -30
    arc_1_15_9  connected_order_arc_948  -11
    arc_1_15_9  in_degree_982  1
    arc_1_15_9  out_degree_1017  1
    arc_1_15_9  original_T_including_depot_unload_1024  1.5413712102626312e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_9  arc_capacity_947  1
    load_1_15_9  free_load_conservation_986  -1
    load_1_15_9  free_load_conservation_1022  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_10  arc_capacity_949  -30
    arc_1_15_10  connected_order_arc_950  -11
    arc_1_15_10  in_degree_988  1
    arc_1_15_10  out_degree_1017  1
    arc_1_15_10  original_T_including_depot_unload_1024  2.8839695646198670e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_10  arc_capacity_949  1
    load_1_15_10  free_load_conservation_992  -1
    load_1_15_10  free_load_conservation_1022  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_11  arc_capacity_951  -30
    arc_1_15_11  connected_order_arc_952  -11
    arc_1_15_11  in_degree_994  1
    arc_1_15_11  out_degree_1017  1
    arc_1_15_11  original_T_including_depot_unload_1024  4.1557375918514475e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_11  arc_capacity_951  1
    load_1_15_11  free_load_conservation_998  -1
    load_1_15_11  free_load_conservation_1022  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_12  arc_capacity_953  -30
    arc_1_15_12  connected_order_arc_954  -11
    arc_1_15_12  in_degree_1000  1
    arc_1_15_12  out_degree_1017  1
    arc_1_15_12  original_T_including_depot_unload_1024  2.7766616410403444e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_12  arc_capacity_953  1
    load_1_15_12  free_load_conservation_1004  -1
    load_1_15_12  free_load_conservation_1022  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_13  arc_capacity_955  -30
    arc_1_15_13  connected_order_arc_956  -11
    arc_1_15_13  in_degree_1006  1
    arc_1_15_13  out_degree_1017  1
    arc_1_15_13  original_T_including_depot_unload_1024  2.9819555494495978e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_13  arc_capacity_955  1
    load_1_15_13  free_load_conservation_1010  -1
    load_1_15_13  free_load_conservation_1022  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_14  arc_capacity_957  -30
    arc_1_15_14  connected_order_arc_958  -11
    arc_1_15_14  in_degree_1012  1
    arc_1_15_14  out_degree_1017  1
    arc_1_15_14  original_T_including_depot_unload_1024  6.0329604828085382e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_14  arc_capacity_957  1
    load_1_15_14  free_load_conservation_1016  -1
    load_1_15_14  free_load_conservation_1022  1
RHS
    RHS1      OBJ       -0.388810654453801
    RHS1      onehot_6_4  1
    RHS1      onehot_3_41  1
    RHS1      onehot_18_76  1
    RHS1      onehot_7_101  1
    RHS1      onehot_17_138  1
    RHS1      onehot_5_147  1
    RHS1      onehot_11_182  1
    RHS1      onehot_2_189  1
    RHS1      stock_ub_193  23
    RHS1      parent_nonstrict_scope_194  5.5117120234392014e-01
    RHS1      normalization_251  1
    RHS1      connected_order_arc_345  -13
    RHS1      connected_order_arc_347  -13
    RHS1      connected_order_arc_349  -13
    RHS1      connected_order_arc_351  -13
    RHS1      connected_order_arc_353  -13
    RHS1      connected_order_arc_355  -13
    RHS1      connected_order_arc_357  -13
    RHS1      connected_order_arc_359  -13
    RHS1      connected_order_arc_361  -13
    RHS1      connected_order_arc_363  -13
    RHS1      connected_order_arc_365  -13
    RHS1      connected_order_arc_367  -13
    RHS1      connected_order_arc_370  -13
    RHS1      connected_order_arc_372  -13
    RHS1      connected_order_arc_374  -13
    RHS1      connected_order_arc_376  -13
    RHS1      connected_order_arc_378  -13
    RHS1      connected_order_arc_380  -13
    RHS1      connected_order_arc_382  -13
    RHS1      connected_order_arc_384  -13
    RHS1      connected_order_arc_386  -13
    RHS1      connected_order_arc_388  -13
    RHS1      connected_order_arc_390  -13
    RHS1      connected_order_arc_392  -13
    RHS1      connected_order_arc_395  -13
    RHS1      connected_order_arc_397  -13
    RHS1      connected_order_arc_399  -13
    RHS1      connected_order_arc_401  -13
    RHS1      connected_order_arc_403  -13
    RHS1      connected_order_arc_405  -13
    RHS1      connected_order_arc_407  -13
    RHS1      connected_order_arc_409  -13
    RHS1      connected_order_arc_411  -13
    RHS1      connected_order_arc_413  -13
    RHS1      connected_order_arc_415  -13
    RHS1      connected_order_arc_417  -13
    RHS1      connected_order_arc_420  -13
    RHS1      connected_order_arc_422  -13
    RHS1      connected_order_arc_424  -13
    RHS1      connected_order_arc_426  -13
    RHS1      connected_order_arc_428  -13
    RHS1      connected_order_arc_430  -13
    RHS1      connected_order_arc_432  -13
    RHS1      connected_order_arc_434  -13
    RHS1      connected_order_arc_436  -13
    RHS1      connected_order_arc_438  -13
    RHS1      connected_order_arc_440  -13
    RHS1      connected_order_arc_442  -13
    RHS1      connected_order_arc_445  -13
    RHS1      connected_order_arc_447  -13
    RHS1      connected_order_arc_449  -13
    RHS1      connected_order_arc_451  -13
    RHS1      connected_order_arc_453  -13
    RHS1      connected_order_arc_455  -13
    RHS1      connected_order_arc_457  -13
    RHS1      connected_order_arc_459  -13
    RHS1      connected_order_arc_461  -13
    RHS1      connected_order_arc_463  -13
    RHS1      connected_order_arc_465  -13
    RHS1      connected_order_arc_467  -13
    RHS1      connected_order_arc_470  -13
    RHS1      connected_order_arc_472  -13
    RHS1      connected_order_arc_474  -13
    RHS1      connected_order_arc_476  -13
    RHS1      connected_order_arc_478  -13
    RHS1      connected_order_arc_480  -13
    RHS1      connected_order_arc_482  -13
    RHS1      connected_order_arc_484  -13
    RHS1      connected_order_arc_486  -13
    RHS1      connected_order_arc_488  -13
    RHS1      connected_order_arc_490  -13
    RHS1      connected_order_arc_492  -13
    RHS1      connected_order_arc_495  -13
    RHS1      connected_order_arc_497  -13
    RHS1      connected_order_arc_499  -13
    RHS1      connected_order_arc_501  -13
    RHS1      connected_order_arc_503  -13
    RHS1      connected_order_arc_505  -13
    RHS1      connected_order_arc_507  -13
    RHS1      connected_order_arc_509  -13
    RHS1      connected_order_arc_511  -13
    RHS1      connected_order_arc_513  -13
    RHS1      connected_order_arc_515  -13
    RHS1      connected_order_arc_517  -13
    RHS1      connected_order_arc_520  -13
    RHS1      connected_order_arc_522  -13
    RHS1      connected_order_arc_524  -13
    RHS1      connected_order_arc_526  -13
    RHS1      connected_order_arc_528  -13
    RHS1      connected_order_arc_530  -13
    RHS1      connected_order_arc_532  -13
    RHS1      connected_order_arc_534  -13
    RHS1      connected_order_arc_536  -13
    RHS1      connected_order_arc_538  -13
    RHS1      connected_order_arc_540  -13
    RHS1      connected_order_arc_542  -13
    RHS1      connected_order_arc_545  -13
    RHS1      connected_order_arc_547  -13
    RHS1      connected_order_arc_549  -13
    RHS1      connected_order_arc_551  -13
    RHS1      connected_order_arc_553  -13
    RHS1      connected_order_arc_555  -13
    RHS1      connected_order_arc_557  -13
    RHS1      connected_order_arc_559  -13
    RHS1      connected_order_arc_561  -13
    RHS1      connected_order_arc_563  -13
    RHS1      connected_order_arc_565  -13
    RHS1      connected_order_arc_567  -13
    RHS1      connected_order_arc_570  -13
    RHS1      connected_order_arc_572  -13
    RHS1      connected_order_arc_574  -13
    RHS1      connected_order_arc_576  -13
    RHS1      connected_order_arc_578  -13
    RHS1      connected_order_arc_580  -13
    RHS1      connected_order_arc_582  -13
    RHS1      connected_order_arc_584  -13
    RHS1      connected_order_arc_586  -13
    RHS1      connected_order_arc_588  -13
    RHS1      connected_order_arc_590  -13
    RHS1      connected_order_arc_592  -13
    RHS1      connected_order_arc_595  -13
    RHS1      connected_order_arc_597  -13
    RHS1      connected_order_arc_599  -13
    RHS1      connected_order_arc_601  -13
    RHS1      connected_order_arc_603  -13
    RHS1      connected_order_arc_605  -13
    RHS1      connected_order_arc_607  -13
    RHS1      connected_order_arc_609  -13
    RHS1      connected_order_arc_611  -13
    RHS1      connected_order_arc_613  -13
    RHS1      connected_order_arc_615  -13
    RHS1      connected_order_arc_617  -13
    RHS1      connected_order_arc_620  -13
    RHS1      connected_order_arc_622  -13
    RHS1      connected_order_arc_624  -13
    RHS1      connected_order_arc_626  -13
    RHS1      connected_order_arc_628  -13
    RHS1      connected_order_arc_630  -13
    RHS1      connected_order_arc_632  -13
    RHS1      connected_order_arc_634  -13
    RHS1      connected_order_arc_636  -13
    RHS1      connected_order_arc_638  -13
    RHS1      connected_order_arc_640  -13
    RHS1      connected_order_arc_642  -13
    RHS1      connected_order_arc_645  -13
    RHS1      connected_order_arc_647  -13
    RHS1      connected_order_arc_649  -13
    RHS1      connected_order_arc_651  -13
    RHS1      connected_order_arc_653  -13
    RHS1      connected_order_arc_655  -13
    RHS1      connected_order_arc_657  -13
    RHS1      connected_order_arc_659  -13
    RHS1      connected_order_arc_661  -13
    RHS1      connected_order_arc_663  -13
    RHS1      connected_order_arc_665  -13
    RHS1      connected_order_arc_667  -13
    RHS1      depot_departure_or_bypass_668  1
    RHS1      depot_return_or_bypass_669  1
    RHS1      segment_load_conservation_674  3
    RHS1      segment_prefix_ub_676  27
    RHS1      segment_load_conservation_681  -1
    RHS1      segment_prefix_lb_682  1
    RHS1      segment_prefix_ub_683  30
    RHS1      segment_load_conservation_688  4
    RHS1      segment_prefix_ub_690  26
    RHS1      segment_load_conservation_695  -2
    RHS1      segment_prefix_lb_696  2
    RHS1      segment_prefix_ub_697  30
    RHS1      segment_load_conservation_702  -1
    RHS1      segment_prefix_lb_703  1
    RHS1      segment_prefix_ub_704  30
    RHS1      fixed_segment_relative_order_753  1
    RHS1      fixed_segment_relative_order_754  1
    RHS1      fixed_segment_relative_order_755  1
    RHS1      fixed_segment_relative_order_756  1
    RHS1      original_T_including_depot_unload_757  3960
    RHS1      connected_order_arc_771  -10
    RHS1      connected_order_arc_773  -10
    RHS1      connected_order_arc_775  -10
    RHS1      connected_order_arc_777  -10
    RHS1      connected_order_arc_779  -10
    RHS1      connected_order_arc_781  -10
    RHS1      connected_order_arc_783  -10
    RHS1      connected_order_arc_785  -10
    RHS1      connected_order_arc_787  -10
    RHS1      connected_order_arc_790  -10
    RHS1      connected_order_arc_792  -10
    RHS1      connected_order_arc_794  -10
    RHS1      connected_order_arc_796  -10
    RHS1      connected_order_arc_798  -10
    RHS1      connected_order_arc_800  -10
    RHS1      connected_order_arc_802  -10
    RHS1      connected_order_arc_804  -10
    RHS1      connected_order_arc_806  -10
    RHS1      connected_order_arc_809  -10
    RHS1      connected_order_arc_811  -10
    RHS1      connected_order_arc_813  -10
    RHS1      connected_order_arc_815  -10
    RHS1      connected_order_arc_817  -10
    RHS1      connected_order_arc_819  -10
    RHS1      connected_order_arc_821  -10
    RHS1      connected_order_arc_823  -10
    RHS1      connected_order_arc_825  -10
    RHS1      connected_order_arc_828  -10
    RHS1      connected_order_arc_830  -10
    RHS1      connected_order_arc_832  -10
    RHS1      connected_order_arc_834  -10
    RHS1      connected_order_arc_836  -10
    RHS1      connected_order_arc_838  -10
    RHS1      connected_order_arc_840  -10
    RHS1      connected_order_arc_842  -10
    RHS1      connected_order_arc_844  -10
    RHS1      connected_order_arc_847  -10
    RHS1      connected_order_arc_849  -10
    RHS1      connected_order_arc_851  -10
    RHS1      connected_order_arc_853  -10
    RHS1      connected_order_arc_855  -10
    RHS1      connected_order_arc_857  -10
    RHS1      connected_order_arc_859  -10
    RHS1      connected_order_arc_861  -10
    RHS1      connected_order_arc_863  -10
    RHS1      connected_order_arc_866  -10
    RHS1      connected_order_arc_868  -10
    RHS1      connected_order_arc_870  -10
    RHS1      connected_order_arc_872  -10
    RHS1      connected_order_arc_874  -10
    RHS1      connected_order_arc_876  -10
    RHS1      connected_order_arc_878  -10
    RHS1      connected_order_arc_880  -10
    RHS1      connected_order_arc_882  -10
    RHS1      connected_order_arc_885  -10
    RHS1      connected_order_arc_887  -10
    RHS1      connected_order_arc_889  -10
    RHS1      connected_order_arc_891  -10
    RHS1      connected_order_arc_893  -10
    RHS1      connected_order_arc_895  -10
    RHS1      connected_order_arc_897  -10
    RHS1      connected_order_arc_899  -10
    RHS1      connected_order_arc_901  -10
    RHS1      connected_order_arc_904  -10
    RHS1      connected_order_arc_906  -10
    RHS1      connected_order_arc_908  -10
    RHS1      connected_order_arc_910  -10
    RHS1      connected_order_arc_912  -10
    RHS1      connected_order_arc_914  -10
    RHS1      connected_order_arc_916  -10
    RHS1      connected_order_arc_918  -10
    RHS1      connected_order_arc_920  -10
    RHS1      connected_order_arc_923  -10
    RHS1      connected_order_arc_925  -10
    RHS1      connected_order_arc_927  -10
    RHS1      connected_order_arc_929  -10
    RHS1      connected_order_arc_931  -10
    RHS1      connected_order_arc_933  -10
    RHS1      connected_order_arc_935  -10
    RHS1      connected_order_arc_937  -10
    RHS1      connected_order_arc_939  -10
    RHS1      connected_order_arc_942  -10
    RHS1      connected_order_arc_944  -10
    RHS1      connected_order_arc_946  -10
    RHS1      connected_order_arc_948  -10
    RHS1      connected_order_arc_950  -10
    RHS1      connected_order_arc_952  -10
    RHS1      connected_order_arc_954  -10
    RHS1      connected_order_arc_956  -10
    RHS1      connected_order_arc_958  -10
    RHS1      depot_departure_or_bypass_959  1
    RHS1      depot_return_or_bypass_960  1
    RHS1      segment_load_conservation_965  4
    RHS1      segment_prefix_ub_967  26
    RHS1      segment_load_conservation_972  -1
    RHS1      segment_prefix_lb_973  1
    RHS1      segment_prefix_ub_974  30
    RHS1      fixed_segment_relative_order_1023  1
    RHS1      original_T_including_depot_unload_1024  4320
BOUNDS
 LO BND1      t         4.3731019522732839e-02
 UP BND1      t         1.1023622047255120e-01
 UP BND1      q         6.9405070034003413e-01
 BV BND1      x_6_0   
 UP BND1      w_6_0     1.1023622047255120e-01
 BV BND1      x_6_1   
 UP BND1      w_6_1     1.1023622047255120e-01
 UP BND1      rho_6     1
 BV BND1      x_3_0   
 UP BND1      w_3_0     1.1023622047255120e-01
 BV BND1      x_3_1   
 UP BND1      w_3_1     1.1023622047255120e-01
 BV BND1      x_3_2   
 UP BND1      w_3_2     1.1023622047255120e-01
 BV BND1      x_3_3   
 UP BND1      w_3_3     1.1023622047255120e-01
 BV BND1      x_3_4   
 UP BND1      w_3_4     1.1023622047255120e-01
 BV BND1      x_3_5   
 UP BND1      w_3_5     1.1023622047255120e-01
 BV BND1      x_3_6   
 UP BND1      w_3_6     1.1023622047255120e-01
 BV BND1      x_3_7   
 UP BND1      w_3_7     1.1023622047255120e-01
 BV BND1      x_3_8   
 UP BND1      w_3_8     1.1023622047255120e-01
 BV BND1      x_3_9   
 UP BND1      w_3_9     1.1023622047255120e-01
 BV BND1      x_3_10  
 UP BND1      w_3_10    1.1023622047255120e-01
 BV BND1      x_3_11  
 UP BND1      w_3_11    1.1023622047255120e-01
 BV BND1      x_3_12  
 UP BND1      w_3_12    1.1023622047255120e-01
 BV BND1      x_3_13  
 UP BND1      w_3_13    1.1023622047255120e-01
 BV BND1      x_3_14  
 UP BND1      w_3_14    1.1023622047255120e-01
 BV BND1      x_3_15  
 UP BND1      w_3_15    1.1023622047255120e-01
 BV BND1      x_3_16  
 UP BND1      w_3_16    1.1023622047255120e-01
 UP BND1      rho_3     1
 BV BND1      x_18_0  
 UP BND1      w_18_0    1.1023622047255120e-01
 BV BND1      x_18_1  
 UP BND1      w_18_1    1.1023622047255120e-01
 BV BND1      x_18_2  
 UP BND1      w_18_2    1.1023622047255120e-01
 BV BND1      x_18_3  
 UP BND1      w_18_3    1.1023622047255120e-01
 BV BND1      x_18_4  
 UP BND1      w_18_4    1.1023622047255120e-01
 BV BND1      x_18_5  
 UP BND1      w_18_5    1.1023622047255120e-01
 BV BND1      x_18_6  
 UP BND1      w_18_6    1.1023622047255120e-01
 BV BND1      x_18_7  
 UP BND1      w_18_7    1.1023622047255120e-01
 BV BND1      x_18_8  
 UP BND1      w_18_8    1.1023622047255120e-01
 BV BND1      x_18_9  
 UP BND1      w_18_9    1.1023622047255120e-01
 BV BND1      x_18_10 
 UP BND1      w_18_10   1.1023622047255120e-01
 BV BND1      x_18_11 
 UP BND1      w_18_11   1.1023622047255120e-01
 BV BND1      x_18_12 
 UP BND1      w_18_12   1.1023622047255120e-01
 BV BND1      x_18_13 
 UP BND1      w_18_13   1.1023622047255120e-01
 BV BND1      x_18_14 
 UP BND1      w_18_14   1.1023622047255120e-01
 BV BND1      x_18_15 
 UP BND1      w_18_15   1.1023622047255120e-01
 UP BND1      rho_18    1
 BV BND1      x_7_0   
 UP BND1      w_7_0     1.1023622047255120e-01
 BV BND1      x_7_1   
 UP BND1      w_7_1     1.1023622047255120e-01
 BV BND1      x_7_2   
 UP BND1      w_7_2     1.1023622047255120e-01
 BV BND1      x_7_3   
 UP BND1      w_7_3     1.1023622047255120e-01
 BV BND1      x_7_4   
 UP BND1      w_7_4     1.1023622047255120e-01
 BV BND1      x_7_5   
 UP BND1      w_7_5     1.1023622047255120e-01
 BV BND1      x_7_6   
 UP BND1      w_7_6     1.1023622047255120e-01
 BV BND1      x_7_7   
 UP BND1      w_7_7     1.1023622047255120e-01
 BV BND1      x_7_8   
 UP BND1      w_7_8     1.1023622047255120e-01
 BV BND1      x_7_9   
 UP BND1      w_7_9     1.1023622047255120e-01
 BV BND1      x_7_10  
 UP BND1      w_7_10    1.1023622047255120e-01
 UP BND1      rho_7     1
 BV BND1      x_17_0  
 UP BND1      w_17_0    1.1023622047255120e-01
 BV BND1      x_17_1  
 UP BND1      w_17_1    1.1023622047255120e-01
 BV BND1      x_17_2  
 UP BND1      w_17_2    1.1023622047255120e-01
 BV BND1      x_17_3  
 UP BND1      w_17_3    1.1023622047255120e-01
 BV BND1      x_17_4  
 UP BND1      w_17_4    1.1023622047255120e-01
 BV BND1      x_17_5  
 UP BND1      w_17_5    1.1023622047255120e-01
 BV BND1      x_17_6  
 UP BND1      w_17_6    1.1023622047255120e-01
 BV BND1      x_17_7  
 UP BND1      w_17_7    1.1023622047255120e-01
 BV BND1      x_17_8  
 UP BND1      w_17_8    1.1023622047255120e-01
 BV BND1      x_17_9  
 UP BND1      w_17_9    1.1023622047255120e-01
 BV BND1      x_17_10 
 UP BND1      w_17_10   1.1023622047255120e-01
 BV BND1      x_17_11 
 UP BND1      w_17_11   1.1023622047255120e-01
 BV BND1      x_17_12 
 UP BND1      w_17_12   1.1023622047255120e-01
 BV BND1      x_17_13 
 UP BND1      w_17_13   1.1023622047255120e-01
 BV BND1      x_17_14 
 UP BND1      w_17_14   1.1023622047255120e-01
 BV BND1      x_17_15 
 UP BND1      w_17_15   1.1023622047255120e-01
 BV BND1      x_17_16 
 UP BND1      w_17_16   1.1023622047255120e-01
 UP BND1      rho_17    1
 BV BND1      x_5_0   
 UP BND1      w_5_0     1.1023622047255120e-01
 BV BND1      x_5_1   
 UP BND1      w_5_1     1.1023622047255120e-01
 BV BND1      x_5_2   
 UP BND1      w_5_2     1.1023622047255120e-01
 UP BND1      rho_5     1
 BV BND1      x_11_0  
 UP BND1      w_11_0    1.1023622047255120e-01
 BV BND1      x_11_1  
 UP BND1      w_11_1    1.1023622047255120e-01
 BV BND1      x_11_2  
 UP BND1      w_11_2    1.1023622047255120e-01
 BV BND1      x_11_3  
 UP BND1      w_11_3    1.1023622047255120e-01
 BV BND1      x_11_4  
 UP BND1      w_11_4    1.1023622047255120e-01
 BV BND1      x_11_5  
 UP BND1      w_11_5    1.1023622047255120e-01
 BV BND1      x_11_6  
 UP BND1      w_11_6    1.1023622047255120e-01
 BV BND1      x_11_7  
 UP BND1      w_11_7    1.1023622047255120e-01
 BV BND1      x_11_8  
 UP BND1      w_11_8    1.1023622047255120e-01
 BV BND1      x_11_9  
 UP BND1      w_11_9    1.1023622047255120e-01
 BV BND1      x_11_10 
 UP BND1      w_11_10   1.1023622047255120e-01
 BV BND1      x_11_11 
 UP BND1      w_11_11   1.1023622047255120e-01
 BV BND1      x_11_12 
 UP BND1      w_11_12   1.1023622047255120e-01
 BV BND1      x_11_13 
 UP BND1      w_11_13   1.1023622047255120e-01
 BV BND1      x_11_14 
 UP BND1      w_11_14   1.1023622047255120e-01
 BV BND1      x_11_15 
 UP BND1      w_11_15   1.1023622047255120e-01
 UP BND1      rho_11    1
 BV BND1      x_2_0   
 UP BND1      w_2_0     1.1023622047255120e-01
 BV BND1      x_2_1   
 UP BND1      w_2_1     1.1023622047255120e-01
 UP BND1      rho_2     1
 UP BND1      a_6_3     1
 UP BND1      a_6_18    1
 UP BND1      a_6_7     1
 UP BND1      a_6_17    1
 UP BND1      a_6_5     1
 UP BND1      a_6_11    1
 UP BND1      a_6_2     1
 UP BND1      a_3_18    1
 UP BND1      a_3_7     1
 UP BND1      a_3_17    1
 UP BND1      a_3_5     1
 UP BND1      a_3_11    1
 UP BND1      a_3_2     1
 UP BND1      a_18_7    1
 UP BND1      a_18_17   1
 UP BND1      a_18_5    1
 UP BND1      a_18_11   1
 UP BND1      a_18_2    1
 UP BND1      a_7_17    1
 UP BND1      a_7_5     1
 UP BND1      a_7_11    1
 UP BND1      a_7_2     1
 UP BND1      a_17_5    1
 UP BND1      a_17_11   1
 UP BND1      a_17_2    1
 UP BND1      a_5_11    1
 UP BND1      a_5_2     1
 UP BND1      a_11_2    1
 BV BND1      service_0_6_1
 BV BND1      service_1_6_1
 BV BND1      service_0_3_0
 BV BND1      service_0_3_1
 BV BND1      service_0_3_2
 BV BND1      service_0_3_3
 BV BND1      service_0_3_4
 BV BND1      service_0_3_5
 BV BND1      service_0_3_6
 BV BND1      service_0_3_7
 BV BND1      service_0_3_8
 BV BND1      service_0_3_9
 BV BND1      service_0_3_10
 BV BND1      service_0_3_11
 BV BND1      service_0_3_13
 BV BND1      service_0_3_14
 BV BND1      service_0_3_15
 BV BND1      service_0_3_16
 BV BND1      service_1_3_0
 BV BND1      service_1_3_1
 BV BND1      service_1_3_2
 BV BND1      service_1_3_3
 BV BND1      service_1_3_4
 BV BND1      service_1_3_5
 BV BND1      service_1_3_6
 BV BND1      service_1_3_7
 BV BND1      service_1_3_8
 BV BND1      service_1_3_9
 BV BND1      service_1_3_10
 BV BND1      service_1_3_11
 BV BND1      service_1_3_13
 BV BND1      service_1_3_14
 BV BND1      service_1_3_15
 BV BND1      service_1_3_16
 BV BND1      service_0_18_1
 BV BND1      service_0_18_2
 BV BND1      service_0_18_3
 BV BND1      service_0_18_4
 BV BND1      service_0_18_5
 BV BND1      service_0_18_6
 BV BND1      service_0_18_7
 BV BND1      service_0_18_8
 BV BND1      service_0_18_9
 BV BND1      service_0_18_10
 BV BND1      service_0_18_11
 BV BND1      service_0_18_12
 BV BND1      service_0_18_13
 BV BND1      service_0_18_14
 BV BND1      service_0_18_15
 BV BND1      service_1_18_1
 BV BND1      service_1_18_2
 BV BND1      service_1_18_3
 BV BND1      service_1_18_4
 BV BND1      service_1_18_5
 BV BND1      service_1_18_6
 BV BND1      service_1_18_7
 BV BND1      service_1_18_8
 BV BND1      service_1_18_9
 BV BND1      service_1_18_10
 BV BND1      service_1_18_11
 BV BND1      service_1_18_12
 BV BND1      service_1_18_13
 BV BND1      service_1_18_14
 BV BND1      service_1_18_15
 BV BND1      service_0_7_0
 BV BND1      service_0_7_2
 BV BND1      service_0_7_3
 BV BND1      service_0_7_4
 BV BND1      service_0_7_5
 BV BND1      service_0_7_6
 BV BND1      service_0_7_7
 BV BND1      service_0_7_8
 BV BND1      service_0_7_9
 BV BND1      service_0_7_10
 BV BND1      service_1_7_0
 BV BND1      service_1_7_2
 BV BND1      service_1_7_3
 BV BND1      service_1_7_4
 BV BND1      service_1_7_5
 BV BND1      service_1_7_6
 BV BND1      service_1_7_7
 BV BND1      service_1_7_8
 BV BND1      service_1_7_9
 BV BND1      service_1_7_10
 BV BND1      service_0_17_0
 BV BND1      service_0_17_1
 BV BND1      service_0_17_2
 BV BND1      service_0_17_4
 BV BND1      service_0_17_5
 BV BND1      service_0_17_6
 BV BND1      service_0_17_7
 BV BND1      service_0_17_8
 BV BND1      service_0_17_9
 BV BND1      service_0_17_10
 BV BND1      service_0_17_11
 BV BND1      service_0_17_12
 BV BND1      service_0_17_13
 BV BND1      service_0_17_14
 BV BND1      service_0_17_15
 BV BND1      service_0_17_16
 BV BND1      service_1_17_0
 BV BND1      service_1_17_1
 BV BND1      service_1_17_2
 BV BND1      service_1_17_4
 BV BND1      service_1_17_5
 BV BND1      service_1_17_6
 BV BND1      service_1_17_7
 BV BND1      service_1_17_8
 BV BND1      service_1_17_9
 BV BND1      service_1_17_10
 BV BND1      service_1_17_11
 BV BND1      service_1_17_12
 BV BND1      service_1_17_13
 BV BND1      service_1_17_14
 BV BND1      service_1_17_15
 BV BND1      service_1_17_16
 BV BND1      service_0_5_1
 BV BND1      service_0_5_2
 BV BND1      service_1_5_1
 BV BND1      service_1_5_2
 BV BND1      service_0_11_0
 BV BND1      service_0_11_2
 BV BND1      service_0_11_3
 BV BND1      service_0_11_4
 BV BND1      service_0_11_5
 BV BND1      service_0_11_6
 BV BND1      service_0_11_7
 BV BND1      service_0_11_8
 BV BND1      service_0_11_9
 BV BND1      service_0_11_10
 BV BND1      service_0_11_11
 BV BND1      service_0_11_12
 BV BND1      service_0_11_13
 BV BND1      service_0_11_14
 BV BND1      service_0_11_15
 BV BND1      service_1_11_0
 BV BND1      service_1_11_2
 BV BND1      service_1_11_3
 BV BND1      service_1_11_4
 BV BND1      service_1_11_5
 BV BND1      service_1_11_6
 BV BND1      service_1_11_7
 BV BND1      service_1_11_8
 BV BND1      service_1_11_9
 BV BND1      service_1_11_10
 BV BND1      service_1_11_11
 BV BND1      service_1_11_12
 BV BND1      service_1_11_13
 BV BND1      service_1_11_14
 BV BND1      service_1_11_15
 BV BND1      service_0_2_1
 BV BND1      service_1_2_1
 FX BND1      visit_0_1  1
 UP BND1      order_0_1  13
 FX BND1      visit_0_2  1
 UP BND1      order_0_2  13
 FX BND1      visit_0_3  1
 UP BND1      order_0_3  13
 FX BND1      visit_0_4  1
 UP BND1      order_0_4  13
 FX BND1      visit_0_5  1
 UP BND1      order_0_5  13
 UP BND1      visit_0_8  1
 UP BND1      order_0_8  13
 UP BND1      visit_0_9  1
 UP BND1      order_0_9  13
 UP BND1      visit_0_10  1
 UP BND1      order_0_10  13
 UP BND1      visit_0_11  1
 UP BND1      order_0_11  13
 UP BND1      visit_0_12  1
 UP BND1      order_0_12  13
 UP BND1      visit_0_13  1
 UP BND1      order_0_13  13
 UP BND1      visit_0_14  1
 UP BND1      order_0_14  13
 UP BND1      visit_0_15  1
 UP BND1      order_0_15  13
 BV BND1      arc_0_0_0
 FX BND1      load_0_0_0  0
 BV BND1      arc_0_0_1
 FX BND1      load_0_0_1  0
 BV BND1      arc_0_0_2
 FX BND1      load_0_0_2  0
 BV BND1      arc_0_0_3
 FX BND1      load_0_0_3  0
 BV BND1      arc_0_0_4
 FX BND1      load_0_0_4  0
 BV BND1      arc_0_0_5
 FX BND1      load_0_0_5  0
 BV BND1      arc_0_0_8
 FX BND1      load_0_0_8  0
 BV BND1      arc_0_0_9
 FX BND1      load_0_0_9  0
 BV BND1      arc_0_0_10
 FX BND1      load_0_0_10  0
 BV BND1      arc_0_0_11
 FX BND1      load_0_0_11  0
 BV BND1      arc_0_0_12
 FX BND1      load_0_0_12  0
 BV BND1      arc_0_0_13
 FX BND1      load_0_0_13  0
 BV BND1      arc_0_0_14
 FX BND1      load_0_0_14  0
 BV BND1      arc_0_0_15
 FX BND1      load_0_0_15  0
 BV BND1      arc_0_1_0
 UP BND1      load_0_1_0  30
 BV BND1      arc_0_1_2
 UP BND1      load_0_1_2  30
 BV BND1      arc_0_1_3
 UP BND1      load_0_1_3  30
 BV BND1      arc_0_1_4
 UP BND1      load_0_1_4  30
 BV BND1      arc_0_1_5
 UP BND1      load_0_1_5  30
 BV BND1      arc_0_1_8
 UP BND1      load_0_1_8  30
 BV BND1      arc_0_1_9
 UP BND1      load_0_1_9  30
 BV BND1      arc_0_1_10
 UP BND1      load_0_1_10  30
 BV BND1      arc_0_1_11
 UP BND1      load_0_1_11  30
 BV BND1      arc_0_1_12
 UP BND1      load_0_1_12  30
 BV BND1      arc_0_1_13
 UP BND1      load_0_1_13  30
 BV BND1      arc_0_1_14
 UP BND1      load_0_1_14  30
 BV BND1      arc_0_1_15
 UP BND1      load_0_1_15  30
 BV BND1      arc_0_2_0
 UP BND1      load_0_2_0  30
 BV BND1      arc_0_2_1
 UP BND1      load_0_2_1  30
 BV BND1      arc_0_2_3
 UP BND1      load_0_2_3  30
 BV BND1      arc_0_2_4
 UP BND1      load_0_2_4  30
 BV BND1      arc_0_2_5
 UP BND1      load_0_2_5  30
 BV BND1      arc_0_2_8
 UP BND1      load_0_2_8  30
 BV BND1      arc_0_2_9
 UP BND1      load_0_2_9  30
 BV BND1      arc_0_2_10
 UP BND1      load_0_2_10  30
 BV BND1      arc_0_2_11
 UP BND1      load_0_2_11  30
 BV BND1      arc_0_2_12
 UP BND1      load_0_2_12  30
 BV BND1      arc_0_2_13
 UP BND1      load_0_2_13  30
 BV BND1      arc_0_2_14
 UP BND1      load_0_2_14  30
 BV BND1      arc_0_2_15
 UP BND1      load_0_2_15  30
 BV BND1      arc_0_3_0
 UP BND1      load_0_3_0  30
 BV BND1      arc_0_3_1
 UP BND1      load_0_3_1  30
 BV BND1      arc_0_3_2
 UP BND1      load_0_3_2  30
 BV BND1      arc_0_3_4
 UP BND1      load_0_3_4  30
 BV BND1      arc_0_3_5
 UP BND1      load_0_3_5  30
 BV BND1      arc_0_3_8
 UP BND1      load_0_3_8  30
 BV BND1      arc_0_3_9
 UP BND1      load_0_3_9  30
 BV BND1      arc_0_3_10
 UP BND1      load_0_3_10  30
 BV BND1      arc_0_3_11
 UP BND1      load_0_3_11  30
 BV BND1      arc_0_3_12
 UP BND1      load_0_3_12  30
 BV BND1      arc_0_3_13
 UP BND1      load_0_3_13  30
 BV BND1      arc_0_3_14
 UP BND1      load_0_3_14  30
 BV BND1      arc_0_3_15
 UP BND1      load_0_3_15  30
 BV BND1      arc_0_4_0
 UP BND1      load_0_4_0  30
 BV BND1      arc_0_4_1
 UP BND1      load_0_4_1  30
 BV BND1      arc_0_4_2
 UP BND1      load_0_4_2  30
 BV BND1      arc_0_4_3
 UP BND1      load_0_4_3  30
 BV BND1      arc_0_4_5
 UP BND1      load_0_4_5  30
 BV BND1      arc_0_4_8
 UP BND1      load_0_4_8  30
 BV BND1      arc_0_4_9
 UP BND1      load_0_4_9  30
 BV BND1      arc_0_4_10
 UP BND1      load_0_4_10  30
 BV BND1      arc_0_4_11
 UP BND1      load_0_4_11  30
 BV BND1      arc_0_4_12
 UP BND1      load_0_4_12  30
 BV BND1      arc_0_4_13
 UP BND1      load_0_4_13  30
 BV BND1      arc_0_4_14
 UP BND1      load_0_4_14  30
 BV BND1      arc_0_4_15
 UP BND1      load_0_4_15  30
 BV BND1      arc_0_5_0
 UP BND1      load_0_5_0  30
 BV BND1      arc_0_5_1
 UP BND1      load_0_5_1  30
 BV BND1      arc_0_5_2
 UP BND1      load_0_5_2  30
 BV BND1      arc_0_5_3
 UP BND1      load_0_5_3  30
 BV BND1      arc_0_5_4
 UP BND1      load_0_5_4  30
 BV BND1      arc_0_5_8
 UP BND1      load_0_5_8  30
 BV BND1      arc_0_5_9
 UP BND1      load_0_5_9  30
 BV BND1      arc_0_5_10
 UP BND1      load_0_5_10  30
 BV BND1      arc_0_5_11
 UP BND1      load_0_5_11  30
 BV BND1      arc_0_5_12
 UP BND1      load_0_5_12  30
 BV BND1      arc_0_5_13
 UP BND1      load_0_5_13  30
 BV BND1      arc_0_5_14
 UP BND1      load_0_5_14  30
 BV BND1      arc_0_5_15
 UP BND1      load_0_5_15  30
 BV BND1      arc_0_8_0
 UP BND1      load_0_8_0  30
 BV BND1      arc_0_8_1
 UP BND1      load_0_8_1  30
 BV BND1      arc_0_8_2
 UP BND1      load_0_8_2  30
 BV BND1      arc_0_8_3
 UP BND1      load_0_8_3  30
 BV BND1      arc_0_8_4
 UP BND1      load_0_8_4  30
 BV BND1      arc_0_8_5
 UP BND1      load_0_8_5  30
 BV BND1      arc_0_8_9
 UP BND1      load_0_8_9  30
 BV BND1      arc_0_8_10
 UP BND1      load_0_8_10  30
 BV BND1      arc_0_8_11
 UP BND1      load_0_8_11  30
 BV BND1      arc_0_8_12
 UP BND1      load_0_8_12  30
 BV BND1      arc_0_8_13
 UP BND1      load_0_8_13  30
 BV BND1      arc_0_8_14
 UP BND1      load_0_8_14  30
 BV BND1      arc_0_8_15
 UP BND1      load_0_8_15  30
 BV BND1      arc_0_9_0
 UP BND1      load_0_9_0  30
 BV BND1      arc_0_9_1
 UP BND1      load_0_9_1  30
 BV BND1      arc_0_9_2
 UP BND1      load_0_9_2  30
 BV BND1      arc_0_9_3
 UP BND1      load_0_9_3  30
 BV BND1      arc_0_9_4
 UP BND1      load_0_9_4  30
 BV BND1      arc_0_9_5
 UP BND1      load_0_9_5  30
 BV BND1      arc_0_9_8
 UP BND1      load_0_9_8  30
 BV BND1      arc_0_9_10
 UP BND1      load_0_9_10  30
 BV BND1      arc_0_9_11
 UP BND1      load_0_9_11  30
 BV BND1      arc_0_9_12
 UP BND1      load_0_9_12  30
 BV BND1      arc_0_9_13
 UP BND1      load_0_9_13  30
 BV BND1      arc_0_9_14
 UP BND1      load_0_9_14  30
 BV BND1      arc_0_9_15
 UP BND1      load_0_9_15  30
 BV BND1      arc_0_10_0
 UP BND1      load_0_10_0  30
 BV BND1      arc_0_10_1
 UP BND1      load_0_10_1  30
 BV BND1      arc_0_10_2
 UP BND1      load_0_10_2  30
 BV BND1      arc_0_10_3
 UP BND1      load_0_10_3  30
 BV BND1      arc_0_10_4
 UP BND1      load_0_10_4  30
 BV BND1      arc_0_10_5
 UP BND1      load_0_10_5  30
 BV BND1      arc_0_10_8
 UP BND1      load_0_10_8  30
 BV BND1      arc_0_10_9
 UP BND1      load_0_10_9  30
 BV BND1      arc_0_10_11
 UP BND1      load_0_10_11  30
 BV BND1      arc_0_10_12
 UP BND1      load_0_10_12  30
 BV BND1      arc_0_10_13
 UP BND1      load_0_10_13  30
 BV BND1      arc_0_10_14
 UP BND1      load_0_10_14  30
 BV BND1      arc_0_10_15
 UP BND1      load_0_10_15  30
 BV BND1      arc_0_11_0
 UP BND1      load_0_11_0  30
 BV BND1      arc_0_11_1
 UP BND1      load_0_11_1  30
 BV BND1      arc_0_11_2
 UP BND1      load_0_11_2  30
 BV BND1      arc_0_11_3
 UP BND1      load_0_11_3  30
 BV BND1      arc_0_11_4
 UP BND1      load_0_11_4  30
 BV BND1      arc_0_11_5
 UP BND1      load_0_11_5  30
 BV BND1      arc_0_11_8
 UP BND1      load_0_11_8  30
 BV BND1      arc_0_11_9
 UP BND1      load_0_11_9  30
 BV BND1      arc_0_11_10
 UP BND1      load_0_11_10  30
 BV BND1      arc_0_11_12
 UP BND1      load_0_11_12  30
 BV BND1      arc_0_11_13
 UP BND1      load_0_11_13  30
 BV BND1      arc_0_11_14
 UP BND1      load_0_11_14  30
 BV BND1      arc_0_11_15
 UP BND1      load_0_11_15  30
 BV BND1      arc_0_12_0
 UP BND1      load_0_12_0  30
 BV BND1      arc_0_12_1
 UP BND1      load_0_12_1  30
 BV BND1      arc_0_12_2
 UP BND1      load_0_12_2  30
 BV BND1      arc_0_12_3
 UP BND1      load_0_12_3  30
 BV BND1      arc_0_12_4
 UP BND1      load_0_12_4  30
 BV BND1      arc_0_12_5
 UP BND1      load_0_12_5  30
 BV BND1      arc_0_12_8
 UP BND1      load_0_12_8  30
 BV BND1      arc_0_12_9
 UP BND1      load_0_12_9  30
 BV BND1      arc_0_12_10
 UP BND1      load_0_12_10  30
 BV BND1      arc_0_12_11
 UP BND1      load_0_12_11  30
 BV BND1      arc_0_12_13
 UP BND1      load_0_12_13  30
 BV BND1      arc_0_12_14
 UP BND1      load_0_12_14  30
 BV BND1      arc_0_12_15
 UP BND1      load_0_12_15  30
 BV BND1      arc_0_13_0
 UP BND1      load_0_13_0  30
 BV BND1      arc_0_13_1
 UP BND1      load_0_13_1  30
 BV BND1      arc_0_13_2
 UP BND1      load_0_13_2  30
 BV BND1      arc_0_13_3
 UP BND1      load_0_13_3  30
 BV BND1      arc_0_13_4
 UP BND1      load_0_13_4  30
 BV BND1      arc_0_13_5
 UP BND1      load_0_13_5  30
 BV BND1      arc_0_13_8
 UP BND1      load_0_13_8  30
 BV BND1      arc_0_13_9
 UP BND1      load_0_13_9  30
 BV BND1      arc_0_13_10
 UP BND1      load_0_13_10  30
 BV BND1      arc_0_13_11
 UP BND1      load_0_13_11  30
 BV BND1      arc_0_13_12
 UP BND1      load_0_13_12  30
 BV BND1      arc_0_13_14
 UP BND1      load_0_13_14  30
 BV BND1      arc_0_13_15
 UP BND1      load_0_13_15  30
 BV BND1      arc_0_14_0
 UP BND1      load_0_14_0  30
 BV BND1      arc_0_14_1
 UP BND1      load_0_14_1  30
 BV BND1      arc_0_14_2
 UP BND1      load_0_14_2  30
 BV BND1      arc_0_14_3
 UP BND1      load_0_14_3  30
 BV BND1      arc_0_14_4
 UP BND1      load_0_14_4  30
 BV BND1      arc_0_14_5
 UP BND1      load_0_14_5  30
 BV BND1      arc_0_14_8
 UP BND1      load_0_14_8  30
 BV BND1      arc_0_14_9
 UP BND1      load_0_14_9  30
 BV BND1      arc_0_14_10
 UP BND1      load_0_14_10  30
 BV BND1      arc_0_14_11
 UP BND1      load_0_14_11  30
 BV BND1      arc_0_14_12
 UP BND1      load_0_14_12  30
 BV BND1      arc_0_14_13
 UP BND1      load_0_14_13  30
 BV BND1      arc_0_14_15
 UP BND1      load_0_14_15  30
 BV BND1      arc_0_15_0
 UP BND1      load_0_15_0  30
 BV BND1      arc_0_15_1
 UP BND1      load_0_15_1  30
 BV BND1      arc_0_15_2
 UP BND1      load_0_15_2  30
 BV BND1      arc_0_15_3
 UP BND1      load_0_15_3  30
 BV BND1      arc_0_15_4
 UP BND1      load_0_15_4  30
 BV BND1      arc_0_15_5
 UP BND1      load_0_15_5  30
 BV BND1      arc_0_15_8
 UP BND1      load_0_15_8  30
 BV BND1      arc_0_15_9
 UP BND1      load_0_15_9  30
 BV BND1      arc_0_15_10
 UP BND1      load_0_15_10  30
 BV BND1      arc_0_15_11
 UP BND1      load_0_15_11  30
 BV BND1      arc_0_15_12
 UP BND1      load_0_15_12  30
 BV BND1      arc_0_15_13
 UP BND1      load_0_15_13  30
 BV BND1      arc_0_15_14
 UP BND1      load_0_15_14  30
 FX BND1      visit_1_6  1
 UP BND1      order_1_6  10
 FX BND1      visit_1_7  1
 UP BND1      order_1_7  10
 UP BND1      visit_1_8  1
 UP BND1      order_1_8  10
 UP BND1      visit_1_9  1
 UP BND1      order_1_9  10
 UP BND1      visit_1_10  1
 UP BND1      order_1_10  10
 UP BND1      visit_1_11  1
 UP BND1      order_1_11  10
 UP BND1      visit_1_12  1
 UP BND1      order_1_12  10
 UP BND1      visit_1_13  1
 UP BND1      order_1_13  10
 UP BND1      visit_1_14  1
 UP BND1      order_1_14  10
 UP BND1      visit_1_15  1
 UP BND1      order_1_15  10
 BV BND1      arc_1_0_0
 FX BND1      load_1_0_0  0
 BV BND1      arc_1_0_6
 FX BND1      load_1_0_6  0
 BV BND1      arc_1_0_7
 FX BND1      load_1_0_7  0
 BV BND1      arc_1_0_8
 FX BND1      load_1_0_8  0
 BV BND1      arc_1_0_9
 FX BND1      load_1_0_9  0
 BV BND1      arc_1_0_10
 FX BND1      load_1_0_10  0
 BV BND1      arc_1_0_11
 FX BND1      load_1_0_11  0
 BV BND1      arc_1_0_12
 FX BND1      load_1_0_12  0
 BV BND1      arc_1_0_13
 FX BND1      load_1_0_13  0
 BV BND1      arc_1_0_14
 FX BND1      load_1_0_14  0
 BV BND1      arc_1_0_15
 FX BND1      load_1_0_15  0
 BV BND1      arc_1_6_0
 UP BND1      load_1_6_0  30
 BV BND1      arc_1_6_7
 UP BND1      load_1_6_7  30
 BV BND1      arc_1_6_8
 UP BND1      load_1_6_8  30
 BV BND1      arc_1_6_9
 UP BND1      load_1_6_9  30
 BV BND1      arc_1_6_10
 UP BND1      load_1_6_10  30
 BV BND1      arc_1_6_11
 UP BND1      load_1_6_11  30
 BV BND1      arc_1_6_12
 UP BND1      load_1_6_12  30
 BV BND1      arc_1_6_13
 UP BND1      load_1_6_13  30
 BV BND1      arc_1_6_14
 UP BND1      load_1_6_14  30
 BV BND1      arc_1_6_15
 UP BND1      load_1_6_15  30
 BV BND1      arc_1_7_0
 UP BND1      load_1_7_0  30
 BV BND1      arc_1_7_6
 UP BND1      load_1_7_6  30
 BV BND1      arc_1_7_8
 UP BND1      load_1_7_8  30
 BV BND1      arc_1_7_9
 UP BND1      load_1_7_9  30
 BV BND1      arc_1_7_10
 UP BND1      load_1_7_10  30
 BV BND1      arc_1_7_11
 UP BND1      load_1_7_11  30
 BV BND1      arc_1_7_12
 UP BND1      load_1_7_12  30
 BV BND1      arc_1_7_13
 UP BND1      load_1_7_13  30
 BV BND1      arc_1_7_14
 UP BND1      load_1_7_14  30
 BV BND1      arc_1_7_15
 UP BND1      load_1_7_15  30
 BV BND1      arc_1_8_0
 UP BND1      load_1_8_0  30
 BV BND1      arc_1_8_6
 UP BND1      load_1_8_6  30
 BV BND1      arc_1_8_7
 UP BND1      load_1_8_7  30
 BV BND1      arc_1_8_9
 UP BND1      load_1_8_9  30
 BV BND1      arc_1_8_10
 UP BND1      load_1_8_10  30
 BV BND1      arc_1_8_11
 UP BND1      load_1_8_11  30
 BV BND1      arc_1_8_12
 UP BND1      load_1_8_12  30
 BV BND1      arc_1_8_13
 UP BND1      load_1_8_13  30
 BV BND1      arc_1_8_14
 UP BND1      load_1_8_14  30
 BV BND1      arc_1_8_15
 UP BND1      load_1_8_15  30
 BV BND1      arc_1_9_0
 UP BND1      load_1_9_0  30
 BV BND1      arc_1_9_6
 UP BND1      load_1_9_6  30
 BV BND1      arc_1_9_7
 UP BND1      load_1_9_7  30
 BV BND1      arc_1_9_8
 UP BND1      load_1_9_8  30
 BV BND1      arc_1_9_10
 UP BND1      load_1_9_10  30
 BV BND1      arc_1_9_11
 UP BND1      load_1_9_11  30
 BV BND1      arc_1_9_12
 UP BND1      load_1_9_12  30
 BV BND1      arc_1_9_13
 UP BND1      load_1_9_13  30
 BV BND1      arc_1_9_14
 UP BND1      load_1_9_14  30
 BV BND1      arc_1_9_15
 UP BND1      load_1_9_15  30
 BV BND1      arc_1_10_0
 UP BND1      load_1_10_0  30
 BV BND1      arc_1_10_6
 UP BND1      load_1_10_6  30
 BV BND1      arc_1_10_7
 UP BND1      load_1_10_7  30
 BV BND1      arc_1_10_8
 UP BND1      load_1_10_8  30
 BV BND1      arc_1_10_9
 UP BND1      load_1_10_9  30
 BV BND1      arc_1_10_11
 UP BND1      load_1_10_11  30
 BV BND1      arc_1_10_12
 UP BND1      load_1_10_12  30
 BV BND1      arc_1_10_13
 UP BND1      load_1_10_13  30
 BV BND1      arc_1_10_14
 UP BND1      load_1_10_14  30
 BV BND1      arc_1_10_15
 UP BND1      load_1_10_15  30
 BV BND1      arc_1_11_0
 UP BND1      load_1_11_0  30
 BV BND1      arc_1_11_6
 UP BND1      load_1_11_6  30
 BV BND1      arc_1_11_7
 UP BND1      load_1_11_7  30
 BV BND1      arc_1_11_8
 UP BND1      load_1_11_8  30
 BV BND1      arc_1_11_9
 UP BND1      load_1_11_9  30
 BV BND1      arc_1_11_10
 UP BND1      load_1_11_10  30
 BV BND1      arc_1_11_12
 UP BND1      load_1_11_12  30
 BV BND1      arc_1_11_13
 UP BND1      load_1_11_13  30
 BV BND1      arc_1_11_14
 UP BND1      load_1_11_14  30
 BV BND1      arc_1_11_15
 UP BND1      load_1_11_15  30
 BV BND1      arc_1_12_0
 UP BND1      load_1_12_0  30
 BV BND1      arc_1_12_6
 UP BND1      load_1_12_6  30
 BV BND1      arc_1_12_7
 UP BND1      load_1_12_7  30
 BV BND1      arc_1_12_8
 UP BND1      load_1_12_8  30
 BV BND1      arc_1_12_9
 UP BND1      load_1_12_9  30
 BV BND1      arc_1_12_10
 UP BND1      load_1_12_10  30
 BV BND1      arc_1_12_11
 UP BND1      load_1_12_11  30
 BV BND1      arc_1_12_13
 UP BND1      load_1_12_13  30
 BV BND1      arc_1_12_14
 UP BND1      load_1_12_14  30
 BV BND1      arc_1_12_15
 UP BND1      load_1_12_15  30
 BV BND1      arc_1_13_0
 UP BND1      load_1_13_0  30
 BV BND1      arc_1_13_6
 UP BND1      load_1_13_6  30
 BV BND1      arc_1_13_7
 UP BND1      load_1_13_7  30
 BV BND1      arc_1_13_8
 UP BND1      load_1_13_8  30
 BV BND1      arc_1_13_9
 UP BND1      load_1_13_9  30
 BV BND1      arc_1_13_10
 UP BND1      load_1_13_10  30
 BV BND1      arc_1_13_11
 UP BND1      load_1_13_11  30
 BV BND1      arc_1_13_12
 UP BND1      load_1_13_12  30
 BV BND1      arc_1_13_14
 UP BND1      load_1_13_14  30
 BV BND1      arc_1_13_15
 UP BND1      load_1_13_15  30
 BV BND1      arc_1_14_0
 UP BND1      load_1_14_0  30
 BV BND1      arc_1_14_6
 UP BND1      load_1_14_6  30
 BV BND1      arc_1_14_7
 UP BND1      load_1_14_7  30
 BV BND1      arc_1_14_8
 UP BND1      load_1_14_8  30
 BV BND1      arc_1_14_9
 UP BND1      load_1_14_9  30
 BV BND1      arc_1_14_10
 UP BND1      load_1_14_10  30
 BV BND1      arc_1_14_11
 UP BND1      load_1_14_11  30
 BV BND1      arc_1_14_12
 UP BND1      load_1_14_12  30
 BV BND1      arc_1_14_13
 UP BND1      load_1_14_13  30
 BV BND1      arc_1_14_15
 UP BND1      load_1_14_15  30
 BV BND1      arc_1_15_0
 UP BND1      load_1_15_0  30
 BV BND1      arc_1_15_6
 UP BND1      load_1_15_6  30
 BV BND1      arc_1_15_7
 UP BND1      load_1_15_7  30
 BV BND1      arc_1_15_8
 UP BND1      load_1_15_8  30
 BV BND1      arc_1_15_9
 UP BND1      load_1_15_9  30
 BV BND1      arc_1_15_10
 UP BND1      load_1_15_10  30
 BV BND1      arc_1_15_11
 UP BND1      load_1_15_11  30
 BV BND1      arc_1_15_12
 UP BND1      load_1_15_12  30
 BV BND1      arc_1_15_13
 UP BND1      load_1_15_13  30
 BV BND1      arc_1_15_14
 UP BND1      load_1_15_14  30
ENDATA
