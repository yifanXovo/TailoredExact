* Signature: 0x4e9d8392c3ded16a
NAME R160_physical_neighborhood
ROWS
 N  OBJ
 G  product_lb_0
 L  product_ub_1
 G  product_lb_2
 L  product_ub_3
 G  product_lb_4
 L  product_ub_5
 G  product_lb_6
 L  product_ub_7
 G  product_lb_8
 L  product_ub_9
 G  product_lb_10
 L  product_ub_11
 G  product_lb_12
 L  product_ub_13
 G  product_lb_14
 L  product_ub_15
 G  product_lb_16
 L  product_ub_17
 G  product_lb_18
 L  product_ub_19
 G  product_lb_20
 L  product_ub_21
 G  product_lb_22
 L  product_ub_23
 G  product_lb_24
 L  product_ub_25
 G  product_lb_26
 L  product_ub_27
 G  product_lb_28
 L  product_ub_29
 G  product_lb_30
 L  product_ub_31
 E  onehot_22_32
 E  normalized_mass_22_33
 E  normalized_ratio_22_34
 G  product_lb_35
 L  product_ub_36
 G  product_lb_37
 L  product_ub_38
 G  product_lb_39
 L  product_ub_40
 G  product_lb_41
 L  product_ub_42
 G  product_lb_43
 L  product_ub_44
 G  product_lb_45
 L  product_ub_46
 G  product_lb_47
 L  product_ub_48
 G  product_lb_49
 L  product_ub_50
 G  product_lb_51
 L  product_ub_52
 E  onehot_26_53
 E  normalized_mass_26_54
 E  normalized_ratio_26_55
 G  product_lb_56
 L  product_ub_57
 G  product_lb_58
 L  product_ub_59
 G  product_lb_60
 L  product_ub_61
 G  product_lb_62
 L  product_ub_63
 G  product_lb_64
 L  product_ub_65
 G  product_lb_66
 L  product_ub_67
 G  product_lb_68
 L  product_ub_69
 G  product_lb_70
 L  product_ub_71
 G  product_lb_72
 L  product_ub_73
 G  product_lb_74
 L  product_ub_75
 G  product_lb_76
 L  product_ub_77
 G  product_lb_78
 L  product_ub_79
 G  product_lb_80
 L  product_ub_81
 G  product_lb_82
 L  product_ub_83
 G  product_lb_84
 L  product_ub_85
 G  product_lb_86
 L  product_ub_87
 E  onehot_34_88
 E  normalized_mass_34_89
 E  normalized_ratio_34_90
 G  product_lb_91
 L  product_ub_92
 G  product_lb_93
 L  product_ub_94
 G  product_lb_95
 L  product_ub_96
 G  product_lb_97
 L  product_ub_98
 E  onehot_23_99
 E  normalized_mass_23_100
 E  normalized_ratio_23_101
 G  product_lb_102
 L  product_ub_103
 G  product_lb_104
 L  product_ub_105
 G  product_lb_106
 L  product_ub_107
 G  product_lb_108
 L  product_ub_109
 G  product_lb_110
 L  product_ub_111
 G  product_lb_112
 L  product_ub_113
 G  product_lb_114
 L  product_ub_115
 E  onehot_27_116
 E  normalized_mass_27_117
 E  normalized_ratio_27_118
 G  product_lb_119
 L  product_ub_120
 G  product_lb_121
 L  product_ub_122
 G  product_lb_123
 L  product_ub_124
 G  product_lb_125
 L  product_ub_126
 G  product_lb_127
 L  product_ub_128
 G  product_lb_129
 L  product_ub_130
 G  product_lb_131
 L  product_ub_132
 E  onehot_21_133
 E  normalized_mass_21_134
 E  normalized_ratio_21_135
 G  product_lb_136
 L  product_ub_137
 G  product_lb_138
 L  product_ub_139
 G  product_lb_140
 L  product_ub_141
 G  product_lb_142
 L  product_ub_143
 G  product_lb_144
 L  product_ub_145
 E  onehot_25_146
 E  normalized_mass_25_147
 E  normalized_ratio_25_148
 G  product_lb_149
 L  product_ub_150
 G  product_lb_151
 L  product_ub_152
 G  product_lb_153
 L  product_ub_154
 G  product_lb_155
 L  product_ub_156
 G  product_lb_157
 L  product_ub_158
 G  product_lb_159
 L  product_ub_160
 G  product_lb_161
 L  product_ub_162
 E  onehot_28_163
 E  normalized_mass_28_164
 E  normalized_ratio_28_165
 G  stock_lb_166
 L  stock_ub_167
 L  parent_nonstrict_scope_168
 G  block_pair_pos_169
 G  block_pair_neg_170
 G  block_pair_pos_171
 G  block_pair_neg_172
 G  block_pair_pos_173
 G  block_pair_neg_174
 G  block_pair_pos_175
 G  block_pair_neg_176
 G  block_pair_pos_177
 G  block_pair_neg_178
 G  block_pair_pos_179
 G  block_pair_neg_180
 G  block_pair_pos_181
 G  block_pair_neg_182
 G  block_pair_pos_183
 G  block_pair_neg_184
 G  block_pair_pos_185
 G  block_pair_neg_186
 G  block_pair_pos_187
 G  block_pair_neg_188
 G  block_pair_pos_189
 G  block_pair_neg_190
 G  block_pair_pos_191
 G  block_pair_neg_192
 G  block_pair_pos_193
 G  block_pair_neg_194
 G  block_pair_pos_195
 G  block_pair_neg_196
 G  block_pair_pos_197
 G  block_pair_neg_198
 G  block_pair_pos_199
 G  block_pair_neg_200
 G  block_pair_pos_201
 G  block_pair_neg_202
 G  block_pair_pos_203
 G  block_pair_neg_204
 G  block_pair_pos_205
 G  block_pair_neg_206
 G  block_pair_pos_207
 G  block_pair_neg_208
 G  block_pair_pos_209
 G  block_pair_neg_210
 G  block_pair_pos_211
 G  block_pair_neg_212
 G  block_pair_pos_213
 G  block_pair_neg_214
 G  block_pair_pos_215
 G  block_pair_neg_216
 G  block_pair_pos_217
 G  block_pair_neg_218
 G  block_pair_pos_219
 G  block_pair_neg_220
 G  block_pair_pos_221
 G  block_pair_neg_222
 G  block_pair_pos_223
 G  block_pair_neg_224
 E  normalization_225
 G  full_original_Gini_226
 E  unique_nonzero_owner_227
 E  unique_nonzero_owner_228
 E  unique_nonzero_owner_229
 E  unique_nonzero_owner_230
 E  unique_nonzero_owner_231
 E  unique_nonzero_owner_232
 E  unique_nonzero_owner_233
 E  unique_nonzero_owner_234
 E  unique_nonzero_owner_235
 E  unique_nonzero_owner_236
 E  unique_nonzero_owner_237
 E  unique_nonzero_owner_238
 E  unique_nonzero_owner_239
 E  unique_nonzero_owner_240
 E  unique_nonzero_owner_241
 E  unique_nonzero_owner_242
 E  unique_nonzero_owner_243
 E  unique_nonzero_owner_244
 E  unique_nonzero_owner_245
 E  unique_nonzero_owner_246
 E  unique_nonzero_owner_247
 E  unique_nonzero_owner_248
 E  unique_nonzero_owner_249
 E  unique_nonzero_owner_250
 E  unique_nonzero_owner_251
 E  unique_nonzero_owner_252
 E  unique_nonzero_owner_253
 E  unique_nonzero_owner_254
 E  unique_nonzero_owner_255
 E  unique_nonzero_owner_256
 E  unique_nonzero_owner_257
 E  unique_nonzero_owner_258
 E  unique_nonzero_owner_259
 E  unique_nonzero_owner_260
 E  unique_nonzero_owner_261
 E  unique_nonzero_owner_262
 E  unique_nonzero_owner_263
 E  unique_nonzero_owner_264
 E  unique_nonzero_owner_265
 E  unique_nonzero_owner_266
 E  unique_nonzero_owner_267
 E  unique_nonzero_owner_268
 E  unique_nonzero_owner_269
 E  unique_nonzero_owner_270
 E  unique_nonzero_owner_271
 E  unique_nonzero_owner_272
 E  unique_nonzero_owner_273
 E  unique_nonzero_owner_274
 E  unique_nonzero_owner_275
 E  unique_nonzero_owner_276
 E  unique_nonzero_owner_277
 E  unique_nonzero_owner_278
 E  unique_nonzero_owner_279
 E  unique_nonzero_owner_280
 E  unique_nonzero_owner_281
 E  unique_nonzero_owner_282
 E  unique_nonzero_owner_283
 E  unique_nonzero_owner_284
 E  unique_nonzero_owner_285
 E  unique_nonzero_owner_286
 E  unique_nonzero_owner_287
 E  unique_nonzero_owner_288
 E  unique_nonzero_owner_289
 L  arc_capacity_290
 L  arc_capacity_291
 L  arc_capacity_292
 L  arc_capacity_293
 L  arc_capacity_294
 L  arc_capacity_295
 L  arc_capacity_296
 L  arc_capacity_297
 L  arc_capacity_298
 L  arc_capacity_299
 L  arc_capacity_300
 L  arc_capacity_301
 L  arc_capacity_302
 L  arc_capacity_303
 L  arc_capacity_304
 G  connected_order_arc_305
 L  arc_capacity_306
 G  connected_order_arc_307
 L  arc_capacity_308
 G  connected_order_arc_309
 L  arc_capacity_310
 G  connected_order_arc_311
 L  arc_capacity_312
 G  connected_order_arc_313
 L  arc_capacity_314
 G  connected_order_arc_315
 L  arc_capacity_316
 G  connected_order_arc_317
 L  arc_capacity_318
 G  connected_order_arc_319
 L  arc_capacity_320
 G  connected_order_arc_321
 L  arc_capacity_322
 G  connected_order_arc_323
 L  arc_capacity_324
 G  connected_order_arc_325
 L  arc_capacity_326
 L  arc_capacity_327
 G  connected_order_arc_328
 L  arc_capacity_329
 G  connected_order_arc_330
 L  arc_capacity_331
 G  connected_order_arc_332
 L  arc_capacity_333
 G  connected_order_arc_334
 L  arc_capacity_335
 G  connected_order_arc_336
 L  arc_capacity_337
 G  connected_order_arc_338
 L  arc_capacity_339
 G  connected_order_arc_340
 L  arc_capacity_341
 G  connected_order_arc_342
 L  arc_capacity_343
 G  connected_order_arc_344
 L  arc_capacity_345
 G  connected_order_arc_346
 L  arc_capacity_347
 G  connected_order_arc_348
 L  arc_capacity_349
 L  arc_capacity_350
 G  connected_order_arc_351
 L  arc_capacity_352
 G  connected_order_arc_353
 L  arc_capacity_354
 G  connected_order_arc_355
 L  arc_capacity_356
 G  connected_order_arc_357
 L  arc_capacity_358
 G  connected_order_arc_359
 L  arc_capacity_360
 G  connected_order_arc_361
 L  arc_capacity_362
 G  connected_order_arc_363
 L  arc_capacity_364
 G  connected_order_arc_365
 L  arc_capacity_366
 G  connected_order_arc_367
 L  arc_capacity_368
 G  connected_order_arc_369
 L  arc_capacity_370
 G  connected_order_arc_371
 L  arc_capacity_372
 L  arc_capacity_373
 G  connected_order_arc_374
 L  arc_capacity_375
 G  connected_order_arc_376
 L  arc_capacity_377
 G  connected_order_arc_378
 L  arc_capacity_379
 G  connected_order_arc_380
 L  arc_capacity_381
 G  connected_order_arc_382
 L  arc_capacity_383
 G  connected_order_arc_384
 L  arc_capacity_385
 G  connected_order_arc_386
 L  arc_capacity_387
 G  connected_order_arc_388
 L  arc_capacity_389
 G  connected_order_arc_390
 L  arc_capacity_391
 G  connected_order_arc_392
 L  arc_capacity_393
 G  connected_order_arc_394
 L  arc_capacity_395
 L  arc_capacity_396
 G  connected_order_arc_397
 L  arc_capacity_398
 G  connected_order_arc_399
 L  arc_capacity_400
 G  connected_order_arc_401
 L  arc_capacity_402
 G  connected_order_arc_403
 L  arc_capacity_404
 G  connected_order_arc_405
 L  arc_capacity_406
 G  connected_order_arc_407
 L  arc_capacity_408
 G  connected_order_arc_409
 L  arc_capacity_410
 G  connected_order_arc_411
 L  arc_capacity_412
 G  connected_order_arc_413
 L  arc_capacity_414
 G  connected_order_arc_415
 L  arc_capacity_416
 G  connected_order_arc_417
 L  arc_capacity_418
 L  arc_capacity_419
 G  connected_order_arc_420
 L  arc_capacity_421
 G  connected_order_arc_422
 L  arc_capacity_423
 G  connected_order_arc_424
 L  arc_capacity_425
 G  connected_order_arc_426
 L  arc_capacity_427
 G  connected_order_arc_428
 L  arc_capacity_429
 G  connected_order_arc_430
 L  arc_capacity_431
 G  connected_order_arc_432
 L  arc_capacity_433
 G  connected_order_arc_434
 L  arc_capacity_435
 G  connected_order_arc_436
 L  arc_capacity_437
 G  connected_order_arc_438
 L  arc_capacity_439
 G  connected_order_arc_440
 L  arc_capacity_441
 L  arc_capacity_442
 G  connected_order_arc_443
 L  arc_capacity_444
 G  connected_order_arc_445
 L  arc_capacity_446
 G  connected_order_arc_447
 L  arc_capacity_448
 G  connected_order_arc_449
 L  arc_capacity_450
 G  connected_order_arc_451
 L  arc_capacity_452
 G  connected_order_arc_453
 L  arc_capacity_454
 G  connected_order_arc_455
 L  arc_capacity_456
 G  connected_order_arc_457
 L  arc_capacity_458
 G  connected_order_arc_459
 L  arc_capacity_460
 G  connected_order_arc_461
 L  arc_capacity_462
 G  connected_order_arc_463
 L  arc_capacity_464
 L  arc_capacity_465
 G  connected_order_arc_466
 L  arc_capacity_467
 G  connected_order_arc_468
 L  arc_capacity_469
 G  connected_order_arc_470
 L  arc_capacity_471
 G  connected_order_arc_472
 L  arc_capacity_473
 G  connected_order_arc_474
 L  arc_capacity_475
 G  connected_order_arc_476
 L  arc_capacity_477
 G  connected_order_arc_478
 L  arc_capacity_479
 G  connected_order_arc_480
 L  arc_capacity_481
 G  connected_order_arc_482
 L  arc_capacity_483
 G  connected_order_arc_484
 L  arc_capacity_485
 G  connected_order_arc_486
 L  arc_capacity_487
 L  arc_capacity_488
 G  connected_order_arc_489
 L  arc_capacity_490
 G  connected_order_arc_491
 L  arc_capacity_492
 G  connected_order_arc_493
 L  arc_capacity_494
 G  connected_order_arc_495
 L  arc_capacity_496
 G  connected_order_arc_497
 L  arc_capacity_498
 G  connected_order_arc_499
 L  arc_capacity_500
 G  connected_order_arc_501
 L  arc_capacity_502
 G  connected_order_arc_503
 L  arc_capacity_504
 G  connected_order_arc_505
 L  arc_capacity_506
 G  connected_order_arc_507
 L  arc_capacity_508
 G  connected_order_arc_509
 L  arc_capacity_510
 L  arc_capacity_511
 G  connected_order_arc_512
 L  arc_capacity_513
 G  connected_order_arc_514
 L  arc_capacity_515
 G  connected_order_arc_516
 L  arc_capacity_517
 G  connected_order_arc_518
 L  arc_capacity_519
 G  connected_order_arc_520
 L  arc_capacity_521
 G  connected_order_arc_522
 L  arc_capacity_523
 G  connected_order_arc_524
 L  arc_capacity_525
 G  connected_order_arc_526
 L  arc_capacity_527
 G  connected_order_arc_528
 L  arc_capacity_529
 G  connected_order_arc_530
 L  arc_capacity_531
 G  connected_order_arc_532
 L  arc_capacity_533
 L  arc_capacity_534
 G  connected_order_arc_535
 L  arc_capacity_536
 G  connected_order_arc_537
 L  arc_capacity_538
 G  connected_order_arc_539
 L  arc_capacity_540
 G  connected_order_arc_541
 L  arc_capacity_542
 G  connected_order_arc_543
 L  arc_capacity_544
 G  connected_order_arc_545
 L  arc_capacity_546
 G  connected_order_arc_547
 L  arc_capacity_548
 G  connected_order_arc_549
 L  arc_capacity_550
 G  connected_order_arc_551
 L  arc_capacity_552
 G  connected_order_arc_553
 L  arc_capacity_554
 G  connected_order_arc_555
 L  arc_capacity_556
 L  arc_capacity_557
 G  connected_order_arc_558
 L  arc_capacity_559
 G  connected_order_arc_560
 L  arc_capacity_561
 G  connected_order_arc_562
 L  arc_capacity_563
 G  connected_order_arc_564
 L  arc_capacity_565
 G  connected_order_arc_566
 L  arc_capacity_567
 G  connected_order_arc_568
 L  arc_capacity_569
 G  connected_order_arc_570
 L  arc_capacity_571
 G  connected_order_arc_572
 L  arc_capacity_573
 G  connected_order_arc_574
 L  arc_capacity_575
 G  connected_order_arc_576
 L  arc_capacity_577
 G  connected_order_arc_578
 E  depot_departure_or_bypass_579
 E  depot_return_or_bypass_580
 E  out_degree_581
 E  in_degree_582
 G  order_active_lb_583
 L  order_active_ub_584
 E  segment_load_conservation_585
 G  segment_prefix_lb_586
 L  segment_prefix_ub_587
 E  out_degree_588
 E  in_degree_589
 G  order_active_lb_590
 L  order_active_ub_591
 E  segment_load_conservation_592
 G  segment_prefix_lb_593
 L  segment_prefix_ub_594
 E  out_degree_595
 E  in_degree_596
 G  order_active_lb_597
 L  order_active_ub_598
 E  segment_load_conservation_599
 G  segment_prefix_lb_600
 L  segment_prefix_ub_601
 E  out_degree_602
 E  in_degree_603
 G  order_active_lb_604
 L  order_active_ub_605
 E  segment_load_conservation_606
 G  segment_prefix_lb_607
 L  segment_prefix_ub_608
 E  out_degree_609
 E  in_degree_610
 G  order_active_lb_611
 L  order_active_ub_612
 E  service_visit_def_613
 E  free_load_conservation_614
 E  out_degree_615
 E  in_degree_616
 G  order_active_lb_617
 L  order_active_ub_618
 E  service_visit_def_619
 E  free_load_conservation_620
 E  out_degree_621
 E  in_degree_622
 G  order_active_lb_623
 L  order_active_ub_624
 E  service_visit_def_625
 E  free_load_conservation_626
 E  out_degree_627
 E  in_degree_628
 G  order_active_lb_629
 L  order_active_ub_630
 E  service_visit_def_631
 E  free_load_conservation_632
 E  out_degree_633
 E  in_degree_634
 G  order_active_lb_635
 L  order_active_ub_636
 E  service_visit_def_637
 E  free_load_conservation_638
 E  out_degree_639
 E  in_degree_640
 G  order_active_lb_641
 L  order_active_ub_642
 E  service_visit_def_643
 E  free_load_conservation_644
 E  out_degree_645
 E  in_degree_646
 G  order_active_lb_647
 L  order_active_ub_648
 E  service_visit_def_649
 E  free_load_conservation_650
 E  out_degree_651
 E  in_degree_652
 G  order_active_lb_653
 L  order_active_ub_654
 E  service_visit_def_655
 E  free_load_conservation_656
 G  fixed_segment_relative_order_657
 G  fixed_segment_relative_order_658
 G  fixed_segment_relative_order_659
 L  original_T_including_depot_unload_660
 L  arc_capacity_661
 L  arc_capacity_662
 L  arc_capacity_663
 L  arc_capacity_664
 L  arc_capacity_665
 L  arc_capacity_666
 L  arc_capacity_667
 L  arc_capacity_668
 L  arc_capacity_669
 L  arc_capacity_670
 L  arc_capacity_671
 L  arc_capacity_672
 L  arc_capacity_673
 L  arc_capacity_674
 L  arc_capacity_675
 G  connected_order_arc_676
 L  arc_capacity_677
 G  connected_order_arc_678
 L  arc_capacity_679
 G  connected_order_arc_680
 L  arc_capacity_681
 G  connected_order_arc_682
 L  arc_capacity_683
 G  connected_order_arc_684
 L  arc_capacity_685
 G  connected_order_arc_686
 L  arc_capacity_687
 G  connected_order_arc_688
 L  arc_capacity_689
 G  connected_order_arc_690
 L  arc_capacity_691
 G  connected_order_arc_692
 L  arc_capacity_693
 G  connected_order_arc_694
 L  arc_capacity_695
 G  connected_order_arc_696
 L  arc_capacity_697
 L  arc_capacity_698
 G  connected_order_arc_699
 L  arc_capacity_700
 G  connected_order_arc_701
 L  arc_capacity_702
 G  connected_order_arc_703
 L  arc_capacity_704
 G  connected_order_arc_705
 L  arc_capacity_706
 G  connected_order_arc_707
 L  arc_capacity_708
 G  connected_order_arc_709
 L  arc_capacity_710
 G  connected_order_arc_711
 L  arc_capacity_712
 G  connected_order_arc_713
 L  arc_capacity_714
 G  connected_order_arc_715
 L  arc_capacity_716
 G  connected_order_arc_717
 L  arc_capacity_718
 G  connected_order_arc_719
 L  arc_capacity_720
 L  arc_capacity_721
 G  connected_order_arc_722
 L  arc_capacity_723
 G  connected_order_arc_724
 L  arc_capacity_725
 G  connected_order_arc_726
 L  arc_capacity_727
 G  connected_order_arc_728
 L  arc_capacity_729
 G  connected_order_arc_730
 L  arc_capacity_731
 G  connected_order_arc_732
 L  arc_capacity_733
 G  connected_order_arc_734
 L  arc_capacity_735
 G  connected_order_arc_736
 L  arc_capacity_737
 G  connected_order_arc_738
 L  arc_capacity_739
 G  connected_order_arc_740
 L  arc_capacity_741
 G  connected_order_arc_742
 L  arc_capacity_743
 L  arc_capacity_744
 G  connected_order_arc_745
 L  arc_capacity_746
 G  connected_order_arc_747
 L  arc_capacity_748
 G  connected_order_arc_749
 L  arc_capacity_750
 G  connected_order_arc_751
 L  arc_capacity_752
 G  connected_order_arc_753
 L  arc_capacity_754
 G  connected_order_arc_755
 L  arc_capacity_756
 G  connected_order_arc_757
 L  arc_capacity_758
 G  connected_order_arc_759
 L  arc_capacity_760
 G  connected_order_arc_761
 L  arc_capacity_762
 G  connected_order_arc_763
 L  arc_capacity_764
 G  connected_order_arc_765
 L  arc_capacity_766
 L  arc_capacity_767
 G  connected_order_arc_768
 L  arc_capacity_769
 G  connected_order_arc_770
 L  arc_capacity_771
 G  connected_order_arc_772
 L  arc_capacity_773
 G  connected_order_arc_774
 L  arc_capacity_775
 G  connected_order_arc_776
 L  arc_capacity_777
 G  connected_order_arc_778
 L  arc_capacity_779
 G  connected_order_arc_780
 L  arc_capacity_781
 G  connected_order_arc_782
 L  arc_capacity_783
 G  connected_order_arc_784
 L  arc_capacity_785
 G  connected_order_arc_786
 L  arc_capacity_787
 G  connected_order_arc_788
 L  arc_capacity_789
 L  arc_capacity_790
 G  connected_order_arc_791
 L  arc_capacity_792
 G  connected_order_arc_793
 L  arc_capacity_794
 G  connected_order_arc_795
 L  arc_capacity_796
 G  connected_order_arc_797
 L  arc_capacity_798
 G  connected_order_arc_799
 L  arc_capacity_800
 G  connected_order_arc_801
 L  arc_capacity_802
 G  connected_order_arc_803
 L  arc_capacity_804
 G  connected_order_arc_805
 L  arc_capacity_806
 G  connected_order_arc_807
 L  arc_capacity_808
 G  connected_order_arc_809
 L  arc_capacity_810
 G  connected_order_arc_811
 L  arc_capacity_812
 L  arc_capacity_813
 G  connected_order_arc_814
 L  arc_capacity_815
 G  connected_order_arc_816
 L  arc_capacity_817
 G  connected_order_arc_818
 L  arc_capacity_819
 G  connected_order_arc_820
 L  arc_capacity_821
 G  connected_order_arc_822
 L  arc_capacity_823
 G  connected_order_arc_824
 L  arc_capacity_825
 G  connected_order_arc_826
 L  arc_capacity_827
 G  connected_order_arc_828
 L  arc_capacity_829
 G  connected_order_arc_830
 L  arc_capacity_831
 G  connected_order_arc_832
 L  arc_capacity_833
 G  connected_order_arc_834
 L  arc_capacity_835
 L  arc_capacity_836
 G  connected_order_arc_837
 L  arc_capacity_838
 G  connected_order_arc_839
 L  arc_capacity_840
 G  connected_order_arc_841
 L  arc_capacity_842
 G  connected_order_arc_843
 L  arc_capacity_844
 G  connected_order_arc_845
 L  arc_capacity_846
 G  connected_order_arc_847
 L  arc_capacity_848
 G  connected_order_arc_849
 L  arc_capacity_850
 G  connected_order_arc_851
 L  arc_capacity_852
 G  connected_order_arc_853
 L  arc_capacity_854
 G  connected_order_arc_855
 L  arc_capacity_856
 G  connected_order_arc_857
 L  arc_capacity_858
 L  arc_capacity_859
 G  connected_order_arc_860
 L  arc_capacity_861
 G  connected_order_arc_862
 L  arc_capacity_863
 G  connected_order_arc_864
 L  arc_capacity_865
 G  connected_order_arc_866
 L  arc_capacity_867
 G  connected_order_arc_868
 L  arc_capacity_869
 G  connected_order_arc_870
 L  arc_capacity_871
 G  connected_order_arc_872
 L  arc_capacity_873
 G  connected_order_arc_874
 L  arc_capacity_875
 G  connected_order_arc_876
 L  arc_capacity_877
 G  connected_order_arc_878
 L  arc_capacity_879
 G  connected_order_arc_880
 L  arc_capacity_881
 L  arc_capacity_882
 G  connected_order_arc_883
 L  arc_capacity_884
 G  connected_order_arc_885
 L  arc_capacity_886
 G  connected_order_arc_887
 L  arc_capacity_888
 G  connected_order_arc_889
 L  arc_capacity_890
 G  connected_order_arc_891
 L  arc_capacity_892
 G  connected_order_arc_893
 L  arc_capacity_894
 G  connected_order_arc_895
 L  arc_capacity_896
 G  connected_order_arc_897
 L  arc_capacity_898
 G  connected_order_arc_899
 L  arc_capacity_900
 G  connected_order_arc_901
 L  arc_capacity_902
 G  connected_order_arc_903
 L  arc_capacity_904
 L  arc_capacity_905
 G  connected_order_arc_906
 L  arc_capacity_907
 G  connected_order_arc_908
 L  arc_capacity_909
 G  connected_order_arc_910
 L  arc_capacity_911
 G  connected_order_arc_912
 L  arc_capacity_913
 G  connected_order_arc_914
 L  arc_capacity_915
 G  connected_order_arc_916
 L  arc_capacity_917
 G  connected_order_arc_918
 L  arc_capacity_919
 G  connected_order_arc_920
 L  arc_capacity_921
 G  connected_order_arc_922
 L  arc_capacity_923
 G  connected_order_arc_924
 L  arc_capacity_925
 G  connected_order_arc_926
 L  arc_capacity_927
 L  arc_capacity_928
 G  connected_order_arc_929
 L  arc_capacity_930
 G  connected_order_arc_931
 L  arc_capacity_932
 G  connected_order_arc_933
 L  arc_capacity_934
 G  connected_order_arc_935
 L  arc_capacity_936
 G  connected_order_arc_937
 L  arc_capacity_938
 G  connected_order_arc_939
 L  arc_capacity_940
 G  connected_order_arc_941
 L  arc_capacity_942
 G  connected_order_arc_943
 L  arc_capacity_944
 G  connected_order_arc_945
 L  arc_capacity_946
 G  connected_order_arc_947
 L  arc_capacity_948
 G  connected_order_arc_949
 E  depot_departure_or_bypass_950
 E  depot_return_or_bypass_951
 E  out_degree_952
 E  in_degree_953
 G  order_active_lb_954
 L  order_active_ub_955
 E  segment_load_conservation_956
 G  segment_prefix_lb_957
 L  segment_prefix_ub_958
 E  out_degree_959
 E  in_degree_960
 G  order_active_lb_961
 L  order_active_ub_962
 E  segment_load_conservation_963
 G  segment_prefix_lb_964
 L  segment_prefix_ub_965
 E  out_degree_966
 E  in_degree_967
 G  order_active_lb_968
 L  order_active_ub_969
 E  segment_load_conservation_970
 G  segment_prefix_lb_971
 L  segment_prefix_ub_972
 E  out_degree_973
 E  in_degree_974
 G  order_active_lb_975
 L  order_active_ub_976
 E  segment_load_conservation_977
 G  segment_prefix_lb_978
 L  segment_prefix_ub_979
 E  out_degree_980
 E  in_degree_981
 G  order_active_lb_982
 L  order_active_ub_983
 E  service_visit_def_984
 E  free_load_conservation_985
 E  out_degree_986
 E  in_degree_987
 G  order_active_lb_988
 L  order_active_ub_989
 E  service_visit_def_990
 E  free_load_conservation_991
 E  out_degree_992
 E  in_degree_993
 G  order_active_lb_994
 L  order_active_ub_995
 E  service_visit_def_996
 E  free_load_conservation_997
 E  out_degree_998
 E  in_degree_999
 G  order_active_lb_1000
 L  order_active_ub_1001
 E  service_visit_def_1002
 E  free_load_conservation_1003
 E  out_degree_1004
 E  in_degree_1005
 G  order_active_lb_1006
 L  order_active_ub_1007
 E  service_visit_def_1008
 E  free_load_conservation_1009
 E  out_degree_1010
 E  in_degree_1011
 G  order_active_lb_1012
 L  order_active_ub_1013
 E  service_visit_def_1014
 E  free_load_conservation_1015
 E  out_degree_1016
 E  in_degree_1017
 G  order_active_lb_1018
 L  order_active_ub_1019
 E  service_visit_def_1020
 E  free_load_conservation_1021
 E  out_degree_1022
 E  in_degree_1023
 G  order_active_lb_1024
 L  order_active_ub_1025
 E  service_visit_def_1026
 E  free_load_conservation_1027
 G  fixed_segment_relative_order_1028
 G  fixed_segment_relative_order_1029
 G  fixed_segment_relative_order_1030
 L  original_T_including_depot_unload_1031
 L  arc_capacity_1032
 L  arc_capacity_1033
 L  arc_capacity_1034
 L  arc_capacity_1035
 L  arc_capacity_1036
 L  arc_capacity_1037
 L  arc_capacity_1038
 L  arc_capacity_1039
 L  arc_capacity_1040
 L  arc_capacity_1041
 L  arc_capacity_1042
 L  arc_capacity_1043
 L  arc_capacity_1044
 L  arc_capacity_1045
 G  connected_order_arc_1046
 L  arc_capacity_1047
 G  connected_order_arc_1048
 L  arc_capacity_1049
 G  connected_order_arc_1050
 L  arc_capacity_1051
 G  connected_order_arc_1052
 L  arc_capacity_1053
 G  connected_order_arc_1054
 L  arc_capacity_1055
 G  connected_order_arc_1056
 L  arc_capacity_1057
 G  connected_order_arc_1058
 L  arc_capacity_1059
 G  connected_order_arc_1060
 L  arc_capacity_1061
 G  connected_order_arc_1062
 L  arc_capacity_1063
 G  connected_order_arc_1064
 L  arc_capacity_1065
 L  arc_capacity_1066
 G  connected_order_arc_1067
 L  arc_capacity_1068
 G  connected_order_arc_1069
 L  arc_capacity_1070
 G  connected_order_arc_1071
 L  arc_capacity_1072
 G  connected_order_arc_1073
 L  arc_capacity_1074
 G  connected_order_arc_1075
 L  arc_capacity_1076
 G  connected_order_arc_1077
 L  arc_capacity_1078
 G  connected_order_arc_1079
 L  arc_capacity_1080
 G  connected_order_arc_1081
 L  arc_capacity_1082
 G  connected_order_arc_1083
 L  arc_capacity_1084
 G  connected_order_arc_1085
 L  arc_capacity_1086
 L  arc_capacity_1087
 G  connected_order_arc_1088
 L  arc_capacity_1089
 G  connected_order_arc_1090
 L  arc_capacity_1091
 G  connected_order_arc_1092
 L  arc_capacity_1093
 G  connected_order_arc_1094
 L  arc_capacity_1095
 G  connected_order_arc_1096
 L  arc_capacity_1097
 G  connected_order_arc_1098
 L  arc_capacity_1099
 G  connected_order_arc_1100
 L  arc_capacity_1101
 G  connected_order_arc_1102
 L  arc_capacity_1103
 G  connected_order_arc_1104
 L  arc_capacity_1105
 G  connected_order_arc_1106
 L  arc_capacity_1107
 L  arc_capacity_1108
 G  connected_order_arc_1109
 L  arc_capacity_1110
 G  connected_order_arc_1111
 L  arc_capacity_1112
 G  connected_order_arc_1113
 L  arc_capacity_1114
 G  connected_order_arc_1115
 L  arc_capacity_1116
 G  connected_order_arc_1117
 L  arc_capacity_1118
 G  connected_order_arc_1119
 L  arc_capacity_1120
 G  connected_order_arc_1121
 L  arc_capacity_1122
 G  connected_order_arc_1123
 L  arc_capacity_1124
 G  connected_order_arc_1125
 L  arc_capacity_1126
 G  connected_order_arc_1127
 L  arc_capacity_1128
 L  arc_capacity_1129
 G  connected_order_arc_1130
 L  arc_capacity_1131
 G  connected_order_arc_1132
 L  arc_capacity_1133
 G  connected_order_arc_1134
 L  arc_capacity_1135
 G  connected_order_arc_1136
 L  arc_capacity_1137
 G  connected_order_arc_1138
 L  arc_capacity_1139
 G  connected_order_arc_1140
 L  arc_capacity_1141
 G  connected_order_arc_1142
 L  arc_capacity_1143
 G  connected_order_arc_1144
 L  arc_capacity_1145
 G  connected_order_arc_1146
 L  arc_capacity_1147
 G  connected_order_arc_1148
 L  arc_capacity_1149
 L  arc_capacity_1150
 G  connected_order_arc_1151
 L  arc_capacity_1152
 G  connected_order_arc_1153
 L  arc_capacity_1154
 G  connected_order_arc_1155
 L  arc_capacity_1156
 G  connected_order_arc_1157
 L  arc_capacity_1158
 G  connected_order_arc_1159
 L  arc_capacity_1160
 G  connected_order_arc_1161
 L  arc_capacity_1162
 G  connected_order_arc_1163
 L  arc_capacity_1164
 G  connected_order_arc_1165
 L  arc_capacity_1166
 G  connected_order_arc_1167
 L  arc_capacity_1168
 G  connected_order_arc_1169
 L  arc_capacity_1170
 L  arc_capacity_1171
 G  connected_order_arc_1172
 L  arc_capacity_1173
 G  connected_order_arc_1174
 L  arc_capacity_1175
 G  connected_order_arc_1176
 L  arc_capacity_1177
 G  connected_order_arc_1178
 L  arc_capacity_1179
 G  connected_order_arc_1180
 L  arc_capacity_1181
 G  connected_order_arc_1182
 L  arc_capacity_1183
 G  connected_order_arc_1184
 L  arc_capacity_1185
 G  connected_order_arc_1186
 L  arc_capacity_1187
 G  connected_order_arc_1188
 L  arc_capacity_1189
 G  connected_order_arc_1190
 L  arc_capacity_1191
 L  arc_capacity_1192
 G  connected_order_arc_1193
 L  arc_capacity_1194
 G  connected_order_arc_1195
 L  arc_capacity_1196
 G  connected_order_arc_1197
 L  arc_capacity_1198
 G  connected_order_arc_1199
 L  arc_capacity_1200
 G  connected_order_arc_1201
 L  arc_capacity_1202
 G  connected_order_arc_1203
 L  arc_capacity_1204
 G  connected_order_arc_1205
 L  arc_capacity_1206
 G  connected_order_arc_1207
 L  arc_capacity_1208
 G  connected_order_arc_1209
 L  arc_capacity_1210
 G  connected_order_arc_1211
 L  arc_capacity_1212
 L  arc_capacity_1213
 G  connected_order_arc_1214
 L  arc_capacity_1215
 G  connected_order_arc_1216
 L  arc_capacity_1217
 G  connected_order_arc_1218
 L  arc_capacity_1219
 G  connected_order_arc_1220
 L  arc_capacity_1221
 G  connected_order_arc_1222
 L  arc_capacity_1223
 G  connected_order_arc_1224
 L  arc_capacity_1225
 G  connected_order_arc_1226
 L  arc_capacity_1227
 G  connected_order_arc_1228
 L  arc_capacity_1229
 G  connected_order_arc_1230
 L  arc_capacity_1231
 G  connected_order_arc_1232
 L  arc_capacity_1233
 L  arc_capacity_1234
 G  connected_order_arc_1235
 L  arc_capacity_1236
 G  connected_order_arc_1237
 L  arc_capacity_1238
 G  connected_order_arc_1239
 L  arc_capacity_1240
 G  connected_order_arc_1241
 L  arc_capacity_1242
 G  connected_order_arc_1243
 L  arc_capacity_1244
 G  connected_order_arc_1245
 L  arc_capacity_1246
 G  connected_order_arc_1247
 L  arc_capacity_1248
 G  connected_order_arc_1249
 L  arc_capacity_1250
 G  connected_order_arc_1251
 L  arc_capacity_1252
 G  connected_order_arc_1253
 L  arc_capacity_1254
 L  arc_capacity_1255
 G  connected_order_arc_1256
 L  arc_capacity_1257
 G  connected_order_arc_1258
 L  arc_capacity_1259
 G  connected_order_arc_1260
 L  arc_capacity_1261
 G  connected_order_arc_1262
 L  arc_capacity_1263
 G  connected_order_arc_1264
 L  arc_capacity_1265
 G  connected_order_arc_1266
 L  arc_capacity_1267
 G  connected_order_arc_1268
 L  arc_capacity_1269
 G  connected_order_arc_1270
 L  arc_capacity_1271
 G  connected_order_arc_1272
 L  arc_capacity_1273
 G  connected_order_arc_1274
 E  depot_departure_or_bypass_1275
 E  depot_return_or_bypass_1276
 E  out_degree_1277
 E  in_degree_1278
 G  order_active_lb_1279
 L  order_active_ub_1280
 E  segment_load_conservation_1281
 G  segment_prefix_lb_1282
 L  segment_prefix_ub_1283
 E  out_degree_1284
 E  in_degree_1285
 G  order_active_lb_1286
 L  order_active_ub_1287
 E  segment_load_conservation_1288
 G  segment_prefix_lb_1289
 L  segment_prefix_ub_1290
 E  out_degree_1291
 E  in_degree_1292
 G  order_active_lb_1293
 L  order_active_ub_1294
 E  segment_load_conservation_1295
 G  segment_prefix_lb_1296
 L  segment_prefix_ub_1297
 E  out_degree_1298
 E  in_degree_1299
 G  order_active_lb_1300
 L  order_active_ub_1301
 E  service_visit_def_1302
 E  free_load_conservation_1303
 E  out_degree_1304
 E  in_degree_1305
 G  order_active_lb_1306
 L  order_active_ub_1307
 E  service_visit_def_1308
 E  free_load_conservation_1309
 E  out_degree_1310
 E  in_degree_1311
 G  order_active_lb_1312
 L  order_active_ub_1313
 E  service_visit_def_1314
 E  free_load_conservation_1315
 E  out_degree_1316
 E  in_degree_1317
 G  order_active_lb_1318
 L  order_active_ub_1319
 E  service_visit_def_1320
 E  free_load_conservation_1321
 E  out_degree_1322
 E  in_degree_1323
 G  order_active_lb_1324
 L  order_active_ub_1325
 E  service_visit_def_1326
 E  free_load_conservation_1327
 E  out_degree_1328
 E  in_degree_1329
 G  order_active_lb_1330
 L  order_active_ub_1331
 E  service_visit_def_1332
 E  free_load_conservation_1333
 E  out_degree_1334
 E  in_degree_1335
 G  order_active_lb_1336
 L  order_active_ub_1337
 E  service_visit_def_1338
 E  free_load_conservation_1339
 E  out_degree_1340
 E  in_degree_1341
 G  order_active_lb_1342
 L  order_active_ub_1343
 E  service_visit_def_1344
 E  free_load_conservation_1345
 G  fixed_segment_relative_order_1346
 G  fixed_segment_relative_order_1347
 L  original_T_including_depot_unload_1348
COLUMNS
    t         normalized_mass_22_33  -1
    t         normalized_mass_26_54  -1
    t         normalized_mass_34_89  -1
    t         normalized_mass_23_100  -1
    t         normalized_mass_27_117  -1
    t         normalized_mass_21_134  -1
    t         normalized_mass_25_147  -1
    t         normalized_mass_28_164  -1
    t         normalization_225  2.3767857142857142e+01
    t         full_original_Gini_226  -7.7188095238095144e+01
    q         OBJ       1
    q         parent_nonstrict_scope_168  1
    q         full_original_Gini_226  35
    MARKER    'MARKER'                 'INTORG'
    x_22_0    OBJ       1.9549429837111887e-02
    x_22_0    product_lb_0  -2.4518388791569173e-02
    x_22_0    product_ub_1  -4.2073628850530440e-02
    x_22_0    onehot_22_32  1
    x_22_0    parent_nonstrict_scope_168  0.0456153362865944
    x_22_0    unique_nonzero_owner_227  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_0    product_lb_0  1
    w_22_0    product_ub_1  1
    w_22_0    normalized_mass_22_33  1
    w_22_0    full_original_Gini_226  -2.3767857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_1    OBJ       1.3032953224741260e-02
    x_22_1    product_lb_2  -2.4518388791569173e-02
    x_22_1    product_ub_3  -4.2073628850530440e-02
    x_22_1    onehot_22_32  1
    x_22_1    stock_lb_166  1
    x_22_1    stock_ub_167  1
    x_22_1    parent_nonstrict_scope_168  3.9098859674223774e-02
    x_22_1    unique_nonzero_owner_228  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_1    product_lb_2  1
    w_22_1    product_ub_3  1
    w_22_1    normalized_mass_22_33  1
    w_22_1    normalized_ratio_22_34  -1.4285714285714285e-01
    w_22_1    full_original_Gini_226  -1.9910714285714292e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_2    OBJ       6.5164766123706336e-03
    x_22_2    product_lb_4  -2.4518388791569173e-02
    x_22_2    product_ub_5  -4.2073628850530440e-02
    x_22_2    onehot_22_32  1
    x_22_2    stock_lb_166  2
    x_22_2    stock_ub_167  2
    x_22_2    parent_nonstrict_scope_168  3.2582383061853147e-02
    MARKER    'MARKER'                 'INTEND'
    w_22_2    product_lb_4  1
    w_22_2    product_ub_5  1
    w_22_2    normalized_mass_22_33  1
    w_22_2    normalized_ratio_22_34  -2.8571428571428570e-01
    w_22_2    full_original_Gini_226  -1.6053571428571420e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_3    product_lb_6  -2.4518388791569173e-02
    x_22_3    product_ub_7  -4.2073628850530440e-02
    x_22_3    onehot_22_32  1
    x_22_3    stock_lb_166  3
    x_22_3    stock_ub_167  3
    x_22_3    parent_nonstrict_scope_168  2.6065906449482514e-02
    x_22_3    unique_nonzero_owner_229  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_3    product_lb_6  1
    w_22_3    product_ub_7  1
    w_22_3    normalized_mass_22_33  1
    w_22_3    normalized_ratio_22_34  -4.2857142857142855e-01
    w_22_3    full_original_Gini_226  -1.2253571428571425e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_4    OBJ       -6.5164766123706266e-03
    x_22_4    product_lb_8  -2.4518388791569173e-02
    x_22_4    product_ub_9  -4.2073628850530440e-02
    x_22_4    onehot_22_32  1
    x_22_4    stock_lb_166  4
    x_22_4    stock_ub_167  4
    x_22_4    parent_nonstrict_scope_168  1.9549429837111887e-02
    x_22_4    unique_nonzero_owner_230  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_4    product_lb_8  1
    w_22_4    product_ub_9  1
    w_22_4    normalized_mass_22_33  1
    w_22_4    normalized_ratio_22_34  -5.7142857142857140e-01
    w_22_4    full_original_Gini_226  -8.8250000000000028e+00
    MARKER    'MARKER'                 'INTORG'
    x_22_5    OBJ       -1.3032953224741252e-02
    x_22_5    product_lb_10  -2.4518388791569173e-02
    x_22_5    product_ub_11  -4.2073628850530440e-02
    x_22_5    onehot_22_32  1
    x_22_5    stock_lb_166  5
    x_22_5    stock_ub_167  5
    x_22_5    parent_nonstrict_scope_168  1.3032953224741262e-02
    x_22_5    unique_nonzero_owner_231  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_5    product_lb_10  1
    w_22_5    product_ub_11  1
    w_22_5    normalized_mass_22_33  1
    w_22_5    normalized_ratio_22_34  -7.1428571428571419e-01
    w_22_5    full_original_Gini_226  -5.8130952380952374e+00
    MARKER    'MARKER'                 'INTORG'
    x_22_6    OBJ       -1.9549429837111883e-02
    x_22_6    product_lb_12  -2.4518388791569173e-02
    x_22_6    product_ub_13  -4.2073628850530440e-02
    x_22_6    onehot_22_32  1
    x_22_6    stock_lb_166  6
    x_22_6    stock_ub_167  6
    x_22_6    parent_nonstrict_scope_168  6.5164766123706310e-03
    x_22_6    unique_nonzero_owner_232  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_6    product_lb_12  1
    w_22_6    product_ub_13  1
    w_22_6    normalized_mass_22_33  1
    w_22_6    normalized_ratio_22_34  -8.5714285714285710e-01
    w_22_6    full_original_Gini_226  -4.3749999999999991e+00
    MARKER    'MARKER'                 'INTORG'
    x_22_7    OBJ       -2.6065906449482514e-02
    x_22_7    product_lb_14  -2.4518388791569173e-02
    x_22_7    product_ub_15  -4.2073628850530440e-02
    x_22_7    onehot_22_32  1
    x_22_7    stock_lb_166  7
    x_22_7    stock_ub_167  7
    x_22_7    unique_nonzero_owner_233  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_7    product_lb_14  1
    w_22_7    product_ub_15  1
    w_22_7    normalized_mass_22_33  1
    w_22_7    normalized_ratio_22_34  -1
    w_22_7    full_original_Gini_226  -4.2321428571428577e+00
    MARKER    'MARKER'                 'INTORG'
    x_22_8    OBJ       -1.9549429837111887e-02
    x_22_8    product_lb_16  -2.4518388791569173e-02
    x_22_8    product_ub_17  -4.2073628850530440e-02
    x_22_8    onehot_22_32  1
    x_22_8    stock_lb_166  8
    x_22_8    stock_ub_167  8
    x_22_8    parent_nonstrict_scope_168  6.5164766123706258e-03
    x_22_8    unique_nonzero_owner_234  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_8    product_lb_16  1
    w_22_8    product_ub_17  1
    w_22_8    normalized_mass_22_33  1
    w_22_8    normalized_ratio_22_34  -1.1428571428571428e+00
    w_22_8    full_original_Gini_226  -7.8035714285714235e+00
    MARKER    'MARKER'                 'INTORG'
    x_22_9    OBJ       -1.3032953224741262e-02
    x_22_9    product_lb_18  -2.4518388791569173e-02
    x_22_9    product_ub_19  -4.2073628850530440e-02
    x_22_9    onehot_22_32  1
    x_22_9    stock_lb_166  9
    x_22_9    stock_ub_167  9
    x_22_9    parent_nonstrict_scope_168  1.3032953224741252e-02
    x_22_9    unique_nonzero_owner_235  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_9    product_lb_18  1
    w_22_9    product_ub_19  1
    w_22_9    normalized_mass_22_33  1
    w_22_9    normalized_ratio_22_34  -1.2857142857142856e+00
    w_22_9    full_original_Gini_226  -1.1374999999999996e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_10   OBJ       -6.5164766123706371e-03
    x_22_10   product_lb_20  -2.4518388791569173e-02
    x_22_10   product_ub_21  -4.2073628850530440e-02
    x_22_10   onehot_22_32  1
    x_22_10   stock_lb_166  10
    x_22_10   stock_ub_167  10
    x_22_10   parent_nonstrict_scope_168  1.9549429837111876e-02
    x_22_10   unique_nonzero_owner_236  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_10   product_lb_20  1
    w_22_10   product_ub_21  1
    w_22_10   normalized_mass_22_33  1
    w_22_10   normalized_ratio_22_34  -1.4285714285714284e+00
    w_22_10   full_original_Gini_226  -1.4946428571428571e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_11   product_lb_22  -2.4518388791569173e-02
    x_22_11   product_ub_23  -4.2073628850530440e-02
    x_22_11   onehot_22_32  1
    x_22_11   stock_lb_166  11
    x_22_11   stock_ub_167  11
    x_22_11   parent_nonstrict_scope_168  2.6065906449482514e-02
    x_22_11   unique_nonzero_owner_237  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_11   product_lb_22  1
    w_22_11   product_ub_23  1
    w_22_11   normalized_mass_22_33  1
    w_22_11   normalized_ratio_22_34  -1.5714285714285714e+00
    w_22_11   full_original_Gini_226  -1.8660714285714288e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_12   OBJ       6.5164766123706266e-03
    x_22_12   product_lb_24  -2.4518388791569173e-02
    x_22_12   product_ub_25  -4.2073628850530440e-02
    x_22_12   onehot_22_32  1
    x_22_12   stock_lb_166  12
    x_22_12   stock_ub_167  12
    x_22_12   parent_nonstrict_scope_168  3.2582383061853140e-02
    x_22_12   unique_nonzero_owner_238  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_12   product_lb_24  1
    w_22_12   product_ub_25  1
    w_22_12   normalized_mass_22_33  1
    w_22_12   normalized_ratio_22_34  -1.7142857142857142e+00
    w_22_12   full_original_Gini_226  -2.2517857142857139e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_13   OBJ       1.3032953224741253e-02
    x_22_13   product_lb_26  -2.4518388791569173e-02
    x_22_13   product_ub_27  -4.2073628850530440e-02
    x_22_13   onehot_22_32  1
    x_22_13   stock_lb_166  13
    x_22_13   stock_ub_167  13
    x_22_13   parent_nonstrict_scope_168  3.9098859674223767e-02
    x_22_13   unique_nonzero_owner_239  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_13   product_lb_26  1
    w_22_13   product_ub_27  1
    w_22_13   normalized_mass_22_33  1
    w_22_13   normalized_ratio_22_34  -1.8571428571428570e+00
    w_22_13   full_original_Gini_226  -26.375
    MARKER    'MARKER'                 'INTORG'
    x_22_14   OBJ       1.9549429837111887e-02
    x_22_14   product_lb_28  -2.4518388791569173e-02
    x_22_14   product_ub_29  -4.2073628850530440e-02
    x_22_14   onehot_22_32  1
    x_22_14   stock_lb_166  14
    x_22_14   stock_ub_167  14
    x_22_14   parent_nonstrict_scope_168  0.0456153362865944
    x_22_14   unique_nonzero_owner_240  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_14   product_lb_28  1
    w_22_14   product_ub_29  1
    w_22_14   normalized_mass_22_33  1
    w_22_14   normalized_ratio_22_34  -2
    w_22_14   full_original_Gini_226  -3.0232142857142858e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_15   OBJ       2.6065906449482514e-02
    x_22_15   product_lb_30  -2.4518388791569173e-02
    x_22_15   product_ub_31  -4.2073628850530440e-02
    x_22_15   onehot_22_32  1
    x_22_15   stock_lb_166  15
    x_22_15   stock_ub_167  15
    x_22_15   parent_nonstrict_scope_168  5.2131812898965027e-02
    x_22_15   unique_nonzero_owner_241  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_15   product_lb_30  1
    w_22_15   product_ub_31  1
    w_22_15   normalized_mass_22_33  1
    w_22_15   normalized_ratio_22_34  -2.1428571428571428e+00
    w_22_15   full_original_Gini_226  -3.4089285714285715e+01
    rho_22    normalized_ratio_22_34  1
    rho_22    block_pair_pos_173  -1
    rho_22    block_pair_neg_174  1
    rho_22    block_pair_pos_175  -1
    rho_22    block_pair_neg_176  1
    rho_22    block_pair_pos_177  -1
    rho_22    block_pair_neg_178  1
    rho_22    block_pair_pos_179  -1
    rho_22    block_pair_neg_180  1
    rho_22    block_pair_pos_181  -1
    rho_22    block_pair_neg_182  1
    rho_22    block_pair_pos_183  -1
    rho_22    block_pair_neg_184  1
    rho_22    block_pair_pos_185  -1
    rho_22    block_pair_neg_186  1
    rho_22    normalization_225  1
    MARKER    'MARKER'                 'INTORG'
    x_26_0    OBJ       7.4474103065332977e-03
    x_26_0    product_lb_35  -2.4518388791569173e-02
    x_26_0    product_ub_36  -4.2073628850530440e-02
    x_26_0    onehot_26_53  1
    x_26_0    parent_nonstrict_scope_168  1.4894820613066595e-02
    x_26_0    unique_nonzero_owner_242  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_0    product_lb_35  1
    w_26_0    product_ub_36  1
    w_26_0    normalized_mass_26_54  1
    w_26_0    full_original_Gini_226  -2.3767857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_26_1    OBJ       3.7237051532666493e-03
    x_26_1    product_lb_37  -2.4518388791569173e-02
    x_26_1    product_ub_38  -4.2073628850530440e-02
    x_26_1    onehot_26_53  1
    x_26_1    stock_lb_166  1
    x_26_1    stock_ub_167  1
    x_26_1    parent_nonstrict_scope_168  1.1171115459799947e-02
    x_26_1    unique_nonzero_owner_243  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_1    product_lb_37  1
    w_26_1    product_ub_38  1
    w_26_1    normalized_mass_26_54  1
    w_26_1    normalized_ratio_26_55  -0.25
    w_26_1    full_original_Gini_226  -1.7017857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_26_2    product_lb_39  -2.4518388791569173e-02
    x_26_2    product_ub_40  -4.2073628850530440e-02
    x_26_2    onehot_26_53  1
    x_26_2    stock_lb_166  2
    x_26_2    stock_ub_167  2
    x_26_2    parent_nonstrict_scope_168  7.4474103065332977e-03
    x_26_2    unique_nonzero_owner_244  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_2    product_lb_39  1
    w_26_2    product_ub_40  1
    w_26_2    normalized_mass_26_54  1
    w_26_2    normalized_ratio_26_55  -0.5
    w_26_2    full_original_Gini_226  -1.0467857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_26_3    OBJ       -3.7237051532666488e-03
    x_26_3    product_lb_41  -2.4518388791569173e-02
    x_26_3    product_ub_42  -4.2073628850530440e-02
    x_26_3    onehot_26_53  1
    x_26_3    stock_lb_166  3
    x_26_3    stock_ub_167  3
    x_26_3    parent_nonstrict_scope_168  3.7237051532666488e-03
    x_26_3    unique_nonzero_owner_245  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_3    product_lb_41  1
    w_26_3    product_ub_42  1
    w_26_3    normalized_mass_26_54  1
    w_26_3    normalized_ratio_26_55  -0.75
    w_26_3    full_original_Gini_226  -5.2773809523809518e+00
    MARKER    'MARKER'                 'INTORG'
    x_26_4    OBJ       -7.4474103065332977e-03
    x_26_4    product_lb_43  -2.4518388791569173e-02
    x_26_4    product_ub_44  -4.2073628850530440e-02
    x_26_4    onehot_26_53  1
    x_26_4    stock_lb_166  4
    x_26_4    stock_ub_167  4
    x_26_4    unique_nonzero_owner_246  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_4    product_lb_43  1
    w_26_4    product_ub_44  1
    w_26_4    normalized_mass_26_54  1
    w_26_4    normalized_ratio_26_55  -1
    w_26_4    full_original_Gini_226  -4.2321428571428577e+00
    MARKER    'MARKER'                 'INTORG'
    x_26_5    OBJ       -3.7237051532666488e-03
    x_26_5    product_lb_45  -2.4518388791569173e-02
    x_26_5    product_ub_46  -4.2073628850530440e-02
    x_26_5    onehot_26_53  1
    x_26_5    stock_lb_166  5
    x_26_5    stock_ub_167  5
    x_26_5    parent_nonstrict_scope_168  3.7237051532666488e-03
    MARKER    'MARKER'                 'INTEND'
    w_26_5    product_lb_45  1
    w_26_5    product_ub_46  1
    w_26_5    normalized_mass_26_54  1
    w_26_5    normalized_ratio_26_55  -1.25
    w_26_5    full_original_Gini_226  -1.0482142857142859e+01
    MARKER    'MARKER'                 'INTORG'
    x_26_6    product_lb_47  -2.4518388791569173e-02
    x_26_6    product_ub_48  -4.2073628850530440e-02
    x_26_6    onehot_26_53  1
    x_26_6    stock_lb_166  6
    x_26_6    stock_ub_167  6
    x_26_6    parent_nonstrict_scope_168  7.4474103065332977e-03
    x_26_6    unique_nonzero_owner_247  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_6    product_lb_47  1
    w_26_6    product_ub_48  1
    w_26_6    normalized_mass_26_54  1
    w_26_6    normalized_ratio_26_55  -1.5
    w_26_6    full_original_Gini_226  -1.6732142857142858e+01
    MARKER    'MARKER'                 'INTORG'
    x_26_7    OBJ       3.7237051532666493e-03
    x_26_7    product_lb_49  -2.4518388791569173e-02
    x_26_7    product_ub_50  -4.2073628850530440e-02
    x_26_7    onehot_26_53  1
    x_26_7    stock_lb_166  7
    x_26_7    stock_ub_167  7
    x_26_7    parent_nonstrict_scope_168  1.1171115459799947e-02
    x_26_7    unique_nonzero_owner_248  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_7    product_lb_49  1
    w_26_7    product_ub_50  1
    w_26_7    normalized_mass_26_54  1
    w_26_7    normalized_ratio_26_55  -1.75
    w_26_7    full_original_Gini_226  -2.3482142857142858e+01
    MARKER    'MARKER'                 'INTORG'
    x_26_8    OBJ       7.4474103065332977e-03
    x_26_8    product_lb_51  -2.4518388791569173e-02
    x_26_8    product_ub_52  -4.2073628850530440e-02
    x_26_8    onehot_26_53  1
    x_26_8    stock_lb_166  8
    x_26_8    stock_ub_167  8
    x_26_8    parent_nonstrict_scope_168  1.4894820613066595e-02
    x_26_8    unique_nonzero_owner_249  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_8    product_lb_51  1
    w_26_8    product_ub_52  1
    w_26_8    normalized_mass_26_54  1
    w_26_8    normalized_ratio_26_55  -2
    w_26_8    full_original_Gini_226  -3.0232142857142858e+01
    rho_26    normalized_ratio_26_55  1
    rho_26    block_pair_pos_179  1
    rho_26    block_pair_neg_180  -1
    rho_26    block_pair_pos_197  -1
    rho_26    block_pair_neg_198  1
    rho_26    block_pair_pos_199  -1
    rho_26    block_pair_neg_200  1
    rho_26    block_pair_pos_201  -1
    rho_26    block_pair_neg_202  1
    rho_26    block_pair_pos_203  -1
    rho_26    block_pair_neg_204  1
    rho_26    block_pair_pos_205  -1
    rho_26    block_pair_neg_206  1
    rho_26    block_pair_pos_207  -1
    rho_26    block_pair_neg_208  1
    rho_26    normalization_225  1
    MARKER    'MARKER'                 'INTORG'
    x_34_0    OBJ       2.9789603523644435e-02
    x_34_0    product_lb_56  -2.4518388791569173e-02
    x_34_0    product_ub_57  -4.2073628850530440e-02
    x_34_0    onehot_34_88  1
    x_34_0    parent_nonstrict_scope_168  5.9579207047288869e-02
    x_34_0    unique_nonzero_owner_250  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_0    product_lb_56  1
    w_34_0    product_ub_57  1
    w_34_0    normalized_mass_34_89  1
    w_34_0    full_original_Gini_226  -2.3767857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_1    OBJ       2.2342202642733327e-02
    x_34_1    product_lb_58  -2.4518388791569173e-02
    x_34_1    product_ub_59  -4.2073628850530440e-02
    x_34_1    onehot_34_88  1
    x_34_1    stock_lb_166  1
    x_34_1    stock_ub_167  1
    x_34_1    parent_nonstrict_scope_168  5.2131806166377762e-02
    x_34_1    unique_nonzero_owner_251  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_1    product_lb_58  1
    w_34_1    product_ub_59  1
    w_34_1    normalized_mass_34_89  1
    w_34_1    normalized_ratio_34_90  -0.125
    w_34_1    full_original_Gini_226  -2.0392857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_2    OBJ       1.4894801761822219e-02
    x_34_2    product_lb_60  -2.4518388791569173e-02
    x_34_2    product_ub_61  -4.2073628850530440e-02
    x_34_2    onehot_34_88  1
    x_34_2    stock_lb_166  2
    x_34_2    stock_ub_167  2
    x_34_2    parent_nonstrict_scope_168  4.4684405285466654e-02
    MARKER    'MARKER'                 'INTEND'
    w_34_2    product_lb_60  1
    w_34_2    product_ub_61  1
    w_34_2    normalized_mass_34_89  1
    w_34_2    normalized_ratio_34_90  -0.25
    w_34_2    full_original_Gini_226  -1.7017857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_3    OBJ       7.4474008809111113e-03
    x_34_3    product_lb_62  -2.4518388791569173e-02
    x_34_3    product_ub_63  -4.2073628850530440e-02
    x_34_3    onehot_34_88  1
    x_34_3    stock_lb_166  3
    x_34_3    stock_ub_167  3
    x_34_3    parent_nonstrict_scope_168  3.7237004404555546e-02
    x_34_3    unique_nonzero_owner_252  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_3    product_lb_62  1
    w_34_3    product_ub_63  1
    w_34_3    normalized_mass_34_89  1
    w_34_3    normalized_ratio_34_90  -0.375
    w_34_3    full_original_Gini_226  -1.3642857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_4    product_lb_64  -2.4518388791569173e-02
    x_34_4    product_ub_65  -4.2073628850530440e-02
    x_34_4    onehot_34_88  1
    x_34_4    stock_lb_166  4
    x_34_4    stock_ub_167  4
    x_34_4    parent_nonstrict_scope_168  2.9789603523644435e-02
    x_34_4    unique_nonzero_owner_253  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_4    product_lb_64  1
    w_34_4    product_ub_65  1
    w_34_4    normalized_mass_34_89  1
    w_34_4    normalized_ratio_34_90  -0.5
    w_34_4    full_original_Gini_226  -1.0467857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_5    OBJ       -7.4474008809111078e-03
    x_34_5    product_lb_66  -2.4518388791569173e-02
    x_34_5    product_ub_67  -4.2073628850530440e-02
    x_34_5    onehot_34_88  1
    x_34_5    stock_lb_166  5
    x_34_5    stock_ub_167  5
    x_34_5    parent_nonstrict_scope_168  2.2342202642733327e-02
    x_34_5    unique_nonzero_owner_254  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_5    product_lb_66  1
    w_34_5    product_ub_67  1
    w_34_5    normalized_mass_34_89  1
    w_34_5    normalized_ratio_34_90  -0.625
    w_34_5    full_original_Gini_226  -7.5928571428571416e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_6    OBJ       -1.4894801761822217e-02
    x_34_6    product_lb_68  -2.4518388791569173e-02
    x_34_6    product_ub_69  -4.2073628850530440e-02
    x_34_6    onehot_34_88  1
    x_34_6    stock_lb_166  6
    x_34_6    stock_ub_167  6
    x_34_6    parent_nonstrict_scope_168  1.4894801761822217e-02
    x_34_6    unique_nonzero_owner_255  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_6    product_lb_68  1
    w_34_6    product_ub_69  1
    w_34_6    normalized_mass_34_89  1
    w_34_6    normalized_ratio_34_90  -0.75
    w_34_6    full_original_Gini_226  -5.2773809523809518e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_7    OBJ       -2.2342202642733327e-02
    x_34_7    product_lb_70  -2.4518388791569173e-02
    x_34_7    product_ub_71  -4.2073628850530440e-02
    x_34_7    onehot_34_88  1
    x_34_7    stock_lb_166  7
    x_34_7    stock_ub_167  7
    x_34_7    parent_nonstrict_scope_168  7.4474008809111087e-03
    x_34_7    unique_nonzero_owner_256  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_7    product_lb_70  1
    w_34_7    product_ub_71  1
    w_34_7    normalized_mass_34_89  1
    w_34_7    normalized_ratio_34_90  -0.875
    w_34_7    full_original_Gini_226  -4.3571428571428577e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_8    OBJ       -2.9789603523644435e-02
    x_34_8    product_lb_72  -2.4518388791569173e-02
    x_34_8    product_ub_73  -4.2073628850530440e-02
    x_34_8    onehot_34_88  1
    x_34_8    stock_lb_166  8
    x_34_8    stock_ub_167  8
    x_34_8    unique_nonzero_owner_257  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_8    product_lb_72  1
    w_34_8    product_ub_73  1
    w_34_8    normalized_mass_34_89  1
    w_34_8    normalized_ratio_34_90  -1
    w_34_8    full_original_Gini_226  -4.2321428571428577e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_9    OBJ       -2.2342202642733327e-02
    x_34_9    product_lb_74  -2.4518388791569173e-02
    x_34_9    product_ub_75  -4.2073628850530440e-02
    x_34_9    onehot_34_88  1
    x_34_9    stock_lb_166  9
    x_34_9    stock_ub_167  9
    x_34_9    parent_nonstrict_scope_168  7.4474008809111087e-03
    x_34_9    unique_nonzero_owner_258  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_9    product_lb_74  1
    w_34_9    product_ub_75  1
    w_34_9    normalized_mass_34_89  1
    w_34_9    normalized_ratio_34_90  -1.125
    w_34_9    full_original_Gini_226  -7.3571428571428577e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_10   OBJ       -1.4894801761822217e-02
    x_34_10   product_lb_76  -2.4518388791569173e-02
    x_34_10   product_ub_77  -4.2073628850530440e-02
    x_34_10   onehot_34_88  1
    x_34_10   stock_lb_166  10
    x_34_10   stock_ub_167  10
    x_34_10   parent_nonstrict_scope_168  1.4894801761822217e-02
    x_34_10   unique_nonzero_owner_259  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_10   product_lb_76  1
    w_34_10   product_ub_77  1
    w_34_10   normalized_mass_34_89  1
    w_34_10   normalized_ratio_34_90  -1.25
    w_34_10   full_original_Gini_226  -1.0482142857142859e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_11   OBJ       -7.4474008809111078e-03
    x_34_11   product_lb_78  -2.4518388791569173e-02
    x_34_11   product_ub_79  -4.2073628850530440e-02
    x_34_11   onehot_34_88  1
    x_34_11   stock_lb_166  11
    x_34_11   stock_ub_167  11
    x_34_11   parent_nonstrict_scope_168  2.2342202642733327e-02
    x_34_11   unique_nonzero_owner_260  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_11   product_lb_78  1
    w_34_11   product_ub_79  1
    w_34_11   normalized_mass_34_89  1
    w_34_11   normalized_ratio_34_90  -1.375
    w_34_11   full_original_Gini_226  -1.3607142857142858e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_12   product_lb_80  -2.4518388791569173e-02
    x_34_12   product_ub_81  -4.2073628850530440e-02
    x_34_12   onehot_34_88  1
    x_34_12   stock_lb_166  12
    x_34_12   stock_ub_167  12
    x_34_12   parent_nonstrict_scope_168  2.9789603523644435e-02
    x_34_12   unique_nonzero_owner_261  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_12   product_lb_80  1
    w_34_12   product_ub_81  1
    w_34_12   normalized_mass_34_89  1
    w_34_12   normalized_ratio_34_90  -1.5
    w_34_12   full_original_Gini_226  -1.6732142857142858e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_13   OBJ       7.4474008809111113e-03
    x_34_13   product_lb_82  -2.4518388791569173e-02
    x_34_13   product_ub_83  -4.2073628850530440e-02
    x_34_13   onehot_34_88  1
    x_34_13   stock_lb_166  13
    x_34_13   stock_ub_167  13
    x_34_13   parent_nonstrict_scope_168  3.7237004404555546e-02
    x_34_13   unique_nonzero_owner_262  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_13   product_lb_82  1
    w_34_13   product_ub_83  1
    w_34_13   normalized_mass_34_89  1
    w_34_13   normalized_ratio_34_90  -1.625
    w_34_13   full_original_Gini_226  -2.0107142857142858e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_14   OBJ       1.4894801761822219e-02
    x_34_14   product_lb_84  -2.4518388791569173e-02
    x_34_14   product_ub_85  -4.2073628850530440e-02
    x_34_14   onehot_34_88  1
    x_34_14   stock_lb_166  14
    x_34_14   stock_ub_167  14
    x_34_14   parent_nonstrict_scope_168  4.4684405285466654e-02
    x_34_14   unique_nonzero_owner_263  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_14   product_lb_84  1
    w_34_14   product_ub_85  1
    w_34_14   normalized_mass_34_89  1
    w_34_14   normalized_ratio_34_90  -1.75
    w_34_14   full_original_Gini_226  -2.3482142857142858e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_15   OBJ       2.2342202642733327e-02
    x_34_15   product_lb_86  -2.4518388791569173e-02
    x_34_15   product_ub_87  -4.2073628850530440e-02
    x_34_15   onehot_34_88  1
    x_34_15   stock_lb_166  15
    x_34_15   stock_ub_167  15
    x_34_15   parent_nonstrict_scope_168  5.2131806166377762e-02
    x_34_15   unique_nonzero_owner_264  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_15   product_lb_86  1
    w_34_15   product_ub_87  1
    w_34_15   normalized_mass_34_89  1
    w_34_15   normalized_ratio_34_90  -1.875
    w_34_15   full_original_Gini_226  -2.6857142857142858e+01
    rho_34    normalized_ratio_34_90  1
    rho_34    block_pair_pos_185  1
    rho_34    block_pair_neg_186  -1
    rho_34    block_pair_pos_207  1
    rho_34    block_pair_neg_208  -1
    rho_34    block_pair_pos_215  -1
    rho_34    block_pair_neg_216  1
    rho_34    block_pair_pos_217  -1
    rho_34    block_pair_neg_218  1
    rho_34    block_pair_pos_219  -1
    rho_34    block_pair_neg_220  1
    rho_34    block_pair_pos_221  -1
    rho_34    block_pair_neg_222  1
    rho_34    block_pair_pos_223  -1
    rho_34    block_pair_neg_224  1
    rho_34    normalization_225  1
    MARKER    'MARKER'                 'INTORG'
    x_23_0    product_lb_91  -2.4518388791569173e-02
    x_23_0    product_ub_92  -4.2073628850530440e-02
    x_23_0    onehot_23_99  1
    x_23_0    parent_nonstrict_scope_168  7.5404977512727595e-03
    x_23_0    unique_nonzero_owner_265  -1
    MARKER    'MARKER'                 'INTEND'
    w_23_0    product_lb_91  1
    w_23_0    product_ub_92  1
    w_23_0    normalized_mass_23_100  1
    w_23_0    full_original_Gini_226  -2.3767857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_23_1    OBJ       -7.5404977512727595e-03
    x_23_1    product_lb_93  -2.4518388791569173e-02
    x_23_1    product_ub_94  -4.2073628850530440e-02
    x_23_1    onehot_23_99  1
    x_23_1    stock_lb_166  1
    x_23_1    stock_ub_167  1
    MARKER    'MARKER'                 'INTEND'
    w_23_1    product_lb_93  1
    w_23_1    product_ub_94  1
    w_23_1    normalized_mass_23_100  1
    w_23_1    normalized_ratio_23_101  -1
    w_23_1    full_original_Gini_226  -4.2321428571428577e+00
    MARKER    'MARKER'                 'INTORG'
    x_23_2    product_lb_95  -2.4518388791569173e-02
    x_23_2    product_ub_96  -4.2073628850530440e-02
    x_23_2    onehot_23_99  1
    x_23_2    stock_lb_166  2
    x_23_2    stock_ub_167  2
    x_23_2    parent_nonstrict_scope_168  7.5404977512727595e-03
    x_23_2    unique_nonzero_owner_266  -1
    MARKER    'MARKER'                 'INTEND'
    w_23_2    product_lb_95  1
    w_23_2    product_ub_96  1
    w_23_2    normalized_mass_23_100  1
    w_23_2    normalized_ratio_23_101  -2
    w_23_2    full_original_Gini_226  -3.0232142857142858e+01
    MARKER    'MARKER'                 'INTORG'
    x_23_3    OBJ       7.5404977512727595e-03
    x_23_3    product_lb_97  -2.4518388791569173e-02
    x_23_3    product_ub_98  -4.2073628850530440e-02
    x_23_3    onehot_23_99  1
    x_23_3    stock_lb_166  3
    x_23_3    stock_ub_167  3
    x_23_3    parent_nonstrict_scope_168  1.5080995502545519e-02
    x_23_3    unique_nonzero_owner_267  -1
    MARKER    'MARKER'                 'INTEND'
    w_23_3    product_lb_97  1
    w_23_3    product_ub_98  1
    w_23_3    normalized_mass_23_100  1
    w_23_3    normalized_ratio_23_101  -3
    w_23_3    full_original_Gini_226  -5.7232142857142861e+01
    rho_23    normalized_ratio_23_101  1
    rho_23    block_pair_pos_175  1
    rho_23    block_pair_neg_176  -1
    rho_23    block_pair_pos_187  -1
    rho_23    block_pair_neg_188  1
    rho_23    block_pair_pos_189  -1
    rho_23    block_pair_neg_190  1
    rho_23    block_pair_pos_191  -1
    rho_23    block_pair_neg_192  1
    rho_23    block_pair_pos_193  -1
    rho_23    block_pair_neg_194  1
    rho_23    block_pair_pos_199  1
    rho_23    block_pair_neg_200  -1
    rho_23    block_pair_pos_217  1
    rho_23    block_pair_neg_218  -1
    rho_23    normalization_225  1
    MARKER    'MARKER'                 'INTORG'
    x_27_0    OBJ       4.1891612282083379e-03
    x_27_0    product_lb_102  -2.4518388791569173e-02
    x_27_0    product_ub_103  -4.2073628850530440e-02
    x_27_0    onehot_27_116  1
    x_27_0    parent_nonstrict_scope_168  8.3783224564166758e-03
    MARKER    'MARKER'                 'INTEND'
    w_27_0    product_lb_102  1
    w_27_0    product_ub_103  1
    w_27_0    normalized_mass_27_117  1
    w_27_0    full_original_Gini_226  -2.3767857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_1    OBJ       1.3963870760694466e-03
    x_27_1    product_lb_104  -2.4518388791569173e-02
    x_27_1    product_ub_105  -4.2073628850530440e-02
    x_27_1    onehot_27_116  1
    x_27_1    stock_lb_166  1
    x_27_1    stock_ub_167  1
    x_27_1    parent_nonstrict_scope_168  5.5855483042777845e-03
    x_27_1    unique_nonzero_owner_268  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_1    product_lb_104  1
    w_27_1    product_ub_105  1
    w_27_1    normalized_mass_27_117  1
    w_27_1    normalized_ratio_27_118  -3.3333333333333331e-01
    w_27_1    full_original_Gini_226  -1.4767857142857139e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_2    OBJ       -1.3963870760694457e-03
    x_27_2    product_lb_106  -2.4518388791569173e-02
    x_27_2    product_ub_107  -4.2073628850530440e-02
    x_27_2    onehot_27_116  1
    x_27_2    stock_lb_166  2
    x_27_2    stock_ub_167  2
    x_27_2    parent_nonstrict_scope_168  2.7927741521388922e-03
    x_27_2    unique_nonzero_owner_269  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_2    product_lb_106  1
    w_27_2    product_ub_107  1
    w_27_2    normalized_mass_27_117  1
    w_27_2    normalized_ratio_27_118  -6.6666666666666663e-01
    w_27_2    full_original_Gini_226  -6.7178571428571408e+00
    MARKER    'MARKER'                 'INTORG'
    x_27_3    OBJ       -4.1891612282083379e-03
    x_27_3    product_lb_108  -2.4518388791569173e-02
    x_27_3    product_ub_109  -4.2073628850530440e-02
    x_27_3    onehot_27_116  1
    x_27_3    stock_lb_166  3
    x_27_3    stock_ub_167  3
    x_27_3    unique_nonzero_owner_270  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_3    product_lb_108  1
    w_27_3    product_ub_109  1
    w_27_3    normalized_mass_27_117  1
    w_27_3    normalized_ratio_27_118  -1
    w_27_3    full_original_Gini_226  -4.2321428571428577e+00
    MARKER    'MARKER'                 'INTORG'
    x_27_4    OBJ       -1.3963870760694466e-03
    x_27_4    product_lb_110  -2.4518388791569173e-02
    x_27_4    product_ub_111  -4.2073628850530440e-02
    x_27_4    onehot_27_116  1
    x_27_4    stock_lb_166  4
    x_27_4    stock_ub_167  4
    x_27_4    parent_nonstrict_scope_168  2.7927741521388914e-03
    x_27_4    unique_nonzero_owner_271  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_4    product_lb_110  1
    w_27_4    product_ub_111  1
    w_27_4    normalized_mass_27_117  1
    w_27_4    normalized_ratio_27_118  -1.3333333333333333e+00
    w_27_4    full_original_Gini_226  -1.2565476190476193e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_5    OBJ       1.3963870760694448e-03
    x_27_5    product_lb_112  -2.4518388791569173e-02
    x_27_5    product_ub_113  -4.2073628850530440e-02
    x_27_5    onehot_27_116  1
    x_27_5    stock_lb_166  5
    x_27_5    stock_ub_167  5
    x_27_5    parent_nonstrict_scope_168  5.5855483042777827e-03
    x_27_5    unique_nonzero_owner_272  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_5    product_lb_112  1
    w_27_5    product_ub_113  1
    w_27_5    normalized_mass_27_117  1
    w_27_5    normalized_ratio_27_118  -1.6666666666666665e+00
    w_27_5    full_original_Gini_226  -2.1232142857142858e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_6    OBJ       4.1891612282083379e-03
    x_27_6    product_lb_114  -2.4518388791569173e-02
    x_27_6    product_ub_115  -4.2073628850530440e-02
    x_27_6    onehot_27_116  1
    x_27_6    stock_lb_166  6
    x_27_6    stock_ub_167  6
    x_27_6    parent_nonstrict_scope_168  8.3783224564166758e-03
    x_27_6    unique_nonzero_owner_273  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_6    product_lb_114  1
    w_27_6    product_ub_115  1
    w_27_6    normalized_mass_27_117  1
    w_27_6    normalized_ratio_27_118  -2
    w_27_6    full_original_Gini_226  -3.0232142857142858e+01
    rho_27    normalized_ratio_27_118  1
    rho_27    block_pair_pos_181  1
    rho_27    block_pair_neg_182  -1
    rho_27    block_pair_pos_191  1
    rho_27    block_pair_neg_192  -1
    rho_27    block_pair_pos_203  1
    rho_27    block_pair_neg_204  -1
    rho_27    block_pair_pos_209  -1
    rho_27    block_pair_neg_210  1
    rho_27    block_pair_pos_211  -1
    rho_27    block_pair_neg_212  1
    rho_27    block_pair_pos_213  -1
    rho_27    block_pair_neg_214  1
    rho_27    block_pair_pos_221  1
    rho_27    block_pair_neg_222  -1
    rho_27    normalization_225  1
    MARKER    'MARKER'                 'INTORG'
    x_21_0    OBJ       4.1891612282083379e-03
    x_21_0    product_lb_119  -2.4518388791569173e-02
    x_21_0    product_ub_120  -4.2073628850530440e-02
    x_21_0    onehot_21_133  1
    x_21_0    parent_nonstrict_scope_168  8.3783224564166758e-03
    MARKER    'MARKER'                 'INTEND'
    w_21_0    product_lb_119  1
    w_21_0    product_ub_120  1
    w_21_0    normalized_mass_21_134  1
    w_21_0    full_original_Gini_226  -2.3767857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_21_1    OBJ       1.3963870760694466e-03
    x_21_1    product_lb_121  -2.4518388791569173e-02
    x_21_1    product_ub_122  -4.2073628850530440e-02
    x_21_1    onehot_21_133  1
    x_21_1    stock_lb_166  1
    x_21_1    stock_ub_167  1
    x_21_1    parent_nonstrict_scope_168  5.5855483042777845e-03
    x_21_1    unique_nonzero_owner_274  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_1    product_lb_121  1
    w_21_1    product_ub_122  1
    w_21_1    normalized_mass_21_134  1
    w_21_1    normalized_ratio_21_135  -3.3333333333333331e-01
    w_21_1    full_original_Gini_226  -1.4767857142857139e+01
    MARKER    'MARKER'                 'INTORG'
    x_21_2    OBJ       -1.3963870760694457e-03
    x_21_2    product_lb_123  -2.4518388791569173e-02
    x_21_2    product_ub_124  -4.2073628850530440e-02
    x_21_2    onehot_21_133  1
    x_21_2    stock_lb_166  2
    x_21_2    stock_ub_167  2
    x_21_2    parent_nonstrict_scope_168  2.7927741521388922e-03
    x_21_2    unique_nonzero_owner_275  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_2    product_lb_123  1
    w_21_2    product_ub_124  1
    w_21_2    normalized_mass_21_134  1
    w_21_2    normalized_ratio_21_135  -6.6666666666666663e-01
    w_21_2    full_original_Gini_226  -6.7178571428571408e+00
    MARKER    'MARKER'                 'INTORG'
    x_21_3    OBJ       -4.1891612282083379e-03
    x_21_3    product_lb_125  -2.4518388791569173e-02
    x_21_3    product_ub_126  -4.2073628850530440e-02
    x_21_3    onehot_21_133  1
    x_21_3    stock_lb_166  3
    x_21_3    stock_ub_167  3
    x_21_3    unique_nonzero_owner_276  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_3    product_lb_125  1
    w_21_3    product_ub_126  1
    w_21_3    normalized_mass_21_134  1
    w_21_3    normalized_ratio_21_135  -1
    w_21_3    full_original_Gini_226  -4.2321428571428577e+00
    MARKER    'MARKER'                 'INTORG'
    x_21_4    OBJ       -1.3963870760694466e-03
    x_21_4    product_lb_127  -2.4518388791569173e-02
    x_21_4    product_ub_128  -4.2073628850530440e-02
    x_21_4    onehot_21_133  1
    x_21_4    stock_lb_166  4
    x_21_4    stock_ub_167  4
    x_21_4    parent_nonstrict_scope_168  2.7927741521388914e-03
    x_21_4    unique_nonzero_owner_277  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_4    product_lb_127  1
    w_21_4    product_ub_128  1
    w_21_4    normalized_mass_21_134  1
    w_21_4    normalized_ratio_21_135  -1.3333333333333333e+00
    w_21_4    full_original_Gini_226  -1.2565476190476193e+01
    MARKER    'MARKER'                 'INTORG'
    x_21_5    OBJ       1.3963870760694448e-03
    x_21_5    product_lb_129  -2.4518388791569173e-02
    x_21_5    product_ub_130  -4.2073628850530440e-02
    x_21_5    onehot_21_133  1
    x_21_5    stock_lb_166  5
    x_21_5    stock_ub_167  5
    x_21_5    parent_nonstrict_scope_168  5.5855483042777827e-03
    x_21_5    unique_nonzero_owner_278  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_5    product_lb_129  1
    w_21_5    product_ub_130  1
    w_21_5    normalized_mass_21_134  1
    w_21_5    normalized_ratio_21_135  -1.6666666666666665e+00
    w_21_5    full_original_Gini_226  -2.1232142857142858e+01
    MARKER    'MARKER'                 'INTORG'
    x_21_6    OBJ       4.1891612282083379e-03
    x_21_6    product_lb_131  -2.4518388791569173e-02
    x_21_6    product_ub_132  -4.2073628850530440e-02
    x_21_6    onehot_21_133  1
    x_21_6    stock_lb_166  6
    x_21_6    stock_ub_167  6
    x_21_6    parent_nonstrict_scope_168  8.3783224564166758e-03
    x_21_6    unique_nonzero_owner_279  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_6    product_lb_131  1
    w_21_6    product_ub_132  1
    w_21_6    normalized_mass_21_134  1
    w_21_6    normalized_ratio_21_135  -2
    w_21_6    full_original_Gini_226  -3.0232142857142858e+01
    rho_21    normalized_ratio_21_135  1
    rho_21    block_pair_pos_169  -1
    rho_21    block_pair_neg_170  1
    rho_21    block_pair_pos_171  -1
    rho_21    block_pair_neg_172  1
    rho_21    block_pair_pos_173  1
    rho_21    block_pair_neg_174  -1
    rho_21    block_pair_pos_187  1
    rho_21    block_pair_neg_188  -1
    rho_21    block_pair_pos_197  1
    rho_21    block_pair_neg_198  -1
    rho_21    block_pair_pos_209  1
    rho_21    block_pair_neg_210  -1
    rho_21    block_pair_pos_215  1
    rho_21    block_pair_neg_216  -1
    rho_21    normalization_225  1
    MARKER    'MARKER'                 'INTORG'
    x_25_0    OBJ       3.7702488756363797e-03
    x_25_0    product_lb_136  -2.4518388791569173e-02
    x_25_0    product_ub_137  -4.2073628850530440e-02
    x_25_0    onehot_25_146  1
    x_25_0    parent_nonstrict_scope_168  7.5404977512727595e-03
    MARKER    'MARKER'                 'INTEND'
    w_25_0    product_lb_136  1
    w_25_0    product_ub_137  1
    w_25_0    normalized_mass_25_147  1
    w_25_0    full_original_Gini_226  -2.3767857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_25_1    product_lb_138  -2.4518388791569173e-02
    x_25_1    product_ub_139  -4.2073628850530440e-02
    x_25_1    onehot_25_146  1
    x_25_1    stock_lb_166  1
    x_25_1    stock_ub_167  1
    x_25_1    parent_nonstrict_scope_168  3.7702488756363797e-03
    x_25_1    unique_nonzero_owner_280  -1
    MARKER    'MARKER'                 'INTEND'
    w_25_1    product_lb_138  1
    w_25_1    product_ub_139  1
    w_25_1    normalized_mass_25_147  1
    w_25_1    normalized_ratio_25_148  -0.5
    w_25_1    full_original_Gini_226  -1.0467857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_25_2    OBJ       -3.7702488756363797e-03
    x_25_2    product_lb_140  -2.4518388791569173e-02
    x_25_2    product_ub_141  -4.2073628850530440e-02
    x_25_2    onehot_25_146  1
    x_25_2    stock_lb_166  2
    x_25_2    stock_ub_167  2
    x_25_2    unique_nonzero_owner_281  -1
    MARKER    'MARKER'                 'INTEND'
    w_25_2    product_lb_140  1
    w_25_2    product_ub_141  1
    w_25_2    normalized_mass_25_147  1
    w_25_2    normalized_ratio_25_148  -1
    w_25_2    full_original_Gini_226  -4.2321428571428577e+00
    MARKER    'MARKER'                 'INTORG'
    x_25_3    product_lb_142  -2.4518388791569173e-02
    x_25_3    product_ub_143  -4.2073628850530440e-02
    x_25_3    onehot_25_146  1
    x_25_3    stock_lb_166  3
    x_25_3    stock_ub_167  3
    x_25_3    parent_nonstrict_scope_168  3.7702488756363797e-03
    x_25_3    unique_nonzero_owner_282  -1
    MARKER    'MARKER'                 'INTEND'
    w_25_3    product_lb_142  1
    w_25_3    product_ub_143  1
    w_25_3    normalized_mass_25_147  1
    w_25_3    normalized_ratio_25_148  -1.5
    w_25_3    full_original_Gini_226  -1.6732142857142858e+01
    MARKER    'MARKER'                 'INTORG'
    x_25_4    OBJ       3.7702488756363797e-03
    x_25_4    product_lb_144  -2.4518388791569173e-02
    x_25_4    product_ub_145  -4.2073628850530440e-02
    x_25_4    onehot_25_146  1
    x_25_4    stock_lb_166  4
    x_25_4    stock_ub_167  4
    x_25_4    parent_nonstrict_scope_168  7.5404977512727595e-03
    x_25_4    unique_nonzero_owner_283  -1
    MARKER    'MARKER'                 'INTEND'
    w_25_4    product_lb_144  1
    w_25_4    product_ub_145  1
    w_25_4    normalized_mass_25_147  1
    w_25_4    normalized_ratio_25_148  -2
    w_25_4    full_original_Gini_226  -3.0232142857142858e+01
    rho_25    normalized_ratio_25_148  1
    rho_25    block_pair_pos_169  1
    rho_25    block_pair_neg_170  -1
    rho_25    block_pair_pos_177  1
    rho_25    block_pair_neg_178  -1
    rho_25    block_pair_pos_189  1
    rho_25    block_pair_neg_190  -1
    rho_25    block_pair_pos_195  -1
    rho_25    block_pair_neg_196  1
    rho_25    block_pair_pos_201  1
    rho_25    block_pair_neg_202  -1
    rho_25    block_pair_pos_211  1
    rho_25    block_pair_neg_212  -1
    rho_25    block_pair_pos_219  1
    rho_25    block_pair_neg_220  -1
    rho_25    normalization_225  1
    MARKER    'MARKER'                 'INTORG'
    x_28_0    OBJ       4.1891612282083379e-03
    x_28_0    product_lb_149  -2.4518388791569173e-02
    x_28_0    product_ub_150  -4.2073628850530440e-02
    x_28_0    onehot_28_163  1
    x_28_0    parent_nonstrict_scope_168  8.3783224564166758e-03
    x_28_0    unique_nonzero_owner_284  -1
    MARKER    'MARKER'                 'INTEND'
    w_28_0    product_lb_149  1
    w_28_0    product_ub_150  1
    w_28_0    normalized_mass_28_164  1
    w_28_0    full_original_Gini_226  -2.3767857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_28_1    OBJ       1.3963870760694466e-03
    x_28_1    product_lb_151  -2.4518388791569173e-02
    x_28_1    product_ub_152  -4.2073628850530440e-02
    x_28_1    onehot_28_163  1
    x_28_1    stock_lb_166  1
    x_28_1    stock_ub_167  1
    x_28_1    parent_nonstrict_scope_168  5.5855483042777845e-03
    MARKER    'MARKER'                 'INTEND'
    w_28_1    product_lb_151  1
    w_28_1    product_ub_152  1
    w_28_1    normalized_mass_28_164  1
    w_28_1    normalized_ratio_28_165  -3.3333333333333331e-01
    w_28_1    full_original_Gini_226  -1.4767857142857139e+01
    MARKER    'MARKER'                 'INTORG'
    x_28_2    OBJ       -1.3963870760694457e-03
    x_28_2    product_lb_153  -2.4518388791569173e-02
    x_28_2    product_ub_154  -4.2073628850530440e-02
    x_28_2    onehot_28_163  1
    x_28_2    stock_lb_166  2
    x_28_2    stock_ub_167  2
    x_28_2    parent_nonstrict_scope_168  2.7927741521388922e-03
    x_28_2    unique_nonzero_owner_285  -1
    MARKER    'MARKER'                 'INTEND'
    w_28_2    product_lb_153  1
    w_28_2    product_ub_154  1
    w_28_2    normalized_mass_28_164  1
    w_28_2    normalized_ratio_28_165  -6.6666666666666663e-01
    w_28_2    full_original_Gini_226  -6.7178571428571408e+00
    MARKER    'MARKER'                 'INTORG'
    x_28_3    OBJ       -4.1891612282083379e-03
    x_28_3    product_lb_155  -2.4518388791569173e-02
    x_28_3    product_ub_156  -4.2073628850530440e-02
    x_28_3    onehot_28_163  1
    x_28_3    stock_lb_166  3
    x_28_3    stock_ub_167  3
    x_28_3    unique_nonzero_owner_286  -1
    MARKER    'MARKER'                 'INTEND'
    w_28_3    product_lb_155  1
    w_28_3    product_ub_156  1
    w_28_3    normalized_mass_28_164  1
    w_28_3    normalized_ratio_28_165  -1
    w_28_3    full_original_Gini_226  -4.2321428571428577e+00
    MARKER    'MARKER'                 'INTORG'
    x_28_4    OBJ       -1.3963870760694466e-03
    x_28_4    product_lb_157  -2.4518388791569173e-02
    x_28_4    product_ub_158  -4.2073628850530440e-02
    x_28_4    onehot_28_163  1
    x_28_4    stock_lb_166  4
    x_28_4    stock_ub_167  4
    x_28_4    parent_nonstrict_scope_168  2.7927741521388914e-03
    x_28_4    unique_nonzero_owner_287  -1
    MARKER    'MARKER'                 'INTEND'
    w_28_4    product_lb_157  1
    w_28_4    product_ub_158  1
    w_28_4    normalized_mass_28_164  1
    w_28_4    normalized_ratio_28_165  -1.3333333333333333e+00
    w_28_4    full_original_Gini_226  -1.2565476190476193e+01
    MARKER    'MARKER'                 'INTORG'
    x_28_5    OBJ       1.3963870760694448e-03
    x_28_5    product_lb_159  -2.4518388791569173e-02
    x_28_5    product_ub_160  -4.2073628850530440e-02
    x_28_5    onehot_28_163  1
    x_28_5    stock_lb_166  5
    x_28_5    stock_ub_167  5
    x_28_5    parent_nonstrict_scope_168  5.5855483042777827e-03
    x_28_5    unique_nonzero_owner_288  -1
    MARKER    'MARKER'                 'INTEND'
    w_28_5    product_lb_159  1
    w_28_5    product_ub_160  1
    w_28_5    normalized_mass_28_164  1
    w_28_5    normalized_ratio_28_165  -1.6666666666666665e+00
    w_28_5    full_original_Gini_226  -2.1232142857142858e+01
    MARKER    'MARKER'                 'INTORG'
    x_28_6    OBJ       4.1891612282083379e-03
    x_28_6    product_lb_161  -2.4518388791569173e-02
    x_28_6    product_ub_162  -4.2073628850530440e-02
    x_28_6    onehot_28_163  1
    x_28_6    stock_lb_166  6
    x_28_6    stock_ub_167  6
    x_28_6    parent_nonstrict_scope_168  8.3783224564166758e-03
    x_28_6    unique_nonzero_owner_289  -1
    MARKER    'MARKER'                 'INTEND'
    w_28_6    product_lb_161  1
    w_28_6    product_ub_162  1
    w_28_6    normalized_mass_28_164  1
    w_28_6    normalized_ratio_28_165  -2
    w_28_6    full_original_Gini_226  -3.0232142857142858e+01
    rho_28    normalized_ratio_28_165  1
    rho_28    block_pair_pos_171  1
    rho_28    block_pair_neg_172  -1
    rho_28    block_pair_pos_183  1
    rho_28    block_pair_neg_184  -1
    rho_28    block_pair_pos_193  1
    rho_28    block_pair_neg_194  -1
    rho_28    block_pair_pos_195  1
    rho_28    block_pair_neg_196  -1
    rho_28    block_pair_pos_205  1
    rho_28    block_pair_neg_206  -1
    rho_28    block_pair_pos_213  1
    rho_28    block_pair_neg_214  -1
    rho_28    block_pair_pos_223  1
    rho_28    block_pair_neg_224  -1
    rho_28    normalization_225  1
    a_22_26   block_pair_pos_179  1
    a_22_26   block_pair_neg_180  1
    a_22_26   full_original_Gini_226  -1
    a_22_34   block_pair_pos_185  1
    a_22_34   block_pair_neg_186  1
    a_22_34   full_original_Gini_226  -1
    a_22_23   block_pair_pos_175  1
    a_22_23   block_pair_neg_176  1
    a_22_23   full_original_Gini_226  -1
    a_22_27   block_pair_pos_181  1
    a_22_27   block_pair_neg_182  1
    a_22_27   full_original_Gini_226  -1
    a_22_21   block_pair_pos_173  1
    a_22_21   block_pair_neg_174  1
    a_22_21   full_original_Gini_226  -1
    a_22_25   block_pair_pos_177  1
    a_22_25   block_pair_neg_178  1
    a_22_25   full_original_Gini_226  -1
    a_22_28   block_pair_pos_183  1
    a_22_28   block_pair_neg_184  1
    a_22_28   full_original_Gini_226  -1
    a_26_34   block_pair_pos_207  1
    a_26_34   block_pair_neg_208  1
    a_26_34   full_original_Gini_226  -1
    a_26_23   block_pair_pos_199  1
    a_26_23   block_pair_neg_200  1
    a_26_23   full_original_Gini_226  -1
    a_26_27   block_pair_pos_203  1
    a_26_27   block_pair_neg_204  1
    a_26_27   full_original_Gini_226  -1
    a_26_21   block_pair_pos_197  1
    a_26_21   block_pair_neg_198  1
    a_26_21   full_original_Gini_226  -1
    a_26_25   block_pair_pos_201  1
    a_26_25   block_pair_neg_202  1
    a_26_25   full_original_Gini_226  -1
    a_26_28   block_pair_pos_205  1
    a_26_28   block_pair_neg_206  1
    a_26_28   full_original_Gini_226  -1
    a_34_23   block_pair_pos_217  1
    a_34_23   block_pair_neg_218  1
    a_34_23   full_original_Gini_226  -1
    a_34_27   block_pair_pos_221  1
    a_34_27   block_pair_neg_222  1
    a_34_27   full_original_Gini_226  -1
    a_34_21   block_pair_pos_215  1
    a_34_21   block_pair_neg_216  1
    a_34_21   full_original_Gini_226  -1
    a_34_25   block_pair_pos_219  1
    a_34_25   block_pair_neg_220  1
    a_34_25   full_original_Gini_226  -1
    a_34_28   block_pair_pos_223  1
    a_34_28   block_pair_neg_224  1
    a_34_28   full_original_Gini_226  -1
    a_23_27   block_pair_pos_191  1
    a_23_27   block_pair_neg_192  1
    a_23_27   full_original_Gini_226  -1
    a_23_21   block_pair_pos_187  1
    a_23_21   block_pair_neg_188  1
    a_23_21   full_original_Gini_226  -1
    a_23_25   block_pair_pos_189  1
    a_23_25   block_pair_neg_190  1
    a_23_25   full_original_Gini_226  -1
    a_23_28   block_pair_pos_193  1
    a_23_28   block_pair_neg_194  1
    a_23_28   full_original_Gini_226  -1
    a_27_21   block_pair_pos_209  1
    a_27_21   block_pair_neg_210  1
    a_27_21   full_original_Gini_226  -1
    a_27_25   block_pair_pos_211  1
    a_27_25   block_pair_neg_212  1
    a_27_25   full_original_Gini_226  -1
    a_27_28   block_pair_pos_213  1
    a_27_28   block_pair_neg_214  1
    a_27_28   full_original_Gini_226  -1
    a_21_25   block_pair_pos_169  1
    a_21_25   block_pair_neg_170  1
    a_21_25   full_original_Gini_226  -1
    a_21_28   block_pair_pos_171  1
    a_21_28   block_pair_neg_172  1
    a_21_28   full_original_Gini_226  -1
    a_25_28   block_pair_pos_195  1
    a_25_28   block_pair_neg_196  1
    a_25_28   full_original_Gini_226  -1
    MARKER    'MARKER'                 'INTORG'
    service_0_22_0  unique_nonzero_owner_227  1
    service_0_22_0  service_visit_def_613  1
    service_0_22_0  free_load_conservation_614  -2
    service_0_22_0  original_T_including_depot_unload_660  240
    service_0_22_1  unique_nonzero_owner_228  1
    service_0_22_1  service_visit_def_613  1
    service_0_22_1  free_load_conservation_614  -1
    service_0_22_1  original_T_including_depot_unload_660  120
    service_0_22_3  unique_nonzero_owner_229  1
    service_0_22_3  service_visit_def_613  1
    service_0_22_3  free_load_conservation_614  1
    service_0_22_4  unique_nonzero_owner_230  1
    service_0_22_4  service_visit_def_613  1
    service_0_22_4  free_load_conservation_614  2
    service_0_22_5  unique_nonzero_owner_231  1
    service_0_22_5  service_visit_def_613  1
    service_0_22_5  free_load_conservation_614  3
    service_0_22_6  unique_nonzero_owner_232  1
    service_0_22_6  service_visit_def_613  1
    service_0_22_6  free_load_conservation_614  4
    service_0_22_7  unique_nonzero_owner_233  1
    service_0_22_7  service_visit_def_613  1
    service_0_22_7  free_load_conservation_614  5
    service_0_22_8  unique_nonzero_owner_234  1
    service_0_22_8  service_visit_def_613  1
    service_0_22_8  free_load_conservation_614  6
    service_0_22_9  unique_nonzero_owner_235  1
    service_0_22_9  service_visit_def_613  1
    service_0_22_9  free_load_conservation_614  7
    service_0_22_10  unique_nonzero_owner_236  1
    service_0_22_10  service_visit_def_613  1
    service_0_22_10  free_load_conservation_614  8
    service_0_22_11  unique_nonzero_owner_237  1
    service_0_22_11  service_visit_def_613  1
    service_0_22_11  free_load_conservation_614  9
    service_0_22_12  unique_nonzero_owner_238  1
    service_0_22_12  service_visit_def_613  1
    service_0_22_12  free_load_conservation_614  10
    service_0_22_13  unique_nonzero_owner_239  1
    service_0_22_13  service_visit_def_613  1
    service_0_22_13  free_load_conservation_614  11
    service_0_22_14  unique_nonzero_owner_240  1
    service_0_22_14  service_visit_def_613  1
    service_0_22_14  free_load_conservation_614  12
    service_0_22_15  unique_nonzero_owner_241  1
    service_0_22_15  service_visit_def_613  1
    service_0_22_15  free_load_conservation_614  13
    service_1_22_0  unique_nonzero_owner_227  1
    service_1_22_0  service_visit_def_984  1
    service_1_22_0  free_load_conservation_985  -2
    service_1_22_0  original_T_including_depot_unload_1031  240
    service_1_22_1  unique_nonzero_owner_228  1
    service_1_22_1  service_visit_def_984  1
    service_1_22_1  free_load_conservation_985  -1
    service_1_22_1  original_T_including_depot_unload_1031  120
    service_1_22_3  unique_nonzero_owner_229  1
    service_1_22_3  service_visit_def_984  1
    service_1_22_3  free_load_conservation_985  1
    service_1_22_4  unique_nonzero_owner_230  1
    service_1_22_4  service_visit_def_984  1
    service_1_22_4  free_load_conservation_985  2
    service_1_22_5  unique_nonzero_owner_231  1
    service_1_22_5  service_visit_def_984  1
    service_1_22_5  free_load_conservation_985  3
    service_1_22_6  unique_nonzero_owner_232  1
    service_1_22_6  service_visit_def_984  1
    service_1_22_6  free_load_conservation_985  4
    service_1_22_7  unique_nonzero_owner_233  1
    service_1_22_7  service_visit_def_984  1
    service_1_22_7  free_load_conservation_985  5
    service_1_22_8  unique_nonzero_owner_234  1
    service_1_22_8  service_visit_def_984  1
    service_1_22_8  free_load_conservation_985  6
    service_1_22_9  unique_nonzero_owner_235  1
    service_1_22_9  service_visit_def_984  1
    service_1_22_9  free_load_conservation_985  7
    service_1_22_10  unique_nonzero_owner_236  1
    service_1_22_10  service_visit_def_984  1
    service_1_22_10  free_load_conservation_985  8
    service_1_22_11  unique_nonzero_owner_237  1
    service_1_22_11  service_visit_def_984  1
    service_1_22_11  free_load_conservation_985  9
    service_1_22_12  unique_nonzero_owner_238  1
    service_1_22_12  service_visit_def_984  1
    service_1_22_12  free_load_conservation_985  10
    service_1_22_13  unique_nonzero_owner_239  1
    service_1_22_13  service_visit_def_984  1
    service_1_22_13  free_load_conservation_985  11
    service_1_22_14  unique_nonzero_owner_240  1
    service_1_22_14  service_visit_def_984  1
    service_1_22_14  free_load_conservation_985  12
    service_1_22_15  unique_nonzero_owner_241  1
    service_1_22_15  service_visit_def_984  1
    service_1_22_15  free_load_conservation_985  13
    service_2_22_0  unique_nonzero_owner_227  1
    service_2_22_0  service_visit_def_1302  1
    service_2_22_0  free_load_conservation_1303  -2
    service_2_22_0  original_T_including_depot_unload_1348  240
    service_2_22_1  unique_nonzero_owner_228  1
    service_2_22_1  service_visit_def_1302  1
    service_2_22_1  free_load_conservation_1303  -1
    service_2_22_1  original_T_including_depot_unload_1348  120
    service_2_22_3  unique_nonzero_owner_229  1
    service_2_22_3  service_visit_def_1302  1
    service_2_22_3  free_load_conservation_1303  1
    service_2_22_4  unique_nonzero_owner_230  1
    service_2_22_4  service_visit_def_1302  1
    service_2_22_4  free_load_conservation_1303  2
    service_2_22_5  unique_nonzero_owner_231  1
    service_2_22_5  service_visit_def_1302  1
    service_2_22_5  free_load_conservation_1303  3
    service_2_22_6  unique_nonzero_owner_232  1
    service_2_22_6  service_visit_def_1302  1
    service_2_22_6  free_load_conservation_1303  4
    service_2_22_7  unique_nonzero_owner_233  1
    service_2_22_7  service_visit_def_1302  1
    service_2_22_7  free_load_conservation_1303  5
    service_2_22_8  unique_nonzero_owner_234  1
    service_2_22_8  service_visit_def_1302  1
    service_2_22_8  free_load_conservation_1303  6
    service_2_22_9  unique_nonzero_owner_235  1
    service_2_22_9  service_visit_def_1302  1
    service_2_22_9  free_load_conservation_1303  7
    service_2_22_10  unique_nonzero_owner_236  1
    service_2_22_10  service_visit_def_1302  1
    service_2_22_10  free_load_conservation_1303  8
    service_2_22_11  unique_nonzero_owner_237  1
    service_2_22_11  service_visit_def_1302  1
    service_2_22_11  free_load_conservation_1303  9
    service_2_22_12  unique_nonzero_owner_238  1
    service_2_22_12  service_visit_def_1302  1
    service_2_22_12  free_load_conservation_1303  10
    service_2_22_13  unique_nonzero_owner_239  1
    service_2_22_13  service_visit_def_1302  1
    service_2_22_13  free_load_conservation_1303  11
    service_2_22_14  unique_nonzero_owner_240  1
    service_2_22_14  service_visit_def_1302  1
    service_2_22_14  free_load_conservation_1303  12
    service_2_22_15  unique_nonzero_owner_241  1
    service_2_22_15  service_visit_def_1302  1
    service_2_22_15  free_load_conservation_1303  13
    service_0_26_0  unique_nonzero_owner_242  1
    service_0_26_0  service_visit_def_619  1
    service_0_26_0  free_load_conservation_620  -5
    service_0_26_0  original_T_including_depot_unload_660  600
    service_0_26_1  unique_nonzero_owner_243  1
    service_0_26_1  service_visit_def_619  1
    service_0_26_1  free_load_conservation_620  -4
    service_0_26_1  original_T_including_depot_unload_660  480
    service_0_26_2  unique_nonzero_owner_244  1
    service_0_26_2  service_visit_def_619  1
    service_0_26_2  free_load_conservation_620  -3
    service_0_26_2  original_T_including_depot_unload_660  360
    service_0_26_3  unique_nonzero_owner_245  1
    service_0_26_3  service_visit_def_619  1
    service_0_26_3  free_load_conservation_620  -2
    service_0_26_3  original_T_including_depot_unload_660  240
    service_0_26_4  unique_nonzero_owner_246  1
    service_0_26_4  service_visit_def_619  1
    service_0_26_4  free_load_conservation_620  -1
    service_0_26_4  original_T_including_depot_unload_660  120
    service_0_26_6  unique_nonzero_owner_247  1
    service_0_26_6  service_visit_def_619  1
    service_0_26_6  free_load_conservation_620  1
    service_0_26_7  unique_nonzero_owner_248  1
    service_0_26_7  service_visit_def_619  1
    service_0_26_7  free_load_conservation_620  2
    service_0_26_8  unique_nonzero_owner_249  1
    service_0_26_8  service_visit_def_619  1
    service_0_26_8  free_load_conservation_620  3
    service_1_26_0  unique_nonzero_owner_242  1
    service_1_26_0  service_visit_def_990  1
    service_1_26_0  free_load_conservation_991  -5
    service_1_26_0  original_T_including_depot_unload_1031  600
    service_1_26_1  unique_nonzero_owner_243  1
    service_1_26_1  service_visit_def_990  1
    service_1_26_1  free_load_conservation_991  -4
    service_1_26_1  original_T_including_depot_unload_1031  480
    service_1_26_2  unique_nonzero_owner_244  1
    service_1_26_2  service_visit_def_990  1
    service_1_26_2  free_load_conservation_991  -3
    service_1_26_2  original_T_including_depot_unload_1031  360
    service_1_26_3  unique_nonzero_owner_245  1
    service_1_26_3  service_visit_def_990  1
    service_1_26_3  free_load_conservation_991  -2
    service_1_26_3  original_T_including_depot_unload_1031  240
    service_1_26_4  unique_nonzero_owner_246  1
    service_1_26_4  service_visit_def_990  1
    service_1_26_4  free_load_conservation_991  -1
    service_1_26_4  original_T_including_depot_unload_1031  120
    service_1_26_6  unique_nonzero_owner_247  1
    service_1_26_6  service_visit_def_990  1
    service_1_26_6  free_load_conservation_991  1
    service_1_26_7  unique_nonzero_owner_248  1
    service_1_26_7  service_visit_def_990  1
    service_1_26_7  free_load_conservation_991  2
    service_1_26_8  unique_nonzero_owner_249  1
    service_1_26_8  service_visit_def_990  1
    service_1_26_8  free_load_conservation_991  3
    service_2_26_0  unique_nonzero_owner_242  1
    service_2_26_0  service_visit_def_1308  1
    service_2_26_0  free_load_conservation_1309  -5
    service_2_26_0  original_T_including_depot_unload_1348  600
    service_2_26_1  unique_nonzero_owner_243  1
    service_2_26_1  service_visit_def_1308  1
    service_2_26_1  free_load_conservation_1309  -4
    service_2_26_1  original_T_including_depot_unload_1348  480
    service_2_26_2  unique_nonzero_owner_244  1
    service_2_26_2  service_visit_def_1308  1
    service_2_26_2  free_load_conservation_1309  -3
    service_2_26_2  original_T_including_depot_unload_1348  360
    service_2_26_3  unique_nonzero_owner_245  1
    service_2_26_3  service_visit_def_1308  1
    service_2_26_3  free_load_conservation_1309  -2
    service_2_26_3  original_T_including_depot_unload_1348  240
    service_2_26_4  unique_nonzero_owner_246  1
    service_2_26_4  service_visit_def_1308  1
    service_2_26_4  free_load_conservation_1309  -1
    service_2_26_4  original_T_including_depot_unload_1348  120
    service_2_26_6  unique_nonzero_owner_247  1
    service_2_26_6  service_visit_def_1308  1
    service_2_26_6  free_load_conservation_1309  1
    service_2_26_7  unique_nonzero_owner_248  1
    service_2_26_7  service_visit_def_1308  1
    service_2_26_7  free_load_conservation_1309  2
    service_2_26_8  unique_nonzero_owner_249  1
    service_2_26_8  service_visit_def_1308  1
    service_2_26_8  free_load_conservation_1309  3
    service_0_34_0  unique_nonzero_owner_250  1
    service_0_34_0  service_visit_def_625  1
    service_0_34_0  free_load_conservation_626  -2
    service_0_34_0  original_T_including_depot_unload_660  240
    service_0_34_1  unique_nonzero_owner_251  1
    service_0_34_1  service_visit_def_625  1
    service_0_34_1  free_load_conservation_626  -1
    service_0_34_1  original_T_including_depot_unload_660  120
    service_0_34_3  unique_nonzero_owner_252  1
    service_0_34_3  service_visit_def_625  1
    service_0_34_3  free_load_conservation_626  1
    service_0_34_4  unique_nonzero_owner_253  1
    service_0_34_4  service_visit_def_625  1
    service_0_34_4  free_load_conservation_626  2
    service_0_34_5  unique_nonzero_owner_254  1
    service_0_34_5  service_visit_def_625  1
    service_0_34_5  free_load_conservation_626  3
    service_0_34_6  unique_nonzero_owner_255  1
    service_0_34_6  service_visit_def_625  1
    service_0_34_6  free_load_conservation_626  4
    service_0_34_7  unique_nonzero_owner_256  1
    service_0_34_7  service_visit_def_625  1
    service_0_34_7  free_load_conservation_626  5
    service_0_34_8  unique_nonzero_owner_257  1
    service_0_34_8  service_visit_def_625  1
    service_0_34_8  free_load_conservation_626  6
    service_0_34_9  unique_nonzero_owner_258  1
    service_0_34_9  service_visit_def_625  1
    service_0_34_9  free_load_conservation_626  7
    service_0_34_10  unique_nonzero_owner_259  1
    service_0_34_10  service_visit_def_625  1
    service_0_34_10  free_load_conservation_626  8
    service_0_34_11  unique_nonzero_owner_260  1
    service_0_34_11  service_visit_def_625  1
    service_0_34_11  free_load_conservation_626  9
    service_0_34_12  unique_nonzero_owner_261  1
    service_0_34_12  service_visit_def_625  1
    service_0_34_12  free_load_conservation_626  10
    service_0_34_13  unique_nonzero_owner_262  1
    service_0_34_13  service_visit_def_625  1
    service_0_34_13  free_load_conservation_626  11
    service_0_34_14  unique_nonzero_owner_263  1
    service_0_34_14  service_visit_def_625  1
    service_0_34_14  free_load_conservation_626  12
    service_0_34_15  unique_nonzero_owner_264  1
    service_0_34_15  service_visit_def_625  1
    service_0_34_15  free_load_conservation_626  13
    service_1_34_0  unique_nonzero_owner_250  1
    service_1_34_0  service_visit_def_996  1
    service_1_34_0  free_load_conservation_997  -2
    service_1_34_0  original_T_including_depot_unload_1031  240
    service_1_34_1  unique_nonzero_owner_251  1
    service_1_34_1  service_visit_def_996  1
    service_1_34_1  free_load_conservation_997  -1
    service_1_34_1  original_T_including_depot_unload_1031  120
    service_1_34_3  unique_nonzero_owner_252  1
    service_1_34_3  service_visit_def_996  1
    service_1_34_3  free_load_conservation_997  1
    service_1_34_4  unique_nonzero_owner_253  1
    service_1_34_4  service_visit_def_996  1
    service_1_34_4  free_load_conservation_997  2
    service_1_34_5  unique_nonzero_owner_254  1
    service_1_34_5  service_visit_def_996  1
    service_1_34_5  free_load_conservation_997  3
    service_1_34_6  unique_nonzero_owner_255  1
    service_1_34_6  service_visit_def_996  1
    service_1_34_6  free_load_conservation_997  4
    service_1_34_7  unique_nonzero_owner_256  1
    service_1_34_7  service_visit_def_996  1
    service_1_34_7  free_load_conservation_997  5
    service_1_34_8  unique_nonzero_owner_257  1
    service_1_34_8  service_visit_def_996  1
    service_1_34_8  free_load_conservation_997  6
    service_1_34_9  unique_nonzero_owner_258  1
    service_1_34_9  service_visit_def_996  1
    service_1_34_9  free_load_conservation_997  7
    service_1_34_10  unique_nonzero_owner_259  1
    service_1_34_10  service_visit_def_996  1
    service_1_34_10  free_load_conservation_997  8
    service_1_34_11  unique_nonzero_owner_260  1
    service_1_34_11  service_visit_def_996  1
    service_1_34_11  free_load_conservation_997  9
    service_1_34_12  unique_nonzero_owner_261  1
    service_1_34_12  service_visit_def_996  1
    service_1_34_12  free_load_conservation_997  10
    service_1_34_13  unique_nonzero_owner_262  1
    service_1_34_13  service_visit_def_996  1
    service_1_34_13  free_load_conservation_997  11
    service_1_34_14  unique_nonzero_owner_263  1
    service_1_34_14  service_visit_def_996  1
    service_1_34_14  free_load_conservation_997  12
    service_1_34_15  unique_nonzero_owner_264  1
    service_1_34_15  service_visit_def_996  1
    service_1_34_15  free_load_conservation_997  13
    service_2_34_0  unique_nonzero_owner_250  1
    service_2_34_0  service_visit_def_1314  1
    service_2_34_0  free_load_conservation_1315  -2
    service_2_34_0  original_T_including_depot_unload_1348  240
    service_2_34_1  unique_nonzero_owner_251  1
    service_2_34_1  service_visit_def_1314  1
    service_2_34_1  free_load_conservation_1315  -1
    service_2_34_1  original_T_including_depot_unload_1348  120
    service_2_34_3  unique_nonzero_owner_252  1
    service_2_34_3  service_visit_def_1314  1
    service_2_34_3  free_load_conservation_1315  1
    service_2_34_4  unique_nonzero_owner_253  1
    service_2_34_4  service_visit_def_1314  1
    service_2_34_4  free_load_conservation_1315  2
    service_2_34_5  unique_nonzero_owner_254  1
    service_2_34_5  service_visit_def_1314  1
    service_2_34_5  free_load_conservation_1315  3
    service_2_34_6  unique_nonzero_owner_255  1
    service_2_34_6  service_visit_def_1314  1
    service_2_34_6  free_load_conservation_1315  4
    service_2_34_7  unique_nonzero_owner_256  1
    service_2_34_7  service_visit_def_1314  1
    service_2_34_7  free_load_conservation_1315  5
    service_2_34_8  unique_nonzero_owner_257  1
    service_2_34_8  service_visit_def_1314  1
    service_2_34_8  free_load_conservation_1315  6
    service_2_34_9  unique_nonzero_owner_258  1
    service_2_34_9  service_visit_def_1314  1
    service_2_34_9  free_load_conservation_1315  7
    service_2_34_10  unique_nonzero_owner_259  1
    service_2_34_10  service_visit_def_1314  1
    service_2_34_10  free_load_conservation_1315  8
    service_2_34_11  unique_nonzero_owner_260  1
    service_2_34_11  service_visit_def_1314  1
    service_2_34_11  free_load_conservation_1315  9
    service_2_34_12  unique_nonzero_owner_261  1
    service_2_34_12  service_visit_def_1314  1
    service_2_34_12  free_load_conservation_1315  10
    service_2_34_13  unique_nonzero_owner_262  1
    service_2_34_13  service_visit_def_1314  1
    service_2_34_13  free_load_conservation_1315  11
    service_2_34_14  unique_nonzero_owner_263  1
    service_2_34_14  service_visit_def_1314  1
    service_2_34_14  free_load_conservation_1315  12
    service_2_34_15  unique_nonzero_owner_264  1
    service_2_34_15  service_visit_def_1314  1
    service_2_34_15  free_load_conservation_1315  13
    service_0_23_0  unique_nonzero_owner_265  1
    service_0_23_0  service_visit_def_631  1
    service_0_23_0  free_load_conservation_632  -1
    service_0_23_0  original_T_including_depot_unload_660  120
    service_0_23_2  unique_nonzero_owner_266  1
    service_0_23_2  service_visit_def_631  1
    service_0_23_2  free_load_conservation_632  1
    service_0_23_3  unique_nonzero_owner_267  1
    service_0_23_3  service_visit_def_631  1
    service_0_23_3  free_load_conservation_632  2
    service_1_23_0  unique_nonzero_owner_265  1
    service_1_23_0  service_visit_def_1002  1
    service_1_23_0  free_load_conservation_1003  -1
    service_1_23_0  original_T_including_depot_unload_1031  120
    service_1_23_2  unique_nonzero_owner_266  1
    service_1_23_2  service_visit_def_1002  1
    service_1_23_2  free_load_conservation_1003  1
    service_1_23_3  unique_nonzero_owner_267  1
    service_1_23_3  service_visit_def_1002  1
    service_1_23_3  free_load_conservation_1003  2
    service_2_23_0  unique_nonzero_owner_265  1
    service_2_23_0  service_visit_def_1320  1
    service_2_23_0  free_load_conservation_1321  -1
    service_2_23_0  original_T_including_depot_unload_1348  120
    service_2_23_2  unique_nonzero_owner_266  1
    service_2_23_2  service_visit_def_1320  1
    service_2_23_2  free_load_conservation_1321  1
    service_2_23_3  unique_nonzero_owner_267  1
    service_2_23_3  service_visit_def_1320  1
    service_2_23_3  free_load_conservation_1321  2
    service_0_27_1  unique_nonzero_owner_268  1
    service_0_27_1  service_visit_def_637  1
    service_0_27_1  free_load_conservation_638  1
    service_0_27_2  unique_nonzero_owner_269  1
    service_0_27_2  service_visit_def_637  1
    service_0_27_2  free_load_conservation_638  2
    service_0_27_3  unique_nonzero_owner_270  1
    service_0_27_3  service_visit_def_637  1
    service_0_27_3  free_load_conservation_638  3
    service_0_27_4  unique_nonzero_owner_271  1
    service_0_27_4  service_visit_def_637  1
    service_0_27_4  free_load_conservation_638  4
    service_0_27_5  unique_nonzero_owner_272  1
    service_0_27_5  service_visit_def_637  1
    service_0_27_5  free_load_conservation_638  5
    service_0_27_6  unique_nonzero_owner_273  1
    service_0_27_6  service_visit_def_637  1
    service_0_27_6  free_load_conservation_638  6
    service_1_27_1  unique_nonzero_owner_268  1
    service_1_27_1  service_visit_def_1008  1
    service_1_27_1  free_load_conservation_1009  1
    service_1_27_2  unique_nonzero_owner_269  1
    service_1_27_2  service_visit_def_1008  1
    service_1_27_2  free_load_conservation_1009  2
    service_1_27_3  unique_nonzero_owner_270  1
    service_1_27_3  service_visit_def_1008  1
    service_1_27_3  free_load_conservation_1009  3
    service_1_27_4  unique_nonzero_owner_271  1
    service_1_27_4  service_visit_def_1008  1
    service_1_27_4  free_load_conservation_1009  4
    service_1_27_5  unique_nonzero_owner_272  1
    service_1_27_5  service_visit_def_1008  1
    service_1_27_5  free_load_conservation_1009  5
    service_1_27_6  unique_nonzero_owner_273  1
    service_1_27_6  service_visit_def_1008  1
    service_1_27_6  free_load_conservation_1009  6
    service_2_27_1  unique_nonzero_owner_268  1
    service_2_27_1  service_visit_def_1326  1
    service_2_27_1  free_load_conservation_1327  1
    service_2_27_2  unique_nonzero_owner_269  1
    service_2_27_2  service_visit_def_1326  1
    service_2_27_2  free_load_conservation_1327  2
    service_2_27_3  unique_nonzero_owner_270  1
    service_2_27_3  service_visit_def_1326  1
    service_2_27_3  free_load_conservation_1327  3
    service_2_27_4  unique_nonzero_owner_271  1
    service_2_27_4  service_visit_def_1326  1
    service_2_27_4  free_load_conservation_1327  4
    service_2_27_5  unique_nonzero_owner_272  1
    service_2_27_5  service_visit_def_1326  1
    service_2_27_5  free_load_conservation_1327  5
    service_2_27_6  unique_nonzero_owner_273  1
    service_2_27_6  service_visit_def_1326  1
    service_2_27_6  free_load_conservation_1327  6
    service_0_21_1  unique_nonzero_owner_274  1
    service_0_21_1  service_visit_def_643  1
    service_0_21_1  free_load_conservation_644  1
    service_0_21_2  unique_nonzero_owner_275  1
    service_0_21_2  service_visit_def_643  1
    service_0_21_2  free_load_conservation_644  2
    service_0_21_3  unique_nonzero_owner_276  1
    service_0_21_3  service_visit_def_643  1
    service_0_21_3  free_load_conservation_644  3
    service_0_21_4  unique_nonzero_owner_277  1
    service_0_21_4  service_visit_def_643  1
    service_0_21_4  free_load_conservation_644  4
    service_0_21_5  unique_nonzero_owner_278  1
    service_0_21_5  service_visit_def_643  1
    service_0_21_5  free_load_conservation_644  5
    service_0_21_6  unique_nonzero_owner_279  1
    service_0_21_6  service_visit_def_643  1
    service_0_21_6  free_load_conservation_644  6
    service_1_21_1  unique_nonzero_owner_274  1
    service_1_21_1  service_visit_def_1014  1
    service_1_21_1  free_load_conservation_1015  1
    service_1_21_2  unique_nonzero_owner_275  1
    service_1_21_2  service_visit_def_1014  1
    service_1_21_2  free_load_conservation_1015  2
    service_1_21_3  unique_nonzero_owner_276  1
    service_1_21_3  service_visit_def_1014  1
    service_1_21_3  free_load_conservation_1015  3
    service_1_21_4  unique_nonzero_owner_277  1
    service_1_21_4  service_visit_def_1014  1
    service_1_21_4  free_load_conservation_1015  4
    service_1_21_5  unique_nonzero_owner_278  1
    service_1_21_5  service_visit_def_1014  1
    service_1_21_5  free_load_conservation_1015  5
    service_1_21_6  unique_nonzero_owner_279  1
    service_1_21_6  service_visit_def_1014  1
    service_1_21_6  free_load_conservation_1015  6
    service_2_21_1  unique_nonzero_owner_274  1
    service_2_21_1  service_visit_def_1332  1
    service_2_21_1  free_load_conservation_1333  1
    service_2_21_2  unique_nonzero_owner_275  1
    service_2_21_2  service_visit_def_1332  1
    service_2_21_2  free_load_conservation_1333  2
    service_2_21_3  unique_nonzero_owner_276  1
    service_2_21_3  service_visit_def_1332  1
    service_2_21_3  free_load_conservation_1333  3
    service_2_21_4  unique_nonzero_owner_277  1
    service_2_21_4  service_visit_def_1332  1
    service_2_21_4  free_load_conservation_1333  4
    service_2_21_5  unique_nonzero_owner_278  1
    service_2_21_5  service_visit_def_1332  1
    service_2_21_5  free_load_conservation_1333  5
    service_2_21_6  unique_nonzero_owner_279  1
    service_2_21_6  service_visit_def_1332  1
    service_2_21_6  free_load_conservation_1333  6
    service_0_25_1  unique_nonzero_owner_280  1
    service_0_25_1  service_visit_def_649  1
    service_0_25_1  free_load_conservation_650  1
    service_0_25_2  unique_nonzero_owner_281  1
    service_0_25_2  service_visit_def_649  1
    service_0_25_2  free_load_conservation_650  2
    service_0_25_3  unique_nonzero_owner_282  1
    service_0_25_3  service_visit_def_649  1
    service_0_25_3  free_load_conservation_650  3
    service_0_25_4  unique_nonzero_owner_283  1
    service_0_25_4  service_visit_def_649  1
    service_0_25_4  free_load_conservation_650  4
    service_1_25_1  unique_nonzero_owner_280  1
    service_1_25_1  service_visit_def_1020  1
    service_1_25_1  free_load_conservation_1021  1
    service_1_25_2  unique_nonzero_owner_281  1
    service_1_25_2  service_visit_def_1020  1
    service_1_25_2  free_load_conservation_1021  2
    service_1_25_3  unique_nonzero_owner_282  1
    service_1_25_3  service_visit_def_1020  1
    service_1_25_3  free_load_conservation_1021  3
    service_1_25_4  unique_nonzero_owner_283  1
    service_1_25_4  service_visit_def_1020  1
    service_1_25_4  free_load_conservation_1021  4
    service_2_25_1  unique_nonzero_owner_280  1
    service_2_25_1  service_visit_def_1338  1
    service_2_25_1  free_load_conservation_1339  1
    service_2_25_2  unique_nonzero_owner_281  1
    service_2_25_2  service_visit_def_1338  1
    service_2_25_2  free_load_conservation_1339  2
    service_2_25_3  unique_nonzero_owner_282  1
    service_2_25_3  service_visit_def_1338  1
    service_2_25_3  free_load_conservation_1339  3
    service_2_25_4  unique_nonzero_owner_283  1
    service_2_25_4  service_visit_def_1338  1
    service_2_25_4  free_load_conservation_1339  4
    service_0_28_0  unique_nonzero_owner_284  1
    service_0_28_0  service_visit_def_655  1
    service_0_28_0  free_load_conservation_656  -1
    service_0_28_0  original_T_including_depot_unload_660  120
    service_0_28_2  unique_nonzero_owner_285  1
    service_0_28_2  service_visit_def_655  1
    service_0_28_2  free_load_conservation_656  1
    service_0_28_3  unique_nonzero_owner_286  1
    service_0_28_3  service_visit_def_655  1
    service_0_28_3  free_load_conservation_656  2
    service_0_28_4  unique_nonzero_owner_287  1
    service_0_28_4  service_visit_def_655  1
    service_0_28_4  free_load_conservation_656  3
    service_0_28_5  unique_nonzero_owner_288  1
    service_0_28_5  service_visit_def_655  1
    service_0_28_5  free_load_conservation_656  4
    service_0_28_6  unique_nonzero_owner_289  1
    service_0_28_6  service_visit_def_655  1
    service_0_28_6  free_load_conservation_656  5
    service_1_28_0  unique_nonzero_owner_284  1
    service_1_28_0  service_visit_def_1026  1
    service_1_28_0  free_load_conservation_1027  -1
    service_1_28_0  original_T_including_depot_unload_1031  120
    service_1_28_2  unique_nonzero_owner_285  1
    service_1_28_2  service_visit_def_1026  1
    service_1_28_2  free_load_conservation_1027  1
    service_1_28_3  unique_nonzero_owner_286  1
    service_1_28_3  service_visit_def_1026  1
    service_1_28_3  free_load_conservation_1027  2
    service_1_28_4  unique_nonzero_owner_287  1
    service_1_28_4  service_visit_def_1026  1
    service_1_28_4  free_load_conservation_1027  3
    service_1_28_5  unique_nonzero_owner_288  1
    service_1_28_5  service_visit_def_1026  1
    service_1_28_5  free_load_conservation_1027  4
    service_1_28_6  unique_nonzero_owner_289  1
    service_1_28_6  service_visit_def_1026  1
    service_1_28_6  free_load_conservation_1027  5
    service_2_28_0  unique_nonzero_owner_284  1
    service_2_28_0  service_visit_def_1344  1
    service_2_28_0  free_load_conservation_1345  -1
    service_2_28_0  original_T_including_depot_unload_1348  120
    service_2_28_2  unique_nonzero_owner_285  1
    service_2_28_2  service_visit_def_1344  1
    service_2_28_2  free_load_conservation_1345  1
    service_2_28_3  unique_nonzero_owner_286  1
    service_2_28_3  service_visit_def_1344  1
    service_2_28_3  free_load_conservation_1345  2
    service_2_28_4  unique_nonzero_owner_287  1
    service_2_28_4  service_visit_def_1344  1
    service_2_28_4  free_load_conservation_1345  3
    service_2_28_5  unique_nonzero_owner_288  1
    service_2_28_5  service_visit_def_1344  1
    service_2_28_5  free_load_conservation_1345  4
    service_2_28_6  unique_nonzero_owner_289  1
    service_2_28_6  service_visit_def_1344  1
    service_2_28_6  free_load_conservation_1345  5
    MARKER    'MARKER'                 'INTEND'
    visit_0_1  out_degree_581  -1
    visit_0_1  in_degree_582  -1
    visit_0_1  order_active_lb_583  -1
    visit_0_1  order_active_ub_584  -12
    order_0_1  connected_order_arc_305  -1
    order_0_1  connected_order_arc_307  -1
    order_0_1  connected_order_arc_309  -1
    order_0_1  connected_order_arc_311  -1
    order_0_1  connected_order_arc_313  -1
    order_0_1  connected_order_arc_315  -1
    order_0_1  connected_order_arc_317  -1
    order_0_1  connected_order_arc_319  -1
    order_0_1  connected_order_arc_321  -1
    order_0_1  connected_order_arc_323  -1
    order_0_1  connected_order_arc_325  -1
    order_0_1  connected_order_arc_328  1
    order_0_1  connected_order_arc_351  1
    order_0_1  connected_order_arc_374  1
    order_0_1  connected_order_arc_397  1
    order_0_1  connected_order_arc_420  1
    order_0_1  connected_order_arc_443  1
    order_0_1  connected_order_arc_466  1
    order_0_1  connected_order_arc_489  1
    order_0_1  connected_order_arc_512  1
    order_0_1  connected_order_arc_535  1
    order_0_1  connected_order_arc_558  1
    order_0_1  order_active_lb_583  1
    order_0_1  order_active_ub_584  1
    order_0_1  fixed_segment_relative_order_657  -1
    visit_0_2  out_degree_588  -1
    visit_0_2  in_degree_589  -1
    visit_0_2  order_active_lb_590  -1
    visit_0_2  order_active_ub_591  -12
    order_0_2  connected_order_arc_305  1
    order_0_2  connected_order_arc_328  -1
    order_0_2  connected_order_arc_330  -1
    order_0_2  connected_order_arc_332  -1
    order_0_2  connected_order_arc_334  -1
    order_0_2  connected_order_arc_336  -1
    order_0_2  connected_order_arc_338  -1
    order_0_2  connected_order_arc_340  -1
    order_0_2  connected_order_arc_342  -1
    order_0_2  connected_order_arc_344  -1
    order_0_2  connected_order_arc_346  -1
    order_0_2  connected_order_arc_348  -1
    order_0_2  connected_order_arc_353  1
    order_0_2  connected_order_arc_376  1
    order_0_2  connected_order_arc_399  1
    order_0_2  connected_order_arc_422  1
    order_0_2  connected_order_arc_445  1
    order_0_2  connected_order_arc_468  1
    order_0_2  connected_order_arc_491  1
    order_0_2  connected_order_arc_514  1
    order_0_2  connected_order_arc_537  1
    order_0_2  connected_order_arc_560  1
    order_0_2  order_active_lb_590  1
    order_0_2  order_active_ub_591  1
    order_0_2  fixed_segment_relative_order_657  1
    order_0_2  fixed_segment_relative_order_658  -1
    visit_0_3  out_degree_595  -1
    visit_0_3  in_degree_596  -1
    visit_0_3  order_active_lb_597  -1
    visit_0_3  order_active_ub_598  -12
    order_0_3  connected_order_arc_307  1
    order_0_3  connected_order_arc_330  1
    order_0_3  connected_order_arc_351  -1
    order_0_3  connected_order_arc_353  -1
    order_0_3  connected_order_arc_355  -1
    order_0_3  connected_order_arc_357  -1
    order_0_3  connected_order_arc_359  -1
    order_0_3  connected_order_arc_361  -1
    order_0_3  connected_order_arc_363  -1
    order_0_3  connected_order_arc_365  -1
    order_0_3  connected_order_arc_367  -1
    order_0_3  connected_order_arc_369  -1
    order_0_3  connected_order_arc_371  -1
    order_0_3  connected_order_arc_378  1
    order_0_3  connected_order_arc_401  1
    order_0_3  connected_order_arc_424  1
    order_0_3  connected_order_arc_447  1
    order_0_3  connected_order_arc_470  1
    order_0_3  connected_order_arc_493  1
    order_0_3  connected_order_arc_516  1
    order_0_3  connected_order_arc_539  1
    order_0_3  connected_order_arc_562  1
    order_0_3  order_active_lb_597  1
    order_0_3  order_active_ub_598  1
    order_0_3  fixed_segment_relative_order_658  1
    order_0_3  fixed_segment_relative_order_659  -1
    visit_0_4  out_degree_602  -1
    visit_0_4  in_degree_603  -1
    visit_0_4  order_active_lb_604  -1
    visit_0_4  order_active_ub_605  -12
    order_0_4  connected_order_arc_309  1
    order_0_4  connected_order_arc_332  1
    order_0_4  connected_order_arc_355  1
    order_0_4  connected_order_arc_374  -1
    order_0_4  connected_order_arc_376  -1
    order_0_4  connected_order_arc_378  -1
    order_0_4  connected_order_arc_380  -1
    order_0_4  connected_order_arc_382  -1
    order_0_4  connected_order_arc_384  -1
    order_0_4  connected_order_arc_386  -1
    order_0_4  connected_order_arc_388  -1
    order_0_4  connected_order_arc_390  -1
    order_0_4  connected_order_arc_392  -1
    order_0_4  connected_order_arc_394  -1
    order_0_4  connected_order_arc_403  1
    order_0_4  connected_order_arc_426  1
    order_0_4  connected_order_arc_449  1
    order_0_4  connected_order_arc_472  1
    order_0_4  connected_order_arc_495  1
    order_0_4  connected_order_arc_518  1
    order_0_4  connected_order_arc_541  1
    order_0_4  connected_order_arc_564  1
    order_0_4  order_active_lb_604  1
    order_0_4  order_active_ub_605  1
    order_0_4  fixed_segment_relative_order_659  1
    visit_0_12  out_degree_609  -1
    visit_0_12  in_degree_610  -1
    visit_0_12  order_active_lb_611  -1
    visit_0_12  order_active_ub_612  -12
    visit_0_12  service_visit_def_613  -1
    order_0_12  connected_order_arc_311  1
    order_0_12  connected_order_arc_334  1
    order_0_12  connected_order_arc_357  1
    order_0_12  connected_order_arc_380  1
    order_0_12  connected_order_arc_397  -1
    order_0_12  connected_order_arc_399  -1
    order_0_12  connected_order_arc_401  -1
    order_0_12  connected_order_arc_403  -1
    order_0_12  connected_order_arc_405  -1
    order_0_12  connected_order_arc_407  -1
    order_0_12  connected_order_arc_409  -1
    order_0_12  connected_order_arc_411  -1
    order_0_12  connected_order_arc_413  -1
    order_0_12  connected_order_arc_415  -1
    order_0_12  connected_order_arc_417  -1
    order_0_12  connected_order_arc_428  1
    order_0_12  connected_order_arc_451  1
    order_0_12  connected_order_arc_474  1
    order_0_12  connected_order_arc_497  1
    order_0_12  connected_order_arc_520  1
    order_0_12  connected_order_arc_543  1
    order_0_12  connected_order_arc_566  1
    order_0_12  order_active_lb_611  1
    order_0_12  order_active_ub_612  1
    visit_0_13  out_degree_615  -1
    visit_0_13  in_degree_616  -1
    visit_0_13  order_active_lb_617  -1
    visit_0_13  order_active_ub_618  -12
    visit_0_13  service_visit_def_619  -1
    order_0_13  connected_order_arc_313  1
    order_0_13  connected_order_arc_336  1
    order_0_13  connected_order_arc_359  1
    order_0_13  connected_order_arc_382  1
    order_0_13  connected_order_arc_405  1
    order_0_13  connected_order_arc_420  -1
    order_0_13  connected_order_arc_422  -1
    order_0_13  connected_order_arc_424  -1
    order_0_13  connected_order_arc_426  -1
    order_0_13  connected_order_arc_428  -1
    order_0_13  connected_order_arc_430  -1
    order_0_13  connected_order_arc_432  -1
    order_0_13  connected_order_arc_434  -1
    order_0_13  connected_order_arc_436  -1
    order_0_13  connected_order_arc_438  -1
    order_0_13  connected_order_arc_440  -1
    order_0_13  connected_order_arc_453  1
    order_0_13  connected_order_arc_476  1
    order_0_13  connected_order_arc_499  1
    order_0_13  connected_order_arc_522  1
    order_0_13  connected_order_arc_545  1
    order_0_13  connected_order_arc_568  1
    order_0_13  order_active_lb_617  1
    order_0_13  order_active_ub_618  1
    visit_0_14  out_degree_621  -1
    visit_0_14  in_degree_622  -1
    visit_0_14  order_active_lb_623  -1
    visit_0_14  order_active_ub_624  -12
    visit_0_14  service_visit_def_625  -1
    order_0_14  connected_order_arc_315  1
    order_0_14  connected_order_arc_338  1
    order_0_14  connected_order_arc_361  1
    order_0_14  connected_order_arc_384  1
    order_0_14  connected_order_arc_407  1
    order_0_14  connected_order_arc_430  1
    order_0_14  connected_order_arc_443  -1
    order_0_14  connected_order_arc_445  -1
    order_0_14  connected_order_arc_447  -1
    order_0_14  connected_order_arc_449  -1
    order_0_14  connected_order_arc_451  -1
    order_0_14  connected_order_arc_453  -1
    order_0_14  connected_order_arc_455  -1
    order_0_14  connected_order_arc_457  -1
    order_0_14  connected_order_arc_459  -1
    order_0_14  connected_order_arc_461  -1
    order_0_14  connected_order_arc_463  -1
    order_0_14  connected_order_arc_478  1
    order_0_14  connected_order_arc_501  1
    order_0_14  connected_order_arc_524  1
    order_0_14  connected_order_arc_547  1
    order_0_14  connected_order_arc_570  1
    order_0_14  order_active_lb_623  1
    order_0_14  order_active_ub_624  1
    visit_0_15  out_degree_627  -1
    visit_0_15  in_degree_628  -1
    visit_0_15  order_active_lb_629  -1
    visit_0_15  order_active_ub_630  -12
    visit_0_15  service_visit_def_631  -1
    order_0_15  connected_order_arc_317  1
    order_0_15  connected_order_arc_340  1
    order_0_15  connected_order_arc_363  1
    order_0_15  connected_order_arc_386  1
    order_0_15  connected_order_arc_409  1
    order_0_15  connected_order_arc_432  1
    order_0_15  connected_order_arc_455  1
    order_0_15  connected_order_arc_466  -1
    order_0_15  connected_order_arc_468  -1
    order_0_15  connected_order_arc_470  -1
    order_0_15  connected_order_arc_472  -1
    order_0_15  connected_order_arc_474  -1
    order_0_15  connected_order_arc_476  -1
    order_0_15  connected_order_arc_478  -1
    order_0_15  connected_order_arc_480  -1
    order_0_15  connected_order_arc_482  -1
    order_0_15  connected_order_arc_484  -1
    order_0_15  connected_order_arc_486  -1
    order_0_15  connected_order_arc_503  1
    order_0_15  connected_order_arc_526  1
    order_0_15  connected_order_arc_549  1
    order_0_15  connected_order_arc_572  1
    order_0_15  order_active_lb_629  1
    order_0_15  order_active_ub_630  1
    visit_0_16  out_degree_633  -1
    visit_0_16  in_degree_634  -1
    visit_0_16  order_active_lb_635  -1
    visit_0_16  order_active_ub_636  -12
    visit_0_16  service_visit_def_637  -1
    order_0_16  connected_order_arc_319  1
    order_0_16  connected_order_arc_342  1
    order_0_16  connected_order_arc_365  1
    order_0_16  connected_order_arc_388  1
    order_0_16  connected_order_arc_411  1
    order_0_16  connected_order_arc_434  1
    order_0_16  connected_order_arc_457  1
    order_0_16  connected_order_arc_480  1
    order_0_16  connected_order_arc_489  -1
    order_0_16  connected_order_arc_491  -1
    order_0_16  connected_order_arc_493  -1
    order_0_16  connected_order_arc_495  -1
    order_0_16  connected_order_arc_497  -1
    order_0_16  connected_order_arc_499  -1
    order_0_16  connected_order_arc_501  -1
    order_0_16  connected_order_arc_503  -1
    order_0_16  connected_order_arc_505  -1
    order_0_16  connected_order_arc_507  -1
    order_0_16  connected_order_arc_509  -1
    order_0_16  connected_order_arc_528  1
    order_0_16  connected_order_arc_551  1
    order_0_16  connected_order_arc_574  1
    order_0_16  order_active_lb_635  1
    order_0_16  order_active_ub_636  1
    visit_0_17  out_degree_639  -1
    visit_0_17  in_degree_640  -1
    visit_0_17  order_active_lb_641  -1
    visit_0_17  order_active_ub_642  -12
    visit_0_17  service_visit_def_643  -1
    order_0_17  connected_order_arc_321  1
    order_0_17  connected_order_arc_344  1
    order_0_17  connected_order_arc_367  1
    order_0_17  connected_order_arc_390  1
    order_0_17  connected_order_arc_413  1
    order_0_17  connected_order_arc_436  1
    order_0_17  connected_order_arc_459  1
    order_0_17  connected_order_arc_482  1
    order_0_17  connected_order_arc_505  1
    order_0_17  connected_order_arc_512  -1
    order_0_17  connected_order_arc_514  -1
    order_0_17  connected_order_arc_516  -1
    order_0_17  connected_order_arc_518  -1
    order_0_17  connected_order_arc_520  -1
    order_0_17  connected_order_arc_522  -1
    order_0_17  connected_order_arc_524  -1
    order_0_17  connected_order_arc_526  -1
    order_0_17  connected_order_arc_528  -1
    order_0_17  connected_order_arc_530  -1
    order_0_17  connected_order_arc_532  -1
    order_0_17  connected_order_arc_553  1
    order_0_17  connected_order_arc_576  1
    order_0_17  order_active_lb_641  1
    order_0_17  order_active_ub_642  1
    visit_0_18  out_degree_645  -1
    visit_0_18  in_degree_646  -1
    visit_0_18  order_active_lb_647  -1
    visit_0_18  order_active_ub_648  -12
    visit_0_18  service_visit_def_649  -1
    order_0_18  connected_order_arc_323  1
    order_0_18  connected_order_arc_346  1
    order_0_18  connected_order_arc_369  1
    order_0_18  connected_order_arc_392  1
    order_0_18  connected_order_arc_415  1
    order_0_18  connected_order_arc_438  1
    order_0_18  connected_order_arc_461  1
    order_0_18  connected_order_arc_484  1
    order_0_18  connected_order_arc_507  1
    order_0_18  connected_order_arc_530  1
    order_0_18  connected_order_arc_535  -1
    order_0_18  connected_order_arc_537  -1
    order_0_18  connected_order_arc_539  -1
    order_0_18  connected_order_arc_541  -1
    order_0_18  connected_order_arc_543  -1
    order_0_18  connected_order_arc_545  -1
    order_0_18  connected_order_arc_547  -1
    order_0_18  connected_order_arc_549  -1
    order_0_18  connected_order_arc_551  -1
    order_0_18  connected_order_arc_553  -1
    order_0_18  connected_order_arc_555  -1
    order_0_18  connected_order_arc_578  1
    order_0_18  order_active_lb_647  1
    order_0_18  order_active_ub_648  1
    visit_0_19  out_degree_651  -1
    visit_0_19  in_degree_652  -1
    visit_0_19  order_active_lb_653  -1
    visit_0_19  order_active_ub_654  -12
    visit_0_19  service_visit_def_655  -1
    order_0_19  connected_order_arc_325  1
    order_0_19  connected_order_arc_348  1
    order_0_19  connected_order_arc_371  1
    order_0_19  connected_order_arc_394  1
    order_0_19  connected_order_arc_417  1
    order_0_19  connected_order_arc_440  1
    order_0_19  connected_order_arc_463  1
    order_0_19  connected_order_arc_486  1
    order_0_19  connected_order_arc_509  1
    order_0_19  connected_order_arc_532  1
    order_0_19  connected_order_arc_555  1
    order_0_19  connected_order_arc_558  -1
    order_0_19  connected_order_arc_560  -1
    order_0_19  connected_order_arc_562  -1
    order_0_19  connected_order_arc_564  -1
    order_0_19  connected_order_arc_566  -1
    order_0_19  connected_order_arc_568  -1
    order_0_19  connected_order_arc_570  -1
    order_0_19  connected_order_arc_572  -1
    order_0_19  connected_order_arc_574  -1
    order_0_19  connected_order_arc_576  -1
    order_0_19  connected_order_arc_578  -1
    order_0_19  order_active_lb_653  1
    order_0_19  order_active_ub_654  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_0  arc_capacity_290  -20
    arc_0_0_0  depot_departure_or_bypass_579  1
    arc_0_0_0  depot_return_or_bypass_580  1
    MARKER    'MARKER'                 'INTEND'
    load_0_0_0  arc_capacity_290  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_1  arc_capacity_291  -20
    arc_0_0_1  depot_departure_or_bypass_579  1
    arc_0_0_1  in_degree_582  1
    arc_0_0_1  original_T_including_depot_unload_660  6.2851955830851955e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_1  arc_capacity_291  1
    load_0_0_1  segment_load_conservation_585  -1
    load_0_0_1  segment_prefix_lb_586  1
    load_0_0_1  segment_prefix_ub_587  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_2  arc_capacity_292  -20
    arc_0_0_2  depot_departure_or_bypass_579  1
    arc_0_0_2  in_degree_589  1
    arc_0_0_2  original_T_including_depot_unload_660  3.9307504957585564e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_2  arc_capacity_292  1
    load_0_0_2  segment_load_conservation_592  -1
    load_0_0_2  segment_prefix_lb_593  1
    load_0_0_2  segment_prefix_ub_594  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_3  arc_capacity_293  -20
    arc_0_0_3  depot_departure_or_bypass_579  1
    arc_0_0_3  in_degree_596  1
    arc_0_0_3  original_T_including_depot_unload_660  391.582148421393
    MARKER    'MARKER'                 'INTEND'
    load_0_0_3  arc_capacity_293  1
    load_0_0_3  segment_load_conservation_599  -1
    load_0_0_3  segment_prefix_lb_600  1
    load_0_0_3  segment_prefix_ub_601  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_4  arc_capacity_294  -20
    arc_0_0_4  depot_departure_or_bypass_579  1
    arc_0_0_4  in_degree_603  1
    arc_0_0_4  original_T_including_depot_unload_660  3.6666597054112611e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_4  arc_capacity_294  1
    load_0_0_4  segment_load_conservation_606  -1
    load_0_0_4  segment_prefix_lb_607  1
    load_0_0_4  segment_prefix_ub_608  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_12  arc_capacity_295  -20
    arc_0_0_12  depot_departure_or_bypass_579  1
    arc_0_0_12  in_degree_610  1
    arc_0_0_12  original_T_including_depot_unload_660  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_12  arc_capacity_295  1
    load_0_0_12  free_load_conservation_614  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_13  arc_capacity_296  -20
    arc_0_0_13  depot_departure_or_bypass_579  1
    arc_0_0_13  in_degree_616  1
    arc_0_0_13  original_T_including_depot_unload_660  7.9650294035968375e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_13  arc_capacity_296  1
    load_0_0_13  free_load_conservation_620  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_14  arc_capacity_297  -20
    arc_0_0_14  depot_departure_or_bypass_579  1
    arc_0_0_14  in_degree_622  1
    arc_0_0_14  original_T_including_depot_unload_660  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_14  arc_capacity_297  1
    load_0_0_14  free_load_conservation_626  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_15  arc_capacity_298  -20
    arc_0_0_15  depot_departure_or_bypass_579  1
    arc_0_0_15  in_degree_628  1
    arc_0_0_15  original_T_including_depot_unload_660  5.8421641813809208e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_15  arc_capacity_298  1
    load_0_0_15  free_load_conservation_632  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_16  arc_capacity_299  -20
    arc_0_0_16  depot_departure_or_bypass_579  1
    arc_0_0_16  in_degree_634  1
    arc_0_0_16  original_T_including_depot_unload_660  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_16  arc_capacity_299  1
    load_0_0_16  free_load_conservation_638  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_17  arc_capacity_300  -20
    arc_0_0_17  depot_departure_or_bypass_579  1
    arc_0_0_17  in_degree_640  1
    arc_0_0_17  original_T_including_depot_unload_660  3.8060477410436619e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_17  arc_capacity_300  1
    load_0_0_17  free_load_conservation_644  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_18  arc_capacity_301  -20
    arc_0_0_18  depot_departure_or_bypass_579  1
    arc_0_0_18  in_degree_646  1
    arc_0_0_18  original_T_including_depot_unload_660  778.011461754062
    MARKER    'MARKER'                 'INTEND'
    load_0_0_18  arc_capacity_301  1
    load_0_0_18  free_load_conservation_650  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_19  arc_capacity_302  -20
    arc_0_0_19  depot_departure_or_bypass_579  1
    arc_0_0_19  in_degree_652  1
    arc_0_0_19  original_T_including_depot_unload_660  1.0056399980521732e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_19  arc_capacity_302  1
    load_0_0_19  free_load_conservation_656  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_0  arc_capacity_303  -20
    arc_0_1_0  depot_return_or_bypass_580  1
    arc_0_1_0  out_degree_581  1
    arc_0_1_0  original_T_including_depot_unload_660  4.3364857643570593e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_0  arc_capacity_303  1
    load_0_1_0  segment_load_conservation_585  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_2  arc_capacity_304  -20
    arc_0_1_2  connected_order_arc_305  -13
    arc_0_1_2  out_degree_581  1
    arc_0_1_2  in_degree_589  1
    arc_0_1_2  original_T_including_depot_unload_660  1.9684882536425036e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_2  arc_capacity_304  1
    load_0_1_2  segment_load_conservation_585  1
    load_0_1_2  segment_load_conservation_592  -1
    load_0_1_2  segment_prefix_lb_593  1
    load_0_1_2  segment_prefix_ub_594  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_3  arc_capacity_306  -20
    arc_0_1_3  connected_order_arc_307  -13
    arc_0_1_3  out_degree_581  1
    arc_0_1_3  in_degree_596  1
    arc_0_1_3  original_T_including_depot_unload_660  1.9892540565194176e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_3  arc_capacity_306  1
    load_0_1_3  segment_load_conservation_585  1
    load_0_1_3  segment_load_conservation_599  -1
    load_0_1_3  segment_prefix_lb_600  1
    load_0_1_3  segment_prefix_ub_601  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_4  arc_capacity_308  -20
    arc_0_1_4  connected_order_arc_309  -13
    arc_0_1_4  out_degree_581  1
    arc_0_1_4  in_degree_603  1
    arc_0_1_4  original_T_including_depot_unload_660  3.8423967538093660e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_4  arc_capacity_308  1
    load_0_1_4  segment_load_conservation_585  1
    load_0_1_4  segment_load_conservation_606  -1
    load_0_1_4  segment_prefix_lb_607  1
    load_0_1_4  segment_prefix_ub_608  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_12  arc_capacity_310  -20
    arc_0_1_12  connected_order_arc_311  -13
    arc_0_1_12  out_degree_581  1
    arc_0_1_12  in_degree_610  1
    arc_0_1_12  original_T_including_depot_unload_660  8.5579830526745980e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_12  arc_capacity_310  1
    load_0_1_12  segment_load_conservation_585  1
    load_0_1_12  free_load_conservation_614  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_13  arc_capacity_312  -20
    arc_0_1_13  connected_order_arc_313  -13
    arc_0_1_13  out_degree_581  1
    arc_0_1_13  in_degree_616  1
    arc_0_1_13  original_T_including_depot_unload_660  1.1827214856899616e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_13  arc_capacity_312  1
    load_0_1_13  segment_load_conservation_585  1
    load_0_1_13  free_load_conservation_620  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_14  arc_capacity_314  -20
    arc_0_1_14  connected_order_arc_315  -13
    arc_0_1_14  out_degree_581  1
    arc_0_1_14  in_degree_622  1
    arc_0_1_14  original_T_including_depot_unload_660  1.7908610301589636e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_14  arc_capacity_314  1
    load_0_1_14  segment_load_conservation_585  1
    load_0_1_14  free_load_conservation_626  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_15  arc_capacity_316  -20
    arc_0_1_15  connected_order_arc_317  -13
    arc_0_1_15  out_degree_581  1
    arc_0_1_15  in_degree_628  1
    arc_0_1_15  original_T_including_depot_unload_660  7.9279566508536948e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_15  arc_capacity_316  1
    load_0_1_15  segment_load_conservation_585  1
    load_0_1_15  free_load_conservation_632  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_16  arc_capacity_318  -20
    arc_0_1_16  connected_order_arc_319  -13
    arc_0_1_16  out_degree_581  1
    arc_0_1_16  in_degree_634  1
    arc_0_1_16  original_T_including_depot_unload_660  1.1588937665971753e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_16  arc_capacity_318  1
    load_0_1_16  segment_load_conservation_585  1
    load_0_1_16  free_load_conservation_638  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_17  arc_capacity_320  -20
    arc_0_1_17  connected_order_arc_321  -13
    arc_0_1_17  out_degree_581  1
    arc_0_1_17  in_degree_640  1
    arc_0_1_17  original_T_including_depot_unload_660  4.8520683722319296e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_17  arc_capacity_320  1
    load_0_1_17  segment_load_conservation_585  1
    load_0_1_17  free_load_conservation_644  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_18  arc_capacity_322  -20
    arc_0_1_18  connected_order_arc_323  -13
    arc_0_1_18  out_degree_581  1
    arc_0_1_18  in_degree_646  1
    arc_0_1_18  original_T_including_depot_unload_660  9.9507040584540334e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_18  arc_capacity_322  1
    load_0_1_18  segment_load_conservation_585  1
    load_0_1_18  free_load_conservation_650  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_19  arc_capacity_324  -20
    arc_0_1_19  connected_order_arc_325  -13
    arc_0_1_19  out_degree_581  1
    arc_0_1_19  in_degree_652  1
    arc_0_1_19  original_T_including_depot_unload_660  1.4285403548915413e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_19  arc_capacity_324  1
    load_0_1_19  segment_load_conservation_585  1
    load_0_1_19  free_load_conservation_656  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_0  arc_capacity_326  -20
    arc_0_2_0  depot_return_or_bypass_580  1
    arc_0_2_0  out_degree_588  1
    arc_0_2_0  original_T_including_depot_unload_660  3.9270969537253126e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_0  arc_capacity_326  1
    load_0_2_0  segment_load_conservation_592  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_1  arc_capacity_327  -20
    arc_0_2_1  connected_order_arc_328  -13
    arc_0_2_1  in_degree_582  1
    arc_0_2_1  out_degree_588  1
    arc_0_2_1  original_T_including_depot_unload_660  4.9445985110995662e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_1  arc_capacity_327  1
    load_0_2_1  segment_load_conservation_585  -1
    load_0_2_1  segment_prefix_lb_586  1
    load_0_2_1  segment_prefix_ub_587  1
    load_0_2_1  segment_load_conservation_592  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_3  arc_capacity_329  -20
    arc_0_2_3  connected_order_arc_330  -13
    arc_0_2_3  out_degree_588  1
    arc_0_2_3  in_degree_596  1
    arc_0_2_3  original_T_including_depot_unload_660  1.2340243107914335e+00
    MARKER    'MARKER'                 'INTEND'
    load_0_2_3  arc_capacity_329  1
    load_0_2_3  segment_load_conservation_592  1
    load_0_2_3  segment_load_conservation_599  -1
    load_0_2_3  segment_prefix_lb_600  1
    load_0_2_3  segment_prefix_ub_601  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_4  arc_capacity_331  -20
    arc_0_2_4  connected_order_arc_332  -13
    arc_0_2_4  out_degree_588  1
    arc_0_2_4  in_degree_603  1
    arc_0_2_4  original_T_including_depot_unload_660  1.9450542613707577e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_4  arc_capacity_331  1
    load_0_2_4  segment_load_conservation_592  1
    load_0_2_4  segment_load_conservation_606  -1
    load_0_2_4  segment_prefix_lb_607  1
    load_0_2_4  segment_prefix_ub_608  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_12  arc_capacity_333  -20
    arc_0_2_12  connected_order_arc_334  -13
    arc_0_2_12  out_degree_588  1
    arc_0_2_12  in_degree_610  1
    arc_0_2_12  original_T_including_depot_unload_660  756.038676628532
    MARKER    'MARKER'                 'INTEND'
    load_0_2_12  arc_capacity_333  1
    load_0_2_12  segment_load_conservation_592  1
    load_0_2_12  free_load_conservation_614  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_13  arc_capacity_335  -20
    arc_0_2_13  connected_order_arc_336  -13
    arc_0_2_13  out_degree_588  1
    arc_0_2_13  in_degree_616  1
    arc_0_2_13  original_T_including_depot_unload_660  1.0464557570570403e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_13  arc_capacity_335  1
    load_0_2_13  segment_load_conservation_592  1
    load_0_2_13  free_load_conservation_620  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_14  arc_capacity_337  -20
    arc_0_2_14  connected_order_arc_338  -13
    arc_0_2_14  out_degree_588  1
    arc_0_2_14  in_degree_622  1
    arc_0_2_14  original_T_including_depot_unload_660  1.5975637706723310e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_14  arc_capacity_337  1
    load_0_2_14  segment_load_conservation_592  1
    load_0_2_14  free_load_conservation_626  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_15  arc_capacity_339  -20
    arc_0_2_15  connected_order_arc_340  -13
    arc_0_2_15  out_degree_588  1
    arc_0_2_15  in_degree_628  1
    arc_0_2_15  original_T_including_depot_unload_660  607.934328093982
    MARKER    'MARKER'                 'INTEND'
    load_0_2_15  arc_capacity_339  1
    load_0_2_15  segment_load_conservation_592  1
    load_0_2_15  free_load_conservation_632  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_16  arc_capacity_341  -20
    arc_0_2_16  connected_order_arc_342  -13
    arc_0_2_16  out_degree_588  1
    arc_0_2_16  in_degree_634  1
    arc_0_2_16  original_T_including_depot_unload_660  9.6988018824317578e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_16  arc_capacity_341  1
    load_0_2_16  segment_load_conservation_592  1
    load_0_2_16  free_load_conservation_638  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_17  arc_capacity_343  -20
    arc_0_2_17  connected_order_arc_344  -13
    arc_0_2_17  out_degree_588  1
    arc_0_2_17  in_degree_640  1
    arc_0_2_17  original_T_including_depot_unload_660  299.915584808525
    MARKER    'MARKER'                 'INTEND'
    load_0_2_17  arc_capacity_343  1
    load_0_2_17  segment_load_conservation_592  1
    load_0_2_17  free_load_conservation_644  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_18  arc_capacity_345  -20
    arc_0_2_18  connected_order_arc_346  -13
    arc_0_2_18  out_degree_588  1
    arc_0_2_18  in_degree_646  1
    arc_0_2_18  original_T_including_depot_unload_660  8.0665554503073736e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_18  arc_capacity_345  1
    load_0_2_18  segment_load_conservation_592  1
    load_0_2_18  free_load_conservation_650  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_19  arc_capacity_347  -20
    arc_0_2_19  connected_order_arc_348  -13
    arc_0_2_19  out_degree_588  1
    arc_0_2_19  in_degree_652  1
    arc_0_2_19  original_T_including_depot_unload_660  1.3220876423614575e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_19  arc_capacity_347  1
    load_0_2_19  segment_load_conservation_592  1
    load_0_2_19  free_load_conservation_656  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_0  arc_capacity_349  -20
    arc_0_3_0  depot_return_or_bypass_580  1
    arc_0_3_0  out_degree_595  1
    arc_0_3_0  original_T_including_depot_unload_660  391.582148421393
    MARKER    'MARKER'                 'INTEND'
    load_0_3_0  arc_capacity_349  1
    load_0_3_0  segment_load_conservation_599  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_1  arc_capacity_350  -20
    arc_0_3_1  connected_order_arc_351  -13
    arc_0_3_1  in_degree_582  1
    arc_0_3_1  out_degree_595  1
    arc_0_3_1  original_T_including_depot_unload_660  4.9495118393852869e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_1  arc_capacity_350  1
    load_0_3_1  segment_load_conservation_585  -1
    load_0_3_1  segment_prefix_lb_586  1
    load_0_3_1  segment_prefix_ub_587  1
    load_0_3_1  segment_load_conservation_599  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_2  arc_capacity_352  -20
    arc_0_3_2  connected_order_arc_353  -13
    arc_0_3_2  in_degree_589  1
    arc_0_3_2  out_degree_595  1
    arc_0_3_2  original_T_including_depot_unload_660  2.5978621120511871e+00
    MARKER    'MARKER'                 'INTEND'
    load_0_3_2  arc_capacity_352  1
    load_0_3_2  segment_load_conservation_592  -1
    load_0_3_2  segment_prefix_lb_593  1
    load_0_3_2  segment_prefix_ub_594  1
    load_0_3_2  segment_load_conservation_599  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_4  arc_capacity_354  -20
    arc_0_3_4  connected_order_arc_355  -13
    arc_0_3_4  out_degree_595  1
    arc_0_3_4  in_degree_603  1
    arc_0_3_4  original_T_including_depot_unload_660  193.618232742121
    MARKER    'MARKER'                 'INTEND'
    load_0_3_4  arc_capacity_354  1
    load_0_3_4  segment_load_conservation_599  1
    load_0_3_4  segment_load_conservation_606  -1
    load_0_3_4  segment_prefix_lb_607  1
    load_0_3_4  segment_prefix_ub_608  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_12  arc_capacity_356  -20
    arc_0_3_12  connected_order_arc_357  -13
    arc_0_3_12  out_degree_595  1
    arc_0_3_12  in_degree_610  1
    arc_0_3_12  original_T_including_depot_unload_660  7.5480538147776406e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_12  arc_capacity_356  1
    load_0_3_12  segment_load_conservation_599  1
    load_0_3_12  free_load_conservation_614  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_13  arc_capacity_358  -20
    arc_0_3_13  connected_order_arc_359  -13
    arc_0_3_13  out_degree_595  1
    arc_0_3_13  in_degree_616  1
    arc_0_3_13  original_T_including_depot_unload_660  1.0452797846577832e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_13  arc_capacity_358  1
    load_0_3_13  segment_load_conservation_599  1
    load_0_3_13  free_load_conservation_620  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_14  arc_capacity_360  -20
    arc_0_3_14  connected_order_arc_361  -13
    arc_0_3_14  out_degree_595  1
    arc_0_3_14  in_degree_622  1
    arc_0_3_14  original_T_including_depot_unload_660  1.5968425841449753e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_14  arc_capacity_360  1
    load_0_3_14  segment_load_conservation_599  1
    load_0_3_14  free_load_conservation_626  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_15  arc_capacity_362  -20
    arc_0_3_15  connected_order_arc_363  -13
    arc_0_3_15  out_degree_595  1
    arc_0_3_15  in_degree_628  1
    arc_0_3_15  original_T_including_depot_unload_660  6.0704113403569352e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_15  arc_capacity_362  1
    load_0_3_15  segment_load_conservation_599  1
    load_0_3_15  free_load_conservation_632  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_16  arc_capacity_364  -20
    arc_0_3_16  connected_order_arc_365  -13
    arc_0_3_16  out_degree_595  1
    arc_0_3_16  in_degree_634  1
    arc_0_3_16  original_T_including_depot_unload_660  9.6906528258679839e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_16  arc_capacity_364  1
    load_0_3_16  segment_load_conservation_599  1
    load_0_3_16  free_load_conservation_638  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_17  arc_capacity_366  -20
    arc_0_3_17  connected_order_arc_367  -13
    arc_0_3_17  out_degree_595  1
    arc_0_3_17  in_degree_640  1
    arc_0_3_17  original_T_including_depot_unload_660  2.9898712977512486e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_17  arc_capacity_366  1
    load_0_3_17  segment_load_conservation_599  1
    load_0_3_17  free_load_conservation_644  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_18  arc_capacity_368  -20
    arc_0_3_18  connected_order_arc_369  -13
    arc_0_3_18  out_degree_595  1
    arc_0_3_18  in_degree_646  1
    arc_0_3_18  original_T_including_depot_unload_660  8.0582548325956611e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_18  arc_capacity_368  1
    load_0_3_18  segment_load_conservation_599  1
    load_0_3_18  free_load_conservation_650  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_19  arc_capacity_370  -20
    arc_0_3_19  connected_order_arc_371  -13
    arc_0_3_19  out_degree_595  1
    arc_0_3_19  in_degree_652  1
    arc_0_3_19  original_T_including_depot_unload_660  1.3208627731923268e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_19  arc_capacity_370  1
    load_0_3_19  segment_load_conservation_599  1
    load_0_3_19  free_load_conservation_656  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_0  arc_capacity_372  -20
    arc_0_4_0  depot_return_or_bypass_580  1
    arc_0_4_0  out_degree_602  1
    arc_0_4_0  original_T_including_depot_unload_660  3.6666597054112611e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_0  arc_capacity_372  1
    load_0_4_0  segment_load_conservation_606  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_1  arc_capacity_373  -20
    arc_0_4_1  connected_order_arc_374  -13
    arc_0_4_1  in_degree_582  1
    arc_0_4_1  out_degree_602  1
    arc_0_4_1  original_T_including_depot_unload_660  6.7806925965469873e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_1  arc_capacity_373  1
    load_0_4_1  segment_load_conservation_585  -1
    load_0_4_1  segment_prefix_lb_586  1
    load_0_4_1  segment_prefix_ub_587  1
    load_0_4_1  segment_load_conservation_606  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_2  arc_capacity_375  -20
    arc_0_4_2  connected_order_arc_376  -13
    arc_0_4_2  in_degree_589  1
    arc_0_4_2  out_degree_602  1
    arc_0_4_2  original_T_including_depot_unload_660  1.9614944290232185e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_2  arc_capacity_375  1
    load_0_4_2  segment_load_conservation_592  -1
    load_0_4_2  segment_prefix_lb_593  1
    load_0_4_2  segment_prefix_ub_594  1
    load_0_4_2  segment_load_conservation_606  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_3  arc_capacity_377  -20
    arc_0_4_3  connected_order_arc_378  -13
    arc_0_4_3  in_degree_596  1
    arc_0_4_3  out_degree_602  1
    arc_0_4_3  original_T_including_depot_unload_660  193.618232742121
    MARKER    'MARKER'                 'INTEND'
    load_0_4_3  arc_capacity_377  1
    load_0_4_3  segment_load_conservation_599  -1
    load_0_4_3  segment_prefix_lb_600  1
    load_0_4_3  segment_prefix_ub_601  1
    load_0_4_3  segment_load_conservation_606  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_12  arc_capacity_379  -20
    arc_0_4_12  connected_order_arc_380  -13
    arc_0_4_12  out_degree_602  1
    arc_0_4_12  in_degree_610  1
    arc_0_4_12  original_T_including_depot_unload_660  6.2502004715709484e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_12  arc_capacity_379  1
    load_0_4_12  segment_load_conservation_606  1
    load_0_4_12  free_load_conservation_614  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_13  arc_capacity_381  -20
    arc_0_4_13  connected_order_arc_382  -13
    arc_0_4_13  out_degree_602  1
    arc_0_4_13  in_degree_616  1
    arc_0_4_13  original_T_including_depot_unload_660  876.282348312514
    MARKER    'MARKER'                 'INTEND'
    load_0_4_13  arc_capacity_381  1
    load_0_4_13  segment_load_conservation_606  1
    load_0_4_13  free_load_conservation_620  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_14  arc_capacity_383  -20
    arc_0_4_14  connected_order_arc_384  -13
    arc_0_4_14  out_degree_602  1
    arc_0_4_14  in_degree_622  1
    arc_0_4_14  original_T_including_depot_unload_660  1.4066323818659139e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_14  arc_capacity_383  1
    load_0_4_14  segment_load_conservation_606  1
    load_0_4_14  free_load_conservation_626  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_15  arc_capacity_385  -20
    arc_0_4_15  connected_order_arc_386  -13
    arc_0_4_15  out_degree_602  1
    arc_0_4_15  in_degree_628  1
    arc_0_4_15  original_T_including_depot_unload_660  4.1343325097934911e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_15  arc_capacity_385  1
    load_0_4_15  segment_load_conservation_606  1
    load_0_4_15  free_load_conservation_632  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_16  arc_capacity_387  -20
    arc_0_4_16  connected_order_arc_388  -13
    arc_0_4_16  out_degree_602  1
    arc_0_4_16  in_degree_634  1
    arc_0_4_16  original_T_including_depot_unload_660  7.7620596437921665e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_16  arc_capacity_387  1
    load_0_4_16  segment_load_conservation_606  1
    load_0_4_16  free_load_conservation_638  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_17  arc_capacity_389  -20
    arc_0_4_17  connected_order_arc_390  -13
    arc_0_4_17  out_degree_602  1
    arc_0_4_17  in_degree_640  1
    arc_0_4_17  original_T_including_depot_unload_660  1.0605986491096120e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_17  arc_capacity_389  1
    load_0_4_17  segment_load_conservation_606  1
    load_0_4_17  free_load_conservation_644  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_18  arc_capacity_391  -20
    arc_0_4_18  connected_order_arc_392  -13
    arc_0_4_18  out_degree_602  1
    arc_0_4_18  in_degree_646  1
    arc_0_4_18  original_T_including_depot_unload_660  6.1271031593432815e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_18  arc_capacity_391  1
    load_0_4_18  segment_load_conservation_606  1
    load_0_4_18  free_load_conservation_650  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_19  arc_capacity_393  -20
    arc_0_4_19  connected_order_arc_394  -13
    arc_0_4_19  out_degree_602  1
    arc_0_4_19  in_degree_652  1
    arc_0_4_19  original_T_including_depot_unload_660  1.1724354239849338e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_19  arc_capacity_393  1
    load_0_4_19  segment_load_conservation_606  1
    load_0_4_19  free_load_conservation_656  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_0  arc_capacity_395  -20
    arc_0_12_0  depot_return_or_bypass_580  1
    arc_0_12_0  out_degree_609  1
    arc_0_12_0  original_T_including_depot_unload_660  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_0  arc_capacity_395  1
    load_0_12_0  free_load_conservation_614  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_1  arc_capacity_396  -20
    arc_0_12_1  connected_order_arc_397  -13
    arc_0_12_1  in_degree_582  1
    arc_0_12_1  out_degree_609  1
    arc_0_12_1  original_T_including_depot_unload_660  1.0660093540264595e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_1  arc_capacity_396  1
    load_0_12_1  segment_load_conservation_585  -1
    load_0_12_1  segment_prefix_lb_586  1
    load_0_12_1  segment_prefix_ub_587  1
    load_0_12_1  free_load_conservation_614  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_2  arc_capacity_398  -20
    arc_0_12_2  connected_order_arc_399  -13
    arc_0_12_2  in_degree_589  1
    arc_0_12_2  out_degree_609  1
    arc_0_12_2  original_T_including_depot_unload_660  7.5707648242091466e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_2  arc_capacity_398  1
    load_0_12_2  segment_load_conservation_592  -1
    load_0_12_2  segment_prefix_lb_593  1
    load_0_12_2  segment_prefix_ub_594  1
    load_0_12_2  free_load_conservation_614  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_3  arc_capacity_400  -20
    arc_0_12_3  connected_order_arc_401  -13
    arc_0_12_3  in_degree_596  1
    arc_0_12_3  out_degree_609  1
    arc_0_12_3  original_T_including_depot_unload_660  7.5480538147776406e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_3  arc_capacity_400  1
    load_0_12_3  segment_load_conservation_599  -1
    load_0_12_3  segment_prefix_lb_600  1
    load_0_12_3  segment_prefix_ub_601  1
    load_0_12_3  free_load_conservation_614  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_4  arc_capacity_402  -20
    arc_0_12_4  connected_order_arc_403  -13
    arc_0_12_4  in_degree_603  1
    arc_0_12_4  out_degree_609  1
    arc_0_12_4  original_T_including_depot_unload_660  6.2502004715709484e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_4  arc_capacity_402  1
    load_0_12_4  segment_load_conservation_606  -1
    load_0_12_4  segment_prefix_lb_607  1
    load_0_12_4  segment_prefix_ub_608  1
    load_0_12_4  free_load_conservation_614  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_13  arc_capacity_404  -20
    arc_0_12_13  connected_order_arc_405  -13
    arc_0_12_13  out_degree_609  1
    arc_0_12_13  in_degree_616  1
    arc_0_12_13  original_T_including_depot_unload_660  3.7831268047064754e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_13  arc_capacity_404  1
    load_0_12_13  free_load_conservation_614  1
    load_0_12_13  free_load_conservation_620  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_14  arc_capacity_406  -20
    arc_0_12_14  connected_order_arc_407  -13
    arc_0_12_14  out_degree_609  1
    arc_0_12_14  in_degree_622  1
    arc_0_12_14  original_T_including_depot_unload_660  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_14  arc_capacity_406  1
    load_0_12_14  free_load_conservation_614  1
    load_0_12_14  free_load_conservation_626  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_15  arc_capacity_408  -20
    arc_0_12_15  connected_order_arc_409  -13
    arc_0_12_15  out_degree_609  1
    arc_0_12_15  in_degree_628  1
    arc_0_12_15  original_T_including_depot_unload_660  5.0398976026149836e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_15  arc_capacity_408  1
    load_0_12_15  free_load_conservation_614  1
    load_0_12_15  free_load_conservation_632  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_16  arc_capacity_410  -20
    arc_0_12_16  connected_order_arc_411  -13
    arc_0_12_16  out_degree_609  1
    arc_0_12_16  in_degree_634  1
    arc_0_12_16  original_T_including_depot_unload_660  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_0_12_16  arc_capacity_410  1
    load_0_12_16  free_load_conservation_614  1
    load_0_12_16  free_load_conservation_638  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_17  arc_capacity_412  -20
    arc_0_12_17  connected_order_arc_413  -13
    arc_0_12_17  out_degree_609  1
    arc_0_12_17  in_degree_640  1
    arc_0_12_17  original_T_including_depot_unload_660  5.5668303114993182e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_17  arc_capacity_412  1
    load_0_12_17  free_load_conservation_614  1
    load_0_12_17  free_load_conservation_644  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_18  arc_capacity_414  -20
    arc_0_12_18  connected_order_arc_415  -13
    arc_0_12_18  out_degree_609  1
    arc_0_12_18  in_degree_646  1
    arc_0_12_18  original_T_including_depot_unload_660  608.963327854777
    MARKER    'MARKER'                 'INTEND'
    load_0_12_18  arc_capacity_414  1
    load_0_12_18  free_load_conservation_614  1
    load_0_12_18  free_load_conservation_650  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_19  arc_capacity_416  -20
    arc_0_12_19  connected_order_arc_417  -13
    arc_0_12_19  out_degree_609  1
    arc_0_12_19  in_degree_652  1
    arc_0_12_19  original_T_including_depot_unload_660  5.7276146581216926e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_19  arc_capacity_416  1
    load_0_12_19  free_load_conservation_614  1
    load_0_12_19  free_load_conservation_656  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_0  arc_capacity_418  -20
    arc_0_13_0  depot_return_or_bypass_580  1
    arc_0_13_0  out_degree_615  1
    arc_0_13_0  original_T_including_depot_unload_660  7.9650294035968375e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_0  arc_capacity_418  1
    load_0_13_0  free_load_conservation_620  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_1  arc_capacity_419  -20
    arc_0_13_1  connected_order_arc_420  -13
    arc_0_13_1  in_degree_582  1
    arc_0_13_1  out_degree_615  1
    arc_0_13_1  original_T_including_depot_unload_660  1.4208855669296320e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_1  arc_capacity_419  1
    load_0_13_1  segment_load_conservation_585  -1
    load_0_13_1  segment_prefix_lb_586  1
    load_0_13_1  segment_prefix_ub_587  1
    load_0_13_1  free_load_conservation_620  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_2  arc_capacity_421  -20
    arc_0_13_2  connected_order_arc_422  -13
    arc_0_13_2  in_degree_589  1
    arc_0_13_2  out_degree_615  1
    arc_0_13_2  original_T_including_depot_unload_660  1.0478069687959494e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_2  arc_capacity_421  1
    load_0_13_2  segment_load_conservation_592  -1
    load_0_13_2  segment_prefix_lb_593  1
    load_0_13_2  segment_prefix_ub_594  1
    load_0_13_2  free_load_conservation_620  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_3  arc_capacity_423  -20
    arc_0_13_3  connected_order_arc_424  -13
    arc_0_13_3  in_degree_596  1
    arc_0_13_3  out_degree_615  1
    arc_0_13_3  original_T_including_depot_unload_660  1.0452797846577832e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_3  arc_capacity_423  1
    load_0_13_3  segment_load_conservation_599  -1
    load_0_13_3  segment_prefix_lb_600  1
    load_0_13_3  segment_prefix_ub_601  1
    load_0_13_3  free_load_conservation_620  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_4  arc_capacity_425  -20
    arc_0_13_4  connected_order_arc_426  -13
    arc_0_13_4  in_degree_603  1
    arc_0_13_4  out_degree_615  1
    arc_0_13_4  original_T_including_depot_unload_660  876.282348312514
    MARKER    'MARKER'                 'INTEND'
    load_0_13_4  arc_capacity_425  1
    load_0_13_4  segment_load_conservation_606  -1
    load_0_13_4  segment_prefix_lb_607  1
    load_0_13_4  segment_prefix_ub_608  1
    load_0_13_4  free_load_conservation_620  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_12  arc_capacity_427  -20
    arc_0_13_12  connected_order_arc_428  -13
    arc_0_13_12  in_degree_610  1
    arc_0_13_12  out_degree_615  1
    arc_0_13_12  original_T_including_depot_unload_660  3.7831268047064754e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_12  arc_capacity_427  1
    load_0_13_12  free_load_conservation_614  -1
    load_0_13_12  free_load_conservation_620  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_14  arc_capacity_429  -20
    arc_0_13_14  connected_order_arc_430  -13
    arc_0_13_14  out_degree_615  1
    arc_0_13_14  in_degree_622  1
    arc_0_13_14  original_T_including_depot_unload_660  9.8108674361469946e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_14  arc_capacity_429  1
    load_0_13_14  free_load_conservation_620  1
    load_0_13_14  free_load_conservation_626  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_15  arc_capacity_431  -20
    arc_0_13_15  connected_order_arc_432  -13
    arc_0_13_15  out_degree_615  1
    arc_0_13_15  in_degree_628  1
    arc_0_13_15  original_T_including_depot_unload_660  566.256001718161
    MARKER    'MARKER'                 'INTEND'
    load_0_13_15  arc_capacity_431  1
    load_0_13_15  free_load_conservation_620  1
    load_0_13_15  free_load_conservation_632  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_16  arc_capacity_433  -20
    arc_0_13_16  connected_order_arc_434  -13
    arc_0_13_16  out_degree_615  1
    arc_0_13_16  in_degree_634  1
    arc_0_13_16  original_T_including_depot_unload_660  5.4405628017126674e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_16  arc_capacity_433  1
    load_0_13_16  free_load_conservation_620  1
    load_0_13_16  free_load_conservation_638  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_17  arc_capacity_435  -20
    arc_0_13_17  connected_order_arc_436  -13
    arc_0_13_17  out_degree_615  1
    arc_0_13_17  in_degree_640  1
    arc_0_13_17  original_T_including_depot_unload_660  7.8060605690718819e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_17  arc_capacity_435  1
    load_0_13_17  free_load_conservation_620  1
    load_0_13_17  free_load_conservation_644  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_18  arc_capacity_437  -20
    arc_0_13_18  connected_order_arc_438  -13
    arc_0_13_18  out_degree_615  1
    arc_0_13_18  in_degree_646  1
    arc_0_13_18  original_T_including_depot_unload_660  5.3348116005684176e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_18  arc_capacity_437  1
    load_0_13_18  free_load_conservation_620  1
    load_0_13_18  free_load_conservation_650  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_19  arc_capacity_439  -20
    arc_0_13_19  connected_order_arc_440  -13
    arc_0_13_19  out_degree_615  1
    arc_0_13_19  in_degree_652  1
    arc_0_13_19  original_T_including_depot_unload_660  3.5166546157461704e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_19  arc_capacity_439  1
    load_0_13_19  free_load_conservation_620  1
    load_0_13_19  free_load_conservation_656  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_0  arc_capacity_441  -20
    arc_0_14_0  depot_return_or_bypass_580  1
    arc_0_14_0  out_degree_621  1
    arc_0_14_0  original_T_including_depot_unload_660  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_0  arc_capacity_441  1
    load_0_14_0  free_load_conservation_626  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_1  arc_capacity_442  -20
    arc_0_14_1  connected_order_arc_443  -13
    arc_0_14_1  in_degree_582  1
    arc_0_14_1  out_degree_621  1
    arc_0_14_1  original_T_including_depot_unload_660  2.0832214111784192e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_1  arc_capacity_442  1
    load_0_14_1  segment_load_conservation_585  -1
    load_0_14_1  segment_prefix_lb_586  1
    load_0_14_1  segment_prefix_ub_587  1
    load_0_14_1  free_load_conservation_626  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_2  arc_capacity_444  -20
    arc_0_14_2  connected_order_arc_445  -13
    arc_0_14_2  in_degree_589  1
    arc_0_14_2  out_degree_621  1
    arc_0_14_2  original_T_including_depot_unload_660  1.5992308845216928e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_2  arc_capacity_444  1
    load_0_14_2  segment_load_conservation_592  -1
    load_0_14_2  segment_prefix_lb_593  1
    load_0_14_2  segment_prefix_ub_594  1
    load_0_14_2  free_load_conservation_626  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_3  arc_capacity_446  -20
    arc_0_14_3  connected_order_arc_447  -13
    arc_0_14_3  in_degree_596  1
    arc_0_14_3  out_degree_621  1
    arc_0_14_3  original_T_including_depot_unload_660  1.5968425841449753e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_3  arc_capacity_446  1
    load_0_14_3  segment_load_conservation_599  -1
    load_0_14_3  segment_prefix_lb_600  1
    load_0_14_3  segment_prefix_ub_601  1
    load_0_14_3  free_load_conservation_626  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_4  arc_capacity_448  -20
    arc_0_14_4  connected_order_arc_449  -13
    arc_0_14_4  in_degree_603  1
    arc_0_14_4  out_degree_621  1
    arc_0_14_4  original_T_including_depot_unload_660  1.4066323818659139e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_4  arc_capacity_448  1
    load_0_14_4  segment_load_conservation_606  -1
    load_0_14_4  segment_prefix_lb_607  1
    load_0_14_4  segment_prefix_ub_608  1
    load_0_14_4  free_load_conservation_626  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_12  arc_capacity_450  -20
    arc_0_14_12  connected_order_arc_451  -13
    arc_0_14_12  in_degree_610  1
    arc_0_14_12  out_degree_621  1
    arc_0_14_12  original_T_including_depot_unload_660  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_12  arc_capacity_450  1
    load_0_14_12  free_load_conservation_614  -1
    load_0_14_12  free_load_conservation_626  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_13  arc_capacity_452  -20
    arc_0_14_13  connected_order_arc_453  -13
    arc_0_14_13  in_degree_616  1
    arc_0_14_13  out_degree_621  1
    arc_0_14_13  original_T_including_depot_unload_660  9.8108674361469946e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_13  arc_capacity_452  1
    load_0_14_13  free_load_conservation_620  -1
    load_0_14_13  free_load_conservation_626  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_15  arc_capacity_454  -20
    arc_0_14_15  connected_order_arc_455  -13
    arc_0_14_15  out_degree_621  1
    arc_0_14_15  in_degree_628  1
    arc_0_14_15  original_T_including_depot_unload_660  1.0063298732365655e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_15  arc_capacity_454  1
    load_0_14_15  free_load_conservation_626  1
    load_0_14_15  free_load_conservation_632  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_16  arc_capacity_456  -20
    arc_0_14_16  connected_order_arc_457  -13
    arc_0_14_16  out_degree_621  1
    arc_0_14_16  in_degree_634  1
    arc_0_14_16  original_T_including_depot_unload_660  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_0_14_16  arc_capacity_456  1
    load_0_14_16  free_load_conservation_626  1
    load_0_14_16  free_load_conservation_638  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_17  arc_capacity_458  -20
    arc_0_14_17  connected_order_arc_459  -13
    arc_0_14_17  out_degree_621  1
    arc_0_14_17  in_degree_640  1
    arc_0_14_17  original_T_including_depot_unload_660  1.3072142379397485e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_17  arc_capacity_458  1
    load_0_14_17  free_load_conservation_626  1
    load_0_14_17  free_load_conservation_644  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_18  arc_capacity_460  -20
    arc_0_14_18  connected_order_arc_461  -13
    arc_0_14_18  out_degree_621  1
    arc_0_14_18  in_degree_646  1
    arc_0_14_18  original_T_including_depot_unload_660  8.0139063451811444e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_18  arc_capacity_460  1
    load_0_14_18  free_load_conservation_626  1
    load_0_14_18  free_load_conservation_650  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_19  arc_capacity_462  -20
    arc_0_14_19  connected_order_arc_463  -13
    arc_0_14_19  out_degree_621  1
    arc_0_14_19  in_degree_652  1
    arc_0_14_19  original_T_including_depot_unload_660  1.1967280409234234e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_19  arc_capacity_462  1
    load_0_14_19  free_load_conservation_626  1
    load_0_14_19  free_load_conservation_656  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_0  arc_capacity_464  -20
    arc_0_15_0  depot_return_or_bypass_580  1
    arc_0_15_0  out_degree_627  1
    arc_0_15_0  original_T_including_depot_unload_660  5.8421641813809208e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_0  arc_capacity_464  1
    load_0_15_0  free_load_conservation_632  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_1  arc_capacity_465  -20
    arc_0_15_1  connected_order_arc_466  -13
    arc_0_15_1  in_degree_582  1
    arc_0_15_1  out_degree_627  1
    arc_0_15_1  original_T_including_depot_unload_660  1.0804765714682671e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_1  arc_capacity_465  1
    load_0_15_1  segment_load_conservation_585  -1
    load_0_15_1  segment_prefix_lb_586  1
    load_0_15_1  segment_prefix_ub_587  1
    load_0_15_1  free_load_conservation_632  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_2  arc_capacity_467  -20
    arc_0_15_2  connected_order_arc_468  -13
    arc_0_15_2  in_degree_589  1
    arc_0_15_2  out_degree_627  1
    arc_0_15_2  original_T_including_depot_unload_660  6.0957665440032713e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_2  arc_capacity_467  1
    load_0_15_2  segment_load_conservation_592  -1
    load_0_15_2  segment_prefix_lb_593  1
    load_0_15_2  segment_prefix_ub_594  1
    load_0_15_2  free_load_conservation_632  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_3  arc_capacity_469  -20
    arc_0_15_3  connected_order_arc_470  -13
    arc_0_15_3  in_degree_596  1
    arc_0_15_3  out_degree_627  1
    arc_0_15_3  original_T_including_depot_unload_660  6.0704113403569352e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_3  arc_capacity_469  1
    load_0_15_3  segment_load_conservation_599  -1
    load_0_15_3  segment_prefix_lb_600  1
    load_0_15_3  segment_prefix_ub_601  1
    load_0_15_3  free_load_conservation_632  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_4  arc_capacity_471  -20
    arc_0_15_4  connected_order_arc_472  -13
    arc_0_15_4  in_degree_603  1
    arc_0_15_4  out_degree_627  1
    arc_0_15_4  original_T_including_depot_unload_660  4.1343325097934911e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_4  arc_capacity_471  1
    load_0_15_4  segment_load_conservation_606  -1
    load_0_15_4  segment_prefix_lb_607  1
    load_0_15_4  segment_prefix_ub_608  1
    load_0_15_4  free_load_conservation_632  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_12  arc_capacity_473  -20
    arc_0_15_12  connected_order_arc_474  -13
    arc_0_15_12  in_degree_610  1
    arc_0_15_12  out_degree_627  1
    arc_0_15_12  original_T_including_depot_unload_660  5.0398976026149836e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_12  arc_capacity_473  1
    load_0_15_12  free_load_conservation_614  -1
    load_0_15_12  free_load_conservation_632  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_13  arc_capacity_475  -20
    arc_0_15_13  connected_order_arc_476  -13
    arc_0_15_13  in_degree_616  1
    arc_0_15_13  out_degree_627  1
    arc_0_15_13  original_T_including_depot_unload_660  566.256001718161
    MARKER    'MARKER'                 'INTEND'
    load_0_15_13  arc_capacity_475  1
    load_0_15_13  free_load_conservation_620  -1
    load_0_15_13  free_load_conservation_632  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_14  arc_capacity_477  -20
    arc_0_15_14  connected_order_arc_478  -13
    arc_0_15_14  in_degree_622  1
    arc_0_15_14  out_degree_627  1
    arc_0_15_14  original_T_including_depot_unload_660  1.0063298732365655e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_14  arc_capacity_477  1
    load_0_15_14  free_load_conservation_626  -1
    load_0_15_14  free_load_conservation_632  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_16  arc_capacity_479  -20
    arc_0_15_16  connected_order_arc_480  -13
    arc_0_15_16  out_degree_627  1
    arc_0_15_16  in_degree_634  1
    arc_0_15_16  original_T_including_depot_unload_660  3.6822662782562685e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_16  arc_capacity_479  1
    load_0_15_16  free_load_conservation_632  1
    load_0_15_16  free_load_conservation_638  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_17  arc_capacity_481  -20
    arc_0_15_17  connected_order_arc_482  -13
    arc_0_15_17  out_degree_627  1
    arc_0_15_17  in_degree_640  1
    arc_0_15_17  original_T_including_depot_unload_660  308.565954837055
    MARKER    'MARKER'                 'INTEND'
    load_0_15_17  arc_capacity_481  1
    load_0_15_17  free_load_conservation_632  1
    load_0_15_17  free_load_conservation_644  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_18  arc_capacity_483  -20
    arc_0_15_18  connected_order_arc_484  -13
    arc_0_15_18  out_degree_627  1
    arc_0_15_18  in_degree_646  1
    arc_0_15_18  original_T_including_depot_unload_660  204.956380049771
    MARKER    'MARKER'                 'INTEND'
    load_0_15_18  arc_capacity_483  1
    load_0_15_18  free_load_conservation_632  1
    load_0_15_18  free_load_conservation_650  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_19  arc_capacity_485  -20
    arc_0_15_19  connected_order_arc_486  -13
    arc_0_15_19  out_degree_627  1
    arc_0_15_19  in_degree_652  1
    arc_0_15_19  original_T_including_depot_unload_660  9.0947747566405189e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_19  arc_capacity_485  1
    load_0_15_19  free_load_conservation_632  1
    load_0_15_19  free_load_conservation_656  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_0  arc_capacity_487  -20
    arc_0_16_0  depot_return_or_bypass_580  1
    arc_0_16_0  out_degree_633  1
    arc_0_16_0  original_T_including_depot_unload_660  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_0  arc_capacity_487  1
    load_0_16_0  free_load_conservation_638  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_1  arc_capacity_488  -20
    arc_0_16_1  connected_order_arc_489  -13
    arc_0_16_1  in_degree_582  1
    arc_0_16_1  out_degree_633  1
    arc_0_16_1  original_T_including_depot_unload_660  1.4482979064849126e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_1  arc_capacity_488  1
    load_0_16_1  segment_load_conservation_585  -1
    load_0_16_1  segment_prefix_lb_586  1
    load_0_16_1  segment_prefix_ub_587  1
    load_0_16_1  free_load_conservation_638  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_2  arc_capacity_490  -20
    arc_0_16_2  connected_order_arc_491  -13
    arc_0_16_2  in_degree_589  1
    arc_0_16_2  out_degree_633  1
    arc_0_16_2  original_T_including_depot_unload_660  9.7154140307447824e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_2  arc_capacity_490  1
    load_0_16_2  segment_load_conservation_592  -1
    load_0_16_2  segment_prefix_lb_593  1
    load_0_16_2  segment_prefix_ub_594  1
    load_0_16_2  free_load_conservation_638  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_3  arc_capacity_492  -20
    arc_0_16_3  connected_order_arc_493  -13
    arc_0_16_3  in_degree_596  1
    arc_0_16_3  out_degree_633  1
    arc_0_16_3  original_T_including_depot_unload_660  9.6906528258679839e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_3  arc_capacity_492  1
    load_0_16_3  segment_load_conservation_599  -1
    load_0_16_3  segment_prefix_lb_600  1
    load_0_16_3  segment_prefix_ub_601  1
    load_0_16_3  free_load_conservation_638  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_4  arc_capacity_494  -20
    arc_0_16_4  connected_order_arc_495  -13
    arc_0_16_4  in_degree_603  1
    arc_0_16_4  out_degree_633  1
    arc_0_16_4  original_T_including_depot_unload_660  7.7620596437921665e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_4  arc_capacity_494  1
    load_0_16_4  segment_load_conservation_606  -1
    load_0_16_4  segment_prefix_lb_607  1
    load_0_16_4  segment_prefix_ub_608  1
    load_0_16_4  free_load_conservation_638  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_12  arc_capacity_496  -20
    arc_0_16_12  connected_order_arc_497  -13
    arc_0_16_12  in_degree_610  1
    arc_0_16_12  out_degree_633  1
    arc_0_16_12  original_T_including_depot_unload_660  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_0_16_12  arc_capacity_496  1
    load_0_16_12  free_load_conservation_614  -1
    load_0_16_12  free_load_conservation_638  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_13  arc_capacity_498  -20
    arc_0_16_13  connected_order_arc_499  -13
    arc_0_16_13  in_degree_616  1
    arc_0_16_13  out_degree_633  1
    arc_0_16_13  original_T_including_depot_unload_660  5.4405628017126674e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_13  arc_capacity_498  1
    load_0_16_13  free_load_conservation_620  -1
    load_0_16_13  free_load_conservation_638  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_14  arc_capacity_500  -20
    arc_0_16_14  connected_order_arc_501  -13
    arc_0_16_14  in_degree_622  1
    arc_0_16_14  out_degree_633  1
    arc_0_16_14  original_T_including_depot_unload_660  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_0_16_14  arc_capacity_500  1
    load_0_16_14  free_load_conservation_626  -1
    load_0_16_14  free_load_conservation_638  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_15  arc_capacity_502  -20
    arc_0_16_15  connected_order_arc_503  -13
    arc_0_16_15  in_degree_628  1
    arc_0_16_15  out_degree_633  1
    arc_0_16_15  original_T_including_depot_unload_660  3.6822662782562685e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_15  arc_capacity_502  1
    load_0_16_15  free_load_conservation_632  -1
    load_0_16_15  free_load_conservation_638  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_17  arc_capacity_504  -20
    arc_0_16_17  connected_order_arc_505  -13
    arc_0_16_17  out_degree_633  1
    arc_0_16_17  in_degree_640  1
    arc_0_16_17  original_T_including_depot_unload_660  6.7368811350376711e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_17  arc_capacity_504  1
    load_0_16_17  free_load_conservation_638  1
    load_0_16_17  free_load_conservation_644  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_18  arc_capacity_506  -20
    arc_0_16_18  connected_order_arc_507  -13
    arc_0_16_18  out_degree_633  1
    arc_0_16_18  in_degree_646  1
    arc_0_16_18  original_T_including_depot_unload_660  1.6388081578301370e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_18  arc_capacity_506  1
    load_0_16_18  free_load_conservation_638  1
    load_0_16_18  free_load_conservation_650  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_19  arc_capacity_508  -20
    arc_0_16_19  connected_order_arc_509  -13
    arc_0_16_19  out_degree_633  1
    arc_0_16_19  in_degree_652  1
    arc_0_16_19  original_T_including_depot_unload_660  8.7906342149593650e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_19  arc_capacity_508  1
    load_0_16_19  free_load_conservation_638  1
    load_0_16_19  free_load_conservation_656  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_0  arc_capacity_510  -20
    arc_0_17_0  depot_return_or_bypass_580  1
    arc_0_17_0  out_degree_639  1
    arc_0_17_0  original_T_including_depot_unload_660  3.8060477410436619e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_0  arc_capacity_510  1
    load_0_17_0  free_load_conservation_644  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_1  arc_capacity_511  -20
    arc_0_17_1  connected_order_arc_512  -13
    arc_0_17_1  in_degree_582  1
    arc_0_17_1  out_degree_639  1
    arc_0_17_1  original_T_including_depot_unload_660  7.7600923635341769e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_1  arc_capacity_511  1
    load_0_17_1  segment_load_conservation_585  -1
    load_0_17_1  segment_prefix_lb_586  1
    load_0_17_1  segment_prefix_ub_587  1
    load_0_17_1  free_load_conservation_644  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_2  arc_capacity_513  -20
    arc_0_17_2  connected_order_arc_514  -13
    arc_0_17_2  in_degree_589  1
    arc_0_17_2  out_degree_639  1
    arc_0_17_2  original_T_including_depot_unload_660  3.0154417050280659e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_2  arc_capacity_513  1
    load_0_17_2  segment_load_conservation_592  -1
    load_0_17_2  segment_prefix_lb_593  1
    load_0_17_2  segment_prefix_ub_594  1
    load_0_17_2  free_load_conservation_644  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_3  arc_capacity_515  -20
    arc_0_17_3  connected_order_arc_516  -13
    arc_0_17_3  in_degree_596  1
    arc_0_17_3  out_degree_639  1
    arc_0_17_3  original_T_including_depot_unload_660  2.9898712977512486e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_3  arc_capacity_515  1
    load_0_17_3  segment_load_conservation_599  -1
    load_0_17_3  segment_prefix_lb_600  1
    load_0_17_3  segment_prefix_ub_601  1
    load_0_17_3  free_load_conservation_644  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_4  arc_capacity_517  -20
    arc_0_17_4  connected_order_arc_518  -13
    arc_0_17_4  in_degree_603  1
    arc_0_17_4  out_degree_639  1
    arc_0_17_4  original_T_including_depot_unload_660  1.0605986491096120e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_4  arc_capacity_517  1
    load_0_17_4  segment_load_conservation_606  -1
    load_0_17_4  segment_prefix_lb_607  1
    load_0_17_4  segment_prefix_ub_608  1
    load_0_17_4  free_load_conservation_644  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_12  arc_capacity_519  -20
    arc_0_17_12  connected_order_arc_520  -13
    arc_0_17_12  in_degree_610  1
    arc_0_17_12  out_degree_639  1
    arc_0_17_12  original_T_including_depot_unload_660  5.5668303114993182e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_12  arc_capacity_519  1
    load_0_17_12  free_load_conservation_614  -1
    load_0_17_12  free_load_conservation_644  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_13  arc_capacity_521  -20
    arc_0_17_13  connected_order_arc_522  -13
    arc_0_17_13  in_degree_616  1
    arc_0_17_13  out_degree_639  1
    arc_0_17_13  original_T_including_depot_unload_660  7.8060605690718819e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_13  arc_capacity_521  1
    load_0_17_13  free_load_conservation_620  -1
    load_0_17_13  free_load_conservation_644  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_14  arc_capacity_523  -20
    arc_0_17_14  connected_order_arc_524  -13
    arc_0_17_14  in_degree_622  1
    arc_0_17_14  out_degree_639  1
    arc_0_17_14  original_T_including_depot_unload_660  1.3072142379397485e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_14  arc_capacity_523  1
    load_0_17_14  free_load_conservation_626  -1
    load_0_17_14  free_load_conservation_644  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_15  arc_capacity_525  -20
    arc_0_17_15  connected_order_arc_526  -13
    arc_0_17_15  in_degree_628  1
    arc_0_17_15  out_degree_639  1
    arc_0_17_15  original_T_including_depot_unload_660  308.565954837055
    MARKER    'MARKER'                 'INTEND'
    load_0_17_15  arc_capacity_525  1
    load_0_17_15  free_load_conservation_632  -1
    load_0_17_15  free_load_conservation_644  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_16  arc_capacity_527  -20
    arc_0_17_16  connected_order_arc_528  -13
    arc_0_17_16  in_degree_634  1
    arc_0_17_16  out_degree_639  1
    arc_0_17_16  original_T_including_depot_unload_660  6.7368811350376711e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_16  arc_capacity_527  1
    load_0_17_16  free_load_conservation_638  -1
    load_0_17_16  free_load_conservation_644  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_18  arc_capacity_529  -20
    arc_0_17_18  connected_order_arc_530  -13
    arc_0_17_18  out_degree_639  1
    arc_0_17_18  in_degree_646  1
    arc_0_17_18  original_T_including_depot_unload_660  5.0986619729981788e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_18  arc_capacity_529  1
    load_0_17_18  free_load_conservation_644  1
    load_0_17_18  free_load_conservation_650  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_19  arc_capacity_531  -20
    arc_0_17_19  connected_order_arc_532  -13
    arc_0_17_19  out_degree_639  1
    arc_0_17_19  in_degree_652  1
    arc_0_17_19  original_T_including_depot_unload_660  1.0869859877715128e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_19  arc_capacity_531  1
    load_0_17_19  free_load_conservation_644  1
    load_0_17_19  free_load_conservation_656  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_0  arc_capacity_533  -20
    arc_0_18_0  depot_return_or_bypass_580  1
    arc_0_18_0  out_degree_645  1
    arc_0_18_0  original_T_including_depot_unload_660  778.011461754062
    MARKER    'MARKER'                 'INTEND'
    load_0_18_0  arc_capacity_533  1
    load_0_18_0  free_load_conservation_650  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_1  arc_capacity_534  -20
    arc_0_18_1  connected_order_arc_535  -13
    arc_0_18_1  in_degree_582  1
    arc_0_18_1  out_degree_645  1
    arc_0_18_1  original_T_including_depot_unload_660  1.2844696003118074e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_1  arc_capacity_534  1
    load_0_18_1  segment_load_conservation_585  -1
    load_0_18_1  segment_prefix_lb_586  1
    load_0_18_1  segment_prefix_ub_587  1
    load_0_18_1  free_load_conservation_650  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_2  arc_capacity_536  -20
    arc_0_18_2  connected_order_arc_537  -13
    arc_0_18_2  in_degree_589  1
    arc_0_18_2  out_degree_645  1
    arc_0_18_2  original_T_including_depot_unload_660  8.0831419223632781e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_2  arc_capacity_536  1
    load_0_18_2  segment_load_conservation_592  -1
    load_0_18_2  segment_prefix_lb_593  1
    load_0_18_2  segment_prefix_ub_594  1
    load_0_18_2  free_load_conservation_650  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_3  arc_capacity_538  -20
    arc_0_18_3  connected_order_arc_539  -13
    arc_0_18_3  in_degree_596  1
    arc_0_18_3  out_degree_645  1
    arc_0_18_3  original_T_including_depot_unload_660  8.0582548325956611e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_3  arc_capacity_538  1
    load_0_18_3  segment_load_conservation_599  -1
    load_0_18_3  segment_prefix_lb_600  1
    load_0_18_3  segment_prefix_ub_601  1
    load_0_18_3  free_load_conservation_650  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_4  arc_capacity_540  -20
    arc_0_18_4  connected_order_arc_541  -13
    arc_0_18_4  in_degree_603  1
    arc_0_18_4  out_degree_645  1
    arc_0_18_4  original_T_including_depot_unload_660  6.1271031593432815e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_4  arc_capacity_540  1
    load_0_18_4  segment_load_conservation_606  -1
    load_0_18_4  segment_prefix_lb_607  1
    load_0_18_4  segment_prefix_ub_608  1
    load_0_18_4  free_load_conservation_650  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_12  arc_capacity_542  -20
    arc_0_18_12  connected_order_arc_543  -13
    arc_0_18_12  in_degree_610  1
    arc_0_18_12  out_degree_645  1
    arc_0_18_12  original_T_including_depot_unload_660  608.963327854777
    MARKER    'MARKER'                 'INTEND'
    load_0_18_12  arc_capacity_542  1
    load_0_18_12  free_load_conservation_614  -1
    load_0_18_12  free_load_conservation_650  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_13  arc_capacity_544  -20
    arc_0_18_13  connected_order_arc_545  -13
    arc_0_18_13  in_degree_616  1
    arc_0_18_13  out_degree_645  1
    arc_0_18_13  original_T_including_depot_unload_660  5.3348116005684176e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_13  arc_capacity_544  1
    load_0_18_13  free_load_conservation_620  -1
    load_0_18_13  free_load_conservation_650  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_14  arc_capacity_546  -20
    arc_0_18_14  connected_order_arc_547  -13
    arc_0_18_14  in_degree_622  1
    arc_0_18_14  out_degree_645  1
    arc_0_18_14  original_T_including_depot_unload_660  8.0139063451811444e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_14  arc_capacity_546  1
    load_0_18_14  free_load_conservation_626  -1
    load_0_18_14  free_load_conservation_650  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_15  arc_capacity_548  -20
    arc_0_18_15  connected_order_arc_549  -13
    arc_0_18_15  in_degree_628  1
    arc_0_18_15  out_degree_645  1
    arc_0_18_15  original_T_including_depot_unload_660  204.956380049771
    MARKER    'MARKER'                 'INTEND'
    load_0_18_15  arc_capacity_548  1
    load_0_18_15  free_load_conservation_632  -1
    load_0_18_15  free_load_conservation_650  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_16  arc_capacity_550  -20
    arc_0_18_16  connected_order_arc_551  -13
    arc_0_18_16  in_degree_634  1
    arc_0_18_16  out_degree_645  1
    arc_0_18_16  original_T_including_depot_unload_660  1.6388081578301370e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_16  arc_capacity_550  1
    load_0_18_16  free_load_conservation_638  -1
    load_0_18_16  free_load_conservation_650  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_17  arc_capacity_552  -20
    arc_0_18_17  connected_order_arc_553  -13
    arc_0_18_17  in_degree_640  1
    arc_0_18_17  out_degree_645  1
    arc_0_18_17  original_T_including_depot_unload_660  5.0986619729981788e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_17  arc_capacity_552  1
    load_0_18_17  free_load_conservation_644  -1
    load_0_18_17  free_load_conservation_650  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_19  arc_capacity_554  -20
    arc_0_18_19  connected_order_arc_555  -13
    arc_0_18_19  out_degree_645  1
    arc_0_18_19  in_degree_652  1
    arc_0_18_19  original_T_including_depot_unload_660  8.8427037135592116e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_19  arc_capacity_554  1
    load_0_18_19  free_load_conservation_650  1
    load_0_18_19  free_load_conservation_656  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_0  arc_capacity_556  -20
    arc_0_19_0  depot_return_or_bypass_580  1
    arc_0_19_0  out_degree_651  1
    arc_0_19_0  original_T_including_depot_unload_660  1.0056399980521732e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_0  arc_capacity_556  1
    load_0_19_0  free_load_conservation_656  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_1  arc_capacity_557  -20
    arc_0_19_1  connected_order_arc_558  -13
    arc_0_19_1  in_degree_582  1
    arc_0_19_1  out_degree_651  1
    arc_0_19_1  original_T_including_depot_unload_660  1.6289794123513827e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_1  arc_capacity_557  1
    load_0_19_1  segment_load_conservation_585  -1
    load_0_19_1  segment_prefix_lb_586  1
    load_0_19_1  segment_prefix_ub_587  1
    load_0_19_1  free_load_conservation_656  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_2  arc_capacity_559  -20
    arc_0_19_2  connected_order_arc_560  -13
    arc_0_19_2  in_degree_589  1
    arc_0_19_2  out_degree_651  1
    arc_0_19_2  original_T_including_depot_unload_660  1.3232349913962587e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_2  arc_capacity_559  1
    load_0_19_2  segment_load_conservation_592  -1
    load_0_19_2  segment_prefix_lb_593  1
    load_0_19_2  segment_prefix_ub_594  1
    load_0_19_2  free_load_conservation_656  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_3  arc_capacity_561  -20
    arc_0_19_3  connected_order_arc_562  -13
    arc_0_19_3  in_degree_596  1
    arc_0_19_3  out_degree_651  1
    arc_0_19_3  original_T_including_depot_unload_660  1.3208627731923268e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_3  arc_capacity_561  1
    load_0_19_3  segment_load_conservation_599  -1
    load_0_19_3  segment_prefix_lb_600  1
    load_0_19_3  segment_prefix_ub_601  1
    load_0_19_3  free_load_conservation_656  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_4  arc_capacity_563  -20
    arc_0_19_4  connected_order_arc_564  -13
    arc_0_19_4  in_degree_603  1
    arc_0_19_4  out_degree_651  1
    arc_0_19_4  original_T_including_depot_unload_660  1.1724354239849338e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_4  arc_capacity_563  1
    load_0_19_4  segment_load_conservation_606  -1
    load_0_19_4  segment_prefix_lb_607  1
    load_0_19_4  segment_prefix_ub_608  1
    load_0_19_4  free_load_conservation_656  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_12  arc_capacity_565  -20
    arc_0_19_12  connected_order_arc_566  -13
    arc_0_19_12  in_degree_610  1
    arc_0_19_12  out_degree_651  1
    arc_0_19_12  original_T_including_depot_unload_660  5.7276146581216926e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_12  arc_capacity_565  1
    load_0_19_12  free_load_conservation_614  -1
    load_0_19_12  free_load_conservation_656  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_13  arc_capacity_567  -20
    arc_0_19_13  connected_order_arc_568  -13
    arc_0_19_13  in_degree_616  1
    arc_0_19_13  out_degree_651  1
    arc_0_19_13  original_T_including_depot_unload_660  3.5166546157461704e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_13  arc_capacity_567  1
    load_0_19_13  free_load_conservation_620  -1
    load_0_19_13  free_load_conservation_656  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_14  arc_capacity_569  -20
    arc_0_19_14  connected_order_arc_570  -13
    arc_0_19_14  in_degree_622  1
    arc_0_19_14  out_degree_651  1
    arc_0_19_14  original_T_including_depot_unload_660  1.1967280409234234e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_14  arc_capacity_569  1
    load_0_19_14  free_load_conservation_626  -1
    load_0_19_14  free_load_conservation_656  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_15  arc_capacity_571  -20
    arc_0_19_15  connected_order_arc_572  -13
    arc_0_19_15  in_degree_628  1
    arc_0_19_15  out_degree_651  1
    arc_0_19_15  original_T_including_depot_unload_660  9.0947747566405189e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_15  arc_capacity_571  1
    load_0_19_15  free_load_conservation_632  -1
    load_0_19_15  free_load_conservation_656  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_16  arc_capacity_573  -20
    arc_0_19_16  connected_order_arc_574  -13
    arc_0_19_16  in_degree_634  1
    arc_0_19_16  out_degree_651  1
    arc_0_19_16  original_T_including_depot_unload_660  8.7906342149593650e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_16  arc_capacity_573  1
    load_0_19_16  free_load_conservation_638  -1
    load_0_19_16  free_load_conservation_656  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_17  arc_capacity_575  -20
    arc_0_19_17  connected_order_arc_576  -13
    arc_0_19_17  in_degree_640  1
    arc_0_19_17  out_degree_651  1
    arc_0_19_17  original_T_including_depot_unload_660  1.0869859877715128e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_17  arc_capacity_575  1
    load_0_19_17  free_load_conservation_644  -1
    load_0_19_17  free_load_conservation_656  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_18  arc_capacity_577  -20
    arc_0_19_18  connected_order_arc_578  -13
    arc_0_19_18  in_degree_646  1
    arc_0_19_18  out_degree_651  1
    arc_0_19_18  original_T_including_depot_unload_660  8.8427037135592116e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_18  arc_capacity_577  1
    load_0_19_18  free_load_conservation_650  -1
    load_0_19_18  free_load_conservation_656  1
    visit_1_5  out_degree_952  -1
    visit_1_5  in_degree_953  -1
    visit_1_5  order_active_lb_954  -1
    visit_1_5  order_active_ub_955  -12
    order_1_5  connected_order_arc_676  -1
    order_1_5  connected_order_arc_678  -1
    order_1_5  connected_order_arc_680  -1
    order_1_5  connected_order_arc_682  -1
    order_1_5  connected_order_arc_684  -1
    order_1_5  connected_order_arc_686  -1
    order_1_5  connected_order_arc_688  -1
    order_1_5  connected_order_arc_690  -1
    order_1_5  connected_order_arc_692  -1
    order_1_5  connected_order_arc_694  -1
    order_1_5  connected_order_arc_696  -1
    order_1_5  connected_order_arc_699  1
    order_1_5  connected_order_arc_722  1
    order_1_5  connected_order_arc_745  1
    order_1_5  connected_order_arc_768  1
    order_1_5  connected_order_arc_791  1
    order_1_5  connected_order_arc_814  1
    order_1_5  connected_order_arc_837  1
    order_1_5  connected_order_arc_860  1
    order_1_5  connected_order_arc_883  1
    order_1_5  connected_order_arc_906  1
    order_1_5  connected_order_arc_929  1
    order_1_5  order_active_lb_954  1
    order_1_5  order_active_ub_955  1
    order_1_5  fixed_segment_relative_order_1028  -1
    visit_1_6  out_degree_959  -1
    visit_1_6  in_degree_960  -1
    visit_1_6  order_active_lb_961  -1
    visit_1_6  order_active_ub_962  -12
    order_1_6  connected_order_arc_676  1
    order_1_6  connected_order_arc_699  -1
    order_1_6  connected_order_arc_701  -1
    order_1_6  connected_order_arc_703  -1
    order_1_6  connected_order_arc_705  -1
    order_1_6  connected_order_arc_707  -1
    order_1_6  connected_order_arc_709  -1
    order_1_6  connected_order_arc_711  -1
    order_1_6  connected_order_arc_713  -1
    order_1_6  connected_order_arc_715  -1
    order_1_6  connected_order_arc_717  -1
    order_1_6  connected_order_arc_719  -1
    order_1_6  connected_order_arc_724  1
    order_1_6  connected_order_arc_747  1
    order_1_6  connected_order_arc_770  1
    order_1_6  connected_order_arc_793  1
    order_1_6  connected_order_arc_816  1
    order_1_6  connected_order_arc_839  1
    order_1_6  connected_order_arc_862  1
    order_1_6  connected_order_arc_885  1
    order_1_6  connected_order_arc_908  1
    order_1_6  connected_order_arc_931  1
    order_1_6  order_active_lb_961  1
    order_1_6  order_active_ub_962  1
    order_1_6  fixed_segment_relative_order_1028  1
    order_1_6  fixed_segment_relative_order_1029  -1
    visit_1_7  out_degree_966  -1
    visit_1_7  in_degree_967  -1
    visit_1_7  order_active_lb_968  -1
    visit_1_7  order_active_ub_969  -12
    order_1_7  connected_order_arc_678  1
    order_1_7  connected_order_arc_701  1
    order_1_7  connected_order_arc_722  -1
    order_1_7  connected_order_arc_724  -1
    order_1_7  connected_order_arc_726  -1
    order_1_7  connected_order_arc_728  -1
    order_1_7  connected_order_arc_730  -1
    order_1_7  connected_order_arc_732  -1
    order_1_7  connected_order_arc_734  -1
    order_1_7  connected_order_arc_736  -1
    order_1_7  connected_order_arc_738  -1
    order_1_7  connected_order_arc_740  -1
    order_1_7  connected_order_arc_742  -1
    order_1_7  connected_order_arc_749  1
    order_1_7  connected_order_arc_772  1
    order_1_7  connected_order_arc_795  1
    order_1_7  connected_order_arc_818  1
    order_1_7  connected_order_arc_841  1
    order_1_7  connected_order_arc_864  1
    order_1_7  connected_order_arc_887  1
    order_1_7  connected_order_arc_910  1
    order_1_7  connected_order_arc_933  1
    order_1_7  order_active_lb_968  1
    order_1_7  order_active_ub_969  1
    order_1_7  fixed_segment_relative_order_1029  1
    order_1_7  fixed_segment_relative_order_1030  -1
    visit_1_8  out_degree_973  -1
    visit_1_8  in_degree_974  -1
    visit_1_8  order_active_lb_975  -1
    visit_1_8  order_active_ub_976  -12
    order_1_8  connected_order_arc_680  1
    order_1_8  connected_order_arc_703  1
    order_1_8  connected_order_arc_726  1
    order_1_8  connected_order_arc_745  -1
    order_1_8  connected_order_arc_747  -1
    order_1_8  connected_order_arc_749  -1
    order_1_8  connected_order_arc_751  -1
    order_1_8  connected_order_arc_753  -1
    order_1_8  connected_order_arc_755  -1
    order_1_8  connected_order_arc_757  -1
    order_1_8  connected_order_arc_759  -1
    order_1_8  connected_order_arc_761  -1
    order_1_8  connected_order_arc_763  -1
    order_1_8  connected_order_arc_765  -1
    order_1_8  connected_order_arc_774  1
    order_1_8  connected_order_arc_797  1
    order_1_8  connected_order_arc_820  1
    order_1_8  connected_order_arc_843  1
    order_1_8  connected_order_arc_866  1
    order_1_8  connected_order_arc_889  1
    order_1_8  connected_order_arc_912  1
    order_1_8  connected_order_arc_935  1
    order_1_8  order_active_lb_975  1
    order_1_8  order_active_ub_976  1
    order_1_8  fixed_segment_relative_order_1030  1
    visit_1_12  out_degree_980  -1
    visit_1_12  in_degree_981  -1
    visit_1_12  order_active_lb_982  -1
    visit_1_12  order_active_ub_983  -12
    visit_1_12  service_visit_def_984  -1
    order_1_12  connected_order_arc_682  1
    order_1_12  connected_order_arc_705  1
    order_1_12  connected_order_arc_728  1
    order_1_12  connected_order_arc_751  1
    order_1_12  connected_order_arc_768  -1
    order_1_12  connected_order_arc_770  -1
    order_1_12  connected_order_arc_772  -1
    order_1_12  connected_order_arc_774  -1
    order_1_12  connected_order_arc_776  -1
    order_1_12  connected_order_arc_778  -1
    order_1_12  connected_order_arc_780  -1
    order_1_12  connected_order_arc_782  -1
    order_1_12  connected_order_arc_784  -1
    order_1_12  connected_order_arc_786  -1
    order_1_12  connected_order_arc_788  -1
    order_1_12  connected_order_arc_799  1
    order_1_12  connected_order_arc_822  1
    order_1_12  connected_order_arc_845  1
    order_1_12  connected_order_arc_868  1
    order_1_12  connected_order_arc_891  1
    order_1_12  connected_order_arc_914  1
    order_1_12  connected_order_arc_937  1
    order_1_12  order_active_lb_982  1
    order_1_12  order_active_ub_983  1
    visit_1_13  out_degree_986  -1
    visit_1_13  in_degree_987  -1
    visit_1_13  order_active_lb_988  -1
    visit_1_13  order_active_ub_989  -12
    visit_1_13  service_visit_def_990  -1
    order_1_13  connected_order_arc_684  1
    order_1_13  connected_order_arc_707  1
    order_1_13  connected_order_arc_730  1
    order_1_13  connected_order_arc_753  1
    order_1_13  connected_order_arc_776  1
    order_1_13  connected_order_arc_791  -1
    order_1_13  connected_order_arc_793  -1
    order_1_13  connected_order_arc_795  -1
    order_1_13  connected_order_arc_797  -1
    order_1_13  connected_order_arc_799  -1
    order_1_13  connected_order_arc_801  -1
    order_1_13  connected_order_arc_803  -1
    order_1_13  connected_order_arc_805  -1
    order_1_13  connected_order_arc_807  -1
    order_1_13  connected_order_arc_809  -1
    order_1_13  connected_order_arc_811  -1
    order_1_13  connected_order_arc_824  1
    order_1_13  connected_order_arc_847  1
    order_1_13  connected_order_arc_870  1
    order_1_13  connected_order_arc_893  1
    order_1_13  connected_order_arc_916  1
    order_1_13  connected_order_arc_939  1
    order_1_13  order_active_lb_988  1
    order_1_13  order_active_ub_989  1
    visit_1_14  out_degree_992  -1
    visit_1_14  in_degree_993  -1
    visit_1_14  order_active_lb_994  -1
    visit_1_14  order_active_ub_995  -12
    visit_1_14  service_visit_def_996  -1
    order_1_14  connected_order_arc_686  1
    order_1_14  connected_order_arc_709  1
    order_1_14  connected_order_arc_732  1
    order_1_14  connected_order_arc_755  1
    order_1_14  connected_order_arc_778  1
    order_1_14  connected_order_arc_801  1
    order_1_14  connected_order_arc_814  -1
    order_1_14  connected_order_arc_816  -1
    order_1_14  connected_order_arc_818  -1
    order_1_14  connected_order_arc_820  -1
    order_1_14  connected_order_arc_822  -1
    order_1_14  connected_order_arc_824  -1
    order_1_14  connected_order_arc_826  -1
    order_1_14  connected_order_arc_828  -1
    order_1_14  connected_order_arc_830  -1
    order_1_14  connected_order_arc_832  -1
    order_1_14  connected_order_arc_834  -1
    order_1_14  connected_order_arc_849  1
    order_1_14  connected_order_arc_872  1
    order_1_14  connected_order_arc_895  1
    order_1_14  connected_order_arc_918  1
    order_1_14  connected_order_arc_941  1
    order_1_14  order_active_lb_994  1
    order_1_14  order_active_ub_995  1
    visit_1_15  out_degree_998  -1
    visit_1_15  in_degree_999  -1
    visit_1_15  order_active_lb_1000  -1
    visit_1_15  order_active_ub_1001  -12
    visit_1_15  service_visit_def_1002  -1
    order_1_15  connected_order_arc_688  1
    order_1_15  connected_order_arc_711  1
    order_1_15  connected_order_arc_734  1
    order_1_15  connected_order_arc_757  1
    order_1_15  connected_order_arc_780  1
    order_1_15  connected_order_arc_803  1
    order_1_15  connected_order_arc_826  1
    order_1_15  connected_order_arc_837  -1
    order_1_15  connected_order_arc_839  -1
    order_1_15  connected_order_arc_841  -1
    order_1_15  connected_order_arc_843  -1
    order_1_15  connected_order_arc_845  -1
    order_1_15  connected_order_arc_847  -1
    order_1_15  connected_order_arc_849  -1
    order_1_15  connected_order_arc_851  -1
    order_1_15  connected_order_arc_853  -1
    order_1_15  connected_order_arc_855  -1
    order_1_15  connected_order_arc_857  -1
    order_1_15  connected_order_arc_874  1
    order_1_15  connected_order_arc_897  1
    order_1_15  connected_order_arc_920  1
    order_1_15  connected_order_arc_943  1
    order_1_15  order_active_lb_1000  1
    order_1_15  order_active_ub_1001  1
    visit_1_16  out_degree_1004  -1
    visit_1_16  in_degree_1005  -1
    visit_1_16  order_active_lb_1006  -1
    visit_1_16  order_active_ub_1007  -12
    visit_1_16  service_visit_def_1008  -1
    order_1_16  connected_order_arc_690  1
    order_1_16  connected_order_arc_713  1
    order_1_16  connected_order_arc_736  1
    order_1_16  connected_order_arc_759  1
    order_1_16  connected_order_arc_782  1
    order_1_16  connected_order_arc_805  1
    order_1_16  connected_order_arc_828  1
    order_1_16  connected_order_arc_851  1
    order_1_16  connected_order_arc_860  -1
    order_1_16  connected_order_arc_862  -1
    order_1_16  connected_order_arc_864  -1
    order_1_16  connected_order_arc_866  -1
    order_1_16  connected_order_arc_868  -1
    order_1_16  connected_order_arc_870  -1
    order_1_16  connected_order_arc_872  -1
    order_1_16  connected_order_arc_874  -1
    order_1_16  connected_order_arc_876  -1
    order_1_16  connected_order_arc_878  -1
    order_1_16  connected_order_arc_880  -1
    order_1_16  connected_order_arc_899  1
    order_1_16  connected_order_arc_922  1
    order_1_16  connected_order_arc_945  1
    order_1_16  order_active_lb_1006  1
    order_1_16  order_active_ub_1007  1
    visit_1_17  out_degree_1010  -1
    visit_1_17  in_degree_1011  -1
    visit_1_17  order_active_lb_1012  -1
    visit_1_17  order_active_ub_1013  -12
    visit_1_17  service_visit_def_1014  -1
    order_1_17  connected_order_arc_692  1
    order_1_17  connected_order_arc_715  1
    order_1_17  connected_order_arc_738  1
    order_1_17  connected_order_arc_761  1
    order_1_17  connected_order_arc_784  1
    order_1_17  connected_order_arc_807  1
    order_1_17  connected_order_arc_830  1
    order_1_17  connected_order_arc_853  1
    order_1_17  connected_order_arc_876  1
    order_1_17  connected_order_arc_883  -1
    order_1_17  connected_order_arc_885  -1
    order_1_17  connected_order_arc_887  -1
    order_1_17  connected_order_arc_889  -1
    order_1_17  connected_order_arc_891  -1
    order_1_17  connected_order_arc_893  -1
    order_1_17  connected_order_arc_895  -1
    order_1_17  connected_order_arc_897  -1
    order_1_17  connected_order_arc_899  -1
    order_1_17  connected_order_arc_901  -1
    order_1_17  connected_order_arc_903  -1
    order_1_17  connected_order_arc_924  1
    order_1_17  connected_order_arc_947  1
    order_1_17  order_active_lb_1012  1
    order_1_17  order_active_ub_1013  1
    visit_1_18  out_degree_1016  -1
    visit_1_18  in_degree_1017  -1
    visit_1_18  order_active_lb_1018  -1
    visit_1_18  order_active_ub_1019  -12
    visit_1_18  service_visit_def_1020  -1
    order_1_18  connected_order_arc_694  1
    order_1_18  connected_order_arc_717  1
    order_1_18  connected_order_arc_740  1
    order_1_18  connected_order_arc_763  1
    order_1_18  connected_order_arc_786  1
    order_1_18  connected_order_arc_809  1
    order_1_18  connected_order_arc_832  1
    order_1_18  connected_order_arc_855  1
    order_1_18  connected_order_arc_878  1
    order_1_18  connected_order_arc_901  1
    order_1_18  connected_order_arc_906  -1
    order_1_18  connected_order_arc_908  -1
    order_1_18  connected_order_arc_910  -1
    order_1_18  connected_order_arc_912  -1
    order_1_18  connected_order_arc_914  -1
    order_1_18  connected_order_arc_916  -1
    order_1_18  connected_order_arc_918  -1
    order_1_18  connected_order_arc_920  -1
    order_1_18  connected_order_arc_922  -1
    order_1_18  connected_order_arc_924  -1
    order_1_18  connected_order_arc_926  -1
    order_1_18  connected_order_arc_949  1
    order_1_18  order_active_lb_1018  1
    order_1_18  order_active_ub_1019  1
    visit_1_19  out_degree_1022  -1
    visit_1_19  in_degree_1023  -1
    visit_1_19  order_active_lb_1024  -1
    visit_1_19  order_active_ub_1025  -12
    visit_1_19  service_visit_def_1026  -1
    order_1_19  connected_order_arc_696  1
    order_1_19  connected_order_arc_719  1
    order_1_19  connected_order_arc_742  1
    order_1_19  connected_order_arc_765  1
    order_1_19  connected_order_arc_788  1
    order_1_19  connected_order_arc_811  1
    order_1_19  connected_order_arc_834  1
    order_1_19  connected_order_arc_857  1
    order_1_19  connected_order_arc_880  1
    order_1_19  connected_order_arc_903  1
    order_1_19  connected_order_arc_926  1
    order_1_19  connected_order_arc_929  -1
    order_1_19  connected_order_arc_931  -1
    order_1_19  connected_order_arc_933  -1
    order_1_19  connected_order_arc_935  -1
    order_1_19  connected_order_arc_937  -1
    order_1_19  connected_order_arc_939  -1
    order_1_19  connected_order_arc_941  -1
    order_1_19  connected_order_arc_943  -1
    order_1_19  connected_order_arc_945  -1
    order_1_19  connected_order_arc_947  -1
    order_1_19  connected_order_arc_949  -1
    order_1_19  order_active_lb_1024  1
    order_1_19  order_active_ub_1025  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_0  arc_capacity_661  -25
    arc_1_0_0  depot_departure_or_bypass_950  1
    arc_1_0_0  depot_return_or_bypass_951  1
    MARKER    'MARKER'                 'INTEND'
    load_1_0_0  arc_capacity_661  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_5  arc_capacity_662  -25
    arc_1_0_5  depot_departure_or_bypass_950  1
    arc_1_0_5  in_degree_953  1
    arc_1_0_5  original_T_including_depot_unload_1031  1.1935953747864173e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_5  arc_capacity_662  1
    load_1_0_5  segment_load_conservation_956  -1
    load_1_0_5  segment_prefix_lb_957  1
    load_1_0_5  segment_prefix_ub_958  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_6  arc_capacity_663  -25
    arc_1_0_6  depot_departure_or_bypass_950  1
    arc_1_0_6  in_degree_960  1
    arc_1_0_6  original_T_including_depot_unload_1031  1.4834116102542102e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_6  arc_capacity_663  1
    load_1_0_6  segment_load_conservation_963  -1
    load_1_0_6  segment_prefix_lb_964  1
    load_1_0_6  segment_prefix_ub_965  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_7  arc_capacity_664  -25
    arc_1_0_7  depot_departure_or_bypass_950  1
    arc_1_0_7  in_degree_967  1
    arc_1_0_7  original_T_including_depot_unload_1031  5.4911852608328161e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_7  arc_capacity_664  1
    load_1_0_7  segment_load_conservation_970  -1
    load_1_0_7  segment_prefix_lb_971  1
    load_1_0_7  segment_prefix_ub_972  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_8  arc_capacity_665  -25
    arc_1_0_8  depot_departure_or_bypass_950  1
    arc_1_0_8  in_degree_974  1
    arc_1_0_8  original_T_including_depot_unload_1031  3.5061909388980052e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_8  arc_capacity_665  1
    load_1_0_8  segment_load_conservation_977  -1
    load_1_0_8  segment_prefix_lb_978  1
    load_1_0_8  segment_prefix_ub_979  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_12  arc_capacity_666  -25
    arc_1_0_12  depot_departure_or_bypass_950  1
    arc_1_0_12  in_degree_981  1
    arc_1_0_12  original_T_including_depot_unload_1031  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_12  arc_capacity_666  1
    load_1_0_12  free_load_conservation_985  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_13  arc_capacity_667  -25
    arc_1_0_13  depot_departure_or_bypass_950  1
    arc_1_0_13  in_degree_987  1
    arc_1_0_13  original_T_including_depot_unload_1031  7.9650294035968375e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_13  arc_capacity_667  1
    load_1_0_13  free_load_conservation_991  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_14  arc_capacity_668  -25
    arc_1_0_14  depot_departure_or_bypass_950  1
    arc_1_0_14  in_degree_993  1
    arc_1_0_14  original_T_including_depot_unload_1031  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_14  arc_capacity_668  1
    load_1_0_14  free_load_conservation_997  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_15  arc_capacity_669  -25
    arc_1_0_15  depot_departure_or_bypass_950  1
    arc_1_0_15  in_degree_999  1
    arc_1_0_15  original_T_including_depot_unload_1031  5.8421641813809208e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_15  arc_capacity_669  1
    load_1_0_15  free_load_conservation_1003  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_16  arc_capacity_670  -25
    arc_1_0_16  depot_departure_or_bypass_950  1
    arc_1_0_16  in_degree_1005  1
    arc_1_0_16  original_T_including_depot_unload_1031  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_16  arc_capacity_670  1
    load_1_0_16  free_load_conservation_1009  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_17  arc_capacity_671  -25
    arc_1_0_17  depot_departure_or_bypass_950  1
    arc_1_0_17  in_degree_1011  1
    arc_1_0_17  original_T_including_depot_unload_1031  3.8060477410436619e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_17  arc_capacity_671  1
    load_1_0_17  free_load_conservation_1015  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_18  arc_capacity_672  -25
    arc_1_0_18  depot_departure_or_bypass_950  1
    arc_1_0_18  in_degree_1017  1
    arc_1_0_18  original_T_including_depot_unload_1031  778.011461754062
    MARKER    'MARKER'                 'INTEND'
    load_1_0_18  arc_capacity_672  1
    load_1_0_18  free_load_conservation_1021  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_19  arc_capacity_673  -25
    arc_1_0_19  depot_departure_or_bypass_950  1
    arc_1_0_19  in_degree_1023  1
    arc_1_0_19  original_T_including_depot_unload_1031  1.0056399980521732e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_19  arc_capacity_673  1
    load_1_0_19  free_load_conservation_1027  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_0  arc_capacity_674  -25
    arc_1_5_0  depot_return_or_bypass_951  1
    arc_1_5_0  out_degree_952  1
    arc_1_5_0  original_T_including_depot_unload_1031  1.1935953747864173e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_0  arc_capacity_674  1
    load_1_5_0  segment_load_conservation_956  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_6  arc_capacity_675  -25
    arc_1_5_6  connected_order_arc_676  -13
    arc_1_5_6  out_degree_952  1
    arc_1_5_6  in_degree_960  1
    arc_1_5_6  original_T_including_depot_unload_1031  2.1016283653335277e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_6  arc_capacity_675  1
    load_1_5_6  segment_load_conservation_956  1
    load_1_5_6  segment_load_conservation_963  -1
    load_1_5_6  segment_prefix_lb_964  1
    load_1_5_6  segment_prefix_ub_965  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_7  arc_capacity_677  -25
    arc_1_5_7  connected_order_arc_678  -13
    arc_1_5_7  out_degree_952  1
    arc_1_5_7  in_degree_967  1
    arc_1_5_7  original_T_including_depot_unload_1031  1.2739580769060942e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_7  arc_capacity_677  1
    load_1_5_7  segment_load_conservation_956  1
    load_1_5_7  segment_load_conservation_970  -1
    load_1_5_7  segment_prefix_lb_971  1
    load_1_5_7  segment_prefix_ub_972  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_8  arc_capacity_679  -25
    arc_1_5_8  connected_order_arc_680  -13
    arc_1_5_8  out_degree_952  1
    arc_1_5_8  in_degree_974  1
    arc_1_5_8  original_T_including_depot_unload_1031  1.0313568965059917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_8  arc_capacity_679  1
    load_1_5_8  segment_load_conservation_956  1
    load_1_5_8  segment_load_conservation_977  -1
    load_1_5_8  segment_prefix_lb_978  1
    load_1_5_8  segment_prefix_ub_979  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_12  arc_capacity_681  -25
    arc_1_5_12  connected_order_arc_682  -13
    arc_1_5_12  out_degree_952  1
    arc_1_5_12  in_degree_981  1
    arc_1_5_12  original_T_including_depot_unload_1031  1.0321140782598593e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_12  arc_capacity_681  1
    load_1_5_12  segment_load_conservation_956  1
    load_1_5_12  free_load_conservation_985  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_13  arc_capacity_683  -25
    arc_1_5_13  connected_order_arc_684  -13
    arc_1_5_13  out_degree_952  1
    arc_1_5_13  in_degree_987  1
    arc_1_5_13  original_T_including_depot_unload_1031  1.1851786693030479e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_13  arc_capacity_683  1
    load_1_5_13  segment_load_conservation_956  1
    load_1_5_13  free_load_conservation_991  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_14  arc_capacity_685  -25
    arc_1_5_14  connected_order_arc_686  -13
    arc_1_5_14  out_degree_952  1
    arc_1_5_14  in_degree_993  1
    arc_1_5_14  original_T_including_depot_unload_1031  2.1501600514850211e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_14  arc_capacity_685  1
    load_1_5_14  segment_load_conservation_956  1
    load_1_5_14  free_load_conservation_997  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_15  arc_capacity_687  -25
    arc_1_5_15  connected_order_arc_688  -13
    arc_1_5_15  out_degree_952  1
    arc_1_5_15  in_degree_999  1
    arc_1_5_15  original_T_including_depot_unload_1031  1.5356438916798834e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_15  arc_capacity_687  1
    load_1_5_15  segment_load_conservation_956  1
    load_1_5_15  free_load_conservation_1003  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_16  arc_capacity_689  -25
    arc_1_5_16  connected_order_arc_690  -13
    arc_1_5_16  out_degree_952  1
    arc_1_5_16  in_degree_1005  1
    arc_1_5_16  original_T_including_depot_unload_1031  1.6988291947636669e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_16  arc_capacity_689  1
    load_1_5_16  segment_load_conservation_956  1
    load_1_5_16  free_load_conservation_1009  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_17  arc_capacity_691  -25
    arc_1_5_17  connected_order_arc_692  -13
    arc_1_5_17  out_degree_952  1
    arc_1_5_17  in_degree_1011  1
    arc_1_5_17  original_T_including_depot_unload_1031  1.5168242190367512e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_17  arc_capacity_691  1
    load_1_5_17  segment_load_conservation_956  1
    load_1_5_17  free_load_conservation_1015  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_18  arc_capacity_693  -25
    arc_1_5_18  connected_order_arc_694  -13
    arc_1_5_18  out_degree_952  1
    arc_1_5_18  in_degree_1017  1
    arc_1_5_18  original_T_including_depot_unload_1031  1.6274520107532360e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_18  arc_capacity_693  1
    load_1_5_18  segment_load_conservation_956  1
    load_1_5_18  free_load_conservation_1021  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_19  arc_capacity_695  -25
    arc_1_5_19  connected_order_arc_696  -13
    arc_1_5_19  out_degree_952  1
    arc_1_5_19  in_degree_1023  1
    arc_1_5_19  original_T_including_depot_unload_1031  9.7357850164388731e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_5_19  arc_capacity_695  1
    load_1_5_19  segment_load_conservation_956  1
    load_1_5_19  free_load_conservation_1027  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_0  arc_capacity_697  -25
    arc_1_6_0  depot_return_or_bypass_951  1
    arc_1_6_0  out_degree_959  1
    arc_1_6_0  original_T_including_depot_unload_1031  1.4834116102542102e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_0  arc_capacity_697  1
    load_1_6_0  segment_load_conservation_963  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_5  arc_capacity_698  -25
    arc_1_6_5  connected_order_arc_699  -13
    arc_1_6_5  in_degree_953  1
    arc_1_6_5  out_degree_959  1
    arc_1_6_5  original_T_including_depot_unload_1031  2.1016283653335277e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_5  arc_capacity_698  1
    load_1_6_5  segment_load_conservation_956  -1
    load_1_6_5  segment_prefix_lb_957  1
    load_1_6_5  segment_prefix_ub_958  1
    load_1_6_5  segment_load_conservation_963  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_7  arc_capacity_700  -25
    arc_1_6_7  connected_order_arc_701  -13
    arc_1_6_7  out_degree_959  1
    arc_1_6_7  in_degree_967  1
    arc_1_6_7  original_T_including_depot_unload_1031  9.7352441264247466e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_7  arc_capacity_700  1
    load_1_6_7  segment_load_conservation_963  1
    load_1_6_7  segment_load_conservation_970  -1
    load_1_6_7  segment_prefix_lb_971  1
    load_1_6_7  segment_prefix_ub_972  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_8  arc_capacity_702  -25
    arc_1_6_8  connected_order_arc_703  -13
    arc_1_6_8  out_degree_959  1
    arc_1_6_8  in_degree_974  1
    arc_1_6_8  original_T_including_depot_unload_1031  1.2769578074048923e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_8  arc_capacity_702  1
    load_1_6_8  segment_load_conservation_963  1
    load_1_6_8  segment_load_conservation_977  -1
    load_1_6_8  segment_prefix_lb_978  1
    load_1_6_8  segment_prefix_ub_979  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_12  arc_capacity_704  -25
    arc_1_6_12  connected_order_arc_705  -13
    arc_1_6_12  out_degree_959  1
    arc_1_6_12  in_degree_981  1
    arc_1_6_12  original_T_including_depot_unload_1031  1.9029099398713563e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_12  arc_capacity_704  1
    load_1_6_12  segment_load_conservation_963  1
    load_1_6_12  free_load_conservation_985  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_13  arc_capacity_706  -25
    arc_1_6_13  connected_order_arc_707  -13
    arc_1_6_13  out_degree_959  1
    arc_1_6_13  in_degree_987  1
    arc_1_6_13  original_T_including_depot_unload_1031  2.2758084421049020e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_13  arc_capacity_706  1
    load_1_6_13  segment_load_conservation_963  1
    load_1_6_13  free_load_conservation_991  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_14  arc_capacity_708  -25
    arc_1_6_14  connected_order_arc_709  -13
    arc_1_6_14  out_degree_959  1
    arc_1_6_14  in_degree_993  1
    arc_1_6_14  original_T_including_depot_unload_1031  2.9790156048453791e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_14  arc_capacity_708  1
    load_1_6_14  segment_load_conservation_963  1
    load_1_6_14  free_load_conservation_997  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_15  arc_capacity_710  -25
    arc_1_6_15  connected_order_arc_711  -13
    arc_1_6_15  out_degree_959  1
    arc_1_6_15  in_degree_999  1
    arc_1_6_15  original_T_including_depot_unload_1031  1.9765601995118598e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_15  arc_capacity_710  1
    load_1_6_15  segment_load_conservation_963  1
    load_1_6_15  free_load_conservation_1003  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_16  arc_capacity_712  -25
    arc_1_6_16  connected_order_arc_713  -13
    arc_1_6_16  out_degree_959  1
    arc_1_6_16  in_degree_1005  1
    arc_1_6_16  original_T_including_depot_unload_1031  2.3444750474890211e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_16  arc_capacity_712  1
    load_1_6_16  segment_load_conservation_963  1
    load_1_6_16  free_load_conservation_1009  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_17  arc_capacity_714  -25
    arc_1_6_17  connected_order_arc_715  -13
    arc_1_6_17  out_degree_959  1
    arc_1_6_17  in_degree_1011  1
    arc_1_6_17  original_T_including_depot_unload_1031  1.6719633410042259e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_17  arc_capacity_714  1
    load_1_6_17  segment_load_conservation_963  1
    load_1_6_17  free_load_conservation_1015  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_18  arc_capacity_716  -25
    arc_1_6_18  connected_order_arc_717  -13
    arc_1_6_18  out_degree_959  1
    arc_1_6_18  in_degree_1017  1
    arc_1_6_18  original_T_including_depot_unload_1031  2.1806564621513235e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_18  arc_capacity_716  1
    load_1_6_18  segment_load_conservation_963  1
    load_1_6_18  free_load_conservation_1021  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_19  arc_capacity_718  -25
    arc_1_6_19  connected_order_arc_719  -13
    arc_1_6_19  out_degree_959  1
    arc_1_6_19  in_degree_1023  1
    arc_1_6_19  original_T_including_depot_unload_1031  2.4304747035816213e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_19  arc_capacity_718  1
    load_1_6_19  segment_load_conservation_963  1
    load_1_6_19  free_load_conservation_1027  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_0  arc_capacity_720  -25
    arc_1_7_0  depot_return_or_bypass_951  1
    arc_1_7_0  out_degree_966  1
    arc_1_7_0  original_T_including_depot_unload_1031  5.4911852608328161e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_0  arc_capacity_720  1
    load_1_7_0  segment_load_conservation_970  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_5  arc_capacity_721  -25
    arc_1_7_5  connected_order_arc_722  -13
    arc_1_7_5  in_degree_953  1
    arc_1_7_5  out_degree_966  1
    arc_1_7_5  original_T_including_depot_unload_1031  1.2739580769060942e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_5  arc_capacity_721  1
    load_1_7_5  segment_load_conservation_956  -1
    load_1_7_5  segment_prefix_lb_957  1
    load_1_7_5  segment_prefix_ub_958  1
    load_1_7_5  segment_load_conservation_970  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_6  arc_capacity_723  -25
    arc_1_7_6  connected_order_arc_724  -13
    arc_1_7_6  in_degree_960  1
    arc_1_7_6  out_degree_966  1
    arc_1_7_6  original_T_including_depot_unload_1031  9.7352441264247466e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_6  arc_capacity_723  1
    load_1_7_6  segment_load_conservation_963  -1
    load_1_7_6  segment_prefix_lb_964  1
    load_1_7_6  segment_prefix_ub_965  1
    load_1_7_6  segment_load_conservation_970  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_8  arc_capacity_725  -25
    arc_1_7_8  connected_order_arc_726  -13
    arc_1_7_8  out_degree_966  1
    arc_1_7_8  in_degree_974  1
    arc_1_7_8  original_T_including_depot_unload_1031  3.0614301781508658e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_8  arc_capacity_725  1
    load_1_7_8  segment_load_conservation_970  1
    load_1_7_8  segment_load_conservation_977  -1
    load_1_7_8  segment_prefix_lb_978  1
    load_1_7_8  segment_prefix_ub_979  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_12  arc_capacity_727  -25
    arc_1_7_12  connected_order_arc_728  -13
    arc_1_7_12  out_degree_966  1
    arc_1_7_12  in_degree_981  1
    arc_1_7_12  original_T_including_depot_unload_1031  9.3836915476275669e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_12  arc_capacity_727  1
    load_1_7_12  segment_load_conservation_970  1
    load_1_7_12  free_load_conservation_985  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_13  arc_capacity_729  -25
    arc_1_7_13  connected_order_arc_730  -13
    arc_1_7_13  out_degree_966  1
    arc_1_7_13  in_degree_987  1
    arc_1_7_13  original_T_including_depot_unload_1031  1.3156708792004563e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_13  arc_capacity_729  1
    load_1_7_13  segment_load_conservation_970  1
    load_1_7_13  free_load_conservation_991  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_14  arc_capacity_731  -25
    arc_1_7_14  connected_order_arc_732  -13
    arc_1_7_14  out_degree_966  1
    arc_1_7_14  in_degree_993  1
    arc_1_7_14  original_T_including_depot_unload_1031  2.1109553693139742e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_14  arc_capacity_731  1
    load_1_7_14  segment_load_conservation_970  1
    load_1_7_14  free_load_conservation_997  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_15  arc_capacity_733  -25
    arc_1_7_15  connected_order_arc_734  -13
    arc_1_7_15  out_degree_966  1
    arc_1_7_15  in_degree_999  1
    arc_1_7_15  original_T_including_depot_unload_1031  1.1150690045767951e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_15  arc_capacity_733  1
    load_1_7_15  segment_load_conservation_970  1
    load_1_7_15  free_load_conservation_1003  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_16  arc_capacity_735  -25
    arc_1_7_16  connected_order_arc_736  -13
    arc_1_7_16  out_degree_966  1
    arc_1_7_16  in_degree_1005  1
    arc_1_7_16  original_T_including_depot_unload_1031  1.4738339199468992e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_16  arc_capacity_735  1
    load_1_7_16  segment_load_conservation_970  1
    load_1_7_16  free_load_conservation_1009  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_17  arc_capacity_737  -25
    arc_1_7_17  connected_order_arc_738  -13
    arc_1_7_17  out_degree_966  1
    arc_1_7_17  in_degree_1011  1
    arc_1_7_17  original_T_including_depot_unload_1031  8.4865162627289658e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_17  arc_capacity_737  1
    load_1_7_17  segment_load_conservation_970  1
    load_1_7_17  free_load_conservation_1015  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_18  arc_capacity_739  -25
    arc_1_7_18  connected_order_arc_740  -13
    arc_1_7_18  out_degree_966  1
    arc_1_7_18  in_degree_1017  1
    arc_1_7_18  original_T_including_depot_unload_1031  1.3162040688959055e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_18  arc_capacity_739  1
    load_1_7_18  segment_load_conservation_970  1
    load_1_7_18  free_load_conservation_1021  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_19  arc_capacity_741  -25
    arc_1_7_19  connected_order_arc_742  -13
    arc_1_7_19  out_degree_966  1
    arc_1_7_19  in_degree_1023  1
    arc_1_7_19  original_T_including_depot_unload_1031  1.4570094449922669e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_19  arc_capacity_741  1
    load_1_7_19  segment_load_conservation_970  1
    load_1_7_19  free_load_conservation_1027  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_0  arc_capacity_743  -25
    arc_1_8_0  depot_return_or_bypass_951  1
    arc_1_8_0  out_degree_973  1
    arc_1_8_0  original_T_including_depot_unload_1031  3.5061909388980052e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_0  arc_capacity_743  1
    load_1_8_0  segment_load_conservation_977  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_5  arc_capacity_744  -25
    arc_1_8_5  connected_order_arc_745  -13
    arc_1_8_5  in_degree_953  1
    arc_1_8_5  out_degree_973  1
    arc_1_8_5  original_T_including_depot_unload_1031  1.0313568965059917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_5  arc_capacity_744  1
    load_1_8_5  segment_load_conservation_956  -1
    load_1_8_5  segment_prefix_lb_957  1
    load_1_8_5  segment_prefix_ub_958  1
    load_1_8_5  segment_load_conservation_977  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_6  arc_capacity_746  -25
    arc_1_8_6  connected_order_arc_747  -13
    arc_1_8_6  in_degree_960  1
    arc_1_8_6  out_degree_973  1
    arc_1_8_6  original_T_including_depot_unload_1031  1.2769578074048923e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_6  arc_capacity_746  1
    load_1_8_6  segment_load_conservation_963  -1
    load_1_8_6  segment_prefix_lb_964  1
    load_1_8_6  segment_prefix_ub_965  1
    load_1_8_6  segment_load_conservation_977  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_7  arc_capacity_748  -25
    arc_1_8_7  connected_order_arc_749  -13
    arc_1_8_7  in_degree_967  1
    arc_1_8_7  out_degree_973  1
    arc_1_8_7  original_T_including_depot_unload_1031  3.0614301781508658e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_7  arc_capacity_748  1
    load_1_8_7  segment_load_conservation_970  -1
    load_1_8_7  segment_prefix_lb_971  1
    load_1_8_7  segment_prefix_ub_972  1
    load_1_8_7  segment_load_conservation_977  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_12  arc_capacity_750  -25
    arc_1_8_12  connected_order_arc_751  -13
    arc_1_8_12  out_degree_973  1
    arc_1_8_12  in_degree_981  1
    arc_1_8_12  original_T_including_depot_unload_1031  6.5869285599668615e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_12  arc_capacity_750  1
    load_1_8_12  segment_load_conservation_977  1
    load_1_8_12  free_load_conservation_985  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_13  arc_capacity_752  -25
    arc_1_8_13  connected_order_arc_753  -13
    arc_1_8_13  out_degree_973  1
    arc_1_8_13  in_degree_987  1
    arc_1_8_13  original_T_including_depot_unload_1031  1.0363838262442744e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_13  arc_capacity_752  1
    load_1_8_13  segment_load_conservation_977  1
    load_1_8_13  free_load_conservation_991  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_14  arc_capacity_754  -25
    arc_1_8_14  connected_order_arc_755  -13
    arc_1_8_14  out_degree_973  1
    arc_1_8_14  in_degree_993  1
    arc_1_8_14  original_T_including_depot_unload_1031  1.8911324761641883e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_14  arc_capacity_754  1
    load_1_8_14  segment_load_conservation_977  1
    load_1_8_14  free_load_conservation_997  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_15  arc_capacity_756  -25
    arc_1_8_15  connected_order_arc_757  -13
    arc_1_8_15  out_degree_973  1
    arc_1_8_15  in_degree_999  1
    arc_1_8_15  original_T_including_depot_unload_1031  9.3137133767849343e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_15  arc_capacity_756  1
    load_1_8_15  segment_load_conservation_977  1
    load_1_8_15  free_load_conservation_1003  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_16  arc_capacity_758  -25
    arc_1_8_16  connected_order_arc_759  -13
    arc_1_8_16  out_degree_973  1
    arc_1_8_16  in_degree_1005  1
    arc_1_8_16  original_T_including_depot_unload_1031  1.2665309635243570e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_16  arc_capacity_758  1
    load_1_8_16  segment_load_conservation_977  1
    load_1_8_16  free_load_conservation_1009  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_17  arc_capacity_760  -25
    arc_1_8_17  connected_order_arc_761  -13
    arc_1_8_17  out_degree_973  1
    arc_1_8_17  in_degree_1011  1
    arc_1_8_17  original_T_including_depot_unload_1031  7.2196448570394080e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_17  arc_capacity_760  1
    load_1_8_17  segment_load_conservation_977  1
    load_1_8_17  free_load_conservation_1015  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_18  arc_capacity_762  -25
    arc_1_8_18  connected_order_arc_763  -13
    arc_1_8_18  out_degree_973  1
    arc_1_8_18  in_degree_1017  1
    arc_1_8_18  original_T_including_depot_unload_1031  1.1193870869231816e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_18  arc_capacity_762  1
    load_1_8_18  segment_load_conservation_977  1
    load_1_8_18  free_load_conservation_1021  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_19  arc_capacity_764  -25
    arc_1_8_19  connected_order_arc_765  -13
    arc_1_8_19  out_degree_973  1
    arc_1_8_19  in_degree_1023  1
    arc_1_8_19  original_T_including_depot_unload_1031  1.1545648513745866e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_19  arc_capacity_764  1
    load_1_8_19  segment_load_conservation_977  1
    load_1_8_19  free_load_conservation_1027  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_0  arc_capacity_766  -25
    arc_1_12_0  depot_return_or_bypass_951  1
    arc_1_12_0  out_degree_980  1
    arc_1_12_0  original_T_including_depot_unload_1031  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_0  arc_capacity_766  1
    load_1_12_0  free_load_conservation_985  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_5  arc_capacity_767  -25
    arc_1_12_5  connected_order_arc_768  -13
    arc_1_12_5  in_degree_953  1
    arc_1_12_5  out_degree_980  1
    arc_1_12_5  original_T_including_depot_unload_1031  1.0321140782598593e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_5  arc_capacity_767  1
    load_1_12_5  segment_load_conservation_956  -1
    load_1_12_5  segment_prefix_lb_957  1
    load_1_12_5  segment_prefix_ub_958  1
    load_1_12_5  free_load_conservation_985  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_6  arc_capacity_769  -25
    arc_1_12_6  connected_order_arc_770  -13
    arc_1_12_6  in_degree_960  1
    arc_1_12_6  out_degree_980  1
    arc_1_12_6  original_T_including_depot_unload_1031  1.9029099398713563e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_6  arc_capacity_769  1
    load_1_12_6  segment_load_conservation_963  -1
    load_1_12_6  segment_prefix_lb_964  1
    load_1_12_6  segment_prefix_ub_965  1
    load_1_12_6  free_load_conservation_985  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_7  arc_capacity_771  -25
    arc_1_12_7  connected_order_arc_772  -13
    arc_1_12_7  in_degree_967  1
    arc_1_12_7  out_degree_980  1
    arc_1_12_7  original_T_including_depot_unload_1031  9.3836915476275669e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_7  arc_capacity_771  1
    load_1_12_7  segment_load_conservation_970  -1
    load_1_12_7  segment_prefix_lb_971  1
    load_1_12_7  segment_prefix_ub_972  1
    load_1_12_7  free_load_conservation_985  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_8  arc_capacity_773  -25
    arc_1_12_8  connected_order_arc_774  -13
    arc_1_12_8  in_degree_974  1
    arc_1_12_8  out_degree_980  1
    arc_1_12_8  original_T_including_depot_unload_1031  6.5869285599668615e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_8  arc_capacity_773  1
    load_1_12_8  segment_load_conservation_977  -1
    load_1_12_8  segment_prefix_lb_978  1
    load_1_12_8  segment_prefix_ub_979  1
    load_1_12_8  free_load_conservation_985  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_13  arc_capacity_775  -25
    arc_1_12_13  connected_order_arc_776  -13
    arc_1_12_13  out_degree_980  1
    arc_1_12_13  in_degree_987  1
    arc_1_12_13  original_T_including_depot_unload_1031  3.7831268047064754e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_13  arc_capacity_775  1
    load_1_12_13  free_load_conservation_985  1
    load_1_12_13  free_load_conservation_991  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_14  arc_capacity_777  -25
    arc_1_12_14  connected_order_arc_778  -13
    arc_1_12_14  out_degree_980  1
    arc_1_12_14  in_degree_993  1
    arc_1_12_14  original_T_including_depot_unload_1031  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_14  arc_capacity_777  1
    load_1_12_14  free_load_conservation_985  1
    load_1_12_14  free_load_conservation_997  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_15  arc_capacity_779  -25
    arc_1_12_15  connected_order_arc_780  -13
    arc_1_12_15  out_degree_980  1
    arc_1_12_15  in_degree_999  1
    arc_1_12_15  original_T_including_depot_unload_1031  5.0398976026149836e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_15  arc_capacity_779  1
    load_1_12_15  free_load_conservation_985  1
    load_1_12_15  free_load_conservation_1003  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_16  arc_capacity_781  -25
    arc_1_12_16  connected_order_arc_782  -13
    arc_1_12_16  out_degree_980  1
    arc_1_12_16  in_degree_1005  1
    arc_1_12_16  original_T_including_depot_unload_1031  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_1_12_16  arc_capacity_781  1
    load_1_12_16  free_load_conservation_985  1
    load_1_12_16  free_load_conservation_1009  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_17  arc_capacity_783  -25
    arc_1_12_17  connected_order_arc_784  -13
    arc_1_12_17  out_degree_980  1
    arc_1_12_17  in_degree_1011  1
    arc_1_12_17  original_T_including_depot_unload_1031  5.5668303114993182e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_17  arc_capacity_783  1
    load_1_12_17  free_load_conservation_985  1
    load_1_12_17  free_load_conservation_1015  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_18  arc_capacity_785  -25
    arc_1_12_18  connected_order_arc_786  -13
    arc_1_12_18  out_degree_980  1
    arc_1_12_18  in_degree_1017  1
    arc_1_12_18  original_T_including_depot_unload_1031  608.963327854777
    MARKER    'MARKER'                 'INTEND'
    load_1_12_18  arc_capacity_785  1
    load_1_12_18  free_load_conservation_985  1
    load_1_12_18  free_load_conservation_1021  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_19  arc_capacity_787  -25
    arc_1_12_19  connected_order_arc_788  -13
    arc_1_12_19  out_degree_980  1
    arc_1_12_19  in_degree_1023  1
    arc_1_12_19  original_T_including_depot_unload_1031  5.7276146581216926e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_19  arc_capacity_787  1
    load_1_12_19  free_load_conservation_985  1
    load_1_12_19  free_load_conservation_1027  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_0  arc_capacity_789  -25
    arc_1_13_0  depot_return_or_bypass_951  1
    arc_1_13_0  out_degree_986  1
    arc_1_13_0  original_T_including_depot_unload_1031  7.9650294035968375e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_0  arc_capacity_789  1
    load_1_13_0  free_load_conservation_991  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_5  arc_capacity_790  -25
    arc_1_13_5  connected_order_arc_791  -13
    arc_1_13_5  in_degree_953  1
    arc_1_13_5  out_degree_986  1
    arc_1_13_5  original_T_including_depot_unload_1031  1.1851786693030479e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_5  arc_capacity_790  1
    load_1_13_5  segment_load_conservation_956  -1
    load_1_13_5  segment_prefix_lb_957  1
    load_1_13_5  segment_prefix_ub_958  1
    load_1_13_5  free_load_conservation_991  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_6  arc_capacity_792  -25
    arc_1_13_6  connected_order_arc_793  -13
    arc_1_13_6  in_degree_960  1
    arc_1_13_6  out_degree_986  1
    arc_1_13_6  original_T_including_depot_unload_1031  2.2758084421049020e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_6  arc_capacity_792  1
    load_1_13_6  segment_load_conservation_963  -1
    load_1_13_6  segment_prefix_lb_964  1
    load_1_13_6  segment_prefix_ub_965  1
    load_1_13_6  free_load_conservation_991  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_7  arc_capacity_794  -25
    arc_1_13_7  connected_order_arc_795  -13
    arc_1_13_7  in_degree_967  1
    arc_1_13_7  out_degree_986  1
    arc_1_13_7  original_T_including_depot_unload_1031  1.3156708792004563e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_7  arc_capacity_794  1
    load_1_13_7  segment_load_conservation_970  -1
    load_1_13_7  segment_prefix_lb_971  1
    load_1_13_7  segment_prefix_ub_972  1
    load_1_13_7  free_load_conservation_991  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_8  arc_capacity_796  -25
    arc_1_13_8  connected_order_arc_797  -13
    arc_1_13_8  in_degree_974  1
    arc_1_13_8  out_degree_986  1
    arc_1_13_8  original_T_including_depot_unload_1031  1.0363838262442744e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_8  arc_capacity_796  1
    load_1_13_8  segment_load_conservation_977  -1
    load_1_13_8  segment_prefix_lb_978  1
    load_1_13_8  segment_prefix_ub_979  1
    load_1_13_8  free_load_conservation_991  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_12  arc_capacity_798  -25
    arc_1_13_12  connected_order_arc_799  -13
    arc_1_13_12  in_degree_981  1
    arc_1_13_12  out_degree_986  1
    arc_1_13_12  original_T_including_depot_unload_1031  3.7831268047064754e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_12  arc_capacity_798  1
    load_1_13_12  free_load_conservation_985  -1
    load_1_13_12  free_load_conservation_991  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_14  arc_capacity_800  -25
    arc_1_13_14  connected_order_arc_801  -13
    arc_1_13_14  out_degree_986  1
    arc_1_13_14  in_degree_993  1
    arc_1_13_14  original_T_including_depot_unload_1031  9.8108674361469946e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_14  arc_capacity_800  1
    load_1_13_14  free_load_conservation_991  1
    load_1_13_14  free_load_conservation_997  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_15  arc_capacity_802  -25
    arc_1_13_15  connected_order_arc_803  -13
    arc_1_13_15  out_degree_986  1
    arc_1_13_15  in_degree_999  1
    arc_1_13_15  original_T_including_depot_unload_1031  566.256001718161
    MARKER    'MARKER'                 'INTEND'
    load_1_13_15  arc_capacity_802  1
    load_1_13_15  free_load_conservation_991  1
    load_1_13_15  free_load_conservation_1003  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_16  arc_capacity_804  -25
    arc_1_13_16  connected_order_arc_805  -13
    arc_1_13_16  out_degree_986  1
    arc_1_13_16  in_degree_1005  1
    arc_1_13_16  original_T_including_depot_unload_1031  5.4405628017126674e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_16  arc_capacity_804  1
    load_1_13_16  free_load_conservation_991  1
    load_1_13_16  free_load_conservation_1009  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_17  arc_capacity_806  -25
    arc_1_13_17  connected_order_arc_807  -13
    arc_1_13_17  out_degree_986  1
    arc_1_13_17  in_degree_1011  1
    arc_1_13_17  original_T_including_depot_unload_1031  7.8060605690718819e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_17  arc_capacity_806  1
    load_1_13_17  free_load_conservation_991  1
    load_1_13_17  free_load_conservation_1015  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_18  arc_capacity_808  -25
    arc_1_13_18  connected_order_arc_809  -13
    arc_1_13_18  out_degree_986  1
    arc_1_13_18  in_degree_1017  1
    arc_1_13_18  original_T_including_depot_unload_1031  5.3348116005684176e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_18  arc_capacity_808  1
    load_1_13_18  free_load_conservation_991  1
    load_1_13_18  free_load_conservation_1021  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_19  arc_capacity_810  -25
    arc_1_13_19  connected_order_arc_811  -13
    arc_1_13_19  out_degree_986  1
    arc_1_13_19  in_degree_1023  1
    arc_1_13_19  original_T_including_depot_unload_1031  3.5166546157461704e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_19  arc_capacity_810  1
    load_1_13_19  free_load_conservation_991  1
    load_1_13_19  free_load_conservation_1027  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_0  arc_capacity_812  -25
    arc_1_14_0  depot_return_or_bypass_951  1
    arc_1_14_0  out_degree_992  1
    arc_1_14_0  original_T_including_depot_unload_1031  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_0  arc_capacity_812  1
    load_1_14_0  free_load_conservation_997  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_5  arc_capacity_813  -25
    arc_1_14_5  connected_order_arc_814  -13
    arc_1_14_5  in_degree_953  1
    arc_1_14_5  out_degree_992  1
    arc_1_14_5  original_T_including_depot_unload_1031  2.1501600514850211e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_5  arc_capacity_813  1
    load_1_14_5  segment_load_conservation_956  -1
    load_1_14_5  segment_prefix_lb_957  1
    load_1_14_5  segment_prefix_ub_958  1
    load_1_14_5  free_load_conservation_997  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_6  arc_capacity_815  -25
    arc_1_14_6  connected_order_arc_816  -13
    arc_1_14_6  in_degree_960  1
    arc_1_14_6  out_degree_992  1
    arc_1_14_6  original_T_including_depot_unload_1031  2.9790156048453791e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_6  arc_capacity_815  1
    load_1_14_6  segment_load_conservation_963  -1
    load_1_14_6  segment_prefix_lb_964  1
    load_1_14_6  segment_prefix_ub_965  1
    load_1_14_6  free_load_conservation_997  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_7  arc_capacity_817  -25
    arc_1_14_7  connected_order_arc_818  -13
    arc_1_14_7  in_degree_967  1
    arc_1_14_7  out_degree_992  1
    arc_1_14_7  original_T_including_depot_unload_1031  2.1109553693139742e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_7  arc_capacity_817  1
    load_1_14_7  segment_load_conservation_970  -1
    load_1_14_7  segment_prefix_lb_971  1
    load_1_14_7  segment_prefix_ub_972  1
    load_1_14_7  free_load_conservation_997  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_8  arc_capacity_819  -25
    arc_1_14_8  connected_order_arc_820  -13
    arc_1_14_8  in_degree_974  1
    arc_1_14_8  out_degree_992  1
    arc_1_14_8  original_T_including_depot_unload_1031  1.8911324761641883e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_8  arc_capacity_819  1
    load_1_14_8  segment_load_conservation_977  -1
    load_1_14_8  segment_prefix_lb_978  1
    load_1_14_8  segment_prefix_ub_979  1
    load_1_14_8  free_load_conservation_997  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_12  arc_capacity_821  -25
    arc_1_14_12  connected_order_arc_822  -13
    arc_1_14_12  in_degree_981  1
    arc_1_14_12  out_degree_992  1
    arc_1_14_12  original_T_including_depot_unload_1031  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_12  arc_capacity_821  1
    load_1_14_12  free_load_conservation_985  -1
    load_1_14_12  free_load_conservation_997  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_13  arc_capacity_823  -25
    arc_1_14_13  connected_order_arc_824  -13
    arc_1_14_13  in_degree_987  1
    arc_1_14_13  out_degree_992  1
    arc_1_14_13  original_T_including_depot_unload_1031  9.8108674361469946e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_13  arc_capacity_823  1
    load_1_14_13  free_load_conservation_991  -1
    load_1_14_13  free_load_conservation_997  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_15  arc_capacity_825  -25
    arc_1_14_15  connected_order_arc_826  -13
    arc_1_14_15  out_degree_992  1
    arc_1_14_15  in_degree_999  1
    arc_1_14_15  original_T_including_depot_unload_1031  1.0063298732365655e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_15  arc_capacity_825  1
    load_1_14_15  free_load_conservation_997  1
    load_1_14_15  free_load_conservation_1003  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_16  arc_capacity_827  -25
    arc_1_14_16  connected_order_arc_828  -13
    arc_1_14_16  out_degree_992  1
    arc_1_14_16  in_degree_1005  1
    arc_1_14_16  original_T_including_depot_unload_1031  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_1_14_16  arc_capacity_827  1
    load_1_14_16  free_load_conservation_997  1
    load_1_14_16  free_load_conservation_1009  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_17  arc_capacity_829  -25
    arc_1_14_17  connected_order_arc_830  -13
    arc_1_14_17  out_degree_992  1
    arc_1_14_17  in_degree_1011  1
    arc_1_14_17  original_T_including_depot_unload_1031  1.3072142379397485e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_17  arc_capacity_829  1
    load_1_14_17  free_load_conservation_997  1
    load_1_14_17  free_load_conservation_1015  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_18  arc_capacity_831  -25
    arc_1_14_18  connected_order_arc_832  -13
    arc_1_14_18  out_degree_992  1
    arc_1_14_18  in_degree_1017  1
    arc_1_14_18  original_T_including_depot_unload_1031  8.0139063451811444e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_18  arc_capacity_831  1
    load_1_14_18  free_load_conservation_997  1
    load_1_14_18  free_load_conservation_1021  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_19  arc_capacity_833  -25
    arc_1_14_19  connected_order_arc_834  -13
    arc_1_14_19  out_degree_992  1
    arc_1_14_19  in_degree_1023  1
    arc_1_14_19  original_T_including_depot_unload_1031  1.1967280409234234e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_19  arc_capacity_833  1
    load_1_14_19  free_load_conservation_997  1
    load_1_14_19  free_load_conservation_1027  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_0  arc_capacity_835  -25
    arc_1_15_0  depot_return_or_bypass_951  1
    arc_1_15_0  out_degree_998  1
    arc_1_15_0  original_T_including_depot_unload_1031  5.8421641813809208e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_0  arc_capacity_835  1
    load_1_15_0  free_load_conservation_1003  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_5  arc_capacity_836  -25
    arc_1_15_5  connected_order_arc_837  -13
    arc_1_15_5  in_degree_953  1
    arc_1_15_5  out_degree_998  1
    arc_1_15_5  original_T_including_depot_unload_1031  1.5356438916798834e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_5  arc_capacity_836  1
    load_1_15_5  segment_load_conservation_956  -1
    load_1_15_5  segment_prefix_lb_957  1
    load_1_15_5  segment_prefix_ub_958  1
    load_1_15_5  free_load_conservation_1003  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_6  arc_capacity_838  -25
    arc_1_15_6  connected_order_arc_839  -13
    arc_1_15_6  in_degree_960  1
    arc_1_15_6  out_degree_998  1
    arc_1_15_6  original_T_including_depot_unload_1031  1.9765601995118598e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_6  arc_capacity_838  1
    load_1_15_6  segment_load_conservation_963  -1
    load_1_15_6  segment_prefix_lb_964  1
    load_1_15_6  segment_prefix_ub_965  1
    load_1_15_6  free_load_conservation_1003  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_7  arc_capacity_840  -25
    arc_1_15_7  connected_order_arc_841  -13
    arc_1_15_7  in_degree_967  1
    arc_1_15_7  out_degree_998  1
    arc_1_15_7  original_T_including_depot_unload_1031  1.1150690045767951e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_7  arc_capacity_840  1
    load_1_15_7  segment_load_conservation_970  -1
    load_1_15_7  segment_prefix_lb_971  1
    load_1_15_7  segment_prefix_ub_972  1
    load_1_15_7  free_load_conservation_1003  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_8  arc_capacity_842  -25
    arc_1_15_8  connected_order_arc_843  -13
    arc_1_15_8  in_degree_974  1
    arc_1_15_8  out_degree_998  1
    arc_1_15_8  original_T_including_depot_unload_1031  9.3137133767849343e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_8  arc_capacity_842  1
    load_1_15_8  segment_load_conservation_977  -1
    load_1_15_8  segment_prefix_lb_978  1
    load_1_15_8  segment_prefix_ub_979  1
    load_1_15_8  free_load_conservation_1003  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_12  arc_capacity_844  -25
    arc_1_15_12  connected_order_arc_845  -13
    arc_1_15_12  in_degree_981  1
    arc_1_15_12  out_degree_998  1
    arc_1_15_12  original_T_including_depot_unload_1031  5.0398976026149836e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_12  arc_capacity_844  1
    load_1_15_12  free_load_conservation_985  -1
    load_1_15_12  free_load_conservation_1003  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_13  arc_capacity_846  -25
    arc_1_15_13  connected_order_arc_847  -13
    arc_1_15_13  in_degree_987  1
    arc_1_15_13  out_degree_998  1
    arc_1_15_13  original_T_including_depot_unload_1031  566.256001718161
    MARKER    'MARKER'                 'INTEND'
    load_1_15_13  arc_capacity_846  1
    load_1_15_13  free_load_conservation_991  -1
    load_1_15_13  free_load_conservation_1003  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_14  arc_capacity_848  -25
    arc_1_15_14  connected_order_arc_849  -13
    arc_1_15_14  in_degree_993  1
    arc_1_15_14  out_degree_998  1
    arc_1_15_14  original_T_including_depot_unload_1031  1.0063298732365655e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_14  arc_capacity_848  1
    load_1_15_14  free_load_conservation_997  -1
    load_1_15_14  free_load_conservation_1003  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_16  arc_capacity_850  -25
    arc_1_15_16  connected_order_arc_851  -13
    arc_1_15_16  out_degree_998  1
    arc_1_15_16  in_degree_1005  1
    arc_1_15_16  original_T_including_depot_unload_1031  3.6822662782562685e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_16  arc_capacity_850  1
    load_1_15_16  free_load_conservation_1003  1
    load_1_15_16  free_load_conservation_1009  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_17  arc_capacity_852  -25
    arc_1_15_17  connected_order_arc_853  -13
    arc_1_15_17  out_degree_998  1
    arc_1_15_17  in_degree_1011  1
    arc_1_15_17  original_T_including_depot_unload_1031  308.565954837055
    MARKER    'MARKER'                 'INTEND'
    load_1_15_17  arc_capacity_852  1
    load_1_15_17  free_load_conservation_1003  1
    load_1_15_17  free_load_conservation_1015  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_18  arc_capacity_854  -25
    arc_1_15_18  connected_order_arc_855  -13
    arc_1_15_18  out_degree_998  1
    arc_1_15_18  in_degree_1017  1
    arc_1_15_18  original_T_including_depot_unload_1031  204.956380049771
    MARKER    'MARKER'                 'INTEND'
    load_1_15_18  arc_capacity_854  1
    load_1_15_18  free_load_conservation_1003  1
    load_1_15_18  free_load_conservation_1021  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_19  arc_capacity_856  -25
    arc_1_15_19  connected_order_arc_857  -13
    arc_1_15_19  out_degree_998  1
    arc_1_15_19  in_degree_1023  1
    arc_1_15_19  original_T_including_depot_unload_1031  9.0947747566405189e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_19  arc_capacity_856  1
    load_1_15_19  free_load_conservation_1003  1
    load_1_15_19  free_load_conservation_1027  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_0  arc_capacity_858  -25
    arc_1_16_0  depot_return_or_bypass_951  1
    arc_1_16_0  out_degree_1004  1
    arc_1_16_0  original_T_including_depot_unload_1031  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_0  arc_capacity_858  1
    load_1_16_0  free_load_conservation_1009  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_5  arc_capacity_859  -25
    arc_1_16_5  connected_order_arc_860  -13
    arc_1_16_5  in_degree_953  1
    arc_1_16_5  out_degree_1004  1
    arc_1_16_5  original_T_including_depot_unload_1031  1.6988291947636669e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_5  arc_capacity_859  1
    load_1_16_5  segment_load_conservation_956  -1
    load_1_16_5  segment_prefix_lb_957  1
    load_1_16_5  segment_prefix_ub_958  1
    load_1_16_5  free_load_conservation_1009  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_6  arc_capacity_861  -25
    arc_1_16_6  connected_order_arc_862  -13
    arc_1_16_6  in_degree_960  1
    arc_1_16_6  out_degree_1004  1
    arc_1_16_6  original_T_including_depot_unload_1031  2.3444750474890211e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_6  arc_capacity_861  1
    load_1_16_6  segment_load_conservation_963  -1
    load_1_16_6  segment_prefix_lb_964  1
    load_1_16_6  segment_prefix_ub_965  1
    load_1_16_6  free_load_conservation_1009  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_7  arc_capacity_863  -25
    arc_1_16_7  connected_order_arc_864  -13
    arc_1_16_7  in_degree_967  1
    arc_1_16_7  out_degree_1004  1
    arc_1_16_7  original_T_including_depot_unload_1031  1.4738339199468992e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_7  arc_capacity_863  1
    load_1_16_7  segment_load_conservation_970  -1
    load_1_16_7  segment_prefix_lb_971  1
    load_1_16_7  segment_prefix_ub_972  1
    load_1_16_7  free_load_conservation_1009  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_8  arc_capacity_865  -25
    arc_1_16_8  connected_order_arc_866  -13
    arc_1_16_8  in_degree_974  1
    arc_1_16_8  out_degree_1004  1
    arc_1_16_8  original_T_including_depot_unload_1031  1.2665309635243570e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_8  arc_capacity_865  1
    load_1_16_8  segment_load_conservation_977  -1
    load_1_16_8  segment_prefix_lb_978  1
    load_1_16_8  segment_prefix_ub_979  1
    load_1_16_8  free_load_conservation_1009  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_12  arc_capacity_867  -25
    arc_1_16_12  connected_order_arc_868  -13
    arc_1_16_12  in_degree_981  1
    arc_1_16_12  out_degree_1004  1
    arc_1_16_12  original_T_including_depot_unload_1031  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_1_16_12  arc_capacity_867  1
    load_1_16_12  free_load_conservation_985  -1
    load_1_16_12  free_load_conservation_1009  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_13  arc_capacity_869  -25
    arc_1_16_13  connected_order_arc_870  -13
    arc_1_16_13  in_degree_987  1
    arc_1_16_13  out_degree_1004  1
    arc_1_16_13  original_T_including_depot_unload_1031  5.4405628017126674e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_13  arc_capacity_869  1
    load_1_16_13  free_load_conservation_991  -1
    load_1_16_13  free_load_conservation_1009  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_14  arc_capacity_871  -25
    arc_1_16_14  connected_order_arc_872  -13
    arc_1_16_14  in_degree_993  1
    arc_1_16_14  out_degree_1004  1
    arc_1_16_14  original_T_including_depot_unload_1031  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_1_16_14  arc_capacity_871  1
    load_1_16_14  free_load_conservation_997  -1
    load_1_16_14  free_load_conservation_1009  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_15  arc_capacity_873  -25
    arc_1_16_15  connected_order_arc_874  -13
    arc_1_16_15  in_degree_999  1
    arc_1_16_15  out_degree_1004  1
    arc_1_16_15  original_T_including_depot_unload_1031  3.6822662782562685e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_15  arc_capacity_873  1
    load_1_16_15  free_load_conservation_1003  -1
    load_1_16_15  free_load_conservation_1009  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_17  arc_capacity_875  -25
    arc_1_16_17  connected_order_arc_876  -13
    arc_1_16_17  out_degree_1004  1
    arc_1_16_17  in_degree_1011  1
    arc_1_16_17  original_T_including_depot_unload_1031  6.7368811350376711e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_17  arc_capacity_875  1
    load_1_16_17  free_load_conservation_1009  1
    load_1_16_17  free_load_conservation_1015  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_18  arc_capacity_877  -25
    arc_1_16_18  connected_order_arc_878  -13
    arc_1_16_18  out_degree_1004  1
    arc_1_16_18  in_degree_1017  1
    arc_1_16_18  original_T_including_depot_unload_1031  1.6388081578301370e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_18  arc_capacity_877  1
    load_1_16_18  free_load_conservation_1009  1
    load_1_16_18  free_load_conservation_1021  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_19  arc_capacity_879  -25
    arc_1_16_19  connected_order_arc_880  -13
    arc_1_16_19  out_degree_1004  1
    arc_1_16_19  in_degree_1023  1
    arc_1_16_19  original_T_including_depot_unload_1031  8.7906342149593650e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_19  arc_capacity_879  1
    load_1_16_19  free_load_conservation_1009  1
    load_1_16_19  free_load_conservation_1027  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_0  arc_capacity_881  -25
    arc_1_17_0  depot_return_or_bypass_951  1
    arc_1_17_0  out_degree_1010  1
    arc_1_17_0  original_T_including_depot_unload_1031  3.8060477410436619e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_0  arc_capacity_881  1
    load_1_17_0  free_load_conservation_1015  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_5  arc_capacity_882  -25
    arc_1_17_5  connected_order_arc_883  -13
    arc_1_17_5  in_degree_953  1
    arc_1_17_5  out_degree_1010  1
    arc_1_17_5  original_T_including_depot_unload_1031  1.5168242190367512e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_5  arc_capacity_882  1
    load_1_17_5  segment_load_conservation_956  -1
    load_1_17_5  segment_prefix_lb_957  1
    load_1_17_5  segment_prefix_ub_958  1
    load_1_17_5  free_load_conservation_1015  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_6  arc_capacity_884  -25
    arc_1_17_6  connected_order_arc_885  -13
    arc_1_17_6  in_degree_960  1
    arc_1_17_6  out_degree_1010  1
    arc_1_17_6  original_T_including_depot_unload_1031  1.6719633410042259e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_6  arc_capacity_884  1
    load_1_17_6  segment_load_conservation_963  -1
    load_1_17_6  segment_prefix_lb_964  1
    load_1_17_6  segment_prefix_ub_965  1
    load_1_17_6  free_load_conservation_1015  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_7  arc_capacity_886  -25
    arc_1_17_7  connected_order_arc_887  -13
    arc_1_17_7  in_degree_967  1
    arc_1_17_7  out_degree_1010  1
    arc_1_17_7  original_T_including_depot_unload_1031  8.4865162627289658e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_7  arc_capacity_886  1
    load_1_17_7  segment_load_conservation_970  -1
    load_1_17_7  segment_prefix_lb_971  1
    load_1_17_7  segment_prefix_ub_972  1
    load_1_17_7  free_load_conservation_1015  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_8  arc_capacity_888  -25
    arc_1_17_8  connected_order_arc_889  -13
    arc_1_17_8  in_degree_974  1
    arc_1_17_8  out_degree_1010  1
    arc_1_17_8  original_T_including_depot_unload_1031  7.2196448570394080e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_8  arc_capacity_888  1
    load_1_17_8  segment_load_conservation_977  -1
    load_1_17_8  segment_prefix_lb_978  1
    load_1_17_8  segment_prefix_ub_979  1
    load_1_17_8  free_load_conservation_1015  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_12  arc_capacity_890  -25
    arc_1_17_12  connected_order_arc_891  -13
    arc_1_17_12  in_degree_981  1
    arc_1_17_12  out_degree_1010  1
    arc_1_17_12  original_T_including_depot_unload_1031  5.5668303114993182e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_12  arc_capacity_890  1
    load_1_17_12  free_load_conservation_985  -1
    load_1_17_12  free_load_conservation_1015  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_13  arc_capacity_892  -25
    arc_1_17_13  connected_order_arc_893  -13
    arc_1_17_13  in_degree_987  1
    arc_1_17_13  out_degree_1010  1
    arc_1_17_13  original_T_including_depot_unload_1031  7.8060605690718819e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_13  arc_capacity_892  1
    load_1_17_13  free_load_conservation_991  -1
    load_1_17_13  free_load_conservation_1015  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_14  arc_capacity_894  -25
    arc_1_17_14  connected_order_arc_895  -13
    arc_1_17_14  in_degree_993  1
    arc_1_17_14  out_degree_1010  1
    arc_1_17_14  original_T_including_depot_unload_1031  1.3072142379397485e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_14  arc_capacity_894  1
    load_1_17_14  free_load_conservation_997  -1
    load_1_17_14  free_load_conservation_1015  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_15  arc_capacity_896  -25
    arc_1_17_15  connected_order_arc_897  -13
    arc_1_17_15  in_degree_999  1
    arc_1_17_15  out_degree_1010  1
    arc_1_17_15  original_T_including_depot_unload_1031  308.565954837055
    MARKER    'MARKER'                 'INTEND'
    load_1_17_15  arc_capacity_896  1
    load_1_17_15  free_load_conservation_1003  -1
    load_1_17_15  free_load_conservation_1015  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_16  arc_capacity_898  -25
    arc_1_17_16  connected_order_arc_899  -13
    arc_1_17_16  in_degree_1005  1
    arc_1_17_16  out_degree_1010  1
    arc_1_17_16  original_T_including_depot_unload_1031  6.7368811350376711e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_16  arc_capacity_898  1
    load_1_17_16  free_load_conservation_1009  -1
    load_1_17_16  free_load_conservation_1015  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_18  arc_capacity_900  -25
    arc_1_17_18  connected_order_arc_901  -13
    arc_1_17_18  out_degree_1010  1
    arc_1_17_18  in_degree_1017  1
    arc_1_17_18  original_T_including_depot_unload_1031  5.0986619729981788e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_18  arc_capacity_900  1
    load_1_17_18  free_load_conservation_1015  1
    load_1_17_18  free_load_conservation_1021  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_19  arc_capacity_902  -25
    arc_1_17_19  connected_order_arc_903  -13
    arc_1_17_19  out_degree_1010  1
    arc_1_17_19  in_degree_1023  1
    arc_1_17_19  original_T_including_depot_unload_1031  1.0869859877715128e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_19  arc_capacity_902  1
    load_1_17_19  free_load_conservation_1015  1
    load_1_17_19  free_load_conservation_1027  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_0  arc_capacity_904  -25
    arc_1_18_0  depot_return_or_bypass_951  1
    arc_1_18_0  out_degree_1016  1
    arc_1_18_0  original_T_including_depot_unload_1031  778.011461754062
    MARKER    'MARKER'                 'INTEND'
    load_1_18_0  arc_capacity_904  1
    load_1_18_0  free_load_conservation_1021  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_5  arc_capacity_905  -25
    arc_1_18_5  connected_order_arc_906  -13
    arc_1_18_5  in_degree_953  1
    arc_1_18_5  out_degree_1016  1
    arc_1_18_5  original_T_including_depot_unload_1031  1.6274520107532360e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_5  arc_capacity_905  1
    load_1_18_5  segment_load_conservation_956  -1
    load_1_18_5  segment_prefix_lb_957  1
    load_1_18_5  segment_prefix_ub_958  1
    load_1_18_5  free_load_conservation_1021  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_6  arc_capacity_907  -25
    arc_1_18_6  connected_order_arc_908  -13
    arc_1_18_6  in_degree_960  1
    arc_1_18_6  out_degree_1016  1
    arc_1_18_6  original_T_including_depot_unload_1031  2.1806564621513235e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_6  arc_capacity_907  1
    load_1_18_6  segment_load_conservation_963  -1
    load_1_18_6  segment_prefix_lb_964  1
    load_1_18_6  segment_prefix_ub_965  1
    load_1_18_6  free_load_conservation_1021  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_7  arc_capacity_909  -25
    arc_1_18_7  connected_order_arc_910  -13
    arc_1_18_7  in_degree_967  1
    arc_1_18_7  out_degree_1016  1
    arc_1_18_7  original_T_including_depot_unload_1031  1.3162040688959055e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_7  arc_capacity_909  1
    load_1_18_7  segment_load_conservation_970  -1
    load_1_18_7  segment_prefix_lb_971  1
    load_1_18_7  segment_prefix_ub_972  1
    load_1_18_7  free_load_conservation_1021  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_8  arc_capacity_911  -25
    arc_1_18_8  connected_order_arc_912  -13
    arc_1_18_8  in_degree_974  1
    arc_1_18_8  out_degree_1016  1
    arc_1_18_8  original_T_including_depot_unload_1031  1.1193870869231816e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_8  arc_capacity_911  1
    load_1_18_8  segment_load_conservation_977  -1
    load_1_18_8  segment_prefix_lb_978  1
    load_1_18_8  segment_prefix_ub_979  1
    load_1_18_8  free_load_conservation_1021  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_12  arc_capacity_913  -25
    arc_1_18_12  connected_order_arc_914  -13
    arc_1_18_12  in_degree_981  1
    arc_1_18_12  out_degree_1016  1
    arc_1_18_12  original_T_including_depot_unload_1031  608.963327854777
    MARKER    'MARKER'                 'INTEND'
    load_1_18_12  arc_capacity_913  1
    load_1_18_12  free_load_conservation_985  -1
    load_1_18_12  free_load_conservation_1021  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_13  arc_capacity_915  -25
    arc_1_18_13  connected_order_arc_916  -13
    arc_1_18_13  in_degree_987  1
    arc_1_18_13  out_degree_1016  1
    arc_1_18_13  original_T_including_depot_unload_1031  5.3348116005684176e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_13  arc_capacity_915  1
    load_1_18_13  free_load_conservation_991  -1
    load_1_18_13  free_load_conservation_1021  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_14  arc_capacity_917  -25
    arc_1_18_14  connected_order_arc_918  -13
    arc_1_18_14  in_degree_993  1
    arc_1_18_14  out_degree_1016  1
    arc_1_18_14  original_T_including_depot_unload_1031  8.0139063451811444e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_14  arc_capacity_917  1
    load_1_18_14  free_load_conservation_997  -1
    load_1_18_14  free_load_conservation_1021  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_15  arc_capacity_919  -25
    arc_1_18_15  connected_order_arc_920  -13
    arc_1_18_15  in_degree_999  1
    arc_1_18_15  out_degree_1016  1
    arc_1_18_15  original_T_including_depot_unload_1031  204.956380049771
    MARKER    'MARKER'                 'INTEND'
    load_1_18_15  arc_capacity_919  1
    load_1_18_15  free_load_conservation_1003  -1
    load_1_18_15  free_load_conservation_1021  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_16  arc_capacity_921  -25
    arc_1_18_16  connected_order_arc_922  -13
    arc_1_18_16  in_degree_1005  1
    arc_1_18_16  out_degree_1016  1
    arc_1_18_16  original_T_including_depot_unload_1031  1.6388081578301370e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_16  arc_capacity_921  1
    load_1_18_16  free_load_conservation_1009  -1
    load_1_18_16  free_load_conservation_1021  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_17  arc_capacity_923  -25
    arc_1_18_17  connected_order_arc_924  -13
    arc_1_18_17  in_degree_1011  1
    arc_1_18_17  out_degree_1016  1
    arc_1_18_17  original_T_including_depot_unload_1031  5.0986619729981788e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_17  arc_capacity_923  1
    load_1_18_17  free_load_conservation_1015  -1
    load_1_18_17  free_load_conservation_1021  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_19  arc_capacity_925  -25
    arc_1_18_19  connected_order_arc_926  -13
    arc_1_18_19  out_degree_1016  1
    arc_1_18_19  in_degree_1023  1
    arc_1_18_19  original_T_including_depot_unload_1031  8.8427037135592116e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_19  arc_capacity_925  1
    load_1_18_19  free_load_conservation_1021  1
    load_1_18_19  free_load_conservation_1027  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_0  arc_capacity_927  -25
    arc_1_19_0  depot_return_or_bypass_951  1
    arc_1_19_0  out_degree_1022  1
    arc_1_19_0  original_T_including_depot_unload_1031  1.0056399980521732e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_0  arc_capacity_927  1
    load_1_19_0  free_load_conservation_1027  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_5  arc_capacity_928  -25
    arc_1_19_5  connected_order_arc_929  -13
    arc_1_19_5  in_degree_953  1
    arc_1_19_5  out_degree_1022  1
    arc_1_19_5  original_T_including_depot_unload_1031  9.7357850164388731e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_5  arc_capacity_928  1
    load_1_19_5  segment_load_conservation_956  -1
    load_1_19_5  segment_prefix_lb_957  1
    load_1_19_5  segment_prefix_ub_958  1
    load_1_19_5  free_load_conservation_1027  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_6  arc_capacity_930  -25
    arc_1_19_6  connected_order_arc_931  -13
    arc_1_19_6  in_degree_960  1
    arc_1_19_6  out_degree_1022  1
    arc_1_19_6  original_T_including_depot_unload_1031  2.4304747035816213e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_6  arc_capacity_930  1
    load_1_19_6  segment_load_conservation_963  -1
    load_1_19_6  segment_prefix_lb_964  1
    load_1_19_6  segment_prefix_ub_965  1
    load_1_19_6  free_load_conservation_1027  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_7  arc_capacity_932  -25
    arc_1_19_7  connected_order_arc_933  -13
    arc_1_19_7  in_degree_967  1
    arc_1_19_7  out_degree_1022  1
    arc_1_19_7  original_T_including_depot_unload_1031  1.4570094449922669e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_7  arc_capacity_932  1
    load_1_19_7  segment_load_conservation_970  -1
    load_1_19_7  segment_prefix_lb_971  1
    load_1_19_7  segment_prefix_ub_972  1
    load_1_19_7  free_load_conservation_1027  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_8  arc_capacity_934  -25
    arc_1_19_8  connected_order_arc_935  -13
    arc_1_19_8  in_degree_974  1
    arc_1_19_8  out_degree_1022  1
    arc_1_19_8  original_T_including_depot_unload_1031  1.1545648513745866e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_8  arc_capacity_934  1
    load_1_19_8  segment_load_conservation_977  -1
    load_1_19_8  segment_prefix_lb_978  1
    load_1_19_8  segment_prefix_ub_979  1
    load_1_19_8  free_load_conservation_1027  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_12  arc_capacity_936  -25
    arc_1_19_12  connected_order_arc_937  -13
    arc_1_19_12  in_degree_981  1
    arc_1_19_12  out_degree_1022  1
    arc_1_19_12  original_T_including_depot_unload_1031  5.7276146581216926e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_12  arc_capacity_936  1
    load_1_19_12  free_load_conservation_985  -1
    load_1_19_12  free_load_conservation_1027  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_13  arc_capacity_938  -25
    arc_1_19_13  connected_order_arc_939  -13
    arc_1_19_13  in_degree_987  1
    arc_1_19_13  out_degree_1022  1
    arc_1_19_13  original_T_including_depot_unload_1031  3.5166546157461704e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_13  arc_capacity_938  1
    load_1_19_13  free_load_conservation_991  -1
    load_1_19_13  free_load_conservation_1027  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_14  arc_capacity_940  -25
    arc_1_19_14  connected_order_arc_941  -13
    arc_1_19_14  in_degree_993  1
    arc_1_19_14  out_degree_1022  1
    arc_1_19_14  original_T_including_depot_unload_1031  1.1967280409234234e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_14  arc_capacity_940  1
    load_1_19_14  free_load_conservation_997  -1
    load_1_19_14  free_load_conservation_1027  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_15  arc_capacity_942  -25
    arc_1_19_15  connected_order_arc_943  -13
    arc_1_19_15  in_degree_999  1
    arc_1_19_15  out_degree_1022  1
    arc_1_19_15  original_T_including_depot_unload_1031  9.0947747566405189e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_15  arc_capacity_942  1
    load_1_19_15  free_load_conservation_1003  -1
    load_1_19_15  free_load_conservation_1027  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_16  arc_capacity_944  -25
    arc_1_19_16  connected_order_arc_945  -13
    arc_1_19_16  in_degree_1005  1
    arc_1_19_16  out_degree_1022  1
    arc_1_19_16  original_T_including_depot_unload_1031  8.7906342149593650e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_16  arc_capacity_944  1
    load_1_19_16  free_load_conservation_1009  -1
    load_1_19_16  free_load_conservation_1027  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_17  arc_capacity_946  -25
    arc_1_19_17  connected_order_arc_947  -13
    arc_1_19_17  in_degree_1011  1
    arc_1_19_17  out_degree_1022  1
    arc_1_19_17  original_T_including_depot_unload_1031  1.0869859877715128e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_17  arc_capacity_946  1
    load_1_19_17  free_load_conservation_1015  -1
    load_1_19_17  free_load_conservation_1027  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_18  arc_capacity_948  -25
    arc_1_19_18  connected_order_arc_949  -13
    arc_1_19_18  in_degree_1017  1
    arc_1_19_18  out_degree_1022  1
    arc_1_19_18  original_T_including_depot_unload_1031  8.8427037135592116e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_18  arc_capacity_948  1
    load_1_19_18  free_load_conservation_1021  -1
    load_1_19_18  free_load_conservation_1027  1
    visit_2_9  out_degree_1277  -1
    visit_2_9  in_degree_1278  -1
    visit_2_9  order_active_lb_1279  -1
    visit_2_9  order_active_ub_1280  -11
    order_2_9  connected_order_arc_1046  -1
    order_2_9  connected_order_arc_1048  -1
    order_2_9  connected_order_arc_1050  -1
    order_2_9  connected_order_arc_1052  -1
    order_2_9  connected_order_arc_1054  -1
    order_2_9  connected_order_arc_1056  -1
    order_2_9  connected_order_arc_1058  -1
    order_2_9  connected_order_arc_1060  -1
    order_2_9  connected_order_arc_1062  -1
    order_2_9  connected_order_arc_1064  -1
    order_2_9  connected_order_arc_1067  1
    order_2_9  connected_order_arc_1088  1
    order_2_9  connected_order_arc_1109  1
    order_2_9  connected_order_arc_1130  1
    order_2_9  connected_order_arc_1151  1
    order_2_9  connected_order_arc_1172  1
    order_2_9  connected_order_arc_1193  1
    order_2_9  connected_order_arc_1214  1
    order_2_9  connected_order_arc_1235  1
    order_2_9  connected_order_arc_1256  1
    order_2_9  order_active_lb_1279  1
    order_2_9  order_active_ub_1280  1
    order_2_9  fixed_segment_relative_order_1346  -1
    visit_2_10  out_degree_1284  -1
    visit_2_10  in_degree_1285  -1
    visit_2_10  order_active_lb_1286  -1
    visit_2_10  order_active_ub_1287  -11
    order_2_10  connected_order_arc_1046  1
    order_2_10  connected_order_arc_1067  -1
    order_2_10  connected_order_arc_1069  -1
    order_2_10  connected_order_arc_1071  -1
    order_2_10  connected_order_arc_1073  -1
    order_2_10  connected_order_arc_1075  -1
    order_2_10  connected_order_arc_1077  -1
    order_2_10  connected_order_arc_1079  -1
    order_2_10  connected_order_arc_1081  -1
    order_2_10  connected_order_arc_1083  -1
    order_2_10  connected_order_arc_1085  -1
    order_2_10  connected_order_arc_1090  1
    order_2_10  connected_order_arc_1111  1
    order_2_10  connected_order_arc_1132  1
    order_2_10  connected_order_arc_1153  1
    order_2_10  connected_order_arc_1174  1
    order_2_10  connected_order_arc_1195  1
    order_2_10  connected_order_arc_1216  1
    order_2_10  connected_order_arc_1237  1
    order_2_10  connected_order_arc_1258  1
    order_2_10  order_active_lb_1286  1
    order_2_10  order_active_ub_1287  1
    order_2_10  fixed_segment_relative_order_1346  1
    order_2_10  fixed_segment_relative_order_1347  -1
    visit_2_11  out_degree_1291  -1
    visit_2_11  in_degree_1292  -1
    visit_2_11  order_active_lb_1293  -1
    visit_2_11  order_active_ub_1294  -11
    order_2_11  connected_order_arc_1048  1
    order_2_11  connected_order_arc_1069  1
    order_2_11  connected_order_arc_1088  -1
    order_2_11  connected_order_arc_1090  -1
    order_2_11  connected_order_arc_1092  -1
    order_2_11  connected_order_arc_1094  -1
    order_2_11  connected_order_arc_1096  -1
    order_2_11  connected_order_arc_1098  -1
    order_2_11  connected_order_arc_1100  -1
    order_2_11  connected_order_arc_1102  -1
    order_2_11  connected_order_arc_1104  -1
    order_2_11  connected_order_arc_1106  -1
    order_2_11  connected_order_arc_1113  1
    order_2_11  connected_order_arc_1134  1
    order_2_11  connected_order_arc_1155  1
    order_2_11  connected_order_arc_1176  1
    order_2_11  connected_order_arc_1197  1
    order_2_11  connected_order_arc_1218  1
    order_2_11  connected_order_arc_1239  1
    order_2_11  connected_order_arc_1260  1
    order_2_11  order_active_lb_1293  1
    order_2_11  order_active_ub_1294  1
    order_2_11  fixed_segment_relative_order_1347  1
    visit_2_12  out_degree_1298  -1
    visit_2_12  in_degree_1299  -1
    visit_2_12  order_active_lb_1300  -1
    visit_2_12  order_active_ub_1301  -11
    visit_2_12  service_visit_def_1302  -1
    order_2_12  connected_order_arc_1050  1
    order_2_12  connected_order_arc_1071  1
    order_2_12  connected_order_arc_1092  1
    order_2_12  connected_order_arc_1109  -1
    order_2_12  connected_order_arc_1111  -1
    order_2_12  connected_order_arc_1113  -1
    order_2_12  connected_order_arc_1115  -1
    order_2_12  connected_order_arc_1117  -1
    order_2_12  connected_order_arc_1119  -1
    order_2_12  connected_order_arc_1121  -1
    order_2_12  connected_order_arc_1123  -1
    order_2_12  connected_order_arc_1125  -1
    order_2_12  connected_order_arc_1127  -1
    order_2_12  connected_order_arc_1136  1
    order_2_12  connected_order_arc_1157  1
    order_2_12  connected_order_arc_1178  1
    order_2_12  connected_order_arc_1199  1
    order_2_12  connected_order_arc_1220  1
    order_2_12  connected_order_arc_1241  1
    order_2_12  connected_order_arc_1262  1
    order_2_12  order_active_lb_1300  1
    order_2_12  order_active_ub_1301  1
    visit_2_13  out_degree_1304  -1
    visit_2_13  in_degree_1305  -1
    visit_2_13  order_active_lb_1306  -1
    visit_2_13  order_active_ub_1307  -11
    visit_2_13  service_visit_def_1308  -1
    order_2_13  connected_order_arc_1052  1
    order_2_13  connected_order_arc_1073  1
    order_2_13  connected_order_arc_1094  1
    order_2_13  connected_order_arc_1115  1
    order_2_13  connected_order_arc_1130  -1
    order_2_13  connected_order_arc_1132  -1
    order_2_13  connected_order_arc_1134  -1
    order_2_13  connected_order_arc_1136  -1
    order_2_13  connected_order_arc_1138  -1
    order_2_13  connected_order_arc_1140  -1
    order_2_13  connected_order_arc_1142  -1
    order_2_13  connected_order_arc_1144  -1
    order_2_13  connected_order_arc_1146  -1
    order_2_13  connected_order_arc_1148  -1
    order_2_13  connected_order_arc_1159  1
    order_2_13  connected_order_arc_1180  1
    order_2_13  connected_order_arc_1201  1
    order_2_13  connected_order_arc_1222  1
    order_2_13  connected_order_arc_1243  1
    order_2_13  connected_order_arc_1264  1
    order_2_13  order_active_lb_1306  1
    order_2_13  order_active_ub_1307  1
    visit_2_14  out_degree_1310  -1
    visit_2_14  in_degree_1311  -1
    visit_2_14  order_active_lb_1312  -1
    visit_2_14  order_active_ub_1313  -11
    visit_2_14  service_visit_def_1314  -1
    order_2_14  connected_order_arc_1054  1
    order_2_14  connected_order_arc_1075  1
    order_2_14  connected_order_arc_1096  1
    order_2_14  connected_order_arc_1117  1
    order_2_14  connected_order_arc_1138  1
    order_2_14  connected_order_arc_1151  -1
    order_2_14  connected_order_arc_1153  -1
    order_2_14  connected_order_arc_1155  -1
    order_2_14  connected_order_arc_1157  -1
    order_2_14  connected_order_arc_1159  -1
    order_2_14  connected_order_arc_1161  -1
    order_2_14  connected_order_arc_1163  -1
    order_2_14  connected_order_arc_1165  -1
    order_2_14  connected_order_arc_1167  -1
    order_2_14  connected_order_arc_1169  -1
    order_2_14  connected_order_arc_1182  1
    order_2_14  connected_order_arc_1203  1
    order_2_14  connected_order_arc_1224  1
    order_2_14  connected_order_arc_1245  1
    order_2_14  connected_order_arc_1266  1
    order_2_14  order_active_lb_1312  1
    order_2_14  order_active_ub_1313  1
    visit_2_15  out_degree_1316  -1
    visit_2_15  in_degree_1317  -1
    visit_2_15  order_active_lb_1318  -1
    visit_2_15  order_active_ub_1319  -11
    visit_2_15  service_visit_def_1320  -1
    order_2_15  connected_order_arc_1056  1
    order_2_15  connected_order_arc_1077  1
    order_2_15  connected_order_arc_1098  1
    order_2_15  connected_order_arc_1119  1
    order_2_15  connected_order_arc_1140  1
    order_2_15  connected_order_arc_1161  1
    order_2_15  connected_order_arc_1172  -1
    order_2_15  connected_order_arc_1174  -1
    order_2_15  connected_order_arc_1176  -1
    order_2_15  connected_order_arc_1178  -1
    order_2_15  connected_order_arc_1180  -1
    order_2_15  connected_order_arc_1182  -1
    order_2_15  connected_order_arc_1184  -1
    order_2_15  connected_order_arc_1186  -1
    order_2_15  connected_order_arc_1188  -1
    order_2_15  connected_order_arc_1190  -1
    order_2_15  connected_order_arc_1205  1
    order_2_15  connected_order_arc_1226  1
    order_2_15  connected_order_arc_1247  1
    order_2_15  connected_order_arc_1268  1
    order_2_15  order_active_lb_1318  1
    order_2_15  order_active_ub_1319  1
    visit_2_16  out_degree_1322  -1
    visit_2_16  in_degree_1323  -1
    visit_2_16  order_active_lb_1324  -1
    visit_2_16  order_active_ub_1325  -11
    visit_2_16  service_visit_def_1326  -1
    order_2_16  connected_order_arc_1058  1
    order_2_16  connected_order_arc_1079  1
    order_2_16  connected_order_arc_1100  1
    order_2_16  connected_order_arc_1121  1
    order_2_16  connected_order_arc_1142  1
    order_2_16  connected_order_arc_1163  1
    order_2_16  connected_order_arc_1184  1
    order_2_16  connected_order_arc_1193  -1
    order_2_16  connected_order_arc_1195  -1
    order_2_16  connected_order_arc_1197  -1
    order_2_16  connected_order_arc_1199  -1
    order_2_16  connected_order_arc_1201  -1
    order_2_16  connected_order_arc_1203  -1
    order_2_16  connected_order_arc_1205  -1
    order_2_16  connected_order_arc_1207  -1
    order_2_16  connected_order_arc_1209  -1
    order_2_16  connected_order_arc_1211  -1
    order_2_16  connected_order_arc_1228  1
    order_2_16  connected_order_arc_1249  1
    order_2_16  connected_order_arc_1270  1
    order_2_16  order_active_lb_1324  1
    order_2_16  order_active_ub_1325  1
    visit_2_17  out_degree_1328  -1
    visit_2_17  in_degree_1329  -1
    visit_2_17  order_active_lb_1330  -1
    visit_2_17  order_active_ub_1331  -11
    visit_2_17  service_visit_def_1332  -1
    order_2_17  connected_order_arc_1060  1
    order_2_17  connected_order_arc_1081  1
    order_2_17  connected_order_arc_1102  1
    order_2_17  connected_order_arc_1123  1
    order_2_17  connected_order_arc_1144  1
    order_2_17  connected_order_arc_1165  1
    order_2_17  connected_order_arc_1186  1
    order_2_17  connected_order_arc_1207  1
    order_2_17  connected_order_arc_1214  -1
    order_2_17  connected_order_arc_1216  -1
    order_2_17  connected_order_arc_1218  -1
    order_2_17  connected_order_arc_1220  -1
    order_2_17  connected_order_arc_1222  -1
    order_2_17  connected_order_arc_1224  -1
    order_2_17  connected_order_arc_1226  -1
    order_2_17  connected_order_arc_1228  -1
    order_2_17  connected_order_arc_1230  -1
    order_2_17  connected_order_arc_1232  -1
    order_2_17  connected_order_arc_1251  1
    order_2_17  connected_order_arc_1272  1
    order_2_17  order_active_lb_1330  1
    order_2_17  order_active_ub_1331  1
    visit_2_18  out_degree_1334  -1
    visit_2_18  in_degree_1335  -1
    visit_2_18  order_active_lb_1336  -1
    visit_2_18  order_active_ub_1337  -11
    visit_2_18  service_visit_def_1338  -1
    order_2_18  connected_order_arc_1062  1
    order_2_18  connected_order_arc_1083  1
    order_2_18  connected_order_arc_1104  1
    order_2_18  connected_order_arc_1125  1
    order_2_18  connected_order_arc_1146  1
    order_2_18  connected_order_arc_1167  1
    order_2_18  connected_order_arc_1188  1
    order_2_18  connected_order_arc_1209  1
    order_2_18  connected_order_arc_1230  1
    order_2_18  connected_order_arc_1235  -1
    order_2_18  connected_order_arc_1237  -1
    order_2_18  connected_order_arc_1239  -1
    order_2_18  connected_order_arc_1241  -1
    order_2_18  connected_order_arc_1243  -1
    order_2_18  connected_order_arc_1245  -1
    order_2_18  connected_order_arc_1247  -1
    order_2_18  connected_order_arc_1249  -1
    order_2_18  connected_order_arc_1251  -1
    order_2_18  connected_order_arc_1253  -1
    order_2_18  connected_order_arc_1274  1
    order_2_18  order_active_lb_1336  1
    order_2_18  order_active_ub_1337  1
    visit_2_19  out_degree_1340  -1
    visit_2_19  in_degree_1341  -1
    visit_2_19  order_active_lb_1342  -1
    visit_2_19  order_active_ub_1343  -11
    visit_2_19  service_visit_def_1344  -1
    order_2_19  connected_order_arc_1064  1
    order_2_19  connected_order_arc_1085  1
    order_2_19  connected_order_arc_1106  1
    order_2_19  connected_order_arc_1127  1
    order_2_19  connected_order_arc_1148  1
    order_2_19  connected_order_arc_1169  1
    order_2_19  connected_order_arc_1190  1
    order_2_19  connected_order_arc_1211  1
    order_2_19  connected_order_arc_1232  1
    order_2_19  connected_order_arc_1253  1
    order_2_19  connected_order_arc_1256  -1
    order_2_19  connected_order_arc_1258  -1
    order_2_19  connected_order_arc_1260  -1
    order_2_19  connected_order_arc_1262  -1
    order_2_19  connected_order_arc_1264  -1
    order_2_19  connected_order_arc_1266  -1
    order_2_19  connected_order_arc_1268  -1
    order_2_19  connected_order_arc_1270  -1
    order_2_19  connected_order_arc_1272  -1
    order_2_19  connected_order_arc_1274  -1
    order_2_19  order_active_lb_1342  1
    order_2_19  order_active_ub_1343  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_0  arc_capacity_1032  -30
    arc_2_0_0  depot_departure_or_bypass_1275  1
    arc_2_0_0  depot_return_or_bypass_1276  1
    MARKER    'MARKER'                 'INTEND'
    load_2_0_0  arc_capacity_1032  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_9  arc_capacity_1033  -30
    arc_2_0_9  depot_departure_or_bypass_1275  1
    arc_2_0_9  in_degree_1278  1
    arc_2_0_9  original_T_including_depot_unload_1348  1.4373810231417410e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_9  arc_capacity_1033  1
    load_2_0_9  segment_load_conservation_1281  -1
    load_2_0_9  segment_prefix_lb_1282  1
    load_2_0_9  segment_prefix_ub_1283  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_10  arc_capacity_1034  -30
    arc_2_0_10  depot_departure_or_bypass_1275  1
    arc_2_0_10  in_degree_1285  1
    arc_2_0_10  original_T_including_depot_unload_1348  1.4206108045382291e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_10  arc_capacity_1034  1
    load_2_0_10  segment_load_conservation_1288  -1
    load_2_0_10  segment_prefix_lb_1289  1
    load_2_0_10  segment_prefix_ub_1290  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_11  arc_capacity_1035  -30
    arc_2_0_11  depot_departure_or_bypass_1275  1
    arc_2_0_11  in_degree_1292  1
    arc_2_0_11  original_T_including_depot_unload_1348  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_11  arc_capacity_1035  1
    load_2_0_11  segment_load_conservation_1295  -1
    load_2_0_11  segment_prefix_lb_1296  1
    load_2_0_11  segment_prefix_ub_1297  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_12  arc_capacity_1036  -30
    arc_2_0_12  depot_departure_or_bypass_1275  1
    arc_2_0_12  in_degree_1299  1
    arc_2_0_12  original_T_including_depot_unload_1348  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_12  arc_capacity_1036  1
    load_2_0_12  free_load_conservation_1303  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_13  arc_capacity_1037  -30
    arc_2_0_13  depot_departure_or_bypass_1275  1
    arc_2_0_13  in_degree_1305  1
    arc_2_0_13  original_T_including_depot_unload_1348  7.9650294035968375e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_13  arc_capacity_1037  1
    load_2_0_13  free_load_conservation_1309  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_14  arc_capacity_1038  -30
    arc_2_0_14  depot_departure_or_bypass_1275  1
    arc_2_0_14  in_degree_1311  1
    arc_2_0_14  original_T_including_depot_unload_1348  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_14  arc_capacity_1038  1
    load_2_0_14  free_load_conservation_1315  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_15  arc_capacity_1039  -30
    arc_2_0_15  depot_departure_or_bypass_1275  1
    arc_2_0_15  in_degree_1317  1
    arc_2_0_15  original_T_including_depot_unload_1348  5.8421641813809208e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_15  arc_capacity_1039  1
    load_2_0_15  free_load_conservation_1321  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_16  arc_capacity_1040  -30
    arc_2_0_16  depot_departure_or_bypass_1275  1
    arc_2_0_16  in_degree_1323  1
    arc_2_0_16  original_T_including_depot_unload_1348  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_16  arc_capacity_1040  1
    load_2_0_16  free_load_conservation_1327  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_17  arc_capacity_1041  -30
    arc_2_0_17  depot_departure_or_bypass_1275  1
    arc_2_0_17  in_degree_1329  1
    arc_2_0_17  original_T_including_depot_unload_1348  3.8060477410436619e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_17  arc_capacity_1041  1
    load_2_0_17  free_load_conservation_1333  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_18  arc_capacity_1042  -30
    arc_2_0_18  depot_departure_or_bypass_1275  1
    arc_2_0_18  in_degree_1335  1
    arc_2_0_18  original_T_including_depot_unload_1348  778.011461754062
    MARKER    'MARKER'                 'INTEND'
    load_2_0_18  arc_capacity_1042  1
    load_2_0_18  free_load_conservation_1339  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_19  arc_capacity_1043  -30
    arc_2_0_19  depot_departure_or_bypass_1275  1
    arc_2_0_19  in_degree_1341  1
    arc_2_0_19  original_T_including_depot_unload_1348  1.0056399980521732e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_19  arc_capacity_1043  1
    load_2_0_19  free_load_conservation_1345  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_0  arc_capacity_1044  -30
    arc_2_9_0  depot_return_or_bypass_1276  1
    arc_2_9_0  out_degree_1277  1
    arc_2_9_0  original_T_including_depot_unload_1348  1.4373810231417410e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_9_0  arc_capacity_1044  1
    load_2_9_0  segment_load_conservation_1281  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_10  arc_capacity_1045  -30
    arc_2_9_10  connected_order_arc_1046  -12
    arc_2_9_10  out_degree_1277  1
    arc_2_9_10  in_degree_1285  1
    arc_2_9_10  original_T_including_depot_unload_1348  2.2310212250199638e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_9_10  arc_capacity_1045  1
    load_2_9_10  segment_load_conservation_1281  1
    load_2_9_10  segment_load_conservation_1288  -1
    load_2_9_10  segment_prefix_lb_1289  1
    load_2_9_10  segment_prefix_ub_1290  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_11  arc_capacity_1047  -30
    arc_2_9_11  connected_order_arc_1048  -12
    arc_2_9_11  out_degree_1277  1
    arc_2_9_11  in_degree_1292  1
    arc_2_9_11  original_T_including_depot_unload_1348  925.691754925099
    MARKER    'MARKER'                 'INTEND'
    load_2_9_11  arc_capacity_1047  1
    load_2_9_11  segment_load_conservation_1281  1
    load_2_9_11  segment_load_conservation_1295  -1
    load_2_9_11  segment_prefix_lb_1296  1
    load_2_9_11  segment_prefix_ub_1297  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_12  arc_capacity_1049  -30
    arc_2_9_12  connected_order_arc_1050  -12
    arc_2_9_12  out_degree_1277  1
    arc_2_9_12  in_degree_1299  1
    arc_2_9_12  original_T_including_depot_unload_1348  1.0984912119828512e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_9_12  arc_capacity_1049  1
    load_2_9_12  segment_load_conservation_1281  1
    load_2_9_12  free_load_conservation_1303  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_13  arc_capacity_1051  -30
    arc_2_9_13  connected_order_arc_1052  -12
    arc_2_9_13  out_degree_1277  1
    arc_2_9_13  in_degree_1305  1
    arc_2_9_13  original_T_including_depot_unload_1348  7.5681404708111961e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_9_13  arc_capacity_1051  1
    load_2_9_13  segment_load_conservation_1281  1
    load_2_9_13  free_load_conservation_1309  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_14  arc_capacity_1053  -30
    arc_2_9_14  connected_order_arc_1054  -12
    arc_2_9_14  out_degree_1277  1
    arc_2_9_14  in_degree_1311  1
    arc_2_9_14  original_T_including_depot_unload_1348  2.9139628504456829e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_9_14  arc_capacity_1053  1
    load_2_9_14  segment_load_conservation_1281  1
    load_2_9_14  free_load_conservation_1315  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_15  arc_capacity_1055  -30
    arc_2_9_15  connected_order_arc_1056  -12
    arc_2_9_15  out_degree_1277  1
    arc_2_9_15  in_degree_1317  1
    arc_2_9_15  original_T_including_depot_unload_1348  9.3170331463979812e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_9_15  arc_capacity_1055  1
    load_2_9_15  segment_load_conservation_1281  1
    load_2_9_15  free_load_conservation_1321  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_16  arc_capacity_1057  -30
    arc_2_9_16  connected_order_arc_1058  -12
    arc_2_9_16  out_degree_1277  1
    arc_2_9_16  in_degree_1323  1
    arc_2_9_16  original_T_including_depot_unload_1348  5.7914586906741226e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_9_16  arc_capacity_1057  1
    load_2_9_16  segment_load_conservation_1281  1
    load_2_9_16  free_load_conservation_1327  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_17  arc_capacity_1059  -30
    arc_2_9_17  connected_order_arc_1060  -12
    arc_2_9_17  out_degree_1277  1
    arc_2_9_17  in_degree_1329  1
    arc_2_9_17  original_T_including_depot_unload_1348  1.2401143998876444e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_9_17  arc_capacity_1059  1
    load_2_9_17  segment_load_conservation_1281  1
    load_2_9_17  free_load_conservation_1333  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_18  arc_capacity_1061  -30
    arc_2_9_18  connected_order_arc_1062  -12
    arc_2_9_18  out_degree_1277  1
    arc_2_9_18  in_degree_1335  1
    arc_2_9_18  original_T_including_depot_unload_1348  7.3693716289230485e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_9_18  arc_capacity_1061  1
    load_2_9_18  segment_load_conservation_1281  1
    load_2_9_18  free_load_conservation_1339  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_19  arc_capacity_1063  -30
    arc_2_9_19  connected_order_arc_1064  -12
    arc_2_9_19  out_degree_1277  1
    arc_2_9_19  in_degree_1341  1
    arc_2_9_19  original_T_including_depot_unload_1348  926.407625506948
    MARKER    'MARKER'                 'INTEND'
    load_2_9_19  arc_capacity_1063  1
    load_2_9_19  segment_load_conservation_1281  1
    load_2_9_19  free_load_conservation_1345  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_0  arc_capacity_1065  -30
    arc_2_10_0  depot_return_or_bypass_1276  1
    arc_2_10_0  out_degree_1284  1
    arc_2_10_0  original_T_including_depot_unload_1348  1.6602888921784454e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_0  arc_capacity_1065  1
    load_2_10_0  segment_load_conservation_1288  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_9  arc_capacity_1066  -30
    arc_2_10_9  connected_order_arc_1067  -12
    arc_2_10_9  in_degree_1278  1
    arc_2_10_9  out_degree_1284  1
    arc_2_10_9  original_T_including_depot_unload_1348  1.6865464326628071e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_9  arc_capacity_1066  1
    load_2_10_9  segment_load_conservation_1281  -1
    load_2_10_9  segment_prefix_lb_1282  1
    load_2_10_9  segment_prefix_ub_1283  1
    load_2_10_9  segment_load_conservation_1288  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_11  arc_capacity_1068  -30
    arc_2_10_11  connected_order_arc_1069  -12
    arc_2_10_11  out_degree_1284  1
    arc_2_10_11  in_degree_1292  1
    arc_2_10_11  original_T_including_depot_unload_1348  8.7008776944597639e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_11  arc_capacity_1068  1
    load_2_10_11  segment_load_conservation_1288  1
    load_2_10_11  segment_load_conservation_1295  -1
    load_2_10_11  segment_prefix_lb_1296  1
    load_2_10_11  segment_prefix_ub_1297  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_12  arc_capacity_1070  -30
    arc_2_10_12  connected_order_arc_1071  -12
    arc_2_10_12  out_degree_1284  1
    arc_2_10_12  in_degree_1299  1
    arc_2_10_12  original_T_including_depot_unload_1348  1.3104307696104611e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_12  arc_capacity_1070  1
    load_2_10_12  segment_load_conservation_1288  1
    load_2_10_12  free_load_conservation_1303  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_13  arc_capacity_1072  -30
    arc_2_10_13  connected_order_arc_1073  -12
    arc_2_10_13  out_degree_1284  1
    arc_2_10_13  in_degree_1305  1
    arc_2_10_13  original_T_including_depot_unload_1348  1.2177809159572148e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_13  arc_capacity_1072  1
    load_2_10_13  segment_load_conservation_1288  1
    load_2_10_13  free_load_conservation_1309  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_14  arc_capacity_1074  -30
    arc_2_10_14  connected_order_arc_1075  -12
    arc_2_10_14  out_degree_1284  1
    arc_2_10_14  in_degree_1311  1
    arc_2_10_14  original_T_including_depot_unload_1348  1.9767828664634856e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_14  arc_capacity_1074  1
    load_2_10_14  segment_load_conservation_1288  1
    load_2_10_14  free_load_conservation_1315  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_15  arc_capacity_1076  -30
    arc_2_10_15  connected_order_arc_1077  -12
    arc_2_10_15  out_degree_1284  1
    arc_2_10_15  in_degree_1317  1
    arc_2_10_15  original_T_including_depot_unload_1348  1.7513054753242350e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_15  arc_capacity_1076  1
    load_2_10_15  segment_load_conservation_1288  1
    load_2_10_15  free_load_conservation_1321  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_16  arc_capacity_1078  -30
    arc_2_10_16  connected_order_arc_1079  -12
    arc_2_10_16  out_degree_1284  1
    arc_2_10_16  in_degree_1323  1
    arc_2_10_16  original_T_including_depot_unload_1348  1.7489191280566063e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_16  arc_capacity_1078  1
    load_2_10_16  segment_load_conservation_1288  1
    load_2_10_16  free_load_conservation_1327  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_17  arc_capacity_1080  -30
    arc_2_10_17  connected_order_arc_1081  -12
    arc_2_10_17  out_degree_1284  1
    arc_2_10_17  in_degree_1329  1
    arc_2_10_17  original_T_including_depot_unload_1348  1.8670935270400330e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_17  arc_capacity_1080  1
    load_2_10_17  segment_load_conservation_1288  1
    load_2_10_17  free_load_conservation_1333  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_18  arc_capacity_1082  -30
    arc_2_10_18  connected_order_arc_1083  -12
    arc_2_10_18  out_degree_1284  1
    arc_2_10_18  in_degree_1335  1
    arc_2_10_18  original_T_including_depot_unload_1348  1.7509294259345222e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_18  arc_capacity_1082  1
    load_2_10_18  segment_load_conservation_1288  1
    load_2_10_18  free_load_conservation_1339  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_19  arc_capacity_1084  -30
    arc_2_10_19  connected_order_arc_1085  -12
    arc_2_10_19  out_degree_1284  1
    arc_2_10_19  in_degree_1341  1
    arc_2_10_19  original_T_including_depot_unload_1348  8.7049015369085737e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_19  arc_capacity_1084  1
    load_2_10_19  segment_load_conservation_1288  1
    load_2_10_19  free_load_conservation_1345  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_0  arc_capacity_1086  -30
    arc_2_11_0  depot_return_or_bypass_1276  1
    arc_2_11_0  out_degree_1291  1
    arc_2_11_0  original_T_including_depot_unload_1348  1.0071736480438395e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_0  arc_capacity_1086  1
    load_2_11_0  segment_load_conservation_1295  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_9  arc_capacity_1087  -30
    arc_2_11_9  connected_order_arc_1088  -12
    arc_2_11_9  in_degree_1278  1
    arc_2_11_9  out_degree_1291  1
    arc_2_11_9  original_T_including_depot_unload_1348  925.691754925099
    MARKER    'MARKER'                 'INTEND'
    load_2_11_9  arc_capacity_1087  1
    load_2_11_9  segment_load_conservation_1281  -1
    load_2_11_9  segment_prefix_lb_1282  1
    load_2_11_9  segment_prefix_ub_1283  1
    load_2_11_9  segment_load_conservation_1295  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_10  arc_capacity_1089  -30
    arc_2_11_10  connected_order_arc_1090  -12
    arc_2_11_10  in_degree_1285  1
    arc_2_11_10  out_degree_1291  1
    arc_2_11_10  original_T_including_depot_unload_1348  7.5965235847304257e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_10  arc_capacity_1089  1
    load_2_11_10  segment_load_conservation_1288  -1
    load_2_11_10  segment_prefix_lb_1289  1
    load_2_11_10  segment_prefix_ub_1290  1
    load_2_11_10  segment_load_conservation_1295  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_12  arc_capacity_1091  -30
    arc_2_11_12  connected_order_arc_1092  -12
    arc_2_11_12  out_degree_1291  1
    arc_2_11_12  in_degree_1299  1
    arc_2_11_12  original_T_including_depot_unload_1348  5.7424143497696048e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_12  arc_capacity_1091  1
    load_2_11_12  segment_load_conservation_1295  1
    load_2_11_12  free_load_conservation_1303  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_13  arc_capacity_1093  -30
    arc_2_11_13  connected_order_arc_1094  -12
    arc_2_11_13  out_degree_1291  1
    arc_2_11_13  in_degree_1305  1
    arc_2_11_13  original_T_including_depot_unload_1348  3.5235932354279930e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_13  arc_capacity_1093  1
    load_2_11_13  segment_load_conservation_1295  1
    load_2_11_13  free_load_conservation_1309  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_14  arc_capacity_1095  -30
    arc_2_11_14  connected_order_arc_1096  -12
    arc_2_11_14  out_degree_1291  1
    arc_2_11_14  in_degree_1311  1
    arc_2_11_14  original_T_including_depot_unload_1348  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_14  arc_capacity_1095  1
    load_2_11_14  segment_load_conservation_1295  1
    load_2_11_14  free_load_conservation_1315  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_15  arc_capacity_1097  -30
    arc_2_11_15  connected_order_arc_1098  -12
    arc_2_11_15  out_degree_1291  1
    arc_2_11_15  in_degree_1317  1
    arc_2_11_15  original_T_including_depot_unload_1348  9.1041274142057227e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_15  arc_capacity_1097  1
    load_2_11_15  segment_load_conservation_1295  1
    load_2_11_15  free_load_conservation_1321  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_16  arc_capacity_1099  -30
    arc_2_11_16  connected_order_arc_1100  -12
    arc_2_11_16  out_degree_1291  1
    arc_2_11_16  in_degree_1323  1
    arc_2_11_16  original_T_including_depot_unload_1348  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_16  arc_capacity_1099  1
    load_2_11_16  segment_load_conservation_1295  1
    load_2_11_16  free_load_conservation_1327  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_17  arc_capacity_1101  -30
    arc_2_11_17  connected_order_arc_1102  -12
    arc_2_11_17  out_degree_1291  1
    arc_2_11_17  in_degree_1329  1
    arc_2_11_17  original_T_including_depot_unload_1348  1.0882276141652012e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_17  arc_capacity_1101  1
    load_2_11_17  segment_load_conservation_1295  1
    load_2_11_17  free_load_conservation_1333  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_18  arc_capacity_1103  -30
    arc_2_11_18  connected_order_arc_1104  -12
    arc_2_11_18  out_degree_1291  1
    arc_2_11_18  in_degree_1335  1
    arc_2_11_18  original_T_including_depot_unload_1348  8.8488037837239642e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_18  arc_capacity_1103  1
    load_2_11_18  segment_load_conservation_1295  1
    load_2_11_18  free_load_conservation_1339  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_19  arc_capacity_1105  -30
    arc_2_11_19  connected_order_arc_1106  -12
    arc_2_11_19  out_degree_1291  1
    arc_2_11_19  in_degree_1341  1
    arc_2_11_19  original_T_including_depot_unload_1348  1.6320002720932780e+00
    MARKER    'MARKER'                 'INTEND'
    load_2_11_19  arc_capacity_1105  1
    load_2_11_19  segment_load_conservation_1295  1
    load_2_11_19  free_load_conservation_1345  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_0  arc_capacity_1107  -30
    arc_2_12_0  depot_return_or_bypass_1276  1
    arc_2_12_0  out_degree_1298  1
    arc_2_12_0  original_T_including_depot_unload_1348  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_0  arc_capacity_1107  1
    load_2_12_0  free_load_conservation_1303  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_9  arc_capacity_1108  -30
    arc_2_12_9  connected_order_arc_1109  -12
    arc_2_12_9  in_degree_1278  1
    arc_2_12_9  out_degree_1298  1
    arc_2_12_9  original_T_including_depot_unload_1348  1.0984912119828512e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_9  arc_capacity_1108  1
    load_2_12_9  segment_load_conservation_1281  -1
    load_2_12_9  segment_prefix_lb_1282  1
    load_2_12_9  segment_prefix_ub_1283  1
    load_2_12_9  free_load_conservation_1303  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_10  arc_capacity_1110  -30
    arc_2_12_10  connected_order_arc_1111  -12
    arc_2_12_10  in_degree_1285  1
    arc_2_12_10  out_degree_1298  1
    arc_2_12_10  original_T_including_depot_unload_1348  1.0379751075251477e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_10  arc_capacity_1110  1
    load_2_12_10  segment_load_conservation_1288  -1
    load_2_12_10  segment_prefix_lb_1289  1
    load_2_12_10  segment_prefix_ub_1290  1
    load_2_12_10  free_load_conservation_1303  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_11  arc_capacity_1112  -30
    arc_2_12_11  connected_order_arc_1113  -12
    arc_2_12_11  in_degree_1292  1
    arc_2_12_11  out_degree_1298  1
    arc_2_12_11  original_T_including_depot_unload_1348  5.7424143497696048e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_11  arc_capacity_1112  1
    load_2_12_11  segment_load_conservation_1295  -1
    load_2_12_11  segment_prefix_lb_1296  1
    load_2_12_11  segment_prefix_ub_1297  1
    load_2_12_11  free_load_conservation_1303  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_13  arc_capacity_1114  -30
    arc_2_12_13  connected_order_arc_1115  -12
    arc_2_12_13  out_degree_1298  1
    arc_2_12_13  in_degree_1305  1
    arc_2_12_13  original_T_including_depot_unload_1348  3.7831268047064754e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_13  arc_capacity_1114  1
    load_2_12_13  free_load_conservation_1303  1
    load_2_12_13  free_load_conservation_1309  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_14  arc_capacity_1116  -30
    arc_2_12_14  connected_order_arc_1117  -12
    arc_2_12_14  out_degree_1298  1
    arc_2_12_14  in_degree_1311  1
    arc_2_12_14  original_T_including_depot_unload_1348  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_14  arc_capacity_1116  1
    load_2_12_14  free_load_conservation_1303  1
    load_2_12_14  free_load_conservation_1315  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_15  arc_capacity_1118  -30
    arc_2_12_15  connected_order_arc_1119  -12
    arc_2_12_15  out_degree_1298  1
    arc_2_12_15  in_degree_1317  1
    arc_2_12_15  original_T_including_depot_unload_1348  5.0398976026149836e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_15  arc_capacity_1118  1
    load_2_12_15  free_load_conservation_1303  1
    load_2_12_15  free_load_conservation_1321  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_16  arc_capacity_1120  -30
    arc_2_12_16  connected_order_arc_1121  -12
    arc_2_12_16  out_degree_1298  1
    arc_2_12_16  in_degree_1323  1
    arc_2_12_16  original_T_including_depot_unload_1348  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_2_12_16  arc_capacity_1120  1
    load_2_12_16  free_load_conservation_1303  1
    load_2_12_16  free_load_conservation_1327  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_17  arc_capacity_1122  -30
    arc_2_12_17  connected_order_arc_1123  -12
    arc_2_12_17  out_degree_1298  1
    arc_2_12_17  in_degree_1329  1
    arc_2_12_17  original_T_including_depot_unload_1348  5.5668303114993182e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_17  arc_capacity_1122  1
    load_2_12_17  free_load_conservation_1303  1
    load_2_12_17  free_load_conservation_1333  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_18  arc_capacity_1124  -30
    arc_2_12_18  connected_order_arc_1125  -12
    arc_2_12_18  out_degree_1298  1
    arc_2_12_18  in_degree_1335  1
    arc_2_12_18  original_T_including_depot_unload_1348  608.963327854777
    MARKER    'MARKER'                 'INTEND'
    load_2_12_18  arc_capacity_1124  1
    load_2_12_18  free_load_conservation_1303  1
    load_2_12_18  free_load_conservation_1339  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_19  arc_capacity_1126  -30
    arc_2_12_19  connected_order_arc_1127  -12
    arc_2_12_19  out_degree_1298  1
    arc_2_12_19  in_degree_1341  1
    arc_2_12_19  original_T_including_depot_unload_1348  5.7276146581216926e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_19  arc_capacity_1126  1
    load_2_12_19  free_load_conservation_1303  1
    load_2_12_19  free_load_conservation_1345  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_0  arc_capacity_1128  -30
    arc_2_13_0  depot_return_or_bypass_1276  1
    arc_2_13_0  out_degree_1304  1
    arc_2_13_0  original_T_including_depot_unload_1348  7.9650294035968375e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_0  arc_capacity_1128  1
    load_2_13_0  free_load_conservation_1309  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_9  arc_capacity_1129  -30
    arc_2_13_9  connected_order_arc_1130  -12
    arc_2_13_9  in_degree_1278  1
    arc_2_13_9  out_degree_1304  1
    arc_2_13_9  original_T_including_depot_unload_1348  7.5681404708111961e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_9  arc_capacity_1129  1
    load_2_13_9  segment_load_conservation_1281  -1
    load_2_13_9  segment_prefix_lb_1282  1
    load_2_13_9  segment_prefix_ub_1283  1
    load_2_13_9  free_load_conservation_1309  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_10  arc_capacity_1131  -30
    arc_2_13_10  connected_order_arc_1132  -12
    arc_2_13_10  in_degree_1285  1
    arc_2_13_10  out_degree_1304  1
    arc_2_13_10  original_T_including_depot_unload_1348  6.6735284319782306e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_10  arc_capacity_1131  1
    load_2_13_10  segment_load_conservation_1288  -1
    load_2_13_10  segment_prefix_lb_1289  1
    load_2_13_10  segment_prefix_ub_1290  1
    load_2_13_10  free_load_conservation_1309  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_11  arc_capacity_1133  -30
    arc_2_13_11  connected_order_arc_1134  -12
    arc_2_13_11  in_degree_1292  1
    arc_2_13_11  out_degree_1304  1
    arc_2_13_11  original_T_including_depot_unload_1348  3.5235932354279930e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_11  arc_capacity_1133  1
    load_2_13_11  segment_load_conservation_1295  -1
    load_2_13_11  segment_prefix_lb_1296  1
    load_2_13_11  segment_prefix_ub_1297  1
    load_2_13_11  free_load_conservation_1309  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_12  arc_capacity_1135  -30
    arc_2_13_12  connected_order_arc_1136  -12
    arc_2_13_12  in_degree_1299  1
    arc_2_13_12  out_degree_1304  1
    arc_2_13_12  original_T_including_depot_unload_1348  3.7831268047064754e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_12  arc_capacity_1135  1
    load_2_13_12  free_load_conservation_1303  -1
    load_2_13_12  free_load_conservation_1309  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_14  arc_capacity_1137  -30
    arc_2_13_14  connected_order_arc_1138  -12
    arc_2_13_14  out_degree_1304  1
    arc_2_13_14  in_degree_1311  1
    arc_2_13_14  original_T_including_depot_unload_1348  9.8108674361469946e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_14  arc_capacity_1137  1
    load_2_13_14  free_load_conservation_1309  1
    load_2_13_14  free_load_conservation_1315  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_15  arc_capacity_1139  -30
    arc_2_13_15  connected_order_arc_1140  -12
    arc_2_13_15  out_degree_1304  1
    arc_2_13_15  in_degree_1317  1
    arc_2_13_15  original_T_including_depot_unload_1348  566.256001718161
    MARKER    'MARKER'                 'INTEND'
    load_2_13_15  arc_capacity_1139  1
    load_2_13_15  free_load_conservation_1309  1
    load_2_13_15  free_load_conservation_1321  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_16  arc_capacity_1141  -30
    arc_2_13_16  connected_order_arc_1142  -12
    arc_2_13_16  out_degree_1304  1
    arc_2_13_16  in_degree_1323  1
    arc_2_13_16  original_T_including_depot_unload_1348  5.4405628017126674e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_16  arc_capacity_1141  1
    load_2_13_16  free_load_conservation_1309  1
    load_2_13_16  free_load_conservation_1327  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_17  arc_capacity_1143  -30
    arc_2_13_17  connected_order_arc_1144  -12
    arc_2_13_17  out_degree_1304  1
    arc_2_13_17  in_degree_1329  1
    arc_2_13_17  original_T_including_depot_unload_1348  7.8060605690718819e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_17  arc_capacity_1143  1
    load_2_13_17  free_load_conservation_1309  1
    load_2_13_17  free_load_conservation_1333  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_18  arc_capacity_1145  -30
    arc_2_13_18  connected_order_arc_1146  -12
    arc_2_13_18  out_degree_1304  1
    arc_2_13_18  in_degree_1335  1
    arc_2_13_18  original_T_including_depot_unload_1348  5.3348116005684176e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_18  arc_capacity_1145  1
    load_2_13_18  free_load_conservation_1309  1
    load_2_13_18  free_load_conservation_1339  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_19  arc_capacity_1147  -30
    arc_2_13_19  connected_order_arc_1148  -12
    arc_2_13_19  out_degree_1304  1
    arc_2_13_19  in_degree_1341  1
    arc_2_13_19  original_T_including_depot_unload_1348  3.5166546157461704e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_19  arc_capacity_1147  1
    load_2_13_19  free_load_conservation_1309  1
    load_2_13_19  free_load_conservation_1345  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_0  arc_capacity_1149  -30
    arc_2_14_0  depot_return_or_bypass_1276  1
    arc_2_14_0  out_degree_1310  1
    arc_2_14_0  original_T_including_depot_unload_1348  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_0  arc_capacity_1149  1
    load_2_14_0  free_load_conservation_1315  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_9  arc_capacity_1150  -30
    arc_2_14_9  connected_order_arc_1151  -12
    arc_2_14_9  in_degree_1278  1
    arc_2_14_9  out_degree_1310  1
    arc_2_14_9  original_T_including_depot_unload_1348  2.9139628504456829e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_9  arc_capacity_1150  1
    load_2_14_9  segment_load_conservation_1281  -1
    load_2_14_9  segment_prefix_lb_1282  1
    load_2_14_9  segment_prefix_ub_1283  1
    load_2_14_9  free_load_conservation_1315  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_10  arc_capacity_1152  -30
    arc_2_14_10  connected_order_arc_1153  -12
    arc_2_14_10  in_degree_1285  1
    arc_2_14_10  out_degree_1310  1
    arc_2_14_10  original_T_including_depot_unload_1348  5.1169459347980438e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_10  arc_capacity_1152  1
    load_2_14_10  segment_load_conservation_1288  -1
    load_2_14_10  segment_prefix_lb_1289  1
    load_2_14_10  segment_prefix_ub_1290  1
    load_2_14_10  free_load_conservation_1315  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_11  arc_capacity_1154  -30
    arc_2_14_11  connected_order_arc_1155  -12
    arc_2_14_11  in_degree_1292  1
    arc_2_14_11  out_degree_1310  1
    arc_2_14_11  original_T_including_depot_unload_1348  1.1961671124469858e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_11  arc_capacity_1154  1
    load_2_14_11  segment_load_conservation_1295  -1
    load_2_14_11  segment_prefix_lb_1296  1
    load_2_14_11  segment_prefix_ub_1297  1
    load_2_14_11  free_load_conservation_1315  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_12  arc_capacity_1156  -30
    arc_2_14_12  connected_order_arc_1157  -12
    arc_2_14_12  in_degree_1299  1
    arc_2_14_12  out_degree_1310  1
    arc_2_14_12  original_T_including_depot_unload_1348  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_12  arc_capacity_1156  1
    load_2_14_12  free_load_conservation_1303  -1
    load_2_14_12  free_load_conservation_1315  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_13  arc_capacity_1158  -30
    arc_2_14_13  connected_order_arc_1159  -12
    arc_2_14_13  in_degree_1305  1
    arc_2_14_13  out_degree_1310  1
    arc_2_14_13  original_T_including_depot_unload_1348  9.8108674361469946e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_13  arc_capacity_1158  1
    load_2_14_13  free_load_conservation_1309  -1
    load_2_14_13  free_load_conservation_1315  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_15  arc_capacity_1160  -30
    arc_2_14_15  connected_order_arc_1161  -12
    arc_2_14_15  out_degree_1310  1
    arc_2_14_15  in_degree_1317  1
    arc_2_14_15  original_T_including_depot_unload_1348  1.0063298732365655e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_15  arc_capacity_1160  1
    load_2_14_15  free_load_conservation_1315  1
    load_2_14_15  free_load_conservation_1321  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_16  arc_capacity_1162  -30
    arc_2_14_16  connected_order_arc_1163  -12
    arc_2_14_16  out_degree_1310  1
    arc_2_14_16  in_degree_1323  1
    arc_2_14_16  original_T_including_depot_unload_1348  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_2_14_16  arc_capacity_1162  1
    load_2_14_16  free_load_conservation_1315  1
    load_2_14_16  free_load_conservation_1327  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_17  arc_capacity_1164  -30
    arc_2_14_17  connected_order_arc_1165  -12
    arc_2_14_17  out_degree_1310  1
    arc_2_14_17  in_degree_1329  1
    arc_2_14_17  original_T_including_depot_unload_1348  1.3072142379397485e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_17  arc_capacity_1164  1
    load_2_14_17  free_load_conservation_1315  1
    load_2_14_17  free_load_conservation_1333  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_18  arc_capacity_1166  -30
    arc_2_14_18  connected_order_arc_1167  -12
    arc_2_14_18  out_degree_1310  1
    arc_2_14_18  in_degree_1335  1
    arc_2_14_18  original_T_including_depot_unload_1348  8.0139063451811444e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_18  arc_capacity_1166  1
    load_2_14_18  free_load_conservation_1315  1
    load_2_14_18  free_load_conservation_1339  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_19  arc_capacity_1168  -30
    arc_2_14_19  connected_order_arc_1169  -12
    arc_2_14_19  out_degree_1310  1
    arc_2_14_19  in_degree_1341  1
    arc_2_14_19  original_T_including_depot_unload_1348  1.1967280409234234e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_19  arc_capacity_1168  1
    load_2_14_19  free_load_conservation_1315  1
    load_2_14_19  free_load_conservation_1345  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_0  arc_capacity_1170  -30
    arc_2_15_0  depot_return_or_bypass_1276  1
    arc_2_15_0  out_degree_1316  1
    arc_2_15_0  original_T_including_depot_unload_1348  5.8421641813809208e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_0  arc_capacity_1170  1
    load_2_15_0  free_load_conservation_1321  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_9  arc_capacity_1171  -30
    arc_2_15_9  connected_order_arc_1172  -12
    arc_2_15_9  in_degree_1278  1
    arc_2_15_9  out_degree_1316  1
    arc_2_15_9  original_T_including_depot_unload_1348  9.3170331463979812e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_9  arc_capacity_1171  1
    load_2_15_9  segment_load_conservation_1281  -1
    load_2_15_9  segment_prefix_lb_1282  1
    load_2_15_9  segment_prefix_ub_1283  1
    load_2_15_9  free_load_conservation_1321  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_10  arc_capacity_1173  -30
    arc_2_15_10  connected_order_arc_1174  -12
    arc_2_15_10  in_degree_1285  1
    arc_2_15_10  out_degree_1316  1
    arc_2_15_10  original_T_including_depot_unload_1348  9.7958300464034107e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_10  arc_capacity_1173  1
    load_2_15_10  segment_load_conservation_1288  -1
    load_2_15_10  segment_prefix_lb_1289  1
    load_2_15_10  segment_prefix_ub_1290  1
    load_2_15_10  free_load_conservation_1321  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_11  arc_capacity_1175  -30
    arc_2_15_11  connected_order_arc_1176  -12
    arc_2_15_11  in_degree_1292  1
    arc_2_15_11  out_degree_1316  1
    arc_2_15_11  original_T_including_depot_unload_1348  9.1041274142057227e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_11  arc_capacity_1175  1
    load_2_15_11  segment_load_conservation_1295  -1
    load_2_15_11  segment_prefix_lb_1296  1
    load_2_15_11  segment_prefix_ub_1297  1
    load_2_15_11  free_load_conservation_1321  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_12  arc_capacity_1177  -30
    arc_2_15_12  connected_order_arc_1178  -12
    arc_2_15_12  in_degree_1299  1
    arc_2_15_12  out_degree_1316  1
    arc_2_15_12  original_T_including_depot_unload_1348  5.0398976026149836e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_12  arc_capacity_1177  1
    load_2_15_12  free_load_conservation_1303  -1
    load_2_15_12  free_load_conservation_1321  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_13  arc_capacity_1179  -30
    arc_2_15_13  connected_order_arc_1180  -12
    arc_2_15_13  in_degree_1305  1
    arc_2_15_13  out_degree_1316  1
    arc_2_15_13  original_T_including_depot_unload_1348  566.256001718161
    MARKER    'MARKER'                 'INTEND'
    load_2_15_13  arc_capacity_1179  1
    load_2_15_13  free_load_conservation_1309  -1
    load_2_15_13  free_load_conservation_1321  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_14  arc_capacity_1181  -30
    arc_2_15_14  connected_order_arc_1182  -12
    arc_2_15_14  in_degree_1311  1
    arc_2_15_14  out_degree_1316  1
    arc_2_15_14  original_T_including_depot_unload_1348  1.0063298732365655e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_14  arc_capacity_1181  1
    load_2_15_14  free_load_conservation_1315  -1
    load_2_15_14  free_load_conservation_1321  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_16  arc_capacity_1183  -30
    arc_2_15_16  connected_order_arc_1184  -12
    arc_2_15_16  out_degree_1316  1
    arc_2_15_16  in_degree_1323  1
    arc_2_15_16  original_T_including_depot_unload_1348  3.6822662782562685e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_16  arc_capacity_1183  1
    load_2_15_16  free_load_conservation_1321  1
    load_2_15_16  free_load_conservation_1327  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_17  arc_capacity_1185  -30
    arc_2_15_17  connected_order_arc_1186  -12
    arc_2_15_17  out_degree_1316  1
    arc_2_15_17  in_degree_1329  1
    arc_2_15_17  original_T_including_depot_unload_1348  308.565954837055
    MARKER    'MARKER'                 'INTEND'
    load_2_15_17  arc_capacity_1185  1
    load_2_15_17  free_load_conservation_1321  1
    load_2_15_17  free_load_conservation_1333  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_18  arc_capacity_1187  -30
    arc_2_15_18  connected_order_arc_1188  -12
    arc_2_15_18  out_degree_1316  1
    arc_2_15_18  in_degree_1335  1
    arc_2_15_18  original_T_including_depot_unload_1348  204.956380049771
    MARKER    'MARKER'                 'INTEND'
    load_2_15_18  arc_capacity_1187  1
    load_2_15_18  free_load_conservation_1321  1
    load_2_15_18  free_load_conservation_1339  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_19  arc_capacity_1189  -30
    arc_2_15_19  connected_order_arc_1190  -12
    arc_2_15_19  out_degree_1316  1
    arc_2_15_19  in_degree_1341  1
    arc_2_15_19  original_T_including_depot_unload_1348  9.0947747566405189e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_19  arc_capacity_1189  1
    load_2_15_19  free_load_conservation_1321  1
    load_2_15_19  free_load_conservation_1345  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_0  arc_capacity_1191  -30
    arc_2_16_0  depot_return_or_bypass_1276  1
    arc_2_16_0  out_degree_1322  1
    arc_2_16_0  original_T_including_depot_unload_1348  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_0  arc_capacity_1191  1
    load_2_16_0  free_load_conservation_1327  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_9  arc_capacity_1192  -30
    arc_2_16_9  connected_order_arc_1193  -12
    arc_2_16_9  in_degree_1278  1
    arc_2_16_9  out_degree_1322  1
    arc_2_16_9  original_T_including_depot_unload_1348  5.7914586906741226e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_9  arc_capacity_1192  1
    load_2_16_9  segment_load_conservation_1281  -1
    load_2_16_9  segment_prefix_lb_1282  1
    load_2_16_9  segment_prefix_ub_1283  1
    load_2_16_9  free_load_conservation_1327  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_10  arc_capacity_1194  -30
    arc_2_16_10  connected_order_arc_1195  -12
    arc_2_16_10  in_degree_1285  1
    arc_2_16_10  out_degree_1322  1
    arc_2_16_10  original_T_including_depot_unload_1348  6.6929586395597710e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_10  arc_capacity_1194  1
    load_2_16_10  segment_load_conservation_1288  -1
    load_2_16_10  segment_prefix_lb_1289  1
    load_2_16_10  segment_prefix_ub_1290  1
    load_2_16_10  free_load_conservation_1327  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_11  arc_capacity_1196  -30
    arc_2_16_11  connected_order_arc_1197  -12
    arc_2_16_11  in_degree_1292  1
    arc_2_16_11  out_degree_1322  1
    arc_2_16_11  original_T_including_depot_unload_1348  8.7938298268254312e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_11  arc_capacity_1196  1
    load_2_16_11  segment_load_conservation_1295  -1
    load_2_16_11  segment_prefix_lb_1296  1
    load_2_16_11  segment_prefix_ub_1297  1
    load_2_16_11  free_load_conservation_1327  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_12  arc_capacity_1198  -30
    arc_2_16_12  connected_order_arc_1199  -12
    arc_2_16_12  in_degree_1299  1
    arc_2_16_12  out_degree_1322  1
    arc_2_16_12  original_T_including_depot_unload_1348  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_2_16_12  arc_capacity_1198  1
    load_2_16_12  free_load_conservation_1303  -1
    load_2_16_12  free_load_conservation_1327  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_13  arc_capacity_1200  -30
    arc_2_16_13  connected_order_arc_1201  -12
    arc_2_16_13  in_degree_1305  1
    arc_2_16_13  out_degree_1322  1
    arc_2_16_13  original_T_including_depot_unload_1348  5.4405628017126674e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_13  arc_capacity_1200  1
    load_2_16_13  free_load_conservation_1309  -1
    load_2_16_13  free_load_conservation_1327  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_14  arc_capacity_1202  -30
    arc_2_16_14  connected_order_arc_1203  -12
    arc_2_16_14  in_degree_1311  1
    arc_2_16_14  out_degree_1322  1
    arc_2_16_14  original_T_including_depot_unload_1348  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_2_16_14  arc_capacity_1202  1
    load_2_16_14  free_load_conservation_1315  -1
    load_2_16_14  free_load_conservation_1327  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_15  arc_capacity_1204  -30
    arc_2_16_15  connected_order_arc_1205  -12
    arc_2_16_15  in_degree_1317  1
    arc_2_16_15  out_degree_1322  1
    arc_2_16_15  original_T_including_depot_unload_1348  3.6822662782562685e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_15  arc_capacity_1204  1
    load_2_16_15  free_load_conservation_1321  -1
    load_2_16_15  free_load_conservation_1327  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_17  arc_capacity_1206  -30
    arc_2_16_17  connected_order_arc_1207  -12
    arc_2_16_17  out_degree_1322  1
    arc_2_16_17  in_degree_1329  1
    arc_2_16_17  original_T_including_depot_unload_1348  6.7368811350376711e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_17  arc_capacity_1206  1
    load_2_16_17  free_load_conservation_1327  1
    load_2_16_17  free_load_conservation_1333  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_18  arc_capacity_1208  -30
    arc_2_16_18  connected_order_arc_1209  -12
    arc_2_16_18  out_degree_1322  1
    arc_2_16_18  in_degree_1335  1
    arc_2_16_18  original_T_including_depot_unload_1348  1.6388081578301370e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_18  arc_capacity_1208  1
    load_2_16_18  free_load_conservation_1327  1
    load_2_16_18  free_load_conservation_1339  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_19  arc_capacity_1210  -30
    arc_2_16_19  connected_order_arc_1211  -12
    arc_2_16_19  out_degree_1322  1
    arc_2_16_19  in_degree_1341  1
    arc_2_16_19  original_T_including_depot_unload_1348  8.7906342149593650e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_19  arc_capacity_1210  1
    load_2_16_19  free_load_conservation_1327  1
    load_2_16_19  free_load_conservation_1345  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_0  arc_capacity_1212  -30
    arc_2_17_0  depot_return_or_bypass_1276  1
    arc_2_17_0  out_degree_1328  1
    arc_2_17_0  original_T_including_depot_unload_1348  3.8060477410436619e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_0  arc_capacity_1212  1
    load_2_17_0  free_load_conservation_1333  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_9  arc_capacity_1213  -30
    arc_2_17_9  connected_order_arc_1214  -12
    arc_2_17_9  in_degree_1278  1
    arc_2_17_9  out_degree_1328  1
    arc_2_17_9  original_T_including_depot_unload_1348  1.2401143998876444e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_9  arc_capacity_1213  1
    load_2_17_9  segment_load_conservation_1281  -1
    load_2_17_9  segment_prefix_lb_1282  1
    load_2_17_9  segment_prefix_ub_1283  1
    load_2_17_9  free_load_conservation_1333  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_10  arc_capacity_1215  -30
    arc_2_17_10  connected_order_arc_1216  -12
    arc_2_17_10  in_degree_1285  1
    arc_2_17_10  out_degree_1328  1
    arc_2_17_10  original_T_including_depot_unload_1348  1.2799228371310815e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_10  arc_capacity_1215  1
    load_2_17_10  segment_load_conservation_1288  -1
    load_2_17_10  segment_prefix_lb_1289  1
    load_2_17_10  segment_prefix_ub_1290  1
    load_2_17_10  free_load_conservation_1333  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_11  arc_capacity_1217  -30
    arc_2_17_11  connected_order_arc_1218  -12
    arc_2_17_11  in_degree_1292  1
    arc_2_17_11  out_degree_1328  1
    arc_2_17_11  original_T_including_depot_unload_1348  1.0882276141652012e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_11  arc_capacity_1217  1
    load_2_17_11  segment_load_conservation_1295  -1
    load_2_17_11  segment_prefix_lb_1296  1
    load_2_17_11  segment_prefix_ub_1297  1
    load_2_17_11  free_load_conservation_1333  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_12  arc_capacity_1219  -30
    arc_2_17_12  connected_order_arc_1220  -12
    arc_2_17_12  in_degree_1299  1
    arc_2_17_12  out_degree_1328  1
    arc_2_17_12  original_T_including_depot_unload_1348  5.5668303114993182e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_12  arc_capacity_1219  1
    load_2_17_12  free_load_conservation_1303  -1
    load_2_17_12  free_load_conservation_1333  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_13  arc_capacity_1221  -30
    arc_2_17_13  connected_order_arc_1222  -12
    arc_2_17_13  in_degree_1305  1
    arc_2_17_13  out_degree_1328  1
    arc_2_17_13  original_T_including_depot_unload_1348  7.8060605690718819e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_13  arc_capacity_1221  1
    load_2_17_13  free_load_conservation_1309  -1
    load_2_17_13  free_load_conservation_1333  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_14  arc_capacity_1223  -30
    arc_2_17_14  connected_order_arc_1224  -12
    arc_2_17_14  in_degree_1311  1
    arc_2_17_14  out_degree_1328  1
    arc_2_17_14  original_T_including_depot_unload_1348  1.3072142379397485e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_14  arc_capacity_1223  1
    load_2_17_14  free_load_conservation_1315  -1
    load_2_17_14  free_load_conservation_1333  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_15  arc_capacity_1225  -30
    arc_2_17_15  connected_order_arc_1226  -12
    arc_2_17_15  in_degree_1317  1
    arc_2_17_15  out_degree_1328  1
    arc_2_17_15  original_T_including_depot_unload_1348  308.565954837055
    MARKER    'MARKER'                 'INTEND'
    load_2_17_15  arc_capacity_1225  1
    load_2_17_15  free_load_conservation_1321  -1
    load_2_17_15  free_load_conservation_1333  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_16  arc_capacity_1227  -30
    arc_2_17_16  connected_order_arc_1228  -12
    arc_2_17_16  in_degree_1323  1
    arc_2_17_16  out_degree_1328  1
    arc_2_17_16  original_T_including_depot_unload_1348  6.7368811350376711e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_16  arc_capacity_1227  1
    load_2_17_16  free_load_conservation_1327  -1
    load_2_17_16  free_load_conservation_1333  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_18  arc_capacity_1229  -30
    arc_2_17_18  connected_order_arc_1230  -12
    arc_2_17_18  out_degree_1328  1
    arc_2_17_18  in_degree_1335  1
    arc_2_17_18  original_T_including_depot_unload_1348  5.0986619729981788e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_18  arc_capacity_1229  1
    load_2_17_18  free_load_conservation_1333  1
    load_2_17_18  free_load_conservation_1339  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_19  arc_capacity_1231  -30
    arc_2_17_19  connected_order_arc_1232  -12
    arc_2_17_19  out_degree_1328  1
    arc_2_17_19  in_degree_1341  1
    arc_2_17_19  original_T_including_depot_unload_1348  1.0869859877715128e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_19  arc_capacity_1231  1
    load_2_17_19  free_load_conservation_1333  1
    load_2_17_19  free_load_conservation_1345  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_0  arc_capacity_1233  -30
    arc_2_18_0  depot_return_or_bypass_1276  1
    arc_2_18_0  out_degree_1334  1
    arc_2_18_0  original_T_including_depot_unload_1348  778.011461754062
    MARKER    'MARKER'                 'INTEND'
    load_2_18_0  arc_capacity_1233  1
    load_2_18_0  free_load_conservation_1339  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_9  arc_capacity_1234  -30
    arc_2_18_9  connected_order_arc_1235  -12
    arc_2_18_9  in_degree_1278  1
    arc_2_18_9  out_degree_1334  1
    arc_2_18_9  original_T_including_depot_unload_1348  7.3693716289230485e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_9  arc_capacity_1234  1
    load_2_18_9  segment_load_conservation_1281  -1
    load_2_18_9  segment_prefix_lb_1282  1
    load_2_18_9  segment_prefix_ub_1283  1
    load_2_18_9  free_load_conservation_1339  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_10  arc_capacity_1236  -30
    arc_2_18_10  connected_order_arc_1237  -12
    arc_2_18_10  in_degree_1285  1
    arc_2_18_10  out_degree_1334  1
    arc_2_18_10  original_T_including_depot_unload_1348  8.0681198709780529e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_10  arc_capacity_1236  1
    load_2_18_10  segment_load_conservation_1288  -1
    load_2_18_10  segment_prefix_lb_1289  1
    load_2_18_10  segment_prefix_ub_1290  1
    load_2_18_10  free_load_conservation_1339  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_11  arc_capacity_1238  -30
    arc_2_18_11  connected_order_arc_1239  -12
    arc_2_18_11  in_degree_1292  1
    arc_2_18_11  out_degree_1334  1
    arc_2_18_11  original_T_including_depot_unload_1348  8.8488037837239642e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_11  arc_capacity_1238  1
    load_2_18_11  segment_load_conservation_1295  -1
    load_2_18_11  segment_prefix_lb_1296  1
    load_2_18_11  segment_prefix_ub_1297  1
    load_2_18_11  free_load_conservation_1339  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_12  arc_capacity_1240  -30
    arc_2_18_12  connected_order_arc_1241  -12
    arc_2_18_12  in_degree_1299  1
    arc_2_18_12  out_degree_1334  1
    arc_2_18_12  original_T_including_depot_unload_1348  608.963327854777
    MARKER    'MARKER'                 'INTEND'
    load_2_18_12  arc_capacity_1240  1
    load_2_18_12  free_load_conservation_1303  -1
    load_2_18_12  free_load_conservation_1339  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_13  arc_capacity_1242  -30
    arc_2_18_13  connected_order_arc_1243  -12
    arc_2_18_13  in_degree_1305  1
    arc_2_18_13  out_degree_1334  1
    arc_2_18_13  original_T_including_depot_unload_1348  5.3348116005684176e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_13  arc_capacity_1242  1
    load_2_18_13  free_load_conservation_1309  -1
    load_2_18_13  free_load_conservation_1339  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_14  arc_capacity_1244  -30
    arc_2_18_14  connected_order_arc_1245  -12
    arc_2_18_14  in_degree_1311  1
    arc_2_18_14  out_degree_1334  1
    arc_2_18_14  original_T_including_depot_unload_1348  8.0139063451811444e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_14  arc_capacity_1244  1
    load_2_18_14  free_load_conservation_1315  -1
    load_2_18_14  free_load_conservation_1339  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_15  arc_capacity_1246  -30
    arc_2_18_15  connected_order_arc_1247  -12
    arc_2_18_15  in_degree_1317  1
    arc_2_18_15  out_degree_1334  1
    arc_2_18_15  original_T_including_depot_unload_1348  204.956380049771
    MARKER    'MARKER'                 'INTEND'
    load_2_18_15  arc_capacity_1246  1
    load_2_18_15  free_load_conservation_1321  -1
    load_2_18_15  free_load_conservation_1339  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_16  arc_capacity_1248  -30
    arc_2_18_16  connected_order_arc_1249  -12
    arc_2_18_16  in_degree_1323  1
    arc_2_18_16  out_degree_1334  1
    arc_2_18_16  original_T_including_depot_unload_1348  1.6388081578301370e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_16  arc_capacity_1248  1
    load_2_18_16  free_load_conservation_1327  -1
    load_2_18_16  free_load_conservation_1339  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_17  arc_capacity_1250  -30
    arc_2_18_17  connected_order_arc_1251  -12
    arc_2_18_17  in_degree_1329  1
    arc_2_18_17  out_degree_1334  1
    arc_2_18_17  original_T_including_depot_unload_1348  5.0986619729981788e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_17  arc_capacity_1250  1
    load_2_18_17  free_load_conservation_1333  -1
    load_2_18_17  free_load_conservation_1339  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_19  arc_capacity_1252  -30
    arc_2_18_19  connected_order_arc_1253  -12
    arc_2_18_19  out_degree_1334  1
    arc_2_18_19  in_degree_1341  1
    arc_2_18_19  original_T_including_depot_unload_1348  8.8427037135592116e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_19  arc_capacity_1252  1
    load_2_18_19  free_load_conservation_1339  1
    load_2_18_19  free_load_conservation_1345  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_0  arc_capacity_1254  -30
    arc_2_19_0  depot_return_or_bypass_1276  1
    arc_2_19_0  out_degree_1340  1
    arc_2_19_0  original_T_including_depot_unload_1348  1.0056399980521732e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_0  arc_capacity_1254  1
    load_2_19_0  free_load_conservation_1345  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_9  arc_capacity_1255  -30
    arc_2_19_9  connected_order_arc_1256  -12
    arc_2_19_9  in_degree_1278  1
    arc_2_19_9  out_degree_1340  1
    arc_2_19_9  original_T_including_depot_unload_1348  926.407625506948
    MARKER    'MARKER'                 'INTEND'
    load_2_19_9  arc_capacity_1255  1
    load_2_19_9  segment_load_conservation_1281  -1
    load_2_19_9  segment_prefix_lb_1282  1
    load_2_19_9  segment_prefix_ub_1283  1
    load_2_19_9  free_load_conservation_1345  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_10  arc_capacity_1257  -30
    arc_2_19_10  connected_order_arc_1258  -12
    arc_2_19_10  in_degree_1285  1
    arc_2_19_10  out_degree_1340  1
    arc_2_19_10  original_T_including_depot_unload_1348  7.6061661180217550e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_10  arc_capacity_1257  1
    load_2_19_10  segment_load_conservation_1288  -1
    load_2_19_10  segment_prefix_lb_1289  1
    load_2_19_10  segment_prefix_ub_1290  1
    load_2_19_10  free_load_conservation_1345  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_11  arc_capacity_1259  -30
    arc_2_19_11  connected_order_arc_1260  -12
    arc_2_19_11  in_degree_1292  1
    arc_2_19_11  out_degree_1340  1
    arc_2_19_11  original_T_including_depot_unload_1348  1.6320002720932780e+00
    MARKER    'MARKER'                 'INTEND'
    load_2_19_11  arc_capacity_1259  1
    load_2_19_11  segment_load_conservation_1295  -1
    load_2_19_11  segment_prefix_lb_1296  1
    load_2_19_11  segment_prefix_ub_1297  1
    load_2_19_11  free_load_conservation_1345  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_12  arc_capacity_1261  -30
    arc_2_19_12  connected_order_arc_1262  -12
    arc_2_19_12  in_degree_1299  1
    arc_2_19_12  out_degree_1340  1
    arc_2_19_12  original_T_including_depot_unload_1348  5.7276146581216926e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_12  arc_capacity_1261  1
    load_2_19_12  free_load_conservation_1303  -1
    load_2_19_12  free_load_conservation_1345  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_13  arc_capacity_1263  -30
    arc_2_19_13  connected_order_arc_1264  -12
    arc_2_19_13  in_degree_1305  1
    arc_2_19_13  out_degree_1340  1
    arc_2_19_13  original_T_including_depot_unload_1348  3.5166546157461704e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_13  arc_capacity_1263  1
    load_2_19_13  free_load_conservation_1309  -1
    load_2_19_13  free_load_conservation_1345  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_14  arc_capacity_1265  -30
    arc_2_19_14  connected_order_arc_1266  -12
    arc_2_19_14  in_degree_1311  1
    arc_2_19_14  out_degree_1340  1
    arc_2_19_14  original_T_including_depot_unload_1348  1.1967280409234234e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_14  arc_capacity_1265  1
    load_2_19_14  free_load_conservation_1315  -1
    load_2_19_14  free_load_conservation_1345  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_15  arc_capacity_1267  -30
    arc_2_19_15  connected_order_arc_1268  -12
    arc_2_19_15  in_degree_1317  1
    arc_2_19_15  out_degree_1340  1
    arc_2_19_15  original_T_including_depot_unload_1348  9.0947747566405189e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_15  arc_capacity_1267  1
    load_2_19_15  free_load_conservation_1321  -1
    load_2_19_15  free_load_conservation_1345  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_16  arc_capacity_1269  -30
    arc_2_19_16  connected_order_arc_1270  -12
    arc_2_19_16  in_degree_1323  1
    arc_2_19_16  out_degree_1340  1
    arc_2_19_16  original_T_including_depot_unload_1348  8.7906342149593650e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_16  arc_capacity_1269  1
    load_2_19_16  free_load_conservation_1327  -1
    load_2_19_16  free_load_conservation_1345  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_17  arc_capacity_1271  -30
    arc_2_19_17  connected_order_arc_1272  -12
    arc_2_19_17  in_degree_1329  1
    arc_2_19_17  out_degree_1340  1
    arc_2_19_17  original_T_including_depot_unload_1348  1.0869859877715128e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_17  arc_capacity_1271  1
    load_2_19_17  free_load_conservation_1333  -1
    load_2_19_17  free_load_conservation_1345  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_18  arc_capacity_1273  -30
    arc_2_19_18  connected_order_arc_1274  -12
    arc_2_19_18  in_degree_1335  1
    arc_2_19_18  out_degree_1340  1
    arc_2_19_18  original_T_including_depot_unload_1348  8.8427037135592116e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_18  arc_capacity_1273  1
    load_2_19_18  free_load_conservation_1339  -1
    load_2_19_18  free_load_conservation_1345  1
RHS
    RHS1      OBJ       -2.2495812770575496e-01
    RHS1      onehot_22_32  1
    RHS1      onehot_26_53  1
    RHS1      onehot_34_88  1
    RHS1      onehot_23_99  1
    RHS1      onehot_27_116  1
    RHS1      onehot_21_133  1
    RHS1      onehot_25_146  1
    RHS1      onehot_28_163  1
    RHS1      stock_ub_167  16
    RHS1      parent_nonstrict_scope_168  2.8616270184742765e-01
    RHS1      normalization_225  1
    RHS1      connected_order_arc_305  -12
    RHS1      connected_order_arc_307  -12
    RHS1      connected_order_arc_309  -12
    RHS1      connected_order_arc_311  -12
    RHS1      connected_order_arc_313  -12
    RHS1      connected_order_arc_315  -12
    RHS1      connected_order_arc_317  -12
    RHS1      connected_order_arc_319  -12
    RHS1      connected_order_arc_321  -12
    RHS1      connected_order_arc_323  -12
    RHS1      connected_order_arc_325  -12
    RHS1      connected_order_arc_328  -12
    RHS1      connected_order_arc_330  -12
    RHS1      connected_order_arc_332  -12
    RHS1      connected_order_arc_334  -12
    RHS1      connected_order_arc_336  -12
    RHS1      connected_order_arc_338  -12
    RHS1      connected_order_arc_340  -12
    RHS1      connected_order_arc_342  -12
    RHS1      connected_order_arc_344  -12
    RHS1      connected_order_arc_346  -12
    RHS1      connected_order_arc_348  -12
    RHS1      connected_order_arc_351  -12
    RHS1      connected_order_arc_353  -12
    RHS1      connected_order_arc_355  -12
    RHS1      connected_order_arc_357  -12
    RHS1      connected_order_arc_359  -12
    RHS1      connected_order_arc_361  -12
    RHS1      connected_order_arc_363  -12
    RHS1      connected_order_arc_365  -12
    RHS1      connected_order_arc_367  -12
    RHS1      connected_order_arc_369  -12
    RHS1      connected_order_arc_371  -12
    RHS1      connected_order_arc_374  -12
    RHS1      connected_order_arc_376  -12
    RHS1      connected_order_arc_378  -12
    RHS1      connected_order_arc_380  -12
    RHS1      connected_order_arc_382  -12
    RHS1      connected_order_arc_384  -12
    RHS1      connected_order_arc_386  -12
    RHS1      connected_order_arc_388  -12
    RHS1      connected_order_arc_390  -12
    RHS1      connected_order_arc_392  -12
    RHS1      connected_order_arc_394  -12
    RHS1      connected_order_arc_397  -12
    RHS1      connected_order_arc_399  -12
    RHS1      connected_order_arc_401  -12
    RHS1      connected_order_arc_403  -12
    RHS1      connected_order_arc_405  -12
    RHS1      connected_order_arc_407  -12
    RHS1      connected_order_arc_409  -12
    RHS1      connected_order_arc_411  -12
    RHS1      connected_order_arc_413  -12
    RHS1      connected_order_arc_415  -12
    RHS1      connected_order_arc_417  -12
    RHS1      connected_order_arc_420  -12
    RHS1      connected_order_arc_422  -12
    RHS1      connected_order_arc_424  -12
    RHS1      connected_order_arc_426  -12
    RHS1      connected_order_arc_428  -12
    RHS1      connected_order_arc_430  -12
    RHS1      connected_order_arc_432  -12
    RHS1      connected_order_arc_434  -12
    RHS1      connected_order_arc_436  -12
    RHS1      connected_order_arc_438  -12
    RHS1      connected_order_arc_440  -12
    RHS1      connected_order_arc_443  -12
    RHS1      connected_order_arc_445  -12
    RHS1      connected_order_arc_447  -12
    RHS1      connected_order_arc_449  -12
    RHS1      connected_order_arc_451  -12
    RHS1      connected_order_arc_453  -12
    RHS1      connected_order_arc_455  -12
    RHS1      connected_order_arc_457  -12
    RHS1      connected_order_arc_459  -12
    RHS1      connected_order_arc_461  -12
    RHS1      connected_order_arc_463  -12
    RHS1      connected_order_arc_466  -12
    RHS1      connected_order_arc_468  -12
    RHS1      connected_order_arc_470  -12
    RHS1      connected_order_arc_472  -12
    RHS1      connected_order_arc_474  -12
    RHS1      connected_order_arc_476  -12
    RHS1      connected_order_arc_478  -12
    RHS1      connected_order_arc_480  -12
    RHS1      connected_order_arc_482  -12
    RHS1      connected_order_arc_484  -12
    RHS1      connected_order_arc_486  -12
    RHS1      connected_order_arc_489  -12
    RHS1      connected_order_arc_491  -12
    RHS1      connected_order_arc_493  -12
    RHS1      connected_order_arc_495  -12
    RHS1      connected_order_arc_497  -12
    RHS1      connected_order_arc_499  -12
    RHS1      connected_order_arc_501  -12
    RHS1      connected_order_arc_503  -12
    RHS1      connected_order_arc_505  -12
    RHS1      connected_order_arc_507  -12
    RHS1      connected_order_arc_509  -12
    RHS1      connected_order_arc_512  -12
    RHS1      connected_order_arc_514  -12
    RHS1      connected_order_arc_516  -12
    RHS1      connected_order_arc_518  -12
    RHS1      connected_order_arc_520  -12
    RHS1      connected_order_arc_522  -12
    RHS1      connected_order_arc_524  -12
    RHS1      connected_order_arc_526  -12
    RHS1      connected_order_arc_528  -12
    RHS1      connected_order_arc_530  -12
    RHS1      connected_order_arc_532  -12
    RHS1      connected_order_arc_535  -12
    RHS1      connected_order_arc_537  -12
    RHS1      connected_order_arc_539  -12
    RHS1      connected_order_arc_541  -12
    RHS1      connected_order_arc_543  -12
    RHS1      connected_order_arc_545  -12
    RHS1      connected_order_arc_547  -12
    RHS1      connected_order_arc_549  -12
    RHS1      connected_order_arc_551  -12
    RHS1      connected_order_arc_553  -12
    RHS1      connected_order_arc_555  -12
    RHS1      connected_order_arc_558  -12
    RHS1      connected_order_arc_560  -12
    RHS1      connected_order_arc_562  -12
    RHS1      connected_order_arc_564  -12
    RHS1      connected_order_arc_566  -12
    RHS1      connected_order_arc_568  -12
    RHS1      connected_order_arc_570  -12
    RHS1      connected_order_arc_572  -12
    RHS1      connected_order_arc_574  -12
    RHS1      connected_order_arc_576  -12
    RHS1      connected_order_arc_578  -12
    RHS1      depot_departure_or_bypass_579  1
    RHS1      depot_return_or_bypass_580  1
    RHS1      segment_load_conservation_585  2
    RHS1      segment_prefix_ub_587  9
    RHS1      segment_load_conservation_592  5
    RHS1      segment_prefix_ub_594  15
    RHS1      segment_load_conservation_599  -4
    RHS1      segment_prefix_lb_600  4
    RHS1      segment_prefix_ub_601  20
    RHS1      segment_load_conservation_606  2
    RHS1      segment_prefix_ub_608  18
    RHS1      fixed_segment_relative_order_657  1
    RHS1      fixed_segment_relative_order_658  1
    RHS1      fixed_segment_relative_order_659  1
    RHS1      original_T_including_depot_unload_660  1.6098802582214093e+03
    RHS1      connected_order_arc_676  -12
    RHS1      connected_order_arc_678  -12
    RHS1      connected_order_arc_680  -12
    RHS1      connected_order_arc_682  -12
    RHS1      connected_order_arc_684  -12
    RHS1      connected_order_arc_686  -12
    RHS1      connected_order_arc_688  -12
    RHS1      connected_order_arc_690  -12
    RHS1      connected_order_arc_692  -12
    RHS1      connected_order_arc_694  -12
    RHS1      connected_order_arc_696  -12
    RHS1      connected_order_arc_699  -12
    RHS1      connected_order_arc_701  -12
    RHS1      connected_order_arc_703  -12
    RHS1      connected_order_arc_705  -12
    RHS1      connected_order_arc_707  -12
    RHS1      connected_order_arc_709  -12
    RHS1      connected_order_arc_711  -12
    RHS1      connected_order_arc_713  -12
    RHS1      connected_order_arc_715  -12
    RHS1      connected_order_arc_717  -12
    RHS1      connected_order_arc_719  -12
    RHS1      connected_order_arc_722  -12
    RHS1      connected_order_arc_724  -12
    RHS1      connected_order_arc_726  -12
    RHS1      connected_order_arc_728  -12
    RHS1      connected_order_arc_730  -12
    RHS1      connected_order_arc_732  -12
    RHS1      connected_order_arc_734  -12
    RHS1      connected_order_arc_736  -12
    RHS1      connected_order_arc_738  -12
    RHS1      connected_order_arc_740  -12
    RHS1      connected_order_arc_742  -12
    RHS1      connected_order_arc_745  -12
    RHS1      connected_order_arc_747  -12
    RHS1      connected_order_arc_749  -12
    RHS1      connected_order_arc_751  -12
    RHS1      connected_order_arc_753  -12
    RHS1      connected_order_arc_755  -12
    RHS1      connected_order_arc_757  -12
    RHS1      connected_order_arc_759  -12
    RHS1      connected_order_arc_761  -12
    RHS1      connected_order_arc_763  -12
    RHS1      connected_order_arc_765  -12
    RHS1      connected_order_arc_768  -12
    RHS1      connected_order_arc_770  -12
    RHS1      connected_order_arc_772  -12
    RHS1      connected_order_arc_774  -12
    RHS1      connected_order_arc_776  -12
    RHS1      connected_order_arc_778  -12
    RHS1      connected_order_arc_780  -12
    RHS1      connected_order_arc_782  -12
    RHS1      connected_order_arc_784  -12
    RHS1      connected_order_arc_786  -12
    RHS1      connected_order_arc_788  -12
    RHS1      connected_order_arc_791  -12
    RHS1      connected_order_arc_793  -12
    RHS1      connected_order_arc_795  -12
    RHS1      connected_order_arc_797  -12
    RHS1      connected_order_arc_799  -12
    RHS1      connected_order_arc_801  -12
    RHS1      connected_order_arc_803  -12
    RHS1      connected_order_arc_805  -12
    RHS1      connected_order_arc_807  -12
    RHS1      connected_order_arc_809  -12
    RHS1      connected_order_arc_811  -12
    RHS1      connected_order_arc_814  -12
    RHS1      connected_order_arc_816  -12
    RHS1      connected_order_arc_818  -12
    RHS1      connected_order_arc_820  -12
    RHS1      connected_order_arc_822  -12
    RHS1      connected_order_arc_824  -12
    RHS1      connected_order_arc_826  -12
    RHS1      connected_order_arc_828  -12
    RHS1      connected_order_arc_830  -12
    RHS1      connected_order_arc_832  -12
    RHS1      connected_order_arc_834  -12
    RHS1      connected_order_arc_837  -12
    RHS1      connected_order_arc_839  -12
    RHS1      connected_order_arc_841  -12
    RHS1      connected_order_arc_843  -12
    RHS1      connected_order_arc_845  -12
    RHS1      connected_order_arc_847  -12
    RHS1      connected_order_arc_849  -12
    RHS1      connected_order_arc_851  -12
    RHS1      connected_order_arc_853  -12
    RHS1      connected_order_arc_855  -12
    RHS1      connected_order_arc_857  -12
    RHS1      connected_order_arc_860  -12
    RHS1      connected_order_arc_862  -12
    RHS1      connected_order_arc_864  -12
    RHS1      connected_order_arc_866  -12
    RHS1      connected_order_arc_868  -12
    RHS1      connected_order_arc_870  -12
    RHS1      connected_order_arc_872  -12
    RHS1      connected_order_arc_874  -12
    RHS1      connected_order_arc_876  -12
    RHS1      connected_order_arc_878  -12
    RHS1      connected_order_arc_880  -12
    RHS1      connected_order_arc_883  -12
    RHS1      connected_order_arc_885  -12
    RHS1      connected_order_arc_887  -12
    RHS1      connected_order_arc_889  -12
    RHS1      connected_order_arc_891  -12
    RHS1      connected_order_arc_893  -12
    RHS1      connected_order_arc_895  -12
    RHS1      connected_order_arc_897  -12
    RHS1      connected_order_arc_899  -12
    RHS1      connected_order_arc_901  -12
    RHS1      connected_order_arc_903  -12
    RHS1      connected_order_arc_906  -12
    RHS1      connected_order_arc_908  -12
    RHS1      connected_order_arc_910  -12
    RHS1      connected_order_arc_912  -12
    RHS1      connected_order_arc_914  -12
    RHS1      connected_order_arc_916  -12
    RHS1      connected_order_arc_918  -12
    RHS1      connected_order_arc_920  -12
    RHS1      connected_order_arc_922  -12
    RHS1      connected_order_arc_924  -12
    RHS1      connected_order_arc_926  -12
    RHS1      connected_order_arc_929  -12
    RHS1      connected_order_arc_931  -12
    RHS1      connected_order_arc_933  -12
    RHS1      connected_order_arc_935  -12
    RHS1      connected_order_arc_937  -12
    RHS1      connected_order_arc_939  -12
    RHS1      connected_order_arc_941  -12
    RHS1      connected_order_arc_943  -12
    RHS1      connected_order_arc_945  -12
    RHS1      connected_order_arc_947  -12
    RHS1      connected_order_arc_949  -12
    RHS1      depot_departure_or_bypass_950  1
    RHS1      depot_return_or_bypass_951  1
    RHS1      segment_load_conservation_956  5
    RHS1      segment_prefix_ub_958  20
    RHS1      segment_load_conservation_963  5
    RHS1      segment_prefix_ub_965  20
    RHS1      segment_load_conservation_970  -4
    RHS1      segment_prefix_lb_971  4
    RHS1      segment_prefix_ub_972  25
    RHS1      segment_load_conservation_977  -6
    RHS1      segment_prefix_lb_978  6
    RHS1      segment_prefix_ub_979  25
    RHS1      fixed_segment_relative_order_1028  1
    RHS1      fixed_segment_relative_order_1029  1
    RHS1      fixed_segment_relative_order_1030  1
    RHS1      original_T_including_depot_unload_1031  5100
    RHS1      connected_order_arc_1046  -11
    RHS1      connected_order_arc_1048  -11
    RHS1      connected_order_arc_1050  -11
    RHS1      connected_order_arc_1052  -11
    RHS1      connected_order_arc_1054  -11
    RHS1      connected_order_arc_1056  -11
    RHS1      connected_order_arc_1058  -11
    RHS1      connected_order_arc_1060  -11
    RHS1      connected_order_arc_1062  -11
    RHS1      connected_order_arc_1064  -11
    RHS1      connected_order_arc_1067  -11
    RHS1      connected_order_arc_1069  -11
    RHS1      connected_order_arc_1071  -11
    RHS1      connected_order_arc_1073  -11
    RHS1      connected_order_arc_1075  -11
    RHS1      connected_order_arc_1077  -11
    RHS1      connected_order_arc_1079  -11
    RHS1      connected_order_arc_1081  -11
    RHS1      connected_order_arc_1083  -11
    RHS1      connected_order_arc_1085  -11
    RHS1      connected_order_arc_1088  -11
    RHS1      connected_order_arc_1090  -11
    RHS1      connected_order_arc_1092  -11
    RHS1      connected_order_arc_1094  -11
    RHS1      connected_order_arc_1096  -11
    RHS1      connected_order_arc_1098  -11
    RHS1      connected_order_arc_1100  -11
    RHS1      connected_order_arc_1102  -11
    RHS1      connected_order_arc_1104  -11
    RHS1      connected_order_arc_1106  -11
    RHS1      connected_order_arc_1109  -11
    RHS1      connected_order_arc_1111  -11
    RHS1      connected_order_arc_1113  -11
    RHS1      connected_order_arc_1115  -11
    RHS1      connected_order_arc_1117  -11
    RHS1      connected_order_arc_1119  -11
    RHS1      connected_order_arc_1121  -11
    RHS1      connected_order_arc_1123  -11
    RHS1      connected_order_arc_1125  -11
    RHS1      connected_order_arc_1127  -11
    RHS1      connected_order_arc_1130  -11
    RHS1      connected_order_arc_1132  -11
    RHS1      connected_order_arc_1134  -11
    RHS1      connected_order_arc_1136  -11
    RHS1      connected_order_arc_1138  -11
    RHS1      connected_order_arc_1140  -11
    RHS1      connected_order_arc_1142  -11
    RHS1      connected_order_arc_1144  -11
    RHS1      connected_order_arc_1146  -11
    RHS1      connected_order_arc_1148  -11
    RHS1      connected_order_arc_1151  -11
    RHS1      connected_order_arc_1153  -11
    RHS1      connected_order_arc_1155  -11
    RHS1      connected_order_arc_1157  -11
    RHS1      connected_order_arc_1159  -11
    RHS1      connected_order_arc_1161  -11
    RHS1      connected_order_arc_1163  -11
    RHS1      connected_order_arc_1165  -11
    RHS1      connected_order_arc_1167  -11
    RHS1      connected_order_arc_1169  -11
    RHS1      connected_order_arc_1172  -11
    RHS1      connected_order_arc_1174  -11
    RHS1      connected_order_arc_1176  -11
    RHS1      connected_order_arc_1178  -11
    RHS1      connected_order_arc_1180  -11
    RHS1      connected_order_arc_1182  -11
    RHS1      connected_order_arc_1184  -11
    RHS1      connected_order_arc_1186  -11
    RHS1      connected_order_arc_1188  -11
    RHS1      connected_order_arc_1190  -11
    RHS1      connected_order_arc_1193  -11
    RHS1      connected_order_arc_1195  -11
    RHS1      connected_order_arc_1197  -11
    RHS1      connected_order_arc_1199  -11
    RHS1      connected_order_arc_1201  -11
    RHS1      connected_order_arc_1203  -11
    RHS1      connected_order_arc_1205  -11
    RHS1      connected_order_arc_1207  -11
    RHS1      connected_order_arc_1209  -11
    RHS1      connected_order_arc_1211  -11
    RHS1      connected_order_arc_1214  -11
    RHS1      connected_order_arc_1216  -11
    RHS1      connected_order_arc_1218  -11
    RHS1      connected_order_arc_1220  -11
    RHS1      connected_order_arc_1222  -11
    RHS1      connected_order_arc_1224  -11
    RHS1      connected_order_arc_1226  -11
    RHS1      connected_order_arc_1228  -11
    RHS1      connected_order_arc_1230  -11
    RHS1      connected_order_arc_1232  -11
    RHS1      connected_order_arc_1235  -11
    RHS1      connected_order_arc_1237  -11
    RHS1      connected_order_arc_1239  -11
    RHS1      connected_order_arc_1241  -11
    RHS1      connected_order_arc_1243  -11
    RHS1      connected_order_arc_1245  -11
    RHS1      connected_order_arc_1247  -11
    RHS1      connected_order_arc_1249  -11
    RHS1      connected_order_arc_1251  -11
    RHS1      connected_order_arc_1253  -11
    RHS1      connected_order_arc_1256  -11
    RHS1      connected_order_arc_1258  -11
    RHS1      connected_order_arc_1260  -11
    RHS1      connected_order_arc_1262  -11
    RHS1      connected_order_arc_1264  -11
    RHS1      connected_order_arc_1266  -11
    RHS1      connected_order_arc_1268  -11
    RHS1      connected_order_arc_1270  -11
    RHS1      connected_order_arc_1272  -11
    RHS1      connected_order_arc_1274  -11
    RHS1      depot_departure_or_bypass_1275  1
    RHS1      depot_return_or_bypass_1276  1
    RHS1      segment_load_conservation_1281  2
    RHS1      segment_prefix_ub_1283  28
    RHS1      segment_load_conservation_1288  -1
    RHS1      segment_prefix_lb_1289  4
    RHS1      segment_prefix_ub_1290  30
    RHS1      segment_load_conservation_1295  -1
    RHS1      segment_prefix_lb_1296  1
    RHS1      segment_prefix_ub_1297  30
    RHS1      fixed_segment_relative_order_1346  1
    RHS1      fixed_segment_relative_order_1347  1
    RHS1      original_T_including_depot_unload_1348  3.9148449150211036e+03
BOUNDS
 LO BND1      t         2.4518388791569173e-02
 UP BND1      t         4.2073628850530440e-02
 UP BND1      q         4.2393967896198825e-01
 BV BND1      x_22_0  
 UP BND1      w_22_0    4.2073628850530440e-02
 BV BND1      x_22_1  
 UP BND1      w_22_1    4.2073628850530440e-02
 BV BND1      x_22_2  
 UP BND1      w_22_2    4.2073628850530440e-02
 BV BND1      x_22_3  
 UP BND1      w_22_3    4.2073628850530440e-02
 BV BND1      x_22_4  
 UP BND1      w_22_4    4.2073628850530440e-02
 BV BND1      x_22_5  
 UP BND1      w_22_5    4.2073628850530440e-02
 BV BND1      x_22_6  
 UP BND1      w_22_6    4.2073628850530440e-02
 BV BND1      x_22_7  
 UP BND1      w_22_7    4.2073628850530440e-02
 BV BND1      x_22_8  
 UP BND1      w_22_8    4.2073628850530440e-02
 BV BND1      x_22_9  
 UP BND1      w_22_9    4.2073628850530440e-02
 BV BND1      x_22_10 
 UP BND1      w_22_10   4.2073628850530440e-02
 BV BND1      x_22_11 
 UP BND1      w_22_11   4.2073628850530440e-02
 BV BND1      x_22_12 
 UP BND1      w_22_12   4.2073628850530440e-02
 BV BND1      x_22_13 
 UP BND1      w_22_13   4.2073628850530440e-02
 BV BND1      x_22_14 
 UP BND1      w_22_14   4.2073628850530440e-02
 BV BND1      x_22_15 
 UP BND1      w_22_15   4.2073628850530440e-02
 UP BND1      rho_22    1
 BV BND1      x_26_0  
 UP BND1      w_26_0    4.2073628850530440e-02
 BV BND1      x_26_1  
 UP BND1      w_26_1    4.2073628850530440e-02
 BV BND1      x_26_2  
 UP BND1      w_26_2    4.2073628850530440e-02
 BV BND1      x_26_3  
 UP BND1      w_26_3    4.2073628850530440e-02
 BV BND1      x_26_4  
 UP BND1      w_26_4    4.2073628850530440e-02
 BV BND1      x_26_5  
 UP BND1      w_26_5    4.2073628850530440e-02
 BV BND1      x_26_6  
 UP BND1      w_26_6    4.2073628850530440e-02
 BV BND1      x_26_7  
 UP BND1      w_26_7    4.2073628850530440e-02
 BV BND1      x_26_8  
 UP BND1      w_26_8    4.2073628850530440e-02
 UP BND1      rho_26    1
 BV BND1      x_34_0  
 UP BND1      w_34_0    4.2073628850530440e-02
 BV BND1      x_34_1  
 UP BND1      w_34_1    4.2073628850530440e-02
 BV BND1      x_34_2  
 UP BND1      w_34_2    4.2073628850530440e-02
 BV BND1      x_34_3  
 UP BND1      w_34_3    4.2073628850530440e-02
 BV BND1      x_34_4  
 UP BND1      w_34_4    4.2073628850530440e-02
 BV BND1      x_34_5  
 UP BND1      w_34_5    4.2073628850530440e-02
 BV BND1      x_34_6  
 UP BND1      w_34_6    4.2073628850530440e-02
 BV BND1      x_34_7  
 UP BND1      w_34_7    4.2073628850530440e-02
 BV BND1      x_34_8  
 UP BND1      w_34_8    4.2073628850530440e-02
 BV BND1      x_34_9  
 UP BND1      w_34_9    4.2073628850530440e-02
 BV BND1      x_34_10 
 UP BND1      w_34_10   4.2073628850530440e-02
 BV BND1      x_34_11 
 UP BND1      w_34_11   4.2073628850530440e-02
 BV BND1      x_34_12 
 UP BND1      w_34_12   4.2073628850530440e-02
 BV BND1      x_34_13 
 UP BND1      w_34_13   4.2073628850530440e-02
 BV BND1      x_34_14 
 UP BND1      w_34_14   4.2073628850530440e-02
 BV BND1      x_34_15 
 UP BND1      w_34_15   4.2073628850530440e-02
 UP BND1      rho_34    1
 BV BND1      x_23_0  
 UP BND1      w_23_0    4.2073628850530440e-02
 BV BND1      x_23_1  
 UP BND1      w_23_1    4.2073628850530440e-02
 BV BND1      x_23_2  
 UP BND1      w_23_2    4.2073628850530440e-02
 BV BND1      x_23_3  
 UP BND1      w_23_3    4.2073628850530440e-02
 UP BND1      rho_23    1
 BV BND1      x_27_0  
 UP BND1      w_27_0    4.2073628850530440e-02
 BV BND1      x_27_1  
 UP BND1      w_27_1    4.2073628850530440e-02
 BV BND1      x_27_2  
 UP BND1      w_27_2    4.2073628850530440e-02
 BV BND1      x_27_3  
 UP BND1      w_27_3    4.2073628850530440e-02
 BV BND1      x_27_4  
 UP BND1      w_27_4    4.2073628850530440e-02
 BV BND1      x_27_5  
 UP BND1      w_27_5    4.2073628850530440e-02
 BV BND1      x_27_6  
 UP BND1      w_27_6    4.2073628850530440e-02
 UP BND1      rho_27    1
 BV BND1      x_21_0  
 UP BND1      w_21_0    4.2073628850530440e-02
 BV BND1      x_21_1  
 UP BND1      w_21_1    4.2073628850530440e-02
 BV BND1      x_21_2  
 UP BND1      w_21_2    4.2073628850530440e-02
 BV BND1      x_21_3  
 UP BND1      w_21_3    4.2073628850530440e-02
 BV BND1      x_21_4  
 UP BND1      w_21_4    4.2073628850530440e-02
 BV BND1      x_21_5  
 UP BND1      w_21_5    4.2073628850530440e-02
 BV BND1      x_21_6  
 UP BND1      w_21_6    4.2073628850530440e-02
 UP BND1      rho_21    1
 BV BND1      x_25_0  
 UP BND1      w_25_0    4.2073628850530440e-02
 BV BND1      x_25_1  
 UP BND1      w_25_1    4.2073628850530440e-02
 BV BND1      x_25_2  
 UP BND1      w_25_2    4.2073628850530440e-02
 BV BND1      x_25_3  
 UP BND1      w_25_3    4.2073628850530440e-02
 BV BND1      x_25_4  
 UP BND1      w_25_4    4.2073628850530440e-02
 UP BND1      rho_25    1
 BV BND1      x_28_0  
 UP BND1      w_28_0    4.2073628850530440e-02
 BV BND1      x_28_1  
 UP BND1      w_28_1    4.2073628850530440e-02
 BV BND1      x_28_2  
 UP BND1      w_28_2    4.2073628850530440e-02
 BV BND1      x_28_3  
 UP BND1      w_28_3    4.2073628850530440e-02
 BV BND1      x_28_4  
 UP BND1      w_28_4    4.2073628850530440e-02
 BV BND1      x_28_5  
 UP BND1      w_28_5    4.2073628850530440e-02
 BV BND1      x_28_6  
 UP BND1      w_28_6    4.2073628850530440e-02
 UP BND1      rho_28    1
 UP BND1      a_22_26   1
 UP BND1      a_22_34   1
 UP BND1      a_22_23   1
 UP BND1      a_22_27   1
 UP BND1      a_22_21   1
 UP BND1      a_22_25   1
 UP BND1      a_22_28   1
 UP BND1      a_26_34   1
 UP BND1      a_26_23   1
 UP BND1      a_26_27   1
 UP BND1      a_26_21   1
 UP BND1      a_26_25   1
 UP BND1      a_26_28   1
 UP BND1      a_34_23   1
 UP BND1      a_34_27   1
 UP BND1      a_34_21   1
 UP BND1      a_34_25   1
 UP BND1      a_34_28   1
 UP BND1      a_23_27   1
 UP BND1      a_23_21   1
 UP BND1      a_23_25   1
 UP BND1      a_23_28   1
 UP BND1      a_27_21   1
 UP BND1      a_27_25   1
 UP BND1      a_27_28   1
 UP BND1      a_21_25   1
 UP BND1      a_21_28   1
 UP BND1      a_25_28   1
 BV BND1      service_0_22_0
 BV BND1      service_0_22_1
 BV BND1      service_0_22_3
 BV BND1      service_0_22_4
 BV BND1      service_0_22_5
 BV BND1      service_0_22_6
 BV BND1      service_0_22_7
 BV BND1      service_0_22_8
 BV BND1      service_0_22_9
 BV BND1      service_0_22_10
 BV BND1      service_0_22_11
 BV BND1      service_0_22_12
 BV BND1      service_0_22_13
 BV BND1      service_0_22_14
 BV BND1      service_0_22_15
 BV BND1      service_1_22_0
 BV BND1      service_1_22_1
 BV BND1      service_1_22_3
 BV BND1      service_1_22_4
 BV BND1      service_1_22_5
 BV BND1      service_1_22_6
 BV BND1      service_1_22_7
 BV BND1      service_1_22_8
 BV BND1      service_1_22_9
 BV BND1      service_1_22_10
 BV BND1      service_1_22_11
 BV BND1      service_1_22_12
 BV BND1      service_1_22_13
 BV BND1      service_1_22_14
 BV BND1      service_1_22_15
 BV BND1      service_2_22_0
 BV BND1      service_2_22_1
 BV BND1      service_2_22_3
 BV BND1      service_2_22_4
 BV BND1      service_2_22_5
 BV BND1      service_2_22_6
 BV BND1      service_2_22_7
 BV BND1      service_2_22_8
 BV BND1      service_2_22_9
 BV BND1      service_2_22_10
 BV BND1      service_2_22_11
 BV BND1      service_2_22_12
 BV BND1      service_2_22_13
 BV BND1      service_2_22_14
 BV BND1      service_2_22_15
 BV BND1      service_0_26_0
 BV BND1      service_0_26_1
 BV BND1      service_0_26_2
 BV BND1      service_0_26_3
 BV BND1      service_0_26_4
 BV BND1      service_0_26_6
 BV BND1      service_0_26_7
 BV BND1      service_0_26_8
 BV BND1      service_1_26_0
 BV BND1      service_1_26_1
 BV BND1      service_1_26_2
 BV BND1      service_1_26_3
 BV BND1      service_1_26_4
 BV BND1      service_1_26_6
 BV BND1      service_1_26_7
 BV BND1      service_1_26_8
 BV BND1      service_2_26_0
 BV BND1      service_2_26_1
 BV BND1      service_2_26_2
 BV BND1      service_2_26_3
 BV BND1      service_2_26_4
 BV BND1      service_2_26_6
 BV BND1      service_2_26_7
 BV BND1      service_2_26_8
 BV BND1      service_0_34_0
 BV BND1      service_0_34_1
 BV BND1      service_0_34_3
 BV BND1      service_0_34_4
 BV BND1      service_0_34_5
 BV BND1      service_0_34_6
 BV BND1      service_0_34_7
 BV BND1      service_0_34_8
 BV BND1      service_0_34_9
 BV BND1      service_0_34_10
 BV BND1      service_0_34_11
 BV BND1      service_0_34_12
 BV BND1      service_0_34_13
 BV BND1      service_0_34_14
 BV BND1      service_0_34_15
 BV BND1      service_1_34_0
 BV BND1      service_1_34_1
 BV BND1      service_1_34_3
 BV BND1      service_1_34_4
 BV BND1      service_1_34_5
 BV BND1      service_1_34_6
 BV BND1      service_1_34_7
 BV BND1      service_1_34_8
 BV BND1      service_1_34_9
 BV BND1      service_1_34_10
 BV BND1      service_1_34_11
 BV BND1      service_1_34_12
 BV BND1      service_1_34_13
 BV BND1      service_1_34_14
 BV BND1      service_1_34_15
 BV BND1      service_2_34_0
 BV BND1      service_2_34_1
 BV BND1      service_2_34_3
 BV BND1      service_2_34_4
 BV BND1      service_2_34_5
 BV BND1      service_2_34_6
 BV BND1      service_2_34_7
 BV BND1      service_2_34_8
 BV BND1      service_2_34_9
 BV BND1      service_2_34_10
 BV BND1      service_2_34_11
 BV BND1      service_2_34_12
 BV BND1      service_2_34_13
 BV BND1      service_2_34_14
 BV BND1      service_2_34_15
 BV BND1      service_0_23_0
 BV BND1      service_0_23_2
 BV BND1      service_0_23_3
 BV BND1      service_1_23_0
 BV BND1      service_1_23_2
 BV BND1      service_1_23_3
 BV BND1      service_2_23_0
 BV BND1      service_2_23_2
 BV BND1      service_2_23_3
 BV BND1      service_0_27_1
 BV BND1      service_0_27_2
 BV BND1      service_0_27_3
 BV BND1      service_0_27_4
 BV BND1      service_0_27_5
 BV BND1      service_0_27_6
 BV BND1      service_1_27_1
 BV BND1      service_1_27_2
 BV BND1      service_1_27_3
 BV BND1      service_1_27_4
 BV BND1      service_1_27_5
 BV BND1      service_1_27_6
 BV BND1      service_2_27_1
 BV BND1      service_2_27_2
 BV BND1      service_2_27_3
 BV BND1      service_2_27_4
 BV BND1      service_2_27_5
 BV BND1      service_2_27_6
 BV BND1      service_0_21_1
 BV BND1      service_0_21_2
 BV BND1      service_0_21_3
 BV BND1      service_0_21_4
 BV BND1      service_0_21_5
 BV BND1      service_0_21_6
 BV BND1      service_1_21_1
 BV BND1      service_1_21_2
 BV BND1      service_1_21_3
 BV BND1      service_1_21_4
 BV BND1      service_1_21_5
 BV BND1      service_1_21_6
 BV BND1      service_2_21_1
 BV BND1      service_2_21_2
 BV BND1      service_2_21_3
 BV BND1      service_2_21_4
 BV BND1      service_2_21_5
 BV BND1      service_2_21_6
 BV BND1      service_0_25_1
 BV BND1      service_0_25_2
 BV BND1      service_0_25_3
 BV BND1      service_0_25_4
 BV BND1      service_1_25_1
 BV BND1      service_1_25_2
 BV BND1      service_1_25_3
 BV BND1      service_1_25_4
 BV BND1      service_2_25_1
 BV BND1      service_2_25_2
 BV BND1      service_2_25_3
 BV BND1      service_2_25_4
 BV BND1      service_0_28_0
 BV BND1      service_0_28_2
 BV BND1      service_0_28_3
 BV BND1      service_0_28_4
 BV BND1      service_0_28_5
 BV BND1      service_0_28_6
 BV BND1      service_1_28_0
 BV BND1      service_1_28_2
 BV BND1      service_1_28_3
 BV BND1      service_1_28_4
 BV BND1      service_1_28_5
 BV BND1      service_1_28_6
 BV BND1      service_2_28_0
 BV BND1      service_2_28_2
 BV BND1      service_2_28_3
 BV BND1      service_2_28_4
 BV BND1      service_2_28_5
 BV BND1      service_2_28_6
 FX BND1      visit_0_1  1
 UP BND1      order_0_1  12
 FX BND1      visit_0_2  1
 UP BND1      order_0_2  12
 FX BND1      visit_0_3  1
 UP BND1      order_0_3  12
 FX BND1      visit_0_4  1
 UP BND1      order_0_4  12
 UP BND1      visit_0_12  1
 UP BND1      order_0_12  12
 UP BND1      visit_0_13  1
 UP BND1      order_0_13  12
 UP BND1      visit_0_14  1
 UP BND1      order_0_14  12
 UP BND1      visit_0_15  1
 UP BND1      order_0_15  12
 UP BND1      visit_0_16  1
 UP BND1      order_0_16  12
 UP BND1      visit_0_17  1
 UP BND1      order_0_17  12
 UP BND1      visit_0_18  1
 UP BND1      order_0_18  12
 UP BND1      visit_0_19  1
 UP BND1      order_0_19  12
 BV BND1      arc_0_0_0
 FX BND1      load_0_0_0  0
 BV BND1      arc_0_0_1
 FX BND1      load_0_0_1  0
 BV BND1      arc_0_0_2
 FX BND1      load_0_0_2  0
 BV BND1      arc_0_0_3
 FX BND1      load_0_0_3  0
 BV BND1      arc_0_0_4
 FX BND1      load_0_0_4  0
 BV BND1      arc_0_0_12
 FX BND1      load_0_0_12  0
 BV BND1      arc_0_0_13
 FX BND1      load_0_0_13  0
 BV BND1      arc_0_0_14
 FX BND1      load_0_0_14  0
 BV BND1      arc_0_0_15
 FX BND1      load_0_0_15  0
 BV BND1      arc_0_0_16
 FX BND1      load_0_0_16  0
 BV BND1      arc_0_0_17
 FX BND1      load_0_0_17  0
 BV BND1      arc_0_0_18
 FX BND1      load_0_0_18  0
 BV BND1      arc_0_0_19
 FX BND1      load_0_0_19  0
 BV BND1      arc_0_1_0
 UP BND1      load_0_1_0  20
 BV BND1      arc_0_1_2
 UP BND1      load_0_1_2  20
 BV BND1      arc_0_1_3
 UP BND1      load_0_1_3  20
 BV BND1      arc_0_1_4
 UP BND1      load_0_1_4  20
 BV BND1      arc_0_1_12
 UP BND1      load_0_1_12  20
 BV BND1      arc_0_1_13
 UP BND1      load_0_1_13  20
 BV BND1      arc_0_1_14
 UP BND1      load_0_1_14  20
 BV BND1      arc_0_1_15
 UP BND1      load_0_1_15  20
 BV BND1      arc_0_1_16
 UP BND1      load_0_1_16  20
 BV BND1      arc_0_1_17
 UP BND1      load_0_1_17  20
 BV BND1      arc_0_1_18
 UP BND1      load_0_1_18  20
 BV BND1      arc_0_1_19
 UP BND1      load_0_1_19  20
 BV BND1      arc_0_2_0
 UP BND1      load_0_2_0  20
 BV BND1      arc_0_2_1
 UP BND1      load_0_2_1  20
 BV BND1      arc_0_2_3
 UP BND1      load_0_2_3  20
 BV BND1      arc_0_2_4
 UP BND1      load_0_2_4  20
 BV BND1      arc_0_2_12
 UP BND1      load_0_2_12  20
 BV BND1      arc_0_2_13
 UP BND1      load_0_2_13  20
 BV BND1      arc_0_2_14
 UP BND1      load_0_2_14  20
 BV BND1      arc_0_2_15
 UP BND1      load_0_2_15  20
 BV BND1      arc_0_2_16
 UP BND1      load_0_2_16  20
 BV BND1      arc_0_2_17
 UP BND1      load_0_2_17  20
 BV BND1      arc_0_2_18
 UP BND1      load_0_2_18  20
 BV BND1      arc_0_2_19
 UP BND1      load_0_2_19  20
 BV BND1      arc_0_3_0
 UP BND1      load_0_3_0  20
 BV BND1      arc_0_3_1
 UP BND1      load_0_3_1  20
 BV BND1      arc_0_3_2
 UP BND1      load_0_3_2  20
 BV BND1      arc_0_3_4
 UP BND1      load_0_3_4  20
 BV BND1      arc_0_3_12
 UP BND1      load_0_3_12  20
 BV BND1      arc_0_3_13
 UP BND1      load_0_3_13  20
 BV BND1      arc_0_3_14
 UP BND1      load_0_3_14  20
 BV BND1      arc_0_3_15
 UP BND1      load_0_3_15  20
 BV BND1      arc_0_3_16
 UP BND1      load_0_3_16  20
 BV BND1      arc_0_3_17
 UP BND1      load_0_3_17  20
 BV BND1      arc_0_3_18
 UP BND1      load_0_3_18  20
 BV BND1      arc_0_3_19
 UP BND1      load_0_3_19  20
 BV BND1      arc_0_4_0
 UP BND1      load_0_4_0  20
 BV BND1      arc_0_4_1
 UP BND1      load_0_4_1  20
 BV BND1      arc_0_4_2
 UP BND1      load_0_4_2  20
 BV BND1      arc_0_4_3
 UP BND1      load_0_4_3  20
 BV BND1      arc_0_4_12
 UP BND1      load_0_4_12  20
 BV BND1      arc_0_4_13
 UP BND1      load_0_4_13  20
 BV BND1      arc_0_4_14
 UP BND1      load_0_4_14  20
 BV BND1      arc_0_4_15
 UP BND1      load_0_4_15  20
 BV BND1      arc_0_4_16
 UP BND1      load_0_4_16  20
 BV BND1      arc_0_4_17
 UP BND1      load_0_4_17  20
 BV BND1      arc_0_4_18
 UP BND1      load_0_4_18  20
 BV BND1      arc_0_4_19
 UP BND1      load_0_4_19  20
 BV BND1      arc_0_12_0
 UP BND1      load_0_12_0  20
 BV BND1      arc_0_12_1
 UP BND1      load_0_12_1  20
 BV BND1      arc_0_12_2
 UP BND1      load_0_12_2  20
 BV BND1      arc_0_12_3
 UP BND1      load_0_12_3  20
 BV BND1      arc_0_12_4
 UP BND1      load_0_12_4  20
 BV BND1      arc_0_12_13
 UP BND1      load_0_12_13  20
 BV BND1      arc_0_12_14
 UP BND1      load_0_12_14  20
 BV BND1      arc_0_12_15
 UP BND1      load_0_12_15  20
 BV BND1      arc_0_12_16
 UP BND1      load_0_12_16  20
 BV BND1      arc_0_12_17
 UP BND1      load_0_12_17  20
 BV BND1      arc_0_12_18
 UP BND1      load_0_12_18  20
 BV BND1      arc_0_12_19
 UP BND1      load_0_12_19  20
 BV BND1      arc_0_13_0
 UP BND1      load_0_13_0  20
 BV BND1      arc_0_13_1
 UP BND1      load_0_13_1  20
 BV BND1      arc_0_13_2
 UP BND1      load_0_13_2  20
 BV BND1      arc_0_13_3
 UP BND1      load_0_13_3  20
 BV BND1      arc_0_13_4
 UP BND1      load_0_13_4  20
 BV BND1      arc_0_13_12
 UP BND1      load_0_13_12  20
 BV BND1      arc_0_13_14
 UP BND1      load_0_13_14  20
 BV BND1      arc_0_13_15
 UP BND1      load_0_13_15  20
 BV BND1      arc_0_13_16
 UP BND1      load_0_13_16  20
 BV BND1      arc_0_13_17
 UP BND1      load_0_13_17  20
 BV BND1      arc_0_13_18
 UP BND1      load_0_13_18  20
 BV BND1      arc_0_13_19
 UP BND1      load_0_13_19  20
 BV BND1      arc_0_14_0
 UP BND1      load_0_14_0  20
 BV BND1      arc_0_14_1
 UP BND1      load_0_14_1  20
 BV BND1      arc_0_14_2
 UP BND1      load_0_14_2  20
 BV BND1      arc_0_14_3
 UP BND1      load_0_14_3  20
 BV BND1      arc_0_14_4
 UP BND1      load_0_14_4  20
 BV BND1      arc_0_14_12
 UP BND1      load_0_14_12  20
 BV BND1      arc_0_14_13
 UP BND1      load_0_14_13  20
 BV BND1      arc_0_14_15
 UP BND1      load_0_14_15  20
 BV BND1      arc_0_14_16
 UP BND1      load_0_14_16  20
 BV BND1      arc_0_14_17
 UP BND1      load_0_14_17  20
 BV BND1      arc_0_14_18
 UP BND1      load_0_14_18  20
 BV BND1      arc_0_14_19
 UP BND1      load_0_14_19  20
 BV BND1      arc_0_15_0
 UP BND1      load_0_15_0  20
 BV BND1      arc_0_15_1
 UP BND1      load_0_15_1  20
 BV BND1      arc_0_15_2
 UP BND1      load_0_15_2  20
 BV BND1      arc_0_15_3
 UP BND1      load_0_15_3  20
 BV BND1      arc_0_15_4
 UP BND1      load_0_15_4  20
 BV BND1      arc_0_15_12
 UP BND1      load_0_15_12  20
 BV BND1      arc_0_15_13
 UP BND1      load_0_15_13  20
 BV BND1      arc_0_15_14
 UP BND1      load_0_15_14  20
 BV BND1      arc_0_15_16
 UP BND1      load_0_15_16  20
 BV BND1      arc_0_15_17
 UP BND1      load_0_15_17  20
 BV BND1      arc_0_15_18
 UP BND1      load_0_15_18  20
 BV BND1      arc_0_15_19
 UP BND1      load_0_15_19  20
 BV BND1      arc_0_16_0
 UP BND1      load_0_16_0  20
 BV BND1      arc_0_16_1
 UP BND1      load_0_16_1  20
 BV BND1      arc_0_16_2
 UP BND1      load_0_16_2  20
 BV BND1      arc_0_16_3
 UP BND1      load_0_16_3  20
 BV BND1      arc_0_16_4
 UP BND1      load_0_16_4  20
 BV BND1      arc_0_16_12
 UP BND1      load_0_16_12  20
 BV BND1      arc_0_16_13
 UP BND1      load_0_16_13  20
 BV BND1      arc_0_16_14
 UP BND1      load_0_16_14  20
 BV BND1      arc_0_16_15
 UP BND1      load_0_16_15  20
 BV BND1      arc_0_16_17
 UP BND1      load_0_16_17  20
 BV BND1      arc_0_16_18
 UP BND1      load_0_16_18  20
 BV BND1      arc_0_16_19
 UP BND1      load_0_16_19  20
 BV BND1      arc_0_17_0
 UP BND1      load_0_17_0  20
 BV BND1      arc_0_17_1
 UP BND1      load_0_17_1  20
 BV BND1      arc_0_17_2
 UP BND1      load_0_17_2  20
 BV BND1      arc_0_17_3
 UP BND1      load_0_17_3  20
 BV BND1      arc_0_17_4
 UP BND1      load_0_17_4  20
 BV BND1      arc_0_17_12
 UP BND1      load_0_17_12  20
 BV BND1      arc_0_17_13
 UP BND1      load_0_17_13  20
 BV BND1      arc_0_17_14
 UP BND1      load_0_17_14  20
 BV BND1      arc_0_17_15
 UP BND1      load_0_17_15  20
 BV BND1      arc_0_17_16
 UP BND1      load_0_17_16  20
 BV BND1      arc_0_17_18
 UP BND1      load_0_17_18  20
 BV BND1      arc_0_17_19
 UP BND1      load_0_17_19  20
 BV BND1      arc_0_18_0
 UP BND1      load_0_18_0  20
 BV BND1      arc_0_18_1
 UP BND1      load_0_18_1  20
 BV BND1      arc_0_18_2
 UP BND1      load_0_18_2  20
 BV BND1      arc_0_18_3
 UP BND1      load_0_18_3  20
 BV BND1      arc_0_18_4
 UP BND1      load_0_18_4  20
 BV BND1      arc_0_18_12
 UP BND1      load_0_18_12  20
 BV BND1      arc_0_18_13
 UP BND1      load_0_18_13  20
 BV BND1      arc_0_18_14
 UP BND1      load_0_18_14  20
 BV BND1      arc_0_18_15
 UP BND1      load_0_18_15  20
 BV BND1      arc_0_18_16
 UP BND1      load_0_18_16  20
 BV BND1      arc_0_18_17
 UP BND1      load_0_18_17  20
 BV BND1      arc_0_18_19
 UP BND1      load_0_18_19  20
 BV BND1      arc_0_19_0
 UP BND1      load_0_19_0  20
 BV BND1      arc_0_19_1
 UP BND1      load_0_19_1  20
 BV BND1      arc_0_19_2
 UP BND1      load_0_19_2  20
 BV BND1      arc_0_19_3
 UP BND1      load_0_19_3  20
 BV BND1      arc_0_19_4
 UP BND1      load_0_19_4  20
 BV BND1      arc_0_19_12
 UP BND1      load_0_19_12  20
 BV BND1      arc_0_19_13
 UP BND1      load_0_19_13  20
 BV BND1      arc_0_19_14
 UP BND1      load_0_19_14  20
 BV BND1      arc_0_19_15
 UP BND1      load_0_19_15  20
 BV BND1      arc_0_19_16
 UP BND1      load_0_19_16  20
 BV BND1      arc_0_19_17
 UP BND1      load_0_19_17  20
 BV BND1      arc_0_19_18
 UP BND1      load_0_19_18  20
 FX BND1      visit_1_5  1
 UP BND1      order_1_5  12
 FX BND1      visit_1_6  1
 UP BND1      order_1_6  12
 FX BND1      visit_1_7  1
 UP BND1      order_1_7  12
 FX BND1      visit_1_8  1
 UP BND1      order_1_8  12
 UP BND1      visit_1_12  1
 UP BND1      order_1_12  12
 UP BND1      visit_1_13  1
 UP BND1      order_1_13  12
 UP BND1      visit_1_14  1
 UP BND1      order_1_14  12
 UP BND1      visit_1_15  1
 UP BND1      order_1_15  12
 UP BND1      visit_1_16  1
 UP BND1      order_1_16  12
 UP BND1      visit_1_17  1
 UP BND1      order_1_17  12
 UP BND1      visit_1_18  1
 UP BND1      order_1_18  12
 UP BND1      visit_1_19  1
 UP BND1      order_1_19  12
 BV BND1      arc_1_0_0
 FX BND1      load_1_0_0  0
 BV BND1      arc_1_0_5
 FX BND1      load_1_0_5  0
 BV BND1      arc_1_0_6
 FX BND1      load_1_0_6  0
 BV BND1      arc_1_0_7
 FX BND1      load_1_0_7  0
 BV BND1      arc_1_0_8
 FX BND1      load_1_0_8  0
 BV BND1      arc_1_0_12
 FX BND1      load_1_0_12  0
 BV BND1      arc_1_0_13
 FX BND1      load_1_0_13  0
 BV BND1      arc_1_0_14
 FX BND1      load_1_0_14  0
 BV BND1      arc_1_0_15
 FX BND1      load_1_0_15  0
 BV BND1      arc_1_0_16
 FX BND1      load_1_0_16  0
 BV BND1      arc_1_0_17
 FX BND1      load_1_0_17  0
 BV BND1      arc_1_0_18
 FX BND1      load_1_0_18  0
 BV BND1      arc_1_0_19
 FX BND1      load_1_0_19  0
 BV BND1      arc_1_5_0
 UP BND1      load_1_5_0  25
 BV BND1      arc_1_5_6
 UP BND1      load_1_5_6  25
 BV BND1      arc_1_5_7
 UP BND1      load_1_5_7  25
 BV BND1      arc_1_5_8
 UP BND1      load_1_5_8  25
 BV BND1      arc_1_5_12
 UP BND1      load_1_5_12  25
 BV BND1      arc_1_5_13
 UP BND1      load_1_5_13  25
 BV BND1      arc_1_5_14
 UP BND1      load_1_5_14  25
 BV BND1      arc_1_5_15
 UP BND1      load_1_5_15  25
 BV BND1      arc_1_5_16
 UP BND1      load_1_5_16  25
 BV BND1      arc_1_5_17
 UP BND1      load_1_5_17  25
 BV BND1      arc_1_5_18
 UP BND1      load_1_5_18  25
 BV BND1      arc_1_5_19
 UP BND1      load_1_5_19  25
 BV BND1      arc_1_6_0
 UP BND1      load_1_6_0  25
 BV BND1      arc_1_6_5
 UP BND1      load_1_6_5  25
 BV BND1      arc_1_6_7
 UP BND1      load_1_6_7  25
 BV BND1      arc_1_6_8
 UP BND1      load_1_6_8  25
 BV BND1      arc_1_6_12
 UP BND1      load_1_6_12  25
 BV BND1      arc_1_6_13
 UP BND1      load_1_6_13  25
 BV BND1      arc_1_6_14
 UP BND1      load_1_6_14  25
 BV BND1      arc_1_6_15
 UP BND1      load_1_6_15  25
 BV BND1      arc_1_6_16
 UP BND1      load_1_6_16  25
 BV BND1      arc_1_6_17
 UP BND1      load_1_6_17  25
 BV BND1      arc_1_6_18
 UP BND1      load_1_6_18  25
 BV BND1      arc_1_6_19
 UP BND1      load_1_6_19  25
 BV BND1      arc_1_7_0
 UP BND1      load_1_7_0  25
 BV BND1      arc_1_7_5
 UP BND1      load_1_7_5  25
 BV BND1      arc_1_7_6
 UP BND1      load_1_7_6  25
 BV BND1      arc_1_7_8
 UP BND1      load_1_7_8  25
 BV BND1      arc_1_7_12
 UP BND1      load_1_7_12  25
 BV BND1      arc_1_7_13
 UP BND1      load_1_7_13  25
 BV BND1      arc_1_7_14
 UP BND1      load_1_7_14  25
 BV BND1      arc_1_7_15
 UP BND1      load_1_7_15  25
 BV BND1      arc_1_7_16
 UP BND1      load_1_7_16  25
 BV BND1      arc_1_7_17
 UP BND1      load_1_7_17  25
 BV BND1      arc_1_7_18
 UP BND1      load_1_7_18  25
 BV BND1      arc_1_7_19
 UP BND1      load_1_7_19  25
 BV BND1      arc_1_8_0
 UP BND1      load_1_8_0  25
 BV BND1      arc_1_8_5
 UP BND1      load_1_8_5  25
 BV BND1      arc_1_8_6
 UP BND1      load_1_8_6  25
 BV BND1      arc_1_8_7
 UP BND1      load_1_8_7  25
 BV BND1      arc_1_8_12
 UP BND1      load_1_8_12  25
 BV BND1      arc_1_8_13
 UP BND1      load_1_8_13  25
 BV BND1      arc_1_8_14
 UP BND1      load_1_8_14  25
 BV BND1      arc_1_8_15
 UP BND1      load_1_8_15  25
 BV BND1      arc_1_8_16
 UP BND1      load_1_8_16  25
 BV BND1      arc_1_8_17
 UP BND1      load_1_8_17  25
 BV BND1      arc_1_8_18
 UP BND1      load_1_8_18  25
 BV BND1      arc_1_8_19
 UP BND1      load_1_8_19  25
 BV BND1      arc_1_12_0
 UP BND1      load_1_12_0  25
 BV BND1      arc_1_12_5
 UP BND1      load_1_12_5  25
 BV BND1      arc_1_12_6
 UP BND1      load_1_12_6  25
 BV BND1      arc_1_12_7
 UP BND1      load_1_12_7  25
 BV BND1      arc_1_12_8
 UP BND1      load_1_12_8  25
 BV BND1      arc_1_12_13
 UP BND1      load_1_12_13  25
 BV BND1      arc_1_12_14
 UP BND1      load_1_12_14  25
 BV BND1      arc_1_12_15
 UP BND1      load_1_12_15  25
 BV BND1      arc_1_12_16
 UP BND1      load_1_12_16  25
 BV BND1      arc_1_12_17
 UP BND1      load_1_12_17  25
 BV BND1      arc_1_12_18
 UP BND1      load_1_12_18  25
 BV BND1      arc_1_12_19
 UP BND1      load_1_12_19  25
 BV BND1      arc_1_13_0
 UP BND1      load_1_13_0  25
 BV BND1      arc_1_13_5
 UP BND1      load_1_13_5  25
 BV BND1      arc_1_13_6
 UP BND1      load_1_13_6  25
 BV BND1      arc_1_13_7
 UP BND1      load_1_13_7  25
 BV BND1      arc_1_13_8
 UP BND1      load_1_13_8  25
 BV BND1      arc_1_13_12
 UP BND1      load_1_13_12  25
 BV BND1      arc_1_13_14
 UP BND1      load_1_13_14  25
 BV BND1      arc_1_13_15
 UP BND1      load_1_13_15  25
 BV BND1      arc_1_13_16
 UP BND1      load_1_13_16  25
 BV BND1      arc_1_13_17
 UP BND1      load_1_13_17  25
 BV BND1      arc_1_13_18
 UP BND1      load_1_13_18  25
 BV BND1      arc_1_13_19
 UP BND1      load_1_13_19  25
 BV BND1      arc_1_14_0
 UP BND1      load_1_14_0  25
 BV BND1      arc_1_14_5
 UP BND1      load_1_14_5  25
 BV BND1      arc_1_14_6
 UP BND1      load_1_14_6  25
 BV BND1      arc_1_14_7
 UP BND1      load_1_14_7  25
 BV BND1      arc_1_14_8
 UP BND1      load_1_14_8  25
 BV BND1      arc_1_14_12
 UP BND1      load_1_14_12  25
 BV BND1      arc_1_14_13
 UP BND1      load_1_14_13  25
 BV BND1      arc_1_14_15
 UP BND1      load_1_14_15  25
 BV BND1      arc_1_14_16
 UP BND1      load_1_14_16  25
 BV BND1      arc_1_14_17
 UP BND1      load_1_14_17  25
 BV BND1      arc_1_14_18
 UP BND1      load_1_14_18  25
 BV BND1      arc_1_14_19
 UP BND1      load_1_14_19  25
 BV BND1      arc_1_15_0
 UP BND1      load_1_15_0  25
 BV BND1      arc_1_15_5
 UP BND1      load_1_15_5  25
 BV BND1      arc_1_15_6
 UP BND1      load_1_15_6  25
 BV BND1      arc_1_15_7
 UP BND1      load_1_15_7  25
 BV BND1      arc_1_15_8
 UP BND1      load_1_15_8  25
 BV BND1      arc_1_15_12
 UP BND1      load_1_15_12  25
 BV BND1      arc_1_15_13
 UP BND1      load_1_15_13  25
 BV BND1      arc_1_15_14
 UP BND1      load_1_15_14  25
 BV BND1      arc_1_15_16
 UP BND1      load_1_15_16  25
 BV BND1      arc_1_15_17
 UP BND1      load_1_15_17  25
 BV BND1      arc_1_15_18
 UP BND1      load_1_15_18  25
 BV BND1      arc_1_15_19
 UP BND1      load_1_15_19  25
 BV BND1      arc_1_16_0
 UP BND1      load_1_16_0  25
 BV BND1      arc_1_16_5
 UP BND1      load_1_16_5  25
 BV BND1      arc_1_16_6
 UP BND1      load_1_16_6  25
 BV BND1      arc_1_16_7
 UP BND1      load_1_16_7  25
 BV BND1      arc_1_16_8
 UP BND1      load_1_16_8  25
 BV BND1      arc_1_16_12
 UP BND1      load_1_16_12  25
 BV BND1      arc_1_16_13
 UP BND1      load_1_16_13  25
 BV BND1      arc_1_16_14
 UP BND1      load_1_16_14  25
 BV BND1      arc_1_16_15
 UP BND1      load_1_16_15  25
 BV BND1      arc_1_16_17
 UP BND1      load_1_16_17  25
 BV BND1      arc_1_16_18
 UP BND1      load_1_16_18  25
 BV BND1      arc_1_16_19
 UP BND1      load_1_16_19  25
 BV BND1      arc_1_17_0
 UP BND1      load_1_17_0  25
 BV BND1      arc_1_17_5
 UP BND1      load_1_17_5  25
 BV BND1      arc_1_17_6
 UP BND1      load_1_17_6  25
 BV BND1      arc_1_17_7
 UP BND1      load_1_17_7  25
 BV BND1      arc_1_17_8
 UP BND1      load_1_17_8  25
 BV BND1      arc_1_17_12
 UP BND1      load_1_17_12  25
 BV BND1      arc_1_17_13
 UP BND1      load_1_17_13  25
 BV BND1      arc_1_17_14
 UP BND1      load_1_17_14  25
 BV BND1      arc_1_17_15
 UP BND1      load_1_17_15  25
 BV BND1      arc_1_17_16
 UP BND1      load_1_17_16  25
 BV BND1      arc_1_17_18
 UP BND1      load_1_17_18  25
 BV BND1      arc_1_17_19
 UP BND1      load_1_17_19  25
 BV BND1      arc_1_18_0
 UP BND1      load_1_18_0  25
 BV BND1      arc_1_18_5
 UP BND1      load_1_18_5  25
 BV BND1      arc_1_18_6
 UP BND1      load_1_18_6  25
 BV BND1      arc_1_18_7
 UP BND1      load_1_18_7  25
 BV BND1      arc_1_18_8
 UP BND1      load_1_18_8  25
 BV BND1      arc_1_18_12
 UP BND1      load_1_18_12  25
 BV BND1      arc_1_18_13
 UP BND1      load_1_18_13  25
 BV BND1      arc_1_18_14
 UP BND1      load_1_18_14  25
 BV BND1      arc_1_18_15
 UP BND1      load_1_18_15  25
 BV BND1      arc_1_18_16
 UP BND1      load_1_18_16  25
 BV BND1      arc_1_18_17
 UP BND1      load_1_18_17  25
 BV BND1      arc_1_18_19
 UP BND1      load_1_18_19  25
 BV BND1      arc_1_19_0
 UP BND1      load_1_19_0  25
 BV BND1      arc_1_19_5
 UP BND1      load_1_19_5  25
 BV BND1      arc_1_19_6
 UP BND1      load_1_19_6  25
 BV BND1      arc_1_19_7
 UP BND1      load_1_19_7  25
 BV BND1      arc_1_19_8
 UP BND1      load_1_19_8  25
 BV BND1      arc_1_19_12
 UP BND1      load_1_19_12  25
 BV BND1      arc_1_19_13
 UP BND1      load_1_19_13  25
 BV BND1      arc_1_19_14
 UP BND1      load_1_19_14  25
 BV BND1      arc_1_19_15
 UP BND1      load_1_19_15  25
 BV BND1      arc_1_19_16
 UP BND1      load_1_19_16  25
 BV BND1      arc_1_19_17
 UP BND1      load_1_19_17  25
 BV BND1      arc_1_19_18
 UP BND1      load_1_19_18  25
 FX BND1      visit_2_9  1
 UP BND1      order_2_9  11
 FX BND1      visit_2_10  1
 UP BND1      order_2_10  11
 FX BND1      visit_2_11  1
 UP BND1      order_2_11  11
 UP BND1      visit_2_12  1
 UP BND1      order_2_12  11
 UP BND1      visit_2_13  1
 UP BND1      order_2_13  11
 UP BND1      visit_2_14  1
 UP BND1      order_2_14  11
 UP BND1      visit_2_15  1
 UP BND1      order_2_15  11
 UP BND1      visit_2_16  1
 UP BND1      order_2_16  11
 UP BND1      visit_2_17  1
 UP BND1      order_2_17  11
 UP BND1      visit_2_18  1
 UP BND1      order_2_18  11
 UP BND1      visit_2_19  1
 UP BND1      order_2_19  11
 BV BND1      arc_2_0_0
 FX BND1      load_2_0_0  0
 BV BND1      arc_2_0_9
 FX BND1      load_2_0_9  0
 BV BND1      arc_2_0_10
 FX BND1      load_2_0_10  0
 BV BND1      arc_2_0_11
 FX BND1      load_2_0_11  0
 BV BND1      arc_2_0_12
 FX BND1      load_2_0_12  0
 BV BND1      arc_2_0_13
 FX BND1      load_2_0_13  0
 BV BND1      arc_2_0_14
 FX BND1      load_2_0_14  0
 BV BND1      arc_2_0_15
 FX BND1      load_2_0_15  0
 BV BND1      arc_2_0_16
 FX BND1      load_2_0_16  0
 BV BND1      arc_2_0_17
 FX BND1      load_2_0_17  0
 BV BND1      arc_2_0_18
 FX BND1      load_2_0_18  0
 BV BND1      arc_2_0_19
 FX BND1      load_2_0_19  0
 BV BND1      arc_2_9_0
 UP BND1      load_2_9_0  30
 BV BND1      arc_2_9_10
 UP BND1      load_2_9_10  30
 BV BND1      arc_2_9_11
 UP BND1      load_2_9_11  30
 BV BND1      arc_2_9_12
 UP BND1      load_2_9_12  30
 BV BND1      arc_2_9_13
 UP BND1      load_2_9_13  30
 BV BND1      arc_2_9_14
 UP BND1      load_2_9_14  30
 BV BND1      arc_2_9_15
 UP BND1      load_2_9_15  30
 BV BND1      arc_2_9_16
 UP BND1      load_2_9_16  30
 BV BND1      arc_2_9_17
 UP BND1      load_2_9_17  30
 BV BND1      arc_2_9_18
 UP BND1      load_2_9_18  30
 BV BND1      arc_2_9_19
 UP BND1      load_2_9_19  30
 BV BND1      arc_2_10_0
 UP BND1      load_2_10_0  30
 BV BND1      arc_2_10_9
 UP BND1      load_2_10_9  30
 BV BND1      arc_2_10_11
 UP BND1      load_2_10_11  30
 BV BND1      arc_2_10_12
 UP BND1      load_2_10_12  30
 BV BND1      arc_2_10_13
 UP BND1      load_2_10_13  30
 BV BND1      arc_2_10_14
 UP BND1      load_2_10_14  30
 BV BND1      arc_2_10_15
 UP BND1      load_2_10_15  30
 BV BND1      arc_2_10_16
 UP BND1      load_2_10_16  30
 BV BND1      arc_2_10_17
 UP BND1      load_2_10_17  30
 BV BND1      arc_2_10_18
 UP BND1      load_2_10_18  30
 BV BND1      arc_2_10_19
 UP BND1      load_2_10_19  30
 BV BND1      arc_2_11_0
 UP BND1      load_2_11_0  30
 BV BND1      arc_2_11_9
 UP BND1      load_2_11_9  30
 BV BND1      arc_2_11_10
 UP BND1      load_2_11_10  30
 BV BND1      arc_2_11_12
 UP BND1      load_2_11_12  30
 BV BND1      arc_2_11_13
 UP BND1      load_2_11_13  30
 BV BND1      arc_2_11_14
 UP BND1      load_2_11_14  30
 BV BND1      arc_2_11_15
 UP BND1      load_2_11_15  30
 BV BND1      arc_2_11_16
 UP BND1      load_2_11_16  30
 BV BND1      arc_2_11_17
 UP BND1      load_2_11_17  30
 BV BND1      arc_2_11_18
 UP BND1      load_2_11_18  30
 BV BND1      arc_2_11_19
 UP BND1      load_2_11_19  30
 BV BND1      arc_2_12_0
 UP BND1      load_2_12_0  30
 BV BND1      arc_2_12_9
 UP BND1      load_2_12_9  30
 BV BND1      arc_2_12_10
 UP BND1      load_2_12_10  30
 BV BND1      arc_2_12_11
 UP BND1      load_2_12_11  30
 BV BND1      arc_2_12_13
 UP BND1      load_2_12_13  30
 BV BND1      arc_2_12_14
 UP BND1      load_2_12_14  30
 BV BND1      arc_2_12_15
 UP BND1      load_2_12_15  30
 BV BND1      arc_2_12_16
 UP BND1      load_2_12_16  30
 BV BND1      arc_2_12_17
 UP BND1      load_2_12_17  30
 BV BND1      arc_2_12_18
 UP BND1      load_2_12_18  30
 BV BND1      arc_2_12_19
 UP BND1      load_2_12_19  30
 BV BND1      arc_2_13_0
 UP BND1      load_2_13_0  30
 BV BND1      arc_2_13_9
 UP BND1      load_2_13_9  30
 BV BND1      arc_2_13_10
 UP BND1      load_2_13_10  30
 BV BND1      arc_2_13_11
 UP BND1      load_2_13_11  30
 BV BND1      arc_2_13_12
 UP BND1      load_2_13_12  30
 BV BND1      arc_2_13_14
 UP BND1      load_2_13_14  30
 BV BND1      arc_2_13_15
 UP BND1      load_2_13_15  30
 BV BND1      arc_2_13_16
 UP BND1      load_2_13_16  30
 BV BND1      arc_2_13_17
 UP BND1      load_2_13_17  30
 BV BND1      arc_2_13_18
 UP BND1      load_2_13_18  30
 BV BND1      arc_2_13_19
 UP BND1      load_2_13_19  30
 BV BND1      arc_2_14_0
 UP BND1      load_2_14_0  30
 BV BND1      arc_2_14_9
 UP BND1      load_2_14_9  30
 BV BND1      arc_2_14_10
 UP BND1      load_2_14_10  30
 BV BND1      arc_2_14_11
 UP BND1      load_2_14_11  30
 BV BND1      arc_2_14_12
 UP BND1      load_2_14_12  30
 BV BND1      arc_2_14_13
 UP BND1      load_2_14_13  30
 BV BND1      arc_2_14_15
 UP BND1      load_2_14_15  30
 BV BND1      arc_2_14_16
 UP BND1      load_2_14_16  30
 BV BND1      arc_2_14_17
 UP BND1      load_2_14_17  30
 BV BND1      arc_2_14_18
 UP BND1      load_2_14_18  30
 BV BND1      arc_2_14_19
 UP BND1      load_2_14_19  30
 BV BND1      arc_2_15_0
 UP BND1      load_2_15_0  30
 BV BND1      arc_2_15_9
 UP BND1      load_2_15_9  30
 BV BND1      arc_2_15_10
 UP BND1      load_2_15_10  30
 BV BND1      arc_2_15_11
 UP BND1      load_2_15_11  30
 BV BND1      arc_2_15_12
 UP BND1      load_2_15_12  30
 BV BND1      arc_2_15_13
 UP BND1      load_2_15_13  30
 BV BND1      arc_2_15_14
 UP BND1      load_2_15_14  30
 BV BND1      arc_2_15_16
 UP BND1      load_2_15_16  30
 BV BND1      arc_2_15_17
 UP BND1      load_2_15_17  30
 BV BND1      arc_2_15_18
 UP BND1      load_2_15_18  30
 BV BND1      arc_2_15_19
 UP BND1      load_2_15_19  30
 BV BND1      arc_2_16_0
 UP BND1      load_2_16_0  30
 BV BND1      arc_2_16_9
 UP BND1      load_2_16_9  30
 BV BND1      arc_2_16_10
 UP BND1      load_2_16_10  30
 BV BND1      arc_2_16_11
 UP BND1      load_2_16_11  30
 BV BND1      arc_2_16_12
 UP BND1      load_2_16_12  30
 BV BND1      arc_2_16_13
 UP BND1      load_2_16_13  30
 BV BND1      arc_2_16_14
 UP BND1      load_2_16_14  30
 BV BND1      arc_2_16_15
 UP BND1      load_2_16_15  30
 BV BND1      arc_2_16_17
 UP BND1      load_2_16_17  30
 BV BND1      arc_2_16_18
 UP BND1      load_2_16_18  30
 BV BND1      arc_2_16_19
 UP BND1      load_2_16_19  30
 BV BND1      arc_2_17_0
 UP BND1      load_2_17_0  30
 BV BND1      arc_2_17_9
 UP BND1      load_2_17_9  30
 BV BND1      arc_2_17_10
 UP BND1      load_2_17_10  30
 BV BND1      arc_2_17_11
 UP BND1      load_2_17_11  30
 BV BND1      arc_2_17_12
 UP BND1      load_2_17_12  30
 BV BND1      arc_2_17_13
 UP BND1      load_2_17_13  30
 BV BND1      arc_2_17_14
 UP BND1      load_2_17_14  30
 BV BND1      arc_2_17_15
 UP BND1      load_2_17_15  30
 BV BND1      arc_2_17_16
 UP BND1      load_2_17_16  30
 BV BND1      arc_2_17_18
 UP BND1      load_2_17_18  30
 BV BND1      arc_2_17_19
 UP BND1      load_2_17_19  30
 BV BND1      arc_2_18_0
 UP BND1      load_2_18_0  30
 BV BND1      arc_2_18_9
 UP BND1      load_2_18_9  30
 BV BND1      arc_2_18_10
 UP BND1      load_2_18_10  30
 BV BND1      arc_2_18_11
 UP BND1      load_2_18_11  30
 BV BND1      arc_2_18_12
 UP BND1      load_2_18_12  30
 BV BND1      arc_2_18_13
 UP BND1      load_2_18_13  30
 BV BND1      arc_2_18_14
 UP BND1      load_2_18_14  30
 BV BND1      arc_2_18_15
 UP BND1      load_2_18_15  30
 BV BND1      arc_2_18_16
 UP BND1      load_2_18_16  30
 BV BND1      arc_2_18_17
 UP BND1      load_2_18_17  30
 BV BND1      arc_2_18_19
 UP BND1      load_2_18_19  30
 BV BND1      arc_2_19_0
 UP BND1      load_2_19_0  30
 BV BND1      arc_2_19_9
 UP BND1      load_2_19_9  30
 BV BND1      arc_2_19_10
 UP BND1      load_2_19_10  30
 BV BND1      arc_2_19_11
 UP BND1      load_2_19_11  30
 BV BND1      arc_2_19_12
 UP BND1      load_2_19_12  30
 BV BND1      arc_2_19_13
 UP BND1      load_2_19_13  30
 BV BND1      arc_2_19_14
 UP BND1      load_2_19_14  30
 BV BND1      arc_2_19_15
 UP BND1      load_2_19_15  30
 BV BND1      arc_2_19_16
 UP BND1      load_2_19_16  30
 BV BND1      arc_2_19_17
 UP BND1      load_2_19_17  30
 BV BND1      arc_2_19_18
 UP BND1      load_2_19_18  30
ENDATA
