* Signature: 0xdbc9dfd45f81b42e
NAME 
OBJSENSE MAX
ROWS
 N  OBJ
 L  column_0
 L  column_1
 L  column_2
 L  column_3
 L  column_4
 L  column_5
 L  column_6
 L  column_7
 L  column_8
 L  column_9
COLUMNS
    psi[1,11]  OBJ       1
    psi[1,11]  column_0  1
    psi[1,11]  column_1  1
    psi[1,11]  column_2  1
    psi[1,11]  column_3  1
    psi[1,11]  column_4  1
    psi[1,11]  column_5  1
    psi[1,11]  column_6  1
    psi[1,11]  column_7  1
    psi[1,11]  column_8  1
    psi[1,11]  column_9  1
    psi[2,14]  OBJ       1
    psi[2,14]  column_0  1
    psi[2,14]  column_1  1
    psi[2,14]  column_2  1
    psi[2,14]  column_3  1
    psi[2,14]  column_4  1
    psi[2,14]  column_5  1
    psi[2,14]  column_6  1
    psi[2,14]  column_7  1
    psi[2,14]  column_8  1
    psi[2,14]  column_9  1
    psi[3,15]  OBJ       1
    psi[3,15]  column_0  1
    psi[3,15]  column_1  1
    psi[3,15]  column_2  1
    psi[3,15]  column_3  1
    psi[3,15]  column_4  1
    psi[3,15]  column_5  1
    psi[3,15]  column_6  1
    psi[3,15]  column_7  1
    psi[3,15]  column_8  1
    psi[3,15]  column_9  1
    psi[4,11]  OBJ       1
    psi[4,11]  column_0  1
    psi[4,11]  column_1  1
    psi[4,11]  column_2  1
    psi[4,11]  column_3  1
    psi[4,11]  column_4  1
    psi[4,11]  column_5  1
    psi[4,11]  column_6  1
    psi[4,11]  column_7  1
    psi[4,11]  column_8  1
    psi[4,11]  column_9  1
    psi[5,11]  OBJ       6.1875355036488555e-01
    psi[5,11]  column_0  1
    psi[5,11]  column_1  1
    psi[5,11]  column_2  1
    psi[5,11]  column_3  1
    psi[5,11]  column_4  1
    psi[5,11]  column_5  1
    psi[5,18]  OBJ       3.8124644963511450e-01
    psi[5,18]  column_6  1
    psi[5,18]  column_7  1
    psi[5,18]  column_8  1
    psi[5,18]  column_9  1
    psi[6,11]  OBJ       7.0347498361713323e-01
    psi[6,11]  column_0  1
    psi[6,11]  column_1  1
    psi[6,11]  column_2  1
    psi[6,11]  column_3  1
    psi[6,11]  column_4  1
    psi[6,11]  column_5  1
    psi[6,11]  column_6  1
    psi[6,11]  column_7  1
    psi[6,11]  column_8  1
    psi[6,20]  OBJ       2.9652501638286682e-01
    psi[6,20]  column_9  1
    psi[7,10]  OBJ       1.0000000000000069e+00
    psi[7,10]  column_0  1
    psi[7,10]  column_1  1
    psi[7,10]  column_2  1
    psi[7,10]  column_3  1
    psi[7,10]  column_4  1
    psi[7,10]  column_5  1
    psi[7,10]  column_6  1
    psi[7,10]  column_7  1
    psi[7,10]  column_8  1
    psi[7,10]  column_9  1
    psi[8,11]  OBJ       1
    psi[8,11]  column_0  1
    psi[8,11]  column_1  1
    psi[8,11]  column_2  1
    psi[8,11]  column_3  1
    psi[8,11]  column_4  1
    psi[8,11]  column_5  1
    psi[8,11]  column_6  1
    psi[8,11]  column_7  1
    psi[8,11]  column_8  1
    psi[8,11]  column_9  1
    psi[9,9]  OBJ       1
    psi[9,9]  column_0  1
    psi[9,9]  column_1  1
    psi[9,9]  column_2  1
    psi[9,9]  column_3  1
    psi[9,9]  column_4  1
    psi[9,9]  column_5  1
    psi[9,9]  column_6  1
    psi[9,9]  column_7  1
    psi[9,9]  column_8  1
    psi[9,9]  column_9  1
    psi[10,16]  OBJ       1
    psi[10,16]  column_0  1
    psi[10,16]  column_1  1
    psi[10,16]  column_2  1
    psi[10,16]  column_3  1
    psi[10,16]  column_4  1
    psi[10,16]  column_5  1
    psi[10,16]  column_6  1
    psi[10,16]  column_7  1
    psi[10,16]  column_8  1
    psi[10,16]  column_9  1
    psi[11,17]  OBJ       1
    psi[11,17]  column_0  1
    psi[11,17]  column_1  1
    psi[11,17]  column_2  1
    psi[11,17]  column_3  1
    psi[11,17]  column_4  1
    psi[11,17]  column_5  1
    psi[11,17]  column_6  1
    psi[11,17]  column_7  1
    psi[11,17]  column_8  1
    psi[11,17]  column_9  1
    psi[12,10]  OBJ       6.9673577869934089e-01
    psi[12,10]  column_0  1
    psi[12,10]  column_1  1
    psi[12,10]  column_2  1
    psi[12,10]  column_6  1
    psi[12,10]  column_7  1
    psi[12,10]  column_9  1
    psi[12,18]  OBJ       3.0326422130065911e-01
    psi[12,18]  column_3  1
    psi[12,18]  column_4  1
    psi[12,18]  column_5  1
    psi[12,18]  column_8  1
    psi[13,13]  OBJ       1
    psi[13,13]  column_0  1
    psi[13,13]  column_1  1
    psi[13,13]  column_2  1
    psi[13,13]  column_3  1
    psi[13,13]  column_4  1
    psi[13,13]  column_5  1
    psi[13,13]  column_6  1
    psi[13,13]  column_7  1
    psi[13,13]  column_8  1
    psi[13,13]  column_9  1
    psi[14,13]  OBJ       1
    psi[14,13]  column_0  1
    psi[14,13]  column_1  1
    psi[14,13]  column_2  1
    psi[14,13]  column_3  1
    psi[14,13]  column_4  1
    psi[14,13]  column_5  1
    psi[14,13]  column_6  1
    psi[14,13]  column_7  1
    psi[14,13]  column_8  1
    psi[14,13]  column_9  1
    psi[15,14]  OBJ       1
    psi[15,14]  column_0  1
    psi[15,14]  column_1  1
    psi[15,14]  column_2  1
    psi[15,14]  column_3  1
    psi[15,14]  column_4  1
    psi[15,14]  column_5  1
    psi[15,14]  column_6  1
    psi[15,14]  column_7  1
    psi[15,14]  column_8  1
    psi[15,14]  column_9  1
    psi[16,12]  OBJ       5.6482196947941687e-01
    psi[16,12]  column_0  1
    psi[16,12]  column_1  1
    psi[16,12]  column_3  1
    psi[16,12]  column_4  1
    psi[16,12]  column_5  1
    psi[16,12]  column_6  1
    psi[16,12]  column_7  1
    psi[16,13]  OBJ       1.2565821877486494e-01
    psi[16,13]  column_2  1
    psi[16,21]  OBJ       3.0951981174571819e-01
    psi[16,21]  column_8  1
    psi[16,21]  column_9  1
    psi[17,8]  OBJ       7.5738862295947262e-01
    psi[17,8]  column_0  1
    psi[17,8]  column_1  1
    psi[17,8]  column_3  1
    psi[17,8]  column_4  1
    psi[17,8]  column_8  1
    psi[17,8]  column_9  1
    psi[17,16]  OBJ       2.4261137704052738e-01
    psi[17,16]  column_2  1
    psi[17,16]  column_5  1
    psi[17,16]  column_6  1
    psi[17,16]  column_7  1
    psi[18,11]  OBJ       0.703474983617133
    psi[18,11]  column_0  1
    psi[18,11]  column_1  1
    psi[18,11]  column_2  1
    psi[18,11]  column_3  1
    psi[18,11]  column_5  1
    psi[18,11]  column_6  1
    psi[18,11]  column_8  1
    psi[18,11]  column_9  1
    psi[18,20]  OBJ       2.9652501638286693e-01
    psi[18,20]  column_4  1
    psi[18,20]  column_7  1
    psi[19,12]  OBJ       6.3608293443920894e-01
    psi[19,12]  column_0  1
    psi[19,12]  column_3  1
    psi[19,12]  column_4  1
    psi[19,12]  column_6  1
    psi[19,12]  column_7  1
    psi[19,12]  column_8  1
    psi[19,12]  column_9  1
    psi[19,20]  OBJ       3.6391706556079106e-01
    psi[19,20]  column_1  1
    psi[19,20]  column_2  1
    psi[19,20]  column_5  1
    psi[20,13]  OBJ       6.0575651230914307e-01
    psi[20,13]  column_1  1
    psi[20,13]  column_3  1
    psi[20,13]  column_5  1
    psi[20,13]  column_7  1
    psi[20,13]  column_8  1
    psi[20,13]  column_9  1
    psi[20,21]  OBJ       3.9424348769085693e-01
    psi[20,21]  column_0  1
    psi[20,21]  column_2  1
    psi[20,21]  column_4  1
    psi[20,21]  column_6  1
    a         OBJ       1
    a         column_0  1
    a         column_1  1
    a         column_2  1
    a         column_3  1
    a         column_4  1
    a         column_5  1
    a         column_6  1
    a         column_7  1
    a         column_8  1
    a         column_9  1
RHS
    RHS1      column_0  2.8358208955223906e-02
    RHS1      column_1  3.0645161290322596e-02
    RHS1      column_2  9.0871309830897126e-02
    RHS1      column_3  3.6538461538461568e-02
    RHS1      column_4  8.6302447002579136e-02
    RHS1      column_5  9.4807121661721089e-02
    RHS1      column_6  0.0877435575109994
    RHS1      column_7  9.4534412955465608e-02
    RHS1      column_8  8.4501126818274971e-02
    RHS1      column_9  8.5209825997952932e-02
BOUNDS
 FX BND1      psi[1,11]  0
 FX BND1      psi[2,14]  0
 FX BND1      psi[3,15]  0
 FX BND1      psi[4,11]  0
 FX BND1      psi[5,11]  0
 LO BND1      psi[5,18]  -0.05
 UP BND1      psi[5,18]  0.05
 FX BND1      psi[6,11]  0
 LO BND1      psi[6,20]  -0.05
 UP BND1      psi[6,20]  0.05
 FX BND1      psi[7,10]  0
 FX BND1      psi[8,11]  0
 FX BND1      psi[9,9]  0
 FX BND1      psi[10,16]  0
 FX BND1      psi[11,17]  0
 FX BND1      psi[12,10]  0
 LO BND1      psi[12,18]  -0.05
 UP BND1      psi[12,18]  0.05
 FX BND1      psi[13,13]  0
 FX BND1      psi[14,13]  0
 FX BND1      psi[15,14]  0
 FX BND1      psi[16,12]  0
 LO BND1      psi[16,13]  -0.05
 UP BND1      psi[16,13]  0.05
 LO BND1      psi[16,21]  -0.05
 UP BND1      psi[16,21]  0.05
 FX BND1      psi[17,8]  0
 LO BND1      psi[17,16]  -0.05
 UP BND1      psi[17,16]  0.05
 FX BND1      psi[18,11]  0
 LO BND1      psi[18,20]  -0.05
 UP BND1      psi[18,20]  0.05
 FX BND1      psi[19,12]  0
 LO BND1      psi[19,20]  -0.05
 UP BND1      psi[19,20]  0.05
 FX BND1      psi[20,13]  0
 LO BND1      psi[20,21]  -0.05
 UP BND1      psi[20,21]  0.05
 FR BND1      a       
ENDATA
