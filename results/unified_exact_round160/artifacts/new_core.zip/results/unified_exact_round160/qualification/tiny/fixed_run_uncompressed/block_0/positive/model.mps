* Signature: 0xb64c5304dd6467cc
NAME R160_physical_neighborhood
ROWS
 N  OBJ
 G  product_lb_0
 L  product_ub_1
 G  product_lb_2
 L  product_ub_3
 G  product_lb_4
 L  product_ub_5
 G  product_lb_6
 L  product_ub_7
 E  onehot_3_8
 E  normalized_mass_3_9
 E  normalized_ratio_3_10
 G  stock_lb_11
 L  stock_ub_12
 L  parent_nonstrict_scope_13
 E  normalization_14
 G  full_original_Gini_15
 E  unique_nonzero_owner_16
 E  unique_nonzero_owner_17
 E  unique_nonzero_owner_18
 L  arc_capacity_19
 L  arc_capacity_20
 L  arc_capacity_21
 L  arc_capacity_22
 L  arc_capacity_23
 L  arc_capacity_24
 L  arc_capacity_25
 G  connected_order_arc_26
 L  arc_capacity_27
 G  connected_order_arc_28
 L  arc_capacity_29
 G  connected_order_arc_30
 L  arc_capacity_31
 L  arc_capacity_32
 G  connected_order_arc_33
 L  arc_capacity_34
 G  connected_order_arc_35
 L  arc_capacity_36
 G  connected_order_arc_37
 L  arc_capacity_38
 L  arc_capacity_39
 G  connected_order_arc_40
 L  arc_capacity_41
 G  connected_order_arc_42
 L  arc_capacity_43
 G  connected_order_arc_44
 L  arc_capacity_45
 L  arc_capacity_46
 G  connected_order_arc_47
 L  arc_capacity_48
 G  connected_order_arc_49
 L  arc_capacity_50
 G  connected_order_arc_51
 E  depot_departure_or_bypass_52
 E  depot_return_or_bypass_53
 E  out_degree_54
 E  in_degree_55
 G  order_active_lb_56
 L  order_active_ub_57
 E  segment_load_conservation_58
 G  segment_prefix_lb_59
 L  segment_prefix_ub_60
 E  out_degree_61
 E  in_degree_62
 G  order_active_lb_63
 L  order_active_ub_64
 E  segment_load_conservation_65
 G  segment_prefix_lb_66
 L  segment_prefix_ub_67
 E  out_degree_68
 E  in_degree_69
 G  order_active_lb_70
 L  order_active_ub_71
 E  segment_load_conservation_72
 G  segment_prefix_lb_73
 L  segment_prefix_ub_74
 E  out_degree_75
 E  in_degree_76
 G  order_active_lb_77
 L  order_active_ub_78
 E  service_visit_def_79
 E  free_load_conservation_80
 G  fixed_segment_relative_order_81
 G  fixed_segment_relative_order_82
 L  original_T_including_depot_unload_83
 L  arc_capacity_84
 L  arc_capacity_85
 L  arc_capacity_86
 E  depot_departure_or_bypass_87
 E  depot_return_or_bypass_88
 E  out_degree_89
 E  in_degree_90
 G  order_active_lb_91
 L  order_active_ub_92
 E  service_visit_def_93
 E  free_load_conservation_94
 L  original_T_including_depot_unload_95
COLUMNS
    t         normalized_mass_3_9  -1
    t         normalization_14  1
    t         full_original_Gini_15  -2
    q         OBJ       1
    q         parent_nonstrict_scope_13  1
    q         full_original_Gini_15  4
    MARKER    'MARKER'                 'INTORG'
    x_3_0     product_lb_0  -2.4999999999974998e-01
    x_3_0     product_ub_1  -1.0000000000010003e+00
    x_3_0     onehot_3_8  1
    x_3_0     parent_nonstrict_scope_13  0.15
    MARKER    'MARKER'                 'INTEND'
    w_3_0     product_lb_0  1
    w_3_0     product_ub_1  1
    w_3_0     normalized_mass_3_9  1
    w_3_0     full_original_Gini_15  -1
    MARKER    'MARKER'                 'INTORG'
    x_3_1     OBJ       -0.15
    x_3_1     product_lb_2  -2.4999999999974998e-01
    x_3_1     product_ub_3  -1.0000000000010003e+00
    x_3_1     onehot_3_8  1
    x_3_1     stock_lb_11  1
    x_3_1     stock_ub_12  1
    x_3_1     unique_nonzero_owner_16  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_1     product_lb_2  1
    w_3_1     product_ub_3  1
    w_3_1     normalized_mass_3_9  1
    w_3_1     normalized_ratio_3_10  -1
    w_3_1     full_original_Gini_15  -2
    MARKER    'MARKER'                 'INTORG'
    x_3_2     product_lb_4  -2.4999999999974998e-01
    x_3_2     product_ub_5  -1.0000000000010003e+00
    x_3_2     onehot_3_8  1
    x_3_2     stock_lb_11  2
    x_3_2     stock_ub_12  2
    x_3_2     parent_nonstrict_scope_13  0.15
    x_3_2     unique_nonzero_owner_17  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_2     product_lb_4  1
    w_3_2     product_ub_5  1
    w_3_2     normalized_mass_3_9  1
    w_3_2     normalized_ratio_3_10  -2
    w_3_2     full_original_Gini_15  -5
    MARKER    'MARKER'                 'INTORG'
    x_3_3     OBJ       0.15
    x_3_3     product_lb_6  -2.4999999999974998e-01
    x_3_3     product_ub_7  -1.0000000000010003e+00
    x_3_3     onehot_3_8  1
    x_3_3     stock_lb_11  3
    x_3_3     stock_ub_12  3
    x_3_3     parent_nonstrict_scope_13  0.3
    x_3_3     unique_nonzero_owner_18  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_3     product_lb_6  1
    w_3_3     product_ub_7  1
    w_3_3     normalized_mass_3_9  1
    w_3_3     normalized_ratio_3_10  -3
    w_3_3     full_original_Gini_15  -8
    rho_3     normalized_ratio_3_10  1
    rho_3     normalization_14  1
    MARKER    'MARKER'                 'INTORG'
    service_0_3_1  unique_nonzero_owner_16  1
    service_0_3_1  service_visit_def_79  1
    service_0_3_1  free_load_conservation_80  1
    service_0_3_2  unique_nonzero_owner_17  1
    service_0_3_2  service_visit_def_79  1
    service_0_3_2  free_load_conservation_80  2
    service_0_3_3  unique_nonzero_owner_18  1
    service_0_3_3  service_visit_def_79  1
    service_0_3_3  free_load_conservation_80  3
    service_1_3_1  unique_nonzero_owner_16  1
    service_1_3_1  service_visit_def_93  1
    service_1_3_1  free_load_conservation_94  1
    service_1_3_2  unique_nonzero_owner_17  1
    service_1_3_2  service_visit_def_93  1
    service_1_3_2  free_load_conservation_94  2
    service_1_3_3  unique_nonzero_owner_18  1
    service_1_3_3  service_visit_def_93  1
    service_1_3_3  free_load_conservation_94  3
    MARKER    'MARKER'                 'INTEND'
    visit_0_1  out_degree_54  -1
    visit_0_1  in_degree_55  -1
    visit_0_1  order_active_lb_56  -1
    visit_0_1  order_active_ub_57  -4
    order_0_1  connected_order_arc_26  -1
    order_0_1  connected_order_arc_28  -1
    order_0_1  connected_order_arc_30  -1
    order_0_1  connected_order_arc_33  1
    order_0_1  connected_order_arc_40  1
    order_0_1  connected_order_arc_47  1
    order_0_1  order_active_lb_56  1
    order_0_1  order_active_ub_57  1
    order_0_1  fixed_segment_relative_order_81  -1
    visit_0_2  out_degree_61  -1
    visit_0_2  in_degree_62  -1
    visit_0_2  order_active_lb_63  -1
    visit_0_2  order_active_ub_64  -4
    order_0_2  connected_order_arc_26  1
    order_0_2  connected_order_arc_33  -1
    order_0_2  connected_order_arc_35  -1
    order_0_2  connected_order_arc_37  -1
    order_0_2  connected_order_arc_42  1
    order_0_2  connected_order_arc_49  1
    order_0_2  order_active_lb_63  1
    order_0_2  order_active_ub_64  1
    order_0_2  fixed_segment_relative_order_81  1
    order_0_2  fixed_segment_relative_order_82  -1
    visit_0_3  out_degree_68  -1
    visit_0_3  in_degree_69  -1
    visit_0_3  order_active_lb_70  -1
    visit_0_3  order_active_ub_71  -4
    order_0_3  connected_order_arc_28  1
    order_0_3  connected_order_arc_35  1
    order_0_3  connected_order_arc_40  -1
    order_0_3  connected_order_arc_42  -1
    order_0_3  connected_order_arc_44  -1
    order_0_3  connected_order_arc_51  1
    order_0_3  order_active_lb_70  1
    order_0_3  order_active_ub_71  1
    order_0_3  fixed_segment_relative_order_82  1
    visit_0_4  out_degree_75  -1
    visit_0_4  in_degree_76  -1
    visit_0_4  order_active_lb_77  -1
    visit_0_4  order_active_ub_78  -4
    visit_0_4  service_visit_def_79  -1
    order_0_4  connected_order_arc_30  1
    order_0_4  connected_order_arc_37  1
    order_0_4  connected_order_arc_44  1
    order_0_4  connected_order_arc_47  -1
    order_0_4  connected_order_arc_49  -1
    order_0_4  connected_order_arc_51  -1
    order_0_4  order_active_lb_77  1
    order_0_4  order_active_ub_78  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_0  arc_capacity_19  -3
    arc_0_0_0  depot_departure_or_bypass_52  1
    arc_0_0_0  depot_return_or_bypass_53  1
    MARKER    'MARKER'                 'INTEND'
    load_0_0_0  arc_capacity_19  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_1  arc_capacity_20  -3
    arc_0_0_1  depot_departure_or_bypass_52  1
    arc_0_0_1  in_degree_55  1
    arc_0_0_1  original_T_including_depot_unload_83  6.6666666666666663e-01
    MARKER    'MARKER'                 'INTEND'
    load_0_0_1  arc_capacity_20  1
    load_0_0_1  segment_load_conservation_58  -1
    load_0_0_1  segment_prefix_lb_59  1
    load_0_0_1  segment_prefix_ub_60  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_2  arc_capacity_21  -3
    arc_0_0_2  depot_departure_or_bypass_52  1
    arc_0_0_2  in_degree_62  1
    arc_0_0_2  original_T_including_depot_unload_83  9.4280904158206347e-01
    MARKER    'MARKER'                 'INTEND'
    load_0_0_2  arc_capacity_21  1
    load_0_0_2  segment_load_conservation_65  -1
    load_0_0_2  segment_prefix_lb_66  1
    load_0_0_2  segment_prefix_ub_67  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_3  arc_capacity_22  -3
    arc_0_0_3  depot_departure_or_bypass_52  1
    arc_0_0_3  in_degree_69  1
    arc_0_0_3  original_T_including_depot_unload_83  2
    MARKER    'MARKER'                 'INTEND'
    load_0_0_3  arc_capacity_22  1
    load_0_0_3  segment_load_conservation_72  -1
    load_0_0_3  segment_prefix_lb_73  1
    load_0_0_3  segment_prefix_ub_74  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_4  arc_capacity_23  -3
    arc_0_0_4  depot_departure_or_bypass_52  1
    arc_0_0_4  in_degree_76  1
    arc_0_0_4  original_T_including_depot_unload_83  2.1081851067789197e+00
    MARKER    'MARKER'                 'INTEND'
    load_0_0_4  arc_capacity_23  1
    load_0_0_4  free_load_conservation_80  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_0  arc_capacity_24  -3
    arc_0_1_0  depot_return_or_bypass_53  1
    arc_0_1_0  out_degree_54  1
    arc_0_1_0  original_T_including_depot_unload_83  6.6666666666666663e-01
    MARKER    'MARKER'                 'INTEND'
    load_0_1_0  arc_capacity_24  1
    load_0_1_0  segment_load_conservation_58  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_2  arc_capacity_25  -3
    arc_0_1_2  connected_order_arc_26  -5
    arc_0_1_2  out_degree_54  1
    arc_0_1_2  in_degree_62  1
    arc_0_1_2  original_T_including_depot_unload_83  6.6666666666666663e-01
    MARKER    'MARKER'                 'INTEND'
    load_0_1_2  arc_capacity_25  1
    load_0_1_2  segment_load_conservation_58  1
    load_0_1_2  segment_load_conservation_65  -1
    load_0_1_2  segment_prefix_lb_66  1
    load_0_1_2  segment_prefix_ub_67  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_3  arc_capacity_27  -3
    arc_0_1_3  connected_order_arc_28  -5
    arc_0_1_3  out_degree_54  1
    arc_0_1_3  in_degree_69  1
    arc_0_1_3  original_T_including_depot_unload_83  1.3333333333333333e+00
    MARKER    'MARKER'                 'INTEND'
    load_0_1_3  arc_capacity_27  1
    load_0_1_3  segment_load_conservation_58  1
    load_0_1_3  segment_load_conservation_72  -1
    load_0_1_3  segment_prefix_lb_73  1
    load_0_1_3  segment_prefix_ub_74  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_4  arc_capacity_29  -3
    arc_0_1_4  connected_order_arc_30  -5
    arc_0_1_4  out_degree_54  1
    arc_0_1_4  in_degree_76  1
    arc_0_1_4  original_T_including_depot_unload_83  1.4907119849998598e+00
    MARKER    'MARKER'                 'INTEND'
    load_0_1_4  arc_capacity_29  1
    load_0_1_4  segment_load_conservation_58  1
    load_0_1_4  free_load_conservation_80  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_0  arc_capacity_31  -3
    arc_0_2_0  depot_return_or_bypass_53  1
    arc_0_2_0  out_degree_61  1
    arc_0_2_0  original_T_including_depot_unload_83  9.4280904158206347e-01
    MARKER    'MARKER'                 'INTEND'
    load_0_2_0  arc_capacity_31  1
    load_0_2_0  segment_load_conservation_65  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_1  arc_capacity_32  -3
    arc_0_2_1  connected_order_arc_33  -5
    arc_0_2_1  in_degree_55  1
    arc_0_2_1  out_degree_61  1
    arc_0_2_1  original_T_including_depot_unload_83  6.6666666666666663e-01
    MARKER    'MARKER'                 'INTEND'
    load_0_2_1  arc_capacity_32  1
    load_0_2_1  segment_load_conservation_58  -1
    load_0_2_1  segment_prefix_lb_59  1
    load_0_2_1  segment_prefix_ub_60  1
    load_0_2_1  segment_load_conservation_65  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_3  arc_capacity_34  -3
    arc_0_2_3  connected_order_arc_35  -5
    arc_0_2_3  out_degree_61  1
    arc_0_2_3  in_degree_69  1
    arc_0_2_3  original_T_including_depot_unload_83  1.4907119849998598e+00
    MARKER    'MARKER'                 'INTEND'
    load_0_2_3  arc_capacity_34  1
    load_0_2_3  segment_load_conservation_65  1
    load_0_2_3  segment_load_conservation_72  -1
    load_0_2_3  segment_prefix_lb_73  1
    load_0_2_3  segment_prefix_ub_74  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_4  arc_capacity_36  -3
    arc_0_2_4  connected_order_arc_37  -5
    arc_0_2_4  out_degree_61  1
    arc_0_2_4  in_degree_76  1
    arc_0_2_4  original_T_including_depot_unload_83  1.3333333333333333e+00
    MARKER    'MARKER'                 'INTEND'
    load_0_2_4  arc_capacity_36  1
    load_0_2_4  segment_load_conservation_65  1
    load_0_2_4  free_load_conservation_80  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_0  arc_capacity_38  -3
    arc_0_3_0  depot_return_or_bypass_53  1
    arc_0_3_0  out_degree_68  1
    arc_0_3_0  original_T_including_depot_unload_83  2
    MARKER    'MARKER'                 'INTEND'
    load_0_3_0  arc_capacity_38  1
    load_0_3_0  segment_load_conservation_72  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_1  arc_capacity_39  -3
    arc_0_3_1  connected_order_arc_40  -5
    arc_0_3_1  in_degree_55  1
    arc_0_3_1  out_degree_68  1
    arc_0_3_1  original_T_including_depot_unload_83  1.3333333333333333e+00
    MARKER    'MARKER'                 'INTEND'
    load_0_3_1  arc_capacity_39  1
    load_0_3_1  segment_load_conservation_58  -1
    load_0_3_1  segment_prefix_lb_59  1
    load_0_3_1  segment_prefix_ub_60  1
    load_0_3_1  segment_load_conservation_72  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_2  arc_capacity_41  -3
    arc_0_3_2  connected_order_arc_42  -5
    arc_0_3_2  in_degree_62  1
    arc_0_3_2  out_degree_68  1
    arc_0_3_2  original_T_including_depot_unload_83  1.4907119849998598e+00
    MARKER    'MARKER'                 'INTEND'
    load_0_3_2  arc_capacity_41  1
    load_0_3_2  segment_load_conservation_65  -1
    load_0_3_2  segment_prefix_lb_66  1
    load_0_3_2  segment_prefix_ub_67  1
    load_0_3_2  segment_load_conservation_72  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_4  arc_capacity_43  -3
    arc_0_3_4  connected_order_arc_44  -5
    arc_0_3_4  out_degree_68  1
    arc_0_3_4  in_degree_76  1
    arc_0_3_4  original_T_including_depot_unload_83  6.6666666666666663e-01
    MARKER    'MARKER'                 'INTEND'
    load_0_3_4  arc_capacity_43  1
    load_0_3_4  segment_load_conservation_72  1
    load_0_3_4  free_load_conservation_80  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_0  arc_capacity_45  -3
    arc_0_4_0  depot_return_or_bypass_53  1
    arc_0_4_0  out_degree_75  1
    arc_0_4_0  original_T_including_depot_unload_83  2.1081851067789197e+00
    MARKER    'MARKER'                 'INTEND'
    load_0_4_0  arc_capacity_45  1
    load_0_4_0  free_load_conservation_80  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_1  arc_capacity_46  -3
    arc_0_4_1  connected_order_arc_47  -5
    arc_0_4_1  in_degree_55  1
    arc_0_4_1  out_degree_75  1
    arc_0_4_1  original_T_including_depot_unload_83  1.4907119849998598e+00
    MARKER    'MARKER'                 'INTEND'
    load_0_4_1  arc_capacity_46  1
    load_0_4_1  segment_load_conservation_58  -1
    load_0_4_1  segment_prefix_lb_59  1
    load_0_4_1  segment_prefix_ub_60  1
    load_0_4_1  free_load_conservation_80  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_2  arc_capacity_48  -3
    arc_0_4_2  connected_order_arc_49  -5
    arc_0_4_2  in_degree_62  1
    arc_0_4_2  out_degree_75  1
    arc_0_4_2  original_T_including_depot_unload_83  1.3333333333333333e+00
    MARKER    'MARKER'                 'INTEND'
    load_0_4_2  arc_capacity_48  1
    load_0_4_2  segment_load_conservation_65  -1
    load_0_4_2  segment_prefix_lb_66  1
    load_0_4_2  segment_prefix_ub_67  1
    load_0_4_2  free_load_conservation_80  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_3  arc_capacity_50  -3
    arc_0_4_3  connected_order_arc_51  -5
    arc_0_4_3  in_degree_69  1
    arc_0_4_3  out_degree_75  1
    arc_0_4_3  original_T_including_depot_unload_83  6.6666666666666663e-01
    MARKER    'MARKER'                 'INTEND'
    load_0_4_3  arc_capacity_50  1
    load_0_4_3  segment_load_conservation_72  -1
    load_0_4_3  segment_prefix_lb_73  1
    load_0_4_3  segment_prefix_ub_74  1
    load_0_4_3  free_load_conservation_80  1
    visit_1_4  out_degree_89  -1
    visit_1_4  in_degree_90  -1
    visit_1_4  order_active_lb_91  -1
    visit_1_4  order_active_ub_92  -1
    visit_1_4  service_visit_def_93  -1
    order_1_4  order_active_lb_91  1
    order_1_4  order_active_ub_92  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_0  arc_capacity_84  -3
    arc_1_0_0  depot_departure_or_bypass_87  1
    arc_1_0_0  depot_return_or_bypass_88  1
    MARKER    'MARKER'                 'INTEND'
    load_1_0_0  arc_capacity_84  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_4  arc_capacity_85  -3
    arc_1_0_4  depot_departure_or_bypass_87  1
    arc_1_0_4  in_degree_90  1
    arc_1_0_4  original_T_including_depot_unload_95  2.1081851067789197e+00
    MARKER    'MARKER'                 'INTEND'
    load_1_0_4  arc_capacity_85  1
    load_1_0_4  free_load_conservation_94  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_4_0  arc_capacity_86  -3
    arc_1_4_0  depot_return_or_bypass_88  1
    arc_1_4_0  out_degree_89  1
    arc_1_4_0  original_T_including_depot_unload_95  2.1081851067789197e+00
    MARKER    'MARKER'                 'INTEND'
    load_1_4_0  arc_capacity_86  1
    load_1_4_0  free_load_conservation_94  1
RHS
    RHS1      OBJ       -4.4999999999999996e-01
    RHS1      onehot_3_8  1
    RHS1      stock_ub_12  3
    RHS1      parent_nonstrict_scope_13  0.92500001
    RHS1      normalization_14  1
    RHS1      connected_order_arc_26  -4
    RHS1      connected_order_arc_28  -4
    RHS1      connected_order_arc_30  -4
    RHS1      connected_order_arc_33  -4
    RHS1      connected_order_arc_35  -4
    RHS1      connected_order_arc_37  -4
    RHS1      connected_order_arc_40  -4
    RHS1      connected_order_arc_42  -4
    RHS1      connected_order_arc_44  -4
    RHS1      connected_order_arc_47  -4
    RHS1      connected_order_arc_49  -4
    RHS1      connected_order_arc_51  -4
    RHS1      depot_departure_or_bypass_52  1
    RHS1      depot_return_or_bypass_53  1
    RHS1      segment_load_conservation_58  2
    RHS1      segment_prefix_ub_60  1
    RHS1      segment_load_conservation_65  -1
    RHS1      segment_prefix_lb_66  1
    RHS1      segment_prefix_ub_67  3
    RHS1      segment_load_conservation_72  2
    RHS1      segment_prefix_ub_74  1
    RHS1      fixed_segment_relative_order_81  1
    RHS1      fixed_segment_relative_order_82  1
    RHS1      original_T_including_depot_unload_83  72
    RHS1      depot_departure_or_bypass_87  1
    RHS1      depot_return_or_bypass_88  1
    RHS1      original_T_including_depot_unload_95  100
BOUNDS
 LO BND1      t         2.4999999999974998e-01
 UP BND1      t         1.0000000000010003e+00
 UP BND1      q         1
 BV BND1      x_3_0   
 UP BND1      w_3_0     1.0000000000010003e+00
 BV BND1      x_3_1   
 UP BND1      w_3_1     1.0000000000010003e+00
 BV BND1      x_3_2   
 UP BND1      w_3_2     1.0000000000010003e+00
 BV BND1      x_3_3   
 UP BND1      w_3_3     1.0000000000010003e+00
 UP BND1      rho_3     1
 BV BND1      service_0_3_1
 BV BND1      service_0_3_2
 BV BND1      service_0_3_3
 BV BND1      service_1_3_1
 BV BND1      service_1_3_2
 BV BND1      service_1_3_3
 FX BND1      visit_0_1  1
 UP BND1      order_0_1  4
 FX BND1      visit_0_2  1
 UP BND1      order_0_2  4
 FX BND1      visit_0_3  1
 UP BND1      order_0_3  4
 UP BND1      visit_0_4  1
 UP BND1      order_0_4  4
 BV BND1      arc_0_0_0
 FX BND1      load_0_0_0  0
 BV BND1      arc_0_0_1
 FX BND1      load_0_0_1  0
 BV BND1      arc_0_0_2
 FX BND1      load_0_0_2  0
 BV BND1      arc_0_0_3
 FX BND1      load_0_0_3  0
 BV BND1      arc_0_0_4
 FX BND1      load_0_0_4  0
 BV BND1      arc_0_1_0
 UP BND1      load_0_1_0  3
 FX BND1      arc_0_1_2  1
 BV BND1      arc_0_1_2
 UP BND1      load_0_1_2  3
 BV BND1      arc_0_1_3
 UP BND1      load_0_1_3  3
 BV BND1      arc_0_1_4
 UP BND1      load_0_1_4  3
 BV BND1      arc_0_2_0
 UP BND1      load_0_2_0  3
 BV BND1      arc_0_2_1
 UP BND1      load_0_2_1  3
 BV BND1      arc_0_2_3
 UP BND1      load_0_2_3  3
 BV BND1      arc_0_2_4
 UP BND1      load_0_2_4  3
 BV BND1      arc_0_3_0
 UP BND1      load_0_3_0  3
 BV BND1      arc_0_3_1
 UP BND1      load_0_3_1  3
 BV BND1      arc_0_3_2
 UP BND1      load_0_3_2  3
 BV BND1      arc_0_3_4
 UP BND1      load_0_3_4  3
 BV BND1      arc_0_4_0
 UP BND1      load_0_4_0  3
 BV BND1      arc_0_4_1
 UP BND1      load_0_4_1  3
 BV BND1      arc_0_4_2
 UP BND1      load_0_4_2  3
 BV BND1      arc_0_4_3
 UP BND1      load_0_4_3  3
 UP BND1      visit_1_4  1
 UP BND1      order_1_4  1
 BV BND1      arc_1_0_0
 FX BND1      load_1_0_0  0
 BV BND1      arc_1_0_4
 FX BND1      load_1_0_4  0
 BV BND1      arc_1_4_0
 UP BND1      load_1_4_0  3
ENDATA
