* Signature: 0x6455488be1cf4b53
NAME R160_physical_neighborhood
ROWS
 N  OBJ
 G  product_lb_0
 L  product_ub_1
 G  product_lb_2
 L  product_ub_3
 G  product_lb_4
 L  product_ub_5
 G  product_lb_6
 L  product_ub_7
 G  product_lb_8
 L  product_ub_9
 G  product_lb_10
 L  product_ub_11
 G  product_lb_12
 L  product_ub_13
 G  product_lb_14
 L  product_ub_15
 G  product_lb_16
 L  product_ub_17
 G  product_lb_18
 L  product_ub_19
 G  product_lb_20
 L  product_ub_21
 G  product_lb_22
 L  product_ub_23
 G  product_lb_24
 L  product_ub_25
 G  product_lb_26
 L  product_ub_27
 G  product_lb_28
 L  product_ub_29
 G  product_lb_30
 L  product_ub_31
 G  product_lb_32
 L  product_ub_33
 G  product_lb_34
 L  product_ub_35
 G  product_lb_36
 L  product_ub_37
 G  product_lb_38
 L  product_ub_39
 E  onehot_13_40
 E  normalized_mass_13_41
 E  normalized_ratio_13_42
 G  product_lb_43
 L  product_ub_44
 G  product_lb_45
 L  product_ub_46
 G  product_lb_47
 L  product_ub_48
 G  product_lb_49
 L  product_ub_50
 G  product_lb_51
 L  product_ub_52
 G  product_lb_53
 L  product_ub_54
 G  product_lb_55
 L  product_ub_56
 G  product_lb_57
 L  product_ub_58
 G  product_lb_59
 L  product_ub_60
 G  product_lb_61
 L  product_ub_62
 G  product_lb_63
 L  product_ub_64
 G  product_lb_65
 L  product_ub_66
 G  product_lb_67
 L  product_ub_68
 G  product_lb_69
 L  product_ub_70
 G  product_lb_71
 L  product_ub_72
 G  product_lb_73
 L  product_ub_74
 G  product_lb_75
 L  product_ub_76
 E  onehot_17_77
 E  normalized_mass_17_78
 E  normalized_ratio_17_79
 G  product_lb_80
 L  product_ub_81
 G  product_lb_82
 L  product_ub_83
 G  product_lb_84
 L  product_ub_85
 G  product_lb_86
 L  product_ub_87
 G  product_lb_88
 L  product_ub_89
 G  product_lb_90
 L  product_ub_91
 G  product_lb_92
 L  product_ub_93
 G  product_lb_94
 L  product_ub_95
 G  product_lb_96
 L  product_ub_97
 G  product_lb_98
 L  product_ub_99
 G  product_lb_100
 L  product_ub_101
 G  product_lb_102
 L  product_ub_103
 G  product_lb_104
 L  product_ub_105
 E  onehot_31_106
 E  normalized_mass_31_107
 E  normalized_ratio_31_108
 G  product_lb_109
 L  product_ub_110
 G  product_lb_111
 L  product_ub_112
 G  product_lb_113
 L  product_ub_114
 G  product_lb_115
 L  product_ub_116
 G  product_lb_117
 L  product_ub_118
 G  product_lb_119
 L  product_ub_120
 G  product_lb_121
 L  product_ub_122
 G  product_lb_123
 L  product_ub_124
 G  product_lb_125
 L  product_ub_126
 G  product_lb_127
 L  product_ub_128
 G  product_lb_129
 L  product_ub_130
 E  onehot_6_131
 E  normalized_mass_6_132
 E  normalized_ratio_6_133
 G  product_lb_134
 L  product_ub_135
 G  product_lb_136
 L  product_ub_137
 G  product_lb_138
 L  product_ub_139
 G  product_lb_140
 L  product_ub_141
 G  product_lb_142
 L  product_ub_143
 G  product_lb_144
 L  product_ub_145
 G  product_lb_146
 L  product_ub_147
 G  product_lb_148
 L  product_ub_149
 G  product_lb_150
 L  product_ub_151
 G  product_lb_152
 L  product_ub_153
 G  product_lb_154
 L  product_ub_155
 G  product_lb_156
 L  product_ub_157
 G  product_lb_158
 L  product_ub_159
 G  product_lb_160
 L  product_ub_161
 G  product_lb_162
 L  product_ub_163
 G  product_lb_164
 L  product_ub_165
 E  onehot_14_166
 E  normalized_mass_14_167
 E  normalized_ratio_14_168
 G  product_lb_169
 L  product_ub_170
 G  product_lb_171
 L  product_ub_172
 G  product_lb_173
 L  product_ub_174
 G  product_lb_175
 L  product_ub_176
 G  product_lb_177
 L  product_ub_178
 G  product_lb_179
 L  product_ub_180
 G  product_lb_181
 L  product_ub_182
 G  product_lb_183
 L  product_ub_184
 G  product_lb_185
 L  product_ub_186
 G  product_lb_187
 L  product_ub_188
 G  product_lb_189
 L  product_ub_190
 G  product_lb_191
 L  product_ub_192
 G  product_lb_193
 L  product_ub_194
 G  product_lb_195
 L  product_ub_196
 G  product_lb_197
 L  product_ub_198
 G  product_lb_199
 L  product_ub_200
 G  product_lb_201
 L  product_ub_202
 E  onehot_15_203
 E  normalized_mass_15_204
 E  normalized_ratio_15_205
 G  product_lb_206
 L  product_ub_207
 G  product_lb_208
 L  product_ub_209
 G  product_lb_210
 L  product_ub_211
 G  product_lb_212
 L  product_ub_213
 G  product_lb_214
 L  product_ub_215
 G  product_lb_216
 L  product_ub_217
 G  product_lb_218
 L  product_ub_219
 G  product_lb_220
 L  product_ub_221
 G  product_lb_222
 L  product_ub_223
 G  product_lb_224
 L  product_ub_225
 G  product_lb_226
 L  product_ub_227
 G  product_lb_228
 L  product_ub_229
 G  product_lb_230
 L  product_ub_231
 G  product_lb_232
 L  product_ub_233
 G  product_lb_234
 L  product_ub_235
 G  product_lb_236
 L  product_ub_237
 E  onehot_2_238
 E  normalized_mass_2_239
 E  normalized_ratio_2_240
 G  product_lb_241
 L  product_ub_242
 G  product_lb_243
 L  product_ub_244
 G  product_lb_245
 L  product_ub_246
 G  product_lb_247
 L  product_ub_248
 G  product_lb_249
 L  product_ub_250
 G  product_lb_251
 L  product_ub_252
 G  product_lb_253
 L  product_ub_254
 G  product_lb_255
 L  product_ub_256
 G  product_lb_257
 L  product_ub_258
 G  product_lb_259
 L  product_ub_260
 G  product_lb_261
 L  product_ub_262
 G  product_lb_263
 L  product_ub_264
 G  product_lb_265
 L  product_ub_266
 E  onehot_9_267
 E  normalized_mass_9_268
 E  normalized_ratio_9_269
 G  stock_lb_270
 L  stock_ub_271
 L  parent_nonstrict_scope_272
 G  block_pair_pos_273
 G  block_pair_neg_274
 G  block_pair_pos_275
 G  block_pair_neg_276
 G  block_pair_pos_277
 G  block_pair_neg_278
 G  block_pair_pos_279
 G  block_pair_neg_280
 G  block_pair_pos_281
 G  block_pair_neg_282
 G  block_pair_pos_283
 G  block_pair_neg_284
 G  block_pair_pos_285
 G  block_pair_neg_286
 G  block_pair_pos_287
 G  block_pair_neg_288
 G  block_pair_pos_289
 G  block_pair_neg_290
 G  block_pair_pos_291
 G  block_pair_neg_292
 G  block_pair_pos_293
 G  block_pair_neg_294
 G  block_pair_pos_295
 G  block_pair_neg_296
 G  block_pair_pos_297
 G  block_pair_neg_298
 G  block_pair_pos_299
 G  block_pair_neg_300
 G  block_pair_pos_301
 G  block_pair_neg_302
 G  block_pair_pos_303
 G  block_pair_neg_304
 G  block_pair_pos_305
 G  block_pair_neg_306
 G  block_pair_pos_307
 G  block_pair_neg_308
 G  block_pair_pos_309
 G  block_pair_neg_310
 G  block_pair_pos_311
 G  block_pair_neg_312
 G  block_pair_pos_313
 G  block_pair_neg_314
 G  block_pair_pos_315
 G  block_pair_neg_316
 G  block_pair_pos_317
 G  block_pair_neg_318
 G  block_pair_pos_319
 G  block_pair_neg_320
 G  block_pair_pos_321
 G  block_pair_neg_322
 G  block_pair_pos_323
 G  block_pair_neg_324
 G  block_pair_pos_325
 G  block_pair_neg_326
 G  block_pair_pos_327
 G  block_pair_neg_328
 E  normalization_329
 G  full_original_Gini_330
 E  unique_nonzero_owner_331
 E  unique_nonzero_owner_332
 E  unique_nonzero_owner_333
 E  unique_nonzero_owner_334
 E  unique_nonzero_owner_335
 E  unique_nonzero_owner_336
 E  unique_nonzero_owner_337
 E  unique_nonzero_owner_338
 E  unique_nonzero_owner_339
 E  unique_nonzero_owner_340
 E  unique_nonzero_owner_341
 E  unique_nonzero_owner_342
 E  unique_nonzero_owner_343
 E  unique_nonzero_owner_344
 E  unique_nonzero_owner_345
 E  unique_nonzero_owner_346
 E  unique_nonzero_owner_347
 E  unique_nonzero_owner_348
 E  unique_nonzero_owner_349
 E  unique_nonzero_owner_350
 E  unique_nonzero_owner_351
 E  unique_nonzero_owner_352
 E  unique_nonzero_owner_353
 E  unique_nonzero_owner_354
 E  unique_nonzero_owner_355
 E  unique_nonzero_owner_356
 E  unique_nonzero_owner_357
 E  unique_nonzero_owner_358
 E  unique_nonzero_owner_359
 E  unique_nonzero_owner_360
 E  unique_nonzero_owner_361
 E  unique_nonzero_owner_362
 E  unique_nonzero_owner_363
 E  unique_nonzero_owner_364
 E  unique_nonzero_owner_365
 E  unique_nonzero_owner_366
 E  unique_nonzero_owner_367
 E  unique_nonzero_owner_368
 E  unique_nonzero_owner_369
 E  unique_nonzero_owner_370
 E  unique_nonzero_owner_371
 E  unique_nonzero_owner_372
 E  unique_nonzero_owner_373
 E  unique_nonzero_owner_374
 E  unique_nonzero_owner_375
 E  unique_nonzero_owner_376
 E  unique_nonzero_owner_377
 E  unique_nonzero_owner_378
 E  unique_nonzero_owner_379
 E  unique_nonzero_owner_380
 E  unique_nonzero_owner_381
 E  unique_nonzero_owner_382
 E  unique_nonzero_owner_383
 E  unique_nonzero_owner_384
 E  unique_nonzero_owner_385
 E  unique_nonzero_owner_386
 E  unique_nonzero_owner_387
 E  unique_nonzero_owner_388
 E  unique_nonzero_owner_389
 E  unique_nonzero_owner_390
 E  unique_nonzero_owner_391
 E  unique_nonzero_owner_392
 E  unique_nonzero_owner_393
 E  unique_nonzero_owner_394
 E  unique_nonzero_owner_395
 E  unique_nonzero_owner_396
 E  unique_nonzero_owner_397
 E  unique_nonzero_owner_398
 E  unique_nonzero_owner_399
 E  unique_nonzero_owner_400
 E  unique_nonzero_owner_401
 E  unique_nonzero_owner_402
 E  unique_nonzero_owner_403
 E  unique_nonzero_owner_404
 E  unique_nonzero_owner_405
 E  unique_nonzero_owner_406
 E  unique_nonzero_owner_407
 E  unique_nonzero_owner_408
 E  unique_nonzero_owner_409
 E  unique_nonzero_owner_410
 E  unique_nonzero_owner_411
 E  unique_nonzero_owner_412
 E  unique_nonzero_owner_413
 E  unique_nonzero_owner_414
 E  unique_nonzero_owner_415
 E  unique_nonzero_owner_416
 E  unique_nonzero_owner_417
 E  unique_nonzero_owner_418
 E  unique_nonzero_owner_419
 E  unique_nonzero_owner_420
 E  unique_nonzero_owner_421
 E  unique_nonzero_owner_422
 E  unique_nonzero_owner_423
 E  unique_nonzero_owner_424
 E  unique_nonzero_owner_425
 E  unique_nonzero_owner_426
 E  unique_nonzero_owner_427
 E  unique_nonzero_owner_428
 E  unique_nonzero_owner_429
 E  unique_nonzero_owner_430
 E  unique_nonzero_owner_431
 E  unique_nonzero_owner_432
 E  unique_nonzero_owner_433
 E  unique_nonzero_owner_434
 E  unique_nonzero_owner_435
 E  unique_nonzero_owner_436
 E  unique_nonzero_owner_437
 E  unique_nonzero_owner_438
 E  unique_nonzero_owner_439
 E  unique_nonzero_owner_440
 E  unique_nonzero_owner_441
 E  unique_nonzero_owner_442
 E  unique_nonzero_owner_443
 E  unique_nonzero_owner_444
 E  unique_nonzero_owner_445
 L  arc_capacity_446
 L  arc_capacity_447
 L  arc_capacity_448
 L  arc_capacity_449
 L  arc_capacity_450
 L  arc_capacity_451
 L  arc_capacity_452
 L  arc_capacity_453
 L  arc_capacity_454
 L  arc_capacity_455
 L  arc_capacity_456
 L  arc_capacity_457
 L  arc_capacity_458
 L  arc_capacity_459
 L  arc_capacity_460
 L  arc_capacity_461
 L  arc_capacity_462
 G  connected_order_arc_463
 L  arc_capacity_464
 G  connected_order_arc_465
 L  arc_capacity_466
 G  connected_order_arc_467
 L  arc_capacity_468
 G  connected_order_arc_469
 L  arc_capacity_470
 G  connected_order_arc_471
 L  arc_capacity_472
 G  connected_order_arc_473
 L  arc_capacity_474
 G  connected_order_arc_475
 L  arc_capacity_476
 G  connected_order_arc_477
 L  arc_capacity_478
 G  connected_order_arc_479
 L  arc_capacity_480
 G  connected_order_arc_481
 L  arc_capacity_482
 G  connected_order_arc_483
 L  arc_capacity_484
 G  connected_order_arc_485
 L  arc_capacity_486
 G  connected_order_arc_487
 L  arc_capacity_488
 L  arc_capacity_489
 G  connected_order_arc_490
 L  arc_capacity_491
 G  connected_order_arc_492
 L  arc_capacity_493
 G  connected_order_arc_494
 L  arc_capacity_495
 G  connected_order_arc_496
 L  arc_capacity_497
 G  connected_order_arc_498
 L  arc_capacity_499
 G  connected_order_arc_500
 L  arc_capacity_501
 G  connected_order_arc_502
 L  arc_capacity_503
 G  connected_order_arc_504
 L  arc_capacity_505
 G  connected_order_arc_506
 L  arc_capacity_507
 G  connected_order_arc_508
 L  arc_capacity_509
 G  connected_order_arc_510
 L  arc_capacity_511
 G  connected_order_arc_512
 L  arc_capacity_513
 G  connected_order_arc_514
 L  arc_capacity_515
 L  arc_capacity_516
 G  connected_order_arc_517
 L  arc_capacity_518
 G  connected_order_arc_519
 L  arc_capacity_520
 G  connected_order_arc_521
 L  arc_capacity_522
 G  connected_order_arc_523
 L  arc_capacity_524
 G  connected_order_arc_525
 L  arc_capacity_526
 G  connected_order_arc_527
 L  arc_capacity_528
 G  connected_order_arc_529
 L  arc_capacity_530
 G  connected_order_arc_531
 L  arc_capacity_532
 G  connected_order_arc_533
 L  arc_capacity_534
 G  connected_order_arc_535
 L  arc_capacity_536
 G  connected_order_arc_537
 L  arc_capacity_538
 G  connected_order_arc_539
 L  arc_capacity_540
 G  connected_order_arc_541
 L  arc_capacity_542
 L  arc_capacity_543
 G  connected_order_arc_544
 L  arc_capacity_545
 G  connected_order_arc_546
 L  arc_capacity_547
 G  connected_order_arc_548
 L  arc_capacity_549
 G  connected_order_arc_550
 L  arc_capacity_551
 G  connected_order_arc_552
 L  arc_capacity_553
 G  connected_order_arc_554
 L  arc_capacity_555
 G  connected_order_arc_556
 L  arc_capacity_557
 G  connected_order_arc_558
 L  arc_capacity_559
 G  connected_order_arc_560
 L  arc_capacity_561
 G  connected_order_arc_562
 L  arc_capacity_563
 G  connected_order_arc_564
 L  arc_capacity_565
 G  connected_order_arc_566
 L  arc_capacity_567
 G  connected_order_arc_568
 L  arc_capacity_569
 L  arc_capacity_570
 G  connected_order_arc_571
 L  arc_capacity_572
 G  connected_order_arc_573
 L  arc_capacity_574
 G  connected_order_arc_575
 L  arc_capacity_576
 G  connected_order_arc_577
 L  arc_capacity_578
 G  connected_order_arc_579
 L  arc_capacity_580
 G  connected_order_arc_581
 L  arc_capacity_582
 G  connected_order_arc_583
 L  arc_capacity_584
 G  connected_order_arc_585
 L  arc_capacity_586
 G  connected_order_arc_587
 L  arc_capacity_588
 G  connected_order_arc_589
 L  arc_capacity_590
 G  connected_order_arc_591
 L  arc_capacity_592
 G  connected_order_arc_593
 L  arc_capacity_594
 G  connected_order_arc_595
 L  arc_capacity_596
 L  arc_capacity_597
 G  connected_order_arc_598
 L  arc_capacity_599
 G  connected_order_arc_600
 L  arc_capacity_601
 G  connected_order_arc_602
 L  arc_capacity_603
 G  connected_order_arc_604
 L  arc_capacity_605
 G  connected_order_arc_606
 L  arc_capacity_607
 G  connected_order_arc_608
 L  arc_capacity_609
 G  connected_order_arc_610
 L  arc_capacity_611
 G  connected_order_arc_612
 L  arc_capacity_613
 G  connected_order_arc_614
 L  arc_capacity_615
 G  connected_order_arc_616
 L  arc_capacity_617
 G  connected_order_arc_618
 L  arc_capacity_619
 G  connected_order_arc_620
 L  arc_capacity_621
 G  connected_order_arc_622
 L  arc_capacity_623
 L  arc_capacity_624
 G  connected_order_arc_625
 L  arc_capacity_626
 G  connected_order_arc_627
 L  arc_capacity_628
 G  connected_order_arc_629
 L  arc_capacity_630
 G  connected_order_arc_631
 L  arc_capacity_632
 G  connected_order_arc_633
 L  arc_capacity_634
 G  connected_order_arc_635
 L  arc_capacity_636
 G  connected_order_arc_637
 L  arc_capacity_638
 G  connected_order_arc_639
 L  arc_capacity_640
 G  connected_order_arc_641
 L  arc_capacity_642
 G  connected_order_arc_643
 L  arc_capacity_644
 G  connected_order_arc_645
 L  arc_capacity_646
 G  connected_order_arc_647
 L  arc_capacity_648
 G  connected_order_arc_649
 L  arc_capacity_650
 L  arc_capacity_651
 G  connected_order_arc_652
 L  arc_capacity_653
 G  connected_order_arc_654
 L  arc_capacity_655
 G  connected_order_arc_656
 L  arc_capacity_657
 G  connected_order_arc_658
 L  arc_capacity_659
 G  connected_order_arc_660
 L  arc_capacity_661
 G  connected_order_arc_662
 L  arc_capacity_663
 G  connected_order_arc_664
 L  arc_capacity_665
 G  connected_order_arc_666
 L  arc_capacity_667
 G  connected_order_arc_668
 L  arc_capacity_669
 G  connected_order_arc_670
 L  arc_capacity_671
 G  connected_order_arc_672
 L  arc_capacity_673
 G  connected_order_arc_674
 L  arc_capacity_675
 G  connected_order_arc_676
 L  arc_capacity_677
 L  arc_capacity_678
 G  connected_order_arc_679
 L  arc_capacity_680
 G  connected_order_arc_681
 L  arc_capacity_682
 G  connected_order_arc_683
 L  arc_capacity_684
 G  connected_order_arc_685
 L  arc_capacity_686
 G  connected_order_arc_687
 L  arc_capacity_688
 G  connected_order_arc_689
 L  arc_capacity_690
 G  connected_order_arc_691
 L  arc_capacity_692
 G  connected_order_arc_693
 L  arc_capacity_694
 G  connected_order_arc_695
 L  arc_capacity_696
 G  connected_order_arc_697
 L  arc_capacity_698
 G  connected_order_arc_699
 L  arc_capacity_700
 G  connected_order_arc_701
 L  arc_capacity_702
 G  connected_order_arc_703
 L  arc_capacity_704
 L  arc_capacity_705
 G  connected_order_arc_706
 L  arc_capacity_707
 G  connected_order_arc_708
 L  arc_capacity_709
 G  connected_order_arc_710
 L  arc_capacity_711
 G  connected_order_arc_712
 L  arc_capacity_713
 G  connected_order_arc_714
 L  arc_capacity_715
 G  connected_order_arc_716
 L  arc_capacity_717
 G  connected_order_arc_718
 L  arc_capacity_719
 G  connected_order_arc_720
 L  arc_capacity_721
 G  connected_order_arc_722
 L  arc_capacity_723
 G  connected_order_arc_724
 L  arc_capacity_725
 G  connected_order_arc_726
 L  arc_capacity_727
 G  connected_order_arc_728
 L  arc_capacity_729
 G  connected_order_arc_730
 L  arc_capacity_731
 L  arc_capacity_732
 G  connected_order_arc_733
 L  arc_capacity_734
 G  connected_order_arc_735
 L  arc_capacity_736
 G  connected_order_arc_737
 L  arc_capacity_738
 G  connected_order_arc_739
 L  arc_capacity_740
 G  connected_order_arc_741
 L  arc_capacity_742
 G  connected_order_arc_743
 L  arc_capacity_744
 G  connected_order_arc_745
 L  arc_capacity_746
 G  connected_order_arc_747
 L  arc_capacity_748
 G  connected_order_arc_749
 L  arc_capacity_750
 G  connected_order_arc_751
 L  arc_capacity_752
 G  connected_order_arc_753
 L  arc_capacity_754
 G  connected_order_arc_755
 L  arc_capacity_756
 G  connected_order_arc_757
 L  arc_capacity_758
 L  arc_capacity_759
 G  connected_order_arc_760
 L  arc_capacity_761
 G  connected_order_arc_762
 L  arc_capacity_763
 G  connected_order_arc_764
 L  arc_capacity_765
 G  connected_order_arc_766
 L  arc_capacity_767
 G  connected_order_arc_768
 L  arc_capacity_769
 G  connected_order_arc_770
 L  arc_capacity_771
 G  connected_order_arc_772
 L  arc_capacity_773
 G  connected_order_arc_774
 L  arc_capacity_775
 G  connected_order_arc_776
 L  arc_capacity_777
 G  connected_order_arc_778
 L  arc_capacity_779
 G  connected_order_arc_780
 L  arc_capacity_781
 G  connected_order_arc_782
 L  arc_capacity_783
 G  connected_order_arc_784
 L  arc_capacity_785
 L  arc_capacity_786
 G  connected_order_arc_787
 L  arc_capacity_788
 G  connected_order_arc_789
 L  arc_capacity_790
 G  connected_order_arc_791
 L  arc_capacity_792
 G  connected_order_arc_793
 L  arc_capacity_794
 G  connected_order_arc_795
 L  arc_capacity_796
 G  connected_order_arc_797
 L  arc_capacity_798
 G  connected_order_arc_799
 L  arc_capacity_800
 G  connected_order_arc_801
 L  arc_capacity_802
 G  connected_order_arc_803
 L  arc_capacity_804
 G  connected_order_arc_805
 L  arc_capacity_806
 G  connected_order_arc_807
 L  arc_capacity_808
 G  connected_order_arc_809
 L  arc_capacity_810
 G  connected_order_arc_811
 L  arc_capacity_812
 L  arc_capacity_813
 G  connected_order_arc_814
 L  arc_capacity_815
 G  connected_order_arc_816
 L  arc_capacity_817
 G  connected_order_arc_818
 L  arc_capacity_819
 G  connected_order_arc_820
 L  arc_capacity_821
 G  connected_order_arc_822
 L  arc_capacity_823
 G  connected_order_arc_824
 L  arc_capacity_825
 G  connected_order_arc_826
 L  arc_capacity_827
 G  connected_order_arc_828
 L  arc_capacity_829
 G  connected_order_arc_830
 L  arc_capacity_831
 G  connected_order_arc_832
 L  arc_capacity_833
 G  connected_order_arc_834
 L  arc_capacity_835
 G  connected_order_arc_836
 L  arc_capacity_837
 G  connected_order_arc_838
 E  depot_departure_or_bypass_839
 E  depot_return_or_bypass_840
 E  out_degree_841
 E  in_degree_842
 G  order_active_lb_843
 L  order_active_ub_844
 E  segment_load_conservation_845
 G  segment_prefix_lb_846
 L  segment_prefix_ub_847
 E  out_degree_848
 E  in_degree_849
 G  order_active_lb_850
 L  order_active_ub_851
 E  segment_load_conservation_852
 G  segment_prefix_lb_853
 L  segment_prefix_ub_854
 E  out_degree_855
 E  in_degree_856
 G  order_active_lb_857
 L  order_active_ub_858
 E  segment_load_conservation_859
 G  segment_prefix_lb_860
 L  segment_prefix_ub_861
 E  out_degree_862
 E  in_degree_863
 G  order_active_lb_864
 L  order_active_ub_865
 E  segment_load_conservation_866
 G  segment_prefix_lb_867
 L  segment_prefix_ub_868
 E  out_degree_869
 E  in_degree_870
 G  order_active_lb_871
 L  order_active_ub_872
 E  segment_load_conservation_873
 G  segment_prefix_lb_874
 L  segment_prefix_ub_875
 E  out_degree_876
 E  in_degree_877
 G  order_active_lb_878
 L  order_active_ub_879
 E  segment_load_conservation_880
 G  segment_prefix_lb_881
 L  segment_prefix_ub_882
 E  out_degree_883
 E  in_degree_884
 G  order_active_lb_885
 L  order_active_ub_886
 E  service_visit_def_887
 E  free_load_conservation_888
 E  out_degree_889
 E  in_degree_890
 G  order_active_lb_891
 L  order_active_ub_892
 E  service_visit_def_893
 E  free_load_conservation_894
 E  out_degree_895
 E  in_degree_896
 G  order_active_lb_897
 L  order_active_ub_898
 E  service_visit_def_899
 E  free_load_conservation_900
 E  out_degree_901
 E  in_degree_902
 G  order_active_lb_903
 L  order_active_ub_904
 E  service_visit_def_905
 E  free_load_conservation_906
 E  out_degree_907
 E  in_degree_908
 G  order_active_lb_909
 L  order_active_ub_910
 E  service_visit_def_911
 E  free_load_conservation_912
 E  out_degree_913
 E  in_degree_914
 G  order_active_lb_915
 L  order_active_ub_916
 E  service_visit_def_917
 E  free_load_conservation_918
 E  out_degree_919
 E  in_degree_920
 G  order_active_lb_921
 L  order_active_ub_922
 E  service_visit_def_923
 E  free_load_conservation_924
 E  out_degree_925
 E  in_degree_926
 G  order_active_lb_927
 L  order_active_ub_928
 E  service_visit_def_929
 E  free_load_conservation_930
 G  fixed_segment_relative_order_931
 G  fixed_segment_relative_order_932
 G  fixed_segment_relative_order_933
 G  fixed_segment_relative_order_934
 G  fixed_segment_relative_order_935
 L  original_T_including_depot_unload_936
 L  arc_capacity_937
 L  arc_capacity_938
 L  arc_capacity_939
 L  arc_capacity_940
 L  arc_capacity_941
 L  arc_capacity_942
 L  arc_capacity_943
 L  arc_capacity_944
 L  arc_capacity_945
 L  arc_capacity_946
 L  arc_capacity_947
 L  arc_capacity_948
 L  arc_capacity_949
 L  arc_capacity_950
 L  arc_capacity_951
 G  connected_order_arc_952
 L  arc_capacity_953
 G  connected_order_arc_954
 L  arc_capacity_955
 G  connected_order_arc_956
 L  arc_capacity_957
 G  connected_order_arc_958
 L  arc_capacity_959
 G  connected_order_arc_960
 L  arc_capacity_961
 G  connected_order_arc_962
 L  arc_capacity_963
 G  connected_order_arc_964
 L  arc_capacity_965
 G  connected_order_arc_966
 L  arc_capacity_967
 G  connected_order_arc_968
 L  arc_capacity_969
 G  connected_order_arc_970
 L  arc_capacity_971
 G  connected_order_arc_972
 L  arc_capacity_973
 L  arc_capacity_974
 G  connected_order_arc_975
 L  arc_capacity_976
 G  connected_order_arc_977
 L  arc_capacity_978
 G  connected_order_arc_979
 L  arc_capacity_980
 G  connected_order_arc_981
 L  arc_capacity_982
 G  connected_order_arc_983
 L  arc_capacity_984
 G  connected_order_arc_985
 L  arc_capacity_986
 G  connected_order_arc_987
 L  arc_capacity_988
 G  connected_order_arc_989
 L  arc_capacity_990
 G  connected_order_arc_991
 L  arc_capacity_992
 G  connected_order_arc_993
 L  arc_capacity_994
 G  connected_order_arc_995
 L  arc_capacity_996
 L  arc_capacity_997
 G  connected_order_arc_998
 L  arc_capacity_999
 G  connected_order_arc_1000
 L  arc_capacity_1001
 G  connected_order_arc_1002
 L  arc_capacity_1003
 G  connected_order_arc_1004
 L  arc_capacity_1005
 G  connected_order_arc_1006
 L  arc_capacity_1007
 G  connected_order_arc_1008
 L  arc_capacity_1009
 G  connected_order_arc_1010
 L  arc_capacity_1011
 G  connected_order_arc_1012
 L  arc_capacity_1013
 G  connected_order_arc_1014
 L  arc_capacity_1015
 G  connected_order_arc_1016
 L  arc_capacity_1017
 G  connected_order_arc_1018
 L  arc_capacity_1019
 L  arc_capacity_1020
 G  connected_order_arc_1021
 L  arc_capacity_1022
 G  connected_order_arc_1023
 L  arc_capacity_1024
 G  connected_order_arc_1025
 L  arc_capacity_1026
 G  connected_order_arc_1027
 L  arc_capacity_1028
 G  connected_order_arc_1029
 L  arc_capacity_1030
 G  connected_order_arc_1031
 L  arc_capacity_1032
 G  connected_order_arc_1033
 L  arc_capacity_1034
 G  connected_order_arc_1035
 L  arc_capacity_1036
 G  connected_order_arc_1037
 L  arc_capacity_1038
 G  connected_order_arc_1039
 L  arc_capacity_1040
 G  connected_order_arc_1041
 L  arc_capacity_1042
 L  arc_capacity_1043
 G  connected_order_arc_1044
 L  arc_capacity_1045
 G  connected_order_arc_1046
 L  arc_capacity_1047
 G  connected_order_arc_1048
 L  arc_capacity_1049
 G  connected_order_arc_1050
 L  arc_capacity_1051
 G  connected_order_arc_1052
 L  arc_capacity_1053
 G  connected_order_arc_1054
 L  arc_capacity_1055
 G  connected_order_arc_1056
 L  arc_capacity_1057
 G  connected_order_arc_1058
 L  arc_capacity_1059
 G  connected_order_arc_1060
 L  arc_capacity_1061
 G  connected_order_arc_1062
 L  arc_capacity_1063
 G  connected_order_arc_1064
 L  arc_capacity_1065
 L  arc_capacity_1066
 G  connected_order_arc_1067
 L  arc_capacity_1068
 G  connected_order_arc_1069
 L  arc_capacity_1070
 G  connected_order_arc_1071
 L  arc_capacity_1072
 G  connected_order_arc_1073
 L  arc_capacity_1074
 G  connected_order_arc_1075
 L  arc_capacity_1076
 G  connected_order_arc_1077
 L  arc_capacity_1078
 G  connected_order_arc_1079
 L  arc_capacity_1080
 G  connected_order_arc_1081
 L  arc_capacity_1082
 G  connected_order_arc_1083
 L  arc_capacity_1084
 G  connected_order_arc_1085
 L  arc_capacity_1086
 G  connected_order_arc_1087
 L  arc_capacity_1088
 L  arc_capacity_1089
 G  connected_order_arc_1090
 L  arc_capacity_1091
 G  connected_order_arc_1092
 L  arc_capacity_1093
 G  connected_order_arc_1094
 L  arc_capacity_1095
 G  connected_order_arc_1096
 L  arc_capacity_1097
 G  connected_order_arc_1098
 L  arc_capacity_1099
 G  connected_order_arc_1100
 L  arc_capacity_1101
 G  connected_order_arc_1102
 L  arc_capacity_1103
 G  connected_order_arc_1104
 L  arc_capacity_1105
 G  connected_order_arc_1106
 L  arc_capacity_1107
 G  connected_order_arc_1108
 L  arc_capacity_1109
 G  connected_order_arc_1110
 L  arc_capacity_1111
 L  arc_capacity_1112
 G  connected_order_arc_1113
 L  arc_capacity_1114
 G  connected_order_arc_1115
 L  arc_capacity_1116
 G  connected_order_arc_1117
 L  arc_capacity_1118
 G  connected_order_arc_1119
 L  arc_capacity_1120
 G  connected_order_arc_1121
 L  arc_capacity_1122
 G  connected_order_arc_1123
 L  arc_capacity_1124
 G  connected_order_arc_1125
 L  arc_capacity_1126
 G  connected_order_arc_1127
 L  arc_capacity_1128
 G  connected_order_arc_1129
 L  arc_capacity_1130
 G  connected_order_arc_1131
 L  arc_capacity_1132
 G  connected_order_arc_1133
 L  arc_capacity_1134
 L  arc_capacity_1135
 G  connected_order_arc_1136
 L  arc_capacity_1137
 G  connected_order_arc_1138
 L  arc_capacity_1139
 G  connected_order_arc_1140
 L  arc_capacity_1141
 G  connected_order_arc_1142
 L  arc_capacity_1143
 G  connected_order_arc_1144
 L  arc_capacity_1145
 G  connected_order_arc_1146
 L  arc_capacity_1147
 G  connected_order_arc_1148
 L  arc_capacity_1149
 G  connected_order_arc_1150
 L  arc_capacity_1151
 G  connected_order_arc_1152
 L  arc_capacity_1153
 G  connected_order_arc_1154
 L  arc_capacity_1155
 G  connected_order_arc_1156
 L  arc_capacity_1157
 L  arc_capacity_1158
 G  connected_order_arc_1159
 L  arc_capacity_1160
 G  connected_order_arc_1161
 L  arc_capacity_1162
 G  connected_order_arc_1163
 L  arc_capacity_1164
 G  connected_order_arc_1165
 L  arc_capacity_1166
 G  connected_order_arc_1167
 L  arc_capacity_1168
 G  connected_order_arc_1169
 L  arc_capacity_1170
 G  connected_order_arc_1171
 L  arc_capacity_1172
 G  connected_order_arc_1173
 L  arc_capacity_1174
 G  connected_order_arc_1175
 L  arc_capacity_1176
 G  connected_order_arc_1177
 L  arc_capacity_1178
 G  connected_order_arc_1179
 L  arc_capacity_1180
 L  arc_capacity_1181
 G  connected_order_arc_1182
 L  arc_capacity_1183
 G  connected_order_arc_1184
 L  arc_capacity_1185
 G  connected_order_arc_1186
 L  arc_capacity_1187
 G  connected_order_arc_1188
 L  arc_capacity_1189
 G  connected_order_arc_1190
 L  arc_capacity_1191
 G  connected_order_arc_1192
 L  arc_capacity_1193
 G  connected_order_arc_1194
 L  arc_capacity_1195
 G  connected_order_arc_1196
 L  arc_capacity_1197
 G  connected_order_arc_1198
 L  arc_capacity_1199
 G  connected_order_arc_1200
 L  arc_capacity_1201
 G  connected_order_arc_1202
 L  arc_capacity_1203
 L  arc_capacity_1204
 G  connected_order_arc_1205
 L  arc_capacity_1206
 G  connected_order_arc_1207
 L  arc_capacity_1208
 G  connected_order_arc_1209
 L  arc_capacity_1210
 G  connected_order_arc_1211
 L  arc_capacity_1212
 G  connected_order_arc_1213
 L  arc_capacity_1214
 G  connected_order_arc_1215
 L  arc_capacity_1216
 G  connected_order_arc_1217
 L  arc_capacity_1218
 G  connected_order_arc_1219
 L  arc_capacity_1220
 G  connected_order_arc_1221
 L  arc_capacity_1222
 G  connected_order_arc_1223
 L  arc_capacity_1224
 G  connected_order_arc_1225
 E  depot_departure_or_bypass_1226
 E  depot_return_or_bypass_1227
 E  out_degree_1228
 E  in_degree_1229
 G  order_active_lb_1230
 L  order_active_ub_1231
 E  segment_load_conservation_1232
 G  segment_prefix_lb_1233
 L  segment_prefix_ub_1234
 E  out_degree_1235
 E  in_degree_1236
 G  order_active_lb_1237
 L  order_active_ub_1238
 E  segment_load_conservation_1239
 G  segment_prefix_lb_1240
 L  segment_prefix_ub_1241
 E  out_degree_1242
 E  in_degree_1243
 G  order_active_lb_1244
 L  order_active_ub_1245
 E  segment_load_conservation_1246
 G  segment_prefix_lb_1247
 L  segment_prefix_ub_1248
 E  out_degree_1249
 E  in_degree_1250
 G  order_active_lb_1251
 L  order_active_ub_1252
 E  segment_load_conservation_1253
 G  segment_prefix_lb_1254
 L  segment_prefix_ub_1255
 E  out_degree_1256
 E  in_degree_1257
 G  order_active_lb_1258
 L  order_active_ub_1259
 E  service_visit_def_1260
 E  free_load_conservation_1261
 E  out_degree_1262
 E  in_degree_1263
 G  order_active_lb_1264
 L  order_active_ub_1265
 E  service_visit_def_1266
 E  free_load_conservation_1267
 E  out_degree_1268
 E  in_degree_1269
 G  order_active_lb_1270
 L  order_active_ub_1271
 E  service_visit_def_1272
 E  free_load_conservation_1273
 E  out_degree_1274
 E  in_degree_1275
 G  order_active_lb_1276
 L  order_active_ub_1277
 E  service_visit_def_1278
 E  free_load_conservation_1279
 E  out_degree_1280
 E  in_degree_1281
 G  order_active_lb_1282
 L  order_active_ub_1283
 E  service_visit_def_1284
 E  free_load_conservation_1285
 E  out_degree_1286
 E  in_degree_1287
 G  order_active_lb_1288
 L  order_active_ub_1289
 E  service_visit_def_1290
 E  free_load_conservation_1291
 E  out_degree_1292
 E  in_degree_1293
 G  order_active_lb_1294
 L  order_active_ub_1295
 E  service_visit_def_1296
 E  free_load_conservation_1297
 E  out_degree_1298
 E  in_degree_1299
 G  order_active_lb_1300
 L  order_active_ub_1301
 E  service_visit_def_1302
 E  free_load_conservation_1303
 G  fixed_segment_relative_order_1304
 G  fixed_segment_relative_order_1305
 G  fixed_segment_relative_order_1306
 L  original_T_including_depot_unload_1307
 L  arc_capacity_1308
 L  arc_capacity_1309
 L  arc_capacity_1310
 L  arc_capacity_1311
 L  arc_capacity_1312
 L  arc_capacity_1313
 L  arc_capacity_1314
 L  arc_capacity_1315
 L  arc_capacity_1316
 L  arc_capacity_1317
 L  arc_capacity_1318
 L  arc_capacity_1319
 L  arc_capacity_1320
 L  arc_capacity_1321
 G  connected_order_arc_1322
 L  arc_capacity_1323
 G  connected_order_arc_1324
 L  arc_capacity_1325
 G  connected_order_arc_1326
 L  arc_capacity_1327
 G  connected_order_arc_1328
 L  arc_capacity_1329
 G  connected_order_arc_1330
 L  arc_capacity_1331
 G  connected_order_arc_1332
 L  arc_capacity_1333
 G  connected_order_arc_1334
 L  arc_capacity_1335
 G  connected_order_arc_1336
 L  arc_capacity_1337
 G  connected_order_arc_1338
 L  arc_capacity_1339
 G  connected_order_arc_1340
 L  arc_capacity_1341
 L  arc_capacity_1342
 G  connected_order_arc_1343
 L  arc_capacity_1344
 G  connected_order_arc_1345
 L  arc_capacity_1346
 G  connected_order_arc_1347
 L  arc_capacity_1348
 G  connected_order_arc_1349
 L  arc_capacity_1350
 G  connected_order_arc_1351
 L  arc_capacity_1352
 G  connected_order_arc_1353
 L  arc_capacity_1354
 G  connected_order_arc_1355
 L  arc_capacity_1356
 G  connected_order_arc_1357
 L  arc_capacity_1358
 G  connected_order_arc_1359
 L  arc_capacity_1360
 G  connected_order_arc_1361
 L  arc_capacity_1362
 L  arc_capacity_1363
 G  connected_order_arc_1364
 L  arc_capacity_1365
 G  connected_order_arc_1366
 L  arc_capacity_1367
 G  connected_order_arc_1368
 L  arc_capacity_1369
 G  connected_order_arc_1370
 L  arc_capacity_1371
 G  connected_order_arc_1372
 L  arc_capacity_1373
 G  connected_order_arc_1374
 L  arc_capacity_1375
 G  connected_order_arc_1376
 L  arc_capacity_1377
 G  connected_order_arc_1378
 L  arc_capacity_1379
 G  connected_order_arc_1380
 L  arc_capacity_1381
 G  connected_order_arc_1382
 L  arc_capacity_1383
 L  arc_capacity_1384
 G  connected_order_arc_1385
 L  arc_capacity_1386
 G  connected_order_arc_1387
 L  arc_capacity_1388
 G  connected_order_arc_1389
 L  arc_capacity_1390
 G  connected_order_arc_1391
 L  arc_capacity_1392
 G  connected_order_arc_1393
 L  arc_capacity_1394
 G  connected_order_arc_1395
 L  arc_capacity_1396
 G  connected_order_arc_1397
 L  arc_capacity_1398
 G  connected_order_arc_1399
 L  arc_capacity_1400
 G  connected_order_arc_1401
 L  arc_capacity_1402
 G  connected_order_arc_1403
 L  arc_capacity_1404
 L  arc_capacity_1405
 G  connected_order_arc_1406
 L  arc_capacity_1407
 G  connected_order_arc_1408
 L  arc_capacity_1409
 G  connected_order_arc_1410
 L  arc_capacity_1411
 G  connected_order_arc_1412
 L  arc_capacity_1413
 G  connected_order_arc_1414
 L  arc_capacity_1415
 G  connected_order_arc_1416
 L  arc_capacity_1417
 G  connected_order_arc_1418
 L  arc_capacity_1419
 G  connected_order_arc_1420
 L  arc_capacity_1421
 G  connected_order_arc_1422
 L  arc_capacity_1423
 G  connected_order_arc_1424
 L  arc_capacity_1425
 L  arc_capacity_1426
 G  connected_order_arc_1427
 L  arc_capacity_1428
 G  connected_order_arc_1429
 L  arc_capacity_1430
 G  connected_order_arc_1431
 L  arc_capacity_1432
 G  connected_order_arc_1433
 L  arc_capacity_1434
 G  connected_order_arc_1435
 L  arc_capacity_1436
 G  connected_order_arc_1437
 L  arc_capacity_1438
 G  connected_order_arc_1439
 L  arc_capacity_1440
 G  connected_order_arc_1441
 L  arc_capacity_1442
 G  connected_order_arc_1443
 L  arc_capacity_1444
 G  connected_order_arc_1445
 L  arc_capacity_1446
 L  arc_capacity_1447
 G  connected_order_arc_1448
 L  arc_capacity_1449
 G  connected_order_arc_1450
 L  arc_capacity_1451
 G  connected_order_arc_1452
 L  arc_capacity_1453
 G  connected_order_arc_1454
 L  arc_capacity_1455
 G  connected_order_arc_1456
 L  arc_capacity_1457
 G  connected_order_arc_1458
 L  arc_capacity_1459
 G  connected_order_arc_1460
 L  arc_capacity_1461
 G  connected_order_arc_1462
 L  arc_capacity_1463
 G  connected_order_arc_1464
 L  arc_capacity_1465
 G  connected_order_arc_1466
 L  arc_capacity_1467
 L  arc_capacity_1468
 G  connected_order_arc_1469
 L  arc_capacity_1470
 G  connected_order_arc_1471
 L  arc_capacity_1472
 G  connected_order_arc_1473
 L  arc_capacity_1474
 G  connected_order_arc_1475
 L  arc_capacity_1476
 G  connected_order_arc_1477
 L  arc_capacity_1478
 G  connected_order_arc_1479
 L  arc_capacity_1480
 G  connected_order_arc_1481
 L  arc_capacity_1482
 G  connected_order_arc_1483
 L  arc_capacity_1484
 G  connected_order_arc_1485
 L  arc_capacity_1486
 G  connected_order_arc_1487
 L  arc_capacity_1488
 L  arc_capacity_1489
 G  connected_order_arc_1490
 L  arc_capacity_1491
 G  connected_order_arc_1492
 L  arc_capacity_1493
 G  connected_order_arc_1494
 L  arc_capacity_1495
 G  connected_order_arc_1496
 L  arc_capacity_1497
 G  connected_order_arc_1498
 L  arc_capacity_1499
 G  connected_order_arc_1500
 L  arc_capacity_1501
 G  connected_order_arc_1502
 L  arc_capacity_1503
 G  connected_order_arc_1504
 L  arc_capacity_1505
 G  connected_order_arc_1506
 L  arc_capacity_1507
 G  connected_order_arc_1508
 L  arc_capacity_1509
 L  arc_capacity_1510
 G  connected_order_arc_1511
 L  arc_capacity_1512
 G  connected_order_arc_1513
 L  arc_capacity_1514
 G  connected_order_arc_1515
 L  arc_capacity_1516
 G  connected_order_arc_1517
 L  arc_capacity_1518
 G  connected_order_arc_1519
 L  arc_capacity_1520
 G  connected_order_arc_1521
 L  arc_capacity_1522
 G  connected_order_arc_1523
 L  arc_capacity_1524
 G  connected_order_arc_1525
 L  arc_capacity_1526
 G  connected_order_arc_1527
 L  arc_capacity_1528
 G  connected_order_arc_1529
 L  arc_capacity_1530
 L  arc_capacity_1531
 G  connected_order_arc_1532
 L  arc_capacity_1533
 G  connected_order_arc_1534
 L  arc_capacity_1535
 G  connected_order_arc_1536
 L  arc_capacity_1537
 G  connected_order_arc_1538
 L  arc_capacity_1539
 G  connected_order_arc_1540
 L  arc_capacity_1541
 G  connected_order_arc_1542
 L  arc_capacity_1543
 G  connected_order_arc_1544
 L  arc_capacity_1545
 G  connected_order_arc_1546
 L  arc_capacity_1547
 G  connected_order_arc_1548
 L  arc_capacity_1549
 G  connected_order_arc_1550
 E  depot_departure_or_bypass_1551
 E  depot_return_or_bypass_1552
 E  out_degree_1553
 E  in_degree_1554
 G  order_active_lb_1555
 L  order_active_ub_1556
 E  segment_load_conservation_1557
 G  segment_prefix_lb_1558
 L  segment_prefix_ub_1559
 E  out_degree_1560
 E  in_degree_1561
 G  order_active_lb_1562
 L  order_active_ub_1563
 E  segment_load_conservation_1564
 G  segment_prefix_lb_1565
 L  segment_prefix_ub_1566
 E  out_degree_1567
 E  in_degree_1568
 G  order_active_lb_1569
 L  order_active_ub_1570
 E  segment_load_conservation_1571
 G  segment_prefix_lb_1572
 L  segment_prefix_ub_1573
 E  out_degree_1574
 E  in_degree_1575
 G  order_active_lb_1576
 L  order_active_ub_1577
 E  service_visit_def_1578
 E  free_load_conservation_1579
 E  out_degree_1580
 E  in_degree_1581
 G  order_active_lb_1582
 L  order_active_ub_1583
 E  service_visit_def_1584
 E  free_load_conservation_1585
 E  out_degree_1586
 E  in_degree_1587
 G  order_active_lb_1588
 L  order_active_ub_1589
 E  service_visit_def_1590
 E  free_load_conservation_1591
 E  out_degree_1592
 E  in_degree_1593
 G  order_active_lb_1594
 L  order_active_ub_1595
 E  service_visit_def_1596
 E  free_load_conservation_1597
 E  out_degree_1598
 E  in_degree_1599
 G  order_active_lb_1600
 L  order_active_ub_1601
 E  service_visit_def_1602
 E  free_load_conservation_1603
 E  out_degree_1604
 E  in_degree_1605
 G  order_active_lb_1606
 L  order_active_ub_1607
 E  service_visit_def_1608
 E  free_load_conservation_1609
 E  out_degree_1610
 E  in_degree_1611
 G  order_active_lb_1612
 L  order_active_ub_1613
 E  service_visit_def_1614
 E  free_load_conservation_1615
 E  out_degree_1616
 E  in_degree_1617
 G  order_active_lb_1618
 L  order_active_ub_1619
 E  service_visit_def_1620
 E  free_load_conservation_1621
 G  fixed_segment_relative_order_1622
 G  fixed_segment_relative_order_1623
 L  original_T_including_depot_unload_1624
COLUMNS
    t         normalized_mass_13_41  -1
    t         normalized_mass_17_78  -1
    t         normalized_mass_31_107  -1
    t         normalized_mass_6_132  -1
    t         normalized_mass_14_167  -1
    t         normalized_mass_15_204  -1
    t         normalized_mass_2_239  -1
    t         normalized_mass_9_268  -1
    t         normalization_329  2.3083333333333336e+01
    t         full_original_Gini_330  -8.5752380952381031e+01
    q         OBJ       1
    q         parent_nonstrict_scope_272  1
    q         full_original_Gini_330  35
    MARKER    'MARKER'                 'INTORG'
    x_13_0    OBJ       0.03
    x_13_0    product_lb_0  -2.5545373449005350e-02
    x_13_0    product_ub_1  -0.0433212996390325
    x_13_0    onehot_13_40  1
    x_13_0    parent_nonstrict_scope_272  0.096
    x_13_0    unique_nonzero_owner_331  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_0    product_lb_0  1
    w_13_0    product_ub_1  1
    w_13_0    normalized_mass_13_41  1
    w_13_0    full_original_Gini_330  -2.3083333333333336e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_1    OBJ       1.8000000000000002e-02
    x_13_1    product_lb_2  -2.5545373449005350e-02
    x_13_1    product_ub_3  -0.0433212996390325
    x_13_1    onehot_13_40  1
    x_13_1    stock_lb_270  1
    x_13_1    stock_ub_271  1
    x_13_1    parent_nonstrict_scope_272  0.084
    x_13_1    unique_nonzero_owner_332  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_1    product_lb_2  1
    w_13_1    product_ub_3  1
    w_13_1    normalized_mass_13_41  1
    w_13_1    normalized_ratio_13_42  -0.125
    w_13_1    full_original_Gini_330  -1.9708333333333336e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_2    OBJ       6.0000000000000053e-03
    x_13_2    product_lb_4  -2.5545373449005350e-02
    x_13_2    product_ub_5  -0.0433212996390325
    x_13_2    onehot_13_40  1
    x_13_2    stock_lb_270  2
    x_13_2    stock_ub_271  2
    x_13_2    parent_nonstrict_scope_272  7.2000000000000008e-02
    x_13_2    unique_nonzero_owner_333  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_2    product_lb_4  1
    w_13_2    product_ub_5  1
    w_13_2    normalized_mass_13_41  1
    w_13_2    normalized_ratio_13_42  -0.25
    w_13_2    full_original_Gini_330  -1.6333333333333332e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_3    OBJ       -6.0000000000000053e-03
    x_13_3    product_lb_6  -2.5545373449005350e-02
    x_13_3    product_ub_7  -0.0433212996390325
    x_13_3    onehot_13_40  1
    x_13_3    stock_lb_270  3
    x_13_3    stock_ub_271  3
    x_13_3    parent_nonstrict_scope_272  0.06
    x_13_3    unique_nonzero_owner_334  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_3    product_lb_6  1
    w_13_3    product_ub_7  1
    w_13_3    normalized_mass_13_41  1
    w_13_3    normalized_ratio_13_42  -0.375
    w_13_3    full_original_Gini_330  -1.2958333333333332e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_4    OBJ       -1.8000000000000002e-02
    x_13_4    product_lb_8  -2.5545373449005350e-02
    x_13_4    product_ub_9  -0.0433212996390325
    x_13_4    onehot_13_40  1
    x_13_4    stock_lb_270  4
    x_13_4    stock_ub_271  4
    x_13_4    parent_nonstrict_scope_272  0.048
    x_13_4    unique_nonzero_owner_335  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_4    product_lb_8  1
    w_13_4    product_ub_9  1
    w_13_4    normalized_mass_13_41  1
    w_13_4    normalized_ratio_13_42  -0.5
    w_13_4    full_original_Gini_330  -9.7833333333333332e+00
    MARKER    'MARKER'                 'INTORG'
    x_13_5    OBJ       -0.03
    x_13_5    product_lb_10  -2.5545373449005350e-02
    x_13_5    product_ub_11  -0.0433212996390325
    x_13_5    onehot_13_40  1
    x_13_5    stock_lb_270  5
    x_13_5    stock_ub_271  5
    x_13_5    parent_nonstrict_scope_272  3.6000000000000004e-02
    x_13_5    unique_nonzero_owner_336  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_5    product_lb_10  1
    w_13_5    product_ub_11  1
    w_13_5    normalized_mass_13_41  1
    w_13_5    normalized_ratio_13_42  -0.625
    w_13_5    full_original_Gini_330  -7.4583333333333339e+00
    MARKER    'MARKER'                 'INTORG'
    x_13_6    OBJ       -0.042
    x_13_6    product_lb_12  -2.5545373449005350e-02
    x_13_6    product_ub_13  -0.0433212996390325
    x_13_6    onehot_13_40  1
    x_13_6    stock_lb_270  6
    x_13_6    stock_ub_271  6
    x_13_6    parent_nonstrict_scope_272  0.024
    x_13_6    unique_nonzero_owner_337  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_6    product_lb_12  1
    w_13_6    product_ub_13  1
    w_13_6    normalized_mass_13_41  1
    w_13_6    normalized_ratio_13_42  -0.75
    w_13_6    full_original_Gini_330  -5.5476190476190474e+00
    MARKER    'MARKER'                 'INTORG'
    x_13_7    OBJ       -5.4000000000000006e-02
    x_13_7    product_lb_14  -2.5545373449005350e-02
    x_13_7    product_ub_15  -0.0433212996390325
    x_13_7    onehot_13_40  1
    x_13_7    stock_lb_270  7
    x_13_7    stock_ub_271  7
    x_13_7    parent_nonstrict_scope_272  0.012
    x_13_7    unique_nonzero_owner_338  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_7    product_lb_14  1
    w_13_7    product_ub_15  1
    w_13_7    normalized_mass_13_41  1
    w_13_7    normalized_ratio_13_42  -0.875
    w_13_7    full_original_Gini_330  -4.9416666666666664e+00
    MARKER    'MARKER'                 'INTORG'
    x_13_8    OBJ       -0.066
    x_13_8    product_lb_16  -2.5545373449005350e-02
    x_13_8    product_ub_17  -0.0433212996390325
    x_13_8    onehot_13_40  1
    x_13_8    stock_lb_270  8
    x_13_8    stock_ub_271  8
    x_13_8    unique_nonzero_owner_339  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_8    product_lb_16  1
    w_13_8    product_ub_17  1
    w_13_8    normalized_mass_13_41  1
    w_13_8    normalized_ratio_13_42  -1
    w_13_8    full_original_Gini_330  -4.8166666666666664e+00
    MARKER    'MARKER'                 'INTORG'
    x_13_9    OBJ       -5.4000000000000006e-02
    x_13_9    product_lb_18  -2.5545373449005350e-02
    x_13_9    product_ub_19  -0.0433212996390325
    x_13_9    onehot_13_40  1
    x_13_9    stock_lb_270  9
    x_13_9    stock_ub_271  9
    x_13_9    parent_nonstrict_scope_272  0.012
    x_13_9    unique_nonzero_owner_340  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_9    product_lb_18  1
    w_13_9    product_ub_19  1
    w_13_9    normalized_mass_13_41  1
    w_13_9    normalized_ratio_13_42  -1.125
    w_13_9    full_original_Gini_330  -7.6916666666666664e+00
    MARKER    'MARKER'                 'INTORG'
    x_13_10   OBJ       -0.042
    x_13_10   product_lb_20  -2.5545373449005350e-02
    x_13_10   product_ub_21  -0.0433212996390325
    x_13_10   onehot_13_40  1
    x_13_10   stock_lb_270  10
    x_13_10   stock_ub_271  10
    x_13_10   parent_nonstrict_scope_272  0.024
    x_13_10   unique_nonzero_owner_341  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_10   product_lb_20  1
    w_13_10   product_ub_21  1
    w_13_10   normalized_mass_13_41  1
    w_13_10   normalized_ratio_13_42  -1.25
    w_13_10   full_original_Gini_330  -1.0666666666666666e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_11   OBJ       -0.03
    x_13_11   product_lb_22  -2.5545373449005350e-02
    x_13_11   product_ub_23  -0.0433212996390325
    x_13_11   onehot_13_40  1
    x_13_11   stock_lb_270  11
    x_13_11   stock_ub_271  11
    x_13_11   parent_nonstrict_scope_272  3.6000000000000004e-02
    x_13_11   unique_nonzero_owner_342  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_11   product_lb_22  1
    w_13_11   product_ub_23  1
    w_13_11   normalized_mass_13_41  1
    w_13_11   normalized_ratio_13_42  -1.375
    w_13_11   full_original_Gini_330  -1.4041666666666668e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_12   OBJ       -1.8000000000000002e-02
    x_13_12   product_lb_24  -2.5545373449005350e-02
    x_13_12   product_ub_25  -0.0433212996390325
    x_13_12   onehot_13_40  1
    x_13_12   stock_lb_270  12
    x_13_12   stock_ub_271  12
    x_13_12   parent_nonstrict_scope_272  0.048
    x_13_12   unique_nonzero_owner_343  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_12   product_lb_24  1
    w_13_12   product_ub_25  1
    w_13_12   normalized_mass_13_41  1
    w_13_12   normalized_ratio_13_42  -1.5
    w_13_12   full_original_Gini_330  -1.7416666666666664e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_13   OBJ       -6.0000000000000053e-03
    x_13_13   product_lb_26  -2.5545373449005350e-02
    x_13_13   product_ub_27  -0.0433212996390325
    x_13_13   onehot_13_40  1
    x_13_13   stock_lb_270  13
    x_13_13   stock_ub_271  13
    x_13_13   parent_nonstrict_scope_272  0.06
    MARKER    'MARKER'                 'INTEND'
    w_13_13   product_lb_26  1
    w_13_13   product_ub_27  1
    w_13_13   normalized_mass_13_41  1
    w_13_13   normalized_ratio_13_42  -1.625
    w_13_13   full_original_Gini_330  -2.0791666666666664e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_14   OBJ       6.0000000000000053e-03
    x_13_14   product_lb_28  -2.5545373449005350e-02
    x_13_14   product_ub_29  -0.0433212996390325
    x_13_14   onehot_13_40  1
    x_13_14   stock_lb_270  14
    x_13_14   stock_ub_271  14
    x_13_14   parent_nonstrict_scope_272  7.2000000000000008e-02
    x_13_14   unique_nonzero_owner_344  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_14   product_lb_28  1
    w_13_14   product_ub_29  1
    w_13_14   normalized_mass_13_41  1
    w_13_14   normalized_ratio_13_42  -1.75
    w_13_14   full_original_Gini_330  -2.4166666666666664e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_15   OBJ       1.8000000000000002e-02
    x_13_15   product_lb_30  -2.5545373449005350e-02
    x_13_15   product_ub_31  -0.0433212996390325
    x_13_15   onehot_13_40  1
    x_13_15   stock_lb_270  15
    x_13_15   stock_ub_271  15
    x_13_15   parent_nonstrict_scope_272  0.084
    x_13_15   unique_nonzero_owner_345  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_15   product_lb_30  1
    w_13_15   product_ub_31  1
    w_13_15   normalized_mass_13_41  1
    w_13_15   normalized_ratio_13_42  -1.875
    w_13_15   full_original_Gini_330  -2.7541666666666664e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_16   OBJ       0.03
    x_13_16   product_lb_32  -2.5545373449005350e-02
    x_13_16   product_ub_33  -0.0433212996390325
    x_13_16   onehot_13_40  1
    x_13_16   stock_lb_270  16
    x_13_16   stock_ub_271  16
    x_13_16   parent_nonstrict_scope_272  0.096
    x_13_16   unique_nonzero_owner_346  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_16   product_lb_32  1
    w_13_16   product_ub_33  1
    w_13_16   normalized_mass_13_41  1
    w_13_16   normalized_ratio_13_42  -2
    w_13_16   full_original_Gini_330  -3.0916666666666664e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_17   OBJ       4.1999999999999996e-02
    x_13_17   product_lb_34  -2.5545373449005350e-02
    x_13_17   product_ub_35  -0.0433212996390325
    x_13_17   onehot_13_40  1
    x_13_17   stock_lb_270  17
    x_13_17   stock_ub_271  17
    x_13_17   parent_nonstrict_scope_272  0.108
    x_13_17   unique_nonzero_owner_347  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_17   product_lb_34  1
    w_13_17   product_ub_35  1
    w_13_17   normalized_mass_13_41  1
    w_13_17   normalized_ratio_13_42  -2.125
    w_13_17   full_original_Gini_330  -3.4291666666666664e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_18   OBJ       5.3999999999999992e-02
    x_13_18   product_lb_36  -2.5545373449005350e-02
    x_13_18   product_ub_37  -0.0433212996390325
    x_13_18   onehot_13_40  1
    x_13_18   stock_lb_270  18
    x_13_18   stock_ub_271  18
    x_13_18   parent_nonstrict_scope_272  0.12
    x_13_18   unique_nonzero_owner_348  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_18   product_lb_36  1
    w_13_18   product_ub_37  1
    w_13_18   normalized_mass_13_41  1
    w_13_18   normalized_ratio_13_42  -2.25
    w_13_18   full_original_Gini_330  -3.7666666666666664e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_19   OBJ       0.066
    x_13_19   product_lb_38  -2.5545373449005350e-02
    x_13_19   product_ub_39  -0.0433212996390325
    x_13_19   onehot_13_40  1
    x_13_19   stock_lb_270  19
    x_13_19   stock_ub_271  19
    x_13_19   parent_nonstrict_scope_272  0.132
    x_13_19   unique_nonzero_owner_349  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_19   product_lb_38  1
    w_13_19   product_ub_39  1
    w_13_19   normalized_mass_13_41  1
    w_13_19   normalized_ratio_13_42  -2.375
    w_13_19   full_original_Gini_330  -4.1041666666666664e+01
    rho_13    normalized_ratio_13_42  1
    rho_13    block_pair_pos_283  -1
    rho_13    block_pair_neg_284  1
    rho_13    block_pair_pos_285  -1
    rho_13    block_pair_neg_286  1
    rho_13    block_pair_pos_287  -1
    rho_13    block_pair_neg_288  1
    rho_13    block_pair_pos_289  -1
    rho_13    block_pair_neg_290  1
    rho_13    block_pair_pos_291  -1
    rho_13    block_pair_neg_292  1
    rho_13    block_pair_pos_293  -1
    rho_13    block_pair_neg_294  1
    rho_13    block_pair_pos_295  -1
    rho_13    block_pair_neg_296  1
    rho_13    normalization_329  1
    MARKER    'MARKER'                 'INTORG'
    x_17_0    OBJ       0.06075
    x_17_0    product_lb_43  -2.5545373449005350e-02
    x_17_0    product_ub_44  -0.0433212996390325
    x_17_0    onehot_17_77  1
    x_17_0    parent_nonstrict_scope_272  0.1215
    x_17_0    unique_nonzero_owner_350  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_0    product_lb_43  1
    w_17_0    product_ub_44  1
    w_17_0    normalized_mass_17_78  1
    w_17_0    full_original_Gini_330  -2.3083333333333336e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_1    OBJ       4.7249999999999986e-02
    x_17_1    product_lb_45  -2.5545373449005350e-02
    x_17_1    product_ub_46  -0.0433212996390325
    x_17_1    onehot_17_77  1
    x_17_1    stock_lb_270  1
    x_17_1    stock_ub_271  1
    x_17_1    parent_nonstrict_scope_272  1.0799999999999998e-01
    x_17_1    unique_nonzero_owner_351  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_1    product_lb_45  1
    w_17_1    product_ub_46  1
    w_17_1    normalized_mass_17_78  1
    w_17_1    normalized_ratio_17_79  -1.1111111111111110e-01
    w_17_1    full_original_Gini_330  -2.0083333333333336e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_2    OBJ       0.03375
    x_17_2    product_lb_47  -2.5545373449005350e-02
    x_17_2    product_ub_48  -0.0433212996390325
    x_17_2    onehot_17_77  1
    x_17_2    stock_lb_270  2
    x_17_2    stock_ub_271  2
    x_17_2    parent_nonstrict_scope_272  0.0945
    x_17_2    unique_nonzero_owner_352  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_2    product_lb_47  1
    w_17_2    product_ub_48  1
    w_17_2    normalized_mass_17_78  1
    w_17_2    normalized_ratio_17_79  -2.2222222222222221e-01
    w_17_2    full_original_Gini_330  -1.7083333333333339e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_3    OBJ       2.0250000000000004e-02
    x_17_3    product_lb_49  -2.5545373449005350e-02
    x_17_3    product_ub_50  -0.0433212996390325
    x_17_3    onehot_17_77  1
    x_17_3    stock_lb_270  3
    x_17_3    stock_ub_271  3
    x_17_3    parent_nonstrict_scope_272  0.081
    MARKER    'MARKER'                 'INTEND'
    w_17_3    product_lb_49  1
    w_17_3    product_ub_50  1
    w_17_3    normalized_mass_17_78  1
    w_17_3    normalized_ratio_17_79  -3.3333333333333331e-01
    w_17_3    full_original_Gini_330  -1.4083333333333332e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_4    OBJ       6.7500000000000060e-03
    x_17_4    product_lb_51  -2.5545373449005350e-02
    x_17_4    product_ub_52  -0.0433212996390325
    x_17_4    onehot_17_77  1
    x_17_4    stock_lb_270  4
    x_17_4    stock_ub_271  4
    x_17_4    parent_nonstrict_scope_272  0.0675
    x_17_4    unique_nonzero_owner_353  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_4    product_lb_51  1
    w_17_4    product_ub_52  1
    w_17_4    normalized_mass_17_78  1
    w_17_4    normalized_ratio_17_79  -4.4444444444444442e-01
    w_17_4    full_original_Gini_330  -1.1172222222222219e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_5    OBJ       -6.7500000000000060e-03
    x_17_5    product_lb_53  -2.5545373449005350e-02
    x_17_5    product_ub_54  -0.0433212996390325
    x_17_5    onehot_17_77  1
    x_17_5    stock_lb_270  5
    x_17_5    stock_ub_271  5
    x_17_5    parent_nonstrict_scope_272  5.3999999999999992e-02
    x_17_5    unique_nonzero_owner_354  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_5    product_lb_53  1
    w_17_5    product_ub_54  1
    w_17_5    normalized_mass_17_78  1
    w_17_5    normalized_ratio_17_79  -5.5555555555555558e-01
    w_17_5    full_original_Gini_330  -8.7277777777777779e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_6    OBJ       -2.0249999999999997e-02
    x_17_6    product_lb_55  -2.5545373449005350e-02
    x_17_6    product_ub_56  -0.0433212996390325
    x_17_6    onehot_17_77  1
    x_17_6    stock_lb_270  6
    x_17_6    stock_ub_271  6
    x_17_6    parent_nonstrict_scope_272  0.0405
    x_17_6    unique_nonzero_owner_355  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_6    product_lb_55  1
    w_17_6    product_ub_56  1
    w_17_6    normalized_mass_17_78  1
    w_17_6    normalized_ratio_17_79  -6.6666666666666663e-01
    w_17_6    full_original_Gini_330  -6.7499999999999982e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_7    OBJ       -3.3749999999999988e-02
    x_17_7    product_lb_57  -2.5545373449005350e-02
    x_17_7    product_ub_58  -0.0433212996390325
    x_17_7    onehot_17_77  1
    x_17_7    stock_lb_270  7
    x_17_7    stock_ub_271  7
    x_17_7    parent_nonstrict_scope_272  2.7000000000000010e-02
    x_17_7    unique_nonzero_owner_356  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_7    product_lb_57  1
    w_17_7    product_ub_58  1
    w_17_7    normalized_mass_17_78  1
    w_17_7    normalized_ratio_17_79  -7.7777777777777768e-01
    w_17_7    full_original_Gini_330  -5.3531746031746037e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_8    OBJ       -4.7249999999999993e-02
    x_17_8    product_lb_59  -2.5545373449005350e-02
    x_17_8    product_ub_60  -0.0433212996390325
    x_17_8    onehot_17_77  1
    x_17_8    stock_lb_270  8
    x_17_8    stock_ub_271  8
    x_17_8    parent_nonstrict_scope_272  1.3500000000000005e-02
    x_17_8    unique_nonzero_owner_357  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_8    product_lb_59  1
    w_17_8    product_ub_60  1
    w_17_8    normalized_mass_17_78  1
    w_17_8    normalized_ratio_17_79  -8.8888888888888884e-01
    w_17_8    full_original_Gini_330  -4.9277777777777789e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_9    OBJ       -0.06075
    x_17_9    product_lb_61  -2.5545373449005350e-02
    x_17_9    product_ub_62  -0.0433212996390325
    x_17_9    onehot_17_77  1
    x_17_9    stock_lb_270  9
    x_17_9    stock_ub_271  9
    x_17_9    unique_nonzero_owner_358  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_9    product_lb_61  1
    w_17_9    product_ub_62  1
    w_17_9    normalized_mass_17_78  1
    w_17_9    normalized_ratio_17_79  -1
    w_17_9    full_original_Gini_330  -4.8166666666666664e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_10   OBJ       -4.7249999999999993e-02
    x_17_10   product_lb_63  -2.5545373449005350e-02
    x_17_10   product_ub_64  -0.0433212996390325
    x_17_10   onehot_17_77  1
    x_17_10   stock_lb_270  10
    x_17_10   stock_ub_271  10
    x_17_10   parent_nonstrict_scope_272  1.3500000000000005e-02
    x_17_10   unique_nonzero_owner_359  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_10   product_lb_63  1
    w_17_10   product_ub_64  1
    w_17_10   normalized_mass_17_78  1
    w_17_10   normalized_ratio_17_79  -1.1111111111111112e+00
    w_17_10   full_original_Gini_330  -7.3722222222222236e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_11   OBJ       -3.3750000000000016e-02
    x_17_11   product_lb_65  -2.5545373449005350e-02
    x_17_11   product_ub_66  -0.0433212996390325
    x_17_11   onehot_17_77  1
    x_17_11   stock_lb_270  11
    x_17_11   stock_ub_271  11
    x_17_11   parent_nonstrict_scope_272  2.6999999999999986e-02
    x_17_11   unique_nonzero_owner_360  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_11   product_lb_65  1
    w_17_11   product_ub_66  1
    w_17_11   normalized_mass_17_78  1
    w_17_11   normalized_ratio_17_79  -1.2222222222222221e+00
    w_17_11   full_original_Gini_330  -9.9722222222222214e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_12   OBJ       -2.0250000000000011e-02
    x_17_12   product_lb_67  -2.5545373449005350e-02
    x_17_12   product_ub_68  -0.0433212996390325
    x_17_12   onehot_17_77  1
    x_17_12   stock_lb_270  12
    x_17_12   stock_ub_271  12
    x_17_12   parent_nonstrict_scope_272  4.0499999999999987e-02
    x_17_12   unique_nonzero_owner_361  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_12   product_lb_67  1
    w_17_12   product_ub_68  1
    w_17_12   normalized_mass_17_78  1
    w_17_12   normalized_ratio_17_79  -1.3333333333333333e+00
    w_17_12   full_original_Gini_330  -1.2916666666666666e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_13   OBJ       -6.7500000000000060e-03
    x_17_13   product_lb_69  -2.5545373449005350e-02
    x_17_13   product_ub_70  -0.0433212996390325
    x_17_13   onehot_17_77  1
    x_17_13   stock_lb_270  13
    x_17_13   stock_ub_271  13
    x_17_13   parent_nonstrict_scope_272  5.3999999999999992e-02
    x_17_13   unique_nonzero_owner_362  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_13   product_lb_69  1
    w_17_13   product_ub_70  1
    w_17_13   normalized_mass_17_78  1
    w_17_13   normalized_ratio_17_79  -1.4444444444444444e+00
    w_17_13   full_original_Gini_330  -1.5916666666666666e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_14   OBJ       6.7499999999999782e-03
    x_17_14   product_lb_71  -2.5545373449005350e-02
    x_17_14   product_ub_72  -0.0433212996390325
    x_17_14   onehot_17_77  1
    x_17_14   stock_lb_270  14
    x_17_14   stock_ub_271  14
    x_17_14   parent_nonstrict_scope_272  6.7499999999999977e-02
    x_17_14   unique_nonzero_owner_363  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_14   product_lb_71  1
    w_17_14   product_ub_72  1
    w_17_14   normalized_mass_17_78  1
    w_17_14   normalized_ratio_17_79  -1.5555555555555554e+00
    w_17_14   full_original_Gini_330  -1.8916666666666664e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_15   OBJ       2.0249999999999976e-02
    x_17_15   product_lb_73  -2.5545373449005350e-02
    x_17_15   product_ub_74  -0.0433212996390325
    x_17_15   onehot_17_77  1
    x_17_15   stock_lb_270  15
    x_17_15   stock_ub_271  15
    x_17_15   parent_nonstrict_scope_272  8.0999999999999975e-02
    x_17_15   unique_nonzero_owner_364  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_15   product_lb_73  1
    w_17_15   product_ub_74  1
    w_17_15   normalized_mass_17_78  1
    w_17_15   normalized_ratio_17_79  -1.6666666666666665e+00
    w_17_15   full_original_Gini_330  -2.1916666666666668e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_16   OBJ       3.3749999999999988e-02
    x_17_16   product_lb_75  -2.5545373449005350e-02
    x_17_16   product_ub_76  -0.0433212996390325
    x_17_16   onehot_17_77  1
    x_17_16   stock_lb_270  16
    x_17_16   stock_ub_271  16
    x_17_16   parent_nonstrict_scope_272  9.4499999999999987e-02
    x_17_16   unique_nonzero_owner_365  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_16   product_lb_75  1
    w_17_16   product_ub_76  1
    w_17_16   normalized_mass_17_78  1
    w_17_16   normalized_ratio_17_79  -1.7777777777777777e+00
    w_17_16   full_original_Gini_330  -2.4916666666666671e+01
    rho_17    normalized_ratio_17_79  1
    rho_17    block_pair_pos_293  1
    rho_17    block_pair_neg_294  -1
    rho_17    block_pair_pos_307  -1
    rho_17    block_pair_neg_308  1
    rho_17    block_pair_pos_309  -1
    rho_17    block_pair_neg_310  1
    rho_17    block_pair_pos_311  -1
    rho_17    block_pair_neg_312  1
    rho_17    block_pair_pos_313  -1
    rho_17    block_pair_neg_314  1
    rho_17    block_pair_pos_315  -1
    rho_17    block_pair_neg_316  1
    rho_17    block_pair_pos_317  -1
    rho_17    block_pair_neg_318  1
    rho_17    normalization_329  1
    MARKER    'MARKER'                 'INTORG'
    x_31_0    OBJ       0.03675
    x_31_0    product_lb_80  -2.5545373449005350e-02
    x_31_0    product_ub_81  -0.0433212996390325
    x_31_0    onehot_31_106  1
    x_31_0    parent_nonstrict_scope_272  0.0735
    x_31_0    unique_nonzero_owner_366  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_0    product_lb_80  1
    w_31_0    product_ub_81  1
    w_31_0    normalized_mass_31_107  1
    w_31_0    full_original_Gini_330  -2.3083333333333336e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_1    OBJ       2.6250000000000002e-02
    x_31_1    product_lb_82  -2.5545373449005350e-02
    x_31_1    product_ub_83  -0.0433212996390325
    x_31_1    onehot_31_106  1
    x_31_1    stock_lb_270  1
    x_31_1    stock_ub_271  1
    x_31_1    parent_nonstrict_scope_272  0.063
    x_31_1    unique_nonzero_owner_367  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_1    product_lb_82  1
    w_31_1    product_ub_83  1
    w_31_1    normalized_mass_31_107  1
    w_31_1    normalized_ratio_31_108  -1.4285714285714285e-01
    w_31_1    full_original_Gini_330  -1.9226190476190478e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_2    OBJ       0.01575
    x_31_2    product_lb_84  -2.5545373449005350e-02
    x_31_2    product_ub_85  -0.0433212996390325
    x_31_2    onehot_31_106  1
    x_31_2    stock_lb_270  2
    x_31_2    stock_ub_271  2
    x_31_2    parent_nonstrict_scope_272  0.0525
    MARKER    'MARKER'                 'INTEND'
    w_31_2    product_lb_84  1
    w_31_2    product_ub_85  1
    w_31_2    normalized_mass_31_107  1
    w_31_2    normalized_ratio_31_108  -2.8571428571428570e-01
    w_31_2    full_original_Gini_330  -1.5369047619047617e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_3    OBJ       5.2499999999999977e-03
    x_31_3    product_lb_86  -2.5545373449005350e-02
    x_31_3    product_ub_87  -0.0433212996390325
    x_31_3    onehot_31_106  1
    x_31_3    stock_lb_270  3
    x_31_3    stock_ub_271  3
    x_31_3    parent_nonstrict_scope_272  4.1999999999999996e-02
    x_31_3    unique_nonzero_owner_368  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_3    product_lb_86  1
    w_31_3    product_ub_87  1
    w_31_3    normalized_mass_31_107  1
    w_31_3    normalized_ratio_31_108  -4.2857142857142855e-01
    w_31_3    full_original_Gini_330  -1.1569047619047616e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_4    OBJ       -5.2499999999999977e-03
    x_31_4    product_lb_88  -2.5545373449005350e-02
    x_31_4    product_ub_89  -0.0433212996390325
    x_31_4    onehot_31_106  1
    x_31_4    stock_lb_270  4
    x_31_4    stock_ub_271  4
    x_31_4    parent_nonstrict_scope_272  0.0315
    x_31_4    unique_nonzero_owner_369  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_4    product_lb_88  1
    w_31_4    product_ub_89  1
    w_31_4    normalized_mass_31_107  1
    w_31_4    normalized_ratio_31_108  -5.7142857142857140e-01
    w_31_4    full_original_Gini_330  -8.42619047619048
    MARKER    'MARKER'                 'INTORG'
    x_31_5    OBJ       -1.5749999999999993e-02
    x_31_5    product_lb_90  -2.5545373449005350e-02
    x_31_5    product_ub_91  -0.0433212996390325
    x_31_5    onehot_31_106  1
    x_31_5    stock_lb_270  5
    x_31_5    stock_ub_271  5
    x_31_5    parent_nonstrict_scope_272  2.1000000000000005e-02
    x_31_5    unique_nonzero_owner_370  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_5    product_lb_90  1
    w_31_5    product_ub_91  1
    w_31_5    normalized_mass_31_107  1
    w_31_5    normalized_ratio_31_108  -7.1428571428571419e-01
    w_31_5    full_original_Gini_330  -5.94047619047619
    MARKER    'MARKER'                 'INTORG'
    x_31_6    OBJ       -2.6249999999999996e-02
    x_31_6    product_lb_92  -2.5545373449005350e-02
    x_31_6    product_ub_93  -0.0433212996390325
    x_31_6    onehot_31_106  1
    x_31_6    stock_lb_270  6
    x_31_6    stock_ub_271  6
    x_31_6    parent_nonstrict_scope_272  1.0500000000000002e-02
    x_31_6    unique_nonzero_owner_371  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_6    product_lb_92  1
    w_31_6    product_ub_93  1
    w_31_6    normalized_mass_31_107  1
    w_31_6    normalized_ratio_31_108  -8.5714285714285710e-01
    w_31_6    full_original_Gini_330  -4.95952380952381
    MARKER    'MARKER'                 'INTORG'
    x_31_7    OBJ       -0.03675
    x_31_7    product_lb_94  -2.5545373449005350e-02
    x_31_7    product_ub_95  -0.0433212996390325
    x_31_7    onehot_31_106  1
    x_31_7    stock_lb_270  7
    x_31_7    stock_ub_271  7
    x_31_7    unique_nonzero_owner_372  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_7    product_lb_94  1
    w_31_7    product_ub_95  1
    w_31_7    normalized_mass_31_107  1
    w_31_7    normalized_ratio_31_108  -1
    w_31_7    full_original_Gini_330  -4.8166666666666664e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_8    OBJ       -2.6250000000000002e-02
    x_31_8    product_lb_96  -2.5545373449005350e-02
    x_31_8    product_ub_97  -0.0433212996390325
    x_31_8    onehot_31_106  1
    x_31_8    stock_lb_270  8
    x_31_8    stock_ub_271  8
    x_31_8    parent_nonstrict_scope_272  1.0499999999999995e-02
    x_31_8    unique_nonzero_owner_373  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_8    product_lb_96  1
    w_31_8    product_ub_97  1
    w_31_8    normalized_mass_31_107  1
    w_31_8    normalized_ratio_31_108  -1.1428571428571428e+00
    w_31_8    full_original_Gini_330  -8.1023809523809511e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_9    OBJ       -1.5750000000000007e-02
    x_31_9    product_lb_98  -2.5545373449005350e-02
    x_31_9    product_ub_99  -0.0433212996390325
    x_31_9    onehot_31_106  1
    x_31_9    stock_lb_270  9
    x_31_9    stock_ub_271  9
    x_31_9    parent_nonstrict_scope_272  2.0999999999999991e-02
    x_31_9    unique_nonzero_owner_374  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_9    product_lb_98  1
    w_31_9    product_ub_99  1
    w_31_9    normalized_mass_31_107  1
    w_31_9    normalized_ratio_31_108  -1.2857142857142856e+00
    w_31_9    full_original_Gini_330  -1.1630952380952372e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_10   OBJ       -5.2500000000000116e-03
    x_31_10   product_lb_100  -2.5545373449005350e-02
    x_31_10   product_ub_101  -0.0433212996390325
    x_31_10   onehot_31_106  1
    x_31_10   stock_lb_270  10
    x_31_10   stock_ub_271  10
    x_31_10   parent_nonstrict_scope_272  3.1499999999999986e-02
    x_31_10   unique_nonzero_owner_375  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_10   product_lb_100  1
    w_31_10   product_ub_101  1
    w_31_10   normalized_mass_31_107  1
    w_31_10   normalized_ratio_31_108  -1.4285714285714284e+00
    w_31_10   full_original_Gini_330  -1.5488095238095235e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_11   OBJ       5.2499999999999977e-03
    x_31_11   product_lb_102  -2.5545373449005350e-02
    x_31_11   product_ub_103  -0.0433212996390325
    x_31_11   onehot_31_106  1
    x_31_11   stock_lb_270  11
    x_31_11   stock_ub_271  11
    x_31_11   parent_nonstrict_scope_272  4.1999999999999996e-02
    x_31_11   unique_nonzero_owner_376  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_11   product_lb_102  1
    w_31_11   product_ub_103  1
    w_31_11   normalized_mass_31_107  1
    w_31_11   normalized_ratio_31_108  -1.5714285714285714e+00
    w_31_11   full_original_Gini_330  -1.9345238095238095e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_12   OBJ       1.5749999999999993e-02
    x_31_12   product_lb_104  -2.5545373449005350e-02
    x_31_12   product_ub_105  -0.0433212996390325
    x_31_12   onehot_31_106  1
    x_31_12   stock_lb_270  12
    x_31_12   stock_ub_271  12
    x_31_12   parent_nonstrict_scope_272  5.2499999999999991e-02
    x_31_12   unique_nonzero_owner_377  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_12   product_lb_104  1
    w_31_12   product_ub_105  1
    w_31_12   normalized_mass_31_107  1
    w_31_12   normalized_ratio_31_108  -1.7142857142857142e+00
    w_31_12   full_original_Gini_330  -2.3202380952380953e+01
    rho_31    normalized_ratio_31_108  1
    rho_31    block_pair_pos_295  1
    rho_31    block_pair_neg_296  -1
    rho_31    block_pair_pos_317  1
    rho_31    block_pair_neg_318  -1
    rho_31    block_pair_pos_319  -1
    rho_31    block_pair_neg_320  1
    rho_31    block_pair_pos_321  -1
    rho_31    block_pair_neg_322  1
    rho_31    block_pair_pos_323  -1
    rho_31    block_pair_neg_324  1
    rho_31    block_pair_pos_325  -1
    rho_31    block_pair_neg_326  1
    rho_31    block_pair_pos_327  -1
    rho_31    block_pair_neg_328  1
    rho_31    normalization_329  1
    MARKER    'MARKER'                 'INTORG'
    x_6_0     OBJ       0.01875
    x_6_0     product_lb_109  -2.5545373449005350e-02
    x_6_0     product_ub_110  -0.0433212996390325
    x_6_0     onehot_6_131  1
    x_6_0     parent_nonstrict_scope_272  0.0375
    x_6_0     unique_nonzero_owner_378  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_0     product_lb_109  1
    w_6_0     product_ub_110  1
    w_6_0     normalized_mass_6_132  1
    w_6_0     full_original_Gini_330  -2.3083333333333336e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_1     OBJ       0.01125
    x_6_1     product_lb_111  -2.5545373449005350e-02
    x_6_1     product_ub_112  -0.0433212996390325
    x_6_1     onehot_6_131  1
    x_6_1     stock_lb_270  1
    x_6_1     stock_ub_271  1
    x_6_1     parent_nonstrict_scope_272  0.03
    MARKER    'MARKER'                 'INTEND'
    w_6_1     product_lb_111  1
    w_6_1     product_ub_112  1
    w_6_1     normalized_mass_6_132  1
    w_6_1     normalized_ratio_6_133  -0.2
    w_6_1     full_original_Gini_330  -1.7683333333333334e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_2     OBJ       0.00375
    x_6_2     product_lb_113  -2.5545373449005350e-02
    x_6_2     product_ub_114  -0.0433212996390325
    x_6_2     onehot_6_131  1
    x_6_2     stock_lb_270  2
    x_6_2     stock_ub_271  2
    x_6_2     parent_nonstrict_scope_272  0.0225
    x_6_2     unique_nonzero_owner_379  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_2     product_lb_113  1
    w_6_2     product_ub_114  1
    w_6_2     normalized_mass_6_132  1
    w_6_2     normalized_ratio_6_133  -0.4
    w_6_2     full_original_Gini_330  -1.2283333333333330e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_3     OBJ       -3.7500000000000033e-03
    x_6_3     product_lb_115  -2.5545373449005350e-02
    x_6_3     product_ub_116  -0.0433212996390325
    x_6_3     onehot_6_131  1
    x_6_3     stock_lb_270  3
    x_6_3     stock_ub_271  3
    x_6_3     parent_nonstrict_scope_272  1.4999999999999996e-02
    x_6_3     unique_nonzero_owner_380  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_3     product_lb_115  1
    w_6_3     product_ub_116  1
    w_6_3     normalized_mass_6_132  1
    w_6_3     normalized_ratio_6_133  -6.0000000000000009e-01
    w_6_3     full_original_Gini_330  -7.8833333333333329e+00
    MARKER    'MARKER'                 'INTORG'
    x_6_4     OBJ       -1.1250000000000001e-02
    x_6_4     product_lb_117  -2.5545373449005350e-02
    x_6_4     product_ub_118  -0.0433212996390325
    x_6_4     onehot_6_131  1
    x_6_4     stock_lb_270  4
    x_6_4     stock_ub_271  4
    x_6_4     parent_nonstrict_scope_272  7.4999999999999980e-03
    x_6_4     unique_nonzero_owner_381  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_4     product_lb_117  1
    w_6_4     product_ub_118  1
    w_6_4     normalized_mass_6_132  1
    w_6_4     normalized_ratio_6_133  -0.8
    w_6_4     full_original_Gini_330  -5.19761904761905
    MARKER    'MARKER'                 'INTORG'
    x_6_5     OBJ       -0.01875
    x_6_5     product_lb_119  -2.5545373449005350e-02
    x_6_5     product_ub_120  -0.0433212996390325
    x_6_5     onehot_6_131  1
    x_6_5     stock_lb_270  5
    x_6_5     stock_ub_271  5
    x_6_5     unique_nonzero_owner_382  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_5     product_lb_119  1
    w_6_5     product_ub_120  1
    w_6_5     normalized_mass_6_132  1
    w_6_5     normalized_ratio_6_133  -1
    w_6_5     full_original_Gini_330  -4.8166666666666664e+00
    MARKER    'MARKER'                 'INTORG'
    x_6_6     OBJ       -1.1249999999999993e-02
    x_6_6     product_lb_121  -2.5545373449005350e-02
    x_6_6     product_ub_122  -0.0433212996390325
    x_6_6     onehot_6_131  1
    x_6_6     stock_lb_270  6
    x_6_6     stock_ub_271  6
    x_6_6     parent_nonstrict_scope_272  7.5000000000000067e-03
    x_6_6     unique_nonzero_owner_383  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_6     product_lb_121  1
    w_6_6     product_ub_122  1
    w_6_6     normalized_mass_6_132  1
    w_6_6     normalized_ratio_6_133  -1.2000000000000002e+00
    w_6_6     full_original_Gini_330  -9.4166666666666714e+00
    MARKER    'MARKER'                 'INTORG'
    x_6_7     OBJ       -3.7499999999999947e-03
    x_6_7     product_lb_123  -2.5545373449005350e-02
    x_6_7     product_ub_124  -0.0433212996390325
    x_6_7     onehot_6_131  1
    x_6_7     stock_lb_270  7
    x_6_7     stock_ub_271  7
    x_6_7     parent_nonstrict_scope_272  1.5000000000000005e-02
    x_6_7     unique_nonzero_owner_384  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_7     product_lb_123  1
    w_6_7     product_ub_124  1
    w_6_7     normalized_mass_6_132  1
    w_6_7     normalized_ratio_6_133  -1.4000000000000001e+00
    w_6_7     full_original_Gini_330  -1.4716666666666670e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_8     OBJ       3.7500000000000033e-03
    x_6_8     product_lb_125  -2.5545373449005350e-02
    x_6_8     product_ub_126  -0.0433212996390325
    x_6_8     onehot_6_131  1
    x_6_8     stock_lb_270  8
    x_6_8     stock_ub_271  8
    x_6_8     parent_nonstrict_scope_272  2.2500000000000003e-02
    x_6_8     unique_nonzero_owner_385  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_8     product_lb_125  1
    w_6_8     product_ub_126  1
    w_6_8     normalized_mass_6_132  1
    w_6_8     normalized_ratio_6_133  -1.6
    w_6_8     full_original_Gini_330  -2.0116666666666671e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_9     OBJ       0.01125
    x_6_9     product_lb_127  -2.5545373449005350e-02
    x_6_9     product_ub_128  -0.0433212996390325
    x_6_9     onehot_6_131  1
    x_6_9     stock_lb_270  9
    x_6_9     stock_ub_271  9
    x_6_9     parent_nonstrict_scope_272  0.03
    x_6_9     unique_nonzero_owner_386  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_9     product_lb_127  1
    w_6_9     product_ub_128  1
    w_6_9     normalized_mass_6_132  1
    w_6_9     normalized_ratio_6_133  -1.8
    w_6_9     full_original_Gini_330  -2.5516666666666673e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_10    OBJ       0.01875
    x_6_10    product_lb_129  -2.5545373449005350e-02
    x_6_10    product_ub_130  -0.0433212996390325
    x_6_10    onehot_6_131  1
    x_6_10    stock_lb_270  10
    x_6_10    stock_ub_271  10
    x_6_10    parent_nonstrict_scope_272  0.0375
    x_6_10    unique_nonzero_owner_387  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_10    product_lb_129  1
    w_6_10    product_ub_130  1
    w_6_10    normalized_mass_6_132  1
    w_6_10    normalized_ratio_6_133  -2
    w_6_10    full_original_Gini_330  -3.0916666666666664e+01
    rho_6     normalized_ratio_6_133  1
    rho_6     block_pair_pos_275  -1
    rho_6     block_pair_neg_276  1
    rho_6     block_pair_pos_277  -1
    rho_6     block_pair_neg_278  1
    rho_6     block_pair_pos_279  -1
    rho_6     block_pair_neg_280  1
    rho_6     block_pair_pos_281  -1
    rho_6     block_pair_neg_282  1
    rho_6     block_pair_pos_285  1
    rho_6     block_pair_neg_286  -1
    rho_6     block_pair_pos_309  1
    rho_6     block_pair_neg_310  -1
    rho_6     block_pair_pos_321  1
    rho_6     block_pair_neg_322  -1
    rho_6     normalization_329  1
    MARKER    'MARKER'                 'INTORG'
    x_14_0    OBJ       0.048
    x_14_0    product_lb_134  -2.5545373449005350e-02
    x_14_0    product_ub_135  -0.0433212996390325
    x_14_0    onehot_14_166  1
    x_14_0    parent_nonstrict_scope_272  0.096
    x_14_0    unique_nonzero_owner_388  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_0    product_lb_134  1
    w_14_0    product_ub_135  1
    w_14_0    normalized_mass_14_167  1
    w_14_0    full_original_Gini_330  -2.3083333333333336e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_1    OBJ       3.6000000000000004e-02
    x_14_1    product_lb_136  -2.5545373449005350e-02
    x_14_1    product_ub_137  -0.0433212996390325
    x_14_1    onehot_14_166  1
    x_14_1    stock_lb_270  1
    x_14_1    stock_ub_271  1
    x_14_1    parent_nonstrict_scope_272  0.084
    x_14_1    unique_nonzero_owner_389  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_1    product_lb_136  1
    w_14_1    product_ub_137  1
    w_14_1    normalized_mass_14_167  1
    w_14_1    normalized_ratio_14_168  -0.125
    w_14_1    full_original_Gini_330  -1.9708333333333336e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_2    OBJ       2.4000000000000007e-02
    x_14_2    product_lb_138  -2.5545373449005350e-02
    x_14_2    product_ub_139  -0.0433212996390325
    x_14_2    onehot_14_166  1
    x_14_2    stock_lb_270  2
    x_14_2    stock_ub_271  2
    x_14_2    parent_nonstrict_scope_272  7.2000000000000008e-02
    MARKER    'MARKER'                 'INTEND'
    w_14_2    product_lb_138  1
    w_14_2    product_ub_139  1
    w_14_2    normalized_mass_14_167  1
    w_14_2    normalized_ratio_14_168  -0.25
    w_14_2    full_original_Gini_330  -1.6333333333333332e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_3    OBJ       1.1999999999999997e-02
    x_14_3    product_lb_140  -2.5545373449005350e-02
    x_14_3    product_ub_141  -0.0433212996390325
    x_14_3    onehot_14_166  1
    x_14_3    stock_lb_270  3
    x_14_3    stock_ub_271  3
    x_14_3    parent_nonstrict_scope_272  0.06
    x_14_3    unique_nonzero_owner_390  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_3    product_lb_140  1
    w_14_3    product_ub_141  1
    w_14_3    normalized_mass_14_167  1
    w_14_3    normalized_ratio_14_168  -0.375
    w_14_3    full_original_Gini_330  -1.2958333333333332e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_4    product_lb_142  -2.5545373449005350e-02
    x_14_4    product_ub_143  -0.0433212996390325
    x_14_4    onehot_14_166  1
    x_14_4    stock_lb_270  4
    x_14_4    stock_ub_271  4
    x_14_4    parent_nonstrict_scope_272  0.048
    x_14_4    unique_nonzero_owner_391  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_4    product_lb_142  1
    w_14_4    product_ub_143  1
    w_14_4    normalized_mass_14_167  1
    w_14_4    normalized_ratio_14_168  -0.5
    w_14_4    full_original_Gini_330  -9.7833333333333332e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_5    OBJ       -1.1999999999999997e-02
    x_14_5    product_lb_144  -2.5545373449005350e-02
    x_14_5    product_ub_145  -0.0433212996390325
    x_14_5    onehot_14_166  1
    x_14_5    stock_lb_270  5
    x_14_5    stock_ub_271  5
    x_14_5    parent_nonstrict_scope_272  3.6000000000000004e-02
    x_14_5    unique_nonzero_owner_392  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_5    product_lb_144  1
    w_14_5    product_ub_145  1
    w_14_5    normalized_mass_14_167  1
    w_14_5    normalized_ratio_14_168  -0.625
    w_14_5    full_original_Gini_330  -7.4583333333333339e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_6    OBJ       -0.024
    x_14_6    product_lb_146  -2.5545373449005350e-02
    x_14_6    product_ub_147  -0.0433212996390325
    x_14_6    onehot_14_166  1
    x_14_6    stock_lb_270  6
    x_14_6    stock_ub_271  6
    x_14_6    parent_nonstrict_scope_272  0.024
    x_14_6    unique_nonzero_owner_393  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_6    product_lb_146  1
    w_14_6    product_ub_147  1
    w_14_6    normalized_mass_14_167  1
    w_14_6    normalized_ratio_14_168  -0.75
    w_14_6    full_original_Gini_330  -5.5476190476190474e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_7    OBJ       -3.6000000000000004e-02
    x_14_7    product_lb_148  -2.5545373449005350e-02
    x_14_7    product_ub_149  -0.0433212996390325
    x_14_7    onehot_14_166  1
    x_14_7    stock_lb_270  7
    x_14_7    stock_ub_271  7
    x_14_7    parent_nonstrict_scope_272  0.012
    x_14_7    unique_nonzero_owner_394  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_7    product_lb_148  1
    w_14_7    product_ub_149  1
    w_14_7    normalized_mass_14_167  1
    w_14_7    normalized_ratio_14_168  -0.875
    w_14_7    full_original_Gini_330  -4.9416666666666664e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_8    OBJ       -0.048
    x_14_8    product_lb_150  -2.5545373449005350e-02
    x_14_8    product_ub_151  -0.0433212996390325
    x_14_8    onehot_14_166  1
    x_14_8    stock_lb_270  8
    x_14_8    stock_ub_271  8
    x_14_8    unique_nonzero_owner_395  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_8    product_lb_150  1
    w_14_8    product_ub_151  1
    w_14_8    normalized_mass_14_167  1
    w_14_8    normalized_ratio_14_168  -1
    w_14_8    full_original_Gini_330  -4.8166666666666664e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_9    OBJ       -3.6000000000000004e-02
    x_14_9    product_lb_152  -2.5545373449005350e-02
    x_14_9    product_ub_153  -0.0433212996390325
    x_14_9    onehot_14_166  1
    x_14_9    stock_lb_270  9
    x_14_9    stock_ub_271  9
    x_14_9    parent_nonstrict_scope_272  0.012
    x_14_9    unique_nonzero_owner_396  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_9    product_lb_152  1
    w_14_9    product_ub_153  1
    w_14_9    normalized_mass_14_167  1
    w_14_9    normalized_ratio_14_168  -1.125
    w_14_9    full_original_Gini_330  -7.6916666666666664e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_10   OBJ       -0.024
    x_14_10   product_lb_154  -2.5545373449005350e-02
    x_14_10   product_ub_155  -0.0433212996390325
    x_14_10   onehot_14_166  1
    x_14_10   stock_lb_270  10
    x_14_10   stock_ub_271  10
    x_14_10   parent_nonstrict_scope_272  0.024
    x_14_10   unique_nonzero_owner_397  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_10   product_lb_154  1
    w_14_10   product_ub_155  1
    w_14_10   normalized_mass_14_167  1
    w_14_10   normalized_ratio_14_168  -1.25
    w_14_10   full_original_Gini_330  -1.0666666666666666e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_11   OBJ       -1.1999999999999997e-02
    x_14_11   product_lb_156  -2.5545373449005350e-02
    x_14_11   product_ub_157  -0.0433212996390325
    x_14_11   onehot_14_166  1
    x_14_11   stock_lb_270  11
    x_14_11   stock_ub_271  11
    x_14_11   parent_nonstrict_scope_272  3.6000000000000004e-02
    x_14_11   unique_nonzero_owner_398  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_11   product_lb_156  1
    w_14_11   product_ub_157  1
    w_14_11   normalized_mass_14_167  1
    w_14_11   normalized_ratio_14_168  -1.375
    w_14_11   full_original_Gini_330  -1.4041666666666668e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_12   product_lb_158  -2.5545373449005350e-02
    x_14_12   product_ub_159  -0.0433212996390325
    x_14_12   onehot_14_166  1
    x_14_12   stock_lb_270  12
    x_14_12   stock_ub_271  12
    x_14_12   parent_nonstrict_scope_272  0.048
    x_14_12   unique_nonzero_owner_399  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_12   product_lb_158  1
    w_14_12   product_ub_159  1
    w_14_12   normalized_mass_14_167  1
    w_14_12   normalized_ratio_14_168  -1.5
    w_14_12   full_original_Gini_330  -1.7416666666666664e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_13   OBJ       1.1999999999999997e-02
    x_14_13   product_lb_160  -2.5545373449005350e-02
    x_14_13   product_ub_161  -0.0433212996390325
    x_14_13   onehot_14_166  1
    x_14_13   stock_lb_270  13
    x_14_13   stock_ub_271  13
    x_14_13   parent_nonstrict_scope_272  0.06
    x_14_13   unique_nonzero_owner_400  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_13   product_lb_160  1
    w_14_13   product_ub_161  1
    w_14_13   normalized_mass_14_167  1
    w_14_13   normalized_ratio_14_168  -1.625
    w_14_13   full_original_Gini_330  -2.0791666666666664e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_14   OBJ       2.4000000000000007e-02
    x_14_14   product_lb_162  -2.5545373449005350e-02
    x_14_14   product_ub_163  -0.0433212996390325
    x_14_14   onehot_14_166  1
    x_14_14   stock_lb_270  14
    x_14_14   stock_ub_271  14
    x_14_14   parent_nonstrict_scope_272  7.2000000000000008e-02
    x_14_14   unique_nonzero_owner_401  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_14   product_lb_162  1
    w_14_14   product_ub_163  1
    w_14_14   normalized_mass_14_167  1
    w_14_14   normalized_ratio_14_168  -1.75
    w_14_14   full_original_Gini_330  -2.4166666666666664e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_15   OBJ       3.6000000000000004e-02
    x_14_15   product_lb_164  -2.5545373449005350e-02
    x_14_15   product_ub_165  -0.0433212996390325
    x_14_15   onehot_14_166  1
    x_14_15   stock_lb_270  15
    x_14_15   stock_ub_271  15
    x_14_15   parent_nonstrict_scope_272  0.084
    x_14_15   unique_nonzero_owner_402  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_15   product_lb_164  1
    w_14_15   product_ub_165  1
    w_14_15   normalized_mass_14_167  1
    w_14_15   normalized_ratio_14_168  -1.875
    w_14_15   full_original_Gini_330  -2.7541666666666664e+01
    rho_14    normalized_ratio_14_168  1
    rho_14    block_pair_pos_279  1
    rho_14    block_pair_neg_280  -1
    rho_14    block_pair_pos_289  1
    rho_14    block_pair_neg_290  -1
    rho_14    block_pair_pos_297  -1
    rho_14    block_pair_neg_298  1
    rho_14    block_pair_pos_299  -1
    rho_14    block_pair_neg_300  1
    rho_14    block_pair_pos_301  -1
    rho_14    block_pair_neg_302  1
    rho_14    block_pair_pos_313  1
    rho_14    block_pair_neg_314  -1
    rho_14    block_pair_pos_325  1
    rho_14    block_pair_neg_326  -1
    rho_14    normalization_329  1
    MARKER    'MARKER'                 'INTORG'
    x_15_0    OBJ       0.06075
    x_15_0    product_lb_169  -2.5545373449005350e-02
    x_15_0    product_ub_170  -0.0433212996390325
    x_15_0    onehot_15_203  1
    x_15_0    parent_nonstrict_scope_272  0.1215
    x_15_0    unique_nonzero_owner_403  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_0    product_lb_169  1
    w_15_0    product_ub_170  1
    w_15_0    normalized_mass_15_204  1
    w_15_0    full_original_Gini_330  -2.3083333333333336e+01
    MARKER    'MARKER'                 'INTORG'
    x_15_1    OBJ       4.7249999999999986e-02
    x_15_1    product_lb_171  -2.5545373449005350e-02
    x_15_1    product_ub_172  -0.0433212996390325
    x_15_1    onehot_15_203  1
    x_15_1    stock_lb_270  1
    x_15_1    stock_ub_271  1
    x_15_1    parent_nonstrict_scope_272  1.0799999999999998e-01
    x_15_1    unique_nonzero_owner_404  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_1    product_lb_171  1
    w_15_1    product_ub_172  1
    w_15_1    normalized_mass_15_204  1
    w_15_1    normalized_ratio_15_205  -1.1111111111111110e-01
    w_15_1    full_original_Gini_330  -2.0083333333333336e+01
    MARKER    'MARKER'                 'INTORG'
    x_15_2    OBJ       0.03375
    x_15_2    product_lb_173  -2.5545373449005350e-02
    x_15_2    product_ub_174  -0.0433212996390325
    x_15_2    onehot_15_203  1
    x_15_2    stock_lb_270  2
    x_15_2    stock_ub_271  2
    x_15_2    parent_nonstrict_scope_272  0.0945
    x_15_2    unique_nonzero_owner_405  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_2    product_lb_173  1
    w_15_2    product_ub_174  1
    w_15_2    normalized_mass_15_204  1
    w_15_2    normalized_ratio_15_205  -2.2222222222222221e-01
    w_15_2    full_original_Gini_330  -1.7083333333333339e+01
    MARKER    'MARKER'                 'INTORG'
    x_15_3    OBJ       2.0250000000000004e-02
    x_15_3    product_lb_175  -2.5545373449005350e-02
    x_15_3    product_ub_176  -0.0433212996390325
    x_15_3    onehot_15_203  1
    x_15_3    stock_lb_270  3
    x_15_3    stock_ub_271  3
    x_15_3    parent_nonstrict_scope_272  0.081
    MARKER    'MARKER'                 'INTEND'
    w_15_3    product_lb_175  1
    w_15_3    product_ub_176  1
    w_15_3    normalized_mass_15_204  1
    w_15_3    normalized_ratio_15_205  -3.3333333333333331e-01
    w_15_3    full_original_Gini_330  -1.4083333333333332e+01
    MARKER    'MARKER'                 'INTORG'
    x_15_4    OBJ       6.7500000000000060e-03
    x_15_4    product_lb_177  -2.5545373449005350e-02
    x_15_4    product_ub_178  -0.0433212996390325
    x_15_4    onehot_15_203  1
    x_15_4    stock_lb_270  4
    x_15_4    stock_ub_271  4
    x_15_4    parent_nonstrict_scope_272  0.0675
    x_15_4    unique_nonzero_owner_406  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_4    product_lb_177  1
    w_15_4    product_ub_178  1
    w_15_4    normalized_mass_15_204  1
    w_15_4    normalized_ratio_15_205  -4.4444444444444442e-01
    w_15_4    full_original_Gini_330  -1.1172222222222219e+01
    MARKER    'MARKER'                 'INTORG'
    x_15_5    OBJ       -6.7500000000000060e-03
    x_15_5    product_lb_179  -2.5545373449005350e-02
    x_15_5    product_ub_180  -0.0433212996390325
    x_15_5    onehot_15_203  1
    x_15_5    stock_lb_270  5
    x_15_5    stock_ub_271  5
    x_15_5    parent_nonstrict_scope_272  5.3999999999999992e-02
    x_15_5    unique_nonzero_owner_407  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_5    product_lb_179  1
    w_15_5    product_ub_180  1
    w_15_5    normalized_mass_15_204  1
    w_15_5    normalized_ratio_15_205  -5.5555555555555558e-01
    w_15_5    full_original_Gini_330  -8.7277777777777779e+00
    MARKER    'MARKER'                 'INTORG'
    x_15_6    OBJ       -2.0249999999999997e-02
    x_15_6    product_lb_181  -2.5545373449005350e-02
    x_15_6    product_ub_182  -0.0433212996390325
    x_15_6    onehot_15_203  1
    x_15_6    stock_lb_270  6
    x_15_6    stock_ub_271  6
    x_15_6    parent_nonstrict_scope_272  0.0405
    x_15_6    unique_nonzero_owner_408  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_6    product_lb_181  1
    w_15_6    product_ub_182  1
    w_15_6    normalized_mass_15_204  1
    w_15_6    normalized_ratio_15_205  -6.6666666666666663e-01
    w_15_6    full_original_Gini_330  -6.7499999999999982e+00
    MARKER    'MARKER'                 'INTORG'
    x_15_7    OBJ       -3.3749999999999988e-02
    x_15_7    product_lb_183  -2.5545373449005350e-02
    x_15_7    product_ub_184  -0.0433212996390325
    x_15_7    onehot_15_203  1
    x_15_7    stock_lb_270  7
    x_15_7    stock_ub_271  7
    x_15_7    parent_nonstrict_scope_272  2.7000000000000010e-02
    x_15_7    unique_nonzero_owner_409  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_7    product_lb_183  1
    w_15_7    product_ub_184  1
    w_15_7    normalized_mass_15_204  1
    w_15_7    normalized_ratio_15_205  -7.7777777777777768e-01
    w_15_7    full_original_Gini_330  -5.3531746031746037e+00
    MARKER    'MARKER'                 'INTORG'
    x_15_8    OBJ       -4.7249999999999993e-02
    x_15_8    product_lb_185  -2.5545373449005350e-02
    x_15_8    product_ub_186  -0.0433212996390325
    x_15_8    onehot_15_203  1
    x_15_8    stock_lb_270  8
    x_15_8    stock_ub_271  8
    x_15_8    parent_nonstrict_scope_272  1.3500000000000005e-02
    x_15_8    unique_nonzero_owner_410  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_8    product_lb_185  1
    w_15_8    product_ub_186  1
    w_15_8    normalized_mass_15_204  1
    w_15_8    normalized_ratio_15_205  -8.8888888888888884e-01
    w_15_8    full_original_Gini_330  -4.9277777777777789e+00
    MARKER    'MARKER'                 'INTORG'
    x_15_9    OBJ       -0.06075
    x_15_9    product_lb_187  -2.5545373449005350e-02
    x_15_9    product_ub_188  -0.0433212996390325
    x_15_9    onehot_15_203  1
    x_15_9    stock_lb_270  9
    x_15_9    stock_ub_271  9
    x_15_9    unique_nonzero_owner_411  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_9    product_lb_187  1
    w_15_9    product_ub_188  1
    w_15_9    normalized_mass_15_204  1
    w_15_9    normalized_ratio_15_205  -1
    w_15_9    full_original_Gini_330  -4.8166666666666664e+00
    MARKER    'MARKER'                 'INTORG'
    x_15_10   OBJ       -4.7249999999999993e-02
    x_15_10   product_lb_189  -2.5545373449005350e-02
    x_15_10   product_ub_190  -0.0433212996390325
    x_15_10   onehot_15_203  1
    x_15_10   stock_lb_270  10
    x_15_10   stock_ub_271  10
    x_15_10   parent_nonstrict_scope_272  1.3500000000000005e-02
    x_15_10   unique_nonzero_owner_412  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_10   product_lb_189  1
    w_15_10   product_ub_190  1
    w_15_10   normalized_mass_15_204  1
    w_15_10   normalized_ratio_15_205  -1.1111111111111112e+00
    w_15_10   full_original_Gini_330  -7.3722222222222236e+00
    MARKER    'MARKER'                 'INTORG'
    x_15_11   OBJ       -3.3750000000000016e-02
    x_15_11   product_lb_191  -2.5545373449005350e-02
    x_15_11   product_ub_192  -0.0433212996390325
    x_15_11   onehot_15_203  1
    x_15_11   stock_lb_270  11
    x_15_11   stock_ub_271  11
    x_15_11   parent_nonstrict_scope_272  2.6999999999999986e-02
    x_15_11   unique_nonzero_owner_413  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_11   product_lb_191  1
    w_15_11   product_ub_192  1
    w_15_11   normalized_mass_15_204  1
    w_15_11   normalized_ratio_15_205  -1.2222222222222221e+00
    w_15_11   full_original_Gini_330  -9.9722222222222214e+00
    MARKER    'MARKER'                 'INTORG'
    x_15_12   OBJ       -2.0250000000000011e-02
    x_15_12   product_lb_193  -2.5545373449005350e-02
    x_15_12   product_ub_194  -0.0433212996390325
    x_15_12   onehot_15_203  1
    x_15_12   stock_lb_270  12
    x_15_12   stock_ub_271  12
    x_15_12   parent_nonstrict_scope_272  4.0499999999999987e-02
    x_15_12   unique_nonzero_owner_414  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_12   product_lb_193  1
    w_15_12   product_ub_194  1
    w_15_12   normalized_mass_15_204  1
    w_15_12   normalized_ratio_15_205  -1.3333333333333333e+00
    w_15_12   full_original_Gini_330  -1.2916666666666666e+01
    MARKER    'MARKER'                 'INTORG'
    x_15_13   OBJ       -6.7500000000000060e-03
    x_15_13   product_lb_195  -2.5545373449005350e-02
    x_15_13   product_ub_196  -0.0433212996390325
    x_15_13   onehot_15_203  1
    x_15_13   stock_lb_270  13
    x_15_13   stock_ub_271  13
    x_15_13   parent_nonstrict_scope_272  5.3999999999999992e-02
    x_15_13   unique_nonzero_owner_415  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_13   product_lb_195  1
    w_15_13   product_ub_196  1
    w_15_13   normalized_mass_15_204  1
    w_15_13   normalized_ratio_15_205  -1.4444444444444444e+00
    w_15_13   full_original_Gini_330  -1.5916666666666666e+01
    MARKER    'MARKER'                 'INTORG'
    x_15_14   OBJ       6.7499999999999782e-03
    x_15_14   product_lb_197  -2.5545373449005350e-02
    x_15_14   product_ub_198  -0.0433212996390325
    x_15_14   onehot_15_203  1
    x_15_14   stock_lb_270  14
    x_15_14   stock_ub_271  14
    x_15_14   parent_nonstrict_scope_272  6.7499999999999977e-02
    x_15_14   unique_nonzero_owner_416  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_14   product_lb_197  1
    w_15_14   product_ub_198  1
    w_15_14   normalized_mass_15_204  1
    w_15_14   normalized_ratio_15_205  -1.5555555555555554e+00
    w_15_14   full_original_Gini_330  -1.8916666666666664e+01
    MARKER    'MARKER'                 'INTORG'
    x_15_15   OBJ       2.0249999999999976e-02
    x_15_15   product_lb_199  -2.5545373449005350e-02
    x_15_15   product_ub_200  -0.0433212996390325
    x_15_15   onehot_15_203  1
    x_15_15   stock_lb_270  15
    x_15_15   stock_ub_271  15
    x_15_15   parent_nonstrict_scope_272  8.0999999999999975e-02
    x_15_15   unique_nonzero_owner_417  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_15   product_lb_199  1
    w_15_15   product_ub_200  1
    w_15_15   normalized_mass_15_204  1
    w_15_15   normalized_ratio_15_205  -1.6666666666666665e+00
    w_15_15   full_original_Gini_330  -2.1916666666666668e+01
    MARKER    'MARKER'                 'INTORG'
    x_15_16   OBJ       3.3749999999999988e-02
    x_15_16   product_lb_201  -2.5545373449005350e-02
    x_15_16   product_ub_202  -0.0433212996390325
    x_15_16   onehot_15_203  1
    x_15_16   stock_lb_270  16
    x_15_16   stock_ub_271  16
    x_15_16   parent_nonstrict_scope_272  9.4499999999999987e-02
    x_15_16   unique_nonzero_owner_418  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_16   product_lb_201  1
    w_15_16   product_ub_202  1
    w_15_16   normalized_mass_15_204  1
    w_15_16   normalized_ratio_15_205  -1.7777777777777777e+00
    w_15_16   full_original_Gini_330  -2.4916666666666671e+01
    rho_15    normalized_ratio_15_205  1
    rho_15    block_pair_pos_281  1
    rho_15    block_pair_neg_282  -1
    rho_15    block_pair_pos_291  1
    rho_15    block_pair_neg_292  -1
    rho_15    block_pair_pos_301  1
    rho_15    block_pair_neg_302  -1
    rho_15    block_pair_pos_303  -1
    rho_15    block_pair_neg_304  1
    rho_15    block_pair_pos_305  -1
    rho_15    block_pair_neg_306  1
    rho_15    block_pair_pos_315  1
    rho_15    block_pair_neg_316  -1
    rho_15    block_pair_pos_327  1
    rho_15    block_pair_neg_328  -1
    rho_15    normalization_329  1
    MARKER    'MARKER'                 'INTORG'
    x_2_0     OBJ       0.0315
    x_2_0     product_lb_206  -2.5545373449005350e-02
    x_2_0     product_ub_207  -0.0433212996390325
    x_2_0     onehot_2_238  1
    x_2_0     parent_nonstrict_scope_272  0.0735
    MARKER    'MARKER'                 'INTEND'
    w_2_0     product_lb_206  1
    w_2_0     product_ub_207  1
    w_2_0     normalized_mass_2_239  1
    w_2_0     full_original_Gini_330  -2.3083333333333336e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_1     OBJ       2.1000000000000005e-02
    x_2_1     product_lb_208  -2.5545373449005350e-02
    x_2_1     product_ub_209  -0.0433212996390325
    x_2_1     onehot_2_238  1
    x_2_1     stock_lb_270  1
    x_2_1     stock_ub_271  1
    x_2_1     parent_nonstrict_scope_272  0.063
    x_2_1     unique_nonzero_owner_419  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_1     product_lb_208  1
    w_2_1     product_ub_209  1
    w_2_1     normalized_mass_2_239  1
    w_2_1     normalized_ratio_2_240  -1.4285714285714285e-01
    w_2_1     full_original_Gini_330  -1.9226190476190478e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_2     OBJ       1.0500000000000002e-02
    x_2_2     product_lb_210  -2.5545373449005350e-02
    x_2_2     product_ub_211  -0.0433212996390325
    x_2_2     onehot_2_238  1
    x_2_2     stock_lb_270  2
    x_2_2     stock_ub_271  2
    x_2_2     parent_nonstrict_scope_272  0.0525
    x_2_2     unique_nonzero_owner_420  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_2     product_lb_210  1
    w_2_2     product_ub_211  1
    w_2_2     normalized_mass_2_239  1
    w_2_2     normalized_ratio_2_240  -2.8571428571428570e-01
    w_2_2     full_original_Gini_330  -1.5369047619047617e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_3     product_lb_212  -2.5545373449005350e-02
    x_2_3     product_ub_213  -0.0433212996390325
    x_2_3     onehot_2_238  1
    x_2_3     stock_lb_270  3
    x_2_3     stock_ub_271  3
    x_2_3     parent_nonstrict_scope_272  4.1999999999999996e-02
    x_2_3     unique_nonzero_owner_421  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_3     product_lb_212  1
    w_2_3     product_ub_213  1
    w_2_3     normalized_mass_2_239  1
    w_2_3     normalized_ratio_2_240  -4.2857142857142855e-01
    w_2_3     full_original_Gini_330  -1.1569047619047616e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_4     OBJ       -1.0499999999999995e-02
    x_2_4     product_lb_214  -2.5545373449005350e-02
    x_2_4     product_ub_215  -0.0433212996390325
    x_2_4     onehot_2_238  1
    x_2_4     stock_lb_270  4
    x_2_4     stock_ub_271  4
    x_2_4     parent_nonstrict_scope_272  0.0315
    x_2_4     unique_nonzero_owner_422  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_4     product_lb_214  1
    w_2_4     product_ub_215  1
    w_2_4     normalized_mass_2_239  1
    w_2_4     normalized_ratio_2_240  -5.7142857142857140e-01
    w_2_4     full_original_Gini_330  -8.42619047619048
    MARKER    'MARKER'                 'INTORG'
    x_2_5     OBJ       -2.0999999999999991e-02
    x_2_5     product_lb_216  -2.5545373449005350e-02
    x_2_5     product_ub_217  -0.0433212996390325
    x_2_5     onehot_2_238  1
    x_2_5     stock_lb_270  5
    x_2_5     stock_ub_271  5
    x_2_5     parent_nonstrict_scope_272  2.1000000000000005e-02
    x_2_5     unique_nonzero_owner_423  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_5     product_lb_216  1
    w_2_5     product_ub_217  1
    w_2_5     normalized_mass_2_239  1
    w_2_5     normalized_ratio_2_240  -7.1428571428571419e-01
    w_2_5     full_original_Gini_330  -5.94047619047619
    MARKER    'MARKER'                 'INTORG'
    x_2_6     OBJ       -3.1499999999999993e-02
    x_2_6     product_lb_218  -2.5545373449005350e-02
    x_2_6     product_ub_219  -0.0433212996390325
    x_2_6     onehot_2_238  1
    x_2_6     stock_lb_270  6
    x_2_6     stock_ub_271  6
    x_2_6     parent_nonstrict_scope_272  1.0500000000000002e-02
    x_2_6     unique_nonzero_owner_424  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_6     product_lb_218  1
    w_2_6     product_ub_219  1
    w_2_6     normalized_mass_2_239  1
    w_2_6     normalized_ratio_2_240  -8.5714285714285710e-01
    w_2_6     full_original_Gini_330  -4.95952380952381
    MARKER    'MARKER'                 'INTORG'
    x_2_7     OBJ       -4.1999999999999996e-02
    x_2_7     product_lb_220  -2.5545373449005350e-02
    x_2_7     product_ub_221  -0.0433212996390325
    x_2_7     onehot_2_238  1
    x_2_7     stock_lb_270  7
    x_2_7     stock_ub_271  7
    x_2_7     unique_nonzero_owner_425  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_7     product_lb_220  1
    w_2_7     product_ub_221  1
    w_2_7     normalized_mass_2_239  1
    w_2_7     normalized_ratio_2_240  -1
    w_2_7     full_original_Gini_330  -4.8166666666666664e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_8     OBJ       -0.0315
    x_2_8     product_lb_222  -2.5545373449005350e-02
    x_2_8     product_ub_223  -0.0433212996390325
    x_2_8     onehot_2_238  1
    x_2_8     stock_lb_270  8
    x_2_8     stock_ub_271  8
    x_2_8     parent_nonstrict_scope_272  1.0499999999999995e-02
    x_2_8     unique_nonzero_owner_426  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_8     product_lb_222  1
    w_2_8     product_ub_223  1
    w_2_8     normalized_mass_2_239  1
    w_2_8     normalized_ratio_2_240  -1.1428571428571428e+00
    w_2_8     full_original_Gini_330  -8.1023809523809511e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_9     OBJ       -2.1000000000000005e-02
    x_2_9     product_lb_224  -2.5545373449005350e-02
    x_2_9     product_ub_225  -0.0433212996390325
    x_2_9     onehot_2_238  1
    x_2_9     stock_lb_270  9
    x_2_9     stock_ub_271  9
    x_2_9     parent_nonstrict_scope_272  2.0999999999999991e-02
    x_2_9     unique_nonzero_owner_427  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_9     product_lb_224  1
    w_2_9     product_ub_225  1
    w_2_9     normalized_mass_2_239  1
    w_2_9     normalized_ratio_2_240  -1.2857142857142856e+00
    w_2_9     full_original_Gini_330  -1.1630952380952372e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_10    OBJ       -1.0500000000000009e-02
    x_2_10    product_lb_226  -2.5545373449005350e-02
    x_2_10    product_ub_227  -0.0433212996390325
    x_2_10    onehot_2_238  1
    x_2_10    stock_lb_270  10
    x_2_10    stock_ub_271  10
    x_2_10    parent_nonstrict_scope_272  3.1499999999999986e-02
    x_2_10    unique_nonzero_owner_428  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_10    product_lb_226  1
    w_2_10    product_ub_227  1
    w_2_10    normalized_mass_2_239  1
    w_2_10    normalized_ratio_2_240  -1.4285714285714284e+00
    w_2_10    full_original_Gini_330  -1.5488095238095235e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_11    product_lb_228  -2.5545373449005350e-02
    x_2_11    product_ub_229  -0.0433212996390325
    x_2_11    onehot_2_238  1
    x_2_11    stock_lb_270  11
    x_2_11    stock_ub_271  11
    x_2_11    parent_nonstrict_scope_272  4.1999999999999996e-02
    x_2_11    unique_nonzero_owner_429  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_11    product_lb_228  1
    w_2_11    product_ub_229  1
    w_2_11    normalized_mass_2_239  1
    w_2_11    normalized_ratio_2_240  -1.5714285714285714e+00
    w_2_11    full_original_Gini_330  -1.9345238095238095e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_12    OBJ       1.0499999999999995e-02
    x_2_12    product_lb_230  -2.5545373449005350e-02
    x_2_12    product_ub_231  -0.0433212996390325
    x_2_12    onehot_2_238  1
    x_2_12    stock_lb_270  12
    x_2_12    stock_ub_271  12
    x_2_12    parent_nonstrict_scope_272  5.2499999999999991e-02
    x_2_12    unique_nonzero_owner_430  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_12    product_lb_230  1
    w_2_12    product_ub_231  1
    w_2_12    normalized_mass_2_239  1
    w_2_12    normalized_ratio_2_240  -1.7142857142857142e+00
    w_2_12    full_original_Gini_330  -2.3202380952380953e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_13    OBJ       2.0999999999999991e-02
    x_2_13    product_lb_232  -2.5545373449005350e-02
    x_2_13    product_ub_233  -0.0433212996390325
    x_2_13    onehot_2_238  1
    x_2_13    stock_lb_270  13
    x_2_13    stock_ub_271  13
    x_2_13    parent_nonstrict_scope_272  6.2999999999999987e-02
    x_2_13    unique_nonzero_owner_431  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_13    product_lb_232  1
    w_2_13    product_ub_233  1
    w_2_13    normalized_mass_2_239  1
    w_2_13    normalized_ratio_2_240  -1.8571428571428570e+00
    w_2_13    full_original_Gini_330  -2.7059523809523810e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_14    OBJ       0.0315
    x_2_14    product_lb_234  -2.5545373449005350e-02
    x_2_14    product_ub_235  -0.0433212996390325
    x_2_14    onehot_2_238  1
    x_2_14    stock_lb_270  14
    x_2_14    stock_ub_271  14
    x_2_14    parent_nonstrict_scope_272  0.0735
    x_2_14    unique_nonzero_owner_432  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_14    product_lb_234  1
    w_2_14    product_ub_235  1
    w_2_14    normalized_mass_2_239  1
    w_2_14    normalized_ratio_2_240  -2
    w_2_14    full_original_Gini_330  -3.0916666666666664e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_15    OBJ       4.1999999999999996e-02
    x_2_15    product_lb_236  -2.5545373449005350e-02
    x_2_15    product_ub_237  -0.0433212996390325
    x_2_15    onehot_2_238  1
    x_2_15    stock_lb_270  15
    x_2_15    stock_ub_271  15
    x_2_15    parent_nonstrict_scope_272  8.3999999999999991e-02
    x_2_15    unique_nonzero_owner_433  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_15    product_lb_236  1
    w_2_15    product_ub_237  1
    w_2_15    normalized_mass_2_239  1
    w_2_15    normalized_ratio_2_240  -2.1428571428571428e+00
    w_2_15    full_original_Gini_330  -3.4773809523809526e+01
    rho_2     normalized_ratio_2_240  1
    rho_2     block_pair_pos_273  -1
    rho_2     block_pair_neg_274  1
    rho_2     block_pair_pos_275  1
    rho_2     block_pair_neg_276  -1
    rho_2     block_pair_pos_283  1
    rho_2     block_pair_neg_284  -1
    rho_2     block_pair_pos_297  1
    rho_2     block_pair_neg_298  -1
    rho_2     block_pair_pos_303  1
    rho_2     block_pair_neg_304  -1
    rho_2     block_pair_pos_307  1
    rho_2     block_pair_neg_308  -1
    rho_2     block_pair_pos_319  1
    rho_2     block_pair_neg_320  -1
    rho_2     normalization_329  1
    MARKER    'MARKER'                 'INTORG'
    x_9_0     OBJ       1.1249999999999993e-02
    x_9_0     product_lb_241  -2.5545373449005350e-02
    x_9_0     product_ub_242  -0.0433212996390325
    x_9_0     onehot_9_267  1
    x_9_0     parent_nonstrict_scope_272  0.0375
    x_9_0     unique_nonzero_owner_434  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_0     product_lb_241  1
    w_9_0     product_ub_242  1
    w_9_0     normalized_mass_9_268  1
    w_9_0     full_original_Gini_330  -2.3083333333333336e+01
    MARKER    'MARKER'                 'INTORG'
    x_9_1     OBJ       3.7499999999999929e-03
    x_9_1     product_lb_243  -2.5545373449005350e-02
    x_9_1     product_ub_244  -0.0433212996390325
    x_9_1     onehot_9_267  1
    x_9_1     stock_lb_270  1
    x_9_1     stock_ub_271  1
    x_9_1     parent_nonstrict_scope_272  0.03
    x_9_1     unique_nonzero_owner_435  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_1     product_lb_243  1
    w_9_1     product_ub_244  1
    w_9_1     normalized_mass_9_268  1
    w_9_1     normalized_ratio_9_269  -0.2
    w_9_1     full_original_Gini_330  -1.7683333333333334e+01
    MARKER    'MARKER'                 'INTORG'
    x_9_2     OBJ       -3.7500000000000068e-03
    x_9_2     product_lb_245  -2.5545373449005350e-02
    x_9_2     product_ub_246  -0.0433212996390325
    x_9_2     onehot_9_267  1
    x_9_2     stock_lb_270  2
    x_9_2     stock_ub_271  2
    x_9_2     parent_nonstrict_scope_272  0.0225
    x_9_2     unique_nonzero_owner_436  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_2     product_lb_245  1
    w_9_2     product_ub_246  1
    w_9_2     normalized_mass_9_268  1
    w_9_2     normalized_ratio_9_269  -0.4
    w_9_2     full_original_Gini_330  -1.2283333333333330e+01
    MARKER    'MARKER'                 'INTORG'
    x_9_3     OBJ       -1.1250000000000010e-02
    x_9_3     product_lb_247  -2.5545373449005350e-02
    x_9_3     product_ub_248  -0.0433212996390325
    x_9_3     onehot_9_267  1
    x_9_3     stock_lb_270  3
    x_9_3     stock_ub_271  3
    x_9_3     parent_nonstrict_scope_272  1.4999999999999996e-02
    x_9_3     unique_nonzero_owner_437  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_3     product_lb_247  1
    w_9_3     product_ub_248  1
    w_9_3     normalized_mass_9_268  1
    w_9_3     normalized_ratio_9_269  -6.0000000000000009e-01
    w_9_3     full_original_Gini_330  -7.8833333333333329e+00
    MARKER    'MARKER'                 'INTORG'
    x_9_4     OBJ       -1.8750000000000010e-02
    x_9_4     product_lb_249  -2.5545373449005350e-02
    x_9_4     product_ub_250  -0.0433212996390325
    x_9_4     onehot_9_267  1
    x_9_4     stock_lb_270  4
    x_9_4     stock_ub_271  4
    x_9_4     parent_nonstrict_scope_272  7.4999999999999980e-03
    x_9_4     unique_nonzero_owner_438  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_4     product_lb_249  1
    w_9_4     product_ub_250  1
    w_9_4     normalized_mass_9_268  1
    w_9_4     normalized_ratio_9_269  -0.8
    w_9_4     full_original_Gini_330  -5.19761904761905
    MARKER    'MARKER'                 'INTORG'
    x_9_5     OBJ       -2.6250000000000006e-02
    x_9_5     product_lb_251  -2.5545373449005350e-02
    x_9_5     product_ub_252  -0.0433212996390325
    x_9_5     onehot_9_267  1
    x_9_5     stock_lb_270  5
    x_9_5     stock_ub_271  5
    x_9_5     unique_nonzero_owner_439  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_5     product_lb_251  1
    w_9_5     product_ub_252  1
    w_9_5     normalized_mass_9_268  1
    w_9_5     normalized_ratio_9_269  -1
    w_9_5     full_original_Gini_330  -4.8166666666666664e+00
    MARKER    'MARKER'                 'INTORG'
    x_9_6     OBJ       -0.01875
    x_9_6     product_lb_253  -2.5545373449005350e-02
    x_9_6     product_ub_254  -0.0433212996390325
    x_9_6     onehot_9_267  1
    x_9_6     stock_lb_270  6
    x_9_6     stock_ub_271  6
    x_9_6     parent_nonstrict_scope_272  7.5000000000000067e-03
    x_9_6     unique_nonzero_owner_440  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_6     product_lb_253  1
    w_9_6     product_ub_254  1
    w_9_6     normalized_mass_9_268  1
    w_9_6     normalized_ratio_9_269  -1.2000000000000002e+00
    w_9_6     full_original_Gini_330  -9.4166666666666714e+00
    MARKER    'MARKER'                 'INTORG'
    x_9_7     OBJ       -1.1250000000000001e-02
    x_9_7     product_lb_255  -2.5545373449005350e-02
    x_9_7     product_ub_256  -0.0433212996390325
    x_9_7     onehot_9_267  1
    x_9_7     stock_lb_270  7
    x_9_7     stock_ub_271  7
    x_9_7     parent_nonstrict_scope_272  1.5000000000000005e-02
    x_9_7     unique_nonzero_owner_441  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_7     product_lb_255  1
    w_9_7     product_ub_256  1
    w_9_7     normalized_mass_9_268  1
    w_9_7     normalized_ratio_9_269  -1.4000000000000001e+00
    w_9_7     full_original_Gini_330  -1.4716666666666670e+01
    MARKER    'MARKER'                 'INTORG'
    x_9_8     OBJ       -3.7500000000000033e-03
    x_9_8     product_lb_257  -2.5545373449005350e-02
    x_9_8     product_ub_258  -0.0433212996390325
    x_9_8     onehot_9_267  1
    x_9_8     stock_lb_270  8
    x_9_8     stock_ub_271  8
    x_9_8     parent_nonstrict_scope_272  2.2500000000000003e-02
    MARKER    'MARKER'                 'INTEND'
    w_9_8     product_lb_257  1
    w_9_8     product_ub_258  1
    w_9_8     normalized_mass_9_268  1
    w_9_8     normalized_ratio_9_269  -1.6
    w_9_8     full_original_Gini_330  -2.0116666666666671e+01
    MARKER    'MARKER'                 'INTORG'
    x_9_9     OBJ       3.7499999999999929e-03
    x_9_9     product_lb_259  -2.5545373449005350e-02
    x_9_9     product_ub_260  -0.0433212996390325
    x_9_9     onehot_9_267  1
    x_9_9     stock_lb_270  9
    x_9_9     stock_ub_271  9
    x_9_9     parent_nonstrict_scope_272  0.03
    x_9_9     unique_nonzero_owner_442  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_9     product_lb_259  1
    w_9_9     product_ub_260  1
    w_9_9     normalized_mass_9_268  1
    w_9_9     normalized_ratio_9_269  -1.8
    w_9_9     full_original_Gini_330  -2.5516666666666673e+01
    MARKER    'MARKER'                 'INTORG'
    x_9_10    OBJ       1.1249999999999993e-02
    x_9_10    product_lb_261  -2.5545373449005350e-02
    x_9_10    product_ub_262  -0.0433212996390325
    x_9_10    onehot_9_267  1
    x_9_10    stock_lb_270  10
    x_9_10    stock_ub_271  10
    x_9_10    parent_nonstrict_scope_272  0.0375
    x_9_10    unique_nonzero_owner_443  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_10    product_lb_261  1
    w_9_10    product_ub_262  1
    w_9_10    normalized_mass_9_268  1
    w_9_10    normalized_ratio_9_269  -2
    w_9_10    full_original_Gini_330  -3.0916666666666664e+01
    MARKER    'MARKER'                 'INTORG'
    x_9_11    OBJ       0.01875
    x_9_11    product_lb_263  -2.5545373449005350e-02
    x_9_11    product_ub_264  -0.0433212996390325
    x_9_11    onehot_9_267  1
    x_9_11    stock_lb_270  11
    x_9_11    stock_ub_271  11
    x_9_11    parent_nonstrict_scope_272  4.5000000000000005e-02
    x_9_11    unique_nonzero_owner_444  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_11    product_lb_263  1
    w_9_11    product_ub_264  1
    w_9_11    normalized_mass_9_268  1
    w_9_11    normalized_ratio_9_269  -2.2
    w_9_11    full_original_Gini_330  -3.6316666666666670e+01
    MARKER    'MARKER'                 'INTORG'
    x_9_12    OBJ       2.6250000000000006e-02
    x_9_12    product_lb_265  -2.5545373449005350e-02
    x_9_12    product_ub_266  -0.0433212996390325
    x_9_12    onehot_9_267  1
    x_9_12    stock_lb_270  12
    x_9_12    stock_ub_271  12
    x_9_12    parent_nonstrict_scope_272  5.2500000000000012e-02
    x_9_12    unique_nonzero_owner_445  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_12    product_lb_265  1
    w_9_12    product_ub_266  1
    w_9_12    normalized_mass_9_268  1
    w_9_12    normalized_ratio_9_269  -2.4000000000000004e+00
    w_9_12    full_original_Gini_330  -4.1716666666666654e+01
    rho_9     normalized_ratio_9_269  1
    rho_9     block_pair_pos_273  1
    rho_9     block_pair_neg_274  -1
    rho_9     block_pair_pos_277  1
    rho_9     block_pair_neg_278  -1
    rho_9     block_pair_pos_287  1
    rho_9     block_pair_neg_288  -1
    rho_9     block_pair_pos_299  1
    rho_9     block_pair_neg_300  -1
    rho_9     block_pair_pos_305  1
    rho_9     block_pair_neg_306  -1
    rho_9     block_pair_pos_311  1
    rho_9     block_pair_neg_312  -1
    rho_9     block_pair_pos_323  1
    rho_9     block_pair_neg_324  -1
    rho_9     normalization_329  1
    a_13_17   block_pair_pos_293  1
    a_13_17   block_pair_neg_294  1
    a_13_17   full_original_Gini_330  -1
    a_13_31   block_pair_pos_295  1
    a_13_31   block_pair_neg_296  1
    a_13_31   full_original_Gini_330  -1
    a_13_6    block_pair_pos_285  1
    a_13_6    block_pair_neg_286  1
    a_13_6    full_original_Gini_330  -1
    a_13_14   block_pair_pos_289  1
    a_13_14   block_pair_neg_290  1
    a_13_14   full_original_Gini_330  -1
    a_13_15   block_pair_pos_291  1
    a_13_15   block_pair_neg_292  1
    a_13_15   full_original_Gini_330  -1
    a_13_2    block_pair_pos_283  1
    a_13_2    block_pair_neg_284  1
    a_13_2    full_original_Gini_330  -1
    a_13_9    block_pair_pos_287  1
    a_13_9    block_pair_neg_288  1
    a_13_9    full_original_Gini_330  -1
    a_17_31   block_pair_pos_317  1
    a_17_31   block_pair_neg_318  1
    a_17_31   full_original_Gini_330  -1
    a_17_6    block_pair_pos_309  1
    a_17_6    block_pair_neg_310  1
    a_17_6    full_original_Gini_330  -1
    a_17_14   block_pair_pos_313  1
    a_17_14   block_pair_neg_314  1
    a_17_14   full_original_Gini_330  -1
    a_17_15   block_pair_pos_315  1
    a_17_15   block_pair_neg_316  1
    a_17_15   full_original_Gini_330  -1
    a_17_2    block_pair_pos_307  1
    a_17_2    block_pair_neg_308  1
    a_17_2    full_original_Gini_330  -1
    a_17_9    block_pair_pos_311  1
    a_17_9    block_pair_neg_312  1
    a_17_9    full_original_Gini_330  -1
    a_31_6    block_pair_pos_321  1
    a_31_6    block_pair_neg_322  1
    a_31_6    full_original_Gini_330  -1
    a_31_14   block_pair_pos_325  1
    a_31_14   block_pair_neg_326  1
    a_31_14   full_original_Gini_330  -1
    a_31_15   block_pair_pos_327  1
    a_31_15   block_pair_neg_328  1
    a_31_15   full_original_Gini_330  -1
    a_31_2    block_pair_pos_319  1
    a_31_2    block_pair_neg_320  1
    a_31_2    full_original_Gini_330  -1
    a_31_9    block_pair_pos_323  1
    a_31_9    block_pair_neg_324  1
    a_31_9    full_original_Gini_330  -1
    a_6_14    block_pair_pos_279  1
    a_6_14    block_pair_neg_280  1
    a_6_14    full_original_Gini_330  -1
    a_6_15    block_pair_pos_281  1
    a_6_15    block_pair_neg_282  1
    a_6_15    full_original_Gini_330  -1
    a_6_2     block_pair_pos_275  1
    a_6_2     block_pair_neg_276  1
    a_6_2     full_original_Gini_330  -1
    a_6_9     block_pair_pos_277  1
    a_6_9     block_pair_neg_278  1
    a_6_9     full_original_Gini_330  -1
    a_14_15   block_pair_pos_301  1
    a_14_15   block_pair_neg_302  1
    a_14_15   full_original_Gini_330  -1
    a_14_2    block_pair_pos_297  1
    a_14_2    block_pair_neg_298  1
    a_14_2    full_original_Gini_330  -1
    a_14_9    block_pair_pos_299  1
    a_14_9    block_pair_neg_300  1
    a_14_9    full_original_Gini_330  -1
    a_15_2    block_pair_pos_303  1
    a_15_2    block_pair_neg_304  1
    a_15_2    full_original_Gini_330  -1
    a_15_9    block_pair_pos_305  1
    a_15_9    block_pair_neg_306  1
    a_15_9    full_original_Gini_330  -1
    a_2_9     block_pair_pos_273  1
    a_2_9     block_pair_neg_274  1
    a_2_9     full_original_Gini_330  -1
    MARKER    'MARKER'                 'INTORG'
    service_0_13_0  unique_nonzero_owner_331  1
    service_0_13_0  service_visit_def_887  1
    service_0_13_0  free_load_conservation_888  -13
    service_0_13_0  original_T_including_depot_unload_936  1560
    service_0_13_1  unique_nonzero_owner_332  1
    service_0_13_1  service_visit_def_887  1
    service_0_13_1  free_load_conservation_888  -12
    service_0_13_1  original_T_including_depot_unload_936  1440
    service_0_13_2  unique_nonzero_owner_333  1
    service_0_13_2  service_visit_def_887  1
    service_0_13_2  free_load_conservation_888  -11
    service_0_13_2  original_T_including_depot_unload_936  1320
    service_0_13_3  unique_nonzero_owner_334  1
    service_0_13_3  service_visit_def_887  1
    service_0_13_3  free_load_conservation_888  -10
    service_0_13_3  original_T_including_depot_unload_936  1200
    service_0_13_4  unique_nonzero_owner_335  1
    service_0_13_4  service_visit_def_887  1
    service_0_13_4  free_load_conservation_888  -9
    service_0_13_4  original_T_including_depot_unload_936  1080
    service_0_13_5  unique_nonzero_owner_336  1
    service_0_13_5  service_visit_def_887  1
    service_0_13_5  free_load_conservation_888  -8
    service_0_13_5  original_T_including_depot_unload_936  960
    service_0_13_6  unique_nonzero_owner_337  1
    service_0_13_6  service_visit_def_887  1
    service_0_13_6  free_load_conservation_888  -7
    service_0_13_6  original_T_including_depot_unload_936  840
    service_0_13_7  unique_nonzero_owner_338  1
    service_0_13_7  service_visit_def_887  1
    service_0_13_7  free_load_conservation_888  -6
    service_0_13_7  original_T_including_depot_unload_936  720
    service_0_13_8  unique_nonzero_owner_339  1
    service_0_13_8  service_visit_def_887  1
    service_0_13_8  free_load_conservation_888  -5
    service_0_13_8  original_T_including_depot_unload_936  600
    service_0_13_9  unique_nonzero_owner_340  1
    service_0_13_9  service_visit_def_887  1
    service_0_13_9  free_load_conservation_888  -4
    service_0_13_9  original_T_including_depot_unload_936  480
    service_0_13_10  unique_nonzero_owner_341  1
    service_0_13_10  service_visit_def_887  1
    service_0_13_10  free_load_conservation_888  -3
    service_0_13_10  original_T_including_depot_unload_936  360
    service_0_13_11  unique_nonzero_owner_342  1
    service_0_13_11  service_visit_def_887  1
    service_0_13_11  free_load_conservation_888  -2
    service_0_13_11  original_T_including_depot_unload_936  240
    service_0_13_12  unique_nonzero_owner_343  1
    service_0_13_12  service_visit_def_887  1
    service_0_13_12  free_load_conservation_888  -1
    service_0_13_12  original_T_including_depot_unload_936  120
    service_0_13_14  unique_nonzero_owner_344  1
    service_0_13_14  service_visit_def_887  1
    service_0_13_14  free_load_conservation_888  1
    service_0_13_15  unique_nonzero_owner_345  1
    service_0_13_15  service_visit_def_887  1
    service_0_13_15  free_load_conservation_888  2
    service_0_13_16  unique_nonzero_owner_346  1
    service_0_13_16  service_visit_def_887  1
    service_0_13_16  free_load_conservation_888  3
    service_0_13_17  unique_nonzero_owner_347  1
    service_0_13_17  service_visit_def_887  1
    service_0_13_17  free_load_conservation_888  4
    service_0_13_18  unique_nonzero_owner_348  1
    service_0_13_18  service_visit_def_887  1
    service_0_13_18  free_load_conservation_888  5
    service_0_13_19  unique_nonzero_owner_349  1
    service_0_13_19  service_visit_def_887  1
    service_0_13_19  free_load_conservation_888  6
    service_1_13_0  unique_nonzero_owner_331  1
    service_1_13_0  service_visit_def_1260  1
    service_1_13_0  free_load_conservation_1261  -13
    service_1_13_0  original_T_including_depot_unload_1307  1560
    service_1_13_1  unique_nonzero_owner_332  1
    service_1_13_1  service_visit_def_1260  1
    service_1_13_1  free_load_conservation_1261  -12
    service_1_13_1  original_T_including_depot_unload_1307  1440
    service_1_13_2  unique_nonzero_owner_333  1
    service_1_13_2  service_visit_def_1260  1
    service_1_13_2  free_load_conservation_1261  -11
    service_1_13_2  original_T_including_depot_unload_1307  1320
    service_1_13_3  unique_nonzero_owner_334  1
    service_1_13_3  service_visit_def_1260  1
    service_1_13_3  free_load_conservation_1261  -10
    service_1_13_3  original_T_including_depot_unload_1307  1200
    service_1_13_4  unique_nonzero_owner_335  1
    service_1_13_4  service_visit_def_1260  1
    service_1_13_4  free_load_conservation_1261  -9
    service_1_13_4  original_T_including_depot_unload_1307  1080
    service_1_13_5  unique_nonzero_owner_336  1
    service_1_13_5  service_visit_def_1260  1
    service_1_13_5  free_load_conservation_1261  -8
    service_1_13_5  original_T_including_depot_unload_1307  960
    service_1_13_6  unique_nonzero_owner_337  1
    service_1_13_6  service_visit_def_1260  1
    service_1_13_6  free_load_conservation_1261  -7
    service_1_13_6  original_T_including_depot_unload_1307  840
    service_1_13_7  unique_nonzero_owner_338  1
    service_1_13_7  service_visit_def_1260  1
    service_1_13_7  free_load_conservation_1261  -6
    service_1_13_7  original_T_including_depot_unload_1307  720
    service_1_13_8  unique_nonzero_owner_339  1
    service_1_13_8  service_visit_def_1260  1
    service_1_13_8  free_load_conservation_1261  -5
    service_1_13_8  original_T_including_depot_unload_1307  600
    service_1_13_9  unique_nonzero_owner_340  1
    service_1_13_9  service_visit_def_1260  1
    service_1_13_9  free_load_conservation_1261  -4
    service_1_13_9  original_T_including_depot_unload_1307  480
    service_1_13_10  unique_nonzero_owner_341  1
    service_1_13_10  service_visit_def_1260  1
    service_1_13_10  free_load_conservation_1261  -3
    service_1_13_10  original_T_including_depot_unload_1307  360
    service_1_13_11  unique_nonzero_owner_342  1
    service_1_13_11  service_visit_def_1260  1
    service_1_13_11  free_load_conservation_1261  -2
    service_1_13_11  original_T_including_depot_unload_1307  240
    service_1_13_12  unique_nonzero_owner_343  1
    service_1_13_12  service_visit_def_1260  1
    service_1_13_12  free_load_conservation_1261  -1
    service_1_13_12  original_T_including_depot_unload_1307  120
    service_1_13_14  unique_nonzero_owner_344  1
    service_1_13_14  service_visit_def_1260  1
    service_1_13_14  free_load_conservation_1261  1
    service_1_13_15  unique_nonzero_owner_345  1
    service_1_13_15  service_visit_def_1260  1
    service_1_13_15  free_load_conservation_1261  2
    service_1_13_16  unique_nonzero_owner_346  1
    service_1_13_16  service_visit_def_1260  1
    service_1_13_16  free_load_conservation_1261  3
    service_1_13_17  unique_nonzero_owner_347  1
    service_1_13_17  service_visit_def_1260  1
    service_1_13_17  free_load_conservation_1261  4
    service_1_13_18  unique_nonzero_owner_348  1
    service_1_13_18  service_visit_def_1260  1
    service_1_13_18  free_load_conservation_1261  5
    service_1_13_19  unique_nonzero_owner_349  1
    service_1_13_19  service_visit_def_1260  1
    service_1_13_19  free_load_conservation_1261  6
    service_2_13_0  unique_nonzero_owner_331  1
    service_2_13_0  service_visit_def_1578  1
    service_2_13_0  free_load_conservation_1579  -13
    service_2_13_0  original_T_including_depot_unload_1624  1560
    service_2_13_1  unique_nonzero_owner_332  1
    service_2_13_1  service_visit_def_1578  1
    service_2_13_1  free_load_conservation_1579  -12
    service_2_13_1  original_T_including_depot_unload_1624  1440
    service_2_13_2  unique_nonzero_owner_333  1
    service_2_13_2  service_visit_def_1578  1
    service_2_13_2  free_load_conservation_1579  -11
    service_2_13_2  original_T_including_depot_unload_1624  1320
    service_2_13_3  unique_nonzero_owner_334  1
    service_2_13_3  service_visit_def_1578  1
    service_2_13_3  free_load_conservation_1579  -10
    service_2_13_3  original_T_including_depot_unload_1624  1200
    service_2_13_4  unique_nonzero_owner_335  1
    service_2_13_4  service_visit_def_1578  1
    service_2_13_4  free_load_conservation_1579  -9
    service_2_13_4  original_T_including_depot_unload_1624  1080
    service_2_13_5  unique_nonzero_owner_336  1
    service_2_13_5  service_visit_def_1578  1
    service_2_13_5  free_load_conservation_1579  -8
    service_2_13_5  original_T_including_depot_unload_1624  960
    service_2_13_6  unique_nonzero_owner_337  1
    service_2_13_6  service_visit_def_1578  1
    service_2_13_6  free_load_conservation_1579  -7
    service_2_13_6  original_T_including_depot_unload_1624  840
    service_2_13_7  unique_nonzero_owner_338  1
    service_2_13_7  service_visit_def_1578  1
    service_2_13_7  free_load_conservation_1579  -6
    service_2_13_7  original_T_including_depot_unload_1624  720
    service_2_13_8  unique_nonzero_owner_339  1
    service_2_13_8  service_visit_def_1578  1
    service_2_13_8  free_load_conservation_1579  -5
    service_2_13_8  original_T_including_depot_unload_1624  600
    service_2_13_9  unique_nonzero_owner_340  1
    service_2_13_9  service_visit_def_1578  1
    service_2_13_9  free_load_conservation_1579  -4
    service_2_13_9  original_T_including_depot_unload_1624  480
    service_2_13_10  unique_nonzero_owner_341  1
    service_2_13_10  service_visit_def_1578  1
    service_2_13_10  free_load_conservation_1579  -3
    service_2_13_10  original_T_including_depot_unload_1624  360
    service_2_13_11  unique_nonzero_owner_342  1
    service_2_13_11  service_visit_def_1578  1
    service_2_13_11  free_load_conservation_1579  -2
    service_2_13_11  original_T_including_depot_unload_1624  240
    service_2_13_12  unique_nonzero_owner_343  1
    service_2_13_12  service_visit_def_1578  1
    service_2_13_12  free_load_conservation_1579  -1
    service_2_13_12  original_T_including_depot_unload_1624  120
    service_2_13_14  unique_nonzero_owner_344  1
    service_2_13_14  service_visit_def_1578  1
    service_2_13_14  free_load_conservation_1579  1
    service_2_13_15  unique_nonzero_owner_345  1
    service_2_13_15  service_visit_def_1578  1
    service_2_13_15  free_load_conservation_1579  2
    service_2_13_16  unique_nonzero_owner_346  1
    service_2_13_16  service_visit_def_1578  1
    service_2_13_16  free_load_conservation_1579  3
    service_2_13_17  unique_nonzero_owner_347  1
    service_2_13_17  service_visit_def_1578  1
    service_2_13_17  free_load_conservation_1579  4
    service_2_13_18  unique_nonzero_owner_348  1
    service_2_13_18  service_visit_def_1578  1
    service_2_13_18  free_load_conservation_1579  5
    service_2_13_19  unique_nonzero_owner_349  1
    service_2_13_19  service_visit_def_1578  1
    service_2_13_19  free_load_conservation_1579  6
    service_0_17_0  unique_nonzero_owner_350  1
    service_0_17_0  service_visit_def_893  1
    service_0_17_0  free_load_conservation_894  -3
    service_0_17_0  original_T_including_depot_unload_936  360
    service_0_17_1  unique_nonzero_owner_351  1
    service_0_17_1  service_visit_def_893  1
    service_0_17_1  free_load_conservation_894  -2
    service_0_17_1  original_T_including_depot_unload_936  240
    service_0_17_2  unique_nonzero_owner_352  1
    service_0_17_2  service_visit_def_893  1
    service_0_17_2  free_load_conservation_894  -1
    service_0_17_2  original_T_including_depot_unload_936  120
    service_0_17_4  unique_nonzero_owner_353  1
    service_0_17_4  service_visit_def_893  1
    service_0_17_4  free_load_conservation_894  1
    service_0_17_5  unique_nonzero_owner_354  1
    service_0_17_5  service_visit_def_893  1
    service_0_17_5  free_load_conservation_894  2
    service_0_17_6  unique_nonzero_owner_355  1
    service_0_17_6  service_visit_def_893  1
    service_0_17_6  free_load_conservation_894  3
    service_0_17_7  unique_nonzero_owner_356  1
    service_0_17_7  service_visit_def_893  1
    service_0_17_7  free_load_conservation_894  4
    service_0_17_8  unique_nonzero_owner_357  1
    service_0_17_8  service_visit_def_893  1
    service_0_17_8  free_load_conservation_894  5
    service_0_17_9  unique_nonzero_owner_358  1
    service_0_17_9  service_visit_def_893  1
    service_0_17_9  free_load_conservation_894  6
    service_0_17_10  unique_nonzero_owner_359  1
    service_0_17_10  service_visit_def_893  1
    service_0_17_10  free_load_conservation_894  7
    service_0_17_11  unique_nonzero_owner_360  1
    service_0_17_11  service_visit_def_893  1
    service_0_17_11  free_load_conservation_894  8
    service_0_17_12  unique_nonzero_owner_361  1
    service_0_17_12  service_visit_def_893  1
    service_0_17_12  free_load_conservation_894  9
    service_0_17_13  unique_nonzero_owner_362  1
    service_0_17_13  service_visit_def_893  1
    service_0_17_13  free_load_conservation_894  10
    service_0_17_14  unique_nonzero_owner_363  1
    service_0_17_14  service_visit_def_893  1
    service_0_17_14  free_load_conservation_894  11
    service_0_17_15  unique_nonzero_owner_364  1
    service_0_17_15  service_visit_def_893  1
    service_0_17_15  free_load_conservation_894  12
    service_0_17_16  unique_nonzero_owner_365  1
    service_0_17_16  service_visit_def_893  1
    service_0_17_16  free_load_conservation_894  13
    service_1_17_0  unique_nonzero_owner_350  1
    service_1_17_0  service_visit_def_1266  1
    service_1_17_0  free_load_conservation_1267  -3
    service_1_17_0  original_T_including_depot_unload_1307  360
    service_1_17_1  unique_nonzero_owner_351  1
    service_1_17_1  service_visit_def_1266  1
    service_1_17_1  free_load_conservation_1267  -2
    service_1_17_1  original_T_including_depot_unload_1307  240
    service_1_17_2  unique_nonzero_owner_352  1
    service_1_17_2  service_visit_def_1266  1
    service_1_17_2  free_load_conservation_1267  -1
    service_1_17_2  original_T_including_depot_unload_1307  120
    service_1_17_4  unique_nonzero_owner_353  1
    service_1_17_4  service_visit_def_1266  1
    service_1_17_4  free_load_conservation_1267  1
    service_1_17_5  unique_nonzero_owner_354  1
    service_1_17_5  service_visit_def_1266  1
    service_1_17_5  free_load_conservation_1267  2
    service_1_17_6  unique_nonzero_owner_355  1
    service_1_17_6  service_visit_def_1266  1
    service_1_17_6  free_load_conservation_1267  3
    service_1_17_7  unique_nonzero_owner_356  1
    service_1_17_7  service_visit_def_1266  1
    service_1_17_7  free_load_conservation_1267  4
    service_1_17_8  unique_nonzero_owner_357  1
    service_1_17_8  service_visit_def_1266  1
    service_1_17_8  free_load_conservation_1267  5
    service_1_17_9  unique_nonzero_owner_358  1
    service_1_17_9  service_visit_def_1266  1
    service_1_17_9  free_load_conservation_1267  6
    service_1_17_10  unique_nonzero_owner_359  1
    service_1_17_10  service_visit_def_1266  1
    service_1_17_10  free_load_conservation_1267  7
    service_1_17_11  unique_nonzero_owner_360  1
    service_1_17_11  service_visit_def_1266  1
    service_1_17_11  free_load_conservation_1267  8
    service_1_17_12  unique_nonzero_owner_361  1
    service_1_17_12  service_visit_def_1266  1
    service_1_17_12  free_load_conservation_1267  9
    service_1_17_13  unique_nonzero_owner_362  1
    service_1_17_13  service_visit_def_1266  1
    service_1_17_13  free_load_conservation_1267  10
    service_1_17_14  unique_nonzero_owner_363  1
    service_1_17_14  service_visit_def_1266  1
    service_1_17_14  free_load_conservation_1267  11
    service_1_17_15  unique_nonzero_owner_364  1
    service_1_17_15  service_visit_def_1266  1
    service_1_17_15  free_load_conservation_1267  12
    service_1_17_16  unique_nonzero_owner_365  1
    service_1_17_16  service_visit_def_1266  1
    service_1_17_16  free_load_conservation_1267  13
    service_2_17_0  unique_nonzero_owner_350  1
    service_2_17_0  service_visit_def_1584  1
    service_2_17_0  free_load_conservation_1585  -3
    service_2_17_0  original_T_including_depot_unload_1624  360
    service_2_17_1  unique_nonzero_owner_351  1
    service_2_17_1  service_visit_def_1584  1
    service_2_17_1  free_load_conservation_1585  -2
    service_2_17_1  original_T_including_depot_unload_1624  240
    service_2_17_2  unique_nonzero_owner_352  1
    service_2_17_2  service_visit_def_1584  1
    service_2_17_2  free_load_conservation_1585  -1
    service_2_17_2  original_T_including_depot_unload_1624  120
    service_2_17_4  unique_nonzero_owner_353  1
    service_2_17_4  service_visit_def_1584  1
    service_2_17_4  free_load_conservation_1585  1
    service_2_17_5  unique_nonzero_owner_354  1
    service_2_17_5  service_visit_def_1584  1
    service_2_17_5  free_load_conservation_1585  2
    service_2_17_6  unique_nonzero_owner_355  1
    service_2_17_6  service_visit_def_1584  1
    service_2_17_6  free_load_conservation_1585  3
    service_2_17_7  unique_nonzero_owner_356  1
    service_2_17_7  service_visit_def_1584  1
    service_2_17_7  free_load_conservation_1585  4
    service_2_17_8  unique_nonzero_owner_357  1
    service_2_17_8  service_visit_def_1584  1
    service_2_17_8  free_load_conservation_1585  5
    service_2_17_9  unique_nonzero_owner_358  1
    service_2_17_9  service_visit_def_1584  1
    service_2_17_9  free_load_conservation_1585  6
    service_2_17_10  unique_nonzero_owner_359  1
    service_2_17_10  service_visit_def_1584  1
    service_2_17_10  free_load_conservation_1585  7
    service_2_17_11  unique_nonzero_owner_360  1
    service_2_17_11  service_visit_def_1584  1
    service_2_17_11  free_load_conservation_1585  8
    service_2_17_12  unique_nonzero_owner_361  1
    service_2_17_12  service_visit_def_1584  1
    service_2_17_12  free_load_conservation_1585  9
    service_2_17_13  unique_nonzero_owner_362  1
    service_2_17_13  service_visit_def_1584  1
    service_2_17_13  free_load_conservation_1585  10
    service_2_17_14  unique_nonzero_owner_363  1
    service_2_17_14  service_visit_def_1584  1
    service_2_17_14  free_load_conservation_1585  11
    service_2_17_15  unique_nonzero_owner_364  1
    service_2_17_15  service_visit_def_1584  1
    service_2_17_15  free_load_conservation_1585  12
    service_2_17_16  unique_nonzero_owner_365  1
    service_2_17_16  service_visit_def_1584  1
    service_2_17_16  free_load_conservation_1585  13
    service_0_31_0  unique_nonzero_owner_366  1
    service_0_31_0  service_visit_def_899  1
    service_0_31_0  free_load_conservation_900  -2
    service_0_31_0  original_T_including_depot_unload_936  240
    service_0_31_1  unique_nonzero_owner_367  1
    service_0_31_1  service_visit_def_899  1
    service_0_31_1  free_load_conservation_900  -1
    service_0_31_1  original_T_including_depot_unload_936  120
    service_0_31_3  unique_nonzero_owner_368  1
    service_0_31_3  service_visit_def_899  1
    service_0_31_3  free_load_conservation_900  1
    service_0_31_4  unique_nonzero_owner_369  1
    service_0_31_4  service_visit_def_899  1
    service_0_31_4  free_load_conservation_900  2
    service_0_31_5  unique_nonzero_owner_370  1
    service_0_31_5  service_visit_def_899  1
    service_0_31_5  free_load_conservation_900  3
    service_0_31_6  unique_nonzero_owner_371  1
    service_0_31_6  service_visit_def_899  1
    service_0_31_6  free_load_conservation_900  4
    service_0_31_7  unique_nonzero_owner_372  1
    service_0_31_7  service_visit_def_899  1
    service_0_31_7  free_load_conservation_900  5
    service_0_31_8  unique_nonzero_owner_373  1
    service_0_31_8  service_visit_def_899  1
    service_0_31_8  free_load_conservation_900  6
    service_0_31_9  unique_nonzero_owner_374  1
    service_0_31_9  service_visit_def_899  1
    service_0_31_9  free_load_conservation_900  7
    service_0_31_10  unique_nonzero_owner_375  1
    service_0_31_10  service_visit_def_899  1
    service_0_31_10  free_load_conservation_900  8
    service_0_31_11  unique_nonzero_owner_376  1
    service_0_31_11  service_visit_def_899  1
    service_0_31_11  free_load_conservation_900  9
    service_0_31_12  unique_nonzero_owner_377  1
    service_0_31_12  service_visit_def_899  1
    service_0_31_12  free_load_conservation_900  10
    service_1_31_0  unique_nonzero_owner_366  1
    service_1_31_0  service_visit_def_1272  1
    service_1_31_0  free_load_conservation_1273  -2
    service_1_31_0  original_T_including_depot_unload_1307  240
    service_1_31_1  unique_nonzero_owner_367  1
    service_1_31_1  service_visit_def_1272  1
    service_1_31_1  free_load_conservation_1273  -1
    service_1_31_1  original_T_including_depot_unload_1307  120
    service_1_31_3  unique_nonzero_owner_368  1
    service_1_31_3  service_visit_def_1272  1
    service_1_31_3  free_load_conservation_1273  1
    service_1_31_4  unique_nonzero_owner_369  1
    service_1_31_4  service_visit_def_1272  1
    service_1_31_4  free_load_conservation_1273  2
    service_1_31_5  unique_nonzero_owner_370  1
    service_1_31_5  service_visit_def_1272  1
    service_1_31_5  free_load_conservation_1273  3
    service_1_31_6  unique_nonzero_owner_371  1
    service_1_31_6  service_visit_def_1272  1
    service_1_31_6  free_load_conservation_1273  4
    service_1_31_7  unique_nonzero_owner_372  1
    service_1_31_7  service_visit_def_1272  1
    service_1_31_7  free_load_conservation_1273  5
    service_1_31_8  unique_nonzero_owner_373  1
    service_1_31_8  service_visit_def_1272  1
    service_1_31_8  free_load_conservation_1273  6
    service_1_31_9  unique_nonzero_owner_374  1
    service_1_31_9  service_visit_def_1272  1
    service_1_31_9  free_load_conservation_1273  7
    service_1_31_10  unique_nonzero_owner_375  1
    service_1_31_10  service_visit_def_1272  1
    service_1_31_10  free_load_conservation_1273  8
    service_1_31_11  unique_nonzero_owner_376  1
    service_1_31_11  service_visit_def_1272  1
    service_1_31_11  free_load_conservation_1273  9
    service_1_31_12  unique_nonzero_owner_377  1
    service_1_31_12  service_visit_def_1272  1
    service_1_31_12  free_load_conservation_1273  10
    service_2_31_0  unique_nonzero_owner_366  1
    service_2_31_0  service_visit_def_1590  1
    service_2_31_0  free_load_conservation_1591  -2
    service_2_31_0  original_T_including_depot_unload_1624  240
    service_2_31_1  unique_nonzero_owner_367  1
    service_2_31_1  service_visit_def_1590  1
    service_2_31_1  free_load_conservation_1591  -1
    service_2_31_1  original_T_including_depot_unload_1624  120
    service_2_31_3  unique_nonzero_owner_368  1
    service_2_31_3  service_visit_def_1590  1
    service_2_31_3  free_load_conservation_1591  1
    service_2_31_4  unique_nonzero_owner_369  1
    service_2_31_4  service_visit_def_1590  1
    service_2_31_4  free_load_conservation_1591  2
    service_2_31_5  unique_nonzero_owner_370  1
    service_2_31_5  service_visit_def_1590  1
    service_2_31_5  free_load_conservation_1591  3
    service_2_31_6  unique_nonzero_owner_371  1
    service_2_31_6  service_visit_def_1590  1
    service_2_31_6  free_load_conservation_1591  4
    service_2_31_7  unique_nonzero_owner_372  1
    service_2_31_7  service_visit_def_1590  1
    service_2_31_7  free_load_conservation_1591  5
    service_2_31_8  unique_nonzero_owner_373  1
    service_2_31_8  service_visit_def_1590  1
    service_2_31_8  free_load_conservation_1591  6
    service_2_31_9  unique_nonzero_owner_374  1
    service_2_31_9  service_visit_def_1590  1
    service_2_31_9  free_load_conservation_1591  7
    service_2_31_10  unique_nonzero_owner_375  1
    service_2_31_10  service_visit_def_1590  1
    service_2_31_10  free_load_conservation_1591  8
    service_2_31_11  unique_nonzero_owner_376  1
    service_2_31_11  service_visit_def_1590  1
    service_2_31_11  free_load_conservation_1591  9
    service_2_31_12  unique_nonzero_owner_377  1
    service_2_31_12  service_visit_def_1590  1
    service_2_31_12  free_load_conservation_1591  10
    service_0_6_0  unique_nonzero_owner_378  1
    service_0_6_0  service_visit_def_905  1
    service_0_6_0  free_load_conservation_906  -1
    service_0_6_0  original_T_including_depot_unload_936  120
    service_0_6_2  unique_nonzero_owner_379  1
    service_0_6_2  service_visit_def_905  1
    service_0_6_2  free_load_conservation_906  1
    service_0_6_3  unique_nonzero_owner_380  1
    service_0_6_3  service_visit_def_905  1
    service_0_6_3  free_load_conservation_906  2
    service_0_6_4  unique_nonzero_owner_381  1
    service_0_6_4  service_visit_def_905  1
    service_0_6_4  free_load_conservation_906  3
    service_0_6_5  unique_nonzero_owner_382  1
    service_0_6_5  service_visit_def_905  1
    service_0_6_5  free_load_conservation_906  4
    service_0_6_6  unique_nonzero_owner_383  1
    service_0_6_6  service_visit_def_905  1
    service_0_6_6  free_load_conservation_906  5
    service_0_6_7  unique_nonzero_owner_384  1
    service_0_6_7  service_visit_def_905  1
    service_0_6_7  free_load_conservation_906  6
    service_0_6_8  unique_nonzero_owner_385  1
    service_0_6_8  service_visit_def_905  1
    service_0_6_8  free_load_conservation_906  7
    service_0_6_9  unique_nonzero_owner_386  1
    service_0_6_9  service_visit_def_905  1
    service_0_6_9  free_load_conservation_906  8
    service_0_6_10  unique_nonzero_owner_387  1
    service_0_6_10  service_visit_def_905  1
    service_0_6_10  free_load_conservation_906  9
    service_1_6_0  unique_nonzero_owner_378  1
    service_1_6_0  service_visit_def_1278  1
    service_1_6_0  free_load_conservation_1279  -1
    service_1_6_0  original_T_including_depot_unload_1307  120
    service_1_6_2  unique_nonzero_owner_379  1
    service_1_6_2  service_visit_def_1278  1
    service_1_6_2  free_load_conservation_1279  1
    service_1_6_3  unique_nonzero_owner_380  1
    service_1_6_3  service_visit_def_1278  1
    service_1_6_3  free_load_conservation_1279  2
    service_1_6_4  unique_nonzero_owner_381  1
    service_1_6_4  service_visit_def_1278  1
    service_1_6_4  free_load_conservation_1279  3
    service_1_6_5  unique_nonzero_owner_382  1
    service_1_6_5  service_visit_def_1278  1
    service_1_6_5  free_load_conservation_1279  4
    service_1_6_6  unique_nonzero_owner_383  1
    service_1_6_6  service_visit_def_1278  1
    service_1_6_6  free_load_conservation_1279  5
    service_1_6_7  unique_nonzero_owner_384  1
    service_1_6_7  service_visit_def_1278  1
    service_1_6_7  free_load_conservation_1279  6
    service_1_6_8  unique_nonzero_owner_385  1
    service_1_6_8  service_visit_def_1278  1
    service_1_6_8  free_load_conservation_1279  7
    service_1_6_9  unique_nonzero_owner_386  1
    service_1_6_9  service_visit_def_1278  1
    service_1_6_9  free_load_conservation_1279  8
    service_1_6_10  unique_nonzero_owner_387  1
    service_1_6_10  service_visit_def_1278  1
    service_1_6_10  free_load_conservation_1279  9
    service_2_6_0  unique_nonzero_owner_378  1
    service_2_6_0  service_visit_def_1596  1
    service_2_6_0  free_load_conservation_1597  -1
    service_2_6_0  original_T_including_depot_unload_1624  120
    service_2_6_2  unique_nonzero_owner_379  1
    service_2_6_2  service_visit_def_1596  1
    service_2_6_2  free_load_conservation_1597  1
    service_2_6_3  unique_nonzero_owner_380  1
    service_2_6_3  service_visit_def_1596  1
    service_2_6_3  free_load_conservation_1597  2
    service_2_6_4  unique_nonzero_owner_381  1
    service_2_6_4  service_visit_def_1596  1
    service_2_6_4  free_load_conservation_1597  3
    service_2_6_5  unique_nonzero_owner_382  1
    service_2_6_5  service_visit_def_1596  1
    service_2_6_5  free_load_conservation_1597  4
    service_2_6_6  unique_nonzero_owner_383  1
    service_2_6_6  service_visit_def_1596  1
    service_2_6_6  free_load_conservation_1597  5
    service_2_6_7  unique_nonzero_owner_384  1
    service_2_6_7  service_visit_def_1596  1
    service_2_6_7  free_load_conservation_1597  6
    service_2_6_8  unique_nonzero_owner_385  1
    service_2_6_8  service_visit_def_1596  1
    service_2_6_8  free_load_conservation_1597  7
    service_2_6_9  unique_nonzero_owner_386  1
    service_2_6_9  service_visit_def_1596  1
    service_2_6_9  free_load_conservation_1597  8
    service_2_6_10  unique_nonzero_owner_387  1
    service_2_6_10  service_visit_def_1596  1
    service_2_6_10  free_load_conservation_1597  9
    service_0_14_0  unique_nonzero_owner_388  1
    service_0_14_0  service_visit_def_911  1
    service_0_14_0  free_load_conservation_912  -2
    service_0_14_0  original_T_including_depot_unload_936  240
    service_0_14_1  unique_nonzero_owner_389  1
    service_0_14_1  service_visit_def_911  1
    service_0_14_1  free_load_conservation_912  -1
    service_0_14_1  original_T_including_depot_unload_936  120
    service_0_14_3  unique_nonzero_owner_390  1
    service_0_14_3  service_visit_def_911  1
    service_0_14_3  free_load_conservation_912  1
    service_0_14_4  unique_nonzero_owner_391  1
    service_0_14_4  service_visit_def_911  1
    service_0_14_4  free_load_conservation_912  2
    service_0_14_5  unique_nonzero_owner_392  1
    service_0_14_5  service_visit_def_911  1
    service_0_14_5  free_load_conservation_912  3
    service_0_14_6  unique_nonzero_owner_393  1
    service_0_14_6  service_visit_def_911  1
    service_0_14_6  free_load_conservation_912  4
    service_0_14_7  unique_nonzero_owner_394  1
    service_0_14_7  service_visit_def_911  1
    service_0_14_7  free_load_conservation_912  5
    service_0_14_8  unique_nonzero_owner_395  1
    service_0_14_8  service_visit_def_911  1
    service_0_14_8  free_load_conservation_912  6
    service_0_14_9  unique_nonzero_owner_396  1
    service_0_14_9  service_visit_def_911  1
    service_0_14_9  free_load_conservation_912  7
    service_0_14_10  unique_nonzero_owner_397  1
    service_0_14_10  service_visit_def_911  1
    service_0_14_10  free_load_conservation_912  8
    service_0_14_11  unique_nonzero_owner_398  1
    service_0_14_11  service_visit_def_911  1
    service_0_14_11  free_load_conservation_912  9
    service_0_14_12  unique_nonzero_owner_399  1
    service_0_14_12  service_visit_def_911  1
    service_0_14_12  free_load_conservation_912  10
    service_0_14_13  unique_nonzero_owner_400  1
    service_0_14_13  service_visit_def_911  1
    service_0_14_13  free_load_conservation_912  11
    service_0_14_14  unique_nonzero_owner_401  1
    service_0_14_14  service_visit_def_911  1
    service_0_14_14  free_load_conservation_912  12
    service_0_14_15  unique_nonzero_owner_402  1
    service_0_14_15  service_visit_def_911  1
    service_0_14_15  free_load_conservation_912  13
    service_1_14_0  unique_nonzero_owner_388  1
    service_1_14_0  service_visit_def_1284  1
    service_1_14_0  free_load_conservation_1285  -2
    service_1_14_0  original_T_including_depot_unload_1307  240
    service_1_14_1  unique_nonzero_owner_389  1
    service_1_14_1  service_visit_def_1284  1
    service_1_14_1  free_load_conservation_1285  -1
    service_1_14_1  original_T_including_depot_unload_1307  120
    service_1_14_3  unique_nonzero_owner_390  1
    service_1_14_3  service_visit_def_1284  1
    service_1_14_3  free_load_conservation_1285  1
    service_1_14_4  unique_nonzero_owner_391  1
    service_1_14_4  service_visit_def_1284  1
    service_1_14_4  free_load_conservation_1285  2
    service_1_14_5  unique_nonzero_owner_392  1
    service_1_14_5  service_visit_def_1284  1
    service_1_14_5  free_load_conservation_1285  3
    service_1_14_6  unique_nonzero_owner_393  1
    service_1_14_6  service_visit_def_1284  1
    service_1_14_6  free_load_conservation_1285  4
    service_1_14_7  unique_nonzero_owner_394  1
    service_1_14_7  service_visit_def_1284  1
    service_1_14_7  free_load_conservation_1285  5
    service_1_14_8  unique_nonzero_owner_395  1
    service_1_14_8  service_visit_def_1284  1
    service_1_14_8  free_load_conservation_1285  6
    service_1_14_9  unique_nonzero_owner_396  1
    service_1_14_9  service_visit_def_1284  1
    service_1_14_9  free_load_conservation_1285  7
    service_1_14_10  unique_nonzero_owner_397  1
    service_1_14_10  service_visit_def_1284  1
    service_1_14_10  free_load_conservation_1285  8
    service_1_14_11  unique_nonzero_owner_398  1
    service_1_14_11  service_visit_def_1284  1
    service_1_14_11  free_load_conservation_1285  9
    service_1_14_12  unique_nonzero_owner_399  1
    service_1_14_12  service_visit_def_1284  1
    service_1_14_12  free_load_conservation_1285  10
    service_1_14_13  unique_nonzero_owner_400  1
    service_1_14_13  service_visit_def_1284  1
    service_1_14_13  free_load_conservation_1285  11
    service_1_14_14  unique_nonzero_owner_401  1
    service_1_14_14  service_visit_def_1284  1
    service_1_14_14  free_load_conservation_1285  12
    service_1_14_15  unique_nonzero_owner_402  1
    service_1_14_15  service_visit_def_1284  1
    service_1_14_15  free_load_conservation_1285  13
    service_2_14_0  unique_nonzero_owner_388  1
    service_2_14_0  service_visit_def_1602  1
    service_2_14_0  free_load_conservation_1603  -2
    service_2_14_0  original_T_including_depot_unload_1624  240
    service_2_14_1  unique_nonzero_owner_389  1
    service_2_14_1  service_visit_def_1602  1
    service_2_14_1  free_load_conservation_1603  -1
    service_2_14_1  original_T_including_depot_unload_1624  120
    service_2_14_3  unique_nonzero_owner_390  1
    service_2_14_3  service_visit_def_1602  1
    service_2_14_3  free_load_conservation_1603  1
    service_2_14_4  unique_nonzero_owner_391  1
    service_2_14_4  service_visit_def_1602  1
    service_2_14_4  free_load_conservation_1603  2
    service_2_14_5  unique_nonzero_owner_392  1
    service_2_14_5  service_visit_def_1602  1
    service_2_14_5  free_load_conservation_1603  3
    service_2_14_6  unique_nonzero_owner_393  1
    service_2_14_6  service_visit_def_1602  1
    service_2_14_6  free_load_conservation_1603  4
    service_2_14_7  unique_nonzero_owner_394  1
    service_2_14_7  service_visit_def_1602  1
    service_2_14_7  free_load_conservation_1603  5
    service_2_14_8  unique_nonzero_owner_395  1
    service_2_14_8  service_visit_def_1602  1
    service_2_14_8  free_load_conservation_1603  6
    service_2_14_9  unique_nonzero_owner_396  1
    service_2_14_9  service_visit_def_1602  1
    service_2_14_9  free_load_conservation_1603  7
    service_2_14_10  unique_nonzero_owner_397  1
    service_2_14_10  service_visit_def_1602  1
    service_2_14_10  free_load_conservation_1603  8
    service_2_14_11  unique_nonzero_owner_398  1
    service_2_14_11  service_visit_def_1602  1
    service_2_14_11  free_load_conservation_1603  9
    service_2_14_12  unique_nonzero_owner_399  1
    service_2_14_12  service_visit_def_1602  1
    service_2_14_12  free_load_conservation_1603  10
    service_2_14_13  unique_nonzero_owner_400  1
    service_2_14_13  service_visit_def_1602  1
    service_2_14_13  free_load_conservation_1603  11
    service_2_14_14  unique_nonzero_owner_401  1
    service_2_14_14  service_visit_def_1602  1
    service_2_14_14  free_load_conservation_1603  12
    service_2_14_15  unique_nonzero_owner_402  1
    service_2_14_15  service_visit_def_1602  1
    service_2_14_15  free_load_conservation_1603  13
    service_0_15_0  unique_nonzero_owner_403  1
    service_0_15_0  service_visit_def_917  1
    service_0_15_0  free_load_conservation_918  -3
    service_0_15_0  original_T_including_depot_unload_936  360
    service_0_15_1  unique_nonzero_owner_404  1
    service_0_15_1  service_visit_def_917  1
    service_0_15_1  free_load_conservation_918  -2
    service_0_15_1  original_T_including_depot_unload_936  240
    service_0_15_2  unique_nonzero_owner_405  1
    service_0_15_2  service_visit_def_917  1
    service_0_15_2  free_load_conservation_918  -1
    service_0_15_2  original_T_including_depot_unload_936  120
    service_0_15_4  unique_nonzero_owner_406  1
    service_0_15_4  service_visit_def_917  1
    service_0_15_4  free_load_conservation_918  1
    service_0_15_5  unique_nonzero_owner_407  1
    service_0_15_5  service_visit_def_917  1
    service_0_15_5  free_load_conservation_918  2
    service_0_15_6  unique_nonzero_owner_408  1
    service_0_15_6  service_visit_def_917  1
    service_0_15_6  free_load_conservation_918  3
    service_0_15_7  unique_nonzero_owner_409  1
    service_0_15_7  service_visit_def_917  1
    service_0_15_7  free_load_conservation_918  4
    service_0_15_8  unique_nonzero_owner_410  1
    service_0_15_8  service_visit_def_917  1
    service_0_15_8  free_load_conservation_918  5
    service_0_15_9  unique_nonzero_owner_411  1
    service_0_15_9  service_visit_def_917  1
    service_0_15_9  free_load_conservation_918  6
    service_0_15_10  unique_nonzero_owner_412  1
    service_0_15_10  service_visit_def_917  1
    service_0_15_10  free_load_conservation_918  7
    service_0_15_11  unique_nonzero_owner_413  1
    service_0_15_11  service_visit_def_917  1
    service_0_15_11  free_load_conservation_918  8
    service_0_15_12  unique_nonzero_owner_414  1
    service_0_15_12  service_visit_def_917  1
    service_0_15_12  free_load_conservation_918  9
    service_0_15_13  unique_nonzero_owner_415  1
    service_0_15_13  service_visit_def_917  1
    service_0_15_13  free_load_conservation_918  10
    service_0_15_14  unique_nonzero_owner_416  1
    service_0_15_14  service_visit_def_917  1
    service_0_15_14  free_load_conservation_918  11
    service_0_15_15  unique_nonzero_owner_417  1
    service_0_15_15  service_visit_def_917  1
    service_0_15_15  free_load_conservation_918  12
    service_0_15_16  unique_nonzero_owner_418  1
    service_0_15_16  service_visit_def_917  1
    service_0_15_16  free_load_conservation_918  13
    service_1_15_0  unique_nonzero_owner_403  1
    service_1_15_0  service_visit_def_1290  1
    service_1_15_0  free_load_conservation_1291  -3
    service_1_15_0  original_T_including_depot_unload_1307  360
    service_1_15_1  unique_nonzero_owner_404  1
    service_1_15_1  service_visit_def_1290  1
    service_1_15_1  free_load_conservation_1291  -2
    service_1_15_1  original_T_including_depot_unload_1307  240
    service_1_15_2  unique_nonzero_owner_405  1
    service_1_15_2  service_visit_def_1290  1
    service_1_15_2  free_load_conservation_1291  -1
    service_1_15_2  original_T_including_depot_unload_1307  120
    service_1_15_4  unique_nonzero_owner_406  1
    service_1_15_4  service_visit_def_1290  1
    service_1_15_4  free_load_conservation_1291  1
    service_1_15_5  unique_nonzero_owner_407  1
    service_1_15_5  service_visit_def_1290  1
    service_1_15_5  free_load_conservation_1291  2
    service_1_15_6  unique_nonzero_owner_408  1
    service_1_15_6  service_visit_def_1290  1
    service_1_15_6  free_load_conservation_1291  3
    service_1_15_7  unique_nonzero_owner_409  1
    service_1_15_7  service_visit_def_1290  1
    service_1_15_7  free_load_conservation_1291  4
    service_1_15_8  unique_nonzero_owner_410  1
    service_1_15_8  service_visit_def_1290  1
    service_1_15_8  free_load_conservation_1291  5
    service_1_15_9  unique_nonzero_owner_411  1
    service_1_15_9  service_visit_def_1290  1
    service_1_15_9  free_load_conservation_1291  6
    service_1_15_10  unique_nonzero_owner_412  1
    service_1_15_10  service_visit_def_1290  1
    service_1_15_10  free_load_conservation_1291  7
    service_1_15_11  unique_nonzero_owner_413  1
    service_1_15_11  service_visit_def_1290  1
    service_1_15_11  free_load_conservation_1291  8
    service_1_15_12  unique_nonzero_owner_414  1
    service_1_15_12  service_visit_def_1290  1
    service_1_15_12  free_load_conservation_1291  9
    service_1_15_13  unique_nonzero_owner_415  1
    service_1_15_13  service_visit_def_1290  1
    service_1_15_13  free_load_conservation_1291  10
    service_1_15_14  unique_nonzero_owner_416  1
    service_1_15_14  service_visit_def_1290  1
    service_1_15_14  free_load_conservation_1291  11
    service_1_15_15  unique_nonzero_owner_417  1
    service_1_15_15  service_visit_def_1290  1
    service_1_15_15  free_load_conservation_1291  12
    service_1_15_16  unique_nonzero_owner_418  1
    service_1_15_16  service_visit_def_1290  1
    service_1_15_16  free_load_conservation_1291  13
    service_2_15_0  unique_nonzero_owner_403  1
    service_2_15_0  service_visit_def_1608  1
    service_2_15_0  free_load_conservation_1609  -3
    service_2_15_0  original_T_including_depot_unload_1624  360
    service_2_15_1  unique_nonzero_owner_404  1
    service_2_15_1  service_visit_def_1608  1
    service_2_15_1  free_load_conservation_1609  -2
    service_2_15_1  original_T_including_depot_unload_1624  240
    service_2_15_2  unique_nonzero_owner_405  1
    service_2_15_2  service_visit_def_1608  1
    service_2_15_2  free_load_conservation_1609  -1
    service_2_15_2  original_T_including_depot_unload_1624  120
    service_2_15_4  unique_nonzero_owner_406  1
    service_2_15_4  service_visit_def_1608  1
    service_2_15_4  free_load_conservation_1609  1
    service_2_15_5  unique_nonzero_owner_407  1
    service_2_15_5  service_visit_def_1608  1
    service_2_15_5  free_load_conservation_1609  2
    service_2_15_6  unique_nonzero_owner_408  1
    service_2_15_6  service_visit_def_1608  1
    service_2_15_6  free_load_conservation_1609  3
    service_2_15_7  unique_nonzero_owner_409  1
    service_2_15_7  service_visit_def_1608  1
    service_2_15_7  free_load_conservation_1609  4
    service_2_15_8  unique_nonzero_owner_410  1
    service_2_15_8  service_visit_def_1608  1
    service_2_15_8  free_load_conservation_1609  5
    service_2_15_9  unique_nonzero_owner_411  1
    service_2_15_9  service_visit_def_1608  1
    service_2_15_9  free_load_conservation_1609  6
    service_2_15_10  unique_nonzero_owner_412  1
    service_2_15_10  service_visit_def_1608  1
    service_2_15_10  free_load_conservation_1609  7
    service_2_15_11  unique_nonzero_owner_413  1
    service_2_15_11  service_visit_def_1608  1
    service_2_15_11  free_load_conservation_1609  8
    service_2_15_12  unique_nonzero_owner_414  1
    service_2_15_12  service_visit_def_1608  1
    service_2_15_12  free_load_conservation_1609  9
    service_2_15_13  unique_nonzero_owner_415  1
    service_2_15_13  service_visit_def_1608  1
    service_2_15_13  free_load_conservation_1609  10
    service_2_15_14  unique_nonzero_owner_416  1
    service_2_15_14  service_visit_def_1608  1
    service_2_15_14  free_load_conservation_1609  11
    service_2_15_15  unique_nonzero_owner_417  1
    service_2_15_15  service_visit_def_1608  1
    service_2_15_15  free_load_conservation_1609  12
    service_2_15_16  unique_nonzero_owner_418  1
    service_2_15_16  service_visit_def_1608  1
    service_2_15_16  free_load_conservation_1609  13
    service_0_2_1  unique_nonzero_owner_419  1
    service_0_2_1  service_visit_def_923  1
    service_0_2_1  free_load_conservation_924  1
    service_0_2_2  unique_nonzero_owner_420  1
    service_0_2_2  service_visit_def_923  1
    service_0_2_2  free_load_conservation_924  2
    service_0_2_3  unique_nonzero_owner_421  1
    service_0_2_3  service_visit_def_923  1
    service_0_2_3  free_load_conservation_924  3
    service_0_2_4  unique_nonzero_owner_422  1
    service_0_2_4  service_visit_def_923  1
    service_0_2_4  free_load_conservation_924  4
    service_0_2_5  unique_nonzero_owner_423  1
    service_0_2_5  service_visit_def_923  1
    service_0_2_5  free_load_conservation_924  5
    service_0_2_6  unique_nonzero_owner_424  1
    service_0_2_6  service_visit_def_923  1
    service_0_2_6  free_load_conservation_924  6
    service_0_2_7  unique_nonzero_owner_425  1
    service_0_2_7  service_visit_def_923  1
    service_0_2_7  free_load_conservation_924  7
    service_0_2_8  unique_nonzero_owner_426  1
    service_0_2_8  service_visit_def_923  1
    service_0_2_8  free_load_conservation_924  8
    service_0_2_9  unique_nonzero_owner_427  1
    service_0_2_9  service_visit_def_923  1
    service_0_2_9  free_load_conservation_924  9
    service_0_2_10  unique_nonzero_owner_428  1
    service_0_2_10  service_visit_def_923  1
    service_0_2_10  free_load_conservation_924  10
    service_0_2_11  unique_nonzero_owner_429  1
    service_0_2_11  service_visit_def_923  1
    service_0_2_11  free_load_conservation_924  11
    service_0_2_12  unique_nonzero_owner_430  1
    service_0_2_12  service_visit_def_923  1
    service_0_2_12  free_load_conservation_924  12
    service_0_2_13  unique_nonzero_owner_431  1
    service_0_2_13  service_visit_def_923  1
    service_0_2_13  free_load_conservation_924  13
    service_0_2_14  unique_nonzero_owner_432  1
    service_0_2_14  service_visit_def_923  1
    service_0_2_14  free_load_conservation_924  14
    service_0_2_15  unique_nonzero_owner_433  1
    service_0_2_15  service_visit_def_923  1
    service_0_2_15  free_load_conservation_924  15
    service_1_2_1  unique_nonzero_owner_419  1
    service_1_2_1  service_visit_def_1296  1
    service_1_2_1  free_load_conservation_1297  1
    service_1_2_2  unique_nonzero_owner_420  1
    service_1_2_2  service_visit_def_1296  1
    service_1_2_2  free_load_conservation_1297  2
    service_1_2_3  unique_nonzero_owner_421  1
    service_1_2_3  service_visit_def_1296  1
    service_1_2_3  free_load_conservation_1297  3
    service_1_2_4  unique_nonzero_owner_422  1
    service_1_2_4  service_visit_def_1296  1
    service_1_2_4  free_load_conservation_1297  4
    service_1_2_5  unique_nonzero_owner_423  1
    service_1_2_5  service_visit_def_1296  1
    service_1_2_5  free_load_conservation_1297  5
    service_1_2_6  unique_nonzero_owner_424  1
    service_1_2_6  service_visit_def_1296  1
    service_1_2_6  free_load_conservation_1297  6
    service_1_2_7  unique_nonzero_owner_425  1
    service_1_2_7  service_visit_def_1296  1
    service_1_2_7  free_load_conservation_1297  7
    service_1_2_8  unique_nonzero_owner_426  1
    service_1_2_8  service_visit_def_1296  1
    service_1_2_8  free_load_conservation_1297  8
    service_1_2_9  unique_nonzero_owner_427  1
    service_1_2_9  service_visit_def_1296  1
    service_1_2_9  free_load_conservation_1297  9
    service_1_2_10  unique_nonzero_owner_428  1
    service_1_2_10  service_visit_def_1296  1
    service_1_2_10  free_load_conservation_1297  10
    service_1_2_11  unique_nonzero_owner_429  1
    service_1_2_11  service_visit_def_1296  1
    service_1_2_11  free_load_conservation_1297  11
    service_1_2_12  unique_nonzero_owner_430  1
    service_1_2_12  service_visit_def_1296  1
    service_1_2_12  free_load_conservation_1297  12
    service_1_2_13  unique_nonzero_owner_431  1
    service_1_2_13  service_visit_def_1296  1
    service_1_2_13  free_load_conservation_1297  13
    service_1_2_14  unique_nonzero_owner_432  1
    service_1_2_14  service_visit_def_1296  1
    service_1_2_14  free_load_conservation_1297  14
    service_1_2_15  unique_nonzero_owner_433  1
    service_1_2_15  service_visit_def_1296  1
    service_1_2_15  free_load_conservation_1297  15
    service_2_2_1  unique_nonzero_owner_419  1
    service_2_2_1  service_visit_def_1614  1
    service_2_2_1  free_load_conservation_1615  1
    service_2_2_2  unique_nonzero_owner_420  1
    service_2_2_2  service_visit_def_1614  1
    service_2_2_2  free_load_conservation_1615  2
    service_2_2_3  unique_nonzero_owner_421  1
    service_2_2_3  service_visit_def_1614  1
    service_2_2_3  free_load_conservation_1615  3
    service_2_2_4  unique_nonzero_owner_422  1
    service_2_2_4  service_visit_def_1614  1
    service_2_2_4  free_load_conservation_1615  4
    service_2_2_5  unique_nonzero_owner_423  1
    service_2_2_5  service_visit_def_1614  1
    service_2_2_5  free_load_conservation_1615  5
    service_2_2_6  unique_nonzero_owner_424  1
    service_2_2_6  service_visit_def_1614  1
    service_2_2_6  free_load_conservation_1615  6
    service_2_2_7  unique_nonzero_owner_425  1
    service_2_2_7  service_visit_def_1614  1
    service_2_2_7  free_load_conservation_1615  7
    service_2_2_8  unique_nonzero_owner_426  1
    service_2_2_8  service_visit_def_1614  1
    service_2_2_8  free_load_conservation_1615  8
    service_2_2_9  unique_nonzero_owner_427  1
    service_2_2_9  service_visit_def_1614  1
    service_2_2_9  free_load_conservation_1615  9
    service_2_2_10  unique_nonzero_owner_428  1
    service_2_2_10  service_visit_def_1614  1
    service_2_2_10  free_load_conservation_1615  10
    service_2_2_11  unique_nonzero_owner_429  1
    service_2_2_11  service_visit_def_1614  1
    service_2_2_11  free_load_conservation_1615  11
    service_2_2_12  unique_nonzero_owner_430  1
    service_2_2_12  service_visit_def_1614  1
    service_2_2_12  free_load_conservation_1615  12
    service_2_2_13  unique_nonzero_owner_431  1
    service_2_2_13  service_visit_def_1614  1
    service_2_2_13  free_load_conservation_1615  13
    service_2_2_14  unique_nonzero_owner_432  1
    service_2_2_14  service_visit_def_1614  1
    service_2_2_14  free_load_conservation_1615  14
    service_2_2_15  unique_nonzero_owner_433  1
    service_2_2_15  service_visit_def_1614  1
    service_2_2_15  free_load_conservation_1615  15
    service_0_9_0  unique_nonzero_owner_434  1
    service_0_9_0  service_visit_def_929  1
    service_0_9_0  free_load_conservation_930  -8
    service_0_9_0  original_T_including_depot_unload_936  960
    service_0_9_1  unique_nonzero_owner_435  1
    service_0_9_1  service_visit_def_929  1
    service_0_9_1  free_load_conservation_930  -7
    service_0_9_1  original_T_including_depot_unload_936  840
    service_0_9_2  unique_nonzero_owner_436  1
    service_0_9_2  service_visit_def_929  1
    service_0_9_2  free_load_conservation_930  -6
    service_0_9_2  original_T_including_depot_unload_936  720
    service_0_9_3  unique_nonzero_owner_437  1
    service_0_9_3  service_visit_def_929  1
    service_0_9_3  free_load_conservation_930  -5
    service_0_9_3  original_T_including_depot_unload_936  600
    service_0_9_4  unique_nonzero_owner_438  1
    service_0_9_4  service_visit_def_929  1
    service_0_9_4  free_load_conservation_930  -4
    service_0_9_4  original_T_including_depot_unload_936  480
    service_0_9_5  unique_nonzero_owner_439  1
    service_0_9_5  service_visit_def_929  1
    service_0_9_5  free_load_conservation_930  -3
    service_0_9_5  original_T_including_depot_unload_936  360
    service_0_9_6  unique_nonzero_owner_440  1
    service_0_9_6  service_visit_def_929  1
    service_0_9_6  free_load_conservation_930  -2
    service_0_9_6  original_T_including_depot_unload_936  240
    service_0_9_7  unique_nonzero_owner_441  1
    service_0_9_7  service_visit_def_929  1
    service_0_9_7  free_load_conservation_930  -1
    service_0_9_7  original_T_including_depot_unload_936  120
    service_0_9_9  unique_nonzero_owner_442  1
    service_0_9_9  service_visit_def_929  1
    service_0_9_9  free_load_conservation_930  1
    service_0_9_10  unique_nonzero_owner_443  1
    service_0_9_10  service_visit_def_929  1
    service_0_9_10  free_load_conservation_930  2
    service_0_9_11  unique_nonzero_owner_444  1
    service_0_9_11  service_visit_def_929  1
    service_0_9_11  free_load_conservation_930  3
    service_0_9_12  unique_nonzero_owner_445  1
    service_0_9_12  service_visit_def_929  1
    service_0_9_12  free_load_conservation_930  4
    service_1_9_0  unique_nonzero_owner_434  1
    service_1_9_0  service_visit_def_1302  1
    service_1_9_0  free_load_conservation_1303  -8
    service_1_9_0  original_T_including_depot_unload_1307  960
    service_1_9_1  unique_nonzero_owner_435  1
    service_1_9_1  service_visit_def_1302  1
    service_1_9_1  free_load_conservation_1303  -7
    service_1_9_1  original_T_including_depot_unload_1307  840
    service_1_9_2  unique_nonzero_owner_436  1
    service_1_9_2  service_visit_def_1302  1
    service_1_9_2  free_load_conservation_1303  -6
    service_1_9_2  original_T_including_depot_unload_1307  720
    service_1_9_3  unique_nonzero_owner_437  1
    service_1_9_3  service_visit_def_1302  1
    service_1_9_3  free_load_conservation_1303  -5
    service_1_9_3  original_T_including_depot_unload_1307  600
    service_1_9_4  unique_nonzero_owner_438  1
    service_1_9_4  service_visit_def_1302  1
    service_1_9_4  free_load_conservation_1303  -4
    service_1_9_4  original_T_including_depot_unload_1307  480
    service_1_9_5  unique_nonzero_owner_439  1
    service_1_9_5  service_visit_def_1302  1
    service_1_9_5  free_load_conservation_1303  -3
    service_1_9_5  original_T_including_depot_unload_1307  360
    service_1_9_6  unique_nonzero_owner_440  1
    service_1_9_6  service_visit_def_1302  1
    service_1_9_6  free_load_conservation_1303  -2
    service_1_9_6  original_T_including_depot_unload_1307  240
    service_1_9_7  unique_nonzero_owner_441  1
    service_1_9_7  service_visit_def_1302  1
    service_1_9_7  free_load_conservation_1303  -1
    service_1_9_7  original_T_including_depot_unload_1307  120
    service_1_9_9  unique_nonzero_owner_442  1
    service_1_9_9  service_visit_def_1302  1
    service_1_9_9  free_load_conservation_1303  1
    service_1_9_10  unique_nonzero_owner_443  1
    service_1_9_10  service_visit_def_1302  1
    service_1_9_10  free_load_conservation_1303  2
    service_1_9_11  unique_nonzero_owner_444  1
    service_1_9_11  service_visit_def_1302  1
    service_1_9_11  free_load_conservation_1303  3
    service_1_9_12  unique_nonzero_owner_445  1
    service_1_9_12  service_visit_def_1302  1
    service_1_9_12  free_load_conservation_1303  4
    service_2_9_0  unique_nonzero_owner_434  1
    service_2_9_0  service_visit_def_1620  1
    service_2_9_0  free_load_conservation_1621  -8
    service_2_9_0  original_T_including_depot_unload_1624  960
    service_2_9_1  unique_nonzero_owner_435  1
    service_2_9_1  service_visit_def_1620  1
    service_2_9_1  free_load_conservation_1621  -7
    service_2_9_1  original_T_including_depot_unload_1624  840
    service_2_9_2  unique_nonzero_owner_436  1
    service_2_9_2  service_visit_def_1620  1
    service_2_9_2  free_load_conservation_1621  -6
    service_2_9_2  original_T_including_depot_unload_1624  720
    service_2_9_3  unique_nonzero_owner_437  1
    service_2_9_3  service_visit_def_1620  1
    service_2_9_3  free_load_conservation_1621  -5
    service_2_9_3  original_T_including_depot_unload_1624  600
    service_2_9_4  unique_nonzero_owner_438  1
    service_2_9_4  service_visit_def_1620  1
    service_2_9_4  free_load_conservation_1621  -4
    service_2_9_4  original_T_including_depot_unload_1624  480
    service_2_9_5  unique_nonzero_owner_439  1
    service_2_9_5  service_visit_def_1620  1
    service_2_9_5  free_load_conservation_1621  -3
    service_2_9_5  original_T_including_depot_unload_1624  360
    service_2_9_6  unique_nonzero_owner_440  1
    service_2_9_6  service_visit_def_1620  1
    service_2_9_6  free_load_conservation_1621  -2
    service_2_9_6  original_T_including_depot_unload_1624  240
    service_2_9_7  unique_nonzero_owner_441  1
    service_2_9_7  service_visit_def_1620  1
    service_2_9_7  free_load_conservation_1621  -1
    service_2_9_7  original_T_including_depot_unload_1624  120
    service_2_9_9  unique_nonzero_owner_442  1
    service_2_9_9  service_visit_def_1620  1
    service_2_9_9  free_load_conservation_1621  1
    service_2_9_10  unique_nonzero_owner_443  1
    service_2_9_10  service_visit_def_1620  1
    service_2_9_10  free_load_conservation_1621  2
    service_2_9_11  unique_nonzero_owner_444  1
    service_2_9_11  service_visit_def_1620  1
    service_2_9_11  free_load_conservation_1621  3
    service_2_9_12  unique_nonzero_owner_445  1
    service_2_9_12  service_visit_def_1620  1
    service_2_9_12  free_load_conservation_1621  4
    MARKER    'MARKER'                 'INTEND'
    visit_0_1  out_degree_841  -1
    visit_0_1  in_degree_842  -1
    visit_0_1  order_active_lb_843  -1
    visit_0_1  order_active_ub_844  -14
    order_0_1  connected_order_arc_463  -1
    order_0_1  connected_order_arc_465  -1
    order_0_1  connected_order_arc_467  -1
    order_0_1  connected_order_arc_469  -1
    order_0_1  connected_order_arc_471  -1
    order_0_1  connected_order_arc_473  -1
    order_0_1  connected_order_arc_475  -1
    order_0_1  connected_order_arc_477  -1
    order_0_1  connected_order_arc_479  -1
    order_0_1  connected_order_arc_481  -1
    order_0_1  connected_order_arc_483  -1
    order_0_1  connected_order_arc_485  -1
    order_0_1  connected_order_arc_487  -1
    order_0_1  connected_order_arc_490  1
    order_0_1  connected_order_arc_517  1
    order_0_1  connected_order_arc_544  1
    order_0_1  connected_order_arc_571  1
    order_0_1  connected_order_arc_598  1
    order_0_1  connected_order_arc_625  1
    order_0_1  connected_order_arc_652  1
    order_0_1  connected_order_arc_679  1
    order_0_1  connected_order_arc_706  1
    order_0_1  connected_order_arc_733  1
    order_0_1  connected_order_arc_760  1
    order_0_1  connected_order_arc_787  1
    order_0_1  connected_order_arc_814  1
    order_0_1  order_active_lb_843  1
    order_0_1  order_active_ub_844  1
    order_0_1  fixed_segment_relative_order_931  -1
    visit_0_2  out_degree_848  -1
    visit_0_2  in_degree_849  -1
    visit_0_2  order_active_lb_850  -1
    visit_0_2  order_active_ub_851  -14
    order_0_2  connected_order_arc_463  1
    order_0_2  connected_order_arc_490  -1
    order_0_2  connected_order_arc_492  -1
    order_0_2  connected_order_arc_494  -1
    order_0_2  connected_order_arc_496  -1
    order_0_2  connected_order_arc_498  -1
    order_0_2  connected_order_arc_500  -1
    order_0_2  connected_order_arc_502  -1
    order_0_2  connected_order_arc_504  -1
    order_0_2  connected_order_arc_506  -1
    order_0_2  connected_order_arc_508  -1
    order_0_2  connected_order_arc_510  -1
    order_0_2  connected_order_arc_512  -1
    order_0_2  connected_order_arc_514  -1
    order_0_2  connected_order_arc_519  1
    order_0_2  connected_order_arc_546  1
    order_0_2  connected_order_arc_573  1
    order_0_2  connected_order_arc_600  1
    order_0_2  connected_order_arc_627  1
    order_0_2  connected_order_arc_654  1
    order_0_2  connected_order_arc_681  1
    order_0_2  connected_order_arc_708  1
    order_0_2  connected_order_arc_735  1
    order_0_2  connected_order_arc_762  1
    order_0_2  connected_order_arc_789  1
    order_0_2  connected_order_arc_816  1
    order_0_2  order_active_lb_850  1
    order_0_2  order_active_ub_851  1
    order_0_2  fixed_segment_relative_order_931  1
    order_0_2  fixed_segment_relative_order_932  -1
    visit_0_3  out_degree_855  -1
    visit_0_3  in_degree_856  -1
    visit_0_3  order_active_lb_857  -1
    visit_0_3  order_active_ub_858  -14
    order_0_3  connected_order_arc_465  1
    order_0_3  connected_order_arc_492  1
    order_0_3  connected_order_arc_517  -1
    order_0_3  connected_order_arc_519  -1
    order_0_3  connected_order_arc_521  -1
    order_0_3  connected_order_arc_523  -1
    order_0_3  connected_order_arc_525  -1
    order_0_3  connected_order_arc_527  -1
    order_0_3  connected_order_arc_529  -1
    order_0_3  connected_order_arc_531  -1
    order_0_3  connected_order_arc_533  -1
    order_0_3  connected_order_arc_535  -1
    order_0_3  connected_order_arc_537  -1
    order_0_3  connected_order_arc_539  -1
    order_0_3  connected_order_arc_541  -1
    order_0_3  connected_order_arc_548  1
    order_0_3  connected_order_arc_575  1
    order_0_3  connected_order_arc_602  1
    order_0_3  connected_order_arc_629  1
    order_0_3  connected_order_arc_656  1
    order_0_3  connected_order_arc_683  1
    order_0_3  connected_order_arc_710  1
    order_0_3  connected_order_arc_737  1
    order_0_3  connected_order_arc_764  1
    order_0_3  connected_order_arc_791  1
    order_0_3  connected_order_arc_818  1
    order_0_3  order_active_lb_857  1
    order_0_3  order_active_ub_858  1
    order_0_3  fixed_segment_relative_order_932  1
    order_0_3  fixed_segment_relative_order_933  -1
    visit_0_4  out_degree_862  -1
    visit_0_4  in_degree_863  -1
    visit_0_4  order_active_lb_864  -1
    visit_0_4  order_active_ub_865  -14
    order_0_4  connected_order_arc_467  1
    order_0_4  connected_order_arc_494  1
    order_0_4  connected_order_arc_521  1
    order_0_4  connected_order_arc_544  -1
    order_0_4  connected_order_arc_546  -1
    order_0_4  connected_order_arc_548  -1
    order_0_4  connected_order_arc_550  -1
    order_0_4  connected_order_arc_552  -1
    order_0_4  connected_order_arc_554  -1
    order_0_4  connected_order_arc_556  -1
    order_0_4  connected_order_arc_558  -1
    order_0_4  connected_order_arc_560  -1
    order_0_4  connected_order_arc_562  -1
    order_0_4  connected_order_arc_564  -1
    order_0_4  connected_order_arc_566  -1
    order_0_4  connected_order_arc_568  -1
    order_0_4  connected_order_arc_577  1
    order_0_4  connected_order_arc_604  1
    order_0_4  connected_order_arc_631  1
    order_0_4  connected_order_arc_658  1
    order_0_4  connected_order_arc_685  1
    order_0_4  connected_order_arc_712  1
    order_0_4  connected_order_arc_739  1
    order_0_4  connected_order_arc_766  1
    order_0_4  connected_order_arc_793  1
    order_0_4  connected_order_arc_820  1
    order_0_4  order_active_lb_864  1
    order_0_4  order_active_ub_865  1
    order_0_4  fixed_segment_relative_order_933  1
    order_0_4  fixed_segment_relative_order_934  -1
    visit_0_5  out_degree_869  -1
    visit_0_5  in_degree_870  -1
    visit_0_5  order_active_lb_871  -1
    visit_0_5  order_active_ub_872  -14
    order_0_5  connected_order_arc_469  1
    order_0_5  connected_order_arc_496  1
    order_0_5  connected_order_arc_523  1
    order_0_5  connected_order_arc_550  1
    order_0_5  connected_order_arc_571  -1
    order_0_5  connected_order_arc_573  -1
    order_0_5  connected_order_arc_575  -1
    order_0_5  connected_order_arc_577  -1
    order_0_5  connected_order_arc_579  -1
    order_0_5  connected_order_arc_581  -1
    order_0_5  connected_order_arc_583  -1
    order_0_5  connected_order_arc_585  -1
    order_0_5  connected_order_arc_587  -1
    order_0_5  connected_order_arc_589  -1
    order_0_5  connected_order_arc_591  -1
    order_0_5  connected_order_arc_593  -1
    order_0_5  connected_order_arc_595  -1
    order_0_5  connected_order_arc_606  1
    order_0_5  connected_order_arc_633  1
    order_0_5  connected_order_arc_660  1
    order_0_5  connected_order_arc_687  1
    order_0_5  connected_order_arc_714  1
    order_0_5  connected_order_arc_741  1
    order_0_5  connected_order_arc_768  1
    order_0_5  connected_order_arc_795  1
    order_0_5  connected_order_arc_822  1
    order_0_5  order_active_lb_871  1
    order_0_5  order_active_ub_872  1
    order_0_5  fixed_segment_relative_order_934  1
    order_0_5  fixed_segment_relative_order_935  -1
    visit_0_6  out_degree_876  -1
    visit_0_6  in_degree_877  -1
    visit_0_6  order_active_lb_878  -1
    visit_0_6  order_active_ub_879  -14
    order_0_6  connected_order_arc_471  1
    order_0_6  connected_order_arc_498  1
    order_0_6  connected_order_arc_525  1
    order_0_6  connected_order_arc_552  1
    order_0_6  connected_order_arc_579  1
    order_0_6  connected_order_arc_598  -1
    order_0_6  connected_order_arc_600  -1
    order_0_6  connected_order_arc_602  -1
    order_0_6  connected_order_arc_604  -1
    order_0_6  connected_order_arc_606  -1
    order_0_6  connected_order_arc_608  -1
    order_0_6  connected_order_arc_610  -1
    order_0_6  connected_order_arc_612  -1
    order_0_6  connected_order_arc_614  -1
    order_0_6  connected_order_arc_616  -1
    order_0_6  connected_order_arc_618  -1
    order_0_6  connected_order_arc_620  -1
    order_0_6  connected_order_arc_622  -1
    order_0_6  connected_order_arc_635  1
    order_0_6  connected_order_arc_662  1
    order_0_6  connected_order_arc_689  1
    order_0_6  connected_order_arc_716  1
    order_0_6  connected_order_arc_743  1
    order_0_6  connected_order_arc_770  1
    order_0_6  connected_order_arc_797  1
    order_0_6  connected_order_arc_824  1
    order_0_6  order_active_lb_878  1
    order_0_6  order_active_ub_879  1
    order_0_6  fixed_segment_relative_order_935  1
    visit_0_14  out_degree_883  -1
    visit_0_14  in_degree_884  -1
    visit_0_14  order_active_lb_885  -1
    visit_0_14  order_active_ub_886  -14
    visit_0_14  service_visit_def_887  -1
    order_0_14  connected_order_arc_473  1
    order_0_14  connected_order_arc_500  1
    order_0_14  connected_order_arc_527  1
    order_0_14  connected_order_arc_554  1
    order_0_14  connected_order_arc_581  1
    order_0_14  connected_order_arc_608  1
    order_0_14  connected_order_arc_625  -1
    order_0_14  connected_order_arc_627  -1
    order_0_14  connected_order_arc_629  -1
    order_0_14  connected_order_arc_631  -1
    order_0_14  connected_order_arc_633  -1
    order_0_14  connected_order_arc_635  -1
    order_0_14  connected_order_arc_637  -1
    order_0_14  connected_order_arc_639  -1
    order_0_14  connected_order_arc_641  -1
    order_0_14  connected_order_arc_643  -1
    order_0_14  connected_order_arc_645  -1
    order_0_14  connected_order_arc_647  -1
    order_0_14  connected_order_arc_649  -1
    order_0_14  connected_order_arc_664  1
    order_0_14  connected_order_arc_691  1
    order_0_14  connected_order_arc_718  1
    order_0_14  connected_order_arc_745  1
    order_0_14  connected_order_arc_772  1
    order_0_14  connected_order_arc_799  1
    order_0_14  connected_order_arc_826  1
    order_0_14  order_active_lb_885  1
    order_0_14  order_active_ub_886  1
    visit_0_15  out_degree_889  -1
    visit_0_15  in_degree_890  -1
    visit_0_15  order_active_lb_891  -1
    visit_0_15  order_active_ub_892  -14
    visit_0_15  service_visit_def_893  -1
    order_0_15  connected_order_arc_475  1
    order_0_15  connected_order_arc_502  1
    order_0_15  connected_order_arc_529  1
    order_0_15  connected_order_arc_556  1
    order_0_15  connected_order_arc_583  1
    order_0_15  connected_order_arc_610  1
    order_0_15  connected_order_arc_637  1
    order_0_15  connected_order_arc_652  -1
    order_0_15  connected_order_arc_654  -1
    order_0_15  connected_order_arc_656  -1
    order_0_15  connected_order_arc_658  -1
    order_0_15  connected_order_arc_660  -1
    order_0_15  connected_order_arc_662  -1
    order_0_15  connected_order_arc_664  -1
    order_0_15  connected_order_arc_666  -1
    order_0_15  connected_order_arc_668  -1
    order_0_15  connected_order_arc_670  -1
    order_0_15  connected_order_arc_672  -1
    order_0_15  connected_order_arc_674  -1
    order_0_15  connected_order_arc_676  -1
    order_0_15  connected_order_arc_693  1
    order_0_15  connected_order_arc_720  1
    order_0_15  connected_order_arc_747  1
    order_0_15  connected_order_arc_774  1
    order_0_15  connected_order_arc_801  1
    order_0_15  connected_order_arc_828  1
    order_0_15  order_active_lb_891  1
    order_0_15  order_active_ub_892  1
    visit_0_16  out_degree_895  -1
    visit_0_16  in_degree_896  -1
    visit_0_16  order_active_lb_897  -1
    visit_0_16  order_active_ub_898  -14
    visit_0_16  service_visit_def_899  -1
    order_0_16  connected_order_arc_477  1
    order_0_16  connected_order_arc_504  1
    order_0_16  connected_order_arc_531  1
    order_0_16  connected_order_arc_558  1
    order_0_16  connected_order_arc_585  1
    order_0_16  connected_order_arc_612  1
    order_0_16  connected_order_arc_639  1
    order_0_16  connected_order_arc_666  1
    order_0_16  connected_order_arc_679  -1
    order_0_16  connected_order_arc_681  -1
    order_0_16  connected_order_arc_683  -1
    order_0_16  connected_order_arc_685  -1
    order_0_16  connected_order_arc_687  -1
    order_0_16  connected_order_arc_689  -1
    order_0_16  connected_order_arc_691  -1
    order_0_16  connected_order_arc_693  -1
    order_0_16  connected_order_arc_695  -1
    order_0_16  connected_order_arc_697  -1
    order_0_16  connected_order_arc_699  -1
    order_0_16  connected_order_arc_701  -1
    order_0_16  connected_order_arc_703  -1
    order_0_16  connected_order_arc_722  1
    order_0_16  connected_order_arc_749  1
    order_0_16  connected_order_arc_776  1
    order_0_16  connected_order_arc_803  1
    order_0_16  connected_order_arc_830  1
    order_0_16  order_active_lb_897  1
    order_0_16  order_active_ub_898  1
    visit_0_17  out_degree_901  -1
    visit_0_17  in_degree_902  -1
    visit_0_17  order_active_lb_903  -1
    visit_0_17  order_active_ub_904  -14
    visit_0_17  service_visit_def_905  -1
    order_0_17  connected_order_arc_479  1
    order_0_17  connected_order_arc_506  1
    order_0_17  connected_order_arc_533  1
    order_0_17  connected_order_arc_560  1
    order_0_17  connected_order_arc_587  1
    order_0_17  connected_order_arc_614  1
    order_0_17  connected_order_arc_641  1
    order_0_17  connected_order_arc_668  1
    order_0_17  connected_order_arc_695  1
    order_0_17  connected_order_arc_706  -1
    order_0_17  connected_order_arc_708  -1
    order_0_17  connected_order_arc_710  -1
    order_0_17  connected_order_arc_712  -1
    order_0_17  connected_order_arc_714  -1
    order_0_17  connected_order_arc_716  -1
    order_0_17  connected_order_arc_718  -1
    order_0_17  connected_order_arc_720  -1
    order_0_17  connected_order_arc_722  -1
    order_0_17  connected_order_arc_724  -1
    order_0_17  connected_order_arc_726  -1
    order_0_17  connected_order_arc_728  -1
    order_0_17  connected_order_arc_730  -1
    order_0_17  connected_order_arc_751  1
    order_0_17  connected_order_arc_778  1
    order_0_17  connected_order_arc_805  1
    order_0_17  connected_order_arc_832  1
    order_0_17  order_active_lb_903  1
    order_0_17  order_active_ub_904  1
    visit_0_18  out_degree_907  -1
    visit_0_18  in_degree_908  -1
    visit_0_18  order_active_lb_909  -1
    visit_0_18  order_active_ub_910  -14
    visit_0_18  service_visit_def_911  -1
    order_0_18  connected_order_arc_481  1
    order_0_18  connected_order_arc_508  1
    order_0_18  connected_order_arc_535  1
    order_0_18  connected_order_arc_562  1
    order_0_18  connected_order_arc_589  1
    order_0_18  connected_order_arc_616  1
    order_0_18  connected_order_arc_643  1
    order_0_18  connected_order_arc_670  1
    order_0_18  connected_order_arc_697  1
    order_0_18  connected_order_arc_724  1
    order_0_18  connected_order_arc_733  -1
    order_0_18  connected_order_arc_735  -1
    order_0_18  connected_order_arc_737  -1
    order_0_18  connected_order_arc_739  -1
    order_0_18  connected_order_arc_741  -1
    order_0_18  connected_order_arc_743  -1
    order_0_18  connected_order_arc_745  -1
    order_0_18  connected_order_arc_747  -1
    order_0_18  connected_order_arc_749  -1
    order_0_18  connected_order_arc_751  -1
    order_0_18  connected_order_arc_753  -1
    order_0_18  connected_order_arc_755  -1
    order_0_18  connected_order_arc_757  -1
    order_0_18  connected_order_arc_780  1
    order_0_18  connected_order_arc_807  1
    order_0_18  connected_order_arc_834  1
    order_0_18  order_active_lb_909  1
    order_0_18  order_active_ub_910  1
    visit_0_19  out_degree_913  -1
    visit_0_19  in_degree_914  -1
    visit_0_19  order_active_lb_915  -1
    visit_0_19  order_active_ub_916  -14
    visit_0_19  service_visit_def_917  -1
    order_0_19  connected_order_arc_483  1
    order_0_19  connected_order_arc_510  1
    order_0_19  connected_order_arc_537  1
    order_0_19  connected_order_arc_564  1
    order_0_19  connected_order_arc_591  1
    order_0_19  connected_order_arc_618  1
    order_0_19  connected_order_arc_645  1
    order_0_19  connected_order_arc_672  1
    order_0_19  connected_order_arc_699  1
    order_0_19  connected_order_arc_726  1
    order_0_19  connected_order_arc_753  1
    order_0_19  connected_order_arc_760  -1
    order_0_19  connected_order_arc_762  -1
    order_0_19  connected_order_arc_764  -1
    order_0_19  connected_order_arc_766  -1
    order_0_19  connected_order_arc_768  -1
    order_0_19  connected_order_arc_770  -1
    order_0_19  connected_order_arc_772  -1
    order_0_19  connected_order_arc_774  -1
    order_0_19  connected_order_arc_776  -1
    order_0_19  connected_order_arc_778  -1
    order_0_19  connected_order_arc_780  -1
    order_0_19  connected_order_arc_782  -1
    order_0_19  connected_order_arc_784  -1
    order_0_19  connected_order_arc_809  1
    order_0_19  connected_order_arc_836  1
    order_0_19  order_active_lb_915  1
    order_0_19  order_active_ub_916  1
    visit_0_20  out_degree_919  -1
    visit_0_20  in_degree_920  -1
    visit_0_20  order_active_lb_921  -1
    visit_0_20  order_active_ub_922  -14
    visit_0_20  service_visit_def_923  -1
    order_0_20  connected_order_arc_485  1
    order_0_20  connected_order_arc_512  1
    order_0_20  connected_order_arc_539  1
    order_0_20  connected_order_arc_566  1
    order_0_20  connected_order_arc_593  1
    order_0_20  connected_order_arc_620  1
    order_0_20  connected_order_arc_647  1
    order_0_20  connected_order_arc_674  1
    order_0_20  connected_order_arc_701  1
    order_0_20  connected_order_arc_728  1
    order_0_20  connected_order_arc_755  1
    order_0_20  connected_order_arc_782  1
    order_0_20  connected_order_arc_787  -1
    order_0_20  connected_order_arc_789  -1
    order_0_20  connected_order_arc_791  -1
    order_0_20  connected_order_arc_793  -1
    order_0_20  connected_order_arc_795  -1
    order_0_20  connected_order_arc_797  -1
    order_0_20  connected_order_arc_799  -1
    order_0_20  connected_order_arc_801  -1
    order_0_20  connected_order_arc_803  -1
    order_0_20  connected_order_arc_805  -1
    order_0_20  connected_order_arc_807  -1
    order_0_20  connected_order_arc_809  -1
    order_0_20  connected_order_arc_811  -1
    order_0_20  connected_order_arc_838  1
    order_0_20  order_active_lb_921  1
    order_0_20  order_active_ub_922  1
    visit_0_21  out_degree_925  -1
    visit_0_21  in_degree_926  -1
    visit_0_21  order_active_lb_927  -1
    visit_0_21  order_active_ub_928  -14
    visit_0_21  service_visit_def_929  -1
    order_0_21  connected_order_arc_487  1
    order_0_21  connected_order_arc_514  1
    order_0_21  connected_order_arc_541  1
    order_0_21  connected_order_arc_568  1
    order_0_21  connected_order_arc_595  1
    order_0_21  connected_order_arc_622  1
    order_0_21  connected_order_arc_649  1
    order_0_21  connected_order_arc_676  1
    order_0_21  connected_order_arc_703  1
    order_0_21  connected_order_arc_730  1
    order_0_21  connected_order_arc_757  1
    order_0_21  connected_order_arc_784  1
    order_0_21  connected_order_arc_811  1
    order_0_21  connected_order_arc_814  -1
    order_0_21  connected_order_arc_816  -1
    order_0_21  connected_order_arc_818  -1
    order_0_21  connected_order_arc_820  -1
    order_0_21  connected_order_arc_822  -1
    order_0_21  connected_order_arc_824  -1
    order_0_21  connected_order_arc_826  -1
    order_0_21  connected_order_arc_828  -1
    order_0_21  connected_order_arc_830  -1
    order_0_21  connected_order_arc_832  -1
    order_0_21  connected_order_arc_834  -1
    order_0_21  connected_order_arc_836  -1
    order_0_21  connected_order_arc_838  -1
    order_0_21  order_active_lb_927  1
    order_0_21  order_active_ub_928  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_0  arc_capacity_446  -20
    arc_0_0_0  depot_departure_or_bypass_839  1
    arc_0_0_0  depot_return_or_bypass_840  1
    MARKER    'MARKER'                 'INTEND'
    load_0_0_0  arc_capacity_446  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_1  arc_capacity_447  -20
    arc_0_0_1  depot_departure_or_bypass_839  1
    arc_0_0_1  in_degree_842  1
    arc_0_0_1  original_T_including_depot_unload_936  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_1  arc_capacity_447  1
    load_0_0_1  segment_load_conservation_845  -1
    load_0_0_1  segment_prefix_lb_846  1
    load_0_0_1  segment_prefix_ub_847  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_2  arc_capacity_448  -20
    arc_0_0_2  depot_departure_or_bypass_839  1
    arc_0_0_2  in_degree_849  1
    arc_0_0_2  original_T_including_depot_unload_936  7.2130540230577469e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_2  arc_capacity_448  1
    load_0_0_2  segment_load_conservation_852  -1
    load_0_0_2  segment_prefix_lb_853  1
    load_0_0_2  segment_prefix_ub_854  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_3  arc_capacity_449  -20
    arc_0_0_3  depot_departure_or_bypass_839  1
    arc_0_0_3  in_degree_856  1
    arc_0_0_3  original_T_including_depot_unload_936  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_3  arc_capacity_449  1
    load_0_0_3  segment_load_conservation_859  -1
    load_0_0_3  segment_prefix_lb_860  1
    load_0_0_3  segment_prefix_ub_861  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_4  arc_capacity_450  -20
    arc_0_0_4  depot_departure_or_bypass_839  1
    arc_0_0_4  in_degree_863  1
    arc_0_0_4  original_T_including_depot_unload_936  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_4  arc_capacity_450  1
    load_0_0_4  segment_load_conservation_866  -1
    load_0_0_4  segment_prefix_lb_867  1
    load_0_0_4  segment_prefix_ub_868  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_5  arc_capacity_451  -20
    arc_0_0_5  depot_departure_or_bypass_839  1
    arc_0_0_5  in_degree_870  1
    arc_0_0_5  original_T_including_depot_unload_936  6.6653528395596720e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_5  arc_capacity_451  1
    load_0_0_5  segment_load_conservation_873  -1
    load_0_0_5  segment_prefix_lb_874  1
    load_0_0_5  segment_prefix_ub_875  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_6  arc_capacity_452  -20
    arc_0_0_6  depot_departure_or_bypass_839  1
    arc_0_0_6  in_degree_877  1
    arc_0_0_6  original_T_including_depot_unload_936  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_6  arc_capacity_452  1
    load_0_0_6  segment_load_conservation_880  -1
    load_0_0_6  segment_prefix_lb_881  1
    load_0_0_6  segment_prefix_ub_882  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_14  arc_capacity_453  -20
    arc_0_0_14  depot_departure_or_bypass_839  1
    arc_0_0_14  in_degree_884  1
    arc_0_0_14  original_T_including_depot_unload_936  5.9431738885389052e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_14  arc_capacity_453  1
    load_0_0_14  free_load_conservation_888  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_15  arc_capacity_454  -20
    arc_0_0_15  depot_departure_or_bypass_839  1
    arc_0_0_15  in_degree_890  1
    arc_0_0_15  original_T_including_depot_unload_936  7.2571167924583824e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_15  arc_capacity_454  1
    load_0_0_15  free_load_conservation_894  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_16  arc_capacity_455  -20
    arc_0_0_16  depot_departure_or_bypass_839  1
    arc_0_0_16  in_degree_896  1
    arc_0_0_16  original_T_including_depot_unload_936  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_16  arc_capacity_455  1
    load_0_0_16  free_load_conservation_900  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_17  arc_capacity_456  -20
    arc_0_0_17  depot_departure_or_bypass_839  1
    arc_0_0_17  in_degree_902  1
    arc_0_0_17  original_T_including_depot_unload_936  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_17  arc_capacity_456  1
    load_0_0_17  free_load_conservation_906  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_18  arc_capacity_457  -20
    arc_0_0_18  depot_departure_or_bypass_839  1
    arc_0_0_18  in_degree_908  1
    arc_0_0_18  original_T_including_depot_unload_936  9.5330620720858735e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_18  arc_capacity_457  1
    load_0_0_18  free_load_conservation_912  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_19  arc_capacity_458  -20
    arc_0_0_19  depot_departure_or_bypass_839  1
    arc_0_0_19  in_degree_914  1
    arc_0_0_19  original_T_including_depot_unload_936  4.6364706268001146e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_19  arc_capacity_458  1
    load_0_0_19  free_load_conservation_918  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_20  arc_capacity_459  -20
    arc_0_0_20  depot_departure_or_bypass_839  1
    arc_0_0_20  in_degree_920  1
    arc_0_0_20  original_T_including_depot_unload_936  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_20  arc_capacity_459  1
    load_0_0_20  free_load_conservation_924  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_21  arc_capacity_460  -20
    arc_0_0_21  depot_departure_or_bypass_839  1
    arc_0_0_21  in_degree_926  1
    arc_0_0_21  original_T_including_depot_unload_936  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_21  arc_capacity_460  1
    load_0_0_21  free_load_conservation_930  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_0  arc_capacity_461  -20
    arc_0_1_0  depot_return_or_bypass_840  1
    arc_0_1_0  out_degree_841  1
    arc_0_1_0  original_T_including_depot_unload_936  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_0  arc_capacity_461  1
    load_0_1_0  segment_load_conservation_845  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_2  arc_capacity_462  -20
    arc_0_1_2  connected_order_arc_463  -15
    arc_0_1_2  out_degree_841  1
    arc_0_1_2  in_degree_849  1
    arc_0_1_2  original_T_including_depot_unload_936  4.4733407106545638e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_2  arc_capacity_462  1
    load_0_1_2  segment_load_conservation_845  1
    load_0_1_2  segment_load_conservation_852  -1
    load_0_1_2  segment_prefix_lb_853  1
    load_0_1_2  segment_prefix_ub_854  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_3  arc_capacity_464  -20
    arc_0_1_3  connected_order_arc_465  -15
    arc_0_1_3  out_degree_841  1
    arc_0_1_3  in_degree_856  1
    arc_0_1_3  original_T_including_depot_unload_936  2.7078292664437623e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_3  arc_capacity_464  1
    load_0_1_3  segment_load_conservation_845  1
    load_0_1_3  segment_load_conservation_859  -1
    load_0_1_3  segment_prefix_lb_860  1
    load_0_1_3  segment_prefix_ub_861  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_4  arc_capacity_466  -20
    arc_0_1_4  connected_order_arc_467  -15
    arc_0_1_4  out_degree_841  1
    arc_0_1_4  in_degree_863  1
    arc_0_1_4  original_T_including_depot_unload_936  545.439458844012
    MARKER    'MARKER'                 'INTEND'
    load_0_1_4  arc_capacity_466  1
    load_0_1_4  segment_load_conservation_845  1
    load_0_1_4  segment_load_conservation_866  -1
    load_0_1_4  segment_prefix_lb_867  1
    load_0_1_4  segment_prefix_ub_868  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_5  arc_capacity_468  -20
    arc_0_1_5  connected_order_arc_469  -15
    arc_0_1_5  out_degree_841  1
    arc_0_1_5  in_degree_870  1
    arc_0_1_5  original_T_including_depot_unload_936  628.141943094385
    MARKER    'MARKER'                 'INTEND'
    load_0_1_5  arc_capacity_468  1
    load_0_1_5  segment_load_conservation_845  1
    load_0_1_5  segment_load_conservation_873  -1
    load_0_1_5  segment_prefix_lb_874  1
    load_0_1_5  segment_prefix_ub_875  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_6  arc_capacity_470  -20
    arc_0_1_6  connected_order_arc_471  -15
    arc_0_1_6  out_degree_841  1
    arc_0_1_6  in_degree_877  1
    arc_0_1_6  original_T_including_depot_unload_936  9.3905252655669165e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_6  arc_capacity_470  1
    load_0_1_6  segment_load_conservation_845  1
    load_0_1_6  segment_load_conservation_880  -1
    load_0_1_6  segment_prefix_lb_881  1
    load_0_1_6  segment_prefix_ub_882  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_14  arc_capacity_472  -20
    arc_0_1_14  connected_order_arc_473  -15
    arc_0_1_14  out_degree_841  1
    arc_0_1_14  in_degree_884  1
    arc_0_1_14  original_T_including_depot_unload_936  6.9736186698570737e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_14  arc_capacity_472  1
    load_0_1_14  segment_load_conservation_845  1
    load_0_1_14  free_load_conservation_888  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_15  arc_capacity_474  -20
    arc_0_1_15  connected_order_arc_475  -15
    arc_0_1_15  out_degree_841  1
    arc_0_1_15  in_degree_890  1
    arc_0_1_15  original_T_including_depot_unload_936  8.7876124407720954e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_15  arc_capacity_474  1
    load_0_1_15  segment_load_conservation_845  1
    load_0_1_15  free_load_conservation_894  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_16  arc_capacity_476  -20
    arc_0_1_16  connected_order_arc_477  -15
    arc_0_1_16  out_degree_841  1
    arc_0_1_16  in_degree_896  1
    arc_0_1_16  original_T_including_depot_unload_936  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_16  arc_capacity_476  1
    load_0_1_16  segment_load_conservation_845  1
    load_0_1_16  free_load_conservation_900  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_17  arc_capacity_478  -20
    arc_0_1_17  connected_order_arc_479  -15
    arc_0_1_17  out_degree_841  1
    arc_0_1_17  in_degree_902  1
    arc_0_1_17  original_T_including_depot_unload_936  4.2733962838090457e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_17  arc_capacity_478  1
    load_0_1_17  segment_load_conservation_845  1
    load_0_1_17  free_load_conservation_906  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_18  arc_capacity_480  -20
    arc_0_1_18  connected_order_arc_481  -15
    arc_0_1_18  out_degree_841  1
    arc_0_1_18  in_degree_908  1
    arc_0_1_18  original_T_including_depot_unload_936  8.4968861461374138e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_18  arc_capacity_480  1
    load_0_1_18  segment_load_conservation_845  1
    load_0_1_18  free_load_conservation_912  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_19  arc_capacity_482  -20
    arc_0_1_19  connected_order_arc_483  -15
    arc_0_1_19  out_degree_841  1
    arc_0_1_19  in_degree_914  1
    arc_0_1_19  original_T_including_depot_unload_936  6.7517249538835438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_19  arc_capacity_482  1
    load_0_1_19  segment_load_conservation_845  1
    load_0_1_19  free_load_conservation_918  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_20  arc_capacity_484  -20
    arc_0_1_20  connected_order_arc_485  -15
    arc_0_1_20  out_degree_841  1
    arc_0_1_20  in_degree_920  1
    arc_0_1_20  original_T_including_depot_unload_936  3.9758967496529505e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_20  arc_capacity_484  1
    load_0_1_20  segment_load_conservation_845  1
    load_0_1_20  free_load_conservation_924  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_21  arc_capacity_486  -20
    arc_0_1_21  connected_order_arc_487  -15
    arc_0_1_21  out_degree_841  1
    arc_0_1_21  in_degree_926  1
    arc_0_1_21  original_T_including_depot_unload_936  4.3618991857210159e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_21  arc_capacity_486  1
    load_0_1_21  segment_load_conservation_845  1
    load_0_1_21  free_load_conservation_930  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_0  arc_capacity_488  -20
    arc_0_2_0  depot_return_or_bypass_840  1
    arc_0_2_0  out_degree_848  1
    arc_0_2_0  original_T_including_depot_unload_936  5.4249700630778887e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_0  arc_capacity_488  1
    load_0_2_0  segment_load_conservation_852  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_1  arc_capacity_489  -20
    arc_0_2_1  connected_order_arc_490  -15
    arc_0_2_1  in_degree_842  1
    arc_0_2_1  out_degree_848  1
    arc_0_2_1  original_T_including_depot_unload_936  2.8529311190414518e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_1  arc_capacity_489  1
    load_0_2_1  segment_load_conservation_845  -1
    load_0_2_1  segment_prefix_lb_846  1
    load_0_2_1  segment_prefix_ub_847  1
    load_0_2_1  segment_load_conservation_852  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_3  arc_capacity_491  -20
    arc_0_2_3  connected_order_arc_492  -15
    arc_0_2_3  out_degree_848  1
    arc_0_2_3  in_degree_856  1
    arc_0_2_3  original_T_including_depot_unload_936  1.7461252424213140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_3  arc_capacity_491  1
    load_0_2_3  segment_load_conservation_852  1
    load_0_2_3  segment_load_conservation_859  -1
    load_0_2_3  segment_prefix_lb_860  1
    load_0_2_3  segment_prefix_ub_861  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_4  arc_capacity_493  -20
    arc_0_2_4  connected_order_arc_494  -15
    arc_0_2_4  out_degree_848  1
    arc_0_2_4  in_degree_863  1
    arc_0_2_4  original_T_including_depot_unload_936  3.4289721135663990e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_4  arc_capacity_493  1
    load_0_2_4  segment_load_conservation_852  1
    load_0_2_4  segment_load_conservation_866  -1
    load_0_2_4  segment_prefix_lb_867  1
    load_0_2_4  segment_prefix_ub_868  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_5  arc_capacity_495  -20
    arc_0_2_5  connected_order_arc_496  -15
    arc_0_2_5  out_degree_848  1
    arc_0_2_5  in_degree_870  1
    arc_0_2_5  original_T_including_depot_unload_936  5.5739415765733247e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_5  arc_capacity_495  1
    load_0_2_5  segment_load_conservation_852  1
    load_0_2_5  segment_load_conservation_873  -1
    load_0_2_5  segment_prefix_lb_874  1
    load_0_2_5  segment_prefix_ub_875  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_6  arc_capacity_497  -20
    arc_0_2_6  connected_order_arc_498  -15
    arc_0_2_6  out_degree_848  1
    arc_0_2_6  in_degree_877  1
    arc_0_2_6  original_T_including_depot_unload_936  1.0838347754693179e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_6  arc_capacity_497  1
    load_0_2_6  segment_load_conservation_852  1
    load_0_2_6  segment_load_conservation_880  -1
    load_0_2_6  segment_prefix_lb_881  1
    load_0_2_6  segment_prefix_ub_882  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_14  arc_capacity_499  -20
    arc_0_2_14  connected_order_arc_500  -15
    arc_0_2_14  out_degree_848  1
    arc_0_2_14  in_degree_884  1
    arc_0_2_14  original_T_including_depot_unload_936  7.5688558078083690e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_14  arc_capacity_499  1
    load_0_2_14  segment_load_conservation_852  1
    load_0_2_14  free_load_conservation_888  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_15  arc_capacity_501  -20
    arc_0_2_15  connected_order_arc_502  -15
    arc_0_2_15  out_degree_848  1
    arc_0_2_15  in_degree_890  1
    arc_0_2_15  original_T_including_depot_unload_936  9.6620394708383776e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_15  arc_capacity_501  1
    load_0_2_15  segment_load_conservation_852  1
    load_0_2_15  free_load_conservation_894  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_16  arc_capacity_503  -20
    arc_0_2_16  connected_order_arc_504  -15
    arc_0_2_16  out_degree_848  1
    arc_0_2_16  in_degree_896  1
    arc_0_2_16  original_T_including_depot_unload_936  1.6231508478292610e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_16  arc_capacity_503  1
    load_0_2_16  segment_load_conservation_852  1
    load_0_2_16  free_load_conservation_900  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_17  arc_capacity_505  -20
    arc_0_2_17  connected_order_arc_506  -15
    arc_0_2_17  out_degree_848  1
    arc_0_2_17  in_degree_902  1
    arc_0_2_17  original_T_including_depot_unload_936  4.6789193623835109e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_17  arc_capacity_505  1
    load_0_2_17  segment_load_conservation_852  1
    load_0_2_17  free_load_conservation_906  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_18  arc_capacity_507  -20
    arc_0_2_18  connected_order_arc_508  -15
    arc_0_2_18  out_degree_848  1
    arc_0_2_18  in_degree_908  1
    arc_0_2_18  original_T_including_depot_unload_936  6.7711923781893620e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_18  arc_capacity_507  1
    load_0_2_18  segment_load_conservation_852  1
    load_0_2_18  free_load_conservation_912  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_19  arc_capacity_509  -20
    arc_0_2_19  connected_order_arc_510  -15
    arc_0_2_19  out_degree_848  1
    arc_0_2_19  in_degree_914  1
    arc_0_2_19  original_T_including_depot_unload_936  839.148853987777
    MARKER    'MARKER'                 'INTEND'
    load_0_2_19  arc_capacity_509  1
    load_0_2_19  segment_load_conservation_852  1
    load_0_2_19  free_load_conservation_918  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_20  arc_capacity_511  -20
    arc_0_2_20  connected_order_arc_512  -15
    arc_0_2_20  out_degree_848  1
    arc_0_2_20  in_degree_920  1
    arc_0_2_20  original_T_including_depot_unload_936  3.3800157717255917e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_20  arc_capacity_511  1
    load_0_2_20  segment_load_conservation_852  1
    load_0_2_20  free_load_conservation_924  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_21  arc_capacity_513  -20
    arc_0_2_21  connected_order_arc_514  -15
    arc_0_2_21  out_degree_848  1
    arc_0_2_21  in_degree_926  1
    arc_0_2_21  original_T_including_depot_unload_936  6.0309764600105484e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_21  arc_capacity_513  1
    load_0_2_21  segment_load_conservation_852  1
    load_0_2_21  free_load_conservation_930  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_0  arc_capacity_515  -20
    arc_0_3_0  depot_return_or_bypass_840  1
    arc_0_3_0  out_degree_855  1
    arc_0_3_0  original_T_including_depot_unload_936  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_0  arc_capacity_515  1
    load_0_3_0  segment_load_conservation_859  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_1  arc_capacity_516  -20
    arc_0_3_1  connected_order_arc_517  -15
    arc_0_3_1  in_degree_842  1
    arc_0_3_1  out_degree_855  1
    arc_0_3_1  original_T_including_depot_unload_936  2.7078292664437623e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_1  arc_capacity_516  1
    load_0_3_1  segment_load_conservation_845  -1
    load_0_3_1  segment_prefix_lb_846  1
    load_0_3_1  segment_prefix_ub_847  1
    load_0_3_1  segment_load_conservation_859  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_2  arc_capacity_518  -20
    arc_0_3_2  connected_order_arc_519  -15
    arc_0_3_2  in_degree_849  1
    arc_0_3_2  out_degree_855  1
    arc_0_3_2  original_T_including_depot_unload_936  4.9242827332511274e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_2  arc_capacity_518  1
    load_0_3_2  segment_load_conservation_852  -1
    load_0_3_2  segment_prefix_lb_853  1
    load_0_3_2  segment_prefix_ub_854  1
    load_0_3_2  segment_load_conservation_859  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_4  arc_capacity_520  -20
    arc_0_3_4  connected_order_arc_521  -15
    arc_0_3_4  out_degree_855  1
    arc_0_3_4  in_degree_863  1
    arc_0_3_4  original_T_including_depot_unload_936  2.7570828838654035e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_4  arc_capacity_520  1
    load_0_3_4  segment_load_conservation_859  1
    load_0_3_4  segment_load_conservation_866  -1
    load_0_3_4  segment_prefix_lb_867  1
    load_0_3_4  segment_prefix_ub_868  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_5  arc_capacity_522  -20
    arc_0_3_5  connected_order_arc_523  -15
    arc_0_3_5  out_degree_855  1
    arc_0_3_5  in_degree_870  1
    arc_0_3_5  original_T_including_depot_unload_936  4.0284428834016438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_5  arc_capacity_522  1
    load_0_3_5  segment_load_conservation_859  1
    load_0_3_5  segment_load_conservation_873  -1
    load_0_3_5  segment_prefix_lb_874  1
    load_0_3_5  segment_prefix_ub_875  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_6  arc_capacity_524  -20
    arc_0_3_6  connected_order_arc_525  -15
    arc_0_3_6  out_degree_855  1
    arc_0_3_6  in_degree_877  1
    arc_0_3_6  original_T_including_depot_unload_936  9.1580557259044724e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_6  arc_capacity_524  1
    load_0_3_6  segment_load_conservation_859  1
    load_0_3_6  segment_load_conservation_880  -1
    load_0_3_6  segment_prefix_lb_881  1
    load_0_3_6  segment_prefix_ub_882  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_14  arc_capacity_526  -20
    arc_0_3_14  connected_order_arc_527  -15
    arc_0_3_14  out_degree_855  1
    arc_0_3_14  in_degree_884  1
    arc_0_3_14  original_T_including_depot_unload_936  5.8227353503177085e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_14  arc_capacity_526  1
    load_0_3_14  segment_load_conservation_859  1
    load_0_3_14  free_load_conservation_888  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_15  arc_capacity_528  -20
    arc_0_3_15  connected_order_arc_529  -15
    arc_0_3_15  out_degree_855  1
    arc_0_3_15  in_degree_890  1
    arc_0_3_15  original_T_including_depot_unload_936  7.9195606724980928e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_15  arc_capacity_528  1
    load_0_3_15  segment_load_conservation_859  1
    load_0_3_15  free_load_conservation_894  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_16  arc_capacity_530  -20
    arc_0_3_16  connected_order_arc_531  -15
    arc_0_3_16  out_degree_855  1
    arc_0_3_16  in_degree_896  1
    arc_0_3_16  original_T_including_depot_unload_936  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_16  arc_capacity_530  1
    load_0_3_16  segment_load_conservation_859  1
    load_0_3_16  free_load_conservation_900  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_17  arc_capacity_532  -20
    arc_0_3_17  connected_order_arc_533  -15
    arc_0_3_17  out_degree_855  1
    arc_0_3_17  in_degree_902  1
    arc_0_3_17  original_T_including_depot_unload_936  2.9376641610717382e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_17  arc_capacity_532  1
    load_0_3_17  segment_load_conservation_859  1
    load_0_3_17  free_load_conservation_906  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_18  arc_capacity_534  -20
    arc_0_3_18  connected_order_arc_535  -15
    arc_0_3_18  out_degree_855  1
    arc_0_3_18  in_degree_908  1
    arc_0_3_18  original_T_including_depot_unload_936  5.8292761965990132e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_18  arc_capacity_534  1
    load_0_3_18  segment_load_conservation_859  1
    load_0_3_18  free_load_conservation_912  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_19  arc_capacity_536  -20
    arc_0_3_19  connected_order_arc_537  -15
    arc_0_3_19  out_degree_855  1
    arc_0_3_19  in_degree_914  1
    arc_0_3_19  original_T_including_depot_unload_936  6.7868877694996661e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_19  arc_capacity_536  1
    load_0_3_19  segment_load_conservation_859  1
    load_0_3_19  free_load_conservation_918  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_20  arc_capacity_538  -20
    arc_0_3_20  connected_order_arc_539  -15
    arc_0_3_20  out_degree_855  1
    arc_0_3_20  in_degree_920  1
    arc_0_3_20  original_T_including_depot_unload_936  1.7053268374267958e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_20  arc_capacity_538  1
    load_0_3_20  segment_load_conservation_859  1
    load_0_3_20  free_load_conservation_924  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_21  arc_capacity_540  -20
    arc_0_3_21  connected_order_arc_541  -15
    arc_0_3_21  out_degree_855  1
    arc_0_3_21  in_degree_926  1
    arc_0_3_21  original_T_including_depot_unload_936  4.5094949828949649e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_21  arc_capacity_540  1
    load_0_3_21  segment_load_conservation_859  1
    load_0_3_21  free_load_conservation_930  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_0  arc_capacity_542  -20
    arc_0_4_0  depot_return_or_bypass_840  1
    arc_0_4_0  out_degree_862  1
    arc_0_4_0  original_T_including_depot_unload_936  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_0  arc_capacity_542  1
    load_0_4_0  segment_load_conservation_866  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_1  arc_capacity_543  -20
    arc_0_4_1  connected_order_arc_544  -15
    arc_0_4_1  in_degree_842  1
    arc_0_4_1  out_degree_862  1
    arc_0_4_1  original_T_including_depot_unload_936  545.439458844012
    MARKER    'MARKER'                 'INTEND'
    load_0_4_1  arc_capacity_543  1
    load_0_4_1  segment_load_conservation_845  -1
    load_0_4_1  segment_prefix_lb_846  1
    load_0_4_1  segment_prefix_ub_847  1
    load_0_4_1  segment_load_conservation_866  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_2  arc_capacity_545  -20
    arc_0_4_2  connected_order_arc_546  -15
    arc_0_4_2  in_degree_849  1
    arc_0_4_2  out_degree_862  1
    arc_0_4_2  original_T_including_depot_unload_936  6.3648699141452130e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_2  arc_capacity_545  1
    load_0_4_2  segment_load_conservation_852  -1
    load_0_4_2  segment_prefix_lb_853  1
    load_0_4_2  segment_prefix_ub_854  1
    load_0_4_2  segment_load_conservation_866  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_3  arc_capacity_547  -20
    arc_0_4_3  connected_order_arc_548  -15
    arc_0_4_3  in_degree_856  1
    arc_0_4_3  out_degree_862  1
    arc_0_4_3  original_T_including_depot_unload_936  2.7570828838654035e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_3  arc_capacity_547  1
    load_0_4_3  segment_load_conservation_859  -1
    load_0_4_3  segment_prefix_lb_860  1
    load_0_4_3  segment_prefix_ub_861  1
    load_0_4_3  segment_load_conservation_866  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_5  arc_capacity_549  -20
    arc_0_4_5  connected_order_arc_550  -15
    arc_0_4_5  out_degree_862  1
    arc_0_4_5  in_degree_870  1
    arc_0_4_5  original_T_including_depot_unload_936  3.1069481377857926e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_5  arc_capacity_549  1
    load_0_4_5  segment_load_conservation_866  1
    load_0_4_5  segment_load_conservation_873  -1
    load_0_4_5  segment_prefix_lb_874  1
    load_0_4_5  segment_prefix_ub_875  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_6  arc_capacity_551  -20
    arc_0_4_6  connected_order_arc_552  -15
    arc_0_4_6  out_degree_862  1
    arc_0_4_6  in_degree_877  1
    arc_0_4_6  original_T_including_depot_unload_936  1.0038065985492663e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_6  arc_capacity_551  1
    load_0_4_6  segment_load_conservation_866  1
    load_0_4_6  segment_load_conservation_880  -1
    load_0_4_6  segment_prefix_lb_881  1
    load_0_4_6  segment_prefix_ub_882  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_14  arc_capacity_553  -20
    arc_0_4_14  connected_order_arc_554  -15
    arc_0_4_14  out_degree_862  1
    arc_0_4_14  in_degree_884  1
    arc_0_4_14  original_T_including_depot_unload_936  6.1561452832791758e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_14  arc_capacity_553  1
    load_0_4_14  segment_load_conservation_866  1
    load_0_4_14  free_load_conservation_888  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_15  arc_capacity_555  -20
    arc_0_4_15  connected_order_arc_556  -15
    arc_0_4_15  out_degree_862  1
    arc_0_4_15  in_degree_890  1
    arc_0_4_15  original_T_including_depot_unload_936  8.2707974701454475e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_15  arc_capacity_555  1
    load_0_4_15  segment_load_conservation_866  1
    load_0_4_15  free_load_conservation_894  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_16  arc_capacity_557  -20
    arc_0_4_16  connected_order_arc_558  -15
    arc_0_4_16  out_degree_862  1
    arc_0_4_16  in_degree_896  1
    arc_0_4_16  original_T_including_depot_unload_936  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_16  arc_capacity_557  1
    load_0_4_16  segment_load_conservation_866  1
    load_0_4_16  free_load_conservation_900  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_17  arc_capacity_559  -20
    arc_0_4_17  connected_order_arc_560  -15
    arc_0_4_17  out_degree_862  1
    arc_0_4_17  in_degree_902  1
    arc_0_4_17  original_T_including_depot_unload_936  3.9864800790786632e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_17  arc_capacity_559  1
    load_0_4_17  segment_load_conservation_866  1
    load_0_4_17  free_load_conservation_906  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_18  arc_capacity_561  -20
    arc_0_4_18  connected_order_arc_562  -15
    arc_0_4_18  out_degree_862  1
    arc_0_4_18  in_degree_908  1
    arc_0_4_18  original_T_including_depot_unload_936  3.3469758905462760e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_18  arc_capacity_561  1
    load_0_4_18  segment_load_conservation_866  1
    load_0_4_18  free_load_conservation_912  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_19  arc_capacity_563  -20
    arc_0_4_19  connected_order_arc_564  -15
    arc_0_4_19  out_degree_862  1
    arc_0_4_19  in_degree_914  1
    arc_0_4_19  original_T_including_depot_unload_936  8.1289340937717509e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_19  arc_capacity_563  1
    load_0_4_19  segment_load_conservation_866  1
    load_0_4_19  free_load_conservation_918  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_20  arc_capacity_565  -20
    arc_0_4_20  connected_order_arc_566  -15
    arc_0_4_20  out_degree_862  1
    arc_0_4_20  in_degree_920  1
    arc_0_4_20  original_T_including_depot_unload_936  2.4111148152767828e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_20  arc_capacity_565  1
    load_0_4_20  segment_load_conservation_866  1
    load_0_4_20  free_load_conservation_924  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_21  arc_capacity_567  -20
    arc_0_4_21  connected_order_arc_568  -15
    arc_0_4_21  out_degree_862  1
    arc_0_4_21  in_degree_926  1
    arc_0_4_21  original_T_including_depot_unload_936  6.2886632383683013e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_21  arc_capacity_567  1
    load_0_4_21  segment_load_conservation_866  1
    load_0_4_21  free_load_conservation_930  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_0  arc_capacity_569  -20
    arc_0_5_0  depot_return_or_bypass_840  1
    arc_0_5_0  out_degree_869  1
    arc_0_5_0  original_T_including_depot_unload_936  6.6653528395596720e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_0  arc_capacity_569  1
    load_0_5_0  segment_load_conservation_873  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_1  arc_capacity_570  -20
    arc_0_5_1  connected_order_arc_571  -15
    arc_0_5_1  in_degree_842  1
    arc_0_5_1  out_degree_869  1
    arc_0_5_1  original_T_including_depot_unload_936  628.141943094385
    MARKER    'MARKER'                 'INTEND'
    load_0_5_1  arc_capacity_570  1
    load_0_5_1  segment_load_conservation_845  -1
    load_0_5_1  segment_prefix_lb_846  1
    load_0_5_1  segment_prefix_ub_847  1
    load_0_5_1  segment_load_conservation_873  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_2  arc_capacity_572  -20
    arc_0_5_2  connected_order_arc_573  -15
    arc_0_5_2  in_degree_849  1
    arc_0_5_2  out_degree_869  1
    arc_0_5_2  original_T_including_depot_unload_936  880.352897387315
    MARKER    'MARKER'                 'INTEND'
    load_0_5_2  arc_capacity_572  1
    load_0_5_2  segment_load_conservation_852  -1
    load_0_5_2  segment_prefix_lb_853  1
    load_0_5_2  segment_prefix_ub_854  1
    load_0_5_2  segment_load_conservation_873  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_3  arc_capacity_574  -20
    arc_0_5_3  connected_order_arc_575  -15
    arc_0_5_3  in_degree_856  1
    arc_0_5_3  out_degree_869  1
    arc_0_5_3  original_T_including_depot_unload_936  4.0284428834016438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_3  arc_capacity_574  1
    load_0_5_3  segment_load_conservation_859  -1
    load_0_5_3  segment_prefix_lb_860  1
    load_0_5_3  segment_prefix_ub_861  1
    load_0_5_3  segment_load_conservation_873  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_4  arc_capacity_576  -20
    arc_0_5_4  connected_order_arc_577  -15
    arc_0_5_4  in_degree_863  1
    arc_0_5_4  out_degree_869  1
    arc_0_5_4  original_T_including_depot_unload_936  3.1069481377857926e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_4  arc_capacity_576  1
    load_0_5_4  segment_load_conservation_866  -1
    load_0_5_4  segment_prefix_lb_867  1
    load_0_5_4  segment_prefix_ub_868  1
    load_0_5_4  segment_load_conservation_873  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_6  arc_capacity_578  -20
    arc_0_5_6  connected_order_arc_579  -15
    arc_0_5_6  out_degree_869  1
    arc_0_5_6  in_degree_877  1
    arc_0_5_6  original_T_including_depot_unload_936  7.2751050611121218e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_6  arc_capacity_578  1
    load_0_5_6  segment_load_conservation_873  1
    load_0_5_6  segment_load_conservation_880  -1
    load_0_5_6  segment_prefix_lb_881  1
    load_0_5_6  segment_prefix_ub_882  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_14  arc_capacity_580  -20
    arc_0_5_14  connected_order_arc_581  -15
    arc_0_5_14  out_degree_869  1
    arc_0_5_14  in_degree_884  1
    arc_0_5_14  original_T_including_depot_unload_936  3.2985327387120213e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_14  arc_capacity_580  1
    load_0_5_14  segment_load_conservation_873  1
    load_0_5_14  free_load_conservation_888  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_15  arc_capacity_582  -20
    arc_0_5_15  connected_order_arc_583  -15
    arc_0_5_15  out_degree_869  1
    arc_0_5_15  in_degree_890  1
    arc_0_5_15  original_T_including_depot_unload_936  5.2996691306068044e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_15  arc_capacity_582  1
    load_0_5_15  segment_load_conservation_873  1
    load_0_5_15  free_load_conservation_894  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_16  arc_capacity_584  -20
    arc_0_5_16  connected_order_arc_585  -15
    arc_0_5_16  out_degree_869  1
    arc_0_5_16  in_degree_896  1
    arc_0_5_16  original_T_including_depot_unload_936  1.6292966848558842e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_16  arc_capacity_584  1
    load_0_5_16  segment_load_conservation_873  1
    load_0_5_16  free_load_conservation_900  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_17  arc_capacity_586  -20
    arc_0_5_17  connected_order_arc_587  -15
    arc_0_5_17  out_degree_869  1
    arc_0_5_17  in_degree_902  1
    arc_0_5_17  original_T_including_depot_unload_936  2.5147997402163108e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_17  arc_capacity_586  1
    load_0_5_17  segment_load_conservation_873  1
    load_0_5_17  free_load_conservation_906  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_18  arc_capacity_588  -20
    arc_0_5_18  connected_order_arc_589  -15
    arc_0_5_18  out_degree_869  1
    arc_0_5_18  in_degree_908  1
    arc_0_5_18  original_T_including_depot_unload_936  3.1728416035596246e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_18  arc_capacity_588  1
    load_0_5_18  segment_load_conservation_873  1
    load_0_5_18  free_load_conservation_912  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_19  arc_capacity_590  -20
    arc_0_5_19  connected_order_arc_591  -15
    arc_0_5_19  out_degree_869  1
    arc_0_5_19  in_degree_914  1
    arc_0_5_19  original_T_including_depot_unload_936  5.8442598457899078e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_19  arc_capacity_590  1
    load_0_5_19  segment_load_conservation_873  1
    load_0_5_19  free_load_conservation_918  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_20  arc_capacity_592  -20
    arc_0_5_20  connected_order_arc_593  -15
    arc_0_5_20  out_degree_869  1
    arc_0_5_20  in_degree_920  1
    arc_0_5_20  original_T_including_depot_unload_936  2.3649901674897566e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_20  arc_capacity_592  1
    load_0_5_20  segment_load_conservation_873  1
    load_0_5_20  free_load_conservation_924  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_21  arc_capacity_594  -20
    arc_0_5_21  connected_order_arc_595  -15
    arc_0_5_21  out_degree_869  1
    arc_0_5_21  in_degree_926  1
    arc_0_5_21  original_T_including_depot_unload_936  4.7597588586788925e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_21  arc_capacity_594  1
    load_0_5_21  segment_load_conservation_873  1
    load_0_5_21  free_load_conservation_930  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_0  arc_capacity_596  -20
    arc_0_6_0  depot_return_or_bypass_840  1
    arc_0_6_0  out_degree_876  1
    arc_0_6_0  original_T_including_depot_unload_936  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_0  arc_capacity_596  1
    load_0_6_0  segment_load_conservation_880  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_1  arc_capacity_597  -20
    arc_0_6_1  connected_order_arc_598  -15
    arc_0_6_1  in_degree_842  1
    arc_0_6_1  out_degree_876  1
    arc_0_6_1  original_T_including_depot_unload_936  9.3905252655669165e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_1  arc_capacity_597  1
    load_0_6_1  segment_load_conservation_845  -1
    load_0_6_1  segment_prefix_lb_846  1
    load_0_6_1  segment_prefix_ub_847  1
    load_0_6_1  segment_load_conservation_880  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_2  arc_capacity_599  -20
    arc_0_6_2  connected_order_arc_600  -15
    arc_0_6_2  in_degree_849  1
    arc_0_6_2  out_degree_876  1
    arc_0_6_2  original_T_including_depot_unload_936  1.3669225770244122e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_2  arc_capacity_599  1
    load_0_6_2  segment_load_conservation_852  -1
    load_0_6_2  segment_prefix_lb_853  1
    load_0_6_2  segment_prefix_ub_854  1
    load_0_6_2  segment_load_conservation_880  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_3  arc_capacity_601  -20
    arc_0_6_3  connected_order_arc_602  -15
    arc_0_6_3  in_degree_856  1
    arc_0_6_3  out_degree_876  1
    arc_0_6_3  original_T_including_depot_unload_936  9.1580557259044724e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_3  arc_capacity_601  1
    load_0_6_3  segment_load_conservation_859  -1
    load_0_6_3  segment_prefix_lb_860  1
    load_0_6_3  segment_prefix_ub_861  1
    load_0_6_3  segment_load_conservation_880  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_4  arc_capacity_603  -20
    arc_0_6_4  connected_order_arc_604  -15
    arc_0_6_4  in_degree_863  1
    arc_0_6_4  out_degree_876  1
    arc_0_6_4  original_T_including_depot_unload_936  1.0038065985492663e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_4  arc_capacity_603  1
    load_0_6_4  segment_load_conservation_866  -1
    load_0_6_4  segment_prefix_lb_867  1
    load_0_6_4  segment_prefix_ub_868  1
    load_0_6_4  segment_load_conservation_880  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_5  arc_capacity_605  -20
    arc_0_6_5  connected_order_arc_606  -15
    arc_0_6_5  in_degree_870  1
    arc_0_6_5  out_degree_876  1
    arc_0_6_5  original_T_including_depot_unload_936  7.2751050611121218e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_5  arc_capacity_605  1
    load_0_6_5  segment_load_conservation_873  -1
    load_0_6_5  segment_prefix_lb_874  1
    load_0_6_5  segment_prefix_ub_875  1
    load_0_6_5  segment_load_conservation_880  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_14  arc_capacity_607  -20
    arc_0_6_14  connected_order_arc_608  -15
    arc_0_6_14  out_degree_876  1
    arc_0_6_14  in_degree_884  1
    arc_0_6_14  original_T_including_depot_unload_936  3.9766425523492148e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_14  arc_capacity_607  1
    load_0_6_14  segment_load_conservation_880  1
    load_0_6_14  free_load_conservation_888  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_15  arc_capacity_609  -20
    arc_0_6_15  connected_order_arc_610  -15
    arc_0_6_15  out_degree_876  1
    arc_0_6_15  in_degree_890  1
    arc_0_6_15  original_T_including_depot_unload_936  2.3059951477332697e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_15  arc_capacity_609  1
    load_0_6_15  segment_load_conservation_880  1
    load_0_6_15  free_load_conservation_894  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_16  arc_capacity_611  -20
    arc_0_6_16  connected_order_arc_612  -15
    arc_0_6_16  out_degree_876  1
    arc_0_6_16  in_degree_896  1
    arc_0_6_16  original_T_including_depot_unload_936  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_16  arc_capacity_611  1
    load_0_6_16  segment_load_conservation_880  1
    load_0_6_16  free_load_conservation_900  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_17  arc_capacity_613  -20
    arc_0_6_17  connected_order_arc_614  -15
    arc_0_6_17  out_degree_876  1
    arc_0_6_17  in_degree_902  1
    arc_0_6_17  original_T_including_depot_unload_936  6.3111682574558915e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_17  arc_capacity_613  1
    load_0_6_17  segment_load_conservation_880  1
    load_0_6_17  free_load_conservation_906  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_18  arc_capacity_615  -20
    arc_0_6_18  connected_order_arc_616  -15
    arc_0_6_18  out_degree_876  1
    arc_0_6_18  in_degree_908  1
    arc_0_6_18  original_T_including_depot_unload_936  1.0105932041904148e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_18  arc_capacity_615  1
    load_0_6_18  segment_load_conservation_880  1
    load_0_6_18  free_load_conservation_912  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_19  arc_capacity_617  -20
    arc_0_6_19  connected_order_arc_618  -15
    arc_0_6_19  out_degree_876  1
    arc_0_6_19  in_degree_914  1
    arc_0_6_19  original_T_including_depot_unload_936  2.6602972191926557e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_19  arc_capacity_617  1
    load_0_6_19  segment_load_conservation_880  1
    load_0_6_19  free_load_conservation_918  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_20  arc_capacity_619  -20
    arc_0_6_20  connected_order_arc_620  -15
    arc_0_6_20  out_degree_876  1
    arc_0_6_20  in_degree_920  1
    arc_0_6_20  original_T_including_depot_unload_936  7.9403551275216375e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_20  arc_capacity_619  1
    load_0_6_20  segment_load_conservation_880  1
    load_0_6_20  free_load_conservation_924  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_21  arc_capacity_621  -20
    arc_0_6_21  connected_order_arc_622  -15
    arc_0_6_21  out_degree_876  1
    arc_0_6_21  in_degree_926  1
    arc_0_6_21  original_T_including_depot_unload_936  5.0315495126439691e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_21  arc_capacity_621  1
    load_0_6_21  segment_load_conservation_880  1
    load_0_6_21  free_load_conservation_930  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_0  arc_capacity_623  -20
    arc_0_14_0  depot_return_or_bypass_840  1
    arc_0_14_0  out_degree_883  1
    arc_0_14_0  original_T_including_depot_unload_936  5.9431738885389052e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_0  arc_capacity_623  1
    load_0_14_0  free_load_conservation_888  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_1  arc_capacity_624  -20
    arc_0_14_1  connected_order_arc_625  -15
    arc_0_14_1  in_degree_842  1
    arc_0_14_1  out_degree_883  1
    arc_0_14_1  original_T_including_depot_unload_936  6.9736186698570737e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_1  arc_capacity_624  1
    load_0_14_1  segment_load_conservation_845  -1
    load_0_14_1  segment_prefix_lb_846  1
    load_0_14_1  segment_prefix_ub_847  1
    load_0_14_1  free_load_conservation_888  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_2  arc_capacity_626  -20
    arc_0_14_2  connected_order_arc_627  -15
    arc_0_14_2  in_degree_849  1
    arc_0_14_2  out_degree_883  1
    arc_0_14_2  original_T_including_depot_unload_936  1.0687086794720833e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_2  arc_capacity_626  1
    load_0_14_2  segment_load_conservation_852  -1
    load_0_14_2  segment_prefix_lb_853  1
    load_0_14_2  segment_prefix_ub_854  1
    load_0_14_2  free_load_conservation_888  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_3  arc_capacity_628  -20
    arc_0_14_3  connected_order_arc_629  -15
    arc_0_14_3  in_degree_856  1
    arc_0_14_3  out_degree_883  1
    arc_0_14_3  original_T_including_depot_unload_936  5.8227353503177085e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_3  arc_capacity_628  1
    load_0_14_3  segment_load_conservation_859  -1
    load_0_14_3  segment_prefix_lb_860  1
    load_0_14_3  segment_prefix_ub_861  1
    load_0_14_3  free_load_conservation_888  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_4  arc_capacity_630  -20
    arc_0_14_4  connected_order_arc_631  -15
    arc_0_14_4  in_degree_863  1
    arc_0_14_4  out_degree_883  1
    arc_0_14_4  original_T_including_depot_unload_936  6.1561452832791758e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_4  arc_capacity_630  1
    load_0_14_4  segment_load_conservation_866  -1
    load_0_14_4  segment_prefix_lb_867  1
    load_0_14_4  segment_prefix_ub_868  1
    load_0_14_4  free_load_conservation_888  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_5  arc_capacity_632  -20
    arc_0_14_5  connected_order_arc_633  -15
    arc_0_14_5  in_degree_870  1
    arc_0_14_5  out_degree_883  1
    arc_0_14_5  original_T_including_depot_unload_936  3.2985327387120213e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_5  arc_capacity_632  1
    load_0_14_5  segment_load_conservation_873  -1
    load_0_14_5  segment_prefix_lb_874  1
    load_0_14_5  segment_prefix_ub_875  1
    load_0_14_5  free_load_conservation_888  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_6  arc_capacity_634  -20
    arc_0_14_6  connected_order_arc_635  -15
    arc_0_14_6  in_degree_877  1
    arc_0_14_6  out_degree_883  1
    arc_0_14_6  original_T_including_depot_unload_936  3.9766425523492148e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_6  arc_capacity_634  1
    load_0_14_6  segment_load_conservation_880  -1
    load_0_14_6  segment_prefix_lb_881  1
    load_0_14_6  segment_prefix_ub_882  1
    load_0_14_6  free_load_conservation_888  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_15  arc_capacity_636  -20
    arc_0_14_15  connected_order_arc_637  -15
    arc_0_14_15  out_degree_883  1
    arc_0_14_15  in_degree_890  1
    arc_0_14_15  original_T_including_depot_unload_936  2.1481294511470344e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_15  arc_capacity_636  1
    load_0_14_15  free_load_conservation_888  1
    load_0_14_15  free_load_conservation_894  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_16  arc_capacity_638  -20
    arc_0_14_16  connected_order_arc_639  -15
    arc_0_14_16  out_degree_883  1
    arc_0_14_16  in_degree_896  1
    arc_0_14_16  original_T_including_depot_unload_936  1.3727638439182763e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_16  arc_capacity_638  1
    load_0_14_16  free_load_conservation_888  1
    load_0_14_16  free_load_conservation_900  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_17  arc_capacity_640  -20
    arc_0_14_17  connected_order_arc_641  -15
    arc_0_14_17  out_degree_883  1
    arc_0_14_17  in_degree_902  1
    arc_0_14_17  original_T_including_depot_unload_936  2.9098466309579254e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_17  arc_capacity_640  1
    load_0_14_17  free_load_conservation_888  1
    load_0_14_17  free_load_conservation_906  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_18  arc_capacity_642  -20
    arc_0_14_18  connected_order_arc_643  -15
    arc_0_14_18  out_degree_883  1
    arc_0_14_18  in_degree_908  1
    arc_0_14_18  original_T_including_depot_unload_936  6.2159179673866879e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_18  arc_capacity_642  1
    load_0_14_18  free_load_conservation_888  1
    load_0_14_18  free_load_conservation_912  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_19  arc_capacity_644  -20
    arc_0_14_19  connected_order_arc_645  -15
    arc_0_14_19  out_degree_883  1
    arc_0_14_19  in_degree_914  1
    arc_0_14_19  original_T_including_depot_unload_936  2.9706418113632907e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_19  arc_capacity_644  1
    load_0_14_19  free_load_conservation_888  1
    load_0_14_19  free_load_conservation_918  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_20  arc_capacity_646  -20
    arc_0_14_20  connected_order_arc_647  -15
    arc_0_14_20  out_degree_883  1
    arc_0_14_20  in_degree_920  1
    arc_0_14_20  original_T_including_depot_unload_936  4.3129452098285111e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_20  arc_capacity_646  1
    load_0_14_20  free_load_conservation_888  1
    load_0_14_20  free_load_conservation_924  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_21  arc_capacity_648  -20
    arc_0_14_21  connected_order_arc_649  -15
    arc_0_14_21  out_degree_883  1
    arc_0_14_21  in_degree_926  1
    arc_0_14_21  original_T_including_depot_unload_936  3.2938591738444967e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_21  arc_capacity_648  1
    load_0_14_21  free_load_conservation_888  1
    load_0_14_21  free_load_conservation_930  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_0  arc_capacity_650  -20
    arc_0_15_0  depot_return_or_bypass_840  1
    arc_0_15_0  out_degree_889  1
    arc_0_15_0  original_T_including_depot_unload_936  7.2571167924583824e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_0  arc_capacity_650  1
    load_0_15_0  free_load_conservation_894  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_1  arc_capacity_651  -20
    arc_0_15_1  connected_order_arc_652  -15
    arc_0_15_1  in_degree_842  1
    arc_0_15_1  out_degree_889  1
    arc_0_15_1  original_T_including_depot_unload_936  8.7876124407720954e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_1  arc_capacity_651  1
    load_0_15_1  segment_load_conservation_845  -1
    load_0_15_1  segment_prefix_lb_846  1
    load_0_15_1  segment_prefix_ub_847  1
    load_0_15_1  free_load_conservation_894  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_2  arc_capacity_653  -20
    arc_0_15_2  connected_order_arc_654  -15
    arc_0_15_2  in_degree_849  1
    arc_0_15_2  out_degree_889  1
    arc_0_15_2  original_T_including_depot_unload_936  1.2724370432148053e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_2  arc_capacity_653  1
    load_0_15_2  segment_load_conservation_852  -1
    load_0_15_2  segment_prefix_lb_853  1
    load_0_15_2  segment_prefix_ub_854  1
    load_0_15_2  free_load_conservation_894  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_3  arc_capacity_655  -20
    arc_0_15_3  connected_order_arc_656  -15
    arc_0_15_3  in_degree_856  1
    arc_0_15_3  out_degree_889  1
    arc_0_15_3  original_T_including_depot_unload_936  7.9195606724980928e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_3  arc_capacity_655  1
    load_0_15_3  segment_load_conservation_859  -1
    load_0_15_3  segment_prefix_lb_860  1
    load_0_15_3  segment_prefix_ub_861  1
    load_0_15_3  free_load_conservation_894  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_4  arc_capacity_657  -20
    arc_0_15_4  connected_order_arc_658  -15
    arc_0_15_4  in_degree_863  1
    arc_0_15_4  out_degree_889  1
    arc_0_15_4  original_T_including_depot_unload_936  8.2707974701454475e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_4  arc_capacity_657  1
    load_0_15_4  segment_load_conservation_866  -1
    load_0_15_4  segment_prefix_lb_867  1
    load_0_15_4  segment_prefix_ub_868  1
    load_0_15_4  free_load_conservation_894  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_5  arc_capacity_659  -20
    arc_0_15_5  connected_order_arc_660  -15
    arc_0_15_5  in_degree_870  1
    arc_0_15_5  out_degree_889  1
    arc_0_15_5  original_T_including_depot_unload_936  5.2996691306068044e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_5  arc_capacity_659  1
    load_0_15_5  segment_load_conservation_873  -1
    load_0_15_5  segment_prefix_lb_874  1
    load_0_15_5  segment_prefix_ub_875  1
    load_0_15_5  free_load_conservation_894  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_6  arc_capacity_661  -20
    arc_0_15_6  connected_order_arc_662  -15
    arc_0_15_6  in_degree_877  1
    arc_0_15_6  out_degree_889  1
    arc_0_15_6  original_T_including_depot_unload_936  2.3059951477332697e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_6  arc_capacity_661  1
    load_0_15_6  segment_load_conservation_880  -1
    load_0_15_6  segment_prefix_lb_881  1
    load_0_15_6  segment_prefix_ub_882  1
    load_0_15_6  free_load_conservation_894  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_14  arc_capacity_663  -20
    arc_0_15_14  connected_order_arc_664  -15
    arc_0_15_14  in_degree_884  1
    arc_0_15_14  out_degree_889  1
    arc_0_15_14  original_T_including_depot_unload_936  2.1481294511470344e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_14  arc_capacity_663  1
    load_0_15_14  free_load_conservation_888  -1
    load_0_15_14  free_load_conservation_894  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_16  arc_capacity_665  -20
    arc_0_15_16  connected_order_arc_666  -15
    arc_0_15_16  out_degree_889  1
    arc_0_15_16  in_degree_896  1
    arc_0_15_16  original_T_including_depot_unload_936  1.3163662834239574e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_16  arc_capacity_665  1
    load_0_15_16  free_load_conservation_894  1
    load_0_15_16  free_load_conservation_900  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_17  arc_capacity_667  -20
    arc_0_15_17  connected_order_arc_668  -15
    arc_0_15_17  out_degree_889  1
    arc_0_15_17  in_degree_902  1
    arc_0_15_17  original_T_including_depot_unload_936  4.9831220386775891e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_17  arc_capacity_667  1
    load_0_15_17  free_load_conservation_894  1
    load_0_15_17  free_load_conservation_906  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_18  arc_capacity_669  -20
    arc_0_15_18  connected_order_arc_670  -15
    arc_0_15_18  out_degree_889  1
    arc_0_15_18  in_degree_908  1
    arc_0_15_18  original_T_including_depot_unload_936  7.9206888044020991e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_18  arc_capacity_669  1
    load_0_15_18  free_load_conservation_894  1
    load_0_15_18  free_load_conservation_912  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_19  arc_capacity_671  -20
    arc_0_15_19  connected_order_arc_672  -15
    arc_0_15_19  out_degree_889  1
    arc_0_15_19  in_degree_914  1
    arc_0_15_19  original_T_including_depot_unload_936  3.0055050459786975e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_19  arc_capacity_671  1
    load_0_15_19  free_load_conservation_894  1
    load_0_15_19  free_load_conservation_918  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_20  arc_capacity_673  -20
    arc_0_15_20  connected_order_arc_674  -15
    arc_0_15_20  out_degree_889  1
    arc_0_15_20  in_degree_920  1
    arc_0_15_20  original_T_including_depot_unload_936  6.4542450829473034e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_20  arc_capacity_673  1
    load_0_15_20  free_load_conservation_894  1
    load_0_15_20  free_load_conservation_924  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_21  arc_capacity_675  -20
    arc_0_15_21  connected_order_arc_676  -15
    arc_0_15_21  out_degree_889  1
    arc_0_15_21  in_degree_926  1
    arc_0_15_21  original_T_including_depot_unload_936  4.6276703023336785e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_21  arc_capacity_675  1
    load_0_15_21  free_load_conservation_894  1
    load_0_15_21  free_load_conservation_930  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_0  arc_capacity_677  -20
    arc_0_16_0  depot_return_or_bypass_840  1
    arc_0_16_0  out_degree_895  1
    arc_0_16_0  original_T_including_depot_unload_936  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_0  arc_capacity_677  1
    load_0_16_0  free_load_conservation_900  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_1  arc_capacity_678  -20
    arc_0_16_1  connected_order_arc_679  -15
    arc_0_16_1  in_degree_842  1
    arc_0_16_1  out_degree_895  1
    arc_0_16_1  original_T_including_depot_unload_936  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_1  arc_capacity_678  1
    load_0_16_1  segment_load_conservation_845  -1
    load_0_16_1  segment_prefix_lb_846  1
    load_0_16_1  segment_prefix_ub_847  1
    load_0_16_1  free_load_conservation_900  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_2  arc_capacity_680  -20
    arc_0_16_2  connected_order_arc_681  -15
    arc_0_16_2  in_degree_849  1
    arc_0_16_2  out_degree_895  1
    arc_0_16_2  original_T_including_depot_unload_936  1.7303231472353602e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_2  arc_capacity_680  1
    load_0_16_2  segment_load_conservation_852  -1
    load_0_16_2  segment_prefix_lb_853  1
    load_0_16_2  segment_prefix_ub_854  1
    load_0_16_2  free_load_conservation_900  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_3  arc_capacity_682  -20
    arc_0_16_3  connected_order_arc_683  -15
    arc_0_16_3  in_degree_856  1
    arc_0_16_3  out_degree_895  1
    arc_0_16_3  original_T_including_depot_unload_936  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_3  arc_capacity_682  1
    load_0_16_3  segment_load_conservation_859  -1
    load_0_16_3  segment_prefix_lb_860  1
    load_0_16_3  segment_prefix_ub_861  1
    load_0_16_3  free_load_conservation_900  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_4  arc_capacity_684  -20
    arc_0_16_4  connected_order_arc_685  -15
    arc_0_16_4  in_degree_863  1
    arc_0_16_4  out_degree_895  1
    arc_0_16_4  original_T_including_depot_unload_936  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_4  arc_capacity_684  1
    load_0_16_4  segment_load_conservation_866  -1
    load_0_16_4  segment_prefix_lb_867  1
    load_0_16_4  segment_prefix_ub_868  1
    load_0_16_4  free_load_conservation_900  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_5  arc_capacity_686  -20
    arc_0_16_5  connected_order_arc_687  -15
    arc_0_16_5  in_degree_870  1
    arc_0_16_5  out_degree_895  1
    arc_0_16_5  original_T_including_depot_unload_936  1.6292966848558842e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_5  arc_capacity_686  1
    load_0_16_5  segment_load_conservation_873  -1
    load_0_16_5  segment_prefix_lb_874  1
    load_0_16_5  segment_prefix_ub_875  1
    load_0_16_5  free_load_conservation_900  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_6  arc_capacity_688  -20
    arc_0_16_6  connected_order_arc_689  -15
    arc_0_16_6  in_degree_877  1
    arc_0_16_6  out_degree_895  1
    arc_0_16_6  original_T_including_depot_unload_936  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_6  arc_capacity_688  1
    load_0_16_6  segment_load_conservation_880  -1
    load_0_16_6  segment_prefix_lb_881  1
    load_0_16_6  segment_prefix_ub_882  1
    load_0_16_6  free_load_conservation_900  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_14  arc_capacity_690  -20
    arc_0_16_14  connected_order_arc_691  -15
    arc_0_16_14  in_degree_884  1
    arc_0_16_14  out_degree_895  1
    arc_0_16_14  original_T_including_depot_unload_936  1.3727638439182763e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_14  arc_capacity_690  1
    load_0_16_14  free_load_conservation_888  -1
    load_0_16_14  free_load_conservation_900  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_15  arc_capacity_692  -20
    arc_0_16_15  connected_order_arc_693  -15
    arc_0_16_15  in_degree_890  1
    arc_0_16_15  out_degree_895  1
    arc_0_16_15  original_T_including_depot_unload_936  1.3163662834239574e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_15  arc_capacity_692  1
    load_0_16_15  free_load_conservation_894  -1
    load_0_16_15  free_load_conservation_900  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_17  arc_capacity_694  -20
    arc_0_16_17  connected_order_arc_695  -15
    arc_0_16_17  out_degree_895  1
    arc_0_16_17  in_degree_902  1
    arc_0_16_17  original_T_including_depot_unload_936  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_17  arc_capacity_694  1
    load_0_16_17  free_load_conservation_900  1
    load_0_16_17  free_load_conservation_906  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_18  arc_capacity_696  -20
    arc_0_16_18  connected_order_arc_697  -15
    arc_0_16_18  out_degree_895  1
    arc_0_16_18  in_degree_908  1
    arc_0_16_18  original_T_including_depot_unload_936  1.9462564869425171e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_18  arc_capacity_696  1
    load_0_16_18  free_load_conservation_900  1
    load_0_16_18  free_load_conservation_912  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_19  arc_capacity_698  -20
    arc_0_16_19  connected_order_arc_699  -15
    arc_0_16_19  out_degree_895  1
    arc_0_16_19  in_degree_914  1
    arc_0_16_19  original_T_including_depot_unload_936  1075.72043838369
    MARKER    'MARKER'                 'INTEND'
    load_0_16_19  arc_capacity_698  1
    load_0_16_19  free_load_conservation_900  1
    load_0_16_19  free_load_conservation_918  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_20  arc_capacity_700  -20
    arc_0_16_20  connected_order_arc_701  -15
    arc_0_16_20  out_degree_895  1
    arc_0_16_20  in_degree_920  1
    arc_0_16_20  original_T_including_depot_unload_936  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_20  arc_capacity_700  1
    load_0_16_20  free_load_conservation_900  1
    load_0_16_20  free_load_conservation_924  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_21  arc_capacity_702  -20
    arc_0_16_21  connected_order_arc_703  -15
    arc_0_16_21  out_degree_895  1
    arc_0_16_21  in_degree_926  1
    arc_0_16_21  original_T_including_depot_unload_936  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_21  arc_capacity_702  1
    load_0_16_21  free_load_conservation_900  1
    load_0_16_21  free_load_conservation_930  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_0  arc_capacity_704  -20
    arc_0_17_0  depot_return_or_bypass_840  1
    arc_0_17_0  out_degree_901  1
    arc_0_17_0  original_T_including_depot_unload_936  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_0  arc_capacity_704  1
    load_0_17_0  free_load_conservation_906  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_1  arc_capacity_705  -20
    arc_0_17_1  connected_order_arc_706  -15
    arc_0_17_1  in_degree_842  1
    arc_0_17_1  out_degree_901  1
    arc_0_17_1  original_T_including_depot_unload_936  4.2733962838090457e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_1  arc_capacity_705  1
    load_0_17_1  segment_load_conservation_845  -1
    load_0_17_1  segment_prefix_lb_846  1
    load_0_17_1  segment_prefix_ub_847  1
    load_0_17_1  free_load_conservation_906  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_2  arc_capacity_707  -20
    arc_0_17_2  connected_order_arc_708  -15
    arc_0_17_2  in_degree_849  1
    arc_0_17_2  out_degree_901  1
    arc_0_17_2  original_T_including_depot_unload_936  7.7772825846942942e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_2  arc_capacity_707  1
    load_0_17_2  segment_load_conservation_852  -1
    load_0_17_2  segment_prefix_lb_853  1
    load_0_17_2  segment_prefix_ub_854  1
    load_0_17_2  free_load_conservation_906  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_3  arc_capacity_709  -20
    arc_0_17_3  connected_order_arc_710  -15
    arc_0_17_3  in_degree_856  1
    arc_0_17_3  out_degree_901  1
    arc_0_17_3  original_T_including_depot_unload_936  2.9376641610717382e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_3  arc_capacity_709  1
    load_0_17_3  segment_load_conservation_859  -1
    load_0_17_3  segment_prefix_lb_860  1
    load_0_17_3  segment_prefix_ub_861  1
    load_0_17_3  free_load_conservation_906  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_4  arc_capacity_711  -20
    arc_0_17_4  connected_order_arc_712  -15
    arc_0_17_4  in_degree_863  1
    arc_0_17_4  out_degree_901  1
    arc_0_17_4  original_T_including_depot_unload_936  3.9864800790786632e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_4  arc_capacity_711  1
    load_0_17_4  segment_load_conservation_866  -1
    load_0_17_4  segment_prefix_lb_867  1
    load_0_17_4  segment_prefix_ub_868  1
    load_0_17_4  free_load_conservation_906  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_5  arc_capacity_713  -20
    arc_0_17_5  connected_order_arc_714  -15
    arc_0_17_5  in_degree_870  1
    arc_0_17_5  out_degree_901  1
    arc_0_17_5  original_T_including_depot_unload_936  2.5147997402163108e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_5  arc_capacity_713  1
    load_0_17_5  segment_load_conservation_873  -1
    load_0_17_5  segment_prefix_lb_874  1
    load_0_17_5  segment_prefix_ub_875  1
    load_0_17_5  free_load_conservation_906  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_6  arc_capacity_715  -20
    arc_0_17_6  connected_order_arc_716  -15
    arc_0_17_6  in_degree_877  1
    arc_0_17_6  out_degree_901  1
    arc_0_17_6  original_T_including_depot_unload_936  6.3111682574558915e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_6  arc_capacity_715  1
    load_0_17_6  segment_load_conservation_880  -1
    load_0_17_6  segment_prefix_lb_881  1
    load_0_17_6  segment_prefix_ub_882  1
    load_0_17_6  free_load_conservation_906  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_14  arc_capacity_717  -20
    arc_0_17_14  connected_order_arc_718  -15
    arc_0_17_14  in_degree_884  1
    arc_0_17_14  out_degree_901  1
    arc_0_17_14  original_T_including_depot_unload_936  2.9098466309579254e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_14  arc_capacity_717  1
    load_0_17_14  free_load_conservation_888  -1
    load_0_17_14  free_load_conservation_906  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_15  arc_capacity_719  -20
    arc_0_17_15  connected_order_arc_720  -15
    arc_0_17_15  in_degree_890  1
    arc_0_17_15  out_degree_901  1
    arc_0_17_15  original_T_including_depot_unload_936  4.9831220386775891e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_15  arc_capacity_719  1
    load_0_17_15  free_load_conservation_894  -1
    load_0_17_15  free_load_conservation_906  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_16  arc_capacity_721  -20
    arc_0_17_16  connected_order_arc_722  -15
    arc_0_17_16  in_degree_896  1
    arc_0_17_16  out_degree_901  1
    arc_0_17_16  original_T_including_depot_unload_936  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_16  arc_capacity_721  1
    load_0_17_16  free_load_conservation_900  -1
    load_0_17_16  free_load_conservation_906  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_18  arc_capacity_723  -20
    arc_0_17_18  connected_order_arc_724  -15
    arc_0_17_18  out_degree_901  1
    arc_0_17_18  in_degree_908  1
    arc_0_17_18  original_T_including_depot_unload_936  5.5448403235604167e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_18  arc_capacity_723  1
    load_0_17_18  free_load_conservation_906  1
    load_0_17_18  free_load_conservation_912  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_19  arc_capacity_725  -20
    arc_0_17_19  connected_order_arc_726  -15
    arc_0_17_19  out_degree_901  1
    arc_0_17_19  in_degree_914  1
    arc_0_17_19  original_T_including_depot_unload_936  4.1665889045115779e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_19  arc_capacity_725  1
    load_0_17_19  free_load_conservation_906  1
    load_0_17_19  free_load_conservation_918  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_20  arc_capacity_727  -20
    arc_0_17_20  connected_order_arc_728  -15
    arc_0_17_20  out_degree_901  1
    arc_0_17_20  in_degree_920  1
    arc_0_17_20  original_T_including_depot_unload_936  1.6597164064313077e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_20  arc_capacity_727  1
    load_0_17_20  free_load_conservation_906  1
    load_0_17_20  free_load_conservation_924  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_21  arc_capacity_729  -20
    arc_0_17_21  connected_order_arc_730  -15
    arc_0_17_21  out_degree_901  1
    arc_0_17_21  in_degree_926  1
    arc_0_17_21  original_T_including_depot_unload_936  2.4083746437975364e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_21  arc_capacity_729  1
    load_0_17_21  free_load_conservation_906  1
    load_0_17_21  free_load_conservation_930  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_0  arc_capacity_731  -20
    arc_0_18_0  depot_return_or_bypass_840  1
    arc_0_18_0  out_degree_907  1
    arc_0_18_0  original_T_including_depot_unload_936  9.5330620720858735e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_0  arc_capacity_731  1
    load_0_18_0  free_load_conservation_912  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_1  arc_capacity_732  -20
    arc_0_18_1  connected_order_arc_733  -15
    arc_0_18_1  in_degree_842  1
    arc_0_18_1  out_degree_907  1
    arc_0_18_1  original_T_including_depot_unload_936  8.4968861461374138e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_1  arc_capacity_732  1
    load_0_18_1  segment_load_conservation_845  -1
    load_0_18_1  segment_prefix_lb_846  1
    load_0_18_1  segment_prefix_ub_847  1
    load_0_18_1  free_load_conservation_912  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_2  arc_capacity_734  -20
    arc_0_18_2  connected_order_arc_735  -15
    arc_0_18_2  in_degree_849  1
    arc_0_18_2  out_degree_907  1
    arc_0_18_2  original_T_including_depot_unload_936  9.6598937061987863e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_2  arc_capacity_734  1
    load_0_18_2  segment_load_conservation_852  -1
    load_0_18_2  segment_prefix_lb_853  1
    load_0_18_2  segment_prefix_ub_854  1
    load_0_18_2  free_load_conservation_912  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_3  arc_capacity_736  -20
    arc_0_18_3  connected_order_arc_737  -15
    arc_0_18_3  in_degree_856  1
    arc_0_18_3  out_degree_907  1
    arc_0_18_3  original_T_including_depot_unload_936  5.8292761965990132e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_3  arc_capacity_736  1
    load_0_18_3  segment_load_conservation_859  -1
    load_0_18_3  segment_prefix_lb_860  1
    load_0_18_3  segment_prefix_ub_861  1
    load_0_18_3  free_load_conservation_912  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_4  arc_capacity_738  -20
    arc_0_18_4  connected_order_arc_739  -15
    arc_0_18_4  in_degree_863  1
    arc_0_18_4  out_degree_907  1
    arc_0_18_4  original_T_including_depot_unload_936  3.3469758905462760e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_4  arc_capacity_738  1
    load_0_18_4  segment_load_conservation_866  -1
    load_0_18_4  segment_prefix_lb_867  1
    load_0_18_4  segment_prefix_ub_868  1
    load_0_18_4  free_load_conservation_912  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_5  arc_capacity_740  -20
    arc_0_18_5  connected_order_arc_741  -15
    arc_0_18_5  in_degree_870  1
    arc_0_18_5  out_degree_907  1
    arc_0_18_5  original_T_including_depot_unload_936  3.1728416035596246e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_5  arc_capacity_740  1
    load_0_18_5  segment_load_conservation_873  -1
    load_0_18_5  segment_prefix_lb_874  1
    load_0_18_5  segment_prefix_ub_875  1
    load_0_18_5  free_load_conservation_912  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_6  arc_capacity_742  -20
    arc_0_18_6  connected_order_arc_743  -15
    arc_0_18_6  in_degree_877  1
    arc_0_18_6  out_degree_907  1
    arc_0_18_6  original_T_including_depot_unload_936  1.0105932041904148e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_6  arc_capacity_742  1
    load_0_18_6  segment_load_conservation_880  -1
    load_0_18_6  segment_prefix_lb_881  1
    load_0_18_6  segment_prefix_ub_882  1
    load_0_18_6  free_load_conservation_912  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_14  arc_capacity_744  -20
    arc_0_18_14  connected_order_arc_745  -15
    arc_0_18_14  in_degree_884  1
    arc_0_18_14  out_degree_907  1
    arc_0_18_14  original_T_including_depot_unload_936  6.2159179673866879e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_14  arc_capacity_744  1
    load_0_18_14  free_load_conservation_888  -1
    load_0_18_14  free_load_conservation_912  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_15  arc_capacity_746  -20
    arc_0_18_15  connected_order_arc_747  -15
    arc_0_18_15  in_degree_890  1
    arc_0_18_15  out_degree_907  1
    arc_0_18_15  original_T_including_depot_unload_936  7.9206888044020991e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_15  arc_capacity_746  1
    load_0_18_15  free_load_conservation_894  -1
    load_0_18_15  free_load_conservation_912  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_16  arc_capacity_748  -20
    arc_0_18_16  connected_order_arc_749  -15
    arc_0_18_16  in_degree_896  1
    arc_0_18_16  out_degree_907  1
    arc_0_18_16  original_T_including_depot_unload_936  1.9462564869425171e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_16  arc_capacity_748  1
    load_0_18_16  free_load_conservation_900  -1
    load_0_18_16  free_load_conservation_912  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_17  arc_capacity_750  -20
    arc_0_18_17  connected_order_arc_751  -15
    arc_0_18_17  in_degree_902  1
    arc_0_18_17  out_degree_907  1
    arc_0_18_17  original_T_including_depot_unload_936  5.5448403235604167e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_17  arc_capacity_750  1
    load_0_18_17  free_load_conservation_906  -1
    load_0_18_17  free_load_conservation_912  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_19  arc_capacity_752  -20
    arc_0_18_19  connected_order_arc_753  -15
    arc_0_18_19  out_degree_907  1
    arc_0_18_19  in_degree_914  1
    arc_0_18_19  original_T_including_depot_unload_936  897.031483121361
    MARKER    'MARKER'                 'INTEND'
    load_0_18_19  arc_capacity_752  1
    load_0_18_19  free_load_conservation_912  1
    load_0_18_19  free_load_conservation_918  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_20  arc_capacity_754  -20
    arc_0_18_20  connected_order_arc_755  -15
    arc_0_18_20  out_degree_907  1
    arc_0_18_20  in_degree_920  1
    arc_0_18_20  original_T_including_depot_unload_936  4.6772747357218117e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_20  arc_capacity_754  1
    load_0_18_20  free_load_conservation_912  1
    load_0_18_20  free_load_conservation_924  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_21  arc_capacity_756  -20
    arc_0_18_21  connected_order_arc_757  -15
    arc_0_18_21  out_degree_907  1
    arc_0_18_21  in_degree_926  1
    arc_0_18_21  original_T_including_depot_unload_936  7.8947565022471792e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_21  arc_capacity_756  1
    load_0_18_21  free_load_conservation_912  1
    load_0_18_21  free_load_conservation_930  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_0  arc_capacity_758  -20
    arc_0_19_0  depot_return_or_bypass_840  1
    arc_0_19_0  out_degree_913  1
    arc_0_19_0  original_T_including_depot_unload_936  4.6364706268001146e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_0  arc_capacity_758  1
    load_0_19_0  free_load_conservation_918  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_1  arc_capacity_759  -20
    arc_0_19_1  connected_order_arc_760  -15
    arc_0_19_1  in_degree_842  1
    arc_0_19_1  out_degree_913  1
    arc_0_19_1  original_T_including_depot_unload_936  6.7517249538835438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_1  arc_capacity_759  1
    load_0_19_1  segment_load_conservation_845  -1
    load_0_19_1  segment_prefix_lb_846  1
    load_0_19_1  segment_prefix_ub_847  1
    load_0_19_1  free_load_conservation_918  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_2  arc_capacity_761  -20
    arc_0_19_2  connected_order_arc_762  -15
    arc_0_19_2  in_degree_849  1
    arc_0_19_2  out_degree_913  1
    arc_0_19_2  original_T_including_depot_unload_936  1.1090437276384578e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_2  arc_capacity_761  1
    load_0_19_2  segment_load_conservation_852  -1
    load_0_19_2  segment_prefix_lb_853  1
    load_0_19_2  segment_prefix_ub_854  1
    load_0_19_2  free_load_conservation_918  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_3  arc_capacity_763  -20
    arc_0_19_3  connected_order_arc_764  -15
    arc_0_19_3  in_degree_856  1
    arc_0_19_3  out_degree_913  1
    arc_0_19_3  original_T_including_depot_unload_936  6.7868877694996661e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_3  arc_capacity_763  1
    load_0_19_3  segment_load_conservation_859  -1
    load_0_19_3  segment_prefix_lb_860  1
    load_0_19_3  segment_prefix_ub_861  1
    load_0_19_3  free_load_conservation_918  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_4  arc_capacity_765  -20
    arc_0_19_4  connected_order_arc_766  -15
    arc_0_19_4  in_degree_863  1
    arc_0_19_4  out_degree_913  1
    arc_0_19_4  original_T_including_depot_unload_936  8.1289340937717509e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_4  arc_capacity_765  1
    load_0_19_4  segment_load_conservation_866  -1
    load_0_19_4  segment_prefix_lb_867  1
    load_0_19_4  segment_prefix_ub_868  1
    load_0_19_4  free_load_conservation_918  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_5  arc_capacity_767  -20
    arc_0_19_5  connected_order_arc_768  -15
    arc_0_19_5  in_degree_870  1
    arc_0_19_5  out_degree_913  1
    arc_0_19_5  original_T_including_depot_unload_936  5.8442598457899078e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_5  arc_capacity_767  1
    load_0_19_5  segment_load_conservation_873  -1
    load_0_19_5  segment_prefix_lb_874  1
    load_0_19_5  segment_prefix_ub_875  1
    load_0_19_5  free_load_conservation_918  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_6  arc_capacity_769  -20
    arc_0_19_6  connected_order_arc_770  -15
    arc_0_19_6  in_degree_877  1
    arc_0_19_6  out_degree_913  1
    arc_0_19_6  original_T_including_depot_unload_936  2.6602972191926557e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_6  arc_capacity_769  1
    load_0_19_6  segment_load_conservation_880  -1
    load_0_19_6  segment_prefix_lb_881  1
    load_0_19_6  segment_prefix_ub_882  1
    load_0_19_6  free_load_conservation_918  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_14  arc_capacity_771  -20
    arc_0_19_14  connected_order_arc_772  -15
    arc_0_19_14  in_degree_884  1
    arc_0_19_14  out_degree_913  1
    arc_0_19_14  original_T_including_depot_unload_936  2.9706418113632907e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_14  arc_capacity_771  1
    load_0_19_14  free_load_conservation_888  -1
    load_0_19_14  free_load_conservation_918  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_15  arc_capacity_773  -20
    arc_0_19_15  connected_order_arc_774  -15
    arc_0_19_15  in_degree_890  1
    arc_0_19_15  out_degree_913  1
    arc_0_19_15  original_T_including_depot_unload_936  3.0055050459786975e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_15  arc_capacity_773  1
    load_0_19_15  free_load_conservation_894  -1
    load_0_19_15  free_load_conservation_918  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_16  arc_capacity_775  -20
    arc_0_19_16  connected_order_arc_776  -15
    arc_0_19_16  in_degree_896  1
    arc_0_19_16  out_degree_913  1
    arc_0_19_16  original_T_including_depot_unload_936  1075.72043838369
    MARKER    'MARKER'                 'INTEND'
    load_0_19_16  arc_capacity_775  1
    load_0_19_16  free_load_conservation_900  -1
    load_0_19_16  free_load_conservation_918  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_17  arc_capacity_777  -20
    arc_0_19_17  connected_order_arc_778  -15
    arc_0_19_17  in_degree_902  1
    arc_0_19_17  out_degree_913  1
    arc_0_19_17  original_T_including_depot_unload_936  4.1665889045115779e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_17  arc_capacity_777  1
    load_0_19_17  free_load_conservation_906  -1
    load_0_19_17  free_load_conservation_918  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_18  arc_capacity_779  -20
    arc_0_19_18  connected_order_arc_780  -15
    arc_0_19_18  in_degree_908  1
    arc_0_19_18  out_degree_913  1
    arc_0_19_18  original_T_including_depot_unload_936  897.031483121361
    MARKER    'MARKER'                 'INTEND'
    load_0_19_18  arc_capacity_779  1
    load_0_19_18  free_load_conservation_912  -1
    load_0_19_18  free_load_conservation_918  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_20  arc_capacity_781  -20
    arc_0_19_20  connected_order_arc_782  -15
    arc_0_19_20  out_degree_913  1
    arc_0_19_20  in_degree_920  1
    arc_0_19_20  original_T_including_depot_unload_936  5.8212369880329140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_20  arc_capacity_781  1
    load_0_19_20  free_load_conservation_918  1
    load_0_19_20  free_load_conservation_924  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_21  arc_capacity_783  -20
    arc_0_19_21  connected_order_arc_784  -15
    arc_0_19_21  out_degree_913  1
    arc_0_19_21  in_degree_926  1
    arc_0_19_21  original_T_including_depot_unload_936  2.4191291221621205e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_21  arc_capacity_783  1
    load_0_19_21  free_load_conservation_918  1
    load_0_19_21  free_load_conservation_930  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_0  arc_capacity_785  -20
    arc_0_20_0  depot_return_or_bypass_840  1
    arc_0_20_0  out_degree_919  1
    arc_0_20_0  original_T_including_depot_unload_936  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_0  arc_capacity_785  1
    load_0_20_0  free_load_conservation_924  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_1  arc_capacity_786  -20
    arc_0_20_1  connected_order_arc_787  -15
    arc_0_20_1  in_degree_842  1
    arc_0_20_1  out_degree_919  1
    arc_0_20_1  original_T_including_depot_unload_936  3.9758967496529505e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_1  arc_capacity_786  1
    load_0_20_1  segment_load_conservation_845  -1
    load_0_20_1  segment_prefix_lb_846  1
    load_0_20_1  segment_prefix_ub_847  1
    load_0_20_1  free_load_conservation_924  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_2  arc_capacity_788  -20
    arc_0_20_2  connected_order_arc_789  -15
    arc_0_20_2  in_degree_849  1
    arc_0_20_2  out_degree_919  1
    arc_0_20_2  original_T_including_depot_unload_936  6.6047504008669523e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_2  arc_capacity_788  1
    load_0_20_2  segment_load_conservation_852  -1
    load_0_20_2  segment_prefix_lb_853  1
    load_0_20_2  segment_prefix_ub_854  1
    load_0_20_2  free_load_conservation_924  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_3  arc_capacity_790  -20
    arc_0_20_3  connected_order_arc_791  -15
    arc_0_20_3  in_degree_856  1
    arc_0_20_3  out_degree_919  1
    arc_0_20_3  original_T_including_depot_unload_936  1.7053268374267958e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_3  arc_capacity_790  1
    load_0_20_3  segment_load_conservation_859  -1
    load_0_20_3  segment_prefix_lb_860  1
    load_0_20_3  segment_prefix_ub_861  1
    load_0_20_3  free_load_conservation_924  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_4  arc_capacity_792  -20
    arc_0_20_4  connected_order_arc_793  -15
    arc_0_20_4  in_degree_863  1
    arc_0_20_4  out_degree_919  1
    arc_0_20_4  original_T_including_depot_unload_936  2.4111148152767828e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_4  arc_capacity_792  1
    load_0_20_4  segment_load_conservation_866  -1
    load_0_20_4  segment_prefix_lb_867  1
    load_0_20_4  segment_prefix_ub_868  1
    load_0_20_4  free_load_conservation_924  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_5  arc_capacity_794  -20
    arc_0_20_5  connected_order_arc_795  -15
    arc_0_20_5  in_degree_870  1
    arc_0_20_5  out_degree_919  1
    arc_0_20_5  original_T_including_depot_unload_936  2.3649901674897566e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_5  arc_capacity_794  1
    load_0_20_5  segment_load_conservation_873  -1
    load_0_20_5  segment_prefix_lb_874  1
    load_0_20_5  segment_prefix_ub_875  1
    load_0_20_5  free_load_conservation_924  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_6  arc_capacity_796  -20
    arc_0_20_6  connected_order_arc_797  -15
    arc_0_20_6  in_degree_877  1
    arc_0_20_6  out_degree_919  1
    arc_0_20_6  original_T_including_depot_unload_936  7.9403551275216375e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_6  arc_capacity_796  1
    load_0_20_6  segment_load_conservation_880  -1
    load_0_20_6  segment_prefix_lb_881  1
    load_0_20_6  segment_prefix_ub_882  1
    load_0_20_6  free_load_conservation_924  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_14  arc_capacity_798  -20
    arc_0_20_14  connected_order_arc_799  -15
    arc_0_20_14  in_degree_884  1
    arc_0_20_14  out_degree_919  1
    arc_0_20_14  original_T_including_depot_unload_936  4.3129452098285111e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_14  arc_capacity_798  1
    load_0_20_14  free_load_conservation_888  -1
    load_0_20_14  free_load_conservation_924  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_15  arc_capacity_800  -20
    arc_0_20_15  connected_order_arc_801  -15
    arc_0_20_15  in_degree_890  1
    arc_0_20_15  out_degree_919  1
    arc_0_20_15  original_T_including_depot_unload_936  6.4542450829473034e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_15  arc_capacity_800  1
    load_0_20_15  free_load_conservation_894  -1
    load_0_20_15  free_load_conservation_924  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_16  arc_capacity_802  -20
    arc_0_20_16  connected_order_arc_803  -15
    arc_0_20_16  in_degree_896  1
    arc_0_20_16  out_degree_919  1
    arc_0_20_16  original_T_including_depot_unload_936  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_16  arc_capacity_802  1
    load_0_20_16  free_load_conservation_900  -1
    load_0_20_16  free_load_conservation_924  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_17  arc_capacity_804  -20
    arc_0_20_17  connected_order_arc_805  -15
    arc_0_20_17  in_degree_902  1
    arc_0_20_17  out_degree_919  1
    arc_0_20_17  original_T_including_depot_unload_936  1.6597164064313077e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_17  arc_capacity_804  1
    load_0_20_17  free_load_conservation_906  -1
    load_0_20_17  free_load_conservation_924  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_18  arc_capacity_806  -20
    arc_0_20_18  connected_order_arc_807  -15
    arc_0_20_18  in_degree_908  1
    arc_0_20_18  out_degree_919  1
    arc_0_20_18  original_T_including_depot_unload_936  4.6772747357218117e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_18  arc_capacity_806  1
    load_0_20_18  free_load_conservation_912  -1
    load_0_20_18  free_load_conservation_924  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_19  arc_capacity_808  -20
    arc_0_20_19  connected_order_arc_809  -15
    arc_0_20_19  in_degree_914  1
    arc_0_20_19  out_degree_919  1
    arc_0_20_19  original_T_including_depot_unload_936  5.8212369880329140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_19  arc_capacity_808  1
    load_0_20_19  free_load_conservation_918  -1
    load_0_20_19  free_load_conservation_924  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_21  arc_capacity_810  -20
    arc_0_20_21  connected_order_arc_811  -15
    arc_0_20_21  out_degree_919  1
    arc_0_20_21  in_degree_926  1
    arc_0_20_21  original_T_including_depot_unload_936  3.8790073962518773e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_21  arc_capacity_810  1
    load_0_20_21  free_load_conservation_924  1
    load_0_20_21  free_load_conservation_930  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_0  arc_capacity_812  -20
    arc_0_21_0  depot_return_or_bypass_840  1
    arc_0_21_0  out_degree_925  1
    arc_0_21_0  original_T_including_depot_unload_936  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_0  arc_capacity_812  1
    load_0_21_0  free_load_conservation_930  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_1  arc_capacity_813  -20
    arc_0_21_1  connected_order_arc_814  -15
    arc_0_21_1  in_degree_842  1
    arc_0_21_1  out_degree_925  1
    arc_0_21_1  original_T_including_depot_unload_936  4.3618991857210159e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_1  arc_capacity_813  1
    load_0_21_1  segment_load_conservation_845  -1
    load_0_21_1  segment_prefix_lb_846  1
    load_0_21_1  segment_prefix_ub_847  1
    load_0_21_1  free_load_conservation_930  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_2  arc_capacity_815  -20
    arc_0_21_2  connected_order_arc_816  -15
    arc_0_21_2  in_degree_849  1
    arc_0_21_2  out_degree_925  1
    arc_0_21_2  original_T_including_depot_unload_936  8.6713096341893186e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_2  arc_capacity_815  1
    load_0_21_2  segment_load_conservation_852  -1
    load_0_21_2  segment_prefix_lb_853  1
    load_0_21_2  segment_prefix_ub_854  1
    load_0_21_2  free_load_conservation_930  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_3  arc_capacity_817  -20
    arc_0_21_3  connected_order_arc_818  -15
    arc_0_21_3  in_degree_856  1
    arc_0_21_3  out_degree_925  1
    arc_0_21_3  original_T_including_depot_unload_936  4.5094949828949649e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_3  arc_capacity_817  1
    load_0_21_3  segment_load_conservation_859  -1
    load_0_21_3  segment_prefix_lb_860  1
    load_0_21_3  segment_prefix_ub_861  1
    load_0_21_3  free_load_conservation_930  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_4  arc_capacity_819  -20
    arc_0_21_4  connected_order_arc_820  -15
    arc_0_21_4  in_degree_863  1
    arc_0_21_4  out_degree_925  1
    arc_0_21_4  original_T_including_depot_unload_936  6.2886632383683013e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_4  arc_capacity_819  1
    load_0_21_4  segment_load_conservation_866  -1
    load_0_21_4  segment_prefix_lb_867  1
    load_0_21_4  segment_prefix_ub_868  1
    load_0_21_4  free_load_conservation_930  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_5  arc_capacity_821  -20
    arc_0_21_5  connected_order_arc_822  -15
    arc_0_21_5  in_degree_870  1
    arc_0_21_5  out_degree_925  1
    arc_0_21_5  original_T_including_depot_unload_936  4.7597588586788925e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_5  arc_capacity_821  1
    load_0_21_5  segment_load_conservation_873  -1
    load_0_21_5  segment_prefix_lb_874  1
    load_0_21_5  segment_prefix_ub_875  1
    load_0_21_5  free_load_conservation_930  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_6  arc_capacity_823  -20
    arc_0_21_6  connected_order_arc_824  -15
    arc_0_21_6  in_degree_877  1
    arc_0_21_6  out_degree_925  1
    arc_0_21_6  original_T_including_depot_unload_936  5.0315495126439691e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_6  arc_capacity_823  1
    load_0_21_6  segment_load_conservation_880  -1
    load_0_21_6  segment_prefix_lb_881  1
    load_0_21_6  segment_prefix_ub_882  1
    load_0_21_6  free_load_conservation_930  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_14  arc_capacity_825  -20
    arc_0_21_14  connected_order_arc_826  -15
    arc_0_21_14  in_degree_884  1
    arc_0_21_14  out_degree_925  1
    arc_0_21_14  original_T_including_depot_unload_936  3.2938591738444967e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_14  arc_capacity_825  1
    load_0_21_14  free_load_conservation_888  -1
    load_0_21_14  free_load_conservation_930  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_15  arc_capacity_827  -20
    arc_0_21_15  connected_order_arc_828  -15
    arc_0_21_15  in_degree_890  1
    arc_0_21_15  out_degree_925  1
    arc_0_21_15  original_T_including_depot_unload_936  4.6276703023336785e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_15  arc_capacity_827  1
    load_0_21_15  free_load_conservation_894  -1
    load_0_21_15  free_load_conservation_930  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_16  arc_capacity_829  -20
    arc_0_21_16  connected_order_arc_830  -15
    arc_0_21_16  in_degree_896  1
    arc_0_21_16  out_degree_925  1
    arc_0_21_16  original_T_including_depot_unload_936  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_16  arc_capacity_829  1
    load_0_21_16  free_load_conservation_900  -1
    load_0_21_16  free_load_conservation_930  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_17  arc_capacity_831  -20
    arc_0_21_17  connected_order_arc_832  -15
    arc_0_21_17  in_degree_902  1
    arc_0_21_17  out_degree_925  1
    arc_0_21_17  original_T_including_depot_unload_936  2.4083746437975364e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_17  arc_capacity_831  1
    load_0_21_17  free_load_conservation_906  -1
    load_0_21_17  free_load_conservation_930  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_18  arc_capacity_833  -20
    arc_0_21_18  connected_order_arc_834  -15
    arc_0_21_18  in_degree_908  1
    arc_0_21_18  out_degree_925  1
    arc_0_21_18  original_T_including_depot_unload_936  7.8947565022471792e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_18  arc_capacity_833  1
    load_0_21_18  free_load_conservation_912  -1
    load_0_21_18  free_load_conservation_930  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_19  arc_capacity_835  -20
    arc_0_21_19  connected_order_arc_836  -15
    arc_0_21_19  in_degree_914  1
    arc_0_21_19  out_degree_925  1
    arc_0_21_19  original_T_including_depot_unload_936  2.4191291221621205e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_19  arc_capacity_835  1
    load_0_21_19  free_load_conservation_918  -1
    load_0_21_19  free_load_conservation_930  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_20  arc_capacity_837  -20
    arc_0_21_20  connected_order_arc_838  -15
    arc_0_21_20  in_degree_920  1
    arc_0_21_20  out_degree_925  1
    arc_0_21_20  original_T_including_depot_unload_936  3.8790073962518773e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_20  arc_capacity_837  1
    load_0_21_20  free_load_conservation_924  -1
    load_0_21_20  free_load_conservation_930  1
    visit_1_7  out_degree_1228  -1
    visit_1_7  in_degree_1229  -1
    visit_1_7  order_active_lb_1230  -1
    visit_1_7  order_active_ub_1231  -12
    order_1_7  connected_order_arc_952  -1
    order_1_7  connected_order_arc_954  -1
    order_1_7  connected_order_arc_956  -1
    order_1_7  connected_order_arc_958  -1
    order_1_7  connected_order_arc_960  -1
    order_1_7  connected_order_arc_962  -1
    order_1_7  connected_order_arc_964  -1
    order_1_7  connected_order_arc_966  -1
    order_1_7  connected_order_arc_968  -1
    order_1_7  connected_order_arc_970  -1
    order_1_7  connected_order_arc_972  -1
    order_1_7  connected_order_arc_975  1
    order_1_7  connected_order_arc_998  1
    order_1_7  connected_order_arc_1021  1
    order_1_7  connected_order_arc_1044  1
    order_1_7  connected_order_arc_1067  1
    order_1_7  connected_order_arc_1090  1
    order_1_7  connected_order_arc_1113  1
    order_1_7  connected_order_arc_1136  1
    order_1_7  connected_order_arc_1159  1
    order_1_7  connected_order_arc_1182  1
    order_1_7  connected_order_arc_1205  1
    order_1_7  order_active_lb_1230  1
    order_1_7  order_active_ub_1231  1
    order_1_7  fixed_segment_relative_order_1304  -1
    visit_1_8  out_degree_1235  -1
    visit_1_8  in_degree_1236  -1
    visit_1_8  order_active_lb_1237  -1
    visit_1_8  order_active_ub_1238  -12
    order_1_8  connected_order_arc_952  1
    order_1_8  connected_order_arc_975  -1
    order_1_8  connected_order_arc_977  -1
    order_1_8  connected_order_arc_979  -1
    order_1_8  connected_order_arc_981  -1
    order_1_8  connected_order_arc_983  -1
    order_1_8  connected_order_arc_985  -1
    order_1_8  connected_order_arc_987  -1
    order_1_8  connected_order_arc_989  -1
    order_1_8  connected_order_arc_991  -1
    order_1_8  connected_order_arc_993  -1
    order_1_8  connected_order_arc_995  -1
    order_1_8  connected_order_arc_1000  1
    order_1_8  connected_order_arc_1023  1
    order_1_8  connected_order_arc_1046  1
    order_1_8  connected_order_arc_1069  1
    order_1_8  connected_order_arc_1092  1
    order_1_8  connected_order_arc_1115  1
    order_1_8  connected_order_arc_1138  1
    order_1_8  connected_order_arc_1161  1
    order_1_8  connected_order_arc_1184  1
    order_1_8  connected_order_arc_1207  1
    order_1_8  order_active_lb_1237  1
    order_1_8  order_active_ub_1238  1
    order_1_8  fixed_segment_relative_order_1304  1
    order_1_8  fixed_segment_relative_order_1305  -1
    visit_1_9  out_degree_1242  -1
    visit_1_9  in_degree_1243  -1
    visit_1_9  order_active_lb_1244  -1
    visit_1_9  order_active_ub_1245  -12
    order_1_9  connected_order_arc_954  1
    order_1_9  connected_order_arc_977  1
    order_1_9  connected_order_arc_998  -1
    order_1_9  connected_order_arc_1000  -1
    order_1_9  connected_order_arc_1002  -1
    order_1_9  connected_order_arc_1004  -1
    order_1_9  connected_order_arc_1006  -1
    order_1_9  connected_order_arc_1008  -1
    order_1_9  connected_order_arc_1010  -1
    order_1_9  connected_order_arc_1012  -1
    order_1_9  connected_order_arc_1014  -1
    order_1_9  connected_order_arc_1016  -1
    order_1_9  connected_order_arc_1018  -1
    order_1_9  connected_order_arc_1025  1
    order_1_9  connected_order_arc_1048  1
    order_1_9  connected_order_arc_1071  1
    order_1_9  connected_order_arc_1094  1
    order_1_9  connected_order_arc_1117  1
    order_1_9  connected_order_arc_1140  1
    order_1_9  connected_order_arc_1163  1
    order_1_9  connected_order_arc_1186  1
    order_1_9  connected_order_arc_1209  1
    order_1_9  order_active_lb_1244  1
    order_1_9  order_active_ub_1245  1
    order_1_9  fixed_segment_relative_order_1305  1
    order_1_9  fixed_segment_relative_order_1306  -1
    visit_1_10  out_degree_1249  -1
    visit_1_10  in_degree_1250  -1
    visit_1_10  order_active_lb_1251  -1
    visit_1_10  order_active_ub_1252  -12
    order_1_10  connected_order_arc_956  1
    order_1_10  connected_order_arc_979  1
    order_1_10  connected_order_arc_1002  1
    order_1_10  connected_order_arc_1021  -1
    order_1_10  connected_order_arc_1023  -1
    order_1_10  connected_order_arc_1025  -1
    order_1_10  connected_order_arc_1027  -1
    order_1_10  connected_order_arc_1029  -1
    order_1_10  connected_order_arc_1031  -1
    order_1_10  connected_order_arc_1033  -1
    order_1_10  connected_order_arc_1035  -1
    order_1_10  connected_order_arc_1037  -1
    order_1_10  connected_order_arc_1039  -1
    order_1_10  connected_order_arc_1041  -1
    order_1_10  connected_order_arc_1050  1
    order_1_10  connected_order_arc_1073  1
    order_1_10  connected_order_arc_1096  1
    order_1_10  connected_order_arc_1119  1
    order_1_10  connected_order_arc_1142  1
    order_1_10  connected_order_arc_1165  1
    order_1_10  connected_order_arc_1188  1
    order_1_10  connected_order_arc_1211  1
    order_1_10  order_active_lb_1251  1
    order_1_10  order_active_ub_1252  1
    order_1_10  fixed_segment_relative_order_1306  1
    visit_1_14  out_degree_1256  -1
    visit_1_14  in_degree_1257  -1
    visit_1_14  order_active_lb_1258  -1
    visit_1_14  order_active_ub_1259  -12
    visit_1_14  service_visit_def_1260  -1
    order_1_14  connected_order_arc_958  1
    order_1_14  connected_order_arc_981  1
    order_1_14  connected_order_arc_1004  1
    order_1_14  connected_order_arc_1027  1
    order_1_14  connected_order_arc_1044  -1
    order_1_14  connected_order_arc_1046  -1
    order_1_14  connected_order_arc_1048  -1
    order_1_14  connected_order_arc_1050  -1
    order_1_14  connected_order_arc_1052  -1
    order_1_14  connected_order_arc_1054  -1
    order_1_14  connected_order_arc_1056  -1
    order_1_14  connected_order_arc_1058  -1
    order_1_14  connected_order_arc_1060  -1
    order_1_14  connected_order_arc_1062  -1
    order_1_14  connected_order_arc_1064  -1
    order_1_14  connected_order_arc_1075  1
    order_1_14  connected_order_arc_1098  1
    order_1_14  connected_order_arc_1121  1
    order_1_14  connected_order_arc_1144  1
    order_1_14  connected_order_arc_1167  1
    order_1_14  connected_order_arc_1190  1
    order_1_14  connected_order_arc_1213  1
    order_1_14  order_active_lb_1258  1
    order_1_14  order_active_ub_1259  1
    visit_1_15  out_degree_1262  -1
    visit_1_15  in_degree_1263  -1
    visit_1_15  order_active_lb_1264  -1
    visit_1_15  order_active_ub_1265  -12
    visit_1_15  service_visit_def_1266  -1
    order_1_15  connected_order_arc_960  1
    order_1_15  connected_order_arc_983  1
    order_1_15  connected_order_arc_1006  1
    order_1_15  connected_order_arc_1029  1
    order_1_15  connected_order_arc_1052  1
    order_1_15  connected_order_arc_1067  -1
    order_1_15  connected_order_arc_1069  -1
    order_1_15  connected_order_arc_1071  -1
    order_1_15  connected_order_arc_1073  -1
    order_1_15  connected_order_arc_1075  -1
    order_1_15  connected_order_arc_1077  -1
    order_1_15  connected_order_arc_1079  -1
    order_1_15  connected_order_arc_1081  -1
    order_1_15  connected_order_arc_1083  -1
    order_1_15  connected_order_arc_1085  -1
    order_1_15  connected_order_arc_1087  -1
    order_1_15  connected_order_arc_1100  1
    order_1_15  connected_order_arc_1123  1
    order_1_15  connected_order_arc_1146  1
    order_1_15  connected_order_arc_1169  1
    order_1_15  connected_order_arc_1192  1
    order_1_15  connected_order_arc_1215  1
    order_1_15  order_active_lb_1264  1
    order_1_15  order_active_ub_1265  1
    visit_1_16  out_degree_1268  -1
    visit_1_16  in_degree_1269  -1
    visit_1_16  order_active_lb_1270  -1
    visit_1_16  order_active_ub_1271  -12
    visit_1_16  service_visit_def_1272  -1
    order_1_16  connected_order_arc_962  1
    order_1_16  connected_order_arc_985  1
    order_1_16  connected_order_arc_1008  1
    order_1_16  connected_order_arc_1031  1
    order_1_16  connected_order_arc_1054  1
    order_1_16  connected_order_arc_1077  1
    order_1_16  connected_order_arc_1090  -1
    order_1_16  connected_order_arc_1092  -1
    order_1_16  connected_order_arc_1094  -1
    order_1_16  connected_order_arc_1096  -1
    order_1_16  connected_order_arc_1098  -1
    order_1_16  connected_order_arc_1100  -1
    order_1_16  connected_order_arc_1102  -1
    order_1_16  connected_order_arc_1104  -1
    order_1_16  connected_order_arc_1106  -1
    order_1_16  connected_order_arc_1108  -1
    order_1_16  connected_order_arc_1110  -1
    order_1_16  connected_order_arc_1125  1
    order_1_16  connected_order_arc_1148  1
    order_1_16  connected_order_arc_1171  1
    order_1_16  connected_order_arc_1194  1
    order_1_16  connected_order_arc_1217  1
    order_1_16  order_active_lb_1270  1
    order_1_16  order_active_ub_1271  1
    visit_1_17  out_degree_1274  -1
    visit_1_17  in_degree_1275  -1
    visit_1_17  order_active_lb_1276  -1
    visit_1_17  order_active_ub_1277  -12
    visit_1_17  service_visit_def_1278  -1
    order_1_17  connected_order_arc_964  1
    order_1_17  connected_order_arc_987  1
    order_1_17  connected_order_arc_1010  1
    order_1_17  connected_order_arc_1033  1
    order_1_17  connected_order_arc_1056  1
    order_1_17  connected_order_arc_1079  1
    order_1_17  connected_order_arc_1102  1
    order_1_17  connected_order_arc_1113  -1
    order_1_17  connected_order_arc_1115  -1
    order_1_17  connected_order_arc_1117  -1
    order_1_17  connected_order_arc_1119  -1
    order_1_17  connected_order_arc_1121  -1
    order_1_17  connected_order_arc_1123  -1
    order_1_17  connected_order_arc_1125  -1
    order_1_17  connected_order_arc_1127  -1
    order_1_17  connected_order_arc_1129  -1
    order_1_17  connected_order_arc_1131  -1
    order_1_17  connected_order_arc_1133  -1
    order_1_17  connected_order_arc_1150  1
    order_1_17  connected_order_arc_1173  1
    order_1_17  connected_order_arc_1196  1
    order_1_17  connected_order_arc_1219  1
    order_1_17  order_active_lb_1276  1
    order_1_17  order_active_ub_1277  1
    visit_1_18  out_degree_1280  -1
    visit_1_18  in_degree_1281  -1
    visit_1_18  order_active_lb_1282  -1
    visit_1_18  order_active_ub_1283  -12
    visit_1_18  service_visit_def_1284  -1
    order_1_18  connected_order_arc_966  1
    order_1_18  connected_order_arc_989  1
    order_1_18  connected_order_arc_1012  1
    order_1_18  connected_order_arc_1035  1
    order_1_18  connected_order_arc_1058  1
    order_1_18  connected_order_arc_1081  1
    order_1_18  connected_order_arc_1104  1
    order_1_18  connected_order_arc_1127  1
    order_1_18  connected_order_arc_1136  -1
    order_1_18  connected_order_arc_1138  -1
    order_1_18  connected_order_arc_1140  -1
    order_1_18  connected_order_arc_1142  -1
    order_1_18  connected_order_arc_1144  -1
    order_1_18  connected_order_arc_1146  -1
    order_1_18  connected_order_arc_1148  -1
    order_1_18  connected_order_arc_1150  -1
    order_1_18  connected_order_arc_1152  -1
    order_1_18  connected_order_arc_1154  -1
    order_1_18  connected_order_arc_1156  -1
    order_1_18  connected_order_arc_1175  1
    order_1_18  connected_order_arc_1198  1
    order_1_18  connected_order_arc_1221  1
    order_1_18  order_active_lb_1282  1
    order_1_18  order_active_ub_1283  1
    visit_1_19  out_degree_1286  -1
    visit_1_19  in_degree_1287  -1
    visit_1_19  order_active_lb_1288  -1
    visit_1_19  order_active_ub_1289  -12
    visit_1_19  service_visit_def_1290  -1
    order_1_19  connected_order_arc_968  1
    order_1_19  connected_order_arc_991  1
    order_1_19  connected_order_arc_1014  1
    order_1_19  connected_order_arc_1037  1
    order_1_19  connected_order_arc_1060  1
    order_1_19  connected_order_arc_1083  1
    order_1_19  connected_order_arc_1106  1
    order_1_19  connected_order_arc_1129  1
    order_1_19  connected_order_arc_1152  1
    order_1_19  connected_order_arc_1159  -1
    order_1_19  connected_order_arc_1161  -1
    order_1_19  connected_order_arc_1163  -1
    order_1_19  connected_order_arc_1165  -1
    order_1_19  connected_order_arc_1167  -1
    order_1_19  connected_order_arc_1169  -1
    order_1_19  connected_order_arc_1171  -1
    order_1_19  connected_order_arc_1173  -1
    order_1_19  connected_order_arc_1175  -1
    order_1_19  connected_order_arc_1177  -1
    order_1_19  connected_order_arc_1179  -1
    order_1_19  connected_order_arc_1200  1
    order_1_19  connected_order_arc_1223  1
    order_1_19  order_active_lb_1288  1
    order_1_19  order_active_ub_1289  1
    visit_1_20  out_degree_1292  -1
    visit_1_20  in_degree_1293  -1
    visit_1_20  order_active_lb_1294  -1
    visit_1_20  order_active_ub_1295  -12
    visit_1_20  service_visit_def_1296  -1
    order_1_20  connected_order_arc_970  1
    order_1_20  connected_order_arc_993  1
    order_1_20  connected_order_arc_1016  1
    order_1_20  connected_order_arc_1039  1
    order_1_20  connected_order_arc_1062  1
    order_1_20  connected_order_arc_1085  1
    order_1_20  connected_order_arc_1108  1
    order_1_20  connected_order_arc_1131  1
    order_1_20  connected_order_arc_1154  1
    order_1_20  connected_order_arc_1177  1
    order_1_20  connected_order_arc_1182  -1
    order_1_20  connected_order_arc_1184  -1
    order_1_20  connected_order_arc_1186  -1
    order_1_20  connected_order_arc_1188  -1
    order_1_20  connected_order_arc_1190  -1
    order_1_20  connected_order_arc_1192  -1
    order_1_20  connected_order_arc_1194  -1
    order_1_20  connected_order_arc_1196  -1
    order_1_20  connected_order_arc_1198  -1
    order_1_20  connected_order_arc_1200  -1
    order_1_20  connected_order_arc_1202  -1
    order_1_20  connected_order_arc_1225  1
    order_1_20  order_active_lb_1294  1
    order_1_20  order_active_ub_1295  1
    visit_1_21  out_degree_1298  -1
    visit_1_21  in_degree_1299  -1
    visit_1_21  order_active_lb_1300  -1
    visit_1_21  order_active_ub_1301  -12
    visit_1_21  service_visit_def_1302  -1
    order_1_21  connected_order_arc_972  1
    order_1_21  connected_order_arc_995  1
    order_1_21  connected_order_arc_1018  1
    order_1_21  connected_order_arc_1041  1
    order_1_21  connected_order_arc_1064  1
    order_1_21  connected_order_arc_1087  1
    order_1_21  connected_order_arc_1110  1
    order_1_21  connected_order_arc_1133  1
    order_1_21  connected_order_arc_1156  1
    order_1_21  connected_order_arc_1179  1
    order_1_21  connected_order_arc_1202  1
    order_1_21  connected_order_arc_1205  -1
    order_1_21  connected_order_arc_1207  -1
    order_1_21  connected_order_arc_1209  -1
    order_1_21  connected_order_arc_1211  -1
    order_1_21  connected_order_arc_1213  -1
    order_1_21  connected_order_arc_1215  -1
    order_1_21  connected_order_arc_1217  -1
    order_1_21  connected_order_arc_1219  -1
    order_1_21  connected_order_arc_1221  -1
    order_1_21  connected_order_arc_1223  -1
    order_1_21  connected_order_arc_1225  -1
    order_1_21  order_active_lb_1300  1
    order_1_21  order_active_ub_1301  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_0  arc_capacity_937  -25
    arc_1_0_0  depot_departure_or_bypass_1226  1
    arc_1_0_0  depot_return_or_bypass_1227  1
    MARKER    'MARKER'                 'INTEND'
    load_1_0_0  arc_capacity_937  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_7  arc_capacity_938  -25
    arc_1_0_7  depot_departure_or_bypass_1226  1
    arc_1_0_7  in_degree_1229  1
    arc_1_0_7  original_T_including_depot_unload_1307  8.7749189782983967e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_7  arc_capacity_938  1
    load_1_0_7  segment_load_conservation_1232  -1
    load_1_0_7  segment_prefix_lb_1233  1
    load_1_0_7  segment_prefix_ub_1234  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_8  arc_capacity_939  -25
    arc_1_0_8  depot_departure_or_bypass_1226  1
    arc_1_0_8  in_degree_1236  1
    arc_1_0_8  original_T_including_depot_unload_1307  8.7918533905669346e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_8  arc_capacity_939  1
    load_1_0_8  segment_load_conservation_1239  -1
    load_1_0_8  segment_prefix_lb_1240  1
    load_1_0_8  segment_prefix_ub_1241  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_9  arc_capacity_940  -25
    arc_1_0_9  depot_departure_or_bypass_1226  1
    arc_1_0_9  in_degree_1243  1
    arc_1_0_9  original_T_including_depot_unload_1307  1.0088905112952611e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_9  arc_capacity_940  1
    load_1_0_9  segment_load_conservation_1246  -1
    load_1_0_9  segment_prefix_lb_1247  1
    load_1_0_9  segment_prefix_ub_1248  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_10  arc_capacity_941  -25
    arc_1_0_10  depot_departure_or_bypass_1226  1
    arc_1_0_10  in_degree_1250  1
    arc_1_0_10  original_T_including_depot_unload_1307  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_10  arc_capacity_941  1
    load_1_0_10  segment_load_conservation_1253  -1
    load_1_0_10  segment_prefix_lb_1254  1
    load_1_0_10  segment_prefix_ub_1255  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_14  arc_capacity_942  -25
    arc_1_0_14  depot_departure_or_bypass_1226  1
    arc_1_0_14  in_degree_1257  1
    arc_1_0_14  original_T_including_depot_unload_1307  5.9431738885389052e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_14  arc_capacity_942  1
    load_1_0_14  free_load_conservation_1261  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_15  arc_capacity_943  -25
    arc_1_0_15  depot_departure_or_bypass_1226  1
    arc_1_0_15  in_degree_1263  1
    arc_1_0_15  original_T_including_depot_unload_1307  7.2571167924583824e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_15  arc_capacity_943  1
    load_1_0_15  free_load_conservation_1267  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_16  arc_capacity_944  -25
    arc_1_0_16  depot_departure_or_bypass_1226  1
    arc_1_0_16  in_degree_1269  1
    arc_1_0_16  original_T_including_depot_unload_1307  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_16  arc_capacity_944  1
    load_1_0_16  free_load_conservation_1273  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_17  arc_capacity_945  -25
    arc_1_0_17  depot_departure_or_bypass_1226  1
    arc_1_0_17  in_degree_1275  1
    arc_1_0_17  original_T_including_depot_unload_1307  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_17  arc_capacity_945  1
    load_1_0_17  free_load_conservation_1279  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_18  arc_capacity_946  -25
    arc_1_0_18  depot_departure_or_bypass_1226  1
    arc_1_0_18  in_degree_1281  1
    arc_1_0_18  original_T_including_depot_unload_1307  9.5330620720858735e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_18  arc_capacity_946  1
    load_1_0_18  free_load_conservation_1285  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_19  arc_capacity_947  -25
    arc_1_0_19  depot_departure_or_bypass_1226  1
    arc_1_0_19  in_degree_1287  1
    arc_1_0_19  original_T_including_depot_unload_1307  4.6364706268001146e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_19  arc_capacity_947  1
    load_1_0_19  free_load_conservation_1291  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_20  arc_capacity_948  -25
    arc_1_0_20  depot_departure_or_bypass_1226  1
    arc_1_0_20  in_degree_1293  1
    arc_1_0_20  original_T_including_depot_unload_1307  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_20  arc_capacity_948  1
    load_1_0_20  free_load_conservation_1297  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_21  arc_capacity_949  -25
    arc_1_0_21  depot_departure_or_bypass_1226  1
    arc_1_0_21  in_degree_1299  1
    arc_1_0_21  original_T_including_depot_unload_1307  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_21  arc_capacity_949  1
    load_1_0_21  free_load_conservation_1303  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_0  arc_capacity_950  -25
    arc_1_7_0  depot_return_or_bypass_1227  1
    arc_1_7_0  out_degree_1228  1
    arc_1_7_0  original_T_including_depot_unload_1307  1.0479182987243917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_0  arc_capacity_950  1
    load_1_7_0  segment_load_conservation_1232  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_8  arc_capacity_951  -25
    arc_1_7_8  connected_order_arc_952  -13
    arc_1_7_8  out_degree_1228  1
    arc_1_7_8  in_degree_1236  1
    arc_1_7_8  original_T_including_depot_unload_1307  2.4155873404211835e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_8  arc_capacity_951  1
    load_1_7_8  segment_load_conservation_1232  1
    load_1_7_8  segment_load_conservation_1239  -1
    load_1_7_8  segment_prefix_lb_1240  1
    load_1_7_8  segment_prefix_ub_1241  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_9  arc_capacity_953  -25
    arc_1_7_9  connected_order_arc_954  -13
    arc_1_7_9  out_degree_1228  1
    arc_1_7_9  in_degree_1243  1
    arc_1_7_9  original_T_including_depot_unload_1307  3.6094216796124527e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_9  arc_capacity_953  1
    load_1_7_9  segment_load_conservation_1232  1
    load_1_7_9  segment_load_conservation_1246  -1
    load_1_7_9  segment_prefix_lb_1247  1
    load_1_7_9  segment_prefix_ub_1248  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_10  arc_capacity_955  -25
    arc_1_7_10  connected_order_arc_956  -13
    arc_1_7_10  out_degree_1228  1
    arc_1_7_10  in_degree_1250  1
    arc_1_7_10  original_T_including_depot_unload_1307  9.2235470209829464e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_10  arc_capacity_955  1
    load_1_7_10  segment_load_conservation_1232  1
    load_1_7_10  segment_load_conservation_1253  -1
    load_1_7_10  segment_prefix_lb_1254  1
    load_1_7_10  segment_prefix_ub_1255  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_14  arc_capacity_957  -25
    arc_1_7_14  connected_order_arc_958  -13
    arc_1_7_14  out_degree_1228  1
    arc_1_7_14  in_degree_1257  1
    arc_1_7_14  original_T_including_depot_unload_1307  1.5230377993795889e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_14  arc_capacity_957  1
    load_1_7_14  segment_load_conservation_1232  1
    load_1_7_14  free_load_conservation_1261  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_15  arc_capacity_959  -25
    arc_1_7_15  connected_order_arc_960  -13
    arc_1_7_15  out_degree_1228  1
    arc_1_7_15  in_degree_1263  1
    arc_1_7_15  original_T_including_depot_unload_1307  1.5393972350798747e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_15  arc_capacity_959  1
    load_1_7_15  segment_load_conservation_1232  1
    load_1_7_15  free_load_conservation_1267  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_16  arc_capacity_961  -25
    arc_1_7_16  connected_order_arc_962  -13
    arc_1_7_16  out_degree_1228  1
    arc_1_7_16  in_degree_1269  1
    arc_1_7_16  original_T_including_depot_unload_1307  5.2280951376932137e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_16  arc_capacity_961  1
    load_1_7_16  segment_load_conservation_1232  1
    load_1_7_16  free_load_conservation_1273  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_17  arc_capacity_963  -25
    arc_1_7_17  connected_order_arc_964  -13
    arc_1_7_17  out_degree_1228  1
    arc_1_7_17  in_degree_1275  1
    arc_1_7_17  original_T_including_depot_unload_1307  1.4479585101303876e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_17  arc_capacity_963  1
    load_1_7_17  segment_load_conservation_1232  1
    load_1_7_17  free_load_conservation_1279  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_18  arc_capacity_965  -25
    arc_1_7_18  connected_order_arc_966  -13
    arc_1_7_18  out_degree_1228  1
    arc_1_7_18  in_degree_1281  1
    arc_1_7_18  original_T_including_depot_unload_1307  1.9981042624472673e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_18  arc_capacity_965  1
    load_1_7_18  segment_load_conservation_1232  1
    load_1_7_18  free_load_conservation_1285  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_19  arc_capacity_967  -25
    arc_1_7_19  connected_order_arc_968  -13
    arc_1_7_19  out_degree_1228  1
    arc_1_7_19  in_degree_1287  1
    arc_1_7_19  original_T_including_depot_unload_1307  1.2492199513695298e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_19  arc_capacity_967  1
    load_1_7_19  segment_load_conservation_1232  1
    load_1_7_19  free_load_conservation_1291  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_20  arc_capacity_969  -25
    arc_1_7_20  connected_order_arc_970  -13
    arc_1_7_20  out_degree_1228  1
    arc_1_7_20  in_degree_1293  1
    arc_1_7_20  original_T_including_depot_unload_1307  1.5393904884690303e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_20  arc_capacity_969  1
    load_1_7_20  segment_load_conservation_1232  1
    load_1_7_20  free_load_conservation_1297  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_21  arc_capacity_971  -25
    arc_1_7_21  connected_order_arc_972  -13
    arc_1_7_21  out_degree_1228  1
    arc_1_7_21  in_degree_1299  1
    arc_1_7_21  original_T_including_depot_unload_1307  1.2309802293463208e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_21  arc_capacity_971  1
    load_1_7_21  segment_load_conservation_1232  1
    load_1_7_21  free_load_conservation_1303  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_0  arc_capacity_973  -25
    arc_1_8_0  depot_return_or_bypass_1227  1
    arc_1_8_0  out_degree_1235  1
    arc_1_8_0  original_T_including_depot_unload_1307  8.7918533905669346e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_0  arc_capacity_973  1
    load_1_8_0  segment_load_conservation_1239  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_7  arc_capacity_974  -25
    arc_1_8_7  connected_order_arc_975  -13
    arc_1_8_7  in_degree_1229  1
    arc_1_8_7  out_degree_1235  1
    arc_1_8_7  original_T_including_depot_unload_1307  3.6821827312741834e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_7  arc_capacity_974  1
    load_1_8_7  segment_load_conservation_1232  -1
    load_1_8_7  segment_prefix_lb_1233  1
    load_1_8_7  segment_prefix_ub_1234  1
    load_1_8_7  segment_load_conservation_1239  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_9  arc_capacity_976  -25
    arc_1_8_9  connected_order_arc_977  -13
    arc_1_8_9  out_degree_1235  1
    arc_1_8_9  in_degree_1243  1
    arc_1_8_9  original_T_including_depot_unload_1307  5.1107432522690152e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_9  arc_capacity_976  1
    load_1_8_9  segment_load_conservation_1239  1
    load_1_8_9  segment_load_conservation_1246  -1
    load_1_8_9  segment_prefix_lb_1247  1
    load_1_8_9  segment_prefix_ub_1248  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_10  arc_capacity_978  -25
    arc_1_8_10  connected_order_arc_979  -13
    arc_1_8_10  out_degree_1235  1
    arc_1_8_10  in_degree_1250  1
    arc_1_8_10  original_T_including_depot_unload_1307  7.5634788469878674e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_10  arc_capacity_978  1
    load_1_8_10  segment_load_conservation_1239  1
    load_1_8_10  segment_load_conservation_1253  -1
    load_1_8_10  segment_prefix_lb_1254  1
    load_1_8_10  segment_prefix_ub_1255  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_14  arc_capacity_980  -25
    arc_1_8_14  connected_order_arc_981  -13
    arc_1_8_14  out_degree_1235  1
    arc_1_8_14  in_degree_1257  1
    arc_1_8_14  original_T_including_depot_unload_1307  1.3070841601346692e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_14  arc_capacity_980  1
    load_1_8_14  segment_load_conservation_1239  1
    load_1_8_14  free_load_conservation_1261  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_15  arc_capacity_982  -25
    arc_1_8_15  connected_order_arc_983  -13
    arc_1_8_15  out_degree_1235  1
    arc_1_8_15  in_degree_1263  1
    arc_1_8_15  original_T_including_depot_unload_1307  1.3095620674514091e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_15  arc_capacity_982  1
    load_1_8_15  segment_load_conservation_1239  1
    load_1_8_15  free_load_conservation_1267  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_16  arc_capacity_984  -25
    arc_1_8_16  connected_order_arc_985  -13
    arc_1_8_16  out_degree_1235  1
    arc_1_8_16  in_degree_1269  1
    arc_1_8_16  original_T_including_depot_unload_1307  3.6824909986567474e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_16  arc_capacity_984  1
    load_1_8_16  segment_load_conservation_1239  1
    load_1_8_16  free_load_conservation_1273  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_17  arc_capacity_986  -25
    arc_1_8_17  connected_order_arc_987  -13
    arc_1_8_17  out_degree_1235  1
    arc_1_8_17  in_degree_1275  1
    arc_1_8_17  original_T_including_depot_unload_1307  1.2587701383314870e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_17  arc_capacity_986  1
    load_1_8_17  segment_load_conservation_1239  1
    load_1_8_17  free_load_conservation_1279  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_18  arc_capacity_988  -25
    arc_1_8_18  connected_order_arc_989  -13
    arc_1_8_18  out_degree_1235  1
    arc_1_8_18  in_degree_1281  1
    arc_1_8_18  original_T_including_depot_unload_1307  1.8130068061837439e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_18  arc_capacity_988  1
    load_1_8_18  segment_load_conservation_1239  1
    load_1_8_18  free_load_conservation_1285  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_19  arc_capacity_990  -25
    arc_1_8_19  connected_order_arc_991  -13
    arc_1_8_19  out_degree_1235  1
    arc_1_8_19  in_degree_1287  1
    arc_1_8_19  original_T_including_depot_unload_1307  1.0250717569202773e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_19  arc_capacity_990  1
    load_1_8_19  segment_load_conservation_1239  1
    load_1_8_19  free_load_conservation_1291  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_20  arc_capacity_992  -25
    arc_1_8_20  connected_order_arc_993  -13
    arc_1_8_20  out_degree_1235  1
    arc_1_8_20  in_degree_1293  1
    arc_1_8_20  original_T_including_depot_unload_1307  1.3653307388496069e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_20  arc_capacity_992  1
    load_1_8_20  segment_load_conservation_1239  1
    load_1_8_20  free_load_conservation_1297  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_21  arc_capacity_994  -25
    arc_1_8_21  connected_order_arc_995  -13
    arc_1_8_21  out_degree_1235  1
    arc_1_8_21  in_degree_1299  1
    arc_1_8_21  original_T_including_depot_unload_1307  1.0311494902403294e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_21  arc_capacity_994  1
    load_1_8_21  segment_load_conservation_1239  1
    load_1_8_21  free_load_conservation_1303  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_0  arc_capacity_996  -25
    arc_1_9_0  depot_return_or_bypass_1227  1
    arc_1_9_0  out_degree_1242  1
    arc_1_9_0  original_T_including_depot_unload_1307  4.7522445589173662e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_0  arc_capacity_996  1
    load_1_9_0  segment_load_conservation_1246  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_7  arc_capacity_997  -25
    arc_1_9_7  connected_order_arc_998  -13
    arc_1_9_7  in_degree_1229  1
    arc_1_9_7  out_degree_1242  1
    arc_1_9_7  original_T_including_depot_unload_1307  9.0121368945211725e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_7  arc_capacity_997  1
    load_1_9_7  segment_load_conservation_1232  -1
    load_1_9_7  segment_prefix_lb_1233  1
    load_1_9_7  segment_prefix_ub_1234  1
    load_1_9_7  segment_load_conservation_1246  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_8  arc_capacity_999  -25
    arc_1_9_8  connected_order_arc_1000  -13
    arc_1_9_8  in_degree_1236  1
    arc_1_9_8  out_degree_1242  1
    arc_1_9_8  original_T_including_depot_unload_1307  1.0793944823036150e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_8  arc_capacity_999  1
    load_1_9_8  segment_load_conservation_1239  -1
    load_1_9_8  segment_prefix_lb_1240  1
    load_1_9_8  segment_prefix_ub_1241  1
    load_1_9_8  segment_load_conservation_1246  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_10  arc_capacity_1001  -25
    arc_1_9_10  connected_order_arc_1002  -13
    arc_1_9_10  out_degree_1242  1
    arc_1_9_10  in_degree_1250  1
    arc_1_9_10  original_T_including_depot_unload_1307  4.9232225330062903e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_10  arc_capacity_1001  1
    load_1_9_10  segment_load_conservation_1246  1
    load_1_9_10  segment_load_conservation_1253  -1
    load_1_9_10  segment_prefix_lb_1254  1
    load_1_9_10  segment_prefix_ub_1255  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_14  arc_capacity_1003  -25
    arc_1_9_14  connected_order_arc_1004  -13
    arc_1_9_14  out_degree_1242  1
    arc_1_9_14  in_degree_1257  1
    arc_1_9_14  original_T_including_depot_unload_1307  987.973588780524
    MARKER    'MARKER'                 'INTEND'
    load_1_9_14  arc_capacity_1003  1
    load_1_9_14  segment_load_conservation_1246  1
    load_1_9_14  free_load_conservation_1261  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_15  arc_capacity_1005  -25
    arc_1_9_15  connected_order_arc_1006  -13
    arc_1_9_15  out_degree_1242  1
    arc_1_9_15  in_degree_1263  1
    arc_1_9_15  original_T_including_depot_unload_1307  1.1605914703789122e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_15  arc_capacity_1005  1
    load_1_9_15  segment_load_conservation_1246  1
    load_1_9_15  free_load_conservation_1267  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_16  arc_capacity_1007  -25
    arc_1_9_16  connected_order_arc_1008  -13
    arc_1_9_16  out_degree_1242  1
    arc_1_9_16  in_degree_1269  1
    arc_1_9_16  original_T_including_depot_unload_1307  1.3823927712314810e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_16  arc_capacity_1007  1
    load_1_9_16  segment_load_conservation_1246  1
    load_1_9_16  free_load_conservation_1273  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_17  arc_capacity_1009  -25
    arc_1_9_17  connected_order_arc_1010  -13
    arc_1_9_17  out_degree_1242  1
    arc_1_9_17  in_degree_1275  1
    arc_1_9_17  original_T_including_depot_unload_1307  7.2171835955896984e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_17  arc_capacity_1009  1
    load_1_9_17  segment_load_conservation_1246  1
    load_1_9_17  free_load_conservation_1279  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_18  arc_capacity_1011  -25
    arc_1_9_18  connected_order_arc_1012  -13
    arc_1_9_18  out_degree_1242  1
    arc_1_9_18  in_degree_1281  1
    arc_1_9_18  original_T_including_depot_unload_1307  1.1034987922840380e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_18  arc_capacity_1011  1
    load_1_9_18  segment_load_conservation_1246  1
    load_1_9_18  free_load_conservation_1285  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_19  arc_capacity_1013  -25
    arc_1_9_19  connected_order_arc_1014  -13
    arc_1_9_19  out_degree_1242  1
    arc_1_9_19  in_degree_1287  1
    arc_1_9_19  original_T_including_depot_unload_1307  9.2985081319651772e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_19  arc_capacity_1013  1
    load_1_9_19  segment_load_conservation_1246  1
    load_1_9_19  free_load_conservation_1291  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_20  arc_capacity_1015  -25
    arc_1_9_20  connected_order_arc_1016  -13
    arc_1_9_20  out_degree_1242  1
    arc_1_9_20  in_degree_1293  1
    arc_1_9_20  original_T_including_depot_unload_1307  6.7803521648175558e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_20  arc_capacity_1015  1
    load_1_9_20  segment_load_conservation_1246  1
    load_1_9_20  free_load_conservation_1297  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_21  arc_capacity_1017  -25
    arc_1_9_21  connected_order_arc_1018  -13
    arc_1_9_21  out_degree_1242  1
    arc_1_9_21  in_degree_1299  1
    arc_1_9_21  original_T_including_depot_unload_1307  7.0350721341213284e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_21  arc_capacity_1017  1
    load_1_9_21  segment_load_conservation_1246  1
    load_1_9_21  free_load_conservation_1303  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_0  arc_capacity_1019  -25
    arc_1_10_0  depot_return_or_bypass_1227  1
    arc_1_10_0  out_degree_1249  1
    arc_1_10_0  original_T_including_depot_unload_1307  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_0  arc_capacity_1019  1
    load_1_10_0  segment_load_conservation_1253  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_7  arc_capacity_1020  -25
    arc_1_10_7  connected_order_arc_1021  -13
    arc_1_10_7  in_degree_1229  1
    arc_1_10_7  out_degree_1249  1
    arc_1_10_7  original_T_including_depot_unload_1307  7.5571464781430223e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_7  arc_capacity_1020  1
    load_1_10_7  segment_load_conservation_1232  -1
    load_1_10_7  segment_prefix_lb_1233  1
    load_1_10_7  segment_prefix_ub_1234  1
    load_1_10_7  segment_load_conservation_1253  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_8  arc_capacity_1022  -25
    arc_1_10_8  connected_order_arc_1023  -13
    arc_1_10_8  in_degree_1236  1
    arc_1_10_8  out_degree_1249  1
    arc_1_10_8  original_T_including_depot_unload_1307  7.5634788469878674e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_8  arc_capacity_1022  1
    load_1_10_8  segment_load_conservation_1239  -1
    load_1_10_8  segment_prefix_lb_1240  1
    load_1_10_8  segment_prefix_ub_1241  1
    load_1_10_8  segment_load_conservation_1253  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_9  arc_capacity_1024  -25
    arc_1_10_9  connected_order_arc_1025  -13
    arc_1_10_9  in_degree_1243  1
    arc_1_10_9  out_degree_1249  1
    arc_1_10_9  original_T_including_depot_unload_1307  8.9135689158237335e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_9  arc_capacity_1024  1
    load_1_10_9  segment_load_conservation_1246  -1
    load_1_10_9  segment_prefix_lb_1247  1
    load_1_10_9  segment_prefix_ub_1248  1
    load_1_10_9  segment_load_conservation_1253  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_14  arc_capacity_1026  -25
    arc_1_10_14  connected_order_arc_1027  -13
    arc_1_10_14  out_degree_1249  1
    arc_1_10_14  in_degree_1257  1
    arc_1_10_14  original_T_including_depot_unload_1307  6.8881953094806647e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_14  arc_capacity_1026  1
    load_1_10_14  segment_load_conservation_1253  1
    load_1_10_14  free_load_conservation_1261  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_15  arc_capacity_1028  -25
    arc_1_10_15  connected_order_arc_1029  -13
    arc_1_10_15  out_degree_1249  1
    arc_1_10_15  in_degree_1263  1
    arc_1_10_15  original_T_including_depot_unload_1307  7.9613989083692911e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_15  arc_capacity_1028  1
    load_1_10_15  segment_load_conservation_1253  1
    load_1_10_15  free_load_conservation_1267  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_16  arc_capacity_1030  -25
    arc_1_10_16  connected_order_arc_1031  -13
    arc_1_10_16  out_degree_1249  1
    arc_1_10_16  in_degree_1269  1
    arc_1_10_16  original_T_including_depot_unload_1307  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_16  arc_capacity_1030  1
    load_1_10_16  segment_load_conservation_1253  1
    load_1_10_16  free_load_conservation_1273  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_17  arc_capacity_1032  -25
    arc_1_10_17  connected_order_arc_1033  -13
    arc_1_10_17  out_degree_1249  1
    arc_1_10_17  in_degree_1275  1
    arc_1_10_17  original_T_including_depot_unload_1307  5.3713048648006088e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_17  arc_capacity_1032  1
    load_1_10_17  segment_load_conservation_1253  1
    load_1_10_17  free_load_conservation_1279  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_18  arc_capacity_1034  -25
    arc_1_10_18  connected_order_arc_1035  -13
    arc_1_10_18  out_degree_1249  1
    arc_1_10_18  in_degree_1281  1
    arc_1_10_18  original_T_including_depot_unload_1307  1.0783470469841145e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_18  arc_capacity_1034  1
    load_1_10_18  segment_load_conservation_1253  1
    load_1_10_18  free_load_conservation_1285  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_19  arc_capacity_1036  -25
    arc_1_10_19  connected_order_arc_1037  -13
    arc_1_10_19  out_degree_1249  1
    arc_1_10_19  in_degree_1287  1
    arc_1_10_19  original_T_including_depot_unload_1307  5.1177250003741761e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_19  arc_capacity_1036  1
    load_1_10_19  segment_load_conservation_1253  1
    load_1_10_19  free_load_conservation_1291  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_20  arc_capacity_1038  -25
    arc_1_10_20  connected_order_arc_1039  -13
    arc_1_10_20  out_degree_1249  1
    arc_1_10_20  in_degree_1293  1
    arc_1_10_20  original_T_including_depot_unload_1307  6.1704611580490348e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_20  arc_capacity_1038  1
    load_1_10_20  segment_load_conservation_1253  1
    load_1_10_20  free_load_conservation_1297  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_21  arc_capacity_1040  -25
    arc_1_10_21  connected_order_arc_1041  -13
    arc_1_10_21  out_degree_1249  1
    arc_1_10_21  in_degree_1299  1
    arc_1_10_21  original_T_including_depot_unload_1307  359.975566576564
    MARKER    'MARKER'                 'INTEND'
    load_1_10_21  arc_capacity_1040  1
    load_1_10_21  segment_load_conservation_1253  1
    load_1_10_21  free_load_conservation_1303  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_0  arc_capacity_1042  -25
    arc_1_14_0  depot_return_or_bypass_1227  1
    arc_1_14_0  out_degree_1256  1
    arc_1_14_0  original_T_including_depot_unload_1307  5.9431738885389052e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_0  arc_capacity_1042  1
    load_1_14_0  free_load_conservation_1261  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_7  arc_capacity_1043  -25
    arc_1_14_7  connected_order_arc_1044  -13
    arc_1_14_7  in_degree_1229  1
    arc_1_14_7  out_degree_1256  1
    arc_1_14_7  original_T_including_depot_unload_1307  1.4171530684324468e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_7  arc_capacity_1043  1
    load_1_14_7  segment_load_conservation_1232  -1
    load_1_14_7  segment_prefix_lb_1233  1
    load_1_14_7  segment_prefix_ub_1234  1
    load_1_14_7  free_load_conservation_1261  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_8  arc_capacity_1045  -25
    arc_1_14_8  connected_order_arc_1046  -13
    arc_1_14_8  in_degree_1236  1
    arc_1_14_8  out_degree_1256  1
    arc_1_14_8  original_T_including_depot_unload_1307  1.3070841601346692e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_8  arc_capacity_1045  1
    load_1_14_8  segment_load_conservation_1239  -1
    load_1_14_8  segment_prefix_lb_1240  1
    load_1_14_8  segment_prefix_ub_1241  1
    load_1_14_8  free_load_conservation_1261  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_9  arc_capacity_1047  -25
    arc_1_14_9  connected_order_arc_1048  -13
    arc_1_14_9  in_degree_1243  1
    arc_1_14_9  out_degree_1256  1
    arc_1_14_9  original_T_including_depot_unload_1307  1.5657515083159024e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_9  arc_capacity_1047  1
    load_1_14_9  segment_load_conservation_1246  -1
    load_1_14_9  segment_prefix_lb_1247  1
    load_1_14_9  segment_prefix_ub_1248  1
    load_1_14_9  free_load_conservation_1261  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_10  arc_capacity_1049  -25
    arc_1_14_10  connected_order_arc_1050  -13
    arc_1_14_10  in_degree_1250  1
    arc_1_14_10  out_degree_1256  1
    arc_1_14_10  original_T_including_depot_unload_1307  6.8881953094806647e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_10  arc_capacity_1049  1
    load_1_14_10  segment_load_conservation_1253  -1
    load_1_14_10  segment_prefix_lb_1254  1
    load_1_14_10  segment_prefix_ub_1255  1
    load_1_14_10  free_load_conservation_1261  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_15  arc_capacity_1051  -25
    arc_1_14_15  connected_order_arc_1052  -13
    arc_1_14_15  out_degree_1256  1
    arc_1_14_15  in_degree_1263  1
    arc_1_14_15  original_T_including_depot_unload_1307  2.1481294511470344e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_15  arc_capacity_1051  1
    load_1_14_15  free_load_conservation_1261  1
    load_1_14_15  free_load_conservation_1267  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_16  arc_capacity_1053  -25
    arc_1_14_16  connected_order_arc_1054  -13
    arc_1_14_16  out_degree_1256  1
    arc_1_14_16  in_degree_1269  1
    arc_1_14_16  original_T_including_depot_unload_1307  1.3727638439182763e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_16  arc_capacity_1053  1
    load_1_14_16  free_load_conservation_1261  1
    load_1_14_16  free_load_conservation_1273  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_17  arc_capacity_1055  -25
    arc_1_14_17  connected_order_arc_1056  -13
    arc_1_14_17  out_degree_1256  1
    arc_1_14_17  in_degree_1275  1
    arc_1_14_17  original_T_including_depot_unload_1307  2.9098466309579254e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_17  arc_capacity_1055  1
    load_1_14_17  free_load_conservation_1261  1
    load_1_14_17  free_load_conservation_1279  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_18  arc_capacity_1057  -25
    arc_1_14_18  connected_order_arc_1058  -13
    arc_1_14_18  out_degree_1256  1
    arc_1_14_18  in_degree_1281  1
    arc_1_14_18  original_T_including_depot_unload_1307  6.2159179673866879e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_18  arc_capacity_1057  1
    load_1_14_18  free_load_conservation_1261  1
    load_1_14_18  free_load_conservation_1285  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_19  arc_capacity_1059  -25
    arc_1_14_19  connected_order_arc_1060  -13
    arc_1_14_19  out_degree_1256  1
    arc_1_14_19  in_degree_1287  1
    arc_1_14_19  original_T_including_depot_unload_1307  2.9706418113632907e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_19  arc_capacity_1059  1
    load_1_14_19  free_load_conservation_1261  1
    load_1_14_19  free_load_conservation_1291  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_20  arc_capacity_1061  -25
    arc_1_14_20  connected_order_arc_1062  -13
    arc_1_14_20  out_degree_1256  1
    arc_1_14_20  in_degree_1293  1
    arc_1_14_20  original_T_including_depot_unload_1307  4.3129452098285111e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_20  arc_capacity_1061  1
    load_1_14_20  free_load_conservation_1261  1
    load_1_14_20  free_load_conservation_1297  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_21  arc_capacity_1063  -25
    arc_1_14_21  connected_order_arc_1064  -13
    arc_1_14_21  out_degree_1256  1
    arc_1_14_21  in_degree_1299  1
    arc_1_14_21  original_T_including_depot_unload_1307  3.2938591738444967e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_21  arc_capacity_1063  1
    load_1_14_21  free_load_conservation_1261  1
    load_1_14_21  free_load_conservation_1303  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_0  arc_capacity_1065  -25
    arc_1_15_0  depot_return_or_bypass_1227  1
    arc_1_15_0  out_degree_1262  1
    arc_1_15_0  original_T_including_depot_unload_1307  7.2571167924583824e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_0  arc_capacity_1065  1
    load_1_15_0  free_load_conservation_1267  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_7  arc_capacity_1066  -25
    arc_1_15_7  connected_order_arc_1067  -13
    arc_1_15_7  in_degree_1229  1
    arc_1_15_7  out_degree_1262  1
    arc_1_15_7  original_T_including_depot_unload_1307  1.4725441282427828e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_7  arc_capacity_1066  1
    load_1_15_7  segment_load_conservation_1232  -1
    load_1_15_7  segment_prefix_lb_1233  1
    load_1_15_7  segment_prefix_ub_1234  1
    load_1_15_7  free_load_conservation_1267  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_8  arc_capacity_1068  -25
    arc_1_15_8  connected_order_arc_1069  -13
    arc_1_15_8  in_degree_1236  1
    arc_1_15_8  out_degree_1262  1
    arc_1_15_8  original_T_including_depot_unload_1307  1.3095620674514091e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_8  arc_capacity_1068  1
    load_1_15_8  segment_load_conservation_1239  -1
    load_1_15_8  segment_prefix_lb_1240  1
    load_1_15_8  segment_prefix_ub_1241  1
    load_1_15_8  free_load_conservation_1267  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_9  arc_capacity_1070  -25
    arc_1_15_9  connected_order_arc_1071  -13
    arc_1_15_9  in_degree_1243  1
    arc_1_15_9  out_degree_1262  1
    arc_1_15_9  original_T_including_depot_unload_1307  1.6299527591666472e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_9  arc_capacity_1070  1
    load_1_15_9  segment_load_conservation_1246  -1
    load_1_15_9  segment_prefix_lb_1247  1
    load_1_15_9  segment_prefix_ub_1248  1
    load_1_15_9  free_load_conservation_1267  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_10  arc_capacity_1072  -25
    arc_1_15_10  connected_order_arc_1073  -13
    arc_1_15_10  in_degree_1250  1
    arc_1_15_10  out_degree_1262  1
    arc_1_15_10  original_T_including_depot_unload_1307  7.9613989083692911e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_10  arc_capacity_1072  1
    load_1_15_10  segment_load_conservation_1253  -1
    load_1_15_10  segment_prefix_lb_1254  1
    load_1_15_10  segment_prefix_ub_1255  1
    load_1_15_10  free_load_conservation_1267  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_14  arc_capacity_1074  -25
    arc_1_15_14  connected_order_arc_1075  -13
    arc_1_15_14  in_degree_1257  1
    arc_1_15_14  out_degree_1262  1
    arc_1_15_14  original_T_including_depot_unload_1307  2.1481294511470344e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_14  arc_capacity_1074  1
    load_1_15_14  free_load_conservation_1261  -1
    load_1_15_14  free_load_conservation_1267  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_16  arc_capacity_1076  -25
    arc_1_15_16  connected_order_arc_1077  -13
    arc_1_15_16  out_degree_1262  1
    arc_1_15_16  in_degree_1269  1
    arc_1_15_16  original_T_including_depot_unload_1307  1.3163662834239574e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_16  arc_capacity_1076  1
    load_1_15_16  free_load_conservation_1267  1
    load_1_15_16  free_load_conservation_1273  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_17  arc_capacity_1078  -25
    arc_1_15_17  connected_order_arc_1079  -13
    arc_1_15_17  out_degree_1262  1
    arc_1_15_17  in_degree_1275  1
    arc_1_15_17  original_T_including_depot_unload_1307  4.9831220386775891e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_17  arc_capacity_1078  1
    load_1_15_17  free_load_conservation_1267  1
    load_1_15_17  free_load_conservation_1279  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_18  arc_capacity_1080  -25
    arc_1_15_18  connected_order_arc_1081  -13
    arc_1_15_18  out_degree_1262  1
    arc_1_15_18  in_degree_1281  1
    arc_1_15_18  original_T_including_depot_unload_1307  7.9206888044020991e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_18  arc_capacity_1080  1
    load_1_15_18  free_load_conservation_1267  1
    load_1_15_18  free_load_conservation_1285  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_19  arc_capacity_1082  -25
    arc_1_15_19  connected_order_arc_1083  -13
    arc_1_15_19  out_degree_1262  1
    arc_1_15_19  in_degree_1287  1
    arc_1_15_19  original_T_including_depot_unload_1307  3.0055050459786975e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_19  arc_capacity_1082  1
    load_1_15_19  free_load_conservation_1267  1
    load_1_15_19  free_load_conservation_1291  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_20  arc_capacity_1084  -25
    arc_1_15_20  connected_order_arc_1085  -13
    arc_1_15_20  out_degree_1262  1
    arc_1_15_20  in_degree_1293  1
    arc_1_15_20  original_T_including_depot_unload_1307  6.4542450829473034e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_20  arc_capacity_1084  1
    load_1_15_20  free_load_conservation_1267  1
    load_1_15_20  free_load_conservation_1297  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_21  arc_capacity_1086  -25
    arc_1_15_21  connected_order_arc_1087  -13
    arc_1_15_21  out_degree_1262  1
    arc_1_15_21  in_degree_1299  1
    arc_1_15_21  original_T_including_depot_unload_1307  4.6276703023336785e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_21  arc_capacity_1086  1
    load_1_15_21  free_load_conservation_1267  1
    load_1_15_21  free_load_conservation_1303  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_0  arc_capacity_1088  -25
    arc_1_16_0  depot_return_or_bypass_1227  1
    arc_1_16_0  out_degree_1268  1
    arc_1_16_0  original_T_including_depot_unload_1307  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_0  arc_capacity_1088  1
    load_1_16_0  free_load_conservation_1273  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_7  arc_capacity_1089  -25
    arc_1_16_7  connected_order_arc_1090  -13
    arc_1_16_7  in_degree_1229  1
    arc_1_16_7  out_degree_1268  1
    arc_1_16_7  original_T_including_depot_unload_1307  7.3227602527872671e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_7  arc_capacity_1089  1
    load_1_16_7  segment_load_conservation_1232  -1
    load_1_16_7  segment_prefix_lb_1233  1
    load_1_16_7  segment_prefix_ub_1234  1
    load_1_16_7  free_load_conservation_1273  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_8  arc_capacity_1091  -25
    arc_1_16_8  connected_order_arc_1092  -13
    arc_1_16_8  in_degree_1236  1
    arc_1_16_8  out_degree_1268  1
    arc_1_16_8  original_T_including_depot_unload_1307  3.6824909986567474e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_8  arc_capacity_1091  1
    load_1_16_8  segment_load_conservation_1239  -1
    load_1_16_8  segment_prefix_lb_1240  1
    load_1_16_8  segment_prefix_ub_1241  1
    load_1_16_8  free_load_conservation_1273  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_9  arc_capacity_1093  -25
    arc_1_16_9  connected_order_arc_1094  -13
    arc_1_16_9  in_degree_1243  1
    arc_1_16_9  out_degree_1268  1
    arc_1_16_9  original_T_including_depot_unload_1307  861.314419336229
    MARKER    'MARKER'                 'INTEND'
    load_1_16_9  arc_capacity_1093  1
    load_1_16_9  segment_load_conservation_1246  -1
    load_1_16_9  segment_prefix_lb_1247  1
    load_1_16_9  segment_prefix_ub_1248  1
    load_1_16_9  free_load_conservation_1273  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_10  arc_capacity_1095  -25
    arc_1_16_10  connected_order_arc_1096  -13
    arc_1_16_10  in_degree_1250  1
    arc_1_16_10  out_degree_1268  1
    arc_1_16_10  original_T_including_depot_unload_1307  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_10  arc_capacity_1095  1
    load_1_16_10  segment_load_conservation_1253  -1
    load_1_16_10  segment_prefix_lb_1254  1
    load_1_16_10  segment_prefix_ub_1255  1
    load_1_16_10  free_load_conservation_1273  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_14  arc_capacity_1097  -25
    arc_1_16_14  connected_order_arc_1098  -13
    arc_1_16_14  in_degree_1257  1
    arc_1_16_14  out_degree_1268  1
    arc_1_16_14  original_T_including_depot_unload_1307  1.3727638439182763e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_14  arc_capacity_1097  1
    load_1_16_14  free_load_conservation_1261  -1
    load_1_16_14  free_load_conservation_1273  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_15  arc_capacity_1099  -25
    arc_1_16_15  connected_order_arc_1100  -13
    arc_1_16_15  in_degree_1263  1
    arc_1_16_15  out_degree_1268  1
    arc_1_16_15  original_T_including_depot_unload_1307  1.3163662834239574e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_15  arc_capacity_1099  1
    load_1_16_15  free_load_conservation_1267  -1
    load_1_16_15  free_load_conservation_1273  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_17  arc_capacity_1101  -25
    arc_1_16_17  connected_order_arc_1102  -13
    arc_1_16_17  out_degree_1268  1
    arc_1_16_17  in_degree_1275  1
    arc_1_16_17  original_T_including_depot_unload_1307  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_17  arc_capacity_1101  1
    load_1_16_17  free_load_conservation_1273  1
    load_1_16_17  free_load_conservation_1279  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_18  arc_capacity_1103  -25
    arc_1_16_18  connected_order_arc_1104  -13
    arc_1_16_18  out_degree_1268  1
    arc_1_16_18  in_degree_1281  1
    arc_1_16_18  original_T_including_depot_unload_1307  1.9462564869425171e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_18  arc_capacity_1103  1
    load_1_16_18  free_load_conservation_1273  1
    load_1_16_18  free_load_conservation_1285  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_19  arc_capacity_1105  -25
    arc_1_16_19  connected_order_arc_1106  -13
    arc_1_16_19  out_degree_1268  1
    arc_1_16_19  in_degree_1287  1
    arc_1_16_19  original_T_including_depot_unload_1307  1075.72043838369
    MARKER    'MARKER'                 'INTEND'
    load_1_16_19  arc_capacity_1105  1
    load_1_16_19  free_load_conservation_1273  1
    load_1_16_19  free_load_conservation_1291  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_20  arc_capacity_1107  -25
    arc_1_16_20  connected_order_arc_1108  -13
    arc_1_16_20  out_degree_1268  1
    arc_1_16_20  in_degree_1293  1
    arc_1_16_20  original_T_including_depot_unload_1307  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_20  arc_capacity_1107  1
    load_1_16_20  free_load_conservation_1273  1
    load_1_16_20  free_load_conservation_1297  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_21  arc_capacity_1109  -25
    arc_1_16_21  connected_order_arc_1110  -13
    arc_1_16_21  out_degree_1268  1
    arc_1_16_21  in_degree_1299  1
    arc_1_16_21  original_T_including_depot_unload_1307  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_21  arc_capacity_1109  1
    load_1_16_21  free_load_conservation_1273  1
    load_1_16_21  free_load_conservation_1303  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_0  arc_capacity_1111  -25
    arc_1_17_0  depot_return_or_bypass_1227  1
    arc_1_17_0  out_degree_1274  1
    arc_1_17_0  original_T_including_depot_unload_1307  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_0  arc_capacity_1111  1
    load_1_17_0  free_load_conservation_1279  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_7  arc_capacity_1112  -25
    arc_1_17_7  connected_order_arc_1113  -13
    arc_1_17_7  in_degree_1229  1
    arc_1_17_7  out_degree_1274  1
    arc_1_17_7  original_T_including_depot_unload_1307  1.2927779971523576e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_7  arc_capacity_1112  1
    load_1_17_7  segment_load_conservation_1232  -1
    load_1_17_7  segment_prefix_lb_1233  1
    load_1_17_7  segment_prefix_ub_1234  1
    load_1_17_7  free_load_conservation_1279  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_8  arc_capacity_1114  -25
    arc_1_17_8  connected_order_arc_1115  -13
    arc_1_17_8  in_degree_1236  1
    arc_1_17_8  out_degree_1274  1
    arc_1_17_8  original_T_including_depot_unload_1307  1.2587701383314870e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_8  arc_capacity_1114  1
    load_1_17_8  segment_load_conservation_1239  -1
    load_1_17_8  segment_prefix_lb_1240  1
    load_1_17_8  segment_prefix_ub_1241  1
    load_1_17_8  free_load_conservation_1279  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_9  arc_capacity_1116  -25
    arc_1_17_9  connected_order_arc_1117  -13
    arc_1_17_9  in_degree_1243  1
    arc_1_17_9  out_degree_1274  1
    arc_1_17_9  original_T_including_depot_unload_1307  1.4252778892498145e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_9  arc_capacity_1116  1
    load_1_17_9  segment_load_conservation_1246  -1
    load_1_17_9  segment_prefix_lb_1247  1
    load_1_17_9  segment_prefix_ub_1248  1
    load_1_17_9  free_load_conservation_1279  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_10  arc_capacity_1118  -25
    arc_1_17_10  connected_order_arc_1119  -13
    arc_1_17_10  in_degree_1250  1
    arc_1_17_10  out_degree_1274  1
    arc_1_17_10  original_T_including_depot_unload_1307  5.3713048648006088e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_10  arc_capacity_1118  1
    load_1_17_10  segment_load_conservation_1253  -1
    load_1_17_10  segment_prefix_lb_1254  1
    load_1_17_10  segment_prefix_ub_1255  1
    load_1_17_10  free_load_conservation_1279  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_14  arc_capacity_1120  -25
    arc_1_17_14  connected_order_arc_1121  -13
    arc_1_17_14  in_degree_1257  1
    arc_1_17_14  out_degree_1274  1
    arc_1_17_14  original_T_including_depot_unload_1307  2.9098466309579254e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_14  arc_capacity_1120  1
    load_1_17_14  free_load_conservation_1261  -1
    load_1_17_14  free_load_conservation_1279  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_15  arc_capacity_1122  -25
    arc_1_17_15  connected_order_arc_1123  -13
    arc_1_17_15  in_degree_1263  1
    arc_1_17_15  out_degree_1274  1
    arc_1_17_15  original_T_including_depot_unload_1307  4.9831220386775891e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_15  arc_capacity_1122  1
    load_1_17_15  free_load_conservation_1267  -1
    load_1_17_15  free_load_conservation_1279  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_16  arc_capacity_1124  -25
    arc_1_17_16  connected_order_arc_1125  -13
    arc_1_17_16  in_degree_1269  1
    arc_1_17_16  out_degree_1274  1
    arc_1_17_16  original_T_including_depot_unload_1307  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_16  arc_capacity_1124  1
    load_1_17_16  free_load_conservation_1273  -1
    load_1_17_16  free_load_conservation_1279  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_18  arc_capacity_1126  -25
    arc_1_17_18  connected_order_arc_1127  -13
    arc_1_17_18  out_degree_1274  1
    arc_1_17_18  in_degree_1281  1
    arc_1_17_18  original_T_including_depot_unload_1307  5.5448403235604167e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_18  arc_capacity_1126  1
    load_1_17_18  free_load_conservation_1279  1
    load_1_17_18  free_load_conservation_1285  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_19  arc_capacity_1128  -25
    arc_1_17_19  connected_order_arc_1129  -13
    arc_1_17_19  out_degree_1274  1
    arc_1_17_19  in_degree_1287  1
    arc_1_17_19  original_T_including_depot_unload_1307  4.1665889045115779e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_19  arc_capacity_1128  1
    load_1_17_19  free_load_conservation_1279  1
    load_1_17_19  free_load_conservation_1291  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_20  arc_capacity_1130  -25
    arc_1_17_20  connected_order_arc_1131  -13
    arc_1_17_20  out_degree_1274  1
    arc_1_17_20  in_degree_1293  1
    arc_1_17_20  original_T_including_depot_unload_1307  1.6597164064313077e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_20  arc_capacity_1130  1
    load_1_17_20  free_load_conservation_1279  1
    load_1_17_20  free_load_conservation_1297  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_21  arc_capacity_1132  -25
    arc_1_17_21  connected_order_arc_1133  -13
    arc_1_17_21  out_degree_1274  1
    arc_1_17_21  in_degree_1299  1
    arc_1_17_21  original_T_including_depot_unload_1307  2.4083746437975364e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_21  arc_capacity_1132  1
    load_1_17_21  free_load_conservation_1279  1
    load_1_17_21  free_load_conservation_1303  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_0  arc_capacity_1134  -25
    arc_1_18_0  depot_return_or_bypass_1227  1
    arc_1_18_0  out_degree_1280  1
    arc_1_18_0  original_T_including_depot_unload_1307  9.5330620720858735e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_0  arc_capacity_1134  1
    load_1_18_0  free_load_conservation_1285  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_7  arc_capacity_1135  -25
    arc_1_18_7  connected_order_arc_1136  -13
    arc_1_18_7  in_degree_1229  1
    arc_1_18_7  out_degree_1280  1
    arc_1_18_7  original_T_including_depot_unload_1307  1.8269270746185791e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_7  arc_capacity_1135  1
    load_1_18_7  segment_load_conservation_1232  -1
    load_1_18_7  segment_prefix_lb_1233  1
    load_1_18_7  segment_prefix_ub_1234  1
    load_1_18_7  free_load_conservation_1285  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_8  arc_capacity_1137  -25
    arc_1_18_8  connected_order_arc_1138  -13
    arc_1_18_8  in_degree_1236  1
    arc_1_18_8  out_degree_1280  1
    arc_1_18_8  original_T_including_depot_unload_1307  1.8130068061837439e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_8  arc_capacity_1137  1
    load_1_18_8  segment_load_conservation_1239  -1
    load_1_18_8  segment_prefix_lb_1240  1
    load_1_18_8  segment_prefix_ub_1241  1
    load_1_18_8  free_load_conservation_1285  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_9  arc_capacity_1139  -25
    arc_1_18_9  connected_order_arc_1140  -13
    arc_1_18_9  in_degree_1243  1
    arc_1_18_9  out_degree_1280  1
    arc_1_18_9  original_T_including_depot_unload_1307  1.9482201819157062e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_9  arc_capacity_1139  1
    load_1_18_9  segment_load_conservation_1246  -1
    load_1_18_9  segment_prefix_lb_1247  1
    load_1_18_9  segment_prefix_ub_1248  1
    load_1_18_9  free_load_conservation_1285  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_10  arc_capacity_1141  -25
    arc_1_18_10  connected_order_arc_1142  -13
    arc_1_18_10  in_degree_1250  1
    arc_1_18_10  out_degree_1280  1
    arc_1_18_10  original_T_including_depot_unload_1307  1.0783470469841145e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_10  arc_capacity_1141  1
    load_1_18_10  segment_load_conservation_1253  -1
    load_1_18_10  segment_prefix_lb_1254  1
    load_1_18_10  segment_prefix_ub_1255  1
    load_1_18_10  free_load_conservation_1285  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_14  arc_capacity_1143  -25
    arc_1_18_14  connected_order_arc_1144  -13
    arc_1_18_14  in_degree_1257  1
    arc_1_18_14  out_degree_1280  1
    arc_1_18_14  original_T_including_depot_unload_1307  6.2159179673866879e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_14  arc_capacity_1143  1
    load_1_18_14  free_load_conservation_1261  -1
    load_1_18_14  free_load_conservation_1285  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_15  arc_capacity_1145  -25
    arc_1_18_15  connected_order_arc_1146  -13
    arc_1_18_15  in_degree_1263  1
    arc_1_18_15  out_degree_1280  1
    arc_1_18_15  original_T_including_depot_unload_1307  7.9206888044020991e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_15  arc_capacity_1145  1
    load_1_18_15  free_load_conservation_1267  -1
    load_1_18_15  free_load_conservation_1285  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_16  arc_capacity_1147  -25
    arc_1_18_16  connected_order_arc_1148  -13
    arc_1_18_16  in_degree_1269  1
    arc_1_18_16  out_degree_1280  1
    arc_1_18_16  original_T_including_depot_unload_1307  1.9462564869425171e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_16  arc_capacity_1147  1
    load_1_18_16  free_load_conservation_1273  -1
    load_1_18_16  free_load_conservation_1285  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_17  arc_capacity_1149  -25
    arc_1_18_17  connected_order_arc_1150  -13
    arc_1_18_17  in_degree_1275  1
    arc_1_18_17  out_degree_1280  1
    arc_1_18_17  original_T_including_depot_unload_1307  5.5448403235604167e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_17  arc_capacity_1149  1
    load_1_18_17  free_load_conservation_1279  -1
    load_1_18_17  free_load_conservation_1285  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_19  arc_capacity_1151  -25
    arc_1_18_19  connected_order_arc_1152  -13
    arc_1_18_19  out_degree_1280  1
    arc_1_18_19  in_degree_1287  1
    arc_1_18_19  original_T_including_depot_unload_1307  897.031483121361
    MARKER    'MARKER'                 'INTEND'
    load_1_18_19  arc_capacity_1151  1
    load_1_18_19  free_load_conservation_1285  1
    load_1_18_19  free_load_conservation_1291  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_20  arc_capacity_1153  -25
    arc_1_18_20  connected_order_arc_1154  -13
    arc_1_18_20  out_degree_1280  1
    arc_1_18_20  in_degree_1293  1
    arc_1_18_20  original_T_including_depot_unload_1307  4.6772747357218117e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_20  arc_capacity_1153  1
    load_1_18_20  free_load_conservation_1285  1
    load_1_18_20  free_load_conservation_1297  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_21  arc_capacity_1155  -25
    arc_1_18_21  connected_order_arc_1156  -13
    arc_1_18_21  out_degree_1280  1
    arc_1_18_21  in_degree_1299  1
    arc_1_18_21  original_T_including_depot_unload_1307  7.8947565022471792e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_21  arc_capacity_1155  1
    load_1_18_21  free_load_conservation_1285  1
    load_1_18_21  free_load_conservation_1303  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_0  arc_capacity_1157  -25
    arc_1_19_0  depot_return_or_bypass_1227  1
    arc_1_19_0  out_degree_1286  1
    arc_1_19_0  original_T_including_depot_unload_1307  4.6364706268001146e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_0  arc_capacity_1157  1
    load_1_19_0  free_load_conservation_1291  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_7  arc_capacity_1158  -25
    arc_1_19_7  connected_order_arc_1159  -13
    arc_1_19_7  in_degree_1229  1
    arc_1_19_7  out_degree_1286  1
    arc_1_19_7  original_T_including_depot_unload_1307  1.1724800521319269e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_7  arc_capacity_1158  1
    load_1_19_7  segment_load_conservation_1232  -1
    load_1_19_7  segment_prefix_lb_1233  1
    load_1_19_7  segment_prefix_ub_1234  1
    load_1_19_7  free_load_conservation_1291  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_8  arc_capacity_1160  -25
    arc_1_19_8  connected_order_arc_1161  -13
    arc_1_19_8  in_degree_1236  1
    arc_1_19_8  out_degree_1286  1
    arc_1_19_8  original_T_including_depot_unload_1307  1.0250717569202773e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_8  arc_capacity_1160  1
    load_1_19_8  segment_load_conservation_1239  -1
    load_1_19_8  segment_prefix_lb_1240  1
    load_1_19_8  segment_prefix_ub_1241  1
    load_1_19_8  free_load_conservation_1291  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_9  arc_capacity_1162  -25
    arc_1_19_9  connected_order_arc_1163  -13
    arc_1_19_9  in_degree_1243  1
    arc_1_19_9  out_degree_1286  1
    arc_1_19_9  original_T_including_depot_unload_1307  1.3294477435531232e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_9  arc_capacity_1162  1
    load_1_19_9  segment_load_conservation_1246  -1
    load_1_19_9  segment_prefix_lb_1247  1
    load_1_19_9  segment_prefix_ub_1248  1
    load_1_19_9  free_load_conservation_1291  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_10  arc_capacity_1164  -25
    arc_1_19_10  connected_order_arc_1165  -13
    arc_1_19_10  in_degree_1250  1
    arc_1_19_10  out_degree_1286  1
    arc_1_19_10  original_T_including_depot_unload_1307  5.1177250003741761e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_10  arc_capacity_1164  1
    load_1_19_10  segment_load_conservation_1253  -1
    load_1_19_10  segment_prefix_lb_1254  1
    load_1_19_10  segment_prefix_ub_1255  1
    load_1_19_10  free_load_conservation_1291  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_14  arc_capacity_1166  -25
    arc_1_19_14  connected_order_arc_1167  -13
    arc_1_19_14  in_degree_1257  1
    arc_1_19_14  out_degree_1286  1
    arc_1_19_14  original_T_including_depot_unload_1307  2.9706418113632907e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_14  arc_capacity_1166  1
    load_1_19_14  free_load_conservation_1261  -1
    load_1_19_14  free_load_conservation_1291  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_15  arc_capacity_1168  -25
    arc_1_19_15  connected_order_arc_1169  -13
    arc_1_19_15  in_degree_1263  1
    arc_1_19_15  out_degree_1286  1
    arc_1_19_15  original_T_including_depot_unload_1307  3.0055050459786975e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_15  arc_capacity_1168  1
    load_1_19_15  free_load_conservation_1267  -1
    load_1_19_15  free_load_conservation_1291  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_16  arc_capacity_1170  -25
    arc_1_19_16  connected_order_arc_1171  -13
    arc_1_19_16  in_degree_1269  1
    arc_1_19_16  out_degree_1286  1
    arc_1_19_16  original_T_including_depot_unload_1307  1075.72043838369
    MARKER    'MARKER'                 'INTEND'
    load_1_19_16  arc_capacity_1170  1
    load_1_19_16  free_load_conservation_1273  -1
    load_1_19_16  free_load_conservation_1291  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_17  arc_capacity_1172  -25
    arc_1_19_17  connected_order_arc_1173  -13
    arc_1_19_17  in_degree_1275  1
    arc_1_19_17  out_degree_1286  1
    arc_1_19_17  original_T_including_depot_unload_1307  4.1665889045115779e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_17  arc_capacity_1172  1
    load_1_19_17  free_load_conservation_1279  -1
    load_1_19_17  free_load_conservation_1291  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_18  arc_capacity_1174  -25
    arc_1_19_18  connected_order_arc_1175  -13
    arc_1_19_18  in_degree_1281  1
    arc_1_19_18  out_degree_1286  1
    arc_1_19_18  original_T_including_depot_unload_1307  897.031483121361
    MARKER    'MARKER'                 'INTEND'
    load_1_19_18  arc_capacity_1174  1
    load_1_19_18  free_load_conservation_1285  -1
    load_1_19_18  free_load_conservation_1291  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_20  arc_capacity_1176  -25
    arc_1_19_20  connected_order_arc_1177  -13
    arc_1_19_20  out_degree_1286  1
    arc_1_19_20  in_degree_1293  1
    arc_1_19_20  original_T_including_depot_unload_1307  5.8212369880329140e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_20  arc_capacity_1176  1
    load_1_19_20  free_load_conservation_1291  1
    load_1_19_20  free_load_conservation_1297  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_21  arc_capacity_1178  -25
    arc_1_19_21  connected_order_arc_1179  -13
    arc_1_19_21  out_degree_1286  1
    arc_1_19_21  in_degree_1299  1
    arc_1_19_21  original_T_including_depot_unload_1307  2.4191291221621205e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_21  arc_capacity_1178  1
    load_1_19_21  free_load_conservation_1291  1
    load_1_19_21  free_load_conservation_1303  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_0  arc_capacity_1180  -25
    arc_1_20_0  depot_return_or_bypass_1227  1
    arc_1_20_0  out_degree_1292  1
    arc_1_20_0  original_T_including_depot_unload_1307  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_0  arc_capacity_1180  1
    load_1_20_0  free_load_conservation_1297  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_7  arc_capacity_1181  -25
    arc_1_20_7  connected_order_arc_1182  -13
    arc_1_20_7  in_degree_1229  1
    arc_1_20_7  out_degree_1292  1
    arc_1_20_7  original_T_including_depot_unload_1307  1.3600272346134373e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_7  arc_capacity_1181  1
    load_1_20_7  segment_load_conservation_1232  -1
    load_1_20_7  segment_prefix_lb_1233  1
    load_1_20_7  segment_prefix_ub_1234  1
    load_1_20_7  free_load_conservation_1297  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_8  arc_capacity_1183  -25
    arc_1_20_8  connected_order_arc_1184  -13
    arc_1_20_8  in_degree_1236  1
    arc_1_20_8  out_degree_1292  1
    arc_1_20_8  original_T_including_depot_unload_1307  1.3653307388496069e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_8  arc_capacity_1183  1
    load_1_20_8  segment_load_conservation_1239  -1
    load_1_20_8  segment_prefix_lb_1240  1
    load_1_20_8  segment_prefix_ub_1241  1
    load_1_20_8  free_load_conservation_1297  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_9  arc_capacity_1185  -25
    arc_1_20_9  connected_order_arc_1186  -13
    arc_1_20_9  in_degree_1243  1
    arc_1_20_9  out_degree_1292  1
    arc_1_20_9  original_T_including_depot_unload_1307  1.4805184908215606e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_9  arc_capacity_1185  1
    load_1_20_9  segment_load_conservation_1246  -1
    load_1_20_9  segment_prefix_lb_1247  1
    load_1_20_9  segment_prefix_ub_1248  1
    load_1_20_9  free_load_conservation_1297  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_10  arc_capacity_1187  -25
    arc_1_20_10  connected_order_arc_1188  -13
    arc_1_20_10  in_degree_1250  1
    arc_1_20_10  out_degree_1292  1
    arc_1_20_10  original_T_including_depot_unload_1307  6.1704611580490348e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_10  arc_capacity_1187  1
    load_1_20_10  segment_load_conservation_1253  -1
    load_1_20_10  segment_prefix_lb_1254  1
    load_1_20_10  segment_prefix_ub_1255  1
    load_1_20_10  free_load_conservation_1297  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_14  arc_capacity_1189  -25
    arc_1_20_14  connected_order_arc_1190  -13
    arc_1_20_14  in_degree_1257  1
    arc_1_20_14  out_degree_1292  1
    arc_1_20_14  original_T_including_depot_unload_1307  4.3129452098285111e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_14  arc_capacity_1189  1
    load_1_20_14  free_load_conservation_1261  -1
    load_1_20_14  free_load_conservation_1297  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_15  arc_capacity_1191  -25
    arc_1_20_15  connected_order_arc_1192  -13
    arc_1_20_15  in_degree_1263  1
    arc_1_20_15  out_degree_1292  1
    arc_1_20_15  original_T_including_depot_unload_1307  6.4542450829473034e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_15  arc_capacity_1191  1
    load_1_20_15  free_load_conservation_1267  -1
    load_1_20_15  free_load_conservation_1297  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_16  arc_capacity_1193  -25
    arc_1_20_16  connected_order_arc_1194  -13
    arc_1_20_16  in_degree_1269  1
    arc_1_20_16  out_degree_1292  1
    arc_1_20_16  original_T_including_depot_unload_1307  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_16  arc_capacity_1193  1
    load_1_20_16  free_load_conservation_1273  -1
    load_1_20_16  free_load_conservation_1297  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_17  arc_capacity_1195  -25
    arc_1_20_17  connected_order_arc_1196  -13
    arc_1_20_17  in_degree_1275  1
    arc_1_20_17  out_degree_1292  1
    arc_1_20_17  original_T_including_depot_unload_1307  1.6597164064313077e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_17  arc_capacity_1195  1
    load_1_20_17  free_load_conservation_1279  -1
    load_1_20_17  free_load_conservation_1297  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_18  arc_capacity_1197  -25
    arc_1_20_18  connected_order_arc_1198  -13
    arc_1_20_18  in_degree_1281  1
    arc_1_20_18  out_degree_1292  1
    arc_1_20_18  original_T_including_depot_unload_1307  4.6772747357218117e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_18  arc_capacity_1197  1
    load_1_20_18  free_load_conservation_1285  -1
    load_1_20_18  free_load_conservation_1297  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_19  arc_capacity_1199  -25
    arc_1_20_19  connected_order_arc_1200  -13
    arc_1_20_19  in_degree_1287  1
    arc_1_20_19  out_degree_1292  1
    arc_1_20_19  original_T_including_depot_unload_1307  5.8212369880329140e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_19  arc_capacity_1199  1
    load_1_20_19  free_load_conservation_1291  -1
    load_1_20_19  free_load_conservation_1297  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_21  arc_capacity_1201  -25
    arc_1_20_21  connected_order_arc_1202  -13
    arc_1_20_21  out_degree_1292  1
    arc_1_20_21  in_degree_1299  1
    arc_1_20_21  original_T_including_depot_unload_1307  3.8790073962518773e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_21  arc_capacity_1201  1
    load_1_20_21  free_load_conservation_1297  1
    load_1_20_21  free_load_conservation_1303  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_0  arc_capacity_1203  -25
    arc_1_21_0  depot_return_or_bypass_1227  1
    arc_1_21_0  out_degree_1298  1
    arc_1_21_0  original_T_including_depot_unload_1307  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_0  arc_capacity_1203  1
    load_1_21_0  free_load_conservation_1303  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_7  arc_capacity_1204  -25
    arc_1_21_7  connected_order_arc_1205  -13
    arc_1_21_7  in_degree_1229  1
    arc_1_21_7  out_degree_1298  1
    arc_1_21_7  original_T_including_depot_unload_1307  1.1005939447212634e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_7  arc_capacity_1204  1
    load_1_21_7  segment_load_conservation_1232  -1
    load_1_21_7  segment_prefix_lb_1233  1
    load_1_21_7  segment_prefix_ub_1234  1
    load_1_21_7  free_load_conservation_1303  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_8  arc_capacity_1206  -25
    arc_1_21_8  connected_order_arc_1207  -13
    arc_1_21_8  in_degree_1236  1
    arc_1_21_8  out_degree_1298  1
    arc_1_21_8  original_T_including_depot_unload_1307  1.0311494902403294e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_8  arc_capacity_1206  1
    load_1_21_8  segment_load_conservation_1239  -1
    load_1_21_8  segment_prefix_lb_1240  1
    load_1_21_8  segment_prefix_ub_1241  1
    load_1_21_8  free_load_conservation_1303  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_9  arc_capacity_1208  -25
    arc_1_21_9  connected_order_arc_1209  -13
    arc_1_21_9  in_degree_1243  1
    arc_1_21_9  out_degree_1298  1
    arc_1_21_9  original_T_including_depot_unload_1307  1.2442780266664952e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_9  arc_capacity_1208  1
    load_1_21_9  segment_load_conservation_1246  -1
    load_1_21_9  segment_prefix_lb_1247  1
    load_1_21_9  segment_prefix_ub_1248  1
    load_1_21_9  free_load_conservation_1303  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_10  arc_capacity_1210  -25
    arc_1_21_10  connected_order_arc_1211  -13
    arc_1_21_10  in_degree_1250  1
    arc_1_21_10  out_degree_1298  1
    arc_1_21_10  original_T_including_depot_unload_1307  359.975566576564
    MARKER    'MARKER'                 'INTEND'
    load_1_21_10  arc_capacity_1210  1
    load_1_21_10  segment_load_conservation_1253  -1
    load_1_21_10  segment_prefix_lb_1254  1
    load_1_21_10  segment_prefix_ub_1255  1
    load_1_21_10  free_load_conservation_1303  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_14  arc_capacity_1212  -25
    arc_1_21_14  connected_order_arc_1213  -13
    arc_1_21_14  in_degree_1257  1
    arc_1_21_14  out_degree_1298  1
    arc_1_21_14  original_T_including_depot_unload_1307  3.2938591738444967e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_14  arc_capacity_1212  1
    load_1_21_14  free_load_conservation_1261  -1
    load_1_21_14  free_load_conservation_1303  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_15  arc_capacity_1214  -25
    arc_1_21_15  connected_order_arc_1215  -13
    arc_1_21_15  in_degree_1263  1
    arc_1_21_15  out_degree_1298  1
    arc_1_21_15  original_T_including_depot_unload_1307  4.6276703023336785e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_15  arc_capacity_1214  1
    load_1_21_15  free_load_conservation_1267  -1
    load_1_21_15  free_load_conservation_1303  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_16  arc_capacity_1216  -25
    arc_1_21_16  connected_order_arc_1217  -13
    arc_1_21_16  in_degree_1269  1
    arc_1_21_16  out_degree_1298  1
    arc_1_21_16  original_T_including_depot_unload_1307  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_16  arc_capacity_1216  1
    load_1_21_16  free_load_conservation_1273  -1
    load_1_21_16  free_load_conservation_1303  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_17  arc_capacity_1218  -25
    arc_1_21_17  connected_order_arc_1219  -13
    arc_1_21_17  in_degree_1275  1
    arc_1_21_17  out_degree_1298  1
    arc_1_21_17  original_T_including_depot_unload_1307  2.4083746437975364e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_17  arc_capacity_1218  1
    load_1_21_17  free_load_conservation_1279  -1
    load_1_21_17  free_load_conservation_1303  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_18  arc_capacity_1220  -25
    arc_1_21_18  connected_order_arc_1221  -13
    arc_1_21_18  in_degree_1281  1
    arc_1_21_18  out_degree_1298  1
    arc_1_21_18  original_T_including_depot_unload_1307  7.8947565022471792e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_18  arc_capacity_1220  1
    load_1_21_18  free_load_conservation_1285  -1
    load_1_21_18  free_load_conservation_1303  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_19  arc_capacity_1222  -25
    arc_1_21_19  connected_order_arc_1223  -13
    arc_1_21_19  in_degree_1287  1
    arc_1_21_19  out_degree_1298  1
    arc_1_21_19  original_T_including_depot_unload_1307  2.4191291221621205e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_19  arc_capacity_1222  1
    load_1_21_19  free_load_conservation_1291  -1
    load_1_21_19  free_load_conservation_1303  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_20  arc_capacity_1224  -25
    arc_1_21_20  connected_order_arc_1225  -13
    arc_1_21_20  in_degree_1293  1
    arc_1_21_20  out_degree_1298  1
    arc_1_21_20  original_T_including_depot_unload_1307  3.8790073962518773e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_20  arc_capacity_1224  1
    load_1_21_20  free_load_conservation_1297  -1
    load_1_21_20  free_load_conservation_1303  1
    visit_2_11  out_degree_1553  -1
    visit_2_11  in_degree_1554  -1
    visit_2_11  order_active_lb_1555  -1
    visit_2_11  order_active_ub_1556  -11
    order_2_11  connected_order_arc_1322  -1
    order_2_11  connected_order_arc_1324  -1
    order_2_11  connected_order_arc_1326  -1
    order_2_11  connected_order_arc_1328  -1
    order_2_11  connected_order_arc_1330  -1
    order_2_11  connected_order_arc_1332  -1
    order_2_11  connected_order_arc_1334  -1
    order_2_11  connected_order_arc_1336  -1
    order_2_11  connected_order_arc_1338  -1
    order_2_11  connected_order_arc_1340  -1
    order_2_11  connected_order_arc_1343  1
    order_2_11  connected_order_arc_1364  1
    order_2_11  connected_order_arc_1385  1
    order_2_11  connected_order_arc_1406  1
    order_2_11  connected_order_arc_1427  1
    order_2_11  connected_order_arc_1448  1
    order_2_11  connected_order_arc_1469  1
    order_2_11  connected_order_arc_1490  1
    order_2_11  connected_order_arc_1511  1
    order_2_11  connected_order_arc_1532  1
    order_2_11  order_active_lb_1555  1
    order_2_11  order_active_ub_1556  1
    order_2_11  fixed_segment_relative_order_1622  -1
    visit_2_12  out_degree_1560  -1
    visit_2_12  in_degree_1561  -1
    visit_2_12  order_active_lb_1562  -1
    visit_2_12  order_active_ub_1563  -11
    order_2_12  connected_order_arc_1322  1
    order_2_12  connected_order_arc_1343  -1
    order_2_12  connected_order_arc_1345  -1
    order_2_12  connected_order_arc_1347  -1
    order_2_12  connected_order_arc_1349  -1
    order_2_12  connected_order_arc_1351  -1
    order_2_12  connected_order_arc_1353  -1
    order_2_12  connected_order_arc_1355  -1
    order_2_12  connected_order_arc_1357  -1
    order_2_12  connected_order_arc_1359  -1
    order_2_12  connected_order_arc_1361  -1
    order_2_12  connected_order_arc_1366  1
    order_2_12  connected_order_arc_1387  1
    order_2_12  connected_order_arc_1408  1
    order_2_12  connected_order_arc_1429  1
    order_2_12  connected_order_arc_1450  1
    order_2_12  connected_order_arc_1471  1
    order_2_12  connected_order_arc_1492  1
    order_2_12  connected_order_arc_1513  1
    order_2_12  connected_order_arc_1534  1
    order_2_12  order_active_lb_1562  1
    order_2_12  order_active_ub_1563  1
    order_2_12  fixed_segment_relative_order_1622  1
    order_2_12  fixed_segment_relative_order_1623  -1
    visit_2_13  out_degree_1567  -1
    visit_2_13  in_degree_1568  -1
    visit_2_13  order_active_lb_1569  -1
    visit_2_13  order_active_ub_1570  -11
    order_2_13  connected_order_arc_1324  1
    order_2_13  connected_order_arc_1345  1
    order_2_13  connected_order_arc_1364  -1
    order_2_13  connected_order_arc_1366  -1
    order_2_13  connected_order_arc_1368  -1
    order_2_13  connected_order_arc_1370  -1
    order_2_13  connected_order_arc_1372  -1
    order_2_13  connected_order_arc_1374  -1
    order_2_13  connected_order_arc_1376  -1
    order_2_13  connected_order_arc_1378  -1
    order_2_13  connected_order_arc_1380  -1
    order_2_13  connected_order_arc_1382  -1
    order_2_13  connected_order_arc_1389  1
    order_2_13  connected_order_arc_1410  1
    order_2_13  connected_order_arc_1431  1
    order_2_13  connected_order_arc_1452  1
    order_2_13  connected_order_arc_1473  1
    order_2_13  connected_order_arc_1494  1
    order_2_13  connected_order_arc_1515  1
    order_2_13  connected_order_arc_1536  1
    order_2_13  order_active_lb_1569  1
    order_2_13  order_active_ub_1570  1
    order_2_13  fixed_segment_relative_order_1623  1
    visit_2_14  out_degree_1574  -1
    visit_2_14  in_degree_1575  -1
    visit_2_14  order_active_lb_1576  -1
    visit_2_14  order_active_ub_1577  -11
    visit_2_14  service_visit_def_1578  -1
    order_2_14  connected_order_arc_1326  1
    order_2_14  connected_order_arc_1347  1
    order_2_14  connected_order_arc_1368  1
    order_2_14  connected_order_arc_1385  -1
    order_2_14  connected_order_arc_1387  -1
    order_2_14  connected_order_arc_1389  -1
    order_2_14  connected_order_arc_1391  -1
    order_2_14  connected_order_arc_1393  -1
    order_2_14  connected_order_arc_1395  -1
    order_2_14  connected_order_arc_1397  -1
    order_2_14  connected_order_arc_1399  -1
    order_2_14  connected_order_arc_1401  -1
    order_2_14  connected_order_arc_1403  -1
    order_2_14  connected_order_arc_1412  1
    order_2_14  connected_order_arc_1433  1
    order_2_14  connected_order_arc_1454  1
    order_2_14  connected_order_arc_1475  1
    order_2_14  connected_order_arc_1496  1
    order_2_14  connected_order_arc_1517  1
    order_2_14  connected_order_arc_1538  1
    order_2_14  order_active_lb_1576  1
    order_2_14  order_active_ub_1577  1
    visit_2_15  out_degree_1580  -1
    visit_2_15  in_degree_1581  -1
    visit_2_15  order_active_lb_1582  -1
    visit_2_15  order_active_ub_1583  -11
    visit_2_15  service_visit_def_1584  -1
    order_2_15  connected_order_arc_1328  1
    order_2_15  connected_order_arc_1349  1
    order_2_15  connected_order_arc_1370  1
    order_2_15  connected_order_arc_1391  1
    order_2_15  connected_order_arc_1406  -1
    order_2_15  connected_order_arc_1408  -1
    order_2_15  connected_order_arc_1410  -1
    order_2_15  connected_order_arc_1412  -1
    order_2_15  connected_order_arc_1414  -1
    order_2_15  connected_order_arc_1416  -1
    order_2_15  connected_order_arc_1418  -1
    order_2_15  connected_order_arc_1420  -1
    order_2_15  connected_order_arc_1422  -1
    order_2_15  connected_order_arc_1424  -1
    order_2_15  connected_order_arc_1435  1
    order_2_15  connected_order_arc_1456  1
    order_2_15  connected_order_arc_1477  1
    order_2_15  connected_order_arc_1498  1
    order_2_15  connected_order_arc_1519  1
    order_2_15  connected_order_arc_1540  1
    order_2_15  order_active_lb_1582  1
    order_2_15  order_active_ub_1583  1
    visit_2_16  out_degree_1586  -1
    visit_2_16  in_degree_1587  -1
    visit_2_16  order_active_lb_1588  -1
    visit_2_16  order_active_ub_1589  -11
    visit_2_16  service_visit_def_1590  -1
    order_2_16  connected_order_arc_1330  1
    order_2_16  connected_order_arc_1351  1
    order_2_16  connected_order_arc_1372  1
    order_2_16  connected_order_arc_1393  1
    order_2_16  connected_order_arc_1414  1
    order_2_16  connected_order_arc_1427  -1
    order_2_16  connected_order_arc_1429  -1
    order_2_16  connected_order_arc_1431  -1
    order_2_16  connected_order_arc_1433  -1
    order_2_16  connected_order_arc_1435  -1
    order_2_16  connected_order_arc_1437  -1
    order_2_16  connected_order_arc_1439  -1
    order_2_16  connected_order_arc_1441  -1
    order_2_16  connected_order_arc_1443  -1
    order_2_16  connected_order_arc_1445  -1
    order_2_16  connected_order_arc_1458  1
    order_2_16  connected_order_arc_1479  1
    order_2_16  connected_order_arc_1500  1
    order_2_16  connected_order_arc_1521  1
    order_2_16  connected_order_arc_1542  1
    order_2_16  order_active_lb_1588  1
    order_2_16  order_active_ub_1589  1
    visit_2_17  out_degree_1592  -1
    visit_2_17  in_degree_1593  -1
    visit_2_17  order_active_lb_1594  -1
    visit_2_17  order_active_ub_1595  -11
    visit_2_17  service_visit_def_1596  -1
    order_2_17  connected_order_arc_1332  1
    order_2_17  connected_order_arc_1353  1
    order_2_17  connected_order_arc_1374  1
    order_2_17  connected_order_arc_1395  1
    order_2_17  connected_order_arc_1416  1
    order_2_17  connected_order_arc_1437  1
    order_2_17  connected_order_arc_1448  -1
    order_2_17  connected_order_arc_1450  -1
    order_2_17  connected_order_arc_1452  -1
    order_2_17  connected_order_arc_1454  -1
    order_2_17  connected_order_arc_1456  -1
    order_2_17  connected_order_arc_1458  -1
    order_2_17  connected_order_arc_1460  -1
    order_2_17  connected_order_arc_1462  -1
    order_2_17  connected_order_arc_1464  -1
    order_2_17  connected_order_arc_1466  -1
    order_2_17  connected_order_arc_1481  1
    order_2_17  connected_order_arc_1502  1
    order_2_17  connected_order_arc_1523  1
    order_2_17  connected_order_arc_1544  1
    order_2_17  order_active_lb_1594  1
    order_2_17  order_active_ub_1595  1
    visit_2_18  out_degree_1598  -1
    visit_2_18  in_degree_1599  -1
    visit_2_18  order_active_lb_1600  -1
    visit_2_18  order_active_ub_1601  -11
    visit_2_18  service_visit_def_1602  -1
    order_2_18  connected_order_arc_1334  1
    order_2_18  connected_order_arc_1355  1
    order_2_18  connected_order_arc_1376  1
    order_2_18  connected_order_arc_1397  1
    order_2_18  connected_order_arc_1418  1
    order_2_18  connected_order_arc_1439  1
    order_2_18  connected_order_arc_1460  1
    order_2_18  connected_order_arc_1469  -1
    order_2_18  connected_order_arc_1471  -1
    order_2_18  connected_order_arc_1473  -1
    order_2_18  connected_order_arc_1475  -1
    order_2_18  connected_order_arc_1477  -1
    order_2_18  connected_order_arc_1479  -1
    order_2_18  connected_order_arc_1481  -1
    order_2_18  connected_order_arc_1483  -1
    order_2_18  connected_order_arc_1485  -1
    order_2_18  connected_order_arc_1487  -1
    order_2_18  connected_order_arc_1504  1
    order_2_18  connected_order_arc_1525  1
    order_2_18  connected_order_arc_1546  1
    order_2_18  order_active_lb_1600  1
    order_2_18  order_active_ub_1601  1
    visit_2_19  out_degree_1604  -1
    visit_2_19  in_degree_1605  -1
    visit_2_19  order_active_lb_1606  -1
    visit_2_19  order_active_ub_1607  -11
    visit_2_19  service_visit_def_1608  -1
    order_2_19  connected_order_arc_1336  1
    order_2_19  connected_order_arc_1357  1
    order_2_19  connected_order_arc_1378  1
    order_2_19  connected_order_arc_1399  1
    order_2_19  connected_order_arc_1420  1
    order_2_19  connected_order_arc_1441  1
    order_2_19  connected_order_arc_1462  1
    order_2_19  connected_order_arc_1483  1
    order_2_19  connected_order_arc_1490  -1
    order_2_19  connected_order_arc_1492  -1
    order_2_19  connected_order_arc_1494  -1
    order_2_19  connected_order_arc_1496  -1
    order_2_19  connected_order_arc_1498  -1
    order_2_19  connected_order_arc_1500  -1
    order_2_19  connected_order_arc_1502  -1
    order_2_19  connected_order_arc_1504  -1
    order_2_19  connected_order_arc_1506  -1
    order_2_19  connected_order_arc_1508  -1
    order_2_19  connected_order_arc_1527  1
    order_2_19  connected_order_arc_1548  1
    order_2_19  order_active_lb_1606  1
    order_2_19  order_active_ub_1607  1
    visit_2_20  out_degree_1610  -1
    visit_2_20  in_degree_1611  -1
    visit_2_20  order_active_lb_1612  -1
    visit_2_20  order_active_ub_1613  -11
    visit_2_20  service_visit_def_1614  -1
    order_2_20  connected_order_arc_1338  1
    order_2_20  connected_order_arc_1359  1
    order_2_20  connected_order_arc_1380  1
    order_2_20  connected_order_arc_1401  1
    order_2_20  connected_order_arc_1422  1
    order_2_20  connected_order_arc_1443  1
    order_2_20  connected_order_arc_1464  1
    order_2_20  connected_order_arc_1485  1
    order_2_20  connected_order_arc_1506  1
    order_2_20  connected_order_arc_1511  -1
    order_2_20  connected_order_arc_1513  -1
    order_2_20  connected_order_arc_1515  -1
    order_2_20  connected_order_arc_1517  -1
    order_2_20  connected_order_arc_1519  -1
    order_2_20  connected_order_arc_1521  -1
    order_2_20  connected_order_arc_1523  -1
    order_2_20  connected_order_arc_1525  -1
    order_2_20  connected_order_arc_1527  -1
    order_2_20  connected_order_arc_1529  -1
    order_2_20  connected_order_arc_1550  1
    order_2_20  order_active_lb_1612  1
    order_2_20  order_active_ub_1613  1
    visit_2_21  out_degree_1616  -1
    visit_2_21  in_degree_1617  -1
    visit_2_21  order_active_lb_1618  -1
    visit_2_21  order_active_ub_1619  -11
    visit_2_21  service_visit_def_1620  -1
    order_2_21  connected_order_arc_1340  1
    order_2_21  connected_order_arc_1361  1
    order_2_21  connected_order_arc_1382  1
    order_2_21  connected_order_arc_1403  1
    order_2_21  connected_order_arc_1424  1
    order_2_21  connected_order_arc_1445  1
    order_2_21  connected_order_arc_1466  1
    order_2_21  connected_order_arc_1487  1
    order_2_21  connected_order_arc_1508  1
    order_2_21  connected_order_arc_1529  1
    order_2_21  connected_order_arc_1532  -1
    order_2_21  connected_order_arc_1534  -1
    order_2_21  connected_order_arc_1536  -1
    order_2_21  connected_order_arc_1538  -1
    order_2_21  connected_order_arc_1540  -1
    order_2_21  connected_order_arc_1542  -1
    order_2_21  connected_order_arc_1544  -1
    order_2_21  connected_order_arc_1546  -1
    order_2_21  connected_order_arc_1548  -1
    order_2_21  connected_order_arc_1550  -1
    order_2_21  order_active_lb_1618  1
    order_2_21  order_active_ub_1619  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_0  arc_capacity_1308  -30
    arc_2_0_0  depot_departure_or_bypass_1551  1
    arc_2_0_0  depot_return_or_bypass_1552  1
    MARKER    'MARKER'                 'INTEND'
    load_2_0_0  arc_capacity_1308  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_11  arc_capacity_1309  -30
    arc_2_0_11  depot_departure_or_bypass_1551  1
    arc_2_0_11  in_degree_1554  1
    arc_2_0_11  original_T_including_depot_unload_1624  1.4567038050199781e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_11  arc_capacity_1309  1
    load_2_0_11  segment_load_conservation_1557  -1
    load_2_0_11  segment_prefix_lb_1558  1
    load_2_0_11  segment_prefix_ub_1559  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_12  arc_capacity_1310  -30
    arc_2_0_12  depot_departure_or_bypass_1551  1
    arc_2_0_12  in_degree_1561  1
    arc_2_0_12  original_T_including_depot_unload_1624  1.4501558573355060e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_12  arc_capacity_1310  1
    load_2_0_12  segment_load_conservation_1564  -1
    load_2_0_12  segment_prefix_lb_1565  1
    load_2_0_12  segment_prefix_ub_1566  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_13  arc_capacity_1311  -30
    arc_2_0_13  depot_departure_or_bypass_1551  1
    arc_2_0_13  in_degree_1568  1
    arc_2_0_13  original_T_including_depot_unload_1624  1.3396590612935172e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_13  arc_capacity_1311  1
    load_2_0_13  segment_load_conservation_1571  -1
    load_2_0_13  segment_prefix_lb_1572  1
    load_2_0_13  segment_prefix_ub_1573  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_14  arc_capacity_1312  -30
    arc_2_0_14  depot_departure_or_bypass_1551  1
    arc_2_0_14  in_degree_1575  1
    arc_2_0_14  original_T_including_depot_unload_1624  5.9431738885389052e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_14  arc_capacity_1312  1
    load_2_0_14  free_load_conservation_1579  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_15  arc_capacity_1313  -30
    arc_2_0_15  depot_departure_or_bypass_1551  1
    arc_2_0_15  in_degree_1581  1
    arc_2_0_15  original_T_including_depot_unload_1624  7.2571167924583824e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_15  arc_capacity_1313  1
    load_2_0_15  free_load_conservation_1585  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_16  arc_capacity_1314  -30
    arc_2_0_16  depot_departure_or_bypass_1551  1
    arc_2_0_16  in_degree_1587  1
    arc_2_0_16  original_T_including_depot_unload_1624  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_16  arc_capacity_1314  1
    load_2_0_16  free_load_conservation_1591  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_17  arc_capacity_1315  -30
    arc_2_0_17  depot_departure_or_bypass_1551  1
    arc_2_0_17  in_degree_1593  1
    arc_2_0_17  original_T_including_depot_unload_1624  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_17  arc_capacity_1315  1
    load_2_0_17  free_load_conservation_1597  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_18  arc_capacity_1316  -30
    arc_2_0_18  depot_departure_or_bypass_1551  1
    arc_2_0_18  in_degree_1599  1
    arc_2_0_18  original_T_including_depot_unload_1624  9.5330620720858735e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_18  arc_capacity_1316  1
    load_2_0_18  free_load_conservation_1603  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_19  arc_capacity_1317  -30
    arc_2_0_19  depot_departure_or_bypass_1551  1
    arc_2_0_19  in_degree_1605  1
    arc_2_0_19  original_T_including_depot_unload_1624  4.6364706268001146e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_19  arc_capacity_1317  1
    load_2_0_19  free_load_conservation_1609  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_20  arc_capacity_1318  -30
    arc_2_0_20  depot_departure_or_bypass_1551  1
    arc_2_0_20  in_degree_1611  1
    arc_2_0_20  original_T_including_depot_unload_1624  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_20  arc_capacity_1318  1
    load_2_0_20  free_load_conservation_1615  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_21  arc_capacity_1319  -30
    arc_2_0_21  depot_departure_or_bypass_1551  1
    arc_2_0_21  in_degree_1617  1
    arc_2_0_21  original_T_including_depot_unload_1624  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_21  arc_capacity_1319  1
    load_2_0_21  free_load_conservation_1621  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_0  arc_capacity_1320  -30
    arc_2_11_0  depot_return_or_bypass_1552  1
    arc_2_11_0  out_degree_1553  1
    arc_2_11_0  original_T_including_depot_unload_1624  1.2506062209426416e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_0  arc_capacity_1320  1
    load_2_11_0  segment_load_conservation_1557  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_12  arc_capacity_1321  -30
    arc_2_11_12  connected_order_arc_1322  -12
    arc_2_11_12  out_degree_1553  1
    arc_2_11_12  in_degree_1561  1
    arc_2_11_12  original_T_including_depot_unload_1624  1.6502895430075375e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_12  arc_capacity_1321  1
    load_2_11_12  segment_load_conservation_1557  1
    load_2_11_12  segment_load_conservation_1564  -1
    load_2_11_12  segment_prefix_lb_1565  1
    load_2_11_12  segment_prefix_ub_1566  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_13  arc_capacity_1323  -30
    arc_2_11_13  connected_order_arc_1324  -12
    arc_2_11_13  out_degree_1553  1
    arc_2_11_13  in_degree_1568  1
    arc_2_11_13  original_T_including_depot_unload_1624  1.9038107656775676e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_13  arc_capacity_1323  1
    load_2_11_13  segment_load_conservation_1557  1
    load_2_11_13  segment_load_conservation_1571  -1
    load_2_11_13  segment_prefix_lb_1572  1
    load_2_11_13  segment_prefix_ub_1573  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_14  arc_capacity_1325  -30
    arc_2_11_14  connected_order_arc_1326  -12
    arc_2_11_14  out_degree_1553  1
    arc_2_11_14  in_degree_1575  1
    arc_2_11_14  original_T_including_depot_unload_1624  8.0231446125927152e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_14  arc_capacity_1325  1
    load_2_11_14  segment_load_conservation_1557  1
    load_2_11_14  free_load_conservation_1579  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_15  arc_capacity_1327  -30
    arc_2_11_15  connected_order_arc_1328  -12
    arc_2_11_15  out_degree_1553  1
    arc_2_11_15  in_degree_1581  1
    arc_2_11_15  original_T_including_depot_unload_1624  5.8943244236516807e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_15  arc_capacity_1327  1
    load_2_11_15  segment_load_conservation_1557  1
    load_2_11_15  free_load_conservation_1585  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_16  arc_capacity_1329  -30
    arc_2_11_16  connected_order_arc_1330  -12
    arc_2_11_16  out_degree_1553  1
    arc_2_11_16  in_degree_1587  1
    arc_2_11_16  original_T_including_depot_unload_1624  1.4255422670497167e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_16  arc_capacity_1329  1
    load_2_11_16  segment_load_conservation_1557  1
    load_2_11_16  free_load_conservation_1591  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_17  arc_capacity_1331  -30
    arc_2_11_17  connected_order_arc_1332  -12
    arc_2_11_17  out_degree_1553  1
    arc_2_11_17  in_degree_1593  1
    arc_2_11_17  original_T_including_depot_unload_1624  1.0874822831610163e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_17  arc_capacity_1331  1
    load_2_11_17  segment_load_conservation_1557  1
    load_2_11_17  free_load_conservation_1597  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_18  arc_capacity_1333  -30
    arc_2_11_18  connected_order_arc_1334  -12
    arc_2_11_18  out_degree_1553  1
    arc_2_11_18  in_degree_1599  1
    arc_2_11_18  original_T_including_depot_unload_1624  1.2941622036935485e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_18  arc_capacity_1333  1
    load_2_11_18  segment_load_conservation_1557  1
    load_2_11_18  free_load_conservation_1603  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_19  arc_capacity_1335  -30
    arc_2_11_19  connected_order_arc_1336  -12
    arc_2_11_19  out_degree_1553  1
    arc_2_11_19  in_degree_1605  1
    arc_2_11_19  original_T_including_depot_unload_1624  7.8724938919046190e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_19  arc_capacity_1335  1
    load_2_11_19  segment_load_conservation_1557  1
    load_2_11_19  free_load_conservation_1609  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_20  arc_capacity_1337  -30
    arc_2_11_20  connected_order_arc_1338  -12
    arc_2_11_20  out_degree_1553  1
    arc_2_11_20  in_degree_1611  1
    arc_2_11_20  original_T_including_depot_unload_1624  1.2335670980381785e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_20  arc_capacity_1337  1
    load_2_11_20  segment_load_conservation_1557  1
    load_2_11_20  free_load_conservation_1615  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_21  arc_capacity_1339  -30
    arc_2_11_21  connected_order_arc_1340  -12
    arc_2_11_21  out_degree_1553  1
    arc_2_11_21  in_degree_1617  1
    arc_2_11_21  original_T_including_depot_unload_1624  1.0138993437494995e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_21  arc_capacity_1339  1
    load_2_11_21  segment_load_conservation_1557  1
    load_2_11_21  free_load_conservation_1621  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_0  arc_capacity_1341  -30
    arc_2_12_0  depot_return_or_bypass_1552  1
    arc_2_12_0  out_degree_1560  1
    arc_2_12_0  original_T_including_depot_unload_1624  1.4501558573355060e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_0  arc_capacity_1341  1
    load_2_12_0  segment_load_conservation_1564  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_11  arc_capacity_1342  -30
    arc_2_12_11  connected_order_arc_1343  -12
    arc_2_12_11  in_degree_1554  1
    arc_2_12_11  out_degree_1560  1
    arc_2_12_11  original_T_including_depot_unload_1624  2.1542021003680966e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_11  arc_capacity_1342  1
    load_2_12_11  segment_load_conservation_1557  -1
    load_2_12_11  segment_prefix_lb_1558  1
    load_2_12_11  segment_prefix_ub_1559  1
    load_2_12_11  segment_load_conservation_1564  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_13  arc_capacity_1344  -30
    arc_2_12_13  connected_order_arc_1345  -12
    arc_2_12_13  out_degree_1560  1
    arc_2_12_13  in_degree_1568  1
    arc_2_12_13  original_T_including_depot_unload_1624  4.8781034218421996e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_13  arc_capacity_1344  1
    load_2_12_13  segment_load_conservation_1564  1
    load_2_12_13  segment_load_conservation_1571  -1
    load_2_12_13  segment_prefix_lb_1572  1
    load_2_12_13  segment_prefix_ub_1573  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_14  arc_capacity_1346  -30
    arc_2_12_14  connected_order_arc_1347  -12
    arc_2_12_14  out_degree_1560  1
    arc_2_12_14  in_degree_1575  1
    arc_2_12_14  original_T_including_depot_unload_1624  1.1016218375294079e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_14  arc_capacity_1346  1
    load_2_12_14  segment_load_conservation_1564  1
    load_2_12_14  free_load_conservation_1579  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_15  arc_capacity_1348  -30
    arc_2_12_15  connected_order_arc_1349  -12
    arc_2_12_15  out_degree_1560  1
    arc_2_12_15  in_degree_1581  1
    arc_2_12_15  original_T_including_depot_unload_1624  1.2399174881238241e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_15  arc_capacity_1348  1
    load_2_12_15  segment_load_conservation_1564  1
    load_2_12_15  free_load_conservation_1585  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_16  arc_capacity_1350  -30
    arc_2_12_16  connected_order_arc_1351  -12
    arc_2_12_16  out_degree_1560  1
    arc_2_12_16  in_degree_1587  1
    arc_2_12_16  original_T_including_depot_unload_1624  2.4496137598598170e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_16  arc_capacity_1350  1
    load_2_12_16  segment_load_conservation_1564  1
    load_2_12_16  free_load_conservation_1591  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_17  arc_capacity_1352  -30
    arc_2_12_17  connected_order_arc_1353  -12
    arc_2_12_17  out_degree_1560  1
    arc_2_12_17  in_degree_1593  1
    arc_2_12_17  original_T_including_depot_unload_1624  1.0592524244968324e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_17  arc_capacity_1352  1
    load_2_12_17  segment_load_conservation_1564  1
    load_2_12_17  free_load_conservation_1597  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_18  arc_capacity_1354  -30
    arc_2_12_18  connected_order_arc_1355  -12
    arc_2_12_18  out_degree_1560  1
    arc_2_12_18  in_degree_1599  1
    arc_2_12_18  original_T_including_depot_unload_1624  5.0525672969651123e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_18  arc_capacity_1354  1
    load_2_12_18  segment_load_conservation_1564  1
    load_2_12_18  free_load_conservation_1603  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_19  arc_capacity_1356  -30
    arc_2_12_19  connected_order_arc_1357  -12
    arc_2_12_19  out_degree_1560  1
    arc_2_12_19  in_degree_1605  1
    arc_2_12_19  original_T_including_depot_unload_1624  1.3898988531263665e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_19  arc_capacity_1356  1
    load_2_12_19  segment_load_conservation_1564  1
    load_2_12_19  free_load_conservation_1609  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_20  arc_capacity_1358  -30
    arc_2_12_20  connected_order_arc_1359  -12
    arc_2_12_20  out_degree_1560  1
    arc_2_12_20  in_degree_1611  1
    arc_2_12_20  original_T_including_depot_unload_1624  9.5901863634429412e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_20  arc_capacity_1358  1
    load_2_12_20  segment_load_conservation_1564  1
    load_2_12_20  free_load_conservation_1615  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_21  arc_capacity_1360  -30
    arc_2_12_21  connected_order_arc_1361  -12
    arc_2_12_21  out_degree_1560  1
    arc_2_12_21  in_degree_1617  1
    arc_2_12_21  original_T_including_depot_unload_1624  1.2946770575314561e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_21  arc_capacity_1360  1
    load_2_12_21  segment_load_conservation_1564  1
    load_2_12_21  free_load_conservation_1621  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_0  arc_capacity_1362  -30
    arc_2_13_0  depot_return_or_bypass_1552  1
    arc_2_13_0  out_degree_1567  1
    arc_2_13_0  original_T_including_depot_unload_1624  1.3396590612935172e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_0  arc_capacity_1362  1
    load_2_13_0  segment_load_conservation_1571  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_11  arc_capacity_1363  -30
    arc_2_13_11  connected_order_arc_1364  -12
    arc_2_13_11  in_degree_1554  1
    arc_2_13_11  out_degree_1567  1
    arc_2_13_11  original_T_including_depot_unload_1624  2362.83310343652
    MARKER    'MARKER'                 'INTEND'
    load_2_13_11  arc_capacity_1363  1
    load_2_13_11  segment_load_conservation_1557  -1
    load_2_13_11  segment_prefix_lb_1558  1
    load_2_13_11  segment_prefix_ub_1559  1
    load_2_13_11  segment_load_conservation_1571  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_12  arc_capacity_1365  -30
    arc_2_13_12  connected_order_arc_1366  -12
    arc_2_13_12  in_degree_1561  1
    arc_2_13_12  out_degree_1567  1
    arc_2_13_12  original_T_including_depot_unload_1624  4.8781034218421996e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_12  arc_capacity_1365  1
    load_2_13_12  segment_load_conservation_1564  -1
    load_2_13_12  segment_prefix_lb_1565  1
    load_2_13_12  segment_prefix_ub_1566  1
    load_2_13_12  segment_load_conservation_1571  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_14  arc_capacity_1367  -30
    arc_2_13_14  connected_order_arc_1368  -12
    arc_2_13_14  out_degree_1567  1
    arc_2_13_14  in_degree_1575  1
    arc_2_13_14  original_T_including_depot_unload_1624  1.1989066345879348e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_14  arc_capacity_1367  1
    load_2_13_14  segment_load_conservation_1571  1
    load_2_13_14  free_load_conservation_1579  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_15  arc_capacity_1369  -30
    arc_2_13_15  connected_order_arc_1370  -12
    arc_2_13_15  out_degree_1567  1
    arc_2_13_15  in_degree_1581  1
    arc_2_13_15  original_T_including_depot_unload_1624  1.3889860796771311e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_15  arc_capacity_1369  1
    load_2_13_15  segment_load_conservation_1571  1
    load_2_13_15  free_load_conservation_1585  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_16  arc_capacity_1371  -30
    arc_2_13_16  connected_order_arc_1372  -12
    arc_2_13_16  out_degree_1567  1
    arc_2_13_16  in_degree_1587  1
    arc_2_13_16  original_T_including_depot_unload_1624  2.4147485851762935e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_16  arc_capacity_1371  1
    load_2_13_16  segment_load_conservation_1571  1
    load_2_13_16  free_load_conservation_1591  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_17  arc_capacity_1373  -30
    arc_2_13_17  connected_order_arc_1374  -12
    arc_2_13_17  out_degree_1567  1
    arc_2_13_17  in_degree_1593  1
    arc_2_13_17  original_T_including_depot_unload_1624  1.0363003610648061e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_17  arc_capacity_1373  1
    load_2_13_17  segment_load_conservation_1571  1
    load_2_13_17  free_load_conservation_1597  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_18  arc_capacity_1375  -30
    arc_2_13_18  connected_order_arc_1376  -12
    arc_2_13_18  out_degree_1567  1
    arc_2_13_18  in_degree_1599  1
    arc_2_13_18  original_T_including_depot_unload_1624  6.0985881995898160e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_18  arc_capacity_1375  1
    load_2_13_18  segment_load_conservation_1571  1
    load_2_13_18  free_load_conservation_1603  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_19  arc_capacity_1377  -30
    arc_2_13_19  connected_order_arc_1378  -12
    arc_2_13_19  out_degree_1567  1
    arc_2_13_19  in_degree_1605  1
    arc_2_13_19  original_T_including_depot_unload_1624  1.4399299780980639e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_19  arc_capacity_1377  1
    load_2_13_19  segment_load_conservation_1571  1
    load_2_13_19  free_load_conservation_1609  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_20  arc_capacity_1379  -30
    arc_2_13_20  connected_order_arc_1380  -12
    arc_2_13_20  out_degree_1567  1
    arc_2_13_20  in_degree_1611  1
    arc_2_13_20  original_T_including_depot_unload_1624  8.8496780902404032e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_20  arc_capacity_1379  1
    load_2_13_20  segment_load_conservation_1571  1
    load_2_13_20  free_load_conservation_1615  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_21  arc_capacity_1381  -30
    arc_2_13_21  connected_order_arc_1382  -12
    arc_2_13_21  out_degree_1567  1
    arc_2_13_21  in_degree_1617  1
    arc_2_13_21  original_T_including_depot_unload_1624  1.2717918724165304e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_21  arc_capacity_1381  1
    load_2_13_21  segment_load_conservation_1571  1
    load_2_13_21  free_load_conservation_1621  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_0  arc_capacity_1383  -30
    arc_2_14_0  depot_return_or_bypass_1552  1
    arc_2_14_0  out_degree_1574  1
    arc_2_14_0  original_T_including_depot_unload_1624  5.9431738885389052e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_0  arc_capacity_1383  1
    load_2_14_0  free_load_conservation_1579  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_11  arc_capacity_1384  -30
    arc_2_14_11  connected_order_arc_1385  -12
    arc_2_14_11  in_degree_1554  1
    arc_2_14_11  out_degree_1574  1
    arc_2_14_11  original_T_including_depot_unload_1624  1.1848225970179703e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_11  arc_capacity_1384  1
    load_2_14_11  segment_load_conservation_1557  -1
    load_2_14_11  segment_prefix_lb_1558  1
    load_2_14_11  segment_prefix_ub_1559  1
    load_2_14_11  free_load_conservation_1579  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_12  arc_capacity_1386  -30
    arc_2_14_12  connected_order_arc_1387  -12
    arc_2_14_12  in_degree_1561  1
    arc_2_14_12  out_degree_1574  1
    arc_2_14_12  original_T_including_depot_unload_1624  1.1016218375294079e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_12  arc_capacity_1386  1
    load_2_14_12  segment_load_conservation_1564  -1
    load_2_14_12  segment_prefix_lb_1565  1
    load_2_14_12  segment_prefix_ub_1566  1
    load_2_14_12  free_load_conservation_1579  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_13  arc_capacity_1388  -30
    arc_2_14_13  connected_order_arc_1389  -12
    arc_2_14_13  in_degree_1568  1
    arc_2_14_13  out_degree_1574  1
    arc_2_14_13  original_T_including_depot_unload_1624  1.1989066345879348e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_13  arc_capacity_1388  1
    load_2_14_13  segment_load_conservation_1571  -1
    load_2_14_13  segment_prefix_lb_1572  1
    load_2_14_13  segment_prefix_ub_1573  1
    load_2_14_13  free_load_conservation_1579  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_15  arc_capacity_1390  -30
    arc_2_14_15  connected_order_arc_1391  -12
    arc_2_14_15  out_degree_1574  1
    arc_2_14_15  in_degree_1581  1
    arc_2_14_15  original_T_including_depot_unload_1624  2.1481294511470344e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_15  arc_capacity_1390  1
    load_2_14_15  free_load_conservation_1579  1
    load_2_14_15  free_load_conservation_1585  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_16  arc_capacity_1392  -30
    arc_2_14_16  connected_order_arc_1393  -12
    arc_2_14_16  out_degree_1574  1
    arc_2_14_16  in_degree_1587  1
    arc_2_14_16  original_T_including_depot_unload_1624  1.3727638439182763e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_16  arc_capacity_1392  1
    load_2_14_16  free_load_conservation_1579  1
    load_2_14_16  free_load_conservation_1591  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_17  arc_capacity_1394  -30
    arc_2_14_17  connected_order_arc_1395  -12
    arc_2_14_17  out_degree_1574  1
    arc_2_14_17  in_degree_1593  1
    arc_2_14_17  original_T_including_depot_unload_1624  2.9098466309579254e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_17  arc_capacity_1394  1
    load_2_14_17  free_load_conservation_1579  1
    load_2_14_17  free_load_conservation_1597  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_18  arc_capacity_1396  -30
    arc_2_14_18  connected_order_arc_1397  -12
    arc_2_14_18  out_degree_1574  1
    arc_2_14_18  in_degree_1599  1
    arc_2_14_18  original_T_including_depot_unload_1624  6.2159179673866879e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_18  arc_capacity_1396  1
    load_2_14_18  free_load_conservation_1579  1
    load_2_14_18  free_load_conservation_1603  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_19  arc_capacity_1398  -30
    arc_2_14_19  connected_order_arc_1399  -12
    arc_2_14_19  out_degree_1574  1
    arc_2_14_19  in_degree_1605  1
    arc_2_14_19  original_T_including_depot_unload_1624  2.9706418113632907e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_19  arc_capacity_1398  1
    load_2_14_19  free_load_conservation_1579  1
    load_2_14_19  free_load_conservation_1609  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_20  arc_capacity_1400  -30
    arc_2_14_20  connected_order_arc_1401  -12
    arc_2_14_20  out_degree_1574  1
    arc_2_14_20  in_degree_1611  1
    arc_2_14_20  original_T_including_depot_unload_1624  4.3129452098285111e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_20  arc_capacity_1400  1
    load_2_14_20  free_load_conservation_1579  1
    load_2_14_20  free_load_conservation_1615  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_21  arc_capacity_1402  -30
    arc_2_14_21  connected_order_arc_1403  -12
    arc_2_14_21  out_degree_1574  1
    arc_2_14_21  in_degree_1617  1
    arc_2_14_21  original_T_including_depot_unload_1624  3.2938591738444967e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_21  arc_capacity_1402  1
    load_2_14_21  free_load_conservation_1579  1
    load_2_14_21  free_load_conservation_1621  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_0  arc_capacity_1404  -30
    arc_2_15_0  depot_return_or_bypass_1552  1
    arc_2_15_0  out_degree_1580  1
    arc_2_15_0  original_T_including_depot_unload_1624  7.2571167924583824e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_0  arc_capacity_1404  1
    load_2_15_0  free_load_conservation_1585  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_11  arc_capacity_1405  -30
    arc_2_15_11  connected_order_arc_1406  -12
    arc_2_15_11  in_degree_1554  1
    arc_2_15_11  out_degree_1580  1
    arc_2_15_11  original_T_including_depot_unload_1624  9.7877495286142823e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_11  arc_capacity_1405  1
    load_2_15_11  segment_load_conservation_1557  -1
    load_2_15_11  segment_prefix_lb_1558  1
    load_2_15_11  segment_prefix_ub_1559  1
    load_2_15_11  free_load_conservation_1585  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_12  arc_capacity_1407  -30
    arc_2_15_12  connected_order_arc_1408  -12
    arc_2_15_12  in_degree_1561  1
    arc_2_15_12  out_degree_1580  1
    arc_2_15_12  original_T_including_depot_unload_1624  1.2399174881238241e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_12  arc_capacity_1407  1
    load_2_15_12  segment_load_conservation_1564  -1
    load_2_15_12  segment_prefix_lb_1565  1
    load_2_15_12  segment_prefix_ub_1566  1
    load_2_15_12  free_load_conservation_1585  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_13  arc_capacity_1409  -30
    arc_2_15_13  connected_order_arc_1410  -12
    arc_2_15_13  in_degree_1568  1
    arc_2_15_13  out_degree_1580  1
    arc_2_15_13  original_T_including_depot_unload_1624  1.3889860796771311e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_13  arc_capacity_1409  1
    load_2_15_13  segment_load_conservation_1571  -1
    load_2_15_13  segment_prefix_lb_1572  1
    load_2_15_13  segment_prefix_ub_1573  1
    load_2_15_13  free_load_conservation_1585  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_14  arc_capacity_1411  -30
    arc_2_15_14  connected_order_arc_1412  -12
    arc_2_15_14  in_degree_1575  1
    arc_2_15_14  out_degree_1580  1
    arc_2_15_14  original_T_including_depot_unload_1624  2.1481294511470344e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_14  arc_capacity_1411  1
    load_2_15_14  free_load_conservation_1579  -1
    load_2_15_14  free_load_conservation_1585  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_16  arc_capacity_1413  -30
    arc_2_15_16  connected_order_arc_1414  -12
    arc_2_15_16  out_degree_1580  1
    arc_2_15_16  in_degree_1587  1
    arc_2_15_16  original_T_including_depot_unload_1624  1.3163662834239574e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_16  arc_capacity_1413  1
    load_2_15_16  free_load_conservation_1585  1
    load_2_15_16  free_load_conservation_1591  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_17  arc_capacity_1415  -30
    arc_2_15_17  connected_order_arc_1416  -12
    arc_2_15_17  out_degree_1580  1
    arc_2_15_17  in_degree_1593  1
    arc_2_15_17  original_T_including_depot_unload_1624  4.9831220386775891e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_17  arc_capacity_1415  1
    load_2_15_17  free_load_conservation_1585  1
    load_2_15_17  free_load_conservation_1597  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_18  arc_capacity_1417  -30
    arc_2_15_18  connected_order_arc_1418  -12
    arc_2_15_18  out_degree_1580  1
    arc_2_15_18  in_degree_1599  1
    arc_2_15_18  original_T_including_depot_unload_1624  7.9206888044020991e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_18  arc_capacity_1417  1
    load_2_15_18  free_load_conservation_1585  1
    load_2_15_18  free_load_conservation_1603  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_19  arc_capacity_1419  -30
    arc_2_15_19  connected_order_arc_1420  -12
    arc_2_15_19  out_degree_1580  1
    arc_2_15_19  in_degree_1605  1
    arc_2_15_19  original_T_including_depot_unload_1624  3.0055050459786975e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_19  arc_capacity_1419  1
    load_2_15_19  free_load_conservation_1585  1
    load_2_15_19  free_load_conservation_1609  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_20  arc_capacity_1421  -30
    arc_2_15_20  connected_order_arc_1422  -12
    arc_2_15_20  out_degree_1580  1
    arc_2_15_20  in_degree_1611  1
    arc_2_15_20  original_T_including_depot_unload_1624  6.4542450829473034e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_20  arc_capacity_1421  1
    load_2_15_20  free_load_conservation_1585  1
    load_2_15_20  free_load_conservation_1615  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_21  arc_capacity_1423  -30
    arc_2_15_21  connected_order_arc_1424  -12
    arc_2_15_21  out_degree_1580  1
    arc_2_15_21  in_degree_1617  1
    arc_2_15_21  original_T_including_depot_unload_1624  4.6276703023336785e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_21  arc_capacity_1423  1
    load_2_15_21  free_load_conservation_1585  1
    load_2_15_21  free_load_conservation_1621  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_0  arc_capacity_1425  -30
    arc_2_16_0  depot_return_or_bypass_1552  1
    arc_2_16_0  out_degree_1586  1
    arc_2_16_0  original_T_including_depot_unload_1624  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_0  arc_capacity_1425  1
    load_2_16_0  free_load_conservation_1591  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_11  arc_capacity_1426  -30
    arc_2_16_11  connected_order_arc_1427  -12
    arc_2_16_11  in_degree_1554  1
    arc_2_16_11  out_degree_1586  1
    arc_2_16_11  original_T_including_depot_unload_1624  1.2027697073878232e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_11  arc_capacity_1426  1
    load_2_16_11  segment_load_conservation_1557  -1
    load_2_16_11  segment_prefix_lb_1558  1
    load_2_16_11  segment_prefix_ub_1559  1
    load_2_16_11  free_load_conservation_1591  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_12  arc_capacity_1428  -30
    arc_2_16_12  connected_order_arc_1429  -12
    arc_2_16_12  in_degree_1561  1
    arc_2_16_12  out_degree_1586  1
    arc_2_16_12  original_T_including_depot_unload_1624  2.4496137598598170e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_12  arc_capacity_1428  1
    load_2_16_12  segment_load_conservation_1564  -1
    load_2_16_12  segment_prefix_lb_1565  1
    load_2_16_12  segment_prefix_ub_1566  1
    load_2_16_12  free_load_conservation_1591  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_13  arc_capacity_1430  -30
    arc_2_16_13  connected_order_arc_1431  -12
    arc_2_16_13  in_degree_1568  1
    arc_2_16_13  out_degree_1586  1
    arc_2_16_13  original_T_including_depot_unload_1624  2.4147485851762935e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_13  arc_capacity_1430  1
    load_2_16_13  segment_load_conservation_1571  -1
    load_2_16_13  segment_prefix_lb_1572  1
    load_2_16_13  segment_prefix_ub_1573  1
    load_2_16_13  free_load_conservation_1591  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_14  arc_capacity_1432  -30
    arc_2_16_14  connected_order_arc_1433  -12
    arc_2_16_14  in_degree_1575  1
    arc_2_16_14  out_degree_1586  1
    arc_2_16_14  original_T_including_depot_unload_1624  1.3727638439182763e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_14  arc_capacity_1432  1
    load_2_16_14  free_load_conservation_1579  -1
    load_2_16_14  free_load_conservation_1591  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_15  arc_capacity_1434  -30
    arc_2_16_15  connected_order_arc_1435  -12
    arc_2_16_15  in_degree_1581  1
    arc_2_16_15  out_degree_1586  1
    arc_2_16_15  original_T_including_depot_unload_1624  1.3163662834239574e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_15  arc_capacity_1434  1
    load_2_16_15  free_load_conservation_1585  -1
    load_2_16_15  free_load_conservation_1591  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_17  arc_capacity_1436  -30
    arc_2_16_17  connected_order_arc_1437  -12
    arc_2_16_17  out_degree_1586  1
    arc_2_16_17  in_degree_1593  1
    arc_2_16_17  original_T_including_depot_unload_1624  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_17  arc_capacity_1436  1
    load_2_16_17  free_load_conservation_1591  1
    load_2_16_17  free_load_conservation_1597  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_18  arc_capacity_1438  -30
    arc_2_16_18  connected_order_arc_1439  -12
    arc_2_16_18  out_degree_1586  1
    arc_2_16_18  in_degree_1599  1
    arc_2_16_18  original_T_including_depot_unload_1624  1.9462564869425171e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_18  arc_capacity_1438  1
    load_2_16_18  free_load_conservation_1591  1
    load_2_16_18  free_load_conservation_1603  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_19  arc_capacity_1440  -30
    arc_2_16_19  connected_order_arc_1441  -12
    arc_2_16_19  out_degree_1586  1
    arc_2_16_19  in_degree_1605  1
    arc_2_16_19  original_T_including_depot_unload_1624  1075.72043838369
    MARKER    'MARKER'                 'INTEND'
    load_2_16_19  arc_capacity_1440  1
    load_2_16_19  free_load_conservation_1591  1
    load_2_16_19  free_load_conservation_1609  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_20  arc_capacity_1442  -30
    arc_2_16_20  connected_order_arc_1443  -12
    arc_2_16_20  out_degree_1586  1
    arc_2_16_20  in_degree_1611  1
    arc_2_16_20  original_T_including_depot_unload_1624  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_20  arc_capacity_1442  1
    load_2_16_20  free_load_conservation_1591  1
    load_2_16_20  free_load_conservation_1615  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_21  arc_capacity_1444  -30
    arc_2_16_21  connected_order_arc_1445  -12
    arc_2_16_21  out_degree_1586  1
    arc_2_16_21  in_degree_1617  1
    arc_2_16_21  original_T_including_depot_unload_1624  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_21  arc_capacity_1444  1
    load_2_16_21  free_load_conservation_1591  1
    load_2_16_21  free_load_conservation_1621  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_0  arc_capacity_1446  -30
    arc_2_17_0  depot_return_or_bypass_1552  1
    arc_2_17_0  out_degree_1592  1
    arc_2_17_0  original_T_including_depot_unload_1624  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_0  arc_capacity_1446  1
    load_2_17_0  free_load_conservation_1597  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_11  arc_capacity_1447  -30
    arc_2_17_11  connected_order_arc_1448  -12
    arc_2_17_11  in_degree_1554  1
    arc_2_17_11  out_degree_1592  1
    arc_2_17_11  original_T_including_depot_unload_1624  1.4332871320059419e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_11  arc_capacity_1447  1
    load_2_17_11  segment_load_conservation_1557  -1
    load_2_17_11  segment_prefix_lb_1558  1
    load_2_17_11  segment_prefix_ub_1559  1
    load_2_17_11  free_load_conservation_1597  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_12  arc_capacity_1449  -30
    arc_2_17_12  connected_order_arc_1450  -12
    arc_2_17_12  in_degree_1561  1
    arc_2_17_12  out_degree_1592  1
    arc_2_17_12  original_T_including_depot_unload_1624  1.0592524244968324e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_12  arc_capacity_1449  1
    load_2_17_12  segment_load_conservation_1564  -1
    load_2_17_12  segment_prefix_lb_1565  1
    load_2_17_12  segment_prefix_ub_1566  1
    load_2_17_12  free_load_conservation_1597  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_13  arc_capacity_1451  -30
    arc_2_17_13  connected_order_arc_1452  -12
    arc_2_17_13  in_degree_1568  1
    arc_2_17_13  out_degree_1592  1
    arc_2_17_13  original_T_including_depot_unload_1624  1.0363003610648061e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_13  arc_capacity_1451  1
    load_2_17_13  segment_load_conservation_1571  -1
    load_2_17_13  segment_prefix_lb_1572  1
    load_2_17_13  segment_prefix_ub_1573  1
    load_2_17_13  free_load_conservation_1597  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_14  arc_capacity_1453  -30
    arc_2_17_14  connected_order_arc_1454  -12
    arc_2_17_14  in_degree_1575  1
    arc_2_17_14  out_degree_1592  1
    arc_2_17_14  original_T_including_depot_unload_1624  2.9098466309579254e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_14  arc_capacity_1453  1
    load_2_17_14  free_load_conservation_1579  -1
    load_2_17_14  free_load_conservation_1597  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_15  arc_capacity_1455  -30
    arc_2_17_15  connected_order_arc_1456  -12
    arc_2_17_15  in_degree_1581  1
    arc_2_17_15  out_degree_1592  1
    arc_2_17_15  original_T_including_depot_unload_1624  4.9831220386775891e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_15  arc_capacity_1455  1
    load_2_17_15  free_load_conservation_1585  -1
    load_2_17_15  free_load_conservation_1597  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_16  arc_capacity_1457  -30
    arc_2_17_16  connected_order_arc_1458  -12
    arc_2_17_16  in_degree_1587  1
    arc_2_17_16  out_degree_1592  1
    arc_2_17_16  original_T_including_depot_unload_1624  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_16  arc_capacity_1457  1
    load_2_17_16  free_load_conservation_1591  -1
    load_2_17_16  free_load_conservation_1597  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_18  arc_capacity_1459  -30
    arc_2_17_18  connected_order_arc_1460  -12
    arc_2_17_18  out_degree_1592  1
    arc_2_17_18  in_degree_1599  1
    arc_2_17_18  original_T_including_depot_unload_1624  5.5448403235604167e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_18  arc_capacity_1459  1
    load_2_17_18  free_load_conservation_1597  1
    load_2_17_18  free_load_conservation_1603  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_19  arc_capacity_1461  -30
    arc_2_17_19  connected_order_arc_1462  -12
    arc_2_17_19  out_degree_1592  1
    arc_2_17_19  in_degree_1605  1
    arc_2_17_19  original_T_including_depot_unload_1624  4.1665889045115779e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_19  arc_capacity_1461  1
    load_2_17_19  free_load_conservation_1597  1
    load_2_17_19  free_load_conservation_1609  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_20  arc_capacity_1463  -30
    arc_2_17_20  connected_order_arc_1464  -12
    arc_2_17_20  out_degree_1592  1
    arc_2_17_20  in_degree_1611  1
    arc_2_17_20  original_T_including_depot_unload_1624  1.6597164064313077e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_20  arc_capacity_1463  1
    load_2_17_20  free_load_conservation_1597  1
    load_2_17_20  free_load_conservation_1615  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_21  arc_capacity_1465  -30
    arc_2_17_21  connected_order_arc_1466  -12
    arc_2_17_21  out_degree_1592  1
    arc_2_17_21  in_degree_1617  1
    arc_2_17_21  original_T_including_depot_unload_1624  2.4083746437975364e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_21  arc_capacity_1465  1
    load_2_17_21  free_load_conservation_1597  1
    load_2_17_21  free_load_conservation_1621  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_0  arc_capacity_1467  -30
    arc_2_18_0  depot_return_or_bypass_1552  1
    arc_2_18_0  out_degree_1598  1
    arc_2_18_0  original_T_including_depot_unload_1624  9.5330620720858735e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_0  arc_capacity_1467  1
    load_2_18_0  free_load_conservation_1603  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_11  arc_capacity_1468  -30
    arc_2_18_11  connected_order_arc_1469  -12
    arc_2_18_11  in_degree_1554  1
    arc_2_18_11  out_degree_1598  1
    arc_2_18_11  original_T_including_depot_unload_1624  1.7571531345240103e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_11  arc_capacity_1468  1
    load_2_18_11  segment_load_conservation_1557  -1
    load_2_18_11  segment_prefix_lb_1558  1
    load_2_18_11  segment_prefix_ub_1559  1
    load_2_18_11  free_load_conservation_1603  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_12  arc_capacity_1470  -30
    arc_2_18_12  connected_order_arc_1471  -12
    arc_2_18_12  in_degree_1561  1
    arc_2_18_12  out_degree_1598  1
    arc_2_18_12  original_T_including_depot_unload_1624  5.0525672969651123e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_12  arc_capacity_1470  1
    load_2_18_12  segment_load_conservation_1564  -1
    load_2_18_12  segment_prefix_lb_1565  1
    load_2_18_12  segment_prefix_ub_1566  1
    load_2_18_12  free_load_conservation_1603  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_13  arc_capacity_1472  -30
    arc_2_18_13  connected_order_arc_1473  -12
    arc_2_18_13  in_degree_1568  1
    arc_2_18_13  out_degree_1598  1
    arc_2_18_13  original_T_including_depot_unload_1624  6.0985881995898160e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_13  arc_capacity_1472  1
    load_2_18_13  segment_load_conservation_1571  -1
    load_2_18_13  segment_prefix_lb_1572  1
    load_2_18_13  segment_prefix_ub_1573  1
    load_2_18_13  free_load_conservation_1603  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_14  arc_capacity_1474  -30
    arc_2_18_14  connected_order_arc_1475  -12
    arc_2_18_14  in_degree_1575  1
    arc_2_18_14  out_degree_1598  1
    arc_2_18_14  original_T_including_depot_unload_1624  6.2159179673866879e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_14  arc_capacity_1474  1
    load_2_18_14  free_load_conservation_1579  -1
    load_2_18_14  free_load_conservation_1603  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_15  arc_capacity_1476  -30
    arc_2_18_15  connected_order_arc_1477  -12
    arc_2_18_15  in_degree_1581  1
    arc_2_18_15  out_degree_1598  1
    arc_2_18_15  original_T_including_depot_unload_1624  7.9206888044020991e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_15  arc_capacity_1476  1
    load_2_18_15  free_load_conservation_1585  -1
    load_2_18_15  free_load_conservation_1603  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_16  arc_capacity_1478  -30
    arc_2_18_16  connected_order_arc_1479  -12
    arc_2_18_16  in_degree_1587  1
    arc_2_18_16  out_degree_1598  1
    arc_2_18_16  original_T_including_depot_unload_1624  1.9462564869425171e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_16  arc_capacity_1478  1
    load_2_18_16  free_load_conservation_1591  -1
    load_2_18_16  free_load_conservation_1603  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_17  arc_capacity_1480  -30
    arc_2_18_17  connected_order_arc_1481  -12
    arc_2_18_17  in_degree_1593  1
    arc_2_18_17  out_degree_1598  1
    arc_2_18_17  original_T_including_depot_unload_1624  5.5448403235604167e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_17  arc_capacity_1480  1
    load_2_18_17  free_load_conservation_1597  -1
    load_2_18_17  free_load_conservation_1603  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_19  arc_capacity_1482  -30
    arc_2_18_19  connected_order_arc_1483  -12
    arc_2_18_19  out_degree_1598  1
    arc_2_18_19  in_degree_1605  1
    arc_2_18_19  original_T_including_depot_unload_1624  897.031483121361
    MARKER    'MARKER'                 'INTEND'
    load_2_18_19  arc_capacity_1482  1
    load_2_18_19  free_load_conservation_1603  1
    load_2_18_19  free_load_conservation_1609  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_20  arc_capacity_1484  -30
    arc_2_18_20  connected_order_arc_1485  -12
    arc_2_18_20  out_degree_1598  1
    arc_2_18_20  in_degree_1611  1
    arc_2_18_20  original_T_including_depot_unload_1624  4.6772747357218117e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_20  arc_capacity_1484  1
    load_2_18_20  free_load_conservation_1603  1
    load_2_18_20  free_load_conservation_1615  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_21  arc_capacity_1486  -30
    arc_2_18_21  connected_order_arc_1487  -12
    arc_2_18_21  out_degree_1598  1
    arc_2_18_21  in_degree_1617  1
    arc_2_18_21  original_T_including_depot_unload_1624  7.8947565022471792e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_21  arc_capacity_1486  1
    load_2_18_21  free_load_conservation_1603  1
    load_2_18_21  free_load_conservation_1621  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_0  arc_capacity_1488  -30
    arc_2_19_0  depot_return_or_bypass_1552  1
    arc_2_19_0  out_degree_1604  1
    arc_2_19_0  original_T_including_depot_unload_1624  4.6364706268001146e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_0  arc_capacity_1488  1
    load_2_19_0  free_load_conservation_1609  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_11  arc_capacity_1489  -30
    arc_2_19_11  connected_order_arc_1490  -12
    arc_2_19_11  in_degree_1554  1
    arc_2_19_11  out_degree_1604  1
    arc_2_19_11  original_T_including_depot_unload_1624  1.0428195034234207e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_11  arc_capacity_1489  1
    load_2_19_11  segment_load_conservation_1557  -1
    load_2_19_11  segment_prefix_lb_1558  1
    load_2_19_11  segment_prefix_ub_1559  1
    load_2_19_11  free_load_conservation_1609  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_12  arc_capacity_1491  -30
    arc_2_19_12  connected_order_arc_1492  -12
    arc_2_19_12  in_degree_1561  1
    arc_2_19_12  out_degree_1604  1
    arc_2_19_12  original_T_including_depot_unload_1624  1.3898988531263665e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_12  arc_capacity_1491  1
    load_2_19_12  segment_load_conservation_1564  -1
    load_2_19_12  segment_prefix_lb_1565  1
    load_2_19_12  segment_prefix_ub_1566  1
    load_2_19_12  free_load_conservation_1609  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_13  arc_capacity_1493  -30
    arc_2_19_13  connected_order_arc_1494  -12
    arc_2_19_13  in_degree_1568  1
    arc_2_19_13  out_degree_1604  1
    arc_2_19_13  original_T_including_depot_unload_1624  1.4399299780980639e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_13  arc_capacity_1493  1
    load_2_19_13  segment_load_conservation_1571  -1
    load_2_19_13  segment_prefix_lb_1572  1
    load_2_19_13  segment_prefix_ub_1573  1
    load_2_19_13  free_load_conservation_1609  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_14  arc_capacity_1495  -30
    arc_2_19_14  connected_order_arc_1496  -12
    arc_2_19_14  in_degree_1575  1
    arc_2_19_14  out_degree_1604  1
    arc_2_19_14  original_T_including_depot_unload_1624  2.9706418113632907e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_14  arc_capacity_1495  1
    load_2_19_14  free_load_conservation_1579  -1
    load_2_19_14  free_load_conservation_1609  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_15  arc_capacity_1497  -30
    arc_2_19_15  connected_order_arc_1498  -12
    arc_2_19_15  in_degree_1581  1
    arc_2_19_15  out_degree_1604  1
    arc_2_19_15  original_T_including_depot_unload_1624  3.0055050459786975e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_15  arc_capacity_1497  1
    load_2_19_15  free_load_conservation_1585  -1
    load_2_19_15  free_load_conservation_1609  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_16  arc_capacity_1499  -30
    arc_2_19_16  connected_order_arc_1500  -12
    arc_2_19_16  in_degree_1587  1
    arc_2_19_16  out_degree_1604  1
    arc_2_19_16  original_T_including_depot_unload_1624  1075.72043838369
    MARKER    'MARKER'                 'INTEND'
    load_2_19_16  arc_capacity_1499  1
    load_2_19_16  free_load_conservation_1591  -1
    load_2_19_16  free_load_conservation_1609  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_17  arc_capacity_1501  -30
    arc_2_19_17  connected_order_arc_1502  -12
    arc_2_19_17  in_degree_1593  1
    arc_2_19_17  out_degree_1604  1
    arc_2_19_17  original_T_including_depot_unload_1624  4.1665889045115779e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_17  arc_capacity_1501  1
    load_2_19_17  free_load_conservation_1597  -1
    load_2_19_17  free_load_conservation_1609  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_18  arc_capacity_1503  -30
    arc_2_19_18  connected_order_arc_1504  -12
    arc_2_19_18  in_degree_1599  1
    arc_2_19_18  out_degree_1604  1
    arc_2_19_18  original_T_including_depot_unload_1624  897.031483121361
    MARKER    'MARKER'                 'INTEND'
    load_2_19_18  arc_capacity_1503  1
    load_2_19_18  free_load_conservation_1603  -1
    load_2_19_18  free_load_conservation_1609  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_20  arc_capacity_1505  -30
    arc_2_19_20  connected_order_arc_1506  -12
    arc_2_19_20  out_degree_1604  1
    arc_2_19_20  in_degree_1611  1
    arc_2_19_20  original_T_including_depot_unload_1624  5.8212369880329140e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_20  arc_capacity_1505  1
    load_2_19_20  free_load_conservation_1609  1
    load_2_19_20  free_load_conservation_1615  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_21  arc_capacity_1507  -30
    arc_2_19_21  connected_order_arc_1508  -12
    arc_2_19_21  out_degree_1604  1
    arc_2_19_21  in_degree_1617  1
    arc_2_19_21  original_T_including_depot_unload_1624  2.4191291221621205e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_21  arc_capacity_1507  1
    load_2_19_21  free_load_conservation_1609  1
    load_2_19_21  free_load_conservation_1621  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_0  arc_capacity_1509  -30
    arc_2_20_0  depot_return_or_bypass_1552  1
    arc_2_20_0  out_degree_1610  1
    arc_2_20_0  original_T_including_depot_unload_1624  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_0  arc_capacity_1509  1
    load_2_20_0  free_load_conservation_1615  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_11  arc_capacity_1510  -30
    arc_2_20_11  connected_order_arc_1511  -12
    arc_2_20_11  in_degree_1554  1
    arc_2_20_11  out_degree_1610  1
    arc_2_20_11  original_T_including_depot_unload_1624  1.5960107821452696e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_11  arc_capacity_1510  1
    load_2_20_11  segment_load_conservation_1557  -1
    load_2_20_11  segment_prefix_lb_1558  1
    load_2_20_11  segment_prefix_ub_1559  1
    load_2_20_11  free_load_conservation_1615  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_12  arc_capacity_1512  -30
    arc_2_20_12  connected_order_arc_1513  -12
    arc_2_20_12  in_degree_1561  1
    arc_2_20_12  out_degree_1610  1
    arc_2_20_12  original_T_including_depot_unload_1624  9.5901863634429412e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_12  arc_capacity_1512  1
    load_2_20_12  segment_load_conservation_1564  -1
    load_2_20_12  segment_prefix_lb_1565  1
    load_2_20_12  segment_prefix_ub_1566  1
    load_2_20_12  free_load_conservation_1615  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_13  arc_capacity_1514  -30
    arc_2_20_13  connected_order_arc_1515  -12
    arc_2_20_13  in_degree_1568  1
    arc_2_20_13  out_degree_1610  1
    arc_2_20_13  original_T_including_depot_unload_1624  8.8496780902404032e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_13  arc_capacity_1514  1
    load_2_20_13  segment_load_conservation_1571  -1
    load_2_20_13  segment_prefix_lb_1572  1
    load_2_20_13  segment_prefix_ub_1573  1
    load_2_20_13  free_load_conservation_1615  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_14  arc_capacity_1516  -30
    arc_2_20_14  connected_order_arc_1517  -12
    arc_2_20_14  in_degree_1575  1
    arc_2_20_14  out_degree_1610  1
    arc_2_20_14  original_T_including_depot_unload_1624  4.3129452098285111e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_14  arc_capacity_1516  1
    load_2_20_14  free_load_conservation_1579  -1
    load_2_20_14  free_load_conservation_1615  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_15  arc_capacity_1518  -30
    arc_2_20_15  connected_order_arc_1519  -12
    arc_2_20_15  in_degree_1581  1
    arc_2_20_15  out_degree_1610  1
    arc_2_20_15  original_T_including_depot_unload_1624  6.4542450829473034e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_15  arc_capacity_1518  1
    load_2_20_15  free_load_conservation_1585  -1
    load_2_20_15  free_load_conservation_1615  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_16  arc_capacity_1520  -30
    arc_2_20_16  connected_order_arc_1521  -12
    arc_2_20_16  in_degree_1587  1
    arc_2_20_16  out_degree_1610  1
    arc_2_20_16  original_T_including_depot_unload_1624  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_16  arc_capacity_1520  1
    load_2_20_16  free_load_conservation_1591  -1
    load_2_20_16  free_load_conservation_1615  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_17  arc_capacity_1522  -30
    arc_2_20_17  connected_order_arc_1523  -12
    arc_2_20_17  in_degree_1593  1
    arc_2_20_17  out_degree_1610  1
    arc_2_20_17  original_T_including_depot_unload_1624  1.6597164064313077e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_17  arc_capacity_1522  1
    load_2_20_17  free_load_conservation_1597  -1
    load_2_20_17  free_load_conservation_1615  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_18  arc_capacity_1524  -30
    arc_2_20_18  connected_order_arc_1525  -12
    arc_2_20_18  in_degree_1599  1
    arc_2_20_18  out_degree_1610  1
    arc_2_20_18  original_T_including_depot_unload_1624  4.6772747357218117e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_18  arc_capacity_1524  1
    load_2_20_18  free_load_conservation_1603  -1
    load_2_20_18  free_load_conservation_1615  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_19  arc_capacity_1526  -30
    arc_2_20_19  connected_order_arc_1527  -12
    arc_2_20_19  in_degree_1605  1
    arc_2_20_19  out_degree_1610  1
    arc_2_20_19  original_T_including_depot_unload_1624  5.8212369880329140e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_19  arc_capacity_1526  1
    load_2_20_19  free_load_conservation_1609  -1
    load_2_20_19  free_load_conservation_1615  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_21  arc_capacity_1528  -30
    arc_2_20_21  connected_order_arc_1529  -12
    arc_2_20_21  out_degree_1610  1
    arc_2_20_21  in_degree_1617  1
    arc_2_20_21  original_T_including_depot_unload_1624  3.8790073962518773e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_21  arc_capacity_1528  1
    load_2_20_21  free_load_conservation_1615  1
    load_2_20_21  free_load_conservation_1621  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_0  arc_capacity_1530  -30
    arc_2_21_0  depot_return_or_bypass_1552  1
    arc_2_21_0  out_degree_1616  1
    arc_2_21_0  original_T_including_depot_unload_1624  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_0  arc_capacity_1530  1
    load_2_21_0  free_load_conservation_1621  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_11  arc_capacity_1531  -30
    arc_2_21_11  connected_order_arc_1532  -12
    arc_2_21_11  in_degree_1554  1
    arc_2_21_11  out_degree_1616  1
    arc_2_21_11  original_T_including_depot_unload_1624  1.2835993572680911e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_11  arc_capacity_1531  1
    load_2_21_11  segment_load_conservation_1557  -1
    load_2_21_11  segment_prefix_lb_1558  1
    load_2_21_11  segment_prefix_ub_1559  1
    load_2_21_11  free_load_conservation_1621  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_12  arc_capacity_1533  -30
    arc_2_21_12  connected_order_arc_1534  -12
    arc_2_21_12  in_degree_1561  1
    arc_2_21_12  out_degree_1616  1
    arc_2_21_12  original_T_including_depot_unload_1624  1.2946770575314561e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_12  arc_capacity_1533  1
    load_2_21_12  segment_load_conservation_1564  -1
    load_2_21_12  segment_prefix_lb_1565  1
    load_2_21_12  segment_prefix_ub_1566  1
    load_2_21_12  free_load_conservation_1621  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_13  arc_capacity_1535  -30
    arc_2_21_13  connected_order_arc_1536  -12
    arc_2_21_13  in_degree_1568  1
    arc_2_21_13  out_degree_1616  1
    arc_2_21_13  original_T_including_depot_unload_1624  1.2717918724165304e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_13  arc_capacity_1535  1
    load_2_21_13  segment_load_conservation_1571  -1
    load_2_21_13  segment_prefix_lb_1572  1
    load_2_21_13  segment_prefix_ub_1573  1
    load_2_21_13  free_load_conservation_1621  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_14  arc_capacity_1537  -30
    arc_2_21_14  connected_order_arc_1538  -12
    arc_2_21_14  in_degree_1575  1
    arc_2_21_14  out_degree_1616  1
    arc_2_21_14  original_T_including_depot_unload_1624  3.2938591738444967e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_14  arc_capacity_1537  1
    load_2_21_14  free_load_conservation_1579  -1
    load_2_21_14  free_load_conservation_1621  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_15  arc_capacity_1539  -30
    arc_2_21_15  connected_order_arc_1540  -12
    arc_2_21_15  in_degree_1581  1
    arc_2_21_15  out_degree_1616  1
    arc_2_21_15  original_T_including_depot_unload_1624  4.6276703023336785e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_15  arc_capacity_1539  1
    load_2_21_15  free_load_conservation_1585  -1
    load_2_21_15  free_load_conservation_1621  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_16  arc_capacity_1541  -30
    arc_2_21_16  connected_order_arc_1542  -12
    arc_2_21_16  in_degree_1587  1
    arc_2_21_16  out_degree_1616  1
    arc_2_21_16  original_T_including_depot_unload_1624  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_16  arc_capacity_1541  1
    load_2_21_16  free_load_conservation_1591  -1
    load_2_21_16  free_load_conservation_1621  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_17  arc_capacity_1543  -30
    arc_2_21_17  connected_order_arc_1544  -12
    arc_2_21_17  in_degree_1593  1
    arc_2_21_17  out_degree_1616  1
    arc_2_21_17  original_T_including_depot_unload_1624  2.4083746437975364e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_17  arc_capacity_1543  1
    load_2_21_17  free_load_conservation_1597  -1
    load_2_21_17  free_load_conservation_1621  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_18  arc_capacity_1545  -30
    arc_2_21_18  connected_order_arc_1546  -12
    arc_2_21_18  in_degree_1599  1
    arc_2_21_18  out_degree_1616  1
    arc_2_21_18  original_T_including_depot_unload_1624  7.8947565022471792e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_18  arc_capacity_1545  1
    load_2_21_18  free_load_conservation_1603  -1
    load_2_21_18  free_load_conservation_1621  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_19  arc_capacity_1547  -30
    arc_2_21_19  connected_order_arc_1548  -12
    arc_2_21_19  in_degree_1605  1
    arc_2_21_19  out_degree_1616  1
    arc_2_21_19  original_T_including_depot_unload_1624  2.4191291221621205e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_19  arc_capacity_1547  1
    load_2_21_19  free_load_conservation_1609  -1
    load_2_21_19  free_load_conservation_1621  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_20  arc_capacity_1549  -30
    arc_2_21_20  connected_order_arc_1550  -12
    arc_2_21_20  in_degree_1611  1
    arc_2_21_20  out_degree_1616  1
    arc_2_21_20  original_T_including_depot_unload_1624  3.8790073962518773e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_20  arc_capacity_1549  1
    load_2_21_20  free_load_conservation_1615  -1
    load_2_21_20  free_load_conservation_1621  1
RHS
    RHS1      OBJ       -5.9925000000000006e-01
    RHS1      onehot_13_40  1
    RHS1      onehot_17_77  1
    RHS1      onehot_31_106  1
    RHS1      onehot_6_131  1
    RHS1      onehot_14_166  1
    RHS1      onehot_15_203  1
    RHS1      onehot_2_238  1
    RHS1      onehot_9_267  1
    RHS1      stock_ub_271  46
    RHS1      parent_nonstrict_scope_272  2.9707784389027569e-01
    RHS1      normalization_329  1
    RHS1      connected_order_arc_463  -14
    RHS1      connected_order_arc_465  -14
    RHS1      connected_order_arc_467  -14
    RHS1      connected_order_arc_469  -14
    RHS1      connected_order_arc_471  -14
    RHS1      connected_order_arc_473  -14
    RHS1      connected_order_arc_475  -14
    RHS1      connected_order_arc_477  -14
    RHS1      connected_order_arc_479  -14
    RHS1      connected_order_arc_481  -14
    RHS1      connected_order_arc_483  -14
    RHS1      connected_order_arc_485  -14
    RHS1      connected_order_arc_487  -14
    RHS1      connected_order_arc_490  -14
    RHS1      connected_order_arc_492  -14
    RHS1      connected_order_arc_494  -14
    RHS1      connected_order_arc_496  -14
    RHS1      connected_order_arc_498  -14
    RHS1      connected_order_arc_500  -14
    RHS1      connected_order_arc_502  -14
    RHS1      connected_order_arc_504  -14
    RHS1      connected_order_arc_506  -14
    RHS1      connected_order_arc_508  -14
    RHS1      connected_order_arc_510  -14
    RHS1      connected_order_arc_512  -14
    RHS1      connected_order_arc_514  -14
    RHS1      connected_order_arc_517  -14
    RHS1      connected_order_arc_519  -14
    RHS1      connected_order_arc_521  -14
    RHS1      connected_order_arc_523  -14
    RHS1      connected_order_arc_525  -14
    RHS1      connected_order_arc_527  -14
    RHS1      connected_order_arc_529  -14
    RHS1      connected_order_arc_531  -14
    RHS1      connected_order_arc_533  -14
    RHS1      connected_order_arc_535  -14
    RHS1      connected_order_arc_537  -14
    RHS1      connected_order_arc_539  -14
    RHS1      connected_order_arc_541  -14
    RHS1      connected_order_arc_544  -14
    RHS1      connected_order_arc_546  -14
    RHS1      connected_order_arc_548  -14
    RHS1      connected_order_arc_550  -14
    RHS1      connected_order_arc_552  -14
    RHS1      connected_order_arc_554  -14
    RHS1      connected_order_arc_556  -14
    RHS1      connected_order_arc_558  -14
    RHS1      connected_order_arc_560  -14
    RHS1      connected_order_arc_562  -14
    RHS1      connected_order_arc_564  -14
    RHS1      connected_order_arc_566  -14
    RHS1      connected_order_arc_568  -14
    RHS1      connected_order_arc_571  -14
    RHS1      connected_order_arc_573  -14
    RHS1      connected_order_arc_575  -14
    RHS1      connected_order_arc_577  -14
    RHS1      connected_order_arc_579  -14
    RHS1      connected_order_arc_581  -14
    RHS1      connected_order_arc_583  -14
    RHS1      connected_order_arc_585  -14
    RHS1      connected_order_arc_587  -14
    RHS1      connected_order_arc_589  -14
    RHS1      connected_order_arc_591  -14
    RHS1      connected_order_arc_593  -14
    RHS1      connected_order_arc_595  -14
    RHS1      connected_order_arc_598  -14
    RHS1      connected_order_arc_600  -14
    RHS1      connected_order_arc_602  -14
    RHS1      connected_order_arc_604  -14
    RHS1      connected_order_arc_606  -14
    RHS1      connected_order_arc_608  -14
    RHS1      connected_order_arc_610  -14
    RHS1      connected_order_arc_612  -14
    RHS1      connected_order_arc_614  -14
    RHS1      connected_order_arc_616  -14
    RHS1      connected_order_arc_618  -14
    RHS1      connected_order_arc_620  -14
    RHS1      connected_order_arc_622  -14
    RHS1      connected_order_arc_625  -14
    RHS1      connected_order_arc_627  -14
    RHS1      connected_order_arc_629  -14
    RHS1      connected_order_arc_631  -14
    RHS1      connected_order_arc_633  -14
    RHS1      connected_order_arc_635  -14
    RHS1      connected_order_arc_637  -14
    RHS1      connected_order_arc_639  -14
    RHS1      connected_order_arc_641  -14
    RHS1      connected_order_arc_643  -14
    RHS1      connected_order_arc_645  -14
    RHS1      connected_order_arc_647  -14
    RHS1      connected_order_arc_649  -14
    RHS1      connected_order_arc_652  -14
    RHS1      connected_order_arc_654  -14
    RHS1      connected_order_arc_656  -14
    RHS1      connected_order_arc_658  -14
    RHS1      connected_order_arc_660  -14
    RHS1      connected_order_arc_662  -14
    RHS1      connected_order_arc_664  -14
    RHS1      connected_order_arc_666  -14
    RHS1      connected_order_arc_668  -14
    RHS1      connected_order_arc_670  -14
    RHS1      connected_order_arc_672  -14
    RHS1      connected_order_arc_674  -14
    RHS1      connected_order_arc_676  -14
    RHS1      connected_order_arc_679  -14
    RHS1      connected_order_arc_681  -14
    RHS1      connected_order_arc_683  -14
    RHS1      connected_order_arc_685  -14
    RHS1      connected_order_arc_687  -14
    RHS1      connected_order_arc_689  -14
    RHS1      connected_order_arc_691  -14
    RHS1      connected_order_arc_693  -14
    RHS1      connected_order_arc_695  -14
    RHS1      connected_order_arc_697  -14
    RHS1      connected_order_arc_699  -14
    RHS1      connected_order_arc_701  -14
    RHS1      connected_order_arc_703  -14
    RHS1      connected_order_arc_706  -14
    RHS1      connected_order_arc_708  -14
    RHS1      connected_order_arc_710  -14
    RHS1      connected_order_arc_712  -14
    RHS1      connected_order_arc_714  -14
    RHS1      connected_order_arc_716  -14
    RHS1      connected_order_arc_718  -14
    RHS1      connected_order_arc_720  -14
    RHS1      connected_order_arc_722  -14
    RHS1      connected_order_arc_724  -14
    RHS1      connected_order_arc_726  -14
    RHS1      connected_order_arc_728  -14
    RHS1      connected_order_arc_730  -14
    RHS1      connected_order_arc_733  -14
    RHS1      connected_order_arc_735  -14
    RHS1      connected_order_arc_737  -14
    RHS1      connected_order_arc_739  -14
    RHS1      connected_order_arc_741  -14
    RHS1      connected_order_arc_743  -14
    RHS1      connected_order_arc_745  -14
    RHS1      connected_order_arc_747  -14
    RHS1      connected_order_arc_749  -14
    RHS1      connected_order_arc_751  -14
    RHS1      connected_order_arc_753  -14
    RHS1      connected_order_arc_755  -14
    RHS1      connected_order_arc_757  -14
    RHS1      connected_order_arc_760  -14
    RHS1      connected_order_arc_762  -14
    RHS1      connected_order_arc_764  -14
    RHS1      connected_order_arc_766  -14
    RHS1      connected_order_arc_768  -14
    RHS1      connected_order_arc_770  -14
    RHS1      connected_order_arc_772  -14
    RHS1      connected_order_arc_774  -14
    RHS1      connected_order_arc_776  -14
    RHS1      connected_order_arc_778  -14
    RHS1      connected_order_arc_780  -14
    RHS1      connected_order_arc_782  -14
    RHS1      connected_order_arc_784  -14
    RHS1      connected_order_arc_787  -14
    RHS1      connected_order_arc_789  -14
    RHS1      connected_order_arc_791  -14
    RHS1      connected_order_arc_793  -14
    RHS1      connected_order_arc_795  -14
    RHS1      connected_order_arc_797  -14
    RHS1      connected_order_arc_799  -14
    RHS1      connected_order_arc_801  -14
    RHS1      connected_order_arc_803  -14
    RHS1      connected_order_arc_805  -14
    RHS1      connected_order_arc_807  -14
    RHS1      connected_order_arc_809  -14
    RHS1      connected_order_arc_811  -14
    RHS1      connected_order_arc_814  -14
    RHS1      connected_order_arc_816  -14
    RHS1      connected_order_arc_818  -14
    RHS1      connected_order_arc_820  -14
    RHS1      connected_order_arc_822  -14
    RHS1      connected_order_arc_824  -14
    RHS1      connected_order_arc_826  -14
    RHS1      connected_order_arc_828  -14
    RHS1      connected_order_arc_830  -14
    RHS1      connected_order_arc_832  -14
    RHS1      connected_order_arc_834  -14
    RHS1      connected_order_arc_836  -14
    RHS1      connected_order_arc_838  -14
    RHS1      depot_departure_or_bypass_839  1
    RHS1      depot_return_or_bypass_840  1
    RHS1      segment_load_conservation_845  5
    RHS1      segment_prefix_ub_847  15
    RHS1      segment_load_conservation_852  13
    RHS1      segment_prefix_ub_854  7
    RHS1      segment_load_conservation_859  -8
    RHS1      segment_prefix_lb_860  8
    RHS1      segment_prefix_ub_861  20
    RHS1      segment_load_conservation_866  -4
    RHS1      segment_prefix_lb_867  4
    RHS1      segment_prefix_ub_868  20
    RHS1      segment_load_conservation_873  5
    RHS1      segment_prefix_ub_875  15
    RHS1      segment_load_conservation_880  -2
    RHS1      segment_prefix_lb_881  2
    RHS1      segment_prefix_ub_882  20
    RHS1      fixed_segment_relative_order_931  1
    RHS1      fixed_segment_relative_order_932  1
    RHS1      fixed_segment_relative_order_933  1
    RHS1      fixed_segment_relative_order_934  1
    RHS1      fixed_segment_relative_order_935  1
    RHS1      original_T_including_depot_unload_936  3.9811043022375270e+03
    RHS1      connected_order_arc_952  -12
    RHS1      connected_order_arc_954  -12
    RHS1      connected_order_arc_956  -12
    RHS1      connected_order_arc_958  -12
    RHS1      connected_order_arc_960  -12
    RHS1      connected_order_arc_962  -12
    RHS1      connected_order_arc_964  -12
    RHS1      connected_order_arc_966  -12
    RHS1      connected_order_arc_968  -12
    RHS1      connected_order_arc_970  -12
    RHS1      connected_order_arc_972  -12
    RHS1      connected_order_arc_975  -12
    RHS1      connected_order_arc_977  -12
    RHS1      connected_order_arc_979  -12
    RHS1      connected_order_arc_981  -12
    RHS1      connected_order_arc_983  -12
    RHS1      connected_order_arc_985  -12
    RHS1      connected_order_arc_987  -12
    RHS1      connected_order_arc_989  -12
    RHS1      connected_order_arc_991  -12
    RHS1      connected_order_arc_993  -12
    RHS1      connected_order_arc_995  -12
    RHS1      connected_order_arc_998  -12
    RHS1      connected_order_arc_1000  -12
    RHS1      connected_order_arc_1002  -12
    RHS1      connected_order_arc_1004  -12
    RHS1      connected_order_arc_1006  -12
    RHS1      connected_order_arc_1008  -12
    RHS1      connected_order_arc_1010  -12
    RHS1      connected_order_arc_1012  -12
    RHS1      connected_order_arc_1014  -12
    RHS1      connected_order_arc_1016  -12
    RHS1      connected_order_arc_1018  -12
    RHS1      connected_order_arc_1021  -12
    RHS1      connected_order_arc_1023  -12
    RHS1      connected_order_arc_1025  -12
    RHS1      connected_order_arc_1027  -12
    RHS1      connected_order_arc_1029  -12
    RHS1      connected_order_arc_1031  -12
    RHS1      connected_order_arc_1033  -12
    RHS1      connected_order_arc_1035  -12
    RHS1      connected_order_arc_1037  -12
    RHS1      connected_order_arc_1039  -12
    RHS1      connected_order_arc_1041  -12
    RHS1      connected_order_arc_1044  -12
    RHS1      connected_order_arc_1046  -12
    RHS1      connected_order_arc_1048  -12
    RHS1      connected_order_arc_1050  -12
    RHS1      connected_order_arc_1052  -12
    RHS1      connected_order_arc_1054  -12
    RHS1      connected_order_arc_1056  -12
    RHS1      connected_order_arc_1058  -12
    RHS1      connected_order_arc_1060  -12
    RHS1      connected_order_arc_1062  -12
    RHS1      connected_order_arc_1064  -12
    RHS1      connected_order_arc_1067  -12
    RHS1      connected_order_arc_1069  -12
    RHS1      connected_order_arc_1071  -12
    RHS1      connected_order_arc_1073  -12
    RHS1      connected_order_arc_1075  -12
    RHS1      connected_order_arc_1077  -12
    RHS1      connected_order_arc_1079  -12
    RHS1      connected_order_arc_1081  -12
    RHS1      connected_order_arc_1083  -12
    RHS1      connected_order_arc_1085  -12
    RHS1      connected_order_arc_1087  -12
    RHS1      connected_order_arc_1090  -12
    RHS1      connected_order_arc_1092  -12
    RHS1      connected_order_arc_1094  -12
    RHS1      connected_order_arc_1096  -12
    RHS1      connected_order_arc_1098  -12
    RHS1      connected_order_arc_1100  -12
    RHS1      connected_order_arc_1102  -12
    RHS1      connected_order_arc_1104  -12
    RHS1      connected_order_arc_1106  -12
    RHS1      connected_order_arc_1108  -12
    RHS1      connected_order_arc_1110  -12
    RHS1      connected_order_arc_1113  -12
    RHS1      connected_order_arc_1115  -12
    RHS1      connected_order_arc_1117  -12
    RHS1      connected_order_arc_1119  -12
    RHS1      connected_order_arc_1121  -12
    RHS1      connected_order_arc_1123  -12
    RHS1      connected_order_arc_1125  -12
    RHS1      connected_order_arc_1127  -12
    RHS1      connected_order_arc_1129  -12
    RHS1      connected_order_arc_1131  -12
    RHS1      connected_order_arc_1133  -12
    RHS1      connected_order_arc_1136  -12
    RHS1      connected_order_arc_1138  -12
    RHS1      connected_order_arc_1140  -12
    RHS1      connected_order_arc_1142  -12
    RHS1      connected_order_arc_1144  -12
    RHS1      connected_order_arc_1146  -12
    RHS1      connected_order_arc_1148  -12
    RHS1      connected_order_arc_1150  -12
    RHS1      connected_order_arc_1152  -12
    RHS1      connected_order_arc_1154  -12
    RHS1      connected_order_arc_1156  -12
    RHS1      connected_order_arc_1159  -12
    RHS1      connected_order_arc_1161  -12
    RHS1      connected_order_arc_1163  -12
    RHS1      connected_order_arc_1165  -12
    RHS1      connected_order_arc_1167  -12
    RHS1      connected_order_arc_1169  -12
    RHS1      connected_order_arc_1171  -12
    RHS1      connected_order_arc_1173  -12
    RHS1      connected_order_arc_1175  -12
    RHS1      connected_order_arc_1177  -12
    RHS1      connected_order_arc_1179  -12
    RHS1      connected_order_arc_1182  -12
    RHS1      connected_order_arc_1184  -12
    RHS1      connected_order_arc_1186  -12
    RHS1      connected_order_arc_1188  -12
    RHS1      connected_order_arc_1190  -12
    RHS1      connected_order_arc_1192  -12
    RHS1      connected_order_arc_1194  -12
    RHS1      connected_order_arc_1196  -12
    RHS1      connected_order_arc_1198  -12
    RHS1      connected_order_arc_1200  -12
    RHS1      connected_order_arc_1202  -12
    RHS1      connected_order_arc_1205  -12
    RHS1      connected_order_arc_1207  -12
    RHS1      connected_order_arc_1209  -12
    RHS1      connected_order_arc_1211  -12
    RHS1      connected_order_arc_1213  -12
    RHS1      connected_order_arc_1215  -12
    RHS1      connected_order_arc_1217  -12
    RHS1      connected_order_arc_1219  -12
    RHS1      connected_order_arc_1221  -12
    RHS1      connected_order_arc_1223  -12
    RHS1      connected_order_arc_1225  -12
    RHS1      depot_departure_or_bypass_1226  1
    RHS1      depot_return_or_bypass_1227  1
    RHS1      segment_load_conservation_1232  6
    RHS1      segment_prefix_ub_1234  19
    RHS1      segment_load_conservation_1239  -4
    RHS1      segment_prefix_lb_1240  4
    RHS1      segment_prefix_ub_1241  25
    RHS1      segment_load_conservation_1246  3
    RHS1      segment_prefix_lb_1247  2
    RHS1      segment_prefix_ub_1248  21
    RHS1      segment_load_conservation_1253  -5
    RHS1      segment_prefix_lb_1254  5
    RHS1      segment_prefix_ub_1255  25
    RHS1      fixed_segment_relative_order_1304  1
    RHS1      fixed_segment_relative_order_1305  1
    RHS1      fixed_segment_relative_order_1306  1
    RHS1      original_T_including_depot_unload_1307  2.2731043790930526e+03
    RHS1      connected_order_arc_1322  -11
    RHS1      connected_order_arc_1324  -11
    RHS1      connected_order_arc_1326  -11
    RHS1      connected_order_arc_1328  -11
    RHS1      connected_order_arc_1330  -11
    RHS1      connected_order_arc_1332  -11
    RHS1      connected_order_arc_1334  -11
    RHS1      connected_order_arc_1336  -11
    RHS1      connected_order_arc_1338  -11
    RHS1      connected_order_arc_1340  -11
    RHS1      connected_order_arc_1343  -11
    RHS1      connected_order_arc_1345  -11
    RHS1      connected_order_arc_1347  -11
    RHS1      connected_order_arc_1349  -11
    RHS1      connected_order_arc_1351  -11
    RHS1      connected_order_arc_1353  -11
    RHS1      connected_order_arc_1355  -11
    RHS1      connected_order_arc_1357  -11
    RHS1      connected_order_arc_1359  -11
    RHS1      connected_order_arc_1361  -11
    RHS1      connected_order_arc_1364  -11
    RHS1      connected_order_arc_1366  -11
    RHS1      connected_order_arc_1368  -11
    RHS1      connected_order_arc_1370  -11
    RHS1      connected_order_arc_1372  -11
    RHS1      connected_order_arc_1374  -11
    RHS1      connected_order_arc_1376  -11
    RHS1      connected_order_arc_1378  -11
    RHS1      connected_order_arc_1380  -11
    RHS1      connected_order_arc_1382  -11
    RHS1      connected_order_arc_1385  -11
    RHS1      connected_order_arc_1387  -11
    RHS1      connected_order_arc_1389  -11
    RHS1      connected_order_arc_1391  -11
    RHS1      connected_order_arc_1393  -11
    RHS1      connected_order_arc_1395  -11
    RHS1      connected_order_arc_1397  -11
    RHS1      connected_order_arc_1399  -11
    RHS1      connected_order_arc_1401  -11
    RHS1      connected_order_arc_1403  -11
    RHS1      connected_order_arc_1406  -11
    RHS1      connected_order_arc_1408  -11
    RHS1      connected_order_arc_1410  -11
    RHS1      connected_order_arc_1412  -11
    RHS1      connected_order_arc_1414  -11
    RHS1      connected_order_arc_1416  -11
    RHS1      connected_order_arc_1418  -11
    RHS1      connected_order_arc_1420  -11
    RHS1      connected_order_arc_1422  -11
    RHS1      connected_order_arc_1424  -11
    RHS1      connected_order_arc_1427  -11
    RHS1      connected_order_arc_1429  -11
    RHS1      connected_order_arc_1431  -11
    RHS1      connected_order_arc_1433  -11
    RHS1      connected_order_arc_1435  -11
    RHS1      connected_order_arc_1437  -11
    RHS1      connected_order_arc_1439  -11
    RHS1      connected_order_arc_1441  -11
    RHS1      connected_order_arc_1443  -11
    RHS1      connected_order_arc_1445  -11
    RHS1      connected_order_arc_1448  -11
    RHS1      connected_order_arc_1450  -11
    RHS1      connected_order_arc_1452  -11
    RHS1      connected_order_arc_1454  -11
    RHS1      connected_order_arc_1456  -11
    RHS1      connected_order_arc_1458  -11
    RHS1      connected_order_arc_1460  -11
    RHS1      connected_order_arc_1462  -11
    RHS1      connected_order_arc_1464  -11
    RHS1      connected_order_arc_1466  -11
    RHS1      connected_order_arc_1469  -11
    RHS1      connected_order_arc_1471  -11
    RHS1      connected_order_arc_1473  -11
    RHS1      connected_order_arc_1475  -11
    RHS1      connected_order_arc_1477  -11
    RHS1      connected_order_arc_1479  -11
    RHS1      connected_order_arc_1481  -11
    RHS1      connected_order_arc_1483  -11
    RHS1      connected_order_arc_1485  -11
    RHS1      connected_order_arc_1487  -11
    RHS1      connected_order_arc_1490  -11
    RHS1      connected_order_arc_1492  -11
    RHS1      connected_order_arc_1494  -11
    RHS1      connected_order_arc_1496  -11
    RHS1      connected_order_arc_1498  -11
    RHS1      connected_order_arc_1500  -11
    RHS1      connected_order_arc_1502  -11
    RHS1      connected_order_arc_1504  -11
    RHS1      connected_order_arc_1506  -11
    RHS1      connected_order_arc_1508  -11
    RHS1      connected_order_arc_1511  -11
    RHS1      connected_order_arc_1513  -11
    RHS1      connected_order_arc_1515  -11
    RHS1      connected_order_arc_1517  -11
    RHS1      connected_order_arc_1519  -11
    RHS1      connected_order_arc_1521  -11
    RHS1      connected_order_arc_1523  -11
    RHS1      connected_order_arc_1525  -11
    RHS1      connected_order_arc_1527  -11
    RHS1      connected_order_arc_1529  -11
    RHS1      connected_order_arc_1532  -11
    RHS1      connected_order_arc_1534  -11
    RHS1      connected_order_arc_1536  -11
    RHS1      connected_order_arc_1538  -11
    RHS1      connected_order_arc_1540  -11
    RHS1      connected_order_arc_1542  -11
    RHS1      connected_order_arc_1544  -11
    RHS1      connected_order_arc_1546  -11
    RHS1      connected_order_arc_1548  -11
    RHS1      connected_order_arc_1550  -11
    RHS1      depot_departure_or_bypass_1551  1
    RHS1      depot_return_or_bypass_1552  1
    RHS1      segment_load_conservation_1557  -1
    RHS1      segment_prefix_lb_1558  1
    RHS1      segment_prefix_ub_1559  27
    RHS1      segment_load_conservation_1564  3
    RHS1      segment_prefix_ub_1566  27
    RHS1      segment_load_conservation_1571  3
    RHS1      segment_prefix_ub_1573  27
    RHS1      fixed_segment_relative_order_1622  1
    RHS1      fixed_segment_relative_order_1623  1
    RHS1      original_T_including_depot_unload_1624  5.5801620601312861e+03
BOUNDS
 LO BND1      t         2.5545373449005350e-02
 UP BND1      t         0.0433212996390325
 UP BND1      q         5.3707784389027569e-01
 BV BND1      x_13_0  
 UP BND1      w_13_0    0.0433212996390325
 BV BND1      x_13_1  
 UP BND1      w_13_1    0.0433212996390325
 BV BND1      x_13_2  
 UP BND1      w_13_2    0.0433212996390325
 BV BND1      x_13_3  
 UP BND1      w_13_3    0.0433212996390325
 BV BND1      x_13_4  
 UP BND1      w_13_4    0.0433212996390325
 BV BND1      x_13_5  
 UP BND1      w_13_5    0.0433212996390325
 BV BND1      x_13_6  
 UP BND1      w_13_6    0.0433212996390325
 BV BND1      x_13_7  
 UP BND1      w_13_7    0.0433212996390325
 BV BND1      x_13_8  
 UP BND1      w_13_8    0.0433212996390325
 BV BND1      x_13_9  
 UP BND1      w_13_9    0.0433212996390325
 BV BND1      x_13_10 
 UP BND1      w_13_10   0.0433212996390325
 BV BND1      x_13_11 
 UP BND1      w_13_11   0.0433212996390325
 BV BND1      x_13_12 
 UP BND1      w_13_12   0.0433212996390325
 BV BND1      x_13_13 
 UP BND1      w_13_13   0.0433212996390325
 BV BND1      x_13_14 
 UP BND1      w_13_14   0.0433212996390325
 BV BND1      x_13_15 
 UP BND1      w_13_15   0.0433212996390325
 BV BND1      x_13_16 
 UP BND1      w_13_16   0.0433212996390325
 BV BND1      x_13_17 
 UP BND1      w_13_17   0.0433212996390325
 BV BND1      x_13_18 
 UP BND1      w_13_18   0.0433212996390325
 BV BND1      x_13_19 
 UP BND1      w_13_19   0.0433212996390325
 UP BND1      rho_13    1
 BV BND1      x_17_0  
 UP BND1      w_17_0    0.0433212996390325
 BV BND1      x_17_1  
 UP BND1      w_17_1    0.0433212996390325
 BV BND1      x_17_2  
 UP BND1      w_17_2    0.0433212996390325
 BV BND1      x_17_3  
 UP BND1      w_17_3    0.0433212996390325
 BV BND1      x_17_4  
 UP BND1      w_17_4    0.0433212996390325
 BV BND1      x_17_5  
 UP BND1      w_17_5    0.0433212996390325
 BV BND1      x_17_6  
 UP BND1      w_17_6    0.0433212996390325
 BV BND1      x_17_7  
 UP BND1      w_17_7    0.0433212996390325
 BV BND1      x_17_8  
 UP BND1      w_17_8    0.0433212996390325
 BV BND1      x_17_9  
 UP BND1      w_17_9    0.0433212996390325
 BV BND1      x_17_10 
 UP BND1      w_17_10   0.0433212996390325
 BV BND1      x_17_11 
 UP BND1      w_17_11   0.0433212996390325
 BV BND1      x_17_12 
 UP BND1      w_17_12   0.0433212996390325
 BV BND1      x_17_13 
 UP BND1      w_17_13   0.0433212996390325
 BV BND1      x_17_14 
 UP BND1      w_17_14   0.0433212996390325
 BV BND1      x_17_15 
 UP BND1      w_17_15   0.0433212996390325
 BV BND1      x_17_16 
 UP BND1      w_17_16   0.0433212996390325
 UP BND1      rho_17    1
 BV BND1      x_31_0  
 UP BND1      w_31_0    0.0433212996390325
 BV BND1      x_31_1  
 UP BND1      w_31_1    0.0433212996390325
 BV BND1      x_31_2  
 UP BND1      w_31_2    0.0433212996390325
 BV BND1      x_31_3  
 UP BND1      w_31_3    0.0433212996390325
 BV BND1      x_31_4  
 UP BND1      w_31_4    0.0433212996390325
 BV BND1      x_31_5  
 UP BND1      w_31_5    0.0433212996390325
 BV BND1      x_31_6  
 UP BND1      w_31_6    0.0433212996390325
 BV BND1      x_31_7  
 UP BND1      w_31_7    0.0433212996390325
 BV BND1      x_31_8  
 UP BND1      w_31_8    0.0433212996390325
 BV BND1      x_31_9  
 UP BND1      w_31_9    0.0433212996390325
 BV BND1      x_31_10 
 UP BND1      w_31_10   0.0433212996390325
 BV BND1      x_31_11 
 UP BND1      w_31_11   0.0433212996390325
 BV BND1      x_31_12 
 UP BND1      w_31_12   0.0433212996390325
 UP BND1      rho_31    1
 BV BND1      x_6_0   
 UP BND1      w_6_0     0.0433212996390325
 BV BND1      x_6_1   
 UP BND1      w_6_1     0.0433212996390325
 BV BND1      x_6_2   
 UP BND1      w_6_2     0.0433212996390325
 BV BND1      x_6_3   
 UP BND1      w_6_3     0.0433212996390325
 BV BND1      x_6_4   
 UP BND1      w_6_4     0.0433212996390325
 BV BND1      x_6_5   
 UP BND1      w_6_5     0.0433212996390325
 BV BND1      x_6_6   
 UP BND1      w_6_6     0.0433212996390325
 BV BND1      x_6_7   
 UP BND1      w_6_7     0.0433212996390325
 BV BND1      x_6_8   
 UP BND1      w_6_8     0.0433212996390325
 BV BND1      x_6_9   
 UP BND1      w_6_9     0.0433212996390325
 BV BND1      x_6_10  
 UP BND1      w_6_10    0.0433212996390325
 UP BND1      rho_6     1
 BV BND1      x_14_0  
 UP BND1      w_14_0    0.0433212996390325
 BV BND1      x_14_1  
 UP BND1      w_14_1    0.0433212996390325
 BV BND1      x_14_2  
 UP BND1      w_14_2    0.0433212996390325
 BV BND1      x_14_3  
 UP BND1      w_14_3    0.0433212996390325
 BV BND1      x_14_4  
 UP BND1      w_14_4    0.0433212996390325
 BV BND1      x_14_5  
 UP BND1      w_14_5    0.0433212996390325
 BV BND1      x_14_6  
 UP BND1      w_14_6    0.0433212996390325
 BV BND1      x_14_7  
 UP BND1      w_14_7    0.0433212996390325
 BV BND1      x_14_8  
 UP BND1      w_14_8    0.0433212996390325
 BV BND1      x_14_9  
 UP BND1      w_14_9    0.0433212996390325
 BV BND1      x_14_10 
 UP BND1      w_14_10   0.0433212996390325
 BV BND1      x_14_11 
 UP BND1      w_14_11   0.0433212996390325
 BV BND1      x_14_12 
 UP BND1      w_14_12   0.0433212996390325
 BV BND1      x_14_13 
 UP BND1      w_14_13   0.0433212996390325
 BV BND1      x_14_14 
 UP BND1      w_14_14   0.0433212996390325
 BV BND1      x_14_15 
 UP BND1      w_14_15   0.0433212996390325
 UP BND1      rho_14    1
 BV BND1      x_15_0  
 UP BND1      w_15_0    0.0433212996390325
 BV BND1      x_15_1  
 UP BND1      w_15_1    0.0433212996390325
 BV BND1      x_15_2  
 UP BND1      w_15_2    0.0433212996390325
 BV BND1      x_15_3  
 UP BND1      w_15_3    0.0433212996390325
 BV BND1      x_15_4  
 UP BND1      w_15_4    0.0433212996390325
 BV BND1      x_15_5  
 UP BND1      w_15_5    0.0433212996390325
 BV BND1      x_15_6  
 UP BND1      w_15_6    0.0433212996390325
 BV BND1      x_15_7  
 UP BND1      w_15_7    0.0433212996390325
 BV BND1      x_15_8  
 UP BND1      w_15_8    0.0433212996390325
 BV BND1      x_15_9  
 UP BND1      w_15_9    0.0433212996390325
 BV BND1      x_15_10 
 UP BND1      w_15_10   0.0433212996390325
 BV BND1      x_15_11 
 UP BND1      w_15_11   0.0433212996390325
 BV BND1      x_15_12 
 UP BND1      w_15_12   0.0433212996390325
 BV BND1      x_15_13 
 UP BND1      w_15_13   0.0433212996390325
 BV BND1      x_15_14 
 UP BND1      w_15_14   0.0433212996390325
 BV BND1      x_15_15 
 UP BND1      w_15_15   0.0433212996390325
 BV BND1      x_15_16 
 UP BND1      w_15_16   0.0433212996390325
 UP BND1      rho_15    1
 BV BND1      x_2_0   
 UP BND1      w_2_0     0.0433212996390325
 BV BND1      x_2_1   
 UP BND1      w_2_1     0.0433212996390325
 BV BND1      x_2_2   
 UP BND1      w_2_2     0.0433212996390325
 BV BND1      x_2_3   
 UP BND1      w_2_3     0.0433212996390325
 BV BND1      x_2_4   
 UP BND1      w_2_4     0.0433212996390325
 BV BND1      x_2_5   
 UP BND1      w_2_5     0.0433212996390325
 BV BND1      x_2_6   
 UP BND1      w_2_6     0.0433212996390325
 BV BND1      x_2_7   
 UP BND1      w_2_7     0.0433212996390325
 BV BND1      x_2_8   
 UP BND1      w_2_8     0.0433212996390325
 BV BND1      x_2_9   
 UP BND1      w_2_9     0.0433212996390325
 BV BND1      x_2_10  
 UP BND1      w_2_10    0.0433212996390325
 BV BND1      x_2_11  
 UP BND1      w_2_11    0.0433212996390325
 BV BND1      x_2_12  
 UP BND1      w_2_12    0.0433212996390325
 BV BND1      x_2_13  
 UP BND1      w_2_13    0.0433212996390325
 BV BND1      x_2_14  
 UP BND1      w_2_14    0.0433212996390325
 BV BND1      x_2_15  
 UP BND1      w_2_15    0.0433212996390325
 UP BND1      rho_2     1
 BV BND1      x_9_0   
 UP BND1      w_9_0     0.0433212996390325
 BV BND1      x_9_1   
 UP BND1      w_9_1     0.0433212996390325
 BV BND1      x_9_2   
 UP BND1      w_9_2     0.0433212996390325
 BV BND1      x_9_3   
 UP BND1      w_9_3     0.0433212996390325
 BV BND1      x_9_4   
 UP BND1      w_9_4     0.0433212996390325
 BV BND1      x_9_5   
 UP BND1      w_9_5     0.0433212996390325
 BV BND1      x_9_6   
 UP BND1      w_9_6     0.0433212996390325
 BV BND1      x_9_7   
 UP BND1      w_9_7     0.0433212996390325
 BV BND1      x_9_8   
 UP BND1      w_9_8     0.0433212996390325
 BV BND1      x_9_9   
 UP BND1      w_9_9     0.0433212996390325
 BV BND1      x_9_10  
 UP BND1      w_9_10    0.0433212996390325
 BV BND1      x_9_11  
 UP BND1      w_9_11    0.0433212996390325
 BV BND1      x_9_12  
 UP BND1      w_9_12    0.0433212996390325
 UP BND1      rho_9     1
 UP BND1      a_13_17   1
 UP BND1      a_13_31   1
 UP BND1      a_13_6    1
 UP BND1      a_13_14   1
 UP BND1      a_13_15   1
 UP BND1      a_13_2    1
 UP BND1      a_13_9    1
 UP BND1      a_17_31   1
 UP BND1      a_17_6    1
 UP BND1      a_17_14   1
 UP BND1      a_17_15   1
 UP BND1      a_17_2    1
 UP BND1      a_17_9    1
 UP BND1      a_31_6    1
 UP BND1      a_31_14   1
 UP BND1      a_31_15   1
 UP BND1      a_31_2    1
 UP BND1      a_31_9    1
 UP BND1      a_6_14    1
 UP BND1      a_6_15    1
 UP BND1      a_6_2     1
 UP BND1      a_6_9     1
 UP BND1      a_14_15   1
 UP BND1      a_14_2    1
 UP BND1      a_14_9    1
 UP BND1      a_15_2    1
 UP BND1      a_15_9    1
 UP BND1      a_2_9     1
 BV BND1      service_0_13_0
 BV BND1      service_0_13_1
 BV BND1      service_0_13_2
 BV BND1      service_0_13_3
 BV BND1      service_0_13_4
 BV BND1      service_0_13_5
 BV BND1      service_0_13_6
 BV BND1      service_0_13_7
 BV BND1      service_0_13_8
 BV BND1      service_0_13_9
 BV BND1      service_0_13_10
 BV BND1      service_0_13_11
 BV BND1      service_0_13_12
 BV BND1      service_0_13_14
 BV BND1      service_0_13_15
 BV BND1      service_0_13_16
 BV BND1      service_0_13_17
 BV BND1      service_0_13_18
 BV BND1      service_0_13_19
 BV BND1      service_1_13_0
 BV BND1      service_1_13_1
 BV BND1      service_1_13_2
 BV BND1      service_1_13_3
 BV BND1      service_1_13_4
 BV BND1      service_1_13_5
 BV BND1      service_1_13_6
 BV BND1      service_1_13_7
 BV BND1      service_1_13_8
 BV BND1      service_1_13_9
 BV BND1      service_1_13_10
 BV BND1      service_1_13_11
 BV BND1      service_1_13_12
 BV BND1      service_1_13_14
 BV BND1      service_1_13_15
 BV BND1      service_1_13_16
 BV BND1      service_1_13_17
 BV BND1      service_1_13_18
 BV BND1      service_1_13_19
 BV BND1      service_2_13_0
 BV BND1      service_2_13_1
 BV BND1      service_2_13_2
 BV BND1      service_2_13_3
 BV BND1      service_2_13_4
 BV BND1      service_2_13_5
 BV BND1      service_2_13_6
 BV BND1      service_2_13_7
 BV BND1      service_2_13_8
 BV BND1      service_2_13_9
 BV BND1      service_2_13_10
 BV BND1      service_2_13_11
 BV BND1      service_2_13_12
 BV BND1      service_2_13_14
 BV BND1      service_2_13_15
 BV BND1      service_2_13_16
 BV BND1      service_2_13_17
 BV BND1      service_2_13_18
 BV BND1      service_2_13_19
 BV BND1      service_0_17_0
 BV BND1      service_0_17_1
 BV BND1      service_0_17_2
 BV BND1      service_0_17_4
 BV BND1      service_0_17_5
 BV BND1      service_0_17_6
 BV BND1      service_0_17_7
 BV BND1      service_0_17_8
 BV BND1      service_0_17_9
 BV BND1      service_0_17_10
 BV BND1      service_0_17_11
 BV BND1      service_0_17_12
 BV BND1      service_0_17_13
 BV BND1      service_0_17_14
 BV BND1      service_0_17_15
 BV BND1      service_0_17_16
 BV BND1      service_1_17_0
 BV BND1      service_1_17_1
 BV BND1      service_1_17_2
 BV BND1      service_1_17_4
 BV BND1      service_1_17_5
 BV BND1      service_1_17_6
 BV BND1      service_1_17_7
 BV BND1      service_1_17_8
 BV BND1      service_1_17_9
 BV BND1      service_1_17_10
 BV BND1      service_1_17_11
 BV BND1      service_1_17_12
 BV BND1      service_1_17_13
 BV BND1      service_1_17_14
 BV BND1      service_1_17_15
 BV BND1      service_1_17_16
 BV BND1      service_2_17_0
 BV BND1      service_2_17_1
 BV BND1      service_2_17_2
 BV BND1      service_2_17_4
 BV BND1      service_2_17_5
 BV BND1      service_2_17_6
 BV BND1      service_2_17_7
 BV BND1      service_2_17_8
 BV BND1      service_2_17_9
 BV BND1      service_2_17_10
 BV BND1      service_2_17_11
 BV BND1      service_2_17_12
 BV BND1      service_2_17_13
 BV BND1      service_2_17_14
 BV BND1      service_2_17_15
 BV BND1      service_2_17_16
 BV BND1      service_0_31_0
 BV BND1      service_0_31_1
 BV BND1      service_0_31_3
 BV BND1      service_0_31_4
 BV BND1      service_0_31_5
 BV BND1      service_0_31_6
 BV BND1      service_0_31_7
 BV BND1      service_0_31_8
 BV BND1      service_0_31_9
 BV BND1      service_0_31_10
 BV BND1      service_0_31_11
 BV BND1      service_0_31_12
 BV BND1      service_1_31_0
 BV BND1      service_1_31_1
 BV BND1      service_1_31_3
 BV BND1      service_1_31_4
 BV BND1      service_1_31_5
 BV BND1      service_1_31_6
 BV BND1      service_1_31_7
 BV BND1      service_1_31_8
 BV BND1      service_1_31_9
 BV BND1      service_1_31_10
 BV BND1      service_1_31_11
 BV BND1      service_1_31_12
 BV BND1      service_2_31_0
 BV BND1      service_2_31_1
 BV BND1      service_2_31_3
 BV BND1      service_2_31_4
 BV BND1      service_2_31_5
 BV BND1      service_2_31_6
 BV BND1      service_2_31_7
 BV BND1      service_2_31_8
 BV BND1      service_2_31_9
 BV BND1      service_2_31_10
 BV BND1      service_2_31_11
 BV BND1      service_2_31_12
 BV BND1      service_0_6_0
 BV BND1      service_0_6_2
 BV BND1      service_0_6_3
 BV BND1      service_0_6_4
 BV BND1      service_0_6_5
 BV BND1      service_0_6_6
 BV BND1      service_0_6_7
 BV BND1      service_0_6_8
 BV BND1      service_0_6_9
 BV BND1      service_0_6_10
 BV BND1      service_1_6_0
 BV BND1      service_1_6_2
 BV BND1      service_1_6_3
 BV BND1      service_1_6_4
 BV BND1      service_1_6_5
 BV BND1      service_1_6_6
 BV BND1      service_1_6_7
 BV BND1      service_1_6_8
 BV BND1      service_1_6_9
 BV BND1      service_1_6_10
 BV BND1      service_2_6_0
 BV BND1      service_2_6_2
 BV BND1      service_2_6_3
 BV BND1      service_2_6_4
 BV BND1      service_2_6_5
 BV BND1      service_2_6_6
 BV BND1      service_2_6_7
 BV BND1      service_2_6_8
 BV BND1      service_2_6_9
 BV BND1      service_2_6_10
 BV BND1      service_0_14_0
 BV BND1      service_0_14_1
 BV BND1      service_0_14_3
 BV BND1      service_0_14_4
 BV BND1      service_0_14_5
 BV BND1      service_0_14_6
 BV BND1      service_0_14_7
 BV BND1      service_0_14_8
 BV BND1      service_0_14_9
 BV BND1      service_0_14_10
 BV BND1      service_0_14_11
 BV BND1      service_0_14_12
 BV BND1      service_0_14_13
 BV BND1      service_0_14_14
 BV BND1      service_0_14_15
 BV BND1      service_1_14_0
 BV BND1      service_1_14_1
 BV BND1      service_1_14_3
 BV BND1      service_1_14_4
 BV BND1      service_1_14_5
 BV BND1      service_1_14_6
 BV BND1      service_1_14_7
 BV BND1      service_1_14_8
 BV BND1      service_1_14_9
 BV BND1      service_1_14_10
 BV BND1      service_1_14_11
 BV BND1      service_1_14_12
 BV BND1      service_1_14_13
 BV BND1      service_1_14_14
 BV BND1      service_1_14_15
 BV BND1      service_2_14_0
 BV BND1      service_2_14_1
 BV BND1      service_2_14_3
 BV BND1      service_2_14_4
 BV BND1      service_2_14_5
 BV BND1      service_2_14_6
 BV BND1      service_2_14_7
 BV BND1      service_2_14_8
 BV BND1      service_2_14_9
 BV BND1      service_2_14_10
 BV BND1      service_2_14_11
 BV BND1      service_2_14_12
 BV BND1      service_2_14_13
 BV BND1      service_2_14_14
 BV BND1      service_2_14_15
 BV BND1      service_0_15_0
 BV BND1      service_0_15_1
 BV BND1      service_0_15_2
 BV BND1      service_0_15_4
 BV BND1      service_0_15_5
 BV BND1      service_0_15_6
 BV BND1      service_0_15_7
 BV BND1      service_0_15_8
 BV BND1      service_0_15_9
 BV BND1      service_0_15_10
 BV BND1      service_0_15_11
 BV BND1      service_0_15_12
 BV BND1      service_0_15_13
 BV BND1      service_0_15_14
 BV BND1      service_0_15_15
 BV BND1      service_0_15_16
 BV BND1      service_1_15_0
 BV BND1      service_1_15_1
 BV BND1      service_1_15_2
 BV BND1      service_1_15_4
 BV BND1      service_1_15_5
 BV BND1      service_1_15_6
 BV BND1      service_1_15_7
 BV BND1      service_1_15_8
 BV BND1      service_1_15_9
 BV BND1      service_1_15_10
 BV BND1      service_1_15_11
 BV BND1      service_1_15_12
 BV BND1      service_1_15_13
 BV BND1      service_1_15_14
 BV BND1      service_1_15_15
 BV BND1      service_1_15_16
 BV BND1      service_2_15_0
 BV BND1      service_2_15_1
 BV BND1      service_2_15_2
 BV BND1      service_2_15_4
 BV BND1      service_2_15_5
 BV BND1      service_2_15_6
 BV BND1      service_2_15_7
 BV BND1      service_2_15_8
 BV BND1      service_2_15_9
 BV BND1      service_2_15_10
 BV BND1      service_2_15_11
 BV BND1      service_2_15_12
 BV BND1      service_2_15_13
 BV BND1      service_2_15_14
 BV BND1      service_2_15_15
 BV BND1      service_2_15_16
 BV BND1      service_0_2_1
 BV BND1      service_0_2_2
 BV BND1      service_0_2_3
 BV BND1      service_0_2_4
 BV BND1      service_0_2_5
 BV BND1      service_0_2_6
 BV BND1      service_0_2_7
 BV BND1      service_0_2_8
 BV BND1      service_0_2_9
 BV BND1      service_0_2_10
 BV BND1      service_0_2_11
 BV BND1      service_0_2_12
 BV BND1      service_0_2_13
 BV BND1      service_0_2_14
 BV BND1      service_0_2_15
 BV BND1      service_1_2_1
 BV BND1      service_1_2_2
 BV BND1      service_1_2_3
 BV BND1      service_1_2_4
 BV BND1      service_1_2_5
 BV BND1      service_1_2_6
 BV BND1      service_1_2_7
 BV BND1      service_1_2_8
 BV BND1      service_1_2_9
 BV BND1      service_1_2_10
 BV BND1      service_1_2_11
 BV BND1      service_1_2_12
 BV BND1      service_1_2_13
 BV BND1      service_1_2_14
 BV BND1      service_1_2_15
 BV BND1      service_2_2_1
 BV BND1      service_2_2_2
 BV BND1      service_2_2_3
 BV BND1      service_2_2_4
 BV BND1      service_2_2_5
 BV BND1      service_2_2_6
 BV BND1      service_2_2_7
 BV BND1      service_2_2_8
 BV BND1      service_2_2_9
 BV BND1      service_2_2_10
 BV BND1      service_2_2_11
 BV BND1      service_2_2_12
 BV BND1      service_2_2_13
 BV BND1      service_2_2_14
 BV BND1      service_2_2_15
 BV BND1      service_0_9_0
 BV BND1      service_0_9_1
 BV BND1      service_0_9_2
 BV BND1      service_0_9_3
 BV BND1      service_0_9_4
 BV BND1      service_0_9_5
 BV BND1      service_0_9_6
 BV BND1      service_0_9_7
 BV BND1      service_0_9_9
 BV BND1      service_0_9_10
 BV BND1      service_0_9_11
 BV BND1      service_0_9_12
 BV BND1      service_1_9_0
 BV BND1      service_1_9_1
 BV BND1      service_1_9_2
 BV BND1      service_1_9_3
 BV BND1      service_1_9_4
 BV BND1      service_1_9_5
 BV BND1      service_1_9_6
 BV BND1      service_1_9_7
 BV BND1      service_1_9_9
 BV BND1      service_1_9_10
 BV BND1      service_1_9_11
 BV BND1      service_1_9_12
 BV BND1      service_2_9_0
 BV BND1      service_2_9_1
 BV BND1      service_2_9_2
 BV BND1      service_2_9_3
 BV BND1      service_2_9_4
 BV BND1      service_2_9_5
 BV BND1      service_2_9_6
 BV BND1      service_2_9_7
 BV BND1      service_2_9_9
 BV BND1      service_2_9_10
 BV BND1      service_2_9_11
 BV BND1      service_2_9_12
 FX BND1      visit_0_1  1
 UP BND1      order_0_1  14
 FX BND1      visit_0_2  1
 UP BND1      order_0_2  14
 FX BND1      visit_0_3  1
 UP BND1      order_0_3  14
 FX BND1      visit_0_4  1
 UP BND1      order_0_4  14
 FX BND1      visit_0_5  1
 UP BND1      order_0_5  14
 FX BND1      visit_0_6  1
 UP BND1      order_0_6  14
 UP BND1      visit_0_14  1
 UP BND1      order_0_14  14
 UP BND1      visit_0_15  1
 UP BND1      order_0_15  14
 UP BND1      visit_0_16  1
 UP BND1      order_0_16  14
 UP BND1      visit_0_17  1
 UP BND1      order_0_17  14
 UP BND1      visit_0_18  1
 UP BND1      order_0_18  14
 UP BND1      visit_0_19  1
 UP BND1      order_0_19  14
 UP BND1      visit_0_20  1
 UP BND1      order_0_20  14
 UP BND1      visit_0_21  1
 UP BND1      order_0_21  14
 BV BND1      arc_0_0_0
 FX BND1      load_0_0_0  0
 BV BND1      arc_0_0_1
 FX BND1      load_0_0_1  0
 BV BND1      arc_0_0_2
 FX BND1      load_0_0_2  0
 BV BND1      arc_0_0_3
 FX BND1      load_0_0_3  0
 BV BND1      arc_0_0_4
 FX BND1      load_0_0_4  0
 BV BND1      arc_0_0_5
 FX BND1      load_0_0_5  0
 BV BND1      arc_0_0_6
 FX BND1      load_0_0_6  0
 BV BND1      arc_0_0_14
 FX BND1      load_0_0_14  0
 BV BND1      arc_0_0_15
 FX BND1      load_0_0_15  0
 BV BND1      arc_0_0_16
 FX BND1      load_0_0_16  0
 BV BND1      arc_0_0_17
 FX BND1      load_0_0_17  0
 BV BND1      arc_0_0_18
 FX BND1      load_0_0_18  0
 BV BND1      arc_0_0_19
 FX BND1      load_0_0_19  0
 BV BND1      arc_0_0_20
 FX BND1      load_0_0_20  0
 BV BND1      arc_0_0_21
 FX BND1      load_0_0_21  0
 BV BND1      arc_0_1_0
 UP BND1      load_0_1_0  20
 BV BND1      arc_0_1_2
 UP BND1      load_0_1_2  20
 BV BND1      arc_0_1_3
 UP BND1      load_0_1_3  20
 BV BND1      arc_0_1_4
 UP BND1      load_0_1_4  20
 BV BND1      arc_0_1_5
 UP BND1      load_0_1_5  20
 BV BND1      arc_0_1_6
 UP BND1      load_0_1_6  20
 BV BND1      arc_0_1_14
 UP BND1      load_0_1_14  20
 BV BND1      arc_0_1_15
 UP BND1      load_0_1_15  20
 BV BND1      arc_0_1_16
 UP BND1      load_0_1_16  20
 BV BND1      arc_0_1_17
 UP BND1      load_0_1_17  20
 BV BND1      arc_0_1_18
 UP BND1      load_0_1_18  20
 BV BND1      arc_0_1_19
 UP BND1      load_0_1_19  20
 BV BND1      arc_0_1_20
 UP BND1      load_0_1_20  20
 BV BND1      arc_0_1_21
 UP BND1      load_0_1_21  20
 BV BND1      arc_0_2_0
 UP BND1      load_0_2_0  20
 BV BND1      arc_0_2_1
 UP BND1      load_0_2_1  20
 BV BND1      arc_0_2_3
 UP BND1      load_0_2_3  20
 BV BND1      arc_0_2_4
 UP BND1      load_0_2_4  20
 BV BND1      arc_0_2_5
 UP BND1      load_0_2_5  20
 BV BND1      arc_0_2_6
 UP BND1      load_0_2_6  20
 BV BND1      arc_0_2_14
 UP BND1      load_0_2_14  20
 BV BND1      arc_0_2_15
 UP BND1      load_0_2_15  20
 BV BND1      arc_0_2_16
 UP BND1      load_0_2_16  20
 BV BND1      arc_0_2_17
 UP BND1      load_0_2_17  20
 BV BND1      arc_0_2_18
 UP BND1      load_0_2_18  20
 BV BND1      arc_0_2_19
 UP BND1      load_0_2_19  20
 BV BND1      arc_0_2_20
 UP BND1      load_0_2_20  20
 BV BND1      arc_0_2_21
 UP BND1      load_0_2_21  20
 BV BND1      arc_0_3_0
 UP BND1      load_0_3_0  20
 BV BND1      arc_0_3_1
 UP BND1      load_0_3_1  20
 BV BND1      arc_0_3_2
 UP BND1      load_0_3_2  20
 BV BND1      arc_0_3_4
 UP BND1      load_0_3_4  20
 BV BND1      arc_0_3_5
 UP BND1      load_0_3_5  20
 BV BND1      arc_0_3_6
 UP BND1      load_0_3_6  20
 BV BND1      arc_0_3_14
 UP BND1      load_0_3_14  20
 BV BND1      arc_0_3_15
 UP BND1      load_0_3_15  20
 BV BND1      arc_0_3_16
 UP BND1      load_0_3_16  20
 BV BND1      arc_0_3_17
 UP BND1      load_0_3_17  20
 BV BND1      arc_0_3_18
 UP BND1      load_0_3_18  20
 BV BND1      arc_0_3_19
 UP BND1      load_0_3_19  20
 BV BND1      arc_0_3_20
 UP BND1      load_0_3_20  20
 BV BND1      arc_0_3_21
 UP BND1      load_0_3_21  20
 BV BND1      arc_0_4_0
 UP BND1      load_0_4_0  20
 BV BND1      arc_0_4_1
 UP BND1      load_0_4_1  20
 BV BND1      arc_0_4_2
 UP BND1      load_0_4_2  20
 BV BND1      arc_0_4_3
 UP BND1      load_0_4_3  20
 BV BND1      arc_0_4_5
 UP BND1      load_0_4_5  20
 BV BND1      arc_0_4_6
 UP BND1      load_0_4_6  20
 BV BND1      arc_0_4_14
 UP BND1      load_0_4_14  20
 BV BND1      arc_0_4_15
 UP BND1      load_0_4_15  20
 BV BND1      arc_0_4_16
 UP BND1      load_0_4_16  20
 BV BND1      arc_0_4_17
 UP BND1      load_0_4_17  20
 BV BND1      arc_0_4_18
 UP BND1      load_0_4_18  20
 BV BND1      arc_0_4_19
 UP BND1      load_0_4_19  20
 BV BND1      arc_0_4_20
 UP BND1      load_0_4_20  20
 BV BND1      arc_0_4_21
 UP BND1      load_0_4_21  20
 BV BND1      arc_0_5_0
 UP BND1      load_0_5_0  20
 BV BND1      arc_0_5_1
 UP BND1      load_0_5_1  20
 BV BND1      arc_0_5_2
 UP BND1      load_0_5_2  20
 BV BND1      arc_0_5_3
 UP BND1      load_0_5_3  20
 BV BND1      arc_0_5_4
 UP BND1      load_0_5_4  20
 BV BND1      arc_0_5_6
 UP BND1      load_0_5_6  20
 BV BND1      arc_0_5_14
 UP BND1      load_0_5_14  20
 BV BND1      arc_0_5_15
 UP BND1      load_0_5_15  20
 BV BND1      arc_0_5_16
 UP BND1      load_0_5_16  20
 BV BND1      arc_0_5_17
 UP BND1      load_0_5_17  20
 BV BND1      arc_0_5_18
 UP BND1      load_0_5_18  20
 BV BND1      arc_0_5_19
 UP BND1      load_0_5_19  20
 BV BND1      arc_0_5_20
 UP BND1      load_0_5_20  20
 BV BND1      arc_0_5_21
 UP BND1      load_0_5_21  20
 BV BND1      arc_0_6_0
 UP BND1      load_0_6_0  20
 BV BND1      arc_0_6_1
 UP BND1      load_0_6_1  20
 BV BND1      arc_0_6_2
 UP BND1      load_0_6_2  20
 BV BND1      arc_0_6_3
 UP BND1      load_0_6_3  20
 BV BND1      arc_0_6_4
 UP BND1      load_0_6_4  20
 BV BND1      arc_0_6_5
 UP BND1      load_0_6_5  20
 BV BND1      arc_0_6_14
 UP BND1      load_0_6_14  20
 BV BND1      arc_0_6_15
 UP BND1      load_0_6_15  20
 BV BND1      arc_0_6_16
 UP BND1      load_0_6_16  20
 BV BND1      arc_0_6_17
 UP BND1      load_0_6_17  20
 BV BND1      arc_0_6_18
 UP BND1      load_0_6_18  20
 BV BND1      arc_0_6_19
 UP BND1      load_0_6_19  20
 BV BND1      arc_0_6_20
 UP BND1      load_0_6_20  20
 BV BND1      arc_0_6_21
 UP BND1      load_0_6_21  20
 BV BND1      arc_0_14_0
 UP BND1      load_0_14_0  20
 BV BND1      arc_0_14_1
 UP BND1      load_0_14_1  20
 BV BND1      arc_0_14_2
 UP BND1      load_0_14_2  20
 BV BND1      arc_0_14_3
 UP BND1      load_0_14_3  20
 BV BND1      arc_0_14_4
 UP BND1      load_0_14_4  20
 BV BND1      arc_0_14_5
 UP BND1      load_0_14_5  20
 BV BND1      arc_0_14_6
 UP BND1      load_0_14_6  20
 BV BND1      arc_0_14_15
 UP BND1      load_0_14_15  20
 BV BND1      arc_0_14_16
 UP BND1      load_0_14_16  20
 BV BND1      arc_0_14_17
 UP BND1      load_0_14_17  20
 BV BND1      arc_0_14_18
 UP BND1      load_0_14_18  20
 BV BND1      arc_0_14_19
 UP BND1      load_0_14_19  20
 BV BND1      arc_0_14_20
 UP BND1      load_0_14_20  20
 BV BND1      arc_0_14_21
 UP BND1      load_0_14_21  20
 BV BND1      arc_0_15_0
 UP BND1      load_0_15_0  20
 BV BND1      arc_0_15_1
 UP BND1      load_0_15_1  20
 BV BND1      arc_0_15_2
 UP BND1      load_0_15_2  20
 BV BND1      arc_0_15_3
 UP BND1      load_0_15_3  20
 BV BND1      arc_0_15_4
 UP BND1      load_0_15_4  20
 BV BND1      arc_0_15_5
 UP BND1      load_0_15_5  20
 BV BND1      arc_0_15_6
 UP BND1      load_0_15_6  20
 BV BND1      arc_0_15_14
 UP BND1      load_0_15_14  20
 BV BND1      arc_0_15_16
 UP BND1      load_0_15_16  20
 BV BND1      arc_0_15_17
 UP BND1      load_0_15_17  20
 BV BND1      arc_0_15_18
 UP BND1      load_0_15_18  20
 BV BND1      arc_0_15_19
 UP BND1      load_0_15_19  20
 BV BND1      arc_0_15_20
 UP BND1      load_0_15_20  20
 BV BND1      arc_0_15_21
 UP BND1      load_0_15_21  20
 BV BND1      arc_0_16_0
 UP BND1      load_0_16_0  20
 BV BND1      arc_0_16_1
 UP BND1      load_0_16_1  20
 BV BND1      arc_0_16_2
 UP BND1      load_0_16_2  20
 BV BND1      arc_0_16_3
 UP BND1      load_0_16_3  20
 BV BND1      arc_0_16_4
 UP BND1      load_0_16_4  20
 BV BND1      arc_0_16_5
 UP BND1      load_0_16_5  20
 BV BND1      arc_0_16_6
 UP BND1      load_0_16_6  20
 BV BND1      arc_0_16_14
 UP BND1      load_0_16_14  20
 BV BND1      arc_0_16_15
 UP BND1      load_0_16_15  20
 BV BND1      arc_0_16_17
 UP BND1      load_0_16_17  20
 BV BND1      arc_0_16_18
 UP BND1      load_0_16_18  20
 BV BND1      arc_0_16_19
 UP BND1      load_0_16_19  20
 BV BND1      arc_0_16_20
 UP BND1      load_0_16_20  20
 BV BND1      arc_0_16_21
 UP BND1      load_0_16_21  20
 BV BND1      arc_0_17_0
 UP BND1      load_0_17_0  20
 BV BND1      arc_0_17_1
 UP BND1      load_0_17_1  20
 BV BND1      arc_0_17_2
 UP BND1      load_0_17_2  20
 BV BND1      arc_0_17_3
 UP BND1      load_0_17_3  20
 BV BND1      arc_0_17_4
 UP BND1      load_0_17_4  20
 BV BND1      arc_0_17_5
 UP BND1      load_0_17_5  20
 BV BND1      arc_0_17_6
 UP BND1      load_0_17_6  20
 BV BND1      arc_0_17_14
 UP BND1      load_0_17_14  20
 BV BND1      arc_0_17_15
 UP BND1      load_0_17_15  20
 BV BND1      arc_0_17_16
 UP BND1      load_0_17_16  20
 BV BND1      arc_0_17_18
 UP BND1      load_0_17_18  20
 BV BND1      arc_0_17_19
 UP BND1      load_0_17_19  20
 BV BND1      arc_0_17_20
 UP BND1      load_0_17_20  20
 BV BND1      arc_0_17_21
 UP BND1      load_0_17_21  20
 BV BND1      arc_0_18_0
 UP BND1      load_0_18_0  20
 BV BND1      arc_0_18_1
 UP BND1      load_0_18_1  20
 BV BND1      arc_0_18_2
 UP BND1      load_0_18_2  20
 BV BND1      arc_0_18_3
 UP BND1      load_0_18_3  20
 BV BND1      arc_0_18_4
 UP BND1      load_0_18_4  20
 BV BND1      arc_0_18_5
 UP BND1      load_0_18_5  20
 BV BND1      arc_0_18_6
 UP BND1      load_0_18_6  20
 BV BND1      arc_0_18_14
 UP BND1      load_0_18_14  20
 BV BND1      arc_0_18_15
 UP BND1      load_0_18_15  20
 BV BND1      arc_0_18_16
 UP BND1      load_0_18_16  20
 BV BND1      arc_0_18_17
 UP BND1      load_0_18_17  20
 BV BND1      arc_0_18_19
 UP BND1      load_0_18_19  20
 BV BND1      arc_0_18_20
 UP BND1      load_0_18_20  20
 BV BND1      arc_0_18_21
 UP BND1      load_0_18_21  20
 BV BND1      arc_0_19_0
 UP BND1      load_0_19_0  20
 BV BND1      arc_0_19_1
 UP BND1      load_0_19_1  20
 BV BND1      arc_0_19_2
 UP BND1      load_0_19_2  20
 BV BND1      arc_0_19_3
 UP BND1      load_0_19_3  20
 BV BND1      arc_0_19_4
 UP BND1      load_0_19_4  20
 BV BND1      arc_0_19_5
 UP BND1      load_0_19_5  20
 BV BND1      arc_0_19_6
 UP BND1      load_0_19_6  20
 BV BND1      arc_0_19_14
 UP BND1      load_0_19_14  20
 BV BND1      arc_0_19_15
 UP BND1      load_0_19_15  20
 BV BND1      arc_0_19_16
 UP BND1      load_0_19_16  20
 BV BND1      arc_0_19_17
 UP BND1      load_0_19_17  20
 BV BND1      arc_0_19_18
 UP BND1      load_0_19_18  20
 BV BND1      arc_0_19_20
 UP BND1      load_0_19_20  20
 BV BND1      arc_0_19_21
 UP BND1      load_0_19_21  20
 BV BND1      arc_0_20_0
 UP BND1      load_0_20_0  20
 BV BND1      arc_0_20_1
 UP BND1      load_0_20_1  20
 BV BND1      arc_0_20_2
 UP BND1      load_0_20_2  20
 BV BND1      arc_0_20_3
 UP BND1      load_0_20_3  20
 BV BND1      arc_0_20_4
 UP BND1      load_0_20_4  20
 BV BND1      arc_0_20_5
 UP BND1      load_0_20_5  20
 BV BND1      arc_0_20_6
 UP BND1      load_0_20_6  20
 BV BND1      arc_0_20_14
 UP BND1      load_0_20_14  20
 BV BND1      arc_0_20_15
 UP BND1      load_0_20_15  20
 BV BND1      arc_0_20_16
 UP BND1      load_0_20_16  20
 BV BND1      arc_0_20_17
 UP BND1      load_0_20_17  20
 BV BND1      arc_0_20_18
 UP BND1      load_0_20_18  20
 BV BND1      arc_0_20_19
 UP BND1      load_0_20_19  20
 BV BND1      arc_0_20_21
 UP BND1      load_0_20_21  20
 BV BND1      arc_0_21_0
 UP BND1      load_0_21_0  20
 BV BND1      arc_0_21_1
 UP BND1      load_0_21_1  20
 BV BND1      arc_0_21_2
 UP BND1      load_0_21_2  20
 BV BND1      arc_0_21_3
 UP BND1      load_0_21_3  20
 BV BND1      arc_0_21_4
 UP BND1      load_0_21_4  20
 BV BND1      arc_0_21_5
 UP BND1      load_0_21_5  20
 BV BND1      arc_0_21_6
 UP BND1      load_0_21_6  20
 BV BND1      arc_0_21_14
 UP BND1      load_0_21_14  20
 BV BND1      arc_0_21_15
 UP BND1      load_0_21_15  20
 BV BND1      arc_0_21_16
 UP BND1      load_0_21_16  20
 BV BND1      arc_0_21_17
 UP BND1      load_0_21_17  20
 BV BND1      arc_0_21_18
 UP BND1      load_0_21_18  20
 BV BND1      arc_0_21_19
 UP BND1      load_0_21_19  20
 BV BND1      arc_0_21_20
 UP BND1      load_0_21_20  20
 FX BND1      visit_1_7  1
 UP BND1      order_1_7  12
 FX BND1      visit_1_8  1
 UP BND1      order_1_8  12
 FX BND1      visit_1_9  1
 UP BND1      order_1_9  12
 FX BND1      visit_1_10  1
 UP BND1      order_1_10  12
 UP BND1      visit_1_14  1
 UP BND1      order_1_14  12
 UP BND1      visit_1_15  1
 UP BND1      order_1_15  12
 UP BND1      visit_1_16  1
 UP BND1      order_1_16  12
 UP BND1      visit_1_17  1
 UP BND1      order_1_17  12
 UP BND1      visit_1_18  1
 UP BND1      order_1_18  12
 UP BND1      visit_1_19  1
 UP BND1      order_1_19  12
 UP BND1      visit_1_20  1
 UP BND1      order_1_20  12
 UP BND1      visit_1_21  1
 UP BND1      order_1_21  12
 BV BND1      arc_1_0_0
 FX BND1      load_1_0_0  0
 BV BND1      arc_1_0_7
 FX BND1      load_1_0_7  0
 BV BND1      arc_1_0_8
 FX BND1      load_1_0_8  0
 BV BND1      arc_1_0_9
 FX BND1      load_1_0_9  0
 BV BND1      arc_1_0_10
 FX BND1      load_1_0_10  0
 BV BND1      arc_1_0_14
 FX BND1      load_1_0_14  0
 BV BND1      arc_1_0_15
 FX BND1      load_1_0_15  0
 BV BND1      arc_1_0_16
 FX BND1      load_1_0_16  0
 BV BND1      arc_1_0_17
 FX BND1      load_1_0_17  0
 BV BND1      arc_1_0_18
 FX BND1      load_1_0_18  0
 BV BND1      arc_1_0_19
 FX BND1      load_1_0_19  0
 BV BND1      arc_1_0_20
 FX BND1      load_1_0_20  0
 BV BND1      arc_1_0_21
 FX BND1      load_1_0_21  0
 BV BND1      arc_1_7_0
 UP BND1      load_1_7_0  25
 BV BND1      arc_1_7_8
 UP BND1      load_1_7_8  25
 BV BND1      arc_1_7_9
 UP BND1      load_1_7_9  25
 BV BND1      arc_1_7_10
 UP BND1      load_1_7_10  25
 BV BND1      arc_1_7_14
 UP BND1      load_1_7_14  25
 BV BND1      arc_1_7_15
 UP BND1      load_1_7_15  25
 BV BND1      arc_1_7_16
 UP BND1      load_1_7_16  25
 BV BND1      arc_1_7_17
 UP BND1      load_1_7_17  25
 BV BND1      arc_1_7_18
 UP BND1      load_1_7_18  25
 BV BND1      arc_1_7_19
 UP BND1      load_1_7_19  25
 BV BND1      arc_1_7_20
 UP BND1      load_1_7_20  25
 BV BND1      arc_1_7_21
 UP BND1      load_1_7_21  25
 BV BND1      arc_1_8_0
 UP BND1      load_1_8_0  25
 BV BND1      arc_1_8_7
 UP BND1      load_1_8_7  25
 BV BND1      arc_1_8_9
 UP BND1      load_1_8_9  25
 BV BND1      arc_1_8_10
 UP BND1      load_1_8_10  25
 BV BND1      arc_1_8_14
 UP BND1      load_1_8_14  25
 BV BND1      arc_1_8_15
 UP BND1      load_1_8_15  25
 BV BND1      arc_1_8_16
 UP BND1      load_1_8_16  25
 BV BND1      arc_1_8_17
 UP BND1      load_1_8_17  25
 BV BND1      arc_1_8_18
 UP BND1      load_1_8_18  25
 BV BND1      arc_1_8_19
 UP BND1      load_1_8_19  25
 BV BND1      arc_1_8_20
 UP BND1      load_1_8_20  25
 BV BND1      arc_1_8_21
 UP BND1      load_1_8_21  25
 BV BND1      arc_1_9_0
 UP BND1      load_1_9_0  25
 BV BND1      arc_1_9_7
 UP BND1      load_1_9_7  25
 BV BND1      arc_1_9_8
 UP BND1      load_1_9_8  25
 BV BND1      arc_1_9_10
 UP BND1      load_1_9_10  25
 BV BND1      arc_1_9_14
 UP BND1      load_1_9_14  25
 BV BND1      arc_1_9_15
 UP BND1      load_1_9_15  25
 BV BND1      arc_1_9_16
 UP BND1      load_1_9_16  25
 BV BND1      arc_1_9_17
 UP BND1      load_1_9_17  25
 BV BND1      arc_1_9_18
 UP BND1      load_1_9_18  25
 BV BND1      arc_1_9_19
 UP BND1      load_1_9_19  25
 BV BND1      arc_1_9_20
 UP BND1      load_1_9_20  25
 BV BND1      arc_1_9_21
 UP BND1      load_1_9_21  25
 BV BND1      arc_1_10_0
 UP BND1      load_1_10_0  25
 BV BND1      arc_1_10_7
 UP BND1      load_1_10_7  25
 BV BND1      arc_1_10_8
 UP BND1      load_1_10_8  25
 BV BND1      arc_1_10_9
 UP BND1      load_1_10_9  25
 BV BND1      arc_1_10_14
 UP BND1      load_1_10_14  25
 BV BND1      arc_1_10_15
 UP BND1      load_1_10_15  25
 BV BND1      arc_1_10_16
 UP BND1      load_1_10_16  25
 BV BND1      arc_1_10_17
 UP BND1      load_1_10_17  25
 BV BND1      arc_1_10_18
 UP BND1      load_1_10_18  25
 BV BND1      arc_1_10_19
 UP BND1      load_1_10_19  25
 BV BND1      arc_1_10_20
 UP BND1      load_1_10_20  25
 BV BND1      arc_1_10_21
 UP BND1      load_1_10_21  25
 BV BND1      arc_1_14_0
 UP BND1      load_1_14_0  25
 BV BND1      arc_1_14_7
 UP BND1      load_1_14_7  25
 BV BND1      arc_1_14_8
 UP BND1      load_1_14_8  25
 BV BND1      arc_1_14_9
 UP BND1      load_1_14_9  25
 BV BND1      arc_1_14_10
 UP BND1      load_1_14_10  25
 BV BND1      arc_1_14_15
 UP BND1      load_1_14_15  25
 BV BND1      arc_1_14_16
 UP BND1      load_1_14_16  25
 BV BND1      arc_1_14_17
 UP BND1      load_1_14_17  25
 BV BND1      arc_1_14_18
 UP BND1      load_1_14_18  25
 BV BND1      arc_1_14_19
 UP BND1      load_1_14_19  25
 BV BND1      arc_1_14_20
 UP BND1      load_1_14_20  25
 BV BND1      arc_1_14_21
 UP BND1      load_1_14_21  25
 BV BND1      arc_1_15_0
 UP BND1      load_1_15_0  25
 BV BND1      arc_1_15_7
 UP BND1      load_1_15_7  25
 BV BND1      arc_1_15_8
 UP BND1      load_1_15_8  25
 BV BND1      arc_1_15_9
 UP BND1      load_1_15_9  25
 BV BND1      arc_1_15_10
 UP BND1      load_1_15_10  25
 BV BND1      arc_1_15_14
 UP BND1      load_1_15_14  25
 BV BND1      arc_1_15_16
 UP BND1      load_1_15_16  25
 BV BND1      arc_1_15_17
 UP BND1      load_1_15_17  25
 BV BND1      arc_1_15_18
 UP BND1      load_1_15_18  25
 BV BND1      arc_1_15_19
 UP BND1      load_1_15_19  25
 BV BND1      arc_1_15_20
 UP BND1      load_1_15_20  25
 BV BND1      arc_1_15_21
 UP BND1      load_1_15_21  25
 BV BND1      arc_1_16_0
 UP BND1      load_1_16_0  25
 BV BND1      arc_1_16_7
 UP BND1      load_1_16_7  25
 BV BND1      arc_1_16_8
 UP BND1      load_1_16_8  25
 BV BND1      arc_1_16_9
 UP BND1      load_1_16_9  25
 BV BND1      arc_1_16_10
 UP BND1      load_1_16_10  25
 BV BND1      arc_1_16_14
 UP BND1      load_1_16_14  25
 BV BND1      arc_1_16_15
 UP BND1      load_1_16_15  25
 BV BND1      arc_1_16_17
 UP BND1      load_1_16_17  25
 BV BND1      arc_1_16_18
 UP BND1      load_1_16_18  25
 BV BND1      arc_1_16_19
 UP BND1      load_1_16_19  25
 BV BND1      arc_1_16_20
 UP BND1      load_1_16_20  25
 BV BND1      arc_1_16_21
 UP BND1      load_1_16_21  25
 BV BND1      arc_1_17_0
 UP BND1      load_1_17_0  25
 BV BND1      arc_1_17_7
 UP BND1      load_1_17_7  25
 BV BND1      arc_1_17_8
 UP BND1      load_1_17_8  25
 BV BND1      arc_1_17_9
 UP BND1      load_1_17_9  25
 BV BND1      arc_1_17_10
 UP BND1      load_1_17_10  25
 BV BND1      arc_1_17_14
 UP BND1      load_1_17_14  25
 BV BND1      arc_1_17_15
 UP BND1      load_1_17_15  25
 BV BND1      arc_1_17_16
 UP BND1      load_1_17_16  25
 BV BND1      arc_1_17_18
 UP BND1      load_1_17_18  25
 BV BND1      arc_1_17_19
 UP BND1      load_1_17_19  25
 BV BND1      arc_1_17_20
 UP BND1      load_1_17_20  25
 BV BND1      arc_1_17_21
 UP BND1      load_1_17_21  25
 BV BND1      arc_1_18_0
 UP BND1      load_1_18_0  25
 BV BND1      arc_1_18_7
 UP BND1      load_1_18_7  25
 BV BND1      arc_1_18_8
 UP BND1      load_1_18_8  25
 BV BND1      arc_1_18_9
 UP BND1      load_1_18_9  25
 BV BND1      arc_1_18_10
 UP BND1      load_1_18_10  25
 BV BND1      arc_1_18_14
 UP BND1      load_1_18_14  25
 BV BND1      arc_1_18_15
 UP BND1      load_1_18_15  25
 BV BND1      arc_1_18_16
 UP BND1      load_1_18_16  25
 BV BND1      arc_1_18_17
 UP BND1      load_1_18_17  25
 BV BND1      arc_1_18_19
 UP BND1      load_1_18_19  25
 BV BND1      arc_1_18_20
 UP BND1      load_1_18_20  25
 BV BND1      arc_1_18_21
 UP BND1      load_1_18_21  25
 BV BND1      arc_1_19_0
 UP BND1      load_1_19_0  25
 BV BND1      arc_1_19_7
 UP BND1      load_1_19_7  25
 BV BND1      arc_1_19_8
 UP BND1      load_1_19_8  25
 BV BND1      arc_1_19_9
 UP BND1      load_1_19_9  25
 BV BND1      arc_1_19_10
 UP BND1      load_1_19_10  25
 BV BND1      arc_1_19_14
 UP BND1      load_1_19_14  25
 BV BND1      arc_1_19_15
 UP BND1      load_1_19_15  25
 BV BND1      arc_1_19_16
 UP BND1      load_1_19_16  25
 BV BND1      arc_1_19_17
 UP BND1      load_1_19_17  25
 BV BND1      arc_1_19_18
 UP BND1      load_1_19_18  25
 BV BND1      arc_1_19_20
 UP BND1      load_1_19_20  25
 BV BND1      arc_1_19_21
 UP BND1      load_1_19_21  25
 BV BND1      arc_1_20_0
 UP BND1      load_1_20_0  25
 BV BND1      arc_1_20_7
 UP BND1      load_1_20_7  25
 BV BND1      arc_1_20_8
 UP BND1      load_1_20_8  25
 BV BND1      arc_1_20_9
 UP BND1      load_1_20_9  25
 BV BND1      arc_1_20_10
 UP BND1      load_1_20_10  25
 BV BND1      arc_1_20_14
 UP BND1      load_1_20_14  25
 BV BND1      arc_1_20_15
 UP BND1      load_1_20_15  25
 BV BND1      arc_1_20_16
 UP BND1      load_1_20_16  25
 BV BND1      arc_1_20_17
 UP BND1      load_1_20_17  25
 BV BND1      arc_1_20_18
 UP BND1      load_1_20_18  25
 BV BND1      arc_1_20_19
 UP BND1      load_1_20_19  25
 BV BND1      arc_1_20_21
 UP BND1      load_1_20_21  25
 BV BND1      arc_1_21_0
 UP BND1      load_1_21_0  25
 BV BND1      arc_1_21_7
 UP BND1      load_1_21_7  25
 BV BND1      arc_1_21_8
 UP BND1      load_1_21_8  25
 BV BND1      arc_1_21_9
 UP BND1      load_1_21_9  25
 BV BND1      arc_1_21_10
 UP BND1      load_1_21_10  25
 BV BND1      arc_1_21_14
 UP BND1      load_1_21_14  25
 BV BND1      arc_1_21_15
 UP BND1      load_1_21_15  25
 BV BND1      arc_1_21_16
 UP BND1      load_1_21_16  25
 BV BND1      arc_1_21_17
 UP BND1      load_1_21_17  25
 BV BND1      arc_1_21_18
 UP BND1      load_1_21_18  25
 BV BND1      arc_1_21_19
 UP BND1      load_1_21_19  25
 BV BND1      arc_1_21_20
 UP BND1      load_1_21_20  25
 FX BND1      visit_2_11  1
 UP BND1      order_2_11  11
 FX BND1      visit_2_12  1
 UP BND1      order_2_12  11
 FX BND1      visit_2_13  1
 UP BND1      order_2_13  11
 UP BND1      visit_2_14  1
 UP BND1      order_2_14  11
 UP BND1      visit_2_15  1
 UP BND1      order_2_15  11
 UP BND1      visit_2_16  1
 UP BND1      order_2_16  11
 UP BND1      visit_2_17  1
 UP BND1      order_2_17  11
 UP BND1      visit_2_18  1
 UP BND1      order_2_18  11
 UP BND1      visit_2_19  1
 UP BND1      order_2_19  11
 UP BND1      visit_2_20  1
 UP BND1      order_2_20  11
 UP BND1      visit_2_21  1
 UP BND1      order_2_21  11
 BV BND1      arc_2_0_0
 FX BND1      load_2_0_0  0
 BV BND1      arc_2_0_11
 FX BND1      load_2_0_11  0
 BV BND1      arc_2_0_12
 FX BND1      load_2_0_12  0
 BV BND1      arc_2_0_13
 FX BND1      load_2_0_13  0
 BV BND1      arc_2_0_14
 FX BND1      load_2_0_14  0
 BV BND1      arc_2_0_15
 FX BND1      load_2_0_15  0
 BV BND1      arc_2_0_16
 FX BND1      load_2_0_16  0
 BV BND1      arc_2_0_17
 FX BND1      load_2_0_17  0
 BV BND1      arc_2_0_18
 FX BND1      load_2_0_18  0
 BV BND1      arc_2_0_19
 FX BND1      load_2_0_19  0
 BV BND1      arc_2_0_20
 FX BND1      load_2_0_20  0
 BV BND1      arc_2_0_21
 FX BND1      load_2_0_21  0
 BV BND1      arc_2_11_0
 UP BND1      load_2_11_0  30
 BV BND1      arc_2_11_12
 UP BND1      load_2_11_12  30
 BV BND1      arc_2_11_13
 UP BND1      load_2_11_13  30
 BV BND1      arc_2_11_14
 UP BND1      load_2_11_14  30
 BV BND1      arc_2_11_15
 UP BND1      load_2_11_15  30
 BV BND1      arc_2_11_16
 UP BND1      load_2_11_16  30
 BV BND1      arc_2_11_17
 UP BND1      load_2_11_17  30
 BV BND1      arc_2_11_18
 UP BND1      load_2_11_18  30
 BV BND1      arc_2_11_19
 UP BND1      load_2_11_19  30
 BV BND1      arc_2_11_20
 UP BND1      load_2_11_20  30
 BV BND1      arc_2_11_21
 UP BND1      load_2_11_21  30
 BV BND1      arc_2_12_0
 UP BND1      load_2_12_0  30
 BV BND1      arc_2_12_11
 UP BND1      load_2_12_11  30
 BV BND1      arc_2_12_13
 UP BND1      load_2_12_13  30
 BV BND1      arc_2_12_14
 UP BND1      load_2_12_14  30
 BV BND1      arc_2_12_15
 UP BND1      load_2_12_15  30
 BV BND1      arc_2_12_16
 UP BND1      load_2_12_16  30
 BV BND1      arc_2_12_17
 UP BND1      load_2_12_17  30
 BV BND1      arc_2_12_18
 UP BND1      load_2_12_18  30
 BV BND1      arc_2_12_19
 UP BND1      load_2_12_19  30
 BV BND1      arc_2_12_20
 UP BND1      load_2_12_20  30
 BV BND1      arc_2_12_21
 UP BND1      load_2_12_21  30
 BV BND1      arc_2_13_0
 UP BND1      load_2_13_0  30
 BV BND1      arc_2_13_11
 UP BND1      load_2_13_11  30
 BV BND1      arc_2_13_12
 UP BND1      load_2_13_12  30
 BV BND1      arc_2_13_14
 UP BND1      load_2_13_14  30
 BV BND1      arc_2_13_15
 UP BND1      load_2_13_15  30
 BV BND1      arc_2_13_16
 UP BND1      load_2_13_16  30
 BV BND1      arc_2_13_17
 UP BND1      load_2_13_17  30
 BV BND1      arc_2_13_18
 UP BND1      load_2_13_18  30
 BV BND1      arc_2_13_19
 UP BND1      load_2_13_19  30
 BV BND1      arc_2_13_20
 UP BND1      load_2_13_20  30
 BV BND1      arc_2_13_21
 UP BND1      load_2_13_21  30
 BV BND1      arc_2_14_0
 UP BND1      load_2_14_0  30
 BV BND1      arc_2_14_11
 UP BND1      load_2_14_11  30
 BV BND1      arc_2_14_12
 UP BND1      load_2_14_12  30
 BV BND1      arc_2_14_13
 UP BND1      load_2_14_13  30
 BV BND1      arc_2_14_15
 UP BND1      load_2_14_15  30
 BV BND1      arc_2_14_16
 UP BND1      load_2_14_16  30
 BV BND1      arc_2_14_17
 UP BND1      load_2_14_17  30
 BV BND1      arc_2_14_18
 UP BND1      load_2_14_18  30
 BV BND1      arc_2_14_19
 UP BND1      load_2_14_19  30
 BV BND1      arc_2_14_20
 UP BND1      load_2_14_20  30
 BV BND1      arc_2_14_21
 UP BND1      load_2_14_21  30
 BV BND1      arc_2_15_0
 UP BND1      load_2_15_0  30
 BV BND1      arc_2_15_11
 UP BND1      load_2_15_11  30
 BV BND1      arc_2_15_12
 UP BND1      load_2_15_12  30
 BV BND1      arc_2_15_13
 UP BND1      load_2_15_13  30
 BV BND1      arc_2_15_14
 UP BND1      load_2_15_14  30
 BV BND1      arc_2_15_16
 UP BND1      load_2_15_16  30
 BV BND1      arc_2_15_17
 UP BND1      load_2_15_17  30
 BV BND1      arc_2_15_18
 UP BND1      load_2_15_18  30
 BV BND1      arc_2_15_19
 UP BND1      load_2_15_19  30
 BV BND1      arc_2_15_20
 UP BND1      load_2_15_20  30
 BV BND1      arc_2_15_21
 UP BND1      load_2_15_21  30
 BV BND1      arc_2_16_0
 UP BND1      load_2_16_0  30
 BV BND1      arc_2_16_11
 UP BND1      load_2_16_11  30
 BV BND1      arc_2_16_12
 UP BND1      load_2_16_12  30
 BV BND1      arc_2_16_13
 UP BND1      load_2_16_13  30
 BV BND1      arc_2_16_14
 UP BND1      load_2_16_14  30
 BV BND1      arc_2_16_15
 UP BND1      load_2_16_15  30
 BV BND1      arc_2_16_17
 UP BND1      load_2_16_17  30
 BV BND1      arc_2_16_18
 UP BND1      load_2_16_18  30
 BV BND1      arc_2_16_19
 UP BND1      load_2_16_19  30
 BV BND1      arc_2_16_20
 UP BND1      load_2_16_20  30
 BV BND1      arc_2_16_21
 UP BND1      load_2_16_21  30
 BV BND1      arc_2_17_0
 UP BND1      load_2_17_0  30
 BV BND1      arc_2_17_11
 UP BND1      load_2_17_11  30
 BV BND1      arc_2_17_12
 UP BND1      load_2_17_12  30
 BV BND1      arc_2_17_13
 UP BND1      load_2_17_13  30
 BV BND1      arc_2_17_14
 UP BND1      load_2_17_14  30
 BV BND1      arc_2_17_15
 UP BND1      load_2_17_15  30
 BV BND1      arc_2_17_16
 UP BND1      load_2_17_16  30
 BV BND1      arc_2_17_18
 UP BND1      load_2_17_18  30
 BV BND1      arc_2_17_19
 UP BND1      load_2_17_19  30
 BV BND1      arc_2_17_20
 UP BND1      load_2_17_20  30
 BV BND1      arc_2_17_21
 UP BND1      load_2_17_21  30
 BV BND1      arc_2_18_0
 UP BND1      load_2_18_0  30
 BV BND1      arc_2_18_11
 UP BND1      load_2_18_11  30
 BV BND1      arc_2_18_12
 UP BND1      load_2_18_12  30
 BV BND1      arc_2_18_13
 UP BND1      load_2_18_13  30
 BV BND1      arc_2_18_14
 UP BND1      load_2_18_14  30
 BV BND1      arc_2_18_15
 UP BND1      load_2_18_15  30
 BV BND1      arc_2_18_16
 UP BND1      load_2_18_16  30
 BV BND1      arc_2_18_17
 UP BND1      load_2_18_17  30
 BV BND1      arc_2_18_19
 UP BND1      load_2_18_19  30
 BV BND1      arc_2_18_20
 UP BND1      load_2_18_20  30
 BV BND1      arc_2_18_21
 UP BND1      load_2_18_21  30
 BV BND1      arc_2_19_0
 UP BND1      load_2_19_0  30
 BV BND1      arc_2_19_11
 UP BND1      load_2_19_11  30
 BV BND1      arc_2_19_12
 UP BND1      load_2_19_12  30
 BV BND1      arc_2_19_13
 UP BND1      load_2_19_13  30
 BV BND1      arc_2_19_14
 UP BND1      load_2_19_14  30
 BV BND1      arc_2_19_15
 UP BND1      load_2_19_15  30
 BV BND1      arc_2_19_16
 UP BND1      load_2_19_16  30
 BV BND1      arc_2_19_17
 UP BND1      load_2_19_17  30
 BV BND1      arc_2_19_18
 UP BND1      load_2_19_18  30
 BV BND1      arc_2_19_20
 UP BND1      load_2_19_20  30
 BV BND1      arc_2_19_21
 UP BND1      load_2_19_21  30
 BV BND1      arc_2_20_0
 UP BND1      load_2_20_0  30
 BV BND1      arc_2_20_11
 UP BND1      load_2_20_11  30
 BV BND1      arc_2_20_12
 UP BND1      load_2_20_12  30
 BV BND1      arc_2_20_13
 UP BND1      load_2_20_13  30
 BV BND1      arc_2_20_14
 UP BND1      load_2_20_14  30
 BV BND1      arc_2_20_15
 UP BND1      load_2_20_15  30
 BV BND1      arc_2_20_16
 UP BND1      load_2_20_16  30
 BV BND1      arc_2_20_17
 UP BND1      load_2_20_17  30
 BV BND1      arc_2_20_18
 UP BND1      load_2_20_18  30
 BV BND1      arc_2_20_19
 UP BND1      load_2_20_19  30
 BV BND1      arc_2_20_21
 UP BND1      load_2_20_21  30
 BV BND1      arc_2_21_0
 UP BND1      load_2_21_0  30
 BV BND1      arc_2_21_11
 UP BND1      load_2_21_11  30
 BV BND1      arc_2_21_12
 UP BND1      load_2_21_12  30
 BV BND1      arc_2_21_13
 UP BND1      load_2_21_13  30
 BV BND1      arc_2_21_14
 UP BND1      load_2_21_14  30
 BV BND1      arc_2_21_15
 UP BND1      load_2_21_15  30
 BV BND1      arc_2_21_16
 UP BND1      load_2_21_16  30
 BV BND1      arc_2_21_17
 UP BND1      load_2_21_17  30
 BV BND1      arc_2_21_18
 UP BND1      load_2_21_18  30
 BV BND1      arc_2_21_19
 UP BND1      load_2_21_19  30
 BV BND1      arc_2_21_20
 UP BND1      load_2_21_20  30
ENDATA
