* Signature: 0x13c9658dcb085fc0
NAME R160_physical_neighborhood
ROWS
 N  OBJ
 G  product_lb_0
 L  product_ub_1
 G  product_lb_2
 L  product_ub_3
 G  product_lb_4
 L  product_ub_5
 G  product_lb_6
 L  product_ub_7
 G  product_lb_8
 L  product_ub_9
 G  product_lb_10
 L  product_ub_11
 G  product_lb_12
 L  product_ub_13
 G  product_lb_14
 L  product_ub_15
 G  product_lb_16
 L  product_ub_17
 G  product_lb_18
 L  product_ub_19
 G  product_lb_20
 L  product_ub_21
 G  product_lb_22
 L  product_ub_23
 G  product_lb_24
 L  product_ub_25
 G  product_lb_26
 L  product_ub_27
 G  product_lb_28
 L  product_ub_29
 G  product_lb_30
 L  product_ub_31
 G  product_lb_32
 L  product_ub_33
 G  product_lb_34
 L  product_ub_35
 E  onehot_3_36
 E  normalized_mass_3_37
 E  normalized_ratio_3_38
 G  product_lb_39
 L  product_ub_40
 G  product_lb_41
 L  product_ub_42
 G  product_lb_43
 L  product_ub_44
 G  product_lb_45
 L  product_ub_46
 G  product_lb_47
 L  product_ub_48
 G  product_lb_49
 L  product_ub_50
 G  product_lb_51
 L  product_ub_52
 G  product_lb_53
 L  product_ub_54
 G  product_lb_55
 L  product_ub_56
 G  product_lb_57
 L  product_ub_58
 G  product_lb_59
 L  product_ub_60
 G  product_lb_61
 L  product_ub_62
 G  product_lb_63
 L  product_ub_64
 G  product_lb_65
 L  product_ub_66
 G  product_lb_67
 L  product_ub_68
 G  product_lb_69
 L  product_ub_70
 G  product_lb_71
 L  product_ub_72
 G  product_lb_73
 L  product_ub_74
 G  product_lb_75
 L  product_ub_76
 G  product_lb_77
 L  product_ub_78
 E  onehot_1_79
 E  normalized_mass_1_80
 E  normalized_ratio_1_81
 G  product_lb_82
 L  product_ub_83
 G  product_lb_84
 L  product_ub_85
 G  product_lb_86
 L  product_ub_87
 G  product_lb_88
 L  product_ub_89
 G  product_lb_90
 L  product_ub_91
 G  product_lb_92
 L  product_ub_93
 G  product_lb_94
 L  product_ub_95
 G  product_lb_96
 L  product_ub_97
 G  product_lb_98
 L  product_ub_99
 G  product_lb_100
 L  product_ub_101
 G  product_lb_102
 L  product_ub_103
 G  product_lb_104
 L  product_ub_105
 G  product_lb_106
 L  product_ub_107
 E  onehot_31_108
 E  normalized_mass_31_109
 E  normalized_ratio_31_110
 G  product_lb_111
 L  product_ub_112
 G  product_lb_113
 L  product_ub_114
 G  product_lb_115
 L  product_ub_116
 G  product_lb_117
 L  product_ub_118
 G  product_lb_119
 L  product_ub_120
 G  product_lb_121
 L  product_ub_122
 G  product_lb_123
 L  product_ub_124
 G  product_lb_125
 L  product_ub_126
 G  product_lb_127
 L  product_ub_128
 G  product_lb_129
 L  product_ub_130
 G  product_lb_131
 L  product_ub_132
 G  product_lb_133
 L  product_ub_134
 G  product_lb_135
 L  product_ub_136
 G  product_lb_137
 L  product_ub_138
 G  product_lb_139
 L  product_ub_140
 G  product_lb_141
 L  product_ub_142
 G  product_lb_143
 L  product_ub_144
 G  product_lb_145
 L  product_ub_146
 E  onehot_7_147
 E  normalized_mass_7_148
 E  normalized_ratio_7_149
 G  product_lb_150
 L  product_ub_151
 G  product_lb_152
 L  product_ub_153
 G  product_lb_154
 L  product_ub_155
 G  product_lb_156
 L  product_ub_157
 G  product_lb_158
 L  product_ub_159
 G  product_lb_160
 L  product_ub_161
 G  product_lb_162
 L  product_ub_163
 G  product_lb_164
 L  product_ub_165
 G  product_lb_166
 L  product_ub_167
 G  product_lb_168
 L  product_ub_169
 G  product_lb_170
 L  product_ub_171
 G  product_lb_172
 L  product_ub_173
 G  product_lb_174
 L  product_ub_175
 E  onehot_32_176
 E  normalized_mass_32_177
 E  normalized_ratio_32_178
 G  product_lb_179
 L  product_ub_180
 G  product_lb_181
 L  product_ub_182
 G  product_lb_183
 L  product_ub_184
 G  product_lb_185
 L  product_ub_186
 G  product_lb_187
 L  product_ub_188
 G  product_lb_189
 L  product_ub_190
 G  product_lb_191
 L  product_ub_192
 G  product_lb_193
 L  product_ub_194
 G  product_lb_195
 L  product_ub_196
 G  product_lb_197
 L  product_ub_198
 G  product_lb_199
 L  product_ub_200
 G  product_lb_201
 L  product_ub_202
 G  product_lb_203
 L  product_ub_204
 G  product_lb_205
 L  product_ub_206
 G  product_lb_207
 L  product_ub_208
 G  product_lb_209
 L  product_ub_210
 E  onehot_4_211
 E  normalized_mass_4_212
 E  normalized_ratio_4_213
 G  product_lb_214
 L  product_ub_215
 G  product_lb_216
 L  product_ub_217
 G  product_lb_218
 L  product_ub_219
 G  product_lb_220
 L  product_ub_221
 G  product_lb_222
 L  product_ub_223
 G  product_lb_224
 L  product_ub_225
 G  product_lb_226
 L  product_ub_227
 G  product_lb_228
 L  product_ub_229
 G  product_lb_230
 L  product_ub_231
 E  onehot_19_232
 E  normalized_mass_19_233
 E  normalized_ratio_19_234
 G  product_lb_235
 L  product_ub_236
 G  product_lb_237
 L  product_ub_238
 G  product_lb_239
 L  product_ub_240
 G  product_lb_241
 L  product_ub_242
 G  product_lb_243
 L  product_ub_244
 G  product_lb_245
 L  product_ub_246
 G  product_lb_247
 L  product_ub_248
 G  product_lb_249
 L  product_ub_250
 G  product_lb_251
 L  product_ub_252
 G  product_lb_253
 L  product_ub_254
 G  product_lb_255
 L  product_ub_256
 G  product_lb_257
 L  product_ub_258
 G  product_lb_259
 L  product_ub_260
 G  product_lb_261
 L  product_ub_262
 G  product_lb_263
 L  product_ub_264
 G  product_lb_265
 L  product_ub_266
 G  product_lb_267
 L  product_ub_268
 G  product_lb_269
 L  product_ub_270
 G  product_lb_271
 L  product_ub_272
 G  product_lb_273
 L  product_ub_274
 E  onehot_10_275
 E  normalized_mass_10_276
 E  normalized_ratio_10_277
 G  stock_lb_278
 L  stock_ub_279
 L  parent_nonstrict_scope_280
 G  block_pair_pos_281
 G  block_pair_neg_282
 G  block_pair_pos_283
 G  block_pair_neg_284
 G  block_pair_pos_285
 G  block_pair_neg_286
 G  block_pair_pos_287
 G  block_pair_neg_288
 G  block_pair_pos_289
 G  block_pair_neg_290
 G  block_pair_pos_291
 G  block_pair_neg_292
 G  block_pair_pos_293
 G  block_pair_neg_294
 G  block_pair_pos_295
 G  block_pair_neg_296
 G  block_pair_pos_297
 G  block_pair_neg_298
 G  block_pair_pos_299
 G  block_pair_neg_300
 G  block_pair_pos_301
 G  block_pair_neg_302
 G  block_pair_pos_303
 G  block_pair_neg_304
 G  block_pair_pos_305
 G  block_pair_neg_306
 G  block_pair_pos_307
 G  block_pair_neg_308
 G  block_pair_pos_309
 G  block_pair_neg_310
 G  block_pair_pos_311
 G  block_pair_neg_312
 G  block_pair_pos_313
 G  block_pair_neg_314
 G  block_pair_pos_315
 G  block_pair_neg_316
 G  block_pair_pos_317
 G  block_pair_neg_318
 G  block_pair_pos_319
 G  block_pair_neg_320
 G  block_pair_pos_321
 G  block_pair_neg_322
 G  block_pair_pos_323
 G  block_pair_neg_324
 G  block_pair_pos_325
 G  block_pair_neg_326
 G  block_pair_pos_327
 G  block_pair_neg_328
 G  block_pair_pos_329
 G  block_pair_neg_330
 G  block_pair_pos_331
 G  block_pair_neg_332
 G  block_pair_pos_333
 G  block_pair_neg_334
 G  block_pair_pos_335
 G  block_pair_neg_336
 E  normalization_337
 G  full_original_Gini_338
 E  unique_nonzero_owner_339
 E  unique_nonzero_owner_340
 E  unique_nonzero_owner_341
 E  unique_nonzero_owner_342
 E  unique_nonzero_owner_343
 E  unique_nonzero_owner_344
 E  unique_nonzero_owner_345
 E  unique_nonzero_owner_346
 E  unique_nonzero_owner_347
 E  unique_nonzero_owner_348
 E  unique_nonzero_owner_349
 E  unique_nonzero_owner_350
 E  unique_nonzero_owner_351
 E  unique_nonzero_owner_352
 E  unique_nonzero_owner_353
 E  unique_nonzero_owner_354
 E  unique_nonzero_owner_355
 E  unique_nonzero_owner_356
 E  unique_nonzero_owner_357
 E  unique_nonzero_owner_358
 E  unique_nonzero_owner_359
 E  unique_nonzero_owner_360
 E  unique_nonzero_owner_361
 E  unique_nonzero_owner_362
 E  unique_nonzero_owner_363
 E  unique_nonzero_owner_364
 E  unique_nonzero_owner_365
 E  unique_nonzero_owner_366
 E  unique_nonzero_owner_367
 E  unique_nonzero_owner_368
 E  unique_nonzero_owner_369
 E  unique_nonzero_owner_370
 E  unique_nonzero_owner_371
 E  unique_nonzero_owner_372
 E  unique_nonzero_owner_373
 E  unique_nonzero_owner_374
 E  unique_nonzero_owner_375
 E  unique_nonzero_owner_376
 E  unique_nonzero_owner_377
 E  unique_nonzero_owner_378
 E  unique_nonzero_owner_379
 E  unique_nonzero_owner_380
 E  unique_nonzero_owner_381
 E  unique_nonzero_owner_382
 E  unique_nonzero_owner_383
 E  unique_nonzero_owner_384
 E  unique_nonzero_owner_385
 E  unique_nonzero_owner_386
 E  unique_nonzero_owner_387
 E  unique_nonzero_owner_388
 E  unique_nonzero_owner_389
 E  unique_nonzero_owner_390
 E  unique_nonzero_owner_391
 E  unique_nonzero_owner_392
 E  unique_nonzero_owner_393
 E  unique_nonzero_owner_394
 E  unique_nonzero_owner_395
 E  unique_nonzero_owner_396
 E  unique_nonzero_owner_397
 E  unique_nonzero_owner_398
 E  unique_nonzero_owner_399
 E  unique_nonzero_owner_400
 E  unique_nonzero_owner_401
 E  unique_nonzero_owner_402
 E  unique_nonzero_owner_403
 E  unique_nonzero_owner_404
 E  unique_nonzero_owner_405
 E  unique_nonzero_owner_406
 E  unique_nonzero_owner_407
 E  unique_nonzero_owner_408
 E  unique_nonzero_owner_409
 E  unique_nonzero_owner_410
 E  unique_nonzero_owner_411
 E  unique_nonzero_owner_412
 E  unique_nonzero_owner_413
 E  unique_nonzero_owner_414
 E  unique_nonzero_owner_415
 E  unique_nonzero_owner_416
 E  unique_nonzero_owner_417
 E  unique_nonzero_owner_418
 E  unique_nonzero_owner_419
 E  unique_nonzero_owner_420
 E  unique_nonzero_owner_421
 E  unique_nonzero_owner_422
 E  unique_nonzero_owner_423
 E  unique_nonzero_owner_424
 E  unique_nonzero_owner_425
 E  unique_nonzero_owner_426
 E  unique_nonzero_owner_427
 E  unique_nonzero_owner_428
 E  unique_nonzero_owner_429
 E  unique_nonzero_owner_430
 E  unique_nonzero_owner_431
 E  unique_nonzero_owner_432
 E  unique_nonzero_owner_433
 E  unique_nonzero_owner_434
 E  unique_nonzero_owner_435
 E  unique_nonzero_owner_436
 E  unique_nonzero_owner_437
 E  unique_nonzero_owner_438
 E  unique_nonzero_owner_439
 E  unique_nonzero_owner_440
 E  unique_nonzero_owner_441
 E  unique_nonzero_owner_442
 E  unique_nonzero_owner_443
 E  unique_nonzero_owner_444
 E  unique_nonzero_owner_445
 E  unique_nonzero_owner_446
 E  unique_nonzero_owner_447
 E  unique_nonzero_owner_448
 E  unique_nonzero_owner_449
 E  unique_nonzero_owner_450
 E  unique_nonzero_owner_451
 E  unique_nonzero_owner_452
 E  unique_nonzero_owner_453
 E  unique_nonzero_owner_454
 E  unique_nonzero_owner_455
 E  unique_nonzero_owner_456
 E  unique_nonzero_owner_457
 L  arc_capacity_458
 L  arc_capacity_459
 L  arc_capacity_460
 L  arc_capacity_461
 L  arc_capacity_462
 L  arc_capacity_463
 L  arc_capacity_464
 L  arc_capacity_465
 L  arc_capacity_466
 L  arc_capacity_467
 L  arc_capacity_468
 L  arc_capacity_469
 L  arc_capacity_470
 L  arc_capacity_471
 L  arc_capacity_472
 L  arc_capacity_473
 G  connected_order_arc_474
 L  arc_capacity_475
 G  connected_order_arc_476
 L  arc_capacity_477
 G  connected_order_arc_478
 L  arc_capacity_479
 G  connected_order_arc_480
 L  arc_capacity_481
 G  connected_order_arc_482
 L  arc_capacity_483
 G  connected_order_arc_484
 L  arc_capacity_485
 G  connected_order_arc_486
 L  arc_capacity_487
 G  connected_order_arc_488
 L  arc_capacity_489
 G  connected_order_arc_490
 L  arc_capacity_491
 G  connected_order_arc_492
 L  arc_capacity_493
 G  connected_order_arc_494
 L  arc_capacity_495
 G  connected_order_arc_496
 L  arc_capacity_497
 L  arc_capacity_498
 G  connected_order_arc_499
 L  arc_capacity_500
 G  connected_order_arc_501
 L  arc_capacity_502
 G  connected_order_arc_503
 L  arc_capacity_504
 G  connected_order_arc_505
 L  arc_capacity_506
 G  connected_order_arc_507
 L  arc_capacity_508
 G  connected_order_arc_509
 L  arc_capacity_510
 G  connected_order_arc_511
 L  arc_capacity_512
 G  connected_order_arc_513
 L  arc_capacity_514
 G  connected_order_arc_515
 L  arc_capacity_516
 G  connected_order_arc_517
 L  arc_capacity_518
 G  connected_order_arc_519
 L  arc_capacity_520
 G  connected_order_arc_521
 L  arc_capacity_522
 L  arc_capacity_523
 G  connected_order_arc_524
 L  arc_capacity_525
 G  connected_order_arc_526
 L  arc_capacity_527
 G  connected_order_arc_528
 L  arc_capacity_529
 G  connected_order_arc_530
 L  arc_capacity_531
 G  connected_order_arc_532
 L  arc_capacity_533
 G  connected_order_arc_534
 L  arc_capacity_535
 G  connected_order_arc_536
 L  arc_capacity_537
 G  connected_order_arc_538
 L  arc_capacity_539
 G  connected_order_arc_540
 L  arc_capacity_541
 G  connected_order_arc_542
 L  arc_capacity_543
 G  connected_order_arc_544
 L  arc_capacity_545
 G  connected_order_arc_546
 L  arc_capacity_547
 L  arc_capacity_548
 G  connected_order_arc_549
 L  arc_capacity_550
 G  connected_order_arc_551
 L  arc_capacity_552
 G  connected_order_arc_553
 L  arc_capacity_554
 G  connected_order_arc_555
 L  arc_capacity_556
 G  connected_order_arc_557
 L  arc_capacity_558
 G  connected_order_arc_559
 L  arc_capacity_560
 G  connected_order_arc_561
 L  arc_capacity_562
 G  connected_order_arc_563
 L  arc_capacity_564
 G  connected_order_arc_565
 L  arc_capacity_566
 G  connected_order_arc_567
 L  arc_capacity_568
 G  connected_order_arc_569
 L  arc_capacity_570
 G  connected_order_arc_571
 L  arc_capacity_572
 L  arc_capacity_573
 G  connected_order_arc_574
 L  arc_capacity_575
 G  connected_order_arc_576
 L  arc_capacity_577
 G  connected_order_arc_578
 L  arc_capacity_579
 G  connected_order_arc_580
 L  arc_capacity_581
 G  connected_order_arc_582
 L  arc_capacity_583
 G  connected_order_arc_584
 L  arc_capacity_585
 G  connected_order_arc_586
 L  arc_capacity_587
 G  connected_order_arc_588
 L  arc_capacity_589
 G  connected_order_arc_590
 L  arc_capacity_591
 G  connected_order_arc_592
 L  arc_capacity_593
 G  connected_order_arc_594
 L  arc_capacity_595
 G  connected_order_arc_596
 L  arc_capacity_597
 L  arc_capacity_598
 G  connected_order_arc_599
 L  arc_capacity_600
 G  connected_order_arc_601
 L  arc_capacity_602
 G  connected_order_arc_603
 L  arc_capacity_604
 G  connected_order_arc_605
 L  arc_capacity_606
 G  connected_order_arc_607
 L  arc_capacity_608
 G  connected_order_arc_609
 L  arc_capacity_610
 G  connected_order_arc_611
 L  arc_capacity_612
 G  connected_order_arc_613
 L  arc_capacity_614
 G  connected_order_arc_615
 L  arc_capacity_616
 G  connected_order_arc_617
 L  arc_capacity_618
 G  connected_order_arc_619
 L  arc_capacity_620
 G  connected_order_arc_621
 L  arc_capacity_622
 L  arc_capacity_623
 G  connected_order_arc_624
 L  arc_capacity_625
 G  connected_order_arc_626
 L  arc_capacity_627
 G  connected_order_arc_628
 L  arc_capacity_629
 G  connected_order_arc_630
 L  arc_capacity_631
 G  connected_order_arc_632
 L  arc_capacity_633
 G  connected_order_arc_634
 L  arc_capacity_635
 G  connected_order_arc_636
 L  arc_capacity_637
 G  connected_order_arc_638
 L  arc_capacity_639
 G  connected_order_arc_640
 L  arc_capacity_641
 G  connected_order_arc_642
 L  arc_capacity_643
 G  connected_order_arc_644
 L  arc_capacity_645
 G  connected_order_arc_646
 L  arc_capacity_647
 L  arc_capacity_648
 G  connected_order_arc_649
 L  arc_capacity_650
 G  connected_order_arc_651
 L  arc_capacity_652
 G  connected_order_arc_653
 L  arc_capacity_654
 G  connected_order_arc_655
 L  arc_capacity_656
 G  connected_order_arc_657
 L  arc_capacity_658
 G  connected_order_arc_659
 L  arc_capacity_660
 G  connected_order_arc_661
 L  arc_capacity_662
 G  connected_order_arc_663
 L  arc_capacity_664
 G  connected_order_arc_665
 L  arc_capacity_666
 G  connected_order_arc_667
 L  arc_capacity_668
 G  connected_order_arc_669
 L  arc_capacity_670
 G  connected_order_arc_671
 L  arc_capacity_672
 L  arc_capacity_673
 G  connected_order_arc_674
 L  arc_capacity_675
 G  connected_order_arc_676
 L  arc_capacity_677
 G  connected_order_arc_678
 L  arc_capacity_679
 G  connected_order_arc_680
 L  arc_capacity_681
 G  connected_order_arc_682
 L  arc_capacity_683
 G  connected_order_arc_684
 L  arc_capacity_685
 G  connected_order_arc_686
 L  arc_capacity_687
 G  connected_order_arc_688
 L  arc_capacity_689
 G  connected_order_arc_690
 L  arc_capacity_691
 G  connected_order_arc_692
 L  arc_capacity_693
 G  connected_order_arc_694
 L  arc_capacity_695
 G  connected_order_arc_696
 L  arc_capacity_697
 L  arc_capacity_698
 G  connected_order_arc_699
 L  arc_capacity_700
 G  connected_order_arc_701
 L  arc_capacity_702
 G  connected_order_arc_703
 L  arc_capacity_704
 G  connected_order_arc_705
 L  arc_capacity_706
 G  connected_order_arc_707
 L  arc_capacity_708
 G  connected_order_arc_709
 L  arc_capacity_710
 G  connected_order_arc_711
 L  arc_capacity_712
 G  connected_order_arc_713
 L  arc_capacity_714
 G  connected_order_arc_715
 L  arc_capacity_716
 G  connected_order_arc_717
 L  arc_capacity_718
 G  connected_order_arc_719
 L  arc_capacity_720
 G  connected_order_arc_721
 L  arc_capacity_722
 L  arc_capacity_723
 G  connected_order_arc_724
 L  arc_capacity_725
 G  connected_order_arc_726
 L  arc_capacity_727
 G  connected_order_arc_728
 L  arc_capacity_729
 G  connected_order_arc_730
 L  arc_capacity_731
 G  connected_order_arc_732
 L  arc_capacity_733
 G  connected_order_arc_734
 L  arc_capacity_735
 G  connected_order_arc_736
 L  arc_capacity_737
 G  connected_order_arc_738
 L  arc_capacity_739
 G  connected_order_arc_740
 L  arc_capacity_741
 G  connected_order_arc_742
 L  arc_capacity_743
 G  connected_order_arc_744
 L  arc_capacity_745
 G  connected_order_arc_746
 L  arc_capacity_747
 L  arc_capacity_748
 G  connected_order_arc_749
 L  arc_capacity_750
 G  connected_order_arc_751
 L  arc_capacity_752
 G  connected_order_arc_753
 L  arc_capacity_754
 G  connected_order_arc_755
 L  arc_capacity_756
 G  connected_order_arc_757
 L  arc_capacity_758
 G  connected_order_arc_759
 L  arc_capacity_760
 G  connected_order_arc_761
 L  arc_capacity_762
 G  connected_order_arc_763
 L  arc_capacity_764
 G  connected_order_arc_765
 L  arc_capacity_766
 G  connected_order_arc_767
 L  arc_capacity_768
 G  connected_order_arc_769
 L  arc_capacity_770
 G  connected_order_arc_771
 L  arc_capacity_772
 L  arc_capacity_773
 G  connected_order_arc_774
 L  arc_capacity_775
 G  connected_order_arc_776
 L  arc_capacity_777
 G  connected_order_arc_778
 L  arc_capacity_779
 G  connected_order_arc_780
 L  arc_capacity_781
 G  connected_order_arc_782
 L  arc_capacity_783
 G  connected_order_arc_784
 L  arc_capacity_785
 G  connected_order_arc_786
 L  arc_capacity_787
 G  connected_order_arc_788
 L  arc_capacity_789
 G  connected_order_arc_790
 L  arc_capacity_791
 G  connected_order_arc_792
 L  arc_capacity_793
 G  connected_order_arc_794
 L  arc_capacity_795
 G  connected_order_arc_796
 E  depot_departure_or_bypass_797
 E  depot_return_or_bypass_798
 E  out_degree_799
 E  in_degree_800
 G  order_active_lb_801
 L  order_active_ub_802
 E  segment_load_conservation_803
 G  segment_prefix_lb_804
 L  segment_prefix_ub_805
 E  out_degree_806
 E  in_degree_807
 G  order_active_lb_808
 L  order_active_ub_809
 E  segment_load_conservation_810
 G  segment_prefix_lb_811
 L  segment_prefix_ub_812
 E  out_degree_813
 E  in_degree_814
 G  order_active_lb_815
 L  order_active_ub_816
 E  segment_load_conservation_817
 G  segment_prefix_lb_818
 L  segment_prefix_ub_819
 E  out_degree_820
 E  in_degree_821
 G  order_active_lb_822
 L  order_active_ub_823
 E  segment_load_conservation_824
 G  segment_prefix_lb_825
 L  segment_prefix_ub_826
 E  out_degree_827
 E  in_degree_828
 G  order_active_lb_829
 L  order_active_ub_830
 E  segment_load_conservation_831
 G  segment_prefix_lb_832
 L  segment_prefix_ub_833
 E  out_degree_834
 E  in_degree_835
 G  order_active_lb_836
 L  order_active_ub_837
 E  service_visit_def_838
 E  free_load_conservation_839
 E  out_degree_840
 E  in_degree_841
 G  order_active_lb_842
 L  order_active_ub_843
 E  service_visit_def_844
 E  free_load_conservation_845
 E  out_degree_846
 E  in_degree_847
 G  order_active_lb_848
 L  order_active_ub_849
 E  service_visit_def_850
 E  free_load_conservation_851
 E  out_degree_852
 E  in_degree_853
 G  order_active_lb_854
 L  order_active_ub_855
 E  service_visit_def_856
 E  free_load_conservation_857
 E  out_degree_858
 E  in_degree_859
 G  order_active_lb_860
 L  order_active_ub_861
 E  service_visit_def_862
 E  free_load_conservation_863
 E  out_degree_864
 E  in_degree_865
 G  order_active_lb_866
 L  order_active_ub_867
 E  service_visit_def_868
 E  free_load_conservation_869
 E  out_degree_870
 E  in_degree_871
 G  order_active_lb_872
 L  order_active_ub_873
 E  service_visit_def_874
 E  free_load_conservation_875
 E  out_degree_876
 E  in_degree_877
 G  order_active_lb_878
 L  order_active_ub_879
 E  service_visit_def_880
 E  free_load_conservation_881
 G  fixed_segment_relative_order_882
 G  fixed_segment_relative_order_883
 G  fixed_segment_relative_order_884
 G  fixed_segment_relative_order_885
 L  original_T_including_depot_unload_886
 L  arc_capacity_887
 L  arc_capacity_888
 L  arc_capacity_889
 L  arc_capacity_890
 L  arc_capacity_891
 L  arc_capacity_892
 L  arc_capacity_893
 L  arc_capacity_894
 L  arc_capacity_895
 L  arc_capacity_896
 L  arc_capacity_897
 L  arc_capacity_898
 L  arc_capacity_899
 L  arc_capacity_900
 L  arc_capacity_901
 G  connected_order_arc_902
 L  arc_capacity_903
 G  connected_order_arc_904
 L  arc_capacity_905
 G  connected_order_arc_906
 L  arc_capacity_907
 G  connected_order_arc_908
 L  arc_capacity_909
 G  connected_order_arc_910
 L  arc_capacity_911
 G  connected_order_arc_912
 L  arc_capacity_913
 G  connected_order_arc_914
 L  arc_capacity_915
 G  connected_order_arc_916
 L  arc_capacity_917
 G  connected_order_arc_918
 L  arc_capacity_919
 G  connected_order_arc_920
 L  arc_capacity_921
 G  connected_order_arc_922
 L  arc_capacity_923
 L  arc_capacity_924
 G  connected_order_arc_925
 L  arc_capacity_926
 G  connected_order_arc_927
 L  arc_capacity_928
 G  connected_order_arc_929
 L  arc_capacity_930
 G  connected_order_arc_931
 L  arc_capacity_932
 G  connected_order_arc_933
 L  arc_capacity_934
 G  connected_order_arc_935
 L  arc_capacity_936
 G  connected_order_arc_937
 L  arc_capacity_938
 G  connected_order_arc_939
 L  arc_capacity_940
 G  connected_order_arc_941
 L  arc_capacity_942
 G  connected_order_arc_943
 L  arc_capacity_944
 G  connected_order_arc_945
 L  arc_capacity_946
 L  arc_capacity_947
 G  connected_order_arc_948
 L  arc_capacity_949
 G  connected_order_arc_950
 L  arc_capacity_951
 G  connected_order_arc_952
 L  arc_capacity_953
 G  connected_order_arc_954
 L  arc_capacity_955
 G  connected_order_arc_956
 L  arc_capacity_957
 G  connected_order_arc_958
 L  arc_capacity_959
 G  connected_order_arc_960
 L  arc_capacity_961
 G  connected_order_arc_962
 L  arc_capacity_963
 G  connected_order_arc_964
 L  arc_capacity_965
 G  connected_order_arc_966
 L  arc_capacity_967
 G  connected_order_arc_968
 L  arc_capacity_969
 L  arc_capacity_970
 G  connected_order_arc_971
 L  arc_capacity_972
 G  connected_order_arc_973
 L  arc_capacity_974
 G  connected_order_arc_975
 L  arc_capacity_976
 G  connected_order_arc_977
 L  arc_capacity_978
 G  connected_order_arc_979
 L  arc_capacity_980
 G  connected_order_arc_981
 L  arc_capacity_982
 G  connected_order_arc_983
 L  arc_capacity_984
 G  connected_order_arc_985
 L  arc_capacity_986
 G  connected_order_arc_987
 L  arc_capacity_988
 G  connected_order_arc_989
 L  arc_capacity_990
 G  connected_order_arc_991
 L  arc_capacity_992
 L  arc_capacity_993
 G  connected_order_arc_994
 L  arc_capacity_995
 G  connected_order_arc_996
 L  arc_capacity_997
 G  connected_order_arc_998
 L  arc_capacity_999
 G  connected_order_arc_1000
 L  arc_capacity_1001
 G  connected_order_arc_1002
 L  arc_capacity_1003
 G  connected_order_arc_1004
 L  arc_capacity_1005
 G  connected_order_arc_1006
 L  arc_capacity_1007
 G  connected_order_arc_1008
 L  arc_capacity_1009
 G  connected_order_arc_1010
 L  arc_capacity_1011
 G  connected_order_arc_1012
 L  arc_capacity_1013
 G  connected_order_arc_1014
 L  arc_capacity_1015
 L  arc_capacity_1016
 G  connected_order_arc_1017
 L  arc_capacity_1018
 G  connected_order_arc_1019
 L  arc_capacity_1020
 G  connected_order_arc_1021
 L  arc_capacity_1022
 G  connected_order_arc_1023
 L  arc_capacity_1024
 G  connected_order_arc_1025
 L  arc_capacity_1026
 G  connected_order_arc_1027
 L  arc_capacity_1028
 G  connected_order_arc_1029
 L  arc_capacity_1030
 G  connected_order_arc_1031
 L  arc_capacity_1032
 G  connected_order_arc_1033
 L  arc_capacity_1034
 G  connected_order_arc_1035
 L  arc_capacity_1036
 G  connected_order_arc_1037
 L  arc_capacity_1038
 L  arc_capacity_1039
 G  connected_order_arc_1040
 L  arc_capacity_1041
 G  connected_order_arc_1042
 L  arc_capacity_1043
 G  connected_order_arc_1044
 L  arc_capacity_1045
 G  connected_order_arc_1046
 L  arc_capacity_1047
 G  connected_order_arc_1048
 L  arc_capacity_1049
 G  connected_order_arc_1050
 L  arc_capacity_1051
 G  connected_order_arc_1052
 L  arc_capacity_1053
 G  connected_order_arc_1054
 L  arc_capacity_1055
 G  connected_order_arc_1056
 L  arc_capacity_1057
 G  connected_order_arc_1058
 L  arc_capacity_1059
 G  connected_order_arc_1060
 L  arc_capacity_1061
 L  arc_capacity_1062
 G  connected_order_arc_1063
 L  arc_capacity_1064
 G  connected_order_arc_1065
 L  arc_capacity_1066
 G  connected_order_arc_1067
 L  arc_capacity_1068
 G  connected_order_arc_1069
 L  arc_capacity_1070
 G  connected_order_arc_1071
 L  arc_capacity_1072
 G  connected_order_arc_1073
 L  arc_capacity_1074
 G  connected_order_arc_1075
 L  arc_capacity_1076
 G  connected_order_arc_1077
 L  arc_capacity_1078
 G  connected_order_arc_1079
 L  arc_capacity_1080
 G  connected_order_arc_1081
 L  arc_capacity_1082
 G  connected_order_arc_1083
 L  arc_capacity_1084
 L  arc_capacity_1085
 G  connected_order_arc_1086
 L  arc_capacity_1087
 G  connected_order_arc_1088
 L  arc_capacity_1089
 G  connected_order_arc_1090
 L  arc_capacity_1091
 G  connected_order_arc_1092
 L  arc_capacity_1093
 G  connected_order_arc_1094
 L  arc_capacity_1095
 G  connected_order_arc_1096
 L  arc_capacity_1097
 G  connected_order_arc_1098
 L  arc_capacity_1099
 G  connected_order_arc_1100
 L  arc_capacity_1101
 G  connected_order_arc_1102
 L  arc_capacity_1103
 G  connected_order_arc_1104
 L  arc_capacity_1105
 G  connected_order_arc_1106
 L  arc_capacity_1107
 L  arc_capacity_1108
 G  connected_order_arc_1109
 L  arc_capacity_1110
 G  connected_order_arc_1111
 L  arc_capacity_1112
 G  connected_order_arc_1113
 L  arc_capacity_1114
 G  connected_order_arc_1115
 L  arc_capacity_1116
 G  connected_order_arc_1117
 L  arc_capacity_1118
 G  connected_order_arc_1119
 L  arc_capacity_1120
 G  connected_order_arc_1121
 L  arc_capacity_1122
 G  connected_order_arc_1123
 L  arc_capacity_1124
 G  connected_order_arc_1125
 L  arc_capacity_1126
 G  connected_order_arc_1127
 L  arc_capacity_1128
 G  connected_order_arc_1129
 L  arc_capacity_1130
 L  arc_capacity_1131
 G  connected_order_arc_1132
 L  arc_capacity_1133
 G  connected_order_arc_1134
 L  arc_capacity_1135
 G  connected_order_arc_1136
 L  arc_capacity_1137
 G  connected_order_arc_1138
 L  arc_capacity_1139
 G  connected_order_arc_1140
 L  arc_capacity_1141
 G  connected_order_arc_1142
 L  arc_capacity_1143
 G  connected_order_arc_1144
 L  arc_capacity_1145
 G  connected_order_arc_1146
 L  arc_capacity_1147
 G  connected_order_arc_1148
 L  arc_capacity_1149
 G  connected_order_arc_1150
 L  arc_capacity_1151
 G  connected_order_arc_1152
 L  arc_capacity_1153
 L  arc_capacity_1154
 G  connected_order_arc_1155
 L  arc_capacity_1156
 G  connected_order_arc_1157
 L  arc_capacity_1158
 G  connected_order_arc_1159
 L  arc_capacity_1160
 G  connected_order_arc_1161
 L  arc_capacity_1162
 G  connected_order_arc_1163
 L  arc_capacity_1164
 G  connected_order_arc_1165
 L  arc_capacity_1166
 G  connected_order_arc_1167
 L  arc_capacity_1168
 G  connected_order_arc_1169
 L  arc_capacity_1170
 G  connected_order_arc_1171
 L  arc_capacity_1172
 G  connected_order_arc_1173
 L  arc_capacity_1174
 G  connected_order_arc_1175
 E  depot_departure_or_bypass_1176
 E  depot_return_or_bypass_1177
 E  out_degree_1178
 E  in_degree_1179
 G  order_active_lb_1180
 L  order_active_ub_1181
 E  segment_load_conservation_1182
 G  segment_prefix_lb_1183
 L  segment_prefix_ub_1184
 E  out_degree_1185
 E  in_degree_1186
 G  order_active_lb_1187
 L  order_active_ub_1188
 E  segment_load_conservation_1189
 G  segment_prefix_lb_1190
 L  segment_prefix_ub_1191
 E  out_degree_1192
 E  in_degree_1193
 G  order_active_lb_1194
 L  order_active_ub_1195
 E  segment_load_conservation_1196
 G  segment_prefix_lb_1197
 L  segment_prefix_ub_1198
 E  out_degree_1199
 E  in_degree_1200
 G  order_active_lb_1201
 L  order_active_ub_1202
 E  segment_load_conservation_1203
 G  segment_prefix_lb_1204
 L  segment_prefix_ub_1205
 E  out_degree_1206
 E  in_degree_1207
 G  order_active_lb_1208
 L  order_active_ub_1209
 E  service_visit_def_1210
 E  free_load_conservation_1211
 E  out_degree_1212
 E  in_degree_1213
 G  order_active_lb_1214
 L  order_active_ub_1215
 E  service_visit_def_1216
 E  free_load_conservation_1217
 E  out_degree_1218
 E  in_degree_1219
 G  order_active_lb_1220
 L  order_active_ub_1221
 E  service_visit_def_1222
 E  free_load_conservation_1223
 E  out_degree_1224
 E  in_degree_1225
 G  order_active_lb_1226
 L  order_active_ub_1227
 E  service_visit_def_1228
 E  free_load_conservation_1229
 E  out_degree_1230
 E  in_degree_1231
 G  order_active_lb_1232
 L  order_active_ub_1233
 E  service_visit_def_1234
 E  free_load_conservation_1235
 E  out_degree_1236
 E  in_degree_1237
 G  order_active_lb_1238
 L  order_active_ub_1239
 E  service_visit_def_1240
 E  free_load_conservation_1241
 E  out_degree_1242
 E  in_degree_1243
 G  order_active_lb_1244
 L  order_active_ub_1245
 E  service_visit_def_1246
 E  free_load_conservation_1247
 E  out_degree_1248
 E  in_degree_1249
 G  order_active_lb_1250
 L  order_active_ub_1251
 E  service_visit_def_1252
 E  free_load_conservation_1253
 G  fixed_segment_relative_order_1254
 G  fixed_segment_relative_order_1255
 G  fixed_segment_relative_order_1256
 L  original_T_including_depot_unload_1257
 L  arc_capacity_1258
 L  arc_capacity_1259
 L  arc_capacity_1260
 L  arc_capacity_1261
 L  arc_capacity_1262
 L  arc_capacity_1263
 L  arc_capacity_1264
 L  arc_capacity_1265
 L  arc_capacity_1266
 L  arc_capacity_1267
 L  arc_capacity_1268
 L  arc_capacity_1269
 L  arc_capacity_1270
 L  arc_capacity_1271
 G  connected_order_arc_1272
 L  arc_capacity_1273
 G  connected_order_arc_1274
 L  arc_capacity_1275
 G  connected_order_arc_1276
 L  arc_capacity_1277
 G  connected_order_arc_1278
 L  arc_capacity_1279
 G  connected_order_arc_1280
 L  arc_capacity_1281
 G  connected_order_arc_1282
 L  arc_capacity_1283
 G  connected_order_arc_1284
 L  arc_capacity_1285
 G  connected_order_arc_1286
 L  arc_capacity_1287
 G  connected_order_arc_1288
 L  arc_capacity_1289
 G  connected_order_arc_1290
 L  arc_capacity_1291
 L  arc_capacity_1292
 G  connected_order_arc_1293
 L  arc_capacity_1294
 G  connected_order_arc_1295
 L  arc_capacity_1296
 G  connected_order_arc_1297
 L  arc_capacity_1298
 G  connected_order_arc_1299
 L  arc_capacity_1300
 G  connected_order_arc_1301
 L  arc_capacity_1302
 G  connected_order_arc_1303
 L  arc_capacity_1304
 G  connected_order_arc_1305
 L  arc_capacity_1306
 G  connected_order_arc_1307
 L  arc_capacity_1308
 G  connected_order_arc_1309
 L  arc_capacity_1310
 G  connected_order_arc_1311
 L  arc_capacity_1312
 L  arc_capacity_1313
 G  connected_order_arc_1314
 L  arc_capacity_1315
 G  connected_order_arc_1316
 L  arc_capacity_1317
 G  connected_order_arc_1318
 L  arc_capacity_1319
 G  connected_order_arc_1320
 L  arc_capacity_1321
 G  connected_order_arc_1322
 L  arc_capacity_1323
 G  connected_order_arc_1324
 L  arc_capacity_1325
 G  connected_order_arc_1326
 L  arc_capacity_1327
 G  connected_order_arc_1328
 L  arc_capacity_1329
 G  connected_order_arc_1330
 L  arc_capacity_1331
 G  connected_order_arc_1332
 L  arc_capacity_1333
 L  arc_capacity_1334
 G  connected_order_arc_1335
 L  arc_capacity_1336
 G  connected_order_arc_1337
 L  arc_capacity_1338
 G  connected_order_arc_1339
 L  arc_capacity_1340
 G  connected_order_arc_1341
 L  arc_capacity_1342
 G  connected_order_arc_1343
 L  arc_capacity_1344
 G  connected_order_arc_1345
 L  arc_capacity_1346
 G  connected_order_arc_1347
 L  arc_capacity_1348
 G  connected_order_arc_1349
 L  arc_capacity_1350
 G  connected_order_arc_1351
 L  arc_capacity_1352
 G  connected_order_arc_1353
 L  arc_capacity_1354
 L  arc_capacity_1355
 G  connected_order_arc_1356
 L  arc_capacity_1357
 G  connected_order_arc_1358
 L  arc_capacity_1359
 G  connected_order_arc_1360
 L  arc_capacity_1361
 G  connected_order_arc_1362
 L  arc_capacity_1363
 G  connected_order_arc_1364
 L  arc_capacity_1365
 G  connected_order_arc_1366
 L  arc_capacity_1367
 G  connected_order_arc_1368
 L  arc_capacity_1369
 G  connected_order_arc_1370
 L  arc_capacity_1371
 G  connected_order_arc_1372
 L  arc_capacity_1373
 G  connected_order_arc_1374
 L  arc_capacity_1375
 L  arc_capacity_1376
 G  connected_order_arc_1377
 L  arc_capacity_1378
 G  connected_order_arc_1379
 L  arc_capacity_1380
 G  connected_order_arc_1381
 L  arc_capacity_1382
 G  connected_order_arc_1383
 L  arc_capacity_1384
 G  connected_order_arc_1385
 L  arc_capacity_1386
 G  connected_order_arc_1387
 L  arc_capacity_1388
 G  connected_order_arc_1389
 L  arc_capacity_1390
 G  connected_order_arc_1391
 L  arc_capacity_1392
 G  connected_order_arc_1393
 L  arc_capacity_1394
 G  connected_order_arc_1395
 L  arc_capacity_1396
 L  arc_capacity_1397
 G  connected_order_arc_1398
 L  arc_capacity_1399
 G  connected_order_arc_1400
 L  arc_capacity_1401
 G  connected_order_arc_1402
 L  arc_capacity_1403
 G  connected_order_arc_1404
 L  arc_capacity_1405
 G  connected_order_arc_1406
 L  arc_capacity_1407
 G  connected_order_arc_1408
 L  arc_capacity_1409
 G  connected_order_arc_1410
 L  arc_capacity_1411
 G  connected_order_arc_1412
 L  arc_capacity_1413
 G  connected_order_arc_1414
 L  arc_capacity_1415
 G  connected_order_arc_1416
 L  arc_capacity_1417
 L  arc_capacity_1418
 G  connected_order_arc_1419
 L  arc_capacity_1420
 G  connected_order_arc_1421
 L  arc_capacity_1422
 G  connected_order_arc_1423
 L  arc_capacity_1424
 G  connected_order_arc_1425
 L  arc_capacity_1426
 G  connected_order_arc_1427
 L  arc_capacity_1428
 G  connected_order_arc_1429
 L  arc_capacity_1430
 G  connected_order_arc_1431
 L  arc_capacity_1432
 G  connected_order_arc_1433
 L  arc_capacity_1434
 G  connected_order_arc_1435
 L  arc_capacity_1436
 G  connected_order_arc_1437
 L  arc_capacity_1438
 L  arc_capacity_1439
 G  connected_order_arc_1440
 L  arc_capacity_1441
 G  connected_order_arc_1442
 L  arc_capacity_1443
 G  connected_order_arc_1444
 L  arc_capacity_1445
 G  connected_order_arc_1446
 L  arc_capacity_1447
 G  connected_order_arc_1448
 L  arc_capacity_1449
 G  connected_order_arc_1450
 L  arc_capacity_1451
 G  connected_order_arc_1452
 L  arc_capacity_1453
 G  connected_order_arc_1454
 L  arc_capacity_1455
 G  connected_order_arc_1456
 L  arc_capacity_1457
 G  connected_order_arc_1458
 L  arc_capacity_1459
 L  arc_capacity_1460
 G  connected_order_arc_1461
 L  arc_capacity_1462
 G  connected_order_arc_1463
 L  arc_capacity_1464
 G  connected_order_arc_1465
 L  arc_capacity_1466
 G  connected_order_arc_1467
 L  arc_capacity_1468
 G  connected_order_arc_1469
 L  arc_capacity_1470
 G  connected_order_arc_1471
 L  arc_capacity_1472
 G  connected_order_arc_1473
 L  arc_capacity_1474
 G  connected_order_arc_1475
 L  arc_capacity_1476
 G  connected_order_arc_1477
 L  arc_capacity_1478
 G  connected_order_arc_1479
 L  arc_capacity_1480
 L  arc_capacity_1481
 G  connected_order_arc_1482
 L  arc_capacity_1483
 G  connected_order_arc_1484
 L  arc_capacity_1485
 G  connected_order_arc_1486
 L  arc_capacity_1487
 G  connected_order_arc_1488
 L  arc_capacity_1489
 G  connected_order_arc_1490
 L  arc_capacity_1491
 G  connected_order_arc_1492
 L  arc_capacity_1493
 G  connected_order_arc_1494
 L  arc_capacity_1495
 G  connected_order_arc_1496
 L  arc_capacity_1497
 G  connected_order_arc_1498
 L  arc_capacity_1499
 G  connected_order_arc_1500
 E  depot_departure_or_bypass_1501
 E  depot_return_or_bypass_1502
 E  out_degree_1503
 E  in_degree_1504
 G  order_active_lb_1505
 L  order_active_ub_1506
 E  segment_load_conservation_1507
 G  segment_prefix_lb_1508
 L  segment_prefix_ub_1509
 E  out_degree_1510
 E  in_degree_1511
 G  order_active_lb_1512
 L  order_active_ub_1513
 E  segment_load_conservation_1514
 G  segment_prefix_lb_1515
 L  segment_prefix_ub_1516
 E  out_degree_1517
 E  in_degree_1518
 G  order_active_lb_1519
 L  order_active_ub_1520
 E  segment_load_conservation_1521
 G  segment_prefix_lb_1522
 L  segment_prefix_ub_1523
 E  out_degree_1524
 E  in_degree_1525
 G  order_active_lb_1526
 L  order_active_ub_1527
 E  service_visit_def_1528
 E  free_load_conservation_1529
 E  out_degree_1530
 E  in_degree_1531
 G  order_active_lb_1532
 L  order_active_ub_1533
 E  service_visit_def_1534
 E  free_load_conservation_1535
 E  out_degree_1536
 E  in_degree_1537
 G  order_active_lb_1538
 L  order_active_ub_1539
 E  service_visit_def_1540
 E  free_load_conservation_1541
 E  out_degree_1542
 E  in_degree_1543
 G  order_active_lb_1544
 L  order_active_ub_1545
 E  service_visit_def_1546
 E  free_load_conservation_1547
 E  out_degree_1548
 E  in_degree_1549
 G  order_active_lb_1550
 L  order_active_ub_1551
 E  service_visit_def_1552
 E  free_load_conservation_1553
 E  out_degree_1554
 E  in_degree_1555
 G  order_active_lb_1556
 L  order_active_ub_1557
 E  service_visit_def_1558
 E  free_load_conservation_1559
 E  out_degree_1560
 E  in_degree_1561
 G  order_active_lb_1562
 L  order_active_ub_1563
 E  service_visit_def_1564
 E  free_load_conservation_1565
 E  out_degree_1566
 E  in_degree_1567
 G  order_active_lb_1568
 L  order_active_ub_1569
 E  service_visit_def_1570
 E  free_load_conservation_1571
 G  fixed_segment_relative_order_1572
 G  fixed_segment_relative_order_1573
 L  original_T_including_depot_unload_1574
COLUMNS
    t         normalized_mass_3_37  -1
    t         normalized_mass_1_80  -1
    t         normalized_mass_31_109  -1
    t         normalized_mass_7_148  -1
    t         normalized_mass_32_177  -1
    t         normalized_mass_4_212  -1
    t         normalized_mass_19_233  -1
    t         normalized_mass_10_276  -1
    t         normalization_337  2.3276190476190479e+01
    t         full_original_Gini_338  -8.0833333333333343e+01
    q         OBJ       1
    q         parent_nonstrict_scope_280  1
    q         full_original_Gini_338  35
    MARKER    'MARKER'                 'INTORG'
    x_3_0     OBJ       0.042
    x_3_0     product_lb_0  -2.5263157894711577e-02
    x_3_0     product_ub_1  -0.042962356792187
    x_3_0     onehot_3_36  1
    x_3_0     parent_nonstrict_scope_280  0.096
    x_3_0     unique_nonzero_owner_339  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_0     product_lb_0  1
    w_3_0     product_ub_1  1
    w_3_0     normalized_mass_3_37  1
    w_3_0     full_original_Gini_338  -2.3276190476190479e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_1     OBJ       3.0000000000000006e-02
    x_3_1     product_lb_2  -2.5263157894711577e-02
    x_3_1     product_ub_3  -0.042962356792187
    x_3_1     onehot_3_36  1
    x_3_1     stock_lb_278  1
    x_3_1     stock_ub_279  1
    x_3_1     parent_nonstrict_scope_280  0.084
    x_3_1     unique_nonzero_owner_340  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_1     product_lb_2  1
    w_3_1     product_ub_3  1
    w_3_1     normalized_mass_3_37  1
    w_3_1     normalized_ratio_3_38  -0.125
    w_3_1     full_original_Gini_338  -2.0151190476190475e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_2     OBJ       1.8000000000000009e-02
    x_3_2     product_lb_4  -2.5263157894711577e-02
    x_3_2     product_ub_5  -0.042962356792187
    x_3_2     onehot_3_36  1
    x_3_2     stock_lb_278  2
    x_3_2     stock_ub_279  2
    x_3_2     parent_nonstrict_scope_280  7.2000000000000008e-02
    x_3_2     unique_nonzero_owner_341  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_2     product_lb_4  1
    w_3_2     product_ub_5  1
    w_3_2     normalized_mass_3_37  1
    w_3_2     normalized_ratio_3_38  -0.25
    w_3_2     full_original_Gini_338  -1.7026190476190475e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_3     OBJ       5.9999999999999984e-03
    x_3_3     product_lb_6  -2.5263157894711577e-02
    x_3_3     product_ub_7  -0.042962356792187
    x_3_3     onehot_3_36  1
    x_3_3     stock_lb_278  3
    x_3_3     stock_ub_279  3
    x_3_3     parent_nonstrict_scope_280  0.06
    x_3_3     unique_nonzero_owner_342  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_3     product_lb_6  1
    w_3_3     product_ub_7  1
    w_3_3     normalized_mass_3_37  1
    w_3_3     normalized_ratio_3_38  -0.375
    w_3_3     full_original_Gini_338  -1.3901190476190477e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_4     OBJ       -5.9999999999999984e-03
    x_3_4     product_lb_8  -2.5263157894711577e-02
    x_3_4     product_ub_9  -0.042962356792187
    x_3_4     onehot_3_36  1
    x_3_4     stock_lb_278  4
    x_3_4     stock_ub_279  4
    x_3_4     parent_nonstrict_scope_280  0.048
    x_3_4     unique_nonzero_owner_343  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_4     product_lb_8  1
    w_3_4     product_ub_9  1
    w_3_4     normalized_mass_3_37  1
    w_3_4     normalized_ratio_3_38  -0.5
    w_3_4     full_original_Gini_338  -1.1176190476190476e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_5     OBJ       -1.7999999999999995e-02
    x_3_5     product_lb_10  -2.5263157894711577e-02
    x_3_5     product_ub_11  -0.042962356792187
    x_3_5     onehot_3_36  1
    x_3_5     stock_lb_278  5
    x_3_5     stock_ub_279  5
    x_3_5     parent_nonstrict_scope_280  3.6000000000000004e-02
    x_3_5     unique_nonzero_owner_344  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_5     product_lb_10  1
    w_3_5     product_ub_11  1
    w_3_5     normalized_mass_3_37  1
    w_3_5     normalized_ratio_3_38  -0.625
    w_3_5     full_original_Gini_338  -8.5511904761904756e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_6     OBJ       -0.03
    x_3_6     product_lb_12  -2.5263157894711577e-02
    x_3_6     product_ub_13  -0.042962356792187
    x_3_6     onehot_3_36  1
    x_3_6     stock_lb_278  6
    x_3_6     stock_ub_279  6
    x_3_6     parent_nonstrict_scope_280  0.024
    x_3_6     unique_nonzero_owner_345  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_6     product_lb_12  1
    w_3_6     product_ub_13  1
    w_3_6     normalized_mass_3_37  1
    w_3_6     normalized_ratio_3_38  -0.75
    w_3_6     full_original_Gini_338  -6.0690476190476188e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_7     OBJ       -4.1999999999999996e-02
    x_3_7     product_lb_14  -2.5263157894711577e-02
    x_3_7     product_ub_15  -0.042962356792187
    x_3_7     onehot_3_36  1
    x_3_7     stock_lb_278  7
    x_3_7     stock_ub_279  7
    x_3_7     parent_nonstrict_scope_280  0.012
    x_3_7     unique_nonzero_owner_346  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_7     product_lb_14  1
    w_3_7     product_ub_15  1
    w_3_7     normalized_mass_3_37  1
    w_3_7     normalized_ratio_3_38  -0.875
    w_3_7     full_original_Gini_338  -4.2488095238095234e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_8     OBJ       -0.054
    x_3_8     product_lb_16  -2.5263157894711577e-02
    x_3_8     product_ub_17  -0.042962356792187
    x_3_8     onehot_3_36  1
    x_3_8     stock_lb_278  8
    x_3_8     stock_ub_279  8
    x_3_8     unique_nonzero_owner_347  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_8     product_lb_16  1
    w_3_8     product_ub_17  1
    w_3_8     normalized_mass_3_37  1
    w_3_8     normalized_ratio_3_38  -1
    w_3_8     full_original_Gini_338  -4.1238095238095234e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_9     OBJ       -4.1999999999999996e-02
    x_3_9     product_lb_18  -2.5263157894711577e-02
    x_3_9     product_ub_19  -0.042962356792187
    x_3_9     onehot_3_36  1
    x_3_9     stock_lb_278  9
    x_3_9     stock_ub_279  9
    x_3_9     parent_nonstrict_scope_280  0.012
    x_3_9     unique_nonzero_owner_348  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_9     product_lb_18  1
    w_3_9     product_ub_19  1
    w_3_9     normalized_mass_3_37  1
    w_3_9     normalized_ratio_3_38  -1.125
    w_3_9     full_original_Gini_338  -7.2488095238095251e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_10    OBJ       -0.03
    x_3_10    product_lb_20  -2.5263157894711577e-02
    x_3_10    product_ub_21  -0.042962356792187
    x_3_10    onehot_3_36  1
    x_3_10    stock_lb_278  10
    x_3_10    stock_ub_279  10
    x_3_10    parent_nonstrict_scope_280  0.024
    x_3_10    unique_nonzero_owner_349  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_10    product_lb_20  1
    w_3_10    product_ub_21  1
    w_3_10    normalized_mass_3_37  1
    w_3_10    normalized_ratio_3_38  -1.25
    w_3_10    full_original_Gini_338  -1.0473809523809523e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_11    OBJ       -1.7999999999999995e-02
    x_3_11    product_lb_22  -2.5263157894711577e-02
    x_3_11    product_ub_23  -0.042962356792187
    x_3_11    onehot_3_36  1
    x_3_11    stock_lb_278  11
    x_3_11    stock_ub_279  11
    x_3_11    parent_nonstrict_scope_280  3.6000000000000004e-02
    x_3_11    unique_nonzero_owner_350  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_11    product_lb_22  1
    w_3_11    product_ub_23  1
    w_3_11    normalized_mass_3_37  1
    w_3_11    normalized_ratio_3_38  -1.375
    w_3_11    full_original_Gini_338  -1.3848809523809523e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_12    OBJ       -5.9999999999999984e-03
    x_3_12    product_lb_24  -2.5263157894711577e-02
    x_3_12    product_ub_25  -0.042962356792187
    x_3_12    onehot_3_36  1
    x_3_12    stock_lb_278  12
    x_3_12    stock_ub_279  12
    x_3_12    parent_nonstrict_scope_280  0.048
    MARKER    'MARKER'                 'INTEND'
    w_3_12    product_lb_24  1
    w_3_12    product_ub_25  1
    w_3_12    normalized_mass_3_37  1
    w_3_12    normalized_ratio_3_38  -1.5
    w_3_12    full_original_Gini_338  -1.7223809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_13    OBJ       5.9999999999999984e-03
    x_3_13    product_lb_26  -2.5263157894711577e-02
    x_3_13    product_ub_27  -0.042962356792187
    x_3_13    onehot_3_36  1
    x_3_13    stock_lb_278  13
    x_3_13    stock_ub_279  13
    x_3_13    parent_nonstrict_scope_280  0.06
    x_3_13    unique_nonzero_owner_351  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_13    product_lb_26  1
    w_3_13    product_ub_27  1
    w_3_13    normalized_mass_3_37  1
    w_3_13    normalized_ratio_3_38  -1.625
    w_3_13    full_original_Gini_338  -2.0598809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_14    OBJ       1.8000000000000009e-02
    x_3_14    product_lb_28  -2.5263157894711577e-02
    x_3_14    product_ub_29  -0.042962356792187
    x_3_14    onehot_3_36  1
    x_3_14    stock_lb_278  14
    x_3_14    stock_ub_279  14
    x_3_14    parent_nonstrict_scope_280  7.2000000000000008e-02
    x_3_14    unique_nonzero_owner_352  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_14    product_lb_28  1
    w_3_14    product_ub_29  1
    w_3_14    normalized_mass_3_37  1
    w_3_14    normalized_ratio_3_38  -1.75
    w_3_14    full_original_Gini_338  -2.3973809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_15    OBJ       3.0000000000000006e-02
    x_3_15    product_lb_30  -2.5263157894711577e-02
    x_3_15    product_ub_31  -0.042962356792187
    x_3_15    onehot_3_36  1
    x_3_15    stock_lb_278  15
    x_3_15    stock_ub_279  15
    x_3_15    parent_nonstrict_scope_280  0.084
    x_3_15    unique_nonzero_owner_353  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_15    product_lb_30  1
    w_3_15    product_ub_31  1
    w_3_15    normalized_mass_3_37  1
    w_3_15    normalized_ratio_3_38  -1.875
    w_3_15    full_original_Gini_338  -2.7348809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_16    OBJ       0.042
    x_3_16    product_lb_32  -2.5263157894711577e-02
    x_3_16    product_ub_33  -0.042962356792187
    x_3_16    onehot_3_36  1
    x_3_16    stock_lb_278  16
    x_3_16    stock_ub_279  16
    x_3_16    parent_nonstrict_scope_280  0.096
    x_3_16    unique_nonzero_owner_354  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_16    product_lb_32  1
    w_3_16    product_ub_33  1
    w_3_16    normalized_mass_3_37  1
    w_3_16    normalized_ratio_3_38  -2
    w_3_16    full_original_Gini_338  -3.0723809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_17    OBJ       0.054
    x_3_17    product_lb_34  -2.5263157894711577e-02
    x_3_17    product_ub_35  -0.042962356792187
    x_3_17    onehot_3_36  1
    x_3_17    stock_lb_278  17
    x_3_17    stock_ub_279  17
    x_3_17    parent_nonstrict_scope_280  0.108
    x_3_17    unique_nonzero_owner_355  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_17    product_lb_34  1
    w_3_17    product_ub_35  1
    w_3_17    normalized_mass_3_37  1
    w_3_17    normalized_ratio_3_38  -2.125
    w_3_17    full_original_Gini_338  -3.4098809523809521e+01
    rho_3     normalized_ratio_3_38  1
    rho_3     block_pair_pos_293  -1
    rho_3     block_pair_neg_294  1
    rho_3     block_pair_pos_295  -1
    rho_3     block_pair_neg_296  1
    rho_3     block_pair_pos_297  -1
    rho_3     block_pair_neg_298  1
    rho_3     block_pair_pos_299  -1
    rho_3     block_pair_neg_300  1
    rho_3     block_pair_pos_301  -1
    rho_3     block_pair_neg_302  1
    rho_3     block_pair_pos_303  -1
    rho_3     block_pair_neg_304  1
    rho_3     block_pair_pos_305  -1
    rho_3     block_pair_neg_306  1
    rho_3     normalization_337  1
    MARKER    'MARKER'                 'INTORG'
    x_1_0     OBJ       0.075
    x_1_0     product_lb_39  -2.5263157894711577e-02
    x_1_0     product_ub_40  -0.042962356792187
    x_1_0     onehot_1_79  1
    x_1_0     parent_nonstrict_scope_280  0.15
    x_1_0     unique_nonzero_owner_356  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_0     product_lb_39  1
    w_1_0     product_ub_40  1
    w_1_0     normalized_mass_1_80  1
    w_1_0     full_original_Gini_338  -2.3276190476190479e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_1     OBJ       6.0000000000000012e-02
    x_1_1     product_lb_41  -2.5263157894711577e-02
    x_1_1     product_ub_42  -0.042962356792187
    x_1_1     onehot_1_79  1
    x_1_1     stock_lb_278  1
    x_1_1     stock_ub_279  1
    x_1_1     parent_nonstrict_scope_280  0.135
    x_1_1     unique_nonzero_owner_357  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_1     product_lb_41  1
    w_1_1     product_ub_42  1
    w_1_1     normalized_mass_1_80  1
    w_1_1     normalized_ratio_1_81  -0.1
    w_1_1     full_original_Gini_338  -2.0776190476190472e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_2     OBJ       0.045
    x_1_2     product_lb_43  -2.5263157894711577e-02
    x_1_2     product_ub_44  -0.042962356792187
    x_1_2     onehot_1_79  1
    x_1_2     stock_lb_278  2
    x_1_2     stock_ub_279  2
    x_1_2     parent_nonstrict_scope_280  0.12
    MARKER    'MARKER'                 'INTEND'
    w_1_2     product_lb_43  1
    w_1_2     product_ub_44  1
    w_1_2     normalized_mass_1_80  1
    w_1_2     normalized_ratio_1_81  -0.2
    w_1_2     full_original_Gini_338  -1.8276190476190482e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_3     OBJ       0.03
    x_1_3     product_lb_45  -2.5263157894711577e-02
    x_1_3     product_ub_46  -0.042962356792187
    x_1_3     onehot_1_79  1
    x_1_3     stock_lb_278  3
    x_1_3     stock_ub_279  3
    x_1_3     parent_nonstrict_scope_280  0.105
    x_1_3     unique_nonzero_owner_358  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_3     product_lb_45  1
    w_1_3     product_ub_46  1
    w_1_3     normalized_mass_1_80  1
    w_1_3     normalized_ratio_1_81  -3.0000000000000004e-01
    w_1_3     full_original_Gini_338  -1.5776190476190470e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_4     OBJ       0.015
    x_1_4     product_lb_47  -2.5263157894711577e-02
    x_1_4     product_ub_48  -0.042962356792187
    x_1_4     onehot_1_79  1
    x_1_4     stock_lb_278  4
    x_1_4     stock_ub_279  4
    x_1_4     parent_nonstrict_scope_280  0.09
    x_1_4     unique_nonzero_owner_359  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_4     product_lb_47  1
    w_1_4     product_ub_48  1
    w_1_4     normalized_mass_1_80  1
    w_1_4     normalized_ratio_1_81  -0.4
    w_1_4     full_original_Gini_338  -1.3276190476190473e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_5     product_lb_49  -2.5263157894711577e-02
    x_1_5     product_ub_50  -0.042962356792187
    x_1_5     onehot_1_79  1
    x_1_5     stock_lb_278  5
    x_1_5     stock_ub_279  5
    x_1_5     parent_nonstrict_scope_280  0.075
    x_1_5     unique_nonzero_owner_360  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_5     product_lb_49  1
    w_1_5     product_ub_50  1
    w_1_5     normalized_mass_1_80  1
    w_1_5     normalized_ratio_1_81  -0.5
    w_1_5     full_original_Gini_338  -1.1176190476190476e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_6     OBJ       -1.5000000000000013e-02
    x_1_6     product_lb_51  -2.5263157894711577e-02
    x_1_6     product_ub_52  -0.042962356792187
    x_1_6     onehot_1_79  1
    x_1_6     stock_lb_278  6
    x_1_6     stock_ub_279  6
    x_1_6     parent_nonstrict_scope_280  5.9999999999999984e-02
    x_1_6     unique_nonzero_owner_361  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_6     product_lb_51  1
    w_1_6     product_ub_52  1
    w_1_6     normalized_mass_1_80  1
    w_1_6     normalized_ratio_1_81  -6.0000000000000009e-01
    w_1_6     full_original_Gini_338  -9.0761904761904759e+00
    MARKER    'MARKER'                 'INTORG'
    x_1_7     OBJ       -3.0000000000000006e-02
    x_1_7     product_lb_53  -2.5263157894711577e-02
    x_1_7     product_ub_54  -0.042962356792187
    x_1_7     onehot_1_79  1
    x_1_7     stock_lb_278  7
    x_1_7     stock_ub_279  7
    x_1_7     parent_nonstrict_scope_280  4.4999999999999991e-02
    x_1_7     unique_nonzero_owner_362  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_7     product_lb_53  1
    w_1_7     product_ub_54  1
    w_1_7     normalized_mass_1_80  1
    w_1_7     normalized_ratio_1_81  -7.0000000000000007e-01
    w_1_7     full_original_Gini_338  -6.9761904761904745e+00
    MARKER    'MARKER'                 'INTORG'
    x_1_8     OBJ       -4.5000000000000005e-02
    x_1_8     product_lb_55  -2.5263157894711577e-02
    x_1_8     product_ub_56  -0.042962356792187
    x_1_8     onehot_1_79  1
    x_1_8     stock_lb_278  8
    x_1_8     stock_ub_279  8
    x_1_8     parent_nonstrict_scope_280  2.9999999999999992e-02
    x_1_8     unique_nonzero_owner_363  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_8     product_lb_55  1
    w_1_8     product_ub_56  1
    w_1_8     normalized_mass_1_80  1
    w_1_8     normalized_ratio_1_81  -0.8
    w_1_8     full_original_Gini_338  -5.2190476190476209e+00
    MARKER    'MARKER'                 'INTORG'
    x_1_9     OBJ       -0.06
    x_1_9     product_lb_57  -2.5263157894711577e-02
    x_1_9     product_ub_58  -0.042962356792187
    x_1_9     onehot_1_79  1
    x_1_9     stock_lb_278  9
    x_1_9     stock_ub_279  9
    x_1_9     parent_nonstrict_scope_280  1.4999999999999996e-02
    x_1_9     unique_nonzero_owner_364  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_9     product_lb_57  1
    w_1_9     product_ub_58  1
    w_1_9     normalized_mass_1_80  1
    w_1_9     normalized_ratio_1_81  -0.9
    w_1_9     full_original_Gini_338  -4.2238095238095248e+00
    MARKER    'MARKER'                 'INTORG'
    x_1_10    OBJ       -0.075
    x_1_10    product_lb_59  -2.5263157894711577e-02
    x_1_10    product_ub_60  -0.042962356792187
    x_1_10    onehot_1_79  1
    x_1_10    stock_lb_278  10
    x_1_10    stock_ub_279  10
    x_1_10    unique_nonzero_owner_365  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_10    product_lb_59  1
    w_1_10    product_ub_60  1
    w_1_10    normalized_mass_1_80  1
    w_1_10    normalized_ratio_1_81  -1
    w_1_10    full_original_Gini_338  -4.1238095238095234e+00
    MARKER    'MARKER'                 'INTORG'
    x_1_11    OBJ       -5.9999999999999984e-02
    x_1_11    product_lb_61  -2.5263157894711577e-02
    x_1_11    product_ub_62  -0.042962356792187
    x_1_11    onehot_1_79  1
    x_1_11    stock_lb_278  11
    x_1_11    stock_ub_279  11
    x_1_11    parent_nonstrict_scope_280  1.5000000000000013e-02
    x_1_11    unique_nonzero_owner_366  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_11    product_lb_61  1
    w_1_11    product_ub_62  1
    w_1_11    normalized_mass_1_80  1
    w_1_11    normalized_ratio_1_81  -1.1
    w_1_11    full_original_Gini_338  -6.6238095238095251e+00
    MARKER    'MARKER'                 'INTORG'
    x_1_12    OBJ       -4.4999999999999971e-02
    x_1_12    product_lb_63  -2.5263157894711577e-02
    x_1_12    product_ub_64  -0.042962356792187
    x_1_12    onehot_1_79  1
    x_1_12    stock_lb_278  12
    x_1_12    stock_ub_279  12
    x_1_12    parent_nonstrict_scope_280  3.0000000000000027e-02
    x_1_12    unique_nonzero_owner_367  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_12    product_lb_63  1
    w_1_12    product_ub_64  1
    w_1_12    normalized_mass_1_80  1
    w_1_12    normalized_ratio_1_81  -1.2000000000000002e+00
    w_1_12    full_original_Gini_338  -9.12380952380953
    MARKER    'MARKER'                 'INTORG'
    x_1_13    OBJ       -2.9999999999999992e-02
    x_1_13    product_lb_65  -2.5263157894711577e-02
    x_1_13    product_ub_66  -0.042962356792187
    x_1_13    onehot_1_79  1
    x_1_13    stock_lb_278  13
    x_1_13    stock_ub_279  13
    x_1_13    parent_nonstrict_scope_280  4.5000000000000005e-02
    x_1_13    unique_nonzero_owner_368  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_13    product_lb_65  1
    w_1_13    product_ub_66  1
    w_1_13    normalized_mass_1_80  1
    w_1_13    normalized_ratio_1_81  -1.3
    w_1_13    full_original_Gini_338  -1.1823809523809528e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_14    OBJ       -1.4999999999999979e-02
    x_1_14    product_lb_67  -2.5263157894711577e-02
    x_1_14    product_ub_68  -0.042962356792187
    x_1_14    onehot_1_79  1
    x_1_14    stock_lb_278  14
    x_1_14    stock_ub_279  14
    x_1_14    parent_nonstrict_scope_280  6.0000000000000019e-02
    x_1_14    unique_nonzero_owner_369  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_14    product_lb_67  1
    w_1_14    product_ub_68  1
    w_1_14    normalized_mass_1_80  1
    w_1_14    normalized_ratio_1_81  -1.4000000000000001e+00
    w_1_14    full_original_Gini_338  -1.4523809523809531e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_15    product_lb_69  -2.5263157894711577e-02
    x_1_15    product_ub_70  -0.042962356792187
    x_1_15    onehot_1_79  1
    x_1_15    stock_lb_278  15
    x_1_15    stock_ub_279  15
    x_1_15    parent_nonstrict_scope_280  0.075
    x_1_15    unique_nonzero_owner_370  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_15    product_lb_69  1
    w_1_15    product_ub_70  1
    w_1_15    normalized_mass_1_80  1
    w_1_15    normalized_ratio_1_81  -1.5
    w_1_15    full_original_Gini_338  -1.7223809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_16    OBJ       1.5000000000000013e-02
    x_1_16    product_lb_71  -2.5263157894711577e-02
    x_1_16    product_ub_72  -0.042962356792187
    x_1_16    onehot_1_79  1
    x_1_16    stock_lb_278  16
    x_1_16    stock_ub_279  16
    x_1_16    parent_nonstrict_scope_280  9.0000000000000011e-02
    x_1_16    unique_nonzero_owner_371  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_16    product_lb_71  1
    w_1_16    product_ub_72  1
    w_1_16    normalized_mass_1_80  1
    w_1_16    normalized_ratio_1_81  -1.6
    w_1_16    full_original_Gini_338  -1.9923809523809528e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_17    OBJ       3.0000000000000027e-02
    x_1_17    product_lb_73  -2.5263157894711577e-02
    x_1_17    product_ub_74  -0.042962356792187
    x_1_17    onehot_1_79  1
    x_1_17    stock_lb_278  17
    x_1_17    stock_ub_279  17
    x_1_17    parent_nonstrict_scope_280  1.0500000000000002e-01
    x_1_17    unique_nonzero_owner_372  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_17    product_lb_73  1
    w_1_17    product_ub_74  1
    w_1_17    normalized_mass_1_80  1
    w_1_17    normalized_ratio_1_81  -1.7000000000000002e+00
    w_1_17    full_original_Gini_338  -2.2623809523809523e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_18    OBJ       0.045
    x_1_18    product_lb_75  -2.5263157894711577e-02
    x_1_18    product_ub_76  -0.042962356792187
    x_1_18    onehot_1_79  1
    x_1_18    stock_lb_278  18
    x_1_18    stock_ub_279  18
    x_1_18    parent_nonstrict_scope_280  0.12
    x_1_18    unique_nonzero_owner_373  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_18    product_lb_75  1
    w_1_18    product_ub_76  1
    w_1_18    normalized_mass_1_80  1
    w_1_18    normalized_ratio_1_81  -1.8
    w_1_18    full_original_Gini_338  -2.5323809523809530e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_19    OBJ       6.0000000000000012e-02
    x_1_19    product_lb_77  -2.5263157894711577e-02
    x_1_19    product_ub_78  -0.042962356792187
    x_1_19    onehot_1_79  1
    x_1_19    stock_lb_278  19
    x_1_19    stock_ub_279  19
    x_1_19    parent_nonstrict_scope_280  0.135
    x_1_19    unique_nonzero_owner_374  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_19    product_lb_77  1
    w_1_19    product_ub_78  1
    w_1_19    normalized_mass_1_80  1
    w_1_19    normalized_ratio_1_81  -1.9000000000000001e+00
    w_1_19    full_original_Gini_338  -2.8023809523809522e+01
    rho_1     normalized_ratio_1_81  1
    rho_1     block_pair_pos_281  -1
    rho_1     block_pair_neg_282  1
    rho_1     block_pair_pos_283  -1
    rho_1     block_pair_neg_284  1
    rho_1     block_pair_pos_285  -1
    rho_1     block_pair_neg_286  1
    rho_1     block_pair_pos_287  -1
    rho_1     block_pair_neg_288  1
    rho_1     block_pair_pos_289  -1
    rho_1     block_pair_neg_290  1
    rho_1     block_pair_pos_291  -1
    rho_1     block_pair_neg_292  1
    rho_1     block_pair_pos_293  1
    rho_1     block_pair_neg_294  -1
    rho_1     normalization_337  1
    MARKER    'MARKER'                 'INTORG'
    x_31_0    OBJ       0.03675
    x_31_0    product_lb_82  -2.5263157894711577e-02
    x_31_0    product_ub_83  -0.042962356792187
    x_31_0    onehot_31_108  1
    x_31_0    parent_nonstrict_scope_280  0.0735
    x_31_0    unique_nonzero_owner_375  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_0    product_lb_82  1
    w_31_0    product_ub_83  1
    w_31_0    normalized_mass_31_109  1
    w_31_0    full_original_Gini_338  -2.3276190476190479e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_1    OBJ       2.6250000000000002e-02
    x_31_1    product_lb_84  -2.5263157894711577e-02
    x_31_1    product_ub_85  -0.042962356792187
    x_31_1    onehot_31_108  1
    x_31_1    stock_lb_278  1
    x_31_1    stock_ub_279  1
    x_31_1    parent_nonstrict_scope_280  0.063
    x_31_1    unique_nonzero_owner_376  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_1    product_lb_84  1
    w_31_1    product_ub_85  1
    w_31_1    normalized_mass_31_109  1
    w_31_1    normalized_ratio_31_110  -1.4285714285714285e-01
    w_31_1    full_original_Gini_338  -1.9704761904761909e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_2    OBJ       0.01575
    x_31_2    product_lb_86  -2.5263157894711577e-02
    x_31_2    product_ub_87  -0.042962356792187
    x_31_2    onehot_31_108  1
    x_31_2    stock_lb_278  2
    x_31_2    stock_ub_279  2
    x_31_2    parent_nonstrict_scope_280  0.0525
    MARKER    'MARKER'                 'INTEND'
    w_31_2    product_lb_86  1
    w_31_2    product_ub_87  1
    w_31_2    normalized_mass_31_109  1
    w_31_2    normalized_ratio_31_110  -2.8571428571428570e-01
    w_31_2    full_original_Gini_338  -1.6133333333333329e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_3    OBJ       5.2499999999999977e-03
    x_31_3    product_lb_88  -2.5263157894711577e-02
    x_31_3    product_ub_89  -0.042962356792187
    x_31_3    onehot_31_108  1
    x_31_3    stock_lb_278  3
    x_31_3    stock_ub_279  3
    x_31_3    parent_nonstrict_scope_280  4.1999999999999996e-02
    x_31_3    unique_nonzero_owner_377  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_3    product_lb_88  1
    w_31_3    product_ub_89  1
    w_31_3    normalized_mass_31_109  1
    w_31_3    normalized_ratio_31_110  -4.2857142857142855e-01
    w_31_3    full_original_Gini_338  -1.2676190476190474e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_4    OBJ       -5.2499999999999977e-03
    x_31_4    product_lb_90  -2.5263157894711577e-02
    x_31_4    product_ub_91  -0.042962356792187
    x_31_4    onehot_31_108  1
    x_31_4    stock_lb_278  4
    x_31_4    stock_ub_279  4
    x_31_4    parent_nonstrict_scope_280  0.0315
    x_31_4    unique_nonzero_owner_378  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_4    product_lb_90  1
    w_31_4    product_ub_91  1
    w_31_4    normalized_mass_31_109  1
    w_31_4    normalized_ratio_31_110  -5.7142857142857140e-01
    w_31_4    full_original_Gini_338  -9.67619047619048
    MARKER    'MARKER'                 'INTORG'
    x_31_5    OBJ       -1.5749999999999993e-02
    x_31_5    product_lb_92  -2.5263157894711577e-02
    x_31_5    product_ub_93  -0.042962356792187
    x_31_5    onehot_31_108  1
    x_31_5    stock_lb_278  5
    x_31_5    stock_ub_279  5
    x_31_5    parent_nonstrict_scope_280  2.1000000000000005e-02
    x_31_5    unique_nonzero_owner_379  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_5    product_lb_92  1
    w_31_5    product_ub_93  1
    w_31_5    normalized_mass_31_109  1
    w_31_5    normalized_ratio_31_110  -7.1428571428571419e-01
    w_31_5    full_original_Gini_338  -6.6761904761904773e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_6    OBJ       -2.6249999999999996e-02
    x_31_6    product_lb_94  -2.5263157894711577e-02
    x_31_6    product_ub_95  -0.042962356792187
    x_31_6    onehot_31_108  1
    x_31_6    stock_lb_278  6
    x_31_6    stock_ub_279  6
    x_31_6    parent_nonstrict_scope_280  1.0500000000000002e-02
    x_31_6    unique_nonzero_owner_380  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_6    product_lb_94  1
    w_31_6    product_ub_95  1
    w_31_6    normalized_mass_31_109  1
    w_31_6    normalized_ratio_31_110  -8.5714285714285710e-01
    w_31_6    full_original_Gini_338  -4.4095238095238090e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_7    OBJ       -0.03675
    x_31_7    product_lb_96  -2.5263157894711577e-02
    x_31_7    product_ub_97  -0.042962356792187
    x_31_7    onehot_31_108  1
    x_31_7    stock_lb_278  7
    x_31_7    stock_ub_279  7
    x_31_7    unique_nonzero_owner_381  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_7    product_lb_96  1
    w_31_7    product_ub_97  1
    w_31_7    normalized_mass_31_109  1
    w_31_7    normalized_ratio_31_110  -1
    w_31_7    full_original_Gini_338  -4.1238095238095234e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_8    OBJ       -2.6250000000000002e-02
    x_31_8    product_lb_98  -2.5263157894711577e-02
    x_31_8    product_ub_99  -0.042962356792187
    x_31_8    onehot_31_108  1
    x_31_8    stock_lb_278  8
    x_31_8    stock_ub_279  8
    x_31_8    parent_nonstrict_scope_280  1.0499999999999995e-02
    x_31_8    unique_nonzero_owner_382  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_8    product_lb_98  1
    w_31_8    product_ub_99  1
    w_31_8    normalized_mass_31_109  1
    w_31_8    normalized_ratio_31_110  -1.1428571428571428e+00
    w_31_8    full_original_Gini_338  -7.6952380952380928e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_9    OBJ       -1.5750000000000007e-02
    x_31_9    product_lb_100  -2.5263157894711577e-02
    x_31_9    product_ub_101  -0.042962356792187
    x_31_9    onehot_31_108  1
    x_31_9    stock_lb_278  9
    x_31_9    stock_ub_279  9
    x_31_9    parent_nonstrict_scope_280  2.0999999999999991e-02
    x_31_9    unique_nonzero_owner_383  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_9    product_lb_100  1
    w_31_9    product_ub_101  1
    w_31_9    normalized_mass_31_109  1
    w_31_9    normalized_ratio_31_110  -1.2857142857142856e+00
    w_31_9    full_original_Gini_338  -1.1438095238095233e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_10   OBJ       -5.2500000000000116e-03
    x_31_10   product_lb_102  -2.5263157894711577e-02
    x_31_10   product_ub_103  -0.042962356792187
    x_31_10   onehot_31_108  1
    x_31_10   stock_lb_278  10
    x_31_10   stock_ub_279  10
    x_31_10   parent_nonstrict_scope_280  3.1499999999999986e-02
    x_31_10   unique_nonzero_owner_384  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_10   product_lb_102  1
    w_31_10   product_ub_103  1
    w_31_10   normalized_mass_31_109  1
    w_31_10   normalized_ratio_31_110  -1.4285714285714284e+00
    w_31_10   full_original_Gini_338  -1.5295238095238096e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_11   OBJ       5.2499999999999977e-03
    x_31_11   product_lb_104  -2.5263157894711577e-02
    x_31_11   product_ub_105  -0.042962356792187
    x_31_11   onehot_31_108  1
    x_31_11   stock_lb_278  11
    x_31_11   stock_ub_279  11
    x_31_11   parent_nonstrict_scope_280  4.1999999999999996e-02
    x_31_11   unique_nonzero_owner_385  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_11   product_lb_104  1
    w_31_11   product_ub_105  1
    w_31_11   normalized_mass_31_109  1
    w_31_11   normalized_ratio_31_110  -1.5714285714285714e+00
    w_31_11   full_original_Gini_338  -1.9152380952380952e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_12   OBJ       1.5749999999999993e-02
    x_31_12   product_lb_106  -2.5263157894711577e-02
    x_31_12   product_ub_107  -0.042962356792187
    x_31_12   onehot_31_108  1
    x_31_12   stock_lb_278  12
    x_31_12   stock_ub_279  12
    x_31_12   parent_nonstrict_scope_280  5.2499999999999991e-02
    x_31_12   unique_nonzero_owner_386  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_12   product_lb_106  1
    w_31_12   product_ub_107  1
    w_31_12   normalized_mass_31_109  1
    w_31_12   normalized_ratio_31_110  -1.7142857142857142e+00
    w_31_12   full_original_Gini_338  -2.3009523809523809e+01
    rho_31    normalized_ratio_31_110  1
    rho_31    block_pair_pos_289  1
    rho_31    block_pair_neg_290  -1
    rho_31    block_pair_pos_303  1
    rho_31    block_pair_neg_304  -1
    rho_31    block_pair_pos_321  -1
    rho_31    block_pair_neg_322  1
    rho_31    block_pair_pos_323  -1
    rho_31    block_pair_neg_324  1
    rho_31    block_pair_pos_325  -1
    rho_31    block_pair_neg_326  1
    rho_31    block_pair_pos_327  -1
    rho_31    block_pair_neg_328  1
    rho_31    block_pair_pos_329  -1
    rho_31    block_pair_neg_330  1
    rho_31    normalization_337  1
    MARKER    'MARKER'                 'INTORG'
    x_7_0     OBJ       0.042
    x_7_0     product_lb_111  -2.5263157894711577e-02
    x_7_0     product_ub_112  -0.042962356792187
    x_7_0     onehot_7_147  1
    x_7_0     parent_nonstrict_scope_280  0.096
    x_7_0     unique_nonzero_owner_387  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_0     product_lb_111  1
    w_7_0     product_ub_112  1
    w_7_0     normalized_mass_7_148  1
    w_7_0     full_original_Gini_338  -2.3276190476190479e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_1     OBJ       3.0000000000000006e-02
    x_7_1     product_lb_113  -2.5263157894711577e-02
    x_7_1     product_ub_114  -0.042962356792187
    x_7_1     onehot_7_147  1
    x_7_1     stock_lb_278  1
    x_7_1     stock_ub_279  1
    x_7_1     parent_nonstrict_scope_280  0.084
    x_7_1     unique_nonzero_owner_388  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_1     product_lb_113  1
    w_7_1     product_ub_114  1
    w_7_1     normalized_mass_7_148  1
    w_7_1     normalized_ratio_7_149  -0.125
    w_7_1     full_original_Gini_338  -2.0151190476190475e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_2     OBJ       1.8000000000000009e-02
    x_7_2     product_lb_115  -2.5263157894711577e-02
    x_7_2     product_ub_116  -0.042962356792187
    x_7_2     onehot_7_147  1
    x_7_2     stock_lb_278  2
    x_7_2     stock_ub_279  2
    x_7_2     parent_nonstrict_scope_280  7.2000000000000008e-02
    x_7_2     unique_nonzero_owner_389  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_2     product_lb_115  1
    w_7_2     product_ub_116  1
    w_7_2     normalized_mass_7_148  1
    w_7_2     normalized_ratio_7_149  -0.25
    w_7_2     full_original_Gini_338  -1.7026190476190475e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_3     OBJ       5.9999999999999984e-03
    x_7_3     product_lb_117  -2.5263157894711577e-02
    x_7_3     product_ub_118  -0.042962356792187
    x_7_3     onehot_7_147  1
    x_7_3     stock_lb_278  3
    x_7_3     stock_ub_279  3
    x_7_3     parent_nonstrict_scope_280  0.06
    x_7_3     unique_nonzero_owner_390  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_3     product_lb_117  1
    w_7_3     product_ub_118  1
    w_7_3     normalized_mass_7_148  1
    w_7_3     normalized_ratio_7_149  -0.375
    w_7_3     full_original_Gini_338  -1.3901190476190477e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_4     OBJ       -5.9999999999999984e-03
    x_7_4     product_lb_119  -2.5263157894711577e-02
    x_7_4     product_ub_120  -0.042962356792187
    x_7_4     onehot_7_147  1
    x_7_4     stock_lb_278  4
    x_7_4     stock_ub_279  4
    x_7_4     parent_nonstrict_scope_280  0.048
    x_7_4     unique_nonzero_owner_391  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_4     product_lb_119  1
    w_7_4     product_ub_120  1
    w_7_4     normalized_mass_7_148  1
    w_7_4     normalized_ratio_7_149  -0.5
    w_7_4     full_original_Gini_338  -1.1176190476190476e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_5     OBJ       -1.7999999999999995e-02
    x_7_5     product_lb_121  -2.5263157894711577e-02
    x_7_5     product_ub_122  -0.042962356792187
    x_7_5     onehot_7_147  1
    x_7_5     stock_lb_278  5
    x_7_5     stock_ub_279  5
    x_7_5     parent_nonstrict_scope_280  3.6000000000000004e-02
    x_7_5     unique_nonzero_owner_392  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_5     product_lb_121  1
    w_7_5     product_ub_122  1
    w_7_5     normalized_mass_7_148  1
    w_7_5     normalized_ratio_7_149  -0.625
    w_7_5     full_original_Gini_338  -8.5511904761904756e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_6     OBJ       -0.03
    x_7_6     product_lb_123  -2.5263157894711577e-02
    x_7_6     product_ub_124  -0.042962356792187
    x_7_6     onehot_7_147  1
    x_7_6     stock_lb_278  6
    x_7_6     stock_ub_279  6
    x_7_6     parent_nonstrict_scope_280  0.024
    x_7_6     unique_nonzero_owner_393  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_6     product_lb_123  1
    w_7_6     product_ub_124  1
    w_7_6     normalized_mass_7_148  1
    w_7_6     normalized_ratio_7_149  -0.75
    w_7_6     full_original_Gini_338  -6.0690476190476188e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_7     OBJ       -4.1999999999999996e-02
    x_7_7     product_lb_125  -2.5263157894711577e-02
    x_7_7     product_ub_126  -0.042962356792187
    x_7_7     onehot_7_147  1
    x_7_7     stock_lb_278  7
    x_7_7     stock_ub_279  7
    x_7_7     parent_nonstrict_scope_280  0.012
    x_7_7     unique_nonzero_owner_394  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_7     product_lb_125  1
    w_7_7     product_ub_126  1
    w_7_7     normalized_mass_7_148  1
    w_7_7     normalized_ratio_7_149  -0.875
    w_7_7     full_original_Gini_338  -4.2488095238095234e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_8     OBJ       -0.054
    x_7_8     product_lb_127  -2.5263157894711577e-02
    x_7_8     product_ub_128  -0.042962356792187
    x_7_8     onehot_7_147  1
    x_7_8     stock_lb_278  8
    x_7_8     stock_ub_279  8
    x_7_8     unique_nonzero_owner_395  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_8     product_lb_127  1
    w_7_8     product_ub_128  1
    w_7_8     normalized_mass_7_148  1
    w_7_8     normalized_ratio_7_149  -1
    w_7_8     full_original_Gini_338  -4.1238095238095234e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_9     OBJ       -4.1999999999999996e-02
    x_7_9     product_lb_129  -2.5263157894711577e-02
    x_7_9     product_ub_130  -0.042962356792187
    x_7_9     onehot_7_147  1
    x_7_9     stock_lb_278  9
    x_7_9     stock_ub_279  9
    x_7_9     parent_nonstrict_scope_280  0.012
    x_7_9     unique_nonzero_owner_396  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_9     product_lb_129  1
    w_7_9     product_ub_130  1
    w_7_9     normalized_mass_7_148  1
    w_7_9     normalized_ratio_7_149  -1.125
    w_7_9     full_original_Gini_338  -7.2488095238095251e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_10    OBJ       -0.03
    x_7_10    product_lb_131  -2.5263157894711577e-02
    x_7_10    product_ub_132  -0.042962356792187
    x_7_10    onehot_7_147  1
    x_7_10    stock_lb_278  10
    x_7_10    stock_ub_279  10
    x_7_10    parent_nonstrict_scope_280  0.024
    x_7_10    unique_nonzero_owner_397  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_10    product_lb_131  1
    w_7_10    product_ub_132  1
    w_7_10    normalized_mass_7_148  1
    w_7_10    normalized_ratio_7_149  -1.25
    w_7_10    full_original_Gini_338  -1.0473809523809523e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_11    OBJ       -1.7999999999999995e-02
    x_7_11    product_lb_133  -2.5263157894711577e-02
    x_7_11    product_ub_134  -0.042962356792187
    x_7_11    onehot_7_147  1
    x_7_11    stock_lb_278  11
    x_7_11    stock_ub_279  11
    x_7_11    parent_nonstrict_scope_280  3.6000000000000004e-02
    x_7_11    unique_nonzero_owner_398  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_11    product_lb_133  1
    w_7_11    product_ub_134  1
    w_7_11    normalized_mass_7_148  1
    w_7_11    normalized_ratio_7_149  -1.375
    w_7_11    full_original_Gini_338  -1.3848809523809523e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_12    OBJ       -5.9999999999999984e-03
    x_7_12    product_lb_135  -2.5263157894711577e-02
    x_7_12    product_ub_136  -0.042962356792187
    x_7_12    onehot_7_147  1
    x_7_12    stock_lb_278  12
    x_7_12    stock_ub_279  12
    x_7_12    parent_nonstrict_scope_280  0.048
    MARKER    'MARKER'                 'INTEND'
    w_7_12    product_lb_135  1
    w_7_12    product_ub_136  1
    w_7_12    normalized_mass_7_148  1
    w_7_12    normalized_ratio_7_149  -1.5
    w_7_12    full_original_Gini_338  -1.7223809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_13    OBJ       5.9999999999999984e-03
    x_7_13    product_lb_137  -2.5263157894711577e-02
    x_7_13    product_ub_138  -0.042962356792187
    x_7_13    onehot_7_147  1
    x_7_13    stock_lb_278  13
    x_7_13    stock_ub_279  13
    x_7_13    parent_nonstrict_scope_280  0.06
    x_7_13    unique_nonzero_owner_399  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_13    product_lb_137  1
    w_7_13    product_ub_138  1
    w_7_13    normalized_mass_7_148  1
    w_7_13    normalized_ratio_7_149  -1.625
    w_7_13    full_original_Gini_338  -2.0598809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_14    OBJ       1.8000000000000009e-02
    x_7_14    product_lb_139  -2.5263157894711577e-02
    x_7_14    product_ub_140  -0.042962356792187
    x_7_14    onehot_7_147  1
    x_7_14    stock_lb_278  14
    x_7_14    stock_ub_279  14
    x_7_14    parent_nonstrict_scope_280  7.2000000000000008e-02
    x_7_14    unique_nonzero_owner_400  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_14    product_lb_139  1
    w_7_14    product_ub_140  1
    w_7_14    normalized_mass_7_148  1
    w_7_14    normalized_ratio_7_149  -1.75
    w_7_14    full_original_Gini_338  -2.3973809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_15    OBJ       3.0000000000000006e-02
    x_7_15    product_lb_141  -2.5263157894711577e-02
    x_7_15    product_ub_142  -0.042962356792187
    x_7_15    onehot_7_147  1
    x_7_15    stock_lb_278  15
    x_7_15    stock_ub_279  15
    x_7_15    parent_nonstrict_scope_280  0.084
    x_7_15    unique_nonzero_owner_401  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_15    product_lb_141  1
    w_7_15    product_ub_142  1
    w_7_15    normalized_mass_7_148  1
    w_7_15    normalized_ratio_7_149  -1.875
    w_7_15    full_original_Gini_338  -2.7348809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_16    OBJ       0.042
    x_7_16    product_lb_143  -2.5263157894711577e-02
    x_7_16    product_ub_144  -0.042962356792187
    x_7_16    onehot_7_147  1
    x_7_16    stock_lb_278  16
    x_7_16    stock_ub_279  16
    x_7_16    parent_nonstrict_scope_280  0.096
    x_7_16    unique_nonzero_owner_402  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_16    product_lb_143  1
    w_7_16    product_ub_144  1
    w_7_16    normalized_mass_7_148  1
    w_7_16    normalized_ratio_7_149  -2
    w_7_16    full_original_Gini_338  -3.0723809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_17    OBJ       0.054
    x_7_17    product_lb_145  -2.5263157894711577e-02
    x_7_17    product_ub_146  -0.042962356792187
    x_7_17    onehot_7_147  1
    x_7_17    stock_lb_278  17
    x_7_17    stock_ub_279  17
    x_7_17    parent_nonstrict_scope_280  0.108
    x_7_17    unique_nonzero_owner_403  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_17    product_lb_145  1
    w_7_17    product_ub_146  1
    w_7_17    normalized_mass_7_148  1
    w_7_17    normalized_ratio_7_149  -2.125
    w_7_17    full_original_Gini_338  -3.4098809523809521e+01
    rho_7     normalized_ratio_7_149  1
    rho_7     block_pair_pos_283  1
    rho_7     block_pair_neg_284  -1
    rho_7     block_pair_pos_297  1
    rho_7     block_pair_neg_298  -1
    rho_7     block_pair_pos_311  -1
    rho_7     block_pair_neg_312  1
    rho_7     block_pair_pos_313  -1
    rho_7     block_pair_neg_314  1
    rho_7     block_pair_pos_315  -1
    rho_7     block_pair_neg_316  1
    rho_7     block_pair_pos_317  -1
    rho_7     block_pair_neg_318  1
    rho_7     block_pair_pos_323  1
    rho_7     block_pair_neg_324  -1
    rho_7     normalization_337  1
    MARKER    'MARKER'                 'INTORG'
    x_32_0    OBJ       1.1249999999999993e-02
    x_32_0    product_lb_150  -2.5263157894711577e-02
    x_32_0    product_ub_151  -0.042962356792187
    x_32_0    onehot_32_176  1
    x_32_0    parent_nonstrict_scope_280  0.0375
    MARKER    'MARKER'                 'INTEND'
    w_32_0    product_lb_150  1
    w_32_0    product_ub_151  1
    w_32_0    normalized_mass_32_177  1
    w_32_0    full_original_Gini_338  -2.3276190476190479e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_1    OBJ       3.7499999999999929e-03
    x_32_1    product_lb_152  -2.5263157894711577e-02
    x_32_1    product_ub_153  -0.042962356792187
    x_32_1    onehot_32_176  1
    x_32_1    stock_lb_278  1
    x_32_1    stock_ub_279  1
    x_32_1    parent_nonstrict_scope_280  0.03
    x_32_1    unique_nonzero_owner_404  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_1    product_lb_152  1
    w_32_1    product_ub_153  1
    w_32_1    normalized_mass_32_177  1
    w_32_1    normalized_ratio_32_178  -0.2
    w_32_1    full_original_Gini_338  -1.8276190476190482e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_2    OBJ       -3.7500000000000068e-03
    x_32_2    product_lb_154  -2.5263157894711577e-02
    x_32_2    product_ub_155  -0.042962356792187
    x_32_2    onehot_32_176  1
    x_32_2    stock_lb_278  2
    x_32_2    stock_ub_279  2
    x_32_2    parent_nonstrict_scope_280  0.0225
    x_32_2    unique_nonzero_owner_405  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_2    product_lb_154  1
    w_32_2    product_ub_155  1
    w_32_2    normalized_mass_32_177  1
    w_32_2    normalized_ratio_32_178  -0.4
    w_32_2    full_original_Gini_338  -1.3276190476190473e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_3    OBJ       -1.1250000000000010e-02
    x_32_3    product_lb_156  -2.5263157894711577e-02
    x_32_3    product_ub_157  -0.042962356792187
    x_32_3    onehot_32_176  1
    x_32_3    stock_lb_278  3
    x_32_3    stock_ub_279  3
    x_32_3    parent_nonstrict_scope_280  1.4999999999999996e-02
    x_32_3    unique_nonzero_owner_406  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_3    product_lb_156  1
    w_32_3    product_ub_157  1
    w_32_3    normalized_mass_32_177  1
    w_32_3    normalized_ratio_32_178  -6.0000000000000009e-01
    w_32_3    full_original_Gini_338  -9.0761904761904759e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_4    OBJ       -1.8750000000000010e-02
    x_32_4    product_lb_158  -2.5263157894711577e-02
    x_32_4    product_ub_159  -0.042962356792187
    x_32_4    onehot_32_176  1
    x_32_4    stock_lb_278  4
    x_32_4    stock_ub_279  4
    x_32_4    parent_nonstrict_scope_280  7.4999999999999980e-03
    x_32_4    unique_nonzero_owner_407  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_4    product_lb_158  1
    w_32_4    product_ub_159  1
    w_32_4    normalized_mass_32_177  1
    w_32_4    normalized_ratio_32_178  -0.8
    w_32_4    full_original_Gini_338  -5.2190476190476209e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_5    OBJ       -2.6250000000000006e-02
    x_32_5    product_lb_160  -2.5263157894711577e-02
    x_32_5    product_ub_161  -0.042962356792187
    x_32_5    onehot_32_176  1
    x_32_5    stock_lb_278  5
    x_32_5    stock_ub_279  5
    x_32_5    unique_nonzero_owner_408  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_5    product_lb_160  1
    w_32_5    product_ub_161  1
    w_32_5    normalized_mass_32_177  1
    w_32_5    normalized_ratio_32_178  -1
    w_32_5    full_original_Gini_338  -4.1238095238095234e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_6    OBJ       -0.01875
    x_32_6    product_lb_162  -2.5263157894711577e-02
    x_32_6    product_ub_163  -0.042962356792187
    x_32_6    onehot_32_176  1
    x_32_6    stock_lb_278  6
    x_32_6    stock_ub_279  6
    x_32_6    parent_nonstrict_scope_280  7.5000000000000067e-03
    x_32_6    unique_nonzero_owner_409  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_6    product_lb_162  1
    w_32_6    product_ub_163  1
    w_32_6    normalized_mass_32_177  1
    w_32_6    normalized_ratio_32_178  -1.2000000000000002e+00
    w_32_6    full_original_Gini_338  -9.12380952380953
    MARKER    'MARKER'                 'INTORG'
    x_32_7    OBJ       -1.1250000000000001e-02
    x_32_7    product_lb_164  -2.5263157894711577e-02
    x_32_7    product_ub_165  -0.042962356792187
    x_32_7    onehot_32_176  1
    x_32_7    stock_lb_278  7
    x_32_7    stock_ub_279  7
    x_32_7    parent_nonstrict_scope_280  1.5000000000000005e-02
    x_32_7    unique_nonzero_owner_410  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_7    product_lb_164  1
    w_32_7    product_ub_165  1
    w_32_7    normalized_mass_32_177  1
    w_32_7    normalized_ratio_32_178  -1.4000000000000001e+00
    w_32_7    full_original_Gini_338  -1.4523809523809531e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_8    OBJ       -3.7500000000000033e-03
    x_32_8    product_lb_166  -2.5263157894711577e-02
    x_32_8    product_ub_167  -0.042962356792187
    x_32_8    onehot_32_176  1
    x_32_8    stock_lb_278  8
    x_32_8    stock_ub_279  8
    x_32_8    parent_nonstrict_scope_280  2.2500000000000003e-02
    x_32_8    unique_nonzero_owner_411  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_8    product_lb_166  1
    w_32_8    product_ub_167  1
    w_32_8    normalized_mass_32_177  1
    w_32_8    normalized_ratio_32_178  -1.6
    w_32_8    full_original_Gini_338  -1.9923809523809528e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_9    OBJ       3.7499999999999929e-03
    x_32_9    product_lb_168  -2.5263157894711577e-02
    x_32_9    product_ub_169  -0.042962356792187
    x_32_9    onehot_32_176  1
    x_32_9    stock_lb_278  9
    x_32_9    stock_ub_279  9
    x_32_9    parent_nonstrict_scope_280  0.03
    x_32_9    unique_nonzero_owner_412  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_9    product_lb_168  1
    w_32_9    product_ub_169  1
    w_32_9    normalized_mass_32_177  1
    w_32_9    normalized_ratio_32_178  -1.8
    w_32_9    full_original_Gini_338  -2.5323809523809530e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_10   OBJ       1.1249999999999993e-02
    x_32_10   product_lb_170  -2.5263157894711577e-02
    x_32_10   product_ub_171  -0.042962356792187
    x_32_10   onehot_32_176  1
    x_32_10   stock_lb_278  10
    x_32_10   stock_ub_279  10
    x_32_10   parent_nonstrict_scope_280  0.0375
    x_32_10   unique_nonzero_owner_413  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_10   product_lb_170  1
    w_32_10   product_ub_171  1
    w_32_10   normalized_mass_32_177  1
    w_32_10   normalized_ratio_32_178  -2
    w_32_10   full_original_Gini_338  -3.0723809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_11   OBJ       0.01875
    x_32_11   product_lb_172  -2.5263157894711577e-02
    x_32_11   product_ub_173  -0.042962356792187
    x_32_11   onehot_32_176  1
    x_32_11   stock_lb_278  11
    x_32_11   stock_ub_279  11
    x_32_11   parent_nonstrict_scope_280  4.5000000000000005e-02
    x_32_11   unique_nonzero_owner_414  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_11   product_lb_172  1
    w_32_11   product_ub_173  1
    w_32_11   normalized_mass_32_177  1
    w_32_11   normalized_ratio_32_178  -2.2
    w_32_11   full_original_Gini_338  -3.6123809523809513e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_12   OBJ       2.6250000000000006e-02
    x_32_12   product_lb_174  -2.5263157894711577e-02
    x_32_12   product_ub_175  -0.042962356792187
    x_32_12   onehot_32_176  1
    x_32_12   stock_lb_278  12
    x_32_12   stock_ub_279  12
    x_32_12   parent_nonstrict_scope_280  5.2500000000000012e-02
    x_32_12   unique_nonzero_owner_415  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_12   product_lb_174  1
    w_32_12   product_ub_175  1
    w_32_12   normalized_mass_32_177  1
    w_32_12   normalized_ratio_32_178  -2.4000000000000004e+00
    w_32_12   full_original_Gini_338  -4.1523809523809518e+01
    rho_32    normalized_ratio_32_178  1
    rho_32    block_pair_pos_291  1
    rho_32    block_pair_neg_292  -1
    rho_32    block_pair_pos_305  1
    rho_32    block_pair_neg_306  -1
    rho_32    block_pair_pos_317  1
    rho_32    block_pair_neg_318  -1
    rho_32    block_pair_pos_329  1
    rho_32    block_pair_neg_330  -1
    rho_32    block_pair_pos_331  -1
    rho_32    block_pair_neg_332  1
    rho_32    block_pair_pos_333  -1
    rho_32    block_pair_neg_334  1
    rho_32    block_pair_pos_335  -1
    rho_32    block_pair_neg_336  1
    rho_32    normalization_337  1
    MARKER    'MARKER'                 'INTORG'
    x_4_0     OBJ       0.0315
    x_4_0     product_lb_179  -2.5263157894711577e-02
    x_4_0     product_ub_180  -0.042962356792187
    x_4_0     onehot_4_211  1
    x_4_0     parent_nonstrict_scope_280  0.0735
    x_4_0     unique_nonzero_owner_416  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_0     product_lb_179  1
    w_4_0     product_ub_180  1
    w_4_0     normalized_mass_4_212  1
    w_4_0     full_original_Gini_338  -2.3276190476190479e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_1     OBJ       2.1000000000000005e-02
    x_4_1     product_lb_181  -2.5263157894711577e-02
    x_4_1     product_ub_182  -0.042962356792187
    x_4_1     onehot_4_211  1
    x_4_1     stock_lb_278  1
    x_4_1     stock_ub_279  1
    x_4_1     parent_nonstrict_scope_280  0.063
    x_4_1     unique_nonzero_owner_417  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_1     product_lb_181  1
    w_4_1     product_ub_182  1
    w_4_1     normalized_mass_4_212  1
    w_4_1     normalized_ratio_4_213  -1.4285714285714285e-01
    w_4_1     full_original_Gini_338  -1.9704761904761909e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_2     OBJ       1.0500000000000002e-02
    x_4_2     product_lb_183  -2.5263157894711577e-02
    x_4_2     product_ub_184  -0.042962356792187
    x_4_2     onehot_4_211  1
    x_4_2     stock_lb_278  2
    x_4_2     stock_ub_279  2
    x_4_2     parent_nonstrict_scope_280  0.0525
    x_4_2     unique_nonzero_owner_418  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_2     product_lb_183  1
    w_4_2     product_ub_184  1
    w_4_2     normalized_mass_4_212  1
    w_4_2     normalized_ratio_4_213  -2.8571428571428570e-01
    w_4_2     full_original_Gini_338  -1.6133333333333329e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_3     product_lb_185  -2.5263157894711577e-02
    x_4_3     product_ub_186  -0.042962356792187
    x_4_3     onehot_4_211  1
    x_4_3     stock_lb_278  3
    x_4_3     stock_ub_279  3
    x_4_3     parent_nonstrict_scope_280  4.1999999999999996e-02
    x_4_3     unique_nonzero_owner_419  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_3     product_lb_185  1
    w_4_3     product_ub_186  1
    w_4_3     normalized_mass_4_212  1
    w_4_3     normalized_ratio_4_213  -4.2857142857142855e-01
    w_4_3     full_original_Gini_338  -1.2676190476190474e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_4     OBJ       -1.0499999999999995e-02
    x_4_4     product_lb_187  -2.5263157894711577e-02
    x_4_4     product_ub_188  -0.042962356792187
    x_4_4     onehot_4_211  1
    x_4_4     stock_lb_278  4
    x_4_4     stock_ub_279  4
    x_4_4     parent_nonstrict_scope_280  0.0315
    x_4_4     unique_nonzero_owner_420  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_4     product_lb_187  1
    w_4_4     product_ub_188  1
    w_4_4     normalized_mass_4_212  1
    w_4_4     normalized_ratio_4_213  -5.7142857142857140e-01
    w_4_4     full_original_Gini_338  -9.67619047619048
    MARKER    'MARKER'                 'INTORG'
    x_4_5     OBJ       -2.0999999999999991e-02
    x_4_5     product_lb_189  -2.5263157894711577e-02
    x_4_5     product_ub_190  -0.042962356792187
    x_4_5     onehot_4_211  1
    x_4_5     stock_lb_278  5
    x_4_5     stock_ub_279  5
    x_4_5     parent_nonstrict_scope_280  2.1000000000000005e-02
    x_4_5     unique_nonzero_owner_421  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_5     product_lb_189  1
    w_4_5     product_ub_190  1
    w_4_5     normalized_mass_4_212  1
    w_4_5     normalized_ratio_4_213  -7.1428571428571419e-01
    w_4_5     full_original_Gini_338  -6.6761904761904773e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_6     OBJ       -3.1499999999999993e-02
    x_4_6     product_lb_191  -2.5263157894711577e-02
    x_4_6     product_ub_192  -0.042962356792187
    x_4_6     onehot_4_211  1
    x_4_6     stock_lb_278  6
    x_4_6     stock_ub_279  6
    x_4_6     parent_nonstrict_scope_280  1.0500000000000002e-02
    x_4_6     unique_nonzero_owner_422  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_6     product_lb_191  1
    w_4_6     product_ub_192  1
    w_4_6     normalized_mass_4_212  1
    w_4_6     normalized_ratio_4_213  -8.5714285714285710e-01
    w_4_6     full_original_Gini_338  -4.4095238095238090e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_7     OBJ       -4.1999999999999996e-02
    x_4_7     product_lb_193  -2.5263157894711577e-02
    x_4_7     product_ub_194  -0.042962356792187
    x_4_7     onehot_4_211  1
    x_4_7     stock_lb_278  7
    x_4_7     stock_ub_279  7
    x_4_7     unique_nonzero_owner_423  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_7     product_lb_193  1
    w_4_7     product_ub_194  1
    w_4_7     normalized_mass_4_212  1
    w_4_7     normalized_ratio_4_213  -1
    w_4_7     full_original_Gini_338  -4.1238095238095234e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_8     OBJ       -0.0315
    x_4_8     product_lb_195  -2.5263157894711577e-02
    x_4_8     product_ub_196  -0.042962356792187
    x_4_8     onehot_4_211  1
    x_4_8     stock_lb_278  8
    x_4_8     stock_ub_279  8
    x_4_8     parent_nonstrict_scope_280  1.0499999999999995e-02
    x_4_8     unique_nonzero_owner_424  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_8     product_lb_195  1
    w_4_8     product_ub_196  1
    w_4_8     normalized_mass_4_212  1
    w_4_8     normalized_ratio_4_213  -1.1428571428571428e+00
    w_4_8     full_original_Gini_338  -7.6952380952380928e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_9     OBJ       -2.1000000000000005e-02
    x_4_9     product_lb_197  -2.5263157894711577e-02
    x_4_9     product_ub_198  -0.042962356792187
    x_4_9     onehot_4_211  1
    x_4_9     stock_lb_278  9
    x_4_9     stock_ub_279  9
    x_4_9     parent_nonstrict_scope_280  2.0999999999999991e-02
    x_4_9     unique_nonzero_owner_425  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_9     product_lb_197  1
    w_4_9     product_ub_198  1
    w_4_9     normalized_mass_4_212  1
    w_4_9     normalized_ratio_4_213  -1.2857142857142856e+00
    w_4_9     full_original_Gini_338  -1.1438095238095233e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_10    OBJ       -1.0500000000000009e-02
    x_4_10    product_lb_199  -2.5263157894711577e-02
    x_4_10    product_ub_200  -0.042962356792187
    x_4_10    onehot_4_211  1
    x_4_10    stock_lb_278  10
    x_4_10    stock_ub_279  10
    x_4_10    parent_nonstrict_scope_280  3.1499999999999986e-02
    x_4_10    unique_nonzero_owner_426  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_10    product_lb_199  1
    w_4_10    product_ub_200  1
    w_4_10    normalized_mass_4_212  1
    w_4_10    normalized_ratio_4_213  -1.4285714285714284e+00
    w_4_10    full_original_Gini_338  -1.5295238095238096e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_11    product_lb_201  -2.5263157894711577e-02
    x_4_11    product_ub_202  -0.042962356792187
    x_4_11    onehot_4_211  1
    x_4_11    stock_lb_278  11
    x_4_11    stock_ub_279  11
    x_4_11    parent_nonstrict_scope_280  4.1999999999999996e-02
    MARKER    'MARKER'                 'INTEND'
    w_4_11    product_lb_201  1
    w_4_11    product_ub_202  1
    w_4_11    normalized_mass_4_212  1
    w_4_11    normalized_ratio_4_213  -1.5714285714285714e+00
    w_4_11    full_original_Gini_338  -1.9152380952380952e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_12    OBJ       1.0499999999999995e-02
    x_4_12    product_lb_203  -2.5263157894711577e-02
    x_4_12    product_ub_204  -0.042962356792187
    x_4_12    onehot_4_211  1
    x_4_12    stock_lb_278  12
    x_4_12    stock_ub_279  12
    x_4_12    parent_nonstrict_scope_280  5.2499999999999991e-02
    x_4_12    unique_nonzero_owner_427  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_12    product_lb_203  1
    w_4_12    product_ub_204  1
    w_4_12    normalized_mass_4_212  1
    w_4_12    normalized_ratio_4_213  -1.7142857142857142e+00
    w_4_12    full_original_Gini_338  -2.3009523809523809e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_13    OBJ       2.0999999999999991e-02
    x_4_13    product_lb_205  -2.5263157894711577e-02
    x_4_13    product_ub_206  -0.042962356792187
    x_4_13    onehot_4_211  1
    x_4_13    stock_lb_278  13
    x_4_13    stock_ub_279  13
    x_4_13    parent_nonstrict_scope_280  6.2999999999999987e-02
    x_4_13    unique_nonzero_owner_428  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_13    product_lb_205  1
    w_4_13    product_ub_206  1
    w_4_13    normalized_mass_4_212  1
    w_4_13    normalized_ratio_4_213  -1.8571428571428570e+00
    w_4_13    full_original_Gini_338  -2.6866666666666671e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_14    OBJ       0.0315
    x_4_14    product_lb_207  -2.5263157894711577e-02
    x_4_14    product_ub_208  -0.042962356792187
    x_4_14    onehot_4_211  1
    x_4_14    stock_lb_278  14
    x_4_14    stock_ub_279  14
    x_4_14    parent_nonstrict_scope_280  0.0735
    x_4_14    unique_nonzero_owner_429  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_14    product_lb_207  1
    w_4_14    product_ub_208  1
    w_4_14    normalized_mass_4_212  1
    w_4_14    normalized_ratio_4_213  -2
    w_4_14    full_original_Gini_338  -3.0723809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_15    OBJ       4.1999999999999996e-02
    x_4_15    product_lb_209  -2.5263157894711577e-02
    x_4_15    product_ub_210  -0.042962356792187
    x_4_15    onehot_4_211  1
    x_4_15    stock_lb_278  15
    x_4_15    stock_ub_279  15
    x_4_15    parent_nonstrict_scope_280  8.3999999999999991e-02
    x_4_15    unique_nonzero_owner_430  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_15    product_lb_209  1
    w_4_15    product_ub_210  1
    w_4_15    normalized_mass_4_212  1
    w_4_15    normalized_ratio_4_213  -2.1428571428571428e+00
    w_4_15    full_original_Gini_338  -3.4580952380952375e+01
    rho_4     normalized_ratio_4_213  1
    rho_4     block_pair_pos_281  1
    rho_4     block_pair_neg_282  -1
    rho_4     block_pair_pos_295  1
    rho_4     block_pair_neg_296  -1
    rho_4     block_pair_pos_307  -1
    rho_4     block_pair_neg_308  1
    rho_4     block_pair_pos_309  -1
    rho_4     block_pair_neg_310  1
    rho_4     block_pair_pos_311  1
    rho_4     block_pair_neg_312  -1
    rho_4     block_pair_pos_321  1
    rho_4     block_pair_neg_322  -1
    rho_4     block_pair_pos_331  1
    rho_4     block_pair_neg_332  -1
    rho_4     normalization_337  1
    MARKER    'MARKER'                 'INTORG'
    x_19_0    OBJ       0.012
    x_19_0    product_lb_214  -2.5263157894711577e-02
    x_19_0    product_ub_215  -0.042962356792187
    x_19_0    onehot_19_232  1
    x_19_0    parent_nonstrict_scope_280  0.024
    MARKER    'MARKER'                 'INTEND'
    w_19_0    product_lb_214  1
    w_19_0    product_ub_215  1
    w_19_0    normalized_mass_19_233  1
    w_19_0    full_original_Gini_338  -2.3276190476190479e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_1    OBJ       6.0000000000000019e-03
    x_19_1    product_lb_216  -2.5263157894711577e-02
    x_19_1    product_ub_217  -0.042962356792187
    x_19_1    onehot_19_232  1
    x_19_1    stock_lb_278  1
    x_19_1    stock_ub_279  1
    x_19_1    parent_nonstrict_scope_280  1.8000000000000002e-02
    x_19_1    unique_nonzero_owner_431  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_1    product_lb_216  1
    w_19_1    product_ub_217  1
    w_19_1    normalized_mass_19_233  1
    w_19_1    normalized_ratio_19_234  -0.25
    w_19_1    full_original_Gini_338  -1.7026190476190475e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_2    product_lb_218  -2.5263157894711577e-02
    x_19_2    product_ub_219  -0.042962356792187
    x_19_2    onehot_19_232  1
    x_19_2    stock_lb_278  2
    x_19_2    stock_ub_279  2
    x_19_2    parent_nonstrict_scope_280  0.012
    x_19_2    unique_nonzero_owner_432  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_2    product_lb_218  1
    w_19_2    product_ub_219  1
    w_19_2    normalized_mass_19_233  1
    w_19_2    normalized_ratio_19_234  -0.5
    w_19_2    full_original_Gini_338  -1.1176190476190476e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_3    OBJ       -0.006
    x_19_3    product_lb_220  -2.5263157894711577e-02
    x_19_3    product_ub_221  -0.042962356792187
    x_19_3    onehot_19_232  1
    x_19_3    stock_lb_278  3
    x_19_3    stock_ub_279  3
    x_19_3    parent_nonstrict_scope_280  0.006
    x_19_3    unique_nonzero_owner_433  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_3    product_lb_220  1
    w_19_3    product_ub_221  1
    w_19_3    normalized_mass_19_233  1
    w_19_3    normalized_ratio_19_234  -0.75
    w_19_3    full_original_Gini_338  -6.0690476190476188e+00
    MARKER    'MARKER'                 'INTORG'
    x_19_4    OBJ       -0.012
    x_19_4    product_lb_222  -2.5263157894711577e-02
    x_19_4    product_ub_223  -0.042962356792187
    x_19_4    onehot_19_232  1
    x_19_4    stock_lb_278  4
    x_19_4    stock_ub_279  4
    x_19_4    unique_nonzero_owner_434  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_4    product_lb_222  1
    w_19_4    product_ub_223  1
    w_19_4    normalized_mass_19_233  1
    w_19_4    normalized_ratio_19_234  -1
    w_19_4    full_original_Gini_338  -4.1238095238095234e+00
    MARKER    'MARKER'                 'INTORG'
    x_19_5    OBJ       -0.006
    x_19_5    product_lb_224  -2.5263157894711577e-02
    x_19_5    product_ub_225  -0.042962356792187
    x_19_5    onehot_19_232  1
    x_19_5    stock_lb_278  5
    x_19_5    stock_ub_279  5
    x_19_5    parent_nonstrict_scope_280  0.006
    x_19_5    unique_nonzero_owner_435  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_5    product_lb_224  1
    w_19_5    product_ub_225  1
    w_19_5    normalized_mass_19_233  1
    w_19_5    normalized_ratio_19_234  -1.25
    w_19_5    full_original_Gini_338  -1.0473809523809523e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_6    product_lb_226  -2.5263157894711577e-02
    x_19_6    product_ub_227  -0.042962356792187
    x_19_6    onehot_19_232  1
    x_19_6    stock_lb_278  6
    x_19_6    stock_ub_279  6
    x_19_6    parent_nonstrict_scope_280  0.012
    x_19_6    unique_nonzero_owner_436  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_6    product_lb_226  1
    w_19_6    product_ub_227  1
    w_19_6    normalized_mass_19_233  1
    w_19_6    normalized_ratio_19_234  -1.5
    w_19_6    full_original_Gini_338  -1.7223809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_7    OBJ       6.0000000000000019e-03
    x_19_7    product_lb_228  -2.5263157894711577e-02
    x_19_7    product_ub_229  -0.042962356792187
    x_19_7    onehot_19_232  1
    x_19_7    stock_lb_278  7
    x_19_7    stock_ub_279  7
    x_19_7    parent_nonstrict_scope_280  1.8000000000000002e-02
    x_19_7    unique_nonzero_owner_437  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_7    product_lb_228  1
    w_19_7    product_ub_229  1
    w_19_7    normalized_mass_19_233  1
    w_19_7    normalized_ratio_19_234  -1.75
    w_19_7    full_original_Gini_338  -2.3973809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_8    OBJ       0.012
    x_19_8    product_lb_230  -2.5263157894711577e-02
    x_19_8    product_ub_231  -0.042962356792187
    x_19_8    onehot_19_232  1
    x_19_8    stock_lb_278  8
    x_19_8    stock_ub_279  8
    x_19_8    parent_nonstrict_scope_280  0.024
    x_19_8    unique_nonzero_owner_438  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_8    product_lb_230  1
    w_19_8    product_ub_231  1
    w_19_8    normalized_mass_19_233  1
    w_19_8    normalized_ratio_19_234  -2
    w_19_8    full_original_Gini_338  -3.0723809523809525e+01
    rho_19    normalized_ratio_19_234  1
    rho_19    block_pair_pos_287  1
    rho_19    block_pair_neg_288  -1
    rho_19    block_pair_pos_301  1
    rho_19    block_pair_neg_302  -1
    rho_19    block_pair_pos_309  1
    rho_19    block_pair_neg_310  -1
    rho_19    block_pair_pos_315  1
    rho_19    block_pair_neg_316  -1
    rho_19    block_pair_pos_319  -1
    rho_19    block_pair_neg_320  1
    rho_19    block_pair_pos_327  1
    rho_19    block_pair_neg_328  -1
    rho_19    block_pair_pos_335  1
    rho_19    block_pair_neg_336  -1
    rho_19    normalization_337  1
    MARKER    'MARKER'                 'INTORG'
    x_10_0    OBJ       0.075
    x_10_0    product_lb_235  -2.5263157894711577e-02
    x_10_0    product_ub_236  -0.042962356792187
    x_10_0    onehot_10_275  1
    x_10_0    parent_nonstrict_scope_280  0.15
    x_10_0    unique_nonzero_owner_439  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_0    product_lb_235  1
    w_10_0    product_ub_236  1
    w_10_0    normalized_mass_10_276  1
    w_10_0    full_original_Gini_338  -2.3276190476190479e+01
    MARKER    'MARKER'                 'INTORG'
    x_10_1    OBJ       6.0000000000000012e-02
    x_10_1    product_lb_237  -2.5263157894711577e-02
    x_10_1    product_ub_238  -0.042962356792187
    x_10_1    onehot_10_275  1
    x_10_1    stock_lb_278  1
    x_10_1    stock_ub_279  1
    x_10_1    parent_nonstrict_scope_280  0.135
    x_10_1    unique_nonzero_owner_440  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_1    product_lb_237  1
    w_10_1    product_ub_238  1
    w_10_1    normalized_mass_10_276  1
    w_10_1    normalized_ratio_10_277  -0.1
    w_10_1    full_original_Gini_338  -2.0776190476190472e+01
    MARKER    'MARKER'                 'INTORG'
    x_10_2    OBJ       0.045
    x_10_2    product_lb_239  -2.5263157894711577e-02
    x_10_2    product_ub_240  -0.042962356792187
    x_10_2    onehot_10_275  1
    x_10_2    stock_lb_278  2
    x_10_2    stock_ub_279  2
    x_10_2    parent_nonstrict_scope_280  0.12
    x_10_2    unique_nonzero_owner_441  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_2    product_lb_239  1
    w_10_2    product_ub_240  1
    w_10_2    normalized_mass_10_276  1
    w_10_2    normalized_ratio_10_277  -0.2
    w_10_2    full_original_Gini_338  -1.8276190476190482e+01
    MARKER    'MARKER'                 'INTORG'
    x_10_3    OBJ       0.03
    x_10_3    product_lb_241  -2.5263157894711577e-02
    x_10_3    product_ub_242  -0.042962356792187
    x_10_3    onehot_10_275  1
    x_10_3    stock_lb_278  3
    x_10_3    stock_ub_279  3
    x_10_3    parent_nonstrict_scope_280  0.105
    x_10_3    unique_nonzero_owner_442  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_3    product_lb_241  1
    w_10_3    product_ub_242  1
    w_10_3    normalized_mass_10_276  1
    w_10_3    normalized_ratio_10_277  -3.0000000000000004e-01
    w_10_3    full_original_Gini_338  -1.5776190476190470e+01
    MARKER    'MARKER'                 'INTORG'
    x_10_4    OBJ       0.015
    x_10_4    product_lb_243  -2.5263157894711577e-02
    x_10_4    product_ub_244  -0.042962356792187
    x_10_4    onehot_10_275  1
    x_10_4    stock_lb_278  4
    x_10_4    stock_ub_279  4
    x_10_4    parent_nonstrict_scope_280  0.09
    x_10_4    unique_nonzero_owner_443  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_4    product_lb_243  1
    w_10_4    product_ub_244  1
    w_10_4    normalized_mass_10_276  1
    w_10_4    normalized_ratio_10_277  -0.4
    w_10_4    full_original_Gini_338  -1.3276190476190473e+01
    MARKER    'MARKER'                 'INTORG'
    x_10_5    product_lb_245  -2.5263157894711577e-02
    x_10_5    product_ub_246  -0.042962356792187
    x_10_5    onehot_10_275  1
    x_10_5    stock_lb_278  5
    x_10_5    stock_ub_279  5
    x_10_5    parent_nonstrict_scope_280  0.075
    x_10_5    unique_nonzero_owner_444  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_5    product_lb_245  1
    w_10_5    product_ub_246  1
    w_10_5    normalized_mass_10_276  1
    w_10_5    normalized_ratio_10_277  -0.5
    w_10_5    full_original_Gini_338  -1.1176190476190476e+01
    MARKER    'MARKER'                 'INTORG'
    x_10_6    OBJ       -1.5000000000000013e-02
    x_10_6    product_lb_247  -2.5263157894711577e-02
    x_10_6    product_ub_248  -0.042962356792187
    x_10_6    onehot_10_275  1
    x_10_6    stock_lb_278  6
    x_10_6    stock_ub_279  6
    x_10_6    parent_nonstrict_scope_280  5.9999999999999984e-02
    x_10_6    unique_nonzero_owner_445  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_6    product_lb_247  1
    w_10_6    product_ub_248  1
    w_10_6    normalized_mass_10_276  1
    w_10_6    normalized_ratio_10_277  -6.0000000000000009e-01
    w_10_6    full_original_Gini_338  -9.0761904761904759e+00
    MARKER    'MARKER'                 'INTORG'
    x_10_7    OBJ       -3.0000000000000006e-02
    x_10_7    product_lb_249  -2.5263157894711577e-02
    x_10_7    product_ub_250  -0.042962356792187
    x_10_7    onehot_10_275  1
    x_10_7    stock_lb_278  7
    x_10_7    stock_ub_279  7
    x_10_7    parent_nonstrict_scope_280  4.4999999999999991e-02
    x_10_7    unique_nonzero_owner_446  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_7    product_lb_249  1
    w_10_7    product_ub_250  1
    w_10_7    normalized_mass_10_276  1
    w_10_7    normalized_ratio_10_277  -7.0000000000000007e-01
    w_10_7    full_original_Gini_338  -6.9761904761904745e+00
    MARKER    'MARKER'                 'INTORG'
    x_10_8    OBJ       -4.5000000000000005e-02
    x_10_8    product_lb_251  -2.5263157894711577e-02
    x_10_8    product_ub_252  -0.042962356792187
    x_10_8    onehot_10_275  1
    x_10_8    stock_lb_278  8
    x_10_8    stock_ub_279  8
    x_10_8    parent_nonstrict_scope_280  2.9999999999999992e-02
    x_10_8    unique_nonzero_owner_447  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_8    product_lb_251  1
    w_10_8    product_ub_252  1
    w_10_8    normalized_mass_10_276  1
    w_10_8    normalized_ratio_10_277  -0.8
    w_10_8    full_original_Gini_338  -5.2190476190476209e+00
    MARKER    'MARKER'                 'INTORG'
    x_10_9    OBJ       -0.06
    x_10_9    product_lb_253  -2.5263157894711577e-02
    x_10_9    product_ub_254  -0.042962356792187
    x_10_9    onehot_10_275  1
    x_10_9    stock_lb_278  9
    x_10_9    stock_ub_279  9
    x_10_9    parent_nonstrict_scope_280  1.4999999999999996e-02
    x_10_9    unique_nonzero_owner_448  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_9    product_lb_253  1
    w_10_9    product_ub_254  1
    w_10_9    normalized_mass_10_276  1
    w_10_9    normalized_ratio_10_277  -0.9
    w_10_9    full_original_Gini_338  -4.2238095238095248e+00
    MARKER    'MARKER'                 'INTORG'
    x_10_10   OBJ       -0.075
    x_10_10   product_lb_255  -2.5263157894711577e-02
    x_10_10   product_ub_256  -0.042962356792187
    x_10_10   onehot_10_275  1
    x_10_10   stock_lb_278  10
    x_10_10   stock_ub_279  10
    x_10_10   unique_nonzero_owner_449  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_10   product_lb_255  1
    w_10_10   product_ub_256  1
    w_10_10   normalized_mass_10_276  1
    w_10_10   normalized_ratio_10_277  -1
    w_10_10   full_original_Gini_338  -4.1238095238095234e+00
    MARKER    'MARKER'                 'INTORG'
    x_10_11   OBJ       -5.9999999999999984e-02
    x_10_11   product_lb_257  -2.5263157894711577e-02
    x_10_11   product_ub_258  -0.042962356792187
    x_10_11   onehot_10_275  1
    x_10_11   stock_lb_278  11
    x_10_11   stock_ub_279  11
    x_10_11   parent_nonstrict_scope_280  1.5000000000000013e-02
    x_10_11   unique_nonzero_owner_450  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_11   product_lb_257  1
    w_10_11   product_ub_258  1
    w_10_11   normalized_mass_10_276  1
    w_10_11   normalized_ratio_10_277  -1.1
    w_10_11   full_original_Gini_338  -6.6238095238095251e+00
    MARKER    'MARKER'                 'INTORG'
    x_10_12   OBJ       -4.4999999999999971e-02
    x_10_12   product_lb_259  -2.5263157894711577e-02
    x_10_12   product_ub_260  -0.042962356792187
    x_10_12   onehot_10_275  1
    x_10_12   stock_lb_278  12
    x_10_12   stock_ub_279  12
    x_10_12   parent_nonstrict_scope_280  3.0000000000000027e-02
    x_10_12   unique_nonzero_owner_451  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_12   product_lb_259  1
    w_10_12   product_ub_260  1
    w_10_12   normalized_mass_10_276  1
    w_10_12   normalized_ratio_10_277  -1.2000000000000002e+00
    w_10_12   full_original_Gini_338  -9.12380952380953
    MARKER    'MARKER'                 'INTORG'
    x_10_13   OBJ       -2.9999999999999992e-02
    x_10_13   product_lb_261  -2.5263157894711577e-02
    x_10_13   product_ub_262  -0.042962356792187
    x_10_13   onehot_10_275  1
    x_10_13   stock_lb_278  13
    x_10_13   stock_ub_279  13
    x_10_13   parent_nonstrict_scope_280  4.5000000000000005e-02
    x_10_13   unique_nonzero_owner_452  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_13   product_lb_261  1
    w_10_13   product_ub_262  1
    w_10_13   normalized_mass_10_276  1
    w_10_13   normalized_ratio_10_277  -1.3
    w_10_13   full_original_Gini_338  -1.1823809523809528e+01
    MARKER    'MARKER'                 'INTORG'
    x_10_14   OBJ       -1.4999999999999979e-02
    x_10_14   product_lb_263  -2.5263157894711577e-02
    x_10_14   product_ub_264  -0.042962356792187
    x_10_14   onehot_10_275  1
    x_10_14   stock_lb_278  14
    x_10_14   stock_ub_279  14
    x_10_14   parent_nonstrict_scope_280  6.0000000000000019e-02
    x_10_14   unique_nonzero_owner_453  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_14   product_lb_263  1
    w_10_14   product_ub_264  1
    w_10_14   normalized_mass_10_276  1
    w_10_14   normalized_ratio_10_277  -1.4000000000000001e+00
    w_10_14   full_original_Gini_338  -1.4523809523809531e+01
    MARKER    'MARKER'                 'INTORG'
    x_10_15   product_lb_265  -2.5263157894711577e-02
    x_10_15   product_ub_266  -0.042962356792187
    x_10_15   onehot_10_275  1
    x_10_15   stock_lb_278  15
    x_10_15   stock_ub_279  15
    x_10_15   parent_nonstrict_scope_280  0.075
    MARKER    'MARKER'                 'INTEND'
    w_10_15   product_lb_265  1
    w_10_15   product_ub_266  1
    w_10_15   normalized_mass_10_276  1
    w_10_15   normalized_ratio_10_277  -1.5
    w_10_15   full_original_Gini_338  -1.7223809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_10_16   OBJ       1.5000000000000013e-02
    x_10_16   product_lb_267  -2.5263157894711577e-02
    x_10_16   product_ub_268  -0.042962356792187
    x_10_16   onehot_10_275  1
    x_10_16   stock_lb_278  16
    x_10_16   stock_ub_279  16
    x_10_16   parent_nonstrict_scope_280  9.0000000000000011e-02
    x_10_16   unique_nonzero_owner_454  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_16   product_lb_267  1
    w_10_16   product_ub_268  1
    w_10_16   normalized_mass_10_276  1
    w_10_16   normalized_ratio_10_277  -1.6
    w_10_16   full_original_Gini_338  -1.9923809523809528e+01
    MARKER    'MARKER'                 'INTORG'
    x_10_17   OBJ       3.0000000000000027e-02
    x_10_17   product_lb_269  -2.5263157894711577e-02
    x_10_17   product_ub_270  -0.042962356792187
    x_10_17   onehot_10_275  1
    x_10_17   stock_lb_278  17
    x_10_17   stock_ub_279  17
    x_10_17   parent_nonstrict_scope_280  1.0500000000000002e-01
    x_10_17   unique_nonzero_owner_455  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_17   product_lb_269  1
    w_10_17   product_ub_270  1
    w_10_17   normalized_mass_10_276  1
    w_10_17   normalized_ratio_10_277  -1.7000000000000002e+00
    w_10_17   full_original_Gini_338  -2.2623809523809523e+01
    MARKER    'MARKER'                 'INTORG'
    x_10_18   OBJ       0.045
    x_10_18   product_lb_271  -2.5263157894711577e-02
    x_10_18   product_ub_272  -0.042962356792187
    x_10_18   onehot_10_275  1
    x_10_18   stock_lb_278  18
    x_10_18   stock_ub_279  18
    x_10_18   parent_nonstrict_scope_280  0.12
    x_10_18   unique_nonzero_owner_456  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_18   product_lb_271  1
    w_10_18   product_ub_272  1
    w_10_18   normalized_mass_10_276  1
    w_10_18   normalized_ratio_10_277  -1.8
    w_10_18   full_original_Gini_338  -2.5323809523809530e+01
    MARKER    'MARKER'                 'INTORG'
    x_10_19   OBJ       6.0000000000000012e-02
    x_10_19   product_lb_273  -2.5263157894711577e-02
    x_10_19   product_ub_274  -0.042962356792187
    x_10_19   onehot_10_275  1
    x_10_19   stock_lb_278  19
    x_10_19   stock_ub_279  19
    x_10_19   parent_nonstrict_scope_280  0.135
    x_10_19   unique_nonzero_owner_457  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_19   product_lb_273  1
    w_10_19   product_ub_274  1
    w_10_19   normalized_mass_10_276  1
    w_10_19   normalized_ratio_10_277  -1.9000000000000001e+00
    w_10_19   full_original_Gini_338  -2.8023809523809522e+01
    rho_10    normalized_ratio_10_277  1
    rho_10    block_pair_pos_285  1
    rho_10    block_pair_neg_286  -1
    rho_10    block_pair_pos_299  1
    rho_10    block_pair_neg_300  -1
    rho_10    block_pair_pos_307  1
    rho_10    block_pair_neg_308  -1
    rho_10    block_pair_pos_313  1
    rho_10    block_pair_neg_314  -1
    rho_10    block_pair_pos_319  1
    rho_10    block_pair_neg_320  -1
    rho_10    block_pair_pos_325  1
    rho_10    block_pair_neg_326  -1
    rho_10    block_pair_pos_333  1
    rho_10    block_pair_neg_334  -1
    rho_10    normalization_337  1
    a_3_1     block_pair_pos_293  1
    a_3_1     block_pair_neg_294  1
    a_3_1     full_original_Gini_338  -1
    a_3_31    block_pair_pos_303  1
    a_3_31    block_pair_neg_304  1
    a_3_31    full_original_Gini_338  -1
    a_3_7     block_pair_pos_297  1
    a_3_7     block_pair_neg_298  1
    a_3_7     full_original_Gini_338  -1
    a_3_32    block_pair_pos_305  1
    a_3_32    block_pair_neg_306  1
    a_3_32    full_original_Gini_338  -1
    a_3_4     block_pair_pos_295  1
    a_3_4     block_pair_neg_296  1
    a_3_4     full_original_Gini_338  -1
    a_3_19    block_pair_pos_301  1
    a_3_19    block_pair_neg_302  1
    a_3_19    full_original_Gini_338  -1
    a_3_10    block_pair_pos_299  1
    a_3_10    block_pair_neg_300  1
    a_3_10    full_original_Gini_338  -1
    a_1_31    block_pair_pos_289  1
    a_1_31    block_pair_neg_290  1
    a_1_31    full_original_Gini_338  -1
    a_1_7     block_pair_pos_283  1
    a_1_7     block_pair_neg_284  1
    a_1_7     full_original_Gini_338  -1
    a_1_32    block_pair_pos_291  1
    a_1_32    block_pair_neg_292  1
    a_1_32    full_original_Gini_338  -1
    a_1_4     block_pair_pos_281  1
    a_1_4     block_pair_neg_282  1
    a_1_4     full_original_Gini_338  -1
    a_1_19    block_pair_pos_287  1
    a_1_19    block_pair_neg_288  1
    a_1_19    full_original_Gini_338  -1
    a_1_10    block_pair_pos_285  1
    a_1_10    block_pair_neg_286  1
    a_1_10    full_original_Gini_338  -1
    a_31_7    block_pair_pos_323  1
    a_31_7    block_pair_neg_324  1
    a_31_7    full_original_Gini_338  -1
    a_31_32   block_pair_pos_329  1
    a_31_32   block_pair_neg_330  1
    a_31_32   full_original_Gini_338  -1
    a_31_4    block_pair_pos_321  1
    a_31_4    block_pair_neg_322  1
    a_31_4    full_original_Gini_338  -1
    a_31_19   block_pair_pos_327  1
    a_31_19   block_pair_neg_328  1
    a_31_19   full_original_Gini_338  -1
    a_31_10   block_pair_pos_325  1
    a_31_10   block_pair_neg_326  1
    a_31_10   full_original_Gini_338  -1
    a_7_32    block_pair_pos_317  1
    a_7_32    block_pair_neg_318  1
    a_7_32    full_original_Gini_338  -1
    a_7_4     block_pair_pos_311  1
    a_7_4     block_pair_neg_312  1
    a_7_4     full_original_Gini_338  -1
    a_7_19    block_pair_pos_315  1
    a_7_19    block_pair_neg_316  1
    a_7_19    full_original_Gini_338  -1
    a_7_10    block_pair_pos_313  1
    a_7_10    block_pair_neg_314  1
    a_7_10    full_original_Gini_338  -1
    a_32_4    block_pair_pos_331  1
    a_32_4    block_pair_neg_332  1
    a_32_4    full_original_Gini_338  -1
    a_32_19   block_pair_pos_335  1
    a_32_19   block_pair_neg_336  1
    a_32_19   full_original_Gini_338  -1
    a_32_10   block_pair_pos_333  1
    a_32_10   block_pair_neg_334  1
    a_32_10   full_original_Gini_338  -1
    a_4_19    block_pair_pos_309  1
    a_4_19    block_pair_neg_310  1
    a_4_19    full_original_Gini_338  -1
    a_4_10    block_pair_pos_307  1
    a_4_10    block_pair_neg_308  1
    a_4_10    full_original_Gini_338  -1
    a_19_10   block_pair_pos_319  1
    a_19_10   block_pair_neg_320  1
    a_19_10   full_original_Gini_338  -1
    MARKER    'MARKER'                 'INTORG'
    service_0_3_0  unique_nonzero_owner_339  1
    service_0_3_0  service_visit_def_838  1
    service_0_3_0  free_load_conservation_839  -12
    service_0_3_0  original_T_including_depot_unload_886  1440
    service_0_3_1  unique_nonzero_owner_340  1
    service_0_3_1  service_visit_def_838  1
    service_0_3_1  free_load_conservation_839  -11
    service_0_3_1  original_T_including_depot_unload_886  1320
    service_0_3_2  unique_nonzero_owner_341  1
    service_0_3_2  service_visit_def_838  1
    service_0_3_2  free_load_conservation_839  -10
    service_0_3_2  original_T_including_depot_unload_886  1200
    service_0_3_3  unique_nonzero_owner_342  1
    service_0_3_3  service_visit_def_838  1
    service_0_3_3  free_load_conservation_839  -9
    service_0_3_3  original_T_including_depot_unload_886  1080
    service_0_3_4  unique_nonzero_owner_343  1
    service_0_3_4  service_visit_def_838  1
    service_0_3_4  free_load_conservation_839  -8
    service_0_3_4  original_T_including_depot_unload_886  960
    service_0_3_5  unique_nonzero_owner_344  1
    service_0_3_5  service_visit_def_838  1
    service_0_3_5  free_load_conservation_839  -7
    service_0_3_5  original_T_including_depot_unload_886  840
    service_0_3_6  unique_nonzero_owner_345  1
    service_0_3_6  service_visit_def_838  1
    service_0_3_6  free_load_conservation_839  -6
    service_0_3_6  original_T_including_depot_unload_886  720
    service_0_3_7  unique_nonzero_owner_346  1
    service_0_3_7  service_visit_def_838  1
    service_0_3_7  free_load_conservation_839  -5
    service_0_3_7  original_T_including_depot_unload_886  600
    service_0_3_8  unique_nonzero_owner_347  1
    service_0_3_8  service_visit_def_838  1
    service_0_3_8  free_load_conservation_839  -4
    service_0_3_8  original_T_including_depot_unload_886  480
    service_0_3_9  unique_nonzero_owner_348  1
    service_0_3_9  service_visit_def_838  1
    service_0_3_9  free_load_conservation_839  -3
    service_0_3_9  original_T_including_depot_unload_886  360
    service_0_3_10  unique_nonzero_owner_349  1
    service_0_3_10  service_visit_def_838  1
    service_0_3_10  free_load_conservation_839  -2
    service_0_3_10  original_T_including_depot_unload_886  240
    service_0_3_11  unique_nonzero_owner_350  1
    service_0_3_11  service_visit_def_838  1
    service_0_3_11  free_load_conservation_839  -1
    service_0_3_11  original_T_including_depot_unload_886  120
    service_0_3_13  unique_nonzero_owner_351  1
    service_0_3_13  service_visit_def_838  1
    service_0_3_13  free_load_conservation_839  1
    service_0_3_14  unique_nonzero_owner_352  1
    service_0_3_14  service_visit_def_838  1
    service_0_3_14  free_load_conservation_839  2
    service_0_3_15  unique_nonzero_owner_353  1
    service_0_3_15  service_visit_def_838  1
    service_0_3_15  free_load_conservation_839  3
    service_0_3_16  unique_nonzero_owner_354  1
    service_0_3_16  service_visit_def_838  1
    service_0_3_16  free_load_conservation_839  4
    service_0_3_17  unique_nonzero_owner_355  1
    service_0_3_17  service_visit_def_838  1
    service_0_3_17  free_load_conservation_839  5
    service_1_3_0  unique_nonzero_owner_339  1
    service_1_3_0  service_visit_def_1210  1
    service_1_3_0  free_load_conservation_1211  -12
    service_1_3_0  original_T_including_depot_unload_1257  1440
    service_1_3_1  unique_nonzero_owner_340  1
    service_1_3_1  service_visit_def_1210  1
    service_1_3_1  free_load_conservation_1211  -11
    service_1_3_1  original_T_including_depot_unload_1257  1320
    service_1_3_2  unique_nonzero_owner_341  1
    service_1_3_2  service_visit_def_1210  1
    service_1_3_2  free_load_conservation_1211  -10
    service_1_3_2  original_T_including_depot_unload_1257  1200
    service_1_3_3  unique_nonzero_owner_342  1
    service_1_3_3  service_visit_def_1210  1
    service_1_3_3  free_load_conservation_1211  -9
    service_1_3_3  original_T_including_depot_unload_1257  1080
    service_1_3_4  unique_nonzero_owner_343  1
    service_1_3_4  service_visit_def_1210  1
    service_1_3_4  free_load_conservation_1211  -8
    service_1_3_4  original_T_including_depot_unload_1257  960
    service_1_3_5  unique_nonzero_owner_344  1
    service_1_3_5  service_visit_def_1210  1
    service_1_3_5  free_load_conservation_1211  -7
    service_1_3_5  original_T_including_depot_unload_1257  840
    service_1_3_6  unique_nonzero_owner_345  1
    service_1_3_6  service_visit_def_1210  1
    service_1_3_6  free_load_conservation_1211  -6
    service_1_3_6  original_T_including_depot_unload_1257  720
    service_1_3_7  unique_nonzero_owner_346  1
    service_1_3_7  service_visit_def_1210  1
    service_1_3_7  free_load_conservation_1211  -5
    service_1_3_7  original_T_including_depot_unload_1257  600
    service_1_3_8  unique_nonzero_owner_347  1
    service_1_3_8  service_visit_def_1210  1
    service_1_3_8  free_load_conservation_1211  -4
    service_1_3_8  original_T_including_depot_unload_1257  480
    service_1_3_9  unique_nonzero_owner_348  1
    service_1_3_9  service_visit_def_1210  1
    service_1_3_9  free_load_conservation_1211  -3
    service_1_3_9  original_T_including_depot_unload_1257  360
    service_1_3_10  unique_nonzero_owner_349  1
    service_1_3_10  service_visit_def_1210  1
    service_1_3_10  free_load_conservation_1211  -2
    service_1_3_10  original_T_including_depot_unload_1257  240
    service_1_3_11  unique_nonzero_owner_350  1
    service_1_3_11  service_visit_def_1210  1
    service_1_3_11  free_load_conservation_1211  -1
    service_1_3_11  original_T_including_depot_unload_1257  120
    service_1_3_13  unique_nonzero_owner_351  1
    service_1_3_13  service_visit_def_1210  1
    service_1_3_13  free_load_conservation_1211  1
    service_1_3_14  unique_nonzero_owner_352  1
    service_1_3_14  service_visit_def_1210  1
    service_1_3_14  free_load_conservation_1211  2
    service_1_3_15  unique_nonzero_owner_353  1
    service_1_3_15  service_visit_def_1210  1
    service_1_3_15  free_load_conservation_1211  3
    service_1_3_16  unique_nonzero_owner_354  1
    service_1_3_16  service_visit_def_1210  1
    service_1_3_16  free_load_conservation_1211  4
    service_1_3_17  unique_nonzero_owner_355  1
    service_1_3_17  service_visit_def_1210  1
    service_1_3_17  free_load_conservation_1211  5
    service_2_3_0  unique_nonzero_owner_339  1
    service_2_3_0  service_visit_def_1528  1
    service_2_3_0  free_load_conservation_1529  -12
    service_2_3_0  original_T_including_depot_unload_1574  1440
    service_2_3_1  unique_nonzero_owner_340  1
    service_2_3_1  service_visit_def_1528  1
    service_2_3_1  free_load_conservation_1529  -11
    service_2_3_1  original_T_including_depot_unload_1574  1320
    service_2_3_2  unique_nonzero_owner_341  1
    service_2_3_2  service_visit_def_1528  1
    service_2_3_2  free_load_conservation_1529  -10
    service_2_3_2  original_T_including_depot_unload_1574  1200
    service_2_3_3  unique_nonzero_owner_342  1
    service_2_3_3  service_visit_def_1528  1
    service_2_3_3  free_load_conservation_1529  -9
    service_2_3_3  original_T_including_depot_unload_1574  1080
    service_2_3_4  unique_nonzero_owner_343  1
    service_2_3_4  service_visit_def_1528  1
    service_2_3_4  free_load_conservation_1529  -8
    service_2_3_4  original_T_including_depot_unload_1574  960
    service_2_3_5  unique_nonzero_owner_344  1
    service_2_3_5  service_visit_def_1528  1
    service_2_3_5  free_load_conservation_1529  -7
    service_2_3_5  original_T_including_depot_unload_1574  840
    service_2_3_6  unique_nonzero_owner_345  1
    service_2_3_6  service_visit_def_1528  1
    service_2_3_6  free_load_conservation_1529  -6
    service_2_3_6  original_T_including_depot_unload_1574  720
    service_2_3_7  unique_nonzero_owner_346  1
    service_2_3_7  service_visit_def_1528  1
    service_2_3_7  free_load_conservation_1529  -5
    service_2_3_7  original_T_including_depot_unload_1574  600
    service_2_3_8  unique_nonzero_owner_347  1
    service_2_3_8  service_visit_def_1528  1
    service_2_3_8  free_load_conservation_1529  -4
    service_2_3_8  original_T_including_depot_unload_1574  480
    service_2_3_9  unique_nonzero_owner_348  1
    service_2_3_9  service_visit_def_1528  1
    service_2_3_9  free_load_conservation_1529  -3
    service_2_3_9  original_T_including_depot_unload_1574  360
    service_2_3_10  unique_nonzero_owner_349  1
    service_2_3_10  service_visit_def_1528  1
    service_2_3_10  free_load_conservation_1529  -2
    service_2_3_10  original_T_including_depot_unload_1574  240
    service_2_3_11  unique_nonzero_owner_350  1
    service_2_3_11  service_visit_def_1528  1
    service_2_3_11  free_load_conservation_1529  -1
    service_2_3_11  original_T_including_depot_unload_1574  120
    service_2_3_13  unique_nonzero_owner_351  1
    service_2_3_13  service_visit_def_1528  1
    service_2_3_13  free_load_conservation_1529  1
    service_2_3_14  unique_nonzero_owner_352  1
    service_2_3_14  service_visit_def_1528  1
    service_2_3_14  free_load_conservation_1529  2
    service_2_3_15  unique_nonzero_owner_353  1
    service_2_3_15  service_visit_def_1528  1
    service_2_3_15  free_load_conservation_1529  3
    service_2_3_16  unique_nonzero_owner_354  1
    service_2_3_16  service_visit_def_1528  1
    service_2_3_16  free_load_conservation_1529  4
    service_2_3_17  unique_nonzero_owner_355  1
    service_2_3_17  service_visit_def_1528  1
    service_2_3_17  free_load_conservation_1529  5
    service_0_1_0  unique_nonzero_owner_356  1
    service_0_1_0  service_visit_def_844  1
    service_0_1_0  free_load_conservation_845  -2
    service_0_1_0  original_T_including_depot_unload_886  240
    service_0_1_1  unique_nonzero_owner_357  1
    service_0_1_1  service_visit_def_844  1
    service_0_1_1  free_load_conservation_845  -1
    service_0_1_1  original_T_including_depot_unload_886  120
    service_0_1_3  unique_nonzero_owner_358  1
    service_0_1_3  service_visit_def_844  1
    service_0_1_3  free_load_conservation_845  1
    service_0_1_4  unique_nonzero_owner_359  1
    service_0_1_4  service_visit_def_844  1
    service_0_1_4  free_load_conservation_845  2
    service_0_1_5  unique_nonzero_owner_360  1
    service_0_1_5  service_visit_def_844  1
    service_0_1_5  free_load_conservation_845  3
    service_0_1_6  unique_nonzero_owner_361  1
    service_0_1_6  service_visit_def_844  1
    service_0_1_6  free_load_conservation_845  4
    service_0_1_7  unique_nonzero_owner_362  1
    service_0_1_7  service_visit_def_844  1
    service_0_1_7  free_load_conservation_845  5
    service_0_1_8  unique_nonzero_owner_363  1
    service_0_1_8  service_visit_def_844  1
    service_0_1_8  free_load_conservation_845  6
    service_0_1_9  unique_nonzero_owner_364  1
    service_0_1_9  service_visit_def_844  1
    service_0_1_9  free_load_conservation_845  7
    service_0_1_10  unique_nonzero_owner_365  1
    service_0_1_10  service_visit_def_844  1
    service_0_1_10  free_load_conservation_845  8
    service_0_1_11  unique_nonzero_owner_366  1
    service_0_1_11  service_visit_def_844  1
    service_0_1_11  free_load_conservation_845  9
    service_0_1_12  unique_nonzero_owner_367  1
    service_0_1_12  service_visit_def_844  1
    service_0_1_12  free_load_conservation_845  10
    service_0_1_13  unique_nonzero_owner_368  1
    service_0_1_13  service_visit_def_844  1
    service_0_1_13  free_load_conservation_845  11
    service_0_1_14  unique_nonzero_owner_369  1
    service_0_1_14  service_visit_def_844  1
    service_0_1_14  free_load_conservation_845  12
    service_0_1_15  unique_nonzero_owner_370  1
    service_0_1_15  service_visit_def_844  1
    service_0_1_15  free_load_conservation_845  13
    service_0_1_16  unique_nonzero_owner_371  1
    service_0_1_16  service_visit_def_844  1
    service_0_1_16  free_load_conservation_845  14
    service_0_1_17  unique_nonzero_owner_372  1
    service_0_1_17  service_visit_def_844  1
    service_0_1_17  free_load_conservation_845  15
    service_0_1_18  unique_nonzero_owner_373  1
    service_0_1_18  service_visit_def_844  1
    service_0_1_18  free_load_conservation_845  16
    service_0_1_19  unique_nonzero_owner_374  1
    service_0_1_19  service_visit_def_844  1
    service_0_1_19  free_load_conservation_845  17
    service_1_1_0  unique_nonzero_owner_356  1
    service_1_1_0  service_visit_def_1216  1
    service_1_1_0  free_load_conservation_1217  -2
    service_1_1_0  original_T_including_depot_unload_1257  240
    service_1_1_1  unique_nonzero_owner_357  1
    service_1_1_1  service_visit_def_1216  1
    service_1_1_1  free_load_conservation_1217  -1
    service_1_1_1  original_T_including_depot_unload_1257  120
    service_1_1_3  unique_nonzero_owner_358  1
    service_1_1_3  service_visit_def_1216  1
    service_1_1_3  free_load_conservation_1217  1
    service_1_1_4  unique_nonzero_owner_359  1
    service_1_1_4  service_visit_def_1216  1
    service_1_1_4  free_load_conservation_1217  2
    service_1_1_5  unique_nonzero_owner_360  1
    service_1_1_5  service_visit_def_1216  1
    service_1_1_5  free_load_conservation_1217  3
    service_1_1_6  unique_nonzero_owner_361  1
    service_1_1_6  service_visit_def_1216  1
    service_1_1_6  free_load_conservation_1217  4
    service_1_1_7  unique_nonzero_owner_362  1
    service_1_1_7  service_visit_def_1216  1
    service_1_1_7  free_load_conservation_1217  5
    service_1_1_8  unique_nonzero_owner_363  1
    service_1_1_8  service_visit_def_1216  1
    service_1_1_8  free_load_conservation_1217  6
    service_1_1_9  unique_nonzero_owner_364  1
    service_1_1_9  service_visit_def_1216  1
    service_1_1_9  free_load_conservation_1217  7
    service_1_1_10  unique_nonzero_owner_365  1
    service_1_1_10  service_visit_def_1216  1
    service_1_1_10  free_load_conservation_1217  8
    service_1_1_11  unique_nonzero_owner_366  1
    service_1_1_11  service_visit_def_1216  1
    service_1_1_11  free_load_conservation_1217  9
    service_1_1_12  unique_nonzero_owner_367  1
    service_1_1_12  service_visit_def_1216  1
    service_1_1_12  free_load_conservation_1217  10
    service_1_1_13  unique_nonzero_owner_368  1
    service_1_1_13  service_visit_def_1216  1
    service_1_1_13  free_load_conservation_1217  11
    service_1_1_14  unique_nonzero_owner_369  1
    service_1_1_14  service_visit_def_1216  1
    service_1_1_14  free_load_conservation_1217  12
    service_1_1_15  unique_nonzero_owner_370  1
    service_1_1_15  service_visit_def_1216  1
    service_1_1_15  free_load_conservation_1217  13
    service_1_1_16  unique_nonzero_owner_371  1
    service_1_1_16  service_visit_def_1216  1
    service_1_1_16  free_load_conservation_1217  14
    service_1_1_17  unique_nonzero_owner_372  1
    service_1_1_17  service_visit_def_1216  1
    service_1_1_17  free_load_conservation_1217  15
    service_1_1_18  unique_nonzero_owner_373  1
    service_1_1_18  service_visit_def_1216  1
    service_1_1_18  free_load_conservation_1217  16
    service_1_1_19  unique_nonzero_owner_374  1
    service_1_1_19  service_visit_def_1216  1
    service_1_1_19  free_load_conservation_1217  17
    service_2_1_0  unique_nonzero_owner_356  1
    service_2_1_0  service_visit_def_1534  1
    service_2_1_0  free_load_conservation_1535  -2
    service_2_1_0  original_T_including_depot_unload_1574  240
    service_2_1_1  unique_nonzero_owner_357  1
    service_2_1_1  service_visit_def_1534  1
    service_2_1_1  free_load_conservation_1535  -1
    service_2_1_1  original_T_including_depot_unload_1574  120
    service_2_1_3  unique_nonzero_owner_358  1
    service_2_1_3  service_visit_def_1534  1
    service_2_1_3  free_load_conservation_1535  1
    service_2_1_4  unique_nonzero_owner_359  1
    service_2_1_4  service_visit_def_1534  1
    service_2_1_4  free_load_conservation_1535  2
    service_2_1_5  unique_nonzero_owner_360  1
    service_2_1_5  service_visit_def_1534  1
    service_2_1_5  free_load_conservation_1535  3
    service_2_1_6  unique_nonzero_owner_361  1
    service_2_1_6  service_visit_def_1534  1
    service_2_1_6  free_load_conservation_1535  4
    service_2_1_7  unique_nonzero_owner_362  1
    service_2_1_7  service_visit_def_1534  1
    service_2_1_7  free_load_conservation_1535  5
    service_2_1_8  unique_nonzero_owner_363  1
    service_2_1_8  service_visit_def_1534  1
    service_2_1_8  free_load_conservation_1535  6
    service_2_1_9  unique_nonzero_owner_364  1
    service_2_1_9  service_visit_def_1534  1
    service_2_1_9  free_load_conservation_1535  7
    service_2_1_10  unique_nonzero_owner_365  1
    service_2_1_10  service_visit_def_1534  1
    service_2_1_10  free_load_conservation_1535  8
    service_2_1_11  unique_nonzero_owner_366  1
    service_2_1_11  service_visit_def_1534  1
    service_2_1_11  free_load_conservation_1535  9
    service_2_1_12  unique_nonzero_owner_367  1
    service_2_1_12  service_visit_def_1534  1
    service_2_1_12  free_load_conservation_1535  10
    service_2_1_13  unique_nonzero_owner_368  1
    service_2_1_13  service_visit_def_1534  1
    service_2_1_13  free_load_conservation_1535  11
    service_2_1_14  unique_nonzero_owner_369  1
    service_2_1_14  service_visit_def_1534  1
    service_2_1_14  free_load_conservation_1535  12
    service_2_1_15  unique_nonzero_owner_370  1
    service_2_1_15  service_visit_def_1534  1
    service_2_1_15  free_load_conservation_1535  13
    service_2_1_16  unique_nonzero_owner_371  1
    service_2_1_16  service_visit_def_1534  1
    service_2_1_16  free_load_conservation_1535  14
    service_2_1_17  unique_nonzero_owner_372  1
    service_2_1_17  service_visit_def_1534  1
    service_2_1_17  free_load_conservation_1535  15
    service_2_1_18  unique_nonzero_owner_373  1
    service_2_1_18  service_visit_def_1534  1
    service_2_1_18  free_load_conservation_1535  16
    service_2_1_19  unique_nonzero_owner_374  1
    service_2_1_19  service_visit_def_1534  1
    service_2_1_19  free_load_conservation_1535  17
    service_0_31_0  unique_nonzero_owner_375  1
    service_0_31_0  service_visit_def_850  1
    service_0_31_0  free_load_conservation_851  -2
    service_0_31_0  original_T_including_depot_unload_886  240
    service_0_31_1  unique_nonzero_owner_376  1
    service_0_31_1  service_visit_def_850  1
    service_0_31_1  free_load_conservation_851  -1
    service_0_31_1  original_T_including_depot_unload_886  120
    service_0_31_3  unique_nonzero_owner_377  1
    service_0_31_3  service_visit_def_850  1
    service_0_31_3  free_load_conservation_851  1
    service_0_31_4  unique_nonzero_owner_378  1
    service_0_31_4  service_visit_def_850  1
    service_0_31_4  free_load_conservation_851  2
    service_0_31_5  unique_nonzero_owner_379  1
    service_0_31_5  service_visit_def_850  1
    service_0_31_5  free_load_conservation_851  3
    service_0_31_6  unique_nonzero_owner_380  1
    service_0_31_6  service_visit_def_850  1
    service_0_31_6  free_load_conservation_851  4
    service_0_31_7  unique_nonzero_owner_381  1
    service_0_31_7  service_visit_def_850  1
    service_0_31_7  free_load_conservation_851  5
    service_0_31_8  unique_nonzero_owner_382  1
    service_0_31_8  service_visit_def_850  1
    service_0_31_8  free_load_conservation_851  6
    service_0_31_9  unique_nonzero_owner_383  1
    service_0_31_9  service_visit_def_850  1
    service_0_31_9  free_load_conservation_851  7
    service_0_31_10  unique_nonzero_owner_384  1
    service_0_31_10  service_visit_def_850  1
    service_0_31_10  free_load_conservation_851  8
    service_0_31_11  unique_nonzero_owner_385  1
    service_0_31_11  service_visit_def_850  1
    service_0_31_11  free_load_conservation_851  9
    service_0_31_12  unique_nonzero_owner_386  1
    service_0_31_12  service_visit_def_850  1
    service_0_31_12  free_load_conservation_851  10
    service_1_31_0  unique_nonzero_owner_375  1
    service_1_31_0  service_visit_def_1222  1
    service_1_31_0  free_load_conservation_1223  -2
    service_1_31_0  original_T_including_depot_unload_1257  240
    service_1_31_1  unique_nonzero_owner_376  1
    service_1_31_1  service_visit_def_1222  1
    service_1_31_1  free_load_conservation_1223  -1
    service_1_31_1  original_T_including_depot_unload_1257  120
    service_1_31_3  unique_nonzero_owner_377  1
    service_1_31_3  service_visit_def_1222  1
    service_1_31_3  free_load_conservation_1223  1
    service_1_31_4  unique_nonzero_owner_378  1
    service_1_31_4  service_visit_def_1222  1
    service_1_31_4  free_load_conservation_1223  2
    service_1_31_5  unique_nonzero_owner_379  1
    service_1_31_5  service_visit_def_1222  1
    service_1_31_5  free_load_conservation_1223  3
    service_1_31_6  unique_nonzero_owner_380  1
    service_1_31_6  service_visit_def_1222  1
    service_1_31_6  free_load_conservation_1223  4
    service_1_31_7  unique_nonzero_owner_381  1
    service_1_31_7  service_visit_def_1222  1
    service_1_31_7  free_load_conservation_1223  5
    service_1_31_8  unique_nonzero_owner_382  1
    service_1_31_8  service_visit_def_1222  1
    service_1_31_8  free_load_conservation_1223  6
    service_1_31_9  unique_nonzero_owner_383  1
    service_1_31_9  service_visit_def_1222  1
    service_1_31_9  free_load_conservation_1223  7
    service_1_31_10  unique_nonzero_owner_384  1
    service_1_31_10  service_visit_def_1222  1
    service_1_31_10  free_load_conservation_1223  8
    service_1_31_11  unique_nonzero_owner_385  1
    service_1_31_11  service_visit_def_1222  1
    service_1_31_11  free_load_conservation_1223  9
    service_1_31_12  unique_nonzero_owner_386  1
    service_1_31_12  service_visit_def_1222  1
    service_1_31_12  free_load_conservation_1223  10
    service_2_31_0  unique_nonzero_owner_375  1
    service_2_31_0  service_visit_def_1540  1
    service_2_31_0  free_load_conservation_1541  -2
    service_2_31_0  original_T_including_depot_unload_1574  240
    service_2_31_1  unique_nonzero_owner_376  1
    service_2_31_1  service_visit_def_1540  1
    service_2_31_1  free_load_conservation_1541  -1
    service_2_31_1  original_T_including_depot_unload_1574  120
    service_2_31_3  unique_nonzero_owner_377  1
    service_2_31_3  service_visit_def_1540  1
    service_2_31_3  free_load_conservation_1541  1
    service_2_31_4  unique_nonzero_owner_378  1
    service_2_31_4  service_visit_def_1540  1
    service_2_31_4  free_load_conservation_1541  2
    service_2_31_5  unique_nonzero_owner_379  1
    service_2_31_5  service_visit_def_1540  1
    service_2_31_5  free_load_conservation_1541  3
    service_2_31_6  unique_nonzero_owner_380  1
    service_2_31_6  service_visit_def_1540  1
    service_2_31_6  free_load_conservation_1541  4
    service_2_31_7  unique_nonzero_owner_381  1
    service_2_31_7  service_visit_def_1540  1
    service_2_31_7  free_load_conservation_1541  5
    service_2_31_8  unique_nonzero_owner_382  1
    service_2_31_8  service_visit_def_1540  1
    service_2_31_8  free_load_conservation_1541  6
    service_2_31_9  unique_nonzero_owner_383  1
    service_2_31_9  service_visit_def_1540  1
    service_2_31_9  free_load_conservation_1541  7
    service_2_31_10  unique_nonzero_owner_384  1
    service_2_31_10  service_visit_def_1540  1
    service_2_31_10  free_load_conservation_1541  8
    service_2_31_11  unique_nonzero_owner_385  1
    service_2_31_11  service_visit_def_1540  1
    service_2_31_11  free_load_conservation_1541  9
    service_2_31_12  unique_nonzero_owner_386  1
    service_2_31_12  service_visit_def_1540  1
    service_2_31_12  free_load_conservation_1541  10
    service_0_7_0  unique_nonzero_owner_387  1
    service_0_7_0  service_visit_def_856  1
    service_0_7_0  free_load_conservation_857  -12
    service_0_7_0  original_T_including_depot_unload_886  1440
    service_0_7_1  unique_nonzero_owner_388  1
    service_0_7_1  service_visit_def_856  1
    service_0_7_1  free_load_conservation_857  -11
    service_0_7_1  original_T_including_depot_unload_886  1320
    service_0_7_2  unique_nonzero_owner_389  1
    service_0_7_2  service_visit_def_856  1
    service_0_7_2  free_load_conservation_857  -10
    service_0_7_2  original_T_including_depot_unload_886  1200
    service_0_7_3  unique_nonzero_owner_390  1
    service_0_7_3  service_visit_def_856  1
    service_0_7_3  free_load_conservation_857  -9
    service_0_7_3  original_T_including_depot_unload_886  1080
    service_0_7_4  unique_nonzero_owner_391  1
    service_0_7_4  service_visit_def_856  1
    service_0_7_4  free_load_conservation_857  -8
    service_0_7_4  original_T_including_depot_unload_886  960
    service_0_7_5  unique_nonzero_owner_392  1
    service_0_7_5  service_visit_def_856  1
    service_0_7_5  free_load_conservation_857  -7
    service_0_7_5  original_T_including_depot_unload_886  840
    service_0_7_6  unique_nonzero_owner_393  1
    service_0_7_6  service_visit_def_856  1
    service_0_7_6  free_load_conservation_857  -6
    service_0_7_6  original_T_including_depot_unload_886  720
    service_0_7_7  unique_nonzero_owner_394  1
    service_0_7_7  service_visit_def_856  1
    service_0_7_7  free_load_conservation_857  -5
    service_0_7_7  original_T_including_depot_unload_886  600
    service_0_7_8  unique_nonzero_owner_395  1
    service_0_7_8  service_visit_def_856  1
    service_0_7_8  free_load_conservation_857  -4
    service_0_7_8  original_T_including_depot_unload_886  480
    service_0_7_9  unique_nonzero_owner_396  1
    service_0_7_9  service_visit_def_856  1
    service_0_7_9  free_load_conservation_857  -3
    service_0_7_9  original_T_including_depot_unload_886  360
    service_0_7_10  unique_nonzero_owner_397  1
    service_0_7_10  service_visit_def_856  1
    service_0_7_10  free_load_conservation_857  -2
    service_0_7_10  original_T_including_depot_unload_886  240
    service_0_7_11  unique_nonzero_owner_398  1
    service_0_7_11  service_visit_def_856  1
    service_0_7_11  free_load_conservation_857  -1
    service_0_7_11  original_T_including_depot_unload_886  120
    service_0_7_13  unique_nonzero_owner_399  1
    service_0_7_13  service_visit_def_856  1
    service_0_7_13  free_load_conservation_857  1
    service_0_7_14  unique_nonzero_owner_400  1
    service_0_7_14  service_visit_def_856  1
    service_0_7_14  free_load_conservation_857  2
    service_0_7_15  unique_nonzero_owner_401  1
    service_0_7_15  service_visit_def_856  1
    service_0_7_15  free_load_conservation_857  3
    service_0_7_16  unique_nonzero_owner_402  1
    service_0_7_16  service_visit_def_856  1
    service_0_7_16  free_load_conservation_857  4
    service_0_7_17  unique_nonzero_owner_403  1
    service_0_7_17  service_visit_def_856  1
    service_0_7_17  free_load_conservation_857  5
    service_1_7_0  unique_nonzero_owner_387  1
    service_1_7_0  service_visit_def_1228  1
    service_1_7_0  free_load_conservation_1229  -12
    service_1_7_0  original_T_including_depot_unload_1257  1440
    service_1_7_1  unique_nonzero_owner_388  1
    service_1_7_1  service_visit_def_1228  1
    service_1_7_1  free_load_conservation_1229  -11
    service_1_7_1  original_T_including_depot_unload_1257  1320
    service_1_7_2  unique_nonzero_owner_389  1
    service_1_7_2  service_visit_def_1228  1
    service_1_7_2  free_load_conservation_1229  -10
    service_1_7_2  original_T_including_depot_unload_1257  1200
    service_1_7_3  unique_nonzero_owner_390  1
    service_1_7_3  service_visit_def_1228  1
    service_1_7_3  free_load_conservation_1229  -9
    service_1_7_3  original_T_including_depot_unload_1257  1080
    service_1_7_4  unique_nonzero_owner_391  1
    service_1_7_4  service_visit_def_1228  1
    service_1_7_4  free_load_conservation_1229  -8
    service_1_7_4  original_T_including_depot_unload_1257  960
    service_1_7_5  unique_nonzero_owner_392  1
    service_1_7_5  service_visit_def_1228  1
    service_1_7_5  free_load_conservation_1229  -7
    service_1_7_5  original_T_including_depot_unload_1257  840
    service_1_7_6  unique_nonzero_owner_393  1
    service_1_7_6  service_visit_def_1228  1
    service_1_7_6  free_load_conservation_1229  -6
    service_1_7_6  original_T_including_depot_unload_1257  720
    service_1_7_7  unique_nonzero_owner_394  1
    service_1_7_7  service_visit_def_1228  1
    service_1_7_7  free_load_conservation_1229  -5
    service_1_7_7  original_T_including_depot_unload_1257  600
    service_1_7_8  unique_nonzero_owner_395  1
    service_1_7_8  service_visit_def_1228  1
    service_1_7_8  free_load_conservation_1229  -4
    service_1_7_8  original_T_including_depot_unload_1257  480
    service_1_7_9  unique_nonzero_owner_396  1
    service_1_7_9  service_visit_def_1228  1
    service_1_7_9  free_load_conservation_1229  -3
    service_1_7_9  original_T_including_depot_unload_1257  360
    service_1_7_10  unique_nonzero_owner_397  1
    service_1_7_10  service_visit_def_1228  1
    service_1_7_10  free_load_conservation_1229  -2
    service_1_7_10  original_T_including_depot_unload_1257  240
    service_1_7_11  unique_nonzero_owner_398  1
    service_1_7_11  service_visit_def_1228  1
    service_1_7_11  free_load_conservation_1229  -1
    service_1_7_11  original_T_including_depot_unload_1257  120
    service_1_7_13  unique_nonzero_owner_399  1
    service_1_7_13  service_visit_def_1228  1
    service_1_7_13  free_load_conservation_1229  1
    service_1_7_14  unique_nonzero_owner_400  1
    service_1_7_14  service_visit_def_1228  1
    service_1_7_14  free_load_conservation_1229  2
    service_1_7_15  unique_nonzero_owner_401  1
    service_1_7_15  service_visit_def_1228  1
    service_1_7_15  free_load_conservation_1229  3
    service_1_7_16  unique_nonzero_owner_402  1
    service_1_7_16  service_visit_def_1228  1
    service_1_7_16  free_load_conservation_1229  4
    service_1_7_17  unique_nonzero_owner_403  1
    service_1_7_17  service_visit_def_1228  1
    service_1_7_17  free_load_conservation_1229  5
    service_2_7_0  unique_nonzero_owner_387  1
    service_2_7_0  service_visit_def_1546  1
    service_2_7_0  free_load_conservation_1547  -12
    service_2_7_0  original_T_including_depot_unload_1574  1440
    service_2_7_1  unique_nonzero_owner_388  1
    service_2_7_1  service_visit_def_1546  1
    service_2_7_1  free_load_conservation_1547  -11
    service_2_7_1  original_T_including_depot_unload_1574  1320
    service_2_7_2  unique_nonzero_owner_389  1
    service_2_7_2  service_visit_def_1546  1
    service_2_7_2  free_load_conservation_1547  -10
    service_2_7_2  original_T_including_depot_unload_1574  1200
    service_2_7_3  unique_nonzero_owner_390  1
    service_2_7_3  service_visit_def_1546  1
    service_2_7_3  free_load_conservation_1547  -9
    service_2_7_3  original_T_including_depot_unload_1574  1080
    service_2_7_4  unique_nonzero_owner_391  1
    service_2_7_4  service_visit_def_1546  1
    service_2_7_4  free_load_conservation_1547  -8
    service_2_7_4  original_T_including_depot_unload_1574  960
    service_2_7_5  unique_nonzero_owner_392  1
    service_2_7_5  service_visit_def_1546  1
    service_2_7_5  free_load_conservation_1547  -7
    service_2_7_5  original_T_including_depot_unload_1574  840
    service_2_7_6  unique_nonzero_owner_393  1
    service_2_7_6  service_visit_def_1546  1
    service_2_7_6  free_load_conservation_1547  -6
    service_2_7_6  original_T_including_depot_unload_1574  720
    service_2_7_7  unique_nonzero_owner_394  1
    service_2_7_7  service_visit_def_1546  1
    service_2_7_7  free_load_conservation_1547  -5
    service_2_7_7  original_T_including_depot_unload_1574  600
    service_2_7_8  unique_nonzero_owner_395  1
    service_2_7_8  service_visit_def_1546  1
    service_2_7_8  free_load_conservation_1547  -4
    service_2_7_8  original_T_including_depot_unload_1574  480
    service_2_7_9  unique_nonzero_owner_396  1
    service_2_7_9  service_visit_def_1546  1
    service_2_7_9  free_load_conservation_1547  -3
    service_2_7_9  original_T_including_depot_unload_1574  360
    service_2_7_10  unique_nonzero_owner_397  1
    service_2_7_10  service_visit_def_1546  1
    service_2_7_10  free_load_conservation_1547  -2
    service_2_7_10  original_T_including_depot_unload_1574  240
    service_2_7_11  unique_nonzero_owner_398  1
    service_2_7_11  service_visit_def_1546  1
    service_2_7_11  free_load_conservation_1547  -1
    service_2_7_11  original_T_including_depot_unload_1574  120
    service_2_7_13  unique_nonzero_owner_399  1
    service_2_7_13  service_visit_def_1546  1
    service_2_7_13  free_load_conservation_1547  1
    service_2_7_14  unique_nonzero_owner_400  1
    service_2_7_14  service_visit_def_1546  1
    service_2_7_14  free_load_conservation_1547  2
    service_2_7_15  unique_nonzero_owner_401  1
    service_2_7_15  service_visit_def_1546  1
    service_2_7_15  free_load_conservation_1547  3
    service_2_7_16  unique_nonzero_owner_402  1
    service_2_7_16  service_visit_def_1546  1
    service_2_7_16  free_load_conservation_1547  4
    service_2_7_17  unique_nonzero_owner_403  1
    service_2_7_17  service_visit_def_1546  1
    service_2_7_17  free_load_conservation_1547  5
    service_0_32_1  unique_nonzero_owner_404  1
    service_0_32_1  service_visit_def_862  1
    service_0_32_1  free_load_conservation_863  1
    service_0_32_2  unique_nonzero_owner_405  1
    service_0_32_2  service_visit_def_862  1
    service_0_32_2  free_load_conservation_863  2
    service_0_32_3  unique_nonzero_owner_406  1
    service_0_32_3  service_visit_def_862  1
    service_0_32_3  free_load_conservation_863  3
    service_0_32_4  unique_nonzero_owner_407  1
    service_0_32_4  service_visit_def_862  1
    service_0_32_4  free_load_conservation_863  4
    service_0_32_5  unique_nonzero_owner_408  1
    service_0_32_5  service_visit_def_862  1
    service_0_32_5  free_load_conservation_863  5
    service_0_32_6  unique_nonzero_owner_409  1
    service_0_32_6  service_visit_def_862  1
    service_0_32_6  free_load_conservation_863  6
    service_0_32_7  unique_nonzero_owner_410  1
    service_0_32_7  service_visit_def_862  1
    service_0_32_7  free_load_conservation_863  7
    service_0_32_8  unique_nonzero_owner_411  1
    service_0_32_8  service_visit_def_862  1
    service_0_32_8  free_load_conservation_863  8
    service_0_32_9  unique_nonzero_owner_412  1
    service_0_32_9  service_visit_def_862  1
    service_0_32_9  free_load_conservation_863  9
    service_0_32_10  unique_nonzero_owner_413  1
    service_0_32_10  service_visit_def_862  1
    service_0_32_10  free_load_conservation_863  10
    service_0_32_11  unique_nonzero_owner_414  1
    service_0_32_11  service_visit_def_862  1
    service_0_32_11  free_load_conservation_863  11
    service_0_32_12  unique_nonzero_owner_415  1
    service_0_32_12  service_visit_def_862  1
    service_0_32_12  free_load_conservation_863  12
    service_1_32_1  unique_nonzero_owner_404  1
    service_1_32_1  service_visit_def_1234  1
    service_1_32_1  free_load_conservation_1235  1
    service_1_32_2  unique_nonzero_owner_405  1
    service_1_32_2  service_visit_def_1234  1
    service_1_32_2  free_load_conservation_1235  2
    service_1_32_3  unique_nonzero_owner_406  1
    service_1_32_3  service_visit_def_1234  1
    service_1_32_3  free_load_conservation_1235  3
    service_1_32_4  unique_nonzero_owner_407  1
    service_1_32_4  service_visit_def_1234  1
    service_1_32_4  free_load_conservation_1235  4
    service_1_32_5  unique_nonzero_owner_408  1
    service_1_32_5  service_visit_def_1234  1
    service_1_32_5  free_load_conservation_1235  5
    service_1_32_6  unique_nonzero_owner_409  1
    service_1_32_6  service_visit_def_1234  1
    service_1_32_6  free_load_conservation_1235  6
    service_1_32_7  unique_nonzero_owner_410  1
    service_1_32_7  service_visit_def_1234  1
    service_1_32_7  free_load_conservation_1235  7
    service_1_32_8  unique_nonzero_owner_411  1
    service_1_32_8  service_visit_def_1234  1
    service_1_32_8  free_load_conservation_1235  8
    service_1_32_9  unique_nonzero_owner_412  1
    service_1_32_9  service_visit_def_1234  1
    service_1_32_9  free_load_conservation_1235  9
    service_1_32_10  unique_nonzero_owner_413  1
    service_1_32_10  service_visit_def_1234  1
    service_1_32_10  free_load_conservation_1235  10
    service_1_32_11  unique_nonzero_owner_414  1
    service_1_32_11  service_visit_def_1234  1
    service_1_32_11  free_load_conservation_1235  11
    service_1_32_12  unique_nonzero_owner_415  1
    service_1_32_12  service_visit_def_1234  1
    service_1_32_12  free_load_conservation_1235  12
    service_2_32_1  unique_nonzero_owner_404  1
    service_2_32_1  service_visit_def_1552  1
    service_2_32_1  free_load_conservation_1553  1
    service_2_32_2  unique_nonzero_owner_405  1
    service_2_32_2  service_visit_def_1552  1
    service_2_32_2  free_load_conservation_1553  2
    service_2_32_3  unique_nonzero_owner_406  1
    service_2_32_3  service_visit_def_1552  1
    service_2_32_3  free_load_conservation_1553  3
    service_2_32_4  unique_nonzero_owner_407  1
    service_2_32_4  service_visit_def_1552  1
    service_2_32_4  free_load_conservation_1553  4
    service_2_32_5  unique_nonzero_owner_408  1
    service_2_32_5  service_visit_def_1552  1
    service_2_32_5  free_load_conservation_1553  5
    service_2_32_6  unique_nonzero_owner_409  1
    service_2_32_6  service_visit_def_1552  1
    service_2_32_6  free_load_conservation_1553  6
    service_2_32_7  unique_nonzero_owner_410  1
    service_2_32_7  service_visit_def_1552  1
    service_2_32_7  free_load_conservation_1553  7
    service_2_32_8  unique_nonzero_owner_411  1
    service_2_32_8  service_visit_def_1552  1
    service_2_32_8  free_load_conservation_1553  8
    service_2_32_9  unique_nonzero_owner_412  1
    service_2_32_9  service_visit_def_1552  1
    service_2_32_9  free_load_conservation_1553  9
    service_2_32_10  unique_nonzero_owner_413  1
    service_2_32_10  service_visit_def_1552  1
    service_2_32_10  free_load_conservation_1553  10
    service_2_32_11  unique_nonzero_owner_414  1
    service_2_32_11  service_visit_def_1552  1
    service_2_32_11  free_load_conservation_1553  11
    service_2_32_12  unique_nonzero_owner_415  1
    service_2_32_12  service_visit_def_1552  1
    service_2_32_12  free_load_conservation_1553  12
    service_0_4_0  unique_nonzero_owner_416  1
    service_0_4_0  service_visit_def_868  1
    service_0_4_0  free_load_conservation_869  -11
    service_0_4_0  original_T_including_depot_unload_886  1320
    service_0_4_1  unique_nonzero_owner_417  1
    service_0_4_1  service_visit_def_868  1
    service_0_4_1  free_load_conservation_869  -10
    service_0_4_1  original_T_including_depot_unload_886  1200
    service_0_4_2  unique_nonzero_owner_418  1
    service_0_4_2  service_visit_def_868  1
    service_0_4_2  free_load_conservation_869  -9
    service_0_4_2  original_T_including_depot_unload_886  1080
    service_0_4_3  unique_nonzero_owner_419  1
    service_0_4_3  service_visit_def_868  1
    service_0_4_3  free_load_conservation_869  -8
    service_0_4_3  original_T_including_depot_unload_886  960
    service_0_4_4  unique_nonzero_owner_420  1
    service_0_4_4  service_visit_def_868  1
    service_0_4_4  free_load_conservation_869  -7
    service_0_4_4  original_T_including_depot_unload_886  840
    service_0_4_5  unique_nonzero_owner_421  1
    service_0_4_5  service_visit_def_868  1
    service_0_4_5  free_load_conservation_869  -6
    service_0_4_5  original_T_including_depot_unload_886  720
    service_0_4_6  unique_nonzero_owner_422  1
    service_0_4_6  service_visit_def_868  1
    service_0_4_6  free_load_conservation_869  -5
    service_0_4_6  original_T_including_depot_unload_886  600
    service_0_4_7  unique_nonzero_owner_423  1
    service_0_4_7  service_visit_def_868  1
    service_0_4_7  free_load_conservation_869  -4
    service_0_4_7  original_T_including_depot_unload_886  480
    service_0_4_8  unique_nonzero_owner_424  1
    service_0_4_8  service_visit_def_868  1
    service_0_4_8  free_load_conservation_869  -3
    service_0_4_8  original_T_including_depot_unload_886  360
    service_0_4_9  unique_nonzero_owner_425  1
    service_0_4_9  service_visit_def_868  1
    service_0_4_9  free_load_conservation_869  -2
    service_0_4_9  original_T_including_depot_unload_886  240
    service_0_4_10  unique_nonzero_owner_426  1
    service_0_4_10  service_visit_def_868  1
    service_0_4_10  free_load_conservation_869  -1
    service_0_4_10  original_T_including_depot_unload_886  120
    service_0_4_12  unique_nonzero_owner_427  1
    service_0_4_12  service_visit_def_868  1
    service_0_4_12  free_load_conservation_869  1
    service_0_4_13  unique_nonzero_owner_428  1
    service_0_4_13  service_visit_def_868  1
    service_0_4_13  free_load_conservation_869  2
    service_0_4_14  unique_nonzero_owner_429  1
    service_0_4_14  service_visit_def_868  1
    service_0_4_14  free_load_conservation_869  3
    service_0_4_15  unique_nonzero_owner_430  1
    service_0_4_15  service_visit_def_868  1
    service_0_4_15  free_load_conservation_869  4
    service_1_4_0  unique_nonzero_owner_416  1
    service_1_4_0  service_visit_def_1240  1
    service_1_4_0  free_load_conservation_1241  -11
    service_1_4_0  original_T_including_depot_unload_1257  1320
    service_1_4_1  unique_nonzero_owner_417  1
    service_1_4_1  service_visit_def_1240  1
    service_1_4_1  free_load_conservation_1241  -10
    service_1_4_1  original_T_including_depot_unload_1257  1200
    service_1_4_2  unique_nonzero_owner_418  1
    service_1_4_2  service_visit_def_1240  1
    service_1_4_2  free_load_conservation_1241  -9
    service_1_4_2  original_T_including_depot_unload_1257  1080
    service_1_4_3  unique_nonzero_owner_419  1
    service_1_4_3  service_visit_def_1240  1
    service_1_4_3  free_load_conservation_1241  -8
    service_1_4_3  original_T_including_depot_unload_1257  960
    service_1_4_4  unique_nonzero_owner_420  1
    service_1_4_4  service_visit_def_1240  1
    service_1_4_4  free_load_conservation_1241  -7
    service_1_4_4  original_T_including_depot_unload_1257  840
    service_1_4_5  unique_nonzero_owner_421  1
    service_1_4_5  service_visit_def_1240  1
    service_1_4_5  free_load_conservation_1241  -6
    service_1_4_5  original_T_including_depot_unload_1257  720
    service_1_4_6  unique_nonzero_owner_422  1
    service_1_4_6  service_visit_def_1240  1
    service_1_4_6  free_load_conservation_1241  -5
    service_1_4_6  original_T_including_depot_unload_1257  600
    service_1_4_7  unique_nonzero_owner_423  1
    service_1_4_7  service_visit_def_1240  1
    service_1_4_7  free_load_conservation_1241  -4
    service_1_4_7  original_T_including_depot_unload_1257  480
    service_1_4_8  unique_nonzero_owner_424  1
    service_1_4_8  service_visit_def_1240  1
    service_1_4_8  free_load_conservation_1241  -3
    service_1_4_8  original_T_including_depot_unload_1257  360
    service_1_4_9  unique_nonzero_owner_425  1
    service_1_4_9  service_visit_def_1240  1
    service_1_4_9  free_load_conservation_1241  -2
    service_1_4_9  original_T_including_depot_unload_1257  240
    service_1_4_10  unique_nonzero_owner_426  1
    service_1_4_10  service_visit_def_1240  1
    service_1_4_10  free_load_conservation_1241  -1
    service_1_4_10  original_T_including_depot_unload_1257  120
    service_1_4_12  unique_nonzero_owner_427  1
    service_1_4_12  service_visit_def_1240  1
    service_1_4_12  free_load_conservation_1241  1
    service_1_4_13  unique_nonzero_owner_428  1
    service_1_4_13  service_visit_def_1240  1
    service_1_4_13  free_load_conservation_1241  2
    service_1_4_14  unique_nonzero_owner_429  1
    service_1_4_14  service_visit_def_1240  1
    service_1_4_14  free_load_conservation_1241  3
    service_1_4_15  unique_nonzero_owner_430  1
    service_1_4_15  service_visit_def_1240  1
    service_1_4_15  free_load_conservation_1241  4
    service_2_4_0  unique_nonzero_owner_416  1
    service_2_4_0  service_visit_def_1558  1
    service_2_4_0  free_load_conservation_1559  -11
    service_2_4_0  original_T_including_depot_unload_1574  1320
    service_2_4_1  unique_nonzero_owner_417  1
    service_2_4_1  service_visit_def_1558  1
    service_2_4_1  free_load_conservation_1559  -10
    service_2_4_1  original_T_including_depot_unload_1574  1200
    service_2_4_2  unique_nonzero_owner_418  1
    service_2_4_2  service_visit_def_1558  1
    service_2_4_2  free_load_conservation_1559  -9
    service_2_4_2  original_T_including_depot_unload_1574  1080
    service_2_4_3  unique_nonzero_owner_419  1
    service_2_4_3  service_visit_def_1558  1
    service_2_4_3  free_load_conservation_1559  -8
    service_2_4_3  original_T_including_depot_unload_1574  960
    service_2_4_4  unique_nonzero_owner_420  1
    service_2_4_4  service_visit_def_1558  1
    service_2_4_4  free_load_conservation_1559  -7
    service_2_4_4  original_T_including_depot_unload_1574  840
    service_2_4_5  unique_nonzero_owner_421  1
    service_2_4_5  service_visit_def_1558  1
    service_2_4_5  free_load_conservation_1559  -6
    service_2_4_5  original_T_including_depot_unload_1574  720
    service_2_4_6  unique_nonzero_owner_422  1
    service_2_4_6  service_visit_def_1558  1
    service_2_4_6  free_load_conservation_1559  -5
    service_2_4_6  original_T_including_depot_unload_1574  600
    service_2_4_7  unique_nonzero_owner_423  1
    service_2_4_7  service_visit_def_1558  1
    service_2_4_7  free_load_conservation_1559  -4
    service_2_4_7  original_T_including_depot_unload_1574  480
    service_2_4_8  unique_nonzero_owner_424  1
    service_2_4_8  service_visit_def_1558  1
    service_2_4_8  free_load_conservation_1559  -3
    service_2_4_8  original_T_including_depot_unload_1574  360
    service_2_4_9  unique_nonzero_owner_425  1
    service_2_4_9  service_visit_def_1558  1
    service_2_4_9  free_load_conservation_1559  -2
    service_2_4_9  original_T_including_depot_unload_1574  240
    service_2_4_10  unique_nonzero_owner_426  1
    service_2_4_10  service_visit_def_1558  1
    service_2_4_10  free_load_conservation_1559  -1
    service_2_4_10  original_T_including_depot_unload_1574  120
    service_2_4_12  unique_nonzero_owner_427  1
    service_2_4_12  service_visit_def_1558  1
    service_2_4_12  free_load_conservation_1559  1
    service_2_4_13  unique_nonzero_owner_428  1
    service_2_4_13  service_visit_def_1558  1
    service_2_4_13  free_load_conservation_1559  2
    service_2_4_14  unique_nonzero_owner_429  1
    service_2_4_14  service_visit_def_1558  1
    service_2_4_14  free_load_conservation_1559  3
    service_2_4_15  unique_nonzero_owner_430  1
    service_2_4_15  service_visit_def_1558  1
    service_2_4_15  free_load_conservation_1559  4
    service_0_19_1  unique_nonzero_owner_431  1
    service_0_19_1  service_visit_def_874  1
    service_0_19_1  free_load_conservation_875  1
    service_0_19_2  unique_nonzero_owner_432  1
    service_0_19_2  service_visit_def_874  1
    service_0_19_2  free_load_conservation_875  2
    service_0_19_3  unique_nonzero_owner_433  1
    service_0_19_3  service_visit_def_874  1
    service_0_19_3  free_load_conservation_875  3
    service_0_19_4  unique_nonzero_owner_434  1
    service_0_19_4  service_visit_def_874  1
    service_0_19_4  free_load_conservation_875  4
    service_0_19_5  unique_nonzero_owner_435  1
    service_0_19_5  service_visit_def_874  1
    service_0_19_5  free_load_conservation_875  5
    service_0_19_6  unique_nonzero_owner_436  1
    service_0_19_6  service_visit_def_874  1
    service_0_19_6  free_load_conservation_875  6
    service_0_19_7  unique_nonzero_owner_437  1
    service_0_19_7  service_visit_def_874  1
    service_0_19_7  free_load_conservation_875  7
    service_0_19_8  unique_nonzero_owner_438  1
    service_0_19_8  service_visit_def_874  1
    service_0_19_8  free_load_conservation_875  8
    service_1_19_1  unique_nonzero_owner_431  1
    service_1_19_1  service_visit_def_1246  1
    service_1_19_1  free_load_conservation_1247  1
    service_1_19_2  unique_nonzero_owner_432  1
    service_1_19_2  service_visit_def_1246  1
    service_1_19_2  free_load_conservation_1247  2
    service_1_19_3  unique_nonzero_owner_433  1
    service_1_19_3  service_visit_def_1246  1
    service_1_19_3  free_load_conservation_1247  3
    service_1_19_4  unique_nonzero_owner_434  1
    service_1_19_4  service_visit_def_1246  1
    service_1_19_4  free_load_conservation_1247  4
    service_1_19_5  unique_nonzero_owner_435  1
    service_1_19_5  service_visit_def_1246  1
    service_1_19_5  free_load_conservation_1247  5
    service_1_19_6  unique_nonzero_owner_436  1
    service_1_19_6  service_visit_def_1246  1
    service_1_19_6  free_load_conservation_1247  6
    service_1_19_7  unique_nonzero_owner_437  1
    service_1_19_7  service_visit_def_1246  1
    service_1_19_7  free_load_conservation_1247  7
    service_1_19_8  unique_nonzero_owner_438  1
    service_1_19_8  service_visit_def_1246  1
    service_1_19_8  free_load_conservation_1247  8
    service_2_19_1  unique_nonzero_owner_431  1
    service_2_19_1  service_visit_def_1564  1
    service_2_19_1  free_load_conservation_1565  1
    service_2_19_2  unique_nonzero_owner_432  1
    service_2_19_2  service_visit_def_1564  1
    service_2_19_2  free_load_conservation_1565  2
    service_2_19_3  unique_nonzero_owner_433  1
    service_2_19_3  service_visit_def_1564  1
    service_2_19_3  free_load_conservation_1565  3
    service_2_19_4  unique_nonzero_owner_434  1
    service_2_19_4  service_visit_def_1564  1
    service_2_19_4  free_load_conservation_1565  4
    service_2_19_5  unique_nonzero_owner_435  1
    service_2_19_5  service_visit_def_1564  1
    service_2_19_5  free_load_conservation_1565  5
    service_2_19_6  unique_nonzero_owner_436  1
    service_2_19_6  service_visit_def_1564  1
    service_2_19_6  free_load_conservation_1565  6
    service_2_19_7  unique_nonzero_owner_437  1
    service_2_19_7  service_visit_def_1564  1
    service_2_19_7  free_load_conservation_1565  7
    service_2_19_8  unique_nonzero_owner_438  1
    service_2_19_8  service_visit_def_1564  1
    service_2_19_8  free_load_conservation_1565  8
    service_0_10_0  unique_nonzero_owner_439  1
    service_0_10_0  service_visit_def_880  1
    service_0_10_0  free_load_conservation_881  -15
    service_0_10_0  original_T_including_depot_unload_886  1800
    service_0_10_1  unique_nonzero_owner_440  1
    service_0_10_1  service_visit_def_880  1
    service_0_10_1  free_load_conservation_881  -14
    service_0_10_1  original_T_including_depot_unload_886  1680
    service_0_10_2  unique_nonzero_owner_441  1
    service_0_10_2  service_visit_def_880  1
    service_0_10_2  free_load_conservation_881  -13
    service_0_10_2  original_T_including_depot_unload_886  1560
    service_0_10_3  unique_nonzero_owner_442  1
    service_0_10_3  service_visit_def_880  1
    service_0_10_3  free_load_conservation_881  -12
    service_0_10_3  original_T_including_depot_unload_886  1440
    service_0_10_4  unique_nonzero_owner_443  1
    service_0_10_4  service_visit_def_880  1
    service_0_10_4  free_load_conservation_881  -11
    service_0_10_4  original_T_including_depot_unload_886  1320
    service_0_10_5  unique_nonzero_owner_444  1
    service_0_10_5  service_visit_def_880  1
    service_0_10_5  free_load_conservation_881  -10
    service_0_10_5  original_T_including_depot_unload_886  1200
    service_0_10_6  unique_nonzero_owner_445  1
    service_0_10_6  service_visit_def_880  1
    service_0_10_6  free_load_conservation_881  -9
    service_0_10_6  original_T_including_depot_unload_886  1080
    service_0_10_7  unique_nonzero_owner_446  1
    service_0_10_7  service_visit_def_880  1
    service_0_10_7  free_load_conservation_881  -8
    service_0_10_7  original_T_including_depot_unload_886  960
    service_0_10_8  unique_nonzero_owner_447  1
    service_0_10_8  service_visit_def_880  1
    service_0_10_8  free_load_conservation_881  -7
    service_0_10_8  original_T_including_depot_unload_886  840
    service_0_10_9  unique_nonzero_owner_448  1
    service_0_10_9  service_visit_def_880  1
    service_0_10_9  free_load_conservation_881  -6
    service_0_10_9  original_T_including_depot_unload_886  720
    service_0_10_10  unique_nonzero_owner_449  1
    service_0_10_10  service_visit_def_880  1
    service_0_10_10  free_load_conservation_881  -5
    service_0_10_10  original_T_including_depot_unload_886  600
    service_0_10_11  unique_nonzero_owner_450  1
    service_0_10_11  service_visit_def_880  1
    service_0_10_11  free_load_conservation_881  -4
    service_0_10_11  original_T_including_depot_unload_886  480
    service_0_10_12  unique_nonzero_owner_451  1
    service_0_10_12  service_visit_def_880  1
    service_0_10_12  free_load_conservation_881  -3
    service_0_10_12  original_T_including_depot_unload_886  360
    service_0_10_13  unique_nonzero_owner_452  1
    service_0_10_13  service_visit_def_880  1
    service_0_10_13  free_load_conservation_881  -2
    service_0_10_13  original_T_including_depot_unload_886  240
    service_0_10_14  unique_nonzero_owner_453  1
    service_0_10_14  service_visit_def_880  1
    service_0_10_14  free_load_conservation_881  -1
    service_0_10_14  original_T_including_depot_unload_886  120
    service_0_10_16  unique_nonzero_owner_454  1
    service_0_10_16  service_visit_def_880  1
    service_0_10_16  free_load_conservation_881  1
    service_0_10_17  unique_nonzero_owner_455  1
    service_0_10_17  service_visit_def_880  1
    service_0_10_17  free_load_conservation_881  2
    service_0_10_18  unique_nonzero_owner_456  1
    service_0_10_18  service_visit_def_880  1
    service_0_10_18  free_load_conservation_881  3
    service_0_10_19  unique_nonzero_owner_457  1
    service_0_10_19  service_visit_def_880  1
    service_0_10_19  free_load_conservation_881  4
    service_1_10_0  unique_nonzero_owner_439  1
    service_1_10_0  service_visit_def_1252  1
    service_1_10_0  free_load_conservation_1253  -15
    service_1_10_0  original_T_including_depot_unload_1257  1800
    service_1_10_1  unique_nonzero_owner_440  1
    service_1_10_1  service_visit_def_1252  1
    service_1_10_1  free_load_conservation_1253  -14
    service_1_10_1  original_T_including_depot_unload_1257  1680
    service_1_10_2  unique_nonzero_owner_441  1
    service_1_10_2  service_visit_def_1252  1
    service_1_10_2  free_load_conservation_1253  -13
    service_1_10_2  original_T_including_depot_unload_1257  1560
    service_1_10_3  unique_nonzero_owner_442  1
    service_1_10_3  service_visit_def_1252  1
    service_1_10_3  free_load_conservation_1253  -12
    service_1_10_3  original_T_including_depot_unload_1257  1440
    service_1_10_4  unique_nonzero_owner_443  1
    service_1_10_4  service_visit_def_1252  1
    service_1_10_4  free_load_conservation_1253  -11
    service_1_10_4  original_T_including_depot_unload_1257  1320
    service_1_10_5  unique_nonzero_owner_444  1
    service_1_10_5  service_visit_def_1252  1
    service_1_10_5  free_load_conservation_1253  -10
    service_1_10_5  original_T_including_depot_unload_1257  1200
    service_1_10_6  unique_nonzero_owner_445  1
    service_1_10_6  service_visit_def_1252  1
    service_1_10_6  free_load_conservation_1253  -9
    service_1_10_6  original_T_including_depot_unload_1257  1080
    service_1_10_7  unique_nonzero_owner_446  1
    service_1_10_7  service_visit_def_1252  1
    service_1_10_7  free_load_conservation_1253  -8
    service_1_10_7  original_T_including_depot_unload_1257  960
    service_1_10_8  unique_nonzero_owner_447  1
    service_1_10_8  service_visit_def_1252  1
    service_1_10_8  free_load_conservation_1253  -7
    service_1_10_8  original_T_including_depot_unload_1257  840
    service_1_10_9  unique_nonzero_owner_448  1
    service_1_10_9  service_visit_def_1252  1
    service_1_10_9  free_load_conservation_1253  -6
    service_1_10_9  original_T_including_depot_unload_1257  720
    service_1_10_10  unique_nonzero_owner_449  1
    service_1_10_10  service_visit_def_1252  1
    service_1_10_10  free_load_conservation_1253  -5
    service_1_10_10  original_T_including_depot_unload_1257  600
    service_1_10_11  unique_nonzero_owner_450  1
    service_1_10_11  service_visit_def_1252  1
    service_1_10_11  free_load_conservation_1253  -4
    service_1_10_11  original_T_including_depot_unload_1257  480
    service_1_10_12  unique_nonzero_owner_451  1
    service_1_10_12  service_visit_def_1252  1
    service_1_10_12  free_load_conservation_1253  -3
    service_1_10_12  original_T_including_depot_unload_1257  360
    service_1_10_13  unique_nonzero_owner_452  1
    service_1_10_13  service_visit_def_1252  1
    service_1_10_13  free_load_conservation_1253  -2
    service_1_10_13  original_T_including_depot_unload_1257  240
    service_1_10_14  unique_nonzero_owner_453  1
    service_1_10_14  service_visit_def_1252  1
    service_1_10_14  free_load_conservation_1253  -1
    service_1_10_14  original_T_including_depot_unload_1257  120
    service_1_10_16  unique_nonzero_owner_454  1
    service_1_10_16  service_visit_def_1252  1
    service_1_10_16  free_load_conservation_1253  1
    service_1_10_17  unique_nonzero_owner_455  1
    service_1_10_17  service_visit_def_1252  1
    service_1_10_17  free_load_conservation_1253  2
    service_1_10_18  unique_nonzero_owner_456  1
    service_1_10_18  service_visit_def_1252  1
    service_1_10_18  free_load_conservation_1253  3
    service_1_10_19  unique_nonzero_owner_457  1
    service_1_10_19  service_visit_def_1252  1
    service_1_10_19  free_load_conservation_1253  4
    service_2_10_0  unique_nonzero_owner_439  1
    service_2_10_0  service_visit_def_1570  1
    service_2_10_0  free_load_conservation_1571  -15
    service_2_10_0  original_T_including_depot_unload_1574  1800
    service_2_10_1  unique_nonzero_owner_440  1
    service_2_10_1  service_visit_def_1570  1
    service_2_10_1  free_load_conservation_1571  -14
    service_2_10_1  original_T_including_depot_unload_1574  1680
    service_2_10_2  unique_nonzero_owner_441  1
    service_2_10_2  service_visit_def_1570  1
    service_2_10_2  free_load_conservation_1571  -13
    service_2_10_2  original_T_including_depot_unload_1574  1560
    service_2_10_3  unique_nonzero_owner_442  1
    service_2_10_3  service_visit_def_1570  1
    service_2_10_3  free_load_conservation_1571  -12
    service_2_10_3  original_T_including_depot_unload_1574  1440
    service_2_10_4  unique_nonzero_owner_443  1
    service_2_10_4  service_visit_def_1570  1
    service_2_10_4  free_load_conservation_1571  -11
    service_2_10_4  original_T_including_depot_unload_1574  1320
    service_2_10_5  unique_nonzero_owner_444  1
    service_2_10_5  service_visit_def_1570  1
    service_2_10_5  free_load_conservation_1571  -10
    service_2_10_5  original_T_including_depot_unload_1574  1200
    service_2_10_6  unique_nonzero_owner_445  1
    service_2_10_6  service_visit_def_1570  1
    service_2_10_6  free_load_conservation_1571  -9
    service_2_10_6  original_T_including_depot_unload_1574  1080
    service_2_10_7  unique_nonzero_owner_446  1
    service_2_10_7  service_visit_def_1570  1
    service_2_10_7  free_load_conservation_1571  -8
    service_2_10_7  original_T_including_depot_unload_1574  960
    service_2_10_8  unique_nonzero_owner_447  1
    service_2_10_8  service_visit_def_1570  1
    service_2_10_8  free_load_conservation_1571  -7
    service_2_10_8  original_T_including_depot_unload_1574  840
    service_2_10_9  unique_nonzero_owner_448  1
    service_2_10_9  service_visit_def_1570  1
    service_2_10_9  free_load_conservation_1571  -6
    service_2_10_9  original_T_including_depot_unload_1574  720
    service_2_10_10  unique_nonzero_owner_449  1
    service_2_10_10  service_visit_def_1570  1
    service_2_10_10  free_load_conservation_1571  -5
    service_2_10_10  original_T_including_depot_unload_1574  600
    service_2_10_11  unique_nonzero_owner_450  1
    service_2_10_11  service_visit_def_1570  1
    service_2_10_11  free_load_conservation_1571  -4
    service_2_10_11  original_T_including_depot_unload_1574  480
    service_2_10_12  unique_nonzero_owner_451  1
    service_2_10_12  service_visit_def_1570  1
    service_2_10_12  free_load_conservation_1571  -3
    service_2_10_12  original_T_including_depot_unload_1574  360
    service_2_10_13  unique_nonzero_owner_452  1
    service_2_10_13  service_visit_def_1570  1
    service_2_10_13  free_load_conservation_1571  -2
    service_2_10_13  original_T_including_depot_unload_1574  240
    service_2_10_14  unique_nonzero_owner_453  1
    service_2_10_14  service_visit_def_1570  1
    service_2_10_14  free_load_conservation_1571  -1
    service_2_10_14  original_T_including_depot_unload_1574  120
    service_2_10_16  unique_nonzero_owner_454  1
    service_2_10_16  service_visit_def_1570  1
    service_2_10_16  free_load_conservation_1571  1
    service_2_10_17  unique_nonzero_owner_455  1
    service_2_10_17  service_visit_def_1570  1
    service_2_10_17  free_load_conservation_1571  2
    service_2_10_18  unique_nonzero_owner_456  1
    service_2_10_18  service_visit_def_1570  1
    service_2_10_18  free_load_conservation_1571  3
    service_2_10_19  unique_nonzero_owner_457  1
    service_2_10_19  service_visit_def_1570  1
    service_2_10_19  free_load_conservation_1571  4
    MARKER    'MARKER'                 'INTEND'
    visit_0_1  out_degree_799  -1
    visit_0_1  in_degree_800  -1
    visit_0_1  order_active_lb_801  -1
    visit_0_1  order_active_ub_802  -13
    order_0_1  connected_order_arc_474  -1
    order_0_1  connected_order_arc_476  -1
    order_0_1  connected_order_arc_478  -1
    order_0_1  connected_order_arc_480  -1
    order_0_1  connected_order_arc_482  -1
    order_0_1  connected_order_arc_484  -1
    order_0_1  connected_order_arc_486  -1
    order_0_1  connected_order_arc_488  -1
    order_0_1  connected_order_arc_490  -1
    order_0_1  connected_order_arc_492  -1
    order_0_1  connected_order_arc_494  -1
    order_0_1  connected_order_arc_496  -1
    order_0_1  connected_order_arc_499  1
    order_0_1  connected_order_arc_524  1
    order_0_1  connected_order_arc_549  1
    order_0_1  connected_order_arc_574  1
    order_0_1  connected_order_arc_599  1
    order_0_1  connected_order_arc_624  1
    order_0_1  connected_order_arc_649  1
    order_0_1  connected_order_arc_674  1
    order_0_1  connected_order_arc_699  1
    order_0_1  connected_order_arc_724  1
    order_0_1  connected_order_arc_749  1
    order_0_1  connected_order_arc_774  1
    order_0_1  order_active_lb_801  1
    order_0_1  order_active_ub_802  1
    order_0_1  fixed_segment_relative_order_882  -1
    visit_0_2  out_degree_806  -1
    visit_0_2  in_degree_807  -1
    visit_0_2  order_active_lb_808  -1
    visit_0_2  order_active_ub_809  -13
    order_0_2  connected_order_arc_474  1
    order_0_2  connected_order_arc_499  -1
    order_0_2  connected_order_arc_501  -1
    order_0_2  connected_order_arc_503  -1
    order_0_2  connected_order_arc_505  -1
    order_0_2  connected_order_arc_507  -1
    order_0_2  connected_order_arc_509  -1
    order_0_2  connected_order_arc_511  -1
    order_0_2  connected_order_arc_513  -1
    order_0_2  connected_order_arc_515  -1
    order_0_2  connected_order_arc_517  -1
    order_0_2  connected_order_arc_519  -1
    order_0_2  connected_order_arc_521  -1
    order_0_2  connected_order_arc_526  1
    order_0_2  connected_order_arc_551  1
    order_0_2  connected_order_arc_576  1
    order_0_2  connected_order_arc_601  1
    order_0_2  connected_order_arc_626  1
    order_0_2  connected_order_arc_651  1
    order_0_2  connected_order_arc_676  1
    order_0_2  connected_order_arc_701  1
    order_0_2  connected_order_arc_726  1
    order_0_2  connected_order_arc_751  1
    order_0_2  connected_order_arc_776  1
    order_0_2  order_active_lb_808  1
    order_0_2  order_active_ub_809  1
    order_0_2  fixed_segment_relative_order_882  1
    order_0_2  fixed_segment_relative_order_883  -1
    visit_0_3  out_degree_813  -1
    visit_0_3  in_degree_814  -1
    visit_0_3  order_active_lb_815  -1
    visit_0_3  order_active_ub_816  -13
    order_0_3  connected_order_arc_476  1
    order_0_3  connected_order_arc_501  1
    order_0_3  connected_order_arc_524  -1
    order_0_3  connected_order_arc_526  -1
    order_0_3  connected_order_arc_528  -1
    order_0_3  connected_order_arc_530  -1
    order_0_3  connected_order_arc_532  -1
    order_0_3  connected_order_arc_534  -1
    order_0_3  connected_order_arc_536  -1
    order_0_3  connected_order_arc_538  -1
    order_0_3  connected_order_arc_540  -1
    order_0_3  connected_order_arc_542  -1
    order_0_3  connected_order_arc_544  -1
    order_0_3  connected_order_arc_546  -1
    order_0_3  connected_order_arc_553  1
    order_0_3  connected_order_arc_578  1
    order_0_3  connected_order_arc_603  1
    order_0_3  connected_order_arc_628  1
    order_0_3  connected_order_arc_653  1
    order_0_3  connected_order_arc_678  1
    order_0_3  connected_order_arc_703  1
    order_0_3  connected_order_arc_728  1
    order_0_3  connected_order_arc_753  1
    order_0_3  connected_order_arc_778  1
    order_0_3  order_active_lb_815  1
    order_0_3  order_active_ub_816  1
    order_0_3  fixed_segment_relative_order_883  1
    order_0_3  fixed_segment_relative_order_884  -1
    visit_0_4  out_degree_820  -1
    visit_0_4  in_degree_821  -1
    visit_0_4  order_active_lb_822  -1
    visit_0_4  order_active_ub_823  -13
    order_0_4  connected_order_arc_478  1
    order_0_4  connected_order_arc_503  1
    order_0_4  connected_order_arc_528  1
    order_0_4  connected_order_arc_549  -1
    order_0_4  connected_order_arc_551  -1
    order_0_4  connected_order_arc_553  -1
    order_0_4  connected_order_arc_555  -1
    order_0_4  connected_order_arc_557  -1
    order_0_4  connected_order_arc_559  -1
    order_0_4  connected_order_arc_561  -1
    order_0_4  connected_order_arc_563  -1
    order_0_4  connected_order_arc_565  -1
    order_0_4  connected_order_arc_567  -1
    order_0_4  connected_order_arc_569  -1
    order_0_4  connected_order_arc_571  -1
    order_0_4  connected_order_arc_580  1
    order_0_4  connected_order_arc_605  1
    order_0_4  connected_order_arc_630  1
    order_0_4  connected_order_arc_655  1
    order_0_4  connected_order_arc_680  1
    order_0_4  connected_order_arc_705  1
    order_0_4  connected_order_arc_730  1
    order_0_4  connected_order_arc_755  1
    order_0_4  connected_order_arc_780  1
    order_0_4  order_active_lb_822  1
    order_0_4  order_active_ub_823  1
    order_0_4  fixed_segment_relative_order_884  1
    order_0_4  fixed_segment_relative_order_885  -1
    visit_0_5  out_degree_827  -1
    visit_0_5  in_degree_828  -1
    visit_0_5  order_active_lb_829  -1
    visit_0_5  order_active_ub_830  -13
    order_0_5  connected_order_arc_480  1
    order_0_5  connected_order_arc_505  1
    order_0_5  connected_order_arc_530  1
    order_0_5  connected_order_arc_555  1
    order_0_5  connected_order_arc_574  -1
    order_0_5  connected_order_arc_576  -1
    order_0_5  connected_order_arc_578  -1
    order_0_5  connected_order_arc_580  -1
    order_0_5  connected_order_arc_582  -1
    order_0_5  connected_order_arc_584  -1
    order_0_5  connected_order_arc_586  -1
    order_0_5  connected_order_arc_588  -1
    order_0_5  connected_order_arc_590  -1
    order_0_5  connected_order_arc_592  -1
    order_0_5  connected_order_arc_594  -1
    order_0_5  connected_order_arc_596  -1
    order_0_5  connected_order_arc_607  1
    order_0_5  connected_order_arc_632  1
    order_0_5  connected_order_arc_657  1
    order_0_5  connected_order_arc_682  1
    order_0_5  connected_order_arc_707  1
    order_0_5  connected_order_arc_732  1
    order_0_5  connected_order_arc_757  1
    order_0_5  connected_order_arc_782  1
    order_0_5  order_active_lb_829  1
    order_0_5  order_active_ub_830  1
    order_0_5  fixed_segment_relative_order_885  1
    visit_0_13  out_degree_834  -1
    visit_0_13  in_degree_835  -1
    visit_0_13  order_active_lb_836  -1
    visit_0_13  order_active_ub_837  -13
    visit_0_13  service_visit_def_838  -1
    order_0_13  connected_order_arc_482  1
    order_0_13  connected_order_arc_507  1
    order_0_13  connected_order_arc_532  1
    order_0_13  connected_order_arc_557  1
    order_0_13  connected_order_arc_582  1
    order_0_13  connected_order_arc_599  -1
    order_0_13  connected_order_arc_601  -1
    order_0_13  connected_order_arc_603  -1
    order_0_13  connected_order_arc_605  -1
    order_0_13  connected_order_arc_607  -1
    order_0_13  connected_order_arc_609  -1
    order_0_13  connected_order_arc_611  -1
    order_0_13  connected_order_arc_613  -1
    order_0_13  connected_order_arc_615  -1
    order_0_13  connected_order_arc_617  -1
    order_0_13  connected_order_arc_619  -1
    order_0_13  connected_order_arc_621  -1
    order_0_13  connected_order_arc_634  1
    order_0_13  connected_order_arc_659  1
    order_0_13  connected_order_arc_684  1
    order_0_13  connected_order_arc_709  1
    order_0_13  connected_order_arc_734  1
    order_0_13  connected_order_arc_759  1
    order_0_13  connected_order_arc_784  1
    order_0_13  order_active_lb_836  1
    order_0_13  order_active_ub_837  1
    visit_0_14  out_degree_840  -1
    visit_0_14  in_degree_841  -1
    visit_0_14  order_active_lb_842  -1
    visit_0_14  order_active_ub_843  -13
    visit_0_14  service_visit_def_844  -1
    order_0_14  connected_order_arc_484  1
    order_0_14  connected_order_arc_509  1
    order_0_14  connected_order_arc_534  1
    order_0_14  connected_order_arc_559  1
    order_0_14  connected_order_arc_584  1
    order_0_14  connected_order_arc_609  1
    order_0_14  connected_order_arc_624  -1
    order_0_14  connected_order_arc_626  -1
    order_0_14  connected_order_arc_628  -1
    order_0_14  connected_order_arc_630  -1
    order_0_14  connected_order_arc_632  -1
    order_0_14  connected_order_arc_634  -1
    order_0_14  connected_order_arc_636  -1
    order_0_14  connected_order_arc_638  -1
    order_0_14  connected_order_arc_640  -1
    order_0_14  connected_order_arc_642  -1
    order_0_14  connected_order_arc_644  -1
    order_0_14  connected_order_arc_646  -1
    order_0_14  connected_order_arc_661  1
    order_0_14  connected_order_arc_686  1
    order_0_14  connected_order_arc_711  1
    order_0_14  connected_order_arc_736  1
    order_0_14  connected_order_arc_761  1
    order_0_14  connected_order_arc_786  1
    order_0_14  order_active_lb_842  1
    order_0_14  order_active_ub_843  1
    visit_0_15  out_degree_846  -1
    visit_0_15  in_degree_847  -1
    visit_0_15  order_active_lb_848  -1
    visit_0_15  order_active_ub_849  -13
    visit_0_15  service_visit_def_850  -1
    order_0_15  connected_order_arc_486  1
    order_0_15  connected_order_arc_511  1
    order_0_15  connected_order_arc_536  1
    order_0_15  connected_order_arc_561  1
    order_0_15  connected_order_arc_586  1
    order_0_15  connected_order_arc_611  1
    order_0_15  connected_order_arc_636  1
    order_0_15  connected_order_arc_649  -1
    order_0_15  connected_order_arc_651  -1
    order_0_15  connected_order_arc_653  -1
    order_0_15  connected_order_arc_655  -1
    order_0_15  connected_order_arc_657  -1
    order_0_15  connected_order_arc_659  -1
    order_0_15  connected_order_arc_661  -1
    order_0_15  connected_order_arc_663  -1
    order_0_15  connected_order_arc_665  -1
    order_0_15  connected_order_arc_667  -1
    order_0_15  connected_order_arc_669  -1
    order_0_15  connected_order_arc_671  -1
    order_0_15  connected_order_arc_688  1
    order_0_15  connected_order_arc_713  1
    order_0_15  connected_order_arc_738  1
    order_0_15  connected_order_arc_763  1
    order_0_15  connected_order_arc_788  1
    order_0_15  order_active_lb_848  1
    order_0_15  order_active_ub_849  1
    visit_0_16  out_degree_852  -1
    visit_0_16  in_degree_853  -1
    visit_0_16  order_active_lb_854  -1
    visit_0_16  order_active_ub_855  -13
    visit_0_16  service_visit_def_856  -1
    order_0_16  connected_order_arc_488  1
    order_0_16  connected_order_arc_513  1
    order_0_16  connected_order_arc_538  1
    order_0_16  connected_order_arc_563  1
    order_0_16  connected_order_arc_588  1
    order_0_16  connected_order_arc_613  1
    order_0_16  connected_order_arc_638  1
    order_0_16  connected_order_arc_663  1
    order_0_16  connected_order_arc_674  -1
    order_0_16  connected_order_arc_676  -1
    order_0_16  connected_order_arc_678  -1
    order_0_16  connected_order_arc_680  -1
    order_0_16  connected_order_arc_682  -1
    order_0_16  connected_order_arc_684  -1
    order_0_16  connected_order_arc_686  -1
    order_0_16  connected_order_arc_688  -1
    order_0_16  connected_order_arc_690  -1
    order_0_16  connected_order_arc_692  -1
    order_0_16  connected_order_arc_694  -1
    order_0_16  connected_order_arc_696  -1
    order_0_16  connected_order_arc_715  1
    order_0_16  connected_order_arc_740  1
    order_0_16  connected_order_arc_765  1
    order_0_16  connected_order_arc_790  1
    order_0_16  order_active_lb_854  1
    order_0_16  order_active_ub_855  1
    visit_0_17  out_degree_858  -1
    visit_0_17  in_degree_859  -1
    visit_0_17  order_active_lb_860  -1
    visit_0_17  order_active_ub_861  -13
    visit_0_17  service_visit_def_862  -1
    order_0_17  connected_order_arc_490  1
    order_0_17  connected_order_arc_515  1
    order_0_17  connected_order_arc_540  1
    order_0_17  connected_order_arc_565  1
    order_0_17  connected_order_arc_590  1
    order_0_17  connected_order_arc_615  1
    order_0_17  connected_order_arc_640  1
    order_0_17  connected_order_arc_665  1
    order_0_17  connected_order_arc_690  1
    order_0_17  connected_order_arc_699  -1
    order_0_17  connected_order_arc_701  -1
    order_0_17  connected_order_arc_703  -1
    order_0_17  connected_order_arc_705  -1
    order_0_17  connected_order_arc_707  -1
    order_0_17  connected_order_arc_709  -1
    order_0_17  connected_order_arc_711  -1
    order_0_17  connected_order_arc_713  -1
    order_0_17  connected_order_arc_715  -1
    order_0_17  connected_order_arc_717  -1
    order_0_17  connected_order_arc_719  -1
    order_0_17  connected_order_arc_721  -1
    order_0_17  connected_order_arc_742  1
    order_0_17  connected_order_arc_767  1
    order_0_17  connected_order_arc_792  1
    order_0_17  order_active_lb_860  1
    order_0_17  order_active_ub_861  1
    visit_0_18  out_degree_864  -1
    visit_0_18  in_degree_865  -1
    visit_0_18  order_active_lb_866  -1
    visit_0_18  order_active_ub_867  -13
    visit_0_18  service_visit_def_868  -1
    order_0_18  connected_order_arc_492  1
    order_0_18  connected_order_arc_517  1
    order_0_18  connected_order_arc_542  1
    order_0_18  connected_order_arc_567  1
    order_0_18  connected_order_arc_592  1
    order_0_18  connected_order_arc_617  1
    order_0_18  connected_order_arc_642  1
    order_0_18  connected_order_arc_667  1
    order_0_18  connected_order_arc_692  1
    order_0_18  connected_order_arc_717  1
    order_0_18  connected_order_arc_724  -1
    order_0_18  connected_order_arc_726  -1
    order_0_18  connected_order_arc_728  -1
    order_0_18  connected_order_arc_730  -1
    order_0_18  connected_order_arc_732  -1
    order_0_18  connected_order_arc_734  -1
    order_0_18  connected_order_arc_736  -1
    order_0_18  connected_order_arc_738  -1
    order_0_18  connected_order_arc_740  -1
    order_0_18  connected_order_arc_742  -1
    order_0_18  connected_order_arc_744  -1
    order_0_18  connected_order_arc_746  -1
    order_0_18  connected_order_arc_769  1
    order_0_18  connected_order_arc_794  1
    order_0_18  order_active_lb_866  1
    order_0_18  order_active_ub_867  1
    visit_0_19  out_degree_870  -1
    visit_0_19  in_degree_871  -1
    visit_0_19  order_active_lb_872  -1
    visit_0_19  order_active_ub_873  -13
    visit_0_19  service_visit_def_874  -1
    order_0_19  connected_order_arc_494  1
    order_0_19  connected_order_arc_519  1
    order_0_19  connected_order_arc_544  1
    order_0_19  connected_order_arc_569  1
    order_0_19  connected_order_arc_594  1
    order_0_19  connected_order_arc_619  1
    order_0_19  connected_order_arc_644  1
    order_0_19  connected_order_arc_669  1
    order_0_19  connected_order_arc_694  1
    order_0_19  connected_order_arc_719  1
    order_0_19  connected_order_arc_744  1
    order_0_19  connected_order_arc_749  -1
    order_0_19  connected_order_arc_751  -1
    order_0_19  connected_order_arc_753  -1
    order_0_19  connected_order_arc_755  -1
    order_0_19  connected_order_arc_757  -1
    order_0_19  connected_order_arc_759  -1
    order_0_19  connected_order_arc_761  -1
    order_0_19  connected_order_arc_763  -1
    order_0_19  connected_order_arc_765  -1
    order_0_19  connected_order_arc_767  -1
    order_0_19  connected_order_arc_769  -1
    order_0_19  connected_order_arc_771  -1
    order_0_19  connected_order_arc_796  1
    order_0_19  order_active_lb_872  1
    order_0_19  order_active_ub_873  1
    visit_0_20  out_degree_876  -1
    visit_0_20  in_degree_877  -1
    visit_0_20  order_active_lb_878  -1
    visit_0_20  order_active_ub_879  -13
    visit_0_20  service_visit_def_880  -1
    order_0_20  connected_order_arc_496  1
    order_0_20  connected_order_arc_521  1
    order_0_20  connected_order_arc_546  1
    order_0_20  connected_order_arc_571  1
    order_0_20  connected_order_arc_596  1
    order_0_20  connected_order_arc_621  1
    order_0_20  connected_order_arc_646  1
    order_0_20  connected_order_arc_671  1
    order_0_20  connected_order_arc_696  1
    order_0_20  connected_order_arc_721  1
    order_0_20  connected_order_arc_746  1
    order_0_20  connected_order_arc_771  1
    order_0_20  connected_order_arc_774  -1
    order_0_20  connected_order_arc_776  -1
    order_0_20  connected_order_arc_778  -1
    order_0_20  connected_order_arc_780  -1
    order_0_20  connected_order_arc_782  -1
    order_0_20  connected_order_arc_784  -1
    order_0_20  connected_order_arc_786  -1
    order_0_20  connected_order_arc_788  -1
    order_0_20  connected_order_arc_790  -1
    order_0_20  connected_order_arc_792  -1
    order_0_20  connected_order_arc_794  -1
    order_0_20  connected_order_arc_796  -1
    order_0_20  order_active_lb_878  1
    order_0_20  order_active_ub_879  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_0  arc_capacity_458  -20
    arc_0_0_0  depot_departure_or_bypass_797  1
    arc_0_0_0  depot_return_or_bypass_798  1
    MARKER    'MARKER'                 'INTEND'
    load_0_0_0  arc_capacity_458  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_1  arc_capacity_459  -20
    arc_0_0_1  depot_departure_or_bypass_797  1
    arc_0_0_1  in_degree_800  1
    arc_0_0_1  original_T_including_depot_unload_886  4.7522445589173662e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_1  arc_capacity_459  1
    load_0_0_1  segment_load_conservation_803  -1
    load_0_0_1  segment_prefix_lb_804  1
    load_0_0_1  segment_prefix_ub_805  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_2  arc_capacity_460  -20
    arc_0_0_2  depot_departure_or_bypass_797  1
    arc_0_0_2  in_degree_807  1
    arc_0_0_2  original_T_including_depot_unload_886  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_2  arc_capacity_460  1
    load_0_0_2  segment_load_conservation_810  -1
    load_0_0_2  segment_prefix_lb_811  1
    load_0_0_2  segment_prefix_ub_812  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_3  arc_capacity_461  -20
    arc_0_0_3  depot_departure_or_bypass_797  1
    arc_0_0_3  in_degree_814  1
    arc_0_0_3  original_T_including_depot_unload_886  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_3  arc_capacity_461  1
    load_0_0_3  segment_load_conservation_817  -1
    load_0_0_3  segment_prefix_lb_818  1
    load_0_0_3  segment_prefix_ub_819  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_4  arc_capacity_462  -20
    arc_0_0_4  depot_departure_or_bypass_797  1
    arc_0_0_4  in_degree_821  1
    arc_0_0_4  original_T_including_depot_unload_886  6.6653528395596720e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_4  arc_capacity_462  1
    load_0_0_4  segment_load_conservation_824  -1
    load_0_0_4  segment_prefix_lb_825  1
    load_0_0_4  segment_prefix_ub_826  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_5  arc_capacity_463  -20
    arc_0_0_5  depot_departure_or_bypass_797  1
    arc_0_0_5  in_degree_828  1
    arc_0_0_5  original_T_including_depot_unload_886  4.6364706268001146e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_5  arc_capacity_463  1
    load_0_0_5  segment_load_conservation_831  -1
    load_0_0_5  segment_prefix_lb_832  1
    load_0_0_5  segment_prefix_ub_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_13  arc_capacity_464  -20
    arc_0_0_13  depot_departure_or_bypass_797  1
    arc_0_0_13  in_degree_835  1
    arc_0_0_13  original_T_including_depot_unload_886  5.4249700630778887e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_13  arc_capacity_464  1
    load_0_0_13  free_load_conservation_839  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_14  arc_capacity_465  -20
    arc_0_0_14  depot_departure_or_bypass_797  1
    arc_0_0_14  in_degree_841  1
    arc_0_0_14  original_T_including_depot_unload_886  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_14  arc_capacity_465  1
    load_0_0_14  free_load_conservation_845  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_15  arc_capacity_466  -20
    arc_0_0_15  depot_departure_or_bypass_797  1
    arc_0_0_15  in_degree_847  1
    arc_0_0_15  original_T_including_depot_unload_886  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_15  arc_capacity_466  1
    load_0_0_15  free_load_conservation_851  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_16  arc_capacity_467  -20
    arc_0_0_16  depot_departure_or_bypass_797  1
    arc_0_0_16  in_degree_853  1
    arc_0_0_16  original_T_including_depot_unload_886  4.9403722507151832e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_16  arc_capacity_467  1
    load_0_0_16  free_load_conservation_857  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_17  arc_capacity_468  -20
    arc_0_0_17  depot_departure_or_bypass_797  1
    arc_0_0_17  in_degree_859  1
    arc_0_0_17  original_T_including_depot_unload_886  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_17  arc_capacity_468  1
    load_0_0_17  free_load_conservation_863  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_18  arc_capacity_469  -20
    arc_0_0_18  depot_departure_or_bypass_797  1
    arc_0_0_18  in_degree_865  1
    arc_0_0_18  original_T_including_depot_unload_886  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_18  arc_capacity_469  1
    load_0_0_18  free_load_conservation_869  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_19  arc_capacity_470  -20
    arc_0_0_19  depot_departure_or_bypass_797  1
    arc_0_0_19  in_degree_871  1
    arc_0_0_19  original_T_including_depot_unload_886  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_19  arc_capacity_470  1
    load_0_0_19  free_load_conservation_875  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_20  arc_capacity_471  -20
    arc_0_0_20  depot_departure_or_bypass_797  1
    arc_0_0_20  in_degree_877  1
    arc_0_0_20  original_T_including_depot_unload_886  7.2130540230577469e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_20  arc_capacity_471  1
    load_0_0_20  free_load_conservation_881  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_0  arc_capacity_472  -20
    arc_0_1_0  depot_return_or_bypass_798  1
    arc_0_1_0  out_degree_799  1
    arc_0_1_0  original_T_including_depot_unload_886  4.7522445589173662e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_0  arc_capacity_472  1
    load_0_1_0  segment_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_2  arc_capacity_473  -20
    arc_0_1_2  connected_order_arc_474  -14
    arc_0_1_2  out_degree_799  1
    arc_0_1_2  in_degree_807  1
    arc_0_1_2  original_T_including_depot_unload_886  6.7803521648175558e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_2  arc_capacity_473  1
    load_0_1_2  segment_load_conservation_803  1
    load_0_1_2  segment_load_conservation_810  -1
    load_0_1_2  segment_prefix_lb_811  1
    load_0_1_2  segment_prefix_ub_812  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_3  arc_capacity_475  -20
    arc_0_1_3  connected_order_arc_476  -14
    arc_0_1_3  out_degree_799  1
    arc_0_1_3  in_degree_814  1
    arc_0_1_3  original_T_including_depot_unload_886  7.7690262287132452e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_3  arc_capacity_475  1
    load_0_1_3  segment_load_conservation_803  1
    load_0_1_3  segment_load_conservation_817  -1
    load_0_1_3  segment_prefix_lb_818  1
    load_0_1_3  segment_prefix_ub_819  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_4  arc_capacity_477  -20
    arc_0_1_4  connected_order_arc_478  -14
    arc_0_1_4  out_degree_799  1
    arc_0_1_4  in_degree_821  1
    arc_0_1_4  original_T_including_depot_unload_886  9.1345700487521981e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_4  arc_capacity_477  1
    load_0_1_4  segment_load_conservation_803  1
    load_0_1_4  segment_load_conservation_824  -1
    load_0_1_4  segment_prefix_lb_825  1
    load_0_1_4  segment_prefix_ub_826  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_5  arc_capacity_479  -20
    arc_0_1_5  connected_order_arc_480  -14
    arc_0_1_5  out_degree_799  1
    arc_0_1_5  in_degree_828  1
    arc_0_1_5  original_T_including_depot_unload_886  9.2985081319651772e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_5  arc_capacity_479  1
    load_0_1_5  segment_load_conservation_803  1
    load_0_1_5  segment_load_conservation_831  -1
    load_0_1_5  segment_prefix_lb_832  1
    load_0_1_5  segment_prefix_ub_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_13  arc_capacity_481  -20
    arc_0_1_13  connected_order_arc_482  -14
    arc_0_1_13  out_degree_799  1
    arc_0_1_13  in_degree_835  1
    arc_0_1_13  original_T_including_depot_unload_886  4.4474809771996007e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_13  arc_capacity_481  1
    load_0_1_13  segment_load_conservation_803  1
    load_0_1_13  free_load_conservation_839  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_14  arc_capacity_483  -20
    arc_0_1_14  connected_order_arc_484  -14
    arc_0_1_14  out_degree_799  1
    arc_0_1_14  in_degree_841  1
    arc_0_1_14  original_T_including_depot_unload_886  5.2534086948364859e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_14  arc_capacity_483  1
    load_0_1_14  segment_load_conservation_803  1
    load_0_1_14  free_load_conservation_845  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_15  arc_capacity_485  -20
    arc_0_1_15  connected_order_arc_486  -14
    arc_0_1_15  out_degree_799  1
    arc_0_1_15  in_degree_847  1
    arc_0_1_15  original_T_including_depot_unload_886  1.3823927712314810e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_15  arc_capacity_485  1
    load_0_1_15  segment_load_conservation_803  1
    load_0_1_15  free_load_conservation_851  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_16  arc_capacity_487  -20
    arc_0_1_16  connected_order_arc_488  -14
    arc_0_1_16  out_degree_799  1
    arc_0_1_16  in_degree_853  1
    arc_0_1_16  original_T_including_depot_unload_886  2.1911621128640562e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_16  arc_capacity_487  1
    load_0_1_16  segment_load_conservation_803  1
    load_0_1_16  free_load_conservation_857  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_17  arc_capacity_489  -20
    arc_0_1_17  connected_order_arc_490  -14
    arc_0_1_17  out_degree_799  1
    arc_0_1_17  in_degree_859  1
    arc_0_1_17  original_T_including_depot_unload_886  1.8418804985785646e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_17  arc_capacity_489  1
    load_0_1_17  segment_load_conservation_803  1
    load_0_1_17  free_load_conservation_863  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_18  arc_capacity_491  -20
    arc_0_1_18  connected_order_arc_492  -14
    arc_0_1_18  out_degree_799  1
    arc_0_1_18  in_degree_865  1
    arc_0_1_18  original_T_including_depot_unload_886  2.9438424317501273e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_18  arc_capacity_491  1
    load_0_1_18  segment_load_conservation_803  1
    load_0_1_18  free_load_conservation_869  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_19  arc_capacity_493  -20
    arc_0_1_19  connected_order_arc_494  -14
    arc_0_1_19  out_degree_799  1
    arc_0_1_19  in_degree_871  1
    arc_0_1_19  original_T_including_depot_unload_886  1.1957430085580884e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_19  arc_capacity_493  1
    load_0_1_19  segment_load_conservation_803  1
    load_0_1_19  free_load_conservation_875  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_20  arc_capacity_495  -20
    arc_0_1_20  connected_order_arc_496  -14
    arc_0_1_20  out_degree_799  1
    arc_0_1_20  in_degree_877  1
    arc_0_1_20  original_T_including_depot_unload_886  3.6338251321041224e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_20  arc_capacity_495  1
    load_0_1_20  segment_load_conservation_803  1
    load_0_1_20  free_load_conservation_881  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_0  arc_capacity_497  -20
    arc_0_2_0  depot_return_or_bypass_798  1
    arc_0_2_0  out_degree_806  1
    arc_0_2_0  original_T_including_depot_unload_886  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_0  arc_capacity_497  1
    load_0_2_0  segment_load_conservation_810  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_1  arc_capacity_498  -20
    arc_0_2_1  connected_order_arc_499  -14
    arc_0_2_1  in_degree_800  1
    arc_0_2_1  out_degree_806  1
    arc_0_2_1  original_T_including_depot_unload_886  6.7803521648175558e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_1  arc_capacity_498  1
    load_0_2_1  segment_load_conservation_803  -1
    load_0_2_1  segment_prefix_lb_804  1
    load_0_2_1  segment_prefix_ub_805  1
    load_0_2_1  segment_load_conservation_810  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_3  arc_capacity_500  -20
    arc_0_2_3  connected_order_arc_501  -14
    arc_0_2_3  out_degree_806  1
    arc_0_2_3  in_degree_814  1
    arc_0_2_3  original_T_including_depot_unload_886  2.4111148152767828e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_3  arc_capacity_500  1
    load_0_2_3  segment_load_conservation_810  1
    load_0_2_3  segment_load_conservation_817  -1
    load_0_2_3  segment_prefix_lb_818  1
    load_0_2_3  segment_prefix_ub_819  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_4  arc_capacity_502  -20
    arc_0_2_4  connected_order_arc_503  -14
    arc_0_2_4  out_degree_806  1
    arc_0_2_4  in_degree_821  1
    arc_0_2_4  original_T_including_depot_unload_886  2.3649901674897566e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_4  arc_capacity_502  1
    load_0_2_4  segment_load_conservation_810  1
    load_0_2_4  segment_load_conservation_824  -1
    load_0_2_4  segment_prefix_lb_825  1
    load_0_2_4  segment_prefix_ub_826  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_5  arc_capacity_504  -20
    arc_0_2_5  connected_order_arc_505  -14
    arc_0_2_5  out_degree_806  1
    arc_0_2_5  in_degree_828  1
    arc_0_2_5  original_T_including_depot_unload_886  5.8212369880329140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_5  arc_capacity_504  1
    load_0_2_5  segment_load_conservation_810  1
    load_0_2_5  segment_load_conservation_831  -1
    load_0_2_5  segment_prefix_lb_832  1
    load_0_2_5  segment_prefix_ub_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_13  arc_capacity_506  -20
    arc_0_2_13  connected_order_arc_507  -14
    arc_0_2_13  out_degree_806  1
    arc_0_2_13  in_degree_835  1
    arc_0_2_13  original_T_including_depot_unload_886  3.3800157717255917e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_13  arc_capacity_506  1
    load_0_2_13  segment_load_conservation_810  1
    load_0_2_13  free_load_conservation_839  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_14  arc_capacity_508  -20
    arc_0_2_14  connected_order_arc_509  -14
    arc_0_2_14  out_degree_806  1
    arc_0_2_14  in_degree_841  1
    arc_0_2_14  original_T_including_depot_unload_886  1.7053268374267958e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_14  arc_capacity_508  1
    load_0_2_14  segment_load_conservation_810  1
    load_0_2_14  free_load_conservation_845  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_15  arc_capacity_510  -20
    arc_0_2_15  connected_order_arc_511  -14
    arc_0_2_15  out_degree_806  1
    arc_0_2_15  in_degree_847  1
    arc_0_2_15  original_T_including_depot_unload_886  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_15  arc_capacity_510  1
    load_0_2_15  segment_load_conservation_810  1
    load_0_2_15  free_load_conservation_851  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_16  arc_capacity_512  -20
    arc_0_2_16  connected_order_arc_513  -14
    arc_0_2_16  out_degree_806  1
    arc_0_2_16  in_degree_853  1
    arc_0_2_16  original_T_including_depot_unload_886  5.1510428418120409e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_16  arc_capacity_512  1
    load_0_2_16  segment_load_conservation_810  1
    load_0_2_16  free_load_conservation_857  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_17  arc_capacity_514  -20
    arc_0_2_17  connected_order_arc_515  -14
    arc_0_2_17  out_degree_806  1
    arc_0_2_17  in_degree_859  1
    arc_0_2_17  original_T_including_depot_unload_886  1.4150780419437449e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_17  arc_capacity_514  1
    load_0_2_17  segment_load_conservation_810  1
    load_0_2_17  free_load_conservation_863  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_18  arc_capacity_516  -20
    arc_0_2_18  connected_order_arc_517  -14
    arc_0_2_18  out_degree_806  1
    arc_0_2_18  in_degree_865  1
    arc_0_2_18  original_T_including_depot_unload_886  3.9758967496529505e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_18  arc_capacity_516  1
    load_0_2_18  segment_load_conservation_810  1
    load_0_2_18  free_load_conservation_869  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_19  arc_capacity_518  -20
    arc_0_2_19  connected_order_arc_519  -14
    arc_0_2_19  out_degree_806  1
    arc_0_2_19  in_degree_871  1
    arc_0_2_19  original_T_including_depot_unload_886  7.9403551275216375e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_19  arc_capacity_518  1
    load_0_2_19  segment_load_conservation_810  1
    load_0_2_19  free_load_conservation_875  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_20  arc_capacity_520  -20
    arc_0_2_20  connected_order_arc_521  -14
    arc_0_2_20  out_degree_806  1
    arc_0_2_20  in_degree_877  1
    arc_0_2_20  original_T_including_depot_unload_886  6.6047504008669523e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_20  arc_capacity_520  1
    load_0_2_20  segment_load_conservation_810  1
    load_0_2_20  free_load_conservation_881  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_0  arc_capacity_522  -20
    arc_0_3_0  depot_return_or_bypass_798  1
    arc_0_3_0  out_degree_813  1
    arc_0_3_0  original_T_including_depot_unload_886  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_0  arc_capacity_522  1
    load_0_3_0  segment_load_conservation_817  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_1  arc_capacity_523  -20
    arc_0_3_1  connected_order_arc_524  -14
    arc_0_3_1  in_degree_800  1
    arc_0_3_1  out_degree_813  1
    arc_0_3_1  original_T_including_depot_unload_886  7.7690262287132452e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_1  arc_capacity_523  1
    load_0_3_1  segment_load_conservation_803  -1
    load_0_3_1  segment_prefix_lb_804  1
    load_0_3_1  segment_prefix_ub_805  1
    load_0_3_1  segment_load_conservation_817  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_2  arc_capacity_525  -20
    arc_0_3_2  connected_order_arc_526  -14
    arc_0_3_2  in_degree_807  1
    arc_0_3_2  out_degree_813  1
    arc_0_3_2  original_T_including_depot_unload_886  2.4111148152767828e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_2  arc_capacity_525  1
    load_0_3_2  segment_load_conservation_810  -1
    load_0_3_2  segment_prefix_lb_811  1
    load_0_3_2  segment_prefix_ub_812  1
    load_0_3_2  segment_load_conservation_817  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_4  arc_capacity_527  -20
    arc_0_3_4  connected_order_arc_528  -14
    arc_0_3_4  out_degree_813  1
    arc_0_3_4  in_degree_821  1
    arc_0_3_4  original_T_including_depot_unload_886  3.1069481377857926e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_4  arc_capacity_527  1
    load_0_3_4  segment_load_conservation_817  1
    load_0_3_4  segment_load_conservation_824  -1
    load_0_3_4  segment_prefix_lb_825  1
    load_0_3_4  segment_prefix_ub_826  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_5  arc_capacity_529  -20
    arc_0_3_5  connected_order_arc_530  -14
    arc_0_3_5  out_degree_813  1
    arc_0_3_5  in_degree_828  1
    arc_0_3_5  original_T_including_depot_unload_886  8.1289340937717509e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_5  arc_capacity_529  1
    load_0_3_5  segment_load_conservation_817  1
    load_0_3_5  segment_load_conservation_831  -1
    load_0_3_5  segment_prefix_lb_832  1
    load_0_3_5  segment_prefix_ub_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_13  arc_capacity_531  -20
    arc_0_3_13  connected_order_arc_532  -14
    arc_0_3_13  out_degree_813  1
    arc_0_3_13  in_degree_835  1
    arc_0_3_13  original_T_including_depot_unload_886  3.4289721135663990e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_13  arc_capacity_531  1
    load_0_3_13  segment_load_conservation_817  1
    load_0_3_13  free_load_conservation_839  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_14  arc_capacity_533  -20
    arc_0_3_14  connected_order_arc_534  -14
    arc_0_3_14  out_degree_813  1
    arc_0_3_14  in_degree_841  1
    arc_0_3_14  original_T_including_depot_unload_886  2.7570828838654035e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_14  arc_capacity_533  1
    load_0_3_14  segment_load_conservation_817  1
    load_0_3_14  free_load_conservation_845  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_15  arc_capacity_535  -20
    arc_0_3_15  connected_order_arc_536  -14
    arc_0_3_15  out_degree_813  1
    arc_0_3_15  in_degree_847  1
    arc_0_3_15  original_T_including_depot_unload_886  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_15  arc_capacity_535  1
    load_0_3_15  segment_load_conservation_817  1
    load_0_3_15  free_load_conservation_851  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_16  arc_capacity_537  -20
    arc_0_3_16  connected_order_arc_538  -14
    arc_0_3_16  out_degree_813  1
    arc_0_3_16  in_degree_853  1
    arc_0_3_16  original_T_including_depot_unload_886  5.7237486782756332e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_16  arc_capacity_537  1
    load_0_3_16  segment_load_conservation_817  1
    load_0_3_16  free_load_conservation_857  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_17  arc_capacity_539  -20
    arc_0_3_17  connected_order_arc_540  -14
    arc_0_3_17  out_degree_813  1
    arc_0_3_17  in_degree_859  1
    arc_0_3_17  original_T_including_depot_unload_886  1.5968108380866881e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_17  arc_capacity_539  1
    load_0_3_17  segment_load_conservation_817  1
    load_0_3_17  free_load_conservation_863  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_18  arc_capacity_541  -20
    arc_0_3_18  connected_order_arc_542  -14
    arc_0_3_18  out_degree_813  1
    arc_0_3_18  in_degree_865  1
    arc_0_3_18  original_T_including_depot_unload_886  545.439458844012
    MARKER    'MARKER'                 'INTEND'
    load_0_3_18  arc_capacity_541  1
    load_0_3_18  segment_load_conservation_817  1
    load_0_3_18  free_load_conservation_869  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_19  arc_capacity_543  -20
    arc_0_3_19  connected_order_arc_544  -14
    arc_0_3_19  out_degree_813  1
    arc_0_3_19  in_degree_871  1
    arc_0_3_19  original_T_including_depot_unload_886  1.0038065985492663e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_19  arc_capacity_543  1
    load_0_3_19  segment_load_conservation_817  1
    load_0_3_19  free_load_conservation_875  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_20  arc_capacity_545  -20
    arc_0_3_20  connected_order_arc_546  -14
    arc_0_3_20  out_degree_813  1
    arc_0_3_20  in_degree_877  1
    arc_0_3_20  original_T_including_depot_unload_886  6.3648699141452130e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_20  arc_capacity_545  1
    load_0_3_20  segment_load_conservation_817  1
    load_0_3_20  free_load_conservation_881  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_0  arc_capacity_547  -20
    arc_0_4_0  depot_return_or_bypass_798  1
    arc_0_4_0  out_degree_820  1
    arc_0_4_0  original_T_including_depot_unload_886  7.2571167924583824e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_0  arc_capacity_547  1
    load_0_4_0  segment_load_conservation_824  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_1  arc_capacity_548  -20
    arc_0_4_1  connected_order_arc_549  -14
    arc_0_4_1  in_degree_800  1
    arc_0_4_1  out_degree_820  1
    arc_0_4_1  original_T_including_depot_unload_886  1.1605914703789122e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_1  arc_capacity_548  1
    load_0_4_1  segment_load_conservation_803  -1
    load_0_4_1  segment_prefix_lb_804  1
    load_0_4_1  segment_prefix_ub_805  1
    load_0_4_1  segment_load_conservation_824  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_2  arc_capacity_550  -20
    arc_0_4_2  connected_order_arc_551  -14
    arc_0_4_2  in_degree_807  1
    arc_0_4_2  out_degree_820  1
    arc_0_4_2  original_T_including_depot_unload_886  6.4542450829473034e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_2  arc_capacity_550  1
    load_0_4_2  segment_load_conservation_810  -1
    load_0_4_2  segment_prefix_lb_811  1
    load_0_4_2  segment_prefix_ub_812  1
    load_0_4_2  segment_load_conservation_824  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_3  arc_capacity_552  -20
    arc_0_4_3  connected_order_arc_553  -14
    arc_0_4_3  in_degree_814  1
    arc_0_4_3  out_degree_820  1
    arc_0_4_3  original_T_including_depot_unload_886  8.2707974701454475e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_3  arc_capacity_552  1
    load_0_4_3  segment_load_conservation_817  -1
    load_0_4_3  segment_prefix_lb_818  1
    load_0_4_3  segment_prefix_ub_819  1
    load_0_4_3  segment_load_conservation_824  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_5  arc_capacity_554  -20
    arc_0_4_5  connected_order_arc_555  -14
    arc_0_4_5  out_degree_820  1
    arc_0_4_5  in_degree_828  1
    arc_0_4_5  original_T_including_depot_unload_886  3.0055050459786975e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_5  arc_capacity_554  1
    load_0_4_5  segment_load_conservation_824  1
    load_0_4_5  segment_load_conservation_831  -1
    load_0_4_5  segment_prefix_lb_832  1
    load_0_4_5  segment_prefix_ub_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_13  arc_capacity_556  -20
    arc_0_4_13  connected_order_arc_557  -14
    arc_0_4_13  out_degree_820  1
    arc_0_4_13  in_degree_835  1
    arc_0_4_13  original_T_including_depot_unload_886  9.6620394708383776e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_13  arc_capacity_556  1
    load_0_4_13  segment_load_conservation_824  1
    load_0_4_13  free_load_conservation_839  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_14  arc_capacity_558  -20
    arc_0_4_14  connected_order_arc_559  -14
    arc_0_4_14  out_degree_820  1
    arc_0_4_14  in_degree_841  1
    arc_0_4_14  original_T_including_depot_unload_886  7.9195606724980928e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_14  arc_capacity_558  1
    load_0_4_14  segment_load_conservation_824  1
    load_0_4_14  free_load_conservation_845  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_15  arc_capacity_560  -20
    arc_0_4_15  connected_order_arc_561  -14
    arc_0_4_15  out_degree_820  1
    arc_0_4_15  in_degree_847  1
    arc_0_4_15  original_T_including_depot_unload_886  1.3163662834239574e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_15  arc_capacity_560  1
    load_0_4_15  segment_load_conservation_824  1
    load_0_4_15  free_load_conservation_851  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_16  arc_capacity_562  -20
    arc_0_4_16  connected_order_arc_563  -14
    arc_0_4_16  out_degree_820  1
    arc_0_4_16  in_degree_853  1
    arc_0_4_16  original_T_including_depot_unload_886  1.0799954902659535e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_16  arc_capacity_562  1
    load_0_4_16  segment_load_conservation_824  1
    load_0_4_16  free_load_conservation_857  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_17  arc_capacity_564  -20
    arc_0_4_17  connected_order_arc_565  -14
    arc_0_4_17  out_degree_820  1
    arc_0_4_17  in_degree_859  1
    arc_0_4_17  original_T_including_depot_unload_886  7.7190219995954919e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_17  arc_capacity_564  1
    load_0_4_17  segment_load_conservation_824  1
    load_0_4_17  free_load_conservation_863  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_18  arc_capacity_566  -20
    arc_0_4_18  connected_order_arc_567  -14
    arc_0_4_18  out_degree_820  1
    arc_0_4_18  in_degree_865  1
    arc_0_4_18  original_T_including_depot_unload_886  8.7876124407720954e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_18  arc_capacity_566  1
    load_0_4_18  segment_load_conservation_824  1
    load_0_4_18  free_load_conservation_869  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_19  arc_capacity_568  -20
    arc_0_4_19  connected_order_arc_569  -14
    arc_0_4_19  out_degree_820  1
    arc_0_4_19  in_degree_871  1
    arc_0_4_19  original_T_including_depot_unload_886  2.3059951477332697e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_19  arc_capacity_568  1
    load_0_4_19  segment_load_conservation_824  1
    load_0_4_19  free_load_conservation_875  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_20  arc_capacity_570  -20
    arc_0_4_20  connected_order_arc_571  -14
    arc_0_4_20  out_degree_820  1
    arc_0_4_20  in_degree_877  1
    arc_0_4_20  original_T_including_depot_unload_886  1.2724370432148053e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_20  arc_capacity_570  1
    load_0_4_20  segment_load_conservation_824  1
    load_0_4_20  free_load_conservation_881  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_0  arc_capacity_572  -20
    arc_0_5_0  depot_return_or_bypass_798  1
    arc_0_5_0  out_degree_827  1
    arc_0_5_0  original_T_including_depot_unload_886  4.6364706268001146e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_0  arc_capacity_572  1
    load_0_5_0  segment_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_1  arc_capacity_573  -20
    arc_0_5_1  connected_order_arc_574  -14
    arc_0_5_1  in_degree_800  1
    arc_0_5_1  out_degree_827  1
    arc_0_5_1  original_T_including_depot_unload_886  9.2985081319651772e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_1  arc_capacity_573  1
    load_0_5_1  segment_load_conservation_803  -1
    load_0_5_1  segment_prefix_lb_804  1
    load_0_5_1  segment_prefix_ub_805  1
    load_0_5_1  segment_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_2  arc_capacity_575  -20
    arc_0_5_2  connected_order_arc_576  -14
    arc_0_5_2  in_degree_807  1
    arc_0_5_2  out_degree_827  1
    arc_0_5_2  original_T_including_depot_unload_886  5.8212369880329140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_2  arc_capacity_575  1
    load_0_5_2  segment_load_conservation_810  -1
    load_0_5_2  segment_prefix_lb_811  1
    load_0_5_2  segment_prefix_ub_812  1
    load_0_5_2  segment_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_3  arc_capacity_577  -20
    arc_0_5_3  connected_order_arc_578  -14
    arc_0_5_3  in_degree_814  1
    arc_0_5_3  out_degree_827  1
    arc_0_5_3  original_T_including_depot_unload_886  8.1289340937717509e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_3  arc_capacity_577  1
    load_0_5_3  segment_load_conservation_817  -1
    load_0_5_3  segment_prefix_lb_818  1
    load_0_5_3  segment_prefix_ub_819  1
    load_0_5_3  segment_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_4  arc_capacity_579  -20
    arc_0_5_4  connected_order_arc_580  -14
    arc_0_5_4  in_degree_821  1
    arc_0_5_4  out_degree_827  1
    arc_0_5_4  original_T_including_depot_unload_886  5.8442598457899078e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_4  arc_capacity_579  1
    load_0_5_4  segment_load_conservation_824  -1
    load_0_5_4  segment_prefix_lb_825  1
    load_0_5_4  segment_prefix_ub_826  1
    load_0_5_4  segment_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_13  arc_capacity_581  -20
    arc_0_5_13  connected_order_arc_582  -14
    arc_0_5_13  out_degree_827  1
    arc_0_5_13  in_degree_835  1
    arc_0_5_13  original_T_including_depot_unload_886  839.148853987777
    MARKER    'MARKER'                 'INTEND'
    load_0_5_13  arc_capacity_581  1
    load_0_5_13  segment_load_conservation_831  1
    load_0_5_13  free_load_conservation_839  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_14  arc_capacity_583  -20
    arc_0_5_14  connected_order_arc_584  -14
    arc_0_5_14  out_degree_827  1
    arc_0_5_14  in_degree_841  1
    arc_0_5_14  original_T_including_depot_unload_886  6.7868877694996661e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_14  arc_capacity_583  1
    load_0_5_14  segment_load_conservation_831  1
    load_0_5_14  free_load_conservation_845  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_15  arc_capacity_585  -20
    arc_0_5_15  connected_order_arc_586  -14
    arc_0_5_15  out_degree_827  1
    arc_0_5_15  in_degree_847  1
    arc_0_5_15  original_T_including_depot_unload_886  1075.72043838369
    MARKER    'MARKER'                 'INTEND'
    load_0_5_15  arc_capacity_585  1
    load_0_5_15  segment_load_conservation_831  1
    load_0_5_15  free_load_conservation_851  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_16  arc_capacity_587  -20
    arc_0_5_16  connected_order_arc_588  -14
    arc_0_5_16  out_degree_827  1
    arc_0_5_16  in_degree_853  1
    arc_0_5_16  original_T_including_depot_unload_886  8.9433085313747858e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_16  arc_capacity_587  1
    load_0_5_16  segment_load_conservation_831  1
    load_0_5_16  free_load_conservation_857  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_17  arc_capacity_589  -20
    arc_0_5_17  connected_order_arc_590  -14
    arc_0_5_17  out_degree_827  1
    arc_0_5_17  in_degree_859  1
    arc_0_5_17  original_T_including_depot_unload_886  9.1576870176747968e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_17  arc_capacity_589  1
    load_0_5_17  segment_load_conservation_831  1
    load_0_5_17  free_load_conservation_863  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_18  arc_capacity_591  -20
    arc_0_5_18  connected_order_arc_592  -14
    arc_0_5_18  out_degree_827  1
    arc_0_5_18  in_degree_865  1
    arc_0_5_18  original_T_including_depot_unload_886  6.7517249538835438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_18  arc_capacity_591  1
    load_0_5_18  segment_load_conservation_831  1
    load_0_5_18  free_load_conservation_869  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_19  arc_capacity_593  -20
    arc_0_5_19  connected_order_arc_594  -14
    arc_0_5_19  out_degree_827  1
    arc_0_5_19  in_degree_871  1
    arc_0_5_19  original_T_including_depot_unload_886  2.6602972191926557e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_19  arc_capacity_593  1
    load_0_5_19  segment_load_conservation_831  1
    load_0_5_19  free_load_conservation_875  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_20  arc_capacity_595  -20
    arc_0_5_20  connected_order_arc_596  -14
    arc_0_5_20  out_degree_827  1
    arc_0_5_20  in_degree_877  1
    arc_0_5_20  original_T_including_depot_unload_886  1.1090437276384578e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_20  arc_capacity_595  1
    load_0_5_20  segment_load_conservation_831  1
    load_0_5_20  free_load_conservation_881  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_0  arc_capacity_597  -20
    arc_0_13_0  depot_return_or_bypass_798  1
    arc_0_13_0  out_degree_834  1
    arc_0_13_0  original_T_including_depot_unload_886  5.4249700630778887e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_0  arc_capacity_597  1
    load_0_13_0  free_load_conservation_839  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_1  arc_capacity_598  -20
    arc_0_13_1  connected_order_arc_599  -14
    arc_0_13_1  in_degree_800  1
    arc_0_13_1  out_degree_834  1
    arc_0_13_1  original_T_including_depot_unload_886  4.4474809771996007e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_1  arc_capacity_598  1
    load_0_13_1  segment_load_conservation_803  -1
    load_0_13_1  segment_prefix_lb_804  1
    load_0_13_1  segment_prefix_ub_805  1
    load_0_13_1  free_load_conservation_839  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_2  arc_capacity_600  -20
    arc_0_13_2  connected_order_arc_601  -14
    arc_0_13_2  in_degree_807  1
    arc_0_13_2  out_degree_834  1
    arc_0_13_2  original_T_including_depot_unload_886  3.3800157717255917e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_2  arc_capacity_600  1
    load_0_13_2  segment_load_conservation_810  -1
    load_0_13_2  segment_prefix_lb_811  1
    load_0_13_2  segment_prefix_ub_812  1
    load_0_13_2  free_load_conservation_839  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_3  arc_capacity_602  -20
    arc_0_13_3  connected_order_arc_603  -14
    arc_0_13_3  in_degree_814  1
    arc_0_13_3  out_degree_834  1
    arc_0_13_3  original_T_including_depot_unload_886  3.4289721135663990e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_3  arc_capacity_602  1
    load_0_13_3  segment_load_conservation_817  -1
    load_0_13_3  segment_prefix_lb_818  1
    load_0_13_3  segment_prefix_ub_819  1
    load_0_13_3  free_load_conservation_839  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_4  arc_capacity_604  -20
    arc_0_13_4  connected_order_arc_605  -14
    arc_0_13_4  in_degree_821  1
    arc_0_13_4  out_degree_834  1
    arc_0_13_4  original_T_including_depot_unload_886  5.5739415765733247e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_4  arc_capacity_604  1
    load_0_13_4  segment_load_conservation_824  -1
    load_0_13_4  segment_prefix_lb_825  1
    load_0_13_4  segment_prefix_ub_826  1
    load_0_13_4  free_load_conservation_839  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_5  arc_capacity_606  -20
    arc_0_13_5  connected_order_arc_607  -14
    arc_0_13_5  in_degree_828  1
    arc_0_13_5  out_degree_834  1
    arc_0_13_5  original_T_including_depot_unload_886  839.148853987777
    MARKER    'MARKER'                 'INTEND'
    load_0_13_5  arc_capacity_606  1
    load_0_13_5  segment_load_conservation_831  -1
    load_0_13_5  segment_prefix_lb_832  1
    load_0_13_5  segment_prefix_ub_833  1
    load_0_13_5  free_load_conservation_839  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_14  arc_capacity_608  -20
    arc_0_13_14  connected_order_arc_609  -14
    arc_0_13_14  out_degree_834  1
    arc_0_13_14  in_degree_841  1
    arc_0_13_14  original_T_including_depot_unload_886  1.7461252424213140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_14  arc_capacity_608  1
    load_0_13_14  free_load_conservation_839  1
    load_0_13_14  free_load_conservation_845  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_15  arc_capacity_610  -20
    arc_0_13_15  connected_order_arc_611  -14
    arc_0_13_15  out_degree_834  1
    arc_0_13_15  in_degree_847  1
    arc_0_13_15  original_T_including_depot_unload_886  1.6231508478292610e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_15  arc_capacity_610  1
    load_0_13_15  free_load_conservation_839  1
    load_0_13_15  free_load_conservation_851  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_16  arc_capacity_612  -20
    arc_0_13_16  connected_order_arc_613  -14
    arc_0_13_16  out_degree_834  1
    arc_0_13_16  in_degree_853  1
    arc_0_13_16  original_T_including_depot_unload_886  2.3159636865750136e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_16  arc_capacity_612  1
    load_0_13_16  free_load_conservation_839  1
    load_0_13_16  free_load_conservation_857  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_17  arc_capacity_614  -20
    arc_0_13_17  connected_order_arc_615  -14
    arc_0_13_17  out_degree_834  1
    arc_0_13_17  in_degree_859  1
    arc_0_13_17  original_T_including_depot_unload_886  1.7249161387293191e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_17  arc_capacity_614  1
    load_0_13_17  free_load_conservation_839  1
    load_0_13_17  free_load_conservation_863  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_18  arc_capacity_616  -20
    arc_0_13_18  connected_order_arc_617  -14
    arc_0_13_18  out_degree_834  1
    arc_0_13_18  in_degree_865  1
    arc_0_13_18  original_T_including_depot_unload_886  2.8529311190414518e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_18  arc_capacity_616  1
    load_0_13_18  free_load_conservation_839  1
    load_0_13_18  free_load_conservation_869  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_19  arc_capacity_618  -20
    arc_0_13_19  connected_order_arc_619  -14
    arc_0_13_19  out_degree_834  1
    arc_0_13_19  in_degree_871  1
    arc_0_13_19  original_T_including_depot_unload_886  1.0838347754693179e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_19  arc_capacity_618  1
    load_0_13_19  free_load_conservation_839  1
    load_0_13_19  free_load_conservation_875  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_20  arc_capacity_620  -20
    arc_0_13_20  connected_order_arc_621  -14
    arc_0_13_20  out_degree_834  1
    arc_0_13_20  in_degree_877  1
    arc_0_13_20  original_T_including_depot_unload_886  3.2367117212973966e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_20  arc_capacity_620  1
    load_0_13_20  free_load_conservation_839  1
    load_0_13_20  free_load_conservation_881  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_0  arc_capacity_622  -20
    arc_0_14_0  depot_return_or_bypass_798  1
    arc_0_14_0  out_degree_840  1
    arc_0_14_0  original_T_including_depot_unload_886  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_0  arc_capacity_622  1
    load_0_14_0  free_load_conservation_845  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_1  arc_capacity_623  -20
    arc_0_14_1  connected_order_arc_624  -14
    arc_0_14_1  in_degree_800  1
    arc_0_14_1  out_degree_840  1
    arc_0_14_1  original_T_including_depot_unload_886  5.2534086948364859e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_1  arc_capacity_623  1
    load_0_14_1  segment_load_conservation_803  -1
    load_0_14_1  segment_prefix_lb_804  1
    load_0_14_1  segment_prefix_ub_805  1
    load_0_14_1  free_load_conservation_845  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_2  arc_capacity_625  -20
    arc_0_14_2  connected_order_arc_626  -14
    arc_0_14_2  in_degree_807  1
    arc_0_14_2  out_degree_840  1
    arc_0_14_2  original_T_including_depot_unload_886  1.7053268374267958e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_2  arc_capacity_625  1
    load_0_14_2  segment_load_conservation_810  -1
    load_0_14_2  segment_prefix_lb_811  1
    load_0_14_2  segment_prefix_ub_812  1
    load_0_14_2  free_load_conservation_845  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_3  arc_capacity_627  -20
    arc_0_14_3  connected_order_arc_628  -14
    arc_0_14_3  in_degree_814  1
    arc_0_14_3  out_degree_840  1
    arc_0_14_3  original_T_including_depot_unload_886  2.7570828838654035e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_3  arc_capacity_627  1
    load_0_14_3  segment_load_conservation_817  -1
    load_0_14_3  segment_prefix_lb_818  1
    load_0_14_3  segment_prefix_ub_819  1
    load_0_14_3  free_load_conservation_845  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_4  arc_capacity_629  -20
    arc_0_14_4  connected_order_arc_630  -14
    arc_0_14_4  in_degree_821  1
    arc_0_14_4  out_degree_840  1
    arc_0_14_4  original_T_including_depot_unload_886  4.0284428834016438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_4  arc_capacity_629  1
    load_0_14_4  segment_load_conservation_824  -1
    load_0_14_4  segment_prefix_lb_825  1
    load_0_14_4  segment_prefix_ub_826  1
    load_0_14_4  free_load_conservation_845  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_5  arc_capacity_631  -20
    arc_0_14_5  connected_order_arc_632  -14
    arc_0_14_5  in_degree_828  1
    arc_0_14_5  out_degree_840  1
    arc_0_14_5  original_T_including_depot_unload_886  6.7868877694996661e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_5  arc_capacity_631  1
    load_0_14_5  segment_load_conservation_831  -1
    load_0_14_5  segment_prefix_lb_832  1
    load_0_14_5  segment_prefix_ub_833  1
    load_0_14_5  free_load_conservation_845  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_13  arc_capacity_633  -20
    arc_0_14_13  connected_order_arc_634  -14
    arc_0_14_13  in_degree_835  1
    arc_0_14_13  out_degree_840  1
    arc_0_14_13  original_T_including_depot_unload_886  1.7461252424213140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_13  arc_capacity_633  1
    load_0_14_13  free_load_conservation_839  -1
    load_0_14_13  free_load_conservation_845  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_15  arc_capacity_635  -20
    arc_0_14_15  connected_order_arc_636  -14
    arc_0_14_15  out_degree_840  1
    arc_0_14_15  in_degree_847  1
    arc_0_14_15  original_T_including_depot_unload_886  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_15  arc_capacity_635  1
    load_0_14_15  free_load_conservation_845  1
    load_0_14_15  free_load_conservation_851  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_16  arc_capacity_637  -20
    arc_0_14_16  connected_order_arc_638  -14
    arc_0_14_16  out_degree_840  1
    arc_0_14_16  in_degree_853  1
    arc_0_14_16  original_T_including_depot_unload_886  3.4754938304534517e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_16  arc_capacity_637  1
    load_0_14_16  free_load_conservation_845  1
    load_0_14_16  free_load_conservation_857  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_17  arc_capacity_639  -20
    arc_0_14_17  connected_order_arc_640  -14
    arc_0_14_17  out_degree_840  1
    arc_0_14_17  in_degree_859  1
    arc_0_14_17  original_T_including_depot_unload_886  1.5530568652263394e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_17  arc_capacity_639  1
    load_0_14_17  free_load_conservation_845  1
    load_0_14_17  free_load_conservation_863  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_18  arc_capacity_641  -20
    arc_0_14_18  connected_order_arc_642  -14
    arc_0_14_18  out_degree_840  1
    arc_0_14_18  in_degree_865  1
    arc_0_14_18  original_T_including_depot_unload_886  2.7078292664437623e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_18  arc_capacity_641  1
    load_0_14_18  free_load_conservation_845  1
    load_0_14_18  free_load_conservation_869  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_19  arc_capacity_643  -20
    arc_0_14_19  connected_order_arc_644  -14
    arc_0_14_19  out_degree_840  1
    arc_0_14_19  in_degree_871  1
    arc_0_14_19  original_T_including_depot_unload_886  9.1580557259044724e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_19  arc_capacity_643  1
    load_0_14_19  free_load_conservation_845  1
    load_0_14_19  free_load_conservation_875  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_20  arc_capacity_645  -20
    arc_0_14_20  connected_order_arc_646  -14
    arc_0_14_20  out_degree_840  1
    arc_0_14_20  in_degree_877  1
    arc_0_14_20  original_T_including_depot_unload_886  4.9242827332511274e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_20  arc_capacity_645  1
    load_0_14_20  free_load_conservation_845  1
    load_0_14_20  free_load_conservation_881  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_0  arc_capacity_647  -20
    arc_0_15_0  depot_return_or_bypass_798  1
    arc_0_15_0  out_degree_846  1
    arc_0_15_0  original_T_including_depot_unload_886  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_0  arc_capacity_647  1
    load_0_15_0  free_load_conservation_851  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_1  arc_capacity_648  -20
    arc_0_15_1  connected_order_arc_649  -14
    arc_0_15_1  in_degree_800  1
    arc_0_15_1  out_degree_846  1
    arc_0_15_1  original_T_including_depot_unload_886  1.3823927712314810e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_1  arc_capacity_648  1
    load_0_15_1  segment_load_conservation_803  -1
    load_0_15_1  segment_prefix_lb_804  1
    load_0_15_1  segment_prefix_ub_805  1
    load_0_15_1  free_load_conservation_851  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_2  arc_capacity_650  -20
    arc_0_15_2  connected_order_arc_651  -14
    arc_0_15_2  in_degree_807  1
    arc_0_15_2  out_degree_846  1
    arc_0_15_2  original_T_including_depot_unload_886  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_2  arc_capacity_650  1
    load_0_15_2  segment_load_conservation_810  -1
    load_0_15_2  segment_prefix_lb_811  1
    load_0_15_2  segment_prefix_ub_812  1
    load_0_15_2  free_load_conservation_851  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_3  arc_capacity_652  -20
    arc_0_15_3  connected_order_arc_653  -14
    arc_0_15_3  in_degree_814  1
    arc_0_15_3  out_degree_846  1
    arc_0_15_3  original_T_including_depot_unload_886  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_3  arc_capacity_652  1
    load_0_15_3  segment_load_conservation_817  -1
    load_0_15_3  segment_prefix_lb_818  1
    load_0_15_3  segment_prefix_ub_819  1
    load_0_15_3  free_load_conservation_851  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_4  arc_capacity_654  -20
    arc_0_15_4  connected_order_arc_655  -14
    arc_0_15_4  in_degree_821  1
    arc_0_15_4  out_degree_846  1
    arc_0_15_4  original_T_including_depot_unload_886  1.6292966848558842e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_4  arc_capacity_654  1
    load_0_15_4  segment_load_conservation_824  -1
    load_0_15_4  segment_prefix_lb_825  1
    load_0_15_4  segment_prefix_ub_826  1
    load_0_15_4  free_load_conservation_851  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_5  arc_capacity_656  -20
    arc_0_15_5  connected_order_arc_657  -14
    arc_0_15_5  in_degree_828  1
    arc_0_15_5  out_degree_846  1
    arc_0_15_5  original_T_including_depot_unload_886  1075.72043838369
    MARKER    'MARKER'                 'INTEND'
    load_0_15_5  arc_capacity_656  1
    load_0_15_5  segment_load_conservation_831  -1
    load_0_15_5  segment_prefix_lb_832  1
    load_0_15_5  segment_prefix_ub_833  1
    load_0_15_5  free_load_conservation_851  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_13  arc_capacity_658  -20
    arc_0_15_13  connected_order_arc_659  -14
    arc_0_15_13  in_degree_835  1
    arc_0_15_13  out_degree_846  1
    arc_0_15_13  original_T_including_depot_unload_886  1.6231508478292610e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_13  arc_capacity_658  1
    load_0_15_13  free_load_conservation_839  -1
    load_0_15_13  free_load_conservation_851  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_14  arc_capacity_660  -20
    arc_0_15_14  connected_order_arc_661  -14
    arc_0_15_14  in_degree_841  1
    arc_0_15_14  out_degree_846  1
    arc_0_15_14  original_T_including_depot_unload_886  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_14  arc_capacity_660  1
    load_0_15_14  free_load_conservation_845  -1
    load_0_15_14  free_load_conservation_851  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_16  arc_capacity_662  -20
    arc_0_15_16  connected_order_arc_663  -14
    arc_0_15_16  out_degree_846  1
    arc_0_15_16  in_degree_853  1
    arc_0_15_16  original_T_including_depot_unload_886  1.5184659007075070e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_16  arc_capacity_662  1
    load_0_15_16  free_load_conservation_851  1
    load_0_15_16  free_load_conservation_857  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_17  arc_capacity_664  -20
    arc_0_15_17  connected_order_arc_665  -14
    arc_0_15_17  out_degree_846  1
    arc_0_15_17  in_degree_859  1
    arc_0_15_17  original_T_including_depot_unload_886  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_17  arc_capacity_664  1
    load_0_15_17  free_load_conservation_851  1
    load_0_15_17  free_load_conservation_863  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_18  arc_capacity_666  -20
    arc_0_15_18  connected_order_arc_667  -14
    arc_0_15_18  out_degree_846  1
    arc_0_15_18  in_degree_865  1
    arc_0_15_18  original_T_including_depot_unload_886  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_18  arc_capacity_666  1
    load_0_15_18  free_load_conservation_851  1
    load_0_15_18  free_load_conservation_869  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_19  arc_capacity_668  -20
    arc_0_15_19  connected_order_arc_669  -14
    arc_0_15_19  out_degree_846  1
    arc_0_15_19  in_degree_871  1
    arc_0_15_19  original_T_including_depot_unload_886  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_19  arc_capacity_668  1
    load_0_15_19  free_load_conservation_851  1
    load_0_15_19  free_load_conservation_875  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_20  arc_capacity_670  -20
    arc_0_15_20  connected_order_arc_671  -14
    arc_0_15_20  out_degree_846  1
    arc_0_15_20  in_degree_877  1
    arc_0_15_20  original_T_including_depot_unload_886  1.7303231472353602e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_20  arc_capacity_670  1
    load_0_15_20  free_load_conservation_851  1
    load_0_15_20  free_load_conservation_881  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_0  arc_capacity_672  -20
    arc_0_16_0  depot_return_or_bypass_798  1
    arc_0_16_0  out_degree_852  1
    arc_0_16_0  original_T_including_depot_unload_886  4.9403722507151832e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_0  arc_capacity_672  1
    load_0_16_0  free_load_conservation_857  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_1  arc_capacity_673  -20
    arc_0_16_1  connected_order_arc_674  -14
    arc_0_16_1  in_degree_800  1
    arc_0_16_1  out_degree_852  1
    arc_0_16_1  original_T_including_depot_unload_886  2.1911621128640562e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_1  arc_capacity_673  1
    load_0_16_1  segment_load_conservation_803  -1
    load_0_16_1  segment_prefix_lb_804  1
    load_0_16_1  segment_prefix_ub_805  1
    load_0_16_1  free_load_conservation_857  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_2  arc_capacity_675  -20
    arc_0_16_2  connected_order_arc_676  -14
    arc_0_16_2  in_degree_807  1
    arc_0_16_2  out_degree_852  1
    arc_0_16_2  original_T_including_depot_unload_886  5.1510428418120409e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_2  arc_capacity_675  1
    load_0_16_2  segment_load_conservation_810  -1
    load_0_16_2  segment_prefix_lb_811  1
    load_0_16_2  segment_prefix_ub_812  1
    load_0_16_2  free_load_conservation_857  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_3  arc_capacity_677  -20
    arc_0_16_3  connected_order_arc_678  -14
    arc_0_16_3  in_degree_814  1
    arc_0_16_3  out_degree_852  1
    arc_0_16_3  original_T_including_depot_unload_886  5.7237486782756332e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_3  arc_capacity_677  1
    load_0_16_3  segment_load_conservation_817  -1
    load_0_16_3  segment_prefix_lb_818  1
    load_0_16_3  segment_prefix_ub_819  1
    load_0_16_3  free_load_conservation_857  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_4  arc_capacity_679  -20
    arc_0_16_4  connected_order_arc_680  -14
    arc_0_16_4  in_degree_821  1
    arc_0_16_4  out_degree_852  1
    arc_0_16_4  original_T_including_depot_unload_886  750.067997850428
    MARKER    'MARKER'                 'INTEND'
    load_0_16_4  arc_capacity_679  1
    load_0_16_4  segment_load_conservation_824  -1
    load_0_16_4  segment_prefix_lb_825  1
    load_0_16_4  segment_prefix_ub_826  1
    load_0_16_4  free_load_conservation_857  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_5  arc_capacity_681  -20
    arc_0_16_5  connected_order_arc_682  -14
    arc_0_16_5  in_degree_828  1
    arc_0_16_5  out_degree_852  1
    arc_0_16_5  original_T_including_depot_unload_886  8.9433085313747858e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_5  arc_capacity_681  1
    load_0_16_5  segment_load_conservation_831  -1
    load_0_16_5  segment_prefix_lb_832  1
    load_0_16_5  segment_prefix_ub_833  1
    load_0_16_5  free_load_conservation_857  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_13  arc_capacity_683  -20
    arc_0_16_13  connected_order_arc_684  -14
    arc_0_16_13  in_degree_835  1
    arc_0_16_13  out_degree_852  1
    arc_0_16_13  original_T_including_depot_unload_886  2.3159636865750136e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_13  arc_capacity_683  1
    load_0_16_13  free_load_conservation_839  -1
    load_0_16_13  free_load_conservation_857  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_14  arc_capacity_685  -20
    arc_0_16_14  connected_order_arc_686  -14
    arc_0_16_14  in_degree_841  1
    arc_0_16_14  out_degree_852  1
    arc_0_16_14  original_T_including_depot_unload_886  3.4754938304534517e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_14  arc_capacity_685  1
    load_0_16_14  free_load_conservation_845  -1
    load_0_16_14  free_load_conservation_857  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_15  arc_capacity_687  -20
    arc_0_16_15  connected_order_arc_688  -14
    arc_0_16_15  in_degree_847  1
    arc_0_16_15  out_degree_852  1
    arc_0_16_15  original_T_including_depot_unload_886  1.5184659007075070e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_15  arc_capacity_687  1
    load_0_16_15  free_load_conservation_851  -1
    load_0_16_15  free_load_conservation_857  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_17  arc_capacity_689  -20
    arc_0_16_17  connected_order_arc_690  -14
    arc_0_16_17  out_degree_852  1
    arc_0_16_17  in_degree_859  1
    arc_0_16_17  original_T_including_depot_unload_886  1.8073464544423741e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_17  arc_capacity_689  1
    load_0_16_17  free_load_conservation_857  1
    load_0_16_17  free_load_conservation_863  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_18  arc_capacity_691  -20
    arc_0_16_18  connected_order_arc_692  -14
    arc_0_16_18  out_degree_852  1
    arc_0_16_18  in_degree_865  1
    arc_0_16_18  original_T_including_depot_unload_886  2.2271784981792140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_18  arc_capacity_691  1
    load_0_16_18  free_load_conservation_857  1
    load_0_16_18  free_load_conservation_869  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_19  arc_capacity_693  -20
    arc_0_16_19  connected_order_arc_694  -14
    arc_0_16_19  out_degree_852  1
    arc_0_16_19  in_degree_871  1
    arc_0_16_19  original_T_including_depot_unload_886  1.1562172312295786e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_19  arc_capacity_693  1
    load_0_16_19  free_load_conservation_857  1
    load_0_16_19  free_load_conservation_875  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_20  arc_capacity_695  -20
    arc_0_16_20  connected_order_arc_696  -14
    arc_0_16_20  out_degree_852  1
    arc_0_16_20  in_degree_877  1
    arc_0_16_20  original_T_including_depot_unload_886  2.2729932910497158e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_20  arc_capacity_695  1
    load_0_16_20  free_load_conservation_857  1
    load_0_16_20  free_load_conservation_881  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_0  arc_capacity_697  -20
    arc_0_17_0  depot_return_or_bypass_798  1
    arc_0_17_0  out_degree_858  1
    arc_0_17_0  original_T_including_depot_unload_886  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_0  arc_capacity_697  1
    load_0_17_0  free_load_conservation_863  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_1  arc_capacity_698  -20
    arc_0_17_1  connected_order_arc_699  -14
    arc_0_17_1  in_degree_800  1
    arc_0_17_1  out_degree_858  1
    arc_0_17_1  original_T_including_depot_unload_886  1.8418804985785646e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_1  arc_capacity_698  1
    load_0_17_1  segment_load_conservation_803  -1
    load_0_17_1  segment_prefix_lb_804  1
    load_0_17_1  segment_prefix_ub_805  1
    load_0_17_1  free_load_conservation_863  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_2  arc_capacity_700  -20
    arc_0_17_2  connected_order_arc_701  -14
    arc_0_17_2  in_degree_807  1
    arc_0_17_2  out_degree_858  1
    arc_0_17_2  original_T_including_depot_unload_886  1.4150780419437449e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_2  arc_capacity_700  1
    load_0_17_2  segment_load_conservation_810  -1
    load_0_17_2  segment_prefix_lb_811  1
    load_0_17_2  segment_prefix_ub_812  1
    load_0_17_2  free_load_conservation_863  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_3  arc_capacity_702  -20
    arc_0_17_3  connected_order_arc_703  -14
    arc_0_17_3  in_degree_814  1
    arc_0_17_3  out_degree_858  1
    arc_0_17_3  original_T_including_depot_unload_886  1.5968108380866881e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_3  arc_capacity_702  1
    load_0_17_3  segment_load_conservation_817  -1
    load_0_17_3  segment_prefix_lb_818  1
    load_0_17_3  segment_prefix_ub_819  1
    load_0_17_3  free_load_conservation_863  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_4  arc_capacity_704  -20
    arc_0_17_4  connected_order_arc_705  -14
    arc_0_17_4  in_degree_821  1
    arc_0_17_4  out_degree_858  1
    arc_0_17_4  original_T_including_depot_unload_886  1.2927075446362680e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_4  arc_capacity_704  1
    load_0_17_4  segment_load_conservation_824  -1
    load_0_17_4  segment_prefix_lb_825  1
    load_0_17_4  segment_prefix_ub_826  1
    load_0_17_4  free_load_conservation_863  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_5  arc_capacity_706  -20
    arc_0_17_5  connected_order_arc_707  -14
    arc_0_17_5  in_degree_828  1
    arc_0_17_5  out_degree_858  1
    arc_0_17_5  original_T_including_depot_unload_886  9.1576870176747968e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_5  arc_capacity_706  1
    load_0_17_5  segment_load_conservation_831  -1
    load_0_17_5  segment_prefix_lb_832  1
    load_0_17_5  segment_prefix_ub_833  1
    load_0_17_5  free_load_conservation_863  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_13  arc_capacity_708  -20
    arc_0_17_13  connected_order_arc_709  -14
    arc_0_17_13  in_degree_835  1
    arc_0_17_13  out_degree_858  1
    arc_0_17_13  original_T_including_depot_unload_886  1.7249161387293191e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_13  arc_capacity_708  1
    load_0_17_13  free_load_conservation_839  -1
    load_0_17_13  free_load_conservation_863  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_14  arc_capacity_710  -20
    arc_0_17_14  connected_order_arc_711  -14
    arc_0_17_14  in_degree_841  1
    arc_0_17_14  out_degree_858  1
    arc_0_17_14  original_T_including_depot_unload_886  1.5530568652263394e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_14  arc_capacity_710  1
    load_0_17_14  free_load_conservation_845  -1
    load_0_17_14  free_load_conservation_863  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_15  arc_capacity_712  -20
    arc_0_17_15  connected_order_arc_713  -14
    arc_0_17_15  in_degree_847  1
    arc_0_17_15  out_degree_858  1
    arc_0_17_15  original_T_including_depot_unload_886  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_15  arc_capacity_712  1
    load_0_17_15  free_load_conservation_851  -1
    load_0_17_15  free_load_conservation_863  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_16  arc_capacity_714  -20
    arc_0_17_16  connected_order_arc_715  -14
    arc_0_17_16  in_degree_853  1
    arc_0_17_16  out_degree_858  1
    arc_0_17_16  original_T_including_depot_unload_886  1.8073464544423741e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_16  arc_capacity_714  1
    load_0_17_16  free_load_conservation_857  -1
    load_0_17_16  free_load_conservation_863  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_18  arc_capacity_716  -20
    arc_0_17_18  connected_order_arc_717  -14
    arc_0_17_18  out_degree_858  1
    arc_0_17_18  in_degree_865  1
    arc_0_17_18  original_T_including_depot_unload_886  1.5902582434549993e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_18  arc_capacity_716  1
    load_0_17_18  free_load_conservation_863  1
    load_0_17_18  free_load_conservation_869  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_19  arc_capacity_718  -20
    arc_0_17_19  connected_order_arc_719  -14
    arc_0_17_19  out_degree_858  1
    arc_0_17_19  in_degree_871  1
    arc_0_17_19  original_T_including_depot_unload_886  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_19  arc_capacity_718  1
    load_0_17_19  free_load_conservation_863  1
    load_0_17_19  free_load_conservation_875  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_20  arc_capacity_720  -20
    arc_0_17_20  connected_order_arc_721  -14
    arc_0_17_20  out_degree_858  1
    arc_0_17_20  in_degree_877  1
    arc_0_17_20  original_T_including_depot_unload_886  2.0162129512771592e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_20  arc_capacity_720  1
    load_0_17_20  free_load_conservation_863  1
    load_0_17_20  free_load_conservation_881  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_0  arc_capacity_722  -20
    arc_0_18_0  depot_return_or_bypass_798  1
    arc_0_18_0  out_degree_864  1
    arc_0_18_0  original_T_including_depot_unload_886  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_0  arc_capacity_722  1
    load_0_18_0  free_load_conservation_869  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_1  arc_capacity_723  -20
    arc_0_18_1  connected_order_arc_724  -14
    arc_0_18_1  in_degree_800  1
    arc_0_18_1  out_degree_864  1
    arc_0_18_1  original_T_including_depot_unload_886  2.9438424317501273e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_1  arc_capacity_723  1
    load_0_18_1  segment_load_conservation_803  -1
    load_0_18_1  segment_prefix_lb_804  1
    load_0_18_1  segment_prefix_ub_805  1
    load_0_18_1  free_load_conservation_869  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_2  arc_capacity_725  -20
    arc_0_18_2  connected_order_arc_726  -14
    arc_0_18_2  in_degree_807  1
    arc_0_18_2  out_degree_864  1
    arc_0_18_2  original_T_including_depot_unload_886  3.9758967496529505e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_2  arc_capacity_725  1
    load_0_18_2  segment_load_conservation_810  -1
    load_0_18_2  segment_prefix_lb_811  1
    load_0_18_2  segment_prefix_ub_812  1
    load_0_18_2  free_load_conservation_869  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_3  arc_capacity_727  -20
    arc_0_18_3  connected_order_arc_728  -14
    arc_0_18_3  in_degree_814  1
    arc_0_18_3  out_degree_864  1
    arc_0_18_3  original_T_including_depot_unload_886  545.439458844012
    MARKER    'MARKER'                 'INTEND'
    load_0_18_3  arc_capacity_727  1
    load_0_18_3  segment_load_conservation_817  -1
    load_0_18_3  segment_prefix_lb_818  1
    load_0_18_3  segment_prefix_ub_819  1
    load_0_18_3  free_load_conservation_869  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_4  arc_capacity_729  -20
    arc_0_18_4  connected_order_arc_730  -14
    arc_0_18_4  in_degree_821  1
    arc_0_18_4  out_degree_864  1
    arc_0_18_4  original_T_including_depot_unload_886  628.141943094385
    MARKER    'MARKER'                 'INTEND'
    load_0_18_4  arc_capacity_729  1
    load_0_18_4  segment_load_conservation_824  -1
    load_0_18_4  segment_prefix_lb_825  1
    load_0_18_4  segment_prefix_ub_826  1
    load_0_18_4  free_load_conservation_869  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_5  arc_capacity_731  -20
    arc_0_18_5  connected_order_arc_732  -14
    arc_0_18_5  in_degree_828  1
    arc_0_18_5  out_degree_864  1
    arc_0_18_5  original_T_including_depot_unload_886  6.7517249538835438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_5  arc_capacity_731  1
    load_0_18_5  segment_load_conservation_831  -1
    load_0_18_5  segment_prefix_lb_832  1
    load_0_18_5  segment_prefix_ub_833  1
    load_0_18_5  free_load_conservation_869  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_13  arc_capacity_733  -20
    arc_0_18_13  connected_order_arc_734  -14
    arc_0_18_13  in_degree_835  1
    arc_0_18_13  out_degree_864  1
    arc_0_18_13  original_T_including_depot_unload_886  2.8529311190414518e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_13  arc_capacity_733  1
    load_0_18_13  free_load_conservation_839  -1
    load_0_18_13  free_load_conservation_869  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_14  arc_capacity_735  -20
    arc_0_18_14  connected_order_arc_736  -14
    arc_0_18_14  in_degree_841  1
    arc_0_18_14  out_degree_864  1
    arc_0_18_14  original_T_including_depot_unload_886  2.7078292664437623e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_14  arc_capacity_735  1
    load_0_18_14  free_load_conservation_845  -1
    load_0_18_14  free_load_conservation_869  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_15  arc_capacity_737  -20
    arc_0_18_15  connected_order_arc_738  -14
    arc_0_18_15  in_degree_847  1
    arc_0_18_15  out_degree_864  1
    arc_0_18_15  original_T_including_depot_unload_886  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_15  arc_capacity_737  1
    load_0_18_15  free_load_conservation_851  -1
    load_0_18_15  free_load_conservation_869  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_16  arc_capacity_739  -20
    arc_0_18_16  connected_order_arc_740  -14
    arc_0_18_16  in_degree_853  1
    arc_0_18_16  out_degree_864  1
    arc_0_18_16  original_T_including_depot_unload_886  2.2271784981792140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_16  arc_capacity_739  1
    load_0_18_16  free_load_conservation_857  -1
    load_0_18_16  free_load_conservation_869  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_17  arc_capacity_741  -20
    arc_0_18_17  connected_order_arc_742  -14
    arc_0_18_17  in_degree_859  1
    arc_0_18_17  out_degree_864  1
    arc_0_18_17  original_T_including_depot_unload_886  1.5902582434549993e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_17  arc_capacity_741  1
    load_0_18_17  free_load_conservation_863  -1
    load_0_18_17  free_load_conservation_869  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_19  arc_capacity_743  -20
    arc_0_18_19  connected_order_arc_744  -14
    arc_0_18_19  out_degree_864  1
    arc_0_18_19  in_degree_871  1
    arc_0_18_19  original_T_including_depot_unload_886  9.3905252655669165e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_19  arc_capacity_743  1
    load_0_18_19  free_load_conservation_869  1
    load_0_18_19  free_load_conservation_875  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_20  arc_capacity_745  -20
    arc_0_18_20  connected_order_arc_746  -14
    arc_0_18_20  out_degree_864  1
    arc_0_18_20  in_degree_877  1
    arc_0_18_20  original_T_including_depot_unload_886  4.4733407106545638e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_20  arc_capacity_745  1
    load_0_18_20  free_load_conservation_869  1
    load_0_18_20  free_load_conservation_881  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_0  arc_capacity_747  -20
    arc_0_19_0  depot_return_or_bypass_798  1
    arc_0_19_0  out_degree_870  1
    arc_0_19_0  original_T_including_depot_unload_886  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_0  arc_capacity_747  1
    load_0_19_0  free_load_conservation_875  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_1  arc_capacity_748  -20
    arc_0_19_1  connected_order_arc_749  -14
    arc_0_19_1  in_degree_800  1
    arc_0_19_1  out_degree_870  1
    arc_0_19_1  original_T_including_depot_unload_886  1.1957430085580884e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_1  arc_capacity_748  1
    load_0_19_1  segment_load_conservation_803  -1
    load_0_19_1  segment_prefix_lb_804  1
    load_0_19_1  segment_prefix_ub_805  1
    load_0_19_1  free_load_conservation_875  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_2  arc_capacity_750  -20
    arc_0_19_2  connected_order_arc_751  -14
    arc_0_19_2  in_degree_807  1
    arc_0_19_2  out_degree_870  1
    arc_0_19_2  original_T_including_depot_unload_886  7.9403551275216375e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_2  arc_capacity_750  1
    load_0_19_2  segment_load_conservation_810  -1
    load_0_19_2  segment_prefix_lb_811  1
    load_0_19_2  segment_prefix_ub_812  1
    load_0_19_2  free_load_conservation_875  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_3  arc_capacity_752  -20
    arc_0_19_3  connected_order_arc_753  -14
    arc_0_19_3  in_degree_814  1
    arc_0_19_3  out_degree_870  1
    arc_0_19_3  original_T_including_depot_unload_886  1.0038065985492663e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_3  arc_capacity_752  1
    load_0_19_3  segment_load_conservation_817  -1
    load_0_19_3  segment_prefix_lb_818  1
    load_0_19_3  segment_prefix_ub_819  1
    load_0_19_3  free_load_conservation_875  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_4  arc_capacity_754  -20
    arc_0_19_4  connected_order_arc_755  -14
    arc_0_19_4  in_degree_821  1
    arc_0_19_4  out_degree_870  1
    arc_0_19_4  original_T_including_depot_unload_886  7.2751050611121218e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_4  arc_capacity_754  1
    load_0_19_4  segment_load_conservation_824  -1
    load_0_19_4  segment_prefix_lb_825  1
    load_0_19_4  segment_prefix_ub_826  1
    load_0_19_4  free_load_conservation_875  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_5  arc_capacity_756  -20
    arc_0_19_5  connected_order_arc_757  -14
    arc_0_19_5  in_degree_828  1
    arc_0_19_5  out_degree_870  1
    arc_0_19_5  original_T_including_depot_unload_886  2.6602972191926557e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_5  arc_capacity_756  1
    load_0_19_5  segment_load_conservation_831  -1
    load_0_19_5  segment_prefix_lb_832  1
    load_0_19_5  segment_prefix_ub_833  1
    load_0_19_5  free_load_conservation_875  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_13  arc_capacity_758  -20
    arc_0_19_13  connected_order_arc_759  -14
    arc_0_19_13  in_degree_835  1
    arc_0_19_13  out_degree_870  1
    arc_0_19_13  original_T_including_depot_unload_886  1.0838347754693179e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_13  arc_capacity_758  1
    load_0_19_13  free_load_conservation_839  -1
    load_0_19_13  free_load_conservation_875  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_14  arc_capacity_760  -20
    arc_0_19_14  connected_order_arc_761  -14
    arc_0_19_14  in_degree_841  1
    arc_0_19_14  out_degree_870  1
    arc_0_19_14  original_T_including_depot_unload_886  9.1580557259044724e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_14  arc_capacity_760  1
    load_0_19_14  free_load_conservation_845  -1
    load_0_19_14  free_load_conservation_875  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_15  arc_capacity_762  -20
    arc_0_19_15  connected_order_arc_763  -14
    arc_0_19_15  in_degree_847  1
    arc_0_19_15  out_degree_870  1
    arc_0_19_15  original_T_including_depot_unload_886  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_15  arc_capacity_762  1
    load_0_19_15  free_load_conservation_851  -1
    load_0_19_15  free_load_conservation_875  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_16  arc_capacity_764  -20
    arc_0_19_16  connected_order_arc_765  -14
    arc_0_19_16  in_degree_853  1
    arc_0_19_16  out_degree_870  1
    arc_0_19_16  original_T_including_depot_unload_886  1.1562172312295786e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_16  arc_capacity_764  1
    load_0_19_16  free_load_conservation_857  -1
    load_0_19_16  free_load_conservation_875  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_17  arc_capacity_766  -20
    arc_0_19_17  connected_order_arc_767  -14
    arc_0_19_17  in_degree_859  1
    arc_0_19_17  out_degree_870  1
    arc_0_19_17  original_T_including_depot_unload_886  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_17  arc_capacity_766  1
    load_0_19_17  free_load_conservation_863  -1
    load_0_19_17  free_load_conservation_875  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_18  arc_capacity_768  -20
    arc_0_19_18  connected_order_arc_769  -14
    arc_0_19_18  in_degree_865  1
    arc_0_19_18  out_degree_870  1
    arc_0_19_18  original_T_including_depot_unload_886  9.3905252655669165e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_18  arc_capacity_768  1
    load_0_19_18  free_load_conservation_869  -1
    load_0_19_18  free_load_conservation_875  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_20  arc_capacity_770  -20
    arc_0_19_20  connected_order_arc_771  -14
    arc_0_19_20  out_degree_870  1
    arc_0_19_20  in_degree_877  1
    arc_0_19_20  original_T_including_depot_unload_886  1.3669225770244122e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_20  arc_capacity_770  1
    load_0_19_20  free_load_conservation_875  1
    load_0_19_20  free_load_conservation_881  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_0  arc_capacity_772  -20
    arc_0_20_0  depot_return_or_bypass_798  1
    arc_0_20_0  out_degree_876  1
    arc_0_20_0  original_T_including_depot_unload_886  7.2130540230577469e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_0  arc_capacity_772  1
    load_0_20_0  free_load_conservation_881  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_1  arc_capacity_773  -20
    arc_0_20_1  connected_order_arc_774  -14
    arc_0_20_1  in_degree_800  1
    arc_0_20_1  out_degree_876  1
    arc_0_20_1  original_T_including_depot_unload_886  3.6338251321041224e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_1  arc_capacity_773  1
    load_0_20_1  segment_load_conservation_803  -1
    load_0_20_1  segment_prefix_lb_804  1
    load_0_20_1  segment_prefix_ub_805  1
    load_0_20_1  free_load_conservation_881  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_2  arc_capacity_775  -20
    arc_0_20_2  connected_order_arc_776  -14
    arc_0_20_2  in_degree_807  1
    arc_0_20_2  out_degree_876  1
    arc_0_20_2  original_T_including_depot_unload_886  6.6047504008669523e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_2  arc_capacity_775  1
    load_0_20_2  segment_load_conservation_810  -1
    load_0_20_2  segment_prefix_lb_811  1
    load_0_20_2  segment_prefix_ub_812  1
    load_0_20_2  free_load_conservation_881  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_3  arc_capacity_777  -20
    arc_0_20_3  connected_order_arc_778  -14
    arc_0_20_3  in_degree_814  1
    arc_0_20_3  out_degree_876  1
    arc_0_20_3  original_T_including_depot_unload_886  6.3648699141452130e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_3  arc_capacity_777  1
    load_0_20_3  segment_load_conservation_817  -1
    load_0_20_3  segment_prefix_lb_818  1
    load_0_20_3  segment_prefix_ub_819  1
    load_0_20_3  free_load_conservation_881  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_4  arc_capacity_779  -20
    arc_0_20_4  connected_order_arc_780  -14
    arc_0_20_4  in_degree_821  1
    arc_0_20_4  out_degree_876  1
    arc_0_20_4  original_T_including_depot_unload_886  880.352897387315
    MARKER    'MARKER'                 'INTEND'
    load_0_20_4  arc_capacity_779  1
    load_0_20_4  segment_load_conservation_824  -1
    load_0_20_4  segment_prefix_lb_825  1
    load_0_20_4  segment_prefix_ub_826  1
    load_0_20_4  free_load_conservation_881  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_5  arc_capacity_781  -20
    arc_0_20_5  connected_order_arc_782  -14
    arc_0_20_5  in_degree_828  1
    arc_0_20_5  out_degree_876  1
    arc_0_20_5  original_T_including_depot_unload_886  1.1090437276384578e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_5  arc_capacity_781  1
    load_0_20_5  segment_load_conservation_831  -1
    load_0_20_5  segment_prefix_lb_832  1
    load_0_20_5  segment_prefix_ub_833  1
    load_0_20_5  free_load_conservation_881  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_13  arc_capacity_783  -20
    arc_0_20_13  connected_order_arc_784  -14
    arc_0_20_13  in_degree_835  1
    arc_0_20_13  out_degree_876  1
    arc_0_20_13  original_T_including_depot_unload_886  3.2367117212973966e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_13  arc_capacity_783  1
    load_0_20_13  free_load_conservation_839  -1
    load_0_20_13  free_load_conservation_881  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_14  arc_capacity_785  -20
    arc_0_20_14  connected_order_arc_786  -14
    arc_0_20_14  in_degree_841  1
    arc_0_20_14  out_degree_876  1
    arc_0_20_14  original_T_including_depot_unload_886  4.9242827332511274e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_14  arc_capacity_785  1
    load_0_20_14  free_load_conservation_845  -1
    load_0_20_14  free_load_conservation_881  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_15  arc_capacity_787  -20
    arc_0_20_15  connected_order_arc_788  -14
    arc_0_20_15  in_degree_847  1
    arc_0_20_15  out_degree_876  1
    arc_0_20_15  original_T_including_depot_unload_886  1.7303231472353602e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_15  arc_capacity_787  1
    load_0_20_15  free_load_conservation_851  -1
    load_0_20_15  free_load_conservation_881  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_16  arc_capacity_789  -20
    arc_0_20_16  connected_order_arc_790  -14
    arc_0_20_16  in_degree_853  1
    arc_0_20_16  out_degree_876  1
    arc_0_20_16  original_T_including_depot_unload_886  2.2729932910497158e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_16  arc_capacity_789  1
    load_0_20_16  free_load_conservation_857  -1
    load_0_20_16  free_load_conservation_881  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_17  arc_capacity_791  -20
    arc_0_20_17  connected_order_arc_792  -14
    arc_0_20_17  in_degree_859  1
    arc_0_20_17  out_degree_876  1
    arc_0_20_17  original_T_including_depot_unload_886  2.0162129512771592e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_17  arc_capacity_791  1
    load_0_20_17  free_load_conservation_863  -1
    load_0_20_17  free_load_conservation_881  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_18  arc_capacity_793  -20
    arc_0_20_18  connected_order_arc_794  -14
    arc_0_20_18  in_degree_865  1
    arc_0_20_18  out_degree_876  1
    arc_0_20_18  original_T_including_depot_unload_886  4.4733407106545638e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_18  arc_capacity_793  1
    load_0_20_18  free_load_conservation_869  -1
    load_0_20_18  free_load_conservation_881  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_19  arc_capacity_795  -20
    arc_0_20_19  connected_order_arc_796  -14
    arc_0_20_19  in_degree_871  1
    arc_0_20_19  out_degree_876  1
    arc_0_20_19  original_T_including_depot_unload_886  1.3669225770244122e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_19  arc_capacity_795  1
    load_0_20_19  free_load_conservation_875  -1
    load_0_20_19  free_load_conservation_881  1
    visit_1_6  out_degree_1178  -1
    visit_1_6  in_degree_1179  -1
    visit_1_6  order_active_lb_1180  -1
    visit_1_6  order_active_ub_1181  -12
    order_1_6  connected_order_arc_902  -1
    order_1_6  connected_order_arc_904  -1
    order_1_6  connected_order_arc_906  -1
    order_1_6  connected_order_arc_908  -1
    order_1_6  connected_order_arc_910  -1
    order_1_6  connected_order_arc_912  -1
    order_1_6  connected_order_arc_914  -1
    order_1_6  connected_order_arc_916  -1
    order_1_6  connected_order_arc_918  -1
    order_1_6  connected_order_arc_920  -1
    order_1_6  connected_order_arc_922  -1
    order_1_6  connected_order_arc_925  1
    order_1_6  connected_order_arc_948  1
    order_1_6  connected_order_arc_971  1
    order_1_6  connected_order_arc_994  1
    order_1_6  connected_order_arc_1017  1
    order_1_6  connected_order_arc_1040  1
    order_1_6  connected_order_arc_1063  1
    order_1_6  connected_order_arc_1086  1
    order_1_6  connected_order_arc_1109  1
    order_1_6  connected_order_arc_1132  1
    order_1_6  connected_order_arc_1155  1
    order_1_6  order_active_lb_1180  1
    order_1_6  order_active_ub_1181  1
    order_1_6  fixed_segment_relative_order_1254  -1
    visit_1_7  out_degree_1185  -1
    visit_1_7  in_degree_1186  -1
    visit_1_7  order_active_lb_1187  -1
    visit_1_7  order_active_ub_1188  -12
    order_1_7  connected_order_arc_902  1
    order_1_7  connected_order_arc_925  -1
    order_1_7  connected_order_arc_927  -1
    order_1_7  connected_order_arc_929  -1
    order_1_7  connected_order_arc_931  -1
    order_1_7  connected_order_arc_933  -1
    order_1_7  connected_order_arc_935  -1
    order_1_7  connected_order_arc_937  -1
    order_1_7  connected_order_arc_939  -1
    order_1_7  connected_order_arc_941  -1
    order_1_7  connected_order_arc_943  -1
    order_1_7  connected_order_arc_945  -1
    order_1_7  connected_order_arc_950  1
    order_1_7  connected_order_arc_973  1
    order_1_7  connected_order_arc_996  1
    order_1_7  connected_order_arc_1019  1
    order_1_7  connected_order_arc_1042  1
    order_1_7  connected_order_arc_1065  1
    order_1_7  connected_order_arc_1088  1
    order_1_7  connected_order_arc_1111  1
    order_1_7  connected_order_arc_1134  1
    order_1_7  connected_order_arc_1157  1
    order_1_7  order_active_lb_1187  1
    order_1_7  order_active_ub_1188  1
    order_1_7  fixed_segment_relative_order_1254  1
    order_1_7  fixed_segment_relative_order_1255  -1
    visit_1_8  out_degree_1192  -1
    visit_1_8  in_degree_1193  -1
    visit_1_8  order_active_lb_1194  -1
    visit_1_8  order_active_ub_1195  -12
    order_1_8  connected_order_arc_904  1
    order_1_8  connected_order_arc_927  1
    order_1_8  connected_order_arc_948  -1
    order_1_8  connected_order_arc_950  -1
    order_1_8  connected_order_arc_952  -1
    order_1_8  connected_order_arc_954  -1
    order_1_8  connected_order_arc_956  -1
    order_1_8  connected_order_arc_958  -1
    order_1_8  connected_order_arc_960  -1
    order_1_8  connected_order_arc_962  -1
    order_1_8  connected_order_arc_964  -1
    order_1_8  connected_order_arc_966  -1
    order_1_8  connected_order_arc_968  -1
    order_1_8  connected_order_arc_975  1
    order_1_8  connected_order_arc_998  1
    order_1_8  connected_order_arc_1021  1
    order_1_8  connected_order_arc_1044  1
    order_1_8  connected_order_arc_1067  1
    order_1_8  connected_order_arc_1090  1
    order_1_8  connected_order_arc_1113  1
    order_1_8  connected_order_arc_1136  1
    order_1_8  connected_order_arc_1159  1
    order_1_8  order_active_lb_1194  1
    order_1_8  order_active_ub_1195  1
    order_1_8  fixed_segment_relative_order_1255  1
    order_1_8  fixed_segment_relative_order_1256  -1
    visit_1_9  out_degree_1199  -1
    visit_1_9  in_degree_1200  -1
    visit_1_9  order_active_lb_1201  -1
    visit_1_9  order_active_ub_1202  -12
    order_1_9  connected_order_arc_906  1
    order_1_9  connected_order_arc_929  1
    order_1_9  connected_order_arc_952  1
    order_1_9  connected_order_arc_971  -1
    order_1_9  connected_order_arc_973  -1
    order_1_9  connected_order_arc_975  -1
    order_1_9  connected_order_arc_977  -1
    order_1_9  connected_order_arc_979  -1
    order_1_9  connected_order_arc_981  -1
    order_1_9  connected_order_arc_983  -1
    order_1_9  connected_order_arc_985  -1
    order_1_9  connected_order_arc_987  -1
    order_1_9  connected_order_arc_989  -1
    order_1_9  connected_order_arc_991  -1
    order_1_9  connected_order_arc_1000  1
    order_1_9  connected_order_arc_1023  1
    order_1_9  connected_order_arc_1046  1
    order_1_9  connected_order_arc_1069  1
    order_1_9  connected_order_arc_1092  1
    order_1_9  connected_order_arc_1115  1
    order_1_9  connected_order_arc_1138  1
    order_1_9  connected_order_arc_1161  1
    order_1_9  order_active_lb_1201  1
    order_1_9  order_active_ub_1202  1
    order_1_9  fixed_segment_relative_order_1256  1
    visit_1_13  out_degree_1206  -1
    visit_1_13  in_degree_1207  -1
    visit_1_13  order_active_lb_1208  -1
    visit_1_13  order_active_ub_1209  -12
    visit_1_13  service_visit_def_1210  -1
    order_1_13  connected_order_arc_908  1
    order_1_13  connected_order_arc_931  1
    order_1_13  connected_order_arc_954  1
    order_1_13  connected_order_arc_977  1
    order_1_13  connected_order_arc_994  -1
    order_1_13  connected_order_arc_996  -1
    order_1_13  connected_order_arc_998  -1
    order_1_13  connected_order_arc_1000  -1
    order_1_13  connected_order_arc_1002  -1
    order_1_13  connected_order_arc_1004  -1
    order_1_13  connected_order_arc_1006  -1
    order_1_13  connected_order_arc_1008  -1
    order_1_13  connected_order_arc_1010  -1
    order_1_13  connected_order_arc_1012  -1
    order_1_13  connected_order_arc_1014  -1
    order_1_13  connected_order_arc_1025  1
    order_1_13  connected_order_arc_1048  1
    order_1_13  connected_order_arc_1071  1
    order_1_13  connected_order_arc_1094  1
    order_1_13  connected_order_arc_1117  1
    order_1_13  connected_order_arc_1140  1
    order_1_13  connected_order_arc_1163  1
    order_1_13  order_active_lb_1208  1
    order_1_13  order_active_ub_1209  1
    visit_1_14  out_degree_1212  -1
    visit_1_14  in_degree_1213  -1
    visit_1_14  order_active_lb_1214  -1
    visit_1_14  order_active_ub_1215  -12
    visit_1_14  service_visit_def_1216  -1
    order_1_14  connected_order_arc_910  1
    order_1_14  connected_order_arc_933  1
    order_1_14  connected_order_arc_956  1
    order_1_14  connected_order_arc_979  1
    order_1_14  connected_order_arc_1002  1
    order_1_14  connected_order_arc_1017  -1
    order_1_14  connected_order_arc_1019  -1
    order_1_14  connected_order_arc_1021  -1
    order_1_14  connected_order_arc_1023  -1
    order_1_14  connected_order_arc_1025  -1
    order_1_14  connected_order_arc_1027  -1
    order_1_14  connected_order_arc_1029  -1
    order_1_14  connected_order_arc_1031  -1
    order_1_14  connected_order_arc_1033  -1
    order_1_14  connected_order_arc_1035  -1
    order_1_14  connected_order_arc_1037  -1
    order_1_14  connected_order_arc_1050  1
    order_1_14  connected_order_arc_1073  1
    order_1_14  connected_order_arc_1096  1
    order_1_14  connected_order_arc_1119  1
    order_1_14  connected_order_arc_1142  1
    order_1_14  connected_order_arc_1165  1
    order_1_14  order_active_lb_1214  1
    order_1_14  order_active_ub_1215  1
    visit_1_15  out_degree_1218  -1
    visit_1_15  in_degree_1219  -1
    visit_1_15  order_active_lb_1220  -1
    visit_1_15  order_active_ub_1221  -12
    visit_1_15  service_visit_def_1222  -1
    order_1_15  connected_order_arc_912  1
    order_1_15  connected_order_arc_935  1
    order_1_15  connected_order_arc_958  1
    order_1_15  connected_order_arc_981  1
    order_1_15  connected_order_arc_1004  1
    order_1_15  connected_order_arc_1027  1
    order_1_15  connected_order_arc_1040  -1
    order_1_15  connected_order_arc_1042  -1
    order_1_15  connected_order_arc_1044  -1
    order_1_15  connected_order_arc_1046  -1
    order_1_15  connected_order_arc_1048  -1
    order_1_15  connected_order_arc_1050  -1
    order_1_15  connected_order_arc_1052  -1
    order_1_15  connected_order_arc_1054  -1
    order_1_15  connected_order_arc_1056  -1
    order_1_15  connected_order_arc_1058  -1
    order_1_15  connected_order_arc_1060  -1
    order_1_15  connected_order_arc_1075  1
    order_1_15  connected_order_arc_1098  1
    order_1_15  connected_order_arc_1121  1
    order_1_15  connected_order_arc_1144  1
    order_1_15  connected_order_arc_1167  1
    order_1_15  order_active_lb_1220  1
    order_1_15  order_active_ub_1221  1
    visit_1_16  out_degree_1224  -1
    visit_1_16  in_degree_1225  -1
    visit_1_16  order_active_lb_1226  -1
    visit_1_16  order_active_ub_1227  -12
    visit_1_16  service_visit_def_1228  -1
    order_1_16  connected_order_arc_914  1
    order_1_16  connected_order_arc_937  1
    order_1_16  connected_order_arc_960  1
    order_1_16  connected_order_arc_983  1
    order_1_16  connected_order_arc_1006  1
    order_1_16  connected_order_arc_1029  1
    order_1_16  connected_order_arc_1052  1
    order_1_16  connected_order_arc_1063  -1
    order_1_16  connected_order_arc_1065  -1
    order_1_16  connected_order_arc_1067  -1
    order_1_16  connected_order_arc_1069  -1
    order_1_16  connected_order_arc_1071  -1
    order_1_16  connected_order_arc_1073  -1
    order_1_16  connected_order_arc_1075  -1
    order_1_16  connected_order_arc_1077  -1
    order_1_16  connected_order_arc_1079  -1
    order_1_16  connected_order_arc_1081  -1
    order_1_16  connected_order_arc_1083  -1
    order_1_16  connected_order_arc_1100  1
    order_1_16  connected_order_arc_1123  1
    order_1_16  connected_order_arc_1146  1
    order_1_16  connected_order_arc_1169  1
    order_1_16  order_active_lb_1226  1
    order_1_16  order_active_ub_1227  1
    visit_1_17  out_degree_1230  -1
    visit_1_17  in_degree_1231  -1
    visit_1_17  order_active_lb_1232  -1
    visit_1_17  order_active_ub_1233  -12
    visit_1_17  service_visit_def_1234  -1
    order_1_17  connected_order_arc_916  1
    order_1_17  connected_order_arc_939  1
    order_1_17  connected_order_arc_962  1
    order_1_17  connected_order_arc_985  1
    order_1_17  connected_order_arc_1008  1
    order_1_17  connected_order_arc_1031  1
    order_1_17  connected_order_arc_1054  1
    order_1_17  connected_order_arc_1077  1
    order_1_17  connected_order_arc_1086  -1
    order_1_17  connected_order_arc_1088  -1
    order_1_17  connected_order_arc_1090  -1
    order_1_17  connected_order_arc_1092  -1
    order_1_17  connected_order_arc_1094  -1
    order_1_17  connected_order_arc_1096  -1
    order_1_17  connected_order_arc_1098  -1
    order_1_17  connected_order_arc_1100  -1
    order_1_17  connected_order_arc_1102  -1
    order_1_17  connected_order_arc_1104  -1
    order_1_17  connected_order_arc_1106  -1
    order_1_17  connected_order_arc_1125  1
    order_1_17  connected_order_arc_1148  1
    order_1_17  connected_order_arc_1171  1
    order_1_17  order_active_lb_1232  1
    order_1_17  order_active_ub_1233  1
    visit_1_18  out_degree_1236  -1
    visit_1_18  in_degree_1237  -1
    visit_1_18  order_active_lb_1238  -1
    visit_1_18  order_active_ub_1239  -12
    visit_1_18  service_visit_def_1240  -1
    order_1_18  connected_order_arc_918  1
    order_1_18  connected_order_arc_941  1
    order_1_18  connected_order_arc_964  1
    order_1_18  connected_order_arc_987  1
    order_1_18  connected_order_arc_1010  1
    order_1_18  connected_order_arc_1033  1
    order_1_18  connected_order_arc_1056  1
    order_1_18  connected_order_arc_1079  1
    order_1_18  connected_order_arc_1102  1
    order_1_18  connected_order_arc_1109  -1
    order_1_18  connected_order_arc_1111  -1
    order_1_18  connected_order_arc_1113  -1
    order_1_18  connected_order_arc_1115  -1
    order_1_18  connected_order_arc_1117  -1
    order_1_18  connected_order_arc_1119  -1
    order_1_18  connected_order_arc_1121  -1
    order_1_18  connected_order_arc_1123  -1
    order_1_18  connected_order_arc_1125  -1
    order_1_18  connected_order_arc_1127  -1
    order_1_18  connected_order_arc_1129  -1
    order_1_18  connected_order_arc_1150  1
    order_1_18  connected_order_arc_1173  1
    order_1_18  order_active_lb_1238  1
    order_1_18  order_active_ub_1239  1
    visit_1_19  out_degree_1242  -1
    visit_1_19  in_degree_1243  -1
    visit_1_19  order_active_lb_1244  -1
    visit_1_19  order_active_ub_1245  -12
    visit_1_19  service_visit_def_1246  -1
    order_1_19  connected_order_arc_920  1
    order_1_19  connected_order_arc_943  1
    order_1_19  connected_order_arc_966  1
    order_1_19  connected_order_arc_989  1
    order_1_19  connected_order_arc_1012  1
    order_1_19  connected_order_arc_1035  1
    order_1_19  connected_order_arc_1058  1
    order_1_19  connected_order_arc_1081  1
    order_1_19  connected_order_arc_1104  1
    order_1_19  connected_order_arc_1127  1
    order_1_19  connected_order_arc_1132  -1
    order_1_19  connected_order_arc_1134  -1
    order_1_19  connected_order_arc_1136  -1
    order_1_19  connected_order_arc_1138  -1
    order_1_19  connected_order_arc_1140  -1
    order_1_19  connected_order_arc_1142  -1
    order_1_19  connected_order_arc_1144  -1
    order_1_19  connected_order_arc_1146  -1
    order_1_19  connected_order_arc_1148  -1
    order_1_19  connected_order_arc_1150  -1
    order_1_19  connected_order_arc_1152  -1
    order_1_19  connected_order_arc_1175  1
    order_1_19  order_active_lb_1244  1
    order_1_19  order_active_ub_1245  1
    visit_1_20  out_degree_1248  -1
    visit_1_20  in_degree_1249  -1
    visit_1_20  order_active_lb_1250  -1
    visit_1_20  order_active_ub_1251  -12
    visit_1_20  service_visit_def_1252  -1
    order_1_20  connected_order_arc_922  1
    order_1_20  connected_order_arc_945  1
    order_1_20  connected_order_arc_968  1
    order_1_20  connected_order_arc_991  1
    order_1_20  connected_order_arc_1014  1
    order_1_20  connected_order_arc_1037  1
    order_1_20  connected_order_arc_1060  1
    order_1_20  connected_order_arc_1083  1
    order_1_20  connected_order_arc_1106  1
    order_1_20  connected_order_arc_1129  1
    order_1_20  connected_order_arc_1152  1
    order_1_20  connected_order_arc_1155  -1
    order_1_20  connected_order_arc_1157  -1
    order_1_20  connected_order_arc_1159  -1
    order_1_20  connected_order_arc_1161  -1
    order_1_20  connected_order_arc_1163  -1
    order_1_20  connected_order_arc_1165  -1
    order_1_20  connected_order_arc_1167  -1
    order_1_20  connected_order_arc_1169  -1
    order_1_20  connected_order_arc_1171  -1
    order_1_20  connected_order_arc_1173  -1
    order_1_20  connected_order_arc_1175  -1
    order_1_20  order_active_lb_1250  1
    order_1_20  order_active_ub_1251  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_0  arc_capacity_887  -25
    arc_1_0_0  depot_departure_or_bypass_1176  1
    arc_1_0_0  depot_return_or_bypass_1177  1
    MARKER    'MARKER'                 'INTEND'
    load_1_0_0  arc_capacity_887  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_6  arc_capacity_888  -25
    arc_1_0_6  depot_departure_or_bypass_1176  1
    arc_1_0_6  in_degree_1179  1
    arc_1_0_6  original_T_including_depot_unload_1257  8.7749189782983967e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_6  arc_capacity_888  1
    load_1_0_6  segment_load_conservation_1182  -1
    load_1_0_6  segment_prefix_lb_1183  1
    load_1_0_6  segment_prefix_ub_1184  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_7  arc_capacity_889  -25
    arc_1_0_7  depot_departure_or_bypass_1176  1
    arc_1_0_7  in_degree_1186  1
    arc_1_0_7  original_T_including_depot_unload_1257  8.7918533905669346e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_7  arc_capacity_889  1
    load_1_0_7  segment_load_conservation_1189  -1
    load_1_0_7  segment_prefix_lb_1190  1
    load_1_0_7  segment_prefix_ub_1191  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_8  arc_capacity_890  -25
    arc_1_0_8  depot_departure_or_bypass_1176  1
    arc_1_0_8  in_degree_1193  1
    arc_1_0_8  original_T_including_depot_unload_1257  1.0088905112952611e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_8  arc_capacity_890  1
    load_1_0_8  segment_load_conservation_1196  -1
    load_1_0_8  segment_prefix_lb_1197  1
    load_1_0_8  segment_prefix_ub_1198  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_9  arc_capacity_891  -25
    arc_1_0_9  depot_departure_or_bypass_1176  1
    arc_1_0_9  in_degree_1200  1
    arc_1_0_9  original_T_including_depot_unload_1257  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_9  arc_capacity_891  1
    load_1_0_9  segment_load_conservation_1203  -1
    load_1_0_9  segment_prefix_lb_1204  1
    load_1_0_9  segment_prefix_ub_1205  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_13  arc_capacity_892  -25
    arc_1_0_13  depot_departure_or_bypass_1176  1
    arc_1_0_13  in_degree_1207  1
    arc_1_0_13  original_T_including_depot_unload_1257  5.4249700630778887e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_13  arc_capacity_892  1
    load_1_0_13  free_load_conservation_1211  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_14  arc_capacity_893  -25
    arc_1_0_14  depot_departure_or_bypass_1176  1
    arc_1_0_14  in_degree_1213  1
    arc_1_0_14  original_T_including_depot_unload_1257  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_14  arc_capacity_893  1
    load_1_0_14  free_load_conservation_1217  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_15  arc_capacity_894  -25
    arc_1_0_15  depot_departure_or_bypass_1176  1
    arc_1_0_15  in_degree_1219  1
    arc_1_0_15  original_T_including_depot_unload_1257  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_15  arc_capacity_894  1
    load_1_0_15  free_load_conservation_1223  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_16  arc_capacity_895  -25
    arc_1_0_16  depot_departure_or_bypass_1176  1
    arc_1_0_16  in_degree_1225  1
    arc_1_0_16  original_T_including_depot_unload_1257  4.9403722507151832e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_16  arc_capacity_895  1
    load_1_0_16  free_load_conservation_1229  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_17  arc_capacity_896  -25
    arc_1_0_17  depot_departure_or_bypass_1176  1
    arc_1_0_17  in_degree_1231  1
    arc_1_0_17  original_T_including_depot_unload_1257  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_17  arc_capacity_896  1
    load_1_0_17  free_load_conservation_1235  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_18  arc_capacity_897  -25
    arc_1_0_18  depot_departure_or_bypass_1176  1
    arc_1_0_18  in_degree_1237  1
    arc_1_0_18  original_T_including_depot_unload_1257  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_18  arc_capacity_897  1
    load_1_0_18  free_load_conservation_1241  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_19  arc_capacity_898  -25
    arc_1_0_19  depot_departure_or_bypass_1176  1
    arc_1_0_19  in_degree_1243  1
    arc_1_0_19  original_T_including_depot_unload_1257  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_19  arc_capacity_898  1
    load_1_0_19  free_load_conservation_1247  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_20  arc_capacity_899  -25
    arc_1_0_20  depot_departure_or_bypass_1176  1
    arc_1_0_20  in_degree_1249  1
    arc_1_0_20  original_T_including_depot_unload_1257  7.2130540230577469e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_20  arc_capacity_899  1
    load_1_0_20  free_load_conservation_1253  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_0  arc_capacity_900  -25
    arc_1_6_0  depot_return_or_bypass_1177  1
    arc_1_6_0  out_degree_1178  1
    arc_1_6_0  original_T_including_depot_unload_1257  1.0479182987243917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_0  arc_capacity_900  1
    load_1_6_0  segment_load_conservation_1182  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_7  arc_capacity_901  -25
    arc_1_6_7  connected_order_arc_902  -13
    arc_1_6_7  out_degree_1178  1
    arc_1_6_7  in_degree_1186  1
    arc_1_6_7  original_T_including_depot_unload_1257  2.4155873404211835e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_7  arc_capacity_901  1
    load_1_6_7  segment_load_conservation_1182  1
    load_1_6_7  segment_load_conservation_1189  -1
    load_1_6_7  segment_prefix_lb_1190  1
    load_1_6_7  segment_prefix_ub_1191  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_8  arc_capacity_903  -25
    arc_1_6_8  connected_order_arc_904  -13
    arc_1_6_8  out_degree_1178  1
    arc_1_6_8  in_degree_1193  1
    arc_1_6_8  original_T_including_depot_unload_1257  3.6094216796124527e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_8  arc_capacity_903  1
    load_1_6_8  segment_load_conservation_1182  1
    load_1_6_8  segment_load_conservation_1196  -1
    load_1_6_8  segment_prefix_lb_1197  1
    load_1_6_8  segment_prefix_ub_1198  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_9  arc_capacity_905  -25
    arc_1_6_9  connected_order_arc_906  -13
    arc_1_6_9  out_degree_1178  1
    arc_1_6_9  in_degree_1200  1
    arc_1_6_9  original_T_including_depot_unload_1257  1.0880068546845516e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_9  arc_capacity_905  1
    load_1_6_9  segment_load_conservation_1182  1
    load_1_6_9  segment_load_conservation_1203  -1
    load_1_6_9  segment_prefix_lb_1204  1
    load_1_6_9  segment_prefix_ub_1205  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_13  arc_capacity_907  -25
    arc_1_6_13  connected_order_arc_908  -13
    arc_1_6_13  out_degree_1178  1
    arc_1_6_13  in_degree_1207  1
    arc_1_6_13  original_T_including_depot_unload_1257  1.5145600125783847e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_13  arc_capacity_907  1
    load_1_6_13  segment_load_conservation_1182  1
    load_1_6_13  free_load_conservation_1211  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_14  arc_capacity_909  -25
    arc_1_6_14  connected_order_arc_910  -13
    arc_1_6_14  out_degree_1178  1
    arc_1_6_14  in_degree_1213  1
    arc_1_6_14  original_T_including_depot_unload_1257  1.4829753176244692e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_14  arc_capacity_909  1
    load_1_6_14  segment_load_conservation_1182  1
    load_1_6_14  free_load_conservation_1217  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_15  arc_capacity_911  -25
    arc_1_6_15  connected_order_arc_912  -13
    arc_1_6_15  out_degree_1178  1
    arc_1_6_15  in_degree_1219  1
    arc_1_6_15  original_T_including_depot_unload_1257  5.2280951376932137e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_15  arc_capacity_911  1
    load_1_6_15  segment_load_conservation_1182  1
    load_1_6_15  free_load_conservation_1223  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_16  arc_capacity_913  -25
    arc_1_6_16  connected_order_arc_914  -13
    arc_1_6_16  out_degree_1178  1
    arc_1_6_16  in_degree_1225  1
    arc_1_6_16  original_T_including_depot_unload_1257  1.3473071485321755e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_16  arc_capacity_913  1
    load_1_6_16  segment_load_conservation_1182  1
    load_1_6_16  free_load_conservation_1229  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_17  arc_capacity_915  -25
    arc_1_6_17  connected_order_arc_916  -13
    arc_1_6_17  out_degree_1178  1
    arc_1_6_17  in_degree_1231  1
    arc_1_6_17  original_T_including_depot_unload_1257  1.7883808204567979e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_17  arc_capacity_915  1
    load_1_6_17  segment_load_conservation_1182  1
    load_1_6_17  free_load_conservation_1235  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_18  arc_capacity_917  -25
    arc_1_6_18  connected_order_arc_918  -13
    arc_1_6_18  out_degree_1178  1
    arc_1_6_18  in_degree_1237  1
    arc_1_6_18  original_T_including_depot_unload_1257  1.2336637947519732e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_18  arc_capacity_917  1
    load_1_6_18  segment_load_conservation_1182  1
    load_1_6_18  free_load_conservation_1241  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_19  arc_capacity_919  -25
    arc_1_6_19  connected_order_arc_920  -13
    arc_1_6_19  out_degree_1178  1
    arc_1_6_19  in_degree_1243  1
    arc_1_6_19  original_T_including_depot_unload_1257  1.3852878731513219e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_19  arc_capacity_919  1
    load_1_6_19  segment_load_conservation_1182  1
    load_1_6_19  free_load_conservation_1247  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_20  arc_capacity_921  -25
    arc_1_6_20  connected_order_arc_922  -13
    arc_1_6_20  out_degree_1178  1
    arc_1_6_20  in_degree_1249  1
    arc_1_6_20  original_T_including_depot_unload_1257  1.5223381412470410e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_20  arc_capacity_921  1
    load_1_6_20  segment_load_conservation_1182  1
    load_1_6_20  free_load_conservation_1253  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_0  arc_capacity_923  -25
    arc_1_7_0  depot_return_or_bypass_1177  1
    arc_1_7_0  out_degree_1185  1
    arc_1_7_0  original_T_including_depot_unload_1257  8.7918533905669346e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_0  arc_capacity_923  1
    load_1_7_0  segment_load_conservation_1189  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_6  arc_capacity_924  -25
    arc_1_7_6  connected_order_arc_925  -13
    arc_1_7_6  in_degree_1179  1
    arc_1_7_6  out_degree_1185  1
    arc_1_7_6  original_T_including_depot_unload_1257  3.6821827312741834e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_6  arc_capacity_924  1
    load_1_7_6  segment_load_conservation_1182  -1
    load_1_7_6  segment_prefix_lb_1183  1
    load_1_7_6  segment_prefix_ub_1184  1
    load_1_7_6  segment_load_conservation_1189  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_8  arc_capacity_926  -25
    arc_1_7_8  connected_order_arc_927  -13
    arc_1_7_8  out_degree_1185  1
    arc_1_7_8  in_degree_1193  1
    arc_1_7_8  original_T_including_depot_unload_1257  5.1107432522690152e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_8  arc_capacity_926  1
    load_1_7_8  segment_load_conservation_1189  1
    load_1_7_8  segment_load_conservation_1196  -1
    load_1_7_8  segment_prefix_lb_1197  1
    load_1_7_8  segment_prefix_ub_1198  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_9  arc_capacity_928  -25
    arc_1_7_9  connected_order_arc_929  -13
    arc_1_7_9  out_degree_1185  1
    arc_1_7_9  in_degree_1200  1
    arc_1_7_9  original_T_including_depot_unload_1257  1.0412376551742484e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_9  arc_capacity_928  1
    load_1_7_9  segment_load_conservation_1189  1
    load_1_7_9  segment_load_conservation_1203  -1
    load_1_7_9  segment_prefix_lb_1204  1
    load_1_7_9  segment_prefix_ub_1205  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_13  arc_capacity_930  -25
    arc_1_7_13  connected_order_arc_931  -13
    arc_1_7_13  out_degree_1185  1
    arc_1_7_13  in_degree_1207  1
    arc_1_7_13  original_T_including_depot_unload_1257  1.3840439316159188e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_13  arc_capacity_930  1
    load_1_7_13  segment_load_conservation_1189  1
    load_1_7_13  free_load_conservation_1211  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_14  arc_capacity_932  -25
    arc_1_7_14  connected_order_arc_933  -13
    arc_1_7_14  out_degree_1185  1
    arc_1_7_14  in_degree_1213  1
    arc_1_7_14  original_T_including_depot_unload_1257  1.3293032990949939e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_14  arc_capacity_932  1
    load_1_7_14  segment_load_conservation_1189  1
    load_1_7_14  free_load_conservation_1217  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_15  arc_capacity_934  -25
    arc_1_7_15  connected_order_arc_935  -13
    arc_1_7_15  out_degree_1185  1
    arc_1_7_15  in_degree_1219  1
    arc_1_7_15  original_T_including_depot_unload_1257  3.6824909986567474e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_15  arc_capacity_934  1
    load_1_7_15  segment_load_conservation_1189  1
    load_1_7_15  free_load_conservation_1223  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_16  arc_capacity_936  -25
    arc_1_7_16  connected_order_arc_937  -13
    arc_1_7_16  out_degree_1185  1
    arc_1_7_16  in_degree_1225  1
    arc_1_7_16  original_T_including_depot_unload_1257  1.2434091529834902e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_16  arc_capacity_936  1
    load_1_7_16  segment_load_conservation_1189  1
    load_1_7_16  free_load_conservation_1229  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_17  arc_capacity_938  -25
    arc_1_7_17  connected_order_arc_939  -13
    arc_1_7_17  out_degree_1185  1
    arc_1_7_17  in_degree_1231  1
    arc_1_7_17  original_T_including_depot_unload_1257  1.5502221880497036e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_17  arc_capacity_938  1
    load_1_7_17  segment_load_conservation_1189  1
    load_1_7_17  free_load_conservation_1235  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_18  arc_capacity_940  -25
    arc_1_7_18  connected_order_arc_941  -13
    arc_1_7_18  out_degree_1185  1
    arc_1_7_18  in_degree_1237  1
    arc_1_7_18  original_T_including_depot_unload_1257  1.0988088346747072e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_18  arc_capacity_940  1
    load_1_7_18  segment_load_conservation_1189  1
    load_1_7_18  free_load_conservation_1241  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_19  arc_capacity_942  -25
    arc_1_7_19  connected_order_arc_943  -13
    arc_1_7_19  out_degree_1185  1
    arc_1_7_19  in_degree_1243  1
    arc_1_7_19  original_T_including_depot_unload_1257  1.1479472058029019e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_19  arc_capacity_942  1
    load_1_7_19  segment_load_conservation_1189  1
    load_1_7_19  free_load_conservation_1247  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_20  arc_capacity_944  -25
    arc_1_7_20  connected_order_arc_945  -13
    arc_1_7_20  out_degree_1185  1
    arc_1_7_20  in_degree_1249  1
    arc_1_7_20  original_T_including_depot_unload_1257  1.4394323281782954e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_20  arc_capacity_944  1
    load_1_7_20  segment_load_conservation_1189  1
    load_1_7_20  free_load_conservation_1253  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_0  arc_capacity_946  -25
    arc_1_8_0  depot_return_or_bypass_1177  1
    arc_1_8_0  out_degree_1192  1
    arc_1_8_0  original_T_including_depot_unload_1257  887.312716328479
    MARKER    'MARKER'                 'INTEND'
    load_1_8_0  arc_capacity_946  1
    load_1_8_0  segment_load_conservation_1196  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_6  arc_capacity_947  -25
    arc_1_8_6  connected_order_arc_948  -13
    arc_1_8_6  in_degree_1179  1
    arc_1_8_6  out_degree_1192  1
    arc_1_8_6  original_T_including_depot_unload_1257  7.8136221151890174e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_6  arc_capacity_947  1
    load_1_8_6  segment_load_conservation_1182  -1
    load_1_8_6  segment_prefix_lb_1183  1
    load_1_8_6  segment_prefix_ub_1184  1
    load_1_8_6  segment_load_conservation_1196  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_7  arc_capacity_949  -25
    arc_1_8_7  connected_order_arc_950  -13
    arc_1_8_7  in_degree_1186  1
    arc_1_8_7  out_degree_1192  1
    arc_1_8_7  original_T_including_depot_unload_1257  1.0967168052209140e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_7  arc_capacity_949  1
    load_1_8_7  segment_load_conservation_1189  -1
    load_1_8_7  segment_prefix_lb_1190  1
    load_1_8_7  segment_prefix_ub_1191  1
    load_1_8_7  segment_load_conservation_1196  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_9  arc_capacity_951  -25
    arc_1_8_9  connected_order_arc_952  -13
    arc_1_8_9  out_degree_1192  1
    arc_1_8_9  in_degree_1200  1
    arc_1_8_9  original_T_including_depot_unload_1257  3.3422575089633142e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_9  arc_capacity_951  1
    load_1_8_9  segment_load_conservation_1196  1
    load_1_8_9  segment_load_conservation_1203  -1
    load_1_8_9  segment_prefix_lb_1204  1
    load_1_8_9  segment_prefix_ub_1205  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_13  arc_capacity_953  -25
    arc_1_8_13  connected_order_arc_954  -13
    arc_1_8_13  out_degree_1192  1
    arc_1_8_13  in_degree_1207  1
    arc_1_8_13  original_T_including_depot_unload_1257  9.2153450304618127e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_13  arc_capacity_953  1
    load_1_8_13  segment_load_conservation_1196  1
    load_1_8_13  free_load_conservation_1211  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_14  arc_capacity_955  -25
    arc_1_8_14  connected_order_arc_956  -13
    arc_1_8_14  out_degree_1192  1
    arc_1_8_14  in_degree_1213  1
    arc_1_8_14  original_T_including_depot_unload_1257  1.0213043329444467e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_14  arc_capacity_955  1
    load_1_8_14  segment_load_conservation_1196  1
    load_1_8_14  free_load_conservation_1217  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_15  arc_capacity_957  -25
    arc_1_8_15  connected_order_arc_958  -13
    arc_1_8_15  out_degree_1192  1
    arc_1_8_15  in_degree_1219  1
    arc_1_8_15  original_T_including_depot_unload_1257  1.4573788798892317e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_15  arc_capacity_957  1
    load_1_8_15  segment_load_conservation_1196  1
    load_1_8_15  free_load_conservation_1223  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_16  arc_capacity_959  -25
    arc_1_8_16  connected_order_arc_960  -13
    arc_1_8_16  out_degree_1192  1
    arc_1_8_16  in_degree_1225  1
    arc_1_8_16  original_T_including_depot_unload_1257  6.9052982730578867e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_16  arc_capacity_959  1
    load_1_8_16  segment_load_conservation_1196  1
    load_1_8_16  free_load_conservation_1229  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_17  arc_capacity_961  -25
    arc_1_8_17  connected_order_arc_962  -13
    arc_1_8_17  out_degree_1192  1
    arc_1_8_17  in_degree_1231  1
    arc_1_8_17  original_T_including_depot_unload_1257  2226.1143218952
    MARKER    'MARKER'                 'INTEND'
    load_1_8_17  arc_capacity_961  1
    load_1_8_17  segment_load_conservation_1196  1
    load_1_8_17  free_load_conservation_1235  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_18  arc_capacity_963  -25
    arc_1_8_18  connected_order_arc_964  -13
    arc_1_8_18  out_degree_1192  1
    arc_1_8_18  in_degree_1237  1
    arc_1_8_18  original_T_including_depot_unload_1257  7.8495921746600118e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_18  arc_capacity_963  1
    load_1_8_18  segment_load_conservation_1196  1
    load_1_8_18  free_load_conservation_1241  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_19  arc_capacity_965  -25
    arc_1_8_19  connected_order_arc_966  -13
    arc_1_8_19  out_degree_1192  1
    arc_1_8_19  in_degree_1243  1
    arc_1_8_19  original_T_including_depot_unload_1257  1.6048175645110312e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_19  arc_capacity_965  1
    load_1_8_19  segment_load_conservation_1196  1
    load_1_8_19  free_load_conservation_1247  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_20  arc_capacity_967  -25
    arc_1_8_20  connected_order_arc_968  -13
    arc_1_8_20  out_degree_1192  1
    arc_1_8_20  in_degree_1249  1
    arc_1_8_20  original_T_including_depot_unload_1257  7.1006591329511764e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_20  arc_capacity_967  1
    load_1_8_20  segment_load_conservation_1196  1
    load_1_8_20  free_load_conservation_1253  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_0  arc_capacity_969  -25
    arc_1_9_0  depot_return_or_bypass_1177  1
    arc_1_9_0  out_degree_1199  1
    arc_1_9_0  original_T_including_depot_unload_1257  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_0  arc_capacity_969  1
    load_1_9_0  segment_load_conservation_1203  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_6  arc_capacity_970  -25
    arc_1_9_6  connected_order_arc_971  -13
    arc_1_9_6  in_degree_1179  1
    arc_1_9_6  out_degree_1199  1
    arc_1_9_6  original_T_including_depot_unload_1257  8.1417957710766450e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_6  arc_capacity_970  1
    load_1_9_6  segment_load_conservation_1182  -1
    load_1_9_6  segment_prefix_lb_1183  1
    load_1_9_6  segment_prefix_ub_1184  1
    load_1_9_6  segment_load_conservation_1203  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_7  arc_capacity_972  -25
    arc_1_9_7  connected_order_arc_973  -13
    arc_1_9_7  in_degree_1186  1
    arc_1_9_7  out_degree_1199  1
    arc_1_9_7  original_T_including_depot_unload_1257  1.0412376551742484e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_7  arc_capacity_972  1
    load_1_9_7  segment_load_conservation_1189  -1
    load_1_9_7  segment_prefix_lb_1190  1
    load_1_9_7  segment_prefix_ub_1191  1
    load_1_9_7  segment_load_conservation_1203  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_8  arc_capacity_974  -25
    arc_1_9_8  connected_order_arc_975  -13
    arc_1_9_8  in_degree_1193  1
    arc_1_9_8  out_degree_1199  1
    arc_1_9_8  original_T_including_depot_unload_1257  8.5502565124349769e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_8  arc_capacity_974  1
    load_1_9_8  segment_load_conservation_1196  -1
    load_1_9_8  segment_prefix_lb_1197  1
    load_1_9_8  segment_prefix_ub_1198  1
    load_1_9_8  segment_load_conservation_1203  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_13  arc_capacity_976  -25
    arc_1_9_13  connected_order_arc_977  -13
    arc_1_9_13  out_degree_1199  1
    arc_1_9_13  in_degree_1207  1
    arc_1_9_13  original_T_including_depot_unload_1257  603.649383070884
    MARKER    'MARKER'                 'INTEND'
    load_1_9_13  arc_capacity_976  1
    load_1_9_13  segment_load_conservation_1203  1
    load_1_9_13  free_load_conservation_1211  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_14  arc_capacity_978  -25
    arc_1_9_14  connected_order_arc_979  -13
    arc_1_9_14  out_degree_1199  1
    arc_1_9_14  in_degree_1213  1
    arc_1_9_14  original_T_including_depot_unload_1257  6.8976718276177132e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_14  arc_capacity_978  1
    load_1_9_14  segment_load_conservation_1203  1
    load_1_9_14  free_load_conservation_1217  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_15  arc_capacity_980  -25
    arc_1_9_15  connected_order_arc_981  -13
    arc_1_9_15  out_degree_1199  1
    arc_1_9_15  in_degree_1219  1
    arc_1_9_15  original_T_including_depot_unload_1257  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_15  arc_capacity_980  1
    load_1_9_15  segment_load_conservation_1203  1
    load_1_9_15  free_load_conservation_1223  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_16  arc_capacity_982  -25
    arc_1_9_16  connected_order_arc_983  -13
    arc_1_9_16  out_degree_1199  1
    arc_1_9_16  in_degree_1225  1
    arc_1_9_16  original_T_including_depot_unload_1257  3.7315439746742123e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_16  arc_capacity_982  1
    load_1_9_16  segment_load_conservation_1203  1
    load_1_9_16  free_load_conservation_1229  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_17  arc_capacity_984  -25
    arc_1_9_17  connected_order_arc_985  -13
    arc_1_9_17  out_degree_1199  1
    arc_1_9_17  in_degree_1231  1
    arc_1_9_17  original_T_including_depot_unload_1257  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_17  arc_capacity_984  1
    load_1_9_17  segment_load_conservation_1203  1
    load_1_9_17  free_load_conservation_1235  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_18  arc_capacity_986  -25
    arc_1_9_18  connected_order_arc_987  -13
    arc_1_9_18  out_degree_1199  1
    arc_1_9_18  in_degree_1237  1
    arc_1_9_18  original_T_including_depot_unload_1257  4.5128490093732506e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_18  arc_capacity_986  1
    load_1_9_18  segment_load_conservation_1203  1
    load_1_9_18  free_load_conservation_1241  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_19  arc_capacity_988  -25
    arc_1_9_19  connected_order_arc_989  -13
    arc_1_9_19  out_degree_1199  1
    arc_1_9_19  in_degree_1243  1
    arc_1_9_19  original_T_including_depot_unload_1257  1.3127274783157229e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_19  arc_capacity_988  1
    load_1_9_19  segment_load_conservation_1203  1
    load_1_9_19  free_load_conservation_1247  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_20  arc_capacity_990  -25
    arc_1_9_20  connected_order_arc_991  -13
    arc_1_9_20  out_degree_1199  1
    arc_1_9_20  in_degree_1249  1
    arc_1_9_20  original_T_including_depot_unload_1257  4.6128219015626763e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_20  arc_capacity_990  1
    load_1_9_20  segment_load_conservation_1203  1
    load_1_9_20  free_load_conservation_1253  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_0  arc_capacity_992  -25
    arc_1_13_0  depot_return_or_bypass_1177  1
    arc_1_13_0  out_degree_1206  1
    arc_1_13_0  original_T_including_depot_unload_1257  5.4249700630778887e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_0  arc_capacity_992  1
    load_1_13_0  free_load_conservation_1211  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_6  arc_capacity_993  -25
    arc_1_13_6  connected_order_arc_994  -13
    arc_1_13_6  in_degree_1179  1
    arc_1_13_6  out_degree_1206  1
    arc_1_13_6  original_T_including_depot_unload_1257  1.2876689365561549e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_6  arc_capacity_993  1
    load_1_13_6  segment_load_conservation_1182  -1
    load_1_13_6  segment_prefix_lb_1183  1
    load_1_13_6  segment_prefix_ub_1184  1
    load_1_13_6  free_load_conservation_1211  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_7  arc_capacity_995  -25
    arc_1_13_7  connected_order_arc_996  -13
    arc_1_13_7  in_degree_1186  1
    arc_1_13_7  out_degree_1206  1
    arc_1_13_7  original_T_including_depot_unload_1257  1.3840439316159188e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_7  arc_capacity_995  1
    load_1_13_7  segment_load_conservation_1189  -1
    load_1_13_7  segment_prefix_lb_1190  1
    load_1_13_7  segment_prefix_ub_1191  1
    load_1_13_7  free_load_conservation_1211  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_8  arc_capacity_997  -25
    arc_1_13_8  connected_order_arc_998  -13
    arc_1_13_8  in_degree_1193  1
    arc_1_13_8  out_degree_1206  1
    arc_1_13_8  original_T_including_depot_unload_1257  1.3776676659817167e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_8  arc_capacity_997  1
    load_1_13_8  segment_load_conservation_1196  -1
    load_1_13_8  segment_prefix_lb_1197  1
    load_1_13_8  segment_prefix_ub_1198  1
    load_1_13_8  free_load_conservation_1211  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_9  arc_capacity_999  -25
    arc_1_13_9  connected_order_arc_1000  -13
    arc_1_13_9  in_degree_1200  1
    arc_1_13_9  out_degree_1206  1
    arc_1_13_9  original_T_including_depot_unload_1257  603.649383070884
    MARKER    'MARKER'                 'INTEND'
    load_1_13_9  arc_capacity_999  1
    load_1_13_9  segment_load_conservation_1203  -1
    load_1_13_9  segment_prefix_lb_1204  1
    load_1_13_9  segment_prefix_ub_1205  1
    load_1_13_9  free_load_conservation_1211  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_14  arc_capacity_1001  -25
    arc_1_13_14  connected_order_arc_1002  -13
    arc_1_13_14  out_degree_1206  1
    arc_1_13_14  in_degree_1213  1
    arc_1_13_14  original_T_including_depot_unload_1257  1.7461252424213140e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_14  arc_capacity_1001  1
    load_1_13_14  free_load_conservation_1211  1
    load_1_13_14  free_load_conservation_1217  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_15  arc_capacity_1003  -25
    arc_1_13_15  connected_order_arc_1004  -13
    arc_1_13_15  out_degree_1206  1
    arc_1_13_15  in_degree_1219  1
    arc_1_13_15  original_T_including_depot_unload_1257  1.6231508478292610e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_15  arc_capacity_1003  1
    load_1_13_15  free_load_conservation_1211  1
    load_1_13_15  free_load_conservation_1223  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_16  arc_capacity_1005  -25
    arc_1_13_16  connected_order_arc_1006  -13
    arc_1_13_16  out_degree_1206  1
    arc_1_13_16  in_degree_1225  1
    arc_1_13_16  original_T_including_depot_unload_1257  2.3159636865750136e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_16  arc_capacity_1005  1
    load_1_13_16  free_load_conservation_1211  1
    load_1_13_16  free_load_conservation_1229  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_17  arc_capacity_1007  -25
    arc_1_13_17  connected_order_arc_1008  -13
    arc_1_13_17  out_degree_1206  1
    arc_1_13_17  in_degree_1231  1
    arc_1_13_17  original_T_including_depot_unload_1257  1.7249161387293191e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_17  arc_capacity_1007  1
    load_1_13_17  free_load_conservation_1211  1
    load_1_13_17  free_load_conservation_1235  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_18  arc_capacity_1009  -25
    arc_1_13_18  connected_order_arc_1010  -13
    arc_1_13_18  out_degree_1206  1
    arc_1_13_18  in_degree_1237  1
    arc_1_13_18  original_T_including_depot_unload_1257  2.8529311190414518e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_18  arc_capacity_1009  1
    load_1_13_18  free_load_conservation_1211  1
    load_1_13_18  free_load_conservation_1241  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_19  arc_capacity_1011  -25
    arc_1_13_19  connected_order_arc_1012  -13
    arc_1_13_19  out_degree_1206  1
    arc_1_13_19  in_degree_1243  1
    arc_1_13_19  original_T_including_depot_unload_1257  1.0838347754693179e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_19  arc_capacity_1011  1
    load_1_13_19  free_load_conservation_1211  1
    load_1_13_19  free_load_conservation_1247  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_20  arc_capacity_1013  -25
    arc_1_13_20  connected_order_arc_1014  -13
    arc_1_13_20  out_degree_1206  1
    arc_1_13_20  in_degree_1249  1
    arc_1_13_20  original_T_including_depot_unload_1257  3.2367117212973966e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_20  arc_capacity_1013  1
    load_1_13_20  free_load_conservation_1211  1
    load_1_13_20  free_load_conservation_1253  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_0  arc_capacity_1015  -25
    arc_1_14_0  depot_return_or_bypass_1177  1
    arc_1_14_0  out_degree_1212  1
    arc_1_14_0  original_T_including_depot_unload_1257  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_0  arc_capacity_1015  1
    load_1_14_0  free_load_conservation_1217  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_6  arc_capacity_1016  -25
    arc_1_14_6  connected_order_arc_1017  -13
    arc_1_14_6  in_degree_1179  1
    arc_1_14_6  out_degree_1212  1
    arc_1_14_6  original_T_including_depot_unload_1257  1.2798962893775918e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_6  arc_capacity_1016  1
    load_1_14_6  segment_load_conservation_1182  -1
    load_1_14_6  segment_prefix_lb_1183  1
    load_1_14_6  segment_prefix_ub_1184  1
    load_1_14_6  free_load_conservation_1217  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_7  arc_capacity_1018  -25
    arc_1_14_7  connected_order_arc_1019  -13
    arc_1_14_7  in_degree_1186  1
    arc_1_14_7  out_degree_1212  1
    arc_1_14_7  original_T_including_depot_unload_1257  1.3293032990949939e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_7  arc_capacity_1018  1
    load_1_14_7  segment_load_conservation_1189  -1
    load_1_14_7  segment_prefix_lb_1190  1
    load_1_14_7  segment_prefix_ub_1191  1
    load_1_14_7  free_load_conservation_1217  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_8  arc_capacity_1020  -25
    arc_1_14_8  connected_order_arc_1021  -13
    arc_1_14_8  in_degree_1193  1
    arc_1_14_8  out_degree_1212  1
    arc_1_14_8  original_T_including_depot_unload_1257  1.3874440214926751e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_8  arc_capacity_1020  1
    load_1_14_8  segment_load_conservation_1196  -1
    load_1_14_8  segment_prefix_lb_1197  1
    load_1_14_8  segment_prefix_ub_1198  1
    load_1_14_8  free_load_conservation_1217  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_9  arc_capacity_1022  -25
    arc_1_14_9  connected_order_arc_1023  -13
    arc_1_14_9  in_degree_1200  1
    arc_1_14_9  out_degree_1212  1
    arc_1_14_9  original_T_including_depot_unload_1257  6.8976718276177132e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_9  arc_capacity_1022  1
    load_1_14_9  segment_load_conservation_1203  -1
    load_1_14_9  segment_prefix_lb_1204  1
    load_1_14_9  segment_prefix_ub_1205  1
    load_1_14_9  free_load_conservation_1217  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_13  arc_capacity_1024  -25
    arc_1_14_13  connected_order_arc_1025  -13
    arc_1_14_13  in_degree_1207  1
    arc_1_14_13  out_degree_1212  1
    arc_1_14_13  original_T_including_depot_unload_1257  1.7461252424213140e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_13  arc_capacity_1024  1
    load_1_14_13  free_load_conservation_1211  -1
    load_1_14_13  free_load_conservation_1217  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_15  arc_capacity_1026  -25
    arc_1_14_15  connected_order_arc_1027  -13
    arc_1_14_15  out_degree_1212  1
    arc_1_14_15  in_degree_1219  1
    arc_1_14_15  original_T_including_depot_unload_1257  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_15  arc_capacity_1026  1
    load_1_14_15  free_load_conservation_1217  1
    load_1_14_15  free_load_conservation_1223  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_16  arc_capacity_1028  -25
    arc_1_14_16  connected_order_arc_1029  -13
    arc_1_14_16  out_degree_1212  1
    arc_1_14_16  in_degree_1225  1
    arc_1_14_16  original_T_including_depot_unload_1257  3.4754938304534517e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_16  arc_capacity_1028  1
    load_1_14_16  free_load_conservation_1217  1
    load_1_14_16  free_load_conservation_1229  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_17  arc_capacity_1030  -25
    arc_1_14_17  connected_order_arc_1031  -13
    arc_1_14_17  out_degree_1212  1
    arc_1_14_17  in_degree_1231  1
    arc_1_14_17  original_T_including_depot_unload_1257  1.5530568652263394e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_17  arc_capacity_1030  1
    load_1_14_17  free_load_conservation_1217  1
    load_1_14_17  free_load_conservation_1235  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_18  arc_capacity_1032  -25
    arc_1_14_18  connected_order_arc_1033  -13
    arc_1_14_18  out_degree_1212  1
    arc_1_14_18  in_degree_1237  1
    arc_1_14_18  original_T_including_depot_unload_1257  2.7078292664437623e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_18  arc_capacity_1032  1
    load_1_14_18  free_load_conservation_1217  1
    load_1_14_18  free_load_conservation_1241  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_19  arc_capacity_1034  -25
    arc_1_14_19  connected_order_arc_1035  -13
    arc_1_14_19  out_degree_1212  1
    arc_1_14_19  in_degree_1243  1
    arc_1_14_19  original_T_including_depot_unload_1257  9.1580557259044724e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_19  arc_capacity_1034  1
    load_1_14_19  free_load_conservation_1217  1
    load_1_14_19  free_load_conservation_1247  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_20  arc_capacity_1036  -25
    arc_1_14_20  connected_order_arc_1037  -13
    arc_1_14_20  out_degree_1212  1
    arc_1_14_20  in_degree_1249  1
    arc_1_14_20  original_T_including_depot_unload_1257  4.9242827332511274e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_20  arc_capacity_1036  1
    load_1_14_20  free_load_conservation_1217  1
    load_1_14_20  free_load_conservation_1253  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_0  arc_capacity_1038  -25
    arc_1_15_0  depot_return_or_bypass_1177  1
    arc_1_15_0  out_degree_1218  1
    arc_1_15_0  original_T_including_depot_unload_1257  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_0  arc_capacity_1038  1
    load_1_15_0  free_load_conservation_1223  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_6  arc_capacity_1039  -25
    arc_1_15_6  connected_order_arc_1040  -13
    arc_1_15_6  in_degree_1179  1
    arc_1_15_6  out_degree_1218  1
    arc_1_15_6  original_T_including_depot_unload_1257  7.3227602527872671e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_6  arc_capacity_1039  1
    load_1_15_6  segment_load_conservation_1182  -1
    load_1_15_6  segment_prefix_lb_1183  1
    load_1_15_6  segment_prefix_ub_1184  1
    load_1_15_6  free_load_conservation_1223  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_7  arc_capacity_1041  -25
    arc_1_15_7  connected_order_arc_1042  -13
    arc_1_15_7  in_degree_1186  1
    arc_1_15_7  out_degree_1218  1
    arc_1_15_7  original_T_including_depot_unload_1257  3.6824909986567474e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_7  arc_capacity_1041  1
    load_1_15_7  segment_load_conservation_1189  -1
    load_1_15_7  segment_prefix_lb_1190  1
    load_1_15_7  segment_prefix_ub_1191  1
    load_1_15_7  free_load_conservation_1223  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_8  arc_capacity_1043  -25
    arc_1_15_8  connected_order_arc_1044  -13
    arc_1_15_8  in_degree_1193  1
    arc_1_15_8  out_degree_1218  1
    arc_1_15_8  original_T_including_depot_unload_1257  861.314419336229
    MARKER    'MARKER'                 'INTEND'
    load_1_15_8  arc_capacity_1043  1
    load_1_15_8  segment_load_conservation_1196  -1
    load_1_15_8  segment_prefix_lb_1197  1
    load_1_15_8  segment_prefix_ub_1198  1
    load_1_15_8  free_load_conservation_1223  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_9  arc_capacity_1045  -25
    arc_1_15_9  connected_order_arc_1046  -13
    arc_1_15_9  in_degree_1200  1
    arc_1_15_9  out_degree_1218  1
    arc_1_15_9  original_T_including_depot_unload_1257  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_9  arc_capacity_1045  1
    load_1_15_9  segment_load_conservation_1203  -1
    load_1_15_9  segment_prefix_lb_1204  1
    load_1_15_9  segment_prefix_ub_1205  1
    load_1_15_9  free_load_conservation_1223  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_13  arc_capacity_1047  -25
    arc_1_15_13  connected_order_arc_1048  -13
    arc_1_15_13  in_degree_1207  1
    arc_1_15_13  out_degree_1218  1
    arc_1_15_13  original_T_including_depot_unload_1257  1.6231508478292610e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_13  arc_capacity_1047  1
    load_1_15_13  free_load_conservation_1211  -1
    load_1_15_13  free_load_conservation_1223  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_14  arc_capacity_1049  -25
    arc_1_15_14  connected_order_arc_1050  -13
    arc_1_15_14  in_degree_1213  1
    arc_1_15_14  out_degree_1218  1
    arc_1_15_14  original_T_including_depot_unload_1257  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_14  arc_capacity_1049  1
    load_1_15_14  free_load_conservation_1217  -1
    load_1_15_14  free_load_conservation_1223  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_16  arc_capacity_1051  -25
    arc_1_15_16  connected_order_arc_1052  -13
    arc_1_15_16  out_degree_1218  1
    arc_1_15_16  in_degree_1225  1
    arc_1_15_16  original_T_including_depot_unload_1257  1.5184659007075070e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_16  arc_capacity_1051  1
    load_1_15_16  free_load_conservation_1223  1
    load_1_15_16  free_load_conservation_1229  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_17  arc_capacity_1053  -25
    arc_1_15_17  connected_order_arc_1054  -13
    arc_1_15_17  out_degree_1218  1
    arc_1_15_17  in_degree_1231  1
    arc_1_15_17  original_T_including_depot_unload_1257  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_17  arc_capacity_1053  1
    load_1_15_17  free_load_conservation_1223  1
    load_1_15_17  free_load_conservation_1235  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_18  arc_capacity_1055  -25
    arc_1_15_18  connected_order_arc_1056  -13
    arc_1_15_18  out_degree_1218  1
    arc_1_15_18  in_degree_1237  1
    arc_1_15_18  original_T_including_depot_unload_1257  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_18  arc_capacity_1055  1
    load_1_15_18  free_load_conservation_1223  1
    load_1_15_18  free_load_conservation_1241  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_19  arc_capacity_1057  -25
    arc_1_15_19  connected_order_arc_1058  -13
    arc_1_15_19  out_degree_1218  1
    arc_1_15_19  in_degree_1243  1
    arc_1_15_19  original_T_including_depot_unload_1257  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_19  arc_capacity_1057  1
    load_1_15_19  free_load_conservation_1223  1
    load_1_15_19  free_load_conservation_1247  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_20  arc_capacity_1059  -25
    arc_1_15_20  connected_order_arc_1060  -13
    arc_1_15_20  out_degree_1218  1
    arc_1_15_20  in_degree_1249  1
    arc_1_15_20  original_T_including_depot_unload_1257  1.7303231472353602e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_20  arc_capacity_1059  1
    load_1_15_20  free_load_conservation_1223  1
    load_1_15_20  free_load_conservation_1253  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_0  arc_capacity_1061  -25
    arc_1_16_0  depot_return_or_bypass_1177  1
    arc_1_16_0  out_degree_1224  1
    arc_1_16_0  original_T_including_depot_unload_1257  4.9403722507151832e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_0  arc_capacity_1061  1
    load_1_16_0  free_load_conservation_1229  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_6  arc_capacity_1062  -25
    arc_1_16_6  connected_order_arc_1063  -13
    arc_1_16_6  in_degree_1179  1
    arc_1_16_6  out_degree_1224  1
    arc_1_16_6  original_T_including_depot_unload_1257  1.1017171222416982e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_6  arc_capacity_1062  1
    load_1_16_6  segment_load_conservation_1182  -1
    load_1_16_6  segment_prefix_lb_1183  1
    load_1_16_6  segment_prefix_ub_1184  1
    load_1_16_6  free_load_conservation_1229  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_7  arc_capacity_1064  -25
    arc_1_16_7  connected_order_arc_1065  -13
    arc_1_16_7  in_degree_1186  1
    arc_1_16_7  out_degree_1224  1
    arc_1_16_7  original_T_including_depot_unload_1257  1.2434091529834902e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_7  arc_capacity_1064  1
    load_1_16_7  segment_load_conservation_1189  -1
    load_1_16_7  segment_prefix_lb_1190  1
    load_1_16_7  segment_prefix_ub_1191  1
    load_1_16_7  free_load_conservation_1229  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_8  arc_capacity_1066  -25
    arc_1_16_8  connected_order_arc_1067  -13
    arc_1_16_8  in_degree_1193  1
    arc_1_16_8  out_degree_1224  1
    arc_1_16_8  original_T_including_depot_unload_1257  1.1768203711166027e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_8  arc_capacity_1066  1
    load_1_16_8  segment_load_conservation_1196  -1
    load_1_16_8  segment_prefix_lb_1197  1
    load_1_16_8  segment_prefix_ub_1198  1
    load_1_16_8  free_load_conservation_1229  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_9  arc_capacity_1068  -25
    arc_1_16_9  connected_order_arc_1069  -13
    arc_1_16_9  in_degree_1200  1
    arc_1_16_9  out_degree_1224  1
    arc_1_16_9  original_T_including_depot_unload_1257  3.7315439746742123e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_9  arc_capacity_1068  1
    load_1_16_9  segment_load_conservation_1203  -1
    load_1_16_9  segment_prefix_lb_1204  1
    load_1_16_9  segment_prefix_ub_1205  1
    load_1_16_9  free_load_conservation_1229  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_13  arc_capacity_1070  -25
    arc_1_16_13  connected_order_arc_1071  -13
    arc_1_16_13  in_degree_1207  1
    arc_1_16_13  out_degree_1224  1
    arc_1_16_13  original_T_including_depot_unload_1257  2.3159636865750136e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_13  arc_capacity_1070  1
    load_1_16_13  free_load_conservation_1211  -1
    load_1_16_13  free_load_conservation_1229  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_14  arc_capacity_1072  -25
    arc_1_16_14  connected_order_arc_1073  -13
    arc_1_16_14  in_degree_1213  1
    arc_1_16_14  out_degree_1224  1
    arc_1_16_14  original_T_including_depot_unload_1257  3.4754938304534517e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_14  arc_capacity_1072  1
    load_1_16_14  free_load_conservation_1217  -1
    load_1_16_14  free_load_conservation_1229  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_15  arc_capacity_1074  -25
    arc_1_16_15  connected_order_arc_1075  -13
    arc_1_16_15  in_degree_1219  1
    arc_1_16_15  out_degree_1224  1
    arc_1_16_15  original_T_including_depot_unload_1257  1.5184659007075070e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_15  arc_capacity_1074  1
    load_1_16_15  free_load_conservation_1223  -1
    load_1_16_15  free_load_conservation_1229  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_17  arc_capacity_1076  -25
    arc_1_16_17  connected_order_arc_1077  -13
    arc_1_16_17  out_degree_1224  1
    arc_1_16_17  in_degree_1231  1
    arc_1_16_17  original_T_including_depot_unload_1257  1.8073464544423741e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_17  arc_capacity_1076  1
    load_1_16_17  free_load_conservation_1229  1
    load_1_16_17  free_load_conservation_1235  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_18  arc_capacity_1078  -25
    arc_1_16_18  connected_order_arc_1079  -13
    arc_1_16_18  out_degree_1224  1
    arc_1_16_18  in_degree_1237  1
    arc_1_16_18  original_T_including_depot_unload_1257  2.2271784981792140e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_18  arc_capacity_1078  1
    load_1_16_18  free_load_conservation_1229  1
    load_1_16_18  free_load_conservation_1241  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_19  arc_capacity_1080  -25
    arc_1_16_19  connected_order_arc_1081  -13
    arc_1_16_19  out_degree_1224  1
    arc_1_16_19  in_degree_1243  1
    arc_1_16_19  original_T_including_depot_unload_1257  1.1562172312295786e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_19  arc_capacity_1080  1
    load_1_16_19  free_load_conservation_1229  1
    load_1_16_19  free_load_conservation_1247  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_20  arc_capacity_1082  -25
    arc_1_16_20  connected_order_arc_1083  -13
    arc_1_16_20  out_degree_1224  1
    arc_1_16_20  in_degree_1249  1
    arc_1_16_20  original_T_including_depot_unload_1257  2.2729932910497158e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_20  arc_capacity_1082  1
    load_1_16_20  free_load_conservation_1229  1
    load_1_16_20  free_load_conservation_1253  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_0  arc_capacity_1084  -25
    arc_1_17_0  depot_return_or_bypass_1177  1
    arc_1_17_0  out_degree_1230  1
    arc_1_17_0  original_T_including_depot_unload_1257  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_0  arc_capacity_1084  1
    load_1_17_0  free_load_conservation_1235  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_6  arc_capacity_1085  -25
    arc_1_17_6  connected_order_arc_1086  -13
    arc_1_17_6  in_degree_1179  1
    arc_1_17_6  out_degree_1230  1
    arc_1_17_6  original_T_including_depot_unload_1257  1.8442669473423912e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_6  arc_capacity_1085  1
    load_1_17_6  segment_load_conservation_1182  -1
    load_1_17_6  segment_prefix_lb_1183  1
    load_1_17_6  segment_prefix_ub_1184  1
    load_1_17_6  free_load_conservation_1235  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_7  arc_capacity_1087  -25
    arc_1_17_7  connected_order_arc_1088  -13
    arc_1_17_7  in_degree_1186  1
    arc_1_17_7  out_degree_1230  1
    arc_1_17_7  original_T_including_depot_unload_1257  1.5502221880497036e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_7  arc_capacity_1087  1
    load_1_17_7  segment_load_conservation_1189  -1
    load_1_17_7  segment_prefix_lb_1190  1
    load_1_17_7  segment_prefix_ub_1191  1
    load_1_17_7  free_load_conservation_1235  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_8  arc_capacity_1089  -25
    arc_1_17_8  connected_order_arc_1090  -13
    arc_1_17_8  in_degree_1193  1
    arc_1_17_8  out_degree_1230  1
    arc_1_17_8  original_T_including_depot_unload_1257  2.0104743468619281e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_8  arc_capacity_1089  1
    load_1_17_8  segment_load_conservation_1196  -1
    load_1_17_8  segment_prefix_lb_1197  1
    load_1_17_8  segment_prefix_ub_1198  1
    load_1_17_8  free_load_conservation_1235  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_9  arc_capacity_1091  -25
    arc_1_17_9  connected_order_arc_1092  -13
    arc_1_17_9  in_degree_1200  1
    arc_1_17_9  out_degree_1230  1
    arc_1_17_9  original_T_including_depot_unload_1257  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_9  arc_capacity_1091  1
    load_1_17_9  segment_load_conservation_1203  -1
    load_1_17_9  segment_prefix_lb_1204  1
    load_1_17_9  segment_prefix_ub_1205  1
    load_1_17_9  free_load_conservation_1235  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_13  arc_capacity_1093  -25
    arc_1_17_13  connected_order_arc_1094  -13
    arc_1_17_13  in_degree_1207  1
    arc_1_17_13  out_degree_1230  1
    arc_1_17_13  original_T_including_depot_unload_1257  1.7249161387293191e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_13  arc_capacity_1093  1
    load_1_17_13  free_load_conservation_1211  -1
    load_1_17_13  free_load_conservation_1235  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_14  arc_capacity_1095  -25
    arc_1_17_14  connected_order_arc_1096  -13
    arc_1_17_14  in_degree_1213  1
    arc_1_17_14  out_degree_1230  1
    arc_1_17_14  original_T_including_depot_unload_1257  1.5530568652263394e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_14  arc_capacity_1095  1
    load_1_17_14  free_load_conservation_1217  -1
    load_1_17_14  free_load_conservation_1235  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_15  arc_capacity_1097  -25
    arc_1_17_15  connected_order_arc_1098  -13
    arc_1_17_15  in_degree_1219  1
    arc_1_17_15  out_degree_1230  1
    arc_1_17_15  original_T_including_depot_unload_1257  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_15  arc_capacity_1097  1
    load_1_17_15  free_load_conservation_1223  -1
    load_1_17_15  free_load_conservation_1235  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_16  arc_capacity_1099  -25
    arc_1_17_16  connected_order_arc_1100  -13
    arc_1_17_16  in_degree_1225  1
    arc_1_17_16  out_degree_1230  1
    arc_1_17_16  original_T_including_depot_unload_1257  1.8073464544423741e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_16  arc_capacity_1099  1
    load_1_17_16  free_load_conservation_1229  -1
    load_1_17_16  free_load_conservation_1235  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_18  arc_capacity_1101  -25
    arc_1_17_18  connected_order_arc_1102  -13
    arc_1_17_18  out_degree_1230  1
    arc_1_17_18  in_degree_1237  1
    arc_1_17_18  original_T_including_depot_unload_1257  1.5902582434549993e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_18  arc_capacity_1101  1
    load_1_17_18  free_load_conservation_1235  1
    load_1_17_18  free_load_conservation_1241  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_19  arc_capacity_1103  -25
    arc_1_17_19  connected_order_arc_1104  -13
    arc_1_17_19  out_degree_1230  1
    arc_1_17_19  in_degree_1243  1
    arc_1_17_19  original_T_including_depot_unload_1257  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_19  arc_capacity_1103  1
    load_1_17_19  free_load_conservation_1235  1
    load_1_17_19  free_load_conservation_1247  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_20  arc_capacity_1105  -25
    arc_1_17_20  connected_order_arc_1106  -13
    arc_1_17_20  out_degree_1230  1
    arc_1_17_20  in_degree_1249  1
    arc_1_17_20  original_T_including_depot_unload_1257  2.0162129512771592e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_20  arc_capacity_1105  1
    load_1_17_20  free_load_conservation_1235  1
    load_1_17_20  free_load_conservation_1253  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_0  arc_capacity_1107  -25
    arc_1_18_0  depot_return_or_bypass_1177  1
    arc_1_18_0  out_degree_1236  1
    arc_1_18_0  original_T_including_depot_unload_1257  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_0  arc_capacity_1107  1
    load_1_18_0  free_load_conservation_1241  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_6  arc_capacity_1108  -25
    arc_1_18_6  connected_order_arc_1109  -13
    arc_1_18_6  in_degree_1179  1
    arc_1_18_6  out_degree_1236  1
    arc_1_18_6  original_T_including_depot_unload_1257  1.0170488276971105e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_6  arc_capacity_1108  1
    load_1_18_6  segment_load_conservation_1182  -1
    load_1_18_6  segment_prefix_lb_1183  1
    load_1_18_6  segment_prefix_ub_1184  1
    load_1_18_6  free_load_conservation_1241  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_7  arc_capacity_1110  -25
    arc_1_18_7  connected_order_arc_1111  -13
    arc_1_18_7  in_degree_1186  1
    arc_1_18_7  out_degree_1236  1
    arc_1_18_7  original_T_including_depot_unload_1257  1.0988088346747072e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_7  arc_capacity_1110  1
    load_1_18_7  segment_load_conservation_1189  -1
    load_1_18_7  segment_prefix_lb_1190  1
    load_1_18_7  segment_prefix_ub_1191  1
    load_1_18_7  free_load_conservation_1241  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_8  arc_capacity_1112  -25
    arc_1_18_8  connected_order_arc_1113  -13
    arc_1_18_8  in_degree_1193  1
    arc_1_18_8  out_degree_1236  1
    arc_1_18_8  original_T_including_depot_unload_1257  1.1190931627527086e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_8  arc_capacity_1112  1
    load_1_18_8  segment_load_conservation_1196  -1
    load_1_18_8  segment_prefix_lb_1197  1
    load_1_18_8  segment_prefix_ub_1198  1
    load_1_18_8  free_load_conservation_1241  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_9  arc_capacity_1114  -25
    arc_1_18_9  connected_order_arc_1115  -13
    arc_1_18_9  in_degree_1200  1
    arc_1_18_9  out_degree_1236  1
    arc_1_18_9  original_T_including_depot_unload_1257  4.5128490093732506e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_9  arc_capacity_1114  1
    load_1_18_9  segment_load_conservation_1203  -1
    load_1_18_9  segment_prefix_lb_1204  1
    load_1_18_9  segment_prefix_ub_1205  1
    load_1_18_9  free_load_conservation_1241  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_13  arc_capacity_1116  -25
    arc_1_18_13  connected_order_arc_1117  -13
    arc_1_18_13  in_degree_1207  1
    arc_1_18_13  out_degree_1236  1
    arc_1_18_13  original_T_including_depot_unload_1257  2.8529311190414518e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_13  arc_capacity_1116  1
    load_1_18_13  free_load_conservation_1211  -1
    load_1_18_13  free_load_conservation_1241  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_14  arc_capacity_1118  -25
    arc_1_18_14  connected_order_arc_1119  -13
    arc_1_18_14  in_degree_1213  1
    arc_1_18_14  out_degree_1236  1
    arc_1_18_14  original_T_including_depot_unload_1257  2.7078292664437623e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_14  arc_capacity_1118  1
    load_1_18_14  free_load_conservation_1217  -1
    load_1_18_14  free_load_conservation_1241  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_15  arc_capacity_1120  -25
    arc_1_18_15  connected_order_arc_1121  -13
    arc_1_18_15  in_degree_1219  1
    arc_1_18_15  out_degree_1236  1
    arc_1_18_15  original_T_including_depot_unload_1257  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_15  arc_capacity_1120  1
    load_1_18_15  free_load_conservation_1223  -1
    load_1_18_15  free_load_conservation_1241  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_16  arc_capacity_1122  -25
    arc_1_18_16  connected_order_arc_1123  -13
    arc_1_18_16  in_degree_1225  1
    arc_1_18_16  out_degree_1236  1
    arc_1_18_16  original_T_including_depot_unload_1257  2.2271784981792140e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_16  arc_capacity_1122  1
    load_1_18_16  free_load_conservation_1229  -1
    load_1_18_16  free_load_conservation_1241  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_17  arc_capacity_1124  -25
    arc_1_18_17  connected_order_arc_1125  -13
    arc_1_18_17  in_degree_1231  1
    arc_1_18_17  out_degree_1236  1
    arc_1_18_17  original_T_including_depot_unload_1257  1.5902582434549993e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_17  arc_capacity_1124  1
    load_1_18_17  free_load_conservation_1235  -1
    load_1_18_17  free_load_conservation_1241  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_19  arc_capacity_1126  -25
    arc_1_18_19  connected_order_arc_1127  -13
    arc_1_18_19  out_degree_1236  1
    arc_1_18_19  in_degree_1243  1
    arc_1_18_19  original_T_including_depot_unload_1257  9.3905252655669165e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_19  arc_capacity_1126  1
    load_1_18_19  free_load_conservation_1241  1
    load_1_18_19  free_load_conservation_1247  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_20  arc_capacity_1128  -25
    arc_1_18_20  connected_order_arc_1129  -13
    arc_1_18_20  out_degree_1236  1
    arc_1_18_20  in_degree_1249  1
    arc_1_18_20  original_T_including_depot_unload_1257  4.4733407106545638e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_20  arc_capacity_1128  1
    load_1_18_20  free_load_conservation_1241  1
    load_1_18_20  free_load_conservation_1253  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_0  arc_capacity_1130  -25
    arc_1_19_0  depot_return_or_bypass_1177  1
    arc_1_19_0  out_degree_1242  1
    arc_1_19_0  original_T_including_depot_unload_1257  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_0  arc_capacity_1130  1
    load_1_19_0  free_load_conservation_1247  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_6  arc_capacity_1131  -25
    arc_1_19_6  connected_order_arc_1132  -13
    arc_1_19_6  in_degree_1179  1
    arc_1_19_6  out_degree_1242  1
    arc_1_19_6  original_T_including_depot_unload_1257  1.3551088510632424e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_6  arc_capacity_1131  1
    load_1_19_6  segment_load_conservation_1182  -1
    load_1_19_6  segment_prefix_lb_1183  1
    load_1_19_6  segment_prefix_ub_1184  1
    load_1_19_6  free_load_conservation_1247  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_7  arc_capacity_1133  -25
    arc_1_19_7  connected_order_arc_1134  -13
    arc_1_19_7  in_degree_1186  1
    arc_1_19_7  out_degree_1242  1
    arc_1_19_7  original_T_including_depot_unload_1257  1.1479472058029019e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_7  arc_capacity_1133  1
    load_1_19_7  segment_load_conservation_1189  -1
    load_1_19_7  segment_prefix_lb_1190  1
    load_1_19_7  segment_prefix_ub_1191  1
    load_1_19_7  free_load_conservation_1247  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_8  arc_capacity_1135  -25
    arc_1_19_8  connected_order_arc_1136  -13
    arc_1_19_8  in_degree_1193  1
    arc_1_19_8  out_degree_1242  1
    arc_1_19_8  original_T_including_depot_unload_1257  1.5183735648810946e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_8  arc_capacity_1135  1
    load_1_19_8  segment_load_conservation_1196  -1
    load_1_19_8  segment_prefix_lb_1197  1
    load_1_19_8  segment_prefix_ub_1198  1
    load_1_19_8  free_load_conservation_1247  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_9  arc_capacity_1137  -25
    arc_1_19_9  connected_order_arc_1138  -13
    arc_1_19_9  in_degree_1200  1
    arc_1_19_9  out_degree_1242  1
    arc_1_19_9  original_T_including_depot_unload_1257  1.3127274783157229e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_9  arc_capacity_1137  1
    load_1_19_9  segment_load_conservation_1203  -1
    load_1_19_9  segment_prefix_lb_1204  1
    load_1_19_9  segment_prefix_ub_1205  1
    load_1_19_9  free_load_conservation_1247  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_13  arc_capacity_1139  -25
    arc_1_19_13  connected_order_arc_1140  -13
    arc_1_19_13  in_degree_1207  1
    arc_1_19_13  out_degree_1242  1
    arc_1_19_13  original_T_including_depot_unload_1257  1.0838347754693179e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_13  arc_capacity_1139  1
    load_1_19_13  free_load_conservation_1211  -1
    load_1_19_13  free_load_conservation_1247  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_14  arc_capacity_1141  -25
    arc_1_19_14  connected_order_arc_1142  -13
    arc_1_19_14  in_degree_1213  1
    arc_1_19_14  out_degree_1242  1
    arc_1_19_14  original_T_including_depot_unload_1257  9.1580557259044724e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_14  arc_capacity_1141  1
    load_1_19_14  free_load_conservation_1217  -1
    load_1_19_14  free_load_conservation_1247  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_15  arc_capacity_1143  -25
    arc_1_19_15  connected_order_arc_1144  -13
    arc_1_19_15  in_degree_1219  1
    arc_1_19_15  out_degree_1242  1
    arc_1_19_15  original_T_including_depot_unload_1257  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_15  arc_capacity_1143  1
    load_1_19_15  free_load_conservation_1223  -1
    load_1_19_15  free_load_conservation_1247  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_16  arc_capacity_1145  -25
    arc_1_19_16  connected_order_arc_1146  -13
    arc_1_19_16  in_degree_1225  1
    arc_1_19_16  out_degree_1242  1
    arc_1_19_16  original_T_including_depot_unload_1257  1.1562172312295786e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_16  arc_capacity_1145  1
    load_1_19_16  free_load_conservation_1229  -1
    load_1_19_16  free_load_conservation_1247  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_17  arc_capacity_1147  -25
    arc_1_19_17  connected_order_arc_1148  -13
    arc_1_19_17  in_degree_1231  1
    arc_1_19_17  out_degree_1242  1
    arc_1_19_17  original_T_including_depot_unload_1257  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_17  arc_capacity_1147  1
    load_1_19_17  free_load_conservation_1235  -1
    load_1_19_17  free_load_conservation_1247  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_18  arc_capacity_1149  -25
    arc_1_19_18  connected_order_arc_1150  -13
    arc_1_19_18  in_degree_1237  1
    arc_1_19_18  out_degree_1242  1
    arc_1_19_18  original_T_including_depot_unload_1257  9.3905252655669165e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_18  arc_capacity_1149  1
    load_1_19_18  free_load_conservation_1241  -1
    load_1_19_18  free_load_conservation_1247  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_20  arc_capacity_1151  -25
    arc_1_19_20  connected_order_arc_1152  -13
    arc_1_19_20  out_degree_1242  1
    arc_1_19_20  in_degree_1249  1
    arc_1_19_20  original_T_including_depot_unload_1257  1.3669225770244122e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_20  arc_capacity_1151  1
    load_1_19_20  free_load_conservation_1247  1
    load_1_19_20  free_load_conservation_1253  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_0  arc_capacity_1153  -25
    arc_1_20_0  depot_return_or_bypass_1177  1
    arc_1_20_0  out_degree_1248  1
    arc_1_20_0  original_T_including_depot_unload_1257  7.2130540230577469e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_0  arc_capacity_1153  1
    load_1_20_0  free_load_conservation_1253  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_6  arc_capacity_1154  -25
    arc_1_20_6  connected_order_arc_1155  -13
    arc_1_20_6  in_degree_1179  1
    arc_1_20_6  out_degree_1248  1
    arc_1_20_6  original_T_including_depot_unload_1257  1.2608023164150941e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_6  arc_capacity_1154  1
    load_1_20_6  segment_load_conservation_1182  -1
    load_1_20_6  segment_prefix_lb_1183  1
    load_1_20_6  segment_prefix_ub_1184  1
    load_1_20_6  free_load_conservation_1253  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_7  arc_capacity_1156  -25
    arc_1_20_7  connected_order_arc_1157  -13
    arc_1_20_7  in_degree_1186  1
    arc_1_20_7  out_degree_1248  1
    arc_1_20_7  original_T_including_depot_unload_1257  1.4394323281782954e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_7  arc_capacity_1156  1
    load_1_20_7  segment_load_conservation_1189  -1
    load_1_20_7  segment_prefix_lb_1190  1
    load_1_20_7  segment_prefix_ub_1191  1
    load_1_20_7  free_load_conservation_1253  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_8  arc_capacity_1158  -25
    arc_1_20_8  connected_order_arc_1159  -13
    arc_1_20_8  in_degree_1193  1
    arc_1_20_8  out_degree_1248  1
    arc_1_20_8  original_T_including_depot_unload_1257  1.3140724694688972e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_8  arc_capacity_1158  1
    load_1_20_8  segment_load_conservation_1196  -1
    load_1_20_8  segment_prefix_lb_1197  1
    load_1_20_8  segment_prefix_ub_1198  1
    load_1_20_8  free_load_conservation_1253  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_9  arc_capacity_1160  -25
    arc_1_20_9  connected_order_arc_1161  -13
    arc_1_20_9  in_degree_1200  1
    arc_1_20_9  out_degree_1248  1
    arc_1_20_9  original_T_including_depot_unload_1257  4.6128219015626763e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_9  arc_capacity_1160  1
    load_1_20_9  segment_load_conservation_1203  -1
    load_1_20_9  segment_prefix_lb_1204  1
    load_1_20_9  segment_prefix_ub_1205  1
    load_1_20_9  free_load_conservation_1253  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_13  arc_capacity_1162  -25
    arc_1_20_13  connected_order_arc_1163  -13
    arc_1_20_13  in_degree_1207  1
    arc_1_20_13  out_degree_1248  1
    arc_1_20_13  original_T_including_depot_unload_1257  3.2367117212973966e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_13  arc_capacity_1162  1
    load_1_20_13  free_load_conservation_1211  -1
    load_1_20_13  free_load_conservation_1253  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_14  arc_capacity_1164  -25
    arc_1_20_14  connected_order_arc_1165  -13
    arc_1_20_14  in_degree_1213  1
    arc_1_20_14  out_degree_1248  1
    arc_1_20_14  original_T_including_depot_unload_1257  4.9242827332511274e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_14  arc_capacity_1164  1
    load_1_20_14  free_load_conservation_1217  -1
    load_1_20_14  free_load_conservation_1253  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_15  arc_capacity_1166  -25
    arc_1_20_15  connected_order_arc_1167  -13
    arc_1_20_15  in_degree_1219  1
    arc_1_20_15  out_degree_1248  1
    arc_1_20_15  original_T_including_depot_unload_1257  1.7303231472353602e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_15  arc_capacity_1166  1
    load_1_20_15  free_load_conservation_1223  -1
    load_1_20_15  free_load_conservation_1253  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_16  arc_capacity_1168  -25
    arc_1_20_16  connected_order_arc_1169  -13
    arc_1_20_16  in_degree_1225  1
    arc_1_20_16  out_degree_1248  1
    arc_1_20_16  original_T_including_depot_unload_1257  2.2729932910497158e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_16  arc_capacity_1168  1
    load_1_20_16  free_load_conservation_1229  -1
    load_1_20_16  free_load_conservation_1253  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_17  arc_capacity_1170  -25
    arc_1_20_17  connected_order_arc_1171  -13
    arc_1_20_17  in_degree_1231  1
    arc_1_20_17  out_degree_1248  1
    arc_1_20_17  original_T_including_depot_unload_1257  2.0162129512771592e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_17  arc_capacity_1170  1
    load_1_20_17  free_load_conservation_1235  -1
    load_1_20_17  free_load_conservation_1253  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_18  arc_capacity_1172  -25
    arc_1_20_18  connected_order_arc_1173  -13
    arc_1_20_18  in_degree_1237  1
    arc_1_20_18  out_degree_1248  1
    arc_1_20_18  original_T_including_depot_unload_1257  4.4733407106545638e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_18  arc_capacity_1172  1
    load_1_20_18  free_load_conservation_1241  -1
    load_1_20_18  free_load_conservation_1253  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_19  arc_capacity_1174  -25
    arc_1_20_19  connected_order_arc_1175  -13
    arc_1_20_19  in_degree_1243  1
    arc_1_20_19  out_degree_1248  1
    arc_1_20_19  original_T_including_depot_unload_1257  1.3669225770244122e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_19  arc_capacity_1174  1
    load_1_20_19  free_load_conservation_1247  -1
    load_1_20_19  free_load_conservation_1253  1
    visit_2_10  out_degree_1503  -1
    visit_2_10  in_degree_1504  -1
    visit_2_10  order_active_lb_1505  -1
    visit_2_10  order_active_ub_1506  -11
    order_2_10  connected_order_arc_1272  -1
    order_2_10  connected_order_arc_1274  -1
    order_2_10  connected_order_arc_1276  -1
    order_2_10  connected_order_arc_1278  -1
    order_2_10  connected_order_arc_1280  -1
    order_2_10  connected_order_arc_1282  -1
    order_2_10  connected_order_arc_1284  -1
    order_2_10  connected_order_arc_1286  -1
    order_2_10  connected_order_arc_1288  -1
    order_2_10  connected_order_arc_1290  -1
    order_2_10  connected_order_arc_1293  1
    order_2_10  connected_order_arc_1314  1
    order_2_10  connected_order_arc_1335  1
    order_2_10  connected_order_arc_1356  1
    order_2_10  connected_order_arc_1377  1
    order_2_10  connected_order_arc_1398  1
    order_2_10  connected_order_arc_1419  1
    order_2_10  connected_order_arc_1440  1
    order_2_10  connected_order_arc_1461  1
    order_2_10  connected_order_arc_1482  1
    order_2_10  order_active_lb_1505  1
    order_2_10  order_active_ub_1506  1
    order_2_10  fixed_segment_relative_order_1572  -1
    visit_2_11  out_degree_1510  -1
    visit_2_11  in_degree_1511  -1
    visit_2_11  order_active_lb_1512  -1
    visit_2_11  order_active_ub_1513  -11
    order_2_11  connected_order_arc_1272  1
    order_2_11  connected_order_arc_1293  -1
    order_2_11  connected_order_arc_1295  -1
    order_2_11  connected_order_arc_1297  -1
    order_2_11  connected_order_arc_1299  -1
    order_2_11  connected_order_arc_1301  -1
    order_2_11  connected_order_arc_1303  -1
    order_2_11  connected_order_arc_1305  -1
    order_2_11  connected_order_arc_1307  -1
    order_2_11  connected_order_arc_1309  -1
    order_2_11  connected_order_arc_1311  -1
    order_2_11  connected_order_arc_1316  1
    order_2_11  connected_order_arc_1337  1
    order_2_11  connected_order_arc_1358  1
    order_2_11  connected_order_arc_1379  1
    order_2_11  connected_order_arc_1400  1
    order_2_11  connected_order_arc_1421  1
    order_2_11  connected_order_arc_1442  1
    order_2_11  connected_order_arc_1463  1
    order_2_11  connected_order_arc_1484  1
    order_2_11  order_active_lb_1512  1
    order_2_11  order_active_ub_1513  1
    order_2_11  fixed_segment_relative_order_1572  1
    order_2_11  fixed_segment_relative_order_1573  -1
    visit_2_12  out_degree_1517  -1
    visit_2_12  in_degree_1518  -1
    visit_2_12  order_active_lb_1519  -1
    visit_2_12  order_active_ub_1520  -11
    order_2_12  connected_order_arc_1274  1
    order_2_12  connected_order_arc_1295  1
    order_2_12  connected_order_arc_1314  -1
    order_2_12  connected_order_arc_1316  -1
    order_2_12  connected_order_arc_1318  -1
    order_2_12  connected_order_arc_1320  -1
    order_2_12  connected_order_arc_1322  -1
    order_2_12  connected_order_arc_1324  -1
    order_2_12  connected_order_arc_1326  -1
    order_2_12  connected_order_arc_1328  -1
    order_2_12  connected_order_arc_1330  -1
    order_2_12  connected_order_arc_1332  -1
    order_2_12  connected_order_arc_1339  1
    order_2_12  connected_order_arc_1360  1
    order_2_12  connected_order_arc_1381  1
    order_2_12  connected_order_arc_1402  1
    order_2_12  connected_order_arc_1423  1
    order_2_12  connected_order_arc_1444  1
    order_2_12  connected_order_arc_1465  1
    order_2_12  connected_order_arc_1486  1
    order_2_12  order_active_lb_1519  1
    order_2_12  order_active_ub_1520  1
    order_2_12  fixed_segment_relative_order_1573  1
    visit_2_13  out_degree_1524  -1
    visit_2_13  in_degree_1525  -1
    visit_2_13  order_active_lb_1526  -1
    visit_2_13  order_active_ub_1527  -11
    visit_2_13  service_visit_def_1528  -1
    order_2_13  connected_order_arc_1276  1
    order_2_13  connected_order_arc_1297  1
    order_2_13  connected_order_arc_1318  1
    order_2_13  connected_order_arc_1335  -1
    order_2_13  connected_order_arc_1337  -1
    order_2_13  connected_order_arc_1339  -1
    order_2_13  connected_order_arc_1341  -1
    order_2_13  connected_order_arc_1343  -1
    order_2_13  connected_order_arc_1345  -1
    order_2_13  connected_order_arc_1347  -1
    order_2_13  connected_order_arc_1349  -1
    order_2_13  connected_order_arc_1351  -1
    order_2_13  connected_order_arc_1353  -1
    order_2_13  connected_order_arc_1362  1
    order_2_13  connected_order_arc_1383  1
    order_2_13  connected_order_arc_1404  1
    order_2_13  connected_order_arc_1425  1
    order_2_13  connected_order_arc_1446  1
    order_2_13  connected_order_arc_1467  1
    order_2_13  connected_order_arc_1488  1
    order_2_13  order_active_lb_1526  1
    order_2_13  order_active_ub_1527  1
    visit_2_14  out_degree_1530  -1
    visit_2_14  in_degree_1531  -1
    visit_2_14  order_active_lb_1532  -1
    visit_2_14  order_active_ub_1533  -11
    visit_2_14  service_visit_def_1534  -1
    order_2_14  connected_order_arc_1278  1
    order_2_14  connected_order_arc_1299  1
    order_2_14  connected_order_arc_1320  1
    order_2_14  connected_order_arc_1341  1
    order_2_14  connected_order_arc_1356  -1
    order_2_14  connected_order_arc_1358  -1
    order_2_14  connected_order_arc_1360  -1
    order_2_14  connected_order_arc_1362  -1
    order_2_14  connected_order_arc_1364  -1
    order_2_14  connected_order_arc_1366  -1
    order_2_14  connected_order_arc_1368  -1
    order_2_14  connected_order_arc_1370  -1
    order_2_14  connected_order_arc_1372  -1
    order_2_14  connected_order_arc_1374  -1
    order_2_14  connected_order_arc_1385  1
    order_2_14  connected_order_arc_1406  1
    order_2_14  connected_order_arc_1427  1
    order_2_14  connected_order_arc_1448  1
    order_2_14  connected_order_arc_1469  1
    order_2_14  connected_order_arc_1490  1
    order_2_14  order_active_lb_1532  1
    order_2_14  order_active_ub_1533  1
    visit_2_15  out_degree_1536  -1
    visit_2_15  in_degree_1537  -1
    visit_2_15  order_active_lb_1538  -1
    visit_2_15  order_active_ub_1539  -11
    visit_2_15  service_visit_def_1540  -1
    order_2_15  connected_order_arc_1280  1
    order_2_15  connected_order_arc_1301  1
    order_2_15  connected_order_arc_1322  1
    order_2_15  connected_order_arc_1343  1
    order_2_15  connected_order_arc_1364  1
    order_2_15  connected_order_arc_1377  -1
    order_2_15  connected_order_arc_1379  -1
    order_2_15  connected_order_arc_1381  -1
    order_2_15  connected_order_arc_1383  -1
    order_2_15  connected_order_arc_1385  -1
    order_2_15  connected_order_arc_1387  -1
    order_2_15  connected_order_arc_1389  -1
    order_2_15  connected_order_arc_1391  -1
    order_2_15  connected_order_arc_1393  -1
    order_2_15  connected_order_arc_1395  -1
    order_2_15  connected_order_arc_1408  1
    order_2_15  connected_order_arc_1429  1
    order_2_15  connected_order_arc_1450  1
    order_2_15  connected_order_arc_1471  1
    order_2_15  connected_order_arc_1492  1
    order_2_15  order_active_lb_1538  1
    order_2_15  order_active_ub_1539  1
    visit_2_16  out_degree_1542  -1
    visit_2_16  in_degree_1543  -1
    visit_2_16  order_active_lb_1544  -1
    visit_2_16  order_active_ub_1545  -11
    visit_2_16  service_visit_def_1546  -1
    order_2_16  connected_order_arc_1282  1
    order_2_16  connected_order_arc_1303  1
    order_2_16  connected_order_arc_1324  1
    order_2_16  connected_order_arc_1345  1
    order_2_16  connected_order_arc_1366  1
    order_2_16  connected_order_arc_1387  1
    order_2_16  connected_order_arc_1398  -1
    order_2_16  connected_order_arc_1400  -1
    order_2_16  connected_order_arc_1402  -1
    order_2_16  connected_order_arc_1404  -1
    order_2_16  connected_order_arc_1406  -1
    order_2_16  connected_order_arc_1408  -1
    order_2_16  connected_order_arc_1410  -1
    order_2_16  connected_order_arc_1412  -1
    order_2_16  connected_order_arc_1414  -1
    order_2_16  connected_order_arc_1416  -1
    order_2_16  connected_order_arc_1431  1
    order_2_16  connected_order_arc_1452  1
    order_2_16  connected_order_arc_1473  1
    order_2_16  connected_order_arc_1494  1
    order_2_16  order_active_lb_1544  1
    order_2_16  order_active_ub_1545  1
    visit_2_17  out_degree_1548  -1
    visit_2_17  in_degree_1549  -1
    visit_2_17  order_active_lb_1550  -1
    visit_2_17  order_active_ub_1551  -11
    visit_2_17  service_visit_def_1552  -1
    order_2_17  connected_order_arc_1284  1
    order_2_17  connected_order_arc_1305  1
    order_2_17  connected_order_arc_1326  1
    order_2_17  connected_order_arc_1347  1
    order_2_17  connected_order_arc_1368  1
    order_2_17  connected_order_arc_1389  1
    order_2_17  connected_order_arc_1410  1
    order_2_17  connected_order_arc_1419  -1
    order_2_17  connected_order_arc_1421  -1
    order_2_17  connected_order_arc_1423  -1
    order_2_17  connected_order_arc_1425  -1
    order_2_17  connected_order_arc_1427  -1
    order_2_17  connected_order_arc_1429  -1
    order_2_17  connected_order_arc_1431  -1
    order_2_17  connected_order_arc_1433  -1
    order_2_17  connected_order_arc_1435  -1
    order_2_17  connected_order_arc_1437  -1
    order_2_17  connected_order_arc_1454  1
    order_2_17  connected_order_arc_1475  1
    order_2_17  connected_order_arc_1496  1
    order_2_17  order_active_lb_1550  1
    order_2_17  order_active_ub_1551  1
    visit_2_18  out_degree_1554  -1
    visit_2_18  in_degree_1555  -1
    visit_2_18  order_active_lb_1556  -1
    visit_2_18  order_active_ub_1557  -11
    visit_2_18  service_visit_def_1558  -1
    order_2_18  connected_order_arc_1286  1
    order_2_18  connected_order_arc_1307  1
    order_2_18  connected_order_arc_1328  1
    order_2_18  connected_order_arc_1349  1
    order_2_18  connected_order_arc_1370  1
    order_2_18  connected_order_arc_1391  1
    order_2_18  connected_order_arc_1412  1
    order_2_18  connected_order_arc_1433  1
    order_2_18  connected_order_arc_1440  -1
    order_2_18  connected_order_arc_1442  -1
    order_2_18  connected_order_arc_1444  -1
    order_2_18  connected_order_arc_1446  -1
    order_2_18  connected_order_arc_1448  -1
    order_2_18  connected_order_arc_1450  -1
    order_2_18  connected_order_arc_1452  -1
    order_2_18  connected_order_arc_1454  -1
    order_2_18  connected_order_arc_1456  -1
    order_2_18  connected_order_arc_1458  -1
    order_2_18  connected_order_arc_1477  1
    order_2_18  connected_order_arc_1498  1
    order_2_18  order_active_lb_1556  1
    order_2_18  order_active_ub_1557  1
    visit_2_19  out_degree_1560  -1
    visit_2_19  in_degree_1561  -1
    visit_2_19  order_active_lb_1562  -1
    visit_2_19  order_active_ub_1563  -11
    visit_2_19  service_visit_def_1564  -1
    order_2_19  connected_order_arc_1288  1
    order_2_19  connected_order_arc_1309  1
    order_2_19  connected_order_arc_1330  1
    order_2_19  connected_order_arc_1351  1
    order_2_19  connected_order_arc_1372  1
    order_2_19  connected_order_arc_1393  1
    order_2_19  connected_order_arc_1414  1
    order_2_19  connected_order_arc_1435  1
    order_2_19  connected_order_arc_1456  1
    order_2_19  connected_order_arc_1461  -1
    order_2_19  connected_order_arc_1463  -1
    order_2_19  connected_order_arc_1465  -1
    order_2_19  connected_order_arc_1467  -1
    order_2_19  connected_order_arc_1469  -1
    order_2_19  connected_order_arc_1471  -1
    order_2_19  connected_order_arc_1473  -1
    order_2_19  connected_order_arc_1475  -1
    order_2_19  connected_order_arc_1477  -1
    order_2_19  connected_order_arc_1479  -1
    order_2_19  connected_order_arc_1500  1
    order_2_19  order_active_lb_1562  1
    order_2_19  order_active_ub_1563  1
    visit_2_20  out_degree_1566  -1
    visit_2_20  in_degree_1567  -1
    visit_2_20  order_active_lb_1568  -1
    visit_2_20  order_active_ub_1569  -11
    visit_2_20  service_visit_def_1570  -1
    order_2_20  connected_order_arc_1290  1
    order_2_20  connected_order_arc_1311  1
    order_2_20  connected_order_arc_1332  1
    order_2_20  connected_order_arc_1353  1
    order_2_20  connected_order_arc_1374  1
    order_2_20  connected_order_arc_1395  1
    order_2_20  connected_order_arc_1416  1
    order_2_20  connected_order_arc_1437  1
    order_2_20  connected_order_arc_1458  1
    order_2_20  connected_order_arc_1479  1
    order_2_20  connected_order_arc_1482  -1
    order_2_20  connected_order_arc_1484  -1
    order_2_20  connected_order_arc_1486  -1
    order_2_20  connected_order_arc_1488  -1
    order_2_20  connected_order_arc_1490  -1
    order_2_20  connected_order_arc_1492  -1
    order_2_20  connected_order_arc_1494  -1
    order_2_20  connected_order_arc_1496  -1
    order_2_20  connected_order_arc_1498  -1
    order_2_20  connected_order_arc_1500  -1
    order_2_20  order_active_lb_1568  1
    order_2_20  order_active_ub_1569  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_0  arc_capacity_1258  -30
    arc_2_0_0  depot_departure_or_bypass_1501  1
    arc_2_0_0  depot_return_or_bypass_1502  1
    MARKER    'MARKER'                 'INTEND'
    load_2_0_0  arc_capacity_1258  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_10  arc_capacity_1259  -30
    arc_2_0_10  depot_departure_or_bypass_1501  1
    arc_2_0_10  in_degree_1504  1
    arc_2_0_10  original_T_including_depot_unload_1574  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_10  arc_capacity_1259  1
    load_2_0_10  segment_load_conservation_1507  -1
    load_2_0_10  segment_prefix_lb_1508  1
    load_2_0_10  segment_prefix_ub_1509  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_11  arc_capacity_1260  -30
    arc_2_0_11  depot_departure_or_bypass_1501  1
    arc_2_0_11  in_degree_1511  1
    arc_2_0_11  original_T_including_depot_unload_1574  1.2898901502795654e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_11  arc_capacity_1260  1
    load_2_0_11  segment_load_conservation_1514  -1
    load_2_0_11  segment_prefix_lb_1515  1
    load_2_0_11  segment_prefix_ub_1516  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_12  arc_capacity_1261  -30
    arc_2_0_12  depot_departure_or_bypass_1501  1
    arc_2_0_12  in_degree_1518  1
    arc_2_0_12  original_T_including_depot_unload_1574  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_12  arc_capacity_1261  1
    load_2_0_12  segment_load_conservation_1521  -1
    load_2_0_12  segment_prefix_lb_1522  1
    load_2_0_12  segment_prefix_ub_1523  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_13  arc_capacity_1262  -30
    arc_2_0_13  depot_departure_or_bypass_1501  1
    arc_2_0_13  in_degree_1525  1
    arc_2_0_13  original_T_including_depot_unload_1574  5.4249700630778887e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_13  arc_capacity_1262  1
    load_2_0_13  free_load_conservation_1529  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_14  arc_capacity_1263  -30
    arc_2_0_14  depot_departure_or_bypass_1501  1
    arc_2_0_14  in_degree_1531  1
    arc_2_0_14  original_T_including_depot_unload_1574  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_14  arc_capacity_1263  1
    load_2_0_14  free_load_conservation_1535  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_15  arc_capacity_1264  -30
    arc_2_0_15  depot_departure_or_bypass_1501  1
    arc_2_0_15  in_degree_1537  1
    arc_2_0_15  original_T_including_depot_unload_1574  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_15  arc_capacity_1264  1
    load_2_0_15  free_load_conservation_1541  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_16  arc_capacity_1265  -30
    arc_2_0_16  depot_departure_or_bypass_1501  1
    arc_2_0_16  in_degree_1543  1
    arc_2_0_16  original_T_including_depot_unload_1574  4.9403722507151832e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_16  arc_capacity_1265  1
    load_2_0_16  free_load_conservation_1547  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_17  arc_capacity_1266  -30
    arc_2_0_17  depot_departure_or_bypass_1501  1
    arc_2_0_17  in_degree_1549  1
    arc_2_0_17  original_T_including_depot_unload_1574  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_17  arc_capacity_1266  1
    load_2_0_17  free_load_conservation_1553  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_18  arc_capacity_1267  -30
    arc_2_0_18  depot_departure_or_bypass_1501  1
    arc_2_0_18  in_degree_1555  1
    arc_2_0_18  original_T_including_depot_unload_1574  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_18  arc_capacity_1267  1
    load_2_0_18  free_load_conservation_1559  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_19  arc_capacity_1268  -30
    arc_2_0_19  depot_departure_or_bypass_1501  1
    arc_2_0_19  in_degree_1561  1
    arc_2_0_19  original_T_including_depot_unload_1574  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_19  arc_capacity_1268  1
    load_2_0_19  free_load_conservation_1565  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_20  arc_capacity_1269  -30
    arc_2_0_20  depot_departure_or_bypass_1501  1
    arc_2_0_20  in_degree_1567  1
    arc_2_0_20  original_T_including_depot_unload_1574  7.2130540230577469e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_20  arc_capacity_1269  1
    load_2_0_20  free_load_conservation_1571  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_0  arc_capacity_1270  -30
    arc_2_10_0  depot_return_or_bypass_1502  1
    arc_2_10_0  out_degree_1503  1
    arc_2_10_0  original_T_including_depot_unload_1574  9.5330620720858735e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_0  arc_capacity_1270  1
    load_2_10_0  segment_load_conservation_1507  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_11  arc_capacity_1271  -30
    arc_2_10_11  connected_order_arc_1272  -12
    arc_2_10_11  out_degree_1503  1
    arc_2_10_11  in_degree_1511  1
    arc_2_10_11  original_T_including_depot_unload_1574  1.5797541979515834e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_11  arc_capacity_1271  1
    load_2_10_11  segment_load_conservation_1507  1
    load_2_10_11  segment_load_conservation_1514  -1
    load_2_10_11  segment_prefix_lb_1515  1
    load_2_10_11  segment_prefix_ub_1516  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_12  arc_capacity_1273  -30
    arc_2_10_12  connected_order_arc_1274  -12
    arc_2_10_12  out_degree_1503  1
    arc_2_10_12  in_degree_1518  1
    arc_2_10_12  original_T_including_depot_unload_1574  1.0783470469841145e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_12  arc_capacity_1273  1
    load_2_10_12  segment_load_conservation_1507  1
    load_2_10_12  segment_load_conservation_1521  -1
    load_2_10_12  segment_prefix_lb_1522  1
    load_2_10_12  segment_prefix_ub_1523  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_13  arc_capacity_1275  -30
    arc_2_10_13  connected_order_arc_1276  -12
    arc_2_10_13  out_degree_1503  1
    arc_2_10_13  in_degree_1525  1
    arc_2_10_13  original_T_including_depot_unload_1574  6.7711923781893620e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_13  arc_capacity_1275  1
    load_2_10_13  segment_load_conservation_1507  1
    load_2_10_13  free_load_conservation_1529  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_14  arc_capacity_1277  -30
    arc_2_10_14  connected_order_arc_1278  -12
    arc_2_10_14  out_degree_1503  1
    arc_2_10_14  in_degree_1531  1
    arc_2_10_14  original_T_including_depot_unload_1574  5.8292761965990132e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_14  arc_capacity_1277  1
    load_2_10_14  segment_load_conservation_1507  1
    load_2_10_14  free_load_conservation_1535  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_15  arc_capacity_1279  -30
    arc_2_10_15  connected_order_arc_1280  -12
    arc_2_10_15  out_degree_1503  1
    arc_2_10_15  in_degree_1537  1
    arc_2_10_15  original_T_including_depot_unload_1574  1.9462564869425171e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_15  arc_capacity_1279  1
    load_2_10_15  segment_load_conservation_1507  1
    load_2_10_15  free_load_conservation_1541  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_16  arc_capacity_1281  -30
    arc_2_10_16  connected_order_arc_1282  -12
    arc_2_10_16  out_degree_1503  1
    arc_2_10_16  in_degree_1543  1
    arc_2_10_16  original_T_including_depot_unload_1574  904.837890445026
    MARKER    'MARKER'                 'INTEND'
    load_2_10_16  arc_capacity_1281  1
    load_2_10_16  segment_load_conservation_1507  1
    load_2_10_16  free_load_conservation_1547  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_17  arc_capacity_1283  -30
    arc_2_10_17  connected_order_arc_1284  -12
    arc_2_10_17  out_degree_1503  1
    arc_2_10_17  in_degree_1549  1
    arc_2_10_17  original_T_including_depot_unload_1574  1.5117151439160034e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_17  arc_capacity_1283  1
    load_2_10_17  segment_load_conservation_1507  1
    load_2_10_17  free_load_conservation_1553  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_18  arc_capacity_1285  -30
    arc_2_10_18  connected_order_arc_1286  -12
    arc_2_10_18  out_degree_1503  1
    arc_2_10_18  in_degree_1555  1
    arc_2_10_18  original_T_including_depot_unload_1574  8.4968861461374138e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_18  arc_capacity_1285  1
    load_2_10_18  segment_load_conservation_1507  1
    load_2_10_18  free_load_conservation_1559  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_19  arc_capacity_1287  -30
    arc_2_10_19  connected_order_arc_1288  -12
    arc_2_10_19  out_degree_1503  1
    arc_2_10_19  in_degree_1561  1
    arc_2_10_19  original_T_including_depot_unload_1574  1.0105932041904148e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_19  arc_capacity_1287  1
    load_2_10_19  segment_load_conservation_1507  1
    load_2_10_19  free_load_conservation_1565  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_20  arc_capacity_1289  -30
    arc_2_10_20  connected_order_arc_1290  -12
    arc_2_10_20  out_degree_1503  1
    arc_2_10_20  in_degree_1567  1
    arc_2_10_20  original_T_including_depot_unload_1574  9.6598937061987863e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_20  arc_capacity_1289  1
    load_2_10_20  segment_load_conservation_1507  1
    load_2_10_20  free_load_conservation_1571  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_0  arc_capacity_1291  -30
    arc_2_11_0  depot_return_or_bypass_1502  1
    arc_2_11_0  out_degree_1510  1
    arc_2_11_0  original_T_including_depot_unload_1574  1.4567038050199781e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_0  arc_capacity_1291  1
    load_2_11_0  segment_load_conservation_1514  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_10  arc_capacity_1292  -30
    arc_2_11_10  connected_order_arc_1293  -12
    arc_2_11_10  in_degree_1504  1
    arc_2_11_10  out_degree_1510  1
    arc_2_11_10  original_T_including_depot_unload_1574  1.2835993572680911e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_10  arc_capacity_1292  1
    load_2_11_10  segment_load_conservation_1507  -1
    load_2_11_10  segment_prefix_lb_1508  1
    load_2_11_10  segment_prefix_ub_1509  1
    load_2_11_10  segment_load_conservation_1514  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_12  arc_capacity_1294  -30
    arc_2_11_12  connected_order_arc_1295  -12
    arc_2_11_12  out_degree_1510  1
    arc_2_11_12  in_degree_1518  1
    arc_2_11_12  original_T_including_depot_unload_1574  1.4472076573979532e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_12  arc_capacity_1294  1
    load_2_11_12  segment_load_conservation_1514  1
    load_2_11_12  segment_load_conservation_1521  -1
    load_2_11_12  segment_prefix_lb_1522  1
    load_2_11_12  segment_prefix_ub_1523  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_13  arc_capacity_1296  -30
    arc_2_11_13  connected_order_arc_1297  -12
    arc_2_11_13  out_degree_1510  1
    arc_2_11_13  in_degree_1525  1
    arc_2_11_13  original_T_including_depot_unload_1574  1.8805180645589260e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_13  arc_capacity_1296  1
    load_2_11_13  segment_load_conservation_1514  1
    load_2_11_13  free_load_conservation_1529  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_14  arc_capacity_1298  -30
    arc_2_11_14  connected_order_arc_1299  -12
    arc_2_11_14  out_degree_1510  1
    arc_2_11_14  in_degree_1531  1
    arc_2_11_14  original_T_including_depot_unload_1574  1.7155529120526971e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_14  arc_capacity_1298  1
    load_2_11_14  segment_load_conservation_1514  1
    load_2_11_14  free_load_conservation_1535  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_15  arc_capacity_1300  -30
    arc_2_11_15  connected_order_arc_1301  -12
    arc_2_11_15  out_degree_1510  1
    arc_2_11_15  in_degree_1537  1
    arc_2_11_15  original_T_including_depot_unload_1574  1.2027697073878232e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_15  arc_capacity_1300  1
    load_2_11_15  segment_load_conservation_1514  1
    load_2_11_15  free_load_conservation_1541  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_16  arc_capacity_1302  -30
    arc_2_11_16  connected_order_arc_1303  -12
    arc_2_11_16  out_degree_1510  1
    arc_2_11_16  in_degree_1543  1
    arc_2_11_16  original_T_including_depot_unload_1574  1.9292357601859349e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_16  arc_capacity_1302  1
    load_2_11_16  segment_load_conservation_1514  1
    load_2_11_16  free_load_conservation_1547  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_17  arc_capacity_1304  -30
    arc_2_11_17  connected_order_arc_1305  -12
    arc_2_11_17  out_degree_1510  1
    arc_2_11_17  in_degree_1549  1
    arc_2_11_17  original_T_including_depot_unload_1574  3.1118349756671438e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_17  arc_capacity_1304  1
    load_2_11_17  segment_load_conservation_1514  1
    load_2_11_17  free_load_conservation_1553  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_18  arc_capacity_1306  -30
    arc_2_11_18  connected_order_arc_1307  -12
    arc_2_11_18  out_degree_1510  1
    arc_2_11_18  in_degree_1555  1
    arc_2_11_18  original_T_including_depot_unload_1574  1.7069358358556344e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_18  arc_capacity_1306  1
    load_2_11_18  segment_load_conservation_1514  1
    load_2_11_18  free_load_conservation_1559  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_19  arc_capacity_1308  -30
    arc_2_11_19  connected_order_arc_1309  -12
    arc_2_11_19  out_degree_1510  1
    arc_2_11_19  in_degree_1561  1
    arc_2_11_19  original_T_including_depot_unload_1574  8.0219422833177862e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_19  arc_capacity_1308  1
    load_2_11_19  segment_load_conservation_1514  1
    load_2_11_19  free_load_conservation_1565  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_20  arc_capacity_1310  -30
    arc_2_11_20  connected_order_arc_1311  -12
    arc_2_11_20  out_degree_1510  1
    arc_2_11_20  in_degree_1567  1
    arc_2_11_20  original_T_including_depot_unload_1574  2.1488172932724365e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_20  arc_capacity_1310  1
    load_2_11_20  segment_load_conservation_1514  1
    load_2_11_20  free_load_conservation_1571  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_0  arc_capacity_1312  -30
    arc_2_12_0  depot_return_or_bypass_1502  1
    arc_2_12_0  out_degree_1517  1
    arc_2_12_0  original_T_including_depot_unload_1574  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_0  arc_capacity_1312  1
    load_2_12_0  segment_load_conservation_1521  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_10  arc_capacity_1313  -30
    arc_2_12_10  connected_order_arc_1314  -12
    arc_2_12_10  in_degree_1504  1
    arc_2_12_10  out_degree_1517  1
    arc_2_12_10  original_T_including_depot_unload_1574  359.975566576564
    MARKER    'MARKER'                 'INTEND'
    load_2_12_10  arc_capacity_1313  1
    load_2_12_10  segment_load_conservation_1507  -1
    load_2_12_10  segment_prefix_lb_1508  1
    load_2_12_10  segment_prefix_ub_1509  1
    load_2_12_10  segment_load_conservation_1521  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_11  arc_capacity_1315  -30
    arc_2_12_11  connected_order_arc_1316  -12
    arc_2_12_11  in_degree_1511  1
    arc_2_12_11  out_degree_1517  1
    arc_2_12_11  original_T_including_depot_unload_1574  1.2875945644569279e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_11  arc_capacity_1315  1
    load_2_12_11  segment_load_conservation_1514  -1
    load_2_12_11  segment_prefix_lb_1515  1
    load_2_12_11  segment_prefix_ub_1516  1
    load_2_12_11  segment_load_conservation_1521  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_13  arc_capacity_1317  -30
    arc_2_12_13  connected_order_arc_1318  -12
    arc_2_12_13  out_degree_1517  1
    arc_2_12_13  in_degree_1525  1
    arc_2_12_13  original_T_including_depot_unload_1574  6.4572843340219208e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_13  arc_capacity_1317  1
    load_2_12_13  segment_load_conservation_1521  1
    load_2_12_13  free_load_conservation_1529  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_14  arc_capacity_1319  -30
    arc_2_12_14  connected_order_arc_1320  -12
    arc_2_12_14  out_degree_1517  1
    arc_2_12_14  in_degree_1531  1
    arc_2_12_14  original_T_including_depot_unload_1574  5.7354473845222140e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_14  arc_capacity_1319  1
    load_2_12_14  segment_load_conservation_1521  1
    load_2_12_14  free_load_conservation_1535  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_15  arc_capacity_1321  -30
    arc_2_12_15  connected_order_arc_1322  -12
    arc_2_12_15  out_degree_1517  1
    arc_2_12_15  in_degree_1537  1
    arc_2_12_15  original_T_including_depot_unload_1574  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_15  arc_capacity_1321  1
    load_2_12_15  segment_load_conservation_1521  1
    load_2_12_15  free_load_conservation_1541  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_16  arc_capacity_1323  -30
    arc_2_12_16  connected_order_arc_1324  -12
    arc_2_12_16  out_degree_1517  1
    arc_2_12_16  in_degree_1543  1
    arc_2_12_16  original_T_including_depot_unload_1574  5.6127522609820687e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_16  arc_capacity_1323  1
    load_2_12_16  segment_load_conservation_1521  1
    load_2_12_16  free_load_conservation_1547  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_17  arc_capacity_1325  -30
    arc_2_12_17  connected_order_arc_1326  -12
    arc_2_12_17  out_degree_1517  1
    arc_2_12_17  in_degree_1549  1
    arc_2_12_17  original_T_including_depot_unload_1574  1.3857128117205509e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_17  arc_capacity_1325  1
    load_2_12_17  segment_load_conservation_1521  1
    load_2_12_17  free_load_conservation_1553  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_18  arc_capacity_1327  -30
    arc_2_12_18  connected_order_arc_1328  -12
    arc_2_12_18  out_degree_1517  1
    arc_2_12_18  in_degree_1555  1
    arc_2_12_18  original_T_including_depot_unload_1574  3.6658228437834981e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_18  arc_capacity_1327  1
    load_2_12_18  segment_load_conservation_1521  1
    load_2_12_18  free_load_conservation_1559  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_19  arc_capacity_1329  -30
    arc_2_12_19  connected_order_arc_1330  -12
    arc_2_12_19  out_degree_1517  1
    arc_2_12_19  in_degree_1561  1
    arc_2_12_19  original_T_including_depot_unload_1574  7.6275540057842773e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_19  arc_capacity_1329  1
    load_2_12_19  segment_load_conservation_1521  1
    load_2_12_19  free_load_conservation_1565  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_20  arc_capacity_1331  -30
    arc_2_12_20  connected_order_arc_1332  -12
    arc_2_12_20  out_degree_1517  1
    arc_2_12_20  in_degree_1567  1
    arc_2_12_20  original_T_including_depot_unload_1574  7.8590541298812059e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_20  arc_capacity_1331  1
    load_2_12_20  segment_load_conservation_1521  1
    load_2_12_20  free_load_conservation_1571  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_0  arc_capacity_1333  -30
    arc_2_13_0  depot_return_or_bypass_1502  1
    arc_2_13_0  out_degree_1524  1
    arc_2_13_0  original_T_including_depot_unload_1574  5.4249700630778887e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_0  arc_capacity_1333  1
    load_2_13_0  free_load_conservation_1529  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_10  arc_capacity_1334  -30
    arc_2_13_10  connected_order_arc_1335  -12
    arc_2_13_10  in_degree_1504  1
    arc_2_13_10  out_degree_1524  1
    arc_2_13_10  original_T_including_depot_unload_1574  6.0309764600105484e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_10  arc_capacity_1334  1
    load_2_13_10  segment_load_conservation_1507  -1
    load_2_13_10  segment_prefix_lb_1508  1
    load_2_13_10  segment_prefix_ub_1509  1
    load_2_13_10  free_load_conservation_1529  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_11  arc_capacity_1336  -30
    arc_2_13_11  connected_order_arc_1337  -12
    arc_2_13_11  in_degree_1511  1
    arc_2_13_11  out_degree_1524  1
    arc_2_13_11  original_T_including_depot_unload_1574  1.7022035239152008e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_11  arc_capacity_1336  1
    load_2_13_11  segment_load_conservation_1514  -1
    load_2_13_11  segment_prefix_lb_1515  1
    load_2_13_11  segment_prefix_ub_1516  1
    load_2_13_11  free_load_conservation_1529  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_12  arc_capacity_1338  -30
    arc_2_13_12  connected_order_arc_1339  -12
    arc_2_13_12  in_degree_1518  1
    arc_2_13_12  out_degree_1524  1
    arc_2_13_12  original_T_including_depot_unload_1574  6.4572843340219208e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_12  arc_capacity_1338  1
    load_2_13_12  segment_load_conservation_1521  -1
    load_2_13_12  segment_prefix_lb_1522  1
    load_2_13_12  segment_prefix_ub_1523  1
    load_2_13_12  free_load_conservation_1529  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_14  arc_capacity_1340  -30
    arc_2_13_14  connected_order_arc_1341  -12
    arc_2_13_14  out_degree_1524  1
    arc_2_13_14  in_degree_1531  1
    arc_2_13_14  original_T_including_depot_unload_1574  1.7461252424213140e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_14  arc_capacity_1340  1
    load_2_13_14  free_load_conservation_1529  1
    load_2_13_14  free_load_conservation_1535  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_15  arc_capacity_1342  -30
    arc_2_13_15  connected_order_arc_1343  -12
    arc_2_13_15  out_degree_1524  1
    arc_2_13_15  in_degree_1537  1
    arc_2_13_15  original_T_including_depot_unload_1574  1.6231508478292610e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_15  arc_capacity_1342  1
    load_2_13_15  free_load_conservation_1529  1
    load_2_13_15  free_load_conservation_1541  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_16  arc_capacity_1344  -30
    arc_2_13_16  connected_order_arc_1345  -12
    arc_2_13_16  out_degree_1524  1
    arc_2_13_16  in_degree_1543  1
    arc_2_13_16  original_T_including_depot_unload_1574  2.3159636865750136e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_16  arc_capacity_1344  1
    load_2_13_16  free_load_conservation_1529  1
    load_2_13_16  free_load_conservation_1547  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_17  arc_capacity_1346  -30
    arc_2_13_17  connected_order_arc_1347  -12
    arc_2_13_17  out_degree_1524  1
    arc_2_13_17  in_degree_1549  1
    arc_2_13_17  original_T_including_depot_unload_1574  1.7249161387293191e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_17  arc_capacity_1346  1
    load_2_13_17  free_load_conservation_1529  1
    load_2_13_17  free_load_conservation_1553  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_18  arc_capacity_1348  -30
    arc_2_13_18  connected_order_arc_1349  -12
    arc_2_13_18  out_degree_1524  1
    arc_2_13_18  in_degree_1555  1
    arc_2_13_18  original_T_including_depot_unload_1574  2.8529311190414518e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_18  arc_capacity_1348  1
    load_2_13_18  free_load_conservation_1529  1
    load_2_13_18  free_load_conservation_1559  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_19  arc_capacity_1350  -30
    arc_2_13_19  connected_order_arc_1351  -12
    arc_2_13_19  out_degree_1524  1
    arc_2_13_19  in_degree_1561  1
    arc_2_13_19  original_T_including_depot_unload_1574  1.0838347754693179e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_19  arc_capacity_1350  1
    load_2_13_19  free_load_conservation_1529  1
    load_2_13_19  free_load_conservation_1565  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_20  arc_capacity_1352  -30
    arc_2_13_20  connected_order_arc_1353  -12
    arc_2_13_20  out_degree_1524  1
    arc_2_13_20  in_degree_1567  1
    arc_2_13_20  original_T_including_depot_unload_1574  3.2367117212973966e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_20  arc_capacity_1352  1
    load_2_13_20  free_load_conservation_1529  1
    load_2_13_20  free_load_conservation_1571  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_0  arc_capacity_1354  -30
    arc_2_14_0  depot_return_or_bypass_1502  1
    arc_2_14_0  out_degree_1530  1
    arc_2_14_0  original_T_including_depot_unload_1574  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_0  arc_capacity_1354  1
    load_2_14_0  free_load_conservation_1535  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_10  arc_capacity_1355  -30
    arc_2_14_10  connected_order_arc_1356  -12
    arc_2_14_10  in_degree_1504  1
    arc_2_14_10  out_degree_1530  1
    arc_2_14_10  original_T_including_depot_unload_1574  4.5094949828949649e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_10  arc_capacity_1355  1
    load_2_14_10  segment_load_conservation_1507  -1
    load_2_14_10  segment_prefix_lb_1508  1
    load_2_14_10  segment_prefix_ub_1509  1
    load_2_14_10  free_load_conservation_1535  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_11  arc_capacity_1357  -30
    arc_2_14_11  connected_order_arc_1358  -12
    arc_2_14_11  in_degree_1511  1
    arc_2_14_11  out_degree_1530  1
    arc_2_14_11  original_T_including_depot_unload_1574  1.5362659379368008e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_11  arc_capacity_1357  1
    load_2_14_11  segment_load_conservation_1514  -1
    load_2_14_11  segment_prefix_lb_1515  1
    load_2_14_11  segment_prefix_ub_1516  1
    load_2_14_11  free_load_conservation_1535  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_12  arc_capacity_1359  -30
    arc_2_14_12  connected_order_arc_1360  -12
    arc_2_14_12  in_degree_1518  1
    arc_2_14_12  out_degree_1530  1
    arc_2_14_12  original_T_including_depot_unload_1574  5.7354473845222140e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_12  arc_capacity_1359  1
    load_2_14_12  segment_load_conservation_1521  -1
    load_2_14_12  segment_prefix_lb_1522  1
    load_2_14_12  segment_prefix_ub_1523  1
    load_2_14_12  free_load_conservation_1535  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_13  arc_capacity_1361  -30
    arc_2_14_13  connected_order_arc_1362  -12
    arc_2_14_13  in_degree_1525  1
    arc_2_14_13  out_degree_1530  1
    arc_2_14_13  original_T_including_depot_unload_1574  1.7461252424213140e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_13  arc_capacity_1361  1
    load_2_14_13  free_load_conservation_1529  -1
    load_2_14_13  free_load_conservation_1535  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_15  arc_capacity_1363  -30
    arc_2_14_15  connected_order_arc_1364  -12
    arc_2_14_15  out_degree_1530  1
    arc_2_14_15  in_degree_1537  1
    arc_2_14_15  original_T_including_depot_unload_1574  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_15  arc_capacity_1363  1
    load_2_14_15  free_load_conservation_1535  1
    load_2_14_15  free_load_conservation_1541  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_16  arc_capacity_1365  -30
    arc_2_14_16  connected_order_arc_1366  -12
    arc_2_14_16  out_degree_1530  1
    arc_2_14_16  in_degree_1543  1
    arc_2_14_16  original_T_including_depot_unload_1574  3.4754938304534517e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_16  arc_capacity_1365  1
    load_2_14_16  free_load_conservation_1535  1
    load_2_14_16  free_load_conservation_1547  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_17  arc_capacity_1367  -30
    arc_2_14_17  connected_order_arc_1368  -12
    arc_2_14_17  out_degree_1530  1
    arc_2_14_17  in_degree_1549  1
    arc_2_14_17  original_T_including_depot_unload_1574  1.5530568652263394e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_17  arc_capacity_1367  1
    load_2_14_17  free_load_conservation_1535  1
    load_2_14_17  free_load_conservation_1553  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_18  arc_capacity_1369  -30
    arc_2_14_18  connected_order_arc_1370  -12
    arc_2_14_18  out_degree_1530  1
    arc_2_14_18  in_degree_1555  1
    arc_2_14_18  original_T_including_depot_unload_1574  2.7078292664437623e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_18  arc_capacity_1369  1
    load_2_14_18  free_load_conservation_1535  1
    load_2_14_18  free_load_conservation_1559  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_19  arc_capacity_1371  -30
    arc_2_14_19  connected_order_arc_1372  -12
    arc_2_14_19  out_degree_1530  1
    arc_2_14_19  in_degree_1561  1
    arc_2_14_19  original_T_including_depot_unload_1574  9.1580557259044724e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_19  arc_capacity_1371  1
    load_2_14_19  free_load_conservation_1535  1
    load_2_14_19  free_load_conservation_1565  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_20  arc_capacity_1373  -30
    arc_2_14_20  connected_order_arc_1374  -12
    arc_2_14_20  out_degree_1530  1
    arc_2_14_20  in_degree_1567  1
    arc_2_14_20  original_T_including_depot_unload_1574  4.9242827332511274e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_20  arc_capacity_1373  1
    load_2_14_20  free_load_conservation_1535  1
    load_2_14_20  free_load_conservation_1571  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_0  arc_capacity_1375  -30
    arc_2_15_0  depot_return_or_bypass_1502  1
    arc_2_15_0  out_degree_1536  1
    arc_2_15_0  original_T_including_depot_unload_1574  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_0  arc_capacity_1375  1
    load_2_15_0  free_load_conservation_1541  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_10  arc_capacity_1376  -30
    arc_2_15_10  connected_order_arc_1377  -12
    arc_2_15_10  in_degree_1504  1
    arc_2_15_10  out_degree_1536  1
    arc_2_15_10  original_T_including_depot_unload_1574  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_10  arc_capacity_1376  1
    load_2_15_10  segment_load_conservation_1507  -1
    load_2_15_10  segment_prefix_lb_1508  1
    load_2_15_10  segment_prefix_ub_1509  1
    load_2_15_10  free_load_conservation_1541  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_11  arc_capacity_1378  -30
    arc_2_15_11  connected_order_arc_1379  -12
    arc_2_15_11  in_degree_1511  1
    arc_2_15_11  out_degree_1536  1
    arc_2_15_11  original_T_including_depot_unload_1574  1.1490429395374924e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_11  arc_capacity_1378  1
    load_2_15_11  segment_load_conservation_1514  -1
    load_2_15_11  segment_prefix_lb_1515  1
    load_2_15_11  segment_prefix_ub_1516  1
    load_2_15_11  free_load_conservation_1541  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_12  arc_capacity_1380  -30
    arc_2_15_12  connected_order_arc_1381  -12
    arc_2_15_12  in_degree_1518  1
    arc_2_15_12  out_degree_1536  1
    arc_2_15_12  original_T_including_depot_unload_1574  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_12  arc_capacity_1380  1
    load_2_15_12  segment_load_conservation_1521  -1
    load_2_15_12  segment_prefix_lb_1522  1
    load_2_15_12  segment_prefix_ub_1523  1
    load_2_15_12  free_load_conservation_1541  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_13  arc_capacity_1382  -30
    arc_2_15_13  connected_order_arc_1383  -12
    arc_2_15_13  in_degree_1525  1
    arc_2_15_13  out_degree_1536  1
    arc_2_15_13  original_T_including_depot_unload_1574  1.6231508478292610e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_13  arc_capacity_1382  1
    load_2_15_13  free_load_conservation_1529  -1
    load_2_15_13  free_load_conservation_1541  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_14  arc_capacity_1384  -30
    arc_2_15_14  connected_order_arc_1385  -12
    arc_2_15_14  in_degree_1531  1
    arc_2_15_14  out_degree_1536  1
    arc_2_15_14  original_T_including_depot_unload_1574  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_14  arc_capacity_1384  1
    load_2_15_14  free_load_conservation_1535  -1
    load_2_15_14  free_load_conservation_1541  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_16  arc_capacity_1386  -30
    arc_2_15_16  connected_order_arc_1387  -12
    arc_2_15_16  out_degree_1536  1
    arc_2_15_16  in_degree_1543  1
    arc_2_15_16  original_T_including_depot_unload_1574  1.5184659007075070e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_16  arc_capacity_1386  1
    load_2_15_16  free_load_conservation_1541  1
    load_2_15_16  free_load_conservation_1547  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_17  arc_capacity_1388  -30
    arc_2_15_17  connected_order_arc_1389  -12
    arc_2_15_17  out_degree_1536  1
    arc_2_15_17  in_degree_1549  1
    arc_2_15_17  original_T_including_depot_unload_1574  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_17  arc_capacity_1388  1
    load_2_15_17  free_load_conservation_1541  1
    load_2_15_17  free_load_conservation_1553  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_18  arc_capacity_1390  -30
    arc_2_15_18  connected_order_arc_1391  -12
    arc_2_15_18  out_degree_1536  1
    arc_2_15_18  in_degree_1555  1
    arc_2_15_18  original_T_including_depot_unload_1574  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_18  arc_capacity_1390  1
    load_2_15_18  free_load_conservation_1541  1
    load_2_15_18  free_load_conservation_1559  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_19  arc_capacity_1392  -30
    arc_2_15_19  connected_order_arc_1393  -12
    arc_2_15_19  out_degree_1536  1
    arc_2_15_19  in_degree_1561  1
    arc_2_15_19  original_T_including_depot_unload_1574  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_19  arc_capacity_1392  1
    load_2_15_19  free_load_conservation_1541  1
    load_2_15_19  free_load_conservation_1565  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_20  arc_capacity_1394  -30
    arc_2_15_20  connected_order_arc_1395  -12
    arc_2_15_20  out_degree_1536  1
    arc_2_15_20  in_degree_1567  1
    arc_2_15_20  original_T_including_depot_unload_1574  1.7303231472353602e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_20  arc_capacity_1394  1
    load_2_15_20  free_load_conservation_1541  1
    load_2_15_20  free_load_conservation_1571  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_0  arc_capacity_1396  -30
    arc_2_16_0  depot_return_or_bypass_1502  1
    arc_2_16_0  out_degree_1542  1
    arc_2_16_0  original_T_including_depot_unload_1574  4.9403722507151832e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_0  arc_capacity_1396  1
    load_2_16_0  free_load_conservation_1547  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_10  arc_capacity_1397  -30
    arc_2_16_10  connected_order_arc_1398  -12
    arc_2_16_10  in_degree_1504  1
    arc_2_16_10  out_degree_1542  1
    arc_2_16_10  original_T_including_depot_unload_1574  6.5332321619697848e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_10  arc_capacity_1397  1
    load_2_16_10  segment_load_conservation_1507  -1
    load_2_16_10  segment_prefix_lb_1508  1
    load_2_16_10  segment_prefix_ub_1509  1
    load_2_16_10  free_load_conservation_1547  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_11  arc_capacity_1399  -30
    arc_2_16_11  connected_order_arc_1400  -12
    arc_2_16_11  in_degree_1511  1
    arc_2_16_11  out_degree_1542  1
    arc_2_16_11  original_T_including_depot_unload_1574  1.7563534000055533e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_11  arc_capacity_1399  1
    load_2_16_11  segment_load_conservation_1514  -1
    load_2_16_11  segment_prefix_lb_1515  1
    load_2_16_11  segment_prefix_ub_1516  1
    load_2_16_11  free_load_conservation_1547  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_12  arc_capacity_1401  -30
    arc_2_16_12  connected_order_arc_1402  -12
    arc_2_16_12  in_degree_1518  1
    arc_2_16_12  out_degree_1542  1
    arc_2_16_12  original_T_including_depot_unload_1574  5.6127522609820687e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_12  arc_capacity_1401  1
    load_2_16_12  segment_load_conservation_1521  -1
    load_2_16_12  segment_prefix_lb_1522  1
    load_2_16_12  segment_prefix_ub_1523  1
    load_2_16_12  free_load_conservation_1547  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_13  arc_capacity_1403  -30
    arc_2_16_13  connected_order_arc_1404  -12
    arc_2_16_13  in_degree_1525  1
    arc_2_16_13  out_degree_1542  1
    arc_2_16_13  original_T_including_depot_unload_1574  2.3159636865750136e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_13  arc_capacity_1403  1
    load_2_16_13  free_load_conservation_1529  -1
    load_2_16_13  free_load_conservation_1547  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_14  arc_capacity_1405  -30
    arc_2_16_14  connected_order_arc_1406  -12
    arc_2_16_14  in_degree_1531  1
    arc_2_16_14  out_degree_1542  1
    arc_2_16_14  original_T_including_depot_unload_1574  3.4754938304534517e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_14  arc_capacity_1405  1
    load_2_16_14  free_load_conservation_1535  -1
    load_2_16_14  free_load_conservation_1547  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_15  arc_capacity_1407  -30
    arc_2_16_15  connected_order_arc_1408  -12
    arc_2_16_15  in_degree_1537  1
    arc_2_16_15  out_degree_1542  1
    arc_2_16_15  original_T_including_depot_unload_1574  1.5184659007075070e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_15  arc_capacity_1407  1
    load_2_16_15  free_load_conservation_1541  -1
    load_2_16_15  free_load_conservation_1547  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_17  arc_capacity_1409  -30
    arc_2_16_17  connected_order_arc_1410  -12
    arc_2_16_17  out_degree_1542  1
    arc_2_16_17  in_degree_1549  1
    arc_2_16_17  original_T_including_depot_unload_1574  1.8073464544423741e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_17  arc_capacity_1409  1
    load_2_16_17  free_load_conservation_1547  1
    load_2_16_17  free_load_conservation_1553  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_18  arc_capacity_1411  -30
    arc_2_16_18  connected_order_arc_1412  -12
    arc_2_16_18  out_degree_1542  1
    arc_2_16_18  in_degree_1555  1
    arc_2_16_18  original_T_including_depot_unload_1574  2.2271784981792140e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_18  arc_capacity_1411  1
    load_2_16_18  free_load_conservation_1547  1
    load_2_16_18  free_load_conservation_1559  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_19  arc_capacity_1413  -30
    arc_2_16_19  connected_order_arc_1414  -12
    arc_2_16_19  out_degree_1542  1
    arc_2_16_19  in_degree_1561  1
    arc_2_16_19  original_T_including_depot_unload_1574  1.1562172312295786e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_19  arc_capacity_1413  1
    load_2_16_19  free_load_conservation_1547  1
    load_2_16_19  free_load_conservation_1565  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_20  arc_capacity_1415  -30
    arc_2_16_20  connected_order_arc_1416  -12
    arc_2_16_20  out_degree_1542  1
    arc_2_16_20  in_degree_1567  1
    arc_2_16_20  original_T_including_depot_unload_1574  2.2729932910497158e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_20  arc_capacity_1415  1
    load_2_16_20  free_load_conservation_1547  1
    load_2_16_20  free_load_conservation_1571  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_0  arc_capacity_1417  -30
    arc_2_17_0  depot_return_or_bypass_1502  1
    arc_2_17_0  out_degree_1548  1
    arc_2_17_0  original_T_including_depot_unload_1574  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_0  arc_capacity_1417  1
    load_2_17_0  free_load_conservation_1553  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_10  arc_capacity_1418  -30
    arc_2_17_10  connected_order_arc_1419  -12
    arc_2_17_10  in_degree_1504  1
    arc_2_17_10  out_degree_1548  1
    arc_2_17_10  original_T_including_depot_unload_1574  1.1544376314422677e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_10  arc_capacity_1418  1
    load_2_17_10  segment_load_conservation_1507  -1
    load_2_17_10  segment_prefix_lb_1508  1
    load_2_17_10  segment_prefix_ub_1509  1
    load_2_17_10  free_load_conservation_1553  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_11  arc_capacity_1420  -30
    arc_2_17_11  connected_order_arc_1421  -12
    arc_2_17_11  in_degree_1511  1
    arc_2_17_11  out_degree_1548  1
    arc_2_17_11  original_T_including_depot_unload_1574  2.2636464857275848e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_11  arc_capacity_1420  1
    load_2_17_11  segment_load_conservation_1514  -1
    load_2_17_11  segment_prefix_lb_1515  1
    load_2_17_11  segment_prefix_ub_1516  1
    load_2_17_11  free_load_conservation_1553  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_12  arc_capacity_1422  -30
    arc_2_17_12  connected_order_arc_1423  -12
    arc_2_17_12  in_degree_1518  1
    arc_2_17_12  out_degree_1548  1
    arc_2_17_12  original_T_including_depot_unload_1574  1.3857128117205509e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_12  arc_capacity_1422  1
    load_2_17_12  segment_load_conservation_1521  -1
    load_2_17_12  segment_prefix_lb_1522  1
    load_2_17_12  segment_prefix_ub_1523  1
    load_2_17_12  free_load_conservation_1553  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_13  arc_capacity_1424  -30
    arc_2_17_13  connected_order_arc_1425  -12
    arc_2_17_13  in_degree_1525  1
    arc_2_17_13  out_degree_1548  1
    arc_2_17_13  original_T_including_depot_unload_1574  1.7249161387293191e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_13  arc_capacity_1424  1
    load_2_17_13  free_load_conservation_1529  -1
    load_2_17_13  free_load_conservation_1553  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_14  arc_capacity_1426  -30
    arc_2_17_14  connected_order_arc_1427  -12
    arc_2_17_14  in_degree_1531  1
    arc_2_17_14  out_degree_1548  1
    arc_2_17_14  original_T_including_depot_unload_1574  1.5530568652263394e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_14  arc_capacity_1426  1
    load_2_17_14  free_load_conservation_1535  -1
    load_2_17_14  free_load_conservation_1553  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_15  arc_capacity_1428  -30
    arc_2_17_15  connected_order_arc_1429  -12
    arc_2_17_15  in_degree_1537  1
    arc_2_17_15  out_degree_1548  1
    arc_2_17_15  original_T_including_depot_unload_1574  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_15  arc_capacity_1428  1
    load_2_17_15  free_load_conservation_1541  -1
    load_2_17_15  free_load_conservation_1553  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_16  arc_capacity_1430  -30
    arc_2_17_16  connected_order_arc_1431  -12
    arc_2_17_16  in_degree_1543  1
    arc_2_17_16  out_degree_1548  1
    arc_2_17_16  original_T_including_depot_unload_1574  1.8073464544423741e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_16  arc_capacity_1430  1
    load_2_17_16  free_load_conservation_1547  -1
    load_2_17_16  free_load_conservation_1553  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_18  arc_capacity_1432  -30
    arc_2_17_18  connected_order_arc_1433  -12
    arc_2_17_18  out_degree_1548  1
    arc_2_17_18  in_degree_1555  1
    arc_2_17_18  original_T_including_depot_unload_1574  1.5902582434549993e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_18  arc_capacity_1432  1
    load_2_17_18  free_load_conservation_1553  1
    load_2_17_18  free_load_conservation_1559  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_19  arc_capacity_1434  -30
    arc_2_17_19  connected_order_arc_1435  -12
    arc_2_17_19  out_degree_1548  1
    arc_2_17_19  in_degree_1561  1
    arc_2_17_19  original_T_including_depot_unload_1574  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_19  arc_capacity_1434  1
    load_2_17_19  free_load_conservation_1553  1
    load_2_17_19  free_load_conservation_1565  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_20  arc_capacity_1436  -30
    arc_2_17_20  connected_order_arc_1437  -12
    arc_2_17_20  out_degree_1548  1
    arc_2_17_20  in_degree_1567  1
    arc_2_17_20  original_T_including_depot_unload_1574  2.0162129512771592e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_20  arc_capacity_1436  1
    load_2_17_20  free_load_conservation_1553  1
    load_2_17_20  free_load_conservation_1571  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_0  arc_capacity_1438  -30
    arc_2_18_0  depot_return_or_bypass_1502  1
    arc_2_18_0  out_degree_1554  1
    arc_2_18_0  original_T_including_depot_unload_1574  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_0  arc_capacity_1438  1
    load_2_18_0  free_load_conservation_1559  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_10  arc_capacity_1439  -30
    arc_2_18_10  connected_order_arc_1440  -12
    arc_2_18_10  in_degree_1504  1
    arc_2_18_10  out_degree_1554  1
    arc_2_18_10  original_T_including_depot_unload_1574  4.3618991857210159e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_10  arc_capacity_1439  1
    load_2_18_10  segment_load_conservation_1507  -1
    load_2_18_10  segment_prefix_lb_1508  1
    load_2_18_10  segment_prefix_ub_1509  1
    load_2_18_10  free_load_conservation_1559  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_11  arc_capacity_1441  -30
    arc_2_18_11  connected_order_arc_1442  -12
    arc_2_18_11  in_degree_1511  1
    arc_2_18_11  out_degree_1554  1
    arc_2_18_11  original_T_including_depot_unload_1574  1.5346053834915313e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_11  arc_capacity_1441  1
    load_2_18_11  segment_load_conservation_1514  -1
    load_2_18_11  segment_prefix_lb_1515  1
    load_2_18_11  segment_prefix_ub_1516  1
    load_2_18_11  free_load_conservation_1559  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_12  arc_capacity_1443  -30
    arc_2_18_12  connected_order_arc_1444  -12
    arc_2_18_12  in_degree_1518  1
    arc_2_18_12  out_degree_1554  1
    arc_2_18_12  original_T_including_depot_unload_1574  3.6658228437834981e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_12  arc_capacity_1443  1
    load_2_18_12  segment_load_conservation_1521  -1
    load_2_18_12  segment_prefix_lb_1522  1
    load_2_18_12  segment_prefix_ub_1523  1
    load_2_18_12  free_load_conservation_1559  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_13  arc_capacity_1445  -30
    arc_2_18_13  connected_order_arc_1446  -12
    arc_2_18_13  in_degree_1525  1
    arc_2_18_13  out_degree_1554  1
    arc_2_18_13  original_T_including_depot_unload_1574  2.8529311190414518e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_13  arc_capacity_1445  1
    load_2_18_13  free_load_conservation_1529  -1
    load_2_18_13  free_load_conservation_1559  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_14  arc_capacity_1447  -30
    arc_2_18_14  connected_order_arc_1448  -12
    arc_2_18_14  in_degree_1531  1
    arc_2_18_14  out_degree_1554  1
    arc_2_18_14  original_T_including_depot_unload_1574  2.7078292664437623e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_14  arc_capacity_1447  1
    load_2_18_14  free_load_conservation_1535  -1
    load_2_18_14  free_load_conservation_1559  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_15  arc_capacity_1449  -30
    arc_2_18_15  connected_order_arc_1450  -12
    arc_2_18_15  in_degree_1537  1
    arc_2_18_15  out_degree_1554  1
    arc_2_18_15  original_T_including_depot_unload_1574  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_15  arc_capacity_1449  1
    load_2_18_15  free_load_conservation_1541  -1
    load_2_18_15  free_load_conservation_1559  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_16  arc_capacity_1451  -30
    arc_2_18_16  connected_order_arc_1452  -12
    arc_2_18_16  in_degree_1543  1
    arc_2_18_16  out_degree_1554  1
    arc_2_18_16  original_T_including_depot_unload_1574  2.2271784981792140e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_16  arc_capacity_1451  1
    load_2_18_16  free_load_conservation_1547  -1
    load_2_18_16  free_load_conservation_1559  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_17  arc_capacity_1453  -30
    arc_2_18_17  connected_order_arc_1454  -12
    arc_2_18_17  in_degree_1549  1
    arc_2_18_17  out_degree_1554  1
    arc_2_18_17  original_T_including_depot_unload_1574  1.5902582434549993e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_17  arc_capacity_1453  1
    load_2_18_17  free_load_conservation_1553  -1
    load_2_18_17  free_load_conservation_1559  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_19  arc_capacity_1455  -30
    arc_2_18_19  connected_order_arc_1456  -12
    arc_2_18_19  out_degree_1554  1
    arc_2_18_19  in_degree_1561  1
    arc_2_18_19  original_T_including_depot_unload_1574  9.3905252655669165e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_19  arc_capacity_1455  1
    load_2_18_19  free_load_conservation_1559  1
    load_2_18_19  free_load_conservation_1565  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_20  arc_capacity_1457  -30
    arc_2_18_20  connected_order_arc_1458  -12
    arc_2_18_20  out_degree_1554  1
    arc_2_18_20  in_degree_1567  1
    arc_2_18_20  original_T_including_depot_unload_1574  4.4733407106545638e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_20  arc_capacity_1457  1
    load_2_18_20  free_load_conservation_1559  1
    load_2_18_20  free_load_conservation_1571  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_0  arc_capacity_1459  -30
    arc_2_19_0  depot_return_or_bypass_1502  1
    arc_2_19_0  out_degree_1560  1
    arc_2_19_0  original_T_including_depot_unload_1574  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_0  arc_capacity_1459  1
    load_2_19_0  free_load_conservation_1565  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_10  arc_capacity_1460  -30
    arc_2_19_10  connected_order_arc_1461  -12
    arc_2_19_10  in_degree_1504  1
    arc_2_19_10  out_degree_1560  1
    arc_2_19_10  original_T_including_depot_unload_1574  5.0315495126439691e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_10  arc_capacity_1460  1
    load_2_19_10  segment_load_conservation_1507  -1
    load_2_19_10  segment_prefix_lb_1508  1
    load_2_19_10  segment_prefix_ub_1509  1
    load_2_19_10  free_load_conservation_1565  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_11  arc_capacity_1462  -30
    arc_2_19_11  connected_order_arc_1463  -12
    arc_2_19_11  in_degree_1511  1
    arc_2_19_11  out_degree_1560  1
    arc_2_19_11  original_T_including_depot_unload_1574  6.2172856448708023e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_11  arc_capacity_1462  1
    load_2_19_11  segment_load_conservation_1514  -1
    load_2_19_11  segment_prefix_lb_1515  1
    load_2_19_11  segment_prefix_ub_1516  1
    load_2_19_11  free_load_conservation_1565  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_12  arc_capacity_1464  -30
    arc_2_19_12  connected_order_arc_1465  -12
    arc_2_19_12  in_degree_1518  1
    arc_2_19_12  out_degree_1560  1
    arc_2_19_12  original_T_including_depot_unload_1574  7.6275540057842773e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_12  arc_capacity_1464  1
    load_2_19_12  segment_load_conservation_1521  -1
    load_2_19_12  segment_prefix_lb_1522  1
    load_2_19_12  segment_prefix_ub_1523  1
    load_2_19_12  free_load_conservation_1565  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_13  arc_capacity_1466  -30
    arc_2_19_13  connected_order_arc_1467  -12
    arc_2_19_13  in_degree_1525  1
    arc_2_19_13  out_degree_1560  1
    arc_2_19_13  original_T_including_depot_unload_1574  1.0838347754693179e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_13  arc_capacity_1466  1
    load_2_19_13  free_load_conservation_1529  -1
    load_2_19_13  free_load_conservation_1565  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_14  arc_capacity_1468  -30
    arc_2_19_14  connected_order_arc_1469  -12
    arc_2_19_14  in_degree_1531  1
    arc_2_19_14  out_degree_1560  1
    arc_2_19_14  original_T_including_depot_unload_1574  9.1580557259044724e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_14  arc_capacity_1468  1
    load_2_19_14  free_load_conservation_1535  -1
    load_2_19_14  free_load_conservation_1565  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_15  arc_capacity_1470  -30
    arc_2_19_15  connected_order_arc_1471  -12
    arc_2_19_15  in_degree_1537  1
    arc_2_19_15  out_degree_1560  1
    arc_2_19_15  original_T_including_depot_unload_1574  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_15  arc_capacity_1470  1
    load_2_19_15  free_load_conservation_1541  -1
    load_2_19_15  free_load_conservation_1565  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_16  arc_capacity_1472  -30
    arc_2_19_16  connected_order_arc_1473  -12
    arc_2_19_16  in_degree_1543  1
    arc_2_19_16  out_degree_1560  1
    arc_2_19_16  original_T_including_depot_unload_1574  1.1562172312295786e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_16  arc_capacity_1472  1
    load_2_19_16  free_load_conservation_1547  -1
    load_2_19_16  free_load_conservation_1565  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_17  arc_capacity_1474  -30
    arc_2_19_17  connected_order_arc_1475  -12
    arc_2_19_17  in_degree_1549  1
    arc_2_19_17  out_degree_1560  1
    arc_2_19_17  original_T_including_depot_unload_1574  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_17  arc_capacity_1474  1
    load_2_19_17  free_load_conservation_1553  -1
    load_2_19_17  free_load_conservation_1565  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_18  arc_capacity_1476  -30
    arc_2_19_18  connected_order_arc_1477  -12
    arc_2_19_18  in_degree_1555  1
    arc_2_19_18  out_degree_1560  1
    arc_2_19_18  original_T_including_depot_unload_1574  9.3905252655669165e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_18  arc_capacity_1476  1
    load_2_19_18  free_load_conservation_1559  -1
    load_2_19_18  free_load_conservation_1565  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_20  arc_capacity_1478  -30
    arc_2_19_20  connected_order_arc_1479  -12
    arc_2_19_20  out_degree_1560  1
    arc_2_19_20  in_degree_1567  1
    arc_2_19_20  original_T_including_depot_unload_1574  1.3669225770244122e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_20  arc_capacity_1478  1
    load_2_19_20  free_load_conservation_1565  1
    load_2_19_20  free_load_conservation_1571  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_0  arc_capacity_1480  -30
    arc_2_20_0  depot_return_or_bypass_1502  1
    arc_2_20_0  out_degree_1566  1
    arc_2_20_0  original_T_including_depot_unload_1574  7.2130540230577469e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_0  arc_capacity_1480  1
    load_2_20_0  free_load_conservation_1571  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_10  arc_capacity_1481  -30
    arc_2_20_10  connected_order_arc_1482  -12
    arc_2_20_10  in_degree_1504  1
    arc_2_20_10  out_degree_1566  1
    arc_2_20_10  original_T_including_depot_unload_1574  8.6713096341893186e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_10  arc_capacity_1481  1
    load_2_20_10  segment_load_conservation_1507  -1
    load_2_20_10  segment_prefix_lb_1508  1
    load_2_20_10  segment_prefix_ub_1509  1
    load_2_20_10  free_load_conservation_1571  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_11  arc_capacity_1483  -30
    arc_2_20_11  connected_order_arc_1484  -12
    arc_2_20_11  in_degree_1511  1
    arc_2_20_11  out_degree_1566  1
    arc_2_20_11  original_T_including_depot_unload_1574  1.9742958969613567e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_11  arc_capacity_1483  1
    load_2_20_11  segment_load_conservation_1514  -1
    load_2_20_11  segment_prefix_lb_1515  1
    load_2_20_11  segment_prefix_ub_1516  1
    load_2_20_11  free_load_conservation_1571  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_12  arc_capacity_1485  -30
    arc_2_20_12  connected_order_arc_1486  -12
    arc_2_20_12  in_degree_1518  1
    arc_2_20_12  out_degree_1566  1
    arc_2_20_12  original_T_including_depot_unload_1574  7.8590541298812059e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_12  arc_capacity_1485  1
    load_2_20_12  segment_load_conservation_1521  -1
    load_2_20_12  segment_prefix_lb_1522  1
    load_2_20_12  segment_prefix_ub_1523  1
    load_2_20_12  free_load_conservation_1571  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_13  arc_capacity_1487  -30
    arc_2_20_13  connected_order_arc_1488  -12
    arc_2_20_13  in_degree_1525  1
    arc_2_20_13  out_degree_1566  1
    arc_2_20_13  original_T_including_depot_unload_1574  3.2367117212973966e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_13  arc_capacity_1487  1
    load_2_20_13  free_load_conservation_1529  -1
    load_2_20_13  free_load_conservation_1571  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_14  arc_capacity_1489  -30
    arc_2_20_14  connected_order_arc_1490  -12
    arc_2_20_14  in_degree_1531  1
    arc_2_20_14  out_degree_1566  1
    arc_2_20_14  original_T_including_depot_unload_1574  4.9242827332511274e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_14  arc_capacity_1489  1
    load_2_20_14  free_load_conservation_1535  -1
    load_2_20_14  free_load_conservation_1571  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_15  arc_capacity_1491  -30
    arc_2_20_15  connected_order_arc_1492  -12
    arc_2_20_15  in_degree_1537  1
    arc_2_20_15  out_degree_1566  1
    arc_2_20_15  original_T_including_depot_unload_1574  1.7303231472353602e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_15  arc_capacity_1491  1
    load_2_20_15  free_load_conservation_1541  -1
    load_2_20_15  free_load_conservation_1571  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_16  arc_capacity_1493  -30
    arc_2_20_16  connected_order_arc_1494  -12
    arc_2_20_16  in_degree_1543  1
    arc_2_20_16  out_degree_1566  1
    arc_2_20_16  original_T_including_depot_unload_1574  2.2729932910497158e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_16  arc_capacity_1493  1
    load_2_20_16  free_load_conservation_1547  -1
    load_2_20_16  free_load_conservation_1571  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_17  arc_capacity_1495  -30
    arc_2_20_17  connected_order_arc_1496  -12
    arc_2_20_17  in_degree_1549  1
    arc_2_20_17  out_degree_1566  1
    arc_2_20_17  original_T_including_depot_unload_1574  2.0162129512771592e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_17  arc_capacity_1495  1
    load_2_20_17  free_load_conservation_1553  -1
    load_2_20_17  free_load_conservation_1571  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_18  arc_capacity_1497  -30
    arc_2_20_18  connected_order_arc_1498  -12
    arc_2_20_18  in_degree_1555  1
    arc_2_20_18  out_degree_1566  1
    arc_2_20_18  original_T_including_depot_unload_1574  4.4733407106545638e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_18  arc_capacity_1497  1
    load_2_20_18  free_load_conservation_1559  -1
    load_2_20_18  free_load_conservation_1571  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_19  arc_capacity_1499  -30
    arc_2_20_19  connected_order_arc_1500  -12
    arc_2_20_19  in_degree_1561  1
    arc_2_20_19  out_degree_1566  1
    arc_2_20_19  original_T_including_depot_unload_1574  1.3669225770244122e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_19  arc_capacity_1499  1
    load_2_20_19  free_load_conservation_1565  -1
    load_2_20_19  free_load_conservation_1571  1
RHS
    RHS1      OBJ       -0.579
    RHS1      onehot_3_36  1
    RHS1      onehot_1_79  1
    RHS1      onehot_31_108  1
    RHS1      onehot_7_147  1
    RHS1      onehot_32_176  1
    RHS1      onehot_4_211  1
    RHS1      onehot_19_232  1
    RHS1      onehot_10_275  1
    RHS1      stock_ub_279  45
    RHS1      parent_nonstrict_scope_280  2.9234040918067933e-01
    RHS1      normalization_337  1
    RHS1      connected_order_arc_474  -13
    RHS1      connected_order_arc_476  -13
    RHS1      connected_order_arc_478  -13
    RHS1      connected_order_arc_480  -13
    RHS1      connected_order_arc_482  -13
    RHS1      connected_order_arc_484  -13
    RHS1      connected_order_arc_486  -13
    RHS1      connected_order_arc_488  -13
    RHS1      connected_order_arc_490  -13
    RHS1      connected_order_arc_492  -13
    RHS1      connected_order_arc_494  -13
    RHS1      connected_order_arc_496  -13
    RHS1      connected_order_arc_499  -13
    RHS1      connected_order_arc_501  -13
    RHS1      connected_order_arc_503  -13
    RHS1      connected_order_arc_505  -13
    RHS1      connected_order_arc_507  -13
    RHS1      connected_order_arc_509  -13
    RHS1      connected_order_arc_511  -13
    RHS1      connected_order_arc_513  -13
    RHS1      connected_order_arc_515  -13
    RHS1      connected_order_arc_517  -13
    RHS1      connected_order_arc_519  -13
    RHS1      connected_order_arc_521  -13
    RHS1      connected_order_arc_524  -13
    RHS1      connected_order_arc_526  -13
    RHS1      connected_order_arc_528  -13
    RHS1      connected_order_arc_530  -13
    RHS1      connected_order_arc_532  -13
    RHS1      connected_order_arc_534  -13
    RHS1      connected_order_arc_536  -13
    RHS1      connected_order_arc_538  -13
    RHS1      connected_order_arc_540  -13
    RHS1      connected_order_arc_542  -13
    RHS1      connected_order_arc_544  -13
    RHS1      connected_order_arc_546  -13
    RHS1      connected_order_arc_549  -13
    RHS1      connected_order_arc_551  -13
    RHS1      connected_order_arc_553  -13
    RHS1      connected_order_arc_555  -13
    RHS1      connected_order_arc_557  -13
    RHS1      connected_order_arc_559  -13
    RHS1      connected_order_arc_561  -13
    RHS1      connected_order_arc_563  -13
    RHS1      connected_order_arc_565  -13
    RHS1      connected_order_arc_567  -13
    RHS1      connected_order_arc_569  -13
    RHS1      connected_order_arc_571  -13
    RHS1      connected_order_arc_574  -13
    RHS1      connected_order_arc_576  -13
    RHS1      connected_order_arc_578  -13
    RHS1      connected_order_arc_580  -13
    RHS1      connected_order_arc_582  -13
    RHS1      connected_order_arc_584  -13
    RHS1      connected_order_arc_586  -13
    RHS1      connected_order_arc_588  -13
    RHS1      connected_order_arc_590  -13
    RHS1      connected_order_arc_592  -13
    RHS1      connected_order_arc_594  -13
    RHS1      connected_order_arc_596  -13
    RHS1      connected_order_arc_599  -13
    RHS1      connected_order_arc_601  -13
    RHS1      connected_order_arc_603  -13
    RHS1      connected_order_arc_605  -13
    RHS1      connected_order_arc_607  -13
    RHS1      connected_order_arc_609  -13
    RHS1      connected_order_arc_611  -13
    RHS1      connected_order_arc_613  -13
    RHS1      connected_order_arc_615  -13
    RHS1      connected_order_arc_617  -13
    RHS1      connected_order_arc_619  -13
    RHS1      connected_order_arc_621  -13
    RHS1      connected_order_arc_624  -13
    RHS1      connected_order_arc_626  -13
    RHS1      connected_order_arc_628  -13
    RHS1      connected_order_arc_630  -13
    RHS1      connected_order_arc_632  -13
    RHS1      connected_order_arc_634  -13
    RHS1      connected_order_arc_636  -13
    RHS1      connected_order_arc_638  -13
    RHS1      connected_order_arc_640  -13
    RHS1      connected_order_arc_642  -13
    RHS1      connected_order_arc_644  -13
    RHS1      connected_order_arc_646  -13
    RHS1      connected_order_arc_649  -13
    RHS1      connected_order_arc_651  -13
    RHS1      connected_order_arc_653  -13
    RHS1      connected_order_arc_655  -13
    RHS1      connected_order_arc_657  -13
    RHS1      connected_order_arc_659  -13
    RHS1      connected_order_arc_661  -13
    RHS1      connected_order_arc_663  -13
    RHS1      connected_order_arc_665  -13
    RHS1      connected_order_arc_667  -13
    RHS1      connected_order_arc_669  -13
    RHS1      connected_order_arc_671  -13
    RHS1      connected_order_arc_674  -13
    RHS1      connected_order_arc_676  -13
    RHS1      connected_order_arc_678  -13
    RHS1      connected_order_arc_680  -13
    RHS1      connected_order_arc_682  -13
    RHS1      connected_order_arc_684  -13
    RHS1      connected_order_arc_686  -13
    RHS1      connected_order_arc_688  -13
    RHS1      connected_order_arc_690  -13
    RHS1      connected_order_arc_692  -13
    RHS1      connected_order_arc_694  -13
    RHS1      connected_order_arc_696  -13
    RHS1      connected_order_arc_699  -13
    RHS1      connected_order_arc_701  -13
    RHS1      connected_order_arc_703  -13
    RHS1      connected_order_arc_705  -13
    RHS1      connected_order_arc_707  -13
    RHS1      connected_order_arc_709  -13
    RHS1      connected_order_arc_711  -13
    RHS1      connected_order_arc_713  -13
    RHS1      connected_order_arc_715  -13
    RHS1      connected_order_arc_717  -13
    RHS1      connected_order_arc_719  -13
    RHS1      connected_order_arc_721  -13
    RHS1      connected_order_arc_724  -13
    RHS1      connected_order_arc_726  -13
    RHS1      connected_order_arc_728  -13
    RHS1      connected_order_arc_730  -13
    RHS1      connected_order_arc_732  -13
    RHS1      connected_order_arc_734  -13
    RHS1      connected_order_arc_736  -13
    RHS1      connected_order_arc_738  -13
    RHS1      connected_order_arc_740  -13
    RHS1      connected_order_arc_742  -13
    RHS1      connected_order_arc_744  -13
    RHS1      connected_order_arc_746  -13
    RHS1      connected_order_arc_749  -13
    RHS1      connected_order_arc_751  -13
    RHS1      connected_order_arc_753  -13
    RHS1      connected_order_arc_755  -13
    RHS1      connected_order_arc_757  -13
    RHS1      connected_order_arc_759  -13
    RHS1      connected_order_arc_761  -13
    RHS1      connected_order_arc_763  -13
    RHS1      connected_order_arc_765  -13
    RHS1      connected_order_arc_767  -13
    RHS1      connected_order_arc_769  -13
    RHS1      connected_order_arc_771  -13
    RHS1      connected_order_arc_774  -13
    RHS1      connected_order_arc_776  -13
    RHS1      connected_order_arc_778  -13
    RHS1      connected_order_arc_780  -13
    RHS1      connected_order_arc_782  -13
    RHS1      connected_order_arc_784  -13
    RHS1      connected_order_arc_786  -13
    RHS1      connected_order_arc_788  -13
    RHS1      connected_order_arc_790  -13
    RHS1      connected_order_arc_792  -13
    RHS1      connected_order_arc_794  -13
    RHS1      connected_order_arc_796  -13
    RHS1      depot_departure_or_bypass_797  1
    RHS1      depot_return_or_bypass_798  1
    RHS1      segment_load_conservation_803  2
    RHS1      segment_prefix_ub_805  18
    RHS1      segment_load_conservation_810  -5
    RHS1      segment_prefix_lb_811  5
    RHS1      segment_prefix_ub_812  20
    RHS1      segment_load_conservation_817  -5
    RHS1      segment_prefix_lb_818  5
    RHS1      segment_prefix_ub_819  20
    RHS1      segment_load_conservation_824  5
    RHS1      segment_prefix_ub_826  9
    RHS1      segment_load_conservation_831  -6
    RHS1      segment_prefix_lb_832  6
    RHS1      segment_prefix_ub_833  20
    RHS1      fixed_segment_relative_order_882  1
    RHS1      fixed_segment_relative_order_883  1
    RHS1      fixed_segment_relative_order_884  1
    RHS1      fixed_segment_relative_order_885  1
    RHS1      original_T_including_depot_unload_886  5.0953337810140947e+03
    RHS1      connected_order_arc_902  -12
    RHS1      connected_order_arc_904  -12
    RHS1      connected_order_arc_906  -12
    RHS1      connected_order_arc_908  -12
    RHS1      connected_order_arc_910  -12
    RHS1      connected_order_arc_912  -12
    RHS1      connected_order_arc_914  -12
    RHS1      connected_order_arc_916  -12
    RHS1      connected_order_arc_918  -12
    RHS1      connected_order_arc_920  -12
    RHS1      connected_order_arc_922  -12
    RHS1      connected_order_arc_925  -12
    RHS1      connected_order_arc_927  -12
    RHS1      connected_order_arc_929  -12
    RHS1      connected_order_arc_931  -12
    RHS1      connected_order_arc_933  -12
    RHS1      connected_order_arc_935  -12
    RHS1      connected_order_arc_937  -12
    RHS1      connected_order_arc_939  -12
    RHS1      connected_order_arc_941  -12
    RHS1      connected_order_arc_943  -12
    RHS1      connected_order_arc_945  -12
    RHS1      connected_order_arc_948  -12
    RHS1      connected_order_arc_950  -12
    RHS1      connected_order_arc_952  -12
    RHS1      connected_order_arc_954  -12
    RHS1      connected_order_arc_956  -12
    RHS1      connected_order_arc_958  -12
    RHS1      connected_order_arc_960  -12
    RHS1      connected_order_arc_962  -12
    RHS1      connected_order_arc_964  -12
    RHS1      connected_order_arc_966  -12
    RHS1      connected_order_arc_968  -12
    RHS1      connected_order_arc_971  -12
    RHS1      connected_order_arc_973  -12
    RHS1      connected_order_arc_975  -12
    RHS1      connected_order_arc_977  -12
    RHS1      connected_order_arc_979  -12
    RHS1      connected_order_arc_981  -12
    RHS1      connected_order_arc_983  -12
    RHS1      connected_order_arc_985  -12
    RHS1      connected_order_arc_987  -12
    RHS1      connected_order_arc_989  -12
    RHS1      connected_order_arc_991  -12
    RHS1      connected_order_arc_994  -12
    RHS1      connected_order_arc_996  -12
    RHS1      connected_order_arc_998  -12
    RHS1      connected_order_arc_1000  -12
    RHS1      connected_order_arc_1002  -12
    RHS1      connected_order_arc_1004  -12
    RHS1      connected_order_arc_1006  -12
    RHS1      connected_order_arc_1008  -12
    RHS1      connected_order_arc_1010  -12
    RHS1      connected_order_arc_1012  -12
    RHS1      connected_order_arc_1014  -12
    RHS1      connected_order_arc_1017  -12
    RHS1      connected_order_arc_1019  -12
    RHS1      connected_order_arc_1021  -12
    RHS1      connected_order_arc_1023  -12
    RHS1      connected_order_arc_1025  -12
    RHS1      connected_order_arc_1027  -12
    RHS1      connected_order_arc_1029  -12
    RHS1      connected_order_arc_1031  -12
    RHS1      connected_order_arc_1033  -12
    RHS1      connected_order_arc_1035  -12
    RHS1      connected_order_arc_1037  -12
    RHS1      connected_order_arc_1040  -12
    RHS1      connected_order_arc_1042  -12
    RHS1      connected_order_arc_1044  -12
    RHS1      connected_order_arc_1046  -12
    RHS1      connected_order_arc_1048  -12
    RHS1      connected_order_arc_1050  -12
    RHS1      connected_order_arc_1052  -12
    RHS1      connected_order_arc_1054  -12
    RHS1      connected_order_arc_1056  -12
    RHS1      connected_order_arc_1058  -12
    RHS1      connected_order_arc_1060  -12
    RHS1      connected_order_arc_1063  -12
    RHS1      connected_order_arc_1065  -12
    RHS1      connected_order_arc_1067  -12
    RHS1      connected_order_arc_1069  -12
    RHS1      connected_order_arc_1071  -12
    RHS1      connected_order_arc_1073  -12
    RHS1      connected_order_arc_1075  -12
    RHS1      connected_order_arc_1077  -12
    RHS1      connected_order_arc_1079  -12
    RHS1      connected_order_arc_1081  -12
    RHS1      connected_order_arc_1083  -12
    RHS1      connected_order_arc_1086  -12
    RHS1      connected_order_arc_1088  -12
    RHS1      connected_order_arc_1090  -12
    RHS1      connected_order_arc_1092  -12
    RHS1      connected_order_arc_1094  -12
    RHS1      connected_order_arc_1096  -12
    RHS1      connected_order_arc_1098  -12
    RHS1      connected_order_arc_1100  -12
    RHS1      connected_order_arc_1102  -12
    RHS1      connected_order_arc_1104  -12
    RHS1      connected_order_arc_1106  -12
    RHS1      connected_order_arc_1109  -12
    RHS1      connected_order_arc_1111  -12
    RHS1      connected_order_arc_1113  -12
    RHS1      connected_order_arc_1115  -12
    RHS1      connected_order_arc_1117  -12
    RHS1      connected_order_arc_1119  -12
    RHS1      connected_order_arc_1121  -12
    RHS1      connected_order_arc_1123  -12
    RHS1      connected_order_arc_1125  -12
    RHS1      connected_order_arc_1127  -12
    RHS1      connected_order_arc_1129  -12
    RHS1      connected_order_arc_1132  -12
    RHS1      connected_order_arc_1134  -12
    RHS1      connected_order_arc_1136  -12
    RHS1      connected_order_arc_1138  -12
    RHS1      connected_order_arc_1140  -12
    RHS1      connected_order_arc_1142  -12
    RHS1      connected_order_arc_1144  -12
    RHS1      connected_order_arc_1146  -12
    RHS1      connected_order_arc_1148  -12
    RHS1      connected_order_arc_1150  -12
    RHS1      connected_order_arc_1152  -12
    RHS1      connected_order_arc_1155  -12
    RHS1      connected_order_arc_1157  -12
    RHS1      connected_order_arc_1159  -12
    RHS1      connected_order_arc_1161  -12
    RHS1      connected_order_arc_1163  -12
    RHS1      connected_order_arc_1165  -12
    RHS1      connected_order_arc_1167  -12
    RHS1      connected_order_arc_1169  -12
    RHS1      connected_order_arc_1171  -12
    RHS1      connected_order_arc_1173  -12
    RHS1      connected_order_arc_1175  -12
    RHS1      depot_departure_or_bypass_1176  1
    RHS1      depot_return_or_bypass_1177  1
    RHS1      segment_load_conservation_1182  7
    RHS1      segment_prefix_ub_1184  18
    RHS1      segment_load_conservation_1189  -5
    RHS1      segment_prefix_lb_1190  5
    RHS1      segment_prefix_ub_1191  25
    RHS1      segment_load_conservation_1196  2
    RHS1      segment_prefix_lb_1197  2
    RHS1      segment_prefix_ub_1198  16
    RHS1      segment_load_conservation_1203  -4
    RHS1      segment_prefix_lb_1204  4
    RHS1      segment_prefix_ub_1205  25
    RHS1      fixed_segment_relative_order_1254  1
    RHS1      fixed_segment_relative_order_1255  1
    RHS1      fixed_segment_relative_order_1256  1
    RHS1      original_T_including_depot_unload_1257  2.5933514884265333e+03
    RHS1      connected_order_arc_1272  -11
    RHS1      connected_order_arc_1274  -11
    RHS1      connected_order_arc_1276  -11
    RHS1      connected_order_arc_1278  -11
    RHS1      connected_order_arc_1280  -11
    RHS1      connected_order_arc_1282  -11
    RHS1      connected_order_arc_1284  -11
    RHS1      connected_order_arc_1286  -11
    RHS1      connected_order_arc_1288  -11
    RHS1      connected_order_arc_1290  -11
    RHS1      connected_order_arc_1293  -11
    RHS1      connected_order_arc_1295  -11
    RHS1      connected_order_arc_1297  -11
    RHS1      connected_order_arc_1299  -11
    RHS1      connected_order_arc_1301  -11
    RHS1      connected_order_arc_1303  -11
    RHS1      connected_order_arc_1305  -11
    RHS1      connected_order_arc_1307  -11
    RHS1      connected_order_arc_1309  -11
    RHS1      connected_order_arc_1311  -11
    RHS1      connected_order_arc_1314  -11
    RHS1      connected_order_arc_1316  -11
    RHS1      connected_order_arc_1318  -11
    RHS1      connected_order_arc_1320  -11
    RHS1      connected_order_arc_1322  -11
    RHS1      connected_order_arc_1324  -11
    RHS1      connected_order_arc_1326  -11
    RHS1      connected_order_arc_1328  -11
    RHS1      connected_order_arc_1330  -11
    RHS1      connected_order_arc_1332  -11
    RHS1      connected_order_arc_1335  -11
    RHS1      connected_order_arc_1337  -11
    RHS1      connected_order_arc_1339  -11
    RHS1      connected_order_arc_1341  -11
    RHS1      connected_order_arc_1343  -11
    RHS1      connected_order_arc_1345  -11
    RHS1      connected_order_arc_1347  -11
    RHS1      connected_order_arc_1349  -11
    RHS1      connected_order_arc_1351  -11
    RHS1      connected_order_arc_1353  -11
    RHS1      connected_order_arc_1356  -11
    RHS1      connected_order_arc_1358  -11
    RHS1      connected_order_arc_1360  -11
    RHS1      connected_order_arc_1362  -11
    RHS1      connected_order_arc_1364  -11
    RHS1      connected_order_arc_1366  -11
    RHS1      connected_order_arc_1368  -11
    RHS1      connected_order_arc_1370  -11
    RHS1      connected_order_arc_1372  -11
    RHS1      connected_order_arc_1374  -11
    RHS1      connected_order_arc_1377  -11
    RHS1      connected_order_arc_1379  -11
    RHS1      connected_order_arc_1381  -11
    RHS1      connected_order_arc_1383  -11
    RHS1      connected_order_arc_1385  -11
    RHS1      connected_order_arc_1387  -11
    RHS1      connected_order_arc_1389  -11
    RHS1      connected_order_arc_1391  -11
    RHS1      connected_order_arc_1393  -11
    RHS1      connected_order_arc_1395  -11
    RHS1      connected_order_arc_1398  -11
    RHS1      connected_order_arc_1400  -11
    RHS1      connected_order_arc_1402  -11
    RHS1      connected_order_arc_1404  -11
    RHS1      connected_order_arc_1406  -11
    RHS1      connected_order_arc_1408  -11
    RHS1      connected_order_arc_1410  -11
    RHS1      connected_order_arc_1412  -11
    RHS1      connected_order_arc_1414  -11
    RHS1      connected_order_arc_1416  -11
    RHS1      connected_order_arc_1419  -11
    RHS1      connected_order_arc_1421  -11
    RHS1      connected_order_arc_1423  -11
    RHS1      connected_order_arc_1425  -11
    RHS1      connected_order_arc_1427  -11
    RHS1      connected_order_arc_1429  -11
    RHS1      connected_order_arc_1431  -11
    RHS1      connected_order_arc_1433  -11
    RHS1      connected_order_arc_1435  -11
    RHS1      connected_order_arc_1437  -11
    RHS1      connected_order_arc_1440  -11
    RHS1      connected_order_arc_1442  -11
    RHS1      connected_order_arc_1444  -11
    RHS1      connected_order_arc_1446  -11
    RHS1      connected_order_arc_1448  -11
    RHS1      connected_order_arc_1450  -11
    RHS1      connected_order_arc_1452  -11
    RHS1      connected_order_arc_1454  -11
    RHS1      connected_order_arc_1456  -11
    RHS1      connected_order_arc_1458  -11
    RHS1      connected_order_arc_1461  -11
    RHS1      connected_order_arc_1463  -11
    RHS1      connected_order_arc_1465  -11
    RHS1      connected_order_arc_1467  -11
    RHS1      connected_order_arc_1469  -11
    RHS1      connected_order_arc_1471  -11
    RHS1      connected_order_arc_1473  -11
    RHS1      connected_order_arc_1475  -11
    RHS1      connected_order_arc_1477  -11
    RHS1      connected_order_arc_1479  -11
    RHS1      connected_order_arc_1482  -11
    RHS1      connected_order_arc_1484  -11
    RHS1      connected_order_arc_1486  -11
    RHS1      connected_order_arc_1488  -11
    RHS1      connected_order_arc_1490  -11
    RHS1      connected_order_arc_1492  -11
    RHS1      connected_order_arc_1494  -11
    RHS1      connected_order_arc_1496  -11
    RHS1      connected_order_arc_1498  -11
    RHS1      connected_order_arc_1500  -11
    RHS1      depot_departure_or_bypass_1501  1
    RHS1      depot_return_or_bypass_1502  1
    RHS1      segment_load_conservation_1507  1
    RHS1      segment_prefix_ub_1509  24
    RHS1      segment_load_conservation_1514  4
    RHS1      segment_prefix_ub_1516  26
    RHS1      segment_load_conservation_1521  -5
    RHS1      segment_prefix_lb_1522  5
    RHS1      segment_prefix_ub_1523  30
    RHS1      fixed_segment_relative_order_1572  1
    RHS1      fixed_segment_relative_order_1573  1
    RHS1      original_T_including_depot_unload_1574  3.4285204222867415e+03
BOUNDS
 LO BND1      t         2.5263157894711577e-02
 UP BND1      t         0.042962356792187
 UP BND1      q         4.9634040918067934e-01
 BV BND1      x_3_0   
 UP BND1      w_3_0     0.042962356792187
 BV BND1      x_3_1   
 UP BND1      w_3_1     0.042962356792187
 BV BND1      x_3_2   
 UP BND1      w_3_2     0.042962356792187
 BV BND1      x_3_3   
 UP BND1      w_3_3     0.042962356792187
 BV BND1      x_3_4   
 UP BND1      w_3_4     0.042962356792187
 BV BND1      x_3_5   
 UP BND1      w_3_5     0.042962356792187
 BV BND1      x_3_6   
 UP BND1      w_3_6     0.042962356792187
 BV BND1      x_3_7   
 UP BND1      w_3_7     0.042962356792187
 BV BND1      x_3_8   
 UP BND1      w_3_8     0.042962356792187
 BV BND1      x_3_9   
 UP BND1      w_3_9     0.042962356792187
 BV BND1      x_3_10  
 UP BND1      w_3_10    0.042962356792187
 BV BND1      x_3_11  
 UP BND1      w_3_11    0.042962356792187
 BV BND1      x_3_12  
 UP BND1      w_3_12    0.042962356792187
 BV BND1      x_3_13  
 UP BND1      w_3_13    0.042962356792187
 BV BND1      x_3_14  
 UP BND1      w_3_14    0.042962356792187
 BV BND1      x_3_15  
 UP BND1      w_3_15    0.042962356792187
 BV BND1      x_3_16  
 UP BND1      w_3_16    0.042962356792187
 BV BND1      x_3_17  
 UP BND1      w_3_17    0.042962356792187
 UP BND1      rho_3     1
 BV BND1      x_1_0   
 UP BND1      w_1_0     0.042962356792187
 BV BND1      x_1_1   
 UP BND1      w_1_1     0.042962356792187
 BV BND1      x_1_2   
 UP BND1      w_1_2     0.042962356792187
 BV BND1      x_1_3   
 UP BND1      w_1_3     0.042962356792187
 BV BND1      x_1_4   
 UP BND1      w_1_4     0.042962356792187
 BV BND1      x_1_5   
 UP BND1      w_1_5     0.042962356792187
 BV BND1      x_1_6   
 UP BND1      w_1_6     0.042962356792187
 BV BND1      x_1_7   
 UP BND1      w_1_7     0.042962356792187
 BV BND1      x_1_8   
 UP BND1      w_1_8     0.042962356792187
 BV BND1      x_1_9   
 UP BND1      w_1_9     0.042962356792187
 BV BND1      x_1_10  
 UP BND1      w_1_10    0.042962356792187
 BV BND1      x_1_11  
 UP BND1      w_1_11    0.042962356792187
 BV BND1      x_1_12  
 UP BND1      w_1_12    0.042962356792187
 BV BND1      x_1_13  
 UP BND1      w_1_13    0.042962356792187
 BV BND1      x_1_14  
 UP BND1      w_1_14    0.042962356792187
 BV BND1      x_1_15  
 UP BND1      w_1_15    0.042962356792187
 BV BND1      x_1_16  
 UP BND1      w_1_16    0.042962356792187
 BV BND1      x_1_17  
 UP BND1      w_1_17    0.042962356792187
 BV BND1      x_1_18  
 UP BND1      w_1_18    0.042962356792187
 BV BND1      x_1_19  
 UP BND1      w_1_19    0.042962356792187
 UP BND1      rho_1     1
 BV BND1      x_31_0  
 UP BND1      w_31_0    0.042962356792187
 BV BND1      x_31_1  
 UP BND1      w_31_1    0.042962356792187
 BV BND1      x_31_2  
 UP BND1      w_31_2    0.042962356792187
 BV BND1      x_31_3  
 UP BND1      w_31_3    0.042962356792187
 BV BND1      x_31_4  
 UP BND1      w_31_4    0.042962356792187
 BV BND1      x_31_5  
 UP BND1      w_31_5    0.042962356792187
 BV BND1      x_31_6  
 UP BND1      w_31_6    0.042962356792187
 BV BND1      x_31_7  
 UP BND1      w_31_7    0.042962356792187
 BV BND1      x_31_8  
 UP BND1      w_31_8    0.042962356792187
 BV BND1      x_31_9  
 UP BND1      w_31_9    0.042962356792187
 BV BND1      x_31_10 
 UP BND1      w_31_10   0.042962356792187
 BV BND1      x_31_11 
 UP BND1      w_31_11   0.042962356792187
 BV BND1      x_31_12 
 UP BND1      w_31_12   0.042962356792187
 UP BND1      rho_31    1
 BV BND1      x_7_0   
 UP BND1      w_7_0     0.042962356792187
 BV BND1      x_7_1   
 UP BND1      w_7_1     0.042962356792187
 BV BND1      x_7_2   
 UP BND1      w_7_2     0.042962356792187
 BV BND1      x_7_3   
 UP BND1      w_7_3     0.042962356792187
 BV BND1      x_7_4   
 UP BND1      w_7_4     0.042962356792187
 BV BND1      x_7_5   
 UP BND1      w_7_5     0.042962356792187
 BV BND1      x_7_6   
 UP BND1      w_7_6     0.042962356792187
 BV BND1      x_7_7   
 UP BND1      w_7_7     0.042962356792187
 BV BND1      x_7_8   
 UP BND1      w_7_8     0.042962356792187
 BV BND1      x_7_9   
 UP BND1      w_7_9     0.042962356792187
 BV BND1      x_7_10  
 UP BND1      w_7_10    0.042962356792187
 BV BND1      x_7_11  
 UP BND1      w_7_11    0.042962356792187
 BV BND1      x_7_12  
 UP BND1      w_7_12    0.042962356792187
 BV BND1      x_7_13  
 UP BND1      w_7_13    0.042962356792187
 BV BND1      x_7_14  
 UP BND1      w_7_14    0.042962356792187
 BV BND1      x_7_15  
 UP BND1      w_7_15    0.042962356792187
 BV BND1      x_7_16  
 UP BND1      w_7_16    0.042962356792187
 BV BND1      x_7_17  
 UP BND1      w_7_17    0.042962356792187
 UP BND1      rho_7     1
 BV BND1      x_32_0  
 UP BND1      w_32_0    0.042962356792187
 BV BND1      x_32_1  
 UP BND1      w_32_1    0.042962356792187
 BV BND1      x_32_2  
 UP BND1      w_32_2    0.042962356792187
 BV BND1      x_32_3  
 UP BND1      w_32_3    0.042962356792187
 BV BND1      x_32_4  
 UP BND1      w_32_4    0.042962356792187
 BV BND1      x_32_5  
 UP BND1      w_32_5    0.042962356792187
 BV BND1      x_32_6  
 UP BND1      w_32_6    0.042962356792187
 BV BND1      x_32_7  
 UP BND1      w_32_7    0.042962356792187
 BV BND1      x_32_8  
 UP BND1      w_32_8    0.042962356792187
 BV BND1      x_32_9  
 UP BND1      w_32_9    0.042962356792187
 BV BND1      x_32_10 
 UP BND1      w_32_10   0.042962356792187
 BV BND1      x_32_11 
 UP BND1      w_32_11   0.042962356792187
 BV BND1      x_32_12 
 UP BND1      w_32_12   0.042962356792187
 UP BND1      rho_32    1
 BV BND1      x_4_0   
 UP BND1      w_4_0     0.042962356792187
 BV BND1      x_4_1   
 UP BND1      w_4_1     0.042962356792187
 BV BND1      x_4_2   
 UP BND1      w_4_2     0.042962356792187
 BV BND1      x_4_3   
 UP BND1      w_4_3     0.042962356792187
 BV BND1      x_4_4   
 UP BND1      w_4_4     0.042962356792187
 BV BND1      x_4_5   
 UP BND1      w_4_5     0.042962356792187
 BV BND1      x_4_6   
 UP BND1      w_4_6     0.042962356792187
 BV BND1      x_4_7   
 UP BND1      w_4_7     0.042962356792187
 BV BND1      x_4_8   
 UP BND1      w_4_8     0.042962356792187
 BV BND1      x_4_9   
 UP BND1      w_4_9     0.042962356792187
 BV BND1      x_4_10  
 UP BND1      w_4_10    0.042962356792187
 BV BND1      x_4_11  
 UP BND1      w_4_11    0.042962356792187
 BV BND1      x_4_12  
 UP BND1      w_4_12    0.042962356792187
 BV BND1      x_4_13  
 UP BND1      w_4_13    0.042962356792187
 BV BND1      x_4_14  
 UP BND1      w_4_14    0.042962356792187
 BV BND1      x_4_15  
 UP BND1      w_4_15    0.042962356792187
 UP BND1      rho_4     1
 BV BND1      x_19_0  
 UP BND1      w_19_0    0.042962356792187
 BV BND1      x_19_1  
 UP BND1      w_19_1    0.042962356792187
 BV BND1      x_19_2  
 UP BND1      w_19_2    0.042962356792187
 BV BND1      x_19_3  
 UP BND1      w_19_3    0.042962356792187
 BV BND1      x_19_4  
 UP BND1      w_19_4    0.042962356792187
 BV BND1      x_19_5  
 UP BND1      w_19_5    0.042962356792187
 BV BND1      x_19_6  
 UP BND1      w_19_6    0.042962356792187
 BV BND1      x_19_7  
 UP BND1      w_19_7    0.042962356792187
 BV BND1      x_19_8  
 UP BND1      w_19_8    0.042962356792187
 UP BND1      rho_19    1
 BV BND1      x_10_0  
 UP BND1      w_10_0    0.042962356792187
 BV BND1      x_10_1  
 UP BND1      w_10_1    0.042962356792187
 BV BND1      x_10_2  
 UP BND1      w_10_2    0.042962356792187
 BV BND1      x_10_3  
 UP BND1      w_10_3    0.042962356792187
 BV BND1      x_10_4  
 UP BND1      w_10_4    0.042962356792187
 BV BND1      x_10_5  
 UP BND1      w_10_5    0.042962356792187
 BV BND1      x_10_6  
 UP BND1      w_10_6    0.042962356792187
 BV BND1      x_10_7  
 UP BND1      w_10_7    0.042962356792187
 BV BND1      x_10_8  
 UP BND1      w_10_8    0.042962356792187
 BV BND1      x_10_9  
 UP BND1      w_10_9    0.042962356792187
 BV BND1      x_10_10 
 UP BND1      w_10_10   0.042962356792187
 BV BND1      x_10_11 
 UP BND1      w_10_11   0.042962356792187
 BV BND1      x_10_12 
 UP BND1      w_10_12   0.042962356792187
 BV BND1      x_10_13 
 UP BND1      w_10_13   0.042962356792187
 BV BND1      x_10_14 
 UP BND1      w_10_14   0.042962356792187
 BV BND1      x_10_15 
 UP BND1      w_10_15   0.042962356792187
 BV BND1      x_10_16 
 UP BND1      w_10_16   0.042962356792187
 BV BND1      x_10_17 
 UP BND1      w_10_17   0.042962356792187
 BV BND1      x_10_18 
 UP BND1      w_10_18   0.042962356792187
 BV BND1      x_10_19 
 UP BND1      w_10_19   0.042962356792187
 UP BND1      rho_10    1
 UP BND1      a_3_1     1
 UP BND1      a_3_31    1
 UP BND1      a_3_7     1
 UP BND1      a_3_32    1
 UP BND1      a_3_4     1
 UP BND1      a_3_19    1
 UP BND1      a_3_10    1
 UP BND1      a_1_31    1
 UP BND1      a_1_7     1
 UP BND1      a_1_32    1
 UP BND1      a_1_4     1
 UP BND1      a_1_19    1
 UP BND1      a_1_10    1
 UP BND1      a_31_7    1
 UP BND1      a_31_32   1
 UP BND1      a_31_4    1
 UP BND1      a_31_19   1
 UP BND1      a_31_10   1
 UP BND1      a_7_32    1
 UP BND1      a_7_4     1
 UP BND1      a_7_19    1
 UP BND1      a_7_10    1
 UP BND1      a_32_4    1
 UP BND1      a_32_19   1
 UP BND1      a_32_10   1
 UP BND1      a_4_19    1
 UP BND1      a_4_10    1
 UP BND1      a_19_10   1
 BV BND1      service_0_3_0
 BV BND1      service_0_3_1
 BV BND1      service_0_3_2
 BV BND1      service_0_3_3
 BV BND1      service_0_3_4
 BV BND1      service_0_3_5
 BV BND1      service_0_3_6
 BV BND1      service_0_3_7
 BV BND1      service_0_3_8
 BV BND1      service_0_3_9
 BV BND1      service_0_3_10
 BV BND1      service_0_3_11
 BV BND1      service_0_3_13
 BV BND1      service_0_3_14
 BV BND1      service_0_3_15
 BV BND1      service_0_3_16
 BV BND1      service_0_3_17
 BV BND1      service_1_3_0
 BV BND1      service_1_3_1
 BV BND1      service_1_3_2
 BV BND1      service_1_3_3
 BV BND1      service_1_3_4
 BV BND1      service_1_3_5
 BV BND1      service_1_3_6
 BV BND1      service_1_3_7
 BV BND1      service_1_3_8
 BV BND1      service_1_3_9
 BV BND1      service_1_3_10
 BV BND1      service_1_3_11
 BV BND1      service_1_3_13
 BV BND1      service_1_3_14
 BV BND1      service_1_3_15
 BV BND1      service_1_3_16
 BV BND1      service_1_3_17
 BV BND1      service_2_3_0
 BV BND1      service_2_3_1
 BV BND1      service_2_3_2
 BV BND1      service_2_3_3
 BV BND1      service_2_3_4
 BV BND1      service_2_3_5
 BV BND1      service_2_3_6
 BV BND1      service_2_3_7
 BV BND1      service_2_3_8
 BV BND1      service_2_3_9
 BV BND1      service_2_3_10
 BV BND1      service_2_3_11
 BV BND1      service_2_3_13
 BV BND1      service_2_3_14
 BV BND1      service_2_3_15
 BV BND1      service_2_3_16
 BV BND1      service_2_3_17
 BV BND1      service_0_1_0
 BV BND1      service_0_1_1
 BV BND1      service_0_1_3
 BV BND1      service_0_1_4
 BV BND1      service_0_1_5
 BV BND1      service_0_1_6
 BV BND1      service_0_1_7
 BV BND1      service_0_1_8
 BV BND1      service_0_1_9
 BV BND1      service_0_1_10
 BV BND1      service_0_1_11
 BV BND1      service_0_1_12
 BV BND1      service_0_1_13
 BV BND1      service_0_1_14
 BV BND1      service_0_1_15
 BV BND1      service_0_1_16
 BV BND1      service_0_1_17
 BV BND1      service_0_1_18
 BV BND1      service_0_1_19
 BV BND1      service_1_1_0
 BV BND1      service_1_1_1
 BV BND1      service_1_1_3
 BV BND1      service_1_1_4
 BV BND1      service_1_1_5
 BV BND1      service_1_1_6
 BV BND1      service_1_1_7
 BV BND1      service_1_1_8
 BV BND1      service_1_1_9
 BV BND1      service_1_1_10
 BV BND1      service_1_1_11
 BV BND1      service_1_1_12
 BV BND1      service_1_1_13
 BV BND1      service_1_1_14
 BV BND1      service_1_1_15
 BV BND1      service_1_1_16
 BV BND1      service_1_1_17
 BV BND1      service_1_1_18
 BV BND1      service_1_1_19
 BV BND1      service_2_1_0
 BV BND1      service_2_1_1
 BV BND1      service_2_1_3
 BV BND1      service_2_1_4
 BV BND1      service_2_1_5
 BV BND1      service_2_1_6
 BV BND1      service_2_1_7
 BV BND1      service_2_1_8
 BV BND1      service_2_1_9
 BV BND1      service_2_1_10
 BV BND1      service_2_1_11
 BV BND1      service_2_1_12
 BV BND1      service_2_1_13
 BV BND1      service_2_1_14
 BV BND1      service_2_1_15
 BV BND1      service_2_1_16
 BV BND1      service_2_1_17
 BV BND1      service_2_1_18
 BV BND1      service_2_1_19
 BV BND1      service_0_31_0
 BV BND1      service_0_31_1
 BV BND1      service_0_31_3
 BV BND1      service_0_31_4
 BV BND1      service_0_31_5
 BV BND1      service_0_31_6
 BV BND1      service_0_31_7
 BV BND1      service_0_31_8
 BV BND1      service_0_31_9
 BV BND1      service_0_31_10
 BV BND1      service_0_31_11
 BV BND1      service_0_31_12
 BV BND1      service_1_31_0
 BV BND1      service_1_31_1
 BV BND1      service_1_31_3
 BV BND1      service_1_31_4
 BV BND1      service_1_31_5
 BV BND1      service_1_31_6
 BV BND1      service_1_31_7
 BV BND1      service_1_31_8
 BV BND1      service_1_31_9
 BV BND1      service_1_31_10
 BV BND1      service_1_31_11
 BV BND1      service_1_31_12
 BV BND1      service_2_31_0
 BV BND1      service_2_31_1
 BV BND1      service_2_31_3
 BV BND1      service_2_31_4
 BV BND1      service_2_31_5
 BV BND1      service_2_31_6
 BV BND1      service_2_31_7
 BV BND1      service_2_31_8
 BV BND1      service_2_31_9
 BV BND1      service_2_31_10
 BV BND1      service_2_31_11
 BV BND1      service_2_31_12
 BV BND1      service_0_7_0
 BV BND1      service_0_7_1
 BV BND1      service_0_7_2
 BV BND1      service_0_7_3
 BV BND1      service_0_7_4
 BV BND1      service_0_7_5
 BV BND1      service_0_7_6
 BV BND1      service_0_7_7
 BV BND1      service_0_7_8
 BV BND1      service_0_7_9
 BV BND1      service_0_7_10
 BV BND1      service_0_7_11
 BV BND1      service_0_7_13
 BV BND1      service_0_7_14
 BV BND1      service_0_7_15
 BV BND1      service_0_7_16
 BV BND1      service_0_7_17
 BV BND1      service_1_7_0
 BV BND1      service_1_7_1
 BV BND1      service_1_7_2
 BV BND1      service_1_7_3
 BV BND1      service_1_7_4
 BV BND1      service_1_7_5
 BV BND1      service_1_7_6
 BV BND1      service_1_7_7
 BV BND1      service_1_7_8
 BV BND1      service_1_7_9
 BV BND1      service_1_7_10
 BV BND1      service_1_7_11
 BV BND1      service_1_7_13
 BV BND1      service_1_7_14
 BV BND1      service_1_7_15
 BV BND1      service_1_7_16
 BV BND1      service_1_7_17
 BV BND1      service_2_7_0
 BV BND1      service_2_7_1
 BV BND1      service_2_7_2
 BV BND1      service_2_7_3
 BV BND1      service_2_7_4
 BV BND1      service_2_7_5
 BV BND1      service_2_7_6
 BV BND1      service_2_7_7
 BV BND1      service_2_7_8
 BV BND1      service_2_7_9
 BV BND1      service_2_7_10
 BV BND1      service_2_7_11
 BV BND1      service_2_7_13
 BV BND1      service_2_7_14
 BV BND1      service_2_7_15
 BV BND1      service_2_7_16
 BV BND1      service_2_7_17
 BV BND1      service_0_32_1
 BV BND1      service_0_32_2
 BV BND1      service_0_32_3
 BV BND1      service_0_32_4
 BV BND1      service_0_32_5
 BV BND1      service_0_32_6
 BV BND1      service_0_32_7
 BV BND1      service_0_32_8
 BV BND1      service_0_32_9
 BV BND1      service_0_32_10
 BV BND1      service_0_32_11
 BV BND1      service_0_32_12
 BV BND1      service_1_32_1
 BV BND1      service_1_32_2
 BV BND1      service_1_32_3
 BV BND1      service_1_32_4
 BV BND1      service_1_32_5
 BV BND1      service_1_32_6
 BV BND1      service_1_32_7
 BV BND1      service_1_32_8
 BV BND1      service_1_32_9
 BV BND1      service_1_32_10
 BV BND1      service_1_32_11
 BV BND1      service_1_32_12
 BV BND1      service_2_32_1
 BV BND1      service_2_32_2
 BV BND1      service_2_32_3
 BV BND1      service_2_32_4
 BV BND1      service_2_32_5
 BV BND1      service_2_32_6
 BV BND1      service_2_32_7
 BV BND1      service_2_32_8
 BV BND1      service_2_32_9
 BV BND1      service_2_32_10
 BV BND1      service_2_32_11
 BV BND1      service_2_32_12
 BV BND1      service_0_4_0
 BV BND1      service_0_4_1
 BV BND1      service_0_4_2
 BV BND1      service_0_4_3
 BV BND1      service_0_4_4
 BV BND1      service_0_4_5
 BV BND1      service_0_4_6
 BV BND1      service_0_4_7
 BV BND1      service_0_4_8
 BV BND1      service_0_4_9
 BV BND1      service_0_4_10
 BV BND1      service_0_4_12
 BV BND1      service_0_4_13
 BV BND1      service_0_4_14
 BV BND1      service_0_4_15
 BV BND1      service_1_4_0
 BV BND1      service_1_4_1
 BV BND1      service_1_4_2
 BV BND1      service_1_4_3
 BV BND1      service_1_4_4
 BV BND1      service_1_4_5
 BV BND1      service_1_4_6
 BV BND1      service_1_4_7
 BV BND1      service_1_4_8
 BV BND1      service_1_4_9
 BV BND1      service_1_4_10
 BV BND1      service_1_4_12
 BV BND1      service_1_4_13
 BV BND1      service_1_4_14
 BV BND1      service_1_4_15
 BV BND1      service_2_4_0
 BV BND1      service_2_4_1
 BV BND1      service_2_4_2
 BV BND1      service_2_4_3
 BV BND1      service_2_4_4
 BV BND1      service_2_4_5
 BV BND1      service_2_4_6
 BV BND1      service_2_4_7
 BV BND1      service_2_4_8
 BV BND1      service_2_4_9
 BV BND1      service_2_4_10
 BV BND1      service_2_4_12
 BV BND1      service_2_4_13
 BV BND1      service_2_4_14
 BV BND1      service_2_4_15
 BV BND1      service_0_19_1
 BV BND1      service_0_19_2
 BV BND1      service_0_19_3
 BV BND1      service_0_19_4
 BV BND1      service_0_19_5
 BV BND1      service_0_19_6
 BV BND1      service_0_19_7
 BV BND1      service_0_19_8
 BV BND1      service_1_19_1
 BV BND1      service_1_19_2
 BV BND1      service_1_19_3
 BV BND1      service_1_19_4
 BV BND1      service_1_19_5
 BV BND1      service_1_19_6
 BV BND1      service_1_19_7
 BV BND1      service_1_19_8
 BV BND1      service_2_19_1
 BV BND1      service_2_19_2
 BV BND1      service_2_19_3
 BV BND1      service_2_19_4
 BV BND1      service_2_19_5
 BV BND1      service_2_19_6
 BV BND1      service_2_19_7
 BV BND1      service_2_19_8
 BV BND1      service_0_10_0
 BV BND1      service_0_10_1
 BV BND1      service_0_10_2
 BV BND1      service_0_10_3
 BV BND1      service_0_10_4
 BV BND1      service_0_10_5
 BV BND1      service_0_10_6
 BV BND1      service_0_10_7
 BV BND1      service_0_10_8
 BV BND1      service_0_10_9
 BV BND1      service_0_10_10
 BV BND1      service_0_10_11
 BV BND1      service_0_10_12
 BV BND1      service_0_10_13
 BV BND1      service_0_10_14
 BV BND1      service_0_10_16
 BV BND1      service_0_10_17
 BV BND1      service_0_10_18
 BV BND1      service_0_10_19
 BV BND1      service_1_10_0
 BV BND1      service_1_10_1
 BV BND1      service_1_10_2
 BV BND1      service_1_10_3
 BV BND1      service_1_10_4
 BV BND1      service_1_10_5
 BV BND1      service_1_10_6
 BV BND1      service_1_10_7
 BV BND1      service_1_10_8
 BV BND1      service_1_10_9
 BV BND1      service_1_10_10
 BV BND1      service_1_10_11
 BV BND1      service_1_10_12
 BV BND1      service_1_10_13
 BV BND1      service_1_10_14
 BV BND1      service_1_10_16
 BV BND1      service_1_10_17
 BV BND1      service_1_10_18
 BV BND1      service_1_10_19
 BV BND1      service_2_10_0
 BV BND1      service_2_10_1
 BV BND1      service_2_10_2
 BV BND1      service_2_10_3
 BV BND1      service_2_10_4
 BV BND1      service_2_10_5
 BV BND1      service_2_10_6
 BV BND1      service_2_10_7
 BV BND1      service_2_10_8
 BV BND1      service_2_10_9
 BV BND1      service_2_10_10
 BV BND1      service_2_10_11
 BV BND1      service_2_10_12
 BV BND1      service_2_10_13
 BV BND1      service_2_10_14
 BV BND1      service_2_10_16
 BV BND1      service_2_10_17
 BV BND1      service_2_10_18
 BV BND1      service_2_10_19
 FX BND1      visit_0_1  1
 UP BND1      order_0_1  13
 FX BND1      visit_0_2  1
 UP BND1      order_0_2  13
 FX BND1      visit_0_3  1
 UP BND1      order_0_3  13
 FX BND1      visit_0_4  1
 UP BND1      order_0_4  13
 FX BND1      visit_0_5  1
 UP BND1      order_0_5  13
 UP BND1      visit_0_13  1
 UP BND1      order_0_13  13
 UP BND1      visit_0_14  1
 UP BND1      order_0_14  13
 UP BND1      visit_0_15  1
 UP BND1      order_0_15  13
 UP BND1      visit_0_16  1
 UP BND1      order_0_16  13
 UP BND1      visit_0_17  1
 UP BND1      order_0_17  13
 UP BND1      visit_0_18  1
 UP BND1      order_0_18  13
 UP BND1      visit_0_19  1
 UP BND1      order_0_19  13
 UP BND1      visit_0_20  1
 UP BND1      order_0_20  13
 BV BND1      arc_0_0_0
 FX BND1      load_0_0_0  0
 BV BND1      arc_0_0_1
 FX BND1      load_0_0_1  0
 BV BND1      arc_0_0_2
 FX BND1      load_0_0_2  0
 BV BND1      arc_0_0_3
 FX BND1      load_0_0_3  0
 BV BND1      arc_0_0_4
 FX BND1      load_0_0_4  0
 BV BND1      arc_0_0_5
 FX BND1      load_0_0_5  0
 BV BND1      arc_0_0_13
 FX BND1      load_0_0_13  0
 BV BND1      arc_0_0_14
 FX BND1      load_0_0_14  0
 BV BND1      arc_0_0_15
 FX BND1      load_0_0_15  0
 BV BND1      arc_0_0_16
 FX BND1      load_0_0_16  0
 BV BND1      arc_0_0_17
 FX BND1      load_0_0_17  0
 BV BND1      arc_0_0_18
 FX BND1      load_0_0_18  0
 BV BND1      arc_0_0_19
 FX BND1      load_0_0_19  0
 BV BND1      arc_0_0_20
 FX BND1      load_0_0_20  0
 BV BND1      arc_0_1_0
 UP BND1      load_0_1_0  20
 BV BND1      arc_0_1_2
 UP BND1      load_0_1_2  20
 BV BND1      arc_0_1_3
 UP BND1      load_0_1_3  20
 BV BND1      arc_0_1_4
 UP BND1      load_0_1_4  20
 BV BND1      arc_0_1_5
 UP BND1      load_0_1_5  20
 BV BND1      arc_0_1_13
 UP BND1      load_0_1_13  20
 BV BND1      arc_0_1_14
 UP BND1      load_0_1_14  20
 BV BND1      arc_0_1_15
 UP BND1      load_0_1_15  20
 BV BND1      arc_0_1_16
 UP BND1      load_0_1_16  20
 BV BND1      arc_0_1_17
 UP BND1      load_0_1_17  20
 BV BND1      arc_0_1_18
 UP BND1      load_0_1_18  20
 BV BND1      arc_0_1_19
 UP BND1      load_0_1_19  20
 BV BND1      arc_0_1_20
 UP BND1      load_0_1_20  20
 BV BND1      arc_0_2_0
 UP BND1      load_0_2_0  20
 BV BND1      arc_0_2_1
 UP BND1      load_0_2_1  20
 BV BND1      arc_0_2_3
 UP BND1      load_0_2_3  20
 BV BND1      arc_0_2_4
 UP BND1      load_0_2_4  20
 BV BND1      arc_0_2_5
 UP BND1      load_0_2_5  20
 BV BND1      arc_0_2_13
 UP BND1      load_0_2_13  20
 BV BND1      arc_0_2_14
 UP BND1      load_0_2_14  20
 BV BND1      arc_0_2_15
 UP BND1      load_0_2_15  20
 BV BND1      arc_0_2_16
 UP BND1      load_0_2_16  20
 BV BND1      arc_0_2_17
 UP BND1      load_0_2_17  20
 BV BND1      arc_0_2_18
 UP BND1      load_0_2_18  20
 BV BND1      arc_0_2_19
 UP BND1      load_0_2_19  20
 BV BND1      arc_0_2_20
 UP BND1      load_0_2_20  20
 BV BND1      arc_0_3_0
 UP BND1      load_0_3_0  20
 BV BND1      arc_0_3_1
 UP BND1      load_0_3_1  20
 BV BND1      arc_0_3_2
 UP BND1      load_0_3_2  20
 BV BND1      arc_0_3_4
 UP BND1      load_0_3_4  20
 BV BND1      arc_0_3_5
 UP BND1      load_0_3_5  20
 BV BND1      arc_0_3_13
 UP BND1      load_0_3_13  20
 BV BND1      arc_0_3_14
 UP BND1      load_0_3_14  20
 BV BND1      arc_0_3_15
 UP BND1      load_0_3_15  20
 BV BND1      arc_0_3_16
 UP BND1      load_0_3_16  20
 BV BND1      arc_0_3_17
 UP BND1      load_0_3_17  20
 BV BND1      arc_0_3_18
 UP BND1      load_0_3_18  20
 BV BND1      arc_0_3_19
 UP BND1      load_0_3_19  20
 BV BND1      arc_0_3_20
 UP BND1      load_0_3_20  20
 BV BND1      arc_0_4_0
 UP BND1      load_0_4_0  20
 BV BND1      arc_0_4_1
 UP BND1      load_0_4_1  20
 BV BND1      arc_0_4_2
 UP BND1      load_0_4_2  20
 BV BND1      arc_0_4_3
 UP BND1      load_0_4_3  20
 BV BND1      arc_0_4_5
 UP BND1      load_0_4_5  20
 BV BND1      arc_0_4_13
 UP BND1      load_0_4_13  20
 BV BND1      arc_0_4_14
 UP BND1      load_0_4_14  20
 BV BND1      arc_0_4_15
 UP BND1      load_0_4_15  20
 BV BND1      arc_0_4_16
 UP BND1      load_0_4_16  20
 BV BND1      arc_0_4_17
 UP BND1      load_0_4_17  20
 BV BND1      arc_0_4_18
 UP BND1      load_0_4_18  20
 BV BND1      arc_0_4_19
 UP BND1      load_0_4_19  20
 BV BND1      arc_0_4_20
 UP BND1      load_0_4_20  20
 BV BND1      arc_0_5_0
 UP BND1      load_0_5_0  20
 BV BND1      arc_0_5_1
 UP BND1      load_0_5_1  20
 BV BND1      arc_0_5_2
 UP BND1      load_0_5_2  20
 BV BND1      arc_0_5_3
 UP BND1      load_0_5_3  20
 BV BND1      arc_0_5_4
 UP BND1      load_0_5_4  20
 BV BND1      arc_0_5_13
 UP BND1      load_0_5_13  20
 BV BND1      arc_0_5_14
 UP BND1      load_0_5_14  20
 BV BND1      arc_0_5_15
 UP BND1      load_0_5_15  20
 BV BND1      arc_0_5_16
 UP BND1      load_0_5_16  20
 BV BND1      arc_0_5_17
 UP BND1      load_0_5_17  20
 BV BND1      arc_0_5_18
 UP BND1      load_0_5_18  20
 BV BND1      arc_0_5_19
 UP BND1      load_0_5_19  20
 BV BND1      arc_0_5_20
 UP BND1      load_0_5_20  20
 BV BND1      arc_0_13_0
 UP BND1      load_0_13_0  20
 BV BND1      arc_0_13_1
 UP BND1      load_0_13_1  20
 BV BND1      arc_0_13_2
 UP BND1      load_0_13_2  20
 BV BND1      arc_0_13_3
 UP BND1      load_0_13_3  20
 BV BND1      arc_0_13_4
 UP BND1      load_0_13_4  20
 BV BND1      arc_0_13_5
 UP BND1      load_0_13_5  20
 BV BND1      arc_0_13_14
 UP BND1      load_0_13_14  20
 BV BND1      arc_0_13_15
 UP BND1      load_0_13_15  20
 BV BND1      arc_0_13_16
 UP BND1      load_0_13_16  20
 BV BND1      arc_0_13_17
 UP BND1      load_0_13_17  20
 BV BND1      arc_0_13_18
 UP BND1      load_0_13_18  20
 BV BND1      arc_0_13_19
 UP BND1      load_0_13_19  20
 BV BND1      arc_0_13_20
 UP BND1      load_0_13_20  20
 BV BND1      arc_0_14_0
 UP BND1      load_0_14_0  20
 BV BND1      arc_0_14_1
 UP BND1      load_0_14_1  20
 BV BND1      arc_0_14_2
 UP BND1      load_0_14_2  20
 BV BND1      arc_0_14_3
 UP BND1      load_0_14_3  20
 BV BND1      arc_0_14_4
 UP BND1      load_0_14_4  20
 BV BND1      arc_0_14_5
 UP BND1      load_0_14_5  20
 BV BND1      arc_0_14_13
 UP BND1      load_0_14_13  20
 BV BND1      arc_0_14_15
 UP BND1      load_0_14_15  20
 BV BND1      arc_0_14_16
 UP BND1      load_0_14_16  20
 BV BND1      arc_0_14_17
 UP BND1      load_0_14_17  20
 BV BND1      arc_0_14_18
 UP BND1      load_0_14_18  20
 BV BND1      arc_0_14_19
 UP BND1      load_0_14_19  20
 BV BND1      arc_0_14_20
 UP BND1      load_0_14_20  20
 BV BND1      arc_0_15_0
 UP BND1      load_0_15_0  20
 BV BND1      arc_0_15_1
 UP BND1      load_0_15_1  20
 BV BND1      arc_0_15_2
 UP BND1      load_0_15_2  20
 BV BND1      arc_0_15_3
 UP BND1      load_0_15_3  20
 BV BND1      arc_0_15_4
 UP BND1      load_0_15_4  20
 BV BND1      arc_0_15_5
 UP BND1      load_0_15_5  20
 BV BND1      arc_0_15_13
 UP BND1      load_0_15_13  20
 BV BND1      arc_0_15_14
 UP BND1      load_0_15_14  20
 BV BND1      arc_0_15_16
 UP BND1      load_0_15_16  20
 BV BND1      arc_0_15_17
 UP BND1      load_0_15_17  20
 BV BND1      arc_0_15_18
 UP BND1      load_0_15_18  20
 BV BND1      arc_0_15_19
 UP BND1      load_0_15_19  20
 BV BND1      arc_0_15_20
 UP BND1      load_0_15_20  20
 BV BND1      arc_0_16_0
 UP BND1      load_0_16_0  20
 BV BND1      arc_0_16_1
 UP BND1      load_0_16_1  20
 BV BND1      arc_0_16_2
 UP BND1      load_0_16_2  20
 BV BND1      arc_0_16_3
 UP BND1      load_0_16_3  20
 BV BND1      arc_0_16_4
 UP BND1      load_0_16_4  20
 BV BND1      arc_0_16_5
 UP BND1      load_0_16_5  20
 BV BND1      arc_0_16_13
 UP BND1      load_0_16_13  20
 BV BND1      arc_0_16_14
 UP BND1      load_0_16_14  20
 BV BND1      arc_0_16_15
 UP BND1      load_0_16_15  20
 BV BND1      arc_0_16_17
 UP BND1      load_0_16_17  20
 BV BND1      arc_0_16_18
 UP BND1      load_0_16_18  20
 BV BND1      arc_0_16_19
 UP BND1      load_0_16_19  20
 BV BND1      arc_0_16_20
 UP BND1      load_0_16_20  20
 BV BND1      arc_0_17_0
 UP BND1      load_0_17_0  20
 BV BND1      arc_0_17_1
 UP BND1      load_0_17_1  20
 BV BND1      arc_0_17_2
 UP BND1      load_0_17_2  20
 BV BND1      arc_0_17_3
 UP BND1      load_0_17_3  20
 BV BND1      arc_0_17_4
 UP BND1      load_0_17_4  20
 BV BND1      arc_0_17_5
 UP BND1      load_0_17_5  20
 BV BND1      arc_0_17_13
 UP BND1      load_0_17_13  20
 BV BND1      arc_0_17_14
 UP BND1      load_0_17_14  20
 BV BND1      arc_0_17_15
 UP BND1      load_0_17_15  20
 BV BND1      arc_0_17_16
 UP BND1      load_0_17_16  20
 BV BND1      arc_0_17_18
 UP BND1      load_0_17_18  20
 BV BND1      arc_0_17_19
 UP BND1      load_0_17_19  20
 BV BND1      arc_0_17_20
 UP BND1      load_0_17_20  20
 BV BND1      arc_0_18_0
 UP BND1      load_0_18_0  20
 BV BND1      arc_0_18_1
 UP BND1      load_0_18_1  20
 BV BND1      arc_0_18_2
 UP BND1      load_0_18_2  20
 BV BND1      arc_0_18_3
 UP BND1      load_0_18_3  20
 BV BND1      arc_0_18_4
 UP BND1      load_0_18_4  20
 BV BND1      arc_0_18_5
 UP BND1      load_0_18_5  20
 BV BND1      arc_0_18_13
 UP BND1      load_0_18_13  20
 BV BND1      arc_0_18_14
 UP BND1      load_0_18_14  20
 BV BND1      arc_0_18_15
 UP BND1      load_0_18_15  20
 BV BND1      arc_0_18_16
 UP BND1      load_0_18_16  20
 BV BND1      arc_0_18_17
 UP BND1      load_0_18_17  20
 BV BND1      arc_0_18_19
 UP BND1      load_0_18_19  20
 BV BND1      arc_0_18_20
 UP BND1      load_0_18_20  20
 BV BND1      arc_0_19_0
 UP BND1      load_0_19_0  20
 BV BND1      arc_0_19_1
 UP BND1      load_0_19_1  20
 BV BND1      arc_0_19_2
 UP BND1      load_0_19_2  20
 BV BND1      arc_0_19_3
 UP BND1      load_0_19_3  20
 BV BND1      arc_0_19_4
 UP BND1      load_0_19_4  20
 BV BND1      arc_0_19_5
 UP BND1      load_0_19_5  20
 BV BND1      arc_0_19_13
 UP BND1      load_0_19_13  20
 BV BND1      arc_0_19_14
 UP BND1      load_0_19_14  20
 BV BND1      arc_0_19_15
 UP BND1      load_0_19_15  20
 BV BND1      arc_0_19_16
 UP BND1      load_0_19_16  20
 BV BND1      arc_0_19_17
 UP BND1      load_0_19_17  20
 BV BND1      arc_0_19_18
 UP BND1      load_0_19_18  20
 BV BND1      arc_0_19_20
 UP BND1      load_0_19_20  20
 BV BND1      arc_0_20_0
 UP BND1      load_0_20_0  20
 BV BND1      arc_0_20_1
 UP BND1      load_0_20_1  20
 BV BND1      arc_0_20_2
 UP BND1      load_0_20_2  20
 BV BND1      arc_0_20_3
 UP BND1      load_0_20_3  20
 BV BND1      arc_0_20_4
 UP BND1      load_0_20_4  20
 BV BND1      arc_0_20_5
 UP BND1      load_0_20_5  20
 BV BND1      arc_0_20_13
 UP BND1      load_0_20_13  20
 BV BND1      arc_0_20_14
 UP BND1      load_0_20_14  20
 BV BND1      arc_0_20_15
 UP BND1      load_0_20_15  20
 BV BND1      arc_0_20_16
 UP BND1      load_0_20_16  20
 BV BND1      arc_0_20_17
 UP BND1      load_0_20_17  20
 BV BND1      arc_0_20_18
 UP BND1      load_0_20_18  20
 BV BND1      arc_0_20_19
 UP BND1      load_0_20_19  20
 FX BND1      visit_1_6  1
 UP BND1      order_1_6  12
 FX BND1      visit_1_7  1
 UP BND1      order_1_7  12
 FX BND1      visit_1_8  1
 UP BND1      order_1_8  12
 FX BND1      visit_1_9  1
 UP BND1      order_1_9  12
 UP BND1      visit_1_13  1
 UP BND1      order_1_13  12
 UP BND1      visit_1_14  1
 UP BND1      order_1_14  12
 UP BND1      visit_1_15  1
 UP BND1      order_1_15  12
 UP BND1      visit_1_16  1
 UP BND1      order_1_16  12
 UP BND1      visit_1_17  1
 UP BND1      order_1_17  12
 UP BND1      visit_1_18  1
 UP BND1      order_1_18  12
 UP BND1      visit_1_19  1
 UP BND1      order_1_19  12
 UP BND1      visit_1_20  1
 UP BND1      order_1_20  12
 BV BND1      arc_1_0_0
 FX BND1      load_1_0_0  0
 BV BND1      arc_1_0_6
 FX BND1      load_1_0_6  0
 BV BND1      arc_1_0_7
 FX BND1      load_1_0_7  0
 BV BND1      arc_1_0_8
 FX BND1      load_1_0_8  0
 BV BND1      arc_1_0_9
 FX BND1      load_1_0_9  0
 BV BND1      arc_1_0_13
 FX BND1      load_1_0_13  0
 BV BND1      arc_1_0_14
 FX BND1      load_1_0_14  0
 BV BND1      arc_1_0_15
 FX BND1      load_1_0_15  0
 BV BND1      arc_1_0_16
 FX BND1      load_1_0_16  0
 BV BND1      arc_1_0_17
 FX BND1      load_1_0_17  0
 BV BND1      arc_1_0_18
 FX BND1      load_1_0_18  0
 BV BND1      arc_1_0_19
 FX BND1      load_1_0_19  0
 BV BND1      arc_1_0_20
 FX BND1      load_1_0_20  0
 BV BND1      arc_1_6_0
 UP BND1      load_1_6_0  25
 BV BND1      arc_1_6_7
 UP BND1      load_1_6_7  25
 BV BND1      arc_1_6_8
 UP BND1      load_1_6_8  25
 BV BND1      arc_1_6_9
 UP BND1      load_1_6_9  25
 BV BND1      arc_1_6_13
 UP BND1      load_1_6_13  25
 BV BND1      arc_1_6_14
 UP BND1      load_1_6_14  25
 BV BND1      arc_1_6_15
 UP BND1      load_1_6_15  25
 BV BND1      arc_1_6_16
 UP BND1      load_1_6_16  25
 BV BND1      arc_1_6_17
 UP BND1      load_1_6_17  25
 BV BND1      arc_1_6_18
 UP BND1      load_1_6_18  25
 BV BND1      arc_1_6_19
 UP BND1      load_1_6_19  25
 BV BND1      arc_1_6_20
 UP BND1      load_1_6_20  25
 BV BND1      arc_1_7_0
 UP BND1      load_1_7_0  25
 BV BND1      arc_1_7_6
 UP BND1      load_1_7_6  25
 BV BND1      arc_1_7_8
 UP BND1      load_1_7_8  25
 BV BND1      arc_1_7_9
 UP BND1      load_1_7_9  25
 BV BND1      arc_1_7_13
 UP BND1      load_1_7_13  25
 BV BND1      arc_1_7_14
 UP BND1      load_1_7_14  25
 BV BND1      arc_1_7_15
 UP BND1      load_1_7_15  25
 BV BND1      arc_1_7_16
 UP BND1      load_1_7_16  25
 BV BND1      arc_1_7_17
 UP BND1      load_1_7_17  25
 BV BND1      arc_1_7_18
 UP BND1      load_1_7_18  25
 BV BND1      arc_1_7_19
 UP BND1      load_1_7_19  25
 BV BND1      arc_1_7_20
 UP BND1      load_1_7_20  25
 BV BND1      arc_1_8_0
 UP BND1      load_1_8_0  25
 BV BND1      arc_1_8_6
 UP BND1      load_1_8_6  25
 BV BND1      arc_1_8_7
 UP BND1      load_1_8_7  25
 BV BND1      arc_1_8_9
 UP BND1      load_1_8_9  25
 BV BND1      arc_1_8_13
 UP BND1      load_1_8_13  25
 BV BND1      arc_1_8_14
 UP BND1      load_1_8_14  25
 BV BND1      arc_1_8_15
 UP BND1      load_1_8_15  25
 BV BND1      arc_1_8_16
 UP BND1      load_1_8_16  25
 BV BND1      arc_1_8_17
 UP BND1      load_1_8_17  25
 BV BND1      arc_1_8_18
 UP BND1      load_1_8_18  25
 BV BND1      arc_1_8_19
 UP BND1      load_1_8_19  25
 BV BND1      arc_1_8_20
 UP BND1      load_1_8_20  25
 BV BND1      arc_1_9_0
 UP BND1      load_1_9_0  25
 BV BND1      arc_1_9_6
 UP BND1      load_1_9_6  25
 BV BND1      arc_1_9_7
 UP BND1      load_1_9_7  25
 BV BND1      arc_1_9_8
 UP BND1      load_1_9_8  25
 BV BND1      arc_1_9_13
 UP BND1      load_1_9_13  25
 BV BND1      arc_1_9_14
 UP BND1      load_1_9_14  25
 BV BND1      arc_1_9_15
 UP BND1      load_1_9_15  25
 BV BND1      arc_1_9_16
 UP BND1      load_1_9_16  25
 BV BND1      arc_1_9_17
 UP BND1      load_1_9_17  25
 BV BND1      arc_1_9_18
 UP BND1      load_1_9_18  25
 BV BND1      arc_1_9_19
 UP BND1      load_1_9_19  25
 BV BND1      arc_1_9_20
 UP BND1      load_1_9_20  25
 BV BND1      arc_1_13_0
 UP BND1      load_1_13_0  25
 BV BND1      arc_1_13_6
 UP BND1      load_1_13_6  25
 BV BND1      arc_1_13_7
 UP BND1      load_1_13_7  25
 BV BND1      arc_1_13_8
 UP BND1      load_1_13_8  25
 BV BND1      arc_1_13_9
 UP BND1      load_1_13_9  25
 BV BND1      arc_1_13_14
 UP BND1      load_1_13_14  25
 BV BND1      arc_1_13_15
 UP BND1      load_1_13_15  25
 BV BND1      arc_1_13_16
 UP BND1      load_1_13_16  25
 BV BND1      arc_1_13_17
 UP BND1      load_1_13_17  25
 BV BND1      arc_1_13_18
 UP BND1      load_1_13_18  25
 BV BND1      arc_1_13_19
 UP BND1      load_1_13_19  25
 BV BND1      arc_1_13_20
 UP BND1      load_1_13_20  25
 BV BND1      arc_1_14_0
 UP BND1      load_1_14_0  25
 BV BND1      arc_1_14_6
 UP BND1      load_1_14_6  25
 BV BND1      arc_1_14_7
 UP BND1      load_1_14_7  25
 BV BND1      arc_1_14_8
 UP BND1      load_1_14_8  25
 BV BND1      arc_1_14_9
 UP BND1      load_1_14_9  25
 BV BND1      arc_1_14_13
 UP BND1      load_1_14_13  25
 BV BND1      arc_1_14_15
 UP BND1      load_1_14_15  25
 BV BND1      arc_1_14_16
 UP BND1      load_1_14_16  25
 BV BND1      arc_1_14_17
 UP BND1      load_1_14_17  25
 BV BND1      arc_1_14_18
 UP BND1      load_1_14_18  25
 BV BND1      arc_1_14_19
 UP BND1      load_1_14_19  25
 BV BND1      arc_1_14_20
 UP BND1      load_1_14_20  25
 BV BND1      arc_1_15_0
 UP BND1      load_1_15_0  25
 BV BND1      arc_1_15_6
 UP BND1      load_1_15_6  25
 BV BND1      arc_1_15_7
 UP BND1      load_1_15_7  25
 BV BND1      arc_1_15_8
 UP BND1      load_1_15_8  25
 BV BND1      arc_1_15_9
 UP BND1      load_1_15_9  25
 BV BND1      arc_1_15_13
 UP BND1      load_1_15_13  25
 BV BND1      arc_1_15_14
 UP BND1      load_1_15_14  25
 BV BND1      arc_1_15_16
 UP BND1      load_1_15_16  25
 BV BND1      arc_1_15_17
 UP BND1      load_1_15_17  25
 BV BND1      arc_1_15_18
 UP BND1      load_1_15_18  25
 BV BND1      arc_1_15_19
 UP BND1      load_1_15_19  25
 BV BND1      arc_1_15_20
 UP BND1      load_1_15_20  25
 BV BND1      arc_1_16_0
 UP BND1      load_1_16_0  25
 BV BND1      arc_1_16_6
 UP BND1      load_1_16_6  25
 BV BND1      arc_1_16_7
 UP BND1      load_1_16_7  25
 BV BND1      arc_1_16_8
 UP BND1      load_1_16_8  25
 BV BND1      arc_1_16_9
 UP BND1      load_1_16_9  25
 BV BND1      arc_1_16_13
 UP BND1      load_1_16_13  25
 BV BND1      arc_1_16_14
 UP BND1      load_1_16_14  25
 BV BND1      arc_1_16_15
 UP BND1      load_1_16_15  25
 BV BND1      arc_1_16_17
 UP BND1      load_1_16_17  25
 BV BND1      arc_1_16_18
 UP BND1      load_1_16_18  25
 BV BND1      arc_1_16_19
 UP BND1      load_1_16_19  25
 BV BND1      arc_1_16_20
 UP BND1      load_1_16_20  25
 BV BND1      arc_1_17_0
 UP BND1      load_1_17_0  25
 BV BND1      arc_1_17_6
 UP BND1      load_1_17_6  25
 BV BND1      arc_1_17_7
 UP BND1      load_1_17_7  25
 BV BND1      arc_1_17_8
 UP BND1      load_1_17_8  25
 BV BND1      arc_1_17_9
 UP BND1      load_1_17_9  25
 BV BND1      arc_1_17_13
 UP BND1      load_1_17_13  25
 BV BND1      arc_1_17_14
 UP BND1      load_1_17_14  25
 BV BND1      arc_1_17_15
 UP BND1      load_1_17_15  25
 BV BND1      arc_1_17_16
 UP BND1      load_1_17_16  25
 BV BND1      arc_1_17_18
 UP BND1      load_1_17_18  25
 BV BND1      arc_1_17_19
 UP BND1      load_1_17_19  25
 BV BND1      arc_1_17_20
 UP BND1      load_1_17_20  25
 BV BND1      arc_1_18_0
 UP BND1      load_1_18_0  25
 BV BND1      arc_1_18_6
 UP BND1      load_1_18_6  25
 BV BND1      arc_1_18_7
 UP BND1      load_1_18_7  25
 BV BND1      arc_1_18_8
 UP BND1      load_1_18_8  25
 BV BND1      arc_1_18_9
 UP BND1      load_1_18_9  25
 BV BND1      arc_1_18_13
 UP BND1      load_1_18_13  25
 BV BND1      arc_1_18_14
 UP BND1      load_1_18_14  25
 BV BND1      arc_1_18_15
 UP BND1      load_1_18_15  25
 BV BND1      arc_1_18_16
 UP BND1      load_1_18_16  25
 BV BND1      arc_1_18_17
 UP BND1      load_1_18_17  25
 BV BND1      arc_1_18_19
 UP BND1      load_1_18_19  25
 BV BND1      arc_1_18_20
 UP BND1      load_1_18_20  25
 BV BND1      arc_1_19_0
 UP BND1      load_1_19_0  25
 BV BND1      arc_1_19_6
 UP BND1      load_1_19_6  25
 BV BND1      arc_1_19_7
 UP BND1      load_1_19_7  25
 BV BND1      arc_1_19_8
 UP BND1      load_1_19_8  25
 BV BND1      arc_1_19_9
 UP BND1      load_1_19_9  25
 BV BND1      arc_1_19_13
 UP BND1      load_1_19_13  25
 BV BND1      arc_1_19_14
 UP BND1      load_1_19_14  25
 BV BND1      arc_1_19_15
 UP BND1      load_1_19_15  25
 BV BND1      arc_1_19_16
 UP BND1      load_1_19_16  25
 BV BND1      arc_1_19_17
 UP BND1      load_1_19_17  25
 BV BND1      arc_1_19_18
 UP BND1      load_1_19_18  25
 BV BND1      arc_1_19_20
 UP BND1      load_1_19_20  25
 BV BND1      arc_1_20_0
 UP BND1      load_1_20_0  25
 BV BND1      arc_1_20_6
 UP BND1      load_1_20_6  25
 BV BND1      arc_1_20_7
 UP BND1      load_1_20_7  25
 BV BND1      arc_1_20_8
 UP BND1      load_1_20_8  25
 BV BND1      arc_1_20_9
 UP BND1      load_1_20_9  25
 BV BND1      arc_1_20_13
 UP BND1      load_1_20_13  25
 BV BND1      arc_1_20_14
 UP BND1      load_1_20_14  25
 BV BND1      arc_1_20_15
 UP BND1      load_1_20_15  25
 BV BND1      arc_1_20_16
 UP BND1      load_1_20_16  25
 BV BND1      arc_1_20_17
 UP BND1      load_1_20_17  25
 BV BND1      arc_1_20_18
 UP BND1      load_1_20_18  25
 BV BND1      arc_1_20_19
 UP BND1      load_1_20_19  25
 FX BND1      visit_2_10  1
 UP BND1      order_2_10  11
 FX BND1      visit_2_11  1
 UP BND1      order_2_11  11
 FX BND1      visit_2_12  1
 UP BND1      order_2_12  11
 UP BND1      visit_2_13  1
 UP BND1      order_2_13  11
 UP BND1      visit_2_14  1
 UP BND1      order_2_14  11
 UP BND1      visit_2_15  1
 UP BND1      order_2_15  11
 UP BND1      visit_2_16  1
 UP BND1      order_2_16  11
 UP BND1      visit_2_17  1
 UP BND1      order_2_17  11
 UP BND1      visit_2_18  1
 UP BND1      order_2_18  11
 UP BND1      visit_2_19  1
 UP BND1      order_2_19  11
 UP BND1      visit_2_20  1
 UP BND1      order_2_20  11
 BV BND1      arc_2_0_0
 FX BND1      load_2_0_0  0
 BV BND1      arc_2_0_10
 FX BND1      load_2_0_10  0
 BV BND1      arc_2_0_11
 FX BND1      load_2_0_11  0
 BV BND1      arc_2_0_12
 FX BND1      load_2_0_12  0
 BV BND1      arc_2_0_13
 FX BND1      load_2_0_13  0
 BV BND1      arc_2_0_14
 FX BND1      load_2_0_14  0
 BV BND1      arc_2_0_15
 FX BND1      load_2_0_15  0
 BV BND1      arc_2_0_16
 FX BND1      load_2_0_16  0
 BV BND1      arc_2_0_17
 FX BND1      load_2_0_17  0
 BV BND1      arc_2_0_18
 FX BND1      load_2_0_18  0
 BV BND1      arc_2_0_19
 FX BND1      load_2_0_19  0
 BV BND1      arc_2_0_20
 FX BND1      load_2_0_20  0
 BV BND1      arc_2_10_0
 UP BND1      load_2_10_0  30
 BV BND1      arc_2_10_11
 UP BND1      load_2_10_11  30
 BV BND1      arc_2_10_12
 UP BND1      load_2_10_12  30
 BV BND1      arc_2_10_13
 UP BND1      load_2_10_13  30
 BV BND1      arc_2_10_14
 UP BND1      load_2_10_14  30
 BV BND1      arc_2_10_15
 UP BND1      load_2_10_15  30
 BV BND1      arc_2_10_16
 UP BND1      load_2_10_16  30
 BV BND1      arc_2_10_17
 UP BND1      load_2_10_17  30
 BV BND1      arc_2_10_18
 UP BND1      load_2_10_18  30
 BV BND1      arc_2_10_19
 UP BND1      load_2_10_19  30
 BV BND1      arc_2_10_20
 UP BND1      load_2_10_20  30
 BV BND1      arc_2_11_0
 UP BND1      load_2_11_0  30
 BV BND1      arc_2_11_10
 UP BND1      load_2_11_10  30
 BV BND1      arc_2_11_12
 UP BND1      load_2_11_12  30
 BV BND1      arc_2_11_13
 UP BND1      load_2_11_13  30
 BV BND1      arc_2_11_14
 UP BND1      load_2_11_14  30
 BV BND1      arc_2_11_15
 UP BND1      load_2_11_15  30
 BV BND1      arc_2_11_16
 UP BND1      load_2_11_16  30
 BV BND1      arc_2_11_17
 UP BND1      load_2_11_17  30
 BV BND1      arc_2_11_18
 UP BND1      load_2_11_18  30
 BV BND1      arc_2_11_19
 UP BND1      load_2_11_19  30
 BV BND1      arc_2_11_20
 UP BND1      load_2_11_20  30
 BV BND1      arc_2_12_0
 UP BND1      load_2_12_0  30
 BV BND1      arc_2_12_10
 UP BND1      load_2_12_10  30
 BV BND1      arc_2_12_11
 UP BND1      load_2_12_11  30
 BV BND1      arc_2_12_13
 UP BND1      load_2_12_13  30
 BV BND1      arc_2_12_14
 UP BND1      load_2_12_14  30
 BV BND1      arc_2_12_15
 UP BND1      load_2_12_15  30
 BV BND1      arc_2_12_16
 UP BND1      load_2_12_16  30
 BV BND1      arc_2_12_17
 UP BND1      load_2_12_17  30
 BV BND1      arc_2_12_18
 UP BND1      load_2_12_18  30
 BV BND1      arc_2_12_19
 UP BND1      load_2_12_19  30
 BV BND1      arc_2_12_20
 UP BND1      load_2_12_20  30
 BV BND1      arc_2_13_0
 UP BND1      load_2_13_0  30
 BV BND1      arc_2_13_10
 UP BND1      load_2_13_10  30
 BV BND1      arc_2_13_11
 UP BND1      load_2_13_11  30
 BV BND1      arc_2_13_12
 UP BND1      load_2_13_12  30
 BV BND1      arc_2_13_14
 UP BND1      load_2_13_14  30
 BV BND1      arc_2_13_15
 UP BND1      load_2_13_15  30
 BV BND1      arc_2_13_16
 UP BND1      load_2_13_16  30
 BV BND1      arc_2_13_17
 UP BND1      load_2_13_17  30
 BV BND1      arc_2_13_18
 UP BND1      load_2_13_18  30
 BV BND1      arc_2_13_19
 UP BND1      load_2_13_19  30
 BV BND1      arc_2_13_20
 UP BND1      load_2_13_20  30
 BV BND1      arc_2_14_0
 UP BND1      load_2_14_0  30
 BV BND1      arc_2_14_10
 UP BND1      load_2_14_10  30
 BV BND1      arc_2_14_11
 UP BND1      load_2_14_11  30
 BV BND1      arc_2_14_12
 UP BND1      load_2_14_12  30
 BV BND1      arc_2_14_13
 UP BND1      load_2_14_13  30
 BV BND1      arc_2_14_15
 UP BND1      load_2_14_15  30
 BV BND1      arc_2_14_16
 UP BND1      load_2_14_16  30
 BV BND1      arc_2_14_17
 UP BND1      load_2_14_17  30
 BV BND1      arc_2_14_18
 UP BND1      load_2_14_18  30
 BV BND1      arc_2_14_19
 UP BND1      load_2_14_19  30
 BV BND1      arc_2_14_20
 UP BND1      load_2_14_20  30
 BV BND1      arc_2_15_0
 UP BND1      load_2_15_0  30
 BV BND1      arc_2_15_10
 UP BND1      load_2_15_10  30
 BV BND1      arc_2_15_11
 UP BND1      load_2_15_11  30
 BV BND1      arc_2_15_12
 UP BND1      load_2_15_12  30
 BV BND1      arc_2_15_13
 UP BND1      load_2_15_13  30
 BV BND1      arc_2_15_14
 UP BND1      load_2_15_14  30
 BV BND1      arc_2_15_16
 UP BND1      load_2_15_16  30
 BV BND1      arc_2_15_17
 UP BND1      load_2_15_17  30
 BV BND1      arc_2_15_18
 UP BND1      load_2_15_18  30
 BV BND1      arc_2_15_19
 UP BND1      load_2_15_19  30
 BV BND1      arc_2_15_20
 UP BND1      load_2_15_20  30
 BV BND1      arc_2_16_0
 UP BND1      load_2_16_0  30
 BV BND1      arc_2_16_10
 UP BND1      load_2_16_10  30
 BV BND1      arc_2_16_11
 UP BND1      load_2_16_11  30
 BV BND1      arc_2_16_12
 UP BND1      load_2_16_12  30
 BV BND1      arc_2_16_13
 UP BND1      load_2_16_13  30
 BV BND1      arc_2_16_14
 UP BND1      load_2_16_14  30
 BV BND1      arc_2_16_15
 UP BND1      load_2_16_15  30
 BV BND1      arc_2_16_17
 UP BND1      load_2_16_17  30
 BV BND1      arc_2_16_18
 UP BND1      load_2_16_18  30
 BV BND1      arc_2_16_19
 UP BND1      load_2_16_19  30
 BV BND1      arc_2_16_20
 UP BND1      load_2_16_20  30
 BV BND1      arc_2_17_0
 UP BND1      load_2_17_0  30
 BV BND1      arc_2_17_10
 UP BND1      load_2_17_10  30
 BV BND1      arc_2_17_11
 UP BND1      load_2_17_11  30
 BV BND1      arc_2_17_12
 UP BND1      load_2_17_12  30
 BV BND1      arc_2_17_13
 UP BND1      load_2_17_13  30
 BV BND1      arc_2_17_14
 UP BND1      load_2_17_14  30
 BV BND1      arc_2_17_15
 UP BND1      load_2_17_15  30
 BV BND1      arc_2_17_16
 UP BND1      load_2_17_16  30
 BV BND1      arc_2_17_18
 UP BND1      load_2_17_18  30
 BV BND1      arc_2_17_19
 UP BND1      load_2_17_19  30
 BV BND1      arc_2_17_20
 UP BND1      load_2_17_20  30
 BV BND1      arc_2_18_0
 UP BND1      load_2_18_0  30
 BV BND1      arc_2_18_10
 UP BND1      load_2_18_10  30
 BV BND1      arc_2_18_11
 UP BND1      load_2_18_11  30
 BV BND1      arc_2_18_12
 UP BND1      load_2_18_12  30
 BV BND1      arc_2_18_13
 UP BND1      load_2_18_13  30
 BV BND1      arc_2_18_14
 UP BND1      load_2_18_14  30
 BV BND1      arc_2_18_15
 UP BND1      load_2_18_15  30
 BV BND1      arc_2_18_16
 UP BND1      load_2_18_16  30
 BV BND1      arc_2_18_17
 UP BND1      load_2_18_17  30
 BV BND1      arc_2_18_19
 UP BND1      load_2_18_19  30
 BV BND1      arc_2_18_20
 UP BND1      load_2_18_20  30
 BV BND1      arc_2_19_0
 UP BND1      load_2_19_0  30
 BV BND1      arc_2_19_10
 UP BND1      load_2_19_10  30
 BV BND1      arc_2_19_11
 UP BND1      load_2_19_11  30
 BV BND1      arc_2_19_12
 UP BND1      load_2_19_12  30
 BV BND1      arc_2_19_13
 UP BND1      load_2_19_13  30
 BV BND1      arc_2_19_14
 UP BND1      load_2_19_14  30
 BV BND1      arc_2_19_15
 UP BND1      load_2_19_15  30
 BV BND1      arc_2_19_16
 UP BND1      load_2_19_16  30
 BV BND1      arc_2_19_17
 UP BND1      load_2_19_17  30
 BV BND1      arc_2_19_18
 UP BND1      load_2_19_18  30
 BV BND1      arc_2_19_20
 UP BND1      load_2_19_20  30
 BV BND1      arc_2_20_0
 UP BND1      load_2_20_0  30
 BV BND1      arc_2_20_10
 UP BND1      load_2_20_10  30
 BV BND1      arc_2_20_11
 UP BND1      load_2_20_11  30
 BV BND1      arc_2_20_12
 UP BND1      load_2_20_12  30
 BV BND1      arc_2_20_13
 UP BND1      load_2_20_13  30
 BV BND1      arc_2_20_14
 UP BND1      load_2_20_14  30
 BV BND1      arc_2_20_15
 UP BND1      load_2_20_15  30
 BV BND1      arc_2_20_16
 UP BND1      load_2_20_16  30
 BV BND1      arc_2_20_17
 UP BND1      load_2_20_17  30
 BV BND1      arc_2_20_18
 UP BND1      load_2_20_18  30
 BV BND1      arc_2_20_19
 UP BND1      load_2_20_19  30
ENDATA
