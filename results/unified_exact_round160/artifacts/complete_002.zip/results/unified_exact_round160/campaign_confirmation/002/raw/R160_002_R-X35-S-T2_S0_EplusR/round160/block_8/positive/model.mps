* Signature: 0x22f96c691fb652a0
NAME R160_physical_neighborhood
ROWS
 N  OBJ
 G  product_lb_0
 L  product_ub_1
 G  product_lb_2
 L  product_ub_3
 G  product_lb_4
 L  product_ub_5
 G  product_lb_6
 L  product_ub_7
 G  product_lb_8
 L  product_ub_9
 G  product_lb_10
 L  product_ub_11
 G  product_lb_12
 L  product_ub_13
 G  product_lb_14
 L  product_ub_15
 G  product_lb_16
 L  product_ub_17
 G  product_lb_18
 L  product_ub_19
 G  product_lb_20
 L  product_ub_21
 G  product_lb_22
 L  product_ub_23
 G  product_lb_24
 L  product_ub_25
 G  product_lb_26
 L  product_ub_27
 G  product_lb_28
 L  product_ub_29
 G  product_lb_30
 L  product_ub_31
 E  onehot_4_32
 E  normalized_mass_4_33
 E  normalized_ratio_4_34
 G  product_lb_35
 L  product_ub_36
 G  product_lb_37
 L  product_ub_38
 G  product_lb_39
 L  product_ub_40
 G  product_lb_41
 L  product_ub_42
 G  product_lb_43
 L  product_ub_44
 G  product_lb_45
 L  product_ub_46
 G  product_lb_47
 L  product_ub_48
 G  product_lb_49
 L  product_ub_50
 G  product_lb_51
 L  product_ub_52
 E  onehot_6_53
 E  normalized_mass_6_54
 E  normalized_ratio_6_55
 G  product_lb_56
 L  product_ub_57
 G  product_lb_58
 L  product_ub_59
 G  product_lb_60
 L  product_ub_61
 G  product_lb_62
 L  product_ub_63
 G  product_lb_64
 L  product_ub_65
 G  product_lb_66
 L  product_ub_67
 G  product_lb_68
 L  product_ub_69
 G  product_lb_70
 L  product_ub_71
 G  product_lb_72
 L  product_ub_73
 G  product_lb_74
 L  product_ub_75
 G  product_lb_76
 L  product_ub_77
 G  product_lb_78
 L  product_ub_79
 G  product_lb_80
 L  product_ub_81
 G  product_lb_82
 L  product_ub_83
 G  product_lb_84
 L  product_ub_85
 G  product_lb_86
 L  product_ub_87
 E  onehot_34_88
 E  normalized_mass_34_89
 E  normalized_ratio_34_90
 G  product_lb_91
 L  product_ub_92
 G  product_lb_93
 L  product_ub_94
 G  product_lb_95
 L  product_ub_96
 G  product_lb_97
 L  product_ub_98
 G  product_lb_99
 L  product_ub_100
 G  product_lb_101
 L  product_ub_102
 G  product_lb_103
 L  product_ub_104
 G  product_lb_105
 L  product_ub_106
 G  product_lb_107
 L  product_ub_108
 G  product_lb_109
 L  product_ub_110
 G  product_lb_111
 L  product_ub_112
 G  product_lb_113
 L  product_ub_114
 G  product_lb_115
 L  product_ub_116
 E  onehot_3_117
 E  normalized_mass_3_118
 E  normalized_ratio_3_119
 G  product_lb_120
 L  product_ub_121
 G  product_lb_122
 L  product_ub_123
 G  product_lb_124
 L  product_ub_125
 G  product_lb_126
 L  product_ub_127
 G  product_lb_128
 L  product_ub_129
 G  product_lb_130
 L  product_ub_131
 G  product_lb_132
 L  product_ub_133
 G  product_lb_134
 L  product_ub_135
 G  product_lb_136
 L  product_ub_137
 G  product_lb_138
 L  product_ub_139
 G  product_lb_140
 L  product_ub_141
 G  product_lb_142
 L  product_ub_143
 G  product_lb_144
 L  product_ub_145
 G  product_lb_146
 L  product_ub_147
 G  product_lb_148
 L  product_ub_149
 G  product_lb_150
 L  product_ub_151
 E  onehot_22_152
 E  normalized_mass_22_153
 E  normalized_ratio_22_154
 G  product_lb_155
 L  product_ub_156
 G  product_lb_157
 L  product_ub_158
 G  product_lb_159
 L  product_ub_160
 G  product_lb_161
 L  product_ub_162
 G  product_lb_163
 L  product_ub_164
 G  product_lb_165
 L  product_ub_166
 G  product_lb_167
 L  product_ub_168
 G  product_lb_169
 L  product_ub_170
 G  product_lb_171
 L  product_ub_172
 G  product_lb_173
 L  product_ub_174
 G  product_lb_175
 L  product_ub_176
 G  product_lb_177
 L  product_ub_178
 G  product_lb_179
 L  product_ub_180
 G  product_lb_181
 L  product_ub_182
 G  product_lb_183
 L  product_ub_184
 G  product_lb_185
 L  product_ub_186
 E  onehot_5_187
 E  normalized_mass_5_188
 E  normalized_ratio_5_189
 G  product_lb_190
 L  product_ub_191
 G  product_lb_192
 L  product_ub_193
 G  product_lb_194
 L  product_ub_195
 G  product_lb_196
 L  product_ub_197
 G  product_lb_198
 L  product_ub_199
 G  product_lb_200
 L  product_ub_201
 G  product_lb_202
 L  product_ub_203
 E  onehot_27_204
 E  normalized_mass_27_205
 E  normalized_ratio_27_206
 G  product_lb_207
 L  product_ub_208
 G  product_lb_209
 L  product_ub_210
 G  product_lb_211
 L  product_ub_212
 G  product_lb_213
 L  product_ub_214
 G  product_lb_215
 L  product_ub_216
 G  product_lb_217
 L  product_ub_218
 G  product_lb_219
 L  product_ub_220
 G  product_lb_221
 L  product_ub_222
 G  product_lb_223
 L  product_ub_224
 G  product_lb_225
 L  product_ub_226
 G  product_lb_227
 L  product_ub_228
 G  product_lb_229
 L  product_ub_230
 G  product_lb_231
 L  product_ub_232
 E  onehot_8_233
 E  normalized_mass_8_234
 E  normalized_ratio_8_235
 G  stock_lb_236
 L  stock_ub_237
 L  parent_nonstrict_scope_238
 G  block_pair_pos_239
 G  block_pair_neg_240
 G  block_pair_pos_241
 G  block_pair_neg_242
 G  block_pair_pos_243
 G  block_pair_neg_244
 G  block_pair_pos_245
 G  block_pair_neg_246
 G  block_pair_pos_247
 G  block_pair_neg_248
 G  block_pair_pos_249
 G  block_pair_neg_250
 G  block_pair_pos_251
 G  block_pair_neg_252
 G  block_pair_pos_253
 G  block_pair_neg_254
 G  block_pair_pos_255
 G  block_pair_neg_256
 G  block_pair_pos_257
 G  block_pair_neg_258
 G  block_pair_pos_259
 G  block_pair_neg_260
 G  block_pair_pos_261
 G  block_pair_neg_262
 G  block_pair_pos_263
 G  block_pair_neg_264
 G  block_pair_pos_265
 G  block_pair_neg_266
 G  block_pair_pos_267
 G  block_pair_neg_268
 G  block_pair_pos_269
 G  block_pair_neg_270
 G  block_pair_pos_271
 G  block_pair_neg_272
 G  block_pair_pos_273
 G  block_pair_neg_274
 G  block_pair_pos_275
 G  block_pair_neg_276
 G  block_pair_pos_277
 G  block_pair_neg_278
 G  block_pair_pos_279
 G  block_pair_neg_280
 G  block_pair_pos_281
 G  block_pair_neg_282
 G  block_pair_pos_283
 G  block_pair_neg_284
 G  block_pair_pos_285
 G  block_pair_neg_286
 G  block_pair_pos_287
 G  block_pair_neg_288
 G  block_pair_pos_289
 G  block_pair_neg_290
 G  block_pair_pos_291
 G  block_pair_neg_292
 G  block_pair_pos_293
 G  block_pair_neg_294
 E  normalization_295
 G  full_original_Gini_296
 E  unique_nonzero_owner_297
 E  unique_nonzero_owner_298
 E  unique_nonzero_owner_299
 E  unique_nonzero_owner_300
 E  unique_nonzero_owner_301
 E  unique_nonzero_owner_302
 E  unique_nonzero_owner_303
 E  unique_nonzero_owner_304
 E  unique_nonzero_owner_305
 E  unique_nonzero_owner_306
 E  unique_nonzero_owner_307
 E  unique_nonzero_owner_308
 E  unique_nonzero_owner_309
 E  unique_nonzero_owner_310
 E  unique_nonzero_owner_311
 E  unique_nonzero_owner_312
 E  unique_nonzero_owner_313
 E  unique_nonzero_owner_314
 E  unique_nonzero_owner_315
 E  unique_nonzero_owner_316
 E  unique_nonzero_owner_317
 E  unique_nonzero_owner_318
 E  unique_nonzero_owner_319
 E  unique_nonzero_owner_320
 E  unique_nonzero_owner_321
 E  unique_nonzero_owner_322
 E  unique_nonzero_owner_323
 E  unique_nonzero_owner_324
 E  unique_nonzero_owner_325
 E  unique_nonzero_owner_326
 E  unique_nonzero_owner_327
 E  unique_nonzero_owner_328
 E  unique_nonzero_owner_329
 E  unique_nonzero_owner_330
 E  unique_nonzero_owner_331
 E  unique_nonzero_owner_332
 E  unique_nonzero_owner_333
 E  unique_nonzero_owner_334
 E  unique_nonzero_owner_335
 E  unique_nonzero_owner_336
 E  unique_nonzero_owner_337
 E  unique_nonzero_owner_338
 E  unique_nonzero_owner_339
 E  unique_nonzero_owner_340
 E  unique_nonzero_owner_341
 E  unique_nonzero_owner_342
 E  unique_nonzero_owner_343
 E  unique_nonzero_owner_344
 E  unique_nonzero_owner_345
 E  unique_nonzero_owner_346
 E  unique_nonzero_owner_347
 E  unique_nonzero_owner_348
 E  unique_nonzero_owner_349
 E  unique_nonzero_owner_350
 E  unique_nonzero_owner_351
 E  unique_nonzero_owner_352
 E  unique_nonzero_owner_353
 E  unique_nonzero_owner_354
 E  unique_nonzero_owner_355
 E  unique_nonzero_owner_356
 E  unique_nonzero_owner_357
 E  unique_nonzero_owner_358
 E  unique_nonzero_owner_359
 E  unique_nonzero_owner_360
 E  unique_nonzero_owner_361
 E  unique_nonzero_owner_362
 E  unique_nonzero_owner_363
 E  unique_nonzero_owner_364
 E  unique_nonzero_owner_365
 E  unique_nonzero_owner_366
 E  unique_nonzero_owner_367
 E  unique_nonzero_owner_368
 E  unique_nonzero_owner_369
 E  unique_nonzero_owner_370
 E  unique_nonzero_owner_371
 E  unique_nonzero_owner_372
 E  unique_nonzero_owner_373
 E  unique_nonzero_owner_374
 E  unique_nonzero_owner_375
 E  unique_nonzero_owner_376
 E  unique_nonzero_owner_377
 E  unique_nonzero_owner_378
 E  unique_nonzero_owner_379
 E  unique_nonzero_owner_380
 E  unique_nonzero_owner_381
 E  unique_nonzero_owner_382
 E  unique_nonzero_owner_383
 E  unique_nonzero_owner_384
 E  unique_nonzero_owner_385
 E  unique_nonzero_owner_386
 E  unique_nonzero_owner_387
 E  unique_nonzero_owner_388
 E  unique_nonzero_owner_389
 E  unique_nonzero_owner_390
 E  unique_nonzero_owner_391
 E  unique_nonzero_owner_392
 E  unique_nonzero_owner_393
 E  unique_nonzero_owner_394
 L  arc_capacity_395
 L  arc_capacity_396
 L  arc_capacity_397
 L  arc_capacity_398
 L  arc_capacity_399
 L  arc_capacity_400
 L  arc_capacity_401
 L  arc_capacity_402
 L  arc_capacity_403
 L  arc_capacity_404
 L  arc_capacity_405
 L  arc_capacity_406
 L  arc_capacity_407
 L  arc_capacity_408
 L  arc_capacity_409
 L  arc_capacity_410
 G  connected_order_arc_411
 L  arc_capacity_412
 G  connected_order_arc_413
 L  arc_capacity_414
 G  connected_order_arc_415
 L  arc_capacity_416
 G  connected_order_arc_417
 L  arc_capacity_418
 G  connected_order_arc_419
 L  arc_capacity_420
 G  connected_order_arc_421
 L  arc_capacity_422
 G  connected_order_arc_423
 L  arc_capacity_424
 G  connected_order_arc_425
 L  arc_capacity_426
 G  connected_order_arc_427
 L  arc_capacity_428
 G  connected_order_arc_429
 L  arc_capacity_430
 G  connected_order_arc_431
 L  arc_capacity_432
 G  connected_order_arc_433
 L  arc_capacity_434
 L  arc_capacity_435
 G  connected_order_arc_436
 L  arc_capacity_437
 G  connected_order_arc_438
 L  arc_capacity_439
 G  connected_order_arc_440
 L  arc_capacity_441
 G  connected_order_arc_442
 L  arc_capacity_443
 G  connected_order_arc_444
 L  arc_capacity_445
 G  connected_order_arc_446
 L  arc_capacity_447
 G  connected_order_arc_448
 L  arc_capacity_449
 G  connected_order_arc_450
 L  arc_capacity_451
 G  connected_order_arc_452
 L  arc_capacity_453
 G  connected_order_arc_454
 L  arc_capacity_455
 G  connected_order_arc_456
 L  arc_capacity_457
 G  connected_order_arc_458
 L  arc_capacity_459
 L  arc_capacity_460
 G  connected_order_arc_461
 L  arc_capacity_462
 G  connected_order_arc_463
 L  arc_capacity_464
 G  connected_order_arc_465
 L  arc_capacity_466
 G  connected_order_arc_467
 L  arc_capacity_468
 G  connected_order_arc_469
 L  arc_capacity_470
 G  connected_order_arc_471
 L  arc_capacity_472
 G  connected_order_arc_473
 L  arc_capacity_474
 G  connected_order_arc_475
 L  arc_capacity_476
 G  connected_order_arc_477
 L  arc_capacity_478
 G  connected_order_arc_479
 L  arc_capacity_480
 G  connected_order_arc_481
 L  arc_capacity_482
 G  connected_order_arc_483
 L  arc_capacity_484
 L  arc_capacity_485
 G  connected_order_arc_486
 L  arc_capacity_487
 G  connected_order_arc_488
 L  arc_capacity_489
 G  connected_order_arc_490
 L  arc_capacity_491
 G  connected_order_arc_492
 L  arc_capacity_493
 G  connected_order_arc_494
 L  arc_capacity_495
 G  connected_order_arc_496
 L  arc_capacity_497
 G  connected_order_arc_498
 L  arc_capacity_499
 G  connected_order_arc_500
 L  arc_capacity_501
 G  connected_order_arc_502
 L  arc_capacity_503
 G  connected_order_arc_504
 L  arc_capacity_505
 G  connected_order_arc_506
 L  arc_capacity_507
 G  connected_order_arc_508
 L  arc_capacity_509
 L  arc_capacity_510
 G  connected_order_arc_511
 L  arc_capacity_512
 G  connected_order_arc_513
 L  arc_capacity_514
 G  connected_order_arc_515
 L  arc_capacity_516
 G  connected_order_arc_517
 L  arc_capacity_518
 G  connected_order_arc_519
 L  arc_capacity_520
 G  connected_order_arc_521
 L  arc_capacity_522
 G  connected_order_arc_523
 L  arc_capacity_524
 G  connected_order_arc_525
 L  arc_capacity_526
 G  connected_order_arc_527
 L  arc_capacity_528
 G  connected_order_arc_529
 L  arc_capacity_530
 G  connected_order_arc_531
 L  arc_capacity_532
 G  connected_order_arc_533
 L  arc_capacity_534
 L  arc_capacity_535
 G  connected_order_arc_536
 L  arc_capacity_537
 G  connected_order_arc_538
 L  arc_capacity_539
 G  connected_order_arc_540
 L  arc_capacity_541
 G  connected_order_arc_542
 L  arc_capacity_543
 G  connected_order_arc_544
 L  arc_capacity_545
 G  connected_order_arc_546
 L  arc_capacity_547
 G  connected_order_arc_548
 L  arc_capacity_549
 G  connected_order_arc_550
 L  arc_capacity_551
 G  connected_order_arc_552
 L  arc_capacity_553
 G  connected_order_arc_554
 L  arc_capacity_555
 G  connected_order_arc_556
 L  arc_capacity_557
 G  connected_order_arc_558
 L  arc_capacity_559
 L  arc_capacity_560
 G  connected_order_arc_561
 L  arc_capacity_562
 G  connected_order_arc_563
 L  arc_capacity_564
 G  connected_order_arc_565
 L  arc_capacity_566
 G  connected_order_arc_567
 L  arc_capacity_568
 G  connected_order_arc_569
 L  arc_capacity_570
 G  connected_order_arc_571
 L  arc_capacity_572
 G  connected_order_arc_573
 L  arc_capacity_574
 G  connected_order_arc_575
 L  arc_capacity_576
 G  connected_order_arc_577
 L  arc_capacity_578
 G  connected_order_arc_579
 L  arc_capacity_580
 G  connected_order_arc_581
 L  arc_capacity_582
 G  connected_order_arc_583
 L  arc_capacity_584
 L  arc_capacity_585
 G  connected_order_arc_586
 L  arc_capacity_587
 G  connected_order_arc_588
 L  arc_capacity_589
 G  connected_order_arc_590
 L  arc_capacity_591
 G  connected_order_arc_592
 L  arc_capacity_593
 G  connected_order_arc_594
 L  arc_capacity_595
 G  connected_order_arc_596
 L  arc_capacity_597
 G  connected_order_arc_598
 L  arc_capacity_599
 G  connected_order_arc_600
 L  arc_capacity_601
 G  connected_order_arc_602
 L  arc_capacity_603
 G  connected_order_arc_604
 L  arc_capacity_605
 G  connected_order_arc_606
 L  arc_capacity_607
 G  connected_order_arc_608
 L  arc_capacity_609
 L  arc_capacity_610
 G  connected_order_arc_611
 L  arc_capacity_612
 G  connected_order_arc_613
 L  arc_capacity_614
 G  connected_order_arc_615
 L  arc_capacity_616
 G  connected_order_arc_617
 L  arc_capacity_618
 G  connected_order_arc_619
 L  arc_capacity_620
 G  connected_order_arc_621
 L  arc_capacity_622
 G  connected_order_arc_623
 L  arc_capacity_624
 G  connected_order_arc_625
 L  arc_capacity_626
 G  connected_order_arc_627
 L  arc_capacity_628
 G  connected_order_arc_629
 L  arc_capacity_630
 G  connected_order_arc_631
 L  arc_capacity_632
 G  connected_order_arc_633
 L  arc_capacity_634
 L  arc_capacity_635
 G  connected_order_arc_636
 L  arc_capacity_637
 G  connected_order_arc_638
 L  arc_capacity_639
 G  connected_order_arc_640
 L  arc_capacity_641
 G  connected_order_arc_642
 L  arc_capacity_643
 G  connected_order_arc_644
 L  arc_capacity_645
 G  connected_order_arc_646
 L  arc_capacity_647
 G  connected_order_arc_648
 L  arc_capacity_649
 G  connected_order_arc_650
 L  arc_capacity_651
 G  connected_order_arc_652
 L  arc_capacity_653
 G  connected_order_arc_654
 L  arc_capacity_655
 G  connected_order_arc_656
 L  arc_capacity_657
 G  connected_order_arc_658
 L  arc_capacity_659
 L  arc_capacity_660
 G  connected_order_arc_661
 L  arc_capacity_662
 G  connected_order_arc_663
 L  arc_capacity_664
 G  connected_order_arc_665
 L  arc_capacity_666
 G  connected_order_arc_667
 L  arc_capacity_668
 G  connected_order_arc_669
 L  arc_capacity_670
 G  connected_order_arc_671
 L  arc_capacity_672
 G  connected_order_arc_673
 L  arc_capacity_674
 G  connected_order_arc_675
 L  arc_capacity_676
 G  connected_order_arc_677
 L  arc_capacity_678
 G  connected_order_arc_679
 L  arc_capacity_680
 G  connected_order_arc_681
 L  arc_capacity_682
 G  connected_order_arc_683
 L  arc_capacity_684
 L  arc_capacity_685
 G  connected_order_arc_686
 L  arc_capacity_687
 G  connected_order_arc_688
 L  arc_capacity_689
 G  connected_order_arc_690
 L  arc_capacity_691
 G  connected_order_arc_692
 L  arc_capacity_693
 G  connected_order_arc_694
 L  arc_capacity_695
 G  connected_order_arc_696
 L  arc_capacity_697
 G  connected_order_arc_698
 L  arc_capacity_699
 G  connected_order_arc_700
 L  arc_capacity_701
 G  connected_order_arc_702
 L  arc_capacity_703
 G  connected_order_arc_704
 L  arc_capacity_705
 G  connected_order_arc_706
 L  arc_capacity_707
 G  connected_order_arc_708
 L  arc_capacity_709
 L  arc_capacity_710
 G  connected_order_arc_711
 L  arc_capacity_712
 G  connected_order_arc_713
 L  arc_capacity_714
 G  connected_order_arc_715
 L  arc_capacity_716
 G  connected_order_arc_717
 L  arc_capacity_718
 G  connected_order_arc_719
 L  arc_capacity_720
 G  connected_order_arc_721
 L  arc_capacity_722
 G  connected_order_arc_723
 L  arc_capacity_724
 G  connected_order_arc_725
 L  arc_capacity_726
 G  connected_order_arc_727
 L  arc_capacity_728
 G  connected_order_arc_729
 L  arc_capacity_730
 G  connected_order_arc_731
 L  arc_capacity_732
 G  connected_order_arc_733
 E  depot_departure_or_bypass_734
 E  depot_return_or_bypass_735
 E  out_degree_736
 E  in_degree_737
 G  order_active_lb_738
 L  order_active_ub_739
 E  segment_load_conservation_740
 G  segment_prefix_lb_741
 L  segment_prefix_ub_742
 E  out_degree_743
 E  in_degree_744
 G  order_active_lb_745
 L  order_active_ub_746
 E  segment_load_conservation_747
 G  segment_prefix_lb_748
 L  segment_prefix_ub_749
 E  out_degree_750
 E  in_degree_751
 G  order_active_lb_752
 L  order_active_ub_753
 E  segment_load_conservation_754
 G  segment_prefix_lb_755
 L  segment_prefix_ub_756
 E  out_degree_757
 E  in_degree_758
 G  order_active_lb_759
 L  order_active_ub_760
 E  segment_load_conservation_761
 G  segment_prefix_lb_762
 L  segment_prefix_ub_763
 E  out_degree_764
 E  in_degree_765
 G  order_active_lb_766
 L  order_active_ub_767
 E  segment_load_conservation_768
 G  segment_prefix_lb_769
 L  segment_prefix_ub_770
 E  out_degree_771
 E  in_degree_772
 G  order_active_lb_773
 L  order_active_ub_774
 E  service_visit_def_775
 E  free_load_conservation_776
 E  out_degree_777
 E  in_degree_778
 G  order_active_lb_779
 L  order_active_ub_780
 E  service_visit_def_781
 E  free_load_conservation_782
 E  out_degree_783
 E  in_degree_784
 G  order_active_lb_785
 L  order_active_ub_786
 E  service_visit_def_787
 E  free_load_conservation_788
 E  out_degree_789
 E  in_degree_790
 G  order_active_lb_791
 L  order_active_ub_792
 E  service_visit_def_793
 E  free_load_conservation_794
 E  out_degree_795
 E  in_degree_796
 G  order_active_lb_797
 L  order_active_ub_798
 E  service_visit_def_799
 E  free_load_conservation_800
 E  out_degree_801
 E  in_degree_802
 G  order_active_lb_803
 L  order_active_ub_804
 E  service_visit_def_805
 E  free_load_conservation_806
 E  out_degree_807
 E  in_degree_808
 G  order_active_lb_809
 L  order_active_ub_810
 E  service_visit_def_811
 E  free_load_conservation_812
 E  out_degree_813
 E  in_degree_814
 G  order_active_lb_815
 L  order_active_ub_816
 E  service_visit_def_817
 E  free_load_conservation_818
 G  fixed_segment_relative_order_819
 G  fixed_segment_relative_order_820
 G  fixed_segment_relative_order_821
 G  fixed_segment_relative_order_822
 L  original_T_including_depot_unload_823
 L  arc_capacity_824
 L  arc_capacity_825
 L  arc_capacity_826
 L  arc_capacity_827
 L  arc_capacity_828
 L  arc_capacity_829
 L  arc_capacity_830
 L  arc_capacity_831
 L  arc_capacity_832
 L  arc_capacity_833
 L  arc_capacity_834
 L  arc_capacity_835
 L  arc_capacity_836
 L  arc_capacity_837
 L  arc_capacity_838
 G  connected_order_arc_839
 L  arc_capacity_840
 G  connected_order_arc_841
 L  arc_capacity_842
 G  connected_order_arc_843
 L  arc_capacity_844
 G  connected_order_arc_845
 L  arc_capacity_846
 G  connected_order_arc_847
 L  arc_capacity_848
 G  connected_order_arc_849
 L  arc_capacity_850
 G  connected_order_arc_851
 L  arc_capacity_852
 G  connected_order_arc_853
 L  arc_capacity_854
 G  connected_order_arc_855
 L  arc_capacity_856
 G  connected_order_arc_857
 L  arc_capacity_858
 G  connected_order_arc_859
 L  arc_capacity_860
 L  arc_capacity_861
 G  connected_order_arc_862
 L  arc_capacity_863
 G  connected_order_arc_864
 L  arc_capacity_865
 G  connected_order_arc_866
 L  arc_capacity_867
 G  connected_order_arc_868
 L  arc_capacity_869
 G  connected_order_arc_870
 L  arc_capacity_871
 G  connected_order_arc_872
 L  arc_capacity_873
 G  connected_order_arc_874
 L  arc_capacity_875
 G  connected_order_arc_876
 L  arc_capacity_877
 G  connected_order_arc_878
 L  arc_capacity_879
 G  connected_order_arc_880
 L  arc_capacity_881
 G  connected_order_arc_882
 L  arc_capacity_883
 L  arc_capacity_884
 G  connected_order_arc_885
 L  arc_capacity_886
 G  connected_order_arc_887
 L  arc_capacity_888
 G  connected_order_arc_889
 L  arc_capacity_890
 G  connected_order_arc_891
 L  arc_capacity_892
 G  connected_order_arc_893
 L  arc_capacity_894
 G  connected_order_arc_895
 L  arc_capacity_896
 G  connected_order_arc_897
 L  arc_capacity_898
 G  connected_order_arc_899
 L  arc_capacity_900
 G  connected_order_arc_901
 L  arc_capacity_902
 G  connected_order_arc_903
 L  arc_capacity_904
 G  connected_order_arc_905
 L  arc_capacity_906
 L  arc_capacity_907
 G  connected_order_arc_908
 L  arc_capacity_909
 G  connected_order_arc_910
 L  arc_capacity_911
 G  connected_order_arc_912
 L  arc_capacity_913
 G  connected_order_arc_914
 L  arc_capacity_915
 G  connected_order_arc_916
 L  arc_capacity_917
 G  connected_order_arc_918
 L  arc_capacity_919
 G  connected_order_arc_920
 L  arc_capacity_921
 G  connected_order_arc_922
 L  arc_capacity_923
 G  connected_order_arc_924
 L  arc_capacity_925
 G  connected_order_arc_926
 L  arc_capacity_927
 G  connected_order_arc_928
 L  arc_capacity_929
 L  arc_capacity_930
 G  connected_order_arc_931
 L  arc_capacity_932
 G  connected_order_arc_933
 L  arc_capacity_934
 G  connected_order_arc_935
 L  arc_capacity_936
 G  connected_order_arc_937
 L  arc_capacity_938
 G  connected_order_arc_939
 L  arc_capacity_940
 G  connected_order_arc_941
 L  arc_capacity_942
 G  connected_order_arc_943
 L  arc_capacity_944
 G  connected_order_arc_945
 L  arc_capacity_946
 G  connected_order_arc_947
 L  arc_capacity_948
 G  connected_order_arc_949
 L  arc_capacity_950
 G  connected_order_arc_951
 L  arc_capacity_952
 L  arc_capacity_953
 G  connected_order_arc_954
 L  arc_capacity_955
 G  connected_order_arc_956
 L  arc_capacity_957
 G  connected_order_arc_958
 L  arc_capacity_959
 G  connected_order_arc_960
 L  arc_capacity_961
 G  connected_order_arc_962
 L  arc_capacity_963
 G  connected_order_arc_964
 L  arc_capacity_965
 G  connected_order_arc_966
 L  arc_capacity_967
 G  connected_order_arc_968
 L  arc_capacity_969
 G  connected_order_arc_970
 L  arc_capacity_971
 G  connected_order_arc_972
 L  arc_capacity_973
 G  connected_order_arc_974
 L  arc_capacity_975
 L  arc_capacity_976
 G  connected_order_arc_977
 L  arc_capacity_978
 G  connected_order_arc_979
 L  arc_capacity_980
 G  connected_order_arc_981
 L  arc_capacity_982
 G  connected_order_arc_983
 L  arc_capacity_984
 G  connected_order_arc_985
 L  arc_capacity_986
 G  connected_order_arc_987
 L  arc_capacity_988
 G  connected_order_arc_989
 L  arc_capacity_990
 G  connected_order_arc_991
 L  arc_capacity_992
 G  connected_order_arc_993
 L  arc_capacity_994
 G  connected_order_arc_995
 L  arc_capacity_996
 G  connected_order_arc_997
 L  arc_capacity_998
 L  arc_capacity_999
 G  connected_order_arc_1000
 L  arc_capacity_1001
 G  connected_order_arc_1002
 L  arc_capacity_1003
 G  connected_order_arc_1004
 L  arc_capacity_1005
 G  connected_order_arc_1006
 L  arc_capacity_1007
 G  connected_order_arc_1008
 L  arc_capacity_1009
 G  connected_order_arc_1010
 L  arc_capacity_1011
 G  connected_order_arc_1012
 L  arc_capacity_1013
 G  connected_order_arc_1014
 L  arc_capacity_1015
 G  connected_order_arc_1016
 L  arc_capacity_1017
 G  connected_order_arc_1018
 L  arc_capacity_1019
 G  connected_order_arc_1020
 L  arc_capacity_1021
 L  arc_capacity_1022
 G  connected_order_arc_1023
 L  arc_capacity_1024
 G  connected_order_arc_1025
 L  arc_capacity_1026
 G  connected_order_arc_1027
 L  arc_capacity_1028
 G  connected_order_arc_1029
 L  arc_capacity_1030
 G  connected_order_arc_1031
 L  arc_capacity_1032
 G  connected_order_arc_1033
 L  arc_capacity_1034
 G  connected_order_arc_1035
 L  arc_capacity_1036
 G  connected_order_arc_1037
 L  arc_capacity_1038
 G  connected_order_arc_1039
 L  arc_capacity_1040
 G  connected_order_arc_1041
 L  arc_capacity_1042
 G  connected_order_arc_1043
 L  arc_capacity_1044
 L  arc_capacity_1045
 G  connected_order_arc_1046
 L  arc_capacity_1047
 G  connected_order_arc_1048
 L  arc_capacity_1049
 G  connected_order_arc_1050
 L  arc_capacity_1051
 G  connected_order_arc_1052
 L  arc_capacity_1053
 G  connected_order_arc_1054
 L  arc_capacity_1055
 G  connected_order_arc_1056
 L  arc_capacity_1057
 G  connected_order_arc_1058
 L  arc_capacity_1059
 G  connected_order_arc_1060
 L  arc_capacity_1061
 G  connected_order_arc_1062
 L  arc_capacity_1063
 G  connected_order_arc_1064
 L  arc_capacity_1065
 G  connected_order_arc_1066
 L  arc_capacity_1067
 L  arc_capacity_1068
 G  connected_order_arc_1069
 L  arc_capacity_1070
 G  connected_order_arc_1071
 L  arc_capacity_1072
 G  connected_order_arc_1073
 L  arc_capacity_1074
 G  connected_order_arc_1075
 L  arc_capacity_1076
 G  connected_order_arc_1077
 L  arc_capacity_1078
 G  connected_order_arc_1079
 L  arc_capacity_1080
 G  connected_order_arc_1081
 L  arc_capacity_1082
 G  connected_order_arc_1083
 L  arc_capacity_1084
 G  connected_order_arc_1085
 L  arc_capacity_1086
 G  connected_order_arc_1087
 L  arc_capacity_1088
 G  connected_order_arc_1089
 L  arc_capacity_1090
 L  arc_capacity_1091
 G  connected_order_arc_1092
 L  arc_capacity_1093
 G  connected_order_arc_1094
 L  arc_capacity_1095
 G  connected_order_arc_1096
 L  arc_capacity_1097
 G  connected_order_arc_1098
 L  arc_capacity_1099
 G  connected_order_arc_1100
 L  arc_capacity_1101
 G  connected_order_arc_1102
 L  arc_capacity_1103
 G  connected_order_arc_1104
 L  arc_capacity_1105
 G  connected_order_arc_1106
 L  arc_capacity_1107
 G  connected_order_arc_1108
 L  arc_capacity_1109
 G  connected_order_arc_1110
 L  arc_capacity_1111
 G  connected_order_arc_1112
 E  depot_departure_or_bypass_1113
 E  depot_return_or_bypass_1114
 E  out_degree_1115
 E  in_degree_1116
 G  order_active_lb_1117
 L  order_active_ub_1118
 E  segment_load_conservation_1119
 G  segment_prefix_lb_1120
 L  segment_prefix_ub_1121
 E  out_degree_1122
 E  in_degree_1123
 G  order_active_lb_1124
 L  order_active_ub_1125
 E  segment_load_conservation_1126
 G  segment_prefix_lb_1127
 L  segment_prefix_ub_1128
 E  out_degree_1129
 E  in_degree_1130
 G  order_active_lb_1131
 L  order_active_ub_1132
 E  segment_load_conservation_1133
 G  segment_prefix_lb_1134
 L  segment_prefix_ub_1135
 E  out_degree_1136
 E  in_degree_1137
 G  order_active_lb_1138
 L  order_active_ub_1139
 E  segment_load_conservation_1140
 G  segment_prefix_lb_1141
 L  segment_prefix_ub_1142
 E  out_degree_1143
 E  in_degree_1144
 G  order_active_lb_1145
 L  order_active_ub_1146
 E  service_visit_def_1147
 E  free_load_conservation_1148
 E  out_degree_1149
 E  in_degree_1150
 G  order_active_lb_1151
 L  order_active_ub_1152
 E  service_visit_def_1153
 E  free_load_conservation_1154
 E  out_degree_1155
 E  in_degree_1156
 G  order_active_lb_1157
 L  order_active_ub_1158
 E  service_visit_def_1159
 E  free_load_conservation_1160
 E  out_degree_1161
 E  in_degree_1162
 G  order_active_lb_1163
 L  order_active_ub_1164
 E  service_visit_def_1165
 E  free_load_conservation_1166
 E  out_degree_1167
 E  in_degree_1168
 G  order_active_lb_1169
 L  order_active_ub_1170
 E  service_visit_def_1171
 E  free_load_conservation_1172
 E  out_degree_1173
 E  in_degree_1174
 G  order_active_lb_1175
 L  order_active_ub_1176
 E  service_visit_def_1177
 E  free_load_conservation_1178
 E  out_degree_1179
 E  in_degree_1180
 G  order_active_lb_1181
 L  order_active_ub_1182
 E  service_visit_def_1183
 E  free_load_conservation_1184
 E  out_degree_1185
 E  in_degree_1186
 G  order_active_lb_1187
 L  order_active_ub_1188
 E  service_visit_def_1189
 E  free_load_conservation_1190
 G  fixed_segment_relative_order_1191
 G  fixed_segment_relative_order_1192
 G  fixed_segment_relative_order_1193
 L  original_T_including_depot_unload_1194
 L  arc_capacity_1195
 L  arc_capacity_1196
 L  arc_capacity_1197
 L  arc_capacity_1198
 L  arc_capacity_1199
 L  arc_capacity_1200
 L  arc_capacity_1201
 L  arc_capacity_1202
 L  arc_capacity_1203
 L  arc_capacity_1204
 L  arc_capacity_1205
 L  arc_capacity_1206
 L  arc_capacity_1207
 L  arc_capacity_1208
 G  connected_order_arc_1209
 L  arc_capacity_1210
 G  connected_order_arc_1211
 L  arc_capacity_1212
 G  connected_order_arc_1213
 L  arc_capacity_1214
 G  connected_order_arc_1215
 L  arc_capacity_1216
 G  connected_order_arc_1217
 L  arc_capacity_1218
 G  connected_order_arc_1219
 L  arc_capacity_1220
 G  connected_order_arc_1221
 L  arc_capacity_1222
 G  connected_order_arc_1223
 L  arc_capacity_1224
 G  connected_order_arc_1225
 L  arc_capacity_1226
 G  connected_order_arc_1227
 L  arc_capacity_1228
 L  arc_capacity_1229
 G  connected_order_arc_1230
 L  arc_capacity_1231
 G  connected_order_arc_1232
 L  arc_capacity_1233
 G  connected_order_arc_1234
 L  arc_capacity_1235
 G  connected_order_arc_1236
 L  arc_capacity_1237
 G  connected_order_arc_1238
 L  arc_capacity_1239
 G  connected_order_arc_1240
 L  arc_capacity_1241
 G  connected_order_arc_1242
 L  arc_capacity_1243
 G  connected_order_arc_1244
 L  arc_capacity_1245
 G  connected_order_arc_1246
 L  arc_capacity_1247
 G  connected_order_arc_1248
 L  arc_capacity_1249
 L  arc_capacity_1250
 G  connected_order_arc_1251
 L  arc_capacity_1252
 G  connected_order_arc_1253
 L  arc_capacity_1254
 G  connected_order_arc_1255
 L  arc_capacity_1256
 G  connected_order_arc_1257
 L  arc_capacity_1258
 G  connected_order_arc_1259
 L  arc_capacity_1260
 G  connected_order_arc_1261
 L  arc_capacity_1262
 G  connected_order_arc_1263
 L  arc_capacity_1264
 G  connected_order_arc_1265
 L  arc_capacity_1266
 G  connected_order_arc_1267
 L  arc_capacity_1268
 G  connected_order_arc_1269
 L  arc_capacity_1270
 L  arc_capacity_1271
 G  connected_order_arc_1272
 L  arc_capacity_1273
 G  connected_order_arc_1274
 L  arc_capacity_1275
 G  connected_order_arc_1276
 L  arc_capacity_1277
 G  connected_order_arc_1278
 L  arc_capacity_1279
 G  connected_order_arc_1280
 L  arc_capacity_1281
 G  connected_order_arc_1282
 L  arc_capacity_1283
 G  connected_order_arc_1284
 L  arc_capacity_1285
 G  connected_order_arc_1286
 L  arc_capacity_1287
 G  connected_order_arc_1288
 L  arc_capacity_1289
 G  connected_order_arc_1290
 L  arc_capacity_1291
 L  arc_capacity_1292
 G  connected_order_arc_1293
 L  arc_capacity_1294
 G  connected_order_arc_1295
 L  arc_capacity_1296
 G  connected_order_arc_1297
 L  arc_capacity_1298
 G  connected_order_arc_1299
 L  arc_capacity_1300
 G  connected_order_arc_1301
 L  arc_capacity_1302
 G  connected_order_arc_1303
 L  arc_capacity_1304
 G  connected_order_arc_1305
 L  arc_capacity_1306
 G  connected_order_arc_1307
 L  arc_capacity_1308
 G  connected_order_arc_1309
 L  arc_capacity_1310
 G  connected_order_arc_1311
 L  arc_capacity_1312
 L  arc_capacity_1313
 G  connected_order_arc_1314
 L  arc_capacity_1315
 G  connected_order_arc_1316
 L  arc_capacity_1317
 G  connected_order_arc_1318
 L  arc_capacity_1319
 G  connected_order_arc_1320
 L  arc_capacity_1321
 G  connected_order_arc_1322
 L  arc_capacity_1323
 G  connected_order_arc_1324
 L  arc_capacity_1325
 G  connected_order_arc_1326
 L  arc_capacity_1327
 G  connected_order_arc_1328
 L  arc_capacity_1329
 G  connected_order_arc_1330
 L  arc_capacity_1331
 G  connected_order_arc_1332
 L  arc_capacity_1333
 L  arc_capacity_1334
 G  connected_order_arc_1335
 L  arc_capacity_1336
 G  connected_order_arc_1337
 L  arc_capacity_1338
 G  connected_order_arc_1339
 L  arc_capacity_1340
 G  connected_order_arc_1341
 L  arc_capacity_1342
 G  connected_order_arc_1343
 L  arc_capacity_1344
 G  connected_order_arc_1345
 L  arc_capacity_1346
 G  connected_order_arc_1347
 L  arc_capacity_1348
 G  connected_order_arc_1349
 L  arc_capacity_1350
 G  connected_order_arc_1351
 L  arc_capacity_1352
 G  connected_order_arc_1353
 L  arc_capacity_1354
 L  arc_capacity_1355
 G  connected_order_arc_1356
 L  arc_capacity_1357
 G  connected_order_arc_1358
 L  arc_capacity_1359
 G  connected_order_arc_1360
 L  arc_capacity_1361
 G  connected_order_arc_1362
 L  arc_capacity_1363
 G  connected_order_arc_1364
 L  arc_capacity_1365
 G  connected_order_arc_1366
 L  arc_capacity_1367
 G  connected_order_arc_1368
 L  arc_capacity_1369
 G  connected_order_arc_1370
 L  arc_capacity_1371
 G  connected_order_arc_1372
 L  arc_capacity_1373
 G  connected_order_arc_1374
 L  arc_capacity_1375
 L  arc_capacity_1376
 G  connected_order_arc_1377
 L  arc_capacity_1378
 G  connected_order_arc_1379
 L  arc_capacity_1380
 G  connected_order_arc_1381
 L  arc_capacity_1382
 G  connected_order_arc_1383
 L  arc_capacity_1384
 G  connected_order_arc_1385
 L  arc_capacity_1386
 G  connected_order_arc_1387
 L  arc_capacity_1388
 G  connected_order_arc_1389
 L  arc_capacity_1390
 G  connected_order_arc_1391
 L  arc_capacity_1392
 G  connected_order_arc_1393
 L  arc_capacity_1394
 G  connected_order_arc_1395
 L  arc_capacity_1396
 L  arc_capacity_1397
 G  connected_order_arc_1398
 L  arc_capacity_1399
 G  connected_order_arc_1400
 L  arc_capacity_1401
 G  connected_order_arc_1402
 L  arc_capacity_1403
 G  connected_order_arc_1404
 L  arc_capacity_1405
 G  connected_order_arc_1406
 L  arc_capacity_1407
 G  connected_order_arc_1408
 L  arc_capacity_1409
 G  connected_order_arc_1410
 L  arc_capacity_1411
 G  connected_order_arc_1412
 L  arc_capacity_1413
 G  connected_order_arc_1414
 L  arc_capacity_1415
 G  connected_order_arc_1416
 L  arc_capacity_1417
 L  arc_capacity_1418
 G  connected_order_arc_1419
 L  arc_capacity_1420
 G  connected_order_arc_1421
 L  arc_capacity_1422
 G  connected_order_arc_1423
 L  arc_capacity_1424
 G  connected_order_arc_1425
 L  arc_capacity_1426
 G  connected_order_arc_1427
 L  arc_capacity_1428
 G  connected_order_arc_1429
 L  arc_capacity_1430
 G  connected_order_arc_1431
 L  arc_capacity_1432
 G  connected_order_arc_1433
 L  arc_capacity_1434
 G  connected_order_arc_1435
 L  arc_capacity_1436
 G  connected_order_arc_1437
 E  depot_departure_or_bypass_1438
 E  depot_return_or_bypass_1439
 E  out_degree_1440
 E  in_degree_1441
 G  order_active_lb_1442
 L  order_active_ub_1443
 E  segment_load_conservation_1444
 G  segment_prefix_lb_1445
 L  segment_prefix_ub_1446
 E  out_degree_1447
 E  in_degree_1448
 G  order_active_lb_1449
 L  order_active_ub_1450
 E  segment_load_conservation_1451
 G  segment_prefix_lb_1452
 L  segment_prefix_ub_1453
 E  out_degree_1454
 E  in_degree_1455
 G  order_active_lb_1456
 L  order_active_ub_1457
 E  segment_load_conservation_1458
 G  segment_prefix_lb_1459
 L  segment_prefix_ub_1460
 E  out_degree_1461
 E  in_degree_1462
 G  order_active_lb_1463
 L  order_active_ub_1464
 E  service_visit_def_1465
 E  free_load_conservation_1466
 E  out_degree_1467
 E  in_degree_1468
 G  order_active_lb_1469
 L  order_active_ub_1470
 E  service_visit_def_1471
 E  free_load_conservation_1472
 E  out_degree_1473
 E  in_degree_1474
 G  order_active_lb_1475
 L  order_active_ub_1476
 E  service_visit_def_1477
 E  free_load_conservation_1478
 E  out_degree_1479
 E  in_degree_1480
 G  order_active_lb_1481
 L  order_active_ub_1482
 E  service_visit_def_1483
 E  free_load_conservation_1484
 E  out_degree_1485
 E  in_degree_1486
 G  order_active_lb_1487
 L  order_active_ub_1488
 E  service_visit_def_1489
 E  free_load_conservation_1490
 E  out_degree_1491
 E  in_degree_1492
 G  order_active_lb_1493
 L  order_active_ub_1494
 E  service_visit_def_1495
 E  free_load_conservation_1496
 E  out_degree_1497
 E  in_degree_1498
 G  order_active_lb_1499
 L  order_active_ub_1500
 E  service_visit_def_1501
 E  free_load_conservation_1502
 E  out_degree_1503
 E  in_degree_1504
 G  order_active_lb_1505
 L  order_active_ub_1506
 E  service_visit_def_1507
 E  free_load_conservation_1508
 G  fixed_segment_relative_order_1509
 G  fixed_segment_relative_order_1510
 L  original_T_including_depot_unload_1511
COLUMNS
    t         normalized_mass_4_33  -1
    t         normalized_mass_6_54  -1
    t         normalized_mass_34_89  -1
    t         normalized_mass_3_118  -1
    t         normalized_mass_22_153  -1
    t         normalized_mass_5_188  -1
    t         normalized_mass_27_205  -1
    t         normalized_mass_8_234  -1
    t         normalization_295  2.3130952380952380e+01
    t         full_original_Gini_296  -9.0273809523809433e+01
    q         OBJ       1
    q         parent_nonstrict_scope_238  1
    q         full_original_Gini_296  35
    MARKER    'MARKER'                 'INTORG'
    x_4_0     OBJ       1.9549429837111887e-02
    x_4_0     product_lb_0  -2.5358490566012373e-02
    x_4_0     product_ub_1  -4.3232115285684006e-02
    x_4_0     onehot_4_32  1
    x_4_0     parent_nonstrict_scope_238  0.0456153362865944
    x_4_0     unique_nonzero_owner_297  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_0     product_lb_0  1
    w_4_0     product_ub_1  1
    w_4_0     normalized_mass_4_33  1
    w_4_0     full_original_Gini_296  -2.3130952380952380e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_1     OBJ       1.3032953224741260e-02
    x_4_1     product_lb_2  -2.5358490566012373e-02
    x_4_1     product_ub_3  -4.3232115285684006e-02
    x_4_1     onehot_4_32  1
    x_4_1     stock_lb_236  1
    x_4_1     stock_ub_237  1
    x_4_1     parent_nonstrict_scope_238  3.9098859674223774e-02
    x_4_1     unique_nonzero_owner_298  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_1     product_lb_2  1
    w_4_1     product_ub_3  1
    w_4_1     normalized_mass_4_33  1
    w_4_1     normalized_ratio_4_34  -1.4285714285714285e-01
    w_4_1     full_original_Gini_296  -1.9559523809523817e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_2     OBJ       6.5164766123706336e-03
    x_4_2     product_lb_4  -2.5358490566012373e-02
    x_4_2     product_ub_5  -4.3232115285684006e-02
    x_4_2     onehot_4_32  1
    x_4_2     stock_lb_236  2
    x_4_2     stock_ub_237  2
    x_4_2     parent_nonstrict_scope_238  3.2582383061853147e-02
    MARKER    'MARKER'                 'INTEND'
    w_4_2     product_lb_4  1
    w_4_2     product_ub_5  1
    w_4_2     normalized_mass_4_33  1
    w_4_2     normalized_ratio_4_34  -2.8571428571428570e-01
    w_4_2     full_original_Gini_296  -1.5988095238095232e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_3     product_lb_6  -2.5358490566012373e-02
    x_4_3     product_ub_7  -4.3232115285684006e-02
    x_4_3     onehot_4_32  1
    x_4_3     stock_lb_236  3
    x_4_3     stock_ub_237  3
    x_4_3     parent_nonstrict_scope_238  2.6065906449482514e-02
    x_4_3     unique_nonzero_owner_299  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_3     product_lb_6  1
    w_4_3     product_ub_7  1
    w_4_3     normalized_mass_4_33  1
    w_4_3     normalized_ratio_4_34  -4.2857142857142855e-01
    w_4_3     full_original_Gini_296  -1.2473809523809519e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_4     OBJ       -6.5164766123706266e-03
    x_4_4     product_lb_8  -2.5358490566012373e-02
    x_4_4     product_ub_9  -4.3232115285684006e-02
    x_4_4     onehot_4_32  1
    x_4_4     stock_lb_236  4
    x_4_4     stock_ub_237  4
    x_4_4     parent_nonstrict_scope_238  1.9549429837111887e-02
    x_4_4     unique_nonzero_owner_300  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_4     product_lb_8  1
    w_4_4     product_ub_9  1
    w_4_4     normalized_mass_4_33  1
    w_4_4     normalized_ratio_4_34  -5.7142857142857140e-01
    w_4_4     full_original_Gini_296  -9.1880952380952419e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_5     OBJ       -1.3032953224741252e-02
    x_4_5     product_lb_10  -2.5358490566012373e-02
    x_4_5     product_ub_11  -4.3232115285684006e-02
    x_4_5     onehot_4_32  1
    x_4_5     stock_lb_236  5
    x_4_5     stock_ub_237  5
    x_4_5     parent_nonstrict_scope_238  1.3032953224741262e-02
    x_4_5     unique_nonzero_owner_301  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_5     product_lb_10  1
    w_4_5     product_ub_11  1
    w_4_5     normalized_mass_4_33  1
    w_4_5     normalized_ratio_4_34  -7.1428571428571419e-01
    w_4_5     full_original_Gini_296  -6.2714285714285705e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_6     OBJ       -1.9549429837111883e-02
    x_4_6     product_lb_12  -2.5358490566012373e-02
    x_4_6     product_ub_13  -4.3232115285684006e-02
    x_4_6     onehot_4_32  1
    x_4_6     stock_lb_236  6
    x_4_6     stock_ub_237  6
    x_4_6     parent_nonstrict_scope_238  6.5164766123706310e-03
    x_4_6     unique_nonzero_owner_302  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_6     product_lb_12  1
    w_4_6     product_ub_13  1
    w_4_6     normalized_mass_4_33  1
    w_4_6     normalized_ratio_4_34  -8.5714285714285710e-01
    w_4_6     full_original_Gini_296  -4.7619047619047619e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_7     OBJ       -2.6065906449482514e-02
    x_4_7     product_lb_14  -2.5358490566012373e-02
    x_4_7     product_ub_15  -4.3232115285684006e-02
    x_4_7     onehot_4_32  1
    x_4_7     stock_lb_236  7
    x_4_7     stock_ub_237  7
    x_4_7     unique_nonzero_owner_303  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_7     product_lb_14  1
    w_4_7     product_ub_15  1
    w_4_7     normalized_mass_4_33  1
    w_4_7     normalized_ratio_4_34  -1
    w_4_7     full_original_Gini_296  -4.8690476190476195e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_8     OBJ       -1.9549429837111887e-02
    x_4_8     product_lb_16  -2.5358490566012373e-02
    x_4_8     product_ub_17  -4.3232115285684006e-02
    x_4_8     onehot_4_32  1
    x_4_8     stock_lb_236  8
    x_4_8     stock_ub_237  8
    x_4_8     parent_nonstrict_scope_238  6.5164766123706258e-03
    x_4_8     unique_nonzero_owner_304  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_8     product_lb_16  1
    w_4_8     product_ub_17  1
    w_4_8     normalized_mass_4_33  1
    w_4_8     normalized_ratio_4_34  -1.1428571428571428e+00
    w_4_8     full_original_Gini_296  -8.4404761904761880e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_9     OBJ       -1.3032953224741262e-02
    x_4_9     product_lb_18  -2.5358490566012373e-02
    x_4_9     product_ub_19  -4.3232115285684006e-02
    x_4_9     onehot_4_32  1
    x_4_9     stock_lb_236  9
    x_4_9     stock_ub_237  9
    x_4_9     parent_nonstrict_scope_238  1.3032953224741252e-02
    x_4_9     unique_nonzero_owner_305  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_9     product_lb_18  1
    w_4_9     product_ub_19  1
    w_4_9     normalized_mass_4_33  1
    w_4_9     normalized_ratio_4_34  -1.2857142857142856e+00
    w_4_9     full_original_Gini_296  -1.2011904761904759e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_10    OBJ       -6.5164766123706371e-03
    x_4_10    product_lb_20  -2.5358490566012373e-02
    x_4_10    product_ub_21  -4.3232115285684006e-02
    x_4_10    onehot_4_32  1
    x_4_10    stock_lb_236  10
    x_4_10    stock_ub_237  10
    x_4_10    parent_nonstrict_scope_238  1.9549429837111876e-02
    x_4_10    unique_nonzero_owner_306  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_10    product_lb_20  1
    w_4_10    product_ub_21  1
    w_4_10    normalized_mass_4_33  1
    w_4_10    normalized_ratio_4_34  -1.4285714285714284e+00
    w_4_10    full_original_Gini_296  -1.5583333333333334e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_11    product_lb_22  -2.5358490566012373e-02
    x_4_11    product_ub_23  -4.3232115285684006e-02
    x_4_11    onehot_4_32  1
    x_4_11    stock_lb_236  11
    x_4_11    stock_ub_237  11
    x_4_11    parent_nonstrict_scope_238  2.6065906449482514e-02
    x_4_11    unique_nonzero_owner_307  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_11    product_lb_22  1
    w_4_11    product_ub_23  1
    w_4_11    normalized_mass_4_33  1
    w_4_11    normalized_ratio_4_34  -1.5714285714285714e+00
    w_4_11    full_original_Gini_296  -1.9297619047619051e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_12    OBJ       6.5164766123706266e-03
    x_4_12    product_lb_24  -2.5358490566012373e-02
    x_4_12    product_ub_25  -4.3232115285684006e-02
    x_4_12    onehot_4_32  1
    x_4_12    stock_lb_236  12
    x_4_12    stock_ub_237  12
    x_4_12    parent_nonstrict_scope_238  3.2582383061853140e-02
    x_4_12    unique_nonzero_owner_308  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_12    product_lb_24  1
    w_4_12    product_ub_25  1
    w_4_12    normalized_mass_4_33  1
    w_4_12    normalized_ratio_4_34  -1.7142857142857142e+00
    w_4_12    full_original_Gini_296  -23.1547619047619
    MARKER    'MARKER'                 'INTORG'
    x_4_13    OBJ       1.3032953224741253e-02
    x_4_13    product_lb_26  -2.5358490566012373e-02
    x_4_13    product_ub_27  -4.3232115285684006e-02
    x_4_13    onehot_4_32  1
    x_4_13    stock_lb_236  13
    x_4_13    stock_ub_237  13
    x_4_13    parent_nonstrict_scope_238  3.9098859674223767e-02
    x_4_13    unique_nonzero_owner_309  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_13    product_lb_26  1
    w_4_13    product_ub_27  1
    w_4_13    normalized_mass_4_33  1
    w_4_13    normalized_ratio_4_34  -1.8571428571428570e+00
    w_4_13    full_original_Gini_296  -2.7011904761904763e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_14    OBJ       1.9549429837111887e-02
    x_4_14    product_lb_28  -2.5358490566012373e-02
    x_4_14    product_ub_29  -4.3232115285684006e-02
    x_4_14    onehot_4_32  1
    x_4_14    stock_lb_236  14
    x_4_14    stock_ub_237  14
    x_4_14    parent_nonstrict_scope_238  0.0456153362865944
    x_4_14    unique_nonzero_owner_310  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_14    product_lb_28  1
    w_4_14    product_ub_29  1
    w_4_14    normalized_mass_4_33  1
    w_4_14    normalized_ratio_4_34  -2
    w_4_14    full_original_Gini_296  -3.0869047619047620e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_15    OBJ       2.6065906449482514e-02
    x_4_15    product_lb_30  -2.5358490566012373e-02
    x_4_15    product_ub_31  -4.3232115285684006e-02
    x_4_15    onehot_4_32  1
    x_4_15    stock_lb_236  15
    x_4_15    stock_ub_237  15
    x_4_15    parent_nonstrict_scope_238  5.2131812898965027e-02
    x_4_15    unique_nonzero_owner_311  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_15    product_lb_30  1
    w_4_15    product_ub_31  1
    w_4_15    normalized_mass_4_33  1
    w_4_15    normalized_ratio_4_34  -2.1428571428571428e+00
    w_4_15    full_original_Gini_296  -3.4726190476190474e+01
    rho_4     normalized_ratio_4_34  1
    rho_4     block_pair_pos_247  -1
    rho_4     block_pair_neg_248  1
    rho_4     block_pair_pos_249  -1
    rho_4     block_pair_neg_250  1
    rho_4     block_pair_pos_251  -1
    rho_4     block_pair_neg_252  1
    rho_4     block_pair_pos_253  -1
    rho_4     block_pair_neg_254  1
    rho_4     block_pair_pos_255  -1
    rho_4     block_pair_neg_256  1
    rho_4     block_pair_pos_257  -1
    rho_4     block_pair_neg_258  1
    rho_4     block_pair_pos_259  -1
    rho_4     block_pair_neg_260  1
    rho_4     normalization_295  1
    MARKER    'MARKER'                 'INTORG'
    x_6_0     OBJ       7.4474103065332977e-03
    x_6_0     product_lb_35  -2.5358490566012373e-02
    x_6_0     product_ub_36  -4.3232115285684006e-02
    x_6_0     onehot_6_53  1
    x_6_0     parent_nonstrict_scope_238  1.4894820613066595e-02
    x_6_0     unique_nonzero_owner_312  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_0     product_lb_35  1
    w_6_0     product_ub_36  1
    w_6_0     normalized_mass_6_54  1
    w_6_0     full_original_Gini_296  -2.3130952380952380e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_1     OBJ       3.7237051532666493e-03
    x_6_1     product_lb_37  -2.5358490566012373e-02
    x_6_1     product_ub_38  -4.3232115285684006e-02
    x_6_1     onehot_6_53  1
    x_6_1     stock_lb_236  1
    x_6_1     stock_ub_237  1
    x_6_1     parent_nonstrict_scope_238  1.1171115459799947e-02
    x_6_1     unique_nonzero_owner_313  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_1     product_lb_37  1
    w_6_1     product_ub_38  1
    w_6_1     normalized_mass_6_54  1
    w_6_1     normalized_ratio_6_55  -0.25
    w_6_1     full_original_Gini_296  -1.6880952380952380e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_2     product_lb_39  -2.5358490566012373e-02
    x_6_2     product_ub_40  -4.3232115285684006e-02
    x_6_2     onehot_6_53  1
    x_6_2     stock_lb_236  2
    x_6_2     stock_ub_237  2
    x_6_2     parent_nonstrict_scope_238  7.4474103065332977e-03
    x_6_2     unique_nonzero_owner_314  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_2     product_lb_39  1
    w_6_2     product_ub_40  1
    w_6_2     normalized_mass_6_54  1
    w_6_2     normalized_ratio_6_55  -0.5
    w_6_2     full_original_Gini_296  -1.0830952380952379e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_3     OBJ       -3.7237051532666488e-03
    x_6_3     product_lb_41  -2.5358490566012373e-02
    x_6_3     product_ub_42  -4.3232115285684006e-02
    x_6_3     onehot_6_53  1
    x_6_3     stock_lb_236  3
    x_6_3     stock_ub_237  3
    x_6_3     parent_nonstrict_scope_238  3.7237051532666488e-03
    x_6_3     unique_nonzero_owner_315  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_3     product_lb_41  1
    w_6_3     product_ub_42  1
    w_6_3     normalized_mass_6_54  1
    w_6_3     normalized_ratio_6_55  -0.75
    w_6_3     full_original_Gini_296  -5.6642857142857128e+00
    MARKER    'MARKER'                 'INTORG'
    x_6_4     OBJ       -7.4474103065332977e-03
    x_6_4     product_lb_43  -2.5358490566012373e-02
    x_6_4     product_ub_44  -4.3232115285684006e-02
    x_6_4     onehot_6_53  1
    x_6_4     stock_lb_236  4
    x_6_4     stock_ub_237  4
    x_6_4     unique_nonzero_owner_316  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_4     product_lb_43  1
    w_6_4     product_ub_44  1
    w_6_4     normalized_mass_6_54  1
    w_6_4     normalized_ratio_6_55  -1
    w_6_4     full_original_Gini_296  -4.8690476190476195e+00
    MARKER    'MARKER'                 'INTORG'
    x_6_5     OBJ       -3.7237051532666488e-03
    x_6_5     product_lb_45  -2.5358490566012373e-02
    x_6_5     product_ub_46  -4.3232115285684006e-02
    x_6_5     onehot_6_53  1
    x_6_5     stock_lb_236  5
    x_6_5     stock_ub_237  5
    x_6_5     parent_nonstrict_scope_238  3.7237051532666488e-03
    x_6_5     unique_nonzero_owner_317  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_5     product_lb_45  1
    w_6_5     product_ub_46  1
    w_6_5     normalized_mass_6_54  1
    w_6_5     normalized_ratio_6_55  -1.25
    w_6_5     full_original_Gini_296  -1.1119047619047620e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_6     product_lb_47  -2.5358490566012373e-02
    x_6_6     product_ub_48  -4.3232115285684006e-02
    x_6_6     onehot_6_53  1
    x_6_6     stock_lb_236  6
    x_6_6     stock_ub_237  6
    x_6_6     parent_nonstrict_scope_238  7.4474103065332977e-03
    MARKER    'MARKER'                 'INTEND'
    w_6_6     product_lb_47  1
    w_6_6     product_ub_48  1
    w_6_6     normalized_mass_6_54  1
    w_6_6     normalized_ratio_6_55  -1.5
    w_6_6     full_original_Gini_296  -1.7369047619047620e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_7     OBJ       3.7237051532666493e-03
    x_6_7     product_lb_49  -2.5358490566012373e-02
    x_6_7     product_ub_50  -4.3232115285684006e-02
    x_6_7     onehot_6_53  1
    x_6_7     stock_lb_236  7
    x_6_7     stock_ub_237  7
    x_6_7     parent_nonstrict_scope_238  1.1171115459799947e-02
    x_6_7     unique_nonzero_owner_318  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_7     product_lb_49  1
    w_6_7     product_ub_50  1
    w_6_7     normalized_mass_6_54  1
    w_6_7     normalized_ratio_6_55  -1.75
    w_6_7     full_original_Gini_296  -2.4119047619047620e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_8     OBJ       7.4474103065332977e-03
    x_6_8     product_lb_51  -2.5358490566012373e-02
    x_6_8     product_ub_52  -4.3232115285684006e-02
    x_6_8     onehot_6_53  1
    x_6_8     stock_lb_236  8
    x_6_8     stock_ub_237  8
    x_6_8     parent_nonstrict_scope_238  1.4894820613066595e-02
    x_6_8     unique_nonzero_owner_319  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_8     product_lb_51  1
    w_6_8     product_ub_52  1
    w_6_8     normalized_mass_6_54  1
    w_6_8     normalized_ratio_6_55  -2
    w_6_8     full_original_Gini_296  -3.0869047619047620e+01
    rho_6     normalized_ratio_6_55  1
    rho_6     block_pair_pos_251  1
    rho_6     block_pair_neg_252  -1
    rho_6     block_pair_pos_265  -1
    rho_6     block_pair_neg_266  1
    rho_6     block_pair_pos_267  -1
    rho_6     block_pair_neg_268  1
    rho_6     block_pair_pos_269  -1
    rho_6     block_pair_neg_270  1
    rho_6     block_pair_pos_271  -1
    rho_6     block_pair_neg_272  1
    rho_6     block_pair_pos_273  -1
    rho_6     block_pair_neg_274  1
    rho_6     block_pair_pos_275  -1
    rho_6     block_pair_neg_276  1
    rho_6     normalization_295  1
    MARKER    'MARKER'                 'INTORG'
    x_34_0    OBJ       2.9789603523644435e-02
    x_34_0    product_lb_56  -2.5358490566012373e-02
    x_34_0    product_ub_57  -4.3232115285684006e-02
    x_34_0    onehot_34_88  1
    x_34_0    parent_nonstrict_scope_238  5.9579207047288869e-02
    x_34_0    unique_nonzero_owner_320  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_0    product_lb_56  1
    w_34_0    product_ub_57  1
    w_34_0    normalized_mass_34_89  1
    w_34_0    full_original_Gini_296  -2.3130952380952380e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_1    OBJ       2.2342202642733327e-02
    x_34_1    product_lb_58  -2.5358490566012373e-02
    x_34_1    product_ub_59  -4.3232115285684006e-02
    x_34_1    onehot_34_88  1
    x_34_1    stock_lb_236  1
    x_34_1    stock_ub_237  1
    x_34_1    parent_nonstrict_scope_238  5.2131806166377762e-02
    x_34_1    unique_nonzero_owner_321  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_1    product_lb_58  1
    w_34_1    product_ub_59  1
    w_34_1    normalized_mass_34_89  1
    w_34_1    normalized_ratio_34_90  -0.125
    w_34_1    full_original_Gini_296  -2.0005952380952380e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_2    OBJ       1.4894801761822219e-02
    x_34_2    product_lb_60  -2.5358490566012373e-02
    x_34_2    product_ub_61  -4.3232115285684006e-02
    x_34_2    onehot_34_88  1
    x_34_2    stock_lb_236  2
    x_34_2    stock_ub_237  2
    x_34_2    parent_nonstrict_scope_238  4.4684405285466654e-02
    MARKER    'MARKER'                 'INTEND'
    w_34_2    product_lb_60  1
    w_34_2    product_ub_61  1
    w_34_2    normalized_mass_34_89  1
    w_34_2    normalized_ratio_34_90  -0.25
    w_34_2    full_original_Gini_296  -1.6880952380952380e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_3    OBJ       7.4474008809111113e-03
    x_34_3    product_lb_62  -2.5358490566012373e-02
    x_34_3    product_ub_63  -4.3232115285684006e-02
    x_34_3    onehot_34_88  1
    x_34_3    stock_lb_236  3
    x_34_3    stock_ub_237  3
    x_34_3    parent_nonstrict_scope_238  3.7237004404555546e-02
    x_34_3    unique_nonzero_owner_322  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_3    product_lb_62  1
    w_34_3    product_ub_63  1
    w_34_3    normalized_mass_34_89  1
    w_34_3    normalized_ratio_34_90  -0.375
    w_34_3    full_original_Gini_296  -1.3755952380952380e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_4    product_lb_64  -2.5358490566012373e-02
    x_34_4    product_ub_65  -4.3232115285684006e-02
    x_34_4    onehot_34_88  1
    x_34_4    stock_lb_236  4
    x_34_4    stock_ub_237  4
    x_34_4    parent_nonstrict_scope_238  2.9789603523644435e-02
    x_34_4    unique_nonzero_owner_323  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_4    product_lb_64  1
    w_34_4    product_ub_65  1
    w_34_4    normalized_mass_34_89  1
    w_34_4    normalized_ratio_34_90  -0.5
    w_34_4    full_original_Gini_296  -1.0830952380952379e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_5    OBJ       -7.4474008809111078e-03
    x_34_5    product_lb_66  -2.5358490566012373e-02
    x_34_5    product_ub_67  -4.3232115285684006e-02
    x_34_5    onehot_34_88  1
    x_34_5    stock_lb_236  5
    x_34_5    stock_ub_237  5
    x_34_5    parent_nonstrict_scope_238  2.2342202642733327e-02
    x_34_5    unique_nonzero_owner_324  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_5    product_lb_66  1
    w_34_5    product_ub_67  1
    w_34_5    normalized_mass_34_89  1
    w_34_5    normalized_ratio_34_90  -0.625
    w_34_5    full_original_Gini_296  -7.9559523809523816e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_6    OBJ       -1.4894801761822217e-02
    x_34_6    product_lb_68  -2.5358490566012373e-02
    x_34_6    product_ub_69  -4.3232115285684006e-02
    x_34_6    onehot_34_88  1
    x_34_6    stock_lb_236  6
    x_34_6    stock_ub_237  6
    x_34_6    parent_nonstrict_scope_238  1.4894801761822217e-02
    x_34_6    unique_nonzero_owner_325  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_6    product_lb_68  1
    w_34_6    product_ub_69  1
    w_34_6    normalized_mass_34_89  1
    w_34_6    normalized_ratio_34_90  -0.75
    w_34_6    full_original_Gini_296  -5.6642857142857128e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_7    OBJ       -2.2342202642733327e-02
    x_34_7    product_lb_70  -2.5358490566012373e-02
    x_34_7    product_ub_71  -4.3232115285684006e-02
    x_34_7    onehot_34_88  1
    x_34_7    stock_lb_236  7
    x_34_7    stock_ub_237  7
    x_34_7    parent_nonstrict_scope_238  7.4474008809111087e-03
    x_34_7    unique_nonzero_owner_326  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_7    product_lb_70  1
    w_34_7    product_ub_71  1
    w_34_7    normalized_mass_34_89  1
    w_34_7    normalized_ratio_34_90  -0.875
    w_34_7    full_original_Gini_296  -4.7440476190476195e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_8    OBJ       -2.9789603523644435e-02
    x_34_8    product_lb_72  -2.5358490566012373e-02
    x_34_8    product_ub_73  -4.3232115285684006e-02
    x_34_8    onehot_34_88  1
    x_34_8    stock_lb_236  8
    x_34_8    stock_ub_237  8
    x_34_8    unique_nonzero_owner_327  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_8    product_lb_72  1
    w_34_8    product_ub_73  1
    w_34_8    normalized_mass_34_89  1
    w_34_8    normalized_ratio_34_90  -1
    w_34_8    full_original_Gini_296  -4.8690476190476195e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_9    OBJ       -2.2342202642733327e-02
    x_34_9    product_lb_74  -2.5358490566012373e-02
    x_34_9    product_ub_75  -4.3232115285684006e-02
    x_34_9    onehot_34_88  1
    x_34_9    stock_lb_236  9
    x_34_9    stock_ub_237  9
    x_34_9    parent_nonstrict_scope_238  7.4474008809111087e-03
    x_34_9    unique_nonzero_owner_328  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_9    product_lb_74  1
    w_34_9    product_ub_75  1
    w_34_9    normalized_mass_34_89  1
    w_34_9    normalized_ratio_34_90  -1.125
    w_34_9    full_original_Gini_296  -7.9940476190476186e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_10   OBJ       -1.4894801761822217e-02
    x_34_10   product_lb_76  -2.5358490566012373e-02
    x_34_10   product_ub_77  -4.3232115285684006e-02
    x_34_10   onehot_34_88  1
    x_34_10   stock_lb_236  10
    x_34_10   stock_ub_237  10
    x_34_10   parent_nonstrict_scope_238  1.4894801761822217e-02
    x_34_10   unique_nonzero_owner_329  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_10   product_lb_76  1
    w_34_10   product_ub_77  1
    w_34_10   normalized_mass_34_89  1
    w_34_10   normalized_ratio_34_90  -1.25
    w_34_10   full_original_Gini_296  -1.1119047619047620e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_11   OBJ       -7.4474008809111078e-03
    x_34_11   product_lb_78  -2.5358490566012373e-02
    x_34_11   product_ub_79  -4.3232115285684006e-02
    x_34_11   onehot_34_88  1
    x_34_11   stock_lb_236  11
    x_34_11   stock_ub_237  11
    x_34_11   parent_nonstrict_scope_238  2.2342202642733327e-02
    x_34_11   unique_nonzero_owner_330  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_11   product_lb_78  1
    w_34_11   product_ub_79  1
    w_34_11   normalized_mass_34_89  1
    w_34_11   normalized_ratio_34_90  -1.375
    w_34_11   full_original_Gini_296  -1.4244047619047620e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_12   product_lb_80  -2.5358490566012373e-02
    x_34_12   product_ub_81  -4.3232115285684006e-02
    x_34_12   onehot_34_88  1
    x_34_12   stock_lb_236  12
    x_34_12   stock_ub_237  12
    x_34_12   parent_nonstrict_scope_238  2.9789603523644435e-02
    x_34_12   unique_nonzero_owner_331  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_12   product_lb_80  1
    w_34_12   product_ub_81  1
    w_34_12   normalized_mass_34_89  1
    w_34_12   normalized_ratio_34_90  -1.5
    w_34_12   full_original_Gini_296  -1.7369047619047620e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_13   OBJ       7.4474008809111113e-03
    x_34_13   product_lb_82  -2.5358490566012373e-02
    x_34_13   product_ub_83  -4.3232115285684006e-02
    x_34_13   onehot_34_88  1
    x_34_13   stock_lb_236  13
    x_34_13   stock_ub_237  13
    x_34_13   parent_nonstrict_scope_238  3.7237004404555546e-02
    x_34_13   unique_nonzero_owner_332  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_13   product_lb_82  1
    w_34_13   product_ub_83  1
    w_34_13   normalized_mass_34_89  1
    w_34_13   normalized_ratio_34_90  -1.625
    w_34_13   full_original_Gini_296  -2.0744047619047620e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_14   OBJ       1.4894801761822219e-02
    x_34_14   product_lb_84  -2.5358490566012373e-02
    x_34_14   product_ub_85  -4.3232115285684006e-02
    x_34_14   onehot_34_88  1
    x_34_14   stock_lb_236  14
    x_34_14   stock_ub_237  14
    x_34_14   parent_nonstrict_scope_238  4.4684405285466654e-02
    x_34_14   unique_nonzero_owner_333  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_14   product_lb_84  1
    w_34_14   product_ub_85  1
    w_34_14   normalized_mass_34_89  1
    w_34_14   normalized_ratio_34_90  -1.75
    w_34_14   full_original_Gini_296  -2.4119047619047620e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_15   OBJ       2.2342202642733327e-02
    x_34_15   product_lb_86  -2.5358490566012373e-02
    x_34_15   product_ub_87  -4.3232115285684006e-02
    x_34_15   onehot_34_88  1
    x_34_15   stock_lb_236  15
    x_34_15   stock_ub_237  15
    x_34_15   parent_nonstrict_scope_238  5.2131806166377762e-02
    x_34_15   unique_nonzero_owner_334  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_15   product_lb_86  1
    w_34_15   product_ub_87  1
    w_34_15   normalized_mass_34_89  1
    w_34_15   normalized_ratio_34_90  -1.875
    w_34_15   full_original_Gini_296  -2.7494047619047620e+01
    rho_34    normalized_ratio_34_90  1
    rho_34    block_pair_pos_259  1
    rho_34    block_pair_neg_260  -1
    rho_34    block_pair_pos_275  1
    rho_34    block_pair_neg_276  -1
    rho_34    block_pair_pos_285  -1
    rho_34    block_pair_neg_286  1
    rho_34    block_pair_pos_287  -1
    rho_34    block_pair_neg_288  1
    rho_34    block_pair_pos_289  -1
    rho_34    block_pair_neg_290  1
    rho_34    block_pair_pos_291  -1
    rho_34    block_pair_neg_292  1
    rho_34    block_pair_pos_293  -1
    rho_34    block_pair_neg_294  1
    rho_34    normalization_295  1
    MARKER    'MARKER'                 'INTORG'
    x_3_0     OBJ       1.6756644912833352e-02
    x_3_0     product_lb_91  -2.5358490566012373e-02
    x_3_0     product_ub_92  -4.3232115285684006e-02
    x_3_0     onehot_3_117  1
    x_3_0     parent_nonstrict_scope_238  0.0335132898256667
    x_3_0     unique_nonzero_owner_335  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_0     product_lb_91  1
    w_3_0     product_ub_92  1
    w_3_0     normalized_mass_3_118  1
    w_3_0     full_original_Gini_296  -2.3130952380952380e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_1     OBJ       1.1171096608555569e-02
    x_3_1     product_lb_93  -2.5358490566012373e-02
    x_3_1     product_ub_94  -4.3232115285684006e-02
    x_3_1     onehot_3_117  1
    x_3_1     stock_lb_236  1
    x_3_1     stock_ub_237  1
    x_3_1     parent_nonstrict_scope_238  2.7927741521388921e-02
    x_3_1     unique_nonzero_owner_336  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_1     product_lb_93  1
    w_3_1     product_ub_94  1
    w_3_1     normalized_mass_3_118  1
    w_3_1     normalized_ratio_3_119  -1.6666666666666666e-01
    w_3_1     full_original_Gini_296  -1.8964285714285715e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_2     OBJ       5.5855483042777862e-03
    x_3_2     product_lb_95  -2.5358490566012373e-02
    x_3_2     product_ub_96  -4.3232115285684006e-02
    x_3_2     onehot_3_117  1
    x_3_2     stock_lb_236  2
    x_3_2     stock_ub_237  2
    x_3_2     parent_nonstrict_scope_238  2.2342193217111138e-02
    x_3_2     unique_nonzero_owner_337  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_2     product_lb_95  1
    w_3_2     product_ub_96  1
    w_3_2     normalized_mass_3_118  1
    w_3_2     normalized_ratio_3_119  -3.3333333333333331e-01
    w_3_2     full_original_Gini_296  -1.4797619047619046e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_3     product_lb_97  -2.5358490566012373e-02
    x_3_3     product_ub_98  -4.3232115285684006e-02
    x_3_3     onehot_3_117  1
    x_3_3     stock_lb_236  3
    x_3_3     stock_ub_237  3
    x_3_3     parent_nonstrict_scope_238  1.6756644912833352e-02
    x_3_3     unique_nonzero_owner_338  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_3     product_lb_97  1
    w_3_3     product_ub_98  1
    w_3_3     normalized_mass_3_118  1
    w_3_3     normalized_ratio_3_119  -0.5
    w_3_3     full_original_Gini_296  -1.0830952380952379e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_4     OBJ       -5.5855483042777827e-03
    x_3_4     product_lb_99  -2.5358490566012373e-02
    x_3_4     product_ub_100  -4.3232115285684006e-02
    x_3_4     onehot_3_117  1
    x_3_4     stock_lb_236  4
    x_3_4     stock_ub_237  4
    x_3_4     parent_nonstrict_scope_238  1.1171096608555569e-02
    x_3_4     unique_nonzero_owner_339  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_4     product_lb_99  1
    w_3_4     product_ub_100  1
    w_3_4     normalized_mass_3_118  1
    w_3_4     normalized_ratio_3_119  -6.6666666666666663e-01
    w_3_4     full_original_Gini_296  -7.0809523809523807e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_5     OBJ       -1.1171096608555565e-02
    x_3_5     product_lb_101  -2.5358490566012373e-02
    x_3_5     product_ub_102  -4.3232115285684006e-02
    x_3_5     onehot_3_117  1
    x_3_5     stock_lb_236  5
    x_3_5     stock_ub_237  5
    x_3_5     parent_nonstrict_scope_238  5.5855483042777862e-03
    x_3_5     unique_nonzero_owner_340  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_5     product_lb_101  1
    w_3_5     product_ub_102  1
    w_3_5     normalized_mass_3_118  1
    w_3_5     normalized_ratio_3_119  -8.3333333333333326e-01
    w_3_5     full_original_Gini_296  -4.8809523809523814e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_6     OBJ       -1.6756644912833352e-02
    x_3_6     product_lb_103  -2.5358490566012373e-02
    x_3_6     product_ub_104  -4.3232115285684006e-02
    x_3_6     onehot_3_117  1
    x_3_6     stock_lb_236  6
    x_3_6     stock_ub_237  6
    x_3_6     unique_nonzero_owner_341  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_6     product_lb_103  1
    w_3_6     product_ub_104  1
    w_3_6     normalized_mass_3_118  1
    w_3_6     normalized_ratio_3_119  -1
    w_3_6     full_original_Gini_296  -4.8690476190476195e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_7     OBJ       -1.1171096608555572e-02
    x_3_7     product_lb_105  -2.5358490566012373e-02
    x_3_7     product_ub_106  -4.3232115285684006e-02
    x_3_7     onehot_3_117  1
    x_3_7     stock_lb_236  7
    x_3_7     stock_ub_237  7
    x_3_7     parent_nonstrict_scope_238  5.5855483042777793e-03
    x_3_7     unique_nonzero_owner_342  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_7     product_lb_105  1
    w_3_7     product_ub_106  1
    w_3_7     normalized_mass_3_118  1
    w_3_7     normalized_ratio_3_119  -1.1666666666666665e+00
    w_3_7     full_original_Gini_296  -9.03571428571428
    MARKER    'MARKER'                 'INTORG'
    x_3_8     OBJ       -5.5855483042777862e-03
    x_3_8     product_lb_107  -2.5358490566012373e-02
    x_3_8     product_ub_108  -4.3232115285684006e-02
    x_3_8     onehot_3_117  1
    x_3_8     stock_lb_236  8
    x_3_8     stock_ub_237  8
    x_3_8     parent_nonstrict_scope_238  1.1171096608555565e-02
    x_3_8     unique_nonzero_owner_343  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_8     product_lb_107  1
    w_3_8     product_ub_108  1
    w_3_8     normalized_mass_3_118  1
    w_3_8     normalized_ratio_3_119  -1.3333333333333333e+00
    w_3_8     full_original_Gini_296  -1.3202380952380951e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_9     product_lb_109  -2.5358490566012373e-02
    x_3_9     product_ub_110  -4.3232115285684006e-02
    x_3_9     onehot_3_117  1
    x_3_9     stock_lb_236  9
    x_3_9     stock_ub_237  9
    x_3_9     parent_nonstrict_scope_238  1.6756644912833352e-02
    MARKER    'MARKER'                 'INTEND'
    w_3_9     product_lb_109  1
    w_3_9     product_ub_110  1
    w_3_9     normalized_mass_3_118  1
    w_3_9     normalized_ratio_3_119  -1.5
    w_3_9     full_original_Gini_296  -1.7369047619047620e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_10    OBJ       5.5855483042777793e-03
    x_3_10    product_lb_111  -2.5358490566012373e-02
    x_3_10    product_ub_112  -4.3232115285684006e-02
    x_3_10    onehot_3_117  1
    x_3_10    stock_lb_236  10
    x_3_10    stock_ub_237  10
    x_3_10    parent_nonstrict_scope_238  2.2342193217111131e-02
    x_3_10    unique_nonzero_owner_344  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_10    product_lb_111  1
    w_3_10    product_ub_112  1
    w_3_10    normalized_mass_3_118  1
    w_3_10    normalized_ratio_3_119  -1.6666666666666665e+00
    w_3_10    full_original_Gini_296  -2.1869047619047613e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_11    OBJ       1.1171096608555565e-02
    x_3_11    product_lb_113  -2.5358490566012373e-02
    x_3_11    product_ub_114  -4.3232115285684006e-02
    x_3_11    onehot_3_117  1
    x_3_11    stock_lb_236  11
    x_3_11    stock_ub_237  11
    x_3_11    parent_nonstrict_scope_238  2.7927741521388917e-02
    x_3_11    unique_nonzero_owner_345  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_11    product_lb_113  1
    w_3_11    product_ub_114  1
    w_3_11    normalized_mass_3_118  1
    w_3_11    normalized_ratio_3_119  -1.8333333333333333e+00
    w_3_11    full_original_Gini_296  -2.6369047619047620e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_12    OBJ       1.6756644912833352e-02
    x_3_12    product_lb_115  -2.5358490566012373e-02
    x_3_12    product_ub_116  -4.3232115285684006e-02
    x_3_12    onehot_3_117  1
    x_3_12    stock_lb_236  12
    x_3_12    stock_ub_237  12
    x_3_12    parent_nonstrict_scope_238  0.0335132898256667
    x_3_12    unique_nonzero_owner_346  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_12    product_lb_115  1
    w_3_12    product_ub_116  1
    w_3_12    normalized_mass_3_118  1
    w_3_12    normalized_ratio_3_119  -2
    w_3_12    full_original_Gini_296  -3.0869047619047620e+01
    rho_3     normalized_ratio_3_119  1
    rho_3     block_pair_pos_239  -1
    rho_3     block_pair_neg_240  1
    rho_3     block_pair_pos_241  -1
    rho_3     block_pair_neg_242  1
    rho_3     block_pair_pos_243  -1
    rho_3     block_pair_neg_244  1
    rho_3     block_pair_pos_245  -1
    rho_3     block_pair_neg_246  1
    rho_3     block_pair_pos_247  1
    rho_3     block_pair_neg_248  -1
    rho_3     block_pair_pos_265  1
    rho_3     block_pair_neg_266  -1
    rho_3     block_pair_pos_285  1
    rho_3     block_pair_neg_286  -1
    rho_3     normalization_295  1
    MARKER    'MARKER'                 'INTORG'
    x_22_0    OBJ       1.9549429837111887e-02
    x_22_0    product_lb_120  -2.5358490566012373e-02
    x_22_0    product_ub_121  -4.3232115285684006e-02
    x_22_0    onehot_22_152  1
    x_22_0    parent_nonstrict_scope_238  0.0456153362865944
    x_22_0    unique_nonzero_owner_347  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_0    product_lb_120  1
    w_22_0    product_ub_121  1
    w_22_0    normalized_mass_22_153  1
    w_22_0    full_original_Gini_296  -2.3130952380952380e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_1    OBJ       1.3032953224741260e-02
    x_22_1    product_lb_122  -2.5358490566012373e-02
    x_22_1    product_ub_123  -4.3232115285684006e-02
    x_22_1    onehot_22_152  1
    x_22_1    stock_lb_236  1
    x_22_1    stock_ub_237  1
    x_22_1    parent_nonstrict_scope_238  3.9098859674223774e-02
    x_22_1    unique_nonzero_owner_348  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_1    product_lb_122  1
    w_22_1    product_ub_123  1
    w_22_1    normalized_mass_22_153  1
    w_22_1    normalized_ratio_22_154  -1.4285714285714285e-01
    w_22_1    full_original_Gini_296  -1.9559523809523817e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_2    OBJ       6.5164766123706336e-03
    x_22_2    product_lb_124  -2.5358490566012373e-02
    x_22_2    product_ub_125  -4.3232115285684006e-02
    x_22_2    onehot_22_152  1
    x_22_2    stock_lb_236  2
    x_22_2    stock_ub_237  2
    x_22_2    parent_nonstrict_scope_238  3.2582383061853147e-02
    MARKER    'MARKER'                 'INTEND'
    w_22_2    product_lb_124  1
    w_22_2    product_ub_125  1
    w_22_2    normalized_mass_22_153  1
    w_22_2    normalized_ratio_22_154  -2.8571428571428570e-01
    w_22_2    full_original_Gini_296  -1.5988095238095232e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_3    product_lb_126  -2.5358490566012373e-02
    x_22_3    product_ub_127  -4.3232115285684006e-02
    x_22_3    onehot_22_152  1
    x_22_3    stock_lb_236  3
    x_22_3    stock_ub_237  3
    x_22_3    parent_nonstrict_scope_238  2.6065906449482514e-02
    x_22_3    unique_nonzero_owner_349  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_3    product_lb_126  1
    w_22_3    product_ub_127  1
    w_22_3    normalized_mass_22_153  1
    w_22_3    normalized_ratio_22_154  -4.2857142857142855e-01
    w_22_3    full_original_Gini_296  -1.2473809523809519e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_4    OBJ       -6.5164766123706266e-03
    x_22_4    product_lb_128  -2.5358490566012373e-02
    x_22_4    product_ub_129  -4.3232115285684006e-02
    x_22_4    onehot_22_152  1
    x_22_4    stock_lb_236  4
    x_22_4    stock_ub_237  4
    x_22_4    parent_nonstrict_scope_238  1.9549429837111887e-02
    x_22_4    unique_nonzero_owner_350  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_4    product_lb_128  1
    w_22_4    product_ub_129  1
    w_22_4    normalized_mass_22_153  1
    w_22_4    normalized_ratio_22_154  -5.7142857142857140e-01
    w_22_4    full_original_Gini_296  -9.1880952380952419e+00
    MARKER    'MARKER'                 'INTORG'
    x_22_5    OBJ       -1.3032953224741252e-02
    x_22_5    product_lb_130  -2.5358490566012373e-02
    x_22_5    product_ub_131  -4.3232115285684006e-02
    x_22_5    onehot_22_152  1
    x_22_5    stock_lb_236  5
    x_22_5    stock_ub_237  5
    x_22_5    parent_nonstrict_scope_238  1.3032953224741262e-02
    x_22_5    unique_nonzero_owner_351  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_5    product_lb_130  1
    w_22_5    product_ub_131  1
    w_22_5    normalized_mass_22_153  1
    w_22_5    normalized_ratio_22_154  -7.1428571428571419e-01
    w_22_5    full_original_Gini_296  -6.2714285714285705e+00
    MARKER    'MARKER'                 'INTORG'
    x_22_6    OBJ       -1.9549429837111883e-02
    x_22_6    product_lb_132  -2.5358490566012373e-02
    x_22_6    product_ub_133  -4.3232115285684006e-02
    x_22_6    onehot_22_152  1
    x_22_6    stock_lb_236  6
    x_22_6    stock_ub_237  6
    x_22_6    parent_nonstrict_scope_238  6.5164766123706310e-03
    x_22_6    unique_nonzero_owner_352  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_6    product_lb_132  1
    w_22_6    product_ub_133  1
    w_22_6    normalized_mass_22_153  1
    w_22_6    normalized_ratio_22_154  -8.5714285714285710e-01
    w_22_6    full_original_Gini_296  -4.7619047619047619e+00
    MARKER    'MARKER'                 'INTORG'
    x_22_7    OBJ       -2.6065906449482514e-02
    x_22_7    product_lb_134  -2.5358490566012373e-02
    x_22_7    product_ub_135  -4.3232115285684006e-02
    x_22_7    onehot_22_152  1
    x_22_7    stock_lb_236  7
    x_22_7    stock_ub_237  7
    x_22_7    unique_nonzero_owner_353  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_7    product_lb_134  1
    w_22_7    product_ub_135  1
    w_22_7    normalized_mass_22_153  1
    w_22_7    normalized_ratio_22_154  -1
    w_22_7    full_original_Gini_296  -4.8690476190476195e+00
    MARKER    'MARKER'                 'INTORG'
    x_22_8    OBJ       -1.9549429837111887e-02
    x_22_8    product_lb_136  -2.5358490566012373e-02
    x_22_8    product_ub_137  -4.3232115285684006e-02
    x_22_8    onehot_22_152  1
    x_22_8    stock_lb_236  8
    x_22_8    stock_ub_237  8
    x_22_8    parent_nonstrict_scope_238  6.5164766123706258e-03
    x_22_8    unique_nonzero_owner_354  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_8    product_lb_136  1
    w_22_8    product_ub_137  1
    w_22_8    normalized_mass_22_153  1
    w_22_8    normalized_ratio_22_154  -1.1428571428571428e+00
    w_22_8    full_original_Gini_296  -8.4404761904761880e+00
    MARKER    'MARKER'                 'INTORG'
    x_22_9    OBJ       -1.3032953224741262e-02
    x_22_9    product_lb_138  -2.5358490566012373e-02
    x_22_9    product_ub_139  -4.3232115285684006e-02
    x_22_9    onehot_22_152  1
    x_22_9    stock_lb_236  9
    x_22_9    stock_ub_237  9
    x_22_9    parent_nonstrict_scope_238  1.3032953224741252e-02
    x_22_9    unique_nonzero_owner_355  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_9    product_lb_138  1
    w_22_9    product_ub_139  1
    w_22_9    normalized_mass_22_153  1
    w_22_9    normalized_ratio_22_154  -1.2857142857142856e+00
    w_22_9    full_original_Gini_296  -1.2011904761904759e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_10   OBJ       -6.5164766123706371e-03
    x_22_10   product_lb_140  -2.5358490566012373e-02
    x_22_10   product_ub_141  -4.3232115285684006e-02
    x_22_10   onehot_22_152  1
    x_22_10   stock_lb_236  10
    x_22_10   stock_ub_237  10
    x_22_10   parent_nonstrict_scope_238  1.9549429837111876e-02
    x_22_10   unique_nonzero_owner_356  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_10   product_lb_140  1
    w_22_10   product_ub_141  1
    w_22_10   normalized_mass_22_153  1
    w_22_10   normalized_ratio_22_154  -1.4285714285714284e+00
    w_22_10   full_original_Gini_296  -1.5583333333333334e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_11   product_lb_142  -2.5358490566012373e-02
    x_22_11   product_ub_143  -4.3232115285684006e-02
    x_22_11   onehot_22_152  1
    x_22_11   stock_lb_236  11
    x_22_11   stock_ub_237  11
    x_22_11   parent_nonstrict_scope_238  2.6065906449482514e-02
    x_22_11   unique_nonzero_owner_357  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_11   product_lb_142  1
    w_22_11   product_ub_143  1
    w_22_11   normalized_mass_22_153  1
    w_22_11   normalized_ratio_22_154  -1.5714285714285714e+00
    w_22_11   full_original_Gini_296  -1.9297619047619051e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_12   OBJ       6.5164766123706266e-03
    x_22_12   product_lb_144  -2.5358490566012373e-02
    x_22_12   product_ub_145  -4.3232115285684006e-02
    x_22_12   onehot_22_152  1
    x_22_12   stock_lb_236  12
    x_22_12   stock_ub_237  12
    x_22_12   parent_nonstrict_scope_238  3.2582383061853140e-02
    x_22_12   unique_nonzero_owner_358  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_12   product_lb_144  1
    w_22_12   product_ub_145  1
    w_22_12   normalized_mass_22_153  1
    w_22_12   normalized_ratio_22_154  -1.7142857142857142e+00
    w_22_12   full_original_Gini_296  -23.1547619047619
    MARKER    'MARKER'                 'INTORG'
    x_22_13   OBJ       1.3032953224741253e-02
    x_22_13   product_lb_146  -2.5358490566012373e-02
    x_22_13   product_ub_147  -4.3232115285684006e-02
    x_22_13   onehot_22_152  1
    x_22_13   stock_lb_236  13
    x_22_13   stock_ub_237  13
    x_22_13   parent_nonstrict_scope_238  3.9098859674223767e-02
    x_22_13   unique_nonzero_owner_359  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_13   product_lb_146  1
    w_22_13   product_ub_147  1
    w_22_13   normalized_mass_22_153  1
    w_22_13   normalized_ratio_22_154  -1.8571428571428570e+00
    w_22_13   full_original_Gini_296  -2.7011904761904763e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_14   OBJ       1.9549429837111887e-02
    x_22_14   product_lb_148  -2.5358490566012373e-02
    x_22_14   product_ub_149  -4.3232115285684006e-02
    x_22_14   onehot_22_152  1
    x_22_14   stock_lb_236  14
    x_22_14   stock_ub_237  14
    x_22_14   parent_nonstrict_scope_238  0.0456153362865944
    x_22_14   unique_nonzero_owner_360  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_14   product_lb_148  1
    w_22_14   product_ub_149  1
    w_22_14   normalized_mass_22_153  1
    w_22_14   normalized_ratio_22_154  -2
    w_22_14   full_original_Gini_296  -3.0869047619047620e+01
    MARKER    'MARKER'                 'INTORG'
    x_22_15   OBJ       2.6065906449482514e-02
    x_22_15   product_lb_150  -2.5358490566012373e-02
    x_22_15   product_ub_151  -4.3232115285684006e-02
    x_22_15   onehot_22_152  1
    x_22_15   stock_lb_236  15
    x_22_15   stock_ub_237  15
    x_22_15   parent_nonstrict_scope_238  5.2131812898965027e-02
    x_22_15   unique_nonzero_owner_361  -1
    MARKER    'MARKER'                 'INTEND'
    w_22_15   product_lb_150  1
    w_22_15   product_ub_151  1
    w_22_15   normalized_mass_22_153  1
    w_22_15   normalized_ratio_22_154  -2.1428571428571428e+00
    w_22_15   full_original_Gini_296  -3.4726190476190474e+01
    rho_22    normalized_ratio_22_154  1
    rho_22    block_pair_pos_243  1
    rho_22    block_pair_neg_244  -1
    rho_22    block_pair_pos_255  1
    rho_22    block_pair_neg_256  -1
    rho_22    block_pair_pos_271  1
    rho_22    block_pair_neg_272  -1
    rho_22    block_pair_pos_277  -1
    rho_22    block_pair_neg_278  1
    rho_22    block_pair_pos_279  -1
    rho_22    block_pair_neg_280  1
    rho_22    block_pair_pos_281  -1
    rho_22    block_pair_neg_282  1
    rho_22    block_pair_pos_291  1
    rho_22    block_pair_neg_292  -1
    rho_22    normalization_295  1
    MARKER    'MARKER'                 'INTORG'
    x_5_0     OBJ       1.9549429837111887e-02
    x_5_0     product_lb_155  -2.5358490566012373e-02
    x_5_0     product_ub_156  -4.3232115285684006e-02
    x_5_0     onehot_5_187  1
    x_5_0     parent_nonstrict_scope_238  0.0456153362865944
    x_5_0     unique_nonzero_owner_362  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_0     product_lb_155  1
    w_5_0     product_ub_156  1
    w_5_0     normalized_mass_5_188  1
    w_5_0     full_original_Gini_296  -2.3130952380952380e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_1     OBJ       1.3032953224741260e-02
    x_5_1     product_lb_157  -2.5358490566012373e-02
    x_5_1     product_ub_158  -4.3232115285684006e-02
    x_5_1     onehot_5_187  1
    x_5_1     stock_lb_236  1
    x_5_1     stock_ub_237  1
    x_5_1     parent_nonstrict_scope_238  3.9098859674223774e-02
    MARKER    'MARKER'                 'INTEND'
    w_5_1     product_lb_157  1
    w_5_1     product_ub_158  1
    w_5_1     normalized_mass_5_188  1
    w_5_1     normalized_ratio_5_189  -1.4285714285714285e-01
    w_5_1     full_original_Gini_296  -1.9559523809523817e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_2     OBJ       6.5164766123706336e-03
    x_5_2     product_lb_159  -2.5358490566012373e-02
    x_5_2     product_ub_160  -4.3232115285684006e-02
    x_5_2     onehot_5_187  1
    x_5_2     stock_lb_236  2
    x_5_2     stock_ub_237  2
    x_5_2     parent_nonstrict_scope_238  3.2582383061853147e-02
    x_5_2     unique_nonzero_owner_363  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_2     product_lb_159  1
    w_5_2     product_ub_160  1
    w_5_2     normalized_mass_5_188  1
    w_5_2     normalized_ratio_5_189  -2.8571428571428570e-01
    w_5_2     full_original_Gini_296  -1.5988095238095232e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_3     product_lb_161  -2.5358490566012373e-02
    x_5_3     product_ub_162  -4.3232115285684006e-02
    x_5_3     onehot_5_187  1
    x_5_3     stock_lb_236  3
    x_5_3     stock_ub_237  3
    x_5_3     parent_nonstrict_scope_238  2.6065906449482514e-02
    x_5_3     unique_nonzero_owner_364  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_3     product_lb_161  1
    w_5_3     product_ub_162  1
    w_5_3     normalized_mass_5_188  1
    w_5_3     normalized_ratio_5_189  -4.2857142857142855e-01
    w_5_3     full_original_Gini_296  -1.2473809523809519e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_4     OBJ       -6.5164766123706266e-03
    x_5_4     product_lb_163  -2.5358490566012373e-02
    x_5_4     product_ub_164  -4.3232115285684006e-02
    x_5_4     onehot_5_187  1
    x_5_4     stock_lb_236  4
    x_5_4     stock_ub_237  4
    x_5_4     parent_nonstrict_scope_238  1.9549429837111887e-02
    x_5_4     unique_nonzero_owner_365  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_4     product_lb_163  1
    w_5_4     product_ub_164  1
    w_5_4     normalized_mass_5_188  1
    w_5_4     normalized_ratio_5_189  -5.7142857142857140e-01
    w_5_4     full_original_Gini_296  -9.1880952380952419e+00
    MARKER    'MARKER'                 'INTORG'
    x_5_5     OBJ       -1.3032953224741252e-02
    x_5_5     product_lb_165  -2.5358490566012373e-02
    x_5_5     product_ub_166  -4.3232115285684006e-02
    x_5_5     onehot_5_187  1
    x_5_5     stock_lb_236  5
    x_5_5     stock_ub_237  5
    x_5_5     parent_nonstrict_scope_238  1.3032953224741262e-02
    x_5_5     unique_nonzero_owner_366  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_5     product_lb_165  1
    w_5_5     product_ub_166  1
    w_5_5     normalized_mass_5_188  1
    w_5_5     normalized_ratio_5_189  -7.1428571428571419e-01
    w_5_5     full_original_Gini_296  -6.2714285714285705e+00
    MARKER    'MARKER'                 'INTORG'
    x_5_6     OBJ       -1.9549429837111883e-02
    x_5_6     product_lb_167  -2.5358490566012373e-02
    x_5_6     product_ub_168  -4.3232115285684006e-02
    x_5_6     onehot_5_187  1
    x_5_6     stock_lb_236  6
    x_5_6     stock_ub_237  6
    x_5_6     parent_nonstrict_scope_238  6.5164766123706310e-03
    x_5_6     unique_nonzero_owner_367  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_6     product_lb_167  1
    w_5_6     product_ub_168  1
    w_5_6     normalized_mass_5_188  1
    w_5_6     normalized_ratio_5_189  -8.5714285714285710e-01
    w_5_6     full_original_Gini_296  -4.7619047619047619e+00
    MARKER    'MARKER'                 'INTORG'
    x_5_7     OBJ       -2.6065906449482514e-02
    x_5_7     product_lb_169  -2.5358490566012373e-02
    x_5_7     product_ub_170  -4.3232115285684006e-02
    x_5_7     onehot_5_187  1
    x_5_7     stock_lb_236  7
    x_5_7     stock_ub_237  7
    x_5_7     unique_nonzero_owner_368  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_7     product_lb_169  1
    w_5_7     product_ub_170  1
    w_5_7     normalized_mass_5_188  1
    w_5_7     normalized_ratio_5_189  -1
    w_5_7     full_original_Gini_296  -4.8690476190476195e+00
    MARKER    'MARKER'                 'INTORG'
    x_5_8     OBJ       -1.9549429837111887e-02
    x_5_8     product_lb_171  -2.5358490566012373e-02
    x_5_8     product_ub_172  -4.3232115285684006e-02
    x_5_8     onehot_5_187  1
    x_5_8     stock_lb_236  8
    x_5_8     stock_ub_237  8
    x_5_8     parent_nonstrict_scope_238  6.5164766123706258e-03
    x_5_8     unique_nonzero_owner_369  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_8     product_lb_171  1
    w_5_8     product_ub_172  1
    w_5_8     normalized_mass_5_188  1
    w_5_8     normalized_ratio_5_189  -1.1428571428571428e+00
    w_5_8     full_original_Gini_296  -8.4404761904761880e+00
    MARKER    'MARKER'                 'INTORG'
    x_5_9     OBJ       -1.3032953224741262e-02
    x_5_9     product_lb_173  -2.5358490566012373e-02
    x_5_9     product_ub_174  -4.3232115285684006e-02
    x_5_9     onehot_5_187  1
    x_5_9     stock_lb_236  9
    x_5_9     stock_ub_237  9
    x_5_9     parent_nonstrict_scope_238  1.3032953224741252e-02
    x_5_9     unique_nonzero_owner_370  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_9     product_lb_173  1
    w_5_9     product_ub_174  1
    w_5_9     normalized_mass_5_188  1
    w_5_9     normalized_ratio_5_189  -1.2857142857142856e+00
    w_5_9     full_original_Gini_296  -1.2011904761904759e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_10    OBJ       -6.5164766123706371e-03
    x_5_10    product_lb_175  -2.5358490566012373e-02
    x_5_10    product_ub_176  -4.3232115285684006e-02
    x_5_10    onehot_5_187  1
    x_5_10    stock_lb_236  10
    x_5_10    stock_ub_237  10
    x_5_10    parent_nonstrict_scope_238  1.9549429837111876e-02
    x_5_10    unique_nonzero_owner_371  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_10    product_lb_175  1
    w_5_10    product_ub_176  1
    w_5_10    normalized_mass_5_188  1
    w_5_10    normalized_ratio_5_189  -1.4285714285714284e+00
    w_5_10    full_original_Gini_296  -1.5583333333333334e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_11    product_lb_177  -2.5358490566012373e-02
    x_5_11    product_ub_178  -4.3232115285684006e-02
    x_5_11    onehot_5_187  1
    x_5_11    stock_lb_236  11
    x_5_11    stock_ub_237  11
    x_5_11    parent_nonstrict_scope_238  2.6065906449482514e-02
    x_5_11    unique_nonzero_owner_372  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_11    product_lb_177  1
    w_5_11    product_ub_178  1
    w_5_11    normalized_mass_5_188  1
    w_5_11    normalized_ratio_5_189  -1.5714285714285714e+00
    w_5_11    full_original_Gini_296  -1.9297619047619051e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_12    OBJ       6.5164766123706266e-03
    x_5_12    product_lb_179  -2.5358490566012373e-02
    x_5_12    product_ub_180  -4.3232115285684006e-02
    x_5_12    onehot_5_187  1
    x_5_12    stock_lb_236  12
    x_5_12    stock_ub_237  12
    x_5_12    parent_nonstrict_scope_238  3.2582383061853140e-02
    x_5_12    unique_nonzero_owner_373  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_12    product_lb_179  1
    w_5_12    product_ub_180  1
    w_5_12    normalized_mass_5_188  1
    w_5_12    normalized_ratio_5_189  -1.7142857142857142e+00
    w_5_12    full_original_Gini_296  -23.1547619047619
    MARKER    'MARKER'                 'INTORG'
    x_5_13    OBJ       1.3032953224741253e-02
    x_5_13    product_lb_181  -2.5358490566012373e-02
    x_5_13    product_ub_182  -4.3232115285684006e-02
    x_5_13    onehot_5_187  1
    x_5_13    stock_lb_236  13
    x_5_13    stock_ub_237  13
    x_5_13    parent_nonstrict_scope_238  3.9098859674223767e-02
    x_5_13    unique_nonzero_owner_374  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_13    product_lb_181  1
    w_5_13    product_ub_182  1
    w_5_13    normalized_mass_5_188  1
    w_5_13    normalized_ratio_5_189  -1.8571428571428570e+00
    w_5_13    full_original_Gini_296  -2.7011904761904763e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_14    OBJ       1.9549429837111887e-02
    x_5_14    product_lb_183  -2.5358490566012373e-02
    x_5_14    product_ub_184  -4.3232115285684006e-02
    x_5_14    onehot_5_187  1
    x_5_14    stock_lb_236  14
    x_5_14    stock_ub_237  14
    x_5_14    parent_nonstrict_scope_238  0.0456153362865944
    x_5_14    unique_nonzero_owner_375  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_14    product_lb_183  1
    w_5_14    product_ub_184  1
    w_5_14    normalized_mass_5_188  1
    w_5_14    normalized_ratio_5_189  -2
    w_5_14    full_original_Gini_296  -3.0869047619047620e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_15    OBJ       2.6065906449482514e-02
    x_5_15    product_lb_185  -2.5358490566012373e-02
    x_5_15    product_ub_186  -4.3232115285684006e-02
    x_5_15    onehot_5_187  1
    x_5_15    stock_lb_236  15
    x_5_15    stock_ub_237  15
    x_5_15    parent_nonstrict_scope_238  5.2131812898965027e-02
    x_5_15    unique_nonzero_owner_376  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_15    product_lb_185  1
    w_5_15    product_ub_186  1
    w_5_15    normalized_mass_5_188  1
    w_5_15    normalized_ratio_5_189  -2.1428571428571428e+00
    w_5_15    full_original_Gini_296  -3.4726190476190474e+01
    rho_5     normalized_ratio_5_189  1
    rho_5     block_pair_pos_239  1
    rho_5     block_pair_neg_240  -1
    rho_5     block_pair_pos_249  1
    rho_5     block_pair_neg_250  -1
    rho_5     block_pair_pos_261  -1
    rho_5     block_pair_neg_262  1
    rho_5     block_pair_pos_263  -1
    rho_5     block_pair_neg_264  1
    rho_5     block_pair_pos_267  1
    rho_5     block_pair_neg_268  -1
    rho_5     block_pair_pos_277  1
    rho_5     block_pair_neg_278  -1
    rho_5     block_pair_pos_287  1
    rho_5     block_pair_neg_288  -1
    rho_5     normalization_295  1
    MARKER    'MARKER'                 'INTORG'
    x_27_0    OBJ       4.1891612282083379e-03
    x_27_0    product_lb_190  -2.5358490566012373e-02
    x_27_0    product_ub_191  -4.3232115285684006e-02
    x_27_0    onehot_27_204  1
    x_27_0    parent_nonstrict_scope_238  8.3783224564166758e-03
    MARKER    'MARKER'                 'INTEND'
    w_27_0    product_lb_190  1
    w_27_0    product_ub_191  1
    w_27_0    normalized_mass_27_205  1
    w_27_0    full_original_Gini_296  -2.3130952380952380e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_1    OBJ       1.3963870760694466e-03
    x_27_1    product_lb_192  -2.5358490566012373e-02
    x_27_1    product_ub_193  -4.3232115285684006e-02
    x_27_1    onehot_27_204  1
    x_27_1    stock_lb_236  1
    x_27_1    stock_ub_237  1
    x_27_1    parent_nonstrict_scope_238  5.5855483042777845e-03
    x_27_1    unique_nonzero_owner_377  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_1    product_lb_192  1
    w_27_1    product_ub_193  1
    w_27_1    normalized_mass_27_205  1
    w_27_1    normalized_ratio_27_206  -3.3333333333333331e-01
    w_27_1    full_original_Gini_296  -1.4797619047619046e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_2    OBJ       -1.3963870760694457e-03
    x_27_2    product_lb_194  -2.5358490566012373e-02
    x_27_2    product_ub_195  -4.3232115285684006e-02
    x_27_2    onehot_27_204  1
    x_27_2    stock_lb_236  2
    x_27_2    stock_ub_237  2
    x_27_2    parent_nonstrict_scope_238  2.7927741521388922e-03
    x_27_2    unique_nonzero_owner_378  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_2    product_lb_194  1
    w_27_2    product_ub_195  1
    w_27_2    normalized_mass_27_205  1
    w_27_2    normalized_ratio_27_206  -6.6666666666666663e-01
    w_27_2    full_original_Gini_296  -7.0809523809523807e+00
    MARKER    'MARKER'                 'INTORG'
    x_27_3    OBJ       -4.1891612282083379e-03
    x_27_3    product_lb_196  -2.5358490566012373e-02
    x_27_3    product_ub_197  -4.3232115285684006e-02
    x_27_3    onehot_27_204  1
    x_27_3    stock_lb_236  3
    x_27_3    stock_ub_237  3
    x_27_3    unique_nonzero_owner_379  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_3    product_lb_196  1
    w_27_3    product_ub_197  1
    w_27_3    normalized_mass_27_205  1
    w_27_3    normalized_ratio_27_206  -1
    w_27_3    full_original_Gini_296  -4.8690476190476195e+00
    MARKER    'MARKER'                 'INTORG'
    x_27_4    OBJ       -1.3963870760694466e-03
    x_27_4    product_lb_198  -2.5358490566012373e-02
    x_27_4    product_ub_199  -4.3232115285684006e-02
    x_27_4    onehot_27_204  1
    x_27_4    stock_lb_236  4
    x_27_4    stock_ub_237  4
    x_27_4    parent_nonstrict_scope_238  2.7927741521388914e-03
    x_27_4    unique_nonzero_owner_380  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_4    product_lb_198  1
    w_27_4    product_ub_199  1
    w_27_4    normalized_mass_27_205  1
    w_27_4    normalized_ratio_27_206  -1.3333333333333333e+00
    w_27_4    full_original_Gini_296  -1.3202380952380951e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_5    OBJ       1.3963870760694448e-03
    x_27_5    product_lb_200  -2.5358490566012373e-02
    x_27_5    product_ub_201  -4.3232115285684006e-02
    x_27_5    onehot_27_204  1
    x_27_5    stock_lb_236  5
    x_27_5    stock_ub_237  5
    x_27_5    parent_nonstrict_scope_238  5.5855483042777827e-03
    x_27_5    unique_nonzero_owner_381  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_5    product_lb_200  1
    w_27_5    product_ub_201  1
    w_27_5    normalized_mass_27_205  1
    w_27_5    normalized_ratio_27_206  -1.6666666666666665e+00
    w_27_5    full_original_Gini_296  -2.1869047619047613e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_6    OBJ       4.1891612282083379e-03
    x_27_6    product_lb_202  -2.5358490566012373e-02
    x_27_6    product_ub_203  -4.3232115285684006e-02
    x_27_6    onehot_27_204  1
    x_27_6    stock_lb_236  6
    x_27_6    stock_ub_237  6
    x_27_6    parent_nonstrict_scope_238  8.3783224564166758e-03
    x_27_6    unique_nonzero_owner_382  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_6    product_lb_202  1
    w_27_6    product_ub_203  1
    w_27_6    normalized_mass_27_205  1
    w_27_6    normalized_ratio_27_206  -2
    w_27_6    full_original_Gini_296  -3.0869047619047620e+01
    rho_27    normalized_ratio_27_206  1
    rho_27    block_pair_pos_245  1
    rho_27    block_pair_neg_246  -1
    rho_27    block_pair_pos_257  1
    rho_27    block_pair_neg_258  -1
    rho_27    block_pair_pos_263  1
    rho_27    block_pair_neg_264  -1
    rho_27    block_pair_pos_273  1
    rho_27    block_pair_neg_274  -1
    rho_27    block_pair_pos_281  1
    rho_27    block_pair_neg_282  -1
    rho_27    block_pair_pos_283  -1
    rho_27    block_pair_neg_284  1
    rho_27    block_pair_pos_293  1
    rho_27    block_pair_neg_294  -1
    rho_27    normalization_295  1
    MARKER    'MARKER'                 'INTORG'
    x_8_0     OBJ       1.6756644912833352e-02
    x_8_0     product_lb_207  -2.5358490566012373e-02
    x_8_0     product_ub_208  -4.3232115285684006e-02
    x_8_0     onehot_8_233  1
    x_8_0     parent_nonstrict_scope_238  0.0335132898256667
    x_8_0     unique_nonzero_owner_383  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_0     product_lb_207  1
    w_8_0     product_ub_208  1
    w_8_0     normalized_mass_8_234  1
    w_8_0     full_original_Gini_296  -2.3130952380952380e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_1     OBJ       1.1171096608555569e-02
    x_8_1     product_lb_209  -2.5358490566012373e-02
    x_8_1     product_ub_210  -4.3232115285684006e-02
    x_8_1     onehot_8_233  1
    x_8_1     stock_lb_236  1
    x_8_1     stock_ub_237  1
    x_8_1     parent_nonstrict_scope_238  2.7927741521388921e-02
    x_8_1     unique_nonzero_owner_384  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_1     product_lb_209  1
    w_8_1     product_ub_210  1
    w_8_1     normalized_mass_8_234  1
    w_8_1     normalized_ratio_8_235  -1.6666666666666666e-01
    w_8_1     full_original_Gini_296  -1.8964285714285715e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_2     OBJ       5.5855483042777862e-03
    x_8_2     product_lb_211  -2.5358490566012373e-02
    x_8_2     product_ub_212  -4.3232115285684006e-02
    x_8_2     onehot_8_233  1
    x_8_2     stock_lb_236  2
    x_8_2     stock_ub_237  2
    x_8_2     parent_nonstrict_scope_238  2.2342193217111138e-02
    x_8_2     unique_nonzero_owner_385  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_2     product_lb_211  1
    w_8_2     product_ub_212  1
    w_8_2     normalized_mass_8_234  1
    w_8_2     normalized_ratio_8_235  -3.3333333333333331e-01
    w_8_2     full_original_Gini_296  -1.4797619047619046e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_3     product_lb_213  -2.5358490566012373e-02
    x_8_3     product_ub_214  -4.3232115285684006e-02
    x_8_3     onehot_8_233  1
    x_8_3     stock_lb_236  3
    x_8_3     stock_ub_237  3
    x_8_3     parent_nonstrict_scope_238  1.6756644912833352e-02
    x_8_3     unique_nonzero_owner_386  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_3     product_lb_213  1
    w_8_3     product_ub_214  1
    w_8_3     normalized_mass_8_234  1
    w_8_3     normalized_ratio_8_235  -0.5
    w_8_3     full_original_Gini_296  -1.0830952380952379e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_4     OBJ       -5.5855483042777827e-03
    x_8_4     product_lb_215  -2.5358490566012373e-02
    x_8_4     product_ub_216  -4.3232115285684006e-02
    x_8_4     onehot_8_233  1
    x_8_4     stock_lb_236  4
    x_8_4     stock_ub_237  4
    x_8_4     parent_nonstrict_scope_238  1.1171096608555569e-02
    x_8_4     unique_nonzero_owner_387  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_4     product_lb_215  1
    w_8_4     product_ub_216  1
    w_8_4     normalized_mass_8_234  1
    w_8_4     normalized_ratio_8_235  -6.6666666666666663e-01
    w_8_4     full_original_Gini_296  -7.0809523809523807e+00
    MARKER    'MARKER'                 'INTORG'
    x_8_5     OBJ       -1.1171096608555565e-02
    x_8_5     product_lb_217  -2.5358490566012373e-02
    x_8_5     product_ub_218  -4.3232115285684006e-02
    x_8_5     onehot_8_233  1
    x_8_5     stock_lb_236  5
    x_8_5     stock_ub_237  5
    x_8_5     parent_nonstrict_scope_238  5.5855483042777862e-03
    x_8_5     unique_nonzero_owner_388  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_5     product_lb_217  1
    w_8_5     product_ub_218  1
    w_8_5     normalized_mass_8_234  1
    w_8_5     normalized_ratio_8_235  -8.3333333333333326e-01
    w_8_5     full_original_Gini_296  -4.8809523809523814e+00
    MARKER    'MARKER'                 'INTORG'
    x_8_6     OBJ       -1.6756644912833352e-02
    x_8_6     product_lb_219  -2.5358490566012373e-02
    x_8_6     product_ub_220  -4.3232115285684006e-02
    x_8_6     onehot_8_233  1
    x_8_6     stock_lb_236  6
    x_8_6     stock_ub_237  6
    x_8_6     unique_nonzero_owner_389  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_6     product_lb_219  1
    w_8_6     product_ub_220  1
    w_8_6     normalized_mass_8_234  1
    w_8_6     normalized_ratio_8_235  -1
    w_8_6     full_original_Gini_296  -4.8690476190476195e+00
    MARKER    'MARKER'                 'INTORG'
    x_8_7     OBJ       -1.1171096608555572e-02
    x_8_7     product_lb_221  -2.5358490566012373e-02
    x_8_7     product_ub_222  -4.3232115285684006e-02
    x_8_7     onehot_8_233  1
    x_8_7     stock_lb_236  7
    x_8_7     stock_ub_237  7
    x_8_7     parent_nonstrict_scope_238  5.5855483042777793e-03
    x_8_7     unique_nonzero_owner_390  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_7     product_lb_221  1
    w_8_7     product_ub_222  1
    w_8_7     normalized_mass_8_234  1
    w_8_7     normalized_ratio_8_235  -1.1666666666666665e+00
    w_8_7     full_original_Gini_296  -9.03571428571428
    MARKER    'MARKER'                 'INTORG'
    x_8_8     OBJ       -5.5855483042777862e-03
    x_8_8     product_lb_223  -2.5358490566012373e-02
    x_8_8     product_ub_224  -4.3232115285684006e-02
    x_8_8     onehot_8_233  1
    x_8_8     stock_lb_236  8
    x_8_8     stock_ub_237  8
    x_8_8     parent_nonstrict_scope_238  1.1171096608555565e-02
    x_8_8     unique_nonzero_owner_391  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_8     product_lb_223  1
    w_8_8     product_ub_224  1
    w_8_8     normalized_mass_8_234  1
    w_8_8     normalized_ratio_8_235  -1.3333333333333333e+00
    w_8_8     full_original_Gini_296  -1.3202380952380951e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_9     product_lb_225  -2.5358490566012373e-02
    x_8_9     product_ub_226  -4.3232115285684006e-02
    x_8_9     onehot_8_233  1
    x_8_9     stock_lb_236  9
    x_8_9     stock_ub_237  9
    x_8_9     parent_nonstrict_scope_238  1.6756644912833352e-02
    MARKER    'MARKER'                 'INTEND'
    w_8_9     product_lb_225  1
    w_8_9     product_ub_226  1
    w_8_9     normalized_mass_8_234  1
    w_8_9     normalized_ratio_8_235  -1.5
    w_8_9     full_original_Gini_296  -1.7369047619047620e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_10    OBJ       5.5855483042777793e-03
    x_8_10    product_lb_227  -2.5358490566012373e-02
    x_8_10    product_ub_228  -4.3232115285684006e-02
    x_8_10    onehot_8_233  1
    x_8_10    stock_lb_236  10
    x_8_10    stock_ub_237  10
    x_8_10    parent_nonstrict_scope_238  2.2342193217111131e-02
    x_8_10    unique_nonzero_owner_392  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_10    product_lb_227  1
    w_8_10    product_ub_228  1
    w_8_10    normalized_mass_8_234  1
    w_8_10    normalized_ratio_8_235  -1.6666666666666665e+00
    w_8_10    full_original_Gini_296  -2.1869047619047613e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_11    OBJ       1.1171096608555565e-02
    x_8_11    product_lb_229  -2.5358490566012373e-02
    x_8_11    product_ub_230  -4.3232115285684006e-02
    x_8_11    onehot_8_233  1
    x_8_11    stock_lb_236  11
    x_8_11    stock_ub_237  11
    x_8_11    parent_nonstrict_scope_238  2.7927741521388917e-02
    x_8_11    unique_nonzero_owner_393  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_11    product_lb_229  1
    w_8_11    product_ub_230  1
    w_8_11    normalized_mass_8_234  1
    w_8_11    normalized_ratio_8_235  -1.8333333333333333e+00
    w_8_11    full_original_Gini_296  -2.6369047619047620e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_12    OBJ       1.6756644912833352e-02
    x_8_12    product_lb_231  -2.5358490566012373e-02
    x_8_12    product_ub_232  -4.3232115285684006e-02
    x_8_12    onehot_8_233  1
    x_8_12    stock_lb_236  12
    x_8_12    stock_ub_237  12
    x_8_12    parent_nonstrict_scope_238  0.0335132898256667
    x_8_12    unique_nonzero_owner_394  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_12    product_lb_231  1
    w_8_12    product_ub_232  1
    w_8_12    normalized_mass_8_234  1
    w_8_12    normalized_ratio_8_235  -2
    w_8_12    full_original_Gini_296  -3.0869047619047620e+01
    rho_8     normalized_ratio_8_235  1
    rho_8     block_pair_pos_241  1
    rho_8     block_pair_neg_242  -1
    rho_8     block_pair_pos_253  1
    rho_8     block_pair_neg_254  -1
    rho_8     block_pair_pos_261  1
    rho_8     block_pair_neg_262  -1
    rho_8     block_pair_pos_269  1
    rho_8     block_pair_neg_270  -1
    rho_8     block_pair_pos_279  1
    rho_8     block_pair_neg_280  -1
    rho_8     block_pair_pos_283  1
    rho_8     block_pair_neg_284  -1
    rho_8     block_pair_pos_289  1
    rho_8     block_pair_neg_290  -1
    rho_8     normalization_295  1
    a_4_6     block_pair_pos_251  1
    a_4_6     block_pair_neg_252  1
    a_4_6     full_original_Gini_296  -1
    a_4_34    block_pair_pos_259  1
    a_4_34    block_pair_neg_260  1
    a_4_34    full_original_Gini_296  -1
    a_4_3     block_pair_pos_247  1
    a_4_3     block_pair_neg_248  1
    a_4_3     full_original_Gini_296  -1
    a_4_22    block_pair_pos_255  1
    a_4_22    block_pair_neg_256  1
    a_4_22    full_original_Gini_296  -1
    a_4_5     block_pair_pos_249  1
    a_4_5     block_pair_neg_250  1
    a_4_5     full_original_Gini_296  -1
    a_4_27    block_pair_pos_257  1
    a_4_27    block_pair_neg_258  1
    a_4_27    full_original_Gini_296  -1
    a_4_8     block_pair_pos_253  1
    a_4_8     block_pair_neg_254  1
    a_4_8     full_original_Gini_296  -1
    a_6_34    block_pair_pos_275  1
    a_6_34    block_pair_neg_276  1
    a_6_34    full_original_Gini_296  -1
    a_6_3     block_pair_pos_265  1
    a_6_3     block_pair_neg_266  1
    a_6_3     full_original_Gini_296  -1
    a_6_22    block_pair_pos_271  1
    a_6_22    block_pair_neg_272  1
    a_6_22    full_original_Gini_296  -1
    a_6_5     block_pair_pos_267  1
    a_6_5     block_pair_neg_268  1
    a_6_5     full_original_Gini_296  -1
    a_6_27    block_pair_pos_273  1
    a_6_27    block_pair_neg_274  1
    a_6_27    full_original_Gini_296  -1
    a_6_8     block_pair_pos_269  1
    a_6_8     block_pair_neg_270  1
    a_6_8     full_original_Gini_296  -1
    a_34_3    block_pair_pos_285  1
    a_34_3    block_pair_neg_286  1
    a_34_3    full_original_Gini_296  -1
    a_34_22   block_pair_pos_291  1
    a_34_22   block_pair_neg_292  1
    a_34_22   full_original_Gini_296  -1
    a_34_5    block_pair_pos_287  1
    a_34_5    block_pair_neg_288  1
    a_34_5    full_original_Gini_296  -1
    a_34_27   block_pair_pos_293  1
    a_34_27   block_pair_neg_294  1
    a_34_27   full_original_Gini_296  -1
    a_34_8    block_pair_pos_289  1
    a_34_8    block_pair_neg_290  1
    a_34_8    full_original_Gini_296  -1
    a_3_22    block_pair_pos_243  1
    a_3_22    block_pair_neg_244  1
    a_3_22    full_original_Gini_296  -1
    a_3_5     block_pair_pos_239  1
    a_3_5     block_pair_neg_240  1
    a_3_5     full_original_Gini_296  -1
    a_3_27    block_pair_pos_245  1
    a_3_27    block_pair_neg_246  1
    a_3_27    full_original_Gini_296  -1
    a_3_8     block_pair_pos_241  1
    a_3_8     block_pair_neg_242  1
    a_3_8     full_original_Gini_296  -1
    a_22_5    block_pair_pos_277  1
    a_22_5    block_pair_neg_278  1
    a_22_5    full_original_Gini_296  -1
    a_22_27   block_pair_pos_281  1
    a_22_27   block_pair_neg_282  1
    a_22_27   full_original_Gini_296  -1
    a_22_8    block_pair_pos_279  1
    a_22_8    block_pair_neg_280  1
    a_22_8    full_original_Gini_296  -1
    a_5_27    block_pair_pos_263  1
    a_5_27    block_pair_neg_264  1
    a_5_27    full_original_Gini_296  -1
    a_5_8     block_pair_pos_261  1
    a_5_8     block_pair_neg_262  1
    a_5_8     full_original_Gini_296  -1
    a_27_8    block_pair_pos_283  1
    a_27_8    block_pair_neg_284  1
    a_27_8    full_original_Gini_296  -1
    MARKER    'MARKER'                 'INTORG'
    service_0_4_0  unique_nonzero_owner_297  1
    service_0_4_0  service_visit_def_775  1
    service_0_4_0  free_load_conservation_776  -2
    service_0_4_0  original_T_including_depot_unload_823  240
    service_0_4_1  unique_nonzero_owner_298  1
    service_0_4_1  service_visit_def_775  1
    service_0_4_1  free_load_conservation_776  -1
    service_0_4_1  original_T_including_depot_unload_823  120
    service_0_4_3  unique_nonzero_owner_299  1
    service_0_4_3  service_visit_def_775  1
    service_0_4_3  free_load_conservation_776  1
    service_0_4_4  unique_nonzero_owner_300  1
    service_0_4_4  service_visit_def_775  1
    service_0_4_4  free_load_conservation_776  2
    service_0_4_5  unique_nonzero_owner_301  1
    service_0_4_5  service_visit_def_775  1
    service_0_4_5  free_load_conservation_776  3
    service_0_4_6  unique_nonzero_owner_302  1
    service_0_4_6  service_visit_def_775  1
    service_0_4_6  free_load_conservation_776  4
    service_0_4_7  unique_nonzero_owner_303  1
    service_0_4_7  service_visit_def_775  1
    service_0_4_7  free_load_conservation_776  5
    service_0_4_8  unique_nonzero_owner_304  1
    service_0_4_8  service_visit_def_775  1
    service_0_4_8  free_load_conservation_776  6
    service_0_4_9  unique_nonzero_owner_305  1
    service_0_4_9  service_visit_def_775  1
    service_0_4_9  free_load_conservation_776  7
    service_0_4_10  unique_nonzero_owner_306  1
    service_0_4_10  service_visit_def_775  1
    service_0_4_10  free_load_conservation_776  8
    service_0_4_11  unique_nonzero_owner_307  1
    service_0_4_11  service_visit_def_775  1
    service_0_4_11  free_load_conservation_776  9
    service_0_4_12  unique_nonzero_owner_308  1
    service_0_4_12  service_visit_def_775  1
    service_0_4_12  free_load_conservation_776  10
    service_0_4_13  unique_nonzero_owner_309  1
    service_0_4_13  service_visit_def_775  1
    service_0_4_13  free_load_conservation_776  11
    service_0_4_14  unique_nonzero_owner_310  1
    service_0_4_14  service_visit_def_775  1
    service_0_4_14  free_load_conservation_776  12
    service_0_4_15  unique_nonzero_owner_311  1
    service_0_4_15  service_visit_def_775  1
    service_0_4_15  free_load_conservation_776  13
    service_1_4_0  unique_nonzero_owner_297  1
    service_1_4_0  service_visit_def_1147  1
    service_1_4_0  free_load_conservation_1148  -2
    service_1_4_0  original_T_including_depot_unload_1194  240
    service_1_4_1  unique_nonzero_owner_298  1
    service_1_4_1  service_visit_def_1147  1
    service_1_4_1  free_load_conservation_1148  -1
    service_1_4_1  original_T_including_depot_unload_1194  120
    service_1_4_3  unique_nonzero_owner_299  1
    service_1_4_3  service_visit_def_1147  1
    service_1_4_3  free_load_conservation_1148  1
    service_1_4_4  unique_nonzero_owner_300  1
    service_1_4_4  service_visit_def_1147  1
    service_1_4_4  free_load_conservation_1148  2
    service_1_4_5  unique_nonzero_owner_301  1
    service_1_4_5  service_visit_def_1147  1
    service_1_4_5  free_load_conservation_1148  3
    service_1_4_6  unique_nonzero_owner_302  1
    service_1_4_6  service_visit_def_1147  1
    service_1_4_6  free_load_conservation_1148  4
    service_1_4_7  unique_nonzero_owner_303  1
    service_1_4_7  service_visit_def_1147  1
    service_1_4_7  free_load_conservation_1148  5
    service_1_4_8  unique_nonzero_owner_304  1
    service_1_4_8  service_visit_def_1147  1
    service_1_4_8  free_load_conservation_1148  6
    service_1_4_9  unique_nonzero_owner_305  1
    service_1_4_9  service_visit_def_1147  1
    service_1_4_9  free_load_conservation_1148  7
    service_1_4_10  unique_nonzero_owner_306  1
    service_1_4_10  service_visit_def_1147  1
    service_1_4_10  free_load_conservation_1148  8
    service_1_4_11  unique_nonzero_owner_307  1
    service_1_4_11  service_visit_def_1147  1
    service_1_4_11  free_load_conservation_1148  9
    service_1_4_12  unique_nonzero_owner_308  1
    service_1_4_12  service_visit_def_1147  1
    service_1_4_12  free_load_conservation_1148  10
    service_1_4_13  unique_nonzero_owner_309  1
    service_1_4_13  service_visit_def_1147  1
    service_1_4_13  free_load_conservation_1148  11
    service_1_4_14  unique_nonzero_owner_310  1
    service_1_4_14  service_visit_def_1147  1
    service_1_4_14  free_load_conservation_1148  12
    service_1_4_15  unique_nonzero_owner_311  1
    service_1_4_15  service_visit_def_1147  1
    service_1_4_15  free_load_conservation_1148  13
    service_2_4_0  unique_nonzero_owner_297  1
    service_2_4_0  service_visit_def_1465  1
    service_2_4_0  free_load_conservation_1466  -2
    service_2_4_0  original_T_including_depot_unload_1511  240
    service_2_4_1  unique_nonzero_owner_298  1
    service_2_4_1  service_visit_def_1465  1
    service_2_4_1  free_load_conservation_1466  -1
    service_2_4_1  original_T_including_depot_unload_1511  120
    service_2_4_3  unique_nonzero_owner_299  1
    service_2_4_3  service_visit_def_1465  1
    service_2_4_3  free_load_conservation_1466  1
    service_2_4_4  unique_nonzero_owner_300  1
    service_2_4_4  service_visit_def_1465  1
    service_2_4_4  free_load_conservation_1466  2
    service_2_4_5  unique_nonzero_owner_301  1
    service_2_4_5  service_visit_def_1465  1
    service_2_4_5  free_load_conservation_1466  3
    service_2_4_6  unique_nonzero_owner_302  1
    service_2_4_6  service_visit_def_1465  1
    service_2_4_6  free_load_conservation_1466  4
    service_2_4_7  unique_nonzero_owner_303  1
    service_2_4_7  service_visit_def_1465  1
    service_2_4_7  free_load_conservation_1466  5
    service_2_4_8  unique_nonzero_owner_304  1
    service_2_4_8  service_visit_def_1465  1
    service_2_4_8  free_load_conservation_1466  6
    service_2_4_9  unique_nonzero_owner_305  1
    service_2_4_9  service_visit_def_1465  1
    service_2_4_9  free_load_conservation_1466  7
    service_2_4_10  unique_nonzero_owner_306  1
    service_2_4_10  service_visit_def_1465  1
    service_2_4_10  free_load_conservation_1466  8
    service_2_4_11  unique_nonzero_owner_307  1
    service_2_4_11  service_visit_def_1465  1
    service_2_4_11  free_load_conservation_1466  9
    service_2_4_12  unique_nonzero_owner_308  1
    service_2_4_12  service_visit_def_1465  1
    service_2_4_12  free_load_conservation_1466  10
    service_2_4_13  unique_nonzero_owner_309  1
    service_2_4_13  service_visit_def_1465  1
    service_2_4_13  free_load_conservation_1466  11
    service_2_4_14  unique_nonzero_owner_310  1
    service_2_4_14  service_visit_def_1465  1
    service_2_4_14  free_load_conservation_1466  12
    service_2_4_15  unique_nonzero_owner_311  1
    service_2_4_15  service_visit_def_1465  1
    service_2_4_15  free_load_conservation_1466  13
    service_0_6_0  unique_nonzero_owner_312  1
    service_0_6_0  service_visit_def_781  1
    service_0_6_0  free_load_conservation_782  -6
    service_0_6_0  original_T_including_depot_unload_823  720
    service_0_6_1  unique_nonzero_owner_313  1
    service_0_6_1  service_visit_def_781  1
    service_0_6_1  free_load_conservation_782  -5
    service_0_6_1  original_T_including_depot_unload_823  600
    service_0_6_2  unique_nonzero_owner_314  1
    service_0_6_2  service_visit_def_781  1
    service_0_6_2  free_load_conservation_782  -4
    service_0_6_2  original_T_including_depot_unload_823  480
    service_0_6_3  unique_nonzero_owner_315  1
    service_0_6_3  service_visit_def_781  1
    service_0_6_3  free_load_conservation_782  -3
    service_0_6_3  original_T_including_depot_unload_823  360
    service_0_6_4  unique_nonzero_owner_316  1
    service_0_6_4  service_visit_def_781  1
    service_0_6_4  free_load_conservation_782  -2
    service_0_6_4  original_T_including_depot_unload_823  240
    service_0_6_5  unique_nonzero_owner_317  1
    service_0_6_5  service_visit_def_781  1
    service_0_6_5  free_load_conservation_782  -1
    service_0_6_5  original_T_including_depot_unload_823  120
    service_0_6_7  unique_nonzero_owner_318  1
    service_0_6_7  service_visit_def_781  1
    service_0_6_7  free_load_conservation_782  1
    service_0_6_8  unique_nonzero_owner_319  1
    service_0_6_8  service_visit_def_781  1
    service_0_6_8  free_load_conservation_782  2
    service_1_6_0  unique_nonzero_owner_312  1
    service_1_6_0  service_visit_def_1153  1
    service_1_6_0  free_load_conservation_1154  -6
    service_1_6_0  original_T_including_depot_unload_1194  720
    service_1_6_1  unique_nonzero_owner_313  1
    service_1_6_1  service_visit_def_1153  1
    service_1_6_1  free_load_conservation_1154  -5
    service_1_6_1  original_T_including_depot_unload_1194  600
    service_1_6_2  unique_nonzero_owner_314  1
    service_1_6_2  service_visit_def_1153  1
    service_1_6_2  free_load_conservation_1154  -4
    service_1_6_2  original_T_including_depot_unload_1194  480
    service_1_6_3  unique_nonzero_owner_315  1
    service_1_6_3  service_visit_def_1153  1
    service_1_6_3  free_load_conservation_1154  -3
    service_1_6_3  original_T_including_depot_unload_1194  360
    service_1_6_4  unique_nonzero_owner_316  1
    service_1_6_4  service_visit_def_1153  1
    service_1_6_4  free_load_conservation_1154  -2
    service_1_6_4  original_T_including_depot_unload_1194  240
    service_1_6_5  unique_nonzero_owner_317  1
    service_1_6_5  service_visit_def_1153  1
    service_1_6_5  free_load_conservation_1154  -1
    service_1_6_5  original_T_including_depot_unload_1194  120
    service_1_6_7  unique_nonzero_owner_318  1
    service_1_6_7  service_visit_def_1153  1
    service_1_6_7  free_load_conservation_1154  1
    service_1_6_8  unique_nonzero_owner_319  1
    service_1_6_8  service_visit_def_1153  1
    service_1_6_8  free_load_conservation_1154  2
    service_2_6_0  unique_nonzero_owner_312  1
    service_2_6_0  service_visit_def_1471  1
    service_2_6_0  free_load_conservation_1472  -6
    service_2_6_0  original_T_including_depot_unload_1511  720
    service_2_6_1  unique_nonzero_owner_313  1
    service_2_6_1  service_visit_def_1471  1
    service_2_6_1  free_load_conservation_1472  -5
    service_2_6_1  original_T_including_depot_unload_1511  600
    service_2_6_2  unique_nonzero_owner_314  1
    service_2_6_2  service_visit_def_1471  1
    service_2_6_2  free_load_conservation_1472  -4
    service_2_6_2  original_T_including_depot_unload_1511  480
    service_2_6_3  unique_nonzero_owner_315  1
    service_2_6_3  service_visit_def_1471  1
    service_2_6_3  free_load_conservation_1472  -3
    service_2_6_3  original_T_including_depot_unload_1511  360
    service_2_6_4  unique_nonzero_owner_316  1
    service_2_6_4  service_visit_def_1471  1
    service_2_6_4  free_load_conservation_1472  -2
    service_2_6_4  original_T_including_depot_unload_1511  240
    service_2_6_5  unique_nonzero_owner_317  1
    service_2_6_5  service_visit_def_1471  1
    service_2_6_5  free_load_conservation_1472  -1
    service_2_6_5  original_T_including_depot_unload_1511  120
    service_2_6_7  unique_nonzero_owner_318  1
    service_2_6_7  service_visit_def_1471  1
    service_2_6_7  free_load_conservation_1472  1
    service_2_6_8  unique_nonzero_owner_319  1
    service_2_6_8  service_visit_def_1471  1
    service_2_6_8  free_load_conservation_1472  2
    service_0_34_0  unique_nonzero_owner_320  1
    service_0_34_0  service_visit_def_787  1
    service_0_34_0  free_load_conservation_788  -2
    service_0_34_0  original_T_including_depot_unload_823  240
    service_0_34_1  unique_nonzero_owner_321  1
    service_0_34_1  service_visit_def_787  1
    service_0_34_1  free_load_conservation_788  -1
    service_0_34_1  original_T_including_depot_unload_823  120
    service_0_34_3  unique_nonzero_owner_322  1
    service_0_34_3  service_visit_def_787  1
    service_0_34_3  free_load_conservation_788  1
    service_0_34_4  unique_nonzero_owner_323  1
    service_0_34_4  service_visit_def_787  1
    service_0_34_4  free_load_conservation_788  2
    service_0_34_5  unique_nonzero_owner_324  1
    service_0_34_5  service_visit_def_787  1
    service_0_34_5  free_load_conservation_788  3
    service_0_34_6  unique_nonzero_owner_325  1
    service_0_34_6  service_visit_def_787  1
    service_0_34_6  free_load_conservation_788  4
    service_0_34_7  unique_nonzero_owner_326  1
    service_0_34_7  service_visit_def_787  1
    service_0_34_7  free_load_conservation_788  5
    service_0_34_8  unique_nonzero_owner_327  1
    service_0_34_8  service_visit_def_787  1
    service_0_34_8  free_load_conservation_788  6
    service_0_34_9  unique_nonzero_owner_328  1
    service_0_34_9  service_visit_def_787  1
    service_0_34_9  free_load_conservation_788  7
    service_0_34_10  unique_nonzero_owner_329  1
    service_0_34_10  service_visit_def_787  1
    service_0_34_10  free_load_conservation_788  8
    service_0_34_11  unique_nonzero_owner_330  1
    service_0_34_11  service_visit_def_787  1
    service_0_34_11  free_load_conservation_788  9
    service_0_34_12  unique_nonzero_owner_331  1
    service_0_34_12  service_visit_def_787  1
    service_0_34_12  free_load_conservation_788  10
    service_0_34_13  unique_nonzero_owner_332  1
    service_0_34_13  service_visit_def_787  1
    service_0_34_13  free_load_conservation_788  11
    service_0_34_14  unique_nonzero_owner_333  1
    service_0_34_14  service_visit_def_787  1
    service_0_34_14  free_load_conservation_788  12
    service_0_34_15  unique_nonzero_owner_334  1
    service_0_34_15  service_visit_def_787  1
    service_0_34_15  free_load_conservation_788  13
    service_1_34_0  unique_nonzero_owner_320  1
    service_1_34_0  service_visit_def_1159  1
    service_1_34_0  free_load_conservation_1160  -2
    service_1_34_0  original_T_including_depot_unload_1194  240
    service_1_34_1  unique_nonzero_owner_321  1
    service_1_34_1  service_visit_def_1159  1
    service_1_34_1  free_load_conservation_1160  -1
    service_1_34_1  original_T_including_depot_unload_1194  120
    service_1_34_3  unique_nonzero_owner_322  1
    service_1_34_3  service_visit_def_1159  1
    service_1_34_3  free_load_conservation_1160  1
    service_1_34_4  unique_nonzero_owner_323  1
    service_1_34_4  service_visit_def_1159  1
    service_1_34_4  free_load_conservation_1160  2
    service_1_34_5  unique_nonzero_owner_324  1
    service_1_34_5  service_visit_def_1159  1
    service_1_34_5  free_load_conservation_1160  3
    service_1_34_6  unique_nonzero_owner_325  1
    service_1_34_6  service_visit_def_1159  1
    service_1_34_6  free_load_conservation_1160  4
    service_1_34_7  unique_nonzero_owner_326  1
    service_1_34_7  service_visit_def_1159  1
    service_1_34_7  free_load_conservation_1160  5
    service_1_34_8  unique_nonzero_owner_327  1
    service_1_34_8  service_visit_def_1159  1
    service_1_34_8  free_load_conservation_1160  6
    service_1_34_9  unique_nonzero_owner_328  1
    service_1_34_9  service_visit_def_1159  1
    service_1_34_9  free_load_conservation_1160  7
    service_1_34_10  unique_nonzero_owner_329  1
    service_1_34_10  service_visit_def_1159  1
    service_1_34_10  free_load_conservation_1160  8
    service_1_34_11  unique_nonzero_owner_330  1
    service_1_34_11  service_visit_def_1159  1
    service_1_34_11  free_load_conservation_1160  9
    service_1_34_12  unique_nonzero_owner_331  1
    service_1_34_12  service_visit_def_1159  1
    service_1_34_12  free_load_conservation_1160  10
    service_1_34_13  unique_nonzero_owner_332  1
    service_1_34_13  service_visit_def_1159  1
    service_1_34_13  free_load_conservation_1160  11
    service_1_34_14  unique_nonzero_owner_333  1
    service_1_34_14  service_visit_def_1159  1
    service_1_34_14  free_load_conservation_1160  12
    service_1_34_15  unique_nonzero_owner_334  1
    service_1_34_15  service_visit_def_1159  1
    service_1_34_15  free_load_conservation_1160  13
    service_2_34_0  unique_nonzero_owner_320  1
    service_2_34_0  service_visit_def_1477  1
    service_2_34_0  free_load_conservation_1478  -2
    service_2_34_0  original_T_including_depot_unload_1511  240
    service_2_34_1  unique_nonzero_owner_321  1
    service_2_34_1  service_visit_def_1477  1
    service_2_34_1  free_load_conservation_1478  -1
    service_2_34_1  original_T_including_depot_unload_1511  120
    service_2_34_3  unique_nonzero_owner_322  1
    service_2_34_3  service_visit_def_1477  1
    service_2_34_3  free_load_conservation_1478  1
    service_2_34_4  unique_nonzero_owner_323  1
    service_2_34_4  service_visit_def_1477  1
    service_2_34_4  free_load_conservation_1478  2
    service_2_34_5  unique_nonzero_owner_324  1
    service_2_34_5  service_visit_def_1477  1
    service_2_34_5  free_load_conservation_1478  3
    service_2_34_6  unique_nonzero_owner_325  1
    service_2_34_6  service_visit_def_1477  1
    service_2_34_6  free_load_conservation_1478  4
    service_2_34_7  unique_nonzero_owner_326  1
    service_2_34_7  service_visit_def_1477  1
    service_2_34_7  free_load_conservation_1478  5
    service_2_34_8  unique_nonzero_owner_327  1
    service_2_34_8  service_visit_def_1477  1
    service_2_34_8  free_load_conservation_1478  6
    service_2_34_9  unique_nonzero_owner_328  1
    service_2_34_9  service_visit_def_1477  1
    service_2_34_9  free_load_conservation_1478  7
    service_2_34_10  unique_nonzero_owner_329  1
    service_2_34_10  service_visit_def_1477  1
    service_2_34_10  free_load_conservation_1478  8
    service_2_34_11  unique_nonzero_owner_330  1
    service_2_34_11  service_visit_def_1477  1
    service_2_34_11  free_load_conservation_1478  9
    service_2_34_12  unique_nonzero_owner_331  1
    service_2_34_12  service_visit_def_1477  1
    service_2_34_12  free_load_conservation_1478  10
    service_2_34_13  unique_nonzero_owner_332  1
    service_2_34_13  service_visit_def_1477  1
    service_2_34_13  free_load_conservation_1478  11
    service_2_34_14  unique_nonzero_owner_333  1
    service_2_34_14  service_visit_def_1477  1
    service_2_34_14  free_load_conservation_1478  12
    service_2_34_15  unique_nonzero_owner_334  1
    service_2_34_15  service_visit_def_1477  1
    service_2_34_15  free_load_conservation_1478  13
    service_0_3_0  unique_nonzero_owner_335  1
    service_0_3_0  service_visit_def_793  1
    service_0_3_0  free_load_conservation_794  -9
    service_0_3_0  original_T_including_depot_unload_823  1080
    service_0_3_1  unique_nonzero_owner_336  1
    service_0_3_1  service_visit_def_793  1
    service_0_3_1  free_load_conservation_794  -8
    service_0_3_1  original_T_including_depot_unload_823  960
    service_0_3_2  unique_nonzero_owner_337  1
    service_0_3_2  service_visit_def_793  1
    service_0_3_2  free_load_conservation_794  -7
    service_0_3_2  original_T_including_depot_unload_823  840
    service_0_3_3  unique_nonzero_owner_338  1
    service_0_3_3  service_visit_def_793  1
    service_0_3_3  free_load_conservation_794  -6
    service_0_3_3  original_T_including_depot_unload_823  720
    service_0_3_4  unique_nonzero_owner_339  1
    service_0_3_4  service_visit_def_793  1
    service_0_3_4  free_load_conservation_794  -5
    service_0_3_4  original_T_including_depot_unload_823  600
    service_0_3_5  unique_nonzero_owner_340  1
    service_0_3_5  service_visit_def_793  1
    service_0_3_5  free_load_conservation_794  -4
    service_0_3_5  original_T_including_depot_unload_823  480
    service_0_3_6  unique_nonzero_owner_341  1
    service_0_3_6  service_visit_def_793  1
    service_0_3_6  free_load_conservation_794  -3
    service_0_3_6  original_T_including_depot_unload_823  360
    service_0_3_7  unique_nonzero_owner_342  1
    service_0_3_7  service_visit_def_793  1
    service_0_3_7  free_load_conservation_794  -2
    service_0_3_7  original_T_including_depot_unload_823  240
    service_0_3_8  unique_nonzero_owner_343  1
    service_0_3_8  service_visit_def_793  1
    service_0_3_8  free_load_conservation_794  -1
    service_0_3_8  original_T_including_depot_unload_823  120
    service_0_3_10  unique_nonzero_owner_344  1
    service_0_3_10  service_visit_def_793  1
    service_0_3_10  free_load_conservation_794  1
    service_0_3_11  unique_nonzero_owner_345  1
    service_0_3_11  service_visit_def_793  1
    service_0_3_11  free_load_conservation_794  2
    service_0_3_12  unique_nonzero_owner_346  1
    service_0_3_12  service_visit_def_793  1
    service_0_3_12  free_load_conservation_794  3
    service_1_3_0  unique_nonzero_owner_335  1
    service_1_3_0  service_visit_def_1165  1
    service_1_3_0  free_load_conservation_1166  -9
    service_1_3_0  original_T_including_depot_unload_1194  1080
    service_1_3_1  unique_nonzero_owner_336  1
    service_1_3_1  service_visit_def_1165  1
    service_1_3_1  free_load_conservation_1166  -8
    service_1_3_1  original_T_including_depot_unload_1194  960
    service_1_3_2  unique_nonzero_owner_337  1
    service_1_3_2  service_visit_def_1165  1
    service_1_3_2  free_load_conservation_1166  -7
    service_1_3_2  original_T_including_depot_unload_1194  840
    service_1_3_3  unique_nonzero_owner_338  1
    service_1_3_3  service_visit_def_1165  1
    service_1_3_3  free_load_conservation_1166  -6
    service_1_3_3  original_T_including_depot_unload_1194  720
    service_1_3_4  unique_nonzero_owner_339  1
    service_1_3_4  service_visit_def_1165  1
    service_1_3_4  free_load_conservation_1166  -5
    service_1_3_4  original_T_including_depot_unload_1194  600
    service_1_3_5  unique_nonzero_owner_340  1
    service_1_3_5  service_visit_def_1165  1
    service_1_3_5  free_load_conservation_1166  -4
    service_1_3_5  original_T_including_depot_unload_1194  480
    service_1_3_6  unique_nonzero_owner_341  1
    service_1_3_6  service_visit_def_1165  1
    service_1_3_6  free_load_conservation_1166  -3
    service_1_3_6  original_T_including_depot_unload_1194  360
    service_1_3_7  unique_nonzero_owner_342  1
    service_1_3_7  service_visit_def_1165  1
    service_1_3_7  free_load_conservation_1166  -2
    service_1_3_7  original_T_including_depot_unload_1194  240
    service_1_3_8  unique_nonzero_owner_343  1
    service_1_3_8  service_visit_def_1165  1
    service_1_3_8  free_load_conservation_1166  -1
    service_1_3_8  original_T_including_depot_unload_1194  120
    service_1_3_10  unique_nonzero_owner_344  1
    service_1_3_10  service_visit_def_1165  1
    service_1_3_10  free_load_conservation_1166  1
    service_1_3_11  unique_nonzero_owner_345  1
    service_1_3_11  service_visit_def_1165  1
    service_1_3_11  free_load_conservation_1166  2
    service_1_3_12  unique_nonzero_owner_346  1
    service_1_3_12  service_visit_def_1165  1
    service_1_3_12  free_load_conservation_1166  3
    service_2_3_0  unique_nonzero_owner_335  1
    service_2_3_0  service_visit_def_1483  1
    service_2_3_0  free_load_conservation_1484  -9
    service_2_3_0  original_T_including_depot_unload_1511  1080
    service_2_3_1  unique_nonzero_owner_336  1
    service_2_3_1  service_visit_def_1483  1
    service_2_3_1  free_load_conservation_1484  -8
    service_2_3_1  original_T_including_depot_unload_1511  960
    service_2_3_2  unique_nonzero_owner_337  1
    service_2_3_2  service_visit_def_1483  1
    service_2_3_2  free_load_conservation_1484  -7
    service_2_3_2  original_T_including_depot_unload_1511  840
    service_2_3_3  unique_nonzero_owner_338  1
    service_2_3_3  service_visit_def_1483  1
    service_2_3_3  free_load_conservation_1484  -6
    service_2_3_3  original_T_including_depot_unload_1511  720
    service_2_3_4  unique_nonzero_owner_339  1
    service_2_3_4  service_visit_def_1483  1
    service_2_3_4  free_load_conservation_1484  -5
    service_2_3_4  original_T_including_depot_unload_1511  600
    service_2_3_5  unique_nonzero_owner_340  1
    service_2_3_5  service_visit_def_1483  1
    service_2_3_5  free_load_conservation_1484  -4
    service_2_3_5  original_T_including_depot_unload_1511  480
    service_2_3_6  unique_nonzero_owner_341  1
    service_2_3_6  service_visit_def_1483  1
    service_2_3_6  free_load_conservation_1484  -3
    service_2_3_6  original_T_including_depot_unload_1511  360
    service_2_3_7  unique_nonzero_owner_342  1
    service_2_3_7  service_visit_def_1483  1
    service_2_3_7  free_load_conservation_1484  -2
    service_2_3_7  original_T_including_depot_unload_1511  240
    service_2_3_8  unique_nonzero_owner_343  1
    service_2_3_8  service_visit_def_1483  1
    service_2_3_8  free_load_conservation_1484  -1
    service_2_3_8  original_T_including_depot_unload_1511  120
    service_2_3_10  unique_nonzero_owner_344  1
    service_2_3_10  service_visit_def_1483  1
    service_2_3_10  free_load_conservation_1484  1
    service_2_3_11  unique_nonzero_owner_345  1
    service_2_3_11  service_visit_def_1483  1
    service_2_3_11  free_load_conservation_1484  2
    service_2_3_12  unique_nonzero_owner_346  1
    service_2_3_12  service_visit_def_1483  1
    service_2_3_12  free_load_conservation_1484  3
    service_0_22_0  unique_nonzero_owner_347  1
    service_0_22_0  service_visit_def_799  1
    service_0_22_0  free_load_conservation_800  -2
    service_0_22_0  original_T_including_depot_unload_823  240
    service_0_22_1  unique_nonzero_owner_348  1
    service_0_22_1  service_visit_def_799  1
    service_0_22_1  free_load_conservation_800  -1
    service_0_22_1  original_T_including_depot_unload_823  120
    service_0_22_3  unique_nonzero_owner_349  1
    service_0_22_3  service_visit_def_799  1
    service_0_22_3  free_load_conservation_800  1
    service_0_22_4  unique_nonzero_owner_350  1
    service_0_22_4  service_visit_def_799  1
    service_0_22_4  free_load_conservation_800  2
    service_0_22_5  unique_nonzero_owner_351  1
    service_0_22_5  service_visit_def_799  1
    service_0_22_5  free_load_conservation_800  3
    service_0_22_6  unique_nonzero_owner_352  1
    service_0_22_6  service_visit_def_799  1
    service_0_22_6  free_load_conservation_800  4
    service_0_22_7  unique_nonzero_owner_353  1
    service_0_22_7  service_visit_def_799  1
    service_0_22_7  free_load_conservation_800  5
    service_0_22_8  unique_nonzero_owner_354  1
    service_0_22_8  service_visit_def_799  1
    service_0_22_8  free_load_conservation_800  6
    service_0_22_9  unique_nonzero_owner_355  1
    service_0_22_9  service_visit_def_799  1
    service_0_22_9  free_load_conservation_800  7
    service_0_22_10  unique_nonzero_owner_356  1
    service_0_22_10  service_visit_def_799  1
    service_0_22_10  free_load_conservation_800  8
    service_0_22_11  unique_nonzero_owner_357  1
    service_0_22_11  service_visit_def_799  1
    service_0_22_11  free_load_conservation_800  9
    service_0_22_12  unique_nonzero_owner_358  1
    service_0_22_12  service_visit_def_799  1
    service_0_22_12  free_load_conservation_800  10
    service_0_22_13  unique_nonzero_owner_359  1
    service_0_22_13  service_visit_def_799  1
    service_0_22_13  free_load_conservation_800  11
    service_0_22_14  unique_nonzero_owner_360  1
    service_0_22_14  service_visit_def_799  1
    service_0_22_14  free_load_conservation_800  12
    service_0_22_15  unique_nonzero_owner_361  1
    service_0_22_15  service_visit_def_799  1
    service_0_22_15  free_load_conservation_800  13
    service_1_22_0  unique_nonzero_owner_347  1
    service_1_22_0  service_visit_def_1171  1
    service_1_22_0  free_load_conservation_1172  -2
    service_1_22_0  original_T_including_depot_unload_1194  240
    service_1_22_1  unique_nonzero_owner_348  1
    service_1_22_1  service_visit_def_1171  1
    service_1_22_1  free_load_conservation_1172  -1
    service_1_22_1  original_T_including_depot_unload_1194  120
    service_1_22_3  unique_nonzero_owner_349  1
    service_1_22_3  service_visit_def_1171  1
    service_1_22_3  free_load_conservation_1172  1
    service_1_22_4  unique_nonzero_owner_350  1
    service_1_22_4  service_visit_def_1171  1
    service_1_22_4  free_load_conservation_1172  2
    service_1_22_5  unique_nonzero_owner_351  1
    service_1_22_5  service_visit_def_1171  1
    service_1_22_5  free_load_conservation_1172  3
    service_1_22_6  unique_nonzero_owner_352  1
    service_1_22_6  service_visit_def_1171  1
    service_1_22_6  free_load_conservation_1172  4
    service_1_22_7  unique_nonzero_owner_353  1
    service_1_22_7  service_visit_def_1171  1
    service_1_22_7  free_load_conservation_1172  5
    service_1_22_8  unique_nonzero_owner_354  1
    service_1_22_8  service_visit_def_1171  1
    service_1_22_8  free_load_conservation_1172  6
    service_1_22_9  unique_nonzero_owner_355  1
    service_1_22_9  service_visit_def_1171  1
    service_1_22_9  free_load_conservation_1172  7
    service_1_22_10  unique_nonzero_owner_356  1
    service_1_22_10  service_visit_def_1171  1
    service_1_22_10  free_load_conservation_1172  8
    service_1_22_11  unique_nonzero_owner_357  1
    service_1_22_11  service_visit_def_1171  1
    service_1_22_11  free_load_conservation_1172  9
    service_1_22_12  unique_nonzero_owner_358  1
    service_1_22_12  service_visit_def_1171  1
    service_1_22_12  free_load_conservation_1172  10
    service_1_22_13  unique_nonzero_owner_359  1
    service_1_22_13  service_visit_def_1171  1
    service_1_22_13  free_load_conservation_1172  11
    service_1_22_14  unique_nonzero_owner_360  1
    service_1_22_14  service_visit_def_1171  1
    service_1_22_14  free_load_conservation_1172  12
    service_1_22_15  unique_nonzero_owner_361  1
    service_1_22_15  service_visit_def_1171  1
    service_1_22_15  free_load_conservation_1172  13
    service_2_22_0  unique_nonzero_owner_347  1
    service_2_22_0  service_visit_def_1489  1
    service_2_22_0  free_load_conservation_1490  -2
    service_2_22_0  original_T_including_depot_unload_1511  240
    service_2_22_1  unique_nonzero_owner_348  1
    service_2_22_1  service_visit_def_1489  1
    service_2_22_1  free_load_conservation_1490  -1
    service_2_22_1  original_T_including_depot_unload_1511  120
    service_2_22_3  unique_nonzero_owner_349  1
    service_2_22_3  service_visit_def_1489  1
    service_2_22_3  free_load_conservation_1490  1
    service_2_22_4  unique_nonzero_owner_350  1
    service_2_22_4  service_visit_def_1489  1
    service_2_22_4  free_load_conservation_1490  2
    service_2_22_5  unique_nonzero_owner_351  1
    service_2_22_5  service_visit_def_1489  1
    service_2_22_5  free_load_conservation_1490  3
    service_2_22_6  unique_nonzero_owner_352  1
    service_2_22_6  service_visit_def_1489  1
    service_2_22_6  free_load_conservation_1490  4
    service_2_22_7  unique_nonzero_owner_353  1
    service_2_22_7  service_visit_def_1489  1
    service_2_22_7  free_load_conservation_1490  5
    service_2_22_8  unique_nonzero_owner_354  1
    service_2_22_8  service_visit_def_1489  1
    service_2_22_8  free_load_conservation_1490  6
    service_2_22_9  unique_nonzero_owner_355  1
    service_2_22_9  service_visit_def_1489  1
    service_2_22_9  free_load_conservation_1490  7
    service_2_22_10  unique_nonzero_owner_356  1
    service_2_22_10  service_visit_def_1489  1
    service_2_22_10  free_load_conservation_1490  8
    service_2_22_11  unique_nonzero_owner_357  1
    service_2_22_11  service_visit_def_1489  1
    service_2_22_11  free_load_conservation_1490  9
    service_2_22_12  unique_nonzero_owner_358  1
    service_2_22_12  service_visit_def_1489  1
    service_2_22_12  free_load_conservation_1490  10
    service_2_22_13  unique_nonzero_owner_359  1
    service_2_22_13  service_visit_def_1489  1
    service_2_22_13  free_load_conservation_1490  11
    service_2_22_14  unique_nonzero_owner_360  1
    service_2_22_14  service_visit_def_1489  1
    service_2_22_14  free_load_conservation_1490  12
    service_2_22_15  unique_nonzero_owner_361  1
    service_2_22_15  service_visit_def_1489  1
    service_2_22_15  free_load_conservation_1490  13
    service_0_5_0  unique_nonzero_owner_362  1
    service_0_5_0  service_visit_def_805  1
    service_0_5_0  free_load_conservation_806  -1
    service_0_5_0  original_T_including_depot_unload_823  120
    service_0_5_2  unique_nonzero_owner_363  1
    service_0_5_2  service_visit_def_805  1
    service_0_5_2  free_load_conservation_806  1
    service_0_5_3  unique_nonzero_owner_364  1
    service_0_5_3  service_visit_def_805  1
    service_0_5_3  free_load_conservation_806  2
    service_0_5_4  unique_nonzero_owner_365  1
    service_0_5_4  service_visit_def_805  1
    service_0_5_4  free_load_conservation_806  3
    service_0_5_5  unique_nonzero_owner_366  1
    service_0_5_5  service_visit_def_805  1
    service_0_5_5  free_load_conservation_806  4
    service_0_5_6  unique_nonzero_owner_367  1
    service_0_5_6  service_visit_def_805  1
    service_0_5_6  free_load_conservation_806  5
    service_0_5_7  unique_nonzero_owner_368  1
    service_0_5_7  service_visit_def_805  1
    service_0_5_7  free_load_conservation_806  6
    service_0_5_8  unique_nonzero_owner_369  1
    service_0_5_8  service_visit_def_805  1
    service_0_5_8  free_load_conservation_806  7
    service_0_5_9  unique_nonzero_owner_370  1
    service_0_5_9  service_visit_def_805  1
    service_0_5_9  free_load_conservation_806  8
    service_0_5_10  unique_nonzero_owner_371  1
    service_0_5_10  service_visit_def_805  1
    service_0_5_10  free_load_conservation_806  9
    service_0_5_11  unique_nonzero_owner_372  1
    service_0_5_11  service_visit_def_805  1
    service_0_5_11  free_load_conservation_806  10
    service_0_5_12  unique_nonzero_owner_373  1
    service_0_5_12  service_visit_def_805  1
    service_0_5_12  free_load_conservation_806  11
    service_0_5_13  unique_nonzero_owner_374  1
    service_0_5_13  service_visit_def_805  1
    service_0_5_13  free_load_conservation_806  12
    service_0_5_14  unique_nonzero_owner_375  1
    service_0_5_14  service_visit_def_805  1
    service_0_5_14  free_load_conservation_806  13
    service_0_5_15  unique_nonzero_owner_376  1
    service_0_5_15  service_visit_def_805  1
    service_0_5_15  free_load_conservation_806  14
    service_1_5_0  unique_nonzero_owner_362  1
    service_1_5_0  service_visit_def_1177  1
    service_1_5_0  free_load_conservation_1178  -1
    service_1_5_0  original_T_including_depot_unload_1194  120
    service_1_5_2  unique_nonzero_owner_363  1
    service_1_5_2  service_visit_def_1177  1
    service_1_5_2  free_load_conservation_1178  1
    service_1_5_3  unique_nonzero_owner_364  1
    service_1_5_3  service_visit_def_1177  1
    service_1_5_3  free_load_conservation_1178  2
    service_1_5_4  unique_nonzero_owner_365  1
    service_1_5_4  service_visit_def_1177  1
    service_1_5_4  free_load_conservation_1178  3
    service_1_5_5  unique_nonzero_owner_366  1
    service_1_5_5  service_visit_def_1177  1
    service_1_5_5  free_load_conservation_1178  4
    service_1_5_6  unique_nonzero_owner_367  1
    service_1_5_6  service_visit_def_1177  1
    service_1_5_6  free_load_conservation_1178  5
    service_1_5_7  unique_nonzero_owner_368  1
    service_1_5_7  service_visit_def_1177  1
    service_1_5_7  free_load_conservation_1178  6
    service_1_5_8  unique_nonzero_owner_369  1
    service_1_5_8  service_visit_def_1177  1
    service_1_5_8  free_load_conservation_1178  7
    service_1_5_9  unique_nonzero_owner_370  1
    service_1_5_9  service_visit_def_1177  1
    service_1_5_9  free_load_conservation_1178  8
    service_1_5_10  unique_nonzero_owner_371  1
    service_1_5_10  service_visit_def_1177  1
    service_1_5_10  free_load_conservation_1178  9
    service_1_5_11  unique_nonzero_owner_372  1
    service_1_5_11  service_visit_def_1177  1
    service_1_5_11  free_load_conservation_1178  10
    service_1_5_12  unique_nonzero_owner_373  1
    service_1_5_12  service_visit_def_1177  1
    service_1_5_12  free_load_conservation_1178  11
    service_1_5_13  unique_nonzero_owner_374  1
    service_1_5_13  service_visit_def_1177  1
    service_1_5_13  free_load_conservation_1178  12
    service_1_5_14  unique_nonzero_owner_375  1
    service_1_5_14  service_visit_def_1177  1
    service_1_5_14  free_load_conservation_1178  13
    service_1_5_15  unique_nonzero_owner_376  1
    service_1_5_15  service_visit_def_1177  1
    service_1_5_15  free_load_conservation_1178  14
    service_2_5_0  unique_nonzero_owner_362  1
    service_2_5_0  service_visit_def_1495  1
    service_2_5_0  free_load_conservation_1496  -1
    service_2_5_0  original_T_including_depot_unload_1511  120
    service_2_5_2  unique_nonzero_owner_363  1
    service_2_5_2  service_visit_def_1495  1
    service_2_5_2  free_load_conservation_1496  1
    service_2_5_3  unique_nonzero_owner_364  1
    service_2_5_3  service_visit_def_1495  1
    service_2_5_3  free_load_conservation_1496  2
    service_2_5_4  unique_nonzero_owner_365  1
    service_2_5_4  service_visit_def_1495  1
    service_2_5_4  free_load_conservation_1496  3
    service_2_5_5  unique_nonzero_owner_366  1
    service_2_5_5  service_visit_def_1495  1
    service_2_5_5  free_load_conservation_1496  4
    service_2_5_6  unique_nonzero_owner_367  1
    service_2_5_6  service_visit_def_1495  1
    service_2_5_6  free_load_conservation_1496  5
    service_2_5_7  unique_nonzero_owner_368  1
    service_2_5_7  service_visit_def_1495  1
    service_2_5_7  free_load_conservation_1496  6
    service_2_5_8  unique_nonzero_owner_369  1
    service_2_5_8  service_visit_def_1495  1
    service_2_5_8  free_load_conservation_1496  7
    service_2_5_9  unique_nonzero_owner_370  1
    service_2_5_9  service_visit_def_1495  1
    service_2_5_9  free_load_conservation_1496  8
    service_2_5_10  unique_nonzero_owner_371  1
    service_2_5_10  service_visit_def_1495  1
    service_2_5_10  free_load_conservation_1496  9
    service_2_5_11  unique_nonzero_owner_372  1
    service_2_5_11  service_visit_def_1495  1
    service_2_5_11  free_load_conservation_1496  10
    service_2_5_12  unique_nonzero_owner_373  1
    service_2_5_12  service_visit_def_1495  1
    service_2_5_12  free_load_conservation_1496  11
    service_2_5_13  unique_nonzero_owner_374  1
    service_2_5_13  service_visit_def_1495  1
    service_2_5_13  free_load_conservation_1496  12
    service_2_5_14  unique_nonzero_owner_375  1
    service_2_5_14  service_visit_def_1495  1
    service_2_5_14  free_load_conservation_1496  13
    service_2_5_15  unique_nonzero_owner_376  1
    service_2_5_15  service_visit_def_1495  1
    service_2_5_15  free_load_conservation_1496  14
    service_0_27_1  unique_nonzero_owner_377  1
    service_0_27_1  service_visit_def_811  1
    service_0_27_1  free_load_conservation_812  1
    service_0_27_2  unique_nonzero_owner_378  1
    service_0_27_2  service_visit_def_811  1
    service_0_27_2  free_load_conservation_812  2
    service_0_27_3  unique_nonzero_owner_379  1
    service_0_27_3  service_visit_def_811  1
    service_0_27_3  free_load_conservation_812  3
    service_0_27_4  unique_nonzero_owner_380  1
    service_0_27_4  service_visit_def_811  1
    service_0_27_4  free_load_conservation_812  4
    service_0_27_5  unique_nonzero_owner_381  1
    service_0_27_5  service_visit_def_811  1
    service_0_27_5  free_load_conservation_812  5
    service_0_27_6  unique_nonzero_owner_382  1
    service_0_27_6  service_visit_def_811  1
    service_0_27_6  free_load_conservation_812  6
    service_1_27_1  unique_nonzero_owner_377  1
    service_1_27_1  service_visit_def_1183  1
    service_1_27_1  free_load_conservation_1184  1
    service_1_27_2  unique_nonzero_owner_378  1
    service_1_27_2  service_visit_def_1183  1
    service_1_27_2  free_load_conservation_1184  2
    service_1_27_3  unique_nonzero_owner_379  1
    service_1_27_3  service_visit_def_1183  1
    service_1_27_3  free_load_conservation_1184  3
    service_1_27_4  unique_nonzero_owner_380  1
    service_1_27_4  service_visit_def_1183  1
    service_1_27_4  free_load_conservation_1184  4
    service_1_27_5  unique_nonzero_owner_381  1
    service_1_27_5  service_visit_def_1183  1
    service_1_27_5  free_load_conservation_1184  5
    service_1_27_6  unique_nonzero_owner_382  1
    service_1_27_6  service_visit_def_1183  1
    service_1_27_6  free_load_conservation_1184  6
    service_2_27_1  unique_nonzero_owner_377  1
    service_2_27_1  service_visit_def_1501  1
    service_2_27_1  free_load_conservation_1502  1
    service_2_27_2  unique_nonzero_owner_378  1
    service_2_27_2  service_visit_def_1501  1
    service_2_27_2  free_load_conservation_1502  2
    service_2_27_3  unique_nonzero_owner_379  1
    service_2_27_3  service_visit_def_1501  1
    service_2_27_3  free_load_conservation_1502  3
    service_2_27_4  unique_nonzero_owner_380  1
    service_2_27_4  service_visit_def_1501  1
    service_2_27_4  free_load_conservation_1502  4
    service_2_27_5  unique_nonzero_owner_381  1
    service_2_27_5  service_visit_def_1501  1
    service_2_27_5  free_load_conservation_1502  5
    service_2_27_6  unique_nonzero_owner_382  1
    service_2_27_6  service_visit_def_1501  1
    service_2_27_6  free_load_conservation_1502  6
    service_0_8_0  unique_nonzero_owner_383  1
    service_0_8_0  service_visit_def_817  1
    service_0_8_0  free_load_conservation_818  -9
    service_0_8_0  original_T_including_depot_unload_823  1080
    service_0_8_1  unique_nonzero_owner_384  1
    service_0_8_1  service_visit_def_817  1
    service_0_8_1  free_load_conservation_818  -8
    service_0_8_1  original_T_including_depot_unload_823  960
    service_0_8_2  unique_nonzero_owner_385  1
    service_0_8_2  service_visit_def_817  1
    service_0_8_2  free_load_conservation_818  -7
    service_0_8_2  original_T_including_depot_unload_823  840
    service_0_8_3  unique_nonzero_owner_386  1
    service_0_8_3  service_visit_def_817  1
    service_0_8_3  free_load_conservation_818  -6
    service_0_8_3  original_T_including_depot_unload_823  720
    service_0_8_4  unique_nonzero_owner_387  1
    service_0_8_4  service_visit_def_817  1
    service_0_8_4  free_load_conservation_818  -5
    service_0_8_4  original_T_including_depot_unload_823  600
    service_0_8_5  unique_nonzero_owner_388  1
    service_0_8_5  service_visit_def_817  1
    service_0_8_5  free_load_conservation_818  -4
    service_0_8_5  original_T_including_depot_unload_823  480
    service_0_8_6  unique_nonzero_owner_389  1
    service_0_8_6  service_visit_def_817  1
    service_0_8_6  free_load_conservation_818  -3
    service_0_8_6  original_T_including_depot_unload_823  360
    service_0_8_7  unique_nonzero_owner_390  1
    service_0_8_7  service_visit_def_817  1
    service_0_8_7  free_load_conservation_818  -2
    service_0_8_7  original_T_including_depot_unload_823  240
    service_0_8_8  unique_nonzero_owner_391  1
    service_0_8_8  service_visit_def_817  1
    service_0_8_8  free_load_conservation_818  -1
    service_0_8_8  original_T_including_depot_unload_823  120
    service_0_8_10  unique_nonzero_owner_392  1
    service_0_8_10  service_visit_def_817  1
    service_0_8_10  free_load_conservation_818  1
    service_0_8_11  unique_nonzero_owner_393  1
    service_0_8_11  service_visit_def_817  1
    service_0_8_11  free_load_conservation_818  2
    service_0_8_12  unique_nonzero_owner_394  1
    service_0_8_12  service_visit_def_817  1
    service_0_8_12  free_load_conservation_818  3
    service_1_8_0  unique_nonzero_owner_383  1
    service_1_8_0  service_visit_def_1189  1
    service_1_8_0  free_load_conservation_1190  -9
    service_1_8_0  original_T_including_depot_unload_1194  1080
    service_1_8_1  unique_nonzero_owner_384  1
    service_1_8_1  service_visit_def_1189  1
    service_1_8_1  free_load_conservation_1190  -8
    service_1_8_1  original_T_including_depot_unload_1194  960
    service_1_8_2  unique_nonzero_owner_385  1
    service_1_8_2  service_visit_def_1189  1
    service_1_8_2  free_load_conservation_1190  -7
    service_1_8_2  original_T_including_depot_unload_1194  840
    service_1_8_3  unique_nonzero_owner_386  1
    service_1_8_3  service_visit_def_1189  1
    service_1_8_3  free_load_conservation_1190  -6
    service_1_8_3  original_T_including_depot_unload_1194  720
    service_1_8_4  unique_nonzero_owner_387  1
    service_1_8_4  service_visit_def_1189  1
    service_1_8_4  free_load_conservation_1190  -5
    service_1_8_4  original_T_including_depot_unload_1194  600
    service_1_8_5  unique_nonzero_owner_388  1
    service_1_8_5  service_visit_def_1189  1
    service_1_8_5  free_load_conservation_1190  -4
    service_1_8_5  original_T_including_depot_unload_1194  480
    service_1_8_6  unique_nonzero_owner_389  1
    service_1_8_6  service_visit_def_1189  1
    service_1_8_6  free_load_conservation_1190  -3
    service_1_8_6  original_T_including_depot_unload_1194  360
    service_1_8_7  unique_nonzero_owner_390  1
    service_1_8_7  service_visit_def_1189  1
    service_1_8_7  free_load_conservation_1190  -2
    service_1_8_7  original_T_including_depot_unload_1194  240
    service_1_8_8  unique_nonzero_owner_391  1
    service_1_8_8  service_visit_def_1189  1
    service_1_8_8  free_load_conservation_1190  -1
    service_1_8_8  original_T_including_depot_unload_1194  120
    service_1_8_10  unique_nonzero_owner_392  1
    service_1_8_10  service_visit_def_1189  1
    service_1_8_10  free_load_conservation_1190  1
    service_1_8_11  unique_nonzero_owner_393  1
    service_1_8_11  service_visit_def_1189  1
    service_1_8_11  free_load_conservation_1190  2
    service_1_8_12  unique_nonzero_owner_394  1
    service_1_8_12  service_visit_def_1189  1
    service_1_8_12  free_load_conservation_1190  3
    service_2_8_0  unique_nonzero_owner_383  1
    service_2_8_0  service_visit_def_1507  1
    service_2_8_0  free_load_conservation_1508  -9
    service_2_8_0  original_T_including_depot_unload_1511  1080
    service_2_8_1  unique_nonzero_owner_384  1
    service_2_8_1  service_visit_def_1507  1
    service_2_8_1  free_load_conservation_1508  -8
    service_2_8_1  original_T_including_depot_unload_1511  960
    service_2_8_2  unique_nonzero_owner_385  1
    service_2_8_2  service_visit_def_1507  1
    service_2_8_2  free_load_conservation_1508  -7
    service_2_8_2  original_T_including_depot_unload_1511  840
    service_2_8_3  unique_nonzero_owner_386  1
    service_2_8_3  service_visit_def_1507  1
    service_2_8_3  free_load_conservation_1508  -6
    service_2_8_3  original_T_including_depot_unload_1511  720
    service_2_8_4  unique_nonzero_owner_387  1
    service_2_8_4  service_visit_def_1507  1
    service_2_8_4  free_load_conservation_1508  -5
    service_2_8_4  original_T_including_depot_unload_1511  600
    service_2_8_5  unique_nonzero_owner_388  1
    service_2_8_5  service_visit_def_1507  1
    service_2_8_5  free_load_conservation_1508  -4
    service_2_8_5  original_T_including_depot_unload_1511  480
    service_2_8_6  unique_nonzero_owner_389  1
    service_2_8_6  service_visit_def_1507  1
    service_2_8_6  free_load_conservation_1508  -3
    service_2_8_6  original_T_including_depot_unload_1511  360
    service_2_8_7  unique_nonzero_owner_390  1
    service_2_8_7  service_visit_def_1507  1
    service_2_8_7  free_load_conservation_1508  -2
    service_2_8_7  original_T_including_depot_unload_1511  240
    service_2_8_8  unique_nonzero_owner_391  1
    service_2_8_8  service_visit_def_1507  1
    service_2_8_8  free_load_conservation_1508  -1
    service_2_8_8  original_T_including_depot_unload_1511  120
    service_2_8_10  unique_nonzero_owner_392  1
    service_2_8_10  service_visit_def_1507  1
    service_2_8_10  free_load_conservation_1508  1
    service_2_8_11  unique_nonzero_owner_393  1
    service_2_8_11  service_visit_def_1507  1
    service_2_8_11  free_load_conservation_1508  2
    service_2_8_12  unique_nonzero_owner_394  1
    service_2_8_12  service_visit_def_1507  1
    service_2_8_12  free_load_conservation_1508  3
    MARKER    'MARKER'                 'INTEND'
    visit_0_1  out_degree_736  -1
    visit_0_1  in_degree_737  -1
    visit_0_1  order_active_lb_738  -1
    visit_0_1  order_active_ub_739  -13
    order_0_1  connected_order_arc_411  -1
    order_0_1  connected_order_arc_413  -1
    order_0_1  connected_order_arc_415  -1
    order_0_1  connected_order_arc_417  -1
    order_0_1  connected_order_arc_419  -1
    order_0_1  connected_order_arc_421  -1
    order_0_1  connected_order_arc_423  -1
    order_0_1  connected_order_arc_425  -1
    order_0_1  connected_order_arc_427  -1
    order_0_1  connected_order_arc_429  -1
    order_0_1  connected_order_arc_431  -1
    order_0_1  connected_order_arc_433  -1
    order_0_1  connected_order_arc_436  1
    order_0_1  connected_order_arc_461  1
    order_0_1  connected_order_arc_486  1
    order_0_1  connected_order_arc_511  1
    order_0_1  connected_order_arc_536  1
    order_0_1  connected_order_arc_561  1
    order_0_1  connected_order_arc_586  1
    order_0_1  connected_order_arc_611  1
    order_0_1  connected_order_arc_636  1
    order_0_1  connected_order_arc_661  1
    order_0_1  connected_order_arc_686  1
    order_0_1  connected_order_arc_711  1
    order_0_1  order_active_lb_738  1
    order_0_1  order_active_ub_739  1
    order_0_1  fixed_segment_relative_order_819  -1
    visit_0_2  out_degree_743  -1
    visit_0_2  in_degree_744  -1
    visit_0_2  order_active_lb_745  -1
    visit_0_2  order_active_ub_746  -13
    order_0_2  connected_order_arc_411  1
    order_0_2  connected_order_arc_436  -1
    order_0_2  connected_order_arc_438  -1
    order_0_2  connected_order_arc_440  -1
    order_0_2  connected_order_arc_442  -1
    order_0_2  connected_order_arc_444  -1
    order_0_2  connected_order_arc_446  -1
    order_0_2  connected_order_arc_448  -1
    order_0_2  connected_order_arc_450  -1
    order_0_2  connected_order_arc_452  -1
    order_0_2  connected_order_arc_454  -1
    order_0_2  connected_order_arc_456  -1
    order_0_2  connected_order_arc_458  -1
    order_0_2  connected_order_arc_463  1
    order_0_2  connected_order_arc_488  1
    order_0_2  connected_order_arc_513  1
    order_0_2  connected_order_arc_538  1
    order_0_2  connected_order_arc_563  1
    order_0_2  connected_order_arc_588  1
    order_0_2  connected_order_arc_613  1
    order_0_2  connected_order_arc_638  1
    order_0_2  connected_order_arc_663  1
    order_0_2  connected_order_arc_688  1
    order_0_2  connected_order_arc_713  1
    order_0_2  order_active_lb_745  1
    order_0_2  order_active_ub_746  1
    order_0_2  fixed_segment_relative_order_819  1
    order_0_2  fixed_segment_relative_order_820  -1
    visit_0_3  out_degree_750  -1
    visit_0_3  in_degree_751  -1
    visit_0_3  order_active_lb_752  -1
    visit_0_3  order_active_ub_753  -13
    order_0_3  connected_order_arc_413  1
    order_0_3  connected_order_arc_438  1
    order_0_3  connected_order_arc_461  -1
    order_0_3  connected_order_arc_463  -1
    order_0_3  connected_order_arc_465  -1
    order_0_3  connected_order_arc_467  -1
    order_0_3  connected_order_arc_469  -1
    order_0_3  connected_order_arc_471  -1
    order_0_3  connected_order_arc_473  -1
    order_0_3  connected_order_arc_475  -1
    order_0_3  connected_order_arc_477  -1
    order_0_3  connected_order_arc_479  -1
    order_0_3  connected_order_arc_481  -1
    order_0_3  connected_order_arc_483  -1
    order_0_3  connected_order_arc_490  1
    order_0_3  connected_order_arc_515  1
    order_0_3  connected_order_arc_540  1
    order_0_3  connected_order_arc_565  1
    order_0_3  connected_order_arc_590  1
    order_0_3  connected_order_arc_615  1
    order_0_3  connected_order_arc_640  1
    order_0_3  connected_order_arc_665  1
    order_0_3  connected_order_arc_690  1
    order_0_3  connected_order_arc_715  1
    order_0_3  order_active_lb_752  1
    order_0_3  order_active_ub_753  1
    order_0_3  fixed_segment_relative_order_820  1
    order_0_3  fixed_segment_relative_order_821  -1
    visit_0_4  out_degree_757  -1
    visit_0_4  in_degree_758  -1
    visit_0_4  order_active_lb_759  -1
    visit_0_4  order_active_ub_760  -13
    order_0_4  connected_order_arc_415  1
    order_0_4  connected_order_arc_440  1
    order_0_4  connected_order_arc_465  1
    order_0_4  connected_order_arc_486  -1
    order_0_4  connected_order_arc_488  -1
    order_0_4  connected_order_arc_490  -1
    order_0_4  connected_order_arc_492  -1
    order_0_4  connected_order_arc_494  -1
    order_0_4  connected_order_arc_496  -1
    order_0_4  connected_order_arc_498  -1
    order_0_4  connected_order_arc_500  -1
    order_0_4  connected_order_arc_502  -1
    order_0_4  connected_order_arc_504  -1
    order_0_4  connected_order_arc_506  -1
    order_0_4  connected_order_arc_508  -1
    order_0_4  connected_order_arc_517  1
    order_0_4  connected_order_arc_542  1
    order_0_4  connected_order_arc_567  1
    order_0_4  connected_order_arc_592  1
    order_0_4  connected_order_arc_617  1
    order_0_4  connected_order_arc_642  1
    order_0_4  connected_order_arc_667  1
    order_0_4  connected_order_arc_692  1
    order_0_4  connected_order_arc_717  1
    order_0_4  order_active_lb_759  1
    order_0_4  order_active_ub_760  1
    order_0_4  fixed_segment_relative_order_821  1
    order_0_4  fixed_segment_relative_order_822  -1
    visit_0_5  out_degree_764  -1
    visit_0_5  in_degree_765  -1
    visit_0_5  order_active_lb_766  -1
    visit_0_5  order_active_ub_767  -13
    order_0_5  connected_order_arc_417  1
    order_0_5  connected_order_arc_442  1
    order_0_5  connected_order_arc_467  1
    order_0_5  connected_order_arc_492  1
    order_0_5  connected_order_arc_511  -1
    order_0_5  connected_order_arc_513  -1
    order_0_5  connected_order_arc_515  -1
    order_0_5  connected_order_arc_517  -1
    order_0_5  connected_order_arc_519  -1
    order_0_5  connected_order_arc_521  -1
    order_0_5  connected_order_arc_523  -1
    order_0_5  connected_order_arc_525  -1
    order_0_5  connected_order_arc_527  -1
    order_0_5  connected_order_arc_529  -1
    order_0_5  connected_order_arc_531  -1
    order_0_5  connected_order_arc_533  -1
    order_0_5  connected_order_arc_544  1
    order_0_5  connected_order_arc_569  1
    order_0_5  connected_order_arc_594  1
    order_0_5  connected_order_arc_619  1
    order_0_5  connected_order_arc_644  1
    order_0_5  connected_order_arc_669  1
    order_0_5  connected_order_arc_694  1
    order_0_5  connected_order_arc_719  1
    order_0_5  order_active_lb_766  1
    order_0_5  order_active_ub_767  1
    order_0_5  fixed_segment_relative_order_822  1
    visit_0_13  out_degree_771  -1
    visit_0_13  in_degree_772  -1
    visit_0_13  order_active_lb_773  -1
    visit_0_13  order_active_ub_774  -13
    visit_0_13  service_visit_def_775  -1
    order_0_13  connected_order_arc_419  1
    order_0_13  connected_order_arc_444  1
    order_0_13  connected_order_arc_469  1
    order_0_13  connected_order_arc_494  1
    order_0_13  connected_order_arc_519  1
    order_0_13  connected_order_arc_536  -1
    order_0_13  connected_order_arc_538  -1
    order_0_13  connected_order_arc_540  -1
    order_0_13  connected_order_arc_542  -1
    order_0_13  connected_order_arc_544  -1
    order_0_13  connected_order_arc_546  -1
    order_0_13  connected_order_arc_548  -1
    order_0_13  connected_order_arc_550  -1
    order_0_13  connected_order_arc_552  -1
    order_0_13  connected_order_arc_554  -1
    order_0_13  connected_order_arc_556  -1
    order_0_13  connected_order_arc_558  -1
    order_0_13  connected_order_arc_571  1
    order_0_13  connected_order_arc_596  1
    order_0_13  connected_order_arc_621  1
    order_0_13  connected_order_arc_646  1
    order_0_13  connected_order_arc_671  1
    order_0_13  connected_order_arc_696  1
    order_0_13  connected_order_arc_721  1
    order_0_13  order_active_lb_773  1
    order_0_13  order_active_ub_774  1
    visit_0_14  out_degree_777  -1
    visit_0_14  in_degree_778  -1
    visit_0_14  order_active_lb_779  -1
    visit_0_14  order_active_ub_780  -13
    visit_0_14  service_visit_def_781  -1
    order_0_14  connected_order_arc_421  1
    order_0_14  connected_order_arc_446  1
    order_0_14  connected_order_arc_471  1
    order_0_14  connected_order_arc_496  1
    order_0_14  connected_order_arc_521  1
    order_0_14  connected_order_arc_546  1
    order_0_14  connected_order_arc_561  -1
    order_0_14  connected_order_arc_563  -1
    order_0_14  connected_order_arc_565  -1
    order_0_14  connected_order_arc_567  -1
    order_0_14  connected_order_arc_569  -1
    order_0_14  connected_order_arc_571  -1
    order_0_14  connected_order_arc_573  -1
    order_0_14  connected_order_arc_575  -1
    order_0_14  connected_order_arc_577  -1
    order_0_14  connected_order_arc_579  -1
    order_0_14  connected_order_arc_581  -1
    order_0_14  connected_order_arc_583  -1
    order_0_14  connected_order_arc_598  1
    order_0_14  connected_order_arc_623  1
    order_0_14  connected_order_arc_648  1
    order_0_14  connected_order_arc_673  1
    order_0_14  connected_order_arc_698  1
    order_0_14  connected_order_arc_723  1
    order_0_14  order_active_lb_779  1
    order_0_14  order_active_ub_780  1
    visit_0_15  out_degree_783  -1
    visit_0_15  in_degree_784  -1
    visit_0_15  order_active_lb_785  -1
    visit_0_15  order_active_ub_786  -13
    visit_0_15  service_visit_def_787  -1
    order_0_15  connected_order_arc_423  1
    order_0_15  connected_order_arc_448  1
    order_0_15  connected_order_arc_473  1
    order_0_15  connected_order_arc_498  1
    order_0_15  connected_order_arc_523  1
    order_0_15  connected_order_arc_548  1
    order_0_15  connected_order_arc_573  1
    order_0_15  connected_order_arc_586  -1
    order_0_15  connected_order_arc_588  -1
    order_0_15  connected_order_arc_590  -1
    order_0_15  connected_order_arc_592  -1
    order_0_15  connected_order_arc_594  -1
    order_0_15  connected_order_arc_596  -1
    order_0_15  connected_order_arc_598  -1
    order_0_15  connected_order_arc_600  -1
    order_0_15  connected_order_arc_602  -1
    order_0_15  connected_order_arc_604  -1
    order_0_15  connected_order_arc_606  -1
    order_0_15  connected_order_arc_608  -1
    order_0_15  connected_order_arc_625  1
    order_0_15  connected_order_arc_650  1
    order_0_15  connected_order_arc_675  1
    order_0_15  connected_order_arc_700  1
    order_0_15  connected_order_arc_725  1
    order_0_15  order_active_lb_785  1
    order_0_15  order_active_ub_786  1
    visit_0_16  out_degree_789  -1
    visit_0_16  in_degree_790  -1
    visit_0_16  order_active_lb_791  -1
    visit_0_16  order_active_ub_792  -13
    visit_0_16  service_visit_def_793  -1
    order_0_16  connected_order_arc_425  1
    order_0_16  connected_order_arc_450  1
    order_0_16  connected_order_arc_475  1
    order_0_16  connected_order_arc_500  1
    order_0_16  connected_order_arc_525  1
    order_0_16  connected_order_arc_550  1
    order_0_16  connected_order_arc_575  1
    order_0_16  connected_order_arc_600  1
    order_0_16  connected_order_arc_611  -1
    order_0_16  connected_order_arc_613  -1
    order_0_16  connected_order_arc_615  -1
    order_0_16  connected_order_arc_617  -1
    order_0_16  connected_order_arc_619  -1
    order_0_16  connected_order_arc_621  -1
    order_0_16  connected_order_arc_623  -1
    order_0_16  connected_order_arc_625  -1
    order_0_16  connected_order_arc_627  -1
    order_0_16  connected_order_arc_629  -1
    order_0_16  connected_order_arc_631  -1
    order_0_16  connected_order_arc_633  -1
    order_0_16  connected_order_arc_652  1
    order_0_16  connected_order_arc_677  1
    order_0_16  connected_order_arc_702  1
    order_0_16  connected_order_arc_727  1
    order_0_16  order_active_lb_791  1
    order_0_16  order_active_ub_792  1
    visit_0_17  out_degree_795  -1
    visit_0_17  in_degree_796  -1
    visit_0_17  order_active_lb_797  -1
    visit_0_17  order_active_ub_798  -13
    visit_0_17  service_visit_def_799  -1
    order_0_17  connected_order_arc_427  1
    order_0_17  connected_order_arc_452  1
    order_0_17  connected_order_arc_477  1
    order_0_17  connected_order_arc_502  1
    order_0_17  connected_order_arc_527  1
    order_0_17  connected_order_arc_552  1
    order_0_17  connected_order_arc_577  1
    order_0_17  connected_order_arc_602  1
    order_0_17  connected_order_arc_627  1
    order_0_17  connected_order_arc_636  -1
    order_0_17  connected_order_arc_638  -1
    order_0_17  connected_order_arc_640  -1
    order_0_17  connected_order_arc_642  -1
    order_0_17  connected_order_arc_644  -1
    order_0_17  connected_order_arc_646  -1
    order_0_17  connected_order_arc_648  -1
    order_0_17  connected_order_arc_650  -1
    order_0_17  connected_order_arc_652  -1
    order_0_17  connected_order_arc_654  -1
    order_0_17  connected_order_arc_656  -1
    order_0_17  connected_order_arc_658  -1
    order_0_17  connected_order_arc_679  1
    order_0_17  connected_order_arc_704  1
    order_0_17  connected_order_arc_729  1
    order_0_17  order_active_lb_797  1
    order_0_17  order_active_ub_798  1
    visit_0_18  out_degree_801  -1
    visit_0_18  in_degree_802  -1
    visit_0_18  order_active_lb_803  -1
    visit_0_18  order_active_ub_804  -13
    visit_0_18  service_visit_def_805  -1
    order_0_18  connected_order_arc_429  1
    order_0_18  connected_order_arc_454  1
    order_0_18  connected_order_arc_479  1
    order_0_18  connected_order_arc_504  1
    order_0_18  connected_order_arc_529  1
    order_0_18  connected_order_arc_554  1
    order_0_18  connected_order_arc_579  1
    order_0_18  connected_order_arc_604  1
    order_0_18  connected_order_arc_629  1
    order_0_18  connected_order_arc_654  1
    order_0_18  connected_order_arc_661  -1
    order_0_18  connected_order_arc_663  -1
    order_0_18  connected_order_arc_665  -1
    order_0_18  connected_order_arc_667  -1
    order_0_18  connected_order_arc_669  -1
    order_0_18  connected_order_arc_671  -1
    order_0_18  connected_order_arc_673  -1
    order_0_18  connected_order_arc_675  -1
    order_0_18  connected_order_arc_677  -1
    order_0_18  connected_order_arc_679  -1
    order_0_18  connected_order_arc_681  -1
    order_0_18  connected_order_arc_683  -1
    order_0_18  connected_order_arc_706  1
    order_0_18  connected_order_arc_731  1
    order_0_18  order_active_lb_803  1
    order_0_18  order_active_ub_804  1
    visit_0_19  out_degree_807  -1
    visit_0_19  in_degree_808  -1
    visit_0_19  order_active_lb_809  -1
    visit_0_19  order_active_ub_810  -13
    visit_0_19  service_visit_def_811  -1
    order_0_19  connected_order_arc_431  1
    order_0_19  connected_order_arc_456  1
    order_0_19  connected_order_arc_481  1
    order_0_19  connected_order_arc_506  1
    order_0_19  connected_order_arc_531  1
    order_0_19  connected_order_arc_556  1
    order_0_19  connected_order_arc_581  1
    order_0_19  connected_order_arc_606  1
    order_0_19  connected_order_arc_631  1
    order_0_19  connected_order_arc_656  1
    order_0_19  connected_order_arc_681  1
    order_0_19  connected_order_arc_686  -1
    order_0_19  connected_order_arc_688  -1
    order_0_19  connected_order_arc_690  -1
    order_0_19  connected_order_arc_692  -1
    order_0_19  connected_order_arc_694  -1
    order_0_19  connected_order_arc_696  -1
    order_0_19  connected_order_arc_698  -1
    order_0_19  connected_order_arc_700  -1
    order_0_19  connected_order_arc_702  -1
    order_0_19  connected_order_arc_704  -1
    order_0_19  connected_order_arc_706  -1
    order_0_19  connected_order_arc_708  -1
    order_0_19  connected_order_arc_733  1
    order_0_19  order_active_lb_809  1
    order_0_19  order_active_ub_810  1
    visit_0_20  out_degree_813  -1
    visit_0_20  in_degree_814  -1
    visit_0_20  order_active_lb_815  -1
    visit_0_20  order_active_ub_816  -13
    visit_0_20  service_visit_def_817  -1
    order_0_20  connected_order_arc_433  1
    order_0_20  connected_order_arc_458  1
    order_0_20  connected_order_arc_483  1
    order_0_20  connected_order_arc_508  1
    order_0_20  connected_order_arc_533  1
    order_0_20  connected_order_arc_558  1
    order_0_20  connected_order_arc_583  1
    order_0_20  connected_order_arc_608  1
    order_0_20  connected_order_arc_633  1
    order_0_20  connected_order_arc_658  1
    order_0_20  connected_order_arc_683  1
    order_0_20  connected_order_arc_708  1
    order_0_20  connected_order_arc_711  -1
    order_0_20  connected_order_arc_713  -1
    order_0_20  connected_order_arc_715  -1
    order_0_20  connected_order_arc_717  -1
    order_0_20  connected_order_arc_719  -1
    order_0_20  connected_order_arc_721  -1
    order_0_20  connected_order_arc_723  -1
    order_0_20  connected_order_arc_725  -1
    order_0_20  connected_order_arc_727  -1
    order_0_20  connected_order_arc_729  -1
    order_0_20  connected_order_arc_731  -1
    order_0_20  connected_order_arc_733  -1
    order_0_20  order_active_lb_815  1
    order_0_20  order_active_ub_816  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_0  arc_capacity_395  -20
    arc_0_0_0  depot_departure_or_bypass_734  1
    arc_0_0_0  depot_return_or_bypass_735  1
    MARKER    'MARKER'                 'INTEND'
    load_0_0_0  arc_capacity_395  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_1  arc_capacity_396  -20
    arc_0_0_1  depot_departure_or_bypass_734  1
    arc_0_0_1  in_degree_737  1
    arc_0_0_1  original_T_including_depot_unload_823  6.2851955830851955e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_1  arc_capacity_396  1
    load_0_0_1  segment_load_conservation_740  -1
    load_0_0_1  segment_prefix_lb_741  1
    load_0_0_1  segment_prefix_ub_742  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_2  arc_capacity_397  -20
    arc_0_0_2  depot_departure_or_bypass_734  1
    arc_0_0_2  in_degree_744  1
    arc_0_0_2  original_T_including_depot_unload_823  6.2904707403788154e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_2  arc_capacity_397  1
    load_0_0_2  segment_load_conservation_747  -1
    load_0_0_2  segment_prefix_lb_748  1
    load_0_0_2  segment_prefix_ub_749  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_3  arc_capacity_398  -20
    arc_0_0_3  depot_departure_or_bypass_734  1
    arc_0_0_3  in_degree_751  1
    arc_0_0_3  original_T_including_depot_unload_823  8.9725048283911053e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_3  arc_capacity_398  1
    load_0_0_3  segment_load_conservation_754  -1
    load_0_0_3  segment_prefix_lb_755  1
    load_0_0_3  segment_prefix_ub_756  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_4  arc_capacity_399  -20
    arc_0_0_4  depot_departure_or_bypass_734  1
    arc_0_0_4  in_degree_758  1
    arc_0_0_4  original_T_including_depot_unload_823  6.4256529461228865e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_4  arc_capacity_399  1
    load_0_0_4  segment_load_conservation_761  -1
    load_0_0_4  segment_prefix_lb_762  1
    load_0_0_4  segment_prefix_ub_763  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_5  arc_capacity_400  -20
    arc_0_0_5  depot_departure_or_bypass_734  1
    arc_0_0_5  in_degree_765  1
    arc_0_0_5  original_T_including_depot_unload_823  5.2273830510106120e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_5  arc_capacity_400  1
    load_0_0_5  segment_load_conservation_768  -1
    load_0_0_5  segment_prefix_lb_769  1
    load_0_0_5  segment_prefix_ub_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_13  arc_capacity_401  -20
    arc_0_0_13  depot_departure_or_bypass_734  1
    arc_0_0_13  in_degree_772  1
    arc_0_0_13  original_T_including_depot_unload_823  1.1055042743585939e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_13  arc_capacity_401  1
    load_0_0_13  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_14  arc_capacity_402  -20
    arc_0_0_14  depot_departure_or_bypass_734  1
    arc_0_0_14  in_degree_778  1
    arc_0_0_14  original_T_including_depot_unload_823  885.819758595088
    MARKER    'MARKER'                 'INTEND'
    load_0_0_14  arc_capacity_402  1
    load_0_0_14  free_load_conservation_782  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_15  arc_capacity_403  -20
    arc_0_0_15  depot_departure_or_bypass_734  1
    arc_0_0_15  in_degree_784  1
    arc_0_0_15  original_T_including_depot_unload_823  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_15  arc_capacity_403  1
    load_0_0_15  free_load_conservation_788  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_16  arc_capacity_404  -20
    arc_0_0_16  depot_departure_or_bypass_734  1
    arc_0_0_16  in_degree_790  1
    arc_0_0_16  original_T_including_depot_unload_823  1163.36883938708
    MARKER    'MARKER'                 'INTEND'
    load_0_0_16  arc_capacity_404  1
    load_0_0_16  free_load_conservation_794  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_17  arc_capacity_405  -20
    arc_0_0_17  depot_departure_or_bypass_734  1
    arc_0_0_17  in_degree_796  1
    arc_0_0_17  original_T_including_depot_unload_823  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_17  arc_capacity_405  1
    load_0_0_17  free_load_conservation_800  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_18  arc_capacity_406  -20
    arc_0_0_18  depot_departure_or_bypass_734  1
    arc_0_0_18  in_degree_802  1
    arc_0_0_18  original_T_including_depot_unload_823  9.1137190274562636e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_18  arc_capacity_406  1
    load_0_0_18  free_load_conservation_806  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_19  arc_capacity_407  -20
    arc_0_0_19  depot_departure_or_bypass_734  1
    arc_0_0_19  in_degree_808  1
    arc_0_0_19  original_T_including_depot_unload_823  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_19  arc_capacity_407  1
    load_0_0_19  free_load_conservation_812  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_20  arc_capacity_408  -20
    arc_0_0_20  depot_departure_or_bypass_734  1
    arc_0_0_20  in_degree_814  1
    arc_0_0_20  original_T_including_depot_unload_823  7.8199183337763486e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_20  arc_capacity_408  1
    load_0_0_20  free_load_conservation_818  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_0  arc_capacity_409  -20
    arc_0_1_0  depot_return_or_bypass_735  1
    arc_0_1_0  out_degree_736  1
    arc_0_1_0  original_T_including_depot_unload_823  6.2851955830851955e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_0  arc_capacity_409  1
    load_0_1_0  segment_load_conservation_740  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_2  arc_capacity_410  -20
    arc_0_1_2  connected_order_arc_411  -14
    arc_0_1_2  out_degree_736  1
    arc_0_1_2  in_degree_744  1
    arc_0_1_2  original_T_including_depot_unload_823  6.1926694994249909e-01
    MARKER    'MARKER'                 'INTEND'
    load_0_1_2  arc_capacity_410  1
    load_0_1_2  segment_load_conservation_740  1
    load_0_1_2  segment_load_conservation_747  -1
    load_0_1_2  segment_prefix_lb_748  1
    load_0_1_2  segment_prefix_ub_749  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_3  arc_capacity_412  -20
    arc_0_1_3  connected_order_arc_413  -14
    arc_0_1_3  out_degree_736  1
    arc_0_1_3  in_degree_751  1
    arc_0_1_3  original_T_including_depot_unload_823  4.3127471875854752e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_3  arc_capacity_412  1
    load_0_1_3  segment_load_conservation_740  1
    load_0_1_3  segment_load_conservation_754  -1
    load_0_1_3  segment_prefix_lb_755  1
    load_0_1_3  segment_prefix_ub_756  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_4  arc_capacity_414  -20
    arc_0_1_4  connected_order_arc_415  -14
    arc_0_1_4  out_degree_736  1
    arc_0_1_4  in_degree_758  1
    arc_0_1_4  original_T_including_depot_unload_823  3.5317482243205085e+01
    MARKER    'MARKER'                 'INTEND'
    load_0_1_4  arc_capacity_414  1
    load_0_1_4  segment_load_conservation_740  1
    load_0_1_4  segment_load_conservation_761  -1
    load_0_1_4  segment_prefix_lb_762  1
    load_0_1_4  segment_prefix_ub_763  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_5  arc_capacity_416  -20
    arc_0_1_5  connected_order_arc_417  -14
    arc_0_1_5  out_degree_736  1
    arc_0_1_5  in_degree_765  1
    arc_0_1_5  original_T_including_depot_unload_823  1.3146996282072985e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_5  arc_capacity_416  1
    load_0_1_5  segment_load_conservation_740  1
    load_0_1_5  segment_load_conservation_768  -1
    load_0_1_5  segment_prefix_lb_769  1
    load_0_1_5  segment_prefix_ub_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_13  arc_capacity_418  -20
    arc_0_1_13  connected_order_arc_419  -14
    arc_0_1_13  out_degree_736  1
    arc_0_1_13  in_degree_772  1
    arc_0_1_13  original_T_including_depot_unload_823  4.8268503899521744e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_13  arc_capacity_418  1
    load_0_1_13  segment_load_conservation_740  1
    load_0_1_13  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_14  arc_capacity_420  -20
    arc_0_1_14  connected_order_arc_421  -14
    arc_0_1_14  out_degree_736  1
    arc_0_1_14  in_degree_778  1
    arc_0_1_14  original_T_including_depot_unload_823  2.6477572380586179e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_14  arc_capacity_420  1
    load_0_1_14  segment_load_conservation_740  1
    load_0_1_14  free_load_conservation_782  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_15  arc_capacity_422  -20
    arc_0_1_15  connected_order_arc_423  -14
    arc_0_1_15  out_degree_736  1
    arc_0_1_15  in_degree_784  1
    arc_0_1_15  original_T_including_depot_unload_823  2.0832214111784192e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_15  arc_capacity_422  1
    load_0_1_15  segment_load_conservation_740  1
    load_0_1_15  free_load_conservation_788  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_16  arc_capacity_424  -20
    arc_0_1_16  connected_order_arc_425  -14
    arc_0_1_16  out_degree_736  1
    arc_0_1_16  in_degree_790  1
    arc_0_1_16  original_T_including_depot_unload_823  5.9232553492869590e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_16  arc_capacity_424  1
    load_0_1_16  segment_load_conservation_740  1
    load_0_1_16  free_load_conservation_794  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_17  arc_capacity_426  -20
    arc_0_1_17  connected_order_arc_427  -14
    arc_0_1_17  out_degree_736  1
    arc_0_1_17  in_degree_796  1
    arc_0_1_17  original_T_including_depot_unload_823  1.0660093540264595e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_17  arc_capacity_426  1
    load_0_1_17  segment_load_conservation_740  1
    load_0_1_17  free_load_conservation_800  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_18  arc_capacity_428  -20
    arc_0_1_18  connected_order_arc_429  -14
    arc_0_1_18  out_degree_736  1
    arc_0_1_18  in_degree_802  1
    arc_0_1_18  original_T_including_depot_unload_823  3.7143421209022068e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_18  arc_capacity_428  1
    load_0_1_18  segment_load_conservation_740  1
    load_0_1_18  free_load_conservation_806  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_19  arc_capacity_430  -20
    arc_0_1_19  connected_order_arc_431  -14
    arc_0_1_19  out_degree_736  1
    arc_0_1_19  in_degree_808  1
    arc_0_1_19  original_T_including_depot_unload_823  1.4482979064849126e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_19  arc_capacity_430  1
    load_0_1_19  segment_load_conservation_740  1
    load_0_1_19  free_load_conservation_812  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_20  arc_capacity_432  -20
    arc_0_1_20  connected_order_arc_433  -14
    arc_0_1_20  out_degree_736  1
    arc_0_1_20  in_degree_814  1
    arc_0_1_20  original_T_including_depot_unload_823  1.5518157315724611e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_20  arc_capacity_432  1
    load_0_1_20  segment_load_conservation_740  1
    load_0_1_20  free_load_conservation_818  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_0  arc_capacity_434  -20
    arc_0_2_0  depot_return_or_bypass_735  1
    arc_0_2_0  out_degree_743  1
    arc_0_2_0  original_T_including_depot_unload_823  6.2904707403788154e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_0  arc_capacity_434  1
    load_0_2_0  segment_load_conservation_747  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_1  arc_capacity_435  -20
    arc_0_2_1  connected_order_arc_436  -14
    arc_0_2_1  in_degree_737  1
    arc_0_2_1  out_degree_743  1
    arc_0_2_1  original_T_including_depot_unload_823  6.1926694994249909e-01
    MARKER    'MARKER'                 'INTEND'
    load_0_2_1  arc_capacity_435  1
    load_0_2_1  segment_load_conservation_740  -1
    load_0_2_1  segment_prefix_lb_741  1
    load_0_2_1  segment_prefix_ub_742  1
    load_0_2_1  segment_load_conservation_747  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_3  arc_capacity_437  -20
    arc_0_2_3  connected_order_arc_438  -14
    arc_0_2_3  out_degree_743  1
    arc_0_2_3  in_degree_751  1
    arc_0_2_3  original_T_including_depot_unload_823  4.3076139952356033e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_3  arc_capacity_437  1
    load_0_2_3  segment_load_conservation_747  1
    load_0_2_3  segment_load_conservation_754  -1
    load_0_2_3  segment_prefix_lb_755  1
    load_0_2_3  segment_prefix_ub_756  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_4  arc_capacity_439  -20
    arc_0_2_4  connected_order_arc_440  -14
    arc_0_2_4  out_degree_743  1
    arc_0_2_4  in_degree_758  1
    arc_0_2_4  original_T_including_depot_unload_823  3.5426413058949414e+01
    MARKER    'MARKER'                 'INTEND'
    load_0_2_4  arc_capacity_439  1
    load_0_2_4  segment_load_conservation_747  1
    load_0_2_4  segment_load_conservation_761  -1
    load_0_2_4  segment_prefix_lb_762  1
    load_0_2_4  segment_prefix_ub_763  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_5  arc_capacity_441  -20
    arc_0_2_5  connected_order_arc_442  -14
    arc_0_2_5  out_degree_743  1
    arc_0_2_5  in_degree_765  1
    arc_0_2_5  original_T_including_depot_unload_823  1.3208911608803092e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_5  arc_capacity_441  1
    load_0_2_5  segment_load_conservation_747  1
    load_0_2_5  segment_load_conservation_768  -1
    load_0_2_5  segment_prefix_lb_769  1
    load_0_2_5  segment_prefix_ub_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_13  arc_capacity_443  -20
    arc_0_2_13  connected_order_arc_444  -14
    arc_0_2_13  out_degree_743  1
    arc_0_2_13  in_degree_772  1
    arc_0_2_13  original_T_including_depot_unload_823  4.8210275478508015e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_13  arc_capacity_443  1
    load_0_2_13  segment_load_conservation_747  1
    load_0_2_13  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_14  arc_capacity_445  -20
    arc_0_2_14  connected_order_arc_446  -14
    arc_0_2_14  out_degree_743  1
    arc_0_2_14  in_degree_778  1
    arc_0_2_14  original_T_including_depot_unload_823  2.6417860079316790e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_14  arc_capacity_445  1
    load_0_2_14  segment_load_conservation_747  1
    load_0_2_14  free_load_conservation_782  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_15  arc_capacity_447  -20
    arc_0_2_15  connected_order_arc_448  -14
    arc_0_2_15  out_degree_743  1
    arc_0_2_15  in_degree_784  1
    arc_0_2_15  original_T_including_depot_unload_823  2.0838401346783280e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_15  arc_capacity_447  1
    load_0_2_15  segment_load_conservation_747  1
    load_0_2_15  free_load_conservation_788  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_16  arc_capacity_449  -20
    arc_0_2_16  connected_order_arc_450  -14
    arc_0_2_16  out_degree_743  1
    arc_0_2_16  in_degree_790  1
    arc_0_2_16  original_T_including_depot_unload_823  5.9170757102467792e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_16  arc_capacity_449  1
    load_0_2_16  segment_load_conservation_747  1
    load_0_2_16  free_load_conservation_794  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_17  arc_capacity_451  -20
    arc_0_2_17  connected_order_arc_452  -14
    arc_0_2_17  out_degree_743  1
    arc_0_2_17  in_degree_796  1
    arc_0_2_17  original_T_including_depot_unload_823  1.0665299943292241e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_17  arc_capacity_451  1
    load_0_2_17  segment_load_conservation_747  1
    load_0_2_17  free_load_conservation_800  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_18  arc_capacity_453  -20
    arc_0_2_18  connected_order_arc_454  -14
    arc_0_2_18  out_degree_743  1
    arc_0_2_18  in_degree_802  1
    arc_0_2_18  original_T_including_depot_unload_823  3.7084803914885475e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_18  arc_capacity_453  1
    load_0_2_18  segment_load_conservation_747  1
    load_0_2_18  free_load_conservation_806  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_19  arc_capacity_455  -20
    arc_0_2_19  connected_order_arc_456  -14
    arc_0_2_19  out_degree_743  1
    arc_0_2_19  in_degree_808  1
    arc_0_2_19  original_T_including_depot_unload_823  1.4489149558446036e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_19  arc_capacity_455  1
    load_0_2_19  segment_load_conservation_747  1
    load_0_2_19  free_load_conservation_812  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_20  arc_capacity_457  -20
    arc_0_2_20  connected_order_arc_458  -14
    arc_0_2_20  out_degree_743  1
    arc_0_2_20  in_degree_814  1
    arc_0_2_20  original_T_including_depot_unload_823  1.5460798335742169e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_20  arc_capacity_457  1
    load_0_2_20  segment_load_conservation_747  1
    load_0_2_20  free_load_conservation_818  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_0  arc_capacity_459  -20
    arc_0_3_0  depot_return_or_bypass_735  1
    arc_0_3_0  out_degree_750  1
    arc_0_3_0  original_T_including_depot_unload_823  8.9725048283911053e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_0  arc_capacity_459  1
    load_0_3_0  segment_load_conservation_754  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_1  arc_capacity_460  -20
    arc_0_3_1  connected_order_arc_461  -14
    arc_0_3_1  in_degree_737  1
    arc_0_3_1  out_degree_750  1
    arc_0_3_1  original_T_including_depot_unload_823  4.3127471875854752e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_1  arc_capacity_460  1
    load_0_3_1  segment_load_conservation_740  -1
    load_0_3_1  segment_prefix_lb_741  1
    load_0_3_1  segment_prefix_ub_742  1
    load_0_3_1  segment_load_conservation_754  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_2  arc_capacity_462  -20
    arc_0_3_2  connected_order_arc_463  -14
    arc_0_3_2  in_degree_744  1
    arc_0_3_2  out_degree_750  1
    arc_0_3_2  original_T_including_depot_unload_823  4.3076139952356033e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_2  arc_capacity_462  1
    load_0_3_2  segment_load_conservation_747  -1
    load_0_3_2  segment_prefix_lb_748  1
    load_0_3_2  segment_prefix_ub_749  1
    load_0_3_2  segment_load_conservation_754  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_4  arc_capacity_464  -20
    arc_0_3_4  connected_order_arc_465  -14
    arc_0_3_4  out_degree_750  1
    arc_0_3_4  in_degree_758  1
    arc_0_3_4  original_T_including_depot_unload_823  4.5635886855303721e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_4  arc_capacity_464  1
    load_0_3_4  segment_load_conservation_754  1
    load_0_3_4  segment_load_conservation_761  -1
    load_0_3_4  segment_prefix_lb_762  1
    load_0_3_4  segment_prefix_ub_763  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_5  arc_capacity_466  -20
    arc_0_3_5  connected_order_arc_467  -14
    arc_0_3_5  out_degree_750  1
    arc_0_3_5  in_degree_765  1
    arc_0_3_5  original_T_including_depot_unload_823  5.4635723875297333e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_5  arc_capacity_466  1
    load_0_3_5  segment_load_conservation_754  1
    load_0_3_5  segment_load_conservation_768  -1
    load_0_3_5  segment_prefix_lb_769  1
    load_0_3_5  segment_prefix_ub_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_13  arc_capacity_468  -20
    arc_0_3_13  connected_order_arc_469  -14
    arc_0_3_13  out_degree_750  1
    arc_0_3_13  in_degree_772  1
    arc_0_3_13  original_T_including_depot_unload_823  4.1659410744554447e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_13  arc_capacity_468  1
    load_0_3_13  segment_load_conservation_754  1
    load_0_3_13  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_14  arc_capacity_470  -20
    arc_0_3_14  connected_order_arc_471  -14
    arc_0_3_14  out_degree_750  1
    arc_0_3_14  in_degree_778  1
    arc_0_3_14  original_T_including_depot_unload_823  3.2756388134900334e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_14  arc_capacity_470  1
    load_0_3_14  segment_load_conservation_754  1
    load_0_3_14  free_load_conservation_782  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_15  arc_capacity_472  -20
    arc_0_3_15  connected_order_arc_473  -14
    arc_0_3_15  out_degree_750  1
    arc_0_3_15  in_degree_784  1
    arc_0_3_15  original_T_including_depot_unload_823  2.4438258071820178e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_15  arc_capacity_472  1
    load_0_3_15  segment_load_conservation_754  1
    load_0_3_15  free_load_conservation_788  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_16  arc_capacity_474  -20
    arc_0_3_16  connected_order_arc_475  -14
    arc_0_3_16  out_degree_750  1
    arc_0_3_16  in_degree_790  1
    arc_0_3_16  original_T_including_depot_unload_823  3.0921371532685328e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_16  arc_capacity_474  1
    load_0_3_16  segment_load_conservation_754  1
    load_0_3_16  free_load_conservation_794  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_17  arc_capacity_476  -20
    arc_0_3_17  connected_order_arc_477  -14
    arc_0_3_17  out_degree_750  1
    arc_0_3_17  in_degree_796  1
    arc_0_3_17  original_T_including_depot_unload_823  1.2980305053253444e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_17  arc_capacity_476  1
    load_0_3_17  segment_load_conservation_754  1
    load_0_3_17  free_load_conservation_800  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_18  arc_capacity_478  -20
    arc_0_3_18  connected_order_arc_479  -14
    arc_0_3_18  out_degree_750  1
    arc_0_3_18  in_degree_802  1
    arc_0_3_18  original_T_including_depot_unload_823  1.2154367551722198e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_18  arc_capacity_478  1
    load_0_3_18  segment_load_conservation_754  1
    load_0_3_18  free_load_conservation_806  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_19  arc_capacity_480  -20
    arc_0_3_19  connected_order_arc_481  -14
    arc_0_3_19  out_degree_750  1
    arc_0_3_19  in_degree_808  1
    arc_0_3_19  original_T_including_depot_unload_823  1804.59863156495
    MARKER    'MARKER'                 'INTEND'
    load_0_3_19  arc_capacity_480  1
    load_0_3_19  segment_load_conservation_754  1
    load_0_3_19  free_load_conservation_812  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_20  arc_capacity_482  -20
    arc_0_3_20  connected_order_arc_483  -14
    arc_0_3_20  out_degree_750  1
    arc_0_3_20  in_degree_814  1
    arc_0_3_20  original_T_including_depot_unload_823  3.6797474390734163e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_20  arc_capacity_482  1
    load_0_3_20  segment_load_conservation_754  1
    load_0_3_20  free_load_conservation_818  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_0  arc_capacity_484  -20
    arc_0_4_0  depot_return_or_bypass_735  1
    arc_0_4_0  out_degree_757  1
    arc_0_4_0  original_T_including_depot_unload_823  6.4256529461228865e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_0  arc_capacity_484  1
    load_0_4_0  segment_load_conservation_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_1  arc_capacity_485  -20
    arc_0_4_1  connected_order_arc_486  -14
    arc_0_4_1  in_degree_737  1
    arc_0_4_1  out_degree_757  1
    arc_0_4_1  original_T_including_depot_unload_823  3.5317482243205085e+01
    MARKER    'MARKER'                 'INTEND'
    load_0_4_1  arc_capacity_485  1
    load_0_4_1  segment_load_conservation_740  -1
    load_0_4_1  segment_prefix_lb_741  1
    load_0_4_1  segment_prefix_ub_742  1
    load_0_4_1  segment_load_conservation_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_2  arc_capacity_487  -20
    arc_0_4_2  connected_order_arc_488  -14
    arc_0_4_2  in_degree_744  1
    arc_0_4_2  out_degree_757  1
    arc_0_4_2  original_T_including_depot_unload_823  3.5426413058949414e+01
    MARKER    'MARKER'                 'INTEND'
    load_0_4_2  arc_capacity_487  1
    load_0_4_2  segment_load_conservation_747  -1
    load_0_4_2  segment_prefix_lb_748  1
    load_0_4_2  segment_prefix_ub_749  1
    load_0_4_2  segment_load_conservation_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_3  arc_capacity_489  -20
    arc_0_4_3  connected_order_arc_490  -14
    arc_0_4_3  in_degree_751  1
    arc_0_4_3  out_degree_757  1
    arc_0_4_3  original_T_including_depot_unload_823  4.5635886855303721e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_3  arc_capacity_489  1
    load_0_4_3  segment_load_conservation_754  -1
    load_0_4_3  segment_prefix_lb_755  1
    load_0_4_3  segment_prefix_ub_756  1
    load_0_4_3  segment_load_conservation_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_5  arc_capacity_491  -20
    arc_0_4_5  connected_order_arc_492  -14
    arc_0_4_5  out_degree_757  1
    arc_0_4_5  in_degree_765  1
    arc_0_4_5  original_T_including_depot_unload_823  1.2962070286822930e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_5  arc_capacity_491  1
    load_0_4_5  segment_load_conservation_761  1
    load_0_4_5  segment_load_conservation_768  -1
    load_0_4_5  segment_prefix_lb_769  1
    load_0_4_5  segment_prefix_ub_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_13  arc_capacity_493  -20
    arc_0_4_13  connected_order_arc_494  -14
    arc_0_4_13  out_degree_757  1
    arc_0_4_13  in_degree_772  1
    arc_0_4_13  original_T_including_depot_unload_823  477.665399637945
    MARKER    'MARKER'                 'INTEND'
    load_0_4_13  arc_capacity_493  1
    load_0_4_13  segment_load_conservation_761  1
    load_0_4_13  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_14  arc_capacity_495  -20
    arc_0_4_14  connected_order_arc_496  -14
    arc_0_4_14  out_degree_757  1
    arc_0_4_14  in_degree_778  1
    arc_0_4_14  original_T_including_depot_unload_823  2.6361257108552718e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_14  arc_capacity_495  1
    load_0_4_14  segment_load_conservation_761  1
    load_0_4_14  free_load_conservation_782  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_15  arc_capacity_497  -20
    arc_0_4_15  connected_order_arc_498  -14
    arc_0_4_15  out_degree_757  1
    arc_0_4_15  in_degree_784  1
    arc_0_4_15  original_T_including_depot_unload_823  2.0790680627934375e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_15  arc_capacity_497  1
    load_0_4_15  segment_load_conservation_761  1
    load_0_4_15  free_load_conservation_788  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_16  arc_capacity_499  -20
    arc_0_4_16  connected_order_arc_500  -14
    arc_0_4_16  out_degree_757  1
    arc_0_4_16  in_degree_790  1
    arc_0_4_16  original_T_including_depot_unload_823  6.0146431446211739e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_16  arc_capacity_499  1
    load_0_4_16  segment_load_conservation_761  1
    load_0_4_16  free_load_conservation_794  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_17  arc_capacity_501  -20
    arc_0_4_17  connected_order_arc_502  -14
    arc_0_4_17  out_degree_757  1
    arc_0_4_17  in_degree_796  1
    arc_0_4_17  original_T_including_depot_unload_823  1.0803844170008674e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_17  arc_capacity_501  1
    load_0_4_17  segment_load_conservation_761  1
    load_0_4_17  free_load_conservation_800  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_18  arc_capacity_503  -20
    arc_0_4_18  connected_order_arc_504  -14
    arc_0_4_18  out_degree_757  1
    arc_0_4_18  in_degree_802  1
    arc_0_4_18  original_T_including_depot_unload_823  3.8949255894881873e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_18  arc_capacity_503  1
    load_0_4_18  segment_load_conservation_761  1
    load_0_4_18  free_load_conservation_806  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_19  arc_capacity_505  -20
    arc_0_4_19  connected_order_arc_506  -14
    arc_0_4_19  out_degree_757  1
    arc_0_4_19  in_degree_808  1
    arc_0_4_19  original_T_including_depot_unload_823  1.4457797980495495e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_19  arc_capacity_505  1
    load_0_4_19  segment_load_conservation_761  1
    load_0_4_19  free_load_conservation_812  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_20  arc_capacity_507  -20
    arc_0_4_20  connected_order_arc_508  -14
    arc_0_4_20  out_degree_757  1
    arc_0_4_20  in_degree_814  1
    arc_0_4_20  original_T_including_depot_unload_823  1.5153540246292351e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_20  arc_capacity_507  1
    load_0_4_20  segment_load_conservation_761  1
    load_0_4_20  free_load_conservation_818  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_0  arc_capacity_509  -20
    arc_0_5_0  depot_return_or_bypass_735  1
    arc_0_5_0  out_degree_764  1
    arc_0_5_0  original_T_including_depot_unload_823  3.8060477410436619e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_0  arc_capacity_509  1
    load_0_5_0  segment_load_conservation_768  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_1  arc_capacity_510  -20
    arc_0_5_1  connected_order_arc_511  -14
    arc_0_5_1  in_degree_737  1
    arc_0_5_1  out_degree_764  1
    arc_0_5_1  original_T_including_depot_unload_823  7.7600923635341769e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_1  arc_capacity_510  1
    load_0_5_1  segment_load_conservation_740  -1
    load_0_5_1  segment_prefix_lb_741  1
    load_0_5_1  segment_prefix_ub_742  1
    load_0_5_1  segment_load_conservation_768  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_2  arc_capacity_512  -20
    arc_0_5_2  connected_order_arc_513  -14
    arc_0_5_2  in_degree_744  1
    arc_0_5_2  out_degree_764  1
    arc_0_5_2  original_T_including_depot_unload_823  7.7662791174533720e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_2  arc_capacity_512  1
    load_0_5_2  segment_load_conservation_747  -1
    load_0_5_2  segment_prefix_lb_748  1
    load_0_5_2  segment_prefix_ub_749  1
    load_0_5_2  segment_load_conservation_768  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_3  arc_capacity_514  -20
    arc_0_5_3  connected_order_arc_515  -14
    arc_0_5_3  in_degree_751  1
    arc_0_5_3  out_degree_764  1
    arc_0_5_3  original_T_including_depot_unload_823  1.1516424799836650e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_3  arc_capacity_514  1
    load_0_5_3  segment_load_conservation_754  -1
    load_0_5_3  segment_prefix_lb_755  1
    load_0_5_3  segment_prefix_ub_756  1
    load_0_5_3  segment_load_conservation_768  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_4  arc_capacity_516  -20
    arc_0_5_4  connected_order_arc_517  -14
    arc_0_5_4  in_degree_758  1
    arc_0_5_4  out_degree_764  1
    arc_0_5_4  original_T_including_depot_unload_823  7.7242003812192672e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_4  arc_capacity_516  1
    load_0_5_4  segment_load_conservation_761  -1
    load_0_5_4  segment_prefix_lb_762  1
    load_0_5_4  segment_prefix_ub_763  1
    load_0_5_4  segment_load_conservation_768  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_13  arc_capacity_518  -20
    arc_0_5_13  connected_order_arc_519  -14
    arc_0_5_13  out_degree_764  1
    arc_0_5_13  in_degree_772  1
    arc_0_5_13  original_T_including_depot_unload_823  1.2450286067313011e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_13  arc_capacity_518  1
    load_0_5_13  segment_load_conservation_768  1
    load_0_5_13  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_14  arc_capacity_520  -20
    arc_0_5_14  connected_order_arc_521  -14
    arc_0_5_14  out_degree_764  1
    arc_0_5_14  in_degree_778  1
    arc_0_5_14  original_T_including_depot_unload_823  1035.83277530205
    MARKER    'MARKER'                 'INTEND'
    load_0_5_14  arc_capacity_520  1
    load_0_5_14  segment_load_conservation_768  1
    load_0_5_14  free_load_conservation_782  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_15  arc_capacity_522  -20
    arc_0_5_15  connected_order_arc_523  -14
    arc_0_5_15  out_degree_764  1
    arc_0_5_15  in_degree_784  1
    arc_0_5_15  original_T_including_depot_unload_823  1.3072142379397485e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_15  arc_capacity_522  1
    load_0_5_15  segment_load_conservation_768  1
    load_0_5_15  free_load_conservation_788  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_16  arc_capacity_524  -20
    arc_0_5_16  connected_order_arc_525  -14
    arc_0_5_16  out_degree_764  1
    arc_0_5_16  in_degree_790  1
    arc_0_5_16  original_T_including_depot_unload_823  1.3663551195332984e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_16  arc_capacity_524  1
    load_0_5_16  segment_load_conservation_768  1
    load_0_5_16  free_load_conservation_794  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_17  arc_capacity_526  -20
    arc_0_5_17  connected_order_arc_527  -14
    arc_0_5_17  out_degree_764  1
    arc_0_5_17  in_degree_796  1
    arc_0_5_17  original_T_including_depot_unload_823  5.5668303114993182e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_17  arc_capacity_526  1
    load_0_5_17  segment_load_conservation_768  1
    load_0_5_17  free_load_conservation_800  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_18  arc_capacity_528  -20
    arc_0_5_18  connected_order_arc_529  -14
    arc_0_5_18  out_degree_764  1
    arc_0_5_18  in_degree_802  1
    arc_0_5_18  original_T_including_depot_unload_823  1.1301442107738828e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_18  arc_capacity_528  1
    load_0_5_18  segment_load_conservation_768  1
    load_0_5_18  free_load_conservation_806  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_19  arc_capacity_530  -20
    arc_0_5_19  connected_order_arc_531  -14
    arc_0_5_19  out_degree_764  1
    arc_0_5_19  in_degree_808  1
    arc_0_5_19  original_T_including_depot_unload_823  6.7368811350376711e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_19  arc_capacity_530  1
    load_0_5_19  segment_load_conservation_768  1
    load_0_5_19  free_load_conservation_812  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_20  arc_capacity_532  -20
    arc_0_5_20  connected_order_arc_533  -14
    arc_0_5_20  out_degree_764  1
    arc_0_5_20  in_degree_814  1
    arc_0_5_20  original_T_including_depot_unload_823  9.2367088355230590e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_20  arc_capacity_532  1
    load_0_5_20  segment_load_conservation_768  1
    load_0_5_20  free_load_conservation_818  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_0  arc_capacity_534  -20
    arc_0_13_0  depot_return_or_bypass_735  1
    arc_0_13_0  out_degree_771  1
    arc_0_13_0  original_T_including_depot_unload_823  1.1055042743585939e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_0  arc_capacity_534  1
    load_0_13_0  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_1  arc_capacity_535  -20
    arc_0_13_1  connected_order_arc_536  -14
    arc_0_13_1  in_degree_737  1
    arc_0_13_1  out_degree_771  1
    arc_0_13_1  original_T_including_depot_unload_823  4.8268503899521744e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_1  arc_capacity_535  1
    load_0_13_1  segment_load_conservation_740  -1
    load_0_13_1  segment_prefix_lb_741  1
    load_0_13_1  segment_prefix_ub_742  1
    load_0_13_1  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_2  arc_capacity_537  -20
    arc_0_13_2  connected_order_arc_538  -14
    arc_0_13_2  in_degree_744  1
    arc_0_13_2  out_degree_771  1
    arc_0_13_2  original_T_including_depot_unload_823  4.8210275478508015e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_2  arc_capacity_537  1
    load_0_13_2  segment_load_conservation_747  -1
    load_0_13_2  segment_prefix_lb_748  1
    load_0_13_2  segment_prefix_ub_749  1
    load_0_13_2  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_3  arc_capacity_539  -20
    arc_0_13_3  connected_order_arc_540  -14
    arc_0_13_3  in_degree_751  1
    arc_0_13_3  out_degree_771  1
    arc_0_13_3  original_T_including_depot_unload_823  4.1659410744554447e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_3  arc_capacity_539  1
    load_0_13_3  segment_load_conservation_754  -1
    load_0_13_3  segment_prefix_lb_755  1
    load_0_13_3  segment_prefix_ub_756  1
    load_0_13_3  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_4  arc_capacity_541  -20
    arc_0_13_4  connected_order_arc_542  -14
    arc_0_13_4  in_degree_758  1
    arc_0_13_4  out_degree_771  1
    arc_0_13_4  original_T_including_depot_unload_823  477.665399637945
    MARKER    'MARKER'                 'INTEND'
    load_0_13_4  arc_capacity_541  1
    load_0_13_4  segment_load_conservation_761  -1
    load_0_13_4  segment_prefix_lb_762  1
    load_0_13_4  segment_prefix_ub_763  1
    load_0_13_4  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_5  arc_capacity_543  -20
    arc_0_13_5  connected_order_arc_544  -14
    arc_0_13_5  in_degree_765  1
    arc_0_13_5  out_degree_771  1
    arc_0_13_5  original_T_including_depot_unload_823  6.0726027477261266e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_5  arc_capacity_543  1
    load_0_13_5  segment_load_conservation_768  -1
    load_0_13_5  segment_prefix_lb_769  1
    load_0_13_5  segment_prefix_ub_770  1
    load_0_13_5  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_14  arc_capacity_545  -20
    arc_0_13_14  connected_order_arc_546  -14
    arc_0_13_14  out_degree_771  1
    arc_0_13_14  in_degree_778  1
    arc_0_13_14  original_T_including_depot_unload_823  2.1974044543706933e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_14  arc_capacity_545  1
    load_0_13_14  free_load_conservation_776  1
    load_0_13_14  free_load_conservation_782  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_15  arc_capacity_547  -20
    arc_0_13_15  connected_order_arc_548  -14
    arc_0_13_15  out_degree_771  1
    arc_0_13_15  in_degree_784  1
    arc_0_13_15  original_T_including_depot_unload_823  2.5477291514674703e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_15  arc_capacity_547  1
    load_0_13_15  free_load_conservation_776  1
    load_0_13_15  free_load_conservation_788  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_16  arc_capacity_549  -20
    arc_0_13_16  connected_order_arc_550  -14
    arc_0_13_16  out_degree_771  1
    arc_0_13_16  in_degree_790  1
    arc_0_13_16  original_T_including_depot_unload_823  2.4467085139097674e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_16  arc_capacity_549  1
    load_0_13_16  free_load_conservation_776  1
    load_0_13_16  free_load_conservation_794  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_17  arc_capacity_551  -20
    arc_0_13_17  connected_order_arc_552  -14
    arc_0_13_17  out_degree_771  1
    arc_0_13_17  in_degree_796  1
    arc_0_13_17  original_T_including_depot_unload_823  1.5402832821684894e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_17  arc_capacity_551  1
    load_0_13_17  free_load_conservation_776  1
    load_0_13_17  free_load_conservation_800  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_18  arc_capacity_553  -20
    arc_0_13_18  connected_order_arc_554  -14
    arc_0_13_18  out_degree_771  1
    arc_0_13_18  in_degree_802  1
    arc_0_13_18  original_T_including_depot_unload_823  3.0177284565053407e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_18  arc_capacity_553  1
    load_0_13_18  free_load_conservation_776  1
    load_0_13_18  free_load_conservation_806  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_19  arc_capacity_555  -20
    arc_0_13_19  connected_order_arc_556  -14
    arc_0_13_19  out_degree_771  1
    arc_0_13_19  in_degree_808  1
    arc_0_13_19  original_T_including_depot_unload_823  1.9185455792071525e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_19  arc_capacity_555  1
    load_0_13_19  free_load_conservation_776  1
    load_0_13_19  free_load_conservation_812  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_20  arc_capacity_557  -20
    arc_0_13_20  connected_order_arc_558  -14
    arc_0_13_20  out_degree_771  1
    arc_0_13_20  in_degree_814  1
    arc_0_13_20  original_T_including_depot_unload_823  3.2767382990070683e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_20  arc_capacity_557  1
    load_0_13_20  free_load_conservation_776  1
    load_0_13_20  free_load_conservation_818  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_0  arc_capacity_559  -20
    arc_0_14_0  depot_return_or_bypass_735  1
    arc_0_14_0  out_degree_777  1
    arc_0_14_0  original_T_including_depot_unload_823  885.819758595088
    MARKER    'MARKER'                 'INTEND'
    load_0_14_0  arc_capacity_559  1
    load_0_14_0  free_load_conservation_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_1  arc_capacity_560  -20
    arc_0_14_1  connected_order_arc_561  -14
    arc_0_14_1  in_degree_737  1
    arc_0_14_1  out_degree_777  1
    arc_0_14_1  original_T_including_depot_unload_823  2.6477572380586179e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_1  arc_capacity_560  1
    load_0_14_1  segment_load_conservation_740  -1
    load_0_14_1  segment_prefix_lb_741  1
    load_0_14_1  segment_prefix_ub_742  1
    load_0_14_1  free_load_conservation_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_2  arc_capacity_562  -20
    arc_0_14_2  connected_order_arc_563  -14
    arc_0_14_2  in_degree_744  1
    arc_0_14_2  out_degree_777  1
    arc_0_14_2  original_T_including_depot_unload_823  2.6417860079316790e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_2  arc_capacity_562  1
    load_0_14_2  segment_load_conservation_747  -1
    load_0_14_2  segment_prefix_lb_748  1
    load_0_14_2  segment_prefix_ub_749  1
    load_0_14_2  free_load_conservation_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_3  arc_capacity_564  -20
    arc_0_14_3  connected_order_arc_565  -14
    arc_0_14_3  in_degree_751  1
    arc_0_14_3  out_degree_777  1
    arc_0_14_3  original_T_including_depot_unload_823  3.2756388134900334e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_3  arc_capacity_564  1
    load_0_14_3  segment_load_conservation_754  -1
    load_0_14_3  segment_prefix_lb_755  1
    load_0_14_3  segment_prefix_ub_756  1
    load_0_14_3  free_load_conservation_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_4  arc_capacity_566  -20
    arc_0_14_4  connected_order_arc_567  -14
    arc_0_14_4  in_degree_758  1
    arc_0_14_4  out_degree_777  1
    arc_0_14_4  original_T_including_depot_unload_823  2.6361257108552718e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_4  arc_capacity_566  1
    load_0_14_4  segment_load_conservation_761  -1
    load_0_14_4  segment_prefix_lb_762  1
    load_0_14_4  segment_prefix_ub_763  1
    load_0_14_4  free_load_conservation_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_5  arc_capacity_568  -20
    arc_0_14_5  connected_order_arc_569  -14
    arc_0_14_5  in_degree_765  1
    arc_0_14_5  out_degree_777  1
    arc_0_14_5  original_T_including_depot_unload_823  3.9263280945415767e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_5  arc_capacity_568  1
    load_0_14_5  segment_load_conservation_768  -1
    load_0_14_5  segment_prefix_lb_769  1
    load_0_14_5  segment_prefix_ub_770  1
    load_0_14_5  free_load_conservation_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_13  arc_capacity_570  -20
    arc_0_14_13  connected_order_arc_571  -14
    arc_0_14_13  in_degree_772  1
    arc_0_14_13  out_degree_777  1
    arc_0_14_13  original_T_including_depot_unload_823  2.1974044543706933e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_13  arc_capacity_570  1
    load_0_14_13  free_load_conservation_776  -1
    load_0_14_13  free_load_conservation_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_15  arc_capacity_572  -20
    arc_0_14_15  connected_order_arc_573  -14
    arc_0_14_15  out_degree_777  1
    arc_0_14_15  in_degree_784  1
    arc_0_14_15  original_T_including_depot_unload_823  2.3420148578372859e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_15  arc_capacity_572  1
    load_0_14_15  free_load_conservation_782  1
    load_0_14_15  free_load_conservation_788  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_16  arc_capacity_574  -20
    arc_0_14_16  connected_order_arc_575  -14
    arc_0_14_16  out_degree_777  1
    arc_0_14_16  in_degree_790  1
    arc_0_14_16  original_T_including_depot_unload_823  3.5284009487492966e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_16  arc_capacity_574  1
    load_0_14_16  free_load_conservation_782  1
    load_0_14_16  free_load_conservation_794  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_17  arc_capacity_576  -20
    arc_0_14_17  connected_order_arc_577  -14
    arc_0_14_17  out_degree_777  1
    arc_0_14_17  in_degree_796  1
    arc_0_14_17  original_T_including_depot_unload_823  1.3209989051658847e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_17  arc_capacity_576  1
    load_0_14_17  free_load_conservation_782  1
    load_0_14_17  free_load_conservation_800  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_18  arc_capacity_578  -20
    arc_0_14_18  connected_order_arc_579  -14
    arc_0_14_18  out_degree_777  1
    arc_0_14_18  in_degree_802  1
    arc_0_14_18  original_T_including_depot_unload_823  2.1282400853806328e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_18  arc_capacity_578  1
    load_0_14_18  free_load_conservation_782  1
    load_0_14_18  free_load_conservation_806  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_19  arc_capacity_580  -20
    arc_0_14_19  connected_order_arc_581  -14
    arc_0_14_19  out_degree_777  1
    arc_0_14_19  in_degree_808  1
    arc_0_14_19  original_T_including_depot_unload_823  1.7093216071319850e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_19  arc_capacity_580  1
    load_0_14_19  free_load_conservation_782  1
    load_0_14_19  free_load_conservation_812  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_20  arc_capacity_582  -20
    arc_0_14_20  connected_order_arc_583  -14
    arc_0_14_20  out_degree_777  1
    arc_0_14_20  in_degree_814  1
    arc_0_14_20  original_T_including_depot_unload_823  1.1216289013953633e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_20  arc_capacity_582  1
    load_0_14_20  free_load_conservation_782  1
    load_0_14_20  free_load_conservation_818  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_0  arc_capacity_584  -20
    arc_0_15_0  depot_return_or_bypass_735  1
    arc_0_15_0  out_degree_783  1
    arc_0_15_0  original_T_including_depot_unload_823  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_0  arc_capacity_584  1
    load_0_15_0  free_load_conservation_788  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_1  arc_capacity_585  -20
    arc_0_15_1  connected_order_arc_586  -14
    arc_0_15_1  in_degree_737  1
    arc_0_15_1  out_degree_783  1
    arc_0_15_1  original_T_including_depot_unload_823  2.0832214111784192e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_1  arc_capacity_585  1
    load_0_15_1  segment_load_conservation_740  -1
    load_0_15_1  segment_prefix_lb_741  1
    load_0_15_1  segment_prefix_ub_742  1
    load_0_15_1  free_load_conservation_788  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_2  arc_capacity_587  -20
    arc_0_15_2  connected_order_arc_588  -14
    arc_0_15_2  in_degree_744  1
    arc_0_15_2  out_degree_783  1
    arc_0_15_2  original_T_including_depot_unload_823  2.0838401346783280e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_2  arc_capacity_587  1
    load_0_15_2  segment_load_conservation_747  -1
    load_0_15_2  segment_prefix_lb_748  1
    load_0_15_2  segment_prefix_ub_749  1
    load_0_15_2  free_load_conservation_788  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_3  arc_capacity_589  -20
    arc_0_15_3  connected_order_arc_590  -14
    arc_0_15_3  in_degree_751  1
    arc_0_15_3  out_degree_783  1
    arc_0_15_3  original_T_including_depot_unload_823  2.4438258071820178e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_3  arc_capacity_589  1
    load_0_15_3  segment_load_conservation_754  -1
    load_0_15_3  segment_prefix_lb_755  1
    load_0_15_3  segment_prefix_ub_756  1
    load_0_15_3  free_load_conservation_788  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_4  arc_capacity_591  -20
    arc_0_15_4  connected_order_arc_592  -14
    arc_0_15_4  in_degree_758  1
    arc_0_15_4  out_degree_783  1
    arc_0_15_4  original_T_including_depot_unload_823  2.0790680627934375e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_4  arc_capacity_591  1
    load_0_15_4  segment_load_conservation_761  -1
    load_0_15_4  segment_prefix_lb_762  1
    load_0_15_4  segment_prefix_ub_763  1
    load_0_15_4  free_load_conservation_788  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_5  arc_capacity_593  -20
    arc_0_15_5  connected_order_arc_594  -14
    arc_0_15_5  in_degree_765  1
    arc_0_15_5  out_degree_783  1
    arc_0_15_5  original_T_including_depot_unload_823  1.9520133700471852e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_5  arc_capacity_593  1
    load_0_15_5  segment_load_conservation_768  -1
    load_0_15_5  segment_prefix_lb_769  1
    load_0_15_5  segment_prefix_ub_770  1
    load_0_15_5  free_load_conservation_788  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_13  arc_capacity_595  -20
    arc_0_15_13  connected_order_arc_596  -14
    arc_0_15_13  in_degree_772  1
    arc_0_15_13  out_degree_783  1
    arc_0_15_13  original_T_including_depot_unload_823  2.5477291514674703e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_13  arc_capacity_595  1
    load_0_15_13  free_load_conservation_776  -1
    load_0_15_13  free_load_conservation_788  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_14  arc_capacity_597  -20
    arc_0_15_14  connected_order_arc_598  -14
    arc_0_15_14  in_degree_778  1
    arc_0_15_14  out_degree_783  1
    arc_0_15_14  original_T_including_depot_unload_823  2.3420148578372859e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_14  arc_capacity_597  1
    load_0_15_14  free_load_conservation_782  -1
    load_0_15_14  free_load_conservation_788  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_16  arc_capacity_599  -20
    arc_0_15_16  connected_order_arc_600  -14
    arc_0_15_16  out_degree_783  1
    arc_0_15_16  in_degree_790  1
    arc_0_15_16  original_T_including_depot_unload_823  2.6729202257370252e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_16  arc_capacity_599  1
    load_0_15_16  free_load_conservation_788  1
    load_0_15_16  free_load_conservation_794  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_17  arc_capacity_601  -20
    arc_0_15_17  connected_order_arc_602  -14
    arc_0_15_17  out_degree_783  1
    arc_0_15_17  in_degree_796  1
    arc_0_15_17  original_T_including_depot_unload_823  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_17  arc_capacity_601  1
    load_0_15_17  free_load_conservation_788  1
    load_0_15_17  free_load_conservation_800  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_18  arc_capacity_603  -20
    arc_0_15_18  connected_order_arc_604  -14
    arc_0_15_18  out_degree_783  1
    arc_0_15_18  in_degree_802  1
    arc_0_15_18  original_T_including_depot_unload_823  2.4332256311874226e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_18  arc_capacity_603  1
    load_0_15_18  free_load_conservation_788  1
    load_0_15_18  free_load_conservation_806  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_19  arc_capacity_605  -20
    arc_0_15_19  connected_order_arc_606  -14
    arc_0_15_19  out_degree_783  1
    arc_0_15_19  in_degree_808  1
    arc_0_15_19  original_T_including_depot_unload_823  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_0_15_19  arc_capacity_605  1
    load_0_15_19  free_load_conservation_788  1
    load_0_15_19  free_load_conservation_812  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_20  arc_capacity_607  -20
    arc_0_15_20  connected_order_arc_608  -14
    arc_0_15_20  out_degree_783  1
    arc_0_15_20  in_degree_814  1
    arc_0_15_20  original_T_including_depot_unload_823  2.2299340442558691e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_20  arc_capacity_607  1
    load_0_15_20  free_load_conservation_788  1
    load_0_15_20  free_load_conservation_818  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_0  arc_capacity_609  -20
    arc_0_16_0  depot_return_or_bypass_735  1
    arc_0_16_0  out_degree_789  1
    arc_0_16_0  original_T_including_depot_unload_823  1163.36883938708
    MARKER    'MARKER'                 'INTEND'
    load_0_16_0  arc_capacity_609  1
    load_0_16_0  free_load_conservation_794  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_1  arc_capacity_610  -20
    arc_0_16_1  connected_order_arc_611  -14
    arc_0_16_1  in_degree_737  1
    arc_0_16_1  out_degree_789  1
    arc_0_16_1  original_T_including_depot_unload_823  5.9232553492869590e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_1  arc_capacity_610  1
    load_0_16_1  segment_load_conservation_740  -1
    load_0_16_1  segment_prefix_lb_741  1
    load_0_16_1  segment_prefix_ub_742  1
    load_0_16_1  free_load_conservation_794  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_2  arc_capacity_612  -20
    arc_0_16_2  connected_order_arc_613  -14
    arc_0_16_2  in_degree_744  1
    arc_0_16_2  out_degree_789  1
    arc_0_16_2  original_T_including_depot_unload_823  5.9170757102467792e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_2  arc_capacity_612  1
    load_0_16_2  segment_load_conservation_747  -1
    load_0_16_2  segment_prefix_lb_748  1
    load_0_16_2  segment_prefix_ub_749  1
    load_0_16_2  free_load_conservation_794  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_3  arc_capacity_614  -20
    arc_0_16_3  connected_order_arc_615  -14
    arc_0_16_3  in_degree_751  1
    arc_0_16_3  out_degree_789  1
    arc_0_16_3  original_T_including_depot_unload_823  3.0921371532685328e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_3  arc_capacity_614  1
    load_0_16_3  segment_load_conservation_754  -1
    load_0_16_3  segment_prefix_lb_755  1
    load_0_16_3  segment_prefix_ub_756  1
    load_0_16_3  free_load_conservation_794  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_4  arc_capacity_616  -20
    arc_0_16_4  connected_order_arc_617  -14
    arc_0_16_4  in_degree_758  1
    arc_0_16_4  out_degree_789  1
    arc_0_16_4  original_T_including_depot_unload_823  6.0146431446211739e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_4  arc_capacity_616  1
    load_0_16_4  segment_load_conservation_761  -1
    load_0_16_4  segment_prefix_lb_762  1
    load_0_16_4  segment_prefix_ub_763  1
    load_0_16_4  free_load_conservation_794  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_5  arc_capacity_618  -20
    arc_0_16_5  connected_order_arc_619  -14
    arc_0_16_5  in_degree_765  1
    arc_0_16_5  out_degree_789  1
    arc_0_16_5  original_T_including_depot_unload_823  7.2368344003319692e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_5  arc_capacity_618  1
    load_0_16_5  segment_load_conservation_768  -1
    load_0_16_5  segment_prefix_lb_769  1
    load_0_16_5  segment_prefix_ub_770  1
    load_0_16_5  free_load_conservation_794  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_13  arc_capacity_620  -20
    arc_0_16_13  connected_order_arc_621  -14
    arc_0_16_13  in_degree_772  1
    arc_0_16_13  out_degree_789  1
    arc_0_16_13  original_T_including_depot_unload_823  2.4467085139097674e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_13  arc_capacity_620  1
    load_0_16_13  free_load_conservation_776  -1
    load_0_16_13  free_load_conservation_794  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_14  arc_capacity_622  -20
    arc_0_16_14  connected_order_arc_623  -14
    arc_0_16_14  in_degree_778  1
    arc_0_16_14  out_degree_789  1
    arc_0_16_14  original_T_including_depot_unload_823  3.5284009487492966e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_14  arc_capacity_622  1
    load_0_16_14  free_load_conservation_782  -1
    load_0_16_14  free_load_conservation_794  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_15  arc_capacity_624  -20
    arc_0_16_15  connected_order_arc_625  -14
    arc_0_16_15  in_degree_784  1
    arc_0_16_15  out_degree_789  1
    arc_0_16_15  original_T_including_depot_unload_823  2.6729202257370252e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_15  arc_capacity_624  1
    load_0_16_15  free_load_conservation_788  -1
    load_0_16_15  free_load_conservation_794  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_17  arc_capacity_626  -20
    arc_0_16_17  connected_order_arc_627  -14
    arc_0_16_17  out_degree_789  1
    arc_0_16_17  in_degree_796  1
    arc_0_16_17  original_T_including_depot_unload_823  1.5818623486522529e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_17  arc_capacity_626  1
    load_0_16_17  free_load_conservation_794  1
    load_0_16_17  free_load_conservation_800  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_18  arc_capacity_628  -20
    arc_0_16_18  connected_order_arc_629  -14
    arc_0_16_18  out_degree_789  1
    arc_0_16_18  in_degree_802  1
    arc_0_16_18  original_T_including_depot_unload_823  2.5289455774621715e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_18  arc_capacity_628  1
    load_0_16_18  free_load_conservation_794  1
    load_0_16_18  free_load_conservation_806  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_19  arc_capacity_630  -20
    arc_0_16_19  connected_order_arc_631  -14
    arc_0_16_19  out_degree_789  1
    arc_0_16_19  in_degree_808  1
    arc_0_16_19  original_T_including_depot_unload_823  2.0359275139821484e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_19  arc_capacity_630  1
    load_0_16_19  free_load_conservation_794  1
    load_0_16_19  free_load_conservation_812  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_20  arc_capacity_632  -20
    arc_0_16_20  connected_order_arc_633  -14
    arc_0_16_20  out_degree_789  1
    arc_0_16_20  in_degree_814  1
    arc_0_16_20  original_T_including_depot_unload_823  4.5764912346489922e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_20  arc_capacity_632  1
    load_0_16_20  free_load_conservation_794  1
    load_0_16_20  free_load_conservation_818  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_0  arc_capacity_634  -20
    arc_0_17_0  depot_return_or_bypass_735  1
    arc_0_17_0  out_degree_795  1
    arc_0_17_0  original_T_including_depot_unload_823  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_0  arc_capacity_634  1
    load_0_17_0  free_load_conservation_800  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_1  arc_capacity_635  -20
    arc_0_17_1  connected_order_arc_636  -14
    arc_0_17_1  in_degree_737  1
    arc_0_17_1  out_degree_795  1
    arc_0_17_1  original_T_including_depot_unload_823  1.0660093540264595e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_1  arc_capacity_635  1
    load_0_17_1  segment_load_conservation_740  -1
    load_0_17_1  segment_prefix_lb_741  1
    load_0_17_1  segment_prefix_ub_742  1
    load_0_17_1  free_load_conservation_800  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_2  arc_capacity_637  -20
    arc_0_17_2  connected_order_arc_638  -14
    arc_0_17_2  in_degree_744  1
    arc_0_17_2  out_degree_795  1
    arc_0_17_2  original_T_including_depot_unload_823  1.0665299943292241e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_2  arc_capacity_637  1
    load_0_17_2  segment_load_conservation_747  -1
    load_0_17_2  segment_prefix_lb_748  1
    load_0_17_2  segment_prefix_ub_749  1
    load_0_17_2  free_load_conservation_800  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_3  arc_capacity_639  -20
    arc_0_17_3  connected_order_arc_640  -14
    arc_0_17_3  in_degree_751  1
    arc_0_17_3  out_degree_795  1
    arc_0_17_3  original_T_including_depot_unload_823  1.2980305053253444e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_3  arc_capacity_639  1
    load_0_17_3  segment_load_conservation_754  -1
    load_0_17_3  segment_prefix_lb_755  1
    load_0_17_3  segment_prefix_ub_756  1
    load_0_17_3  free_load_conservation_800  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_4  arc_capacity_641  -20
    arc_0_17_4  connected_order_arc_642  -14
    arc_0_17_4  in_degree_758  1
    arc_0_17_4  out_degree_795  1
    arc_0_17_4  original_T_including_depot_unload_823  1.0803844170008674e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_4  arc_capacity_641  1
    load_0_17_4  segment_load_conservation_761  -1
    load_0_17_4  segment_prefix_lb_762  1
    load_0_17_4  segment_prefix_ub_763  1
    load_0_17_4  free_load_conservation_800  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_5  arc_capacity_643  -20
    arc_0_17_5  connected_order_arc_644  -14
    arc_0_17_5  in_degree_765  1
    arc_0_17_5  out_degree_795  1
    arc_0_17_5  original_T_including_depot_unload_823  9.5968099967049886e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_5  arc_capacity_643  1
    load_0_17_5  segment_load_conservation_768  -1
    load_0_17_5  segment_prefix_lb_769  1
    load_0_17_5  segment_prefix_ub_770  1
    load_0_17_5  free_load_conservation_800  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_13  arc_capacity_645  -20
    arc_0_17_13  connected_order_arc_646  -14
    arc_0_17_13  in_degree_772  1
    arc_0_17_13  out_degree_795  1
    arc_0_17_13  original_T_including_depot_unload_823  1.5402832821684894e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_13  arc_capacity_645  1
    load_0_17_13  free_load_conservation_776  -1
    load_0_17_13  free_load_conservation_800  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_14  arc_capacity_647  -20
    arc_0_17_14  connected_order_arc_648  -14
    arc_0_17_14  in_degree_778  1
    arc_0_17_14  out_degree_795  1
    arc_0_17_14  original_T_including_depot_unload_823  1.3209989051658847e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_14  arc_capacity_647  1
    load_0_17_14  free_load_conservation_782  -1
    load_0_17_14  free_load_conservation_800  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_15  arc_capacity_649  -20
    arc_0_17_15  connected_order_arc_650  -14
    arc_0_17_15  in_degree_784  1
    arc_0_17_15  out_degree_795  1
    arc_0_17_15  original_T_including_depot_unload_823  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_15  arc_capacity_649  1
    load_0_17_15  free_load_conservation_788  -1
    load_0_17_15  free_load_conservation_800  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_16  arc_capacity_651  -20
    arc_0_17_16  connected_order_arc_652  -14
    arc_0_17_16  in_degree_790  1
    arc_0_17_16  out_degree_795  1
    arc_0_17_16  original_T_including_depot_unload_823  1.5818623486522529e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_16  arc_capacity_651  1
    load_0_17_16  free_load_conservation_794  -1
    load_0_17_16  free_load_conservation_800  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_18  arc_capacity_653  -20
    arc_0_17_18  connected_order_arc_654  -14
    arc_0_17_18  out_degree_795  1
    arc_0_17_18  in_degree_802  1
    arc_0_17_18  original_T_including_depot_unload_823  1.3290297652049680e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_18  arc_capacity_653  1
    load_0_17_18  free_load_conservation_800  1
    load_0_17_18  free_load_conservation_806  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_19  arc_capacity_655  -20
    arc_0_17_19  connected_order_arc_656  -14
    arc_0_17_19  out_degree_795  1
    arc_0_17_19  in_degree_808  1
    arc_0_17_19  original_T_including_depot_unload_823  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_0_17_19  arc_capacity_655  1
    load_0_17_19  free_load_conservation_800  1
    load_0_17_19  free_load_conservation_812  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_20  arc_capacity_657  -20
    arc_0_17_20  connected_order_arc_658  -14
    arc_0_17_20  out_degree_795  1
    arc_0_17_20  in_degree_814  1
    arc_0_17_20  original_T_including_depot_unload_823  1.2188376307261726e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_20  arc_capacity_657  1
    load_0_17_20  free_load_conservation_800  1
    load_0_17_20  free_load_conservation_818  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_0  arc_capacity_659  -20
    arc_0_18_0  depot_return_or_bypass_735  1
    arc_0_18_0  out_degree_801  1
    arc_0_18_0  original_T_including_depot_unload_823  9.1137190274562636e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_0  arc_capacity_659  1
    load_0_18_0  free_load_conservation_806  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_1  arc_capacity_660  -20
    arc_0_18_1  connected_order_arc_661  -14
    arc_0_18_1  in_degree_737  1
    arc_0_18_1  out_degree_801  1
    arc_0_18_1  original_T_including_depot_unload_823  3.7143421209022068e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_1  arc_capacity_660  1
    load_0_18_1  segment_load_conservation_740  -1
    load_0_18_1  segment_prefix_lb_741  1
    load_0_18_1  segment_prefix_ub_742  1
    load_0_18_1  free_load_conservation_806  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_2  arc_capacity_662  -20
    arc_0_18_2  connected_order_arc_663  -14
    arc_0_18_2  in_degree_744  1
    arc_0_18_2  out_degree_801  1
    arc_0_18_2  original_T_including_depot_unload_823  3.7084803914885475e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_2  arc_capacity_662  1
    load_0_18_2  segment_load_conservation_747  -1
    load_0_18_2  segment_prefix_lb_748  1
    load_0_18_2  segment_prefix_ub_749  1
    load_0_18_2  free_load_conservation_806  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_3  arc_capacity_664  -20
    arc_0_18_3  connected_order_arc_665  -14
    arc_0_18_3  in_degree_751  1
    arc_0_18_3  out_degree_801  1
    arc_0_18_3  original_T_including_depot_unload_823  1.2154367551722198e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_3  arc_capacity_664  1
    load_0_18_3  segment_load_conservation_754  -1
    load_0_18_3  segment_prefix_lb_755  1
    load_0_18_3  segment_prefix_ub_756  1
    load_0_18_3  free_load_conservation_806  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_4  arc_capacity_666  -20
    arc_0_18_4  connected_order_arc_667  -14
    arc_0_18_4  in_degree_758  1
    arc_0_18_4  out_degree_801  1
    arc_0_18_4  original_T_including_depot_unload_823  3.8949255894881873e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_4  arc_capacity_666  1
    load_0_18_4  segment_load_conservation_761  -1
    load_0_18_4  segment_prefix_lb_762  1
    load_0_18_4  segment_prefix_ub_763  1
    load_0_18_4  free_load_conservation_806  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_5  arc_capacity_668  -20
    arc_0_18_5  connected_order_arc_669  -14
    arc_0_18_5  in_degree_765  1
    arc_0_18_5  out_degree_801  1
    arc_0_18_5  original_T_including_depot_unload_823  4.9828630663707764e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_5  arc_capacity_668  1
    load_0_18_5  segment_load_conservation_768  -1
    load_0_18_5  segment_prefix_lb_769  1
    load_0_18_5  segment_prefix_ub_770  1
    load_0_18_5  free_load_conservation_806  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_13  arc_capacity_670  -20
    arc_0_18_13  connected_order_arc_671  -14
    arc_0_18_13  in_degree_772  1
    arc_0_18_13  out_degree_801  1
    arc_0_18_13  original_T_including_depot_unload_823  3.0177284565053407e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_13  arc_capacity_670  1
    load_0_18_13  free_load_conservation_776  -1
    load_0_18_13  free_load_conservation_806  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_14  arc_capacity_672  -20
    arc_0_18_14  connected_order_arc_673  -14
    arc_0_18_14  in_degree_778  1
    arc_0_18_14  out_degree_801  1
    arc_0_18_14  original_T_including_depot_unload_823  2.1282400853806328e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_14  arc_capacity_672  1
    load_0_18_14  free_load_conservation_782  -1
    load_0_18_14  free_load_conservation_806  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_15  arc_capacity_674  -20
    arc_0_18_15  connected_order_arc_675  -14
    arc_0_18_15  in_degree_784  1
    arc_0_18_15  out_degree_801  1
    arc_0_18_15  original_T_including_depot_unload_823  2.4332256311874226e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_15  arc_capacity_674  1
    load_0_18_15  free_load_conservation_788  -1
    load_0_18_15  free_load_conservation_806  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_16  arc_capacity_676  -20
    arc_0_18_16  connected_order_arc_677  -14
    arc_0_18_16  in_degree_790  1
    arc_0_18_16  out_degree_801  1
    arc_0_18_16  original_T_including_depot_unload_823  2.5289455774621715e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_16  arc_capacity_676  1
    load_0_18_16  free_load_conservation_794  -1
    load_0_18_16  free_load_conservation_806  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_17  arc_capacity_678  -20
    arc_0_18_17  connected_order_arc_679  -14
    arc_0_18_17  in_degree_796  1
    arc_0_18_17  out_degree_801  1
    arc_0_18_17  original_T_including_depot_unload_823  1.3290297652049680e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_17  arc_capacity_678  1
    load_0_18_17  free_load_conservation_800  -1
    load_0_18_17  free_load_conservation_806  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_19  arc_capacity_680  -20
    arc_0_18_19  connected_order_arc_681  -14
    arc_0_18_19  out_degree_801  1
    arc_0_18_19  in_degree_808  1
    arc_0_18_19  original_T_including_depot_unload_823  1.7947282495227562e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_19  arc_capacity_680  1
    load_0_18_19  free_load_conservation_806  1
    load_0_18_19  free_load_conservation_812  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_20  arc_capacity_682  -20
    arc_0_18_20  connected_order_arc_683  -14
    arc_0_18_20  out_degree_801  1
    arc_0_18_20  in_degree_814  1
    arc_0_18_20  original_T_including_depot_unload_823  2.7370069334295619e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_20  arc_capacity_682  1
    load_0_18_20  free_load_conservation_806  1
    load_0_18_20  free_load_conservation_818  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_0  arc_capacity_684  -20
    arc_0_19_0  depot_return_or_bypass_735  1
    arc_0_19_0  out_degree_807  1
    arc_0_19_0  original_T_including_depot_unload_823  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_0  arc_capacity_684  1
    load_0_19_0  free_load_conservation_812  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_1  arc_capacity_685  -20
    arc_0_19_1  connected_order_arc_686  -14
    arc_0_19_1  in_degree_737  1
    arc_0_19_1  out_degree_807  1
    arc_0_19_1  original_T_including_depot_unload_823  1.4482979064849126e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_1  arc_capacity_685  1
    load_0_19_1  segment_load_conservation_740  -1
    load_0_19_1  segment_prefix_lb_741  1
    load_0_19_1  segment_prefix_ub_742  1
    load_0_19_1  free_load_conservation_812  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_2  arc_capacity_687  -20
    arc_0_19_2  connected_order_arc_688  -14
    arc_0_19_2  in_degree_744  1
    arc_0_19_2  out_degree_807  1
    arc_0_19_2  original_T_including_depot_unload_823  1.4489149558446036e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_2  arc_capacity_687  1
    load_0_19_2  segment_load_conservation_747  -1
    load_0_19_2  segment_prefix_lb_748  1
    load_0_19_2  segment_prefix_ub_749  1
    load_0_19_2  free_load_conservation_812  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_3  arc_capacity_689  -20
    arc_0_19_3  connected_order_arc_690  -14
    arc_0_19_3  in_degree_751  1
    arc_0_19_3  out_degree_807  1
    arc_0_19_3  original_T_including_depot_unload_823  1804.59863156495
    MARKER    'MARKER'                 'INTEND'
    load_0_19_3  arc_capacity_689  1
    load_0_19_3  segment_load_conservation_754  -1
    load_0_19_3  segment_prefix_lb_755  1
    load_0_19_3  segment_prefix_ub_756  1
    load_0_19_3  free_load_conservation_812  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_4  arc_capacity_691  -20
    arc_0_19_4  connected_order_arc_692  -14
    arc_0_19_4  in_degree_758  1
    arc_0_19_4  out_degree_807  1
    arc_0_19_4  original_T_including_depot_unload_823  1.4457797980495495e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_4  arc_capacity_691  1
    load_0_19_4  segment_load_conservation_761  -1
    load_0_19_4  segment_prefix_lb_762  1
    load_0_19_4  segment_prefix_ub_763  1
    load_0_19_4  free_load_conservation_812  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_5  arc_capacity_693  -20
    arc_0_19_5  connected_order_arc_694  -14
    arc_0_19_5  in_degree_765  1
    arc_0_19_5  out_degree_807  1
    arc_0_19_5  original_T_including_depot_unload_823  1.3176071585703125e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_5  arc_capacity_693  1
    load_0_19_5  segment_load_conservation_768  -1
    load_0_19_5  segment_prefix_lb_769  1
    load_0_19_5  segment_prefix_ub_770  1
    load_0_19_5  free_load_conservation_812  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_13  arc_capacity_695  -20
    arc_0_19_13  connected_order_arc_696  -14
    arc_0_19_13  in_degree_772  1
    arc_0_19_13  out_degree_807  1
    arc_0_19_13  original_T_including_depot_unload_823  1.9185455792071525e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_13  arc_capacity_695  1
    load_0_19_13  free_load_conservation_776  -1
    load_0_19_13  free_load_conservation_812  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_14  arc_capacity_697  -20
    arc_0_19_14  connected_order_arc_698  -14
    arc_0_19_14  in_degree_778  1
    arc_0_19_14  out_degree_807  1
    arc_0_19_14  original_T_including_depot_unload_823  1.7093216071319850e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_14  arc_capacity_697  1
    load_0_19_14  free_load_conservation_782  -1
    load_0_19_14  free_load_conservation_812  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_15  arc_capacity_699  -20
    arc_0_19_15  connected_order_arc_700  -14
    arc_0_19_15  in_degree_784  1
    arc_0_19_15  out_degree_807  1
    arc_0_19_15  original_T_including_depot_unload_823  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_0_19_15  arc_capacity_699  1
    load_0_19_15  free_load_conservation_788  -1
    load_0_19_15  free_load_conservation_812  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_16  arc_capacity_701  -20
    arc_0_19_16  connected_order_arc_702  -14
    arc_0_19_16  in_degree_790  1
    arc_0_19_16  out_degree_807  1
    arc_0_19_16  original_T_including_depot_unload_823  2.0359275139821484e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_16  arc_capacity_701  1
    load_0_19_16  free_load_conservation_794  -1
    load_0_19_16  free_load_conservation_812  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_17  arc_capacity_703  -20
    arc_0_19_17  connected_order_arc_704  -14
    arc_0_19_17  in_degree_796  1
    arc_0_19_17  out_degree_807  1
    arc_0_19_17  original_T_including_depot_unload_823  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_0_19_17  arc_capacity_703  1
    load_0_19_17  free_load_conservation_800  -1
    load_0_19_17  free_load_conservation_812  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_18  arc_capacity_705  -20
    arc_0_19_18  connected_order_arc_706  -14
    arc_0_19_18  in_degree_802  1
    arc_0_19_18  out_degree_807  1
    arc_0_19_18  original_T_including_depot_unload_823  1.7947282495227562e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_18  arc_capacity_705  1
    load_0_19_18  free_load_conservation_806  -1
    load_0_19_18  free_load_conservation_812  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_20  arc_capacity_707  -20
    arc_0_19_20  connected_order_arc_708  -14
    arc_0_19_20  out_degree_807  1
    arc_0_19_20  in_degree_814  1
    arc_0_19_20  original_T_including_depot_unload_823  1.5971628811503840e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_20  arc_capacity_707  1
    load_0_19_20  free_load_conservation_812  1
    load_0_19_20  free_load_conservation_818  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_0  arc_capacity_709  -20
    arc_0_20_0  depot_return_or_bypass_735  1
    arc_0_20_0  out_degree_813  1
    arc_0_20_0  original_T_including_depot_unload_823  7.8199183337763486e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_0  arc_capacity_709  1
    load_0_20_0  free_load_conservation_818  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_1  arc_capacity_710  -20
    arc_0_20_1  connected_order_arc_711  -14
    arc_0_20_1  in_degree_737  1
    arc_0_20_1  out_degree_813  1
    arc_0_20_1  original_T_including_depot_unload_823  1.5518157315724611e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_1  arc_capacity_710  1
    load_0_20_1  segment_load_conservation_740  -1
    load_0_20_1  segment_prefix_lb_741  1
    load_0_20_1  segment_prefix_ub_742  1
    load_0_20_1  free_load_conservation_818  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_2  arc_capacity_712  -20
    arc_0_20_2  connected_order_arc_713  -14
    arc_0_20_2  in_degree_744  1
    arc_0_20_2  out_degree_813  1
    arc_0_20_2  original_T_including_depot_unload_823  1.5460798335742169e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_2  arc_capacity_712  1
    load_0_20_2  segment_load_conservation_747  -1
    load_0_20_2  segment_prefix_lb_748  1
    load_0_20_2  segment_prefix_ub_749  1
    load_0_20_2  free_load_conservation_818  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_3  arc_capacity_714  -20
    arc_0_20_3  connected_order_arc_715  -14
    arc_0_20_3  in_degree_751  1
    arc_0_20_3  out_degree_813  1
    arc_0_20_3  original_T_including_depot_unload_823  3.6797474390734163e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_3  arc_capacity_714  1
    load_0_20_3  segment_load_conservation_754  -1
    load_0_20_3  segment_prefix_lb_755  1
    load_0_20_3  segment_prefix_ub_756  1
    load_0_20_3  free_load_conservation_818  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_4  arc_capacity_716  -20
    arc_0_20_4  connected_order_arc_717  -14
    arc_0_20_4  in_degree_758  1
    arc_0_20_4  out_degree_813  1
    arc_0_20_4  original_T_including_depot_unload_823  1.5153540246292351e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_4  arc_capacity_716  1
    load_0_20_4  segment_load_conservation_761  -1
    load_0_20_4  segment_prefix_lb_762  1
    load_0_20_4  segment_prefix_ub_763  1
    load_0_20_4  free_load_conservation_818  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_5  arc_capacity_718  -20
    arc_0_20_5  connected_order_arc_719  -14
    arc_0_20_5  in_degree_765  1
    arc_0_20_5  out_degree_813  1
    arc_0_20_5  original_T_including_depot_unload_823  2.8083660458664087e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_5  arc_capacity_718  1
    load_0_20_5  segment_load_conservation_768  -1
    load_0_20_5  segment_prefix_lb_769  1
    load_0_20_5  segment_prefix_ub_770  1
    load_0_20_5  free_load_conservation_818  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_13  arc_capacity_720  -20
    arc_0_20_13  connected_order_arc_721  -14
    arc_0_20_13  in_degree_772  1
    arc_0_20_13  out_degree_813  1
    arc_0_20_13  original_T_including_depot_unload_823  3.2767382990070683e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_13  arc_capacity_720  1
    load_0_20_13  free_load_conservation_776  -1
    load_0_20_13  free_load_conservation_818  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_14  arc_capacity_722  -20
    arc_0_20_14  connected_order_arc_723  -14
    arc_0_20_14  in_degree_778  1
    arc_0_20_14  out_degree_813  1
    arc_0_20_14  original_T_including_depot_unload_823  1.1216289013953633e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_14  arc_capacity_722  1
    load_0_20_14  free_load_conservation_782  -1
    load_0_20_14  free_load_conservation_818  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_15  arc_capacity_724  -20
    arc_0_20_15  connected_order_arc_725  -14
    arc_0_20_15  in_degree_784  1
    arc_0_20_15  out_degree_813  1
    arc_0_20_15  original_T_including_depot_unload_823  2.2299340442558691e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_15  arc_capacity_724  1
    load_0_20_15  free_load_conservation_788  -1
    load_0_20_15  free_load_conservation_818  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_16  arc_capacity_726  -20
    arc_0_20_16  connected_order_arc_727  -14
    arc_0_20_16  in_degree_790  1
    arc_0_20_16  out_degree_813  1
    arc_0_20_16  original_T_including_depot_unload_823  4.5764912346489922e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_16  arc_capacity_726  1
    load_0_20_16  free_load_conservation_794  -1
    load_0_20_16  free_load_conservation_818  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_17  arc_capacity_728  -20
    arc_0_20_17  connected_order_arc_729  -14
    arc_0_20_17  in_degree_796  1
    arc_0_20_17  out_degree_813  1
    arc_0_20_17  original_T_including_depot_unload_823  1.2188376307261726e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_17  arc_capacity_728  1
    load_0_20_17  free_load_conservation_800  -1
    load_0_20_17  free_load_conservation_818  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_18  arc_capacity_730  -20
    arc_0_20_18  connected_order_arc_731  -14
    arc_0_20_18  in_degree_802  1
    arc_0_20_18  out_degree_813  1
    arc_0_20_18  original_T_including_depot_unload_823  2.7370069334295619e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_18  arc_capacity_730  1
    load_0_20_18  free_load_conservation_806  -1
    load_0_20_18  free_load_conservation_818  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_19  arc_capacity_732  -20
    arc_0_20_19  connected_order_arc_733  -14
    arc_0_20_19  in_degree_808  1
    arc_0_20_19  out_degree_813  1
    arc_0_20_19  original_T_including_depot_unload_823  1.5971628811503840e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_19  arc_capacity_732  1
    load_0_20_19  free_load_conservation_812  -1
    load_0_20_19  free_load_conservation_818  1
    visit_1_6  out_degree_1115  -1
    visit_1_6  in_degree_1116  -1
    visit_1_6  order_active_lb_1117  -1
    visit_1_6  order_active_ub_1118  -12
    order_1_6  connected_order_arc_839  -1
    order_1_6  connected_order_arc_841  -1
    order_1_6  connected_order_arc_843  -1
    order_1_6  connected_order_arc_845  -1
    order_1_6  connected_order_arc_847  -1
    order_1_6  connected_order_arc_849  -1
    order_1_6  connected_order_arc_851  -1
    order_1_6  connected_order_arc_853  -1
    order_1_6  connected_order_arc_855  -1
    order_1_6  connected_order_arc_857  -1
    order_1_6  connected_order_arc_859  -1
    order_1_6  connected_order_arc_862  1
    order_1_6  connected_order_arc_885  1
    order_1_6  connected_order_arc_908  1
    order_1_6  connected_order_arc_931  1
    order_1_6  connected_order_arc_954  1
    order_1_6  connected_order_arc_977  1
    order_1_6  connected_order_arc_1000  1
    order_1_6  connected_order_arc_1023  1
    order_1_6  connected_order_arc_1046  1
    order_1_6  connected_order_arc_1069  1
    order_1_6  connected_order_arc_1092  1
    order_1_6  order_active_lb_1117  1
    order_1_6  order_active_ub_1118  1
    order_1_6  fixed_segment_relative_order_1191  -1
    visit_1_7  out_degree_1122  -1
    visit_1_7  in_degree_1123  -1
    visit_1_7  order_active_lb_1124  -1
    visit_1_7  order_active_ub_1125  -12
    order_1_7  connected_order_arc_839  1
    order_1_7  connected_order_arc_862  -1
    order_1_7  connected_order_arc_864  -1
    order_1_7  connected_order_arc_866  -1
    order_1_7  connected_order_arc_868  -1
    order_1_7  connected_order_arc_870  -1
    order_1_7  connected_order_arc_872  -1
    order_1_7  connected_order_arc_874  -1
    order_1_7  connected_order_arc_876  -1
    order_1_7  connected_order_arc_878  -1
    order_1_7  connected_order_arc_880  -1
    order_1_7  connected_order_arc_882  -1
    order_1_7  connected_order_arc_887  1
    order_1_7  connected_order_arc_910  1
    order_1_7  connected_order_arc_933  1
    order_1_7  connected_order_arc_956  1
    order_1_7  connected_order_arc_979  1
    order_1_7  connected_order_arc_1002  1
    order_1_7  connected_order_arc_1025  1
    order_1_7  connected_order_arc_1048  1
    order_1_7  connected_order_arc_1071  1
    order_1_7  connected_order_arc_1094  1
    order_1_7  order_active_lb_1124  1
    order_1_7  order_active_ub_1125  1
    order_1_7  fixed_segment_relative_order_1191  1
    order_1_7  fixed_segment_relative_order_1192  -1
    visit_1_8  out_degree_1129  -1
    visit_1_8  in_degree_1130  -1
    visit_1_8  order_active_lb_1131  -1
    visit_1_8  order_active_ub_1132  -12
    order_1_8  connected_order_arc_841  1
    order_1_8  connected_order_arc_864  1
    order_1_8  connected_order_arc_885  -1
    order_1_8  connected_order_arc_887  -1
    order_1_8  connected_order_arc_889  -1
    order_1_8  connected_order_arc_891  -1
    order_1_8  connected_order_arc_893  -1
    order_1_8  connected_order_arc_895  -1
    order_1_8  connected_order_arc_897  -1
    order_1_8  connected_order_arc_899  -1
    order_1_8  connected_order_arc_901  -1
    order_1_8  connected_order_arc_903  -1
    order_1_8  connected_order_arc_905  -1
    order_1_8  connected_order_arc_912  1
    order_1_8  connected_order_arc_935  1
    order_1_8  connected_order_arc_958  1
    order_1_8  connected_order_arc_981  1
    order_1_8  connected_order_arc_1004  1
    order_1_8  connected_order_arc_1027  1
    order_1_8  connected_order_arc_1050  1
    order_1_8  connected_order_arc_1073  1
    order_1_8  connected_order_arc_1096  1
    order_1_8  order_active_lb_1131  1
    order_1_8  order_active_ub_1132  1
    order_1_8  fixed_segment_relative_order_1192  1
    order_1_8  fixed_segment_relative_order_1193  -1
    visit_1_9  out_degree_1136  -1
    visit_1_9  in_degree_1137  -1
    visit_1_9  order_active_lb_1138  -1
    visit_1_9  order_active_ub_1139  -12
    order_1_9  connected_order_arc_843  1
    order_1_9  connected_order_arc_866  1
    order_1_9  connected_order_arc_889  1
    order_1_9  connected_order_arc_908  -1
    order_1_9  connected_order_arc_910  -1
    order_1_9  connected_order_arc_912  -1
    order_1_9  connected_order_arc_914  -1
    order_1_9  connected_order_arc_916  -1
    order_1_9  connected_order_arc_918  -1
    order_1_9  connected_order_arc_920  -1
    order_1_9  connected_order_arc_922  -1
    order_1_9  connected_order_arc_924  -1
    order_1_9  connected_order_arc_926  -1
    order_1_9  connected_order_arc_928  -1
    order_1_9  connected_order_arc_937  1
    order_1_9  connected_order_arc_960  1
    order_1_9  connected_order_arc_983  1
    order_1_9  connected_order_arc_1006  1
    order_1_9  connected_order_arc_1029  1
    order_1_9  connected_order_arc_1052  1
    order_1_9  connected_order_arc_1075  1
    order_1_9  connected_order_arc_1098  1
    order_1_9  order_active_lb_1138  1
    order_1_9  order_active_ub_1139  1
    order_1_9  fixed_segment_relative_order_1193  1
    visit_1_13  out_degree_1143  -1
    visit_1_13  in_degree_1144  -1
    visit_1_13  order_active_lb_1145  -1
    visit_1_13  order_active_ub_1146  -12
    visit_1_13  service_visit_def_1147  -1
    order_1_13  connected_order_arc_845  1
    order_1_13  connected_order_arc_868  1
    order_1_13  connected_order_arc_891  1
    order_1_13  connected_order_arc_914  1
    order_1_13  connected_order_arc_931  -1
    order_1_13  connected_order_arc_933  -1
    order_1_13  connected_order_arc_935  -1
    order_1_13  connected_order_arc_937  -1
    order_1_13  connected_order_arc_939  -1
    order_1_13  connected_order_arc_941  -1
    order_1_13  connected_order_arc_943  -1
    order_1_13  connected_order_arc_945  -1
    order_1_13  connected_order_arc_947  -1
    order_1_13  connected_order_arc_949  -1
    order_1_13  connected_order_arc_951  -1
    order_1_13  connected_order_arc_962  1
    order_1_13  connected_order_arc_985  1
    order_1_13  connected_order_arc_1008  1
    order_1_13  connected_order_arc_1031  1
    order_1_13  connected_order_arc_1054  1
    order_1_13  connected_order_arc_1077  1
    order_1_13  connected_order_arc_1100  1
    order_1_13  order_active_lb_1145  1
    order_1_13  order_active_ub_1146  1
    visit_1_14  out_degree_1149  -1
    visit_1_14  in_degree_1150  -1
    visit_1_14  order_active_lb_1151  -1
    visit_1_14  order_active_ub_1152  -12
    visit_1_14  service_visit_def_1153  -1
    order_1_14  connected_order_arc_847  1
    order_1_14  connected_order_arc_870  1
    order_1_14  connected_order_arc_893  1
    order_1_14  connected_order_arc_916  1
    order_1_14  connected_order_arc_939  1
    order_1_14  connected_order_arc_954  -1
    order_1_14  connected_order_arc_956  -1
    order_1_14  connected_order_arc_958  -1
    order_1_14  connected_order_arc_960  -1
    order_1_14  connected_order_arc_962  -1
    order_1_14  connected_order_arc_964  -1
    order_1_14  connected_order_arc_966  -1
    order_1_14  connected_order_arc_968  -1
    order_1_14  connected_order_arc_970  -1
    order_1_14  connected_order_arc_972  -1
    order_1_14  connected_order_arc_974  -1
    order_1_14  connected_order_arc_987  1
    order_1_14  connected_order_arc_1010  1
    order_1_14  connected_order_arc_1033  1
    order_1_14  connected_order_arc_1056  1
    order_1_14  connected_order_arc_1079  1
    order_1_14  connected_order_arc_1102  1
    order_1_14  order_active_lb_1151  1
    order_1_14  order_active_ub_1152  1
    visit_1_15  out_degree_1155  -1
    visit_1_15  in_degree_1156  -1
    visit_1_15  order_active_lb_1157  -1
    visit_1_15  order_active_ub_1158  -12
    visit_1_15  service_visit_def_1159  -1
    order_1_15  connected_order_arc_849  1
    order_1_15  connected_order_arc_872  1
    order_1_15  connected_order_arc_895  1
    order_1_15  connected_order_arc_918  1
    order_1_15  connected_order_arc_941  1
    order_1_15  connected_order_arc_964  1
    order_1_15  connected_order_arc_977  -1
    order_1_15  connected_order_arc_979  -1
    order_1_15  connected_order_arc_981  -1
    order_1_15  connected_order_arc_983  -1
    order_1_15  connected_order_arc_985  -1
    order_1_15  connected_order_arc_987  -1
    order_1_15  connected_order_arc_989  -1
    order_1_15  connected_order_arc_991  -1
    order_1_15  connected_order_arc_993  -1
    order_1_15  connected_order_arc_995  -1
    order_1_15  connected_order_arc_997  -1
    order_1_15  connected_order_arc_1012  1
    order_1_15  connected_order_arc_1035  1
    order_1_15  connected_order_arc_1058  1
    order_1_15  connected_order_arc_1081  1
    order_1_15  connected_order_arc_1104  1
    order_1_15  order_active_lb_1157  1
    order_1_15  order_active_ub_1158  1
    visit_1_16  out_degree_1161  -1
    visit_1_16  in_degree_1162  -1
    visit_1_16  order_active_lb_1163  -1
    visit_1_16  order_active_ub_1164  -12
    visit_1_16  service_visit_def_1165  -1
    order_1_16  connected_order_arc_851  1
    order_1_16  connected_order_arc_874  1
    order_1_16  connected_order_arc_897  1
    order_1_16  connected_order_arc_920  1
    order_1_16  connected_order_arc_943  1
    order_1_16  connected_order_arc_966  1
    order_1_16  connected_order_arc_989  1
    order_1_16  connected_order_arc_1000  -1
    order_1_16  connected_order_arc_1002  -1
    order_1_16  connected_order_arc_1004  -1
    order_1_16  connected_order_arc_1006  -1
    order_1_16  connected_order_arc_1008  -1
    order_1_16  connected_order_arc_1010  -1
    order_1_16  connected_order_arc_1012  -1
    order_1_16  connected_order_arc_1014  -1
    order_1_16  connected_order_arc_1016  -1
    order_1_16  connected_order_arc_1018  -1
    order_1_16  connected_order_arc_1020  -1
    order_1_16  connected_order_arc_1037  1
    order_1_16  connected_order_arc_1060  1
    order_1_16  connected_order_arc_1083  1
    order_1_16  connected_order_arc_1106  1
    order_1_16  order_active_lb_1163  1
    order_1_16  order_active_ub_1164  1
    visit_1_17  out_degree_1167  -1
    visit_1_17  in_degree_1168  -1
    visit_1_17  order_active_lb_1169  -1
    visit_1_17  order_active_ub_1170  -12
    visit_1_17  service_visit_def_1171  -1
    order_1_17  connected_order_arc_853  1
    order_1_17  connected_order_arc_876  1
    order_1_17  connected_order_arc_899  1
    order_1_17  connected_order_arc_922  1
    order_1_17  connected_order_arc_945  1
    order_1_17  connected_order_arc_968  1
    order_1_17  connected_order_arc_991  1
    order_1_17  connected_order_arc_1014  1
    order_1_17  connected_order_arc_1023  -1
    order_1_17  connected_order_arc_1025  -1
    order_1_17  connected_order_arc_1027  -1
    order_1_17  connected_order_arc_1029  -1
    order_1_17  connected_order_arc_1031  -1
    order_1_17  connected_order_arc_1033  -1
    order_1_17  connected_order_arc_1035  -1
    order_1_17  connected_order_arc_1037  -1
    order_1_17  connected_order_arc_1039  -1
    order_1_17  connected_order_arc_1041  -1
    order_1_17  connected_order_arc_1043  -1
    order_1_17  connected_order_arc_1062  1
    order_1_17  connected_order_arc_1085  1
    order_1_17  connected_order_arc_1108  1
    order_1_17  order_active_lb_1169  1
    order_1_17  order_active_ub_1170  1
    visit_1_18  out_degree_1173  -1
    visit_1_18  in_degree_1174  -1
    visit_1_18  order_active_lb_1175  -1
    visit_1_18  order_active_ub_1176  -12
    visit_1_18  service_visit_def_1177  -1
    order_1_18  connected_order_arc_855  1
    order_1_18  connected_order_arc_878  1
    order_1_18  connected_order_arc_901  1
    order_1_18  connected_order_arc_924  1
    order_1_18  connected_order_arc_947  1
    order_1_18  connected_order_arc_970  1
    order_1_18  connected_order_arc_993  1
    order_1_18  connected_order_arc_1016  1
    order_1_18  connected_order_arc_1039  1
    order_1_18  connected_order_arc_1046  -1
    order_1_18  connected_order_arc_1048  -1
    order_1_18  connected_order_arc_1050  -1
    order_1_18  connected_order_arc_1052  -1
    order_1_18  connected_order_arc_1054  -1
    order_1_18  connected_order_arc_1056  -1
    order_1_18  connected_order_arc_1058  -1
    order_1_18  connected_order_arc_1060  -1
    order_1_18  connected_order_arc_1062  -1
    order_1_18  connected_order_arc_1064  -1
    order_1_18  connected_order_arc_1066  -1
    order_1_18  connected_order_arc_1087  1
    order_1_18  connected_order_arc_1110  1
    order_1_18  order_active_lb_1175  1
    order_1_18  order_active_ub_1176  1
    visit_1_19  out_degree_1179  -1
    visit_1_19  in_degree_1180  -1
    visit_1_19  order_active_lb_1181  -1
    visit_1_19  order_active_ub_1182  -12
    visit_1_19  service_visit_def_1183  -1
    order_1_19  connected_order_arc_857  1
    order_1_19  connected_order_arc_880  1
    order_1_19  connected_order_arc_903  1
    order_1_19  connected_order_arc_926  1
    order_1_19  connected_order_arc_949  1
    order_1_19  connected_order_arc_972  1
    order_1_19  connected_order_arc_995  1
    order_1_19  connected_order_arc_1018  1
    order_1_19  connected_order_arc_1041  1
    order_1_19  connected_order_arc_1064  1
    order_1_19  connected_order_arc_1069  -1
    order_1_19  connected_order_arc_1071  -1
    order_1_19  connected_order_arc_1073  -1
    order_1_19  connected_order_arc_1075  -1
    order_1_19  connected_order_arc_1077  -1
    order_1_19  connected_order_arc_1079  -1
    order_1_19  connected_order_arc_1081  -1
    order_1_19  connected_order_arc_1083  -1
    order_1_19  connected_order_arc_1085  -1
    order_1_19  connected_order_arc_1087  -1
    order_1_19  connected_order_arc_1089  -1
    order_1_19  connected_order_arc_1112  1
    order_1_19  order_active_lb_1181  1
    order_1_19  order_active_ub_1182  1
    visit_1_20  out_degree_1185  -1
    visit_1_20  in_degree_1186  -1
    visit_1_20  order_active_lb_1187  -1
    visit_1_20  order_active_ub_1188  -12
    visit_1_20  service_visit_def_1189  -1
    order_1_20  connected_order_arc_859  1
    order_1_20  connected_order_arc_882  1
    order_1_20  connected_order_arc_905  1
    order_1_20  connected_order_arc_928  1
    order_1_20  connected_order_arc_951  1
    order_1_20  connected_order_arc_974  1
    order_1_20  connected_order_arc_997  1
    order_1_20  connected_order_arc_1020  1
    order_1_20  connected_order_arc_1043  1
    order_1_20  connected_order_arc_1066  1
    order_1_20  connected_order_arc_1089  1
    order_1_20  connected_order_arc_1092  -1
    order_1_20  connected_order_arc_1094  -1
    order_1_20  connected_order_arc_1096  -1
    order_1_20  connected_order_arc_1098  -1
    order_1_20  connected_order_arc_1100  -1
    order_1_20  connected_order_arc_1102  -1
    order_1_20  connected_order_arc_1104  -1
    order_1_20  connected_order_arc_1106  -1
    order_1_20  connected_order_arc_1108  -1
    order_1_20  connected_order_arc_1110  -1
    order_1_20  connected_order_arc_1112  -1
    order_1_20  order_active_lb_1187  1
    order_1_20  order_active_ub_1188  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_0  arc_capacity_824  -25
    arc_1_0_0  depot_departure_or_bypass_1113  1
    arc_1_0_0  depot_return_or_bypass_1114  1
    MARKER    'MARKER'                 'INTEND'
    load_1_0_0  arc_capacity_824  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_6  arc_capacity_825  -25
    arc_1_0_6  depot_departure_or_bypass_1113  1
    arc_1_0_6  in_degree_1116  1
    arc_1_0_6  original_T_including_depot_unload_1194  1.1935953747864173e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_6  arc_capacity_825  1
    load_1_0_6  segment_load_conservation_1119  -1
    load_1_0_6  segment_prefix_lb_1120  1
    load_1_0_6  segment_prefix_ub_1121  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_7  arc_capacity_826  -25
    arc_1_0_7  depot_departure_or_bypass_1113  1
    arc_1_0_7  in_degree_1123  1
    arc_1_0_7  original_T_including_depot_unload_1194  1.4834116102542102e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_7  arc_capacity_826  1
    load_1_0_7  segment_load_conservation_1126  -1
    load_1_0_7  segment_prefix_lb_1127  1
    load_1_0_7  segment_prefix_ub_1128  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_8  arc_capacity_827  -25
    arc_1_0_8  depot_departure_or_bypass_1113  1
    arc_1_0_8  in_degree_1130  1
    arc_1_0_8  original_T_including_depot_unload_1194  5.4911852608328161e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_8  arc_capacity_827  1
    load_1_0_8  segment_load_conservation_1133  -1
    load_1_0_8  segment_prefix_lb_1134  1
    load_1_0_8  segment_prefix_ub_1135  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_9  arc_capacity_828  -25
    arc_1_0_9  depot_departure_or_bypass_1113  1
    arc_1_0_9  in_degree_1137  1
    arc_1_0_9  original_T_including_depot_unload_1194  3.5061909388980052e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_9  arc_capacity_828  1
    load_1_0_9  segment_load_conservation_1140  -1
    load_1_0_9  segment_prefix_lb_1141  1
    load_1_0_9  segment_prefix_ub_1142  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_13  arc_capacity_829  -25
    arc_1_0_13  depot_departure_or_bypass_1113  1
    arc_1_0_13  in_degree_1144  1
    arc_1_0_13  original_T_including_depot_unload_1194  1.1055042743585939e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_13  arc_capacity_829  1
    load_1_0_13  free_load_conservation_1148  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_14  arc_capacity_830  -25
    arc_1_0_14  depot_departure_or_bypass_1113  1
    arc_1_0_14  in_degree_1150  1
    arc_1_0_14  original_T_including_depot_unload_1194  885.819758595088
    MARKER    'MARKER'                 'INTEND'
    load_1_0_14  arc_capacity_830  1
    load_1_0_14  free_load_conservation_1154  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_15  arc_capacity_831  -25
    arc_1_0_15  depot_departure_or_bypass_1113  1
    arc_1_0_15  in_degree_1156  1
    arc_1_0_15  original_T_including_depot_unload_1194  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_15  arc_capacity_831  1
    load_1_0_15  free_load_conservation_1160  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_16  arc_capacity_832  -25
    arc_1_0_16  depot_departure_or_bypass_1113  1
    arc_1_0_16  in_degree_1162  1
    arc_1_0_16  original_T_including_depot_unload_1194  1163.36883938708
    MARKER    'MARKER'                 'INTEND'
    load_1_0_16  arc_capacity_832  1
    load_1_0_16  free_load_conservation_1166  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_17  arc_capacity_833  -25
    arc_1_0_17  depot_departure_or_bypass_1113  1
    arc_1_0_17  in_degree_1168  1
    arc_1_0_17  original_T_including_depot_unload_1194  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_17  arc_capacity_833  1
    load_1_0_17  free_load_conservation_1172  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_18  arc_capacity_834  -25
    arc_1_0_18  depot_departure_or_bypass_1113  1
    arc_1_0_18  in_degree_1174  1
    arc_1_0_18  original_T_including_depot_unload_1194  9.1137190274562636e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_18  arc_capacity_834  1
    load_1_0_18  free_load_conservation_1178  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_19  arc_capacity_835  -25
    arc_1_0_19  depot_departure_or_bypass_1113  1
    arc_1_0_19  in_degree_1180  1
    arc_1_0_19  original_T_including_depot_unload_1194  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_19  arc_capacity_835  1
    load_1_0_19  free_load_conservation_1184  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_20  arc_capacity_836  -25
    arc_1_0_20  depot_departure_or_bypass_1113  1
    arc_1_0_20  in_degree_1186  1
    arc_1_0_20  original_T_including_depot_unload_1194  7.8199183337763486e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_20  arc_capacity_836  1
    load_1_0_20  free_load_conservation_1190  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_0  arc_capacity_837  -25
    arc_1_6_0  depot_return_or_bypass_1114  1
    arc_1_6_0  out_degree_1115  1
    arc_1_6_0  original_T_including_depot_unload_1194  7.2047755761928431e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_0  arc_capacity_837  1
    load_1_6_0  segment_load_conservation_1119  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_7  arc_capacity_838  -25
    arc_1_6_7  connected_order_arc_839  -13
    arc_1_6_7  out_degree_1115  1
    arc_1_6_7  in_degree_1123  1
    arc_1_6_7  original_T_including_depot_unload_1194  1.0359917537364215e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_7  arc_capacity_838  1
    load_1_6_7  segment_load_conservation_1119  1
    load_1_6_7  segment_load_conservation_1126  -1
    load_1_6_7  segment_prefix_lb_1127  1
    load_1_6_7  segment_prefix_ub_1128  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_8  arc_capacity_840  -25
    arc_1_6_8  connected_order_arc_841  -13
    arc_1_6_8  out_degree_1115  1
    arc_1_6_8  in_degree_1130  1
    arc_1_6_8  original_T_including_depot_unload_1194  2.9662284735332634e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_8  arc_capacity_840  1
    load_1_6_8  segment_load_conservation_1119  1
    load_1_6_8  segment_load_conservation_1133  -1
    load_1_6_8  segment_prefix_lb_1134  1
    load_1_6_8  segment_prefix_ub_1135  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_9  arc_capacity_842  -25
    arc_1_6_9  connected_order_arc_843  -13
    arc_1_6_9  out_degree_1115  1
    arc_1_6_9  in_degree_1137  1
    arc_1_6_9  original_T_including_depot_unload_1194  3.7747736142736670e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_9  arc_capacity_842  1
    load_1_6_9  segment_load_conservation_1119  1
    load_1_6_9  segment_load_conservation_1140  -1
    load_1_6_9  segment_prefix_lb_1141  1
    load_1_6_9  segment_prefix_ub_1142  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_13  arc_capacity_844  -25
    arc_1_6_13  connected_order_arc_845  -13
    arc_1_6_13  out_degree_1115  1
    arc_1_6_13  in_degree_1144  1
    arc_1_6_13  original_T_including_depot_unload_1194  8.5386479957462541e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_13  arc_capacity_844  1
    load_1_6_13  segment_load_conservation_1119  1
    load_1_6_13  free_load_conservation_1148  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_14  arc_capacity_846  -25
    arc_1_6_14  connected_order_arc_847  -13
    arc_1_6_14  out_degree_1115  1
    arc_1_6_14  in_degree_1150  1
    arc_1_6_14  original_T_including_depot_unload_1194  7.0547985627601940e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_14  arc_capacity_846  1
    load_1_6_14  segment_load_conservation_1119  1
    load_1_6_14  free_load_conservation_1154  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_15  arc_capacity_848  -25
    arc_1_6_15  connected_order_arc_849  -13
    arc_1_6_15  out_degree_1115  1
    arc_1_6_15  in_degree_1156  1
    arc_1_6_15  original_T_including_depot_unload_1194  2.2682175936128497e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_15  arc_capacity_848  1
    load_1_6_15  segment_load_conservation_1119  1
    load_1_6_15  free_load_conservation_1160  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_16  arc_capacity_850  -25
    arc_1_6_16  connected_order_arc_851  -13
    arc_1_6_16  out_degree_1115  1
    arc_1_6_16  in_degree_1162  1
    arc_1_6_16  original_T_including_depot_unload_1194  7.4895433191723123e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_16  arc_capacity_850  1
    load_1_6_16  segment_load_conservation_1119  1
    load_1_6_16  free_load_conservation_1166  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_17  arc_capacity_852  -25
    arc_1_6_17  connected_order_arc_853  -13
    arc_1_6_17  out_degree_1115  1
    arc_1_6_17  in_degree_1168  1
    arc_1_6_17  original_T_including_depot_unload_1194  1.0198535056659911e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_17  arc_capacity_852  1
    load_1_6_17  segment_load_conservation_1119  1
    load_1_6_17  free_load_conservation_1172  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_18  arc_capacity_854  -25
    arc_1_6_18  connected_order_arc_855  -13
    arc_1_6_18  out_degree_1115  1
    arc_1_6_18  in_degree_1174  1
    arc_1_6_18  original_T_including_depot_unload_1194  5.5273606659162363e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_18  arc_capacity_854  1
    load_1_6_18  segment_load_conservation_1119  1
    load_1_6_18  free_load_conservation_1178  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_19  arc_capacity_856  -25
    arc_1_6_19  connected_order_arc_857  -13
    arc_1_6_19  out_degree_1115  1
    arc_1_6_19  in_degree_1180  1
    arc_1_6_19  original_T_including_depot_unload_1194  1.6437981048195304e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_19  arc_capacity_856  1
    load_1_6_19  segment_load_conservation_1119  1
    load_1_6_19  free_load_conservation_1184  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_20  arc_capacity_858  -25
    arc_1_6_20  connected_order_arc_859  -13
    arc_1_6_20  out_degree_1115  1
    arc_1_6_20  in_degree_1186  1
    arc_1_6_20  original_T_including_depot_unload_1194  6.8151832047278333e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_20  arc_capacity_858  1
    load_1_6_20  segment_load_conservation_1119  1
    load_1_6_20  free_load_conservation_1190  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_0  arc_capacity_860  -25
    arc_1_7_0  depot_return_or_bypass_1114  1
    arc_1_7_0  out_degree_1122  1
    arc_1_7_0  original_T_including_depot_unload_1194  1.4834116102542102e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_0  arc_capacity_860  1
    load_1_7_0  segment_load_conservation_1126  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_6  arc_capacity_861  -25
    arc_1_7_6  connected_order_arc_862  -13
    arc_1_7_6  in_degree_1116  1
    arc_1_7_6  out_degree_1122  1
    arc_1_7_6  original_T_including_depot_unload_1194  2.1016283653335277e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_6  arc_capacity_861  1
    load_1_7_6  segment_load_conservation_1119  -1
    load_1_7_6  segment_prefix_lb_1120  1
    load_1_7_6  segment_prefix_ub_1121  1
    load_1_7_6  segment_load_conservation_1126  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_8  arc_capacity_863  -25
    arc_1_7_8  connected_order_arc_864  -13
    arc_1_7_8  out_degree_1122  1
    arc_1_7_8  in_degree_1130  1
    arc_1_7_8  original_T_including_depot_unload_1194  9.7352441264247466e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_8  arc_capacity_863  1
    load_1_7_8  segment_load_conservation_1126  1
    load_1_7_8  segment_load_conservation_1133  -1
    load_1_7_8  segment_prefix_lb_1134  1
    load_1_7_8  segment_prefix_ub_1135  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_9  arc_capacity_865  -25
    arc_1_7_9  connected_order_arc_866  -13
    arc_1_7_9  out_degree_1122  1
    arc_1_7_9  in_degree_1137  1
    arc_1_7_9  original_T_including_depot_unload_1194  1.2769578074048923e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_9  arc_capacity_865  1
    load_1_7_9  segment_load_conservation_1126  1
    load_1_7_9  segment_load_conservation_1140  -1
    load_1_7_9  segment_prefix_lb_1141  1
    load_1_7_9  segment_prefix_ub_1142  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_13  arc_capacity_867  -25
    arc_1_7_13  connected_order_arc_868  -13
    arc_1_7_13  out_degree_1122  1
    arc_1_7_13  in_degree_1144  1
    arc_1_7_13  original_T_including_depot_unload_1194  4.4971477761144257e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_13  arc_capacity_867  1
    load_1_7_13  segment_load_conservation_1126  1
    load_1_7_13  free_load_conservation_1148  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_14  arc_capacity_869  -25
    arc_1_7_14  connected_order_arc_870  -13
    arc_1_7_14  out_degree_1122  1
    arc_1_7_14  in_degree_1150  1
    arc_1_7_14  original_T_including_depot_unload_1194  6.3817162287710391e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_14  arc_capacity_869  1
    load_1_7_14  segment_load_conservation_1126  1
    load_1_7_14  free_load_conservation_1154  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_15  arc_capacity_871  -25
    arc_1_7_15  connected_order_arc_872  -13
    arc_1_7_15  out_degree_1122  1
    arc_1_7_15  in_degree_1156  1
    arc_1_7_15  original_T_including_depot_unload_1194  2.9790156048453791e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_15  arc_capacity_871  1
    load_1_7_15  segment_load_conservation_1126  1
    load_1_7_15  free_load_conservation_1160  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_16  arc_capacity_873  -25
    arc_1_7_16  connected_order_arc_874  -13
    arc_1_7_16  out_degree_1122  1
    arc_1_7_16  in_degree_1162  1
    arc_1_7_16  original_T_including_depot_unload_1194  3.2105135706875041e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_16  arc_capacity_873  1
    load_1_7_16  segment_load_conservation_1126  1
    load_1_7_16  free_load_conservation_1166  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_17  arc_capacity_875  -25
    arc_1_7_17  connected_order_arc_876  -13
    arc_1_7_17  out_degree_1122  1
    arc_1_7_17  in_degree_1168  1
    arc_1_7_17  original_T_including_depot_unload_1194  1.9029099398713563e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_17  arc_capacity_875  1
    load_1_7_17  segment_load_conservation_1126  1
    load_1_7_17  free_load_conservation_1172  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_18  arc_capacity_877  -25
    arc_1_7_18  connected_order_arc_878  -13
    arc_1_7_18  out_degree_1122  1
    arc_1_7_18  in_degree_1174  1
    arc_1_7_18  original_T_including_depot_unload_1194  5.7393004225094967e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_18  arc_capacity_877  1
    load_1_7_18  segment_load_conservation_1126  1
    load_1_7_18  free_load_conservation_1178  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_19  arc_capacity_879  -25
    arc_1_7_19  connected_order_arc_880  -13
    arc_1_7_19  out_degree_1122  1
    arc_1_7_19  in_degree_1180  1
    arc_1_7_19  original_T_including_depot_unload_1194  2.3444750474890211e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_19  arc_capacity_879  1
    load_1_7_19  segment_load_conservation_1126  1
    load_1_7_19  free_load_conservation_1184  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_20  arc_capacity_881  -25
    arc_1_7_20  connected_order_arc_882  -13
    arc_1_7_20  out_degree_1122  1
    arc_1_7_20  in_degree_1186  1
    arc_1_7_20  original_T_including_depot_unload_1194  7.4980220943945562e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_20  arc_capacity_881  1
    load_1_7_20  segment_load_conservation_1126  1
    load_1_7_20  free_load_conservation_1190  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_0  arc_capacity_883  -25
    arc_1_8_0  depot_return_or_bypass_1114  1
    arc_1_8_0  out_degree_1129  1
    arc_1_8_0  original_T_including_depot_unload_1194  5.4911852608328161e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_0  arc_capacity_883  1
    load_1_8_0  segment_load_conservation_1133  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_6  arc_capacity_884  -25
    arc_1_8_6  connected_order_arc_885  -13
    arc_1_8_6  in_degree_1116  1
    arc_1_8_6  out_degree_1129  1
    arc_1_8_6  original_T_including_depot_unload_1194  1.2739580769060942e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_6  arc_capacity_884  1
    load_1_8_6  segment_load_conservation_1119  -1
    load_1_8_6  segment_prefix_lb_1120  1
    load_1_8_6  segment_prefix_ub_1121  1
    load_1_8_6  segment_load_conservation_1133  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_7  arc_capacity_886  -25
    arc_1_8_7  connected_order_arc_887  -13
    arc_1_8_7  in_degree_1123  1
    arc_1_8_7  out_degree_1129  1
    arc_1_8_7  original_T_including_depot_unload_1194  9.7352441264247466e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_7  arc_capacity_886  1
    load_1_8_7  segment_load_conservation_1126  -1
    load_1_8_7  segment_prefix_lb_1127  1
    load_1_8_7  segment_prefix_ub_1128  1
    load_1_8_7  segment_load_conservation_1133  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_9  arc_capacity_888  -25
    arc_1_8_9  connected_order_arc_889  -13
    arc_1_8_9  out_degree_1129  1
    arc_1_8_9  in_degree_1137  1
    arc_1_8_9  original_T_including_depot_unload_1194  3.0614301781508658e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_9  arc_capacity_888  1
    load_1_8_9  segment_load_conservation_1133  1
    load_1_8_9  segment_load_conservation_1140  -1
    load_1_8_9  segment_prefix_lb_1141  1
    load_1_8_9  segment_prefix_ub_1142  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_13  arc_capacity_890  -25
    arc_1_8_13  connected_order_arc_891  -13
    arc_1_8_13  out_degree_1129  1
    arc_1_8_13  in_degree_1144  1
    arc_1_8_13  original_T_including_depot_unload_1194  674.735556064576
    MARKER    'MARKER'                 'INTEND'
    load_1_8_13  arc_capacity_890  1
    load_1_8_13  segment_load_conservation_1133  1
    load_1_8_13  free_load_conservation_1148  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_14  arc_capacity_892  -25
    arc_1_8_14  connected_order_arc_893  -13
    arc_1_8_14  out_degree_1129  1
    arc_1_8_14  in_degree_1150  1
    arc_1_8_14  original_T_including_depot_unload_1194  4.8212282798659248e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_14  arc_capacity_892  1
    load_1_8_14  segment_load_conservation_1133  1
    load_1_8_14  free_load_conservation_1154  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_15  arc_capacity_894  -25
    arc_1_8_15  connected_order_arc_895  -13
    arc_1_8_15  out_degree_1129  1
    arc_1_8_15  in_degree_1156  1
    arc_1_8_15  original_T_including_depot_unload_1194  2.1109553693139742e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_15  arc_capacity_894  1
    load_1_8_15  segment_load_conservation_1133  1
    load_1_8_15  free_load_conservation_1160  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_16  arc_capacity_896  -25
    arc_1_8_16  connected_order_arc_897  -13
    arc_1_8_16  out_degree_1129  1
    arc_1_8_16  in_degree_1162  1
    arc_1_8_16  original_T_including_depot_unload_1194  6.5484387194508088e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_16  arc_capacity_896  1
    load_1_8_16  segment_load_conservation_1133  1
    load_1_8_16  free_load_conservation_1166  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_17  arc_capacity_898  -25
    arc_1_8_17  connected_order_arc_899  -13
    arc_1_8_17  out_degree_1129  1
    arc_1_8_17  in_degree_1168  1
    arc_1_8_17  original_T_including_depot_unload_1194  9.3836915476275669e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_17  arc_capacity_898  1
    load_1_8_17  segment_load_conservation_1133  1
    load_1_8_17  free_load_conservation_1172  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_18  arc_capacity_900  -25
    arc_1_8_18  connected_order_arc_901  -13
    arc_1_8_18  out_degree_1129  1
    arc_1_8_18  in_degree_1174  1
    arc_1_8_18  original_T_including_depot_unload_1194  4.0739926745194407e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_18  arc_capacity_900  1
    load_1_8_18  segment_load_conservation_1133  1
    load_1_8_18  free_load_conservation_1178  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_19  arc_capacity_902  -25
    arc_1_8_19  connected_order_arc_903  -13
    arc_1_8_19  out_degree_1129  1
    arc_1_8_19  in_degree_1180  1
    arc_1_8_19  original_T_including_depot_unload_1194  1.4738339199468992e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_19  arc_capacity_902  1
    load_1_8_19  segment_load_conservation_1133  1
    load_1_8_19  free_load_conservation_1184  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_20  arc_capacity_904  -25
    arc_1_8_20  connected_order_arc_905  -13
    arc_1_8_20  out_degree_1129  1
    arc_1_8_20  in_degree_1186  1
    arc_1_8_20  original_T_including_depot_unload_1194  4.2580398435897172e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_20  arc_capacity_904  1
    load_1_8_20  segment_load_conservation_1133  1
    load_1_8_20  free_load_conservation_1190  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_0  arc_capacity_906  -25
    arc_1_9_0  depot_return_or_bypass_1114  1
    arc_1_9_0  out_degree_1136  1
    arc_1_9_0  original_T_including_depot_unload_1194  3.5061909388980052e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_0  arc_capacity_906  1
    load_1_9_0  segment_load_conservation_1140  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_6  arc_capacity_907  -25
    arc_1_9_6  connected_order_arc_908  -13
    arc_1_9_6  in_degree_1116  1
    arc_1_9_6  out_degree_1136  1
    arc_1_9_6  original_T_including_depot_unload_1194  1.0313568965059917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_6  arc_capacity_907  1
    load_1_9_6  segment_load_conservation_1119  -1
    load_1_9_6  segment_prefix_lb_1120  1
    load_1_9_6  segment_prefix_ub_1121  1
    load_1_9_6  segment_load_conservation_1140  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_7  arc_capacity_909  -25
    arc_1_9_7  connected_order_arc_910  -13
    arc_1_9_7  in_degree_1123  1
    arc_1_9_7  out_degree_1136  1
    arc_1_9_7  original_T_including_depot_unload_1194  1.2769578074048923e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_7  arc_capacity_909  1
    load_1_9_7  segment_load_conservation_1126  -1
    load_1_9_7  segment_prefix_lb_1127  1
    load_1_9_7  segment_prefix_ub_1128  1
    load_1_9_7  segment_load_conservation_1140  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_8  arc_capacity_911  -25
    arc_1_9_8  connected_order_arc_912  -13
    arc_1_9_8  in_degree_1130  1
    arc_1_9_8  out_degree_1136  1
    arc_1_9_8  original_T_including_depot_unload_1194  3.0614301781508658e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_8  arc_capacity_911  1
    load_1_9_8  segment_load_conservation_1133  -1
    load_1_9_8  segment_prefix_lb_1134  1
    load_1_9_8  segment_prefix_ub_1135  1
    load_1_9_8  segment_load_conservation_1140  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_13  arc_capacity_913  -25
    arc_1_9_13  connected_order_arc_914  -13
    arc_1_9_13  out_degree_1136  1
    arc_1_9_13  in_degree_1144  1
    arc_1_9_13  original_T_including_depot_unload_1194  9.7349243097924864e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_13  arc_capacity_913  1
    load_1_9_13  segment_load_conservation_1140  1
    load_1_9_13  free_load_conservation_1148  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_14  arc_capacity_915  -25
    arc_1_9_14  connected_order_arc_916  -13
    arc_1_9_14  out_degree_1136  1
    arc_1_9_14  in_degree_1150  1
    arc_1_9_14  original_T_including_depot_unload_1194  7.6932985985964615e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_14  arc_capacity_915  1
    load_1_9_14  segment_load_conservation_1140  1
    load_1_9_14  free_load_conservation_1154  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_15  arc_capacity_917  -25
    arc_1_9_15  connected_order_arc_918  -13
    arc_1_9_15  out_degree_1136  1
    arc_1_9_15  in_degree_1156  1
    arc_1_9_15  original_T_including_depot_unload_1194  1.8911324761641883e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_15  arc_capacity_917  1
    load_1_9_15  segment_load_conservation_1140  1
    load_1_9_15  free_load_conservation_1160  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_16  arc_capacity_919  -25
    arc_1_9_16  connected_order_arc_920  -13
    arc_1_9_16  out_degree_1136  1
    arc_1_9_16  in_degree_1162  1
    arc_1_9_16  original_T_including_depot_unload_1194  9.5986282589427344e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_16  arc_capacity_919  1
    load_1_9_16  segment_load_conservation_1140  1
    load_1_9_16  free_load_conservation_1166  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_17  arc_capacity_921  -25
    arc_1_9_17  connected_order_arc_922  -13
    arc_1_9_17  out_degree_1136  1
    arc_1_9_17  in_degree_1168  1
    arc_1_9_17  original_T_including_depot_unload_1194  6.5869285599668615e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_17  arc_capacity_921  1
    load_1_9_17  segment_load_conservation_1140  1
    load_1_9_17  free_load_conservation_1172  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_18  arc_capacity_923  -25
    arc_1_9_18  connected_order_arc_924  -13
    arc_1_9_18  out_degree_1136  1
    arc_1_9_18  in_degree_1174  1
    arc_1_9_18  original_T_including_depot_unload_1194  7.1354165601672594e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_18  arc_capacity_923  1
    load_1_9_18  segment_load_conservation_1140  1
    load_1_9_18  free_load_conservation_1178  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_19  arc_capacity_925  -25
    arc_1_9_19  connected_order_arc_926  -13
    arc_1_9_19  out_degree_1136  1
    arc_1_9_19  in_degree_1180  1
    arc_1_9_19  original_T_including_depot_unload_1194  1.2665309635243570e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_19  arc_capacity_925  1
    load_1_9_19  segment_load_conservation_1140  1
    load_1_9_19  free_load_conservation_1184  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_20  arc_capacity_927  -25
    arc_1_9_20  connected_order_arc_928  -13
    arc_1_9_20  out_degree_1136  1
    arc_1_9_20  in_degree_1186  1
    arc_1_9_20  original_T_including_depot_unload_1194  6.9292160543761986e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_20  arc_capacity_927  1
    load_1_9_20  segment_load_conservation_1140  1
    load_1_9_20  free_load_conservation_1190  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_0  arc_capacity_929  -25
    arc_1_13_0  depot_return_or_bypass_1114  1
    arc_1_13_0  out_degree_1143  1
    arc_1_13_0  original_T_including_depot_unload_1194  1.1055042743585939e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_0  arc_capacity_929  1
    load_1_13_0  free_load_conservation_1148  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_6  arc_capacity_930  -25
    arc_1_13_6  connected_order_arc_931  -13
    arc_1_13_6  in_degree_1116  1
    arc_1_13_6  out_degree_1143  1
    arc_1_13_6  original_T_including_depot_unload_1194  1.9270569168668533e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_6  arc_capacity_930  1
    load_1_13_6  segment_load_conservation_1119  -1
    load_1_13_6  segment_prefix_lb_1120  1
    load_1_13_6  segment_prefix_ub_1121  1
    load_1_13_6  free_load_conservation_1148  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_7  arc_capacity_932  -25
    arc_1_13_7  connected_order_arc_933  -13
    arc_1_13_7  in_degree_1123  1
    arc_1_13_7  out_degree_1143  1
    arc_1_13_7  original_T_including_depot_unload_1194  4.4971477761144257e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_7  arc_capacity_932  1
    load_1_13_7  segment_load_conservation_1126  -1
    load_1_13_7  segment_prefix_lb_1127  1
    load_1_13_7  segment_prefix_ub_1128  1
    load_1_13_7  free_load_conservation_1148  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_8  arc_capacity_934  -25
    arc_1_13_8  connected_order_arc_935  -13
    arc_1_13_8  in_degree_1130  1
    arc_1_13_8  out_degree_1143  1
    arc_1_13_8  original_T_including_depot_unload_1194  674.735556064576
    MARKER    'MARKER'                 'INTEND'
    load_1_13_8  arc_capacity_934  1
    load_1_13_8  segment_load_conservation_1133  -1
    load_1_13_8  segment_prefix_lb_1134  1
    load_1_13_8  segment_prefix_ub_1135  1
    load_1_13_8  free_load_conservation_1148  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_9  arc_capacity_936  -25
    arc_1_13_9  connected_order_arc_937  -13
    arc_1_13_9  in_degree_1137  1
    arc_1_13_9  out_degree_1143  1
    arc_1_13_9  original_T_including_depot_unload_1194  9.7349243097924864e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_9  arc_capacity_936  1
    load_1_13_9  segment_load_conservation_1140  -1
    load_1_13_9  segment_prefix_lb_1141  1
    load_1_13_9  segment_prefix_ub_1142  1
    load_1_13_9  free_load_conservation_1148  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_14  arc_capacity_938  -25
    arc_1_13_14  connected_order_arc_939  -13
    arc_1_13_14  out_degree_1143  1
    arc_1_13_14  in_degree_1150  1
    arc_1_13_14  original_T_including_depot_unload_1194  2.1974044543706933e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_14  arc_capacity_938  1
    load_1_13_14  free_load_conservation_1148  1
    load_1_13_14  free_load_conservation_1154  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_15  arc_capacity_940  -25
    arc_1_13_15  connected_order_arc_941  -13
    arc_1_13_15  out_degree_1143  1
    arc_1_13_15  in_degree_1156  1
    arc_1_13_15  original_T_including_depot_unload_1194  2.5477291514674703e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_15  arc_capacity_940  1
    load_1_13_15  free_load_conservation_1148  1
    load_1_13_15  free_load_conservation_1160  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_16  arc_capacity_942  -25
    arc_1_13_16  connected_order_arc_943  -13
    arc_1_13_16  out_degree_1143  1
    arc_1_13_16  in_degree_1162  1
    arc_1_13_16  original_T_including_depot_unload_1194  2.4467085139097674e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_16  arc_capacity_942  1
    load_1_13_16  free_load_conservation_1148  1
    load_1_13_16  free_load_conservation_1166  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_17  arc_capacity_944  -25
    arc_1_13_17  connected_order_arc_945  -13
    arc_1_13_17  out_degree_1143  1
    arc_1_13_17  in_degree_1168  1
    arc_1_13_17  original_T_including_depot_unload_1194  1.5402832821684894e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_17  arc_capacity_944  1
    load_1_13_17  free_load_conservation_1148  1
    load_1_13_17  free_load_conservation_1172  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_18  arc_capacity_946  -25
    arc_1_13_18  connected_order_arc_947  -13
    arc_1_13_18  out_degree_1143  1
    arc_1_13_18  in_degree_1174  1
    arc_1_13_18  original_T_including_depot_unload_1194  3.0177284565053407e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_18  arc_capacity_946  1
    load_1_13_18  free_load_conservation_1148  1
    load_1_13_18  free_load_conservation_1178  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_19  arc_capacity_948  -25
    arc_1_13_19  connected_order_arc_949  -13
    arc_1_13_19  out_degree_1143  1
    arc_1_13_19  in_degree_1180  1
    arc_1_13_19  original_T_including_depot_unload_1194  1.9185455792071525e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_19  arc_capacity_948  1
    load_1_13_19  free_load_conservation_1148  1
    load_1_13_19  free_load_conservation_1184  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_20  arc_capacity_950  -25
    arc_1_13_20  connected_order_arc_951  -13
    arc_1_13_20  out_degree_1143  1
    arc_1_13_20  in_degree_1186  1
    arc_1_13_20  original_T_including_depot_unload_1194  3.2767382990070683e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_20  arc_capacity_950  1
    load_1_13_20  free_load_conservation_1148  1
    load_1_13_20  free_load_conservation_1190  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_0  arc_capacity_952  -25
    arc_1_14_0  depot_return_or_bypass_1114  1
    arc_1_14_0  out_degree_1149  1
    arc_1_14_0  original_T_including_depot_unload_1194  885.819758595088
    MARKER    'MARKER'                 'INTEND'
    load_1_14_0  arc_capacity_952  1
    load_1_14_0  free_load_conservation_1154  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_6  arc_capacity_953  -25
    arc_1_14_6  connected_order_arc_954  -13
    arc_1_14_6  in_degree_1116  1
    arc_1_14_6  out_degree_1149  1
    arc_1_14_6  original_T_including_depot_unload_1194  1.7532207666032109e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_6  arc_capacity_953  1
    load_1_14_6  segment_load_conservation_1119  -1
    load_1_14_6  segment_prefix_lb_1120  1
    load_1_14_6  segment_prefix_ub_1121  1
    load_1_14_6  free_load_conservation_1154  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_7  arc_capacity_955  -25
    arc_1_14_7  connected_order_arc_956  -13
    arc_1_14_7  in_degree_1123  1
    arc_1_14_7  out_degree_1149  1
    arc_1_14_7  original_T_including_depot_unload_1194  6.3817162287710391e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_7  arc_capacity_955  1
    load_1_14_7  segment_load_conservation_1126  -1
    load_1_14_7  segment_prefix_lb_1127  1
    load_1_14_7  segment_prefix_ub_1128  1
    load_1_14_7  free_load_conservation_1154  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_8  arc_capacity_957  -25
    arc_1_14_8  connected_order_arc_958  -13
    arc_1_14_8  in_degree_1130  1
    arc_1_14_8  out_degree_1149  1
    arc_1_14_8  original_T_including_depot_unload_1194  4.8212282798659248e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_8  arc_capacity_957  1
    load_1_14_8  segment_load_conservation_1133  -1
    load_1_14_8  segment_prefix_lb_1134  1
    load_1_14_8  segment_prefix_ub_1135  1
    load_1_14_8  free_load_conservation_1154  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_9  arc_capacity_959  -25
    arc_1_14_9  connected_order_arc_960  -13
    arc_1_14_9  in_degree_1137  1
    arc_1_14_9  out_degree_1149  1
    arc_1_14_9  original_T_including_depot_unload_1194  7.6932985985964615e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_9  arc_capacity_959  1
    load_1_14_9  segment_load_conservation_1140  -1
    load_1_14_9  segment_prefix_lb_1141  1
    load_1_14_9  segment_prefix_ub_1142  1
    load_1_14_9  free_load_conservation_1154  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_13  arc_capacity_961  -25
    arc_1_14_13  connected_order_arc_962  -13
    arc_1_14_13  in_degree_1144  1
    arc_1_14_13  out_degree_1149  1
    arc_1_14_13  original_T_including_depot_unload_1194  2.1974044543706933e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_13  arc_capacity_961  1
    load_1_14_13  free_load_conservation_1148  -1
    load_1_14_13  free_load_conservation_1154  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_15  arc_capacity_963  -25
    arc_1_14_15  connected_order_arc_964  -13
    arc_1_14_15  out_degree_1149  1
    arc_1_14_15  in_degree_1156  1
    arc_1_14_15  original_T_including_depot_unload_1194  2.3420148578372859e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_15  arc_capacity_963  1
    load_1_14_15  free_load_conservation_1154  1
    load_1_14_15  free_load_conservation_1160  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_16  arc_capacity_965  -25
    arc_1_14_16  connected_order_arc_966  -13
    arc_1_14_16  out_degree_1149  1
    arc_1_14_16  in_degree_1162  1
    arc_1_14_16  original_T_including_depot_unload_1194  3.5284009487492966e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_16  arc_capacity_965  1
    load_1_14_16  free_load_conservation_1154  1
    load_1_14_16  free_load_conservation_1166  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_17  arc_capacity_967  -25
    arc_1_14_17  connected_order_arc_968  -13
    arc_1_14_17  out_degree_1149  1
    arc_1_14_17  in_degree_1168  1
    arc_1_14_17  original_T_including_depot_unload_1194  1.3209989051658847e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_17  arc_capacity_967  1
    load_1_14_17  free_load_conservation_1154  1
    load_1_14_17  free_load_conservation_1172  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_18  arc_capacity_969  -25
    arc_1_14_18  connected_order_arc_970  -13
    arc_1_14_18  out_degree_1149  1
    arc_1_14_18  in_degree_1174  1
    arc_1_14_18  original_T_including_depot_unload_1194  2.1282400853806328e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_18  arc_capacity_969  1
    load_1_14_18  free_load_conservation_1154  1
    load_1_14_18  free_load_conservation_1178  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_19  arc_capacity_971  -25
    arc_1_14_19  connected_order_arc_972  -13
    arc_1_14_19  out_degree_1149  1
    arc_1_14_19  in_degree_1180  1
    arc_1_14_19  original_T_including_depot_unload_1194  1.7093216071319850e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_19  arc_capacity_971  1
    load_1_14_19  free_load_conservation_1154  1
    load_1_14_19  free_load_conservation_1184  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_20  arc_capacity_973  -25
    arc_1_14_20  connected_order_arc_974  -13
    arc_1_14_20  out_degree_1149  1
    arc_1_14_20  in_degree_1186  1
    arc_1_14_20  original_T_including_depot_unload_1194  1.1216289013953633e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_20  arc_capacity_973  1
    load_1_14_20  free_load_conservation_1154  1
    load_1_14_20  free_load_conservation_1190  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_0  arc_capacity_975  -25
    arc_1_15_0  depot_return_or_bypass_1114  1
    arc_1_15_0  out_degree_1155  1
    arc_1_15_0  original_T_including_depot_unload_1194  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_0  arc_capacity_975  1
    load_1_15_0  free_load_conservation_1160  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_6  arc_capacity_976  -25
    arc_1_15_6  connected_order_arc_977  -13
    arc_1_15_6  in_degree_1116  1
    arc_1_15_6  out_degree_1155  1
    arc_1_15_6  original_T_including_depot_unload_1194  2.1501600514850211e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_6  arc_capacity_976  1
    load_1_15_6  segment_load_conservation_1119  -1
    load_1_15_6  segment_prefix_lb_1120  1
    load_1_15_6  segment_prefix_ub_1121  1
    load_1_15_6  free_load_conservation_1160  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_7  arc_capacity_978  -25
    arc_1_15_7  connected_order_arc_979  -13
    arc_1_15_7  in_degree_1123  1
    arc_1_15_7  out_degree_1155  1
    arc_1_15_7  original_T_including_depot_unload_1194  2.9790156048453791e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_7  arc_capacity_978  1
    load_1_15_7  segment_load_conservation_1126  -1
    load_1_15_7  segment_prefix_lb_1127  1
    load_1_15_7  segment_prefix_ub_1128  1
    load_1_15_7  free_load_conservation_1160  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_8  arc_capacity_980  -25
    arc_1_15_8  connected_order_arc_981  -13
    arc_1_15_8  in_degree_1130  1
    arc_1_15_8  out_degree_1155  1
    arc_1_15_8  original_T_including_depot_unload_1194  2.1109553693139742e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_8  arc_capacity_980  1
    load_1_15_8  segment_load_conservation_1133  -1
    load_1_15_8  segment_prefix_lb_1134  1
    load_1_15_8  segment_prefix_ub_1135  1
    load_1_15_8  free_load_conservation_1160  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_9  arc_capacity_982  -25
    arc_1_15_9  connected_order_arc_983  -13
    arc_1_15_9  in_degree_1137  1
    arc_1_15_9  out_degree_1155  1
    arc_1_15_9  original_T_including_depot_unload_1194  1.8911324761641883e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_9  arc_capacity_982  1
    load_1_15_9  segment_load_conservation_1140  -1
    load_1_15_9  segment_prefix_lb_1141  1
    load_1_15_9  segment_prefix_ub_1142  1
    load_1_15_9  free_load_conservation_1160  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_13  arc_capacity_984  -25
    arc_1_15_13  connected_order_arc_985  -13
    arc_1_15_13  in_degree_1144  1
    arc_1_15_13  out_degree_1155  1
    arc_1_15_13  original_T_including_depot_unload_1194  2.5477291514674703e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_13  arc_capacity_984  1
    load_1_15_13  free_load_conservation_1148  -1
    load_1_15_13  free_load_conservation_1160  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_14  arc_capacity_986  -25
    arc_1_15_14  connected_order_arc_987  -13
    arc_1_15_14  in_degree_1150  1
    arc_1_15_14  out_degree_1155  1
    arc_1_15_14  original_T_including_depot_unload_1194  2.3420148578372859e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_14  arc_capacity_986  1
    load_1_15_14  free_load_conservation_1154  -1
    load_1_15_14  free_load_conservation_1160  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_16  arc_capacity_988  -25
    arc_1_15_16  connected_order_arc_989  -13
    arc_1_15_16  out_degree_1155  1
    arc_1_15_16  in_degree_1162  1
    arc_1_15_16  original_T_including_depot_unload_1194  2.6729202257370252e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_16  arc_capacity_988  1
    load_1_15_16  free_load_conservation_1160  1
    load_1_15_16  free_load_conservation_1166  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_17  arc_capacity_990  -25
    arc_1_15_17  connected_order_arc_991  -13
    arc_1_15_17  out_degree_1155  1
    arc_1_15_17  in_degree_1168  1
    arc_1_15_17  original_T_including_depot_unload_1194  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_17  arc_capacity_990  1
    load_1_15_17  free_load_conservation_1160  1
    load_1_15_17  free_load_conservation_1172  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_18  arc_capacity_992  -25
    arc_1_15_18  connected_order_arc_993  -13
    arc_1_15_18  out_degree_1155  1
    arc_1_15_18  in_degree_1174  1
    arc_1_15_18  original_T_including_depot_unload_1194  2.4332256311874226e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_18  arc_capacity_992  1
    load_1_15_18  free_load_conservation_1160  1
    load_1_15_18  free_load_conservation_1178  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_19  arc_capacity_994  -25
    arc_1_15_19  connected_order_arc_995  -13
    arc_1_15_19  out_degree_1155  1
    arc_1_15_19  in_degree_1180  1
    arc_1_15_19  original_T_including_depot_unload_1194  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_1_15_19  arc_capacity_994  1
    load_1_15_19  free_load_conservation_1160  1
    load_1_15_19  free_load_conservation_1184  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_20  arc_capacity_996  -25
    arc_1_15_20  connected_order_arc_997  -13
    arc_1_15_20  out_degree_1155  1
    arc_1_15_20  in_degree_1186  1
    arc_1_15_20  original_T_including_depot_unload_1194  2.2299340442558691e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_20  arc_capacity_996  1
    load_1_15_20  free_load_conservation_1160  1
    load_1_15_20  free_load_conservation_1190  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_0  arc_capacity_998  -25
    arc_1_16_0  depot_return_or_bypass_1114  1
    arc_1_16_0  out_degree_1161  1
    arc_1_16_0  original_T_including_depot_unload_1194  1163.36883938708
    MARKER    'MARKER'                 'INTEND'
    load_1_16_0  arc_capacity_998  1
    load_1_16_0  free_load_conservation_1166  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_6  arc_capacity_999  -25
    arc_1_16_6  connected_order_arc_1000  -13
    arc_1_16_6  in_degree_1116  1
    arc_1_16_6  out_degree_1161  1
    arc_1_16_6  original_T_including_depot_unload_1194  1829.33035879167
    MARKER    'MARKER'                 'INTEND'
    load_1_16_6  arc_capacity_999  1
    load_1_16_6  segment_load_conservation_1119  -1
    load_1_16_6  segment_prefix_lb_1120  1
    load_1_16_6  segment_prefix_ub_1121  1
    load_1_16_6  free_load_conservation_1166  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_7  arc_capacity_1001  -25
    arc_1_16_7  connected_order_arc_1002  -13
    arc_1_16_7  in_degree_1123  1
    arc_1_16_7  out_degree_1161  1
    arc_1_16_7  original_T_including_depot_unload_1194  3.2105135706875041e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_7  arc_capacity_1001  1
    load_1_16_7  segment_load_conservation_1126  -1
    load_1_16_7  segment_prefix_lb_1127  1
    load_1_16_7  segment_prefix_ub_1128  1
    load_1_16_7  free_load_conservation_1166  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_8  arc_capacity_1003  -25
    arc_1_16_8  connected_order_arc_1004  -13
    arc_1_16_8  in_degree_1130  1
    arc_1_16_8  out_degree_1161  1
    arc_1_16_8  original_T_including_depot_unload_1194  6.5484387194508088e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_8  arc_capacity_1003  1
    load_1_16_8  segment_load_conservation_1133  -1
    load_1_16_8  segment_prefix_lb_1134  1
    load_1_16_8  segment_prefix_ub_1135  1
    load_1_16_8  free_load_conservation_1166  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_9  arc_capacity_1005  -25
    arc_1_16_9  connected_order_arc_1006  -13
    arc_1_16_9  in_degree_1137  1
    arc_1_16_9  out_degree_1161  1
    arc_1_16_9  original_T_including_depot_unload_1194  9.5986282589427344e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_9  arc_capacity_1005  1
    load_1_16_9  segment_load_conservation_1140  -1
    load_1_16_9  segment_prefix_lb_1141  1
    load_1_16_9  segment_prefix_ub_1142  1
    load_1_16_9  free_load_conservation_1166  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_13  arc_capacity_1007  -25
    arc_1_16_13  connected_order_arc_1008  -13
    arc_1_16_13  in_degree_1144  1
    arc_1_16_13  out_degree_1161  1
    arc_1_16_13  original_T_including_depot_unload_1194  2.4467085139097674e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_13  arc_capacity_1007  1
    load_1_16_13  free_load_conservation_1148  -1
    load_1_16_13  free_load_conservation_1166  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_14  arc_capacity_1009  -25
    arc_1_16_14  connected_order_arc_1010  -13
    arc_1_16_14  in_degree_1150  1
    arc_1_16_14  out_degree_1161  1
    arc_1_16_14  original_T_including_depot_unload_1194  3.5284009487492966e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_14  arc_capacity_1009  1
    load_1_16_14  free_load_conservation_1154  -1
    load_1_16_14  free_load_conservation_1166  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_15  arc_capacity_1011  -25
    arc_1_16_15  connected_order_arc_1012  -13
    arc_1_16_15  in_degree_1156  1
    arc_1_16_15  out_degree_1161  1
    arc_1_16_15  original_T_including_depot_unload_1194  2.6729202257370252e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_15  arc_capacity_1011  1
    load_1_16_15  free_load_conservation_1160  -1
    load_1_16_15  free_load_conservation_1166  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_17  arc_capacity_1013  -25
    arc_1_16_17  connected_order_arc_1014  -13
    arc_1_16_17  out_degree_1161  1
    arc_1_16_17  in_degree_1168  1
    arc_1_16_17  original_T_including_depot_unload_1194  1.5818623486522529e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_17  arc_capacity_1013  1
    load_1_16_17  free_load_conservation_1166  1
    load_1_16_17  free_load_conservation_1172  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_18  arc_capacity_1015  -25
    arc_1_16_18  connected_order_arc_1016  -13
    arc_1_16_18  out_degree_1161  1
    arc_1_16_18  in_degree_1174  1
    arc_1_16_18  original_T_including_depot_unload_1194  2.5289455774621715e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_18  arc_capacity_1015  1
    load_1_16_18  free_load_conservation_1166  1
    load_1_16_18  free_load_conservation_1178  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_19  arc_capacity_1017  -25
    arc_1_16_19  connected_order_arc_1018  -13
    arc_1_16_19  out_degree_1161  1
    arc_1_16_19  in_degree_1180  1
    arc_1_16_19  original_T_including_depot_unload_1194  2.0359275139821484e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_19  arc_capacity_1017  1
    load_1_16_19  free_load_conservation_1166  1
    load_1_16_19  free_load_conservation_1184  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_20  arc_capacity_1019  -25
    arc_1_16_20  connected_order_arc_1020  -13
    arc_1_16_20  out_degree_1161  1
    arc_1_16_20  in_degree_1186  1
    arc_1_16_20  original_T_including_depot_unload_1194  4.5764912346489922e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_20  arc_capacity_1019  1
    load_1_16_20  free_load_conservation_1166  1
    load_1_16_20  free_load_conservation_1190  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_0  arc_capacity_1021  -25
    arc_1_17_0  depot_return_or_bypass_1114  1
    arc_1_17_0  out_degree_1167  1
    arc_1_17_0  original_T_including_depot_unload_1194  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_0  arc_capacity_1021  1
    load_1_17_0  free_load_conservation_1172  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_6  arc_capacity_1022  -25
    arc_1_17_6  connected_order_arc_1023  -13
    arc_1_17_6  in_degree_1116  1
    arc_1_17_6  out_degree_1167  1
    arc_1_17_6  original_T_including_depot_unload_1194  1.0321140782598593e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_6  arc_capacity_1022  1
    load_1_17_6  segment_load_conservation_1119  -1
    load_1_17_6  segment_prefix_lb_1120  1
    load_1_17_6  segment_prefix_ub_1121  1
    load_1_17_6  free_load_conservation_1172  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_7  arc_capacity_1024  -25
    arc_1_17_7  connected_order_arc_1025  -13
    arc_1_17_7  in_degree_1123  1
    arc_1_17_7  out_degree_1167  1
    arc_1_17_7  original_T_including_depot_unload_1194  1.9029099398713563e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_7  arc_capacity_1024  1
    load_1_17_7  segment_load_conservation_1126  -1
    load_1_17_7  segment_prefix_lb_1127  1
    load_1_17_7  segment_prefix_ub_1128  1
    load_1_17_7  free_load_conservation_1172  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_8  arc_capacity_1026  -25
    arc_1_17_8  connected_order_arc_1027  -13
    arc_1_17_8  in_degree_1130  1
    arc_1_17_8  out_degree_1167  1
    arc_1_17_8  original_T_including_depot_unload_1194  9.3836915476275669e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_8  arc_capacity_1026  1
    load_1_17_8  segment_load_conservation_1133  -1
    load_1_17_8  segment_prefix_lb_1134  1
    load_1_17_8  segment_prefix_ub_1135  1
    load_1_17_8  free_load_conservation_1172  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_9  arc_capacity_1028  -25
    arc_1_17_9  connected_order_arc_1029  -13
    arc_1_17_9  in_degree_1137  1
    arc_1_17_9  out_degree_1167  1
    arc_1_17_9  original_T_including_depot_unload_1194  6.5869285599668615e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_9  arc_capacity_1028  1
    load_1_17_9  segment_load_conservation_1140  -1
    load_1_17_9  segment_prefix_lb_1141  1
    load_1_17_9  segment_prefix_ub_1142  1
    load_1_17_9  free_load_conservation_1172  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_13  arc_capacity_1030  -25
    arc_1_17_13  connected_order_arc_1031  -13
    arc_1_17_13  in_degree_1144  1
    arc_1_17_13  out_degree_1167  1
    arc_1_17_13  original_T_including_depot_unload_1194  1.5402832821684894e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_13  arc_capacity_1030  1
    load_1_17_13  free_load_conservation_1148  -1
    load_1_17_13  free_load_conservation_1172  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_14  arc_capacity_1032  -25
    arc_1_17_14  connected_order_arc_1033  -13
    arc_1_17_14  in_degree_1150  1
    arc_1_17_14  out_degree_1167  1
    arc_1_17_14  original_T_including_depot_unload_1194  1.3209989051658847e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_14  arc_capacity_1032  1
    load_1_17_14  free_load_conservation_1154  -1
    load_1_17_14  free_load_conservation_1172  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_15  arc_capacity_1034  -25
    arc_1_17_15  connected_order_arc_1035  -13
    arc_1_17_15  in_degree_1156  1
    arc_1_17_15  out_degree_1167  1
    arc_1_17_15  original_T_including_depot_unload_1194  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_15  arc_capacity_1034  1
    load_1_17_15  free_load_conservation_1160  -1
    load_1_17_15  free_load_conservation_1172  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_16  arc_capacity_1036  -25
    arc_1_17_16  connected_order_arc_1037  -13
    arc_1_17_16  in_degree_1162  1
    arc_1_17_16  out_degree_1167  1
    arc_1_17_16  original_T_including_depot_unload_1194  1.5818623486522529e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_16  arc_capacity_1036  1
    load_1_17_16  free_load_conservation_1166  -1
    load_1_17_16  free_load_conservation_1172  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_18  arc_capacity_1038  -25
    arc_1_17_18  connected_order_arc_1039  -13
    arc_1_17_18  out_degree_1167  1
    arc_1_17_18  in_degree_1174  1
    arc_1_17_18  original_T_including_depot_unload_1194  1.3290297652049680e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_18  arc_capacity_1038  1
    load_1_17_18  free_load_conservation_1172  1
    load_1_17_18  free_load_conservation_1178  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_19  arc_capacity_1040  -25
    arc_1_17_19  connected_order_arc_1041  -13
    arc_1_17_19  out_degree_1167  1
    arc_1_17_19  in_degree_1180  1
    arc_1_17_19  original_T_including_depot_unload_1194  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_1_17_19  arc_capacity_1040  1
    load_1_17_19  free_load_conservation_1172  1
    load_1_17_19  free_load_conservation_1184  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_20  arc_capacity_1042  -25
    arc_1_17_20  connected_order_arc_1043  -13
    arc_1_17_20  out_degree_1167  1
    arc_1_17_20  in_degree_1186  1
    arc_1_17_20  original_T_including_depot_unload_1194  1.2188376307261726e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_20  arc_capacity_1042  1
    load_1_17_20  free_load_conservation_1172  1
    load_1_17_20  free_load_conservation_1190  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_0  arc_capacity_1044  -25
    arc_1_18_0  depot_return_or_bypass_1114  1
    arc_1_18_0  out_degree_1173  1
    arc_1_18_0  original_T_including_depot_unload_1194  9.1137190274562636e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_0  arc_capacity_1044  1
    load_1_18_0  free_load_conservation_1178  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_6  arc_capacity_1045  -25
    arc_1_18_6  connected_order_arc_1046  -13
    arc_1_18_6  in_degree_1116  1
    arc_1_18_6  out_degree_1173  1
    arc_1_18_6  original_T_including_depot_unload_1194  1.6298434106568175e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_6  arc_capacity_1045  1
    load_1_18_6  segment_load_conservation_1119  -1
    load_1_18_6  segment_prefix_lb_1120  1
    load_1_18_6  segment_prefix_ub_1121  1
    load_1_18_6  free_load_conservation_1178  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_7  arc_capacity_1047  -25
    arc_1_18_7  connected_order_arc_1048  -13
    arc_1_18_7  in_degree_1123  1
    arc_1_18_7  out_degree_1173  1
    arc_1_18_7  original_T_including_depot_unload_1194  5.7393004225094967e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_7  arc_capacity_1047  1
    load_1_18_7  segment_load_conservation_1126  -1
    load_1_18_7  segment_prefix_lb_1127  1
    load_1_18_7  segment_prefix_ub_1128  1
    load_1_18_7  free_load_conservation_1178  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_8  arc_capacity_1049  -25
    arc_1_18_8  connected_order_arc_1050  -13
    arc_1_18_8  in_degree_1130  1
    arc_1_18_8  out_degree_1173  1
    arc_1_18_8  original_T_including_depot_unload_1194  4.0739926745194407e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_8  arc_capacity_1049  1
    load_1_18_8  segment_load_conservation_1133  -1
    load_1_18_8  segment_prefix_lb_1134  1
    load_1_18_8  segment_prefix_ub_1135  1
    load_1_18_8  free_load_conservation_1178  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_9  arc_capacity_1051  -25
    arc_1_18_9  connected_order_arc_1052  -13
    arc_1_18_9  in_degree_1137  1
    arc_1_18_9  out_degree_1173  1
    arc_1_18_9  original_T_including_depot_unload_1194  7.1354165601672594e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_9  arc_capacity_1051  1
    load_1_18_9  segment_load_conservation_1140  -1
    load_1_18_9  segment_prefix_lb_1141  1
    load_1_18_9  segment_prefix_ub_1142  1
    load_1_18_9  free_load_conservation_1178  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_13  arc_capacity_1053  -25
    arc_1_18_13  connected_order_arc_1054  -13
    arc_1_18_13  in_degree_1144  1
    arc_1_18_13  out_degree_1173  1
    arc_1_18_13  original_T_including_depot_unload_1194  3.0177284565053407e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_13  arc_capacity_1053  1
    load_1_18_13  free_load_conservation_1148  -1
    load_1_18_13  free_load_conservation_1178  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_14  arc_capacity_1055  -25
    arc_1_18_14  connected_order_arc_1056  -13
    arc_1_18_14  in_degree_1150  1
    arc_1_18_14  out_degree_1173  1
    arc_1_18_14  original_T_including_depot_unload_1194  2.1282400853806328e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_14  arc_capacity_1055  1
    load_1_18_14  free_load_conservation_1154  -1
    load_1_18_14  free_load_conservation_1178  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_15  arc_capacity_1057  -25
    arc_1_18_15  connected_order_arc_1058  -13
    arc_1_18_15  in_degree_1156  1
    arc_1_18_15  out_degree_1173  1
    arc_1_18_15  original_T_including_depot_unload_1194  2.4332256311874226e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_15  arc_capacity_1057  1
    load_1_18_15  free_load_conservation_1160  -1
    load_1_18_15  free_load_conservation_1178  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_16  arc_capacity_1059  -25
    arc_1_18_16  connected_order_arc_1060  -13
    arc_1_18_16  in_degree_1162  1
    arc_1_18_16  out_degree_1173  1
    arc_1_18_16  original_T_including_depot_unload_1194  2.5289455774621715e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_16  arc_capacity_1059  1
    load_1_18_16  free_load_conservation_1166  -1
    load_1_18_16  free_load_conservation_1178  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_17  arc_capacity_1061  -25
    arc_1_18_17  connected_order_arc_1062  -13
    arc_1_18_17  in_degree_1168  1
    arc_1_18_17  out_degree_1173  1
    arc_1_18_17  original_T_including_depot_unload_1194  1.3290297652049680e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_17  arc_capacity_1061  1
    load_1_18_17  free_load_conservation_1172  -1
    load_1_18_17  free_load_conservation_1178  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_19  arc_capacity_1063  -25
    arc_1_18_19  connected_order_arc_1064  -13
    arc_1_18_19  out_degree_1173  1
    arc_1_18_19  in_degree_1180  1
    arc_1_18_19  original_T_including_depot_unload_1194  1.7947282495227562e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_19  arc_capacity_1063  1
    load_1_18_19  free_load_conservation_1178  1
    load_1_18_19  free_load_conservation_1184  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_20  arc_capacity_1065  -25
    arc_1_18_20  connected_order_arc_1066  -13
    arc_1_18_20  out_degree_1173  1
    arc_1_18_20  in_degree_1186  1
    arc_1_18_20  original_T_including_depot_unload_1194  2.7370069334295619e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_20  arc_capacity_1065  1
    load_1_18_20  free_load_conservation_1178  1
    load_1_18_20  free_load_conservation_1190  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_0  arc_capacity_1067  -25
    arc_1_19_0  depot_return_or_bypass_1114  1
    arc_1_19_0  out_degree_1179  1
    arc_1_19_0  original_T_including_depot_unload_1194  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_0  arc_capacity_1067  1
    load_1_19_0  free_load_conservation_1184  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_6  arc_capacity_1068  -25
    arc_1_19_6  connected_order_arc_1069  -13
    arc_1_19_6  in_degree_1116  1
    arc_1_19_6  out_degree_1179  1
    arc_1_19_6  original_T_including_depot_unload_1194  1.6988291947636669e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_6  arc_capacity_1068  1
    load_1_19_6  segment_load_conservation_1119  -1
    load_1_19_6  segment_prefix_lb_1120  1
    load_1_19_6  segment_prefix_ub_1121  1
    load_1_19_6  free_load_conservation_1184  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_7  arc_capacity_1070  -25
    arc_1_19_7  connected_order_arc_1071  -13
    arc_1_19_7  in_degree_1123  1
    arc_1_19_7  out_degree_1179  1
    arc_1_19_7  original_T_including_depot_unload_1194  2.3444750474890211e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_7  arc_capacity_1070  1
    load_1_19_7  segment_load_conservation_1126  -1
    load_1_19_7  segment_prefix_lb_1127  1
    load_1_19_7  segment_prefix_ub_1128  1
    load_1_19_7  free_load_conservation_1184  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_8  arc_capacity_1072  -25
    arc_1_19_8  connected_order_arc_1073  -13
    arc_1_19_8  in_degree_1130  1
    arc_1_19_8  out_degree_1179  1
    arc_1_19_8  original_T_including_depot_unload_1194  1.4738339199468992e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_8  arc_capacity_1072  1
    load_1_19_8  segment_load_conservation_1133  -1
    load_1_19_8  segment_prefix_lb_1134  1
    load_1_19_8  segment_prefix_ub_1135  1
    load_1_19_8  free_load_conservation_1184  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_9  arc_capacity_1074  -25
    arc_1_19_9  connected_order_arc_1075  -13
    arc_1_19_9  in_degree_1137  1
    arc_1_19_9  out_degree_1179  1
    arc_1_19_9  original_T_including_depot_unload_1194  1.2665309635243570e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_9  arc_capacity_1074  1
    load_1_19_9  segment_load_conservation_1140  -1
    load_1_19_9  segment_prefix_lb_1141  1
    load_1_19_9  segment_prefix_ub_1142  1
    load_1_19_9  free_load_conservation_1184  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_13  arc_capacity_1076  -25
    arc_1_19_13  connected_order_arc_1077  -13
    arc_1_19_13  in_degree_1144  1
    arc_1_19_13  out_degree_1179  1
    arc_1_19_13  original_T_including_depot_unload_1194  1.9185455792071525e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_13  arc_capacity_1076  1
    load_1_19_13  free_load_conservation_1148  -1
    load_1_19_13  free_load_conservation_1184  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_14  arc_capacity_1078  -25
    arc_1_19_14  connected_order_arc_1079  -13
    arc_1_19_14  in_degree_1150  1
    arc_1_19_14  out_degree_1179  1
    arc_1_19_14  original_T_including_depot_unload_1194  1.7093216071319850e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_14  arc_capacity_1078  1
    load_1_19_14  free_load_conservation_1154  -1
    load_1_19_14  free_load_conservation_1184  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_15  arc_capacity_1080  -25
    arc_1_19_15  connected_order_arc_1081  -13
    arc_1_19_15  in_degree_1156  1
    arc_1_19_15  out_degree_1179  1
    arc_1_19_15  original_T_including_depot_unload_1194  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_1_19_15  arc_capacity_1080  1
    load_1_19_15  free_load_conservation_1160  -1
    load_1_19_15  free_load_conservation_1184  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_16  arc_capacity_1082  -25
    arc_1_19_16  connected_order_arc_1083  -13
    arc_1_19_16  in_degree_1162  1
    arc_1_19_16  out_degree_1179  1
    arc_1_19_16  original_T_including_depot_unload_1194  2.0359275139821484e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_16  arc_capacity_1082  1
    load_1_19_16  free_load_conservation_1166  -1
    load_1_19_16  free_load_conservation_1184  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_17  arc_capacity_1084  -25
    arc_1_19_17  connected_order_arc_1085  -13
    arc_1_19_17  in_degree_1168  1
    arc_1_19_17  out_degree_1179  1
    arc_1_19_17  original_T_including_depot_unload_1194  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_1_19_17  arc_capacity_1084  1
    load_1_19_17  free_load_conservation_1172  -1
    load_1_19_17  free_load_conservation_1184  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_18  arc_capacity_1086  -25
    arc_1_19_18  connected_order_arc_1087  -13
    arc_1_19_18  in_degree_1174  1
    arc_1_19_18  out_degree_1179  1
    arc_1_19_18  original_T_including_depot_unload_1194  1.7947282495227562e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_18  arc_capacity_1086  1
    load_1_19_18  free_load_conservation_1178  -1
    load_1_19_18  free_load_conservation_1184  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_20  arc_capacity_1088  -25
    arc_1_19_20  connected_order_arc_1089  -13
    arc_1_19_20  out_degree_1179  1
    arc_1_19_20  in_degree_1186  1
    arc_1_19_20  original_T_including_depot_unload_1194  1.5971628811503840e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_20  arc_capacity_1088  1
    load_1_19_20  free_load_conservation_1184  1
    load_1_19_20  free_load_conservation_1190  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_0  arc_capacity_1090  -25
    arc_1_20_0  depot_return_or_bypass_1114  1
    arc_1_20_0  out_degree_1185  1
    arc_1_20_0  original_T_including_depot_unload_1194  7.8199183337763486e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_0  arc_capacity_1090  1
    load_1_20_0  free_load_conservation_1190  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_6  arc_capacity_1091  -25
    arc_1_20_6  connected_order_arc_1092  -13
    arc_1_20_6  in_degree_1116  1
    arc_1_20_6  out_degree_1185  1
    arc_1_20_6  original_T_including_depot_unload_1194  1.6985664713248598e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_6  arc_capacity_1091  1
    load_1_20_6  segment_load_conservation_1119  -1
    load_1_20_6  segment_prefix_lb_1120  1
    load_1_20_6  segment_prefix_ub_1121  1
    load_1_20_6  free_load_conservation_1190  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_7  arc_capacity_1093  -25
    arc_1_20_7  connected_order_arc_1094  -13
    arc_1_20_7  in_degree_1123  1
    arc_1_20_7  out_degree_1185  1
    arc_1_20_7  original_T_including_depot_unload_1194  7.4980220943945562e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_7  arc_capacity_1093  1
    load_1_20_7  segment_load_conservation_1126  -1
    load_1_20_7  segment_prefix_lb_1127  1
    load_1_20_7  segment_prefix_ub_1128  1
    load_1_20_7  free_load_conservation_1190  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_8  arc_capacity_1095  -25
    arc_1_20_8  connected_order_arc_1096  -13
    arc_1_20_8  in_degree_1130  1
    arc_1_20_8  out_degree_1185  1
    arc_1_20_8  original_T_including_depot_unload_1194  4.2580398435897172e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_8  arc_capacity_1095  1
    load_1_20_8  segment_load_conservation_1133  -1
    load_1_20_8  segment_prefix_lb_1134  1
    load_1_20_8  segment_prefix_ub_1135  1
    load_1_20_8  free_load_conservation_1190  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_9  arc_capacity_1097  -25
    arc_1_20_9  connected_order_arc_1098  -13
    arc_1_20_9  in_degree_1137  1
    arc_1_20_9  out_degree_1185  1
    arc_1_20_9  original_T_including_depot_unload_1194  6.9292160543761986e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_9  arc_capacity_1097  1
    load_1_20_9  segment_load_conservation_1140  -1
    load_1_20_9  segment_prefix_lb_1141  1
    load_1_20_9  segment_prefix_ub_1142  1
    load_1_20_9  free_load_conservation_1190  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_13  arc_capacity_1099  -25
    arc_1_20_13  connected_order_arc_1100  -13
    arc_1_20_13  in_degree_1144  1
    arc_1_20_13  out_degree_1185  1
    arc_1_20_13  original_T_including_depot_unload_1194  3.2767382990070683e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_13  arc_capacity_1099  1
    load_1_20_13  free_load_conservation_1148  -1
    load_1_20_13  free_load_conservation_1190  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_14  arc_capacity_1101  -25
    arc_1_20_14  connected_order_arc_1102  -13
    arc_1_20_14  in_degree_1150  1
    arc_1_20_14  out_degree_1185  1
    arc_1_20_14  original_T_including_depot_unload_1194  1.1216289013953633e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_14  arc_capacity_1101  1
    load_1_20_14  free_load_conservation_1154  -1
    load_1_20_14  free_load_conservation_1190  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_15  arc_capacity_1103  -25
    arc_1_20_15  connected_order_arc_1104  -13
    arc_1_20_15  in_degree_1156  1
    arc_1_20_15  out_degree_1185  1
    arc_1_20_15  original_T_including_depot_unload_1194  2.2299340442558691e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_15  arc_capacity_1103  1
    load_1_20_15  free_load_conservation_1160  -1
    load_1_20_15  free_load_conservation_1190  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_16  arc_capacity_1105  -25
    arc_1_20_16  connected_order_arc_1106  -13
    arc_1_20_16  in_degree_1162  1
    arc_1_20_16  out_degree_1185  1
    arc_1_20_16  original_T_including_depot_unload_1194  4.5764912346489922e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_16  arc_capacity_1105  1
    load_1_20_16  free_load_conservation_1166  -1
    load_1_20_16  free_load_conservation_1190  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_17  arc_capacity_1107  -25
    arc_1_20_17  connected_order_arc_1108  -13
    arc_1_20_17  in_degree_1168  1
    arc_1_20_17  out_degree_1185  1
    arc_1_20_17  original_T_including_depot_unload_1194  1.2188376307261726e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_17  arc_capacity_1107  1
    load_1_20_17  free_load_conservation_1172  -1
    load_1_20_17  free_load_conservation_1190  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_18  arc_capacity_1109  -25
    arc_1_20_18  connected_order_arc_1110  -13
    arc_1_20_18  in_degree_1174  1
    arc_1_20_18  out_degree_1185  1
    arc_1_20_18  original_T_including_depot_unload_1194  2.7370069334295619e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_18  arc_capacity_1109  1
    load_1_20_18  free_load_conservation_1178  -1
    load_1_20_18  free_load_conservation_1190  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_19  arc_capacity_1111  -25
    arc_1_20_19  connected_order_arc_1112  -13
    arc_1_20_19  in_degree_1180  1
    arc_1_20_19  out_degree_1185  1
    arc_1_20_19  original_T_including_depot_unload_1194  1.5971628811503840e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_19  arc_capacity_1111  1
    load_1_20_19  free_load_conservation_1184  -1
    load_1_20_19  free_load_conservation_1190  1
    visit_2_10  out_degree_1440  -1
    visit_2_10  in_degree_1441  -1
    visit_2_10  order_active_lb_1442  -1
    visit_2_10  order_active_ub_1443  -11
    order_2_10  connected_order_arc_1209  -1
    order_2_10  connected_order_arc_1211  -1
    order_2_10  connected_order_arc_1213  -1
    order_2_10  connected_order_arc_1215  -1
    order_2_10  connected_order_arc_1217  -1
    order_2_10  connected_order_arc_1219  -1
    order_2_10  connected_order_arc_1221  -1
    order_2_10  connected_order_arc_1223  -1
    order_2_10  connected_order_arc_1225  -1
    order_2_10  connected_order_arc_1227  -1
    order_2_10  connected_order_arc_1230  1
    order_2_10  connected_order_arc_1251  1
    order_2_10  connected_order_arc_1272  1
    order_2_10  connected_order_arc_1293  1
    order_2_10  connected_order_arc_1314  1
    order_2_10  connected_order_arc_1335  1
    order_2_10  connected_order_arc_1356  1
    order_2_10  connected_order_arc_1377  1
    order_2_10  connected_order_arc_1398  1
    order_2_10  connected_order_arc_1419  1
    order_2_10  order_active_lb_1442  1
    order_2_10  order_active_ub_1443  1
    order_2_10  fixed_segment_relative_order_1509  -1
    visit_2_11  out_degree_1447  -1
    visit_2_11  in_degree_1448  -1
    visit_2_11  order_active_lb_1449  -1
    visit_2_11  order_active_ub_1450  -11
    order_2_11  connected_order_arc_1209  1
    order_2_11  connected_order_arc_1230  -1
    order_2_11  connected_order_arc_1232  -1
    order_2_11  connected_order_arc_1234  -1
    order_2_11  connected_order_arc_1236  -1
    order_2_11  connected_order_arc_1238  -1
    order_2_11  connected_order_arc_1240  -1
    order_2_11  connected_order_arc_1242  -1
    order_2_11  connected_order_arc_1244  -1
    order_2_11  connected_order_arc_1246  -1
    order_2_11  connected_order_arc_1248  -1
    order_2_11  connected_order_arc_1253  1
    order_2_11  connected_order_arc_1274  1
    order_2_11  connected_order_arc_1295  1
    order_2_11  connected_order_arc_1316  1
    order_2_11  connected_order_arc_1337  1
    order_2_11  connected_order_arc_1358  1
    order_2_11  connected_order_arc_1379  1
    order_2_11  connected_order_arc_1400  1
    order_2_11  connected_order_arc_1421  1
    order_2_11  order_active_lb_1449  1
    order_2_11  order_active_ub_1450  1
    order_2_11  fixed_segment_relative_order_1509  1
    order_2_11  fixed_segment_relative_order_1510  -1
    visit_2_12  out_degree_1454  -1
    visit_2_12  in_degree_1455  -1
    visit_2_12  order_active_lb_1456  -1
    visit_2_12  order_active_ub_1457  -11
    order_2_12  connected_order_arc_1211  1
    order_2_12  connected_order_arc_1232  1
    order_2_12  connected_order_arc_1251  -1
    order_2_12  connected_order_arc_1253  -1
    order_2_12  connected_order_arc_1255  -1
    order_2_12  connected_order_arc_1257  -1
    order_2_12  connected_order_arc_1259  -1
    order_2_12  connected_order_arc_1261  -1
    order_2_12  connected_order_arc_1263  -1
    order_2_12  connected_order_arc_1265  -1
    order_2_12  connected_order_arc_1267  -1
    order_2_12  connected_order_arc_1269  -1
    order_2_12  connected_order_arc_1276  1
    order_2_12  connected_order_arc_1297  1
    order_2_12  connected_order_arc_1318  1
    order_2_12  connected_order_arc_1339  1
    order_2_12  connected_order_arc_1360  1
    order_2_12  connected_order_arc_1381  1
    order_2_12  connected_order_arc_1402  1
    order_2_12  connected_order_arc_1423  1
    order_2_12  order_active_lb_1456  1
    order_2_12  order_active_ub_1457  1
    order_2_12  fixed_segment_relative_order_1510  1
    visit_2_13  out_degree_1461  -1
    visit_2_13  in_degree_1462  -1
    visit_2_13  order_active_lb_1463  -1
    visit_2_13  order_active_ub_1464  -11
    visit_2_13  service_visit_def_1465  -1
    order_2_13  connected_order_arc_1213  1
    order_2_13  connected_order_arc_1234  1
    order_2_13  connected_order_arc_1255  1
    order_2_13  connected_order_arc_1272  -1
    order_2_13  connected_order_arc_1274  -1
    order_2_13  connected_order_arc_1276  -1
    order_2_13  connected_order_arc_1278  -1
    order_2_13  connected_order_arc_1280  -1
    order_2_13  connected_order_arc_1282  -1
    order_2_13  connected_order_arc_1284  -1
    order_2_13  connected_order_arc_1286  -1
    order_2_13  connected_order_arc_1288  -1
    order_2_13  connected_order_arc_1290  -1
    order_2_13  connected_order_arc_1299  1
    order_2_13  connected_order_arc_1320  1
    order_2_13  connected_order_arc_1341  1
    order_2_13  connected_order_arc_1362  1
    order_2_13  connected_order_arc_1383  1
    order_2_13  connected_order_arc_1404  1
    order_2_13  connected_order_arc_1425  1
    order_2_13  order_active_lb_1463  1
    order_2_13  order_active_ub_1464  1
    visit_2_14  out_degree_1467  -1
    visit_2_14  in_degree_1468  -1
    visit_2_14  order_active_lb_1469  -1
    visit_2_14  order_active_ub_1470  -11
    visit_2_14  service_visit_def_1471  -1
    order_2_14  connected_order_arc_1215  1
    order_2_14  connected_order_arc_1236  1
    order_2_14  connected_order_arc_1257  1
    order_2_14  connected_order_arc_1278  1
    order_2_14  connected_order_arc_1293  -1
    order_2_14  connected_order_arc_1295  -1
    order_2_14  connected_order_arc_1297  -1
    order_2_14  connected_order_arc_1299  -1
    order_2_14  connected_order_arc_1301  -1
    order_2_14  connected_order_arc_1303  -1
    order_2_14  connected_order_arc_1305  -1
    order_2_14  connected_order_arc_1307  -1
    order_2_14  connected_order_arc_1309  -1
    order_2_14  connected_order_arc_1311  -1
    order_2_14  connected_order_arc_1322  1
    order_2_14  connected_order_arc_1343  1
    order_2_14  connected_order_arc_1364  1
    order_2_14  connected_order_arc_1385  1
    order_2_14  connected_order_arc_1406  1
    order_2_14  connected_order_arc_1427  1
    order_2_14  order_active_lb_1469  1
    order_2_14  order_active_ub_1470  1
    visit_2_15  out_degree_1473  -1
    visit_2_15  in_degree_1474  -1
    visit_2_15  order_active_lb_1475  -1
    visit_2_15  order_active_ub_1476  -11
    visit_2_15  service_visit_def_1477  -1
    order_2_15  connected_order_arc_1217  1
    order_2_15  connected_order_arc_1238  1
    order_2_15  connected_order_arc_1259  1
    order_2_15  connected_order_arc_1280  1
    order_2_15  connected_order_arc_1301  1
    order_2_15  connected_order_arc_1314  -1
    order_2_15  connected_order_arc_1316  -1
    order_2_15  connected_order_arc_1318  -1
    order_2_15  connected_order_arc_1320  -1
    order_2_15  connected_order_arc_1322  -1
    order_2_15  connected_order_arc_1324  -1
    order_2_15  connected_order_arc_1326  -1
    order_2_15  connected_order_arc_1328  -1
    order_2_15  connected_order_arc_1330  -1
    order_2_15  connected_order_arc_1332  -1
    order_2_15  connected_order_arc_1345  1
    order_2_15  connected_order_arc_1366  1
    order_2_15  connected_order_arc_1387  1
    order_2_15  connected_order_arc_1408  1
    order_2_15  connected_order_arc_1429  1
    order_2_15  order_active_lb_1475  1
    order_2_15  order_active_ub_1476  1
    visit_2_16  out_degree_1479  -1
    visit_2_16  in_degree_1480  -1
    visit_2_16  order_active_lb_1481  -1
    visit_2_16  order_active_ub_1482  -11
    visit_2_16  service_visit_def_1483  -1
    order_2_16  connected_order_arc_1219  1
    order_2_16  connected_order_arc_1240  1
    order_2_16  connected_order_arc_1261  1
    order_2_16  connected_order_arc_1282  1
    order_2_16  connected_order_arc_1303  1
    order_2_16  connected_order_arc_1324  1
    order_2_16  connected_order_arc_1335  -1
    order_2_16  connected_order_arc_1337  -1
    order_2_16  connected_order_arc_1339  -1
    order_2_16  connected_order_arc_1341  -1
    order_2_16  connected_order_arc_1343  -1
    order_2_16  connected_order_arc_1345  -1
    order_2_16  connected_order_arc_1347  -1
    order_2_16  connected_order_arc_1349  -1
    order_2_16  connected_order_arc_1351  -1
    order_2_16  connected_order_arc_1353  -1
    order_2_16  connected_order_arc_1368  1
    order_2_16  connected_order_arc_1389  1
    order_2_16  connected_order_arc_1410  1
    order_2_16  connected_order_arc_1431  1
    order_2_16  order_active_lb_1481  1
    order_2_16  order_active_ub_1482  1
    visit_2_17  out_degree_1485  -1
    visit_2_17  in_degree_1486  -1
    visit_2_17  order_active_lb_1487  -1
    visit_2_17  order_active_ub_1488  -11
    visit_2_17  service_visit_def_1489  -1
    order_2_17  connected_order_arc_1221  1
    order_2_17  connected_order_arc_1242  1
    order_2_17  connected_order_arc_1263  1
    order_2_17  connected_order_arc_1284  1
    order_2_17  connected_order_arc_1305  1
    order_2_17  connected_order_arc_1326  1
    order_2_17  connected_order_arc_1347  1
    order_2_17  connected_order_arc_1356  -1
    order_2_17  connected_order_arc_1358  -1
    order_2_17  connected_order_arc_1360  -1
    order_2_17  connected_order_arc_1362  -1
    order_2_17  connected_order_arc_1364  -1
    order_2_17  connected_order_arc_1366  -1
    order_2_17  connected_order_arc_1368  -1
    order_2_17  connected_order_arc_1370  -1
    order_2_17  connected_order_arc_1372  -1
    order_2_17  connected_order_arc_1374  -1
    order_2_17  connected_order_arc_1391  1
    order_2_17  connected_order_arc_1412  1
    order_2_17  connected_order_arc_1433  1
    order_2_17  order_active_lb_1487  1
    order_2_17  order_active_ub_1488  1
    visit_2_18  out_degree_1491  -1
    visit_2_18  in_degree_1492  -1
    visit_2_18  order_active_lb_1493  -1
    visit_2_18  order_active_ub_1494  -11
    visit_2_18  service_visit_def_1495  -1
    order_2_18  connected_order_arc_1223  1
    order_2_18  connected_order_arc_1244  1
    order_2_18  connected_order_arc_1265  1
    order_2_18  connected_order_arc_1286  1
    order_2_18  connected_order_arc_1307  1
    order_2_18  connected_order_arc_1328  1
    order_2_18  connected_order_arc_1349  1
    order_2_18  connected_order_arc_1370  1
    order_2_18  connected_order_arc_1377  -1
    order_2_18  connected_order_arc_1379  -1
    order_2_18  connected_order_arc_1381  -1
    order_2_18  connected_order_arc_1383  -1
    order_2_18  connected_order_arc_1385  -1
    order_2_18  connected_order_arc_1387  -1
    order_2_18  connected_order_arc_1389  -1
    order_2_18  connected_order_arc_1391  -1
    order_2_18  connected_order_arc_1393  -1
    order_2_18  connected_order_arc_1395  -1
    order_2_18  connected_order_arc_1414  1
    order_2_18  connected_order_arc_1435  1
    order_2_18  order_active_lb_1493  1
    order_2_18  order_active_ub_1494  1
    visit_2_19  out_degree_1497  -1
    visit_2_19  in_degree_1498  -1
    visit_2_19  order_active_lb_1499  -1
    visit_2_19  order_active_ub_1500  -11
    visit_2_19  service_visit_def_1501  -1
    order_2_19  connected_order_arc_1225  1
    order_2_19  connected_order_arc_1246  1
    order_2_19  connected_order_arc_1267  1
    order_2_19  connected_order_arc_1288  1
    order_2_19  connected_order_arc_1309  1
    order_2_19  connected_order_arc_1330  1
    order_2_19  connected_order_arc_1351  1
    order_2_19  connected_order_arc_1372  1
    order_2_19  connected_order_arc_1393  1
    order_2_19  connected_order_arc_1398  -1
    order_2_19  connected_order_arc_1400  -1
    order_2_19  connected_order_arc_1402  -1
    order_2_19  connected_order_arc_1404  -1
    order_2_19  connected_order_arc_1406  -1
    order_2_19  connected_order_arc_1408  -1
    order_2_19  connected_order_arc_1410  -1
    order_2_19  connected_order_arc_1412  -1
    order_2_19  connected_order_arc_1414  -1
    order_2_19  connected_order_arc_1416  -1
    order_2_19  connected_order_arc_1437  1
    order_2_19  order_active_lb_1499  1
    order_2_19  order_active_ub_1500  1
    visit_2_20  out_degree_1503  -1
    visit_2_20  in_degree_1504  -1
    visit_2_20  order_active_lb_1505  -1
    visit_2_20  order_active_ub_1506  -11
    visit_2_20  service_visit_def_1507  -1
    order_2_20  connected_order_arc_1227  1
    order_2_20  connected_order_arc_1248  1
    order_2_20  connected_order_arc_1269  1
    order_2_20  connected_order_arc_1290  1
    order_2_20  connected_order_arc_1311  1
    order_2_20  connected_order_arc_1332  1
    order_2_20  connected_order_arc_1353  1
    order_2_20  connected_order_arc_1374  1
    order_2_20  connected_order_arc_1395  1
    order_2_20  connected_order_arc_1416  1
    order_2_20  connected_order_arc_1419  -1
    order_2_20  connected_order_arc_1421  -1
    order_2_20  connected_order_arc_1423  -1
    order_2_20  connected_order_arc_1425  -1
    order_2_20  connected_order_arc_1427  -1
    order_2_20  connected_order_arc_1429  -1
    order_2_20  connected_order_arc_1431  -1
    order_2_20  connected_order_arc_1433  -1
    order_2_20  connected_order_arc_1435  -1
    order_2_20  connected_order_arc_1437  -1
    order_2_20  order_active_lb_1505  1
    order_2_20  order_active_ub_1506  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_0  arc_capacity_1195  -30
    arc_2_0_0  depot_departure_or_bypass_1438  1
    arc_2_0_0  depot_return_or_bypass_1439  1
    MARKER    'MARKER'                 'INTEND'
    load_2_0_0  arc_capacity_1195  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_10  arc_capacity_1196  -30
    arc_2_0_10  depot_departure_or_bypass_1438  1
    arc_2_0_10  in_degree_1441  1
    arc_2_0_10  original_T_including_depot_unload_1511  7.9650294035968375e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_10  arc_capacity_1196  1
    load_2_0_10  segment_load_conservation_1444  -1
    load_2_0_10  segment_prefix_lb_1445  1
    load_2_0_10  segment_prefix_ub_1446  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_11  arc_capacity_1197  -30
    arc_2_0_11  depot_departure_or_bypass_1438  1
    arc_2_0_11  in_degree_1448  1
    arc_2_0_11  original_T_including_depot_unload_1511  1.4373810231417410e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_11  arc_capacity_1197  1
    load_2_0_11  segment_load_conservation_1451  -1
    load_2_0_11  segment_prefix_lb_1452  1
    load_2_0_11  segment_prefix_ub_1453  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_12  arc_capacity_1198  -30
    arc_2_0_12  depot_departure_or_bypass_1438  1
    arc_2_0_12  in_degree_1455  1
    arc_2_0_12  original_T_including_depot_unload_1511  1.4206108045382291e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_12  arc_capacity_1198  1
    load_2_0_12  segment_load_conservation_1458  -1
    load_2_0_12  segment_prefix_lb_1459  1
    load_2_0_12  segment_prefix_ub_1460  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_13  arc_capacity_1199  -30
    arc_2_0_13  depot_departure_or_bypass_1438  1
    arc_2_0_13  in_degree_1462  1
    arc_2_0_13  original_T_including_depot_unload_1511  1.1055042743585939e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_13  arc_capacity_1199  1
    load_2_0_13  free_load_conservation_1466  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_14  arc_capacity_1200  -30
    arc_2_0_14  depot_departure_or_bypass_1438  1
    arc_2_0_14  in_degree_1468  1
    arc_2_0_14  original_T_including_depot_unload_1511  885.819758595088
    MARKER    'MARKER'                 'INTEND'
    load_2_0_14  arc_capacity_1200  1
    load_2_0_14  free_load_conservation_1472  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_15  arc_capacity_1201  -30
    arc_2_0_15  depot_departure_or_bypass_1438  1
    arc_2_0_15  in_degree_1474  1
    arc_2_0_15  original_T_including_depot_unload_1511  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_15  arc_capacity_1201  1
    load_2_0_15  free_load_conservation_1478  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_16  arc_capacity_1202  -30
    arc_2_0_16  depot_departure_or_bypass_1438  1
    arc_2_0_16  in_degree_1480  1
    arc_2_0_16  original_T_including_depot_unload_1511  1163.36883938708
    MARKER    'MARKER'                 'INTEND'
    load_2_0_16  arc_capacity_1202  1
    load_2_0_16  free_load_conservation_1484  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_17  arc_capacity_1203  -30
    arc_2_0_17  depot_departure_or_bypass_1438  1
    arc_2_0_17  in_degree_1486  1
    arc_2_0_17  original_T_including_depot_unload_1511  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_17  arc_capacity_1203  1
    load_2_0_17  free_load_conservation_1490  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_18  arc_capacity_1204  -30
    arc_2_0_18  depot_departure_or_bypass_1438  1
    arc_2_0_18  in_degree_1492  1
    arc_2_0_18  original_T_including_depot_unload_1511  9.1137190274562636e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_18  arc_capacity_1204  1
    load_2_0_18  free_load_conservation_1496  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_19  arc_capacity_1205  -30
    arc_2_0_19  depot_departure_or_bypass_1438  1
    arc_2_0_19  in_degree_1498  1
    arc_2_0_19  original_T_including_depot_unload_1511  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_19  arc_capacity_1205  1
    load_2_0_19  free_load_conservation_1502  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_20  arc_capacity_1206  -30
    arc_2_0_20  depot_departure_or_bypass_1438  1
    arc_2_0_20  in_degree_1504  1
    arc_2_0_20  original_T_including_depot_unload_1511  7.8199183337763486e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_20  arc_capacity_1206  1
    load_2_0_20  free_load_conservation_1508  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_0  arc_capacity_1207  -30
    arc_2_10_0  depot_return_or_bypass_1439  1
    arc_2_10_0  out_degree_1440  1
    arc_2_10_0  original_T_including_depot_unload_1511  7.9650294035968375e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_0  arc_capacity_1207  1
    load_2_10_0  segment_load_conservation_1444  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_11  arc_capacity_1208  -30
    arc_2_10_11  connected_order_arc_1209  -12
    arc_2_10_11  out_degree_1440  1
    arc_2_10_11  in_degree_1448  1
    arc_2_10_11  original_T_including_depot_unload_1511  7.5681404708111961e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_11  arc_capacity_1208  1
    load_2_10_11  segment_load_conservation_1444  1
    load_2_10_11  segment_load_conservation_1451  -1
    load_2_10_11  segment_prefix_lb_1452  1
    load_2_10_11  segment_prefix_ub_1453  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_12  arc_capacity_1210  -30
    arc_2_10_12  connected_order_arc_1211  -12
    arc_2_10_12  out_degree_1440  1
    arc_2_10_12  in_degree_1455  1
    arc_2_10_12  original_T_including_depot_unload_1511  6.6735284319782306e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_12  arc_capacity_1210  1
    load_2_10_12  segment_load_conservation_1444  1
    load_2_10_12  segment_load_conservation_1458  -1
    load_2_10_12  segment_prefix_lb_1459  1
    load_2_10_12  segment_prefix_ub_1460  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_13  arc_capacity_1212  -30
    arc_2_10_13  connected_order_arc_1213  -12
    arc_2_10_13  out_degree_1440  1
    arc_2_10_13  in_degree_1462  1
    arc_2_10_13  original_T_including_depot_unload_1511  1.9010369513971175e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_13  arc_capacity_1212  1
    load_2_10_13  segment_load_conservation_1444  1
    load_2_10_13  free_load_conservation_1466  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_14  arc_capacity_1214  -30
    arc_2_10_14  connected_order_arc_1215  -12
    arc_2_10_14  out_degree_1440  1
    arc_2_10_14  in_degree_1468  1
    arc_2_10_14  original_T_including_depot_unload_1511  1.6813024470003036e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_14  arc_capacity_1214  1
    load_2_10_14  segment_load_conservation_1444  1
    load_2_10_14  free_load_conservation_1472  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_15  arc_capacity_1216  -30
    arc_2_10_15  connected_order_arc_1217  -12
    arc_2_10_15  out_degree_1440  1
    arc_2_10_15  in_degree_1474  1
    arc_2_10_15  original_T_including_depot_unload_1511  9.8108674361469946e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_15  arc_capacity_1216  1
    load_2_10_15  segment_load_conservation_1444  1
    load_2_10_15  free_load_conservation_1478  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_16  arc_capacity_1218  -30
    arc_2_10_16  connected_order_arc_1219  -12
    arc_2_10_16  out_degree_1440  1
    arc_2_10_16  in_degree_1480  1
    arc_2_10_16  original_T_including_depot_unload_1511  1.9548856653783507e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_16  arc_capacity_1218  1
    load_2_10_16  segment_load_conservation_1444  1
    load_2_10_16  free_load_conservation_1484  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_17  arc_capacity_1220  -30
    arc_2_10_17  connected_order_arc_1221  -12
    arc_2_10_17  out_degree_1440  1
    arc_2_10_17  in_degree_1486  1
    arc_2_10_17  original_T_including_depot_unload_1511  3.7831268047064754e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_17  arc_capacity_1220  1
    load_2_10_17  segment_load_conservation_1444  1
    load_2_10_17  free_load_conservation_1490  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_18  arc_capacity_1222  -30
    arc_2_10_18  connected_order_arc_1223  -12
    arc_2_10_18  out_degree_1440  1
    arc_2_10_18  in_degree_1492  1
    arc_2_10_18  original_T_including_depot_unload_1511  1.7020262615645904e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_18  arc_capacity_1222  1
    load_2_10_18  segment_load_conservation_1444  1
    load_2_10_18  free_load_conservation_1496  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_19  arc_capacity_1224  -30
    arc_2_10_19  connected_order_arc_1225  -12
    arc_2_10_19  out_degree_1440  1
    arc_2_10_19  in_degree_1498  1
    arc_2_10_19  original_T_including_depot_unload_1511  5.4405628017126674e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_19  arc_capacity_1224  1
    load_2_10_19  segment_load_conservation_1444  1
    load_2_10_19  free_load_conservation_1502  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_20  arc_capacity_1226  -30
    arc_2_10_20  connected_order_arc_1227  -12
    arc_2_10_20  out_degree_1440  1
    arc_2_10_20  in_degree_1504  1
    arc_2_10_20  original_T_including_depot_unload_1511  1.5756194178147177e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_20  arc_capacity_1226  1
    load_2_10_20  segment_load_conservation_1444  1
    load_2_10_20  free_load_conservation_1508  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_0  arc_capacity_1228  -30
    arc_2_11_0  depot_return_or_bypass_1439  1
    arc_2_11_0  out_degree_1447  1
    arc_2_11_0  original_T_including_depot_unload_1511  1.4373810231417410e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_0  arc_capacity_1228  1
    load_2_11_0  segment_load_conservation_1451  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_10  arc_capacity_1229  -30
    arc_2_11_10  connected_order_arc_1230  -12
    arc_2_11_10  in_degree_1441  1
    arc_2_11_10  out_degree_1447  1
    arc_2_11_10  original_T_including_depot_unload_1511  7.5681404708111961e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_10  arc_capacity_1229  1
    load_2_11_10  segment_load_conservation_1444  -1
    load_2_11_10  segment_prefix_lb_1445  1
    load_2_11_10  segment_prefix_ub_1446  1
    load_2_11_10  segment_load_conservation_1451  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_12  arc_capacity_1231  -30
    arc_2_11_12  connected_order_arc_1232  -12
    arc_2_11_12  out_degree_1447  1
    arc_2_11_12  in_degree_1455  1
    arc_2_11_12  original_T_including_depot_unload_1511  2.2310212250199638e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_12  arc_capacity_1231  1
    load_2_11_12  segment_load_conservation_1451  1
    load_2_11_12  segment_load_conservation_1458  -1
    load_2_11_12  segment_prefix_lb_1459  1
    load_2_11_12  segment_prefix_ub_1460  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_13  arc_capacity_1233  -30
    arc_2_11_13  connected_order_arc_1234  -12
    arc_2_11_13  out_degree_1447  1
    arc_2_11_13  in_degree_1462  1
    arc_2_11_13  original_T_including_depot_unload_1511  2.4817723074148175e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_13  arc_capacity_1233  1
    load_2_11_13  segment_load_conservation_1451  1
    load_2_11_13  free_load_conservation_1466  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_14  arc_capacity_1235  -30
    arc_2_11_14  connected_order_arc_1236  -12
    arc_2_11_14  out_degree_1447  1
    arc_2_11_14  in_degree_1468  1
    arc_2_11_14  original_T_including_depot_unload_1511  2.2684160167710820e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_14  arc_capacity_1235  1
    load_2_11_14  segment_load_conservation_1451  1
    load_2_11_14  free_load_conservation_1472  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_15  arc_capacity_1237  -30
    arc_2_11_15  connected_order_arc_1238  -12
    arc_2_11_15  out_degree_1447  1
    arc_2_11_15  in_degree_1474  1
    arc_2_11_15  original_T_including_depot_unload_1511  2.9139628504456829e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_15  arc_capacity_1237  1
    load_2_11_15  segment_load_conservation_1451  1
    load_2_11_15  free_load_conservation_1478  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_16  arc_capacity_1239  -30
    arc_2_11_16  connected_order_arc_1240  -12
    arc_2_11_16  out_degree_1447  1
    arc_2_11_16  in_degree_1480  1
    arc_2_11_16  original_T_including_depot_unload_1511  2.5832867553499068e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_16  arc_capacity_1239  1
    load_2_11_16  segment_load_conservation_1451  1
    load_2_11_16  free_load_conservation_1484  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_17  arc_capacity_1241  -30
    arc_2_11_17  connected_order_arc_1242  -12
    arc_2_11_17  out_degree_1447  1
    arc_2_11_17  in_degree_1486  1
    arc_2_11_17  original_T_including_depot_unload_1511  1.0984912119828512e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_17  arc_capacity_1241  1
    load_2_11_17  segment_load_conservation_1451  1
    load_2_11_17  free_load_conservation_1490  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_18  arc_capacity_1243  -30
    arc_2_11_18  connected_order_arc_1244  -12
    arc_2_11_18  out_degree_1447  1
    arc_2_11_18  in_degree_1492  1
    arc_2_11_18  original_T_including_depot_unload_1511  2.3361705401661034e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_18  arc_capacity_1243  1
    load_2_11_18  segment_load_conservation_1451  1
    load_2_11_18  free_load_conservation_1496  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_19  arc_capacity_1245  -30
    arc_2_11_19  connected_order_arc_1246  -12
    arc_2_11_19  out_degree_1447  1
    arc_2_11_19  in_degree_1498  1
    arc_2_11_19  original_T_including_depot_unload_1511  5.7914586906741226e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_19  arc_capacity_1245  1
    load_2_11_19  segment_load_conservation_1451  1
    load_2_11_19  free_load_conservation_1502  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_20  arc_capacity_1247  -30
    arc_2_11_20  connected_order_arc_1248  -12
    arc_2_11_20  out_degree_1447  1
    arc_2_11_20  in_degree_1504  1
    arc_2_11_20  original_T_including_depot_unload_1511  2.1566797920965496e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_20  arc_capacity_1247  1
    load_2_11_20  segment_load_conservation_1451  1
    load_2_11_20  free_load_conservation_1508  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_0  arc_capacity_1249  -30
    arc_2_12_0  depot_return_or_bypass_1439  1
    arc_2_12_0  out_degree_1454  1
    arc_2_12_0  original_T_including_depot_unload_1511  1.0056399980521732e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_0  arc_capacity_1249  1
    load_2_12_0  segment_load_conservation_1458  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_10  arc_capacity_1250  -30
    arc_2_12_10  connected_order_arc_1251  -12
    arc_2_12_10  in_degree_1441  1
    arc_2_12_10  out_degree_1454  1
    arc_2_12_10  original_T_including_depot_unload_1511  3.5166546157461704e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_10  arc_capacity_1250  1
    load_2_12_10  segment_load_conservation_1444  -1
    load_2_12_10  segment_prefix_lb_1445  1
    load_2_12_10  segment_prefix_ub_1446  1
    load_2_12_10  segment_load_conservation_1458  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_11  arc_capacity_1252  -30
    arc_2_12_11  connected_order_arc_1253  -12
    arc_2_12_11  in_degree_1448  1
    arc_2_12_11  out_degree_1454  1
    arc_2_12_11  original_T_including_depot_unload_1511  926.407625506948
    MARKER    'MARKER'                 'INTEND'
    load_2_12_11  arc_capacity_1252  1
    load_2_12_11  segment_load_conservation_1451  -1
    load_2_12_11  segment_prefix_lb_1452  1
    load_2_12_11  segment_prefix_ub_1453  1
    load_2_12_11  segment_load_conservation_1458  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_13  arc_capacity_1254  -30
    arc_2_12_13  connected_order_arc_1255  -12
    arc_2_12_13  out_degree_1454  1
    arc_2_12_13  in_degree_1462  1
    arc_2_12_13  original_T_including_depot_unload_1511  2.0943827068880682e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_13  arc_capacity_1254  1
    load_2_12_13  segment_load_conservation_1458  1
    load_2_12_13  free_load_conservation_1466  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_14  arc_capacity_1256  -30
    arc_2_12_14  connected_order_arc_1257  -12
    arc_2_12_14  out_degree_1454  1
    arc_2_12_14  in_degree_1468  1
    arc_2_12_14  original_T_including_depot_unload_1511  1.8770574474563218e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_14  arc_capacity_1256  1
    load_2_12_14  segment_load_conservation_1458  1
    load_2_12_14  free_load_conservation_1472  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_15  arc_capacity_1258  -30
    arc_2_12_15  connected_order_arc_1259  -12
    arc_2_12_15  out_degree_1454  1
    arc_2_12_15  in_degree_1474  1
    arc_2_12_15  original_T_including_depot_unload_1511  1.1967280409234234e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_15  arc_capacity_1258  1
    load_2_12_15  segment_load_conservation_1458  1
    load_2_12_15  free_load_conservation_1478  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_16  arc_capacity_1260  -30
    arc_2_12_16  connected_order_arc_1261  -12
    arc_2_12_16  out_degree_1454  1
    arc_2_12_16  in_degree_1480  1
    arc_2_12_16  original_T_including_depot_unload_1511  2.1115837908099625e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_16  arc_capacity_1260  1
    load_2_12_16  segment_load_conservation_1458  1
    load_2_12_16  free_load_conservation_1484  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_17  arc_capacity_1262  -30
    arc_2_12_17  connected_order_arc_1263  -12
    arc_2_12_17  out_degree_1454  1
    arc_2_12_17  in_degree_1486  1
    arc_2_12_17  original_T_including_depot_unload_1511  5.7276146581216926e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_17  arc_capacity_1262  1
    load_2_12_17  segment_load_conservation_1458  1
    load_2_12_17  free_load_conservation_1490  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_18  arc_capacity_1264  -30
    arc_2_12_18  connected_order_arc_1265  -12
    arc_2_12_18  out_degree_1454  1
    arc_2_12_18  in_degree_1492  1
    arc_2_12_18  original_T_including_depot_unload_1511  1.8614801653445954e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_18  arc_capacity_1264  1
    load_2_12_18  segment_load_conservation_1458  1
    load_2_12_18  free_load_conservation_1496  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_19  arc_capacity_1266  -30
    arc_2_12_19  connected_order_arc_1267  -12
    arc_2_12_19  out_degree_1454  1
    arc_2_12_19  in_degree_1498  1
    arc_2_12_19  original_T_including_depot_unload_1511  8.7906342149593650e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_19  arc_capacity_1266  1
    load_2_12_19  segment_load_conservation_1458  1
    load_2_12_19  free_load_conservation_1502  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_20  arc_capacity_1268  -30
    arc_2_12_20  connected_order_arc_1269  -12
    arc_2_12_20  out_degree_1454  1
    arc_2_12_20  in_degree_1504  1
    arc_2_12_20  original_T_including_depot_unload_1511  1.7791475856216737e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_20  arc_capacity_1268  1
    load_2_12_20  segment_load_conservation_1458  1
    load_2_12_20  free_load_conservation_1508  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_0  arc_capacity_1270  -30
    arc_2_13_0  depot_return_or_bypass_1439  1
    arc_2_13_0  out_degree_1461  1
    arc_2_13_0  original_T_including_depot_unload_1511  1.1055042743585939e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_0  arc_capacity_1270  1
    load_2_13_0  free_load_conservation_1466  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_10  arc_capacity_1271  -30
    arc_2_13_10  connected_order_arc_1272  -12
    arc_2_13_10  in_degree_1441  1
    arc_2_13_10  out_degree_1461  1
    arc_2_13_10  original_T_including_depot_unload_1511  1.9010369513971175e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_10  arc_capacity_1271  1
    load_2_13_10  segment_load_conservation_1444  -1
    load_2_13_10  segment_prefix_lb_1445  1
    load_2_13_10  segment_prefix_ub_1446  1
    load_2_13_10  free_load_conservation_1466  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_11  arc_capacity_1273  -30
    arc_2_13_11  connected_order_arc_1274  -12
    arc_2_13_11  in_degree_1448  1
    arc_2_13_11  out_degree_1461  1
    arc_2_13_11  original_T_including_depot_unload_1511  2.4817723074148175e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_11  arc_capacity_1273  1
    load_2_13_11  segment_load_conservation_1451  -1
    load_2_13_11  segment_prefix_lb_1452  1
    load_2_13_11  segment_prefix_ub_1453  1
    load_2_13_11  free_load_conservation_1466  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_12  arc_capacity_1275  -30
    arc_2_13_12  connected_order_arc_1276  -12
    arc_2_13_12  in_degree_1455  1
    arc_2_13_12  out_degree_1461  1
    arc_2_13_12  original_T_including_depot_unload_1511  2.5004905239513250e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_12  arc_capacity_1275  1
    load_2_13_12  segment_load_conservation_1458  -1
    load_2_13_12  segment_prefix_lb_1459  1
    load_2_13_12  segment_prefix_ub_1460  1
    load_2_13_12  free_load_conservation_1466  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_14  arc_capacity_1277  -30
    arc_2_13_14  connected_order_arc_1278  -12
    arc_2_13_14  out_degree_1461  1
    arc_2_13_14  in_degree_1468  1
    arc_2_13_14  original_T_including_depot_unload_1511  2.1974044543706933e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_14  arc_capacity_1277  1
    load_2_13_14  free_load_conservation_1466  1
    load_2_13_14  free_load_conservation_1472  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_15  arc_capacity_1279  -30
    arc_2_13_15  connected_order_arc_1280  -12
    arc_2_13_15  out_degree_1461  1
    arc_2_13_15  in_degree_1474  1
    arc_2_13_15  original_T_including_depot_unload_1511  2.5477291514674703e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_15  arc_capacity_1279  1
    load_2_13_15  free_load_conservation_1466  1
    load_2_13_15  free_load_conservation_1478  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_16  arc_capacity_1281  -30
    arc_2_13_16  connected_order_arc_1282  -12
    arc_2_13_16  out_degree_1461  1
    arc_2_13_16  in_degree_1480  1
    arc_2_13_16  original_T_including_depot_unload_1511  2.4467085139097674e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_16  arc_capacity_1281  1
    load_2_13_16  free_load_conservation_1466  1
    load_2_13_16  free_load_conservation_1484  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_17  arc_capacity_1283  -30
    arc_2_13_17  connected_order_arc_1284  -12
    arc_2_13_17  out_degree_1461  1
    arc_2_13_17  in_degree_1486  1
    arc_2_13_17  original_T_including_depot_unload_1511  1.5402832821684894e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_17  arc_capacity_1283  1
    load_2_13_17  free_load_conservation_1466  1
    load_2_13_17  free_load_conservation_1490  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_18  arc_capacity_1285  -30
    arc_2_13_18  connected_order_arc_1286  -12
    arc_2_13_18  out_degree_1461  1
    arc_2_13_18  in_degree_1492  1
    arc_2_13_18  original_T_including_depot_unload_1511  3.0177284565053407e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_18  arc_capacity_1285  1
    load_2_13_18  free_load_conservation_1466  1
    load_2_13_18  free_load_conservation_1496  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_19  arc_capacity_1287  -30
    arc_2_13_19  connected_order_arc_1288  -12
    arc_2_13_19  out_degree_1461  1
    arc_2_13_19  in_degree_1498  1
    arc_2_13_19  original_T_including_depot_unload_1511  1.9185455792071525e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_19  arc_capacity_1287  1
    load_2_13_19  free_load_conservation_1466  1
    load_2_13_19  free_load_conservation_1502  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_20  arc_capacity_1289  -30
    arc_2_13_20  connected_order_arc_1290  -12
    arc_2_13_20  out_degree_1461  1
    arc_2_13_20  in_degree_1504  1
    arc_2_13_20  original_T_including_depot_unload_1511  3.2767382990070683e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_20  arc_capacity_1289  1
    load_2_13_20  free_load_conservation_1466  1
    load_2_13_20  free_load_conservation_1508  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_0  arc_capacity_1291  -30
    arc_2_14_0  depot_return_or_bypass_1439  1
    arc_2_14_0  out_degree_1467  1
    arc_2_14_0  original_T_including_depot_unload_1511  885.819758595088
    MARKER    'MARKER'                 'INTEND'
    load_2_14_0  arc_capacity_1291  1
    load_2_14_0  free_load_conservation_1472  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_10  arc_capacity_1292  -30
    arc_2_14_10  connected_order_arc_1293  -12
    arc_2_14_10  in_degree_1441  1
    arc_2_14_10  out_degree_1467  1
    arc_2_14_10  original_T_including_depot_unload_1511  1.6813024470003036e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_10  arc_capacity_1292  1
    load_2_14_10  segment_load_conservation_1444  -1
    load_2_14_10  segment_prefix_lb_1445  1
    load_2_14_10  segment_prefix_ub_1446  1
    load_2_14_10  free_load_conservation_1472  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_11  arc_capacity_1294  -30
    arc_2_14_11  connected_order_arc_1295  -12
    arc_2_14_11  in_degree_1448  1
    arc_2_14_11  out_degree_1467  1
    arc_2_14_11  original_T_including_depot_unload_1511  2.2684160167710820e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_11  arc_capacity_1294  1
    load_2_14_11  segment_load_conservation_1451  -1
    load_2_14_11  segment_prefix_lb_1452  1
    load_2_14_11  segment_prefix_ub_1453  1
    load_2_14_11  free_load_conservation_1472  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_12  arc_capacity_1296  -30
    arc_2_14_12  connected_order_arc_1297  -12
    arc_2_14_12  in_degree_1455  1
    arc_2_14_12  out_degree_1467  1
    arc_2_14_12  original_T_including_depot_unload_1511  2.2831577662501127e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_12  arc_capacity_1296  1
    load_2_14_12  segment_load_conservation_1458  -1
    load_2_14_12  segment_prefix_lb_1459  1
    load_2_14_12  segment_prefix_ub_1460  1
    load_2_14_12  free_load_conservation_1472  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_13  arc_capacity_1298  -30
    arc_2_14_13  connected_order_arc_1299  -12
    arc_2_14_13  in_degree_1462  1
    arc_2_14_13  out_degree_1467  1
    arc_2_14_13  original_T_including_depot_unload_1511  2.1974044543706933e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_13  arc_capacity_1298  1
    load_2_14_13  free_load_conservation_1466  -1
    load_2_14_13  free_load_conservation_1472  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_15  arc_capacity_1300  -30
    arc_2_14_15  connected_order_arc_1301  -12
    arc_2_14_15  out_degree_1467  1
    arc_2_14_15  in_degree_1474  1
    arc_2_14_15  original_T_including_depot_unload_1511  2.3420148578372859e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_15  arc_capacity_1300  1
    load_2_14_15  free_load_conservation_1472  1
    load_2_14_15  free_load_conservation_1478  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_16  arc_capacity_1302  -30
    arc_2_14_16  connected_order_arc_1303  -12
    arc_2_14_16  out_degree_1467  1
    arc_2_14_16  in_degree_1480  1
    arc_2_14_16  original_T_including_depot_unload_1511  3.5284009487492966e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_16  arc_capacity_1302  1
    load_2_14_16  free_load_conservation_1472  1
    load_2_14_16  free_load_conservation_1484  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_17  arc_capacity_1304  -30
    arc_2_14_17  connected_order_arc_1305  -12
    arc_2_14_17  out_degree_1467  1
    arc_2_14_17  in_degree_1486  1
    arc_2_14_17  original_T_including_depot_unload_1511  1.3209989051658847e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_17  arc_capacity_1304  1
    load_2_14_17  free_load_conservation_1472  1
    load_2_14_17  free_load_conservation_1490  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_18  arc_capacity_1306  -30
    arc_2_14_18  connected_order_arc_1307  -12
    arc_2_14_18  out_degree_1467  1
    arc_2_14_18  in_degree_1492  1
    arc_2_14_18  original_T_including_depot_unload_1511  2.1282400853806328e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_18  arc_capacity_1306  1
    load_2_14_18  free_load_conservation_1472  1
    load_2_14_18  free_load_conservation_1496  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_19  arc_capacity_1308  -30
    arc_2_14_19  connected_order_arc_1309  -12
    arc_2_14_19  out_degree_1467  1
    arc_2_14_19  in_degree_1498  1
    arc_2_14_19  original_T_including_depot_unload_1511  1.7093216071319850e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_19  arc_capacity_1308  1
    load_2_14_19  free_load_conservation_1472  1
    load_2_14_19  free_load_conservation_1502  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_20  arc_capacity_1310  -30
    arc_2_14_20  connected_order_arc_1311  -12
    arc_2_14_20  out_degree_1467  1
    arc_2_14_20  in_degree_1504  1
    arc_2_14_20  original_T_including_depot_unload_1511  1.1216289013953633e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_20  arc_capacity_1310  1
    load_2_14_20  free_load_conservation_1472  1
    load_2_14_20  free_load_conservation_1508  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_0  arc_capacity_1312  -30
    arc_2_15_0  depot_return_or_bypass_1439  1
    arc_2_15_0  out_degree_1473  1
    arc_2_15_0  original_T_including_depot_unload_1511  1.5649189987028049e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_0  arc_capacity_1312  1
    load_2_15_0  free_load_conservation_1478  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_10  arc_capacity_1313  -30
    arc_2_15_10  connected_order_arc_1314  -12
    arc_2_15_10  in_degree_1441  1
    arc_2_15_10  out_degree_1473  1
    arc_2_15_10  original_T_including_depot_unload_1511  9.8108674361469946e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_10  arc_capacity_1313  1
    load_2_15_10  segment_load_conservation_1444  -1
    load_2_15_10  segment_prefix_lb_1445  1
    load_2_15_10  segment_prefix_ub_1446  1
    load_2_15_10  free_load_conservation_1478  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_11  arc_capacity_1315  -30
    arc_2_15_11  connected_order_arc_1316  -12
    arc_2_15_11  in_degree_1448  1
    arc_2_15_11  out_degree_1473  1
    arc_2_15_11  original_T_including_depot_unload_1511  2.9139628504456829e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_11  arc_capacity_1315  1
    load_2_15_11  segment_load_conservation_1451  -1
    load_2_15_11  segment_prefix_lb_1452  1
    load_2_15_11  segment_prefix_ub_1453  1
    load_2_15_11  free_load_conservation_1478  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_12  arc_capacity_1317  -30
    arc_2_15_12  connected_order_arc_1318  -12
    arc_2_15_12  in_degree_1455  1
    arc_2_15_12  out_degree_1473  1
    arc_2_15_12  original_T_including_depot_unload_1511  5.1169459347980438e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_12  arc_capacity_1317  1
    load_2_15_12  segment_load_conservation_1458  -1
    load_2_15_12  segment_prefix_lb_1459  1
    load_2_15_12  segment_prefix_ub_1460  1
    load_2_15_12  free_load_conservation_1478  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_13  arc_capacity_1319  -30
    arc_2_15_13  connected_order_arc_1320  -12
    arc_2_15_13  in_degree_1462  1
    arc_2_15_13  out_degree_1473  1
    arc_2_15_13  original_T_including_depot_unload_1511  2.5477291514674703e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_13  arc_capacity_1319  1
    load_2_15_13  free_load_conservation_1466  -1
    load_2_15_13  free_load_conservation_1478  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_14  arc_capacity_1321  -30
    arc_2_15_14  connected_order_arc_1322  -12
    arc_2_15_14  in_degree_1468  1
    arc_2_15_14  out_degree_1473  1
    arc_2_15_14  original_T_including_depot_unload_1511  2.3420148578372859e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_14  arc_capacity_1321  1
    load_2_15_14  free_load_conservation_1472  -1
    load_2_15_14  free_load_conservation_1478  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_16  arc_capacity_1323  -30
    arc_2_15_16  connected_order_arc_1324  -12
    arc_2_15_16  out_degree_1473  1
    arc_2_15_16  in_degree_1480  1
    arc_2_15_16  original_T_including_depot_unload_1511  2.6729202257370252e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_16  arc_capacity_1323  1
    load_2_15_16  free_load_conservation_1478  1
    load_2_15_16  free_load_conservation_1484  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_17  arc_capacity_1325  -30
    arc_2_15_17  connected_order_arc_1326  -12
    arc_2_15_17  out_degree_1473  1
    arc_2_15_17  in_degree_1486  1
    arc_2_15_17  original_T_including_depot_unload_1511  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_17  arc_capacity_1325  1
    load_2_15_17  free_load_conservation_1478  1
    load_2_15_17  free_load_conservation_1490  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_18  arc_capacity_1327  -30
    arc_2_15_18  connected_order_arc_1328  -12
    arc_2_15_18  out_degree_1473  1
    arc_2_15_18  in_degree_1492  1
    arc_2_15_18  original_T_including_depot_unload_1511  2.4332256311874226e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_18  arc_capacity_1327  1
    load_2_15_18  free_load_conservation_1478  1
    load_2_15_18  free_load_conservation_1496  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_19  arc_capacity_1329  -30
    arc_2_15_19  connected_order_arc_1330  -12
    arc_2_15_19  out_degree_1473  1
    arc_2_15_19  in_degree_1498  1
    arc_2_15_19  original_T_including_depot_unload_1511  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_2_15_19  arc_capacity_1329  1
    load_2_15_19  free_load_conservation_1478  1
    load_2_15_19  free_load_conservation_1502  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_20  arc_capacity_1331  -30
    arc_2_15_20  connected_order_arc_1332  -12
    arc_2_15_20  out_degree_1473  1
    arc_2_15_20  in_degree_1504  1
    arc_2_15_20  original_T_including_depot_unload_1511  2.2299340442558691e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_20  arc_capacity_1331  1
    load_2_15_20  free_load_conservation_1478  1
    load_2_15_20  free_load_conservation_1508  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_0  arc_capacity_1333  -30
    arc_2_16_0  depot_return_or_bypass_1439  1
    arc_2_16_0  out_degree_1479  1
    arc_2_16_0  original_T_including_depot_unload_1511  1163.36883938708
    MARKER    'MARKER'                 'INTEND'
    load_2_16_0  arc_capacity_1333  1
    load_2_16_0  free_load_conservation_1484  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_10  arc_capacity_1334  -30
    arc_2_16_10  connected_order_arc_1335  -12
    arc_2_16_10  in_degree_1441  1
    arc_2_16_10  out_degree_1479  1
    arc_2_16_10  original_T_including_depot_unload_1511  1.9548856653783507e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_10  arc_capacity_1334  1
    load_2_16_10  segment_load_conservation_1444  -1
    load_2_16_10  segment_prefix_lb_1445  1
    load_2_16_10  segment_prefix_ub_1446  1
    load_2_16_10  free_load_conservation_1484  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_11  arc_capacity_1336  -30
    arc_2_16_11  connected_order_arc_1337  -12
    arc_2_16_11  in_degree_1448  1
    arc_2_16_11  out_degree_1479  1
    arc_2_16_11  original_T_including_depot_unload_1511  2.5832867553499068e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_11  arc_capacity_1336  1
    load_2_16_11  segment_load_conservation_1451  -1
    load_2_16_11  segment_prefix_lb_1452  1
    load_2_16_11  segment_prefix_ub_1453  1
    load_2_16_11  free_load_conservation_1484  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_12  arc_capacity_1338  -30
    arc_2_16_12  connected_order_arc_1339  -12
    arc_2_16_12  in_degree_1455  1
    arc_2_16_12  out_degree_1479  1
    arc_2_16_12  original_T_including_depot_unload_1511  2.5820660682901439e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_12  arc_capacity_1338  1
    load_2_16_12  segment_load_conservation_1458  -1
    load_2_16_12  segment_prefix_lb_1459  1
    load_2_16_12  segment_prefix_ub_1460  1
    load_2_16_12  free_load_conservation_1484  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_13  arc_capacity_1340  -30
    arc_2_16_13  connected_order_arc_1341  -12
    arc_2_16_13  in_degree_1462  1
    arc_2_16_13  out_degree_1479  1
    arc_2_16_13  original_T_including_depot_unload_1511  2.4467085139097674e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_13  arc_capacity_1340  1
    load_2_16_13  free_load_conservation_1466  -1
    load_2_16_13  free_load_conservation_1484  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_14  arc_capacity_1342  -30
    arc_2_16_14  connected_order_arc_1343  -12
    arc_2_16_14  in_degree_1468  1
    arc_2_16_14  out_degree_1479  1
    arc_2_16_14  original_T_including_depot_unload_1511  3.5284009487492966e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_14  arc_capacity_1342  1
    load_2_16_14  free_load_conservation_1472  -1
    load_2_16_14  free_load_conservation_1484  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_15  arc_capacity_1344  -30
    arc_2_16_15  connected_order_arc_1345  -12
    arc_2_16_15  in_degree_1474  1
    arc_2_16_15  out_degree_1479  1
    arc_2_16_15  original_T_including_depot_unload_1511  2.6729202257370252e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_15  arc_capacity_1344  1
    load_2_16_15  free_load_conservation_1478  -1
    load_2_16_15  free_load_conservation_1484  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_17  arc_capacity_1346  -30
    arc_2_16_17  connected_order_arc_1347  -12
    arc_2_16_17  out_degree_1479  1
    arc_2_16_17  in_degree_1486  1
    arc_2_16_17  original_T_including_depot_unload_1511  1.5818623486522529e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_17  arc_capacity_1346  1
    load_2_16_17  free_load_conservation_1484  1
    load_2_16_17  free_load_conservation_1490  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_18  arc_capacity_1348  -30
    arc_2_16_18  connected_order_arc_1349  -12
    arc_2_16_18  out_degree_1479  1
    arc_2_16_18  in_degree_1492  1
    arc_2_16_18  original_T_including_depot_unload_1511  2.5289455774621715e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_18  arc_capacity_1348  1
    load_2_16_18  free_load_conservation_1484  1
    load_2_16_18  free_load_conservation_1496  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_19  arc_capacity_1350  -30
    arc_2_16_19  connected_order_arc_1351  -12
    arc_2_16_19  out_degree_1479  1
    arc_2_16_19  in_degree_1498  1
    arc_2_16_19  original_T_including_depot_unload_1511  2.0359275139821484e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_19  arc_capacity_1350  1
    load_2_16_19  free_load_conservation_1484  1
    load_2_16_19  free_load_conservation_1502  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_20  arc_capacity_1352  -30
    arc_2_16_20  connected_order_arc_1353  -12
    arc_2_16_20  out_degree_1479  1
    arc_2_16_20  in_degree_1504  1
    arc_2_16_20  original_T_including_depot_unload_1511  4.5764912346489922e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_20  arc_capacity_1352  1
    load_2_16_20  free_load_conservation_1484  1
    load_2_16_20  free_load_conservation_1508  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_0  arc_capacity_1354  -30
    arc_2_17_0  depot_return_or_bypass_1439  1
    arc_2_17_0  out_degree_1485  1
    arc_2_17_0  original_T_including_depot_unload_1511  4.3781915129362238e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_0  arc_capacity_1354  1
    load_2_17_0  free_load_conservation_1490  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_10  arc_capacity_1355  -30
    arc_2_17_10  connected_order_arc_1356  -12
    arc_2_17_10  in_degree_1441  1
    arc_2_17_10  out_degree_1485  1
    arc_2_17_10  original_T_including_depot_unload_1511  3.7831268047064754e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_10  arc_capacity_1355  1
    load_2_17_10  segment_load_conservation_1444  -1
    load_2_17_10  segment_prefix_lb_1445  1
    load_2_17_10  segment_prefix_ub_1446  1
    load_2_17_10  free_load_conservation_1490  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_11  arc_capacity_1357  -30
    arc_2_17_11  connected_order_arc_1358  -12
    arc_2_17_11  in_degree_1448  1
    arc_2_17_11  out_degree_1485  1
    arc_2_17_11  original_T_including_depot_unload_1511  1.0984912119828512e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_11  arc_capacity_1357  1
    load_2_17_11  segment_load_conservation_1451  -1
    load_2_17_11  segment_prefix_lb_1452  1
    load_2_17_11  segment_prefix_ub_1453  1
    load_2_17_11  free_load_conservation_1490  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_12  arc_capacity_1359  -30
    arc_2_17_12  connected_order_arc_1360  -12
    arc_2_17_12  in_degree_1455  1
    arc_2_17_12  out_degree_1485  1
    arc_2_17_12  original_T_including_depot_unload_1511  1.0379751075251477e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_12  arc_capacity_1359  1
    load_2_17_12  segment_load_conservation_1458  -1
    load_2_17_12  segment_prefix_lb_1459  1
    load_2_17_12  segment_prefix_ub_1460  1
    load_2_17_12  free_load_conservation_1490  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_13  arc_capacity_1361  -30
    arc_2_17_13  connected_order_arc_1362  -12
    arc_2_17_13  in_degree_1462  1
    arc_2_17_13  out_degree_1485  1
    arc_2_17_13  original_T_including_depot_unload_1511  1.5402832821684894e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_13  arc_capacity_1361  1
    load_2_17_13  free_load_conservation_1466  -1
    load_2_17_13  free_load_conservation_1490  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_14  arc_capacity_1363  -30
    arc_2_17_14  connected_order_arc_1364  -12
    arc_2_17_14  in_degree_1468  1
    arc_2_17_14  out_degree_1485  1
    arc_2_17_14  original_T_including_depot_unload_1511  1.3209989051658847e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_14  arc_capacity_1363  1
    load_2_17_14  free_load_conservation_1472  -1
    load_2_17_14  free_load_conservation_1490  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_15  arc_capacity_1365  -30
    arc_2_17_15  connected_order_arc_1366  -12
    arc_2_17_15  in_degree_1474  1
    arc_2_17_15  out_degree_1485  1
    arc_2_17_15  original_T_including_depot_unload_1511  1.2825655918810096e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_15  arc_capacity_1365  1
    load_2_17_15  free_load_conservation_1478  -1
    load_2_17_15  free_load_conservation_1490  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_16  arc_capacity_1367  -30
    arc_2_17_16  connected_order_arc_1368  -12
    arc_2_17_16  in_degree_1480  1
    arc_2_17_16  out_degree_1485  1
    arc_2_17_16  original_T_including_depot_unload_1511  1.5818623486522529e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_16  arc_capacity_1367  1
    load_2_17_16  free_load_conservation_1484  -1
    load_2_17_16  free_load_conservation_1490  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_18  arc_capacity_1369  -30
    arc_2_17_18  connected_order_arc_1370  -12
    arc_2_17_18  out_degree_1485  1
    arc_2_17_18  in_degree_1492  1
    arc_2_17_18  original_T_including_depot_unload_1511  1.3290297652049680e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_18  arc_capacity_1369  1
    load_2_17_18  free_load_conservation_1490  1
    load_2_17_18  free_load_conservation_1496  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_19  arc_capacity_1371  -30
    arc_2_17_19  connected_order_arc_1372  -12
    arc_2_17_19  out_degree_1485  1
    arc_2_17_19  in_degree_1498  1
    arc_2_17_19  original_T_including_depot_unload_1511  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_2_17_19  arc_capacity_1371  1
    load_2_17_19  free_load_conservation_1490  1
    load_2_17_19  free_load_conservation_1502  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_20  arc_capacity_1373  -30
    arc_2_17_20  connected_order_arc_1374  -12
    arc_2_17_20  out_degree_1485  1
    arc_2_17_20  in_degree_1504  1
    arc_2_17_20  original_T_including_depot_unload_1511  1.2188376307261726e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_20  arc_capacity_1373  1
    load_2_17_20  free_load_conservation_1490  1
    load_2_17_20  free_load_conservation_1508  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_0  arc_capacity_1375  -30
    arc_2_18_0  depot_return_or_bypass_1439  1
    arc_2_18_0  out_degree_1491  1
    arc_2_18_0  original_T_including_depot_unload_1511  9.1137190274562636e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_0  arc_capacity_1375  1
    load_2_18_0  free_load_conservation_1496  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_10  arc_capacity_1376  -30
    arc_2_18_10  connected_order_arc_1377  -12
    arc_2_18_10  in_degree_1441  1
    arc_2_18_10  out_degree_1491  1
    arc_2_18_10  original_T_including_depot_unload_1511  1.7020262615645904e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_10  arc_capacity_1376  1
    load_2_18_10  segment_load_conservation_1444  -1
    load_2_18_10  segment_prefix_lb_1445  1
    load_2_18_10  segment_prefix_ub_1446  1
    load_2_18_10  free_load_conservation_1496  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_11  arc_capacity_1378  -30
    arc_2_18_11  connected_order_arc_1379  -12
    arc_2_18_11  in_degree_1448  1
    arc_2_18_11  out_degree_1491  1
    arc_2_18_11  original_T_including_depot_unload_1511  2.3361705401661034e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_11  arc_capacity_1378  1
    load_2_18_11  segment_load_conservation_1451  -1
    load_2_18_11  segment_prefix_lb_1452  1
    load_2_18_11  segment_prefix_ub_1453  1
    load_2_18_11  free_load_conservation_1496  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_12  arc_capacity_1380  -30
    arc_2_18_12  connected_order_arc_1381  -12
    arc_2_18_12  in_degree_1455  1
    arc_2_18_12  out_degree_1491  1
    arc_2_18_12  original_T_including_depot_unload_1511  2.3310908183310389e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_12  arc_capacity_1380  1
    load_2_18_12  segment_load_conservation_1458  -1
    load_2_18_12  segment_prefix_lb_1459  1
    load_2_18_12  segment_prefix_ub_1460  1
    load_2_18_12  free_load_conservation_1496  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_13  arc_capacity_1382  -30
    arc_2_18_13  connected_order_arc_1383  -12
    arc_2_18_13  in_degree_1462  1
    arc_2_18_13  out_degree_1491  1
    arc_2_18_13  original_T_including_depot_unload_1511  3.0177284565053407e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_13  arc_capacity_1382  1
    load_2_18_13  free_load_conservation_1466  -1
    load_2_18_13  free_load_conservation_1496  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_14  arc_capacity_1384  -30
    arc_2_18_14  connected_order_arc_1385  -12
    arc_2_18_14  in_degree_1468  1
    arc_2_18_14  out_degree_1491  1
    arc_2_18_14  original_T_including_depot_unload_1511  2.1282400853806328e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_14  arc_capacity_1384  1
    load_2_18_14  free_load_conservation_1472  -1
    load_2_18_14  free_load_conservation_1496  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_15  arc_capacity_1386  -30
    arc_2_18_15  connected_order_arc_1387  -12
    arc_2_18_15  in_degree_1474  1
    arc_2_18_15  out_degree_1491  1
    arc_2_18_15  original_T_including_depot_unload_1511  2.4332256311874226e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_15  arc_capacity_1386  1
    load_2_18_15  free_load_conservation_1478  -1
    load_2_18_15  free_load_conservation_1496  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_16  arc_capacity_1388  -30
    arc_2_18_16  connected_order_arc_1389  -12
    arc_2_18_16  in_degree_1480  1
    arc_2_18_16  out_degree_1491  1
    arc_2_18_16  original_T_including_depot_unload_1511  2.5289455774621715e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_16  arc_capacity_1388  1
    load_2_18_16  free_load_conservation_1484  -1
    load_2_18_16  free_load_conservation_1496  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_17  arc_capacity_1390  -30
    arc_2_18_17  connected_order_arc_1391  -12
    arc_2_18_17  in_degree_1486  1
    arc_2_18_17  out_degree_1491  1
    arc_2_18_17  original_T_including_depot_unload_1511  1.3290297652049680e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_17  arc_capacity_1390  1
    load_2_18_17  free_load_conservation_1490  -1
    load_2_18_17  free_load_conservation_1496  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_19  arc_capacity_1392  -30
    arc_2_18_19  connected_order_arc_1393  -12
    arc_2_18_19  out_degree_1491  1
    arc_2_18_19  in_degree_1498  1
    arc_2_18_19  original_T_including_depot_unload_1511  1.7947282495227562e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_19  arc_capacity_1392  1
    load_2_18_19  free_load_conservation_1496  1
    load_2_18_19  free_load_conservation_1502  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_20  arc_capacity_1394  -30
    arc_2_18_20  connected_order_arc_1395  -12
    arc_2_18_20  out_degree_1491  1
    arc_2_18_20  in_degree_1504  1
    arc_2_18_20  original_T_including_depot_unload_1511  2.7370069334295619e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_20  arc_capacity_1394  1
    load_2_18_20  free_load_conservation_1496  1
    load_2_18_20  free_load_conservation_1508  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_0  arc_capacity_1396  -30
    arc_2_19_0  depot_return_or_bypass_1439  1
    arc_2_19_0  out_degree_1497  1
    arc_2_19_0  original_T_including_depot_unload_1511  9.3107064071151524e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_0  arc_capacity_1396  1
    load_2_19_0  free_load_conservation_1502  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_10  arc_capacity_1397  -30
    arc_2_19_10  connected_order_arc_1398  -12
    arc_2_19_10  in_degree_1441  1
    arc_2_19_10  out_degree_1497  1
    arc_2_19_10  original_T_including_depot_unload_1511  5.4405628017126674e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_10  arc_capacity_1397  1
    load_2_19_10  segment_load_conservation_1444  -1
    load_2_19_10  segment_prefix_lb_1445  1
    load_2_19_10  segment_prefix_ub_1446  1
    load_2_19_10  free_load_conservation_1502  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_11  arc_capacity_1399  -30
    arc_2_19_11  connected_order_arc_1400  -12
    arc_2_19_11  in_degree_1448  1
    arc_2_19_11  out_degree_1497  1
    arc_2_19_11  original_T_including_depot_unload_1511  5.7914586906741226e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_11  arc_capacity_1399  1
    load_2_19_11  segment_load_conservation_1451  -1
    load_2_19_11  segment_prefix_lb_1452  1
    load_2_19_11  segment_prefix_ub_1453  1
    load_2_19_11  free_load_conservation_1502  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_12  arc_capacity_1401  -30
    arc_2_19_12  connected_order_arc_1402  -12
    arc_2_19_12  in_degree_1455  1
    arc_2_19_12  out_degree_1497  1
    arc_2_19_12  original_T_including_depot_unload_1511  6.6929586395597710e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_12  arc_capacity_1401  1
    load_2_19_12  segment_load_conservation_1458  -1
    load_2_19_12  segment_prefix_lb_1459  1
    load_2_19_12  segment_prefix_ub_1460  1
    load_2_19_12  free_load_conservation_1502  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_13  arc_capacity_1403  -30
    arc_2_19_13  connected_order_arc_1404  -12
    arc_2_19_13  in_degree_1462  1
    arc_2_19_13  out_degree_1497  1
    arc_2_19_13  original_T_including_depot_unload_1511  1.9185455792071525e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_13  arc_capacity_1403  1
    load_2_19_13  free_load_conservation_1466  -1
    load_2_19_13  free_load_conservation_1502  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_14  arc_capacity_1405  -30
    arc_2_19_14  connected_order_arc_1406  -12
    arc_2_19_14  in_degree_1468  1
    arc_2_19_14  out_degree_1497  1
    arc_2_19_14  original_T_including_depot_unload_1511  1.7093216071319850e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_14  arc_capacity_1405  1
    load_2_19_14  free_load_conservation_1472  -1
    load_2_19_14  free_load_conservation_1502  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_15  arc_capacity_1407  -30
    arc_2_19_15  connected_order_arc_1408  -12
    arc_2_19_15  in_degree_1474  1
    arc_2_19_15  out_degree_1497  1
    arc_2_19_15  original_T_including_depot_unload_1511  639.254012076171
    MARKER    'MARKER'                 'INTEND'
    load_2_19_15  arc_capacity_1407  1
    load_2_19_15  free_load_conservation_1478  -1
    load_2_19_15  free_load_conservation_1502  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_16  arc_capacity_1409  -30
    arc_2_19_16  connected_order_arc_1410  -12
    arc_2_19_16  in_degree_1480  1
    arc_2_19_16  out_degree_1497  1
    arc_2_19_16  original_T_including_depot_unload_1511  2.0359275139821484e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_16  arc_capacity_1409  1
    load_2_19_16  free_load_conservation_1484  -1
    load_2_19_16  free_load_conservation_1502  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_17  arc_capacity_1411  -30
    arc_2_19_17  connected_order_arc_1412  -12
    arc_2_19_17  in_degree_1486  1
    arc_2_19_17  out_degree_1497  1
    arc_2_19_17  original_T_including_depot_unload_1511  711.375155739141
    MARKER    'MARKER'                 'INTEND'
    load_2_19_17  arc_capacity_1411  1
    load_2_19_17  free_load_conservation_1490  -1
    load_2_19_17  free_load_conservation_1502  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_18  arc_capacity_1413  -30
    arc_2_19_18  connected_order_arc_1414  -12
    arc_2_19_18  in_degree_1492  1
    arc_2_19_18  out_degree_1497  1
    arc_2_19_18  original_T_including_depot_unload_1511  1.7947282495227562e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_18  arc_capacity_1413  1
    load_2_19_18  free_load_conservation_1496  -1
    load_2_19_18  free_load_conservation_1502  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_20  arc_capacity_1415  -30
    arc_2_19_20  connected_order_arc_1416  -12
    arc_2_19_20  out_degree_1497  1
    arc_2_19_20  in_degree_1504  1
    arc_2_19_20  original_T_including_depot_unload_1511  1.5971628811503840e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_20  arc_capacity_1415  1
    load_2_19_20  free_load_conservation_1502  1
    load_2_19_20  free_load_conservation_1508  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_0  arc_capacity_1417  -30
    arc_2_20_0  depot_return_or_bypass_1439  1
    arc_2_20_0  out_degree_1503  1
    arc_2_20_0  original_T_including_depot_unload_1511  7.8199183337763486e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_0  arc_capacity_1417  1
    load_2_20_0  free_load_conservation_1508  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_10  arc_capacity_1418  -30
    arc_2_20_10  connected_order_arc_1419  -12
    arc_2_20_10  in_degree_1441  1
    arc_2_20_10  out_degree_1503  1
    arc_2_20_10  original_T_including_depot_unload_1511  1.5756194178147177e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_10  arc_capacity_1418  1
    load_2_20_10  segment_load_conservation_1444  -1
    load_2_20_10  segment_prefix_lb_1445  1
    load_2_20_10  segment_prefix_ub_1446  1
    load_2_20_10  free_load_conservation_1508  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_11  arc_capacity_1420  -30
    arc_2_20_11  connected_order_arc_1421  -12
    arc_2_20_11  in_degree_1448  1
    arc_2_20_11  out_degree_1503  1
    arc_2_20_11  original_T_including_depot_unload_1511  2.1566797920965496e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_11  arc_capacity_1420  1
    load_2_20_11  segment_load_conservation_1451  -1
    load_2_20_11  segment_prefix_lb_1452  1
    load_2_20_11  segment_prefix_ub_1453  1
    load_2_20_11  free_load_conservation_1508  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_12  arc_capacity_1422  -30
    arc_2_20_12  connected_order_arc_1423  -12
    arc_2_20_12  in_degree_1455  1
    arc_2_20_12  out_degree_1503  1
    arc_2_20_12  original_T_including_depot_unload_1511  2.1729620766552225e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_12  arc_capacity_1422  1
    load_2_20_12  segment_load_conservation_1458  -1
    load_2_20_12  segment_prefix_lb_1459  1
    load_2_20_12  segment_prefix_ub_1460  1
    load_2_20_12  free_load_conservation_1508  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_13  arc_capacity_1424  -30
    arc_2_20_13  connected_order_arc_1425  -12
    arc_2_20_13  in_degree_1462  1
    arc_2_20_13  out_degree_1503  1
    arc_2_20_13  original_T_including_depot_unload_1511  3.2767382990070683e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_13  arc_capacity_1424  1
    load_2_20_13  free_load_conservation_1466  -1
    load_2_20_13  free_load_conservation_1508  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_14  arc_capacity_1426  -30
    arc_2_20_14  connected_order_arc_1427  -12
    arc_2_20_14  in_degree_1468  1
    arc_2_20_14  out_degree_1503  1
    arc_2_20_14  original_T_including_depot_unload_1511  1.1216289013953633e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_14  arc_capacity_1426  1
    load_2_20_14  free_load_conservation_1472  -1
    load_2_20_14  free_load_conservation_1508  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_15  arc_capacity_1428  -30
    arc_2_20_15  connected_order_arc_1429  -12
    arc_2_20_15  in_degree_1474  1
    arc_2_20_15  out_degree_1503  1
    arc_2_20_15  original_T_including_depot_unload_1511  2.2299340442558691e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_15  arc_capacity_1428  1
    load_2_20_15  free_load_conservation_1478  -1
    load_2_20_15  free_load_conservation_1508  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_16  arc_capacity_1430  -30
    arc_2_20_16  connected_order_arc_1431  -12
    arc_2_20_16  in_degree_1480  1
    arc_2_20_16  out_degree_1503  1
    arc_2_20_16  original_T_including_depot_unload_1511  4.5764912346489922e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_16  arc_capacity_1430  1
    load_2_20_16  free_load_conservation_1484  -1
    load_2_20_16  free_load_conservation_1508  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_17  arc_capacity_1432  -30
    arc_2_20_17  connected_order_arc_1433  -12
    arc_2_20_17  in_degree_1486  1
    arc_2_20_17  out_degree_1503  1
    arc_2_20_17  original_T_including_depot_unload_1511  1.2188376307261726e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_17  arc_capacity_1432  1
    load_2_20_17  free_load_conservation_1490  -1
    load_2_20_17  free_load_conservation_1508  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_18  arc_capacity_1434  -30
    arc_2_20_18  connected_order_arc_1435  -12
    arc_2_20_18  in_degree_1492  1
    arc_2_20_18  out_degree_1503  1
    arc_2_20_18  original_T_including_depot_unload_1511  2.7370069334295619e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_18  arc_capacity_1434  1
    load_2_20_18  free_load_conservation_1496  -1
    load_2_20_18  free_load_conservation_1508  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_19  arc_capacity_1436  -30
    arc_2_20_19  connected_order_arc_1437  -12
    arc_2_20_19  in_degree_1498  1
    arc_2_20_19  out_degree_1503  1
    arc_2_20_19  original_T_including_depot_unload_1511  1.5971628811503840e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_19  arc_capacity_1436  1
    load_2_20_19  free_load_conservation_1502  -1
    load_2_20_19  free_load_conservation_1508  1
RHS
    RHS1      OBJ       -2.7890522252863448e-01
    RHS1      onehot_4_32  1
    RHS1      onehot_6_53  1
    RHS1      onehot_34_88  1
    RHS1      onehot_3_117  1
    RHS1      onehot_22_152  1
    RHS1      onehot_5_187  1
    RHS1      onehot_27_204  1
    RHS1      onehot_8_233  1
    RHS1      stock_ub_237  32
    RHS1      parent_nonstrict_scope_238  2.9239893120797078e-01
    RHS1      normalization_295  1
    RHS1      connected_order_arc_411  -13
    RHS1      connected_order_arc_413  -13
    RHS1      connected_order_arc_415  -13
    RHS1      connected_order_arc_417  -13
    RHS1      connected_order_arc_419  -13
    RHS1      connected_order_arc_421  -13
    RHS1      connected_order_arc_423  -13
    RHS1      connected_order_arc_425  -13
    RHS1      connected_order_arc_427  -13
    RHS1      connected_order_arc_429  -13
    RHS1      connected_order_arc_431  -13
    RHS1      connected_order_arc_433  -13
    RHS1      connected_order_arc_436  -13
    RHS1      connected_order_arc_438  -13
    RHS1      connected_order_arc_440  -13
    RHS1      connected_order_arc_442  -13
    RHS1      connected_order_arc_444  -13
    RHS1      connected_order_arc_446  -13
    RHS1      connected_order_arc_448  -13
    RHS1      connected_order_arc_450  -13
    RHS1      connected_order_arc_452  -13
    RHS1      connected_order_arc_454  -13
    RHS1      connected_order_arc_456  -13
    RHS1      connected_order_arc_458  -13
    RHS1      connected_order_arc_461  -13
    RHS1      connected_order_arc_463  -13
    RHS1      connected_order_arc_465  -13
    RHS1      connected_order_arc_467  -13
    RHS1      connected_order_arc_469  -13
    RHS1      connected_order_arc_471  -13
    RHS1      connected_order_arc_473  -13
    RHS1      connected_order_arc_475  -13
    RHS1      connected_order_arc_477  -13
    RHS1      connected_order_arc_479  -13
    RHS1      connected_order_arc_481  -13
    RHS1      connected_order_arc_483  -13
    RHS1      connected_order_arc_486  -13
    RHS1      connected_order_arc_488  -13
    RHS1      connected_order_arc_490  -13
    RHS1      connected_order_arc_492  -13
    RHS1      connected_order_arc_494  -13
    RHS1      connected_order_arc_496  -13
    RHS1      connected_order_arc_498  -13
    RHS1      connected_order_arc_500  -13
    RHS1      connected_order_arc_502  -13
    RHS1      connected_order_arc_504  -13
    RHS1      connected_order_arc_506  -13
    RHS1      connected_order_arc_508  -13
    RHS1      connected_order_arc_511  -13
    RHS1      connected_order_arc_513  -13
    RHS1      connected_order_arc_515  -13
    RHS1      connected_order_arc_517  -13
    RHS1      connected_order_arc_519  -13
    RHS1      connected_order_arc_521  -13
    RHS1      connected_order_arc_523  -13
    RHS1      connected_order_arc_525  -13
    RHS1      connected_order_arc_527  -13
    RHS1      connected_order_arc_529  -13
    RHS1      connected_order_arc_531  -13
    RHS1      connected_order_arc_533  -13
    RHS1      connected_order_arc_536  -13
    RHS1      connected_order_arc_538  -13
    RHS1      connected_order_arc_540  -13
    RHS1      connected_order_arc_542  -13
    RHS1      connected_order_arc_544  -13
    RHS1      connected_order_arc_546  -13
    RHS1      connected_order_arc_548  -13
    RHS1      connected_order_arc_550  -13
    RHS1      connected_order_arc_552  -13
    RHS1      connected_order_arc_554  -13
    RHS1      connected_order_arc_556  -13
    RHS1      connected_order_arc_558  -13
    RHS1      connected_order_arc_561  -13
    RHS1      connected_order_arc_563  -13
    RHS1      connected_order_arc_565  -13
    RHS1      connected_order_arc_567  -13
    RHS1      connected_order_arc_569  -13
    RHS1      connected_order_arc_571  -13
    RHS1      connected_order_arc_573  -13
    RHS1      connected_order_arc_575  -13
    RHS1      connected_order_arc_577  -13
    RHS1      connected_order_arc_579  -13
    RHS1      connected_order_arc_581  -13
    RHS1      connected_order_arc_583  -13
    RHS1      connected_order_arc_586  -13
    RHS1      connected_order_arc_588  -13
    RHS1      connected_order_arc_590  -13
    RHS1      connected_order_arc_592  -13
    RHS1      connected_order_arc_594  -13
    RHS1      connected_order_arc_596  -13
    RHS1      connected_order_arc_598  -13
    RHS1      connected_order_arc_600  -13
    RHS1      connected_order_arc_602  -13
    RHS1      connected_order_arc_604  -13
    RHS1      connected_order_arc_606  -13
    RHS1      connected_order_arc_608  -13
    RHS1      connected_order_arc_611  -13
    RHS1      connected_order_arc_613  -13
    RHS1      connected_order_arc_615  -13
    RHS1      connected_order_arc_617  -13
    RHS1      connected_order_arc_619  -13
    RHS1      connected_order_arc_621  -13
    RHS1      connected_order_arc_623  -13
    RHS1      connected_order_arc_625  -13
    RHS1      connected_order_arc_627  -13
    RHS1      connected_order_arc_629  -13
    RHS1      connected_order_arc_631  -13
    RHS1      connected_order_arc_633  -13
    RHS1      connected_order_arc_636  -13
    RHS1      connected_order_arc_638  -13
    RHS1      connected_order_arc_640  -13
    RHS1      connected_order_arc_642  -13
    RHS1      connected_order_arc_644  -13
    RHS1      connected_order_arc_646  -13
    RHS1      connected_order_arc_648  -13
    RHS1      connected_order_arc_650  -13
    RHS1      connected_order_arc_652  -13
    RHS1      connected_order_arc_654  -13
    RHS1      connected_order_arc_656  -13
    RHS1      connected_order_arc_658  -13
    RHS1      connected_order_arc_661  -13
    RHS1      connected_order_arc_663  -13
    RHS1      connected_order_arc_665  -13
    RHS1      connected_order_arc_667  -13
    RHS1      connected_order_arc_669  -13
    RHS1      connected_order_arc_671  -13
    RHS1      connected_order_arc_673  -13
    RHS1      connected_order_arc_675  -13
    RHS1      connected_order_arc_677  -13
    RHS1      connected_order_arc_679  -13
    RHS1      connected_order_arc_681  -13
    RHS1      connected_order_arc_683  -13
    RHS1      connected_order_arc_686  -13
    RHS1      connected_order_arc_688  -13
    RHS1      connected_order_arc_690  -13
    RHS1      connected_order_arc_692  -13
    RHS1      connected_order_arc_694  -13
    RHS1      connected_order_arc_696  -13
    RHS1      connected_order_arc_698  -13
    RHS1      connected_order_arc_700  -13
    RHS1      connected_order_arc_702  -13
    RHS1      connected_order_arc_704  -13
    RHS1      connected_order_arc_706  -13
    RHS1      connected_order_arc_708  -13
    RHS1      connected_order_arc_711  -13
    RHS1      connected_order_arc_713  -13
    RHS1      connected_order_arc_715  -13
    RHS1      connected_order_arc_717  -13
    RHS1      connected_order_arc_719  -13
    RHS1      connected_order_arc_721  -13
    RHS1      connected_order_arc_723  -13
    RHS1      connected_order_arc_725  -13
    RHS1      connected_order_arc_727  -13
    RHS1      connected_order_arc_729  -13
    RHS1      connected_order_arc_731  -13
    RHS1      connected_order_arc_733  -13
    RHS1      depot_departure_or_bypass_734  1
    RHS1      depot_return_or_bypass_735  1
    RHS1      segment_load_conservation_740  4
    RHS1      segment_prefix_ub_742  16
    RHS1      segment_load_conservation_747  1
    RHS1      segment_prefix_ub_749  19
    RHS1      segment_load_conservation_754  -5
    RHS1      segment_prefix_lb_755  5
    RHS1      segment_prefix_ub_756  20
    RHS1      segment_load_conservation_761  -2
    RHS1      segment_prefix_lb_762  2
    RHS1      segment_prefix_ub_763  20
    RHS1      segment_load_conservation_768  2
    RHS1      segment_prefix_ub_770  13
    RHS1      fixed_segment_relative_order_819  1
    RHS1      fixed_segment_relative_order_820  1
    RHS1      fixed_segment_relative_order_821  1
    RHS1      fixed_segment_relative_order_822  1
    RHS1      original_T_including_depot_unload_823  3.9550478046194758e+03
    RHS1      connected_order_arc_839  -12
    RHS1      connected_order_arc_841  -12
    RHS1      connected_order_arc_843  -12
    RHS1      connected_order_arc_845  -12
    RHS1      connected_order_arc_847  -12
    RHS1      connected_order_arc_849  -12
    RHS1      connected_order_arc_851  -12
    RHS1      connected_order_arc_853  -12
    RHS1      connected_order_arc_855  -12
    RHS1      connected_order_arc_857  -12
    RHS1      connected_order_arc_859  -12
    RHS1      connected_order_arc_862  -12
    RHS1      connected_order_arc_864  -12
    RHS1      connected_order_arc_866  -12
    RHS1      connected_order_arc_868  -12
    RHS1      connected_order_arc_870  -12
    RHS1      connected_order_arc_872  -12
    RHS1      connected_order_arc_874  -12
    RHS1      connected_order_arc_876  -12
    RHS1      connected_order_arc_878  -12
    RHS1      connected_order_arc_880  -12
    RHS1      connected_order_arc_882  -12
    RHS1      connected_order_arc_885  -12
    RHS1      connected_order_arc_887  -12
    RHS1      connected_order_arc_889  -12
    RHS1      connected_order_arc_891  -12
    RHS1      connected_order_arc_893  -12
    RHS1      connected_order_arc_895  -12
    RHS1      connected_order_arc_897  -12
    RHS1      connected_order_arc_899  -12
    RHS1      connected_order_arc_901  -12
    RHS1      connected_order_arc_903  -12
    RHS1      connected_order_arc_905  -12
    RHS1      connected_order_arc_908  -12
    RHS1      connected_order_arc_910  -12
    RHS1      connected_order_arc_912  -12
    RHS1      connected_order_arc_914  -12
    RHS1      connected_order_arc_916  -12
    RHS1      connected_order_arc_918  -12
    RHS1      connected_order_arc_920  -12
    RHS1      connected_order_arc_922  -12
    RHS1      connected_order_arc_924  -12
    RHS1      connected_order_arc_926  -12
    RHS1      connected_order_arc_928  -12
    RHS1      connected_order_arc_931  -12
    RHS1      connected_order_arc_933  -12
    RHS1      connected_order_arc_935  -12
    RHS1      connected_order_arc_937  -12
    RHS1      connected_order_arc_939  -12
    RHS1      connected_order_arc_941  -12
    RHS1      connected_order_arc_943  -12
    RHS1      connected_order_arc_945  -12
    RHS1      connected_order_arc_947  -12
    RHS1      connected_order_arc_949  -12
    RHS1      connected_order_arc_951  -12
    RHS1      connected_order_arc_954  -12
    RHS1      connected_order_arc_956  -12
    RHS1      connected_order_arc_958  -12
    RHS1      connected_order_arc_960  -12
    RHS1      connected_order_arc_962  -12
    RHS1      connected_order_arc_964  -12
    RHS1      connected_order_arc_966  -12
    RHS1      connected_order_arc_968  -12
    RHS1      connected_order_arc_970  -12
    RHS1      connected_order_arc_972  -12
    RHS1      connected_order_arc_974  -12
    RHS1      connected_order_arc_977  -12
    RHS1      connected_order_arc_979  -12
    RHS1      connected_order_arc_981  -12
    RHS1      connected_order_arc_983  -12
    RHS1      connected_order_arc_985  -12
    RHS1      connected_order_arc_987  -12
    RHS1      connected_order_arc_989  -12
    RHS1      connected_order_arc_991  -12
    RHS1      connected_order_arc_993  -12
    RHS1      connected_order_arc_995  -12
    RHS1      connected_order_arc_997  -12
    RHS1      connected_order_arc_1000  -12
    RHS1      connected_order_arc_1002  -12
    RHS1      connected_order_arc_1004  -12
    RHS1      connected_order_arc_1006  -12
    RHS1      connected_order_arc_1008  -12
    RHS1      connected_order_arc_1010  -12
    RHS1      connected_order_arc_1012  -12
    RHS1      connected_order_arc_1014  -12
    RHS1      connected_order_arc_1016  -12
    RHS1      connected_order_arc_1018  -12
    RHS1      connected_order_arc_1020  -12
    RHS1      connected_order_arc_1023  -12
    RHS1      connected_order_arc_1025  -12
    RHS1      connected_order_arc_1027  -12
    RHS1      connected_order_arc_1029  -12
    RHS1      connected_order_arc_1031  -12
    RHS1      connected_order_arc_1033  -12
    RHS1      connected_order_arc_1035  -12
    RHS1      connected_order_arc_1037  -12
    RHS1      connected_order_arc_1039  -12
    RHS1      connected_order_arc_1041  -12
    RHS1      connected_order_arc_1043  -12
    RHS1      connected_order_arc_1046  -12
    RHS1      connected_order_arc_1048  -12
    RHS1      connected_order_arc_1050  -12
    RHS1      connected_order_arc_1052  -12
    RHS1      connected_order_arc_1054  -12
    RHS1      connected_order_arc_1056  -12
    RHS1      connected_order_arc_1058  -12
    RHS1      connected_order_arc_1060  -12
    RHS1      connected_order_arc_1062  -12
    RHS1      connected_order_arc_1064  -12
    RHS1      connected_order_arc_1066  -12
    RHS1      connected_order_arc_1069  -12
    RHS1      connected_order_arc_1071  -12
    RHS1      connected_order_arc_1073  -12
    RHS1      connected_order_arc_1075  -12
    RHS1      connected_order_arc_1077  -12
    RHS1      connected_order_arc_1079  -12
    RHS1      connected_order_arc_1081  -12
    RHS1      connected_order_arc_1083  -12
    RHS1      connected_order_arc_1085  -12
    RHS1      connected_order_arc_1087  -12
    RHS1      connected_order_arc_1089  -12
    RHS1      connected_order_arc_1092  -12
    RHS1      connected_order_arc_1094  -12
    RHS1      connected_order_arc_1096  -12
    RHS1      connected_order_arc_1098  -12
    RHS1      connected_order_arc_1100  -12
    RHS1      connected_order_arc_1102  -12
    RHS1      connected_order_arc_1104  -12
    RHS1      connected_order_arc_1106  -12
    RHS1      connected_order_arc_1108  -12
    RHS1      connected_order_arc_1110  -12
    RHS1      connected_order_arc_1112  -12
    RHS1      depot_departure_or_bypass_1113  1
    RHS1      depot_return_or_bypass_1114  1
    RHS1      segment_load_conservation_1119  4
    RHS1      segment_prefix_ub_1121  20
    RHS1      segment_load_conservation_1126  5
    RHS1      segment_prefix_ub_1128  20
    RHS1      segment_load_conservation_1133  -4
    RHS1      segment_prefix_lb_1134  4
    RHS1      segment_prefix_ub_1135  25
    RHS1      segment_load_conservation_1140  -5
    RHS1      segment_prefix_lb_1141  5
    RHS1      segment_prefix_ub_1142  25
    RHS1      fixed_segment_relative_order_1191  1
    RHS1      fixed_segment_relative_order_1192  1
    RHS1      fixed_segment_relative_order_1193  1
    RHS1      original_T_including_depot_unload_1194  4.0180155701548429e+03
    RHS1      connected_order_arc_1209  -11
    RHS1      connected_order_arc_1211  -11
    RHS1      connected_order_arc_1213  -11
    RHS1      connected_order_arc_1215  -11
    RHS1      connected_order_arc_1217  -11
    RHS1      connected_order_arc_1219  -11
    RHS1      connected_order_arc_1221  -11
    RHS1      connected_order_arc_1223  -11
    RHS1      connected_order_arc_1225  -11
    RHS1      connected_order_arc_1227  -11
    RHS1      connected_order_arc_1230  -11
    RHS1      connected_order_arc_1232  -11
    RHS1      connected_order_arc_1234  -11
    RHS1      connected_order_arc_1236  -11
    RHS1      connected_order_arc_1238  -11
    RHS1      connected_order_arc_1240  -11
    RHS1      connected_order_arc_1242  -11
    RHS1      connected_order_arc_1244  -11
    RHS1      connected_order_arc_1246  -11
    RHS1      connected_order_arc_1248  -11
    RHS1      connected_order_arc_1251  -11
    RHS1      connected_order_arc_1253  -11
    RHS1      connected_order_arc_1255  -11
    RHS1      connected_order_arc_1257  -11
    RHS1      connected_order_arc_1259  -11
    RHS1      connected_order_arc_1261  -11
    RHS1      connected_order_arc_1263  -11
    RHS1      connected_order_arc_1265  -11
    RHS1      connected_order_arc_1267  -11
    RHS1      connected_order_arc_1269  -11
    RHS1      connected_order_arc_1272  -11
    RHS1      connected_order_arc_1274  -11
    RHS1      connected_order_arc_1276  -11
    RHS1      connected_order_arc_1278  -11
    RHS1      connected_order_arc_1280  -11
    RHS1      connected_order_arc_1282  -11
    RHS1      connected_order_arc_1284  -11
    RHS1      connected_order_arc_1286  -11
    RHS1      connected_order_arc_1288  -11
    RHS1      connected_order_arc_1290  -11
    RHS1      connected_order_arc_1293  -11
    RHS1      connected_order_arc_1295  -11
    RHS1      connected_order_arc_1297  -11
    RHS1      connected_order_arc_1299  -11
    RHS1      connected_order_arc_1301  -11
    RHS1      connected_order_arc_1303  -11
    RHS1      connected_order_arc_1305  -11
    RHS1      connected_order_arc_1307  -11
    RHS1      connected_order_arc_1309  -11
    RHS1      connected_order_arc_1311  -11
    RHS1      connected_order_arc_1314  -11
    RHS1      connected_order_arc_1316  -11
    RHS1      connected_order_arc_1318  -11
    RHS1      connected_order_arc_1320  -11
    RHS1      connected_order_arc_1322  -11
    RHS1      connected_order_arc_1324  -11
    RHS1      connected_order_arc_1326  -11
    RHS1      connected_order_arc_1328  -11
    RHS1      connected_order_arc_1330  -11
    RHS1      connected_order_arc_1332  -11
    RHS1      connected_order_arc_1335  -11
    RHS1      connected_order_arc_1337  -11
    RHS1      connected_order_arc_1339  -11
    RHS1      connected_order_arc_1341  -11
    RHS1      connected_order_arc_1343  -11
    RHS1      connected_order_arc_1345  -11
    RHS1      connected_order_arc_1347  -11
    RHS1      connected_order_arc_1349  -11
    RHS1      connected_order_arc_1351  -11
    RHS1      connected_order_arc_1353  -11
    RHS1      connected_order_arc_1356  -11
    RHS1      connected_order_arc_1358  -11
    RHS1      connected_order_arc_1360  -11
    RHS1      connected_order_arc_1362  -11
    RHS1      connected_order_arc_1364  -11
    RHS1      connected_order_arc_1366  -11
    RHS1      connected_order_arc_1368  -11
    RHS1      connected_order_arc_1370  -11
    RHS1      connected_order_arc_1372  -11
    RHS1      connected_order_arc_1374  -11
    RHS1      connected_order_arc_1377  -11
    RHS1      connected_order_arc_1379  -11
    RHS1      connected_order_arc_1381  -11
    RHS1      connected_order_arc_1383  -11
    RHS1      connected_order_arc_1385  -11
    RHS1      connected_order_arc_1387  -11
    RHS1      connected_order_arc_1389  -11
    RHS1      connected_order_arc_1391  -11
    RHS1      connected_order_arc_1393  -11
    RHS1      connected_order_arc_1395  -11
    RHS1      connected_order_arc_1398  -11
    RHS1      connected_order_arc_1400  -11
    RHS1      connected_order_arc_1402  -11
    RHS1      connected_order_arc_1404  -11
    RHS1      connected_order_arc_1406  -11
    RHS1      connected_order_arc_1408  -11
    RHS1      connected_order_arc_1410  -11
    RHS1      connected_order_arc_1412  -11
    RHS1      connected_order_arc_1414  -11
    RHS1      connected_order_arc_1416  -11
    RHS1      connected_order_arc_1419  -11
    RHS1      connected_order_arc_1421  -11
    RHS1      connected_order_arc_1423  -11
    RHS1      connected_order_arc_1425  -11
    RHS1      connected_order_arc_1427  -11
    RHS1      connected_order_arc_1429  -11
    RHS1      connected_order_arc_1431  -11
    RHS1      connected_order_arc_1433  -11
    RHS1      connected_order_arc_1435  -11
    RHS1      connected_order_arc_1437  -11
    RHS1      depot_departure_or_bypass_1438  1
    RHS1      depot_return_or_bypass_1439  1
    RHS1      segment_load_conservation_1444  2
    RHS1      segment_prefix_ub_1446  28
    RHS1      segment_load_conservation_1451  2
    RHS1      segment_prefix_ub_1453  28
    RHS1      segment_load_conservation_1458  -3
    RHS1      segment_prefix_lb_1459  4
    RHS1      segment_prefix_ub_1460  30
    RHS1      fixed_segment_relative_order_1509  1
    RHS1      fixed_segment_relative_order_1510  1
    RHS1      original_T_including_depot_unload_1511  2.8031251453030341e+03
BOUNDS
 LO BND1      t         2.5358490566012373e-02
 UP BND1      t         4.3232115285684006e-02
 UP BND1      q         4.1816696950410492e-01
 BV BND1      x_4_0   
 UP BND1      w_4_0     4.3232115285684006e-02
 BV BND1      x_4_1   
 UP BND1      w_4_1     4.3232115285684006e-02
 BV BND1      x_4_2   
 UP BND1      w_4_2     4.3232115285684006e-02
 BV BND1      x_4_3   
 UP BND1      w_4_3     4.3232115285684006e-02
 BV BND1      x_4_4   
 UP BND1      w_4_4     4.3232115285684006e-02
 BV BND1      x_4_5   
 UP BND1      w_4_5     4.3232115285684006e-02
 BV BND1      x_4_6   
 UP BND1      w_4_6     4.3232115285684006e-02
 BV BND1      x_4_7   
 UP BND1      w_4_7     4.3232115285684006e-02
 BV BND1      x_4_8   
 UP BND1      w_4_8     4.3232115285684006e-02
 BV BND1      x_4_9   
 UP BND1      w_4_9     4.3232115285684006e-02
 BV BND1      x_4_10  
 UP BND1      w_4_10    4.3232115285684006e-02
 BV BND1      x_4_11  
 UP BND1      w_4_11    4.3232115285684006e-02
 BV BND1      x_4_12  
 UP BND1      w_4_12    4.3232115285684006e-02
 BV BND1      x_4_13  
 UP BND1      w_4_13    4.3232115285684006e-02
 BV BND1      x_4_14  
 UP BND1      w_4_14    4.3232115285684006e-02
 BV BND1      x_4_15  
 UP BND1      w_4_15    4.3232115285684006e-02
 UP BND1      rho_4     1
 BV BND1      x_6_0   
 UP BND1      w_6_0     4.3232115285684006e-02
 BV BND1      x_6_1   
 UP BND1      w_6_1     4.3232115285684006e-02
 BV BND1      x_6_2   
 UP BND1      w_6_2     4.3232115285684006e-02
 BV BND1      x_6_3   
 UP BND1      w_6_3     4.3232115285684006e-02
 BV BND1      x_6_4   
 UP BND1      w_6_4     4.3232115285684006e-02
 BV BND1      x_6_5   
 UP BND1      w_6_5     4.3232115285684006e-02
 BV BND1      x_6_6   
 UP BND1      w_6_6     4.3232115285684006e-02
 BV BND1      x_6_7   
 UP BND1      w_6_7     4.3232115285684006e-02
 BV BND1      x_6_8   
 UP BND1      w_6_8     4.3232115285684006e-02
 UP BND1      rho_6     1
 BV BND1      x_34_0  
 UP BND1      w_34_0    4.3232115285684006e-02
 BV BND1      x_34_1  
 UP BND1      w_34_1    4.3232115285684006e-02
 BV BND1      x_34_2  
 UP BND1      w_34_2    4.3232115285684006e-02
 BV BND1      x_34_3  
 UP BND1      w_34_3    4.3232115285684006e-02
 BV BND1      x_34_4  
 UP BND1      w_34_4    4.3232115285684006e-02
 BV BND1      x_34_5  
 UP BND1      w_34_5    4.3232115285684006e-02
 BV BND1      x_34_6  
 UP BND1      w_34_6    4.3232115285684006e-02
 BV BND1      x_34_7  
 UP BND1      w_34_7    4.3232115285684006e-02
 BV BND1      x_34_8  
 UP BND1      w_34_8    4.3232115285684006e-02
 BV BND1      x_34_9  
 UP BND1      w_34_9    4.3232115285684006e-02
 BV BND1      x_34_10 
 UP BND1      w_34_10   4.3232115285684006e-02
 BV BND1      x_34_11 
 UP BND1      w_34_11   4.3232115285684006e-02
 BV BND1      x_34_12 
 UP BND1      w_34_12   4.3232115285684006e-02
 BV BND1      x_34_13 
 UP BND1      w_34_13   4.3232115285684006e-02
 BV BND1      x_34_14 
 UP BND1      w_34_14   4.3232115285684006e-02
 BV BND1      x_34_15 
 UP BND1      w_34_15   4.3232115285684006e-02
 UP BND1      rho_34    1
 BV BND1      x_3_0   
 UP BND1      w_3_0     4.3232115285684006e-02
 BV BND1      x_3_1   
 UP BND1      w_3_1     4.3232115285684006e-02
 BV BND1      x_3_2   
 UP BND1      w_3_2     4.3232115285684006e-02
 BV BND1      x_3_3   
 UP BND1      w_3_3     4.3232115285684006e-02
 BV BND1      x_3_4   
 UP BND1      w_3_4     4.3232115285684006e-02
 BV BND1      x_3_5   
 UP BND1      w_3_5     4.3232115285684006e-02
 BV BND1      x_3_6   
 UP BND1      w_3_6     4.3232115285684006e-02
 BV BND1      x_3_7   
 UP BND1      w_3_7     4.3232115285684006e-02
 BV BND1      x_3_8   
 UP BND1      w_3_8     4.3232115285684006e-02
 BV BND1      x_3_9   
 UP BND1      w_3_9     4.3232115285684006e-02
 BV BND1      x_3_10  
 UP BND1      w_3_10    4.3232115285684006e-02
 BV BND1      x_3_11  
 UP BND1      w_3_11    4.3232115285684006e-02
 BV BND1      x_3_12  
 UP BND1      w_3_12    4.3232115285684006e-02
 UP BND1      rho_3     1
 BV BND1      x_22_0  
 UP BND1      w_22_0    4.3232115285684006e-02
 BV BND1      x_22_1  
 UP BND1      w_22_1    4.3232115285684006e-02
 BV BND1      x_22_2  
 UP BND1      w_22_2    4.3232115285684006e-02
 BV BND1      x_22_3  
 UP BND1      w_22_3    4.3232115285684006e-02
 BV BND1      x_22_4  
 UP BND1      w_22_4    4.3232115285684006e-02
 BV BND1      x_22_5  
 UP BND1      w_22_5    4.3232115285684006e-02
 BV BND1      x_22_6  
 UP BND1      w_22_6    4.3232115285684006e-02
 BV BND1      x_22_7  
 UP BND1      w_22_7    4.3232115285684006e-02
 BV BND1      x_22_8  
 UP BND1      w_22_8    4.3232115285684006e-02
 BV BND1      x_22_9  
 UP BND1      w_22_9    4.3232115285684006e-02
 BV BND1      x_22_10 
 UP BND1      w_22_10   4.3232115285684006e-02
 BV BND1      x_22_11 
 UP BND1      w_22_11   4.3232115285684006e-02
 BV BND1      x_22_12 
 UP BND1      w_22_12   4.3232115285684006e-02
 BV BND1      x_22_13 
 UP BND1      w_22_13   4.3232115285684006e-02
 BV BND1      x_22_14 
 UP BND1      w_22_14   4.3232115285684006e-02
 BV BND1      x_22_15 
 UP BND1      w_22_15   4.3232115285684006e-02
 UP BND1      rho_22    1
 BV BND1      x_5_0   
 UP BND1      w_5_0     4.3232115285684006e-02
 BV BND1      x_5_1   
 UP BND1      w_5_1     4.3232115285684006e-02
 BV BND1      x_5_2   
 UP BND1      w_5_2     4.3232115285684006e-02
 BV BND1      x_5_3   
 UP BND1      w_5_3     4.3232115285684006e-02
 BV BND1      x_5_4   
 UP BND1      w_5_4     4.3232115285684006e-02
 BV BND1      x_5_5   
 UP BND1      w_5_5     4.3232115285684006e-02
 BV BND1      x_5_6   
 UP BND1      w_5_6     4.3232115285684006e-02
 BV BND1      x_5_7   
 UP BND1      w_5_7     4.3232115285684006e-02
 BV BND1      x_5_8   
 UP BND1      w_5_8     4.3232115285684006e-02
 BV BND1      x_5_9   
 UP BND1      w_5_9     4.3232115285684006e-02
 BV BND1      x_5_10  
 UP BND1      w_5_10    4.3232115285684006e-02
 BV BND1      x_5_11  
 UP BND1      w_5_11    4.3232115285684006e-02
 BV BND1      x_5_12  
 UP BND1      w_5_12    4.3232115285684006e-02
 BV BND1      x_5_13  
 UP BND1      w_5_13    4.3232115285684006e-02
 BV BND1      x_5_14  
 UP BND1      w_5_14    4.3232115285684006e-02
 BV BND1      x_5_15  
 UP BND1      w_5_15    4.3232115285684006e-02
 UP BND1      rho_5     1
 BV BND1      x_27_0  
 UP BND1      w_27_0    4.3232115285684006e-02
 BV BND1      x_27_1  
 UP BND1      w_27_1    4.3232115285684006e-02
 BV BND1      x_27_2  
 UP BND1      w_27_2    4.3232115285684006e-02
 BV BND1      x_27_3  
 UP BND1      w_27_3    4.3232115285684006e-02
 BV BND1      x_27_4  
 UP BND1      w_27_4    4.3232115285684006e-02
 BV BND1      x_27_5  
 UP BND1      w_27_5    4.3232115285684006e-02
 BV BND1      x_27_6  
 UP BND1      w_27_6    4.3232115285684006e-02
 UP BND1      rho_27    1
 BV BND1      x_8_0   
 UP BND1      w_8_0     4.3232115285684006e-02
 BV BND1      x_8_1   
 UP BND1      w_8_1     4.3232115285684006e-02
 BV BND1      x_8_2   
 UP BND1      w_8_2     4.3232115285684006e-02
 BV BND1      x_8_3   
 UP BND1      w_8_3     4.3232115285684006e-02
 BV BND1      x_8_4   
 UP BND1      w_8_4     4.3232115285684006e-02
 BV BND1      x_8_5   
 UP BND1      w_8_5     4.3232115285684006e-02
 BV BND1      x_8_6   
 UP BND1      w_8_6     4.3232115285684006e-02
 BV BND1      x_8_7   
 UP BND1      w_8_7     4.3232115285684006e-02
 BV BND1      x_8_8   
 UP BND1      w_8_8     4.3232115285684006e-02
 BV BND1      x_8_9   
 UP BND1      w_8_9     4.3232115285684006e-02
 BV BND1      x_8_10  
 UP BND1      w_8_10    4.3232115285684006e-02
 BV BND1      x_8_11  
 UP BND1      w_8_11    4.3232115285684006e-02
 BV BND1      x_8_12  
 UP BND1      w_8_12    4.3232115285684006e-02
 UP BND1      rho_8     1
 UP BND1      a_4_6     1
 UP BND1      a_4_34    1
 UP BND1      a_4_3     1
 UP BND1      a_4_22    1
 UP BND1      a_4_5     1
 UP BND1      a_4_27    1
 UP BND1      a_4_8     1
 UP BND1      a_6_34    1
 UP BND1      a_6_3     1
 UP BND1      a_6_22    1
 UP BND1      a_6_5     1
 UP BND1      a_6_27    1
 UP BND1      a_6_8     1
 UP BND1      a_34_3    1
 UP BND1      a_34_22   1
 UP BND1      a_34_5    1
 UP BND1      a_34_27   1
 UP BND1      a_34_8    1
 UP BND1      a_3_22    1
 UP BND1      a_3_5     1
 UP BND1      a_3_27    1
 UP BND1      a_3_8     1
 UP BND1      a_22_5    1
 UP BND1      a_22_27   1
 UP BND1      a_22_8    1
 UP BND1      a_5_27    1
 UP BND1      a_5_8     1
 UP BND1      a_27_8    1
 BV BND1      service_0_4_0
 BV BND1      service_0_4_1
 BV BND1      service_0_4_3
 BV BND1      service_0_4_4
 BV BND1      service_0_4_5
 BV BND1      service_0_4_6
 BV BND1      service_0_4_7
 BV BND1      service_0_4_8
 BV BND1      service_0_4_9
 BV BND1      service_0_4_10
 BV BND1      service_0_4_11
 BV BND1      service_0_4_12
 BV BND1      service_0_4_13
 BV BND1      service_0_4_14
 BV BND1      service_0_4_15
 BV BND1      service_1_4_0
 BV BND1      service_1_4_1
 BV BND1      service_1_4_3
 BV BND1      service_1_4_4
 BV BND1      service_1_4_5
 BV BND1      service_1_4_6
 BV BND1      service_1_4_7
 BV BND1      service_1_4_8
 BV BND1      service_1_4_9
 BV BND1      service_1_4_10
 BV BND1      service_1_4_11
 BV BND1      service_1_4_12
 BV BND1      service_1_4_13
 BV BND1      service_1_4_14
 BV BND1      service_1_4_15
 BV BND1      service_2_4_0
 BV BND1      service_2_4_1
 BV BND1      service_2_4_3
 BV BND1      service_2_4_4
 BV BND1      service_2_4_5
 BV BND1      service_2_4_6
 BV BND1      service_2_4_7
 BV BND1      service_2_4_8
 BV BND1      service_2_4_9
 BV BND1      service_2_4_10
 BV BND1      service_2_4_11
 BV BND1      service_2_4_12
 BV BND1      service_2_4_13
 BV BND1      service_2_4_14
 BV BND1      service_2_4_15
 BV BND1      service_0_6_0
 BV BND1      service_0_6_1
 BV BND1      service_0_6_2
 BV BND1      service_0_6_3
 BV BND1      service_0_6_4
 BV BND1      service_0_6_5
 BV BND1      service_0_6_7
 BV BND1      service_0_6_8
 BV BND1      service_1_6_0
 BV BND1      service_1_6_1
 BV BND1      service_1_6_2
 BV BND1      service_1_6_3
 BV BND1      service_1_6_4
 BV BND1      service_1_6_5
 BV BND1      service_1_6_7
 BV BND1      service_1_6_8
 BV BND1      service_2_6_0
 BV BND1      service_2_6_1
 BV BND1      service_2_6_2
 BV BND1      service_2_6_3
 BV BND1      service_2_6_4
 BV BND1      service_2_6_5
 BV BND1      service_2_6_7
 BV BND1      service_2_6_8
 BV BND1      service_0_34_0
 BV BND1      service_0_34_1
 BV BND1      service_0_34_3
 BV BND1      service_0_34_4
 BV BND1      service_0_34_5
 BV BND1      service_0_34_6
 BV BND1      service_0_34_7
 BV BND1      service_0_34_8
 BV BND1      service_0_34_9
 BV BND1      service_0_34_10
 BV BND1      service_0_34_11
 BV BND1      service_0_34_12
 BV BND1      service_0_34_13
 BV BND1      service_0_34_14
 BV BND1      service_0_34_15
 BV BND1      service_1_34_0
 BV BND1      service_1_34_1
 BV BND1      service_1_34_3
 BV BND1      service_1_34_4
 BV BND1      service_1_34_5
 BV BND1      service_1_34_6
 BV BND1      service_1_34_7
 BV BND1      service_1_34_8
 BV BND1      service_1_34_9
 BV BND1      service_1_34_10
 BV BND1      service_1_34_11
 BV BND1      service_1_34_12
 BV BND1      service_1_34_13
 BV BND1      service_1_34_14
 BV BND1      service_1_34_15
 BV BND1      service_2_34_0
 BV BND1      service_2_34_1
 BV BND1      service_2_34_3
 BV BND1      service_2_34_4
 BV BND1      service_2_34_5
 BV BND1      service_2_34_6
 BV BND1      service_2_34_7
 BV BND1      service_2_34_8
 BV BND1      service_2_34_9
 BV BND1      service_2_34_10
 BV BND1      service_2_34_11
 BV BND1      service_2_34_12
 BV BND1      service_2_34_13
 BV BND1      service_2_34_14
 BV BND1      service_2_34_15
 BV BND1      service_0_3_0
 BV BND1      service_0_3_1
 BV BND1      service_0_3_2
 BV BND1      service_0_3_3
 BV BND1      service_0_3_4
 BV BND1      service_0_3_5
 BV BND1      service_0_3_6
 BV BND1      service_0_3_7
 BV BND1      service_0_3_8
 BV BND1      service_0_3_10
 BV BND1      service_0_3_11
 BV BND1      service_0_3_12
 BV BND1      service_1_3_0
 BV BND1      service_1_3_1
 BV BND1      service_1_3_2
 BV BND1      service_1_3_3
 BV BND1      service_1_3_4
 BV BND1      service_1_3_5
 BV BND1      service_1_3_6
 BV BND1      service_1_3_7
 BV BND1      service_1_3_8
 BV BND1      service_1_3_10
 BV BND1      service_1_3_11
 BV BND1      service_1_3_12
 BV BND1      service_2_3_0
 BV BND1      service_2_3_1
 BV BND1      service_2_3_2
 BV BND1      service_2_3_3
 BV BND1      service_2_3_4
 BV BND1      service_2_3_5
 BV BND1      service_2_3_6
 BV BND1      service_2_3_7
 BV BND1      service_2_3_8
 BV BND1      service_2_3_10
 BV BND1      service_2_3_11
 BV BND1      service_2_3_12
 BV BND1      service_0_22_0
 BV BND1      service_0_22_1
 BV BND1      service_0_22_3
 BV BND1      service_0_22_4
 BV BND1      service_0_22_5
 BV BND1      service_0_22_6
 BV BND1      service_0_22_7
 BV BND1      service_0_22_8
 BV BND1      service_0_22_9
 BV BND1      service_0_22_10
 BV BND1      service_0_22_11
 BV BND1      service_0_22_12
 BV BND1      service_0_22_13
 BV BND1      service_0_22_14
 BV BND1      service_0_22_15
 BV BND1      service_1_22_0
 BV BND1      service_1_22_1
 BV BND1      service_1_22_3
 BV BND1      service_1_22_4
 BV BND1      service_1_22_5
 BV BND1      service_1_22_6
 BV BND1      service_1_22_7
 BV BND1      service_1_22_8
 BV BND1      service_1_22_9
 BV BND1      service_1_22_10
 BV BND1      service_1_22_11
 BV BND1      service_1_22_12
 BV BND1      service_1_22_13
 BV BND1      service_1_22_14
 BV BND1      service_1_22_15
 BV BND1      service_2_22_0
 BV BND1      service_2_22_1
 BV BND1      service_2_22_3
 BV BND1      service_2_22_4
 BV BND1      service_2_22_5
 BV BND1      service_2_22_6
 BV BND1      service_2_22_7
 BV BND1      service_2_22_8
 BV BND1      service_2_22_9
 BV BND1      service_2_22_10
 BV BND1      service_2_22_11
 BV BND1      service_2_22_12
 BV BND1      service_2_22_13
 BV BND1      service_2_22_14
 BV BND1      service_2_22_15
 BV BND1      service_0_5_0
 BV BND1      service_0_5_2
 BV BND1      service_0_5_3
 BV BND1      service_0_5_4
 BV BND1      service_0_5_5
 BV BND1      service_0_5_6
 BV BND1      service_0_5_7
 BV BND1      service_0_5_8
 BV BND1      service_0_5_9
 BV BND1      service_0_5_10
 BV BND1      service_0_5_11
 BV BND1      service_0_5_12
 BV BND1      service_0_5_13
 BV BND1      service_0_5_14
 BV BND1      service_0_5_15
 BV BND1      service_1_5_0
 BV BND1      service_1_5_2
 BV BND1      service_1_5_3
 BV BND1      service_1_5_4
 BV BND1      service_1_5_5
 BV BND1      service_1_5_6
 BV BND1      service_1_5_7
 BV BND1      service_1_5_8
 BV BND1      service_1_5_9
 BV BND1      service_1_5_10
 BV BND1      service_1_5_11
 BV BND1      service_1_5_12
 BV BND1      service_1_5_13
 BV BND1      service_1_5_14
 BV BND1      service_1_5_15
 BV BND1      service_2_5_0
 BV BND1      service_2_5_2
 BV BND1      service_2_5_3
 BV BND1      service_2_5_4
 BV BND1      service_2_5_5
 BV BND1      service_2_5_6
 BV BND1      service_2_5_7
 BV BND1      service_2_5_8
 BV BND1      service_2_5_9
 BV BND1      service_2_5_10
 BV BND1      service_2_5_11
 BV BND1      service_2_5_12
 BV BND1      service_2_5_13
 BV BND1      service_2_5_14
 BV BND1      service_2_5_15
 BV BND1      service_0_27_1
 BV BND1      service_0_27_2
 BV BND1      service_0_27_3
 BV BND1      service_0_27_4
 BV BND1      service_0_27_5
 BV BND1      service_0_27_6
 BV BND1      service_1_27_1
 BV BND1      service_1_27_2
 BV BND1      service_1_27_3
 BV BND1      service_1_27_4
 BV BND1      service_1_27_5
 BV BND1      service_1_27_6
 BV BND1      service_2_27_1
 BV BND1      service_2_27_2
 BV BND1      service_2_27_3
 BV BND1      service_2_27_4
 BV BND1      service_2_27_5
 BV BND1      service_2_27_6
 BV BND1      service_0_8_0
 BV BND1      service_0_8_1
 BV BND1      service_0_8_2
 BV BND1      service_0_8_3
 BV BND1      service_0_8_4
 BV BND1      service_0_8_5
 BV BND1      service_0_8_6
 BV BND1      service_0_8_7
 BV BND1      service_0_8_8
 BV BND1      service_0_8_10
 BV BND1      service_0_8_11
 BV BND1      service_0_8_12
 BV BND1      service_1_8_0
 BV BND1      service_1_8_1
 BV BND1      service_1_8_2
 BV BND1      service_1_8_3
 BV BND1      service_1_8_4
 BV BND1      service_1_8_5
 BV BND1      service_1_8_6
 BV BND1      service_1_8_7
 BV BND1      service_1_8_8
 BV BND1      service_1_8_10
 BV BND1      service_1_8_11
 BV BND1      service_1_8_12
 BV BND1      service_2_8_0
 BV BND1      service_2_8_1
 BV BND1      service_2_8_2
 BV BND1      service_2_8_3
 BV BND1      service_2_8_4
 BV BND1      service_2_8_5
 BV BND1      service_2_8_6
 BV BND1      service_2_8_7
 BV BND1      service_2_8_8
 BV BND1      service_2_8_10
 BV BND1      service_2_8_11
 BV BND1      service_2_8_12
 FX BND1      visit_0_1  1
 UP BND1      order_0_1  13
 FX BND1      visit_0_2  1
 UP BND1      order_0_2  13
 FX BND1      visit_0_3  1
 UP BND1      order_0_3  13
 FX BND1      visit_0_4  1
 UP BND1      order_0_4  13
 FX BND1      visit_0_5  1
 UP BND1      order_0_5  13
 UP BND1      visit_0_13  1
 UP BND1      order_0_13  13
 UP BND1      visit_0_14  1
 UP BND1      order_0_14  13
 UP BND1      visit_0_15  1
 UP BND1      order_0_15  13
 UP BND1      visit_0_16  1
 UP BND1      order_0_16  13
 UP BND1      visit_0_17  1
 UP BND1      order_0_17  13
 UP BND1      visit_0_18  1
 UP BND1      order_0_18  13
 UP BND1      visit_0_19  1
 UP BND1      order_0_19  13
 UP BND1      visit_0_20  1
 UP BND1      order_0_20  13
 BV BND1      arc_0_0_0
 FX BND1      load_0_0_0  0
 BV BND1      arc_0_0_1
 FX BND1      load_0_0_1  0
 BV BND1      arc_0_0_2
 FX BND1      load_0_0_2  0
 BV BND1      arc_0_0_3
 FX BND1      load_0_0_3  0
 BV BND1      arc_0_0_4
 FX BND1      load_0_0_4  0
 BV BND1      arc_0_0_5
 FX BND1      load_0_0_5  0
 BV BND1      arc_0_0_13
 FX BND1      load_0_0_13  0
 BV BND1      arc_0_0_14
 FX BND1      load_0_0_14  0
 BV BND1      arc_0_0_15
 FX BND1      load_0_0_15  0
 BV BND1      arc_0_0_16
 FX BND1      load_0_0_16  0
 BV BND1      arc_0_0_17
 FX BND1      load_0_0_17  0
 BV BND1      arc_0_0_18
 FX BND1      load_0_0_18  0
 BV BND1      arc_0_0_19
 FX BND1      load_0_0_19  0
 BV BND1      arc_0_0_20
 FX BND1      load_0_0_20  0
 BV BND1      arc_0_1_0
 UP BND1      load_0_1_0  20
 BV BND1      arc_0_1_2
 UP BND1      load_0_1_2  20
 BV BND1      arc_0_1_3
 UP BND1      load_0_1_3  20
 BV BND1      arc_0_1_4
 UP BND1      load_0_1_4  20
 BV BND1      arc_0_1_5
 UP BND1      load_0_1_5  20
 BV BND1      arc_0_1_13
 UP BND1      load_0_1_13  20
 BV BND1      arc_0_1_14
 UP BND1      load_0_1_14  20
 BV BND1      arc_0_1_15
 UP BND1      load_0_1_15  20
 BV BND1      arc_0_1_16
 UP BND1      load_0_1_16  20
 BV BND1      arc_0_1_17
 UP BND1      load_0_1_17  20
 BV BND1      arc_0_1_18
 UP BND1      load_0_1_18  20
 BV BND1      arc_0_1_19
 UP BND1      load_0_1_19  20
 BV BND1      arc_0_1_20
 UP BND1      load_0_1_20  20
 BV BND1      arc_0_2_0
 UP BND1      load_0_2_0  20
 BV BND1      arc_0_2_1
 UP BND1      load_0_2_1  20
 BV BND1      arc_0_2_3
 UP BND1      load_0_2_3  20
 BV BND1      arc_0_2_4
 UP BND1      load_0_2_4  20
 BV BND1      arc_0_2_5
 UP BND1      load_0_2_5  20
 BV BND1      arc_0_2_13
 UP BND1      load_0_2_13  20
 BV BND1      arc_0_2_14
 UP BND1      load_0_2_14  20
 BV BND1      arc_0_2_15
 UP BND1      load_0_2_15  20
 BV BND1      arc_0_2_16
 UP BND1      load_0_2_16  20
 BV BND1      arc_0_2_17
 UP BND1      load_0_2_17  20
 BV BND1      arc_0_2_18
 UP BND1      load_0_2_18  20
 BV BND1      arc_0_2_19
 UP BND1      load_0_2_19  20
 BV BND1      arc_0_2_20
 UP BND1      load_0_2_20  20
 BV BND1      arc_0_3_0
 UP BND1      load_0_3_0  20
 BV BND1      arc_0_3_1
 UP BND1      load_0_3_1  20
 BV BND1      arc_0_3_2
 UP BND1      load_0_3_2  20
 BV BND1      arc_0_3_4
 UP BND1      load_0_3_4  20
 BV BND1      arc_0_3_5
 UP BND1      load_0_3_5  20
 BV BND1      arc_0_3_13
 UP BND1      load_0_3_13  20
 BV BND1      arc_0_3_14
 UP BND1      load_0_3_14  20
 BV BND1      arc_0_3_15
 UP BND1      load_0_3_15  20
 BV BND1      arc_0_3_16
 UP BND1      load_0_3_16  20
 BV BND1      arc_0_3_17
 UP BND1      load_0_3_17  20
 BV BND1      arc_0_3_18
 UP BND1      load_0_3_18  20
 BV BND1      arc_0_3_19
 UP BND1      load_0_3_19  20
 BV BND1      arc_0_3_20
 UP BND1      load_0_3_20  20
 BV BND1      arc_0_4_0
 UP BND1      load_0_4_0  20
 BV BND1      arc_0_4_1
 UP BND1      load_0_4_1  20
 BV BND1      arc_0_4_2
 UP BND1      load_0_4_2  20
 BV BND1      arc_0_4_3
 UP BND1      load_0_4_3  20
 BV BND1      arc_0_4_5
 UP BND1      load_0_4_5  20
 BV BND1      arc_0_4_13
 UP BND1      load_0_4_13  20
 BV BND1      arc_0_4_14
 UP BND1      load_0_4_14  20
 BV BND1      arc_0_4_15
 UP BND1      load_0_4_15  20
 BV BND1      arc_0_4_16
 UP BND1      load_0_4_16  20
 BV BND1      arc_0_4_17
 UP BND1      load_0_4_17  20
 BV BND1      arc_0_4_18
 UP BND1      load_0_4_18  20
 BV BND1      arc_0_4_19
 UP BND1      load_0_4_19  20
 BV BND1      arc_0_4_20
 UP BND1      load_0_4_20  20
 BV BND1      arc_0_5_0
 UP BND1      load_0_5_0  20
 BV BND1      arc_0_5_1
 UP BND1      load_0_5_1  20
 BV BND1      arc_0_5_2
 UP BND1      load_0_5_2  20
 BV BND1      arc_0_5_3
 UP BND1      load_0_5_3  20
 BV BND1      arc_0_5_4
 UP BND1      load_0_5_4  20
 BV BND1      arc_0_5_13
 UP BND1      load_0_5_13  20
 BV BND1      arc_0_5_14
 UP BND1      load_0_5_14  20
 BV BND1      arc_0_5_15
 UP BND1      load_0_5_15  20
 BV BND1      arc_0_5_16
 UP BND1      load_0_5_16  20
 BV BND1      arc_0_5_17
 UP BND1      load_0_5_17  20
 BV BND1      arc_0_5_18
 UP BND1      load_0_5_18  20
 BV BND1      arc_0_5_19
 UP BND1      load_0_5_19  20
 BV BND1      arc_0_5_20
 UP BND1      load_0_5_20  20
 BV BND1      arc_0_13_0
 UP BND1      load_0_13_0  20
 BV BND1      arc_0_13_1
 UP BND1      load_0_13_1  20
 BV BND1      arc_0_13_2
 UP BND1      load_0_13_2  20
 BV BND1      arc_0_13_3
 UP BND1      load_0_13_3  20
 BV BND1      arc_0_13_4
 UP BND1      load_0_13_4  20
 BV BND1      arc_0_13_5
 UP BND1      load_0_13_5  20
 BV BND1      arc_0_13_14
 UP BND1      load_0_13_14  20
 BV BND1      arc_0_13_15
 UP BND1      load_0_13_15  20
 BV BND1      arc_0_13_16
 UP BND1      load_0_13_16  20
 BV BND1      arc_0_13_17
 UP BND1      load_0_13_17  20
 BV BND1      arc_0_13_18
 UP BND1      load_0_13_18  20
 BV BND1      arc_0_13_19
 UP BND1      load_0_13_19  20
 BV BND1      arc_0_13_20
 UP BND1      load_0_13_20  20
 BV BND1      arc_0_14_0
 UP BND1      load_0_14_0  20
 BV BND1      arc_0_14_1
 UP BND1      load_0_14_1  20
 BV BND1      arc_0_14_2
 UP BND1      load_0_14_2  20
 BV BND1      arc_0_14_3
 UP BND1      load_0_14_3  20
 BV BND1      arc_0_14_4
 UP BND1      load_0_14_4  20
 BV BND1      arc_0_14_5
 UP BND1      load_0_14_5  20
 BV BND1      arc_0_14_13
 UP BND1      load_0_14_13  20
 BV BND1      arc_0_14_15
 UP BND1      load_0_14_15  20
 BV BND1      arc_0_14_16
 UP BND1      load_0_14_16  20
 BV BND1      arc_0_14_17
 UP BND1      load_0_14_17  20
 BV BND1      arc_0_14_18
 UP BND1      load_0_14_18  20
 BV BND1      arc_0_14_19
 UP BND1      load_0_14_19  20
 BV BND1      arc_0_14_20
 UP BND1      load_0_14_20  20
 BV BND1      arc_0_15_0
 UP BND1      load_0_15_0  20
 BV BND1      arc_0_15_1
 UP BND1      load_0_15_1  20
 BV BND1      arc_0_15_2
 UP BND1      load_0_15_2  20
 BV BND1      arc_0_15_3
 UP BND1      load_0_15_3  20
 BV BND1      arc_0_15_4
 UP BND1      load_0_15_4  20
 BV BND1      arc_0_15_5
 UP BND1      load_0_15_5  20
 BV BND1      arc_0_15_13
 UP BND1      load_0_15_13  20
 BV BND1      arc_0_15_14
 UP BND1      load_0_15_14  20
 BV BND1      arc_0_15_16
 UP BND1      load_0_15_16  20
 BV BND1      arc_0_15_17
 UP BND1      load_0_15_17  20
 BV BND1      arc_0_15_18
 UP BND1      load_0_15_18  20
 BV BND1      arc_0_15_19
 UP BND1      load_0_15_19  20
 BV BND1      arc_0_15_20
 UP BND1      load_0_15_20  20
 BV BND1      arc_0_16_0
 UP BND1      load_0_16_0  20
 BV BND1      arc_0_16_1
 UP BND1      load_0_16_1  20
 BV BND1      arc_0_16_2
 UP BND1      load_0_16_2  20
 BV BND1      arc_0_16_3
 UP BND1      load_0_16_3  20
 BV BND1      arc_0_16_4
 UP BND1      load_0_16_4  20
 BV BND1      arc_0_16_5
 UP BND1      load_0_16_5  20
 BV BND1      arc_0_16_13
 UP BND1      load_0_16_13  20
 BV BND1      arc_0_16_14
 UP BND1      load_0_16_14  20
 BV BND1      arc_0_16_15
 UP BND1      load_0_16_15  20
 BV BND1      arc_0_16_17
 UP BND1      load_0_16_17  20
 BV BND1      arc_0_16_18
 UP BND1      load_0_16_18  20
 BV BND1      arc_0_16_19
 UP BND1      load_0_16_19  20
 BV BND1      arc_0_16_20
 UP BND1      load_0_16_20  20
 BV BND1      arc_0_17_0
 UP BND1      load_0_17_0  20
 BV BND1      arc_0_17_1
 UP BND1      load_0_17_1  20
 BV BND1      arc_0_17_2
 UP BND1      load_0_17_2  20
 BV BND1      arc_0_17_3
 UP BND1      load_0_17_3  20
 BV BND1      arc_0_17_4
 UP BND1      load_0_17_4  20
 BV BND1      arc_0_17_5
 UP BND1      load_0_17_5  20
 BV BND1      arc_0_17_13
 UP BND1      load_0_17_13  20
 BV BND1      arc_0_17_14
 UP BND1      load_0_17_14  20
 BV BND1      arc_0_17_15
 UP BND1      load_0_17_15  20
 BV BND1      arc_0_17_16
 UP BND1      load_0_17_16  20
 BV BND1      arc_0_17_18
 UP BND1      load_0_17_18  20
 BV BND1      arc_0_17_19
 UP BND1      load_0_17_19  20
 BV BND1      arc_0_17_20
 UP BND1      load_0_17_20  20
 BV BND1      arc_0_18_0
 UP BND1      load_0_18_0  20
 BV BND1      arc_0_18_1
 UP BND1      load_0_18_1  20
 BV BND1      arc_0_18_2
 UP BND1      load_0_18_2  20
 BV BND1      arc_0_18_3
 UP BND1      load_0_18_3  20
 BV BND1      arc_0_18_4
 UP BND1      load_0_18_4  20
 BV BND1      arc_0_18_5
 UP BND1      load_0_18_5  20
 BV BND1      arc_0_18_13
 UP BND1      load_0_18_13  20
 BV BND1      arc_0_18_14
 UP BND1      load_0_18_14  20
 BV BND1      arc_0_18_15
 UP BND1      load_0_18_15  20
 BV BND1      arc_0_18_16
 UP BND1      load_0_18_16  20
 BV BND1      arc_0_18_17
 UP BND1      load_0_18_17  20
 BV BND1      arc_0_18_19
 UP BND1      load_0_18_19  20
 BV BND1      arc_0_18_20
 UP BND1      load_0_18_20  20
 BV BND1      arc_0_19_0
 UP BND1      load_0_19_0  20
 BV BND1      arc_0_19_1
 UP BND1      load_0_19_1  20
 BV BND1      arc_0_19_2
 UP BND1      load_0_19_2  20
 BV BND1      arc_0_19_3
 UP BND1      load_0_19_3  20
 BV BND1      arc_0_19_4
 UP BND1      load_0_19_4  20
 BV BND1      arc_0_19_5
 UP BND1      load_0_19_5  20
 BV BND1      arc_0_19_13
 UP BND1      load_0_19_13  20
 BV BND1      arc_0_19_14
 UP BND1      load_0_19_14  20
 BV BND1      arc_0_19_15
 UP BND1      load_0_19_15  20
 BV BND1      arc_0_19_16
 UP BND1      load_0_19_16  20
 BV BND1      arc_0_19_17
 UP BND1      load_0_19_17  20
 BV BND1      arc_0_19_18
 UP BND1      load_0_19_18  20
 BV BND1      arc_0_19_20
 UP BND1      load_0_19_20  20
 BV BND1      arc_0_20_0
 UP BND1      load_0_20_0  20
 BV BND1      arc_0_20_1
 UP BND1      load_0_20_1  20
 BV BND1      arc_0_20_2
 UP BND1      load_0_20_2  20
 BV BND1      arc_0_20_3
 UP BND1      load_0_20_3  20
 BV BND1      arc_0_20_4
 UP BND1      load_0_20_4  20
 BV BND1      arc_0_20_5
 UP BND1      load_0_20_5  20
 BV BND1      arc_0_20_13
 UP BND1      load_0_20_13  20
 BV BND1      arc_0_20_14
 UP BND1      load_0_20_14  20
 BV BND1      arc_0_20_15
 UP BND1      load_0_20_15  20
 BV BND1      arc_0_20_16
 UP BND1      load_0_20_16  20
 BV BND1      arc_0_20_17
 UP BND1      load_0_20_17  20
 BV BND1      arc_0_20_18
 UP BND1      load_0_20_18  20
 BV BND1      arc_0_20_19
 UP BND1      load_0_20_19  20
 FX BND1      visit_1_6  1
 UP BND1      order_1_6  12
 FX BND1      visit_1_7  1
 UP BND1      order_1_7  12
 FX BND1      visit_1_8  1
 UP BND1      order_1_8  12
 FX BND1      visit_1_9  1
 UP BND1      order_1_9  12
 UP BND1      visit_1_13  1
 UP BND1      order_1_13  12
 UP BND1      visit_1_14  1
 UP BND1      order_1_14  12
 UP BND1      visit_1_15  1
 UP BND1      order_1_15  12
 UP BND1      visit_1_16  1
 UP BND1      order_1_16  12
 UP BND1      visit_1_17  1
 UP BND1      order_1_17  12
 UP BND1      visit_1_18  1
 UP BND1      order_1_18  12
 UP BND1      visit_1_19  1
 UP BND1      order_1_19  12
 UP BND1      visit_1_20  1
 UP BND1      order_1_20  12
 BV BND1      arc_1_0_0
 FX BND1      load_1_0_0  0
 BV BND1      arc_1_0_6
 FX BND1      load_1_0_6  0
 BV BND1      arc_1_0_7
 FX BND1      load_1_0_7  0
 BV BND1      arc_1_0_8
 FX BND1      load_1_0_8  0
 BV BND1      arc_1_0_9
 FX BND1      load_1_0_9  0
 BV BND1      arc_1_0_13
 FX BND1      load_1_0_13  0
 BV BND1      arc_1_0_14
 FX BND1      load_1_0_14  0
 BV BND1      arc_1_0_15
 FX BND1      load_1_0_15  0
 BV BND1      arc_1_0_16
 FX BND1      load_1_0_16  0
 BV BND1      arc_1_0_17
 FX BND1      load_1_0_17  0
 BV BND1      arc_1_0_18
 FX BND1      load_1_0_18  0
 BV BND1      arc_1_0_19
 FX BND1      load_1_0_19  0
 BV BND1      arc_1_0_20
 FX BND1      load_1_0_20  0
 BV BND1      arc_1_6_0
 UP BND1      load_1_6_0  25
 BV BND1      arc_1_6_7
 UP BND1      load_1_6_7  25
 BV BND1      arc_1_6_8
 UP BND1      load_1_6_8  25
 BV BND1      arc_1_6_9
 UP BND1      load_1_6_9  25
 BV BND1      arc_1_6_13
 UP BND1      load_1_6_13  25
 BV BND1      arc_1_6_14
 UP BND1      load_1_6_14  25
 BV BND1      arc_1_6_15
 UP BND1      load_1_6_15  25
 BV BND1      arc_1_6_16
 UP BND1      load_1_6_16  25
 BV BND1      arc_1_6_17
 UP BND1      load_1_6_17  25
 BV BND1      arc_1_6_18
 UP BND1      load_1_6_18  25
 BV BND1      arc_1_6_19
 UP BND1      load_1_6_19  25
 BV BND1      arc_1_6_20
 UP BND1      load_1_6_20  25
 BV BND1      arc_1_7_0
 UP BND1      load_1_7_0  25
 BV BND1      arc_1_7_6
 UP BND1      load_1_7_6  25
 BV BND1      arc_1_7_8
 UP BND1      load_1_7_8  25
 BV BND1      arc_1_7_9
 UP BND1      load_1_7_9  25
 BV BND1      arc_1_7_13
 UP BND1      load_1_7_13  25
 BV BND1      arc_1_7_14
 UP BND1      load_1_7_14  25
 BV BND1      arc_1_7_15
 UP BND1      load_1_7_15  25
 BV BND1      arc_1_7_16
 UP BND1      load_1_7_16  25
 BV BND1      arc_1_7_17
 UP BND1      load_1_7_17  25
 BV BND1      arc_1_7_18
 UP BND1      load_1_7_18  25
 BV BND1      arc_1_7_19
 UP BND1      load_1_7_19  25
 BV BND1      arc_1_7_20
 UP BND1      load_1_7_20  25
 BV BND1      arc_1_8_0
 UP BND1      load_1_8_0  25
 BV BND1      arc_1_8_6
 UP BND1      load_1_8_6  25
 BV BND1      arc_1_8_7
 UP BND1      load_1_8_7  25
 BV BND1      arc_1_8_9
 UP BND1      load_1_8_9  25
 BV BND1      arc_1_8_13
 UP BND1      load_1_8_13  25
 BV BND1      arc_1_8_14
 UP BND1      load_1_8_14  25
 BV BND1      arc_1_8_15
 UP BND1      load_1_8_15  25
 BV BND1      arc_1_8_16
 UP BND1      load_1_8_16  25
 BV BND1      arc_1_8_17
 UP BND1      load_1_8_17  25
 BV BND1      arc_1_8_18
 UP BND1      load_1_8_18  25
 BV BND1      arc_1_8_19
 UP BND1      load_1_8_19  25
 BV BND1      arc_1_8_20
 UP BND1      load_1_8_20  25
 BV BND1      arc_1_9_0
 UP BND1      load_1_9_0  25
 BV BND1      arc_1_9_6
 UP BND1      load_1_9_6  25
 BV BND1      arc_1_9_7
 UP BND1      load_1_9_7  25
 BV BND1      arc_1_9_8
 UP BND1      load_1_9_8  25
 BV BND1      arc_1_9_13
 UP BND1      load_1_9_13  25
 BV BND1      arc_1_9_14
 UP BND1      load_1_9_14  25
 BV BND1      arc_1_9_15
 UP BND1      load_1_9_15  25
 BV BND1      arc_1_9_16
 UP BND1      load_1_9_16  25
 BV BND1      arc_1_9_17
 UP BND1      load_1_9_17  25
 BV BND1      arc_1_9_18
 UP BND1      load_1_9_18  25
 BV BND1      arc_1_9_19
 UP BND1      load_1_9_19  25
 BV BND1      arc_1_9_20
 UP BND1      load_1_9_20  25
 BV BND1      arc_1_13_0
 UP BND1      load_1_13_0  25
 BV BND1      arc_1_13_6
 UP BND1      load_1_13_6  25
 BV BND1      arc_1_13_7
 UP BND1      load_1_13_7  25
 BV BND1      arc_1_13_8
 UP BND1      load_1_13_8  25
 BV BND1      arc_1_13_9
 UP BND1      load_1_13_9  25
 BV BND1      arc_1_13_14
 UP BND1      load_1_13_14  25
 BV BND1      arc_1_13_15
 UP BND1      load_1_13_15  25
 BV BND1      arc_1_13_16
 UP BND1      load_1_13_16  25
 BV BND1      arc_1_13_17
 UP BND1      load_1_13_17  25
 BV BND1      arc_1_13_18
 UP BND1      load_1_13_18  25
 BV BND1      arc_1_13_19
 UP BND1      load_1_13_19  25
 BV BND1      arc_1_13_20
 UP BND1      load_1_13_20  25
 BV BND1      arc_1_14_0
 UP BND1      load_1_14_0  25
 BV BND1      arc_1_14_6
 UP BND1      load_1_14_6  25
 BV BND1      arc_1_14_7
 UP BND1      load_1_14_7  25
 BV BND1      arc_1_14_8
 UP BND1      load_1_14_8  25
 BV BND1      arc_1_14_9
 UP BND1      load_1_14_9  25
 BV BND1      arc_1_14_13
 UP BND1      load_1_14_13  25
 BV BND1      arc_1_14_15
 UP BND1      load_1_14_15  25
 BV BND1      arc_1_14_16
 UP BND1      load_1_14_16  25
 BV BND1      arc_1_14_17
 UP BND1      load_1_14_17  25
 BV BND1      arc_1_14_18
 UP BND1      load_1_14_18  25
 BV BND1      arc_1_14_19
 UP BND1      load_1_14_19  25
 BV BND1      arc_1_14_20
 UP BND1      load_1_14_20  25
 BV BND1      arc_1_15_0
 UP BND1      load_1_15_0  25
 BV BND1      arc_1_15_6
 UP BND1      load_1_15_6  25
 BV BND1      arc_1_15_7
 UP BND1      load_1_15_7  25
 BV BND1      arc_1_15_8
 UP BND1      load_1_15_8  25
 BV BND1      arc_1_15_9
 UP BND1      load_1_15_9  25
 BV BND1      arc_1_15_13
 UP BND1      load_1_15_13  25
 BV BND1      arc_1_15_14
 UP BND1      load_1_15_14  25
 BV BND1      arc_1_15_16
 UP BND1      load_1_15_16  25
 BV BND1      arc_1_15_17
 UP BND1      load_1_15_17  25
 BV BND1      arc_1_15_18
 UP BND1      load_1_15_18  25
 BV BND1      arc_1_15_19
 UP BND1      load_1_15_19  25
 BV BND1      arc_1_15_20
 UP BND1      load_1_15_20  25
 BV BND1      arc_1_16_0
 UP BND1      load_1_16_0  25
 BV BND1      arc_1_16_6
 UP BND1      load_1_16_6  25
 BV BND1      arc_1_16_7
 UP BND1      load_1_16_7  25
 BV BND1      arc_1_16_8
 UP BND1      load_1_16_8  25
 BV BND1      arc_1_16_9
 UP BND1      load_1_16_9  25
 BV BND1      arc_1_16_13
 UP BND1      load_1_16_13  25
 BV BND1      arc_1_16_14
 UP BND1      load_1_16_14  25
 BV BND1      arc_1_16_15
 UP BND1      load_1_16_15  25
 BV BND1      arc_1_16_17
 UP BND1      load_1_16_17  25
 BV BND1      arc_1_16_18
 UP BND1      load_1_16_18  25
 BV BND1      arc_1_16_19
 UP BND1      load_1_16_19  25
 BV BND1      arc_1_16_20
 UP BND1      load_1_16_20  25
 BV BND1      arc_1_17_0
 UP BND1      load_1_17_0  25
 BV BND1      arc_1_17_6
 UP BND1      load_1_17_6  25
 BV BND1      arc_1_17_7
 UP BND1      load_1_17_7  25
 BV BND1      arc_1_17_8
 UP BND1      load_1_17_8  25
 BV BND1      arc_1_17_9
 UP BND1      load_1_17_9  25
 BV BND1      arc_1_17_13
 UP BND1      load_1_17_13  25
 BV BND1      arc_1_17_14
 UP BND1      load_1_17_14  25
 BV BND1      arc_1_17_15
 UP BND1      load_1_17_15  25
 BV BND1      arc_1_17_16
 UP BND1      load_1_17_16  25
 BV BND1      arc_1_17_18
 UP BND1      load_1_17_18  25
 BV BND1      arc_1_17_19
 UP BND1      load_1_17_19  25
 BV BND1      arc_1_17_20
 UP BND1      load_1_17_20  25
 BV BND1      arc_1_18_0
 UP BND1      load_1_18_0  25
 BV BND1      arc_1_18_6
 UP BND1      load_1_18_6  25
 BV BND1      arc_1_18_7
 UP BND1      load_1_18_7  25
 BV BND1      arc_1_18_8
 UP BND1      load_1_18_8  25
 BV BND1      arc_1_18_9
 UP BND1      load_1_18_9  25
 BV BND1      arc_1_18_13
 UP BND1      load_1_18_13  25
 BV BND1      arc_1_18_14
 UP BND1      load_1_18_14  25
 BV BND1      arc_1_18_15
 UP BND1      load_1_18_15  25
 BV BND1      arc_1_18_16
 UP BND1      load_1_18_16  25
 BV BND1      arc_1_18_17
 UP BND1      load_1_18_17  25
 BV BND1      arc_1_18_19
 UP BND1      load_1_18_19  25
 BV BND1      arc_1_18_20
 UP BND1      load_1_18_20  25
 BV BND1      arc_1_19_0
 UP BND1      load_1_19_0  25
 BV BND1      arc_1_19_6
 UP BND1      load_1_19_6  25
 BV BND1      arc_1_19_7
 UP BND1      load_1_19_7  25
 BV BND1      arc_1_19_8
 UP BND1      load_1_19_8  25
 BV BND1      arc_1_19_9
 UP BND1      load_1_19_9  25
 BV BND1      arc_1_19_13
 UP BND1      load_1_19_13  25
 BV BND1      arc_1_19_14
 UP BND1      load_1_19_14  25
 BV BND1      arc_1_19_15
 UP BND1      load_1_19_15  25
 BV BND1      arc_1_19_16
 UP BND1      load_1_19_16  25
 BV BND1      arc_1_19_17
 UP BND1      load_1_19_17  25
 BV BND1      arc_1_19_18
 UP BND1      load_1_19_18  25
 BV BND1      arc_1_19_20
 UP BND1      load_1_19_20  25
 BV BND1      arc_1_20_0
 UP BND1      load_1_20_0  25
 BV BND1      arc_1_20_6
 UP BND1      load_1_20_6  25
 BV BND1      arc_1_20_7
 UP BND1      load_1_20_7  25
 BV BND1      arc_1_20_8
 UP BND1      load_1_20_8  25
 BV BND1      arc_1_20_9
 UP BND1      load_1_20_9  25
 BV BND1      arc_1_20_13
 UP BND1      load_1_20_13  25
 BV BND1      arc_1_20_14
 UP BND1      load_1_20_14  25
 BV BND1      arc_1_20_15
 UP BND1      load_1_20_15  25
 BV BND1      arc_1_20_16
 UP BND1      load_1_20_16  25
 BV BND1      arc_1_20_17
 UP BND1      load_1_20_17  25
 BV BND1      arc_1_20_18
 UP BND1      load_1_20_18  25
 BV BND1      arc_1_20_19
 UP BND1      load_1_20_19  25
 FX BND1      visit_2_10  1
 UP BND1      order_2_10  11
 FX BND1      visit_2_11  1
 UP BND1      order_2_11  11
 FX BND1      visit_2_12  1
 UP BND1      order_2_12  11
 UP BND1      visit_2_13  1
 UP BND1      order_2_13  11
 UP BND1      visit_2_14  1
 UP BND1      order_2_14  11
 UP BND1      visit_2_15  1
 UP BND1      order_2_15  11
 UP BND1      visit_2_16  1
 UP BND1      order_2_16  11
 UP BND1      visit_2_17  1
 UP BND1      order_2_17  11
 UP BND1      visit_2_18  1
 UP BND1      order_2_18  11
 UP BND1      visit_2_19  1
 UP BND1      order_2_19  11
 UP BND1      visit_2_20  1
 UP BND1      order_2_20  11
 BV BND1      arc_2_0_0
 FX BND1      load_2_0_0  0
 BV BND1      arc_2_0_10
 FX BND1      load_2_0_10  0
 BV BND1      arc_2_0_11
 FX BND1      load_2_0_11  0
 BV BND1      arc_2_0_12
 FX BND1      load_2_0_12  0
 BV BND1      arc_2_0_13
 FX BND1      load_2_0_13  0
 BV BND1      arc_2_0_14
 FX BND1      load_2_0_14  0
 BV BND1      arc_2_0_15
 FX BND1      load_2_0_15  0
 BV BND1      arc_2_0_16
 FX BND1      load_2_0_16  0
 BV BND1      arc_2_0_17
 FX BND1      load_2_0_17  0
 BV BND1      arc_2_0_18
 FX BND1      load_2_0_18  0
 BV BND1      arc_2_0_19
 FX BND1      load_2_0_19  0
 BV BND1      arc_2_0_20
 FX BND1      load_2_0_20  0
 BV BND1      arc_2_10_0
 UP BND1      load_2_10_0  30
 BV BND1      arc_2_10_11
 UP BND1      load_2_10_11  30
 BV BND1      arc_2_10_12
 UP BND1      load_2_10_12  30
 BV BND1      arc_2_10_13
 UP BND1      load_2_10_13  30
 BV BND1      arc_2_10_14
 UP BND1      load_2_10_14  30
 BV BND1      arc_2_10_15
 UP BND1      load_2_10_15  30
 BV BND1      arc_2_10_16
 UP BND1      load_2_10_16  30
 BV BND1      arc_2_10_17
 UP BND1      load_2_10_17  30
 BV BND1      arc_2_10_18
 UP BND1      load_2_10_18  30
 BV BND1      arc_2_10_19
 UP BND1      load_2_10_19  30
 BV BND1      arc_2_10_20
 UP BND1      load_2_10_20  30
 BV BND1      arc_2_11_0
 UP BND1      load_2_11_0  30
 BV BND1      arc_2_11_10
 UP BND1      load_2_11_10  30
 BV BND1      arc_2_11_12
 UP BND1      load_2_11_12  30
 BV BND1      arc_2_11_13
 UP BND1      load_2_11_13  30
 BV BND1      arc_2_11_14
 UP BND1      load_2_11_14  30
 BV BND1      arc_2_11_15
 UP BND1      load_2_11_15  30
 BV BND1      arc_2_11_16
 UP BND1      load_2_11_16  30
 BV BND1      arc_2_11_17
 UP BND1      load_2_11_17  30
 BV BND1      arc_2_11_18
 UP BND1      load_2_11_18  30
 BV BND1      arc_2_11_19
 UP BND1      load_2_11_19  30
 BV BND1      arc_2_11_20
 UP BND1      load_2_11_20  30
 BV BND1      arc_2_12_0
 UP BND1      load_2_12_0  30
 BV BND1      arc_2_12_10
 UP BND1      load_2_12_10  30
 BV BND1      arc_2_12_11
 UP BND1      load_2_12_11  30
 BV BND1      arc_2_12_13
 UP BND1      load_2_12_13  30
 BV BND1      arc_2_12_14
 UP BND1      load_2_12_14  30
 BV BND1      arc_2_12_15
 UP BND1      load_2_12_15  30
 BV BND1      arc_2_12_16
 UP BND1      load_2_12_16  30
 BV BND1      arc_2_12_17
 UP BND1      load_2_12_17  30
 BV BND1      arc_2_12_18
 UP BND1      load_2_12_18  30
 BV BND1      arc_2_12_19
 UP BND1      load_2_12_19  30
 BV BND1      arc_2_12_20
 UP BND1      load_2_12_20  30
 BV BND1      arc_2_13_0
 UP BND1      load_2_13_0  30
 BV BND1      arc_2_13_10
 UP BND1      load_2_13_10  30
 BV BND1      arc_2_13_11
 UP BND1      load_2_13_11  30
 BV BND1      arc_2_13_12
 UP BND1      load_2_13_12  30
 BV BND1      arc_2_13_14
 UP BND1      load_2_13_14  30
 BV BND1      arc_2_13_15
 UP BND1      load_2_13_15  30
 BV BND1      arc_2_13_16
 UP BND1      load_2_13_16  30
 BV BND1      arc_2_13_17
 UP BND1      load_2_13_17  30
 BV BND1      arc_2_13_18
 UP BND1      load_2_13_18  30
 BV BND1      arc_2_13_19
 UP BND1      load_2_13_19  30
 BV BND1      arc_2_13_20
 UP BND1      load_2_13_20  30
 BV BND1      arc_2_14_0
 UP BND1      load_2_14_0  30
 BV BND1      arc_2_14_10
 UP BND1      load_2_14_10  30
 BV BND1      arc_2_14_11
 UP BND1      load_2_14_11  30
 BV BND1      arc_2_14_12
 UP BND1      load_2_14_12  30
 BV BND1      arc_2_14_13
 UP BND1      load_2_14_13  30
 BV BND1      arc_2_14_15
 UP BND1      load_2_14_15  30
 BV BND1      arc_2_14_16
 UP BND1      load_2_14_16  30
 BV BND1      arc_2_14_17
 UP BND1      load_2_14_17  30
 BV BND1      arc_2_14_18
 UP BND1      load_2_14_18  30
 BV BND1      arc_2_14_19
 UP BND1      load_2_14_19  30
 BV BND1      arc_2_14_20
 UP BND1      load_2_14_20  30
 BV BND1      arc_2_15_0
 UP BND1      load_2_15_0  30
 BV BND1      arc_2_15_10
 UP BND1      load_2_15_10  30
 BV BND1      arc_2_15_11
 UP BND1      load_2_15_11  30
 BV BND1      arc_2_15_12
 UP BND1      load_2_15_12  30
 BV BND1      arc_2_15_13
 UP BND1      load_2_15_13  30
 BV BND1      arc_2_15_14
 UP BND1      load_2_15_14  30
 BV BND1      arc_2_15_16
 UP BND1      load_2_15_16  30
 BV BND1      arc_2_15_17
 UP BND1      load_2_15_17  30
 BV BND1      arc_2_15_18
 UP BND1      load_2_15_18  30
 BV BND1      arc_2_15_19
 UP BND1      load_2_15_19  30
 BV BND1      arc_2_15_20
 UP BND1      load_2_15_20  30
 BV BND1      arc_2_16_0
 UP BND1      load_2_16_0  30
 BV BND1      arc_2_16_10
 UP BND1      load_2_16_10  30
 BV BND1      arc_2_16_11
 UP BND1      load_2_16_11  30
 BV BND1      arc_2_16_12
 UP BND1      load_2_16_12  30
 BV BND1      arc_2_16_13
 UP BND1      load_2_16_13  30
 BV BND1      arc_2_16_14
 UP BND1      load_2_16_14  30
 BV BND1      arc_2_16_15
 UP BND1      load_2_16_15  30
 BV BND1      arc_2_16_17
 UP BND1      load_2_16_17  30
 BV BND1      arc_2_16_18
 UP BND1      load_2_16_18  30
 BV BND1      arc_2_16_19
 UP BND1      load_2_16_19  30
 BV BND1      arc_2_16_20
 UP BND1      load_2_16_20  30
 BV BND1      arc_2_17_0
 UP BND1      load_2_17_0  30
 BV BND1      arc_2_17_10
 UP BND1      load_2_17_10  30
 BV BND1      arc_2_17_11
 UP BND1      load_2_17_11  30
 BV BND1      arc_2_17_12
 UP BND1      load_2_17_12  30
 BV BND1      arc_2_17_13
 UP BND1      load_2_17_13  30
 BV BND1      arc_2_17_14
 UP BND1      load_2_17_14  30
 BV BND1      arc_2_17_15
 UP BND1      load_2_17_15  30
 BV BND1      arc_2_17_16
 UP BND1      load_2_17_16  30
 BV BND1      arc_2_17_18
 UP BND1      load_2_17_18  30
 BV BND1      arc_2_17_19
 UP BND1      load_2_17_19  30
 BV BND1      arc_2_17_20
 UP BND1      load_2_17_20  30
 BV BND1      arc_2_18_0
 UP BND1      load_2_18_0  30
 BV BND1      arc_2_18_10
 UP BND1      load_2_18_10  30
 BV BND1      arc_2_18_11
 UP BND1      load_2_18_11  30
 BV BND1      arc_2_18_12
 UP BND1      load_2_18_12  30
 BV BND1      arc_2_18_13
 UP BND1      load_2_18_13  30
 BV BND1      arc_2_18_14
 UP BND1      load_2_18_14  30
 BV BND1      arc_2_18_15
 UP BND1      load_2_18_15  30
 BV BND1      arc_2_18_16
 UP BND1      load_2_18_16  30
 BV BND1      arc_2_18_17
 UP BND1      load_2_18_17  30
 BV BND1      arc_2_18_19
 UP BND1      load_2_18_19  30
 BV BND1      arc_2_18_20
 UP BND1      load_2_18_20  30
 BV BND1      arc_2_19_0
 UP BND1      load_2_19_0  30
 BV BND1      arc_2_19_10
 UP BND1      load_2_19_10  30
 BV BND1      arc_2_19_11
 UP BND1      load_2_19_11  30
 BV BND1      arc_2_19_12
 UP BND1      load_2_19_12  30
 BV BND1      arc_2_19_13
 UP BND1      load_2_19_13  30
 BV BND1      arc_2_19_14
 UP BND1      load_2_19_14  30
 BV BND1      arc_2_19_15
 UP BND1      load_2_19_15  30
 BV BND1      arc_2_19_16
 UP BND1      load_2_19_16  30
 BV BND1      arc_2_19_17
 UP BND1      load_2_19_17  30
 BV BND1      arc_2_19_18
 UP BND1      load_2_19_18  30
 BV BND1      arc_2_19_20
 UP BND1      load_2_19_20  30
 BV BND1      arc_2_20_0
 UP BND1      load_2_20_0  30
 BV BND1      arc_2_20_10
 UP BND1      load_2_20_10  30
 BV BND1      arc_2_20_11
 UP BND1      load_2_20_11  30
 BV BND1      arc_2_20_12
 UP BND1      load_2_20_12  30
 BV BND1      arc_2_20_13
 UP BND1      load_2_20_13  30
 BV BND1      arc_2_20_14
 UP BND1      load_2_20_14  30
 BV BND1      arc_2_20_15
 UP BND1      load_2_20_15  30
 BV BND1      arc_2_20_16
 UP BND1      load_2_20_16  30
 BV BND1      arc_2_20_17
 UP BND1      load_2_20_17  30
 BV BND1      arc_2_20_18
 UP BND1      load_2_20_18  30
 BV BND1      arc_2_20_19
 UP BND1      load_2_20_19  30
ENDATA
