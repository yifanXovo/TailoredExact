* Signature: 0x4770e75323e01985
NAME 
ROWS
 N  OBJ
 E  onehot_1
 E  inventory_1
 E  ratio_1 
 E  product_mass_1
 G  product_lx_1_0
 L  product_ux_1_0
 G  product_Su_1_0
 L  product_Sl_1_0
 G  product_lx_1_1
 L  product_ux_1_1
 G  product_Su_1_1
 L  product_Sl_1_1
 G  product_lx_1_2
 L  product_ux_1_2
 G  product_Su_1_2
 L  product_Sl_1_2
 G  product_lx_1_3
 L  product_ux_1_3
 G  product_Su_1_3
 L  product_Sl_1_3
 G  product_lx_1_4
 L  product_ux_1_4
 G  product_Su_1_4
 L  product_Sl_1_4
 E  onehot_2
 E  inventory_2
 E  ratio_2 
 E  product_mass_2
 G  product_lx_2_0
 L  product_ux_2_0
 G  product_Su_2_0
 L  product_Sl_2_0
 G  product_lx_2_1
 L  product_ux_2_1
 G  product_Su_2_1
 L  product_Sl_2_1
 G  product_lx_2_2
 L  product_ux_2_2
 G  product_Su_2_2
 L  product_Sl_2_2
 G  product_lx_2_3
 L  product_ux_2_3
 G  product_Su_2_3
 L  product_Sl_2_3
 G  product_lx_2_4
 L  product_ux_2_4
 G  product_Su_2_4
 L  product_Sl_2_4
 E  denominator
 G  hard_lower
 L  hard_upper
 G  abs_p_1_2
 G  abs_m_1_2
 L  physical_G_upper_outward
 G  total_product_lower
 L  total_product_upper
 G  floor_residual
 G  G_residual
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    x[1,0]    onehot_1  1
    x[1,0]    product_lx_1_0  -0.5
    x[1,0]    product_ux_1_0  -4
    x[1,0]    product_Su_1_0  -4
    x[1,0]    product_Sl_1_0  -0.5
    x[1,1]    onehot_1  1
    x[1,1]    inventory_1  -1
    x[1,1]    product_lx_1_1  -0.5
    x[1,1]    product_ux_1_1  -4
    x[1,1]    product_Su_1_1  -4
    x[1,1]    product_Sl_1_1  -0.5
    x[1,2]    onehot_1  1
    x[1,2]    inventory_1  -2
    x[1,2]    product_lx_1_2  -0.5
    x[1,2]    product_ux_1_2  -4
    x[1,2]    product_Su_1_2  -4
    x[1,2]    product_Sl_1_2  -0.5
    x[1,3]    onehot_1  1
    x[1,3]    inventory_1  -3
    x[1,3]    product_lx_1_3  -0.5
    x[1,3]    product_ux_1_3  -4
    x[1,3]    product_Su_1_3  -4
    x[1,3]    product_Sl_1_3  -0.5
    x[1,4]    onehot_1  1
    x[1,4]    inventory_1  -4
    x[1,4]    product_lx_1_4  -0.5
    x[1,4]    product_ux_1_4  -4
    x[1,4]    product_Su_1_4  -4
    x[1,4]    product_Sl_1_4  -0.5
    x[2,0]    onehot_2  1
    x[2,0]    product_lx_2_0  -0.5
    x[2,0]    product_ux_2_0  -4
    x[2,0]    product_Su_2_0  -4
    x[2,0]    product_Sl_2_0  -0.5
    x[2,1]    onehot_2  1
    x[2,1]    inventory_2  -1
    x[2,1]    product_lx_2_1  -0.5
    x[2,1]    product_ux_2_1  -4
    x[2,1]    product_Su_2_1  -4
    x[2,1]    product_Sl_2_1  -0.5
    x[2,2]    onehot_2  1
    x[2,2]    inventory_2  -2
    x[2,2]    product_lx_2_2  -0.5
    x[2,2]    product_ux_2_2  -4
    x[2,2]    product_Su_2_2  -4
    x[2,2]    product_Sl_2_2  -0.5
    x[2,3]    onehot_2  1
    x[2,3]    inventory_2  -3
    x[2,3]    product_lx_2_3  -0.5
    x[2,3]    product_ux_2_3  -4
    x[2,3]    product_Su_2_3  -4
    x[2,3]    product_Sl_2_3  -0.5
    x[2,4]    onehot_2  1
    x[2,4]    inventory_2  -4
    x[2,4]    product_lx_2_4  -0.5
    x[2,4]    product_ux_2_4  -4
    x[2,4]    product_Su_2_4  -4
    x[2,4]    product_Sl_2_4  -0.5
    MARKER    'MARKER'                 'INTEND'
    Sx[1,0]   product_mass_1  1
    Sx[1,0]   product_lx_1_0  1
    Sx[1,0]   product_ux_1_0  1
    Sx[1,0]   product_Su_1_0  1
    Sx[1,0]   product_Sl_1_0  1
    Sx[1,0]   floor_residual  -0.078125
    Sx[1,0]   G_residual  -0.078125
    Sx[1,1]   product_mass_1  1
    Sx[1,1]   product_lx_1_1  1
    Sx[1,1]   product_ux_1_1  1
    Sx[1,1]   product_Su_1_1  1
    Sx[1,1]   product_Sl_1_1  1
    Sx[1,1]   total_product_lower  1
    Sx[1,1]   total_product_upper  1
    Sx[1,1]   floor_residual  -0.0390625
    Sx[1,1]   G_residual  -0.0390625
    Sx[1,2]   product_mass_1  1
    Sx[1,2]   product_lx_1_2  1
    Sx[1,2]   product_ux_1_2  1
    Sx[1,2]   product_Su_1_2  1
    Sx[1,2]   product_Sl_1_2  1
    Sx[1,2]   total_product_lower  2
    Sx[1,2]   total_product_upper  2
    Sx[1,3]   product_mass_1  1
    Sx[1,3]   product_lx_1_3  1
    Sx[1,3]   product_ux_1_3  1
    Sx[1,3]   product_Su_1_3  1
    Sx[1,3]   product_Sl_1_3  1
    Sx[1,3]   total_product_lower  3
    Sx[1,3]   total_product_upper  3
    Sx[1,3]   floor_residual  0.0390625
    Sx[1,3]   G_residual  0.0390625
    Sx[1,4]   product_mass_1  1
    Sx[1,4]   product_lx_1_4  1
    Sx[1,4]   product_ux_1_4  1
    Sx[1,4]   product_Su_1_4  1
    Sx[1,4]   product_Sl_1_4  1
    Sx[1,4]   total_product_lower  4
    Sx[1,4]   total_product_upper  4
    Sx[1,4]   floor_residual  0.078125
    Sx[1,4]   G_residual  0.078125
    Sx[2,0]   product_mass_2  1
    Sx[2,0]   product_lx_2_0  1
    Sx[2,0]   product_ux_2_0  1
    Sx[2,0]   product_Su_2_0  1
    Sx[2,0]   product_Sl_2_0  1
    Sx[2,0]   floor_residual  -0.078125
    Sx[2,0]   G_residual  -0.078125
    Sx[2,1]   product_mass_2  1
    Sx[2,1]   product_lx_2_1  1
    Sx[2,1]   product_ux_2_1  1
    Sx[2,1]   product_Su_2_1  1
    Sx[2,1]   product_Sl_2_1  1
    Sx[2,1]   total_product_lower  1
    Sx[2,1]   total_product_upper  1
    Sx[2,1]   floor_residual  -0.0390625
    Sx[2,1]   G_residual  -0.0390625
    Sx[2,2]   product_mass_2  1
    Sx[2,2]   product_lx_2_2  1
    Sx[2,2]   product_ux_2_2  1
    Sx[2,2]   product_Su_2_2  1
    Sx[2,2]   product_Sl_2_2  1
    Sx[2,2]   total_product_lower  2
    Sx[2,2]   total_product_upper  2
    Sx[2,3]   product_mass_2  1
    Sx[2,3]   product_lx_2_3  1
    Sx[2,3]   product_ux_2_3  1
    Sx[2,3]   product_Su_2_3  1
    Sx[2,3]   product_Sl_2_3  1
    Sx[2,3]   total_product_lower  3
    Sx[2,3]   total_product_upper  3
    Sx[2,3]   floor_residual  0.0390625
    Sx[2,3]   G_residual  0.0390625
    Sx[2,4]   product_mass_2  1
    Sx[2,4]   product_lx_2_4  1
    Sx[2,4]   product_ux_2_4  1
    Sx[2,4]   product_Su_2_4  1
    Sx[2,4]   product_Sl_2_4  1
    Sx[2,4]   total_product_lower  4
    Sx[2,4]   total_product_upper  4
    Sx[2,4]   floor_residual  0.078125
    Sx[2,4]   G_residual  0.078125
    S         product_mass_1  -1
    S         product_Su_1_0  -1
    S         product_Sl_1_0  -1
    S         product_Su_1_1  -1
    S         product_Sl_1_1  -1
    S         product_Su_1_2  -1
    S         product_Sl_1_2  -1
    S         product_Su_1_3  -1
    S         product_Sl_1_3  -1
    S         product_Su_1_4  -1
    S         product_Sl_1_4  -1
    S         product_mass_2  -1
    S         product_Su_2_0  -1
    S         product_Sl_2_0  -1
    S         product_Su_2_1  -1
    S         product_Sl_2_1  -1
    S         product_Su_2_2  -1
    S         product_Sl_2_2  -1
    S         product_Su_2_3  -1
    S         product_Sl_2_3  -1
    S         product_Su_2_4  -1
    S         product_Sl_2_4  -1
    S         denominator  1
    S         physical_G_upper_outward  -0.6
    S         total_product_lower  -1
    S         total_product_upper  -4
    S         floor_residual  0.015625
    S         G_residual  0.015625
    Y[1]      inventory_1  1
    Y[1]      ratio_1   -1
    Y[1]      hard_lower  1
    Y[1]      hard_upper  1
    Y[2]      inventory_2  1
    Y[2]      ratio_2   -0.5
    Y[2]      hard_lower  1
    Y[2]      hard_upper  1
    r[1]      ratio_1   1
    r[1]      denominator  -1
    r[1]      abs_p_1_2  -1
    r[1]      abs_m_1_2  1
    r[2]      ratio_2   1
    r[2]      denominator  -1
    r[2]      abs_p_1_2  1
    r[2]      abs_m_1_2  -1
    abs[1,2]  abs_p_1_2  1
    abs[1,2]  abs_m_1_2  1
    abs[1,2]  physical_G_upper_outward  1
    residual_scaled  OBJ       1
    residual_scaled  floor_residual  1
    residual_scaled  G_residual  1
RHS
    RHS1      onehot_1  1
    RHS1      product_Su_1_0  -4
    RHS1      product_Sl_1_0  -0.5
    RHS1      product_Su_1_1  -4
    RHS1      product_Sl_1_1  -0.5
    RHS1      product_Su_1_2  -4
    RHS1      product_Sl_1_2  -0.5
    RHS1      product_Su_1_3  -4
    RHS1      product_Sl_1_3  -0.5
    RHS1      product_Su_1_4  -4
    RHS1      product_Sl_1_4  -0.5
    RHS1      onehot_2  1
    RHS1      product_Su_2_0  -4
    RHS1      product_Sl_2_0  -0.5
    RHS1      product_Su_2_1  -4
    RHS1      product_Sl_2_1  -0.5
    RHS1      product_Su_2_2  -4
    RHS1      product_Sl_2_2  -0.5
    RHS1      product_Su_2_3  -4
    RHS1      product_Sl_2_3  -0.5
    RHS1      product_Su_2_4  -4
    RHS1      product_Sl_2_4  -0.5
    RHS1      hard_lower  1
    RHS1      hard_upper  4
BOUNDS
 BV BND1      x[1,0]  
 BV BND1      x[1,1]  
 BV BND1      x[1,2]  
 BV BND1      x[1,3]  
 BV BND1      x[1,4]  
 BV BND1      x[2,0]  
 BV BND1      x[2,1]  
 BV BND1      x[2,2]  
 BV BND1      x[2,3]  
 BV BND1      x[2,4]  
 UP BND1      Sx[1,0]   4
 UP BND1      Sx[1,1]   4
 UP BND1      Sx[1,2]   4
 UP BND1      Sx[1,3]   4
 UP BND1      Sx[1,4]   4
 UP BND1      Sx[2,0]   4
 UP BND1      Sx[2,1]   4
 UP BND1      Sx[2,2]   4
 UP BND1      Sx[2,3]   4
 UP BND1      Sx[2,4]   4
 LO BND1      S         0.5
 UP BND1      S         4
 FR BND1      residual_scaled
ENDATA
