* Signature: 0x73fef0ed6e210736
NAME R160_physical_neighborhood
ROWS
 N  OBJ
 G  product_lb_0
 L  product_ub_1
 G  product_lb_2
 L  product_ub_3
 G  product_lb_4
 L  product_ub_5
 E  onehot_5_6
 E  normalized_mass_5_7
 E  normalized_ratio_5_8
 G  product_lb_9
 L  product_ub_10
 G  product_lb_11
 L  product_ub_12
 E  onehot_6_13
 E  normalized_mass_6_14
 E  normalized_ratio_6_15
 G  product_lb_16
 L  product_ub_17
 G  product_lb_18
 L  product_ub_19
 G  product_lb_20
 L  product_ub_21
 G  product_lb_22
 L  product_ub_23
 G  product_lb_24
 L  product_ub_25
 G  product_lb_26
 L  product_ub_27
 G  product_lb_28
 L  product_ub_29
 G  product_lb_30
 L  product_ub_31
 G  product_lb_32
 L  product_ub_33
 G  product_lb_34
 L  product_ub_35
 G  product_lb_36
 L  product_ub_37
 G  product_lb_38
 L  product_ub_39
 G  product_lb_40
 L  product_ub_41
 G  product_lb_42
 L  product_ub_43
 G  product_lb_44
 L  product_ub_45
 G  product_lb_46
 L  product_ub_47
 E  onehot_18_48
 E  normalized_mass_18_49
 E  normalized_ratio_18_50
 G  product_lb_51
 L  product_ub_52
 G  product_lb_53
 L  product_ub_54
 G  product_lb_55
 L  product_ub_56
 G  product_lb_57
 L  product_ub_58
 G  product_lb_59
 L  product_ub_60
 G  product_lb_61
 L  product_ub_62
 G  product_lb_63
 L  product_ub_64
 G  product_lb_65
 L  product_ub_66
 G  product_lb_67
 L  product_ub_68
 G  product_lb_69
 L  product_ub_70
 G  product_lb_71
 L  product_ub_72
 G  product_lb_73
 L  product_ub_74
 G  product_lb_75
 L  product_ub_76
 G  product_lb_77
 L  product_ub_78
 G  product_lb_79
 L  product_ub_80
 G  product_lb_81
 L  product_ub_82
 G  product_lb_83
 L  product_ub_84
 E  onehot_3_85
 E  normalized_mass_3_86
 E  normalized_ratio_3_87
 G  product_lb_88
 L  product_ub_89
 G  product_lb_90
 L  product_ub_91
 G  product_lb_92
 L  product_ub_93
 G  product_lb_94
 L  product_ub_95
 G  product_lb_96
 L  product_ub_97
 G  product_lb_98
 L  product_ub_99
 G  product_lb_100
 L  product_ub_101
 G  product_lb_102
 L  product_ub_103
 G  product_lb_104
 L  product_ub_105
 G  product_lb_106
 L  product_ub_107
 G  product_lb_108
 L  product_ub_109
 G  product_lb_110
 L  product_ub_111
 G  product_lb_112
 L  product_ub_113
 G  product_lb_114
 L  product_ub_115
 G  product_lb_116
 L  product_ub_117
 G  product_lb_118
 L  product_ub_119
 G  product_lb_120
 L  product_ub_121
 E  onehot_17_122
 E  normalized_mass_17_123
 E  normalized_ratio_17_124
 G  product_lb_125
 L  product_ub_126
 G  product_lb_127
 L  product_ub_128
 G  product_lb_129
 L  product_ub_130
 G  product_lb_131
 L  product_ub_132
 G  product_lb_133
 L  product_ub_134
 G  product_lb_135
 L  product_ub_136
 G  product_lb_137
 L  product_ub_138
 G  product_lb_139
 L  product_ub_140
 G  product_lb_141
 L  product_ub_142
 G  product_lb_143
 L  product_ub_144
 G  product_lb_145
 L  product_ub_146
 G  product_lb_147
 L  product_ub_148
 G  product_lb_149
 L  product_ub_150
 G  product_lb_151
 L  product_ub_152
 G  product_lb_153
 L  product_ub_154
 G  product_lb_155
 L  product_ub_156
 E  onehot_4_157
 E  normalized_mass_4_158
 E  normalized_ratio_4_159
 G  product_lb_160
 L  product_ub_161
 G  product_lb_162
 L  product_ub_163
 G  product_lb_164
 L  product_ub_165
 G  product_lb_166
 L  product_ub_167
 G  product_lb_168
 L  product_ub_169
 G  product_lb_170
 L  product_ub_171
 G  product_lb_172
 L  product_ub_173
 G  product_lb_174
 L  product_ub_175
 G  product_lb_176
 L  product_ub_177
 G  product_lb_178
 L  product_ub_179
 G  product_lb_180
 L  product_ub_181
 G  product_lb_182
 L  product_ub_183
 G  product_lb_184
 L  product_ub_185
 G  product_lb_186
 L  product_ub_187
 G  product_lb_188
 L  product_ub_189
 G  product_lb_190
 L  product_ub_191
 E  onehot_11_192
 E  normalized_mass_11_193
 E  normalized_ratio_11_194
 G  product_lb_195
 L  product_ub_196
 G  product_lb_197
 L  product_ub_198
 E  onehot_2_199
 E  normalized_mass_2_200
 E  normalized_ratio_2_201
 G  stock_lb_202
 L  stock_ub_203
 L  parent_nonstrict_scope_204
 G  block_pair_pos_205
 G  block_pair_neg_206
 G  block_pair_pos_207
 G  block_pair_neg_208
 G  block_pair_pos_209
 G  block_pair_neg_210
 G  block_pair_pos_211
 G  block_pair_neg_212
 G  block_pair_pos_213
 G  block_pair_neg_214
 G  block_pair_pos_215
 G  block_pair_neg_216
 G  block_pair_pos_217
 G  block_pair_neg_218
 G  block_pair_pos_219
 G  block_pair_neg_220
 G  block_pair_pos_221
 G  block_pair_neg_222
 G  block_pair_pos_223
 G  block_pair_neg_224
 G  block_pair_pos_225
 G  block_pair_neg_226
 G  block_pair_pos_227
 G  block_pair_neg_228
 G  block_pair_pos_229
 G  block_pair_neg_230
 G  block_pair_pos_231
 G  block_pair_neg_232
 G  block_pair_pos_233
 G  block_pair_neg_234
 G  block_pair_pos_235
 G  block_pair_neg_236
 G  block_pair_pos_237
 G  block_pair_neg_238
 G  block_pair_pos_239
 G  block_pair_neg_240
 G  block_pair_pos_241
 G  block_pair_neg_242
 G  block_pair_pos_243
 G  block_pair_neg_244
 G  block_pair_pos_245
 G  block_pair_neg_246
 G  block_pair_pos_247
 G  block_pair_neg_248
 G  block_pair_pos_249
 G  block_pair_neg_250
 G  block_pair_pos_251
 G  block_pair_neg_252
 G  block_pair_pos_253
 G  block_pair_neg_254
 G  block_pair_pos_255
 G  block_pair_neg_256
 G  block_pair_pos_257
 G  block_pair_neg_258
 G  block_pair_pos_259
 G  block_pair_neg_260
 E  normalization_261
 G  full_original_Gini_262
 E  unique_nonzero_owner_263
 E  unique_nonzero_owner_264
 E  unique_nonzero_owner_265
 E  unique_nonzero_owner_266
 E  unique_nonzero_owner_267
 E  unique_nonzero_owner_268
 E  unique_nonzero_owner_269
 E  unique_nonzero_owner_270
 E  unique_nonzero_owner_271
 E  unique_nonzero_owner_272
 E  unique_nonzero_owner_273
 E  unique_nonzero_owner_274
 E  unique_nonzero_owner_275
 E  unique_nonzero_owner_276
 E  unique_nonzero_owner_277
 E  unique_nonzero_owner_278
 E  unique_nonzero_owner_279
 E  unique_nonzero_owner_280
 E  unique_nonzero_owner_281
 E  unique_nonzero_owner_282
 E  unique_nonzero_owner_283
 E  unique_nonzero_owner_284
 E  unique_nonzero_owner_285
 E  unique_nonzero_owner_286
 E  unique_nonzero_owner_287
 E  unique_nonzero_owner_288
 E  unique_nonzero_owner_289
 E  unique_nonzero_owner_290
 E  unique_nonzero_owner_291
 E  unique_nonzero_owner_292
 E  unique_nonzero_owner_293
 E  unique_nonzero_owner_294
 E  unique_nonzero_owner_295
 E  unique_nonzero_owner_296
 E  unique_nonzero_owner_297
 E  unique_nonzero_owner_298
 E  unique_nonzero_owner_299
 E  unique_nonzero_owner_300
 E  unique_nonzero_owner_301
 E  unique_nonzero_owner_302
 E  unique_nonzero_owner_303
 E  unique_nonzero_owner_304
 E  unique_nonzero_owner_305
 E  unique_nonzero_owner_306
 E  unique_nonzero_owner_307
 E  unique_nonzero_owner_308
 E  unique_nonzero_owner_309
 E  unique_nonzero_owner_310
 E  unique_nonzero_owner_311
 E  unique_nonzero_owner_312
 E  unique_nonzero_owner_313
 E  unique_nonzero_owner_314
 E  unique_nonzero_owner_315
 E  unique_nonzero_owner_316
 E  unique_nonzero_owner_317
 E  unique_nonzero_owner_318
 E  unique_nonzero_owner_319
 E  unique_nonzero_owner_320
 E  unique_nonzero_owner_321
 E  unique_nonzero_owner_322
 E  unique_nonzero_owner_323
 E  unique_nonzero_owner_324
 E  unique_nonzero_owner_325
 E  unique_nonzero_owner_326
 E  unique_nonzero_owner_327
 E  unique_nonzero_owner_328
 E  unique_nonzero_owner_329
 E  unique_nonzero_owner_330
 E  unique_nonzero_owner_331
 E  unique_nonzero_owner_332
 E  unique_nonzero_owner_333
 E  unique_nonzero_owner_334
 E  unique_nonzero_owner_335
 E  unique_nonzero_owner_336
 E  unique_nonzero_owner_337
 E  unique_nonzero_owner_338
 E  unique_nonzero_owner_339
 E  unique_nonzero_owner_340
 E  unique_nonzero_owner_341
 E  unique_nonzero_owner_342
 E  unique_nonzero_owner_343
 L  arc_capacity_344
 L  arc_capacity_345
 L  arc_capacity_346
 L  arc_capacity_347
 L  arc_capacity_348
 L  arc_capacity_349
 L  arc_capacity_350
 L  arc_capacity_351
 L  arc_capacity_352
 L  arc_capacity_353
 L  arc_capacity_354
 L  arc_capacity_355
 L  arc_capacity_356
 L  arc_capacity_357
 L  arc_capacity_358
 L  arc_capacity_359
 G  connected_order_arc_360
 L  arc_capacity_361
 G  connected_order_arc_362
 L  arc_capacity_363
 G  connected_order_arc_364
 L  arc_capacity_365
 G  connected_order_arc_366
 L  arc_capacity_367
 G  connected_order_arc_368
 L  arc_capacity_369
 G  connected_order_arc_370
 L  arc_capacity_371
 G  connected_order_arc_372
 L  arc_capacity_373
 G  connected_order_arc_374
 L  arc_capacity_375
 G  connected_order_arc_376
 L  arc_capacity_377
 G  connected_order_arc_378
 L  arc_capacity_379
 G  connected_order_arc_380
 L  arc_capacity_381
 G  connected_order_arc_382
 L  arc_capacity_383
 L  arc_capacity_384
 G  connected_order_arc_385
 L  arc_capacity_386
 G  connected_order_arc_387
 L  arc_capacity_388
 G  connected_order_arc_389
 L  arc_capacity_390
 G  connected_order_arc_391
 L  arc_capacity_392
 G  connected_order_arc_393
 L  arc_capacity_394
 G  connected_order_arc_395
 L  arc_capacity_396
 G  connected_order_arc_397
 L  arc_capacity_398
 G  connected_order_arc_399
 L  arc_capacity_400
 G  connected_order_arc_401
 L  arc_capacity_402
 G  connected_order_arc_403
 L  arc_capacity_404
 G  connected_order_arc_405
 L  arc_capacity_406
 G  connected_order_arc_407
 L  arc_capacity_408
 L  arc_capacity_409
 G  connected_order_arc_410
 L  arc_capacity_411
 G  connected_order_arc_412
 L  arc_capacity_413
 G  connected_order_arc_414
 L  arc_capacity_415
 G  connected_order_arc_416
 L  arc_capacity_417
 G  connected_order_arc_418
 L  arc_capacity_419
 G  connected_order_arc_420
 L  arc_capacity_421
 G  connected_order_arc_422
 L  arc_capacity_423
 G  connected_order_arc_424
 L  arc_capacity_425
 G  connected_order_arc_426
 L  arc_capacity_427
 G  connected_order_arc_428
 L  arc_capacity_429
 G  connected_order_arc_430
 L  arc_capacity_431
 G  connected_order_arc_432
 L  arc_capacity_433
 L  arc_capacity_434
 G  connected_order_arc_435
 L  arc_capacity_436
 G  connected_order_arc_437
 L  arc_capacity_438
 G  connected_order_arc_439
 L  arc_capacity_440
 G  connected_order_arc_441
 L  arc_capacity_442
 G  connected_order_arc_443
 L  arc_capacity_444
 G  connected_order_arc_445
 L  arc_capacity_446
 G  connected_order_arc_447
 L  arc_capacity_448
 G  connected_order_arc_449
 L  arc_capacity_450
 G  connected_order_arc_451
 L  arc_capacity_452
 G  connected_order_arc_453
 L  arc_capacity_454
 G  connected_order_arc_455
 L  arc_capacity_456
 G  connected_order_arc_457
 L  arc_capacity_458
 L  arc_capacity_459
 G  connected_order_arc_460
 L  arc_capacity_461
 G  connected_order_arc_462
 L  arc_capacity_463
 G  connected_order_arc_464
 L  arc_capacity_465
 G  connected_order_arc_466
 L  arc_capacity_467
 G  connected_order_arc_468
 L  arc_capacity_469
 G  connected_order_arc_470
 L  arc_capacity_471
 G  connected_order_arc_472
 L  arc_capacity_473
 G  connected_order_arc_474
 L  arc_capacity_475
 G  connected_order_arc_476
 L  arc_capacity_477
 G  connected_order_arc_478
 L  arc_capacity_479
 G  connected_order_arc_480
 L  arc_capacity_481
 G  connected_order_arc_482
 L  arc_capacity_483
 L  arc_capacity_484
 G  connected_order_arc_485
 L  arc_capacity_486
 G  connected_order_arc_487
 L  arc_capacity_488
 G  connected_order_arc_489
 L  arc_capacity_490
 G  connected_order_arc_491
 L  arc_capacity_492
 G  connected_order_arc_493
 L  arc_capacity_494
 G  connected_order_arc_495
 L  arc_capacity_496
 G  connected_order_arc_497
 L  arc_capacity_498
 G  connected_order_arc_499
 L  arc_capacity_500
 G  connected_order_arc_501
 L  arc_capacity_502
 G  connected_order_arc_503
 L  arc_capacity_504
 G  connected_order_arc_505
 L  arc_capacity_506
 G  connected_order_arc_507
 L  arc_capacity_508
 L  arc_capacity_509
 G  connected_order_arc_510
 L  arc_capacity_511
 G  connected_order_arc_512
 L  arc_capacity_513
 G  connected_order_arc_514
 L  arc_capacity_515
 G  connected_order_arc_516
 L  arc_capacity_517
 G  connected_order_arc_518
 L  arc_capacity_519
 G  connected_order_arc_520
 L  arc_capacity_521
 G  connected_order_arc_522
 L  arc_capacity_523
 G  connected_order_arc_524
 L  arc_capacity_525
 G  connected_order_arc_526
 L  arc_capacity_527
 G  connected_order_arc_528
 L  arc_capacity_529
 G  connected_order_arc_530
 L  arc_capacity_531
 G  connected_order_arc_532
 L  arc_capacity_533
 L  arc_capacity_534
 G  connected_order_arc_535
 L  arc_capacity_536
 G  connected_order_arc_537
 L  arc_capacity_538
 G  connected_order_arc_539
 L  arc_capacity_540
 G  connected_order_arc_541
 L  arc_capacity_542
 G  connected_order_arc_543
 L  arc_capacity_544
 G  connected_order_arc_545
 L  arc_capacity_546
 G  connected_order_arc_547
 L  arc_capacity_548
 G  connected_order_arc_549
 L  arc_capacity_550
 G  connected_order_arc_551
 L  arc_capacity_552
 G  connected_order_arc_553
 L  arc_capacity_554
 G  connected_order_arc_555
 L  arc_capacity_556
 G  connected_order_arc_557
 L  arc_capacity_558
 L  arc_capacity_559
 G  connected_order_arc_560
 L  arc_capacity_561
 G  connected_order_arc_562
 L  arc_capacity_563
 G  connected_order_arc_564
 L  arc_capacity_565
 G  connected_order_arc_566
 L  arc_capacity_567
 G  connected_order_arc_568
 L  arc_capacity_569
 G  connected_order_arc_570
 L  arc_capacity_571
 G  connected_order_arc_572
 L  arc_capacity_573
 G  connected_order_arc_574
 L  arc_capacity_575
 G  connected_order_arc_576
 L  arc_capacity_577
 G  connected_order_arc_578
 L  arc_capacity_579
 G  connected_order_arc_580
 L  arc_capacity_581
 G  connected_order_arc_582
 L  arc_capacity_583
 L  arc_capacity_584
 G  connected_order_arc_585
 L  arc_capacity_586
 G  connected_order_arc_587
 L  arc_capacity_588
 G  connected_order_arc_589
 L  arc_capacity_590
 G  connected_order_arc_591
 L  arc_capacity_592
 G  connected_order_arc_593
 L  arc_capacity_594
 G  connected_order_arc_595
 L  arc_capacity_596
 G  connected_order_arc_597
 L  arc_capacity_598
 G  connected_order_arc_599
 L  arc_capacity_600
 G  connected_order_arc_601
 L  arc_capacity_602
 G  connected_order_arc_603
 L  arc_capacity_604
 G  connected_order_arc_605
 L  arc_capacity_606
 G  connected_order_arc_607
 L  arc_capacity_608
 L  arc_capacity_609
 G  connected_order_arc_610
 L  arc_capacity_611
 G  connected_order_arc_612
 L  arc_capacity_613
 G  connected_order_arc_614
 L  arc_capacity_615
 G  connected_order_arc_616
 L  arc_capacity_617
 G  connected_order_arc_618
 L  arc_capacity_619
 G  connected_order_arc_620
 L  arc_capacity_621
 G  connected_order_arc_622
 L  arc_capacity_623
 G  connected_order_arc_624
 L  arc_capacity_625
 G  connected_order_arc_626
 L  arc_capacity_627
 G  connected_order_arc_628
 L  arc_capacity_629
 G  connected_order_arc_630
 L  arc_capacity_631
 G  connected_order_arc_632
 L  arc_capacity_633
 L  arc_capacity_634
 G  connected_order_arc_635
 L  arc_capacity_636
 G  connected_order_arc_637
 L  arc_capacity_638
 G  connected_order_arc_639
 L  arc_capacity_640
 G  connected_order_arc_641
 L  arc_capacity_642
 G  connected_order_arc_643
 L  arc_capacity_644
 G  connected_order_arc_645
 L  arc_capacity_646
 G  connected_order_arc_647
 L  arc_capacity_648
 G  connected_order_arc_649
 L  arc_capacity_650
 G  connected_order_arc_651
 L  arc_capacity_652
 G  connected_order_arc_653
 L  arc_capacity_654
 G  connected_order_arc_655
 L  arc_capacity_656
 G  connected_order_arc_657
 L  arc_capacity_658
 L  arc_capacity_659
 G  connected_order_arc_660
 L  arc_capacity_661
 G  connected_order_arc_662
 L  arc_capacity_663
 G  connected_order_arc_664
 L  arc_capacity_665
 G  connected_order_arc_666
 L  arc_capacity_667
 G  connected_order_arc_668
 L  arc_capacity_669
 G  connected_order_arc_670
 L  arc_capacity_671
 G  connected_order_arc_672
 L  arc_capacity_673
 G  connected_order_arc_674
 L  arc_capacity_675
 G  connected_order_arc_676
 L  arc_capacity_677
 G  connected_order_arc_678
 L  arc_capacity_679
 G  connected_order_arc_680
 L  arc_capacity_681
 G  connected_order_arc_682
 E  depot_departure_or_bypass_683
 E  depot_return_or_bypass_684
 E  out_degree_685
 E  in_degree_686
 G  order_active_lb_687
 L  order_active_ub_688
 E  segment_load_conservation_689
 G  segment_prefix_lb_690
 L  segment_prefix_ub_691
 E  out_degree_692
 E  in_degree_693
 G  order_active_lb_694
 L  order_active_ub_695
 E  segment_load_conservation_696
 G  segment_prefix_lb_697
 L  segment_prefix_ub_698
 E  out_degree_699
 E  in_degree_700
 G  order_active_lb_701
 L  order_active_ub_702
 E  segment_load_conservation_703
 G  segment_prefix_lb_704
 L  segment_prefix_ub_705
 E  out_degree_706
 E  in_degree_707
 G  order_active_lb_708
 L  order_active_ub_709
 E  segment_load_conservation_710
 G  segment_prefix_lb_711
 L  segment_prefix_ub_712
 E  out_degree_713
 E  in_degree_714
 G  order_active_lb_715
 L  order_active_ub_716
 E  segment_load_conservation_717
 G  segment_prefix_lb_718
 L  segment_prefix_ub_719
 E  out_degree_720
 E  in_degree_721
 G  order_active_lb_722
 L  order_active_ub_723
 E  service_visit_def_724
 E  free_load_conservation_725
 E  out_degree_726
 E  in_degree_727
 G  order_active_lb_728
 L  order_active_ub_729
 E  service_visit_def_730
 E  free_load_conservation_731
 E  out_degree_732
 E  in_degree_733
 G  order_active_lb_734
 L  order_active_ub_735
 E  service_visit_def_736
 E  free_load_conservation_737
 E  out_degree_738
 E  in_degree_739
 G  order_active_lb_740
 L  order_active_ub_741
 E  service_visit_def_742
 E  free_load_conservation_743
 E  out_degree_744
 E  in_degree_745
 G  order_active_lb_746
 L  order_active_ub_747
 E  service_visit_def_748
 E  free_load_conservation_749
 E  out_degree_750
 E  in_degree_751
 G  order_active_lb_752
 L  order_active_ub_753
 E  service_visit_def_754
 E  free_load_conservation_755
 E  out_degree_756
 E  in_degree_757
 G  order_active_lb_758
 L  order_active_ub_759
 E  service_visit_def_760
 E  free_load_conservation_761
 E  out_degree_762
 E  in_degree_763
 G  order_active_lb_764
 L  order_active_ub_765
 E  service_visit_def_766
 E  free_load_conservation_767
 G  fixed_segment_relative_order_768
 G  fixed_segment_relative_order_769
 G  fixed_segment_relative_order_770
 G  fixed_segment_relative_order_771
 L  original_T_including_depot_unload_772
 L  arc_capacity_773
 L  arc_capacity_774
 L  arc_capacity_775
 L  arc_capacity_776
 L  arc_capacity_777
 L  arc_capacity_778
 L  arc_capacity_779
 L  arc_capacity_780
 L  arc_capacity_781
 L  arc_capacity_782
 L  arc_capacity_783
 L  arc_capacity_784
 L  arc_capacity_785
 G  connected_order_arc_786
 L  arc_capacity_787
 G  connected_order_arc_788
 L  arc_capacity_789
 G  connected_order_arc_790
 L  arc_capacity_791
 G  connected_order_arc_792
 L  arc_capacity_793
 G  connected_order_arc_794
 L  arc_capacity_795
 G  connected_order_arc_796
 L  arc_capacity_797
 G  connected_order_arc_798
 L  arc_capacity_799
 G  connected_order_arc_800
 L  arc_capacity_801
 G  connected_order_arc_802
 L  arc_capacity_803
 L  arc_capacity_804
 G  connected_order_arc_805
 L  arc_capacity_806
 G  connected_order_arc_807
 L  arc_capacity_808
 G  connected_order_arc_809
 L  arc_capacity_810
 G  connected_order_arc_811
 L  arc_capacity_812
 G  connected_order_arc_813
 L  arc_capacity_814
 G  connected_order_arc_815
 L  arc_capacity_816
 G  connected_order_arc_817
 L  arc_capacity_818
 G  connected_order_arc_819
 L  arc_capacity_820
 G  connected_order_arc_821
 L  arc_capacity_822
 L  arc_capacity_823
 G  connected_order_arc_824
 L  arc_capacity_825
 G  connected_order_arc_826
 L  arc_capacity_827
 G  connected_order_arc_828
 L  arc_capacity_829
 G  connected_order_arc_830
 L  arc_capacity_831
 G  connected_order_arc_832
 L  arc_capacity_833
 G  connected_order_arc_834
 L  arc_capacity_835
 G  connected_order_arc_836
 L  arc_capacity_837
 G  connected_order_arc_838
 L  arc_capacity_839
 G  connected_order_arc_840
 L  arc_capacity_841
 L  arc_capacity_842
 G  connected_order_arc_843
 L  arc_capacity_844
 G  connected_order_arc_845
 L  arc_capacity_846
 G  connected_order_arc_847
 L  arc_capacity_848
 G  connected_order_arc_849
 L  arc_capacity_850
 G  connected_order_arc_851
 L  arc_capacity_852
 G  connected_order_arc_853
 L  arc_capacity_854
 G  connected_order_arc_855
 L  arc_capacity_856
 G  connected_order_arc_857
 L  arc_capacity_858
 G  connected_order_arc_859
 L  arc_capacity_860
 L  arc_capacity_861
 G  connected_order_arc_862
 L  arc_capacity_863
 G  connected_order_arc_864
 L  arc_capacity_865
 G  connected_order_arc_866
 L  arc_capacity_867
 G  connected_order_arc_868
 L  arc_capacity_869
 G  connected_order_arc_870
 L  arc_capacity_871
 G  connected_order_arc_872
 L  arc_capacity_873
 G  connected_order_arc_874
 L  arc_capacity_875
 G  connected_order_arc_876
 L  arc_capacity_877
 G  connected_order_arc_878
 L  arc_capacity_879
 L  arc_capacity_880
 G  connected_order_arc_881
 L  arc_capacity_882
 G  connected_order_arc_883
 L  arc_capacity_884
 G  connected_order_arc_885
 L  arc_capacity_886
 G  connected_order_arc_887
 L  arc_capacity_888
 G  connected_order_arc_889
 L  arc_capacity_890
 G  connected_order_arc_891
 L  arc_capacity_892
 G  connected_order_arc_893
 L  arc_capacity_894
 G  connected_order_arc_895
 L  arc_capacity_896
 G  connected_order_arc_897
 L  arc_capacity_898
 L  arc_capacity_899
 G  connected_order_arc_900
 L  arc_capacity_901
 G  connected_order_arc_902
 L  arc_capacity_903
 G  connected_order_arc_904
 L  arc_capacity_905
 G  connected_order_arc_906
 L  arc_capacity_907
 G  connected_order_arc_908
 L  arc_capacity_909
 G  connected_order_arc_910
 L  arc_capacity_911
 G  connected_order_arc_912
 L  arc_capacity_913
 G  connected_order_arc_914
 L  arc_capacity_915
 G  connected_order_arc_916
 L  arc_capacity_917
 L  arc_capacity_918
 G  connected_order_arc_919
 L  arc_capacity_920
 G  connected_order_arc_921
 L  arc_capacity_922
 G  connected_order_arc_923
 L  arc_capacity_924
 G  connected_order_arc_925
 L  arc_capacity_926
 G  connected_order_arc_927
 L  arc_capacity_928
 G  connected_order_arc_929
 L  arc_capacity_930
 G  connected_order_arc_931
 L  arc_capacity_932
 G  connected_order_arc_933
 L  arc_capacity_934
 G  connected_order_arc_935
 L  arc_capacity_936
 L  arc_capacity_937
 G  connected_order_arc_938
 L  arc_capacity_939
 G  connected_order_arc_940
 L  arc_capacity_941
 G  connected_order_arc_942
 L  arc_capacity_943
 G  connected_order_arc_944
 L  arc_capacity_945
 G  connected_order_arc_946
 L  arc_capacity_947
 G  connected_order_arc_948
 L  arc_capacity_949
 G  connected_order_arc_950
 L  arc_capacity_951
 G  connected_order_arc_952
 L  arc_capacity_953
 G  connected_order_arc_954
 L  arc_capacity_955
 L  arc_capacity_956
 G  connected_order_arc_957
 L  arc_capacity_958
 G  connected_order_arc_959
 L  arc_capacity_960
 G  connected_order_arc_961
 L  arc_capacity_962
 G  connected_order_arc_963
 L  arc_capacity_964
 G  connected_order_arc_965
 L  arc_capacity_966
 G  connected_order_arc_967
 L  arc_capacity_968
 G  connected_order_arc_969
 L  arc_capacity_970
 G  connected_order_arc_971
 L  arc_capacity_972
 G  connected_order_arc_973
 E  depot_departure_or_bypass_974
 E  depot_return_or_bypass_975
 E  out_degree_976
 E  in_degree_977
 G  order_active_lb_978
 L  order_active_ub_979
 E  segment_load_conservation_980
 G  segment_prefix_lb_981
 L  segment_prefix_ub_982
 E  out_degree_983
 E  in_degree_984
 G  order_active_lb_985
 L  order_active_ub_986
 E  segment_load_conservation_987
 G  segment_prefix_lb_988
 L  segment_prefix_ub_989
 E  out_degree_990
 E  in_degree_991
 G  order_active_lb_992
 L  order_active_ub_993
 E  service_visit_def_994
 E  free_load_conservation_995
 E  out_degree_996
 E  in_degree_997
 G  order_active_lb_998
 L  order_active_ub_999
 E  service_visit_def_1000
 E  free_load_conservation_1001
 E  out_degree_1002
 E  in_degree_1003
 G  order_active_lb_1004
 L  order_active_ub_1005
 E  service_visit_def_1006
 E  free_load_conservation_1007
 E  out_degree_1008
 E  in_degree_1009
 G  order_active_lb_1010
 L  order_active_ub_1011
 E  service_visit_def_1012
 E  free_load_conservation_1013
 E  out_degree_1014
 E  in_degree_1015
 G  order_active_lb_1016
 L  order_active_ub_1017
 E  service_visit_def_1018
 E  free_load_conservation_1019
 E  out_degree_1020
 E  in_degree_1021
 G  order_active_lb_1022
 L  order_active_ub_1023
 E  service_visit_def_1024
 E  free_load_conservation_1025
 E  out_degree_1026
 E  in_degree_1027
 G  order_active_lb_1028
 L  order_active_ub_1029
 E  service_visit_def_1030
 E  free_load_conservation_1031
 E  out_degree_1032
 E  in_degree_1033
 G  order_active_lb_1034
 L  order_active_ub_1035
 E  service_visit_def_1036
 E  free_load_conservation_1037
 G  fixed_segment_relative_order_1038
 L  original_T_including_depot_unload_1039
COLUMNS
    t         normalized_mass_5_7  -1
    t         normalized_mass_6_14  -1
    t         normalized_mass_18_49  -1
    t         normalized_mass_3_86  -1
    t         normalized_mass_17_123  -1
    t         normalized_mass_4_158  -1
    t         normalized_mass_11_193  -1
    t         normalized_mass_2_200  -1
    t         normalization_261  8.8714285714285719e+00
    t         full_original_Gini_262  -3.7242857142857140e+01
    q         OBJ       1
    q         parent_nonstrict_scope_204  1
    q         full_original_Gini_262  20
    MARKER    'MARKER'                 'INTORG'
    x_5_0     OBJ       6.3380304899829966e-03
    x_5_0     product_lb_0  -4.4361511107937186e-02
    x_5_0     product_ub_1  -1.1272141706935590e-01
    x_5_0     onehot_5_6  1
    x_5_0     parent_nonstrict_scope_204  1.2676060979965993e-02
    MARKER    'MARKER'                 'INTEND'
    w_5_0     product_lb_0  1
    w_5_0     product_ub_1  1
    w_5_0     normalized_mass_5_7  1
    w_5_0     full_original_Gini_262  -8.8714285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_5_1     OBJ       -6.3380304899829966e-03
    x_5_1     product_lb_2  -4.4361511107937186e-02
    x_5_1     product_ub_3  -1.1272141706935590e-01
    x_5_1     onehot_5_6  1
    x_5_1     stock_lb_202  1
    x_5_1     stock_ub_203  1
    x_5_1     unique_nonzero_owner_263  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_1     product_lb_2  1
    w_5_1     product_ub_3  1
    w_5_1     normalized_mass_5_7  1
    w_5_1     normalized_ratio_5_8  -1
    w_5_1     full_original_Gini_262  -4.4142857142857146e+00
    MARKER    'MARKER'                 'INTORG'
    x_5_2     OBJ       6.3380304899829966e-03
    x_5_2     product_lb_4  -4.4361511107937186e-02
    x_5_2     product_ub_5  -1.1272141706935590e-01
    x_5_2     onehot_5_6  1
    x_5_2     stock_lb_202  2
    x_5_2     stock_ub_203  2
    x_5_2     parent_nonstrict_scope_204  1.2676060979965993e-02
    x_5_2     unique_nonzero_owner_264  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_2     product_lb_4  1
    w_5_2     product_ub_5  1
    w_5_2     normalized_mass_5_7  1
    w_5_2     normalized_ratio_5_8  -2
    w_5_2     full_original_Gini_262  -1.5128571428571428e+01
    rho_5     normalized_ratio_5_8  1
    rho_5     block_pair_pos_217  -1
    rho_5     block_pair_neg_218  1
    rho_5     block_pair_pos_219  -1
    rho_5     block_pair_neg_220  1
    rho_5     block_pair_pos_221  -1
    rho_5     block_pair_neg_222  1
    rho_5     block_pair_pos_223  -1
    rho_5     block_pair_neg_224  1
    rho_5     block_pair_pos_225  -1
    rho_5     block_pair_neg_226  1
    rho_5     block_pair_pos_227  -1
    rho_5     block_pair_neg_228  1
    rho_5     block_pair_pos_229  -1
    rho_5     block_pair_neg_230  1
    rho_5     normalization_261  1
    MARKER    'MARKER'                 'INTORG'
    x_6_0     OBJ       6.3380304899829966e-03
    x_6_0     product_lb_9  -4.4361511107937186e-02
    x_6_0     product_ub_10  -1.1272141706935590e-01
    x_6_0     onehot_6_13  1
    x_6_0     parent_nonstrict_scope_204  1.2676060979965993e-02
    MARKER    'MARKER'                 'INTEND'
    w_6_0     product_lb_9  1
    w_6_0     product_ub_10  1
    w_6_0     normalized_mass_6_14  1
    w_6_0     full_original_Gini_262  -8.8714285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_6_1     OBJ       -6.3380304899829966e-03
    x_6_1     product_lb_11  -4.4361511107937186e-02
    x_6_1     product_ub_12  -1.1272141706935590e-01
    x_6_1     onehot_6_13  1
    x_6_1     stock_lb_202  1
    x_6_1     stock_ub_203  1
    x_6_1     unique_nonzero_owner_265  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_1     product_lb_11  1
    w_6_1     product_ub_12  1
    w_6_1     normalized_mass_6_14  1
    w_6_1     normalized_ratio_6_15  -1
    w_6_1     full_original_Gini_262  -4.4142857142857146e+00
    rho_6     normalized_ratio_6_15  1
    rho_6     block_pair_pos_223  1
    rho_6     block_pair_neg_224  -1
    rho_6     block_pair_pos_231  -1
    rho_6     block_pair_neg_232  1
    rho_6     block_pair_pos_233  -1
    rho_6     block_pair_neg_234  1
    rho_6     block_pair_pos_235  -1
    rho_6     block_pair_neg_236  1
    rho_6     block_pair_pos_237  -1
    rho_6     block_pair_neg_238  1
    rho_6     block_pair_pos_239  -1
    rho_6     block_pair_neg_240  1
    rho_6     block_pair_pos_241  -1
    rho_6     block_pair_neg_242  1
    rho_6     normalization_261  1
    MARKER    'MARKER'                 'INTORG'
    x_18_0    OBJ       3.2863847044708572e-02
    x_18_0    product_lb_16  -4.4361511107937186e-02
    x_18_0    product_ub_17  -1.1272141706935590e-01
    x_18_0    onehot_18_48  1
    x_18_0    parent_nonstrict_scope_204  7.6682309770986667e-02
    MARKER    'MARKER'                 'INTEND'
    w_18_0    product_lb_16  1
    w_18_0    product_ub_17  1
    w_18_0    normalized_mass_18_49  1
    w_18_0    full_original_Gini_262  -8.8714285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_1    OBJ       2.1909231363139048e-02
    x_18_1    product_lb_18  -4.4361511107937186e-02
    x_18_1    product_ub_19  -1.1272141706935590e-01
    x_18_1    onehot_18_48  1
    x_18_1    stock_lb_202  1
    x_18_1    stock_ub_203  1
    x_18_1    parent_nonstrict_scope_204  6.5727694089417144e-02
    x_18_1    unique_nonzero_owner_266  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_1    product_lb_18  1
    w_18_1    product_ub_19  1
    w_18_1    normalized_mass_18_49  1
    w_18_1    normalized_ratio_18_50  -1.4285714285714285e-01
    w_18_1    full_original_Gini_262  -8.0142857142857142e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_2    OBJ       1.0954615681569524e-02
    x_18_2    product_lb_20  -4.4361511107937186e-02
    x_18_2    product_ub_21  -1.1272141706935590e-01
    x_18_2    onehot_18_48  1
    x_18_2    stock_lb_202  2
    x_18_2    stock_ub_203  2
    x_18_2    parent_nonstrict_scope_204  5.4773078407847620e-02
    x_18_2    unique_nonzero_owner_267  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_2    product_lb_20  1
    w_18_2    product_ub_21  1
    w_18_2    normalized_mass_18_49  1
    w_18_2    normalized_ratio_18_50  -2.8571428571428570e-01
    w_18_2    full_original_Gini_262  -7.1571428571428575e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_3    product_lb_22  -4.4361511107937186e-02
    x_18_3    product_ub_23  -1.1272141706935590e-01
    x_18_3    onehot_18_48  1
    x_18_3    stock_lb_202  3
    x_18_3    stock_ub_203  3
    x_18_3    parent_nonstrict_scope_204  4.3818462726278096e-02
    x_18_3    unique_nonzero_owner_268  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_3    product_lb_22  1
    w_18_3    product_ub_23  1
    w_18_3    normalized_mass_18_49  1
    w_18_3    normalized_ratio_18_50  -4.2857142857142855e-01
    w_18_3    full_original_Gini_262  -6.3
    MARKER    'MARKER'                 'INTORG'
    x_18_4    OBJ       -1.0954615681569524e-02
    x_18_4    product_lb_24  -4.4361511107937186e-02
    x_18_4    product_ub_25  -1.1272141706935590e-01
    x_18_4    onehot_18_48  1
    x_18_4    stock_lb_202  4
    x_18_4    stock_ub_203  4
    x_18_4    parent_nonstrict_scope_204  3.2863847044708572e-02
    x_18_4    unique_nonzero_owner_269  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_4    product_lb_24  1
    w_18_4    product_ub_25  1
    w_18_4    normalized_mass_18_49  1
    w_18_4    normalized_ratio_18_50  -5.7142857142857140e-01
    w_18_4    full_original_Gini_262  -5.7285714285714286e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_5    OBJ       -2.1909231363139041e-02
    x_18_5    product_lb_26  -4.4361511107937186e-02
    x_18_5    product_ub_27  -1.1272141706935590e-01
    x_18_5    onehot_18_48  1
    x_18_5    stock_lb_202  5
    x_18_5    stock_ub_203  5
    x_18_5    parent_nonstrict_scope_204  2.1909231363139055e-02
    x_18_5    unique_nonzero_owner_270  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_5    product_lb_26  1
    w_18_5    product_ub_27  1
    w_18_5    normalized_mass_18_49  1
    w_18_5    normalized_ratio_18_50  -7.1428571428571419e-01
    w_18_5    full_original_Gini_262  -5.1571428571428575e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_6    OBJ       -3.2863847044708572e-02
    x_18_6    product_lb_28  -4.4361511107937186e-02
    x_18_6    product_ub_29  -1.1272141706935590e-01
    x_18_6    onehot_18_48  1
    x_18_6    stock_lb_202  6
    x_18_6    stock_ub_203  6
    x_18_6    parent_nonstrict_scope_204  1.0954615681569527e-02
    x_18_6    unique_nonzero_owner_271  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_6    product_lb_28  1
    w_18_6    product_ub_29  1
    w_18_6    normalized_mass_18_49  1
    w_18_6    normalized_ratio_18_50  -8.5714285714285710e-01
    w_18_6    full_original_Gini_262  -4.7
    MARKER    'MARKER'                 'INTORG'
    x_18_7    OBJ       -4.3818462726278096e-02
    x_18_7    product_lb_30  -4.4361511107937186e-02
    x_18_7    product_ub_31  -1.1272141706935590e-01
    x_18_7    onehot_18_48  1
    x_18_7    stock_lb_202  7
    x_18_7    stock_ub_203  7
    x_18_7    unique_nonzero_owner_272  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_7    product_lb_30  1
    w_18_7    product_ub_31  1
    w_18_7    normalized_mass_18_49  1
    w_18_7    normalized_ratio_18_50  -1
    w_18_7    full_original_Gini_262  -4.4142857142857146e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_8    OBJ       -3.2863847044708579e-02
    x_18_8    product_lb_32  -4.4361511107937186e-02
    x_18_8    product_ub_33  -1.1272141706935590e-01
    x_18_8    onehot_18_48  1
    x_18_8    stock_lb_202  8
    x_18_8    stock_ub_203  8
    x_18_8    parent_nonstrict_scope_204  1.0954615681569519e-02
    x_18_8    unique_nonzero_owner_273  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_8    product_lb_32  1
    w_18_8    product_ub_33  1
    w_18_8    normalized_mass_18_49  1
    w_18_8    normalized_ratio_18_50  -1.1428571428571428e+00
    w_18_8    full_original_Gini_262  -5.5571428571428569e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_9    OBJ       -2.1909231363139058e-02
    x_18_9    product_lb_34  -4.4361511107937186e-02
    x_18_9    product_ub_35  -1.1272141706935590e-01
    x_18_9    onehot_18_48  1
    x_18_9    stock_lb_202  9
    x_18_9    stock_ub_203  9
    x_18_9    parent_nonstrict_scope_204  2.1909231363139037e-02
    x_18_9    unique_nonzero_owner_274  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_9    product_lb_34  1
    w_18_9    product_ub_35  1
    w_18_9    normalized_mass_18_49  1
    w_18_9    normalized_ratio_18_50  -1.2857142857142856e+00
    w_18_9    full_original_Gini_262  -6.9857142857142849e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_10   OBJ       -1.0954615681569538e-02
    x_18_10   product_lb_36  -4.4361511107937186e-02
    x_18_10   product_ub_37  -1.1272141706935590e-01
    x_18_10   onehot_18_48  1
    x_18_10   stock_lb_202  10
    x_18_10   stock_ub_203  10
    x_18_10   parent_nonstrict_scope_204  3.2863847044708558e-02
    x_18_10   unique_nonzero_owner_275  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_10   product_lb_36  1
    w_18_10   product_ub_37  1
    w_18_10   normalized_mass_18_49  1
    w_18_10   normalized_ratio_18_50  -1.4285714285714284e+00
    w_18_10   full_original_Gini_262  -8.4142857142857146e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_11   product_lb_38  -4.4361511107937186e-02
    x_18_11   product_ub_39  -1.1272141706935590e-01
    x_18_11   onehot_18_48  1
    x_18_11   stock_lb_202  11
    x_18_11   stock_ub_203  11
    x_18_11   parent_nonstrict_scope_204  4.3818462726278096e-02
    x_18_11   unique_nonzero_owner_276  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_11   product_lb_38  1
    w_18_11   product_ub_39  1
    w_18_11   normalized_mass_18_49  1
    w_18_11   normalized_ratio_18_50  -1.5714285714285714e+00
    w_18_11   full_original_Gini_262  -9.9857142857142840e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_12   OBJ       1.0954615681569517e-02
    x_18_12   product_lb_40  -4.4361511107937186e-02
    x_18_12   product_ub_41  -1.1272141706935590e-01
    x_18_12   onehot_18_48  1
    x_18_12   stock_lb_202  12
    x_18_12   stock_ub_203  12
    x_18_12   parent_nonstrict_scope_204  5.4773078407847613e-02
    x_18_12   unique_nonzero_owner_277  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_12   product_lb_40  1
    w_18_12   product_ub_41  1
    w_18_12   normalized_mass_18_49  1
    w_18_12   normalized_ratio_18_50  -1.7142857142857142e+00
    w_18_12   full_original_Gini_262  -1.1699999999999998e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_13   OBJ       2.1909231363139034e-02
    x_18_13   product_lb_42  -4.4361511107937186e-02
    x_18_13   product_ub_43  -1.1272141706935590e-01
    x_18_13   onehot_18_48  1
    x_18_13   stock_lb_202  13
    x_18_13   stock_ub_203  13
    x_18_13   parent_nonstrict_scope_204  6.5727694089417130e-02
    x_18_13   unique_nonzero_owner_278  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_13   product_lb_42  1
    w_18_13   product_ub_43  1
    w_18_13   normalized_mass_18_49  1
    w_18_13   normalized_ratio_18_50  -1.8571428571428570e+00
    w_18_13   full_original_Gini_262  -1.3414285714285715e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_14   OBJ       3.2863847044708572e-02
    x_18_14   product_lb_44  -4.4361511107937186e-02
    x_18_14   product_ub_45  -1.1272141706935590e-01
    x_18_14   onehot_18_48  1
    x_18_14   stock_lb_202  14
    x_18_14   stock_ub_203  14
    x_18_14   parent_nonstrict_scope_204  7.6682309770986667e-02
    x_18_14   unique_nonzero_owner_279  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_14   product_lb_44  1
    w_18_14   product_ub_45  1
    w_18_14   normalized_mass_18_49  1
    w_18_14   normalized_ratio_18_50  -2
    w_18_14   full_original_Gini_262  -1.5128571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_15   OBJ       4.3818462726278096e-02
    x_18_15   product_lb_46  -4.4361511107937186e-02
    x_18_15   product_ub_47  -1.1272141706935590e-01
    x_18_15   onehot_18_48  1
    x_18_15   stock_lb_202  15
    x_18_15   stock_ub_203  15
    x_18_15   parent_nonstrict_scope_204  8.7636925452556191e-02
    x_18_15   unique_nonzero_owner_280  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_15   product_lb_46  1
    w_18_15   product_ub_47  1
    w_18_15   normalized_mass_18_49  1
    w_18_15   normalized_ratio_18_50  -2.1428571428571428e+00
    w_18_15   full_original_Gini_262  -1.6842857142857138e+01
    rho_18    normalized_ratio_18_50  1
    rho_18    block_pair_pos_229  1
    rho_18    block_pair_neg_230  -1
    rho_18    block_pair_pos_241  1
    rho_18    block_pair_neg_242  -1
    rho_18    block_pair_pos_251  -1
    rho_18    block_pair_neg_252  1
    rho_18    block_pair_pos_253  -1
    rho_18    block_pair_neg_254  1
    rho_18    block_pair_pos_255  -1
    rho_18    block_pair_neg_256  1
    rho_18    block_pair_pos_257  -1
    rho_18    block_pair_neg_258  1
    rho_18    block_pair_pos_259  -1
    rho_18    block_pair_neg_260  1
    rho_18    normalization_261  1
    MARKER    'MARKER'                 'INTORG'
    x_3_0     OBJ       5.0078236648368350e-02
    x_3_0     product_lb_51  -4.4361511107937186e-02
    x_3_0     product_ub_52  -1.1272141706935590e-01
    x_3_0     onehot_3_85  1
    x_3_0     parent_nonstrict_scope_204  1.0015647329673670e-01
    x_3_0     unique_nonzero_owner_281  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_0     product_lb_51  1
    w_3_0     product_ub_52  1
    w_3_0     normalized_mass_3_86  1
    w_3_0     full_original_Gini_262  -8.8714285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_1     OBJ       3.7558677486276261e-02
    x_3_1     product_lb_53  -4.4361511107937186e-02
    x_3_1     product_ub_54  -1.1272141706935590e-01
    x_3_1     onehot_3_85  1
    x_3_1     stock_lb_202  1
    x_3_1     stock_ub_203  1
    x_3_1     parent_nonstrict_scope_204  8.7636914134644611e-02
    x_3_1     unique_nonzero_owner_282  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_1     product_lb_53  1
    w_3_1     product_ub_54  1
    w_3_1     normalized_mass_3_86  1
    w_3_1     normalized_ratio_3_87  -0.125
    w_3_1     full_original_Gini_262  -8.1214285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_2     OBJ       2.5039118324184172e-02
    x_3_2     product_lb_55  -4.4361511107937186e-02
    x_3_2     product_ub_56  -1.1272141706935590e-01
    x_3_2     onehot_3_85  1
    x_3_2     stock_lb_202  2
    x_3_2     stock_ub_203  2
    x_3_2     parent_nonstrict_scope_204  7.5117354972552522e-02
    x_3_2     unique_nonzero_owner_283  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_2     product_lb_55  1
    w_3_2     product_ub_56  1
    w_3_2     normalized_mass_3_86  1
    w_3_2     normalized_ratio_3_87  -0.25
    w_3_2     full_original_Gini_262  -7.3714285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_3     OBJ       1.2519559162092082e-02
    x_3_3     product_lb_57  -4.4361511107937186e-02
    x_3_3     product_ub_58  -1.1272141706935590e-01
    x_3_3     onehot_3_85  1
    x_3_3     stock_lb_202  3
    x_3_3     stock_ub_203  3
    x_3_3     parent_nonstrict_scope_204  6.2597795810460433e-02
    x_3_3     unique_nonzero_owner_284  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_3     product_lb_57  1
    w_3_3     product_ub_58  1
    w_3_3     normalized_mass_3_86  1
    w_3_3     normalized_ratio_3_87  -0.375
    w_3_3     full_original_Gini_262  -6.6214285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_4     product_lb_59  -4.4361511107937186e-02
    x_3_4     product_ub_60  -1.1272141706935590e-01
    x_3_4     onehot_3_85  1
    x_3_4     stock_lb_202  4
    x_3_4     stock_ub_203  4
    x_3_4     parent_nonstrict_scope_204  5.0078236648368350e-02
    x_3_4     unique_nonzero_owner_285  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_4     product_lb_59  1
    w_3_4     product_ub_60  1
    w_3_4     normalized_mass_3_86  1
    w_3_4     normalized_ratio_3_87  -0.5
    w_3_4     full_original_Gini_262  -6.0142857142857142e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_5     OBJ       -1.2519559162092089e-02
    x_3_5     product_lb_61  -4.4361511107937186e-02
    x_3_5     product_ub_62  -1.1272141706935590e-01
    x_3_5     onehot_3_85  1
    x_3_5     stock_lb_202  5
    x_3_5     stock_ub_203  5
    x_3_5     parent_nonstrict_scope_204  3.7558677486276261e-02
    x_3_5     unique_nonzero_owner_286  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_5     product_lb_61  1
    w_3_5     product_ub_62  1
    w_3_5     normalized_mass_3_86  1
    w_3_5     normalized_ratio_3_87  -0.625
    w_3_5     full_original_Gini_262  -5.5142857142857142e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_6     OBJ       -2.5039118324184175e-02
    x_3_6     product_lb_63  -4.4361511107937186e-02
    x_3_6     product_ub_64  -1.1272141706935590e-01
    x_3_6     onehot_3_85  1
    x_3_6     stock_lb_202  6
    x_3_6     stock_ub_203  6
    x_3_6     parent_nonstrict_scope_204  2.5039118324184175e-02
    x_3_6     unique_nonzero_owner_287  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_6     product_lb_63  1
    w_3_6     product_ub_64  1
    w_3_6     normalized_mass_3_86  1
    w_3_6     normalized_ratio_3_87  -0.75
    w_3_6     full_original_Gini_262  -5.0142857142857142e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_7     OBJ       -3.7558677486276261e-02
    x_3_7     product_lb_65  -4.4361511107937186e-02
    x_3_7     product_ub_66  -1.1272141706935590e-01
    x_3_7     onehot_3_85  1
    x_3_7     stock_lb_202  7
    x_3_7     stock_ub_203  7
    x_3_7     parent_nonstrict_scope_204  1.2519559162092088e-02
    x_3_7     unique_nonzero_owner_288  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_7     product_lb_65  1
    w_3_7     product_ub_66  1
    w_3_7     normalized_mass_3_86  1
    w_3_7     normalized_ratio_3_87  -0.875
    w_3_7     full_original_Gini_262  -4.6642857142857146e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_8     OBJ       -5.0078236648368350e-02
    x_3_8     product_lb_67  -4.4361511107937186e-02
    x_3_8     product_ub_68  -1.1272141706935590e-01
    x_3_8     onehot_3_85  1
    x_3_8     stock_lb_202  8
    x_3_8     stock_ub_203  8
    x_3_8     unique_nonzero_owner_289  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_8     product_lb_67  1
    w_3_8     product_ub_68  1
    w_3_8     normalized_mass_3_86  1
    w_3_8     normalized_ratio_3_87  -1
    w_3_8     full_original_Gini_262  -4.4142857142857146e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_9     OBJ       -3.7558677486276261e-02
    x_3_9     product_lb_69  -4.4361511107937186e-02
    x_3_9     product_ub_70  -1.1272141706935590e-01
    x_3_9     onehot_3_85  1
    x_3_9     stock_lb_202  9
    x_3_9     stock_ub_203  9
    x_3_9     parent_nonstrict_scope_204  1.2519559162092088e-02
    x_3_9     unique_nonzero_owner_290  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_9     product_lb_69  1
    w_3_9     product_ub_70  1
    w_3_9     normalized_mass_3_86  1
    w_3_9     normalized_ratio_3_87  -1.125
    w_3_9     full_original_Gini_262  -5.4142857142857146e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_10    OBJ       -2.5039118324184175e-02
    x_3_10    product_lb_71  -4.4361511107937186e-02
    x_3_10    product_ub_72  -1.1272141706935590e-01
    x_3_10    onehot_3_85  1
    x_3_10    stock_lb_202  10
    x_3_10    stock_ub_203  10
    x_3_10    parent_nonstrict_scope_204  2.5039118324184175e-02
    x_3_10    unique_nonzero_owner_291  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_10    product_lb_71  1
    w_3_10    product_ub_72  1
    w_3_10    normalized_mass_3_86  1
    w_3_10    normalized_ratio_3_87  -1.25
    w_3_10    full_original_Gini_262  -6.6285714285714281e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_11    OBJ       -1.2519559162092089e-02
    x_3_11    product_lb_73  -4.4361511107937186e-02
    x_3_11    product_ub_74  -1.1272141706935590e-01
    x_3_11    onehot_3_85  1
    x_3_11    stock_lb_202  11
    x_3_11    stock_ub_203  11
    x_3_11    parent_nonstrict_scope_204  3.7558677486276261e-02
    x_3_11    unique_nonzero_owner_292  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_11    product_lb_73  1
    w_3_11    product_ub_74  1
    w_3_11    normalized_mass_3_86  1
    w_3_11    normalized_ratio_3_87  -1.375
    w_3_11    full_original_Gini_262  -7.8785714285714281e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_12    product_lb_75  -4.4361511107937186e-02
    x_3_12    product_ub_76  -1.1272141706935590e-01
    x_3_12    onehot_3_85  1
    x_3_12    stock_lb_202  12
    x_3_12    stock_ub_203  12
    x_3_12    parent_nonstrict_scope_204  5.0078236648368350e-02
    MARKER    'MARKER'                 'INTEND'
    w_3_12    product_lb_75  1
    w_3_12    product_ub_76  1
    w_3_12    normalized_mass_3_86  1
    w_3_12    normalized_ratio_3_87  -1.5
    w_3_12    full_original_Gini_262  -9.1285714285714281e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_13    OBJ       1.2519559162092082e-02
    x_3_13    product_lb_77  -4.4361511107937186e-02
    x_3_13    product_ub_78  -1.1272141706935590e-01
    x_3_13    onehot_3_85  1
    x_3_13    stock_lb_202  13
    x_3_13    stock_ub_203  13
    x_3_13    parent_nonstrict_scope_204  6.2597795810460433e-02
    x_3_13    unique_nonzero_owner_293  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_13    product_lb_77  1
    w_3_13    product_ub_78  1
    w_3_13    normalized_mass_3_86  1
    w_3_13    normalized_ratio_3_87  -1.625
    w_3_13    full_original_Gini_262  -1.0628571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_14    OBJ       2.5039118324184172e-02
    x_3_14    product_lb_79  -4.4361511107937186e-02
    x_3_14    product_ub_80  -1.1272141706935590e-01
    x_3_14    onehot_3_85  1
    x_3_14    stock_lb_202  14
    x_3_14    stock_ub_203  14
    x_3_14    parent_nonstrict_scope_204  7.5117354972552522e-02
    x_3_14    unique_nonzero_owner_294  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_14    product_lb_79  1
    w_3_14    product_ub_80  1
    w_3_14    normalized_mass_3_86  1
    w_3_14    normalized_ratio_3_87  -1.75
    w_3_14    full_original_Gini_262  -1.2128571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_15    OBJ       3.7558677486276261e-02
    x_3_15    product_lb_81  -4.4361511107937186e-02
    x_3_15    product_ub_82  -1.1272141706935590e-01
    x_3_15    onehot_3_85  1
    x_3_15    stock_lb_202  15
    x_3_15    stock_ub_203  15
    x_3_15    parent_nonstrict_scope_204  8.7636914134644611e-02
    x_3_15    unique_nonzero_owner_295  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_15    product_lb_81  1
    w_3_15    product_ub_82  1
    w_3_15    normalized_mass_3_86  1
    w_3_15    normalized_ratio_3_87  -1.875
    w_3_15    full_original_Gini_262  -1.3628571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_16    OBJ       5.0078236648368350e-02
    x_3_16    product_lb_83  -4.4361511107937186e-02
    x_3_16    product_ub_84  -1.1272141706935590e-01
    x_3_16    onehot_3_85  1
    x_3_16    stock_lb_202  16
    x_3_16    stock_ub_203  16
    x_3_16    parent_nonstrict_scope_204  1.0015647329673670e-01
    x_3_16    unique_nonzero_owner_296  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_16    product_lb_83  1
    w_3_16    product_ub_84  1
    w_3_16    normalized_mass_3_86  1
    w_3_16    normalized_ratio_3_87  -2
    w_3_16    full_original_Gini_262  -1.5128571428571428e+01
    rho_3     normalized_ratio_3_87  1
    rho_3     block_pair_pos_205  -1
    rho_3     block_pair_neg_206  1
    rho_3     block_pair_pos_207  -1
    rho_3     block_pair_neg_208  1
    rho_3     block_pair_pos_209  -1
    rho_3     block_pair_neg_210  1
    rho_3     block_pair_pos_211  -1
    rho_3     block_pair_neg_212  1
    rho_3     block_pair_pos_219  1
    rho_3     block_pair_neg_220  -1
    rho_3     block_pair_pos_233  1
    rho_3     block_pair_neg_234  -1
    rho_3     block_pair_pos_253  1
    rho_3     block_pair_neg_254  -1
    rho_3     normalization_261  1
    MARKER    'MARKER'                 'INTORG'
    x_17_0    OBJ       6.3380304899829959e-02
    x_17_0    product_lb_88  -4.4361511107937186e-02
    x_17_0    product_ub_89  -1.1272141706935590e-01
    x_17_0    onehot_17_122  1
    x_17_0    parent_nonstrict_scope_204  1.2676060979965992e-01
    x_17_0    unique_nonzero_owner_297  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_0    product_lb_88  1
    w_17_0    product_ub_89  1
    w_17_0    normalized_mass_17_123  1
    w_17_0    full_original_Gini_262  -8.8714285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_1    OBJ       4.9295792699867738e-02
    x_17_1    product_lb_90  -4.4361511107937186e-02
    x_17_1    product_ub_91  -1.1272141706935590e-01
    x_17_1    onehot_17_122  1
    x_17_1    stock_lb_202  1
    x_17_1    stock_ub_203  1
    x_17_1    parent_nonstrict_scope_204  1.1267609759969770e-01
    x_17_1    unique_nonzero_owner_298  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_1    product_lb_90  1
    w_17_1    product_ub_91  1
    w_17_1    normalized_mass_17_123  1
    w_17_1    normalized_ratio_17_124  -1.1111111111111110e-01
    w_17_1    full_original_Gini_262  -8.2047619047619040e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_2    OBJ       3.5211280499905531e-02
    x_17_2    product_lb_92  -4.4361511107937186e-02
    x_17_2    product_ub_93  -1.1272141706935590e-01
    x_17_2    onehot_17_122  1
    x_17_2    stock_lb_202  2
    x_17_2    stock_ub_203  2
    x_17_2    parent_nonstrict_scope_204  9.8591585399735490e-02
    x_17_2    unique_nonzero_owner_299  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_2    product_lb_92  1
    w_17_2    product_ub_93  1
    w_17_2    normalized_mass_17_123  1
    w_17_2    normalized_ratio_17_124  -2.2222222222222221e-01
    w_17_2    full_original_Gini_262  -7.5380952380952380e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_3    OBJ       2.1126768299943324e-02
    x_17_3    product_lb_94  -4.4361511107937186e-02
    x_17_3    product_ub_95  -1.1272141706935590e-01
    x_17_3    onehot_17_122  1
    x_17_3    stock_lb_202  3
    x_17_3    stock_ub_203  3
    x_17_3    parent_nonstrict_scope_204  8.4507073199773283e-02
    MARKER    'MARKER'                 'INTEND'
    w_17_3    product_lb_94  1
    w_17_3    product_ub_95  1
    w_17_3    normalized_mass_17_123  1
    w_17_3    normalized_ratio_17_124  -3.3333333333333331e-01
    w_17_3    full_original_Gini_262  -6.8714285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_4    OBJ       7.0422560999811035e-03
    x_17_4    product_lb_96  -4.4361511107937186e-02
    x_17_4    product_ub_97  -1.1272141706935590e-01
    x_17_4    onehot_17_122  1
    x_17_4    stock_lb_202  4
    x_17_4    stock_ub_203  4
    x_17_4    parent_nonstrict_scope_204  7.0422560999811062e-02
    x_17_4    unique_nonzero_owner_300  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_4    product_lb_96  1
    w_17_4    product_ub_97  1
    w_17_4    normalized_mass_17_123  1
    w_17_4    normalized_ratio_17_124  -4.4444444444444442e-01
    w_17_4    full_original_Gini_262  -6.2365079365079366e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_5    OBJ       -0.00704225609998111
    x_17_5    product_lb_98  -4.4361511107937186e-02
    x_17_5    product_ub_99  -1.1272141706935590e-01
    x_17_5    onehot_17_122  1
    x_17_5    stock_lb_202  5
    x_17_5    stock_ub_203  5
    x_17_5    parent_nonstrict_scope_204  5.6338048799848849e-02
    x_17_5    unique_nonzero_owner_301  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_5    product_lb_98  1
    w_17_5    product_ub_99  1
    w_17_5    normalized_mass_17_123  1
    w_17_5    normalized_ratio_17_124  -5.5555555555555558e-01
    w_17_5    full_original_Gini_262  -5.7920634920634919e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_6    OBJ       -2.1126768299943317e-02
    x_17_6    product_lb_100  -4.4361511107937186e-02
    x_17_6    product_ub_101  -1.1272141706935590e-01
    x_17_6    onehot_17_122  1
    x_17_6    stock_lb_202  6
    x_17_6    stock_ub_203  6
    x_17_6    parent_nonstrict_scope_204  4.2253536599886642e-02
    x_17_6    unique_nonzero_owner_302  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_6    product_lb_100  1
    w_17_6    product_ub_101  1
    w_17_6    normalized_mass_17_123  1
    w_17_6    normalized_ratio_17_124  -6.6666666666666663e-01
    w_17_6    full_original_Gini_262  -5.3476190476190482e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_7    OBJ       -3.5211280499905517e-02
    x_17_7    product_lb_102  -4.4361511107937186e-02
    x_17_7    product_ub_103  -1.1272141706935590e-01
    x_17_7    onehot_17_122  1
    x_17_7    stock_lb_202  7
    x_17_7    stock_ub_203  7
    x_17_7    parent_nonstrict_scope_204  2.8169024399924438e-02
    x_17_7    unique_nonzero_owner_303  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_7    product_lb_102  1
    w_17_7    product_ub_103  1
    w_17_7    normalized_mass_17_123  1
    w_17_7    normalized_ratio_17_124  -7.7777777777777768e-01
    w_17_7    full_original_Gini_262  -4.9031746031746035e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_8    OBJ       -4.9295792699867738e-02
    x_17_8    product_lb_104  -4.4361511107937186e-02
    x_17_8    product_ub_105  -1.1272141706935590e-01
    x_17_8    onehot_17_122  1
    x_17_8    stock_lb_202  8
    x_17_8    stock_ub_203  8
    x_17_8    parent_nonstrict_scope_204  1.4084512199962219e-02
    x_17_8    unique_nonzero_owner_304  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_8    product_lb_104  1
    w_17_8    product_ub_105  1
    w_17_8    normalized_mass_17_123  1
    w_17_8    normalized_ratio_17_124  -8.8888888888888884e-01
    w_17_8    full_original_Gini_262  -4.6365079365079360e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_9    OBJ       -6.3380304899829959e-02
    x_17_9    product_lb_106  -4.4361511107937186e-02
    x_17_9    product_ub_107  -1.1272141706935590e-01
    x_17_9    onehot_17_122  1
    x_17_9    stock_lb_202  9
    x_17_9    stock_ub_203  9
    x_17_9    unique_nonzero_owner_305  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_9    product_lb_106  1
    w_17_9    product_ub_107  1
    w_17_9    normalized_mass_17_123  1
    w_17_9    normalized_ratio_17_124  -1
    w_17_9    full_original_Gini_262  -4.4142857142857146e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_10   OBJ       -4.9295792699867738e-02
    x_17_10   product_lb_108  -4.4361511107937186e-02
    x_17_10   product_ub_109  -1.1272141706935590e-01
    x_17_10   onehot_17_122  1
    x_17_10   stock_lb_202  10
    x_17_10   stock_ub_203  10
    x_17_10   parent_nonstrict_scope_204  1.4084512199962219e-02
    x_17_10   unique_nonzero_owner_306  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_10   product_lb_108  1
    w_17_10   product_ub_109  1
    w_17_10   normalized_mass_17_123  1
    w_17_10   normalized_ratio_17_124  -1.1111111111111112e+00
    w_17_10   full_original_Gini_262  -5.3031746031746039e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_11   OBJ       -3.5211280499905545e-02
    x_17_11   product_lb_110  -4.4361511107937186e-02
    x_17_11   product_ub_111  -1.1272141706935590e-01
    x_17_11   onehot_17_122  1
    x_17_11   stock_lb_202  11
    x_17_11   stock_ub_203  11
    x_17_11   parent_nonstrict_scope_204  2.8169024399924410e-02
    x_17_11   unique_nonzero_owner_307  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_11   product_lb_110  1
    w_17_11   product_ub_111  1
    w_17_11   normalized_mass_17_123  1
    w_17_11   normalized_ratio_17_124  -1.2222222222222221e+00
    w_17_11   full_original_Gini_262  -6.35079365079365
    MARKER    'MARKER'                 'INTORG'
    x_17_12   OBJ       -2.1126768299943331e-02
    x_17_12   product_lb_112  -4.4361511107937186e-02
    x_17_12   product_ub_113  -1.1272141706935590e-01
    x_17_12   onehot_17_122  1
    x_17_12   stock_lb_202  12
    x_17_12   stock_ub_203  12
    x_17_12   parent_nonstrict_scope_204  4.2253536599886628e-02
    x_17_12   unique_nonzero_owner_308  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_12   product_lb_112  1
    w_17_12   product_ub_113  1
    w_17_12   normalized_mass_17_123  1
    w_17_12   normalized_ratio_17_124  -1.3333333333333333e+00
    w_17_12   full_original_Gini_262  -7.46190476190476
    MARKER    'MARKER'                 'INTORG'
    x_17_13   OBJ       -0.00704225609998111
    x_17_13   product_lb_114  -4.4361511107937186e-02
    x_17_13   product_ub_115  -1.1272141706935590e-01
    x_17_13   onehot_17_122  1
    x_17_13   stock_lb_202  13
    x_17_13   stock_ub_203  13
    x_17_13   parent_nonstrict_scope_204  5.6338048799848849e-02
    x_17_13   unique_nonzero_owner_309  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_13   product_lb_114  1
    w_17_13   product_ub_115  1
    w_17_13   normalized_mass_17_123  1
    w_17_13   normalized_ratio_17_124  -1.4444444444444444e+00
    w_17_13   full_original_Gini_262  -8.5730158730158728e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_14   OBJ       7.0422560999810757e-03
    x_17_14   product_lb_116  -4.4361511107937186e-02
    x_17_14   product_ub_117  -1.1272141706935590e-01
    x_17_14   onehot_17_122  1
    x_17_14   stock_lb_202  14
    x_17_14   stock_ub_203  14
    x_17_14   parent_nonstrict_scope_204  7.0422560999811035e-02
    x_17_14   unique_nonzero_owner_310  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_14   product_lb_116  1
    w_17_14   product_ub_117  1
    w_17_14   normalized_mass_17_123  1
    w_17_14   normalized_ratio_17_124  -1.5555555555555554e+00
    w_17_14   full_original_Gini_262  -9.7952380952380924e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_15   OBJ       2.1126768299943297e-02
    x_17_15   product_lb_118  -4.4361511107937186e-02
    x_17_15   product_ub_119  -1.1272141706935590e-01
    x_17_15   onehot_17_122  1
    x_17_15   stock_lb_202  15
    x_17_15   stock_ub_203  15
    x_17_15   parent_nonstrict_scope_204  8.4507073199773255e-02
    x_17_15   unique_nonzero_owner_311  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_15   product_lb_118  1
    w_17_15   product_ub_119  1
    w_17_15   normalized_mass_17_123  1
    w_17_15   normalized_ratio_17_124  -1.6666666666666665e+00
    w_17_15   full_original_Gini_262  -1.1128571428571425e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_16   OBJ       3.5211280499905517e-02
    x_17_16   product_lb_120  -4.4361511107937186e-02
    x_17_16   product_ub_121  -1.1272141706935590e-01
    x_17_16   onehot_17_122  1
    x_17_16   stock_lb_202  16
    x_17_16   stock_ub_203  16
    x_17_16   parent_nonstrict_scope_204  9.8591585399735476e-02
    x_17_16   unique_nonzero_owner_312  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_16   product_lb_120  1
    w_17_16   product_ub_121  1
    w_17_16   normalized_mass_17_123  1
    w_17_16   normalized_ratio_17_124  -1.7777777777777777e+00
    w_17_16   full_original_Gini_262  -1.2461904761904762e+01
    rho_17    normalized_ratio_17_124  1
    rho_17    block_pair_pos_211  1
    rho_17    block_pair_neg_212  -1
    rho_17    block_pair_pos_227  1
    rho_17    block_pair_neg_228  -1
    rho_17    block_pair_pos_239  1
    rho_17    block_pair_neg_240  -1
    rho_17    block_pair_pos_245  -1
    rho_17    block_pair_neg_246  1
    rho_17    block_pair_pos_247  -1
    rho_17    block_pair_neg_248  1
    rho_17    block_pair_pos_249  -1
    rho_17    block_pair_neg_250  1
    rho_17    block_pair_pos_259  1
    rho_17    block_pair_neg_260  -1
    rho_17    normalization_261  1
    MARKER    'MARKER'                 'INTORG'
    x_4_0     OBJ       5.0078236648368350e-02
    x_4_0     product_lb_125  -4.4361511107937186e-02
    x_4_0     product_ub_126  -1.1272141706935590e-01
    x_4_0     onehot_4_157  1
    x_4_0     parent_nonstrict_scope_204  1.0015647329673670e-01
    x_4_0     unique_nonzero_owner_313  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_0     product_lb_125  1
    w_4_0     product_ub_126  1
    w_4_0     normalized_mass_4_158  1
    w_4_0     full_original_Gini_262  -8.8714285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_1     OBJ       3.7558677486276261e-02
    x_4_1     product_lb_127  -4.4361511107937186e-02
    x_4_1     product_ub_128  -1.1272141706935590e-01
    x_4_1     onehot_4_157  1
    x_4_1     stock_lb_202  1
    x_4_1     stock_ub_203  1
    x_4_1     parent_nonstrict_scope_204  8.7636914134644611e-02
    x_4_1     unique_nonzero_owner_314  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_1     product_lb_127  1
    w_4_1     product_ub_128  1
    w_4_1     normalized_mass_4_158  1
    w_4_1     normalized_ratio_4_159  -0.125
    w_4_1     full_original_Gini_262  -8.1214285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_2     OBJ       2.5039118324184172e-02
    x_4_2     product_lb_129  -4.4361511107937186e-02
    x_4_2     product_ub_130  -1.1272141706935590e-01
    x_4_2     onehot_4_157  1
    x_4_2     stock_lb_202  2
    x_4_2     stock_ub_203  2
    x_4_2     parent_nonstrict_scope_204  7.5117354972552522e-02
    x_4_2     unique_nonzero_owner_315  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_2     product_lb_129  1
    w_4_2     product_ub_130  1
    w_4_2     normalized_mass_4_158  1
    w_4_2     normalized_ratio_4_159  -0.25
    w_4_2     full_original_Gini_262  -7.3714285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_3     OBJ       1.2519559162092082e-02
    x_4_3     product_lb_131  -4.4361511107937186e-02
    x_4_3     product_ub_132  -1.1272141706935590e-01
    x_4_3     onehot_4_157  1
    x_4_3     stock_lb_202  3
    x_4_3     stock_ub_203  3
    x_4_3     parent_nonstrict_scope_204  6.2597795810460433e-02
    x_4_3     unique_nonzero_owner_316  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_3     product_lb_131  1
    w_4_3     product_ub_132  1
    w_4_3     normalized_mass_4_158  1
    w_4_3     normalized_ratio_4_159  -0.375
    w_4_3     full_original_Gini_262  -6.6214285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_4     product_lb_133  -4.4361511107937186e-02
    x_4_4     product_ub_134  -1.1272141706935590e-01
    x_4_4     onehot_4_157  1
    x_4_4     stock_lb_202  4
    x_4_4     stock_ub_203  4
    x_4_4     parent_nonstrict_scope_204  5.0078236648368350e-02
    x_4_4     unique_nonzero_owner_317  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_4     product_lb_133  1
    w_4_4     product_ub_134  1
    w_4_4     normalized_mass_4_158  1
    w_4_4     normalized_ratio_4_159  -0.5
    w_4_4     full_original_Gini_262  -6.0142857142857142e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_5     OBJ       -1.2519559162092089e-02
    x_4_5     product_lb_135  -4.4361511107937186e-02
    x_4_5     product_ub_136  -1.1272141706935590e-01
    x_4_5     onehot_4_157  1
    x_4_5     stock_lb_202  5
    x_4_5     stock_ub_203  5
    x_4_5     parent_nonstrict_scope_204  3.7558677486276261e-02
    x_4_5     unique_nonzero_owner_318  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_5     product_lb_135  1
    w_4_5     product_ub_136  1
    w_4_5     normalized_mass_4_158  1
    w_4_5     normalized_ratio_4_159  -0.625
    w_4_5     full_original_Gini_262  -5.5142857142857142e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_6     OBJ       -2.5039118324184175e-02
    x_4_6     product_lb_137  -4.4361511107937186e-02
    x_4_6     product_ub_138  -1.1272141706935590e-01
    x_4_6     onehot_4_157  1
    x_4_6     stock_lb_202  6
    x_4_6     stock_ub_203  6
    x_4_6     parent_nonstrict_scope_204  2.5039118324184175e-02
    x_4_6     unique_nonzero_owner_319  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_6     product_lb_137  1
    w_4_6     product_ub_138  1
    w_4_6     normalized_mass_4_158  1
    w_4_6     normalized_ratio_4_159  -0.75
    w_4_6     full_original_Gini_262  -5.0142857142857142e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_7     OBJ       -3.7558677486276261e-02
    x_4_7     product_lb_139  -4.4361511107937186e-02
    x_4_7     product_ub_140  -1.1272141706935590e-01
    x_4_7     onehot_4_157  1
    x_4_7     stock_lb_202  7
    x_4_7     stock_ub_203  7
    x_4_7     parent_nonstrict_scope_204  1.2519559162092088e-02
    x_4_7     unique_nonzero_owner_320  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_7     product_lb_139  1
    w_4_7     product_ub_140  1
    w_4_7     normalized_mass_4_158  1
    w_4_7     normalized_ratio_4_159  -0.875
    w_4_7     full_original_Gini_262  -4.6642857142857146e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_8     OBJ       -5.0078236648368350e-02
    x_4_8     product_lb_141  -4.4361511107937186e-02
    x_4_8     product_ub_142  -1.1272141706935590e-01
    x_4_8     onehot_4_157  1
    x_4_8     stock_lb_202  8
    x_4_8     stock_ub_203  8
    x_4_8     unique_nonzero_owner_321  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_8     product_lb_141  1
    w_4_8     product_ub_142  1
    w_4_8     normalized_mass_4_158  1
    w_4_8     normalized_ratio_4_159  -1
    w_4_8     full_original_Gini_262  -4.4142857142857146e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_9     OBJ       -3.7558677486276261e-02
    x_4_9     product_lb_143  -4.4361511107937186e-02
    x_4_9     product_ub_144  -1.1272141706935590e-01
    x_4_9     onehot_4_157  1
    x_4_9     stock_lb_202  9
    x_4_9     stock_ub_203  9
    x_4_9     parent_nonstrict_scope_204  1.2519559162092088e-02
    x_4_9     unique_nonzero_owner_322  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_9     product_lb_143  1
    w_4_9     product_ub_144  1
    w_4_9     normalized_mass_4_158  1
    w_4_9     normalized_ratio_4_159  -1.125
    w_4_9     full_original_Gini_262  -5.4142857142857146e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_10    OBJ       -2.5039118324184175e-02
    x_4_10    product_lb_145  -4.4361511107937186e-02
    x_4_10    product_ub_146  -1.1272141706935590e-01
    x_4_10    onehot_4_157  1
    x_4_10    stock_lb_202  10
    x_4_10    stock_ub_203  10
    x_4_10    parent_nonstrict_scope_204  2.5039118324184175e-02
    x_4_10    unique_nonzero_owner_323  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_10    product_lb_145  1
    w_4_10    product_ub_146  1
    w_4_10    normalized_mass_4_158  1
    w_4_10    normalized_ratio_4_159  -1.25
    w_4_10    full_original_Gini_262  -6.6285714285714281e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_11    OBJ       -1.2519559162092089e-02
    x_4_11    product_lb_147  -4.4361511107937186e-02
    x_4_11    product_ub_148  -1.1272141706935590e-01
    x_4_11    onehot_4_157  1
    x_4_11    stock_lb_202  11
    x_4_11    stock_ub_203  11
    x_4_11    parent_nonstrict_scope_204  3.7558677486276261e-02
    x_4_11    unique_nonzero_owner_324  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_11    product_lb_147  1
    w_4_11    product_ub_148  1
    w_4_11    normalized_mass_4_158  1
    w_4_11    normalized_ratio_4_159  -1.375
    w_4_11    full_original_Gini_262  -7.8785714285714281e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_12    product_lb_149  -4.4361511107937186e-02
    x_4_12    product_ub_150  -1.1272141706935590e-01
    x_4_12    onehot_4_157  1
    x_4_12    stock_lb_202  12
    x_4_12    stock_ub_203  12
    x_4_12    parent_nonstrict_scope_204  5.0078236648368350e-02
    MARKER    'MARKER'                 'INTEND'
    w_4_12    product_lb_149  1
    w_4_12    product_ub_150  1
    w_4_12    normalized_mass_4_158  1
    w_4_12    normalized_ratio_4_159  -1.5
    w_4_12    full_original_Gini_262  -9.1285714285714281e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_13    OBJ       1.2519559162092082e-02
    x_4_13    product_lb_151  -4.4361511107937186e-02
    x_4_13    product_ub_152  -1.1272141706935590e-01
    x_4_13    onehot_4_157  1
    x_4_13    stock_lb_202  13
    x_4_13    stock_ub_203  13
    x_4_13    parent_nonstrict_scope_204  6.2597795810460433e-02
    x_4_13    unique_nonzero_owner_325  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_13    product_lb_151  1
    w_4_13    product_ub_152  1
    w_4_13    normalized_mass_4_158  1
    w_4_13    normalized_ratio_4_159  -1.625
    w_4_13    full_original_Gini_262  -1.0628571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_14    OBJ       2.5039118324184172e-02
    x_4_14    product_lb_153  -4.4361511107937186e-02
    x_4_14    product_ub_154  -1.1272141706935590e-01
    x_4_14    onehot_4_157  1
    x_4_14    stock_lb_202  14
    x_4_14    stock_ub_203  14
    x_4_14    parent_nonstrict_scope_204  7.5117354972552522e-02
    x_4_14    unique_nonzero_owner_326  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_14    product_lb_153  1
    w_4_14    product_ub_154  1
    w_4_14    normalized_mass_4_158  1
    w_4_14    normalized_ratio_4_159  -1.75
    w_4_14    full_original_Gini_262  -1.2128571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_15    OBJ       3.7558677486276261e-02
    x_4_15    product_lb_155  -4.4361511107937186e-02
    x_4_15    product_ub_156  -1.1272141706935590e-01
    x_4_15    onehot_4_157  1
    x_4_15    stock_lb_202  15
    x_4_15    stock_ub_203  15
    x_4_15    parent_nonstrict_scope_204  8.7636914134644611e-02
    x_4_15    unique_nonzero_owner_327  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_15    product_lb_155  1
    w_4_15    product_ub_156  1
    w_4_15    normalized_mass_4_158  1
    w_4_15    normalized_ratio_4_159  -1.875
    w_4_15    full_original_Gini_262  -1.3628571428571428e+01
    rho_4     normalized_ratio_4_159  1
    rho_4     block_pair_pos_207  1
    rho_4     block_pair_neg_208  -1
    rho_4     block_pair_pos_213  -1
    rho_4     block_pair_neg_214  1
    rho_4     block_pair_pos_215  -1
    rho_4     block_pair_neg_216  1
    rho_4     block_pair_pos_221  1
    rho_4     block_pair_neg_222  -1
    rho_4     block_pair_pos_235  1
    rho_4     block_pair_neg_236  -1
    rho_4     block_pair_pos_247  1
    rho_4     block_pair_neg_248  -1
    rho_4     block_pair_pos_255  1
    rho_4     block_pair_neg_256  -1
    rho_4     normalization_261  1
    MARKER    'MARKER'                 'INTORG'
    x_11_0    OBJ       5.0078236648368350e-02
    x_11_0    product_lb_160  -4.4361511107937186e-02
    x_11_0    product_ub_161  -1.1272141706935590e-01
    x_11_0    onehot_11_192  1
    x_11_0    parent_nonstrict_scope_204  1.0015647329673670e-01
    x_11_0    unique_nonzero_owner_328  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_0    product_lb_160  1
    w_11_0    product_ub_161  1
    w_11_0    normalized_mass_11_193  1
    w_11_0    full_original_Gini_262  -8.8714285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_1    OBJ       3.7558677486276261e-02
    x_11_1    product_lb_162  -4.4361511107937186e-02
    x_11_1    product_ub_163  -1.1272141706935590e-01
    x_11_1    onehot_11_192  1
    x_11_1    stock_lb_202  1
    x_11_1    stock_ub_203  1
    x_11_1    parent_nonstrict_scope_204  8.7636914134644611e-02
    MARKER    'MARKER'                 'INTEND'
    w_11_1    product_lb_162  1
    w_11_1    product_ub_163  1
    w_11_1    normalized_mass_11_193  1
    w_11_1    normalized_ratio_11_194  -0.125
    w_11_1    full_original_Gini_262  -8.1214285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_2    OBJ       2.5039118324184172e-02
    x_11_2    product_lb_164  -4.4361511107937186e-02
    x_11_2    product_ub_165  -1.1272141706935590e-01
    x_11_2    onehot_11_192  1
    x_11_2    stock_lb_202  2
    x_11_2    stock_ub_203  2
    x_11_2    parent_nonstrict_scope_204  7.5117354972552522e-02
    x_11_2    unique_nonzero_owner_329  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_2    product_lb_164  1
    w_11_2    product_ub_165  1
    w_11_2    normalized_mass_11_193  1
    w_11_2    normalized_ratio_11_194  -0.25
    w_11_2    full_original_Gini_262  -7.3714285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_3    OBJ       1.2519559162092082e-02
    x_11_3    product_lb_166  -4.4361511107937186e-02
    x_11_3    product_ub_167  -1.1272141706935590e-01
    x_11_3    onehot_11_192  1
    x_11_3    stock_lb_202  3
    x_11_3    stock_ub_203  3
    x_11_3    parent_nonstrict_scope_204  6.2597795810460433e-02
    x_11_3    unique_nonzero_owner_330  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_3    product_lb_166  1
    w_11_3    product_ub_167  1
    w_11_3    normalized_mass_11_193  1
    w_11_3    normalized_ratio_11_194  -0.375
    w_11_3    full_original_Gini_262  -6.6214285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_4    product_lb_168  -4.4361511107937186e-02
    x_11_4    product_ub_169  -1.1272141706935590e-01
    x_11_4    onehot_11_192  1
    x_11_4    stock_lb_202  4
    x_11_4    stock_ub_203  4
    x_11_4    parent_nonstrict_scope_204  5.0078236648368350e-02
    x_11_4    unique_nonzero_owner_331  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_4    product_lb_168  1
    w_11_4    product_ub_169  1
    w_11_4    normalized_mass_11_193  1
    w_11_4    normalized_ratio_11_194  -0.5
    w_11_4    full_original_Gini_262  -6.0142857142857142e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_5    OBJ       -1.2519559162092089e-02
    x_11_5    product_lb_170  -4.4361511107937186e-02
    x_11_5    product_ub_171  -1.1272141706935590e-01
    x_11_5    onehot_11_192  1
    x_11_5    stock_lb_202  5
    x_11_5    stock_ub_203  5
    x_11_5    parent_nonstrict_scope_204  3.7558677486276261e-02
    x_11_5    unique_nonzero_owner_332  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_5    product_lb_170  1
    w_11_5    product_ub_171  1
    w_11_5    normalized_mass_11_193  1
    w_11_5    normalized_ratio_11_194  -0.625
    w_11_5    full_original_Gini_262  -5.5142857142857142e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_6    OBJ       -2.5039118324184175e-02
    x_11_6    product_lb_172  -4.4361511107937186e-02
    x_11_6    product_ub_173  -1.1272141706935590e-01
    x_11_6    onehot_11_192  1
    x_11_6    stock_lb_202  6
    x_11_6    stock_ub_203  6
    x_11_6    parent_nonstrict_scope_204  2.5039118324184175e-02
    x_11_6    unique_nonzero_owner_333  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_6    product_lb_172  1
    w_11_6    product_ub_173  1
    w_11_6    normalized_mass_11_193  1
    w_11_6    normalized_ratio_11_194  -0.75
    w_11_6    full_original_Gini_262  -5.0142857142857142e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_7    OBJ       -3.7558677486276261e-02
    x_11_7    product_lb_174  -4.4361511107937186e-02
    x_11_7    product_ub_175  -1.1272141706935590e-01
    x_11_7    onehot_11_192  1
    x_11_7    stock_lb_202  7
    x_11_7    stock_ub_203  7
    x_11_7    parent_nonstrict_scope_204  1.2519559162092088e-02
    x_11_7    unique_nonzero_owner_334  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_7    product_lb_174  1
    w_11_7    product_ub_175  1
    w_11_7    normalized_mass_11_193  1
    w_11_7    normalized_ratio_11_194  -0.875
    w_11_7    full_original_Gini_262  -4.6642857142857146e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_8    OBJ       -5.0078236648368350e-02
    x_11_8    product_lb_176  -4.4361511107937186e-02
    x_11_8    product_ub_177  -1.1272141706935590e-01
    x_11_8    onehot_11_192  1
    x_11_8    stock_lb_202  8
    x_11_8    stock_ub_203  8
    x_11_8    unique_nonzero_owner_335  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_8    product_lb_176  1
    w_11_8    product_ub_177  1
    w_11_8    normalized_mass_11_193  1
    w_11_8    normalized_ratio_11_194  -1
    w_11_8    full_original_Gini_262  -4.4142857142857146e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_9    OBJ       -3.7558677486276261e-02
    x_11_9    product_lb_178  -4.4361511107937186e-02
    x_11_9    product_ub_179  -1.1272141706935590e-01
    x_11_9    onehot_11_192  1
    x_11_9    stock_lb_202  9
    x_11_9    stock_ub_203  9
    x_11_9    parent_nonstrict_scope_204  1.2519559162092088e-02
    x_11_9    unique_nonzero_owner_336  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_9    product_lb_178  1
    w_11_9    product_ub_179  1
    w_11_9    normalized_mass_11_193  1
    w_11_9    normalized_ratio_11_194  -1.125
    w_11_9    full_original_Gini_262  -5.4142857142857146e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_10   OBJ       -2.5039118324184175e-02
    x_11_10   product_lb_180  -4.4361511107937186e-02
    x_11_10   product_ub_181  -1.1272141706935590e-01
    x_11_10   onehot_11_192  1
    x_11_10   stock_lb_202  10
    x_11_10   stock_ub_203  10
    x_11_10   parent_nonstrict_scope_204  2.5039118324184175e-02
    x_11_10   unique_nonzero_owner_337  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_10   product_lb_180  1
    w_11_10   product_ub_181  1
    w_11_10   normalized_mass_11_193  1
    w_11_10   normalized_ratio_11_194  -1.25
    w_11_10   full_original_Gini_262  -6.6285714285714281e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_11   OBJ       -1.2519559162092089e-02
    x_11_11   product_lb_182  -4.4361511107937186e-02
    x_11_11   product_ub_183  -1.1272141706935590e-01
    x_11_11   onehot_11_192  1
    x_11_11   stock_lb_202  11
    x_11_11   stock_ub_203  11
    x_11_11   parent_nonstrict_scope_204  3.7558677486276261e-02
    x_11_11   unique_nonzero_owner_338  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_11   product_lb_182  1
    w_11_11   product_ub_183  1
    w_11_11   normalized_mass_11_193  1
    w_11_11   normalized_ratio_11_194  -1.375
    w_11_11   full_original_Gini_262  -7.8785714285714281e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_12   product_lb_184  -4.4361511107937186e-02
    x_11_12   product_ub_185  -1.1272141706935590e-01
    x_11_12   onehot_11_192  1
    x_11_12   stock_lb_202  12
    x_11_12   stock_ub_203  12
    x_11_12   parent_nonstrict_scope_204  5.0078236648368350e-02
    x_11_12   unique_nonzero_owner_339  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_12   product_lb_184  1
    w_11_12   product_ub_185  1
    w_11_12   normalized_mass_11_193  1
    w_11_12   normalized_ratio_11_194  -1.5
    w_11_12   full_original_Gini_262  -9.1285714285714281e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_13   OBJ       1.2519559162092082e-02
    x_11_13   product_lb_186  -4.4361511107937186e-02
    x_11_13   product_ub_187  -1.1272141706935590e-01
    x_11_13   onehot_11_192  1
    x_11_13   stock_lb_202  13
    x_11_13   stock_ub_203  13
    x_11_13   parent_nonstrict_scope_204  6.2597795810460433e-02
    x_11_13   unique_nonzero_owner_340  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_13   product_lb_186  1
    w_11_13   product_ub_187  1
    w_11_13   normalized_mass_11_193  1
    w_11_13   normalized_ratio_11_194  -1.625
    w_11_13   full_original_Gini_262  -1.0628571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_14   OBJ       2.5039118324184172e-02
    x_11_14   product_lb_188  -4.4361511107937186e-02
    x_11_14   product_ub_189  -1.1272141706935590e-01
    x_11_14   onehot_11_192  1
    x_11_14   stock_lb_202  14
    x_11_14   stock_ub_203  14
    x_11_14   parent_nonstrict_scope_204  7.5117354972552522e-02
    x_11_14   unique_nonzero_owner_341  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_14   product_lb_188  1
    w_11_14   product_ub_189  1
    w_11_14   normalized_mass_11_193  1
    w_11_14   normalized_ratio_11_194  -1.75
    w_11_14   full_original_Gini_262  -1.2128571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_15   OBJ       3.7558677486276261e-02
    x_11_15   product_lb_190  -4.4361511107937186e-02
    x_11_15   product_ub_191  -1.1272141706935590e-01
    x_11_15   onehot_11_192  1
    x_11_15   stock_lb_202  15
    x_11_15   stock_ub_203  15
    x_11_15   parent_nonstrict_scope_204  8.7636914134644611e-02
    x_11_15   unique_nonzero_owner_342  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_15   product_lb_190  1
    w_11_15   product_ub_191  1
    w_11_15   normalized_mass_11_193  1
    w_11_15   normalized_ratio_11_194  -1.875
    w_11_15   full_original_Gini_262  -1.3628571428571428e+01
    rho_11    normalized_ratio_11_194  1
    rho_11    block_pair_pos_209  1
    rho_11    block_pair_neg_210  -1
    rho_11    block_pair_pos_215  1
    rho_11    block_pair_neg_216  -1
    rho_11    block_pair_pos_225  1
    rho_11    block_pair_neg_226  -1
    rho_11    block_pair_pos_237  1
    rho_11    block_pair_neg_238  -1
    rho_11    block_pair_pos_243  -1
    rho_11    block_pair_neg_244  1
    rho_11    block_pair_pos_249  1
    rho_11    block_pair_neg_250  -1
    rho_11    block_pair_pos_257  1
    rho_11    block_pair_neg_258  -1
    rho_11    normalization_261  1
    MARKER    'MARKER'                 'INTORG'
    x_2_0     OBJ       6.3380304899829966e-03
    x_2_0     product_lb_195  -4.4361511107937186e-02
    x_2_0     product_ub_196  -1.1272141706935590e-01
    x_2_0     onehot_2_199  1
    x_2_0     parent_nonstrict_scope_204  1.2676060979965993e-02
    MARKER    'MARKER'                 'INTEND'
    w_2_0     product_lb_195  1
    w_2_0     product_ub_196  1
    w_2_0     normalized_mass_2_200  1
    w_2_0     full_original_Gini_262  -8.8714285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_1     OBJ       -6.3380304899829966e-03
    x_2_1     product_lb_197  -4.4361511107937186e-02
    x_2_1     product_ub_198  -1.1272141706935590e-01
    x_2_1     onehot_2_199  1
    x_2_1     stock_lb_202  1
    x_2_1     stock_ub_203  1
    x_2_1     unique_nonzero_owner_343  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_1     product_lb_197  1
    w_2_1     product_ub_198  1
    w_2_1     normalized_mass_2_200  1
    w_2_1     normalized_ratio_2_201  -1
    w_2_1     full_original_Gini_262  -4.4142857142857146e+00
    rho_2     normalized_ratio_2_201  1
    rho_2     block_pair_pos_205  1
    rho_2     block_pair_neg_206  -1
    rho_2     block_pair_pos_213  1
    rho_2     block_pair_neg_214  -1
    rho_2     block_pair_pos_217  1
    rho_2     block_pair_neg_218  -1
    rho_2     block_pair_pos_231  1
    rho_2     block_pair_neg_232  -1
    rho_2     block_pair_pos_243  1
    rho_2     block_pair_neg_244  -1
    rho_2     block_pair_pos_245  1
    rho_2     block_pair_neg_246  -1
    rho_2     block_pair_pos_251  1
    rho_2     block_pair_neg_252  -1
    rho_2     normalization_261  1
    a_5_6     block_pair_pos_223  1
    a_5_6     block_pair_neg_224  1
    a_5_6     full_original_Gini_262  -1
    a_5_18    block_pair_pos_229  1
    a_5_18    block_pair_neg_230  1
    a_5_18    full_original_Gini_262  -1
    a_5_3     block_pair_pos_219  1
    a_5_3     block_pair_neg_220  1
    a_5_3     full_original_Gini_262  -1
    a_5_17    block_pair_pos_227  1
    a_5_17    block_pair_neg_228  1
    a_5_17    full_original_Gini_262  -1
    a_5_4     block_pair_pos_221  1
    a_5_4     block_pair_neg_222  1
    a_5_4     full_original_Gini_262  -1
    a_5_11    block_pair_pos_225  1
    a_5_11    block_pair_neg_226  1
    a_5_11    full_original_Gini_262  -1
    a_5_2     block_pair_pos_217  1
    a_5_2     block_pair_neg_218  1
    a_5_2     full_original_Gini_262  -1
    a_6_18    block_pair_pos_241  1
    a_6_18    block_pair_neg_242  1
    a_6_18    full_original_Gini_262  -1
    a_6_3     block_pair_pos_233  1
    a_6_3     block_pair_neg_234  1
    a_6_3     full_original_Gini_262  -1
    a_6_17    block_pair_pos_239  1
    a_6_17    block_pair_neg_240  1
    a_6_17    full_original_Gini_262  -1
    a_6_4     block_pair_pos_235  1
    a_6_4     block_pair_neg_236  1
    a_6_4     full_original_Gini_262  -1
    a_6_11    block_pair_pos_237  1
    a_6_11    block_pair_neg_238  1
    a_6_11    full_original_Gini_262  -1
    a_6_2     block_pair_pos_231  1
    a_6_2     block_pair_neg_232  1
    a_6_2     full_original_Gini_262  -1
    a_18_3    block_pair_pos_253  1
    a_18_3    block_pair_neg_254  1
    a_18_3    full_original_Gini_262  -1
    a_18_17   block_pair_pos_259  1
    a_18_17   block_pair_neg_260  1
    a_18_17   full_original_Gini_262  -1
    a_18_4    block_pair_pos_255  1
    a_18_4    block_pair_neg_256  1
    a_18_4    full_original_Gini_262  -1
    a_18_11   block_pair_pos_257  1
    a_18_11   block_pair_neg_258  1
    a_18_11   full_original_Gini_262  -1
    a_18_2    block_pair_pos_251  1
    a_18_2    block_pair_neg_252  1
    a_18_2    full_original_Gini_262  -1
    a_3_17    block_pair_pos_211  1
    a_3_17    block_pair_neg_212  1
    a_3_17    full_original_Gini_262  -1
    a_3_4     block_pair_pos_207  1
    a_3_4     block_pair_neg_208  1
    a_3_4     full_original_Gini_262  -1
    a_3_11    block_pair_pos_209  1
    a_3_11    block_pair_neg_210  1
    a_3_11    full_original_Gini_262  -1
    a_3_2     block_pair_pos_205  1
    a_3_2     block_pair_neg_206  1
    a_3_2     full_original_Gini_262  -1
    a_17_4    block_pair_pos_247  1
    a_17_4    block_pair_neg_248  1
    a_17_4    full_original_Gini_262  -1
    a_17_11   block_pair_pos_249  1
    a_17_11   block_pair_neg_250  1
    a_17_11   full_original_Gini_262  -1
    a_17_2    block_pair_pos_245  1
    a_17_2    block_pair_neg_246  1
    a_17_2    full_original_Gini_262  -1
    a_4_11    block_pair_pos_215  1
    a_4_11    block_pair_neg_216  1
    a_4_11    full_original_Gini_262  -1
    a_4_2     block_pair_pos_213  1
    a_4_2     block_pair_neg_214  1
    a_4_2     full_original_Gini_262  -1
    a_11_2    block_pair_pos_243  1
    a_11_2    block_pair_neg_244  1
    a_11_2    full_original_Gini_262  -1
    MARKER    'MARKER'                 'INTORG'
    service_0_5_1  unique_nonzero_owner_263  1
    service_0_5_1  service_visit_def_724  1
    service_0_5_1  free_load_conservation_725  1
    service_0_5_2  unique_nonzero_owner_264  1
    service_0_5_2  service_visit_def_724  1
    service_0_5_2  free_load_conservation_725  2
    service_1_5_1  unique_nonzero_owner_263  1
    service_1_5_1  service_visit_def_994  1
    service_1_5_1  free_load_conservation_995  1
    service_1_5_2  unique_nonzero_owner_264  1
    service_1_5_2  service_visit_def_994  1
    service_1_5_2  free_load_conservation_995  2
    service_0_6_1  unique_nonzero_owner_265  1
    service_0_6_1  service_visit_def_730  1
    service_0_6_1  free_load_conservation_731  1
    service_1_6_1  unique_nonzero_owner_265  1
    service_1_6_1  service_visit_def_1000  1
    service_1_6_1  free_load_conservation_1001  1
    service_0_18_1  unique_nonzero_owner_266  1
    service_0_18_1  service_visit_def_736  1
    service_0_18_1  free_load_conservation_737  1
    service_0_18_2  unique_nonzero_owner_267  1
    service_0_18_2  service_visit_def_736  1
    service_0_18_2  free_load_conservation_737  2
    service_0_18_3  unique_nonzero_owner_268  1
    service_0_18_3  service_visit_def_736  1
    service_0_18_3  free_load_conservation_737  3
    service_0_18_4  unique_nonzero_owner_269  1
    service_0_18_4  service_visit_def_736  1
    service_0_18_4  free_load_conservation_737  4
    service_0_18_5  unique_nonzero_owner_270  1
    service_0_18_5  service_visit_def_736  1
    service_0_18_5  free_load_conservation_737  5
    service_0_18_6  unique_nonzero_owner_271  1
    service_0_18_6  service_visit_def_736  1
    service_0_18_6  free_load_conservation_737  6
    service_0_18_7  unique_nonzero_owner_272  1
    service_0_18_7  service_visit_def_736  1
    service_0_18_7  free_load_conservation_737  7
    service_0_18_8  unique_nonzero_owner_273  1
    service_0_18_8  service_visit_def_736  1
    service_0_18_8  free_load_conservation_737  8
    service_0_18_9  unique_nonzero_owner_274  1
    service_0_18_9  service_visit_def_736  1
    service_0_18_9  free_load_conservation_737  9
    service_0_18_10  unique_nonzero_owner_275  1
    service_0_18_10  service_visit_def_736  1
    service_0_18_10  free_load_conservation_737  10
    service_0_18_11  unique_nonzero_owner_276  1
    service_0_18_11  service_visit_def_736  1
    service_0_18_11  free_load_conservation_737  11
    service_0_18_12  unique_nonzero_owner_277  1
    service_0_18_12  service_visit_def_736  1
    service_0_18_12  free_load_conservation_737  12
    service_0_18_13  unique_nonzero_owner_278  1
    service_0_18_13  service_visit_def_736  1
    service_0_18_13  free_load_conservation_737  13
    service_0_18_14  unique_nonzero_owner_279  1
    service_0_18_14  service_visit_def_736  1
    service_0_18_14  free_load_conservation_737  14
    service_0_18_15  unique_nonzero_owner_280  1
    service_0_18_15  service_visit_def_736  1
    service_0_18_15  free_load_conservation_737  15
    service_1_18_1  unique_nonzero_owner_266  1
    service_1_18_1  service_visit_def_1006  1
    service_1_18_1  free_load_conservation_1007  1
    service_1_18_2  unique_nonzero_owner_267  1
    service_1_18_2  service_visit_def_1006  1
    service_1_18_2  free_load_conservation_1007  2
    service_1_18_3  unique_nonzero_owner_268  1
    service_1_18_3  service_visit_def_1006  1
    service_1_18_3  free_load_conservation_1007  3
    service_1_18_4  unique_nonzero_owner_269  1
    service_1_18_4  service_visit_def_1006  1
    service_1_18_4  free_load_conservation_1007  4
    service_1_18_5  unique_nonzero_owner_270  1
    service_1_18_5  service_visit_def_1006  1
    service_1_18_5  free_load_conservation_1007  5
    service_1_18_6  unique_nonzero_owner_271  1
    service_1_18_6  service_visit_def_1006  1
    service_1_18_6  free_load_conservation_1007  6
    service_1_18_7  unique_nonzero_owner_272  1
    service_1_18_7  service_visit_def_1006  1
    service_1_18_7  free_load_conservation_1007  7
    service_1_18_8  unique_nonzero_owner_273  1
    service_1_18_8  service_visit_def_1006  1
    service_1_18_8  free_load_conservation_1007  8
    service_1_18_9  unique_nonzero_owner_274  1
    service_1_18_9  service_visit_def_1006  1
    service_1_18_9  free_load_conservation_1007  9
    service_1_18_10  unique_nonzero_owner_275  1
    service_1_18_10  service_visit_def_1006  1
    service_1_18_10  free_load_conservation_1007  10
    service_1_18_11  unique_nonzero_owner_276  1
    service_1_18_11  service_visit_def_1006  1
    service_1_18_11  free_load_conservation_1007  11
    service_1_18_12  unique_nonzero_owner_277  1
    service_1_18_12  service_visit_def_1006  1
    service_1_18_12  free_load_conservation_1007  12
    service_1_18_13  unique_nonzero_owner_278  1
    service_1_18_13  service_visit_def_1006  1
    service_1_18_13  free_load_conservation_1007  13
    service_1_18_14  unique_nonzero_owner_279  1
    service_1_18_14  service_visit_def_1006  1
    service_1_18_14  free_load_conservation_1007  14
    service_1_18_15  unique_nonzero_owner_280  1
    service_1_18_15  service_visit_def_1006  1
    service_1_18_15  free_load_conservation_1007  15
    service_0_3_0  unique_nonzero_owner_281  1
    service_0_3_0  service_visit_def_742  1
    service_0_3_0  free_load_conservation_743  -12
    service_0_3_0  original_T_including_depot_unload_772  1440
    service_0_3_1  unique_nonzero_owner_282  1
    service_0_3_1  service_visit_def_742  1
    service_0_3_1  free_load_conservation_743  -11
    service_0_3_1  original_T_including_depot_unload_772  1320
    service_0_3_2  unique_nonzero_owner_283  1
    service_0_3_2  service_visit_def_742  1
    service_0_3_2  free_load_conservation_743  -10
    service_0_3_2  original_T_including_depot_unload_772  1200
    service_0_3_3  unique_nonzero_owner_284  1
    service_0_3_3  service_visit_def_742  1
    service_0_3_3  free_load_conservation_743  -9
    service_0_3_3  original_T_including_depot_unload_772  1080
    service_0_3_4  unique_nonzero_owner_285  1
    service_0_3_4  service_visit_def_742  1
    service_0_3_4  free_load_conservation_743  -8
    service_0_3_4  original_T_including_depot_unload_772  960
    service_0_3_5  unique_nonzero_owner_286  1
    service_0_3_5  service_visit_def_742  1
    service_0_3_5  free_load_conservation_743  -7
    service_0_3_5  original_T_including_depot_unload_772  840
    service_0_3_6  unique_nonzero_owner_287  1
    service_0_3_6  service_visit_def_742  1
    service_0_3_6  free_load_conservation_743  -6
    service_0_3_6  original_T_including_depot_unload_772  720
    service_0_3_7  unique_nonzero_owner_288  1
    service_0_3_7  service_visit_def_742  1
    service_0_3_7  free_load_conservation_743  -5
    service_0_3_7  original_T_including_depot_unload_772  600
    service_0_3_8  unique_nonzero_owner_289  1
    service_0_3_8  service_visit_def_742  1
    service_0_3_8  free_load_conservation_743  -4
    service_0_3_8  original_T_including_depot_unload_772  480
    service_0_3_9  unique_nonzero_owner_290  1
    service_0_3_9  service_visit_def_742  1
    service_0_3_9  free_load_conservation_743  -3
    service_0_3_9  original_T_including_depot_unload_772  360
    service_0_3_10  unique_nonzero_owner_291  1
    service_0_3_10  service_visit_def_742  1
    service_0_3_10  free_load_conservation_743  -2
    service_0_3_10  original_T_including_depot_unload_772  240
    service_0_3_11  unique_nonzero_owner_292  1
    service_0_3_11  service_visit_def_742  1
    service_0_3_11  free_load_conservation_743  -1
    service_0_3_11  original_T_including_depot_unload_772  120
    service_0_3_13  unique_nonzero_owner_293  1
    service_0_3_13  service_visit_def_742  1
    service_0_3_13  free_load_conservation_743  1
    service_0_3_14  unique_nonzero_owner_294  1
    service_0_3_14  service_visit_def_742  1
    service_0_3_14  free_load_conservation_743  2
    service_0_3_15  unique_nonzero_owner_295  1
    service_0_3_15  service_visit_def_742  1
    service_0_3_15  free_load_conservation_743  3
    service_0_3_16  unique_nonzero_owner_296  1
    service_0_3_16  service_visit_def_742  1
    service_0_3_16  free_load_conservation_743  4
    service_1_3_0  unique_nonzero_owner_281  1
    service_1_3_0  service_visit_def_1012  1
    service_1_3_0  free_load_conservation_1013  -12
    service_1_3_0  original_T_including_depot_unload_1039  1440
    service_1_3_1  unique_nonzero_owner_282  1
    service_1_3_1  service_visit_def_1012  1
    service_1_3_1  free_load_conservation_1013  -11
    service_1_3_1  original_T_including_depot_unload_1039  1320
    service_1_3_2  unique_nonzero_owner_283  1
    service_1_3_2  service_visit_def_1012  1
    service_1_3_2  free_load_conservation_1013  -10
    service_1_3_2  original_T_including_depot_unload_1039  1200
    service_1_3_3  unique_nonzero_owner_284  1
    service_1_3_3  service_visit_def_1012  1
    service_1_3_3  free_load_conservation_1013  -9
    service_1_3_3  original_T_including_depot_unload_1039  1080
    service_1_3_4  unique_nonzero_owner_285  1
    service_1_3_4  service_visit_def_1012  1
    service_1_3_4  free_load_conservation_1013  -8
    service_1_3_4  original_T_including_depot_unload_1039  960
    service_1_3_5  unique_nonzero_owner_286  1
    service_1_3_5  service_visit_def_1012  1
    service_1_3_5  free_load_conservation_1013  -7
    service_1_3_5  original_T_including_depot_unload_1039  840
    service_1_3_6  unique_nonzero_owner_287  1
    service_1_3_6  service_visit_def_1012  1
    service_1_3_6  free_load_conservation_1013  -6
    service_1_3_6  original_T_including_depot_unload_1039  720
    service_1_3_7  unique_nonzero_owner_288  1
    service_1_3_7  service_visit_def_1012  1
    service_1_3_7  free_load_conservation_1013  -5
    service_1_3_7  original_T_including_depot_unload_1039  600
    service_1_3_8  unique_nonzero_owner_289  1
    service_1_3_8  service_visit_def_1012  1
    service_1_3_8  free_load_conservation_1013  -4
    service_1_3_8  original_T_including_depot_unload_1039  480
    service_1_3_9  unique_nonzero_owner_290  1
    service_1_3_9  service_visit_def_1012  1
    service_1_3_9  free_load_conservation_1013  -3
    service_1_3_9  original_T_including_depot_unload_1039  360
    service_1_3_10  unique_nonzero_owner_291  1
    service_1_3_10  service_visit_def_1012  1
    service_1_3_10  free_load_conservation_1013  -2
    service_1_3_10  original_T_including_depot_unload_1039  240
    service_1_3_11  unique_nonzero_owner_292  1
    service_1_3_11  service_visit_def_1012  1
    service_1_3_11  free_load_conservation_1013  -1
    service_1_3_11  original_T_including_depot_unload_1039  120
    service_1_3_13  unique_nonzero_owner_293  1
    service_1_3_13  service_visit_def_1012  1
    service_1_3_13  free_load_conservation_1013  1
    service_1_3_14  unique_nonzero_owner_294  1
    service_1_3_14  service_visit_def_1012  1
    service_1_3_14  free_load_conservation_1013  2
    service_1_3_15  unique_nonzero_owner_295  1
    service_1_3_15  service_visit_def_1012  1
    service_1_3_15  free_load_conservation_1013  3
    service_1_3_16  unique_nonzero_owner_296  1
    service_1_3_16  service_visit_def_1012  1
    service_1_3_16  free_load_conservation_1013  4
    service_0_17_0  unique_nonzero_owner_297  1
    service_0_17_0  service_visit_def_748  1
    service_0_17_0  free_load_conservation_749  -3
    service_0_17_0  original_T_including_depot_unload_772  360
    service_0_17_1  unique_nonzero_owner_298  1
    service_0_17_1  service_visit_def_748  1
    service_0_17_1  free_load_conservation_749  -2
    service_0_17_1  original_T_including_depot_unload_772  240
    service_0_17_2  unique_nonzero_owner_299  1
    service_0_17_2  service_visit_def_748  1
    service_0_17_2  free_load_conservation_749  -1
    service_0_17_2  original_T_including_depot_unload_772  120
    service_0_17_4  unique_nonzero_owner_300  1
    service_0_17_4  service_visit_def_748  1
    service_0_17_4  free_load_conservation_749  1
    service_0_17_5  unique_nonzero_owner_301  1
    service_0_17_5  service_visit_def_748  1
    service_0_17_5  free_load_conservation_749  2
    service_0_17_6  unique_nonzero_owner_302  1
    service_0_17_6  service_visit_def_748  1
    service_0_17_6  free_load_conservation_749  3
    service_0_17_7  unique_nonzero_owner_303  1
    service_0_17_7  service_visit_def_748  1
    service_0_17_7  free_load_conservation_749  4
    service_0_17_8  unique_nonzero_owner_304  1
    service_0_17_8  service_visit_def_748  1
    service_0_17_8  free_load_conservation_749  5
    service_0_17_9  unique_nonzero_owner_305  1
    service_0_17_9  service_visit_def_748  1
    service_0_17_9  free_load_conservation_749  6
    service_0_17_10  unique_nonzero_owner_306  1
    service_0_17_10  service_visit_def_748  1
    service_0_17_10  free_load_conservation_749  7
    service_0_17_11  unique_nonzero_owner_307  1
    service_0_17_11  service_visit_def_748  1
    service_0_17_11  free_load_conservation_749  8
    service_0_17_12  unique_nonzero_owner_308  1
    service_0_17_12  service_visit_def_748  1
    service_0_17_12  free_load_conservation_749  9
    service_0_17_13  unique_nonzero_owner_309  1
    service_0_17_13  service_visit_def_748  1
    service_0_17_13  free_load_conservation_749  10
    service_0_17_14  unique_nonzero_owner_310  1
    service_0_17_14  service_visit_def_748  1
    service_0_17_14  free_load_conservation_749  11
    service_0_17_15  unique_nonzero_owner_311  1
    service_0_17_15  service_visit_def_748  1
    service_0_17_15  free_load_conservation_749  12
    service_0_17_16  unique_nonzero_owner_312  1
    service_0_17_16  service_visit_def_748  1
    service_0_17_16  free_load_conservation_749  13
    service_1_17_0  unique_nonzero_owner_297  1
    service_1_17_0  service_visit_def_1018  1
    service_1_17_0  free_load_conservation_1019  -3
    service_1_17_0  original_T_including_depot_unload_1039  360
    service_1_17_1  unique_nonzero_owner_298  1
    service_1_17_1  service_visit_def_1018  1
    service_1_17_1  free_load_conservation_1019  -2
    service_1_17_1  original_T_including_depot_unload_1039  240
    service_1_17_2  unique_nonzero_owner_299  1
    service_1_17_2  service_visit_def_1018  1
    service_1_17_2  free_load_conservation_1019  -1
    service_1_17_2  original_T_including_depot_unload_1039  120
    service_1_17_4  unique_nonzero_owner_300  1
    service_1_17_4  service_visit_def_1018  1
    service_1_17_4  free_load_conservation_1019  1
    service_1_17_5  unique_nonzero_owner_301  1
    service_1_17_5  service_visit_def_1018  1
    service_1_17_5  free_load_conservation_1019  2
    service_1_17_6  unique_nonzero_owner_302  1
    service_1_17_6  service_visit_def_1018  1
    service_1_17_6  free_load_conservation_1019  3
    service_1_17_7  unique_nonzero_owner_303  1
    service_1_17_7  service_visit_def_1018  1
    service_1_17_7  free_load_conservation_1019  4
    service_1_17_8  unique_nonzero_owner_304  1
    service_1_17_8  service_visit_def_1018  1
    service_1_17_8  free_load_conservation_1019  5
    service_1_17_9  unique_nonzero_owner_305  1
    service_1_17_9  service_visit_def_1018  1
    service_1_17_9  free_load_conservation_1019  6
    service_1_17_10  unique_nonzero_owner_306  1
    service_1_17_10  service_visit_def_1018  1
    service_1_17_10  free_load_conservation_1019  7
    service_1_17_11  unique_nonzero_owner_307  1
    service_1_17_11  service_visit_def_1018  1
    service_1_17_11  free_load_conservation_1019  8
    service_1_17_12  unique_nonzero_owner_308  1
    service_1_17_12  service_visit_def_1018  1
    service_1_17_12  free_load_conservation_1019  9
    service_1_17_13  unique_nonzero_owner_309  1
    service_1_17_13  service_visit_def_1018  1
    service_1_17_13  free_load_conservation_1019  10
    service_1_17_14  unique_nonzero_owner_310  1
    service_1_17_14  service_visit_def_1018  1
    service_1_17_14  free_load_conservation_1019  11
    service_1_17_15  unique_nonzero_owner_311  1
    service_1_17_15  service_visit_def_1018  1
    service_1_17_15  free_load_conservation_1019  12
    service_1_17_16  unique_nonzero_owner_312  1
    service_1_17_16  service_visit_def_1018  1
    service_1_17_16  free_load_conservation_1019  13
    service_0_4_0  unique_nonzero_owner_313  1
    service_0_4_0  service_visit_def_754  1
    service_0_4_0  free_load_conservation_755  -12
    service_0_4_0  original_T_including_depot_unload_772  1440
    service_0_4_1  unique_nonzero_owner_314  1
    service_0_4_1  service_visit_def_754  1
    service_0_4_1  free_load_conservation_755  -11
    service_0_4_1  original_T_including_depot_unload_772  1320
    service_0_4_2  unique_nonzero_owner_315  1
    service_0_4_2  service_visit_def_754  1
    service_0_4_2  free_load_conservation_755  -10
    service_0_4_2  original_T_including_depot_unload_772  1200
    service_0_4_3  unique_nonzero_owner_316  1
    service_0_4_3  service_visit_def_754  1
    service_0_4_3  free_load_conservation_755  -9
    service_0_4_3  original_T_including_depot_unload_772  1080
    service_0_4_4  unique_nonzero_owner_317  1
    service_0_4_4  service_visit_def_754  1
    service_0_4_4  free_load_conservation_755  -8
    service_0_4_4  original_T_including_depot_unload_772  960
    service_0_4_5  unique_nonzero_owner_318  1
    service_0_4_5  service_visit_def_754  1
    service_0_4_5  free_load_conservation_755  -7
    service_0_4_5  original_T_including_depot_unload_772  840
    service_0_4_6  unique_nonzero_owner_319  1
    service_0_4_6  service_visit_def_754  1
    service_0_4_6  free_load_conservation_755  -6
    service_0_4_6  original_T_including_depot_unload_772  720
    service_0_4_7  unique_nonzero_owner_320  1
    service_0_4_7  service_visit_def_754  1
    service_0_4_7  free_load_conservation_755  -5
    service_0_4_7  original_T_including_depot_unload_772  600
    service_0_4_8  unique_nonzero_owner_321  1
    service_0_4_8  service_visit_def_754  1
    service_0_4_8  free_load_conservation_755  -4
    service_0_4_8  original_T_including_depot_unload_772  480
    service_0_4_9  unique_nonzero_owner_322  1
    service_0_4_9  service_visit_def_754  1
    service_0_4_9  free_load_conservation_755  -3
    service_0_4_9  original_T_including_depot_unload_772  360
    service_0_4_10  unique_nonzero_owner_323  1
    service_0_4_10  service_visit_def_754  1
    service_0_4_10  free_load_conservation_755  -2
    service_0_4_10  original_T_including_depot_unload_772  240
    service_0_4_11  unique_nonzero_owner_324  1
    service_0_4_11  service_visit_def_754  1
    service_0_4_11  free_load_conservation_755  -1
    service_0_4_11  original_T_including_depot_unload_772  120
    service_0_4_13  unique_nonzero_owner_325  1
    service_0_4_13  service_visit_def_754  1
    service_0_4_13  free_load_conservation_755  1
    service_0_4_14  unique_nonzero_owner_326  1
    service_0_4_14  service_visit_def_754  1
    service_0_4_14  free_load_conservation_755  2
    service_0_4_15  unique_nonzero_owner_327  1
    service_0_4_15  service_visit_def_754  1
    service_0_4_15  free_load_conservation_755  3
    service_1_4_0  unique_nonzero_owner_313  1
    service_1_4_0  service_visit_def_1024  1
    service_1_4_0  free_load_conservation_1025  -12
    service_1_4_0  original_T_including_depot_unload_1039  1440
    service_1_4_1  unique_nonzero_owner_314  1
    service_1_4_1  service_visit_def_1024  1
    service_1_4_1  free_load_conservation_1025  -11
    service_1_4_1  original_T_including_depot_unload_1039  1320
    service_1_4_2  unique_nonzero_owner_315  1
    service_1_4_2  service_visit_def_1024  1
    service_1_4_2  free_load_conservation_1025  -10
    service_1_4_2  original_T_including_depot_unload_1039  1200
    service_1_4_3  unique_nonzero_owner_316  1
    service_1_4_3  service_visit_def_1024  1
    service_1_4_3  free_load_conservation_1025  -9
    service_1_4_3  original_T_including_depot_unload_1039  1080
    service_1_4_4  unique_nonzero_owner_317  1
    service_1_4_4  service_visit_def_1024  1
    service_1_4_4  free_load_conservation_1025  -8
    service_1_4_4  original_T_including_depot_unload_1039  960
    service_1_4_5  unique_nonzero_owner_318  1
    service_1_4_5  service_visit_def_1024  1
    service_1_4_5  free_load_conservation_1025  -7
    service_1_4_5  original_T_including_depot_unload_1039  840
    service_1_4_6  unique_nonzero_owner_319  1
    service_1_4_6  service_visit_def_1024  1
    service_1_4_6  free_load_conservation_1025  -6
    service_1_4_6  original_T_including_depot_unload_1039  720
    service_1_4_7  unique_nonzero_owner_320  1
    service_1_4_7  service_visit_def_1024  1
    service_1_4_7  free_load_conservation_1025  -5
    service_1_4_7  original_T_including_depot_unload_1039  600
    service_1_4_8  unique_nonzero_owner_321  1
    service_1_4_8  service_visit_def_1024  1
    service_1_4_8  free_load_conservation_1025  -4
    service_1_4_8  original_T_including_depot_unload_1039  480
    service_1_4_9  unique_nonzero_owner_322  1
    service_1_4_9  service_visit_def_1024  1
    service_1_4_9  free_load_conservation_1025  -3
    service_1_4_9  original_T_including_depot_unload_1039  360
    service_1_4_10  unique_nonzero_owner_323  1
    service_1_4_10  service_visit_def_1024  1
    service_1_4_10  free_load_conservation_1025  -2
    service_1_4_10  original_T_including_depot_unload_1039  240
    service_1_4_11  unique_nonzero_owner_324  1
    service_1_4_11  service_visit_def_1024  1
    service_1_4_11  free_load_conservation_1025  -1
    service_1_4_11  original_T_including_depot_unload_1039  120
    service_1_4_13  unique_nonzero_owner_325  1
    service_1_4_13  service_visit_def_1024  1
    service_1_4_13  free_load_conservation_1025  1
    service_1_4_14  unique_nonzero_owner_326  1
    service_1_4_14  service_visit_def_1024  1
    service_1_4_14  free_load_conservation_1025  2
    service_1_4_15  unique_nonzero_owner_327  1
    service_1_4_15  service_visit_def_1024  1
    service_1_4_15  free_load_conservation_1025  3
    service_0_11_0  unique_nonzero_owner_328  1
    service_0_11_0  service_visit_def_760  1
    service_0_11_0  free_load_conservation_761  -1
    service_0_11_0  original_T_including_depot_unload_772  120
    service_0_11_2  unique_nonzero_owner_329  1
    service_0_11_2  service_visit_def_760  1
    service_0_11_2  free_load_conservation_761  1
    service_0_11_3  unique_nonzero_owner_330  1
    service_0_11_3  service_visit_def_760  1
    service_0_11_3  free_load_conservation_761  2
    service_0_11_4  unique_nonzero_owner_331  1
    service_0_11_4  service_visit_def_760  1
    service_0_11_4  free_load_conservation_761  3
    service_0_11_5  unique_nonzero_owner_332  1
    service_0_11_5  service_visit_def_760  1
    service_0_11_5  free_load_conservation_761  4
    service_0_11_6  unique_nonzero_owner_333  1
    service_0_11_6  service_visit_def_760  1
    service_0_11_6  free_load_conservation_761  5
    service_0_11_7  unique_nonzero_owner_334  1
    service_0_11_7  service_visit_def_760  1
    service_0_11_7  free_load_conservation_761  6
    service_0_11_8  unique_nonzero_owner_335  1
    service_0_11_8  service_visit_def_760  1
    service_0_11_8  free_load_conservation_761  7
    service_0_11_9  unique_nonzero_owner_336  1
    service_0_11_9  service_visit_def_760  1
    service_0_11_9  free_load_conservation_761  8
    service_0_11_10  unique_nonzero_owner_337  1
    service_0_11_10  service_visit_def_760  1
    service_0_11_10  free_load_conservation_761  9
    service_0_11_11  unique_nonzero_owner_338  1
    service_0_11_11  service_visit_def_760  1
    service_0_11_11  free_load_conservation_761  10
    service_0_11_12  unique_nonzero_owner_339  1
    service_0_11_12  service_visit_def_760  1
    service_0_11_12  free_load_conservation_761  11
    service_0_11_13  unique_nonzero_owner_340  1
    service_0_11_13  service_visit_def_760  1
    service_0_11_13  free_load_conservation_761  12
    service_0_11_14  unique_nonzero_owner_341  1
    service_0_11_14  service_visit_def_760  1
    service_0_11_14  free_load_conservation_761  13
    service_0_11_15  unique_nonzero_owner_342  1
    service_0_11_15  service_visit_def_760  1
    service_0_11_15  free_load_conservation_761  14
    service_1_11_0  unique_nonzero_owner_328  1
    service_1_11_0  service_visit_def_1030  1
    service_1_11_0  free_load_conservation_1031  -1
    service_1_11_0  original_T_including_depot_unload_1039  120
    service_1_11_2  unique_nonzero_owner_329  1
    service_1_11_2  service_visit_def_1030  1
    service_1_11_2  free_load_conservation_1031  1
    service_1_11_3  unique_nonzero_owner_330  1
    service_1_11_3  service_visit_def_1030  1
    service_1_11_3  free_load_conservation_1031  2
    service_1_11_4  unique_nonzero_owner_331  1
    service_1_11_4  service_visit_def_1030  1
    service_1_11_4  free_load_conservation_1031  3
    service_1_11_5  unique_nonzero_owner_332  1
    service_1_11_5  service_visit_def_1030  1
    service_1_11_5  free_load_conservation_1031  4
    service_1_11_6  unique_nonzero_owner_333  1
    service_1_11_6  service_visit_def_1030  1
    service_1_11_6  free_load_conservation_1031  5
    service_1_11_7  unique_nonzero_owner_334  1
    service_1_11_7  service_visit_def_1030  1
    service_1_11_7  free_load_conservation_1031  6
    service_1_11_8  unique_nonzero_owner_335  1
    service_1_11_8  service_visit_def_1030  1
    service_1_11_8  free_load_conservation_1031  7
    service_1_11_9  unique_nonzero_owner_336  1
    service_1_11_9  service_visit_def_1030  1
    service_1_11_9  free_load_conservation_1031  8
    service_1_11_10  unique_nonzero_owner_337  1
    service_1_11_10  service_visit_def_1030  1
    service_1_11_10  free_load_conservation_1031  9
    service_1_11_11  unique_nonzero_owner_338  1
    service_1_11_11  service_visit_def_1030  1
    service_1_11_11  free_load_conservation_1031  10
    service_1_11_12  unique_nonzero_owner_339  1
    service_1_11_12  service_visit_def_1030  1
    service_1_11_12  free_load_conservation_1031  11
    service_1_11_13  unique_nonzero_owner_340  1
    service_1_11_13  service_visit_def_1030  1
    service_1_11_13  free_load_conservation_1031  12
    service_1_11_14  unique_nonzero_owner_341  1
    service_1_11_14  service_visit_def_1030  1
    service_1_11_14  free_load_conservation_1031  13
    service_1_11_15  unique_nonzero_owner_342  1
    service_1_11_15  service_visit_def_1030  1
    service_1_11_15  free_load_conservation_1031  14
    service_0_2_1  unique_nonzero_owner_343  1
    service_0_2_1  service_visit_def_766  1
    service_0_2_1  free_load_conservation_767  1
    service_1_2_1  unique_nonzero_owner_343  1
    service_1_2_1  service_visit_def_1036  1
    service_1_2_1  free_load_conservation_1037  1
    MARKER    'MARKER'                 'INTEND'
    visit_0_1  out_degree_685  -1
    visit_0_1  in_degree_686  -1
    visit_0_1  order_active_lb_687  -1
    visit_0_1  order_active_ub_688  -13
    order_0_1  connected_order_arc_360  -1
    order_0_1  connected_order_arc_362  -1
    order_0_1  connected_order_arc_364  -1
    order_0_1  connected_order_arc_366  -1
    order_0_1  connected_order_arc_368  -1
    order_0_1  connected_order_arc_370  -1
    order_0_1  connected_order_arc_372  -1
    order_0_1  connected_order_arc_374  -1
    order_0_1  connected_order_arc_376  -1
    order_0_1  connected_order_arc_378  -1
    order_0_1  connected_order_arc_380  -1
    order_0_1  connected_order_arc_382  -1
    order_0_1  connected_order_arc_385  1
    order_0_1  connected_order_arc_410  1
    order_0_1  connected_order_arc_435  1
    order_0_1  connected_order_arc_460  1
    order_0_1  connected_order_arc_485  1
    order_0_1  connected_order_arc_510  1
    order_0_1  connected_order_arc_535  1
    order_0_1  connected_order_arc_560  1
    order_0_1  connected_order_arc_585  1
    order_0_1  connected_order_arc_610  1
    order_0_1  connected_order_arc_635  1
    order_0_1  connected_order_arc_660  1
    order_0_1  order_active_lb_687  1
    order_0_1  order_active_ub_688  1
    order_0_1  fixed_segment_relative_order_768  -1
    visit_0_2  out_degree_692  -1
    visit_0_2  in_degree_693  -1
    visit_0_2  order_active_lb_694  -1
    visit_0_2  order_active_ub_695  -13
    order_0_2  connected_order_arc_360  1
    order_0_2  connected_order_arc_385  -1
    order_0_2  connected_order_arc_387  -1
    order_0_2  connected_order_arc_389  -1
    order_0_2  connected_order_arc_391  -1
    order_0_2  connected_order_arc_393  -1
    order_0_2  connected_order_arc_395  -1
    order_0_2  connected_order_arc_397  -1
    order_0_2  connected_order_arc_399  -1
    order_0_2  connected_order_arc_401  -1
    order_0_2  connected_order_arc_403  -1
    order_0_2  connected_order_arc_405  -1
    order_0_2  connected_order_arc_407  -1
    order_0_2  connected_order_arc_412  1
    order_0_2  connected_order_arc_437  1
    order_0_2  connected_order_arc_462  1
    order_0_2  connected_order_arc_487  1
    order_0_2  connected_order_arc_512  1
    order_0_2  connected_order_arc_537  1
    order_0_2  connected_order_arc_562  1
    order_0_2  connected_order_arc_587  1
    order_0_2  connected_order_arc_612  1
    order_0_2  connected_order_arc_637  1
    order_0_2  connected_order_arc_662  1
    order_0_2  order_active_lb_694  1
    order_0_2  order_active_ub_695  1
    order_0_2  fixed_segment_relative_order_768  1
    order_0_2  fixed_segment_relative_order_769  -1
    visit_0_3  out_degree_699  -1
    visit_0_3  in_degree_700  -1
    visit_0_3  order_active_lb_701  -1
    visit_0_3  order_active_ub_702  -13
    order_0_3  connected_order_arc_362  1
    order_0_3  connected_order_arc_387  1
    order_0_3  connected_order_arc_410  -1
    order_0_3  connected_order_arc_412  -1
    order_0_3  connected_order_arc_414  -1
    order_0_3  connected_order_arc_416  -1
    order_0_3  connected_order_arc_418  -1
    order_0_3  connected_order_arc_420  -1
    order_0_3  connected_order_arc_422  -1
    order_0_3  connected_order_arc_424  -1
    order_0_3  connected_order_arc_426  -1
    order_0_3  connected_order_arc_428  -1
    order_0_3  connected_order_arc_430  -1
    order_0_3  connected_order_arc_432  -1
    order_0_3  connected_order_arc_439  1
    order_0_3  connected_order_arc_464  1
    order_0_3  connected_order_arc_489  1
    order_0_3  connected_order_arc_514  1
    order_0_3  connected_order_arc_539  1
    order_0_3  connected_order_arc_564  1
    order_0_3  connected_order_arc_589  1
    order_0_3  connected_order_arc_614  1
    order_0_3  connected_order_arc_639  1
    order_0_3  connected_order_arc_664  1
    order_0_3  order_active_lb_701  1
    order_0_3  order_active_ub_702  1
    order_0_3  fixed_segment_relative_order_769  1
    order_0_3  fixed_segment_relative_order_770  -1
    visit_0_4  out_degree_706  -1
    visit_0_4  in_degree_707  -1
    visit_0_4  order_active_lb_708  -1
    visit_0_4  order_active_ub_709  -13
    order_0_4  connected_order_arc_364  1
    order_0_4  connected_order_arc_389  1
    order_0_4  connected_order_arc_414  1
    order_0_4  connected_order_arc_435  -1
    order_0_4  connected_order_arc_437  -1
    order_0_4  connected_order_arc_439  -1
    order_0_4  connected_order_arc_441  -1
    order_0_4  connected_order_arc_443  -1
    order_0_4  connected_order_arc_445  -1
    order_0_4  connected_order_arc_447  -1
    order_0_4  connected_order_arc_449  -1
    order_0_4  connected_order_arc_451  -1
    order_0_4  connected_order_arc_453  -1
    order_0_4  connected_order_arc_455  -1
    order_0_4  connected_order_arc_457  -1
    order_0_4  connected_order_arc_466  1
    order_0_4  connected_order_arc_491  1
    order_0_4  connected_order_arc_516  1
    order_0_4  connected_order_arc_541  1
    order_0_4  connected_order_arc_566  1
    order_0_4  connected_order_arc_591  1
    order_0_4  connected_order_arc_616  1
    order_0_4  connected_order_arc_641  1
    order_0_4  connected_order_arc_666  1
    order_0_4  order_active_lb_708  1
    order_0_4  order_active_ub_709  1
    order_0_4  fixed_segment_relative_order_770  1
    order_0_4  fixed_segment_relative_order_771  -1
    visit_0_5  out_degree_713  -1
    visit_0_5  in_degree_714  -1
    visit_0_5  order_active_lb_715  -1
    visit_0_5  order_active_ub_716  -13
    order_0_5  connected_order_arc_366  1
    order_0_5  connected_order_arc_391  1
    order_0_5  connected_order_arc_416  1
    order_0_5  connected_order_arc_441  1
    order_0_5  connected_order_arc_460  -1
    order_0_5  connected_order_arc_462  -1
    order_0_5  connected_order_arc_464  -1
    order_0_5  connected_order_arc_466  -1
    order_0_5  connected_order_arc_468  -1
    order_0_5  connected_order_arc_470  -1
    order_0_5  connected_order_arc_472  -1
    order_0_5  connected_order_arc_474  -1
    order_0_5  connected_order_arc_476  -1
    order_0_5  connected_order_arc_478  -1
    order_0_5  connected_order_arc_480  -1
    order_0_5  connected_order_arc_482  -1
    order_0_5  connected_order_arc_493  1
    order_0_5  connected_order_arc_518  1
    order_0_5  connected_order_arc_543  1
    order_0_5  connected_order_arc_568  1
    order_0_5  connected_order_arc_593  1
    order_0_5  connected_order_arc_618  1
    order_0_5  connected_order_arc_643  1
    order_0_5  connected_order_arc_668  1
    order_0_5  order_active_lb_715  1
    order_0_5  order_active_ub_716  1
    order_0_5  fixed_segment_relative_order_771  1
    visit_0_8  out_degree_720  -1
    visit_0_8  in_degree_721  -1
    visit_0_8  order_active_lb_722  -1
    visit_0_8  order_active_ub_723  -13
    visit_0_8  service_visit_def_724  -1
    order_0_8  connected_order_arc_368  1
    order_0_8  connected_order_arc_393  1
    order_0_8  connected_order_arc_418  1
    order_0_8  connected_order_arc_443  1
    order_0_8  connected_order_arc_468  1
    order_0_8  connected_order_arc_485  -1
    order_0_8  connected_order_arc_487  -1
    order_0_8  connected_order_arc_489  -1
    order_0_8  connected_order_arc_491  -1
    order_0_8  connected_order_arc_493  -1
    order_0_8  connected_order_arc_495  -1
    order_0_8  connected_order_arc_497  -1
    order_0_8  connected_order_arc_499  -1
    order_0_8  connected_order_arc_501  -1
    order_0_8  connected_order_arc_503  -1
    order_0_8  connected_order_arc_505  -1
    order_0_8  connected_order_arc_507  -1
    order_0_8  connected_order_arc_520  1
    order_0_8  connected_order_arc_545  1
    order_0_8  connected_order_arc_570  1
    order_0_8  connected_order_arc_595  1
    order_0_8  connected_order_arc_620  1
    order_0_8  connected_order_arc_645  1
    order_0_8  connected_order_arc_670  1
    order_0_8  order_active_lb_722  1
    order_0_8  order_active_ub_723  1
    visit_0_9  out_degree_726  -1
    visit_0_9  in_degree_727  -1
    visit_0_9  order_active_lb_728  -1
    visit_0_9  order_active_ub_729  -13
    visit_0_9  service_visit_def_730  -1
    order_0_9  connected_order_arc_370  1
    order_0_9  connected_order_arc_395  1
    order_0_9  connected_order_arc_420  1
    order_0_9  connected_order_arc_445  1
    order_0_9  connected_order_arc_470  1
    order_0_9  connected_order_arc_495  1
    order_0_9  connected_order_arc_510  -1
    order_0_9  connected_order_arc_512  -1
    order_0_9  connected_order_arc_514  -1
    order_0_9  connected_order_arc_516  -1
    order_0_9  connected_order_arc_518  -1
    order_0_9  connected_order_arc_520  -1
    order_0_9  connected_order_arc_522  -1
    order_0_9  connected_order_arc_524  -1
    order_0_9  connected_order_arc_526  -1
    order_0_9  connected_order_arc_528  -1
    order_0_9  connected_order_arc_530  -1
    order_0_9  connected_order_arc_532  -1
    order_0_9  connected_order_arc_547  1
    order_0_9  connected_order_arc_572  1
    order_0_9  connected_order_arc_597  1
    order_0_9  connected_order_arc_622  1
    order_0_9  connected_order_arc_647  1
    order_0_9  connected_order_arc_672  1
    order_0_9  order_active_lb_728  1
    order_0_9  order_active_ub_729  1
    visit_0_10  out_degree_732  -1
    visit_0_10  in_degree_733  -1
    visit_0_10  order_active_lb_734  -1
    visit_0_10  order_active_ub_735  -13
    visit_0_10  service_visit_def_736  -1
    order_0_10  connected_order_arc_372  1
    order_0_10  connected_order_arc_397  1
    order_0_10  connected_order_arc_422  1
    order_0_10  connected_order_arc_447  1
    order_0_10  connected_order_arc_472  1
    order_0_10  connected_order_arc_497  1
    order_0_10  connected_order_arc_522  1
    order_0_10  connected_order_arc_535  -1
    order_0_10  connected_order_arc_537  -1
    order_0_10  connected_order_arc_539  -1
    order_0_10  connected_order_arc_541  -1
    order_0_10  connected_order_arc_543  -1
    order_0_10  connected_order_arc_545  -1
    order_0_10  connected_order_arc_547  -1
    order_0_10  connected_order_arc_549  -1
    order_0_10  connected_order_arc_551  -1
    order_0_10  connected_order_arc_553  -1
    order_0_10  connected_order_arc_555  -1
    order_0_10  connected_order_arc_557  -1
    order_0_10  connected_order_arc_574  1
    order_0_10  connected_order_arc_599  1
    order_0_10  connected_order_arc_624  1
    order_0_10  connected_order_arc_649  1
    order_0_10  connected_order_arc_674  1
    order_0_10  order_active_lb_734  1
    order_0_10  order_active_ub_735  1
    visit_0_11  out_degree_738  -1
    visit_0_11  in_degree_739  -1
    visit_0_11  order_active_lb_740  -1
    visit_0_11  order_active_ub_741  -13
    visit_0_11  service_visit_def_742  -1
    order_0_11  connected_order_arc_374  1
    order_0_11  connected_order_arc_399  1
    order_0_11  connected_order_arc_424  1
    order_0_11  connected_order_arc_449  1
    order_0_11  connected_order_arc_474  1
    order_0_11  connected_order_arc_499  1
    order_0_11  connected_order_arc_524  1
    order_0_11  connected_order_arc_549  1
    order_0_11  connected_order_arc_560  -1
    order_0_11  connected_order_arc_562  -1
    order_0_11  connected_order_arc_564  -1
    order_0_11  connected_order_arc_566  -1
    order_0_11  connected_order_arc_568  -1
    order_0_11  connected_order_arc_570  -1
    order_0_11  connected_order_arc_572  -1
    order_0_11  connected_order_arc_574  -1
    order_0_11  connected_order_arc_576  -1
    order_0_11  connected_order_arc_578  -1
    order_0_11  connected_order_arc_580  -1
    order_0_11  connected_order_arc_582  -1
    order_0_11  connected_order_arc_601  1
    order_0_11  connected_order_arc_626  1
    order_0_11  connected_order_arc_651  1
    order_0_11  connected_order_arc_676  1
    order_0_11  order_active_lb_740  1
    order_0_11  order_active_ub_741  1
    visit_0_12  out_degree_744  -1
    visit_0_12  in_degree_745  -1
    visit_0_12  order_active_lb_746  -1
    visit_0_12  order_active_ub_747  -13
    visit_0_12  service_visit_def_748  -1
    order_0_12  connected_order_arc_376  1
    order_0_12  connected_order_arc_401  1
    order_0_12  connected_order_arc_426  1
    order_0_12  connected_order_arc_451  1
    order_0_12  connected_order_arc_476  1
    order_0_12  connected_order_arc_501  1
    order_0_12  connected_order_arc_526  1
    order_0_12  connected_order_arc_551  1
    order_0_12  connected_order_arc_576  1
    order_0_12  connected_order_arc_585  -1
    order_0_12  connected_order_arc_587  -1
    order_0_12  connected_order_arc_589  -1
    order_0_12  connected_order_arc_591  -1
    order_0_12  connected_order_arc_593  -1
    order_0_12  connected_order_arc_595  -1
    order_0_12  connected_order_arc_597  -1
    order_0_12  connected_order_arc_599  -1
    order_0_12  connected_order_arc_601  -1
    order_0_12  connected_order_arc_603  -1
    order_0_12  connected_order_arc_605  -1
    order_0_12  connected_order_arc_607  -1
    order_0_12  connected_order_arc_628  1
    order_0_12  connected_order_arc_653  1
    order_0_12  connected_order_arc_678  1
    order_0_12  order_active_lb_746  1
    order_0_12  order_active_ub_747  1
    visit_0_13  out_degree_750  -1
    visit_0_13  in_degree_751  -1
    visit_0_13  order_active_lb_752  -1
    visit_0_13  order_active_ub_753  -13
    visit_0_13  service_visit_def_754  -1
    order_0_13  connected_order_arc_378  1
    order_0_13  connected_order_arc_403  1
    order_0_13  connected_order_arc_428  1
    order_0_13  connected_order_arc_453  1
    order_0_13  connected_order_arc_478  1
    order_0_13  connected_order_arc_503  1
    order_0_13  connected_order_arc_528  1
    order_0_13  connected_order_arc_553  1
    order_0_13  connected_order_arc_578  1
    order_0_13  connected_order_arc_603  1
    order_0_13  connected_order_arc_610  -1
    order_0_13  connected_order_arc_612  -1
    order_0_13  connected_order_arc_614  -1
    order_0_13  connected_order_arc_616  -1
    order_0_13  connected_order_arc_618  -1
    order_0_13  connected_order_arc_620  -1
    order_0_13  connected_order_arc_622  -1
    order_0_13  connected_order_arc_624  -1
    order_0_13  connected_order_arc_626  -1
    order_0_13  connected_order_arc_628  -1
    order_0_13  connected_order_arc_630  -1
    order_0_13  connected_order_arc_632  -1
    order_0_13  connected_order_arc_655  1
    order_0_13  connected_order_arc_680  1
    order_0_13  order_active_lb_752  1
    order_0_13  order_active_ub_753  1
    visit_0_14  out_degree_756  -1
    visit_0_14  in_degree_757  -1
    visit_0_14  order_active_lb_758  -1
    visit_0_14  order_active_ub_759  -13
    visit_0_14  service_visit_def_760  -1
    order_0_14  connected_order_arc_380  1
    order_0_14  connected_order_arc_405  1
    order_0_14  connected_order_arc_430  1
    order_0_14  connected_order_arc_455  1
    order_0_14  connected_order_arc_480  1
    order_0_14  connected_order_arc_505  1
    order_0_14  connected_order_arc_530  1
    order_0_14  connected_order_arc_555  1
    order_0_14  connected_order_arc_580  1
    order_0_14  connected_order_arc_605  1
    order_0_14  connected_order_arc_630  1
    order_0_14  connected_order_arc_635  -1
    order_0_14  connected_order_arc_637  -1
    order_0_14  connected_order_arc_639  -1
    order_0_14  connected_order_arc_641  -1
    order_0_14  connected_order_arc_643  -1
    order_0_14  connected_order_arc_645  -1
    order_0_14  connected_order_arc_647  -1
    order_0_14  connected_order_arc_649  -1
    order_0_14  connected_order_arc_651  -1
    order_0_14  connected_order_arc_653  -1
    order_0_14  connected_order_arc_655  -1
    order_0_14  connected_order_arc_657  -1
    order_0_14  connected_order_arc_682  1
    order_0_14  order_active_lb_758  1
    order_0_14  order_active_ub_759  1
    visit_0_15  out_degree_762  -1
    visit_0_15  in_degree_763  -1
    visit_0_15  order_active_lb_764  -1
    visit_0_15  order_active_ub_765  -13
    visit_0_15  service_visit_def_766  -1
    order_0_15  connected_order_arc_382  1
    order_0_15  connected_order_arc_407  1
    order_0_15  connected_order_arc_432  1
    order_0_15  connected_order_arc_457  1
    order_0_15  connected_order_arc_482  1
    order_0_15  connected_order_arc_507  1
    order_0_15  connected_order_arc_532  1
    order_0_15  connected_order_arc_557  1
    order_0_15  connected_order_arc_582  1
    order_0_15  connected_order_arc_607  1
    order_0_15  connected_order_arc_632  1
    order_0_15  connected_order_arc_657  1
    order_0_15  connected_order_arc_660  -1
    order_0_15  connected_order_arc_662  -1
    order_0_15  connected_order_arc_664  -1
    order_0_15  connected_order_arc_666  -1
    order_0_15  connected_order_arc_668  -1
    order_0_15  connected_order_arc_670  -1
    order_0_15  connected_order_arc_672  -1
    order_0_15  connected_order_arc_674  -1
    order_0_15  connected_order_arc_676  -1
    order_0_15  connected_order_arc_678  -1
    order_0_15  connected_order_arc_680  -1
    order_0_15  connected_order_arc_682  -1
    order_0_15  order_active_lb_764  1
    order_0_15  order_active_ub_765  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_0  arc_capacity_344  -30
    arc_0_0_0  depot_departure_or_bypass_683  1
    arc_0_0_0  depot_return_or_bypass_684  1
    MARKER    'MARKER'                 'INTEND'
    load_0_0_0  arc_capacity_344  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_1  arc_capacity_345  -30
    arc_0_0_1  depot_departure_or_bypass_683  1
    arc_0_0_1  in_degree_686  1
    arc_0_0_1  original_T_including_depot_unload_772  3.5937232665424995e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_1  arc_capacity_345  1
    load_0_0_1  segment_load_conservation_689  -1
    load_0_0_1  segment_prefix_lb_690  1
    load_0_0_1  segment_prefix_ub_691  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_2  arc_capacity_346  -30
    arc_0_0_2  depot_departure_or_bypass_683  1
    arc_0_0_2  in_degree_693  1
    arc_0_0_2  original_T_including_depot_unload_772  5.2774046204590661e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_2  arc_capacity_346  1
    load_0_0_2  segment_load_conservation_696  -1
    load_0_0_2  segment_prefix_lb_697  1
    load_0_0_2  segment_prefix_ub_698  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_3  arc_capacity_347  -30
    arc_0_0_3  depot_departure_or_bypass_683  1
    arc_0_0_3  in_degree_700  1
    arc_0_0_3  original_T_including_depot_unload_772  1.1473865007565566e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_3  arc_capacity_347  1
    load_0_0_3  segment_load_conservation_703  -1
    load_0_0_3  segment_prefix_lb_704  1
    load_0_0_3  segment_prefix_ub_705  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_4  arc_capacity_348  -30
    arc_0_0_4  depot_departure_or_bypass_683  1
    arc_0_0_4  in_degree_707  1
    arc_0_0_4  original_T_including_depot_unload_772  5.9631731642067359e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_4  arc_capacity_348  1
    load_0_0_4  segment_load_conservation_710  -1
    load_0_0_4  segment_prefix_lb_711  1
    load_0_0_4  segment_prefix_ub_712  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_5  arc_capacity_349  -30
    arc_0_0_5  depot_departure_or_bypass_683  1
    arc_0_0_5  in_degree_714  1
    arc_0_0_5  original_T_including_depot_unload_772  4.1588440854375170e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_5  arc_capacity_349  1
    load_0_0_5  segment_load_conservation_717  -1
    load_0_0_5  segment_prefix_lb_718  1
    load_0_0_5  segment_prefix_ub_719  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_8  arc_capacity_350  -30
    arc_0_0_8  depot_departure_or_bypass_683  1
    arc_0_0_8  in_degree_721  1
    arc_0_0_8  original_T_including_depot_unload_772  9.3659929340140741e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_8  arc_capacity_350  1
    load_0_0_8  free_load_conservation_725  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_9  arc_capacity_351  -30
    arc_0_0_9  depot_departure_or_bypass_683  1
    arc_0_0_9  in_degree_727  1
    arc_0_0_9  original_T_including_depot_unload_772  7.4412496590753551e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_9  arc_capacity_351  1
    load_0_0_9  free_load_conservation_731  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_10  arc_capacity_352  -30
    arc_0_0_10  depot_departure_or_bypass_683  1
    arc_0_0_10  in_degree_733  1
    arc_0_0_10  original_T_including_depot_unload_772  2.3234267380118886e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_10  arc_capacity_352  1
    load_0_0_10  free_load_conservation_737  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_11  arc_capacity_353  -30
    arc_0_0_11  depot_departure_or_bypass_683  1
    arc_0_0_11  in_degree_739  1
    arc_0_0_11  original_T_including_depot_unload_772  8.2548955430739034e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_11  arc_capacity_353  1
    load_0_0_11  free_load_conservation_743  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_12  arc_capacity_354  -30
    arc_0_0_12  depot_departure_or_bypass_683  1
    arc_0_0_12  in_degree_745  1
    arc_0_0_12  original_T_including_depot_unload_772  2.2866763971369810e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_12  arc_capacity_354  1
    load_0_0_12  free_load_conservation_749  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_13  arc_capacity_355  -30
    arc_0_0_13  depot_departure_or_bypass_683  1
    arc_0_0_13  in_degree_751  1
    arc_0_0_13  original_T_including_depot_unload_772  1.2186896810212775e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_13  arc_capacity_355  1
    load_0_0_13  free_load_conservation_755  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_14  arc_capacity_356  -30
    arc_0_0_14  depot_departure_or_bypass_683  1
    arc_0_0_14  in_degree_757  1
    arc_0_0_14  original_T_including_depot_unload_772  4.0782796387128610e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_14  arc_capacity_356  1
    load_0_0_14  free_load_conservation_761  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_15  arc_capacity_357  -30
    arc_0_0_15  depot_departure_or_bypass_683  1
    arc_0_0_15  in_degree_763  1
    arc_0_0_15  original_T_including_depot_unload_772  9.3133633713881534e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_15  arc_capacity_357  1
    load_0_0_15  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_0  arc_capacity_358  -30
    arc_0_1_0  depot_return_or_bypass_684  1
    arc_0_1_0  out_degree_685  1
    arc_0_1_0  original_T_including_depot_unload_772  3.5937232665424995e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_0  arc_capacity_358  1
    load_0_1_0  segment_load_conservation_689  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_2  arc_capacity_359  -30
    arc_0_1_2  connected_order_arc_360  -14
    arc_0_1_2  out_degree_685  1
    arc_0_1_2  in_degree_693  1
    arc_0_1_2  original_T_including_depot_unload_772  7.2696582003770027e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_2  arc_capacity_359  1
    load_0_1_2  segment_load_conservation_689  1
    load_0_1_2  segment_load_conservation_696  -1
    load_0_1_2  segment_prefix_lb_697  1
    load_0_1_2  segment_prefix_ub_698  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_3  arc_capacity_361  -30
    arc_0_1_3  connected_order_arc_362  -14
    arc_0_1_3  out_degree_685  1
    arc_0_1_3  in_degree_700  1
    arc_0_1_3  original_T_including_depot_unload_772  1.4558134627196880e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_3  arc_capacity_361  1
    load_0_1_3  segment_load_conservation_689  1
    load_0_1_3  segment_load_conservation_703  -1
    load_0_1_3  segment_prefix_lb_704  1
    load_0_1_3  segment_prefix_ub_705  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_4  arc_capacity_363  -30
    arc_0_1_4  connected_order_arc_364  -14
    arc_0_1_4  out_degree_685  1
    arc_0_1_4  in_degree_707  1
    arc_0_1_4  original_T_including_depot_unload_772  8.4376826601758887e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_4  arc_capacity_363  1
    load_0_1_4  segment_load_conservation_689  1
    load_0_1_4  segment_load_conservation_710  -1
    load_0_1_4  segment_prefix_lb_711  1
    load_0_1_4  segment_prefix_ub_712  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_5  arc_capacity_365  -30
    arc_0_1_5  connected_order_arc_366  -14
    arc_0_1_5  out_degree_685  1
    arc_0_1_5  in_degree_714  1
    arc_0_1_5  original_T_including_depot_unload_772  7.2365484333226220e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_5  arc_capacity_365  1
    load_0_1_5  segment_load_conservation_689  1
    load_0_1_5  segment_load_conservation_717  -1
    load_0_1_5  segment_prefix_lb_718  1
    load_0_1_5  segment_prefix_ub_719  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_8  arc_capacity_367  -30
    arc_0_1_8  connected_order_arc_368  -14
    arc_0_1_8  out_degree_685  1
    arc_0_1_8  in_degree_721  1
    arc_0_1_8  original_T_including_depot_unload_772  1.1702148343313254e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_8  arc_capacity_367  1
    load_0_1_8  segment_load_conservation_689  1
    load_0_1_8  free_load_conservation_725  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_9  arc_capacity_369  -30
    arc_0_1_9  connected_order_arc_370  -14
    arc_0_1_9  out_degree_685  1
    arc_0_1_9  in_degree_727  1
    arc_0_1_9  original_T_including_depot_unload_772  1.0007616644945284e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_9  arc_capacity_369  1
    load_0_1_9  segment_load_conservation_689  1
    load_0_1_9  free_load_conservation_731  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_10  arc_capacity_371  -30
    arc_0_1_10  connected_order_arc_372  -14
    arc_0_1_10  out_degree_685  1
    arc_0_1_10  in_degree_733  1
    arc_0_1_10  original_T_including_depot_unload_772  2.4160844235310037e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_10  arc_capacity_371  1
    load_0_1_10  segment_load_conservation_689  1
    load_0_1_10  free_load_conservation_737  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_11  arc_capacity_373  -30
    arc_0_1_11  connected_order_arc_374  -14
    arc_0_1_11  out_degree_685  1
    arc_0_1_11  in_degree_739  1
    arc_0_1_11  original_T_including_depot_unload_772  1.1046832181240914e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_11  arc_capacity_373  1
    load_0_1_11  segment_load_conservation_689  1
    load_0_1_11  free_load_conservation_743  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_12  arc_capacity_375  -30
    arc_0_1_12  connected_order_arc_376  -14
    arc_0_1_12  out_degree_685  1
    arc_0_1_12  in_degree_745  1
    arc_0_1_12  original_T_including_depot_unload_772  1.9791430726365086e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_12  arc_capacity_375  1
    load_0_1_12  segment_load_conservation_689  1
    load_0_1_12  free_load_conservation_749  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_13  arc_capacity_377  -30
    arc_0_1_13  connected_order_arc_378  -14
    arc_0_1_13  out_degree_685  1
    arc_0_1_13  in_degree_751  1
    arc_0_1_13  original_T_including_depot_unload_772  1.4485896981484648e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_13  arc_capacity_377  1
    load_0_1_13  segment_load_conservation_689  1
    load_0_1_13  free_load_conservation_755  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_14  arc_capacity_379  -30
    arc_0_1_14  connected_order_arc_380  -14
    arc_0_1_14  out_degree_685  1
    arc_0_1_14  in_degree_757  1
    arc_0_1_14  original_T_including_depot_unload_772  6.3975035388222534e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_14  arc_capacity_379  1
    load_0_1_14  segment_load_conservation_689  1
    load_0_1_14  free_load_conservation_761  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_15  arc_capacity_381  -30
    arc_0_1_15  connected_order_arc_382  -14
    arc_0_1_15  out_degree_685  1
    arc_0_1_15  in_degree_763  1
    arc_0_1_15  original_T_including_depot_unload_772  1.2315777010885340e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_15  arc_capacity_381  1
    load_0_1_15  segment_load_conservation_689  1
    load_0_1_15  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_0  arc_capacity_383  -30
    arc_0_2_0  depot_return_or_bypass_684  1
    arc_0_2_0  out_degree_692  1
    arc_0_2_0  original_T_including_depot_unload_772  5.2774046204590661e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_0  arc_capacity_383  1
    load_0_2_0  segment_load_conservation_696  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_1  arc_capacity_384  -30
    arc_0_2_1  connected_order_arc_385  -14
    arc_0_2_1  in_degree_686  1
    arc_0_2_1  out_degree_692  1
    arc_0_2_1  original_T_including_depot_unload_772  7.2696582003770027e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_1  arc_capacity_384  1
    load_0_2_1  segment_load_conservation_689  -1
    load_0_2_1  segment_prefix_lb_690  1
    load_0_2_1  segment_prefix_ub_691  1
    load_0_2_1  segment_load_conservation_696  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_3  arc_capacity_386  -30
    arc_0_2_3  connected_order_arc_387  -14
    arc_0_2_3  out_degree_692  1
    arc_0_2_3  in_degree_700  1
    arc_0_2_3  original_T_including_depot_unload_772  7.8604521666483390e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_3  arc_capacity_386  1
    load_0_2_3  segment_load_conservation_696  1
    load_0_2_3  segment_load_conservation_703  -1
    load_0_2_3  segment_prefix_lb_704  1
    load_0_2_3  segment_prefix_ub_705  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_4  arc_capacity_388  -30
    arc_0_2_4  connected_order_arc_389  -14
    arc_0_2_4  out_degree_692  1
    arc_0_2_4  in_degree_707  1
    arc_0_2_4  original_T_including_depot_unload_772  1.4810770279475858e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_4  arc_capacity_388  1
    load_0_2_4  segment_load_conservation_696  1
    load_0_2_4  segment_load_conservation_710  -1
    load_0_2_4  segment_prefix_lb_711  1
    load_0_2_4  segment_prefix_ub_712  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_5  arc_capacity_390  -30
    arc_0_2_5  connected_order_arc_391  -14
    arc_0_2_5  out_degree_692  1
    arc_0_2_5  in_degree_714  1
    arc_0_2_5  original_T_including_depot_unload_772  2.6178398366762252e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_5  arc_capacity_390  1
    load_0_2_5  segment_load_conservation_696  1
    load_0_2_5  segment_load_conservation_717  -1
    load_0_2_5  segment_prefix_lb_718  1
    load_0_2_5  segment_prefix_ub_719  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_8  arc_capacity_392  -30
    arc_0_2_8  connected_order_arc_393  -14
    arc_0_2_8  out_degree_692  1
    arc_0_2_8  in_degree_721  1
    arc_0_2_8  original_T_including_depot_unload_772  4.4360641393992279e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_8  arc_capacity_392  1
    load_0_2_8  segment_load_conservation_696  1
    load_0_2_8  free_load_conservation_725  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_9  arc_capacity_394  -30
    arc_0_2_9  connected_order_arc_395  -14
    arc_0_2_9  out_degree_692  1
    arc_0_2_9  in_degree_727  1
    arc_0_2_9  original_T_including_depot_unload_772  291.965990421835
    MARKER    'MARKER'                 'INTEND'
    load_0_2_9  arc_capacity_394  1
    load_0_2_9  segment_load_conservation_696  1
    load_0_2_9  free_load_conservation_731  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_10  arc_capacity_396  -30
    arc_0_2_10  connected_order_arc_397  -14
    arc_0_2_10  out_degree_692  1
    arc_0_2_10  in_degree_733  1
    arc_0_2_10  original_T_including_depot_unload_772  2.7957126389480295e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_10  arc_capacity_396  1
    load_0_2_10  segment_load_conservation_696  1
    load_0_2_10  free_load_conservation_737  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_11  arc_capacity_398  -30
    arc_0_2_11  connected_order_arc_399  -14
    arc_0_2_11  out_degree_692  1
    arc_0_2_11  in_degree_739  1
    arc_0_2_11  original_T_including_depot_unload_772  4.1346687597344868e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_11  arc_capacity_398  1
    load_0_2_11  segment_load_conservation_696  1
    load_0_2_11  free_load_conservation_743  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_12  arc_capacity_400  -30
    arc_0_2_12  connected_order_arc_401  -14
    arc_0_2_12  out_degree_692  1
    arc_0_2_12  in_degree_745  1
    arc_0_2_12  original_T_including_depot_unload_772  2.2541698308553673e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_12  arc_capacity_400  1
    load_0_2_12  segment_load_conservation_696  1
    load_0_2_12  free_load_conservation_749  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_13  arc_capacity_402  -30
    arc_0_2_13  connected_order_arc_403  -14
    arc_0_2_13  out_degree_692  1
    arc_0_2_13  in_degree_751  1
    arc_0_2_13  original_T_including_depot_unload_772  7.2186296856879846e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_13  arc_capacity_402  1
    load_0_2_13  segment_load_conservation_696  1
    load_0_2_13  free_load_conservation_755  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_14  arc_capacity_404  -30
    arc_0_2_14  connected_order_arc_405  -14
    arc_0_2_14  out_degree_692  1
    arc_0_2_14  in_degree_757  1
    arc_0_2_14  original_T_including_depot_unload_772  1.2480053261465446e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_14  arc_capacity_404  1
    load_0_2_14  segment_load_conservation_696  1
    load_0_2_14  free_load_conservation_761  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_15  arc_capacity_406  -30
    arc_0_2_15  connected_order_arc_407  -14
    arc_0_2_15  out_degree_692  1
    arc_0_2_15  in_degree_763  1
    arc_0_2_15  original_T_including_depot_unload_772  5.6231331158364958e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_15  arc_capacity_406  1
    load_0_2_15  segment_load_conservation_696  1
    load_0_2_15  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_0  arc_capacity_408  -30
    arc_0_3_0  depot_return_or_bypass_684  1
    arc_0_3_0  out_degree_699  1
    arc_0_3_0  original_T_including_depot_unload_772  1.1473865007565566e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_0  arc_capacity_408  1
    load_0_3_0  segment_load_conservation_703  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_1  arc_capacity_409  -30
    arc_0_3_1  connected_order_arc_410  -14
    arc_0_3_1  in_degree_686  1
    arc_0_3_1  out_degree_699  1
    arc_0_3_1  original_T_including_depot_unload_772  1.4558134627196880e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_1  arc_capacity_409  1
    load_0_3_1  segment_load_conservation_689  -1
    load_0_3_1  segment_prefix_lb_690  1
    load_0_3_1  segment_prefix_ub_691  1
    load_0_3_1  segment_load_conservation_703  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_2  arc_capacity_411  -30
    arc_0_3_2  connected_order_arc_412  -14
    arc_0_3_2  in_degree_693  1
    arc_0_3_2  out_degree_699  1
    arc_0_3_2  original_T_including_depot_unload_772  7.8604521666483390e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_2  arc_capacity_411  1
    load_0_3_2  segment_load_conservation_696  -1
    load_0_3_2  segment_prefix_lb_697  1
    load_0_3_2  segment_prefix_ub_698  1
    load_0_3_2  segment_load_conservation_703  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_4  arc_capacity_413  -30
    arc_0_3_4  connected_order_arc_414  -14
    arc_0_3_4  out_degree_699  1
    arc_0_3_4  in_degree_707  1
    arc_0_3_4  original_T_including_depot_unload_772  6.4057623819624155e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_4  arc_capacity_413  1
    load_0_3_4  segment_load_conservation_703  1
    load_0_3_4  segment_load_conservation_710  -1
    load_0_3_4  segment_prefix_lb_711  1
    load_0_3_4  segment_prefix_ub_712  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_5  arc_capacity_415  -30
    arc_0_3_5  connected_order_arc_416  -14
    arc_0_3_5  out_degree_699  1
    arc_0_3_5  in_degree_714  1
    arc_0_3_5  original_T_including_depot_unload_772  7.3627521985972965e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_5  arc_capacity_415  1
    load_0_3_5  segment_load_conservation_703  1
    load_0_3_5  segment_load_conservation_717  -1
    load_0_3_5  segment_prefix_lb_718  1
    load_0_3_5  segment_prefix_ub_719  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_8  arc_capacity_417  -30
    arc_0_3_8  connected_order_arc_418  -14
    arc_0_3_8  out_degree_699  1
    arc_0_3_8  in_degree_721  1
    arc_0_3_8  original_T_including_depot_unload_772  4.5058965368847572e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_8  arc_capacity_417  1
    load_0_3_8  segment_load_conservation_703  1
    load_0_3_8  free_load_conservation_725  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_9  arc_capacity_419  -30
    arc_0_3_9  connected_order_arc_420  -14
    arc_0_3_9  out_degree_699  1
    arc_0_3_9  in_degree_727  1
    arc_0_3_9  original_T_including_depot_unload_772  4.9817963927689311e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_9  arc_capacity_419  1
    load_0_3_9  segment_load_conservation_703  1
    load_0_3_9  free_load_conservation_731  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_10  arc_capacity_421  -30
    arc_0_3_10  connected_order_arc_422  -14
    arc_0_3_10  out_degree_699  1
    arc_0_3_10  in_degree_733  1
    arc_0_3_10  original_T_including_depot_unload_772  2.9878665461125843e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_10  arc_capacity_421  1
    load_0_3_10  segment_load_conservation_703  1
    load_0_3_10  free_load_conservation_737  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_11  arc_capacity_423  -30
    arc_0_3_11  connected_order_arc_424  -14
    arc_0_3_11  out_degree_699  1
    arc_0_3_11  in_degree_739  1
    arc_0_3_11  original_T_including_depot_unload_772  3.7295617536174859e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_11  arc_capacity_423  1
    load_0_3_11  segment_load_conservation_703  1
    load_0_3_11  free_load_conservation_743  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_12  arc_capacity_425  -30
    arc_0_3_12  connected_order_arc_426  -14
    arc_0_3_12  out_degree_699  1
    arc_0_3_12  in_degree_745  1
    arc_0_3_12  original_T_including_depot_unload_772  2.9747397208089205e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_12  arc_capacity_425  1
    load_0_3_12  segment_load_conservation_703  1
    load_0_3_12  free_load_conservation_749  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_13  arc_capacity_427  -30
    arc_0_3_13  connected_order_arc_428  -14
    arc_0_3_13  out_degree_699  1
    arc_0_3_13  in_degree_751  1
    arc_0_3_13  original_T_including_depot_unload_772  4.4158457011124148e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_13  arc_capacity_427  1
    load_0_3_13  segment_load_conservation_703  1
    load_0_3_13  free_load_conservation_755  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_14  arc_capacity_429  -30
    arc_0_3_14  connected_order_arc_430  -14
    arc_0_3_14  out_degree_699  1
    arc_0_3_14  in_degree_757  1
    arc_0_3_14  original_T_including_depot_unload_772  8.2982882938703278e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_14  arc_capacity_429  1
    load_0_3_14  segment_load_conservation_703  1
    load_0_3_14  free_load_conservation_761  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_15  arc_capacity_431  -30
    arc_0_3_15  connected_order_arc_432  -14
    arc_0_3_15  out_degree_699  1
    arc_0_3_15  in_degree_763  1
    arc_0_3_15  original_T_including_depot_unload_772  2.2655310037545112e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_15  arc_capacity_431  1
    load_0_3_15  segment_load_conservation_703  1
    load_0_3_15  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_0  arc_capacity_433  -30
    arc_0_4_0  depot_return_or_bypass_684  1
    arc_0_4_0  out_degree_706  1
    arc_0_4_0  original_T_including_depot_unload_772  5.9631731642067359e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_0  arc_capacity_433  1
    load_0_4_0  segment_load_conservation_710  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_1  arc_capacity_434  -30
    arc_0_4_1  connected_order_arc_435  -14
    arc_0_4_1  in_degree_686  1
    arc_0_4_1  out_degree_706  1
    arc_0_4_1  original_T_including_depot_unload_772  8.4376826601758887e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_1  arc_capacity_434  1
    load_0_4_1  segment_load_conservation_689  -1
    load_0_4_1  segment_prefix_lb_690  1
    load_0_4_1  segment_prefix_ub_691  1
    load_0_4_1  segment_load_conservation_710  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_2  arc_capacity_436  -30
    arc_0_4_2  connected_order_arc_437  -14
    arc_0_4_2  in_degree_693  1
    arc_0_4_2  out_degree_706  1
    arc_0_4_2  original_T_including_depot_unload_772  1.4810770279475858e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_2  arc_capacity_436  1
    load_0_4_2  segment_load_conservation_696  -1
    load_0_4_2  segment_prefix_lb_697  1
    load_0_4_2  segment_prefix_ub_698  1
    load_0_4_2  segment_load_conservation_710  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_3  arc_capacity_438  -30
    arc_0_4_3  connected_order_arc_439  -14
    arc_0_4_3  in_degree_700  1
    arc_0_4_3  out_degree_706  1
    arc_0_4_3  original_T_including_depot_unload_772  6.4057623819624155e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_3  arc_capacity_438  1
    load_0_4_3  segment_load_conservation_703  -1
    load_0_4_3  segment_prefix_lb_704  1
    load_0_4_3  segment_prefix_ub_705  1
    load_0_4_3  segment_load_conservation_710  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_5  arc_capacity_440  -30
    arc_0_4_5  connected_order_arc_441  -14
    arc_0_4_5  out_degree_706  1
    arc_0_4_5  in_degree_714  1
    arc_0_4_5  original_T_including_depot_unload_772  2.2661537412294956e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_5  arc_capacity_440  1
    load_0_4_5  segment_load_conservation_710  1
    load_0_4_5  segment_load_conservation_717  -1
    load_0_4_5  segment_prefix_lb_718  1
    load_0_4_5  segment_prefix_ub_719  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_8  arc_capacity_442  -30
    arc_0_4_8  connected_order_arc_443  -14
    arc_0_4_8  out_degree_706  1
    arc_0_4_8  in_degree_721  1
    arc_0_4_8  original_T_including_depot_unload_772  3.4037893208114895e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_8  arc_capacity_442  1
    load_0_4_8  segment_load_conservation_710  1
    load_0_4_8  free_load_conservation_725  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_9  arc_capacity_444  -30
    arc_0_4_9  connected_order_arc_445  -14
    arc_0_4_9  out_degree_706  1
    arc_0_4_9  in_degree_727  1
    arc_0_4_9  original_T_including_depot_unload_772  1.5701156446555925e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_9  arc_capacity_444  1
    load_0_4_9  segment_load_conservation_710  1
    load_0_4_9  free_load_conservation_731  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_10  arc_capacity_446  -30
    arc_0_4_10  connected_order_arc_447  -14
    arc_0_4_10  out_degree_706  1
    arc_0_4_10  in_degree_733  1
    arc_0_4_10  original_T_including_depot_unload_772  2.7910579461472848e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_10  arc_capacity_446  1
    load_0_4_10  segment_load_conservation_710  1
    load_0_4_10  free_load_conservation_737  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_11  arc_capacity_448  -30
    arc_0_4_11  connected_order_arc_449  -14
    arc_0_4_11  out_degree_706  1
    arc_0_4_11  in_degree_739  1
    arc_0_4_11  original_T_including_depot_unload_772  2.6991456262177837e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_11  arc_capacity_448  1
    load_0_4_11  segment_load_conservation_710  1
    load_0_4_11  free_load_conservation_743  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_12  arc_capacity_450  -30
    arc_0_4_12  connected_order_arc_451  -14
    arc_0_4_12  out_degree_706  1
    arc_0_4_12  in_degree_745  1
    arc_0_4_12  original_T_including_depot_unload_772  2.3958340327791907e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_12  arc_capacity_450  1
    load_0_4_12  segment_load_conservation_710  1
    load_0_4_12  free_load_conservation_749  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_13  arc_capacity_452  -30
    arc_0_4_13  connected_order_arc_453  -14
    arc_0_4_13  out_degree_706  1
    arc_0_4_13  in_degree_751  1
    arc_0_4_13  original_T_including_depot_unload_772  6.2279118029742506e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_13  arc_capacity_452  1
    load_0_4_13  segment_load_conservation_710  1
    load_0_4_13  free_load_conservation_755  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_14  arc_capacity_454  -30
    arc_0_4_14  connected_order_arc_455  -14
    arc_0_4_14  out_degree_706  1
    arc_0_4_14  in_degree_757  1
    arc_0_4_14  original_T_including_depot_unload_772  2.0430160967046345e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_14  arc_capacity_454  1
    load_0_4_14  segment_load_conservation_710  1
    load_0_4_14  free_load_conservation_761  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_15  arc_capacity_456  -30
    arc_0_4_15  connected_order_arc_457  -14
    arc_0_4_15  out_degree_706  1
    arc_0_4_15  in_degree_763  1
    arc_0_4_15  original_T_including_depot_unload_772  4.1557375918514475e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_15  arc_capacity_456  1
    load_0_4_15  segment_load_conservation_710  1
    load_0_4_15  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_0  arc_capacity_458  -30
    arc_0_5_0  depot_return_or_bypass_684  1
    arc_0_5_0  out_degree_713  1
    arc_0_5_0  original_T_including_depot_unload_772  4.1588440854375170e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_0  arc_capacity_458  1
    load_0_5_0  segment_load_conservation_717  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_1  arc_capacity_459  -30
    arc_0_5_1  connected_order_arc_460  -14
    arc_0_5_1  in_degree_686  1
    arc_0_5_1  out_degree_713  1
    arc_0_5_1  original_T_including_depot_unload_772  7.2365484333226220e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_1  arc_capacity_459  1
    load_0_5_1  segment_load_conservation_689  -1
    load_0_5_1  segment_prefix_lb_690  1
    load_0_5_1  segment_prefix_ub_691  1
    load_0_5_1  segment_load_conservation_717  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_2  arc_capacity_461  -30
    arc_0_5_2  connected_order_arc_462  -14
    arc_0_5_2  in_degree_693  1
    arc_0_5_2  out_degree_713  1
    arc_0_5_2  original_T_including_depot_unload_772  2.6178398366762252e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_2  arc_capacity_461  1
    load_0_5_2  segment_load_conservation_696  -1
    load_0_5_2  segment_prefix_lb_697  1
    load_0_5_2  segment_prefix_ub_698  1
    load_0_5_2  segment_load_conservation_717  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_3  arc_capacity_463  -30
    arc_0_5_3  connected_order_arc_464  -14
    arc_0_5_3  in_degree_700  1
    arc_0_5_3  out_degree_713  1
    arc_0_5_3  original_T_including_depot_unload_772  7.3627521985972965e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_3  arc_capacity_463  1
    load_0_5_3  segment_load_conservation_703  -1
    load_0_5_3  segment_prefix_lb_704  1
    load_0_5_3  segment_prefix_ub_705  1
    load_0_5_3  segment_load_conservation_717  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_4  arc_capacity_465  -30
    arc_0_5_4  connected_order_arc_466  -14
    arc_0_5_4  in_degree_707  1
    arc_0_5_4  out_degree_713  1
    arc_0_5_4  original_T_including_depot_unload_772  2.2661537412294956e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_4  arc_capacity_465  1
    load_0_5_4  segment_load_conservation_710  -1
    load_0_5_4  segment_prefix_lb_711  1
    load_0_5_4  segment_prefix_ub_712  1
    load_0_5_4  segment_load_conservation_717  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_8  arc_capacity_467  -30
    arc_0_5_8  connected_order_arc_468  -14
    arc_0_5_8  out_degree_713  1
    arc_0_5_8  in_degree_721  1
    arc_0_5_8  original_T_including_depot_unload_772  5.4626430531406254e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_8  arc_capacity_467  1
    load_0_5_8  segment_load_conservation_717  1
    load_0_5_8  free_load_conservation_725  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_9  arc_capacity_469  -30
    arc_0_5_9  connected_order_arc_470  -14
    arc_0_5_9  out_degree_713  1
    arc_0_5_9  in_degree_727  1
    arc_0_5_9  original_T_including_depot_unload_772  3.4593676445964553e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_9  arc_capacity_469  1
    load_0_5_9  segment_load_conservation_717  1
    load_0_5_9  free_load_conservation_731  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_10  arc_capacity_471  -30
    arc_0_5_10  connected_order_arc_472  -14
    arc_0_5_10  out_degree_713  1
    arc_0_5_10  in_degree_733  1
    arc_0_5_10  original_T_including_depot_unload_772  2.5651522766561479e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_10  arc_capacity_471  1
    load_0_5_10  segment_load_conservation_717  1
    load_0_5_10  free_load_conservation_737  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_11  arc_capacity_473  -30
    arc_0_5_11  connected_order_arc_474  -14
    arc_0_5_11  out_degree_713  1
    arc_0_5_11  in_degree_739  1
    arc_0_5_11  original_T_including_depot_unload_772  4.1180717113418365e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_11  arc_capacity_473  1
    load_0_5_11  segment_load_conservation_717  1
    load_0_5_11  free_load_conservation_743  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_12  arc_capacity_475  -30
    arc_0_5_12  connected_order_arc_476  -14
    arc_0_5_12  out_degree_713  1
    arc_0_5_12  in_degree_745  1
    arc_0_5_12  original_T_including_depot_unload_772  2.4543912353372671e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_12  arc_capacity_475  1
    load_0_5_12  segment_load_conservation_717  1
    load_0_5_12  free_load_conservation_749  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_13  arc_capacity_477  -30
    arc_0_5_13  connected_order_arc_478  -14
    arc_0_5_13  out_degree_713  1
    arc_0_5_13  in_degree_751  1
    arc_0_5_13  original_T_including_depot_unload_772  8.2210727717430609e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_13  arc_capacity_477  1
    load_0_5_13  segment_load_conservation_717  1
    load_0_5_13  free_load_conservation_755  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_14  arc_capacity_479  -30
    arc_0_5_14  connected_order_arc_480  -14
    arc_0_5_14  out_degree_713  1
    arc_0_5_14  in_degree_757  1
    arc_0_5_14  original_T_including_depot_unload_772  1.7839442696984972e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_14  arc_capacity_479  1
    load_0_5_14  segment_load_conservation_717  1
    load_0_5_14  free_load_conservation_761  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_15  arc_capacity_481  -30
    arc_0_5_15  connected_order_arc_482  -14
    arc_0_5_15  out_degree_713  1
    arc_0_5_15  in_degree_763  1
    arc_0_5_15  original_T_including_depot_unload_772  516.598297486096
    MARKER    'MARKER'                 'INTEND'
    load_0_5_15  arc_capacity_481  1
    load_0_5_15  segment_load_conservation_717  1
    load_0_5_15  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_0  arc_capacity_483  -30
    arc_0_8_0  depot_return_or_bypass_684  1
    arc_0_8_0  out_degree_720  1
    arc_0_8_0  original_T_including_depot_unload_772  9.3659929340140741e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_0  arc_capacity_483  1
    load_0_8_0  free_load_conservation_725  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_1  arc_capacity_484  -30
    arc_0_8_1  connected_order_arc_485  -14
    arc_0_8_1  in_degree_686  1
    arc_0_8_1  out_degree_720  1
    arc_0_8_1  original_T_including_depot_unload_772  1.1702148343313254e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_8_1  arc_capacity_484  1
    load_0_8_1  segment_load_conservation_689  -1
    load_0_8_1  segment_prefix_lb_690  1
    load_0_8_1  segment_prefix_ub_691  1
    load_0_8_1  free_load_conservation_725  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_2  arc_capacity_486  -30
    arc_0_8_2  connected_order_arc_487  -14
    arc_0_8_2  in_degree_693  1
    arc_0_8_2  out_degree_720  1
    arc_0_8_2  original_T_including_depot_unload_772  4.4360641393992279e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_2  arc_capacity_486  1
    load_0_8_2  segment_load_conservation_696  -1
    load_0_8_2  segment_prefix_lb_697  1
    load_0_8_2  segment_prefix_ub_698  1
    load_0_8_2  free_load_conservation_725  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_3  arc_capacity_488  -30
    arc_0_8_3  connected_order_arc_489  -14
    arc_0_8_3  in_degree_700  1
    arc_0_8_3  out_degree_720  1
    arc_0_8_3  original_T_including_depot_unload_772  4.5058965368847572e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_3  arc_capacity_488  1
    load_0_8_3  segment_load_conservation_703  -1
    load_0_8_3  segment_prefix_lb_704  1
    load_0_8_3  segment_prefix_ub_705  1
    load_0_8_3  free_load_conservation_725  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_4  arc_capacity_490  -30
    arc_0_8_4  connected_order_arc_491  -14
    arc_0_8_4  in_degree_707  1
    arc_0_8_4  out_degree_720  1
    arc_0_8_4  original_T_including_depot_unload_772  3.4037893208114895e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_4  arc_capacity_490  1
    load_0_8_4  segment_load_conservation_710  -1
    load_0_8_4  segment_prefix_lb_711  1
    load_0_8_4  segment_prefix_ub_712  1
    load_0_8_4  free_load_conservation_725  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_5  arc_capacity_492  -30
    arc_0_8_5  connected_order_arc_493  -14
    arc_0_8_5  in_degree_714  1
    arc_0_8_5  out_degree_720  1
    arc_0_8_5  original_T_including_depot_unload_772  5.4626430531406254e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_5  arc_capacity_492  1
    load_0_8_5  segment_load_conservation_717  -1
    load_0_8_5  segment_prefix_lb_718  1
    load_0_8_5  segment_prefix_ub_719  1
    load_0_8_5  free_load_conservation_725  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_9  arc_capacity_494  -30
    arc_0_8_9  connected_order_arc_495  -14
    arc_0_8_9  out_degree_720  1
    arc_0_8_9  in_degree_727  1
    arc_0_8_9  original_T_including_depot_unload_772  2.0082608212298291e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_9  arc_capacity_494  1
    load_0_8_9  free_load_conservation_725  1
    load_0_8_9  free_load_conservation_731  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_10  arc_capacity_496  -30
    arc_0_8_10  connected_order_arc_497  -14
    arc_0_8_10  out_degree_720  1
    arc_0_8_10  in_degree_733  1
    arc_0_8_10  original_T_including_depot_unload_772  3.0726580305165480e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_8_10  arc_capacity_496  1
    load_0_8_10  free_load_conservation_725  1
    load_0_8_10  free_load_conservation_737  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_11  arc_capacity_498  -30
    arc_0_8_11  connected_order_arc_499  -14
    arc_0_8_11  out_degree_720  1
    arc_0_8_11  in_degree_739  1
    arc_0_8_11  original_T_including_depot_unload_772  2.0241950709354862e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_11  arc_capacity_498  1
    load_0_8_11  free_load_conservation_725  1
    load_0_8_11  free_load_conservation_743  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_12  arc_capacity_500  -30
    arc_0_8_12  connected_order_arc_501  -14
    arc_0_8_12  out_degree_720  1
    arc_0_8_12  in_degree_745  1
    arc_0_8_12  original_T_including_depot_unload_772  2.5292035468949002e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_8_12  arc_capacity_500  1
    load_0_8_12  free_load_conservation_725  1
    load_0_8_12  free_load_conservation_749  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_13  arc_capacity_502  -30
    arc_0_8_13  connected_order_arc_503  -14
    arc_0_8_13  out_degree_720  1
    arc_0_8_13  in_degree_751  1
    arc_0_8_13  original_T_including_depot_unload_772  2.8260257937815851e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_13  arc_capacity_502  1
    load_0_8_13  free_load_conservation_725  1
    load_0_8_13  free_load_conservation_755  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_14  arc_capacity_504  -30
    arc_0_8_14  connected_order_arc_505  -14
    arc_0_8_14  out_degree_720  1
    arc_0_8_14  in_degree_757  1
    arc_0_8_14  original_T_including_depot_unload_772  5.3918604589472477e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_14  arc_capacity_504  1
    load_0_8_14  free_load_conservation_725  1
    load_0_8_14  free_load_conservation_761  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_15  arc_capacity_506  -30
    arc_0_8_15  connected_order_arc_507  -14
    arc_0_8_15  out_degree_720  1
    arc_0_8_15  in_degree_763  1
    arc_0_8_15  original_T_including_depot_unload_772  2.9819555494495978e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_15  arc_capacity_506  1
    load_0_8_15  free_load_conservation_725  1
    load_0_8_15  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_0  arc_capacity_508  -30
    arc_0_9_0  depot_return_or_bypass_684  1
    arc_0_9_0  out_degree_726  1
    arc_0_9_0  original_T_including_depot_unload_772  7.4412496590753551e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_0  arc_capacity_508  1
    load_0_9_0  free_load_conservation_731  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_1  arc_capacity_509  -30
    arc_0_9_1  connected_order_arc_510  -14
    arc_0_9_1  in_degree_686  1
    arc_0_9_1  out_degree_726  1
    arc_0_9_1  original_T_including_depot_unload_772  1.0007616644945284e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_1  arc_capacity_509  1
    load_0_9_1  segment_load_conservation_689  -1
    load_0_9_1  segment_prefix_lb_690  1
    load_0_9_1  segment_prefix_ub_691  1
    load_0_9_1  free_load_conservation_731  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_2  arc_capacity_511  -30
    arc_0_9_2  connected_order_arc_512  -14
    arc_0_9_2  in_degree_693  1
    arc_0_9_2  out_degree_726  1
    arc_0_9_2  original_T_including_depot_unload_772  291.965990421835
    MARKER    'MARKER'                 'INTEND'
    load_0_9_2  arc_capacity_511  1
    load_0_9_2  segment_load_conservation_696  -1
    load_0_9_2  segment_prefix_lb_697  1
    load_0_9_2  segment_prefix_ub_698  1
    load_0_9_2  free_load_conservation_731  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_3  arc_capacity_513  -30
    arc_0_9_3  connected_order_arc_514  -14
    arc_0_9_3  in_degree_700  1
    arc_0_9_3  out_degree_726  1
    arc_0_9_3  original_T_including_depot_unload_772  4.9817963927689311e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_3  arc_capacity_513  1
    load_0_9_3  segment_load_conservation_703  -1
    load_0_9_3  segment_prefix_lb_704  1
    load_0_9_3  segment_prefix_ub_705  1
    load_0_9_3  free_load_conservation_731  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_4  arc_capacity_515  -30
    arc_0_9_4  connected_order_arc_516  -14
    arc_0_9_4  in_degree_707  1
    arc_0_9_4  out_degree_726  1
    arc_0_9_4  original_T_including_depot_unload_772  1.5701156446555925e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_4  arc_capacity_515  1
    load_0_9_4  segment_load_conservation_710  -1
    load_0_9_4  segment_prefix_lb_711  1
    load_0_9_4  segment_prefix_ub_712  1
    load_0_9_4  free_load_conservation_731  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_5  arc_capacity_517  -30
    arc_0_9_5  connected_order_arc_518  -14
    arc_0_9_5  in_degree_714  1
    arc_0_9_5  out_degree_726  1
    arc_0_9_5  original_T_including_depot_unload_772  3.4593676445964553e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_5  arc_capacity_517  1
    load_0_9_5  segment_load_conservation_717  -1
    load_0_9_5  segment_prefix_lb_718  1
    load_0_9_5  segment_prefix_ub_719  1
    load_0_9_5  free_load_conservation_731  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_8  arc_capacity_519  -30
    arc_0_9_8  connected_order_arc_520  -14
    arc_0_9_8  in_degree_721  1
    arc_0_9_8  out_degree_726  1
    arc_0_9_8  original_T_including_depot_unload_772  2.0082608212298291e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_8  arc_capacity_519  1
    load_0_9_8  free_load_conservation_725  -1
    load_0_9_8  free_load_conservation_731  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_10  arc_capacity_521  -30
    arc_0_9_10  connected_order_arc_522  -14
    arc_0_9_10  out_degree_726  1
    arc_0_9_10  in_degree_733  1
    arc_0_9_10  original_T_including_depot_unload_772  2.8807002034504962e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_10  arc_capacity_521  1
    load_0_9_10  free_load_conservation_731  1
    load_0_9_10  free_load_conservation_737  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_11  arc_capacity_523  -30
    arc_0_9_11  connected_order_arc_524  -14
    arc_0_9_11  out_degree_726  1
    arc_0_9_11  in_degree_739  1
    arc_0_9_11  original_T_including_depot_unload_772  1.2673640125672841e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_11  arc_capacity_523  1
    load_0_9_11  free_load_conservation_731  1
    load_0_9_11  free_load_conservation_743  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_12  arc_capacity_525  -30
    arc_0_9_12  connected_order_arc_526  -14
    arc_0_9_12  out_degree_726  1
    arc_0_9_12  in_degree_745  1
    arc_0_9_12  original_T_including_depot_unload_772  2.4992063774241742e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_12  arc_capacity_525  1
    load_0_9_12  free_load_conservation_731  1
    load_0_9_12  free_load_conservation_749  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_13  arc_capacity_527  -30
    arc_0_9_13  connected_order_arc_528  -14
    arc_0_9_13  out_degree_726  1
    arc_0_9_13  in_degree_751  1
    arc_0_9_13  original_T_including_depot_unload_772  4.7721499161748335e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_13  arc_capacity_527  1
    load_0_9_13  free_load_conservation_731  1
    load_0_9_13  free_load_conservation_755  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_14  arc_capacity_529  -30
    arc_0_9_14  connected_order_arc_530  -14
    arc_0_9_14  out_degree_726  1
    arc_0_9_14  in_degree_757  1
    arc_0_9_14  original_T_including_depot_unload_772  3.6114004430677619e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_14  arc_capacity_529  1
    load_0_9_14  free_load_conservation_731  1
    load_0_9_14  free_load_conservation_761  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_15  arc_capacity_531  -30
    arc_0_9_15  connected_order_arc_532  -14
    arc_0_9_15  out_degree_726  1
    arc_0_9_15  in_degree_763  1
    arc_0_9_15  original_T_including_depot_unload_772  2.8072002002622634e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_15  arc_capacity_531  1
    load_0_9_15  free_load_conservation_731  1
    load_0_9_15  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_0  arc_capacity_533  -30
    arc_0_10_0  depot_return_or_bypass_684  1
    arc_0_10_0  out_degree_732  1
    arc_0_10_0  original_T_including_depot_unload_772  2.3234267380118886e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_0  arc_capacity_533  1
    load_0_10_0  free_load_conservation_737  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_1  arc_capacity_534  -30
    arc_0_10_1  connected_order_arc_535  -14
    arc_0_10_1  in_degree_686  1
    arc_0_10_1  out_degree_732  1
    arc_0_10_1  original_T_including_depot_unload_772  2.4160844235310037e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_1  arc_capacity_534  1
    load_0_10_1  segment_load_conservation_689  -1
    load_0_10_1  segment_prefix_lb_690  1
    load_0_10_1  segment_prefix_ub_691  1
    load_0_10_1  free_load_conservation_737  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_2  arc_capacity_536  -30
    arc_0_10_2  connected_order_arc_537  -14
    arc_0_10_2  in_degree_693  1
    arc_0_10_2  out_degree_732  1
    arc_0_10_2  original_T_including_depot_unload_772  2.7957126389480295e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_2  arc_capacity_536  1
    load_0_10_2  segment_load_conservation_696  -1
    load_0_10_2  segment_prefix_lb_697  1
    load_0_10_2  segment_prefix_ub_698  1
    load_0_10_2  free_load_conservation_737  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_3  arc_capacity_538  -30
    arc_0_10_3  connected_order_arc_539  -14
    arc_0_10_3  in_degree_700  1
    arc_0_10_3  out_degree_732  1
    arc_0_10_3  original_T_including_depot_unload_772  2.9878665461125843e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_3  arc_capacity_538  1
    load_0_10_3  segment_load_conservation_703  -1
    load_0_10_3  segment_prefix_lb_704  1
    load_0_10_3  segment_prefix_ub_705  1
    load_0_10_3  free_load_conservation_737  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_4  arc_capacity_540  -30
    arc_0_10_4  connected_order_arc_541  -14
    arc_0_10_4  in_degree_707  1
    arc_0_10_4  out_degree_732  1
    arc_0_10_4  original_T_including_depot_unload_772  2.7910579461472848e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_4  arc_capacity_540  1
    load_0_10_4  segment_load_conservation_710  -1
    load_0_10_4  segment_prefix_lb_711  1
    load_0_10_4  segment_prefix_ub_712  1
    load_0_10_4  free_load_conservation_737  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_5  arc_capacity_542  -30
    arc_0_10_5  connected_order_arc_543  -14
    arc_0_10_5  in_degree_714  1
    arc_0_10_5  out_degree_732  1
    arc_0_10_5  original_T_including_depot_unload_772  2.5651522766561479e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_5  arc_capacity_542  1
    load_0_10_5  segment_load_conservation_717  -1
    load_0_10_5  segment_prefix_lb_718  1
    load_0_10_5  segment_prefix_ub_719  1
    load_0_10_5  free_load_conservation_737  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_8  arc_capacity_544  -30
    arc_0_10_8  connected_order_arc_545  -14
    arc_0_10_8  in_degree_721  1
    arc_0_10_8  out_degree_732  1
    arc_0_10_8  original_T_including_depot_unload_772  3.0726580305165480e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_8  arc_capacity_544  1
    load_0_10_8  free_load_conservation_725  -1
    load_0_10_8  free_load_conservation_737  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_9  arc_capacity_546  -30
    arc_0_10_9  connected_order_arc_547  -14
    arc_0_10_9  in_degree_727  1
    arc_0_10_9  out_degree_732  1
    arc_0_10_9  original_T_including_depot_unload_772  2.8807002034504962e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_9  arc_capacity_546  1
    load_0_10_9  free_load_conservation_731  -1
    load_0_10_9  free_load_conservation_737  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_11  arc_capacity_548  -30
    arc_0_10_11  connected_order_arc_549  -14
    arc_0_10_11  out_degree_732  1
    arc_0_10_11  in_degree_739  1
    arc_0_10_11  original_T_including_depot_unload_772  2.8834086639088187e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_11  arc_capacity_548  1
    load_0_10_11  free_load_conservation_737  1
    load_0_10_11  free_load_conservation_743  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_12  arc_capacity_550  -30
    arc_0_10_12  connected_order_arc_551  -14
    arc_0_10_12  out_degree_732  1
    arc_0_10_12  in_degree_745  1
    arc_0_10_12  original_T_including_depot_unload_772  4.1686506413165080e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_12  arc_capacity_550  1
    load_0_10_12  free_load_conservation_737  1
    load_0_10_12  free_load_conservation_749  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_13  arc_capacity_552  -30
    arc_0_10_13  connected_order_arc_553  -14
    arc_0_10_13  out_degree_732  1
    arc_0_10_13  in_degree_751  1
    arc_0_10_13  original_T_including_depot_unload_772  3.3076115257178203e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_13  arc_capacity_552  1
    load_0_10_13  free_load_conservation_737  1
    load_0_10_13  free_load_conservation_755  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_14  arc_capacity_554  -30
    arc_0_10_14  connected_order_arc_555  -14
    arc_0_10_14  out_degree_732  1
    arc_0_10_14  in_degree_757  1
    arc_0_10_14  original_T_including_depot_unload_772  2.6728511574036233e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_14  arc_capacity_554  1
    load_0_10_14  free_load_conservation_737  1
    load_0_10_14  free_load_conservation_761  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_15  arc_capacity_556  -30
    arc_0_10_15  connected_order_arc_557  -14
    arc_0_10_15  out_degree_732  1
    arc_0_10_15  in_degree_763  1
    arc_0_10_15  original_T_including_depot_unload_772  2.8839695646198670e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_15  arc_capacity_556  1
    load_0_10_15  free_load_conservation_737  1
    load_0_10_15  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_0  arc_capacity_558  -30
    arc_0_11_0  depot_return_or_bypass_684  1
    arc_0_11_0  out_degree_738  1
    arc_0_11_0  original_T_including_depot_unload_772  8.2548955430739034e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_11_0  arc_capacity_558  1
    load_0_11_0  free_load_conservation_743  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_1  arc_capacity_559  -30
    arc_0_11_1  connected_order_arc_560  -14
    arc_0_11_1  in_degree_686  1
    arc_0_11_1  out_degree_738  1
    arc_0_11_1  original_T_including_depot_unload_772  1.1046832181240914e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_1  arc_capacity_559  1
    load_0_11_1  segment_load_conservation_689  -1
    load_0_11_1  segment_prefix_lb_690  1
    load_0_11_1  segment_prefix_ub_691  1
    load_0_11_1  free_load_conservation_743  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_2  arc_capacity_561  -30
    arc_0_11_2  connected_order_arc_562  -14
    arc_0_11_2  in_degree_693  1
    arc_0_11_2  out_degree_738  1
    arc_0_11_2  original_T_including_depot_unload_772  4.1346687597344868e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_11_2  arc_capacity_561  1
    load_0_11_2  segment_load_conservation_696  -1
    load_0_11_2  segment_prefix_lb_697  1
    load_0_11_2  segment_prefix_ub_698  1
    load_0_11_2  free_load_conservation_743  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_3  arc_capacity_563  -30
    arc_0_11_3  connected_order_arc_564  -14
    arc_0_11_3  in_degree_700  1
    arc_0_11_3  out_degree_738  1
    arc_0_11_3  original_T_including_depot_unload_772  3.7295617536174859e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_11_3  arc_capacity_563  1
    load_0_11_3  segment_load_conservation_703  -1
    load_0_11_3  segment_prefix_lb_704  1
    load_0_11_3  segment_prefix_ub_705  1
    load_0_11_3  free_load_conservation_743  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_4  arc_capacity_565  -30
    arc_0_11_4  connected_order_arc_566  -14
    arc_0_11_4  in_degree_707  1
    arc_0_11_4  out_degree_738  1
    arc_0_11_4  original_T_including_depot_unload_772  2.6991456262177837e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_11_4  arc_capacity_565  1
    load_0_11_4  segment_load_conservation_710  -1
    load_0_11_4  segment_prefix_lb_711  1
    load_0_11_4  segment_prefix_ub_712  1
    load_0_11_4  free_load_conservation_743  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_5  arc_capacity_567  -30
    arc_0_11_5  connected_order_arc_568  -14
    arc_0_11_5  in_degree_714  1
    arc_0_11_5  out_degree_738  1
    arc_0_11_5  original_T_including_depot_unload_772  4.1180717113418365e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_11_5  arc_capacity_567  1
    load_0_11_5  segment_load_conservation_717  -1
    load_0_11_5  segment_prefix_lb_718  1
    load_0_11_5  segment_prefix_ub_719  1
    load_0_11_5  free_load_conservation_743  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_8  arc_capacity_569  -30
    arc_0_11_8  connected_order_arc_570  -14
    arc_0_11_8  in_degree_721  1
    arc_0_11_8  out_degree_738  1
    arc_0_11_8  original_T_including_depot_unload_772  2.0241950709354862e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_11_8  arc_capacity_569  1
    load_0_11_8  free_load_conservation_725  -1
    load_0_11_8  free_load_conservation_743  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_9  arc_capacity_571  -30
    arc_0_11_9  connected_order_arc_572  -14
    arc_0_11_9  in_degree_727  1
    arc_0_11_9  out_degree_738  1
    arc_0_11_9  original_T_including_depot_unload_772  1.2673640125672841e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_11_9  arc_capacity_571  1
    load_0_11_9  free_load_conservation_731  -1
    load_0_11_9  free_load_conservation_743  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_10  arc_capacity_573  -30
    arc_0_11_10  connected_order_arc_574  -14
    arc_0_11_10  in_degree_733  1
    arc_0_11_10  out_degree_738  1
    arc_0_11_10  original_T_including_depot_unload_772  2.8834086639088187e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_10  arc_capacity_573  1
    load_0_11_10  free_load_conservation_737  -1
    load_0_11_10  free_load_conservation_743  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_12  arc_capacity_575  -30
    arc_0_11_12  connected_order_arc_576  -14
    arc_0_11_12  out_degree_738  1
    arc_0_11_12  in_degree_745  1
    arc_0_11_12  original_T_including_depot_unload_772  2.6235983504802839e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_12  arc_capacity_575  1
    load_0_11_12  free_load_conservation_743  1
    load_0_11_12  free_load_conservation_749  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_13  arc_capacity_577  -30
    arc_0_11_13  connected_order_arc_578  -14
    arc_0_11_13  out_degree_738  1
    arc_0_11_13  in_degree_751  1
    arc_0_11_13  original_T_including_depot_unload_772  4.3124580937307496e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_11_13  arc_capacity_577  1
    load_0_11_13  free_load_conservation_743  1
    load_0_11_13  free_load_conservation_755  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_14  arc_capacity_579  -30
    arc_0_11_14  connected_order_arc_580  -14
    arc_0_11_14  out_degree_738  1
    arc_0_11_14  in_degree_757  1
    arc_0_11_14  original_T_including_depot_unload_772  4.6739130846957909e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_11_14  arc_capacity_579  1
    load_0_11_14  free_load_conservation_743  1
    load_0_11_14  free_load_conservation_761  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_15  arc_capacity_581  -30
    arc_0_11_15  connected_order_arc_582  -14
    arc_0_11_15  out_degree_738  1
    arc_0_11_15  in_degree_763  1
    arc_0_11_15  original_T_including_depot_unload_772  1.5413712102626312e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_11_15  arc_capacity_581  1
    load_0_11_15  free_load_conservation_743  1
    load_0_11_15  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_0  arc_capacity_583  -30
    arc_0_12_0  depot_return_or_bypass_684  1
    arc_0_12_0  out_degree_744  1
    arc_0_12_0  original_T_including_depot_unload_772  2.2866763971369810e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_0  arc_capacity_583  1
    load_0_12_0  free_load_conservation_749  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_1  arc_capacity_584  -30
    arc_0_12_1  connected_order_arc_585  -14
    arc_0_12_1  in_degree_686  1
    arc_0_12_1  out_degree_744  1
    arc_0_12_1  original_T_including_depot_unload_772  1.9791430726365086e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_1  arc_capacity_584  1
    load_0_12_1  segment_load_conservation_689  -1
    load_0_12_1  segment_prefix_lb_690  1
    load_0_12_1  segment_prefix_ub_691  1
    load_0_12_1  free_load_conservation_749  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_2  arc_capacity_586  -30
    arc_0_12_2  connected_order_arc_587  -14
    arc_0_12_2  in_degree_693  1
    arc_0_12_2  out_degree_744  1
    arc_0_12_2  original_T_including_depot_unload_772  2.2541698308553673e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_2  arc_capacity_586  1
    load_0_12_2  segment_load_conservation_696  -1
    load_0_12_2  segment_prefix_lb_697  1
    load_0_12_2  segment_prefix_ub_698  1
    load_0_12_2  free_load_conservation_749  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_3  arc_capacity_588  -30
    arc_0_12_3  connected_order_arc_589  -14
    arc_0_12_3  in_degree_700  1
    arc_0_12_3  out_degree_744  1
    arc_0_12_3  original_T_including_depot_unload_772  2.9747397208089205e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_3  arc_capacity_588  1
    load_0_12_3  segment_load_conservation_703  -1
    load_0_12_3  segment_prefix_lb_704  1
    load_0_12_3  segment_prefix_ub_705  1
    load_0_12_3  free_load_conservation_749  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_4  arc_capacity_590  -30
    arc_0_12_4  connected_order_arc_591  -14
    arc_0_12_4  in_degree_707  1
    arc_0_12_4  out_degree_744  1
    arc_0_12_4  original_T_including_depot_unload_772  2.3958340327791907e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_4  arc_capacity_590  1
    load_0_12_4  segment_load_conservation_710  -1
    load_0_12_4  segment_prefix_lb_711  1
    load_0_12_4  segment_prefix_ub_712  1
    load_0_12_4  free_load_conservation_749  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_5  arc_capacity_592  -30
    arc_0_12_5  connected_order_arc_593  -14
    arc_0_12_5  in_degree_714  1
    arc_0_12_5  out_degree_744  1
    arc_0_12_5  original_T_including_depot_unload_772  2.4543912353372671e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_5  arc_capacity_592  1
    load_0_12_5  segment_load_conservation_717  -1
    load_0_12_5  segment_prefix_lb_718  1
    load_0_12_5  segment_prefix_ub_719  1
    load_0_12_5  free_load_conservation_749  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_8  arc_capacity_594  -30
    arc_0_12_8  connected_order_arc_595  -14
    arc_0_12_8  in_degree_721  1
    arc_0_12_8  out_degree_744  1
    arc_0_12_8  original_T_including_depot_unload_772  2.5292035468949002e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_8  arc_capacity_594  1
    load_0_12_8  free_load_conservation_725  -1
    load_0_12_8  free_load_conservation_749  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_9  arc_capacity_596  -30
    arc_0_12_9  connected_order_arc_597  -14
    arc_0_12_9  in_degree_727  1
    arc_0_12_9  out_degree_744  1
    arc_0_12_9  original_T_including_depot_unload_772  2.4992063774241742e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_9  arc_capacity_596  1
    load_0_12_9  free_load_conservation_731  -1
    load_0_12_9  free_load_conservation_749  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_10  arc_capacity_598  -30
    arc_0_12_10  connected_order_arc_599  -14
    arc_0_12_10  in_degree_733  1
    arc_0_12_10  out_degree_744  1
    arc_0_12_10  original_T_including_depot_unload_772  4.1686506413165080e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_10  arc_capacity_598  1
    load_0_12_10  free_load_conservation_737  -1
    load_0_12_10  free_load_conservation_749  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_11  arc_capacity_600  -30
    arc_0_12_11  connected_order_arc_601  -14
    arc_0_12_11  in_degree_739  1
    arc_0_12_11  out_degree_744  1
    arc_0_12_11  original_T_including_depot_unload_772  2.6235983504802839e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_11  arc_capacity_600  1
    load_0_12_11  free_load_conservation_743  -1
    load_0_12_11  free_load_conservation_749  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_13  arc_capacity_602  -30
    arc_0_12_13  connected_order_arc_603  -14
    arc_0_12_13  out_degree_744  1
    arc_0_12_13  in_degree_751  1
    arc_0_12_13  original_T_including_depot_unload_772  2.6797194604092651e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_13  arc_capacity_602  1
    load_0_12_13  free_load_conservation_749  1
    load_0_12_13  free_load_conservation_755  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_14  arc_capacity_604  -30
    arc_0_12_14  connected_order_arc_605  -14
    arc_0_12_14  out_degree_744  1
    arc_0_12_14  in_degree_757  1
    arc_0_12_14  original_T_including_depot_unload_772  2.2811398160464278e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_14  arc_capacity_604  1
    load_0_12_14  free_load_conservation_749  1
    load_0_12_14  free_load_conservation_761  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_15  arc_capacity_606  -30
    arc_0_12_15  connected_order_arc_607  -14
    arc_0_12_15  out_degree_744  1
    arc_0_12_15  in_degree_763  1
    arc_0_12_15  original_T_including_depot_unload_772  2.7766616410403444e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_15  arc_capacity_606  1
    load_0_12_15  free_load_conservation_749  1
    load_0_12_15  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_0  arc_capacity_608  -30
    arc_0_13_0  depot_return_or_bypass_684  1
    arc_0_13_0  out_degree_750  1
    arc_0_13_0  original_T_including_depot_unload_772  1.2186896810212775e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_0  arc_capacity_608  1
    load_0_13_0  free_load_conservation_755  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_1  arc_capacity_609  -30
    arc_0_13_1  connected_order_arc_610  -14
    arc_0_13_1  in_degree_686  1
    arc_0_13_1  out_degree_750  1
    arc_0_13_1  original_T_including_depot_unload_772  1.4485896981484648e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_1  arc_capacity_609  1
    load_0_13_1  segment_load_conservation_689  -1
    load_0_13_1  segment_prefix_lb_690  1
    load_0_13_1  segment_prefix_ub_691  1
    load_0_13_1  free_load_conservation_755  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_2  arc_capacity_611  -30
    arc_0_13_2  connected_order_arc_612  -14
    arc_0_13_2  in_degree_693  1
    arc_0_13_2  out_degree_750  1
    arc_0_13_2  original_T_including_depot_unload_772  7.2186296856879846e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_2  arc_capacity_611  1
    load_0_13_2  segment_load_conservation_696  -1
    load_0_13_2  segment_prefix_lb_697  1
    load_0_13_2  segment_prefix_ub_698  1
    load_0_13_2  free_load_conservation_755  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_3  arc_capacity_613  -30
    arc_0_13_3  connected_order_arc_614  -14
    arc_0_13_3  in_degree_700  1
    arc_0_13_3  out_degree_750  1
    arc_0_13_3  original_T_including_depot_unload_772  4.4158457011124148e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_3  arc_capacity_613  1
    load_0_13_3  segment_load_conservation_703  -1
    load_0_13_3  segment_prefix_lb_704  1
    load_0_13_3  segment_prefix_ub_705  1
    load_0_13_3  free_load_conservation_755  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_4  arc_capacity_615  -30
    arc_0_13_4  connected_order_arc_616  -14
    arc_0_13_4  in_degree_707  1
    arc_0_13_4  out_degree_750  1
    arc_0_13_4  original_T_including_depot_unload_772  6.2279118029742506e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_4  arc_capacity_615  1
    load_0_13_4  segment_load_conservation_710  -1
    load_0_13_4  segment_prefix_lb_711  1
    load_0_13_4  segment_prefix_ub_712  1
    load_0_13_4  free_load_conservation_755  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_5  arc_capacity_617  -30
    arc_0_13_5  connected_order_arc_618  -14
    arc_0_13_5  in_degree_714  1
    arc_0_13_5  out_degree_750  1
    arc_0_13_5  original_T_including_depot_unload_772  8.2210727717430609e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_5  arc_capacity_617  1
    load_0_13_5  segment_load_conservation_717  -1
    load_0_13_5  segment_prefix_lb_718  1
    load_0_13_5  segment_prefix_ub_719  1
    load_0_13_5  free_load_conservation_755  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_8  arc_capacity_619  -30
    arc_0_13_8  connected_order_arc_620  -14
    arc_0_13_8  in_degree_721  1
    arc_0_13_8  out_degree_750  1
    arc_0_13_8  original_T_including_depot_unload_772  2.8260257937815851e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_8  arc_capacity_619  1
    load_0_13_8  free_load_conservation_725  -1
    load_0_13_8  free_load_conservation_755  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_9  arc_capacity_621  -30
    arc_0_13_9  connected_order_arc_622  -14
    arc_0_13_9  in_degree_727  1
    arc_0_13_9  out_degree_750  1
    arc_0_13_9  original_T_including_depot_unload_772  4.7721499161748335e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_9  arc_capacity_621  1
    load_0_13_9  free_load_conservation_731  -1
    load_0_13_9  free_load_conservation_755  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_10  arc_capacity_623  -30
    arc_0_13_10  connected_order_arc_624  -14
    arc_0_13_10  in_degree_733  1
    arc_0_13_10  out_degree_750  1
    arc_0_13_10  original_T_including_depot_unload_772  3.3076115257178203e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_10  arc_capacity_623  1
    load_0_13_10  free_load_conservation_737  -1
    load_0_13_10  free_load_conservation_755  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_11  arc_capacity_625  -30
    arc_0_13_11  connected_order_arc_626  -14
    arc_0_13_11  in_degree_739  1
    arc_0_13_11  out_degree_750  1
    arc_0_13_11  original_T_including_depot_unload_772  4.3124580937307496e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_11  arc_capacity_625  1
    load_0_13_11  free_load_conservation_743  -1
    load_0_13_11  free_load_conservation_755  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_12  arc_capacity_627  -30
    arc_0_13_12  connected_order_arc_628  -14
    arc_0_13_12  in_degree_745  1
    arc_0_13_12  out_degree_750  1
    arc_0_13_12  original_T_including_depot_unload_772  2.6797194604092651e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_12  arc_capacity_627  1
    load_0_13_12  free_load_conservation_749  -1
    load_0_13_12  free_load_conservation_755  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_14  arc_capacity_629  -30
    arc_0_13_14  connected_order_arc_630  -14
    arc_0_13_14  out_degree_750  1
    arc_0_13_14  in_degree_757  1
    arc_0_13_14  original_T_including_depot_unload_772  8.2145202724109538e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_14  arc_capacity_629  1
    load_0_13_14  free_load_conservation_755  1
    load_0_13_14  free_load_conservation_761  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_15  arc_capacity_631  -30
    arc_0_13_15  connected_order_arc_632  -14
    arc_0_13_15  out_degree_750  1
    arc_0_13_15  in_degree_763  1
    arc_0_13_15  original_T_including_depot_unload_772  4.3257823465305182e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_15  arc_capacity_631  1
    load_0_13_15  free_load_conservation_755  1
    load_0_13_15  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_0  arc_capacity_633  -30
    arc_0_14_0  depot_return_or_bypass_684  1
    arc_0_14_0  out_degree_756  1
    arc_0_14_0  original_T_including_depot_unload_772  4.0782796387128610e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_0  arc_capacity_633  1
    load_0_14_0  free_load_conservation_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_1  arc_capacity_634  -30
    arc_0_14_1  connected_order_arc_635  -14
    arc_0_14_1  in_degree_686  1
    arc_0_14_1  out_degree_756  1
    arc_0_14_1  original_T_including_depot_unload_772  6.3975035388222534e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_1  arc_capacity_634  1
    load_0_14_1  segment_load_conservation_689  -1
    load_0_14_1  segment_prefix_lb_690  1
    load_0_14_1  segment_prefix_ub_691  1
    load_0_14_1  free_load_conservation_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_2  arc_capacity_636  -30
    arc_0_14_2  connected_order_arc_637  -14
    arc_0_14_2  in_degree_693  1
    arc_0_14_2  out_degree_756  1
    arc_0_14_2  original_T_including_depot_unload_772  1.2480053261465446e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_2  arc_capacity_636  1
    load_0_14_2  segment_load_conservation_696  -1
    load_0_14_2  segment_prefix_lb_697  1
    load_0_14_2  segment_prefix_ub_698  1
    load_0_14_2  free_load_conservation_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_3  arc_capacity_638  -30
    arc_0_14_3  connected_order_arc_639  -14
    arc_0_14_3  in_degree_700  1
    arc_0_14_3  out_degree_756  1
    arc_0_14_3  original_T_including_depot_unload_772  8.2982882938703278e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_3  arc_capacity_638  1
    load_0_14_3  segment_load_conservation_703  -1
    load_0_14_3  segment_prefix_lb_704  1
    load_0_14_3  segment_prefix_ub_705  1
    load_0_14_3  free_load_conservation_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_4  arc_capacity_640  -30
    arc_0_14_4  connected_order_arc_641  -14
    arc_0_14_4  in_degree_707  1
    arc_0_14_4  out_degree_756  1
    arc_0_14_4  original_T_including_depot_unload_772  2.0430160967046345e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_4  arc_capacity_640  1
    load_0_14_4  segment_load_conservation_710  -1
    load_0_14_4  segment_prefix_lb_711  1
    load_0_14_4  segment_prefix_ub_712  1
    load_0_14_4  free_load_conservation_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_5  arc_capacity_642  -30
    arc_0_14_5  connected_order_arc_643  -14
    arc_0_14_5  in_degree_714  1
    arc_0_14_5  out_degree_756  1
    arc_0_14_5  original_T_including_depot_unload_772  1.7839442696984972e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_5  arc_capacity_642  1
    load_0_14_5  segment_load_conservation_717  -1
    load_0_14_5  segment_prefix_lb_718  1
    load_0_14_5  segment_prefix_ub_719  1
    load_0_14_5  free_load_conservation_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_8  arc_capacity_644  -30
    arc_0_14_8  connected_order_arc_645  -14
    arc_0_14_8  in_degree_721  1
    arc_0_14_8  out_degree_756  1
    arc_0_14_8  original_T_including_depot_unload_772  5.3918604589472477e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_8  arc_capacity_644  1
    load_0_14_8  free_load_conservation_725  -1
    load_0_14_8  free_load_conservation_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_9  arc_capacity_646  -30
    arc_0_14_9  connected_order_arc_647  -14
    arc_0_14_9  in_degree_727  1
    arc_0_14_9  out_degree_756  1
    arc_0_14_9  original_T_including_depot_unload_772  3.6114004430677619e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_9  arc_capacity_646  1
    load_0_14_9  free_load_conservation_731  -1
    load_0_14_9  free_load_conservation_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_10  arc_capacity_648  -30
    arc_0_14_10  connected_order_arc_649  -14
    arc_0_14_10  in_degree_733  1
    arc_0_14_10  out_degree_756  1
    arc_0_14_10  original_T_including_depot_unload_772  2.6728511574036233e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_10  arc_capacity_648  1
    load_0_14_10  free_load_conservation_737  -1
    load_0_14_10  free_load_conservation_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_11  arc_capacity_650  -30
    arc_0_14_11  connected_order_arc_651  -14
    arc_0_14_11  in_degree_739  1
    arc_0_14_11  out_degree_756  1
    arc_0_14_11  original_T_including_depot_unload_772  4.6739130846957909e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_11  arc_capacity_650  1
    load_0_14_11  free_load_conservation_743  -1
    load_0_14_11  free_load_conservation_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_12  arc_capacity_652  -30
    arc_0_14_12  connected_order_arc_653  -14
    arc_0_14_12  in_degree_745  1
    arc_0_14_12  out_degree_756  1
    arc_0_14_12  original_T_including_depot_unload_772  2.2811398160464278e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_12  arc_capacity_652  1
    load_0_14_12  free_load_conservation_749  -1
    load_0_14_12  free_load_conservation_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_13  arc_capacity_654  -30
    arc_0_14_13  connected_order_arc_655  -14
    arc_0_14_13  in_degree_751  1
    arc_0_14_13  out_degree_756  1
    arc_0_14_13  original_T_including_depot_unload_772  8.2145202724109538e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_13  arc_capacity_654  1
    load_0_14_13  free_load_conservation_755  -1
    load_0_14_13  free_load_conservation_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_15  arc_capacity_656  -30
    arc_0_14_15  connected_order_arc_657  -14
    arc_0_14_15  out_degree_756  1
    arc_0_14_15  in_degree_763  1
    arc_0_14_15  original_T_including_depot_unload_772  6.0329604828085382e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_15  arc_capacity_656  1
    load_0_14_15  free_load_conservation_761  1
    load_0_14_15  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_0  arc_capacity_658  -30
    arc_0_15_0  depot_return_or_bypass_684  1
    arc_0_15_0  out_degree_762  1
    arc_0_15_0  original_T_including_depot_unload_772  9.3133633713881534e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_0  arc_capacity_658  1
    load_0_15_0  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_1  arc_capacity_659  -30
    arc_0_15_1  connected_order_arc_660  -14
    arc_0_15_1  in_degree_686  1
    arc_0_15_1  out_degree_762  1
    arc_0_15_1  original_T_including_depot_unload_772  1.2315777010885340e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_1  arc_capacity_659  1
    load_0_15_1  segment_load_conservation_689  -1
    load_0_15_1  segment_prefix_lb_690  1
    load_0_15_1  segment_prefix_ub_691  1
    load_0_15_1  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_2  arc_capacity_661  -30
    arc_0_15_2  connected_order_arc_662  -14
    arc_0_15_2  in_degree_693  1
    arc_0_15_2  out_degree_762  1
    arc_0_15_2  original_T_including_depot_unload_772  5.6231331158364958e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_2  arc_capacity_661  1
    load_0_15_2  segment_load_conservation_696  -1
    load_0_15_2  segment_prefix_lb_697  1
    load_0_15_2  segment_prefix_ub_698  1
    load_0_15_2  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_3  arc_capacity_663  -30
    arc_0_15_3  connected_order_arc_664  -14
    arc_0_15_3  in_degree_700  1
    arc_0_15_3  out_degree_762  1
    arc_0_15_3  original_T_including_depot_unload_772  2.2655310037545112e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_3  arc_capacity_663  1
    load_0_15_3  segment_load_conservation_703  -1
    load_0_15_3  segment_prefix_lb_704  1
    load_0_15_3  segment_prefix_ub_705  1
    load_0_15_3  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_4  arc_capacity_665  -30
    arc_0_15_4  connected_order_arc_666  -14
    arc_0_15_4  in_degree_707  1
    arc_0_15_4  out_degree_762  1
    arc_0_15_4  original_T_including_depot_unload_772  4.1557375918514475e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_4  arc_capacity_665  1
    load_0_15_4  segment_load_conservation_710  -1
    load_0_15_4  segment_prefix_lb_711  1
    load_0_15_4  segment_prefix_ub_712  1
    load_0_15_4  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_5  arc_capacity_667  -30
    arc_0_15_5  connected_order_arc_668  -14
    arc_0_15_5  in_degree_714  1
    arc_0_15_5  out_degree_762  1
    arc_0_15_5  original_T_including_depot_unload_772  516.598297486096
    MARKER    'MARKER'                 'INTEND'
    load_0_15_5  arc_capacity_667  1
    load_0_15_5  segment_load_conservation_717  -1
    load_0_15_5  segment_prefix_lb_718  1
    load_0_15_5  segment_prefix_ub_719  1
    load_0_15_5  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_8  arc_capacity_669  -30
    arc_0_15_8  connected_order_arc_670  -14
    arc_0_15_8  in_degree_721  1
    arc_0_15_8  out_degree_762  1
    arc_0_15_8  original_T_including_depot_unload_772  2.9819555494495978e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_8  arc_capacity_669  1
    load_0_15_8  free_load_conservation_725  -1
    load_0_15_8  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_9  arc_capacity_671  -30
    arc_0_15_9  connected_order_arc_672  -14
    arc_0_15_9  in_degree_727  1
    arc_0_15_9  out_degree_762  1
    arc_0_15_9  original_T_including_depot_unload_772  2.8072002002622634e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_9  arc_capacity_671  1
    load_0_15_9  free_load_conservation_731  -1
    load_0_15_9  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_10  arc_capacity_673  -30
    arc_0_15_10  connected_order_arc_674  -14
    arc_0_15_10  in_degree_733  1
    arc_0_15_10  out_degree_762  1
    arc_0_15_10  original_T_including_depot_unload_772  2.8839695646198670e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_10  arc_capacity_673  1
    load_0_15_10  free_load_conservation_737  -1
    load_0_15_10  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_11  arc_capacity_675  -30
    arc_0_15_11  connected_order_arc_676  -14
    arc_0_15_11  in_degree_739  1
    arc_0_15_11  out_degree_762  1
    arc_0_15_11  original_T_including_depot_unload_772  1.5413712102626312e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_11  arc_capacity_675  1
    load_0_15_11  free_load_conservation_743  -1
    load_0_15_11  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_12  arc_capacity_677  -30
    arc_0_15_12  connected_order_arc_678  -14
    arc_0_15_12  in_degree_745  1
    arc_0_15_12  out_degree_762  1
    arc_0_15_12  original_T_including_depot_unload_772  2.7766616410403444e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_12  arc_capacity_677  1
    load_0_15_12  free_load_conservation_749  -1
    load_0_15_12  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_13  arc_capacity_679  -30
    arc_0_15_13  connected_order_arc_680  -14
    arc_0_15_13  in_degree_751  1
    arc_0_15_13  out_degree_762  1
    arc_0_15_13  original_T_including_depot_unload_772  4.3257823465305182e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_13  arc_capacity_679  1
    load_0_15_13  free_load_conservation_755  -1
    load_0_15_13  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_14  arc_capacity_681  -30
    arc_0_15_14  connected_order_arc_682  -14
    arc_0_15_14  in_degree_757  1
    arc_0_15_14  out_degree_762  1
    arc_0_15_14  original_T_including_depot_unload_772  6.0329604828085382e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_14  arc_capacity_681  1
    load_0_15_14  free_load_conservation_761  -1
    load_0_15_14  free_load_conservation_767  1
    visit_1_6  out_degree_976  -1
    visit_1_6  in_degree_977  -1
    visit_1_6  order_active_lb_978  -1
    visit_1_6  order_active_ub_979  -10
    order_1_6  connected_order_arc_786  -1
    order_1_6  connected_order_arc_788  -1
    order_1_6  connected_order_arc_790  -1
    order_1_6  connected_order_arc_792  -1
    order_1_6  connected_order_arc_794  -1
    order_1_6  connected_order_arc_796  -1
    order_1_6  connected_order_arc_798  -1
    order_1_6  connected_order_arc_800  -1
    order_1_6  connected_order_arc_802  -1
    order_1_6  connected_order_arc_805  1
    order_1_6  connected_order_arc_824  1
    order_1_6  connected_order_arc_843  1
    order_1_6  connected_order_arc_862  1
    order_1_6  connected_order_arc_881  1
    order_1_6  connected_order_arc_900  1
    order_1_6  connected_order_arc_919  1
    order_1_6  connected_order_arc_938  1
    order_1_6  connected_order_arc_957  1
    order_1_6  order_active_lb_978  1
    order_1_6  order_active_ub_979  1
    order_1_6  fixed_segment_relative_order_1038  -1
    visit_1_7  out_degree_983  -1
    visit_1_7  in_degree_984  -1
    visit_1_7  order_active_lb_985  -1
    visit_1_7  order_active_ub_986  -10
    order_1_7  connected_order_arc_786  1
    order_1_7  connected_order_arc_805  -1
    order_1_7  connected_order_arc_807  -1
    order_1_7  connected_order_arc_809  -1
    order_1_7  connected_order_arc_811  -1
    order_1_7  connected_order_arc_813  -1
    order_1_7  connected_order_arc_815  -1
    order_1_7  connected_order_arc_817  -1
    order_1_7  connected_order_arc_819  -1
    order_1_7  connected_order_arc_821  -1
    order_1_7  connected_order_arc_826  1
    order_1_7  connected_order_arc_845  1
    order_1_7  connected_order_arc_864  1
    order_1_7  connected_order_arc_883  1
    order_1_7  connected_order_arc_902  1
    order_1_7  connected_order_arc_921  1
    order_1_7  connected_order_arc_940  1
    order_1_7  connected_order_arc_959  1
    order_1_7  order_active_lb_985  1
    order_1_7  order_active_ub_986  1
    order_1_7  fixed_segment_relative_order_1038  1
    visit_1_8  out_degree_990  -1
    visit_1_8  in_degree_991  -1
    visit_1_8  order_active_lb_992  -1
    visit_1_8  order_active_ub_993  -10
    visit_1_8  service_visit_def_994  -1
    order_1_8  connected_order_arc_788  1
    order_1_8  connected_order_arc_807  1
    order_1_8  connected_order_arc_824  -1
    order_1_8  connected_order_arc_826  -1
    order_1_8  connected_order_arc_828  -1
    order_1_8  connected_order_arc_830  -1
    order_1_8  connected_order_arc_832  -1
    order_1_8  connected_order_arc_834  -1
    order_1_8  connected_order_arc_836  -1
    order_1_8  connected_order_arc_838  -1
    order_1_8  connected_order_arc_840  -1
    order_1_8  connected_order_arc_847  1
    order_1_8  connected_order_arc_866  1
    order_1_8  connected_order_arc_885  1
    order_1_8  connected_order_arc_904  1
    order_1_8  connected_order_arc_923  1
    order_1_8  connected_order_arc_942  1
    order_1_8  connected_order_arc_961  1
    order_1_8  order_active_lb_992  1
    order_1_8  order_active_ub_993  1
    visit_1_9  out_degree_996  -1
    visit_1_9  in_degree_997  -1
    visit_1_9  order_active_lb_998  -1
    visit_1_9  order_active_ub_999  -10
    visit_1_9  service_visit_def_1000  -1
    order_1_9  connected_order_arc_790  1
    order_1_9  connected_order_arc_809  1
    order_1_9  connected_order_arc_828  1
    order_1_9  connected_order_arc_843  -1
    order_1_9  connected_order_arc_845  -1
    order_1_9  connected_order_arc_847  -1
    order_1_9  connected_order_arc_849  -1
    order_1_9  connected_order_arc_851  -1
    order_1_9  connected_order_arc_853  -1
    order_1_9  connected_order_arc_855  -1
    order_1_9  connected_order_arc_857  -1
    order_1_9  connected_order_arc_859  -1
    order_1_9  connected_order_arc_868  1
    order_1_9  connected_order_arc_887  1
    order_1_9  connected_order_arc_906  1
    order_1_9  connected_order_arc_925  1
    order_1_9  connected_order_arc_944  1
    order_1_9  connected_order_arc_963  1
    order_1_9  order_active_lb_998  1
    order_1_9  order_active_ub_999  1
    visit_1_10  out_degree_1002  -1
    visit_1_10  in_degree_1003  -1
    visit_1_10  order_active_lb_1004  -1
    visit_1_10  order_active_ub_1005  -10
    visit_1_10  service_visit_def_1006  -1
    order_1_10  connected_order_arc_792  1
    order_1_10  connected_order_arc_811  1
    order_1_10  connected_order_arc_830  1
    order_1_10  connected_order_arc_849  1
    order_1_10  connected_order_arc_862  -1
    order_1_10  connected_order_arc_864  -1
    order_1_10  connected_order_arc_866  -1
    order_1_10  connected_order_arc_868  -1
    order_1_10  connected_order_arc_870  -1
    order_1_10  connected_order_arc_872  -1
    order_1_10  connected_order_arc_874  -1
    order_1_10  connected_order_arc_876  -1
    order_1_10  connected_order_arc_878  -1
    order_1_10  connected_order_arc_889  1
    order_1_10  connected_order_arc_908  1
    order_1_10  connected_order_arc_927  1
    order_1_10  connected_order_arc_946  1
    order_1_10  connected_order_arc_965  1
    order_1_10  order_active_lb_1004  1
    order_1_10  order_active_ub_1005  1
    visit_1_11  out_degree_1008  -1
    visit_1_11  in_degree_1009  -1
    visit_1_11  order_active_lb_1010  -1
    visit_1_11  order_active_ub_1011  -10
    visit_1_11  service_visit_def_1012  -1
    order_1_11  connected_order_arc_794  1
    order_1_11  connected_order_arc_813  1
    order_1_11  connected_order_arc_832  1
    order_1_11  connected_order_arc_851  1
    order_1_11  connected_order_arc_870  1
    order_1_11  connected_order_arc_881  -1
    order_1_11  connected_order_arc_883  -1
    order_1_11  connected_order_arc_885  -1
    order_1_11  connected_order_arc_887  -1
    order_1_11  connected_order_arc_889  -1
    order_1_11  connected_order_arc_891  -1
    order_1_11  connected_order_arc_893  -1
    order_1_11  connected_order_arc_895  -1
    order_1_11  connected_order_arc_897  -1
    order_1_11  connected_order_arc_910  1
    order_1_11  connected_order_arc_929  1
    order_1_11  connected_order_arc_948  1
    order_1_11  connected_order_arc_967  1
    order_1_11  order_active_lb_1010  1
    order_1_11  order_active_ub_1011  1
    visit_1_12  out_degree_1014  -1
    visit_1_12  in_degree_1015  -1
    visit_1_12  order_active_lb_1016  -1
    visit_1_12  order_active_ub_1017  -10
    visit_1_12  service_visit_def_1018  -1
    order_1_12  connected_order_arc_796  1
    order_1_12  connected_order_arc_815  1
    order_1_12  connected_order_arc_834  1
    order_1_12  connected_order_arc_853  1
    order_1_12  connected_order_arc_872  1
    order_1_12  connected_order_arc_891  1
    order_1_12  connected_order_arc_900  -1
    order_1_12  connected_order_arc_902  -1
    order_1_12  connected_order_arc_904  -1
    order_1_12  connected_order_arc_906  -1
    order_1_12  connected_order_arc_908  -1
    order_1_12  connected_order_arc_910  -1
    order_1_12  connected_order_arc_912  -1
    order_1_12  connected_order_arc_914  -1
    order_1_12  connected_order_arc_916  -1
    order_1_12  connected_order_arc_931  1
    order_1_12  connected_order_arc_950  1
    order_1_12  connected_order_arc_969  1
    order_1_12  order_active_lb_1016  1
    order_1_12  order_active_ub_1017  1
    visit_1_13  out_degree_1020  -1
    visit_1_13  in_degree_1021  -1
    visit_1_13  order_active_lb_1022  -1
    visit_1_13  order_active_ub_1023  -10
    visit_1_13  service_visit_def_1024  -1
    order_1_13  connected_order_arc_798  1
    order_1_13  connected_order_arc_817  1
    order_1_13  connected_order_arc_836  1
    order_1_13  connected_order_arc_855  1
    order_1_13  connected_order_arc_874  1
    order_1_13  connected_order_arc_893  1
    order_1_13  connected_order_arc_912  1
    order_1_13  connected_order_arc_919  -1
    order_1_13  connected_order_arc_921  -1
    order_1_13  connected_order_arc_923  -1
    order_1_13  connected_order_arc_925  -1
    order_1_13  connected_order_arc_927  -1
    order_1_13  connected_order_arc_929  -1
    order_1_13  connected_order_arc_931  -1
    order_1_13  connected_order_arc_933  -1
    order_1_13  connected_order_arc_935  -1
    order_1_13  connected_order_arc_952  1
    order_1_13  connected_order_arc_971  1
    order_1_13  order_active_lb_1022  1
    order_1_13  order_active_ub_1023  1
    visit_1_14  out_degree_1026  -1
    visit_1_14  in_degree_1027  -1
    visit_1_14  order_active_lb_1028  -1
    visit_1_14  order_active_ub_1029  -10
    visit_1_14  service_visit_def_1030  -1
    order_1_14  connected_order_arc_800  1
    order_1_14  connected_order_arc_819  1
    order_1_14  connected_order_arc_838  1
    order_1_14  connected_order_arc_857  1
    order_1_14  connected_order_arc_876  1
    order_1_14  connected_order_arc_895  1
    order_1_14  connected_order_arc_914  1
    order_1_14  connected_order_arc_933  1
    order_1_14  connected_order_arc_938  -1
    order_1_14  connected_order_arc_940  -1
    order_1_14  connected_order_arc_942  -1
    order_1_14  connected_order_arc_944  -1
    order_1_14  connected_order_arc_946  -1
    order_1_14  connected_order_arc_948  -1
    order_1_14  connected_order_arc_950  -1
    order_1_14  connected_order_arc_952  -1
    order_1_14  connected_order_arc_954  -1
    order_1_14  connected_order_arc_973  1
    order_1_14  order_active_lb_1028  1
    order_1_14  order_active_ub_1029  1
    visit_1_15  out_degree_1032  -1
    visit_1_15  in_degree_1033  -1
    visit_1_15  order_active_lb_1034  -1
    visit_1_15  order_active_ub_1035  -10
    visit_1_15  service_visit_def_1036  -1
    order_1_15  connected_order_arc_802  1
    order_1_15  connected_order_arc_821  1
    order_1_15  connected_order_arc_840  1
    order_1_15  connected_order_arc_859  1
    order_1_15  connected_order_arc_878  1
    order_1_15  connected_order_arc_897  1
    order_1_15  connected_order_arc_916  1
    order_1_15  connected_order_arc_935  1
    order_1_15  connected_order_arc_954  1
    order_1_15  connected_order_arc_957  -1
    order_1_15  connected_order_arc_959  -1
    order_1_15  connected_order_arc_961  -1
    order_1_15  connected_order_arc_963  -1
    order_1_15  connected_order_arc_965  -1
    order_1_15  connected_order_arc_967  -1
    order_1_15  connected_order_arc_969  -1
    order_1_15  connected_order_arc_971  -1
    order_1_15  connected_order_arc_973  -1
    order_1_15  order_active_lb_1034  1
    order_1_15  order_active_ub_1035  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_0  arc_capacity_773  -30
    arc_1_0_0  depot_departure_or_bypass_974  1
    arc_1_0_0  depot_return_or_bypass_975  1
    MARKER    'MARKER'                 'INTEND'
    load_1_0_0  arc_capacity_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_6  arc_capacity_774  -30
    arc_1_0_6  depot_departure_or_bypass_974  1
    arc_1_0_6  in_degree_977  1
    arc_1_0_6  original_T_including_depot_unload_1039  1.8065333212349267e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_6  arc_capacity_774  1
    load_1_0_6  segment_load_conservation_980  -1
    load_1_0_6  segment_prefix_lb_981  1
    load_1_0_6  segment_prefix_ub_982  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_7  arc_capacity_775  -30
    arc_1_0_7  depot_departure_or_bypass_974  1
    arc_1_0_7  in_degree_984  1
    arc_1_0_7  original_T_including_depot_unload_1039  1739.61165920636
    MARKER    'MARKER'                 'INTEND'
    load_1_0_7  arc_capacity_775  1
    load_1_0_7  segment_load_conservation_987  -1
    load_1_0_7  segment_prefix_lb_988  1
    load_1_0_7  segment_prefix_ub_989  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_8  arc_capacity_776  -30
    arc_1_0_8  depot_departure_or_bypass_974  1
    arc_1_0_8  in_degree_991  1
    arc_1_0_8  original_T_including_depot_unload_1039  9.3659929340140741e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_8  arc_capacity_776  1
    load_1_0_8  free_load_conservation_995  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_9  arc_capacity_777  -30
    arc_1_0_9  depot_departure_or_bypass_974  1
    arc_1_0_9  in_degree_997  1
    arc_1_0_9  original_T_including_depot_unload_1039  7.4412496590753551e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_9  arc_capacity_777  1
    load_1_0_9  free_load_conservation_1001  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_10  arc_capacity_778  -30
    arc_1_0_10  depot_departure_or_bypass_974  1
    arc_1_0_10  in_degree_1003  1
    arc_1_0_10  original_T_including_depot_unload_1039  2.3234267380118886e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_10  arc_capacity_778  1
    load_1_0_10  free_load_conservation_1007  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_11  arc_capacity_779  -30
    arc_1_0_11  depot_departure_or_bypass_974  1
    arc_1_0_11  in_degree_1009  1
    arc_1_0_11  original_T_including_depot_unload_1039  8.2548955430739034e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_11  arc_capacity_779  1
    load_1_0_11  free_load_conservation_1013  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_12  arc_capacity_780  -30
    arc_1_0_12  depot_departure_or_bypass_974  1
    arc_1_0_12  in_degree_1015  1
    arc_1_0_12  original_T_including_depot_unload_1039  2.2866763971369810e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_12  arc_capacity_780  1
    load_1_0_12  free_load_conservation_1019  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_13  arc_capacity_781  -30
    arc_1_0_13  depot_departure_or_bypass_974  1
    arc_1_0_13  in_degree_1021  1
    arc_1_0_13  original_T_including_depot_unload_1039  1.2186896810212775e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_13  arc_capacity_781  1
    load_1_0_13  free_load_conservation_1025  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_14  arc_capacity_782  -30
    arc_1_0_14  depot_departure_or_bypass_974  1
    arc_1_0_14  in_degree_1027  1
    arc_1_0_14  original_T_including_depot_unload_1039  4.0782796387128610e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_14  arc_capacity_782  1
    load_1_0_14  free_load_conservation_1031  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_15  arc_capacity_783  -30
    arc_1_0_15  depot_departure_or_bypass_974  1
    arc_1_0_15  in_degree_1033  1
    arc_1_0_15  original_T_including_depot_unload_1039  9.3133633713881534e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_15  arc_capacity_783  1
    load_1_0_15  free_load_conservation_1037  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_0  arc_capacity_784  -30
    arc_1_6_0  depot_return_or_bypass_975  1
    arc_1_6_0  out_degree_976  1
    arc_1_6_0  original_T_including_depot_unload_1039  1.8065333212349267e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_0  arc_capacity_784  1
    load_1_6_0  segment_load_conservation_980  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_7  arc_capacity_785  -30
    arc_1_6_7  connected_order_arc_786  -11
    arc_1_6_7  out_degree_976  1
    arc_1_6_7  in_degree_984  1
    arc_1_6_7  original_T_including_depot_unload_1039  1.3126251897454844e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_7  arc_capacity_785  1
    load_1_6_7  segment_load_conservation_980  1
    load_1_6_7  segment_load_conservation_987  -1
    load_1_6_7  segment_prefix_lb_988  1
    load_1_6_7  segment_prefix_ub_989  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_8  arc_capacity_787  -30
    arc_1_6_8  connected_order_arc_788  -11
    arc_1_6_8  out_degree_976  1
    arc_1_6_8  in_degree_991  1
    arc_1_6_8  original_T_including_depot_unload_1039  2.0021738809925773e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_8  arc_capacity_787  1
    load_1_6_8  segment_load_conservation_980  1
    load_1_6_8  free_load_conservation_995  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_9  arc_capacity_789  -30
    arc_1_6_9  connected_order_arc_790  -11
    arc_1_6_9  out_degree_976  1
    arc_1_6_9  in_degree_997  1
    arc_1_6_9  original_T_including_depot_unload_1039  1.9740618091449423e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_9  arc_capacity_789  1
    load_1_6_9  segment_load_conservation_980  1
    load_1_6_9  free_load_conservation_1001  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_10  arc_capacity_791  -30
    arc_1_6_10  connected_order_arc_792  -11
    arc_1_6_10  out_degree_976  1
    arc_1_6_10  in_degree_1003  1
    arc_1_6_10  original_T_including_depot_unload_1039  3.8283958278492823e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_10  arc_capacity_791  1
    load_1_6_10  segment_load_conservation_980  1
    load_1_6_10  free_load_conservation_1007  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_11  arc_capacity_793  -30
    arc_1_6_11  connected_order_arc_794  -11
    arc_1_6_11  out_degree_976  1
    arc_1_6_11  in_degree_1009  1
    arc_1_6_11  original_T_including_depot_unload_1039  2.0979901720969542e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_11  arc_capacity_793  1
    load_1_6_11  segment_load_conservation_980  1
    load_1_6_11  free_load_conservation_1013  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_12  arc_capacity_795  -30
    arc_1_6_12  connected_order_arc_796  -11
    arc_1_6_12  out_degree_976  1
    arc_1_6_12  in_degree_1015  1
    arc_1_6_12  original_T_including_depot_unload_1039  5.2703432304351884e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_12  arc_capacity_795  1
    load_1_6_12  segment_load_conservation_980  1
    load_1_6_12  free_load_conservation_1019  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_13  arc_capacity_797  -30
    arc_1_6_13  connected_order_arc_798  -11
    arc_1_6_13  out_degree_976  1
    arc_1_6_13  in_degree_1021  1
    arc_1_6_13  original_T_including_depot_unload_1039  2.1556817566230284e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_13  arc_capacity_797  1
    load_1_6_13  segment_load_conservation_980  1
    load_1_6_13  free_load_conservation_1025  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_14  arc_capacity_799  -30
    arc_1_6_14  connected_order_arc_800  -11
    arc_1_6_14  out_degree_976  1
    arc_1_6_14  in_degree_1027  1
    arc_1_6_14  original_T_including_depot_unload_1039  1.7671662790958783e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_14  arc_capacity_799  1
    load_1_6_14  segment_load_conservation_980  1
    load_1_6_14  free_load_conservation_1031  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_15  arc_capacity_801  -30
    arc_1_6_15  connected_order_arc_802  -11
    arc_1_6_15  out_degree_976  1
    arc_1_6_15  in_degree_1033  1
    arc_1_6_15  original_T_including_depot_unload_1039  2.2507610939146793e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_15  arc_capacity_801  1
    load_1_6_15  segment_load_conservation_980  1
    load_1_6_15  free_load_conservation_1037  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_0  arc_capacity_803  -30
    arc_1_7_0  depot_return_or_bypass_975  1
    arc_1_7_0  out_degree_983  1
    arc_1_7_0  original_T_including_depot_unload_1039  1739.61165920636
    MARKER    'MARKER'                 'INTEND'
    load_1_7_0  arc_capacity_803  1
    load_1_7_0  segment_load_conservation_987  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_6  arc_capacity_804  -30
    arc_1_7_6  connected_order_arc_805  -11
    arc_1_7_6  in_degree_977  1
    arc_1_7_6  out_degree_983  1
    arc_1_7_6  original_T_including_depot_unload_1039  1.3126251897454844e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_6  arc_capacity_804  1
    load_1_7_6  segment_load_conservation_980  -1
    load_1_7_6  segment_prefix_lb_981  1
    load_1_7_6  segment_prefix_ub_982  1
    load_1_7_6  segment_load_conservation_987  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_8  arc_capacity_806  -30
    arc_1_7_8  connected_order_arc_807  -11
    arc_1_7_8  out_degree_983  1
    arc_1_7_8  in_degree_991  1
    arc_1_7_8  original_T_including_depot_unload_1039  1.9959569014367933e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_8  arc_capacity_806  1
    load_1_7_8  segment_load_conservation_987  1
    load_1_7_8  free_load_conservation_995  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_9  arc_capacity_808  -30
    arc_1_7_9  connected_order_arc_809  -11
    arc_1_7_9  out_degree_983  1
    arc_1_7_9  in_degree_997  1
    arc_1_7_9  original_T_including_depot_unload_1039  1.9548039027038737e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_9  arc_capacity_808  1
    load_1_7_9  segment_load_conservation_987  1
    load_1_7_9  free_load_conservation_1001  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_10  arc_capacity_810  -30
    arc_1_7_10  connected_order_arc_811  -11
    arc_1_7_10  out_degree_983  1
    arc_1_7_10  in_degree_1003  1
    arc_1_7_10  original_T_including_depot_unload_1039  3.7182308190042463e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_10  arc_capacity_810  1
    load_1_7_10  segment_load_conservation_987  1
    load_1_7_10  free_load_conservation_1007  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_11  arc_capacity_812  -30
    arc_1_7_11  connected_order_arc_813  -11
    arc_1_7_11  out_degree_983  1
    arc_1_7_11  in_degree_1009  1
    arc_1_7_11  original_T_including_depot_unload_1039  2.0801782775431307e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_11  arc_capacity_812  1
    load_1_7_11  segment_load_conservation_987  1
    load_1_7_11  free_load_conservation_1013  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_12  arc_capacity_814  -30
    arc_1_7_12  connected_order_arc_815  -11
    arc_1_7_12  out_degree_983  1
    arc_1_7_12  in_degree_1015  1
    arc_1_7_12  original_T_including_depot_unload_1039  5.5382752177930990e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_12  arc_capacity_814  1
    load_1_7_12  segment_load_conservation_987  1
    load_1_7_12  free_load_conservation_1019  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_13  arc_capacity_816  -30
    arc_1_7_13  connected_order_arc_817  -11
    arc_1_7_13  out_degree_983  1
    arc_1_7_13  in_degree_1021  1
    arc_1_7_13  original_T_including_depot_unload_1039  2.1641391312462424e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_13  arc_capacity_816  1
    load_1_7_13  segment_load_conservation_987  1
    load_1_7_13  free_load_conservation_1025  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_14  arc_capacity_818  -30
    arc_1_7_14  connected_order_arc_819  -11
    arc_1_7_14  out_degree_983  1
    arc_1_7_14  in_degree_1027  1
    arc_1_7_14  original_T_including_depot_unload_1039  1.7279728905134273e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_14  arc_capacity_818  1
    load_1_7_14  segment_load_conservation_987  1
    load_1_7_14  free_load_conservation_1031  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_15  arc_capacity_820  -30
    arc_1_7_15  connected_order_arc_821  -11
    arc_1_7_15  out_degree_983  1
    arc_1_7_15  in_degree_1033  1
    arc_1_7_15  original_T_including_depot_unload_1039  2.2339035809798856e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_15  arc_capacity_820  1
    load_1_7_15  segment_load_conservation_987  1
    load_1_7_15  free_load_conservation_1037  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_0  arc_capacity_822  -30
    arc_1_8_0  depot_return_or_bypass_975  1
    arc_1_8_0  out_degree_990  1
    arc_1_8_0  original_T_including_depot_unload_1039  9.3659929340140741e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_0  arc_capacity_822  1
    load_1_8_0  free_load_conservation_995  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_6  arc_capacity_823  -30
    arc_1_8_6  connected_order_arc_824  -11
    arc_1_8_6  in_degree_977  1
    arc_1_8_6  out_degree_990  1
    arc_1_8_6  original_T_including_depot_unload_1039  2.0021738809925773e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_6  arc_capacity_823  1
    load_1_8_6  segment_load_conservation_980  -1
    load_1_8_6  segment_prefix_lb_981  1
    load_1_8_6  segment_prefix_ub_982  1
    load_1_8_6  free_load_conservation_995  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_7  arc_capacity_825  -30
    arc_1_8_7  connected_order_arc_826  -11
    arc_1_8_7  in_degree_984  1
    arc_1_8_7  out_degree_990  1
    arc_1_8_7  original_T_including_depot_unload_1039  1.9959569014367933e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_7  arc_capacity_825  1
    load_1_8_7  segment_load_conservation_987  -1
    load_1_8_7  segment_prefix_lb_988  1
    load_1_8_7  segment_prefix_ub_989  1
    load_1_8_7  free_load_conservation_995  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_9  arc_capacity_827  -30
    arc_1_8_9  connected_order_arc_828  -11
    arc_1_8_9  out_degree_990  1
    arc_1_8_9  in_degree_997  1
    arc_1_8_9  original_T_including_depot_unload_1039  2.0082608212298291e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_9  arc_capacity_827  1
    load_1_8_9  free_load_conservation_995  1
    load_1_8_9  free_load_conservation_1001  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_10  arc_capacity_829  -30
    arc_1_8_10  connected_order_arc_830  -11
    arc_1_8_10  out_degree_990  1
    arc_1_8_10  in_degree_1003  1
    arc_1_8_10  original_T_including_depot_unload_1039  3.0726580305165480e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_10  arc_capacity_829  1
    load_1_8_10  free_load_conservation_995  1
    load_1_8_10  free_load_conservation_1007  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_11  arc_capacity_831  -30
    arc_1_8_11  connected_order_arc_832  -11
    arc_1_8_11  out_degree_990  1
    arc_1_8_11  in_degree_1009  1
    arc_1_8_11  original_T_including_depot_unload_1039  2.0241950709354862e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_11  arc_capacity_831  1
    load_1_8_11  free_load_conservation_995  1
    load_1_8_11  free_load_conservation_1013  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_12  arc_capacity_833  -30
    arc_1_8_12  connected_order_arc_834  -11
    arc_1_8_12  out_degree_990  1
    arc_1_8_12  in_degree_1015  1
    arc_1_8_12  original_T_including_depot_unload_1039  2.5292035468949002e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_12  arc_capacity_833  1
    load_1_8_12  free_load_conservation_995  1
    load_1_8_12  free_load_conservation_1019  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_13  arc_capacity_835  -30
    arc_1_8_13  connected_order_arc_836  -11
    arc_1_8_13  out_degree_990  1
    arc_1_8_13  in_degree_1021  1
    arc_1_8_13  original_T_including_depot_unload_1039  2.8260257937815851e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_13  arc_capacity_835  1
    load_1_8_13  free_load_conservation_995  1
    load_1_8_13  free_load_conservation_1025  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_14  arc_capacity_837  -30
    arc_1_8_14  connected_order_arc_838  -11
    arc_1_8_14  out_degree_990  1
    arc_1_8_14  in_degree_1027  1
    arc_1_8_14  original_T_including_depot_unload_1039  5.3918604589472477e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_14  arc_capacity_837  1
    load_1_8_14  free_load_conservation_995  1
    load_1_8_14  free_load_conservation_1031  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_15  arc_capacity_839  -30
    arc_1_8_15  connected_order_arc_840  -11
    arc_1_8_15  out_degree_990  1
    arc_1_8_15  in_degree_1033  1
    arc_1_8_15  original_T_including_depot_unload_1039  2.9819555494495978e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_15  arc_capacity_839  1
    load_1_8_15  free_load_conservation_995  1
    load_1_8_15  free_load_conservation_1037  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_0  arc_capacity_841  -30
    arc_1_9_0  depot_return_or_bypass_975  1
    arc_1_9_0  out_degree_996  1
    arc_1_9_0  original_T_including_depot_unload_1039  7.4412496590753551e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_0  arc_capacity_841  1
    load_1_9_0  free_load_conservation_1001  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_6  arc_capacity_842  -30
    arc_1_9_6  connected_order_arc_843  -11
    arc_1_9_6  in_degree_977  1
    arc_1_9_6  out_degree_996  1
    arc_1_9_6  original_T_including_depot_unload_1039  1.9740618091449423e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_6  arc_capacity_842  1
    load_1_9_6  segment_load_conservation_980  -1
    load_1_9_6  segment_prefix_lb_981  1
    load_1_9_6  segment_prefix_ub_982  1
    load_1_9_6  free_load_conservation_1001  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_7  arc_capacity_844  -30
    arc_1_9_7  connected_order_arc_845  -11
    arc_1_9_7  in_degree_984  1
    arc_1_9_7  out_degree_996  1
    arc_1_9_7  original_T_including_depot_unload_1039  1.9548039027038737e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_7  arc_capacity_844  1
    load_1_9_7  segment_load_conservation_987  -1
    load_1_9_7  segment_prefix_lb_988  1
    load_1_9_7  segment_prefix_ub_989  1
    load_1_9_7  free_load_conservation_1001  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_8  arc_capacity_846  -30
    arc_1_9_8  connected_order_arc_847  -11
    arc_1_9_8  in_degree_991  1
    arc_1_9_8  out_degree_996  1
    arc_1_9_8  original_T_including_depot_unload_1039  2.0082608212298291e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_8  arc_capacity_846  1
    load_1_9_8  free_load_conservation_995  -1
    load_1_9_8  free_load_conservation_1001  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_10  arc_capacity_848  -30
    arc_1_9_10  connected_order_arc_849  -11
    arc_1_9_10  out_degree_996  1
    arc_1_9_10  in_degree_1003  1
    arc_1_9_10  original_T_including_depot_unload_1039  2.8807002034504962e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_10  arc_capacity_848  1
    load_1_9_10  free_load_conservation_1001  1
    load_1_9_10  free_load_conservation_1007  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_11  arc_capacity_850  -30
    arc_1_9_11  connected_order_arc_851  -11
    arc_1_9_11  out_degree_996  1
    arc_1_9_11  in_degree_1009  1
    arc_1_9_11  original_T_including_depot_unload_1039  1.2673640125672841e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_11  arc_capacity_850  1
    load_1_9_11  free_load_conservation_1001  1
    load_1_9_11  free_load_conservation_1013  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_12  arc_capacity_852  -30
    arc_1_9_12  connected_order_arc_853  -11
    arc_1_9_12  out_degree_996  1
    arc_1_9_12  in_degree_1015  1
    arc_1_9_12  original_T_including_depot_unload_1039  2.4992063774241742e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_12  arc_capacity_852  1
    load_1_9_12  free_load_conservation_1001  1
    load_1_9_12  free_load_conservation_1019  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_13  arc_capacity_854  -30
    arc_1_9_13  connected_order_arc_855  -11
    arc_1_9_13  out_degree_996  1
    arc_1_9_13  in_degree_1021  1
    arc_1_9_13  original_T_including_depot_unload_1039  4.7721499161748335e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_13  arc_capacity_854  1
    load_1_9_13  free_load_conservation_1001  1
    load_1_9_13  free_load_conservation_1025  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_14  arc_capacity_856  -30
    arc_1_9_14  connected_order_arc_857  -11
    arc_1_9_14  out_degree_996  1
    arc_1_9_14  in_degree_1027  1
    arc_1_9_14  original_T_including_depot_unload_1039  3.6114004430677619e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_14  arc_capacity_856  1
    load_1_9_14  free_load_conservation_1001  1
    load_1_9_14  free_load_conservation_1031  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_15  arc_capacity_858  -30
    arc_1_9_15  connected_order_arc_859  -11
    arc_1_9_15  out_degree_996  1
    arc_1_9_15  in_degree_1033  1
    arc_1_9_15  original_T_including_depot_unload_1039  2.8072002002622634e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_15  arc_capacity_858  1
    load_1_9_15  free_load_conservation_1001  1
    load_1_9_15  free_load_conservation_1037  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_0  arc_capacity_860  -30
    arc_1_10_0  depot_return_or_bypass_975  1
    arc_1_10_0  out_degree_1002  1
    arc_1_10_0  original_T_including_depot_unload_1039  2.3234267380118886e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_0  arc_capacity_860  1
    load_1_10_0  free_load_conservation_1007  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_6  arc_capacity_861  -30
    arc_1_10_6  connected_order_arc_862  -11
    arc_1_10_6  in_degree_977  1
    arc_1_10_6  out_degree_1002  1
    arc_1_10_6  original_T_including_depot_unload_1039  3.8283958278492823e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_6  arc_capacity_861  1
    load_1_10_6  segment_load_conservation_980  -1
    load_1_10_6  segment_prefix_lb_981  1
    load_1_10_6  segment_prefix_ub_982  1
    load_1_10_6  free_load_conservation_1007  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_7  arc_capacity_863  -30
    arc_1_10_7  connected_order_arc_864  -11
    arc_1_10_7  in_degree_984  1
    arc_1_10_7  out_degree_1002  1
    arc_1_10_7  original_T_including_depot_unload_1039  3.7182308190042463e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_7  arc_capacity_863  1
    load_1_10_7  segment_load_conservation_987  -1
    load_1_10_7  segment_prefix_lb_988  1
    load_1_10_7  segment_prefix_ub_989  1
    load_1_10_7  free_load_conservation_1007  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_8  arc_capacity_865  -30
    arc_1_10_8  connected_order_arc_866  -11
    arc_1_10_8  in_degree_991  1
    arc_1_10_8  out_degree_1002  1
    arc_1_10_8  original_T_including_depot_unload_1039  3.0726580305165480e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_8  arc_capacity_865  1
    load_1_10_8  free_load_conservation_995  -1
    load_1_10_8  free_load_conservation_1007  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_9  arc_capacity_867  -30
    arc_1_10_9  connected_order_arc_868  -11
    arc_1_10_9  in_degree_997  1
    arc_1_10_9  out_degree_1002  1
    arc_1_10_9  original_T_including_depot_unload_1039  2.8807002034504962e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_9  arc_capacity_867  1
    load_1_10_9  free_load_conservation_1001  -1
    load_1_10_9  free_load_conservation_1007  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_11  arc_capacity_869  -30
    arc_1_10_11  connected_order_arc_870  -11
    arc_1_10_11  out_degree_1002  1
    arc_1_10_11  in_degree_1009  1
    arc_1_10_11  original_T_including_depot_unload_1039  2.8834086639088187e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_11  arc_capacity_869  1
    load_1_10_11  free_load_conservation_1007  1
    load_1_10_11  free_load_conservation_1013  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_12  arc_capacity_871  -30
    arc_1_10_12  connected_order_arc_872  -11
    arc_1_10_12  out_degree_1002  1
    arc_1_10_12  in_degree_1015  1
    arc_1_10_12  original_T_including_depot_unload_1039  4.1686506413165080e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_12  arc_capacity_871  1
    load_1_10_12  free_load_conservation_1007  1
    load_1_10_12  free_load_conservation_1019  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_13  arc_capacity_873  -30
    arc_1_10_13  connected_order_arc_874  -11
    arc_1_10_13  out_degree_1002  1
    arc_1_10_13  in_degree_1021  1
    arc_1_10_13  original_T_including_depot_unload_1039  3.3076115257178203e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_13  arc_capacity_873  1
    load_1_10_13  free_load_conservation_1007  1
    load_1_10_13  free_load_conservation_1025  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_14  arc_capacity_875  -30
    arc_1_10_14  connected_order_arc_876  -11
    arc_1_10_14  out_degree_1002  1
    arc_1_10_14  in_degree_1027  1
    arc_1_10_14  original_T_including_depot_unload_1039  2.6728511574036233e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_14  arc_capacity_875  1
    load_1_10_14  free_load_conservation_1007  1
    load_1_10_14  free_load_conservation_1031  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_15  arc_capacity_877  -30
    arc_1_10_15  connected_order_arc_878  -11
    arc_1_10_15  out_degree_1002  1
    arc_1_10_15  in_degree_1033  1
    arc_1_10_15  original_T_including_depot_unload_1039  2.8839695646198670e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_15  arc_capacity_877  1
    load_1_10_15  free_load_conservation_1007  1
    load_1_10_15  free_load_conservation_1037  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_0  arc_capacity_879  -30
    arc_1_11_0  depot_return_or_bypass_975  1
    arc_1_11_0  out_degree_1008  1
    arc_1_11_0  original_T_including_depot_unload_1039  8.2548955430739034e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_0  arc_capacity_879  1
    load_1_11_0  free_load_conservation_1013  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_6  arc_capacity_880  -30
    arc_1_11_6  connected_order_arc_881  -11
    arc_1_11_6  in_degree_977  1
    arc_1_11_6  out_degree_1008  1
    arc_1_11_6  original_T_including_depot_unload_1039  2.0979901720969542e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_6  arc_capacity_880  1
    load_1_11_6  segment_load_conservation_980  -1
    load_1_11_6  segment_prefix_lb_981  1
    load_1_11_6  segment_prefix_ub_982  1
    load_1_11_6  free_load_conservation_1013  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_7  arc_capacity_882  -30
    arc_1_11_7  connected_order_arc_883  -11
    arc_1_11_7  in_degree_984  1
    arc_1_11_7  out_degree_1008  1
    arc_1_11_7  original_T_including_depot_unload_1039  2.0801782775431307e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_7  arc_capacity_882  1
    load_1_11_7  segment_load_conservation_987  -1
    load_1_11_7  segment_prefix_lb_988  1
    load_1_11_7  segment_prefix_ub_989  1
    load_1_11_7  free_load_conservation_1013  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_8  arc_capacity_884  -30
    arc_1_11_8  connected_order_arc_885  -11
    arc_1_11_8  in_degree_991  1
    arc_1_11_8  out_degree_1008  1
    arc_1_11_8  original_T_including_depot_unload_1039  2.0241950709354862e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_8  arc_capacity_884  1
    load_1_11_8  free_load_conservation_995  -1
    load_1_11_8  free_load_conservation_1013  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_9  arc_capacity_886  -30
    arc_1_11_9  connected_order_arc_887  -11
    arc_1_11_9  in_degree_997  1
    arc_1_11_9  out_degree_1008  1
    arc_1_11_9  original_T_including_depot_unload_1039  1.2673640125672841e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_9  arc_capacity_886  1
    load_1_11_9  free_load_conservation_1001  -1
    load_1_11_9  free_load_conservation_1013  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_10  arc_capacity_888  -30
    arc_1_11_10  connected_order_arc_889  -11
    arc_1_11_10  in_degree_1003  1
    arc_1_11_10  out_degree_1008  1
    arc_1_11_10  original_T_including_depot_unload_1039  2.8834086639088187e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_10  arc_capacity_888  1
    load_1_11_10  free_load_conservation_1007  -1
    load_1_11_10  free_load_conservation_1013  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_12  arc_capacity_890  -30
    arc_1_11_12  connected_order_arc_891  -11
    arc_1_11_12  out_degree_1008  1
    arc_1_11_12  in_degree_1015  1
    arc_1_11_12  original_T_including_depot_unload_1039  2.6235983504802839e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_12  arc_capacity_890  1
    load_1_11_12  free_load_conservation_1013  1
    load_1_11_12  free_load_conservation_1019  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_13  arc_capacity_892  -30
    arc_1_11_13  connected_order_arc_893  -11
    arc_1_11_13  out_degree_1008  1
    arc_1_11_13  in_degree_1021  1
    arc_1_11_13  original_T_including_depot_unload_1039  4.3124580937307496e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_13  arc_capacity_892  1
    load_1_11_13  free_load_conservation_1013  1
    load_1_11_13  free_load_conservation_1025  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_14  arc_capacity_894  -30
    arc_1_11_14  connected_order_arc_895  -11
    arc_1_11_14  out_degree_1008  1
    arc_1_11_14  in_degree_1027  1
    arc_1_11_14  original_T_including_depot_unload_1039  4.6739130846957909e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_14  arc_capacity_894  1
    load_1_11_14  free_load_conservation_1013  1
    load_1_11_14  free_load_conservation_1031  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_15  arc_capacity_896  -30
    arc_1_11_15  connected_order_arc_897  -11
    arc_1_11_15  out_degree_1008  1
    arc_1_11_15  in_degree_1033  1
    arc_1_11_15  original_T_including_depot_unload_1039  1.5413712102626312e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_15  arc_capacity_896  1
    load_1_11_15  free_load_conservation_1013  1
    load_1_11_15  free_load_conservation_1037  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_0  arc_capacity_898  -30
    arc_1_12_0  depot_return_or_bypass_975  1
    arc_1_12_0  out_degree_1014  1
    arc_1_12_0  original_T_including_depot_unload_1039  2.2866763971369810e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_0  arc_capacity_898  1
    load_1_12_0  free_load_conservation_1019  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_6  arc_capacity_899  -30
    arc_1_12_6  connected_order_arc_900  -11
    arc_1_12_6  in_degree_977  1
    arc_1_12_6  out_degree_1014  1
    arc_1_12_6  original_T_including_depot_unload_1039  5.2703432304351884e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_6  arc_capacity_899  1
    load_1_12_6  segment_load_conservation_980  -1
    load_1_12_6  segment_prefix_lb_981  1
    load_1_12_6  segment_prefix_ub_982  1
    load_1_12_6  free_load_conservation_1019  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_7  arc_capacity_901  -30
    arc_1_12_7  connected_order_arc_902  -11
    arc_1_12_7  in_degree_984  1
    arc_1_12_7  out_degree_1014  1
    arc_1_12_7  original_T_including_depot_unload_1039  5.5382752177930990e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_7  arc_capacity_901  1
    load_1_12_7  segment_load_conservation_987  -1
    load_1_12_7  segment_prefix_lb_988  1
    load_1_12_7  segment_prefix_ub_989  1
    load_1_12_7  free_load_conservation_1019  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_8  arc_capacity_903  -30
    arc_1_12_8  connected_order_arc_904  -11
    arc_1_12_8  in_degree_991  1
    arc_1_12_8  out_degree_1014  1
    arc_1_12_8  original_T_including_depot_unload_1039  2.5292035468949002e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_8  arc_capacity_903  1
    load_1_12_8  free_load_conservation_995  -1
    load_1_12_8  free_load_conservation_1019  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_9  arc_capacity_905  -30
    arc_1_12_9  connected_order_arc_906  -11
    arc_1_12_9  in_degree_997  1
    arc_1_12_9  out_degree_1014  1
    arc_1_12_9  original_T_including_depot_unload_1039  2.4992063774241742e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_9  arc_capacity_905  1
    load_1_12_9  free_load_conservation_1001  -1
    load_1_12_9  free_load_conservation_1019  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_10  arc_capacity_907  -30
    arc_1_12_10  connected_order_arc_908  -11
    arc_1_12_10  in_degree_1003  1
    arc_1_12_10  out_degree_1014  1
    arc_1_12_10  original_T_including_depot_unload_1039  4.1686506413165080e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_10  arc_capacity_907  1
    load_1_12_10  free_load_conservation_1007  -1
    load_1_12_10  free_load_conservation_1019  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_11  arc_capacity_909  -30
    arc_1_12_11  connected_order_arc_910  -11
    arc_1_12_11  in_degree_1009  1
    arc_1_12_11  out_degree_1014  1
    arc_1_12_11  original_T_including_depot_unload_1039  2.6235983504802839e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_11  arc_capacity_909  1
    load_1_12_11  free_load_conservation_1013  -1
    load_1_12_11  free_load_conservation_1019  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_13  arc_capacity_911  -30
    arc_1_12_13  connected_order_arc_912  -11
    arc_1_12_13  out_degree_1014  1
    arc_1_12_13  in_degree_1021  1
    arc_1_12_13  original_T_including_depot_unload_1039  2.6797194604092651e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_13  arc_capacity_911  1
    load_1_12_13  free_load_conservation_1019  1
    load_1_12_13  free_load_conservation_1025  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_14  arc_capacity_913  -30
    arc_1_12_14  connected_order_arc_914  -11
    arc_1_12_14  out_degree_1014  1
    arc_1_12_14  in_degree_1027  1
    arc_1_12_14  original_T_including_depot_unload_1039  2.2811398160464278e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_14  arc_capacity_913  1
    load_1_12_14  free_load_conservation_1019  1
    load_1_12_14  free_load_conservation_1031  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_15  arc_capacity_915  -30
    arc_1_12_15  connected_order_arc_916  -11
    arc_1_12_15  out_degree_1014  1
    arc_1_12_15  in_degree_1033  1
    arc_1_12_15  original_T_including_depot_unload_1039  2.7766616410403444e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_15  arc_capacity_915  1
    load_1_12_15  free_load_conservation_1019  1
    load_1_12_15  free_load_conservation_1037  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_0  arc_capacity_917  -30
    arc_1_13_0  depot_return_or_bypass_975  1
    arc_1_13_0  out_degree_1020  1
    arc_1_13_0  original_T_including_depot_unload_1039  1.2186896810212775e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_0  arc_capacity_917  1
    load_1_13_0  free_load_conservation_1025  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_6  arc_capacity_918  -30
    arc_1_13_6  connected_order_arc_919  -11
    arc_1_13_6  in_degree_977  1
    arc_1_13_6  out_degree_1020  1
    arc_1_13_6  original_T_including_depot_unload_1039  2.1556817566230284e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_6  arc_capacity_918  1
    load_1_13_6  segment_load_conservation_980  -1
    load_1_13_6  segment_prefix_lb_981  1
    load_1_13_6  segment_prefix_ub_982  1
    load_1_13_6  free_load_conservation_1025  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_7  arc_capacity_920  -30
    arc_1_13_7  connected_order_arc_921  -11
    arc_1_13_7  in_degree_984  1
    arc_1_13_7  out_degree_1020  1
    arc_1_13_7  original_T_including_depot_unload_1039  2.1641391312462424e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_7  arc_capacity_920  1
    load_1_13_7  segment_load_conservation_987  -1
    load_1_13_7  segment_prefix_lb_988  1
    load_1_13_7  segment_prefix_ub_989  1
    load_1_13_7  free_load_conservation_1025  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_8  arc_capacity_922  -30
    arc_1_13_8  connected_order_arc_923  -11
    arc_1_13_8  in_degree_991  1
    arc_1_13_8  out_degree_1020  1
    arc_1_13_8  original_T_including_depot_unload_1039  2.8260257937815851e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_8  arc_capacity_922  1
    load_1_13_8  free_load_conservation_995  -1
    load_1_13_8  free_load_conservation_1025  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_9  arc_capacity_924  -30
    arc_1_13_9  connected_order_arc_925  -11
    arc_1_13_9  in_degree_997  1
    arc_1_13_9  out_degree_1020  1
    arc_1_13_9  original_T_including_depot_unload_1039  4.7721499161748335e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_9  arc_capacity_924  1
    load_1_13_9  free_load_conservation_1001  -1
    load_1_13_9  free_load_conservation_1025  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_10  arc_capacity_926  -30
    arc_1_13_10  connected_order_arc_927  -11
    arc_1_13_10  in_degree_1003  1
    arc_1_13_10  out_degree_1020  1
    arc_1_13_10  original_T_including_depot_unload_1039  3.3076115257178203e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_10  arc_capacity_926  1
    load_1_13_10  free_load_conservation_1007  -1
    load_1_13_10  free_load_conservation_1025  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_11  arc_capacity_928  -30
    arc_1_13_11  connected_order_arc_929  -11
    arc_1_13_11  in_degree_1009  1
    arc_1_13_11  out_degree_1020  1
    arc_1_13_11  original_T_including_depot_unload_1039  4.3124580937307496e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_11  arc_capacity_928  1
    load_1_13_11  free_load_conservation_1013  -1
    load_1_13_11  free_load_conservation_1025  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_12  arc_capacity_930  -30
    arc_1_13_12  connected_order_arc_931  -11
    arc_1_13_12  in_degree_1015  1
    arc_1_13_12  out_degree_1020  1
    arc_1_13_12  original_T_including_depot_unload_1039  2.6797194604092651e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_12  arc_capacity_930  1
    load_1_13_12  free_load_conservation_1019  -1
    load_1_13_12  free_load_conservation_1025  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_14  arc_capacity_932  -30
    arc_1_13_14  connected_order_arc_933  -11
    arc_1_13_14  out_degree_1020  1
    arc_1_13_14  in_degree_1027  1
    arc_1_13_14  original_T_including_depot_unload_1039  8.2145202724109538e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_14  arc_capacity_932  1
    load_1_13_14  free_load_conservation_1025  1
    load_1_13_14  free_load_conservation_1031  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_15  arc_capacity_934  -30
    arc_1_13_15  connected_order_arc_935  -11
    arc_1_13_15  out_degree_1020  1
    arc_1_13_15  in_degree_1033  1
    arc_1_13_15  original_T_including_depot_unload_1039  4.3257823465305182e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_15  arc_capacity_934  1
    load_1_13_15  free_load_conservation_1025  1
    load_1_13_15  free_load_conservation_1037  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_0  arc_capacity_936  -30
    arc_1_14_0  depot_return_or_bypass_975  1
    arc_1_14_0  out_degree_1026  1
    arc_1_14_0  original_T_including_depot_unload_1039  4.0782796387128610e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_0  arc_capacity_936  1
    load_1_14_0  free_load_conservation_1031  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_6  arc_capacity_937  -30
    arc_1_14_6  connected_order_arc_938  -11
    arc_1_14_6  in_degree_977  1
    arc_1_14_6  out_degree_1026  1
    arc_1_14_6  original_T_including_depot_unload_1039  1.7671662790958783e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_6  arc_capacity_937  1
    load_1_14_6  segment_load_conservation_980  -1
    load_1_14_6  segment_prefix_lb_981  1
    load_1_14_6  segment_prefix_ub_982  1
    load_1_14_6  free_load_conservation_1031  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_7  arc_capacity_939  -30
    arc_1_14_7  connected_order_arc_940  -11
    arc_1_14_7  in_degree_984  1
    arc_1_14_7  out_degree_1026  1
    arc_1_14_7  original_T_including_depot_unload_1039  1.7279728905134273e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_7  arc_capacity_939  1
    load_1_14_7  segment_load_conservation_987  -1
    load_1_14_7  segment_prefix_lb_988  1
    load_1_14_7  segment_prefix_ub_989  1
    load_1_14_7  free_load_conservation_1031  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_8  arc_capacity_941  -30
    arc_1_14_8  connected_order_arc_942  -11
    arc_1_14_8  in_degree_991  1
    arc_1_14_8  out_degree_1026  1
    arc_1_14_8  original_T_including_depot_unload_1039  5.3918604589472477e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_8  arc_capacity_941  1
    load_1_14_8  free_load_conservation_995  -1
    load_1_14_8  free_load_conservation_1031  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_9  arc_capacity_943  -30
    arc_1_14_9  connected_order_arc_944  -11
    arc_1_14_9  in_degree_997  1
    arc_1_14_9  out_degree_1026  1
    arc_1_14_9  original_T_including_depot_unload_1039  3.6114004430677619e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_9  arc_capacity_943  1
    load_1_14_9  free_load_conservation_1001  -1
    load_1_14_9  free_load_conservation_1031  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_10  arc_capacity_945  -30
    arc_1_14_10  connected_order_arc_946  -11
    arc_1_14_10  in_degree_1003  1
    arc_1_14_10  out_degree_1026  1
    arc_1_14_10  original_T_including_depot_unload_1039  2.6728511574036233e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_10  arc_capacity_945  1
    load_1_14_10  free_load_conservation_1007  -1
    load_1_14_10  free_load_conservation_1031  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_11  arc_capacity_947  -30
    arc_1_14_11  connected_order_arc_948  -11
    arc_1_14_11  in_degree_1009  1
    arc_1_14_11  out_degree_1026  1
    arc_1_14_11  original_T_including_depot_unload_1039  4.6739130846957909e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_11  arc_capacity_947  1
    load_1_14_11  free_load_conservation_1013  -1
    load_1_14_11  free_load_conservation_1031  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_12  arc_capacity_949  -30
    arc_1_14_12  connected_order_arc_950  -11
    arc_1_14_12  in_degree_1015  1
    arc_1_14_12  out_degree_1026  1
    arc_1_14_12  original_T_including_depot_unload_1039  2.2811398160464278e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_12  arc_capacity_949  1
    load_1_14_12  free_load_conservation_1019  -1
    load_1_14_12  free_load_conservation_1031  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_13  arc_capacity_951  -30
    arc_1_14_13  connected_order_arc_952  -11
    arc_1_14_13  in_degree_1021  1
    arc_1_14_13  out_degree_1026  1
    arc_1_14_13  original_T_including_depot_unload_1039  8.2145202724109538e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_13  arc_capacity_951  1
    load_1_14_13  free_load_conservation_1025  -1
    load_1_14_13  free_load_conservation_1031  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_15  arc_capacity_953  -30
    arc_1_14_15  connected_order_arc_954  -11
    arc_1_14_15  out_degree_1026  1
    arc_1_14_15  in_degree_1033  1
    arc_1_14_15  original_T_including_depot_unload_1039  6.0329604828085382e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_15  arc_capacity_953  1
    load_1_14_15  free_load_conservation_1031  1
    load_1_14_15  free_load_conservation_1037  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_0  arc_capacity_955  -30
    arc_1_15_0  depot_return_or_bypass_975  1
    arc_1_15_0  out_degree_1032  1
    arc_1_15_0  original_T_including_depot_unload_1039  9.3133633713881534e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_0  arc_capacity_955  1
    load_1_15_0  free_load_conservation_1037  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_6  arc_capacity_956  -30
    arc_1_15_6  connected_order_arc_957  -11
    arc_1_15_6  in_degree_977  1
    arc_1_15_6  out_degree_1032  1
    arc_1_15_6  original_T_including_depot_unload_1039  2.2507610939146793e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_6  arc_capacity_956  1
    load_1_15_6  segment_load_conservation_980  -1
    load_1_15_6  segment_prefix_lb_981  1
    load_1_15_6  segment_prefix_ub_982  1
    load_1_15_6  free_load_conservation_1037  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_7  arc_capacity_958  -30
    arc_1_15_7  connected_order_arc_959  -11
    arc_1_15_7  in_degree_984  1
    arc_1_15_7  out_degree_1032  1
    arc_1_15_7  original_T_including_depot_unload_1039  2.2339035809798856e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_7  arc_capacity_958  1
    load_1_15_7  segment_load_conservation_987  -1
    load_1_15_7  segment_prefix_lb_988  1
    load_1_15_7  segment_prefix_ub_989  1
    load_1_15_7  free_load_conservation_1037  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_8  arc_capacity_960  -30
    arc_1_15_8  connected_order_arc_961  -11
    arc_1_15_8  in_degree_991  1
    arc_1_15_8  out_degree_1032  1
    arc_1_15_8  original_T_including_depot_unload_1039  2.9819555494495978e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_8  arc_capacity_960  1
    load_1_15_8  free_load_conservation_995  -1
    load_1_15_8  free_load_conservation_1037  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_9  arc_capacity_962  -30
    arc_1_15_9  connected_order_arc_963  -11
    arc_1_15_9  in_degree_997  1
    arc_1_15_9  out_degree_1032  1
    arc_1_15_9  original_T_including_depot_unload_1039  2.8072002002622634e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_9  arc_capacity_962  1
    load_1_15_9  free_load_conservation_1001  -1
    load_1_15_9  free_load_conservation_1037  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_10  arc_capacity_964  -30
    arc_1_15_10  connected_order_arc_965  -11
    arc_1_15_10  in_degree_1003  1
    arc_1_15_10  out_degree_1032  1
    arc_1_15_10  original_T_including_depot_unload_1039  2.8839695646198670e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_10  arc_capacity_964  1
    load_1_15_10  free_load_conservation_1007  -1
    load_1_15_10  free_load_conservation_1037  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_11  arc_capacity_966  -30
    arc_1_15_11  connected_order_arc_967  -11
    arc_1_15_11  in_degree_1009  1
    arc_1_15_11  out_degree_1032  1
    arc_1_15_11  original_T_including_depot_unload_1039  1.5413712102626312e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_11  arc_capacity_966  1
    load_1_15_11  free_load_conservation_1013  -1
    load_1_15_11  free_load_conservation_1037  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_12  arc_capacity_968  -30
    arc_1_15_12  connected_order_arc_969  -11
    arc_1_15_12  in_degree_1015  1
    arc_1_15_12  out_degree_1032  1
    arc_1_15_12  original_T_including_depot_unload_1039  2.7766616410403444e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_12  arc_capacity_968  1
    load_1_15_12  free_load_conservation_1019  -1
    load_1_15_12  free_load_conservation_1037  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_13  arc_capacity_970  -30
    arc_1_15_13  connected_order_arc_971  -11
    arc_1_15_13  in_degree_1021  1
    arc_1_15_13  out_degree_1032  1
    arc_1_15_13  original_T_including_depot_unload_1039  4.3257823465305182e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_13  arc_capacity_970  1
    load_1_15_13  free_load_conservation_1025  -1
    load_1_15_13  free_load_conservation_1037  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_14  arc_capacity_972  -30
    arc_1_15_14  connected_order_arc_973  -11
    arc_1_15_14  in_degree_1027  1
    arc_1_15_14  out_degree_1032  1
    arc_1_15_14  original_T_including_depot_unload_1039  6.0329604828085382e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_14  arc_capacity_972  1
    load_1_15_14  free_load_conservation_1031  -1
    load_1_15_14  free_load_conservation_1037  1
RHS
    RHS1      OBJ       -4.2715179666323339e-01
    RHS1      onehot_5_6  1
    RHS1      onehot_6_13  1
    RHS1      onehot_18_48  1
    RHS1      onehot_3_85  1
    RHS1      onehot_17_122  1
    RHS1      onehot_4_157  1
    RHS1      onehot_11_192  1
    RHS1      onehot_2_199  1
    RHS1      stock_ub_203  27
    RHS1      parent_nonstrict_scope_204  5.4334647271796288e-01
    RHS1      normalization_261  1
    RHS1      connected_order_arc_360  -13
    RHS1      connected_order_arc_362  -13
    RHS1      connected_order_arc_364  -13
    RHS1      connected_order_arc_366  -13
    RHS1      connected_order_arc_368  -13
    RHS1      connected_order_arc_370  -13
    RHS1      connected_order_arc_372  -13
    RHS1      connected_order_arc_374  -13
    RHS1      connected_order_arc_376  -13
    RHS1      connected_order_arc_378  -13
    RHS1      connected_order_arc_380  -13
    RHS1      connected_order_arc_382  -13
    RHS1      connected_order_arc_385  -13
    RHS1      connected_order_arc_387  -13
    RHS1      connected_order_arc_389  -13
    RHS1      connected_order_arc_391  -13
    RHS1      connected_order_arc_393  -13
    RHS1      connected_order_arc_395  -13
    RHS1      connected_order_arc_397  -13
    RHS1      connected_order_arc_399  -13
    RHS1      connected_order_arc_401  -13
    RHS1      connected_order_arc_403  -13
    RHS1      connected_order_arc_405  -13
    RHS1      connected_order_arc_407  -13
    RHS1      connected_order_arc_410  -13
    RHS1      connected_order_arc_412  -13
    RHS1      connected_order_arc_414  -13
    RHS1      connected_order_arc_416  -13
    RHS1      connected_order_arc_418  -13
    RHS1      connected_order_arc_420  -13
    RHS1      connected_order_arc_422  -13
    RHS1      connected_order_arc_424  -13
    RHS1      connected_order_arc_426  -13
    RHS1      connected_order_arc_428  -13
    RHS1      connected_order_arc_430  -13
    RHS1      connected_order_arc_432  -13
    RHS1      connected_order_arc_435  -13
    RHS1      connected_order_arc_437  -13
    RHS1      connected_order_arc_439  -13
    RHS1      connected_order_arc_441  -13
    RHS1      connected_order_arc_443  -13
    RHS1      connected_order_arc_445  -13
    RHS1      connected_order_arc_447  -13
    RHS1      connected_order_arc_449  -13
    RHS1      connected_order_arc_451  -13
    RHS1      connected_order_arc_453  -13
    RHS1      connected_order_arc_455  -13
    RHS1      connected_order_arc_457  -13
    RHS1      connected_order_arc_460  -13
    RHS1      connected_order_arc_462  -13
    RHS1      connected_order_arc_464  -13
    RHS1      connected_order_arc_466  -13
    RHS1      connected_order_arc_468  -13
    RHS1      connected_order_arc_470  -13
    RHS1      connected_order_arc_472  -13
    RHS1      connected_order_arc_474  -13
    RHS1      connected_order_arc_476  -13
    RHS1      connected_order_arc_478  -13
    RHS1      connected_order_arc_480  -13
    RHS1      connected_order_arc_482  -13
    RHS1      connected_order_arc_485  -13
    RHS1      connected_order_arc_487  -13
    RHS1      connected_order_arc_489  -13
    RHS1      connected_order_arc_491  -13
    RHS1      connected_order_arc_493  -13
    RHS1      connected_order_arc_495  -13
    RHS1      connected_order_arc_497  -13
    RHS1      connected_order_arc_499  -13
    RHS1      connected_order_arc_501  -13
    RHS1      connected_order_arc_503  -13
    RHS1      connected_order_arc_505  -13
    RHS1      connected_order_arc_507  -13
    RHS1      connected_order_arc_510  -13
    RHS1      connected_order_arc_512  -13
    RHS1      connected_order_arc_514  -13
    RHS1      connected_order_arc_516  -13
    RHS1      connected_order_arc_518  -13
    RHS1      connected_order_arc_520  -13
    RHS1      connected_order_arc_522  -13
    RHS1      connected_order_arc_524  -13
    RHS1      connected_order_arc_526  -13
    RHS1      connected_order_arc_528  -13
    RHS1      connected_order_arc_530  -13
    RHS1      connected_order_arc_532  -13
    RHS1      connected_order_arc_535  -13
    RHS1      connected_order_arc_537  -13
    RHS1      connected_order_arc_539  -13
    RHS1      connected_order_arc_541  -13
    RHS1      connected_order_arc_543  -13
    RHS1      connected_order_arc_545  -13
    RHS1      connected_order_arc_547  -13
    RHS1      connected_order_arc_549  -13
    RHS1      connected_order_arc_551  -13
    RHS1      connected_order_arc_553  -13
    RHS1      connected_order_arc_555  -13
    RHS1      connected_order_arc_557  -13
    RHS1      connected_order_arc_560  -13
    RHS1      connected_order_arc_562  -13
    RHS1      connected_order_arc_564  -13
    RHS1      connected_order_arc_566  -13
    RHS1      connected_order_arc_568  -13
    RHS1      connected_order_arc_570  -13
    RHS1      connected_order_arc_572  -13
    RHS1      connected_order_arc_574  -13
    RHS1      connected_order_arc_576  -13
    RHS1      connected_order_arc_578  -13
    RHS1      connected_order_arc_580  -13
    RHS1      connected_order_arc_582  -13
    RHS1      connected_order_arc_585  -13
    RHS1      connected_order_arc_587  -13
    RHS1      connected_order_arc_589  -13
    RHS1      connected_order_arc_591  -13
    RHS1      connected_order_arc_593  -13
    RHS1      connected_order_arc_595  -13
    RHS1      connected_order_arc_597  -13
    RHS1      connected_order_arc_599  -13
    RHS1      connected_order_arc_601  -13
    RHS1      connected_order_arc_603  -13
    RHS1      connected_order_arc_605  -13
    RHS1      connected_order_arc_607  -13
    RHS1      connected_order_arc_610  -13
    RHS1      connected_order_arc_612  -13
    RHS1      connected_order_arc_614  -13
    RHS1      connected_order_arc_616  -13
    RHS1      connected_order_arc_618  -13
    RHS1      connected_order_arc_620  -13
    RHS1      connected_order_arc_622  -13
    RHS1      connected_order_arc_624  -13
    RHS1      connected_order_arc_626  -13
    RHS1      connected_order_arc_628  -13
    RHS1      connected_order_arc_630  -13
    RHS1      connected_order_arc_632  -13
    RHS1      connected_order_arc_635  -13
    RHS1      connected_order_arc_637  -13
    RHS1      connected_order_arc_639  -13
    RHS1      connected_order_arc_641  -13
    RHS1      connected_order_arc_643  -13
    RHS1      connected_order_arc_645  -13
    RHS1      connected_order_arc_647  -13
    RHS1      connected_order_arc_649  -13
    RHS1      connected_order_arc_651  -13
    RHS1      connected_order_arc_653  -13
    RHS1      connected_order_arc_655  -13
    RHS1      connected_order_arc_657  -13
    RHS1      connected_order_arc_660  -13
    RHS1      connected_order_arc_662  -13
    RHS1      connected_order_arc_664  -13
    RHS1      connected_order_arc_666  -13
    RHS1      connected_order_arc_668  -13
    RHS1      connected_order_arc_670  -13
    RHS1      connected_order_arc_672  -13
    RHS1      connected_order_arc_674  -13
    RHS1      connected_order_arc_676  -13
    RHS1      connected_order_arc_678  -13
    RHS1      connected_order_arc_680  -13
    RHS1      connected_order_arc_682  -13
    RHS1      depot_departure_or_bypass_683  1
    RHS1      depot_return_or_bypass_684  1
    RHS1      segment_load_conservation_689  3
    RHS1      segment_prefix_ub_691  27
    RHS1      segment_load_conservation_696  -1
    RHS1      segment_prefix_lb_697  1
    RHS1      segment_prefix_ub_698  30
    RHS1      segment_load_conservation_703  -2
    RHS1      segment_prefix_lb_704  2
    RHS1      segment_prefix_ub_705  30
    RHS1      segment_load_conservation_710  -3
    RHS1      segment_prefix_lb_711  3
    RHS1      segment_prefix_ub_712  30
    RHS1      segment_load_conservation_717  -1
    RHS1      segment_prefix_lb_718  1
    RHS1      segment_prefix_ub_719  30
    RHS1      fixed_segment_relative_order_768  1
    RHS1      fixed_segment_relative_order_769  1
    RHS1      fixed_segment_relative_order_770  1
    RHS1      fixed_segment_relative_order_771  1
    RHS1      original_T_including_depot_unload_772  4440
    RHS1      connected_order_arc_786  -10
    RHS1      connected_order_arc_788  -10
    RHS1      connected_order_arc_790  -10
    RHS1      connected_order_arc_792  -10
    RHS1      connected_order_arc_794  -10
    RHS1      connected_order_arc_796  -10
    RHS1      connected_order_arc_798  -10
    RHS1      connected_order_arc_800  -10
    RHS1      connected_order_arc_802  -10
    RHS1      connected_order_arc_805  -10
    RHS1      connected_order_arc_807  -10
    RHS1      connected_order_arc_809  -10
    RHS1      connected_order_arc_811  -10
    RHS1      connected_order_arc_813  -10
    RHS1      connected_order_arc_815  -10
    RHS1      connected_order_arc_817  -10
    RHS1      connected_order_arc_819  -10
    RHS1      connected_order_arc_821  -10
    RHS1      connected_order_arc_824  -10
    RHS1      connected_order_arc_826  -10
    RHS1      connected_order_arc_828  -10
    RHS1      connected_order_arc_830  -10
    RHS1      connected_order_arc_832  -10
    RHS1      connected_order_arc_834  -10
    RHS1      connected_order_arc_836  -10
    RHS1      connected_order_arc_838  -10
    RHS1      connected_order_arc_840  -10
    RHS1      connected_order_arc_843  -10
    RHS1      connected_order_arc_845  -10
    RHS1      connected_order_arc_847  -10
    RHS1      connected_order_arc_849  -10
    RHS1      connected_order_arc_851  -10
    RHS1      connected_order_arc_853  -10
    RHS1      connected_order_arc_855  -10
    RHS1      connected_order_arc_857  -10
    RHS1      connected_order_arc_859  -10
    RHS1      connected_order_arc_862  -10
    RHS1      connected_order_arc_864  -10
    RHS1      connected_order_arc_866  -10
    RHS1      connected_order_arc_868  -10
    RHS1      connected_order_arc_870  -10
    RHS1      connected_order_arc_872  -10
    RHS1      connected_order_arc_874  -10
    RHS1      connected_order_arc_876  -10
    RHS1      connected_order_arc_878  -10
    RHS1      connected_order_arc_881  -10
    RHS1      connected_order_arc_883  -10
    RHS1      connected_order_arc_885  -10
    RHS1      connected_order_arc_887  -10
    RHS1      connected_order_arc_889  -10
    RHS1      connected_order_arc_891  -10
    RHS1      connected_order_arc_893  -10
    RHS1      connected_order_arc_895  -10
    RHS1      connected_order_arc_897  -10
    RHS1      connected_order_arc_900  -10
    RHS1      connected_order_arc_902  -10
    RHS1      connected_order_arc_904  -10
    RHS1      connected_order_arc_906  -10
    RHS1      connected_order_arc_908  -10
    RHS1      connected_order_arc_910  -10
    RHS1      connected_order_arc_912  -10
    RHS1      connected_order_arc_914  -10
    RHS1      connected_order_arc_916  -10
    RHS1      connected_order_arc_919  -10
    RHS1      connected_order_arc_921  -10
    RHS1      connected_order_arc_923  -10
    RHS1      connected_order_arc_925  -10
    RHS1      connected_order_arc_927  -10
    RHS1      connected_order_arc_929  -10
    RHS1      connected_order_arc_931  -10
    RHS1      connected_order_arc_933  -10
    RHS1      connected_order_arc_935  -10
    RHS1      connected_order_arc_938  -10
    RHS1      connected_order_arc_940  -10
    RHS1      connected_order_arc_942  -10
    RHS1      connected_order_arc_944  -10
    RHS1      connected_order_arc_946  -10
    RHS1      connected_order_arc_948  -10
    RHS1      connected_order_arc_950  -10
    RHS1      connected_order_arc_952  -10
    RHS1      connected_order_arc_954  -10
    RHS1      connected_order_arc_957  -10
    RHS1      connected_order_arc_959  -10
    RHS1      connected_order_arc_961  -10
    RHS1      connected_order_arc_963  -10
    RHS1      connected_order_arc_965  -10
    RHS1      connected_order_arc_967  -10
    RHS1      connected_order_arc_969  -10
    RHS1      connected_order_arc_971  -10
    RHS1      connected_order_arc_973  -10
    RHS1      depot_departure_or_bypass_974  1
    RHS1      depot_return_or_bypass_975  1
    RHS1      segment_load_conservation_980  4
    RHS1      segment_prefix_ub_982  26
    RHS1      segment_load_conservation_987  -1
    RHS1      segment_prefix_lb_988  1
    RHS1      segment_prefix_ub_989  30
    RHS1      fixed_segment_relative_order_1038  1
    RHS1      original_T_including_depot_unload_1039  4320
BOUNDS
 LO BND1      t         4.4361511107937186e-02
 UP BND1      t         1.1272141706935590e-01
 UP BND1      q         6.9405070034003413e-01
 BV BND1      x_5_0   
 UP BND1      w_5_0     1.1272141706935590e-01
 BV BND1      x_5_1   
 UP BND1      w_5_1     1.1272141706935590e-01
 BV BND1      x_5_2   
 UP BND1      w_5_2     1.1272141706935590e-01
 UP BND1      rho_5     1
 BV BND1      x_6_0   
 UP BND1      w_6_0     1.1272141706935590e-01
 BV BND1      x_6_1   
 UP BND1      w_6_1     1.1272141706935590e-01
 UP BND1      rho_6     1
 BV BND1      x_18_0  
 UP BND1      w_18_0    1.1272141706935590e-01
 BV BND1      x_18_1  
 UP BND1      w_18_1    1.1272141706935590e-01
 BV BND1      x_18_2  
 UP BND1      w_18_2    1.1272141706935590e-01
 BV BND1      x_18_3  
 UP BND1      w_18_3    1.1272141706935590e-01
 BV BND1      x_18_4  
 UP BND1      w_18_4    1.1272141706935590e-01
 BV BND1      x_18_5  
 UP BND1      w_18_5    1.1272141706935590e-01
 BV BND1      x_18_6  
 UP BND1      w_18_6    1.1272141706935590e-01
 BV BND1      x_18_7  
 UP BND1      w_18_7    1.1272141706935590e-01
 BV BND1      x_18_8  
 UP BND1      w_18_8    1.1272141706935590e-01
 BV BND1      x_18_9  
 UP BND1      w_18_9    1.1272141706935590e-01
 BV BND1      x_18_10 
 UP BND1      w_18_10   1.1272141706935590e-01
 BV BND1      x_18_11 
 UP BND1      w_18_11   1.1272141706935590e-01
 BV BND1      x_18_12 
 UP BND1      w_18_12   1.1272141706935590e-01
 BV BND1      x_18_13 
 UP BND1      w_18_13   1.1272141706935590e-01
 BV BND1      x_18_14 
 UP BND1      w_18_14   1.1272141706935590e-01
 BV BND1      x_18_15 
 UP BND1      w_18_15   1.1272141706935590e-01
 UP BND1      rho_18    1
 BV BND1      x_3_0   
 UP BND1      w_3_0     1.1272141706935590e-01
 BV BND1      x_3_1   
 UP BND1      w_3_1     1.1272141706935590e-01
 BV BND1      x_3_2   
 UP BND1      w_3_2     1.1272141706935590e-01
 BV BND1      x_3_3   
 UP BND1      w_3_3     1.1272141706935590e-01
 BV BND1      x_3_4   
 UP BND1      w_3_4     1.1272141706935590e-01
 BV BND1      x_3_5   
 UP BND1      w_3_5     1.1272141706935590e-01
 BV BND1      x_3_6   
 UP BND1      w_3_6     1.1272141706935590e-01
 BV BND1      x_3_7   
 UP BND1      w_3_7     1.1272141706935590e-01
 BV BND1      x_3_8   
 UP BND1      w_3_8     1.1272141706935590e-01
 BV BND1      x_3_9   
 UP BND1      w_3_9     1.1272141706935590e-01
 BV BND1      x_3_10  
 UP BND1      w_3_10    1.1272141706935590e-01
 BV BND1      x_3_11  
 UP BND1      w_3_11    1.1272141706935590e-01
 BV BND1      x_3_12  
 UP BND1      w_3_12    1.1272141706935590e-01
 BV BND1      x_3_13  
 UP BND1      w_3_13    1.1272141706935590e-01
 BV BND1      x_3_14  
 UP BND1      w_3_14    1.1272141706935590e-01
 BV BND1      x_3_15  
 UP BND1      w_3_15    1.1272141706935590e-01
 BV BND1      x_3_16  
 UP BND1      w_3_16    1.1272141706935590e-01
 UP BND1      rho_3     1
 BV BND1      x_17_0  
 UP BND1      w_17_0    1.1272141706935590e-01
 BV BND1      x_17_1  
 UP BND1      w_17_1    1.1272141706935590e-01
 BV BND1      x_17_2  
 UP BND1      w_17_2    1.1272141706935590e-01
 BV BND1      x_17_3  
 UP BND1      w_17_3    1.1272141706935590e-01
 BV BND1      x_17_4  
 UP BND1      w_17_4    1.1272141706935590e-01
 BV BND1      x_17_5  
 UP BND1      w_17_5    1.1272141706935590e-01
 BV BND1      x_17_6  
 UP BND1      w_17_6    1.1272141706935590e-01
 BV BND1      x_17_7  
 UP BND1      w_17_7    1.1272141706935590e-01
 BV BND1      x_17_8  
 UP BND1      w_17_8    1.1272141706935590e-01
 BV BND1      x_17_9  
 UP BND1      w_17_9    1.1272141706935590e-01
 BV BND1      x_17_10 
 UP BND1      w_17_10   1.1272141706935590e-01
 BV BND1      x_17_11 
 UP BND1      w_17_11   1.1272141706935590e-01
 BV BND1      x_17_12 
 UP BND1      w_17_12   1.1272141706935590e-01
 BV BND1      x_17_13 
 UP BND1      w_17_13   1.1272141706935590e-01
 BV BND1      x_17_14 
 UP BND1      w_17_14   1.1272141706935590e-01
 BV BND1      x_17_15 
 UP BND1      w_17_15   1.1272141706935590e-01
 BV BND1      x_17_16 
 UP BND1      w_17_16   1.1272141706935590e-01
 UP BND1      rho_17    1
 BV BND1      x_4_0   
 UP BND1      w_4_0     1.1272141706935590e-01
 BV BND1      x_4_1   
 UP BND1      w_4_1     1.1272141706935590e-01
 BV BND1      x_4_2   
 UP BND1      w_4_2     1.1272141706935590e-01
 BV BND1      x_4_3   
 UP BND1      w_4_3     1.1272141706935590e-01
 BV BND1      x_4_4   
 UP BND1      w_4_4     1.1272141706935590e-01
 BV BND1      x_4_5   
 UP BND1      w_4_5     1.1272141706935590e-01
 BV BND1      x_4_6   
 UP BND1      w_4_6     1.1272141706935590e-01
 BV BND1      x_4_7   
 UP BND1      w_4_7     1.1272141706935590e-01
 BV BND1      x_4_8   
 UP BND1      w_4_8     1.1272141706935590e-01
 BV BND1      x_4_9   
 UP BND1      w_4_9     1.1272141706935590e-01
 BV BND1      x_4_10  
 UP BND1      w_4_10    1.1272141706935590e-01
 BV BND1      x_4_11  
 UP BND1      w_4_11    1.1272141706935590e-01
 BV BND1      x_4_12  
 UP BND1      w_4_12    1.1272141706935590e-01
 BV BND1      x_4_13  
 UP BND1      w_4_13    1.1272141706935590e-01
 BV BND1      x_4_14  
 UP BND1      w_4_14    1.1272141706935590e-01
 BV BND1      x_4_15  
 UP BND1      w_4_15    1.1272141706935590e-01
 UP BND1      rho_4     1
 BV BND1      x_11_0  
 UP BND1      w_11_0    1.1272141706935590e-01
 BV BND1      x_11_1  
 UP BND1      w_11_1    1.1272141706935590e-01
 BV BND1      x_11_2  
 UP BND1      w_11_2    1.1272141706935590e-01
 BV BND1      x_11_3  
 UP BND1      w_11_3    1.1272141706935590e-01
 BV BND1      x_11_4  
 UP BND1      w_11_4    1.1272141706935590e-01
 BV BND1      x_11_5  
 UP BND1      w_11_5    1.1272141706935590e-01
 BV BND1      x_11_6  
 UP BND1      w_11_6    1.1272141706935590e-01
 BV BND1      x_11_7  
 UP BND1      w_11_7    1.1272141706935590e-01
 BV BND1      x_11_8  
 UP BND1      w_11_8    1.1272141706935590e-01
 BV BND1      x_11_9  
 UP BND1      w_11_9    1.1272141706935590e-01
 BV BND1      x_11_10 
 UP BND1      w_11_10   1.1272141706935590e-01
 BV BND1      x_11_11 
 UP BND1      w_11_11   1.1272141706935590e-01
 BV BND1      x_11_12 
 UP BND1      w_11_12   1.1272141706935590e-01
 BV BND1      x_11_13 
 UP BND1      w_11_13   1.1272141706935590e-01
 BV BND1      x_11_14 
 UP BND1      w_11_14   1.1272141706935590e-01
 BV BND1      x_11_15 
 UP BND1      w_11_15   1.1272141706935590e-01
 UP BND1      rho_11    1
 BV BND1      x_2_0   
 UP BND1      w_2_0     1.1272141706935590e-01
 BV BND1      x_2_1   
 UP BND1      w_2_1     1.1272141706935590e-01
 UP BND1      rho_2     1
 UP BND1      a_5_6     1
 UP BND1      a_5_18    1
 UP BND1      a_5_3     1
 UP BND1      a_5_17    1
 UP BND1      a_5_4     1
 UP BND1      a_5_11    1
 UP BND1      a_5_2     1
 UP BND1      a_6_18    1
 UP BND1      a_6_3     1
 UP BND1      a_6_17    1
 UP BND1      a_6_4     1
 UP BND1      a_6_11    1
 UP BND1      a_6_2     1
 UP BND1      a_18_3    1
 UP BND1      a_18_17   1
 UP BND1      a_18_4    1
 UP BND1      a_18_11   1
 UP BND1      a_18_2    1
 UP BND1      a_3_17    1
 UP BND1      a_3_4     1
 UP BND1      a_3_11    1
 UP BND1      a_3_2     1
 UP BND1      a_17_4    1
 UP BND1      a_17_11   1
 UP BND1      a_17_2    1
 UP BND1      a_4_11    1
 UP BND1      a_4_2     1
 UP BND1      a_11_2    1
 BV BND1      service_0_5_1
 BV BND1      service_0_5_2
 BV BND1      service_1_5_1
 BV BND1      service_1_5_2
 BV BND1      service_0_6_1
 BV BND1      service_1_6_1
 BV BND1      service_0_18_1
 BV BND1      service_0_18_2
 BV BND1      service_0_18_3
 BV BND1      service_0_18_4
 BV BND1      service_0_18_5
 BV BND1      service_0_18_6
 BV BND1      service_0_18_7
 BV BND1      service_0_18_8
 BV BND1      service_0_18_9
 BV BND1      service_0_18_10
 BV BND1      service_0_18_11
 BV BND1      service_0_18_12
 BV BND1      service_0_18_13
 BV BND1      service_0_18_14
 BV BND1      service_0_18_15
 BV BND1      service_1_18_1
 BV BND1      service_1_18_2
 BV BND1      service_1_18_3
 BV BND1      service_1_18_4
 BV BND1      service_1_18_5
 BV BND1      service_1_18_6
 BV BND1      service_1_18_7
 BV BND1      service_1_18_8
 BV BND1      service_1_18_9
 BV BND1      service_1_18_10
 BV BND1      service_1_18_11
 BV BND1      service_1_18_12
 BV BND1      service_1_18_13
 BV BND1      service_1_18_14
 BV BND1      service_1_18_15
 BV BND1      service_0_3_0
 BV BND1      service_0_3_1
 BV BND1      service_0_3_2
 BV BND1      service_0_3_3
 BV BND1      service_0_3_4
 BV BND1      service_0_3_5
 BV BND1      service_0_3_6
 BV BND1      service_0_3_7
 BV BND1      service_0_3_8
 BV BND1      service_0_3_9
 BV BND1      service_0_3_10
 BV BND1      service_0_3_11
 BV BND1      service_0_3_13
 BV BND1      service_0_3_14
 BV BND1      service_0_3_15
 BV BND1      service_0_3_16
 BV BND1      service_1_3_0
 BV BND1      service_1_3_1
 BV BND1      service_1_3_2
 BV BND1      service_1_3_3
 BV BND1      service_1_3_4
 BV BND1      service_1_3_5
 BV BND1      service_1_3_6
 BV BND1      service_1_3_7
 BV BND1      service_1_3_8
 BV BND1      service_1_3_9
 BV BND1      service_1_3_10
 BV BND1      service_1_3_11
 BV BND1      service_1_3_13
 BV BND1      service_1_3_14
 BV BND1      service_1_3_15
 BV BND1      service_1_3_16
 BV BND1      service_0_17_0
 BV BND1      service_0_17_1
 BV BND1      service_0_17_2
 BV BND1      service_0_17_4
 BV BND1      service_0_17_5
 BV BND1      service_0_17_6
 BV BND1      service_0_17_7
 BV BND1      service_0_17_8
 BV BND1      service_0_17_9
 BV BND1      service_0_17_10
 BV BND1      service_0_17_11
 BV BND1      service_0_17_12
 BV BND1      service_0_17_13
 BV BND1      service_0_17_14
 BV BND1      service_0_17_15
 BV BND1      service_0_17_16
 BV BND1      service_1_17_0
 BV BND1      service_1_17_1
 BV BND1      service_1_17_2
 BV BND1      service_1_17_4
 BV BND1      service_1_17_5
 BV BND1      service_1_17_6
 BV BND1      service_1_17_7
 BV BND1      service_1_17_8
 BV BND1      service_1_17_9
 BV BND1      service_1_17_10
 BV BND1      service_1_17_11
 BV BND1      service_1_17_12
 BV BND1      service_1_17_13
 BV BND1      service_1_17_14
 BV BND1      service_1_17_15
 BV BND1      service_1_17_16
 BV BND1      service_0_4_0
 BV BND1      service_0_4_1
 BV BND1      service_0_4_2
 BV BND1      service_0_4_3
 BV BND1      service_0_4_4
 BV BND1      service_0_4_5
 BV BND1      service_0_4_6
 BV BND1      service_0_4_7
 BV BND1      service_0_4_8
 BV BND1      service_0_4_9
 BV BND1      service_0_4_10
 BV BND1      service_0_4_11
 BV BND1      service_0_4_13
 BV BND1      service_0_4_14
 BV BND1      service_0_4_15
 BV BND1      service_1_4_0
 BV BND1      service_1_4_1
 BV BND1      service_1_4_2
 BV BND1      service_1_4_3
 BV BND1      service_1_4_4
 BV BND1      service_1_4_5
 BV BND1      service_1_4_6
 BV BND1      service_1_4_7
 BV BND1      service_1_4_8
 BV BND1      service_1_4_9
 BV BND1      service_1_4_10
 BV BND1      service_1_4_11
 BV BND1      service_1_4_13
 BV BND1      service_1_4_14
 BV BND1      service_1_4_15
 BV BND1      service_0_11_0
 BV BND1      service_0_11_2
 BV BND1      service_0_11_3
 BV BND1      service_0_11_4
 BV BND1      service_0_11_5
 BV BND1      service_0_11_6
 BV BND1      service_0_11_7
 BV BND1      service_0_11_8
 BV BND1      service_0_11_9
 BV BND1      service_0_11_10
 BV BND1      service_0_11_11
 BV BND1      service_0_11_12
 BV BND1      service_0_11_13
 BV BND1      service_0_11_14
 BV BND1      service_0_11_15
 BV BND1      service_1_11_0
 BV BND1      service_1_11_2
 BV BND1      service_1_11_3
 BV BND1      service_1_11_4
 BV BND1      service_1_11_5
 BV BND1      service_1_11_6
 BV BND1      service_1_11_7
 BV BND1      service_1_11_8
 BV BND1      service_1_11_9
 BV BND1      service_1_11_10
 BV BND1      service_1_11_11
 BV BND1      service_1_11_12
 BV BND1      service_1_11_13
 BV BND1      service_1_11_14
 BV BND1      service_1_11_15
 BV BND1      service_0_2_1
 BV BND1      service_1_2_1
 FX BND1      visit_0_1  1
 UP BND1      order_0_1  13
 FX BND1      visit_0_2  1
 UP BND1      order_0_2  13
 FX BND1      visit_0_3  1
 UP BND1      order_0_3  13
 FX BND1      visit_0_4  1
 UP BND1      order_0_4  13
 FX BND1      visit_0_5  1
 UP BND1      order_0_5  13
 UP BND1      visit_0_8  1
 UP BND1      order_0_8  13
 UP BND1      visit_0_9  1
 UP BND1      order_0_9  13
 UP BND1      visit_0_10  1
 UP BND1      order_0_10  13
 UP BND1      visit_0_11  1
 UP BND1      order_0_11  13
 UP BND1      visit_0_12  1
 UP BND1      order_0_12  13
 UP BND1      visit_0_13  1
 UP BND1      order_0_13  13
 UP BND1      visit_0_14  1
 UP BND1      order_0_14  13
 UP BND1      visit_0_15  1
 UP BND1      order_0_15  13
 BV BND1      arc_0_0_0
 FX BND1      load_0_0_0  0
 BV BND1      arc_0_0_1
 FX BND1      load_0_0_1  0
 BV BND1      arc_0_0_2
 FX BND1      load_0_0_2  0
 BV BND1      arc_0_0_3
 FX BND1      load_0_0_3  0
 BV BND1      arc_0_0_4
 FX BND1      load_0_0_4  0
 BV BND1      arc_0_0_5
 FX BND1      load_0_0_5  0
 BV BND1      arc_0_0_8
 FX BND1      load_0_0_8  0
 BV BND1      arc_0_0_9
 FX BND1      load_0_0_9  0
 BV BND1      arc_0_0_10
 FX BND1      load_0_0_10  0
 BV BND1      arc_0_0_11
 FX BND1      load_0_0_11  0
 BV BND1      arc_0_0_12
 FX BND1      load_0_0_12  0
 BV BND1      arc_0_0_13
 FX BND1      load_0_0_13  0
 BV BND1      arc_0_0_14
 FX BND1      load_0_0_14  0
 BV BND1      arc_0_0_15
 FX BND1      load_0_0_15  0
 BV BND1      arc_0_1_0
 UP BND1      load_0_1_0  30
 BV BND1      arc_0_1_2
 UP BND1      load_0_1_2  30
 BV BND1      arc_0_1_3
 UP BND1      load_0_1_3  30
 BV BND1      arc_0_1_4
 UP BND1      load_0_1_4  30
 BV BND1      arc_0_1_5
 UP BND1      load_0_1_5  30
 BV BND1      arc_0_1_8
 UP BND1      load_0_1_8  30
 BV BND1      arc_0_1_9
 UP BND1      load_0_1_9  30
 BV BND1      arc_0_1_10
 UP BND1      load_0_1_10  30
 BV BND1      arc_0_1_11
 UP BND1      load_0_1_11  30
 BV BND1      arc_0_1_12
 UP BND1      load_0_1_12  30
 BV BND1      arc_0_1_13
 UP BND1      load_0_1_13  30
 BV BND1      arc_0_1_14
 UP BND1      load_0_1_14  30
 BV BND1      arc_0_1_15
 UP BND1      load_0_1_15  30
 BV BND1      arc_0_2_0
 UP BND1      load_0_2_0  30
 BV BND1      arc_0_2_1
 UP BND1      load_0_2_1  30
 BV BND1      arc_0_2_3
 UP BND1      load_0_2_3  30
 BV BND1      arc_0_2_4
 UP BND1      load_0_2_4  30
 BV BND1      arc_0_2_5
 UP BND1      load_0_2_5  30
 BV BND1      arc_0_2_8
 UP BND1      load_0_2_8  30
 BV BND1      arc_0_2_9
 UP BND1      load_0_2_9  30
 BV BND1      arc_0_2_10
 UP BND1      load_0_2_10  30
 BV BND1      arc_0_2_11
 UP BND1      load_0_2_11  30
 BV BND1      arc_0_2_12
 UP BND1      load_0_2_12  30
 BV BND1      arc_0_2_13
 UP BND1      load_0_2_13  30
 BV BND1      arc_0_2_14
 UP BND1      load_0_2_14  30
 BV BND1      arc_0_2_15
 UP BND1      load_0_2_15  30
 BV BND1      arc_0_3_0
 UP BND1      load_0_3_0  30
 BV BND1      arc_0_3_1
 UP BND1      load_0_3_1  30
 BV BND1      arc_0_3_2
 UP BND1      load_0_3_2  30
 BV BND1      arc_0_3_4
 UP BND1      load_0_3_4  30
 BV BND1      arc_0_3_5
 UP BND1      load_0_3_5  30
 BV BND1      arc_0_3_8
 UP BND1      load_0_3_8  30
 BV BND1      arc_0_3_9
 UP BND1      load_0_3_9  30
 BV BND1      arc_0_3_10
 UP BND1      load_0_3_10  30
 BV BND1      arc_0_3_11
 UP BND1      load_0_3_11  30
 BV BND1      arc_0_3_12
 UP BND1      load_0_3_12  30
 BV BND1      arc_0_3_13
 UP BND1      load_0_3_13  30
 BV BND1      arc_0_3_14
 UP BND1      load_0_3_14  30
 BV BND1      arc_0_3_15
 UP BND1      load_0_3_15  30
 BV BND1      arc_0_4_0
 UP BND1      load_0_4_0  30
 BV BND1      arc_0_4_1
 UP BND1      load_0_4_1  30
 BV BND1      arc_0_4_2
 UP BND1      load_0_4_2  30
 BV BND1      arc_0_4_3
 UP BND1      load_0_4_3  30
 BV BND1      arc_0_4_5
 UP BND1      load_0_4_5  30
 BV BND1      arc_0_4_8
 UP BND1      load_0_4_8  30
 BV BND1      arc_0_4_9
 UP BND1      load_0_4_9  30
 BV BND1      arc_0_4_10
 UP BND1      load_0_4_10  30
 BV BND1      arc_0_4_11
 UP BND1      load_0_4_11  30
 BV BND1      arc_0_4_12
 UP BND1      load_0_4_12  30
 BV BND1      arc_0_4_13
 UP BND1      load_0_4_13  30
 BV BND1      arc_0_4_14
 UP BND1      load_0_4_14  30
 BV BND1      arc_0_4_15
 UP BND1      load_0_4_15  30
 BV BND1      arc_0_5_0
 UP BND1      load_0_5_0  30
 BV BND1      arc_0_5_1
 UP BND1      load_0_5_1  30
 BV BND1      arc_0_5_2
 UP BND1      load_0_5_2  30
 BV BND1      arc_0_5_3
 UP BND1      load_0_5_3  30
 BV BND1      arc_0_5_4
 UP BND1      load_0_5_4  30
 BV BND1      arc_0_5_8
 UP BND1      load_0_5_8  30
 BV BND1      arc_0_5_9
 UP BND1      load_0_5_9  30
 BV BND1      arc_0_5_10
 UP BND1      load_0_5_10  30
 BV BND1      arc_0_5_11
 UP BND1      load_0_5_11  30
 BV BND1      arc_0_5_12
 UP BND1      load_0_5_12  30
 BV BND1      arc_0_5_13
 UP BND1      load_0_5_13  30
 BV BND1      arc_0_5_14
 UP BND1      load_0_5_14  30
 BV BND1      arc_0_5_15
 UP BND1      load_0_5_15  30
 BV BND1      arc_0_8_0
 UP BND1      load_0_8_0  30
 BV BND1      arc_0_8_1
 UP BND1      load_0_8_1  30
 BV BND1      arc_0_8_2
 UP BND1      load_0_8_2  30
 BV BND1      arc_0_8_3
 UP BND1      load_0_8_3  30
 BV BND1      arc_0_8_4
 UP BND1      load_0_8_4  30
 BV BND1      arc_0_8_5
 UP BND1      load_0_8_5  30
 BV BND1      arc_0_8_9
 UP BND1      load_0_8_9  30
 BV BND1      arc_0_8_10
 UP BND1      load_0_8_10  30
 BV BND1      arc_0_8_11
 UP BND1      load_0_8_11  30
 BV BND1      arc_0_8_12
 UP BND1      load_0_8_12  30
 BV BND1      arc_0_8_13
 UP BND1      load_0_8_13  30
 BV BND1      arc_0_8_14
 UP BND1      load_0_8_14  30
 BV BND1      arc_0_8_15
 UP BND1      load_0_8_15  30
 BV BND1      arc_0_9_0
 UP BND1      load_0_9_0  30
 BV BND1      arc_0_9_1
 UP BND1      load_0_9_1  30
 BV BND1      arc_0_9_2
 UP BND1      load_0_9_2  30
 BV BND1      arc_0_9_3
 UP BND1      load_0_9_3  30
 BV BND1      arc_0_9_4
 UP BND1      load_0_9_4  30
 BV BND1      arc_0_9_5
 UP BND1      load_0_9_5  30
 BV BND1      arc_0_9_8
 UP BND1      load_0_9_8  30
 BV BND1      arc_0_9_10
 UP BND1      load_0_9_10  30
 BV BND1      arc_0_9_11
 UP BND1      load_0_9_11  30
 BV BND1      arc_0_9_12
 UP BND1      load_0_9_12  30
 BV BND1      arc_0_9_13
 UP BND1      load_0_9_13  30
 BV BND1      arc_0_9_14
 UP BND1      load_0_9_14  30
 BV BND1      arc_0_9_15
 UP BND1      load_0_9_15  30
 BV BND1      arc_0_10_0
 UP BND1      load_0_10_0  30
 BV BND1      arc_0_10_1
 UP BND1      load_0_10_1  30
 BV BND1      arc_0_10_2
 UP BND1      load_0_10_2  30
 BV BND1      arc_0_10_3
 UP BND1      load_0_10_3  30
 BV BND1      arc_0_10_4
 UP BND1      load_0_10_4  30
 BV BND1      arc_0_10_5
 UP BND1      load_0_10_5  30
 BV BND1      arc_0_10_8
 UP BND1      load_0_10_8  30
 BV BND1      arc_0_10_9
 UP BND1      load_0_10_9  30
 BV BND1      arc_0_10_11
 UP BND1      load_0_10_11  30
 BV BND1      arc_0_10_12
 UP BND1      load_0_10_12  30
 BV BND1      arc_0_10_13
 UP BND1      load_0_10_13  30
 BV BND1      arc_0_10_14
 UP BND1      load_0_10_14  30
 BV BND1      arc_0_10_15
 UP BND1      load_0_10_15  30
 BV BND1      arc_0_11_0
 UP BND1      load_0_11_0  30
 BV BND1      arc_0_11_1
 UP BND1      load_0_11_1  30
 BV BND1      arc_0_11_2
 UP BND1      load_0_11_2  30
 BV BND1      arc_0_11_3
 UP BND1      load_0_11_3  30
 BV BND1      arc_0_11_4
 UP BND1      load_0_11_4  30
 BV BND1      arc_0_11_5
 UP BND1      load_0_11_5  30
 BV BND1      arc_0_11_8
 UP BND1      load_0_11_8  30
 BV BND1      arc_0_11_9
 UP BND1      load_0_11_9  30
 BV BND1      arc_0_11_10
 UP BND1      load_0_11_10  30
 BV BND1      arc_0_11_12
 UP BND1      load_0_11_12  30
 BV BND1      arc_0_11_13
 UP BND1      load_0_11_13  30
 BV BND1      arc_0_11_14
 UP BND1      load_0_11_14  30
 BV BND1      arc_0_11_15
 UP BND1      load_0_11_15  30
 BV BND1      arc_0_12_0
 UP BND1      load_0_12_0  30
 BV BND1      arc_0_12_1
 UP BND1      load_0_12_1  30
 BV BND1      arc_0_12_2
 UP BND1      load_0_12_2  30
 BV BND1      arc_0_12_3
 UP BND1      load_0_12_3  30
 BV BND1      arc_0_12_4
 UP BND1      load_0_12_4  30
 BV BND1      arc_0_12_5
 UP BND1      load_0_12_5  30
 BV BND1      arc_0_12_8
 UP BND1      load_0_12_8  30
 BV BND1      arc_0_12_9
 UP BND1      load_0_12_9  30
 BV BND1      arc_0_12_10
 UP BND1      load_0_12_10  30
 BV BND1      arc_0_12_11
 UP BND1      load_0_12_11  30
 BV BND1      arc_0_12_13
 UP BND1      load_0_12_13  30
 BV BND1      arc_0_12_14
 UP BND1      load_0_12_14  30
 BV BND1      arc_0_12_15
 UP BND1      load_0_12_15  30
 BV BND1      arc_0_13_0
 UP BND1      load_0_13_0  30
 BV BND1      arc_0_13_1
 UP BND1      load_0_13_1  30
 BV BND1      arc_0_13_2
 UP BND1      load_0_13_2  30
 BV BND1      arc_0_13_3
 UP BND1      load_0_13_3  30
 BV BND1      arc_0_13_4
 UP BND1      load_0_13_4  30
 BV BND1      arc_0_13_5
 UP BND1      load_0_13_5  30
 BV BND1      arc_0_13_8
 UP BND1      load_0_13_8  30
 BV BND1      arc_0_13_9
 UP BND1      load_0_13_9  30
 BV BND1      arc_0_13_10
 UP BND1      load_0_13_10  30
 BV BND1      arc_0_13_11
 UP BND1      load_0_13_11  30
 BV BND1      arc_0_13_12
 UP BND1      load_0_13_12  30
 BV BND1      arc_0_13_14
 UP BND1      load_0_13_14  30
 BV BND1      arc_0_13_15
 UP BND1      load_0_13_15  30
 BV BND1      arc_0_14_0
 UP BND1      load_0_14_0  30
 BV BND1      arc_0_14_1
 UP BND1      load_0_14_1  30
 BV BND1      arc_0_14_2
 UP BND1      load_0_14_2  30
 BV BND1      arc_0_14_3
 UP BND1      load_0_14_3  30
 BV BND1      arc_0_14_4
 UP BND1      load_0_14_4  30
 BV BND1      arc_0_14_5
 UP BND1      load_0_14_5  30
 BV BND1      arc_0_14_8
 UP BND1      load_0_14_8  30
 BV BND1      arc_0_14_9
 UP BND1      load_0_14_9  30
 BV BND1      arc_0_14_10
 UP BND1      load_0_14_10  30
 BV BND1      arc_0_14_11
 UP BND1      load_0_14_11  30
 BV BND1      arc_0_14_12
 UP BND1      load_0_14_12  30
 BV BND1      arc_0_14_13
 UP BND1      load_0_14_13  30
 BV BND1      arc_0_14_15
 UP BND1      load_0_14_15  30
 BV BND1      arc_0_15_0
 UP BND1      load_0_15_0  30
 BV BND1      arc_0_15_1
 UP BND1      load_0_15_1  30
 BV BND1      arc_0_15_2
 UP BND1      load_0_15_2  30
 BV BND1      arc_0_15_3
 UP BND1      load_0_15_3  30
 BV BND1      arc_0_15_4
 UP BND1      load_0_15_4  30
 BV BND1      arc_0_15_5
 UP BND1      load_0_15_5  30
 BV BND1      arc_0_15_8
 UP BND1      load_0_15_8  30
 BV BND1      arc_0_15_9
 UP BND1      load_0_15_9  30
 BV BND1      arc_0_15_10
 UP BND1      load_0_15_10  30
 BV BND1      arc_0_15_11
 UP BND1      load_0_15_11  30
 BV BND1      arc_0_15_12
 UP BND1      load_0_15_12  30
 BV BND1      arc_0_15_13
 UP BND1      load_0_15_13  30
 BV BND1      arc_0_15_14
 UP BND1      load_0_15_14  30
 FX BND1      visit_1_6  1
 UP BND1      order_1_6  10
 FX BND1      visit_1_7  1
 UP BND1      order_1_7  10
 UP BND1      visit_1_8  1
 UP BND1      order_1_8  10
 UP BND1      visit_1_9  1
 UP BND1      order_1_9  10
 UP BND1      visit_1_10  1
 UP BND1      order_1_10  10
 UP BND1      visit_1_11  1
 UP BND1      order_1_11  10
 UP BND1      visit_1_12  1
 UP BND1      order_1_12  10
 UP BND1      visit_1_13  1
 UP BND1      order_1_13  10
 UP BND1      visit_1_14  1
 UP BND1      order_1_14  10
 UP BND1      visit_1_15  1
 UP BND1      order_1_15  10
 BV BND1      arc_1_0_0
 FX BND1      load_1_0_0  0
 BV BND1      arc_1_0_6
 FX BND1      load_1_0_6  0
 BV BND1      arc_1_0_7
 FX BND1      load_1_0_7  0
 BV BND1      arc_1_0_8
 FX BND1      load_1_0_8  0
 BV BND1      arc_1_0_9
 FX BND1      load_1_0_9  0
 BV BND1      arc_1_0_10
 FX BND1      load_1_0_10  0
 BV BND1      arc_1_0_11
 FX BND1      load_1_0_11  0
 BV BND1      arc_1_0_12
 FX BND1      load_1_0_12  0
 BV BND1      arc_1_0_13
 FX BND1      load_1_0_13  0
 BV BND1      arc_1_0_14
 FX BND1      load_1_0_14  0
 BV BND1      arc_1_0_15
 FX BND1      load_1_0_15  0
 BV BND1      arc_1_6_0
 UP BND1      load_1_6_0  30
 BV BND1      arc_1_6_7
 UP BND1      load_1_6_7  30
 BV BND1      arc_1_6_8
 UP BND1      load_1_6_8  30
 BV BND1      arc_1_6_9
 UP BND1      load_1_6_9  30
 BV BND1      arc_1_6_10
 UP BND1      load_1_6_10  30
 BV BND1      arc_1_6_11
 UP BND1      load_1_6_11  30
 BV BND1      arc_1_6_12
 UP BND1      load_1_6_12  30
 BV BND1      arc_1_6_13
 UP BND1      load_1_6_13  30
 BV BND1      arc_1_6_14
 UP BND1      load_1_6_14  30
 BV BND1      arc_1_6_15
 UP BND1      load_1_6_15  30
 BV BND1      arc_1_7_0
 UP BND1      load_1_7_0  30
 BV BND1      arc_1_7_6
 UP BND1      load_1_7_6  30
 BV BND1      arc_1_7_8
 UP BND1      load_1_7_8  30
 BV BND1      arc_1_7_9
 UP BND1      load_1_7_9  30
 BV BND1      arc_1_7_10
 UP BND1      load_1_7_10  30
 BV BND1      arc_1_7_11
 UP BND1      load_1_7_11  30
 BV BND1      arc_1_7_12
 UP BND1      load_1_7_12  30
 BV BND1      arc_1_7_13
 UP BND1      load_1_7_13  30
 BV BND1      arc_1_7_14
 UP BND1      load_1_7_14  30
 BV BND1      arc_1_7_15
 UP BND1      load_1_7_15  30
 BV BND1      arc_1_8_0
 UP BND1      load_1_8_0  30
 BV BND1      arc_1_8_6
 UP BND1      load_1_8_6  30
 BV BND1      arc_1_8_7
 UP BND1      load_1_8_7  30
 BV BND1      arc_1_8_9
 UP BND1      load_1_8_9  30
 BV BND1      arc_1_8_10
 UP BND1      load_1_8_10  30
 BV BND1      arc_1_8_11
 UP BND1      load_1_8_11  30
 BV BND1      arc_1_8_12
 UP BND1      load_1_8_12  30
 BV BND1      arc_1_8_13
 UP BND1      load_1_8_13  30
 BV BND1      arc_1_8_14
 UP BND1      load_1_8_14  30
 BV BND1      arc_1_8_15
 UP BND1      load_1_8_15  30
 BV BND1      arc_1_9_0
 UP BND1      load_1_9_0  30
 BV BND1      arc_1_9_6
 UP BND1      load_1_9_6  30
 BV BND1      arc_1_9_7
 UP BND1      load_1_9_7  30
 BV BND1      arc_1_9_8
 UP BND1      load_1_9_8  30
 BV BND1      arc_1_9_10
 UP BND1      load_1_9_10  30
 BV BND1      arc_1_9_11
 UP BND1      load_1_9_11  30
 BV BND1      arc_1_9_12
 UP BND1      load_1_9_12  30
 BV BND1      arc_1_9_13
 UP BND1      load_1_9_13  30
 BV BND1      arc_1_9_14
 UP BND1      load_1_9_14  30
 BV BND1      arc_1_9_15
 UP BND1      load_1_9_15  30
 BV BND1      arc_1_10_0
 UP BND1      load_1_10_0  30
 BV BND1      arc_1_10_6
 UP BND1      load_1_10_6  30
 BV BND1      arc_1_10_7
 UP BND1      load_1_10_7  30
 BV BND1      arc_1_10_8
 UP BND1      load_1_10_8  30
 BV BND1      arc_1_10_9
 UP BND1      load_1_10_9  30
 BV BND1      arc_1_10_11
 UP BND1      load_1_10_11  30
 BV BND1      arc_1_10_12
 UP BND1      load_1_10_12  30
 BV BND1      arc_1_10_13
 UP BND1      load_1_10_13  30
 BV BND1      arc_1_10_14
 UP BND1      load_1_10_14  30
 BV BND1      arc_1_10_15
 UP BND1      load_1_10_15  30
 BV BND1      arc_1_11_0
 UP BND1      load_1_11_0  30
 BV BND1      arc_1_11_6
 UP BND1      load_1_11_6  30
 BV BND1      arc_1_11_7
 UP BND1      load_1_11_7  30
 BV BND1      arc_1_11_8
 UP BND1      load_1_11_8  30
 BV BND1      arc_1_11_9
 UP BND1      load_1_11_9  30
 BV BND1      arc_1_11_10
 UP BND1      load_1_11_10  30
 BV BND1      arc_1_11_12
 UP BND1      load_1_11_12  30
 BV BND1      arc_1_11_13
 UP BND1      load_1_11_13  30
 BV BND1      arc_1_11_14
 UP BND1      load_1_11_14  30
 BV BND1      arc_1_11_15
 UP BND1      load_1_11_15  30
 BV BND1      arc_1_12_0
 UP BND1      load_1_12_0  30
 BV BND1      arc_1_12_6
 UP BND1      load_1_12_6  30
 BV BND1      arc_1_12_7
 UP BND1      load_1_12_7  30
 BV BND1      arc_1_12_8
 UP BND1      load_1_12_8  30
 BV BND1      arc_1_12_9
 UP BND1      load_1_12_9  30
 BV BND1      arc_1_12_10
 UP BND1      load_1_12_10  30
 BV BND1      arc_1_12_11
 UP BND1      load_1_12_11  30
 BV BND1      arc_1_12_13
 UP BND1      load_1_12_13  30
 BV BND1      arc_1_12_14
 UP BND1      load_1_12_14  30
 BV BND1      arc_1_12_15
 UP BND1      load_1_12_15  30
 BV BND1      arc_1_13_0
 UP BND1      load_1_13_0  30
 BV BND1      arc_1_13_6
 UP BND1      load_1_13_6  30
 BV BND1      arc_1_13_7
 UP BND1      load_1_13_7  30
 BV BND1      arc_1_13_8
 UP BND1      load_1_13_8  30
 BV BND1      arc_1_13_9
 UP BND1      load_1_13_9  30
 BV BND1      arc_1_13_10
 UP BND1      load_1_13_10  30
 BV BND1      arc_1_13_11
 UP BND1      load_1_13_11  30
 BV BND1      arc_1_13_12
 UP BND1      load_1_13_12  30
 BV BND1      arc_1_13_14
 UP BND1      load_1_13_14  30
 BV BND1      arc_1_13_15
 UP BND1      load_1_13_15  30
 BV BND1      arc_1_14_0
 UP BND1      load_1_14_0  30
 BV BND1      arc_1_14_6
 UP BND1      load_1_14_6  30
 BV BND1      arc_1_14_7
 UP BND1      load_1_14_7  30
 BV BND1      arc_1_14_8
 UP BND1      load_1_14_8  30
 BV BND1      arc_1_14_9
 UP BND1      load_1_14_9  30
 BV BND1      arc_1_14_10
 UP BND1      load_1_14_10  30
 BV BND1      arc_1_14_11
 UP BND1      load_1_14_11  30
 BV BND1      arc_1_14_12
 UP BND1      load_1_14_12  30
 BV BND1      arc_1_14_13
 UP BND1      load_1_14_13  30
 BV BND1      arc_1_14_15
 UP BND1      load_1_14_15  30
 BV BND1      arc_1_15_0
 UP BND1      load_1_15_0  30
 BV BND1      arc_1_15_6
 UP BND1      load_1_15_6  30
 BV BND1      arc_1_15_7
 UP BND1      load_1_15_7  30
 BV BND1      arc_1_15_8
 UP BND1      load_1_15_8  30
 BV BND1      arc_1_15_9
 UP BND1      load_1_15_9  30
 BV BND1      arc_1_15_10
 UP BND1      load_1_15_10  30
 BV BND1      arc_1_15_11
 UP BND1      load_1_15_11  30
 BV BND1      arc_1_15_12
 UP BND1      load_1_15_12  30
 BV BND1      arc_1_15_13
 UP BND1      load_1_15_13  30
 BV BND1      arc_1_15_14
 UP BND1      load_1_15_14  30
ENDATA
