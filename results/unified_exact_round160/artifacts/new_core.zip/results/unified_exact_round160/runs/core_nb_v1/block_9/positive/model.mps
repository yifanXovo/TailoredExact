* Signature: 0x9815477668d14e8
NAME R160_physical_neighborhood
ROWS
 N  OBJ
 G  product_lb_0
 L  product_ub_1
 G  product_lb_2
 L  product_ub_3
 G  product_lb_4
 L  product_ub_5
 G  product_lb_6
 L  product_ub_7
 G  product_lb_8
 L  product_ub_9
 G  product_lb_10
 L  product_ub_11
 G  product_lb_12
 L  product_ub_13
 G  product_lb_14
 L  product_ub_15
 G  product_lb_16
 L  product_ub_17
 G  product_lb_18
 L  product_ub_19
 G  product_lb_20
 L  product_ub_21
 G  product_lb_22
 L  product_ub_23
 G  product_lb_24
 L  product_ub_25
 G  product_lb_26
 L  product_ub_27
 G  product_lb_28
 L  product_ub_29
 G  product_lb_30
 L  product_ub_31
 E  onehot_25_32
 E  normalized_mass_25_33
 E  normalized_ratio_25_34
 G  product_lb_35
 L  product_ub_36
 G  product_lb_37
 L  product_ub_38
 G  product_lb_39
 L  product_ub_40
 G  product_lb_41
 L  product_ub_42
 G  product_lb_43
 L  product_ub_44
 G  product_lb_45
 L  product_ub_46
 G  product_lb_47
 L  product_ub_48
 G  product_lb_49
 L  product_ub_50
 G  product_lb_51
 L  product_ub_52
 G  product_lb_53
 L  product_ub_54
 G  product_lb_55
 L  product_ub_56
 G  product_lb_57
 L  product_ub_58
 G  product_lb_59
 L  product_ub_60
 G  product_lb_61
 L  product_ub_62
 G  product_lb_63
 L  product_ub_64
 G  product_lb_65
 L  product_ub_66
 E  onehot_29_67
 E  normalized_mass_29_68
 E  normalized_ratio_29_69
 G  product_lb_70
 L  product_ub_71
 G  product_lb_72
 L  product_ub_73
 G  product_lb_74
 L  product_ub_75
 G  product_lb_76
 L  product_ub_77
 G  product_lb_78
 L  product_ub_79
 G  product_lb_80
 L  product_ub_81
 G  product_lb_82
 L  product_ub_83
 G  product_lb_84
 L  product_ub_85
 G  product_lb_86
 L  product_ub_87
 G  product_lb_88
 L  product_ub_89
 G  product_lb_90
 L  product_ub_91
 G  product_lb_92
 L  product_ub_93
 G  product_lb_94
 L  product_ub_95
 E  onehot_31_96
 E  normalized_mass_31_97
 E  normalized_ratio_31_98
 G  product_lb_99
 L  product_ub_100
 G  product_lb_101
 L  product_ub_102
 G  product_lb_103
 L  product_ub_104
 G  product_lb_105
 L  product_ub_106
 G  product_lb_107
 L  product_ub_108
 G  product_lb_109
 L  product_ub_110
 G  product_lb_111
 L  product_ub_112
 G  product_lb_113
 L  product_ub_114
 G  product_lb_115
 L  product_ub_116
 G  product_lb_117
 L  product_ub_118
 G  product_lb_119
 L  product_ub_120
 G  product_lb_121
 L  product_ub_122
 G  product_lb_123
 L  product_ub_124
 G  product_lb_125
 L  product_ub_126
 G  product_lb_127
 L  product_ub_128
 G  product_lb_129
 L  product_ub_130
 E  onehot_24_131
 E  normalized_mass_24_132
 E  normalized_ratio_24_133
 G  product_lb_134
 L  product_ub_135
 G  product_lb_136
 L  product_ub_137
 G  product_lb_138
 L  product_ub_139
 G  product_lb_140
 L  product_ub_141
 G  product_lb_142
 L  product_ub_143
 G  product_lb_144
 L  product_ub_145
 G  product_lb_146
 L  product_ub_147
 G  product_lb_148
 L  product_ub_149
 G  product_lb_150
 L  product_ub_151
 G  product_lb_152
 L  product_ub_153
 G  product_lb_154
 L  product_ub_155
 G  product_lb_156
 L  product_ub_157
 G  product_lb_158
 L  product_ub_159
 G  product_lb_160
 L  product_ub_161
 G  product_lb_162
 L  product_ub_163
 G  product_lb_164
 L  product_ub_165
 E  onehot_2_166
 E  normalized_mass_2_167
 E  normalized_ratio_2_168
 G  product_lb_169
 L  product_ub_170
 G  product_lb_171
 L  product_ub_172
 G  product_lb_173
 L  product_ub_174
 G  product_lb_175
 L  product_ub_176
 G  product_lb_177
 L  product_ub_178
 G  product_lb_179
 L  product_ub_180
 G  product_lb_181
 L  product_ub_182
 G  product_lb_183
 L  product_ub_184
 G  product_lb_185
 L  product_ub_186
 G  product_lb_187
 L  product_ub_188
 G  product_lb_189
 L  product_ub_190
 G  product_lb_191
 L  product_ub_192
 G  product_lb_193
 L  product_ub_194
 G  product_lb_195
 L  product_ub_196
 G  product_lb_197
 L  product_ub_198
 G  product_lb_199
 L  product_ub_200
 E  onehot_27_201
 E  normalized_mass_27_202
 E  normalized_ratio_27_203
 G  product_lb_204
 L  product_ub_205
 G  product_lb_206
 L  product_ub_207
 G  product_lb_208
 L  product_ub_209
 G  product_lb_210
 L  product_ub_211
 G  product_lb_212
 L  product_ub_213
 G  product_lb_214
 L  product_ub_215
 G  product_lb_216
 L  product_ub_217
 G  product_lb_218
 L  product_ub_219
 G  product_lb_220
 L  product_ub_221
 G  product_lb_222
 L  product_ub_223
 G  product_lb_224
 L  product_ub_225
 E  onehot_6_226
 E  normalized_mass_6_227
 E  normalized_ratio_6_228
 G  product_lb_229
 L  product_ub_230
 G  product_lb_231
 L  product_ub_232
 G  product_lb_233
 L  product_ub_234
 G  product_lb_235
 L  product_ub_236
 G  product_lb_237
 L  product_ub_238
 G  product_lb_239
 L  product_ub_240
 G  product_lb_241
 L  product_ub_242
 G  product_lb_243
 L  product_ub_244
 G  product_lb_245
 L  product_ub_246
 G  product_lb_247
 L  product_ub_248
 G  product_lb_249
 L  product_ub_250
 G  product_lb_251
 L  product_ub_252
 G  product_lb_253
 L  product_ub_254
 G  product_lb_255
 L  product_ub_256
 G  product_lb_257
 L  product_ub_258
 G  product_lb_259
 L  product_ub_260
 E  onehot_12_261
 E  normalized_mass_12_262
 E  normalized_ratio_12_263
 G  stock_lb_264
 L  stock_ub_265
 L  parent_nonstrict_scope_266
 G  block_pair_pos_267
 G  block_pair_neg_268
 G  block_pair_pos_269
 G  block_pair_neg_270
 G  block_pair_pos_271
 G  block_pair_neg_272
 G  block_pair_pos_273
 G  block_pair_neg_274
 G  block_pair_pos_275
 G  block_pair_neg_276
 G  block_pair_pos_277
 G  block_pair_neg_278
 G  block_pair_pos_279
 G  block_pair_neg_280
 G  block_pair_pos_281
 G  block_pair_neg_282
 G  block_pair_pos_283
 G  block_pair_neg_284
 G  block_pair_pos_285
 G  block_pair_neg_286
 G  block_pair_pos_287
 G  block_pair_neg_288
 G  block_pair_pos_289
 G  block_pair_neg_290
 G  block_pair_pos_291
 G  block_pair_neg_292
 G  block_pair_pos_293
 G  block_pair_neg_294
 G  block_pair_pos_295
 G  block_pair_neg_296
 G  block_pair_pos_297
 G  block_pair_neg_298
 G  block_pair_pos_299
 G  block_pair_neg_300
 G  block_pair_pos_301
 G  block_pair_neg_302
 G  block_pair_pos_303
 G  block_pair_neg_304
 G  block_pair_pos_305
 G  block_pair_neg_306
 G  block_pair_pos_307
 G  block_pair_neg_308
 G  block_pair_pos_309
 G  block_pair_neg_310
 G  block_pair_pos_311
 G  block_pair_neg_312
 G  block_pair_pos_313
 G  block_pair_neg_314
 G  block_pair_pos_315
 G  block_pair_neg_316
 G  block_pair_pos_317
 G  block_pair_neg_318
 G  block_pair_pos_319
 G  block_pair_neg_320
 G  block_pair_pos_321
 G  block_pair_neg_322
 E  normalization_323
 G  full_original_Gini_324
 E  unique_nonzero_owner_325
 E  unique_nonzero_owner_326
 E  unique_nonzero_owner_327
 E  unique_nonzero_owner_328
 E  unique_nonzero_owner_329
 E  unique_nonzero_owner_330
 E  unique_nonzero_owner_331
 E  unique_nonzero_owner_332
 E  unique_nonzero_owner_333
 E  unique_nonzero_owner_334
 E  unique_nonzero_owner_335
 E  unique_nonzero_owner_336
 E  unique_nonzero_owner_337
 E  unique_nonzero_owner_338
 E  unique_nonzero_owner_339
 E  unique_nonzero_owner_340
 E  unique_nonzero_owner_341
 E  unique_nonzero_owner_342
 E  unique_nonzero_owner_343
 E  unique_nonzero_owner_344
 E  unique_nonzero_owner_345
 E  unique_nonzero_owner_346
 E  unique_nonzero_owner_347
 E  unique_nonzero_owner_348
 E  unique_nonzero_owner_349
 E  unique_nonzero_owner_350
 E  unique_nonzero_owner_351
 E  unique_nonzero_owner_352
 E  unique_nonzero_owner_353
 E  unique_nonzero_owner_354
 E  unique_nonzero_owner_355
 E  unique_nonzero_owner_356
 E  unique_nonzero_owner_357
 E  unique_nonzero_owner_358
 E  unique_nonzero_owner_359
 E  unique_nonzero_owner_360
 E  unique_nonzero_owner_361
 E  unique_nonzero_owner_362
 E  unique_nonzero_owner_363
 E  unique_nonzero_owner_364
 E  unique_nonzero_owner_365
 E  unique_nonzero_owner_366
 E  unique_nonzero_owner_367
 E  unique_nonzero_owner_368
 E  unique_nonzero_owner_369
 E  unique_nonzero_owner_370
 E  unique_nonzero_owner_371
 E  unique_nonzero_owner_372
 E  unique_nonzero_owner_373
 E  unique_nonzero_owner_374
 E  unique_nonzero_owner_375
 E  unique_nonzero_owner_376
 E  unique_nonzero_owner_377
 E  unique_nonzero_owner_378
 E  unique_nonzero_owner_379
 E  unique_nonzero_owner_380
 E  unique_nonzero_owner_381
 E  unique_nonzero_owner_382
 E  unique_nonzero_owner_383
 E  unique_nonzero_owner_384
 E  unique_nonzero_owner_385
 E  unique_nonzero_owner_386
 E  unique_nonzero_owner_387
 E  unique_nonzero_owner_388
 E  unique_nonzero_owner_389
 E  unique_nonzero_owner_390
 E  unique_nonzero_owner_391
 E  unique_nonzero_owner_392
 E  unique_nonzero_owner_393
 E  unique_nonzero_owner_394
 E  unique_nonzero_owner_395
 E  unique_nonzero_owner_396
 E  unique_nonzero_owner_397
 E  unique_nonzero_owner_398
 E  unique_nonzero_owner_399
 E  unique_nonzero_owner_400
 E  unique_nonzero_owner_401
 E  unique_nonzero_owner_402
 E  unique_nonzero_owner_403
 E  unique_nonzero_owner_404
 E  unique_nonzero_owner_405
 E  unique_nonzero_owner_406
 E  unique_nonzero_owner_407
 E  unique_nonzero_owner_408
 E  unique_nonzero_owner_409
 E  unique_nonzero_owner_410
 E  unique_nonzero_owner_411
 E  unique_nonzero_owner_412
 E  unique_nonzero_owner_413
 E  unique_nonzero_owner_414
 E  unique_nonzero_owner_415
 E  unique_nonzero_owner_416
 E  unique_nonzero_owner_417
 E  unique_nonzero_owner_418
 E  unique_nonzero_owner_419
 E  unique_nonzero_owner_420
 E  unique_nonzero_owner_421
 E  unique_nonzero_owner_422
 E  unique_nonzero_owner_423
 E  unique_nonzero_owner_424
 E  unique_nonzero_owner_425
 E  unique_nonzero_owner_426
 E  unique_nonzero_owner_427
 E  unique_nonzero_owner_428
 E  unique_nonzero_owner_429
 E  unique_nonzero_owner_430
 E  unique_nonzero_owner_431
 E  unique_nonzero_owner_432
 E  unique_nonzero_owner_433
 E  unique_nonzero_owner_434
 E  unique_nonzero_owner_435
 E  unique_nonzero_owner_436
 L  arc_capacity_437
 L  arc_capacity_438
 L  arc_capacity_439
 L  arc_capacity_440
 L  arc_capacity_441
 L  arc_capacity_442
 L  arc_capacity_443
 L  arc_capacity_444
 L  arc_capacity_445
 L  arc_capacity_446
 L  arc_capacity_447
 L  arc_capacity_448
 L  arc_capacity_449
 L  arc_capacity_450
 L  arc_capacity_451
 G  connected_order_arc_452
 L  arc_capacity_453
 G  connected_order_arc_454
 L  arc_capacity_455
 G  connected_order_arc_456
 L  arc_capacity_457
 G  connected_order_arc_458
 L  arc_capacity_459
 G  connected_order_arc_460
 L  arc_capacity_461
 G  connected_order_arc_462
 L  arc_capacity_463
 G  connected_order_arc_464
 L  arc_capacity_465
 G  connected_order_arc_466
 L  arc_capacity_467
 G  connected_order_arc_468
 L  arc_capacity_469
 G  connected_order_arc_470
 L  arc_capacity_471
 G  connected_order_arc_472
 L  arc_capacity_473
 L  arc_capacity_474
 G  connected_order_arc_475
 L  arc_capacity_476
 G  connected_order_arc_477
 L  arc_capacity_478
 G  connected_order_arc_479
 L  arc_capacity_480
 G  connected_order_arc_481
 L  arc_capacity_482
 G  connected_order_arc_483
 L  arc_capacity_484
 G  connected_order_arc_485
 L  arc_capacity_486
 G  connected_order_arc_487
 L  arc_capacity_488
 G  connected_order_arc_489
 L  arc_capacity_490
 G  connected_order_arc_491
 L  arc_capacity_492
 G  connected_order_arc_493
 L  arc_capacity_494
 G  connected_order_arc_495
 L  arc_capacity_496
 L  arc_capacity_497
 G  connected_order_arc_498
 L  arc_capacity_499
 G  connected_order_arc_500
 L  arc_capacity_501
 G  connected_order_arc_502
 L  arc_capacity_503
 G  connected_order_arc_504
 L  arc_capacity_505
 G  connected_order_arc_506
 L  arc_capacity_507
 G  connected_order_arc_508
 L  arc_capacity_509
 G  connected_order_arc_510
 L  arc_capacity_511
 G  connected_order_arc_512
 L  arc_capacity_513
 G  connected_order_arc_514
 L  arc_capacity_515
 G  connected_order_arc_516
 L  arc_capacity_517
 G  connected_order_arc_518
 L  arc_capacity_519
 L  arc_capacity_520
 G  connected_order_arc_521
 L  arc_capacity_522
 G  connected_order_arc_523
 L  arc_capacity_524
 G  connected_order_arc_525
 L  arc_capacity_526
 G  connected_order_arc_527
 L  arc_capacity_528
 G  connected_order_arc_529
 L  arc_capacity_530
 G  connected_order_arc_531
 L  arc_capacity_532
 G  connected_order_arc_533
 L  arc_capacity_534
 G  connected_order_arc_535
 L  arc_capacity_536
 G  connected_order_arc_537
 L  arc_capacity_538
 G  connected_order_arc_539
 L  arc_capacity_540
 G  connected_order_arc_541
 L  arc_capacity_542
 L  arc_capacity_543
 G  connected_order_arc_544
 L  arc_capacity_545
 G  connected_order_arc_546
 L  arc_capacity_547
 G  connected_order_arc_548
 L  arc_capacity_549
 G  connected_order_arc_550
 L  arc_capacity_551
 G  connected_order_arc_552
 L  arc_capacity_553
 G  connected_order_arc_554
 L  arc_capacity_555
 G  connected_order_arc_556
 L  arc_capacity_557
 G  connected_order_arc_558
 L  arc_capacity_559
 G  connected_order_arc_560
 L  arc_capacity_561
 G  connected_order_arc_562
 L  arc_capacity_563
 G  connected_order_arc_564
 L  arc_capacity_565
 L  arc_capacity_566
 G  connected_order_arc_567
 L  arc_capacity_568
 G  connected_order_arc_569
 L  arc_capacity_570
 G  connected_order_arc_571
 L  arc_capacity_572
 G  connected_order_arc_573
 L  arc_capacity_574
 G  connected_order_arc_575
 L  arc_capacity_576
 G  connected_order_arc_577
 L  arc_capacity_578
 G  connected_order_arc_579
 L  arc_capacity_580
 G  connected_order_arc_581
 L  arc_capacity_582
 G  connected_order_arc_583
 L  arc_capacity_584
 G  connected_order_arc_585
 L  arc_capacity_586
 G  connected_order_arc_587
 L  arc_capacity_588
 L  arc_capacity_589
 G  connected_order_arc_590
 L  arc_capacity_591
 G  connected_order_arc_592
 L  arc_capacity_593
 G  connected_order_arc_594
 L  arc_capacity_595
 G  connected_order_arc_596
 L  arc_capacity_597
 G  connected_order_arc_598
 L  arc_capacity_599
 G  connected_order_arc_600
 L  arc_capacity_601
 G  connected_order_arc_602
 L  arc_capacity_603
 G  connected_order_arc_604
 L  arc_capacity_605
 G  connected_order_arc_606
 L  arc_capacity_607
 G  connected_order_arc_608
 L  arc_capacity_609
 G  connected_order_arc_610
 L  arc_capacity_611
 L  arc_capacity_612
 G  connected_order_arc_613
 L  arc_capacity_614
 G  connected_order_arc_615
 L  arc_capacity_616
 G  connected_order_arc_617
 L  arc_capacity_618
 G  connected_order_arc_619
 L  arc_capacity_620
 G  connected_order_arc_621
 L  arc_capacity_622
 G  connected_order_arc_623
 L  arc_capacity_624
 G  connected_order_arc_625
 L  arc_capacity_626
 G  connected_order_arc_627
 L  arc_capacity_628
 G  connected_order_arc_629
 L  arc_capacity_630
 G  connected_order_arc_631
 L  arc_capacity_632
 G  connected_order_arc_633
 L  arc_capacity_634
 L  arc_capacity_635
 G  connected_order_arc_636
 L  arc_capacity_637
 G  connected_order_arc_638
 L  arc_capacity_639
 G  connected_order_arc_640
 L  arc_capacity_641
 G  connected_order_arc_642
 L  arc_capacity_643
 G  connected_order_arc_644
 L  arc_capacity_645
 G  connected_order_arc_646
 L  arc_capacity_647
 G  connected_order_arc_648
 L  arc_capacity_649
 G  connected_order_arc_650
 L  arc_capacity_651
 G  connected_order_arc_652
 L  arc_capacity_653
 G  connected_order_arc_654
 L  arc_capacity_655
 G  connected_order_arc_656
 L  arc_capacity_657
 L  arc_capacity_658
 G  connected_order_arc_659
 L  arc_capacity_660
 G  connected_order_arc_661
 L  arc_capacity_662
 G  connected_order_arc_663
 L  arc_capacity_664
 G  connected_order_arc_665
 L  arc_capacity_666
 G  connected_order_arc_667
 L  arc_capacity_668
 G  connected_order_arc_669
 L  arc_capacity_670
 G  connected_order_arc_671
 L  arc_capacity_672
 G  connected_order_arc_673
 L  arc_capacity_674
 G  connected_order_arc_675
 L  arc_capacity_676
 G  connected_order_arc_677
 L  arc_capacity_678
 G  connected_order_arc_679
 L  arc_capacity_680
 L  arc_capacity_681
 G  connected_order_arc_682
 L  arc_capacity_683
 G  connected_order_arc_684
 L  arc_capacity_685
 G  connected_order_arc_686
 L  arc_capacity_687
 G  connected_order_arc_688
 L  arc_capacity_689
 G  connected_order_arc_690
 L  arc_capacity_691
 G  connected_order_arc_692
 L  arc_capacity_693
 G  connected_order_arc_694
 L  arc_capacity_695
 G  connected_order_arc_696
 L  arc_capacity_697
 G  connected_order_arc_698
 L  arc_capacity_699
 G  connected_order_arc_700
 L  arc_capacity_701
 G  connected_order_arc_702
 L  arc_capacity_703
 L  arc_capacity_704
 G  connected_order_arc_705
 L  arc_capacity_706
 G  connected_order_arc_707
 L  arc_capacity_708
 G  connected_order_arc_709
 L  arc_capacity_710
 G  connected_order_arc_711
 L  arc_capacity_712
 G  connected_order_arc_713
 L  arc_capacity_714
 G  connected_order_arc_715
 L  arc_capacity_716
 G  connected_order_arc_717
 L  arc_capacity_718
 G  connected_order_arc_719
 L  arc_capacity_720
 G  connected_order_arc_721
 L  arc_capacity_722
 G  connected_order_arc_723
 L  arc_capacity_724
 G  connected_order_arc_725
 E  depot_departure_or_bypass_726
 E  depot_return_or_bypass_727
 E  out_degree_728
 E  in_degree_729
 G  order_active_lb_730
 L  order_active_ub_731
 E  segment_load_conservation_732
 G  segment_prefix_lb_733
 L  segment_prefix_ub_734
 E  out_degree_735
 E  in_degree_736
 G  order_active_lb_737
 L  order_active_ub_738
 E  segment_load_conservation_739
 G  segment_prefix_lb_740
 L  segment_prefix_ub_741
 E  out_degree_742
 E  in_degree_743
 G  order_active_lb_744
 L  order_active_ub_745
 E  segment_load_conservation_746
 G  segment_prefix_lb_747
 L  segment_prefix_ub_748
 E  out_degree_749
 E  in_degree_750
 G  order_active_lb_751
 L  order_active_ub_752
 E  segment_load_conservation_753
 G  segment_prefix_lb_754
 L  segment_prefix_ub_755
 E  out_degree_756
 E  in_degree_757
 G  order_active_lb_758
 L  order_active_ub_759
 E  service_visit_def_760
 E  free_load_conservation_761
 E  out_degree_762
 E  in_degree_763
 G  order_active_lb_764
 L  order_active_ub_765
 E  service_visit_def_766
 E  free_load_conservation_767
 E  out_degree_768
 E  in_degree_769
 G  order_active_lb_770
 L  order_active_ub_771
 E  service_visit_def_772
 E  free_load_conservation_773
 E  out_degree_774
 E  in_degree_775
 G  order_active_lb_776
 L  order_active_ub_777
 E  service_visit_def_778
 E  free_load_conservation_779
 E  out_degree_780
 E  in_degree_781
 G  order_active_lb_782
 L  order_active_ub_783
 E  service_visit_def_784
 E  free_load_conservation_785
 E  out_degree_786
 E  in_degree_787
 G  order_active_lb_788
 L  order_active_ub_789
 E  service_visit_def_790
 E  free_load_conservation_791
 E  out_degree_792
 E  in_degree_793
 G  order_active_lb_794
 L  order_active_ub_795
 E  service_visit_def_796
 E  free_load_conservation_797
 E  out_degree_798
 E  in_degree_799
 G  order_active_lb_800
 L  order_active_ub_801
 E  service_visit_def_802
 E  free_load_conservation_803
 G  fixed_segment_relative_order_804
 G  fixed_segment_relative_order_805
 G  fixed_segment_relative_order_806
 L  original_T_including_depot_unload_807
 L  arc_capacity_808
 L  arc_capacity_809
 L  arc_capacity_810
 L  arc_capacity_811
 L  arc_capacity_812
 L  arc_capacity_813
 L  arc_capacity_814
 L  arc_capacity_815
 L  arc_capacity_816
 L  arc_capacity_817
 L  arc_capacity_818
 L  arc_capacity_819
 L  arc_capacity_820
 L  arc_capacity_821
 L  arc_capacity_822
 G  connected_order_arc_823
 L  arc_capacity_824
 G  connected_order_arc_825
 L  arc_capacity_826
 G  connected_order_arc_827
 L  arc_capacity_828
 G  connected_order_arc_829
 L  arc_capacity_830
 G  connected_order_arc_831
 L  arc_capacity_832
 G  connected_order_arc_833
 L  arc_capacity_834
 G  connected_order_arc_835
 L  arc_capacity_836
 G  connected_order_arc_837
 L  arc_capacity_838
 G  connected_order_arc_839
 L  arc_capacity_840
 G  connected_order_arc_841
 L  arc_capacity_842
 G  connected_order_arc_843
 L  arc_capacity_844
 L  arc_capacity_845
 G  connected_order_arc_846
 L  arc_capacity_847
 G  connected_order_arc_848
 L  arc_capacity_849
 G  connected_order_arc_850
 L  arc_capacity_851
 G  connected_order_arc_852
 L  arc_capacity_853
 G  connected_order_arc_854
 L  arc_capacity_855
 G  connected_order_arc_856
 L  arc_capacity_857
 G  connected_order_arc_858
 L  arc_capacity_859
 G  connected_order_arc_860
 L  arc_capacity_861
 G  connected_order_arc_862
 L  arc_capacity_863
 G  connected_order_arc_864
 L  arc_capacity_865
 G  connected_order_arc_866
 L  arc_capacity_867
 L  arc_capacity_868
 G  connected_order_arc_869
 L  arc_capacity_870
 G  connected_order_arc_871
 L  arc_capacity_872
 G  connected_order_arc_873
 L  arc_capacity_874
 G  connected_order_arc_875
 L  arc_capacity_876
 G  connected_order_arc_877
 L  arc_capacity_878
 G  connected_order_arc_879
 L  arc_capacity_880
 G  connected_order_arc_881
 L  arc_capacity_882
 G  connected_order_arc_883
 L  arc_capacity_884
 G  connected_order_arc_885
 L  arc_capacity_886
 G  connected_order_arc_887
 L  arc_capacity_888
 G  connected_order_arc_889
 L  arc_capacity_890
 L  arc_capacity_891
 G  connected_order_arc_892
 L  arc_capacity_893
 G  connected_order_arc_894
 L  arc_capacity_895
 G  connected_order_arc_896
 L  arc_capacity_897
 G  connected_order_arc_898
 L  arc_capacity_899
 G  connected_order_arc_900
 L  arc_capacity_901
 G  connected_order_arc_902
 L  arc_capacity_903
 G  connected_order_arc_904
 L  arc_capacity_905
 G  connected_order_arc_906
 L  arc_capacity_907
 G  connected_order_arc_908
 L  arc_capacity_909
 G  connected_order_arc_910
 L  arc_capacity_911
 G  connected_order_arc_912
 L  arc_capacity_913
 L  arc_capacity_914
 G  connected_order_arc_915
 L  arc_capacity_916
 G  connected_order_arc_917
 L  arc_capacity_918
 G  connected_order_arc_919
 L  arc_capacity_920
 G  connected_order_arc_921
 L  arc_capacity_922
 G  connected_order_arc_923
 L  arc_capacity_924
 G  connected_order_arc_925
 L  arc_capacity_926
 G  connected_order_arc_927
 L  arc_capacity_928
 G  connected_order_arc_929
 L  arc_capacity_930
 G  connected_order_arc_931
 L  arc_capacity_932
 G  connected_order_arc_933
 L  arc_capacity_934
 G  connected_order_arc_935
 L  arc_capacity_936
 L  arc_capacity_937
 G  connected_order_arc_938
 L  arc_capacity_939
 G  connected_order_arc_940
 L  arc_capacity_941
 G  connected_order_arc_942
 L  arc_capacity_943
 G  connected_order_arc_944
 L  arc_capacity_945
 G  connected_order_arc_946
 L  arc_capacity_947
 G  connected_order_arc_948
 L  arc_capacity_949
 G  connected_order_arc_950
 L  arc_capacity_951
 G  connected_order_arc_952
 L  arc_capacity_953
 G  connected_order_arc_954
 L  arc_capacity_955
 G  connected_order_arc_956
 L  arc_capacity_957
 G  connected_order_arc_958
 L  arc_capacity_959
 L  arc_capacity_960
 G  connected_order_arc_961
 L  arc_capacity_962
 G  connected_order_arc_963
 L  arc_capacity_964
 G  connected_order_arc_965
 L  arc_capacity_966
 G  connected_order_arc_967
 L  arc_capacity_968
 G  connected_order_arc_969
 L  arc_capacity_970
 G  connected_order_arc_971
 L  arc_capacity_972
 G  connected_order_arc_973
 L  arc_capacity_974
 G  connected_order_arc_975
 L  arc_capacity_976
 G  connected_order_arc_977
 L  arc_capacity_978
 G  connected_order_arc_979
 L  arc_capacity_980
 G  connected_order_arc_981
 L  arc_capacity_982
 L  arc_capacity_983
 G  connected_order_arc_984
 L  arc_capacity_985
 G  connected_order_arc_986
 L  arc_capacity_987
 G  connected_order_arc_988
 L  arc_capacity_989
 G  connected_order_arc_990
 L  arc_capacity_991
 G  connected_order_arc_992
 L  arc_capacity_993
 G  connected_order_arc_994
 L  arc_capacity_995
 G  connected_order_arc_996
 L  arc_capacity_997
 G  connected_order_arc_998
 L  arc_capacity_999
 G  connected_order_arc_1000
 L  arc_capacity_1001
 G  connected_order_arc_1002
 L  arc_capacity_1003
 G  connected_order_arc_1004
 L  arc_capacity_1005
 L  arc_capacity_1006
 G  connected_order_arc_1007
 L  arc_capacity_1008
 G  connected_order_arc_1009
 L  arc_capacity_1010
 G  connected_order_arc_1011
 L  arc_capacity_1012
 G  connected_order_arc_1013
 L  arc_capacity_1014
 G  connected_order_arc_1015
 L  arc_capacity_1016
 G  connected_order_arc_1017
 L  arc_capacity_1018
 G  connected_order_arc_1019
 L  arc_capacity_1020
 G  connected_order_arc_1021
 L  arc_capacity_1022
 G  connected_order_arc_1023
 L  arc_capacity_1024
 G  connected_order_arc_1025
 L  arc_capacity_1026
 G  connected_order_arc_1027
 L  arc_capacity_1028
 L  arc_capacity_1029
 G  connected_order_arc_1030
 L  arc_capacity_1031
 G  connected_order_arc_1032
 L  arc_capacity_1033
 G  connected_order_arc_1034
 L  arc_capacity_1035
 G  connected_order_arc_1036
 L  arc_capacity_1037
 G  connected_order_arc_1038
 L  arc_capacity_1039
 G  connected_order_arc_1040
 L  arc_capacity_1041
 G  connected_order_arc_1042
 L  arc_capacity_1043
 G  connected_order_arc_1044
 L  arc_capacity_1045
 G  connected_order_arc_1046
 L  arc_capacity_1047
 G  connected_order_arc_1048
 L  arc_capacity_1049
 G  connected_order_arc_1050
 L  arc_capacity_1051
 L  arc_capacity_1052
 G  connected_order_arc_1053
 L  arc_capacity_1054
 G  connected_order_arc_1055
 L  arc_capacity_1056
 G  connected_order_arc_1057
 L  arc_capacity_1058
 G  connected_order_arc_1059
 L  arc_capacity_1060
 G  connected_order_arc_1061
 L  arc_capacity_1062
 G  connected_order_arc_1063
 L  arc_capacity_1064
 G  connected_order_arc_1065
 L  arc_capacity_1066
 G  connected_order_arc_1067
 L  arc_capacity_1068
 G  connected_order_arc_1069
 L  arc_capacity_1070
 G  connected_order_arc_1071
 L  arc_capacity_1072
 G  connected_order_arc_1073
 L  arc_capacity_1074
 L  arc_capacity_1075
 G  connected_order_arc_1076
 L  arc_capacity_1077
 G  connected_order_arc_1078
 L  arc_capacity_1079
 G  connected_order_arc_1080
 L  arc_capacity_1081
 G  connected_order_arc_1082
 L  arc_capacity_1083
 G  connected_order_arc_1084
 L  arc_capacity_1085
 G  connected_order_arc_1086
 L  arc_capacity_1087
 G  connected_order_arc_1088
 L  arc_capacity_1089
 G  connected_order_arc_1090
 L  arc_capacity_1091
 G  connected_order_arc_1092
 L  arc_capacity_1093
 G  connected_order_arc_1094
 L  arc_capacity_1095
 G  connected_order_arc_1096
 E  depot_departure_or_bypass_1097
 E  depot_return_or_bypass_1098
 E  out_degree_1099
 E  in_degree_1100
 G  order_active_lb_1101
 L  order_active_ub_1102
 E  segment_load_conservation_1103
 G  segment_prefix_lb_1104
 L  segment_prefix_ub_1105
 E  out_degree_1106
 E  in_degree_1107
 G  order_active_lb_1108
 L  order_active_ub_1109
 E  segment_load_conservation_1110
 G  segment_prefix_lb_1111
 L  segment_prefix_ub_1112
 E  out_degree_1113
 E  in_degree_1114
 G  order_active_lb_1115
 L  order_active_ub_1116
 E  segment_load_conservation_1117
 G  segment_prefix_lb_1118
 L  segment_prefix_ub_1119
 E  out_degree_1120
 E  in_degree_1121
 G  order_active_lb_1122
 L  order_active_ub_1123
 E  segment_load_conservation_1124
 G  segment_prefix_lb_1125
 L  segment_prefix_ub_1126
 E  out_degree_1127
 E  in_degree_1128
 G  order_active_lb_1129
 L  order_active_ub_1130
 E  service_visit_def_1131
 E  free_load_conservation_1132
 E  out_degree_1133
 E  in_degree_1134
 G  order_active_lb_1135
 L  order_active_ub_1136
 E  service_visit_def_1137
 E  free_load_conservation_1138
 E  out_degree_1139
 E  in_degree_1140
 G  order_active_lb_1141
 L  order_active_ub_1142
 E  service_visit_def_1143
 E  free_load_conservation_1144
 E  out_degree_1145
 E  in_degree_1146
 G  order_active_lb_1147
 L  order_active_ub_1148
 E  service_visit_def_1149
 E  free_load_conservation_1150
 E  out_degree_1151
 E  in_degree_1152
 G  order_active_lb_1153
 L  order_active_ub_1154
 E  service_visit_def_1155
 E  free_load_conservation_1156
 E  out_degree_1157
 E  in_degree_1158
 G  order_active_lb_1159
 L  order_active_ub_1160
 E  service_visit_def_1161
 E  free_load_conservation_1162
 E  out_degree_1163
 E  in_degree_1164
 G  order_active_lb_1165
 L  order_active_ub_1166
 E  service_visit_def_1167
 E  free_load_conservation_1168
 E  out_degree_1169
 E  in_degree_1170
 G  order_active_lb_1171
 L  order_active_ub_1172
 E  service_visit_def_1173
 E  free_load_conservation_1174
 G  fixed_segment_relative_order_1175
 G  fixed_segment_relative_order_1176
 G  fixed_segment_relative_order_1177
 L  original_T_including_depot_unload_1178
 L  arc_capacity_1179
 L  arc_capacity_1180
 L  arc_capacity_1181
 L  arc_capacity_1182
 L  arc_capacity_1183
 L  arc_capacity_1184
 L  arc_capacity_1185
 L  arc_capacity_1186
 L  arc_capacity_1187
 L  arc_capacity_1188
 L  arc_capacity_1189
 L  arc_capacity_1190
 L  arc_capacity_1191
 L  arc_capacity_1192
 G  connected_order_arc_1193
 L  arc_capacity_1194
 G  connected_order_arc_1195
 L  arc_capacity_1196
 G  connected_order_arc_1197
 L  arc_capacity_1198
 G  connected_order_arc_1199
 L  arc_capacity_1200
 G  connected_order_arc_1201
 L  arc_capacity_1202
 G  connected_order_arc_1203
 L  arc_capacity_1204
 G  connected_order_arc_1205
 L  arc_capacity_1206
 G  connected_order_arc_1207
 L  arc_capacity_1208
 G  connected_order_arc_1209
 L  arc_capacity_1210
 G  connected_order_arc_1211
 L  arc_capacity_1212
 L  arc_capacity_1213
 G  connected_order_arc_1214
 L  arc_capacity_1215
 G  connected_order_arc_1216
 L  arc_capacity_1217
 G  connected_order_arc_1218
 L  arc_capacity_1219
 G  connected_order_arc_1220
 L  arc_capacity_1221
 G  connected_order_arc_1222
 L  arc_capacity_1223
 G  connected_order_arc_1224
 L  arc_capacity_1225
 G  connected_order_arc_1226
 L  arc_capacity_1227
 G  connected_order_arc_1228
 L  arc_capacity_1229
 G  connected_order_arc_1230
 L  arc_capacity_1231
 G  connected_order_arc_1232
 L  arc_capacity_1233
 L  arc_capacity_1234
 G  connected_order_arc_1235
 L  arc_capacity_1236
 G  connected_order_arc_1237
 L  arc_capacity_1238
 G  connected_order_arc_1239
 L  arc_capacity_1240
 G  connected_order_arc_1241
 L  arc_capacity_1242
 G  connected_order_arc_1243
 L  arc_capacity_1244
 G  connected_order_arc_1245
 L  arc_capacity_1246
 G  connected_order_arc_1247
 L  arc_capacity_1248
 G  connected_order_arc_1249
 L  arc_capacity_1250
 G  connected_order_arc_1251
 L  arc_capacity_1252
 G  connected_order_arc_1253
 L  arc_capacity_1254
 L  arc_capacity_1255
 G  connected_order_arc_1256
 L  arc_capacity_1257
 G  connected_order_arc_1258
 L  arc_capacity_1259
 G  connected_order_arc_1260
 L  arc_capacity_1261
 G  connected_order_arc_1262
 L  arc_capacity_1263
 G  connected_order_arc_1264
 L  arc_capacity_1265
 G  connected_order_arc_1266
 L  arc_capacity_1267
 G  connected_order_arc_1268
 L  arc_capacity_1269
 G  connected_order_arc_1270
 L  arc_capacity_1271
 G  connected_order_arc_1272
 L  arc_capacity_1273
 G  connected_order_arc_1274
 L  arc_capacity_1275
 L  arc_capacity_1276
 G  connected_order_arc_1277
 L  arc_capacity_1278
 G  connected_order_arc_1279
 L  arc_capacity_1280
 G  connected_order_arc_1281
 L  arc_capacity_1282
 G  connected_order_arc_1283
 L  arc_capacity_1284
 G  connected_order_arc_1285
 L  arc_capacity_1286
 G  connected_order_arc_1287
 L  arc_capacity_1288
 G  connected_order_arc_1289
 L  arc_capacity_1290
 G  connected_order_arc_1291
 L  arc_capacity_1292
 G  connected_order_arc_1293
 L  arc_capacity_1294
 G  connected_order_arc_1295
 L  arc_capacity_1296
 L  arc_capacity_1297
 G  connected_order_arc_1298
 L  arc_capacity_1299
 G  connected_order_arc_1300
 L  arc_capacity_1301
 G  connected_order_arc_1302
 L  arc_capacity_1303
 G  connected_order_arc_1304
 L  arc_capacity_1305
 G  connected_order_arc_1306
 L  arc_capacity_1307
 G  connected_order_arc_1308
 L  arc_capacity_1309
 G  connected_order_arc_1310
 L  arc_capacity_1311
 G  connected_order_arc_1312
 L  arc_capacity_1313
 G  connected_order_arc_1314
 L  arc_capacity_1315
 G  connected_order_arc_1316
 L  arc_capacity_1317
 L  arc_capacity_1318
 G  connected_order_arc_1319
 L  arc_capacity_1320
 G  connected_order_arc_1321
 L  arc_capacity_1322
 G  connected_order_arc_1323
 L  arc_capacity_1324
 G  connected_order_arc_1325
 L  arc_capacity_1326
 G  connected_order_arc_1327
 L  arc_capacity_1328
 G  connected_order_arc_1329
 L  arc_capacity_1330
 G  connected_order_arc_1331
 L  arc_capacity_1332
 G  connected_order_arc_1333
 L  arc_capacity_1334
 G  connected_order_arc_1335
 L  arc_capacity_1336
 G  connected_order_arc_1337
 L  arc_capacity_1338
 L  arc_capacity_1339
 G  connected_order_arc_1340
 L  arc_capacity_1341
 G  connected_order_arc_1342
 L  arc_capacity_1343
 G  connected_order_arc_1344
 L  arc_capacity_1345
 G  connected_order_arc_1346
 L  arc_capacity_1347
 G  connected_order_arc_1348
 L  arc_capacity_1349
 G  connected_order_arc_1350
 L  arc_capacity_1351
 G  connected_order_arc_1352
 L  arc_capacity_1353
 G  connected_order_arc_1354
 L  arc_capacity_1355
 G  connected_order_arc_1356
 L  arc_capacity_1357
 G  connected_order_arc_1358
 L  arc_capacity_1359
 L  arc_capacity_1360
 G  connected_order_arc_1361
 L  arc_capacity_1362
 G  connected_order_arc_1363
 L  arc_capacity_1364
 G  connected_order_arc_1365
 L  arc_capacity_1366
 G  connected_order_arc_1367
 L  arc_capacity_1368
 G  connected_order_arc_1369
 L  arc_capacity_1370
 G  connected_order_arc_1371
 L  arc_capacity_1372
 G  connected_order_arc_1373
 L  arc_capacity_1374
 G  connected_order_arc_1375
 L  arc_capacity_1376
 G  connected_order_arc_1377
 L  arc_capacity_1378
 G  connected_order_arc_1379
 L  arc_capacity_1380
 L  arc_capacity_1381
 G  connected_order_arc_1382
 L  arc_capacity_1383
 G  connected_order_arc_1384
 L  arc_capacity_1385
 G  connected_order_arc_1386
 L  arc_capacity_1387
 G  connected_order_arc_1388
 L  arc_capacity_1389
 G  connected_order_arc_1390
 L  arc_capacity_1391
 G  connected_order_arc_1392
 L  arc_capacity_1393
 G  connected_order_arc_1394
 L  arc_capacity_1395
 G  connected_order_arc_1396
 L  arc_capacity_1397
 G  connected_order_arc_1398
 L  arc_capacity_1399
 G  connected_order_arc_1400
 L  arc_capacity_1401
 L  arc_capacity_1402
 G  connected_order_arc_1403
 L  arc_capacity_1404
 G  connected_order_arc_1405
 L  arc_capacity_1406
 G  connected_order_arc_1407
 L  arc_capacity_1408
 G  connected_order_arc_1409
 L  arc_capacity_1410
 G  connected_order_arc_1411
 L  arc_capacity_1412
 G  connected_order_arc_1413
 L  arc_capacity_1414
 G  connected_order_arc_1415
 L  arc_capacity_1416
 G  connected_order_arc_1417
 L  arc_capacity_1418
 G  connected_order_arc_1419
 L  arc_capacity_1420
 G  connected_order_arc_1421
 E  depot_departure_or_bypass_1422
 E  depot_return_or_bypass_1423
 E  out_degree_1424
 E  in_degree_1425
 G  order_active_lb_1426
 L  order_active_ub_1427
 E  segment_load_conservation_1428
 G  segment_prefix_lb_1429
 L  segment_prefix_ub_1430
 E  out_degree_1431
 E  in_degree_1432
 G  order_active_lb_1433
 L  order_active_ub_1434
 E  segment_load_conservation_1435
 G  segment_prefix_lb_1436
 L  segment_prefix_ub_1437
 E  out_degree_1438
 E  in_degree_1439
 G  order_active_lb_1440
 L  order_active_ub_1441
 E  segment_load_conservation_1442
 G  segment_prefix_lb_1443
 L  segment_prefix_ub_1444
 E  out_degree_1445
 E  in_degree_1446
 G  order_active_lb_1447
 L  order_active_ub_1448
 E  service_visit_def_1449
 E  free_load_conservation_1450
 E  out_degree_1451
 E  in_degree_1452
 G  order_active_lb_1453
 L  order_active_ub_1454
 E  service_visit_def_1455
 E  free_load_conservation_1456
 E  out_degree_1457
 E  in_degree_1458
 G  order_active_lb_1459
 L  order_active_ub_1460
 E  service_visit_def_1461
 E  free_load_conservation_1462
 E  out_degree_1463
 E  in_degree_1464
 G  order_active_lb_1465
 L  order_active_ub_1466
 E  service_visit_def_1467
 E  free_load_conservation_1468
 E  out_degree_1469
 E  in_degree_1470
 G  order_active_lb_1471
 L  order_active_ub_1472
 E  service_visit_def_1473
 E  free_load_conservation_1474
 E  out_degree_1475
 E  in_degree_1476
 G  order_active_lb_1477
 L  order_active_ub_1478
 E  service_visit_def_1479
 E  free_load_conservation_1480
 E  out_degree_1481
 E  in_degree_1482
 G  order_active_lb_1483
 L  order_active_ub_1484
 E  service_visit_def_1485
 E  free_load_conservation_1486
 E  out_degree_1487
 E  in_degree_1488
 G  order_active_lb_1489
 L  order_active_ub_1490
 E  service_visit_def_1491
 E  free_load_conservation_1492
 G  fixed_segment_relative_order_1493
 G  fixed_segment_relative_order_1494
 L  original_T_including_depot_unload_1495
COLUMNS
    t         normalized_mass_25_33  -1
    t         normalized_mass_29_68  -1
    t         normalized_mass_31_97  -1
    t         normalized_mass_24_132  -1
    t         normalized_mass_2_167  -1
    t         normalized_mass_27_202  -1
    t         normalized_mass_6_227  -1
    t         normalized_mass_12_262  -1
    t         normalization_323  2.3407142857142855e+01
    t         full_original_Gini_324  -1.0276428571428571e+02
    q         OBJ       1
    q         parent_nonstrict_scope_266  1
    q         full_original_Gini_324  35
    MARKER    'MARKER'                 'INTORG'
    x_25_0    OBJ       0.0315
    x_25_0    product_lb_0  -2.5353132922828682e-02
    x_25_0    product_ub_1  -4.2722001830985672e-02
    x_25_0    onehot_25_32  1
    x_25_0    parent_nonstrict_scope_266  0.0735
    x_25_0    unique_nonzero_owner_325  -1
    MARKER    'MARKER'                 'INTEND'
    w_25_0    product_lb_0  1
    w_25_0    product_ub_1  1
    w_25_0    normalized_mass_25_33  1
    w_25_0    full_original_Gini_324  -2.3407142857142855e+01
    MARKER    'MARKER'                 'INTORG'
    x_25_1    OBJ       2.1000000000000005e-02
    x_25_1    product_lb_2  -2.5353132922828682e-02
    x_25_1    product_ub_3  -4.2722001830985672e-02
    x_25_1    onehot_25_32  1
    x_25_1    stock_lb_264  1
    x_25_1    stock_ub_265  1
    x_25_1    parent_nonstrict_scope_266  0.063
    MARKER    'MARKER'                 'INTEND'
    w_25_1    product_lb_2  1
    w_25_1    product_ub_3  1
    w_25_1    normalized_mass_25_33  1
    w_25_1    normalized_ratio_25_34  -1.4285714285714285e-01
    w_25_1    full_original_Gini_324  -1.9550000000000008e+01
    MARKER    'MARKER'                 'INTORG'
    x_25_2    OBJ       1.0500000000000002e-02
    x_25_2    product_lb_4  -2.5353132922828682e-02
    x_25_2    product_ub_5  -4.2722001830985672e-02
    x_25_2    onehot_25_32  1
    x_25_2    stock_lb_264  2
    x_25_2    stock_ub_265  2
    x_25_2    parent_nonstrict_scope_266  0.0525
    x_25_2    unique_nonzero_owner_326  -1
    MARKER    'MARKER'                 'INTEND'
    w_25_2    product_lb_4  1
    w_25_2    product_ub_5  1
    w_25_2    normalized_mass_25_33  1
    w_25_2    normalized_ratio_25_34  -2.8571428571428570e-01
    w_25_2    full_original_Gini_324  -1.6007142857142853e+01
    MARKER    'MARKER'                 'INTORG'
    x_25_3    product_lb_6  -2.5353132922828682e-02
    x_25_3    product_ub_7  -4.2722001830985672e-02
    x_25_3    onehot_25_32  1
    x_25_3    stock_lb_264  3
    x_25_3    stock_ub_265  3
    x_25_3    parent_nonstrict_scope_266  4.1999999999999996e-02
    x_25_3    unique_nonzero_owner_327  -1
    MARKER    'MARKER'                 'INTEND'
    w_25_3    product_lb_6  1
    w_25_3    product_ub_7  1
    w_25_3    normalized_mass_25_33  1
    w_25_3    normalized_ratio_25_34  -4.2857142857142855e-01
    w_25_3    full_original_Gini_324  -1.3064285714285711e+01
    MARKER    'MARKER'                 'INTORG'
    x_25_4    OBJ       -1.0499999999999995e-02
    x_25_4    product_lb_8  -2.5353132922828682e-02
    x_25_4    product_ub_9  -4.2722001830985672e-02
    x_25_4    onehot_25_32  1
    x_25_4    stock_lb_264  4
    x_25_4    stock_ub_265  4
    x_25_4    parent_nonstrict_scope_266  0.0315
    x_25_4    unique_nonzero_owner_328  -1
    MARKER    'MARKER'                 'INTEND'
    w_25_4    product_lb_8  1
    w_25_4    product_ub_9  1
    w_25_4    normalized_mass_25_33  1
    w_25_4    normalized_ratio_25_34  -5.7142857142857140e-01
    w_25_4    full_original_Gini_324  -1.0492857142857147e+01
    MARKER    'MARKER'                 'INTORG'
    x_25_5    OBJ       -2.0999999999999991e-02
    x_25_5    product_lb_10  -2.5353132922828682e-02
    x_25_5    product_ub_11  -4.2722001830985672e-02
    x_25_5    onehot_25_32  1
    x_25_5    stock_lb_264  5
    x_25_5    stock_ub_265  5
    x_25_5    parent_nonstrict_scope_266  2.1000000000000005e-02
    x_25_5    unique_nonzero_owner_329  -1
    MARKER    'MARKER'                 'INTEND'
    w_25_5    product_lb_10  1
    w_25_5    product_ub_11  1
    w_25_5    normalized_mass_25_33  1
    w_25_5    normalized_ratio_25_34  -7.1428571428571419e-01
    w_25_5    full_original_Gini_324  -8.0642857142857149e+00
    MARKER    'MARKER'                 'INTORG'
    x_25_6    OBJ       -3.1499999999999993e-02
    x_25_6    product_lb_12  -2.5353132922828682e-02
    x_25_6    product_ub_13  -4.2722001830985672e-02
    x_25_6    onehot_25_32  1
    x_25_6    stock_lb_264  6
    x_25_6    stock_ub_265  6
    x_25_6    parent_nonstrict_scope_266  1.0500000000000002e-02
    x_25_6    unique_nonzero_owner_330  -1
    MARKER    'MARKER'                 'INTEND'
    w_25_6    product_lb_12  1
    w_25_6    product_ub_13  1
    w_25_6    normalized_mass_25_33  1
    w_25_6    normalized_ratio_25_34  -8.5714285714285710e-01
    w_25_6    full_original_Gini_324  -5.9642857142857144e+00
    MARKER    'MARKER'                 'INTORG'
    x_25_7    OBJ       -4.1999999999999996e-02
    x_25_7    product_lb_14  -2.5353132922828682e-02
    x_25_7    product_ub_15  -4.2722001830985672e-02
    x_25_7    onehot_25_32  1
    x_25_7    stock_lb_264  7
    x_25_7    stock_ub_265  7
    x_25_7    unique_nonzero_owner_331  -1
    MARKER    'MARKER'                 'INTEND'
    w_25_7    product_lb_14  1
    w_25_7    product_ub_15  1
    w_25_7    normalized_mass_25_33  1
    w_25_7    normalized_ratio_25_34  -1
    w_25_7    full_original_Gini_324  -4.8928571428571432e+00
    MARKER    'MARKER'                 'INTORG'
    x_25_8    OBJ       -0.0315
    x_25_8    product_lb_16  -2.5353132922828682e-02
    x_25_8    product_ub_17  -4.2722001830985672e-02
    x_25_8    onehot_25_32  1
    x_25_8    stock_lb_264  8
    x_25_8    stock_ub_265  8
    x_25_8    parent_nonstrict_scope_266  1.0499999999999995e-02
    x_25_8    unique_nonzero_owner_332  -1
    MARKER    'MARKER'                 'INTEND'
    w_25_8    product_lb_16  1
    w_25_8    product_ub_17  1
    w_25_8    normalized_mass_25_33  1
    w_25_8    normalized_ratio_25_34  -1.1428571428571428e+00
    w_25_8    full_original_Gini_324  -7.8928571428571388e+00
    MARKER    'MARKER'                 'INTORG'
    x_25_9    OBJ       -2.1000000000000005e-02
    x_25_9    product_lb_18  -2.5353132922828682e-02
    x_25_9    product_ub_19  -4.2722001830985672e-02
    x_25_9    onehot_25_32  1
    x_25_9    stock_lb_264  9
    x_25_9    stock_ub_265  9
    x_25_9    parent_nonstrict_scope_266  2.0999999999999991e-02
    x_25_9    unique_nonzero_owner_333  -1
    MARKER    'MARKER'                 'INTEND'
    w_25_9    product_lb_18  1
    w_25_9    product_ub_19  1
    w_25_9    normalized_mass_25_33  1
    w_25_9    normalized_ratio_25_34  -1.2857142857142856e+00
    w_25_9    full_original_Gini_324  -1.1307142857142853e+01
    MARKER    'MARKER'                 'INTORG'
    x_25_10   OBJ       -1.0500000000000009e-02
    x_25_10   product_lb_20  -2.5353132922828682e-02
    x_25_10   product_ub_21  -4.2722001830985672e-02
    x_25_10   onehot_25_32  1
    x_25_10   stock_lb_264  10
    x_25_10   stock_ub_265  10
    x_25_10   parent_nonstrict_scope_266  3.1499999999999986e-02
    x_25_10   unique_nonzero_owner_334  -1
    MARKER    'MARKER'                 'INTEND'
    w_25_10   product_lb_20  1
    w_25_10   product_ub_21  1
    w_25_10   normalized_mass_25_33  1
    w_25_10   normalized_ratio_25_34  -1.4285714285714284e+00
    w_25_10   full_original_Gini_324  -1.5164285714285713e+01
    MARKER    'MARKER'                 'INTORG'
    x_25_11   product_lb_22  -2.5353132922828682e-02
    x_25_11   product_ub_23  -4.2722001830985672e-02
    x_25_11   onehot_25_32  1
    x_25_11   stock_lb_264  11
    x_25_11   stock_ub_265  11
    x_25_11   parent_nonstrict_scope_266  4.1999999999999996e-02
    x_25_11   unique_nonzero_owner_335  -1
    MARKER    'MARKER'                 'INTEND'
    w_25_11   product_lb_22  1
    w_25_11   product_ub_23  1
    w_25_11   normalized_mass_25_33  1
    w_25_11   normalized_ratio_25_34  -1.5714285714285714e+00
    w_25_11   full_original_Gini_324  -1.9021428571428569e+01
    MARKER    'MARKER'                 'INTORG'
    x_25_12   OBJ       1.0499999999999995e-02
    x_25_12   product_lb_24  -2.5353132922828682e-02
    x_25_12   product_ub_25  -4.2722001830985672e-02
    x_25_12   onehot_25_32  1
    x_25_12   stock_lb_264  12
    x_25_12   stock_ub_265  12
    x_25_12   parent_nonstrict_scope_266  5.2499999999999991e-02
    x_25_12   unique_nonzero_owner_336  -1
    MARKER    'MARKER'                 'INTEND'
    w_25_12   product_lb_24  1
    w_25_12   product_ub_25  1
    w_25_12   normalized_mass_25_33  1
    w_25_12   normalized_ratio_25_34  -1.7142857142857142e+00
    w_25_12   full_original_Gini_324  -2.2878571428571426e+01
    MARKER    'MARKER'                 'INTORG'
    x_25_13   OBJ       2.0999999999999991e-02
    x_25_13   product_lb_26  -2.5353132922828682e-02
    x_25_13   product_ub_27  -4.2722001830985672e-02
    x_25_13   onehot_25_32  1
    x_25_13   stock_lb_264  13
    x_25_13   stock_ub_265  13
    x_25_13   parent_nonstrict_scope_266  6.2999999999999987e-02
    x_25_13   unique_nonzero_owner_337  -1
    MARKER    'MARKER'                 'INTEND'
    w_25_13   product_lb_26  1
    w_25_13   product_ub_27  1
    w_25_13   normalized_mass_25_33  1
    w_25_13   normalized_ratio_25_34  -1.8571428571428570e+00
    w_25_13   full_original_Gini_324  -2.6735714285714291e+01
    MARKER    'MARKER'                 'INTORG'
    x_25_14   OBJ       0.0315
    x_25_14   product_lb_28  -2.5353132922828682e-02
    x_25_14   product_ub_29  -4.2722001830985672e-02
    x_25_14   onehot_25_32  1
    x_25_14   stock_lb_264  14
    x_25_14   stock_ub_265  14
    x_25_14   parent_nonstrict_scope_266  0.0735
    x_25_14   unique_nonzero_owner_338  -1
    MARKER    'MARKER'                 'INTEND'
    w_25_14   product_lb_28  1
    w_25_14   product_ub_29  1
    w_25_14   normalized_mass_25_33  1
    w_25_14   normalized_ratio_25_34  -2
    w_25_14   full_original_Gini_324  -3.0592857142857145e+01
    MARKER    'MARKER'                 'INTORG'
    x_25_15   OBJ       4.1999999999999996e-02
    x_25_15   product_lb_30  -2.5353132922828682e-02
    x_25_15   product_ub_31  -4.2722001830985672e-02
    x_25_15   onehot_25_32  1
    x_25_15   stock_lb_264  15
    x_25_15   stock_ub_265  15
    x_25_15   parent_nonstrict_scope_266  8.3999999999999991e-02
    x_25_15   unique_nonzero_owner_339  -1
    MARKER    'MARKER'                 'INTEND'
    w_25_15   product_lb_30  1
    w_25_15   product_ub_31  1
    w_25_15   normalized_mass_25_33  1
    w_25_15   normalized_ratio_25_34  -2.1428571428571428e+00
    w_25_15   full_original_Gini_324  -3.4449999999999996e+01
    rho_25    normalized_ratio_25_34  1
    rho_25    block_pair_pos_283  -1
    rho_25    block_pair_neg_284  1
    rho_25    block_pair_pos_285  -1
    rho_25    block_pair_neg_286  1
    rho_25    block_pair_pos_287  -1
    rho_25    block_pair_neg_288  1
    rho_25    block_pair_pos_289  -1
    rho_25    block_pair_neg_290  1
    rho_25    block_pair_pos_291  -1
    rho_25    block_pair_neg_292  1
    rho_25    block_pair_pos_293  -1
    rho_25    block_pair_neg_294  1
    rho_25    block_pair_pos_295  -1
    rho_25    block_pair_neg_296  1
    rho_25    normalization_323  1
    MARKER    'MARKER'                 'INTORG'
    x_29_0    OBJ       0.048
    x_29_0    product_lb_35  -2.5353132922828682e-02
    x_29_0    product_ub_36  -4.2722001830985672e-02
    x_29_0    onehot_29_67  1
    x_29_0    parent_nonstrict_scope_266  0.096
    x_29_0    unique_nonzero_owner_340  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_0    product_lb_35  1
    w_29_0    product_ub_36  1
    w_29_0    normalized_mass_29_68  1
    w_29_0    full_original_Gini_324  -2.3407142857142855e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_1    OBJ       3.6000000000000004e-02
    x_29_1    product_lb_37  -2.5353132922828682e-02
    x_29_1    product_ub_38  -4.2722001830985672e-02
    x_29_1    onehot_29_67  1
    x_29_1    stock_lb_264  1
    x_29_1    stock_ub_265  1
    x_29_1    parent_nonstrict_scope_266  0.084
    x_29_1    unique_nonzero_owner_341  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_1    product_lb_37  1
    w_29_1    product_ub_38  1
    w_29_1    normalized_mass_29_68  1
    w_29_1    normalized_ratio_29_69  -0.125
    w_29_1    full_original_Gini_324  -2.0032142857142855e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_2    OBJ       2.4000000000000007e-02
    x_29_2    product_lb_39  -2.5353132922828682e-02
    x_29_2    product_ub_40  -4.2722001830985672e-02
    x_29_2    onehot_29_67  1
    x_29_2    stock_lb_264  2
    x_29_2    stock_ub_265  2
    x_29_2    parent_nonstrict_scope_266  7.2000000000000008e-02
    x_29_2    unique_nonzero_owner_342  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_2    product_lb_39  1
    w_29_2    product_ub_40  1
    w_29_2    normalized_mass_29_68  1
    w_29_2    normalized_ratio_29_69  -0.25
    w_29_2    full_original_Gini_324  -1.6757142857142856e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_3    OBJ       1.1999999999999997e-02
    x_29_3    product_lb_41  -2.5353132922828682e-02
    x_29_3    product_ub_42  -4.2722001830985672e-02
    x_29_3    onehot_29_67  1
    x_29_3    stock_lb_264  3
    x_29_3    stock_ub_265  3
    x_29_3    parent_nonstrict_scope_266  0.06
    x_29_3    unique_nonzero_owner_343  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_3    product_lb_41  1
    w_29_3    product_ub_42  1
    w_29_3    normalized_mass_29_68  1
    w_29_3    normalized_ratio_29_69  -0.375
    w_29_3    full_original_Gini_324  -1.4132142857142858e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_4    product_lb_43  -2.5353132922828682e-02
    x_29_4    product_ub_44  -4.2722001830985672e-02
    x_29_4    onehot_29_67  1
    x_29_4    stock_lb_264  4
    x_29_4    stock_ub_265  4
    x_29_4    parent_nonstrict_scope_266  0.048
    x_29_4    unique_nonzero_owner_344  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_4    product_lb_43  1
    w_29_4    product_ub_44  1
    w_29_4    normalized_mass_29_68  1
    w_29_4    normalized_ratio_29_69  -0.5
    w_29_4    full_original_Gini_324  -1.1707142857142857e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_5    OBJ       -1.1999999999999997e-02
    x_29_5    product_lb_45  -2.5353132922828682e-02
    x_29_5    product_ub_46  -4.2722001830985672e-02
    x_29_5    onehot_29_67  1
    x_29_5    stock_lb_264  5
    x_29_5    stock_ub_265  5
    x_29_5    parent_nonstrict_scope_266  3.6000000000000004e-02
    x_29_5    unique_nonzero_owner_345  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_5    product_lb_45  1
    w_29_5    product_ub_46  1
    w_29_5    normalized_mass_29_68  1
    w_29_5    normalized_ratio_29_69  -0.625
    w_29_5    full_original_Gini_324  -9.5821428571428573e+00
    MARKER    'MARKER'                 'INTORG'
    x_29_6    OBJ       -0.024
    x_29_6    product_lb_47  -2.5353132922828682e-02
    x_29_6    product_ub_48  -4.2722001830985672e-02
    x_29_6    onehot_29_67  1
    x_29_6    stock_lb_264  6
    x_29_6    stock_ub_265  6
    x_29_6    parent_nonstrict_scope_266  0.024
    x_29_6    unique_nonzero_owner_346  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_6    product_lb_47  1
    w_29_6    product_ub_48  1
    w_29_6    normalized_mass_29_68  1
    w_29_6    normalized_ratio_29_69  -0.75
    w_29_6    full_original_Gini_324  -7.4571428571428564e+00
    MARKER    'MARKER'                 'INTORG'
    x_29_7    OBJ       -3.6000000000000004e-02
    x_29_7    product_lb_49  -2.5353132922828682e-02
    x_29_7    product_ub_50  -4.2722001830985672e-02
    x_29_7    onehot_29_67  1
    x_29_7    stock_lb_264  7
    x_29_7    stock_ub_265  7
    x_29_7    parent_nonstrict_scope_266  0.012
    x_29_7    unique_nonzero_owner_347  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_7    product_lb_49  1
    w_29_7    product_ub_50  1
    w_29_7    normalized_mass_29_68  1
    w_29_7    normalized_ratio_29_69  -0.875
    w_29_7    full_original_Gini_324  -5.7678571428571432e+00
    MARKER    'MARKER'                 'INTORG'
    x_29_8    OBJ       -0.048
    x_29_8    product_lb_51  -2.5353132922828682e-02
    x_29_8    product_ub_52  -4.2722001830985672e-02
    x_29_8    onehot_29_67  1
    x_29_8    stock_lb_264  8
    x_29_8    stock_ub_265  8
    x_29_8    unique_nonzero_owner_348  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_8    product_lb_51  1
    w_29_8    product_ub_52  1
    w_29_8    normalized_mass_29_68  1
    w_29_8    normalized_ratio_29_69  -1
    w_29_8    full_original_Gini_324  -4.8928571428571432e+00
    MARKER    'MARKER'                 'INTORG'
    x_29_9    OBJ       -3.6000000000000004e-02
    x_29_9    product_lb_53  -2.5353132922828682e-02
    x_29_9    product_ub_54  -4.2722001830985672e-02
    x_29_9    onehot_29_67  1
    x_29_9    stock_lb_264  9
    x_29_9    stock_ub_265  9
    x_29_9    parent_nonstrict_scope_266  0.012
    x_29_9    unique_nonzero_owner_349  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_9    product_lb_53  1
    w_29_9    product_ub_54  1
    w_29_9    normalized_mass_29_68  1
    w_29_9    normalized_ratio_29_69  -1.125
    w_29_9    full_original_Gini_324  -7.5178571428571432e+00
    MARKER    'MARKER'                 'INTORG'
    x_29_10   OBJ       -0.024
    x_29_10   product_lb_55  -2.5353132922828682e-02
    x_29_10   product_ub_56  -4.2722001830985672e-02
    x_29_10   onehot_29_67  1
    x_29_10   stock_lb_264  10
    x_29_10   stock_ub_265  10
    x_29_10   parent_nonstrict_scope_266  0.024
    x_29_10   unique_nonzero_owner_350  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_10   product_lb_55  1
    w_29_10   product_ub_56  1
    w_29_10   normalized_mass_29_68  1
    w_29_10   normalized_ratio_29_69  -1.25
    w_29_10   full_original_Gini_324  -1.0342857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_11   OBJ       -1.1999999999999997e-02
    x_29_11   product_lb_57  -2.5353132922828682e-02
    x_29_11   product_ub_58  -4.2722001830985672e-02
    x_29_11   onehot_29_67  1
    x_29_11   stock_lb_264  11
    x_29_11   stock_ub_265  11
    x_29_11   parent_nonstrict_scope_266  3.6000000000000004e-02
    MARKER    'MARKER'                 'INTEND'
    w_29_11   product_lb_57  1
    w_29_11   product_ub_58  1
    w_29_11   normalized_mass_29_68  1
    w_29_11   normalized_ratio_29_69  -1.375
    w_29_11   full_original_Gini_324  -1.3717857142857143e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_12   product_lb_59  -2.5353132922828682e-02
    x_29_12   product_ub_60  -4.2722001830985672e-02
    x_29_12   onehot_29_67  1
    x_29_12   stock_lb_264  12
    x_29_12   stock_ub_265  12
    x_29_12   parent_nonstrict_scope_266  0.048
    x_29_12   unique_nonzero_owner_351  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_12   product_lb_59  1
    w_29_12   product_ub_60  1
    w_29_12   normalized_mass_29_68  1
    w_29_12   normalized_ratio_29_69  -1.5
    w_29_12   full_original_Gini_324  -1.7092857142857145e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_13   OBJ       1.1999999999999997e-02
    x_29_13   product_lb_61  -2.5353132922828682e-02
    x_29_13   product_ub_62  -4.2722001830985672e-02
    x_29_13   onehot_29_67  1
    x_29_13   stock_lb_264  13
    x_29_13   stock_ub_265  13
    x_29_13   parent_nonstrict_scope_266  0.06
    x_29_13   unique_nonzero_owner_352  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_13   product_lb_61  1
    w_29_13   product_ub_62  1
    w_29_13   normalized_mass_29_68  1
    w_29_13   normalized_ratio_29_69  -1.625
    w_29_13   full_original_Gini_324  -2.0467857142857145e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_14   OBJ       2.4000000000000007e-02
    x_29_14   product_lb_63  -2.5353132922828682e-02
    x_29_14   product_ub_64  -4.2722001830985672e-02
    x_29_14   onehot_29_67  1
    x_29_14   stock_lb_264  14
    x_29_14   stock_ub_265  14
    x_29_14   parent_nonstrict_scope_266  7.2000000000000008e-02
    x_29_14   unique_nonzero_owner_353  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_14   product_lb_63  1
    w_29_14   product_ub_64  1
    w_29_14   normalized_mass_29_68  1
    w_29_14   normalized_ratio_29_69  -1.75
    w_29_14   full_original_Gini_324  -2.3842857142857145e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_15   OBJ       3.6000000000000004e-02
    x_29_15   product_lb_65  -2.5353132922828682e-02
    x_29_15   product_ub_66  -4.2722001830985672e-02
    x_29_15   onehot_29_67  1
    x_29_15   stock_lb_264  15
    x_29_15   stock_ub_265  15
    x_29_15   parent_nonstrict_scope_266  0.084
    x_29_15   unique_nonzero_owner_354  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_15   product_lb_65  1
    w_29_15   product_ub_66  1
    w_29_15   normalized_mass_29_68  1
    w_29_15   normalized_ratio_29_69  -1.875
    w_29_15   full_original_Gini_324  -2.7217857142857145e+01
    rho_29    normalized_ratio_29_69  1
    rho_29    block_pair_pos_293  1
    rho_29    block_pair_neg_294  -1
    rho_29    block_pair_pos_301  -1
    rho_29    block_pair_neg_302  1
    rho_29    block_pair_pos_303  -1
    rho_29    block_pair_neg_304  1
    rho_29    block_pair_pos_305  -1
    rho_29    block_pair_neg_306  1
    rho_29    block_pair_pos_307  -1
    rho_29    block_pair_neg_308  1
    rho_29    block_pair_pos_309  -1
    rho_29    block_pair_neg_310  1
    rho_29    block_pair_pos_311  -1
    rho_29    block_pair_neg_312  1
    rho_29    normalization_323  1
    MARKER    'MARKER'                 'INTORG'
    x_31_0    OBJ       0.03675
    x_31_0    product_lb_70  -2.5353132922828682e-02
    x_31_0    product_ub_71  -4.2722001830985672e-02
    x_31_0    onehot_31_96  1
    x_31_0    parent_nonstrict_scope_266  0.0735
    x_31_0    unique_nonzero_owner_355  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_0    product_lb_70  1
    w_31_0    product_ub_71  1
    w_31_0    normalized_mass_31_97  1
    w_31_0    full_original_Gini_324  -2.3407142857142855e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_1    OBJ       2.6250000000000002e-02
    x_31_1    product_lb_72  -2.5353132922828682e-02
    x_31_1    product_ub_73  -4.2722001830985672e-02
    x_31_1    onehot_31_96  1
    x_31_1    stock_lb_264  1
    x_31_1    stock_ub_265  1
    x_31_1    parent_nonstrict_scope_266  0.063
    x_31_1    unique_nonzero_owner_356  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_1    product_lb_72  1
    w_31_1    product_ub_73  1
    w_31_1    normalized_mass_31_97  1
    w_31_1    normalized_ratio_31_98  -1.4285714285714285e-01
    w_31_1    full_original_Gini_324  -1.9550000000000008e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_2    OBJ       0.01575
    x_31_2    product_lb_74  -2.5353132922828682e-02
    x_31_2    product_ub_75  -4.2722001830985672e-02
    x_31_2    onehot_31_96  1
    x_31_2    stock_lb_264  2
    x_31_2    stock_ub_265  2
    x_31_2    parent_nonstrict_scope_266  0.0525
    MARKER    'MARKER'                 'INTEND'
    w_31_2    product_lb_74  1
    w_31_2    product_ub_75  1
    w_31_2    normalized_mass_31_97  1
    w_31_2    normalized_ratio_31_98  -2.8571428571428570e-01
    w_31_2    full_original_Gini_324  -1.6007142857142853e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_3    OBJ       5.2499999999999977e-03
    x_31_3    product_lb_76  -2.5353132922828682e-02
    x_31_3    product_ub_77  -4.2722001830985672e-02
    x_31_3    onehot_31_96  1
    x_31_3    stock_lb_264  3
    x_31_3    stock_ub_265  3
    x_31_3    parent_nonstrict_scope_266  4.1999999999999996e-02
    x_31_3    unique_nonzero_owner_357  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_3    product_lb_76  1
    w_31_3    product_ub_77  1
    w_31_3    normalized_mass_31_97  1
    w_31_3    normalized_ratio_31_98  -4.2857142857142855e-01
    w_31_3    full_original_Gini_324  -1.3064285714285711e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_4    OBJ       -5.2499999999999977e-03
    x_31_4    product_lb_78  -2.5353132922828682e-02
    x_31_4    product_ub_79  -4.2722001830985672e-02
    x_31_4    onehot_31_96  1
    x_31_4    stock_lb_264  4
    x_31_4    stock_ub_265  4
    x_31_4    parent_nonstrict_scope_266  0.0315
    x_31_4    unique_nonzero_owner_358  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_4    product_lb_78  1
    w_31_4    product_ub_79  1
    w_31_4    normalized_mass_31_97  1
    w_31_4    normalized_ratio_31_98  -5.7142857142857140e-01
    w_31_4    full_original_Gini_324  -1.0492857142857147e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_5    OBJ       -1.5749999999999993e-02
    x_31_5    product_lb_80  -2.5353132922828682e-02
    x_31_5    product_ub_81  -4.2722001830985672e-02
    x_31_5    onehot_31_96  1
    x_31_5    stock_lb_264  5
    x_31_5    stock_ub_265  5
    x_31_5    parent_nonstrict_scope_266  2.1000000000000005e-02
    x_31_5    unique_nonzero_owner_359  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_5    product_lb_80  1
    w_31_5    product_ub_81  1
    w_31_5    normalized_mass_31_97  1
    w_31_5    normalized_ratio_31_98  -7.1428571428571419e-01
    w_31_5    full_original_Gini_324  -8.0642857142857149e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_6    OBJ       -2.6249999999999996e-02
    x_31_6    product_lb_82  -2.5353132922828682e-02
    x_31_6    product_ub_83  -4.2722001830985672e-02
    x_31_6    onehot_31_96  1
    x_31_6    stock_lb_264  6
    x_31_6    stock_ub_265  6
    x_31_6    parent_nonstrict_scope_266  1.0500000000000002e-02
    x_31_6    unique_nonzero_owner_360  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_6    product_lb_82  1
    w_31_6    product_ub_83  1
    w_31_6    normalized_mass_31_97  1
    w_31_6    normalized_ratio_31_98  -8.5714285714285710e-01
    w_31_6    full_original_Gini_324  -5.9642857142857144e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_7    OBJ       -0.03675
    x_31_7    product_lb_84  -2.5353132922828682e-02
    x_31_7    product_ub_85  -4.2722001830985672e-02
    x_31_7    onehot_31_96  1
    x_31_7    stock_lb_264  7
    x_31_7    stock_ub_265  7
    x_31_7    unique_nonzero_owner_361  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_7    product_lb_84  1
    w_31_7    product_ub_85  1
    w_31_7    normalized_mass_31_97  1
    w_31_7    normalized_ratio_31_98  -1
    w_31_7    full_original_Gini_324  -4.8928571428571432e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_8    OBJ       -2.6250000000000002e-02
    x_31_8    product_lb_86  -2.5353132922828682e-02
    x_31_8    product_ub_87  -4.2722001830985672e-02
    x_31_8    onehot_31_96  1
    x_31_8    stock_lb_264  8
    x_31_8    stock_ub_265  8
    x_31_8    parent_nonstrict_scope_266  1.0499999999999995e-02
    x_31_8    unique_nonzero_owner_362  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_8    product_lb_86  1
    w_31_8    product_ub_87  1
    w_31_8    normalized_mass_31_97  1
    w_31_8    normalized_ratio_31_98  -1.1428571428571428e+00
    w_31_8    full_original_Gini_324  -7.8928571428571388e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_9    OBJ       -1.5750000000000007e-02
    x_31_9    product_lb_88  -2.5353132922828682e-02
    x_31_9    product_ub_89  -4.2722001830985672e-02
    x_31_9    onehot_31_96  1
    x_31_9    stock_lb_264  9
    x_31_9    stock_ub_265  9
    x_31_9    parent_nonstrict_scope_266  2.0999999999999991e-02
    x_31_9    unique_nonzero_owner_363  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_9    product_lb_88  1
    w_31_9    product_ub_89  1
    w_31_9    normalized_mass_31_97  1
    w_31_9    normalized_ratio_31_98  -1.2857142857142856e+00
    w_31_9    full_original_Gini_324  -1.1307142857142853e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_10   OBJ       -5.2500000000000116e-03
    x_31_10   product_lb_90  -2.5353132922828682e-02
    x_31_10   product_ub_91  -4.2722001830985672e-02
    x_31_10   onehot_31_96  1
    x_31_10   stock_lb_264  10
    x_31_10   stock_ub_265  10
    x_31_10   parent_nonstrict_scope_266  3.1499999999999986e-02
    x_31_10   unique_nonzero_owner_364  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_10   product_lb_90  1
    w_31_10   product_ub_91  1
    w_31_10   normalized_mass_31_97  1
    w_31_10   normalized_ratio_31_98  -1.4285714285714284e+00
    w_31_10   full_original_Gini_324  -1.5164285714285713e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_11   OBJ       5.2499999999999977e-03
    x_31_11   product_lb_92  -2.5353132922828682e-02
    x_31_11   product_ub_93  -4.2722001830985672e-02
    x_31_11   onehot_31_96  1
    x_31_11   stock_lb_264  11
    x_31_11   stock_ub_265  11
    x_31_11   parent_nonstrict_scope_266  4.1999999999999996e-02
    x_31_11   unique_nonzero_owner_365  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_11   product_lb_92  1
    w_31_11   product_ub_93  1
    w_31_11   normalized_mass_31_97  1
    w_31_11   normalized_ratio_31_98  -1.5714285714285714e+00
    w_31_11   full_original_Gini_324  -1.9021428571428569e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_12   OBJ       1.5749999999999993e-02
    x_31_12   product_lb_94  -2.5353132922828682e-02
    x_31_12   product_ub_95  -4.2722001830985672e-02
    x_31_12   onehot_31_96  1
    x_31_12   stock_lb_264  12
    x_31_12   stock_ub_265  12
    x_31_12   parent_nonstrict_scope_266  5.2499999999999991e-02
    x_31_12   unique_nonzero_owner_366  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_12   product_lb_94  1
    w_31_12   product_ub_95  1
    w_31_12   normalized_mass_31_97  1
    w_31_12   normalized_ratio_31_98  -1.7142857142857142e+00
    w_31_12   full_original_Gini_324  -2.2878571428571426e+01
    rho_31    normalized_ratio_31_98  1
    rho_31    block_pair_pos_295  1
    rho_31    block_pair_neg_296  -1
    rho_31    block_pair_pos_311  1
    rho_31    block_pair_neg_312  -1
    rho_31    block_pair_pos_313  -1
    rho_31    block_pair_neg_314  1
    rho_31    block_pair_pos_315  -1
    rho_31    block_pair_neg_316  1
    rho_31    block_pair_pos_317  -1
    rho_31    block_pair_neg_318  1
    rho_31    block_pair_pos_319  -1
    rho_31    block_pair_neg_320  1
    rho_31    block_pair_pos_321  -1
    rho_31    block_pair_neg_322  1
    rho_31    normalization_323  1
    MARKER    'MARKER'                 'INTORG'
    x_24_0    OBJ       0.048
    x_24_0    product_lb_99  -2.5353132922828682e-02
    x_24_0    product_ub_100  -4.2722001830985672e-02
    x_24_0    onehot_24_131  1
    x_24_0    parent_nonstrict_scope_266  0.096
    x_24_0    unique_nonzero_owner_367  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_0    product_lb_99  1
    w_24_0    product_ub_100  1
    w_24_0    normalized_mass_24_132  1
    w_24_0    full_original_Gini_324  -2.3407142857142855e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_1    OBJ       3.6000000000000004e-02
    x_24_1    product_lb_101  -2.5353132922828682e-02
    x_24_1    product_ub_102  -4.2722001830985672e-02
    x_24_1    onehot_24_131  1
    x_24_1    stock_lb_264  1
    x_24_1    stock_ub_265  1
    x_24_1    parent_nonstrict_scope_266  0.084
    x_24_1    unique_nonzero_owner_368  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_1    product_lb_101  1
    w_24_1    product_ub_102  1
    w_24_1    normalized_mass_24_132  1
    w_24_1    normalized_ratio_24_133  -0.125
    w_24_1    full_original_Gini_324  -2.0032142857142855e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_2    OBJ       2.4000000000000007e-02
    x_24_2    product_lb_103  -2.5353132922828682e-02
    x_24_2    product_ub_104  -4.2722001830985672e-02
    x_24_2    onehot_24_131  1
    x_24_2    stock_lb_264  2
    x_24_2    stock_ub_265  2
    x_24_2    parent_nonstrict_scope_266  7.2000000000000008e-02
    x_24_2    unique_nonzero_owner_369  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_2    product_lb_103  1
    w_24_2    product_ub_104  1
    w_24_2    normalized_mass_24_132  1
    w_24_2    normalized_ratio_24_133  -0.25
    w_24_2    full_original_Gini_324  -1.6757142857142856e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_3    OBJ       1.1999999999999997e-02
    x_24_3    product_lb_105  -2.5353132922828682e-02
    x_24_3    product_ub_106  -4.2722001830985672e-02
    x_24_3    onehot_24_131  1
    x_24_3    stock_lb_264  3
    x_24_3    stock_ub_265  3
    x_24_3    parent_nonstrict_scope_266  0.06
    x_24_3    unique_nonzero_owner_370  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_3    product_lb_105  1
    w_24_3    product_ub_106  1
    w_24_3    normalized_mass_24_132  1
    w_24_3    normalized_ratio_24_133  -0.375
    w_24_3    full_original_Gini_324  -1.4132142857142858e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_4    product_lb_107  -2.5353132922828682e-02
    x_24_4    product_ub_108  -4.2722001830985672e-02
    x_24_4    onehot_24_131  1
    x_24_4    stock_lb_264  4
    x_24_4    stock_ub_265  4
    x_24_4    parent_nonstrict_scope_266  0.048
    x_24_4    unique_nonzero_owner_371  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_4    product_lb_107  1
    w_24_4    product_ub_108  1
    w_24_4    normalized_mass_24_132  1
    w_24_4    normalized_ratio_24_133  -0.5
    w_24_4    full_original_Gini_324  -1.1707142857142857e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_5    OBJ       -1.1999999999999997e-02
    x_24_5    product_lb_109  -2.5353132922828682e-02
    x_24_5    product_ub_110  -4.2722001830985672e-02
    x_24_5    onehot_24_131  1
    x_24_5    stock_lb_264  5
    x_24_5    stock_ub_265  5
    x_24_5    parent_nonstrict_scope_266  3.6000000000000004e-02
    x_24_5    unique_nonzero_owner_372  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_5    product_lb_109  1
    w_24_5    product_ub_110  1
    w_24_5    normalized_mass_24_132  1
    w_24_5    normalized_ratio_24_133  -0.625
    w_24_5    full_original_Gini_324  -9.5821428571428573e+00
    MARKER    'MARKER'                 'INTORG'
    x_24_6    OBJ       -0.024
    x_24_6    product_lb_111  -2.5353132922828682e-02
    x_24_6    product_ub_112  -4.2722001830985672e-02
    x_24_6    onehot_24_131  1
    x_24_6    stock_lb_264  6
    x_24_6    stock_ub_265  6
    x_24_6    parent_nonstrict_scope_266  0.024
    x_24_6    unique_nonzero_owner_373  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_6    product_lb_111  1
    w_24_6    product_ub_112  1
    w_24_6    normalized_mass_24_132  1
    w_24_6    normalized_ratio_24_133  -0.75
    w_24_6    full_original_Gini_324  -7.4571428571428564e+00
    MARKER    'MARKER'                 'INTORG'
    x_24_7    OBJ       -3.6000000000000004e-02
    x_24_7    product_lb_113  -2.5353132922828682e-02
    x_24_7    product_ub_114  -4.2722001830985672e-02
    x_24_7    onehot_24_131  1
    x_24_7    stock_lb_264  7
    x_24_7    stock_ub_265  7
    x_24_7    parent_nonstrict_scope_266  0.012
    x_24_7    unique_nonzero_owner_374  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_7    product_lb_113  1
    w_24_7    product_ub_114  1
    w_24_7    normalized_mass_24_132  1
    w_24_7    normalized_ratio_24_133  -0.875
    w_24_7    full_original_Gini_324  -5.7678571428571432e+00
    MARKER    'MARKER'                 'INTORG'
    x_24_8    OBJ       -0.048
    x_24_8    product_lb_115  -2.5353132922828682e-02
    x_24_8    product_ub_116  -4.2722001830985672e-02
    x_24_8    onehot_24_131  1
    x_24_8    stock_lb_264  8
    x_24_8    stock_ub_265  8
    x_24_8    unique_nonzero_owner_375  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_8    product_lb_115  1
    w_24_8    product_ub_116  1
    w_24_8    normalized_mass_24_132  1
    w_24_8    normalized_ratio_24_133  -1
    w_24_8    full_original_Gini_324  -4.8928571428571432e+00
    MARKER    'MARKER'                 'INTORG'
    x_24_9    OBJ       -3.6000000000000004e-02
    x_24_9    product_lb_117  -2.5353132922828682e-02
    x_24_9    product_ub_118  -4.2722001830985672e-02
    x_24_9    onehot_24_131  1
    x_24_9    stock_lb_264  9
    x_24_9    stock_ub_265  9
    x_24_9    parent_nonstrict_scope_266  0.012
    x_24_9    unique_nonzero_owner_376  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_9    product_lb_117  1
    w_24_9    product_ub_118  1
    w_24_9    normalized_mass_24_132  1
    w_24_9    normalized_ratio_24_133  -1.125
    w_24_9    full_original_Gini_324  -7.5178571428571432e+00
    MARKER    'MARKER'                 'INTORG'
    x_24_10   OBJ       -0.024
    x_24_10   product_lb_119  -2.5353132922828682e-02
    x_24_10   product_ub_120  -4.2722001830985672e-02
    x_24_10   onehot_24_131  1
    x_24_10   stock_lb_264  10
    x_24_10   stock_ub_265  10
    x_24_10   parent_nonstrict_scope_266  0.024
    x_24_10   unique_nonzero_owner_377  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_10   product_lb_119  1
    w_24_10   product_ub_120  1
    w_24_10   normalized_mass_24_132  1
    w_24_10   normalized_ratio_24_133  -1.25
    w_24_10   full_original_Gini_324  -1.0342857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_11   OBJ       -1.1999999999999997e-02
    x_24_11   product_lb_121  -2.5353132922828682e-02
    x_24_11   product_ub_122  -4.2722001830985672e-02
    x_24_11   onehot_24_131  1
    x_24_11   stock_lb_264  11
    x_24_11   stock_ub_265  11
    x_24_11   parent_nonstrict_scope_266  3.6000000000000004e-02
    MARKER    'MARKER'                 'INTEND'
    w_24_11   product_lb_121  1
    w_24_11   product_ub_122  1
    w_24_11   normalized_mass_24_132  1
    w_24_11   normalized_ratio_24_133  -1.375
    w_24_11   full_original_Gini_324  -1.3717857142857143e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_12   product_lb_123  -2.5353132922828682e-02
    x_24_12   product_ub_124  -4.2722001830985672e-02
    x_24_12   onehot_24_131  1
    x_24_12   stock_lb_264  12
    x_24_12   stock_ub_265  12
    x_24_12   parent_nonstrict_scope_266  0.048
    x_24_12   unique_nonzero_owner_378  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_12   product_lb_123  1
    w_24_12   product_ub_124  1
    w_24_12   normalized_mass_24_132  1
    w_24_12   normalized_ratio_24_133  -1.5
    w_24_12   full_original_Gini_324  -1.7092857142857145e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_13   OBJ       1.1999999999999997e-02
    x_24_13   product_lb_125  -2.5353132922828682e-02
    x_24_13   product_ub_126  -4.2722001830985672e-02
    x_24_13   onehot_24_131  1
    x_24_13   stock_lb_264  13
    x_24_13   stock_ub_265  13
    x_24_13   parent_nonstrict_scope_266  0.06
    x_24_13   unique_nonzero_owner_379  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_13   product_lb_125  1
    w_24_13   product_ub_126  1
    w_24_13   normalized_mass_24_132  1
    w_24_13   normalized_ratio_24_133  -1.625
    w_24_13   full_original_Gini_324  -2.0467857142857145e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_14   OBJ       2.4000000000000007e-02
    x_24_14   product_lb_127  -2.5353132922828682e-02
    x_24_14   product_ub_128  -4.2722001830985672e-02
    x_24_14   onehot_24_131  1
    x_24_14   stock_lb_264  14
    x_24_14   stock_ub_265  14
    x_24_14   parent_nonstrict_scope_266  7.2000000000000008e-02
    x_24_14   unique_nonzero_owner_380  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_14   product_lb_127  1
    w_24_14   product_ub_128  1
    w_24_14   normalized_mass_24_132  1
    w_24_14   normalized_ratio_24_133  -1.75
    w_24_14   full_original_Gini_324  -2.3842857142857145e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_15   OBJ       3.6000000000000004e-02
    x_24_15   product_lb_129  -2.5353132922828682e-02
    x_24_15   product_ub_130  -4.2722001830985672e-02
    x_24_15   onehot_24_131  1
    x_24_15   stock_lb_264  15
    x_24_15   stock_ub_265  15
    x_24_15   parent_nonstrict_scope_266  0.084
    x_24_15   unique_nonzero_owner_381  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_15   product_lb_129  1
    w_24_15   product_ub_130  1
    w_24_15   normalized_mass_24_132  1
    w_24_15   normalized_ratio_24_133  -1.875
    w_24_15   full_original_Gini_324  -2.7217857142857145e+01
    rho_24    normalized_ratio_24_133  1
    rho_24    block_pair_pos_275  -1
    rho_24    block_pair_neg_276  1
    rho_24    block_pair_pos_277  -1
    rho_24    block_pair_neg_278  1
    rho_24    block_pair_pos_279  -1
    rho_24    block_pair_neg_280  1
    rho_24    block_pair_pos_281  -1
    rho_24    block_pair_neg_282  1
    rho_24    block_pair_pos_289  1
    rho_24    block_pair_neg_290  -1
    rho_24    block_pair_pos_307  1
    rho_24    block_pair_neg_308  -1
    rho_24    block_pair_pos_319  1
    rho_24    block_pair_neg_320  -1
    rho_24    normalization_323  1
    MARKER    'MARKER'                 'INTORG'
    x_2_0     OBJ       0.0315
    x_2_0     product_lb_134  -2.5353132922828682e-02
    x_2_0     product_ub_135  -4.2722001830985672e-02
    x_2_0     onehot_2_166  1
    x_2_0     parent_nonstrict_scope_266  0.0735
    MARKER    'MARKER'                 'INTEND'
    w_2_0     product_lb_134  1
    w_2_0     product_ub_135  1
    w_2_0     normalized_mass_2_167  1
    w_2_0     full_original_Gini_324  -2.3407142857142855e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_1     OBJ       2.1000000000000005e-02
    x_2_1     product_lb_136  -2.5353132922828682e-02
    x_2_1     product_ub_137  -4.2722001830985672e-02
    x_2_1     onehot_2_166  1
    x_2_1     stock_lb_264  1
    x_2_1     stock_ub_265  1
    x_2_1     parent_nonstrict_scope_266  0.063
    x_2_1     unique_nonzero_owner_382  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_1     product_lb_136  1
    w_2_1     product_ub_137  1
    w_2_1     normalized_mass_2_167  1
    w_2_1     normalized_ratio_2_168  -1.4285714285714285e-01
    w_2_1     full_original_Gini_324  -1.9550000000000008e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_2     OBJ       1.0500000000000002e-02
    x_2_2     product_lb_138  -2.5353132922828682e-02
    x_2_2     product_ub_139  -4.2722001830985672e-02
    x_2_2     onehot_2_166  1
    x_2_2     stock_lb_264  2
    x_2_2     stock_ub_265  2
    x_2_2     parent_nonstrict_scope_266  0.0525
    x_2_2     unique_nonzero_owner_383  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_2     product_lb_138  1
    w_2_2     product_ub_139  1
    w_2_2     normalized_mass_2_167  1
    w_2_2     normalized_ratio_2_168  -2.8571428571428570e-01
    w_2_2     full_original_Gini_324  -1.6007142857142853e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_3     product_lb_140  -2.5353132922828682e-02
    x_2_3     product_ub_141  -4.2722001830985672e-02
    x_2_3     onehot_2_166  1
    x_2_3     stock_lb_264  3
    x_2_3     stock_ub_265  3
    x_2_3     parent_nonstrict_scope_266  4.1999999999999996e-02
    x_2_3     unique_nonzero_owner_384  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_3     product_lb_140  1
    w_2_3     product_ub_141  1
    w_2_3     normalized_mass_2_167  1
    w_2_3     normalized_ratio_2_168  -4.2857142857142855e-01
    w_2_3     full_original_Gini_324  -1.3064285714285711e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_4     OBJ       -1.0499999999999995e-02
    x_2_4     product_lb_142  -2.5353132922828682e-02
    x_2_4     product_ub_143  -4.2722001830985672e-02
    x_2_4     onehot_2_166  1
    x_2_4     stock_lb_264  4
    x_2_4     stock_ub_265  4
    x_2_4     parent_nonstrict_scope_266  0.0315
    x_2_4     unique_nonzero_owner_385  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_4     product_lb_142  1
    w_2_4     product_ub_143  1
    w_2_4     normalized_mass_2_167  1
    w_2_4     normalized_ratio_2_168  -5.7142857142857140e-01
    w_2_4     full_original_Gini_324  -1.0492857142857147e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_5     OBJ       -2.0999999999999991e-02
    x_2_5     product_lb_144  -2.5353132922828682e-02
    x_2_5     product_ub_145  -4.2722001830985672e-02
    x_2_5     onehot_2_166  1
    x_2_5     stock_lb_264  5
    x_2_5     stock_ub_265  5
    x_2_5     parent_nonstrict_scope_266  2.1000000000000005e-02
    x_2_5     unique_nonzero_owner_386  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_5     product_lb_144  1
    w_2_5     product_ub_145  1
    w_2_5     normalized_mass_2_167  1
    w_2_5     normalized_ratio_2_168  -7.1428571428571419e-01
    w_2_5     full_original_Gini_324  -8.0642857142857149e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_6     OBJ       -3.1499999999999993e-02
    x_2_6     product_lb_146  -2.5353132922828682e-02
    x_2_6     product_ub_147  -4.2722001830985672e-02
    x_2_6     onehot_2_166  1
    x_2_6     stock_lb_264  6
    x_2_6     stock_ub_265  6
    x_2_6     parent_nonstrict_scope_266  1.0500000000000002e-02
    x_2_6     unique_nonzero_owner_387  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_6     product_lb_146  1
    w_2_6     product_ub_147  1
    w_2_6     normalized_mass_2_167  1
    w_2_6     normalized_ratio_2_168  -8.5714285714285710e-01
    w_2_6     full_original_Gini_324  -5.9642857142857144e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_7     OBJ       -4.1999999999999996e-02
    x_2_7     product_lb_148  -2.5353132922828682e-02
    x_2_7     product_ub_149  -4.2722001830985672e-02
    x_2_7     onehot_2_166  1
    x_2_7     stock_lb_264  7
    x_2_7     stock_ub_265  7
    x_2_7     unique_nonzero_owner_388  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_7     product_lb_148  1
    w_2_7     product_ub_149  1
    w_2_7     normalized_mass_2_167  1
    w_2_7     normalized_ratio_2_168  -1
    w_2_7     full_original_Gini_324  -4.8928571428571432e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_8     OBJ       -0.0315
    x_2_8     product_lb_150  -2.5353132922828682e-02
    x_2_8     product_ub_151  -4.2722001830985672e-02
    x_2_8     onehot_2_166  1
    x_2_8     stock_lb_264  8
    x_2_8     stock_ub_265  8
    x_2_8     parent_nonstrict_scope_266  1.0499999999999995e-02
    x_2_8     unique_nonzero_owner_389  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_8     product_lb_150  1
    w_2_8     product_ub_151  1
    w_2_8     normalized_mass_2_167  1
    w_2_8     normalized_ratio_2_168  -1.1428571428571428e+00
    w_2_8     full_original_Gini_324  -7.8928571428571388e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_9     OBJ       -2.1000000000000005e-02
    x_2_9     product_lb_152  -2.5353132922828682e-02
    x_2_9     product_ub_153  -4.2722001830985672e-02
    x_2_9     onehot_2_166  1
    x_2_9     stock_lb_264  9
    x_2_9     stock_ub_265  9
    x_2_9     parent_nonstrict_scope_266  2.0999999999999991e-02
    x_2_9     unique_nonzero_owner_390  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_9     product_lb_152  1
    w_2_9     product_ub_153  1
    w_2_9     normalized_mass_2_167  1
    w_2_9     normalized_ratio_2_168  -1.2857142857142856e+00
    w_2_9     full_original_Gini_324  -1.1307142857142853e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_10    OBJ       -1.0500000000000009e-02
    x_2_10    product_lb_154  -2.5353132922828682e-02
    x_2_10    product_ub_155  -4.2722001830985672e-02
    x_2_10    onehot_2_166  1
    x_2_10    stock_lb_264  10
    x_2_10    stock_ub_265  10
    x_2_10    parent_nonstrict_scope_266  3.1499999999999986e-02
    x_2_10    unique_nonzero_owner_391  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_10    product_lb_154  1
    w_2_10    product_ub_155  1
    w_2_10    normalized_mass_2_167  1
    w_2_10    normalized_ratio_2_168  -1.4285714285714284e+00
    w_2_10    full_original_Gini_324  -1.5164285714285713e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_11    product_lb_156  -2.5353132922828682e-02
    x_2_11    product_ub_157  -4.2722001830985672e-02
    x_2_11    onehot_2_166  1
    x_2_11    stock_lb_264  11
    x_2_11    stock_ub_265  11
    x_2_11    parent_nonstrict_scope_266  4.1999999999999996e-02
    x_2_11    unique_nonzero_owner_392  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_11    product_lb_156  1
    w_2_11    product_ub_157  1
    w_2_11    normalized_mass_2_167  1
    w_2_11    normalized_ratio_2_168  -1.5714285714285714e+00
    w_2_11    full_original_Gini_324  -1.9021428571428569e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_12    OBJ       1.0499999999999995e-02
    x_2_12    product_lb_158  -2.5353132922828682e-02
    x_2_12    product_ub_159  -4.2722001830985672e-02
    x_2_12    onehot_2_166  1
    x_2_12    stock_lb_264  12
    x_2_12    stock_ub_265  12
    x_2_12    parent_nonstrict_scope_266  5.2499999999999991e-02
    x_2_12    unique_nonzero_owner_393  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_12    product_lb_158  1
    w_2_12    product_ub_159  1
    w_2_12    normalized_mass_2_167  1
    w_2_12    normalized_ratio_2_168  -1.7142857142857142e+00
    w_2_12    full_original_Gini_324  -2.2878571428571426e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_13    OBJ       2.0999999999999991e-02
    x_2_13    product_lb_160  -2.5353132922828682e-02
    x_2_13    product_ub_161  -4.2722001830985672e-02
    x_2_13    onehot_2_166  1
    x_2_13    stock_lb_264  13
    x_2_13    stock_ub_265  13
    x_2_13    parent_nonstrict_scope_266  6.2999999999999987e-02
    x_2_13    unique_nonzero_owner_394  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_13    product_lb_160  1
    w_2_13    product_ub_161  1
    w_2_13    normalized_mass_2_167  1
    w_2_13    normalized_ratio_2_168  -1.8571428571428570e+00
    w_2_13    full_original_Gini_324  -2.6735714285714291e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_14    OBJ       0.0315
    x_2_14    product_lb_162  -2.5353132922828682e-02
    x_2_14    product_ub_163  -4.2722001830985672e-02
    x_2_14    onehot_2_166  1
    x_2_14    stock_lb_264  14
    x_2_14    stock_ub_265  14
    x_2_14    parent_nonstrict_scope_266  0.0735
    x_2_14    unique_nonzero_owner_395  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_14    product_lb_162  1
    w_2_14    product_ub_163  1
    w_2_14    normalized_mass_2_167  1
    w_2_14    normalized_ratio_2_168  -2
    w_2_14    full_original_Gini_324  -3.0592857142857145e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_15    OBJ       4.1999999999999996e-02
    x_2_15    product_lb_164  -2.5353132922828682e-02
    x_2_15    product_ub_165  -4.2722001830985672e-02
    x_2_15    onehot_2_166  1
    x_2_15    stock_lb_264  15
    x_2_15    stock_ub_265  15
    x_2_15    parent_nonstrict_scope_266  8.3999999999999991e-02
    x_2_15    unique_nonzero_owner_396  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_15    product_lb_164  1
    w_2_15    product_ub_165  1
    w_2_15    normalized_mass_2_167  1
    w_2_15    normalized_ratio_2_168  -2.1428571428571428e+00
    w_2_15    full_original_Gini_324  -3.4449999999999996e+01
    rho_2     normalized_ratio_2_168  1
    rho_2     block_pair_pos_267  -1
    rho_2     block_pair_neg_268  1
    rho_2     block_pair_pos_269  -1
    rho_2     block_pair_neg_270  1
    rho_2     block_pair_pos_271  -1
    rho_2     block_pair_neg_272  1
    rho_2     block_pair_pos_275  1
    rho_2     block_pair_neg_276  -1
    rho_2     block_pair_pos_283  1
    rho_2     block_pair_neg_284  -1
    rho_2     block_pair_pos_301  1
    rho_2     block_pair_neg_302  -1
    rho_2     block_pair_pos_313  1
    rho_2     block_pair_neg_314  -1
    rho_2     normalization_323  1
    MARKER    'MARKER'                 'INTORG'
    x_27_0    OBJ       0.0315
    x_27_0    product_lb_169  -2.5353132922828682e-02
    x_27_0    product_ub_170  -4.2722001830985672e-02
    x_27_0    onehot_27_201  1
    x_27_0    parent_nonstrict_scope_266  0.0735
    x_27_0    unique_nonzero_owner_397  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_0    product_lb_169  1
    w_27_0    product_ub_170  1
    w_27_0    normalized_mass_27_202  1
    w_27_0    full_original_Gini_324  -2.3407142857142855e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_1    OBJ       2.1000000000000005e-02
    x_27_1    product_lb_171  -2.5353132922828682e-02
    x_27_1    product_ub_172  -4.2722001830985672e-02
    x_27_1    onehot_27_201  1
    x_27_1    stock_lb_264  1
    x_27_1    stock_ub_265  1
    x_27_1    parent_nonstrict_scope_266  0.063
    x_27_1    unique_nonzero_owner_398  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_1    product_lb_171  1
    w_27_1    product_ub_172  1
    w_27_1    normalized_mass_27_202  1
    w_27_1    normalized_ratio_27_203  -1.4285714285714285e-01
    w_27_1    full_original_Gini_324  -1.9550000000000008e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_2    OBJ       1.0500000000000002e-02
    x_27_2    product_lb_173  -2.5353132922828682e-02
    x_27_2    product_ub_174  -4.2722001830985672e-02
    x_27_2    onehot_27_201  1
    x_27_2    stock_lb_264  2
    x_27_2    stock_ub_265  2
    x_27_2    parent_nonstrict_scope_266  0.0525
    x_27_2    unique_nonzero_owner_399  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_2    product_lb_173  1
    w_27_2    product_ub_174  1
    w_27_2    normalized_mass_27_202  1
    w_27_2    normalized_ratio_27_203  -2.8571428571428570e-01
    w_27_2    full_original_Gini_324  -1.6007142857142853e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_3    product_lb_175  -2.5353132922828682e-02
    x_27_3    product_ub_176  -4.2722001830985672e-02
    x_27_3    onehot_27_201  1
    x_27_3    stock_lb_264  3
    x_27_3    stock_ub_265  3
    x_27_3    parent_nonstrict_scope_266  4.1999999999999996e-02
    x_27_3    unique_nonzero_owner_400  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_3    product_lb_175  1
    w_27_3    product_ub_176  1
    w_27_3    normalized_mass_27_202  1
    w_27_3    normalized_ratio_27_203  -4.2857142857142855e-01
    w_27_3    full_original_Gini_324  -1.3064285714285711e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_4    OBJ       -1.0499999999999995e-02
    x_27_4    product_lb_177  -2.5353132922828682e-02
    x_27_4    product_ub_178  -4.2722001830985672e-02
    x_27_4    onehot_27_201  1
    x_27_4    stock_lb_264  4
    x_27_4    stock_ub_265  4
    x_27_4    parent_nonstrict_scope_266  0.0315
    x_27_4    unique_nonzero_owner_401  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_4    product_lb_177  1
    w_27_4    product_ub_178  1
    w_27_4    normalized_mass_27_202  1
    w_27_4    normalized_ratio_27_203  -5.7142857142857140e-01
    w_27_4    full_original_Gini_324  -1.0492857142857147e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_5    OBJ       -2.0999999999999991e-02
    x_27_5    product_lb_179  -2.5353132922828682e-02
    x_27_5    product_ub_180  -4.2722001830985672e-02
    x_27_5    onehot_27_201  1
    x_27_5    stock_lb_264  5
    x_27_5    stock_ub_265  5
    x_27_5    parent_nonstrict_scope_266  2.1000000000000005e-02
    x_27_5    unique_nonzero_owner_402  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_5    product_lb_179  1
    w_27_5    product_ub_180  1
    w_27_5    normalized_mass_27_202  1
    w_27_5    normalized_ratio_27_203  -7.1428571428571419e-01
    w_27_5    full_original_Gini_324  -8.0642857142857149e+00
    MARKER    'MARKER'                 'INTORG'
    x_27_6    OBJ       -3.1499999999999993e-02
    x_27_6    product_lb_181  -2.5353132922828682e-02
    x_27_6    product_ub_182  -4.2722001830985672e-02
    x_27_6    onehot_27_201  1
    x_27_6    stock_lb_264  6
    x_27_6    stock_ub_265  6
    x_27_6    parent_nonstrict_scope_266  1.0500000000000002e-02
    x_27_6    unique_nonzero_owner_403  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_6    product_lb_181  1
    w_27_6    product_ub_182  1
    w_27_6    normalized_mass_27_202  1
    w_27_6    normalized_ratio_27_203  -8.5714285714285710e-01
    w_27_6    full_original_Gini_324  -5.9642857142857144e+00
    MARKER    'MARKER'                 'INTORG'
    x_27_7    OBJ       -4.1999999999999996e-02
    x_27_7    product_lb_183  -2.5353132922828682e-02
    x_27_7    product_ub_184  -4.2722001830985672e-02
    x_27_7    onehot_27_201  1
    x_27_7    stock_lb_264  7
    x_27_7    stock_ub_265  7
    x_27_7    unique_nonzero_owner_404  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_7    product_lb_183  1
    w_27_7    product_ub_184  1
    w_27_7    normalized_mass_27_202  1
    w_27_7    normalized_ratio_27_203  -1
    w_27_7    full_original_Gini_324  -4.8928571428571432e+00
    MARKER    'MARKER'                 'INTORG'
    x_27_8    OBJ       -0.0315
    x_27_8    product_lb_185  -2.5353132922828682e-02
    x_27_8    product_ub_186  -4.2722001830985672e-02
    x_27_8    onehot_27_201  1
    x_27_8    stock_lb_264  8
    x_27_8    stock_ub_265  8
    x_27_8    parent_nonstrict_scope_266  1.0499999999999995e-02
    x_27_8    unique_nonzero_owner_405  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_8    product_lb_185  1
    w_27_8    product_ub_186  1
    w_27_8    normalized_mass_27_202  1
    w_27_8    normalized_ratio_27_203  -1.1428571428571428e+00
    w_27_8    full_original_Gini_324  -7.8928571428571388e+00
    MARKER    'MARKER'                 'INTORG'
    x_27_9    OBJ       -2.1000000000000005e-02
    x_27_9    product_lb_187  -2.5353132922828682e-02
    x_27_9    product_ub_188  -4.2722001830985672e-02
    x_27_9    onehot_27_201  1
    x_27_9    stock_lb_264  9
    x_27_9    stock_ub_265  9
    x_27_9    parent_nonstrict_scope_266  2.0999999999999991e-02
    x_27_9    unique_nonzero_owner_406  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_9    product_lb_187  1
    w_27_9    product_ub_188  1
    w_27_9    normalized_mass_27_202  1
    w_27_9    normalized_ratio_27_203  -1.2857142857142856e+00
    w_27_9    full_original_Gini_324  -1.1307142857142853e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_10   OBJ       -1.0500000000000009e-02
    x_27_10   product_lb_189  -2.5353132922828682e-02
    x_27_10   product_ub_190  -4.2722001830985672e-02
    x_27_10   onehot_27_201  1
    x_27_10   stock_lb_264  10
    x_27_10   stock_ub_265  10
    x_27_10   parent_nonstrict_scope_266  3.1499999999999986e-02
    x_27_10   unique_nonzero_owner_407  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_10   product_lb_189  1
    w_27_10   product_ub_190  1
    w_27_10   normalized_mass_27_202  1
    w_27_10   normalized_ratio_27_203  -1.4285714285714284e+00
    w_27_10   full_original_Gini_324  -1.5164285714285713e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_11   product_lb_191  -2.5353132922828682e-02
    x_27_11   product_ub_192  -4.2722001830985672e-02
    x_27_11   onehot_27_201  1
    x_27_11   stock_lb_264  11
    x_27_11   stock_ub_265  11
    x_27_11   parent_nonstrict_scope_266  4.1999999999999996e-02
    MARKER    'MARKER'                 'INTEND'
    w_27_11   product_lb_191  1
    w_27_11   product_ub_192  1
    w_27_11   normalized_mass_27_202  1
    w_27_11   normalized_ratio_27_203  -1.5714285714285714e+00
    w_27_11   full_original_Gini_324  -1.9021428571428569e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_12   OBJ       1.0499999999999995e-02
    x_27_12   product_lb_193  -2.5353132922828682e-02
    x_27_12   product_ub_194  -4.2722001830985672e-02
    x_27_12   onehot_27_201  1
    x_27_12   stock_lb_264  12
    x_27_12   stock_ub_265  12
    x_27_12   parent_nonstrict_scope_266  5.2499999999999991e-02
    x_27_12   unique_nonzero_owner_408  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_12   product_lb_193  1
    w_27_12   product_ub_194  1
    w_27_12   normalized_mass_27_202  1
    w_27_12   normalized_ratio_27_203  -1.7142857142857142e+00
    w_27_12   full_original_Gini_324  -2.2878571428571426e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_13   OBJ       2.0999999999999991e-02
    x_27_13   product_lb_195  -2.5353132922828682e-02
    x_27_13   product_ub_196  -4.2722001830985672e-02
    x_27_13   onehot_27_201  1
    x_27_13   stock_lb_264  13
    x_27_13   stock_ub_265  13
    x_27_13   parent_nonstrict_scope_266  6.2999999999999987e-02
    x_27_13   unique_nonzero_owner_409  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_13   product_lb_195  1
    w_27_13   product_ub_196  1
    w_27_13   normalized_mass_27_202  1
    w_27_13   normalized_ratio_27_203  -1.8571428571428570e+00
    w_27_13   full_original_Gini_324  -2.6735714285714291e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_14   OBJ       0.0315
    x_27_14   product_lb_197  -2.5353132922828682e-02
    x_27_14   product_ub_198  -4.2722001830985672e-02
    x_27_14   onehot_27_201  1
    x_27_14   stock_lb_264  14
    x_27_14   stock_ub_265  14
    x_27_14   parent_nonstrict_scope_266  0.0735
    x_27_14   unique_nonzero_owner_410  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_14   product_lb_197  1
    w_27_14   product_ub_198  1
    w_27_14   normalized_mass_27_202  1
    w_27_14   normalized_ratio_27_203  -2
    w_27_14   full_original_Gini_324  -3.0592857142857145e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_15   OBJ       4.1999999999999996e-02
    x_27_15   product_lb_199  -2.5353132922828682e-02
    x_27_15   product_ub_200  -4.2722001830985672e-02
    x_27_15   onehot_27_201  1
    x_27_15   stock_lb_264  15
    x_27_15   stock_ub_265  15
    x_27_15   parent_nonstrict_scope_266  8.3999999999999991e-02
    x_27_15   unique_nonzero_owner_411  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_15   product_lb_199  1
    w_27_15   product_ub_200  1
    w_27_15   normalized_mass_27_202  1
    w_27_15   normalized_ratio_27_203  -2.1428571428571428e+00
    w_27_15   full_original_Gini_324  -3.4449999999999996e+01
    rho_27    normalized_ratio_27_203  1
    rho_27    block_pair_pos_271  1
    rho_27    block_pair_neg_272  -1
    rho_27    block_pair_pos_281  1
    rho_27    block_pair_neg_282  -1
    rho_27    block_pair_pos_291  1
    rho_27    block_pair_neg_292  -1
    rho_27    block_pair_pos_297  -1
    rho_27    block_pair_neg_298  1
    rho_27    block_pair_pos_299  -1
    rho_27    block_pair_neg_300  1
    rho_27    block_pair_pos_309  1
    rho_27    block_pair_neg_310  -1
    rho_27    block_pair_pos_321  1
    rho_27    block_pair_neg_322  -1
    rho_27    normalization_323  1
    MARKER    'MARKER'                 'INTORG'
    x_6_0     OBJ       0.01875
    x_6_0     product_lb_204  -2.5353132922828682e-02
    x_6_0     product_ub_205  -4.2722001830985672e-02
    x_6_0     onehot_6_226  1
    x_6_0     parent_nonstrict_scope_266  0.0375
    x_6_0     unique_nonzero_owner_412  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_0     product_lb_204  1
    w_6_0     product_ub_205  1
    w_6_0     normalized_mass_6_227  1
    w_6_0     full_original_Gini_324  -2.3407142857142855e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_1     OBJ       0.01125
    x_6_1     product_lb_206  -2.5353132922828682e-02
    x_6_1     product_ub_207  -4.2722001830985672e-02
    x_6_1     onehot_6_226  1
    x_6_1     stock_lb_264  1
    x_6_1     stock_ub_265  1
    x_6_1     parent_nonstrict_scope_266  0.03
    MARKER    'MARKER'                 'INTEND'
    w_6_1     product_lb_206  1
    w_6_1     product_ub_207  1
    w_6_1     normalized_mass_6_227  1
    w_6_1     normalized_ratio_6_228  -0.2
    w_6_1     full_original_Gini_324  -1.8007142857142863e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_2     OBJ       0.00375
    x_6_2     product_lb_208  -2.5353132922828682e-02
    x_6_2     product_ub_209  -4.2722001830985672e-02
    x_6_2     onehot_6_226  1
    x_6_2     stock_lb_264  2
    x_6_2     stock_ub_265  2
    x_6_2     parent_nonstrict_scope_266  0.0225
    x_6_2     unique_nonzero_owner_413  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_2     product_lb_208  1
    w_6_2     product_ub_209  1
    w_6_2     normalized_mass_6_227  1
    w_6_2     normalized_ratio_6_228  -0.4
    w_6_2     full_original_Gini_324  -1.3607142857142854e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_3     OBJ       -3.7500000000000033e-03
    x_6_3     product_lb_210  -2.5353132922828682e-02
    x_6_3     product_ub_211  -4.2722001830985672e-02
    x_6_3     onehot_6_226  1
    x_6_3     stock_lb_264  3
    x_6_3     stock_ub_265  3
    x_6_3     parent_nonstrict_scope_266  1.4999999999999996e-02
    x_6_3     unique_nonzero_owner_414  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_3     product_lb_210  1
    w_6_3     product_ub_211  1
    w_6_3     normalized_mass_6_227  1
    w_6_3     normalized_ratio_6_228  -6.0000000000000009e-01
    w_6_3     full_original_Gini_324  -1.0007142857142856e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_4     OBJ       -1.1250000000000001e-02
    x_6_4     product_lb_212  -2.5353132922828682e-02
    x_6_4     product_ub_213  -4.2722001830985672e-02
    x_6_4     onehot_6_226  1
    x_6_4     stock_lb_264  4
    x_6_4     stock_ub_265  4
    x_6_4     parent_nonstrict_scope_266  7.4999999999999980e-03
    x_6_4     unique_nonzero_owner_415  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_4     product_lb_212  1
    w_6_4     product_ub_213  1
    w_6_4     normalized_mass_6_227  1
    w_6_4     normalized_ratio_6_228  -0.8
    w_6_4     full_original_Gini_324  -6.7071428571428582e+00
    MARKER    'MARKER'                 'INTORG'
    x_6_5     OBJ       -0.01875
    x_6_5     product_lb_214  -2.5353132922828682e-02
    x_6_5     product_ub_215  -4.2722001830985672e-02
    x_6_5     onehot_6_226  1
    x_6_5     stock_lb_264  5
    x_6_5     stock_ub_265  5
    x_6_5     unique_nonzero_owner_416  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_5     product_lb_214  1
    w_6_5     product_ub_215  1
    w_6_5     normalized_mass_6_227  1
    w_6_5     normalized_ratio_6_228  -1
    w_6_5     full_original_Gini_324  -4.8928571428571432e+00
    MARKER    'MARKER'                 'INTORG'
    x_6_6     OBJ       -1.1249999999999993e-02
    x_6_6     product_lb_216  -2.5353132922828682e-02
    x_6_6     product_ub_217  -4.2722001830985672e-02
    x_6_6     onehot_6_226  1
    x_6_6     stock_lb_264  6
    x_6_6     stock_ub_265  6
    x_6_6     parent_nonstrict_scope_266  7.5000000000000067e-03
    x_6_6     unique_nonzero_owner_417  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_6     product_lb_216  1
    w_6_6     product_ub_217  1
    w_6_6     normalized_mass_6_227  1
    w_6_6     normalized_ratio_6_228  -1.2000000000000002e+00
    w_6_6     full_original_Gini_324  -9.0928571428571487e+00
    MARKER    'MARKER'                 'INTORG'
    x_6_7     OBJ       -3.7499999999999947e-03
    x_6_7     product_lb_218  -2.5353132922828682e-02
    x_6_7     product_ub_219  -4.2722001830985672e-02
    x_6_7     onehot_6_226  1
    x_6_7     stock_lb_264  7
    x_6_7     stock_ub_265  7
    x_6_7     parent_nonstrict_scope_266  1.5000000000000005e-02
    x_6_7     unique_nonzero_owner_418  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_7     product_lb_218  1
    w_6_7     product_ub_219  1
    w_6_7     normalized_mass_6_227  1
    w_6_7     normalized_ratio_6_228  -1.4000000000000001e+00
    w_6_7     full_original_Gini_324  -1.4392857142857149e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_8     OBJ       3.7500000000000033e-03
    x_6_8     product_lb_220  -2.5353132922828682e-02
    x_6_8     product_ub_221  -4.2722001830985672e-02
    x_6_8     onehot_6_226  1
    x_6_8     stock_lb_264  8
    x_6_8     stock_ub_265  8
    x_6_8     parent_nonstrict_scope_266  2.2500000000000003e-02
    x_6_8     unique_nonzero_owner_419  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_8     product_lb_220  1
    w_6_8     product_ub_221  1
    w_6_8     normalized_mass_6_227  1
    w_6_8     normalized_ratio_6_228  -1.6
    w_6_8     full_original_Gini_324  -1.9792857142857141e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_9     OBJ       0.01125
    x_6_9     product_lb_222  -2.5353132922828682e-02
    x_6_9     product_ub_223  -4.2722001830985672e-02
    x_6_9     onehot_6_226  1
    x_6_9     stock_lb_264  9
    x_6_9     stock_ub_265  9
    x_6_9     parent_nonstrict_scope_266  0.03
    x_6_9     unique_nonzero_owner_420  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_9     product_lb_222  1
    w_6_9     product_ub_223  1
    w_6_9     normalized_mass_6_227  1
    w_6_9     normalized_ratio_6_228  -1.8
    w_6_9     full_original_Gini_324  -2.5192857142857154e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_10    OBJ       0.01875
    x_6_10    product_lb_224  -2.5353132922828682e-02
    x_6_10    product_ub_225  -4.2722001830985672e-02
    x_6_10    onehot_6_226  1
    x_6_10    stock_lb_264  10
    x_6_10    stock_ub_265  10
    x_6_10    parent_nonstrict_scope_266  0.0375
    x_6_10    unique_nonzero_owner_421  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_10    product_lb_224  1
    w_6_10    product_ub_225  1
    w_6_10    normalized_mass_6_227  1
    w_6_10    normalized_ratio_6_228  -2
    w_6_10    full_original_Gini_324  -3.0592857142857145e+01
    rho_6     normalized_ratio_6_228  1
    rho_6     block_pair_pos_267  1
    rho_6     block_pair_neg_268  -1
    rho_6     block_pair_pos_273  -1
    rho_6     block_pair_neg_274  1
    rho_6     block_pair_pos_277  1
    rho_6     block_pair_neg_278  -1
    rho_6     block_pair_pos_285  1
    rho_6     block_pair_neg_286  -1
    rho_6     block_pair_pos_297  1
    rho_6     block_pair_neg_298  -1
    rho_6     block_pair_pos_303  1
    rho_6     block_pair_neg_304  -1
    rho_6     block_pair_pos_315  1
    rho_6     block_pair_neg_316  -1
    rho_6     normalization_323  1
    MARKER    'MARKER'                 'INTORG'
    x_12_0    OBJ       0.0315
    x_12_0    product_lb_229  -2.5353132922828682e-02
    x_12_0    product_ub_230  -4.2722001830985672e-02
    x_12_0    onehot_12_261  1
    x_12_0    parent_nonstrict_scope_266  0.0735
    MARKER    'MARKER'                 'INTEND'
    w_12_0    product_lb_229  1
    w_12_0    product_ub_230  1
    w_12_0    normalized_mass_12_262  1
    w_12_0    full_original_Gini_324  -2.3407142857142855e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_1    OBJ       2.1000000000000005e-02
    x_12_1    product_lb_231  -2.5353132922828682e-02
    x_12_1    product_ub_232  -4.2722001830985672e-02
    x_12_1    onehot_12_261  1
    x_12_1    stock_lb_264  1
    x_12_1    stock_ub_265  1
    x_12_1    parent_nonstrict_scope_266  0.063
    x_12_1    unique_nonzero_owner_422  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_1    product_lb_231  1
    w_12_1    product_ub_232  1
    w_12_1    normalized_mass_12_262  1
    w_12_1    normalized_ratio_12_263  -1.4285714285714285e-01
    w_12_1    full_original_Gini_324  -1.9550000000000008e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_2    OBJ       1.0500000000000002e-02
    x_12_2    product_lb_233  -2.5353132922828682e-02
    x_12_2    product_ub_234  -4.2722001830985672e-02
    x_12_2    onehot_12_261  1
    x_12_2    stock_lb_264  2
    x_12_2    stock_ub_265  2
    x_12_2    parent_nonstrict_scope_266  0.0525
    x_12_2    unique_nonzero_owner_423  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_2    product_lb_233  1
    w_12_2    product_ub_234  1
    w_12_2    normalized_mass_12_262  1
    w_12_2    normalized_ratio_12_263  -2.8571428571428570e-01
    w_12_2    full_original_Gini_324  -1.6007142857142853e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_3    product_lb_235  -2.5353132922828682e-02
    x_12_3    product_ub_236  -4.2722001830985672e-02
    x_12_3    onehot_12_261  1
    x_12_3    stock_lb_264  3
    x_12_3    stock_ub_265  3
    x_12_3    parent_nonstrict_scope_266  4.1999999999999996e-02
    x_12_3    unique_nonzero_owner_424  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_3    product_lb_235  1
    w_12_3    product_ub_236  1
    w_12_3    normalized_mass_12_262  1
    w_12_3    normalized_ratio_12_263  -4.2857142857142855e-01
    w_12_3    full_original_Gini_324  -1.3064285714285711e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_4    OBJ       -1.0499999999999995e-02
    x_12_4    product_lb_237  -2.5353132922828682e-02
    x_12_4    product_ub_238  -4.2722001830985672e-02
    x_12_4    onehot_12_261  1
    x_12_4    stock_lb_264  4
    x_12_4    stock_ub_265  4
    x_12_4    parent_nonstrict_scope_266  0.0315
    x_12_4    unique_nonzero_owner_425  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_4    product_lb_237  1
    w_12_4    product_ub_238  1
    w_12_4    normalized_mass_12_262  1
    w_12_4    normalized_ratio_12_263  -5.7142857142857140e-01
    w_12_4    full_original_Gini_324  -1.0492857142857147e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_5    OBJ       -2.0999999999999991e-02
    x_12_5    product_lb_239  -2.5353132922828682e-02
    x_12_5    product_ub_240  -4.2722001830985672e-02
    x_12_5    onehot_12_261  1
    x_12_5    stock_lb_264  5
    x_12_5    stock_ub_265  5
    x_12_5    parent_nonstrict_scope_266  2.1000000000000005e-02
    x_12_5    unique_nonzero_owner_426  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_5    product_lb_239  1
    w_12_5    product_ub_240  1
    w_12_5    normalized_mass_12_262  1
    w_12_5    normalized_ratio_12_263  -7.1428571428571419e-01
    w_12_5    full_original_Gini_324  -8.0642857142857149e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_6    OBJ       -3.1499999999999993e-02
    x_12_6    product_lb_241  -2.5353132922828682e-02
    x_12_6    product_ub_242  -4.2722001830985672e-02
    x_12_6    onehot_12_261  1
    x_12_6    stock_lb_264  6
    x_12_6    stock_ub_265  6
    x_12_6    parent_nonstrict_scope_266  1.0500000000000002e-02
    x_12_6    unique_nonzero_owner_427  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_6    product_lb_241  1
    w_12_6    product_ub_242  1
    w_12_6    normalized_mass_12_262  1
    w_12_6    normalized_ratio_12_263  -8.5714285714285710e-01
    w_12_6    full_original_Gini_324  -5.9642857142857144e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_7    OBJ       -4.1999999999999996e-02
    x_12_7    product_lb_243  -2.5353132922828682e-02
    x_12_7    product_ub_244  -4.2722001830985672e-02
    x_12_7    onehot_12_261  1
    x_12_7    stock_lb_264  7
    x_12_7    stock_ub_265  7
    x_12_7    unique_nonzero_owner_428  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_7    product_lb_243  1
    w_12_7    product_ub_244  1
    w_12_7    normalized_mass_12_262  1
    w_12_7    normalized_ratio_12_263  -1
    w_12_7    full_original_Gini_324  -4.8928571428571432e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_8    OBJ       -0.0315
    x_12_8    product_lb_245  -2.5353132922828682e-02
    x_12_8    product_ub_246  -4.2722001830985672e-02
    x_12_8    onehot_12_261  1
    x_12_8    stock_lb_264  8
    x_12_8    stock_ub_265  8
    x_12_8    parent_nonstrict_scope_266  1.0499999999999995e-02
    x_12_8    unique_nonzero_owner_429  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_8    product_lb_245  1
    w_12_8    product_ub_246  1
    w_12_8    normalized_mass_12_262  1
    w_12_8    normalized_ratio_12_263  -1.1428571428571428e+00
    w_12_8    full_original_Gini_324  -7.8928571428571388e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_9    OBJ       -2.1000000000000005e-02
    x_12_9    product_lb_247  -2.5353132922828682e-02
    x_12_9    product_ub_248  -4.2722001830985672e-02
    x_12_9    onehot_12_261  1
    x_12_9    stock_lb_264  9
    x_12_9    stock_ub_265  9
    x_12_9    parent_nonstrict_scope_266  2.0999999999999991e-02
    x_12_9    unique_nonzero_owner_430  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_9    product_lb_247  1
    w_12_9    product_ub_248  1
    w_12_9    normalized_mass_12_262  1
    w_12_9    normalized_ratio_12_263  -1.2857142857142856e+00
    w_12_9    full_original_Gini_324  -1.1307142857142853e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_10   OBJ       -1.0500000000000009e-02
    x_12_10   product_lb_249  -2.5353132922828682e-02
    x_12_10   product_ub_250  -4.2722001830985672e-02
    x_12_10   onehot_12_261  1
    x_12_10   stock_lb_264  10
    x_12_10   stock_ub_265  10
    x_12_10   parent_nonstrict_scope_266  3.1499999999999986e-02
    x_12_10   unique_nonzero_owner_431  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_10   product_lb_249  1
    w_12_10   product_ub_250  1
    w_12_10   normalized_mass_12_262  1
    w_12_10   normalized_ratio_12_263  -1.4285714285714284e+00
    w_12_10   full_original_Gini_324  -1.5164285714285713e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_11   product_lb_251  -2.5353132922828682e-02
    x_12_11   product_ub_252  -4.2722001830985672e-02
    x_12_11   onehot_12_261  1
    x_12_11   stock_lb_264  11
    x_12_11   stock_ub_265  11
    x_12_11   parent_nonstrict_scope_266  4.1999999999999996e-02
    x_12_11   unique_nonzero_owner_432  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_11   product_lb_251  1
    w_12_11   product_ub_252  1
    w_12_11   normalized_mass_12_262  1
    w_12_11   normalized_ratio_12_263  -1.5714285714285714e+00
    w_12_11   full_original_Gini_324  -1.9021428571428569e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_12   OBJ       1.0499999999999995e-02
    x_12_12   product_lb_253  -2.5353132922828682e-02
    x_12_12   product_ub_254  -4.2722001830985672e-02
    x_12_12   onehot_12_261  1
    x_12_12   stock_lb_264  12
    x_12_12   stock_ub_265  12
    x_12_12   parent_nonstrict_scope_266  5.2499999999999991e-02
    x_12_12   unique_nonzero_owner_433  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_12   product_lb_253  1
    w_12_12   product_ub_254  1
    w_12_12   normalized_mass_12_262  1
    w_12_12   normalized_ratio_12_263  -1.7142857142857142e+00
    w_12_12   full_original_Gini_324  -2.2878571428571426e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_13   OBJ       2.0999999999999991e-02
    x_12_13   product_lb_255  -2.5353132922828682e-02
    x_12_13   product_ub_256  -4.2722001830985672e-02
    x_12_13   onehot_12_261  1
    x_12_13   stock_lb_264  13
    x_12_13   stock_ub_265  13
    x_12_13   parent_nonstrict_scope_266  6.2999999999999987e-02
    x_12_13   unique_nonzero_owner_434  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_13   product_lb_255  1
    w_12_13   product_ub_256  1
    w_12_13   normalized_mass_12_262  1
    w_12_13   normalized_ratio_12_263  -1.8571428571428570e+00
    w_12_13   full_original_Gini_324  -2.6735714285714291e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_14   OBJ       0.0315
    x_12_14   product_lb_257  -2.5353132922828682e-02
    x_12_14   product_ub_258  -4.2722001830985672e-02
    x_12_14   onehot_12_261  1
    x_12_14   stock_lb_264  14
    x_12_14   stock_ub_265  14
    x_12_14   parent_nonstrict_scope_266  0.0735
    x_12_14   unique_nonzero_owner_435  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_14   product_lb_257  1
    w_12_14   product_ub_258  1
    w_12_14   normalized_mass_12_262  1
    w_12_14   normalized_ratio_12_263  -2
    w_12_14   full_original_Gini_324  -3.0592857142857145e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_15   OBJ       4.1999999999999996e-02
    x_12_15   product_lb_259  -2.5353132922828682e-02
    x_12_15   product_ub_260  -4.2722001830985672e-02
    x_12_15   onehot_12_261  1
    x_12_15   stock_lb_264  15
    x_12_15   stock_ub_265  15
    x_12_15   parent_nonstrict_scope_266  8.3999999999999991e-02
    x_12_15   unique_nonzero_owner_436  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_15   product_lb_259  1
    w_12_15   product_ub_260  1
    w_12_15   normalized_mass_12_262  1
    w_12_15   normalized_ratio_12_263  -2.1428571428571428e+00
    w_12_15   full_original_Gini_324  -3.4449999999999996e+01
    rho_12    normalized_ratio_12_263  1
    rho_12    block_pair_pos_269  1
    rho_12    block_pair_neg_270  -1
    rho_12    block_pair_pos_273  1
    rho_12    block_pair_neg_274  -1
    rho_12    block_pair_pos_279  1
    rho_12    block_pair_neg_280  -1
    rho_12    block_pair_pos_287  1
    rho_12    block_pair_neg_288  -1
    rho_12    block_pair_pos_299  1
    rho_12    block_pair_neg_300  -1
    rho_12    block_pair_pos_305  1
    rho_12    block_pair_neg_306  -1
    rho_12    block_pair_pos_317  1
    rho_12    block_pair_neg_318  -1
    rho_12    normalization_323  1
    a_25_29   block_pair_pos_293  1
    a_25_29   block_pair_neg_294  1
    a_25_29   full_original_Gini_324  -1
    a_25_31   block_pair_pos_295  1
    a_25_31   block_pair_neg_296  1
    a_25_31   full_original_Gini_324  -1
    a_25_24   block_pair_pos_289  1
    a_25_24   block_pair_neg_290  1
    a_25_24   full_original_Gini_324  -1
    a_25_2    block_pair_pos_283  1
    a_25_2    block_pair_neg_284  1
    a_25_2    full_original_Gini_324  -1
    a_25_27   block_pair_pos_291  1
    a_25_27   block_pair_neg_292  1
    a_25_27   full_original_Gini_324  -1
    a_25_6    block_pair_pos_285  1
    a_25_6    block_pair_neg_286  1
    a_25_6    full_original_Gini_324  -1
    a_25_12   block_pair_pos_287  1
    a_25_12   block_pair_neg_288  1
    a_25_12   full_original_Gini_324  -1
    a_29_31   block_pair_pos_311  1
    a_29_31   block_pair_neg_312  1
    a_29_31   full_original_Gini_324  -1
    a_29_24   block_pair_pos_307  1
    a_29_24   block_pair_neg_308  1
    a_29_24   full_original_Gini_324  -1
    a_29_2    block_pair_pos_301  1
    a_29_2    block_pair_neg_302  1
    a_29_2    full_original_Gini_324  -1
    a_29_27   block_pair_pos_309  1
    a_29_27   block_pair_neg_310  1
    a_29_27   full_original_Gini_324  -1
    a_29_6    block_pair_pos_303  1
    a_29_6    block_pair_neg_304  1
    a_29_6    full_original_Gini_324  -1
    a_29_12   block_pair_pos_305  1
    a_29_12   block_pair_neg_306  1
    a_29_12   full_original_Gini_324  -1
    a_31_24   block_pair_pos_319  1
    a_31_24   block_pair_neg_320  1
    a_31_24   full_original_Gini_324  -1
    a_31_2    block_pair_pos_313  1
    a_31_2    block_pair_neg_314  1
    a_31_2    full_original_Gini_324  -1
    a_31_27   block_pair_pos_321  1
    a_31_27   block_pair_neg_322  1
    a_31_27   full_original_Gini_324  -1
    a_31_6    block_pair_pos_315  1
    a_31_6    block_pair_neg_316  1
    a_31_6    full_original_Gini_324  -1
    a_31_12   block_pair_pos_317  1
    a_31_12   block_pair_neg_318  1
    a_31_12   full_original_Gini_324  -1
    a_24_2    block_pair_pos_275  1
    a_24_2    block_pair_neg_276  1
    a_24_2    full_original_Gini_324  -1
    a_24_27   block_pair_pos_281  1
    a_24_27   block_pair_neg_282  1
    a_24_27   full_original_Gini_324  -1
    a_24_6    block_pair_pos_277  1
    a_24_6    block_pair_neg_278  1
    a_24_6    full_original_Gini_324  -1
    a_24_12   block_pair_pos_279  1
    a_24_12   block_pair_neg_280  1
    a_24_12   full_original_Gini_324  -1
    a_2_27    block_pair_pos_271  1
    a_2_27    block_pair_neg_272  1
    a_2_27    full_original_Gini_324  -1
    a_2_6     block_pair_pos_267  1
    a_2_6     block_pair_neg_268  1
    a_2_6     full_original_Gini_324  -1
    a_2_12    block_pair_pos_269  1
    a_2_12    block_pair_neg_270  1
    a_2_12    full_original_Gini_324  -1
    a_27_6    block_pair_pos_297  1
    a_27_6    block_pair_neg_298  1
    a_27_6    full_original_Gini_324  -1
    a_27_12   block_pair_pos_299  1
    a_27_12   block_pair_neg_300  1
    a_27_12   full_original_Gini_324  -1
    a_6_12    block_pair_pos_273  1
    a_6_12    block_pair_neg_274  1
    a_6_12    full_original_Gini_324  -1
    MARKER    'MARKER'                 'INTORG'
    service_0_25_0  unique_nonzero_owner_325  1
    service_0_25_0  service_visit_def_760  1
    service_0_25_0  free_load_conservation_761  -1
    service_0_25_0  original_T_including_depot_unload_807  120
    service_0_25_2  unique_nonzero_owner_326  1
    service_0_25_2  service_visit_def_760  1
    service_0_25_2  free_load_conservation_761  1
    service_0_25_3  unique_nonzero_owner_327  1
    service_0_25_3  service_visit_def_760  1
    service_0_25_3  free_load_conservation_761  2
    service_0_25_4  unique_nonzero_owner_328  1
    service_0_25_4  service_visit_def_760  1
    service_0_25_4  free_load_conservation_761  3
    service_0_25_5  unique_nonzero_owner_329  1
    service_0_25_5  service_visit_def_760  1
    service_0_25_5  free_load_conservation_761  4
    service_0_25_6  unique_nonzero_owner_330  1
    service_0_25_6  service_visit_def_760  1
    service_0_25_6  free_load_conservation_761  5
    service_0_25_7  unique_nonzero_owner_331  1
    service_0_25_7  service_visit_def_760  1
    service_0_25_7  free_load_conservation_761  6
    service_0_25_8  unique_nonzero_owner_332  1
    service_0_25_8  service_visit_def_760  1
    service_0_25_8  free_load_conservation_761  7
    service_0_25_9  unique_nonzero_owner_333  1
    service_0_25_9  service_visit_def_760  1
    service_0_25_9  free_load_conservation_761  8
    service_0_25_10  unique_nonzero_owner_334  1
    service_0_25_10  service_visit_def_760  1
    service_0_25_10  free_load_conservation_761  9
    service_0_25_11  unique_nonzero_owner_335  1
    service_0_25_11  service_visit_def_760  1
    service_0_25_11  free_load_conservation_761  10
    service_0_25_12  unique_nonzero_owner_336  1
    service_0_25_12  service_visit_def_760  1
    service_0_25_12  free_load_conservation_761  11
    service_0_25_13  unique_nonzero_owner_337  1
    service_0_25_13  service_visit_def_760  1
    service_0_25_13  free_load_conservation_761  12
    service_0_25_14  unique_nonzero_owner_338  1
    service_0_25_14  service_visit_def_760  1
    service_0_25_14  free_load_conservation_761  13
    service_0_25_15  unique_nonzero_owner_339  1
    service_0_25_15  service_visit_def_760  1
    service_0_25_15  free_load_conservation_761  14
    service_1_25_0  unique_nonzero_owner_325  1
    service_1_25_0  service_visit_def_1131  1
    service_1_25_0  free_load_conservation_1132  -1
    service_1_25_0  original_T_including_depot_unload_1178  120
    service_1_25_2  unique_nonzero_owner_326  1
    service_1_25_2  service_visit_def_1131  1
    service_1_25_2  free_load_conservation_1132  1
    service_1_25_3  unique_nonzero_owner_327  1
    service_1_25_3  service_visit_def_1131  1
    service_1_25_3  free_load_conservation_1132  2
    service_1_25_4  unique_nonzero_owner_328  1
    service_1_25_4  service_visit_def_1131  1
    service_1_25_4  free_load_conservation_1132  3
    service_1_25_5  unique_nonzero_owner_329  1
    service_1_25_5  service_visit_def_1131  1
    service_1_25_5  free_load_conservation_1132  4
    service_1_25_6  unique_nonzero_owner_330  1
    service_1_25_6  service_visit_def_1131  1
    service_1_25_6  free_load_conservation_1132  5
    service_1_25_7  unique_nonzero_owner_331  1
    service_1_25_7  service_visit_def_1131  1
    service_1_25_7  free_load_conservation_1132  6
    service_1_25_8  unique_nonzero_owner_332  1
    service_1_25_8  service_visit_def_1131  1
    service_1_25_8  free_load_conservation_1132  7
    service_1_25_9  unique_nonzero_owner_333  1
    service_1_25_9  service_visit_def_1131  1
    service_1_25_9  free_load_conservation_1132  8
    service_1_25_10  unique_nonzero_owner_334  1
    service_1_25_10  service_visit_def_1131  1
    service_1_25_10  free_load_conservation_1132  9
    service_1_25_11  unique_nonzero_owner_335  1
    service_1_25_11  service_visit_def_1131  1
    service_1_25_11  free_load_conservation_1132  10
    service_1_25_12  unique_nonzero_owner_336  1
    service_1_25_12  service_visit_def_1131  1
    service_1_25_12  free_load_conservation_1132  11
    service_1_25_13  unique_nonzero_owner_337  1
    service_1_25_13  service_visit_def_1131  1
    service_1_25_13  free_load_conservation_1132  12
    service_1_25_14  unique_nonzero_owner_338  1
    service_1_25_14  service_visit_def_1131  1
    service_1_25_14  free_load_conservation_1132  13
    service_1_25_15  unique_nonzero_owner_339  1
    service_1_25_15  service_visit_def_1131  1
    service_1_25_15  free_load_conservation_1132  14
    service_2_25_0  unique_nonzero_owner_325  1
    service_2_25_0  service_visit_def_1449  1
    service_2_25_0  free_load_conservation_1450  -1
    service_2_25_0  original_T_including_depot_unload_1495  120
    service_2_25_2  unique_nonzero_owner_326  1
    service_2_25_2  service_visit_def_1449  1
    service_2_25_2  free_load_conservation_1450  1
    service_2_25_3  unique_nonzero_owner_327  1
    service_2_25_3  service_visit_def_1449  1
    service_2_25_3  free_load_conservation_1450  2
    service_2_25_4  unique_nonzero_owner_328  1
    service_2_25_4  service_visit_def_1449  1
    service_2_25_4  free_load_conservation_1450  3
    service_2_25_5  unique_nonzero_owner_329  1
    service_2_25_5  service_visit_def_1449  1
    service_2_25_5  free_load_conservation_1450  4
    service_2_25_6  unique_nonzero_owner_330  1
    service_2_25_6  service_visit_def_1449  1
    service_2_25_6  free_load_conservation_1450  5
    service_2_25_7  unique_nonzero_owner_331  1
    service_2_25_7  service_visit_def_1449  1
    service_2_25_7  free_load_conservation_1450  6
    service_2_25_8  unique_nonzero_owner_332  1
    service_2_25_8  service_visit_def_1449  1
    service_2_25_8  free_load_conservation_1450  7
    service_2_25_9  unique_nonzero_owner_333  1
    service_2_25_9  service_visit_def_1449  1
    service_2_25_9  free_load_conservation_1450  8
    service_2_25_10  unique_nonzero_owner_334  1
    service_2_25_10  service_visit_def_1449  1
    service_2_25_10  free_load_conservation_1450  9
    service_2_25_11  unique_nonzero_owner_335  1
    service_2_25_11  service_visit_def_1449  1
    service_2_25_11  free_load_conservation_1450  10
    service_2_25_12  unique_nonzero_owner_336  1
    service_2_25_12  service_visit_def_1449  1
    service_2_25_12  free_load_conservation_1450  11
    service_2_25_13  unique_nonzero_owner_337  1
    service_2_25_13  service_visit_def_1449  1
    service_2_25_13  free_load_conservation_1450  12
    service_2_25_14  unique_nonzero_owner_338  1
    service_2_25_14  service_visit_def_1449  1
    service_2_25_14  free_load_conservation_1450  13
    service_2_25_15  unique_nonzero_owner_339  1
    service_2_25_15  service_visit_def_1449  1
    service_2_25_15  free_load_conservation_1450  14
    service_0_29_0  unique_nonzero_owner_340  1
    service_0_29_0  service_visit_def_766  1
    service_0_29_0  free_load_conservation_767  -11
    service_0_29_0  original_T_including_depot_unload_807  1320
    service_0_29_1  unique_nonzero_owner_341  1
    service_0_29_1  service_visit_def_766  1
    service_0_29_1  free_load_conservation_767  -10
    service_0_29_1  original_T_including_depot_unload_807  1200
    service_0_29_2  unique_nonzero_owner_342  1
    service_0_29_2  service_visit_def_766  1
    service_0_29_2  free_load_conservation_767  -9
    service_0_29_2  original_T_including_depot_unload_807  1080
    service_0_29_3  unique_nonzero_owner_343  1
    service_0_29_3  service_visit_def_766  1
    service_0_29_3  free_load_conservation_767  -8
    service_0_29_3  original_T_including_depot_unload_807  960
    service_0_29_4  unique_nonzero_owner_344  1
    service_0_29_4  service_visit_def_766  1
    service_0_29_4  free_load_conservation_767  -7
    service_0_29_4  original_T_including_depot_unload_807  840
    service_0_29_5  unique_nonzero_owner_345  1
    service_0_29_5  service_visit_def_766  1
    service_0_29_5  free_load_conservation_767  -6
    service_0_29_5  original_T_including_depot_unload_807  720
    service_0_29_6  unique_nonzero_owner_346  1
    service_0_29_6  service_visit_def_766  1
    service_0_29_6  free_load_conservation_767  -5
    service_0_29_6  original_T_including_depot_unload_807  600
    service_0_29_7  unique_nonzero_owner_347  1
    service_0_29_7  service_visit_def_766  1
    service_0_29_7  free_load_conservation_767  -4
    service_0_29_7  original_T_including_depot_unload_807  480
    service_0_29_8  unique_nonzero_owner_348  1
    service_0_29_8  service_visit_def_766  1
    service_0_29_8  free_load_conservation_767  -3
    service_0_29_8  original_T_including_depot_unload_807  360
    service_0_29_9  unique_nonzero_owner_349  1
    service_0_29_9  service_visit_def_766  1
    service_0_29_9  free_load_conservation_767  -2
    service_0_29_9  original_T_including_depot_unload_807  240
    service_0_29_10  unique_nonzero_owner_350  1
    service_0_29_10  service_visit_def_766  1
    service_0_29_10  free_load_conservation_767  -1
    service_0_29_10  original_T_including_depot_unload_807  120
    service_0_29_12  unique_nonzero_owner_351  1
    service_0_29_12  service_visit_def_766  1
    service_0_29_12  free_load_conservation_767  1
    service_0_29_13  unique_nonzero_owner_352  1
    service_0_29_13  service_visit_def_766  1
    service_0_29_13  free_load_conservation_767  2
    service_0_29_14  unique_nonzero_owner_353  1
    service_0_29_14  service_visit_def_766  1
    service_0_29_14  free_load_conservation_767  3
    service_0_29_15  unique_nonzero_owner_354  1
    service_0_29_15  service_visit_def_766  1
    service_0_29_15  free_load_conservation_767  4
    service_1_29_0  unique_nonzero_owner_340  1
    service_1_29_0  service_visit_def_1137  1
    service_1_29_0  free_load_conservation_1138  -11
    service_1_29_0  original_T_including_depot_unload_1178  1320
    service_1_29_1  unique_nonzero_owner_341  1
    service_1_29_1  service_visit_def_1137  1
    service_1_29_1  free_load_conservation_1138  -10
    service_1_29_1  original_T_including_depot_unload_1178  1200
    service_1_29_2  unique_nonzero_owner_342  1
    service_1_29_2  service_visit_def_1137  1
    service_1_29_2  free_load_conservation_1138  -9
    service_1_29_2  original_T_including_depot_unload_1178  1080
    service_1_29_3  unique_nonzero_owner_343  1
    service_1_29_3  service_visit_def_1137  1
    service_1_29_3  free_load_conservation_1138  -8
    service_1_29_3  original_T_including_depot_unload_1178  960
    service_1_29_4  unique_nonzero_owner_344  1
    service_1_29_4  service_visit_def_1137  1
    service_1_29_4  free_load_conservation_1138  -7
    service_1_29_4  original_T_including_depot_unload_1178  840
    service_1_29_5  unique_nonzero_owner_345  1
    service_1_29_5  service_visit_def_1137  1
    service_1_29_5  free_load_conservation_1138  -6
    service_1_29_5  original_T_including_depot_unload_1178  720
    service_1_29_6  unique_nonzero_owner_346  1
    service_1_29_6  service_visit_def_1137  1
    service_1_29_6  free_load_conservation_1138  -5
    service_1_29_6  original_T_including_depot_unload_1178  600
    service_1_29_7  unique_nonzero_owner_347  1
    service_1_29_7  service_visit_def_1137  1
    service_1_29_7  free_load_conservation_1138  -4
    service_1_29_7  original_T_including_depot_unload_1178  480
    service_1_29_8  unique_nonzero_owner_348  1
    service_1_29_8  service_visit_def_1137  1
    service_1_29_8  free_load_conservation_1138  -3
    service_1_29_8  original_T_including_depot_unload_1178  360
    service_1_29_9  unique_nonzero_owner_349  1
    service_1_29_9  service_visit_def_1137  1
    service_1_29_9  free_load_conservation_1138  -2
    service_1_29_9  original_T_including_depot_unload_1178  240
    service_1_29_10  unique_nonzero_owner_350  1
    service_1_29_10  service_visit_def_1137  1
    service_1_29_10  free_load_conservation_1138  -1
    service_1_29_10  original_T_including_depot_unload_1178  120
    service_1_29_12  unique_nonzero_owner_351  1
    service_1_29_12  service_visit_def_1137  1
    service_1_29_12  free_load_conservation_1138  1
    service_1_29_13  unique_nonzero_owner_352  1
    service_1_29_13  service_visit_def_1137  1
    service_1_29_13  free_load_conservation_1138  2
    service_1_29_14  unique_nonzero_owner_353  1
    service_1_29_14  service_visit_def_1137  1
    service_1_29_14  free_load_conservation_1138  3
    service_1_29_15  unique_nonzero_owner_354  1
    service_1_29_15  service_visit_def_1137  1
    service_1_29_15  free_load_conservation_1138  4
    service_2_29_0  unique_nonzero_owner_340  1
    service_2_29_0  service_visit_def_1455  1
    service_2_29_0  free_load_conservation_1456  -11
    service_2_29_0  original_T_including_depot_unload_1495  1320
    service_2_29_1  unique_nonzero_owner_341  1
    service_2_29_1  service_visit_def_1455  1
    service_2_29_1  free_load_conservation_1456  -10
    service_2_29_1  original_T_including_depot_unload_1495  1200
    service_2_29_2  unique_nonzero_owner_342  1
    service_2_29_2  service_visit_def_1455  1
    service_2_29_2  free_load_conservation_1456  -9
    service_2_29_2  original_T_including_depot_unload_1495  1080
    service_2_29_3  unique_nonzero_owner_343  1
    service_2_29_3  service_visit_def_1455  1
    service_2_29_3  free_load_conservation_1456  -8
    service_2_29_3  original_T_including_depot_unload_1495  960
    service_2_29_4  unique_nonzero_owner_344  1
    service_2_29_4  service_visit_def_1455  1
    service_2_29_4  free_load_conservation_1456  -7
    service_2_29_4  original_T_including_depot_unload_1495  840
    service_2_29_5  unique_nonzero_owner_345  1
    service_2_29_5  service_visit_def_1455  1
    service_2_29_5  free_load_conservation_1456  -6
    service_2_29_5  original_T_including_depot_unload_1495  720
    service_2_29_6  unique_nonzero_owner_346  1
    service_2_29_6  service_visit_def_1455  1
    service_2_29_6  free_load_conservation_1456  -5
    service_2_29_6  original_T_including_depot_unload_1495  600
    service_2_29_7  unique_nonzero_owner_347  1
    service_2_29_7  service_visit_def_1455  1
    service_2_29_7  free_load_conservation_1456  -4
    service_2_29_7  original_T_including_depot_unload_1495  480
    service_2_29_8  unique_nonzero_owner_348  1
    service_2_29_8  service_visit_def_1455  1
    service_2_29_8  free_load_conservation_1456  -3
    service_2_29_8  original_T_including_depot_unload_1495  360
    service_2_29_9  unique_nonzero_owner_349  1
    service_2_29_9  service_visit_def_1455  1
    service_2_29_9  free_load_conservation_1456  -2
    service_2_29_9  original_T_including_depot_unload_1495  240
    service_2_29_10  unique_nonzero_owner_350  1
    service_2_29_10  service_visit_def_1455  1
    service_2_29_10  free_load_conservation_1456  -1
    service_2_29_10  original_T_including_depot_unload_1495  120
    service_2_29_12  unique_nonzero_owner_351  1
    service_2_29_12  service_visit_def_1455  1
    service_2_29_12  free_load_conservation_1456  1
    service_2_29_13  unique_nonzero_owner_352  1
    service_2_29_13  service_visit_def_1455  1
    service_2_29_13  free_load_conservation_1456  2
    service_2_29_14  unique_nonzero_owner_353  1
    service_2_29_14  service_visit_def_1455  1
    service_2_29_14  free_load_conservation_1456  3
    service_2_29_15  unique_nonzero_owner_354  1
    service_2_29_15  service_visit_def_1455  1
    service_2_29_15  free_load_conservation_1456  4
    service_0_31_0  unique_nonzero_owner_355  1
    service_0_31_0  service_visit_def_772  1
    service_0_31_0  free_load_conservation_773  -2
    service_0_31_0  original_T_including_depot_unload_807  240
    service_0_31_1  unique_nonzero_owner_356  1
    service_0_31_1  service_visit_def_772  1
    service_0_31_1  free_load_conservation_773  -1
    service_0_31_1  original_T_including_depot_unload_807  120
    service_0_31_3  unique_nonzero_owner_357  1
    service_0_31_3  service_visit_def_772  1
    service_0_31_3  free_load_conservation_773  1
    service_0_31_4  unique_nonzero_owner_358  1
    service_0_31_4  service_visit_def_772  1
    service_0_31_4  free_load_conservation_773  2
    service_0_31_5  unique_nonzero_owner_359  1
    service_0_31_5  service_visit_def_772  1
    service_0_31_5  free_load_conservation_773  3
    service_0_31_6  unique_nonzero_owner_360  1
    service_0_31_6  service_visit_def_772  1
    service_0_31_6  free_load_conservation_773  4
    service_0_31_7  unique_nonzero_owner_361  1
    service_0_31_7  service_visit_def_772  1
    service_0_31_7  free_load_conservation_773  5
    service_0_31_8  unique_nonzero_owner_362  1
    service_0_31_8  service_visit_def_772  1
    service_0_31_8  free_load_conservation_773  6
    service_0_31_9  unique_nonzero_owner_363  1
    service_0_31_9  service_visit_def_772  1
    service_0_31_9  free_load_conservation_773  7
    service_0_31_10  unique_nonzero_owner_364  1
    service_0_31_10  service_visit_def_772  1
    service_0_31_10  free_load_conservation_773  8
    service_0_31_11  unique_nonzero_owner_365  1
    service_0_31_11  service_visit_def_772  1
    service_0_31_11  free_load_conservation_773  9
    service_0_31_12  unique_nonzero_owner_366  1
    service_0_31_12  service_visit_def_772  1
    service_0_31_12  free_load_conservation_773  10
    service_1_31_0  unique_nonzero_owner_355  1
    service_1_31_0  service_visit_def_1143  1
    service_1_31_0  free_load_conservation_1144  -2
    service_1_31_0  original_T_including_depot_unload_1178  240
    service_1_31_1  unique_nonzero_owner_356  1
    service_1_31_1  service_visit_def_1143  1
    service_1_31_1  free_load_conservation_1144  -1
    service_1_31_1  original_T_including_depot_unload_1178  120
    service_1_31_3  unique_nonzero_owner_357  1
    service_1_31_3  service_visit_def_1143  1
    service_1_31_3  free_load_conservation_1144  1
    service_1_31_4  unique_nonzero_owner_358  1
    service_1_31_4  service_visit_def_1143  1
    service_1_31_4  free_load_conservation_1144  2
    service_1_31_5  unique_nonzero_owner_359  1
    service_1_31_5  service_visit_def_1143  1
    service_1_31_5  free_load_conservation_1144  3
    service_1_31_6  unique_nonzero_owner_360  1
    service_1_31_6  service_visit_def_1143  1
    service_1_31_6  free_load_conservation_1144  4
    service_1_31_7  unique_nonzero_owner_361  1
    service_1_31_7  service_visit_def_1143  1
    service_1_31_7  free_load_conservation_1144  5
    service_1_31_8  unique_nonzero_owner_362  1
    service_1_31_8  service_visit_def_1143  1
    service_1_31_8  free_load_conservation_1144  6
    service_1_31_9  unique_nonzero_owner_363  1
    service_1_31_9  service_visit_def_1143  1
    service_1_31_9  free_load_conservation_1144  7
    service_1_31_10  unique_nonzero_owner_364  1
    service_1_31_10  service_visit_def_1143  1
    service_1_31_10  free_load_conservation_1144  8
    service_1_31_11  unique_nonzero_owner_365  1
    service_1_31_11  service_visit_def_1143  1
    service_1_31_11  free_load_conservation_1144  9
    service_1_31_12  unique_nonzero_owner_366  1
    service_1_31_12  service_visit_def_1143  1
    service_1_31_12  free_load_conservation_1144  10
    service_2_31_0  unique_nonzero_owner_355  1
    service_2_31_0  service_visit_def_1461  1
    service_2_31_0  free_load_conservation_1462  -2
    service_2_31_0  original_T_including_depot_unload_1495  240
    service_2_31_1  unique_nonzero_owner_356  1
    service_2_31_1  service_visit_def_1461  1
    service_2_31_1  free_load_conservation_1462  -1
    service_2_31_1  original_T_including_depot_unload_1495  120
    service_2_31_3  unique_nonzero_owner_357  1
    service_2_31_3  service_visit_def_1461  1
    service_2_31_3  free_load_conservation_1462  1
    service_2_31_4  unique_nonzero_owner_358  1
    service_2_31_4  service_visit_def_1461  1
    service_2_31_4  free_load_conservation_1462  2
    service_2_31_5  unique_nonzero_owner_359  1
    service_2_31_5  service_visit_def_1461  1
    service_2_31_5  free_load_conservation_1462  3
    service_2_31_6  unique_nonzero_owner_360  1
    service_2_31_6  service_visit_def_1461  1
    service_2_31_6  free_load_conservation_1462  4
    service_2_31_7  unique_nonzero_owner_361  1
    service_2_31_7  service_visit_def_1461  1
    service_2_31_7  free_load_conservation_1462  5
    service_2_31_8  unique_nonzero_owner_362  1
    service_2_31_8  service_visit_def_1461  1
    service_2_31_8  free_load_conservation_1462  6
    service_2_31_9  unique_nonzero_owner_363  1
    service_2_31_9  service_visit_def_1461  1
    service_2_31_9  free_load_conservation_1462  7
    service_2_31_10  unique_nonzero_owner_364  1
    service_2_31_10  service_visit_def_1461  1
    service_2_31_10  free_load_conservation_1462  8
    service_2_31_11  unique_nonzero_owner_365  1
    service_2_31_11  service_visit_def_1461  1
    service_2_31_11  free_load_conservation_1462  9
    service_2_31_12  unique_nonzero_owner_366  1
    service_2_31_12  service_visit_def_1461  1
    service_2_31_12  free_load_conservation_1462  10
    service_0_24_0  unique_nonzero_owner_367  1
    service_0_24_0  service_visit_def_778  1
    service_0_24_0  free_load_conservation_779  -11
    service_0_24_0  original_T_including_depot_unload_807  1320
    service_0_24_1  unique_nonzero_owner_368  1
    service_0_24_1  service_visit_def_778  1
    service_0_24_1  free_load_conservation_779  -10
    service_0_24_1  original_T_including_depot_unload_807  1200
    service_0_24_2  unique_nonzero_owner_369  1
    service_0_24_2  service_visit_def_778  1
    service_0_24_2  free_load_conservation_779  -9
    service_0_24_2  original_T_including_depot_unload_807  1080
    service_0_24_3  unique_nonzero_owner_370  1
    service_0_24_3  service_visit_def_778  1
    service_0_24_3  free_load_conservation_779  -8
    service_0_24_3  original_T_including_depot_unload_807  960
    service_0_24_4  unique_nonzero_owner_371  1
    service_0_24_4  service_visit_def_778  1
    service_0_24_4  free_load_conservation_779  -7
    service_0_24_4  original_T_including_depot_unload_807  840
    service_0_24_5  unique_nonzero_owner_372  1
    service_0_24_5  service_visit_def_778  1
    service_0_24_5  free_load_conservation_779  -6
    service_0_24_5  original_T_including_depot_unload_807  720
    service_0_24_6  unique_nonzero_owner_373  1
    service_0_24_6  service_visit_def_778  1
    service_0_24_6  free_load_conservation_779  -5
    service_0_24_6  original_T_including_depot_unload_807  600
    service_0_24_7  unique_nonzero_owner_374  1
    service_0_24_7  service_visit_def_778  1
    service_0_24_7  free_load_conservation_779  -4
    service_0_24_7  original_T_including_depot_unload_807  480
    service_0_24_8  unique_nonzero_owner_375  1
    service_0_24_8  service_visit_def_778  1
    service_0_24_8  free_load_conservation_779  -3
    service_0_24_8  original_T_including_depot_unload_807  360
    service_0_24_9  unique_nonzero_owner_376  1
    service_0_24_9  service_visit_def_778  1
    service_0_24_9  free_load_conservation_779  -2
    service_0_24_9  original_T_including_depot_unload_807  240
    service_0_24_10  unique_nonzero_owner_377  1
    service_0_24_10  service_visit_def_778  1
    service_0_24_10  free_load_conservation_779  -1
    service_0_24_10  original_T_including_depot_unload_807  120
    service_0_24_12  unique_nonzero_owner_378  1
    service_0_24_12  service_visit_def_778  1
    service_0_24_12  free_load_conservation_779  1
    service_0_24_13  unique_nonzero_owner_379  1
    service_0_24_13  service_visit_def_778  1
    service_0_24_13  free_load_conservation_779  2
    service_0_24_14  unique_nonzero_owner_380  1
    service_0_24_14  service_visit_def_778  1
    service_0_24_14  free_load_conservation_779  3
    service_0_24_15  unique_nonzero_owner_381  1
    service_0_24_15  service_visit_def_778  1
    service_0_24_15  free_load_conservation_779  4
    service_1_24_0  unique_nonzero_owner_367  1
    service_1_24_0  service_visit_def_1149  1
    service_1_24_0  free_load_conservation_1150  -11
    service_1_24_0  original_T_including_depot_unload_1178  1320
    service_1_24_1  unique_nonzero_owner_368  1
    service_1_24_1  service_visit_def_1149  1
    service_1_24_1  free_load_conservation_1150  -10
    service_1_24_1  original_T_including_depot_unload_1178  1200
    service_1_24_2  unique_nonzero_owner_369  1
    service_1_24_2  service_visit_def_1149  1
    service_1_24_2  free_load_conservation_1150  -9
    service_1_24_2  original_T_including_depot_unload_1178  1080
    service_1_24_3  unique_nonzero_owner_370  1
    service_1_24_3  service_visit_def_1149  1
    service_1_24_3  free_load_conservation_1150  -8
    service_1_24_3  original_T_including_depot_unload_1178  960
    service_1_24_4  unique_nonzero_owner_371  1
    service_1_24_4  service_visit_def_1149  1
    service_1_24_4  free_load_conservation_1150  -7
    service_1_24_4  original_T_including_depot_unload_1178  840
    service_1_24_5  unique_nonzero_owner_372  1
    service_1_24_5  service_visit_def_1149  1
    service_1_24_5  free_load_conservation_1150  -6
    service_1_24_5  original_T_including_depot_unload_1178  720
    service_1_24_6  unique_nonzero_owner_373  1
    service_1_24_6  service_visit_def_1149  1
    service_1_24_6  free_load_conservation_1150  -5
    service_1_24_6  original_T_including_depot_unload_1178  600
    service_1_24_7  unique_nonzero_owner_374  1
    service_1_24_7  service_visit_def_1149  1
    service_1_24_7  free_load_conservation_1150  -4
    service_1_24_7  original_T_including_depot_unload_1178  480
    service_1_24_8  unique_nonzero_owner_375  1
    service_1_24_8  service_visit_def_1149  1
    service_1_24_8  free_load_conservation_1150  -3
    service_1_24_8  original_T_including_depot_unload_1178  360
    service_1_24_9  unique_nonzero_owner_376  1
    service_1_24_9  service_visit_def_1149  1
    service_1_24_9  free_load_conservation_1150  -2
    service_1_24_9  original_T_including_depot_unload_1178  240
    service_1_24_10  unique_nonzero_owner_377  1
    service_1_24_10  service_visit_def_1149  1
    service_1_24_10  free_load_conservation_1150  -1
    service_1_24_10  original_T_including_depot_unload_1178  120
    service_1_24_12  unique_nonzero_owner_378  1
    service_1_24_12  service_visit_def_1149  1
    service_1_24_12  free_load_conservation_1150  1
    service_1_24_13  unique_nonzero_owner_379  1
    service_1_24_13  service_visit_def_1149  1
    service_1_24_13  free_load_conservation_1150  2
    service_1_24_14  unique_nonzero_owner_380  1
    service_1_24_14  service_visit_def_1149  1
    service_1_24_14  free_load_conservation_1150  3
    service_1_24_15  unique_nonzero_owner_381  1
    service_1_24_15  service_visit_def_1149  1
    service_1_24_15  free_load_conservation_1150  4
    service_2_24_0  unique_nonzero_owner_367  1
    service_2_24_0  service_visit_def_1467  1
    service_2_24_0  free_load_conservation_1468  -11
    service_2_24_0  original_T_including_depot_unload_1495  1320
    service_2_24_1  unique_nonzero_owner_368  1
    service_2_24_1  service_visit_def_1467  1
    service_2_24_1  free_load_conservation_1468  -10
    service_2_24_1  original_T_including_depot_unload_1495  1200
    service_2_24_2  unique_nonzero_owner_369  1
    service_2_24_2  service_visit_def_1467  1
    service_2_24_2  free_load_conservation_1468  -9
    service_2_24_2  original_T_including_depot_unload_1495  1080
    service_2_24_3  unique_nonzero_owner_370  1
    service_2_24_3  service_visit_def_1467  1
    service_2_24_3  free_load_conservation_1468  -8
    service_2_24_3  original_T_including_depot_unload_1495  960
    service_2_24_4  unique_nonzero_owner_371  1
    service_2_24_4  service_visit_def_1467  1
    service_2_24_4  free_load_conservation_1468  -7
    service_2_24_4  original_T_including_depot_unload_1495  840
    service_2_24_5  unique_nonzero_owner_372  1
    service_2_24_5  service_visit_def_1467  1
    service_2_24_5  free_load_conservation_1468  -6
    service_2_24_5  original_T_including_depot_unload_1495  720
    service_2_24_6  unique_nonzero_owner_373  1
    service_2_24_6  service_visit_def_1467  1
    service_2_24_6  free_load_conservation_1468  -5
    service_2_24_6  original_T_including_depot_unload_1495  600
    service_2_24_7  unique_nonzero_owner_374  1
    service_2_24_7  service_visit_def_1467  1
    service_2_24_7  free_load_conservation_1468  -4
    service_2_24_7  original_T_including_depot_unload_1495  480
    service_2_24_8  unique_nonzero_owner_375  1
    service_2_24_8  service_visit_def_1467  1
    service_2_24_8  free_load_conservation_1468  -3
    service_2_24_8  original_T_including_depot_unload_1495  360
    service_2_24_9  unique_nonzero_owner_376  1
    service_2_24_9  service_visit_def_1467  1
    service_2_24_9  free_load_conservation_1468  -2
    service_2_24_9  original_T_including_depot_unload_1495  240
    service_2_24_10  unique_nonzero_owner_377  1
    service_2_24_10  service_visit_def_1467  1
    service_2_24_10  free_load_conservation_1468  -1
    service_2_24_10  original_T_including_depot_unload_1495  120
    service_2_24_12  unique_nonzero_owner_378  1
    service_2_24_12  service_visit_def_1467  1
    service_2_24_12  free_load_conservation_1468  1
    service_2_24_13  unique_nonzero_owner_379  1
    service_2_24_13  service_visit_def_1467  1
    service_2_24_13  free_load_conservation_1468  2
    service_2_24_14  unique_nonzero_owner_380  1
    service_2_24_14  service_visit_def_1467  1
    service_2_24_14  free_load_conservation_1468  3
    service_2_24_15  unique_nonzero_owner_381  1
    service_2_24_15  service_visit_def_1467  1
    service_2_24_15  free_load_conservation_1468  4
    service_0_2_1  unique_nonzero_owner_382  1
    service_0_2_1  service_visit_def_784  1
    service_0_2_1  free_load_conservation_785  1
    service_0_2_2  unique_nonzero_owner_383  1
    service_0_2_2  service_visit_def_784  1
    service_0_2_2  free_load_conservation_785  2
    service_0_2_3  unique_nonzero_owner_384  1
    service_0_2_3  service_visit_def_784  1
    service_0_2_3  free_load_conservation_785  3
    service_0_2_4  unique_nonzero_owner_385  1
    service_0_2_4  service_visit_def_784  1
    service_0_2_4  free_load_conservation_785  4
    service_0_2_5  unique_nonzero_owner_386  1
    service_0_2_5  service_visit_def_784  1
    service_0_2_5  free_load_conservation_785  5
    service_0_2_6  unique_nonzero_owner_387  1
    service_0_2_6  service_visit_def_784  1
    service_0_2_6  free_load_conservation_785  6
    service_0_2_7  unique_nonzero_owner_388  1
    service_0_2_7  service_visit_def_784  1
    service_0_2_7  free_load_conservation_785  7
    service_0_2_8  unique_nonzero_owner_389  1
    service_0_2_8  service_visit_def_784  1
    service_0_2_8  free_load_conservation_785  8
    service_0_2_9  unique_nonzero_owner_390  1
    service_0_2_9  service_visit_def_784  1
    service_0_2_9  free_load_conservation_785  9
    service_0_2_10  unique_nonzero_owner_391  1
    service_0_2_10  service_visit_def_784  1
    service_0_2_10  free_load_conservation_785  10
    service_0_2_11  unique_nonzero_owner_392  1
    service_0_2_11  service_visit_def_784  1
    service_0_2_11  free_load_conservation_785  11
    service_0_2_12  unique_nonzero_owner_393  1
    service_0_2_12  service_visit_def_784  1
    service_0_2_12  free_load_conservation_785  12
    service_0_2_13  unique_nonzero_owner_394  1
    service_0_2_13  service_visit_def_784  1
    service_0_2_13  free_load_conservation_785  13
    service_0_2_14  unique_nonzero_owner_395  1
    service_0_2_14  service_visit_def_784  1
    service_0_2_14  free_load_conservation_785  14
    service_0_2_15  unique_nonzero_owner_396  1
    service_0_2_15  service_visit_def_784  1
    service_0_2_15  free_load_conservation_785  15
    service_1_2_1  unique_nonzero_owner_382  1
    service_1_2_1  service_visit_def_1155  1
    service_1_2_1  free_load_conservation_1156  1
    service_1_2_2  unique_nonzero_owner_383  1
    service_1_2_2  service_visit_def_1155  1
    service_1_2_2  free_load_conservation_1156  2
    service_1_2_3  unique_nonzero_owner_384  1
    service_1_2_3  service_visit_def_1155  1
    service_1_2_3  free_load_conservation_1156  3
    service_1_2_4  unique_nonzero_owner_385  1
    service_1_2_4  service_visit_def_1155  1
    service_1_2_4  free_load_conservation_1156  4
    service_1_2_5  unique_nonzero_owner_386  1
    service_1_2_5  service_visit_def_1155  1
    service_1_2_5  free_load_conservation_1156  5
    service_1_2_6  unique_nonzero_owner_387  1
    service_1_2_6  service_visit_def_1155  1
    service_1_2_6  free_load_conservation_1156  6
    service_1_2_7  unique_nonzero_owner_388  1
    service_1_2_7  service_visit_def_1155  1
    service_1_2_7  free_load_conservation_1156  7
    service_1_2_8  unique_nonzero_owner_389  1
    service_1_2_8  service_visit_def_1155  1
    service_1_2_8  free_load_conservation_1156  8
    service_1_2_9  unique_nonzero_owner_390  1
    service_1_2_9  service_visit_def_1155  1
    service_1_2_9  free_load_conservation_1156  9
    service_1_2_10  unique_nonzero_owner_391  1
    service_1_2_10  service_visit_def_1155  1
    service_1_2_10  free_load_conservation_1156  10
    service_1_2_11  unique_nonzero_owner_392  1
    service_1_2_11  service_visit_def_1155  1
    service_1_2_11  free_load_conservation_1156  11
    service_1_2_12  unique_nonzero_owner_393  1
    service_1_2_12  service_visit_def_1155  1
    service_1_2_12  free_load_conservation_1156  12
    service_1_2_13  unique_nonzero_owner_394  1
    service_1_2_13  service_visit_def_1155  1
    service_1_2_13  free_load_conservation_1156  13
    service_1_2_14  unique_nonzero_owner_395  1
    service_1_2_14  service_visit_def_1155  1
    service_1_2_14  free_load_conservation_1156  14
    service_1_2_15  unique_nonzero_owner_396  1
    service_1_2_15  service_visit_def_1155  1
    service_1_2_15  free_load_conservation_1156  15
    service_2_2_1  unique_nonzero_owner_382  1
    service_2_2_1  service_visit_def_1473  1
    service_2_2_1  free_load_conservation_1474  1
    service_2_2_2  unique_nonzero_owner_383  1
    service_2_2_2  service_visit_def_1473  1
    service_2_2_2  free_load_conservation_1474  2
    service_2_2_3  unique_nonzero_owner_384  1
    service_2_2_3  service_visit_def_1473  1
    service_2_2_3  free_load_conservation_1474  3
    service_2_2_4  unique_nonzero_owner_385  1
    service_2_2_4  service_visit_def_1473  1
    service_2_2_4  free_load_conservation_1474  4
    service_2_2_5  unique_nonzero_owner_386  1
    service_2_2_5  service_visit_def_1473  1
    service_2_2_5  free_load_conservation_1474  5
    service_2_2_6  unique_nonzero_owner_387  1
    service_2_2_6  service_visit_def_1473  1
    service_2_2_6  free_load_conservation_1474  6
    service_2_2_7  unique_nonzero_owner_388  1
    service_2_2_7  service_visit_def_1473  1
    service_2_2_7  free_load_conservation_1474  7
    service_2_2_8  unique_nonzero_owner_389  1
    service_2_2_8  service_visit_def_1473  1
    service_2_2_8  free_load_conservation_1474  8
    service_2_2_9  unique_nonzero_owner_390  1
    service_2_2_9  service_visit_def_1473  1
    service_2_2_9  free_load_conservation_1474  9
    service_2_2_10  unique_nonzero_owner_391  1
    service_2_2_10  service_visit_def_1473  1
    service_2_2_10  free_load_conservation_1474  10
    service_2_2_11  unique_nonzero_owner_392  1
    service_2_2_11  service_visit_def_1473  1
    service_2_2_11  free_load_conservation_1474  11
    service_2_2_12  unique_nonzero_owner_393  1
    service_2_2_12  service_visit_def_1473  1
    service_2_2_12  free_load_conservation_1474  12
    service_2_2_13  unique_nonzero_owner_394  1
    service_2_2_13  service_visit_def_1473  1
    service_2_2_13  free_load_conservation_1474  13
    service_2_2_14  unique_nonzero_owner_395  1
    service_2_2_14  service_visit_def_1473  1
    service_2_2_14  free_load_conservation_1474  14
    service_2_2_15  unique_nonzero_owner_396  1
    service_2_2_15  service_visit_def_1473  1
    service_2_2_15  free_load_conservation_1474  15
    service_0_27_0  unique_nonzero_owner_397  1
    service_0_27_0  service_visit_def_790  1
    service_0_27_0  free_load_conservation_791  -11
    service_0_27_0  original_T_including_depot_unload_807  1320
    service_0_27_1  unique_nonzero_owner_398  1
    service_0_27_1  service_visit_def_790  1
    service_0_27_1  free_load_conservation_791  -10
    service_0_27_1  original_T_including_depot_unload_807  1200
    service_0_27_2  unique_nonzero_owner_399  1
    service_0_27_2  service_visit_def_790  1
    service_0_27_2  free_load_conservation_791  -9
    service_0_27_2  original_T_including_depot_unload_807  1080
    service_0_27_3  unique_nonzero_owner_400  1
    service_0_27_3  service_visit_def_790  1
    service_0_27_3  free_load_conservation_791  -8
    service_0_27_3  original_T_including_depot_unload_807  960
    service_0_27_4  unique_nonzero_owner_401  1
    service_0_27_4  service_visit_def_790  1
    service_0_27_4  free_load_conservation_791  -7
    service_0_27_4  original_T_including_depot_unload_807  840
    service_0_27_5  unique_nonzero_owner_402  1
    service_0_27_5  service_visit_def_790  1
    service_0_27_5  free_load_conservation_791  -6
    service_0_27_5  original_T_including_depot_unload_807  720
    service_0_27_6  unique_nonzero_owner_403  1
    service_0_27_6  service_visit_def_790  1
    service_0_27_6  free_load_conservation_791  -5
    service_0_27_6  original_T_including_depot_unload_807  600
    service_0_27_7  unique_nonzero_owner_404  1
    service_0_27_7  service_visit_def_790  1
    service_0_27_7  free_load_conservation_791  -4
    service_0_27_7  original_T_including_depot_unload_807  480
    service_0_27_8  unique_nonzero_owner_405  1
    service_0_27_8  service_visit_def_790  1
    service_0_27_8  free_load_conservation_791  -3
    service_0_27_8  original_T_including_depot_unload_807  360
    service_0_27_9  unique_nonzero_owner_406  1
    service_0_27_9  service_visit_def_790  1
    service_0_27_9  free_load_conservation_791  -2
    service_0_27_9  original_T_including_depot_unload_807  240
    service_0_27_10  unique_nonzero_owner_407  1
    service_0_27_10  service_visit_def_790  1
    service_0_27_10  free_load_conservation_791  -1
    service_0_27_10  original_T_including_depot_unload_807  120
    service_0_27_12  unique_nonzero_owner_408  1
    service_0_27_12  service_visit_def_790  1
    service_0_27_12  free_load_conservation_791  1
    service_0_27_13  unique_nonzero_owner_409  1
    service_0_27_13  service_visit_def_790  1
    service_0_27_13  free_load_conservation_791  2
    service_0_27_14  unique_nonzero_owner_410  1
    service_0_27_14  service_visit_def_790  1
    service_0_27_14  free_load_conservation_791  3
    service_0_27_15  unique_nonzero_owner_411  1
    service_0_27_15  service_visit_def_790  1
    service_0_27_15  free_load_conservation_791  4
    service_1_27_0  unique_nonzero_owner_397  1
    service_1_27_0  service_visit_def_1161  1
    service_1_27_0  free_load_conservation_1162  -11
    service_1_27_0  original_T_including_depot_unload_1178  1320
    service_1_27_1  unique_nonzero_owner_398  1
    service_1_27_1  service_visit_def_1161  1
    service_1_27_1  free_load_conservation_1162  -10
    service_1_27_1  original_T_including_depot_unload_1178  1200
    service_1_27_2  unique_nonzero_owner_399  1
    service_1_27_2  service_visit_def_1161  1
    service_1_27_2  free_load_conservation_1162  -9
    service_1_27_2  original_T_including_depot_unload_1178  1080
    service_1_27_3  unique_nonzero_owner_400  1
    service_1_27_3  service_visit_def_1161  1
    service_1_27_3  free_load_conservation_1162  -8
    service_1_27_3  original_T_including_depot_unload_1178  960
    service_1_27_4  unique_nonzero_owner_401  1
    service_1_27_4  service_visit_def_1161  1
    service_1_27_4  free_load_conservation_1162  -7
    service_1_27_4  original_T_including_depot_unload_1178  840
    service_1_27_5  unique_nonzero_owner_402  1
    service_1_27_5  service_visit_def_1161  1
    service_1_27_5  free_load_conservation_1162  -6
    service_1_27_5  original_T_including_depot_unload_1178  720
    service_1_27_6  unique_nonzero_owner_403  1
    service_1_27_6  service_visit_def_1161  1
    service_1_27_6  free_load_conservation_1162  -5
    service_1_27_6  original_T_including_depot_unload_1178  600
    service_1_27_7  unique_nonzero_owner_404  1
    service_1_27_7  service_visit_def_1161  1
    service_1_27_7  free_load_conservation_1162  -4
    service_1_27_7  original_T_including_depot_unload_1178  480
    service_1_27_8  unique_nonzero_owner_405  1
    service_1_27_8  service_visit_def_1161  1
    service_1_27_8  free_load_conservation_1162  -3
    service_1_27_8  original_T_including_depot_unload_1178  360
    service_1_27_9  unique_nonzero_owner_406  1
    service_1_27_9  service_visit_def_1161  1
    service_1_27_9  free_load_conservation_1162  -2
    service_1_27_9  original_T_including_depot_unload_1178  240
    service_1_27_10  unique_nonzero_owner_407  1
    service_1_27_10  service_visit_def_1161  1
    service_1_27_10  free_load_conservation_1162  -1
    service_1_27_10  original_T_including_depot_unload_1178  120
    service_1_27_12  unique_nonzero_owner_408  1
    service_1_27_12  service_visit_def_1161  1
    service_1_27_12  free_load_conservation_1162  1
    service_1_27_13  unique_nonzero_owner_409  1
    service_1_27_13  service_visit_def_1161  1
    service_1_27_13  free_load_conservation_1162  2
    service_1_27_14  unique_nonzero_owner_410  1
    service_1_27_14  service_visit_def_1161  1
    service_1_27_14  free_load_conservation_1162  3
    service_1_27_15  unique_nonzero_owner_411  1
    service_1_27_15  service_visit_def_1161  1
    service_1_27_15  free_load_conservation_1162  4
    service_2_27_0  unique_nonzero_owner_397  1
    service_2_27_0  service_visit_def_1479  1
    service_2_27_0  free_load_conservation_1480  -11
    service_2_27_0  original_T_including_depot_unload_1495  1320
    service_2_27_1  unique_nonzero_owner_398  1
    service_2_27_1  service_visit_def_1479  1
    service_2_27_1  free_load_conservation_1480  -10
    service_2_27_1  original_T_including_depot_unload_1495  1200
    service_2_27_2  unique_nonzero_owner_399  1
    service_2_27_2  service_visit_def_1479  1
    service_2_27_2  free_load_conservation_1480  -9
    service_2_27_2  original_T_including_depot_unload_1495  1080
    service_2_27_3  unique_nonzero_owner_400  1
    service_2_27_3  service_visit_def_1479  1
    service_2_27_3  free_load_conservation_1480  -8
    service_2_27_3  original_T_including_depot_unload_1495  960
    service_2_27_4  unique_nonzero_owner_401  1
    service_2_27_4  service_visit_def_1479  1
    service_2_27_4  free_load_conservation_1480  -7
    service_2_27_4  original_T_including_depot_unload_1495  840
    service_2_27_5  unique_nonzero_owner_402  1
    service_2_27_5  service_visit_def_1479  1
    service_2_27_5  free_load_conservation_1480  -6
    service_2_27_5  original_T_including_depot_unload_1495  720
    service_2_27_6  unique_nonzero_owner_403  1
    service_2_27_6  service_visit_def_1479  1
    service_2_27_6  free_load_conservation_1480  -5
    service_2_27_6  original_T_including_depot_unload_1495  600
    service_2_27_7  unique_nonzero_owner_404  1
    service_2_27_7  service_visit_def_1479  1
    service_2_27_7  free_load_conservation_1480  -4
    service_2_27_7  original_T_including_depot_unload_1495  480
    service_2_27_8  unique_nonzero_owner_405  1
    service_2_27_8  service_visit_def_1479  1
    service_2_27_8  free_load_conservation_1480  -3
    service_2_27_8  original_T_including_depot_unload_1495  360
    service_2_27_9  unique_nonzero_owner_406  1
    service_2_27_9  service_visit_def_1479  1
    service_2_27_9  free_load_conservation_1480  -2
    service_2_27_9  original_T_including_depot_unload_1495  240
    service_2_27_10  unique_nonzero_owner_407  1
    service_2_27_10  service_visit_def_1479  1
    service_2_27_10  free_load_conservation_1480  -1
    service_2_27_10  original_T_including_depot_unload_1495  120
    service_2_27_12  unique_nonzero_owner_408  1
    service_2_27_12  service_visit_def_1479  1
    service_2_27_12  free_load_conservation_1480  1
    service_2_27_13  unique_nonzero_owner_409  1
    service_2_27_13  service_visit_def_1479  1
    service_2_27_13  free_load_conservation_1480  2
    service_2_27_14  unique_nonzero_owner_410  1
    service_2_27_14  service_visit_def_1479  1
    service_2_27_14  free_load_conservation_1480  3
    service_2_27_15  unique_nonzero_owner_411  1
    service_2_27_15  service_visit_def_1479  1
    service_2_27_15  free_load_conservation_1480  4
    service_0_6_0  unique_nonzero_owner_412  1
    service_0_6_0  service_visit_def_796  1
    service_0_6_0  free_load_conservation_797  -1
    service_0_6_0  original_T_including_depot_unload_807  120
    service_0_6_2  unique_nonzero_owner_413  1
    service_0_6_2  service_visit_def_796  1
    service_0_6_2  free_load_conservation_797  1
    service_0_6_3  unique_nonzero_owner_414  1
    service_0_6_3  service_visit_def_796  1
    service_0_6_3  free_load_conservation_797  2
    service_0_6_4  unique_nonzero_owner_415  1
    service_0_6_4  service_visit_def_796  1
    service_0_6_4  free_load_conservation_797  3
    service_0_6_5  unique_nonzero_owner_416  1
    service_0_6_5  service_visit_def_796  1
    service_0_6_5  free_load_conservation_797  4
    service_0_6_6  unique_nonzero_owner_417  1
    service_0_6_6  service_visit_def_796  1
    service_0_6_6  free_load_conservation_797  5
    service_0_6_7  unique_nonzero_owner_418  1
    service_0_6_7  service_visit_def_796  1
    service_0_6_7  free_load_conservation_797  6
    service_0_6_8  unique_nonzero_owner_419  1
    service_0_6_8  service_visit_def_796  1
    service_0_6_8  free_load_conservation_797  7
    service_0_6_9  unique_nonzero_owner_420  1
    service_0_6_9  service_visit_def_796  1
    service_0_6_9  free_load_conservation_797  8
    service_0_6_10  unique_nonzero_owner_421  1
    service_0_6_10  service_visit_def_796  1
    service_0_6_10  free_load_conservation_797  9
    service_1_6_0  unique_nonzero_owner_412  1
    service_1_6_0  service_visit_def_1167  1
    service_1_6_0  free_load_conservation_1168  -1
    service_1_6_0  original_T_including_depot_unload_1178  120
    service_1_6_2  unique_nonzero_owner_413  1
    service_1_6_2  service_visit_def_1167  1
    service_1_6_2  free_load_conservation_1168  1
    service_1_6_3  unique_nonzero_owner_414  1
    service_1_6_3  service_visit_def_1167  1
    service_1_6_3  free_load_conservation_1168  2
    service_1_6_4  unique_nonzero_owner_415  1
    service_1_6_4  service_visit_def_1167  1
    service_1_6_4  free_load_conservation_1168  3
    service_1_6_5  unique_nonzero_owner_416  1
    service_1_6_5  service_visit_def_1167  1
    service_1_6_5  free_load_conservation_1168  4
    service_1_6_6  unique_nonzero_owner_417  1
    service_1_6_6  service_visit_def_1167  1
    service_1_6_6  free_load_conservation_1168  5
    service_1_6_7  unique_nonzero_owner_418  1
    service_1_6_7  service_visit_def_1167  1
    service_1_6_7  free_load_conservation_1168  6
    service_1_6_8  unique_nonzero_owner_419  1
    service_1_6_8  service_visit_def_1167  1
    service_1_6_8  free_load_conservation_1168  7
    service_1_6_9  unique_nonzero_owner_420  1
    service_1_6_9  service_visit_def_1167  1
    service_1_6_9  free_load_conservation_1168  8
    service_1_6_10  unique_nonzero_owner_421  1
    service_1_6_10  service_visit_def_1167  1
    service_1_6_10  free_load_conservation_1168  9
    service_2_6_0  unique_nonzero_owner_412  1
    service_2_6_0  service_visit_def_1485  1
    service_2_6_0  free_load_conservation_1486  -1
    service_2_6_0  original_T_including_depot_unload_1495  120
    service_2_6_2  unique_nonzero_owner_413  1
    service_2_6_2  service_visit_def_1485  1
    service_2_6_2  free_load_conservation_1486  1
    service_2_6_3  unique_nonzero_owner_414  1
    service_2_6_3  service_visit_def_1485  1
    service_2_6_3  free_load_conservation_1486  2
    service_2_6_4  unique_nonzero_owner_415  1
    service_2_6_4  service_visit_def_1485  1
    service_2_6_4  free_load_conservation_1486  3
    service_2_6_5  unique_nonzero_owner_416  1
    service_2_6_5  service_visit_def_1485  1
    service_2_6_5  free_load_conservation_1486  4
    service_2_6_6  unique_nonzero_owner_417  1
    service_2_6_6  service_visit_def_1485  1
    service_2_6_6  free_load_conservation_1486  5
    service_2_6_7  unique_nonzero_owner_418  1
    service_2_6_7  service_visit_def_1485  1
    service_2_6_7  free_load_conservation_1486  6
    service_2_6_8  unique_nonzero_owner_419  1
    service_2_6_8  service_visit_def_1485  1
    service_2_6_8  free_load_conservation_1486  7
    service_2_6_9  unique_nonzero_owner_420  1
    service_2_6_9  service_visit_def_1485  1
    service_2_6_9  free_load_conservation_1486  8
    service_2_6_10  unique_nonzero_owner_421  1
    service_2_6_10  service_visit_def_1485  1
    service_2_6_10  free_load_conservation_1486  9
    service_0_12_1  unique_nonzero_owner_422  1
    service_0_12_1  service_visit_def_802  1
    service_0_12_1  free_load_conservation_803  1
    service_0_12_2  unique_nonzero_owner_423  1
    service_0_12_2  service_visit_def_802  1
    service_0_12_2  free_load_conservation_803  2
    service_0_12_3  unique_nonzero_owner_424  1
    service_0_12_3  service_visit_def_802  1
    service_0_12_3  free_load_conservation_803  3
    service_0_12_4  unique_nonzero_owner_425  1
    service_0_12_4  service_visit_def_802  1
    service_0_12_4  free_load_conservation_803  4
    service_0_12_5  unique_nonzero_owner_426  1
    service_0_12_5  service_visit_def_802  1
    service_0_12_5  free_load_conservation_803  5
    service_0_12_6  unique_nonzero_owner_427  1
    service_0_12_6  service_visit_def_802  1
    service_0_12_6  free_load_conservation_803  6
    service_0_12_7  unique_nonzero_owner_428  1
    service_0_12_7  service_visit_def_802  1
    service_0_12_7  free_load_conservation_803  7
    service_0_12_8  unique_nonzero_owner_429  1
    service_0_12_8  service_visit_def_802  1
    service_0_12_8  free_load_conservation_803  8
    service_0_12_9  unique_nonzero_owner_430  1
    service_0_12_9  service_visit_def_802  1
    service_0_12_9  free_load_conservation_803  9
    service_0_12_10  unique_nonzero_owner_431  1
    service_0_12_10  service_visit_def_802  1
    service_0_12_10  free_load_conservation_803  10
    service_0_12_11  unique_nonzero_owner_432  1
    service_0_12_11  service_visit_def_802  1
    service_0_12_11  free_load_conservation_803  11
    service_0_12_12  unique_nonzero_owner_433  1
    service_0_12_12  service_visit_def_802  1
    service_0_12_12  free_load_conservation_803  12
    service_0_12_13  unique_nonzero_owner_434  1
    service_0_12_13  service_visit_def_802  1
    service_0_12_13  free_load_conservation_803  13
    service_0_12_14  unique_nonzero_owner_435  1
    service_0_12_14  service_visit_def_802  1
    service_0_12_14  free_load_conservation_803  14
    service_0_12_15  unique_nonzero_owner_436  1
    service_0_12_15  service_visit_def_802  1
    service_0_12_15  free_load_conservation_803  15
    service_1_12_1  unique_nonzero_owner_422  1
    service_1_12_1  service_visit_def_1173  1
    service_1_12_1  free_load_conservation_1174  1
    service_1_12_2  unique_nonzero_owner_423  1
    service_1_12_2  service_visit_def_1173  1
    service_1_12_2  free_load_conservation_1174  2
    service_1_12_3  unique_nonzero_owner_424  1
    service_1_12_3  service_visit_def_1173  1
    service_1_12_3  free_load_conservation_1174  3
    service_1_12_4  unique_nonzero_owner_425  1
    service_1_12_4  service_visit_def_1173  1
    service_1_12_4  free_load_conservation_1174  4
    service_1_12_5  unique_nonzero_owner_426  1
    service_1_12_5  service_visit_def_1173  1
    service_1_12_5  free_load_conservation_1174  5
    service_1_12_6  unique_nonzero_owner_427  1
    service_1_12_6  service_visit_def_1173  1
    service_1_12_6  free_load_conservation_1174  6
    service_1_12_7  unique_nonzero_owner_428  1
    service_1_12_7  service_visit_def_1173  1
    service_1_12_7  free_load_conservation_1174  7
    service_1_12_8  unique_nonzero_owner_429  1
    service_1_12_8  service_visit_def_1173  1
    service_1_12_8  free_load_conservation_1174  8
    service_1_12_9  unique_nonzero_owner_430  1
    service_1_12_9  service_visit_def_1173  1
    service_1_12_9  free_load_conservation_1174  9
    service_1_12_10  unique_nonzero_owner_431  1
    service_1_12_10  service_visit_def_1173  1
    service_1_12_10  free_load_conservation_1174  10
    service_1_12_11  unique_nonzero_owner_432  1
    service_1_12_11  service_visit_def_1173  1
    service_1_12_11  free_load_conservation_1174  11
    service_1_12_12  unique_nonzero_owner_433  1
    service_1_12_12  service_visit_def_1173  1
    service_1_12_12  free_load_conservation_1174  12
    service_1_12_13  unique_nonzero_owner_434  1
    service_1_12_13  service_visit_def_1173  1
    service_1_12_13  free_load_conservation_1174  13
    service_1_12_14  unique_nonzero_owner_435  1
    service_1_12_14  service_visit_def_1173  1
    service_1_12_14  free_load_conservation_1174  14
    service_1_12_15  unique_nonzero_owner_436  1
    service_1_12_15  service_visit_def_1173  1
    service_1_12_15  free_load_conservation_1174  15
    service_2_12_1  unique_nonzero_owner_422  1
    service_2_12_1  service_visit_def_1491  1
    service_2_12_1  free_load_conservation_1492  1
    service_2_12_2  unique_nonzero_owner_423  1
    service_2_12_2  service_visit_def_1491  1
    service_2_12_2  free_load_conservation_1492  2
    service_2_12_3  unique_nonzero_owner_424  1
    service_2_12_3  service_visit_def_1491  1
    service_2_12_3  free_load_conservation_1492  3
    service_2_12_4  unique_nonzero_owner_425  1
    service_2_12_4  service_visit_def_1491  1
    service_2_12_4  free_load_conservation_1492  4
    service_2_12_5  unique_nonzero_owner_426  1
    service_2_12_5  service_visit_def_1491  1
    service_2_12_5  free_load_conservation_1492  5
    service_2_12_6  unique_nonzero_owner_427  1
    service_2_12_6  service_visit_def_1491  1
    service_2_12_6  free_load_conservation_1492  6
    service_2_12_7  unique_nonzero_owner_428  1
    service_2_12_7  service_visit_def_1491  1
    service_2_12_7  free_load_conservation_1492  7
    service_2_12_8  unique_nonzero_owner_429  1
    service_2_12_8  service_visit_def_1491  1
    service_2_12_8  free_load_conservation_1492  8
    service_2_12_9  unique_nonzero_owner_430  1
    service_2_12_9  service_visit_def_1491  1
    service_2_12_9  free_load_conservation_1492  9
    service_2_12_10  unique_nonzero_owner_431  1
    service_2_12_10  service_visit_def_1491  1
    service_2_12_10  free_load_conservation_1492  10
    service_2_12_11  unique_nonzero_owner_432  1
    service_2_12_11  service_visit_def_1491  1
    service_2_12_11  free_load_conservation_1492  11
    service_2_12_12  unique_nonzero_owner_433  1
    service_2_12_12  service_visit_def_1491  1
    service_2_12_12  free_load_conservation_1492  12
    service_2_12_13  unique_nonzero_owner_434  1
    service_2_12_13  service_visit_def_1491  1
    service_2_12_13  free_load_conservation_1492  13
    service_2_12_14  unique_nonzero_owner_435  1
    service_2_12_14  service_visit_def_1491  1
    service_2_12_14  free_load_conservation_1492  14
    service_2_12_15  unique_nonzero_owner_436  1
    service_2_12_15  service_visit_def_1491  1
    service_2_12_15  free_load_conservation_1492  15
    MARKER    'MARKER'                 'INTEND'
    visit_0_1  out_degree_728  -1
    visit_0_1  in_degree_729  -1
    visit_0_1  order_active_lb_730  -1
    visit_0_1  order_active_ub_731  -12
    order_0_1  connected_order_arc_452  -1
    order_0_1  connected_order_arc_454  -1
    order_0_1  connected_order_arc_456  -1
    order_0_1  connected_order_arc_458  -1
    order_0_1  connected_order_arc_460  -1
    order_0_1  connected_order_arc_462  -1
    order_0_1  connected_order_arc_464  -1
    order_0_1  connected_order_arc_466  -1
    order_0_1  connected_order_arc_468  -1
    order_0_1  connected_order_arc_470  -1
    order_0_1  connected_order_arc_472  -1
    order_0_1  connected_order_arc_475  1
    order_0_1  connected_order_arc_498  1
    order_0_1  connected_order_arc_521  1
    order_0_1  connected_order_arc_544  1
    order_0_1  connected_order_arc_567  1
    order_0_1  connected_order_arc_590  1
    order_0_1  connected_order_arc_613  1
    order_0_1  connected_order_arc_636  1
    order_0_1  connected_order_arc_659  1
    order_0_1  connected_order_arc_682  1
    order_0_1  connected_order_arc_705  1
    order_0_1  order_active_lb_730  1
    order_0_1  order_active_ub_731  1
    order_0_1  fixed_segment_relative_order_804  -1
    visit_0_2  out_degree_735  -1
    visit_0_2  in_degree_736  -1
    visit_0_2  order_active_lb_737  -1
    visit_0_2  order_active_ub_738  -12
    order_0_2  connected_order_arc_452  1
    order_0_2  connected_order_arc_475  -1
    order_0_2  connected_order_arc_477  -1
    order_0_2  connected_order_arc_479  -1
    order_0_2  connected_order_arc_481  -1
    order_0_2  connected_order_arc_483  -1
    order_0_2  connected_order_arc_485  -1
    order_0_2  connected_order_arc_487  -1
    order_0_2  connected_order_arc_489  -1
    order_0_2  connected_order_arc_491  -1
    order_0_2  connected_order_arc_493  -1
    order_0_2  connected_order_arc_495  -1
    order_0_2  connected_order_arc_500  1
    order_0_2  connected_order_arc_523  1
    order_0_2  connected_order_arc_546  1
    order_0_2  connected_order_arc_569  1
    order_0_2  connected_order_arc_592  1
    order_0_2  connected_order_arc_615  1
    order_0_2  connected_order_arc_638  1
    order_0_2  connected_order_arc_661  1
    order_0_2  connected_order_arc_684  1
    order_0_2  connected_order_arc_707  1
    order_0_2  order_active_lb_737  1
    order_0_2  order_active_ub_738  1
    order_0_2  fixed_segment_relative_order_804  1
    order_0_2  fixed_segment_relative_order_805  -1
    visit_0_3  out_degree_742  -1
    visit_0_3  in_degree_743  -1
    visit_0_3  order_active_lb_744  -1
    visit_0_3  order_active_ub_745  -12
    order_0_3  connected_order_arc_454  1
    order_0_3  connected_order_arc_477  1
    order_0_3  connected_order_arc_498  -1
    order_0_3  connected_order_arc_500  -1
    order_0_3  connected_order_arc_502  -1
    order_0_3  connected_order_arc_504  -1
    order_0_3  connected_order_arc_506  -1
    order_0_3  connected_order_arc_508  -1
    order_0_3  connected_order_arc_510  -1
    order_0_3  connected_order_arc_512  -1
    order_0_3  connected_order_arc_514  -1
    order_0_3  connected_order_arc_516  -1
    order_0_3  connected_order_arc_518  -1
    order_0_3  connected_order_arc_525  1
    order_0_3  connected_order_arc_548  1
    order_0_3  connected_order_arc_571  1
    order_0_3  connected_order_arc_594  1
    order_0_3  connected_order_arc_617  1
    order_0_3  connected_order_arc_640  1
    order_0_3  connected_order_arc_663  1
    order_0_3  connected_order_arc_686  1
    order_0_3  connected_order_arc_709  1
    order_0_3  order_active_lb_744  1
    order_0_3  order_active_ub_745  1
    order_0_3  fixed_segment_relative_order_805  1
    order_0_3  fixed_segment_relative_order_806  -1
    visit_0_4  out_degree_749  -1
    visit_0_4  in_degree_750  -1
    visit_0_4  order_active_lb_751  -1
    visit_0_4  order_active_ub_752  -12
    order_0_4  connected_order_arc_456  1
    order_0_4  connected_order_arc_479  1
    order_0_4  connected_order_arc_502  1
    order_0_4  connected_order_arc_521  -1
    order_0_4  connected_order_arc_523  -1
    order_0_4  connected_order_arc_525  -1
    order_0_4  connected_order_arc_527  -1
    order_0_4  connected_order_arc_529  -1
    order_0_4  connected_order_arc_531  -1
    order_0_4  connected_order_arc_533  -1
    order_0_4  connected_order_arc_535  -1
    order_0_4  connected_order_arc_537  -1
    order_0_4  connected_order_arc_539  -1
    order_0_4  connected_order_arc_541  -1
    order_0_4  connected_order_arc_550  1
    order_0_4  connected_order_arc_573  1
    order_0_4  connected_order_arc_596  1
    order_0_4  connected_order_arc_619  1
    order_0_4  connected_order_arc_642  1
    order_0_4  connected_order_arc_665  1
    order_0_4  connected_order_arc_688  1
    order_0_4  connected_order_arc_711  1
    order_0_4  order_active_lb_751  1
    order_0_4  order_active_ub_752  1
    order_0_4  fixed_segment_relative_order_806  1
    visit_0_12  out_degree_756  -1
    visit_0_12  in_degree_757  -1
    visit_0_12  order_active_lb_758  -1
    visit_0_12  order_active_ub_759  -12
    visit_0_12  service_visit_def_760  -1
    order_0_12  connected_order_arc_458  1
    order_0_12  connected_order_arc_481  1
    order_0_12  connected_order_arc_504  1
    order_0_12  connected_order_arc_527  1
    order_0_12  connected_order_arc_544  -1
    order_0_12  connected_order_arc_546  -1
    order_0_12  connected_order_arc_548  -1
    order_0_12  connected_order_arc_550  -1
    order_0_12  connected_order_arc_552  -1
    order_0_12  connected_order_arc_554  -1
    order_0_12  connected_order_arc_556  -1
    order_0_12  connected_order_arc_558  -1
    order_0_12  connected_order_arc_560  -1
    order_0_12  connected_order_arc_562  -1
    order_0_12  connected_order_arc_564  -1
    order_0_12  connected_order_arc_575  1
    order_0_12  connected_order_arc_598  1
    order_0_12  connected_order_arc_621  1
    order_0_12  connected_order_arc_644  1
    order_0_12  connected_order_arc_667  1
    order_0_12  connected_order_arc_690  1
    order_0_12  connected_order_arc_713  1
    order_0_12  order_active_lb_758  1
    order_0_12  order_active_ub_759  1
    visit_0_13  out_degree_762  -1
    visit_0_13  in_degree_763  -1
    visit_0_13  order_active_lb_764  -1
    visit_0_13  order_active_ub_765  -12
    visit_0_13  service_visit_def_766  -1
    order_0_13  connected_order_arc_460  1
    order_0_13  connected_order_arc_483  1
    order_0_13  connected_order_arc_506  1
    order_0_13  connected_order_arc_529  1
    order_0_13  connected_order_arc_552  1
    order_0_13  connected_order_arc_567  -1
    order_0_13  connected_order_arc_569  -1
    order_0_13  connected_order_arc_571  -1
    order_0_13  connected_order_arc_573  -1
    order_0_13  connected_order_arc_575  -1
    order_0_13  connected_order_arc_577  -1
    order_0_13  connected_order_arc_579  -1
    order_0_13  connected_order_arc_581  -1
    order_0_13  connected_order_arc_583  -1
    order_0_13  connected_order_arc_585  -1
    order_0_13  connected_order_arc_587  -1
    order_0_13  connected_order_arc_600  1
    order_0_13  connected_order_arc_623  1
    order_0_13  connected_order_arc_646  1
    order_0_13  connected_order_arc_669  1
    order_0_13  connected_order_arc_692  1
    order_0_13  connected_order_arc_715  1
    order_0_13  order_active_lb_764  1
    order_0_13  order_active_ub_765  1
    visit_0_14  out_degree_768  -1
    visit_0_14  in_degree_769  -1
    visit_0_14  order_active_lb_770  -1
    visit_0_14  order_active_ub_771  -12
    visit_0_14  service_visit_def_772  -1
    order_0_14  connected_order_arc_462  1
    order_0_14  connected_order_arc_485  1
    order_0_14  connected_order_arc_508  1
    order_0_14  connected_order_arc_531  1
    order_0_14  connected_order_arc_554  1
    order_0_14  connected_order_arc_577  1
    order_0_14  connected_order_arc_590  -1
    order_0_14  connected_order_arc_592  -1
    order_0_14  connected_order_arc_594  -1
    order_0_14  connected_order_arc_596  -1
    order_0_14  connected_order_arc_598  -1
    order_0_14  connected_order_arc_600  -1
    order_0_14  connected_order_arc_602  -1
    order_0_14  connected_order_arc_604  -1
    order_0_14  connected_order_arc_606  -1
    order_0_14  connected_order_arc_608  -1
    order_0_14  connected_order_arc_610  -1
    order_0_14  connected_order_arc_625  1
    order_0_14  connected_order_arc_648  1
    order_0_14  connected_order_arc_671  1
    order_0_14  connected_order_arc_694  1
    order_0_14  connected_order_arc_717  1
    order_0_14  order_active_lb_770  1
    order_0_14  order_active_ub_771  1
    visit_0_15  out_degree_774  -1
    visit_0_15  in_degree_775  -1
    visit_0_15  order_active_lb_776  -1
    visit_0_15  order_active_ub_777  -12
    visit_0_15  service_visit_def_778  -1
    order_0_15  connected_order_arc_464  1
    order_0_15  connected_order_arc_487  1
    order_0_15  connected_order_arc_510  1
    order_0_15  connected_order_arc_533  1
    order_0_15  connected_order_arc_556  1
    order_0_15  connected_order_arc_579  1
    order_0_15  connected_order_arc_602  1
    order_0_15  connected_order_arc_613  -1
    order_0_15  connected_order_arc_615  -1
    order_0_15  connected_order_arc_617  -1
    order_0_15  connected_order_arc_619  -1
    order_0_15  connected_order_arc_621  -1
    order_0_15  connected_order_arc_623  -1
    order_0_15  connected_order_arc_625  -1
    order_0_15  connected_order_arc_627  -1
    order_0_15  connected_order_arc_629  -1
    order_0_15  connected_order_arc_631  -1
    order_0_15  connected_order_arc_633  -1
    order_0_15  connected_order_arc_650  1
    order_0_15  connected_order_arc_673  1
    order_0_15  connected_order_arc_696  1
    order_0_15  connected_order_arc_719  1
    order_0_15  order_active_lb_776  1
    order_0_15  order_active_ub_777  1
    visit_0_16  out_degree_780  -1
    visit_0_16  in_degree_781  -1
    visit_0_16  order_active_lb_782  -1
    visit_0_16  order_active_ub_783  -12
    visit_0_16  service_visit_def_784  -1
    order_0_16  connected_order_arc_466  1
    order_0_16  connected_order_arc_489  1
    order_0_16  connected_order_arc_512  1
    order_0_16  connected_order_arc_535  1
    order_0_16  connected_order_arc_558  1
    order_0_16  connected_order_arc_581  1
    order_0_16  connected_order_arc_604  1
    order_0_16  connected_order_arc_627  1
    order_0_16  connected_order_arc_636  -1
    order_0_16  connected_order_arc_638  -1
    order_0_16  connected_order_arc_640  -1
    order_0_16  connected_order_arc_642  -1
    order_0_16  connected_order_arc_644  -1
    order_0_16  connected_order_arc_646  -1
    order_0_16  connected_order_arc_648  -1
    order_0_16  connected_order_arc_650  -1
    order_0_16  connected_order_arc_652  -1
    order_0_16  connected_order_arc_654  -1
    order_0_16  connected_order_arc_656  -1
    order_0_16  connected_order_arc_675  1
    order_0_16  connected_order_arc_698  1
    order_0_16  connected_order_arc_721  1
    order_0_16  order_active_lb_782  1
    order_0_16  order_active_ub_783  1
    visit_0_17  out_degree_786  -1
    visit_0_17  in_degree_787  -1
    visit_0_17  order_active_lb_788  -1
    visit_0_17  order_active_ub_789  -12
    visit_0_17  service_visit_def_790  -1
    order_0_17  connected_order_arc_468  1
    order_0_17  connected_order_arc_491  1
    order_0_17  connected_order_arc_514  1
    order_0_17  connected_order_arc_537  1
    order_0_17  connected_order_arc_560  1
    order_0_17  connected_order_arc_583  1
    order_0_17  connected_order_arc_606  1
    order_0_17  connected_order_arc_629  1
    order_0_17  connected_order_arc_652  1
    order_0_17  connected_order_arc_659  -1
    order_0_17  connected_order_arc_661  -1
    order_0_17  connected_order_arc_663  -1
    order_0_17  connected_order_arc_665  -1
    order_0_17  connected_order_arc_667  -1
    order_0_17  connected_order_arc_669  -1
    order_0_17  connected_order_arc_671  -1
    order_0_17  connected_order_arc_673  -1
    order_0_17  connected_order_arc_675  -1
    order_0_17  connected_order_arc_677  -1
    order_0_17  connected_order_arc_679  -1
    order_0_17  connected_order_arc_700  1
    order_0_17  connected_order_arc_723  1
    order_0_17  order_active_lb_788  1
    order_0_17  order_active_ub_789  1
    visit_0_18  out_degree_792  -1
    visit_0_18  in_degree_793  -1
    visit_0_18  order_active_lb_794  -1
    visit_0_18  order_active_ub_795  -12
    visit_0_18  service_visit_def_796  -1
    order_0_18  connected_order_arc_470  1
    order_0_18  connected_order_arc_493  1
    order_0_18  connected_order_arc_516  1
    order_0_18  connected_order_arc_539  1
    order_0_18  connected_order_arc_562  1
    order_0_18  connected_order_arc_585  1
    order_0_18  connected_order_arc_608  1
    order_0_18  connected_order_arc_631  1
    order_0_18  connected_order_arc_654  1
    order_0_18  connected_order_arc_677  1
    order_0_18  connected_order_arc_682  -1
    order_0_18  connected_order_arc_684  -1
    order_0_18  connected_order_arc_686  -1
    order_0_18  connected_order_arc_688  -1
    order_0_18  connected_order_arc_690  -1
    order_0_18  connected_order_arc_692  -1
    order_0_18  connected_order_arc_694  -1
    order_0_18  connected_order_arc_696  -1
    order_0_18  connected_order_arc_698  -1
    order_0_18  connected_order_arc_700  -1
    order_0_18  connected_order_arc_702  -1
    order_0_18  connected_order_arc_725  1
    order_0_18  order_active_lb_794  1
    order_0_18  order_active_ub_795  1
    visit_0_19  out_degree_798  -1
    visit_0_19  in_degree_799  -1
    visit_0_19  order_active_lb_800  -1
    visit_0_19  order_active_ub_801  -12
    visit_0_19  service_visit_def_802  -1
    order_0_19  connected_order_arc_472  1
    order_0_19  connected_order_arc_495  1
    order_0_19  connected_order_arc_518  1
    order_0_19  connected_order_arc_541  1
    order_0_19  connected_order_arc_564  1
    order_0_19  connected_order_arc_587  1
    order_0_19  connected_order_arc_610  1
    order_0_19  connected_order_arc_633  1
    order_0_19  connected_order_arc_656  1
    order_0_19  connected_order_arc_679  1
    order_0_19  connected_order_arc_702  1
    order_0_19  connected_order_arc_705  -1
    order_0_19  connected_order_arc_707  -1
    order_0_19  connected_order_arc_709  -1
    order_0_19  connected_order_arc_711  -1
    order_0_19  connected_order_arc_713  -1
    order_0_19  connected_order_arc_715  -1
    order_0_19  connected_order_arc_717  -1
    order_0_19  connected_order_arc_719  -1
    order_0_19  connected_order_arc_721  -1
    order_0_19  connected_order_arc_723  -1
    order_0_19  connected_order_arc_725  -1
    order_0_19  order_active_lb_800  1
    order_0_19  order_active_ub_801  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_0  arc_capacity_437  -20
    arc_0_0_0  depot_departure_or_bypass_726  1
    arc_0_0_0  depot_return_or_bypass_727  1
    MARKER    'MARKER'                 'INTEND'
    load_0_0_0  arc_capacity_437  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_1  arc_capacity_438  -20
    arc_0_0_1  depot_departure_or_bypass_726  1
    arc_0_0_1  in_degree_729  1
    arc_0_0_1  original_T_including_depot_unload_807  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_1  arc_capacity_438  1
    load_0_0_1  segment_load_conservation_732  -1
    load_0_0_1  segment_prefix_lb_733  1
    load_0_0_1  segment_prefix_ub_734  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_2  arc_capacity_439  -20
    arc_0_0_2  depot_departure_or_bypass_726  1
    arc_0_0_2  in_degree_736  1
    arc_0_0_2  original_T_including_depot_unload_807  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_2  arc_capacity_439  1
    load_0_0_2  segment_load_conservation_739  -1
    load_0_0_2  segment_prefix_lb_740  1
    load_0_0_2  segment_prefix_ub_741  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_3  arc_capacity_440  -20
    arc_0_0_3  depot_departure_or_bypass_726  1
    arc_0_0_3  in_degree_743  1
    arc_0_0_3  original_T_including_depot_unload_807  6.6653528395596720e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_3  arc_capacity_440  1
    load_0_0_3  segment_load_conservation_746  -1
    load_0_0_3  segment_prefix_lb_747  1
    load_0_0_3  segment_prefix_ub_748  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_4  arc_capacity_441  -20
    arc_0_0_4  depot_departure_or_bypass_726  1
    arc_0_0_4  in_degree_750  1
    arc_0_0_4  original_T_including_depot_unload_807  5.9431738885389052e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_4  arc_capacity_441  1
    load_0_0_4  segment_load_conservation_753  -1
    load_0_0_4  segment_prefix_lb_754  1
    load_0_0_4  segment_prefix_ub_755  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_12  arc_capacity_442  -20
    arc_0_0_12  depot_departure_or_bypass_726  1
    arc_0_0_12  in_degree_757  1
    arc_0_0_12  original_T_including_depot_unload_807  8.7918533905669346e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_12  arc_capacity_442  1
    load_0_0_12  free_load_conservation_761  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_13  arc_capacity_443  -20
    arc_0_0_13  depot_departure_or_bypass_726  1
    arc_0_0_13  in_degree_763  1
    arc_0_0_13  original_T_including_depot_unload_807  1.0479182987243917e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_13  arc_capacity_443  1
    load_0_0_13  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_14  arc_capacity_444  -20
    arc_0_0_14  depot_departure_or_bypass_726  1
    arc_0_0_14  in_degree_769  1
    arc_0_0_14  original_T_including_depot_unload_807  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_14  arc_capacity_444  1
    load_0_0_14  free_load_conservation_773  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_15  arc_capacity_445  -20
    arc_0_0_15  depot_departure_or_bypass_726  1
    arc_0_0_15  in_degree_775  1
    arc_0_0_15  original_T_including_depot_unload_807  8.7749189782983967e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_15  arc_capacity_445  1
    load_0_0_15  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_16  arc_capacity_446  -20
    arc_0_0_16  depot_departure_or_bypass_726  1
    arc_0_0_16  in_degree_781  1
    arc_0_0_16  original_T_including_depot_unload_807  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_16  arc_capacity_446  1
    load_0_0_16  free_load_conservation_785  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_17  arc_capacity_447  -20
    arc_0_0_17  depot_departure_or_bypass_726  1
    arc_0_0_17  in_degree_787  1
    arc_0_0_17  original_T_including_depot_unload_807  1.0088905112952611e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_17  arc_capacity_447  1
    load_0_0_17  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_18  arc_capacity_448  -20
    arc_0_0_18  depot_departure_or_bypass_726  1
    arc_0_0_18  in_degree_793  1
    arc_0_0_18  original_T_including_depot_unload_807  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_18  arc_capacity_448  1
    load_0_0_18  free_load_conservation_797  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_19  arc_capacity_449  -20
    arc_0_0_19  depot_departure_or_bypass_726  1
    arc_0_0_19  in_degree_799  1
    arc_0_0_19  original_T_including_depot_unload_807  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_19  arc_capacity_449  1
    load_0_0_19  free_load_conservation_803  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_0  arc_capacity_450  -20
    arc_0_1_0  depot_return_or_bypass_727  1
    arc_0_1_0  out_degree_728  1
    arc_0_1_0  original_T_including_depot_unload_807  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_0  arc_capacity_450  1
    load_0_1_0  segment_load_conservation_732  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_2  arc_capacity_451  -20
    arc_0_1_2  connected_order_arc_452  -13
    arc_0_1_2  out_degree_728  1
    arc_0_1_2  in_degree_736  1
    arc_0_1_2  original_T_including_depot_unload_807  2.7570828838654035e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_2  arc_capacity_451  1
    load_0_1_2  segment_load_conservation_732  1
    load_0_1_2  segment_load_conservation_739  -1
    load_0_1_2  segment_prefix_lb_740  1
    load_0_1_2  segment_prefix_ub_741  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_3  arc_capacity_453  -20
    arc_0_1_3  connected_order_arc_454  -13
    arc_0_1_3  out_degree_728  1
    arc_0_1_3  in_degree_743  1
    arc_0_1_3  original_T_including_depot_unload_807  4.0284428834016438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_3  arc_capacity_453  1
    load_0_1_3  segment_load_conservation_732  1
    load_0_1_3  segment_load_conservation_746  -1
    load_0_1_3  segment_prefix_lb_747  1
    load_0_1_3  segment_prefix_ub_748  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_4  arc_capacity_455  -20
    arc_0_1_4  connected_order_arc_456  -13
    arc_0_1_4  out_degree_728  1
    arc_0_1_4  in_degree_750  1
    arc_0_1_4  original_T_including_depot_unload_807  5.8227353503177085e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_4  arc_capacity_455  1
    load_0_1_4  segment_load_conservation_732  1
    load_0_1_4  segment_load_conservation_753  -1
    load_0_1_4  segment_prefix_lb_754  1
    load_0_1_4  segment_prefix_ub_755  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_12  arc_capacity_457  -20
    arc_0_1_12  connected_order_arc_458  -13
    arc_0_1_12  out_degree_728  1
    arc_0_1_12  in_degree_757  1
    arc_0_1_12  original_T_including_depot_unload_807  1.3293032990949939e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_12  arc_capacity_457  1
    load_0_1_12  segment_load_conservation_732  1
    load_0_1_12  free_load_conservation_761  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_13  arc_capacity_459  -20
    arc_0_1_13  connected_order_arc_460  -13
    arc_0_1_13  out_degree_728  1
    arc_0_1_13  in_degree_763  1
    arc_0_1_13  original_T_including_depot_unload_807  1.4829753176244692e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_13  arc_capacity_459  1
    load_0_1_13  segment_load_conservation_732  1
    load_0_1_13  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_14  arc_capacity_461  -20
    arc_0_1_14  connected_order_arc_462  -13
    arc_0_1_14  out_degree_728  1
    arc_0_1_14  in_degree_769  1
    arc_0_1_14  original_T_including_depot_unload_807  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_14  arc_capacity_461  1
    load_0_1_14  segment_load_conservation_732  1
    load_0_1_14  free_load_conservation_773  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_15  arc_capacity_463  -20
    arc_0_1_15  connected_order_arc_464  -13
    arc_0_1_15  out_degree_728  1
    arc_0_1_15  in_degree_775  1
    arc_0_1_15  original_T_including_depot_unload_807  1.2798962893775918e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_15  arc_capacity_463  1
    load_0_1_15  segment_load_conservation_732  1
    load_0_1_15  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_16  arc_capacity_465  -20
    arc_0_1_16  connected_order_arc_466  -13
    arc_0_1_16  out_degree_728  1
    arc_0_1_16  in_degree_781  1
    arc_0_1_16  original_T_including_depot_unload_807  1.7053268374267958e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_16  arc_capacity_465  1
    load_0_1_16  segment_load_conservation_732  1
    load_0_1_16  free_load_conservation_785  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_17  arc_capacity_467  -20
    arc_0_1_17  connected_order_arc_468  -13
    arc_0_1_17  out_degree_728  1
    arc_0_1_17  in_degree_787  1
    arc_0_1_17  original_T_including_depot_unload_807  1.3874440214926751e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_17  arc_capacity_467  1
    load_0_1_17  segment_load_conservation_732  1
    load_0_1_17  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_18  arc_capacity_469  -20
    arc_0_1_18  connected_order_arc_470  -13
    arc_0_1_18  out_degree_728  1
    arc_0_1_18  in_degree_793  1
    arc_0_1_18  original_T_including_depot_unload_807  2.9376641610717382e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_18  arc_capacity_469  1
    load_0_1_18  segment_load_conservation_732  1
    load_0_1_18  free_load_conservation_797  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_19  arc_capacity_471  -20
    arc_0_1_19  connected_order_arc_472  -13
    arc_0_1_19  out_degree_728  1
    arc_0_1_19  in_degree_799  1
    arc_0_1_19  original_T_including_depot_unload_807  5.7354473845222140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_19  arc_capacity_471  1
    load_0_1_19  segment_load_conservation_732  1
    load_0_1_19  free_load_conservation_803  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_0  arc_capacity_473  -20
    arc_0_2_0  depot_return_or_bypass_727  1
    arc_0_2_0  out_degree_735  1
    arc_0_2_0  original_T_including_depot_unload_807  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_0  arc_capacity_473  1
    load_0_2_0  segment_load_conservation_739  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_1  arc_capacity_474  -20
    arc_0_2_1  connected_order_arc_475  -13
    arc_0_2_1  in_degree_729  1
    arc_0_2_1  out_degree_735  1
    arc_0_2_1  original_T_including_depot_unload_807  545.439458844012
    MARKER    'MARKER'                 'INTEND'
    load_0_2_1  arc_capacity_474  1
    load_0_2_1  segment_load_conservation_732  -1
    load_0_2_1  segment_prefix_lb_733  1
    load_0_2_1  segment_prefix_ub_734  1
    load_0_2_1  segment_load_conservation_739  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_3  arc_capacity_476  -20
    arc_0_2_3  connected_order_arc_477  -13
    arc_0_2_3  out_degree_735  1
    arc_0_2_3  in_degree_743  1
    arc_0_2_3  original_T_including_depot_unload_807  3.1069481377857926e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_3  arc_capacity_476  1
    load_0_2_3  segment_load_conservation_739  1
    load_0_2_3  segment_load_conservation_746  -1
    load_0_2_3  segment_prefix_lb_747  1
    load_0_2_3  segment_prefix_ub_748  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_4  arc_capacity_478  -20
    arc_0_2_4  connected_order_arc_479  -13
    arc_0_2_4  out_degree_735  1
    arc_0_2_4  in_degree_750  1
    arc_0_2_4  original_T_including_depot_unload_807  6.1561452832791758e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_4  arc_capacity_478  1
    load_0_2_4  segment_load_conservation_739  1
    load_0_2_4  segment_load_conservation_753  -1
    load_0_2_4  segment_prefix_lb_754  1
    load_0_2_4  segment_prefix_ub_755  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_12  arc_capacity_480  -20
    arc_0_2_12  connected_order_arc_481  -13
    arc_0_2_12  out_degree_735  1
    arc_0_2_12  in_degree_757  1
    arc_0_2_12  original_T_including_depot_unload_807  1.5892857916507662e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_12  arc_capacity_480  1
    load_0_2_12  segment_load_conservation_739  1
    load_0_2_12  free_load_conservation_761  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_13  arc_capacity_482  -20
    arc_0_2_13  connected_order_arc_483  -13
    arc_0_2_13  out_degree_735  1
    arc_0_2_13  in_degree_763  1
    arc_0_2_13  original_T_including_depot_unload_807  1.7520337176349503e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_13  arc_capacity_482  1
    load_0_2_13  segment_load_conservation_739  1
    load_0_2_13  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_14  arc_capacity_484  -20
    arc_0_2_14  connected_order_arc_485  -13
    arc_0_2_14  out_degree_735  1
    arc_0_2_14  in_degree_769  1
    arc_0_2_14  original_T_including_depot_unload_807  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_14  arc_capacity_484  1
    load_0_2_14  segment_load_conservation_739  1
    load_0_2_14  free_load_conservation_773  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_15  arc_capacity_486  -20
    arc_0_2_15  connected_order_arc_487  -13
    arc_0_2_15  out_degree_735  1
    arc_0_2_15  in_degree_775  1
    arc_0_2_15  original_T_including_depot_unload_807  1.5546511874277910e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_15  arc_capacity_486  1
    load_0_2_15  segment_load_conservation_739  1
    load_0_2_15  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_16  arc_capacity_488  -20
    arc_0_2_16  connected_order_arc_489  -13
    arc_0_2_16  out_degree_735  1
    arc_0_2_16  in_degree_781  1
    arc_0_2_16  original_T_including_depot_unload_807  2.4111148152767828e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_16  arc_capacity_488  1
    load_0_2_16  segment_load_conservation_739  1
    load_0_2_16  free_load_conservation_785  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_17  arc_capacity_490  -20
    arc_0_2_17  connected_order_arc_491  -13
    arc_0_2_17  out_degree_735  1
    arc_0_2_17  in_degree_787  1
    arc_0_2_17  original_T_including_depot_unload_807  1.6631507094436240e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_17  arc_capacity_490  1
    load_0_2_17  segment_load_conservation_739  1
    load_0_2_17  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_18  arc_capacity_492  -20
    arc_0_2_18  connected_order_arc_493  -13
    arc_0_2_18  out_degree_735  1
    arc_0_2_18  in_degree_793  1
    arc_0_2_18  original_T_including_depot_unload_807  3.9864800790786632e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_18  arc_capacity_492  1
    load_0_2_18  segment_load_conservation_739  1
    load_0_2_18  free_load_conservation_797  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_19  arc_capacity_494  -20
    arc_0_2_19  connected_order_arc_495  -13
    arc_0_2_19  out_degree_735  1
    arc_0_2_19  in_degree_799  1
    arc_0_2_19  original_T_including_depot_unload_807  8.3393751072629220e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_19  arc_capacity_494  1
    load_0_2_19  segment_load_conservation_739  1
    load_0_2_19  free_load_conservation_803  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_0  arc_capacity_496  -20
    arc_0_3_0  depot_return_or_bypass_727  1
    arc_0_3_0  out_degree_742  1
    arc_0_3_0  original_T_including_depot_unload_807  6.6653528395596720e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_0  arc_capacity_496  1
    load_0_3_0  segment_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_1  arc_capacity_497  -20
    arc_0_3_1  connected_order_arc_498  -13
    arc_0_3_1  in_degree_729  1
    arc_0_3_1  out_degree_742  1
    arc_0_3_1  original_T_including_depot_unload_807  628.141943094385
    MARKER    'MARKER'                 'INTEND'
    load_0_3_1  arc_capacity_497  1
    load_0_3_1  segment_load_conservation_732  -1
    load_0_3_1  segment_prefix_lb_733  1
    load_0_3_1  segment_prefix_ub_734  1
    load_0_3_1  segment_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_2  arc_capacity_499  -20
    arc_0_3_2  connected_order_arc_500  -13
    arc_0_3_2  in_degree_736  1
    arc_0_3_2  out_degree_742  1
    arc_0_3_2  original_T_including_depot_unload_807  3.1069481377857926e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_2  arc_capacity_499  1
    load_0_3_2  segment_load_conservation_739  -1
    load_0_3_2  segment_prefix_lb_740  1
    load_0_3_2  segment_prefix_ub_741  1
    load_0_3_2  segment_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_4  arc_capacity_501  -20
    arc_0_3_4  connected_order_arc_502  -13
    arc_0_3_4  out_degree_742  1
    arc_0_3_4  in_degree_750  1
    arc_0_3_4  original_T_including_depot_unload_807  3.2985327387120213e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_4  arc_capacity_501  1
    load_0_3_4  segment_load_conservation_746  1
    load_0_3_4  segment_load_conservation_753  -1
    load_0_3_4  segment_prefix_lb_754  1
    load_0_3_4  segment_prefix_ub_755  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_12  arc_capacity_503  -20
    arc_0_3_12  connected_order_arc_504  -13
    arc_0_3_12  out_degree_742  1
    arc_0_3_12  in_degree_757  1
    arc_0_3_12  original_T_including_depot_unload_807  1.5053327747786273e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_12  arc_capacity_503  1
    load_0_3_12  segment_load_conservation_746  1
    load_0_3_12  free_load_conservation_761  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_13  arc_capacity_505  -20
    arc_0_3_13  connected_order_arc_506  -13
    arc_0_3_13  out_degree_742  1
    arc_0_3_13  in_degree_763  1
    arc_0_3_13  original_T_including_depot_unload_807  1.6982456083268751e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_13  arc_capacity_505  1
    load_0_3_13  segment_load_conservation_746  1
    load_0_3_13  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_14  arc_capacity_507  -20
    arc_0_3_14  connected_order_arc_508  -13
    arc_0_3_14  out_degree_742  1
    arc_0_3_14  in_degree_769  1
    arc_0_3_14  original_T_including_depot_unload_807  1.6292966848558842e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_14  arc_capacity_507  1
    load_0_3_14  segment_load_conservation_746  1
    load_0_3_14  free_load_conservation_773  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_15  arc_capacity_509  -20
    arc_0_3_15  connected_order_arc_510  -13
    arc_0_3_15  out_degree_742  1
    arc_0_3_15  in_degree_775  1
    arc_0_3_15  original_T_including_depot_unload_807  1.5437191441012344e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_15  arc_capacity_509  1
    load_0_3_15  segment_load_conservation_746  1
    load_0_3_15  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_16  arc_capacity_511  -20
    arc_0_3_16  connected_order_arc_512  -13
    arc_0_3_16  out_degree_742  1
    arc_0_3_16  in_degree_781  1
    arc_0_3_16  original_T_including_depot_unload_807  2.3649901674897566e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_16  arc_capacity_511  1
    load_0_3_16  segment_load_conservation_746  1
    load_0_3_16  free_load_conservation_785  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_17  arc_capacity_513  -20
    arc_0_3_17  connected_order_arc_514  -13
    arc_0_3_17  out_degree_742  1
    arc_0_3_17  in_degree_787  1
    arc_0_3_17  original_T_including_depot_unload_807  1.6744862285014353e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_17  arc_capacity_513  1
    load_0_3_17  segment_load_conservation_746  1
    load_0_3_17  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_18  arc_capacity_515  -20
    arc_0_3_18  connected_order_arc_516  -13
    arc_0_3_18  out_degree_742  1
    arc_0_3_18  in_degree_793  1
    arc_0_3_18  original_T_including_depot_unload_807  2.5147997402163108e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_18  arc_capacity_515  1
    load_0_3_18  segment_load_conservation_746  1
    load_0_3_18  free_load_conservation_797  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_19  arc_capacity_517  -20
    arc_0_3_19  connected_order_arc_518  -13
    arc_0_3_19  out_degree_742  1
    arc_0_3_19  in_degree_799  1
    arc_0_3_19  original_T_including_depot_unload_807  7.8830763320343567e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_19  arc_capacity_517  1
    load_0_3_19  segment_load_conservation_746  1
    load_0_3_19  free_load_conservation_803  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_0  arc_capacity_519  -20
    arc_0_4_0  depot_return_or_bypass_727  1
    arc_0_4_0  out_degree_749  1
    arc_0_4_0  original_T_including_depot_unload_807  4.6364706268001146e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_0  arc_capacity_519  1
    load_0_4_0  segment_load_conservation_753  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_1  arc_capacity_520  -20
    arc_0_4_1  connected_order_arc_521  -13
    arc_0_4_1  in_degree_729  1
    arc_0_4_1  out_degree_749  1
    arc_0_4_1  original_T_including_depot_unload_807  6.7517249538835438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_1  arc_capacity_520  1
    load_0_4_1  segment_load_conservation_732  -1
    load_0_4_1  segment_prefix_lb_733  1
    load_0_4_1  segment_prefix_ub_734  1
    load_0_4_1  segment_load_conservation_753  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_2  arc_capacity_522  -20
    arc_0_4_2  connected_order_arc_523  -13
    arc_0_4_2  in_degree_736  1
    arc_0_4_2  out_degree_749  1
    arc_0_4_2  original_T_including_depot_unload_807  8.1289340937717509e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_2  arc_capacity_522  1
    load_0_4_2  segment_load_conservation_739  -1
    load_0_4_2  segment_prefix_lb_740  1
    load_0_4_2  segment_prefix_ub_741  1
    load_0_4_2  segment_load_conservation_753  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_3  arc_capacity_524  -20
    arc_0_4_3  connected_order_arc_525  -13
    arc_0_4_3  in_degree_743  1
    arc_0_4_3  out_degree_749  1
    arc_0_4_3  original_T_including_depot_unload_807  5.8442598457899078e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_3  arc_capacity_524  1
    load_0_4_3  segment_load_conservation_746  -1
    load_0_4_3  segment_prefix_lb_747  1
    load_0_4_3  segment_prefix_ub_748  1
    load_0_4_3  segment_load_conservation_753  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_12  arc_capacity_526  -20
    arc_0_4_12  connected_order_arc_527  -13
    arc_0_4_12  out_degree_749  1
    arc_0_4_12  in_degree_757  1
    arc_0_4_12  original_T_including_depot_unload_807  1.0250717569202773e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_12  arc_capacity_526  1
    load_0_4_12  segment_load_conservation_753  1
    load_0_4_12  free_load_conservation_761  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_13  arc_capacity_528  -20
    arc_0_4_13  connected_order_arc_529  -13
    arc_0_4_13  out_degree_749  1
    arc_0_4_13  in_degree_763  1
    arc_0_4_13  original_T_including_depot_unload_807  1.2492199513695298e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_13  arc_capacity_528  1
    load_0_4_13  segment_load_conservation_753  1
    load_0_4_13  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_14  arc_capacity_530  -20
    arc_0_4_14  connected_order_arc_531  -13
    arc_0_4_14  out_degree_749  1
    arc_0_4_14  in_degree_769  1
    arc_0_4_14  original_T_including_depot_unload_807  1075.72043838369
    MARKER    'MARKER'                 'INTEND'
    load_0_4_14  arc_capacity_530  1
    load_0_4_14  segment_load_conservation_753  1
    load_0_4_14  free_load_conservation_773  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_15  arc_capacity_532  -20
    arc_0_4_15  connected_order_arc_533  -13
    arc_0_4_15  out_degree_749  1
    arc_0_4_15  in_degree_775  1
    arc_0_4_15  original_T_including_depot_unload_807  1.1724800521319269e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_15  arc_capacity_532  1
    load_0_4_15  segment_load_conservation_753  1
    load_0_4_15  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_16  arc_capacity_534  -20
    arc_0_4_16  connected_order_arc_535  -13
    arc_0_4_16  out_degree_749  1
    arc_0_4_16  in_degree_781  1
    arc_0_4_16  original_T_including_depot_unload_807  5.8212369880329140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_16  arc_capacity_534  1
    load_0_4_16  segment_load_conservation_753  1
    load_0_4_16  free_load_conservation_785  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_17  arc_capacity_536  -20
    arc_0_4_17  connected_order_arc_537  -13
    arc_0_4_17  out_degree_749  1
    arc_0_4_17  in_degree_787  1
    arc_0_4_17  original_T_including_depot_unload_807  1.3294477435531232e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_17  arc_capacity_536  1
    load_0_4_17  segment_load_conservation_753  1
    load_0_4_17  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_18  arc_capacity_538  -20
    arc_0_4_18  connected_order_arc_539  -13
    arc_0_4_18  out_degree_749  1
    arc_0_4_18  in_degree_793  1
    arc_0_4_18  original_T_including_depot_unload_807  4.1665889045115779e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_18  arc_capacity_538  1
    load_0_4_18  segment_load_conservation_753  1
    load_0_4_18  free_load_conservation_797  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_19  arc_capacity_540  -20
    arc_0_4_19  connected_order_arc_541  -13
    arc_0_4_19  out_degree_749  1
    arc_0_4_19  in_degree_799  1
    arc_0_4_19  original_T_including_depot_unload_807  5.1177250003741761e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_19  arc_capacity_540  1
    load_0_4_19  segment_load_conservation_753  1
    load_0_4_19  free_load_conservation_803  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_0  arc_capacity_542  -20
    arc_0_12_0  depot_return_or_bypass_727  1
    arc_0_12_0  out_degree_756  1
    arc_0_12_0  original_T_including_depot_unload_807  8.7918533905669346e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_0  arc_capacity_542  1
    load_0_12_0  free_load_conservation_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_1  arc_capacity_543  -20
    arc_0_12_1  connected_order_arc_544  -13
    arc_0_12_1  in_degree_729  1
    arc_0_12_1  out_degree_756  1
    arc_0_12_1  original_T_including_depot_unload_807  1.0988088346747072e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_1  arc_capacity_543  1
    load_0_12_1  segment_load_conservation_732  -1
    load_0_12_1  segment_prefix_lb_733  1
    load_0_12_1  segment_prefix_ub_734  1
    load_0_12_1  free_load_conservation_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_2  arc_capacity_545  -20
    arc_0_12_2  connected_order_arc_546  -13
    arc_0_12_2  in_degree_736  1
    arc_0_12_2  out_degree_756  1
    arc_0_12_2  original_T_including_depot_unload_807  1.5892857916507662e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_2  arc_capacity_545  1
    load_0_12_2  segment_load_conservation_739  -1
    load_0_12_2  segment_prefix_lb_740  1
    load_0_12_2  segment_prefix_ub_741  1
    load_0_12_2  free_load_conservation_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_3  arc_capacity_547  -20
    arc_0_12_3  connected_order_arc_548  -13
    arc_0_12_3  in_degree_743  1
    arc_0_12_3  out_degree_756  1
    arc_0_12_3  original_T_including_depot_unload_807  1.5053327747786273e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_3  arc_capacity_547  1
    load_0_12_3  segment_load_conservation_746  -1
    load_0_12_3  segment_prefix_lb_747  1
    load_0_12_3  segment_prefix_ub_748  1
    load_0_12_3  free_load_conservation_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_4  arc_capacity_549  -20
    arc_0_12_4  connected_order_arc_550  -13
    arc_0_12_4  in_degree_750  1
    arc_0_12_4  out_degree_756  1
    arc_0_12_4  original_T_including_depot_unload_807  1.3070841601346692e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_4  arc_capacity_549  1
    load_0_12_4  segment_load_conservation_753  -1
    load_0_12_4  segment_prefix_lb_754  1
    load_0_12_4  segment_prefix_ub_755  1
    load_0_12_4  free_load_conservation_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_13  arc_capacity_551  -20
    arc_0_12_13  connected_order_arc_552  -13
    arc_0_12_13  out_degree_756  1
    arc_0_12_13  in_degree_763  1
    arc_0_12_13  original_T_including_depot_unload_807  2.4155873404211835e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_13  arc_capacity_551  1
    load_0_12_13  free_load_conservation_761  1
    load_0_12_13  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_14  arc_capacity_553  -20
    arc_0_12_14  connected_order_arc_554  -13
    arc_0_12_14  out_degree_756  1
    arc_0_12_14  in_degree_769  1
    arc_0_12_14  original_T_including_depot_unload_807  3.6824909986567474e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_14  arc_capacity_553  1
    load_0_12_14  free_load_conservation_761  1
    load_0_12_14  free_load_conservation_773  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_15  arc_capacity_555  -20
    arc_0_12_15  connected_order_arc_556  -13
    arc_0_12_15  out_degree_756  1
    arc_0_12_15  in_degree_775  1
    arc_0_12_15  original_T_including_depot_unload_807  3.6821827312741834e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_15  arc_capacity_555  1
    load_0_12_15  free_load_conservation_761  1
    load_0_12_15  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_16  arc_capacity_557  -20
    arc_0_12_16  connected_order_arc_558  -13
    arc_0_12_16  out_degree_756  1
    arc_0_12_16  in_degree_781  1
    arc_0_12_16  original_T_including_depot_unload_807  1.3653307388496069e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_16  arc_capacity_557  1
    load_0_12_16  free_load_conservation_761  1
    load_0_12_16  free_load_conservation_785  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_17  arc_capacity_559  -20
    arc_0_12_17  connected_order_arc_560  -13
    arc_0_12_17  out_degree_756  1
    arc_0_12_17  in_degree_787  1
    arc_0_12_17  original_T_including_depot_unload_807  5.1107432522690152e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_17  arc_capacity_559  1
    load_0_12_17  free_load_conservation_761  1
    load_0_12_17  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_18  arc_capacity_561  -20
    arc_0_12_18  connected_order_arc_562  -13
    arc_0_12_18  out_degree_756  1
    arc_0_12_18  in_degree_793  1
    arc_0_12_18  original_T_including_depot_unload_807  1.2587701383314870e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_18  arc_capacity_561  1
    load_0_12_18  free_load_conservation_761  1
    load_0_12_18  free_load_conservation_797  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_19  arc_capacity_563  -20
    arc_0_12_19  connected_order_arc_564  -13
    arc_0_12_19  out_degree_756  1
    arc_0_12_19  in_degree_799  1
    arc_0_12_19  original_T_including_depot_unload_807  7.5634788469878674e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_19  arc_capacity_563  1
    load_0_12_19  free_load_conservation_761  1
    load_0_12_19  free_load_conservation_803  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_0  arc_capacity_565  -20
    arc_0_13_0  depot_return_or_bypass_727  1
    arc_0_13_0  out_degree_762  1
    arc_0_13_0  original_T_including_depot_unload_807  1.0479182987243917e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_0  arc_capacity_565  1
    load_0_13_0  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_1  arc_capacity_566  -20
    arc_0_13_1  connected_order_arc_567  -13
    arc_0_13_1  in_degree_729  1
    arc_0_13_1  out_degree_762  1
    arc_0_13_1  original_T_including_depot_unload_807  1.2336637947519732e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_1  arc_capacity_566  1
    load_0_13_1  segment_load_conservation_732  -1
    load_0_13_1  segment_prefix_lb_733  1
    load_0_13_1  segment_prefix_ub_734  1
    load_0_13_1  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_2  arc_capacity_568  -20
    arc_0_13_2  connected_order_arc_569  -13
    arc_0_13_2  in_degree_736  1
    arc_0_13_2  out_degree_762  1
    arc_0_13_2  original_T_including_depot_unload_807  1.7520337176349503e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_2  arc_capacity_568  1
    load_0_13_2  segment_load_conservation_739  -1
    load_0_13_2  segment_prefix_lb_740  1
    load_0_13_2  segment_prefix_ub_741  1
    load_0_13_2  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_3  arc_capacity_570  -20
    arc_0_13_3  connected_order_arc_571  -13
    arc_0_13_3  in_degree_743  1
    arc_0_13_3  out_degree_762  1
    arc_0_13_3  original_T_including_depot_unload_807  1.6982456083268751e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_3  arc_capacity_570  1
    load_0_13_3  segment_load_conservation_746  -1
    load_0_13_3  segment_prefix_lb_747  1
    load_0_13_3  segment_prefix_ub_748  1
    load_0_13_3  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_4  arc_capacity_572  -20
    arc_0_13_4  connected_order_arc_573  -13
    arc_0_13_4  in_degree_750  1
    arc_0_13_4  out_degree_762  1
    arc_0_13_4  original_T_including_depot_unload_807  1.5230377993795889e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_4  arc_capacity_572  1
    load_0_13_4  segment_load_conservation_753  -1
    load_0_13_4  segment_prefix_lb_754  1
    load_0_13_4  segment_prefix_ub_755  1
    load_0_13_4  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_12  arc_capacity_574  -20
    arc_0_13_12  connected_order_arc_575  -13
    arc_0_13_12  in_degree_757  1
    arc_0_13_12  out_degree_762  1
    arc_0_13_12  original_T_including_depot_unload_807  2.4155873404211835e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_12  arc_capacity_574  1
    load_0_13_12  free_load_conservation_761  -1
    load_0_13_12  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_14  arc_capacity_576  -20
    arc_0_13_14  connected_order_arc_577  -13
    arc_0_13_14  out_degree_762  1
    arc_0_13_14  in_degree_769  1
    arc_0_13_14  original_T_including_depot_unload_807  5.2280951376932137e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_14  arc_capacity_576  1
    load_0_13_14  free_load_conservation_767  1
    load_0_13_14  free_load_conservation_773  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_15  arc_capacity_578  -20
    arc_0_13_15  connected_order_arc_579  -13
    arc_0_13_15  out_degree_762  1
    arc_0_13_15  in_degree_775  1
    arc_0_13_15  original_T_including_depot_unload_807  2.8747557636937808e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_15  arc_capacity_578  1
    load_0_13_15  free_load_conservation_767  1
    load_0_13_15  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_16  arc_capacity_580  -20
    arc_0_13_16  connected_order_arc_581  -13
    arc_0_13_16  out_degree_762  1
    arc_0_13_16  in_degree_781  1
    arc_0_13_16  original_T_including_depot_unload_807  1.5393904884690303e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_16  arc_capacity_580  1
    load_0_13_16  free_load_conservation_767  1
    load_0_13_16  free_load_conservation_785  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_17  arc_capacity_582  -20
    arc_0_13_17  connected_order_arc_583  -13
    arc_0_13_17  out_degree_762  1
    arc_0_13_17  in_degree_787  1
    arc_0_13_17  original_T_including_depot_unload_807  3.6094216796124527e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_17  arc_capacity_582  1
    load_0_13_17  free_load_conservation_767  1
    load_0_13_17  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_18  arc_capacity_584  -20
    arc_0_13_18  connected_order_arc_585  -13
    arc_0_13_18  out_degree_762  1
    arc_0_13_18  in_degree_793  1
    arc_0_13_18  original_T_including_depot_unload_807  1.4479585101303876e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_18  arc_capacity_584  1
    load_0_13_18  free_load_conservation_767  1
    load_0_13_18  free_load_conservation_797  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_19  arc_capacity_586  -20
    arc_0_13_19  connected_order_arc_587  -13
    arc_0_13_19  out_degree_762  1
    arc_0_13_19  in_degree_799  1
    arc_0_13_19  original_T_including_depot_unload_807  9.2235470209829464e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_19  arc_capacity_586  1
    load_0_13_19  free_load_conservation_767  1
    load_0_13_19  free_load_conservation_803  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_0  arc_capacity_588  -20
    arc_0_14_0  depot_return_or_bypass_727  1
    arc_0_14_0  out_degree_768  1
    arc_0_14_0  original_T_including_depot_unload_807  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_0  arc_capacity_588  1
    load_0_14_0  free_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_1  arc_capacity_589  -20
    arc_0_14_1  connected_order_arc_590  -13
    arc_0_14_1  in_degree_729  1
    arc_0_14_1  out_degree_768  1
    arc_0_14_1  original_T_including_depot_unload_807  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_1  arc_capacity_589  1
    load_0_14_1  segment_load_conservation_732  -1
    load_0_14_1  segment_prefix_lb_733  1
    load_0_14_1  segment_prefix_ub_734  1
    load_0_14_1  free_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_2  arc_capacity_591  -20
    arc_0_14_2  connected_order_arc_592  -13
    arc_0_14_2  in_degree_736  1
    arc_0_14_2  out_degree_768  1
    arc_0_14_2  original_T_including_depot_unload_807  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_2  arc_capacity_591  1
    load_0_14_2  segment_load_conservation_739  -1
    load_0_14_2  segment_prefix_lb_740  1
    load_0_14_2  segment_prefix_ub_741  1
    load_0_14_2  free_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_3  arc_capacity_593  -20
    arc_0_14_3  connected_order_arc_594  -13
    arc_0_14_3  in_degree_743  1
    arc_0_14_3  out_degree_768  1
    arc_0_14_3  original_T_including_depot_unload_807  1.6292966848558842e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_3  arc_capacity_593  1
    load_0_14_3  segment_load_conservation_746  -1
    load_0_14_3  segment_prefix_lb_747  1
    load_0_14_3  segment_prefix_ub_748  1
    load_0_14_3  free_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_4  arc_capacity_595  -20
    arc_0_14_4  connected_order_arc_596  -13
    arc_0_14_4  in_degree_750  1
    arc_0_14_4  out_degree_768  1
    arc_0_14_4  original_T_including_depot_unload_807  1.3727638439182763e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_4  arc_capacity_595  1
    load_0_14_4  segment_load_conservation_753  -1
    load_0_14_4  segment_prefix_lb_754  1
    load_0_14_4  segment_prefix_ub_755  1
    load_0_14_4  free_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_12  arc_capacity_597  -20
    arc_0_14_12  connected_order_arc_598  -13
    arc_0_14_12  in_degree_757  1
    arc_0_14_12  out_degree_768  1
    arc_0_14_12  original_T_including_depot_unload_807  3.6824909986567474e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_12  arc_capacity_597  1
    load_0_14_12  free_load_conservation_761  -1
    load_0_14_12  free_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_13  arc_capacity_599  -20
    arc_0_14_13  connected_order_arc_600  -13
    arc_0_14_13  in_degree_763  1
    arc_0_14_13  out_degree_768  1
    arc_0_14_13  original_T_including_depot_unload_807  5.2280951376932137e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_13  arc_capacity_599  1
    load_0_14_13  free_load_conservation_767  -1
    load_0_14_13  free_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_15  arc_capacity_601  -20
    arc_0_14_15  connected_order_arc_602  -13
    arc_0_14_15  out_degree_768  1
    arc_0_14_15  in_degree_775  1
    arc_0_14_15  original_T_including_depot_unload_807  7.3227602527872671e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_15  arc_capacity_601  1
    load_0_14_15  free_load_conservation_773  1
    load_0_14_15  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_16  arc_capacity_603  -20
    arc_0_14_16  connected_order_arc_604  -13
    arc_0_14_16  out_degree_768  1
    arc_0_14_16  in_degree_781  1
    arc_0_14_16  original_T_including_depot_unload_807  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_16  arc_capacity_603  1
    load_0_14_16  free_load_conservation_773  1
    load_0_14_16  free_load_conservation_785  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_17  arc_capacity_605  -20
    arc_0_14_17  connected_order_arc_606  -13
    arc_0_14_17  out_degree_768  1
    arc_0_14_17  in_degree_787  1
    arc_0_14_17  original_T_including_depot_unload_807  861.314419336229
    MARKER    'MARKER'                 'INTEND'
    load_0_14_17  arc_capacity_605  1
    load_0_14_17  free_load_conservation_773  1
    load_0_14_17  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_18  arc_capacity_607  -20
    arc_0_14_18  connected_order_arc_608  -13
    arc_0_14_18  out_degree_768  1
    arc_0_14_18  in_degree_793  1
    arc_0_14_18  original_T_including_depot_unload_807  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_18  arc_capacity_607  1
    load_0_14_18  free_load_conservation_773  1
    load_0_14_18  free_load_conservation_797  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_19  arc_capacity_609  -20
    arc_0_14_19  connected_order_arc_610  -13
    arc_0_14_19  out_degree_768  1
    arc_0_14_19  in_degree_799  1
    arc_0_14_19  original_T_including_depot_unload_807  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_19  arc_capacity_609  1
    load_0_14_19  free_load_conservation_773  1
    load_0_14_19  free_load_conservation_803  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_0  arc_capacity_611  -20
    arc_0_15_0  depot_return_or_bypass_727  1
    arc_0_15_0  out_degree_774  1
    arc_0_15_0  original_T_including_depot_unload_807  8.7749189782983967e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_0  arc_capacity_611  1
    load_0_15_0  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_1  arc_capacity_612  -20
    arc_0_15_1  connected_order_arc_613  -13
    arc_0_15_1  in_degree_729  1
    arc_0_15_1  out_degree_774  1
    arc_0_15_1  original_T_including_depot_unload_807  1.0170488276971105e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_1  arc_capacity_612  1
    load_0_15_1  segment_load_conservation_732  -1
    load_0_15_1  segment_prefix_lb_733  1
    load_0_15_1  segment_prefix_ub_734  1
    load_0_15_1  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_2  arc_capacity_614  -20
    arc_0_15_2  connected_order_arc_615  -13
    arc_0_15_2  in_degree_736  1
    arc_0_15_2  out_degree_774  1
    arc_0_15_2  original_T_including_depot_unload_807  1.5546511874277910e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_2  arc_capacity_614  1
    load_0_15_2  segment_load_conservation_739  -1
    load_0_15_2  segment_prefix_lb_740  1
    load_0_15_2  segment_prefix_ub_741  1
    load_0_15_2  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_3  arc_capacity_616  -20
    arc_0_15_3  connected_order_arc_617  -13
    arc_0_15_3  in_degree_743  1
    arc_0_15_3  out_degree_774  1
    arc_0_15_3  original_T_including_depot_unload_807  1.5437191441012344e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_3  arc_capacity_616  1
    load_0_15_3  segment_load_conservation_746  -1
    load_0_15_3  segment_prefix_lb_747  1
    load_0_15_3  segment_prefix_ub_748  1
    load_0_15_3  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_4  arc_capacity_618  -20
    arc_0_15_4  connected_order_arc_619  -13
    arc_0_15_4  in_degree_750  1
    arc_0_15_4  out_degree_774  1
    arc_0_15_4  original_T_including_depot_unload_807  1.4171530684324468e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_4  arc_capacity_618  1
    load_0_15_4  segment_load_conservation_753  -1
    load_0_15_4  segment_prefix_lb_754  1
    load_0_15_4  segment_prefix_ub_755  1
    load_0_15_4  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_12  arc_capacity_620  -20
    arc_0_15_12  connected_order_arc_621  -13
    arc_0_15_12  in_degree_757  1
    arc_0_15_12  out_degree_774  1
    arc_0_15_12  original_T_including_depot_unload_807  3.6821827312741834e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_12  arc_capacity_620  1
    load_0_15_12  free_load_conservation_761  -1
    load_0_15_12  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_13  arc_capacity_622  -20
    arc_0_15_13  connected_order_arc_623  -13
    arc_0_15_13  in_degree_763  1
    arc_0_15_13  out_degree_774  1
    arc_0_15_13  original_T_including_depot_unload_807  2.8747557636937808e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_13  arc_capacity_622  1
    load_0_15_13  free_load_conservation_767  -1
    load_0_15_13  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_14  arc_capacity_624  -20
    arc_0_15_14  connected_order_arc_625  -13
    arc_0_15_14  in_degree_769  1
    arc_0_15_14  out_degree_774  1
    arc_0_15_14  original_T_including_depot_unload_807  7.3227602527872671e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_14  arc_capacity_624  1
    load_0_15_14  free_load_conservation_773  -1
    load_0_15_14  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_16  arc_capacity_626  -20
    arc_0_15_16  connected_order_arc_627  -13
    arc_0_15_16  out_degree_774  1
    arc_0_15_16  in_degree_781  1
    arc_0_15_16  original_T_including_depot_unload_807  1.3600272346134373e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_16  arc_capacity_626  1
    load_0_15_16  free_load_conservation_779  1
    load_0_15_16  free_load_conservation_785  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_17  arc_capacity_628  -20
    arc_0_15_17  connected_order_arc_629  -13
    arc_0_15_17  out_degree_774  1
    arc_0_15_17  in_degree_787  1
    arc_0_15_17  original_T_including_depot_unload_807  1.6651295535886251e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_17  arc_capacity_628  1
    load_0_15_17  free_load_conservation_779  1
    load_0_15_17  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_18  arc_capacity_630  -20
    arc_0_15_18  connected_order_arc_631  -13
    arc_0_15_18  out_degree_774  1
    arc_0_15_18  in_degree_793  1
    arc_0_15_18  original_T_including_depot_unload_807  1.2927779971523576e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_18  arc_capacity_630  1
    load_0_15_18  free_load_conservation_779  1
    load_0_15_18  free_load_conservation_797  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_19  arc_capacity_632  -20
    arc_0_15_19  connected_order_arc_633  -13
    arc_0_15_19  out_degree_774  1
    arc_0_15_19  in_degree_799  1
    arc_0_15_19  original_T_including_depot_unload_807  7.5571464781430223e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_19  arc_capacity_632  1
    load_0_15_19  free_load_conservation_779  1
    load_0_15_19  free_load_conservation_803  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_0  arc_capacity_634  -20
    arc_0_16_0  depot_return_or_bypass_727  1
    arc_0_16_0  out_degree_780  1
    arc_0_16_0  original_T_including_depot_unload_807  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_0  arc_capacity_634  1
    load_0_16_0  free_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_1  arc_capacity_635  -20
    arc_0_16_1  connected_order_arc_636  -13
    arc_0_16_1  in_degree_729  1
    arc_0_16_1  out_degree_780  1
    arc_0_16_1  original_T_including_depot_unload_807  3.9758967496529505e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_1  arc_capacity_635  1
    load_0_16_1  segment_load_conservation_732  -1
    load_0_16_1  segment_prefix_lb_733  1
    load_0_16_1  segment_prefix_ub_734  1
    load_0_16_1  free_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_2  arc_capacity_637  -20
    arc_0_16_2  connected_order_arc_638  -13
    arc_0_16_2  in_degree_736  1
    arc_0_16_2  out_degree_780  1
    arc_0_16_2  original_T_including_depot_unload_807  2.4111148152767828e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_2  arc_capacity_637  1
    load_0_16_2  segment_load_conservation_739  -1
    load_0_16_2  segment_prefix_lb_740  1
    load_0_16_2  segment_prefix_ub_741  1
    load_0_16_2  free_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_3  arc_capacity_639  -20
    arc_0_16_3  connected_order_arc_640  -13
    arc_0_16_3  in_degree_743  1
    arc_0_16_3  out_degree_780  1
    arc_0_16_3  original_T_including_depot_unload_807  2.3649901674897566e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_3  arc_capacity_639  1
    load_0_16_3  segment_load_conservation_746  -1
    load_0_16_3  segment_prefix_lb_747  1
    load_0_16_3  segment_prefix_ub_748  1
    load_0_16_3  free_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_4  arc_capacity_641  -20
    arc_0_16_4  connected_order_arc_642  -13
    arc_0_16_4  in_degree_750  1
    arc_0_16_4  out_degree_780  1
    arc_0_16_4  original_T_including_depot_unload_807  4.3129452098285111e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_4  arc_capacity_641  1
    load_0_16_4  segment_load_conservation_753  -1
    load_0_16_4  segment_prefix_lb_754  1
    load_0_16_4  segment_prefix_ub_755  1
    load_0_16_4  free_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_12  arc_capacity_643  -20
    arc_0_16_12  connected_order_arc_644  -13
    arc_0_16_12  in_degree_757  1
    arc_0_16_12  out_degree_780  1
    arc_0_16_12  original_T_including_depot_unload_807  1.3653307388496069e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_12  arc_capacity_643  1
    load_0_16_12  free_load_conservation_761  -1
    load_0_16_12  free_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_13  arc_capacity_645  -20
    arc_0_16_13  connected_order_arc_646  -13
    arc_0_16_13  in_degree_763  1
    arc_0_16_13  out_degree_780  1
    arc_0_16_13  original_T_including_depot_unload_807  1.5393904884690303e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_13  arc_capacity_645  1
    load_0_16_13  free_load_conservation_767  -1
    load_0_16_13  free_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_14  arc_capacity_647  -20
    arc_0_16_14  connected_order_arc_648  -13
    arc_0_16_14  in_degree_769  1
    arc_0_16_14  out_degree_780  1
    arc_0_16_14  original_T_including_depot_unload_807  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_14  arc_capacity_647  1
    load_0_16_14  free_load_conservation_773  -1
    load_0_16_14  free_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_15  arc_capacity_649  -20
    arc_0_16_15  connected_order_arc_650  -13
    arc_0_16_15  in_degree_775  1
    arc_0_16_15  out_degree_780  1
    arc_0_16_15  original_T_including_depot_unload_807  1.3600272346134373e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_15  arc_capacity_649  1
    load_0_16_15  free_load_conservation_779  -1
    load_0_16_15  free_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_17  arc_capacity_651  -20
    arc_0_16_17  connected_order_arc_652  -13
    arc_0_16_17  out_degree_780  1
    arc_0_16_17  in_degree_787  1
    arc_0_16_17  original_T_including_depot_unload_807  1.4805184908215606e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_17  arc_capacity_651  1
    load_0_16_17  free_load_conservation_785  1
    load_0_16_17  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_18  arc_capacity_653  -20
    arc_0_16_18  connected_order_arc_654  -13
    arc_0_16_18  out_degree_780  1
    arc_0_16_18  in_degree_793  1
    arc_0_16_18  original_T_including_depot_unload_807  1.6597164064313077e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_18  arc_capacity_653  1
    load_0_16_18  free_load_conservation_785  1
    load_0_16_18  free_load_conservation_797  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_19  arc_capacity_655  -20
    arc_0_16_19  connected_order_arc_656  -13
    arc_0_16_19  out_degree_780  1
    arc_0_16_19  in_degree_799  1
    arc_0_16_19  original_T_including_depot_unload_807  6.1704611580490348e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_19  arc_capacity_655  1
    load_0_16_19  free_load_conservation_785  1
    load_0_16_19  free_load_conservation_803  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_0  arc_capacity_657  -20
    arc_0_17_0  depot_return_or_bypass_727  1
    arc_0_17_0  out_degree_786  1
    arc_0_17_0  original_T_including_depot_unload_807  1.0088905112952611e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_0  arc_capacity_657  1
    load_0_17_0  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_1  arc_capacity_658  -20
    arc_0_17_1  connected_order_arc_659  -13
    arc_0_17_1  in_degree_729  1
    arc_0_17_1  out_degree_786  1
    arc_0_17_1  original_T_including_depot_unload_807  1.1190931627527086e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_1  arc_capacity_658  1
    load_0_17_1  segment_load_conservation_732  -1
    load_0_17_1  segment_prefix_lb_733  1
    load_0_17_1  segment_prefix_ub_734  1
    load_0_17_1  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_2  arc_capacity_660  -20
    arc_0_17_2  connected_order_arc_661  -13
    arc_0_17_2  in_degree_736  1
    arc_0_17_2  out_degree_786  1
    arc_0_17_2  original_T_including_depot_unload_807  1.6631507094436240e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_2  arc_capacity_660  1
    load_0_17_2  segment_load_conservation_739  -1
    load_0_17_2  segment_prefix_lb_740  1
    load_0_17_2  segment_prefix_ub_741  1
    load_0_17_2  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_3  arc_capacity_662  -20
    arc_0_17_3  connected_order_arc_663  -13
    arc_0_17_3  in_degree_743  1
    arc_0_17_3  out_degree_786  1
    arc_0_17_3  original_T_including_depot_unload_807  1.6744862285014353e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_3  arc_capacity_662  1
    load_0_17_3  segment_load_conservation_746  -1
    load_0_17_3  segment_prefix_lb_747  1
    load_0_17_3  segment_prefix_ub_748  1
    load_0_17_3  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_4  arc_capacity_664  -20
    arc_0_17_4  connected_order_arc_665  -13
    arc_0_17_4  in_degree_750  1
    arc_0_17_4  out_degree_786  1
    arc_0_17_4  original_T_including_depot_unload_807  1.5657515083159024e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_4  arc_capacity_664  1
    load_0_17_4  segment_load_conservation_753  -1
    load_0_17_4  segment_prefix_lb_754  1
    load_0_17_4  segment_prefix_ub_755  1
    load_0_17_4  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_12  arc_capacity_666  -20
    arc_0_17_12  connected_order_arc_667  -13
    arc_0_17_12  in_degree_757  1
    arc_0_17_12  out_degree_786  1
    arc_0_17_12  original_T_including_depot_unload_807  5.1107432522690152e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_12  arc_capacity_666  1
    load_0_17_12  free_load_conservation_761  -1
    load_0_17_12  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_13  arc_capacity_668  -20
    arc_0_17_13  connected_order_arc_669  -13
    arc_0_17_13  in_degree_763  1
    arc_0_17_13  out_degree_786  1
    arc_0_17_13  original_T_including_depot_unload_807  3.6094216796124527e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_13  arc_capacity_668  1
    load_0_17_13  free_load_conservation_767  -1
    load_0_17_13  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_14  arc_capacity_670  -20
    arc_0_17_14  connected_order_arc_671  -13
    arc_0_17_14  in_degree_769  1
    arc_0_17_14  out_degree_786  1
    arc_0_17_14  original_T_including_depot_unload_807  861.314419336229
    MARKER    'MARKER'                 'INTEND'
    load_0_17_14  arc_capacity_670  1
    load_0_17_14  free_load_conservation_773  -1
    load_0_17_14  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_15  arc_capacity_672  -20
    arc_0_17_15  connected_order_arc_673  -13
    arc_0_17_15  in_degree_775  1
    arc_0_17_15  out_degree_786  1
    arc_0_17_15  original_T_including_depot_unload_807  1.6651295535886251e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_15  arc_capacity_672  1
    load_0_17_15  free_load_conservation_779  -1
    load_0_17_15  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_16  arc_capacity_674  -20
    arc_0_17_16  connected_order_arc_675  -13
    arc_0_17_16  in_degree_781  1
    arc_0_17_16  out_degree_786  1
    arc_0_17_16  original_T_including_depot_unload_807  1.4805184908215606e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_16  arc_capacity_674  1
    load_0_17_16  free_load_conservation_785  -1
    load_0_17_16  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_18  arc_capacity_676  -20
    arc_0_17_18  connected_order_arc_677  -13
    arc_0_17_18  out_degree_786  1
    arc_0_17_18  in_degree_793  1
    arc_0_17_18  original_T_including_depot_unload_807  1.4252778892498145e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_18  arc_capacity_676  1
    load_0_17_18  free_load_conservation_791  1
    load_0_17_18  free_load_conservation_797  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_19  arc_capacity_678  -20
    arc_0_17_19  connected_order_arc_679  -13
    arc_0_17_19  out_degree_786  1
    arc_0_17_19  in_degree_799  1
    arc_0_17_19  original_T_including_depot_unload_807  8.9135689158237335e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_19  arc_capacity_678  1
    load_0_17_19  free_load_conservation_791  1
    load_0_17_19  free_load_conservation_803  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_0  arc_capacity_680  -20
    arc_0_18_0  depot_return_or_bypass_727  1
    arc_0_18_0  out_degree_792  1
    arc_0_18_0  original_T_including_depot_unload_807  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_0  arc_capacity_680  1
    load_0_18_0  free_load_conservation_797  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_1  arc_capacity_681  -20
    arc_0_18_1  connected_order_arc_682  -13
    arc_0_18_1  in_degree_729  1
    arc_0_18_1  out_degree_792  1
    arc_0_18_1  original_T_including_depot_unload_807  4.2733962838090457e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_1  arc_capacity_681  1
    load_0_18_1  segment_load_conservation_732  -1
    load_0_18_1  segment_prefix_lb_733  1
    load_0_18_1  segment_prefix_ub_734  1
    load_0_18_1  free_load_conservation_797  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_2  arc_capacity_683  -20
    arc_0_18_2  connected_order_arc_684  -13
    arc_0_18_2  in_degree_736  1
    arc_0_18_2  out_degree_792  1
    arc_0_18_2  original_T_including_depot_unload_807  3.9864800790786632e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_2  arc_capacity_683  1
    load_0_18_2  segment_load_conservation_739  -1
    load_0_18_2  segment_prefix_lb_740  1
    load_0_18_2  segment_prefix_ub_741  1
    load_0_18_2  free_load_conservation_797  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_3  arc_capacity_685  -20
    arc_0_18_3  connected_order_arc_686  -13
    arc_0_18_3  in_degree_743  1
    arc_0_18_3  out_degree_792  1
    arc_0_18_3  original_T_including_depot_unload_807  2.5147997402163108e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_3  arc_capacity_685  1
    load_0_18_3  segment_load_conservation_746  -1
    load_0_18_3  segment_prefix_lb_747  1
    load_0_18_3  segment_prefix_ub_748  1
    load_0_18_3  free_load_conservation_797  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_4  arc_capacity_687  -20
    arc_0_18_4  connected_order_arc_688  -13
    arc_0_18_4  in_degree_750  1
    arc_0_18_4  out_degree_792  1
    arc_0_18_4  original_T_including_depot_unload_807  2.9098466309579254e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_4  arc_capacity_687  1
    load_0_18_4  segment_load_conservation_753  -1
    load_0_18_4  segment_prefix_lb_754  1
    load_0_18_4  segment_prefix_ub_755  1
    load_0_18_4  free_load_conservation_797  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_12  arc_capacity_689  -20
    arc_0_18_12  connected_order_arc_690  -13
    arc_0_18_12  in_degree_757  1
    arc_0_18_12  out_degree_792  1
    arc_0_18_12  original_T_including_depot_unload_807  1.2587701383314870e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_12  arc_capacity_689  1
    load_0_18_12  free_load_conservation_761  -1
    load_0_18_12  free_load_conservation_797  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_13  arc_capacity_691  -20
    arc_0_18_13  connected_order_arc_692  -13
    arc_0_18_13  in_degree_763  1
    arc_0_18_13  out_degree_792  1
    arc_0_18_13  original_T_including_depot_unload_807  1.4479585101303876e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_13  arc_capacity_691  1
    load_0_18_13  free_load_conservation_767  -1
    load_0_18_13  free_load_conservation_797  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_14  arc_capacity_693  -20
    arc_0_18_14  connected_order_arc_694  -13
    arc_0_18_14  in_degree_769  1
    arc_0_18_14  out_degree_792  1
    arc_0_18_14  original_T_including_depot_unload_807  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_14  arc_capacity_693  1
    load_0_18_14  free_load_conservation_773  -1
    load_0_18_14  free_load_conservation_797  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_15  arc_capacity_695  -20
    arc_0_18_15  connected_order_arc_696  -13
    arc_0_18_15  in_degree_775  1
    arc_0_18_15  out_degree_792  1
    arc_0_18_15  original_T_including_depot_unload_807  1.2927779971523576e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_15  arc_capacity_695  1
    load_0_18_15  free_load_conservation_779  -1
    load_0_18_15  free_load_conservation_797  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_16  arc_capacity_697  -20
    arc_0_18_16  connected_order_arc_698  -13
    arc_0_18_16  in_degree_781  1
    arc_0_18_16  out_degree_792  1
    arc_0_18_16  original_T_including_depot_unload_807  1.6597164064313077e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_16  arc_capacity_697  1
    load_0_18_16  free_load_conservation_785  -1
    load_0_18_16  free_load_conservation_797  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_17  arc_capacity_699  -20
    arc_0_18_17  connected_order_arc_700  -13
    arc_0_18_17  in_degree_787  1
    arc_0_18_17  out_degree_792  1
    arc_0_18_17  original_T_including_depot_unload_807  1.4252778892498145e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_17  arc_capacity_699  1
    load_0_18_17  free_load_conservation_791  -1
    load_0_18_17  free_load_conservation_797  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_19  arc_capacity_701  -20
    arc_0_18_19  connected_order_arc_702  -13
    arc_0_18_19  out_degree_792  1
    arc_0_18_19  in_degree_799  1
    arc_0_18_19  original_T_including_depot_unload_807  5.3713048648006088e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_19  arc_capacity_701  1
    load_0_18_19  free_load_conservation_797  1
    load_0_18_19  free_load_conservation_803  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_0  arc_capacity_703  -20
    arc_0_19_0  depot_return_or_bypass_727  1
    arc_0_19_0  out_degree_798  1
    arc_0_19_0  original_T_including_depot_unload_807  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_0  arc_capacity_703  1
    load_0_19_0  free_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_1  arc_capacity_704  -20
    arc_0_19_1  connected_order_arc_705  -13
    arc_0_19_1  in_degree_729  1
    arc_0_19_1  out_degree_798  1
    arc_0_19_1  original_T_including_depot_unload_807  3.6658228437834981e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_1  arc_capacity_704  1
    load_0_19_1  segment_load_conservation_732  -1
    load_0_19_1  segment_prefix_lb_733  1
    load_0_19_1  segment_prefix_ub_734  1
    load_0_19_1  free_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_2  arc_capacity_706  -20
    arc_0_19_2  connected_order_arc_707  -13
    arc_0_19_2  in_degree_736  1
    arc_0_19_2  out_degree_798  1
    arc_0_19_2  original_T_including_depot_unload_807  8.3393751072629220e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_2  arc_capacity_706  1
    load_0_19_2  segment_load_conservation_739  -1
    load_0_19_2  segment_prefix_lb_740  1
    load_0_19_2  segment_prefix_ub_741  1
    load_0_19_2  free_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_3  arc_capacity_708  -20
    arc_0_19_3  connected_order_arc_709  -13
    arc_0_19_3  in_degree_743  1
    arc_0_19_3  out_degree_798  1
    arc_0_19_3  original_T_including_depot_unload_807  7.8830763320343567e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_3  arc_capacity_708  1
    load_0_19_3  segment_load_conservation_746  -1
    load_0_19_3  segment_prefix_lb_747  1
    load_0_19_3  segment_prefix_ub_748  1
    load_0_19_3  free_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_4  arc_capacity_710  -20
    arc_0_19_4  connected_order_arc_711  -13
    arc_0_19_4  in_degree_750  1
    arc_0_19_4  out_degree_798  1
    arc_0_19_4  original_T_including_depot_unload_807  6.8881953094806647e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_4  arc_capacity_710  1
    load_0_19_4  segment_load_conservation_753  -1
    load_0_19_4  segment_prefix_lb_754  1
    load_0_19_4  segment_prefix_ub_755  1
    load_0_19_4  free_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_12  arc_capacity_712  -20
    arc_0_19_12  connected_order_arc_713  -13
    arc_0_19_12  in_degree_757  1
    arc_0_19_12  out_degree_798  1
    arc_0_19_12  original_T_including_depot_unload_807  7.5634788469878674e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_12  arc_capacity_712  1
    load_0_19_12  free_load_conservation_761  -1
    load_0_19_12  free_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_13  arc_capacity_714  -20
    arc_0_19_13  connected_order_arc_715  -13
    arc_0_19_13  in_degree_763  1
    arc_0_19_13  out_degree_798  1
    arc_0_19_13  original_T_including_depot_unload_807  9.2235470209829464e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_13  arc_capacity_714  1
    load_0_19_13  free_load_conservation_767  -1
    load_0_19_13  free_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_14  arc_capacity_716  -20
    arc_0_19_14  connected_order_arc_717  -13
    arc_0_19_14  in_degree_769  1
    arc_0_19_14  out_degree_798  1
    arc_0_19_14  original_T_including_depot_unload_807  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_14  arc_capacity_716  1
    load_0_19_14  free_load_conservation_773  -1
    load_0_19_14  free_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_15  arc_capacity_718  -20
    arc_0_19_15  connected_order_arc_719  -13
    arc_0_19_15  in_degree_775  1
    arc_0_19_15  out_degree_798  1
    arc_0_19_15  original_T_including_depot_unload_807  7.5571464781430223e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_15  arc_capacity_718  1
    load_0_19_15  free_load_conservation_779  -1
    load_0_19_15  free_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_16  arc_capacity_720  -20
    arc_0_19_16  connected_order_arc_721  -13
    arc_0_19_16  in_degree_781  1
    arc_0_19_16  out_degree_798  1
    arc_0_19_16  original_T_including_depot_unload_807  6.1704611580490348e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_16  arc_capacity_720  1
    load_0_19_16  free_load_conservation_785  -1
    load_0_19_16  free_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_17  arc_capacity_722  -20
    arc_0_19_17  connected_order_arc_723  -13
    arc_0_19_17  in_degree_787  1
    arc_0_19_17  out_degree_798  1
    arc_0_19_17  original_T_including_depot_unload_807  8.9135689158237335e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_17  arc_capacity_722  1
    load_0_19_17  free_load_conservation_791  -1
    load_0_19_17  free_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_18  arc_capacity_724  -20
    arc_0_19_18  connected_order_arc_725  -13
    arc_0_19_18  in_degree_793  1
    arc_0_19_18  out_degree_798  1
    arc_0_19_18  original_T_including_depot_unload_807  5.3713048648006088e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_18  arc_capacity_724  1
    load_0_19_18  free_load_conservation_797  -1
    load_0_19_18  free_load_conservation_803  1
    visit_1_5  out_degree_1099  -1
    visit_1_5  in_degree_1100  -1
    visit_1_5  order_active_lb_1101  -1
    visit_1_5  order_active_ub_1102  -12
    order_1_5  connected_order_arc_823  -1
    order_1_5  connected_order_arc_825  -1
    order_1_5  connected_order_arc_827  -1
    order_1_5  connected_order_arc_829  -1
    order_1_5  connected_order_arc_831  -1
    order_1_5  connected_order_arc_833  -1
    order_1_5  connected_order_arc_835  -1
    order_1_5  connected_order_arc_837  -1
    order_1_5  connected_order_arc_839  -1
    order_1_5  connected_order_arc_841  -1
    order_1_5  connected_order_arc_843  -1
    order_1_5  connected_order_arc_846  1
    order_1_5  connected_order_arc_869  1
    order_1_5  connected_order_arc_892  1
    order_1_5  connected_order_arc_915  1
    order_1_5  connected_order_arc_938  1
    order_1_5  connected_order_arc_961  1
    order_1_5  connected_order_arc_984  1
    order_1_5  connected_order_arc_1007  1
    order_1_5  connected_order_arc_1030  1
    order_1_5  connected_order_arc_1053  1
    order_1_5  connected_order_arc_1076  1
    order_1_5  order_active_lb_1101  1
    order_1_5  order_active_ub_1102  1
    order_1_5  fixed_segment_relative_order_1175  -1
    visit_1_6  out_degree_1106  -1
    visit_1_6  in_degree_1107  -1
    visit_1_6  order_active_lb_1108  -1
    visit_1_6  order_active_ub_1109  -12
    order_1_6  connected_order_arc_823  1
    order_1_6  connected_order_arc_846  -1
    order_1_6  connected_order_arc_848  -1
    order_1_6  connected_order_arc_850  -1
    order_1_6  connected_order_arc_852  -1
    order_1_6  connected_order_arc_854  -1
    order_1_6  connected_order_arc_856  -1
    order_1_6  connected_order_arc_858  -1
    order_1_6  connected_order_arc_860  -1
    order_1_6  connected_order_arc_862  -1
    order_1_6  connected_order_arc_864  -1
    order_1_6  connected_order_arc_866  -1
    order_1_6  connected_order_arc_871  1
    order_1_6  connected_order_arc_894  1
    order_1_6  connected_order_arc_917  1
    order_1_6  connected_order_arc_940  1
    order_1_6  connected_order_arc_963  1
    order_1_6  connected_order_arc_986  1
    order_1_6  connected_order_arc_1009  1
    order_1_6  connected_order_arc_1032  1
    order_1_6  connected_order_arc_1055  1
    order_1_6  connected_order_arc_1078  1
    order_1_6  order_active_lb_1108  1
    order_1_6  order_active_ub_1109  1
    order_1_6  fixed_segment_relative_order_1175  1
    order_1_6  fixed_segment_relative_order_1176  -1
    visit_1_7  out_degree_1113  -1
    visit_1_7  in_degree_1114  -1
    visit_1_7  order_active_lb_1115  -1
    visit_1_7  order_active_ub_1116  -12
    order_1_7  connected_order_arc_825  1
    order_1_7  connected_order_arc_848  1
    order_1_7  connected_order_arc_869  -1
    order_1_7  connected_order_arc_871  -1
    order_1_7  connected_order_arc_873  -1
    order_1_7  connected_order_arc_875  -1
    order_1_7  connected_order_arc_877  -1
    order_1_7  connected_order_arc_879  -1
    order_1_7  connected_order_arc_881  -1
    order_1_7  connected_order_arc_883  -1
    order_1_7  connected_order_arc_885  -1
    order_1_7  connected_order_arc_887  -1
    order_1_7  connected_order_arc_889  -1
    order_1_7  connected_order_arc_896  1
    order_1_7  connected_order_arc_919  1
    order_1_7  connected_order_arc_942  1
    order_1_7  connected_order_arc_965  1
    order_1_7  connected_order_arc_988  1
    order_1_7  connected_order_arc_1011  1
    order_1_7  connected_order_arc_1034  1
    order_1_7  connected_order_arc_1057  1
    order_1_7  connected_order_arc_1080  1
    order_1_7  order_active_lb_1115  1
    order_1_7  order_active_ub_1116  1
    order_1_7  fixed_segment_relative_order_1176  1
    order_1_7  fixed_segment_relative_order_1177  -1
    visit_1_8  out_degree_1120  -1
    visit_1_8  in_degree_1121  -1
    visit_1_8  order_active_lb_1122  -1
    visit_1_8  order_active_ub_1123  -12
    order_1_8  connected_order_arc_827  1
    order_1_8  connected_order_arc_850  1
    order_1_8  connected_order_arc_873  1
    order_1_8  connected_order_arc_892  -1
    order_1_8  connected_order_arc_894  -1
    order_1_8  connected_order_arc_896  -1
    order_1_8  connected_order_arc_898  -1
    order_1_8  connected_order_arc_900  -1
    order_1_8  connected_order_arc_902  -1
    order_1_8  connected_order_arc_904  -1
    order_1_8  connected_order_arc_906  -1
    order_1_8  connected_order_arc_908  -1
    order_1_8  connected_order_arc_910  -1
    order_1_8  connected_order_arc_912  -1
    order_1_8  connected_order_arc_921  1
    order_1_8  connected_order_arc_944  1
    order_1_8  connected_order_arc_967  1
    order_1_8  connected_order_arc_990  1
    order_1_8  connected_order_arc_1013  1
    order_1_8  connected_order_arc_1036  1
    order_1_8  connected_order_arc_1059  1
    order_1_8  connected_order_arc_1082  1
    order_1_8  order_active_lb_1122  1
    order_1_8  order_active_ub_1123  1
    order_1_8  fixed_segment_relative_order_1177  1
    visit_1_12  out_degree_1127  -1
    visit_1_12  in_degree_1128  -1
    visit_1_12  order_active_lb_1129  -1
    visit_1_12  order_active_ub_1130  -12
    visit_1_12  service_visit_def_1131  -1
    order_1_12  connected_order_arc_829  1
    order_1_12  connected_order_arc_852  1
    order_1_12  connected_order_arc_875  1
    order_1_12  connected_order_arc_898  1
    order_1_12  connected_order_arc_915  -1
    order_1_12  connected_order_arc_917  -1
    order_1_12  connected_order_arc_919  -1
    order_1_12  connected_order_arc_921  -1
    order_1_12  connected_order_arc_923  -1
    order_1_12  connected_order_arc_925  -1
    order_1_12  connected_order_arc_927  -1
    order_1_12  connected_order_arc_929  -1
    order_1_12  connected_order_arc_931  -1
    order_1_12  connected_order_arc_933  -1
    order_1_12  connected_order_arc_935  -1
    order_1_12  connected_order_arc_946  1
    order_1_12  connected_order_arc_969  1
    order_1_12  connected_order_arc_992  1
    order_1_12  connected_order_arc_1015  1
    order_1_12  connected_order_arc_1038  1
    order_1_12  connected_order_arc_1061  1
    order_1_12  connected_order_arc_1084  1
    order_1_12  order_active_lb_1129  1
    order_1_12  order_active_ub_1130  1
    visit_1_13  out_degree_1133  -1
    visit_1_13  in_degree_1134  -1
    visit_1_13  order_active_lb_1135  -1
    visit_1_13  order_active_ub_1136  -12
    visit_1_13  service_visit_def_1137  -1
    order_1_13  connected_order_arc_831  1
    order_1_13  connected_order_arc_854  1
    order_1_13  connected_order_arc_877  1
    order_1_13  connected_order_arc_900  1
    order_1_13  connected_order_arc_923  1
    order_1_13  connected_order_arc_938  -1
    order_1_13  connected_order_arc_940  -1
    order_1_13  connected_order_arc_942  -1
    order_1_13  connected_order_arc_944  -1
    order_1_13  connected_order_arc_946  -1
    order_1_13  connected_order_arc_948  -1
    order_1_13  connected_order_arc_950  -1
    order_1_13  connected_order_arc_952  -1
    order_1_13  connected_order_arc_954  -1
    order_1_13  connected_order_arc_956  -1
    order_1_13  connected_order_arc_958  -1
    order_1_13  connected_order_arc_971  1
    order_1_13  connected_order_arc_994  1
    order_1_13  connected_order_arc_1017  1
    order_1_13  connected_order_arc_1040  1
    order_1_13  connected_order_arc_1063  1
    order_1_13  connected_order_arc_1086  1
    order_1_13  order_active_lb_1135  1
    order_1_13  order_active_ub_1136  1
    visit_1_14  out_degree_1139  -1
    visit_1_14  in_degree_1140  -1
    visit_1_14  order_active_lb_1141  -1
    visit_1_14  order_active_ub_1142  -12
    visit_1_14  service_visit_def_1143  -1
    order_1_14  connected_order_arc_833  1
    order_1_14  connected_order_arc_856  1
    order_1_14  connected_order_arc_879  1
    order_1_14  connected_order_arc_902  1
    order_1_14  connected_order_arc_925  1
    order_1_14  connected_order_arc_948  1
    order_1_14  connected_order_arc_961  -1
    order_1_14  connected_order_arc_963  -1
    order_1_14  connected_order_arc_965  -1
    order_1_14  connected_order_arc_967  -1
    order_1_14  connected_order_arc_969  -1
    order_1_14  connected_order_arc_971  -1
    order_1_14  connected_order_arc_973  -1
    order_1_14  connected_order_arc_975  -1
    order_1_14  connected_order_arc_977  -1
    order_1_14  connected_order_arc_979  -1
    order_1_14  connected_order_arc_981  -1
    order_1_14  connected_order_arc_996  1
    order_1_14  connected_order_arc_1019  1
    order_1_14  connected_order_arc_1042  1
    order_1_14  connected_order_arc_1065  1
    order_1_14  connected_order_arc_1088  1
    order_1_14  order_active_lb_1141  1
    order_1_14  order_active_ub_1142  1
    visit_1_15  out_degree_1145  -1
    visit_1_15  in_degree_1146  -1
    visit_1_15  order_active_lb_1147  -1
    visit_1_15  order_active_ub_1148  -12
    visit_1_15  service_visit_def_1149  -1
    order_1_15  connected_order_arc_835  1
    order_1_15  connected_order_arc_858  1
    order_1_15  connected_order_arc_881  1
    order_1_15  connected_order_arc_904  1
    order_1_15  connected_order_arc_927  1
    order_1_15  connected_order_arc_950  1
    order_1_15  connected_order_arc_973  1
    order_1_15  connected_order_arc_984  -1
    order_1_15  connected_order_arc_986  -1
    order_1_15  connected_order_arc_988  -1
    order_1_15  connected_order_arc_990  -1
    order_1_15  connected_order_arc_992  -1
    order_1_15  connected_order_arc_994  -1
    order_1_15  connected_order_arc_996  -1
    order_1_15  connected_order_arc_998  -1
    order_1_15  connected_order_arc_1000  -1
    order_1_15  connected_order_arc_1002  -1
    order_1_15  connected_order_arc_1004  -1
    order_1_15  connected_order_arc_1021  1
    order_1_15  connected_order_arc_1044  1
    order_1_15  connected_order_arc_1067  1
    order_1_15  connected_order_arc_1090  1
    order_1_15  order_active_lb_1147  1
    order_1_15  order_active_ub_1148  1
    visit_1_16  out_degree_1151  -1
    visit_1_16  in_degree_1152  -1
    visit_1_16  order_active_lb_1153  -1
    visit_1_16  order_active_ub_1154  -12
    visit_1_16  service_visit_def_1155  -1
    order_1_16  connected_order_arc_837  1
    order_1_16  connected_order_arc_860  1
    order_1_16  connected_order_arc_883  1
    order_1_16  connected_order_arc_906  1
    order_1_16  connected_order_arc_929  1
    order_1_16  connected_order_arc_952  1
    order_1_16  connected_order_arc_975  1
    order_1_16  connected_order_arc_998  1
    order_1_16  connected_order_arc_1007  -1
    order_1_16  connected_order_arc_1009  -1
    order_1_16  connected_order_arc_1011  -1
    order_1_16  connected_order_arc_1013  -1
    order_1_16  connected_order_arc_1015  -1
    order_1_16  connected_order_arc_1017  -1
    order_1_16  connected_order_arc_1019  -1
    order_1_16  connected_order_arc_1021  -1
    order_1_16  connected_order_arc_1023  -1
    order_1_16  connected_order_arc_1025  -1
    order_1_16  connected_order_arc_1027  -1
    order_1_16  connected_order_arc_1046  1
    order_1_16  connected_order_arc_1069  1
    order_1_16  connected_order_arc_1092  1
    order_1_16  order_active_lb_1153  1
    order_1_16  order_active_ub_1154  1
    visit_1_17  out_degree_1157  -1
    visit_1_17  in_degree_1158  -1
    visit_1_17  order_active_lb_1159  -1
    visit_1_17  order_active_ub_1160  -12
    visit_1_17  service_visit_def_1161  -1
    order_1_17  connected_order_arc_839  1
    order_1_17  connected_order_arc_862  1
    order_1_17  connected_order_arc_885  1
    order_1_17  connected_order_arc_908  1
    order_1_17  connected_order_arc_931  1
    order_1_17  connected_order_arc_954  1
    order_1_17  connected_order_arc_977  1
    order_1_17  connected_order_arc_1000  1
    order_1_17  connected_order_arc_1023  1
    order_1_17  connected_order_arc_1030  -1
    order_1_17  connected_order_arc_1032  -1
    order_1_17  connected_order_arc_1034  -1
    order_1_17  connected_order_arc_1036  -1
    order_1_17  connected_order_arc_1038  -1
    order_1_17  connected_order_arc_1040  -1
    order_1_17  connected_order_arc_1042  -1
    order_1_17  connected_order_arc_1044  -1
    order_1_17  connected_order_arc_1046  -1
    order_1_17  connected_order_arc_1048  -1
    order_1_17  connected_order_arc_1050  -1
    order_1_17  connected_order_arc_1071  1
    order_1_17  connected_order_arc_1094  1
    order_1_17  order_active_lb_1159  1
    order_1_17  order_active_ub_1160  1
    visit_1_18  out_degree_1163  -1
    visit_1_18  in_degree_1164  -1
    visit_1_18  order_active_lb_1165  -1
    visit_1_18  order_active_ub_1166  -12
    visit_1_18  service_visit_def_1167  -1
    order_1_18  connected_order_arc_841  1
    order_1_18  connected_order_arc_864  1
    order_1_18  connected_order_arc_887  1
    order_1_18  connected_order_arc_910  1
    order_1_18  connected_order_arc_933  1
    order_1_18  connected_order_arc_956  1
    order_1_18  connected_order_arc_979  1
    order_1_18  connected_order_arc_1002  1
    order_1_18  connected_order_arc_1025  1
    order_1_18  connected_order_arc_1048  1
    order_1_18  connected_order_arc_1053  -1
    order_1_18  connected_order_arc_1055  -1
    order_1_18  connected_order_arc_1057  -1
    order_1_18  connected_order_arc_1059  -1
    order_1_18  connected_order_arc_1061  -1
    order_1_18  connected_order_arc_1063  -1
    order_1_18  connected_order_arc_1065  -1
    order_1_18  connected_order_arc_1067  -1
    order_1_18  connected_order_arc_1069  -1
    order_1_18  connected_order_arc_1071  -1
    order_1_18  connected_order_arc_1073  -1
    order_1_18  connected_order_arc_1096  1
    order_1_18  order_active_lb_1165  1
    order_1_18  order_active_ub_1166  1
    visit_1_19  out_degree_1169  -1
    visit_1_19  in_degree_1170  -1
    visit_1_19  order_active_lb_1171  -1
    visit_1_19  order_active_ub_1172  -12
    visit_1_19  service_visit_def_1173  -1
    order_1_19  connected_order_arc_843  1
    order_1_19  connected_order_arc_866  1
    order_1_19  connected_order_arc_889  1
    order_1_19  connected_order_arc_912  1
    order_1_19  connected_order_arc_935  1
    order_1_19  connected_order_arc_958  1
    order_1_19  connected_order_arc_981  1
    order_1_19  connected_order_arc_1004  1
    order_1_19  connected_order_arc_1027  1
    order_1_19  connected_order_arc_1050  1
    order_1_19  connected_order_arc_1073  1
    order_1_19  connected_order_arc_1076  -1
    order_1_19  connected_order_arc_1078  -1
    order_1_19  connected_order_arc_1080  -1
    order_1_19  connected_order_arc_1082  -1
    order_1_19  connected_order_arc_1084  -1
    order_1_19  connected_order_arc_1086  -1
    order_1_19  connected_order_arc_1088  -1
    order_1_19  connected_order_arc_1090  -1
    order_1_19  connected_order_arc_1092  -1
    order_1_19  connected_order_arc_1094  -1
    order_1_19  connected_order_arc_1096  -1
    order_1_19  order_active_lb_1171  1
    order_1_19  order_active_ub_1172  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_0  arc_capacity_808  -25
    arc_1_0_0  depot_departure_or_bypass_1097  1
    arc_1_0_0  depot_return_or_bypass_1098  1
    MARKER    'MARKER'                 'INTEND'
    load_1_0_0  arc_capacity_808  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_5  arc_capacity_809  -25
    arc_1_0_5  depot_departure_or_bypass_1097  1
    arc_1_0_5  in_degree_1100  1
    arc_1_0_5  original_T_including_depot_unload_1178  1.2751323166566442e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_5  arc_capacity_809  1
    load_1_0_5  segment_load_conservation_1103  -1
    load_1_0_5  segment_prefix_lb_1104  1
    load_1_0_5  segment_prefix_ub_1105  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_6  arc_capacity_810  -25
    arc_1_0_6  depot_departure_or_bypass_1097  1
    arc_1_0_6  in_degree_1107  1
    arc_1_0_6  original_T_including_depot_unload_1178  1.3076700111397606e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_6  arc_capacity_810  1
    load_1_0_6  segment_load_conservation_1110  -1
    load_1_0_6  segment_prefix_lb_1111  1
    load_1_0_6  segment_prefix_ub_1112  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_7  arc_capacity_811  -25
    arc_1_0_7  depot_departure_or_bypass_1097  1
    arc_1_0_7  in_degree_1114  1
    arc_1_0_7  original_T_including_depot_unload_1178  1.2801771486108735e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_7  arc_capacity_811  1
    load_1_0_7  segment_load_conservation_1117  -1
    load_1_0_7  segment_prefix_lb_1118  1
    load_1_0_7  segment_prefix_ub_1119  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_8  arc_capacity_812  -25
    arc_1_0_8  depot_departure_or_bypass_1097  1
    arc_1_0_8  in_degree_1121  1
    arc_1_0_8  original_T_including_depot_unload_1178  4.7522445589173662e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_8  arc_capacity_812  1
    load_1_0_8  segment_load_conservation_1124  -1
    load_1_0_8  segment_prefix_lb_1125  1
    load_1_0_8  segment_prefix_ub_1126  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_12  arc_capacity_813  -25
    arc_1_0_12  depot_departure_or_bypass_1097  1
    arc_1_0_12  in_degree_1128  1
    arc_1_0_12  original_T_including_depot_unload_1178  8.7918533905669346e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_12  arc_capacity_813  1
    load_1_0_12  free_load_conservation_1132  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_13  arc_capacity_814  -25
    arc_1_0_13  depot_departure_or_bypass_1097  1
    arc_1_0_13  in_degree_1134  1
    arc_1_0_13  original_T_including_depot_unload_1178  1.0479182987243917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_13  arc_capacity_814  1
    load_1_0_13  free_load_conservation_1138  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_14  arc_capacity_815  -25
    arc_1_0_14  depot_departure_or_bypass_1097  1
    arc_1_0_14  in_degree_1140  1
    arc_1_0_14  original_T_including_depot_unload_1178  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_14  arc_capacity_815  1
    load_1_0_14  free_load_conservation_1144  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_15  arc_capacity_816  -25
    arc_1_0_15  depot_departure_or_bypass_1097  1
    arc_1_0_15  in_degree_1146  1
    arc_1_0_15  original_T_including_depot_unload_1178  8.7749189782983967e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_15  arc_capacity_816  1
    load_1_0_15  free_load_conservation_1150  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_16  arc_capacity_817  -25
    arc_1_0_16  depot_departure_or_bypass_1097  1
    arc_1_0_16  in_degree_1152  1
    arc_1_0_16  original_T_including_depot_unload_1178  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_16  arc_capacity_817  1
    load_1_0_16  free_load_conservation_1156  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_17  arc_capacity_818  -25
    arc_1_0_17  depot_departure_or_bypass_1097  1
    arc_1_0_17  in_degree_1158  1
    arc_1_0_17  original_T_including_depot_unload_1178  1.0088905112952611e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_17  arc_capacity_818  1
    load_1_0_17  free_load_conservation_1162  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_18  arc_capacity_819  -25
    arc_1_0_18  depot_departure_or_bypass_1097  1
    arc_1_0_18  in_degree_1164  1
    arc_1_0_18  original_T_including_depot_unload_1178  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_18  arc_capacity_819  1
    load_1_0_18  free_load_conservation_1168  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_19  arc_capacity_820  -25
    arc_1_0_19  depot_departure_or_bypass_1097  1
    arc_1_0_19  in_degree_1170  1
    arc_1_0_19  original_T_including_depot_unload_1178  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_19  arc_capacity_820  1
    load_1_0_19  free_load_conservation_1174  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_0  arc_capacity_821  -25
    arc_1_5_0  depot_return_or_bypass_1098  1
    arc_1_5_0  out_degree_1099  1
    arc_1_5_0  original_T_including_depot_unload_1178  1.2751323166566442e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_0  arc_capacity_821  1
    load_1_5_0  segment_load_conservation_1103  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_6  arc_capacity_822  -25
    arc_1_5_6  connected_order_arc_823  -13
    arc_1_5_6  out_degree_1099  1
    arc_1_5_6  in_degree_1107  1
    arc_1_5_6  original_T_including_depot_unload_1178  1.9785969874636677e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_5_6  arc_capacity_822  1
    load_1_5_6  segment_load_conservation_1103  1
    load_1_5_6  segment_load_conservation_1110  -1
    load_1_5_6  segment_prefix_lb_1111  1
    load_1_5_6  segment_prefix_ub_1112  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_7  arc_capacity_824  -25
    arc_1_5_7  connected_order_arc_825  -13
    arc_1_5_7  out_degree_1099  1
    arc_1_5_7  in_degree_1114  1
    arc_1_5_7  original_T_including_depot_unload_1178  726.017738185843
    MARKER    'MARKER'                 'INTEND'
    load_1_5_7  arc_capacity_824  1
    load_1_5_7  segment_load_conservation_1103  1
    load_1_5_7  segment_load_conservation_1117  -1
    load_1_5_7  segment_prefix_lb_1118  1
    load_1_5_7  segment_prefix_ub_1119  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_8  arc_capacity_826  -25
    arc_1_5_8  connected_order_arc_827  -13
    arc_1_5_8  out_degree_1099  1
    arc_1_5_8  in_degree_1121  1
    arc_1_5_8  original_T_including_depot_unload_1178  1.1310682908759807e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_8  arc_capacity_826  1
    load_1_5_8  segment_load_conservation_1103  1
    load_1_5_8  segment_load_conservation_1124  -1
    load_1_5_8  segment_prefix_lb_1125  1
    load_1_5_8  segment_prefix_ub_1126  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_12  arc_capacity_828  -25
    arc_1_5_12  connected_order_arc_829  -13
    arc_1_5_12  out_degree_1099  1
    arc_1_5_12  in_degree_1128  1
    arc_1_5_12  original_T_including_depot_unload_1178  8.2035300709080423e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_5_12  arc_capacity_828  1
    load_1_5_12  segment_load_conservation_1103  1
    load_1_5_12  free_load_conservation_1132  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_13  arc_capacity_830  -25
    arc_1_5_13  connected_order_arc_831  -13
    arc_1_5_13  out_degree_1099  1
    arc_1_5_13  in_degree_1134  1
    arc_1_5_13  original_T_including_depot_unload_1178  6.2793211180612207e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_5_13  arc_capacity_830  1
    load_1_5_13  segment_load_conservation_1103  1
    load_1_5_13  free_load_conservation_1138  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_14  arc_capacity_832  -25
    arc_1_5_14  connected_order_arc_833  -13
    arc_1_5_14  out_degree_1099  1
    arc_1_5_14  in_degree_1140  1
    arc_1_5_14  original_T_including_depot_unload_1178  1.1499210972200315e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_14  arc_capacity_832  1
    load_1_5_14  segment_load_conservation_1103  1
    load_1_5_14  free_load_conservation_1144  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_15  arc_capacity_834  -25
    arc_1_5_15  connected_order_arc_835  -13
    arc_1_5_15  out_degree_1099  1
    arc_1_5_15  in_degree_1146  1
    arc_1_5_15  original_T_including_depot_unload_1178  4.8905010520753694e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_5_15  arc_capacity_834  1
    load_1_5_15  segment_load_conservation_1103  1
    load_1_5_15  free_load_conservation_1150  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_16  arc_capacity_836  -25
    arc_1_5_16  connected_order_arc_837  -13
    arc_1_5_16  out_degree_1099  1
    arc_1_5_16  in_degree_1152  1
    arc_1_5_16  original_T_including_depot_unload_1178  1.7211624454573559e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_16  arc_capacity_836  1
    load_1_5_16  segment_load_conservation_1103  1
    load_1_5_16  free_load_conservation_1156  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_17  arc_capacity_838  -25
    arc_1_5_17  connected_order_arc_839  -13
    arc_1_5_17  out_degree_1099  1
    arc_1_5_17  in_degree_1158  1
    arc_1_5_17  original_T_including_depot_unload_1178  3.2286832955801827e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_5_17  arc_capacity_838  1
    load_1_5_17  segment_load_conservation_1103  1
    load_1_5_17  free_load_conservation_1162  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_18  arc_capacity_840  -25
    arc_1_5_18  connected_order_arc_841  -13
    arc_1_5_18  out_degree_1099  1
    arc_1_5_18  in_degree_1164  1
    arc_1_5_18  original_T_including_depot_unload_1178  1.6865101452371027e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_18  arc_capacity_840  1
    load_1_5_18  segment_load_conservation_1103  1
    load_1_5_18  free_load_conservation_1168  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_19  arc_capacity_842  -25
    arc_1_5_19  connected_order_arc_843  -13
    arc_1_5_19  out_degree_1099  1
    arc_1_5_19  in_degree_1170  1
    arc_1_5_19  original_T_including_depot_unload_1178  1.1663816070445826e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_19  arc_capacity_842  1
    load_1_5_19  segment_load_conservation_1103  1
    load_1_5_19  free_load_conservation_1174  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_0  arc_capacity_844  -25
    arc_1_6_0  depot_return_or_bypass_1098  1
    arc_1_6_0  out_degree_1106  1
    arc_1_6_0  original_T_including_depot_unload_1178  1.3076700111397606e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_0  arc_capacity_844  1
    load_1_6_0  segment_load_conservation_1110  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_5  arc_capacity_845  -25
    arc_1_6_5  connected_order_arc_846  -13
    arc_1_6_5  in_degree_1100  1
    arc_1_6_5  out_degree_1106  1
    arc_1_6_5  original_T_including_depot_unload_1178  1.9785969874636677e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_5  arc_capacity_845  1
    load_1_6_5  segment_load_conservation_1103  -1
    load_1_6_5  segment_prefix_lb_1104  1
    load_1_6_5  segment_prefix_ub_1105  1
    load_1_6_5  segment_load_conservation_1110  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_7  arc_capacity_847  -25
    arc_1_6_7  connected_order_arc_848  -13
    arc_1_6_7  out_degree_1106  1
    arc_1_6_7  in_degree_1114  1
    arc_1_6_7  original_T_including_depot_unload_1178  5.4630148713373910e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_7  arc_capacity_847  1
    load_1_6_7  segment_load_conservation_1110  1
    load_1_6_7  segment_load_conservation_1117  -1
    load_1_6_7  segment_prefix_lb_1118  1
    load_1_6_7  segment_prefix_ub_1119  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_8  arc_capacity_849  -25
    arc_1_6_8  connected_order_arc_850  -13
    arc_1_6_8  out_degree_1106  1
    arc_1_6_8  in_degree_1121  1
    arc_1_6_8  original_T_including_depot_unload_1178  1.0910343836035740e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_8  arc_capacity_849  1
    load_1_6_8  segment_load_conservation_1110  1
    load_1_6_8  segment_load_conservation_1124  -1
    load_1_6_8  segment_prefix_lb_1125  1
    load_1_6_8  segment_prefix_ub_1126  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_12  arc_capacity_851  -25
    arc_1_6_12  connected_order_arc_852  -13
    arc_1_6_12  out_degree_1106  1
    arc_1_6_12  in_degree_1128  1
    arc_1_6_12  original_T_including_depot_unload_1178  9.7692852841087415e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_12  arc_capacity_851  1
    load_1_6_12  segment_load_conservation_1110  1
    load_1_6_12  free_load_conservation_1132  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_13  arc_capacity_853  -25
    arc_1_6_13  connected_order_arc_854  -13
    arc_1_6_13  out_degree_1106  1
    arc_1_6_13  in_degree_1134  1
    arc_1_6_13  original_T_including_depot_unload_1178  8.0531033344008677e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_13  arc_capacity_853  1
    load_1_6_13  segment_load_conservation_1110  1
    load_1_6_13  free_load_conservation_1138  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_14  arc_capacity_855  -25
    arc_1_6_14  connected_order_arc_856  -13
    arc_1_6_14  out_degree_1106  1
    arc_1_6_14  in_degree_1140  1
    arc_1_6_14  original_T_including_depot_unload_1178  1.3218357148919101e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_14  arc_capacity_855  1
    load_1_6_14  segment_load_conservation_1110  1
    load_1_6_14  free_load_conservation_1144  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_15  arc_capacity_857  -25
    arc_1_6_15  connected_order_arc_858  -13
    arc_1_6_15  out_degree_1106  1
    arc_1_6_15  in_degree_1146  1
    arc_1_6_15  original_T_including_depot_unload_1178  6.2102815646279714e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_15  arc_capacity_857  1
    load_1_6_15  segment_load_conservation_1110  1
    load_1_6_15  free_load_conservation_1150  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_16  arc_capacity_859  -25
    arc_1_6_16  connected_order_arc_860  -13
    arc_1_6_16  out_degree_1106  1
    arc_1_6_16  in_degree_1152  1
    arc_1_6_16  original_T_including_depot_unload_1178  1.7225744515697754e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_16  arc_capacity_859  1
    load_1_6_16  segment_load_conservation_1110  1
    load_1_6_16  free_load_conservation_1156  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_17  arc_capacity_861  -25
    arc_1_6_17  connected_order_arc_862  -13
    arc_1_6_17  out_degree_1106  1
    arc_1_6_17  in_degree_1158  1
    arc_1_6_17  original_T_including_depot_unload_1178  4.6588884124393707e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_17  arc_capacity_861  1
    load_1_6_17  segment_load_conservation_1110  1
    load_1_6_17  free_load_conservation_1162  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_18  arc_capacity_863  -25
    arc_1_6_18  connected_order_arc_864  -13
    arc_1_6_18  out_degree_1106  1
    arc_1_6_18  in_degree_1164  1
    arc_1_6_18  original_T_including_depot_unload_1178  1706.88312024691
    MARKER    'MARKER'                 'INTEND'
    load_1_6_18  arc_capacity_863  1
    load_1_6_18  segment_load_conservation_1110  1
    load_1_6_18  free_load_conservation_1168  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_19  arc_capacity_865  -25
    arc_1_6_19  connected_order_arc_866  -13
    arc_1_6_19  out_degree_1106  1
    arc_1_6_19  in_degree_1170  1
    arc_1_6_19  original_T_including_depot_unload_1178  1.2100678255370710e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_19  arc_capacity_865  1
    load_1_6_19  segment_load_conservation_1110  1
    load_1_6_19  free_load_conservation_1174  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_0  arc_capacity_867  -25
    arc_1_7_0  depot_return_or_bypass_1098  1
    arc_1_7_0  out_degree_1113  1
    arc_1_7_0  original_T_including_depot_unload_1178  7.8195480223834068e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_0  arc_capacity_867  1
    load_1_7_0  segment_load_conservation_1117  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_5  arc_capacity_868  -25
    arc_1_7_5  connected_order_arc_869  -13
    arc_1_7_5  in_degree_1100  1
    arc_1_7_5  out_degree_1113  1
    arc_1_7_5  original_T_including_depot_unload_1178  7.7248128224166851e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_5  arc_capacity_868  1
    load_1_7_5  segment_load_conservation_1103  -1
    load_1_7_5  segment_prefix_lb_1104  1
    load_1_7_5  segment_prefix_ub_1105  1
    load_1_7_5  segment_load_conservation_1117  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_6  arc_capacity_870  -25
    arc_1_7_6  connected_order_arc_871  -13
    arc_1_7_6  in_degree_1107  1
    arc_1_7_6  out_degree_1113  1
    arc_1_7_6  original_T_including_depot_unload_1178  6.9492720147205364e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_6  arc_capacity_870  1
    load_1_7_6  segment_load_conservation_1110  -1
    load_1_7_6  segment_prefix_lb_1111  1
    load_1_7_6  segment_prefix_ub_1112  1
    load_1_7_6  segment_load_conservation_1117  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_8  arc_capacity_872  -25
    arc_1_7_8  connected_order_arc_873  -13
    arc_1_7_8  out_degree_1113  1
    arc_1_7_8  in_degree_1121  1
    arc_1_7_8  original_T_including_depot_unload_1178  4.1964259385165178e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_8  arc_capacity_872  1
    load_1_7_8  segment_load_conservation_1117  1
    load_1_7_8  segment_load_conservation_1124  -1
    load_1_7_8  segment_prefix_lb_1125  1
    load_1_7_8  segment_prefix_ub_1126  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_12  arc_capacity_874  -25
    arc_1_7_12  connected_order_arc_875  -13
    arc_1_7_12  out_degree_1113  1
    arc_1_7_12  in_degree_1128  1
    arc_1_7_12  original_T_including_depot_unload_1178  1.0062397105603651e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_12  arc_capacity_874  1
    load_1_7_12  segment_load_conservation_1117  1
    load_1_7_12  free_load_conservation_1132  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_13  arc_capacity_876  -25
    arc_1_7_13  connected_order_arc_877  -13
    arc_1_7_13  out_degree_1113  1
    arc_1_7_13  in_degree_1134  1
    arc_1_7_13  original_T_including_depot_unload_1178  9.9524628735690555e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_13  arc_capacity_876  1
    load_1_7_13  segment_load_conservation_1117  1
    load_1_7_13  free_load_conservation_1138  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_14  arc_capacity_878  -25
    arc_1_7_14  connected_order_arc_879  -13
    arc_1_7_14  out_degree_1113  1
    arc_1_7_14  in_degree_1140  1
    arc_1_7_14  original_T_including_depot_unload_1178  1.3626829404511475e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_14  arc_capacity_878  1
    load_1_7_14  segment_load_conservation_1117  1
    load_1_7_14  free_load_conservation_1144  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_15  arc_capacity_880  -25
    arc_1_7_15  connected_order_arc_881  -13
    arc_1_7_15  out_degree_1113  1
    arc_1_7_15  in_degree_1146  1
    arc_1_7_15  original_T_including_depot_unload_1178  7.0804311489116617e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_15  arc_capacity_880  1
    load_1_7_15  segment_load_conservation_1117  1
    load_1_7_15  free_load_conservation_1150  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_16  arc_capacity_882  -25
    arc_1_7_16  connected_order_arc_883  -13
    arc_1_7_16  out_degree_1113  1
    arc_1_7_16  in_degree_1152  1
    arc_1_7_16  original_T_including_depot_unload_1178  1.0921272639748563e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_16  arc_capacity_882  1
    load_1_7_16  segment_load_conservation_1117  1
    load_1_7_16  free_load_conservation_1156  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_17  arc_capacity_884  -25
    arc_1_7_17  connected_order_arc_885  -13
    arc_1_7_17  out_degree_1113  1
    arc_1_7_17  in_degree_1158  1
    arc_1_7_17  original_T_including_depot_unload_1178  7.0141209816069022e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_17  arc_capacity_884  1
    load_1_7_17  segment_load_conservation_1117  1
    load_1_7_17  free_load_conservation_1162  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_18  arc_capacity_886  -25
    arc_1_7_18  connected_order_arc_887  -13
    arc_1_7_18  out_degree_1113  1
    arc_1_7_18  in_degree_1164  1
    arc_1_7_18  original_T_including_depot_unload_1178  1.1162091303696777e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_18  arc_capacity_886  1
    load_1_7_18  segment_load_conservation_1117  1
    load_1_7_18  free_load_conservation_1168  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_19  arc_capacity_888  -25
    arc_1_7_19  connected_order_arc_889  -13
    arc_1_7_19  out_degree_1113  1
    arc_1_7_19  in_degree_1170  1
    arc_1_7_19  original_T_including_depot_unload_1178  7.3394466063263269e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_19  arc_capacity_888  1
    load_1_7_19  segment_load_conservation_1117  1
    load_1_7_19  free_load_conservation_1174  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_0  arc_capacity_890  -25
    arc_1_8_0  depot_return_or_bypass_1098  1
    arc_1_8_0  out_degree_1120  1
    arc_1_8_0  original_T_including_depot_unload_1178  4.7522445589173662e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_0  arc_capacity_890  1
    load_1_8_0  segment_load_conservation_1124  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_5  arc_capacity_891  -25
    arc_1_8_5  connected_order_arc_892  -13
    arc_1_8_5  in_degree_1100  1
    arc_1_8_5  out_degree_1120  1
    arc_1_8_5  original_T_including_depot_unload_1178  1.1310682908759807e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_5  arc_capacity_891  1
    load_1_8_5  segment_load_conservation_1103  -1
    load_1_8_5  segment_prefix_lb_1104  1
    load_1_8_5  segment_prefix_ub_1105  1
    load_1_8_5  segment_load_conservation_1124  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_6  arc_capacity_893  -25
    arc_1_8_6  connected_order_arc_894  -13
    arc_1_8_6  in_degree_1107  1
    arc_1_8_6  out_degree_1120  1
    arc_1_8_6  original_T_including_depot_unload_1178  1.0910343836035740e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_6  arc_capacity_893  1
    load_1_8_6  segment_load_conservation_1110  -1
    load_1_8_6  segment_prefix_lb_1111  1
    load_1_8_6  segment_prefix_ub_1112  1
    load_1_8_6  segment_load_conservation_1124  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_7  arc_capacity_895  -25
    arc_1_8_7  connected_order_arc_896  -13
    arc_1_8_7  in_degree_1114  1
    arc_1_8_7  out_degree_1120  1
    arc_1_8_7  original_T_including_depot_unload_1178  8.9356126423557316e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_7  arc_capacity_895  1
    load_1_8_7  segment_load_conservation_1117  -1
    load_1_8_7  segment_prefix_lb_1118  1
    load_1_8_7  segment_prefix_ub_1119  1
    load_1_8_7  segment_load_conservation_1124  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_12  arc_capacity_897  -25
    arc_1_8_12  connected_order_arc_898  -13
    arc_1_8_12  out_degree_1120  1
    arc_1_8_12  in_degree_1128  1
    arc_1_8_12  original_T_including_depot_unload_1178  1.0793944823036150e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_12  arc_capacity_897  1
    load_1_8_12  segment_load_conservation_1124  1
    load_1_8_12  free_load_conservation_1132  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_13  arc_capacity_899  -25
    arc_1_8_13  connected_order_arc_900  -13
    arc_1_8_13  out_degree_1120  1
    arc_1_8_13  in_degree_1134  1
    arc_1_8_13  original_T_including_depot_unload_1178  1.1592640472038677e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_13  arc_capacity_899  1
    load_1_8_13  segment_load_conservation_1124  1
    load_1_8_13  free_load_conservation_1138  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_14  arc_capacity_901  -25
    arc_1_8_14  connected_order_arc_902  -13
    arc_1_8_14  out_degree_1120  1
    arc_1_8_14  in_degree_1140  1
    arc_1_8_14  original_T_including_depot_unload_1178  1.3823927712314810e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_14  arc_capacity_901  1
    load_1_8_14  segment_load_conservation_1124  1
    load_1_8_14  free_load_conservation_1144  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_15  arc_capacity_903  -25
    arc_1_8_15  connected_order_arc_904  -13
    arc_1_8_15  out_degree_1120  1
    arc_1_8_15  in_degree_1146  1
    arc_1_8_15  original_T_including_depot_unload_1178  9.0121368945211725e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_15  arc_capacity_903  1
    load_1_8_15  segment_load_conservation_1124  1
    load_1_8_15  free_load_conservation_1150  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_16  arc_capacity_905  -25
    arc_1_8_16  connected_order_arc_906  -13
    arc_1_8_16  out_degree_1120  1
    arc_1_8_16  in_degree_1152  1
    arc_1_8_16  original_T_including_depot_unload_1178  6.7803521648175558e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_16  arc_capacity_905  1
    load_1_8_16  segment_load_conservation_1124  1
    load_1_8_16  free_load_conservation_1156  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_17  arc_capacity_907  -25
    arc_1_8_17  connected_order_arc_908  -13
    arc_1_8_17  out_degree_1120  1
    arc_1_8_17  in_degree_1158  1
    arc_1_8_17  original_T_including_depot_unload_1178  9.6554407723795373e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_17  arc_capacity_907  1
    load_1_8_17  segment_load_conservation_1124  1
    load_1_8_17  free_load_conservation_1162  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_18  arc_capacity_909  -25
    arc_1_8_18  connected_order_arc_910  -13
    arc_1_8_18  out_degree_1120  1
    arc_1_8_18  in_degree_1164  1
    arc_1_8_18  original_T_including_depot_unload_1178  7.2171835955896984e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_18  arc_capacity_909  1
    load_1_8_18  segment_load_conservation_1124  1
    load_1_8_18  free_load_conservation_1168  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_19  arc_capacity_911  -25
    arc_1_8_19  connected_order_arc_912  -13
    arc_1_8_19  out_degree_1120  1
    arc_1_8_19  in_degree_1170  1
    arc_1_8_19  original_T_including_depot_unload_1178  4.9232225330062903e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_19  arc_capacity_911  1
    load_1_8_19  segment_load_conservation_1124  1
    load_1_8_19  free_load_conservation_1174  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_0  arc_capacity_913  -25
    arc_1_12_0  depot_return_or_bypass_1098  1
    arc_1_12_0  out_degree_1127  1
    arc_1_12_0  original_T_including_depot_unload_1178  8.7918533905669346e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_0  arc_capacity_913  1
    load_1_12_0  free_load_conservation_1132  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_5  arc_capacity_914  -25
    arc_1_12_5  connected_order_arc_915  -13
    arc_1_12_5  in_degree_1100  1
    arc_1_12_5  out_degree_1127  1
    arc_1_12_5  original_T_including_depot_unload_1178  8.2035300709080423e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_5  arc_capacity_914  1
    load_1_12_5  segment_load_conservation_1103  -1
    load_1_12_5  segment_prefix_lb_1104  1
    load_1_12_5  segment_prefix_ub_1105  1
    load_1_12_5  free_load_conservation_1132  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_6  arc_capacity_916  -25
    arc_1_12_6  connected_order_arc_917  -13
    arc_1_12_6  in_degree_1107  1
    arc_1_12_6  out_degree_1127  1
    arc_1_12_6  original_T_including_depot_unload_1178  9.7692852841087415e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_6  arc_capacity_916  1
    load_1_12_6  segment_load_conservation_1110  -1
    load_1_12_6  segment_prefix_lb_1111  1
    load_1_12_6  segment_prefix_ub_1112  1
    load_1_12_6  free_load_conservation_1132  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_7  arc_capacity_918  -25
    arc_1_12_7  connected_order_arc_919  -13
    arc_1_12_7  in_degree_1114  1
    arc_1_12_7  out_degree_1127  1
    arc_1_12_7  original_T_including_depot_unload_1178  1.3197014959146461e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_7  arc_capacity_918  1
    load_1_12_7  segment_load_conservation_1117  -1
    load_1_12_7  segment_prefix_lb_1118  1
    load_1_12_7  segment_prefix_ub_1119  1
    load_1_12_7  free_load_conservation_1132  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_8  arc_capacity_920  -25
    arc_1_12_8  connected_order_arc_921  -13
    arc_1_12_8  in_degree_1121  1
    arc_1_12_8  out_degree_1127  1
    arc_1_12_8  original_T_including_depot_unload_1178  1.0793944823036150e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_8  arc_capacity_920  1
    load_1_12_8  segment_load_conservation_1124  -1
    load_1_12_8  segment_prefix_lb_1125  1
    load_1_12_8  segment_prefix_ub_1126  1
    load_1_12_8  free_load_conservation_1132  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_13  arc_capacity_922  -25
    arc_1_12_13  connected_order_arc_923  -13
    arc_1_12_13  out_degree_1127  1
    arc_1_12_13  in_degree_1134  1
    arc_1_12_13  original_T_including_depot_unload_1178  2.4155873404211835e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_13  arc_capacity_922  1
    load_1_12_13  free_load_conservation_1132  1
    load_1_12_13  free_load_conservation_1138  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_14  arc_capacity_924  -25
    arc_1_12_14  connected_order_arc_925  -13
    arc_1_12_14  out_degree_1127  1
    arc_1_12_14  in_degree_1140  1
    arc_1_12_14  original_T_including_depot_unload_1178  3.6824909986567474e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_14  arc_capacity_924  1
    load_1_12_14  free_load_conservation_1132  1
    load_1_12_14  free_load_conservation_1144  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_15  arc_capacity_926  -25
    arc_1_12_15  connected_order_arc_927  -13
    arc_1_12_15  out_degree_1127  1
    arc_1_12_15  in_degree_1146  1
    arc_1_12_15  original_T_including_depot_unload_1178  3.6821827312741834e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_15  arc_capacity_926  1
    load_1_12_15  free_load_conservation_1132  1
    load_1_12_15  free_load_conservation_1150  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_16  arc_capacity_928  -25
    arc_1_12_16  connected_order_arc_929  -13
    arc_1_12_16  out_degree_1127  1
    arc_1_12_16  in_degree_1152  1
    arc_1_12_16  original_T_including_depot_unload_1178  1.3653307388496069e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_16  arc_capacity_928  1
    load_1_12_16  free_load_conservation_1132  1
    load_1_12_16  free_load_conservation_1156  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_17  arc_capacity_930  -25
    arc_1_12_17  connected_order_arc_931  -13
    arc_1_12_17  out_degree_1127  1
    arc_1_12_17  in_degree_1158  1
    arc_1_12_17  original_T_including_depot_unload_1178  5.1107432522690152e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_17  arc_capacity_930  1
    load_1_12_17  free_load_conservation_1132  1
    load_1_12_17  free_load_conservation_1162  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_18  arc_capacity_932  -25
    arc_1_12_18  connected_order_arc_933  -13
    arc_1_12_18  out_degree_1127  1
    arc_1_12_18  in_degree_1164  1
    arc_1_12_18  original_T_including_depot_unload_1178  1.2587701383314870e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_18  arc_capacity_932  1
    load_1_12_18  free_load_conservation_1132  1
    load_1_12_18  free_load_conservation_1168  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_19  arc_capacity_934  -25
    arc_1_12_19  connected_order_arc_935  -13
    arc_1_12_19  out_degree_1127  1
    arc_1_12_19  in_degree_1170  1
    arc_1_12_19  original_T_including_depot_unload_1178  7.5634788469878674e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_19  arc_capacity_934  1
    load_1_12_19  free_load_conservation_1132  1
    load_1_12_19  free_load_conservation_1174  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_0  arc_capacity_936  -25
    arc_1_13_0  depot_return_or_bypass_1098  1
    arc_1_13_0  out_degree_1133  1
    arc_1_13_0  original_T_including_depot_unload_1178  1.0479182987243917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_0  arc_capacity_936  1
    load_1_13_0  free_load_conservation_1138  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_5  arc_capacity_937  -25
    arc_1_13_5  connected_order_arc_938  -13
    arc_1_13_5  in_degree_1100  1
    arc_1_13_5  out_degree_1133  1
    arc_1_13_5  original_T_including_depot_unload_1178  6.2793211180612207e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_5  arc_capacity_937  1
    load_1_13_5  segment_load_conservation_1103  -1
    load_1_13_5  segment_prefix_lb_1104  1
    load_1_13_5  segment_prefix_ub_1105  1
    load_1_13_5  free_load_conservation_1138  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_6  arc_capacity_939  -25
    arc_1_13_6  connected_order_arc_940  -13
    arc_1_13_6  in_degree_1107  1
    arc_1_13_6  out_degree_1133  1
    arc_1_13_6  original_T_including_depot_unload_1178  8.0531033344008677e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_6  arc_capacity_939  1
    load_1_13_6  segment_load_conservation_1110  -1
    load_1_13_6  segment_prefix_lb_1111  1
    load_1_13_6  segment_prefix_ub_1112  1
    load_1_13_6  free_load_conservation_1138  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_7  arc_capacity_941  -25
    arc_1_13_7  connected_order_arc_942  -13
    arc_1_13_7  in_degree_1114  1
    arc_1_13_7  out_degree_1133  1
    arc_1_13_7  original_T_including_depot_unload_1178  1.2213551686272770e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_7  arc_capacity_941  1
    load_1_13_7  segment_load_conservation_1117  -1
    load_1_13_7  segment_prefix_lb_1118  1
    load_1_13_7  segment_prefix_ub_1119  1
    load_1_13_7  free_load_conservation_1138  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_8  arc_capacity_943  -25
    arc_1_13_8  connected_order_arc_944  -13
    arc_1_13_8  in_degree_1121  1
    arc_1_13_8  out_degree_1133  1
    arc_1_13_8  original_T_including_depot_unload_1178  1.1592640472038677e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_8  arc_capacity_943  1
    load_1_13_8  segment_load_conservation_1124  -1
    load_1_13_8  segment_prefix_lb_1125  1
    load_1_13_8  segment_prefix_ub_1126  1
    load_1_13_8  free_load_conservation_1138  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_12  arc_capacity_945  -25
    arc_1_13_12  connected_order_arc_946  -13
    arc_1_13_12  in_degree_1128  1
    arc_1_13_12  out_degree_1133  1
    arc_1_13_12  original_T_including_depot_unload_1178  2.4155873404211835e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_12  arc_capacity_945  1
    load_1_13_12  free_load_conservation_1132  -1
    load_1_13_12  free_load_conservation_1138  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_14  arc_capacity_947  -25
    arc_1_13_14  connected_order_arc_948  -13
    arc_1_13_14  out_degree_1133  1
    arc_1_13_14  in_degree_1140  1
    arc_1_13_14  original_T_including_depot_unload_1178  5.2280951376932137e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_14  arc_capacity_947  1
    load_1_13_14  free_load_conservation_1138  1
    load_1_13_14  free_load_conservation_1144  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_15  arc_capacity_949  -25
    arc_1_13_15  connected_order_arc_950  -13
    arc_1_13_15  out_degree_1133  1
    arc_1_13_15  in_degree_1146  1
    arc_1_13_15  original_T_including_depot_unload_1178  2.8747557636937808e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_15  arc_capacity_949  1
    load_1_13_15  free_load_conservation_1138  1
    load_1_13_15  free_load_conservation_1150  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_16  arc_capacity_951  -25
    arc_1_13_16  connected_order_arc_952  -13
    arc_1_13_16  out_degree_1133  1
    arc_1_13_16  in_degree_1152  1
    arc_1_13_16  original_T_including_depot_unload_1178  1.5393904884690303e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_16  arc_capacity_951  1
    load_1_13_16  free_load_conservation_1138  1
    load_1_13_16  free_load_conservation_1156  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_17  arc_capacity_953  -25
    arc_1_13_17  connected_order_arc_954  -13
    arc_1_13_17  out_degree_1133  1
    arc_1_13_17  in_degree_1158  1
    arc_1_13_17  original_T_including_depot_unload_1178  3.6094216796124527e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_17  arc_capacity_953  1
    load_1_13_17  free_load_conservation_1138  1
    load_1_13_17  free_load_conservation_1162  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_18  arc_capacity_955  -25
    arc_1_13_18  connected_order_arc_956  -13
    arc_1_13_18  out_degree_1133  1
    arc_1_13_18  in_degree_1164  1
    arc_1_13_18  original_T_including_depot_unload_1178  1.4479585101303876e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_18  arc_capacity_955  1
    load_1_13_18  free_load_conservation_1138  1
    load_1_13_18  free_load_conservation_1168  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_19  arc_capacity_957  -25
    arc_1_13_19  connected_order_arc_958  -13
    arc_1_13_19  out_degree_1133  1
    arc_1_13_19  in_degree_1170  1
    arc_1_13_19  original_T_including_depot_unload_1178  9.2235470209829464e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_19  arc_capacity_957  1
    load_1_13_19  free_load_conservation_1138  1
    load_1_13_19  free_load_conservation_1174  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_0  arc_capacity_959  -25
    arc_1_14_0  depot_return_or_bypass_1098  1
    arc_1_14_0  out_degree_1139  1
    arc_1_14_0  original_T_including_depot_unload_1178  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_0  arc_capacity_959  1
    load_1_14_0  free_load_conservation_1144  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_5  arc_capacity_960  -25
    arc_1_14_5  connected_order_arc_961  -13
    arc_1_14_5  in_degree_1100  1
    arc_1_14_5  out_degree_1139  1
    arc_1_14_5  original_T_including_depot_unload_1178  1.1499210972200315e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_5  arc_capacity_960  1
    load_1_14_5  segment_load_conservation_1103  -1
    load_1_14_5  segment_prefix_lb_1104  1
    load_1_14_5  segment_prefix_ub_1105  1
    load_1_14_5  free_load_conservation_1144  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_6  arc_capacity_962  -25
    arc_1_14_6  connected_order_arc_963  -13
    arc_1_14_6  in_degree_1107  1
    arc_1_14_6  out_degree_1139  1
    arc_1_14_6  original_T_including_depot_unload_1178  1.3218357148919101e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_6  arc_capacity_962  1
    load_1_14_6  segment_load_conservation_1110  -1
    load_1_14_6  segment_prefix_lb_1111  1
    load_1_14_6  segment_prefix_ub_1112  1
    load_1_14_6  free_load_conservation_1144  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_7  arc_capacity_964  -25
    arc_1_14_7  connected_order_arc_965  -13
    arc_1_14_7  in_degree_1114  1
    arc_1_14_7  out_degree_1139  1
    arc_1_14_7  original_T_including_depot_unload_1178  1.6876944916846833e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_7  arc_capacity_964  1
    load_1_14_7  segment_load_conservation_1117  -1
    load_1_14_7  segment_prefix_lb_1118  1
    load_1_14_7  segment_prefix_ub_1119  1
    load_1_14_7  free_load_conservation_1144  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_8  arc_capacity_966  -25
    arc_1_14_8  connected_order_arc_967  -13
    arc_1_14_8  in_degree_1121  1
    arc_1_14_8  out_degree_1139  1
    arc_1_14_8  original_T_including_depot_unload_1178  1.3823927712314810e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_8  arc_capacity_966  1
    load_1_14_8  segment_load_conservation_1124  -1
    load_1_14_8  segment_prefix_lb_1125  1
    load_1_14_8  segment_prefix_ub_1126  1
    load_1_14_8  free_load_conservation_1144  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_12  arc_capacity_968  -25
    arc_1_14_12  connected_order_arc_969  -13
    arc_1_14_12  in_degree_1128  1
    arc_1_14_12  out_degree_1139  1
    arc_1_14_12  original_T_including_depot_unload_1178  3.6824909986567474e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_12  arc_capacity_968  1
    load_1_14_12  free_load_conservation_1132  -1
    load_1_14_12  free_load_conservation_1144  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_13  arc_capacity_970  -25
    arc_1_14_13  connected_order_arc_971  -13
    arc_1_14_13  in_degree_1134  1
    arc_1_14_13  out_degree_1139  1
    arc_1_14_13  original_T_including_depot_unload_1178  5.2280951376932137e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_13  arc_capacity_970  1
    load_1_14_13  free_load_conservation_1138  -1
    load_1_14_13  free_load_conservation_1144  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_15  arc_capacity_972  -25
    arc_1_14_15  connected_order_arc_973  -13
    arc_1_14_15  out_degree_1139  1
    arc_1_14_15  in_degree_1146  1
    arc_1_14_15  original_T_including_depot_unload_1178  7.3227602527872671e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_15  arc_capacity_972  1
    load_1_14_15  free_load_conservation_1144  1
    load_1_14_15  free_load_conservation_1150  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_16  arc_capacity_974  -25
    arc_1_14_16  connected_order_arc_975  -13
    arc_1_14_16  out_degree_1139  1
    arc_1_14_16  in_degree_1152  1
    arc_1_14_16  original_T_including_depot_unload_1178  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_16  arc_capacity_974  1
    load_1_14_16  free_load_conservation_1144  1
    load_1_14_16  free_load_conservation_1156  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_17  arc_capacity_976  -25
    arc_1_14_17  connected_order_arc_977  -13
    arc_1_14_17  out_degree_1139  1
    arc_1_14_17  in_degree_1158  1
    arc_1_14_17  original_T_including_depot_unload_1178  861.314419336229
    MARKER    'MARKER'                 'INTEND'
    load_1_14_17  arc_capacity_976  1
    load_1_14_17  free_load_conservation_1144  1
    load_1_14_17  free_load_conservation_1162  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_18  arc_capacity_978  -25
    arc_1_14_18  connected_order_arc_979  -13
    arc_1_14_18  out_degree_1139  1
    arc_1_14_18  in_degree_1164  1
    arc_1_14_18  original_T_including_depot_unload_1178  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_18  arc_capacity_978  1
    load_1_14_18  free_load_conservation_1144  1
    load_1_14_18  free_load_conservation_1168  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_19  arc_capacity_980  -25
    arc_1_14_19  connected_order_arc_981  -13
    arc_1_14_19  out_degree_1139  1
    arc_1_14_19  in_degree_1170  1
    arc_1_14_19  original_T_including_depot_unload_1178  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_19  arc_capacity_980  1
    load_1_14_19  free_load_conservation_1144  1
    load_1_14_19  free_load_conservation_1174  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_0  arc_capacity_982  -25
    arc_1_15_0  depot_return_or_bypass_1098  1
    arc_1_15_0  out_degree_1145  1
    arc_1_15_0  original_T_including_depot_unload_1178  8.7749189782983967e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_0  arc_capacity_982  1
    load_1_15_0  free_load_conservation_1150  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_5  arc_capacity_983  -25
    arc_1_15_5  connected_order_arc_984  -13
    arc_1_15_5  in_degree_1100  1
    arc_1_15_5  out_degree_1145  1
    arc_1_15_5  original_T_including_depot_unload_1178  4.8905010520753694e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_5  arc_capacity_983  1
    load_1_15_5  segment_load_conservation_1103  -1
    load_1_15_5  segment_prefix_lb_1104  1
    load_1_15_5  segment_prefix_ub_1105  1
    load_1_15_5  free_load_conservation_1150  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_6  arc_capacity_985  -25
    arc_1_15_6  connected_order_arc_986  -13
    arc_1_15_6  in_degree_1107  1
    arc_1_15_6  out_degree_1145  1
    arc_1_15_6  original_T_including_depot_unload_1178  6.2102815646279714e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_6  arc_capacity_985  1
    load_1_15_6  segment_load_conservation_1110  -1
    load_1_15_6  segment_prefix_lb_1111  1
    load_1_15_6  segment_prefix_ub_1112  1
    load_1_15_6  free_load_conservation_1150  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_7  arc_capacity_987  -25
    arc_1_15_7  connected_order_arc_988  -13
    arc_1_15_7  in_degree_1114  1
    arc_1_15_7  out_degree_1145  1
    arc_1_15_7  original_T_including_depot_unload_1178  9.5892865701726816e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_7  arc_capacity_987  1
    load_1_15_7  segment_load_conservation_1117  -1
    load_1_15_7  segment_prefix_lb_1118  1
    load_1_15_7  segment_prefix_ub_1119  1
    load_1_15_7  free_load_conservation_1150  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_8  arc_capacity_989  -25
    arc_1_15_8  connected_order_arc_990  -13
    arc_1_15_8  in_degree_1121  1
    arc_1_15_8  out_degree_1145  1
    arc_1_15_8  original_T_including_depot_unload_1178  9.0121368945211725e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_8  arc_capacity_989  1
    load_1_15_8  segment_load_conservation_1124  -1
    load_1_15_8  segment_prefix_lb_1125  1
    load_1_15_8  segment_prefix_ub_1126  1
    load_1_15_8  free_load_conservation_1150  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_12  arc_capacity_991  -25
    arc_1_15_12  connected_order_arc_992  -13
    arc_1_15_12  in_degree_1128  1
    arc_1_15_12  out_degree_1145  1
    arc_1_15_12  original_T_including_depot_unload_1178  3.6821827312741834e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_12  arc_capacity_991  1
    load_1_15_12  free_load_conservation_1132  -1
    load_1_15_12  free_load_conservation_1150  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_13  arc_capacity_993  -25
    arc_1_15_13  connected_order_arc_994  -13
    arc_1_15_13  in_degree_1134  1
    arc_1_15_13  out_degree_1145  1
    arc_1_15_13  original_T_including_depot_unload_1178  2.8747557636937808e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_13  arc_capacity_993  1
    load_1_15_13  free_load_conservation_1138  -1
    load_1_15_13  free_load_conservation_1150  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_14  arc_capacity_995  -25
    arc_1_15_14  connected_order_arc_996  -13
    arc_1_15_14  in_degree_1140  1
    arc_1_15_14  out_degree_1145  1
    arc_1_15_14  original_T_including_depot_unload_1178  7.3227602527872671e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_14  arc_capacity_995  1
    load_1_15_14  free_load_conservation_1144  -1
    load_1_15_14  free_load_conservation_1150  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_16  arc_capacity_997  -25
    arc_1_15_16  connected_order_arc_998  -13
    arc_1_15_16  out_degree_1145  1
    arc_1_15_16  in_degree_1152  1
    arc_1_15_16  original_T_including_depot_unload_1178  1.3600272346134373e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_16  arc_capacity_997  1
    load_1_15_16  free_load_conservation_1150  1
    load_1_15_16  free_load_conservation_1156  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_17  arc_capacity_999  -25
    arc_1_15_17  connected_order_arc_1000  -13
    arc_1_15_17  out_degree_1145  1
    arc_1_15_17  in_degree_1158  1
    arc_1_15_17  original_T_including_depot_unload_1178  1.6651295535886251e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_17  arc_capacity_999  1
    load_1_15_17  free_load_conservation_1150  1
    load_1_15_17  free_load_conservation_1162  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_18  arc_capacity_1001  -25
    arc_1_15_18  connected_order_arc_1002  -13
    arc_1_15_18  out_degree_1145  1
    arc_1_15_18  in_degree_1164  1
    arc_1_15_18  original_T_including_depot_unload_1178  1.2927779971523576e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_18  arc_capacity_1001  1
    load_1_15_18  free_load_conservation_1150  1
    load_1_15_18  free_load_conservation_1168  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_19  arc_capacity_1003  -25
    arc_1_15_19  connected_order_arc_1004  -13
    arc_1_15_19  out_degree_1145  1
    arc_1_15_19  in_degree_1170  1
    arc_1_15_19  original_T_including_depot_unload_1178  7.5571464781430223e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_19  arc_capacity_1003  1
    load_1_15_19  free_load_conservation_1150  1
    load_1_15_19  free_load_conservation_1174  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_0  arc_capacity_1005  -25
    arc_1_16_0  depot_return_or_bypass_1098  1
    arc_1_16_0  out_degree_1151  1
    arc_1_16_0  original_T_including_depot_unload_1178  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_0  arc_capacity_1005  1
    load_1_16_0  free_load_conservation_1156  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_5  arc_capacity_1006  -25
    arc_1_16_5  connected_order_arc_1007  -13
    arc_1_16_5  in_degree_1100  1
    arc_1_16_5  out_degree_1151  1
    arc_1_16_5  original_T_including_depot_unload_1178  1.7211624454573559e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_5  arc_capacity_1006  1
    load_1_16_5  segment_load_conservation_1103  -1
    load_1_16_5  segment_prefix_lb_1104  1
    load_1_16_5  segment_prefix_ub_1105  1
    load_1_16_5  free_load_conservation_1156  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_6  arc_capacity_1008  -25
    arc_1_16_6  connected_order_arc_1009  -13
    arc_1_16_6  in_degree_1107  1
    arc_1_16_6  out_degree_1151  1
    arc_1_16_6  original_T_including_depot_unload_1178  1.7225744515697754e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_6  arc_capacity_1008  1
    load_1_16_6  segment_load_conservation_1110  -1
    load_1_16_6  segment_prefix_lb_1111  1
    load_1_16_6  segment_prefix_ub_1112  1
    load_1_16_6  free_load_conservation_1156  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_7  arc_capacity_1010  -25
    arc_1_16_7  connected_order_arc_1011  -13
    arc_1_16_7  in_degree_1114  1
    arc_1_16_7  out_degree_1151  1
    arc_1_16_7  original_T_including_depot_unload_1178  1.5711351987660353e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_7  arc_capacity_1010  1
    load_1_16_7  segment_load_conservation_1117  -1
    load_1_16_7  segment_prefix_lb_1118  1
    load_1_16_7  segment_prefix_ub_1119  1
    load_1_16_7  free_load_conservation_1156  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_8  arc_capacity_1012  -25
    arc_1_16_8  connected_order_arc_1013  -13
    arc_1_16_8  in_degree_1121  1
    arc_1_16_8  out_degree_1151  1
    arc_1_16_8  original_T_including_depot_unload_1178  6.7803521648175558e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_8  arc_capacity_1012  1
    load_1_16_8  segment_load_conservation_1124  -1
    load_1_16_8  segment_prefix_lb_1125  1
    load_1_16_8  segment_prefix_ub_1126  1
    load_1_16_8  free_load_conservation_1156  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_12  arc_capacity_1014  -25
    arc_1_16_12  connected_order_arc_1015  -13
    arc_1_16_12  in_degree_1128  1
    arc_1_16_12  out_degree_1151  1
    arc_1_16_12  original_T_including_depot_unload_1178  1.3653307388496069e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_12  arc_capacity_1014  1
    load_1_16_12  free_load_conservation_1132  -1
    load_1_16_12  free_load_conservation_1156  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_13  arc_capacity_1016  -25
    arc_1_16_13  connected_order_arc_1017  -13
    arc_1_16_13  in_degree_1134  1
    arc_1_16_13  out_degree_1151  1
    arc_1_16_13  original_T_including_depot_unload_1178  1.5393904884690303e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_13  arc_capacity_1016  1
    load_1_16_13  free_load_conservation_1138  -1
    load_1_16_13  free_load_conservation_1156  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_14  arc_capacity_1018  -25
    arc_1_16_14  connected_order_arc_1019  -13
    arc_1_16_14  in_degree_1140  1
    arc_1_16_14  out_degree_1151  1
    arc_1_16_14  original_T_including_depot_unload_1178  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_14  arc_capacity_1018  1
    load_1_16_14  free_load_conservation_1144  -1
    load_1_16_14  free_load_conservation_1156  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_15  arc_capacity_1020  -25
    arc_1_16_15  connected_order_arc_1021  -13
    arc_1_16_15  in_degree_1146  1
    arc_1_16_15  out_degree_1151  1
    arc_1_16_15  original_T_including_depot_unload_1178  1.3600272346134373e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_15  arc_capacity_1020  1
    load_1_16_15  free_load_conservation_1150  -1
    load_1_16_15  free_load_conservation_1156  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_17  arc_capacity_1022  -25
    arc_1_16_17  connected_order_arc_1023  -13
    arc_1_16_17  out_degree_1151  1
    arc_1_16_17  in_degree_1158  1
    arc_1_16_17  original_T_including_depot_unload_1178  1.4805184908215606e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_17  arc_capacity_1022  1
    load_1_16_17  free_load_conservation_1156  1
    load_1_16_17  free_load_conservation_1162  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_18  arc_capacity_1024  -25
    arc_1_16_18  connected_order_arc_1025  -13
    arc_1_16_18  out_degree_1151  1
    arc_1_16_18  in_degree_1164  1
    arc_1_16_18  original_T_including_depot_unload_1178  1.6597164064313077e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_18  arc_capacity_1024  1
    load_1_16_18  free_load_conservation_1156  1
    load_1_16_18  free_load_conservation_1168  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_19  arc_capacity_1026  -25
    arc_1_16_19  connected_order_arc_1027  -13
    arc_1_16_19  out_degree_1151  1
    arc_1_16_19  in_degree_1170  1
    arc_1_16_19  original_T_including_depot_unload_1178  6.1704611580490348e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_19  arc_capacity_1026  1
    load_1_16_19  free_load_conservation_1156  1
    load_1_16_19  free_load_conservation_1174  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_0  arc_capacity_1028  -25
    arc_1_17_0  depot_return_or_bypass_1098  1
    arc_1_17_0  out_degree_1157  1
    arc_1_17_0  original_T_including_depot_unload_1178  1.0088905112952611e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_0  arc_capacity_1028  1
    load_1_17_0  free_load_conservation_1162  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_5  arc_capacity_1029  -25
    arc_1_17_5  connected_order_arc_1030  -13
    arc_1_17_5  in_degree_1100  1
    arc_1_17_5  out_degree_1157  1
    arc_1_17_5  original_T_including_depot_unload_1178  3.2286832955801827e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_5  arc_capacity_1029  1
    load_1_17_5  segment_load_conservation_1103  -1
    load_1_17_5  segment_prefix_lb_1104  1
    load_1_17_5  segment_prefix_ub_1105  1
    load_1_17_5  free_load_conservation_1162  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_6  arc_capacity_1031  -25
    arc_1_17_6  connected_order_arc_1032  -13
    arc_1_17_6  in_degree_1107  1
    arc_1_17_6  out_degree_1157  1
    arc_1_17_6  original_T_including_depot_unload_1178  4.6588884124393707e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_6  arc_capacity_1031  1
    load_1_17_6  segment_load_conservation_1110  -1
    load_1_17_6  segment_prefix_lb_1111  1
    load_1_17_6  segment_prefix_ub_1112  1
    load_1_17_6  free_load_conservation_1162  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_7  arc_capacity_1033  -25
    arc_1_17_7  connected_order_arc_1034  -13
    arc_1_17_7  in_degree_1114  1
    arc_1_17_7  out_degree_1157  1
    arc_1_17_7  original_T_including_depot_unload_1178  8.6289703303586691e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_7  arc_capacity_1033  1
    load_1_17_7  segment_load_conservation_1117  -1
    load_1_17_7  segment_prefix_lb_1118  1
    load_1_17_7  segment_prefix_ub_1119  1
    load_1_17_7  free_load_conservation_1162  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_8  arc_capacity_1035  -25
    arc_1_17_8  connected_order_arc_1036  -13
    arc_1_17_8  in_degree_1121  1
    arc_1_17_8  out_degree_1157  1
    arc_1_17_8  original_T_including_depot_unload_1178  9.6554407723795373e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_8  arc_capacity_1035  1
    load_1_17_8  segment_load_conservation_1124  -1
    load_1_17_8  segment_prefix_lb_1125  1
    load_1_17_8  segment_prefix_ub_1126  1
    load_1_17_8  free_load_conservation_1162  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_12  arc_capacity_1037  -25
    arc_1_17_12  connected_order_arc_1038  -13
    arc_1_17_12  in_degree_1128  1
    arc_1_17_12  out_degree_1157  1
    arc_1_17_12  original_T_including_depot_unload_1178  5.1107432522690152e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_12  arc_capacity_1037  1
    load_1_17_12  free_load_conservation_1132  -1
    load_1_17_12  free_load_conservation_1162  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_13  arc_capacity_1039  -25
    arc_1_17_13  connected_order_arc_1040  -13
    arc_1_17_13  in_degree_1134  1
    arc_1_17_13  out_degree_1157  1
    arc_1_17_13  original_T_including_depot_unload_1178  3.6094216796124527e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_13  arc_capacity_1039  1
    load_1_17_13  free_load_conservation_1138  -1
    load_1_17_13  free_load_conservation_1162  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_14  arc_capacity_1041  -25
    arc_1_17_14  connected_order_arc_1042  -13
    arc_1_17_14  in_degree_1140  1
    arc_1_17_14  out_degree_1157  1
    arc_1_17_14  original_T_including_depot_unload_1178  861.314419336229
    MARKER    'MARKER'                 'INTEND'
    load_1_17_14  arc_capacity_1041  1
    load_1_17_14  free_load_conservation_1144  -1
    load_1_17_14  free_load_conservation_1162  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_15  arc_capacity_1043  -25
    arc_1_17_15  connected_order_arc_1044  -13
    arc_1_17_15  in_degree_1146  1
    arc_1_17_15  out_degree_1157  1
    arc_1_17_15  original_T_including_depot_unload_1178  1.6651295535886251e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_15  arc_capacity_1043  1
    load_1_17_15  free_load_conservation_1150  -1
    load_1_17_15  free_load_conservation_1162  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_16  arc_capacity_1045  -25
    arc_1_17_16  connected_order_arc_1046  -13
    arc_1_17_16  in_degree_1152  1
    arc_1_17_16  out_degree_1157  1
    arc_1_17_16  original_T_including_depot_unload_1178  1.4805184908215606e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_16  arc_capacity_1045  1
    load_1_17_16  free_load_conservation_1156  -1
    load_1_17_16  free_load_conservation_1162  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_18  arc_capacity_1047  -25
    arc_1_17_18  connected_order_arc_1048  -13
    arc_1_17_18  out_degree_1157  1
    arc_1_17_18  in_degree_1164  1
    arc_1_17_18  original_T_including_depot_unload_1178  1.4252778892498145e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_18  arc_capacity_1047  1
    load_1_17_18  free_load_conservation_1162  1
    load_1_17_18  free_load_conservation_1168  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_19  arc_capacity_1049  -25
    arc_1_17_19  connected_order_arc_1050  -13
    arc_1_17_19  out_degree_1157  1
    arc_1_17_19  in_degree_1170  1
    arc_1_17_19  original_T_including_depot_unload_1178  8.9135689158237335e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_19  arc_capacity_1049  1
    load_1_17_19  free_load_conservation_1162  1
    load_1_17_19  free_load_conservation_1174  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_0  arc_capacity_1051  -25
    arc_1_18_0  depot_return_or_bypass_1098  1
    arc_1_18_0  out_degree_1163  1
    arc_1_18_0  original_T_including_depot_unload_1178  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_0  arc_capacity_1051  1
    load_1_18_0  free_load_conservation_1168  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_5  arc_capacity_1052  -25
    arc_1_18_5  connected_order_arc_1053  -13
    arc_1_18_5  in_degree_1100  1
    arc_1_18_5  out_degree_1163  1
    arc_1_18_5  original_T_including_depot_unload_1178  1.6865101452371027e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_5  arc_capacity_1052  1
    load_1_18_5  segment_load_conservation_1103  -1
    load_1_18_5  segment_prefix_lb_1104  1
    load_1_18_5  segment_prefix_ub_1105  1
    load_1_18_5  free_load_conservation_1168  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_6  arc_capacity_1054  -25
    arc_1_18_6  connected_order_arc_1055  -13
    arc_1_18_6  in_degree_1107  1
    arc_1_18_6  out_degree_1163  1
    arc_1_18_6  original_T_including_depot_unload_1178  1706.88312024691
    MARKER    'MARKER'                 'INTEND'
    load_1_18_6  arc_capacity_1054  1
    load_1_18_6  segment_load_conservation_1110  -1
    load_1_18_6  segment_prefix_lb_1111  1
    load_1_18_6  segment_prefix_ub_1112  1
    load_1_18_6  free_load_conservation_1168  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_7  arc_capacity_1056  -25
    arc_1_18_7  connected_order_arc_1057  -13
    arc_1_18_7  in_degree_1114  1
    arc_1_18_7  out_degree_1163  1
    arc_1_18_7  original_T_including_depot_unload_1178  1.6087820579339759e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_7  arc_capacity_1056  1
    load_1_18_7  segment_load_conservation_1117  -1
    load_1_18_7  segment_prefix_lb_1118  1
    load_1_18_7  segment_prefix_ub_1119  1
    load_1_18_7  free_load_conservation_1168  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_8  arc_capacity_1058  -25
    arc_1_18_8  connected_order_arc_1059  -13
    arc_1_18_8  in_degree_1121  1
    arc_1_18_8  out_degree_1163  1
    arc_1_18_8  original_T_including_depot_unload_1178  7.2171835955896984e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_8  arc_capacity_1058  1
    load_1_18_8  segment_load_conservation_1124  -1
    load_1_18_8  segment_prefix_lb_1125  1
    load_1_18_8  segment_prefix_ub_1126  1
    load_1_18_8  free_load_conservation_1168  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_12  arc_capacity_1060  -25
    arc_1_18_12  connected_order_arc_1061  -13
    arc_1_18_12  in_degree_1128  1
    arc_1_18_12  out_degree_1163  1
    arc_1_18_12  original_T_including_depot_unload_1178  1.2587701383314870e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_12  arc_capacity_1060  1
    load_1_18_12  free_load_conservation_1132  -1
    load_1_18_12  free_load_conservation_1168  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_13  arc_capacity_1062  -25
    arc_1_18_13  connected_order_arc_1063  -13
    arc_1_18_13  in_degree_1134  1
    arc_1_18_13  out_degree_1163  1
    arc_1_18_13  original_T_including_depot_unload_1178  1.4479585101303876e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_13  arc_capacity_1062  1
    load_1_18_13  free_load_conservation_1138  -1
    load_1_18_13  free_load_conservation_1168  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_14  arc_capacity_1064  -25
    arc_1_18_14  connected_order_arc_1065  -13
    arc_1_18_14  in_degree_1140  1
    arc_1_18_14  out_degree_1163  1
    arc_1_18_14  original_T_including_depot_unload_1178  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_14  arc_capacity_1064  1
    load_1_18_14  free_load_conservation_1144  -1
    load_1_18_14  free_load_conservation_1168  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_15  arc_capacity_1066  -25
    arc_1_18_15  connected_order_arc_1067  -13
    arc_1_18_15  in_degree_1146  1
    arc_1_18_15  out_degree_1163  1
    arc_1_18_15  original_T_including_depot_unload_1178  1.2927779971523576e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_15  arc_capacity_1066  1
    load_1_18_15  free_load_conservation_1150  -1
    load_1_18_15  free_load_conservation_1168  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_16  arc_capacity_1068  -25
    arc_1_18_16  connected_order_arc_1069  -13
    arc_1_18_16  in_degree_1152  1
    arc_1_18_16  out_degree_1163  1
    arc_1_18_16  original_T_including_depot_unload_1178  1.6597164064313077e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_16  arc_capacity_1068  1
    load_1_18_16  free_load_conservation_1156  -1
    load_1_18_16  free_load_conservation_1168  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_17  arc_capacity_1070  -25
    arc_1_18_17  connected_order_arc_1071  -13
    arc_1_18_17  in_degree_1158  1
    arc_1_18_17  out_degree_1163  1
    arc_1_18_17  original_T_including_depot_unload_1178  1.4252778892498145e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_17  arc_capacity_1070  1
    load_1_18_17  free_load_conservation_1162  -1
    load_1_18_17  free_load_conservation_1168  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_19  arc_capacity_1072  -25
    arc_1_18_19  connected_order_arc_1073  -13
    arc_1_18_19  out_degree_1163  1
    arc_1_18_19  in_degree_1170  1
    arc_1_18_19  original_T_including_depot_unload_1178  5.3713048648006088e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_19  arc_capacity_1072  1
    load_1_18_19  free_load_conservation_1168  1
    load_1_18_19  free_load_conservation_1174  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_0  arc_capacity_1074  -25
    arc_1_19_0  depot_return_or_bypass_1098  1
    arc_1_19_0  out_degree_1169  1
    arc_1_19_0  original_T_including_depot_unload_1178  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_0  arc_capacity_1074  1
    load_1_19_0  free_load_conservation_1174  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_5  arc_capacity_1075  -25
    arc_1_19_5  connected_order_arc_1076  -13
    arc_1_19_5  in_degree_1100  1
    arc_1_19_5  out_degree_1169  1
    arc_1_19_5  original_T_including_depot_unload_1178  1.1663816070445826e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_5  arc_capacity_1075  1
    load_1_19_5  segment_load_conservation_1103  -1
    load_1_19_5  segment_prefix_lb_1104  1
    load_1_19_5  segment_prefix_ub_1105  1
    load_1_19_5  free_load_conservation_1174  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_6  arc_capacity_1077  -25
    arc_1_19_6  connected_order_arc_1078  -13
    arc_1_19_6  in_degree_1107  1
    arc_1_19_6  out_degree_1169  1
    arc_1_19_6  original_T_including_depot_unload_1178  1.2100678255370710e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_6  arc_capacity_1077  1
    load_1_19_6  segment_load_conservation_1110  -1
    load_1_19_6  segment_prefix_lb_1111  1
    load_1_19_6  segment_prefix_ub_1112  1
    load_1_19_6  free_load_conservation_1174  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_7  arc_capacity_1079  -25
    arc_1_19_7  connected_order_arc_1080  -13
    arc_1_19_7  in_degree_1114  1
    arc_1_19_7  out_degree_1169  1
    arc_1_19_7  original_T_including_depot_unload_1178  1.2253808824170035e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_7  arc_capacity_1079  1
    load_1_19_7  segment_load_conservation_1117  -1
    load_1_19_7  segment_prefix_lb_1118  1
    load_1_19_7  segment_prefix_ub_1119  1
    load_1_19_7  free_load_conservation_1174  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_8  arc_capacity_1081  -25
    arc_1_19_8  connected_order_arc_1082  -13
    arc_1_19_8  in_degree_1121  1
    arc_1_19_8  out_degree_1169  1
    arc_1_19_8  original_T_including_depot_unload_1178  4.9232225330062903e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_8  arc_capacity_1081  1
    load_1_19_8  segment_load_conservation_1124  -1
    load_1_19_8  segment_prefix_lb_1125  1
    load_1_19_8  segment_prefix_ub_1126  1
    load_1_19_8  free_load_conservation_1174  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_12  arc_capacity_1083  -25
    arc_1_19_12  connected_order_arc_1084  -13
    arc_1_19_12  in_degree_1128  1
    arc_1_19_12  out_degree_1169  1
    arc_1_19_12  original_T_including_depot_unload_1178  7.5634788469878674e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_12  arc_capacity_1083  1
    load_1_19_12  free_load_conservation_1132  -1
    load_1_19_12  free_load_conservation_1174  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_13  arc_capacity_1085  -25
    arc_1_19_13  connected_order_arc_1086  -13
    arc_1_19_13  in_degree_1134  1
    arc_1_19_13  out_degree_1169  1
    arc_1_19_13  original_T_including_depot_unload_1178  9.2235470209829464e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_13  arc_capacity_1085  1
    load_1_19_13  free_load_conservation_1138  -1
    load_1_19_13  free_load_conservation_1174  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_14  arc_capacity_1087  -25
    arc_1_19_14  connected_order_arc_1088  -13
    arc_1_19_14  in_degree_1140  1
    arc_1_19_14  out_degree_1169  1
    arc_1_19_14  original_T_including_depot_unload_1178  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_14  arc_capacity_1087  1
    load_1_19_14  free_load_conservation_1144  -1
    load_1_19_14  free_load_conservation_1174  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_15  arc_capacity_1089  -25
    arc_1_19_15  connected_order_arc_1090  -13
    arc_1_19_15  in_degree_1146  1
    arc_1_19_15  out_degree_1169  1
    arc_1_19_15  original_T_including_depot_unload_1178  7.5571464781430223e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_15  arc_capacity_1089  1
    load_1_19_15  free_load_conservation_1150  -1
    load_1_19_15  free_load_conservation_1174  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_16  arc_capacity_1091  -25
    arc_1_19_16  connected_order_arc_1092  -13
    arc_1_19_16  in_degree_1152  1
    arc_1_19_16  out_degree_1169  1
    arc_1_19_16  original_T_including_depot_unload_1178  6.1704611580490348e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_16  arc_capacity_1091  1
    load_1_19_16  free_load_conservation_1156  -1
    load_1_19_16  free_load_conservation_1174  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_17  arc_capacity_1093  -25
    arc_1_19_17  connected_order_arc_1094  -13
    arc_1_19_17  in_degree_1158  1
    arc_1_19_17  out_degree_1169  1
    arc_1_19_17  original_T_including_depot_unload_1178  8.9135689158237335e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_17  arc_capacity_1093  1
    load_1_19_17  free_load_conservation_1162  -1
    load_1_19_17  free_load_conservation_1174  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_18  arc_capacity_1095  -25
    arc_1_19_18  connected_order_arc_1096  -13
    arc_1_19_18  in_degree_1164  1
    arc_1_19_18  out_degree_1169  1
    arc_1_19_18  original_T_including_depot_unload_1178  5.3713048648006088e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_18  arc_capacity_1095  1
    load_1_19_18  free_load_conservation_1168  -1
    load_1_19_18  free_load_conservation_1174  1
    visit_2_9  out_degree_1424  -1
    visit_2_9  in_degree_1425  -1
    visit_2_9  order_active_lb_1426  -1
    visit_2_9  order_active_ub_1427  -11
    order_2_9  connected_order_arc_1193  -1
    order_2_9  connected_order_arc_1195  -1
    order_2_9  connected_order_arc_1197  -1
    order_2_9  connected_order_arc_1199  -1
    order_2_9  connected_order_arc_1201  -1
    order_2_9  connected_order_arc_1203  -1
    order_2_9  connected_order_arc_1205  -1
    order_2_9  connected_order_arc_1207  -1
    order_2_9  connected_order_arc_1209  -1
    order_2_9  connected_order_arc_1211  -1
    order_2_9  connected_order_arc_1214  1
    order_2_9  connected_order_arc_1235  1
    order_2_9  connected_order_arc_1256  1
    order_2_9  connected_order_arc_1277  1
    order_2_9  connected_order_arc_1298  1
    order_2_9  connected_order_arc_1319  1
    order_2_9  connected_order_arc_1340  1
    order_2_9  connected_order_arc_1361  1
    order_2_9  connected_order_arc_1382  1
    order_2_9  connected_order_arc_1403  1
    order_2_9  order_active_lb_1426  1
    order_2_9  order_active_ub_1427  1
    order_2_9  fixed_segment_relative_order_1493  -1
    visit_2_10  out_degree_1431  -1
    visit_2_10  in_degree_1432  -1
    visit_2_10  order_active_lb_1433  -1
    visit_2_10  order_active_ub_1434  -11
    order_2_10  connected_order_arc_1193  1
    order_2_10  connected_order_arc_1214  -1
    order_2_10  connected_order_arc_1216  -1
    order_2_10  connected_order_arc_1218  -1
    order_2_10  connected_order_arc_1220  -1
    order_2_10  connected_order_arc_1222  -1
    order_2_10  connected_order_arc_1224  -1
    order_2_10  connected_order_arc_1226  -1
    order_2_10  connected_order_arc_1228  -1
    order_2_10  connected_order_arc_1230  -1
    order_2_10  connected_order_arc_1232  -1
    order_2_10  connected_order_arc_1237  1
    order_2_10  connected_order_arc_1258  1
    order_2_10  connected_order_arc_1279  1
    order_2_10  connected_order_arc_1300  1
    order_2_10  connected_order_arc_1321  1
    order_2_10  connected_order_arc_1342  1
    order_2_10  connected_order_arc_1363  1
    order_2_10  connected_order_arc_1384  1
    order_2_10  connected_order_arc_1405  1
    order_2_10  order_active_lb_1433  1
    order_2_10  order_active_ub_1434  1
    order_2_10  fixed_segment_relative_order_1493  1
    order_2_10  fixed_segment_relative_order_1494  -1
    visit_2_11  out_degree_1438  -1
    visit_2_11  in_degree_1439  -1
    visit_2_11  order_active_lb_1440  -1
    visit_2_11  order_active_ub_1441  -11
    order_2_11  connected_order_arc_1195  1
    order_2_11  connected_order_arc_1216  1
    order_2_11  connected_order_arc_1235  -1
    order_2_11  connected_order_arc_1237  -1
    order_2_11  connected_order_arc_1239  -1
    order_2_11  connected_order_arc_1241  -1
    order_2_11  connected_order_arc_1243  -1
    order_2_11  connected_order_arc_1245  -1
    order_2_11  connected_order_arc_1247  -1
    order_2_11  connected_order_arc_1249  -1
    order_2_11  connected_order_arc_1251  -1
    order_2_11  connected_order_arc_1253  -1
    order_2_11  connected_order_arc_1260  1
    order_2_11  connected_order_arc_1281  1
    order_2_11  connected_order_arc_1302  1
    order_2_11  connected_order_arc_1323  1
    order_2_11  connected_order_arc_1344  1
    order_2_11  connected_order_arc_1365  1
    order_2_11  connected_order_arc_1386  1
    order_2_11  connected_order_arc_1407  1
    order_2_11  order_active_lb_1440  1
    order_2_11  order_active_ub_1441  1
    order_2_11  fixed_segment_relative_order_1494  1
    visit_2_12  out_degree_1445  -1
    visit_2_12  in_degree_1446  -1
    visit_2_12  order_active_lb_1447  -1
    visit_2_12  order_active_ub_1448  -11
    visit_2_12  service_visit_def_1449  -1
    order_2_12  connected_order_arc_1197  1
    order_2_12  connected_order_arc_1218  1
    order_2_12  connected_order_arc_1239  1
    order_2_12  connected_order_arc_1256  -1
    order_2_12  connected_order_arc_1258  -1
    order_2_12  connected_order_arc_1260  -1
    order_2_12  connected_order_arc_1262  -1
    order_2_12  connected_order_arc_1264  -1
    order_2_12  connected_order_arc_1266  -1
    order_2_12  connected_order_arc_1268  -1
    order_2_12  connected_order_arc_1270  -1
    order_2_12  connected_order_arc_1272  -1
    order_2_12  connected_order_arc_1274  -1
    order_2_12  connected_order_arc_1283  1
    order_2_12  connected_order_arc_1304  1
    order_2_12  connected_order_arc_1325  1
    order_2_12  connected_order_arc_1346  1
    order_2_12  connected_order_arc_1367  1
    order_2_12  connected_order_arc_1388  1
    order_2_12  connected_order_arc_1409  1
    order_2_12  order_active_lb_1447  1
    order_2_12  order_active_ub_1448  1
    visit_2_13  out_degree_1451  -1
    visit_2_13  in_degree_1452  -1
    visit_2_13  order_active_lb_1453  -1
    visit_2_13  order_active_ub_1454  -11
    visit_2_13  service_visit_def_1455  -1
    order_2_13  connected_order_arc_1199  1
    order_2_13  connected_order_arc_1220  1
    order_2_13  connected_order_arc_1241  1
    order_2_13  connected_order_arc_1262  1
    order_2_13  connected_order_arc_1277  -1
    order_2_13  connected_order_arc_1279  -1
    order_2_13  connected_order_arc_1281  -1
    order_2_13  connected_order_arc_1283  -1
    order_2_13  connected_order_arc_1285  -1
    order_2_13  connected_order_arc_1287  -1
    order_2_13  connected_order_arc_1289  -1
    order_2_13  connected_order_arc_1291  -1
    order_2_13  connected_order_arc_1293  -1
    order_2_13  connected_order_arc_1295  -1
    order_2_13  connected_order_arc_1306  1
    order_2_13  connected_order_arc_1327  1
    order_2_13  connected_order_arc_1348  1
    order_2_13  connected_order_arc_1369  1
    order_2_13  connected_order_arc_1390  1
    order_2_13  connected_order_arc_1411  1
    order_2_13  order_active_lb_1453  1
    order_2_13  order_active_ub_1454  1
    visit_2_14  out_degree_1457  -1
    visit_2_14  in_degree_1458  -1
    visit_2_14  order_active_lb_1459  -1
    visit_2_14  order_active_ub_1460  -11
    visit_2_14  service_visit_def_1461  -1
    order_2_14  connected_order_arc_1201  1
    order_2_14  connected_order_arc_1222  1
    order_2_14  connected_order_arc_1243  1
    order_2_14  connected_order_arc_1264  1
    order_2_14  connected_order_arc_1285  1
    order_2_14  connected_order_arc_1298  -1
    order_2_14  connected_order_arc_1300  -1
    order_2_14  connected_order_arc_1302  -1
    order_2_14  connected_order_arc_1304  -1
    order_2_14  connected_order_arc_1306  -1
    order_2_14  connected_order_arc_1308  -1
    order_2_14  connected_order_arc_1310  -1
    order_2_14  connected_order_arc_1312  -1
    order_2_14  connected_order_arc_1314  -1
    order_2_14  connected_order_arc_1316  -1
    order_2_14  connected_order_arc_1329  1
    order_2_14  connected_order_arc_1350  1
    order_2_14  connected_order_arc_1371  1
    order_2_14  connected_order_arc_1392  1
    order_2_14  connected_order_arc_1413  1
    order_2_14  order_active_lb_1459  1
    order_2_14  order_active_ub_1460  1
    visit_2_15  out_degree_1463  -1
    visit_2_15  in_degree_1464  -1
    visit_2_15  order_active_lb_1465  -1
    visit_2_15  order_active_ub_1466  -11
    visit_2_15  service_visit_def_1467  -1
    order_2_15  connected_order_arc_1203  1
    order_2_15  connected_order_arc_1224  1
    order_2_15  connected_order_arc_1245  1
    order_2_15  connected_order_arc_1266  1
    order_2_15  connected_order_arc_1287  1
    order_2_15  connected_order_arc_1308  1
    order_2_15  connected_order_arc_1319  -1
    order_2_15  connected_order_arc_1321  -1
    order_2_15  connected_order_arc_1323  -1
    order_2_15  connected_order_arc_1325  -1
    order_2_15  connected_order_arc_1327  -1
    order_2_15  connected_order_arc_1329  -1
    order_2_15  connected_order_arc_1331  -1
    order_2_15  connected_order_arc_1333  -1
    order_2_15  connected_order_arc_1335  -1
    order_2_15  connected_order_arc_1337  -1
    order_2_15  connected_order_arc_1352  1
    order_2_15  connected_order_arc_1373  1
    order_2_15  connected_order_arc_1394  1
    order_2_15  connected_order_arc_1415  1
    order_2_15  order_active_lb_1465  1
    order_2_15  order_active_ub_1466  1
    visit_2_16  out_degree_1469  -1
    visit_2_16  in_degree_1470  -1
    visit_2_16  order_active_lb_1471  -1
    visit_2_16  order_active_ub_1472  -11
    visit_2_16  service_visit_def_1473  -1
    order_2_16  connected_order_arc_1205  1
    order_2_16  connected_order_arc_1226  1
    order_2_16  connected_order_arc_1247  1
    order_2_16  connected_order_arc_1268  1
    order_2_16  connected_order_arc_1289  1
    order_2_16  connected_order_arc_1310  1
    order_2_16  connected_order_arc_1331  1
    order_2_16  connected_order_arc_1340  -1
    order_2_16  connected_order_arc_1342  -1
    order_2_16  connected_order_arc_1344  -1
    order_2_16  connected_order_arc_1346  -1
    order_2_16  connected_order_arc_1348  -1
    order_2_16  connected_order_arc_1350  -1
    order_2_16  connected_order_arc_1352  -1
    order_2_16  connected_order_arc_1354  -1
    order_2_16  connected_order_arc_1356  -1
    order_2_16  connected_order_arc_1358  -1
    order_2_16  connected_order_arc_1375  1
    order_2_16  connected_order_arc_1396  1
    order_2_16  connected_order_arc_1417  1
    order_2_16  order_active_lb_1471  1
    order_2_16  order_active_ub_1472  1
    visit_2_17  out_degree_1475  -1
    visit_2_17  in_degree_1476  -1
    visit_2_17  order_active_lb_1477  -1
    visit_2_17  order_active_ub_1478  -11
    visit_2_17  service_visit_def_1479  -1
    order_2_17  connected_order_arc_1207  1
    order_2_17  connected_order_arc_1228  1
    order_2_17  connected_order_arc_1249  1
    order_2_17  connected_order_arc_1270  1
    order_2_17  connected_order_arc_1291  1
    order_2_17  connected_order_arc_1312  1
    order_2_17  connected_order_arc_1333  1
    order_2_17  connected_order_arc_1354  1
    order_2_17  connected_order_arc_1361  -1
    order_2_17  connected_order_arc_1363  -1
    order_2_17  connected_order_arc_1365  -1
    order_2_17  connected_order_arc_1367  -1
    order_2_17  connected_order_arc_1369  -1
    order_2_17  connected_order_arc_1371  -1
    order_2_17  connected_order_arc_1373  -1
    order_2_17  connected_order_arc_1375  -1
    order_2_17  connected_order_arc_1377  -1
    order_2_17  connected_order_arc_1379  -1
    order_2_17  connected_order_arc_1398  1
    order_2_17  connected_order_arc_1419  1
    order_2_17  order_active_lb_1477  1
    order_2_17  order_active_ub_1478  1
    visit_2_18  out_degree_1481  -1
    visit_2_18  in_degree_1482  -1
    visit_2_18  order_active_lb_1483  -1
    visit_2_18  order_active_ub_1484  -11
    visit_2_18  service_visit_def_1485  -1
    order_2_18  connected_order_arc_1209  1
    order_2_18  connected_order_arc_1230  1
    order_2_18  connected_order_arc_1251  1
    order_2_18  connected_order_arc_1272  1
    order_2_18  connected_order_arc_1293  1
    order_2_18  connected_order_arc_1314  1
    order_2_18  connected_order_arc_1335  1
    order_2_18  connected_order_arc_1356  1
    order_2_18  connected_order_arc_1377  1
    order_2_18  connected_order_arc_1382  -1
    order_2_18  connected_order_arc_1384  -1
    order_2_18  connected_order_arc_1386  -1
    order_2_18  connected_order_arc_1388  -1
    order_2_18  connected_order_arc_1390  -1
    order_2_18  connected_order_arc_1392  -1
    order_2_18  connected_order_arc_1394  -1
    order_2_18  connected_order_arc_1396  -1
    order_2_18  connected_order_arc_1398  -1
    order_2_18  connected_order_arc_1400  -1
    order_2_18  connected_order_arc_1421  1
    order_2_18  order_active_lb_1483  1
    order_2_18  order_active_ub_1484  1
    visit_2_19  out_degree_1487  -1
    visit_2_19  in_degree_1488  -1
    visit_2_19  order_active_lb_1489  -1
    visit_2_19  order_active_ub_1490  -11
    visit_2_19  service_visit_def_1491  -1
    order_2_19  connected_order_arc_1211  1
    order_2_19  connected_order_arc_1232  1
    order_2_19  connected_order_arc_1253  1
    order_2_19  connected_order_arc_1274  1
    order_2_19  connected_order_arc_1295  1
    order_2_19  connected_order_arc_1316  1
    order_2_19  connected_order_arc_1337  1
    order_2_19  connected_order_arc_1358  1
    order_2_19  connected_order_arc_1379  1
    order_2_19  connected_order_arc_1400  1
    order_2_19  connected_order_arc_1403  -1
    order_2_19  connected_order_arc_1405  -1
    order_2_19  connected_order_arc_1407  -1
    order_2_19  connected_order_arc_1409  -1
    order_2_19  connected_order_arc_1411  -1
    order_2_19  connected_order_arc_1413  -1
    order_2_19  connected_order_arc_1415  -1
    order_2_19  connected_order_arc_1417  -1
    order_2_19  connected_order_arc_1419  -1
    order_2_19  connected_order_arc_1421  -1
    order_2_19  order_active_lb_1489  1
    order_2_19  order_active_ub_1490  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_0  arc_capacity_1179  -30
    arc_2_0_0  depot_departure_or_bypass_1422  1
    arc_2_0_0  depot_return_or_bypass_1423  1
    MARKER    'MARKER'                 'INTEND'
    load_2_0_0  arc_capacity_1179  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_9  arc_capacity_1180  -30
    arc_2_0_9  depot_departure_or_bypass_1422  1
    arc_2_0_9  in_degree_1425  1
    arc_2_0_9  original_T_including_depot_unload_1495  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_9  arc_capacity_1180  1
    load_2_0_9  segment_load_conservation_1428  -1
    load_2_0_9  segment_prefix_lb_1429  1
    load_2_0_9  segment_prefix_ub_1430  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_10  arc_capacity_1181  -30
    arc_2_0_10  depot_departure_or_bypass_1422  1
    arc_2_0_10  in_degree_1432  1
    arc_2_0_10  original_T_including_depot_unload_1495  1.4567038050199781e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_10  arc_capacity_1181  1
    load_2_0_10  segment_load_conservation_1435  -1
    load_2_0_10  segment_prefix_lb_1436  1
    load_2_0_10  segment_prefix_ub_1437  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_11  arc_capacity_1182  -30
    arc_2_0_11  depot_departure_or_bypass_1422  1
    arc_2_0_11  in_degree_1439  1
    arc_2_0_11  original_T_including_depot_unload_1495  1.3396590612935172e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_11  arc_capacity_1182  1
    load_2_0_11  segment_load_conservation_1442  -1
    load_2_0_11  segment_prefix_lb_1443  1
    load_2_0_11  segment_prefix_ub_1444  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_12  arc_capacity_1183  -30
    arc_2_0_12  depot_departure_or_bypass_1422  1
    arc_2_0_12  in_degree_1446  1
    arc_2_0_12  original_T_including_depot_unload_1495  8.7918533905669346e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_12  arc_capacity_1183  1
    load_2_0_12  free_load_conservation_1450  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_13  arc_capacity_1184  -30
    arc_2_0_13  depot_departure_or_bypass_1422  1
    arc_2_0_13  in_degree_1452  1
    arc_2_0_13  original_T_including_depot_unload_1495  1.0479182987243917e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_13  arc_capacity_1184  1
    load_2_0_13  free_load_conservation_1456  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_14  arc_capacity_1185  -30
    arc_2_0_14  depot_departure_or_bypass_1422  1
    arc_2_0_14  in_degree_1458  1
    arc_2_0_14  original_T_including_depot_unload_1495  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_14  arc_capacity_1185  1
    load_2_0_14  free_load_conservation_1462  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_15  arc_capacity_1186  -30
    arc_2_0_15  depot_departure_or_bypass_1422  1
    arc_2_0_15  in_degree_1464  1
    arc_2_0_15  original_T_including_depot_unload_1495  8.7749189782983967e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_15  arc_capacity_1186  1
    load_2_0_15  free_load_conservation_1468  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_16  arc_capacity_1187  -30
    arc_2_0_16  depot_departure_or_bypass_1422  1
    arc_2_0_16  in_degree_1470  1
    arc_2_0_16  original_T_including_depot_unload_1495  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_16  arc_capacity_1187  1
    load_2_0_16  free_load_conservation_1474  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_17  arc_capacity_1188  -30
    arc_2_0_17  depot_departure_or_bypass_1422  1
    arc_2_0_17  in_degree_1476  1
    arc_2_0_17  original_T_including_depot_unload_1495  1.0088905112952611e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_17  arc_capacity_1188  1
    load_2_0_17  free_load_conservation_1480  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_18  arc_capacity_1189  -30
    arc_2_0_18  depot_departure_or_bypass_1422  1
    arc_2_0_18  in_degree_1482  1
    arc_2_0_18  original_T_including_depot_unload_1495  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_18  arc_capacity_1189  1
    load_2_0_18  free_load_conservation_1486  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_19  arc_capacity_1190  -30
    arc_2_0_19  depot_departure_or_bypass_1422  1
    arc_2_0_19  in_degree_1488  1
    arc_2_0_19  original_T_including_depot_unload_1495  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_19  arc_capacity_1190  1
    load_2_0_19  free_load_conservation_1492  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_0  arc_capacity_1191  -30
    arc_2_9_0  depot_return_or_bypass_1423  1
    arc_2_9_0  out_degree_1424  1
    arc_2_9_0  original_T_including_depot_unload_1495  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_9_0  arc_capacity_1191  1
    load_2_9_0  segment_load_conservation_1428  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_10  arc_capacity_1192  -30
    arc_2_9_10  connected_order_arc_1193  -12
    arc_2_9_10  out_degree_1424  1
    arc_2_9_10  in_degree_1432  1
    arc_2_9_10  original_T_including_depot_unload_1495  1.2835993572680911e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_9_10  arc_capacity_1192  1
    load_2_9_10  segment_load_conservation_1428  1
    load_2_9_10  segment_load_conservation_1435  -1
    load_2_9_10  segment_prefix_lb_1436  1
    load_2_9_10  segment_prefix_ub_1437  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_11  arc_capacity_1194  -30
    arc_2_9_11  connected_order_arc_1195  -12
    arc_2_9_11  out_degree_1424  1
    arc_2_9_11  in_degree_1439  1
    arc_2_9_11  original_T_including_depot_unload_1495  1.2717918724165304e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_9_11  arc_capacity_1194  1
    load_2_9_11  segment_load_conservation_1428  1
    load_2_9_11  segment_load_conservation_1442  -1
    load_2_9_11  segment_prefix_lb_1443  1
    load_2_9_11  segment_prefix_ub_1444  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_12  arc_capacity_1196  -30
    arc_2_9_12  connected_order_arc_1197  -12
    arc_2_9_12  out_degree_1424  1
    arc_2_9_12  in_degree_1446  1
    arc_2_9_12  original_T_including_depot_unload_1495  1.0311494902403294e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_9_12  arc_capacity_1196  1
    load_2_9_12  segment_load_conservation_1428  1
    load_2_9_12  free_load_conservation_1450  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_13  arc_capacity_1198  -30
    arc_2_9_13  connected_order_arc_1199  -12
    arc_2_9_13  out_degree_1424  1
    arc_2_9_13  in_degree_1452  1
    arc_2_9_13  original_T_including_depot_unload_1495  1.2309802293463208e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_9_13  arc_capacity_1198  1
    load_2_9_13  segment_load_conservation_1428  1
    load_2_9_13  free_load_conservation_1456  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_14  arc_capacity_1200  -30
    arc_2_9_14  connected_order_arc_1201  -12
    arc_2_9_14  out_degree_1424  1
    arc_2_9_14  in_degree_1458  1
    arc_2_9_14  original_T_including_depot_unload_1495  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_9_14  arc_capacity_1200  1
    load_2_9_14  segment_load_conservation_1428  1
    load_2_9_14  free_load_conservation_1462  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_15  arc_capacity_1202  -30
    arc_2_9_15  connected_order_arc_1203  -12
    arc_2_9_15  out_degree_1424  1
    arc_2_9_15  in_degree_1464  1
    arc_2_9_15  original_T_including_depot_unload_1495  1.1005939447212634e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_9_15  arc_capacity_1202  1
    load_2_9_15  segment_load_conservation_1428  1
    load_2_9_15  free_load_conservation_1468  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_16  arc_capacity_1204  -30
    arc_2_9_16  connected_order_arc_1205  -12
    arc_2_9_16  out_degree_1424  1
    arc_2_9_16  in_degree_1470  1
    arc_2_9_16  original_T_including_depot_unload_1495  3.8790073962518773e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_9_16  arc_capacity_1204  1
    load_2_9_16  segment_load_conservation_1428  1
    load_2_9_16  free_load_conservation_1474  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_17  arc_capacity_1206  -30
    arc_2_9_17  connected_order_arc_1207  -12
    arc_2_9_17  out_degree_1424  1
    arc_2_9_17  in_degree_1476  1
    arc_2_9_17  original_T_including_depot_unload_1495  1.2442780266664952e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_9_17  arc_capacity_1206  1
    load_2_9_17  segment_load_conservation_1428  1
    load_2_9_17  free_load_conservation_1480  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_18  arc_capacity_1208  -30
    arc_2_9_18  connected_order_arc_1209  -12
    arc_2_9_18  out_degree_1424  1
    arc_2_9_18  in_degree_1482  1
    arc_2_9_18  original_T_including_depot_unload_1495  2.4083746437975364e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_9_18  arc_capacity_1208  1
    load_2_9_18  segment_load_conservation_1428  1
    load_2_9_18  free_load_conservation_1486  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_19  arc_capacity_1210  -30
    arc_2_9_19  connected_order_arc_1211  -12
    arc_2_9_19  out_degree_1424  1
    arc_2_9_19  in_degree_1488  1
    arc_2_9_19  original_T_including_depot_unload_1495  359.975566576564
    MARKER    'MARKER'                 'INTEND'
    load_2_9_19  arc_capacity_1210  1
    load_2_9_19  segment_load_conservation_1428  1
    load_2_9_19  free_load_conservation_1492  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_0  arc_capacity_1212  -30
    arc_2_10_0  depot_return_or_bypass_1423  1
    arc_2_10_0  out_degree_1431  1
    arc_2_10_0  original_T_including_depot_unload_1495  1.2506062209426416e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_0  arc_capacity_1212  1
    load_2_10_0  segment_load_conservation_1435  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_9  arc_capacity_1213  -30
    arc_2_10_9  connected_order_arc_1214  -12
    arc_2_10_9  in_degree_1425  1
    arc_2_10_9  out_degree_1431  1
    arc_2_10_9  original_T_including_depot_unload_1495  1.0138993437494995e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_9  arc_capacity_1213  1
    load_2_10_9  segment_load_conservation_1428  -1
    load_2_10_9  segment_prefix_lb_1429  1
    load_2_10_9  segment_prefix_ub_1430  1
    load_2_10_9  segment_load_conservation_1435  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_11  arc_capacity_1215  -30
    arc_2_10_11  connected_order_arc_1216  -12
    arc_2_10_11  out_degree_1431  1
    arc_2_10_11  in_degree_1439  1
    arc_2_10_11  original_T_including_depot_unload_1495  1.9038107656775676e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_11  arc_capacity_1215  1
    load_2_10_11  segment_load_conservation_1435  1
    load_2_10_11  segment_load_conservation_1442  -1
    load_2_10_11  segment_prefix_lb_1443  1
    load_2_10_11  segment_prefix_ub_1444  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_12  arc_capacity_1217  -30
    arc_2_10_12  connected_order_arc_1218  -12
    arc_2_10_12  out_degree_1431  1
    arc_2_10_12  in_degree_1446  1
    arc_2_10_12  original_T_including_depot_unload_1495  1.5636076207019653e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_12  arc_capacity_1217  1
    load_2_10_12  segment_load_conservation_1435  1
    load_2_10_12  free_load_conservation_1450  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_13  arc_capacity_1219  -30
    arc_2_10_13  connected_order_arc_1220  -12
    arc_2_10_13  out_degree_1431  1
    arc_2_10_13  in_degree_1452  1
    arc_2_10_13  original_T_including_depot_unload_1495  1.8050468619497597e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_13  arc_capacity_1219  1
    load_2_10_13  segment_load_conservation_1435  1
    load_2_10_13  free_load_conservation_1456  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_14  arc_capacity_1221  -30
    arc_2_10_14  connected_order_arc_1222  -12
    arc_2_10_14  out_degree_1431  1
    arc_2_10_14  in_degree_1458  1
    arc_2_10_14  original_T_including_depot_unload_1495  1.4255422670497167e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_14  arc_capacity_1221  1
    load_2_10_14  segment_load_conservation_1435  1
    load_2_10_14  free_load_conservation_1462  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_15  arc_capacity_1223  -30
    arc_2_10_15  connected_order_arc_1224  -12
    arc_2_10_15  out_degree_1431  1
    arc_2_10_15  in_degree_1464  1
    arc_2_10_15  original_T_including_depot_unload_1495  1.8250469514445369e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_15  arc_capacity_1223  1
    load_2_10_15  segment_load_conservation_1435  1
    load_2_10_15  free_load_conservation_1468  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_16  arc_capacity_1225  -30
    arc_2_10_16  connected_order_arc_1226  -12
    arc_2_10_16  out_degree_1431  1
    arc_2_10_16  in_degree_1470  1
    arc_2_10_16  original_T_including_depot_unload_1495  1.2335670980381785e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_16  arc_capacity_1225  1
    load_2_10_16  segment_load_conservation_1435  1
    load_2_10_16  free_load_conservation_1474  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_17  arc_capacity_1227  -30
    arc_2_10_17  connected_order_arc_1228  -12
    arc_2_10_17  out_degree_1431  1
    arc_2_10_17  in_degree_1476  1
    arc_2_10_17  original_T_including_depot_unload_1495  1.9912760202020529e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_17  arc_capacity_1227  1
    load_2_10_17  segment_load_conservation_1435  1
    load_2_10_17  free_load_conservation_1480  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_18  arc_capacity_1229  -30
    arc_2_10_18  connected_order_arc_1230  -12
    arc_2_10_18  out_degree_1431  1
    arc_2_10_18  in_degree_1482  1
    arc_2_10_18  original_T_including_depot_unload_1495  1.0874822831610163e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_18  arc_capacity_1229  1
    load_2_10_18  segment_load_conservation_1435  1
    load_2_10_18  free_load_conservation_1486  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_19  arc_capacity_1231  -30
    arc_2_10_19  connected_order_arc_1232  -12
    arc_2_10_19  out_degree_1431  1
    arc_2_10_19  in_degree_1488  1
    arc_2_10_19  original_T_including_depot_unload_1495  1.2866008878928703e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_19  arc_capacity_1231  1
    load_2_10_19  segment_load_conservation_1435  1
    load_2_10_19  free_load_conservation_1492  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_0  arc_capacity_1233  -30
    arc_2_11_0  depot_return_or_bypass_1423  1
    arc_2_11_0  out_degree_1438  1
    arc_2_11_0  original_T_including_depot_unload_1495  9.5330620720858735e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_0  arc_capacity_1233  1
    load_2_11_0  segment_load_conservation_1442  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_9  arc_capacity_1234  -30
    arc_2_11_9  connected_order_arc_1235  -12
    arc_2_11_9  in_degree_1425  1
    arc_2_11_9  out_degree_1438  1
    arc_2_11_9  original_T_including_depot_unload_1495  7.8947565022471792e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_9  arc_capacity_1234  1
    load_2_11_9  segment_load_conservation_1428  -1
    load_2_11_9  segment_prefix_lb_1429  1
    load_2_11_9  segment_prefix_ub_1430  1
    load_2_11_9  segment_load_conservation_1442  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_10  arc_capacity_1236  -30
    arc_2_11_10  connected_order_arc_1237  -12
    arc_2_11_10  in_degree_1432  1
    arc_2_11_10  out_degree_1438  1
    arc_2_11_10  original_T_including_depot_unload_1495  1.7571531345240103e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_10  arc_capacity_1236  1
    load_2_11_10  segment_load_conservation_1435  -1
    load_2_11_10  segment_prefix_lb_1436  1
    load_2_11_10  segment_prefix_ub_1437  1
    load_2_11_10  segment_load_conservation_1442  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_12  arc_capacity_1238  -30
    arc_2_11_12  connected_order_arc_1239  -12
    arc_2_11_12  out_degree_1438  1
    arc_2_11_12  in_degree_1446  1
    arc_2_11_12  original_T_including_depot_unload_1495  1.8130068061837439e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_12  arc_capacity_1238  1
    load_2_11_12  segment_load_conservation_1442  1
    load_2_11_12  free_load_conservation_1450  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_13  arc_capacity_1240  -30
    arc_2_11_13  connected_order_arc_1241  -12
    arc_2_11_13  out_degree_1438  1
    arc_2_11_13  in_degree_1452  1
    arc_2_11_13  original_T_including_depot_unload_1495  1.9981042624472673e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_13  arc_capacity_1240  1
    load_2_11_13  segment_load_conservation_1442  1
    load_2_11_13  free_load_conservation_1456  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_14  arc_capacity_1242  -30
    arc_2_11_14  connected_order_arc_1243  -12
    arc_2_11_14  out_degree_1438  1
    arc_2_11_14  in_degree_1458  1
    arc_2_11_14  original_T_including_depot_unload_1495  1.9462564869425171e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_14  arc_capacity_1242  1
    load_2_11_14  segment_load_conservation_1442  1
    load_2_11_14  free_load_conservation_1462  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_15  arc_capacity_1244  -30
    arc_2_11_15  connected_order_arc_1245  -12
    arc_2_11_15  out_degree_1438  1
    arc_2_11_15  in_degree_1464  1
    arc_2_11_15  original_T_including_depot_unload_1495  1.8269270746185791e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_15  arc_capacity_1244  1
    load_2_11_15  segment_load_conservation_1442  1
    load_2_11_15  free_load_conservation_1468  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_16  arc_capacity_1246  -30
    arc_2_11_16  connected_order_arc_1247  -12
    arc_2_11_16  out_degree_1438  1
    arc_2_11_16  in_degree_1470  1
    arc_2_11_16  original_T_including_depot_unload_1495  4.6772747357218117e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_16  arc_capacity_1246  1
    load_2_11_16  segment_load_conservation_1442  1
    load_2_11_16  free_load_conservation_1474  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_17  arc_capacity_1248  -30
    arc_2_11_17  connected_order_arc_1249  -12
    arc_2_11_17  out_degree_1438  1
    arc_2_11_17  in_degree_1476  1
    arc_2_11_17  original_T_including_depot_unload_1495  1.9482201819157062e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_17  arc_capacity_1248  1
    load_2_11_17  segment_load_conservation_1442  1
    load_2_11_17  free_load_conservation_1480  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_18  arc_capacity_1250  -30
    arc_2_11_18  connected_order_arc_1251  -12
    arc_2_11_18  out_degree_1438  1
    arc_2_11_18  in_degree_1482  1
    arc_2_11_18  original_T_including_depot_unload_1495  5.5448403235604167e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_18  arc_capacity_1250  1
    load_2_11_18  segment_load_conservation_1442  1
    load_2_11_18  free_load_conservation_1486  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_19  arc_capacity_1252  -30
    arc_2_11_19  connected_order_arc_1253  -12
    arc_2_11_19  out_degree_1438  1
    arc_2_11_19  in_degree_1488  1
    arc_2_11_19  original_T_including_depot_unload_1495  1.0783470469841145e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_19  arc_capacity_1252  1
    load_2_11_19  segment_load_conservation_1442  1
    load_2_11_19  free_load_conservation_1492  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_0  arc_capacity_1254  -30
    arc_2_12_0  depot_return_or_bypass_1423  1
    arc_2_12_0  out_degree_1445  1
    arc_2_12_0  original_T_including_depot_unload_1495  8.7918533905669346e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_0  arc_capacity_1254  1
    load_2_12_0  free_load_conservation_1450  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_9  arc_capacity_1255  -30
    arc_2_12_9  connected_order_arc_1256  -12
    arc_2_12_9  in_degree_1425  1
    arc_2_12_9  out_degree_1445  1
    arc_2_12_9  original_T_including_depot_unload_1495  1.0311494902403294e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_9  arc_capacity_1255  1
    load_2_12_9  segment_load_conservation_1428  -1
    load_2_12_9  segment_prefix_lb_1429  1
    load_2_12_9  segment_prefix_ub_1430  1
    load_2_12_9  free_load_conservation_1450  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_10  arc_capacity_1257  -30
    arc_2_12_10  connected_order_arc_1258  -12
    arc_2_12_10  in_degree_1432  1
    arc_2_12_10  out_degree_1445  1
    arc_2_12_10  original_T_including_depot_unload_1495  1.4516198129136008e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_10  arc_capacity_1257  1
    load_2_12_10  segment_load_conservation_1435  -1
    load_2_12_10  segment_prefix_lb_1436  1
    load_2_12_10  segment_prefix_ub_1437  1
    load_2_12_10  free_load_conservation_1450  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_11  arc_capacity_1259  -30
    arc_2_12_11  connected_order_arc_1260  -12
    arc_2_12_11  in_degree_1439  1
    arc_2_12_11  out_degree_1445  1
    arc_2_12_11  original_T_including_depot_unload_1495  2.2144644790128582e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_11  arc_capacity_1259  1
    load_2_12_11  segment_load_conservation_1442  -1
    load_2_12_11  segment_prefix_lb_1443  1
    load_2_12_11  segment_prefix_ub_1444  1
    load_2_12_11  free_load_conservation_1450  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_13  arc_capacity_1261  -30
    arc_2_12_13  connected_order_arc_1262  -12
    arc_2_12_13  out_degree_1445  1
    arc_2_12_13  in_degree_1452  1
    arc_2_12_13  original_T_including_depot_unload_1495  2.4155873404211835e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_13  arc_capacity_1261  1
    load_2_12_13  free_load_conservation_1450  1
    load_2_12_13  free_load_conservation_1456  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_14  arc_capacity_1263  -30
    arc_2_12_14  connected_order_arc_1264  -12
    arc_2_12_14  out_degree_1445  1
    arc_2_12_14  in_degree_1458  1
    arc_2_12_14  original_T_including_depot_unload_1495  3.6824909986567474e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_14  arc_capacity_1263  1
    load_2_12_14  free_load_conservation_1450  1
    load_2_12_14  free_load_conservation_1462  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_15  arc_capacity_1265  -30
    arc_2_12_15  connected_order_arc_1266  -12
    arc_2_12_15  out_degree_1445  1
    arc_2_12_15  in_degree_1464  1
    arc_2_12_15  original_T_including_depot_unload_1495  3.6821827312741834e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_15  arc_capacity_1265  1
    load_2_12_15  free_load_conservation_1450  1
    load_2_12_15  free_load_conservation_1468  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_16  arc_capacity_1267  -30
    arc_2_12_16  connected_order_arc_1268  -12
    arc_2_12_16  out_degree_1445  1
    arc_2_12_16  in_degree_1470  1
    arc_2_12_16  original_T_including_depot_unload_1495  1.3653307388496069e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_16  arc_capacity_1267  1
    load_2_12_16  free_load_conservation_1450  1
    load_2_12_16  free_load_conservation_1474  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_17  arc_capacity_1269  -30
    arc_2_12_17  connected_order_arc_1270  -12
    arc_2_12_17  out_degree_1445  1
    arc_2_12_17  in_degree_1476  1
    arc_2_12_17  original_T_including_depot_unload_1495  5.1107432522690152e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_17  arc_capacity_1269  1
    load_2_12_17  free_load_conservation_1450  1
    load_2_12_17  free_load_conservation_1480  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_18  arc_capacity_1271  -30
    arc_2_12_18  connected_order_arc_1272  -12
    arc_2_12_18  out_degree_1445  1
    arc_2_12_18  in_degree_1482  1
    arc_2_12_18  original_T_including_depot_unload_1495  1.2587701383314870e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_18  arc_capacity_1271  1
    load_2_12_18  free_load_conservation_1450  1
    load_2_12_18  free_load_conservation_1486  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_19  arc_capacity_1273  -30
    arc_2_12_19  connected_order_arc_1274  -12
    arc_2_12_19  out_degree_1445  1
    arc_2_12_19  in_degree_1488  1
    arc_2_12_19  original_T_including_depot_unload_1495  7.5634788469878674e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_19  arc_capacity_1273  1
    load_2_12_19  free_load_conservation_1450  1
    load_2_12_19  free_load_conservation_1492  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_0  arc_capacity_1275  -30
    arc_2_13_0  depot_return_or_bypass_1423  1
    arc_2_13_0  out_degree_1451  1
    arc_2_13_0  original_T_including_depot_unload_1495  1.0479182987243917e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_0  arc_capacity_1275  1
    load_2_13_0  free_load_conservation_1456  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_9  arc_capacity_1276  -30
    arc_2_13_9  connected_order_arc_1277  -12
    arc_2_13_9  in_degree_1425  1
    arc_2_13_9  out_degree_1451  1
    arc_2_13_9  original_T_including_depot_unload_1495  1.2309802293463208e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_9  arc_capacity_1276  1
    load_2_13_9  segment_load_conservation_1428  -1
    load_2_13_9  segment_prefix_lb_1429  1
    load_2_13_9  segment_prefix_ub_1430  1
    load_2_13_9  free_load_conservation_1456  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_10  arc_capacity_1278  -30
    arc_2_13_10  connected_order_arc_1279  -12
    arc_2_13_10  in_degree_1432  1
    arc_2_13_10  out_degree_1451  1
    arc_2_13_10  original_T_including_depot_unload_1495  1.6785246977297163e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_10  arc_capacity_1278  1
    load_2_13_10  segment_load_conservation_1435  -1
    load_2_13_10  segment_prefix_lb_1436  1
    load_2_13_10  segment_prefix_ub_1437  1
    load_2_13_10  free_load_conservation_1456  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_11  arc_capacity_1280  -30
    arc_2_13_11  connected_order_arc_1281  -12
    arc_2_13_11  in_degree_1439  1
    arc_2_13_11  out_degree_1451  1
    arc_2_13_11  original_T_including_depot_unload_1495  2.3595978160229652e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_11  arc_capacity_1280  1
    load_2_13_11  segment_load_conservation_1442  -1
    load_2_13_11  segment_prefix_lb_1443  1
    load_2_13_11  segment_prefix_ub_1444  1
    load_2_13_11  free_load_conservation_1456  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_12  arc_capacity_1282  -30
    arc_2_13_12  connected_order_arc_1283  -12
    arc_2_13_12  in_degree_1446  1
    arc_2_13_12  out_degree_1451  1
    arc_2_13_12  original_T_including_depot_unload_1495  2.4155873404211835e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_12  arc_capacity_1282  1
    load_2_13_12  free_load_conservation_1450  -1
    load_2_13_12  free_load_conservation_1456  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_14  arc_capacity_1284  -30
    arc_2_13_14  connected_order_arc_1285  -12
    arc_2_13_14  out_degree_1451  1
    arc_2_13_14  in_degree_1458  1
    arc_2_13_14  original_T_including_depot_unload_1495  5.2280951376932137e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_14  arc_capacity_1284  1
    load_2_13_14  free_load_conservation_1456  1
    load_2_13_14  free_load_conservation_1462  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_15  arc_capacity_1286  -30
    arc_2_13_15  connected_order_arc_1287  -12
    arc_2_13_15  out_degree_1451  1
    arc_2_13_15  in_degree_1464  1
    arc_2_13_15  original_T_including_depot_unload_1495  2.8747557636937808e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_15  arc_capacity_1286  1
    load_2_13_15  free_load_conservation_1456  1
    load_2_13_15  free_load_conservation_1468  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_16  arc_capacity_1288  -30
    arc_2_13_16  connected_order_arc_1289  -12
    arc_2_13_16  out_degree_1451  1
    arc_2_13_16  in_degree_1470  1
    arc_2_13_16  original_T_including_depot_unload_1495  1.5393904884690303e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_16  arc_capacity_1288  1
    load_2_13_16  free_load_conservation_1456  1
    load_2_13_16  free_load_conservation_1474  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_17  arc_capacity_1290  -30
    arc_2_13_17  connected_order_arc_1291  -12
    arc_2_13_17  out_degree_1451  1
    arc_2_13_17  in_degree_1476  1
    arc_2_13_17  original_T_including_depot_unload_1495  3.6094216796124527e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_17  arc_capacity_1290  1
    load_2_13_17  free_load_conservation_1456  1
    load_2_13_17  free_load_conservation_1480  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_18  arc_capacity_1292  -30
    arc_2_13_18  connected_order_arc_1293  -12
    arc_2_13_18  out_degree_1451  1
    arc_2_13_18  in_degree_1482  1
    arc_2_13_18  original_T_including_depot_unload_1495  1.4479585101303876e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_18  arc_capacity_1292  1
    load_2_13_18  free_load_conservation_1456  1
    load_2_13_18  free_load_conservation_1486  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_19  arc_capacity_1294  -30
    arc_2_13_19  connected_order_arc_1295  -12
    arc_2_13_19  out_degree_1451  1
    arc_2_13_19  in_degree_1488  1
    arc_2_13_19  original_T_including_depot_unload_1495  9.2235470209829464e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_19  arc_capacity_1294  1
    load_2_13_19  free_load_conservation_1456  1
    load_2_13_19  free_load_conservation_1492  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_0  arc_capacity_1296  -30
    arc_2_14_0  depot_return_or_bypass_1423  1
    arc_2_14_0  out_degree_1457  1
    arc_2_14_0  original_T_including_depot_unload_1495  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_0  arc_capacity_1296  1
    load_2_14_0  free_load_conservation_1462  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_9  arc_capacity_1297  -30
    arc_2_14_9  connected_order_arc_1298  -12
    arc_2_14_9  in_degree_1425  1
    arc_2_14_9  out_degree_1457  1
    arc_2_14_9  original_T_including_depot_unload_1495  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_9  arc_capacity_1297  1
    load_2_14_9  segment_load_conservation_1428  -1
    load_2_14_9  segment_prefix_lb_1429  1
    load_2_14_9  segment_prefix_ub_1430  1
    load_2_14_9  free_load_conservation_1462  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_10  arc_capacity_1299  -30
    arc_2_14_10  connected_order_arc_1300  -12
    arc_2_14_10  in_degree_1432  1
    arc_2_14_10  out_degree_1457  1
    arc_2_14_10  original_T_including_depot_unload_1495  1.2027697073878232e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_10  arc_capacity_1299  1
    load_2_14_10  segment_load_conservation_1435  -1
    load_2_14_10  segment_prefix_lb_1436  1
    load_2_14_10  segment_prefix_ub_1437  1
    load_2_14_10  free_load_conservation_1462  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_11  arc_capacity_1301  -30
    arc_2_14_11  connected_order_arc_1302  -12
    arc_2_14_11  in_degree_1439  1
    arc_2_14_11  out_degree_1457  1
    arc_2_14_11  original_T_including_depot_unload_1495  2.4147485851762935e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_11  arc_capacity_1301  1
    load_2_14_11  segment_load_conservation_1442  -1
    load_2_14_11  segment_prefix_lb_1443  1
    load_2_14_11  segment_prefix_ub_1444  1
    load_2_14_11  free_load_conservation_1462  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_12  arc_capacity_1303  -30
    arc_2_14_12  connected_order_arc_1304  -12
    arc_2_14_12  in_degree_1446  1
    arc_2_14_12  out_degree_1457  1
    arc_2_14_12  original_T_including_depot_unload_1495  3.6824909986567474e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_12  arc_capacity_1303  1
    load_2_14_12  free_load_conservation_1450  -1
    load_2_14_12  free_load_conservation_1462  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_13  arc_capacity_1305  -30
    arc_2_14_13  connected_order_arc_1306  -12
    arc_2_14_13  in_degree_1452  1
    arc_2_14_13  out_degree_1457  1
    arc_2_14_13  original_T_including_depot_unload_1495  5.2280951376932137e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_13  arc_capacity_1305  1
    load_2_14_13  free_load_conservation_1456  -1
    load_2_14_13  free_load_conservation_1462  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_15  arc_capacity_1307  -30
    arc_2_14_15  connected_order_arc_1308  -12
    arc_2_14_15  out_degree_1457  1
    arc_2_14_15  in_degree_1464  1
    arc_2_14_15  original_T_including_depot_unload_1495  7.3227602527872671e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_15  arc_capacity_1307  1
    load_2_14_15  free_load_conservation_1462  1
    load_2_14_15  free_load_conservation_1468  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_16  arc_capacity_1309  -30
    arc_2_14_16  connected_order_arc_1310  -12
    arc_2_14_16  out_degree_1457  1
    arc_2_14_16  in_degree_1470  1
    arc_2_14_16  original_T_including_depot_unload_1495  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_16  arc_capacity_1309  1
    load_2_14_16  free_load_conservation_1462  1
    load_2_14_16  free_load_conservation_1474  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_17  arc_capacity_1311  -30
    arc_2_14_17  connected_order_arc_1312  -12
    arc_2_14_17  out_degree_1457  1
    arc_2_14_17  in_degree_1476  1
    arc_2_14_17  original_T_including_depot_unload_1495  861.314419336229
    MARKER    'MARKER'                 'INTEND'
    load_2_14_17  arc_capacity_1311  1
    load_2_14_17  free_load_conservation_1462  1
    load_2_14_17  free_load_conservation_1480  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_18  arc_capacity_1313  -30
    arc_2_14_18  connected_order_arc_1314  -12
    arc_2_14_18  out_degree_1457  1
    arc_2_14_18  in_degree_1482  1
    arc_2_14_18  original_T_including_depot_unload_1495  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_18  arc_capacity_1313  1
    load_2_14_18  free_load_conservation_1462  1
    load_2_14_18  free_load_conservation_1486  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_19  arc_capacity_1315  -30
    arc_2_14_19  connected_order_arc_1316  -12
    arc_2_14_19  out_degree_1457  1
    arc_2_14_19  in_degree_1488  1
    arc_2_14_19  original_T_including_depot_unload_1495  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_19  arc_capacity_1315  1
    load_2_14_19  free_load_conservation_1462  1
    load_2_14_19  free_load_conservation_1492  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_0  arc_capacity_1317  -30
    arc_2_15_0  depot_return_or_bypass_1423  1
    arc_2_15_0  out_degree_1463  1
    arc_2_15_0  original_T_including_depot_unload_1495  8.7749189782983967e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_0  arc_capacity_1317  1
    load_2_15_0  free_load_conservation_1468  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_9  arc_capacity_1318  -30
    arc_2_15_9  connected_order_arc_1319  -12
    arc_2_15_9  in_degree_1425  1
    arc_2_15_9  out_degree_1463  1
    arc_2_15_9  original_T_including_depot_unload_1495  1.1005939447212634e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_9  arc_capacity_1318  1
    load_2_15_9  segment_load_conservation_1428  -1
    load_2_15_9  segment_prefix_lb_1429  1
    load_2_15_9  segment_prefix_ub_1430  1
    load_2_15_9  free_load_conservation_1468  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_10  arc_capacity_1320  -30
    arc_2_15_10  connected_order_arc_1321  -12
    arc_2_15_10  in_degree_1432  1
    arc_2_15_10  out_degree_1463  1
    arc_2_15_10  original_T_including_depot_unload_1495  1.7809992976396034e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_10  arc_capacity_1320  1
    load_2_15_10  segment_load_conservation_1435  -1
    load_2_15_10  segment_prefix_lb_1436  1
    load_2_15_10  segment_prefix_ub_1437  1
    load_2_15_10  free_load_conservation_1468  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_11  arc_capacity_1322  -30
    arc_2_15_11  connected_order_arc_1323  -12
    arc_2_15_11  in_degree_1439  1
    arc_2_15_11  out_degree_1463  1
    arc_2_15_11  original_T_including_depot_unload_1495  2.1372888672431886e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_11  arc_capacity_1322  1
    load_2_15_11  segment_load_conservation_1442  -1
    load_2_15_11  segment_prefix_lb_1443  1
    load_2_15_11  segment_prefix_ub_1444  1
    load_2_15_11  free_load_conservation_1468  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_12  arc_capacity_1324  -30
    arc_2_15_12  connected_order_arc_1325  -12
    arc_2_15_12  in_degree_1446  1
    arc_2_15_12  out_degree_1463  1
    arc_2_15_12  original_T_including_depot_unload_1495  3.6821827312741834e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_12  arc_capacity_1324  1
    load_2_15_12  free_load_conservation_1450  -1
    load_2_15_12  free_load_conservation_1468  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_13  arc_capacity_1326  -30
    arc_2_15_13  connected_order_arc_1327  -12
    arc_2_15_13  in_degree_1452  1
    arc_2_15_13  out_degree_1463  1
    arc_2_15_13  original_T_including_depot_unload_1495  2.8747557636937808e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_13  arc_capacity_1326  1
    load_2_15_13  free_load_conservation_1456  -1
    load_2_15_13  free_load_conservation_1468  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_14  arc_capacity_1328  -30
    arc_2_15_14  connected_order_arc_1329  -12
    arc_2_15_14  in_degree_1458  1
    arc_2_15_14  out_degree_1463  1
    arc_2_15_14  original_T_including_depot_unload_1495  7.3227602527872671e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_14  arc_capacity_1328  1
    load_2_15_14  free_load_conservation_1462  -1
    load_2_15_14  free_load_conservation_1468  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_16  arc_capacity_1330  -30
    arc_2_15_16  connected_order_arc_1331  -12
    arc_2_15_16  out_degree_1463  1
    arc_2_15_16  in_degree_1470  1
    arc_2_15_16  original_T_including_depot_unload_1495  1.3600272346134373e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_16  arc_capacity_1330  1
    load_2_15_16  free_load_conservation_1468  1
    load_2_15_16  free_load_conservation_1474  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_17  arc_capacity_1332  -30
    arc_2_15_17  connected_order_arc_1333  -12
    arc_2_15_17  out_degree_1463  1
    arc_2_15_17  in_degree_1476  1
    arc_2_15_17  original_T_including_depot_unload_1495  1.6651295535886251e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_17  arc_capacity_1332  1
    load_2_15_17  free_load_conservation_1468  1
    load_2_15_17  free_load_conservation_1480  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_18  arc_capacity_1334  -30
    arc_2_15_18  connected_order_arc_1335  -12
    arc_2_15_18  out_degree_1463  1
    arc_2_15_18  in_degree_1482  1
    arc_2_15_18  original_T_including_depot_unload_1495  1.2927779971523576e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_18  arc_capacity_1334  1
    load_2_15_18  free_load_conservation_1468  1
    load_2_15_18  free_load_conservation_1486  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_19  arc_capacity_1336  -30
    arc_2_15_19  connected_order_arc_1337  -12
    arc_2_15_19  out_degree_1463  1
    arc_2_15_19  in_degree_1488  1
    arc_2_15_19  original_T_including_depot_unload_1495  7.5571464781430223e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_19  arc_capacity_1336  1
    load_2_15_19  free_load_conservation_1468  1
    load_2_15_19  free_load_conservation_1492  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_0  arc_capacity_1338  -30
    arc_2_16_0  depot_return_or_bypass_1423  1
    arc_2_16_0  out_degree_1469  1
    arc_2_16_0  original_T_including_depot_unload_1495  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_0  arc_capacity_1338  1
    load_2_16_0  free_load_conservation_1474  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_9  arc_capacity_1339  -30
    arc_2_16_9  connected_order_arc_1340  -12
    arc_2_16_9  in_degree_1425  1
    arc_2_16_9  out_degree_1469  1
    arc_2_16_9  original_T_including_depot_unload_1495  3.8790073962518773e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_9  arc_capacity_1339  1
    load_2_16_9  segment_load_conservation_1428  -1
    load_2_16_9  segment_prefix_lb_1429  1
    load_2_16_9  segment_prefix_ub_1430  1
    load_2_16_9  free_load_conservation_1474  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_10  arc_capacity_1341  -30
    arc_2_16_10  connected_order_arc_1342  -12
    arc_2_16_10  in_degree_1432  1
    arc_2_16_10  out_degree_1469  1
    arc_2_16_10  original_T_including_depot_unload_1495  1.5960107821452696e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_10  arc_capacity_1341  1
    load_2_16_10  segment_load_conservation_1435  -1
    load_2_16_10  segment_prefix_lb_1436  1
    load_2_16_10  segment_prefix_ub_1437  1
    load_2_16_10  free_load_conservation_1474  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_11  arc_capacity_1343  -30
    arc_2_16_11  connected_order_arc_1344  -12
    arc_2_16_11  in_degree_1439  1
    arc_2_16_11  out_degree_1469  1
    arc_2_16_11  original_T_including_depot_unload_1495  8.8496780902404032e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_11  arc_capacity_1343  1
    load_2_16_11  segment_load_conservation_1442  -1
    load_2_16_11  segment_prefix_lb_1443  1
    load_2_16_11  segment_prefix_ub_1444  1
    load_2_16_11  free_load_conservation_1474  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_12  arc_capacity_1345  -30
    arc_2_16_12  connected_order_arc_1346  -12
    arc_2_16_12  in_degree_1446  1
    arc_2_16_12  out_degree_1469  1
    arc_2_16_12  original_T_including_depot_unload_1495  1.3653307388496069e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_12  arc_capacity_1345  1
    load_2_16_12  free_load_conservation_1450  -1
    load_2_16_12  free_load_conservation_1474  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_13  arc_capacity_1347  -30
    arc_2_16_13  connected_order_arc_1348  -12
    arc_2_16_13  in_degree_1452  1
    arc_2_16_13  out_degree_1469  1
    arc_2_16_13  original_T_including_depot_unload_1495  1.5393904884690303e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_13  arc_capacity_1347  1
    load_2_16_13  free_load_conservation_1456  -1
    load_2_16_13  free_load_conservation_1474  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_14  arc_capacity_1349  -30
    arc_2_16_14  connected_order_arc_1350  -12
    arc_2_16_14  in_degree_1458  1
    arc_2_16_14  out_degree_1469  1
    arc_2_16_14  original_T_including_depot_unload_1495  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_14  arc_capacity_1349  1
    load_2_16_14  free_load_conservation_1462  -1
    load_2_16_14  free_load_conservation_1474  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_15  arc_capacity_1351  -30
    arc_2_16_15  connected_order_arc_1352  -12
    arc_2_16_15  in_degree_1464  1
    arc_2_16_15  out_degree_1469  1
    arc_2_16_15  original_T_including_depot_unload_1495  1.3600272346134373e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_15  arc_capacity_1351  1
    load_2_16_15  free_load_conservation_1468  -1
    load_2_16_15  free_load_conservation_1474  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_17  arc_capacity_1353  -30
    arc_2_16_17  connected_order_arc_1354  -12
    arc_2_16_17  out_degree_1469  1
    arc_2_16_17  in_degree_1476  1
    arc_2_16_17  original_T_including_depot_unload_1495  1.4805184908215606e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_17  arc_capacity_1353  1
    load_2_16_17  free_load_conservation_1474  1
    load_2_16_17  free_load_conservation_1480  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_18  arc_capacity_1355  -30
    arc_2_16_18  connected_order_arc_1356  -12
    arc_2_16_18  out_degree_1469  1
    arc_2_16_18  in_degree_1482  1
    arc_2_16_18  original_T_including_depot_unload_1495  1.6597164064313077e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_18  arc_capacity_1355  1
    load_2_16_18  free_load_conservation_1474  1
    load_2_16_18  free_load_conservation_1486  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_19  arc_capacity_1357  -30
    arc_2_16_19  connected_order_arc_1358  -12
    arc_2_16_19  out_degree_1469  1
    arc_2_16_19  in_degree_1488  1
    arc_2_16_19  original_T_including_depot_unload_1495  6.1704611580490348e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_19  arc_capacity_1357  1
    load_2_16_19  free_load_conservation_1474  1
    load_2_16_19  free_load_conservation_1492  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_0  arc_capacity_1359  -30
    arc_2_17_0  depot_return_or_bypass_1423  1
    arc_2_17_0  out_degree_1475  1
    arc_2_17_0  original_T_including_depot_unload_1495  1.0088905112952611e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_0  arc_capacity_1359  1
    load_2_17_0  free_load_conservation_1480  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_9  arc_capacity_1360  -30
    arc_2_17_9  connected_order_arc_1361  -12
    arc_2_17_9  in_degree_1425  1
    arc_2_17_9  out_degree_1475  1
    arc_2_17_9  original_T_including_depot_unload_1495  1.2442780266664952e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_9  arc_capacity_1360  1
    load_2_17_9  segment_load_conservation_1428  -1
    load_2_17_9  segment_prefix_lb_1429  1
    load_2_17_9  segment_prefix_ub_1430  1
    load_2_17_9  free_load_conservation_1480  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_10  arc_capacity_1362  -30
    arc_2_17_10  connected_order_arc_1363  -12
    arc_2_17_10  in_degree_1432  1
    arc_2_17_10  out_degree_1475  1
    arc_2_17_10  original_T_including_depot_unload_1495  1.9434430494183746e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_10  arc_capacity_1362  1
    load_2_17_10  segment_load_conservation_1435  -1
    load_2_17_10  segment_prefix_lb_1436  1
    load_2_17_10  segment_prefix_ub_1437  1
    load_2_17_10  free_load_conservation_1480  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_11  arc_capacity_1364  -30
    arc_2_17_11  connected_order_arc_1365  -12
    arc_2_17_11  in_degree_1439  1
    arc_2_17_11  out_degree_1475  1
    arc_2_17_11  original_T_including_depot_unload_1495  2.2245628069082109e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_11  arc_capacity_1364  1
    load_2_17_11  segment_load_conservation_1442  -1
    load_2_17_11  segment_prefix_lb_1443  1
    load_2_17_11  segment_prefix_ub_1444  1
    load_2_17_11  free_load_conservation_1480  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_12  arc_capacity_1366  -30
    arc_2_17_12  connected_order_arc_1367  -12
    arc_2_17_12  in_degree_1446  1
    arc_2_17_12  out_degree_1475  1
    arc_2_17_12  original_T_including_depot_unload_1495  5.1107432522690152e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_12  arc_capacity_1366  1
    load_2_17_12  free_load_conservation_1450  -1
    load_2_17_12  free_load_conservation_1480  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_13  arc_capacity_1368  -30
    arc_2_17_13  connected_order_arc_1369  -12
    arc_2_17_13  in_degree_1452  1
    arc_2_17_13  out_degree_1475  1
    arc_2_17_13  original_T_including_depot_unload_1495  3.6094216796124527e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_13  arc_capacity_1368  1
    load_2_17_13  free_load_conservation_1456  -1
    load_2_17_13  free_load_conservation_1480  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_14  arc_capacity_1370  -30
    arc_2_17_14  connected_order_arc_1371  -12
    arc_2_17_14  in_degree_1458  1
    arc_2_17_14  out_degree_1475  1
    arc_2_17_14  original_T_including_depot_unload_1495  861.314419336229
    MARKER    'MARKER'                 'INTEND'
    load_2_17_14  arc_capacity_1370  1
    load_2_17_14  free_load_conservation_1462  -1
    load_2_17_14  free_load_conservation_1480  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_15  arc_capacity_1372  -30
    arc_2_17_15  connected_order_arc_1373  -12
    arc_2_17_15  in_degree_1464  1
    arc_2_17_15  out_degree_1475  1
    arc_2_17_15  original_T_including_depot_unload_1495  1.6651295535886251e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_15  arc_capacity_1372  1
    load_2_17_15  free_load_conservation_1468  -1
    load_2_17_15  free_load_conservation_1480  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_16  arc_capacity_1374  -30
    arc_2_17_16  connected_order_arc_1375  -12
    arc_2_17_16  in_degree_1470  1
    arc_2_17_16  out_degree_1475  1
    arc_2_17_16  original_T_including_depot_unload_1495  1.4805184908215606e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_16  arc_capacity_1374  1
    load_2_17_16  free_load_conservation_1474  -1
    load_2_17_16  free_load_conservation_1480  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_18  arc_capacity_1376  -30
    arc_2_17_18  connected_order_arc_1377  -12
    arc_2_17_18  out_degree_1475  1
    arc_2_17_18  in_degree_1482  1
    arc_2_17_18  original_T_including_depot_unload_1495  1.4252778892498145e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_18  arc_capacity_1376  1
    load_2_17_18  free_load_conservation_1480  1
    load_2_17_18  free_load_conservation_1486  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_19  arc_capacity_1378  -30
    arc_2_17_19  connected_order_arc_1379  -12
    arc_2_17_19  out_degree_1475  1
    arc_2_17_19  in_degree_1488  1
    arc_2_17_19  original_T_including_depot_unload_1495  8.9135689158237335e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_19  arc_capacity_1378  1
    load_2_17_19  free_load_conservation_1480  1
    load_2_17_19  free_load_conservation_1492  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_0  arc_capacity_1380  -30
    arc_2_18_0  depot_return_or_bypass_1423  1
    arc_2_18_0  out_degree_1481  1
    arc_2_18_0  original_T_including_depot_unload_1495  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_0  arc_capacity_1380  1
    load_2_18_0  free_load_conservation_1486  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_9  arc_capacity_1381  -30
    arc_2_18_9  connected_order_arc_1382  -12
    arc_2_18_9  in_degree_1425  1
    arc_2_18_9  out_degree_1481  1
    arc_2_18_9  original_T_including_depot_unload_1495  2.4083746437975364e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_9  arc_capacity_1381  1
    load_2_18_9  segment_load_conservation_1428  -1
    load_2_18_9  segment_prefix_lb_1429  1
    load_2_18_9  segment_prefix_ub_1430  1
    load_2_18_9  free_load_conservation_1486  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_10  arc_capacity_1383  -30
    arc_2_18_10  connected_order_arc_1384  -12
    arc_2_18_10  in_degree_1432  1
    arc_2_18_10  out_degree_1481  1
    arc_2_18_10  original_T_including_depot_unload_1495  1.4332871320059419e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_10  arc_capacity_1383  1
    load_2_18_10  segment_load_conservation_1435  -1
    load_2_18_10  segment_prefix_lb_1436  1
    load_2_18_10  segment_prefix_ub_1437  1
    load_2_18_10  free_load_conservation_1486  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_11  arc_capacity_1385  -30
    arc_2_18_11  connected_order_arc_1386  -12
    arc_2_18_11  in_degree_1439  1
    arc_2_18_11  out_degree_1481  1
    arc_2_18_11  original_T_including_depot_unload_1495  1.0363003610648061e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_11  arc_capacity_1385  1
    load_2_18_11  segment_load_conservation_1442  -1
    load_2_18_11  segment_prefix_lb_1443  1
    load_2_18_11  segment_prefix_ub_1444  1
    load_2_18_11  free_load_conservation_1486  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_12  arc_capacity_1387  -30
    arc_2_18_12  connected_order_arc_1388  -12
    arc_2_18_12  in_degree_1446  1
    arc_2_18_12  out_degree_1481  1
    arc_2_18_12  original_T_including_depot_unload_1495  1.2587701383314870e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_12  arc_capacity_1387  1
    load_2_18_12  free_load_conservation_1450  -1
    load_2_18_12  free_load_conservation_1486  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_13  arc_capacity_1389  -30
    arc_2_18_13  connected_order_arc_1390  -12
    arc_2_18_13  in_degree_1452  1
    arc_2_18_13  out_degree_1481  1
    arc_2_18_13  original_T_including_depot_unload_1495  1.4479585101303876e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_13  arc_capacity_1389  1
    load_2_18_13  free_load_conservation_1456  -1
    load_2_18_13  free_load_conservation_1486  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_14  arc_capacity_1391  -30
    arc_2_18_14  connected_order_arc_1392  -12
    arc_2_18_14  in_degree_1458  1
    arc_2_18_14  out_degree_1481  1
    arc_2_18_14  original_T_including_depot_unload_1495  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_14  arc_capacity_1391  1
    load_2_18_14  free_load_conservation_1462  -1
    load_2_18_14  free_load_conservation_1486  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_15  arc_capacity_1393  -30
    arc_2_18_15  connected_order_arc_1394  -12
    arc_2_18_15  in_degree_1464  1
    arc_2_18_15  out_degree_1481  1
    arc_2_18_15  original_T_including_depot_unload_1495  1.2927779971523576e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_15  arc_capacity_1393  1
    load_2_18_15  free_load_conservation_1468  -1
    load_2_18_15  free_load_conservation_1486  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_16  arc_capacity_1395  -30
    arc_2_18_16  connected_order_arc_1396  -12
    arc_2_18_16  in_degree_1470  1
    arc_2_18_16  out_degree_1481  1
    arc_2_18_16  original_T_including_depot_unload_1495  1.6597164064313077e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_16  arc_capacity_1395  1
    load_2_18_16  free_load_conservation_1474  -1
    load_2_18_16  free_load_conservation_1486  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_17  arc_capacity_1397  -30
    arc_2_18_17  connected_order_arc_1398  -12
    arc_2_18_17  in_degree_1476  1
    arc_2_18_17  out_degree_1481  1
    arc_2_18_17  original_T_including_depot_unload_1495  1.4252778892498145e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_17  arc_capacity_1397  1
    load_2_18_17  free_load_conservation_1480  -1
    load_2_18_17  free_load_conservation_1486  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_19  arc_capacity_1399  -30
    arc_2_18_19  connected_order_arc_1400  -12
    arc_2_18_19  out_degree_1481  1
    arc_2_18_19  in_degree_1488  1
    arc_2_18_19  original_T_including_depot_unload_1495  5.3713048648006088e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_19  arc_capacity_1399  1
    load_2_18_19  free_load_conservation_1486  1
    load_2_18_19  free_load_conservation_1492  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_0  arc_capacity_1401  -30
    arc_2_19_0  depot_return_or_bypass_1423  1
    arc_2_19_0  out_degree_1487  1
    arc_2_19_0  original_T_including_depot_unload_1495  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_0  arc_capacity_1401  1
    load_2_19_0  free_load_conservation_1492  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_9  arc_capacity_1402  -30
    arc_2_19_9  connected_order_arc_1403  -12
    arc_2_19_9  in_degree_1425  1
    arc_2_19_9  out_degree_1487  1
    arc_2_19_9  original_T_including_depot_unload_1495  359.975566576564
    MARKER    'MARKER'                 'INTEND'
    load_2_19_9  arc_capacity_1402  1
    load_2_19_9  segment_load_conservation_1428  -1
    load_2_19_9  segment_prefix_lb_1429  1
    load_2_19_9  segment_prefix_ub_1430  1
    load_2_19_9  free_load_conservation_1492  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_10  arc_capacity_1404  -30
    arc_2_19_10  connected_order_arc_1405  -12
    arc_2_19_10  in_degree_1432  1
    arc_2_19_10  out_degree_1487  1
    arc_2_19_10  original_T_including_depot_unload_1495  1.4472076573979532e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_10  arc_capacity_1404  1
    load_2_19_10  segment_load_conservation_1435  -1
    load_2_19_10  segment_prefix_lb_1436  1
    load_2_19_10  segment_prefix_ub_1437  1
    load_2_19_10  free_load_conservation_1492  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_11  arc_capacity_1406  -30
    arc_2_19_11  connected_order_arc_1407  -12
    arc_2_19_11  in_degree_1439  1
    arc_2_19_11  out_degree_1487  1
    arc_2_19_11  original_T_including_depot_unload_1495  1.4593103211867947e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_11  arc_capacity_1406  1
    load_2_19_11  segment_load_conservation_1442  -1
    load_2_19_11  segment_prefix_lb_1443  1
    load_2_19_11  segment_prefix_ub_1444  1
    load_2_19_11  free_load_conservation_1492  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_12  arc_capacity_1408  -30
    arc_2_19_12  connected_order_arc_1409  -12
    arc_2_19_12  in_degree_1446  1
    arc_2_19_12  out_degree_1487  1
    arc_2_19_12  original_T_including_depot_unload_1495  7.5634788469878674e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_12  arc_capacity_1408  1
    load_2_19_12  free_load_conservation_1450  -1
    load_2_19_12  free_load_conservation_1492  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_13  arc_capacity_1410  -30
    arc_2_19_13  connected_order_arc_1411  -12
    arc_2_19_13  in_degree_1452  1
    arc_2_19_13  out_degree_1487  1
    arc_2_19_13  original_T_including_depot_unload_1495  9.2235470209829464e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_13  arc_capacity_1410  1
    load_2_19_13  free_load_conservation_1456  -1
    load_2_19_13  free_load_conservation_1492  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_14  arc_capacity_1412  -30
    arc_2_19_14  connected_order_arc_1413  -12
    arc_2_19_14  in_degree_1458  1
    arc_2_19_14  out_degree_1487  1
    arc_2_19_14  original_T_including_depot_unload_1495  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_14  arc_capacity_1412  1
    load_2_19_14  free_load_conservation_1462  -1
    load_2_19_14  free_load_conservation_1492  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_15  arc_capacity_1414  -30
    arc_2_19_15  connected_order_arc_1415  -12
    arc_2_19_15  in_degree_1464  1
    arc_2_19_15  out_degree_1487  1
    arc_2_19_15  original_T_including_depot_unload_1495  7.5571464781430223e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_15  arc_capacity_1414  1
    load_2_19_15  free_load_conservation_1468  -1
    load_2_19_15  free_load_conservation_1492  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_16  arc_capacity_1416  -30
    arc_2_19_16  connected_order_arc_1417  -12
    arc_2_19_16  in_degree_1470  1
    arc_2_19_16  out_degree_1487  1
    arc_2_19_16  original_T_including_depot_unload_1495  6.1704611580490348e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_16  arc_capacity_1416  1
    load_2_19_16  free_load_conservation_1474  -1
    load_2_19_16  free_load_conservation_1492  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_17  arc_capacity_1418  -30
    arc_2_19_17  connected_order_arc_1419  -12
    arc_2_19_17  in_degree_1476  1
    arc_2_19_17  out_degree_1487  1
    arc_2_19_17  original_T_including_depot_unload_1495  8.9135689158237335e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_17  arc_capacity_1418  1
    load_2_19_17  free_load_conservation_1480  -1
    load_2_19_17  free_load_conservation_1492  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_18  arc_capacity_1420  -30
    arc_2_19_18  connected_order_arc_1421  -12
    arc_2_19_18  in_degree_1482  1
    arc_2_19_18  out_degree_1487  1
    arc_2_19_18  original_T_including_depot_unload_1495  5.3713048648006088e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_18  arc_capacity_1420  1
    load_2_19_18  free_load_conservation_1486  -1
    load_2_19_18  free_load_conservation_1492  1
RHS
    RHS1      OBJ       -5.2199999999999991e-01
    RHS1      onehot_25_32  1
    RHS1      onehot_29_67  1
    RHS1      onehot_31_96  1
    RHS1      onehot_24_131  1
    RHS1      onehot_2_166  1
    RHS1      onehot_27_201  1
    RHS1      onehot_6_226  1
    RHS1      onehot_12_261  1
    RHS1      stock_ub_265  40
    RHS1      parent_nonstrict_scope_266  3.4346954911354421e-01
    RHS1      normalization_323  1
    RHS1      connected_order_arc_452  -12
    RHS1      connected_order_arc_454  -12
    RHS1      connected_order_arc_456  -12
    RHS1      connected_order_arc_458  -12
    RHS1      connected_order_arc_460  -12
    RHS1      connected_order_arc_462  -12
    RHS1      connected_order_arc_464  -12
    RHS1      connected_order_arc_466  -12
    RHS1      connected_order_arc_468  -12
    RHS1      connected_order_arc_470  -12
    RHS1      connected_order_arc_472  -12
    RHS1      connected_order_arc_475  -12
    RHS1      connected_order_arc_477  -12
    RHS1      connected_order_arc_479  -12
    RHS1      connected_order_arc_481  -12
    RHS1      connected_order_arc_483  -12
    RHS1      connected_order_arc_485  -12
    RHS1      connected_order_arc_487  -12
    RHS1      connected_order_arc_489  -12
    RHS1      connected_order_arc_491  -12
    RHS1      connected_order_arc_493  -12
    RHS1      connected_order_arc_495  -12
    RHS1      connected_order_arc_498  -12
    RHS1      connected_order_arc_500  -12
    RHS1      connected_order_arc_502  -12
    RHS1      connected_order_arc_504  -12
    RHS1      connected_order_arc_506  -12
    RHS1      connected_order_arc_508  -12
    RHS1      connected_order_arc_510  -12
    RHS1      connected_order_arc_512  -12
    RHS1      connected_order_arc_514  -12
    RHS1      connected_order_arc_516  -12
    RHS1      connected_order_arc_518  -12
    RHS1      connected_order_arc_521  -12
    RHS1      connected_order_arc_523  -12
    RHS1      connected_order_arc_525  -12
    RHS1      connected_order_arc_527  -12
    RHS1      connected_order_arc_529  -12
    RHS1      connected_order_arc_531  -12
    RHS1      connected_order_arc_533  -12
    RHS1      connected_order_arc_535  -12
    RHS1      connected_order_arc_537  -12
    RHS1      connected_order_arc_539  -12
    RHS1      connected_order_arc_541  -12
    RHS1      connected_order_arc_544  -12
    RHS1      connected_order_arc_546  -12
    RHS1      connected_order_arc_548  -12
    RHS1      connected_order_arc_550  -12
    RHS1      connected_order_arc_552  -12
    RHS1      connected_order_arc_554  -12
    RHS1      connected_order_arc_556  -12
    RHS1      connected_order_arc_558  -12
    RHS1      connected_order_arc_560  -12
    RHS1      connected_order_arc_562  -12
    RHS1      connected_order_arc_564  -12
    RHS1      connected_order_arc_567  -12
    RHS1      connected_order_arc_569  -12
    RHS1      connected_order_arc_571  -12
    RHS1      connected_order_arc_573  -12
    RHS1      connected_order_arc_575  -12
    RHS1      connected_order_arc_577  -12
    RHS1      connected_order_arc_579  -12
    RHS1      connected_order_arc_581  -12
    RHS1      connected_order_arc_583  -12
    RHS1      connected_order_arc_585  -12
    RHS1      connected_order_arc_587  -12
    RHS1      connected_order_arc_590  -12
    RHS1      connected_order_arc_592  -12
    RHS1      connected_order_arc_594  -12
    RHS1      connected_order_arc_596  -12
    RHS1      connected_order_arc_598  -12
    RHS1      connected_order_arc_600  -12
    RHS1      connected_order_arc_602  -12
    RHS1      connected_order_arc_604  -12
    RHS1      connected_order_arc_606  -12
    RHS1      connected_order_arc_608  -12
    RHS1      connected_order_arc_610  -12
    RHS1      connected_order_arc_613  -12
    RHS1      connected_order_arc_615  -12
    RHS1      connected_order_arc_617  -12
    RHS1      connected_order_arc_619  -12
    RHS1      connected_order_arc_621  -12
    RHS1      connected_order_arc_623  -12
    RHS1      connected_order_arc_625  -12
    RHS1      connected_order_arc_627  -12
    RHS1      connected_order_arc_629  -12
    RHS1      connected_order_arc_631  -12
    RHS1      connected_order_arc_633  -12
    RHS1      connected_order_arc_636  -12
    RHS1      connected_order_arc_638  -12
    RHS1      connected_order_arc_640  -12
    RHS1      connected_order_arc_642  -12
    RHS1      connected_order_arc_644  -12
    RHS1      connected_order_arc_646  -12
    RHS1      connected_order_arc_648  -12
    RHS1      connected_order_arc_650  -12
    RHS1      connected_order_arc_652  -12
    RHS1      connected_order_arc_654  -12
    RHS1      connected_order_arc_656  -12
    RHS1      connected_order_arc_659  -12
    RHS1      connected_order_arc_661  -12
    RHS1      connected_order_arc_663  -12
    RHS1      connected_order_arc_665  -12
    RHS1      connected_order_arc_667  -12
    RHS1      connected_order_arc_669  -12
    RHS1      connected_order_arc_671  -12
    RHS1      connected_order_arc_673  -12
    RHS1      connected_order_arc_675  -12
    RHS1      connected_order_arc_677  -12
    RHS1      connected_order_arc_679  -12
    RHS1      connected_order_arc_682  -12
    RHS1      connected_order_arc_684  -12
    RHS1      connected_order_arc_686  -12
    RHS1      connected_order_arc_688  -12
    RHS1      connected_order_arc_690  -12
    RHS1      connected_order_arc_692  -12
    RHS1      connected_order_arc_694  -12
    RHS1      connected_order_arc_696  -12
    RHS1      connected_order_arc_698  -12
    RHS1      connected_order_arc_700  -12
    RHS1      connected_order_arc_702  -12
    RHS1      connected_order_arc_705  -12
    RHS1      connected_order_arc_707  -12
    RHS1      connected_order_arc_709  -12
    RHS1      connected_order_arc_711  -12
    RHS1      connected_order_arc_713  -12
    RHS1      connected_order_arc_715  -12
    RHS1      connected_order_arc_717  -12
    RHS1      connected_order_arc_719  -12
    RHS1      connected_order_arc_721  -12
    RHS1      connected_order_arc_723  -12
    RHS1      connected_order_arc_725  -12
    RHS1      depot_departure_or_bypass_726  1
    RHS1      depot_return_or_bypass_727  1
    RHS1      segment_load_conservation_732  7
    RHS1      segment_prefix_ub_734  5
    RHS1      segment_load_conservation_739  -4
    RHS1      segment_prefix_lb_740  4
    RHS1      segment_prefix_ub_741  20
    RHS1      segment_load_conservation_746  5
    RHS1      segment_prefix_ub_748  15
    RHS1      segment_load_conservation_753  -8
    RHS1      segment_prefix_lb_754  8
    RHS1      segment_prefix_ub_755  15
    RHS1      fixed_segment_relative_order_804  1
    RHS1      fixed_segment_relative_order_805  1
    RHS1      fixed_segment_relative_order_806  1
    RHS1      original_T_including_depot_unload_807  1.7024825050945065e+03
    RHS1      connected_order_arc_823  -12
    RHS1      connected_order_arc_825  -12
    RHS1      connected_order_arc_827  -12
    RHS1      connected_order_arc_829  -12
    RHS1      connected_order_arc_831  -12
    RHS1      connected_order_arc_833  -12
    RHS1      connected_order_arc_835  -12
    RHS1      connected_order_arc_837  -12
    RHS1      connected_order_arc_839  -12
    RHS1      connected_order_arc_841  -12
    RHS1      connected_order_arc_843  -12
    RHS1      connected_order_arc_846  -12
    RHS1      connected_order_arc_848  -12
    RHS1      connected_order_arc_850  -12
    RHS1      connected_order_arc_852  -12
    RHS1      connected_order_arc_854  -12
    RHS1      connected_order_arc_856  -12
    RHS1      connected_order_arc_858  -12
    RHS1      connected_order_arc_860  -12
    RHS1      connected_order_arc_862  -12
    RHS1      connected_order_arc_864  -12
    RHS1      connected_order_arc_866  -12
    RHS1      connected_order_arc_869  -12
    RHS1      connected_order_arc_871  -12
    RHS1      connected_order_arc_873  -12
    RHS1      connected_order_arc_875  -12
    RHS1      connected_order_arc_877  -12
    RHS1      connected_order_arc_879  -12
    RHS1      connected_order_arc_881  -12
    RHS1      connected_order_arc_883  -12
    RHS1      connected_order_arc_885  -12
    RHS1      connected_order_arc_887  -12
    RHS1      connected_order_arc_889  -12
    RHS1      connected_order_arc_892  -12
    RHS1      connected_order_arc_894  -12
    RHS1      connected_order_arc_896  -12
    RHS1      connected_order_arc_898  -12
    RHS1      connected_order_arc_900  -12
    RHS1      connected_order_arc_902  -12
    RHS1      connected_order_arc_904  -12
    RHS1      connected_order_arc_906  -12
    RHS1      connected_order_arc_908  -12
    RHS1      connected_order_arc_910  -12
    RHS1      connected_order_arc_912  -12
    RHS1      connected_order_arc_915  -12
    RHS1      connected_order_arc_917  -12
    RHS1      connected_order_arc_919  -12
    RHS1      connected_order_arc_921  -12
    RHS1      connected_order_arc_923  -12
    RHS1      connected_order_arc_925  -12
    RHS1      connected_order_arc_927  -12
    RHS1      connected_order_arc_929  -12
    RHS1      connected_order_arc_931  -12
    RHS1      connected_order_arc_933  -12
    RHS1      connected_order_arc_935  -12
    RHS1      connected_order_arc_938  -12
    RHS1      connected_order_arc_940  -12
    RHS1      connected_order_arc_942  -12
    RHS1      connected_order_arc_944  -12
    RHS1      connected_order_arc_946  -12
    RHS1      connected_order_arc_948  -12
    RHS1      connected_order_arc_950  -12
    RHS1      connected_order_arc_952  -12
    RHS1      connected_order_arc_954  -12
    RHS1      connected_order_arc_956  -12
    RHS1      connected_order_arc_958  -12
    RHS1      connected_order_arc_961  -12
    RHS1      connected_order_arc_963  -12
    RHS1      connected_order_arc_965  -12
    RHS1      connected_order_arc_967  -12
    RHS1      connected_order_arc_969  -12
    RHS1      connected_order_arc_971  -12
    RHS1      connected_order_arc_973  -12
    RHS1      connected_order_arc_975  -12
    RHS1      connected_order_arc_977  -12
    RHS1      connected_order_arc_979  -12
    RHS1      connected_order_arc_981  -12
    RHS1      connected_order_arc_984  -12
    RHS1      connected_order_arc_986  -12
    RHS1      connected_order_arc_988  -12
    RHS1      connected_order_arc_990  -12
    RHS1      connected_order_arc_992  -12
    RHS1      connected_order_arc_994  -12
    RHS1      connected_order_arc_996  -12
    RHS1      connected_order_arc_998  -12
    RHS1      connected_order_arc_1000  -12
    RHS1      connected_order_arc_1002  -12
    RHS1      connected_order_arc_1004  -12
    RHS1      connected_order_arc_1007  -12
    RHS1      connected_order_arc_1009  -12
    RHS1      connected_order_arc_1011  -12
    RHS1      connected_order_arc_1013  -12
    RHS1      connected_order_arc_1015  -12
    RHS1      connected_order_arc_1017  -12
    RHS1      connected_order_arc_1019  -12
    RHS1      connected_order_arc_1021  -12
    RHS1      connected_order_arc_1023  -12
    RHS1      connected_order_arc_1025  -12
    RHS1      connected_order_arc_1027  -12
    RHS1      connected_order_arc_1030  -12
    RHS1      connected_order_arc_1032  -12
    RHS1      connected_order_arc_1034  -12
    RHS1      connected_order_arc_1036  -12
    RHS1      connected_order_arc_1038  -12
    RHS1      connected_order_arc_1040  -12
    RHS1      connected_order_arc_1042  -12
    RHS1      connected_order_arc_1044  -12
    RHS1      connected_order_arc_1046  -12
    RHS1      connected_order_arc_1048  -12
    RHS1      connected_order_arc_1050  -12
    RHS1      connected_order_arc_1053  -12
    RHS1      connected_order_arc_1055  -12
    RHS1      connected_order_arc_1057  -12
    RHS1      connected_order_arc_1059  -12
    RHS1      connected_order_arc_1061  -12
    RHS1      connected_order_arc_1063  -12
    RHS1      connected_order_arc_1065  -12
    RHS1      connected_order_arc_1067  -12
    RHS1      connected_order_arc_1069  -12
    RHS1      connected_order_arc_1071  -12
    RHS1      connected_order_arc_1073  -12
    RHS1      connected_order_arc_1076  -12
    RHS1      connected_order_arc_1078  -12
    RHS1      connected_order_arc_1080  -12
    RHS1      connected_order_arc_1082  -12
    RHS1      connected_order_arc_1084  -12
    RHS1      connected_order_arc_1086  -12
    RHS1      connected_order_arc_1088  -12
    RHS1      connected_order_arc_1090  -12
    RHS1      connected_order_arc_1092  -12
    RHS1      connected_order_arc_1094  -12
    RHS1      connected_order_arc_1096  -12
    RHS1      depot_departure_or_bypass_1097  1
    RHS1      depot_return_or_bypass_1098  1
    RHS1      segment_load_conservation_1103  -1
    RHS1      segment_prefix_lb_1104  1
    RHS1      segment_prefix_ub_1105  25
    RHS1      segment_load_conservation_1110  -5
    RHS1      segment_prefix_lb_1111  5
    RHS1      segment_prefix_ub_1112  25
    RHS1      segment_load_conservation_1117  3
    RHS1      segment_prefix_ub_1119  19
    RHS1      segment_load_conservation_1124  3
    RHS1      segment_prefix_ub_1126  22
    RHS1      fixed_segment_relative_order_1175  1
    RHS1      fixed_segment_relative_order_1176  1
    RHS1      fixed_segment_relative_order_1177  1
    RHS1      original_T_including_depot_unload_1178  5.2477757503172315e+03
    RHS1      connected_order_arc_1193  -11
    RHS1      connected_order_arc_1195  -11
    RHS1      connected_order_arc_1197  -11
    RHS1      connected_order_arc_1199  -11
    RHS1      connected_order_arc_1201  -11
    RHS1      connected_order_arc_1203  -11
    RHS1      connected_order_arc_1205  -11
    RHS1      connected_order_arc_1207  -11
    RHS1      connected_order_arc_1209  -11
    RHS1      connected_order_arc_1211  -11
    RHS1      connected_order_arc_1214  -11
    RHS1      connected_order_arc_1216  -11
    RHS1      connected_order_arc_1218  -11
    RHS1      connected_order_arc_1220  -11
    RHS1      connected_order_arc_1222  -11
    RHS1      connected_order_arc_1224  -11
    RHS1      connected_order_arc_1226  -11
    RHS1      connected_order_arc_1228  -11
    RHS1      connected_order_arc_1230  -11
    RHS1      connected_order_arc_1232  -11
    RHS1      connected_order_arc_1235  -11
    RHS1      connected_order_arc_1237  -11
    RHS1      connected_order_arc_1239  -11
    RHS1      connected_order_arc_1241  -11
    RHS1      connected_order_arc_1243  -11
    RHS1      connected_order_arc_1245  -11
    RHS1      connected_order_arc_1247  -11
    RHS1      connected_order_arc_1249  -11
    RHS1      connected_order_arc_1251  -11
    RHS1      connected_order_arc_1253  -11
    RHS1      connected_order_arc_1256  -11
    RHS1      connected_order_arc_1258  -11
    RHS1      connected_order_arc_1260  -11
    RHS1      connected_order_arc_1262  -11
    RHS1      connected_order_arc_1264  -11
    RHS1      connected_order_arc_1266  -11
    RHS1      connected_order_arc_1268  -11
    RHS1      connected_order_arc_1270  -11
    RHS1      connected_order_arc_1272  -11
    RHS1      connected_order_arc_1274  -11
    RHS1      connected_order_arc_1277  -11
    RHS1      connected_order_arc_1279  -11
    RHS1      connected_order_arc_1281  -11
    RHS1      connected_order_arc_1283  -11
    RHS1      connected_order_arc_1285  -11
    RHS1      connected_order_arc_1287  -11
    RHS1      connected_order_arc_1289  -11
    RHS1      connected_order_arc_1291  -11
    RHS1      connected_order_arc_1293  -11
    RHS1      connected_order_arc_1295  -11
    RHS1      connected_order_arc_1298  -11
    RHS1      connected_order_arc_1300  -11
    RHS1      connected_order_arc_1302  -11
    RHS1      connected_order_arc_1304  -11
    RHS1      connected_order_arc_1306  -11
    RHS1      connected_order_arc_1308  -11
    RHS1      connected_order_arc_1310  -11
    RHS1      connected_order_arc_1312  -11
    RHS1      connected_order_arc_1314  -11
    RHS1      connected_order_arc_1316  -11
    RHS1      connected_order_arc_1319  -11
    RHS1      connected_order_arc_1321  -11
    RHS1      connected_order_arc_1323  -11
    RHS1      connected_order_arc_1325  -11
    RHS1      connected_order_arc_1327  -11
    RHS1      connected_order_arc_1329  -11
    RHS1      connected_order_arc_1331  -11
    RHS1      connected_order_arc_1333  -11
    RHS1      connected_order_arc_1335  -11
    RHS1      connected_order_arc_1337  -11
    RHS1      connected_order_arc_1340  -11
    RHS1      connected_order_arc_1342  -11
    RHS1      connected_order_arc_1344  -11
    RHS1      connected_order_arc_1346  -11
    RHS1      connected_order_arc_1348  -11
    RHS1      connected_order_arc_1350  -11
    RHS1      connected_order_arc_1352  -11
    RHS1      connected_order_arc_1354  -11
    RHS1      connected_order_arc_1356  -11
    RHS1      connected_order_arc_1358  -11
    RHS1      connected_order_arc_1361  -11
    RHS1      connected_order_arc_1363  -11
    RHS1      connected_order_arc_1365  -11
    RHS1      connected_order_arc_1367  -11
    RHS1      connected_order_arc_1369  -11
    RHS1      connected_order_arc_1371  -11
    RHS1      connected_order_arc_1373  -11
    RHS1      connected_order_arc_1375  -11
    RHS1      connected_order_arc_1377  -11
    RHS1      connected_order_arc_1379  -11
    RHS1      connected_order_arc_1382  -11
    RHS1      connected_order_arc_1384  -11
    RHS1      connected_order_arc_1386  -11
    RHS1      connected_order_arc_1388  -11
    RHS1      connected_order_arc_1390  -11
    RHS1      connected_order_arc_1392  -11
    RHS1      connected_order_arc_1394  -11
    RHS1      connected_order_arc_1396  -11
    RHS1      connected_order_arc_1398  -11
    RHS1      connected_order_arc_1400  -11
    RHS1      connected_order_arc_1403  -11
    RHS1      connected_order_arc_1405  -11
    RHS1      connected_order_arc_1407  -11
    RHS1      connected_order_arc_1409  -11
    RHS1      connected_order_arc_1411  -11
    RHS1      connected_order_arc_1413  -11
    RHS1      connected_order_arc_1415  -11
    RHS1      connected_order_arc_1417  -11
    RHS1      connected_order_arc_1419  -11
    RHS1      connected_order_arc_1421  -11
    RHS1      depot_departure_or_bypass_1422  1
    RHS1      depot_return_or_bypass_1423  1
    RHS1      segment_load_conservation_1428  2
    RHS1      segment_prefix_ub_1430  28
    RHS1      segment_load_conservation_1435  1
    RHS1      segment_prefix_ub_1437  27
    RHS1      segment_prefix_ub_1444  25
    RHS1      fixed_segment_relative_order_1493  1
    RHS1      fixed_segment_relative_order_1494  1
    RHS1      original_T_including_depot_unload_1495  4.4670949882505547e+03
BOUNDS
 LO BND1      t         2.5353132922828682e-02
 UP BND1      t         4.2722001830985672e-02
 UP BND1      q         5.4596954911354423e-01
 BV BND1      x_25_0  
 UP BND1      w_25_0    4.2722001830985672e-02
 BV BND1      x_25_1  
 UP BND1      w_25_1    4.2722001830985672e-02
 BV BND1      x_25_2  
 UP BND1      w_25_2    4.2722001830985672e-02
 BV BND1      x_25_3  
 UP BND1      w_25_3    4.2722001830985672e-02
 BV BND1      x_25_4  
 UP BND1      w_25_4    4.2722001830985672e-02
 BV BND1      x_25_5  
 UP BND1      w_25_5    4.2722001830985672e-02
 BV BND1      x_25_6  
 UP BND1      w_25_6    4.2722001830985672e-02
 BV BND1      x_25_7  
 UP BND1      w_25_7    4.2722001830985672e-02
 BV BND1      x_25_8  
 UP BND1      w_25_8    4.2722001830985672e-02
 BV BND1      x_25_9  
 UP BND1      w_25_9    4.2722001830985672e-02
 BV BND1      x_25_10 
 UP BND1      w_25_10   4.2722001830985672e-02
 BV BND1      x_25_11 
 UP BND1      w_25_11   4.2722001830985672e-02
 BV BND1      x_25_12 
 UP BND1      w_25_12   4.2722001830985672e-02
 BV BND1      x_25_13 
 UP BND1      w_25_13   4.2722001830985672e-02
 BV BND1      x_25_14 
 UP BND1      w_25_14   4.2722001830985672e-02
 BV BND1      x_25_15 
 UP BND1      w_25_15   4.2722001830985672e-02
 UP BND1      rho_25    1
 BV BND1      x_29_0  
 UP BND1      w_29_0    4.2722001830985672e-02
 BV BND1      x_29_1  
 UP BND1      w_29_1    4.2722001830985672e-02
 BV BND1      x_29_2  
 UP BND1      w_29_2    4.2722001830985672e-02
 BV BND1      x_29_3  
 UP BND1      w_29_3    4.2722001830985672e-02
 BV BND1      x_29_4  
 UP BND1      w_29_4    4.2722001830985672e-02
 BV BND1      x_29_5  
 UP BND1      w_29_5    4.2722001830985672e-02
 BV BND1      x_29_6  
 UP BND1      w_29_6    4.2722001830985672e-02
 BV BND1      x_29_7  
 UP BND1      w_29_7    4.2722001830985672e-02
 BV BND1      x_29_8  
 UP BND1      w_29_8    4.2722001830985672e-02
 BV BND1      x_29_9  
 UP BND1      w_29_9    4.2722001830985672e-02
 BV BND1      x_29_10 
 UP BND1      w_29_10   4.2722001830985672e-02
 BV BND1      x_29_11 
 UP BND1      w_29_11   4.2722001830985672e-02
 BV BND1      x_29_12 
 UP BND1      w_29_12   4.2722001830985672e-02
 BV BND1      x_29_13 
 UP BND1      w_29_13   4.2722001830985672e-02
 BV BND1      x_29_14 
 UP BND1      w_29_14   4.2722001830985672e-02
 BV BND1      x_29_15 
 UP BND1      w_29_15   4.2722001830985672e-02
 UP BND1      rho_29    1
 BV BND1      x_31_0  
 UP BND1      w_31_0    4.2722001830985672e-02
 BV BND1      x_31_1  
 UP BND1      w_31_1    4.2722001830985672e-02
 BV BND1      x_31_2  
 UP BND1      w_31_2    4.2722001830985672e-02
 BV BND1      x_31_3  
 UP BND1      w_31_3    4.2722001830985672e-02
 BV BND1      x_31_4  
 UP BND1      w_31_4    4.2722001830985672e-02
 BV BND1      x_31_5  
 UP BND1      w_31_5    4.2722001830985672e-02
 BV BND1      x_31_6  
 UP BND1      w_31_6    4.2722001830985672e-02
 BV BND1      x_31_7  
 UP BND1      w_31_7    4.2722001830985672e-02
 BV BND1      x_31_8  
 UP BND1      w_31_8    4.2722001830985672e-02
 BV BND1      x_31_9  
 UP BND1      w_31_9    4.2722001830985672e-02
 BV BND1      x_31_10 
 UP BND1      w_31_10   4.2722001830985672e-02
 BV BND1      x_31_11 
 UP BND1      w_31_11   4.2722001830985672e-02
 BV BND1      x_31_12 
 UP BND1      w_31_12   4.2722001830985672e-02
 UP BND1      rho_31    1
 BV BND1      x_24_0  
 UP BND1      w_24_0    4.2722001830985672e-02
 BV BND1      x_24_1  
 UP BND1      w_24_1    4.2722001830985672e-02
 BV BND1      x_24_2  
 UP BND1      w_24_2    4.2722001830985672e-02
 BV BND1      x_24_3  
 UP BND1      w_24_3    4.2722001830985672e-02
 BV BND1      x_24_4  
 UP BND1      w_24_4    4.2722001830985672e-02
 BV BND1      x_24_5  
 UP BND1      w_24_5    4.2722001830985672e-02
 BV BND1      x_24_6  
 UP BND1      w_24_6    4.2722001830985672e-02
 BV BND1      x_24_7  
 UP BND1      w_24_7    4.2722001830985672e-02
 BV BND1      x_24_8  
 UP BND1      w_24_8    4.2722001830985672e-02
 BV BND1      x_24_9  
 UP BND1      w_24_9    4.2722001830985672e-02
 BV BND1      x_24_10 
 UP BND1      w_24_10   4.2722001830985672e-02
 BV BND1      x_24_11 
 UP BND1      w_24_11   4.2722001830985672e-02
 BV BND1      x_24_12 
 UP BND1      w_24_12   4.2722001830985672e-02
 BV BND1      x_24_13 
 UP BND1      w_24_13   4.2722001830985672e-02
 BV BND1      x_24_14 
 UP BND1      w_24_14   4.2722001830985672e-02
 BV BND1      x_24_15 
 UP BND1      w_24_15   4.2722001830985672e-02
 UP BND1      rho_24    1
 BV BND1      x_2_0   
 UP BND1      w_2_0     4.2722001830985672e-02
 BV BND1      x_2_1   
 UP BND1      w_2_1     4.2722001830985672e-02
 BV BND1      x_2_2   
 UP BND1      w_2_2     4.2722001830985672e-02
 BV BND1      x_2_3   
 UP BND1      w_2_3     4.2722001830985672e-02
 BV BND1      x_2_4   
 UP BND1      w_2_4     4.2722001830985672e-02
 BV BND1      x_2_5   
 UP BND1      w_2_5     4.2722001830985672e-02
 BV BND1      x_2_6   
 UP BND1      w_2_6     4.2722001830985672e-02
 BV BND1      x_2_7   
 UP BND1      w_2_7     4.2722001830985672e-02
 BV BND1      x_2_8   
 UP BND1      w_2_8     4.2722001830985672e-02
 BV BND1      x_2_9   
 UP BND1      w_2_9     4.2722001830985672e-02
 BV BND1      x_2_10  
 UP BND1      w_2_10    4.2722001830985672e-02
 BV BND1      x_2_11  
 UP BND1      w_2_11    4.2722001830985672e-02
 BV BND1      x_2_12  
 UP BND1      w_2_12    4.2722001830985672e-02
 BV BND1      x_2_13  
 UP BND1      w_2_13    4.2722001830985672e-02
 BV BND1      x_2_14  
 UP BND1      w_2_14    4.2722001830985672e-02
 BV BND1      x_2_15  
 UP BND1      w_2_15    4.2722001830985672e-02
 UP BND1      rho_2     1
 BV BND1      x_27_0  
 UP BND1      w_27_0    4.2722001830985672e-02
 BV BND1      x_27_1  
 UP BND1      w_27_1    4.2722001830985672e-02
 BV BND1      x_27_2  
 UP BND1      w_27_2    4.2722001830985672e-02
 BV BND1      x_27_3  
 UP BND1      w_27_3    4.2722001830985672e-02
 BV BND1      x_27_4  
 UP BND1      w_27_4    4.2722001830985672e-02
 BV BND1      x_27_5  
 UP BND1      w_27_5    4.2722001830985672e-02
 BV BND1      x_27_6  
 UP BND1      w_27_6    4.2722001830985672e-02
 BV BND1      x_27_7  
 UP BND1      w_27_7    4.2722001830985672e-02
 BV BND1      x_27_8  
 UP BND1      w_27_8    4.2722001830985672e-02
 BV BND1      x_27_9  
 UP BND1      w_27_9    4.2722001830985672e-02
 BV BND1      x_27_10 
 UP BND1      w_27_10   4.2722001830985672e-02
 BV BND1      x_27_11 
 UP BND1      w_27_11   4.2722001830985672e-02
 BV BND1      x_27_12 
 UP BND1      w_27_12   4.2722001830985672e-02
 BV BND1      x_27_13 
 UP BND1      w_27_13   4.2722001830985672e-02
 BV BND1      x_27_14 
 UP BND1      w_27_14   4.2722001830985672e-02
 BV BND1      x_27_15 
 UP BND1      w_27_15   4.2722001830985672e-02
 UP BND1      rho_27    1
 BV BND1      x_6_0   
 UP BND1      w_6_0     4.2722001830985672e-02
 BV BND1      x_6_1   
 UP BND1      w_6_1     4.2722001830985672e-02
 BV BND1      x_6_2   
 UP BND1      w_6_2     4.2722001830985672e-02
 BV BND1      x_6_3   
 UP BND1      w_6_3     4.2722001830985672e-02
 BV BND1      x_6_4   
 UP BND1      w_6_4     4.2722001830985672e-02
 BV BND1      x_6_5   
 UP BND1      w_6_5     4.2722001830985672e-02
 BV BND1      x_6_6   
 UP BND1      w_6_6     4.2722001830985672e-02
 BV BND1      x_6_7   
 UP BND1      w_6_7     4.2722001830985672e-02
 BV BND1      x_6_8   
 UP BND1      w_6_8     4.2722001830985672e-02
 BV BND1      x_6_9   
 UP BND1      w_6_9     4.2722001830985672e-02
 BV BND1      x_6_10  
 UP BND1      w_6_10    4.2722001830985672e-02
 UP BND1      rho_6     1
 BV BND1      x_12_0  
 UP BND1      w_12_0    4.2722001830985672e-02
 BV BND1      x_12_1  
 UP BND1      w_12_1    4.2722001830985672e-02
 BV BND1      x_12_2  
 UP BND1      w_12_2    4.2722001830985672e-02
 BV BND1      x_12_3  
 UP BND1      w_12_3    4.2722001830985672e-02
 BV BND1      x_12_4  
 UP BND1      w_12_4    4.2722001830985672e-02
 BV BND1      x_12_5  
 UP BND1      w_12_5    4.2722001830985672e-02
 BV BND1      x_12_6  
 UP BND1      w_12_6    4.2722001830985672e-02
 BV BND1      x_12_7  
 UP BND1      w_12_7    4.2722001830985672e-02
 BV BND1      x_12_8  
 UP BND1      w_12_8    4.2722001830985672e-02
 BV BND1      x_12_9  
 UP BND1      w_12_9    4.2722001830985672e-02
 BV BND1      x_12_10 
 UP BND1      w_12_10   4.2722001830985672e-02
 BV BND1      x_12_11 
 UP BND1      w_12_11   4.2722001830985672e-02
 BV BND1      x_12_12 
 UP BND1      w_12_12   4.2722001830985672e-02
 BV BND1      x_12_13 
 UP BND1      w_12_13   4.2722001830985672e-02
 BV BND1      x_12_14 
 UP BND1      w_12_14   4.2722001830985672e-02
 BV BND1      x_12_15 
 UP BND1      w_12_15   4.2722001830985672e-02
 UP BND1      rho_12    1
 UP BND1      a_25_29   1
 UP BND1      a_25_31   1
 UP BND1      a_25_24   1
 UP BND1      a_25_2    1
 UP BND1      a_25_27   1
 UP BND1      a_25_6    1
 UP BND1      a_25_12   1
 UP BND1      a_29_31   1
 UP BND1      a_29_24   1
 UP BND1      a_29_2    1
 UP BND1      a_29_27   1
 UP BND1      a_29_6    1
 UP BND1      a_29_12   1
 UP BND1      a_31_24   1
 UP BND1      a_31_2    1
 UP BND1      a_31_27   1
 UP BND1      a_31_6    1
 UP BND1      a_31_12   1
 UP BND1      a_24_2    1
 UP BND1      a_24_27   1
 UP BND1      a_24_6    1
 UP BND1      a_24_12   1
 UP BND1      a_2_27    1
 UP BND1      a_2_6     1
 UP BND1      a_2_12    1
 UP BND1      a_27_6    1
 UP BND1      a_27_12   1
 UP BND1      a_6_12    1
 BV BND1      service_0_25_0
 BV BND1      service_0_25_2
 BV BND1      service_0_25_3
 BV BND1      service_0_25_4
 BV BND1      service_0_25_5
 BV BND1      service_0_25_6
 BV BND1      service_0_25_7
 BV BND1      service_0_25_8
 BV BND1      service_0_25_9
 BV BND1      service_0_25_10
 BV BND1      service_0_25_11
 BV BND1      service_0_25_12
 BV BND1      service_0_25_13
 BV BND1      service_0_25_14
 BV BND1      service_0_25_15
 BV BND1      service_1_25_0
 BV BND1      service_1_25_2
 BV BND1      service_1_25_3
 BV BND1      service_1_25_4
 BV BND1      service_1_25_5
 BV BND1      service_1_25_6
 BV BND1      service_1_25_7
 BV BND1      service_1_25_8
 BV BND1      service_1_25_9
 BV BND1      service_1_25_10
 BV BND1      service_1_25_11
 BV BND1      service_1_25_12
 BV BND1      service_1_25_13
 BV BND1      service_1_25_14
 BV BND1      service_1_25_15
 BV BND1      service_2_25_0
 BV BND1      service_2_25_2
 BV BND1      service_2_25_3
 BV BND1      service_2_25_4
 BV BND1      service_2_25_5
 BV BND1      service_2_25_6
 BV BND1      service_2_25_7
 BV BND1      service_2_25_8
 BV BND1      service_2_25_9
 BV BND1      service_2_25_10
 BV BND1      service_2_25_11
 BV BND1      service_2_25_12
 BV BND1      service_2_25_13
 BV BND1      service_2_25_14
 BV BND1      service_2_25_15
 BV BND1      service_0_29_0
 BV BND1      service_0_29_1
 BV BND1      service_0_29_2
 BV BND1      service_0_29_3
 BV BND1      service_0_29_4
 BV BND1      service_0_29_5
 BV BND1      service_0_29_6
 BV BND1      service_0_29_7
 BV BND1      service_0_29_8
 BV BND1      service_0_29_9
 BV BND1      service_0_29_10
 BV BND1      service_0_29_12
 BV BND1      service_0_29_13
 BV BND1      service_0_29_14
 BV BND1      service_0_29_15
 BV BND1      service_1_29_0
 BV BND1      service_1_29_1
 BV BND1      service_1_29_2
 BV BND1      service_1_29_3
 BV BND1      service_1_29_4
 BV BND1      service_1_29_5
 BV BND1      service_1_29_6
 BV BND1      service_1_29_7
 BV BND1      service_1_29_8
 BV BND1      service_1_29_9
 BV BND1      service_1_29_10
 BV BND1      service_1_29_12
 BV BND1      service_1_29_13
 BV BND1      service_1_29_14
 BV BND1      service_1_29_15
 BV BND1      service_2_29_0
 BV BND1      service_2_29_1
 BV BND1      service_2_29_2
 BV BND1      service_2_29_3
 BV BND1      service_2_29_4
 BV BND1      service_2_29_5
 BV BND1      service_2_29_6
 BV BND1      service_2_29_7
 BV BND1      service_2_29_8
 BV BND1      service_2_29_9
 BV BND1      service_2_29_10
 BV BND1      service_2_29_12
 BV BND1      service_2_29_13
 BV BND1      service_2_29_14
 BV BND1      service_2_29_15
 BV BND1      service_0_31_0
 BV BND1      service_0_31_1
 BV BND1      service_0_31_3
 BV BND1      service_0_31_4
 BV BND1      service_0_31_5
 BV BND1      service_0_31_6
 BV BND1      service_0_31_7
 BV BND1      service_0_31_8
 BV BND1      service_0_31_9
 BV BND1      service_0_31_10
 BV BND1      service_0_31_11
 BV BND1      service_0_31_12
 BV BND1      service_1_31_0
 BV BND1      service_1_31_1
 BV BND1      service_1_31_3
 BV BND1      service_1_31_4
 BV BND1      service_1_31_5
 BV BND1      service_1_31_6
 BV BND1      service_1_31_7
 BV BND1      service_1_31_8
 BV BND1      service_1_31_9
 BV BND1      service_1_31_10
 BV BND1      service_1_31_11
 BV BND1      service_1_31_12
 BV BND1      service_2_31_0
 BV BND1      service_2_31_1
 BV BND1      service_2_31_3
 BV BND1      service_2_31_4
 BV BND1      service_2_31_5
 BV BND1      service_2_31_6
 BV BND1      service_2_31_7
 BV BND1      service_2_31_8
 BV BND1      service_2_31_9
 BV BND1      service_2_31_10
 BV BND1      service_2_31_11
 BV BND1      service_2_31_12
 BV BND1      service_0_24_0
 BV BND1      service_0_24_1
 BV BND1      service_0_24_2
 BV BND1      service_0_24_3
 BV BND1      service_0_24_4
 BV BND1      service_0_24_5
 BV BND1      service_0_24_6
 BV BND1      service_0_24_7
 BV BND1      service_0_24_8
 BV BND1      service_0_24_9
 BV BND1      service_0_24_10
 BV BND1      service_0_24_12
 BV BND1      service_0_24_13
 BV BND1      service_0_24_14
 BV BND1      service_0_24_15
 BV BND1      service_1_24_0
 BV BND1      service_1_24_1
 BV BND1      service_1_24_2
 BV BND1      service_1_24_3
 BV BND1      service_1_24_4
 BV BND1      service_1_24_5
 BV BND1      service_1_24_6
 BV BND1      service_1_24_7
 BV BND1      service_1_24_8
 BV BND1      service_1_24_9
 BV BND1      service_1_24_10
 BV BND1      service_1_24_12
 BV BND1      service_1_24_13
 BV BND1      service_1_24_14
 BV BND1      service_1_24_15
 BV BND1      service_2_24_0
 BV BND1      service_2_24_1
 BV BND1      service_2_24_2
 BV BND1      service_2_24_3
 BV BND1      service_2_24_4
 BV BND1      service_2_24_5
 BV BND1      service_2_24_6
 BV BND1      service_2_24_7
 BV BND1      service_2_24_8
 BV BND1      service_2_24_9
 BV BND1      service_2_24_10
 BV BND1      service_2_24_12
 BV BND1      service_2_24_13
 BV BND1      service_2_24_14
 BV BND1      service_2_24_15
 BV BND1      service_0_2_1
 BV BND1      service_0_2_2
 BV BND1      service_0_2_3
 BV BND1      service_0_2_4
 BV BND1      service_0_2_5
 BV BND1      service_0_2_6
 BV BND1      service_0_2_7
 BV BND1      service_0_2_8
 BV BND1      service_0_2_9
 BV BND1      service_0_2_10
 BV BND1      service_0_2_11
 BV BND1      service_0_2_12
 BV BND1      service_0_2_13
 BV BND1      service_0_2_14
 BV BND1      service_0_2_15
 BV BND1      service_1_2_1
 BV BND1      service_1_2_2
 BV BND1      service_1_2_3
 BV BND1      service_1_2_4
 BV BND1      service_1_2_5
 BV BND1      service_1_2_6
 BV BND1      service_1_2_7
 BV BND1      service_1_2_8
 BV BND1      service_1_2_9
 BV BND1      service_1_2_10
 BV BND1      service_1_2_11
 BV BND1      service_1_2_12
 BV BND1      service_1_2_13
 BV BND1      service_1_2_14
 BV BND1      service_1_2_15
 BV BND1      service_2_2_1
 BV BND1      service_2_2_2
 BV BND1      service_2_2_3
 BV BND1      service_2_2_4
 BV BND1      service_2_2_5
 BV BND1      service_2_2_6
 BV BND1      service_2_2_7
 BV BND1      service_2_2_8
 BV BND1      service_2_2_9
 BV BND1      service_2_2_10
 BV BND1      service_2_2_11
 BV BND1      service_2_2_12
 BV BND1      service_2_2_13
 BV BND1      service_2_2_14
 BV BND1      service_2_2_15
 BV BND1      service_0_27_0
 BV BND1      service_0_27_1
 BV BND1      service_0_27_2
 BV BND1      service_0_27_3
 BV BND1      service_0_27_4
 BV BND1      service_0_27_5
 BV BND1      service_0_27_6
 BV BND1      service_0_27_7
 BV BND1      service_0_27_8
 BV BND1      service_0_27_9
 BV BND1      service_0_27_10
 BV BND1      service_0_27_12
 BV BND1      service_0_27_13
 BV BND1      service_0_27_14
 BV BND1      service_0_27_15
 BV BND1      service_1_27_0
 BV BND1      service_1_27_1
 BV BND1      service_1_27_2
 BV BND1      service_1_27_3
 BV BND1      service_1_27_4
 BV BND1      service_1_27_5
 BV BND1      service_1_27_6
 BV BND1      service_1_27_7
 BV BND1      service_1_27_8
 BV BND1      service_1_27_9
 BV BND1      service_1_27_10
 BV BND1      service_1_27_12
 BV BND1      service_1_27_13
 BV BND1      service_1_27_14
 BV BND1      service_1_27_15
 BV BND1      service_2_27_0
 BV BND1      service_2_27_1
 BV BND1      service_2_27_2
 BV BND1      service_2_27_3
 BV BND1      service_2_27_4
 BV BND1      service_2_27_5
 BV BND1      service_2_27_6
 BV BND1      service_2_27_7
 BV BND1      service_2_27_8
 BV BND1      service_2_27_9
 BV BND1      service_2_27_10
 BV BND1      service_2_27_12
 BV BND1      service_2_27_13
 BV BND1      service_2_27_14
 BV BND1      service_2_27_15
 BV BND1      service_0_6_0
 BV BND1      service_0_6_2
 BV BND1      service_0_6_3
 BV BND1      service_0_6_4
 BV BND1      service_0_6_5
 BV BND1      service_0_6_6
 BV BND1      service_0_6_7
 BV BND1      service_0_6_8
 BV BND1      service_0_6_9
 BV BND1      service_0_6_10
 BV BND1      service_1_6_0
 BV BND1      service_1_6_2
 BV BND1      service_1_6_3
 BV BND1      service_1_6_4
 BV BND1      service_1_6_5
 BV BND1      service_1_6_6
 BV BND1      service_1_6_7
 BV BND1      service_1_6_8
 BV BND1      service_1_6_9
 BV BND1      service_1_6_10
 BV BND1      service_2_6_0
 BV BND1      service_2_6_2
 BV BND1      service_2_6_3
 BV BND1      service_2_6_4
 BV BND1      service_2_6_5
 BV BND1      service_2_6_6
 BV BND1      service_2_6_7
 BV BND1      service_2_6_8
 BV BND1      service_2_6_9
 BV BND1      service_2_6_10
 BV BND1      service_0_12_1
 BV BND1      service_0_12_2
 BV BND1      service_0_12_3
 BV BND1      service_0_12_4
 BV BND1      service_0_12_5
 BV BND1      service_0_12_6
 BV BND1      service_0_12_7
 BV BND1      service_0_12_8
 BV BND1      service_0_12_9
 BV BND1      service_0_12_10
 BV BND1      service_0_12_11
 BV BND1      service_0_12_12
 BV BND1      service_0_12_13
 BV BND1      service_0_12_14
 BV BND1      service_0_12_15
 BV BND1      service_1_12_1
 BV BND1      service_1_12_2
 BV BND1      service_1_12_3
 BV BND1      service_1_12_4
 BV BND1      service_1_12_5
 BV BND1      service_1_12_6
 BV BND1      service_1_12_7
 BV BND1      service_1_12_8
 BV BND1      service_1_12_9
 BV BND1      service_1_12_10
 BV BND1      service_1_12_11
 BV BND1      service_1_12_12
 BV BND1      service_1_12_13
 BV BND1      service_1_12_14
 BV BND1      service_1_12_15
 BV BND1      service_2_12_1
 BV BND1      service_2_12_2
 BV BND1      service_2_12_3
 BV BND1      service_2_12_4
 BV BND1      service_2_12_5
 BV BND1      service_2_12_6
 BV BND1      service_2_12_7
 BV BND1      service_2_12_8
 BV BND1      service_2_12_9
 BV BND1      service_2_12_10
 BV BND1      service_2_12_11
 BV BND1      service_2_12_12
 BV BND1      service_2_12_13
 BV BND1      service_2_12_14
 BV BND1      service_2_12_15
 FX BND1      visit_0_1  1
 UP BND1      order_0_1  12
 FX BND1      visit_0_2  1
 UP BND1      order_0_2  12
 FX BND1      visit_0_3  1
 UP BND1      order_0_3  12
 FX BND1      visit_0_4  1
 UP BND1      order_0_4  12
 UP BND1      visit_0_12  1
 UP BND1      order_0_12  12
 UP BND1      visit_0_13  1
 UP BND1      order_0_13  12
 UP BND1      visit_0_14  1
 UP BND1      order_0_14  12
 UP BND1      visit_0_15  1
 UP BND1      order_0_15  12
 UP BND1      visit_0_16  1
 UP BND1      order_0_16  12
 UP BND1      visit_0_17  1
 UP BND1      order_0_17  12
 UP BND1      visit_0_18  1
 UP BND1      order_0_18  12
 UP BND1      visit_0_19  1
 UP BND1      order_0_19  12
 BV BND1      arc_0_0_0
 FX BND1      load_0_0_0  0
 BV BND1      arc_0_0_1
 FX BND1      load_0_0_1  0
 BV BND1      arc_0_0_2
 FX BND1      load_0_0_2  0
 BV BND1      arc_0_0_3
 FX BND1      load_0_0_3  0
 BV BND1      arc_0_0_4
 FX BND1      load_0_0_4  0
 BV BND1      arc_0_0_12
 FX BND1      load_0_0_12  0
 BV BND1      arc_0_0_13
 FX BND1      load_0_0_13  0
 BV BND1      arc_0_0_14
 FX BND1      load_0_0_14  0
 BV BND1      arc_0_0_15
 FX BND1      load_0_0_15  0
 BV BND1      arc_0_0_16
 FX BND1      load_0_0_16  0
 BV BND1      arc_0_0_17
 FX BND1      load_0_0_17  0
 BV BND1      arc_0_0_18
 FX BND1      load_0_0_18  0
 BV BND1      arc_0_0_19
 FX BND1      load_0_0_19  0
 BV BND1      arc_0_1_0
 UP BND1      load_0_1_0  20
 BV BND1      arc_0_1_2
 UP BND1      load_0_1_2  20
 BV BND1      arc_0_1_3
 UP BND1      load_0_1_3  20
 BV BND1      arc_0_1_4
 UP BND1      load_0_1_4  20
 BV BND1      arc_0_1_12
 UP BND1      load_0_1_12  20
 BV BND1      arc_0_1_13
 UP BND1      load_0_1_13  20
 BV BND1      arc_0_1_14
 UP BND1      load_0_1_14  20
 BV BND1      arc_0_1_15
 UP BND1      load_0_1_15  20
 BV BND1      arc_0_1_16
 UP BND1      load_0_1_16  20
 BV BND1      arc_0_1_17
 UP BND1      load_0_1_17  20
 BV BND1      arc_0_1_18
 UP BND1      load_0_1_18  20
 BV BND1      arc_0_1_19
 UP BND1      load_0_1_19  20
 BV BND1      arc_0_2_0
 UP BND1      load_0_2_0  20
 BV BND1      arc_0_2_1
 UP BND1      load_0_2_1  20
 BV BND1      arc_0_2_3
 UP BND1      load_0_2_3  20
 BV BND1      arc_0_2_4
 UP BND1      load_0_2_4  20
 BV BND1      arc_0_2_12
 UP BND1      load_0_2_12  20
 BV BND1      arc_0_2_13
 UP BND1      load_0_2_13  20
 BV BND1      arc_0_2_14
 UP BND1      load_0_2_14  20
 BV BND1      arc_0_2_15
 UP BND1      load_0_2_15  20
 BV BND1      arc_0_2_16
 UP BND1      load_0_2_16  20
 BV BND1      arc_0_2_17
 UP BND1      load_0_2_17  20
 BV BND1      arc_0_2_18
 UP BND1      load_0_2_18  20
 BV BND1      arc_0_2_19
 UP BND1      load_0_2_19  20
 BV BND1      arc_0_3_0
 UP BND1      load_0_3_0  20
 BV BND1      arc_0_3_1
 UP BND1      load_0_3_1  20
 BV BND1      arc_0_3_2
 UP BND1      load_0_3_2  20
 BV BND1      arc_0_3_4
 UP BND1      load_0_3_4  20
 BV BND1      arc_0_3_12
 UP BND1      load_0_3_12  20
 BV BND1      arc_0_3_13
 UP BND1      load_0_3_13  20
 BV BND1      arc_0_3_14
 UP BND1      load_0_3_14  20
 BV BND1      arc_0_3_15
 UP BND1      load_0_3_15  20
 BV BND1      arc_0_3_16
 UP BND1      load_0_3_16  20
 BV BND1      arc_0_3_17
 UP BND1      load_0_3_17  20
 BV BND1      arc_0_3_18
 UP BND1      load_0_3_18  20
 BV BND1      arc_0_3_19
 UP BND1      load_0_3_19  20
 BV BND1      arc_0_4_0
 UP BND1      load_0_4_0  20
 BV BND1      arc_0_4_1
 UP BND1      load_0_4_1  20
 BV BND1      arc_0_4_2
 UP BND1      load_0_4_2  20
 BV BND1      arc_0_4_3
 UP BND1      load_0_4_3  20
 BV BND1      arc_0_4_12
 UP BND1      load_0_4_12  20
 BV BND1      arc_0_4_13
 UP BND1      load_0_4_13  20
 BV BND1      arc_0_4_14
 UP BND1      load_0_4_14  20
 BV BND1      arc_0_4_15
 UP BND1      load_0_4_15  20
 BV BND1      arc_0_4_16
 UP BND1      load_0_4_16  20
 BV BND1      arc_0_4_17
 UP BND1      load_0_4_17  20
 BV BND1      arc_0_4_18
 UP BND1      load_0_4_18  20
 BV BND1      arc_0_4_19
 UP BND1      load_0_4_19  20
 BV BND1      arc_0_12_0
 UP BND1      load_0_12_0  20
 BV BND1      arc_0_12_1
 UP BND1      load_0_12_1  20
 BV BND1      arc_0_12_2
 UP BND1      load_0_12_2  20
 BV BND1      arc_0_12_3
 UP BND1      load_0_12_3  20
 BV BND1      arc_0_12_4
 UP BND1      load_0_12_4  20
 BV BND1      arc_0_12_13
 UP BND1      load_0_12_13  20
 BV BND1      arc_0_12_14
 UP BND1      load_0_12_14  20
 BV BND1      arc_0_12_15
 UP BND1      load_0_12_15  20
 BV BND1      arc_0_12_16
 UP BND1      load_0_12_16  20
 BV BND1      arc_0_12_17
 UP BND1      load_0_12_17  20
 BV BND1      arc_0_12_18
 UP BND1      load_0_12_18  20
 BV BND1      arc_0_12_19
 UP BND1      load_0_12_19  20
 BV BND1      arc_0_13_0
 UP BND1      load_0_13_0  20
 BV BND1      arc_0_13_1
 UP BND1      load_0_13_1  20
 BV BND1      arc_0_13_2
 UP BND1      load_0_13_2  20
 BV BND1      arc_0_13_3
 UP BND1      load_0_13_3  20
 BV BND1      arc_0_13_4
 UP BND1      load_0_13_4  20
 BV BND1      arc_0_13_12
 UP BND1      load_0_13_12  20
 BV BND1      arc_0_13_14
 UP BND1      load_0_13_14  20
 BV BND1      arc_0_13_15
 UP BND1      load_0_13_15  20
 BV BND1      arc_0_13_16
 UP BND1      load_0_13_16  20
 BV BND1      arc_0_13_17
 UP BND1      load_0_13_17  20
 BV BND1      arc_0_13_18
 UP BND1      load_0_13_18  20
 BV BND1      arc_0_13_19
 UP BND1      load_0_13_19  20
 BV BND1      arc_0_14_0
 UP BND1      load_0_14_0  20
 BV BND1      arc_0_14_1
 UP BND1      load_0_14_1  20
 BV BND1      arc_0_14_2
 UP BND1      load_0_14_2  20
 BV BND1      arc_0_14_3
 UP BND1      load_0_14_3  20
 BV BND1      arc_0_14_4
 UP BND1      load_0_14_4  20
 BV BND1      arc_0_14_12
 UP BND1      load_0_14_12  20
 BV BND1      arc_0_14_13
 UP BND1      load_0_14_13  20
 BV BND1      arc_0_14_15
 UP BND1      load_0_14_15  20
 BV BND1      arc_0_14_16
 UP BND1      load_0_14_16  20
 BV BND1      arc_0_14_17
 UP BND1      load_0_14_17  20
 BV BND1      arc_0_14_18
 UP BND1      load_0_14_18  20
 BV BND1      arc_0_14_19
 UP BND1      load_0_14_19  20
 BV BND1      arc_0_15_0
 UP BND1      load_0_15_0  20
 BV BND1      arc_0_15_1
 UP BND1      load_0_15_1  20
 BV BND1      arc_0_15_2
 UP BND1      load_0_15_2  20
 BV BND1      arc_0_15_3
 UP BND1      load_0_15_3  20
 BV BND1      arc_0_15_4
 UP BND1      load_0_15_4  20
 BV BND1      arc_0_15_12
 UP BND1      load_0_15_12  20
 BV BND1      arc_0_15_13
 UP BND1      load_0_15_13  20
 BV BND1      arc_0_15_14
 UP BND1      load_0_15_14  20
 BV BND1      arc_0_15_16
 UP BND1      load_0_15_16  20
 BV BND1      arc_0_15_17
 UP BND1      load_0_15_17  20
 BV BND1      arc_0_15_18
 UP BND1      load_0_15_18  20
 BV BND1      arc_0_15_19
 UP BND1      load_0_15_19  20
 BV BND1      arc_0_16_0
 UP BND1      load_0_16_0  20
 BV BND1      arc_0_16_1
 UP BND1      load_0_16_1  20
 BV BND1      arc_0_16_2
 UP BND1      load_0_16_2  20
 BV BND1      arc_0_16_3
 UP BND1      load_0_16_3  20
 BV BND1      arc_0_16_4
 UP BND1      load_0_16_4  20
 BV BND1      arc_0_16_12
 UP BND1      load_0_16_12  20
 BV BND1      arc_0_16_13
 UP BND1      load_0_16_13  20
 BV BND1      arc_0_16_14
 UP BND1      load_0_16_14  20
 BV BND1      arc_0_16_15
 UP BND1      load_0_16_15  20
 BV BND1      arc_0_16_17
 UP BND1      load_0_16_17  20
 BV BND1      arc_0_16_18
 UP BND1      load_0_16_18  20
 BV BND1      arc_0_16_19
 UP BND1      load_0_16_19  20
 BV BND1      arc_0_17_0
 UP BND1      load_0_17_0  20
 BV BND1      arc_0_17_1
 UP BND1      load_0_17_1  20
 BV BND1      arc_0_17_2
 UP BND1      load_0_17_2  20
 BV BND1      arc_0_17_3
 UP BND1      load_0_17_3  20
 BV BND1      arc_0_17_4
 UP BND1      load_0_17_4  20
 BV BND1      arc_0_17_12
 UP BND1      load_0_17_12  20
 BV BND1      arc_0_17_13
 UP BND1      load_0_17_13  20
 BV BND1      arc_0_17_14
 UP BND1      load_0_17_14  20
 BV BND1      arc_0_17_15
 UP BND1      load_0_17_15  20
 BV BND1      arc_0_17_16
 UP BND1      load_0_17_16  20
 BV BND1      arc_0_17_18
 UP BND1      load_0_17_18  20
 BV BND1      arc_0_17_19
 UP BND1      load_0_17_19  20
 BV BND1      arc_0_18_0
 UP BND1      load_0_18_0  20
 BV BND1      arc_0_18_1
 UP BND1      load_0_18_1  20
 BV BND1      arc_0_18_2
 UP BND1      load_0_18_2  20
 BV BND1      arc_0_18_3
 UP BND1      load_0_18_3  20
 BV BND1      arc_0_18_4
 UP BND1      load_0_18_4  20
 BV BND1      arc_0_18_12
 UP BND1      load_0_18_12  20
 BV BND1      arc_0_18_13
 UP BND1      load_0_18_13  20
 BV BND1      arc_0_18_14
 UP BND1      load_0_18_14  20
 BV BND1      arc_0_18_15
 UP BND1      load_0_18_15  20
 BV BND1      arc_0_18_16
 UP BND1      load_0_18_16  20
 BV BND1      arc_0_18_17
 UP BND1      load_0_18_17  20
 BV BND1      arc_0_18_19
 UP BND1      load_0_18_19  20
 BV BND1      arc_0_19_0
 UP BND1      load_0_19_0  20
 BV BND1      arc_0_19_1
 UP BND1      load_0_19_1  20
 BV BND1      arc_0_19_2
 UP BND1      load_0_19_2  20
 BV BND1      arc_0_19_3
 UP BND1      load_0_19_3  20
 BV BND1      arc_0_19_4
 UP BND1      load_0_19_4  20
 BV BND1      arc_0_19_12
 UP BND1      load_0_19_12  20
 BV BND1      arc_0_19_13
 UP BND1      load_0_19_13  20
 BV BND1      arc_0_19_14
 UP BND1      load_0_19_14  20
 BV BND1      arc_0_19_15
 UP BND1      load_0_19_15  20
 BV BND1      arc_0_19_16
 UP BND1      load_0_19_16  20
 BV BND1      arc_0_19_17
 UP BND1      load_0_19_17  20
 BV BND1      arc_0_19_18
 UP BND1      load_0_19_18  20
 FX BND1      visit_1_5  1
 UP BND1      order_1_5  12
 FX BND1      visit_1_6  1
 UP BND1      order_1_6  12
 FX BND1      visit_1_7  1
 UP BND1      order_1_7  12
 FX BND1      visit_1_8  1
 UP BND1      order_1_8  12
 UP BND1      visit_1_12  1
 UP BND1      order_1_12  12
 UP BND1      visit_1_13  1
 UP BND1      order_1_13  12
 UP BND1      visit_1_14  1
 UP BND1      order_1_14  12
 UP BND1      visit_1_15  1
 UP BND1      order_1_15  12
 UP BND1      visit_1_16  1
 UP BND1      order_1_16  12
 UP BND1      visit_1_17  1
 UP BND1      order_1_17  12
 UP BND1      visit_1_18  1
 UP BND1      order_1_18  12
 UP BND1      visit_1_19  1
 UP BND1      order_1_19  12
 BV BND1      arc_1_0_0
 FX BND1      load_1_0_0  0
 BV BND1      arc_1_0_5
 FX BND1      load_1_0_5  0
 BV BND1      arc_1_0_6
 FX BND1      load_1_0_6  0
 BV BND1      arc_1_0_7
 FX BND1      load_1_0_7  0
 BV BND1      arc_1_0_8
 FX BND1      load_1_0_8  0
 BV BND1      arc_1_0_12
 FX BND1      load_1_0_12  0
 BV BND1      arc_1_0_13
 FX BND1      load_1_0_13  0
 BV BND1      arc_1_0_14
 FX BND1      load_1_0_14  0
 BV BND1      arc_1_0_15
 FX BND1      load_1_0_15  0
 BV BND1      arc_1_0_16
 FX BND1      load_1_0_16  0
 BV BND1      arc_1_0_17
 FX BND1      load_1_0_17  0
 BV BND1      arc_1_0_18
 FX BND1      load_1_0_18  0
 BV BND1      arc_1_0_19
 FX BND1      load_1_0_19  0
 BV BND1      arc_1_5_0
 UP BND1      load_1_5_0  25
 BV BND1      arc_1_5_6
 UP BND1      load_1_5_6  25
 BV BND1      arc_1_5_7
 UP BND1      load_1_5_7  25
 BV BND1      arc_1_5_8
 UP BND1      load_1_5_8  25
 BV BND1      arc_1_5_12
 UP BND1      load_1_5_12  25
 BV BND1      arc_1_5_13
 UP BND1      load_1_5_13  25
 BV BND1      arc_1_5_14
 UP BND1      load_1_5_14  25
 BV BND1      arc_1_5_15
 UP BND1      load_1_5_15  25
 BV BND1      arc_1_5_16
 UP BND1      load_1_5_16  25
 BV BND1      arc_1_5_17
 UP BND1      load_1_5_17  25
 BV BND1      arc_1_5_18
 UP BND1      load_1_5_18  25
 BV BND1      arc_1_5_19
 UP BND1      load_1_5_19  25
 BV BND1      arc_1_6_0
 UP BND1      load_1_6_0  25
 BV BND1      arc_1_6_5
 UP BND1      load_1_6_5  25
 BV BND1      arc_1_6_7
 UP BND1      load_1_6_7  25
 BV BND1      arc_1_6_8
 UP BND1      load_1_6_8  25
 BV BND1      arc_1_6_12
 UP BND1      load_1_6_12  25
 BV BND1      arc_1_6_13
 UP BND1      load_1_6_13  25
 BV BND1      arc_1_6_14
 UP BND1      load_1_6_14  25
 BV BND1      arc_1_6_15
 UP BND1      load_1_6_15  25
 BV BND1      arc_1_6_16
 UP BND1      load_1_6_16  25
 BV BND1      arc_1_6_17
 UP BND1      load_1_6_17  25
 BV BND1      arc_1_6_18
 UP BND1      load_1_6_18  25
 BV BND1      arc_1_6_19
 UP BND1      load_1_6_19  25
 BV BND1      arc_1_7_0
 UP BND1      load_1_7_0  25
 BV BND1      arc_1_7_5
 UP BND1      load_1_7_5  25
 BV BND1      arc_1_7_6
 UP BND1      load_1_7_6  25
 BV BND1      arc_1_7_8
 UP BND1      load_1_7_8  25
 BV BND1      arc_1_7_12
 UP BND1      load_1_7_12  25
 BV BND1      arc_1_7_13
 UP BND1      load_1_7_13  25
 BV BND1      arc_1_7_14
 UP BND1      load_1_7_14  25
 BV BND1      arc_1_7_15
 UP BND1      load_1_7_15  25
 BV BND1      arc_1_7_16
 UP BND1      load_1_7_16  25
 BV BND1      arc_1_7_17
 UP BND1      load_1_7_17  25
 BV BND1      arc_1_7_18
 UP BND1      load_1_7_18  25
 BV BND1      arc_1_7_19
 UP BND1      load_1_7_19  25
 BV BND1      arc_1_8_0
 UP BND1      load_1_8_0  25
 BV BND1      arc_1_8_5
 UP BND1      load_1_8_5  25
 BV BND1      arc_1_8_6
 UP BND1      load_1_8_6  25
 BV BND1      arc_1_8_7
 UP BND1      load_1_8_7  25
 BV BND1      arc_1_8_12
 UP BND1      load_1_8_12  25
 BV BND1      arc_1_8_13
 UP BND1      load_1_8_13  25
 BV BND1      arc_1_8_14
 UP BND1      load_1_8_14  25
 BV BND1      arc_1_8_15
 UP BND1      load_1_8_15  25
 BV BND1      arc_1_8_16
 UP BND1      load_1_8_16  25
 BV BND1      arc_1_8_17
 UP BND1      load_1_8_17  25
 BV BND1      arc_1_8_18
 UP BND1      load_1_8_18  25
 BV BND1      arc_1_8_19
 UP BND1      load_1_8_19  25
 BV BND1      arc_1_12_0
 UP BND1      load_1_12_0  25
 BV BND1      arc_1_12_5
 UP BND1      load_1_12_5  25
 BV BND1      arc_1_12_6
 UP BND1      load_1_12_6  25
 BV BND1      arc_1_12_7
 UP BND1      load_1_12_7  25
 BV BND1      arc_1_12_8
 UP BND1      load_1_12_8  25
 BV BND1      arc_1_12_13
 UP BND1      load_1_12_13  25
 BV BND1      arc_1_12_14
 UP BND1      load_1_12_14  25
 BV BND1      arc_1_12_15
 UP BND1      load_1_12_15  25
 BV BND1      arc_1_12_16
 UP BND1      load_1_12_16  25
 BV BND1      arc_1_12_17
 UP BND1      load_1_12_17  25
 BV BND1      arc_1_12_18
 UP BND1      load_1_12_18  25
 BV BND1      arc_1_12_19
 UP BND1      load_1_12_19  25
 BV BND1      arc_1_13_0
 UP BND1      load_1_13_0  25
 BV BND1      arc_1_13_5
 UP BND1      load_1_13_5  25
 BV BND1      arc_1_13_6
 UP BND1      load_1_13_6  25
 BV BND1      arc_1_13_7
 UP BND1      load_1_13_7  25
 BV BND1      arc_1_13_8
 UP BND1      load_1_13_8  25
 BV BND1      arc_1_13_12
 UP BND1      load_1_13_12  25
 BV BND1      arc_1_13_14
 UP BND1      load_1_13_14  25
 BV BND1      arc_1_13_15
 UP BND1      load_1_13_15  25
 BV BND1      arc_1_13_16
 UP BND1      load_1_13_16  25
 BV BND1      arc_1_13_17
 UP BND1      load_1_13_17  25
 BV BND1      arc_1_13_18
 UP BND1      load_1_13_18  25
 BV BND1      arc_1_13_19
 UP BND1      load_1_13_19  25
 BV BND1      arc_1_14_0
 UP BND1      load_1_14_0  25
 BV BND1      arc_1_14_5
 UP BND1      load_1_14_5  25
 BV BND1      arc_1_14_6
 UP BND1      load_1_14_6  25
 BV BND1      arc_1_14_7
 UP BND1      load_1_14_7  25
 BV BND1      arc_1_14_8
 UP BND1      load_1_14_8  25
 BV BND1      arc_1_14_12
 UP BND1      load_1_14_12  25
 BV BND1      arc_1_14_13
 UP BND1      load_1_14_13  25
 BV BND1      arc_1_14_15
 UP BND1      load_1_14_15  25
 BV BND1      arc_1_14_16
 UP BND1      load_1_14_16  25
 BV BND1      arc_1_14_17
 UP BND1      load_1_14_17  25
 BV BND1      arc_1_14_18
 UP BND1      load_1_14_18  25
 BV BND1      arc_1_14_19
 UP BND1      load_1_14_19  25
 BV BND1      arc_1_15_0
 UP BND1      load_1_15_0  25
 BV BND1      arc_1_15_5
 UP BND1      load_1_15_5  25
 BV BND1      arc_1_15_6
 UP BND1      load_1_15_6  25
 BV BND1      arc_1_15_7
 UP BND1      load_1_15_7  25
 BV BND1      arc_1_15_8
 UP BND1      load_1_15_8  25
 BV BND1      arc_1_15_12
 UP BND1      load_1_15_12  25
 BV BND1      arc_1_15_13
 UP BND1      load_1_15_13  25
 BV BND1      arc_1_15_14
 UP BND1      load_1_15_14  25
 BV BND1      arc_1_15_16
 UP BND1      load_1_15_16  25
 BV BND1      arc_1_15_17
 UP BND1      load_1_15_17  25
 BV BND1      arc_1_15_18
 UP BND1      load_1_15_18  25
 BV BND1      arc_1_15_19
 UP BND1      load_1_15_19  25
 BV BND1      arc_1_16_0
 UP BND1      load_1_16_0  25
 BV BND1      arc_1_16_5
 UP BND1      load_1_16_5  25
 BV BND1      arc_1_16_6
 UP BND1      load_1_16_6  25
 BV BND1      arc_1_16_7
 UP BND1      load_1_16_7  25
 BV BND1      arc_1_16_8
 UP BND1      load_1_16_8  25
 BV BND1      arc_1_16_12
 UP BND1      load_1_16_12  25
 BV BND1      arc_1_16_13
 UP BND1      load_1_16_13  25
 BV BND1      arc_1_16_14
 UP BND1      load_1_16_14  25
 BV BND1      arc_1_16_15
 UP BND1      load_1_16_15  25
 BV BND1      arc_1_16_17
 UP BND1      load_1_16_17  25
 BV BND1      arc_1_16_18
 UP BND1      load_1_16_18  25
 BV BND1      arc_1_16_19
 UP BND1      load_1_16_19  25
 BV BND1      arc_1_17_0
 UP BND1      load_1_17_0  25
 BV BND1      arc_1_17_5
 UP BND1      load_1_17_5  25
 BV BND1      arc_1_17_6
 UP BND1      load_1_17_6  25
 BV BND1      arc_1_17_7
 UP BND1      load_1_17_7  25
 BV BND1      arc_1_17_8
 UP BND1      load_1_17_8  25
 BV BND1      arc_1_17_12
 UP BND1      load_1_17_12  25
 BV BND1      arc_1_17_13
 UP BND1      load_1_17_13  25
 BV BND1      arc_1_17_14
 UP BND1      load_1_17_14  25
 BV BND1      arc_1_17_15
 UP BND1      load_1_17_15  25
 BV BND1      arc_1_17_16
 UP BND1      load_1_17_16  25
 BV BND1      arc_1_17_18
 UP BND1      load_1_17_18  25
 BV BND1      arc_1_17_19
 UP BND1      load_1_17_19  25
 BV BND1      arc_1_18_0
 UP BND1      load_1_18_0  25
 BV BND1      arc_1_18_5
 UP BND1      load_1_18_5  25
 BV BND1      arc_1_18_6
 UP BND1      load_1_18_6  25
 BV BND1      arc_1_18_7
 UP BND1      load_1_18_7  25
 BV BND1      arc_1_18_8
 UP BND1      load_1_18_8  25
 BV BND1      arc_1_18_12
 UP BND1      load_1_18_12  25
 BV BND1      arc_1_18_13
 UP BND1      load_1_18_13  25
 BV BND1      arc_1_18_14
 UP BND1      load_1_18_14  25
 BV BND1      arc_1_18_15
 UP BND1      load_1_18_15  25
 BV BND1      arc_1_18_16
 UP BND1      load_1_18_16  25
 BV BND1      arc_1_18_17
 UP BND1      load_1_18_17  25
 BV BND1      arc_1_18_19
 UP BND1      load_1_18_19  25
 BV BND1      arc_1_19_0
 UP BND1      load_1_19_0  25
 BV BND1      arc_1_19_5
 UP BND1      load_1_19_5  25
 BV BND1      arc_1_19_6
 UP BND1      load_1_19_6  25
 BV BND1      arc_1_19_7
 UP BND1      load_1_19_7  25
 BV BND1      arc_1_19_8
 UP BND1      load_1_19_8  25
 BV BND1      arc_1_19_12
 UP BND1      load_1_19_12  25
 BV BND1      arc_1_19_13
 UP BND1      load_1_19_13  25
 BV BND1      arc_1_19_14
 UP BND1      load_1_19_14  25
 BV BND1      arc_1_19_15
 UP BND1      load_1_19_15  25
 BV BND1      arc_1_19_16
 UP BND1      load_1_19_16  25
 BV BND1      arc_1_19_17
 UP BND1      load_1_19_17  25
 BV BND1      arc_1_19_18
 UP BND1      load_1_19_18  25
 FX BND1      visit_2_9  1
 UP BND1      order_2_9  11
 FX BND1      visit_2_10  1
 UP BND1      order_2_10  11
 FX BND1      visit_2_11  1
 UP BND1      order_2_11  11
 UP BND1      visit_2_12  1
 UP BND1      order_2_12  11
 UP BND1      visit_2_13  1
 UP BND1      order_2_13  11
 UP BND1      visit_2_14  1
 UP BND1      order_2_14  11
 UP BND1      visit_2_15  1
 UP BND1      order_2_15  11
 UP BND1      visit_2_16  1
 UP BND1      order_2_16  11
 UP BND1      visit_2_17  1
 UP BND1      order_2_17  11
 UP BND1      visit_2_18  1
 UP BND1      order_2_18  11
 UP BND1      visit_2_19  1
 UP BND1      order_2_19  11
 BV BND1      arc_2_0_0
 FX BND1      load_2_0_0  0
 BV BND1      arc_2_0_9
 FX BND1      load_2_0_9  0
 BV BND1      arc_2_0_10
 FX BND1      load_2_0_10  0
 BV BND1      arc_2_0_11
 FX BND1      load_2_0_11  0
 BV BND1      arc_2_0_12
 FX BND1      load_2_0_12  0
 BV BND1      arc_2_0_13
 FX BND1      load_2_0_13  0
 BV BND1      arc_2_0_14
 FX BND1      load_2_0_14  0
 BV BND1      arc_2_0_15
 FX BND1      load_2_0_15  0
 BV BND1      arc_2_0_16
 FX BND1      load_2_0_16  0
 BV BND1      arc_2_0_17
 FX BND1      load_2_0_17  0
 BV BND1      arc_2_0_18
 FX BND1      load_2_0_18  0
 BV BND1      arc_2_0_19
 FX BND1      load_2_0_19  0
 BV BND1      arc_2_9_0
 UP BND1      load_2_9_0  30
 BV BND1      arc_2_9_10
 UP BND1      load_2_9_10  30
 BV BND1      arc_2_9_11
 UP BND1      load_2_9_11  30
 BV BND1      arc_2_9_12
 UP BND1      load_2_9_12  30
 BV BND1      arc_2_9_13
 UP BND1      load_2_9_13  30
 BV BND1      arc_2_9_14
 UP BND1      load_2_9_14  30
 BV BND1      arc_2_9_15
 UP BND1      load_2_9_15  30
 BV BND1      arc_2_9_16
 UP BND1      load_2_9_16  30
 BV BND1      arc_2_9_17
 UP BND1      load_2_9_17  30
 BV BND1      arc_2_9_18
 UP BND1      load_2_9_18  30
 BV BND1      arc_2_9_19
 UP BND1      load_2_9_19  30
 BV BND1      arc_2_10_0
 UP BND1      load_2_10_0  30
 BV BND1      arc_2_10_9
 UP BND1      load_2_10_9  30
 BV BND1      arc_2_10_11
 UP BND1      load_2_10_11  30
 BV BND1      arc_2_10_12
 UP BND1      load_2_10_12  30
 BV BND1      arc_2_10_13
 UP BND1      load_2_10_13  30
 BV BND1      arc_2_10_14
 UP BND1      load_2_10_14  30
 BV BND1      arc_2_10_15
 UP BND1      load_2_10_15  30
 BV BND1      arc_2_10_16
 UP BND1      load_2_10_16  30
 BV BND1      arc_2_10_17
 UP BND1      load_2_10_17  30
 BV BND1      arc_2_10_18
 UP BND1      load_2_10_18  30
 BV BND1      arc_2_10_19
 UP BND1      load_2_10_19  30
 BV BND1      arc_2_11_0
 UP BND1      load_2_11_0  30
 BV BND1      arc_2_11_9
 UP BND1      load_2_11_9  30
 BV BND1      arc_2_11_10
 UP BND1      load_2_11_10  30
 BV BND1      arc_2_11_12
 UP BND1      load_2_11_12  30
 BV BND1      arc_2_11_13
 UP BND1      load_2_11_13  30
 BV BND1      arc_2_11_14
 UP BND1      load_2_11_14  30
 BV BND1      arc_2_11_15
 UP BND1      load_2_11_15  30
 BV BND1      arc_2_11_16
 UP BND1      load_2_11_16  30
 BV BND1      arc_2_11_17
 UP BND1      load_2_11_17  30
 BV BND1      arc_2_11_18
 UP BND1      load_2_11_18  30
 BV BND1      arc_2_11_19
 UP BND1      load_2_11_19  30
 BV BND1      arc_2_12_0
 UP BND1      load_2_12_0  30
 BV BND1      arc_2_12_9
 UP BND1      load_2_12_9  30
 BV BND1      arc_2_12_10
 UP BND1      load_2_12_10  30
 BV BND1      arc_2_12_11
 UP BND1      load_2_12_11  30
 BV BND1      arc_2_12_13
 UP BND1      load_2_12_13  30
 BV BND1      arc_2_12_14
 UP BND1      load_2_12_14  30
 BV BND1      arc_2_12_15
 UP BND1      load_2_12_15  30
 BV BND1      arc_2_12_16
 UP BND1      load_2_12_16  30
 BV BND1      arc_2_12_17
 UP BND1      load_2_12_17  30
 BV BND1      arc_2_12_18
 UP BND1      load_2_12_18  30
 BV BND1      arc_2_12_19
 UP BND1      load_2_12_19  30
 BV BND1      arc_2_13_0
 UP BND1      load_2_13_0  30
 BV BND1      arc_2_13_9
 UP BND1      load_2_13_9  30
 BV BND1      arc_2_13_10
 UP BND1      load_2_13_10  30
 BV BND1      arc_2_13_11
 UP BND1      load_2_13_11  30
 BV BND1      arc_2_13_12
 UP BND1      load_2_13_12  30
 BV BND1      arc_2_13_14
 UP BND1      load_2_13_14  30
 BV BND1      arc_2_13_15
 UP BND1      load_2_13_15  30
 BV BND1      arc_2_13_16
 UP BND1      load_2_13_16  30
 BV BND1      arc_2_13_17
 UP BND1      load_2_13_17  30
 BV BND1      arc_2_13_18
 UP BND1      load_2_13_18  30
 BV BND1      arc_2_13_19
 UP BND1      load_2_13_19  30
 BV BND1      arc_2_14_0
 UP BND1      load_2_14_0  30
 BV BND1      arc_2_14_9
 UP BND1      load_2_14_9  30
 BV BND1      arc_2_14_10
 UP BND1      load_2_14_10  30
 BV BND1      arc_2_14_11
 UP BND1      load_2_14_11  30
 BV BND1      arc_2_14_12
 UP BND1      load_2_14_12  30
 BV BND1      arc_2_14_13
 UP BND1      load_2_14_13  30
 BV BND1      arc_2_14_15
 UP BND1      load_2_14_15  30
 BV BND1      arc_2_14_16
 UP BND1      load_2_14_16  30
 BV BND1      arc_2_14_17
 UP BND1      load_2_14_17  30
 BV BND1      arc_2_14_18
 UP BND1      load_2_14_18  30
 BV BND1      arc_2_14_19
 UP BND1      load_2_14_19  30
 BV BND1      arc_2_15_0
 UP BND1      load_2_15_0  30
 BV BND1      arc_2_15_9
 UP BND1      load_2_15_9  30
 BV BND1      arc_2_15_10
 UP BND1      load_2_15_10  30
 BV BND1      arc_2_15_11
 UP BND1      load_2_15_11  30
 BV BND1      arc_2_15_12
 UP BND1      load_2_15_12  30
 BV BND1      arc_2_15_13
 UP BND1      load_2_15_13  30
 BV BND1      arc_2_15_14
 UP BND1      load_2_15_14  30
 BV BND1      arc_2_15_16
 UP BND1      load_2_15_16  30
 BV BND1      arc_2_15_17
 UP BND1      load_2_15_17  30
 BV BND1      arc_2_15_18
 UP BND1      load_2_15_18  30
 BV BND1      arc_2_15_19
 UP BND1      load_2_15_19  30
 BV BND1      arc_2_16_0
 UP BND1      load_2_16_0  30
 BV BND1      arc_2_16_9
 UP BND1      load_2_16_9  30
 BV BND1      arc_2_16_10
 UP BND1      load_2_16_10  30
 BV BND1      arc_2_16_11
 UP BND1      load_2_16_11  30
 BV BND1      arc_2_16_12
 UP BND1      load_2_16_12  30
 BV BND1      arc_2_16_13
 UP BND1      load_2_16_13  30
 BV BND1      arc_2_16_14
 UP BND1      load_2_16_14  30
 BV BND1      arc_2_16_15
 UP BND1      load_2_16_15  30
 BV BND1      arc_2_16_17
 UP BND1      load_2_16_17  30
 BV BND1      arc_2_16_18
 UP BND1      load_2_16_18  30
 BV BND1      arc_2_16_19
 UP BND1      load_2_16_19  30
 BV BND1      arc_2_17_0
 UP BND1      load_2_17_0  30
 BV BND1      arc_2_17_9
 UP BND1      load_2_17_9  30
 BV BND1      arc_2_17_10
 UP BND1      load_2_17_10  30
 BV BND1      arc_2_17_11
 UP BND1      load_2_17_11  30
 BV BND1      arc_2_17_12
 UP BND1      load_2_17_12  30
 BV BND1      arc_2_17_13
 UP BND1      load_2_17_13  30
 BV BND1      arc_2_17_14
 UP BND1      load_2_17_14  30
 BV BND1      arc_2_17_15
 UP BND1      load_2_17_15  30
 BV BND1      arc_2_17_16
 UP BND1      load_2_17_16  30
 BV BND1      arc_2_17_18
 UP BND1      load_2_17_18  30
 BV BND1      arc_2_17_19
 UP BND1      load_2_17_19  30
 BV BND1      arc_2_18_0
 UP BND1      load_2_18_0  30
 BV BND1      arc_2_18_9
 UP BND1      load_2_18_9  30
 BV BND1      arc_2_18_10
 UP BND1      load_2_18_10  30
 BV BND1      arc_2_18_11
 UP BND1      load_2_18_11  30
 BV BND1      arc_2_18_12
 UP BND1      load_2_18_12  30
 BV BND1      arc_2_18_13
 UP BND1      load_2_18_13  30
 BV BND1      arc_2_18_14
 UP BND1      load_2_18_14  30
 BV BND1      arc_2_18_15
 UP BND1      load_2_18_15  30
 BV BND1      arc_2_18_16
 UP BND1      load_2_18_16  30
 BV BND1      arc_2_18_17
 UP BND1      load_2_18_17  30
 BV BND1      arc_2_18_19
 UP BND1      load_2_18_19  30
 BV BND1      arc_2_19_0
 UP BND1      load_2_19_0  30
 BV BND1      arc_2_19_9
 UP BND1      load_2_19_9  30
 BV BND1      arc_2_19_10
 UP BND1      load_2_19_10  30
 BV BND1      arc_2_19_11
 UP BND1      load_2_19_11  30
 BV BND1      arc_2_19_12
 UP BND1      load_2_19_12  30
 BV BND1      arc_2_19_13
 UP BND1      load_2_19_13  30
 BV BND1      arc_2_19_14
 UP BND1      load_2_19_14  30
 BV BND1      arc_2_19_15
 UP BND1      load_2_19_15  30
 BV BND1      arc_2_19_16
 UP BND1      load_2_19_16  30
 BV BND1      arc_2_19_17
 UP BND1      load_2_19_17  30
 BV BND1      arc_2_19_18
 UP BND1      load_2_19_18  30
ENDATA
